"""Tests for auth bootstrap logic and AuthMiddleware enforcement.

This module manages its own auth state — conftest's _test_auth_mode fixture
is excluded for these tests so we can test real auth behaviour.
"""

from __future__ import annotations

import hashlib
import os
from unittest.mock import patch, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from starlette.responses import JSONResponse


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _reset_hash():
    from ravmem.auth.bootstrap import _set_admin_hash
    _set_admin_hash("")


@pytest.fixture(autouse=True)
def _clean_admin_hash():
    """Ensure module-level admin hash is cleared before and after every test."""
    _reset_hash()
    yield
    _reset_hash()


def _make_app_with_auth(test_token: str) -> tuple[TestClient, str]:
    """Return a (TestClient, token) for a minimal app with auth enforced."""
    from ravmem.auth.bootstrap import _set_admin_hash
    from ravmem.server.auth import AuthMiddleware

    token_hash = hashlib.sha256(test_token.encode()).hexdigest()
    _set_admin_hash(token_hash)

    app = FastAPI()
    app.add_middleware(AuthMiddleware)

    @app.get("/api/projects")
    async def projects():
        return []

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    return TestClient(app, raise_server_exceptions=True), test_token


# ---------------------------------------------------------------------------
# Bootstrap — three documented cases
# ---------------------------------------------------------------------------

_PATCH_BASE = "ravmem.auth.bootstrap"


class TestBootstrapDocumentedCases:
    def test_env_token_hashes_and_stores(self):
        """Case 1: RAVMEM_ADMIN_TOKEN set → hash stored in DB and loaded in memory."""
        from ravmem.auth.bootstrap import bootstrap, get_admin_hash

        with (
            patch.dict(os.environ, {"RAVMEM_ADMIN_TOKEN": "rv_admin_testtoken"}),
            patch(f"{_PATCH_BASE}._ensure_system_db"),
            patch(f"{_PATCH_BASE}._apply_schema"),
            patch(f"{_PATCH_BASE}._upsert_hash") as mock_upsert,
        ):
            bootstrap("ravmem_system")

        expected = hashlib.sha256(b"rv_admin_testtoken").hexdigest()
        mock_upsert.assert_called_once_with("ravmem_system", expected)
        assert get_admin_hash() == expected

    def test_existing_hash_loads_silently(self):
        """Case 2: env unset, hash exists in DB → loaded without printing a new token."""
        from ravmem.auth.bootstrap import bootstrap, get_admin_hash

        stored_hash = "a" * 64

        with (
            patch.dict(os.environ, {}, clear=False),
            patch(f"{_PATCH_BASE}.os.environ.get", return_value=""),
            patch(f"{_PATCH_BASE}._ensure_system_db"),
            patch(f"{_PATCH_BASE}._apply_schema"),
            patch(f"{_PATCH_BASE}._query_existing_hash", return_value=stored_hash),
            patch(f"{_PATCH_BASE}._print_generated_token") as mock_print,
        ):
            bootstrap("ravmem_system")

        mock_print.assert_not_called()
        assert get_admin_hash() == stored_hash

    def test_fresh_install_generates_and_prints_token(self, capsys):
        """Case 3: env unset, no hash in DB → token generated, printed, stored."""
        from ravmem.auth.bootstrap import bootstrap, get_admin_hash

        with (
            patch(f"{_PATCH_BASE}.os.environ.get", return_value=""),
            patch(f"{_PATCH_BASE}._ensure_system_db"),
            patch(f"{_PATCH_BASE}._apply_schema"),
            patch(f"{_PATCH_BASE}._query_existing_hash", return_value=None),
            patch(f"{_PATCH_BASE}._upsert_hash"),
        ):
            bootstrap("ravmem_system")

        captured = capsys.readouterr()
        assert "RAVMEM ADMIN TOKEN" in captured.out
        assert "rv_admin_" in captured.out
        h = get_admin_hash()
        assert h != "", "Admin hash must be set after fresh install bootstrap"
        assert len(h) == 64, "Hash must be a SHA-256 hexdigest (64 chars)"


# ---------------------------------------------------------------------------
# Bootstrap — exception / degraded paths
# ---------------------------------------------------------------------------

class TestBootstrapFailurePaths:
    def test_arcadedb_failure_with_env_token_loads_in_memory(self):
        """ArcadeDB unreachable + env token set → in-memory hash, no crash."""
        from ravmem.auth.bootstrap import bootstrap, get_admin_hash

        with (
            patch.dict(os.environ, {"RAVMEM_ADMIN_TOKEN": "rv_admin_envtoken"}),
            patch(f"{_PATCH_BASE}._ensure_system_db", side_effect=ConnectionError("refused")),
        ):
            bootstrap("ravmem_system")

        expected = hashlib.sha256(b"rv_admin_envtoken").hexdigest()
        assert get_admin_hash() == expected

    def test_arcadedb_failure_no_env_token_generates_ephemeral_token(self, capsys):
        """ArcadeDB unreachable + no env token → ephemeral token generated, auth enforced.

        This is THE fix: before the patch, this path left _admin_token_hash = ""
        which caused the middleware to silently allow all requests through.
        """
        from ravmem.auth.bootstrap import bootstrap, get_admin_hash

        with (
            patch(f"{_PATCH_BASE}.os.environ.get", return_value=""),
            patch(f"{_PATCH_BASE}._ensure_system_db", side_effect=ConnectionError("refused")),
        ):
            bootstrap("ravmem_system")

        captured = capsys.readouterr()
        assert "RAVMEM ADMIN TOKEN" in captured.out, (
            "Ephemeral token must be printed so the operator can authenticate"
        )
        h = get_admin_hash()
        assert h != "", (
            "Admin hash MUST be set even when ArcadeDB is unreachable — "
            "empty hash previously caused auth to be silently disabled"
        )
        assert len(h) == 64

    def test_schema_failure_no_env_token_still_sets_hash(self, capsys):
        """DDL/schema failure with no env token also falls into ephemeral path."""
        from ravmem.auth.bootstrap import bootstrap, get_admin_hash

        with (
            patch(f"{_PATCH_BASE}.os.environ.get", return_value=""),
            patch(f"{_PATCH_BASE}._ensure_system_db"),
            patch(f"{_PATCH_BASE}._apply_schema", side_effect=RuntimeError("DDL failed")),
        ):
            bootstrap("ravmem_system")

        assert get_admin_hash() != ""


# ---------------------------------------------------------------------------
# AuthMiddleware — request enforcement
# ---------------------------------------------------------------------------

class TestAuthMiddlewareEnforcement:
    def test_protected_endpoint_rejects_unauthenticated(self):
        """Protected routes return 401 when auth is enabled and no token is sent."""
        client, _ = _make_app_with_auth("rv_admin_secret_token_abc")
        resp = client.get("/api/projects")
        assert resp.status_code == 401, (
            f"Expected 401 for unauthenticated request, got {resp.status_code}"
        )

    def test_valid_admin_token_grants_access(self):
        """Correct Bearer token passes through the middleware."""
        client, token = _make_app_with_auth("rv_admin_secret_token_abc")
        resp = client.get("/api/projects", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 200

    def test_wrong_token_returns_401(self):
        """Wrong token returns 401, not 200.

        The wrong-token path tries the user-token DB lookup; mock bcrypt (not
        installed in this env) and stub the lookup to return None (not found).
        """
        import sys
        from unittest.mock import AsyncMock

        mock_bcrypt = MagicMock()
        with patch.dict(sys.modules, {"bcrypt": mock_bcrypt}):
            client, _ = _make_app_with_auth("rv_admin_correct_token")
            with patch("ravmem.server.auth.asyncio.to_thread", new_callable=AsyncMock, return_value=None):
                resp = client.get("/api/projects",
                                  headers={"Authorization": "Bearer rv_admin_wrong"})
        assert resp.status_code == 401

    def test_malformed_auth_header_returns_401(self):
        """Non-Bearer auth scheme returns 401."""
        client, token = _make_app_with_auth("rv_admin_secret_token_abc")
        resp = client.get("/api/projects", headers={"Authorization": token})
        assert resp.status_code == 401

    def test_exempt_health_path_always_passes(self):
        """Exempt paths like /health pass through even without a token."""
        client, _ = _make_app_with_auth("rv_admin_secret_token_abc")
        resp = client.get("/health")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# AuthMiddleware — dev mode requires explicit opt-in
# ---------------------------------------------------------------------------

class TestDevModeExplicitOptIn:
    def test_empty_hash_without_dev_flag_returns_503(self):
        """Empty admin hash + no RAVMEM_AUTH_DISABLED → 503, never a silent open door."""
        from ravmem.server.auth import AuthMiddleware

        # hash is "" (reset by autouse fixture)
        app = FastAPI()
        app.add_middleware(AuthMiddleware)

        @app.get("/api/projects")
        async def projects():
            return []

        env = {k: v for k, v in os.environ.items() if k != "RAVMEM_AUTH_DISABLED"}
        with patch.dict(os.environ, env, clear=True):
            client = TestClient(app, raise_server_exceptions=True)
            resp = client.get("/api/projects")

        assert resp.status_code == 503, (
            f"Empty hash without RAVMEM_AUTH_DISABLED must return 503, got {resp.status_code}"
        )

    def test_empty_hash_with_dev_flag_passes_through(self):
        """Empty hash + RAVMEM_AUTH_DISABLED=true → pass-through (explicit dev mode)."""
        from ravmem.server.auth import AuthMiddleware

        app = FastAPI()
        app.add_middleware(AuthMiddleware)

        @app.get("/api/projects")
        async def projects():
            return []

        with patch.dict(os.environ, {"RAVMEM_AUTH_DISABLED": "true"}):
            client = TestClient(app, raise_server_exceptions=True)
            resp = client.get("/api/projects")

        assert resp.status_code == 200, (
            "RAVMEM_AUTH_DISABLED=true must enable dev mode pass-through"
        )

    def test_dev_mode_not_triggered_by_bootstrap_failure(self, capsys):
        """After a bootstrap failure with no env token, hash is set (not empty).

        Regression test for the original bug: bootstrap failure used to leave
        hash="" which silently activated dev mode in the middleware.
        """
        from ravmem.auth.bootstrap import bootstrap, get_admin_hash

        with (
            patch(f"{_PATCH_BASE}.os.environ.get", return_value=""),
            patch(f"{_PATCH_BASE}._ensure_system_db", side_effect=Exception("timeout")),
        ):
            bootstrap("ravmem_system")

        assert get_admin_hash() != "", (
            "Bootstrap failure must not leave an empty hash — "
            "empty hash previously triggered silent open dev mode in the middleware"
        )
