"""Unit tests for RavMemClient and client config helpers."""

from __future__ import annotations

import json
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import httpx
import pytest

from ravmem.client.api import RavMemClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_response(status_code: int = 200, json_data=None, raise_error=False):
    """Return a MagicMock that looks like an httpx.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data if json_data is not None else {}
    if raise_error:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    else:
        resp.raise_for_status.return_value = None
    return resp


# ---------------------------------------------------------------------------
# 1. Initialization
# ---------------------------------------------------------------------------

class TestRavMemClientInit:
    def test_no_api_key_no_auth_header(self):
        with patch("httpx.Client.__init__", return_value=None) as mock_init:
            client = RavMemClient(base_url="http://localhost:7432")
            _, kwargs = mock_init.call_args
            headers = kwargs.get("headers", {})
            assert "Authorization" not in headers

    def test_with_api_key_sets_bearer_header(self):
        with patch("httpx.Client.__init__", return_value=None) as mock_init:
            client = RavMemClient(
                base_url="http://localhost:7432", api_key="secret123"
            )
            _, kwargs = mock_init.call_args
            headers = kwargs.get("headers", {})
            assert headers.get("Authorization") == "Bearer secret123"


# ---------------------------------------------------------------------------
# 2. Project methods
# ---------------------------------------------------------------------------

class TestProjectMethods:
    def setup_method(self):
        self.client = RavMemClient(base_url="http://localhost:7432")

    def _patch_request(self, json_data=None):
        resp = _make_response(json_data=json_data or {})
        return patch.object(self.client._client, "request", return_value=resp)

    def test_create_project_with_git_url(self):
        with self._patch_request({"id": "proj-1"}) as mock_req:
            result = self.client.create_project(git_url="https://github.com/org/repo")
        mock_req.assert_called_once_with(
            "POST",
            "/api/projects",
            json={
                "default_branch": "main",
                "mount": False,
                "git_url": "https://github.com/org/repo",
            },
        )
        assert result == {"id": "proj-1"}

    def test_create_project_with_repo_path(self):
        with self._patch_request({"id": "proj-2"}) as mock_req:
            self.client.create_project(repo_path="/tmp/myrepo")
        mock_req.assert_called_once_with(
            "POST",
            "/api/projects",
            json={"default_branch": "main", "mount": False, "repo_path": "/tmp/myrepo"},
        )

    def test_list_projects(self):
        with self._patch_request([{"id": "p1"}, {"id": "p2"}]) as mock_req:
            result = self.client.list_projects()
        mock_req.assert_called_once_with("GET", "/api/projects")
        assert result == [{"id": "p1"}, {"id": "p2"}]

    def test_get_project(self):
        with self._patch_request({"id": "my-proj"}) as mock_req:
            result = self.client.get_project("my-proj")
        mock_req.assert_called_once_with("GET", "/api/projects/my-proj")
        assert result == {"id": "my-proj"}

    def test_delete_project(self):
        with self._patch_request({"deleted": True}) as mock_req:
            result = self.client.delete_project("my-proj")
        mock_req.assert_called_once_with("DELETE", "/api/projects/my-proj")
        assert result == {"deleted": True}


# ---------------------------------------------------------------------------
# 3. Branch methods
# ---------------------------------------------------------------------------

class TestBranchMethods:
    def setup_method(self):
        self.client = RavMemClient(base_url="http://localhost:7432")

    def _patch_request(self, json_data=None):
        resp = _make_response(json_data=json_data or {})
        return patch.object(self.client._client, "request", return_value=resp)

    def test_index_branch_full_mode(self):
        with self._patch_request({"job_id": 1}) as mock_req:
            result = self.client.index_branch("proj", "main", mode="full")
        mock_req.assert_called_once_with(
            "POST",
            "/api/projects/proj/branches/main/index",
            json={"mode": "full"},
        )
        assert result == {"job_id": 1}

    def test_list_branches(self):
        with self._patch_request([{"name": "main"}]) as mock_req:
            result = self.client.list_branches("proj")
        mock_req.assert_called_once_with("GET", "/api/projects/proj/branches")
        assert result == [{"name": "main"}]

    def test_get_branch_status(self):
        with self._patch_request({"status": "indexed"}) as mock_req:
            result = self.client.get_branch_status("proj", "main")
        mock_req.assert_called_once_with(
            "GET", "/api/projects/proj/branches/main/status"
        )
        assert result == {"status": "indexed"}

    def test_delete_branch_index(self):
        with self._patch_request({"deleted": True}) as mock_req:
            result = self.client.delete_branch_index("proj", "main")
        mock_req.assert_called_once_with(
            "DELETE", "/api/projects/proj/branches/main/index"
        )
        assert result == {"deleted": True}


# ---------------------------------------------------------------------------
# 4. Query methods
# ---------------------------------------------------------------------------

class TestQueryMethods:
    def setup_method(self):
        self.client = RavMemClient(base_url="http://localhost:7432")

    def _patch_request(self, json_data=None):
        resp = _make_response(json_data=json_data if json_data is not None else {})
        return patch.object(self.client._client, "request", return_value=resp)

    def test_search_sends_correct_params(self):
        hits = [{"id": "sym1"}, {"id": "sym2"}]
        with self._patch_request(hits) as mock_req:
            result = self.client.search("proj", "main", "foo", limit=5)
        mock_req.assert_called_once_with(
            "GET",
            "/api/projects/proj/branches/main/search",
            params={"q": "foo", "limit": 5},
        )
        assert result == hits

    def test_impact_sends_depth_param(self):
        with self._patch_request({"nodes": []}) as mock_req:
            result = self.client.impact("proj", "main", "sym123", depth=2)
        mock_req.assert_called_once_with(
            "GET",
            "/api/projects/proj/branches/main/impact/sym123",
            params={"depth": 2},
        )
        assert result == {"nodes": []}

    def test_get_symbol(self):
        sym = {"id": "sym123", "name": "my_func"}
        with self._patch_request(sym) as mock_req:
            result = self.client.get_symbol("proj", "main", "sym123")
        mock_req.assert_called_once_with(
            "GET", "/api/projects/proj/branches/main/symbols/sym123"
        )
        assert result == sym

    def test_get_clusters(self):
        clusters = [{"id": "c1"}, {"id": "c2"}]
        with self._patch_request(clusters) as mock_req:
            result = self.client.get_clusters("proj", "main")
        mock_req.assert_called_once_with(
            "GET", "/api/projects/proj/branches/main/clusters"
        )
        assert result == clusters


# ---------------------------------------------------------------------------
# 5. Job methods
# ---------------------------------------------------------------------------

class TestJobMethods:
    def setup_method(self):
        self.client = RavMemClient(base_url="http://localhost:7432")

    def _patch_request(self, json_data=None):
        resp = _make_response(json_data=json_data or {})
        return patch.object(self.client._client, "request", return_value=resp)

    def test_get_job(self):
        with self._patch_request({"id": 42, "status": "done"}) as mock_req:
            result = self.client.get_job(42)
        mock_req.assert_called_once_with("GET", "/api/jobs/42")
        assert result == {"id": 42, "status": "done"}

    def test_poll_job_returns_immediately_when_done(self):
        done_resp = _make_response(json_data={"id": 42, "status": "done"})
        with patch.object(self.client._client, "request", return_value=done_resp):
            with patch("time.sleep") as mock_sleep:
                result = self.client.poll_job(42, interval=0.01, timeout=5.0)
        assert result == {"id": 42, "status": "done"}
        mock_sleep.assert_not_called()

    def test_poll_job_raises_timeout_when_elapsed(self):
        running_resp = _make_response(json_data={"id": 42, "status": "running"})
        with patch.object(self.client._client, "request", return_value=running_resp):
            with patch("time.sleep"):
                # Use a very short timeout and freeze monotonic time so the
                # deadline is already past on the first check after get_job.
                t0 = time.monotonic()
                with patch("time.monotonic", side_effect=[t0, t0 + 1.0, t0 + 1.0]):
                    with pytest.raises(TimeoutError, match="Job 42"):
                        self.client.poll_job(42, interval=0.01, timeout=0.5)

    def test_poll_job_keeps_polling_until_done(self):
        responses = [
            _make_response(json_data={"id": 42, "status": "running"}),
            _make_response(json_data={"id": 42, "status": "running"}),
            _make_response(json_data={"id": 42, "status": "done"}),
        ]
        with patch.object(
            self.client._client, "request", side_effect=responses
        ) as mock_req:
            with patch("time.sleep"):
                result = self.client.poll_job(42, interval=0.01, timeout=60.0)
        assert result == {"id": 42, "status": "done"}
        assert mock_req.call_count == 3


# ---------------------------------------------------------------------------
# 6. Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_request_raises_on_4xx(self):
        client = RavMemClient(base_url="http://localhost:7432")
        error_resp = _make_response(status_code=404, raise_error=True)
        with patch.object(client._client, "request", return_value=error_resp):
            with pytest.raises(httpx.HTTPStatusError):
                client._request("GET", "/api/projects/nonexistent")

    def test_request_raises_on_5xx(self):
        client = RavMemClient(base_url="http://localhost:7432")
        error_resp = _make_response(status_code=500, raise_error=True)
        with patch.object(client._client, "request", return_value=error_resp):
            with pytest.raises(httpx.HTTPStatusError):
                client._request("GET", "/api/projects")


# ---------------------------------------------------------------------------
# 7. Context manager
# ---------------------------------------------------------------------------

class TestContextManager:
    def test_close_called_on_exit(self):
        client = RavMemClient(base_url="http://localhost:7432")
        with patch.object(client, "close") as mock_close:
            with client:
                pass
        mock_close.assert_called_once()

    def test_close_called_on_exception(self):
        client = RavMemClient(base_url="http://localhost:7432")
        with patch.object(client, "close") as mock_close:
            with pytest.raises(ValueError):
                with client:
                    raise ValueError("oops")
        mock_close.assert_called_once()


# ---------------------------------------------------------------------------
# 8. load_config / save_config / get_client_from_config
# ---------------------------------------------------------------------------

class TestConfig:
    def test_load_config_returns_defaults_when_file_missing(self, tmp_path):
        fake_config_path = tmp_path / "nonexistent" / "client.json"
        with patch("ravmem.client.config.CONFIG_PATH", fake_config_path):
            from ravmem.client.config import load_config
            cfg = load_config()
        assert cfg["server_url"] == ""
        assert cfg["api_key"] == ""
        assert cfg["default_project"] == ""
        assert cfg["default_branch"] == ""

    def test_save_and_reload_config(self, tmp_path):
        fake_config_path = tmp_path / "ravmem" / "client.json"
        with patch("ravmem.client.config.CONFIG_PATH", fake_config_path):
            from ravmem.client.config import load_config, save_config
            data = {
                "server_url": "http://myserver:7432",
                "api_key": "tok123",
                "default_project": "myproj",
                "default_branch": "dev",
            }
            save_config(data)
            assert fake_config_path.exists()
            reloaded = load_config()
        assert reloaded["server_url"] == "http://myserver:7432"
        assert reloaded["api_key"] == "tok123"
        assert reloaded["default_project"] == "myproj"
        assert reloaded["default_branch"] == "dev"

    def test_save_config_creates_parent_dirs(self, tmp_path):
        deep_path = tmp_path / "a" / "b" / "c" / "client.json"
        with patch("ravmem.client.config.CONFIG_PATH", deep_path):
            from ravmem.client.config import save_config
            save_config({"server_url": "http://x", "api_key": ""})
        assert deep_path.exists()

    def test_get_client_from_config_returns_none_when_no_url(self, tmp_path):
        fake_config_path = tmp_path / "client.json"
        # Write config with empty server_url
        fake_config_path.write_text(
            json.dumps({"server_url": "", "api_key": ""}), encoding="utf-8"
        )
        with patch("ravmem.client.config.CONFIG_PATH", fake_config_path):
            from ravmem.client.config import get_client_from_config
            result = get_client_from_config()
        assert result is None

    def test_get_client_from_config_returns_client_when_url_set(self, tmp_path):
        fake_config_path = tmp_path / "client.json"
        fake_config_path.write_text(
            json.dumps(
                {"server_url": "http://localhost:7432", "api_key": "mykey"}
            ),
            encoding="utf-8",
        )
        with patch("ravmem.client.config.CONFIG_PATH", fake_config_path):
            from ravmem.client.config import get_client_from_config
            client = get_client_from_config()
        assert client is not None
        assert isinstance(client, RavMemClient)
        client.close()

    def test_load_config_merges_missing_keys(self, tmp_path):
        """Partial config on disk is merged with defaults for missing keys."""
        fake_config_path = tmp_path / "client.json"
        # Only save server_url; other keys should come from defaults
        fake_config_path.write_text(
            json.dumps({"server_url": "http://x:7432"}), encoding="utf-8"
        )
        with patch("ravmem.client.config.CONFIG_PATH", fake_config_path):
            from ravmem.client.config import load_config
            cfg = load_config()
        assert cfg["server_url"] == "http://x:7432"
        assert cfg["api_key"] == ""
        assert cfg["default_project"] == ""
        assert cfg["default_branch"] == ""
