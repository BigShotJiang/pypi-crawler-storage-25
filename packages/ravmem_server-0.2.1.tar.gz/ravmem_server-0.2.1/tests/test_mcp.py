"""Tests for the MCP endpoint — tool dispatch and response format."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import numpy as np
import pytest
from fastapi.testclient import TestClient

from ravmem.storage.schema import Cluster, Edge, Symbol


@pytest.fixture
def app_with_repo(tmp_path):
    """Create a minimal indexed repo and return a TestClient."""
    from ravmem.server.app import create_app, get_repo_engines, _engines
    from ravmem.storage.meta import MetaStore
    from ravmem.storage.vectors import VectorStore
    from ravmem.engine.search import SearchEngine
    from ravmem.engine.impact import ImpactEngine
    from ravmem.engine.context import ContextEngine
    from ravmem.config import VECTORS_SUBDIR, META_DB_NAME, INDEX_DIR, BM25_INDEX_NAME
    from tests.fake_graph_store import FakeGraphStore

    repo_path = tmp_path / "myrepo"
    repo_path.mkdir()
    index_dir = repo_path / INDEX_DIR
    index_dir.mkdir()

    # Storage
    gs = FakeGraphStore()
    sym = Symbol(id="f1", name="my_func", kind="function",
                 file=str(repo_path / "main.py"), line_start=1, line_end=5,
                 lang="python", cluster_id="c1")
    cluster = Cluster(id="c1", label="core", cohesion_score=0.9, size=1)
    gs.upsert_symbol(sym)
    gs.upsert_cluster(cluster)
    gs.upsert_edge(Edge(src_id="f1", dst_id="c1", kind="belongs_to"))

    vs = VectorStore(index_dir / VECTORS_SUBDIR, dim=8)
    vs.initialize()
    vs.add_symbols(["f1"], np.random.rand(1, 8).astype(np.float32))
    vs.save()

    bm25_path = index_dir / BM25_INDEX_NAME
    bm25_path.write_text(json.dumps([
        {"id": "f1", "text": "function my_func", "name": "my_func",
         "file": str(repo_path / "main.py"), "kind": "function"}
    ]))

    ms = MetaStore(index_dir / META_DB_NAME)

    # Pre-populate the engine registry
    from ravmem.server.app import RepoEngines
    _engines[str(repo_path)] = RepoEngines.__new__(RepoEngines)
    eng = _engines[str(repo_path)]
    eng.repo_path = repo_path
    eng.graph = gs
    eng.vectors = vs
    eng.meta = ms
    eng.search_engine = SearchEngine(vs, bm25_path=bm25_path)
    eng.impact_engine = ImpactEngine(gs)
    eng.context_engine = ContextEngine(gs, eng.search_engine, eng.impact_engine)

    app = create_app(repos_dir=tmp_path)
    return TestClient(app), str(repo_path)


class TestMCPEndpoint:
    def test_get_tools(self, app_with_repo):
        client, _ = app_with_repo
        resp = client.get("/mcp")
        assert resp.status_code == 200
        data = resp.json()
        tool_names = [t["name"] for t in data["tools"]]
        assert "search_symbols" in tool_names
        assert "get_impact" in tool_names
        assert "get_symbol" in tool_names

    def test_tools_use_input_schema(self, app_with_repo):
        """MCP spec requires inputSchema not parameters."""
        client, _ = app_with_repo
        resp = client.get("/mcp")
        assert resp.status_code == 200
        data = resp.json()
        for tool in data["tools"]:
            assert "inputSchema" in tool, f"Tool {tool['name']} missing inputSchema"
            assert "parameters" not in tool, f"Tool {tool['name']} should not have parameters key"

    def test_search_symbols_tool(self, app_with_repo):
        client, repo_path = app_with_repo
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "search_symbols", "parameters": {"query": "my_func", "repo": repo_path}}
            ]
        })
        assert resp.status_code == 200
        results = resp.json()["results"]
        assert results[0]["isError"] is False

    def test_search_symbols_enriched_fields(self, app_with_repo):
        """search_symbols response items should include summary and relevance_reason."""
        client, repo_path = app_with_repo
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "search_symbols", "parameters": {"query": "my_func", "repo": repo_path}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        items = json.loads(result["content"][0]["text"])
        assert len(items) > 0
        item = items[0]
        assert "summary" in item, "search_symbols result missing 'summary'"
        assert "relevance_reason" in item, "search_symbols result missing 'relevance_reason'"
        assert "my_func" in item["relevance_reason"]

    def test_get_impact_enriched_fields(self, app_with_repo):
        """get_impact response should include usage_hint and total_affected_count."""
        client, repo_path = app_with_repo
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "get_impact", "parameters": {"symbol_id": "f1", "repo": repo_path}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        data = json.loads(result["content"][0]["text"])
        assert "usage_hint" in data, "get_impact result missing 'usage_hint'"
        assert "total_affected_count" in data, "get_impact result missing 'total_affected_count'"

    def test_get_symbol_tool(self, app_with_repo):
        client, repo_path = app_with_repo
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "get_symbol", "parameters": {"symbol_id": "f1", "repo": repo_path}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        data = json.loads(result["content"][0]["text"])
        assert data["symbol"]["name"] == "my_func"
        assert "docstring" in data["symbol"], "get_symbol result missing 'docstring' field"

    def test_get_symbol_has_incoming_outgoing(self, app_with_repo):
        """get_symbol response should have incoming/outgoing in addition to callers/callees."""
        client, repo_path = app_with_repo
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "get_symbol", "parameters": {"symbol_id": "f1", "repo": repo_path}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        data = json.loads(result["content"][0]["text"])
        # Backward compatible keys still present
        assert "callers" in data
        assert "callees" in data
        # New categorized keys
        assert "incoming" in data
        assert "outgoing" in data
        assert "calls" in data["incoming"]
        assert "calls" in data["outgoing"]

    def test_unknown_tool_returns_error(self, app_with_repo):
        client, repo_path = app_with_repo
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "nonexistent_tool", "parameters": {"repo": repo_path}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is True

    def test_health_endpoint(self, app_with_repo):
        client, _ = app_with_repo
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"

    def test_list_repos_tool(self, app_with_repo):
        """list_repos should return repos registered in MetaStore."""
        from ravmem.storage.meta import MetaStore
        from ravmem.config import INDEX_DIR, META_DB_NAME
        client, repo_path = app_with_repo
        # Register the repo in the MetaStore so list_repos() returns it
        ms = MetaStore(Path(repo_path) / INDEX_DIR / META_DB_NAME)
        ms.register_repo("myrepo", "myrepo", repo_path, ["python"])
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "list_repos", "parameters": {}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        repos = json.loads(result["content"][0]["text"])
        assert isinstance(repos, list)
        # The myrepo should appear via MetaStore
        repo_names = [r["name"] for r in repos]
        assert "myrepo" in repo_names

    def test_suggest_entry_points_tool_no_centrality(self, app_with_repo):
        """suggest_entry_points returns hint when no centrality data."""
        client, repo_path = app_with_repo
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "suggest_entry_points", "parameters": {"repo": repo_path, "limit": 5}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        data = json.loads(result["content"][0]["text"])
        # No centrality data was seeded, so we expect empty entry_points with hint
        assert "entry_points" in data
        assert isinstance(data["entry_points"], list)

    def test_suggest_entry_points_tool_with_centrality(self, app_with_repo):
        """suggest_entry_points returns symbols when centrality data exists."""
        client, repo_path = app_with_repo
        from ravmem.server.app import _engines
        # Seed centrality data
        eng = _engines[repo_path]
        eng.meta.save_centrality("myrepo", {"f1": 0.75})
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "suggest_entry_points", "parameters": {"repo": repo_path, "limit": 5}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        data = json.loads(result["content"][0]["text"])
        assert "entry_points" in data
        assert len(data["entry_points"]) > 0
        assert data["entry_points"][0]["id"] == "f1"
        assert "centrality_score" in data["entry_points"][0]

    def test_diff_impact_truncation_fields(self, app_with_repo):
        """diff_impact response must include results, deleted_or_unresolved_symbols, and usage_hint."""
        client, repo_path = app_with_repo
        # A minimal unified diff that mentions my_func (which is in the graph)
        diff_text = (
            "--- a/main.py\n"
            "+++ b/main.py\n"
            "@@ -1,5 +1,5 @@\n"
            "-def my_func():\n"
            "+def my_func(x):\n"
            "     pass\n"
        )
        resp = client.post("/mcp", json={
            "tool_calls": [
                {"name": "diff_impact", "parameters": {"diff": diff_text, "repo": repo_path}}
            ]
        })
        assert resp.status_code == 200
        result = resp.json()["results"][0]
        assert result["isError"] is False
        data = json.loads(result["content"][0]["text"])
        assert "results" in data, "diff_impact response missing 'results' key"
        assert "deleted_or_unresolved_symbols" in data, (
            "diff_impact response missing 'deleted_or_unresolved_symbols' key"
        )
        assert "usage_hint" in data, "diff_impact response missing 'usage_hint' key"
        assert isinstance(data["results"], list)
        assert isinstance(data["deleted_or_unresolved_symbols"], list)
        # Each result entry must have truncated and total_affected_count fields
        for entry in data["results"]:
            assert "truncated" in entry, "diff_impact result entry missing 'truncated'"
            assert "total_affected_count" in entry, (
                "diff_impact result entry missing 'total_affected_count'"
            )
