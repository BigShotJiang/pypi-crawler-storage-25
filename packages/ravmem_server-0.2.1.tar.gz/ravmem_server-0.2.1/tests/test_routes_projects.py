"""Tests for project/branch management API endpoints."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Generator
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def app():
    """Create a test FastAPI app with mocked state."""
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    from ravmem.server.routes_api import router

    test_app = FastAPI()
    test_app.include_router(router, prefix="/api")
    test_app.state.repos_dir = None
    return test_app


@pytest.fixture
def registry():
    """An in-memory ServerRegistry backed by a temp SQLite DB."""
    with tempfile.TemporaryDirectory() as tmp:
        from ravmem.server.registry import ServerRegistry
        reg = ServerRegistry(Path(tmp) / "server.db")
        try:
            yield reg
        finally:
            # Close the SQLite connection before the temp dir is deleted.
            # On Windows the open file handle would cause PermissionError (WinError 32).
            reg.close()


@pytest.fixture
def data_dir():
    with tempfile.TemporaryDirectory() as tmp:
        yield Path(tmp)


@pytest.fixture
def branch_manager(data_dir, registry):
    from ravmem.server.branch_manager import BranchManager
    return BranchManager(data_dir, registry)


@pytest.fixture
def client(app, registry, branch_manager, data_dir):
    """TestClient with real registry/branch_manager wired into app state."""
    app.state.registry = registry
    app.state.branch_manager = branch_manager
    app.state.data_dir = data_dir
    return TestClient(app)


# ---------------------------------------------------------------------------
# Project CRUD
# ---------------------------------------------------------------------------

class TestProjectEndpoints:
    def test_list_projects_empty(self, client):
        resp = client.get("/api/projects")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_create_project_local_path(self, client, data_dir, tmp_path):
        resp = client.post("/api/projects", json={
            "repo_path": str(tmp_path),
            "name": "test-repo",
            "default_branch": "main",
        })
        assert resp.status_code == 201
        body = resp.json()
        assert body["id"] == "test-repo"
        assert body["name"] == "test-repo"

    def test_create_project_requires_url_or_path(self, client):
        # Pydantic model_validator raises ValueError → FastAPI returns 422
        resp = client.post("/api/projects", json={"name": "test"})
        assert resp.status_code == 422

    def test_get_project(self, client, tmp_path):
        client.post("/api/projects", json={
            "repo_path": str(tmp_path), "name": "myrepo",
        })
        resp = client.get("/api/projects/myrepo")
        assert resp.status_code == 200
        body = resp.json()
        assert body["id"] == "myrepo"
        assert "indexed_branches" in body

    def test_get_project_not_found(self, client):
        resp = client.get("/api/projects/doesnotexist")
        assert resp.status_code == 404

    def test_list_projects_after_create(self, client, tmp_path):
        client.post("/api/projects", json={
            "repo_path": str(tmp_path), "name": "proj-a",
        })
        resp = client.get("/api/projects")
        assert resp.status_code == 200
        assert len(resp.json()) == 1

    def test_delete_project(self, client, tmp_path):
        client.post("/api/projects", json={
            "repo_path": str(tmp_path), "name": "to-delete",
        })
        resp = client.delete("/api/projects/to-delete")
        assert resp.status_code == 200
        assert resp.json()["deleted"] is True
        # Project should be gone
        assert client.get("/api/projects/to-delete").status_code == 404


# ---------------------------------------------------------------------------
# Branch management
# ---------------------------------------------------------------------------

class TestBranchEndpoints:
    @pytest.fixture(autouse=True)
    def setup_project(self, client, registry, tmp_path):
        """Create a project to work with."""
        client.post("/api/projects", json={
            "repo_path": str(tmp_path), "name": "myproject",
        })

    def test_list_branches_empty(self, client):
        resp = client.get("/api/projects/myproject/branches")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_branch_status_not_found(self, client):
        resp = client.get("/api/projects/myproject/branches/main/status")
        assert resp.status_code == 404

    def test_delete_branch_index_not_found(self, client):
        resp = client.delete("/api/projects/myproject/branches/main/index")
        # Should 404 if branch was never indexed
        assert resp.status_code in (200, 404)

    def test_index_branch_triggers_job(self, client):
        with patch(
            "ravmem.server.branch_manager.BranchManager.index_branch",
            new=AsyncMock(return_value=42),
        ):
            resp = client.post(
                "/api/projects/myproject/branches/main/index",
                json={"mode": "full"},
            )
        assert resp.status_code == 202
        assert resp.json()["job_id"] == 42

    def test_index_branch_unknown_project(self, client):
        with patch(
            "ravmem.server.branch_manager.BranchManager.index_branch",
            new=AsyncMock(side_effect=ValueError("Unknown project")),
        ):
            resp = client.post(
                "/api/projects/nosuchproject/branches/main/index",
                json={"mode": "auto"},
            )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Job endpoint
# ---------------------------------------------------------------------------

class TestJobEndpoints:
    def test_get_job_not_found(self, client):
        resp = client.get("/api/jobs/99999")
        assert resp.status_code == 404

    def test_get_job_found(self, client, registry, tmp_path):
        # Register a project and create a job directly
        registry.create_project("p1", "proj", str(tmp_path))
        job_id = registry.create_job("p1", "main", "full")
        resp = client.get(f"/api/jobs/{job_id}")
        assert resp.status_code == 200
        body = resp.json()
        assert body["id"] == job_id
        assert body["status"] == "queued"
