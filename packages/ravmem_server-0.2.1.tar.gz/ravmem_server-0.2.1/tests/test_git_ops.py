"""Unit tests for ravmem.server.git_ops using real temporary git repos."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from ravmem.server.git_ops import (
    GitError,
    checkout_branch,
    diff_name_status,
    get_branches,
    get_current_branch,
    get_head_commit,
    get_merge_base,
    is_ancestor,
    is_git_repo,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _git(args: list[str], cwd: Path) -> None:
    """Run a git command, raising on failure."""
    subprocess.run(["git"] + args, cwd=str(cwd), check=True, capture_output=True)


def _git_init(path: Path) -> None:
    """Initialise a git repo with a default branch named 'main'."""
    path.mkdir(parents=True, exist_ok=True)
    _git(["init", "-b", "main"], path)
    _git(["config", "user.email", "test@example.com"], path)
    _git(["config", "user.name", "Test User"], path)


def _git_commit(path: Path, filename: str, content: str, message: str = "commit") -> str:
    """Write *filename* with *content*, stage it, commit, and return the hash."""
    (path / filename).write_text(content)
    _git(["add", filename], path)
    _git(["commit", "-m", message], path)
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=str(path), capture_output=True, text=True, check=True,
    )
    return result.stdout.strip()


# ---------------------------------------------------------------------------
# Tests: is_git_repo
# ---------------------------------------------------------------------------

class TestIsGitRepo:
    def test_true_for_git_repo(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        assert is_git_repo(tmp_path) is True

    def test_false_for_plain_dir(self, tmp_path: Path) -> None:
        plain = tmp_path / "plain"
        plain.mkdir()
        assert is_git_repo(plain) is False

    def test_true_for_subdirectory_of_repo(self, tmp_path: Path) -> None:
        """Subdirectories of a git repo are also inside the repo."""
        _git_init(tmp_path)
        subdir = tmp_path / "src"
        subdir.mkdir()
        assert is_git_repo(subdir) is True


# ---------------------------------------------------------------------------
# Tests: get_branches
# ---------------------------------------------------------------------------

class TestGetBranches:
    def test_returns_branch_names_after_commit(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        branches = get_branches(tmp_path)
        assert "main" in branches

    def test_multiple_branches(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        _git(["branch", "feature"], tmp_path)
        branches = get_branches(tmp_path)
        assert set(branches) >= {"main", "feature"}

    def test_empty_repo_returns_empty(self, tmp_path: Path) -> None:
        """A fresh repo with no commits has no branches."""
        _git_init(tmp_path)
        branches = get_branches(tmp_path)
        assert branches == []


# ---------------------------------------------------------------------------
# Tests: get_head_commit
# ---------------------------------------------------------------------------

class TestGetHeadCommit:
    def test_returns_40_char_hex(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        sha = get_head_commit(tmp_path)
        assert len(sha) == 40
        assert all(c in "0123456789abcdef" for c in sha)

    def test_matches_actual_head(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        expected = _git_commit(tmp_path, "a.txt", "hello")
        assert get_head_commit(tmp_path) == expected

    def test_specific_branch(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        base_sha = _git_commit(tmp_path, "a.txt", "base")
        _git(["branch", "stable"], tmp_path)
        # Add another commit on main — stable should still point at base_sha
        _git_commit(tmp_path, "b.txt", "extra")
        assert get_head_commit(tmp_path, branch="stable") == base_sha


# ---------------------------------------------------------------------------
# Tests: get_current_branch
# ---------------------------------------------------------------------------

class TestGetCurrentBranch:
    def test_returns_branch_name(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        assert get_current_branch(tmp_path) == "main"

    def test_reflects_checkout(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        _git(["branch", "dev"], tmp_path)
        _git(["checkout", "dev"], tmp_path)
        assert get_current_branch(tmp_path) == "dev"


# ---------------------------------------------------------------------------
# Tests: get_merge_base
# ---------------------------------------------------------------------------

class TestGetMergeBase:
    def test_common_ancestor(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        base_sha = _git_commit(tmp_path, "a.txt", "base")

        # Create feature branch from base
        _git(["branch", "feature"], tmp_path)

        # Advance main
        _git_commit(tmp_path, "b.txt", "main extra")

        # Advance feature
        _git(["checkout", "feature"], tmp_path)
        _git_commit(tmp_path, "c.txt", "feature extra")

        merge_base = get_merge_base(tmp_path, "main", "feature")
        assert merge_base == base_sha

    def test_same_commit_is_own_merge_base(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        sha = _git_commit(tmp_path, "a.txt", "base")
        assert get_merge_base(tmp_path, sha, sha) == sha


# ---------------------------------------------------------------------------
# Tests: is_ancestor
# ---------------------------------------------------------------------------

class TestIsAncestor:
    def _setup_linear(self, tmp_path: Path) -> tuple[str, str]:
        """Return (first_sha, second_sha) for a two-commit linear history."""
        _git_init(tmp_path)
        first = _git_commit(tmp_path, "a.txt", "first")
        second = _git_commit(tmp_path, "b.txt", "second")
        return first, second

    def test_true_when_ancestor(self, tmp_path: Path) -> None:
        first, second = self._setup_linear(tmp_path)
        assert is_ancestor(tmp_path, first, second) is True

    def test_false_when_not_ancestor(self, tmp_path: Path) -> None:
        first, second = self._setup_linear(tmp_path)
        # second is NOT an ancestor of first
        assert is_ancestor(tmp_path, second, first) is False

    def test_commit_is_ancestor_of_itself(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        sha = _git_commit(tmp_path, "a.txt", "only")
        assert is_ancestor(tmp_path, sha, sha) is True

    def test_diverged_branches_not_ancestors(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "base")
        _git(["branch", "feature"], tmp_path)
        main_sha = _git_commit(tmp_path, "b.txt", "main only")
        _git(["checkout", "feature"], tmp_path)
        feature_sha = _git_commit(tmp_path, "c.txt", "feature only")

        assert is_ancestor(tmp_path, main_sha, feature_sha) is False
        assert is_ancestor(tmp_path, feature_sha, main_sha) is False


# ---------------------------------------------------------------------------
# Tests: diff_name_status
# ---------------------------------------------------------------------------

class TestDiffNameStatus:
    def test_added_file(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        base_sha = _git_commit(tmp_path, "a.txt", "hello")
        _git_commit(tmp_path, "b.txt", "new file")
        modified, deleted = diff_name_status(tmp_path, base_sha)
        assert str(tmp_path / "b.txt") in modified
        assert deleted == set()

    def test_modified_file(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        base_sha = _git_commit(tmp_path, "a.txt", "original")
        _git_commit(tmp_path, "a.txt", "changed")
        modified, deleted = diff_name_status(tmp_path, base_sha)
        assert str(tmp_path / "a.txt") in modified
        assert deleted == set()

    def test_deleted_file(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        base_sha = _git_commit(tmp_path, "a.txt", "will be deleted")
        (tmp_path / "a.txt").unlink()
        _git(["rm", "a.txt"], tmp_path)
        _git(["commit", "-m", "delete a.txt"], tmp_path)
        modified, deleted = diff_name_status(tmp_path, base_sha)
        assert str(tmp_path / "a.txt") in deleted
        assert modified == set()

    def test_no_changes(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        sha = _git_commit(tmp_path, "a.txt", "hello")
        modified, deleted = diff_name_status(tmp_path, sha, sha)
        assert modified == set()
        assert deleted == set()

    def test_multiple_files(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        base_sha = _git_commit(tmp_path, "keep.txt", "keep")
        _git_commit(tmp_path, "added.txt", "new")
        _git_commit(tmp_path, "keep.txt", "modified keep")

        modified, deleted = diff_name_status(tmp_path, base_sha)
        assert str(tmp_path / "added.txt") in modified
        assert str(tmp_path / "keep.txt") in modified


# ---------------------------------------------------------------------------
# Tests: checkout_branch
# ---------------------------------------------------------------------------

class TestCheckoutBranch:
    def test_switches_to_existing_branch(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        _git(["branch", "dev"], tmp_path)
        assert get_current_branch(tmp_path) == "main"

        checkout_branch(tmp_path, "dev")
        assert get_current_branch(tmp_path) == "dev"

    def test_switch_back_to_main(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        _git(["branch", "dev"], tmp_path)
        _git(["checkout", "dev"], tmp_path)
        assert get_current_branch(tmp_path) == "dev"

        checkout_branch(tmp_path, "main")
        assert get_current_branch(tmp_path) == "main"

    def test_raises_on_nonexistent_branch(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        with pytest.raises(GitError):
            checkout_branch(tmp_path, "nonexistent-branch-xyz")


# ---------------------------------------------------------------------------
# Tests: GitError
# ---------------------------------------------------------------------------

class TestGitError:
    def test_is_exception_subclass(self) -> None:
        assert issubclass(GitError, Exception)

    def test_raised_on_bad_path(self, tmp_path: Path) -> None:
        """get_head_commit on a non-repo path should raise GitError."""
        plain = tmp_path / "notarepo"
        plain.mkdir()
        with pytest.raises(GitError):
            get_head_commit(plain)

    def test_raised_for_bad_ref(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        with pytest.raises(GitError):
            get_head_commit(tmp_path, branch="does-not-exist")

    def test_raised_for_bad_merge_base(self, tmp_path: Path) -> None:
        _git_init(tmp_path)
        _git_commit(tmp_path, "a.txt", "hello")
        with pytest.raises(GitError):
            get_merge_base(tmp_path, "HEAD", "nonexistent-ref")
