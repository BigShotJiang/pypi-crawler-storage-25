"""Tests for the context engine — search RRF, impact traversal, context assembly."""

import json
import tempfile
from pathlib import Path

import numpy as np
import pytest

from ravmem.storage.schema import Edge, ImpactResult, Symbol


# ---------------------------------------------------------------------------
# SearchEngine — RRF ranking
# ---------------------------------------------------------------------------

class TestSearchEngine:
    def _make_engine(self, tmp_path):
        from ravmem.engine.search import SearchEngine
        from ravmem.storage.vectors import VectorStore

        # Build a small BM25 corpus
        corpus = [
            {"id": "s1", "text": "function authenticate user login", "name": "authenticate", "file": "/auth.py", "kind": "function"},
            {"id": "s2", "text": "function register user signup", "name": "register", "file": "/auth.py", "kind": "function"},
            {"id": "s3", "text": "class UserService user management", "name": "UserService", "file": "/service.py", "kind": "class"},
        ]
        bm25_path = tmp_path / "bm25.json"
        bm25_path.write_text(json.dumps(corpus))

        vs = VectorStore(tmp_path / "vectors", dim=8)
        vs.initialize()
        embs = np.random.rand(3, 8).astype(np.float32)
        vs.add_symbols(["s1", "s2", "s3"], embs)

        return SearchEngine(vs, bm25_path=bm25_path)

    def test_search_returns_results(self, tmp_path):
        engine = self._make_engine(tmp_path)
        results = engine.search("authenticate", k=3)
        assert len(results) > 0

    def test_best_bm25_match_ranks_high(self, tmp_path):
        engine = self._make_engine(tmp_path)
        results = engine.search("authenticate", k=3)
        # "authenticate" should appear in top results
        names = [r.symbol.name for r in results]
        assert "authenticate" in names[:2]

    def test_low_confidence_small_corpus(self, tmp_path):
        """Corpus with fewer than 3 symbols should mark all results low_confidence."""
        from ravmem.engine.search import SearchEngine
        from ravmem.storage.vectors import VectorStore

        corpus = [
            {"id": "s1", "text": "function authenticate user", "name": "authenticate",
             "file": "/auth.py", "kind": "function"},
        ]
        bm25_path = tmp_path / "bm25.json"
        bm25_path.write_text(json.dumps(corpus))

        vs = VectorStore(tmp_path / "vectors", dim=8)
        vs.initialize()
        vs.add_symbols(["s1"], np.random.rand(1, 8).astype(np.float32))

        engine = SearchEngine(vs, bm25_path=bm25_path)
        results = engine.search("authenticate", k=5)
        assert len(results) > 0
        assert all(r.low_confidence for r in results)

    def test_normal_corpus_not_low_confidence(self, tmp_path):
        """Normal corpus with matching query should NOT be marked low_confidence."""
        engine = self._make_engine(tmp_path)
        results = engine.search("authenticate", k=3)
        # With 3 symbols and a good match, top result score should be above threshold
        # and corpus size >= 3, so low_confidence should be False for strong matches
        assert len(results) > 0
        # At least some results should not be low_confidence when corpus is normal-sized
        assert not all(r.low_confidence for r in results)


# ---------------------------------------------------------------------------
# ImpactEngine
# ---------------------------------------------------------------------------

class TestImpactEngine:
    def _make_graph(self, tmp_path):
        from tests.fake_graph_store import FakeGraphStore as GraphStore

        gs = GraphStore()
        gs.initialize_schema()

        syms = [
            Symbol(id="root", name="root_fn", kind="function",
                   file="/f.py", line_start=1, line_end=5, lang="python"),
            Symbol(id="dep1", name="dep1_fn", kind="function",
                   file="/f.py", line_start=10, line_end=15, lang="python"),
            Symbol(id="dep2", name="dep2_fn", kind="function",
                   file="/f.py", line_start=20, line_end=25, lang="python"),
        ]
        gs.upsert_symbols(syms)
        gs.upsert_edge(Edge(src_id="dep1", dst_id="root", kind="calls"))
        gs.upsert_edge(Edge(src_id="dep2", dst_id="dep1", kind="calls"))
        return gs

    def test_get_impact_finds_callers(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine

        graph = self._make_graph(tmp_path)
        engine = ImpactEngine(graph)
        result = engine.get_impact("root", depth=3)

        affected_ids = {n.symbol.id for n in result.affected}
        assert "dep1" in affected_ids

    def test_get_call_chain_callees(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine

        graph = self._make_graph(tmp_path)
        engine = ImpactEngine(graph)
        chain = engine.get_call_chain("dep2", direction="callees", depth=3)
        ids = [s.id for s in chain]
        assert "root" in ids or "dep1" in ids

    def test_diff_impact(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine

        graph = self._make_graph(tmp_path)
        engine = ImpactEngine(graph)

        diff = "+def root_fn():\n+    pass\n"
        results = engine.diff_impact(diff)
        assert isinstance(results, list)


# ---------------------------------------------------------------------------
# ContextEngine
# ---------------------------------------------------------------------------

class TestContextEngine:
    def test_assemble_symbol_context(self, tmp_path):
        import json
        from ravmem.engine.context import ContextEngine
        from ravmem.engine.impact import ImpactEngine
        from ravmem.engine.search import SearchEngine
        from tests.fake_graph_store import FakeGraphStore as GraphStore
        from ravmem.storage.schema import Cluster
        from ravmem.storage.vectors import VectorStore

        gs = GraphStore()
        gs.initialize_schema()
        sym = Symbol(id="t1", name="target", kind="function",
                     file="/f.py", line_start=1, line_end=5, lang="python",
                     cluster_id="c1")
        cluster = Cluster(id="c1", label="core", cohesion_score=0.5, size=1)
        gs.upsert_symbol(sym)
        gs.upsert_cluster(cluster)
        gs.upsert_edge(Edge(src_id="t1", dst_id="c1", kind="belongs_to"))

        bm25_path = tmp_path / "bm25.json"
        bm25_path.write_text(json.dumps([
            {"id": "t1", "text": "function target", "name": "target", "file": "/f.py", "kind": "function"}
        ]))
        vs = VectorStore(tmp_path / "vectors", dim=8)
        vs.initialize()
        vs.add_symbols(["t1"], np.random.rand(1, 8).astype(np.float32))

        search = SearchEngine(vs, bm25_path=bm25_path)
        impact = ImpactEngine(gs)
        ctx_engine = ContextEngine(gs, search, impact)

        ctx = ctx_engine.assemble_symbol_context("t1")
        assert ctx is not None
        assert ctx.symbol.name == "target"
        assert ctx.cluster is not None
        assert ctx.cluster.label == "core"


# ---------------------------------------------------------------------------
# ImpactEngine — bidirectional call chain (Fix 5)
# ---------------------------------------------------------------------------

class TestBidirectionalCallChain:
    def _make_graph(self, tmp_path):
        from tests.fake_graph_store import FakeGraphStore as GraphStore

        gs = GraphStore()
        gs.initialize_schema()
        syms = [
            Symbol(id="root", name="root_fn", kind="function",
                   file="/f.py", line_start=1, line_end=5, lang="python"),
            Symbol(id="child", name="child_fn", kind="function",
                   file="/f.py", line_start=10, line_end=15, lang="python"),
            Symbol(id="parent", name="parent_fn", kind="function",
                   file="/f.py", line_start=20, line_end=25, lang="python"),
        ]
        gs.upsert_symbols(syms)
        gs.upsert_edge(Edge(src_id="parent", dst_id="root", kind="calls"))
        gs.upsert_edge(Edge(src_id="root", dst_id="child", kind="calls"))
        return gs

    def test_direction_both_returns_dict(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine
        graph = self._make_graph(tmp_path)
        result = ImpactEngine(graph).get_call_chain("root", direction="both", depth=3)
        assert isinstance(result, dict)
        assert "callers" in result and "callees" in result

    def test_direction_both_callers_correct(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine
        graph = self._make_graph(tmp_path)
        result = ImpactEngine(graph).get_call_chain("root", direction="both", depth=3)
        assert "parent" in [s.id for s in result["callers"]]

    def test_direction_both_callees_correct(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine
        graph = self._make_graph(tmp_path)
        result = ImpactEngine(graph).get_call_chain("root", direction="both", depth=3)
        assert "child" in [s.id for s in result["callees"]]

    def test_direction_callees_still_returns_list(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine
        graph = self._make_graph(tmp_path)
        assert isinstance(ImpactEngine(graph).get_call_chain("root", direction="callees"), list)

    def test_direction_callers_still_returns_list(self, tmp_path):
        from ravmem.engine.impact import ImpactEngine
        graph = self._make_graph(tmp_path)
        assert isinstance(ImpactEngine(graph).get_call_chain("root", direction="callers"), list)


# ---------------------------------------------------------------------------
# GraphStore — path prefix queries (Fix 4)
# ---------------------------------------------------------------------------

class TestPathPrefixQuery:
    def _make_graph(self, tmp_path):
        from tests.fake_graph_store import FakeGraphStore as GraphStore
        gs = GraphStore()
        gs.initialize_schema()
        gs.upsert_symbols([
            Symbol(id="a1", name="fn_a", kind="function",
                   file="/repo/src/auth/login.py", line_start=1, line_end=5, lang="python"),
            Symbol(id="a2", name="fn_b", kind="function",
                   file="/repo/src/auth/logout.py", line_start=1, line_end=5, lang="python"),
            Symbol(id="b1", name="fn_c", kind="function",
                   file="/repo/src/utils/helper.py", line_start=1, line_end=5, lang="python"),
        ])
        return gs

    def test_prefix_returns_directory_symbols(self, tmp_path):
        graph = self._make_graph(tmp_path)
        ids = [s.id for s in graph.get_symbols_for_path_prefix("/repo/src/auth/")]
        assert "a1" in ids and "a2" in ids and "b1" not in ids

    def test_prefix_excludes_other_dirs(self, tmp_path):
        graph = self._make_graph(tmp_path)
        ids = [s.id for s in graph.get_symbols_for_path_prefix("/repo/src/utils/")]
        assert "b1" in ids and "a1" not in ids

    def test_prefix_empty_when_no_match(self, tmp_path):
        graph = self._make_graph(tmp_path)
        assert graph.get_symbols_for_path_prefix("/repo/src/nonexistent/") == []


# ---------------------------------------------------------------------------
# ArcadeGraphStore — path prefix (Fix 4, mock)
# ---------------------------------------------------------------------------

class TestArcadePathPrefixQuery:
    def _store(self, branch="main", parent=None):
        import threading
        from ravmem.storage.graph_arcade import ArcadeGraphStore
        s = object.__new__(ArcadeGraphStore)
        s._branch = branch
        s._parent_branch = parent
        s._project_id = "test"
        s._local = threading.local()
        s._db = None
        return s

    def test_uses_like_sql(self):
        store = self._store()
        captured = []
        sym_row = {
            "id": "x1", "name": "fn", "kind": "function",
            "file": "/repo/src/auth/login.py", "line_start": 1, "line_end": 5,
            "lang": "python", "cluster_id": "", "embedding_id": -1, "docstring": "",
        }
        store._q = lambda sql: (captured.append(sql), [sym_row])[1]
        results = store.get_symbols_for_path_prefix("/repo/src/auth/")
        assert len(results) == 1 and results[0].id == "x1"
        assert any("LIKE" in sql and "/repo/src/auth/%" in sql for sql in captured)

    def test_parent_fallback_on_empty(self):
        store = self._store(branch="feature", parent="main")
        parent_row = {
            "id": "p1", "name": "base_fn", "kind": "function",
            "file": "/repo/src/auth/base.py", "line_start": 1, "line_end": 5,
            "lang": "python", "cluster_id": "", "embedding_id": -1, "docstring": "",
        }
        store._q = lambda sql: [] if "branch='feature'" in sql else [parent_row]
        results = store.get_symbols_for_path_prefix("/repo/src/auth/")
        assert len(results) == 1 and results[0].id == "p1"

    def test_project_id_included_in_sql(self):
        """All queries must include project_id to prevent cross-project data leakage."""
        store = self._store()
        captured = []
        sym_row = {
            "id": "x1", "name": "fn", "kind": "function",
            "file": "/repo/src/auth/login.py", "line_start": 1, "line_end": 5,
            "lang": "python", "cluster_id": "", "embedding_id": -1, "docstring": "",
        }
        store._q = lambda sql: (captured.append(sql), [sym_row])[1]
        store.get_symbols_for_path_prefix("/repo/src/auth/")
        assert any("project_id=" in sql for sql in captured), (
            "project_id filter missing from get_symbols_for_path_prefix SQL"
        )

    def test_get_all_symbols_scoped_to_project(self):
        """get_all_symbols SQL must include project_id filter."""
        store = self._store()
        captured = []
        store._q = lambda sql: (captured.append(sql), [])[1]
        store.get_all_symbols()
        assert any("project_id=" in sql for sql in captured), (
            "project_id filter missing from get_all_symbols SQL"
        )


# ---------------------------------------------------------------------------
# ArcadeGraphStore — thread-local transaction isolation (Fix 3)
# ---------------------------------------------------------------------------

class TestThreadLocalTransactions:
    def _store(self):
        import threading
        from ravmem.storage.graph_arcade import ArcadeGraphStore
        s = object.__new__(ArcadeGraphStore)
        s._branch = "main"
        s._parent_branch = None
        s._project_id = "test"
        s._local = threading.local()
        s._db = None
        return s

    def test_transactions_are_per_thread(self):
        import threading
        store = self._store()

        class FakeDb:
            def begin_transaction(self):
                return threading.current_thread().name
            def commit_transaction(self, sid):
                pass

        store._db = FakeDb()
        results = {}
        barrier = threading.Barrier(2)

        def run(name):
            barrier.wait()
            sid = store.begin_transaction()
            results[name] = (sid, store._active_tx)

        t1 = threading.Thread(target=run, args=("t1",), name="t1")
        t2 = threading.Thread(target=run, args=("t2",), name="t2")
        t1.start(); t2.start()
        t1.join(); t2.join()

        assert results["t1"][0] == "t1"
        assert results["t2"][0] == "t2"
        assert results["t1"][0] != results["t2"][0]

    def test_commit_only_clears_own_thread(self):
        import threading
        store = self._store()

        class FakeDb:
            def begin_transaction(self):
                return threading.current_thread().name
            def commit_transaction(self, sid):
                pass

        store._db = FakeDb()
        t1_after, t2_after = [None], [None]
        barrier = threading.Barrier(2)

        def t1_run():
            store.begin_transaction()
            barrier.wait()
            barrier.wait()
            t1_after[0] = store._active_tx

        def t2_run():
            sid = store.begin_transaction()
            barrier.wait()
            store.commit_transaction(sid)
            barrier.wait()
            t2_after[0] = store._active_tx

        t1 = threading.Thread(target=t1_run, name="t1")
        t2 = threading.Thread(target=t2_run, name="t2")
        t1.start(); t2.start()
        t1.join(); t2.join()

        assert t1_after[0] == "t1"
        assert t2_after[0] is None


# ---------------------------------------------------------------------------
# phase_cluster — stable IDs (Fix 2)
# ---------------------------------------------------------------------------

class TestStableClusterIds:
    def _syms(self):
        return [
            Symbol(id=f"s{i}", name=f"fn_{i}", kind="function",
                   file=f"/repo/f{i % 3}.py", line_start=i, line_end=i + 5, lang="python")
            for i in range(9)
        ]

    def _edges(self, syms):
        return [Edge(src_id=syms[i].id, dst_id=syms[i + 1].id, kind="calls")
                for i in range(len(syms) - 1)]

    def test_ids_have_known_prefix(self):
        """Cluster IDs use lc_ (Leiden), c_ (Louvain fallback), or fc_ (file-based)."""
        import ravmem.indexer.phase_cluster as pc
        from ravmem.indexer.phase_cluster import run
        clusters, _ = run(self._syms(), self._edges(self._syms()))
        valid_prefixes = ("lc_", "c_", "fc_")
        assert all(
            any(c.id.startswith(p) for p in valid_prefixes) for c in clusters
        ), f"Unexpected cluster ID prefixes: {[c.id for c in clusters]}"
        # When Leiden is available, all IDs should be lc_
        if pc._LEIDEN_AVAILABLE:
            assert all(c.id.startswith("lc_") for c in clusters)

    def test_ids_stable_across_runs(self):
        from ravmem.indexer.phase_cluster import run
        syms = self._syms()
        edges = self._edges(syms)
        ids_1 = {c.id for c in run(syms, edges)[0]}
        ids_2 = {c.id for c in run(self._syms(), self._edges(self._syms()))[0]}
        assert ids_1 == ids_2

    def test_file_based_fallback_stable(self):
        """_run_file_based (the fallback) produces stable IDs across two calls."""
        from ravmem.indexer.phase_cluster import _run_file_based
        syms = self._syms()
        clusters1, _ = _run_file_based(syms[:])
        clusters2, _ = _run_file_based(self._syms())
        assert {c.id for c in clusters1} == {c.id for c in clusters2}
