"""Unit tests for ArcadeGraphStore CoW (Copy-on-Write) branch semantics.

These tests validate the branch isolation logic entirely in Python — no real
ArcadeDB server is required. The DB layer (_q / _cmd) is replaced with
controlled stubs so that each test exercises exactly one CoW behaviour.

CoW semantics under test
------------------------
Read path:
  1. get_symbol / get_cluster try branch-local first → parent fallback.
  2. get_all_symbols / get_all_clusters deduplicate: branch-local wins.
  3. get_callers / get_callees resolve symbols via branch-local → parent.

Write path:
  4. upsert_symbol / upsert_file / upsert_cluster tag with current branch and
     include branch in the UPSERT WHERE condition.

Delete path:
  5. delete_symbols_for_file / delete_file are scoped to current branch only.

Transaction path:
  6. begin_transaction sets _active_tx; commit/rollback clear it.
  7. _cmd_batch uses _active_tx automatically.

Helpers:
  8. _esc() escapes backslashes before single quotes (Windows path safety).
"""

from __future__ import annotations

import pytest

from ravmem.storage.graph_arcade import ArcadeGraphStore
from ravmem.storage.schema import Cluster, Edge, File, Symbol


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_store(branch: str, parent_branch: str | None = None) -> ArcadeGraphStore:
    """Build an ArcadeGraphStore with no real DB connection.

    _q and _cmd are left as None — individual tests assign their own stubs.
    """
    import threading
    store = object.__new__(ArcadeGraphStore)
    store._branch = branch
    store._parent_branch = parent_branch
    store._project_id = "test-project"
    store._local = threading.local()  # required for _active_tx property
    store._db = None  # no real connection
    return store


def _sym_row(sym_id: str, name: str = "fn", branch: str = "main") -> dict:
    return {
        "id": sym_id, "name": name, "kind": "function",
        "file": "/repo/foo.py", "line_start": 1, "line_end": 5,
        "lang": "python", "cluster_id": "", "embedding_id": -1,
        "docstring": "", "branch": branch,
    }


def _cluster_row(cid: str, branch: str = "main") -> dict:
    return {
        "id": cid, "label": "auth", "cohesion_score": 0.8,
        "size": 3, "branch": branch,
    }


# ---------------------------------------------------------------------------
# Read path — get_symbol
# ---------------------------------------------------------------------------

class TestGetSymbolCoW:

    def test_branch_local_hit_no_fallback(self):
        """get_symbol returns branch-local copy without querying parent."""
        store = _make_store("feature", parent_branch="main")
        calls = []

        def fake_q(sql: str) -> list:
            calls.append(sql)
            if "branch='feature'" in sql:
                return [_sym_row("s1", branch="feature")]
            return []

        store._q = fake_q
        result = store.get_symbol("s1")

        assert result is not None
        assert result.id == "s1"
        # Only one query — parent fallback must NOT have been triggered
        assert len(calls) == 1
        assert "branch='feature'" in calls[0]

    def test_fallback_to_parent_when_branch_local_missing(self):
        """get_symbol falls back to parent when no branch-local copy exists."""
        store = _make_store("feature", parent_branch="main")
        calls = []

        def fake_q(sql: str) -> list:
            calls.append(sql)
            if "branch='feature'" in sql:
                return []  # no branch-local copy
            if "branch='main'" in sql:
                return [_sym_row("s1", branch="main")]
            return []

        store._q = fake_q
        result = store.get_symbol("s1")

        assert result is not None
        assert result.id == "s1"
        assert len(calls) == 2
        assert "branch='feature'" in calls[0]
        assert "branch='main'" in calls[1]

    def test_not_found_in_either_branch(self):
        """get_symbol returns None when symbol exists in neither branch."""
        store = _make_store("feature", parent_branch="main")
        store._q = lambda sql: []

        result = store.get_symbol("missing")
        assert result is None

    def test_no_parent_branch_single_query(self):
        """get_symbol on main branch makes exactly one query, no fallback."""
        store = _make_store("main", parent_branch=None)
        calls = []

        def fake_q(sql: str) -> list:
            calls.append(sql)
            return []

        store._q = fake_q
        result = store.get_symbol("s1")

        assert result is None
        assert len(calls) == 1  # no second fallback query


# ---------------------------------------------------------------------------
# Read path — get_all_symbols
# ---------------------------------------------------------------------------

class TestGetAllSymbolsCoW:

    def test_branch_local_wins_over_parent_for_same_id(self):
        """When both branch and parent have the same id, branch version is returned."""
        store = _make_store("feature", parent_branch="main")

        def fake_q(sql: str) -> list:
            if "branch='feature'" in sql:
                return [_sym_row("s1", name="feature_version", branch="feature")]
            if "branch='main'" in sql:
                return [_sym_row("s1", name="parent_version", branch="main")]
            return []

        store._q = fake_q
        symbols = store.get_all_symbols()

        names = [s.name for s in symbols]
        assert "feature_version" in names
        assert "parent_version" not in names  # shadowed by branch-local

    def test_inherits_parent_symbols_not_in_branch(self):
        """Symbols only in parent are included in the result."""
        store = _make_store("feature", parent_branch="main")

        def fake_q(sql: str) -> list:
            if "branch='feature'" in sql:
                return [_sym_row("s1", name="branch_only", branch="feature")]
            if "branch='main'" in sql:
                return [
                    _sym_row("s1", name="parent_version", branch="main"),  # shadowed
                    _sym_row("s2", name="parent_only", branch="main"),     # inherited
                ]
            return []

        store._q = fake_q
        symbols = store.get_all_symbols()

        ids = {s.id for s in symbols}
        names = {s.name for s in symbols}

        assert "s1" in ids
        assert "s2" in ids
        assert "branch_only" in names
        assert "parent_only" in names
        assert "parent_version" not in names  # shadowed
        assert len(symbols) == 2  # no duplicates

    def test_no_parent_returns_branch_only(self):
        """With no parent_branch, only branch-local symbols are returned."""
        store = _make_store("main", parent_branch=None)

        def fake_q(sql: str) -> list:
            if "branch='main'" in sql:
                return [_sym_row("s1", branch="main")]
            return []

        store._q = fake_q
        symbols = store.get_all_symbols()
        assert len(symbols) == 1
        assert symbols[0].id == "s1"


# ---------------------------------------------------------------------------
# Write path — upsert_symbol / upsert_file / upsert_cluster
# ---------------------------------------------------------------------------

class TestUpsertBranchTagging:

    def test_upsert_symbol_tags_current_branch(self):
        """upsert_symbol SQL must include branch=current_branch in SET and WHERE."""
        store = _make_store("feature", parent_branch="main")
        captured = []
        store._cmd = lambda sql, session_id=None: captured.append(sql)

        sym = Symbol(
            id="s1", name="fn", kind="function",
            file="/f.py", line_start=1, line_end=5, lang="python",
        )
        store.upsert_symbol(sym)

        assert len(captured) == 1
        sql = captured[0]
        assert "branch='feature'" in sql
        # Must appear in UPSERT WHERE condition (not just SET)
        assert sql.count("branch='feature'") >= 1

    def test_upsert_symbol_upsert_condition_includes_branch(self):
        """The UPSERT WHERE clause must have BOTH id AND branch — branch-local upsert."""
        store = _make_store("feature")
        captured = []
        store._cmd = lambda sql, session_id=None: captured.append(sql)

        sym = Symbol(
            id="s1", name="fn", kind="function",
            file="/f.py", line_start=1, line_end=5, lang="python",
        )
        store.upsert_symbol(sym)
        sql = captured[0]

        assert "UPSERT WHERE" in sql
        assert "id='s1'" in sql
        assert "branch='feature'" in sql

    def test_upsert_file_tags_current_branch(self):
        """upsert_file SQL includes branch=current_branch."""
        store = _make_store("feature")
        captured = []
        store._cmd = lambda sql, session_id=None: captured.append(sql)

        f = File(path="/f.py", lang="python", size_kb=1.0, checksum="abc")
        store.upsert_file(f)

        sql = captured[0]
        assert "branch='feature'" in sql

    def test_upsert_cluster_tags_current_branch(self):
        """upsert_cluster SQL includes branch=current_branch."""
        store = _make_store("feature")
        captured = []
        store._cmd = lambda sql, session_id=None: captured.append(sql)

        c = Cluster(id="c1", label="auth", cohesion_score=0.8, size=3)
        store.upsert_cluster(c)

        sql = captured[0]
        assert "branch='feature'" in sql

    def test_upsert_does_not_reference_parent_branch(self):
        """Writes must never touch the parent branch — only current_branch."""
        store = _make_store("feature", parent_branch="main")
        captured = []
        store._cmd = lambda sql, session_id=None: captured.append(sql)

        sym = Symbol(
            id="s1", name="fn", kind="function",
            file="/f.py", line_start=1, line_end=5, lang="python",
        )
        store.upsert_symbol(sym)

        sql = captured[0]
        # parent branch must NOT appear anywhere in the write SQL
        assert "branch='main'" not in sql


# ---------------------------------------------------------------------------
# Delete path — branch-scoped deletes
# ---------------------------------------------------------------------------

class TestDeleteBranchScoped:

    def test_delete_symbols_for_file_scoped_to_branch(self):
        """DELETE SQL for symbols must include branch=current_branch."""
        store = _make_store("feature", parent_branch="main")
        delete_calls = []

        def fake_q(sql: str) -> list:
            # SELECT count call — return one row so delete executes
            return [_sym_row("s1", branch="feature")]

        def fake_cmd(sql: str, session_id=None) -> None:
            delete_calls.append(sql)

        store._q = fake_q
        store._cmd = fake_cmd

        store.delete_symbols_for_file("/f.py")

        assert len(delete_calls) == 1
        sql = delete_calls[0]
        assert "branch='feature'" in sql
        assert "branch='main'" not in sql  # parent untouched

    def test_delete_file_scoped_to_branch(self):
        """DELETE FILE SQL must include branch=current_branch."""
        store = _make_store("feature", parent_branch="main")
        delete_calls = []
        store._cmd = lambda sql, session_id=None: delete_calls.append(sql)

        store.delete_file("/f.py")

        assert len(delete_calls) == 1
        assert "branch='feature'" in delete_calls[0]
        assert "branch='main'" not in delete_calls[0]

    def test_delete_symbols_noop_when_none_in_branch(self):
        """No DELETE command is issued when there are no branch-local symbols."""
        store = _make_store("feature")
        delete_calls = []

        store._q = lambda sql: []  # nothing found in SELECT
        store._cmd = lambda sql, session_id=None: delete_calls.append(sql)

        count = store.delete_symbols_for_file("/f.py")

        assert count == 0
        assert len(delete_calls) == 0  # DELETE must not fire


# ---------------------------------------------------------------------------
# Read path — get_callers / get_callees CoW resolution
# ---------------------------------------------------------------------------

class TestTraversalCoW:

    def test_get_callers_resolves_via_parent_fallback(self):
        """BFS callers: found caller ID is resolved via parent when not in branch."""
        store = _make_store("feature", parent_branch="main")

        def fake_q(sql: str) -> list:
            # Edge query: caller_id='s0' calls 's1'
            if "caller_id" in sql and "@in.id" in sql:
                return [{"caller_id": "s0"}]
            # Branch-local resolution for s0: not found
            if "id IN" in sql and "branch='feature'" in sql:
                return []
            # Parent resolution for s0: found
            if "id IN" in sql and "branch='main'" in sql:
                return [_sym_row("s0", name="caller_fn", branch="main")]
            return []

        store._q = fake_q
        callers = store.get_callers("s1", depth=1)

        assert len(callers) == 1
        assert callers[0].id == "s0"
        assert callers[0].name == "caller_fn"

    def test_get_callers_uses_branch_filter_on_edges(self):
        """Edge traversal SQL must filter @in.branch to visible branches."""
        store = _make_store("feature", parent_branch="main")
        queries = []

        def fake_q(sql: str) -> list:
            queries.append(sql)
            return []

        store._q = fake_q
        store.get_callers("s1", depth=1)

        edge_queries = [q for q in queries if "caller_id" in q]
        assert len(edge_queries) >= 1
        # The edge query must restrict to the visible branch set
        eq = edge_queries[0]
        assert "feature" in eq or "main" in eq

    def test_get_callees_resolves_via_parent_fallback(self):
        """BFS callees: found callee ID resolved via parent when not in branch."""
        store = _make_store("feature", parent_branch="main")

        def fake_q(sql: str) -> list:
            if "callee_id" in sql and "@out.id" in sql:
                return [{"callee_id": "s2"}]
            if "id IN" in sql and "branch='feature'" in sql:
                return []
            if "id IN" in sql and "branch='main'" in sql:
                return [_sym_row("s2", name="callee_fn", branch="main")]
            return []

        store._q = fake_q
        callees = store.get_callees("s1", depth=1)

        assert len(callees) == 1
        assert callees[0].id == "s2"


# ---------------------------------------------------------------------------
# get_cluster CoW
# ---------------------------------------------------------------------------

class TestGetClusterCoW:

    def test_get_cluster_falls_back_to_parent(self):
        """get_cluster falls back to parent when no branch-local cluster exists."""
        store = _make_store("feature", parent_branch="main")
        calls = []

        def fake_q(sql: str) -> list:
            calls.append(sql)
            if "branch='feature'" in sql:
                return []
            if "branch='main'" in sql:
                return [_cluster_row("c1", branch="main")]
            return []

        store._q = fake_q
        cluster = store.get_cluster("c1")

        assert cluster is not None
        assert cluster.id == "c1"
        assert len(calls) == 2

    def test_get_all_clusters_dedup_branch_wins(self):
        """get_all_clusters: branch-local cluster shadows same-id parent cluster."""
        store = _make_store("feature", parent_branch="main")

        def fake_q(sql: str) -> list:
            if "branch='feature'" in sql:
                return [_cluster_row("c1", branch="feature")]
            if "branch='main'" in sql:
                return [
                    _cluster_row("c1", branch="main"),   # shadowed
                    _cluster_row("c2", branch="main"),   # inherited
                ]
            return []

        store._q = fake_q
        clusters = store.get_all_clusters()

        ids = [c.id for c in clusters]
        assert ids.count("c1") == 1   # deduplicated
        assert "c2" in ids


# ---------------------------------------------------------------------------
# Transaction lifecycle
# ---------------------------------------------------------------------------

class TestTransactionLifecycle:

    def test_begin_sets_active_tx(self):
        """begin_transaction() stores session_id in _active_tx."""
        store = _make_store("main")
        mock_db = type("DB", (), {})()
        mock_db.begin_transaction = lambda: "sess-001"
        mock_db.commit_transaction = lambda sid: None
        mock_db.rollback_transaction = lambda sid: None
        store._db = mock_db

        sid = store.begin_transaction()
        assert sid == "sess-001"
        assert store._active_tx == "sess-001"

    def test_commit_clears_active_tx(self):
        """commit_transaction() clears _active_tx."""
        store = _make_store("main")
        committed = []
        mock_db = type("DB", (), {})()
        mock_db.commit_transaction = lambda sid: committed.append(sid)
        store._db = mock_db
        store._active_tx = "sess-001"

        store.commit_transaction("sess-001")

        assert store._active_tx is None
        assert "sess-001" in committed

    def test_rollback_clears_active_tx(self):
        """rollback_transaction() clears _active_tx."""
        store = _make_store("main")
        rolled = []
        mock_db = type("DB", (), {})()
        mock_db.rollback_transaction = lambda sid: rolled.append(sid)
        store._db = mock_db
        store._active_tx = "sess-001"

        store.rollback_transaction("sess-001")

        assert store._active_tx is None
        assert "sess-001" in rolled

    def test_cmd_uses_active_tx_automatically(self):
        """_cmd() uses self._active_tx without an explicit session_id argument."""
        store = _make_store("main")
        calls = []

        def fake_query(lang, sql, session_id=None, is_command=False):
            calls.append((sql, session_id))

        mock_db = type("DB", (), {"query": staticmethod(fake_query)})()
        store._db = mock_db
        store._active_tx = "sess-xyz"

        store._cmd("UPDATE Symbol SET name='x'")

        assert len(calls) == 1
        assert calls[0][1] == "sess-xyz"  # session automatically picked up


# ---------------------------------------------------------------------------
# _esc() — backslash-before-quote ordering (Windows path safety)
# ---------------------------------------------------------------------------

class TestEscaping:

    def test_esc_doubles_backslash(self):
        assert ArcadeGraphStore._esc("C:\\Users\\foo") == "C:\\\\Users\\\\foo"

    def test_esc_escapes_single_quote(self):
        assert ArcadeGraphStore._esc("O'Reilly") == "O\\'Reilly"

    def test_esc_backslash_before_quote_order(self):
        """Backslash must be escaped FIRST; C:\\'s end quote must not be double-escaped."""
        raw = "C:\\it's"
        result = ArcadeGraphStore._esc(raw)
        # After correct escaping: C:\\ + it + \' + s  →  C:\\\\it\\'s
        assert result == "C:\\\\it\\'s"

    def test_esc_none_returns_empty(self):
        assert ArcadeGraphStore._esc(None) == ""

    def test_esc_empty_string_returns_empty(self):
        assert ArcadeGraphStore._esc("") == ""


# ---------------------------------------------------------------------------
# Cluster member CoW resolution
# ---------------------------------------------------------------------------

class TestGetClusterMembersCoW:
    """Tests for the CoW-correct get_cluster_members() implementation.

    Uses _sym_row with cluster_id set so the query-by-cluster_id approach works.
    """

    def _sym_row_with_cluster(
        self, sym_id: str, cluster_id: str, branch: str = "main"
    ) -> dict:
        row = _sym_row(sym_id, branch=branch)
        row["cluster_id"] = cluster_id
        return row

    def test_branch_local_members_returned(self):
        """Members on the current branch are returned directly."""
        store = _make_store("feature", parent_branch="main")

        branch_rows = [
            self._sym_row_with_cluster("s1", "lc_abc", branch="feature"),
            self._sym_row_with_cluster("s2", "lc_abc", branch="feature"),
        ]

        def fake_q(sql: str) -> list:
            if "branch='feature'" in sql and "cluster_id='lc_abc'" in sql:
                return branch_rows
            return []

        store._q = fake_q
        members = store.get_cluster_members("lc_abc")

        assert len(members) == 2
        assert {m.id for m in members} == {"s1", "s2"}

    def test_parent_fallback_when_no_branch_local(self):
        """If branch has no members, parent branch members are returned."""
        store = _make_store("feature", parent_branch="main")

        parent_rows = [
            self._sym_row_with_cluster("s3", "lc_abc", branch="main"),
        ]

        def fake_q(sql: str) -> list:
            if "branch='feature'" in sql:
                return []
            if "branch='main'" in sql and "cluster_id='lc_abc'" in sql:
                return parent_rows
            return []

        store._q = fake_q
        members = store.get_cluster_members("lc_abc")

        assert len(members) == 1
        assert members[0].id == "s3"

    def test_branch_local_overrides_parent(self):
        """Symbol overridden on feature branch is not duplicated from parent."""
        store = _make_store("feature", parent_branch="main")

        # s1 exists on feature branch with new cluster; s2 only on main
        branch_rows = [self._sym_row_with_cluster("s1", "lc_abc", branch="feature")]
        parent_rows = [
            self._sym_row_with_cluster("s1", "lc_abc", branch="main"),  # overridden
            self._sym_row_with_cluster("s2", "lc_abc", branch="main"),  # inherited
        ]

        def fake_q(sql: str) -> list:
            if "branch='feature'" in sql and "cluster_id='lc_abc'" in sql:
                return branch_rows
            if "branch='main'" in sql and "cluster_id='lc_abc'" in sql:
                return parent_rows
            return []

        store._q = fake_q
        members = store.get_cluster_members("lc_abc")

        # s1 from branch wins; s1 from parent is excluded; s2 inherited
        assert len(members) == 2
        ids = {m.id for m in members}
        assert ids == {"s1", "s2"}

    def test_no_parent_branch_no_fallback(self):
        """When parent_branch is None, no fallback query is issued."""
        store = _make_store("main", parent_branch=None)

        queries: list[str] = []

        def fake_q(sql: str) -> list:
            queries.append(sql)
            return [self._sym_row_with_cluster("s1", "lc_xyz", branch="main")]

        store._q = fake_q
        members = store.get_cluster_members("lc_xyz")

        assert len(members) == 1
        # Only one query issued (no parent fallback)
        assert len(queries) == 1

    def test_leiden_cluster_vertex_has_no_origin_rid(self):
        """Cluster vertex DDL does not include origin_rid — only branch property."""
        from ravmem.storage.schema import ARCADE_DDL

        cluster_props = [s for s in ARCADE_DDL if "CREATE PROPERTY Cluster" in s]
        prop_names = [s.split("Cluster.")[1].split(" ")[0] for s in cluster_props]

        assert "branch" in prop_names
        assert "origin_rid" not in prop_names, \
            "Cluster vertices should not have origin_rid (only Symbol and File do)"
