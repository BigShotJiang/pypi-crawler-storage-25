"""End-to-end smoke test: indexes a real Python fixture, queries it via the live server.

Skipped automatically when ArcadeDB is not reachable.
NOT subject to the FakeGraphStore patch in conftest.py — uses the real ArcadeGraphStore
so this test catches regressions in the full pipeline that unit tests (which mock the
graph layer) cannot.

Run manually:
    docker compose up arcadedb -d
    .venv/bin/python -m pytest tests/test_smoke.py -v -s

What this covers that the unit test suite does not:
  - Real ArcadeGraphStore writes + reads (no FakeGraphStore)
  - Full 5-phase pipeline (structure → parse → resolve → cluster → embed)
  - BM25 + vector search returning live indexed symbols
  - Impact BFS traversal over ArcadeDB-stored edges
  - All 10 MCP tools wired to real engine instances
  - HTTP server health, metrics, and graph endpoints
  - Symbol context, cluster listing, files/symbols endpoints
  - Incremental reindex: new symbol appears after re-indexing modified file
  - Search result relevance across multiple queries
  - Unified diff impact analysis (diff_impact)
"""

from __future__ import annotations

import textwrap
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Skip guard
# ---------------------------------------------------------------------------

def _arcadedb_available() -> bool:
    try:
        import urllib.request
        urllib.request.urlopen("http://localhost:2480/api/v1/ready", timeout=2)
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _arcadedb_available(),
    reason="ArcadeDB not reachable — start with: docker compose up arcadedb",
)


# ---------------------------------------------------------------------------
# Fixture: richer Python repo — 3 files, 7 symbols, cross-file call edges
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def fixture_repo(tmp_path_factory):
    """Three-file Python repo with a predictable symbol + call graph.

    Files:
      math_utils.py  — add, multiply, square
      string_utils.py — format_result, validate_input
      api.py         — compute, report

    Cross-file call edges (same-file calls are excluded by the resolver):
      compute  → add     (api.py → math_utils.py)
      compute  → square  (api.py → math_utils.py)
      report   → format_result (api.py → string_utils.py)

    Same-file (excluded):
      square   → multiply  (math_utils.py internal)
      report   → compute   (api.py internal)

    Expected symbols: add, multiply, square, format_result, validate_input, compute, report  (7)
    Expected cross-file edges: at least 3
    """
    repo = tmp_path_factory.mktemp("smoke_repo")

    (repo / "math_utils.py").write_text(textwrap.dedent("""\
        def add(a, b):
            \"\"\"Add two numbers.\"\"\"
            return a + b

        def multiply(a, b):
            \"\"\"Multiply two numbers.\"\"\"
            return a * b

        def square(x):
            \"\"\"Square a number using multiply.\"\"\"
            return multiply(x, x)
    """))

    (repo / "string_utils.py").write_text(textwrap.dedent("""\
        def validate_input(value):
            \"\"\"Validate that value is a finite number.\"\"\"
            if not isinstance(value, (int, float)):
                raise TypeError(f"Expected number, got {type(value)}")
            return float(value)

        def format_result(value, label="result"):
            \"\"\"Format a numeric result as a labelled string.\"\"\"
            return f"{label}: {value:.4f}"
    """))

    (repo / "api.py").write_text(textwrap.dedent("""\
        from math_utils import add, square
        from string_utils import format_result, validate_input

        def compute(x, y):
            \"\"\"Sum of squares of x and y.\"\"\"
            x = validate_input(x)
            y = validate_input(y)
            return add(square(x), square(y))

        def report(x, y, label="output"):
            \"\"\"Compute and format as a labelled string.\"\"\"
            result = compute(x, y)
            return format_result(result, label)
    """))

    return repo


# ---------------------------------------------------------------------------
# Fixture: run full pipeline + wire into app engine registry
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def smoke_client(fixture_repo):
    """Run the full 5-phase IndexPipeline, return a (TestClient, engines, repo_id) tuple.

    Uses a unique branch + project_id per run to avoid ArcadeDB collisions in CI.
    """
    from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig
    from ravmem.server.app import create_app, RepoEngines, _engines
    from ravmem.config import INDEX_DIR, VECTORS_SUBDIR, META_DB_NAME, BM25_INDEX_NAME
    from ravmem.storage.meta import MetaStore
    from ravmem.storage.vectors import VectorStore
    from ravmem.storage.graph_arcade import ArcadeGraphStore
    from ravmem.engine.search import SearchEngine
    from ravmem.engine.impact import ImpactEngine
    from ravmem.engine.context import ContextEngine
    from ravmem.engine.ranking import compute_centrality

    run_id = uuid.uuid4().hex[:8]
    branch = f"smoke-{run_id}"
    project_id = f"smoke-{run_id}"

    # Run the full 5-phase pipeline (skip_embeddings=False for real semantic search)
    pipeline = IndexPipeline(
        fixture_repo,
        config=PipelineConfig(langs=["python"], skip_embeddings=False),
        branch=branch,
        repo_id=project_id,
    )
    pipeline.run_full()
    pipeline.close()

    # Open storage handles to the indexes the pipeline just wrote
    index_dir = fixture_repo / INDEX_DIR
    gs = ArcadeGraphStore(branch, project_id=project_id)
    vs = VectorStore(index_dir / VECTORS_SUBDIR)
    vs.initialize()
    ms = MetaStore(index_dir / META_DB_NAME)
    centrality = compute_centrality(gs, ms, project_id)
    bm25_path = index_dir / BM25_INDEX_NAME

    # Wire into the module-level engine registry (legacy /api/repos/… path)
    eng = RepoEngines.__new__(RepoEngines)
    eng.repo_path = fixture_repo
    eng.index_dir = index_dir
    eng.graph = gs
    eng.vectors = vs
    eng.meta = ms
    eng.search_engine = SearchEngine(vs, bm25_path=bm25_path, centrality=centrality)
    eng.impact_engine = ImpactEngine(gs)
    eng.context_engine = ContextEngine(gs, eng.search_engine, eng.impact_engine)

    repo_key = str(fixture_repo)
    _engines[repo_key] = eng

    # repos_dir is fixture_repo's parent; repo_id on the URL is fixture_repo.name
    app = create_app(repos_dir=fixture_repo.parent)
    client = TestClient(app, raise_server_exceptions=True)

    yield client, eng, fixture_repo.name

    _engines.pop(repo_key, None)
    try:
        eng.graph.close()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _symbol_by_name(eng, name: str):
    """Return the Symbol with the given name from the graph."""
    symbols = eng.graph.get_all_symbols()
    return next((s for s in symbols if s.name == name), None)


def _assert_mcp_ok(result: dict, *, tool: str) -> str:
    """Assert an MCP result is not an error and return its text content."""
    assert not result["isError"], f"MCP tool '{tool}' returned error: {result['content']}"
    assert result["content"], f"MCP tool '{tool}' returned empty content"
    return result["content"][0]["text"]


# ---------------------------------------------------------------------------
# Test class 1: Server basics
# ---------------------------------------------------------------------------

class TestServerBasics:
    def test_health_endpoint_structure(self, smoke_client):
        """Health endpoint returns all expected fields with status=ok."""
        client, _, _ = smoke_client
        r = client.get("/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert "version" in body
        assert "uptime_seconds" in body
        assert isinstance(body["uptime_seconds"], (int, float))
        assert body["uptime_seconds"] >= 0
        assert "projects_count" in body
        assert "active_jobs" in body
        assert "queued_jobs" in body

    def test_metrics_endpoint_prometheus_format(self, smoke_client):
        """Metrics returns Prometheus text format with expected gauge names."""
        client, _, _ = smoke_client
        r = client.get("/api/metrics")
        assert r.status_code == 200
        text = r.text
        assert "ravmem_projects_total" in text
        assert "ravmem_jobs_active" in text
        assert "ravmem_jobs_queued" in text
        assert "ravmem_uptime_seconds" in text
        assert "# TYPE" in text
        assert "# HELP" in text

    def test_mcp_tool_list(self, smoke_client):
        """GET /mcp returns all tool definitions."""
        client, _, _ = smoke_client
        r = client.get("/mcp")
        assert r.status_code == 200
        tools = r.json()["tools"]
        tool_names = {t["name"] for t in tools}
        expected = {
            "search_symbols", "get_impact", "get_call_chain", "get_cluster",
            "get_symbol", "diff_impact", "list_repos", "suggest_entry_points",
            "get_file_context", "get_symbols_for_path", "sync_workspace",
        }
        assert expected == tool_names, f"Tool list mismatch. Got: {tool_names}"
        for tool in tools:
            assert "inputSchema" in tool, f"Tool {tool['name']} missing inputSchema"
            assert "description" in tool, f"Tool {tool['name']} missing description"


# ---------------------------------------------------------------------------
# Test class 2: Pipeline indexing correctness
# ---------------------------------------------------------------------------

class TestIndexingCorrectness:
    def test_all_seven_symbols_indexed(self, smoke_client):
        """All 7 expected functions are stored in ArcadeDB."""
        _, eng, _ = smoke_client
        symbols = eng.graph.get_all_symbols()
        names = {s.name for s in symbols}
        for expected in ("add", "multiply", "square", "format_result",
                         "validate_input", "compute", "report"):
            assert expected in names, f"'{expected}' missing from graph. Got: {names}"

    def test_symbol_has_expected_attributes(self, smoke_client):
        """Indexed symbols carry kind, file, line numbers, and lang."""
        _, eng, _ = smoke_client
        sym = _symbol_by_name(eng, "compute")
        assert sym is not None
        assert sym.kind == "function"
        assert sym.lang == "python"
        assert "api.py" in sym.file
        assert sym.line_start > 0
        assert sym.line_end >= sym.line_start

    def test_cross_file_call_edges_created(self, smoke_client):
        """compute (api.py) has cross-file callees add and square (math_utils.py)."""
        _, eng, _ = smoke_client
        compute = _symbol_by_name(eng, "compute")
        assert compute is not None
        callees = eng.graph.get_callees(compute.id, depth=1)
        callee_names = {s.name for s in callees}
        assert callee_names & {"add", "square"}, \
            f"Expected add/square as callees of compute, got: {callee_names}"

    def test_cross_file_caller_edges_created(self, smoke_client):
        """add and square (math_utils.py) have compute (api.py) as a cross-file caller."""
        _, eng, _ = smoke_client
        add = _symbol_by_name(eng, "add")
        assert add is not None
        callers = eng.graph.get_callers(add.id, depth=1)
        caller_names = {s.name for s in callers}
        assert "compute" in caller_names, \
            f"Expected compute as caller of add, got: {caller_names}"

    def test_string_utils_cross_file_edge(self, smoke_client):
        """report (api.py) has cross-file callee format_result (string_utils.py)."""
        _, eng, _ = smoke_client
        report = _symbol_by_name(eng, "report")
        assert report is not None
        callees = eng.graph.get_callees(report.id, depth=1)
        callee_names = {s.name for s in callees}
        assert "format_result" in callee_names, \
            f"Expected format_result as callee of report, got: {callee_names}"

    def test_symbols_clustered(self, smoke_client):
        """Symbols have non-empty cluster_ids assigned by the clustering phase."""
        _, eng, _ = smoke_client
        symbols = eng.graph.get_all_symbols()
        clustered = [s for s in symbols if s.cluster_id]
        assert clustered, "No symbols have cluster_ids — clustering phase may have failed"

    def test_symbols_have_docstrings(self, smoke_client):
        """Docstrings are persisted in ArcadeDB for symbols that have them."""
        _, eng, _ = smoke_client
        add = _symbol_by_name(eng, "add")
        assert add is not None
        assert add.docstring, f"Expected docstring on 'add', got empty string"
        assert "Add" in add.docstring or "add" in add.docstring.lower()


# ---------------------------------------------------------------------------
# Test class 3: REST search and symbol endpoints
# ---------------------------------------------------------------------------

class TestSearchAndSymbols:
    def test_search_finds_exact_name(self, smoke_client):
        """Search for 'multiply' returns multiply in results."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/search", params={"q": "multiply", "limit": 10})
        assert r.status_code == 200, r.text
        names = [hit["symbol"]["name"] for hit in r.json()]
        assert "multiply" in names, f"'multiply' not in search results: {names}"

    def test_search_returns_score_and_match_type(self, smoke_client):
        """Each search result has score and match_type fields."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/search", params={"q": "add", "limit": 5})
        assert r.status_code == 200, r.text
        for hit in r.json():
            assert "score" in hit, f"Missing score in hit: {hit}"
            assert "match_type" in hit, f"Missing match_type in hit: {hit}"
            assert hit["match_type"] in ("bm25", "semantic", "hybrid")

    def test_search_semantic_format_result(self, smoke_client):
        """Semantic/hybrid search finds format_result for a natural language query."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/search",
                       params={"q": "format number as string label", "limit": 10})
        assert r.status_code == 200, r.text
        names = [hit["symbol"]["name"] for hit in r.json()]
        assert "format_result" in names, \
            f"'format_result' not found via semantic query: {names}"

    def test_search_respects_limit(self, smoke_client):
        """Search limit parameter caps the number of results."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/search", params={"q": "function", "limit": 3})
        assert r.status_code == 200, r.text
        assert len(r.json()) <= 3

    def test_symbol_context_endpoint(self, smoke_client):
        """GET /api/repos/{id}/symbol/{id} returns full context for compute."""
        client, eng, repo_id = smoke_client
        compute = _symbol_by_name(eng, "compute")
        assert compute is not None
        r = client.get(f"/api/repos/{repo_id}/symbol/{compute.id}")
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["symbol"]["name"] == "compute"
        assert "callers" in body
        assert "callees" in body
        callee_names = {c["name"] for c in body["callees"]}
        assert callee_names & {"add", "square"}, \
            f"Expected cross-file callees of compute, got: {callee_names}"

    def test_symbol_context_includes_cluster(self, smoke_client):
        """Symbol context endpoint returns cluster info when symbol has one."""
        client, eng, repo_id = smoke_client
        # Find a symbol with a cluster_id
        symbols = eng.graph.get_all_symbols()
        clustered = next((s for s in symbols if s.cluster_id), None)
        assert clustered is not None, "No clustered symbols found"
        r = client.get(f"/api/repos/{repo_id}/symbol/{clustered.id}")
        assert r.status_code == 200, r.text
        body = r.json()
        # cluster may be None if cluster vertex wasn't created, but key must exist
        assert "cluster" in body

    def test_symbol_not_found_returns_404(self, smoke_client):
        """Non-existent symbol ID returns 404."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/symbol/deadbeef00000000")
        assert r.status_code == 404

    def test_files_symbols_exact_path(self, smoke_client):
        """GET /files/symbols?path=<abs> returns symbols from that file."""
        client, eng, repo_id = smoke_client
        file_path = str(eng.repo_path / "math_utils.py")
        r = client.get(f"/api/repos/{repo_id}/files/symbols",
                       params={"path": file_path})
        assert r.status_code == 200, r.text
        body = r.json()
        assert "symbols" in body
        names = {s["name"] for s in body["symbols"]}
        assert {"add", "multiply", "square"} <= names, \
            f"Expected add/multiply/square in math_utils.py symbols, got: {names}"

    def test_files_symbols_prefix(self, smoke_client):
        """GET /files/symbols?path=&prefix=true returns all symbols."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/files/symbols",
                       params={"path": "", "prefix": "true"})
        assert r.status_code == 200, r.text
        body = r.json()
        assert len(body["symbols"]) >= 7, \
            f"Expected at least 7 symbols with prefix='', got {len(body['symbols'])}"


# ---------------------------------------------------------------------------
# Test class 4: Impact and call graph
# ---------------------------------------------------------------------------

class TestImpactAndCallGraph:
    def test_impact_square_reaches_compute(self, smoke_client):
        """Impact BFS from 'square' finds 'compute' as a cross-file caller."""
        client, eng, repo_id = smoke_client
        square = _symbol_by_name(eng, "square")
        assert square is not None
        r = client.get(f"/api/repos/{repo_id}/impact/{square.id}")
        assert r.status_code == 200, r.text
        body = r.json()
        assert "affected" in body, f"Unexpected response shape: {list(body.keys())}"
        assert "root_symbol_id" in body
        impact_names = {n["symbol"]["name"] for n in body["affected"]}
        assert "compute" in impact_names, \
            f"Expected 'compute' in impact of 'square', got: {impact_names}"

    def test_impact_includes_depth_and_path(self, smoke_client):
        """Each affected node carries depth and path fields."""
        client, eng, repo_id = smoke_client
        add = _symbol_by_name(eng, "add")
        assert add is not None
        r = client.get(f"/api/repos/{repo_id}/impact/{add.id}")
        assert r.status_code == 200, r.text
        for node in r.json()["affected"]:
            assert "depth" in node
            assert "path" in node
            assert isinstance(node["depth"], int) and node["depth"] > 0
            assert isinstance(node["path"], list) and len(node["path"]) > 0

    def test_impact_depth_parameter(self, smoke_client):
        """depth=1 limits impact to direct callers only."""
        client, eng, repo_id = smoke_client
        add = _symbol_by_name(eng, "add")
        assert add is not None
        r = client.get(f"/api/repos/{repo_id}/impact/{add.id}", params={"depth": 1})
        assert r.status_code == 200, r.text
        for node in r.json()["affected"]:
            assert node["depth"] == 1, \
                f"depth=1 produced node at depth {node['depth']}"

    def test_impact_format_result_reaches_report(self, smoke_client):
        """Impact BFS from 'format_result' finds 'report' (api.py caller)."""
        client, eng, repo_id = smoke_client
        fmt = _symbol_by_name(eng, "format_result")
        assert fmt is not None
        r = client.get(f"/api/repos/{repo_id}/impact/{fmt.id}")
        assert r.status_code == 200, r.text
        impact_names = {n["symbol"]["name"] for n in r.json()["affected"]}
        assert "report" in impact_names, \
            f"Expected 'report' in impact of 'format_result', got: {impact_names}"


# ---------------------------------------------------------------------------
# Test class 5: Clusters and graph topology
# ---------------------------------------------------------------------------

class TestClustersAndGraph:
    def test_clusters_endpoint_returns_list(self, smoke_client):
        """GET /clusters returns a non-empty list with id, label, size."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/clusters")
        assert r.status_code == 200, r.text
        clusters = r.json()
        assert isinstance(clusters, list)
        assert clusters, "Expected at least one cluster, got empty list"
        for c in clusters:
            assert "id" in c
            assert "label" in c
            assert "size" in c
            assert c["size"] > 0

    def test_graph_endpoint_returns_nodes_and_edges(self, smoke_client):
        """GET /graph returns nodes and edges dicts."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/graph")
        assert r.status_code == 200, r.text
        body = r.json()
        assert "nodes" in body, f"Missing 'nodes' in graph response: {list(body.keys())}"
        assert "edges" in body, f"Missing 'edges' in graph response: {list(body.keys())}"
        assert len(body["nodes"]) >= 7, \
            f"Expected ≥7 nodes, got {len(body['nodes'])}"

    def test_graph_has_call_edges(self, smoke_client):
        """Graph edges include the cross-file Calls edges created by the resolver."""
        client, _, repo_id = smoke_client
        r = client.get(f"/api/repos/{repo_id}/graph")
        assert r.status_code == 200, r.text
        edges = r.json()["edges"]
        assert edges, "Expected call edges in graph, got empty list"


# ---------------------------------------------------------------------------
# Test class 6: All 10 MCP tools
# ---------------------------------------------------------------------------

class TestMCPTools:
    def _call(self, client, tool_name: str, params: dict) -> dict:
        r = client.post("/mcp", json={
            "tool_calls": [{"name": tool_name, "parameters": params}]
        })
        assert r.status_code == 200, r.text
        results = r.json()["results"]
        assert len(results) == 1
        return results[0]

    def test_mcp_search_symbols(self, smoke_client):
        """search_symbols returns results containing 'square'."""
        client, _, repo_id = smoke_client
        result = self._call(client, "search_symbols", {"repo": repo_id, "query": "square"})
        text = _assert_mcp_ok(result, tool="search_symbols")
        assert "square" in text

    def test_mcp_get_impact(self, smoke_client):
        """get_impact returns a blast-radius result for 'square'."""
        client, eng, repo_id = smoke_client
        square = _symbol_by_name(eng, "square")
        result = self._call(client, "get_impact", {
            "repo": repo_id, "symbol_id": square.id, "depth": 3,
        })
        text = _assert_mcp_ok(result, tool="get_impact")
        import json
        body = json.loads(text)
        assert "affected" in body
        assert "root_symbol_id" in body

    def test_mcp_get_call_chain_callees(self, smoke_client):
        """get_call_chain(direction=callees) returns compute's callees."""
        client, eng, repo_id = smoke_client
        compute = _symbol_by_name(eng, "compute")
        result = self._call(client, "get_call_chain", {
            "repo": repo_id, "symbol_id": compute.id, "direction": "callees",
        })
        text = _assert_mcp_ok(result, tool="get_call_chain")
        assert text  # non-empty JSON

    def test_mcp_get_call_chain_both(self, smoke_client):
        """get_call_chain(direction=both) returns callers and callees dicts."""
        client, eng, repo_id = smoke_client
        compute = _symbol_by_name(eng, "compute")
        result = self._call(client, "get_call_chain", {
            "repo": repo_id, "symbol_id": compute.id, "direction": "both",
        })
        text = _assert_mcp_ok(result, tool="get_call_chain")
        import json
        body = json.loads(text)
        assert "callers" in body or "callees" in body, \
            f"direction=both should return callers/callees dict, got: {list(body.keys())}"

    def test_mcp_get_cluster(self, smoke_client):
        """get_cluster returns members for a known cluster."""
        client, eng, repo_id = smoke_client
        symbols = eng.graph.get_all_symbols()
        clustered = next((s for s in symbols if s.cluster_id), None)
        assert clustered is not None, "No clustered symbols to test get_cluster"
        result = self._call(client, "get_cluster", {
            "repo": repo_id, "cluster_id": clustered.cluster_id,
        })
        text = _assert_mcp_ok(result, tool="get_cluster")
        import json
        body = json.loads(text)
        assert "members" in body
        assert isinstance(body["members"], list)

    def test_mcp_get_symbol(self, smoke_client):
        """get_symbol returns full context for 'compute'."""
        client, eng, repo_id = smoke_client
        compute = _symbol_by_name(eng, "compute")
        result = self._call(client, "get_symbol", {
            "repo": repo_id, "symbol_id": compute.id,
        })
        text = _assert_mcp_ok(result, tool="get_symbol")
        import json
        body = json.loads(text)
        assert body["symbol"]["name"] == "compute"
        assert "callers" in body
        assert "callees" in body
        callee_names = {c["name"] for c in body["callees"]}
        assert callee_names & {"add", "square"}, \
            f"Expected add/square in get_symbol callees of compute, got: {callee_names}"

    def test_mcp_diff_impact(self, smoke_client):
        """diff_impact parses a unified diff and returns results (may be empty if names don't match)."""
        client, _, repo_id = smoke_client
        diff = textwrap.dedent("""\
            --- a/math_utils.py
            +++ b/math_utils.py
            @@ -1,4 +1,4 @@
            -def add(a, b):
            +def add(a, b, c=0):
                 \"\"\"Add two numbers.\"\"\"
            -    return a + b
            +    return a + b + c
        """)
        result = self._call(client, "diff_impact", {"repo": repo_id, "diff": diff})
        text = _assert_mcp_ok(result, tool="diff_impact")
        import json
        body = json.loads(text)
        assert "results" in body
        assert "deleted_or_unresolved_symbols" in body

    def test_mcp_list_repos(self, smoke_client):
        """list_repos returns a list (possibly empty if no meta.db for repos_dir scan)."""
        client, _, _ = smoke_client
        result = self._call(client, "list_repos", {})
        text = _assert_mcp_ok(result, tool="list_repos")
        import json
        repos = json.loads(text)
        assert isinstance(repos, list)

    def test_mcp_suggest_entry_points(self, smoke_client):
        """suggest_entry_points returns valid response structure."""
        client, _, repo_id = smoke_client
        result = self._call(client, "suggest_entry_points", {"repo": repo_id, "limit": 5})
        text = _assert_mcp_ok(result, tool="suggest_entry_points")
        import json
        body = json.loads(text)
        assert "entry_points" in body, f"suggest_entry_points response missing key: {list(body.keys())}"
        assert isinstance(body["entry_points"], list)

    def test_mcp_get_file_context(self, smoke_client):
        """get_file_context returns all symbols in math_utils.py with callers/callees."""
        client, eng, repo_id = smoke_client
        file_path = str(eng.repo_path / "math_utils.py")
        result = self._call(client, "get_file_context", {
            "repo": repo_id, "file_path": file_path,
        })
        text = _assert_mcp_ok(result, tool="get_file_context")
        import json
        body = json.loads(text)
        assert "file_path" in body
        assert "symbols" in body
        names = {s["symbol"]["name"] for s in body["symbols"]}
        assert names & {"add", "multiply", "square"}, \
            f"Expected math_utils.py symbols, got: {names}"

    def test_mcp_get_symbols_for_path_exact(self, smoke_client):
        """get_symbols_for_path returns symbols for an exact file path."""
        client, eng, repo_id = smoke_client
        file_path = str(eng.repo_path / "string_utils.py")
        result = self._call(client, "get_symbols_for_path", {
            "repo": repo_id, "path": file_path,
        })
        text = _assert_mcp_ok(result, tool="get_symbols_for_path")
        import json
        body = json.loads(text)
        assert "symbols" in body
        names = {s["name"] for s in body["symbols"]}
        assert names & {"format_result", "validate_input"}, \
            f"Expected string_utils.py symbols, got: {names}"

    def test_mcp_get_symbols_for_path_prefix(self, smoke_client):
        """get_symbols_for_path with prefix=true returns symbols from all files."""
        client, _, repo_id = smoke_client
        result = self._call(client, "get_symbols_for_path", {
            "repo": repo_id, "path": "", "prefix": True,
        })
        text = _assert_mcp_ok(result, tool="get_symbols_for_path")
        import json
        body = json.loads(text)
        assert body["prefix"] is True
        assert len(body["symbols"]) >= 7

    def test_mcp_multiple_tool_calls_in_one_request(self, smoke_client):
        """Multiple tool calls in one /mcp request are all dispatched."""
        client, eng, repo_id = smoke_client
        compute = _symbol_by_name(eng, "compute")
        r = client.post("/mcp", json={
            "tool_calls": [
                {"name": "search_symbols", "parameters": {"repo": repo_id, "query": "add"}},
                {"name": "get_symbol", "parameters": {"repo": repo_id, "symbol_id": compute.id}},
            ]
        })
        assert r.status_code == 200, r.text
        results = r.json()["results"]
        assert len(results) == 2
        for result in results:
            assert not result["isError"], f"Unexpected error in batch MCP: {result}"

    def test_mcp_unknown_tool_returns_error(self, smoke_client):
        """Unknown tool name returns an error result (not HTTP error)."""
        client, _, repo_id = smoke_client
        r = client.post("/mcp", json={
            "tool_calls": [{"name": "nonexistent_tool", "parameters": {}}]
        })
        assert r.status_code == 200, r.text
        results = r.json()["results"]
        assert results[0]["isError"], "Expected isError=true for unknown tool"


# ---------------------------------------------------------------------------
# Test class 7: Incremental reindex
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def incremental_repo(tmp_path_factory):
    """Two-file repo for incremental index testing — we add a third function after first index."""
    repo = tmp_path_factory.mktemp("incremental_repo")
    (repo / "utils.py").write_text(textwrap.dedent("""\
        def helper_a(x):
            \"\"\"First helper.\"\"\"
            return x * 2

        def helper_b(x):
            \"\"\"Second helper.\"\"\"
            return x + 10
    """))
    (repo / "main.py").write_text(textwrap.dedent("""\
        from utils import helper_a

        def run(x):
            \"\"\"Entry point.\"\"\"
            return helper_a(x)
    """))
    return repo


@pytest.fixture(scope="module")
def incremental_client(incremental_repo):
    """Full index on incremental_repo, then incremental re-index after adding a new function."""
    from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig
    from ravmem.server.app import create_app, RepoEngines, _engines
    from ravmem.config import INDEX_DIR, VECTORS_SUBDIR, META_DB_NAME, BM25_INDEX_NAME
    from ravmem.storage.meta import MetaStore
    from ravmem.storage.vectors import VectorStore
    from ravmem.storage.graph_arcade import ArcadeGraphStore
    from ravmem.engine.search import SearchEngine
    from ravmem.engine.impact import ImpactEngine
    from ravmem.engine.context import ContextEngine
    from ravmem.engine.ranking import compute_centrality

    run_id = uuid.uuid4().hex[:8]
    branch = f"incr-{run_id}"
    project_id = f"incr-{run_id}"

    # Phase 1: full index (skip_embeddings=False so BM25 corpus is built)
    pipeline = IndexPipeline(
        incremental_repo,
        config=PipelineConfig(langs=["python"], skip_embeddings=False),
        branch=branch,
        repo_id=project_id,
    )
    pipeline.run_full()
    pipeline.close()

    # Verify initial state: 3 symbols (helper_a, helper_b, run)
    gs_check = ArcadeGraphStore(branch, project_id=project_id)
    initial_names = {s.name for s in gs_check.get_all_symbols()}
    gs_check.close()
    assert "helper_a" in initial_names, f"Initial index missing helper_a: {initial_names}"
    assert "new_function" not in initial_names, "new_function should not exist yet"

    # Add a new function to utils.py
    existing = (incremental_repo / "utils.py").read_text()
    (incremental_repo / "utils.py").write_text(existing + textwrap.dedent("""\

        def new_function(x):
            \"\"\"Brand-new function added after initial index.\"\"\"
            return helper_a(x) + helper_b(x)
    """))

    # Phase 2: incremental re-index (skip_embeddings=False so BM25 is updated with new symbol)
    pipeline2 = IndexPipeline(
        incremental_repo,
        config=PipelineConfig(langs=["python"], skip_embeddings=False),
        branch=branch,
        repo_id=project_id,
    )
    pipeline2.run_incremental()
    pipeline2.close()

    # Wire engines for the updated index
    index_dir = incremental_repo / INDEX_DIR
    gs = ArcadeGraphStore(branch, project_id=project_id)
    vs = VectorStore(index_dir / VECTORS_SUBDIR)
    vs.initialize()
    ms = MetaStore(index_dir / META_DB_NAME)
    centrality = compute_centrality(gs, ms, project_id)
    bm25_path = index_dir / BM25_INDEX_NAME

    eng = RepoEngines.__new__(RepoEngines)
    eng.repo_path = incremental_repo
    eng.index_dir = index_dir
    eng.graph = gs
    eng.vectors = vs
    eng.meta = ms
    eng.search_engine = SearchEngine(vs, bm25_path=bm25_path, centrality=centrality)
    eng.impact_engine = ImpactEngine(gs)
    eng.context_engine = ContextEngine(gs, eng.search_engine, eng.impact_engine)

    repo_key = str(incremental_repo)
    _engines[repo_key] = eng

    app = create_app(repos_dir=incremental_repo.parent)
    client = TestClient(app, raise_server_exceptions=True)

    yield client, eng, incremental_repo.name

    _engines.pop(repo_key, None)
    try:
        eng.graph.close()
    except Exception:
        pass


class TestIncrementalIndexing:
    def test_new_function_appears_after_incremental_reindex(self, incremental_client):
        """new_function added to utils.py appears in the graph after incremental re-index."""
        _, eng, _ = incremental_client
        names = {s.name for s in eng.graph.get_all_symbols()}
        assert "new_function" in names, \
            f"'new_function' should appear after incremental reindex. Got: {names}"

    def test_existing_symbols_preserved_after_reindex(self, incremental_client):
        """helper_a, helper_b, and run survive the incremental reindex."""
        _, eng, _ = incremental_client
        names = {s.name for s in eng.graph.get_all_symbols()}
        for expected in ("helper_a", "helper_b", "run"):
            assert expected in names, \
                f"'{expected}' was lost during incremental reindex. Remaining: {names}"

    def test_new_function_searchable_after_reindex(self, incremental_client):
        """BM25 search finds new_function after it was added and re-indexed."""
        client, _, repo_id = incremental_client
        r = client.get(f"/api/repos/{repo_id}/search",
                       params={"q": "new_function", "limit": 10})
        assert r.status_code == 200, r.text
        names = [hit["symbol"]["name"] for hit in r.json()]
        assert "new_function" in names, \
            f"BM25 search did not find new_function after reindex. Got: {names}"
