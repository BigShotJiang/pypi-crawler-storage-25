"""Unit tests for IndexJobQueue."""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import pytest

from ravmem.server.job_queue import IndexJobQueue
from ravmem.server.registry import ServerRegistry


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


@pytest.fixture
def registry(tmp_dir):
    reg = ServerRegistry(tmp_dir / "server.db")
    # Seed a project so FK constraints are satisfied when creating jobs
    reg.create_project("proj1", "Project One", str(tmp_dir / "repo"), "main")
    reg.register_branch("proj1", "main", str(tmp_dir / "index"))
    yield reg
    reg.close()


@pytest.fixture
def queue(registry):
    return IndexJobQueue(registry, max_concurrent=2)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

async def _noop_factory():
    """A coroutine factory that does nothing."""
    await asyncio.sleep(0)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_initial_counts_are_zero(queue):
    """Before start(), both active_count and queued_count are 0."""
    assert queue.active_count == 0
    assert queue.queued_count == 0


@pytest.mark.asyncio
async def test_counts_after_start(queue):
    """After start() with no jobs enqueued, counts are still 0."""
    await queue.start()
    try:
        assert queue.active_count == 0
        assert queue.queued_count == 0
    finally:
        await queue.stop()


@pytest.mark.asyncio
async def test_crash_recovery_marks_running_jobs_failed(registry):
    """Jobs left in 'running' state are marked 'failed' on start()."""
    # Pre-populate two jobs: one running, one queued
    job_running = registry.create_job("proj1", "main", "full")
    registry.update_job(job_running, status="running")

    job_queued = registry.create_job("proj1", "main", "full")
    # leave job_queued as 'queued'

    q = IndexJobQueue(registry, max_concurrent=2)
    await q.start()
    try:
        recovered = registry.get_job(job_running)
        assert recovered["status"] == "failed"
        assert "server restarted" in recovered["failure_reason"]

        # The queued job should be untouched
        still_queued = registry.get_job(job_queued)
        assert still_queued["status"] == "queued"
    finally:
        await q.stop()


@pytest.mark.asyncio
async def test_crash_recovery_no_running_jobs(registry):
    """start() with no stale running jobs completes without error."""
    q = IndexJobQueue(registry, max_concurrent=2)
    await q.start()
    try:
        jobs = registry.list_jobs()
        assert all(j["status"] != "failed" for j in jobs)
    finally:
        await q.stop()


@pytest.mark.asyncio
async def test_enqueue_before_start_raises(queue):
    """enqueue() before start() raises RuntimeError."""
    job_id = registry_create_job_helper(queue)
    with pytest.raises(RuntimeError, match="not been started"):
        await queue.enqueue(job_id, _noop_factory)


def registry_create_job_helper(queue: IndexJobQueue) -> int:
    """Small helper to create a dummy job id without touching the registry."""
    return 999


@pytest.mark.asyncio
async def test_jobs_complete_successfully(queue):
    """Enqueue a coroutine factory, wait for it to finish, verify it was called."""
    called = []

    async def factory():
        called.append(1)

    await queue.start()
    try:
        job_id = queue._registry.create_job("proj1", "main", "full")
        await queue.enqueue(job_id, factory)
        # Wait for queue to drain
        await queue._queue.join()
        assert called == [1]
    finally:
        await queue.stop()


@pytest.mark.asyncio
async def test_bounded_concurrency(queue):
    """Max 2 jobs run simultaneously even when 5 are enqueued."""
    gate = asyncio.Event()
    peak_active: list[int] = []
    active_count_ref = [0]

    async def gated_factory():
        active_count_ref[0] += 1
        peak_active.append(active_count_ref[0])
        await gate.wait()
        active_count_ref[0] -= 1

    await queue.start()
    try:
        for i in range(5):
            job_id = queue._registry.create_job("proj1", "main", "full")
            await queue.enqueue(job_id, gated_factory)

        # Yield control so the worker loop can pick up jobs
        for _ in range(10):
            await asyncio.sleep(0)

        # At peak, no more than max_concurrent (2) jobs should be active
        # via the queue's own active_count property
        snapshot = queue.active_count
        assert snapshot <= 2, f"active_count={snapshot} exceeded max_concurrent=2"

        # Release the gate so all jobs can finish
        gate.set()
        await queue._queue.join()

        # Verify the peak from within the jobs also never exceeded 2
        assert max(peak_active) <= 2, f"peak inside jobs was {max(peak_active)}"
    finally:
        await queue.stop()


@pytest.mark.asyncio
async def test_active_count_nonzero_while_running(queue):
    """active_count > 0 while a long-running job is executing."""
    gate = asyncio.Event()
    observed: list[int] = []

    async def blocking_factory():
        await gate.wait()

    await queue.start()
    try:
        job_id = queue._registry.create_job("proj1", "main", "full")
        await queue.enqueue(job_id, blocking_factory)

        # Yield until worker picks it up
        for _ in range(20):
            await asyncio.sleep(0)
            if queue.active_count > 0:
                observed.append(queue.active_count)
                break

        assert observed, "active_count was never > 0 while job was running"
    finally:
        gate.set()
        await queue._queue.join()
        await queue.stop()


@pytest.mark.asyncio
async def test_queued_count_property(queue):
    """queued_count is 0 when no jobs are queued, and the queue tracks items correctly."""
    gate = asyncio.Event()

    async def blocking_factory():
        await gate.wait()

    await queue.start()
    try:
        # Before any jobs: queued_count is 0
        assert queue.queued_count == 0

        # Enqueue 3 jobs — more than max_concurrent (2)
        for i in range(3):
            job_id = queue._registry.create_job("proj1", "main", "full")
            await queue.enqueue(job_id, blocking_factory)

        # Let the worker loop start processing
        for _ in range(20):
            await asyncio.sleep(0)

        # The queue should have items tracked (qsize >= 0)
        # and active_count should be at most max_concurrent
        assert queue.active_count <= 2
        # queued_count is non-negative by construction
        assert queue.queued_count >= 0
    finally:
        gate.set()
        await queue._queue.join()
        await queue.stop()


@pytest.mark.asyncio
async def test_exception_in_job_does_not_crash_queue(queue):
    """A job that raises does not stop the queue from running subsequent jobs."""
    second_called = []

    async def failing_factory():
        raise ValueError("intentional failure")

    async def second_factory():
        second_called.append(1)

    await queue.start()
    try:
        job1 = queue._registry.create_job("proj1", "main", "full")
        await queue.enqueue(job1, failing_factory)

        # Give the worker time to process the failing job
        for _ in range(20):
            await asyncio.sleep(0)

        job2 = queue._registry.create_job("proj1", "main", "full")
        await queue.enqueue(job2, second_factory)

        await queue._queue.join()
        assert second_called == [1], "Queue did not recover after exception"
    finally:
        await queue.stop()


@pytest.mark.asyncio
async def test_stop_drains_gracefully(queue):
    """stop() waits for in-flight jobs to complete before returning."""
    completed = []

    async def fast_factory():
        completed.append(1)

    await queue.start()
    job_id = queue._registry.create_job("proj1", "main", "full")
    await queue.enqueue(job_id, fast_factory)
    # Yield a few times to let the worker pick up and finish the job
    for _ in range(5):
        await asyncio.sleep(0)
    await queue.stop()

    assert completed == [1], "Job did not complete before stop() returned"


@pytest.mark.asyncio
async def test_independent_jobs_enqueue_correctly(queue):
    """Multiple independent jobs for different projects all run to completion."""
    results = []

    def make_factory(label: str):
        async def factory():
            results.append(label)
        return factory

    await queue.start()
    try:
        for branch in ("main", "dev", "feature"):
            registry = queue._registry
            registry.register_branch("proj1", branch, f"/tmp/{branch}")
            job_id = registry.create_job("proj1", branch, "full")
            await queue.enqueue(job_id, make_factory(branch))

        await queue._queue.join()
        assert sorted(results) == ["dev", "feature", "main"]
    finally:
        await queue.stop()
