"""Unit tests for the rate limiting middleware and config loader."""

from __future__ import annotations

import os
import time
from pathlib import Path
from unittest.mock import patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Config loader tests
# ---------------------------------------------------------------------------

class TestConfigLoader:
    def test_defaults(self):
        from ravmem.config_loader import load_config
        cfg = load_config()
        assert cfg.server.port == 7432
        assert cfg.rate_limit.enabled is True
        assert cfg.rate_limit.limits.read == "1000/min"
        assert cfg.rate_limit.tiers.standard.read == "1000/min"
        assert cfg.rate_limit.tiers.admin.read == "5000/min"

    def test_env_override(self, monkeypatch):
        from ravmem.config_loader import load_config
        monkeypatch.setenv("RAVMEM_RATELIMIT_ENABLED", "false")
        monkeypatch.setenv("ARCADEDB_HOST", "my-arcade-host")
        cfg = load_config()
        assert cfg.rate_limit.enabled is False
        assert cfg.arcadedb.host == "my-arcade-host"

    def test_yaml_file_loaded(self, tmp_path, monkeypatch):
        from ravmem.config_loader import load_config
        cfg_file = tmp_path / "ravmem.yaml"
        cfg_file.write_text(
            "server:\n  port: 9999\nrate_limit:\n  enabled: false\n"
        )
        monkeypatch.setenv("RAVMEM_CONFIG", str(cfg_file))
        cfg = load_config()
        assert cfg.server.port == 9999
        assert cfg.rate_limit.enabled is False

    def test_env_wins_over_yaml(self, tmp_path, monkeypatch):
        from ravmem.config_loader import load_config
        cfg_file = tmp_path / "ravmem.yaml"
        cfg_file.write_text("arcadedb:\n  host: from-file\n")
        monkeypatch.setenv("RAVMEM_CONFIG", str(cfg_file))
        monkeypatch.setenv("ARCADEDB_HOST", "from-env")
        cfg = load_config()
        assert cfg.arcadedb.host == "from-env"

    def test_invalid_rate_limit_format_raises(self, tmp_path, monkeypatch):
        from ravmem.config_loader import load_config
        cfg_file = tmp_path / "ravmem.yaml"
        cfg_file.write_text("rate_limit:\n  limits:\n    read: '100/decade'\n")
        monkeypatch.setenv("RAVMEM_CONFIG", str(cfg_file))
        with pytest.raises(ValueError, match="Invalid ravmem config"):
            load_config()

    def test_redact_in_show(self, capsys, tmp_path, monkeypatch):
        """ravmem config show must redact sensitive fields."""
        from ravmem.cli.config_cmd import show_cmd
        from typer.testing import CliRunner
        from ravmem.cli.config_cmd import app

        runner = CliRunner()
        result = runner.invoke(app, ["show"])
        assert result.exit_code == 0
        assert "***REDACTED***" not in result.output or "password" in result.output


# ---------------------------------------------------------------------------
# Sliding window counter tests
# ---------------------------------------------------------------------------

class TestSlidingWindow:
    def test_allows_within_limit(self):
        from ravmem.server.rate_limit import _Window
        w = _Window(limit=5, window=60)
        for _ in range(5):
            assert not w.is_exceeded()
            w.add()

    def test_blocks_over_limit(self):
        from ravmem.server.rate_limit import _Window
        w = _Window(limit=3, window=60)
        for _ in range(3):
            w.add()
        assert w.is_exceeded()

    def test_remaining_counts(self):
        from ravmem.server.rate_limit import _Window
        w = _Window(limit=10, window=60)
        for _ in range(4):
            w.add()
        assert w.remaining() == 6

    def test_weighted_add(self):
        from ravmem.server.rate_limit import _Window
        w = _Window(limit=10, window=60)
        w.add(weight=5)
        assert w.remaining() == 5

    def test_eviction_after_window(self):
        from ravmem.server.rate_limit import _Window
        w = _Window(limit=3, window=1)  # 1s window
        for _ in range(3):
            w.add()
        assert w.is_exceeded()
        time.sleep(1.05)
        assert not w.is_exceeded()  # should have evicted


# ---------------------------------------------------------------------------
# Endpoint classification tests
# ---------------------------------------------------------------------------

class TestEndpointClassification:
    def test_auth_group(self):
        from ravmem.server.rate_limit import _classify_endpoint
        assert _classify_endpoint("POST", "/api/auth/tokens") == "auth"
        assert _classify_endpoint("POST", "/api/auth/users") == "auth"

    def test_mcp_group(self):
        from ravmem.server.rate_limit import _classify_endpoint
        assert _classify_endpoint("POST", "/mcp") == "mcp"
        assert _classify_endpoint("POST", "/api/knowledge/mcp") == "mcp"

    def test_index_group(self):
        from ravmem.server.rate_limit import _classify_endpoint
        assert _classify_endpoint("POST", "/api/projects/x/branches/main/index") == "index"
        assert _classify_endpoint("POST", "/api/projects/x/branches/main/reindex") == "index"

    def test_write_group(self):
        from ravmem.server.rate_limit import _classify_endpoint
        assert _classify_endpoint("POST", "/api/projects") == "write"
        assert _classify_endpoint("DELETE", "/api/projects/x") == "write"
        assert _classify_endpoint("PATCH", "/api/projects/x") == "write"

    def test_read_group(self):
        from ravmem.server.rate_limit import _classify_endpoint
        assert _classify_endpoint("GET", "/api/projects") == "read"
        assert _classify_endpoint("GET", "/health") == "read"


# ---------------------------------------------------------------------------
# Tier resolution tests
# ---------------------------------------------------------------------------

class TestTierResolution:
    def test_most_permissive_selects_highest(self):
        from ravmem.server.rate_limit import _most_permissive_tier
        assert _most_permissive_tier(["standard", "restricted"]) == "standard"
        assert _most_permissive_tier(["restricted", "high"]) == "high"
        assert _most_permissive_tier([]) == "standard"
        assert _most_permissive_tier(["unknown"]) == "standard"

    def test_tier_limits_parsed(self):
        from ravmem.server.rate_limit import _get_tier_limits
        from ravmem.config_loader import load_config
        cfg = load_config()
        count, window = _get_tier_limits("admin", "read", cfg)
        assert count == 5000
        assert window == 60  # min

        count, window = _get_tier_limits("restricted", "auth", cfg)
        assert count == 20
        assert window == 60


# ---------------------------------------------------------------------------
# Middleware integration test (no ArcadeDB required)
# ---------------------------------------------------------------------------

@pytest.fixture()
def rl_app():
    """Minimal FastAPI app with RateLimitMiddleware attached."""
    from fastapi import FastAPI
    from ravmem.server.rate_limit import RateLimitMiddleware

    # Use a very tight limit so tests don't have to send hundreds of requests
    with patch.dict(
        os.environ,
        {
            "RAVMEM_RATELIMIT_ENABLED": "true",
            "RAVMEM_RATELIMIT_READ": "3/min",
            "RAVMEM_RATELIMIT_AUTH": "2/min",
        },
    ):
        app = FastAPI()
        # reload config singleton for this test
        import ravmem.config_loader as cl
        cl._config = None

        app.add_middleware(RateLimitMiddleware)

        @app.get("/api/data")
        async def data():
            return {"ok": True}

        @app.post("/api/auth/tokens")
        async def auth():
            return {"token": "x"}

        yield TestClient(app, raise_server_exceptions=True)

    cl._config = None  # cleanup


class TestRateLimitMiddleware:
    def test_headers_present(self, rl_app):
        resp = rl_app.get("/api/data")
        assert resp.status_code == 200
        assert "X-RateLimit-Limit" in resp.headers
        assert "X-RateLimit-Remaining" in resp.headers
        assert "X-RateLimit-Reset" in resp.headers

    def test_429_after_limit(self, rl_app):
        # First 3 succeed, 4th is blocked
        for _ in range(3):
            r = rl_app.get("/api/data")
            assert r.status_code == 200
        r = rl_app.get("/api/data")
        assert r.status_code == 429
        assert "Retry-After" in r.headers

    def test_429_response_body(self, rl_app):
        for _ in range(3):
            rl_app.get("/api/data")
        r = rl_app.get("/api/data")
        assert r.json()["detail"] == "Too many requests — rate limit exceeded."

    def test_exempt_paths_not_limited(self, rl_app):
        # /health is exempt — should never get 429 regardless of config
        for _ in range(20):
            r = rl_app.get("/health")
            assert r.status_code != 429

    def test_remaining_decrements(self, rl_app):
        r1 = rl_app.get("/api/data")
        r2 = rl_app.get("/api/data")
        remaining1 = int(r1.headers["X-RateLimit-Remaining"])
        remaining2 = int(r2.headers["X-RateLimit-Remaining"])
        assert remaining2 == remaining1 - 1
