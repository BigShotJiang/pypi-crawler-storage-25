"""Tests for the storage layer — schema, GraphStore, VectorStore, MetaStore."""

import tempfile
from pathlib import Path

import numpy as np
import pytest

from ravmem.storage.meta import MetaStore
from ravmem.storage.schema import Cluster, Edge, File, Symbol
from ravmem.storage.vectors import VectorStore
from tests.fake_graph_store import FakeGraphStore


@pytest.fixture
def tmp_dir(tmp_path):
    return tmp_path


# ---------------------------------------------------------------------------
# FakeGraphStore — validates the in-memory test fixture behaves correctly
# ---------------------------------------------------------------------------

class TestFakeGraphStore:
    def test_upsert_and_get_symbol(self):
        gs = FakeGraphStore()
        sym = Symbol(
            id="abc123", name="my_func", kind="function",
            file="/repo/foo.py", line_start=10, line_end=20, lang="python"
        )
        gs.upsert_symbol(sym)
        result = gs.get_symbol("abc123")
        assert result is not None
        assert result.name == "my_func"
        assert result.kind == "function"

    def test_upsert_and_get_cluster(self):
        gs = FakeGraphStore()
        cluster = Cluster(id="c1", label="auth", cohesion_score=0.8, size=5)
        gs.upsert_cluster(cluster)
        result = gs.get_cluster("c1")
        assert result is not None
        assert result.label == "auth"

    def test_callers_and_callees(self):
        gs = FakeGraphStore()
        caller = Symbol(id="s1", name="caller_fn", kind="function",
                        file="/f.py", line_start=1, line_end=5, lang="python")
        callee = Symbol(id="s2", name="callee_fn", kind="function",
                        file="/f.py", line_start=10, line_end=15, lang="python")
        gs.upsert_symbols([caller, callee])
        gs.upsert_edge(Edge(src_id="s1", dst_id="s2", kind="calls", confidence=1.0))

        callers = gs.get_callers("s2", depth=1)
        callees = gs.get_callees("s1", depth=1)

        assert any(s.id == "s1" for s in callers)
        assert any(s.id == "s2" for s in callees)

    def test_get_full_graph(self):
        gs = FakeGraphStore()
        sym = Symbol(id="x1", name="foo", kind="function",
                     file="/f.py", line_start=1, line_end=3, lang="python")
        gs.upsert_symbol(sym)
        nodes, edges = gs.get_full_graph()
        assert any(n["id"] == "x1" for n in nodes)

    def test_docstring_roundtrip(self):
        gs = FakeGraphStore()
        sym = Symbol(
            id="ds1", name="get_user", kind="function",
            file="/repo/users.py", line_start=5, line_end=15, lang="python",
            docstring="Returns the user object",
        )
        gs.upsert_symbol(sym)
        result = gs.get_symbol("ds1")
        assert result is not None
        assert result.docstring == "Returns the user object"

    def test_delete_symbols_for_file(self):
        gs = FakeGraphStore()
        gs.upsert_symbols([
            Symbol(id="a", name="fn_a", kind="function", file="/a.py",
                   line_start=1, line_end=5, lang="python"),
            Symbol(id="b", name="fn_b", kind="function", file="/b.py",
                   line_start=1, line_end=5, lang="python"),
        ])
        n = gs.delete_symbols_for_file("/a.py")
        assert n == 1
        assert gs.get_symbol("a") is None
        assert gs.get_symbol("b") is not None

    def test_path_prefix_query(self):
        gs = FakeGraphStore()
        gs.upsert_symbols([
            Symbol(id="s1", name="f1", kind="function", file="/src/auth/login.py",
                   line_start=1, line_end=5, lang="python"),
            Symbol(id="s2", name="f2", kind="function", file="/src/utils/helper.py",
                   line_start=1, line_end=5, lang="python"),
        ])
        results = gs.get_symbols_for_path_prefix("/src/auth/")
        ids = [s.id for s in results]
        assert "s1" in ids and "s2" not in ids

    def test_initialize_schema_idempotent(self):
        gs = FakeGraphStore()
        gs.initialize_schema()
        gs.initialize_schema()  # should not raise


# ---------------------------------------------------------------------------
# VectorStore
# ---------------------------------------------------------------------------

class TestVectorStore:
    def test_add_and_search(self, tmp_dir):
        vs = VectorStore(tmp_dir / "vectors", dim=8)
        vs.initialize()

        embeddings = np.random.rand(3, 8).astype(np.float32)
        # Normalize
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
        ids = vs.add_symbols(["sym_a", "sym_b", "sym_c"], embeddings)
        assert len(ids) == 3

        query = embeddings[0]  # exact match for first
        results = vs.search(query, k=3)
        assert len(results) > 0
        # First result should be sym_a (distance ~0 for cosine on normalized vecs)
        assert results[0][0] == "sym_a"

    def test_save_and_reload(self, tmp_dir):
        vs = VectorStore(tmp_dir / "vectors", dim=8)
        vs.initialize()
        embs = np.random.rand(2, 8).astype(np.float32)
        vs.add_symbols(["s1", "s2"], embs)
        vs.save()

        vs2 = VectorStore(tmp_dir / "vectors", dim=8)
        vs2.initialize()
        assert vs2.count == 2


# ---------------------------------------------------------------------------
# MetaStore
# ---------------------------------------------------------------------------

class TestMetaStore:
    def test_register_and_get_repo(self, tmp_dir):
        ms = MetaStore(tmp_dir / "meta.db")
        ms.register_repo("repo1", "myrepo", "/path/to/repo", ["python"])
        repo = ms.get_repo("repo1")
        assert repo is not None
        assert repo["name"] == "myrepo"

    def test_job_lifecycle(self, tmp_dir):
        ms = MetaStore(tmp_dir / "meta.db")
        ms.register_repo("repo1", "myrepo", "/path", ["python"])
        job_id = ms.create_job("repo1", mode="full")
        assert job_id > 0
        ms.finish_job(job_id, "done")

    def test_centrality_cache(self, tmp_dir):
        ms = MetaStore(tmp_dir / "meta.db")
        scores = {"sym1": 0.9, "sym2": 0.3}
        ms.save_centrality("repo1", scores)
        loaded = ms.load_centrality("repo1")
        assert loaded["sym1"] == pytest.approx(0.9)
        assert loaded["sym2"] == pytest.approx(0.3)


# ---------------------------------------------------------------------------
# VectorStore incremental operations
# ---------------------------------------------------------------------------

class TestVectorStoreIncrementalOps:
    def test_remove_symbols_soft_deletes(self, tmp_dir):
        """remove_symbols marks items deleted; they no longer appear in search."""
        vs = VectorStore(tmp_dir / "vectors")
        vs.initialize()
        embs = np.random.rand(3, 384).astype(np.float32)
        embs = embs / np.linalg.norm(embs, axis=1, keepdims=True)
        vs.add_symbols(["a", "b", "c"], embs)

        removed = vs.remove_symbols(["b"])
        assert removed == 1
        assert vs.deleted_count == 1
        assert vs.live_count == 2
        assert vs.total_count == 3

        # "b" must not appear in search results; ask only for live_count items
        results = vs.search(embs[1], k=vs.live_count)
        returned_ids = [r[0] for r in results]
        assert "b" not in returned_ids

    def test_remove_symbols_skips_unknown_ids(self, tmp_dir):
        """remove_symbols silently skips IDs not in the index."""
        vs = VectorStore(tmp_dir / "vectors")
        vs.initialize()
        embs = np.random.rand(2, 384).astype(np.float32)
        vs.add_symbols(["x", "y"], embs)

        removed = vs.remove_symbols(["z_not_in_index"])
        assert removed == 0
        assert vs.deleted_count == 0

    def test_counts_persist_across_save_reload(self, tmp_dir):
        """deleted_count and live_count survive a save/reload cycle."""
        vs = VectorStore(tmp_dir / "vectors")
        vs.initialize()
        embs = np.random.rand(3, 384).astype(np.float32)
        embs = embs / np.linalg.norm(embs, axis=1, keepdims=True)
        vs.add_symbols(["p", "q", "r"], embs)
        vs.remove_symbols(["p"])
        vs.save()

        vs2 = VectorStore(tmp_dir / "vectors")
        vs2.initialize()
        assert vs2.deleted_count == 1
        assert vs2.live_count == 2
        assert "p" not in vs2._id_to_int
        assert "q" in vs2._id_to_int
        assert "r" in vs2._id_to_int

    def test_backward_compat_bare_list_ids_json(self, tmp_dir):
        """VectorStore loads an ids.json that is a bare list (pre-optimisation format)."""
        import json as _json
        vs = VectorStore(tmp_dir / "vectors")
        vs.initialize()
        embs = np.random.rand(2, 384).astype(np.float32)
        vs.add_symbols(["alpha", "beta"], embs)
        vs.save()

        # Overwrite ids.json with old bare-list format
        ids_path = tmp_dir / "vectors" / "ids.json"
        ids_path.write_text(_json.dumps(["alpha", "beta"]))

        vs2 = VectorStore(tmp_dir / "vectors")
        vs2.initialize()
        assert vs2.count == 2
        assert vs2.deleted_count == 0
        assert "alpha" in vs2._id_to_int
        assert "beta" in vs2._id_to_int

    def test_rebuild_resets_deleted_state(self, tmp_dir):
        """rebuild() clears all soft-delete accounting."""
        vs = VectorStore(tmp_dir / "vectors")
        vs.initialize()
        embs = np.random.rand(3, 384).astype(np.float32)
        embs = embs / np.linalg.norm(embs, axis=1, keepdims=True)
        vs.add_symbols(["a", "b", "c"], embs)
        vs.remove_symbols(["a", "b"])
        assert vs.deleted_count == 2

        new_embs = np.random.rand(2, 384).astype(np.float32)
        new_embs = new_embs / np.linalg.norm(new_embs, axis=1, keepdims=True)
        vs.rebuild(["x", "y"], new_embs)
        assert vs.deleted_count == 0
        assert vs.live_count == 2
        assert "a" not in vs._id_to_int
        assert "x" in vs._id_to_int


# ---------------------------------------------------------------------------
# Cluster ID prefixes
# ---------------------------------------------------------------------------

class TestClusterIdPrefixes:
    def test_fc_prefix_for_file_based(self):
        """run_incremental produces fc_ prefixed cluster IDs."""
        from ravmem.indexer.phase_cluster import run_incremental

        symbols = [
            Symbol(id="s1", name="fn1", kind="function",
                   file="/repo/utils.py", line_start=1, line_end=5, lang="python"),
            Symbol(id="s2", name="fn2", kind="function",
                   file="/repo/utils.py", line_start=6, line_end=10, lang="python"),
        ]
        clusters, bt_edges = run_incremental(symbols)

        assert len(clusters) == 1
        assert clusters[0].id.startswith("fc_")
        assert len(bt_edges) == 2
        assert all(e.dst_id == clusters[0].id for e in bt_edges)

    def test_lc_prefix_for_leiden(self):
        """run() with resolved call edges produces lc_ prefixed cluster IDs (Leiden)."""
        import ravmem.indexer.phase_cluster as pc
        from ravmem.indexer.phase_cluster import run

        if not pc._LEIDEN_AVAILABLE:
            pytest.skip("leidenalg not installed")

        symbols = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file=f"/repo/mod{i % 2}.py", line_start=i, line_end=i+1, lang="python")
            for i in range(6)
        ]
        edges = [
            Edge(src_id="s0", dst_id="s1", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s2", dst_id="s0", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s3", dst_id="s4", kind="calls", confidence=1.0, resolved=True),
        ]

        clusters, bt_edges = run(symbols, edges)

        # Leiden is available — all cluster IDs should start with lc_ (or be sub-clusters)
        base_ids = {c.id.split("_")[0] + "_" + c.id.split("_")[1]
                    if len(c.id.split("_")) > 2 else c.id
                    for c in clusters}
        assert all(cid.startswith("lc_") for cid in base_ids), \
            f"Expected lc_ IDs, got: {base_ids}"
        assert len(bt_edges) == len(symbols)

    def test_multi_file_produces_separate_clusters(self):
        """Symbols from different files get different fc_ cluster IDs in incremental."""
        from ravmem.indexer.phase_cluster import run_incremental

        symbols = [
            Symbol(id="a1", name="fn_a", kind="function",
                   file="/repo/auth.py", line_start=1, line_end=5, lang="python"),
            Symbol(id="b1", name="fn_b", kind="function",
                   file="/repo/billing.py", line_start=1, line_end=5, lang="python"),
        ]
        clusters, _ = run_incremental(symbols)

        assert len(clusters) == 2
        ids = [c.id for c in clusters]
        assert ids[0] != ids[1]
        assert all(c.id.startswith("fc_") for c in clusters)

    def test_orphan_cluster_cleanup(self):
        """delete_orphan_clusters() removes clusters with no symbol members."""
        gs = FakeGraphStore()
        c_active = Cluster(id="c_active", label="active", cohesion_score=1.0, size=1)
        c_orphan = Cluster(id="c_orphan", label="orphan", cohesion_score=0.0, size=0)
        gs.upsert_clusters([c_active, c_orphan])

        sym = Symbol(id="s1", name="fn", kind="function",
                     file="/f.py", line_start=1, line_end=5, lang="python",
                     cluster_id="c_active")
        gs.upsert_symbol(sym)

        gs.delete_orphan_clusters()

        assert gs.get_cluster("c_active") is not None
        assert gs.get_cluster("c_orphan") is None

    def test_leiden_ids_stable_across_identical_graphs(self):
        """Leiden produces same cluster IDs on two identical symbol/edge sets."""
        import ravmem.indexer.phase_cluster as pc
        from ravmem.indexer.phase_cluster import run

        if not pc._LEIDEN_AVAILABLE:
            pytest.skip("leidenalg not installed")

        def _make():
            syms = [
                Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                       file="/repo/app.py", line_start=i, line_end=i+1, lang="python")
                for i in range(5)
            ]
            return syms

        edges = [
            Edge(src_id="s0", dst_id="s1", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s2", dst_id="s1", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s3", dst_id="s4", kind="calls", confidence=1.0, resolved=True),
        ]

        syms_a = _make()
        syms_b = _make()
        clusters_a, _ = run(syms_a, edges)
        clusters_b, _ = run(syms_b, edges)

        assert {c.id for c in clusters_a} == {c.id for c in clusters_b}
