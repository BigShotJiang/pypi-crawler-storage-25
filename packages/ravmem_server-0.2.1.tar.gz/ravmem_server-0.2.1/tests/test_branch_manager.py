"""Unit tests for BranchManager."""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

from ravmem.server.branch_manager import BranchManager
from ravmem.server.registry import ServerRegistry


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


@pytest.fixture
def registry(tmp_dir):
    reg = ServerRegistry(tmp_dir / "server.db")
    yield reg
    reg.close()


@pytest.fixture
def manager(tmp_dir, registry):
    return BranchManager(tmp_dir, registry)


@pytest.fixture
def project(tmp_dir, registry):
    """Register a project in the registry and return its dict."""
    repo_path = tmp_dir / "myrepo"
    repo_path.mkdir(parents=True, exist_ok=True)
    return registry.create_project(
        "proj1", "My Project", str(repo_path), default_branch="main"
    )


# ---------------------------------------------------------------------------
# 1. Path helpers
# ---------------------------------------------------------------------------

class TestPathHelpers:
    def test_project_dir(self, tmp_dir, manager):
        assert manager.project_dir("proj1") == tmp_dir / "repos" / "proj1"

    def test_repo_path_with_registered_project(self, tmp_dir, manager, project):
        expected = Path(project["repo_path"])
        assert manager.repo_path("proj1") == expected

    def test_repo_path_without_registered_project(self, tmp_dir, manager):
        # Falls back to <project_dir>/repo when not registered
        assert manager.repo_path("unknown") == tmp_dir / "repos" / "unknown" / "repo"

    def test_branch_index_dir_simple(self, tmp_dir, manager):
        result = manager.branch_index_dir("proj1", "main")
        assert result == tmp_dir / "repos" / "proj1" / "branches" / "main"

    def test_branch_index_dir_sanitizes_slashes(self, tmp_dir, manager):
        result = manager.branch_index_dir("proj1", "feature/foo")
        assert result == tmp_dir / "repos" / "proj1" / "branches" / "feature__foo"

    def test_branch_index_dir_sanitizes_backslashes(self, tmp_dir, manager):
        result = manager.branch_index_dir("proj1", "feature\\bar")
        assert result == tmp_dir / "repos" / "proj1" / "branches" / "feature__bar"

    def test_branch_index_dir_nested_feature_branch(self, tmp_dir, manager):
        result = manager.branch_index_dir("proj1", "release/v2/candidate")
        assert result == tmp_dir / "repos" / "proj1" / "branches" / "release__v2__candidate"


# ---------------------------------------------------------------------------
# 2. compute_divergence
# ---------------------------------------------------------------------------

class TestComputeDivergence:
    """Tests for divergence detection logic."""

    def test_never_indexed_calls_divergence_vs_base(self, manager, project):
        """Branch with no record → delegates to _divergence_vs_base."""
        with patch.object(manager, "_divergence_vs_base", return_value={
            "changed_files": 5, "total_files": 10, "ratio": 0.5,
            "recommend": "incremental", "force_push": False,
        }) as mock_dvb:
            result = manager.compute_divergence("proj1", "feature/new")
            mock_dvb.assert_called_once_with("proj1", "feature/new", None)
        assert result["recommend"] == "incremental"

    def test_empty_status_calls_divergence_vs_base(self, manager, project, registry):
        """Branch record with status='empty' → delegates to _divergence_vs_base."""
        index_dir = manager.branch_index_dir("proj1", "feature/x")
        registry.register_branch("proj1", "feature/x", str(index_dir))
        # status defaults to 'empty'

        with patch.object(manager, "_divergence_vs_base", return_value={
            "changed_files": 0, "total_files": 0, "ratio": 1.0,
            "recommend": "full", "force_push": False,
        }) as mock_dvb:
            result = manager.compute_divergence("proj1", "feature/x")
            mock_dvb.assert_called_once()
        assert result["recommend"] == "full"

    def test_same_commit_returns_skip(self, manager, project, registry):
        """When last_commit == current HEAD, returns skip."""
        index_dir = manager.branch_index_dir("proj1", "main")
        registry.register_branch("proj1", "main", str(index_dir))
        registry.update_branch_status(
            "proj1", "main",
            status="ready",
            last_commit="abc123",
            symbol_count=100,
        )

        with patch("ravmem.server.branch_manager.git_ops") as mock_git:
            mock_git.get_head_commit.return_value = "abc123"
            result = manager.compute_divergence("proj1", "main")

        assert result["recommend"] == "skip"
        assert result["ratio"] == 0.0
        assert result["force_push"] is False

    def test_force_push_detected(self, manager, project, registry):
        """When last_commit is not an ancestor → force_push=True, recommend=full."""
        index_dir = manager.branch_index_dir("proj1", "main")
        registry.register_branch("proj1", "main", str(index_dir))
        registry.update_branch_status(
            "proj1", "main",
            status="ready",
            last_commit="old_sha",
            symbol_count=50,
        )

        with patch("ravmem.server.branch_manager.git_ops") as mock_git:
            mock_git.GitError = Exception
            mock_git.get_head_commit.return_value = "new_sha"
            mock_git.is_ancestor.return_value = False  # force push!
            result = manager.compute_divergence("proj1", "main")

        assert result["recommend"] == "full"
        assert result["force_push"] is True

    def test_small_diff_recommends_incremental(self, manager, project, registry):
        """Small diff (≤30% files changed) → incremental."""
        index_dir = manager.branch_index_dir("proj1", "main")
        registry.register_branch("proj1", "main", str(index_dir))
        registry.update_branch_status(
            "proj1", "main",
            status="ready",
            last_commit="sha_old",
            symbol_count=100,  # total used as denominator
        )

        with patch("ravmem.server.branch_manager.git_ops") as mock_git:
            mock_git.GitError = Exception
            mock_git.get_head_commit.return_value = "sha_new"
            mock_git.is_ancestor.return_value = True
            # 10 modified + 5 deleted = 15 changed out of 100 = 15%
            mock_git.diff_name_status.return_value = (
                {f"file{i}.py" for i in range(10)},
                {f"del{i}.py" for i in range(5)},
            )
            result = manager.compute_divergence("proj1", "main")

        assert result["recommend"] == "incremental"
        assert result["force_push"] is False
        assert result["changed_files"] == 15

    def test_large_diff_recommends_full(self, manager, project, registry):
        """Large diff (>60% files changed) → full reindex."""
        index_dir = manager.branch_index_dir("proj1", "main")
        registry.register_branch("proj1", "main", str(index_dir))
        registry.update_branch_status(
            "proj1", "main",
            status="ready",
            last_commit="sha_old",
            symbol_count=100,
        )

        with patch("ravmem.server.branch_manager.git_ops") as mock_git:
            mock_git.GitError = Exception
            mock_git.get_head_commit.return_value = "sha_new"
            mock_git.is_ancestor.return_value = True
            # 70 modified = 70% → full
            mock_git.diff_name_status.return_value = (
                {f"file{i}.py" for i in range(70)},
                set(),
            )
            result = manager.compute_divergence("proj1", "main")

        assert result["recommend"] == "full"
        assert result["force_push"] is False

    def test_no_base_branch_indexed_returns_full(self, manager, project, registry):
        """When base branch has no ready index → recommend full."""
        # The branch itself is not indexed; base branch 'main' is also not ready
        # (only registered as 'empty')
        index_dir = manager.branch_index_dir("proj1", "main")
        registry.register_branch("proj1", "main", str(index_dir))
        # Leave status as 'empty' (not 'ready')

        result = manager.compute_divergence("proj1", "feature/x", base_branch="main")
        assert result["recommend"] == "full"

    def test_divergence_vs_base_no_base_record(self, manager, project):
        """No base branch record at all → full."""
        result = manager.compute_divergence("proj1", "feature/new", base_branch="nonexistent")
        assert result["recommend"] == "full"

    def test_git_error_on_get_head_returns_full(self, manager, project, registry):
        """GitError when reading current HEAD → recommend full."""
        from ravmem.server.git_ops import GitError

        index_dir = manager.branch_index_dir("proj1", "main")
        registry.register_branch("proj1", "main", str(index_dir))
        registry.update_branch_status(
            "proj1", "main",
            status="ready",
            last_commit="sha_old",
            symbol_count=50,
        )

        with patch("ravmem.server.branch_manager.git_ops") as mock_git:
            mock_git.GitError = GitError
            mock_git.get_head_commit.side_effect = GitError("not a git repo")
            result = manager.compute_divergence("proj1", "main")

        assert result["recommend"] == "full"


# ---------------------------------------------------------------------------
# 3. index_branch (async)
# ---------------------------------------------------------------------------

class TestIndexBranch:
    """Tests for index_branch async orchestration."""

    @pytest.mark.asyncio
    async def test_duplicate_job_returns_same_id(self, manager, project, registry):
        """If an active job exists for the branch, return its id without creating a new one."""
        # Manually insert an active job
        registry.register_branch("proj1", "main", str(manager.branch_index_dir("proj1", "main")))
        existing_id = registry.create_job("proj1", "main", "full")
        # Leave status as 'queued' so get_active_job will find it

        with patch("asyncio.ensure_future") as mock_future:
            returned_id = await manager.index_branch("proj1", "main", mode="full")

        assert returned_id == existing_id
        mock_future.assert_not_called()

    @pytest.mark.asyncio
    async def test_unknown_project_raises_value_error(self, manager):
        """Calling index_branch for a non-existent project raises ValueError."""
        with pytest.raises(ValueError, match="Unknown project"):
            await manager.index_branch("nonexistent_proj", "main")

    @pytest.mark.asyncio
    async def test_returns_job_id_integer(self, manager, project):
        """index_branch should return an integer job_id."""
        with patch("asyncio.ensure_future"), \
             patch("ravmem.server.branch_manager.git_ops") as mock_git:
            mock_git.get_head_commit.return_value = "sha_head"
            mock_git.is_ancestor.return_value = True
            mock_git.diff_name_status.return_value = (set(), set())

            job_id = await manager.index_branch("proj1", "main", mode="full")

        assert isinstance(job_id, int)
        assert job_id > 0

    @pytest.mark.asyncio
    async def test_mode_auto_triggers_divergence_detection(self, manager, project):
        """mode='auto' calls compute_divergence to decide indexing strategy."""
        with patch("asyncio.ensure_future"), \
             patch.object(manager, "compute_divergence", return_value={
                 "recommend": "incremental",
                 "force_push": False,
                 "changed_files": 5,
                 "total_files": 100,
                 "ratio": 0.05,
             }) as mock_div:
            job_id = await manager.index_branch("proj1", "main", mode="auto")

        mock_div.assert_called_once_with("proj1", "main")
        assert isinstance(job_id, int)

    @pytest.mark.asyncio
    async def test_mode_auto_skip_creates_done_job(self, manager, project):
        """When divergence recommends 'skip', a completed job is still returned."""
        with patch("asyncio.ensure_future") as mock_future, \
             patch.object(manager, "compute_divergence", return_value={
                 "recommend": "skip",
                 "force_push": False,
                 "changed_files": 0,
                 "total_files": 100,
                 "ratio": 0.0,
             }):
            job_id = await manager.index_branch("proj1", "main", mode="auto")

        # ensure_future should NOT be called for skip
        mock_future.assert_not_called()
        assert isinstance(job_id, int)

        # The job should be recorded as done
        job = manager._registry.get_job(job_id)
        assert job is not None
        assert job["status"] == "done"

    @pytest.mark.asyncio
    async def test_full_mode_skips_divergence(self, manager, project):
        """Explicit mode='full' bypasses divergence detection."""
        with patch("asyncio.ensure_future"), \
             patch.object(manager, "compute_divergence") as mock_div:
            job_id = await manager.index_branch("proj1", "main", mode="full")

        mock_div.assert_not_called()
        assert isinstance(job_id, int)

    @pytest.mark.asyncio
    async def test_registers_branch_in_registry(self, manager, project):
        """index_branch registers the branch record before launching the job."""
        with patch("asyncio.ensure_future"):
            await manager.index_branch("proj1", "main", mode="full")

        branch_rec = manager._registry.get_branch("proj1", "main")
        assert branch_rec is not None
        assert branch_rec["branch"] == "main"

    @pytest.mark.asyncio
    async def test_index_dir_created(self, manager, project):
        """branch_index_dir is created on disk when index_branch is called."""
        with patch("asyncio.ensure_future"):
            await manager.index_branch("proj1", "feature/abc", mode="full")

        index_dir = manager.branch_index_dir("proj1", "feature/abc")
        assert index_dir.exists()

    @pytest.mark.asyncio
    async def test_creates_job_in_registry(self, manager, project):
        """A job record is created in the registry."""
        with patch("asyncio.ensure_future"):
            job_id = await manager.index_branch("proj1", "main", mode="full")

        job = manager._registry.get_job(job_id)
        assert job is not None
        assert job["project_id"] == "proj1"
        assert job["branch"] == "main"
        assert job["mode"] == "full"
