"""Tests for the indexing pipeline — structure, parse, resolve, cluster, embed."""

import subprocess
import textwrap
import tempfile
from pathlib import Path

import pytest

from ravmem.storage.schema import Edge, File, Symbol


# ---------------------------------------------------------------------------
# Phase 1 — Structure
# ---------------------------------------------------------------------------

class TestPhaseStructure:
    def test_walks_python_files(self, tmp_path):
        (tmp_path / "app.py").write_text("def hello(): pass")
        (tmp_path / "main.go").write_text("package main")
        (tmp_path / "README.md").write_text("# readme")

        from ravmem.indexer.phase_structure import run
        files = run(tmp_path, langs=["python"])

        py_files = [f for f in files if f.lang == "python"]
        go_files = [f for f in files if f.lang == "go"]
        assert len(py_files) == 1
        assert len(go_files) == 0

    def test_ignores_node_modules(self, tmp_path):
        (tmp_path / "node_modules").mkdir()
        (tmp_path / "node_modules" / "pkg.js").write_text("module.exports = {}")
        (tmp_path / "app.py").write_text("x = 1")

        from ravmem.indexer.phase_structure import run
        files = run(tmp_path)
        assert all("/node_modules/" not in f.path for f in files)


# ---------------------------------------------------------------------------
# Phase 2 — Parse
# ---------------------------------------------------------------------------

class TestPhaseParse:
    def test_extracts_python_functions(self, tmp_path):
        src = textwrap.dedent("""\
            def foo():
                pass

            class Bar:
                def baz(self):
                    pass
        """)
        py_file = tmp_path / "sample.py"
        py_file.write_text(src)

        files = [File(path=str(py_file), lang="python", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)

        names = [s.name for s in symbols]
        assert "foo" in names
        assert "Bar" in names
        assert any("baz" in n for n in names)

    def test_contains_edges_created(self, tmp_path):
        py_file = tmp_path / "f.py"
        py_file.write_text("def alpha(): pass")

        files = [File(path=str(py_file), lang="python", size_kb=0.05, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)

        contains_edges = [e for e in edges if e.kind == "contains"]
        assert len(contains_edges) == len(symbols)

    def test_arrow_functions_extracted_js(self, tmp_path):
        """Arrow function components and async handlers are extracted from .js files."""
        src = textwrap.dedent("""\
            const Login = () => {
                return null;
            };

            const handleSubmit = async (data) => {
                return data;
            };

            export default Login;
        """)
        js_file = tmp_path / "components.js"
        js_file.write_text(src)

        files = [File(path=str(js_file), lang="javascript", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)

        names = [s.name for s in symbols]
        assert "Login" in names, f"Expected 'Login' in symbols, got: {names}"
        assert "handleSubmit" in names, f"Expected 'handleSubmit' in symbols, got: {names}"

    def test_arrow_functions_line_numbers_js(self, tmp_path):
        """Arrow function symbols have correct line_start values."""
        src = textwrap.dedent("""\
            const Alpha = () => {
                return 1;
            };

            const Beta = (x) => x * 2;
        """)
        js_file = tmp_path / "funcs.js"
        js_file.write_text(src)

        files = [File(path=str(js_file), lang="javascript", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)

        by_name = {s.name: s for s in symbols}
        assert "Alpha" in by_name
        assert by_name["Alpha"].line_start == 1
        assert "Beta" in by_name
        assert by_name["Beta"].line_start == 5

    def test_arrow_functions_extracted_ts(self, tmp_path):
        """Arrow function components are extracted from .ts files."""
        src = textwrap.dedent("""\
            const MyComponent = () => {
                return null;
            };

            export const fetchData = async (url: string) => {
                return fetch(url);
            };
        """)
        ts_file = tmp_path / "app.ts"
        ts_file.write_text(src)

        files = [File(path=str(ts_file), lang="typescript", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)

        names = [s.name for s in symbols]
        assert "MyComponent" in names, f"Expected 'MyComponent' in symbols, got: {names}"
        assert "fetchData" in names, f"Expected 'fetchData' in symbols, got: {names}"

    def test_function_expression_extracted(self, tmp_path):
        """Regular function expressions assigned to variables are extracted."""
        src = textwrap.dedent("""\
            const login = function(user) {
                return user;
            };
        """)
        js_file = tmp_path / "auth.js"
        js_file.write_text(src)

        files = [File(path=str(js_file), lang="javascript", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)

        names = [s.name for s in symbols]
        assert "login" in names, f"Expected 'login' in symbols, got: {names}"

    def test_exported_arrow_function_extracted(self, tmp_path):
        """Exported arrow functions (export const foo = () => {}) are extracted."""
        src = textwrap.dedent("""\
            export const handleLogin = async (req, res) => {
                return res.ok;
            };
        """)
        js_file = tmp_path / "handlers.js"
        js_file.write_text(src)

        files = [File(path=str(js_file), lang="javascript", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)

        names = [s.name for s in symbols]
        assert "handleLogin" in names, f"Expected 'handleLogin' in symbols, got: {names}"

    def test_anonymous_arrow_functions_not_extracted(self, tmp_path):
        """Anonymous arrow functions used as callbacks are NOT extracted as top-level symbols."""
        src = textwrap.dedent("""\
            const items = [1, 2, 3];
            const doubled = items.map((x) => x * 2);
            const filtered = items.filter((x) => x > 1);
        """)
        js_file = tmp_path / "utils.js"
        js_file.write_text(src)

        files = [File(path=str(js_file), lang="javascript", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)

        # doubled and filtered are const identifiers whose values are
        # call expressions (not arrow_functions directly), so should not appear.
        names = [s.name for s in symbols]
        assert "doubled" not in names
        assert "filtered" not in names

    def test_existing_function_declaration_still_extracted(self, tmp_path):
        """Existing function_declaration extraction continues to work alongside new patterns."""
        src = textwrap.dedent("""\
            function greet(name) {
                return 'hello ' + name;
            }

            const farewell = (name) => 'bye ' + name;
        """)
        js_file = tmp_path / "greet.js"
        js_file.write_text(src)

        files = [File(path=str(js_file), lang="javascript", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)

        names = [s.name for s in symbols]
        assert "greet" in names, f"Expected 'greet' in symbols, got: {names}"
        assert "farewell" in names, f"Expected 'farewell' in symbols, got: {names}"


# ---------------------------------------------------------------------------
# Phase 3 — Resolve (JS/TS call edges)
# ---------------------------------------------------------------------------

class TestPhaseResolveJSTS:
    def test_js_call_resolution_cross_file(self, tmp_path):
        """A call in file2.js to a function defined in file1.js produces a calls edge."""
        from ravmem.indexer import phase_parse, phase_resolve
        from ravmem.storage.schema import File

        file1 = tmp_path / "auth.js"
        file1.write_text(textwrap.dedent("""\
            function handleLogin(user) {
              return user;
            }
        """))

        file2 = tmp_path / "main.js"
        file2.write_text(textwrap.dedent("""\
            function bootstrap() {
              handleLogin({ name: 'alice' });
            }
        """))

        files = [
            File(path=str(file1), lang="javascript", size_kb=0.1, checksum=""),
            File(path=str(file2), lang="javascript", size_kb=0.1, checksum=""),
        ]
        symbols, _contains = phase_parse.run(files)

        names = [s.name for s in symbols]
        assert "handleLogin" in names, f"handleLogin not found in {names}"
        assert "bootstrap" in names, f"bootstrap not found in {names}"

        edges = phase_resolve.run(files, symbols, tmp_path)
        calls_edges = [e for e in edges if e.kind == "calls"]

        handle_login_sym = next(s for s in symbols if s.name == "handleLogin")
        bootstrap_sym = next(s for s in symbols if s.name == "bootstrap")

        assert any(
            e.src_id == bootstrap_sym.id and e.dst_id == handle_login_sym.id
            for e in calls_edges
        ), (
            f"Expected calls edge {bootstrap_sym.id} -> {handle_login_sym.id}. "
            f"Got calls edges: {[(e.src_id, e.dst_id) for e in calls_edges]}"
        )

    def test_ts_call_resolution_cross_file(self, tmp_path):
        """A TypeScript function calling another function in a different file creates an edge."""
        from ravmem.indexer import phase_parse, phase_resolve
        from ravmem.storage.schema import File

        file1 = tmp_path / "utils.ts"
        file1.write_text(textwrap.dedent("""\
            export function formatUser(user: any): string {
              return user.name;
            }
        """))

        file2 = tmp_path / "controller.ts"
        file2.write_text(textwrap.dedent("""\
            function renderProfile(user: any) {
              const label = formatUser(user);
              return label;
            }
        """))

        files = [
            File(path=str(file1), lang="typescript", size_kb=0.1, checksum=""),
            File(path=str(file2), lang="typescript", size_kb=0.1, checksum=""),
        ]
        symbols, _contains = phase_parse.run(files)

        names = [s.name for s in symbols]
        assert "formatUser" in names
        assert "renderProfile" in names

        edges = phase_resolve.run(files, symbols, tmp_path)
        calls_edges = [e for e in edges if e.kind == "calls"]

        format_sym = next(s for s in symbols if s.name == "formatUser")
        render_sym = next(s for s in symbols if s.name == "renderProfile")

        assert any(
            e.src_id == render_sym.id and e.dst_id == format_sym.id
            for e in calls_edges
        ), (
            f"Expected calls edge {render_sym.id} -> {format_sym.id}. "
            f"Got: {[(e.src_id, e.dst_id) for e in calls_edges]}"
        )

    def test_js_builtin_calls_not_resolved(self, tmp_path):
        """console.log and JSON.parse should NOT produce calls edges."""
        from ravmem.indexer import phase_parse, phase_resolve
        from ravmem.storage.schema import File

        src_file = tmp_path / "noisy.js"
        src_file.write_text(textwrap.dedent("""\
            function doSomething() {
              console.log('hello');
              const x = JSON.parse('{}');
              setTimeout(doSomething, 1000);
            }
        """))

        files = [File(path=str(src_file), lang="javascript", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)

        calls_edges = [e for e in edges if e.kind == "calls"]
        # No cross-symbol calls edges (all callees are built-ins or absent from index)
        assert calls_edges == [], f"Unexpected calls edges: {calls_edges}"

    def test_js_new_expression_resolved(self, tmp_path):
        """new MyClass() in one JS file creates a calls edge to MyClass in another file."""
        from ravmem.indexer import phase_parse, phase_resolve
        from ravmem.storage.schema import File

        file1 = tmp_path / "myclass.js"
        file1.write_text(textwrap.dedent("""\
            class MyClass {
              constructor() {}
            }
        """))

        file2 = tmp_path / "factory.js"
        file2.write_text(textwrap.dedent("""\
            function createInstance() {
              return new MyClass();
            }
        """))

        files = [
            File(path=str(file1), lang="javascript", size_kb=0.1, checksum=""),
            File(path=str(file2), lang="javascript", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        names = [s.name for s in symbols]
        assert "MyClass" in names

        edges = phase_resolve.run(files, symbols, tmp_path)
        calls_edges = [e for e in edges if e.kind == "calls"]

        myclass_sym = next(s for s in symbols if s.name == "MyClass")
        create_sym = next(s for s in symbols if s.name == "createInstance")

        assert any(
            e.src_id == create_sym.id and e.dst_id == myclass_sym.id
            for e in calls_edges
        ), (
            f"Expected new MyClass() edge. "
            f"Got: {[(e.src_id, e.dst_id) for e in calls_edges]}"
        )


# ---------------------------------------------------------------------------
# Phase 4 — Cluster
# ---------------------------------------------------------------------------

class TestPhaseCluster:
    def test_produces_clusters_and_belongs_to_edges(self):
        symbols = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file="/f.py", line_start=i, line_end=i+1, lang="python")
            for i in range(4)
        ]
        edges = [
            Edge(src_id="s0", dst_id="s1", kind="calls", confidence=1.0),
            Edge(src_id="s2", dst_id="s3", kind="calls", confidence=1.0),
        ]

        from ravmem.indexer.phase_cluster import run
        clusters, bt_edges = run(symbols, edges)

        assert len(clusters) >= 1
        assert all(e.kind == "belongs_to" for e in bt_edges)
        assert len(bt_edges) == len(symbols)

    def test_full_index_cluster_ids_stable_across_runs(self):
        """Two identical full-index runs produce identical cluster IDs."""
        symbols_a = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file="/repo/auth.py", line_start=i, line_end=i+1, lang="python")
            for i in range(6)
        ]
        symbols_b = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file="/repo/auth.py", line_start=i, line_end=i+1, lang="python")
            for i in range(6)
        ]
        edges = [
            Edge(src_id="s0", dst_id="s1", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s2", dst_id="s1", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s3", dst_id="s4", kind="calls", confidence=1.0, resolved=True),
        ]

        from ravmem.indexer.phase_cluster import run
        clusters_a, _ = run(symbols_a, edges)
        clusters_b, _ = run(symbols_b, edges)

        ids_a = {c.id for c in clusters_a}
        ids_b = {c.id for c in clusters_b}
        assert ids_a == ids_b, f"Cluster IDs differ between runs: {ids_a} vs {ids_b}"

    def test_incremental_cluster_ids_stable(self):
        """run_incremental always produces the same cluster ID for the same file path."""
        from ravmem.indexer.phase_cluster import run_incremental, _stable_file_cluster_id

        sym = Symbol(id="s1", name="fn1", kind="function",
                     file="/repo/utils.py", line_start=1, line_end=5, lang="python")
        expected_id, _ = _stable_file_cluster_id("/repo/utils.py")

        clusters1, _ = run_incremental([sym])
        sym.cluster_id = ""  # reset
        clusters2, _ = run_incremental([sym])

        assert clusters1[0].id == clusters2[0].id == expected_id

    def test_incremental_does_not_fetch_all_symbols(self):
        """run_incremental accepts only changed symbols — no graph-wide fetch needed."""
        from ravmem.indexer.phase_cluster import run_incremental

        changed = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file="/repo/changed.py", line_start=i, line_end=i+1, lang="python")
            for i in range(5)
        ]
        clusters, bt_edges = run_incremental(changed)
        # All symbols get a cluster; no exception raised without a graph store
        assert len(bt_edges) == len(changed)
        assert all(s.cluster_id.startswith("fc_") for s in changed)

    def test_hub_symbol_cluster_size_bounded(self):
        """A single hub symbol called by 300 others produces no cluster > CLUSTER_MAX_SIZE."""
        from ravmem.config import CLUSTER_MAX_SIZE
        from ravmem.indexer.phase_cluster import run

        hub = Symbol(id="hub", name="hub_fn", kind="function",
                     file="/repo/hub.py", line_start=1, line_end=2, lang="python")
        callers = [
            Symbol(id=f"c{i}", name=f"caller{i}", kind="function",
                   file=f"/repo/file{i % 10}.py", line_start=i, line_end=i+1, lang="python")
            for i in range(300)
        ]
        symbols = [hub] + callers
        edges = [
            Edge(src_id=f"c{i}", dst_id="hub", kind="calls", confidence=1.0, resolved=True)
            for i in range(300)
        ]

        clusters, bt_edges = run(symbols, edges)

        assert all(c.size <= CLUSTER_MAX_SIZE for c in clusters), \
            f"Cluster too large: {max(c.size for c in clusters)}"
        assert len(bt_edges) == len(symbols)

    def test_file_based_init_py_uses_directory_cluster(self):
        """__init__.py symbols are clustered under the parent directory, not the file."""
        from ravmem.indexer.phase_cluster import run_incremental, _stable_file_cluster_id

        init_sym = Symbol(id="s1", name="MyClass", kind="class",
                          file="/repo/auth/__init__.py", line_start=1, line_end=5, lang="python")
        clusters, _ = run_incremental([init_sym])

        expected_id, _ = _stable_file_cluster_id("/repo/auth/__init__.py")
        assert init_sym.cluster_id == expected_id
        assert expected_id.startswith("fc_")
        # Label should be the directory name, not "__init__"
        assert clusters[0].label == "auth"

    def test_full_index_fallback_when_no_call_edges(self):
        """Full index with zero resolved call edges falls back to file-based (fc_ IDs)."""
        from ravmem.indexer.phase_cluster import run

        symbols = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file="/repo/config.py", line_start=i, line_end=i+1, lang="python")
            for i in range(4)
        ]
        # Only unresolved edges — should trigger file-based fallback
        edges = [Edge(src_id="s0", dst_id="s1", kind="calls", confidence=0.5, resolved=False)]

        clusters, bt_edges = run(symbols, edges)

        assert all(c.id.startswith("fc_") for c in clusters)
        assert len(bt_edges) == len(symbols)

    def test_leiden_not_installed_falls_back_gracefully(self):
        """When _LEIDEN_AVAILABLE is False, full index uses Louvain (c_ prefix)."""
        import ravmem.indexer.phase_cluster as pc

        symbols = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file="/repo/app.py", line_start=i, line_end=i+1, lang="python")
            for i in range(4)
        ]
        edges = [
            Edge(src_id="s0", dst_id="s1", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s2", dst_id="s3", kind="calls", confidence=1.0, resolved=True),
        ]

        orig = pc._LEIDEN_AVAILABLE
        try:
            pc._LEIDEN_AVAILABLE = False
            clusters, bt_edges = pc.run(symbols, edges)
        finally:
            pc._LEIDEN_AVAILABLE = orig

        # Louvain produces c_ prefix IDs
        assert len(clusters) >= 1
        assert len(bt_edges) == len(symbols)
        assert all(c.id.startswith("c_") for c in clusters)

    def test_full_fallback_to_file_based_when_no_algos(self):
        """When both leidenalg and python-louvain are unavailable, uses file-based."""
        import ravmem.indexer.phase_cluster as pc

        symbols = [
            Symbol(id=f"s{i}", name=f"fn{i}", kind="function",
                   file="/repo/core.py", line_start=i, line_end=i+1, lang="python")
            for i in range(4)
        ]
        edges = [
            Edge(src_id="s0", dst_id="s1", kind="calls", confidence=1.0, resolved=True),
            Edge(src_id="s2", dst_id="s3", kind="calls", confidence=1.0, resolved=True),
        ]

        orig_leiden = pc._LEIDEN_AVAILABLE
        orig_louvain = pc._run_louvain

        def _louvain_raises(*a, **kw):
            raise ImportError("no louvain")

        try:
            pc._LEIDEN_AVAILABLE = False
            pc._run_louvain = _louvain_raises
            clusters, bt_edges = pc.run(symbols, edges)
        finally:
            pc._LEIDEN_AVAILABLE = orig_leiden
            pc._run_louvain = orig_louvain

        assert all(c.id.startswith("fc_") for c in clusters)
        assert len(bt_edges) == len(symbols)


# ---------------------------------------------------------------------------
# Incremental Indexing
# ---------------------------------------------------------------------------

def _git_init(repo: Path) -> None:
    """Initialize a git repo and commit all files."""
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"],
                   cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test"],
                   cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", "init"],
                   cwd=repo, check=True, capture_output=True)


class TestIncrementalIndexing:
    def test_incremental_updates_modified_file(self, tmp_path):
        """Modified file's old symbols are removed and new ones appear."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        # Set up repo with one Python file
        (tmp_path / "app.py").write_text("def old_function(): pass\n")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        old_names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "old_function" in old_names

        # Modify the file and commit
        (tmp_path / "app.py").write_text("def new_function(): pass\n")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "update"],
                       cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        new_names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "new_function" in new_names
        assert "old_function" not in new_names

    def test_incremental_handles_deleted_file(self, tmp_path):
        """Deleted file's symbols are removed from the graph."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "keep.py").write_text("def keep_fn(): pass\n")
        (tmp_path / "remove.py").write_text("def remove_fn(): pass\n")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        all_names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "remove_fn" in all_names

        # Delete the file and commit
        subprocess.run(["git", "rm", "remove.py"],
                       cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "delete"],
                       cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        remaining = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "keep_fn" in remaining
        assert "remove_fn" not in remaining

    def test_incremental_falls_back_to_full_when_no_prior_index(self, tmp_path):
        """run_incremental() on an unindexed repo runs full indexing."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "app.py").write_text("def alpha(): pass\n")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)

        # Don't call run_full() — run incremental on a fresh pipeline
        pipeline.run_incremental()

        symbols = pipeline.graph_store.get_all_symbols()
        assert any(s.name == "alpha" for s in symbols)

    def test_incremental_checksum_path_no_git(self, tmp_path):
        """Checksum fallback detects changes in a plain directory (no .git)."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        # Plain directory — NO git init
        (tmp_path / "app.py").write_text("def func_v1(): pass\n")

        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "func_v1" in names

        # Modify file — no git commit, checksum path must fire
        (tmp_path / "app.py").write_text("def func_v2(): pass\n")
        pipeline.run_incremental()

        updated = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "func_v2" in updated
        assert "func_v1" not in updated

    def test_incremental_git_diff_path(self, tmp_path):
        """_detect_changes uses git diff when a new commit is available."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "a.py").write_text("def fn_a(): pass\n")
        _git_init(tmp_path)  # commit 1

        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()  # stores commit-1 SHA in meta

        # Make a change and commit → commit 2
        (tmp_path / "a.py").write_text("def fn_a_v2(): pass\n")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "update fn_a"],
                       cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "fn_a_v2" in names
        assert "fn_a" not in names


# ---------------------------------------------------------------------------
# phase_embed.run_partial
# ---------------------------------------------------------------------------

class TestPhaseEmbedPartial:
    def test_run_partial_removes_stale_entries_from_bm25(self, tmp_path):
        """run_partial removes stale BM25 entries and adds new ones."""
        import json
        import numpy as np
        from unittest.mock import MagicMock, patch
        from ravmem.indexer.phase_embed import run_partial
        from ravmem.storage.schema import Symbol
        from ravmem.storage.vectors import VectorStore

        bm25_path = tmp_path / "bm25.json"
        vs = VectorStore(tmp_path / "vectors")
        vs.initialize()

        # Seed vector store with a symbol that will be removed
        seed_embs = np.random.rand(1, 384).astype(np.float32)
        seed_embs = seed_embs / np.linalg.norm(seed_embs, axis=1, keepdims=True)
        vs.add_symbols(["stale_id"], seed_embs)
        vs.save()

        # Seed BM25 corpus with the stale entry
        bm25_path.write_text(json.dumps([
            {"id": "stale_id", "text": "function stale_fn in f.py",
             "name": "stale_fn", "file": "/f.py", "kind": "function",
             "line_start": 1, "line_end": 2, "lang": "python", "cluster_id": ""}
        ]))

        new_sym = Symbol(
            id="new_id", name="new_fn", kind="function",
            file="/f.py", line_start=1, line_end=2, lang="python",
        )

        # Stub out model loading — returns a fake model whose embed() yields
        # properly shaped float32 vectors so no real fastembed needed.
        fake_model = MagicMock()
        fake_model.embed.return_value = iter([np.random.rand(384).astype(np.float32)])

        with patch("ravmem.indexer.phase_embed._load_model", return_value=fake_model):
            run_partial(["stale_id"], [new_sym], vs, bm25_path)

        corpus = json.loads(bm25_path.read_text())
        corpus_ids = [e["id"] for e in corpus]
        assert "stale_id" not in corpus_ids
        assert "new_id" in corpus_ids
        assert new_sym.embedding_id >= 0
        assert vs.deleted_count == 1

    def test_run_partial_handles_empty_new_symbols(self, tmp_path):
        """run_partial with no new symbols only patches BM25 (no encoding)."""
        import json
        import numpy as np
        from ravmem.indexer.phase_embed import run_partial
        from ravmem.storage.vectors import VectorStore

        bm25_path = tmp_path / "bm25.json"
        vs = VectorStore(tmp_path / "vectors")
        vs.initialize()

        seed_embs = np.random.rand(2, 384).astype(np.float32)
        vs.add_symbols(["keep_id", "stale_id"], seed_embs)
        vs.save()

        bm25_path.write_text(json.dumps([
            {"id": "keep_id", "text": "x", "name": "k", "file": "/f.py",
             "kind": "function", "line_start": 1, "line_end": 2, "lang": "python", "cluster_id": ""},
            {"id": "stale_id", "text": "y", "name": "s", "file": "/f.py",
             "kind": "function", "line_start": 3, "line_end": 4, "lang": "python", "cluster_id": ""},
        ]))

        run_partial(["stale_id"], [], vs, bm25_path)

        corpus = json.loads(bm25_path.read_text())
        assert len(corpus) == 1
        assert corpus[0]["id"] == "keep_id"
        assert vs.deleted_count == 1


# ---------------------------------------------------------------------------
# New languages — Phase 2 (Parse)
# ---------------------------------------------------------------------------

class TestPhaseParseJava:
    def test_extracts_java_class_and_methods(self, tmp_path):
        pytest.importorskip("tree_sitter_java")
        src = textwrap.dedent("""\
            public class Calculator {
                public int add(int a, int b) {
                    return a + b;
                }
                public int subtract(int a, int b) {
                    return a - b;
                }
            }
        """)
        f = tmp_path / "Calculator.java"
        f.write_text(src)
        files = [File(path=str(f), lang="java", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "Calculator" in names
        assert any("add" in n for n in names)
        assert any("subtract" in n for n in names)
        assert len(edges) == len(symbols)

    def test_extracts_java_interface_and_enum(self, tmp_path):
        pytest.importorskip("tree_sitter_java")
        src = textwrap.dedent("""\
            public interface Printable {
                void print();
            }
            public enum Color { RED, GREEN, BLUE }
        """)
        f = tmp_path / "Types.java"
        f.write_text(src)
        files = [File(path=str(f), lang="java", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        kinds = {s.kind for s in symbols}
        assert "interface" in kinds
        assert "enum" in kinds

    def test_java_method_kind(self, tmp_path):
        pytest.importorskip("tree_sitter_java")
        src = textwrap.dedent("""\
            class Foo {
                void doWork() {}
            }
        """)
        f = tmp_path / "Foo.java"
        f.write_text(src)
        files = [File(path=str(f), lang="java", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        method_syms = [s for s in symbols if "doWork" in s.name]
        assert method_syms, "Expected 'doWork' method"
        assert method_syms[0].kind == "method"


class TestPhaseParseCSHarp:
    def test_extracts_csharp_class_and_methods(self, tmp_path):
        pytest.importorskip("tree_sitter_c_sharp")
        src = textwrap.dedent("""\
            public class OrderService {
                public Order CreateOrder(int id) {
                    return new Order(id);
                }
                public void DeleteOrder(int id) {}
            }
        """)
        f = tmp_path / "OrderService.cs"
        f.write_text(src)
        files = [File(path=str(f), lang="csharp", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "OrderService" in names
        assert any("CreateOrder" in n for n in names)
        assert len(edges) == len(symbols)

    def test_extracts_csharp_interface_struct_enum(self, tmp_path):
        pytest.importorskip("tree_sitter_c_sharp")
        src = textwrap.dedent("""\
            interface ILogger { void Log(string msg); }
            struct Point { public int X; public int Y; }
            enum Status { Active, Inactive }
        """)
        f = tmp_path / "Types.cs"
        f.write_text(src)
        files = [File(path=str(f), lang="csharp", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        kinds = {s.kind for s in symbols}
        assert "interface" in kinds
        assert "struct" in kinds
        assert "enum" in kinds


class TestPhaseParsePHP:
    def test_extracts_php_class_and_functions(self, tmp_path):
        pytest.importorskip("tree_sitter_php")
        src = textwrap.dedent("""\
            <?php
            class UserRepository {
                public function findById(int $id): User {
                    return new User($id);
                }
                public function save(User $user): void {}
            }
            function bootstrap(): void {}
        """)
        f = tmp_path / "repo.php"
        f.write_text(src)
        files = [File(path=str(f), lang="php", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "UserRepository" in names
        assert any("findById" in n for n in names)
        assert "bootstrap" in names
        assert len(edges) == len(symbols)

    def test_extracts_php_interface_and_trait(self, tmp_path):
        pytest.importorskip("tree_sitter_php")
        src = textwrap.dedent("""\
            <?php
            interface Serializable { public function serialize(): string; }
            trait Timestampable { public function getCreatedAt(): \\DateTime {} }
        """)
        f = tmp_path / "traits.php"
        f.write_text(src)
        files = [File(path=str(f), lang="php", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        kinds = {s.kind for s in symbols}
        assert "interface" in kinds
        assert "trait" in kinds


class TestPhaseParseRust:
    def test_extracts_rust_struct_and_functions(self, tmp_path):
        pytest.importorskip("tree_sitter_rust")
        src = textwrap.dedent("""\
            pub struct Config {
                pub debug: bool,
            }
            impl Config {
                pub fn new(debug: bool) -> Self {
                    Config { debug }
                }
                pub fn is_debug(&self) -> bool {
                    self.debug
                }
            }
            pub fn run() {}
        """)
        f = tmp_path / "lib.rs"
        f.write_text(src)
        files = [File(path=str(f), lang="rust", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "Config" in names
        assert any("new" in n for n in names)
        assert any("is_debug" in n for n in names)
        assert "run" in names
        assert len(edges) == len(symbols)

    def test_extracts_rust_enum_and_trait(self, tmp_path):
        pytest.importorskip("tree_sitter_rust")
        src = textwrap.dedent("""\
            pub enum Status { Ok, Err }
            pub trait Describable {
                fn describe(&self) -> String;
            }
        """)
        f = tmp_path / "types.rs"
        f.write_text(src)
        files = [File(path=str(f), lang="rust", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        kinds = {s.kind for s in symbols}
        assert "enum" in kinds
        assert "interface" in kinds  # traits mapped to interface

    def test_rust_impl_method_kind(self, tmp_path):
        pytest.importorskip("tree_sitter_rust")
        src = textwrap.dedent("""\
            struct Foo;
            impl Foo {
                fn bar(&self) {}
            }
        """)
        f = tmp_path / "foo.rs"
        f.write_text(src)
        files = [File(path=str(f), lang="rust", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        method_syms = [s for s in symbols if "bar" in s.name]
        assert method_syms, "Expected 'bar' method symbol"
        assert method_syms[0].kind == "method"


class TestPhaseParseKotlin:
    def test_extracts_kotlin_class_and_functions(self, tmp_path):
        pytest.importorskip("tree_sitter_kotlin")
        src = textwrap.dedent("""\
            class PaymentService {
                fun processPayment(amount: Double): Boolean {
                    return amount > 0
                }
            }
            fun main() {}
        """)
        f = tmp_path / "payment.kt"
        f.write_text(src)
        files = [File(path=str(f), lang="kotlin", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "PaymentService" in names
        assert any("processPayment" in n for n in names)
        assert "main" in names
        assert len(edges) == len(symbols)

    def test_extracts_kotlin_object_and_interface(self, tmp_path):
        pytest.importorskip("tree_sitter_kotlin")
        # Multi-line required — some grammar versions reject single-line declarations
        src = textwrap.dedent("""\
            object Singleton {
                fun getInstance() = this
            }
            interface Repository {
                fun findAll(): List<Any>
            }
        """)
        f = tmp_path / "types.kt"
        f.write_text(src)
        files = [File(path=str(f), lang="kotlin", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        kinds = {s.kind for s in symbols}
        assert "class" in kinds  # object → class
        assert "interface" in kinds


class TestPhaseParseRuby:
    def test_extracts_ruby_class_and_methods(self, tmp_path):
        pytest.importorskip("tree_sitter_ruby")
        src = textwrap.dedent("""\
            class Invoice
              def initialize(id)
                @id = id
              end

              def total
                @total ||= 0
              end
            end
        """)
        f = tmp_path / "invoice.rb"
        f.write_text(src)
        files = [File(path=str(f), lang="ruby", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "Invoice" in names
        assert any("initialize" in n for n in names)
        assert any("total" in n for n in names)
        assert len(edges) == len(symbols)

    def test_extracts_ruby_module(self, tmp_path):
        pytest.importorskip("tree_sitter_ruby")
        src = textwrap.dedent("""\
            module Helpers
              def format_date(d)
                d.to_s
              end
            end
        """)
        f = tmp_path / "helpers.rb"
        f.write_text(src)
        files = [File(path=str(f), lang="ruby", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        kinds = {s.kind for s in symbols}
        assert "module" in kinds


class TestPhaseParseC:
    def test_extracts_c_functions(self, tmp_path):
        pytest.importorskip("tree_sitter_c")
        src = textwrap.dedent("""\
            #include <stdio.h>

            int add(int a, int b) {
                return a + b;
            }

            void greet(const char *name) {
                printf("Hello, %s\\n", name);
            }
        """)
        f = tmp_path / "utils.c"
        f.write_text(src)
        files = [File(path=str(f), lang="c", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "add" in names
        assert "greet" in names
        assert len(edges) == len(symbols)

    def test_extracts_cpp_class_and_methods(self, tmp_path):
        pytest.importorskip("tree_sitter_cpp")
        src = textwrap.dedent("""\
            class Stack {
            public:
                void push(int val);
                int pop();
            };

            void Stack::push(int val) {}
            int Stack::pop() { return 0; }
        """)
        f = tmp_path / "stack.cpp"
        f.write_text(src)
        files = [File(path=str(f), lang="cpp", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, edges = run(files)
        names = [s.name for s in symbols]
        assert "Stack" in names
        assert len(edges) == len(symbols)

    def test_c_struct_extracted(self, tmp_path):
        pytest.importorskip("tree_sitter_c")
        src = textwrap.dedent("""\
            struct Point {
                int x;
                int y;
            };
        """)
        f = tmp_path / "point.c"
        f.write_text(src)
        files = [File(path=str(f), lang="c", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        names = [s.name for s in symbols]
        assert "Point" in names


# ---------------------------------------------------------------------------
# New languages — Phase 3 (Resolve)
# ---------------------------------------------------------------------------

class TestPhaseResolveJavaInheritance:
    def test_java_extends_creates_inherits_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Animal.java"
        f1.write_text("public class Animal { public void speak() {} }")
        f2 = tmp_path / "Dog.java"
        f2.write_text("public class Dog extends Animal { public void bark() {} }")

        files = [
            File(path=str(f1), lang="java", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="java", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]

        animal_sym = next((s for s in symbols if s.name == "Animal"), None)
        dog_sym = next((s for s in symbols if s.name == "Dog"), None)
        assert animal_sym and dog_sym, f"Symbols: {[s.name for s in symbols]}"
        assert any(e.src_id == dog_sym.id and e.dst_id == animal_sym.id for e in inherits), (
            f"Expected Dog→Animal inherits. Got: {[(e.src_id, e.dst_id) for e in inherits]}"
        )

    def test_java_implements_creates_inherits_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Printable.java"
        f1.write_text("public interface Printable { void print(); }")
        f2 = tmp_path / "Report.java"
        f2.write_text("public class Report implements Printable { public void print() {} }")

        files = [
            File(path=str(f1), lang="java", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="java", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]

        printable = next((s for s in symbols if s.name == "Printable"), None)
        report = next((s for s in symbols if s.name == "Report"), None)
        assert printable and report
        assert any(e.src_id == report.id and e.dst_id == printable.id for e in inherits)


class TestPhaseResolveCSharpInheritance:
    def test_csharp_inherits_base_class(self, tmp_path):
        pytest.importorskip("tree_sitter_c_sharp")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Base.cs"
        f1.write_text("public class BaseService { public void Init() {} }")
        f2 = tmp_path / "Child.cs"
        f2.write_text("public class ChildService : BaseService { }")

        files = [
            File(path=str(f1), lang="csharp", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="csharp", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]

        base = next((s for s in symbols if s.name == "BaseService"), None)
        child = next((s for s in symbols if s.name == "ChildService"), None)
        assert base and child
        assert any(e.src_id == child.id and e.dst_id == base.id for e in inherits)


class TestPhaseResolvePHPImportsAndInheritance:
    def test_php_require_creates_imports_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_php")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "db.php"
        f1.write_text("<?php class Database { public function connect() {} }")
        f2 = tmp_path / "app.php"
        f2.write_text("<?php\nrequire_once 'db.php';\n$db = new Database();")

        files = [
            File(path=str(f1), lang="php", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="php", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports), (
            f"Expected imports edge. Got: {[(e.src_id, e.dst_id) for e in imports]}"
        )

    def test_php_extends_creates_inherits_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_php")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "base.php"
        f1.write_text("<?php class Base { public function init() {} }")
        f2 = tmp_path / "child.php"
        f2.write_text("<?php class Child extends Base { }")

        files = [
            File(path=str(f1), lang="php", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="php", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]
        base = next((s for s in symbols if s.name == "Base"), None)
        child = next((s for s in symbols if s.name == "Child"), None)
        assert base and child
        assert any(e.src_id == child.id and e.dst_id == base.id for e in inherits)


class TestPhaseResolveRustTraits:
    def test_rust_impl_trait_creates_inherits_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_rust")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "lib.rs"
        f1.write_text(textwrap.dedent("""\
            pub trait Drawable {
                fn draw(&self);
            }
            pub struct Circle { pub radius: f64 }
            impl Drawable for Circle {
                fn draw(&self) {}
            }
        """))

        files = [File(path=str(f1), lang="rust", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]

        drawable = next((s for s in symbols if s.name == "Drawable"), None)
        circle = next((s for s in symbols if s.name == "Circle"), None)
        assert drawable and circle, f"Symbols: {[s.name for s in symbols]}"
        assert any(e.src_id == circle.id and e.dst_id == drawable.id for e in inherits), (
            f"Expected Circle→Drawable. Got: {[(e.src_id, e.dst_id) for e in inherits]}"
        )


class TestPhaseResolveRubyImportsAndInheritance:
    def test_ruby_require_relative_creates_imports_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_ruby")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "base.rb"
        f1.write_text("class Base\n  def init\n  end\nend")
        f2 = tmp_path / "child.rb"
        f2.write_text("require_relative 'base'\nclass Child < Base\nend")

        files = [
            File(path=str(f1), lang="ruby", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="ruby", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports)

    def test_ruby_superclass_creates_inherits_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_ruby")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "classes.rb"
        f1.write_text(textwrap.dedent("""\
            class Animal
              def speak; end
            end
            class Dog < Animal
              def bark; end
            end
        """))

        files = [File(path=str(f1), lang="ruby", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]
        animal = next((s for s in symbols if s.name == "Animal"), None)
        dog = next((s for s in symbols if s.name == "Dog"), None)
        assert animal and dog
        assert any(e.src_id == dog.id and e.dst_id == animal.id for e in inherits)


class TestPhaseResolveCIncludes:
    def test_c_local_include_creates_imports_edge(self, tmp_path):
        pytest.importorskip("tree_sitter_c")
        from ravmem.indexer import phase_parse, phase_resolve

        header = tmp_path / "utils.h"
        header.write_text("int add(int a, int b);")
        src = tmp_path / "main.c"
        src.write_text('#include "utils.h"\nint main() { return 0; }')

        files = [
            File(path=str(header), lang="c", size_kb=0.1, checksum=""),
            File(path=str(src), lang="c", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(src) and e.dst_id == str(header) for e in imports), (
            f"Expected main.c→utils.h import. Got: {[(e.src_id, e.dst_id) for e in imports]}"
        )

    def test_cpp_system_include_not_resolved(self, tmp_path):
        """System includes (<...>) should NOT produce imports edges."""
        pytest.importorskip("tree_sitter_cpp")
        from ravmem.indexer import phase_parse, phase_resolve

        src = tmp_path / "main.cpp"
        src.write_text("#include <iostream>\nint main() { return 0; }")

        files = [File(path=str(src), lang="cpp", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert imports == [], f"Unexpected imports from system include: {imports}"


# ---------------------------------------------------------------------------
# Grammar unavailability — graceful degradation
# ---------------------------------------------------------------------------

class TestGrammarUnavailable:
    def test_missing_grammar_returns_empty_symbols(self, tmp_path):
        """If a grammar is not installed, extraction returns [] without crashing."""
        from ravmem.indexer import phase_parse

        # Use a real file path but a non-existent language parser by temporarily
        # patching _get_parser to return None for an otherwise valid lang.
        from unittest.mock import patch
        f = tmp_path / "test.java"
        f.write_text("public class Foo {}")
        files = [File(path=str(f), lang="java", size_kb=0.1, checksum="")]

        with patch("ravmem.indexer.phase_parse._get_parser", return_value=None):
            symbols, edges = phase_parse.run(files)

        assert symbols == []
        assert edges == []

    def test_structure_warns_for_unlisted_lang(self, tmp_path):
        """Files of a language not in --langs produce a warning, not a crash."""
        (tmp_path / "hello.rs").write_text("fn main() {}")

        from ravmem.indexer.phase_structure import run
        # Must NOT raise — just skip and warn
        files = run(tmp_path, langs=["python"])
        assert all(f.lang == "python" for f in files)


# ---------------------------------------------------------------------------
# Incremental indexing — new languages
# ---------------------------------------------------------------------------

class TestIncrementalNewLangs:
    def test_incremental_java_modified_file(self, tmp_path):
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "Svc.java").write_text("public class OldService {}")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["java"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "OldService" in names

        (tmp_path / "Svc.java").write_text("public class NewService {}")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "update"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        updated = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "NewService" in updated
        assert "OldService" not in updated

    def test_incremental_rust_deleted_file(self, tmp_path):
        pytest.importorskip("tree_sitter_rust")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "keep.rs").write_text("pub fn keep_fn() {}")
        (tmp_path / "remove.rs").write_text("pub fn remove_fn() {}")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["rust"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "remove_fn" in names

        subprocess.run(["git", "rm", "remove.rs"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "del"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        remaining = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "keep_fn" in remaining
        assert "remove_fn" not in remaining

    def test_incremental_ruby_checksum_path(self, tmp_path):
        """Checksum-based incremental indexing works for Ruby (no git)."""
        pytest.importorskip("tree_sitter_ruby")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "app.rb").write_text("class OldController\n  def index\n  end\nend")

        config = PipelineConfig(langs=["ruby"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "OldController" in names

        (tmp_path / "app.rb").write_text("class NewController\n  def show\n  end\nend")
        pipeline.run_incremental()

        updated = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "NewController" in updated
        assert "OldController" not in updated

    # ---- C# ----

    def test_incremental_csharp_modified_file(self, tmp_path):
        """C# modified file: old class removed, new class appears (git-diff path)."""
        pytest.importorskip("tree_sitter_c_sharp")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "Svc.cs").write_text("public class OldService { public void Init() {} }")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["csharp"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "OldService" in names

        (tmp_path / "Svc.cs").write_text("public class NewService { public void Start() {} }")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "rename svc"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        updated = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "NewService" in updated
        assert "OldService" not in updated

    def test_incremental_csharp_deleted_file(self, tmp_path):
        """C# deleted file: its symbols are removed from the graph (git-diff path)."""
        pytest.importorskip("tree_sitter_c_sharp")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "Keep.cs").write_text("public class KeepService {}")
        (tmp_path / "Remove.cs").write_text("public class RemoveService {}")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["csharp"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "RemoveService" in names

        subprocess.run(["git", "rm", "Remove.cs"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "del"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        remaining = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "KeepService" in remaining
        assert "RemoveService" not in remaining

    # ---- PHP ----

    def test_incremental_php_modified_checksum(self, tmp_path):
        """PHP modified file: old class removed, new class appears (checksum path, no git)."""
        pytest.importorskip("tree_sitter_php")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        # No _git_init — forces checksum-based change detection
        (tmp_path / "app.php").write_text("<?php class OldController { public function index() {} }")

        config = PipelineConfig(langs=["php"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "OldController" in names

        (tmp_path / "app.php").write_text("<?php class NewController { public function show() {} }")
        pipeline.run_incremental()

        updated = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "NewController" in updated
        assert "OldController" not in updated

    def test_incremental_php_deleted_git(self, tmp_path):
        """PHP deleted file: symbols removed, remaining symbols intact (git-diff path)."""
        pytest.importorskip("tree_sitter_php")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "keep.php").write_text("<?php class KeepClass { public function go() {} }")
        (tmp_path / "remove.php").write_text("<?php class RemoveClass { public function stop() {} }")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["php"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "RemoveClass" in names

        subprocess.run(["git", "rm", "remove.php"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "del"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        remaining = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "KeepClass" in remaining
        assert "RemoveClass" not in remaining

    # ---- Kotlin ----

    def test_incremental_kotlin_modified_file(self, tmp_path):
        """Kotlin modified file: old class removed, new class appears (git-diff path)."""
        pytest.importorskip("tree_sitter_kotlin")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "App.kt").write_text("class OldApp {\n    fun start() {}\n}")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["kotlin"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "OldApp" in names

        (tmp_path / "App.kt").write_text("class NewApp {\n    fun launch() {}\n}")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "rename app"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        updated = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "NewApp" in updated
        assert "OldApp" not in updated

    def test_incremental_kotlin_deleted_file(self, tmp_path):
        """Kotlin deleted file: symbols removed from graph (git-diff path)."""
        pytest.importorskip("tree_sitter_kotlin")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "Keep.kt").write_text("class KeepRepo {\n    fun find() {}\n}")
        (tmp_path / "Remove.kt").write_text("class RemoveRepo {\n    fun clear() {}\n}")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["kotlin"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "RemoveRepo" in names

        subprocess.run(["git", "rm", "Remove.kt"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "del"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        remaining = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "KeepRepo" in remaining
        assert "RemoveRepo" not in remaining

    # ---- C ----

    def test_incremental_c_modified_file(self, tmp_path):
        """C modified file: old function removed, new function appears (git-diff path)."""
        pytest.importorskip("tree_sitter_c")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "main.c").write_text("int old_fn(void) { return 0; }")
        _git_init(tmp_path)

        config = PipelineConfig(langs=["c"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "old_fn" in names

        (tmp_path / "main.c").write_text("int new_fn(void) { return 1; }")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "rename fn"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        updated = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "new_fn" in updated
        assert "old_fn" not in updated

    # ---- C++ ----

    def test_incremental_cpp_deleted_git(self, tmp_path):
        """C++ deleted file: its symbols are removed from the graph (git-diff path)."""
        pytest.importorskip("tree_sitter_cpp")
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        (tmp_path / "keep.cpp").write_text(
            "class KeepWidget {\npublic:\n    void render() {}\n};\n"
        )
        (tmp_path / "remove.cpp").write_text(
            "class RemoveWidget {\npublic:\n    void hide() {}\n};\n"
        )
        _git_init(tmp_path)

        config = PipelineConfig(langs=["cpp"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        names = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "RemoveWidget" in names

        subprocess.run(["git", "rm", "remove.cpp"], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "del"], cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        remaining = [s.name for s in pipeline.graph_store.get_all_symbols()]
        assert "KeepWidget" in remaining
        assert "RemoveWidget" not in remaining


# ---------------------------------------------------------------------------
# Regression — existing languages still pass after refactor
# ---------------------------------------------------------------------------

class TestRegressionExistingLangs:
    def test_python_still_extracts_after_refactor(self, tmp_path):
        """Python extraction must not regress after grammar loader refactor."""
        src = textwrap.dedent("""\
            def foo():
                pass
            class Bar:
                def baz(self): pass
        """)
        f = tmp_path / "sample.py"
        f.write_text(src)
        files = [File(path=str(f), lang="python", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        names = [s.name for s in symbols]
        assert "foo" in names
        assert "Bar" in names
        assert any("baz" in n for n in names)

    def test_go_still_extracts_after_refactor(self, tmp_path):
        src = textwrap.dedent("""\
            package main
            func Greet(name string) string { return name }
            type Config struct {}
        """)
        f = tmp_path / "main.go"
        f.write_text(src)
        files = [File(path=str(f), lang="go", size_kb=0.1, checksum="")]
        from ravmem.indexer.phase_parse import run
        symbols, _ = run(files)
        names = [s.name for s in symbols]
        assert "Greet" in names
        assert "Config" in names

    def test_python_call_resolution_unchanged(self, tmp_path):
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "utils.py"
        f1.write_text("def helper(): pass")
        f2 = tmp_path / "main.py"
        f2.write_text("from utils import helper\ndef run():\n    helper()")

        files = [
            File(path=str(f1), lang="python", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="python", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        calls = [e for e in edges if e.kind == "calls"]
        helper_sym = next((s for s in symbols if s.name == "helper"), None)
        assert helper_sym is not None
        assert any(e.dst_id == helper_sym.id for e in calls)


# ---------------------------------------------------------------------------
# Import resolution — new languages
# ---------------------------------------------------------------------------

class TestPhaseResolveJavaImports:
    def test_java_import_resolves_to_file(self, tmp_path):
        """import com.example.Animal → Animal.java imports edge."""
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Animal.java"
        f1.write_text("public class Animal {}")
        f2 = tmp_path / "Zoo.java"
        f2.write_text("import com.example.Animal;\npublic class Zoo { Animal a; }")

        files = [
            File(path=str(f1), lang="java", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="java", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports), (
            f"Expected Zoo.java→Animal.java import. Got: {[(e.src_id, e.dst_id) for e in imports]}"
        )

    def test_java_wildcard_import_not_resolved(self, tmp_path):
        """import com.example.*; should not produce any import edges."""
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        f = tmp_path / "Main.java"
        f.write_text("import com.example.*;\npublic class Main {}")

        files = [File(path=str(f), lang="java", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert imports == [], f"Unexpected wildcard imports: {imports}"


class TestPhaseResolveCSharpImports:
    def test_csharp_using_resolves_to_file(self, tmp_path):
        """using MyApp.Services; → file declaring that namespace."""
        pytest.importorskip("tree_sitter_c_sharp")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "UserService.cs"
        f1.write_text("namespace MyApp.Services { public class UserService {} }")
        f2 = tmp_path / "Controller.cs"
        f2.write_text("using MyApp.Services;\nnamespace MyApp { public class Controller {} }")

        files = [
            File(path=str(f1), lang="csharp", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="csharp", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports), (
            f"Expected Controller.cs→UserService.cs import. Got: {[(e.src_id, e.dst_id) for e in imports]}"
        )


class TestPhaseResolveRustModImports:
    def test_rust_mod_resolves_to_file(self, tmp_path):
        """mod helpers; → helpers.rs imports edge."""
        pytest.importorskip("tree_sitter_rust")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "helpers.rs"
        f1.write_text("pub fn greet() {}")
        f2 = tmp_path / "main.rs"
        f2.write_text("mod helpers;\nfn main() { helpers::greet(); }")

        files = [
            File(path=str(f1), lang="rust", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="rust", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports), (
            f"Expected main.rs→helpers.rs import. Got: {[(e.src_id, e.dst_id) for e in imports]}"
        )

    def test_rust_pub_mod_resolves_to_file(self, tmp_path):
        """pub mod utils; → utils.rs imports edge."""
        pytest.importorskip("tree_sitter_rust")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "utils.rs"
        f1.write_text("pub fn add(a: i32, b: i32) -> i32 { a + b }")
        f2 = tmp_path / "lib.rs"
        f2.write_text("pub mod utils;")

        files = [
            File(path=str(f1), lang="rust", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="rust", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports)


class TestPhaseResolveKotlinImports:
    def test_kotlin_import_resolves_to_file(self, tmp_path):
        """import com.example.Service → Service.kt imports edge."""
        pytest.importorskip("tree_sitter_kotlin")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Service.kt"
        f1.write_text("class Service { fun start() {} }")
        f2 = tmp_path / "App.kt"
        f2.write_text("import com.example.Service\nfun main() { Service().start() }")

        files = [
            File(path=str(f1), lang="kotlin", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="kotlin", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports), (
            f"Expected App.kt→Service.kt import. Got: {[(e.src_id, e.dst_id) for e in imports]}"
        )


# ---------------------------------------------------------------------------
# AST-based call resolution — new languages
# ---------------------------------------------------------------------------

class TestPhaseResolveJavaASTCalls:
    def test_java_method_call_creates_calls_edge(self, tmp_path):
        """Java method_invocation AST node → calls edge."""
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Logger.java"
        f1.write_text(textwrap.dedent("""\
            public class Logger {
                public void log(String msg) {}
            }
        """))
        f2 = tmp_path / "App.java"
        f2.write_text(textwrap.dedent("""\
            public class App {
                public void run() {
                    Logger logger = new Logger();
                    logger.log("hello");
                }
            }
        """))

        files = [
            File(path=str(f1), lang="java", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="java", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        calls = [e for e in edges if e.kind == "calls"]

        log_sym = next((s for s in symbols if "log" in s.name and s.lang == "java"), None)
        assert log_sym is not None, f"Symbols: {[s.name for s in symbols]}"
        assert any(e.dst_id == log_sym.id for e in calls), (
            f"Expected call to log(). Got: {[(e.src_id, e.dst_id) for e in calls]}"
        )

    def test_java_ast_calls_confidence_higher_than_regex(self, tmp_path):
        """AST-based Java calls have confidence=0.6 (not 0.5 like regex)."""
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Util.java"
        f1.write_text("public class Util { public static void helper() {} }")
        f2 = tmp_path / "Main.java"
        f2.write_text(textwrap.dedent("""\
            public class Main {
                public void run() { Util.helper(); }
            }
        """))

        files = [
            File(path=str(f1), lang="java", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="java", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        calls = [e for e in edges if e.kind == "calls" and e.confidence is not None]
        if calls:
            assert all(e.confidence >= 0.6 for e in calls), (
                f"Expected confidence >= 0.6 for AST calls, got: {[e.confidence for e in calls]}"
            )


class TestPhaseResolveRustASTCalls:
    def test_rust_function_call_creates_edge(self, tmp_path):
        """Rust call_expression AST → calls edge."""
        pytest.importorskip("tree_sitter_rust")
        from ravmem.indexer import phase_parse, phase_resolve

        f = tmp_path / "lib.rs"
        f.write_text(textwrap.dedent("""\
            pub fn helper() {}
            pub fn run() {
                helper();
            }
        """))

        files = [File(path=str(f), lang="rust", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        # calls within same file are filtered (file_sym_ids check)
        # add a second file so cross-file call is tested
        f2 = tmp_path / "main.rs"
        f2.write_text("mod lib;\nfn main() { lib::helper(); }")
        files2 = [
            File(path=str(f), lang="rust", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="rust", size_kb=0.1, checksum=""),
        ]
        symbols2, _ = phase_parse.run(files2)
        edges = phase_resolve.run(files2, symbols2, tmp_path)
        calls = [e for e in edges if e.kind == "calls"]
        helper_sym = next((s for s in symbols2 if s.name == "helper"), None)
        assert helper_sym is not None
        # helper() may be called from main or from run(); either way expect an edge
        assert any(e.dst_id == helper_sym.id for e in calls), (
            f"Expected call to helper. Got: {[(e.src_id, e.dst_id) for e in calls]}"
        )


class TestPhaseResolveRubyMixins:
    def test_ruby_include_with_class_context_creates_inherits_edge(self, tmp_path):
        """Ruby `include Module` inside a class body → inherits edge with correct class."""
        pytest.importorskip("tree_sitter_ruby")
        from ravmem.indexer import phase_parse, phase_resolve

        f = tmp_path / "mixins.rb"
        f.write_text(textwrap.dedent("""\
            module Greetable
              def greet
                "hello"
              end
            end

            class Person
              include Greetable
              def initialize(name)
                @name = name
              end
            end
        """))

        files = [File(path=str(f), lang="ruby", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]

        greetable = next((s for s in symbols if s.name == "Greetable"), None)
        person = next((s for s in symbols if s.name == "Person"), None)
        assert greetable and person, f"Symbols: {[s.name for s in symbols]}"
        assert any(e.src_id == person.id and e.dst_id == greetable.id for e in inherits), (
            f"Expected Person→Greetable inherits via include. "
            f"Got: {[(e.src_id, e.dst_id) for e in inherits]}"
        )

    def test_ruby_extend_with_class_context_creates_inherits_edge(self, tmp_path):
        """Ruby `extend Module` inside a class → inherits edge."""
        pytest.importorskip("tree_sitter_ruby")
        from ravmem.indexer import phase_parse, phase_resolve

        f = tmp_path / "ext.rb"
        f.write_text(textwrap.dedent("""\
            module ClassMethods
              def create; end
            end
            class Widget
              extend ClassMethods
            end
        """))

        files = [File(path=str(f), lang="ruby", size_kb=0.1, checksum="")]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        inherits = [e for e in edges if e.kind == "inherits"]

        cm = next((s for s in symbols if s.name == "ClassMethods"), None)
        widget = next((s for s in symbols if s.name == "Widget"), None)
        assert cm and widget
        assert any(e.src_id == widget.id and e.dst_id == cm.id for e in inherits)


# ---------------------------------------------------------------------------
# Package-aware import resolution (Java, Kotlin) + use crate:: (Rust)
# ---------------------------------------------------------------------------

class TestPhaseResolveJavaPackageImports:
    def test_fqn_resolves_over_stem_when_package_matches(self, tmp_path):
        """import com.app.models.User resolves to the file that declares `package com.app.models`
        even when another User.java with a different package exists in the repo."""
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        # Two files named User.java but in different (simulated) packages
        models_dir = tmp_path / "models"
        models_dir.mkdir()
        auth_dir = tmp_path / "auth"
        auth_dir.mkdir()

        correct = models_dir / "User.java"
        correct.write_text("package com.app.models;\npublic class User {}")
        wrong = auth_dir / "User.java"
        wrong.write_text("package com.app.auth;\npublic class User {}")
        consumer = tmp_path / "Main.java"
        consumer.write_text(
            "import com.app.models.User;\npublic class Main { User u; }"
        )

        files = [
            File(path=str(correct), lang="java", size_kb=0.1, checksum=""),
            File(path=str(wrong), lang="java", size_kb=0.1, checksum=""),
            File(path=str(consumer), lang="java", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]

        assert any(e.src_id == str(consumer) and e.dst_id == str(correct) for e in imports), (
            f"Expected Main.java→models/User.java (FQN match). Got: "
            f"{[(e.src_id, e.dst_id) for e in imports]}"
        )
        # The wrong User.java (different package) must not be linked
        assert not any(e.src_id == str(consumer) and e.dst_id == str(wrong) for e in imports), (
            "FQN match should have prevented auth/User.java from being linked"
        )

    def test_stem_fallback_when_no_package_declared(self, tmp_path):
        """When a Java file has no package declaration, stem-based resolution still works."""
        pytest.importorskip("tree_sitter_java")
        from ravmem.indexer import phase_parse, phase_resolve

        f1 = tmp_path / "Helper.java"
        f1.write_text("public class Helper { public static void help() {} }")
        f2 = tmp_path / "App.java"
        f2.write_text("import org.util.Helper;\npublic class App {}")

        files = [
            File(path=str(f1), lang="java", size_kb=0.1, checksum=""),
            File(path=str(f2), lang="java", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]
        assert any(e.src_id == str(f2) and e.dst_id == str(f1) for e in imports), (
            f"Expected App.java→Helper.java via stem fallback. Got: "
            f"{[(e.src_id, e.dst_id) for e in imports]}"
        )


class TestPhaseResolveKotlinPackageImports:
    def test_fqn_resolves_over_stem_when_package_matches(self, tmp_path):
        """import com.app.models.Repo resolves to the file declaring `package com.app.models`."""
        pytest.importorskip("tree_sitter_kotlin")
        from ravmem.indexer import phase_parse, phase_resolve

        models_dir = tmp_path / "models"
        models_dir.mkdir()
        other_dir = tmp_path / "other"
        other_dir.mkdir()

        correct = models_dir / "Repo.kt"
        correct.write_text("package com.app.models\nclass Repo {}")
        wrong = other_dir / "Repo.kt"
        wrong.write_text("package com.app.other\nclass Repo {}")
        consumer = tmp_path / "Main.kt"
        consumer.write_text("import com.app.models.Repo\nfun main() { Repo() }")

        files = [
            File(path=str(correct), lang="kotlin", size_kb=0.1, checksum=""),
            File(path=str(wrong), lang="kotlin", size_kb=0.1, checksum=""),
            File(path=str(consumer), lang="kotlin", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]

        assert any(e.src_id == str(consumer) and e.dst_id == str(correct) for e in imports), (
            f"Expected Main.kt→models/Repo.kt (FQN match). Got: "
            f"{[(e.src_id, e.dst_id) for e in imports]}"
        )
        assert not any(e.src_id == str(consumer) and e.dst_id == str(wrong) for e in imports), (
            "FQN match should have excluded other/Repo.kt"
        )


class TestPhaseResolveRustUseImports:
    def test_use_crate_resolves_to_module_file(self, tmp_path):
        """`use crate::models::User` resolves to models.rs under the crate src root."""
        pytest.importorskip("tree_sitter_rust")
        from ravmem.indexer import phase_parse, phase_resolve

        src = tmp_path / "src"
        src.mkdir()

        lib_rs = src / "lib.rs"
        lib_rs.write_text("pub mod models;\npub mod handler;")
        models_rs = src / "models.rs"
        models_rs.write_text("pub struct User { pub name: String }")
        handler_rs = src / "handler.rs"
        handler_rs.write_text("use crate::models::User;\npub fn handle(_u: User) {}")

        files = [
            File(path=str(lib_rs), lang="rust", size_kb=0.1, checksum=""),
            File(path=str(models_rs), lang="rust", size_kb=0.1, checksum=""),
            File(path=str(handler_rs), lang="rust", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]

        assert any(e.src_id == str(handler_rs) and e.dst_id == str(models_rs) for e in imports), (
            f"Expected handler.rs→models.rs via use crate::models. Got: "
            f"{[(e.src_id, e.dst_id) for e in imports]}"
        )

    def test_use_crate_brace_group_resolves_to_common_prefix(self, tmp_path):
        """`use crate::utils::{A, B}` resolves to utils.rs (common prefix)."""
        pytest.importorskip("tree_sitter_rust")
        from ravmem.indexer import phase_parse, phase_resolve

        src = tmp_path / "src"
        src.mkdir()

        lib_rs = src / "lib.rs"
        lib_rs.write_text("pub mod utils;\npub mod app;")
        utils_rs = src / "utils.rs"
        utils_rs.write_text("pub struct A {}\npub struct B {}")
        app_rs = src / "app.rs"
        app_rs.write_text("use crate::utils::{A, B};\npub fn run(_a: A, _b: B) {}")

        files = [
            File(path=str(lib_rs), lang="rust", size_kb=0.1, checksum=""),
            File(path=str(utils_rs), lang="rust", size_kb=0.1, checksum=""),
            File(path=str(app_rs), lang="rust", size_kb=0.1, checksum=""),
        ]
        symbols, _ = phase_parse.run(files)
        edges = phase_resolve.run(files, symbols, tmp_path)
        imports = [e for e in edges if e.kind == "imports"]

        assert any(e.src_id == str(app_rs) and e.dst_id == str(utils_rs) for e in imports), (
            f"Expected app.rs→utils.rs via use crate::utils::{{...}}. Got: "
            f"{[(e.src_id, e.dst_id) for e in imports]}"
        )


# ---------------------------------------------------------------------------
# Cluster integration — dummy repo (Step 10 of clustering-upgrade-plan.md)
#
# Validates real clustering output through the full IndexPipeline:
#   full index  → Leiden lc_ IDs (or fc_ if call edges too sparse)
#   incremental → file-based fc_ IDs for changed symbols only
#   mixed types → unchanged symbols keep their lc_ IDs after incremental
# ---------------------------------------------------------------------------

class TestClusterIntegrationDummyRepo:
    """End-to-end cluster validation on a small multi-file Python dummy repo.

    Uses FakeGraphStore (no ArcadeDB server required).
    Uses git commits so incremental diff detection works.
    """

    _AUTH = textwrap.dedent("""\
        from utils import validate, hash_value

        def authenticate(user, password):
            h = hash_value(password)
            return validate({"user": user, "hash": h})

        def logout(user):
            return validate({"user": user})

        def check_token(token):
            return hash_value(token)
    """)

    _UTILS = textwrap.dedent("""\
        def validate(data):
            return bool(data.get("user"))

        def hash_value(val):
            return str(hash(val))
    """)

    def _make_repo(self, tmp_path: Path) -> None:
        (tmp_path / "auth.py").write_text(self._AUTH)
        (tmp_path / "utils.py").write_text(self._UTILS)
        _git_init(tmp_path)

    def test_full_index_produces_cluster_ids(self, tmp_path):
        """Full index assigns a cluster ID to every symbol."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        self._make_repo(tmp_path)
        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        symbols = pipeline.graph_store.get_all_symbols()
        assert len(symbols) >= 4, f"Expected ≥4 symbols, got {len(symbols)}"
        assert all(s.cluster_id for s in symbols), \
            f"Some symbols have no cluster_id: {[s.name for s in symbols if not s.cluster_id]}"

    def test_full_index_cluster_ids_have_valid_prefix(self, tmp_path):
        """Full index cluster IDs start with lc_ (Leiden) or fc_ (file-based fallback)."""
        import ravmem.indexer.phase_cluster as pc
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        self._make_repo(tmp_path)
        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        symbols = pipeline.graph_store.get_all_symbols()
        valid = ("lc_", "fc_", "c_")
        for s in symbols:
            base = s.cluster_id.split("_0")[0] if s.cluster_id.endswith("_0") else s.cluster_id
            assert any(base.startswith(p) for p in valid), \
                f"Symbol {s.name} has unexpected cluster_id: {s.cluster_id}"

        # When Leiden available, all IDs should start with lc_ (or sub-clusters thereof)
        if pc._LEIDEN_AVAILABLE:
            for s in symbols:
                assert s.cluster_id.startswith("lc_"), \
                    f"Expected lc_ from Leiden, got {s.cluster_id} for {s.name}"

    def test_full_index_cluster_ids_stable_across_reindexes(self, tmp_path):
        """Two full indexes on unchanged repo produce identical cluster IDs."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        self._make_repo(tmp_path)
        config = PipelineConfig(langs=["python"], skip_embeddings=True)

        pipeline1 = IndexPipeline(tmp_path, config=config)
        pipeline1.run_full()
        ids_run1 = {s.name: s.cluster_id for s in pipeline1.graph_store.get_all_symbols()}

        pipeline2 = IndexPipeline(tmp_path, config=config)
        pipeline2.run_full()
        ids_run2 = {s.name: s.cluster_id for s in pipeline2.graph_store.get_all_symbols()}

        assert ids_run1 == ids_run2, \
            f"Cluster IDs not stable across full reindexes:\nRun1: {ids_run1}\nRun2: {ids_run2}"

    def test_incremental_changed_symbols_get_fc_ids(self, tmp_path):
        """Incremental index gives fc_ IDs to symbols from the modified file."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        self._make_repo(tmp_path)
        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        # Modify utils.py and commit so incremental detects the change
        updated_utils = self._UTILS + "\ndef sanitize(val):\n    return str(val).strip()\n"
        (tmp_path / "utils.py").write_text(updated_utils)
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "add sanitize"],
                       cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        symbols_by_name = {s.name: s for s in pipeline.graph_store.get_all_symbols()}

        # validate + hash_value (re-indexed from utils.py) must have fc_ IDs
        for name in ("validate", "hash_value", "sanitize"):
            if name in symbols_by_name:
                cid = symbols_by_name[name].cluster_id
                assert cid.startswith("fc_"), \
                    f"Expected fc_ for re-indexed symbol '{name}', got '{cid}'"

    def test_incremental_unchanged_symbols_keep_their_ids(self, tmp_path):
        """Symbols from unchanged files keep their original cluster IDs after incremental."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        self._make_repo(tmp_path)
        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        # Snapshot auth.py symbol cluster IDs before incremental
        before = {s.name: s.cluster_id
                  for s in pipeline.graph_store.get_all_symbols()
                  if s.file.endswith("auth.py")}
        assert before, "No auth.py symbols found after full index"

        # Only modify utils.py
        updated_utils = self._UTILS + "\ndef extra(): pass\n"
        (tmp_path / "utils.py").write_text(updated_utils)
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "add extra"],
                       cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        after = {s.name: s.cluster_id
                 for s in pipeline.graph_store.get_all_symbols()
                 if s.file.endswith("auth.py")}

        for name, cid_before in before.items():
            assert after.get(name) == cid_before, \
                f"auth.py symbol '{name}' cluster_id changed: {cid_before} → {after.get(name)}"

    def test_mixed_cluster_types_coexist(self, tmp_path):
        """After incremental, lc_ (full) and fc_ (incremental) clusters coexist."""
        import ravmem.indexer.phase_cluster as pc
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        if not pc._LEIDEN_AVAILABLE:
            pytest.skip("leidenalg not installed — mixed type test requires Leiden")

        self._make_repo(tmp_path)
        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        # Modify utils.py only
        (tmp_path / "utils.py").write_text(self._UTILS + "\ndef new_fn(): pass\n")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "add fn"],
                       cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        all_symbols = pipeline.graph_store.get_all_symbols()
        cluster_ids = {s.cluster_id for s in all_symbols if s.cluster_id}

        has_leiden = any(c.startswith("lc_") for c in cluster_ids)
        has_file = any(c.startswith("fc_") for c in cluster_ids)

        assert has_leiden, f"Expected some lc_ IDs from full index, got: {cluster_ids}"
        assert has_file, f"Expected some fc_ IDs from incremental, got: {cluster_ids}"

    def test_no_symbol_left_without_cluster(self, tmp_path):
        """After full+incremental, every symbol has a non-empty cluster_id."""
        from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig

        self._make_repo(tmp_path)
        config = PipelineConfig(langs=["python"], skip_embeddings=True)
        pipeline = IndexPipeline(tmp_path, config=config)
        pipeline.run_full()

        (tmp_path / "utils.py").write_text(self._UTILS + "\ndef extra(): pass\n")
        subprocess.run(["git", "add", "."], cwd=tmp_path, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "add extra"],
                       cwd=tmp_path, check=True, capture_output=True)

        pipeline.run_incremental()

        unassigned = [s.name for s in pipeline.graph_store.get_all_symbols() if not s.cluster_id]
        assert not unassigned, f"Symbols missing cluster_id: {unassigned}"
