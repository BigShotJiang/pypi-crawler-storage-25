# ravmem-server

**RavMem** is a code knowledge graph engine that gives AI agents deep, structured understanding of your codebase — symbols, relationships, clusters, and semantic search — all exposed over REST and MCP.

> **Commercial software.** A valid RavMem license is required to run this server in production. Licenses are available at [ravmem.com](https://www.ravmem.com).

---

## What's included in v0.2.1

### Code Indexing
- Indexes Python, TypeScript, JavaScript, and Go codebases out of the box
- Extracts functions, classes, methods, and interfaces with full cross-file resolution
- Extended language support via `pip install "ravmem-server[langs]"` — Java, C#, Rust, Kotlin, Ruby, PHP, C, C++
- Incremental re-indexing detects only what changed — fast updates on large codebases
- Pre-flight divergence check before large re-indexes; CI-friendly `--yes` flag to skip prompts

### Search
- Hybrid keyword + semantic search merged via Reciprocal Rank Fusion
- Results ranked by relevance score combining text match, semantic similarity, and graph centrality

### Impact Analysis
- Blast-radius traversal — given any symbol, find everything that depends on it
- Configurable traversal depth

### Branch-Aware Indexing
- Each branch gets its own isolated index on the server
- New branch indexes inherit from the parent branch — no full re-index required when branching
- Auto-detects the current git branch from the working directory

### AI Agent Integration
- MCP (Model Context Protocol) server — plug directly into Claude, Cursor, or any MCP-compatible agent
- 6 built-in MCP tools: `search_symbols`, `get_symbol`, `get_impact`, `get_call_chain`, `get_cluster`, `diff_impact`
- REST API and WebSocket endpoint for custom integrations

### Agent Memory Layer
- Built-in knowledge graph for agent instructions, decisions, learnings, and task state
- Scoped per team and branch
- 19 MCP tools for reading, writing, and validating agent memory
- Confidence scoring with human-in-the-loop and auto modes

### Security
- Token-based authentication with role-based access control (RBAC)
- 19 granular permission strings across repos, branches, jobs, metrics, and knowledge graph
- Branch-level access policies via regex patterns
- Audit log with configurable retention
- Encrypted storage for private repository credentials

### Operations
- Async job queue with configurable concurrency
- Atomic index promotion — failed indexes never corrupt live data
- Docker Compose setup included (server + graph backend)
- Prometheus-compatible metrics endpoint

---

## Installation

```bash
pip install ravmem-server

# Extended language support
pip install "ravmem-server[langs]"
```

**Requires Python 3.11.**

---

## Quick start

```bash
# Start the server
ravmem serve --host 0.0.0.0 --port 7432

# Configure the CLI
ravmem remote config --url http://localhost:7432

# Register a repository
ravmem remote add /path/to/repo --name my-project --default-branch main

# Index it
ravmem analyze /path/to/repo --project my-project

# Search
ravmem search "authentication handler" --project my-project

# Blast-radius analysis
ravmem impact MyClass.my_method --project my-project
```

---

## License

Elastic License 2.0 — see [LICENSE](LICENSE).
Commercial use requires a valid RavMem subscription. Visit [ravmem.com](https://www.ravmem.com) to get a license.
