use std::env;
use std::fs;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};
use serde::{Deserialize, Serialize};
use serde_json::Value;

const SOVEREIGN_WINDOW_SECONDS: u64 = 30 * 24 * 60 * 60; // 30 days

#[derive(Serialize)]
struct OpaInput {
    input: Value,
}

#[derive(Deserialize)]
struct OpaResponse {
    result: Option<bool>,
}

#[derive(Serialize)]
struct VaultWriteSecret {
    data: Value,
}

fn get_genesis_time() -> f64 {
    let mut path = PathBuf::from(".");
    path.push("registry");
    path.push("vault");
    path.push("genesis_time.txt");

    if !path.exists() {
        if let Some(parent) = path.parent() {
            let _ = fs::create_dir_all(parent);
        }
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs_f64();
        let _ = fs::write(&path, now.to_string());
        return now;
    }

    if let Ok(content) = fs::read_to_string(&path) {
        if let Ok(t) = content.trim().parse::<f64>() {
            return t;
        }
    }

    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}

async fn check_license(
    client: &reqwest::Client,
    vault_url: &str,
    vault_token: &str,
    opa_url: &str,
) -> bool {
    // 1. List keys under coreason/license
    let list_url = format!("{}/v1/secret/metadata/coreason/license?list=true", vault_url);
    let mut keys = Vec::new();

    if let Ok(res) = client
        .get(&list_url)
        .header("X-Vault-Token", vault_token)
        .send()
        .await
    {
        if res.status().is_success() {
            if let Ok(json) = res.json::<Value>().await {
                if let Some(keys_arr) = json["data"]["keys"].as_array() {
                    for k in keys_arr {
                        if let Some(k_str) = k.as_str() {
                            keys.push(k_str.to_string());
                        }
                    }
                }
            }
        }
    }

    // Fallback if list is empty
    if keys.is_empty() {
        keys.push("".to_string());
    }

    // 2. Validate each key's license
    for key in keys {
        let secret_path = if key.is_empty() {
            "coreason/license".to_string()
        } else {
            format!("coreason/license/{}", key)
        };

        let secret_url = format!("{}/v1/secret/data/{}", vault_url, secret_path);
        let res = match client
            .get(&secret_url)
            .header("X-Vault-Token", vault_token)
            .send()
            .await
        {
            Ok(r) => r,
            Err(_) => continue,
        };

        if !res.status().is_success() {
            continue;
        }

        let secret_json = match res.json::<Value>().await {
            Ok(json) => json,
            Err(_) => continue,
        };

        let envelope = &secret_json["data"]["data"];
        if envelope.is_null() {
            continue;
        }

        // Verify token signature if token is present, otherwise fallback to claims or envelope directly
        let token_opt = envelope["token"].as_str();
        let claims = if let Some(token_str) = token_opt {
            let root_ca_key = env::var("COREASON_ROOT_CA_KEY")
                .or_else(|_| env::var("COREASON_DEV_KEY"))
                .unwrap_or_default();
            match coreason_license::verify_token_signature(token_str, &root_ca_key) {
                Ok(c) => c,
                Err(e) => {
                    eprintln!("[Chronometer] Warning: License token signature verification failed: {}", e);
                    continue;
                }
            }
        } else {
            if envelope["claims"].is_null() {
                envelope.clone()
            } else {
                envelope["claims"].clone()
            }
        };

        // 3. Post to OPA
        let opa_endpoint = format!("{}/v1/data/coreason/governance/license/is_sovereign", opa_url);
        let opa_res = match client
            .post(&opa_endpoint)
            .json(&OpaInput { input: claims })
            .send()
            .await
        {
            Ok(r) => r,
            Err(_) => continue,
        };

        if opa_res.status().is_success() {
            if let Ok(opa_json) = opa_res.json::<OpaResponse>().await {
                if opa_json.result.unwrap_or(false) {
                    return true; // Found at least one valid license!
                }
            }
        }
    }

    false
}

async fn update_guillotine_status(
    client: &reqwest::Client,
    vault_url: &str,
    vault_token: &str,
    active: bool,
) {
    let status_str = if active { "True" } else { "False" };
    println!("[Chronometer] AST Guillotine status updated: {}", status_str);

    // Write to Vault
    let write_url = format!("{}/v1/secret/data/coreason/governance", vault_url);
    let payload = VaultWriteSecret {
        data: serde_json::json!({
            "ast_guillotine_active": status_str
        }),
    };

    let _ = client
        .post(&write_url)
        .header("X-Vault-Token", vault_token)
        .json(&payload)
        .send()
        .await;

    // Also update local environment variable just in case
    env::set_var("AST_GUILLOTINE_ACTIVE", status_str);
}

#[tokio::main]
async fn main() {
    let args: Vec<String> = env::args().collect();
    
    // Command line license installation mode
    if args.len() > 1 && (args[1] == "install" || args[1] == "install-license") {
        if args.len() < 3 {
            eprintln!("Error: Missing JWT token argument");
            std::process::exit(1);
        }
        let token = &args[2];
        let vault_url = env::var("VAULT_ADDR").unwrap_or_else(|_| "http://127.0.0.1:8200".to_string());
        let vault_token = env::var("VAULT_TOKEN").unwrap_or_else(|_| "dev-only-token".to_string());
        let root_ca_key = env::var("COREASON_ROOT_CA_KEY").or_else(|_| env::var("COREASON_DEV_KEY")).unwrap_or_default();
        let env_name = env::var("COREASON_ENV").unwrap_or_else(|_| "development".to_string());
        
        match coreason_license::install_license(token, &vault_url, &vault_token, &root_ca_key, &env_name).await {
            Ok(_) => {
                println!("✓ Commercial License installed and mathematically verified.");
                std::process::exit(0);
            }
            Err(e) => {
                eprintln!("✗ License Installation Failed: {}", e);
                std::process::exit(1);
            }
        }
    }

    println!("[Chronometer] Autonomic Timeline Monitoring Daemon starting...");

    let vault_url = env::var("VAULT_ADDR").unwrap_or_else(|_| "http://127.0.0.1:8200".to_string());
    let vault_token = env::var("VAULT_TOKEN").unwrap_or_else(|_| "dev-only-token".to_string());
    let opa_url = env::var("OPA_ADDR").unwrap_or_else(|_| "http://127.0.0.1:8181".to_string());

    let genesis_time = get_genesis_time();
    println!("[Chronometer] Cluster Genesis Time: {}", genesis_time);

    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(2))
        .build()
        .unwrap();

    loop {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs_f64();
        let elapsed = now - genesis_time;

        let has_license = check_license(&client, &vault_url, &vault_token, &opa_url).await;

        let should_be_active = elapsed > SOVEREIGN_WINDOW_SECONDS as f64 && !has_license;
        update_guillotine_status(&client, &vault_url, &vault_token, should_be_active).await;

        tokio::time::sleep(std::time::Duration::from_secs(60)).await;
    }
}
