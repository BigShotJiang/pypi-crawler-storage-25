from __future__ import annotations

import base64
import io
from dataclasses import dataclass
from typing import Callable

import requests
from PIL import Image, ImageDraw, ImageFont

from tteg.models import ImageResult, PreviewPayload

Downloader = Callable[[str], bytes]

CARD_WIDTH = 320
CARD_PADDING = 12
LABEL_SIZE = 30
LABEL_MARGIN = 10
BACKGROUND_COLOR = "#f4f1eb"
CARD_BACKGROUND = "#ffffff"
LABEL_FILL = "#111111"
LABEL_TEXT = "#ffffff"
TEXT_COLOR = "#1b1b1b"
JPEG_QUALITY = 78


@dataclass(slots=True)
class PreviewBuildResult:
    preview: PreviewPayload | None
    warnings: list[str]


def _default_downloader(url: str) -> bytes:
    response = requests.get(url, timeout=15)
    response.raise_for_status()
    return response.content


def _open_and_resize(image_bytes: bytes) -> Image.Image:
    image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    scale = CARD_WIDTH / image.width
    target_height = max(1, int(image.height * scale))
    return image.resize((CARD_WIDTH, target_height))


def _measure_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> tuple[int, int]:
    left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
    return right - left, bottom - top


def build_preview(
    results: list[ImageResult],
    *,
    downloader: Downloader | None = None,
) -> PreviewBuildResult:
    if not results:
        return PreviewBuildResult(preview=None, warnings=["No results to preview."])

    get_bytes = downloader or _default_downloader
    font = ImageFont.load_default()
    prepared: list[tuple[int, Image.Image, str | None]] = []
    warnings: list[str] = []

    for index, result in enumerate(results, start=1):
        if not result.thumb_url:
            warnings.append(f"Missing thumbnail URL for result {index}.")
            continue
        try:
            prepared.append((index, _open_and_resize(get_bytes(result.thumb_url)), result.title))
        except Exception as exc:  # pragma: no cover - exercised through warning behavior
            warnings.append(f"Failed to build preview tile {index}: {exc}")

    if not prepared:
        return PreviewBuildResult(preview=None, warnings=warnings or ["No preview tiles could be downloaded."])

    title_height = 18  # approximate height for title text line
    heights = [
        image.height + (CARD_PADDING * 2) + (title_height if title else 0)
        for _, image, title in prepared
    ]
    canvas_width = CARD_WIDTH + (CARD_PADDING * 2)
    canvas_height = sum(heights) + (CARD_PADDING * (len(prepared) + 1))
    canvas = Image.new("RGB", (canvas_width, canvas_height), BACKGROUND_COLOR)
    draw = ImageDraw.Draw(canvas)

    cursor_y = CARD_PADDING
    for index, image, title in prepared:
        card_left = CARD_PADDING
        card_top = cursor_y
        card_bottom = card_top + image.height + (CARD_PADDING * 2)
        draw.rounded_rectangle(
            [(card_left, card_top), (card_left + CARD_WIDTH + (CARD_PADDING * 2), card_bottom)],
            radius=16,
            fill=CARD_BACKGROUND,
        )

        image_x = card_left + CARD_PADDING
        image_y = card_top + CARD_PADDING
        canvas.paste(image, (image_x, image_y))

        label_left = image_x + LABEL_MARGIN
        label_top = image_y + LABEL_MARGIN
        label_box = (label_left, label_top, label_left + LABEL_SIZE, label_top + LABEL_SIZE)
        draw.rounded_rectangle(label_box, radius=12, fill=LABEL_FILL)
        label_text = str(index)
        text_width, text_height = _measure_text(draw, label_text, font)
        draw.text(
            (
                label_left + ((LABEL_SIZE - text_width) / 2),
                label_top + ((LABEL_SIZE - text_height) / 2) - 1,
            ),
            label_text,
            font=font,
            fill=LABEL_TEXT,
        )

        if title:
            trimmed = title[:60]
            text_y = image_y + image.height + 4
            draw.text((image_x, text_y), trimmed, font=font, fill=TEXT_COLOR)

        cursor_y = card_bottom + CARD_PADDING

    output = io.BytesIO()
    canvas.save(output, format="JPEG", quality=JPEG_QUALITY, optimize=True)
    encoded = base64.b64encode(output.getvalue()).decode("ascii")
    preview = PreviewPayload(
        mime_type="image/jpeg",
        width=canvas.width,
        height=canvas.height,
        data_base64=encoded,
    )
    return PreviewBuildResult(preview=preview, warnings=warnings)

