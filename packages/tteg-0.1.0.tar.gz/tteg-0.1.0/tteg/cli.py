from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import click

from tteg.preview import build_preview
from tteg.sources import search_unsplash


def _load_env_file() -> None:
    candidates = [
        Path.cwd() / ".env",
        Path.home() / ".config" / "tteg" / ".env",
        Path.home() / ".tteg.env",
    ]
    for env_path in candidates:
        if not env_path.exists():
            continue
        for line in env_path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or "=" not in stripped:
                continue
            key, value = stripped.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
        break  # use first env file found


def _resolve_access_key() -> str:
    return os.environ.get("UNSPLASH_ACCESS_KEY") or os.environ.get("ACCESS_KEY") or ""


def _response_payload(
    *,
    query: str,
    results: list[Any],
    preview_enabled: bool,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "query": query,
        "results": [item.to_dict() for item in results],
        "preview": None,
        "warnings": [],
    }
    if not preview_enabled:
        return payload

    preview_result = build_preview(results)
    if preview_result.preview is not None:
        payload["preview"] = preview_result.preview.to_dict()
    if preview_result.warnings:
        payload["warnings"].extend(preview_result.warnings)
    return payload


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("query")
@click.option("-n", "--count", default=5, show_default=True, type=click.IntRange(1, 10))
@click.option(
    "--orientation",
    type=click.Choice(["any", "landscape", "portrait", "square"], case_sensitive=False),
    default="any",
    show_default=True,
)
@click.option("--width", type=click.IntRange(1, 10000), default=None)
@click.option("--height", type=click.IntRange(1, 10000), default=None)
@click.option("--preview/--no-preview", default=False, show_default=True)
def main(
    query: str,
    count: int,
    orientation: str,
    width: int | None,
    height: int | None,
    preview: bool,
) -> None:
    """Search stock images and return URLs plus an inline preview artifact."""
    _load_env_file()
    access_key = _resolve_access_key()
    if not access_key:
        click.echo("Error: No Unsplash API key found.", err=True)
        click.echo("Set UNSPLASH_ACCESS_KEY env var or put it in .env / ~/.config/tteg/.env", err=True)
        raise SystemExit(1)

    try:
        results = search_unsplash(
            access_key=access_key,
            query=query,
            count=count,
            orientation=orientation,
            width=width,
            height=height,
        )
    except Exception as exc:
        click.echo(f"Error: {exc}", err=True)
        raise SystemExit(1)

    payload = _response_payload(query=query, results=results, preview_enabled=preview)
    click.echo(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

