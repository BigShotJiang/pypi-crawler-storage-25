from __future__ import annotations

import base64
import io
import unittest

from PIL import Image

from tteg.models import ImageResult
from tteg.preview import build_preview


def _make_image_bytes(color: str, size: tuple[int, int] = (120, 80)) -> bytes:
    image = Image.new("RGB", size, color)
    output = io.BytesIO()
    image.save(output, format="JPEG")
    return output.getvalue()


class PreviewTests(unittest.TestCase):
    def test_build_preview_returns_base64_jpeg(self) -> None:
        results = [
            ImageResult(
                id="1",
                source="unsplash",
                image_url="https://example.com/full-1.jpg",
                thumb_url="https://example.com/thumb-1.jpg",
                photographer="Jane",
                width=1200,
                height=800,
                title="First image",
                html_url="https://example.com/page-1",
                download_location="https://example.com/download-1",
            ),
            ImageResult(
                id="2",
                source="unsplash",
                image_url="https://example.com/full-2.jpg",
                thumb_url="https://example.com/thumb-2.jpg",
                photographer="John",
                width=1400,
                height=900,
                title="Second image",
                html_url="https://example.com/page-2",
                download_location="https://example.com/download-2",
            ),
        ]
        image_map = {
            "https://example.com/thumb-1.jpg": _make_image_bytes("#cc5500"),
            "https://example.com/thumb-2.jpg": _make_image_bytes("#0055cc"),
        }

        built = build_preview(results, downloader=image_map.__getitem__)

        self.assertEqual(built.warnings, [])
        self.assertIsNotNone(built.preview)
        assert built.preview is not None
        self.assertEqual(built.preview.mime_type, "image/jpeg")
        decoded = base64.b64decode(built.preview.data_base64)
        image = Image.open(io.BytesIO(decoded))
        self.assertEqual(image.format, "JPEG")
        self.assertGreater(image.width, 0)
        self.assertGreater(image.height, 0)


if __name__ == "__main__":
    unittest.main()

