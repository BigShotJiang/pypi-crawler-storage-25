# tteg

`tteg` is a Python CLI for agent-friendly stock-image search.

Current shape:

- one command
- Unsplash-backed search
- JSON output by default
- inline stitched preview as base64 JPEG

## Setup

`tteg` reads environment variables from the shell and also loads a local `.env` file from the current working directory if present.

Supported keys:

- `UNSPLASH_ACCESS_KEY`
- `ACCESS_KEY` as a fallback alias

## Usage

```bash
python3 -m tteg "mountain sunset"
python3 -m tteg "hero banner" --count 8 --orientation landscape --width 1920 --height 1080
```

Example response shape:

```json
{
  "query": "mountain sunset",
  "results": [
    {
      "id": "abc123",
      "source": "unsplash",
      "image_url": "https://images.unsplash.com/...",
      "thumb_url": "https://images.unsplash.com/...",
      "photographer": "Jane Doe",
      "width": 4000,
      "height": 3000,
      "html_url": "https://unsplash.com/photos/...",
      "download_location": "https://api.unsplash.com/photos/.../download"
    }
  ],
  "preview": {
    "mime_type": "image/jpeg",
    "width": 320,
    "height": 1108,
    "data_base64": "..."
  },
  "warnings": []
}
```

