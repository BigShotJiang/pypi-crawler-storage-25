from enum import Enum
from threading import Thread
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple, Union
from collections import deque
import audioop
import io
import ipaddress
import rfcvoip
import random
import socket
import threading
import time
import warnings


__all__ = [
    "add_bytes",
    "byte_to_bits",
    "DynamicPayloadType",
    "codec_fmtp_supported",
    "codec_priority_score",
    "default_payload_type",
    "fmtp_for_payload_type",
    "is_audio_codec",
    "is_transmittable_audio_codec",
    "is_video_codec",
    "payload_type_from_name",
    "payload_type_media_kind",
    "prioritize_payload_type_map",
    "rtpmap_for_payload_type",
    "reset_codec_priorities",
    "set_codec_priority",
    "PayloadType",
    "select_transmittable_audio_codec",
    "RTPParseError",
    "RTPProtocol",
    "RTPPacketManager",
    "RTPClient",
    "TransmitType",
]

debug = rfcvoip.debug

_DTMF_EVENT_TO_CHAR = [
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "#", "A", "B", "C", "D",
]
_DTMF_CHAR_TO_EVENT = {char: idx for idx, char in enumerate(_DTMF_EVENT_TO_CHAR)}


def byte_to_bits(byte: bytes) -> str:
    if len(byte) != 1:
        raise ValueError(f"byte_to_bits expects 1 byte, got {len(byte)}")
    return format(byte[0], "08b")


def add_bytes(byte_string: bytes) -> int:
    return int.from_bytes(byte_string, "big", signed=False)


class DynamicPayloadType(Exception):
    pass


class RTPParseError(Exception):
    pass


class RTPProtocol(Enum):
    UDP = "udp"
    AVP = "RTP/AVP"
    SAVP = "RTP/SAVP"


class TransmitType(Enum):
    RECVONLY = "recvonly"
    SENDRECV = "sendrecv"
    SENDONLY = "sendonly"
    INACTIVE = "inactive"

    def __str__(self):
        return self.value


class PayloadType(Enum):
    def __new__(
        cls,
        value: Union[int, str],
        clock: int = 0,
        channel: int = 0,
        description: str = "",
    ):
        obj = object.__new__(cls)
        obj._value_ = value
        obj.rate = clock
        obj.channel = channel
        obj.description = description
        return obj

    @property
    def rate(self) -> int:
        return self._rate

    @rate.setter
    def rate(self, value: int) -> None:
        self._rate = value

    @property
    def channel(self) -> int:
        return self._channel

    @channel.setter
    def channel(self, value: int) -> None:
        self._channel = value

    @property
    def description(self) -> str:
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        self._description = value

    def __int__(self) -> int:
        try:
            return int(self.value)
        except ValueError:
            pass
        raise DynamicPayloadType(
            self.description + " is a dynamically assigned payload"
        )

    def __str__(self) -> str:
        if isinstance(self.value, int):
            return self.description
        return str(self.value)

    # Audio
    PCMU = 0, 8000, 1, "PCMU"
    GSM = 3, 8000, 1, "GSM"
    G723 = 4, 8000, 1, "G723"
    DVI4_8000 = 5, 8000, 1, "DVI4"
    DVI4_16000 = 6, 16000, 1, "DVI4"
    LPC = 7, 8000, 1, "LPC"
    PCMA = 8, 8000, 1, "PCMA"
    PCMU_WB = "PCMU-WB", 16000, 1, "PCMU-WB"
    PCMA_WB = "PCMA-WB", 16000, 1, "PCMA-WB"
    G722 = 9, 8000, 1, "G722"
    L16_2 = 10, 44100, 2, "L16"
    L16 = 11, 44100, 1, "L16"
    QCELP = 12, 8000, 1, "QCELP"
    CN = 13, 8000, 1, "CN"
    # MPA channel varries, should be defined in the RTP packet.
    MPA = 14, 90000, 0, "MPA"
    G728 = 15, 8000, 1, "G728"
    DVI4_11025 = 16, 11025, 1, "DVI4"
    DVI4_22050 = 17, 22050, 1, "DVI4"
    G729 = 18, 8000, 1, "G729"
    OPUS = "opus", 48000, 1, "opus"
    SILK_24000 = "SILK/24000", 24000, 1, "SILK"
    SILK_16000 = "SILK/16000", 16000, 1, "SILK"
    SILK_12000 = "SILK/12000", 12000, 1, "SILK"
    SILK_8000 = "SILK/8000", 8000, 1, "SILK"

    # Video
    CELB = 25, 90000, 0, "CelB"
    JPEG = 26, 90000, 0, "JPEG"
    NV = 28, 90000, 0, "nv"
    H261 = 31, 90000, 0, "H261"
    MPV = 32, 90000, 0, "MPV"
    # MP2T is both audio and video per RFC 3551 July 2003 5.7
    MP2T = 33, 90000, 1, "MP2T"
    H263 = 34, 90000, 0, "H263"

    # Non-codec
    EVENT = "telephone-event", 8000, 0, "telephone-event"
    UNKNOWN = "UNKNOWN", 0, 0, "UNKNOWN CODEC"

_AUDIO_PAYLOAD_TYPES = frozenset(
    (
        PayloadType.PCMU,
        PayloadType.GSM,
        PayloadType.G723,
        PayloadType.DVI4_8000,
        PayloadType.DVI4_16000,
        PayloadType.LPC,
        PayloadType.PCMA,
        PayloadType.PCMU_WB,
        PayloadType.PCMA_WB,
        PayloadType.G722,
        PayloadType.L16_2,
        PayloadType.L16,
        PayloadType.QCELP,
        PayloadType.CN,
        PayloadType.MPA,
        PayloadType.G728,
        PayloadType.DVI4_11025,
        PayloadType.DVI4_22050,
        PayloadType.G729,
        PayloadType.OPUS,
        PayloadType.SILK_24000,
        PayloadType.SILK_16000,
        PayloadType.SILK_12000,
        PayloadType.SILK_8000,
        # RFC 3551 defines MP2T as both audio and video.  It is classified as
        # audio here for reporting, but it is intentionally not transmittable
        # because rfcvoip does not implement an MP2T encoder.
        PayloadType.MP2T,
    )
)

_VIDEO_PAYLOAD_TYPES = frozenset(
    (
        PayloadType.CELB,
        PayloadType.JPEG,
        PayloadType.NV,
        PayloadType.H261,
        PayloadType.MPV,
        PayloadType.MP2T,
        PayloadType.H263,
    )
)

def payload_type_media_kind(codec: PayloadType) -> str:
    """Return rfcvoip's broad media classification for an RTP payload type.

    This is deliberately separate from SDP media sections.  A payload such as
    ``telephone-event`` appears inside an ``m=audio`` section, but it is not an
    audio codec that can be selected for the continuous RTP media stream.
    """
    if codec == PayloadType.EVENT:
        return "event"
    if codec == PayloadType.UNKNOWN:
        return "unknown"
    if codec == PayloadType.MP2T:
        return "audio/video"

    try:
        from rfcvoip.codecs import codec_payload_kind

        payload_kind = codec_payload_kind(codec)
        if payload_kind:
            return payload_kind
    except Exception:
        pass

    if codec in _AUDIO_PAYLOAD_TYPES:
        return "audio"
    if codec in _VIDEO_PAYLOAD_TYPES:
        return "video"
    return "unknown"


def is_audio_codec(codec: PayloadType) -> bool:
    """Return whether ``codec`` represents an RTP audio payload type."""
    return payload_type_media_kind(codec) in ("audio", "audio/video")


def is_video_codec(codec: PayloadType) -> bool:
    """Return whether ``codec`` represents an RTP video payload type."""
    return payload_type_media_kind(codec) in ("video", "audio/video")


def codec_priority_score(
    codec: PayloadType,
    priority_scores: Optional[Dict[Any, int]] = None,
) -> int:
    """Return the local preference score for ``codec``.

    Larger scores are preferred when building local SDP offers and when
    selecting a negotiated RTP audio codec. Scores are intentionally separate
    from SDP payload numbers so deployments can tune codec preference without
    changing the wire-level payload mapping.
    """
    if priority_scores is not None:
        for key in (
            codec,
            getattr(codec, "name", None),
            str(codec),
            getattr(codec, "description", None),
            getattr(codec, "value", None),
        ):
            if key is None:
                continue
            try:
                if key in priority_scores:
                    return int(priority_scores[key])
            except (TypeError, ValueError):
                continue

    try:
        from rfcvoip.codecs import codec_priority_score as _priority_score

        return _priority_score(codec)
    except Exception:
        return 0


def set_codec_priority(codec: PayloadType, score: int) -> None:
    """Override a codec priority score for this process."""
    from rfcvoip.codecs import set_codec_priority as _set_codec_priority

    _set_codec_priority(codec, score)
    refresh = getattr(rfcvoip, "refresh_supported_codecs", None)
    if callable(refresh):
        refresh()


def reset_codec_priorities() -> None:
    """Reset all codec priority overrides to their defaults."""
    from rfcvoip.codecs import reset_codec_priorities as _reset_codec_priorities

    _reset_codec_priorities()
    refresh = getattr(rfcvoip, "refresh_supported_codecs", None)
    if callable(refresh):
        refresh()


def prioritize_payload_type_map(
    assoc: Dict[int, PayloadType],
    priority_scores: Optional[Dict[Any, int]] = None,
) -> Dict[int, PayloadType]:
    """Return ``assoc`` ordered by rfcvoip codec priority.

    Ties preserve the input order, which keeps remote SDP order meaningful when
    local scores are equal.
    """
    indexed = list(enumerate(assoc.items()))
    indexed.sort(
        key=lambda item: (
            -codec_priority_score(
                item[1][1],
                priority_scores=priority_scores,
            ),
            item[0],
        )
    )
    return {payload_type: codec for _idx, (payload_type, codec) in indexed}


def codec_fmtp_supported(
    codec: PayloadType,
    fmtp: Optional[List[str]] = None,
) -> bool:
    """Return whether rfcvoip can satisfy negotiated FMTP constraints."""
    try:
        from rfcvoip.codecs import codec_fmtp_supported as _codec_fmtp_supported

        return _codec_fmtp_supported(codec, fmtp or [])
    except Exception:
        return True


def default_payload_type(codec: PayloadType) -> Optional[int]:
    try:
        from rfcvoip.codecs import default_payload_type as _default_payload_type

        return _default_payload_type(codec)
    except Exception:
        try:
            return int(codec)
        except Exception:
            return None


def rtpmap_for_payload_type(payload_type: int, codec: PayloadType) -> str:
    try:
        from rfcvoip.codecs import rtpmap_for_codec

        rtpmap = rtpmap_for_codec(codec, int(payload_type))
        if rtpmap:
            return rtpmap
    except Exception:
        pass

    channels = codec.channel
    channel_suffix = f"/{channels}" if channels and channels > 1 else ""
    return f"{payload_type} {codec}/{codec.rate}{channel_suffix}"


def fmtp_for_payload_type(payload_type: int, codec: PayloadType) -> List[str]:
    try:
        from rfcvoip.codecs import fmtp_for_codec

        return fmtp_for_codec(codec)
    except Exception:
        if codec == PayloadType.EVENT:
            return ["0-15"]
        return []


def is_transmittable_audio_codec(
    codec: PayloadType,
    enabled_codecs: Optional[Any] = None,
) -> bool:
    """Return whether rfcvoip can encode ``codec`` as the main audio stream."""
    compatible_codecs = (
        getattr(rfcvoip, "RTPCompatibleCodecs", ())
        if enabled_codecs is None
        else enabled_codecs
    )
    if codec not in compatible_codecs:  # pragma: no branch
        return False

    try:
        from rfcvoip.codecs import codec_can_transmit_audio

        return codec_can_transmit_audio(codec)
    except Exception:
        return False


def select_transmittable_audio_codec(
    assoc: Dict[int, PayloadType],
    priority_scores: Optional[Dict[Any, int]] = None,
    enabled_codecs: Optional[Any] = None,
) -> Tuple[int, PayloadType]:
    """Select the negotiated payload number and codec used for RTP audio.

    ``assoc`` maps negotiated RTP payload numbers to :class:`PayloadType`
    values.  Returning the negotiated payload number is important when a peer
    maps a known codec, such as PCMU, to a dynamic payload number via SDP
    ``rtpmap``.
    """
    rejected = []
    candidates: List[Tuple[int, int, PayloadType]] = []
    for index, (payload_type, codec) in enumerate(assoc.items()):
        try:
            payload_number = int(payload_type)
        except (TypeError, ValueError):
            rejected.append(f"{payload_type}:{codec} (invalid payload number)")
            continue

        if is_transmittable_audio_codec(
            codec,
            enabled_codecs=enabled_codecs,
        ):
            candidates.append((index, payload_number, codec))
            continue

        rejected.append(
            f"{payload_number}:{codec} ({payload_type_media_kind(codec)})"
        )

    if candidates:
        _index, payload_number, codec = sorted(
            candidates,
            key=lambda item: (
                -codec_priority_score(
                    item[2],
                    priority_scores=priority_scores,
                ),
                item[0],
            ),
        )[0]
        return payload_number, codec

    detail = ": " + ", ".join(rejected) if rejected else "."
    raise RTPParseError("No transmittable audio codec negotiated" + detail)


def _rtpmap_channel_count(codec: PayloadType) -> int:
    try:
        from rfcvoip.codecs import codec_class

        cls = codec_class(codec)
        channels = (
            getattr(cls, "rtpmap_channels", None)
            if cls is not None
            else None
        )
        if channels not in (None, 0, ""):
            return int(channels)
    except Exception:
        pass

    return int(getattr(codec, "channel", 0) or 0)


def payload_type_from_name(
    name: str,
    rate: Optional[Union[int, str]] = None,
    channels: Optional[Union[int, str]] = None,
) -> PayloadType:
    """Return a :class:`PayloadType` matching an SDP codec name.

    SDP ``rtpmap`` lines identify dynamic payloads by encoding names such as
    ``telephone-event`` or ``opus``.  Static payloads are often represented by
    their payload number, but some peers still include an ``rtpmap`` name like
    ``PCMU``.  ``rate`` and ``channels`` disambiguate families with the same
    encoding name, such as ``DVI4`` and ``SILK``.
    """
    needle = str(name or "").strip().lower()
    if not needle:
        raise ValueError("Codec name cannot be empty.")

    desired_rate = None
    if rate not in (None, ""):
        try:
            desired_rate = int(rate)
        except (TypeError, ValueError):
            desired_rate = None

    desired_channels = None
    if channels not in (None, ""):
        try:
            desired_channels = int(channels)
        except (TypeError, ValueError):
            desired_channels = None

    matches = []
    for codec in PayloadType:
        names = {str(codec).lower(), codec.description.lower()}
        if isinstance(codec.value, str):
            names.add(codec.value.lower())
        if needle in names:
            matches.append(codec)

    if not matches:
        raise ValueError(f"RTP Payload type {name!r} not found.")

    if desired_rate is not None:
        rate_matches = [
            codec for codec in matches if int(getattr(codec, "rate", 0)) == desired_rate
        ]
        if rate_matches:
            matches = rate_matches
        else:
            raise ValueError(
                f"RTP Payload type {name!r}/{desired_rate} not found."
            )

    if desired_channels is not None:
        channel_matches = [
            codec
            for codec in matches
            if _rtpmap_channel_count(codec) == desired_channels
        ]
        if channel_matches:
            matches = channel_matches
        else:
            raise ValueError(
                f"RTP Payload type {name!r} with {desired_channels} "
                + "channels not found."
            )

    return matches[0]


class RTPPacketManager:
    def __init__(self):
        self.offset = 4294967296
        """
        The largest number storable in 4 bytes + 1. This will ensure the
        offset adjustment in self.write(offset, data) works.
        """
        self.buffer = io.BytesIO()
        self.bufferLock = threading.RLock()
        self.log = {}
        self.max_log_span = 200000
        self.rebuilding = False

    def _available_locked(self) -> int:
        bufferloc = self.buffer.tell()
        self.buffer.seek(0, 2)
        end = self.buffer.tell()
        self.buffer.seek(bufferloc, 0)
        return max(0, end - bufferloc)

    def available(self) -> int:
        while self.rebuilding:
            time.sleep(0.01)
        with self.bufferLock:
            return self._available_locked()

    def read(self, length: int = 160) -> bytes:
        # This acts functionally as a lock while the buffer is being rebuilt.
        while self.rebuilding:
            time.sleep(0.01)
        with self.bufferLock:
            packet = self.buffer.read(length)
            if len(packet) < length:
                missing = length - len(packet)
                self.buffer.seek(missing, 1)
                packet = packet + (b"\x80" * missing)
        return packet

    def rebuild(self, reset: bool, offset: int = 0, data: bytes = b"") -> None:
        self.rebuilding = True
        try:
            with self.bufferLock:
                if reset:
                    self.offset = offset
                    self.log = {offset: data}
                    self.buffer = io.BytesIO(data)
                    return

                bufferloc = self.buffer.tell()
                old_log = sorted(list(self.log.items()))
                self.buffer = io.BytesIO()
                for pkt, payload in old_log:
                    adjusted_offset = pkt - self.offset
                    if adjusted_offset < 0:
                        continue
                    self.buffer.seek(0, 2)
                    buffer_end = self.buffer.tell()
                    if adjusted_offset > buffer_end:
                        self.buffer.write(b"\x80" * (adjusted_offset - buffer_end))
                    self.buffer.seek(adjusted_offset, 0)
                    self.buffer.write(payload)

                self.buffer.seek(bufferloc, 0)
        finally:
            self.rebuilding = False

    def write(self, offset: int, data: bytes) -> None:
        with self.bufferLock:
            newest = max(max(self.log) if self.log else offset, offset)
            cutoff = newest - self.max_log_span
            if offset < cutoff:
                return

            self.log[offset] = data
            for logged_offset in list(self.log):
                if logged_offset < cutoff:
                    del self.log[logged_offset]
            bufferloc = self.buffer.tell()
            if offset < self.offset:
                """
                If the new timestamp is over 100,000 bytes before the
                earliest, erase the buffer.  This will stop memory errors.
                """
                reset = abs(offset - self.offset) >= 100000
                self.offset = offset
                """
                Rebuilds the buffer if something before the earliest
                timestamp comes in, this will stop overwritting.
                """
                self.rebuild(reset, offset, data)
                return
            else:
                adjusted_offset = offset - self.offset
                if adjusted_offset > self.max_log_span:
                    self.offset = offset
                    self.log = {offset: data}
                    self.buffer = io.BytesIO(data)
                    self.buffer.seek(0, 0)
                    return

                self.buffer.seek(0, 2)
                buffer_end = self.buffer.tell()
                if adjusted_offset > buffer_end:
                    self.buffer.write(b"\x80" * (adjusted_offset - buffer_end))
                self.buffer.seek(adjusted_offset, 0)
                self.buffer.write(data)
                self.buffer.seek(bufferloc, 0)

class RTPMessage:
    def __init__(self, data: bytes, assoc: Dict[int, PayloadType]):
        self.RTPCompatibleVersions = rfcvoip.RTPCompatibleVersions
        self.assoc = assoc
        # Setting defaults to stop mypy from complaining
        self.version = 0
        self.padding = False
        self.extension = False
        self.CC = 0
        self.marker = False
        self.payload_type = PayloadType.UNKNOWN
        self.sequence = 0
        self.timestamp = 0
        self.SSRC = 0
        self.CSRC = []
        self.extension_profile = None
        self.extension_payload = b""

        self.parse(data)

    def summary(self) -> str:
        data = ""
        data += f"Version: {self.version}\n"
        data += f"Padding: {self.padding}\n"
        data += f"Extension: {self.extension}\n"
        data += f"CC: {self.CC}\n"
        data += f"Marker: {self.marker}\n"
        data += (
            f"Payload Type: {self.payload_type} "
            + f"({self.payload_type.value})\n"
        )
        data += f"Sequence Number: {self.sequence}\n"
        data += f"Timestamp: {self.timestamp}\n"
        data += f"SSRC: {self.SSRC}\n"
        return data

    def parse(self, packet: bytes) -> None:
        if len(packet) < 12:
            raise RTPParseError(
                f"RTP packet too short: expected at least 12 bytes, got {len(packet)}"
            )

        byte = byte_to_bits(packet[0:1])
        self.version = int(byte[0:2], 2)
        if self.version not in self.RTPCompatibleVersions:
            raise RTPParseError(f"RTP Version {self.version} not compatible.")
        self.padding = bool(int(byte[2], 2))
        self.extension = bool(int(byte[3], 2))
        self.CC = int(byte[4:], 2)

        byte = byte_to_bits(packet[1:2])
        self.marker = bool(int(byte[0], 2))

        pt = int(byte[1:], 2)
        if pt in self.assoc:
            self.payload_type = self.assoc[pt]
        else:
            try:
                self.payload_type = PayloadType(pt)
                e = False
            except ValueError:
                e = True
            if e:
                raise RTPParseError(f"RTP Payload type {pt} not found.")

        self.sequence = add_bytes(packet[2:4])
        self.timestamp = add_bytes(packet[4:8])
        self.SSRC = add_bytes(packet[8:12])

        self.CSRC = []

        i = 12
        if len(packet) < i + (self.CC * 4):
            raise RTPParseError("RTP packet truncated in CSRC list.")

        for x in range(self.CC):
            self.CSRC.append(packet[i : i + 4])
            i += 4

        if self.extension:
            if len(packet) < i + 4:
                raise RTPParseError("RTP packet truncated in extension header.")
            self.extension_profile = add_bytes(packet[i : i + 2])
            extension_length = add_bytes(packet[i + 2 : i + 4]) * 4
            i += 4
            if len(packet) < i + extension_length:
                raise RTPParseError("RTP packet truncated in extension payload.")
            self.extension_payload = packet[i : i + extension_length]
            i += extension_length

        payload = packet[i:]
        if self.padding:
            if not payload:
                raise RTPParseError("RTP packet padding flag set without payload.")
            padding_length = payload[-1]
            if padding_length == 0 or padding_length > len(payload):
                raise RTPParseError("RTP packet contains invalid padding.")
            payload = payload[:-padding_length]

        self.payload = payload


class RTPClient:
    def __init__(
        self,
        assoc: Dict[int, PayloadType],
        inIP: str,
        inPort: int,
        outIP: str,
        outPort: int,
        sendrecv: TransmitType,
        dtmf: Optional[Callable[[str], None]] = None,
        audio_sample_rate: Optional[int] = None,
        audio_sample_width: int = 1,
        audio_channels: int = 1,
        codec_priority_scores: Optional[Dict[Any, int]] = None,
        enabled_codecs: Optional[Any] = None,
    ):
        self._running = threading.Event()
        self._socket_lock = threading.RLock()
        self.NSD = False
        # Example: {0: PayloadType.PCMU, 101: PayloadType.EVENT}
        self.assoc = assoc
        try:
            self.sendrecv = (
                sendrecv
                if isinstance(sendrecv, TransmitType)
                else TransmitType(str(sendrecv))
            )
        except ValueError as ex:
            raise RTPParseError(
                f"Unsupported RTP transmit type {sendrecv!r}."
            ) from ex
        self._codec_adapters: Dict[PayloadType, Any] = {}
        self.codec_priority_scores = dict(codec_priority_scores or {})
        self.enabled_codecs = (
            None if enabled_codecs is None else tuple(enabled_codecs)
        )
        debug("Selecting negotiated audio codec for transmission")
        try:
            (
                self.preference_payload_type,
                self.preference,
            ) = select_transmittable_audio_codec(
                assoc,
                priority_scores=self.codec_priority_scores,
                enabled_codecs=self.enabled_codecs,
            )
        except RTPParseError:
            debug(
                "No transmittable audio codec negotiated from assoc="
                + ",".join(f"{pt}:{codec}" for pt, codec in assoc.items())
             )
            raise
        debug(
            f"Selected {self.preference} "
            + f"as RTP payload {self.preference_payload_type}"
        )
        self.audio_sample_rate = self._resolve_audio_sample_rate(
            audio_sample_rate
        )
        try:
            self.audio_sample_width = int(audio_sample_width)
            self.audio_channels = int(audio_channels)
        except (TypeError, ValueError) as ex:
            raise RTPParseError(
                "Public RTP audio format values must be integers."
            ) from ex
        if self.audio_sample_width != 1 or self.audio_channels != 1:
            raise RTPParseError(
                "rfcvoip public audio currently supports unsigned 8-bit mono; "
                "only the sample rate is configurable."
            )

        self.inIP = inIP
        self.inPort = inPort
        self.outIP = outIP
        self.outPort = outPort
        self._socket_family = self._select_socket_family(inIP, outIP)

        self.dtmf = dtmf

        self.pmout = RTPPacketManager()  # To Send
        self.pmin = RTPPacketManager()  # Received
        self.outOffset = random.randint(1, 5000)

        self.outSequence = random.randint(1, 100)
        self.outTimestamp = random.randint(1, 10000)
        self.outSSRC = random.randint(1000, 65530)
        self._telephone_event_pt = self._find_telephone_event_payload_type()
        self._pending_dtmf: Deque[str] = deque()
        self._dtmf_lock = threading.Lock()

    @staticmethod
    def _preferred_source_sample_rate(codec: PayloadType) -> int:
        try:
            from rfcvoip.codecs import codec_class

            cls = codec_class(codec)
            if cls is not None:
                rate = getattr(
                    cls,
                    "preferred_source_sample_rate",
                    getattr(cls, "source_sample_rate", None),
                )
                if rate:
                    return int(rate)
        except Exception:
            pass

        return int(getattr(codec, "rate", 8000) or 8000)

    def _resolve_audio_sample_rate(
        self, audio_sample_rate: Optional[int]
    ) -> int:
        sample_rate = (
            self._preferred_source_sample_rate(self.preference)
            if audio_sample_rate is None
            else audio_sample_rate
        )
        try:
            sample_rate = int(sample_rate)
        except (TypeError, ValueError) as ex:
            raise RTPParseError("Audio sample rate must be an integer.") from ex
        if sample_rate <= 0:
            raise RTPParseError("Audio sample rate must be positive.")
        return sample_rate

    def _codec_adapter(self, codec: PayloadType):
        adapter = self._codec_adapters.get(codec)
        if adapter is not None:
            return adapter

        from rfcvoip.codecs import create_codec

        adapter = create_codec(
            codec,
            source_sample_rate=self.audio_sample_rate,
            source_sample_width=self.audio_sample_width,
            source_channels=self.audio_channels,
        )
        if adapter is None:
            raise RTPParseError(f"No codec implementation for {codec}.")

        self._codec_adapters[codec] = adapter
        return adapter

    def audio_frame_size(self, duration_ms: Optional[int] = None) -> int:
        return self._codec_adapter(self.preference).source_frame_size(
            duration_ms
        )

    def _find_telephone_event_payload_type(self) -> Optional[int]:
        for payload_type, codec in self.assoc.items():
            if codec == PayloadType.EVENT:
                try:
                    return int(payload_type)
                except Exception:
                    continue
        return None

    def _build_rtp_packet(
        self,
        payload_type: int,
        payload: bytes,
        *,
        marker: bool,
        timestamp: int,
    ) -> bytes:
        try:
            payload_type = int(payload_type)
        except (TypeError, ValueError) as ex:
            raise RTPParseError(
                f"RTP payload type must be an integer, got {payload_type!r}."
            ) from ex

        if payload_type < 0 or payload_type > 127:
            raise RTPParseError(
                f"RTP payload type must be between 0 and 127, got {payload_type}."
            )

        packet = b"\x80"
        packet += (((0x80 if marker else 0x00) | (payload_type & 0x7F))).to_bytes(1, 'big')
        packet += (self.outSequence & 0xFFFF).to_bytes(2, 'big')
        packet += (timestamp & 0xFFFFFFFF).to_bytes(4, 'big')
        packet += (self.outSSRC & 0xFFFFFFFF).to_bytes(4, 'big')
        packet += payload
        return packet

    def _send_rtp_packet(
        self,
        payload_type: int,
        payload: bytes,
        *,
        marker: bool,
        timestamp: int,
    ) -> None:
        packet = self._build_rtp_packet(payload_type, payload, marker=marker, timestamp=timestamp)
        with self._socket_lock:
            sout = getattr(self, "sout", None)
        if sout is None or not self.NSD:
            return
        try:
            sout.sendto(
                packet,
                self._socket_address(self.outIP, self.outPort),
            )
        except OSError:
            if self.NSD:
                warnings.warn(
                    "RTP Packet failed to send!",
                    RuntimeWarning,
                    stacklevel=2,
                )
        self.outSequence = (self.outSequence + 1) & 0xFFFF

    def _build_telephone_event_payload(
        self,
        event_code: int,
        duration: int,
        *,
        end: bool,
        volume: int,
    ) -> bytes:
        return bytes([
            event_code & 0xFF,
            ((0x80 if end else 0x00) | (volume & 0x3F)),
            (duration >> 8) & 0xFF,
            duration & 0xFF,
        ])

    @staticmethod
    def _ip_version(address: str) -> Optional[int]:
        try:
            text = str(address or "").strip().strip("[]")
            if text in ("", "0.0.0.0", "::"):
                return None
            return ipaddress.ip_address(text).version
        except ValueError:
            return None

    @classmethod
    def _select_socket_family(cls, inIP: str, outIP: str):
        in_version = cls._ip_version(inIP)
        out_version = cls._ip_version(outIP)

        if (
            in_version is not None
            and out_version is not None
            and in_version != out_version
        ):
            raise RTPParseError(
                f"RTP local address {inIP!r} and remote address {outIP!r} "
                + "use different IP versions."
            )

        version = in_version or out_version or 4
        return socket.AF_INET6 if version == 6 else socket.AF_INET

    def _socket_address(self, host: str, port: int):
        host = str(host or "").strip().strip("[]")
        if self._socket_family == socket.AF_INET6:
            if host in ("", "0.0.0.0", "::"):
                host = "::"
            return (host, port, 0, 0)
        if host in ("", "0.0.0.0", "::"):
            host = "0.0.0.0"
        return (host, port)

    def sendDTMF(self, code: str) -> bool:
        warnings.warn(
            "sendDTMF is deprecated due to PEP8 compliance. Use send_dtmf instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.send_dtmf(code)

    def send_dtmf(self, code: str) -> bool:
        code = str(code or '').strip().upper()
        if code not in _DTMF_CHAR_TO_EVENT:
            return False
        if self._telephone_event_pt is None:
            return False
        with self._dtmf_lock:
            self._pending_dtmf.append(code)
        return True

    @property
    def NSD(self) -> bool:
        return self._running.is_set()

    @NSD.setter
    def NSD(self, running: bool) -> None:
        if running:
            self._running.set()
        else:
            self._running.clear()

    def transmit_dtmf(
        self,
        code: str,
        *,
        duration_ms: int = 200,
        packet_ms: int = 50,
        volume: int = 10,
    ) -> bool:
        if self._telephone_event_pt is None:
            return False

        code = str(code or '').strip().upper()
        if code not in _DTMF_CHAR_TO_EVENT:
            return False

        clock = 8000
        audio_clock = int(
            getattr(self._codec_adapter(self.preference), "rate", clock)
        )
        event_code = _DTMF_CHAR_TO_EVENT[code]
        start_timestamp = self.outTimestamp & 0xFFFFFFFF
        total_duration = max(1, int((duration_ms * clock) / 1000))
        step = max(1, int((packet_ms * clock) / 1000))
        interval_s = max(0.01, packet_ms / 1000.0)

        first_duration = min(step, total_duration)
        first_payload = self._build_telephone_event_payload(
            event_code, first_duration, end=False, volume=volume
        )
        self._send_rtp_packet(
            self._telephone_event_pt,
            first_payload,
            marker=True,
            timestamp=start_timestamp,
        )

        elapsed = first_duration
        while elapsed + step < total_duration and self.NSD:
            time.sleep(interval_s)
            elapsed += step
            payload = self._build_telephone_event_payload(
                event_code, elapsed, end=False, volume=volume
            )
            self._send_rtp_packet(
                self._telephone_event_pt,
                payload,
                marker=False,
                timestamp=start_timestamp,
            )

        final_payload = self._build_telephone_event_payload(
            event_code, total_duration, end=True, volume=volume
        )
        for repeat in range(3):
            if not self.NSD:
                break
            time.sleep(interval_s)
            self._send_rtp_packet(
                self._telephone_event_pt,
                final_payload,
                marker=False,
                timestamp=start_timestamp,
            )

        audio_timestamp_advance = max(
            1,
            int(round((total_duration / clock) * audio_clock)),
        )
        self.outTimestamp = (
            start_timestamp + audio_timestamp_advance
        ) & 0xFFFFFFFF
        return True

    def start(self) -> None:
        if self.NSD:
            raise RuntimeError("Attempted to start already started RTPClient")

        sin = socket.socket(self._socket_family, socket.SOCK_DGRAM)
        try:
            sin.bind(self._socket_address(self.inIP, self.inPort))
            sin.setblocking(False)
        except Exception:
            sin.close()
            raise

        with self._socket_lock:
            if self.NSD:
                sin.close()
                raise RuntimeError("Attempted to start already started RTPClient")
            self.sin = sin
            # Some systems just reply to the port they receive from instead of
            # listening to the SDP.
            self.sout = self.sin

        self.NSD = True
        r = Thread(target=self.recv, name="RTP Receiver", daemon=True)
        r.start()
        t = Thread(target=self.trans, name="RTP Transmitter", daemon=True)
        t.start()

    def stop(self) -> None:
        self.NSD = False
        with self._socket_lock:
            sin = getattr(self, "sin", None)
            sout = getattr(self, "sout", None)
            self.sin = None
            self.sout = None

        if sin is not None:
            sin.close()
        if sout is not None and sout is not sin:
            sout.close()

    def read(
        self,
        length: Optional[int] = None,
        blocking: bool = True,
    ) -> bytes:
        if length is None:
            length = self.audio_frame_size()
        if not blocking:
            return self.pmin.read(length)
        while self.pmin.available() < length and self.NSD:
            time.sleep(0.01)
        return self.pmin.read(length)

    def write(self, data: bytes) -> None:
        self.pmout.write(self.outOffset, data)
        self.outOffset += len(data)

    def recv(self) -> None:
        while self.NSD:
            try:
                sin = getattr(self, "sin", None)
                if sin is None:
                    time.sleep(0.01)
                    continue
                packet = sin.recv(8192)
                self.parse_packet(packet)
            except BlockingIOError:
                time.sleep(0.01)
            except RTPParseError as e:
                debug(str(e))
            except OSError:
                pass

    def trans(self) -> None:
        while self.NSD:
            if self.sendrecv in (TransmitType.RECVONLY, TransmitType.INACTIVE):
                time.sleep(0.02)
                continue

            with self._dtmf_lock:
                pending_dtmf = self._pending_dtmf.popleft() if self._pending_dtmf else None
            if pending_dtmf is not None:
                self.transmit_dtmf(pending_dtmf)
                continue

            last_sent = time.monotonic_ns()
            adapter = self._codec_adapter(self.preference)
            raw_payload = self.pmout.read(adapter.source_frame_size())
            try:
                payload = adapter.encode(raw_payload)
            except Exception as ex:
                warnings.warn(
                    f"RTP audio encode failed for {self.preference}: {ex}",
                    RuntimeWarning,
                    stacklevel=2,
                )
                time.sleep(0.02)
                continue
            timestamp = self.outTimestamp & 0xFFFFFFFF
            self._send_rtp_packet(
                self.preference_payload_type,
                payload,
                marker=False,
                timestamp=timestamp,
            )
            self.outTimestamp = (
                self.outTimestamp
                + adapter.rtp_timestamp_increment(raw_payload, payload)
            ) & 0xFFFFFFFF
            # Calculate how long it took to generate this packet.
            # Then how long we should wait to send the next, then devide by 2.
            delay = adapter.packet_duration_seconds(raw_payload)
            sleep_time = max(
                0, delay - ((time.monotonic_ns() - last_sent) / 1000000000)
            )
            time.sleep(sleep_time / self.trans_delay_reduction)

    @property
    def trans_delay_reduction(self) -> float:
        try:
            reduction = float(rfcvoip.TRANSMIT_DELAY_REDUCTION) + 1.0
        except (TypeError, ValueError):
            return 1.0
        return reduction if reduction > 0 else 1.0

    def parsePacket(self, packet: bytes) -> None:
        warnings.warn(
            "parsePacket is deprecated due to PEP8 compliance. "
            + "Use parse_packet instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.parse_packet(packet)

    def parse_packet(self, packet: bytes) -> None:
        msg = RTPMessage(packet, self.assoc)
        if msg.payload_type == PayloadType.EVENT:
            self.parse_telephone_event(msg)
        elif is_audio_codec(msg.payload_type):
            self.parse_audio(msg)
        else:
            raise RTPParseError(
                "Unsupported codec (parse): " + str(msg.payload_type)
            )

    def parse_audio(
        self,
        packet: RTPMessage,
        codec: Optional[PayloadType] = None,
    ) -> None:
        codec = codec or packet.payload_type
        adapter = self._codec_adapter(codec)
        try:
            data = adapter.decode(packet.payload)
        except Exception as ex:
            raise RTPParseError(
                f"RTP audio decode failed for {codec}: {ex}"
            ) from ex
        self.pmin.write(adapter.output_offset(packet.timestamp), data)

    def encodePacket(self, payload: bytes) -> bytes:
        warnings.warn(
            "encodePacket is deprecated due to PEP8 compliance. "
            + "Use encode_packet instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.encode_packet(payload)

    def encode_packet(self, payload: bytes) -> bytes:
        return self._codec_adapter(self.preference).encode(payload)

    def parsePCMU(self, packet: RTPMessage) -> None:
        warnings.warn(
            "parsePCMU is deprecated due to PEP8 compliance. "
            + "Use parse_pcmu instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.parse_pcmu(packet)

    def parse_pcmu(self, packet: RTPMessage) -> None:
        self.parse_audio(packet, PayloadType.PCMU)

    def encodePCMU(self, packet: bytes) -> bytes:
        warnings.warn(
            "encodePCMU is deprecated due to PEP8 compliance. "
            + "Use encode_pcmu instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.encode_pcmu(packet)

    def encode_pcmu(self, packet: bytes) -> bytes:
        return self._codec_adapter(PayloadType.PCMU).encode(packet)

    def parsePCMA(self, packet: RTPMessage) -> None:
        warnings.warn(
            "parsePCMA is deprecated due to PEP8 compliance. "
            + "Use parse_pcma instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.parse_pcma(packet)

    def parse_pcma(self, packet: RTPMessage) -> None:
        self.parse_audio(packet, PayloadType.PCMA)

    def encodePCMA(self, packet: bytes) -> bytes:
        warnings.warn(
            "encodePCMA is deprecated due to PEP8 compliance. "
            + "Use encode_pcma instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.encode_pcma(packet)

    def encode_pcma(self, packet: bytes) -> bytes:
        return self._codec_adapter(PayloadType.PCMA).encode(packet)

    def parseTelephoneEvent(self, packet: RTPMessage) -> None:
        warnings.warn(
            "parseTelephoneEvent "
            + "is deprecated due to PEP8 compliance. "
            + "Use parse_telephone_event instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.parse_telephone_event(packet)

    def parse_telephone_event(self, packet: RTPMessage) -> None:
        payload = packet.payload
        if len(payload) < 4:
            raise RTPParseError("telephone-event payload too short.")
        event_code = payload[0]
        if event_code >= len(_DTMF_EVENT_TO_CHAR):
            raise RTPParseError(
                f"Unsupported telephone-event code {event_code}."
            )
        event = _DTMF_EVENT_TO_CHAR[event_code]
        """
        Commented out the following due to F841 (Unused variable).
        Might use at some point though, so I'm saving the logic.

        byte = byte_to_bits(payload[1:2])
        end = (byte[0] == '1')
        volume = int(byte[2:], 2)
        """

        if packet.marker:
            if self.dtmf is not None:
                self.dtmf(event)
