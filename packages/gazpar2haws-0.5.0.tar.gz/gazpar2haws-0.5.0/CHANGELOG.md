# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.0] - 2026-02-08

### Fixed

- [#105](https://github.com/ssenart/gazpar2haws/issues/105): Fixed segmentation fault (exit code 139)** by upgrading to Alpine 3.23 with manual Python installation
  - Switched from pre-installed Python base images to Alpine base images without Python
  - Manually install latest Python 3.x available in Alpine 3.23 (currently 3.12.x)
  - Improved stability on ARM architectures (aarch64)

- [#97](https://github.com/ssenart/gazpar2haws/issues/97): Specify `unit_class` and `mean_type` in statistics metadata to ensure proper sensor classification and display in Home Assistant

### Added

- [#108](https://github.com/ssenart/gazpar2haws/issues/108): **Flexible pricing components** - Define unlimited custom pricing component names instead of being limited to 4 hardcoded names
  - Unlimited number of components (not just 4: consumption, subscription, transport, taxes)
  - Custom component names that reflect your actual billing structure (e.g., `carbon_tax`, `distribution_cost`, `peak_rate`)
  - Flat YAML structure - no nested `components` dict, just add components directly under `pricing:`
  - Automatic Home Assistant sensor creation for each component
  - 100% backward compatible - existing configurations continue to work without changes
  - Legacy sensor names preserved (e.g., `consumption_prices` → `sensor.name_consumption_cost`)
  - Comprehensive documentation in [docs/FLEXIBLE_PRICING_GUIDE.md](docs/FLEXIBLE_PRICING_GUIDE.md)
  - Example configuration with 7 custom components in [tests/config/example_8.yaml](tests/config/example_8.yaml)
- Dynamic component cost start date logging for better debugging
- pytest-asyncio configuration for async test support
- Pricing model now uses flat structure with `vat` as special field and all other fields as pricing components
- CostBreakdown model updated to support dynamic components with backward-compatible property access
- Pricer refactored to process components dynamically instead of hardcoded logic
- Home Assistant integration generates sensors dynamically based on component names

- Home Assistant add-on development reference links in developer guide
  - Official HA documentation links (Apps, Tutorial, Configuration, Security, i18n)
  - Example repository references
  - Docker base image documentation
  - Community resources and related issues
- Comprehensive implementation plan documentation


### Changed

- **Base images**: Migrated from `{arch}-base-python:3.12-alpine3.20` to `{arch}-base:3.23` (Alpine base without Python)
- **Python installation**: Now manually installed via `apk add python3 py3-pip` in Dockerfile
- **Architecture support**: Building for aarch64 and amd64 only (legacy 32-bit architectures armhf, armv7, i386 are no longer supported by Home Assistant)
- **Dockerfile improvements**:
  - Combined package installation into single RUN layer for efficiency
  - Combined chmod commands into single RUN layer
  - Added comprehensive comments explaining each package
- **DevContainer**: Updated to `ghcr.io/home-assistant/devcontainer:2-addons` with improved configuration

- [#103](https://github.com/ssenart/gazpar2haws/issues/103): Cost statistics now use ISO 4217 currency codes (EUR) instead of symbols (€) for Home Assistant integration. This improves standards compliance and ensures proper currency display across Home Assistant interfaces. The domain model continues to use currency symbols internally, maintaining clean separation between business logic and integration layers.

### Technical Details

- **Base images**: `ghcr.io/home-assistant/{arch}-base:3.23` (Alpine 3.23 without Python pre-installed)
- **Python version**: Latest available in Alpine 3.23 (currently 3.12.x, manually installed)
- **Pattern**: Aligned with official Home Assistant example add-on approach
- **Issue resolution**: Manual Python installation provides better compatibility than pre-installed Python images

## [0.4.0] - 2025-10-30

### Added

- [#83](https://github.com/ssenart/gazpar2haws/issues/83): Composite price model with dual components - supports both quantity-based (€/kWh) and time-based (€/month) pricing
- [#83](https://github.com/ssenart/gazpar2haws/issues/83): Quantity-based transport pricing (€/kWh) support in addition to fixed time-based fees (€/year)
- [#83](https://github.com/ssenart/gazpar2haws/issues/83): Enhanced cost breakdown with separate Home Assistant entities for detailed cost analysis:
  - `sensor.${name}_consumption_cost` - Consumption cost component
  - `sensor.${name}_subscription_cost` - Subscription fees component
  - `sensor.${name}_transport_cost` - Transport/delivery fees component
  - `sensor.${name}_energy_taxes_cost` - Energy taxes component
  - `sensor.${name}_total_cost` - Total of all cost components
- Unified pricing API with single `get_composite_price_array()` method and `CostBreakdown` output model
- Automatic sensor migration from v0.3.x `sensor.${name}_cost` to v0.4.0 `sensor.${name}_total_cost` with smart detection and data preservation
- Comprehensive [MIGRATIONS.md](MIGRATIONS.md) guide with step-by-step instructions, examples, and troubleshooting
- Entity names in Home Assistant now properly reflect the sensor type (e.g., "Gazpar2HAWS Energy", "Gazpar2HAWS Volume")

### Changed

- **BREAKING**: Pricing configuration format changed. **See [MIGRATIONS.md](MIGRATIONS.md)** for migration instructions:
  - `value` → `quantity_value` or `time_value`
  - `value_unit` → `price_unit`
  - `base_unit` → `quantity_unit` or `time_unit`
- `Pricer.compute()` now returns `CostBreakdown` object with 5 separate cost components instead of single value
- Cost statistics publishing expanded from 1 entity to 5 entities (consumption, subscription, transport, energy_taxes, total)

### Fixed

- Fixed Home Assistant statistics metadata to include proper entity names instead of generic "gazpar2haws" - statistics now display as "Gazpar2HAWS Energy", "Gazpar2HAWS Volume", etc.

### Migration

Users upgrading from v0.3.x must update their pricing configuration to the new format.

**See [MIGRATIONS.md](MIGRATIONS.md)** for complete migration guide including:
- Step-by-step configuration migration with 7 detailed examples
- Quick reference table for property mapping
- Automatic sensor migration (no user action required)
- Validation checklist
- Troubleshooting common issues

## [0.3.3] - 2025-07-22

### Changed

[#77](https://github.com/ssenart/gazpar2haws/issues/77): Upgrade PyGazpar library version to 1.3.1.

## [0.3.2] - 2025-03-28

### Fixed

[#70](https://github.com/ssenart/gazpar2haws/issues/70): Remove as_of_date configuration property in default configuration template file.

## [0.3.1] - 2025-03-03

### Fixed

[#64](https://github.com/ssenart/gazpar2haws/issues/64): Data is always retrieved up to the application start date instead of up to now.

## [0.3.0] - 2025-02-15

### Added

[#31](https://github.com/ssenart/gazpar2haws/issues/31): Cost integration.

### Changed

[#60](https://github.com/ssenart/gazpar2haws/issues/60): Upgrade PyGazpar library version to 1.3.0.

## [0.2.1] - 2025-01-24

### Fixed

[#57](https://github.com/ssenart/gazpar2haws/issues/57): The addon configuration is the wrong format (still the old one).

## [0.2.0] - 2025-01-23

### Changed

[#55](https://github.com/ssenart/gazpar2haws/issues/55): Change HA addon configuration format to match gazpar2haws file configuration format.

## [0.1.14] - 2025-01-17

### Fixed

[#50](https://github.com/ssenart/gazpar2haws/issues/50): In dockerhub, version displayed in log file is wrong and always N-1.

## [0.1.13] - 2025-01-16

### Fixed

[#47](https://github.com/ssenart/gazpar2haws/issues/47): 'reset' configuration parameter is ignored in the addon configuration panel.

## [0.1.12] - 2025-01-15

### Fixed

[#37](https://github.com/ssenart/gazpar2haws/issues/37): Error GrDF send missing data with type="Absence de Données".

[#38](https://github.com/ssenart/gazpar2haws/issues/38): Using the HA addon, the PCE identifier is transformed into another number.

[#36](https://github.com/ssenart/gazpar2haws/issues/36): Error if HA endpoint configuration is missing in configuration.yaml.

### Added

[#33](https://github.com/ssenart/gazpar2haws/issues/33): Dockerhub 'latest' tag is currently published only if the release is created in the main branch.

## [0.1.11] - 2025-01-12

### Fixed

[#32](https://github.com/ssenart/gazpar2haws/issues/32): Fix fatal happening after introducing as_of_date for tests.

## [0.1.10] - 2025-01-11

### Fixed

[#28](https://github.com/ssenart/gazpar2haws/issues/28): Fix the code lint warning messages.

### Added

[#27](https://github.com/ssenart/gazpar2haws/issues/27): In a Github workflow, run unit tests against a HA container.

## [0.1.9] - 2025-01-10

### Fixed

[#26](https://github.com/ssenart/gazpar2haws/issues/26): Fix broken HA addons update.

## [0.1.8] - 2025-01-10

### Added

[#20](https://github.com/ssenart/gazpar2haws/issues/20): Automate build, package, publish with Github Actions.

## [0.1.7] - 2025-01-05

### Fixed

[#18](https://github.com/ssenart/gazpar2haws/issues/18): Regression on DockerHub deployment.

## [0.1.6] - 2025-01-05

### Added

[#4](https://github.com/ssenart/gazpar2haws/issues/4): Deploy gazpar2haws as an HA add-on.

## [0.1.5] - 2025-01-04

### Added

[#15](https://github.com/ssenart/gazpar2haws/issues/15): Using HassIO, websocket endpoint is /core/websocket.

## [0.1.4] - 2025-01-04

### Fixed

[#13](https://github.com/ssenart/gazpar2haws/issues/13): Using HassIO, connection to the supervisor requires Authorization header.

## [0.1.3] - 2025-01-03

### Changed

[#11](https://github.com/ssenart/gazpar2haws/issues/11): Upgrade PyGazpar version to 1.2.6.

## [0.1.2] - 2024-12-30

### Added

[#2](https://github.com/ssenart/gazpar2haws/issues/2): DockerHub deployment.

### Fixed

[#9](https://github.com/ssenart/gazpar2haws/issues/9): Incorrect timezone info creates duplicate import.

[#6](https://github.com/ssenart/gazpar2haws/issues/6): The last meter value may be imported multiple times and cause the today value being wrong.

[#3](https://github.com/ssenart/gazpar2haws/issues/3): reset=false makes the meter import to restart from zero.

## [0.1.1] - 2024-12-22

### Added

[#1](https://github.com/ssenart/gazpar2haws/issues/1): Publish energy indicator in kWh.

## [0.1.0] - 2024-12-21

First version of the project.
