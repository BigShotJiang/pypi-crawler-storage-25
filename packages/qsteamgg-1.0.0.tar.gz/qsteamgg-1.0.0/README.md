# SteamGG CLI

Interactive CLI tool for searching, downloading and extracting games from steamgg.net.

**Pure Python implementation - works on any system without external dependencies!**

## Installation

```bash
pip install qsteamgg
```

## Usage

After installation, use the `steamgg` command:

```bash
steamgg
```

Or run as a module:

```bash
python -m steamgg_cli
```

## Features

- 🔍 **Search** games from steamgg.net using the built-in search
- 📋 **Paginated table view** with rich formatting
- ⬇️ **Download** from buzzheavier with progress bar
- 📦 **Automatic extraction** using pure Python (zip, tar, gz, bz2, xz)
- 🗑️ **Optional archive cleanup** after extraction
- 🎯 **Smart UX** - fetch download links only when needed

## Quick Start

```bash
# Install
pip install qsteamgg

# Run
steamgg

# Then:
# 1. Enter a search term (e.g., "attack on titan") or press Enter to skip
# 2. Browse results with n/p for next/prev page
# 3. Enter game number to select
# 4. Choose "download" to download and extract
```

## Navigation Commands

| Command | Description |
|---------|-------------|
| `n`, `next` | Next page |
| `p`, `prev` | Previous page |
| `s`, `search` | Search games by name |
| `r`, `refresh` | Refresh games list |
| `1-999` | Select game by number |
| `h`, `help` | Show help |
| `q`, `quit` | Exit |

### After Selecting a Game

| Command | Description |
|---------|-------------|
| `download` (default) | Download selected game |
| `back` | Return to games list |
| `help` | Show help |
| `quit` | Exit |

## Directory Structure

Games are downloaded to `./Games/` directory in the current working directory:

```
./Games/
├── downloads/      # Temporary download folder
└── <game_name>/    # Extracted games
```

## Supported Archive Formats (Pure Python)

| Format | Support | Module |
|--------|---------|--------|
| `.zip` | ✓ Full | `zipfile` |
| `.tar` | ✓ Full | `tarfile` |
| `.tar.gz`, `.tgz` | ✓ Full | `tarfile` + `gzip` |
| `.tar.bz2` | ✓ Full | `tarfile` + `bz2` |
| `.tar.xz` | ✓ Full | `tarfile` + `lzma` |
| `.gz` | ✓ Full | `gzip` |
| `.bz2` | ✓ Full | `bz2` |
| `.xz` | ✓ Full | `lzma` |
| `.rar` | ⚠ Limited | Requires unrar |
| `.7z` | ⚠ Limited | Requires py7zr |

### Notes on RAR and 7z

**RAR** is a proprietary format. For full RAR support:
```bash
pip install rarfile
# macOS: brew install unrar
```

**7z** is complex. For full 7z support:
```bash
pip install py7zr
```

## Example Session

```
$ steamgg

╭─────────────────────────────────────────────────────╮
│  SteamGG CLI                                        │
│  Search, download & extract games from steamgg.net  │
│  Pure Python - System Agnostic                      │
╰─────────────────────────────────────────────────────╯

━ Step 1: Search Games ━

Enter search term (or press Enter to skip) (): attack on titan
Step 1: Searching for 'attack on titan' on steamgg.net...
✓ Found 15 games

                  Search: 'attack on titan' - Results 1-2 of 2                  
╭──────┬────────────────────────────────────────────────┬──────────────────────╮
│    # │ Title                                          │ Status               │
├──────┼────────────────────────────────────────────────┼──────────────────────┤
│    1 │ Attack on Titan 2 Final Battle Free Download   │ ✓ Ready              │
│    2 │ Attack on Titan Wings of Freedom Free Download │ ✓ Ready              │
╰──────┴────────────────────────────────────────────────┴──────────────────────╯

Navigation: n=next p=prev s=search r=refresh 1-999=select h=help q=quit

Enter command (): 1

════════════════════════════════════════════════════════════
╭───────────────────────── Game Details ──────────────────────────╮
│ Attack on Titan 2 Final Battle Free Download (Incl All DLCs)    │
╰──────────────────────────────────────────────────────────────────╯

Options [download/back/help/quit] (download): download

Fetching download info for: Attack on Titan 2...
✓ Buzzheavier: https://buzzheavier.com/xxx
✓ Download URL ready

Download filename [Attack_on_Titan_2.zip]: 
Extraction folder [Attack_on_Titan_2]: 

Start download? [Y/n]: Y

Downloading... 100% ████████████████████
✓ Download complete!
Extracting...
✓ Extraction complete!

✓ SUCCESS! Game installed to: ./Games/Attack_on_Titan_2
```

## Requirements

- Python 3.8+
- No system-level dependencies required!

## Troubleshooting

**Connection timeout**
- Check your internet connection
- The site might be temporarily unavailable

**Download fails**
- buzzheavier links may expire - try selecting the game again

**RAR/7z extraction fails**
- Install optional dependencies:
  ```bash
  pip install rarfile py7zr
  ```

**Permission denied**
- Make sure you have write permissions in the directory
- Try running from a different location

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
