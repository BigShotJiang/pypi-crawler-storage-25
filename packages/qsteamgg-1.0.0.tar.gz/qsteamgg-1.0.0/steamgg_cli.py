#!/usr/bin/env python3
"""
SteamGG CLI - Search, download and extract games from steamgg.net
Pure Python implementation - System Agnostic
"""

import requests
from bs4 import BeautifulSoup
import sys
import os
import zipfile
import tarfile
import gzip
import bz2
import lzma
import shutil
import re
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt, IntPrompt, Confirm
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, DownloadColumn, TransferSpeedColumn, TimeRemainingColumn
from rich.panel import Panel
from rich import box
from rich.live import Live
from rich.layout import Layout
from rich.text import Text

console = Console()

# Valid buzzheavier domains
VALID_DOMAINS = [
    'buzzheavier.com',
    'bzzhr.co',
    'fuckingfast.net',
    'fuckingfast.co'
]

# Base directories
BASE_DIR = Path(__file__).parent
GAMES_DIR = BASE_DIR / "Games"
GAMES_DIR.mkdir(exist_ok=True)


# ============== EXTRACTION FUNCTIONS ==============

def detect_archive_type(archive_path):
    """Detect archive type by magic bytes"""
    with open(archive_path, 'rb') as f:
        header = f.read(16)
    
    if header[:4] == b'PK\x03\x04' or header[:4] == b'PK\x05\x06':
        return 'zip'
    if header[:4] == b'Rar!\x1a\x07\x00' or header[:8] == b'Rar!\x1a\x07\x01\x14':
        return 'rar'
    if header[:6] == b'7z\xbc\xaf\x27\x1c':
        return '7z'
    if header[:2] == b'\x1f\x8b':
        return 'gzip'
    if header[:3] == b'BZh':
        return 'bzip2'
    if header[:6] == b'\xfd7zXZ\x00':
        return 'xz'
    
    with open(archive_path, 'rb') as f:
        f.seek(257)
        tar_header = f.read(5)
        if tar_header == b'ustar':
            return 'tar'
    
    suffix = archive_path.suffix.lower()
    type_map = {'.zip': 'zip', '.rar': 'rar', '.7z': '7z', '.gz': 'gzip', 
                '.bz2': 'bzip2', '.xz': 'xz', '.tar': 'tar', '.tgz': 'gzip'}
    return type_map.get(suffix, 'unknown')


def extract_archive(archive_path, extract_to):
    """Extract archive using pure Python"""
    console.print(f"\n[bold green]✓[/bold green] Download complete!")
    console.print(f"[dim]Extracting to {extract_to}...[/dim]\n")
    
    extract_to.mkdir(parents=True, exist_ok=True)
    archive_type = detect_archive_type(archive_path)
    console.print(f"[dim]Detected archive type: {archive_type}[/dim]\n")
    
    try:
        if archive_type == 'zip':
            with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                zip_ref.extractall(extract_to)
        elif archive_type == 'tar':
            with tarfile.open(archive_path, 'r') as tar_ref:
                tar_ref.extractall(extract_to)
        elif archive_type == 'gzip':
            if archive_path.suffix == '.tgz' or str(archive_path).endswith('.tar.gz'):
                with tarfile.open(archive_path, 'r:gz') as tar_ref:
                    tar_ref.extractall(extract_to)
            else:
                output_file = extract_to / archive_path.stem
                with gzip.open(archive_path, 'rb') as f_in:
                    with open(output_file, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
        elif archive_type == 'bzip2':
            if str(archive_path).endswith('.tar.bz2'):
                with tarfile.open(archive_path, 'r:bz2') as tar_ref:
                    tar_ref.extractall(extract_to)
            else:
                output_file = extract_to / archive_path.stem
                with bz2.open(archive_path, 'rb') as f_in:
                    with open(output_file, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
        elif archive_type == 'xz':
            if str(archive_path).endswith('.tar.xz'):
                with tarfile.open(archive_path, 'r:xz') as tar_ref:
                    tar_ref.extractall(extract_to)
            else:
                output_file = extract_to / archive_path.stem
                with lzma.open(archive_path, 'rb') as f_in:
                    with open(output_file, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
        elif archive_type == 'rar':
            console.print("[yellow]⚠ RAR format requires external tool.[/yellow]")
            console.print("[dim]Install: brew install unrar (macOS) or apt install unrar (Linux)[/dim]")
            return False
        elif archive_type == '7z':
            console.print("[yellow]⚠ 7z format requires external tool.[/yellow]")
            console.print("[dim]Install: uv pip install py7zr[/dim]")
            return False
        else:
            console.print(f"[yellow]Unknown archive type, trying ZIP...[/yellow]")
            with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                zip_ref.extractall(extract_to)
        
        console.print(f"[bold green]✓[/bold green] Extraction complete!")
        console.print(f"[dim]Game extracted to: {extract_to}[/dim]")
        
        contents = list(extract_to.iterdir())
        if contents:
            console.print(f"[dim]Extracted {len(contents)} items[/dim]")
        
        return True
    except Exception as e:
        console.print(f"[bold red]✗[/bold red] Extraction failed: {e}")
        return False


# ============== SCRAPING FUNCTIONS ==============

def scrape_steamgg_games(query=None):
    """Scrape games from steamgg.net with optional search query"""
    if query:
        url = f"https://steamgg.net/?s={query.replace(' ', '+')}"
    else:
        url = "https://steamgg.net/"
    
    with console.status("[bold green]Fetching games...", spinner="dots"):
        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()
        except requests.RequestException as e:
            console.print(f"[bold red]Error:[/bold red] Failed to fetch steamgg.net: {e}")
            return []
    
    soup = BeautifulSoup(response.text, 'html.parser')
    games = []
    seen_titles = set()
    
    # Try vc_gitem-link first (homepage structure)
    game_links = soup.find_all('a', class_='vc_gitem-link')
    
    for link_tag in game_links:
        title = link_tag.get('title')
        if not title:
            title_elem = link_tag.find(class_='vc_gitem-post-data-source-post_title')
            if title_elem:
                title = title_elem.get_text(strip=True)
            else:
                title = link_tag.get_text(strip=True)
        
        link = link_tag.get('href')
        
        if title and link and title not in seen_titles:
            seen_titles.add(title)
            games.append({
                'title': title,
                'page_url': link,
                'buzzheavier_url': None,
                'download_url': None,
            })
    
    # If no vc_gitem-link found, try search results structure
    if not games:
        # Search results use different structure: a > img + div.title-overlay > h4
        search_results = soup.find_all('a', href=True)
        
        for link_tag in search_results:
            href = link_tag.get('href')
            
            # Skip non-game pages
            if not href or 'steamgg.net' not in href:
                continue
            
            # Look for title-overlay h4
            title_overlay = link_tag.find('div', class_='title-overlay')
            if title_overlay:
                h4 = title_overlay.find('h4')
                if h4:
                    title = h4.get_text(strip=True)
                    link = href
                    
                    if title and link and title not in seen_titles:
                        seen_titles.add(title)
                        games.append({
                            'title': title,
                            'page_url': link,
                            'buzzheavier_url': None,
                            'download_url': None,
                        })
    
    return games


def find_buzzheavier_link(game_url):
    """Find buzzheavier download link on game page"""
    try:
        response = requests.get(game_url, timeout=30)
        response.raise_for_status()
    except requests.RequestException:
        return None
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Search for buzzheavier links
    all_links = soup.find_all('a', href=True)
    for a in all_links:
        href = a.get('href')
        if href and any(domain in href for domain in VALID_DOMAINS):
            return href
    
    # Search in page text
    page_text = soup.get_text()
    for domain in VALID_DOMAINS:
        matches = re.findall(rf'https?://{domain}/[a-zA-Z0-9]+', page_text)
        if matches:
            return matches[0]
    
    return None


def get_buzzheavier_download_url(url):
    """Get the actual download URL from buzzheavier"""
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    
    title = soup.title.string.strip() if soup.title else "unknown_file"
    
    download_url = url + '/download'
    headers = {
        'hx-current-url': url,
        'hx-request': 'true',
        'referer': url
    }
    head_response = requests.head(download_url, headers=headers, allow_redirects=False, timeout=30)
    hx_redirect = head_response.headers.get('hx-redirect')
    
    if not hx_redirect:
        raise Exception("Download link not found")
    
    domain = url.split('/')[2]
    final_url = f'https://{domain}' + hx_redirect if hx_redirect.startswith('/dl/') else hx_redirect
    
    return final_url, title


def download_file(url, destination, title=None):
    """Download a file with progress bar"""
    if title is None:
        title = destination.name
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=40),
        TextColumn("[progress.percentage]{task.percentage:>3.1f}%"),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        
        task = progress.add_task(f"Downloading {title[:40]}...", total=None)
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        if total_size > 0:
            progress.update(task, total=total_size)
        
        block_size = 8192
        downloaded = 0
        
        with open(destination, 'wb') as f:
            for chunk in response.iter_content(chunk_size=block_size):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    progress.update(task, completed=downloaded)
    
    return destination


# ============== UI FUNCTIONS ==============

def create_games_display(games, page=0, per_page=15):
    """Create a rich table display for games"""
    total_pages = (len(games) + per_page - 1) // per_page
    start = page * per_page
    end = min(start + per_page, len(games))
    page_games = games[start:end]
    
    table = Table(
        title=f"[bold cyan]Games {start + 1}-{end} of {len(games)} (Page {page + 1}/{total_pages})[/bold cyan]",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold magenta",
        expand=True,
    )
    
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Title", style="cyan", ratio=3)
    table.add_column("Status", style="green", width=20)
    
    for i, game in enumerate(page_games, 1):
        status = "[green]✓ Ready[/green]"
        actual_index = start + i
        table.add_row(str(actual_index), game['title'][:55] + ("..." if len(game['title']) > 55 else ""), status)
    
    return table, total_pages


def create_search_display(games, query, page=0, per_page=15):
    """Create search results display"""
    filtered = [g for g in games if query.lower() in g['title'].lower()]
    
    if not filtered:
        return None, 0
    
    total_pages = (len(filtered) + per_page - 1) // per_page
    start = page * per_page
    end = min(start + per_page, len(filtered))
    page_games = filtered[start:end]
    
    table = Table(
        title=f"[bold cyan]Search: '{query}' - Results {start + 1}-{end} of {len(filtered)}[/bold cyan]",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold magenta",
        expand=True,
    )
    
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Title", style="cyan", ratio=3)
    table.add_column("Status", style="green", width=20)
    
    for i, game in enumerate(page_games, 1):
        actual_index = start + i
        table.add_row(str(actual_index), game['title'][:55] + ("..." if len(game['title']) > 55 else ""), "[green]✓ Ready[/green]")
    
    return table, total_pages


def print_header():
    """Print application header"""
    console.print(Panel.fit(
        "[bold blue]SteamGG CLI[/bold blue]\n"
        "[dim]Search, download & extract games from steamgg.net[/dim]\n"
        "[green]Pure Python - System Agnostic[/green]",
        border_style="blue",
        padding=(1, 2),
    ))
    console.print()


def print_help():
    """Print help information"""
    console.print(Panel(
        "[bold]Navigation:[/bold]\n"
        "  [cyan]n[/cyan], [cyan]next[/cyan]       - Next page\n"
        "  [cyan]p[/cyan], [cyan]prev[/cyan]       - Previous page\n"
        "  [cyan]r[/cyan], [cyan]refresh[/cyan]    - Refresh games list\n"
        "  [cyan]s[/cyan], [cyan]search[/cyan]     - Search games\n"
        "  [cyan]1-999[/cyan]          - Select game number\n"
        "  [cyan]q[/cyan], [cyan]quit[/cyan]         - Exit\n"
        "\n[bold]After selecting a game:[/bold]\n"
        "  [cyan]d[/cyan], [cyan]download[/cyan]   - Download selected game\n"
        "  [cyan]b[/cyan], [cyan]back[/cyan]         - Go back to list\n"
        "  [cyan]q[/cyan], [cyan]quit[/cyan]         - Exit\n",
        title="Help",
        border_style="dim",
    ))


def print_game_details(game):
    """Print detailed game information"""
    console.print(Panel(
        f"[bold cyan]{game['title']}[/bold cyan]\n\n"
        f"[dim]Page URL:[/dim]\n{game['page_url']}\n\n"
        f"[dim]Buzzheavier URL:[/dim]\n{game['buzzheavier_url'] or '[yellow]Not fetched yet[/yellow]'}",
        title="Game Details",
        border_style="cyan",
    ))


# ============== MAIN APPLICATION ==============

class SteamGGApp:
    def __init__(self):
        self.games = []
        self.filtered_games = []
        self.current_page = 0
        self.per_page = 15
        self.search_query = None
        self.selected_game = None
    
    def fetch_games(self, query=None):
        """Fetch games from steamgg.net with optional search"""
        if query:
            console.print(f"[bold]Step 1:[/bold] Searching for '{query}' on steamgg.net...")
        else:
            console.print("[bold]Step 1:[/bold] Fetching games from steamgg.net...")
        
        self.games = scrape_steamgg_games(query)
        self.filtered_games = self.games.copy()
        self.current_page = 0
        self.search_query = query
        
        if not self.games:
            console.print("[bold red]No games found![/bold red]")
            return False
        
        console.print(f"[bold green]✓[/bold green] Found {len(self.games)} games\n")
        return True
    
    def display_games(self):
        """Display current games list"""
        if self.search_query:
            table, total_pages = create_search_display(
                self.games, self.search_query, self.current_page, self.per_page
            )
            if table:
                console.print(table)
        else:
            table, total_pages = create_games_display(
                self.filtered_games, self.current_page, self.per_page
            )
            console.print(table)
        
        return total_pages
    
    def search_games(self, query):
        """Search games by query - fetch from server"""
        if not query:
            # Refetch all games
            self.games = scrape_steamgg_games(None)
            self.filtered_games = self.games.copy()
            self.search_query = None
        else:
            # Fetch search results from server
            self.games = scrape_steamgg_games(query)
            self.filtered_games = self.games.copy()
            self.search_query = query
        self.current_page = 0
    
    def select_game(self, index):
        """Select a game by index (1-based)"""
        if 1 <= index <= len(self.games):
            self.selected_game = self.games[index - 1]
            return True
        return False
    
    def fetch_game_download_info(self, game):
        """Fetch buzzheavier link and download URL for a game"""
        console.print(f"\n[bold]Fetching download info for:[/bold] {game['title']}\n")
        
        # Find buzzheavier link
        with console.status("[dim]Finding buzzheavier link...", spinner="dots"):
            game['buzzheavier_url'] = find_buzzheavier_link(game['page_url'])
        
        if not game['buzzheavier_url']:
            console.print("[yellow]⚠ Could not find buzzheavier link automatically[/yellow]")
            manual_url = Prompt.ask("Enter buzzheavier URL manually (or press Enter to cancel)", default="")
            if manual_url:
                game['buzzheavier_url'] = manual_url
            else:
                return None
        
        console.print(f"[bold green]✓[/bold green] Buzzheavier: {game['buzzheavier_url']}")
        
        # Get actual download URL
        with console.status("[dim]Getting download URL...", spinner="dots"):
            try:
                game['download_url'], file_title = get_buzzheavier_download_url(game['buzzheavier_url'])
                console.print(f"[bold green]✓[/bold green] Download URL ready")
                return file_title
            except Exception as e:
                console.print(f"[bold red]✗[/bold red] Failed: {e}")
                return None
    
    def download_and_extract(self, game):
        """Download and extract a game"""
        # Get download URL if not already fetched
        if not game['download_url']:
            file_title = self.fetch_game_download_info(game)
            if not file_title:
                return False
        else:
            file_title = game.get('file_title', 'unknown')
        
        # Setup paths
        safe_title = "".join(c if c.isalnum() or c in ' -_.' else '_' for c in game['title'])
        safe_title = safe_title[:80]
        
        filename = Prompt.ask("\n[bold]Download filename[/bold]", default=f"{safe_title}.zip")
        if not any(filename.endswith(ext) for ext in ['.zip', '.rar', '.7z', '.tar.gz', '.tar.bz2', '.tar.xz', '.gz', '.bz2', '.xz']):
            filename += '.zip'
        
        download_path = GAMES_DIR / "downloads" / filename
        download_path.parent.mkdir(parents=True, exist_ok=True)
        
        extract_folder = Prompt.ask("[bold]Extraction folder[/bold]", default=safe_title)
        extract_path = GAMES_DIR / extract_folder
        
        console.print(f"\n[dim]Download: {download_path}[/dim]")
        console.print(f"[dim]Extract: {extract_path}[/dim]\n")
        
        if not Confirm.ask("[bold]Start download?[/bold]", default=True):
            return False
        
        try:
            # Download
            final_url = game['download_url']
            download_file(final_url, download_path, file_title)
            
            # Extract
            if not extract_archive(download_path, extract_path):
                return False
            
            # Cleanup
            if Confirm.ask("\n[yellow]Delete downloaded archive?[/yellow]", default=True):
                download_path.unlink()
                console.print("[dim]Archive deleted[/dim]")
            
            console.print(f"\n[bold green]✓ SUCCESS![/bold green] [green]Game installed to: {extract_path}[/green]")
            return True
            
        except Exception as e:
            console.print(f"\n[bold red]✗ Error:[/bold red] {e}")
            return False
    
    def game_selection_mode(self, index):
        """Handle game selection and download flow"""
        # index is 1-based, convert to 0-based for filtered_games
        if index < 1 or index > len(self.filtered_games):
            console.print("[yellow]Invalid selection[/yellow]")
            return
        
        game = self.filtered_games[index - 1]
        
        console.print("\n" + "═" * 60)
        print_game_details(game)
        
        while True:
            choice = Prompt.ask(
                "\n[bold]Options[/bold]",
                choices=["download", "back", "help", "quit"],
                default="download",
            )
            
            if choice in ['q', 'quit']:
                console.print("[yellow]Goodbye![/yellow]")
                sys.exit(0)
            
            if choice in ['b', 'back']:
                return
            
            if choice in ['h', 'help']:
                print_help()
                continue
            
            if choice in ['d', 'download']:
                if self.download_and_extract(game):
                    console.print("\n[green]Download complete! Returning to list...[/green]\n")
                return
    
    def run(self):
        """Main application loop"""
        print_header()
        
        # Step 1: Search first
        console.print("\n[bold cyan]━ Step 1: Search Games ━[/bold cyan]\n")
        search_query = Prompt.ask("[bold]Enter search term[/bold] (or press Enter to skip)", default="")
        
        # Fetch games (with search query if provided)
        if not self.fetch_games(search_query):
            return
        
        # Main loop
        while True:
            console.print()
            total_pages = self.display_games()
            
            # Navigation prompt
            console.print()
            console.print("[dim]Navigation:[/dim] [cyan]n[/cyan]=next [cyan]p[/cyan]=prev [cyan]s[/cyan]=search [cyan]r[/cyan]=refresh [cyan]1-999[/cyan]=select [cyan]h[/cyan]=help [cyan]q[/cyan]=quit\n")
            
            choice = Prompt.ask("[bold]Enter command[/bold]", default="").strip().lower()
            
            if not choice:
                continue
            
            # Quit
            if choice in ['q', 'quit', 'exit']:
                console.print("[yellow]Goodbye![/yellow]")
                return
            
            # Help
            if choice in ['h', 'help', '?']:
                print_help()
                continue
            
            # Refresh
            if choice in ['r', 'refresh']:
                self.fetch_games(self.search_query)
                continue
            
            # Search
            if choice in ['s', 'search']:
                query = Prompt.ask("[bold]Enter search term[/bold]", default="")
                self.search_games(query)
                if not self.filtered_games:
                    console.print("[bold red]No games found![/bold red]")
                    self.search_games(None)
                else:
                    console.print(f"[bold green]✓[/bold green] Found {len(self.filtered_games)} games\n")
                continue
            
            # Next page
            if choice in ['n', 'next']:
                if self.current_page < total_pages - 1:
                    self.current_page += 1
                else:
                    console.print("[yellow]Already at last page[/yellow]")
                continue
            
            # Previous page
            if choice in ['p', 'prev', 'previous']:
                if self.current_page > 0:
                    self.current_page -= 1
                else:
                    console.print("[yellow]Already at first page[/yellow]")
                continue
            
            # Game selection
            try:
                index = int(choice)
                games_list = self.filtered_games if self.filtered_games else self.games
                if 1 <= index <= len(games_list):
                    self.game_selection_mode(index)
                else:
                    max_idx = len(games_list)
                    console.print(f"[yellow]Invalid selection. Enter 1-{max_idx}[/yellow]")
            except ValueError:
                console.print("[yellow]Unknown command. Type 'h' for help.[/yellow]")


def main():
    app = SteamGGApp()
    app.run()


if __name__ == '__main__':
    main()
