"""Levelwright — AI gaming assistant for handhelds.

This is a placeholder release. The real implementation ships as two Hermes
plugins (levelwright-system, levelwright-steam) and a Decky plugin.
See the design docs at https://github.com/levelwright/levelwright for details.
"""

__version__ = "0.0.1"
