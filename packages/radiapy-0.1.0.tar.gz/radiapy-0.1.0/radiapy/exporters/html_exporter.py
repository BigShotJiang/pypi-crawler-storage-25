"""HTML dashboard exporter — standalone, no CDN required.

Strategy
--------
1. Embed Plotly.js fully inline (≈4.7 MB, loaded synchronously before any
   rendering code runs → no race conditions).
2. Serialize every figure to JSON with PlotlyJSONEncoder (handles numpy
   dtypes, datetime, etc.).
3. Render figures **lazily**: only when the user clicks a tab do we call
   ``Plotly.newPlot()`` — this guarantees the container div has non-zero
   dimensions and avoids the display:none render-at-zero-size bug.
4. After rendering, switching back to an already-rendered tab calls
   ``Plotly.relayout(id, {autosize:true})`` to re-fit the figure.
5. Plotly animation frames are added via ``Plotly.addFrames()`` after the
   initial ``newPlot`` call.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import plotly
import plotly.graph_objects as go
import plotly.offline


# ── Serialisation ─────────────────────────────────────────────────────────────

def _fig_to_json(fig: go.Figure) -> str:
    """Serialise a Plotly Figure (including frames) to a compact JSON string."""
    return json.dumps(fig.to_dict(), cls=plotly.utils.PlotlyJSONEncoder,
                      separators=(",", ":"))


# ── Tab metadata ──────────────────────────────────────────────────────────────

_TABS = [
    ("attenuation",  "📊 Attenuation",      "Transmission by absorber material (bars + NIST overlay)"),
    ("spectrum",     "📈 μ/ρ Spectrum",      "NIST attenuation coefficients vs energy — Pb K-edge highlighted"),
    ("distance",     "📏 Inverse-Square",    "Counts vs distance with fitted I ∝ 1/r² curve and R²"),
    ("distance_norm","✓ 1/r² Diagnostic",   "Counts × r² plotted vs distance — a flat line confirms that intensity follows the inverse-square law, i.e. the source behaves as a point source."),
    ("heatmap",      "🟩 Heatmap",           "Transmission matrix: experimental vs NIST Beer-Lambert"),
    ("mu_compare",   "⚗ μ Comparison",      "Experimental μ back-calculated from T_exp vs NIST reference"),
    ("comparison",   "⚖ Cd109 vs Am241",    "Multi-isotope overlay — Pb K-edge effect visible"),
    ("particles",    "⚡ Particle Sim",      "Photon trajectories with absorber-thickness slider"),
]

_NIST_NOTE = """
<div class="nist-note">
  <b>Physics note — Pb K-edge at 88.005 keV:</b>
  Cd-109 emits its main γ at 88.034 keV (just <em>above</em> the K-edge), so the
  K-shell photoelectric channel opens, giving Pb a ~7× higher μ/ρ than the
  sub-edge value. Am-241 (59.5 keV) sits below the edge → Pb attenuates it
  less strongly. This is the counterintuitive reversal visible in the comparison tab.
</div>
"""


# ── CSS ───────────────────────────────────────────────────────────────────────

_CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;color:#222}
header{background:linear-gradient(135deg,#1a1a2e,#16213e,#0f3460);color:#fff;
  padding:26px 36px 20px;box-shadow:0 4px 18px rgba(0,0,0,.3)}
header h1{font-size:2rem;letter-spacing:1px}
header h1 span{color:#e94560}
header p{font-size:.88rem;opacity:.78;margin-top:5px}
.header-meta{display:flex;gap:20px;margin-top:10px;font-size:.78rem;opacity:.68}
.tab-bar{background:#fff;border-bottom:2px solid #e0e4ea;display:flex;
  padding:0 28px;gap:2px;overflow-x:auto;
  position:sticky;top:0;z-index:100;
  box-shadow:0 2px 8px rgba(0,0,0,.07)}
.tab-btn{padding:13px 18px;border:none;background:transparent;cursor:pointer;
  font-size:.84rem;color:#555;border-bottom:3px solid transparent;
  transition:all .18s;white-space:nowrap}
.tab-btn:hover{color:#0f3460;background:rgba(15,52,96,.05)}
.tab-btn.active{color:#0f3460;border-bottom-color:#e94560;font-weight:600}
.tab-content{display:none;padding:26px 34px}
.tab-content.active{display:block}
.section-label{font-size:1rem;font-weight:600;color:#1a1a2e;
  border-bottom:2px solid #e94560;display:inline-block;
  padding-bottom:4px;margin-bottom:8px}
.section-desc{font-size:.83rem;color:#666;margin-bottom:18px;line-height:1.55}
.plot-card{background:#fff;border-radius:10px;padding:16px;
  margin-bottom:22px;box-shadow:0 2px 10px rgba(0,0,0,.07)}
.plot-card .plotly-graph-div{width:100%}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
  gap:14px;padding:20px 34px 0}
.stat-card{background:#fff;border-radius:9px;padding:16px;text-align:center;
  box-shadow:0 2px 8px rgba(0,0,0,.06);border-top:4px solid #e94560}
.stat-card .val{font-size:1.75rem;font-weight:700;color:#0f3460}
.stat-card .lbl{font-size:.76rem;color:#777;margin-top:3px;
  text-transform:uppercase;letter-spacing:.5px}
.nist-note{background:linear-gradient(135deg,#fff8e1,#fffde7);
  border-left:4px solid #f39c12;padding:12px 16px;
  border-radius:0 8px 8px 0;margin-bottom:18px;
  font-size:.83rem;color:#555;line-height:1.55}
.nist-note b{color:#e67e22}
.spinner{text-align:center;padding:40px;color:#888;font-size:.9rem}
footer{background:#1a1a2e;color:rgba(255,255,255,.55);
  text-align:center;padding:18px;font-size:.78rem;margin-top:40px}
footer a{color:#e94560;text-decoration:none}
"""


# ── JavaScript ────────────────────────────────────────────────────────────────

_JS = r"""
// FIGS is injected by Python as a JS object below.
const rendered = {};

function renderTab(tabId) {
    const figs = window.FIGS[tabId];
    if (!figs) return;

    figs.forEach(function(figData, i) {
        const divId = 'fig-' + tabId + '-' + i;
        const el = document.getElementById(divId);
        if (!el) return;

        if (rendered[divId]) {
            // Already rendered — just resize to fill the now-visible container
            Plotly.relayout(divId, {autosize: true});
            return;
        }

        // Remove spinner placeholder
        el.innerHTML = '';

        // Separate frames from the figure data before newPlot
        const frames = figData.frames || [];
        const figNoFrames = {data: figData.data, layout: figData.layout};

        Plotly.newPlot(divId, figNoFrames.data, figNoFrames.layout,
                       {responsive: true, displayModeBar: true,
                        scrollZoom: true, displaylogo: false})
              .then(function() {
                  if (frames.length > 0) {
                      Plotly.addFrames(divId, frames);
                  }
              });

        rendered[divId] = true;
    });
}

function switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(function(b) {
        b.classList.remove('active');
    });
    document.querySelectorAll('.tab-content').forEach(function(c) {
        c.classList.remove('active');
        c.style.display = 'none';
    });
    document.getElementById('btn-' + tabId).classList.add('active');
    var tab = document.getElementById('tab-' + tabId);
    tab.classList.add('active');
    tab.style.display = 'block';

    // Small delay so the browser paints the visible div before Plotly measures it
    setTimeout(function() { renderTab(tabId); }, 30);
}

document.addEventListener('DOMContentLoaded', function() {
    // Render the first tab immediately
    var firstTab = document.querySelector('.tab-btn');
    if (firstTab) {
        var id = firstTab.id.replace('btn-', '');
        switchTab(id);
    }
});
"""


# ── Main export function ──────────────────────────────────────────────────────

def export_dashboard(
    figures: dict[str, Any],
    output_path: str | Path,
    dataset_summary: dict | None = None,
) -> Path:
    """Write a fully self-contained interactive HTML dashboard.

    Parameters
    ----------
    figures        : mapping of tab_id → Figure or list[Figure].
    output_path    : destination HTML file.
    dataset_summary: optional dict of {key: (value, label)} for the stats bar.

    Returns
    -------
    Path of the written file.
    """
    output_path = Path(output_path)

    # ── Serialise figures ──────────────────────────────────────────────────
    fig_json: dict[str, list[str]] = {}
    for tab_id, figs in figures.items():
        if not isinstance(figs, list):
            figs = [figs]
        fig_json[tab_id] = [_fig_to_json(f) for f in figs]

    # Build the JavaScript FIGS object string.
    # We embed each figure as a raw JSON literal (not a quoted string) so the
    # browser JS engine doesn't need to parse it a second time.
    figs_js_parts = []
    for tab_id, json_list in fig_json.items():
        entries = ",".join(json_list)   # already valid JSON objects
        figs_js_parts.append(f'"{tab_id}":[{entries}]')
    figs_js = "window.FIGS = {" + ",".join(figs_js_parts) + "};"

    # ── Tab HTML ───────────────────────────────────────────────────────────
    tab_buttons_html = ""
    tab_contents_html = ""

    active_set = False
    for tab_id, tab_label, tab_desc in _TABS:
        if tab_id not in fig_json:
            continue

        is_active = not active_set
        active_set = True

        tab_buttons_html += (
            f'<button class="tab-btn{" active" if is_active else ""}" '
            f'id="btn-{tab_id}" onclick="switchTab(\'{tab_id}\')">'
            f'{tab_label}</button>\n'
        )

        inner = f'<span class="section-label">{tab_label}</span>\n'
        inner += f'<p class="section-desc">{tab_desc}</p>\n'

        if tab_id in ("attenuation", "comparison"):
            inner += _NIST_NOTE

        n_figs = len(fig_json[tab_id])
        for i in range(n_figs):
            div_id = f"fig-{tab_id}-{i}"
            inner += (
                f'<div class="plot-card">'
                f'<div id="{div_id}" style="min-height:420px">'
                f'<div class="spinner">Loading chart…</div>'
                f'</div></div>\n'
            )

        display = "block" if is_active else "none"
        tab_contents_html += (
            f'<div class="tab-content{"" if not is_active else " active"}" '
            f'id="tab-{tab_id}" style="display:{display}">\n'
            f'{inner}</div>\n'
        )

    # ── Stats bar ─────────────────────────────────────────────────────────
    stats_html = ""
    if dataset_summary:
        stats_html = '<div class="stats-grid">'
        for _, (val, lbl) in dataset_summary.items():
            stats_html += (
                f'<div class="stat-card">'
                f'<div class="val">{val}</div>'
                f'<div class="lbl">{lbl}</div>'
                f'</div>'
            )
        stats_html += "</div>"

    # ── Inline Plotly.js ───────────────────────────────────────────────────
    plotlyjs = plotly.offline.get_plotlyjs()   # full bundle, ~4.7 MB

    # ── Assemble HTML ──────────────────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Radiapy — Radiation Dashboard</title>
<script type="text/javascript">
{plotlyjs}
</script>
<style>{_CSS}</style>
</head>
<body>

<header>
  <h1>Radi<span>apy</span> — Radiation Experiment Dashboard</h1>
  <p>Interactive visualization · Beer-Lambert attenuation · Inverse-square law · NIST reference data</p>
  <div class="header-meta">
    <span>&#9671; Isotopes: Cd-109 (88 keV) · Am-241 (59.5 keV)</span>
    <span>&#9671; Absorbers: Al · Cu · Pb</span>
    <span>&#9671; Distances: 10 · 20 · 30 cm</span>
    <span>&#9671; Radiapy v0.1.0</span>
  </div>
</header>

{stats_html}

<nav class="tab-bar">
{tab_buttons_html}
</nav>

<main>
{tab_contents_html}
</main>

<footer>
  Generated with <a href="https://github.com/radviz/radiapy">Radiapy</a> &mdash;
  NIST data: <a href="https://physics.nist.gov/PhysRefData/Xcom/html/xcom1.html">NIST XCOM</a>
</footer>

<script type="text/javascript">
{figs_js}
{_JS}
</script>
</body>
</html>"""

    output_path.write_text(html, encoding="utf-8")
    return output_path
