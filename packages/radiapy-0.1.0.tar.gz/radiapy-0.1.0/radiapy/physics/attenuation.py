"""Beer-Lambert attenuation law: fitting and prediction utilities."""

from __future__ import annotations

import numpy as np
from scipy.optimize import curve_fit
from dataclasses import dataclass


@dataclass
class AttenuationFit:
    """Result of fitting the Beer-Lambert law to experimental data."""

    material: str
    mu_exp: float
    mu_exp_unc: float
    mu_nist: float
    discrepancy_pct: float
    I0_fit: float
    I0_fit_unc: float
    r_squared: float
    isotope: str

    def summary(self) -> str:
        return (
            f"[{self.isotope} / {self.material}] "
            f"μ_exp = {self.mu_exp:.3f} ± {self.mu_exp_unc:.3f} cm⁻¹ | "
            f"μ_NIST = {self.mu_nist:.3f} cm⁻¹ | "
            f"Δ = {self.discrepancy_pct:+.1f}% | R² = {self.r_squared:.4f}"
        )


def beer_lambert(x: np.ndarray, I0: float, mu: float) -> np.ndarray:
    """I(x) = I0 * exp(-mu * x).

    Parameters
    ----------
    x   : absorber thickness (cm)
    I0  : intensity without absorber
    mu  : linear attenuation coefficient (cm⁻¹)
    """
    return I0 * np.exp(-mu * x)


def fit_attenuation(
    thicknesses: np.ndarray,
    counts: np.ndarray,
    I0_estimate: float,
    mu_nist: float,
    material: str = "",
    isotope: str = "",
    sigma: np.ndarray | None = None,
) -> AttenuationFit:
    """Fit Beer-Lambert to (thickness, counts) pairs and compare with NIST.

    Parameters
    ----------
    thicknesses : 1-D array of absorber thicknesses in cm.
    counts      : 1-D array of mean counts at each thickness.
    I0_estimate : free-field count estimate (no absorber).
    mu_nist     : NIST reference linear attenuation coefficient (cm⁻¹).
    material    : label used in the result.
    isotope     : label used in the result.
    sigma       : 1-D array of count uncertainties (standard errors).

    Returns
    -------
    AttenuationFit
    """
    p0 = [I0_estimate, mu_nist]
    bounds = ([0, 0], [np.inf, np.inf])

    try:
        popt, pcov = curve_fit(
            beer_lambert,
            thicknesses,
            counts,
            p0=p0,
            sigma=sigma,
            absolute_sigma=(sigma is not None),
            bounds=bounds,
            maxfev=10_000,
        )
    except RuntimeError:
        popt = np.array(p0)
        pcov = np.diag([np.nan, np.nan])

    perr = np.sqrt(np.diag(pcov))
    I0_fit, mu_fit = popt
    I0_unc, mu_unc = perr

    # R² against the fit
    counts_pred = beer_lambert(thicknesses, *popt)
    ss_res = np.sum((counts - counts_pred) ** 2)
    ss_tot = np.sum((counts - counts.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")

    discrepancy = 100.0 * (mu_fit - mu_nist) / mu_nist if mu_nist > 0 else float("nan")

    return AttenuationFit(
        material=material,
        mu_exp=float(mu_fit),
        mu_exp_unc=float(mu_unc),
        mu_nist=float(mu_nist),
        discrepancy_pct=float(discrepancy),
        I0_fit=float(I0_fit),
        I0_fit_unc=float(I0_unc),
        r_squared=float(r2),
        isotope=isotope,
    )


def transmission_from_ratio_stats(
    ratios: np.ndarray,
) -> tuple[float, float, float]:
    """Compute mean transmission, standard error, and 95% CI half-width.

    Parameters
    ----------
    ratios : array of per-replicate transmission ratios (counts_filter / counts_free).

    Returns
    -------
    mean, sem, ci95 : floats
    """
    n = len(ratios)
    mean = float(np.mean(ratios))
    std = float(np.std(ratios, ddof=1))
    sem = std / np.sqrt(n)
    # 95% CI using t-distribution approximation (t ≈ 1.96 for n≥30)
    from scipy.stats import t as t_dist
    t_crit = float(t_dist.ppf(0.975, df=n - 1))
    ci95 = t_crit * sem
    return mean, sem, ci95
