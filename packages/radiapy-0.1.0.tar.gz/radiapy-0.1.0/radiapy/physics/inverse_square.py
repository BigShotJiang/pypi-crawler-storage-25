"""Inverse-square law: fitting and prediction utilities."""

from __future__ import annotations

import numpy as np
from scipy.optimize import curve_fit
from dataclasses import dataclass


@dataclass
class InverseSquareFit:
    """Result of fitting I = A / r² to experimental distance data."""

    isotope: str
    A_fit: float
    A_unc: float
    r_squared: float
    distances: np.ndarray
    counts_mean: np.ndarray
    counts_sem: np.ndarray

    def predict(self, r: float | np.ndarray) -> np.ndarray:
        """Predict counts at distance r (cm)."""
        return self.A_fit / np.asarray(r) ** 2

    def summary(self) -> str:
        return (
            f"[{self.isotope}] I = {self.A_fit:.1f} / r² | "
            f"A ± {self.A_unc:.1f} | R² = {self.r_squared:.4f}"
        )


def inverse_square_law(r: np.ndarray, A: float) -> np.ndarray:
    """I(r) = A / r²."""
    return A / np.asarray(r) ** 2


def fit_inverse_square(
    distances: np.ndarray,
    counts_mean: np.ndarray,
    counts_sem: np.ndarray | None = None,
    isotope: str = "",
) -> InverseSquareFit:
    """Fit I ∝ 1/r² to distance-dependent count data.

    Parameters
    ----------
    distances   : source-detector distances in cm.
    counts_mean : mean free-field counts at each distance.
    counts_sem  : standard error of the mean counts (used as sigma in fit).
    isotope     : label for the result object.

    Returns
    -------
    InverseSquareFit
    """
    distances = np.asarray(distances, dtype=float)
    counts_mean = np.asarray(counts_mean, dtype=float)

    A0 = counts_mean[0] * distances[0] ** 2
    p0 = [A0]
    bounds = ([0.0], [np.inf])

    sigma = np.asarray(counts_sem, dtype=float) if counts_sem is not None else None

    try:
        popt, pcov = curve_fit(
            inverse_square_law,
            distances,
            counts_mean,
            p0=p0,
            sigma=sigma,
            absolute_sigma=(sigma is not None),
            bounds=bounds,
            maxfev=10_000,
        )
    except RuntimeError:
        popt = np.array(p0)
        pcov = np.diag([np.nan])

    A_fit = float(popt[0])
    A_unc = float(np.sqrt(pcov[0, 0]))

    counts_pred = inverse_square_law(distances, A_fit)
    ss_res = np.sum((counts_mean - counts_pred) ** 2)
    ss_tot = np.sum((counts_mean - counts_mean.mean()) ** 2)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")

    return InverseSquareFit(
        isotope=isotope,
        A_fit=A_fit,
        A_unc=A_unc,
        r_squared=r2,
        distances=distances,
        counts_mean=counts_mean,
        counts_sem=sigma if sigma is not None else np.zeros_like(counts_mean),
    )
