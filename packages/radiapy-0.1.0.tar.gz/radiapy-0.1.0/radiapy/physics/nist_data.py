"""
NIST mass attenuation coefficients (mu/rho) and derived linear attenuation
coefficients for Al, Cu, and Pb at the energies relevant to Cd-109 and Am-241.

Sources:
  NIST XCOM: Photon Cross Sections Database
  https://physics.nist.gov/PhysRefData/Xcom/html/xcom1.html

Note on Pb K-edge (88.005 keV):
  Cd-109 emits its main gamma at 88.034 keV, which sits just above the Pb
  K-edge. This causes a dramatic increase in the Pb photoelectric cross-section
  for Cd-109 compared to Am-241 (59.5 keV, below the K-edge), making
  Pb a more effective shield for Cd-109 than naive energy ordering would suggest.
"""

from __future__ import annotations
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Material densities (g/cm³)
# ---------------------------------------------------------------------------
DENSITY: dict[str, float] = {
    "Al": 2.699,
    "Cu": 8.960,
    "Pb": 11.350,
}

# ---------------------------------------------------------------------------
# Isotope energies (keV) and descriptions
# ---------------------------------------------------------------------------
ISOTOPE_ENERGY: dict[str, float] = {
    "Am241": 59.54,   # main gamma (59.5409 keV)
    "Cd109": 88.034,  # main gamma; sits just above Pb K-edge at 88.005 keV
}

ISOTOPE_DESCRIPTION: dict[str, str] = {
    "Am241": "Americium-241 (59.5 keV γ, EC decay)",
    "Cd109": "Cadmium-109 (88.0 keV γ, EC decay; near Pb K-edge)",
}

# ---------------------------------------------------------------------------
# NIST mass attenuation coefficients mu/rho (cm²/g)
# Values from NIST XCOM for each material at the two isotope energies.
#
# Pb at 88.034 keV is ABOVE the K-edge (88.005 keV): the K-shell photoelectric
# channel opens, producing a ~7× jump in mu/rho relative to the sub-edge value.
# ---------------------------------------------------------------------------
MU_OVER_RHO: dict[str, dict[str, float]] = {
    "Am241": {          # 59.54 keV
        "Al": 0.3219,   # cm²/g  (NIST XCOM, interpolated)
        "Cu": 0.8156,   # cm²/g
        "Pb": 5.549,    # cm²/g  (below Pb K-edge → moderate absorption)
    },
    "Cd109": {          # 88.034 keV
        "Al": 0.2226,   # cm²/g
        "Cu": 0.5082,   # cm²/g
        "Pb": 13.93,    # cm²/g  (ABOVE Pb K-edge → strongly enhanced absorption)
    },
}

# ---------------------------------------------------------------------------
# Linear attenuation coefficients mu = (mu/rho) * rho  (cm⁻¹)
# ---------------------------------------------------------------------------
MU_LINEAR: dict[str, dict[str, float]] = {
    isotope: {
        mat: MU_OVER_RHO[isotope][mat] * DENSITY[mat]
        for mat in ("Al", "Cu", "Pb")
    }
    for isotope in ("Am241", "Cd109")
}

# ---------------------------------------------------------------------------
# Demo filter thicknesses (cm) — the physical absorbers used in the experiment.
# These are stored here so the physics engine can compute expected transmission
# and compare it with the experimental ratios.
# ---------------------------------------------------------------------------
FILTER_THICKNESS_CM: dict[str, float] = {
    "Al": 0.50,   # 5 mm aluminium sheet
    "Cu": 0.10,   # 1 mm copper sheet
    "Pb": 0.01,   # 0.1 mm lead foil
}

# ---------------------------------------------------------------------------
# Convenience: expected transmission T = exp(-mu * x) for each condition
# ---------------------------------------------------------------------------
def expected_transmission(isotope: str, material: str, thickness_cm: float | None = None) -> float:
    """Theoretical Beer-Lambert transmission fraction.

    Parameters
    ----------
    isotope : str
        Isotope key ('Am241' or 'Cd109').
    material : str
        Absorber key ('Al', 'Cu', or 'Pb').
    thickness_cm : float, optional
        Absorber thickness in cm. Defaults to the demo filter thicknesses.

    Returns
    -------
    float
        Dimensionless transmission fraction in [0, 1].
    """
    import math
    if thickness_cm is None:
        thickness_cm = FILTER_THICKNESS_CM[material]
    mu = MU_LINEAR[isotope][material]
    return math.exp(-mu * thickness_cm)


# ---------------------------------------------------------------------------
# Tabulated mu/rho vs energy for plotting attenuation spectra
# (sparse NIST table; sufficient for log-interpolation over 30–200 keV)
# ---------------------------------------------------------------------------
NIST_SPECTRUM: dict[str, dict[str, list]] = {
    "Al": {
        "energy_keV": [30, 40, 50, 59.54, 60, 80, 88.034, 100, 150, 200],
        "mu_over_rho": [1.128, 0.5685, 0.3681, 0.3219, 0.3066, 0.2389, 0.2226, 0.1704, 0.1370, 0.1233],
    },
    "Cu": {
        "energy_keV": [30, 40, 50, 59.54, 60, 80, 88.034, 100, 150, 200],
        "mu_over_rho": [4.003, 1.920, 1.097, 0.8156, 0.8009, 0.5673, 0.5082, 0.3756, 0.2323, 0.1560],
    },
    "Pb": {
        # K-edge at 88.005 keV: two entries bracket the discontinuity
        "energy_keV": [30, 40, 50, 59.54, 80, 88.000, 88.010, 100, 150, 200],
        "mu_over_rho": [26.35, 12.02, 8.041, 5.549, 2.419, 2.014, 13.93, 5.549, 2.014, 0.9985],
    },
}
