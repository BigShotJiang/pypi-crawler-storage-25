"""Command-line interface for Radiapy."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from radiapy.core import RadViz


@click.group()
@click.version_option(package_name="radiapy")
def main() -> None:
    """Radiapy — radiation experiment visualizer."""


@main.command()
@click.argument("input", metavar="CSV_FILE", type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--output", "-o",
    default="dashboard.html",
    show_default=True,
    help="Path for the output HTML dashboard.",
)
def dashboard(input: str, output: str) -> None:
    """Generate an interactive HTML dashboard from CSV_FILE."""
    rv = RadViz(input)
    path = rv.generate_dashboard(output)
    click.echo(f"\nOpen in browser: {path.resolve()}")


@main.command()
@click.argument("input", metavar="CSV_FILE", type=click.Path(exists=True, dir_okay=False))
def report(input: str) -> None:
    """Print a physics report (fits, μ values, discrepancies) to stdout."""
    rv = RadViz(input)
    click.echo(rv.physics_report())


@main.command()
@click.option("--isotope", default="Am241", show_default=True, help="Isotope key.")
@click.option("--material", default="Pb", show_default=True, help="Absorber material.")
@click.option(
    "--output", "-o",
    default="particles.html",
    show_default=True,
    help="Output HTML file.",
)
def simulate(isotope: str, material: str, output: str) -> None:
    """Export the animated particle simulation (no CSV required)."""
    import plotly.io as pio
    from radiapy.visualizers.particle_viz import plot_particles

    click.echo(f"Simulating {isotope} through {material} …")
    fig = plot_particles(isotope=isotope, material=material)
    out = Path(output)
    pio.write_html(fig, out, include_plotlyjs=True, full_html=True)
    click.echo(f"Saved: {out.resolve()}")


# Backward-compatible alias: `radviz --input FILE --output FILE`
@click.command(name="radviz", hidden=True)
@click.option("--input", "-i", required=True, type=click.Path(exists=True), help="Input CSV file.")
@click.option("--output", "-o", default="dashboard.html", help="Output HTML path.")
def radviz_legacy(input: str, output: str) -> None:
    """Legacy single-command interface: radviz --input FILE --output FILE."""
    rv = RadViz(input)
    rv.generate_dashboard(output)
