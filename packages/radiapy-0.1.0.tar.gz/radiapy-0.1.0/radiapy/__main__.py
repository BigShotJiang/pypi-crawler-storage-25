"""Entry point for ``python -m radiapy CSV_FILE [options]``.

Usage
-----
    python -m radiapy demo/dataset_geiger.csv
    python -m radiapy demo/dataset_geiger.csv --output my_report.html
    python -m radiapy demo/dataset_geiger.csv --report-only
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="python -m radiapy",
        description="Radiapy — interactive radiation experiment visualizer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  python -m radiapy demo/dataset_geiger.csv
  python -m radiapy demo/dataset_geiger.csv --output report.html
  python -m radiapy demo/dataset_geiger.csv --report-only
        """,
    )
    p.add_argument("csv_file", metavar="CSV_FILE", help="Geiger-counter CSV dataset")
    p.add_argument(
        "--output", "-o",
        default="dashboard.html",
        metavar="FILE",
        help="Output HTML dashboard path (default: dashboard.html)",
    )
    p.add_argument(
        "--report-only",
        action="store_true",
        help="Print the physics report to stdout without generating HTML",
    )
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    csv_path = Path(args.csv_file)

    if not csv_path.exists():
        print(f"ERROR: file not found — {csv_path}", file=sys.stderr)
        return 1

    from radiapy.core import RadViz

    print("=" * 60)
    print("  Radiapy v0.1.0 — Radiation Experiment Visualizer")
    print("=" * 60)

    rv = RadViz(csv_path)

    print(f"\nDataset loaded:  {csv_path}")
    print(f"  Isotopes   : {', '.join(rv.dataset.isotopes)}")
    print(f"  Distances  : {rv.dataset.distances} cm")
    print(f"  Materials  : {', '.join(rv.dataset.materials)}")
    print(f"  Total rows : {len(rv.dataset.raw)}")
    print()

    print(rv.physics_report())

    if args.report_only:
        return 0

    out = rv.generate_dashboard(args.output)
    size_kb = out.stat().st_size // 1024
    print(f"\nDashboard saved : {out.resolve()}")
    print(f"File size       : {size_kb} KB")
    print(f"\nOpen in browser :")
    print(f"  open {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
