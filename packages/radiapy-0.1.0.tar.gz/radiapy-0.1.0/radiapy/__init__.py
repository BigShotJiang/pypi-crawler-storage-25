"""
Radiapy — Interactive visualization of radiation experiments.

Quick start::

    from radiapy import RadViz

    rv = RadViz("dataset_geiger.csv")
    rv.generate_dashboard("dashboard.html")

Or visualize a single plot::

    fig = rv.plot_attenuation()
    fig.show()
"""

from radiapy.core import RadViz

__version__ = "0.1.0"
__all__ = ["RadViz"]
