"""Inverse-square law visualizer."""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from radiapy.parsers.base_parser import ParsedDataset
from radiapy.physics.inverse_square import fit_inverse_square

ISOTOPE_COLORS = {"Am241": "#E74C3C", "Cd109": "#2ECC71"}
ISOTOPE_MARKERS = {"Am241": "circle", "Cd109": "diamond"}


def plot_inverse_square(
    dataset: ParsedDataset,
    isotope: str | None = None,
    overlay: bool = True,
) -> go.Figure:
    """Scatter plot of free-field counts vs distance with 1/r² fit overlay.

    Parameters
    ----------
    dataset : ParsedDataset from a parser.
    isotope : Single isotope to plot. None → all isotopes on one canvas.
    overlay : If True, draw the fitted 1/r² curve.

    Returns
    -------
    plotly Figure
    """
    isotopes = [isotope] if isotope else dataset.isotopes
    fig = go.Figure()

    r_smooth = np.linspace(8, 35, 300)

    for iso in isotopes:
        color = ISOTOPE_COLORS.get(iso, "#666")
        marker_sym = ISOTOPE_MARKERS.get(iso, "circle")

        # Collect group stats for this isotope
        gs_list = [gs for gs in dataset.group_stats if gs.isotope == iso]
        gs_list.sort(key=lambda g: g.distance_cm)

        if not gs_list:
            continue

        distances = np.array([gs.distance_cm for gs in gs_list])
        counts_mean = np.array([gs.counts_free_mean for gs in gs_list])
        counts_sem = np.array([gs.counts_free_sem for gs in gs_list])

        # Experimental points
        fig.add_trace(
            go.Scatter(
                x=distances,
                y=counts_mean,
                error_y=dict(
                    type="data",
                    array=1.96 * counts_sem,
                    visible=True,
                    color=color,
                    thickness=2,
                ),
                mode="markers",
                marker=dict(color=color, size=12, symbol=marker_sym, line=dict(color="white", width=1.5)),
                name=f"{iso} (exp.)",
                hovertemplate=(
                    f"<b>{iso}</b><br>"
                    "r = %{x} cm<br>"
                    "Counts = %{y:.1f} ± %{error_y.array:.1f} (95% CI)<extra></extra>"
                ),
            )
        )

        # Fit
        result = fit_inverse_square(distances, counts_mean, counts_sem, isotope=iso)

        if overlay:
            counts_smooth = result.predict(r_smooth)
            fig.add_trace(
                go.Scatter(
                    x=r_smooth,
                    y=counts_smooth,
                    mode="lines",
                    line=dict(color=color, width=2, dash="dash"),
                    name=f"{iso} fit (A={result.A_fit:.0f}, R²={result.r_squared:.4f})",
                    hovertemplate=f"<b>{iso} fit</b><br>r = %{{x:.1f}} cm<br>I = %{{y:.1f}}<extra></extra>",
                )
            )

            # Annotate R²
            fig.add_annotation(
                x=distances[-1],
                y=counts_mean[-1],
                text=f"  R² = {result.r_squared:.4f}<br>  A = {result.A_fit:.0f} ± {result.A_unc:.0f}",
                showarrow=False,
                font=dict(size=11, color=color),
                xanchor="left",
            )

    fig.update_layout(
        title=dict(
            text="<b>Inverse-Square Law: Counts vs Source-Detector Distance</b><br>"
                 "<sup>I ∝ 1/r² — fitted curve shown dashed</sup>",
            x=0.5,
        ),
        xaxis=dict(title="Distance r (cm)", range=[7, 36]),
        yaxis=dict(title="Mean Free-Field Counts"),
        template="plotly_white",
        height=500,
        legend=dict(orientation="h", y=-0.20, x=0.5, xanchor="center"),
        hoverlabel=dict(bgcolor="white", font_size=13),
    )
    return fig


def plot_inverse_square_normalized(dataset: ParsedDataset) -> go.Figure:
    """Plot counts × r² (should be constant if 1/r² law holds) vs distance.

    A flat line confirms the inverse-square behaviour.
    """
    fig = go.Figure()

    for iso in dataset.isotopes:
        color = ISOTOPE_COLORS.get(iso, "#666")
        gs_list = sorted(
            [gs for gs in dataset.group_stats if gs.isotope == iso],
            key=lambda g: g.distance_cm,
        )
        if not gs_list:
            continue

        distances = np.array([gs.distance_cm for gs in gs_list])
        counts_mean = np.array([gs.counts_free_mean for gs in gs_list])
        counts_sem = np.array([gs.counts_free_sem for gs in gs_list])

        normalized = counts_mean * distances ** 2
        norm_err = counts_sem * distances ** 2

        fig.add_trace(
            go.Scatter(
                x=distances,
                y=normalized,
                error_y=dict(type="data", array=1.96 * norm_err, visible=True, color=color),
                mode="markers+lines",
                marker=dict(color=color, size=10),
                line=dict(color=color, width=1.5),
                name=iso,
                hovertemplate=(
                    f"<b>{iso}</b><br>r = %{{x}} cm<br>"
                    "Counts × r² = %{y:.1f}<extra></extra>"
                ),
            )
        )

    fig.update_layout(
        title=dict(
            text=(
                "<b>Counts × r² vs Distance</b><br>"
                "<sup>A flat line here confirms that intensity follows the inverse-square law "
                "— i.e., the source behaves as a point source.</sup>"
            ),
            x=0.5,
        ),
        xaxis=dict(title="Distance r (cm)"),
        yaxis=dict(title="Counts · r²"),
        template="plotly_white",
        height=450,
        legend=dict(orientation="h", y=-0.20, x=0.5, xanchor="center"),
    )
    return fig
