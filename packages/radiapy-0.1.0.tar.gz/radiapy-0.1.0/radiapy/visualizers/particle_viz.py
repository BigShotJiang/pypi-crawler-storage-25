"""Animated photon trajectory visualizer (Plotly slider + frames).

Design: N photon trajectories shown simultaneously.  A Plotly slider steps
through 5 absorber-thickness levels; each step is one Plotly Frame that
swaps the trace data (green = transmitted, red/orange = absorbed).

Kept deliberately simple so the JSON stays small and the figure renders
reliably in a standalone HTML file.
"""

from __future__ import annotations

import math
import numpy as np
import plotly.graph_objects as go

from radiapy.physics.nist_data import MU_LINEAR

# ── Layout constants (arbitrary display units) ───────────────────────────────
X_SOURCE = 0.0
X_MAT_START = 6.0
X_DETECTOR = 13.0
Y_HALF = 3.5

N_PHOTONS = 45
SEED = 42


def _mu(isotope: str, material: str) -> float:
    return MU_LINEAR.get(isotope, {}).get(material, 1.0)


def _transmission(isotope: str, material: str, thickness_cm: float) -> float:
    return math.exp(-_mu(isotope, material) * thickness_cm)


def _photon_angles(n: int, rng: np.random.Generator) -> np.ndarray:
    base = np.linspace(-math.pi / 5.5, math.pi / 5.5, n)
    return base + rng.normal(0, 0.03, n)


def _concat_lines(segs: list[tuple]) -> tuple[list, list]:
    """Flatten line segments into single trace with None gaps."""
    x_flat, y_flat = [], []
    for (x0, x1), (y0, y1) in segs:
        x_flat += [x0, x1, None]
        y_flat += [y0, y1, None]
    return x_flat, y_flat


def _build_traces(
    angles: np.ndarray,
    transmitted: np.ndarray,
    x_mat_end: float,
) -> tuple[go.Scatter, go.Scatter]:
    t_segs, a_segs = [], []
    for ang, is_t in zip(angles, transmitted):
        slope = math.tan(ang)
        x_stop = X_DETECTOR if is_t else x_mat_end
        y_stop = slope * x_stop
        if abs(y_stop) > Y_HALF * 1.5:
            continue
        seg = ((X_SOURCE, x_stop), (0.0, y_stop))
        (t_segs if is_t else a_segs).append(seg)

    n_t = int(np.sum(transmitted))
    n_a = int(np.sum(~transmitted))

    tx, ty = _concat_lines(t_segs)
    ax, ay = _concat_lines(a_segs)

    return (
        go.Scatter(x=tx, y=ty, mode="lines",
                   line=dict(color="rgba(0,230,120,0.85)", width=1.6),
                   name=f"Transmitted ({n_t})", hoverinfo="skip"),
        go.Scatter(x=ax, y=ay, mode="lines",
                   line=dict(color="rgba(255,100,60,0.75)", width=1.6),
                   name=f"Absorbed ({n_a})", hoverinfo="skip"),
    )


def _material_trace(x_mat_end: float, label: str) -> go.Scatter:
    y_lo, y_hi = -Y_HALF * 0.92, Y_HALF * 0.92
    return go.Scatter(
        x=[X_MAT_START, x_mat_end, x_mat_end, X_MAT_START, X_MAT_START],
        y=[y_lo, y_lo, y_hi, y_hi, y_lo],
        mode="lines", fill="toself",
        fillcolor="rgba(200,160,80,0.30)",
        line=dict(color="rgba(160,110,20,0.9)", width=2),
        name=label, hoverinfo="skip",
    )


def _stat_trace(n_t: int, n_a: int, T_theory: float) -> go.Scatter:
    return go.Scatter(
        x=[X_DETECTOR + 0.2],
        y=[Y_HALF * 0.88],
        mode="text",
        text=[
            f"T theory = {T_theory:.3f}<br>"
            f"Transmitted = {n_t}<br>"
            f"Absorbed = {n_a}<br>"
            f"T sim = {n_t / max(n_t + n_a, 1):.3f}"
        ],
        textposition="middle right",
        showlegend=False, hoverinfo="skip",
    )


def plot_particles(
    isotope: str = "Am241",
    material: str = "Pb",
    thickness_levels: list[float] | None = None,
    seed: int = SEED,
) -> go.Figure:
    """Photon simulation with absorber-thickness slider.

    Parameters
    ----------
    isotope          : 'Am241' or 'Cd109'.
    material         : 'Al', 'Cu', or 'Pb'.
    thickness_levels : Absorber thicknesses (cm). Defaults to 5 values.
    seed             : RNG seed for reproducibility.

    Returns
    -------
    plotly Figure with Plotly frames wired to a slider.
    """
    if thickness_levels is None:
        thickness_levels = [0.001, 0.003, 0.007, 0.015, 0.030]

    rng = np.random.default_rng(seed)
    angles = _photon_angles(N_PHOTONS, rng)
    fate_rolls = rng.random(N_PHOTONS)

    frames: list[go.Frame] = []
    slider_steps: list[dict] = []

    for i, thick in enumerate(thickness_levels):
        T = _transmission(isotope, material, thick)
        transmitted = fate_rolls < T
        x_end = X_MAT_START + max(thick * 10, 0.3)

        mat = _material_trace(x_end, f"{material} ({thick*10:.2f} mm)")
        tr_t, tr_a = _build_traces(angles, transmitted, x_end)
        n_t = int(np.sum(transmitted))
        stat = _stat_trace(n_t, N_PHOTONS - n_t, T)

        frame_name = f"t{i}"
        frames.append(go.Frame(
            data=[mat, tr_t, tr_a, stat],
            name=frame_name,
            traces=[0, 1, 2, 3],
        ))
        slider_steps.append(dict(
            label=f"{thick*10:.2f} mm  (T={T:.3f})",
            method="animate",
            args=[[frame_name],
                  dict(mode="immediate",
                       frame=dict(duration=400, redraw=True),
                       transition=dict(duration=250))],
        ))

    # Initial state (first thickness)
    T0 = _transmission(isotope, material, thickness_levels[0])
    tr0 = fate_rolls < T0
    x0 = X_MAT_START + max(thickness_levels[0] * 10, 0.3)
    n_t0 = int(np.sum(tr0))
    init_mat = _material_trace(x0, f"{material} ({thickness_levels[0]*10:.2f} mm)")
    init_t, init_a = _build_traces(angles, tr0, x0)
    init_stat = _stat_trace(n_t0, N_PHOTONS - n_t0, T0)

    fig = go.Figure(data=[init_mat, init_t, init_a, init_stat], frames=frames)

    fig.update_layout(
        title=dict(
            text=(
                f"<b>Photon Simulation: {isotope} → {material}</b><br>"
                "<sup>Green = transmitted · Orange/red = absorbed · "
                "Move slider to change absorber thickness</sup>"
            ),
            x=0.5, font=dict(size=14),
        ),
        plot_bgcolor="rgba(10,10,28,1)",
        paper_bgcolor="#f0f2f5",
        xaxis=dict(range=[-0.8, X_DETECTOR + 2.8],
                   showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(range=[-Y_HALF * 1.2, Y_HALF * 1.2],
                   showgrid=False, zeroline=False, showticklabels=False,
                   scaleanchor="x", scaleratio=1),
        legend=dict(
            orientation="h", x=0.5, y=-0.08, xanchor="center",
            font=dict(color="#222"), bgcolor="rgba(255,255,255,0.85)",
        ),
        shapes=[
            dict(type="circle",
                 x0=-0.22, x1=0.22, y0=-0.22, y1=0.22,
                 fillcolor="yellow", line_color="orange",
                 xref="x", yref="y"),
            dict(type="rect",
                 x0=X_DETECTOR, x1=X_DETECTOR + 0.18,
                 y0=-Y_HALF * 0.92, y1=Y_HALF * 0.92,
                 fillcolor="rgba(60,200,80,0.45)",
                 line_color="rgba(40,180,60,0.9)"),
        ],
        annotations=[
            dict(x=0.0, y=-Y_HALF * 1.1, text="<b>Source</b>",
                 font=dict(color="yellow", size=11), showarrow=False),
            dict(x=X_DETECTOR, y=-Y_HALF * 1.1, text="<b>Detector</b>",
                 font=dict(color="lightgreen", size=11), showarrow=False),
        ],
        sliders=[dict(
            active=0,
            steps=slider_steps,
            currentvalue=dict(
                prefix="Absorber thickness: ",
                visible=True, xanchor="center",
                font=dict(size=13, color="#333"),
            ),
            pad=dict(t=60, b=10),
            len=0.92, x=0.04,
        )],
        height=560,
        margin=dict(l=20, r=20, t=110, b=130),
    )
    return fig
