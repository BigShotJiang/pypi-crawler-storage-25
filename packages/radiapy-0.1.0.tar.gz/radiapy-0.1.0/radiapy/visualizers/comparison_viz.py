"""Multi-isotope comparison visualizer and attenuation heatmap."""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from radiapy.parsers.base_parser import ParsedDataset
from radiapy.physics.nist_data import expected_transmission, MU_LINEAR, FILTER_THICKNESS_CM

MATERIAL_COLORS = {"Al": "#4C9BE8", "Cu": "#E8834C", "Pb": "#7E4CE8"}
ISOTOPE_COLORS = {"Am241": "#E74C3C", "Cd109": "#2ECC71"}
MATERIAL_FULL = {"Al": "Aluminium", "Cu": "Copper", "Pb": "Lead"}


def plot_comparison(dataset: ParsedDataset, distance_cm: float | None = None) -> go.Figure:
    """Overlay Cd109 vs Am241 transmission for every material and distance.

    Parameters
    ----------
    dataset     : ParsedDataset.
    distance_cm : Restrict comparison to one distance. None → all distances.

    Returns
    -------
    plotly Figure
    """
    distances = [distance_cm] if distance_cm else dataset.distances

    fig = make_subplots(
        rows=1,
        cols=len(dataset.materials),
        subplot_titles=[f"<b>{MATERIAL_FULL.get(m, m)}</b>" for m in dataset.materials],
        horizontal_spacing=0.06,
    )

    for col_idx, mat in enumerate(dataset.materials, start=1):
        for iso in dataset.isotopes:
            color = ISOTOPE_COLORS.get(iso, "#888")

            x_vals, y_vals, y_err = [], [], []
            for dist in distances:
                gs_list = [
                    gs for gs in dataset.group_stats
                    if gs.isotope == iso and gs.distance_cm == dist
                ]
                if not gs_list:
                    continue
                gs = gs_list[0]
                x_vals.append(dist)
                y_vals.append(gs.transmission.get(mat, np.nan))
                y_err.append(gs.transmission_ci95.get(mat, 0.0))

            fig.add_trace(
                go.Scatter(
                    x=x_vals,
                    y=y_vals,
                    error_y=dict(type="data", array=y_err, visible=True, color=color, thickness=1.5),
                    mode="markers+lines",
                    marker=dict(color=color, size=10),
                    line=dict(color=color, width=2),
                    name=iso,
                    legendgroup=iso,
                    showlegend=(col_idx == 1),
                    hovertemplate=(
                        f"<b>{iso} / {mat}</b><br>"
                        "r = %{x} cm<br>"
                        "T_exp = %{y:.3f}<extra></extra>"
                    ),
                ),
                row=1, col=col_idx,
            )

            # NIST reference lines (constant vs distance)
            nist_t = expected_transmission(iso, mat)
            mu = MU_LINEAR.get(iso, {}).get(mat, None)
            x_filt = FILTER_THICKNESS_CM.get(mat, None)

            fig.add_hline(
                y=nist_t,
                line=dict(color=color, dash="dot", width=1.5),
                row=1, col=col_idx,
                annotation_text=f"NIST {iso}<br>T={nist_t:.3f}",
                annotation_position="right",
                annotation_font_size=9,
            )

    fig.update_layout(
        title=dict(
            text="<b>Cd-109 vs Am-241 Transmission Comparison by Material</b><br>"
                 "<sup>Dotted lines = Beer-Lambert prediction (NIST μ values)</sup>",
            x=0.5,
        ),
        template="plotly_white",
        height=480,
        legend=dict(orientation="h", y=-0.20, x=0.5, xanchor="center"),
        hoverlabel=dict(bgcolor="white", font_size=13),
    )

    for i in range(1, len(dataset.materials) + 1):
        fig.update_layout(**{f"yaxis{'' if i == 1 else i}": dict(range=[0, 1.08], title="Transmission T" if i == 1 else "")})
        fig.update_layout(**{f"xaxis{'' if i == 1 else i}": dict(title="Distance (cm)")})

    return fig


def plot_heatmap(dataset: ParsedDataset) -> go.Figure:
    """2-D heatmap: rows = materials, columns = (isotope, distance).

    Cell value is the mean experimental transmission fraction.
    """
    isotopes = dataset.isotopes
    distances = dataset.distances
    materials = dataset.materials

    col_labels = [f"{iso}<br>{d} cm" for iso in isotopes for d in distances]
    z_matrix = []
    nist_matrix = []
    text_matrix = []

    for mat in materials:
        row_z, row_nist, row_text = [], [], []
        for iso in isotopes:
            for dist in distances:
                gs_list = [
                    gs for gs in dataset.group_stats
                    if gs.isotope == iso and gs.distance_cm == dist
                ]
                t_exp = gs_list[0].transmission.get(mat, np.nan) if gs_list else np.nan
                t_nist = expected_transmission(iso, mat)
                row_z.append(t_exp)
                row_nist.append(t_nist)
                disc = 100 * (t_exp - t_nist) / t_nist if not np.isnan(t_exp) and t_nist > 0 else np.nan
                row_text.append(
                    f"T_exp={t_exp:.3f}<br>T_NIST={t_nist:.3f}<br>Δ={disc:+.1f}%"
                    if not np.isnan(t_exp) else "N/A"
                )
        z_matrix.append(row_z)
        nist_matrix.append(row_nist)
        text_matrix.append(row_text)

    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=["<b>Experimental Transmission</b>", "<b>NIST Beer-Lambert Reference</b>"],
        horizontal_spacing=0.12,
    )

    for col_idx, (z, title) in enumerate([(z_matrix, "Exp."), (nist_matrix, "NIST")], start=1):
        fig.add_trace(
            go.Heatmap(
                z=z,
                x=col_labels,
                y=materials,
                colorscale="RdYlGn",
                zmin=0, zmax=1,
                text=text_matrix if col_idx == 1 else None,
                texttemplate="%{z:.3f}" if col_idx == 1 else "%{z:.3f}",
                colorbar=dict(
                    title="T",
                    len=0.85,
                    x=0.46 if col_idx == 1 else 1.01,
                ),
                hovertemplate="Material: %{y}<br>Condition: %{x}<br>T = %{z:.3f}<extra></extra>",
            ),
            row=1, col=col_idx,
        )

    fig.update_layout(
        title=dict(
            text="<b>Transmission Heatmap: Experimental vs NIST</b>",
            x=0.5,
        ),
        template="plotly_white",
        height=400,
        hoverlabel=dict(bgcolor="white", font_size=13),
    )
    return fig


def plot_mu_comparison(dataset: ParsedDataset) -> go.Figure:
    """Bar chart comparing experimental vs NIST linear attenuation coefficients.

    The experimental μ is back-calculated from the mean transmission ratio
    and the known filter thickness: μ_exp = -ln(T_exp) / x.
    """
    from radiapy.physics.nist_data import FILTER_THICKNESS_CM, MU_LINEAR

    fig = go.Figure()

    x_labels = []
    y_exp, y_nist, y_disc = [], [], []

    for iso in dataset.isotopes:
        gs_10 = next((gs for gs in dataset.group_stats if gs.isotope == iso and gs.distance_cm == 10.0), None)
        if gs_10 is None:
            continue
        for mat in dataset.materials:
            t_exp = gs_10.transmission.get(mat, np.nan)
            t_sem = gs_10.transmission_sem.get(mat, 0.0)
            x_filt = FILTER_THICKNESS_CM.get(mat, None)
            mu_nist = MU_LINEAR.get(iso, {}).get(mat, np.nan)

            if np.isnan(t_exp) or not x_filt or t_exp <= 0:
                continue

            mu_exp = -np.log(t_exp) / x_filt
            # Error propagation: σ(μ) = σ(T) / (T * x)
            mu_sem = t_sem / (t_exp * x_filt) if t_exp > 0 else 0.0
            disc = 100 * (mu_exp - mu_nist) / mu_nist if mu_nist > 0 else np.nan

            label = f"{iso}<br>{mat}"
            x_labels.append(label)
            y_exp.append(mu_exp)
            y_nist.append(mu_nist)
            y_disc.append(disc)

    fig.add_trace(go.Bar(
        x=x_labels, y=y_exp,
        name="μ experimental (cm⁻¹)",
        marker_color="#3498DB",
        hovertemplate="<b>%{x}</b><br>μ_exp = %{y:.3f} cm⁻¹<extra></extra>",
    ))
    fig.add_trace(go.Bar(
        x=x_labels, y=y_nist,
        name="μ NIST (cm⁻¹)",
        marker_color="#E67E22",
        hovertemplate="<b>%{x}</b><br>μ_NIST = %{y:.3f} cm⁻¹<extra></extra>",
    ))

    fig.update_layout(
        title=dict(
            text="<b>Experimental vs NIST Linear Attenuation Coefficients</b>",
            x=0.5,
        ),
        yaxis=dict(title="μ (cm⁻¹)"),
        barmode="group",
        template="plotly_white",
        height=460,
        legend=dict(orientation="h", y=-0.20, x=0.5, xanchor="center"),
    )
    return fig
