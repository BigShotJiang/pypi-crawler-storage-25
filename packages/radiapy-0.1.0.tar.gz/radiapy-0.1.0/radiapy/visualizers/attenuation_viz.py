"""Attenuation visualizer: bar chart with Beer-Lambert overlay."""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from radiapy.parsers.base_parser import ParsedDataset
from radiapy.physics.nist_data import expected_transmission, FILTER_THICKNESS_CM, MU_LINEAR

MATERIAL_COLORS = {"Al": "#4C9BE8", "Cu": "#E8834C", "Pb": "#7E4CE8"}
MATERIAL_FULL = {"Al": "Aluminium (Al)", "Cu": "Copper (Cu)", "Pb": "Lead (Pb)"}


def plot_attenuation(
    dataset: ParsedDataset,
    isotope: str | None = None,
    distance_cm: float | None = None,
    show_nist: bool = True,
) -> go.Figure:
    """Interactive grouped bar chart of transmission by material.

    Each bar represents the mean experimental transmission T = counts_filter /
    counts_free for one material. Error bars show the 95% confidence interval.
    If ``show_nist`` is True, horizontal markers indicate the Beer-Lambert
    prediction using NIST μ values.

    Parameters
    ----------
    dataset     : ParsedDataset from a parser.
    isotope     : Filter to a single isotope. None → all isotopes (subplots).
    distance_cm : Filter to a single distance. None → all distances averaged.
    show_nist   : Overlay theoretical Beer-Lambert transmission.

    Returns
    -------
    plotly Figure
    """
    isotopes = [isotope] if isotope else dataset.isotopes
    distances = [distance_cm] if distance_cm else dataset.distances

    n_iso = len(isotopes)
    fig = make_subplots(
        rows=1,
        cols=n_iso,
        subplot_titles=[f"<b>{iso}</b>" for iso in isotopes],
        horizontal_spacing=0.08,
    )

    for col_idx, iso in enumerate(isotopes, start=1):
        stats_for_iso = [
            gs for gs in dataset.group_stats
            if gs.isotope == iso and gs.distance_cm in distances
        ]

        # Average across distances if multiple selected
        _agg: dict[str, list[float]] = {mat: [] for mat in dataset.materials}
        _agg_ci: dict[str, list[float]] = {mat: [] for mat in dataset.materials}
        for gs in stats_for_iso:
            for mat in dataset.materials:
                if mat in gs.transmission:
                    _agg[mat].append(gs.transmission[mat])
                    _agg_ci[mat].append(gs.transmission_ci95.get(mat, 0.0))

        for mat in dataset.materials:
            means = _agg[mat]
            cis = _agg_ci[mat]
            if not means:
                continue
            mean_t = float(np.mean(means))
            ci = float(np.mean(cis))

            nist_t = expected_transmission(iso, mat) if (show_nist and mat in FILTER_THICKNESS_CM) else None
            mu = MU_LINEAR.get(iso, {}).get(mat, None)
            x_filt = FILTER_THICKNESS_CM.get(mat, None)

            hover = (
                f"<b>{MATERIAL_FULL.get(mat, mat)}</b><br>"
                f"T_exp = {mean_t:.3f} ± {ci:.3f} (95% CI)<br>"
                + (f"T_NIST = {nist_t:.3f}<br>" if nist_t is not None else "")
                + (f"μ = {mu:.3f} cm⁻¹, x = {x_filt} cm" if mu and x_filt else "")
            )

            fig.add_trace(
                go.Bar(
                    x=[MATERIAL_FULL.get(mat, mat)],
                    y=[mean_t],
                    error_y=dict(type="data", array=[ci], visible=True, color="#555"),
                    marker_color=MATERIAL_COLORS.get(mat, "#888"),
                    name=f"{mat} ({iso})",
                    legendgroup=mat,
                    showlegend=(col_idx == 1),
                    hovertemplate=hover + "<extra></extra>",
                ),
                row=1,
                col=col_idx,
            )

            if nist_t is not None:
                fig.add_shape(
                    type="line",
                    x0=-0.4, x1=0.4,
                    y0=nist_t, y1=nist_t,
                    line=dict(color="black", width=2, dash="dash"),
                    row=1, col=col_idx,
                    xref=f"x{col_idx}",
                    yref=f"y{col_idx}",
                )

        if show_nist:
            fig.add_trace(
                go.Scatter(
                    x=[None], y=[None],
                    mode="lines",
                    line=dict(color="black", width=2, dash="dash"),
                    name="NIST Beer-Lambert",
                    showlegend=(col_idx == 1),
                ),
                row=1, col=col_idx,
            )

    dist_label = (
        f"distance = {distance_cm} cm"
        if distance_cm
        else f"distances = {distances} cm (averaged)"
    )

    fig.update_layout(
        title=dict(
            text=f"<b>Transmission Fraction by Absorber Material</b><br>"
                 f"<sup>{dist_label}</sup>",
            x=0.5,
        ),
        yaxis=dict(title="Transmission T = I/I₀", range=[0, 1.05]),
        barmode="group",
        legend=dict(orientation="h", y=-0.18, x=0.5, xanchor="center"),
        template="plotly_white",
        height=480,
        hoverlabel=dict(bgcolor="white", font_size=13),
    )

    for i in range(2, n_iso + 1):
        fig.update_layout(**{f"yaxis{i}": dict(range=[0, 1.05])})

    return fig


def plot_attenuation_spectrum(materials: list[str] | None = None) -> go.Figure:
    """Plot NIST mu/rho vs energy for the selected materials.

    This diagnostic plot shows the full photon attenuation spectrum including
    the Pb K-edge discontinuity at 88.005 keV.

    Parameters
    ----------
    materials : list of material keys. Defaults to all three (Al, Cu, Pb).

    Returns
    -------
    plotly Figure
    """
    import math
    from radiapy.physics.nist_data import NIST_SPECTRUM, ISOTOPE_ENERGY

    if materials is None:
        materials = ["Al", "Cu", "Pb"]

    fig = go.Figure()

    for mat in materials:
        spec = NIST_SPECTRUM.get(mat, {})
        if not spec:
            continue
        fig.add_trace(
            go.Scatter(
                x=spec["energy_keV"],
                y=spec["mu_over_rho"],
                mode="lines+markers",
                name=MATERIAL_FULL.get(mat, mat),
                line=dict(color=MATERIAL_COLORS.get(mat, "#888"), width=2.5),
                hovertemplate=f"<b>{mat}</b><br>E = %{{x:.2f}} keV<br>μ/ρ = %{{y:.4f}} cm²/g<extra></extra>",
            )
        )

    # Vertical lines for isotope energies — added as shapes (not add_vline) to
    # avoid the Plotly bug where add_vline on a log axis corrupts autorange.
    for iso, energy in ISOTOPE_ENERGY.items():
        fig.add_shape(
            type="line",
            x0=energy, x1=energy,
            y0=0, y1=1,
            xref="x", yref="paper",
            line=dict(dash="dot", color="gray", width=1.5),
        )
        fig.add_annotation(
            x=math.log10(energy),
            y=0.97,
            xref="x", yref="paper",
            text=f"<b>{iso}</b><br>{energy} keV",
            showarrow=False,
            font=dict(size=10, color="gray"),
            bgcolor="rgba(255,255,255,0.75)",
            xanchor="center",
        )

    # K-edge annotation — position in data coordinates so log scale is correct
    fig.add_annotation(
        x=math.log10(88.005),
        y=0.60,
        xref="x", yref="paper",
        text="Pb K-edge<br>(88.005 keV)",
        showarrow=True,
        arrowhead=2,
        ax=40, ay=-30,
        bgcolor="rgba(255,255,200,0.92)",
        font=dict(size=11),
    )

    # Explicit log10 range: 20 keV to 250 keV covers all NIST data points
    # and both isotope energies with comfortable margins.
    x_range = [math.log10(20), math.log10(250)]

    fig.update_layout(
        title=dict(
            text="<b>NIST Mass Attenuation Coefficients μ/ρ vs Photon Energy</b><br>"
                 "<sup>Pb K-edge at 88.005 keV — Cd-109 (88.034 keV) sits just above it</sup>",
            x=0.5,
        ),
        xaxis=dict(
            title="Photon Energy (keV)",
            type="log",
            range=x_range,      # explicit range prevents Plotly from auto-expanding to 10^90
            tickvals=[20, 30, 40, 50, 60, 80, 100, 150, 200],
            ticktext=["20", "30", "40", "50", "60", "80", "100", "150", "200"],
        ),
        yaxis=dict(title="μ/ρ (cm²/g)", type="log"),
        template="plotly_white",
        height=520,
        legend=dict(orientation="h", y=-0.18, x=0.5, xanchor="center"),
        hoverlabel=dict(bgcolor="white", font_size=13),
    )
    return fig
