"""Parser for ASCII output files produced by GEANT4 simulations.

Expected format (one header line, then space-delimited rows)::

    # Isotope  Distance_cm  Material  Counts
    Am241      10.0         Al        1234
    Am241      10.0         Cu         876
    ...

The exact column names are configurable via ``schema``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from radiapy.parsers.base_parser import BaseParser, ParsedDataset

DEFAULT_GEANT4_SCHEMA: dict[str, Any] = {
    "comment_char": "#",
    "isotope_col": "Isotope",
    "distance_col": "Distance_cm",
    "material_col": "Material",
    "counts_col": "Counts",
    "free_material_label": "free",
}


class GEANT4Parser(BaseParser):
    """Parse ASCII-format GEANT4 output into a ParsedDataset.

    Parameters
    ----------
    path : str or Path
        Path to the GEANT4 ASCII output file.
    schema : dict, optional
        Column mapping. Defaults to ``DEFAULT_GEANT4_SCHEMA``.

    Notes
    -----
    The parser pivots the long-format GEANT4 table (one row per material)
    into the wide format expected by the visualizers, then calls the same
    ``_compute_group_stats`` used by ``CSVParser``.
    """

    def __init__(self, path: str | Path, schema: dict | None = None) -> None:
        self.path = Path(path)
        self.schema = {**DEFAULT_GEANT4_SCHEMA, **(schema or {})}

    def parse(self) -> ParsedDataset:
        df = pd.read_csv(
            self.path,
            comment=self.schema["comment_char"],
            sep=r"\s+",
            names=[
                self.schema["isotope_col"],
                self.schema["distance_col"],
                self.schema["material_col"],
                self.schema["counts_col"],
            ],
        )

        iso_col = self.schema["isotope_col"]
        dist_col = self.schema["distance_col"]
        mat_col = self.schema["material_col"]
        cnt_col = self.schema["counts_col"]
        free_label = self.schema["free_material_label"]

        df[dist_col] = pd.to_numeric(df[dist_col], errors="coerce")
        df[cnt_col] = pd.to_numeric(df[cnt_col], errors="coerce")
        df = df.dropna()

        materials = sorted(m for m in df[mat_col].unique() if m != free_label)

        # Pivot to wide: one row per (isotope, distance), columns per material
        wide = df.pivot_table(
            index=[iso_col, dist_col], columns=mat_col, values=cnt_col, aggfunc="sum"
        ).reset_index()
        wide.columns.name = None

        if free_label not in wide.columns:
            raise ValueError(
                f"Column for free-field counts ('{free_label}') not found after pivot. "
                f"Available material labels: {df[mat_col].unique().tolist()}"
            )

        filter_cols = {mat: mat for mat in materials}
        wide.rename(columns={free_label: "counts_free"}, inplace=True)
        wide.rename(columns={iso_col: "isotope", dist_col: "distance_cm"}, inplace=True)

        isotopes = sorted(wide["isotope"].unique().tolist())
        distances = sorted(wide["distance_cm"].unique().tolist())

        group_stats = []
        for isotope in isotopes:
            for distance in distances:
                mask = (wide["isotope"] == isotope) & (wide["distance_cm"] == distance)
                group = wide[mask]
                if group.empty:
                    continue
                gs = self._compute_group_stats(
                    group=group,
                    free_col="counts_free",
                    filter_cols=filter_cols,
                    ratio_cols=None,
                    isotope=isotope,
                    distance=float(distance),
                )
                group_stats.append(gs)

        return ParsedDataset(
            raw=wide,
            isotopes=isotopes,
            distances=[float(d) for d in distances],
            materials=materials,
            group_stats=group_stats,
        )
