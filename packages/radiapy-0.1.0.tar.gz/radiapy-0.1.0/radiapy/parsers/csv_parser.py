"""Generic CSV parser for Geiger-counter radiation experiments."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from radiapy.parsers.base_parser import BaseParser, ParsedDataset

# Default column schema that matches the bundled dataset_geiger.csv
DEFAULT_SCHEMA: dict[str, Any] = {
    "isotope_col": "isotope",
    "distance_col": "distance_cm",
    "free_count_col": "counts_free",
    "filter_cols": {
        "Al": "counts_Al",
        "Cu": "counts_Cu",
        "Pb": "counts_Pb",
    },
    "ratio_cols": {
        "Al": "Al_ratio",
        "Cu": "Cu_ratio",
        "Pb": "Pb_ratio",
    },
}


class CSVParser(BaseParser):
    """Parse a CSV file from a real radiation detector into a ParsedDataset.

    Parameters
    ----------
    path : str or Path
        Path to the CSV file.
    schema : dict, optional
        Column mapping. Defaults to ``DEFAULT_SCHEMA`` which matches the
        bundled ``dataset_geiger.csv``. Provide a custom dict to use with
        other datasets — the keys must match those of DEFAULT_SCHEMA.

    Examples
    --------
    >>> from radiapy.parsers import CSVParser
    >>> ds = CSVParser("dataset_geiger.csv").parse()
    >>> print(ds.stats_df())
    """

    def __init__(self, path: str | Path, schema: dict | None = None) -> None:
        self.path = Path(path)
        self.schema = {**DEFAULT_SCHEMA, **(schema or {})}

    def parse(self) -> ParsedDataset:
        """Load and aggregate the CSV into a ParsedDataset."""
        df = pd.read_csv(self.path)
        df = self._validate_and_coerce(df)

        isotope_col = self.schema["isotope_col"]
        distance_col = self.schema["distance_col"]
        free_col = self.schema["free_count_col"]
        filter_cols: dict[str, str] = self.schema["filter_cols"]
        ratio_cols: dict[str, str] = self.schema.get("ratio_cols", {})

        isotopes = sorted(df[isotope_col].unique().tolist())
        distances = sorted(df[distance_col].unique().tolist())
        materials = list(filter_cols.keys())

        group_stats = []
        for isotope in isotopes:
            for distance in distances:
                mask = (df[isotope_col] == isotope) & (df[distance_col] == distance)
                group = df[mask]
                if group.empty:
                    continue
                gs = self._compute_group_stats(
                    group=group,
                    free_col=free_col,
                    filter_cols=filter_cols,
                    ratio_cols=ratio_cols,
                    isotope=isotope,
                    distance=float(distance),
                )
                group_stats.append(gs)

        return ParsedDataset(
            raw=df,
            isotopes=isotopes,
            distances=[float(d) for d in distances],
            materials=materials,
            group_stats=group_stats,
        )

    def _validate_and_coerce(self, df: pd.DataFrame) -> pd.DataFrame:
        required = [
            self.schema["isotope_col"],
            self.schema["distance_col"],
            self.schema["free_count_col"],
        ] + list(self.schema["filter_cols"].values())

        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(
                f"CSV is missing required columns: {missing}\n"
                f"Available columns: {df.columns.tolist()}\n"
                "Pass a custom schema dict to CSVParser to remap column names."
            )

        num_cols = [self.schema["distance_col"], self.schema["free_count_col"]] + list(
            self.schema["filter_cols"].values()
        )
        for col in num_cols:
            df[col] = pd.to_numeric(df[col], errors="coerce")

        return df.dropna(subset=[self.schema["free_count_col"]])
