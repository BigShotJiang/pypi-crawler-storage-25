"""Abstract base class for all Radiapy data parsers."""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class GroupStats:
    """Aggregated statistics for one (isotope, distance) group."""

    isotope: str
    distance_cm: float
    n_replicates: int
    counts_free_mean: float
    counts_free_std: float
    counts_free_sem: float
    transmission: dict[str, float] = field(default_factory=dict)
    transmission_std: dict[str, float] = field(default_factory=dict)
    transmission_sem: dict[str, float] = field(default_factory=dict)
    transmission_ci95: dict[str, float] = field(default_factory=dict)


@dataclass
class ParsedDataset:
    """Container returned by every parser."""

    raw: pd.DataFrame
    isotopes: list[str]
    distances: list[float]
    materials: list[str]
    group_stats: list[GroupStats]

    def stats_df(self) -> pd.DataFrame:
        """Return group statistics as a tidy DataFrame."""
        rows = []
        for gs in self.group_stats:
            base = {
                "isotope": gs.isotope,
                "distance_cm": gs.distance_cm,
                "n": gs.n_replicates,
                "counts_free_mean": gs.counts_free_mean,
                "counts_free_std": gs.counts_free_std,
                "counts_free_sem": gs.counts_free_sem,
            }
            for mat in self.materials:
                base[f"{mat}_T_mean"] = gs.transmission.get(mat, np.nan)
                base[f"{mat}_T_std"] = gs.transmission_std.get(mat, np.nan)
                base[f"{mat}_T_sem"] = gs.transmission_sem.get(mat, np.nan)
                base[f"{mat}_T_ci95"] = gs.transmission_ci95.get(mat, np.nan)
            rows.append(base)
        return pd.DataFrame(rows)


class BaseParser(ABC):
    """Common interface for all Radiapy parsers."""

    @abstractmethod
    def parse(self) -> ParsedDataset:
        """Parse the data source and return a ParsedDataset."""

    @staticmethod
    def _compute_group_stats(
        group: pd.DataFrame,
        free_col: str,
        filter_cols: dict[str, str],
        ratio_cols: dict[str, str] | None,
        isotope: str,
        distance: float,
    ) -> GroupStats:
        """Compute descriptive statistics for one experimental group."""
        from scipy.stats import t as t_dist

        n = len(group)
        free_vals = group[free_col].values.astype(float)
        counts_mean = float(np.mean(free_vals))
        counts_std = float(np.std(free_vals, ddof=1))
        counts_sem = counts_std / np.sqrt(n)

        transmission: dict[str, float] = {}
        transmission_std: dict[str, float] = {}
        transmission_sem: dict[str, float] = {}
        transmission_ci95: dict[str, float] = {}

        t_crit = float(t_dist.ppf(0.975, df=max(n - 1, 1)))

        for mat, col in filter_cols.items():
            if ratio_cols and mat in ratio_cols and ratio_cols[mat] in group.columns:
                ratios = group[ratio_cols[mat]].values.astype(float)
            else:
                filter_vals = group[col].values.astype(float)
                with np.errstate(divide="ignore", invalid="ignore"):
                    ratios = np.where(free_vals > 0, filter_vals / free_vals, np.nan)

            valid = ratios[~np.isnan(ratios)]
            if len(valid) == 0:
                transmission[mat] = np.nan
                transmission_std[mat] = np.nan
                transmission_sem[mat] = np.nan
                transmission_ci95[mat] = np.nan
                continue

            t_mean = float(np.mean(valid))
            t_std = float(np.std(valid, ddof=1)) if len(valid) > 1 else 0.0
            t_sem = t_std / np.sqrt(len(valid))
            ci95 = t_crit * t_sem

            transmission[mat] = t_mean
            transmission_std[mat] = t_std
            transmission_sem[mat] = t_sem
            transmission_ci95[mat] = ci95

        return GroupStats(
            isotope=isotope,
            distance_cm=distance,
            n_replicates=n,
            counts_free_mean=counts_mean,
            counts_free_std=counts_std,
            counts_free_sem=counts_sem,
            transmission=transmission,
            transmission_std=transmission_std,
            transmission_sem=transmission_sem,
            transmission_ci95=transmission_ci95,
        )
