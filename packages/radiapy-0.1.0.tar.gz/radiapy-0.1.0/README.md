# Radiapy

**Interactive visualization of radiation experiments and radiation-matter interactions.**

Radiapy is an open-source Python library for analysing and visualising Geiger-counter radiation attenuation experiments. It implements the Beer-Lambert law, the inverse-square law, and NIST photon attenuation data, and renders every plot as an interactive Plotly figure exportable to standalone HTML — no ROOT, VTK, or GEANT4 required.

---

## Installation

```bash
pip install radiapy
```

Or from source:

```bash
git clone https://github.com/radviz/radiapy
cd radiapy
pip install -e ".[dev]"
```

**Requirements:** Python ≥ 3.10, plotly, pandas, numpy, scipy, click

---

## Quick start

```python
from radviz import RadViz

rv = RadViz("radviz/demo/dataset_geiger.csv")

# Generate a complete standalone HTML dashboard
rv.generate_dashboard("dashboard.html")

# Individual interactive plots
fig = rv.plot_attenuation()           # Bar chart: T by material + NIST overlay
fig = rv.plot_inverse_square()        # Counts vs distance + 1/r² fit
fig = rv.plot_heatmap()               # 2-D transmission heatmap
fig = rv.plot_comparison()            # Cd109 vs Am241 side-by-side
fig = rv.plot_particles()             # Animated photon trajectories
fig.show()

# Physics report
print(rv.physics_report())
```

## Command-line interface

```bash
# Full dashboard
radviz dashboard dataset_geiger.csv --output dashboard.html

# Physics report
radviz report dataset_geiger.csv

# Particle animation (no CSV needed)
radviz simulate --isotope Cd109 --material Pb --output anim.html

# Legacy single-command form
radviz --input dataset_geiger.csv --output dashboard.html
```

---

## Dataset format

The bundled `dataset_geiger.csv` has the following columns:

| Column | Description |
|--------|-------------|
| `isotope` | Source isotope (`Cd109` or `Am241`) |
| `distance_cm` | Source-detector distance (10, 20, 30 cm) |
| `counts_free` | Raw counts without absorber |
| `counts_Al` | Counts through aluminium filter |
| `counts_Cu` | Counts through copper filter |
| `counts_Pb` | Counts through lead filter |
| `counts_free_mean` | Mean free-field counts for this (isotope, distance) group |
| `Al_ratio` | Transmission fraction: `counts_Al / counts_free` |
| `Cu_ratio` | Transmission fraction: `counts_Cu / counts_free` |
| `Pb_ratio` | Transmission fraction: `counts_Pb / counts_free` |

To use a custom CSV, pass a `schema` dict to `RadViz`:

```python
schema = {
    "isotope_col": "source",
    "distance_col": "dist_cm",
    "free_count_col": "N_free",
    "filter_cols": {"Al": "N_Al", "Cu": "N_Cu", "Pb": "N_Pb"},
}
rv = RadViz("my_data.csv", schema=schema)
```

---

## Physics Background

### Beer-Lambert attenuation law

When a beam of photons passes through a material of thickness *x* (cm), its intensity is reduced according to:

```
I = I₀ · exp(−μ · x)
```

where:
- `I₀` is the incident intensity (counts without absorber),
- `I` is the transmitted intensity,
- `μ` (cm⁻¹) is the **linear attenuation coefficient**, which depends on the material and the photon energy,
- `T = I / I₀ ∈ [0, 1]` is the **transmission fraction**.

The linear coefficient relates to the tabulated **mass attenuation coefficient** as `μ = (μ/ρ) · ρ`, where `ρ` is the material density (g/cm³).

Radiapy fits `μ` experimentally from the measured transmission ratios via `scipy.optimize.curve_fit` (with full covariance matrix for uncertainty propagation), and compares each fitted value against the NIST reference. The experimental coefficient is back-calculated as `μ_exp = −ln(T_exp) / x`.

### Inverse-square law

For a point source radiating isotropically, the intensity at distance *r* from the source falls off as:

```
I(r) = A / r²
```

where `A` is a constant proportional to the source activity and detector efficiency. This geometric dilution of intensity over the surface of an expanding sphere means that doubling the distance reduces counts to one quarter. Radiapy fits `A` with uncertainty via `scipy.optimize.curve_fit` and reports R² as a goodness-of-fit metric.

A diagnostic plot of `I · r²` vs `r` (the "1/r² diagnostic" tab) should yield a horizontal line; deviations indicate room scatter, geometry effects, or a non-point-like source.

### The Pb K-edge and the counterintuitive Cd-109 / Am-241 reversal

Every element has characteristic **absorption edges** — energies at which a new inner-shell photoelectric absorption channel opens as photon energy increases past the binding energy of that electron shell. For **lead (Pb)**, the K-shell binding energy is **88.005 keV**.

The two isotopes in this experiment straddle that edge:

| Isotope | Main γ energy | Position relative to Pb K-edge |
|---------|--------------|-------------------------------|
| Am-241  | 59.54 keV    | **Below** — K shell cannot be ionised |
| Cd-109  | 88.034 keV   | **Just above** — K shell is ionised |

This creates a **counterintuitive reversal**: even though Cd-109 photons are *higher energy* than Am-241 photons (and high-energy photons generally penetrate matter more easily), Pb attenuates Cd-109 *more strongly* because the K-shell photoelectric cross-section is suddenly available. The `μ/ρ` of Pb jumps from ~2.0 cm²/g just below the edge to ~13.9 cm²/g just above — a ~7× increase. This effect is clearly visible in the **Cd109 vs Am241** comparison tab of the dashboard.

### NIST reference data

All theoretical values are taken from:

- **NIST XCOM** — *Photon Cross Sections Database*, Standard Reference Database 8 (XGAM).  
  Berger, M.J., Hubbell, J.H., Seltzer, S.M., Chang, J., Coursey, J.S., Sukumar, R., Zucker, D.S., and Olsen, K.  
  https://physics.nist.gov/PhysRefData/Xcom/html/xcom1.html

- **NIST Standard Reference Database 126** — *X-Ray Mass Attenuation Coefficients*, J.H. Hubbell and S.M. Seltzer.  
  https://www.nist.gov/pml/x-ray-mass-attenuation-coefficients

---

## NIST data

Hardcoded `μ/ρ` values (cm²/g) from [NIST XCOM](https://physics.nist.gov/PhysRefData/Xcom/html/xcom1.html):

| Material | ρ (g/cm³) | μ/ρ @ 59.5 keV | μ/ρ @ 88.034 keV |
|----------|-----------|----------------|------------------|
| Al | 2.699 | 0.3219 | 0.2226 |
| Cu | 8.960 | 0.8156 | 0.5082 |
| Pb | 11.35 | 5.549 | 13.93* |

\* Above Pb K-edge (88.005 keV).

---

## Demo dataset

Regenerate the synthetic demo dataset (Poisson-distributed, 50 replicates × 6 conditions):

```bash
python scripts/generate_demo_data.py
```

---

## Project structure

```
radiapy/
├── __init__.py          # from radiapy import RadViz
├── __main__.py          # python -m radiapy CSV [--output FILE]
├── core.py              # RadViz orchestrator class
├── cli.py               # Click CLI (radiapy dashboard / report / simulate)
├── parsers/
│   ├── base_parser.py   # Abstract base + GroupStats + ParsedDataset
│   ├── csv_parser.py    # Generic CSV → ParsedDataset
│   └── geant4_parser.py # GEANT4 ASCII output → ParsedDataset
├── physics/
│   ├── attenuation.py   # Beer-Lambert fit (curve_fit + pcov)
│   ├── inverse_square.py# 1/r² fit
│   └── nist_data.py     # NIST μ/ρ table, filter thicknesses
├── visualizers/
│   ├── attenuation_viz.py
│   ├── distance_viz.py
│   ├── comparison_viz.py
│   └── particle_viz.py  # Photon trajectories with thickness slider
├── exporters/
│   └── html_exporter.py # Standalone HTML dashboard (Plotly.js inline)
└── demo/
    └── dataset_geiger.csv
```

---

## Citation

If you use Radiapy in scientific work, please cite:

```bibtex
@software{radiapy2024,
  title   = {Radiapy: Interactive visualization of radiation experiments},
  year    = {2024},
  url     = {https://github.com/radviz/radiapy},
  version = {0.1.0}
}
```

Dataset: experimental Geiger-counter measurements of Cd-109 and Am-241 attenuation through Al, Cu, and Pb absorbers.

---

## License

MIT — see [LICENSE](LICENSE).
