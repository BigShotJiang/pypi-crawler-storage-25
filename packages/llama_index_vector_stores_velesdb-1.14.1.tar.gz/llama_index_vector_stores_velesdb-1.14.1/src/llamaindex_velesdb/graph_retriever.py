"""VelesDB Graph Retriever for LlamaIndex.

Provides a retriever that combines vector search with graph traversal
for context expansion in RAG applications.

Example:
    >>> from llamaindex_velesdb import VelesDBVectorStore, GraphRetriever
    >>> from llama_index.core import VectorStoreIndex
    >>>
    >>> vector_store = VelesDBVectorStore(path="./db", collection="docs")
    >>> index = VectorStoreIndex.from_vector_store(vector_store)
    >>>
    >>> # Native mode (no server required)
    >>> retriever = GraphRetriever(
    ...     index=index,
    ...     mode="native",
    ...     graph_collection_name="my_graph",
    ...     max_depth=2
    ... )
    >>>
    >>> # REST mode (backward-compatible)
    >>> retriever = GraphRetriever(
    ...     index=index,
    ...     mode="rest",
    ...     server_url="http://localhost:8080",
    ...     max_depth=2
    ... )
    >>>
    >>> nodes = retriever.retrieve("What is machine learning?")
"""

from typing import Any, List, Optional
import logging

from velesdb_common.ids import stable_hash_id
from llamaindex_velesdb._common import (
    build_graph_rest_payload,
    is_timeout_exception,
    open_native_graph,
    parse_graph_traverse_response,
)

# Lazy VelesDBError resolution. `velesdb` is a runtime dependency for
# every user of this integration (they pass a `velesdb.Collection`
# instance to the retriever), but the integration package itself is
# importable without it (e.g. for documentation, type-stubs, or smoke
# tests running without the compiled Rust extension). When the typed
# exception hierarchy is available we catch it alongside the built-in
# errors; otherwise we fall back to `Exception` which never breaks the
# defensive `try`/`except` logic below.
try:
    from velesdb import VelesDBError as _VelesDBError
except (ImportError, AttributeError):  # pragma: no cover — optional dependency fallback
    _VelesDBError = Exception  # type: ignore[misc,assignment]

logger = logging.getLogger(__name__)

try:
    from llama_index.core.retrievers import BaseRetriever
    from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode
except ImportError:
    # Fallback for older llama-index versions
    from llama_index.retrievers import BaseRetriever
    from llama_index.schema import NodeWithScore, QueryBundle, TextNode


def _infer_db_path(index: Any) -> Optional[str]:
    """Try to infer the database path from an index's vector store."""
    try:
        vs = index._vector_store
        for attr in ("_db_path", "_path", "_data_path"):
            path = getattr(vs, attr, None)
            if path is not None:
                return str(path)
    except AttributeError as exc:
        logger.debug("Failed to infer db_path from index: %s", exc)
    return None


class GraphRetriever(BaseRetriever):
    """Retriever that uses graph traversal for context expansion.

    This retriever implements the "seed + expand" pattern:
    1. Vector search to find initial seed nodes
    2. Graph traversal to expand context to related nodes
    3. Return combined results for RAG

    Supports two modes:

    - ``"native"`` (default): uses the VelesDB Python bindings directly,
      no server required. Requires either ``db_path`` or an index whose
      vector store exposes ``_db_path`` / ``_path``, plus
      ``graph_collection_name``.
    - ``"rest"``: legacy HTTP mode — calls the VelesDB REST server.
      Requires ``server_url``.

    Args:
        index: VectorStoreIndex with VelesDBVectorStore.
        mode: Operation mode, ``"native"`` or ``"rest"`` (default: ``"native"``).
        db_path: Filesystem path to VelesDB data directory (native mode).
        graph_collection_name: Name of the graph collection (native mode).
        server_url: URL of VelesDB server (REST mode only).
        seed_k: Number of initial vector search results (default: 3).
        expand_k: Maximum nodes to include after expansion (default: 10).
        max_depth: Maximum graph traversal depth (default: 2).
        rel_types: Relationship types to follow (default: all).
        collection_name: Override collection name for REST traversal URL.
        low_latency: If True, skip graph expansion for minimal latency (default: False).
        timeout_ms: Timeout for REST graph operations in milliseconds (default: 1000).
        fallback_on_timeout: If True, return vector-only results on timeout (default: True).

    Example:
        >>> # Native mode — preferred
        >>> retriever = GraphRetriever(
        ...     index=index,
        ...     mode="native",
        ...     graph_collection_name="my_graph",
        ...     seed_k=3,
        ...     expand_k=10,
        ...     max_depth=2
        ... )
        >>>
        >>> # REST mode — backward-compatible
        >>> retriever = GraphRetriever(
        ...     index=index,
        ...     mode="rest",
        ...     server_url="http://localhost:8080",
        ...     seed_k=3,
        ...     expand_k=10,
        ...     max_depth=2
        ... )
        >>>
        >>> # Minimal latency mode (vector search only)
        >>> fast_retriever = GraphRetriever(
        ...     index=index,
        ...     low_latency=True
        ... )
    """

    def __init__(
        self,
        index: Any,  # VectorStoreIndex
        mode: str = "native",
        db_path: Optional[str] = None,
        graph_collection_name: Optional[str] = None,
        server_url: str = "http://localhost:8080",
        seed_k: int = 3,
        expand_k: int = 10,
        max_depth: int = 2,
        rel_types: Optional[List[str]] = None,
        collection_name: Optional[str] = None,
        low_latency: bool = False,
        timeout_ms: int = 1000,
        fallback_on_timeout: bool = True,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)

        if mode not in ("native", "rest"):
            raise ValueError(
                f"Invalid mode '{mode}'. Must be 'native' or 'rest'."
            )

        from llamaindex_velesdb.security import validate_k
        validate_k(seed_k, "seed_k")
        validate_k(expand_k, "expand_k")

        if mode == "rest":
            from llamaindex_velesdb.security import validate_url
            validate_url(server_url)

        self._index = index
        self._mode = mode
        self._server_url = server_url
        self._seed_k = seed_k
        self._expand_k = expand_k
        self._max_depth = max_depth
        self._rel_types = rel_types or []
        self._collection_name = collection_name or self._infer_collection_name()
        self._low_latency = low_latency
        self._timeout_ms = timeout_ms
        self._fallback_on_timeout = fallback_on_timeout
        self._graph_collection: Any = None

        if mode == "native":
            self._graph_collection = self._init_native_graph(
                db_path, graph_collection_name
            )

    def _init_native_graph(
        self, db_path: Optional[str], collection_name: Optional[str]
    ) -> Any:
        """Resolve the shared Database and open the native graph collection.

        Reuses the index's vector store lazy Database instance (via
        ``_get_db()``) instead of opening a second ``velesdb.Database`` on
        the same path, which would trigger VELES-031 (exclusive write-lock).

        Falls back to path-based open when the vector store does not expose
        ``_get_db`` (e.g. REST-only stores or custom implementations).
        """
        if not collection_name:
            raise ValueError(
                "Native mode requires 'graph_collection_name'."
            )
        try:
            vs = self._index._vector_store
            get_db = getattr(vs, "_get_db", None)
        except AttributeError:
            get_db = None

        if get_db is not None:
            return self._open_graph_from_shared_db(get_db, collection_name)
        return self._open_graph_from_path(db_path, collection_name)

    def _open_graph_from_shared_db(
        self, get_db: Any, collection_name: str
    ) -> Any:
        """Open graph collection from the vector store's shared Database."""
        db = get_db()
        graph = db.get_graph_collection(collection_name)
        if graph is None:
            raise ValueError(
                f"Graph collection '{collection_name}' not found "
                "in the shared database."
            )
        return graph

    def _open_graph_from_path(
        self, db_path: Optional[str], collection_name: str
    ) -> Any:
        """Open graph collection by resolving db_path (fallback path)."""
        resolved_path = db_path or _infer_db_path(self._index)
        if resolved_path is None:
            raise ValueError(
                "Native mode requires 'db_path' or an index whose vector store "
                "exposes a '_db_path' / '_path' attribute."
            )
        return open_native_graph(resolved_path, collection_name)

    def _infer_collection_name(self) -> str:
        """Try to infer collection name from the index's vector store."""
        try:
            vs = self._index._vector_store
            if hasattr(vs, "_collection_name"):
                return vs._collection_name
            if hasattr(vs, "collection_name"):
                return vs.collection_name
        except AttributeError as exc:
            logger.debug("Failed to infer collection name from vector store: %s", exc)
        return "default"

    def _retrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        """Retrieve nodes using vector search + graph expansion.

        Args:
            query_bundle: Query bundle with query string.

        Returns:
            List of NodeWithScore objects.
        """
        query_str = query_bundle.query_str
        k = self._seed_k if self._low_latency else self._expand_k
        base_retriever = self._index.as_retriever(similarity_top_k=k)
        seed_nodes = base_retriever.retrieve(query_str)

        if not seed_nodes:
            return []

        if self._low_latency:
            return self._build_vector_only_results(seed_nodes)

        return self._build_expanded_results(seed_nodes)

    def _build_vector_only_results(
        self, seed_nodes: List[NodeWithScore]
    ) -> List[NodeWithScore]:
        """Return seed nodes annotated for vector-only mode."""
        for nws in seed_nodes[: self._expand_k]:
            nws.node.metadata["graph_depth"] = 0
            nws.node.metadata["retrieval_mode"] = "vector_only"
        return seed_nodes[: self._expand_k]

    def _build_expanded_results(
        self, seed_nodes: List[NodeWithScore]
    ) -> List[NodeWithScore]:
        """Run graph expansion and return combined node list."""
        expanded_ids: set = set()
        seed_map: dict = {}
        graph_available = True

        for nws in seed_nodes:
            node_id = self._extract_node_id(nws.node)
            if node_id is None:
                continue
            seed_map[node_id] = nws
            expanded_ids.add(node_id)

            if graph_available:
                graph_available = self._expand_from_seed(
                    node_id, expanded_ids, graph_available
                )

        return self._assemble_results(seed_map, expanded_ids, graph_available)

    def _expand_from_seed(
        self, node_id: int, expanded_ids: set, graph_available: bool
    ) -> bool:
        """Traverse graph from one seed node; return updated graph_available flag."""
        try:
            neighbors = self._traverse_graph(node_id)
            for neighbor_id in neighbors:
                expanded_ids.add(neighbor_id)
        except (ValueError, RuntimeError, OSError, TimeoutError, ConnectionError, _VelesDBError) as exc:
            if self._is_timeout(exc):
                logger.warning(
                    "Graph traversal timeout for node %s, falling back to vector-only",
                    node_id,
                )
                if self._fallback_on_timeout:
                    return False
                raise
            logger.debug("Graph traversal failed for node %s: %s", node_id, exc)
        return graph_available

    def _is_timeout(self, exc: Exception) -> bool:
        """Return True if the exception represents a network/operation timeout."""
        return is_timeout_exception(exc)

    def _assemble_results(
        self,
        seed_map: dict,
        expanded_ids: set,
        graph_available: bool,
    ) -> List[NodeWithScore]:
        """Build the final result list from seeds and expanded neighbours."""
        retrieval_mode = "graph_expanded" if graph_available else "vector_fallback"
        results: List[NodeWithScore] = []

        for _node_id, nws in seed_map.items():
            nws.node.metadata["graph_depth"] = 0
            nws.node.metadata["retrieval_mode"] = retrieval_mode
            results.append(nws)

        if graph_available:
            self._append_neighbor_nodes(results, expanded_ids, seed_map)

        return results[: self._expand_k]

    def _append_neighbor_nodes(
        self, results: List[NodeWithScore], expanded_ids: set, seed_map: dict
    ) -> None:
        """Fetch and append expanded neighbor nodes to the result list."""
        remaining = self._expand_k - len(results)
        neighbor_ids = [nid for nid in expanded_ids if nid not in seed_map][:remaining]
        for neighbor_id in neighbor_ids:
            try:
                neighbor_node = self._fetch_node(neighbor_id)
                if neighbor_node:
                    neighbor_node.metadata["graph_depth"] = 1
                    neighbor_node.metadata["retrieval_mode"] = "graph_expanded"
                    results.append(NodeWithScore(node=neighbor_node, score=0.5))
            except (ValueError, RuntimeError, OSError, KeyError, ConnectionError, _VelesDBError) as exc:
                logger.debug("Failed to fetch neighbour node %s: %s", neighbor_id, exc)

    def _extract_node_id(self, node: Any) -> Optional[int]:
        """Extract numeric node ID from a LlamaIndex node.

        ID convention (llamaindex): node IDs are **hash-based** via
        ``_stable_hash_id(node.node_id)``. The extraction path in practice
        is the ``_id_from_node_id`` fallback:

          1. ``_id_from_metadata`` looks for ``id`` / ``doc_id`` /
             ``node_id`` in ``node.metadata`` — in the default flow NONE
             of these are present (``node_builder.py`` stores ``id`` at
             the top level of the point dict, not in the payload; and
             ``vectorstore._metadata_from_payload`` explicitly excludes
             ``node_id`` from metadata).
          2. ``_id_from_node_id`` reads ``node.node_id`` (the UUID string
             assigned by LlamaIndex) and returns
             ``stable_hash_id(node.node_id)``.

        Callers adding graph edges MUST use the same ``_stable_hash_id``
        of the original ``node_id`` as ``source`` / ``target``. This
        differs from the langchain integration, which uses the internal
        VelesDB point ID via ``metadata["_int_id"]`` — see
        ``integrations/langchain/src/langchain_velesdb/graph_retriever.py``
        ``_build_expanded_results``.
        """
        try:
            found, from_meta = self._id_from_metadata(node)
            if found:
                return from_meta
            return self._id_from_node_id(node)
        except (AttributeError, KeyError) as exc:
            logger.debug("Failed to extract node id from node metadata: %s", exc)
        return None

    @staticmethod
    def _id_from_metadata(node: Any) -> tuple:
        """Try to extract an integer ID from node.metadata.

        Returns (found: bool, value: Optional[int]) so callers can
        distinguish 'no key matched' from 'key matched but unusable'.
        """
        if not hasattr(node, "metadata"):
            return False, None
        for key in ["id", "doc_id", "node_id"]:
            if key in node.metadata:
                val = node.metadata[key]
                if isinstance(val, int):
                    return True, val
                if isinstance(val, str):
                    try:
                        return True, int(val)
                    except ValueError:
                        return True, None
                return True, None
        return False, None

    @staticmethod
    def _id_from_node_id(node: Any) -> Optional[int]:
        """Try to extract an integer ID from node.node_id, falling back to hash."""
        if not hasattr(node, "node_id"):
            return None
        try:
            return int(node.node_id)
        except (ValueError, TypeError):
            return stable_hash_id(node.node_id)

    def _traverse_graph(self, source_id: int) -> List[int]:
        """Traverse graph from source node, dispatching to native or REST.

        Args:
            source_id: Starting node ID.

        Returns:
            List of neighbour node IDs.
        """
        if self._mode == "native":
            return self._traverse_graph_native(source_id)
        return self._traverse_graph_rest(source_id)

    def _traverse_graph_native(self, source_id: int) -> List[int]:
        """Traverse graph using the native Python bindings.

        Args:
            source_id: Starting node ID.

        Returns:
            List of neighbour node IDs.
        """
        results = self._graph_collection.traverse_bfs(
            source_id,
            max_depth=self._max_depth,
            limit=self._expand_k * 2,
            rel_types=self._rel_types,
        )
        return [r["target_id"] for r in results]

    def _traverse_graph_rest(self, source_id: int) -> List[int]:
        """Traverse graph via the VelesDB REST API.

        Args:
            source_id: Starting node ID.

        Returns:
            List of neighbour node IDs.

        Raises:
            requests.exceptions.Timeout: If the request exceeds ``timeout_ms``.
        """
        import requests

        url = f"{self._server_url}/collections/{self._collection_name}/graph/traverse"
        payload = build_graph_rest_payload(
            source_id, self._max_depth, self._expand_k, self._rel_types
        )
        timeout_sec = self._timeout_ms / 1000.0
        response = requests.post(url, json=payload, timeout=timeout_sec)
        return parse_graph_traverse_response(response)

    def _fetch_node(self, node_id: int) -> Optional[TextNode]:
        """Fetch a node by its **internal integer ID** (already hashed).

        ``node_id`` is the hash-based int returned by
        ``_extract_node_id`` / ``stable_hash_id(uuid)``. Delegates to
        :meth:`VelesDBVectorStore.get_nodes_by_int_ids`, which passes the
        ID straight to the underlying collection — using
        :meth:`~VelesDBVectorStore.get_nodes` instead would re-hash the
        int's string form and return nothing, making graph expansion a
        silent no-op.
        """
        try:
            vs = self._index._vector_store
            fetcher = getattr(vs, "get_nodes_by_int_ids", None)
            if fetcher is None:
                return None
            results = fetcher([node_id])
            return results[0] if results else None
        except (ValueError, RuntimeError, OSError, KeyError, ConnectionError, _VelesDBError) as exc:
            logger.debug("Failed to fetch node %s from vector store: %s", node_id, exc)
        return None


class GraphQARetriever(GraphRetriever):
    """Graph-enhanced retriever optimized for Q&A tasks.

    Extends GraphRetriever with:
    - Automatic re-ranking based on graph distance
    - Support for multi-hop reasoning
    """

    def __init__(
        self,
        index: Any,
        rerank_by_depth: bool = True,
        **kwargs: Any,
    ) -> None:
        super().__init__(index=index, **kwargs)
        self._rerank_by_depth = rerank_by_depth

    def _retrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        """Retrieve with re-ranking."""
        nodes = super()._retrieve(query_bundle)

        if self._rerank_by_depth:
            # Sort by graph depth, then by score
            nodes.sort(key=lambda n: (
                n.node.metadata.get("graph_depth", 999),
                -n.score
            ))

        return nodes
