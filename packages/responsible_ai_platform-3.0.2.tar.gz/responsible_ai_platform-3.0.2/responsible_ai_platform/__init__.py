"""Responsible AI Platform — SDK for evaluating AI assets.

Evaluation primitives organized by domain:

    from responsible_ai_platform.agentic import AgentTrace, trace, tool
    from responsible_ai_platform.agentic.integrations import log_langgraph_steps

Future domains (ML, RAG, LLM API) will live under
`responsible_ai_platform.ml`, `responsible_ai_platform.rag`, and
`responsible_ai_platform.llm` respectively. Shared plumbing lives in
`responsible_ai_platform._internal` and should not be imported directly —
use the domain submodules instead.
"""

__version__ = "0.4.0"
