"""Agentic evaluation primitives — tracing + decorators for AI agents.

Works with any agent framework (LangGraph, LangChain, CrewAI, custom).

1. Decorator-based (custom agents):

    from responsible_ai_platform.agentic import trace, tool

    @tool
    def search_kb(query: str) -> str: ...

    @trace(task_description="Handle billing query")
    def my_agent(query: str):
        return search_kb(query)

2. LangGraph / LangChain — one-line integration:

    from responsible_ai_platform.agentic import AgentTrace
    from responsible_ai_platform.agentic.integrations import log_langgraph_steps

    with AgentTrace(task_description="...") as t:
        result = agent.invoke({"messages": [HumanMessage(content=query)]})
        log_langgraph_steps(t, result["messages"])
        t.set_outcome("success")

3. Any framework — manual:

    from responsible_ai_platform.agentic import AgentTrace

    with AgentTrace(task_description="...") as t:
        t.log_step(tool="my_tool", args={...}, result="...")
        t.set_outcome("success")
"""

from .context import (
    get_current_agent,
    get_current_trace,
    set_current_agent,
    set_current_trace,
)
from .decorators import tool, trace, trace_subagent
from .trace import AgentTrace

__all__ = [
    "AgentTrace",
    "trace",
    "trace_subagent",
    "tool",
    "get_current_trace",
    "set_current_trace",
    "get_current_agent",
    "set_current_agent",
]
