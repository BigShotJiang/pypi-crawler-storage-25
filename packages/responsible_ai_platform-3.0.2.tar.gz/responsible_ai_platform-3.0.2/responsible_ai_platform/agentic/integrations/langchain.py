"""RAIA SDK integration for LangChain agents (e.g. ``AgentExecutor``,
``create_react_agent``).

Thin façade over the shared message-extraction implementation in
``_messages.py``. LangChain, LangGraph and LangChain-AWS all emit the same
LangChain ``Message`` objects, so the logic is shared; this module just
exposes it under LangChain-named entry points.

Usage:
    from responsible_ai_platform.agentic import AgentTrace
    from responsible_ai_platform.agentic.integrations.langchain import (
        log_langchain_steps,
    )

    with AgentTrace(task_description="...") as t:
        result = agent.invoke({"messages": [HumanMessage(content=query)]})
        log_langchain_steps(t, result["messages"], user_input=query)
        t.set_outcome("success")

Multi-agent variant (safe for single-agent too — falls back automatically):
    from responsible_ai_platform.agentic.integrations.langchain import (
        log_langchain_steps_per_agent,
    )
"""

from ._messages import log_steps as log_langchain_steps
from ._messages import log_steps_per_agent as log_langchain_steps_per_agent

__all__ = ["log_langchain_steps", "log_langchain_steps_per_agent"]
