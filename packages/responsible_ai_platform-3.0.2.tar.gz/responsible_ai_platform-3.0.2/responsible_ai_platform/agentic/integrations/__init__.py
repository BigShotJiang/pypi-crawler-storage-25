"""responsible_ai_platform.agentic integrations for popular agent frameworks.

Auto-captures steps from framework execution — no manual log_step() needed.

Supported frameworks (one implementation, framework-named aliases for each):
- LangChain (`AgentExecutor`, `create_react_agent`, etc.) -> log_langchain_steps
- LangGraph (single-node + supervisor / swarm)            -> log_langgraph_steps
- LangChain-AWS (Bedrock-backed chains; same Message types)-> log_langchain_aws_steps
- Custom code that emits LangChain-style messages          -> any of the above

All the *_steps helpers are identical functions — the per-framework names
exist only so you can import the one that matches your stack. Each has a
``*_per_agent`` variant for multi-agent (per-node) metrics.

Usage (single-agent — works for all frameworks above):
    from responsible_ai_platform.agentic import AgentTrace
    from responsible_ai_platform.agentic.integrations import log_langgraph_steps

    with AgentTrace(...) as trace:
        result = agent.invoke({"messages": [HumanMessage(content=query)]})
        log_langgraph_steps(trace, result["messages"])
        trace.set_outcome("success")

Usage (multi-agent LangGraph supervisor / swarm — one entry per node):
    from responsible_ai_platform.agentic.integrations import log_langgraph_steps_per_agent
    log_langgraph_steps_per_agent(trace, result["messages"])
"""

# Each framework has its own module (langchain / langgraph / langchain_aws),
# all thin façades over the shared extractor in `_messages.py`. Import the name
# that matches your stack — they are functionally identical (no per-framework
# difference; all consume the same LangChain Message objects).
from .langchain import log_langchain_steps, log_langchain_steps_per_agent
from .langchain_aws import (
    log_langchain_aws_steps,
    log_langchain_aws_steps_per_agent,
)
from .langgraph import log_langgraph_steps, log_langgraph_steps_per_agent

__all__ = [
    "log_langgraph_steps",
    "log_langgraph_steps_per_agent",
    "log_langchain_steps",
    "log_langchain_steps_per_agent",
    "log_langchain_aws_steps",
    "log_langchain_aws_steps_per_agent",
]
