"""RAIA SDK integration for LangGraph agents (single-node + supervisor/swarm).

Thin façade over the shared message-extraction implementation in
``_messages.py``. LangChain, LangGraph and LangChain-AWS all emit the same
LangChain ``Message`` objects, so the logic is shared; this module just
exposes it under LangGraph-named entry points.

Usage:
    from responsible_ai_platform.agentic import AgentTrace
    from responsible_ai_platform.agentic.integrations.langgraph import (
        log_langgraph_steps,
    )

    with AgentTrace(task_description="...") as t:
        result = agent.invoke({"messages": [HumanMessage(content=query)]})
        log_langgraph_steps(t, result["messages"], user_input=query)
        t.set_outcome("success")

Multi-agent (one entry per LangGraph node):
    from responsible_ai_platform.agentic.integrations.langgraph import (
        log_langgraph_steps_per_agent,
    )
"""

from ._messages import log_steps as log_langgraph_steps
from ._messages import log_steps_per_agent as log_langgraph_steps_per_agent

__all__ = ["log_langgraph_steps", "log_langgraph_steps_per_agent"]
