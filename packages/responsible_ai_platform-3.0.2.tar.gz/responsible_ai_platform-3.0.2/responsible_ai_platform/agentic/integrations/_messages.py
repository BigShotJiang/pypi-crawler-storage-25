"""Shared message-extraction implementation for the LangChain-family agents.

LangChain, LangGraph and LangChain-AWS (Bedrock) all emit the same LangChain
``Message`` objects (``AIMessage`` / ``ToolMessage`` / ``HumanMessage`` / ...),
so the extraction logic is identical across them and lives here once. The
per-framework modules (``langchain.py``, ``langgraph.py``, ``langchain_aws.py``)
re-export these two functions under framework-named aliases — they are the
public entry points; this module is private (note the leading underscore).

Auto-extracts tool calls, results, tokens, input/output, and (for multi-agent
LangGraph supervisor/swarm graphs) the originating node name per tool call.

Do not import from this module directly — use one of:
    from responsible_ai_platform.agentic.integrations import log_langchain_steps
    from responsible_ai_platform.agentic.integrations import log_langgraph_steps
    from responsible_ai_platform.agentic.integrations import log_langchain_aws_steps
"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger("responsible_ai_platform.agentic.integrations")


def log_steps(
    trace,
    messages: list,
    user_input: str = None,
    start_time: datetime = None,
    end_time: datetime = None,
    agent_name: str = None,
):
    """Extract data from LangGraph messages and log as a single interaction entry.

    Automatically extracts: input, output, tool_calls, tool_results,
    token usage, thinking steps — everything the RAIA evaluation service needs.

    Each tool call is enriched with ``invoked_by_agent_name`` (taken from the
    LangGraph node that emitted the AI message that requested it). For
    single-agent LangChain/LangGraph runs this collapses to the orchestrator.

    Args:
        trace: Active AgentTrace instance (or None — safely no-ops).
        messages: List of LangChain/LangGraph message objects from agent.invoke().
        user_input: The original user query (auto-detected from messages if omitted).
        start_time: When the agent invocation started (defaults to now).
        end_time: When the agent invocation ended (defaults to now).
        agent_name: Override the entry's agent_name. Defaults to the
            orchestrator (or the dominant LangGraph node if a single node
            emitted everything).
    """
    if trace is None:
        return

    now = datetime.now(timezone.utc)
    _start = start_time or now
    _end = end_time or now

    # Extract all components from messages
    _input = user_input or _extract_user_input(messages)
    _output = _extract_final_output(messages)
    _tool_calls, _tool_results, _thinking = _extract_tool_data(messages)
    _tokens = _extract_token_usage(messages)

    # Detect errors
    has_error = any(
        getattr(msg, "status", None) == "error"
        for msg in messages
        if _is_tool_message(msg)
    )

    # Extract system prompt if present
    _system_prompt = _extract_system_prompt(messages)

    # If every tool call came from one node, tag the entry with that node;
    # otherwise leave it as the orchestrator (None → SDK default).
    invoking_agents = {
        tc.get("invoked_by_agent_name") for tc in _tool_calls
        if tc.get("invoked_by_agent_name")
    }
    resolved_entry_agent = agent_name or (
        next(iter(invoking_agents)) if len(invoking_agents) == 1 else None
    )

    trace.log_interaction(
        input_text=_input,
        output_text=_output,
        start_time=_start,
        end_time=_end,
        model=_extract_model(messages),
        prompt_tokens=_tokens["prompt_tokens"],
        completion_tokens=_tokens["completion_tokens"],
        total_tokens=_tokens["total_tokens"],
        success=not has_error,
        error_type=None,
        error_message=None,
        tool_calls=_tool_calls,
        tool_results=_tool_results,
        agent_thinking=_thinking,
        num_steps=len(_thinking) if _thinking else len(_tool_calls),
        system_prompt=_system_prompt,
        agent_name=resolved_entry_agent,
    )


def log_steps_per_agent(
    trace,
    messages: list,
    user_input: str = None,
    start_time: datetime = None,
    end_time: datetime = None,
):
    """Multi-agent variant: emit one entry per LangGraph node that participated.

    Use this for supervisor / swarm graphs where you want per-sub-agent
    operational + quality metrics in RAIA. Each AI message is grouped with
    its paired tool results and logged as its own ``log_interaction()``
    tagged with the node name as ``agent_name``.

    For single-node graphs this behaves like ``log_steps``.
    """
    if trace is None:
        return

    now = datetime.now(timezone.utc)
    _start = start_time or now
    _end = end_time or now
    _input = user_input or _extract_user_input(messages)
    _system_prompt = _extract_system_prompt(messages)

    groups = _group_messages_by_agent(messages)

    if not groups:
        # Fall back to the aggregated path so callers always get an entry.
        return log_steps(
            trace, messages, user_input=user_input,
            start_time=start_time, end_time=end_time,
        )

    final_output = _extract_final_output(messages)
    last_idx = len(groups) - 1

    for idx, group in enumerate(groups):
        is_final = idx == last_idx
        node_name = group["agent_name"]
        tokens = group["tokens"]
        tool_calls = group["tool_calls"]
        tool_results = group["tool_results"]
        thinking = group["thinking"]
        # Only the final node's output represents the user-visible answer.
        output_text = final_output if is_final else (group["output"] or "")

        trace.log_interaction(
            input_text=_input,
            output_text=output_text,
            start_time=_start,
            end_time=_end,
            model=group["model"] or _extract_model(messages),
            prompt_tokens=tokens["prompt_tokens"],
            completion_tokens=tokens["completion_tokens"],
            total_tokens=tokens["total_tokens"],
            success=not group["has_error"],
            tool_calls=tool_calls,
            tool_results=tool_results,
            agent_thinking=thinking,
            num_steps=len(thinking) if thinking else len(tool_calls),
            system_prompt=_system_prompt,
            agent_name=node_name,
            step_index=idx,
        )


def _extract_user_input(messages: list) -> str:
    """Find the first HumanMessage content."""
    for msg in messages:
        if type(msg).__name__ == "HumanMessage":
            content = getattr(msg, "content", "")
            return content if isinstance(content, str) else str(content)
    return ""


def _extract_final_output(messages: list) -> str:
    """Find the last AIMessage content (final response)."""
    for msg in reversed(messages):
        if _is_ai_message(msg):
            content = getattr(msg, "content", "")
            if content:
                return content if isinstance(content, str) else str(content)
    return ""


def _extract_node_name(msg) -> str:
    """Best-effort: pull the LangGraph node name (a.k.a. sub-agent) off a message.

    LangGraph supervisor/swarm patterns put the node name in one of:
    - ``msg.name`` (set by `Command(goto=..., update={"messages": [AIMessage(name=...)]})`)
    - ``msg.response_metadata["langgraph_node"]``
    - ``msg.additional_kwargs["langgraph_node"]`` (older versions)
    Returns None for plain LangChain agents (single-agent, no node tagging).
    """
    name = getattr(msg, "name", None)
    if name:
        return str(name)
    meta = getattr(msg, "response_metadata", None) or {}
    if isinstance(meta, dict):
        node = meta.get("langgraph_node") or meta.get("node")
        if node:
            return str(node)
    extra = getattr(msg, "additional_kwargs", None) or {}
    if isinstance(extra, dict):
        node = extra.get("langgraph_node") or extra.get("node")
        if node:
            return str(node)
    return None


def _extract_tool_data(messages: list):
    """Extract tool_calls, tool_results, and thinking steps from messages.

    Tool calls are tagged with ``invoked_by_agent_name`` derived from the
    originating LangGraph node when available.

    Returns:
        Tuple of (tool_calls, tool_results, thinking_steps)
    """
    # Build a map of tool_call_id -> ToolMessage for result pairing
    tool_result_map = {}
    for msg in messages:
        if _is_tool_message(msg):
            call_id = getattr(msg, "tool_call_id", None)
            if call_id:
                tool_result_map[call_id] = msg

    tool_calls = []
    tool_results = []
    thinking_steps = []
    step_num = 0

    for msg in messages:
        if not _is_ai_message(msg):
            continue

        step_num += 1
        content = getattr(msg, "content", "")
        thought = content if isinstance(content, str) else str(content)
        invoking_agent = _extract_node_name(msg)

        msg_tool_calls = getattr(msg, "tool_calls", None)
        if msg_tool_calls:
            for tc in msg_tool_calls:
                tool_name = tc.get("name", "unknown_tool")
                tool_args = tc.get("args", {})
                call_id = tc.get("id")

                tool_call_entry = {
                    "name": tool_name,
                    "arguments": _safe_args(tool_args),
                }
                if invoking_agent:
                    tool_call_entry["invoked_by_agent_name"] = invoking_agent
                tool_calls.append(tool_call_entry)

                thinking_steps.append({
                    "step": step_num,
                    "thought": thought[:200] if thought else f"Calling tool: {tool_name}",
                    "action": tool_name,
                    "agent_name": invoking_agent,
                })

                # Find paired result
                result_msg = tool_result_map.get(call_id)
                if result_msg:
                    result_content = getattr(result_msg, "content", "")
                    result_str = result_content if isinstance(result_content, str) else str(result_content)
                    tool_results.append({
                        "name": getattr(result_msg, "name", tool_name),
                        "result": result_str[:500],
                    })
        else:
            # Final answer step (no tool calls)
            if thought:
                thinking_steps.append({
                    "step": step_num,
                    "thought": thought[:200],
                    "action": "final_answer",
                    "agent_name": invoking_agent,
                })

    return tool_calls, tool_results, thinking_steps


def _group_messages_by_agent(messages: list):
    """Group AI messages (and their paired tool results) by the originating
    LangGraph node. Each group becomes one log_interaction call.

    Returns a list of dicts with: agent_name, tool_calls, tool_results,
    thinking, tokens, output, model, has_error.
    Returns an empty list if no LangGraph node names are present anywhere
    (i.e. plain single-agent LangChain run — caller should fall back).
    """
    # Pair tool messages by call id once
    tool_result_map = {}
    for msg in messages:
        if _is_tool_message(msg):
            call_id = getattr(msg, "tool_call_id", None)
            if call_id:
                tool_result_map[call_id] = msg

    any_node_tagged = any(
        _extract_node_name(m) for m in messages if _is_ai_message(m)
    )
    if not any_node_tagged:
        return []

    groups_by_agent = {}
    order = []
    step_num = 0

    for msg in messages:
        if not _is_ai_message(msg):
            continue
        step_num += 1
        node = _extract_node_name(msg) or "orchestrator"
        if node not in groups_by_agent:
            order.append(node)
            groups_by_agent[node] = {
                "agent_name": node,
                "tool_calls": [],
                "tool_results": [],
                "thinking": [],
                "tokens": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
                "output": "",
                "model": None,
                "has_error": False,
            }
        g = groups_by_agent[node]

        content = getattr(msg, "content", "")
        thought = content if isinstance(content, str) else str(content)
        if thought:
            g["output"] = thought  # last AI message content from this node wins

        # Token usage
        usage = getattr(msg, "usage_metadata", None)
        if usage and isinstance(usage, dict):
            g["tokens"]["prompt_tokens"] += usage.get("input_tokens", 0)
            g["tokens"]["completion_tokens"] += usage.get("output_tokens", 0)
            g["tokens"]["total_tokens"] = (
                g["tokens"]["prompt_tokens"] + g["tokens"]["completion_tokens"]
            )

        # Model
        meta = getattr(msg, "response_metadata", {}) or {}
        if isinstance(meta, dict) and not g["model"]:
            g["model"] = meta.get("model") or meta.get("model_id") or meta.get("model_name")

        msg_tool_calls = getattr(msg, "tool_calls", None) or []
        for tc in msg_tool_calls:
            tool_name = tc.get("name", "unknown_tool")
            tool_args = tc.get("args", {})
            call_id = tc.get("id")
            g["tool_calls"].append({
                "name": tool_name,
                "arguments": _safe_args(tool_args),
                "invoked_by_agent_name": node,
            })
            g["thinking"].append({
                "step": step_num,
                "thought": thought[:200] if thought else f"Calling tool: {tool_name}",
                "action": tool_name,
                "agent_name": node,
            })
            result_msg = tool_result_map.get(call_id)
            if result_msg:
                result_content = getattr(result_msg, "content", "")
                result_str = result_content if isinstance(result_content, str) else str(result_content)
                if getattr(result_msg, "status", None) == "error":
                    g["has_error"] = True
                g["tool_results"].append({
                    "name": getattr(result_msg, "name", tool_name),
                    "result": result_str[:500],
                })
        if not msg_tool_calls and thought:
            g["thinking"].append({
                "step": step_num,
                "thought": thought[:200],
                "action": "final_answer",
                "agent_name": node,
            })

    return [groups_by_agent[n] for n in order]


def _extract_system_prompt(messages: list) -> str:
    """Find SystemMessage content if present."""
    for msg in messages:
        if type(msg).__name__ == "SystemMessage":
            content = getattr(msg, "content", "")
            return content if isinstance(content, str) else str(content)
    return None


def _extract_model(messages: list) -> str:
    """Try to extract model name from AI message metadata."""
    for msg in messages:
        if _is_ai_message(msg):
            # Some frameworks store model info in response_metadata
            meta = getattr(msg, "response_metadata", {})
            if isinstance(meta, dict):
                model = meta.get("model", meta.get("model_id", meta.get("model_name", "")))
                if model:
                    return str(model)
    return None


def _extract_token_usage(messages: list) -> dict:
    """Sum token usage from all AI messages."""
    prompt_tokens = 0
    completion_tokens = 0

    for msg in messages:
        if _is_ai_message(msg):
            usage = getattr(msg, "usage_metadata", None)
            if usage and isinstance(usage, dict):
                prompt_tokens += usage.get("input_tokens", 0)
                completion_tokens += usage.get("output_tokens", 0)

    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
    }


def _is_ai_message(msg) -> bool:
    return type(msg).__name__ == "AIMessage"


def _is_tool_message(msg) -> bool:
    return type(msg).__name__ == "ToolMessage"


def _safe_args(args: dict, max_value_len: int = 500) -> dict:
    safe = {}
    for k, v in args.items():
        s = str(v)
        safe[k] = s[:max_value_len] + "..." if len(s) > max_value_len else s
    return safe
