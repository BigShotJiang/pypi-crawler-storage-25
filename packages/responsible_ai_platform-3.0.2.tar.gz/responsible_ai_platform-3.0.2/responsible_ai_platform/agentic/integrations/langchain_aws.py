"""RAIA SDK integration for LangChain-AWS (Amazon Bedrock-backed) agents,
e.g. ``ChatBedrock`` / ``ChatBedrockConverse``.

Thin façade over the shared message-extraction implementation in
``_messages.py``. Bedrock chat models return the same LangChain ``Message``
objects as LangChain / LangGraph, so the logic is shared; this module just
exposes it under LangChain-AWS-named entry points.

Note: with Bedrock the model identifier usually arrives as ``model_id`` in
``response_metadata`` (handled by the extractor) rather than ``model``.

Usage:
    from responsible_ai_platform.agentic import AgentTrace
    from responsible_ai_platform.agentic.integrations.langchain_aws import (
        log_langchain_aws_steps,
    )

    with AgentTrace(task_description="...") as t:
        result = agent.invoke({"messages": [HumanMessage(content=query)]})
        log_langchain_aws_steps(t, result["messages"], user_input=query)
        t.set_outcome("success")

Multi-agent variant (safe for single-agent too — falls back automatically):
    from responsible_ai_platform.agentic.integrations.langchain_aws import (
        log_langchain_aws_steps_per_agent,
    )
"""

from ._messages import log_steps as log_langchain_aws_steps
from ._messages import log_steps_per_agent as log_langchain_aws_steps_per_agent

__all__ = ["log_langchain_aws_steps", "log_langchain_aws_steps_per_agent"]
