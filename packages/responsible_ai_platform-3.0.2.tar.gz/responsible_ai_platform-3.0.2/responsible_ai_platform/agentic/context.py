"""Thread-safe current trace + current agent tracking using contextvars.

This allows @tool decorators to find the active trace automatically,
regardless of framework (LangGraph, LangChain, CrewAI, custom).

`_current_agent` lets `@trace_subagent` push a sub-agent identity onto the
context so subsequent `@tool` invocations are stamped with the right agent.
"""

from contextvars import ContextVar

# The currently active AgentTrace for this execution context
_current_trace: ContextVar = ContextVar("raia_current_trace", default=None)

# The currently active sub-agent name within the trace (None == orchestrator)
_current_agent: ContextVar = ContextVar("raia_current_agent", default=None)


def get_current_trace():
    """Get the active trace for this context. Returns None if no trace is active."""
    return _current_trace.get()


def set_current_trace(trace):
    """Set the active trace for this context."""
    return _current_trace.set(trace)


def get_current_agent():
    """Get the active sub-agent name. Returns None if no sub-agent is active."""
    return _current_agent.get()


def set_current_agent(agent_name):
    """Set the active sub-agent name. Returns the token for restoration."""
    return _current_agent.set(agent_name)


def reset_current_agent(token):
    """Restore the previous sub-agent context using the token from set_current_agent."""
    _current_agent.reset(token)
