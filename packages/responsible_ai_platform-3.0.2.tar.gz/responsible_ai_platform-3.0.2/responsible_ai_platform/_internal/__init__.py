"""Internal plumbing shared across all raia.* domains.

Not part of the public API — use `raia.agentic`, `raia.ml`, `raia.rag`, etc.
"""
