"""RAIA SDK Configuration - reads from environment variables."""

import os

from dotenv import load_dotenv

API_KEY_PREFIX = "raia_"


class RaiaConfig:
    """Holds all SDK configuration. Loaded from .env or passed explicitly.

    Only two variables are read from the environment:
        RAIA_API_KEY      — API key from the RAIA UI
        RAIA_API_BASE_URL — RAIA backend URL

    All other per-asset settings (app_id, agent_version, model_version,
    environment, topology, …) are passed in code via
    ``AgentTrace.configure(...)`` / ``AgentTrace(...)``.
    """

    def __init__(self):
        load_dotenv()

        self.api_key = os.getenv("RAIA_API_KEY", "")
        self.api_base_url = os.getenv("RAIA_API_BASE_URL", "http://localhost:8000")

    def validate(self):
        """Check that required fields are set and the API key has the expected shape."""
        missing = []
        if not self.api_key:
            missing.append("RAIA_API_KEY")
        if not self.api_base_url:
            missing.append("RAIA_API_BASE_URL")
        if missing:
            raise ValueError(f"Missing required RAIA config: {', '.join(missing)}")

        if not self.api_key.startswith(API_KEY_PREFIX):
            raise ValueError(
                f"RAIA_API_KEY must start with '{API_KEY_PREFIX}'. "
                "Generate a new key from the RAIA UI."
            )


# Singleton instance
_config = None


def get_config() -> RaiaConfig:
    global _config
    if _config is None:
        _config = RaiaConfig()
    return _config


def reset_config():
    """Reset config (useful for testing)."""
    global _config
    _config = None
