"""RAIA SDK Authentication — API key only.

Legacy email/password login has been removed. The SDK now requires a RAIA API
key (`raia_...`) set via `RAIA_API_KEY`, which is passed as a Bearer token on
every outgoing request.
"""

import logging

from .config import get_config

logger = logging.getLogger("responsible_ai_platform.auth")


class RaiaAuth:
    """Passes the configured API key as a Bearer token. Stateless."""

    @property
    def token(self) -> str:
        config = get_config()
        config.validate()
        return config.api_key

    @property
    def headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token}"}

    def ensure_authenticated(self):
        """Validate config up front so callers get a clear error before the first request."""
        get_config().validate()


# Singleton
_auth = None


def get_auth() -> RaiaAuth:
    global _auth
    if _auth is None:
        _auth = RaiaAuth()
    return _auth


def reset_auth():
    global _auth
    _auth = None
