"""RAIA SDK Uploader - uploads trace JSON files to RAIA."""

import atexit
import io
import json
import logging
import queue
import threading
import time
import uuid
from datetime import datetime, timezone

import requests

from .auth import get_auth
from .config import get_config

logger = logging.getLogger("responsible_ai_platform.uploader")

# Upload caps
MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50 MB
MAX_PENDING_UPLOADS = 100  # bounded queue depth
_UPLOAD_WORKER_COUNT = 4

# ---------------------------------------------------------------------------
# Bounded background upload queue
# ---------------------------------------------------------------------------

_upload_queue: "queue.Queue[object]" = queue.Queue(maxsize=MAX_PENDING_UPLOADS)
_shutdown = threading.Event()
_workers_started = False
_workers_lock = threading.Lock()


def _worker_loop() -> None:
    """Pull trace payloads off the queue and upload synchronously."""
    while not _shutdown.is_set():
        try:
            item = _upload_queue.get(timeout=0.5)
        except queue.Empty:
            continue
        if item is None:  # shutdown sentinel
            _upload_queue.task_done()
            return
        try:
            upload_trace(item)
        except Exception as exc:  # noqa: BLE001 — worker must never die
            logger.exception("Background upload worker crashed: %s", exc)
        finally:
            _upload_queue.task_done()


def _ensure_workers_started() -> None:
    global _workers_started
    if _workers_started:
        return
    with _workers_lock:
        if _workers_started:
            return
        for i in range(_UPLOAD_WORKER_COUNT):
            t = threading.Thread(target=_worker_loop, name=f"raia-upload-{i}", daemon=False)
            t.start()
        _workers_started = True


def _drain_and_stop(timeout: float = 30.0) -> None:
    """Signal workers to exit after the queue drains."""
    _shutdown.set()
    for _ in range(_UPLOAD_WORKER_COUNT):
        try:
            _upload_queue.put_nowait(None)
        except queue.Full:
            # Queue is full of real items; workers will drain and see _shutdown
            pass
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline and not _upload_queue.empty():
        time.sleep(0.05)


atexit.register(_drain_and_stop)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _generate_filename() -> str:
    """Generate a unique filename: {timestamp}_{14-char uuid}.json"""
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    short_id = str(uuid.uuid4()).replace("-", "")[:14]
    return f"{ts}_{short_id}.json"


def _serialize(trace_data) -> bytes:
    return json.dumps(trace_data, indent=2, default=str).encode("utf-8")


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------


def upload_trace(trace_data):
    """Upload a trace JSON to RAIA API.

    Args:
        trace_data: dict (single trace) or list (array of entries).

    Uses API key auth with /agentic/upload-trace-files endpoint. On failure
    the trace is dropped with a warning log — there is no local retry or
    on-disk fallback. Refuses payloads larger than MAX_UPLOAD_BYTES.
    """
    config = get_config()
    auth = get_auth()
    filename = _generate_filename()

    trace_bytes = _serialize(trace_data)

    if len(trace_bytes) > MAX_UPLOAD_BYTES:
        logger.error(
            "Trace %s exceeds max upload size (%d > %d bytes); refusing to upload",
            filename,
            len(trace_bytes),
            MAX_UPLOAD_BYTES,
        )
        return None

    try:
        auth.ensure_authenticated()

        upload_url = f"{config.api_base_url}/agentic/upload-trace-files"
        logger.info("Uploading %s to %s", filename, upload_url)
        response = requests.post(
            upload_url,
            headers=auth.headers,
            files={"file": (filename, io.BytesIO(trace_bytes), "application/json")},
            timeout=60,
            verify=True,
        )
        response.raise_for_status()

        result = response.json()
        logger.info("Trace %s uploaded successfully: %s", filename, result)
        return result

    except requests.exceptions.RequestException as exc:
        logger.warning("Upload failed for %s: %s. Trace dropped.", filename, exc)
        return None


def upload_trace_async(trace_data):
    """Enqueue an upload on the bounded background worker pool (non-blocking).

    If the queue is full (MAX_PENDING_UPLOADS pending uploads), the payload
    is dropped with a warning.
    """
    _ensure_workers_started()
    try:
        _upload_queue.put_nowait(trace_data)
    except queue.Full:
        logger.warning(
            "Upload queue full (%d pending); dropping trace",
            MAX_PENDING_UPLOADS,
        )
