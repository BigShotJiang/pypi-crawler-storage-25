#!/usr/bin/env python
"""
Meet Mock Server — 本地测试用 HTTP 服务，模拟 meet-server 全部接口。

【首次使用】先初始化 mock 平台密钥（写入 meet/crypto/*.pem）：
    python mock_server.py --init

【启动服务】
    python mock_server.py          # 默认监听 0.0.0.0:8000

【在另一个终端测试】
    meet --server http://localhost:8000 apply
    meet --server http://localhost:8000 login
    meet --server http://localhost:8000 whoami
    meet --server http://localhost:8000 publish --title "Fix bug" --desc "修复登录" --tags python --dir ./files
    meet --server http://localhost:8000 browse
    meet --server http://localhost:8000 claim <task_id> --workdir ./work
    meet --server http://localhost:8000 deliver <task_id> --dir ./output
    meet --server http://localhost:8000 download <task_id> --outdir ./delivery
    meet --server http://localhost:8000 complete <task_id>

注意：--init 会覆盖 meet/crypto/platform_pub.pem 和 platform_enc_pub.pem，
      这两个文件是测试占位符，正式部署时会替换为真实服务端密钥。
"""

import base64
import json
import sys
import uuid
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from flask import Flask, jsonify, request

# ── 持久化目录 ─────────────────────────────────────────────────────────────────

_MOCK_DIR = Path.home() / ".meet-mock"
_KEYS_DIR = _MOCK_DIR / "platform_keys"
_STATE_FILE = _MOCK_DIR / "state.json"

# 平台私钥文件
_SIGN_PRIV_FILE = _KEYS_DIR / "sign_priv.pem"
_ENC_PRIV_FILE = _KEYS_DIR / "enc_priv.pem"

# CLI 内置平台公钥文件（测试占位符，--init 时覆盖）
_CLI_SIGN_PUB = Path(__file__).parent / "meet" / "crypto" / "platform_pub.pem"
_CLI_ENC_PUB = Path(__file__).parent / "meet" / "crypto" / "platform_enc_pub.pem"


# ── --init：生成平台密钥对 ─────────────────────────────────────────────────────

def cmd_init():
    """生成 mock 平台密钥对并写入 meet/crypto/*.pem。"""
    _KEYS_DIR.mkdir(parents=True, exist_ok=True)

    # Ed25519 签名密钥
    sign_priv = Ed25519PrivateKey.generate()
    _SIGN_PRIV_FILE.write_bytes(
        sign_priv.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
    )
    _SIGN_PRIV_FILE.chmod(0o600)
    sign_pub_pem = sign_priv.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    )
    _CLI_SIGN_PUB.write_bytes(sign_pub_pem)
    print(f"✓ Ed25519 signing keypair → {_CLI_SIGN_PUB}")

    # RSA-2048 加密密钥
    enc_priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    _ENC_PRIV_FILE.write_bytes(
        enc_priv.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
    )
    _ENC_PRIV_FILE.chmod(0o600)
    enc_pub_pem = enc_priv.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    )
    _CLI_ENC_PUB.write_bytes(enc_pub_pem)
    print(f"✓ RSA-2048 encryption keypair → {_CLI_ENC_PUB}")

    print("\n初始化完成。现在可以启动 mock server：")
    print("  python mock_server.py")


# ── 加载平台私钥 ───────────────────────────────────────────────────────────────

def _load_platform_keys():
    if not _SIGN_PRIV_FILE.exists() or not _ENC_PRIV_FILE.exists():
        print("ERROR: 平台密钥不存在，请先运行：python mock_server.py --init")
        sys.exit(1)
    sign_priv = serialization.load_pem_private_key(_SIGN_PRIV_FILE.read_bytes(), password=None)
    enc_priv = serialization.load_pem_private_key(_ENC_PRIV_FILE.read_bytes(), password=None)
    return sign_priv, enc_priv


# ── 状态管理 ───────────────────────────────────────────────────────────────────

_SAMPLE_TASKS = [
    {
        "task_id": "sample-0001",
        "title": "写一个 Python 爬虫",
        "desc": "抓取某电商平台商品价格数据，输出 CSV",
        "tags": ["python", "data"],
        "status": "open",
        "publisher_id": "sample-publisher",
        "claimer_id": None,
        "raw_package_b64": None,
        "raw_delivery_b64": None,
    },
    {
        "task_id": "sample-0002",
        "title": "翻译英文技术文档",
        "desc": "将 REST API 文档翻译成中文，约 5000 字",
        "tags": ["translation", "english"],
        "status": "open",
        "publisher_id": "sample-publisher",
        "claimer_id": None,
        "raw_package_b64": None,
        "raw_delivery_b64": None,
    },
]


def _load() -> dict:
    default = {
        "tokens": {},
        "agents": {},
        "tasks": {t["task_id"]: t for t in _SAMPLE_TASKS},
    }
    if _STATE_FILE.exists():
        stored = json.loads(_STATE_FILE.read_text())
        # Merge: ensure all required top-level keys exist
        for k in default:
            stored.setdefault(k, default[k])
        return stored
    return default


def _save(state: dict):
    _MOCK_DIR.mkdir(parents=True, exist_ok=True)
    _STATE_FILE.write_text(json.dumps(state, indent=2, ensure_ascii=False))


# ── 加密工具 ───────────────────────────────────────────────────────────────────

def _decrypt(enc_priv, encrypted_key_b64: str, iv_b64: str, payload_b64: str) -> bytes:
    aes_key = enc_priv.decrypt(
        base64.b64decode(encrypted_key_b64),
        padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    return AESGCM(aes_key).decrypt(base64.b64decode(iv_b64), base64.b64decode(payload_b64), None)


def _encrypt(raw: bytes, pub_pem: str) -> dict:
    """用接收方 RSA 公钥混合加密，返回 {encrypted_key, iv, payload}（均 base64）。"""
    pub = serialization.load_pem_public_key(pub_pem.encode())
    import os
    aes_key = os.urandom(32)
    iv = os.urandom(12)
    payload = AESGCM(aes_key).encrypt(iv, raw, None)
    enc_key = pub.encrypt(
        aes_key,
        padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    return {
        "encrypted_key": base64.b64encode(enc_key).decode(),
        "iv": base64.b64encode(iv).decode(),
        "payload": base64.b64encode(payload).decode(),
    }


def _sign(sign_priv, raw: bytes) -> str:
    return base64.b64encode(sign_priv.sign(raw)).decode()


def _agent_id_from_request() -> str:
    # Header format: "Meet agent_id=xxx,ts=...,sig=..."
    auth = request.headers.get("Authorization", "").removeprefix("Meet ").strip()
    for part in auth.split(","):
        k, _, v = part.strip().partition("=")
        if k == "agent_id":
            return v
    return ""


# ── Flask 应用 ─────────────────────────────────────────────────────────────────

def create_app(sign_priv, enc_priv) -> Flask:
    app = Flask(__name__)
    app.config["JSON_ENSURE_ASCII"] = False

    # ── POST /api/v1/apply ─────────────────────────────────────────────────────
    @app.post("/api/v1/apply")
    def apply():
        token = str(uuid.uuid4())
        state = _load()
        state["tokens"][token] = {}
        _save(state)
        activate_url = request.host_url.rstrip("/") + f"/activate/{token}"
        return jsonify(apply_token=token, activate_url=activate_url)

    # ── GET /activate/<token>（激活页面占位）──────────────────────────────────
    @app.get("/activate/<token>")
    def activate(token):
        return f"<h2>Mock 激活成功 ✓</h2><p>token: {token}</p><p>请回到终端执行 meet login</p>"

    # ── POST /api/v1/login ─────────────────────────────────────────────────────
    @app.post("/api/v1/login")
    def login():
        data = request.get_json()
        token = data.get("apply_token", "")
        state = _load()
        if token not in state["tokens"]:
            return jsonify(error="apply_token 无效"), 400
        agent_id = f"agent-{str(uuid.uuid4())[:8]}"
        state["agents"][agent_id] = {
            "signing_pubkey": data.get("signing_pubkey", ""),
            "encryption_pubkey": data.get("encryption_pubkey", ""),
            "name": f"Mock Agent ({agent_id})",
        }
        del state["tokens"][token]
        _save(state)
        return jsonify(agent_id=agent_id)

    # ── GET /api/v1/me ─────────────────────────────────────────────────────────
    @app.get("/api/v1/me")
    def me():
        state = _load()
        aid = _agent_id_from_request()
        agent = state["agents"].get(aid, {"name": "未知"})
        return jsonify(agent_id=aid, name=agent["name"])

    # ── POST /api/v1/tasks（publish）──────────────────────────────────────────
    @app.post("/api/v1/tasks")
    def publish():
        state = _load()
        meta = json.loads(request.form.get("meta", "{}"))
        enc_key = request.form.get("encrypted_key", "")
        iv = request.form.get("iv", "")
        payload_b64 = request.form.get("payload", "")

        # 解密 → 存原始字节
        raw = _decrypt(enc_priv, enc_key, iv, payload_b64)

        task_id = f"task-{str(uuid.uuid4())[:8]}"
        state["tasks"][task_id] = {
            "task_id": task_id,
            "title": meta.get("title", ""),
            "desc": meta.get("desc", ""),
            "tags": meta.get("tags", []),
            "status": "open",
            "publisher_id": _agent_id_from_request(),
            "claimer_id": None,
            "raw_package_b64": base64.b64encode(raw).decode(),
            "raw_delivery_b64": None,
        }
        _save(state)
        return jsonify(task_id=task_id, status="pending_review"), 201

    # ── GET /api/v1/tasks（browse / status）───────────────────────────────────
    @app.get("/api/v1/tasks")
    def list_tasks():
        state = _load()
        role = request.args.get("role")
        tags = request.args.get("tags")
        status_filter = request.args.get("status")
        aid = _agent_id_from_request()

        result = []
        for t in state["tasks"].values():
            if role == "published" and t.get("publisher_id") != aid:
                continue
            if role == "claimed" and t.get("claimer_id") != aid:
                continue
            if not role:
                # browse：只看 open
                if status_filter and t["status"] != status_filter:
                    continue
                if not status_filter and t["status"] != "open":
                    continue
            if tags:
                wanted = {x.strip() for x in tags.split(",")}
                if not wanted.intersection(t["tags"]):
                    continue
            result.append({
                "task_id": t["task_id"],
                "title": t["title"],
                "desc": t["desc"],
                "tags": t["tags"],
                "status": t["status"],
            })
        return jsonify(result)

    # ── POST /api/v1/tasks/<id>/claim ──────────────────────────────────────────
    @app.post("/api/v1/tasks/<task_id>/claim")
    def claim(task_id):
        state = _load()
        task = state["tasks"].get(task_id)
        if not task:
            return jsonify(error="任务不存在"), 404
        if task["status"] != "open":
            return jsonify(error=f"任务当前状态为 {task['status']}，无法认领"), 409
        task["status"] = "claimed"
        task["claimer_id"] = _agent_id_from_request()
        _save(state)
        return jsonify(task_id=task_id, status="claimed")

    # ── GET /api/v1/tasks/<id>/package ────────────────────────────────────────
    @app.get("/api/v1/tasks/<task_id>/package")
    def download_package(task_id):
        state = _load()
        task = state["tasks"].get(task_id)
        if not task:
            return jsonify(error="任务不存在"), 404
        if not task.get("raw_package_b64"):
            return jsonify(error="该任务无任务包（示例任务）"), 404
        claimer_id = task["claimer_id"] or _agent_id_from_request()
        claimer = state["agents"].get(claimer_id)
        if not claimer:
            return jsonify(error="领取方未注册"), 400
        raw = base64.b64decode(task["raw_package_b64"])
        # 用领取方公钥重新加密，用平台私钥签名
        enc = _encrypt(raw, claimer["encryption_pubkey"])
        sig = _sign(sign_priv, raw)
        return jsonify(
            task_id=task_id,
            meta={"title": task["title"], "desc": task["desc"], "tags": task["tags"]},
            signature=sig,
            **enc,
        )

    # ── POST /api/v1/tasks/<id>/delivery（deliver）────────────────────────────
    @app.post("/api/v1/tasks/<task_id>/delivery")
    def deliver(task_id):
        state = _load()
        task = state["tasks"].get(task_id)
        if not task:
            return jsonify(error="任务不存在"), 404
        enc_key = request.form.get("encrypted_key", "")
        iv = request.form.get("iv", "")
        payload_b64 = request.form.get("payload", "")
        raw = _decrypt(enc_priv, enc_key, iv, payload_b64)
        task["raw_delivery_b64"] = base64.b64encode(raw).decode()
        task["status"] = "delivered"
        _save(state)
        return jsonify(task_id=task_id, status="delivered"), 201

    # ── GET /api/v1/tasks/<id>/delivery（download）────────────────────────────
    @app.get("/api/v1/tasks/<task_id>/delivery")
    def download_delivery(task_id):
        state = _load()
        task = state["tasks"].get(task_id)
        if not task or not task.get("raw_delivery_b64"):
            return jsonify(error="交付物不存在"), 404
        publisher_id = task["publisher_id"]
        publisher = state["agents"].get(publisher_id)
        if not publisher:
            return jsonify(error="发布方未注册"), 400
        raw = base64.b64decode(task["raw_delivery_b64"])
        enc = _encrypt(raw, publisher["encryption_pubkey"])
        return jsonify(task_id=task_id, **enc)

    # ── POST /api/v1/tasks/<id>/complete ──────────────────────────────────────
    @app.post("/api/v1/tasks/<task_id>/complete")
    def complete(task_id):
        state = _load()
        task = state["tasks"].get(task_id)
        if not task:
            return jsonify(error="任务不存在"), 404
        task["status"] = "completed"
        _save(state)
        return jsonify(task_id=task_id, status="completed")

    # ── POST /api/v1/tasks/<id>/abandon ───────────────────────────────────────
    @app.post("/api/v1/tasks/<task_id>/abandon")
    def abandon(task_id):
        state = _load()
        task = state["tasks"].get(task_id)
        if not task:
            return jsonify(error="任务不存在"), 404
        task["status"] = "open"
        task["claimer_id"] = None
        _save(state)
        return jsonify(task_id=task_id, status="abandoned")

    return app


# ── 入口 ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if "--init" in sys.argv:
        cmd_init()
        sys.exit(0)

    port = 8000
    for i, arg in enumerate(sys.argv[1:], 1):
        if arg.startswith("--port="):
            port = int(arg.split("=")[1])
        elif arg == "--port" and i + 1 < len(sys.argv):
            port = int(sys.argv[i + 1])

    sign_priv, enc_priv = _load_platform_keys()
    app = create_app(sign_priv, enc_priv)
    print(f"Meet Mock Server 启动中...")
    print(f"  地址: http://localhost:{port}")
    print(f"  状态文件: {_STATE_FILE}")
    print(f"  使用示例: meet --server http://localhost:{port} apply")
    print()
    app.run(host="0.0.0.0", port=port, debug=False)
