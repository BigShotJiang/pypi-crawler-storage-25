# meet/api/client.py
import json
from typing import Optional

import httpx

_DEFAULT_TIMEOUT = 30.0

from meet.api.models import (
    ApplyResponse, LoginResponse, WhoamiResponse, TaskItem,
    PublishResponse, ClaimResponse, PackageResponse, DeliveryDownloadResponse,
)
from meet.crypto.keys import sign_request


class MeetApiError(Exception):
    pass


class AuthError(MeetApiError):
    pass


class NotFoundError(MeetApiError):
    pass


class ConflictError(MeetApiError):
    pass


class ApiClient:
    def __init__(self, server: str, agent_id: str = "", signing_private_key=None):
        self.server = server.rstrip("/")
        self._agent_id = agent_id
        self._signing_key = signing_private_key

    def _auth_header(self, method: str, path: str, body: bytes = b"") -> dict:
        if not self._signing_key:
            return {}
        ts, sig = sign_request(self._signing_key, method, path, body)
        return {"Authorization": f"Meet agent_id={self._agent_id},ts={ts},sig={sig}"}

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.status_code == 401:
            raise AuthError("未授权，请重新登录")
        if resp.status_code == 404:
            raise NotFoundError("资源不存在")
        if resp.status_code == 409:
            try:
                detail = resp.json().get("error", "conflict")
            except Exception:
                detail = "conflict"
            raise ConflictError(f"请求冲突：{detail}")
        resp.raise_for_status()

    @staticmethod
    def apply_static(server: str) -> ApplyResponse:
        resp = httpx.post(server.rstrip("/") + "/api/v1/apply", timeout=_DEFAULT_TIMEOUT)
        resp.raise_for_status()
        return ApplyResponse(**resp.json())

    def login(self, apply_token: str, signing_pubkey: str, encryption_pubkey: str) -> LoginResponse:
        path = "/api/v1/login"
        body = json.dumps({
            "apply_token": apply_token,
            "signing_pubkey": signing_pubkey,
            "encryption_pubkey": encryption_pubkey,
        }).encode()
        resp = httpx.post(self.server + path, content=body, headers={"Content-Type": "application/json"}, timeout=_DEFAULT_TIMEOUT)
        resp.raise_for_status()
        return LoginResponse(**resp.json())

    def whoami(self) -> WhoamiResponse:
        path = "/api/v1/me"
        resp = httpx.get(self.server + path, headers=self._auth_header("GET", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
        return WhoamiResponse(**resp.json())

    def publish(self, meta: dict, encrypted_key: str, iv: str, payload: str) -> PublishResponse:
        path = "/api/v1/tasks"
        files = {
            "meta": (None, json.dumps(meta), "application/json"),
            "encrypted_key": (None, encrypted_key),
            "iv": (None, iv),
            "payload": (None, payload),
        }
        resp = httpx.post(self.server + path, files=files, headers=self._auth_header("POST", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
        return PublishResponse(**resp.json())

    def browse(self, tags: Optional[str] = None, status: Optional[str] = None) -> list[TaskItem]:
        path = "/api/v1/tasks"
        params = {k: v for k, v in {"tags": tags, "status": status}.items() if v is not None}
        resp = httpx.get(self.server + path, params=params, headers=self._auth_header("GET", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
        return [TaskItem(**t) for t in resp.json()]

    def status(self, role: str) -> list[TaskItem]:
        path = "/api/v1/tasks"
        resp = httpx.get(self.server + path, params={"role": role}, headers=self._auth_header("GET", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
        return [TaskItem(**t) for t in resp.json()]

    def claim(self, task_id: str) -> ClaimResponse:
        path = f"/api/v1/tasks/{task_id}/claim"
        resp = httpx.post(self.server + path, headers=self._auth_header("POST", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
        return ClaimResponse(**resp.json())

    def download_package(self, task_id: str) -> PackageResponse:
        path = f"/api/v1/tasks/{task_id}/package"
        resp = httpx.get(self.server + path, headers=self._auth_header("GET", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
        return PackageResponse(**resp.json())

    def deliver(self, task_id: str, encrypted_key: str, iv: str, payload: str) -> None:
        path = f"/api/v1/tasks/{task_id}/delivery"
        files = {
            "encrypted_key": (None, encrypted_key),
            "iv": (None, iv),
            "payload": (None, payload),
        }
        resp = httpx.post(self.server + path, files=files, headers=self._auth_header("POST", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)

    def download_delivery(self, task_id: str) -> DeliveryDownloadResponse:
        path = f"/api/v1/tasks/{task_id}/delivery"
        resp = httpx.get(self.server + path, headers=self._auth_header("GET", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
        return DeliveryDownloadResponse(**resp.json())

    def complete(self, task_id: str) -> None:
        path = f"/api/v1/tasks/{task_id}/complete"
        resp = httpx.post(self.server + path, headers=self._auth_header("POST", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)

    def abandon(self, task_id: str) -> None:
        path = f"/api/v1/tasks/{task_id}/abandon"
        resp = httpx.post(self.server + path, headers=self._auth_header("POST", path), timeout=_DEFAULT_TIMEOUT)
        self._raise_for_status(resp)
