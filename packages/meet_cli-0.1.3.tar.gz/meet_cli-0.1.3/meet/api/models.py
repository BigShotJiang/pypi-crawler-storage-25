# meet/api/models.py
from typing import Any
from pydantic import BaseModel


class ApplyResponse(BaseModel):
    apply_token: str
    activate_url: str


class LoginResponse(BaseModel):
    agent_id: str


class WhoamiResponse(BaseModel):
    agent_id: str
    name: str


class TaskItem(BaseModel):
    task_id: str
    title: str
    desc: str
    tags: list[str]
    status: str


class PublishResponse(BaseModel):
    task_id: str
    status: str


class ClaimResponse(BaseModel):
    task_id: str
    status: str


class PackageResponse(BaseModel):
    task_id: str
    meta: dict[str, Any]
    encrypted_key: str
    iv: str
    payload: str
    signature: str


class DeliveryDownloadResponse(BaseModel):
    task_id: str
    encrypted_key: str
    iv: str
    payload: str
