# meet/cli/auth.py
import json as _json
import sys

import click
from cryptography.hazmat.primitives import serialization

import meet.config as _meet_config
from meet.config import Config
from meet.api.client import ApiClient
from meet.crypto.keys import (
    generate_signing_keypair, signing_key_to_pem,
    generate_encryption_keypair, encryption_key_to_pem,
    signing_key_from_pem,
)

DEFAULT_SERVER = "http://115.190.62.25"


def _out(data):
    """Output dict as JSON (--json flag) or key-value text."""
    ctx = click.get_current_context()
    as_json = ctx.obj.get("as_json", False) if ctx.obj else False
    if as_json:
        click.echo(_json.dumps(data, ensure_ascii=False))
    else:
        for k, v in data.items():
            click.echo(f"{k}: {v}")


@click.group()
def auth_group():
    pass


@auth_group.command("apply")
@click.option("--server", default=DEFAULT_SERVER, show_default=True)
def apply_cmd(server: str):
    """申请激活码，开始注册流程。"""
    try:
        resp = ApiClient.apply_static(server=server)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)
    Config(meet_dir=_meet_config.MEET_DIR).save_pending(resp.apply_token, server)
    ctx = click.get_current_context()
    if ctx.obj and ctx.obj.get("as_json"):
        _out({"activate_url": resp.activate_url, "next_step": "meet login"})
    else:
        click.echo("请点击链接完成激活：")
        click.echo(f"  {resp.activate_url}")
        click.echo("激活完成后，执行 meet login")


@auth_group.command("login")
def login_cmd():
    """完成密钥交换，写入本地凭证。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        pending = cfg.load_pending()
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    effective_server = pending["server"]
    signing_priv, _signing_pub_raw = generate_signing_keypair()
    signing_pub_pem = signing_priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode()
    enc_priv, enc_pub_pem = generate_encryption_keypair()

    try:
        resp = ApiClient(server=effective_server).login(
            apply_token=pending["apply_token"],
            signing_pubkey=signing_pub_pem,
            encryption_pubkey=enc_pub_pem,
        )
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    cfg.save_config(resp.agent_id, effective_server)
    cfg.save_signing_key(signing_key_to_pem(signing_priv))
    cfg.save_encryption_key(encryption_key_to_pem(enc_priv))
    cfg.delete_pending()

    _out({"agent_id": resp.agent_id, "status": "登录成功"})


@auth_group.command("whoami")
def whoami_cmd():
    """显示当前登录身份。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        config = cfg.load_config()
        signing_key = signing_key_from_pem(cfg.load_signing_key_pem())
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    client = ApiClient(
        server=config["server"],
        agent_id=config["agent_id"],
        signing_private_key=signing_key,
    )
    try:
        resp = client.whoami()
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    _out({"agent_id": resp.agent_id, "name": resp.name})
