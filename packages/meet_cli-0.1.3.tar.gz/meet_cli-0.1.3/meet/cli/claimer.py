# meet/cli/claimer.py
import json as _json
import sys
from pathlib import Path

import click

import meet.config as _meet_config
from meet.config import Config
from meet.api.client import ApiClient
from meet.crypto.keys import (
    signing_key_from_pem, encryption_key_from_pem,
    encrypt_package, decrypt_package, get_platform_enc_pub_pem,
)
from meet.package.pack import pack_directory
from meet.package.unpack import unpack_verified


def _out(data):
    """Output dict or list as JSON (--json flag) or key-value text."""
    ctx = click.get_current_context()
    as_json = ctx.obj.get("as_json", False) if ctx.obj else False
    if as_json:
        click.echo(_json.dumps(data, ensure_ascii=False))
    elif isinstance(data, list):
        for item in data:
            click.echo("  ".join(f"{k}: {v}" for k, v in item.items()))
    else:
        for k, v in data.items():
            click.echo(f"{k}: {v}")


def _make_client(cfg: Config) -> ApiClient:
    config = cfg.load_config()
    return ApiClient(
        server=config["server"],
        agent_id=config["agent_id"],
        signing_private_key=signing_key_from_pem(cfg.load_signing_key_pem()),
    )


@click.group()
def claimer_group():
    pass


@claimer_group.command("browse")
@click.option("--tags", default=None)
@click.option("--status", "status_filter", default=None)
def browse_cmd(tags, status_filter):
    """浏览可认领的任务。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        tasks = _make_client(cfg).browse(tags=tags, status=status_filter)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    if not tasks:
        click.echo("暂无可认领任务")
        return
    _out([{"task_id": t.task_id, "title": t.title, "status": t.status, "tags": ",".join(t.tags)} for t in tasks])


@claimer_group.command("claim")
@click.argument("task_id")
@click.option("--workdir", required=True, type=click.Path())
def claim_cmd(task_id, workdir):
    """认领任务并下载任务包。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        client = _make_client(cfg)
        client.claim(task_id)
        pkg = client.download_package(task_id)
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    enc_priv = encryption_key_from_pem(cfg.load_encryption_key_pem())
    try:
        data = decrypt_package(pkg.encrypted_key, pkg.iv, pkg.payload, enc_priv)
    except Exception as e:
        click.echo(f"ERROR: 解密失败 {e}", err=True)
        sys.exit(1)

    out = Path(workdir)
    out.mkdir(parents=True, exist_ok=True)
    try:
        unpack_verified(data, pkg.signature, out)
    except ValueError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    _out({"task_id": task_id, "workdir": workdir, "status": "claimed"})


@claimer_group.command("deliver")
@click.argument("task_id")
@click.option("--dir", "directory", required=True, type=click.Path(exists=True))
def deliver_cmd(task_id, directory):
    """提交交付物（领取方）。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        client = _make_client(cfg)
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    packed = pack_directory(Path(directory))
    enc = encrypt_package(packed, get_platform_enc_pub_pem())

    try:
        client.deliver(task_id, enc["encrypted_key"], enc["iv"], enc["payload"])
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    _out({"task_id": task_id, "status": "delivered"})


@claimer_group.command("abandon")
@click.argument("task_id")
def abandon_cmd(task_id):
    """放弃任务（领取方）。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        _make_client(cfg).abandon(task_id)
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    _out({"task_id": task_id, "status": "abandoned"})
