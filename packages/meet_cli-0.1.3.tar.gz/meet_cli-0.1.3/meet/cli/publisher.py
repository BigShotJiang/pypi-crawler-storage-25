# meet/cli/publisher.py
import json as _json
import sys
from pathlib import Path

import click

import meet.config as _meet_config
from meet.config import Config
from meet.api.client import ApiClient
from meet.crypto.keys import (
    signing_key_from_pem, encryption_key_from_pem,
    encrypt_package, decrypt_package, get_platform_enc_pub_pem,
)
from meet.package.pack import pack_directory
from meet.package.unpack import unpack_to_directory


def _out(data):
    """Output dict or list as JSON (--json flag) or key-value text."""
    ctx = click.get_current_context()
    as_json = ctx.obj.get("as_json", False) if ctx.obj else False
    if as_json:
        click.echo(_json.dumps(data, ensure_ascii=False))
    elif isinstance(data, list):
        for item in data:
            click.echo("  ".join(f"{k}: {v}" for k, v in item.items()))
    else:
        for k, v in data.items():
            click.echo(f"{k}: {v}")


def _make_client(cfg: Config) -> ApiClient:
    config = cfg.load_config()
    return ApiClient(
        server=config["server"],
        agent_id=config["agent_id"],
        signing_private_key=signing_key_from_pem(cfg.load_signing_key_pem()),
    )


@click.group()
def publisher_group():
    pass


@publisher_group.command("publish")
@click.option("--title", required=True)
@click.option("--desc", required=True)
@click.option("--tags", required=True, help="逗号分隔，如 python,data")
@click.option("--dir", "directory", required=True, type=click.Path(exists=True))
def publish_cmd(title, desc, tags, directory):
    """发布任务。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        client = _make_client(cfg)
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    packed = pack_directory(Path(directory))
    enc = encrypt_package(packed, get_platform_enc_pub_pem())
    meta = {"title": title, "desc": desc, "tags": tags.split(",")}

    try:
        resp = client.publish(meta, enc["encrypted_key"], enc["iv"], enc["payload"])
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    _out({"task_id": resp.task_id, "status": resp.status})


@publisher_group.command("status")
@click.option("--published", "role", flag_value="published", default=True)
@click.option("--claimed", "role", flag_value="claimed")
def status_cmd(role):
    """查看任务状态。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        client = _make_client(cfg)
        tasks = client.status(role)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    if not tasks:
        click.echo("暂无任务")
        return
    _out([{"task_id": t.task_id, "title": t.title, "status": t.status, "tags": ",".join(t.tags)} for t in tasks])


@publisher_group.command("download")
@click.argument("task_id")
@click.option("--outdir", required=True, type=click.Path())
def download_cmd(task_id, outdir):
    """下载任务交付物（发布方）。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        client = _make_client(cfg)
        resp = client.download_delivery(task_id)
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    try:
        enc_priv = encryption_key_from_pem(cfg.load_encryption_key_pem())
        data = decrypt_package(resp.encrypted_key, resp.iv, resp.payload, enc_priv)
    except Exception as e:
        click.echo(f"ERROR: 解密失败 {e}", err=True)
        sys.exit(1)

    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    try:
        unpack_to_directory(data, out)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    _out({"outdir": outdir, "status": "downloaded"})


@publisher_group.command("complete")
@click.argument("task_id")
def complete_cmd(task_id):
    """确认任务完成（发布方）。"""
    cfg = Config(meet_dir=_meet_config.MEET_DIR)
    try:
        _make_client(cfg).complete(task_id)
    except FileNotFoundError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

    _out({"task_id": task_id, "status": "completed"})
