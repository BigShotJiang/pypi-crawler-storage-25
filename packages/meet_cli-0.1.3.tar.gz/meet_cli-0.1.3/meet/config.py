# meet/config.py
import json
from pathlib import Path

MEET_DIR = Path.home() / ".meet"


class Config:
    def __init__(self, meet_dir: Path = MEET_DIR):
        self._dir = meet_dir
        self._dir.mkdir(mode=0o700, exist_ok=True)
        (self._dir / "keys").mkdir(mode=0o700, exist_ok=True)

    @property
    def _pending_path(self) -> Path:
        return self._dir / "pending.json"

    @property
    def _config_path(self) -> Path:
        return self._dir / "config.json"

    @property
    def _signing_key_path(self) -> Path:
        return self._dir / "keys" / "signing.pem"

    @property
    def _encryption_key_path(self) -> Path:
        return self._dir / "keys" / "encryption.pem"

    def save_pending(self, apply_token: str, server: str) -> None:
        self._pending_path.write_text(
            json.dumps({"apply_token": apply_token, "server": server})
        )

    def load_pending(self) -> dict:
        try:
            return json.loads(self._pending_path.read_text())
        except FileNotFoundError:
            raise FileNotFoundError("未找到待激活记录，请先执行 meet apply")

    def delete_pending(self) -> None:
        self._pending_path.unlink(missing_ok=True)

    def save_config(self, agent_id: str, server: str) -> None:
        self._config_path.write_text(
            json.dumps({"agent_id": agent_id, "server": server})
        )

    def load_config(self) -> dict:
        try:
            return json.loads(self._config_path.read_text())
        except FileNotFoundError:
            raise FileNotFoundError("未登录，请先执行 meet apply 和 meet login")

    def save_signing_key(self, pem: bytes) -> None:
        self._signing_key_path.write_bytes(pem)
        self._signing_key_path.chmod(0o600)

    def load_signing_key_pem(self) -> bytes:
        return self._signing_key_path.read_bytes()

    def save_encryption_key(self, pem: bytes) -> None:
        self._encryption_key_path.write_bytes(pem)
        self._encryption_key_path.chmod(0o600)

    def load_encryption_key_pem(self) -> bytes:
        return self._encryption_key_path.read_bytes()
