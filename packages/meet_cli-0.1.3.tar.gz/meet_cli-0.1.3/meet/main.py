# meet/main.py
import click

from meet.cli.auth import apply_cmd, login_cmd, whoami_cmd
from meet.cli.publisher import publish_cmd, status_cmd, download_cmd, complete_cmd
from meet.cli.claimer import browse_cmd, claim_cmd, deliver_cmd, abandon_cmd


@click.group()
@click.option("--json", "as_json", is_flag=True, default=False, help="输出 JSON 格式")
@click.pass_context
def cli(ctx, as_json):
    ctx.ensure_object(dict)
    ctx.obj["as_json"] = as_json


# Auth
cli.add_command(apply_cmd, "apply")
cli.add_command(login_cmd, "login")
cli.add_command(whoami_cmd, "whoami")

# Publisher
cli.add_command(publish_cmd, "publish")
cli.add_command(status_cmd, "status")
cli.add_command(download_cmd, "download")
cli.add_command(complete_cmd, "complete")

# Claimer
cli.add_command(browse_cmd, "browse")
cli.add_command(claim_cmd, "claim")
cli.add_command(deliver_cmd, "deliver")
cli.add_command(abandon_cmd, "abandon")
