# meet/crypto/keys.py
import base64
import hashlib
import os
import time
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization


# ── Ed25519: request signing ──────────────────────────────────────────────────

def generate_signing_keypair() -> tuple[Ed25519PrivateKey, bytes]:
    """Returns (private_key, raw_public_key_bytes)."""
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return priv, pub


def signing_key_to_pem(private_key: Ed25519PrivateKey) -> bytes:
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def signing_key_from_pem(pem: bytes) -> Ed25519PrivateKey:
    key = serialization.load_pem_private_key(pem, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise TypeError(f"Expected Ed25519PrivateKey, got {type(key).__name__}")
    return key


def sign_request(
    private_key: Ed25519PrivateKey, method: str, path: str, body: bytes = b""
) -> tuple[str, str]:
    """Returns (timestamp_str, base64_signature)."""
    ts = str(int(time.time()))
    body_hash = hashlib.sha256(body).hexdigest()
    message = f"{method}\n{path}\n{ts}\n{body_hash}".encode()
    sig = private_key.sign(message)
    return ts, base64.b64encode(sig).decode()


from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


# ── RSA-2048: package encryption ──────────────────────────────────────────────

def generate_encryption_keypair() -> tuple:
    """Returns (private_key, public_key_pem_str)."""
    priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pub_pem = priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode()
    return priv, pub_pem


def encryption_key_to_pem(private_key) -> bytes:
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def encryption_key_from_pem(pem: bytes):
    return serialization.load_pem_private_key(pem, password=None)


def encrypt_package(data: bytes, recipient_pubkey_pem: str) -> dict:
    """Hybrid encrypt: AES-256-GCM + RSA-OAEP. All fields base64-encoded."""
    pub = serialization.load_pem_public_key(recipient_pubkey_pem.encode())
    if not isinstance(pub, RSAPublicKey):
        raise TypeError(f"Expected RSA public key, got {type(pub).__name__}")
    aes_key = os.urandom(32)
    iv = os.urandom(12)
    payload = AESGCM(aes_key).encrypt(iv, data, None)
    enc_key = pub.encrypt(
        aes_key,
        padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    return {
        "encrypted_key": base64.b64encode(enc_key).decode(),
        "iv": base64.b64encode(iv).decode(),
        "payload": base64.b64encode(payload).decode(),
    }


def decrypt_package(encrypted_key: str, iv: str, payload: str, private_key) -> bytes:
    """Decrypt hybrid-encrypted package."""
    aes_key = private_key.decrypt(
        base64.b64decode(encrypted_key),
        padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
    )
    return AESGCM(aes_key).decrypt(base64.b64decode(iv), base64.b64decode(payload), None)


# ── Platform keys (embedded) ──────────────────────────────────────────────────

try:
    _PLATFORM_PUB_PEM = (Path(__file__).parent / "platform_pub.pem").read_bytes()
    _PLATFORM_ENC_PUB_PEM = (Path(__file__).parent / "platform_enc_pub.pem").read_bytes()
except FileNotFoundError as e:
    raise RuntimeError(f"Platform public key file missing: {e}") from e


def get_platform_enc_pub_pem() -> str:
    """Return the embedded platform RSA-2048 public key PEM (for encrypting uploads)."""
    return _PLATFORM_ENC_PUB_PEM.decode()


def verify_platform_signature(data: bytes, signature_b64: str) -> None:
    """Verify platform Ed25519 signature over data. Raises ValueError if invalid."""
    pub = serialization.load_pem_public_key(_PLATFORM_PUB_PEM)
    try:
        pub.verify(base64.b64decode(signature_b64), data)
    except Exception:
        raise ValueError("任务包签名无效，已拒绝")
