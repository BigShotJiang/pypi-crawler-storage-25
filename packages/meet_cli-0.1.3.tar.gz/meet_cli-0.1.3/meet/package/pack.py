# meet/package/pack.py
import io
import tarfile
from pathlib import Path


def pack_directory(directory: Path) -> bytes:
    """Pack directory contents into a .tar.gz and return as bytes."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        tf.add(directory, arcname=".")
    return buf.getvalue()
