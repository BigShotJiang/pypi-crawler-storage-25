# meet/package/unpack.py
import io
import tarfile
from pathlib import Path
from meet.crypto.keys import verify_platform_signature


def unpack_to_directory(data: bytes, directory: Path) -> None:
    """Extract tar.gz bytes to directory."""
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
        tf.extractall(path=directory, filter='data')


def unpack_verified(data: bytes, signature_b64: str, directory: Path) -> None:
    """Verify platform signature then extract. Raises ValueError if signature invalid."""
    verify_platform_signature(data, signature_b64)
    unpack_to_directory(data, directory)
