# tests/test_api_client.py
import httpx
import pytest
import respx


@pytest.fixture
def client():
    from meet.api.client import ApiClient
    from meet.crypto.keys import generate_signing_keypair
    priv, _ = generate_signing_keypair()
    return ApiClient(server="https://www.meet-her.com", agent_id="agent_abc", signing_private_key=priv)


@respx.mock
def test_apply_static_returns_apply_response():
    from meet.api.client import ApiClient
    from meet.api.models import ApplyResponse
    respx.post("https://www.meet-her.com/api/v1/apply").mock(
        return_value=httpx.Response(200, json={
            "apply_token": "tok123",
            "activate_url": "https://www.meet-her.com/activate/tok123",
        })
    )
    result = ApiClient.apply_static(server="https://www.meet-her.com")
    assert isinstance(result, ApplyResponse)
    assert result.apply_token == "tok123"


@respx.mock
def test_authenticated_request_has_auth_header(client):
    respx.get("https://www.meet-her.com/api/v1/me").mock(
        return_value=httpx.Response(200, json={"agent_id": "agent_abc", "name": "Test"})
    )
    client.whoami()
    assert "Authorization" in respx.calls[0].request.headers
    assert respx.calls[0].request.headers["Authorization"].startswith("Meet ")


@respx.mock
def test_404_raises_not_found(client):
    from meet.api.client import NotFoundError
    respx.post("https://www.meet-her.com/api/v1/tasks/bad/claim").mock(
        return_value=httpx.Response(404, json={"error": "not found"})
    )
    with pytest.raises(NotFoundError):
        client.claim("bad")


@respx.mock
def test_409_raises_conflict(client):
    from meet.api.client import ConflictError
    respx.post("https://www.meet-her.com/api/v1/tasks/t1/claim").mock(
        return_value=httpx.Response(409, json={"error": "already claimed"})
    )
    with pytest.raises(ConflictError, match="请求冲突"):
        client.claim("t1")


@respx.mock
def test_401_raises_auth_error(client):
    from meet.api.client import AuthError
    respx.get("https://www.meet-her.com/api/v1/me").mock(
        return_value=httpx.Response(401, json={"error": "unauthorized"})
    )
    with pytest.raises(AuthError):
        client.whoami()
