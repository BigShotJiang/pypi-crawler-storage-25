# tests/test_cli_publisher.py
import pytest
from click.testing import CliRunner
from unittest.mock import patch, MagicMock
from pathlib import Path


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def logged_in(tmp_path, monkeypatch):
    import meet.config as m
    monkeypatch.setattr(m, "MEET_DIR", tmp_path)
    from meet.config import Config
    from meet.crypto.keys import (
        generate_signing_keypair, signing_key_to_pem,
        generate_encryption_keypair, encryption_key_to_pem,
    )
    cfg = Config(meet_dir=tmp_path)
    cfg.save_config("agent_abc", "https://www.meet-her.com")
    sp, _ = generate_signing_keypair()
    ep, _ = generate_encryption_keypair()
    cfg.save_signing_key(signing_key_to_pem(sp))
    cfg.save_encryption_key(encryption_key_to_pem(ep))
    return tmp_path


def test_publish_not_logged_in(runner, tmp_path, monkeypatch):
    import meet.config as m
    monkeypatch.setattr(m, "MEET_DIR", tmp_path)
    from meet.cli.publisher import publisher_group
    result = runner.invoke(publisher_group, ["publish", "--title", "t", "--desc", "d", "--tags", "x", "--dir", "."])
    assert result.exit_code != 0


def test_publish_packs_and_calls_api(runner, logged_in, tmp_path):
    task_dir = tmp_path / "task"
    task_dir.mkdir()
    (task_dir / "brief.txt").write_text("do this")

    mock_resp = MagicMock(task_id="t1", status="pending_review")
    with patch("meet.api.client.ApiClient.publish", return_value=mock_resp):
        from meet.cli.publisher import publisher_group
        result = runner.invoke(publisher_group, [
            "publish", "--title", "Fix bug", "--desc", "desc",
            "--tags", "python", "--dir", str(task_dir),
        ])
    assert result.exit_code == 0
    assert "t1" in result.output
    assert "pending_review" in result.output


def test_status_published(runner, logged_in):
    mock_tasks = [MagicMock(task_id="t1", title="Fix bug", status="open", tags=["py"], desc="d")]
    with patch("meet.api.client.ApiClient.status", return_value=mock_tasks):
        from meet.cli.publisher import publisher_group
        result = runner.invoke(publisher_group, ["status", "--published"])
    assert result.exit_code == 0
    assert "t1" in result.output


def test_status_claimed(runner, logged_in):
    mock_tasks = [MagicMock(task_id="t2", title="Do work", status="claimed", tags=["go"], desc="d")]
    with patch("meet.api.client.ApiClient.status", return_value=mock_tasks):
        from meet.cli.publisher import publisher_group
        result = runner.invoke(publisher_group, ["status", "--claimed"])
    assert result.exit_code == 0
    assert "t2" in result.output


def test_download_delivery(runner, logged_in, tmp_path):
    from meet.crypto.keys import (
        generate_encryption_keypair, encrypt_package, encryption_key_from_pem,
    )
    from meet.package.pack import pack_directory
    from cryptography.hazmat.primitives import serialization
    from meet.config import Config

    cfg = Config(meet_dir=logged_in)
    user_enc_priv = encryption_key_from_pem(cfg.load_encryption_key_pem())
    user_enc_pub_pem = user_enc_priv.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    ).decode()

    src = tmp_path / "src"
    src.mkdir()
    (src / "output.txt").write_text("delivery content")
    packed = pack_directory(src)
    enc = encrypt_package(packed, user_enc_pub_pem)

    mock_resp = MagicMock(
        encrypted_key=enc["encrypted_key"],
        iv=enc["iv"],
        payload=enc["payload"],
    )
    outdir = tmp_path / "out"
    outdir.mkdir()

    with patch("meet.api.client.ApiClient.download_delivery", return_value=mock_resp):
        from meet.cli.publisher import publisher_group
        result = runner.invoke(publisher_group, ["download", "t1", "--outdir", str(outdir)])

    assert result.exit_code == 0, result.output
    assert (outdir / "output.txt").exists()


def test_complete_succeeds(runner, logged_in):
    with patch("meet.api.client.ApiClient.complete"):
        from meet.cli.publisher import publisher_group
        result = runner.invoke(publisher_group, ["complete", "t1"])
    assert result.exit_code == 0
    assert "completed" in result.output
