# tests/test_cli_auth.py
import pytest
from click.testing import CliRunner
from unittest.mock import patch, MagicMock


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_meet_dir(tmp_path, monkeypatch):
    import meet.config as m
    monkeypatch.setattr(m, "MEET_DIR", tmp_path)
    return tmp_path


def test_apply_prints_activate_url(runner, mock_meet_dir):
    mock_resp = MagicMock(apply_token="tok123", activate_url="https://www.meet-her.com/activate/tok123")
    with patch("meet.api.client.ApiClient.apply_static", return_value=mock_resp):
        from meet.cli.auth import auth_group
        result = runner.invoke(auth_group, ["apply"])
    assert result.exit_code == 0
    assert "https://www.meet-her.com/activate/tok123" in result.output
    assert "meet login" in result.output


def test_apply_saves_pending(runner, mock_meet_dir):
    mock_resp = MagicMock(apply_token="tok123", activate_url="https://example.com")
    with patch("meet.api.client.ApiClient.apply_static", return_value=mock_resp):
        from meet.cli.auth import auth_group
        runner.invoke(auth_group, ["apply"])
    from meet.config import Config
    data = Config(meet_dir=mock_meet_dir).load_pending()
    assert data["apply_token"] == "tok123"


def test_login_requires_pending(runner, mock_meet_dir):
    from meet.cli.auth import auth_group
    result = runner.invoke(auth_group, ["login"])
    assert result.exit_code != 0
    assert "meet apply" in result.output


def test_whoami_not_logged_in(runner, mock_meet_dir):
    from meet.cli.auth import auth_group
    result = runner.invoke(auth_group, ["whoami"])
    assert result.exit_code != 0
