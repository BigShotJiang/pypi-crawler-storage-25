# tests/test_crypto.py
import base64
import pytest


def test_generate_signing_keypair():
    from meet.crypto.keys import generate_signing_keypair
    private_key, pub_bytes = generate_signing_keypair()
    assert len(pub_bytes) == 32  # Ed25519 raw public key = 32 bytes


def test_sign_request_returns_ts_and_sig():
    from meet.crypto.keys import generate_signing_keypair, sign_request
    priv, _ = generate_signing_keypair()
    ts, sig = sign_request(priv, "POST", "/api/v1/tasks", b'{"title":"x"}')
    assert ts.isdigit()
    assert len(base64.b64decode(sig)) == 64  # Ed25519 signature = 64 bytes


def test_sign_request_different_body_gives_different_sig():
    from meet.crypto.keys import generate_signing_keypair, sign_request
    priv, _ = generate_signing_keypair()
    _, sig1 = sign_request(priv, "POST", "/api/v1/tasks", b"body1")
    _, sig2 = sign_request(priv, "POST", "/api/v1/tasks", b"body2")
    assert sig1 != sig2


def test_signing_key_pem_roundtrip():
    from meet.crypto.keys import (
        generate_signing_keypair, signing_key_to_pem, signing_key_from_pem,
    )
    from cryptography.hazmat.primitives import serialization

    priv, pub_bytes = generate_signing_keypair()
    pem = signing_key_to_pem(priv)
    loaded = signing_key_from_pem(pem)
    loaded_pub = loaded.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    assert loaded_pub == pub_bytes


def test_generate_encryption_keypair():
    from meet.crypto.keys import generate_encryption_keypair
    priv, pub_pem = generate_encryption_keypair()
    assert "BEGIN PUBLIC KEY" in pub_pem


def test_hybrid_encrypt_decrypt_roundtrip():
    from meet.crypto.keys import generate_encryption_keypair, encrypt_package, decrypt_package
    priv, pub_pem = generate_encryption_keypair()
    original = b"task package content"
    enc = encrypt_package(original, pub_pem)
    assert set(enc.keys()) == {"encrypted_key", "iv", "payload"}
    assert decrypt_package(enc["encrypted_key"], enc["iv"], enc["payload"], priv) == original


def test_hybrid_wrong_key_raises():
    from meet.crypto.keys import generate_encryption_keypair, encrypt_package, decrypt_package
    _, pub_pem = generate_encryption_keypair()
    wrong_priv, _ = generate_encryption_keypair()
    enc = encrypt_package(b"secret", pub_pem)
    with pytest.raises(Exception):
        decrypt_package(enc["encrypted_key"], enc["iv"], enc["payload"], wrong_priv)


def test_encryption_key_pem_roundtrip():
    from meet.crypto.keys import (
        generate_encryption_keypair, encryption_key_to_pem, encryption_key_from_pem,
        encrypt_package, decrypt_package,
    )
    priv, pub_pem = generate_encryption_keypair()
    loaded = encryption_key_from_pem(encryption_key_to_pem(priv))
    enc = encrypt_package(b"hello", pub_pem)
    assert decrypt_package(enc["encrypted_key"], enc["iv"], enc["payload"], loaded) == b"hello"


def test_verify_platform_signature_invalid_raises(monkeypatch):
    from meet.crypto.keys import generate_signing_keypair
    from cryptography.hazmat.primitives import serialization
    import meet.crypto.keys as ck

    priv, _ = generate_signing_keypair()
    pub_pem = priv.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    )
    monkeypatch.setattr(ck, "_PLATFORM_PUB_PEM", pub_pem)

    from meet.crypto.keys import verify_platform_signature
    with pytest.raises(ValueError, match="任务包签名无效"):
        verify_platform_signature(b"data", "aW52YWxpZA==")
