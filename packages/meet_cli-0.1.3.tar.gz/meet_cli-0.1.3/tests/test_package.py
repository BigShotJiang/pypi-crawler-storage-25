# tests/test_package.py
import io
import tarfile
import pytest


def test_pack_directory_returns_valid_targz(tmp_path):
    from meet.package.pack import pack_directory
    (tmp_path / "a.txt").write_text("hello")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "b.txt").write_text("world")

    result = pack_directory(tmp_path)

    assert isinstance(result, bytes)
    with tarfile.open(fileobj=io.BytesIO(result), mode="r:gz") as tf:
        names = tf.getnames()
    assert any("a.txt" in n for n in names)
    assert any("b.txt" in n for n in names)


def test_pack_empty_directory(tmp_path):
    from meet.package.pack import pack_directory
    result = pack_directory(tmp_path)
    assert isinstance(result, bytes)
    assert len(result) > 0


def test_unpack_restores_files(tmp_path):
    from meet.package.pack import pack_directory
    from meet.package.unpack import unpack_to_directory

    src = tmp_path / "src"
    src.mkdir()
    (src / "file.txt").write_text("content")

    packed = pack_directory(src)
    out = tmp_path / "out"
    out.mkdir()
    unpack_to_directory(packed, out)

    assert (out / "file.txt").read_text() == "content"


def test_unpack_verified_with_valid_sig(tmp_path, monkeypatch):
    from meet.package.pack import pack_directory
    from meet.package.unpack import unpack_verified
    from meet.crypto.keys import generate_signing_keypair
    from cryptography.hazmat.primitives import serialization
    import meet.crypto.keys as ck

    priv, _ = generate_signing_keypair()
    pub_pem = priv.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    )
    monkeypatch.setattr(ck, "_PLATFORM_PUB_PEM", pub_pem)

    src = tmp_path / "src"
    src.mkdir()
    (src / "x.txt").write_text("data")
    packed = pack_directory(src)

    import base64
    sig = base64.b64encode(priv.sign(packed)).decode()

    out = tmp_path / "out"
    out.mkdir()
    unpack_verified(packed, sig, out)
    assert (out / "x.txt").read_text() == "data"


def test_unpack_verified_with_invalid_sig_raises(tmp_path, monkeypatch):
    from meet.package.pack import pack_directory
    from meet.package.unpack import unpack_verified
    from meet.crypto.keys import generate_signing_keypair
    from cryptography.hazmat.primitives import serialization
    import meet.crypto.keys as ck

    priv, _ = generate_signing_keypair()
    pub_pem = priv.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    )
    monkeypatch.setattr(ck, "_PLATFORM_PUB_PEM", pub_pem)

    src = tmp_path / "src"
    src.mkdir()
    packed = pack_directory(src)

    out = tmp_path / "out"
    out.mkdir()
    with pytest.raises(ValueError, match="签名无效"):
        unpack_verified(packed, "aW52YWxpZA==", out)
