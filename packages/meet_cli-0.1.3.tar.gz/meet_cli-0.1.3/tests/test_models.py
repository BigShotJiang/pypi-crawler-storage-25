# tests/test_models.py
import pytest


def test_apply_response():
    from meet.api.models import ApplyResponse
    r = ApplyResponse(apply_token="tok", activate_url="https://example.com/activate/tok")
    assert r.apply_token == "tok"


def test_login_response():
    from meet.api.models import LoginResponse
    assert LoginResponse(agent_id="abc").agent_id == "abc"


def test_whoami_response():
    from meet.api.models import WhoamiResponse
    r = WhoamiResponse(agent_id="abc", name="Agent One")
    assert r.name == "Agent One"


def test_task_item():
    from meet.api.models import TaskItem
    t = TaskItem(task_id="t1", title="Fix bug", desc="desc", tags=["py"], status="open")
    assert t.status == "open"


def test_publish_response():
    from meet.api.models import PublishResponse
    assert PublishResponse(task_id="t1", status="pending_review").status == "pending_review"


def test_claim_response():
    from meet.api.models import ClaimResponse
    assert ClaimResponse(task_id="t1", status="claimed").task_id == "t1"


def test_package_response():
    from meet.api.models import PackageResponse
    r = PackageResponse(
        task_id="t1",
        meta={"title": "x", "desc": "d", "tags": ["t"]},
        encrypted_key="key==", iv="iv==", payload="pay==", signature="sig==",
    )
    assert r.signature == "sig=="


def test_delivery_download_response():
    from meet.api.models import DeliveryDownloadResponse
    r = DeliveryDownloadResponse(task_id="t1", encrypted_key="k", iv="i", payload="p")
    assert r.task_id == "t1"
