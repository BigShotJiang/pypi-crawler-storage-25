# tests/test_cli_claimer.py
import pytest
from click.testing import CliRunner
from unittest.mock import patch, MagicMock
from pathlib import Path


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def logged_in(tmp_path, monkeypatch):
    import meet.config as m
    monkeypatch.setattr(m, "MEET_DIR", tmp_path)
    from meet.config import Config
    from meet.crypto.keys import (
        generate_signing_keypair, signing_key_to_pem,
        generate_encryption_keypair, encryption_key_to_pem,
    )
    cfg = Config(meet_dir=tmp_path)
    cfg.save_config("agent_abc", "https://www.meet-her.com")
    sp, _ = generate_signing_keypair()
    ep, _ = generate_encryption_keypair()
    cfg.save_signing_key(signing_key_to_pem(sp))
    cfg.save_encryption_key(encryption_key_to_pem(ep))
    return tmp_path


def test_browse_shows_tasks(runner, logged_in):
    mock_tasks = [MagicMock(task_id="t1", title="Fix bug", status="open", tags=["py"], desc="d")]
    with patch("meet.api.client.ApiClient.browse", return_value=mock_tasks):
        from meet.cli.claimer import claimer_group
        result = runner.invoke(claimer_group, ["browse"])
    assert result.exit_code == 0
    assert "t1" in result.output
    assert "Fix bug" in result.output


def test_claim_downloads_and_verifies_package(runner, logged_in, tmp_path):
    from meet.crypto.keys import (
        generate_encryption_keypair, encrypt_package,
        generate_signing_keypair,
    )
    from meet.package.pack import pack_directory
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    import meet.crypto.keys as ck
    import base64

    # Build real encrypted package with the user's actual encryption key
    from meet.config import Config
    cfg = Config(meet_dir=logged_in)
    from meet.crypto.keys import encryption_key_from_pem
    user_enc_priv = encryption_key_from_pem(cfg.load_encryption_key_pem())
    user_enc_pub_pem = user_enc_priv.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    ).decode()

    src = tmp_path / "src"
    src.mkdir()
    (src / "brief.txt").write_text("task content")
    packed = pack_directory(src)

    # Sign with a test platform key
    sig_key = Ed25519PrivateKey.generate()
    pub_pem = sig_key.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
    )
    sig = base64.b64encode(sig_key.sign(packed)).decode()
    enc = encrypt_package(packed, user_enc_pub_pem)

    mock_claim = MagicMock(task_id="t1", status="claimed")
    mock_pkg = MagicMock(
        task_id="t1",
        meta={"title": "Fix bug"},
        signature=sig,
        encrypted_key=enc["encrypted_key"],
        iv=enc["iv"],
        payload=enc["payload"],
    )

    workdir = tmp_path / "work"
    workdir.mkdir()

    import meet.crypto.keys as ck
    with patch("meet.api.client.ApiClient.claim", return_value=mock_claim), \
         patch("meet.api.client.ApiClient.download_package", return_value=mock_pkg), \
         patch.object(ck, "_PLATFORM_PUB_PEM", pub_pem):
        from meet.cli.claimer import claimer_group
        result = runner.invoke(claimer_group, ["claim", "t1", "--workdir", str(workdir)])

    assert result.exit_code == 0, result.output
    assert (workdir / "brief.txt").exists()


def test_deliver_packs_and_calls_api(runner, logged_in, tmp_path):
    deliver_dir = tmp_path / "output"
    deliver_dir.mkdir()
    (deliver_dir / "result.txt").write_text("done")

    with patch("meet.api.client.ApiClient.deliver") as mock_deliver:
        from meet.cli.claimer import claimer_group
        result = runner.invoke(claimer_group, ["deliver", "t1", "--dir", str(deliver_dir)])

    assert result.exit_code == 0, result.output
    assert "delivered" in result.output
    mock_deliver.assert_called_once()


def test_abandon_succeeds(runner, logged_in):
    with patch("meet.api.client.ApiClient.abandon"):
        from meet.cli.claimer import claimer_group
        result = runner.invoke(claimer_group, ["abandon", "t1"])
    assert result.exit_code == 0
    assert "abandoned" in result.output
