# tests/test_config.py
import pytest
from pathlib import Path


@pytest.fixture
def cfg(tmp_path, monkeypatch):
    import meet.config as m
    monkeypatch.setattr(m, "MEET_DIR", tmp_path)
    from meet.config import Config
    return Config(meet_dir=tmp_path)


def test_save_and_load_pending(cfg, tmp_path):
    cfg.save_pending("tok123", "https://www.meet-her.com")
    assert (tmp_path / "pending.json").exists()
    data = cfg.load_pending()
    assert data["apply_token"] == "tok123"
    assert data["server"] == "https://www.meet-her.com"


def test_load_pending_missing_raises(cfg):
    with pytest.raises(FileNotFoundError, match="meet apply"):
        cfg.load_pending()


def test_delete_pending(cfg, tmp_path):
    cfg.save_pending("tok123", "https://www.meet-her.com")
    cfg.delete_pending()
    assert not (tmp_path / "pending.json").exists()


def test_save_and_load_config(cfg):
    cfg.save_config("agent_abc", "https://www.meet-her.com")
    data = cfg.load_config()
    assert data["agent_id"] == "agent_abc"
    assert data["server"] == "https://www.meet-her.com"


def test_load_config_missing_raises(cfg):
    with pytest.raises(FileNotFoundError, match="meet apply"):
        cfg.load_config()


def test_save_and_load_signing_key(cfg):
    cfg.save_signing_key(b"fake_pem_data")
    assert cfg.load_signing_key_pem() == b"fake_pem_data"


def test_save_and_load_encryption_key(cfg):
    cfg.save_encryption_key(b"fake_enc_pem")
    assert cfg.load_encryption_key_pem() == b"fake_enc_pem"
