"""SDK-backed S3/R2 transfer helpers for trusted Tensorhub workers."""

from __future__ import annotations

import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Optional

from .api.errors import ArtifactTransferError
from .presigned_upload import blake3_hash_file

_MULTIPART_CHUNK_BYTES = 64 * 1024 * 1024
_MULTIPART_MAX_WORKERS = 8
_PART_UPLOAD_ATTEMPTS = 4


@dataclass(frozen=True)
class S3TransferGrant:
    endpoint_url: str
    bucket: str
    key: str
    access_key_id: str
    secret_access_key: str
    session_token: str = ""
    region: str = "auto"
    expires_at: str = ""

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "S3TransferGrant":
        def _first(*keys: str) -> str:
            for key in keys:
                value = str(raw.get(key) or "").strip()
                if value:
                    return value
            return ""

        grant = cls(
            endpoint_url=_first("endpoint_url", "endpointUrl"),
            bucket=_first("bucket", "bucket_name", "bucketName"),
            key=_first("key", "object_key", "objectKey"),
            access_key_id=_first("access_key_id", "accessKeyId"),
            secret_access_key=_first("secret_access_key", "secretAccessKey"),
            session_token=_first("session_token", "sessionToken"),
            region=_first("region") or "auto",
            expires_at=_first("expires_at", "expiresAt"),
        )
        missing = [
            name
            for name, value in {
                "endpoint_url": grant.endpoint_url,
                "bucket": grant.bucket,
                "key": grant.key,
                "access_key_id": grant.access_key_id,
                "secret_access_key": grant.secret_access_key,
            }.items()
            if not value
        ]
        if missing:
            raise ArtifactTransferError(
                "tensorhub transfer grant is missing required fields: " + ", ".join(missing),
                provider="tensorhub",
                phase="grant",
                retryable=False,
            )
        return grant


@dataclass(frozen=True)
class S3TransferResult:
    bucket: str
    key: str
    size_bytes: int
    blake3: str
    etag: str = ""


def upload_file_with_grant(
    *,
    file_path: str | Path,
    grant: S3TransferGrant,
    blake3_hex: str,
    size_bytes: int,
    on_progress: Optional[Any] = None,
) -> S3TransferResult:
    path = Path(file_path)
    actual_size = int(path.stat().st_size)
    if actual_size != int(size_bytes):
        raise ArtifactTransferError(
            f"local file size changed before upload: expected {size_bytes}, got {actual_size}",
            provider="tensorhub",
            phase="sdk_upload",
            retryable=False,
        )

    seen = 0
    lock = threading.Lock()

    def _progress(delta: int) -> None:
        nonlocal seen
        if not on_progress:
            return
        with lock:
            seen += int(delta)
            current = min(seen, actual_size)
        on_progress(1 if current >= actual_size else 0, 1, current)

    etag = _upload_file_multipart(path, grant, actual_size, _progress if on_progress else None)

    return S3TransferResult(bucket=grant.bucket, key=grant.key, size_bytes=actual_size, blake3=blake3_hex, etag=etag)


def _upload_file_multipart(
    path: Path,
    grant: S3TransferGrant,
    size_bytes: int,
    on_progress: Optional[Any],
) -> str:
    if size_bytes <= _MULTIPART_CHUNK_BYTES:
        return _put_object(path, grant, size_bytes, on_progress)

    client = _s3_client(grant)
    upload_id = ""
    completed: list[dict[str, Any]] = []
    try:
        created = client.create_multipart_upload(Bucket=grant.bucket, Key=grant.key)
        upload_id = str(created["UploadId"])
        part_count = (size_bytes + _MULTIPART_CHUNK_BYTES - 1) // _MULTIPART_CHUNK_BYTES
        workers = min(_MULTIPART_MAX_WORKERS, part_count)
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="s3-part") as executor:
            futures = [
                executor.submit(
                    _upload_part,
                    path,
                    grant,
                    upload_id,
                    part_number,
                    (part_number - 1) * _MULTIPART_CHUNK_BYTES,
                    min(_MULTIPART_CHUNK_BYTES, size_bytes - ((part_number - 1) * _MULTIPART_CHUNK_BYTES)),
                    on_progress,
                )
                for part_number in range(1, part_count + 1)
            ]
            for future in as_completed(futures):
                completed.append(future.result())
        completed.sort(key=lambda part: int(part["PartNumber"]))
        result = client.complete_multipart_upload(
            Bucket=grant.bucket,
            Key=grant.key,
            UploadId=upload_id,
            MultipartUpload={"Parts": completed},
        )
        return str(result.get("ETag") or "").strip()
    except Exception as exc:
        if upload_id:
            try:
                client.abort_multipart_upload(Bucket=grant.bucket, Key=grant.key, UploadId=upload_id)
            except Exception:
                pass
        if isinstance(exc, ArtifactTransferError):
            raise
        raise ArtifactTransferError(
            f"tensorhub SDK multipart upload failed: {exc}",
            provider="tensorhub",
            phase="sdk_upload",
            retryable=True,
            cause_type=type(exc).__name__,
        ) from exc


def _put_object(
    path: Path,
    grant: S3TransferGrant,
    size_bytes: int,
    on_progress: Optional[Any],
) -> str:
    try:
        with path.open("rb") as handle:
            body = handle.read(size_bytes)
            result = _s3_client(grant).put_object(
                Bucket=grant.bucket,
                Key=grant.key,
                Body=body,
                ContentLength=size_bytes,
            )
        if on_progress:
            on_progress(size_bytes)
        return str(result.get("ETag") or "").strip()
    except Exception as exc:
        raise ArtifactTransferError(
            f"tensorhub SDK upload failed: {exc}",
            provider="tensorhub",
            phase="sdk_upload",
            retryable=True,
            cause_type=type(exc).__name__,
        ) from exc


def _upload_part(
    path: Path,
    grant: S3TransferGrant,
    upload_id: str,
    part_number: int,
    offset: int,
    size_bytes: int,
    on_progress: Optional[Any],
) -> dict[str, Any]:
    last_exc: Exception | None = None
    for attempt in range(1, _PART_UPLOAD_ATTEMPTS + 1):
        client = _s3_client(grant)
        try:
            with path.open("rb") as handle:
                handle.seek(offset)
                body = handle.read(size_bytes)
                result = client.upload_part(
                    Bucket=grant.bucket,
                    Key=grant.key,
                    UploadId=upload_id,
                    PartNumber=part_number,
                    Body=body,
                    ContentLength=size_bytes,
                )
            if on_progress:
                on_progress(size_bytes)
            return {"PartNumber": part_number, "ETag": str(result["ETag"])}
        except Exception as exc:
            last_exc = exc
            if attempt == _PART_UPLOAD_ATTEMPTS:
                break
            time.sleep(min(2 ** (attempt - 1), 8))
        finally:
            close = getattr(client, "close", None)
            if callable(close):
                close()
    raise ArtifactTransferError(
        f"tensorhub SDK upload part {part_number} failed after {_PART_UPLOAD_ATTEMPTS} attempts: {last_exc}",
        provider="tensorhub",
        phase="sdk_upload",
        retryable=True,
        cause_type=type(last_exc).__name__ if last_exc else "Unknown",
    )


def download_file_with_grant(
    *,
    grant: S3TransferGrant,
    dest_path: str | Path,
    expected_blake3: str = "",
    expected_size_bytes: int | None = None,
) -> S3TransferResult:
    dest = Path(dest_path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".tmp")
    client = _s3_client(grant)
    try:
        client.download_file(grant.bucket, grant.key, str(tmp), Config=_transfer_config())
    except Exception as exc:
        raise ArtifactTransferError(
            f"tensorhub SDK download failed: {exc}",
            provider="tensorhub",
            phase="sdk_download",
            retryable=True,
            cause_type=type(exc).__name__,
        ) from exc

    size = int(tmp.stat().st_size)
    if expected_size_bytes is not None and size != int(expected_size_bytes):
        tmp.unlink(missing_ok=True)
        raise ArtifactTransferError(
            f"downloaded object size mismatch: expected {expected_size_bytes}, got {size}",
            provider="tensorhub",
            phase="sdk_download",
            retryable=False,
        )
    digest = blake3_hash_file(tmp)
    if expected_blake3 and digest.lower() != expected_blake3.lower():
        tmp.unlink(missing_ok=True)
        raise ArtifactTransferError(
            "downloaded object BLAKE3 mismatch",
            provider="tensorhub",
            phase="sdk_download",
            retryable=False,
        )
    os.replace(tmp, dest)
    return S3TransferResult(bucket=grant.bucket, key=grant.key, size_bytes=size, blake3=digest)


def _s3_client(grant: S3TransferGrant) -> Any:
    import boto3
    from botocore.config import Config

    return boto3.client(
        "s3",
        endpoint_url=grant.endpoint_url,
        region_name=grant.region or "auto",
        aws_access_key_id=grant.access_key_id,
        aws_secret_access_key=grant.secret_access_key,
        aws_session_token=grant.session_token or None,
        config=Config(
            signature_version="s3v4",
            retries={"mode": "standard", "max_attempts": 10},
            request_checksum_calculation="when_required",
            response_checksum_validation="when_required",
            tcp_keepalive=True,
        ),
    )


def _transfer_config() -> Any:
    from boto3.s3.transfer import TransferConfig

    return TransferConfig(
        multipart_threshold=_MULTIPART_CHUNK_BYTES,
        multipart_chunksize=_MULTIPART_CHUNK_BYTES,
        max_concurrency=1,
        use_threads=False,
    )
