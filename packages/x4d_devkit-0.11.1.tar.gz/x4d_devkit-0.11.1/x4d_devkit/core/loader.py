"""ClipLoader: load an X4D clip directory into typed dataclasses."""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any, Literal

import numpy as np

from x4d_devkit.core.models import (
    ClipMeta,
    CalibratedSensor,
    EgoPose,
    Sample,
    SampleData,
    Annotation,
    Instance,
    SensorInfo,
)
from x4d_devkit.core.transform import Transform, TransformChain, rotation_matrix_to_quat

FrameType = Literal["sensor", "ego", "world"]
_VALID_FRAMES = {"sensor", "ego", "world"}
# In annotation/transform APIs the user may pass the literal aliases above
# OR any frame_id string that resolves in the calibration tree. We resolve
# "ego" and "base_link" to the ego (vehicle body) frame; "world" composes
# with ego_pose; any other string is treated as a sensor frame_id and looked
# up via the calibration tree.
_EGO_ALIASES = {"ego", "base_link"}


class SchemaVersionMismatch(ValueError):
    """Raised when a clip's ``meta.schema_version`` doesn't match the consumer's expectations.

    Attributes:
        actual: the version found in ``meta.json``.
        expected: the version (or set of versions) the consumer required.
    """

    def __init__(self, actual: str, expected: "str | set[str]") -> None:
        self.actual = actual
        self.expected = expected
        if isinstance(expected, str):
            msg = f"clip schema_version is {actual!r}, expected {expected!r}"
        else:
            msg = f"clip schema_version is {actual!r}, expected one of {sorted(expected)!r}"
        super().__init__(msg)


class ClipLoader:
    """Load and index an X4D clip directory.

    Eagerly parses all JSON metadata into frozen dataclasses on construction.
    Binary sensor data (point clouds, images) is loaded on demand.

    Args:
        clip_dir: Path to a clip directory containing meta.json and other
            X4D JSON/binary files.

    Example::

        loader = ClipLoader("/data/clips/my_clip")
        print(loader.meta.clip_id)

        # Find lidar channels by modality — never hardcode "lidar" / "LIDAR_TOP".
        # The directory/channel name is producer-defined: nuScenes-converted clips
        # use "LIDAR_TOP", X-4D platform fused output uses "lidar", reconstruction
        # pipelines may use any name. Always look up via meta.sensors.
        lidar_channels = [
            ch for ch, info in loader.meta.sensors.items()
            if info.modality == "lidar"
        ]

        for sample in loader.samples:
            for sd in loader.sample_data_for_sample(sample.token):
                if sd.channel in lidar_channels:
                    pts = loader.load_point_cloud(sd, frame="ego")

        # Get annotations in their stored frame (loader.annotation_frame_id)
        anns = loader.annotations_for_sample(sample.token)
        # Or transform to a specific frame_id from the calibration tree
        anns_in_top_lidar = loader.annotations_for_sample(sample.token, frame="LIDAR_TOP")
    """

    def __init__(
        self,
        clip_dir: str | Path,
        *,
        expected_schema_version: "str | set[str] | None" = None,
    ) -> None:
        self._clip_dir = Path(clip_dir)

        # Load and parse all JSON
        self._meta = self._load_meta()
        if expected_schema_version is not None:
            self.require_schema_version(expected_schema_version)
        self._calibrated_sensors = self._load_calibrated_sensors()
        self._ego_poses = self._load_ego_poses()
        self._samples = self._load_samples()
        self._sample_data = self._load_sample_data()
        self._annotations = self._load_annotations()
        self._instances = self._load_instances()

        # Build global token → object index
        self._token_index: dict[str, Any] = {}
        for cs in self._calibrated_sensors:
            self._token_index[cs.token] = cs
        for ep in self._ego_poses:
            self._token_index[ep.token] = ep
        for s in self._samples:
            self._token_index[s.token] = s
        for sd in self._sample_data:
            self._token_index[sd.token] = sd
        for a in self._annotations:
            self._token_index[a.token] = a
        for i in self._instances:
            self._token_index[i.token] = i

        # Build auxiliary indices
        self._sd_by_channel: dict[str, list[SampleData]] = {}
        for sd in self._sample_data:
            self._sd_by_channel.setdefault(sd.channel, []).append(sd)
        for ch in self._sd_by_channel:
            self._sd_by_channel[ch].sort(key=lambda sd: sd.timestamp_us)

        self._sd_by_sample: dict[str, list[SampleData]] = {}
        for sd in self._sample_data:
            self._sd_by_sample.setdefault(sd.sample_token, []).append(sd)

        self._ann_by_sample: dict[str, list[Annotation]] = {}
        for a in self._annotations:
            self._ann_by_sample.setdefault(a.sample_token, []).append(a)

    def _read_json(self, name: str) -> Any:
        with open(self._clip_dir / name) as f:
            return json.load(f)

    def _load_meta(self) -> ClipMeta:
        d = self._read_json("meta.json")
        sensors = {
            channel: SensorInfo.from_dict(raw)
            for channel, raw in (d.get("sensors") or {}).items()
        }
        return ClipMeta(
            clip_id=d["clip_id"],
            schema_version=d["schema_version"],
            session_id=d["session_id"],
            vehicle_id=d["vehicle_id"],
            capture_time_utc=d["capture_time_utc"],
            duration_s=d["duration_s"],
            num_keyframes=d["keyframe_count"],
            num_sweeps=d["sweep_count"],
            sensors=sensors,
            annotation_frame_id=d.get("annotation_frame_id"),
            ego_pose_frame_id=d.get("ego_pose_frame_id"),
        )

    def _load_calibrated_sensors(self) -> list[CalibratedSensor]:
        records = self._read_json("calibrated_sensor.json")
        result = []
        for r in records:
            t = r["translation"]
            q = r["rotation"]
            intr = r.get("intrinsics")
            result.append(CalibratedSensor(
                token=r["calibrated_sensor_token"],
                channel=r["channel"],
                parent_frame=r.get("parent_frame"),
                modality="camera" if intr is not None else "lidar",
                translation=[t["x"], t["y"], t["z"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
                intrinsics=intr,
                distortion=r.get("distortion"),
            ))
        return result

    def _load_ego_poses(self) -> list[EgoPose]:
        records = self._read_json("ego_pose.json")
        result = []
        for r in records:
            t = r["translation"]
            q = r["rotation"]
            result.append(EgoPose(
                token=r["ego_pose_token"],
                timestamp_us=r["timestamp_us"],
                translation=[t["x"], t["y"], t["z"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
            ))
        result.sort(key=lambda ep: ep.timestamp_us)
        return result

    def _load_samples(self) -> list[Sample]:
        records = self._read_json("sample.json")
        result = []
        for r in records:
            result.append(Sample(
                token=r["sample_token"],
                timestamp_us=r["timestamp_us"],
                is_keyframe=r["is_keyframe"],
                prev=r["prev"] or "",
                next=r["next"] or "",
            ))
        result.sort(key=lambda s: s.timestamp_us)
        return result

    def _load_sample_data(self) -> list[SampleData]:
        records = self._read_json("sample_data.json")
        result = []
        for r in records:
            result.append(SampleData(
                token=r["sample_data_token"],
                sample_token=r["sample_token"],
                channel=r["channel"],
                timestamp_us=r["timestamp_us"],
                file_path=r["file_path"],
                ego_pose_token=r["ego_pose_token"],
                calibrated_sensor_token=r["calibrated_sensor_token"],
                is_keyframe=r["is_keyframe"],
                width=r.get("width"),
                height=r.get("height"),
                prev=r["prev"] or "",
                next=r["next"] or "",
            ))
        return result

    def _load_annotations(self) -> list[Annotation]:
        records = self._read_json("annotation.json")
        result = []
        for r in records:
            bbox = r["bbox_3d"]
            t = bbox["translation"]
            s = bbox["size"]
            q = bbox["rotation"]
            vel = r.get("velocity")
            result.append(Annotation(
                token=r["annotation_token"],
                sample_token=r["sample_token"],
                instance_token=r["instance_token"],
                category=r["category"],
                translation=[t["x"], t["y"], t["z"]],
                size=[s["length"], s["width"], s["height"]],
                rotation=[q["qx"], q["qy"], q["qz"], q["qw"]],
                num_lidar_pts=r["num_lidar_pts"],
                visibility=str(r["visibility"]) if r["visibility"] is not None else "",
                velocity=[vel["vx"], vel["vy"], vel["vz"]] if vel else None,
                attributes=r.get("attributes", []),
                prev=r["prev"] or "",
                next=r["next"] or "",
                score=r.get("score"),
            ))
        return result

    def _load_instances(self) -> list[Instance]:
        records = self._read_json("instance.json")
        return [
            Instance(
                token=r["instance_token"],
                category=r["category"],
                num_annotations=r["num_annotations"],
                first_annotation_token=r["first_annotation_token"],
                last_annotation_token=r["last_annotation_token"],
            )
            for r in records
        ]

    # --- Public API ---

    @property
    def clip_dir(self) -> Path:
        """Absolute path to the clip directory."""
        return self._clip_dir

    @property
    def meta(self) -> ClipMeta:
        """Clip metadata (from meta.json)."""
        return self._meta

    @property
    def schema_version(self) -> str:
        """Shortcut for ``self.meta.schema_version`` — the X-4D format version this clip was written in."""
        return self._meta.schema_version

    @property
    def annotation_frame_id(self) -> str:
        """The vehicle-local frame_id annotations are stored in.

        Returns ``meta.annotation_frame_id`` if explicitly set (v0.6+ clips).
        Pre-v0.6 clips fall back to ``"base_link"`` — the per-sample ego frame
        all earlier loader code already assumed (``annotations_for_sample(frame="ego")``
        was a no-op transform).
        """
        if self._meta.annotation_frame_id is not None:
            return self._meta.annotation_frame_id
        return "base_link"

    @property
    def ego_pose_frame_id(self) -> str:
        """The frame_id whose pose ``ego_pose.json`` expresses in clip-local world.

        Returns ``meta.ego_pose_frame_id`` if explicitly set (v0.7+). Pre-v0.7
        clips fall back to ``annotation_frame_id`` — every X-4D and nuScenes
        clip pose is anchored to the same frame as its annotations.
        """
        if self._meta.ego_pose_frame_id is not None:
            return self._meta.ego_pose_frame_id
        return self.annotation_frame_id

    def frame_id_for_channel(self, channel: str) -> str:
        """Resolve the ROS frame_id of a sensor channel.

        Looks up ``meta.sensors[channel].frame_id`` (v0.6+). Falls back to the
        channel name itself for older clips, per the v0.4 ``channel ≡ frame_id``
        convention.
        """
        info = self._meta.sensors.get(channel)
        if info is not None and info.frame_id is not None:
            return info.frame_id
        return channel

    def require_schema_version(self, expected: "str | set[str]") -> None:
        """Raise ``SchemaVersionMismatch`` if the clip's schema_version isn't in ``expected``.

        Args:
            expected: a single version string (e.g. ``"0.5"``) or a set of accepted
                versions (e.g. ``{"0.4", "0.5"}``).

        Example::

            loader = ClipLoader(path)
            loader.require_schema_version("0.5")  # raises if not 0.5
        """
        actual = self._meta.schema_version
        if isinstance(expected, str):
            if actual != expected:
                raise SchemaVersionMismatch(actual, expected)
        else:
            if actual not in expected:
                raise SchemaVersionMismatch(actual, set(expected))

    @property
    def samples(self) -> list[Sample]:
        """All samples, sorted by timestamp."""
        return self._samples

    @property
    def sample_data(self) -> list[SampleData]:
        """All sample_data records across all channels."""
        return self._sample_data

    @property
    def ego_poses(self) -> list[EgoPose]:
        """All ego poses, sorted by timestamp."""
        return self._ego_poses

    @property
    def calibrated_sensors(self) -> list[CalibratedSensor]:
        """All calibrated sensor records (one per channel)."""
        return self._calibrated_sensors

    @property
    def annotations(self) -> list[Annotation]:
        """All annotations in their **native frame** (ego since v0.5; world for v0.4 clips).

        Use ``annotations_for_sample(token, frame=...)`` to request a specific frame.
        """
        return self._annotations

    @property
    def instances(self) -> list[Instance]:
        """All tracked object instances."""
        return self._instances

    def get(self, token: str) -> Any:
        """O(1) lookup by token across all entity types.

        Args:
            token: Any entity token (sample, sample_data, annotation, etc.).

        Returns:
            The entity object matching the token.

        Raises:
            KeyError: If the token is not found.
        """
        return self._token_index[token]

    def sample_data_for_channel(self, channel: str) -> list[SampleData]:
        """Get all sample_data for a sensor channel, sorted by timestamp.

        Args:
            channel: Sensor channel name (e.g. "LIDAR_TOP", "CAM_FRONT").

        Returns:
            List of SampleData records for this channel, time-ordered.
        """
        return self._sd_by_channel.get(channel, [])

    def sample_data_for_sample(self, sample_token: str) -> list[SampleData]:
        """Get all sample_data records for a sample (all channels at that timestamp).

        Args:
            sample_token: The sample token.

        Returns:
            List of SampleData records (one per channel) for this sample.
        """
        return self._sd_by_sample.get(sample_token, [])

    def annotations_for_sample(
        self,
        sample_token: str,
        frame: str = "ego",
    ) -> list[Annotation]:
        """All annotations for a given sample, transformed to the requested frame.

        Args:
            sample_token: The sample token.
            frame: Target coordinate frame. Accepted values:
                - ``"ego"`` / ``"base_link"`` (default): vehicle body frame.
                - ``"world"``: clip-local world frame (composes with ego_pose).
                - any sensor's ROS frame_id present in the calibration tree
                  (e.g. ``"LIDAR_TOP"``, ``"camera-front"``).
                - ``"sensor"`` is rejected (ambiguous — no single sensor implied).

        Returns:
            List of Annotation objects in the requested frame.
        """
        if frame == "sensor":
            raise ValueError(
                "frame='sensor' is ambiguous for annotations; pass an explicit "
                "frame_id (e.g. 'LIDAR_TOP') or use 'ego' / 'base_link' / 'world'."
            )

        anns = self._ann_by_sample.get(sample_token, [])
        if not anns:
            return anns

        T = self._transform_for_annotation_target(sample_token, frame)
        if T is None:
            return anns
        return [self._transform_annotation(a, T) for a in anns]

    def _transform_for_annotation_target(
        self, sample_token: str, target_frame: str
    ) -> Transform | None:
        """Build the transform from the clip's annotation frame to ``target_frame``.

        Returns ``None`` when the requested frame matches the storage frame
        (no transform needed).
        """
        ann_frame = self.annotation_frame_id  # e.g. "base_link" or "LIDAR_TOP"
        if target_frame == ann_frame:
            return None
        if target_frame in _EGO_ALIASES and ann_frame in _EGO_ALIASES:
            return None

        chain = self._get_transform_chain()
        # T(ego ← annotation_frame): identity if annotation frame is ego/base_link;
        # else look up the sensor whose frame_id == ann_frame.
        if ann_frame in _EGO_ALIASES:
            ego_from_ann = Transform.identity()
        else:
            ego_from_ann = chain.get_ego_from_frame_id(ann_frame)

        # T(target ← ego)
        if target_frame in _EGO_ALIASES:
            target_from_ego = Transform.identity()
        elif target_frame == "world":
            target_from_ego = self._get_world_from_ego_for_sample(sample_token)
        else:
            try:
                ego_from_target = chain.get_ego_from_frame_id(target_frame)
            except KeyError as e:
                raise ValueError(
                    f"Invalid frame {target_frame!r} for annotations: {e}"
                ) from None
            target_from_ego = ego_from_target.inverse

        return target_from_ego @ ego_from_ann

    def load_point_cloud(
        self,
        sd: SampleData,
        frame: FrameType = "sensor",
    ) -> np.ndarray:
        """Load point cloud binary file as (N, C) float32 array.

        Args:
            sd: The SampleData record for the point cloud.
            frame: Target coordinate frame.
                - "sensor" (default): raw sensor frame.
                - "ego": sensor → ego via calibrated_sensor extrinsics.
                - "world": sensor → ego → world via extrinsics + ego_pose.

        Returns:
            Point cloud as (N, C) float32 array with xyz in the requested frame.
        """
        if frame not in _VALID_FRAMES:
            raise ValueError(f"Invalid frame '{frame}', must be one of {_VALID_FRAMES}")

        sensor_info = self._meta.sensors[sd.channel]
        if sensor_info.point_format is None:
            raise ValueError(
                f"channel '{sd.channel}' has no point_format in meta.json — "
                f"cannot load as a point cloud (modality={sensor_info.modality})"
            )
        num_fields = sensor_info.point_format.num_fields

        path = self._clip_dir / sd.file_path
        raw = np.fromfile(str(path), dtype=np.float32)
        pts = raw.reshape(-1, num_fields)

        if frame == "sensor":
            return pts

        T = self.get_transform(sd, from_frame="sensor", to_frame=frame)
        pts[:, :3] = T.apply(pts[:, :3].astype(np.float64)).astype(np.float32)
        return pts

    def get_transform(
        self,
        sd: SampleData,
        from_frame: FrameType = "sensor",
        to_frame: FrameType = "world",
    ) -> Transform:
        """Get a Transform between coordinate frames for a given sample_data.

        Args:
            sd: The SampleData record (provides channel and ego_pose_token).
            from_frame: Source frame ("sensor", "ego", or "world").
            to_frame: Target frame ("sensor", "ego", or "world").

        Returns:
            Transform object. Use T.apply(points) or T.as_matrix for the 4x4 matrix.
        """
        if from_frame not in _VALID_FRAMES:
            raise ValueError(f"Invalid from_frame '{from_frame}', must be one of {_VALID_FRAMES}")
        if to_frame not in _VALID_FRAMES:
            raise ValueError(f"Invalid to_frame '{to_frame}', must be one of {_VALID_FRAMES}")

        if from_frame == to_frame:
            return Transform.identity()

        chain = self._get_transform_chain()
        ego_from_sensor = chain.get_ego_from_sensor(sd.channel)
        world_from_ego = chain.get_world_from_ego(sd.ego_pose_token)

        if from_frame == "sensor" and to_frame == "ego":
            return ego_from_sensor
        elif from_frame == "sensor" and to_frame == "world":
            return world_from_ego @ ego_from_sensor
        elif from_frame == "ego" and to_frame == "world":
            return world_from_ego
        elif from_frame == "ego" and to_frame == "sensor":
            return ego_from_sensor.inverse
        elif from_frame == "world" and to_frame == "ego":
            return world_from_ego.inverse
        else:  # world -> sensor
            return (world_from_ego @ ego_from_sensor).inverse

    def load_image_path(self, sd: SampleData) -> Path:
        """Get the absolute path to an image file.

        Does not load the image — returns the path for use with OpenCV, PIL, etc.

        Args:
            sd: The SampleData record for a camera channel.

        Returns:
            Absolute Path to the image file.
        """
        return self._clip_dir / sd.file_path

    # --- Private helpers ---

    def _get_transform_chain(self) -> TransformChain:
        """Lazily initialize and return a TransformChain."""
        if not hasattr(self, "_transform_chain"):
            self._transform_chain = TransformChain(self)
        return self._transform_chain

    def _get_world_from_ego_for_sample(self, sample_token: str) -> Transform:
        """Get the world_from_ego transform for a sample.

        Uses the ego_pose from the LiDAR sample_data, or the first sample_data
        if no LiDAR channel exists.
        """
        sds = self._sd_by_sample.get(sample_token, [])
        if not sds:
            raise ValueError(f"No sample_data found for sample {sample_token}")

        # Prefer LiDAR sample_data for the ego_pose
        cs_map = {cs.channel: cs for cs in self._calibrated_sensors}
        sd = next(
            (s for s in sds if cs_map.get(s.channel) and cs_map[s.channel].modality == "lidar"),
            sds[0],
        )
        chain = self._get_transform_chain()
        return chain.get_world_from_ego(sd.ego_pose_token)

    @staticmethod
    def _transform_annotation(ann: Annotation, T: Transform) -> Annotation:
        """Apply a rigid transform to an annotation's pose, returning a new Annotation."""
        new_translation = T.apply(ann.translation)
        new_rotation_mat = T.rotation @ Transform.from_quat(
            [0, 0, 0], ann.rotation
        ).rotation
        new_quat = rotation_matrix_to_quat(new_rotation_mat)

        new_velocity = None
        if ann.velocity is not None:
            new_velocity = T.rotation @ ann.velocity

        return replace(
            ann,
            translation=new_translation,
            rotation=np.array(new_quat),
            velocity=new_velocity,
        )
