# sitemapxml

`sitemapxml` is a powerful and fast command-line tool that extracts all URLs from a given XML sitemap, fetches each URL, and generates a comprehensive CSV report containing:
- Extract all sitemap URLs
- HTTP Status Code
- Title Tag
- Meta Description
- Content Length
- Canonical URL

## Installation

Install via pip:

```bash
pip install sitemapxml
```

## Usage

Simply run the CLI command and pass the URL of the sitemap:

```bash
sitemapxml https://example.com/sitemap.xml
```

This will automatically create a `sitemap_report.csv` file in your current directory containing all the extracted metrics. You can also specify an output file:

```bash
sitemapxml https://example.com/sitemap.xml -o my_report.csv
```

## Author
- Email: amalalex95@gmail.com
- LinkedIn: [Amal Alexander](https://www.linkedin.com/in/amal-alexander-305780131/)
