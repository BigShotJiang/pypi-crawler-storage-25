"""
sitemapxml package
Extract URLs from a sitemap and get metadata.
"""

__version__ = "0.1.0"
