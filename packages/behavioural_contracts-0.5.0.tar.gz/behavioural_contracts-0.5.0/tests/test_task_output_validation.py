"""validate_task_output, checklist fragments, and slim-install behaviour."""

from __future__ import annotations

import importlib

import pytest

from behavioural_contracts import normalize_task_contract_fragment, validate_task_output
from behavioural_contracts.exceptions import BehaviouralContractViolationError
from behavioural_contracts.response_output_validation import (
    response_contract_for_validate_task_output,
    validate_output_against_response_contract,
)


def test_package_import_validate_task_output():
    import behavioural_contracts as bc

    assert hasattr(bc, "validate_task_output")
    assert callable(bc.validate_task_output)
    assert hasattr(bc, "normalize_task_contract_fragment")
    assert callable(bc.normalize_task_contract_fragment)


def test_required_fields_missing():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["answer", "checklist"]},
        }
    }
    with pytest.raises(BehaviouralContractViolationError, match="Missing required field"):
        validate_task_output({"answer": "ok"}, spec)


def test_empty_output():
    spec = {"response_contract": {}}
    with pytest.raises(BehaviouralContractViolationError, match="empty"):
        validate_task_output({}, spec)


def test_empty_output_fragment_only_spec_still_guarded():
    """Vectra-style one fragment per call: falsy output fails before checklist rules."""
    fragment = {
        "applies_to": "checklist",
        "rules": [{"type": "min_word_count", "value": 1}],
    }
    with pytest.raises(BehaviouralContractViolationError, match="empty"):
        validate_task_output({}, fragment)


def test_vectra_yaml_rules_list_must_not_start_with_values():
    """OA/YAML: rules as list[dict] with type + values (not a dict-shaped rules object)."""
    fragment = {
        "applies_to": "checklist",
        "rules": [
            {"type": "must_not_start_with", "values": ["TODO:", "FIXME:"]},
        ],
    }
    validate_task_output({"checklist": ["Ship the feature after review"]}, fragment)
    with pytest.raises(BehaviouralContractViolationError) as exc:
        validate_task_output({"checklist": ["TODO: fix later"]}, fragment)
    assert "item [0]" in str(exc.value)
    assert "must_not_start_with" in str(exc.value)
    assert "TODO:" in str(exc.value)


def test_single_fragment_per_call_no_dummy_response_contract():
    """Loop body: validate_task_output(output, fragment) with only applies_to + rules."""
    fragment = {
        "applies_to": "checklist",
        "rules": {"min_word_count": 2},
    }
    validate_task_output({"checklist": ["a b"]}, fragment)
    with pytest.raises(BehaviouralContractViolationError, match="min_word_count"):
        validate_task_output({"checklist": ["x"]}, fragment)


def test_single_fragment_with_embedded_output_format():
    """Fragment dict may carry output_format (required_fields) alongside applies_to/rules."""
    spec = {
        "applies_to": "checklist",
        "output_format": {"required_fields": ["checklist"]},
        "rules": [{"type": "min_word_count", "value": 2}],
    }
    validate_task_output({"checklist": ["one two"]}, spec)
    with pytest.raises(BehaviouralContractViolationError, match="Missing required field"):
        validate_task_output({"summary": "only"}, spec)


def test_response_contract_for_validate_task_output_full_block_vs_fragment():
    full = {
        "response_contract": {
            "output_format": {"required_fields": ["x"]},
            "fragments": [{"applies_to": "checklist", "rules": {}}],
        }
    }
    assert response_contract_for_validate_task_output(full)["output_format"]["required_fields"] == [
        "x"
    ]
    frag = {"applies_to": "checklist", "rules": {"min_word_count": 1}}
    rc = response_contract_for_validate_task_output(frag)
    assert rc["fragments"] == [frag]
    assert "output_format" not in rc


def test_checklist_min_word_count_dict_rules():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["checklist"]},
            "fragments": [
                {"applies_to": "checklist", "rules": {"min_word_count": 3}},
            ],
        }
    }
    validate_task_output({"checklist": ["one two three"]}, spec)
    with pytest.raises(BehaviouralContractViolationError) as exc:
        validate_task_output({"checklist": ["a b"]}, spec)
    msg = str(exc.value)
    assert "item [0]" in msg
    assert "min_word_count" in msg


def test_checklist_second_item_index_in_error():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["checklist"]},
            "fragments": [{"applies_to": "checklist", "rules": {"min_word_count": 2}}],
        }
    }
    with pytest.raises(BehaviouralContractViolationError, match=r"item \[1\]"):
        validate_task_output({"checklist": ["ok here", "x"]}, spec)


def test_checklist_must_not_start_with_list_payload():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["checklist"]},
            "fragments": [
                {
                    "applies_to": "checklist",
                    "rules": {"must_not_start_with": ["TODO:", "FIXME:"]},
                }
            ],
        }
    }
    validate_task_output({"checklist": ["Implement the fix properly"]}, spec)
    with pytest.raises(BehaviouralContractViolationError) as exc:
        validate_task_output({"checklist": ["TODO: later"]}, spec)
    assert "must_not_start_with" in str(exc.value)
    assert "TODO:" in str(exc.value)


def test_checklist_must_contain_action_verb():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["checklist"]},
            "fragments": [
                {"applies_to": "checklist", "rules": {"must_contain_action_verb": True}},
            ],
        }
    }
    validate_task_output({"checklist": ["Verify the configuration matches prod"]}, spec)
    with pytest.raises(BehaviouralContractViolationError) as exc:
        validate_task_output({"checklist": ["The configuration is fine"]}, spec)
    assert "must_contain_action_verb" in str(exc.value)


def test_checklist_typed_rules_list():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["checklist"]},
            "fragments": [
                {
                    "applies_to": "checklist",
                    "rules": [
                        {"type": "min_word_count", "value": 2},
                        {"type": "must_contain_action_verb", "value": True},
                    ],
                }
            ],
        }
    }
    validate_task_output({"checklist": ["Review all access logs today"]}, spec)


def test_checklist_missing_key():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["summary"]},
            "fragments": [{"applies_to": "checklist", "rules": {"min_word_count": 1}}],
        }
    }
    with pytest.raises(BehaviouralContractViolationError, match="checklist"):
        validate_task_output({"summary": "ok"}, spec)


def test_decorator_path_uses_same_validation_empty_message():
    with pytest.raises(BehaviouralContractViolationError, match="Response is empty"):
        validate_output_against_response_contract(
            {}, {"output_format": {"required_fields": []}}, empty_message="Response is empty"
        )


def test_fragments_must_be_list_when_present():
    spec = {
        "response_contract": {
            "fragments": "not-a-list",
        }
    }
    with pytest.raises(BehaviouralContractViolationError, match="fragments must be a list"):
        validate_task_output({"x": 1}, spec)


def test_persistence_import_error_message_when_sqlalchemy_absent():
    try:
        import sqlalchemy  # noqa: F401
    except ImportError:
        with pytest.raises(ImportError, match=r"persistence"):
            importlib.import_module("behavioural_contracts.persistence")
    else:
        pytest.skip("sqlalchemy installed; optional-deps import path not exercised")


def test_declarative_response_contract_normalize_matches_legacy_and_validates():
    declarative = {
        "name": "response_schema_v1",
        "type": "response_contract",
        "description": "response schema",
        "version": "1",
        "config": {
            "output_format": {
                "type": "object",
                "required_fields": ["summary", "checklist"],
            },
        },
    }
    normalized = normalize_task_contract_fragment(declarative)
    assert normalized["name"] == "response_schema_v1"
    assert normalized["response_contract"]["output_format"]["required_fields"] == [
        "summary",
        "checklist",
    ]
    validate_task_output(
        {"summary": "ok", "checklist": ["Verify step one"]},
        declarative,
    )
    with pytest.raises(BehaviouralContractViolationError, match="Missing required field"):
        validate_task_output({"summary": "only"}, declarative)


def test_declarative_content_contract_checklist_rules():
    declarative = {
        "name": "no_generic_checklist_items",
        "type": "content_contract",
        "description": "no fluff",
        "applies_to": "checklist",
        "config": {
            "rules": [
                {"type": "must_contain_action_verb"},
                {"type": "min_word_count", "value": 5},
                {
                    "type": "must_not_start_with",
                    "values": ["consider", "think about", "understand"],
                },
            ],
        },
    }
    validate_task_output(
        {
            "checklist": [
                "Verify the dependency graph before merging any changes to production"
            ]
        },
        declarative,
    )
    with pytest.raises(BehaviouralContractViolationError, match="must_not_start_with"):
        validate_task_output(
            {"checklist": ["consider alternatives first please verify later"]},
            declarative,
        )


def test_legacy_shapes_pass_through_same_object():
    full = {
        "version": "1",
        "response_contract": {"output_format": {"required_fields": ["a"]}},
    }
    frag = {"applies_to": "checklist", "rules": {"min_word_count": 1}}
    assert normalize_task_contract_fragment(full) is full
    assert normalize_task_contract_fragment(frag) is frag


def test_declarative_unknown_type_pass_through():
    weird = {"type": "custom_rule", "config": {"x": 1}}
    assert normalize_task_contract_fragment(weird) is weird


def test_declarative_invalid_config_not_dict_pass_through():
    bad_rc = {"type": "response_contract", "config": "not-a-dict"}
    bad_cc = {"type": "content_contract", "applies_to": "checklist", "config": None}
    assert normalize_task_contract_fragment(bad_rc) is bad_rc
    assert normalize_task_contract_fragment(bad_cc) is bad_cc


def test_normalize_idempotent_after_declarative_response():
    d = {
        "type": "response_contract",
        "config": {"output_format": {"required_fields": ["k"]}},
    }
    once = normalize_task_contract_fragment(d)
    twice = normalize_task_contract_fragment(once)
    assert twice is once


def test_normalize_idempotent_after_declarative_content():
    d = {
        "type": "content_contract",
        "applies_to": "checklist",
        "config": {"rules": [{"type": "min_word_count", "value": 2}]},
    }
    once = normalize_task_contract_fragment(d)
    twice = normalize_task_contract_fragment(once)
    assert twice is once


def test_validate_task_output_no_double_wrap_declarative_content():
    d = {
        "type": "content_contract",
        "applies_to": "checklist",
        "config": {"rules": [{"type": "min_word_count", "value": 2}]},
    }
    spec = normalize_task_contract_fragment(d)
    rc = response_contract_for_validate_task_output(spec)
    assert rc["fragments"] == [spec]
    assert len(rc["fragments"]) == 1


def test_declarative_content_contract_rules_default_empty_when_not_list():
    d = {
        "type": "content_contract",
        "applies_to": "checklist",
        "config": {"rules": "broken"},
    }
    n = normalize_task_contract_fragment(d)
    assert n["rules"] == []
