"""validate_task_output_detailed, severity, and multi-fragment structured results."""

from __future__ import annotations

import json

import pytest

from behavioural_contracts import (
    coerce_fragment_severity,
    validate_task_output,
    validate_task_output_detailed,
)
from behavioural_contracts.exceptions import BehaviouralContractViolationError


def test_severity_high_on_fragment_result_and_violations():
    frag = {
        "applies_to": "checklist",
        "severity": "high",
        "rules": {"min_word_count": 99},
    }
    rows = validate_task_output_detailed({"checklist": ["nope"]}, frag)
    assert len(rows) == 1
    assert rows[0]["severity"] == "high"
    assert rows[0]["status"] == "fail"
    assert rows[0]["violations"]
    assert rows[0]["violations"][0]["severity"] == "high"
    assert rows[0]["violations"][0]["rule_type"] == "min_word_count"


def test_default_severity_medium_when_omitted():
    frag = {"applies_to": "checklist", "rules": {"min_word_count": 1}}
    assert coerce_fragment_severity({}) == "medium"
    rows = validate_task_output_detailed({"checklist": ["ok"]}, frag)
    assert rows[0]["severity"] == "medium"


def test_multiple_checklist_violations_one_fragment():
    frag = {
        "applies_to": "checklist",
        "name": "strict_list",
        "rules": {"min_word_count": 3},
    }
    rows = validate_task_output_detailed({"checklist": ["a b", "x y z w"]}, frag)
    assert len(rows) == 1
    assert rows[0]["contract"] == "strict_list"
    assert rows[0]["status"] == "fail"
    viols = rows[0]["violations"]
    assert len(viols) == 1
    assert viols[0]["item_index"] == 0
    rows2 = validate_task_output_detailed({"checklist": ["a", "b"]}, frag)
    v2 = rows2[0]["violations"]
    assert len(v2) == 2
    assert {v["item_index"] for v in v2} == {0, 1}


def test_nested_schema_plus_two_checklist_fragments_one_fails():
    spec = {
        "name": "parent_schema",
        "severity": "low",
        "response_contract": {
            "output_format": {"required_fields": ["checklist"]},
            "fragments": [
                {
                    "applies_to": "checklist",
                    "name": "passes",
                    "rules": {"min_word_count": 1},
                },
                {
                    "applies_to": "checklist",
                    "name": "needs_ten_words",
                    "severity": "high",
                    "rules": {"min_word_count": 10},
                },
            ],
        },
    }
    out = {"checklist": ["one", "two three four five six seven eight nine ten eleven"]}
    rows = validate_task_output_detailed(out, spec)
    assert len(rows) == 3
    assert rows[0]["contract"] == "parent_schema"
    assert rows[0]["severity"] == "low"
    assert rows[0]["status"] == "ok"
    assert rows[1]["contract"] == "passes"
    assert rows[1]["status"] == "ok"
    assert rows[2]["contract"] == "needs_ten_words"
    assert rows[2]["status"] == "fail"
    assert rows[2]["severity"] == "high"


def test_validate_task_output_raises_after_all_fragments_evaluated():
    spec = {
        "response_contract": {
            "output_format": {"required_fields": ["checklist"]},
            "fragments": [
                {"applies_to": "checklist", "name": "ok_frag", "rules": {"min_word_count": 1}},
                {"applies_to": "checklist", "name": "bad_frag", "rules": {"min_word_count": 100}},
            ],
        }
    }
    out = {"checklist": ["fine"]}
    rows = validate_task_output_detailed(out, spec)
    assert rows[0]["status"] == "ok"
    assert rows[1]["status"] == "ok"
    assert rows[2]["status"] == "fail"
    with pytest.raises(BehaviouralContractViolationError, match="BCE validation failed: .* failed"):
        validate_task_output(out, spec)
    with pytest.raises(BehaviouralContractViolationError, match="min_word_count"):
        validate_task_output(out, spec)


def test_list_contract_spec_two_top_level_fragments():
    specs = [
        {
            "type": "response_contract",
            "name": "shape",
            "config": {
                "output_format": {"required_fields": ["summary"]},
            },
        },
        {
            "applies_to": "checklist",
            "name": "cl",
            "rules": [{"type": "min_word_count", "value": 2}],
        },
    ]
    out = {"summary": "ok", "checklist": ["one two"]}
    rows = validate_task_output_detailed(out, specs)
    assert len(rows) == 2
    assert rows[0]["contract"] == "shape"
    assert rows[1]["contract"] == "cl"
    assert all(r["status"] == "ok" for r in rows)


def test_violations_json_serializable():
    rows = validate_task_output_detailed(
        {"checklist": ["x"]},
        {"applies_to": "checklist", "rules": {"min_word_count": 5}},
    )
    json.dumps(rows)


def test_legacy_stable_contract_label_without_name():
    spec = {"response_contract": {"output_format": {"required_fields": ["z"]}}}
    rows = validate_task_output_detailed({"z": 1}, spec)
    assert rows[0]["contract"] == "__response_schema__"
    assert rows[0]["severity"] == "medium"
