"""Behavioural Contracts - A Python package for enforcing behavioural contracts in AI agents."""

from .contract import behavioural_contract, validate_task_output
from .exceptions import BehaviouralContractViolationError
from .generator import format_contract, generate_contract
from .models import BehaviouralContractSpec, BehaviouralFlags
from .response_output_validation import (
    coerce_fragment_severity,
    normalize_task_contract_fragment,
    validate_task_output_detailed,
)

__version__ = "0.5.0"
__all__ = [
    "behavioural_contract",
    "coerce_fragment_severity",
    "normalize_task_contract_fragment",
    "validate_task_output",
    "validate_task_output_detailed",
    "generate_contract",
    "format_contract",
    "BehaviouralContractSpec",
    "BehaviouralFlags",
    "BehaviouralContractViolationError",
]
