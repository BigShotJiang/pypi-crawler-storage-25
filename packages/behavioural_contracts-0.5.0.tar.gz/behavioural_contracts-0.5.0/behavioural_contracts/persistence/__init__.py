"""
Data persistence layer for behavioral contracts.

Provides SQLite storage locally with easy migration path to Azure PostgreSQL.
Requires optional dependencies: pip install behavioural-contracts[persistence]
"""

try:
    from .database import Base, SessionLocal, engine, get_db, init_db
    from .metrics_store import MetricsStore
    from .models import AgentPerformance, ContractViolation, MetricRecord
except ImportError as e:
    raise ImportError(
        "behavioural_contracts.persistence requires optional dependencies. "
        "Install with: pip install behavioural-contracts[persistence]"
    ) from e

__all__ = [
    "Base",
    "SessionLocal",
    "engine",
    "get_db",
    "init_db",
    "MetricsStore",
    "ContractViolation",
    "MetricRecord",
    "AgentPerformance",
]
