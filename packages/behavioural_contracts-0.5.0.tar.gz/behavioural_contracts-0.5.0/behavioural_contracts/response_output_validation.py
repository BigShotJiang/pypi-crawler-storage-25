"""Shared validation for structured task output (OA runner + decorator path)."""

from __future__ import annotations

import re
from typing import Any

from .exceptions import BehaviouralContractViolationError

_DEFAULT_FRAGMENT_SEVERITY = "medium"
_ALLOWED_SEVERITIES = frozenset({"low", "medium", "high"})


def coerce_fragment_severity(frag: dict[str, Any]) -> str:
    """Return fragment severity: ``low`` | ``medium`` | ``high``.

    Defaults to **medium** when omitted or invalid (case-insensitive string).
    """
    raw = frag.get("severity")
    if isinstance(raw, str) and raw.lower() in _ALLOWED_SEVERITIES:
        return raw.lower()
    return _DEFAULT_FRAGMENT_SEVERITY


def normalize_task_contract_fragment(frag: dict[str, Any]) -> dict[str, Any]:
    """Normalize OA declarative fragments (``type`` + ``config``) to legacy BCE shapes.

    **Pass-through:** If ``frag`` is not a dict, or ``type`` is missing / not one of
    ``response_contract`` / ``content_contract``, or ``config`` is not a dict when
    required for those types, returns ``frag`` unchanged so legacy integrators keep
    working without double-wrapping.

    **response_contract:** ``{"type": "response_contract", "config": {...}}`` becomes
    ``{"response_contract": {...config}}`` plus optional ``name``, ``description``,
    ``version`` copied from the fragment root.

    **content_contract:** ``{"type": "content_contract", "applies_to": ..., "config": {...}}``
    becomes ``{"applies_to": ..., "rules": [...]}`` with ``rules`` taken from
    ``config["rules"]`` (empty list if missing or not a list), plus optional metadata
    keys as above.
    """
    if not isinstance(frag, dict):
        return frag

    frag_type = frag.get("type")
    config = frag.get("config")

    if frag_type == "response_contract":
        if not isinstance(config, dict):
            return frag
        out: dict[str, Any] = {"response_contract": dict(config)}
        for key in ("name", "description", "version", "severity"):
            if key in frag:
                out[key] = frag[key]
        return out

    if frag_type == "content_contract":
        if not isinstance(config, dict):
            return frag
        rules_raw = config.get("rules")
        rules: list[Any] = list(rules_raw) if isinstance(rules_raw, list) else []
        out = {
            "applies_to": frag.get("applies_to"),
            "rules": rules,
        }
        for key in ("name", "description", "version", "severity"):
            if key in frag:
                out[key] = frag[key]
        return out

    return frag


# Whole-word match for common imperative / action verbs in checklist items
_ACTION_VERB_PATTERN = re.compile(
    r"\b(?:"
    r"verify|implement|review|document|add|remove|fix|test|ensure|update|create|"
    r"delete|run|check|confirm|define|analyze|analyse|assess|complete|validate|"
    r"deploy|refactor|investigate|monitor|schedule|prepare|submit|approve|reject|"
    r"merge|build|install|configure|enable|disable|migrate|backup|restore|list|"
    r"identify|outline|draft|summarize|summarise|gather|collect|compare|evaluate|"
    r"obtain|record|trace|map|escalate"
    r")\b",
    re.IGNORECASE,
)


def _truthy(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() in ("true", "1", "yes", "on")
    if isinstance(value, int | float):
        return bool(value)
    return bool(value)


def _prefixes_from_payload(payload: Any) -> list[str]:
    if payload is None:
        return []
    if isinstance(payload, dict) and "values" in payload:
        return _prefixes_from_payload(payload["values"])
    if isinstance(payload, str):
        return [payload]
    if isinstance(payload, list):
        return [str(p) for p in payload]
    return [str(payload)]


def iter_normalized_rules(rules: Any) -> list[tuple[str, Any]]:
    """Flatten OA-style rules (dict, list of one-key dicts, or typed list) to (name, payload)."""
    if rules is None:
        return []
    if isinstance(rules, dict):
        return list(rules.items())
    if not isinstance(rules, list):
        return []
    out: list[tuple[str, Any]] = []
    for item in rules:
        if not isinstance(item, dict):
            continue
        if len(item) == 1:
            k, v = next(iter(item.items()))
            out.append((str(k), v))
            continue
        rule_type = item.get("type")
        if rule_type is None:
            continue
        t = str(rule_type)
        if t == "must_contain_action_verb":
            out.append(("must_contain_action_verb", item.get("value", True)))
        elif t == "min_word_count":
            out.append(("min_word_count", item.get("value")))
        elif t == "must_not_start_with":
            vals = item.get("values")
            if vals is None and "value" in item:
                vals = item.get("value")
            out.append(("must_not_start_with", vals))
    return out


def _checklist_rule_message(text: str, item_index: int, rule_name: str, payload: Any) -> str | None:
    """Return a human-readable failure message, or None if the rule passes."""
    stripped = text.strip()
    if rule_name == "must_contain_action_verb":
        if not _truthy(payload):
            return None
        if not _ACTION_VERB_PATTERN.search(stripped):
            return (
                f"Checklist item [{item_index}] rule must_contain_action_verb: "
                "text must contain an action verb"
            )
    elif rule_name == "min_word_count":
        if payload is None:
            return None
        min_words = int(payload)
        n = len(stripped.split())
        if n < min_words:
            return (
                f"Checklist item [{item_index}] rule min_word_count: "
                f"need at least {min_words} words, got {n}"
            )
    elif rule_name == "must_not_start_with":
        for prefix in _prefixes_from_payload(payload):
            if stripped.startswith(prefix):
                return (
                    f"Checklist item [{item_index}] rule must_not_start_with: "
                    f"must not start with {prefix!r}"
                )
    return None


def _apply_checklist_rule(text: str, item_index: int, rule_name: str, payload: Any) -> None:
    msg = _checklist_rule_message(text, item_index, rule_name, payload)
    if msg:
        raise BehaviouralContractViolationError(msg)


def _validate_one_checklist_item(text: Any, item_index: int, rules: Any) -> None:
    if not isinstance(text, str):
        raise BehaviouralContractViolationError(
            f"Checklist item [{item_index}] must be a string, got {type(text).__name__}"
        )
    for rule_name, payload in iter_normalized_rules(rules):
        _apply_checklist_rule(text, item_index, rule_name, payload)


def _violation_dict(
    rule_type: str,
    message: str,
    *,
    item_index: int | None = None,
    field: str | None = None,
    path: str | None = None,
    detail: dict[str, Any] | None = None,
    severity: str | None = None,
) -> dict[str, Any]:
    v: dict[str, Any] = {
        "rule_type": rule_type,
        "rule": rule_type,
        "message": message,
    }
    if item_index is not None:
        v["item_index"] = item_index
    if field is not None:
        v["field"] = field
    if path is not None:
        v["path"] = path
    if detail is not None:
        v["detail"] = detail
    if severity is not None:
        v["severity"] = severity
    return v


def collect_checklist_violations_for_fragment(
    output: dict[str, Any],
    fragment: dict[str, Any],
    *,
    severity: str | None = None,
) -> list[dict[str, Any]]:
    """Collect checklist violations without raising."""
    violations: list[dict[str, Any]] = []
    rules = fragment.get("rules")
    raw = output.get("checklist")
    if raw is None:
        violations.append(
            _violation_dict(
                "checklist_key_missing",
                "Missing key 'checklist' required for applies_to: checklist fragment",
                severity=severity,
            )
        )
        return violations
    if isinstance(raw, str):
        items: list[Any] = [raw]
    elif isinstance(raw, list):
        items = list(raw)
    else:
        violations.append(
            _violation_dict(
                "checklist_type_invalid",
                f"output['checklist'] must be a list or string, got {type(raw).__name__}",
                path="checklist",
                detail={"got_type": type(raw).__name__},
                severity=severity,
            )
        )
        return violations

    for idx, item in enumerate(items):
        if not isinstance(item, str):
            violations.append(
                _violation_dict(
                    "checklist_item_type",
                    f"Checklist item [{idx}] must be a string, got {type(item).__name__}",
                    item_index=idx,
                    detail={"expected": "string", "got_type": type(item).__name__},
                    severity=severity,
                )
            )
            continue
        for rule_name, payload in iter_normalized_rules(rules):
            msg = _checklist_rule_message(item, idx, rule_name, payload)
            if msg:
                violations.append(
                    _violation_dict(
                        rule_name,
                        msg,
                        item_index=idx,
                        path="checklist",
                        detail={"payload": payload},
                        severity=severity,
                    )
                )
    return violations


def _schema_contract_label(spec: dict[str, Any], spec_index: int, n_specs: int) -> str:
    name = spec.get("name")
    if isinstance(name, str) and name.strip():
        return name.strip()
    if n_specs > 1:
        return f"__response_schema___{spec_index}"
    return "__response_schema__"


def _checklist_contract_label(frag: dict[str, Any], index: int) -> str:
    name = frag.get("name")
    if isinstance(name, str) and name.strip():
        return name.strip()
    return f"fragment_checklist_{index}"


def _collect_schema_layer_violations(
    output: dict[str, Any],
    rc: dict[str, Any],
    *,
    empty_message: str = "Task output is empty",
) -> list[dict[str, Any]]:
    violations: list[dict[str, Any]] = []
    if not output:
        violations.append(_violation_dict("task_output_empty", empty_message))
        return violations

    output_format = rc.get("output_format") or {}
    required_fields = output_format.get("required_fields") or []
    for field in required_fields:
        if field not in output:
            violations.append(
                _violation_dict(
                    "required_field",
                    f"Missing required field: '{field}'",
                    field=field,
                    path=field,
                )
            )

    fr = rc.get("fragments")
    if fr is not None and not isinstance(fr, list):
        violations.append(
            _violation_dict(
                "invalid_fragments_config",
                "response_contract.fragments must be a list when present",
                path="fragments",
            )
        )
    return violations


def _fragment_result(
    contract: str,
    violations: list[dict[str, Any]],
    *,
    severity: str,
) -> dict[str, Any]:
    return {
        "contract": contract,
        "status": "fail" if violations else "ok",
        "severity": severity,
        "violations": violations,
    }


def _normalized_spec_list(contract_spec: dict[str, Any] | list[Any]) -> list[dict[str, Any]]:
    if isinstance(contract_spec, list):
        return [
            normalize_task_contract_fragment(x)
            for x in contract_spec
            if isinstance(x, dict)
        ]
    if isinstance(contract_spec, dict):
        return [normalize_task_contract_fragment(contract_spec)]
    return []


def _detailed_results_for_one_spec(
    output: dict[str, Any],
    spec: dict[str, Any],
    *,
    spec_index: int,
    n_specs: int,
    empty_message: str,
) -> list[dict[str, Any]]:
    rc = response_contract_for_validate_task_output(spec)
    fragments_raw = rc.get("fragments")

    merge_schema_and_checklist = (
        "response_contract" not in spec
        and isinstance(fragments_raw, list)
        and len(fragments_raw) == 1
        and isinstance(fragments_raw[0], dict)
        and fragments_raw[0].get("applies_to") == "checklist"
    )

    results: list[dict[str, Any]] = []

    if merge_schema_and_checklist:
        frag = fragments_raw[0]
        label = _checklist_contract_label(frag, 0)
        sev = coerce_fragment_severity(frag)
        violations = _collect_schema_layer_violations(output, rc, empty_message=empty_message)
        violations.extend(
            collect_checklist_violations_for_fragment(output, frag, severity=sev)
        )
        for v in violations:
            if "severity" not in v:
                v["severity"] = sev
        results.append(_fragment_result(label, violations, severity=sev))
        return results

    schema_label = _schema_contract_label(spec, spec_index, n_specs)
    schema_sev = coerce_fragment_severity(spec)
    schema_violations = _collect_schema_layer_violations(output, rc, empty_message=empty_message)
    for v in schema_violations:
        if "severity" not in v:
            v["severity"] = schema_sev
    results.append(_fragment_result(schema_label, schema_violations, severity=schema_sev))

    if not isinstance(fragments_raw, list):
        return results

    for fi, frag in enumerate(fragments_raw):
        if not isinstance(frag, dict) or frag.get("applies_to") != "checklist":
            continue
        clabel = _checklist_contract_label(frag, fi)
        csev = coerce_fragment_severity(frag)
        cviol = collect_checklist_violations_for_fragment(output, frag, severity=csev)
        for v in cviol:
            if "severity" not in v:
                v["severity"] = csev
        results.append(_fragment_result(clabel, cviol, severity=csev))

    return results


def validate_task_output_detailed(
    output: dict[str, Any],
    contract_spec: dict[str, Any] | list[Any],
    *,
    empty_message: str = "Task output is empty",
) -> list[dict[str, Any]]:
    """Validate task output and return **one result dict per validation unit** (JSON-serializable).

    Runs **all** units in one call; failures do not short-circuit. Use this for logging
    (e.g. ``bce.validated`` / ``bce.violation``); use :func:`validate_task_output` for
    strict raise-on-failure behaviour.

    **Contract spec:** A single dict (legacy or declarative) or a **list** of such dicts
    (e.g. multiple OA fragments). Each entry is normalized with
    :func:`normalize_task_contract_fragment` first.

    **Result shape** (each element)::

        {
            "contract": str,       # fragment ``name`` or stable id (e.g. ``__response_schema__``)
            "status": "ok" | "fail",
            "severity": "low" | "medium" | "high",  # default ``medium`` if omitted on fragment
            "violations": [
                {
                    "rule_type": str,
                    "rule": str,      # same as rule_type
                    "message": str,
                    "item_index": int | omitted,
                    "field": str | omitted,
                    "path": str | omitted,
                    "detail": dict | omitted,
                    "severity": str | omitted,  # copy of fragment severity when helpful
                },
                ...
            ],
        }

    **Units:** For a nested ``response_contract`` (or declarative ``response_contract``),
    one **schema** result (empty output, ``required_fields``, invalid ``fragments`` shape),
    then one result per ``applies_to: checklist`` fragment. For a **fragment-only** checklist
    spec (no nested ``response_contract``), schema and checklist checks are **merged** into
    a single result row so the same YAML node does not appear twice.

    **Severity:** Optional ``severity`` on each fragment (or declarative root); must be
    ``low``, ``medium``, or ``high`` (case-insensitive). Default when omitted: **medium**.
    """
    specs = _normalized_spec_list(contract_spec)
    if not specs:
        return []

    n = len(specs)
    all_results: list[dict[str, Any]] = []
    for i, spec in enumerate(specs):
        all_results.extend(
            _detailed_results_for_one_spec(
                output,
                spec,
                spec_index=i,
                n_specs=n,
                empty_message=empty_message,
            )
        )
    return all_results


def response_contract_for_validate_task_output(contract_spec: dict[str, Any]) -> dict[str, Any]:
    """Build the effective response_contract dict for validate_task_output.

    Accepts either a full behavioural_contract-style block with nested
    ``response_contract``, or a single OA/Vectra YAML fragment dict passed
    per call (``applies_to``, ``rules``, optionally ``output_format``) — no
    wrapper object required.
    """
    nested = contract_spec.get("response_contract")
    if isinstance(nested, dict):
        return nested

    if "applies_to" in contract_spec:
        rc: dict[str, Any] = {"fragments": [contract_spec]}
        inner_of = contract_spec.get("output_format")
        if isinstance(inner_of, dict):
            rc["output_format"] = inner_of
        return rc

    return {}


def validate_checklist_fragment(output: dict[str, Any], fragment: dict[str, Any]) -> None:
    """Validate output against a single fragment with applies_to: checklist."""
    rules = fragment.get("rules")
    raw = output.get("checklist")
    if raw is None:
        raise BehaviouralContractViolationError(
            "Missing key 'checklist' required for applies_to: checklist fragment"
        )
    if isinstance(raw, str):
        items: list[Any] = [raw]
    elif isinstance(raw, list):
        items = list(raw)
    else:
        raise BehaviouralContractViolationError(
            f"output['checklist'] must be a list or string, got {type(raw).__name__}"
        )
    for idx, item in enumerate(items):
        _validate_one_checklist_item(item, idx, rules)


def validate_output_against_response_contract(
    output: dict[str, Any],
    response_contract: dict[str, Any],
    *,
    empty_message: str = "Task output is empty",
) -> None:
    """Validate required_fields and checklist fragments; raises BehaviouralContractViolationError."""
    if not output:
        raise BehaviouralContractViolationError(empty_message)

    rc = response_contract or {}
    output_format = rc.get("output_format") or {}
    required_fields = output_format.get("required_fields") or []

    for field in required_fields:
        if field not in output:
            raise BehaviouralContractViolationError(f"Missing required field: '{field}'")

    fragments = rc.get("fragments")
    if not fragments:
        return
    if not isinstance(fragments, list):
        raise BehaviouralContractViolationError(
            "response_contract.fragments must be a list when present"
        )
    for frag in fragments:
        if not isinstance(frag, dict):
            continue
        if frag.get("applies_to") != "checklist":
            continue
        validate_checklist_fragment(output, frag)
