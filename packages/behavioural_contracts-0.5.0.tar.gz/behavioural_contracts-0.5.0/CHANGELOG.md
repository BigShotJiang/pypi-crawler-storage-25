# Changelog

## [0.5.0] — 2026-03-28

### Added

- **`validate_task_output_detailed(output, contract_spec) -> list[dict]`** — Structured, JSON-serializable validation results: one row per **schema** unit and per **checklist** fragment. Each row includes `contract` (fragment `name` or stable id such as `__response_schema__` / `fragment_checklist_0`), `status` (`ok` | `fail`), **`severity`** (`low` | `medium` | `high`), and `violations` (objects with `rule_type`, `rule`, `message`, optional `item_index`, `field`, `path`, `detail`, optional `severity`). All units are evaluated in one call (no short-circuit).
- **`coerce_fragment_severity(frag)`** — Returns normalized severity; default **medium** when omitted or invalid.
- Optional **`severity`** on declarative fragments is preserved through **`normalize_task_contract_fragment`** (alongside `name`, `description`, `version`).

### Changed

- **`validate_task_output`** now delegates to the detailed helper, evaluates **all** fragments/units, then raises **`BehaviouralContractViolationError`** if any row has `status == "fail"`. The message is `BCE validation failed: N contract(s) failed. First: <first violation message>` (substring still contains the original rule text for existing `pytest.raises(..., match=...)` patterns).
- **`validate_task_output`** accepts **`contract_spec` as either a dict or a list** of fragment dicts (same as detailed API).

## [0.4.0] — 2026-03-28

### Added

- **`normalize_task_contract_fragment`**: Converts OA **declarative** fragments (`type` + `config`) into the legacy shapes `validate_task_output` already understands. Supported types:
  - `response_contract` — `config` becomes nested `response_contract`; optional `name`, `description`, `version` preserved on the wrapper dict.
  - `content_contract` — `applies_to` from the fragment root, `rules` from `config.rules` (default `[]` if missing or not a list); same optional metadata.
- Unknown `type`, missing `type`, or `config` not a dict for those types: **pass-through** (same object) so legacy fragments are unchanged and integrators do not double-wrap.
- **`validate_task_output`** applies normalization automatically once per call. Export: `from behavioural_contracts import normalize_task_contract_fragment` for hosts that normalize lists ahead of time.

## [0.3.0] — 2026-03-28

### Changed

- **`validate_task_output` contract shape**: Accepts a **single OA/Vectra YAML fragment** per call (dict with `applies_to` / `rules`, as returned when YAML loads a list of fragment objects) without wrapping it in `response_contract`. Optional `output_format` on the same dict is applied for `required_fields`. Empty task output (`{}` or other falsy dict) still fails first with the same empty-output error as before—no silent skip.

### Added

- **`response_contract_for_validate_task_output`**: Helper used by `validate_task_output` to normalize full-block vs single-fragment specs (in `response_output_validation`).

## [0.2.0] — 2026-03-28

### Breaking changes

- **Default install** no longer bundles SQLAlchemy, Alembic, psycopg2, python-dotenv, FastAPI, or Uvicorn. Code that imported persistence or relied on those packages being present **must** install extras explicitly:
  - `pip install behavioural-contracts[persistence]` — database layer (`behavioural_contracts.persistence`)
  - `pip install behavioural-contracts[api]` — FastAPI / Uvicorn (demos or apps)

### Changed

- **Slimmer default install**: Core dependencies are now `pydantic` and `typing-extensions` only. Database drivers and web stack moved to optional extras (see above).
- Importing `behavioural_contracts.persistence` without the persistence extra raises a clear `ImportError` with install instructions.

### Added

- **Checklist contract rules** in `validate_task_output` (and the decorator validation path via shared helpers): `response_contract.fragments` entries with `applies_to: checklist` can define `rules` such as `must_contain_action_verb`, `min_word_count`, and `must_not_start_with`. Rules may be a **mapping** (YAML dict) or a **list of rule objects** with `type` and `value` / `values` keys, matching typical OA/YAML parsing. Each string in `output["checklist"]` is validated; failures raise `BehaviouralContractViolationError` with item index and rule name.
