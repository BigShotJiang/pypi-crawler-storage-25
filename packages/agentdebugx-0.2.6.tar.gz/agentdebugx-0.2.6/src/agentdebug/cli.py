"""Command line entry points.

v0.1 commands:

* ``agentdebug analyze`` — run an analyzer on a trajectory JSON file.
* ``agentdebug list``    — list trace IDs in a store.
* ``agentdebug show``    — pretty-print a trajectory by ID.
* ``agentdebug judge``   — run :class:`LLMJudgeAnalyzer` against a stored trajectory.
* ``agentdebug doctor``  — report which adapters/integrations are available.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Optional, Sequence

from agentdebug.analyzers import HeuristicAnalyzer
from agentdebug.attribution import AllAtOnceAttributor, HeuristicAttributor
from agentdebug.models import DiagnosticReport, model_to_json, trajectory_from_json
from agentdebug.recovery import FixProposal, ReflexionSuggestion
from agentdebug.storage import JsonlTraceStore, SQLiteTraceStore, TraceStore


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog='agentdebug')
    sub = parser.add_subparsers(dest='command', required=True)

    p_analyze = sub.add_parser('analyze', help='Analyze a trajectory JSON file')
    p_analyze.add_argument('trajectory', help='Path to an AgentTrajectory JSON file')
    p_analyze.add_argument('--out', help='Optional output path for the report')
    p_analyze.add_argument(
        '--suggest',
        action='store_true',
        help='Also emit Reflexion-style retry suggestions for each finding',
    )
    p_analyze.add_argument(
        '--traceback',
        action='store_true',
        help='Render a Python-traceback-style cascade view instead of JSON',
    )
    p_analyze.add_argument(
        '--no-color', action='store_true',
        help='Disable ANSI colors in --traceback output (default: auto)',
    )

    p_list = sub.add_parser('list', help='List trace IDs in a store')
    _add_store_args(p_list)

    p_show = sub.add_parser('show', help='Print a stored trajectory as JSON')
    _add_store_args(p_show)
    p_show.add_argument('trace_id', help='Trace ID to print')

    p_judge = sub.add_parser(
        'judge',
        help='Run the LLM judge against a trajectory JSON file or stored trace',
    )
    p_judge.add_argument(
        'target',
        help='Path to a trajectory JSON file, or a trace_id when --store is set',
    )
    _add_store_args(p_judge, required=False)
    p_judge.add_argument(
        '--model',
        default=os.environ.get('AGENTDEBUG_LLM_MODEL', 'gemini-3-flash'),
    )
    p_judge.add_argument('--base-url', dest='base_url')
    p_judge.add_argument('--api-key', dest='api_key')
    p_judge.add_argument('--out', help='Optional output path for the report')
    p_judge.add_argument(
        '--attribute',
        action='store_true',
        help='Also run AllAtOnceAttributor on the judge findings',
    )

    sub.add_parser('doctor', help='Report adapter and integration availability')

    p_serve = sub.add_parser('serve', help='Run the local FastAPI dashboard')
    _add_store_args(p_serve, required=True)
    p_serve.add_argument('--host', default='127.0.0.1')
    p_serve.add_argument('--port', type=int, default=7777)

    # ---- Hub subcommands ----
    p_hub = sub.add_parser('hub', help='Error Hub — package, push, pull bundles')
    hub_sub = p_hub.add_subparsers(dest='hub_command', required=True)

    p_hub_push = hub_sub.add_parser('push', help='Publish a trace bundle')
    p_hub_push.add_argument('trace_id', help='Trace ID to bundle')
    p_hub_push.add_argument('--to', required=True,
                            help='Hub spec: local:/path | git:<remote>[#<path>] | hf:<repo_id>[#<path>]')
    _add_store_args(p_hub_push, required=True)
    p_hub_push.add_argument('--no-scrub', action='store_true',
                            help='DANGER: skip PII/secret scrubbing (only for trusted internal hubs)')
    p_hub_push.add_argument('--license', default='CC-BY-4.0')
    p_hub_push.add_argument('--contributor', default=None,
                            help='Optional contributor identifier (email, handle)')
    p_hub_push.add_argument('--contributor-org', default=None)
    p_hub_push.add_argument('--message', default=None,
                            help='Optional commit message (git/hf only)')

    p_hub_pull = hub_sub.add_parser('pull', help='Fetch a bundle from a Hub')
    p_hub_pull.add_argument('spec', help='Hub spec (see hub push)')
    p_hub_pull.add_argument('--bundle', required=True, help='Bundle ID')
    p_hub_pull.add_argument('--into', default='.agentdebug/hub_pulls')

    p_hub_list = hub_sub.add_parser('list', help='List bundles available at a Hub')
    p_hub_list.add_argument('spec')
    p_hub_list.add_argument('--limit', type=int, default=50)

    # ---- Integrations subcommands ----
    p_int = sub.add_parser('integrations', help='Generate host-runtime integrations')
    int_sub = p_int.add_subparsers(dest='int_command', required=True)

    p_skill = int_sub.add_parser('skill', help='Materialize a Claude Code Skill')
    p_skill.add_argument('--target', default='~/.claude/skills',
                         help='Destination directory (default: ~/.claude/skills)')
    p_skill.add_argument('--name', default='agentdebug')

    p_mc = int_sub.add_parser(
        'openhands-microagent',
        help='Write an OpenHands microagent contract file',
    )
    p_mc.add_argument('--target', default='.openhands/microagents')
    p_mc.add_argument('--name', default='agentdebug')

    # ---- DeepDebug subcommand ----
    p_deep = sub.add_parser(
        'deep',
        help='Iterative multi-turn DeepDebug analysis on a trajectory or stored trace',
    )
    p_deep.add_argument('target',
                        help='Path to a trajectory JSON or a stored trace_id')
    _add_store_args(p_deep, required=False)
    p_deep.add_argument(
        '--model',
        default=os.environ.get('AGENTDEBUG_LLM_MODEL', 'gemini-3-flash'),
    )
    p_deep.add_argument('--base-url', dest='base_url')
    p_deep.add_argument('--api-key', dest='api_key')
    p_deep.add_argument('--out', help='Optional output path for the report JSON')
    p_deep.add_argument(
        '--traceback', action='store_true',
        help='Render a Python-traceback-style cascade view to stdout',
    )
    p_deep.add_argument('--no-color', action='store_true')

    args = parser.parse_args(argv)
    if args.command == 'analyze':
        return _cmd_analyze(args)
    if args.command == 'list':
        return _cmd_list(args)
    if args.command == 'show':
        return _cmd_show(args)
    if args.command == 'judge':
        return _cmd_judge(args)
    if args.command == 'doctor':
        return _cmd_doctor()
    if args.command == 'serve':
        return _cmd_serve(args)
    if args.command == 'hub':
        return _cmd_hub(args)
    if args.command == 'integrations':
        return _cmd_integrations(args)
    if args.command == 'deep':
        return _cmd_deep(args)
    return 1


# ---------------- subcommands ----------------


def _cmd_analyze(args: argparse.Namespace) -> int:
    trajectory_path = Path(args.trajectory)
    trajectory = trajectory_from_json(trajectory_path.read_text(encoding='utf-8'))
    report = HeuristicAnalyzer().analyze(trajectory)
    if args.traceback:
        from agentdebug.traceback import format_traceback

        text = format_traceback(
            report, trajectory, use_color=not args.no_color and sys.stdout.isatty()
        )
        _emit(text, args.out)
        return 0
    rendered = model_to_json(report, indent=2)
    if args.suggest:
        proposals = ReflexionSuggestion().suggest(trajectory, report)
        rendered = _augment_with_suggestions(rendered, report, proposals)
    _emit(rendered, args.out)
    return 0


def _cmd_list(args: argparse.Namespace) -> int:
    store = _resolve_store(args)
    if store is None:
        print('No store configured. Use --store-sqlite or --store-jsonl.', file=sys.stderr)
        return 2
    for trace_id in store.list_traces():
        print(trace_id)
    return 0


def _cmd_show(args: argparse.Namespace) -> int:
    store = _resolve_store(args)
    if store is None:
        print('No store configured. Use --store-sqlite or --store-jsonl.', file=sys.stderr)
        return 2
    trajectory = store.load_trajectory(args.trace_id)
    if trajectory is None:
        print(f'Unknown trace_id: {args.trace_id}', file=sys.stderr)
        return 3
    print(model_to_json(trajectory, indent=2))
    return 0


def _cmd_judge(args: argparse.Namespace) -> int:
    from agentdebug.judges import LLMJudgeAnalyzer
    from agentdebug.llm import OpenAICompatClient

    # Load trajectory: file path first, fall back to store lookup.
    trajectory_path = Path(args.target)
    if trajectory_path.exists():
        trajectory = trajectory_from_json(
            trajectory_path.read_text(encoding='utf-8')
        )
    else:
        store = _resolve_store(args)
        if store is None:
            print(
                f'Could not find {args.target!r} on disk and no store configured.',
                file=sys.stderr,
            )
            return 2
        loaded = store.load_trajectory(args.target)
        if loaded is None:
            print(f'Unknown trace_id: {args.target}', file=sys.stderr)
            return 3
        trajectory = loaded

    base_url = args.base_url or os.environ.get('AGENTDEBUG_LLM_BASE_URL')
    api_key = args.api_key or os.environ.get('AGENTDEBUG_LLM_API_KEY')
    if not base_url or not api_key:
        print(
            'LLM judge requires --base-url and --api-key (or '
            'AGENTDEBUG_LLM_BASE_URL / AGENTDEBUG_LLM_API_KEY).',
            file=sys.stderr,
        )
        return 4

    llm = OpenAICompatClient(base_url=base_url, api_key=api_key, model=args.model)
    report = LLMJudgeAnalyzer(llm=llm).analyze(trajectory)
    rendered = model_to_json(report, indent=2)
    if args.attribute:
        blame = AllAtOnceAttributor(llm=llm).attribute(trajectory, report.findings)
        rendered = _augment_with_blame(rendered, blame)
    if args.traceback:
        from agentdebug.traceback import format_traceback

        rendered = (
            rendered
            + '\n\n# === AgentTraceback ===\n'
            + format_traceback(
                report, trajectory,
                use_color=not args.no_color and sys.stdout.isatty(),
            )
        )
    _emit(rendered, args.out)
    return 0


def _cmd_serve(args: argparse.Namespace) -> int:
    store = _resolve_store(args)
    if store is None:
        print(
            'serve requires --store-sqlite or --store-jsonl.', file=sys.stderr
        )
        return 2
    try:
        from agentdebug.ui import serve

        serve(store, host=args.host, port=args.port)
    except ImportError as exc:
        print(str(exc), file=sys.stderr)
        return 5
    return 0


def _cmd_hub(args: argparse.Namespace) -> int:
    from agentdebug.analyzers import HeuristicAnalyzer
    from agentdebug.hub import (
        Bundle,
        backend_from_spec,
        build_manifest,
    )
    from agentdebug.hub.scrub import SCRUBBER_VERSION, scrub_trajectory

    sub = args.hub_command
    if sub == 'push':
        store = _resolve_store(args)
        if store is None:
            print('hub push requires --store-sqlite or --store-jsonl', file=sys.stderr)
            return 2
        trajectory = store.load_trajectory(args.trace_id)
        if trajectory is None:
            print(f'unknown trace_id: {args.trace_id}', file=sys.stderr)
            return 3
        scrubbed_flag = not args.no_scrub
        scrubber_version = None
        if scrubbed_flag:
            report = scrub_trajectory(trajectory)
            scrubber_version = SCRUBBER_VERSION
            print(
                f'scrubbed: visited={report.fields_visited} '
                f'replacements={dict(report.replacements)}',
                file=sys.stderr,
            )
        # Re-run rule analyzer post-scrub for a deterministic report.
        diag = HeuristicAnalyzer().analyze(trajectory)
        # build_manifest is in agentdebug.hub.bundle
        from agentdebug.hub.bundle import build_manifest as _bm

        manifest = _bm(
            trajectory,
            report=diag,
            license=args.license,
            contributor=args.contributor,
            contributor_org=args.contributor_org,
            scrubbed=scrubbed_flag,
            scrubber_version=scrubber_version,
        )
        bundle = Bundle(manifest=manifest, trajectory=trajectory, report=diag)
        backend = backend_from_spec(args.to)
        try:
            ref = backend.push(bundle, message=args.message)
        except Exception as exc:
            print(f'hub push failed: {exc}', file=sys.stderr)
            return 4
        print(f'pushed bundle {manifest.bundle_id} -> {ref}')
        return 0
    if sub == 'pull':
        from pathlib import Path

        backend = backend_from_spec(args.spec)
        into = Path(args.into)
        into.mkdir(parents=True, exist_ok=True)
        try:
            path = backend.pull(args.bundle, into=into)
        except Exception as exc:
            print(f'hub pull failed: {exc}', file=sys.stderr)
            return 4
        print(f'pulled {args.bundle} -> {path}')
        return 0
    if sub == 'list':
        backend = backend_from_spec(args.spec)
        try:
            ids = backend.list_bundles(limit=args.limit)
        except Exception as exc:
            print(f'hub list failed: {exc}', file=sys.stderr)
            return 4
        for bid in ids:
            print(bid)
        return 0
    return 1


def _cmd_integrations(args: argparse.Namespace) -> int:
    from agentdebug.integrations import (
        OpenHandsMicroagentContract,
        build_skill_bundle,
        write_skill_bundle,
    )

    if args.int_command == 'skill':
        bundle = build_skill_bundle(name=args.name)
        path = write_skill_bundle(bundle, target_dir=Path(args.target))
        print(f'wrote Claude Skill -> {path}')
        return 0
    if args.int_command == 'openhands-microagent':
        contract = OpenHandsMicroagentContract(name=args.name)
        path = contract.write(Path(args.target))
        print(f'wrote OpenHands microagent -> {path}')
        return 0
    return 1


def _cmd_deep(args: argparse.Namespace) -> int:
    from agentdebug.deep import DeepDebugAnalyzer
    from agentdebug.llm import OpenAICompatClient

    base_url = args.base_url or os.environ.get('AGENTDEBUG_LLM_BASE_URL')
    api_key = args.api_key or os.environ.get('AGENTDEBUG_LLM_API_KEY')
    if not base_url or not api_key:
        print(
            'deep requires --base-url and --api-key (or '
            'AGENTDEBUG_LLM_BASE_URL / AGENTDEBUG_LLM_API_KEY).',
            file=sys.stderr,
        )
        return 4

    trajectory_path = Path(args.target)
    if trajectory_path.exists():
        trajectory = trajectory_from_json(
            trajectory_path.read_text(encoding='utf-8')
        )
    else:
        store = _resolve_store(args)
        if store is None:
            print(
                f'no file at {args.target!r} and no store configured',
                file=sys.stderr,
            )
            return 2
        loaded = store.load_trajectory(args.target)
        if loaded is None:
            print(f'unknown trace_id: {args.target}', file=sys.stderr)
            return 3
        trajectory = loaded

    llm = OpenAICompatClient(
        base_url=base_url, api_key=api_key, model=args.model,
        default_max_tokens=8192, timeout=180.0,
    )
    result = DeepDebugAnalyzer(llm=llm).analyze(trajectory)
    out_text = model_to_json(result.report, indent=2)
    print('--- DeepDebug rounds ---', file=sys.stderr)
    for r in result.rounds:
        print(f'  {r.name:>20} {r.duration_ms:>6} ms', file=sys.stderr)
    _emit(out_text, args.out)
    if args.traceback:
        from agentdebug.traceback import format_traceback

        text = format_traceback(
            result.report, trajectory,
            use_color=not args.no_color and sys.stdout.isatty(),
        )
        print()
        print(text)
    return 0


def _cmd_doctor() -> int:
    statuses = []
    try:
        from agentdebug.adapters.langgraph import LangGraphAdapter

        statuses.append(LangGraphAdapter().instrument(_dummy_debugger()))
    except Exception as exc:  # pragma: no cover - defensive
        statuses.append(_status('langgraph', False, str(exc)))
    try:
        from agentdebug.adapters.crewai import CrewAIAdapter

        statuses.append(CrewAIAdapter().instrument(_dummy_debugger()))
    except Exception as exc:  # pragma: no cover - defensive
        statuses.append(_status('crewai', False, str(exc)))
    try:
        from agentdebug.adapters.otel import OTelExportAdapter

        statuses.append(OTelExportAdapter().instrument(_dummy_debugger()))
    except Exception as exc:  # pragma: no cover - defensive
        statuses.append(_status('otel', False, str(exc)))
    from agentdebug.adapters.raw import RawLoopAdapter

    statuses.append(RawLoopAdapter().instrument(_dummy_debugger()))
    for s in statuses:
        flag = '✓' if s.implemented else '✗'
        print(f'  {flag}  {s.framework:<10} {s.notes}')
    return 0


# ---------------- helpers ----------------


def _add_store_args(p: argparse.ArgumentParser, *, required: bool = False) -> None:
    group = p.add_mutually_exclusive_group(required=required)
    group.add_argument('--store-sqlite', help='Path to a SQLite trace store')
    group.add_argument('--store-jsonl', help='Path to a JSONL trace store')


def _resolve_store(args: argparse.Namespace) -> Optional[TraceStore]:
    if getattr(args, 'store_sqlite', None):
        return SQLiteTraceStore(args.store_sqlite)
    if getattr(args, 'store_jsonl', None):
        return JsonlTraceStore(args.store_jsonl)
    return None


def _emit(rendered: str, out_path: Optional[str]) -> None:
    if out_path is None:
        print(rendered)
        return
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(rendered + '\n', encoding='utf-8')


def _augment_with_suggestions(
    rendered: str, report: DiagnosticReport, proposals: list[FixProposal]
) -> str:
    proposals_block = '\n'.join(
        f'-- proposal {p.proposal_id} ({p.recoverer_id}) --\n{p.suggestion_text}'
        for p in proposals
    )
    return rendered + (
        '\n\n# === Reflexion suggestions ===\n' + proposals_block
        if proposals_block
        else ''
    )


def _augment_with_blame(rendered: str, blame_result: object) -> str:
    return rendered + '\n\n# === Attribution ===\n' + repr(blame_result)


def _status(framework: str, implemented: bool, notes: str) -> object:
    from agentdebug.adapters.base import AdapterStatus

    return AdapterStatus(framework=framework, implemented=implemented, notes=notes)


def _dummy_debugger() -> object:
    from agentdebug.recorder import AgentDebug
    from agentdebug.storage import JsonlTraceStore

    return AgentDebug(store=JsonlTraceStore('.agentdebug/_doctor.jsonl'))


if __name__ == '__main__':
    raise SystemExit(main())
