"""Minimal FastAPI dashboard for AgentDebugX.

Endpoints:

* ``GET  /``                       - single-page HTML console.
* ``GET  /api/v1/traces``          - list trace IDs in the store.
* ``GET  /api/v1/traces/{tid}``    - fetch a trajectory + freshly analyzed report.
* ``GET  /api/v1/traces/{tid}/raw``- raw trajectory JSON.
* ``GET  /api/v1/taxonomy``        - list seed failure modes.
* ``GET  /healthz``                - liveness.

The server is intentionally tiny and built on a no-build (vanilla JS) frontend
so it ships with the wheel and runs without `npm`.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, cast

from agentdebug.analyzers import HeuristicAnalyzer
from agentdebug.models import AgentTrajectory, DiagnosticReport, model_to_json
from agentdebug.storage import JsonlTraceStore, SQLiteTraceStore, TraceStore
from agentdebug.taxonomy import SEED_FAILURE_MODES

LOG = logging.getLogger('agentdebug.ui')


def _to_dict(model: Any) -> Dict[str, Any]:
    """Pydantic v1/v2 compatible serialization to dict."""
    if hasattr(model, 'model_dump'):
        return cast(Dict[str, Any], model.model_dump(mode='json'))
    return cast(Dict[str, Any], json.loads(model.json()))


def build_app(store: TraceStore) -> Any:
    try:
        from fastapi import FastAPI, HTTPException
        from fastapi.responses import HTMLResponse, JSONResponse
    except ImportError as exc:  # pragma: no cover - exercised in docs
        raise ImportError(
            'AgentDebugX UI requires `fastapi` and `uvicorn`. '
            'Install with `pip install agentdebugx[ui]`.'
        ) from exc

    app = FastAPI(
        title='AgentDebugX',
        description='Local debug console for agent trajectories.',
        version='0.1.0',
    )

    @app.get('/healthz')
    def healthz() -> Dict[str, str]:
        return {'status': 'ok'}

    @app.get('/api/v1/traces')
    def list_traces() -> Dict[str, List[str]]:
        return {'traces': store.list_traces()}

    @app.get('/api/v1/traces/{trace_id}')
    def get_trace(trace_id: str) -> Dict[str, Any]:
        trajectory = store.load_trajectory(trace_id)
        if trajectory is None:
            raise HTTPException(status_code=404, detail=f'unknown trace_id: {trace_id}')
        report = HeuristicAnalyzer().analyze(trajectory)
        return {
            'trajectory': _to_dict(trajectory),
            'report': _to_dict(report),
        }

    @app.get('/api/v1/traces/{trace_id}/raw')
    def get_trace_raw(trace_id: str) -> JSONResponse:
        trajectory = store.load_trajectory(trace_id)
        if trajectory is None:
            raise HTTPException(status_code=404, detail=f'unknown trace_id: {trace_id}')
        return JSONResponse(content=_to_dict(trajectory))

    @app.get('/api/v1/taxonomy')
    def get_taxonomy() -> Dict[str, Any]:
        return {
            'modes': [_to_dict(m) for m in SEED_FAILURE_MODES.values()],
        }

    @app.get('/', response_class=HTMLResponse)
    def index() -> str:
        bootstrap: Dict[str, Any] = {'traces': [], 'selected': None}
        trace_ids = store.list_traces()
        bootstrap['traces'] = trace_ids
        if trace_ids:
            trajectory = store.load_trajectory(trace_ids[0])
            if trajectory is not None:
                report = HeuristicAnalyzer().analyze(trajectory)
                bootstrap['selected'] = {
                    'trajectory': _to_dict(trajectory),
                    'report': _to_dict(report),
                }
        payload = json.dumps(bootstrap).replace('</', '<\\/')
        return _INDEX_HTML.replace('__BOOTSTRAP_JSON__', payload)

    return app


def serve(
    store: TraceStore,
    *,
    host: str = '127.0.0.1',
    port: int = 7777,
) -> None:
    try:
        import uvicorn
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            'AgentDebugX UI requires `uvicorn`. '
            'Install with `pip install agentdebugx[ui]`.'
        ) from exc
    app = build_app(store)
    LOG.info('Serving AgentDebugX console at http://%s:%s', host, port)
    uvicorn.run(app, host=host, port=port, log_level='warning')


def store_from_path(path: str) -> TraceStore:
    """Heuristic: ``.sqlite`` → SQLiteTraceStore; everything else → JSONL."""
    if path.endswith(('.sqlite', '.db')):
        return SQLiteTraceStore(path)
    return JsonlTraceStore(path)


# Single-file HTML console. Plain DOM + fetch; no build step required.
_INDEX_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>AgentDebugX Console</title>
<style>
  :root {
    color-scheme: dark;
    --bg:#101111;
    --panel:#171818;
    --panel2:#1d1f1f;
    --line:#303333;
    --fg:#f1f2ee;
    --muted:#a8ada6;
    --muted2:#747b73;
    --cyan:#6bd6d8;
    --green:#6fcf97;
    --amber:#f0b75a;
    --rose:#ff6b7a;
    --violet:#b7a4ff;
    --paper:#e9e3d4;
    --shadow:0 18px 48px rgba(0,0,0,.28);
  }
  * { box-sizing:border-box; }
  html, body {
    margin:0; min-height:100%; background:var(--bg); color:var(--fg);
    font-family:Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    letter-spacing:0;
  }
  body { overflow:hidden; }
  .shell { display:grid; grid-template-columns:320px minmax(0,1fr); height:100vh; }
  .sidebar {
    border-right:1px solid var(--line); background:#141515; padding:18px 16px;
    display:flex; flex-direction:column; gap:16px; min-width:0;
  }
  .brand { display:flex; align-items:center; justify-content:space-between; gap:12px; }
  .brand-title { font-size:18px; line-height:1; font-weight:760; letter-spacing:0; }
  .brand-sub { margin-top:5px; color:var(--muted); font-size:12px; }
  .mark {
    width:34px; height:34px; border:1px solid #3d4241; border-radius:8px;
    display:grid; place-items:center; color:var(--cyan); font-weight:800;
    background:#1d2020;
  }
  .side-section-title {
    color:var(--muted2); text-transform:uppercase; font-size:11px;
    font-weight:760; letter-spacing:0; margin:8px 0 8px;
  }
  .run-list { list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:8px; }
  .run {
    width:100%; text-align:left; cursor:pointer; border:1px solid #292d2c;
    background:var(--panel); border-radius:8px; padding:11px 12px;
    color:var(--fg); transition:background .12s ease, border-color .12s ease;
  }
  .run:hover { background:#202322; }
  .run.active { border-color:var(--cyan); background:#1b2424; }
  .run-id { font-family:ui-monospace, SFMono-Regular, Consolas, monospace;
    font-size:11px; color:var(--fg); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .run-meta { margin-top:7px; display:flex; align-items:center; gap:7px; flex-wrap:wrap; }
  .chip {
    display:inline-flex; align-items:center; height:22px; padding:0 8px;
    border:1px solid #353938; border-radius:999px; font-size:11px;
    color:var(--muted); background:#181a1a; white-space:nowrap;
  }
  .chip.bad { color:#ffd5d9; border-color:#6d3038; background:#2a191d; }
  .chip.good { color:#c9f6d9; border-color:#2e5d43; background:#16231b; }
  .chip.warn { color:#ffe4b8; border-color:#6d552d; background:#2a2115; }
  .chip.cyan { color:#c5fbfc; border-color:#2f6061; background:#172526; }
  .side-note {
    margin-top:auto; border:1px solid #2d3130; border-radius:8px; padding:12px;
    color:var(--muted); background:#171818; font-size:12px; line-height:1.45;
  }
  .workspace { min-width:0; height:100vh; overflow:auto; }
  .topbar {
    position:sticky; top:0; z-index:2; backdrop-filter:blur(12px);
    background:rgba(16,17,17,.84); border-bottom:1px solid var(--line);
    display:flex; align-items:center; justify-content:space-between; gap:16px;
    padding:15px 22px;
  }
  .crumb { color:var(--muted); font-size:12px; }
  .top-actions { display:flex; gap:8px; align-items:center; }
  .button {
    border:1px solid #373b3a; border-radius:8px; background:#1a1c1c; color:var(--fg);
    height:32px; padding:0 11px; font-size:12px; display:inline-flex;
    align-items:center; justify-content:center; gap:7px; cursor:pointer;
    font-family:inherit; white-space:nowrap;
  }
  .button:hover { border-color:#4b5250; background:#202323; }
  .button.primary { border-color:#356568; color:#d8fdff; background:#173033; }
  .content { padding:22px; max-width:1440px; margin:0 auto; }
  .hero {
    display:grid; grid-template-columns:minmax(0,1.6fr) minmax(320px,.9fr); gap:14px;
    margin-bottom:14px;
  }
  .panel {
    background:var(--panel); border:1px solid #2d3130; border-radius:8px;
    box-shadow:var(--shadow); min-width:0;
  }
  .hero-main { padding:18px; }
  .kicker { color:var(--cyan); font-size:11px; text-transform:uppercase;
    letter-spacing:0; font-weight:800; }
  h1 { margin:8px 0 8px; font-size:26px; line-height:1.15; letter-spacing:0; }
  .goal { color:var(--muted); font-size:13px; line-height:1.45; max-width:92ch; }
  .meta-line { display:flex; gap:8px; flex-wrap:wrap; margin-top:15px; }
  .stats { display:grid; grid-template-columns:repeat(2, minmax(0,1fr)); gap:10px; padding:12px; }
  .stat { background:var(--panel2); border:1px solid #303434; border-radius:8px; padding:12px; }
  .stat-label { color:var(--muted2); font-size:11px; text-transform:uppercase; letter-spacing:0; }
  .stat-value { margin-top:7px; font-size:22px; line-height:1; font-weight:760; }
  .stat-value.bad { color:var(--rose); }
  .stat-value.warn { color:var(--amber); }
  .stat-value.good { color:var(--green); }
  .stat-value.cyan { color:var(--cyan); }
  .layout { display:grid; grid-template-columns:minmax(0,1.35fr) minmax(360px,.8fr); gap:14px; }
  .panel-head {
    padding:13px 14px; border-bottom:1px solid #2d3130;
    display:flex; align-items:center; justify-content:space-between; gap:10px;
  }
  .panel-title { font-size:13px; font-weight:760; }
  .panel-body { padding:14px; }
  .timeline { display:flex; flex-direction:column; gap:10px; }
  .trace-legend {
    display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); gap:10px;
    margin-bottom:10px;
  }
  .legend-cell {
    border:1px solid #303434; background:#171919; border-radius:8px; padding:10px;
    min-width:0;
  }
  .legend-label { color:var(--muted2); font-size:10px; text-transform:uppercase; letter-spacing:0; }
  .legend-title { margin-top:4px; font-size:13px; font-weight:760; }
  .event {
    display:grid; grid-template-columns:58px minmax(0,1fr); gap:12px;
    border:1px solid #2c302f; border-radius:8px; background:#1a1c1c; padding:12px;
  }
  .event.root { border-color:#73582b; background:#211b12; }
  .step-index {
    width:42px; height:42px; border-radius:8px; display:grid; place-items:center;
    background:#111313; border:1px solid #363a39; font-family:ui-monospace, monospace;
    color:var(--paper); font-size:13px; font-weight:760;
  }
  .event.root .step-index { border-color:#77592a; color:#ffe0ad; }
  .event-title { display:flex; align-items:center; justify-content:space-between; gap:10px; }
  .event-agent { font-size:14px; font-weight:760; }
  .event-type { color:var(--muted); font-size:12px; font-family:ui-monospace, monospace; }
  .trace-pair {
    margin-top:9px; display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr);
    gap:8px;
  }
  .lane {
    min-width:0; border:1px solid #2b2f2e; background:#151717; border-radius:8px;
    padding:10px;
  }
  .lane.agent-lane { border-color:#33403f; }
  .lane.debug-lane { border-color:#3a3430; background:#181713; }
  .event.root .lane.debug-lane { border-color:#80612d; background:#211a11; }
  .lane-head { display:flex; align-items:center; justify-content:space-between; gap:8px; }
  .lane-label {
    color:var(--muted2); font-size:10px; text-transform:uppercase; letter-spacing:0;
  }
  .lane-title { margin-top:6px; color:#f1f2ee; font-size:13px; line-height:1.3; font-weight:720; }
  .lane-copy { margin-top:7px; color:#d9ddd5; font-size:12px; line-height:1.45; overflow-wrap:anywhere; }
  .lane-meta { margin-top:9px; display:flex; gap:6px; flex-wrap:wrap; }
  .trace-link {
    margin-top:8px; color:var(--muted); font-size:11px; line-height:1.4;
    font-family:ui-monospace, SFMono-Regular, Consolas, monospace;
  }
  .event-grid { margin-top:8px; display:grid; grid-template-columns:1fr 1fr; gap:8px; }
  .field { min-width:0; border:1px solid #2b2f2e; background:#151717; border-radius:8px; padding:9px; }
  .field-label { color:var(--muted2); font-size:10px; text-transform:uppercase; letter-spacing:0; }
  .field-value { margin-top:5px; color:#d9ddd5; font-size:12px; line-height:1.4;
    overflow-wrap:anywhere; }
  .field.error { border-color:#66333a; background:#211619; }
  .field.error .field-value { color:#ffd7da; }
  .findings { display:flex; flex-direction:column; gap:10px; }
  .finding { border:1px solid #303434; border-radius:8px; padding:12px; background:#1a1c1c; }
  .finding-title { display:flex; align-items:center; justify-content:space-between; gap:10px; }
  .mode { font-family:ui-monospace, SFMono-Regular, Consolas, monospace; font-size:12px; color:var(--cyan); }
  .confidence { color:var(--paper); font-size:12px; font-weight:760; }
  .suggestion { margin-top:9px; color:#d9ddd5; font-size:12px; line-height:1.45; }
  .evidence { margin-top:9px; color:var(--muted); font-size:11px; line-height:1.45; }
  .rail { display:flex; flex-direction:column; gap:14px; }
  .root-card { border-left:4px solid var(--amber); }
  .root-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px; margin-top:10px; }
  .mini { border:1px solid #303434; border-radius:8px; padding:9px; background:#171919; min-width:0; }
  .mini-label { color:var(--muted2); font-size:10px; text-transform:uppercase; letter-spacing:0; }
  .mini-value { margin-top:6px; font-size:13px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .flow { display:grid; gap:8px; }
  .flow-item {
    display:grid; grid-template-columns:26px minmax(0,1fr); gap:9px; align-items:start;
    color:#d9ddd5; font-size:12px;
  }
  .flow-dot {
    width:22px; height:22px; border-radius:7px; display:grid; place-items:center;
    background:#202525; border:1px solid #38403e; color:var(--cyan); font-size:11px;
  }
  .empty { color:var(--muted); padding:38px 18px; text-align:center; }
  code { font-family:ui-monospace, SFMono-Regular, Consolas, monospace; font-size:11px; }
  @media (max-width: 980px) {
    body { overflow:auto; }
    .shell, .hero, .layout { grid-template-columns:1fr; height:auto; }
    .sidebar { border-right:0; border-bottom:1px solid var(--line); }
    .workspace { height:auto; }
    .topbar { position:static; }
    .trace-legend, .trace-pair { grid-template-columns:1fr; }
  }
  @media (max-width: 640px) {
    .topbar { display:grid; grid-template-columns:1fr; align-items:start; padding:14px 16px; }
    .top-actions { width:100%; display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); }
    .button { width:100%; min-width:0; padding:0 8px; overflow:hidden; text-overflow:ellipsis; }
    .content { padding:22px 16px; }
    h1 { font-size:27px; line-height:1.1; }
    .stats { grid-template-columns:repeat(2,minmax(0,1fr)); }
    .root-grid { grid-template-columns:1fr; }
    .event { grid-template-columns:46px minmax(0,1fr); padding:10px; }
    .step-index { width:38px; height:38px; }
    .event-grid { grid-template-columns:1fr; }
  }
</style>
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="brand">
      <div>
        <div class="brand-title">AgentDebugX</div>
        <div class="brand-sub">Local agent failure console</div>
      </div>
      <div class="mark">AX</div>
    </div>
    <div>
      <div class="side-section-title">Recent Runs</div>
      <ul class="run-list" id="trace-list"></ul>
    </div>
    <div class="side-note">
      Error Hub ready. Scrub locally, package a failure bundle, then publish to
      a Git or Hugging Face dataset backend for team review.
    </div>
  </aside>
  <section class="workspace">
    <div class="topbar">
      <div>
        <div class="crumb">Project / checkout-agent / debug session</div>
        <div class="brand-sub" id="trace-count">Loading traces</div>
      </div>
      <div class="top-actions">
        <button class="button" id="analyze-btn" type="button">Analyze</button>
        <button class="button" id="export-btn" type="button">Bundle</button>
        <button class="button primary" id="hub-btn" type="button">Hub</button>
      </div>
    </div>
    <div class="content" id="detail">
      <div class="empty">Select a trace from the left.</div>
    </div>
  </section>
</div>
<script>
const BOOTSTRAP = __BOOTSTRAP_JSON__;
let CURRENT_TRACE_ID = null;
let CURRENT_TRACE_DATA = null;
async function api(path) {
  const r = await fetch(path);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
function fmt(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}
function truncate(s, n) { s = fmt(s); return s.length > n ? s.slice(0, n) + '...' : s; }
function escapeHtml(s) {
  return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'})[c]);
}
function familyClass(family) {
  if (family === 'system' || family === 'action') return 'bad';
  if (family === 'planning' || family === 'verification') return 'warn';
  if (family === 'memory' || family === 'multiagent') return 'cyan';
  return 'good';
}
function eventProblem(ev) {
  const payload = (fmt(ev.error) + ' ' + fmt(ev.output) + ' ' + fmt(ev.metadata)).toLowerCase();
  return Boolean(ev.error || payload.includes('missing context') || payload.includes('premature') || payload.includes('loop') || payload.includes('handoff'));
}
async function loadTraceList(selectFirst) {
  const data = await api('/api/v1/traces');
  const ul = document.getElementById('trace-list');
  ul.innerHTML = '';
  document.getElementById('trace-count').textContent = data.traces.length + ' trace' + (data.traces.length === 1 ? '' : 's') + ' in local store';
  data.traces.forEach((tid, idx) => {
    const li = document.createElement('li');
    li.className = 'run';
    li.innerHTML = '<div class="run-id">' + escapeHtml(tid) + '</div>' +
      '<div class="run-meta"><span class="chip bad">failed</span><span class="chip">SQLite</span></div>';
    li.dataset.tid = tid;
    li.onclick = () => { selectTrace(tid, li); };
    ul.appendChild(li);
    if (idx === 0 && selectFirst) selectTrace(tid, li);
  });
  if (data.traces.length === 0) {
    document.getElementById('detail').innerHTML = '<div class="empty">No traces in store.</div>';
  }
}
function renderTraceList(traceIds, selectedId) {
  const ul = document.getElementById('trace-list');
  ul.innerHTML = '';
  document.getElementById('trace-count').textContent = traceIds.length + ' trace' + (traceIds.length === 1 ? '' : 's') + ' in local store';
  traceIds.forEach((tid) => {
    const li = document.createElement('li');
    li.className = 'run' + (tid === selectedId ? ' active' : '');
    li.innerHTML = '<div class="run-id">' + escapeHtml(tid) + '</div>' +
      '<div class="run-meta"><span class="chip bad">failed</span><span class="chip">SQLite</span></div>';
    li.dataset.tid = tid;
    li.onclick = () => { selectTrace(tid, li); };
    ul.appendChild(li);
  });
}
async function selectTrace(tid, li) {
  document.querySelectorAll('.run').forEach(el => el.classList.remove('active'));
  li.classList.add('active');
  CURRENT_TRACE_ID = tid;
  document.getElementById('detail').innerHTML = '<div class="empty">Loading trace...</div>';
  try {
    const data = await api('/api/v1/traces/' + encodeURIComponent(tid));
    CURRENT_TRACE_DATA = data;
    renderTrace(data.trajectory, data.report);
  } catch (e) {
    document.getElementById('detail').innerHTML = '<div class="empty">' + escapeHtml(e) + '</div>';
  }
}
function renderTrace(traj, report) {
  const events = traj.events || [];
  const findings = report.findings || [];
  const rootId = report.root_cause_event_id;
  const alignmentEvents = events.filter(ev => ev.step_index !== null && ev.step_index !== undefined);
  const families = [...new Set(findings.map(f => f.failure_mode?.family).filter(Boolean))];
  const errorEvents = events.filter(eventProblem).length;
  const rootEvent = events.find(ev => ev.event_id === rootId) || {};
  let html = '';
  html += '<div class="hero">';
  html += '<div class="panel hero-main">';
  html += '<div class="kicker">Failure analysis report</div>';
  html += '<h1>' + escapeHtml(traj.goal || traj.trace_id) + '</h1>';
  html += '<div class="goal">' + escapeHtml(report.summary || 'No diagnostic summary available.') + '</div>';
  html += '<div class="meta-line"><span class="chip cyan">' + escapeHtml(traj.framework || 'unknown framework') + '</span>';
  html += '<span class="chip">' + escapeHtml(traj.trace_id) + '</span>';
  for (const family of families) html += '<span class="chip ' + familyClass(family) + '">' + escapeHtml(family) + '</span>';
  html += '</div></div>';
  html += '<div class="panel stats">';
  html += stat('Events', events.length, 'cyan');
  html += stat('Findings', findings.length, findings.length ? 'bad' : 'good');
  html += stat('Root step', report.root_cause_step_index ?? '-', 'warn');
  html += stat('Error events', errorEvents, errorEvents ? 'bad' : 'good');
  html += '</div></div>';

  html += '<div class="layout">';
  html += '<div class="panel"><div class="panel-head"><div class="panel-title">Agent Trace + Error Trace Alignment</div><span class="chip">native span -> diagnosis</span></div><div class="panel-body">';
  html += '<div class="trace-legend"><div class="legend-cell"><div class="legend-label">Agent native trace</div><div class="legend-title">What the agent logged, thought, called, or observed.</div></div>';
  html += '<div class="legend-cell"><div class="legend-label">AgentDebugX error trace</div><div class="legend-title">Normalized failure signal, attribution, and repair hint for human review.</div></div></div>';
  html += '<div class="timeline">';
  for (const ev of alignmentEvents) html += renderEvent(ev, ev.event_id === rootId, findingForEvent(findings, ev.event_id));
  html += '</div></div></div>';

  html += '<div class="rail">';
  html += '<div class="panel root-card"><div class="panel-head"><div class="panel-title">Root Cause Hypothesis</div><span class="chip warn">rank 1</span></div><div class="panel-body">';
  html += '<div class="goal">' + escapeHtml(report.summary || 'No root cause found.') + '</div>';
  html += '<div class="root-grid">';
  html += mini('Agent', report.root_cause_agent || rootEvent.agent_name || '-');
  html += mini('Step', report.root_cause_step_index ?? '-');
  html += mini('Event', truncate(rootId || '-', 16));
  html += '</div></div></div>';

  html += '<div class="panel"><div class="panel-head"><div class="panel-title">Detected Findings</div><span class="chip">' + findings.length + ' mode' + (findings.length === 1 ? '' : 's') + '</span></div><div class="panel-body"><div class="findings">';
  if (findings.length === 0) html += '<div class="empty">No findings.</div>';
  for (const f of findings) html += renderFinding(f);
  html += '</div></div></div>';

  html += '<div class="panel" id="error-hub-flow"><div class="panel-head"><div class="panel-title">Use Case Flow</div><span class="chip cyan">Error Hub</span></div><div class="panel-body"><div class="flow">';
  html += flow(1, 'Capture trajectory from the running agent with the lightweight recorder or adapter.');
  html += flow(2, 'Diagnose the trace, localize the likely root cause, and generate recovery suggestions.');
  html += flow(3, 'Scrub secrets and PII, package a reproducible error bundle, and publish to Git or Hugging Face.');
  html += flow(4, 'Pull similar failures from the hub to guide future detectors, tests, and recovery policies.');
  html += '</div></div></div>';
  html += '</div></div>';

  document.getElementById('detail').innerHTML = html;
}
function stat(label, value, klass) {
  return '<div class="stat"><div class="stat-label">' + escapeHtml(label) + '</div><div class="stat-value ' + klass + '">' + escapeHtml(value) + '</div></div>';
}
function mini(label, value) {
  return '<div class="mini"><div class="mini-label">' + escapeHtml(label) + '</div><div class="mini-value">' + escapeHtml(value) + '</div></div>';
}
function flow(n, text) {
  return '<div class="flow-item"><div class="flow-dot">' + n + '</div><div>' + escapeHtml(text) + '</div></div>';
}
function findingForEvent(findings, eventId) {
  return (findings || []).find(f => f.event_id === eventId) || null;
}
function nativeTrace(ev) {
  const meta = ev.metadata || {};
  const native = meta.native_trace || {};
  const fallback = truncate(ev.output || ev.input || ev.error || 'Recorded framework event.', 180);
  const tags = Array.isArray(native.tags) ? native.tags : [ev.module || 'module', ev.event_type || 'event'];
  return {
    span: native.span_id || ev.event_id || '-',
    title: native.title || ((ev.agent_name || 'agent') + ' / ' + (ev.event_type || 'event')),
    body: native.message || fallback,
    tags: tags,
    state: native.state || native.tool || ''
  };
}
function errorTrace(ev, finding) {
  const meta = ev.metadata || {};
  const overlay = meta.error_trace || {};
  const mode = overlay.failure_mode || finding?.failure_mode?.mode_id || (eventProblem(ev) ? 'unclassified.signal' : 'context');
  const title = overlay.title || finding?.failure_mode?.name || (eventProblem(ev) ? 'Failure signal detected' : 'Context event');
  const body = overlay.human_readout || finding?.suggestion || (eventProblem(ev)
    ? 'AgentDebugX keeps this event in the failure trace because it contains an error, lost-context signal, or invalid state transition.'
    : 'No local failure signal; shown to preserve the causal path for the reviewer.');
  const severity = overlay.severity || (finding ? 'high' : (eventProblem(ev) ? 'medium' : 'context'));
  const repair = overlay.repair || finding?.suggestion || '';
  return {mode, title, body, severity, repair};
}
function severityClass(severity) {
  if (severity === 'critical' || severity === 'high') return 'bad';
  if (severity === 'medium') return 'warn';
  if (severity === 'context') return '';
  return 'cyan';
}
function renderEvent(ev, isRoot, finding) {
  const native = nativeTrace(ev);
  const debug = errorTrace(ev, finding);
  let html = '<div class="event ' + (isRoot ? 'root' : '') + '">';
  html += '<div class="step-index">' + escapeHtml(ev.step_index ?? '-') + '</div>';
  html += '<div><div class="event-title"><div><div class="event-agent">' + escapeHtml(ev.agent_name || 'agent') + '</div>';
  html += '<div class="event-type">' + escapeHtml(ev.event_type || '') + ' / ' + escapeHtml(ev.module || 'module') + '</div></div>';
  html += isRoot ? '<span class="chip warn">root candidate</span>' : (eventProblem(ev) ? '<span class="chip bad">signal</span>' : '<span class="chip good">ok</span>');
  html += '</div><div class="trace-pair">';
  html += '<div class="lane agent-lane"><div class="lane-head"><div class="lane-label">Agent native trace</div><span class="chip">' + escapeHtml(native.span) + '</span></div>';
  html += '<div class="lane-title">' + escapeHtml(native.title) + '</div>';
  html += '<div class="lane-copy">' + escapeHtml(native.body) + '</div>';
  html += '<div class="lane-meta">' + (native.tags || []).map(t => '<span class="chip">' + escapeHtml(t) + '</span>').join('') + '</div>';
  if (native.state) html += '<div class="trace-link">' + escapeHtml(native.state) + '</div>';
  html += '</div>';
  html += '<div class="lane debug-lane"><div class="lane-head"><div class="lane-label">AgentDebugX error trace</div><span class="chip ' + severityClass(debug.severity) + '">' + escapeHtml(debug.severity) + '</span></div>';
  html += '<div class="lane-title">' + escapeHtml(debug.title) + '</div>';
  html += '<div class="lane-copy">' + escapeHtml(debug.body) + '</div>';
  html += '<div class="lane-meta"><span class="chip ' + (finding ? familyClass(finding.failure_mode?.family) : '') + '">' + escapeHtml(debug.mode) + '</span></div>';
  if (debug.repair) html += '<div class="trace-link">repair: ' + escapeHtml(debug.repair) + '</div>';
  html += '</div></div><div class="event-grid">';
  html += field('Input', truncate(ev.input, 132), false);
  html += field('Output', truncate(ev.output, 132), false);
  html += field('Error', truncate(ev.error, 132), Boolean(ev.error));
  html += field('Event ID', truncate(ev.event_id, 34), false);
  html += '</div></div></div>';
  return html;
}
function downloadJson(filename, value) {
  const blob = new Blob([JSON.stringify(value, null, 2)], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
function bindTopActions() {
  document.getElementById('analyze-btn').onclick = () => {
    const active = document.querySelector('.run.active');
    if (CURRENT_TRACE_ID && active) selectTrace(CURRENT_TRACE_ID, active);
  };
  document.getElementById('export-btn').onclick = () => {
    if (!CURRENT_TRACE_DATA) return;
    const name = (CURRENT_TRACE_ID || 'trace') + '.agentdebugx.report.json';
    downloadJson(name, CURRENT_TRACE_DATA);
  };
  document.getElementById('hub-btn').onclick = () => {
    const flow = document.getElementById('error-hub-flow');
    if (flow) flow.scrollIntoView({behavior: 'smooth', block: 'start'});
  };
}
function field(label, value, isError) {
  return '<div class="field ' + (isError ? 'error' : '') + '"><div class="field-label">' + escapeHtml(label) + '</div><div class="field-value">' + escapeHtml(value || '-') + '</div></div>';
}
function renderFinding(f) {
  const mode = f.failure_mode || {};
  const family = mode.family || '';
  let html = '<div class="finding">';
  html += '<div class="finding-title"><div><div class="mode">' + escapeHtml(mode.mode_id || '') + '</div>';
  html += '<div class="event-type">' + escapeHtml(family) + ' / step ' + escapeHtml(f.step_index ?? '-') + ' / ' + escapeHtml(f.agent_name || '-') + '</div></div>';
  html += '<div class="confidence">' + (typeof f.confidence === 'number' ? Math.round(f.confidence * 100) + '%' : '-') + '</div></div>';
  if (f.suggestion) html += '<div class="suggestion">' + escapeHtml(f.suggestion) + '</div>';
  if ((f.evidence || []).length) html += '<div class="evidence">Evidence: ' + escapeHtml((f.evidence || []).join('; ')) + '</div>';
  html += '</div>';
  return html;
}
if (BOOTSTRAP && BOOTSTRAP.traces) {
  const selected = BOOTSTRAP.selected ? BOOTSTRAP.selected.trajectory.trace_id : null;
  renderTraceList(BOOTSTRAP.traces, selected);
  if (BOOTSTRAP.selected) {
    CURRENT_TRACE_ID = selected;
    CURRENT_TRACE_DATA = BOOTSTRAP.selected;
    renderTrace(BOOTSTRAP.selected.trajectory, BOOTSTRAP.selected.report);
  } else {
    document.getElementById('detail').innerHTML = '<div class="empty">No traces in store.</div>';
  }
}
bindTopActions();
loadTraceList(!(BOOTSTRAP && BOOTSTRAP.selected));
</script>
</body>
</html>
"""
