"""CrewAI adapter — subscribe to ``crewai_event_bus`` and record into AgentDebug.

CrewAI's runtime emits typed events through a process-global event bus
(``crewai.events.crewai_event_bus``). The bus has ~50 event types covering
crew lifecycle, task lifecycle, agent execution, LLM calls, tool usage,
flows, memory operations, A2A messages, MCP calls, knowledge ops, and
guardrails. This adapter subscribes to the subset that matters for
debugging and translates each into an :class:`agentdebug.models.AgentEvent`.

Why a class (not a free-function listener)? CrewAI's documented gotcha is
that listeners must be instantiated at module level OR explicitly kept
alive; otherwise the GC reclaims them before the bus fires. We hide that
by exposing a context-manager friendly :class:`CrewAIBridge` that holds
the listener instance for its lifetime.

Usage::

    from agentdebug import AgentDebug, SQLiteTraceStore
    from agentdebug.adapters.crewai import CrewAIBridge

    debugger = AgentDebug(store=SQLiteTraceStore('.agentdebug/errors.sqlite'))
    trajectory = debugger.start_trace(goal='build a marketing plan', framework='crewai')

    with CrewAIBridge(debugger, trajectory):
        crew.kickoff(inputs={...})   # normal CrewAI call; events flow into AgentDebug

    debugger.finish_trace(trajectory, success=True)

The bridge defers the ``crewai`` import, so this module is safe to import
even when CrewAI is not installed.
"""

from __future__ import annotations

import logging
from types import TracebackType
from typing import Any, List, Literal, Optional, Tuple, Type

from agentdebug.adapters.base import AdapterStatus, FrameworkAdapter
from agentdebug.models import AgentTrajectory, EventType
from agentdebug.recorder import AgentDebug

LOG = logging.getLogger('agentdebug.adapters.crewai')


def _import_crewai_events() -> Any:
    """Import crewai.events lazily; raise a clear ImportError if missing."""
    try:
        import crewai.events as crewai_events
    except ImportError as exc:
        raise ImportError(
            'CrewAIBridge requires the `crewai` package. '
            "Install with `pip install 'agentdebugx[crewai]'` or `pip install crewai`."
        ) from exc
    return crewai_events


# Event-type name → (EventType, module, agent-field-name) mapping. We resolve
# the class objects at attach-time (after import) so module import stays
# dep-free; class names are stable across CrewAI versions.
_EVENT_MAP: List[Tuple[str, EventType, Optional[str], Optional[str]]] = [
    # (CrewAI event class name, agentdebug EventType, module, agent_attr)
    ('CrewKickoffStartedEvent',    EventType.AGENT_STEP,  'planning', None),
    ('CrewKickoffCompletedEvent',  EventType.OBSERVATION, 'planning', None),
    ('TaskStartedEvent',           EventType.PLAN,        'planning', 'agent'),
    ('TaskCompletedEvent',         EventType.OBSERVATION, 'planning', 'agent'),
    ('AgentExecutionStartedEvent', EventType.AGENT_STEP,  'planning', 'agent'),
    ('AgentExecutionCompletedEvent', EventType.OBSERVATION, 'reflection', 'agent'),
    ('LLMCallStartedEvent',        EventType.LLM_CALL,    'planning', 'agent'),
    ('LLMCallCompletedEvent',      EventType.LLM_RESPONSE, 'planning', 'agent'),
    ('ToolUsageStartedEvent',      EventType.TOOL_CALL,   'action',   'agent_role'),
    ('ToolUsageFinishedEvent',     EventType.TOOL_RESULT, 'action',   'agent_role'),
    ('ToolUsageErrorEvent',        EventType.TOOL_RESULT, 'action',   'agent_role'),
]


def _attr(obj: Any, *names: str) -> Optional[str]:
    """Return the first non-None attribute on `obj` from `names`, stringified."""
    for name in names:
        v = getattr(obj, name, None)
        if v is not None:
            try:
                return str(v)
            except Exception:
                continue
    return None


def _agent_name(event: Any, fallback: str) -> str:
    # CrewAI events expose the agent in a handful of slightly different fields
    # depending on the event class; try the common ones in order.
    return _attr(event, 'agent_role', 'agent_name', 'agent', 'role', 'name') or fallback


def _output_for(event: Any) -> Any:
    return _attr(event, 'output', 'result', 'response', 'completion', 'tool_response')


def _input_for(event: Any) -> Any:
    return _attr(event, 'prompt', 'input', 'tool_input', 'tool_args', 'description')


def _error_for(event: Any) -> Optional[str]:
    err = _attr(event, 'error', 'exception', 'error_message')
    return err if err else None


class CrewAIBridge:
    """Subscribe to crewai_event_bus and record events into an AgentDebug trajectory.

    Behaves as both a context manager (``with CrewAIBridge(...): ...``) and a
    plain object with ``attach()`` / ``detach()``.
    """

    framework = 'crewai'

    def __init__(
        self,
        debugger: AgentDebug,
        trajectory: AgentTrajectory,
        *,
        bus: Any = None,
    ) -> None:
        self.debugger = debugger
        self.trajectory = trajectory
        self._bus = bus
        self._attached = False
        # Keep refs to closures so they don't get GC'd while bus holds them.
        self._handlers: List[Any] = []

    def attach(self) -> 'CrewAIBridge':
        if self._attached:
            return self
        ce = _import_crewai_events()
        bus = self._bus or getattr(ce, 'crewai_event_bus', None)
        if bus is None:
            raise RuntimeError('crewai.events.crewai_event_bus is not available')
        for class_name, et, module, _agent_attr in _EVENT_MAP:
            evt_cls = getattr(ce, class_name, None)
            if evt_cls is None:
                LOG.debug('CrewAI event class %s not found; skipping', class_name)
                continue
            handler = self._make_handler(et, module, class_name)
            self._handlers.append(handler)
            bus.on(evt_cls)(handler)
        self._attached = True
        return self

    def detach(self) -> None:
        # CrewAI's event bus does not expose a public unsubscribe surface as
        # of the versions we target. Drop our handler references so they
        # become eligible for GC; the bus will skip dead refs.
        self._handlers.clear()
        self._attached = False

    # Context-manager sugar — equivalent to attach/detach.

    def __enter__(self) -> 'CrewAIBridge':
        return self.attach()

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> Literal[False]:
        self.detach()
        return False

    # ---- internals ----

    def _make_handler(
        self,
        event_type: EventType,
        module: Optional[str],
        class_name: str,
    ) -> Any:
        debugger = self.debugger
        trajectory = self.trajectory

        def _on_event(source: Any, event: Any) -> None:
            try:
                # NB: record_event takes metadata via **kwargs, so we pass
                # the per-event tags as flat keyword args. Passing them as
                # `metadata={...}` would wrap them under `metadata['metadata']`.
                debugger.record_event(
                    trajectory,
                    event_type=event_type,
                    agent_name=_agent_name(event, fallback=class_name),
                    module=module,
                    input=_input_for(event),
                    output=_output_for(event),
                    error=_error_for(event),
                    crewai_event_class=class_name,
                    crewai_source_type=type(source).__name__,
                )
            except Exception as exc:  # pragma: no cover - defensive
                LOG.warning(
                    'CrewAIBridge handler for %s raised: %s', class_name, exc
                )

        return _on_event


class CrewAIAdapter:
    """Structural :class:`FrameworkAdapter` — used by `agentdebug doctor`."""

    framework = 'crewai'

    def instrument(self, debugger: AgentDebug) -> AdapterStatus:  # noqa: D401
        try:
            _import_crewai_events()
        except ImportError as exc:
            return AdapterStatus(
                framework=self.framework,
                implemented=False,
                notes=str(exc),
            )
        return AdapterStatus(
            framework=self.framework,
            implemented=True,
            notes=(
                'Create a trajectory, then use '
                '`with CrewAIBridge(debugger, trajectory): crew.kickoff(...)` '
                'to record every Crew/Task/Agent/LLM/Tool event into AgentDebug.'
            ),
        )


_: FrameworkAdapter = CrewAIAdapter()  # static structural check


__all__ = ['CrewAIAdapter', 'CrewAIBridge']
