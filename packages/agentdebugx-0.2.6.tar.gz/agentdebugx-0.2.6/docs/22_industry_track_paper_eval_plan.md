# 22 - EMNLP Industry Track Paper + Evaluation Plan

This note translates the EMNLP 2026 Industry Track call and recent ACL/EMNLP
Industry Track patterns into a concrete writing and evaluation plan for the
AgentDebugX paper.

## 1. What Industry Track Reviewers Reward

Industry-track papers are not judged like pure method papers. The recurring
shape in strong papers is:

1. Real deployment pain, not a benchmark-only motivation.
2. A system that can actually be used by practitioners.
3. Evaluation under practical constraints: cost, latency, scale, privacy,
   maintainability, human workflow, and failure modes.
4. Lessons learned that future builders can reuse.
5. Clear limitations and responsible deployment boundaries.

Examples worth emulating:

- **Experience Report: Implementing Machine Translation in a Regulated
  Industry** (EMNLP 2025 Industry): emphasizes legal/security constraints,
  human-in-the-loop validation, and reviewer preferences over more than 11k
  ranked translations. Source: https://aclanthology.org/2025.emnlp-industry/
- **STREAQ** (EMNLP 2025 Industry): frames the contribution as an industrial
  cost-quality routing system and reports both model quality and operational
  cost reduction. Source: https://aclanthology.org/2025.emnlp-industry.121/
- **RAVEN** (ACL 2025 Industry): combines industrial data, public benchmarks,
  deployment pipeline, and online A/B validation. Source:
  https://aclanthology.org/2025.acl-industry.3/
- **ARIA** (EMNLP 2025 Industry): uses a realistic deployed domain plus public
  dynamic-knowledge tasks, and states deployment scope.
- **AutoPenBench** (EMNLP 2025 Industry): releases an open benchmark, reports
  autonomous versus human-assisted agent success, and uses intermediate
  milestones to show where agents struggle. Source:
  https://aclanthology.org/2025.emnlp-industry.114/

For AgentDebugX, the paper should therefore be framed as:

> A deployment-oriented debugging layer for agentic NLP systems, evaluated on
> whether it makes failures observable, attributable, shareable, and easier for
> humans to fix.

The central claim should not be "we beat every attributor." A stronger claim
for the Industry Track is:

> AgentDebugX provides the missing operating layer between raw agent traces and
> actionable debugging workflows: aligned native/error traces, taxonomy-backed
> reports, Error Hub bundles, and cost-aware analysis profiles.

## 2. Appendix Rule

The EMNLP 2026 Industry Track permits appendices after the bibliography. The
appendix does not count against the 6-page review limit, but the main paper
must be self-contained and reviewers are not required to review appendices.
Source: https://2026.emnlp.org/calls/industry_track/
So:

- Main body: problem, system, screenshot, concise evaluation table, key
  findings, limitations.
- Appendix: benchmark matrix, annotation schema, prompts, model settings,
  study protocol, redaction examples, additional error traces.

Do not hide the core evaluation logic in the appendix. Put enough in the main
body that a reviewer can assess technical quality without reading extra pages.

## 3. Main-Body Narrative

Recommended six-page spine:

1. **Introduction**: agent systems fail through cascades; raw traces are not
   enough; teams need who/when/why/fix.
2. **Deployment Requirements**: low-friction instrumentation, privacy,
   portable schema, cost-aware analysis, human review.
3. **System**: recorder + schema + taxonomy + detectors/attributors +
   Error Hub + UI.
4. **Use Case Figure**: paired native trace and AgentDebugX error trace.
5. **Evaluation**: benchmark coverage, diagnostic accuracy, human utility,
   operational overhead.
6. **Lessons/Limitations**: where it works, where it does not, safety.

## 4. Evaluation Questions

### Q1. Coverage

Can AgentDebugX ingest different agent classes without bespoke debugging code?

Benchmarks:

- AgentErrorBench: failure-labeled traces over ALFWorld, GAIA, WebShop.
- MAST and Who&When: multi-agent attribution and failure taxonomy labels.
- AgentRx: 115 failed trajectories with critical-step labels.
- WebShop/WebArena: web navigation and tool-use.
- tau-bench: retail/airline tool-agent-user interaction.
- SWE-bench Lite/Verified: coding agents with executable tests.
- OSWorld: multimodal desktop/GUI agents.

Metric: conversion success rate, required adapter LOC, event coverage, artifact
coverage, and schema loss notes.

### Q2. Diagnostic Accuracy

Can AgentDebugX classify and localize failures?

Labels:

- failure family
- failure mode
- root event ID
- root agent
- root step
- cascade edges
- evidence spans
- accepted repair

Metrics:

- family macro-F1
- mode macro-F1
- responsible-agent accuracy
- root-step exact match
- root-step +/- 1 match
- cascade-edge F1
- false-positive rate on successful traces
- calibration: confidence vs correctness

Baselines:

- rule analyzer
- single-pass LLM judge
- All-at-Once attribution
- Step-by-Step attribution when implemented
- DeepDebug verify/refine loop
- benchmark-native labels or published baselines where available

### Q3. Human Utility

Does the paired trace view reduce debugging effort?

Study design:

- 12-24 developers.
- Within-subject comparison: raw framework trace/logs vs AgentDebugX report.
- 24-48 total debugging sessions.
- Counterbalance task order and UI order.

Metrics:

- time to first plausible root cause
- time to accepted repair
- correctness against adjudicated labels
- number of trace events inspected
- confidence and workload rating
- free-text feedback on missing evidence

Fallback if recruiting slips:

- 3-5 expert agent builders review 30 traces.
- Ask them to choose between raw trace and AgentDebugX report, rate usefulness,
  and mark incorrect/misleading diagnoses.

### Q4. Operational Viability

Can teams run this in real workflows?

Metrics:

- analyzer latency by profile: rule, judge, DeepDebug
- token cost by trace length
- local storage overhead
- UI load time for 100, 1k, 10k events
- scrubber redaction hit rate
- scrubber false positives on benign strings
- Error Hub bundle size and push/pull time

## 5. Data Scale

Minimum credible submission target:

- 500 failed trajectories.
- 100 successful trajectories for false-positive calibration.
- At least 30 examples per high-level family where source benchmarks permit.
- Two annotators per newly labeled trace plus adjudication.
- DeepDebug on a stratified hard subset of 100 traces.

Stronger target:

- 1,000 failed trajectories.
- 200 successful trajectories.
- DeepDebug on every trace where rule and single-pass judge disagree.
- 50-100 private pilot traces, scrubbed and reported only in aggregate.

## 6. API and Infra Needed

Model APIs:

- OpenAI-compatible endpoint as the default abstraction.
- OpenAI, Gemini, Anthropic-through-proxy/LiteLLM, and local vLLM/Ollama where
  feasible.

Benchmark APIs:

- WebShop/ALFWorld/GAIA loaders for AgentErrorBench.
- MAST/Who&When/AgentRx importers preserving existing labels.
- tau-bench user/tool simulator wrapper.
- WebArena browser harness with DOM/text/action capture.
- SWE-bench Docker harness with shell, patch, and test-output capture.
- OSWorld capture path for screenshot, accessibility tree, click/action, and
  verifier result.

Storage/export:

- SQLite for local experiments.
- Error Hub bundles for sharing.
- Parquet manifest roll-up for large result analysis.

## 7. What Should Go in the Appendix

- Full benchmark matrix.
- Exact label schema and examples.
- Prompts for LLM judge, attributor, and DeepDebug.
- Model settings and token budgets.
- Human study instructions and consent/safety notes.
- Redaction examples.
- Two or three full trace/report examples.
- Failure cases where AgentDebugX is wrong.

## 8. Immediate TODO Before Submission

1. Convert at least two public benchmark sources into AgentTrajectory.
2. Produce a first 100-trace labeled set.
3. Add an evaluation runner that outputs a single CSV/JSONL.
4. Run rule, judge, All-at-Once, and DeepDebug on the same split.
5. Add a small human/expert review with raw trace vs paired trace view.
6. Trim main body to 6 pages while keeping appendix rich.

## 9. Implemented Experiment Harness

The repository now contains an `experiments/` directory for the first paper
pipeline:

- `prepare_who_when.py`: downloads the two public Who&When parquet files from
  Hugging Face and normalizes them into `AgentTrajectory` JSONL plus separate
  gold labels. On 2026-05-16 this produced 184 traces and 4,092 events.
- `run_e2e_smoke.py`: exercises the public AgentDebugX modules end to end:
  analyzer, detectors, traceback, recoverers, attribution, and Error Hub local
  push/pull. It can optionally call a live OpenAI-compatible endpoint.
- `run_who_when_eval.py`: runs attribution metrics against Who&When labels,
  including responsible-agent match, exact step match, +/-1 step match, and
  joint agent/step accuracy.
- `generate_paper_figures_openai.py`: generates the optional paper pipeline
  figure with `gpt-image-2` when `OPENAI_API_KEY` is available.

The AgentDebug / AgentErrorBench dataset is currently linked from the upstream
paper repository as a Google Drive folder rather than a stable direct download
URL. `prepare_agenterrorbench.py` accepts a local extracted folder under
`data/agenterrorbench/raw/`, can attempt `gdown` download when the optional
dependency is installed, preserves environment metadata for ALFWorld, GAIA, and
WebShop, and outputs the same `AgentTrajectory` + labels format used by the
Who&When loader.
