# 21 — Host-Runtime Integrations: Claude Code Skill + OpenHands

This doc covers how AgentDebugX plugs into existing host agent runtimes as a
sub-module the host can call on demand.

The constraints we honor:

1. **No fork.** The integration always calls back into the locally installed
   `agentdebug` CLI / Python API, never duplicates AgentDebugX code into the
   host's runtime tree. Upgrading AgentDebugX upgrades the integration.
2. **Suggest-only by default.** Recovery proposals are never auto-applied;
   the host agent surfaces them to the user.
3. **Privacy boundary.** Integrations never auto-upload to the community Hub
   without explicit user opt-in.

## 1. Claude Code Skill

`agentdebug.integrations.claude_skill` generates a Claude Code
[Skill](https://www.claude.com/claude-code) package that wraps the
AgentDebugX CLI. Skills are folders of `SKILL.md` + assets that Claude can
match against and invoke on demand.

### Generate

```bash
agentdebug integrations skill --target ~/.claude/skills --name agentdebug
# wrote Claude Skill -> /home/<user>/.claude/skills/agentdebug
```

Or programmatically:

```python
from pathlib import Path
from agentdebug.integrations import build_skill_bundle, write_skill_bundle

bundle = build_skill_bundle(name='agentdebug')
write_skill_bundle(bundle, target_dir=Path.home() / '.claude' / 'skills')
```

### What it contains

- `SKILL.md` — frontmatter (`name`, `description`, `license`) + trigger
  phrases (e.g., "debug this agent run", "why did this agent fail", "find
  the root cause", "analyze this trajectory") + a recipe for choosing
  between quick-scan / judge / DeepDebug / Hub push based on user intent.
- `README.md` — refresh instructions.

### How Claude uses it

When the user mentions a trajectory file, store path, or asks debugging
questions, Claude's skill matcher fires and Claude invokes the right CLI
command:

| User intent | Skill recipe |
|---|---|
| "what failed?" | `agentdebug analyze <file> --suggest` |
| "who caused it?" | `agentdebug judge <file|trace_id> --attribute` |
| "I need a thorough postmortem" | `agentdebug deep <file|trace_id>` |
| "share this with the team" | `agentdebug hub push <trace_id> --to git:...` |

## 1.5 CrewAI integration

CrewAI emits a typed event stream via a process-global
`crewai.events.crewai_event_bus`. `agentdebug.adapters.crewai` ships two
pieces:

- `CrewAIBridge(debugger, trajectory)` — context manager that subscribes
  to the bus and translates events into AgentDebug records.
- `CrewAIAdapter().instrument(debugger)` — used by `agentdebug doctor` to
  report whether CrewAI is importable.

### Recording a Crew run

```python
from agentdebug import AgentDebug, SQLiteTraceStore
from agentdebug.adapters.crewai import CrewAIBridge

debugger = AgentDebug(store=SQLiteTraceStore('.agentdebug/errors.sqlite'))
trajectory = debugger.start_trace(goal='build a marketing plan', framework='crewai')

with CrewAIBridge(debugger, trajectory):
    crew.kickoff(inputs={...})   # standard CrewAI call

debugger.finish_trace(trajectory, success=True)
```

### What gets recorded

| CrewAI event class | AgentDebug `EventType` | Module |
|---|---|---|
| `CrewKickoffStartedEvent` | `AGENT_STEP` | planning |
| `CrewKickoffCompletedEvent` | `OBSERVATION` | planning |
| `TaskStartedEvent` | `PLAN` | planning |
| `TaskCompletedEvent` | `OBSERVATION` | planning |
| `AgentExecutionStartedEvent` | `AGENT_STEP` | planning |
| `AgentExecutionCompletedEvent` | `OBSERVATION` | reflection |
| `LLMCallStartedEvent` | `LLM_CALL` | planning |
| `LLMCallCompletedEvent` | `LLM_RESPONSE` | planning |
| `ToolUsageStartedEvent` | `TOOL_CALL` | action |
| `ToolUsageFinishedEvent` | `TOOL_RESULT` | action |
| `ToolUsageErrorEvent` | `TOOL_RESULT` (with `error`) | action |

Event class names not present in the installed CrewAI version are silently
skipped — useful for forward/backward compatibility.

### Install

```bash
pip install 'agentdebugx[crewai]'
```

### See also

`examples/crewai_demo.py` shows a complete two-agent crew (researcher +
editor) instrumented with `CrewAIBridge`.

## 2. OpenHands integration

`agentdebug.integrations.openhands` ships two complementary pieces.

### 2.1 Microagent contract (passive — host invokes us)

```bash
agentdebug integrations openhands-microagent --target .openhands/microagents
# wrote OpenHands microagent -> .openhands/microagents/agentdebug.md
```

The generated markdown is a [knowledge
microagent](https://github.com/All-Hands-AI/OpenHands) — Claude / GPT
running inside OpenHands reads it as context when a trigger phrase fires
("debug agent failure", "root cause analysis", "analyze trajectory", …),
then calls the `agentdebug` CLI through OpenHands' shell tool.

### 2.2 Event-stream bridge (active — we record OpenHands)

```python
from agentdebug import AgentDebug
from agentdebug.integrations import OpenHandsBridge

debugger = AgentDebug()
trajectory = debugger.start_trace(goal="...", framework="openhands")
bridge = OpenHandsBridge(debugger=debugger, trajectory=trajectory).attach(
    conversation.event_stream
)

# ...run the OpenHands session normally...

bridge.detach()
debugger.finish_trace(trajectory, success=success)
report = HeuristicAnalyzer().analyze(trajectory)
```

The bridge subscribes to `EventStreamSubscriber.MAIN` and translates each
typed `Action` / `Observation` into an `AgentEvent`. `*Action` → `TOOL_CALL`,
`*Observation` → `TOOL_RESULT`, everything else → `OBSERVATION`. The
mapping is heuristic but consistent because OpenHands' class names follow
a strict convention.

## 3. Why two entry points?

- **Microagent** is the *deferred* path: AgentDebugX runs only when the host
  agent or user asks for it. Zero overhead when idle, no instrumentation of
  the host's hot loop.
- **EventStreamBridge** is the *passive* path: AgentDebugX captures every
  session, even when nothing went wrong. Costs a small per-step overhead but
  gives you a complete trajectory store you can later analyze (or push to a
  Hub for review).

Most teams want both — microagent for on-demand debugging during
development, bridge for production passive observability.

## 4. Beyond Claude Code / OpenHands

The same pattern applies to any host runtime that has a tool/skill registry
+ an event stream. Concretely, the abstractions to copy are:

- A **trigger-matched documentation contract** (Skill.md, microagent.md) that
  describes when to invoke AgentDebugX and what arguments to pass.
- A **structured event stream subscription** that maps host events into
  `AgentEvent`.

Future targets include LangGraph's checkpointer hooks, AutoGen's group-chat
event bus, and Pydantic-AI's OTel integration. See
[docs/05_adapters.md](./05_adapters.md) for the per-framework adapter plan.

## 5. Testing

`tests/test_deep_and_integrations.py` covers:

- Skill bundle generates valid `SKILL.md` with trigger phrases.
- OpenHands microagent emits valid YAML front-matter and references
  `CodeActAgent` / suggest-only safety language.

Live integration tests (Claude Code + OpenHands) are out of scope for CI —
they require the host runtimes installed. The generated artifacts are pure
files, so eyeballing them after generation is the recommended QA path.
