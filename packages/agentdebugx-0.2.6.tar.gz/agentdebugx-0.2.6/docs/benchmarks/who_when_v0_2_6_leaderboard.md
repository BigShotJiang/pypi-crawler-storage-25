# Who&When — 5-trace Live Leaderboard (v0.2.6, gemini-3-flash)

Tiny validation sample drawn from `data/who_when/processed/labels.jsonl`
(first 5 algorithm-generated traces). **Not a publishable benchmark** — the
full benchmark requires the 184-trace dataset + a frontier model and is
deferred for cost reasons. This run exists to verify the analysis stack
produces sensible-shaped numbers and to surface regressions early.

## Aggregate (per attribution method)

| Method | agent_match | exact_step | near_step | both_near | DeepDebug rounds |
|---|---:|---:|---:|---:|---:|
| `heuristic` (rule baseline) | 0.20 | 0.00 | 0.20 | 0.20 | n/a |
| `llm_judge_root` (judge's root_cause field) | **0.40** | 0.00 | **0.20** | **0.20** | n/a |
| `all_at_once` (Who&When method 1) | 0.20 | 0.00 | 0.00 | 0.00 | n/a |
| `step_by_step` (Who&When method 2) | **0.40** | 0.00 | **0.20** | **0.20** | n/a |
| `deep_debug_root` (DeepDebug refined root) | 0.20 | 0.00 | 0.20 | 0.00 | 6 / trace |

## What changed in 0.2.6 vs 0.2.5

Same 5 traces, same model:

| Method | 0.2.5 agent_match | 0.2.6 agent_match | Δ |
|---|---:|---:|---:|
| `heuristic` | 0.20 | 0.20 | — |
| `llm_judge_root` | 0.00 | **0.40** | +0.40 |
| `all_at_once` | 0.00 | 0.20 | +0.20 |
| `step_by_step` | 0.00 | **0.40** | +0.40 |

The driver was the v0.2.6 judge prompt hardening: `max_tokens` default
4096 → 8192, an explicit `max_findings_per_chunk=6` cap surfaced through
the system prompt, and a "CRITICAL OUTPUT RULES" header (output ONLY JSON,
no markdown, no newlines in strings, complete the array). Before the
hardening, the judge truncated mid-array on Who&When debate transcripts
and returned no findings; after, the structured root_cause is populated.

## Honest caveats

* n=5; per-method standard error is ±0.22 — these absolute numbers should
  not be over-interpreted. The 0.4 vs 0.0 jump for two methods is the
  signal worth reporting; everything else is noise.
* `deep_debug_root` underperformed `step_by_step` on this sample. The
  refine round on 7-event traces tends to converge to the *visible*
  failure rather than the *causal* root (a known Who&When difficulty —
  manifestation vs root cause).
* No method beats `near_step=0.20` on this sample. Step-localization
  remains hard, matching the published Who&When ceiling (~14% step on
  127 traces with frontier models).

## Reproducing

```bash
# Prepare data (once)
PYTHONPATH=src python experiments/prepare_who_when.py

# Set live LLM creds (any OpenAI-compatible endpoint works)
export AGENTDEBUG_LLM_BASE_URL=...
export AGENTDEBUG_LLM_API_KEY=...
export AGENTDEBUG_LLM_MODEL=gemini-3-flash

# Without DeepDebug (~1 min)
PYTHONPATH=src python experiments/run_who_when_eval.py \
  --limit 5 --live-openai \
  --out-dir experiments/runs/who_when_eval_subset

# With DeepDebug (~5 min)
PYTHONPATH=src python experiments/run_who_when_eval.py \
  --limit 5 --live-openai --deep \
  --out-dir experiments/runs/who_when_eval_subset_deep
```

The headline benchmark (184 traces × 5 methods × DeepDebug) would take
~6 hours and ~$5-10 in API cost on a frontier model. Run it once before
paper submission; do not run on every iteration.
