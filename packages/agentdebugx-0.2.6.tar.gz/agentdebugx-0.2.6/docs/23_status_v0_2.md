# 23 — Capability + Test Coverage Status (v0.2.3)

A live audit of what's implemented, what's tested, and what's specced but
not yet built. Pair this with [docs/15_roadmap.md](./15_roadmap.md), which is
the forward-looking plan; this doc is the rear-view mirror.

## 1. What ships in v0.2.2 (live on PyPI)

| Layer | Module | Status | Tests |
|---|---|---|---|
| Trace IR | `agentdebug.models` | ✅ stable | round-trip + enum tests |
| Storage | `agentdebug.storage` (JSONL + SQLite) | ✅ stable | round-trip + ctx-mgr |
| Recorder | `agentdebug.recorder` (`AgentDebug`, `TraceSession`) | ✅ stable | record + analyze flow |
| Rule analyzer | `agentdebug.analyzers.HeuristicAnalyzer` | ✅ stable | match + suggest |
| Taxonomy | `agentdebug.taxonomy` (19 seed modes) | ✅ stable | get_mode + list |
| Function instrumentation | `agentdebug.instrumentation.traced_tool` | ✅ stable | happy + raise |
| Event bus | `agentdebug.events.EventBus` | ✅ stable | fan-out + auto-detach |
| LLM client | `agentdebug.llm.OpenAICompatClient` | ✅ stable | mocked httpx + env |
| LLM judge | `agentdebug.judges.LLMJudgeAnalyzer` | ✅ stable | scripted-LLM happy + silent |
| Attribution | `agentdebug.attribution.HeuristicAttributor` | ✅ stable | first-finding + tiebreak |
| Attribution | `agentdebug.attribution.AllAtOnceAttributor` | ✅ stable | mocked LLM + fallback |
| Attribution | `agentdebug.attribution.StepByStepAttributor` | ✅ **new 0.2.2** | scripted-LLM + fallback |
| Attribution | `agentdebug.attribution.BinarySearchAttributor` | ✅ **new 0.2.3** | oracle-LLM logarithmic convergence + fallback + render elision |
| Recovery | `agentdebug.recovery.ReflexionSuggestion` | ✅ stable | per-finding + empty |
| Recovery | `agentdebug.recovery.CriticRecoverer` + `VerifierSpec` registry | ✅ **new 0.2.3** | 5 family-matched verifier templates; dedup + custom-override |
| DeepDebug | `agentdebug.deep.DeepDebugAnalyzer` | ✅ stable | full loop + silent LLM |
| Cascade view | `agentdebug.traceback.format_traceback` | ✅ stable | cascade + step-order + ANSI + empty |
| Detectors | `agentdebug.detectors.RepeatedToolCall / RepeatedState / StepCountLimit` | ✅ **new 0.2.2** | threshold + window + budget |
| Hub bundle | `agentdebug.hub.Bundle / pack_bundle / unpack_bundle` | ✅ stable | round-trip |
| Hub scrubber | `agentdebug.hub.Scrubber` | ✅ stable | 12 redactions + idempotent |
| Hub backends | `LocalHubBackend`, `GitHubBackend`, `HuggingFaceBackend` | ✅ stable | local-bare-git + local |
| Adapters | `agentdebug.adapters.raw` (`trace_loop`, `mark_step`) | ✅ stable | end-to-end + ctxvar |
| Adapters | `agentdebug.adapters.langgraph.LangChainCallbackAdapter` | ✅ stable | gracefully degrades w/o dep |
| Adapters | `agentdebug.adapters.otel.OTelExportAdapter` | ✅ stable | branch test |
| Integrations | `agentdebug.integrations.claude_skill` | ✅ stable | skill-bundle write |
| Integrations | `agentdebug.integrations.openhands` (microagent + bridge) | ⚠️ microagent stable; bridge needs live OpenHands | microagent YAML test |
| CLI | `agentdebug.cli` (`analyze | judge | deep | list | show | hub | integrations | serve | doctor`) | ✅ stable | 12 subcommand smoke tests |
| Local UI | `agentdebug.ui` (FastAPI + vanilla JS console) | ✅ stable | endpoint round-trip |

**Test counts:** 60+ unit tests + 1 live-LLM smoke test, `mypy --strict` clean
across 32 source files.

## 2. Designed in docs, not yet implemented

| Doc | Component | Why deferred | Realistic ship |
|---|---|---|---|
| [06_detectors.md](./06_detectors.md) | `trajectory_perplexity` (TrajAD) | needs token-level LM perplexity API or embedding model + baseline calibration | v0.3 |
| [06_detectors.md](./06_detectors.md) | `topic_drift` (embedding cosine) | needs embedding client; consider reusing `OpenAICompatClient` `/embeddings` | v0.3 |
| [06_detectors.md](./06_detectors.md) | LTL spec monitors | requires user-supplied spec or LLM-synthesized monitors; gated on RV research | v1.2 |
| [07_attribution.md](./07_attribution.md) | `CounterfactualAttributor` | requires re-rolling agent actions; framework-replay dependent | v0.3 |
| [07_attribution.md](./07_attribution.md) | `SBFLAttributor` (Tarantula/Ochiai) | needs corpus of passing + failing traces of same task; gated on Hub adoption | v0.4 |
| [07_attribution.md](./07_attribution.md) | `DeltaDebugAttributor` (Zeller) | same replay constraint | v0.3 |
| [07_attribution.md](./07_attribution.md) | `EnsembleAttributor` | trivial once Counterfactual lands; awaits Counterfactual | v0.3 |
| [08_recovery.md](./08_recovery.md) | `SelfRefineLoop` | small but needs a generator-critic-refiner orchestration | v0.3 |
| [08_recovery.md](./08_recovery.md) | `AutoManualRules` | needs persistent project manual + injection into next-run prompts | v0.3 |
| [08_recovery.md](./08_recovery.md) | `LangGraphRewind` | depends on LangGraph checkpointer; ships when we have a real LangGraph user | v0.3 |
| [08_recovery.md](./08_recovery.md) | `SagaRollback` | needs compensation registry on tool definitions; new schema | v0.3 |
| [08_recovery.md](./08_recovery.md) | `MCTSBranchExploration` (LATS) | heavy; v2 feature | v2.0 |
| [09_error_database.md](./09_error_database.md) | DuckDB analytical + Parquet archive | optional; Hub bundles already give per-project corpus | v0.3 |
| [09_error_database.md](./09_error_database.md) | Vector similarity search | needs embedding model + index choice | v0.3 |
| [10_taxonomy_induction.md](./10_taxonomy_induction.md) | TnT-LLM + BERTopic pipeline | needs ≥ 1k labeled traces to be useful | v0.4 |
| [11_multimodal.md](./11_multimodal.md) | Screenshot/DOM capture, VLM judge | gated on multimodal user (Claude Computer Use / OpenAI CUA / OpenHands browser) | v1.1 |
| [12_ui_dashboard.md](./12_ui_dashboard.md) | TUI (Textual) | low priority; CLI + web UI cover the use cases | v0.4 |
| [12_ui_dashboard.md](./12_ui_dashboard.md) | VSCode extension | needs TS extension scaffolding | v1.0 |
| [05_adapters.md](./05_adapters.md) | CrewAI, OpenAI Agents SDK, AutoGen, smolagents, LlamaIndex, DSPy, Pydantic-AI | each is ~150 LOC + conformance test; ship as users land | rolling |

## 3. Implementation gaps surfaced by the audit

The audit found one real bug and a handful of test gaps:

1. **`agentdebug.hub.build_manifest` was used by the CLI but not re-exported** —
   would have surfaced as `ImportError` for any user calling
   `agentdebug hub push`. Fixed in 0.2.2 (`hub/__init__.py`) and locked in by a
   CLI smoke test.
2. **`cli.py` had 0% coverage** — every subcommand now has a smoke test that
   exercises the argparse path; the LLM-required commands assert the
   "missing credentials" exit code without hitting the network.
3. **`instrumentation.py` (`traced_tool`) had 0% coverage** — happy and
   exception paths now tested.
4. **`llm.OpenAICompatClient.complete` had no test** — covered by a custom
   `httpx.BaseTransport` that returns canned JSON without a network call.
5. **`recovery.ReflexionSuggestion`** had only an indirect test from DeepDebug
   examples; now has direct happy + empty tests.

## 3.7 Judge hardening (0.2.6)

A v0.2.5 Who&When 5-trace live run had `llm_judge_root.agent_match=0.00`
because the judge truncated mid-array on long multi-agent debate
transcripts. Three changes in 0.2.6 lifted that to **0.40** on the same
sample (same model, same traces):

1. `LLMJudgeAnalyzer.max_tokens` default **4096 → 8192** — leaves room for
   thinking-model reasoning tokens before the JSON object starts.
2. `LLMJudgeAnalyzer.max_findings_per_chunk` parameter (default 6) — the
   system prompt now asks the model to cap its findings array, forcing it
   to close the JSON even when many candidates are visible.
3. System prompt now has explicit "CRITICAL OUTPUT RULES" — output ONLY
   JSON, no markdown fences, no newlines in string values, complete the
   array.

Numbers: see [docs/benchmarks/who_when_v0_2_6_leaderboard.md](./benchmarks/who_when_v0_2_6_leaderboard.md).
Same trick works for `BinarySearchAttributor` (shipped in 0.2.4) — apply
to remaining LLM-using analyzers as more thinking models surface this.

## 3.6 Real-usage E2E (live Gemini)

Beyond unit tests, `scripts/e2e_real_usage.py` builds three realistic failing
trajectories using **only the public API** (`AgentDebug`, `traced_tool`,
`SQLiteTraceStore`) and runs the full pipeline against the live LLM.

Stage results (see [docs/benchmarks/e2e_v0_2_3.md](./benchmarks/e2e_v0_2_3.md)):

| Scenario | Stages OK |
|---|---|
| `action_format_then_hallucination` (planner → bad tool call → hallucinated answer) | 12 / 12 |
| `multiagent_handoff_loss` (researcher → handoff drops constraint → wrong summary) | 12 / 12 |
| `planning_loop` (browser clicks #submit 4× with no progress) | 12 / 12 |
| UI smoke (`/healthz`, `/api/v1/traces`, `/api/v1/traces/<id>`, `/api/v1/taxonomy`, `/`) | 5 / 5 |
| Fresh-venv `pip install agentdebugx==0.2.3` + import + CLI listing | ✅ |

**Honest issues the E2E surfaced** (none of these would have been caught by
the mocked unit tests):

1. **LLM judge can return truncated JSON on long traces** — gemini-3-flash
   spent its `max_tokens` budget on reasoning tokens before completing the
   findings array; the pipeline gracefully returned 0 findings rather than
   crashing. Mitigation: per-call `max_tokens=6144`+; document the
   thinking-token trap (done in [docs/20_deep_debug.md §7](./20_deep_debug.md)).
2. **`BinarySearchAttributor` falls back to `HeuristicAttributor` when its
   probe JSON is truncated** — observed in 2 of 3 scenarios. The fallback
   chain works correctly, but the user loses the O(log N) advantage.
   Followup: tighter bisection prompts; track in `result.raw['probe_count']`.
3. **`HeuristicAnalyzer` returns `root_cause_step_index=None` when all
   findings have `step_index=None`** — the event recorded via `traced_tool`
   doesn't carry a step index. Real bug; `traced_tool` should auto-assign.

These are tracked as v0.2.4 fixes.

## 4. Coverage matrix (post-0.2.2)

Run `PYTHONPATH=src pytest --cov=agentdebug --cov-report=term`. The two largest
remaining gaps are deliberate:

- `agentdebug.adapters.langgraph` — exercised only when `langchain_core` is
  installed. The status-test verifies graceful degradation when it isn't.
- `agentdebug.hub.backends.HuggingFaceBackend` — gated on `huggingface_hub`.
  Round-tripping through real HF requires `HF_TOKEN`; covered by the local
  bare-git test for the analogous push/pull flow.

## 5. Acceptance gates for v0.3 (next minor)

Before v0.3 ships, this doc should record green checkmarks for:

- [x] **Logarithmic-cost attributor** (`BinarySearchAttributor`) shipped in
      0.2.3 — Who&When method 3, O(log N) LLM calls, bisects the trajectory
      via prefix evaluation. **Note:** this is not yet a "replayable
      counterfactual" attributor; it predicts whether the failure has
      already occurred from the prefix without re-rolling the agent. True
      counterfactual replay is still v0.3.
- [x] **Tool-grounded recovery strategy** (`CriticRecoverer` + `VerifierSpec`
      registry) shipped in 0.2.3 — pattern-matches failure modes against 5
      default verifier templates (JSON-schema guard, final-state check,
      tool-result type-check, handoff contract, loop-detector guard) and
      emits per-finding `FixProposal` with rationale + suggested code.
- [x] **One additional framework adapter** — CrewAI adapter shipped in
      0.2.5 (`agentdebug.adapters.crewai`). `CrewAIBridge` context manager
      subscribes to `crewai_event_bus`, translates 11 CrewAI event types
      into `AgentEvent`s. Conformance test mocks the bus and verifies
      every documented event mapping plus the version-skew degradation
      path. `examples/crewai_demo.py` shows a working two-agent crew.
- [x] **HuggingFace Hub round-trip live test** — shipped in 0.2.6 as
      `tests/test_hub_huggingface_live.py`. Gated on `HF_TOKEN` +
      `AGENTDEBUG_HF_LIVE=1` so it never runs in default CI. Creates the
      dataset repo if missing, pushes a bundle, lists, pulls back, verifies
      the trajectory round-trips bit-for-bit. Live-validated against
      `KunlunZhu/agentdebugx-live-test`.
- [x] **Bench harness with Who&When loader** — `experiments/prepare_who_when.py`
      ingests 184 Algorithm-Generated + Hand-Crafted traces (4092 events) and
      stores labels separately. `experiments/run_who_when_eval.py` runs all
      4 attributors + DeepDebug against gold labels; reports agent_match,
      exact_step, near_step. Live-Gemini 5-trace validation captured at
      [docs/benchmarks/who_when_v0_2_6_leaderboard.md](./benchmarks/who_when_v0_2_6_leaderboard.md).
      Headline 184-trace run deferred (~6h / ~$5-10 on a frontier model).
