import aurapl

aurapl.run()