#!/bin/bash
# ptk-setup.sh — ensure ptk is available in the AI agent environment.
if ! command -v ptk &> /dev/null; then
    echo "ptk not found; installing..."
    pip install ptk || pip install --user ptk
fi
echo "ptk is available: $(ptk --version)"
