from __future__ import annotations

def main() -> None:
    for i in range(1, 31):
        print(f'phase {i:02d} results summary')
        for _ in range(8):
            print('status: repeating message for compression')
    print('done')

if __name__ == '__main__':
    main()
