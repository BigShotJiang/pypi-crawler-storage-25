from __future__ import annotations

from pathlib import Path
from textwrap import shorten

from ptk.core.tracking import TimedExecution
from ptk.core.toml_filter import apply_filter, find_matching_filter
from ptk.core.utils import run_capturing


def main() -> None:
    cmd = ["python", "scripts/long_output.py"]
    raw_stdout, raw_stderr, returncode = run_capturing(cmd)
    combined = raw_stdout + (f"\n{raw_stderr}" if raw_stderr.strip() else "")
    command_str = " ".join(cmd)
    filt = find_matching_filter(command_str, start_dir=Path.cwd())
    filtered = apply_filter(filt, combined) if filt else combined

    timer = TimedExecution.start(db_path=Path("ptk-local-analytics.db"))
    timer.track(command_str, f"ptk run {command_str}", combined, filtered, project="measure-run")

    raw_tokens = len(combined) // 4
    filtered_tokens = len(filtered) // 4
    saved_tokens = raw_tokens - filtered_tokens
    reduction_pct = (saved_tokens / raw_tokens) * 100 if raw_tokens else 0.0

    print("=== PTK Filtering demo ===")
    print(f"Command: {command_str}")
    print(f"Return code: {returncode}")
    print(f"Raw tokens (estimated): {raw_tokens:,}")
    print(f"Filtered tokens (estimated): {filtered_tokens:,}")
    print(f"Tokens saved: {saved_tokens:,} ({reduction_pct:.1f}%)")
    print()
    print("Filtered output preview:")
    for line in filtered.splitlines()[:20]:
        print(line)
    if len(filtered.splitlines()) > 20:
        print("... (truncated)")


if __name__ == "__main__":
    main()
