# PowerShell Agent Hook Implementation Plan

_Goal_: Extend PTK's hook infrastructure so agents that launch commands via PowerShell can receive the same automatic command rewriting and token savings tracking that Bash-based agents (e.g., Claude Code) already enjoy.

## Requirements

1. **Hook command compatibility** – PowerShell agents must be able to invoke a PTK-powered rewrite script before dispatching every tool call; the rewritten string must be emitted only when a supported command is detected, falling back to the original command otherwise.
2. **Agent installation flow** – Provide a concrete `ptk init` / `ptk hook` experience for PowerShell shells, including configuration file discovery, backup of existing hook values, and user feedback.
3. **CLI surface** – The existing `ptk init` CLI must expose the PowerShell option (e.g., `--agent powershell` or `--shell powershell`) and route it to a reusable installer module so other agents can consume the same logic.
4. **Documentation** – README/docs sections referencing supported agents, auto-rewrite hooks, and installation steps must describe the PowerShell integration (command snippet, installation command, restart requirements, limitations).
5. **Testing / validation** – We must provide a way to test the PowerShell hook logic (unit/integration or manual recipe) and ensure `ptk rewrite` is invoked with the correct command string when the hook runs.
6. **Analytics/tracking** – PowerShell hook runs should log to the same analytics DB so `ptk gain` continues to show aggregate savings; install scripts should ensure the tracking DB remains writable (documented if extra steps are needed on Windows).

## Tasks

- [x] **Write PS hook installer module** (`ptk/hooks/agents/powershell.py`) that:
  - Locates the target agent’s PowerShell config (or accepts a configurable path).
  - Writes a snippet that calls `ptk rewrite`, emits rewritten output only when RTK supports the command, and otherwise prints the original command string.
  - Backs up/restores previous hook settings and reports success/failure.

- [x] **Expand CLI commands** (`ptk/hooks/init.py`) to accept `--shell powershell` and dispatch installers; manual installs use **`ptk hook <agent> --shell powershell`** (agents: `claude`, `cursor`, `gemini`). There is no separate `ptk hook powershell` subcommand.

- [x] **Update documentation**:
  - README sections for “Auto-Rewrite Hook”, “Supported AI Tools”, and any agent-specific docs should describe how to install/reinstall the PowerShell hook, mention restart requirements, and clarify limitations (e.g., need to set execution policy, quoting differences).
  - Add a short section or FAQ entry describing how to manually verify that PowerShell commands are routed through PTK (e.g., running `ptk rewrite` in a PS prompt to inspect output).
  - _Note:_ README still lacks a per-agent PowerShell table row for Cursor/Gemini; tracked under the open “workflow per agent” task below.

- [x] **Add tests or verification scripts** that exercise the PowerShell hook logic:
  - A unit/integration test that simulates the snippet’s behavior (e.g., call a helper function with a mock command and ensure it loads `ptk rewrite` output/exit code).
  - Optionally, document a manual verification flow (`ptk rewrite`, sample command) so future agents can confirm the hook working on Windows.

- [x] **Document analytics/tracking considerations** (if special paths or permissions are needed on Windows) and confirm the hook installer can still write to the analytics DB; mention this in the plan file so future contributors know to check.

- [x] **Cross-team handoff notes** – Summarize key integrations, expected environment variables, and follow-up steps (e.g., which release notes to update) so another agent can pick up from this plan if work stops.

- [x] **Map other agents from the Rust repo** (Copilot, Cursor, Gemini, Codex, Windsurf, Cline/Roo, OpenCode, OpenClaw) to their PowerShell hook artifacts so we know which files or JSON entries must be patched.
  - **Implemented in this port:** Claude → `~/.claude/settings.json` `hookCommand`. Cursor → `~/.cursor/hooks/ptk-rewrite.ps1` + `~/.cursor/hooks.json` `preToolUse` ([rtk `hooks/cursor/rtk-rewrite.sh`](https://github.com/maravedi/ptk/blob/master/hooks/cursor/rtk-rewrite.sh)). Gemini → `~/.gemini/hooks/ptk-hook-gemini.ps1` + `~/.gemini/settings.json` `hooks.BeforeTool` ([rtk `patch_gemini_settings`](https://github.com/maravedi/ptk/blob/master/src/hooks/init.rs)).
  - **Not yet in this port:** Copilot (`.github/hooks` / VS Code JSON), Windsurf/Cline (markdown rules), OpenCode/OpenClaw (TS plugins). **Codex** is implemented (`src/ptk/hooks/agents/codex.py`): global `~/.codex/` or project-local `PTK.md` / `AGENTS.md`.

- [ ] **Add PowerShell-specific installers** for every remaining agent:
  - [x] Claude (`hookCommand` via `agents/powershell.py`).
  - [x] Cursor (`agents/cursor.py`).
  - [x] Gemini (`agents/gemini.py` + runtime `ptk hook-gemini`).
  - [ ] Copilot (project + VS Code hook JSON; may need `hook-copilot` stdin handler like RTK).
  - [x] Codex CLI instruction install (`ptk init --codex`, `ptk hook codex`).
  - [ ] Rule/plugin agents: Windsurf, Cline; OpenCode/OpenClaw TS plugins (shell-agnostic; document PowerShell usage).

- [ ] **Create PowerShell hook scripts + matching stdin handlers** where the agent expects JSON or external `hook` binaries:
  - [x] Cursor: `ptk-rewrite.ps1` (in-script JSON I/O).
  - [x] Gemini: `ptk-hook-gemini.ps1` delegates to **`ptk hook-gemini`** (Python implements [rtk `run_gemini`](https://github.com/maravedi/ptk/blob/master/src/hooks/hook_cmd.rs)).
  - [ ] Copilot: TBD (VS Code vs CLI shapes).
  - [x] Claude: PowerShell snippet inline in `hookCommand` (no separate `.ps1` required).

- [ ] **Extend `ptk init` with optional `--agent`** to install a subset (today, `ptk init --shell powershell` installs **all** wired JSON agents: Claude + Cursor + Gemini).
  - [x] Batch install for PowerShell: `ptk init --shell powershell`.
  - [x] Per-agent manual install: `ptk hook claude|cursor|gemini --shell powershell`.

- [ ] **Document the PowerShell hook workflow per agent** in the plan doc and README (required steps, restart, verify, fallback).
  - **Plan-only quick reference (current phase):**
    - **Claude:** `ptk init --shell powershell` or `ptk hook claude --shell powershell` → restart Claude Code → run a supported command; confirm `ptk rewrite "git status"` works in a terminal.
    - **Cursor:** same init, or `ptk hook cursor --shell powershell` → restart Cursor → `hooks.json` should reference `ptk-rewrite.ps1`.
    - **Gemini:** same init, or `ptk hook gemini --shell powershell` → restart Gemini CLI → `settings.json` should list `ptk-hook-gemini.ps1`; hook runtime requires `ptk` on `PATH` (e.g. shim for `pipenv run python -m ptk.cli`).

## Progress

- Started building the PowerShell hook command helper (`src/ptk/hooks/powershell.py`) so the install path can emit a PowerShell-friendly snippet.
- Added a `--shell` flag to `ptk init/hook` and wired `claude.install` to consume that flag, enabling the new helper (Bash behavior remains the default).
- Extended README with Windows-specific instructions plus the additional PowerShell row in the supported tools table.
- Added pytest coverage for `build_powershell_hook_command` and created a dedicated PowerShell agent installer (`src/ptk/hooks/agents/powershell.py`); `claude.install` now delegates to it when `--shell powershell` is requested.
- Documented that analytics/tracking still flows into the SQLite DB described in `docs/tracking.md` (`%APPDATA%\ptk\analytics.db` on Windows, created via `ptk.core.tracking.get_db_path`) so PowerShell hooks retain the same savings telemetry without extra configuration.
- Introduced shared helper functions for bumping config files (`src/ptk/hooks/agents/utils.py`) and added a PowerShell rewrite script writer (`src/ptk/hooks/powershell.py`) to centralize the `ptk rewrite` stub.
- Added `src/ptk/hooks/agents/cursor.py` and wired `ptk init --shell powershell` plus `ptk hook cursor --shell powershell` so Cursor gets `~/.cursor/hooks/ptk-rewrite.ps1` and a `hooks.json` `preToolUse` entry (RTK-compatible JSON stdin/stdout).
- Added Gemini support: `src/ptk/hooks/agents/gemini.py`, `src/ptk/hooks/gemini_hook.py`, top-level CLI command **`ptk hook-gemini`** (Gemini BeforeTool stdin/stdout), and `ptk init --shell powershell` / `ptk hook gemini --shell powershell` to install `~/.gemini/hooks/ptk-hook-gemini.ps1` plus `settings.json` patch.

## Analytics & Tracking

- PowerShell hook runs reuse the main `ptk` analytics pipeline (no extra installer work). The helper in `src/ptk/core/tracking.py` creates `%APPDATA%\ptk\analytics.db` on Windows and respects permissions, so the new shell hook can write there once the Claude agent restarts. Watch for read/write permissions on `%APPDATA%` when deploying into locked-down environments.

## Handoff Notes

- **`ptk init --shell powershell`** patches Claude (`~/.claude/settings.json`), Cursor (`~/.cursor/hooks.json` + script), and Gemini (`~/.gemini/settings.json` + script). **`ptk hook-gemini`** is the runtime entry Gemini’s `.ps1` calls (parity with `rtk hook gemini`).
- Claude’s PowerShell snippet reads `$Env:CMD`, runs `ptk rewrite`, and echoes either the rewritten or original command; Bash remains the default for `--shell bash`.
- **Codex CLI:** `ptk init --global --codex` / `ptk init --codex` / `ptk hook codex [--global]` installs `PTK.md` + `AGENTS.md` (`@PTK.md`), mirroring RTK `run_codex_mode` (prompt-only; no shell hook). See `src/ptk/hooks/agents/codex.py`.
- **Next implementation phase:** Copilot (`ptk hook copilot` / VS Code JSON + optional `hook-copilot` stdin), then rule-file agents (Windsurf/Cline) and OpenCode/OpenClaw plugins.
- Release notes: mention `ptk hook-gemini`, Gemini/Cursor install paths, and that `ptk` must be on `PATH` for Cursor/Gemini hook scripts that shell out to the CLI.
