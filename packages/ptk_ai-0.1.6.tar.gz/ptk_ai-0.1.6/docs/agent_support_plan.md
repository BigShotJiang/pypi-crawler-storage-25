# PTK Agent Support Implementation Plan

This document tracks the technical implementation of expanded agent support (Jules, Gemini, Cursor CLI, Codex, Claude Code) for both Bash and PowerShell.

> [!IMPORTANT]
> **Objective**: Enable 100% PTK adoption across major AI agents (targeting 60-90% token savings).

## Phase 1: Bash Parity for JSON-Protocol Agents
- [x] **Task 1.1: Implement `cursor_bash.sh`**
- [x] **Task 1.2: Implement `gemini_bash.sh`**
- [x] **Task 1.3: Update Python Installers**

## Phase 2: Add Native Jules & Baton Support
- [x] **Task 2.1: Create `src/ptk/hooks/agents/jules.py`**
- [x] **Task 2.2: Add Baton CLI Support** (grouped with Jules)
- [x] **Task 2.3: Ephemeral Environment Scaffolding**

## Phase 3: Project-Scoped Rules (Persistence)
- [x] **Task 3.1: Add `.clinerules`, `.cursorrules`, and `.windsurfrules`**
- [x] **Task 3.2: Codex instructions (`PTK.md`) synchronization**

## Phase 4: PowerShell Robustness (Windows Optimization)
- [x] **Task 4.1: PS 5.1 / 7.x Compatibility** (verified `[Console]::In` usage)
- [x] **Task 4.2: Execution Policy Management** (added `-ExecutionPolicy Bypass` to all hooks)

## Phase 5: Verification & Diagnostics
- [x] **Task 5.1: Implementation of `ptk hook --verify`**
- [x] **Task 5.2: Per-Agent Token Analytics** (added `agent` filter to `ptk gain`)

---

## Technical Standards
- **No-JQ Fallback**: Bash hooks must work even if `jq` is not installed on the system (using `grep`/`sed` heuristics for simple JSON keys).
- **Environment Isolation**: Project-level rules (`.julesrules`) must be prioritized over global rules to avoid leaking local PTK paths into shared PRs.
- **Exit Code Preservation**: Every hook MUST propagate the exit code of the underlying command perfectly to prevent breaking agent logic.
