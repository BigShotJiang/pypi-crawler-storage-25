# `ptk` — Python Token Killer
### Technical Roadmap: Python Port of `rtk` with Rebranding

---

## Executive Summary

This roadmap covers the full lifecycle of creating a production-grade Python port of the `rtk` (Rust Token Killer) CLI tool — from private fork to a standalone, installable, rebranded Python package. The project is organized into six sequential phases spanning roughly 10–16 weeks for a solo developer with part-time availability, or 4–8 weeks with dedicated full-time effort. The architecture leverages Python's mature CLI and text-processing ecosystem (`typer`, `rich`, `sqlite3`, `subprocess`) and targets distribution via PyPI and Homebrew-style packaging using `pipx`.

---

## Phase Overview

| Phase | Name | Duration | Goal |
|-------|------|----------|------|
| **1** | Fork, Scaffold & Rebrand | 1 week | [x] Private fork, clean repo, new brand identity |
| **2** | Core Engine | 2–3 weeks | [x] CLI framework, subprocess plumbing, filter engine |
| **3** | Command Parity (Tier 1) | 2–3 weeks | Top 20 high-value commands ported |
| **4** | Command Parity (Tier 2) | 2–3 weeks | Remaining 80+ commands, TOML custom filters |
| **5** | Analytics, Hooks & Init | 1–2 weeks | SQLite tracking, `init` for all AI agents, `gain`, `discover` |
| **6** | Packaging, QA & Release | 1–2 weeks | PyPI, `pipx`, cross-platform CI, docs |

---

## Phase 1 — Fork, Scaffold & Rebrand (Completed)

### 1.1 Repository Setup

- [ ] **Create a private fork** of `maravedi/ptk` on GitHub under your organization or personal account. Since Python source will replace Rust source entirely, use `--no-local` and immediately create a clean branch (`main`) rather than tracking upstream Rust changes.
- [ ] **Remove Rust-specific artifacts**: Delete `src/`, `Cargo.toml`, `Cargo.lock`, `.cargo/`, `Makefile` targets for `cargo build`, and any GitHub Actions workflows that invoke `cargo`. Retain `README.md` and `LICENSE` as a reference baseline.
- [ ] **Initialize a Python project layout** using the `src/` layout (preferred by PEP 517/518 and enforced by modern packaging tools):

```
ptk/
├── src/
│   └── ptk/
│       ├── __init__.py          # package version + __all__
│       ├── cli.py               # typer App root — entry point
│       ├── core/
│       │   ├── filter.py        # FilterLevel enum + apply_filter()
│       │   ├── config.py        # TOML config loader (tomllib / tomli)
│       │   ├── tracking.py      # SQLite analytics
│       │   ├── telemetry.py     # opt-in ping (once/day)
│       │   ├── tee.py           # raw output tee + hints
│       │   ├── toml_filter.py   # project-local TOML filter loader
│       │   └── utils.py         # resolve_command(), strip_ansi(), shell_split()
│       ├── cmds/
│       │   ├── git.py
│       │   ├── cloud.py         # aws, psql, curl, wget
│       │   ├── python.py        # pytest, mypy, ruff, pip
│       │   ├── js.py            # npm, pnpm, tsc, eslint, prettier, vitest, prisma, next, playwright
│       │   ├── go.py
│       │   ├── ruby.py          # rake, rspec, rubocop
│       │   ├── rust.py          # cargo, runner (err/test)
│       │   ├── dotnet.py
│       │   ├── system.py        # ls, tree, read, grep, find, log, diff, json, deps, env, wc, format, summary
│       │   └── container.py     # docker, kubectl
│       ├── hooks/
│       │   ├── init.py          # install/uninstall for all agents
│       │   ├── integrity.py     # runtime hook check
│       │   ├── hook_check.py    # outdated hook warning
│       │   └── agents/          # per-agent hook templates
│       │       ├── claude.py
│       │       ├── cursor.py
│       │       ├── gemini.py
│       │       ├── copilot.py
│       │       ├── windsurf.py
│       │       └── cline.py
│       ├── analytics/
│       │   ├── gain.py
│       │   ├── session.py
│       │   └── cc_economics.py
│       ├── discover/
│       │   └── discover.py
│       └── learn/
│           └── learn.py
├── tests/
│   ├── unit/
│   │   ├── test_filter.py
│   │   ├── test_git.py
│   │   └── ...
│   └── integration/
│       ├── test_cli.py
│       └── ...
├── pyproject.toml
├── uv.lock                      # lock file (uv)
├── .python-version              # e.g. "3.12"
├── CHANGELOG.md
├── README.md
└── .github/
    └── workflows/
        ├── ci.yml
        └── release.yml
```

### 1.2 Brand Identity & Naming

The tool is named **`ptk`** — Python Token Killer — a direct Python lineage signal from the original `rtk` (Rust Token Killer). The name is:
- [ ] Available on PyPI: `pip install ptk` / `pipx install ptk`
- [ ] Short, memorable, and conceptually adjacent to the original
- [ ] The CLI binary is `ptk` (called as `ptk git status`, `ptk pytest`, etc.)

Update all references in `README.md`, `pyproject.toml`, shell templates, and agent hook files from `rtk` to `ptk`. Key brand touchpoints:
- [ ] Binary name: `ptk`
- [ ] Config dir: `~/.config/ptk/`
- [ ] Data dir: `~/.local/share/ptk/`
- [ ] Project filter file: `.ptk.toml`
- [ ] Agent instruction file: `PTK.md` (replaces `RTK.md`)

### 1.3 Toolchain Selection (Standards)

Adopt the current Python community standard toolchain:

| Purpose | Tool | Rationale |
|---------|------|-----------|
| Package manager + venv | `uv` | Fastest resolver; replaces pip + virtualenv + pip-tools in one |
| CLI framework | `typer` (v0.12+) | Typer uses type annotations, mirrors Rust `clap` ergonomics, ships with `rich` integration |
| Terminal output | `rich` | ANSI, tables, syntax highlighting; replaces custom ANSI stripping |
| TOML parsing | `tomllib` (stdlib 3.11+) / `tomli` (backport) | Zero-dep TOML; use `tomllib` with a conditional import |
| SQLite | `sqlite3` (stdlib) | Direct 1:1 with Rust's SQLite backend |
| Testing | `pytest` + `pytest-cov` | Industry standard; aligns with the tool's own pytest command handler |
| Linting | `ruff` | Replaces flake8 + isort + pyupgrade; fast Rust-based linter |
| Type checking | `mypy` (strict) | Full static analysis; use `--strict` from day one |
| Formatting | `ruff format` | Replaces black; same config block in `pyproject.toml` |
| Docs | `mkdocs-material` | GitHub Pages deployable; Markdown-native |

### 1.4 `pyproject.toml` Baseline

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "ptk"
version = "0.1.0"
description = "Python Token Killer — token-optimized CLI proxy for LLM context compression"
requires-python = ">=3.11"
license = { text = "MIT" }
dependencies = [
    "typer>=0.12",
    "rich>=13.0",
    "tomli>=2.0; python_version < '3.11'",
]

[project.scripts]
ptk = "ptk.cli:app"

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "mypy>=1.10",
    "ruff>=0.4",
]

[tool.ruff]
target-version = "py311"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM", "ANN"]
ignore = ["ANN101", "ANN102"]

[tool.mypy]
strict = true
python_version = "3.11"

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "--cov=ptk --cov-report=term-missing"
```

### 1.5 Git Conventions

- [ ] Use **Conventional Commits** (`feat:`, `fix:`, `refactor:`, `test:`, `docs:`, `chore:`)
- [ ] Enforce with a pre-commit hook: `pre-commit` + `commitlint`
- [ ] Branch model: `main` (protected), `dev`, feature branches `feat/<name>`
- [ ] `CHANGELOG.md` auto-generated via `git-cliff` or `python-semantic-release`

---

## Phase 2 — Core Engine

This phase builds all shared infrastructure that every command handler depends on. **No command modules are written until this foundation passes all unit tests.**

### 2.1 Subprocess Plumbing (`core/utils.py`)

The most critical piece of infrastructure. Python's `subprocess` module is fully capable but requires careful design for streaming, buffering, and exit code propagation.

```python
# core/utils.py — key contracts

def resolve_command(name: str) -> str:
    """Resolve command to full path, honoring $PATH and shims."""
    ...

def run_capturing(
    args: list[str],
    *,
    env: dict[str, str] | None = None,
    cwd: str | None = None,
) -> tuple[str, str, int]:
    """Run command, capture stdout+stderr, return (stdout, stderr, returncode).
    Uses subprocess.run with text=True, encoding='utf-8', errors='replace'.
    """
    ...

def run_streaming(
    args: list[str],
    *,
    env: dict[str, str] | None = None,
    cwd: str | None = None,
) -> int:
    """Run command with inherited stdio (no capturing). Returns exit code."""
    ...

def run_streaming_filter(
    args: list[str],
    filter_fn: Callable[[str], str],
    *,
    env: dict[str, str] | None = None,
) -> int:
    """Stream stdout through filter_fn line-by-line, inherit stderr. Returns exit code."""
    ...
```

**Key decisions:**
- [ ] Always use `text=True, encoding="utf-8", errors="replace"` — never raw bytes in filter pipelines
- [ ] For streaming filters, use `subprocess.Popen` with `stdout=PIPE` and read line-by-line; do NOT use `communicate()` as it buffers the entire output
- [ ] Propagate exit codes with `sys.exit(returncode)` — never swallow non-zero exits
- [ ] Handle `FileNotFoundError` from `Popen` uniformly: print `[ptk: command not found: {name}]` and exit 127

### 2.2 Filter Engine (`core/filter.py`)

The filter engine is the intellectual core of the tool. Port all four strategies from the Rust implementation:

```python
from enum import StrEnum

class FilterLevel(StrEnum):
    NONE = "none"
    MINIMAL = "minimal"
    AGGRESSIVE = "aggressive"

class FilterStrategy:
    """Composable filter operations — each takes lines: list[str] and returns list[str]."""

    @staticmethod
    def deduplicate(lines: list[str]) -> list[str]:
        """Remove exact-duplicate consecutive lines."""
        ...

    @staticmethod
    def truncate(lines: list[str], max_len: int = 200) -> list[str]:
        """Truncate lines exceeding max_len characters."""
        ...

    @staticmethod
    def group_by_pattern(
        lines: list[str],
        pattern: re.Pattern[str],
        max_per_group: int = 5,
    ) -> list[str]:
        """Group repetitive lines matching pattern; emit "... N more" summary."""
        ...

    @staticmethod
    def strip_ansi(text: str) -> str:
        """Remove ANSI escape codes."""
        return re.sub(r"\x1b\[[0-9;]*[mGKHF]", "", text)

    @staticmethod
    def filter_noise(lines: list[str], patterns: list[re.Pattern[str]]) -> list[str]:
        """Drop lines matching any noise pattern."""
        ...
```

All filter strategies must be **pure functions** (no side effects) to enable easy unit testing. Compose them in command handlers:

```python
def apply_git_status_filter(raw: str) -> str:
    lines = raw.splitlines()
    lines = FilterStrategy.deduplicate(lines)
    lines = FilterStrategy.filter_noise(lines, GIT_STATUS_NOISE_PATTERNS)
    return "\n".join(lines)
```

### 2.3 TOML Filter Loader (`core/toml_filter.py`)

Port the project-local TOML filter system that allows users to define custom command filters in a `.ptk.toml` file:

```python
@dataclass
class TomlFilter:
    pattern: re.Pattern[str]     # regex to match command string
    drop_lines: list[re.Pattern[str]]  # lines to drop
    group_lines: list[re.Pattern[str]] # lines to group
    max_lines: int | None = None
    trust_required: bool = True  # sandboxed by default

def find_matching_filter(command: str) -> TomlFilter | None:
    """Walk up directory tree, load .ptk.toml, return first matching filter."""
    ...

def apply_filter(f: TomlFilter, output: str) -> str:
    ...
```

Include inline test support: TOML filters can embed `[[tests]]` blocks that `ptk verify` executes, ensuring custom filters behave as documented.

### 2.4 Analytics Tracking (`core/tracking.py`)

Port the SQLite-backed tracking system:

```python
# Schema mirrors the original rtk analytics.db structure
CREATE TABLE IF NOT EXISTS commands (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   INTEGER NOT NULL,
    project     TEXT NOT NULL,
    raw_cmd     TEXT NOT NULL,
    ptk_cmd     TEXT NOT NULL,
    raw_tokens  INTEGER NOT NULL,
    ptk_tokens  INTEGER NOT NULL,
    duration_ms INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS parse_failures (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   INTEGER NOT NULL,
    raw_cmd     TEXT NOT NULL,
    error       TEXT NOT NULL,
    ran_ok      INTEGER NOT NULL
);
```

Use a **context manager** for all DB operations to ensure connections are closed:

```python
@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    db_path = get_db_path()  # ~/.local/share/ptk/analytics.db
    conn = sqlite3.connect(db_path)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()
```

Token estimation: use a simple character-based heuristic (`len(text) // 4`) for speed; optionally allow `tiktoken` as an optional dependency for accurate counts.

### 2.5 Config System (`core/config.py`)

```python
# Reads ~/.config/ptk/config.toml
@dataclass
class Config:
    ultra_compact: bool = False
    telemetry_enabled: bool = True
    token_estimator: Literal["heuristic", "tiktoken"] = "heuristic"
    db_path: str | None = None  # override default analytics path
    trust_level: Literal["ask", "auto", "never"] = "ask"

    @classmethod
    def load(cls) -> "Config":
        path = config_path()
        if not path.exists():
            return cls()
        with open(path, "rb") as f:
            data = tomllib.load(f)
        return dacite.from_dict(cls, data)  # or manual dict unpacking
```

### 2.6 Core Utilities

- [ ] **`strip_ansi(text: str) -> str`** — compile the regex once at module level: `_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[mGKHF]")`
- [ ] **`shell_split(cmd: str) -> list[str]`** — use `shlex.split(cmd)`, which is stdlib and battle-tested
- [ ] **`tee_and_hint(raw: str, cmd: str, exit_code: int) -> str | None`** — write raw output to `~/.local/share/ptk/tee/<timestamp>.txt` on failure; return a hint line for the LLM

### 2.7 CLI Root (`cli.py`)

```python
import typer
from rich.console import Console

app = typer.Typer(
    name="ptk",
    help="Python Token Killer — minimize LLM token consumption",
    no_args_is_help=True,
    pretty_exceptions_enable=False,  # raw tracebacks in --verbose mode
)
console = Console()

# Global state passed via typer context or module-level vars
verbose_flag: int = 0
ultra_compact_flag: bool = False

@app.callback()
def main(
    verbose: int = typer.Option(0, "--verbose", "-v", count=True),
    ultra_compact: bool = typer.Option(False, "--ultra-compact", "-u"),
    skip_env: bool = typer.Option(False, "--skip-env"),
) -> None:
    global verbose_flag, ultra_compact_flag
    verbose_flag = verbose
    ultra_compact_flag = ultra_compact
```

The **fallback mechanism** (run unknown commands as-is, with TOML filter lookup) is implemented as a Typer `result_callback` or by catching `SystemExit` from Typer and delegating to `run_fallback()`.

---

## Phase 3 — Command Parity (Tier 1: High-Value Commands)

Port commands in descending order of developer frequency. Each command module follows the same structure:

```python
# Template: cmds/git.py

import typer
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing, run_streaming

git_app = typer.Typer(help="Git commands with compact output")

@git_app.command("status")
def git_status(args: list[str] = typer.Argument(default_factory=list)) -> None:
    """Compact status (supports all git status flags)."""
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["git", "status", *args])
    filtered = _filter_git_status(raw)
    typer.echo(filtered)
    timer.track("git status", "ptk git status", raw, filtered)
    if code != 0:
        raise typer.Exit(code)
```

### Tier 1 Command Priority

**Group A — Git (highest daily frequency):**
- [ ] [x] `git status`, `git diff`, `git log`, `git show`
- [ ] [x] `git add`, `git commit`, `git push`, `git pull`, `git fetch`
- [ ] [x] `git branch`, `git stash`, `git worktree`
- [ ] [x] Passthrough for all other `git` subcommands

**Group B — Python toolchain (self-referential; immediately useful for developing the tool):**
- [ ] [ ] `pytest` — filter to failures only; parse test result summary
- [ ] [ ] `ruff` — group violations by rule code
- [ ] [ ] `mypy` — group errors by file
- [ ] [ ] `pip`/`uv pip` — strip progress bars; compact `list` output

**Group C — System / universal:**
- [ ] [ ] `ls`, `tree` — compact column output
- [ ] [ ] `grep`/`rg` — group by file, truncate long lines
- [ ] [ ] `find` — compact tree output
- [ ] [ ] `json` — depth-limited pretty-print, `--schema` mode
- [ ] [ ] `env` — filter + mask sensitive vars
- [ ] [ ] `diff` — ultra-condensed (changed lines only)
- [ ] [ ] `log` — deduplicate + filter noise
- [ ] [ ] `read` — file reader with filter levels
- [ ] [ ] `err` / `test` / `summary` — universal wrappers
- [ ] [ ] `wc` — strip paths and padding
- [ ] [ ] `deps` — project dependency summarizer (parse `pyproject.toml`, `package.json`, `Cargo.toml`, `go.mod`)

**Group D — Cloud (common in agent workflows):**
- [ ] [ ] `gh` — PR/issue/run/repo compact output
- [ ] [ ] `docker ps`, `docker images`, `docker logs`
- [ ] [ ] `kubectl pods`, `kubectl services`, `kubectl logs`
- [ ] [ ] `curl` — JSON auto-detection + schema output

### Per-Command Implementation Standards

Each command handler must:

1. **Capture exit code** and propagate non-zero exits with `raise typer.Exit(code)`
2. **Track analytics** via `TimedExecution` wrapping the subprocess call
3. **Support `--verbose` flag** — in verbose mode, print raw output before filtered output
4. **Support passthrough** — if subcommand is unrecognized, run the underlying binary directly and track as passthrough
5. **Handle stdin** — commands like `diff`, `log`, and `read` accept `-` as file argument for stdin piping
6. **Include docstring** matching the original `rtk` help text (rebranded)

---

## Phase 4 — Command Parity (Tier 2: Remaining Commands)

### 4.1 JavaScript / Node.js Stack

- [x] `npm run` — filter boilerplate
- [x] `pnpm list`, `pnpm outdated`, `pnpm install`
- [ ] `tsc` — group TypeScript errors by file
- [ ] `eslint` / `lint` — group violations by rule
- [ ] `prettier` / `format` — universal formatter detection
- [ ] `vitest run` — filter to failures only
- [ ] `prisma generate`, `prisma migrate`, `prisma db push`
- [ ] `next build` — compact output
- [ ] `playwright` — E2E compact output
- [x] `npx` — intelligent routing (detect `tsc`, `eslint`, `prisma`, `next`, `prettier`, `playwright`)

### 4.2 Go Stack

- [ ] `go test` — JSON streaming mode (`go test -json`), parse and filter
- [ ] `go build` — errors only
- [ ] `go vet` — compact output
- [ ] `golangci-lint` — group by lint rule

### 4.3 Ruby Stack

- [ ] `rake test` / `rails test` — compact Minitest output
- [ ] `rspec` — failures only
- [ ] `rubocop` — group by cop name

### 4.4 .NET Stack

- [ ] `dotnet build`, `dotnet test`, `dotnet restore`, `dotnet format`
- [ ] Parse `.trx` test result files
- [ ] Parse `.binlog` binary logs (via `dotnet-binlog` or text output mode)

### 4.5 Rust / Cargo (ironic but useful for polyglot devs)

- [ ] `cargo build` — strip "Compiling" lines, keep errors + warnings
- [ ] `cargo test` — failures only
- [ ] `cargo clippy` — group by lint rule
- [ ] `cargo check` — errors only
- [ ] `cargo install` — strip dependency compilation noise
- [ ] `cargo nextest run` — compact output

### 4.6 Cloud / DB

- [ ] `aws <service>` — force JSON output, compress
- [ ] `psql` — strip borders, compress tables
- [ ] `wget` — strip progress bars
- [ ] `curl` — auto-JSON detection

### 4.7 TOML Custom Filters

Implement the full project-local TOML filter system from Phase 2 (`core/toml_filter.py`) including:

- [ ] **Trust system**: `.ptk-trusted` lockfile in `~/.local/share/ptk/` mapping project paths to SHA256 of `.ptk.toml`
- [ ] **`ptk trust`** / **`ptk untrust`** — manage trusted project configs
- [ ] **`ptk verify`** — run inline tests from TOML filter blocks
- [ ] Security: TOML filters run in a restricted environment; no `exec()` or file system writes allowed from filter expressions

---

## Phase 5 — Analytics, Hooks & Init

### 5.1 `ptk gain` — Savings Dashboard

Port the full analytics command including:

- [x] Overall token savings (raw vs. filtered), reduction percentage
- [x] Per-project breakdown (`--project` flag filters to cwd)
- [x] ASCII sparkline graph (`--graph`) using `rich.progress` or hand-drawn bar chars
- [x] Command history (`--history`)
- [ ] Monthly quota savings estimate (`--quota --tier pro|5x|20x`)
- [ ] Daily/weekly/monthly breakdowns (`--daily`, `--weekly`, `--monthly`, `--all`)
- [ ] Output formats: text (rich table), JSON, CSV
- [ ] Parse failure log (`--failures`)

### 5.2 `ptk discover` — Missed Savings

Scan Claude Code / Cursor / Gemini history files to identify commands that `ptk` could have optimized but was not used for. This is the highest-value engagement hook:

```python
# discover/discover.py
HISTORY_PATHS = {
    "claude": "~/.claude/history.jsonl",   # Claude Code
    "cursor": "~/.cursor/history.jsonl",   # Cursor (verify path)
    "gemini": "~/.gemini/history.jsonl",   # Gemini CLI
}

def scan_history(agent: str, since_days: int) -> list[MissedCommand]:
    """Parse agent history, return commands with ptk equivalents that weren't used."""
    ...
```

### 5.3 `ptk learn` — CLI Corrections

Parse agent error histories to identify repeated CLI mistakes (e.g., the agent using `git status` instead of `ptk git status`) and generate correction rules. Write to `.claude/rules/cli-corrections.md` with `--write-rules`.

### 5.4 `ptk init` — Agent Hook Installation

This is the most platform-specific module. Port all 10 agent integrations:

| Agent | Hook Mechanism | Config File |
|-------|---------------|-------------|
| Claude Code | `settings.json` `hookCommand` | `~/.claude/settings.json` |
| Cursor | `settings.json` `terminal.shellArgs` | `~/.cursor/settings.json` |
| Gemini CLI | `BeforeTool` hook in `.gemini/settings.json` | `.gemini/settings.json` |
| GitHub Copilot | `preToolUse` hook JSON | VS Code `settings.json` |
| Windsurf | `cascade.shellIntegration` | `~/.codeium/windsurf/settings.json` |
| Cline/Roo | `cline_mcp_settings.json` hook | VS Code extension settings |
| OpenCode | Plugin config | `.opencode/config.toml` |
| Codex CLI | `AGENTS.md` injection | `AGENTS.md` + `PTK.md` |

For each agent:

```python
# hooks/agents/claude.py

def install(global_: bool, hook_only: bool, patch_mode: PatchMode, verbose: int) -> None:
    """Patch ~/.claude/settings.json to add hookCommand rewrite."""
    settings = load_json(claude_settings_path())
    if "hookCommand" in settings and not overwrite_confirmed(patch_mode):
        return
    settings["hookCommand"] = f"REWRITTEN=$(ptk rewrite \"$CMD\") && echo $REWRITTEN || echo $CMD"
    write_json(claude_settings_path(), settings)
    if not hook_only:
        write_ptk_md()
    print(f"[✓] Claude Code hook installed")

def uninstall(global_: bool, verbose: int) -> None:
    ...
```

**`ptk rewrite`** is the single source of truth for hook rewrites — called by all agent hooks at runtime:

```python
@app.command("rewrite")
def rewrite(args: list[str] = typer.Argument(...)) -> None:
    """Rewrite a raw command to its ptk equivalent. Exit 0 if rewritten, 1 if not."""
    cmd = " ".join(args)
    rewritten = find_rewrite(cmd)  # dict mapping patterns to ptk equivalents
    if rewritten:
        typer.echo(rewritten)
        raise typer.Exit(0)
    raise typer.Exit(1)
```

**`ptk hook gemini`** and **`ptk hook copilot`** process JSON hook payloads from stdin, rewrite if applicable, and return modified JSON.

### 5.5 `ptk session` and `ptk cc-economics`

- [x] `ptk session` — adoption rate across recent agent sessions (% of commands that used `ptk`)
- [x] `ptk cc-economics` — cross-reference Claude Code usage costs vs. token savings (reads `~/.claude/usage.json` or equivalent)

### 5.6 `ptk proxy`

Execute a command without filtering but still record to analytics. Useful for tracking tools that don't have a dedicated handler yet.

---

## Phase 6 — Packaging, QA & Release

### 6.1 Python Packaging Standards

Use **hatchling** as the build backend (PEP 517/518 compliant, zero config) and target **PyPI** as the primary distribution channel.

**Distribution strategy:**

| Method | Command | Use case |
|--------|---------|----------|
| `pipx` | `pipx install ptk` | Primary: isolated, global CLI |
| `uv tool` | `uv tool install ptk` | Modern alternative to pipx |
| PyPI | `pip install ptk` | Fallback / scripted installs |
| Homebrew tap | `brew install ptk/tap/ptk` | macOS power users |
| AUR (optional) | `yay -S ptk` | Arch Linux |

**`pipx` is the recommended install method** for CLI tools like this — it isolates the tool's dependencies in its own venv while still exposing the binary globally. Document this prominently in the README.

### 6.2 Cross-Platform Compatibility

| Platform | Notes |
|----------|-------|
| macOS (arm64, x86_64) | Primary target; test with Homebrew Python |
| Linux (x86_64, arm64) | WSL2 compatibility is critical for your use case |
| Windows (native) | Optional; `subprocess` paths differ; use `shutil.which()` not hardcoded `/usr/bin/` |

**Windows-specific considerations:**
- [ ] Use `shutil.which("git")` instead of assuming `/usr/bin/git`
- [ ] `subprocess` on Windows uses `cmd.exe` by default; pass `shell=False` and full arg lists
- [ ] ANSI output may require `colorama` on older Windows; `rich` handles this automatically
- [ ] Test under WSL2 as a first-class environment (symlinks, `/proc`, etc.)

### 6.3 Test Suite Standards

**Unit tests** (fast, no subprocess):
- [ ] Test every filter function in isolation with known inputs/outputs
- [ ] Use `pytest.mark.parametrize` for pattern-heavy filter tests
- [ ] Aim for **>90% line coverage** on `core/` modules
- [ ] Use `hypothesis` for property-based testing of filter functions (e.g., "filtered output is always ≤ raw output length")

**Integration tests** (subprocess):
- [ ] Use `pytest-subprocess` to mock subprocess calls and avoid real `git`/`cargo` dependencies in CI
- [ ] Test CLI argument parsing via `typer.testing.CliRunner`
- [ ] Test exit code propagation: non-zero exit from underlying command must produce non-zero from `ptk`
- [ ] Test TOML filter trust/untrust workflow end-to-end

**Regression tests:**
- [ ] Keep a `tests/fixtures/` directory of raw command output samples (captured from real runs)
- [ ] Paired with expected filtered output
- [ ] Run automatically on every PR to catch filter regressions

```python
# tests/fixtures/git_status_dirty.txt  (raw)
# tests/fixtures/git_status_dirty.expected.txt  (expected filtered)

@pytest.mark.parametrize("name", ["git_status_dirty", "git_diff_large", ...])
def test_filter_regression(name: str) -> None:
    raw = (FIXTURES / f"{name}.txt").read_text()
    expected = (FIXTURES / f"{name}.expected.txt").read_text()
    assert apply_git_filter(raw) == expected
```

### 6.4 GitHub Actions CI

```yaml
# .github/workflows/ci.yml
name: CI
on: [push, pull_request]
jobs:
  test:
    strategy:
      matrix:
        os: [ubuntu-latest, macos-latest, windows-latest]
        python: ["3.11", "3.12", "3.13"]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv sync --dev
      - run: uv run ruff check .
      - run: uv run ruff format --check .
      - run: uv run mypy src/
      - run: uv run pytest --cov-fail-under=85
```

```yaml
# .github/workflows/release.yml
name: Release
on:
  push:
    tags: ["v*"]
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv build
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          password: ${{ secrets.PYPI_API_TOKEN }}
```

### 6.5 Documentation

Structure `docs/` using **MkDocs Material**:

```
docs/
├── index.md                 # Overview + quick start
├── install.md               # pipx, uv, Homebrew instructions
├── commands/
│   ├── git.md
│   ├── python.md
│   └── ...
├── configuration.md         # config.toml reference
├── toml-filters.md          # custom filter authoring guide
├── hooks/
│   ├── claude.md
│   ├── cursor.md
│   └── ...
├── analytics.md             # ptk gain / discover / learn
└── contributing.md
```

Auto-generate command reference from Typer's `--help` output using `mkdocs-click` or a custom script.

### 6.6 Versioning & Release Process

- [ ] **Semantic Versioning**: `MAJOR.MINOR.PATCH` per [semver.org](https://semver.org)
  - `0.x.x` during initial development phases
  - `1.0.0` when Tier 1 + Tier 2 commands are complete and the hook system is stable
- [ ] **`CHANGELOG.md`** maintained by `git-cliff` with Conventional Commits parsing
- [ ] **Release checklist** (automate via GitHub Actions `release.yml`):
  1. Bump version in `pyproject.toml` and `src/ptk/__init__.py`
  2. Update `CHANGELOG.md`
  3. Tag `v<version>`
  4. CI runs full matrix test
  5. `uv build` produces sdist + wheel
  6. `gh-action-pypi-publish` uploads to PyPI
  7. GitHub Release created with changelog diff

---

## Appendix A — Python Standards Reference

### Code Quality Non-Negotiables

| Standard | Tool | Configuration |
|----------|------|---------------|
| PEP 8 style | `ruff` | `line-length = 100`, all rules enabled |
| Type annotations | All public functions annotated | `mypy --strict` must pass |
| Docstrings | Google style for all public functions | Enforced by `ruff D` rules |
| Import order | `ruff I` (isort-compatible) | Single `ruff` config block |
| No bare `except` | `ruff B001` | `BLE001` rule catches broad catches |
| No `print()` in library code | Use `rich.console.Console` | Custom `ruff` rule or manual review |
| `__all__` in every public module | Manual | Prevents accidental re-exports |

### Python Idioms Critical for This Project

**Use `pathlib.Path` everywhere** — never `os.path.join()`:
```python
db_path = Path.home() / ".local" / "share" / "ptk" / "analytics.db"
```

**Use `dataclasses` or `@dataclass` for config/result objects** — not plain dicts:
```python
@dataclass(frozen=True)
class FilterResult:
    filtered: str
    raw_tokens: int
    filtered_tokens: int
    reduction_pct: float
```

**Use `contextlib.suppress` instead of broad try/except** where appropriate:
```python
with contextlib.suppress(FileNotFoundError):
    config_path.unlink()
```

**Use `tomllib.loads()` (3.11+) or `tomli.loads()` for config reading** — never `json.loads()` for TOML:
```python
try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]
```

**Use `re.compile()` at module level** for patterns used in filter loops — never inside the loop:
```python
_GIT_STATUS_NOISE = re.compile(
    r"^(On branch|Your branch is|nothing to commit|no changes added)",
    re.MULTILINE,
)
```

### Subprocess Best Practices

```python
# CORRECT: explicit args list, text mode, error handling
result = subprocess.run(
    ["git", "status", "--short"],
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="replace",
    check=False,          # Never use check=True in filter pipelines
)

# CORRECT: streaming with line-by-line filter
with subprocess.Popen(
    ["cargo", "test"],
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    text=True,
    encoding="utf-8",
    errors="replace",
    bufsize=1,            # Line buffered
) as proc:
    for line in proc.stdout:
        if not is_noise(line):
            sys.stdout.write(apply_filter(line))

# NEVER: shell=True (security risk + portability issue)
subprocess.run("git status", shell=True)  # BAD

# NEVER: ignore exit code
result = subprocess.run(["git", "push"])
print("pushed!")  # BAD — may have failed
```

---

## Appendix B — Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Agent hook APIs change (Claude, Cursor, Gemini update hook schema) | Medium | High | Abstract hook logic behind agent interface; pin versions in integration tests |
| Python startup overhead noticeable to users | Low | Medium | Measure; use `uv run` shim; consider `zipapp` for faster cold start |
| TOML filter security (malicious `.ptk.toml`) | Medium | High | Trust system + SHA256 lockfile; no `eval()`/`exec()` in filter expressions |
| PyPI name squatting | Low | High | Reserve name immediately in Phase 1 with a stub package |
| Breaking changes in `typer` or `rich` | Low | Medium | Pin minor versions; run matrix tests on new releases |
| Windows subprocess edge cases (CRLF, encoding) | Medium | Medium | Test on Windows in CI from Phase 2 onward |
| Filter regressions as commands are ported | Medium | Medium | Fixture-based regression tests from Phase 3 onward |

---

*Generated: 2026-03-31 | Target Python: 3.11+ | Primary distribution: `pipx install ptk`*
