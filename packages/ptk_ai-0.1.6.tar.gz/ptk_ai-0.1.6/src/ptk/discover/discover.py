"""Scan agent histories for commands that could have used `ptk`."""

from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

discover_app = typer.Typer(help="Find missed token savings in agent history")
console = Console()

HISTORY_PATHS = {
    "claude": Path("~/.claude/history.jsonl").expanduser(),
    "cursor": Path("~/.cursor/history.jsonl").expanduser(),
    "gemini": Path("~/.gemini/history.jsonl").expanduser(),
}


def _entry_timestamp(data: dict[str, object]) -> float | None:
    """Best-effort unix time from common agent history shapes."""
    for key in ("timestamp", "ts", "time", "created_at", "t"):
        if key not in data:
            continue
        val = data[key]
        if isinstance(val, (int, float)):
            ts = float(val)
            return ts / 1000.0 if ts > 1e12 else ts
        if isinstance(val, str):
            try:
                return datetime.fromisoformat(val.replace("Z", "+00:00")).timestamp()
            except ValueError:
                continue
    return None


def scan_history(agent: str, since_days: int) -> list[str]:
    """Parse agent history, return commands with ptk equivalents that were not used."""
    path = HISTORY_PATHS.get(agent)
    if path is None or not path.is_file():
        return []

    cutoff = time.time() - since_days * 86400
    if path.stat().st_mtime < cutoff:
        return []

    missed_commands: list[str] = []
    try:
        with path.open(encoding="utf-8", errors="replace") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(data, dict):
                    continue
                entry_ts = _entry_timestamp(data)
                if entry_ts is not None and entry_ts < cutoff:
                    continue

                line_str = str(data).lower()
                if "git status" in line_str and "ptk git status" not in line_str:
                    missed_commands.append("git status")
                elif "git log" in line_str and "ptk git log" not in line_str:
                    missed_commands.append("git log")
    except OSError:
        return []

    return sorted(set(missed_commands))


@discover_app.callback(invoke_without_command=True)
def discover(
    since_days: int = typer.Option(7, "--since-days", "-d", help="Number of days to look back"),
) -> None:
    """Scan agent histories to identify commands that ptk could have optimized."""
    table = Table(title=f"Missed PTK Savings (Last {since_days} Days)")
    table.add_column("Agent", style="cyan")
    table.add_column("Missed Commands", style="magenta")

    found_any = False
    for agent in HISTORY_PATHS:
        missed = scan_history(agent, since_days)
        if missed:
            found_any = True
            table.add_row(agent, ", ".join(missed))

    if found_any:
        console.print(table)
        console.print("\n[dim]Run [bold]ptk init[/bold] to install agent hooks.[/dim]")
    else:
        console.print("[green]No missed savings found. Your agents are fully optimized![/green]")


if __name__ == "__main__":
    discover_app()
