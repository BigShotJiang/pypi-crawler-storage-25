"""Entry point for python -m ptk."""
from ptk.cli import app

if __name__ == "__main__":
    app()
