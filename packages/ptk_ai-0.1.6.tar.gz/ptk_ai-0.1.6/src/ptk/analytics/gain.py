"""`ptk gain` — token savings dashboard and analytics queries."""

from __future__ import annotations

import csv
import datetime
import io
import json
import sqlite3
from typing import Any, Literal

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ptk.core.tracking import get_db_connection, get_db_path

gain_app = typer.Typer(help="Analytics dashboard for token savings")
console = Console()

# Illustrative USD per 1M tokens for quota estimates (adjust to your provider).
_TIER_USD_PER_MILLION: dict[str, float] = {
    "pro": 15.0,
    "5x": 3.0,
    "20x": 0.75,
}

_SPARKLINE_BLOCKS = "▁▂▃▄▅▆▇█"


def _sparkline_from_counts(counts: list[int], width: int = 14) -> str:
    """Map non-negative counts to a unicode mini-bar chart."""
    if not counts:
        return ""
    if len(counts) > width:
        step = len(counts) / width
        bucket: list[float] = []
        for i in range(width):
            start = int(i * step)
            end = int((i + 1) * step)
            end = max(end, start + 1)
            bucket.append(sum(counts[start:end]) / (end - start))
        counts = [int(round(x)) for x in bucket]
    max_v = max(counts) if counts else 0
    if max_v == 0:
        return _SPARKLINE_BLOCKS[0] * len(counts)
    span = len(_SPARKLINE_BLOCKS) - 1
    return "".join(_SPARKLINE_BLOCKS[min(span, max(0, round(v / max_v * span)))] for v in counts)


def _totals(
    conn: sqlite3.Connection, project: str | None, agent: str | None
) -> tuple[int, int, int, float]:
    raw_tokens_total = 0
    ptk_tokens_total = 0
    try:
        where_clauses = []
        params = []
        if project:
            where_clauses.append("project = ?")
            params.append(project)
        if agent:
            where_clauses.append("agent = ?")
            params.append(agent)

        where_str = f" WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
        cursor = conn.execute(
            f"SELECT sum(raw_tokens), sum(ptk_tokens) FROM commands{where_str}",
            params,
        )
        row = cursor.fetchone()
        if row and row[0] is not None:
            raw_tokens_total = int(row[0])
            ptk_tokens_total = int(row[1] or 0)
    except sqlite3.OperationalError:
        pass

    reduction_pct = 0.0
    if raw_tokens_total > 0:
        reduction_pct = (1.0 - (ptk_tokens_total / raw_tokens_total)) * 100.0
    savings = raw_tokens_total - ptk_tokens_total
    return raw_tokens_total, ptk_tokens_total, savings, reduction_pct


def _daily_savings_series(
    conn: sqlite3.Connection, project: str | None, agent: str | None, days: int
) -> tuple[list[str], list[int]]:
    """Return (labels oldest->newest, savings per day) for sparkline."""
    safe_days = max(1, min(int(days), 366))
    cutoff = f"strftime('%s', 'now', '-{safe_days} days')"
    try:
        q = (
            "SELECT strftime('%Y-%m-%d', timestamp, 'unixepoch') AS d, "
            "SUM(raw_tokens - ptk_tokens) AS saved "
            f"FROM commands WHERE timestamp >= {cutoff} "
        )
        params: list[Any] = []
        if project:
            q += "AND project = ? "
            params.append(project)
        if agent:
            q += "AND agent = ? "
            params.append(agent)
        q += "GROUP BY d ORDER BY d ASC"
        cur = conn.execute(q, params)
        rows = cur.fetchall()
    except sqlite3.OperationalError:
        return [], []
    labels = [r[0] for r in rows if r[0]]
    values = [int(r[1] or 0) for r in rows]
    return labels, values


def _breakdown(
    conn: sqlite3.Connection,
    project: str | None,
    agent: str | None,
    period: Literal["day", "week", "month"],
) -> list[tuple[str, int, int, int]]:
    """Rows: (bucket, raw_sum, ptk_sum, saved)."""
    if period == "day":
        fmt = "strftime('%Y-%m-%d', timestamp, 'unixepoch')"
    elif period == "week":
        fmt = "strftime('%Y-W%W', timestamp, 'unixepoch')"
    else:
        fmt = "strftime('%Y-%m', timestamp, 'unixepoch')"
    try:
        where_clauses = []
        params = []
        if project:
            where_clauses.append("project = ?")
            params.append(project)
        if agent:
            where_clauses.append("agent = ?")
            params.append(agent)

        where_str = f" WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
        q = (
            f"SELECT {fmt}, SUM(raw_tokens), SUM(ptk_tokens) "
            f"FROM commands{where_str} GROUP BY 1 ORDER BY 1 DESC LIMIT 24"
        )
        cur = conn.execute(q, params)
        rows = []
        for bucket, rsum, psum in cur.fetchall():
            rsum_i = int(rsum or 0)
            psum_i = int(psum or 0)
            rows.append((str(bucket), rsum_i, psum_i, rsum_i - psum_i))
        return rows
    except sqlite3.OperationalError:
        return []


def _failures(conn: sqlite3.Connection, limit: int = 50) -> list[tuple[int, str, str, int]]:
    try:
        cur = conn.execute(
            "SELECT timestamp, raw_cmd, error, ran_ok FROM parse_failures "
            "ORDER BY timestamp DESC LIMIT ?",
            (limit,),
        )
        return [(int(r[0]), str(r[1]), str(r[2]), int(r[3])) for r in cur.fetchall()]
    except sqlite3.OperationalError:
        return []


@gain_app.callback(invoke_without_command=True)
def gain(
    project: str | None = typer.Option(None, "--project", "-p", help="Filter by project path"),
    history: bool = typer.Option(False, "--history", help="Show command history"),
    graph: bool = typer.Option(
        False,
        "--graph",
        help="Show ASCII sparkline of recent daily savings",
    ),
    output_format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format",
        case_sensitive=False,
    ),
    failures: bool = typer.Option(False, "--failures", help="Show recent parse / filter failures"),
    daily: bool = typer.Option(False, "--daily", help="Daily token breakdown"),
    weekly: bool = typer.Option(False, "--weekly", help="Weekly token breakdown"),
    monthly: bool = typer.Option(False, "--monthly", help="Monthly token breakdown"),
    all_breakdowns: bool = typer.Option(
        False,
        "--all",
        help="Show daily, weekly, and monthly breakdowns",
    ),
    quota: bool = typer.Option(
        False,
        "--quota",
        help="Estimate dollar value of tokens saved (illustrative rates)",
    ),
    tier: str = typer.Option(
        "pro",
        "--tier",
        help="Pricing tier for --quota: pro | 5x | 20x",
        case_sensitive=False,
    ),
    agent: str | None = typer.Option(
        None,
        "--agent",
        "-a",
        help="Filter by agent name (e.g., 'jules', 'claude')",
    ),
) -> None:
    """Show token savings and adoption metrics."""
    fmt = output_format.lower()
    if fmt not in ("text", "json", "csv"):
        raise typer.BadParameter("format must be one of: text, json, csv")

    tier_key = tier.lower()
    if tier_key not in _TIER_USD_PER_MILLION:
        raise typer.BadParameter("tier must be one of: pro, 5x, 20x")

    with get_db_connection() as conn:
        raw_tokens_total, ptk_tokens_total, savings, reduction_pct = _totals(conn, project, agent)
        labels, daily_vals = _daily_savings_series(conn, project, agent, days=14)
        failure_rows = _failures(conn) if failures else []

        show_daily = daily or all_breakdowns
        show_weekly = weekly or all_breakdowns
        show_monthly = monthly or all_breakdowns

        breakdown_daily = _breakdown(conn, project, agent, "day") if show_daily else []
        breakdown_weekly = _breakdown(conn, project, agent, "week") if show_weekly else []
        breakdown_monthly = _breakdown(conn, project, agent, "month") if show_monthly else []

        hist_rows: list[tuple[str, str, str, int]] = []
        if history:
            try:
                where_clauses = []
                params = []
                if project:
                    where_clauses.append("project = ?")
                    params.append(project)
                if agent:
                    where_clauses.append("agent = ?")
                    params.append(agent)

                where_str = f" WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
                q = (
                    "SELECT timestamp, agent, ptk_cmd, raw_tokens, ptk_tokens FROM commands "
                    f"{where_str} ORDER BY timestamp DESC LIMIT 10"
                )
                cursor = conn.execute(q, params)
                for ts, a_name, cmd, r_tok, p_tok in cursor.fetchall():
                    dt = datetime.datetime.fromtimestamp(int(ts)).strftime("%Y-%m-%d %H:%M:%S")
                    hist_rows.append(
                        (dt, str(a_name or "shell"), str(cmd), int(r_tok or 0) - int(p_tok or 0))
                    )
            except sqlite3.OperationalError:
                pass

    usd_estimate = (savings / 1_000_000.0) * _TIER_USD_PER_MILLION[tier_key] if quota else None
    spark = _sparkline_from_counts(daily_vals) if graph else ""

    payload: dict[str, Any] = {
        "project": project,
        "total_raw_tokens": raw_tokens_total,
        "total_ptk_tokens": ptk_tokens_total,
        "tokens_saved": savings,
        "reduction_percent": round(reduction_pct, 2),
        "db_path": str(get_db_path()),
    }
    if quota and usd_estimate is not None:
        payload["quota_tier"] = tier_key
        payload["estimated_savings_usd"] = round(usd_estimate, 4)
    if graph:
        payload["sparkline_daily_labels"] = labels
        payload["sparkline_daily_savings"] = daily_vals
        payload["sparkline"] = spark
    if history:
        payload["history"] = [
            {"at": a, "agent": b, "command": c, "saved": d} for a, b, c, d in hist_rows
        ]
    if failures:
        payload["failures"] = [
            {"timestamp": ts, "raw_cmd": c, "error": e, "ran_ok": bool(ok)}
            for ts, c, e, ok in failure_rows
        ]
    if show_daily:
        payload["breakdown_daily"] = [
            {"period": p, "raw": r, "ptk": t, "saved": s} for p, r, t, s in breakdown_daily
        ]
    if show_weekly:
        payload["breakdown_weekly"] = [
            {"period": p, "raw": r, "ptk": t, "saved": s} for p, r, t, s in breakdown_weekly
        ]
    if show_monthly:
        payload["breakdown_monthly"] = [
            {"period": p, "raw": r, "ptk": t, "saved": s} for p, r, t, s in breakdown_monthly
        ]

    if fmt == "json":
        typer.echo(json.dumps(payload, indent=2))
        return

    if fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["metric", "value"])
        w.writerow(["total_raw_tokens", raw_tokens_total])
        w.writerow(["total_ptk_tokens", ptk_tokens_total])
        w.writerow(["tokens_saved", savings])
        w.writerow(["reduction_percent", f"{reduction_pct:.2f}"])
        if quota and usd_estimate is not None:
            w.writerow(["quota_tier", tier_key])
            w.writerow(["estimated_savings_usd", f"{usd_estimate:.6f}"])
        for row in breakdown_daily:
            w.writerow(["daily", *row])
        for row in breakdown_weekly:
            w.writerow(["weekly", *row])
        for row in breakdown_monthly:
            w.writerow(["monthly", *row])
        typer.echo(buf.getvalue().strip())
        return

    # text (rich)
    table = Table(title="Token Usage Summary", show_header=False, box=None)
    table.add_row("Total Raw Tokens", f"[bold red]{raw_tokens_total:,}[/bold red]")
    table.add_row("Total PTK Tokens", f"[bold green]{ptk_tokens_total:,}[/bold green]")
    table.add_row("Tokens Saved", f"[bold blue]{savings:,}[/bold blue]")
    table.add_row("Reduction", f"[bold cyan]{reduction_pct:.1f}%[/bold cyan]")

    panel_title = f"PTK Gain Dashboard"
    if project:
        panel_title += f" [dim]({project})[/dim]"
    if agent:
        panel_title += f" [bold yellow]({agent})[/bold yellow]"
    console.print(Panel(table, title=panel_title, expand=False, border_style="blue"))

    if quota and usd_estimate is not None:
        console.print(
            f"[dim]Quota estimate ({tier_key} tier): ~${usd_estimate:.4f} USD "
            "(illustrative; see docs)[/dim]",
        )

    if graph:
        if spark:
            console.print(f"[bold]14d savings sparkline:[/bold] {spark}")
            if labels:
                console.print(f"[dim]{labels[0]} … {labels[-1]}[/dim]")
        else:
            console.print("[dim]No data yet for sparkline.[/dim]")

    if show_daily and breakdown_daily:
        t = Table(title="Daily breakdown", box=None)
        t.add_column("Period")
        t.add_column("Saved", justify="right")
        for p, _r, _pt, s in breakdown_daily[:12]:
            t.add_row(p, f"{s:,}")
        console.print(t)
    if show_weekly and breakdown_weekly:
        t = Table(title="Weekly breakdown", box=None)
        t.add_column("Period")
        t.add_column("Saved", justify="right")
        for p, _r, _pt, s in breakdown_weekly[:12]:
            t.add_row(p, f"{s:,}")
        console.print(t)
    if show_monthly and breakdown_monthly:
        t = Table(title="Monthly breakdown", box=None)
        t.add_column("Period")
        t.add_column("Saved", justify="right")
        for p, _r, _pt, s in breakdown_monthly[:12]:
            t.add_row(p, f"{s:,}")
        console.print(t)

    if history and hist_rows:
        history_table = Table(title="Recent Commands", box=None)
        history_table.add_column("Timestamp", style="dim")
        history_table.add_column("Agent", style="yellow")
        history_table.add_column("Command")
        history_table.add_column("Saved", justify="right", style="green")
        for dt, a_name, cmd, saved in hist_rows:
            history_table.add_row(dt, a_name, cmd, f"{saved:,}")
        console.print(history_table)

    if failures:
        if failure_rows:
            ft = Table(title="Recent parse failures", box=None)
            ft.add_column("When", style="dim")
            ft.add_column("Command")
            ft.add_column("Error")
            for ts, cmd, err, ok in failure_rows:
                dt = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
                ok_note = "ok" if ok else "fail"
                ft.add_row(
                    dt,
                    cmd[:60],
                    (err[:80] + ("…" if len(err) > 80 else "")) + f" [{ok_note}]",
                )
            console.print(ft)
        else:
            console.print("[dim]No parse failures recorded.[/dim]")


if __name__ == "__main__":
    gain_app()
