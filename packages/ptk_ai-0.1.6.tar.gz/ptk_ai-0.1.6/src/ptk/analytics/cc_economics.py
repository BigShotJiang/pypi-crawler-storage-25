import typer
from rich.console import Console

cc_economics_app = typer.Typer(help="Claude Code usage vs token savings")
console = Console()


@cc_economics_app.callback(invoke_without_command=True)
def cc_economics() -> None:
    """Cross-reference Claude Code usage costs vs token savings."""
    console.print("[dim italic]Claude Code economics feature coming soon...[/dim italic]")


if __name__ == "__main__":
    cc_economics_app()
