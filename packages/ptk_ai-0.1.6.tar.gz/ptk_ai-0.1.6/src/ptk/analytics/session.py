import typer
from rich.console import Console

session_app = typer.Typer(help="Session adoption rate tracking")
console = Console()


@session_app.callback(invoke_without_command=True)
def session() -> None:
    """Show adoption rate across recent agent sessions."""
    console.print("[dim italic]Session adoption feature coming soon...[/dim italic]")


if __name__ == "__main__":
    session_app()
