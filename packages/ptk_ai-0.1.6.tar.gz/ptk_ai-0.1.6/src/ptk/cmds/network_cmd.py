"""`ptk curl` and `ptk wget` — network CLIs with quieter, JSON-friendly output."""

from __future__ import annotations

import json
import re

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing

curl_app = typer.Typer(
    help="curl with JSON pretty-print when response looks like JSON",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

wget_app = typer.Typer(
    help="wget with progress bar lines stripped from captured output",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def _writes_to_file(args: list[str]) -> bool:
    if "-O" in args:
        return True
    for i, a in enumerate(args):
        if a in ("-o", "--output") and i + 1 < len(args):
            return True
        if a.startswith("--output="):
            return True
    return False


def _maybe_pretty_json(text: str, *, max_chars: int = 120_000) -> str | None:
    stripped = text.strip()
    if len(stripped) < 2 or stripped[0] not in "{[":
        return None
    try:
        data = json.loads(stripped)
    except (json.JSONDecodeError, ValueError):
        return None
    out = json.dumps(data, indent=2, ensure_ascii=False)
    if len(out) > max_chars:
        return out[:max_chars] + "\n... [ptk: JSON truncated]"
    return out


def _filter_wget_merged(text: str) -> str:
    """Keep summary / HTTP lines; drop typical progress noise."""
    lines: list[str] = []
    for ln in text.splitlines():
        s = ln.strip()
        if re.match(r"^\d+%", s):
            continue
        if re.match(r"^[#\.]+$", s):
            continue
        lines.append(ln)
    compact = "\n".join(FilterStrategy.deduplicate(lines))
    return compact if compact.strip() else text


@curl_app.callback(invoke_without_command=True)
def curl_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to curl",
    ),
) -> None:
    """Run curl; auto-indent JSON bodies on stdout when safe."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "curl " + " ".join(args)
    raw, err, code = run_capturing(["curl", *args])
    merged = raw + (f"\n{err}" if err.strip() else "")

    if _writes_to_file(args):
        filtered = merged
    else:
        pretty = _maybe_pretty_json(raw)
        filtered = pretty if pretty is not None else merged

    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


@wget_app.callback(invoke_without_command=True)
def wget_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to wget",
    ),
) -> None:
    """Run wget; strip spinner/progress lines from captured output."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "wget " + " ".join(args)
    raw, err, code = run_capturing(["wget", *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    filtered = _filter_wget_merged(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)
