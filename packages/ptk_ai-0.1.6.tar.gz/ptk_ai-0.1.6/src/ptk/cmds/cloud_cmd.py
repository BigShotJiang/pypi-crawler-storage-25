"""`ptk gh`, `ptk docker`, `ptk kubectl`, `ptk aws`, `ptk psql` — compact devops CLI output."""

from __future__ import annotations

import json
import re
import shutil

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing, run_streaming

gh_app = typer.Typer(
    help="GitHub CLI with compact text output",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

docker_app = typer.Typer(
    help="Docker CLI with compact output for ps/images/logs",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

kubectl_app = typer.Typer(
    help="kubectl with compact output for get/describe/logs",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

aws_app = typer.Typer(
    help="AWS CLI with JSON output and compact responses",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

psql_app = typer.Typer(
    help="psql with table borders stripped and compact rows",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def _merge_streams(stdout: str, stderr: str) -> str:
    return stdout + (f"\n{stderr}" if stderr.strip() else "")


def _compact_lines(raw: str, *, max_len: int = 220, tail: int | None = None) -> str:
    lines = raw.splitlines()
    if tail is not None and len(lines) > tail:
        extra = len(lines) - tail
        lines = lines[-tail:]
        suffix = f"\n... [{extra} lines truncated]"
    else:
        suffix = ""
    body = "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines), max_len=max_len))
    return body + suffix


def _ensure_aws_json_output(args: list[str]) -> list[str]:
    """Append `--output json` when absent; skip for help/configure entry points."""
    if "--output" in args or any(a.startswith("--output=") for a in args):
        return args
    non_flags = [a for a in args if not a.startswith("-")]
    if not non_flags:
        return args
    if non_flags[0].lower() in ("help", "configure"):
        return args
    return [*args, "--output", "json"]


def _filter_aws_output(raw: str, err: str) -> str:
    """Minify JSON stdout when possible; compact stderr."""
    raw_s = raw.strip()
    if raw_s and raw_s[0] in "{[":
        try:
            obj = json.loads(raw_s)
            body = json.dumps(obj, separators=(",", ":"))
        except json.JSONDecodeError:
            body = _compact_lines(raw)
    else:
        body = _compact_lines(raw)
    max_chars = 400_000
    if len(body) > max_chars:
        body = body[:max_chars] + "\n... [truncated]"
    err_f = _compact_lines(err, max_len=200) if err.strip() else ""
    return body + (f"\n{err_f}" if err_f else "")


_PSQL_BOX = re.compile(r"[\u2500-\u257f\u2550-\u256c\u2502]+")


def _strip_psql_table_noise(line: str) -> str:
    s = _PSQL_BOX.sub(" ", line)
    s = re.sub(r" {2,}", " ", s).strip()
    return s


def _filter_psql_output(raw: str) -> str:
    lines: list[str] = []
    for ln in raw.splitlines():
        stripped = _strip_psql_table_noise(ln)
        if not stripped:
            continue
        if set(stripped) <= {"-", "=", " "}:
            continue
        lines.append(stripped)
    return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines), max_len=240))


@gh_app.callback(invoke_without_command=True)
def gh_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to gh",
    ),
) -> None:
    """Run gh; pass through JSON untouched, compact plain text."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "gh " + " ".join(args)
    raw, err, code = run_capturing(["gh", *args])
    merged = _merge_streams(raw, err)
    joined = " ".join(args)
    filtered = merged if "--json" in joined else _compact_lines(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


def _docker_follow_logs(args: list[str]) -> bool:
    return args[0] == "logs" and ("-f" in args or "--follow" in args)


@docker_app.callback(invoke_without_command=True)
def docker_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to docker",
    ),
) -> None:
    """Run docker; capture+compact common read-only commands."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "docker " + " ".join(args)

    if _docker_follow_logs(args):
        code = run_streaming(["docker", *args])
        timer.track(label, f"ptk {label}", "", "")
        if code != 0:
            raise typer.Exit(code)
        return

    if args[0] in ("ps", "images", "info", "version", "inspect"):
        raw, err, code = run_capturing(["docker", *args])
        merged = _merge_streams(raw, err)
        filtered = _compact_lines(merged, max_len=200)
        emit_filtered_output(merged, filtered)
        timer.track(label, f"ptk {label}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    if args[0] == "logs":
        raw, err, code = run_capturing(["docker", *args])
        merged = _merge_streams(raw, err)
        filtered = _compact_lines(merged, tail=300, max_len=240)
        emit_filtered_output(merged, filtered)
        timer.track(label, f"ptk {label}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    code = run_streaming(["docker", *args])
    timer.track(label, f"ptk {label}", "", "")
    if code != 0:
        raise typer.Exit(code)


def _kubectl_streaming(args: list[str]) -> bool:
    if not args:
        return False
    if args[0] == "logs" and ("-f" in args or "--follow" in args):
        return True
    return args[0] in ("attach", "exec", "port-forward")


@kubectl_app.callback(invoke_without_command=True)
def kubectl_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to kubectl",
    ),
) -> None:
    """Run kubectl; stream attach/exec/follow logs; compact typical reads."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "kubectl " + " ".join(args)

    if _kubectl_streaming(args):
        code = run_streaming(["kubectl", *args])
        timer.track(label, f"ptk {label}", "", "")
        if code != 0:
            raise typer.Exit(code)
        return

    watch_mode = "-w" in args or "--watch" in args
    if not watch_mode and args[0] in (
        "get",
        "describe",
        "logs",
        "top",
        "api-resources",
        "version",
        "cluster-info",
    ):
        raw, err, code = run_capturing(["kubectl", *args])
        merged = _merge_streams(raw, err)
        tail = 400 if args[0] == "logs" else None
        filtered = _compact_lines(merged, max_len=220, tail=tail)
        emit_filtered_output(merged, filtered)
        timer.track(label, f"ptk {label}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    code = run_streaming(["kubectl", *args])
    timer.track(label, f"ptk {label}", "", "")
    if code != 0:
        raise typer.Exit(code)


@aws_app.callback(invoke_without_command=True)
def aws_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to aws",
    ),
) -> None:
    """Run AWS CLI; default to JSON and minify structured output."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    aws_bin = shutil.which("aws")
    if not aws_bin:
        typer.echo("ptk aws: `aws` not found on PATH.", err=True)
        raise typer.Exit(127)

    timer = TimedExecution.start()
    label = "aws " + " ".join(args)
    exec_args = _ensure_aws_json_output(args)
    raw, err, code = run_capturing([aws_bin, *exec_args])
    merged = _merge_streams(raw, err)
    filtered = _filter_aws_output(raw, err)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


@psql_app.callback(invoke_without_command=True)
def psql_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to psql",
    ),
) -> None:
    """Run psql with ASCII table decoration stripped."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    psql_bin = shutil.which("psql")
    if not psql_bin:
        typer.echo("ptk psql: `psql` not found on PATH.", err=True)
        raise typer.Exit(127)

    timer = TimedExecution.start()
    label = "psql " + " ".join(args)
    raw, err, code = run_capturing([psql_bin, *args])
    merged = _merge_streams(raw, err)
    filtered = _filter_psql_output(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)
