"""`ptk wc` — word-count output with normalized spacing."""

from __future__ import annotations

import re
import shutil
import subprocess
import sys

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing

wc_app = typer.Typer(
    help="wc(1) with compact, width-capped lines",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def _filter_wc_output(raw: str) -> str:
    """Collapse padding; drop redundant path columns when line is counts + path."""
    lines_out: list[str] = []
    for ln in raw.splitlines():
        s = re.sub(r"\s+", " ", ln.strip())
        parts = s.split(" ")
        if len(parts) >= 4 and all(p.isdigit() for p in parts[:3]):
            lines_out.append(" ".join(parts[:3]))
        else:
            lines_out.append(s)
    return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines_out), max_len=200))


def _run_wc(args: list[str]) -> tuple[str, str, int]:
    wc_exe = shutil.which("wc")
    if not wc_exe:
        return "", "ptk wc: `wc` not found on PATH.", 127
    if not args:
        result = subprocess.run(
            [wc_exe],
            stdin=sys.stdin,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        return result.stdout, result.stderr or "", result.returncode or 0
    return run_capturing(["wc", *args])


@wc_app.callback(invoke_without_command=True)
def wc_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to wc (omit to read stdin)",
    ),
) -> None:
    """Run wc; normalize whitespace and drop file paths when counts are present."""
    if not args and sys.stdin.isatty():
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = ("wc " + " ".join(args)).strip() or "wc"
    raw, err, code = _run_wc(args)
    merged = raw + (f"\n{err}" if err.strip() else "")
    filtered = _filter_wc_output(merged) if merged.strip() else merged
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)
