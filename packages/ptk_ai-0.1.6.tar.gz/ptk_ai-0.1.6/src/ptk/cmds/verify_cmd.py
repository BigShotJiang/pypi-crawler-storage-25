"""`ptk verify` — run `[[test]]` / `[[tests]]` blocks from `.ptk.toml`."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from rich.console import Console

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]

from ptk.core.toml_filter import apply_filter, select_filter_for_command
from ptk.core.trust_store import find_ptk_toml

console = Console()


def _tests_from_data(data: dict[str, Any]) -> list[dict[str, Any]]:
    raw = data.get("test")
    if raw is None:
        raw = data.get("tests")
    if raw is None:
        return []
    if isinstance(raw, list):
        return [x for x in raw if isinstance(x, dict)]
    if isinstance(raw, dict):
        return [raw]
    return []


def cmd_verify(
    path: Path | None = typer.Option(  # noqa: B008
        None,
        "--path",
        "-p",
        help="Directory to start search for .ptk.toml (default: cwd)",
    ),
) -> None:
    """Execute inline filter tests declared in `.ptk.toml`."""
    start = (path or Path.cwd()).resolve()
    toml_path = find_ptk_toml(start)
    if toml_path is None:
        console.print("[red]No .ptk.toml found.[/red]")
        raise typer.Exit(1)

    try:
        with toml_path.open("rb") as handle:
            data = tomllib.load(handle)
    except OSError as exc:
        console.print(f"[red]Could not read {toml_path}: {exc}[/red]")
        raise typer.Exit(1) from exc

    cases = _tests_from_data(data)
    if not cases:
        console.print("[yellow]No [[test]] or [[tests]] blocks in .ptk.toml.[/yellow]")
        raise typer.Exit(0)

    failed = 0
    for i, case in enumerate(cases, start=1):
        name = str(case.get("name", f"case-{i}"))
        match_cmd = str(case.get("match_command", "cmd"))
        input_text = case.get("input")
        if not isinstance(input_text, str):
            console.print(f"[red]{name}: missing string 'input'[/red]")
            failed += 1
            continue

        filt = select_filter_for_command(data, match_cmd)
        if filt is None:
            console.print(f"[red]{name}: no filter matches match_command={match_cmd!r}[/red]")
            failed += 1
            continue

        got = apply_filter(filt, input_text)
        expected = case.get("expected")
        substr = case.get("expect_contains")

        ok = False
        if isinstance(expected, str):
            ok = got == expected
        elif isinstance(substr, str):
            ok = substr in got
        else:
            console.print(f"[red]{name}: need 'expected' or 'expect_contains'[/red]")
            failed += 1
            continue

        if ok:
            console.print(f"[green]OK[/green]  {name}")
        else:
            failed += 1
            console.print(f"[red]FAIL[/red] {name}")
            if isinstance(expected, str):
                console.print(f"  expected: {expected!r}")
            if isinstance(substr, str):
                console.print(f"  expect_contains: {substr!r}")
            console.print(f"  got: {got!r}")

    if failed:
        raise typer.Exit(1)
