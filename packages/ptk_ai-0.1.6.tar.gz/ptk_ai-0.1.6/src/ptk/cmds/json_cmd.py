"""`ptk json` — depth-limited JSON pretty-print and structural (--schema) view."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import TypeAlias, cast

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.tracking import TimedExecution

json_app = typer.Typer(
    help="Format JSON from a file or stdin with depth limits",
    add_completion=False,
    invoke_without_command=True,
)

_MAX_EMIT_CHARS = 500_000

JSONNode: TypeAlias = dict[str, "JSONNode"] | list["JSONNode"] | str | int | float | bool | None


def _limit_depth(obj: JSONNode, depth: int, *, max_list: int = 80) -> JSONNode | str:
    """Replace deep nodes with ellipsis; cap long arrays."""
    if depth <= 0:
        return "…"
    if isinstance(obj, dict):
        out: dict[str, JSONNode | str] = {}
        for k, v in obj.items():
            out[str(k)] = _limit_depth(v, depth - 1, max_list=max_list)
        return out
    if isinstance(obj, list):
        head = [_limit_depth(x, depth - 1, max_list=max_list) for x in obj[:max_list]]
        if len(obj) > max_list:
            head.append(f"…({len(obj) - max_list} more)")
        return head
    if isinstance(obj, str) and len(obj) > 2000:
        return obj[:2000] + "…"
    return obj


def _schema_skeleton(obj: JSONNode, depth: int) -> JSONNode | str:
    """Emit types / shapes instead of values (no extra dependencies)."""
    if depth <= 0:
        return "…"
    if isinstance(obj, dict):
        sk: dict[str, JSONNode | str] = {}
        for k, v in obj.items():
            sk[str(k)] = _schema_skeleton(v, depth - 1)
        return sk
    if isinstance(obj, list):
        if not obj:
            return []
        inner = _schema_skeleton(obj[0], depth - 1)
        return [inner] if len(obj) == 1 else [inner, f"…({len(obj)} items)"]
    if obj is None:
        return "null"
    if isinstance(obj, bool):
        return "bool"
    if isinstance(obj, int):
        return "int"
    if isinstance(obj, float):
        return "float"
    if isinstance(obj, str):
        return "string"
    return "any"


def _load_json_text(path: str | None) -> str:
    if path is None or path == "-":
        return sys.stdin.read()
    p = Path(path)
    return p.read_text(encoding="utf-8")


@json_app.callback(invoke_without_command=True)
def json_fmt(
    ctx: typer.Context,
    path: str | None = typer.Argument(  # noqa: B008
        None,
        help="JSON file path, or '-' / omit for stdin",
    ),
    depth: int = typer.Option(12, "--depth", "-d", min=1, max=64, help="Max nesting depth"),
    schema: bool = typer.Option(
        False,
        "--schema",
        "-s",
        help="Print type skeleton instead of values",
    ),
    compact: bool = typer.Option(False, "--compact", "-c", help="Single-line JSON"),
) -> None:
    """Parse JSON and print a depth-limited view (or --schema outline)."""
    if path is None and sys.stdin.isatty():
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    label = "json " + (path or "-")
    try:
        text = _load_json_text(path)
    except OSError as e:
        typer.echo(f"ptk json: {e}", err=True)
        raise typer.Exit(1) from e

    merged = text
    try:
        data = cast(JSONNode, json.loads(text))
    except json.JSONDecodeError as e:
        typer.echo(f"ptk json: invalid JSON: {e}", err=True)
        raise typer.Exit(1) from e

    shaped: JSONNode | str = _schema_skeleton(data, depth) if schema else _limit_depth(data, depth)
    if compact:
        filtered = json.dumps(shaped, separators=(",", ":"), ensure_ascii=False)
    else:
        filtered = json.dumps(shaped, indent=2, ensure_ascii=False)
    if len(filtered) > _MAX_EMIT_CHARS:
        filtered = filtered[:_MAX_EMIT_CHARS] + "\n… [truncated]"

    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
