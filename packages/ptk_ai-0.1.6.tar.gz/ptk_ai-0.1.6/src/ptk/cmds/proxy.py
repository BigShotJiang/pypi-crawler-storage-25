import shutil
import subprocess

import typer

from ptk.core.tracking import TimedExecution

proxy_app = typer.Typer(help="Execute a command directly but track usage")


@proxy_app.callback(invoke_without_command=True)
def proxy(
    ctx: typer.Context,
    args: list[str] = typer.Argument(default_factory=list, help="Command to execute"),  # noqa: B008
) -> None:
    """Run an unfiltered command but log analytics."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    cmd_str = " ".join(args)
    timer = TimedExecution.start()

    exe = shutil.which(args[0])
    if exe is None:
        missing = args[0]
        typer.secho(f"[ptk: command not found: {missing}]", err=True)
        raise typer.Exit(127)

    result = subprocess.run(
        [exe, *args[1:]],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )

    out = result.stdout or ""
    err = result.stderr or ""
    if out:
        typer.echo(out, nl=False)
    if err:
        typer.secho(err, err=True, nl=False)

    raw_combined = out if not err else out + err
    timer.track(cmd_str, f"ptk proxy {cmd_str}", raw_combined, raw_combined)

    if result.returncode != 0:
        raise typer.Exit(result.returncode)


if __name__ == "__main__":
    proxy_app()
