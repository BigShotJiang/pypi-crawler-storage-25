"""`ptk env`, `ptk tree`, `ptk diff` — environment, tree listings, and unified diff."""

from __future__ import annotations

import re
import shutil
import sys

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing

_SENSITIVE_KEY = re.compile(
    r"(?i)(password|passwd|secret|token|api_?key|auth|credential|bearer|private|access_?key)"
)


def _mask_env_line(line: str) -> str:
    """Redact values for keys that look sensitive."""
    if "=" not in line:
        return line
    key, _, _val = line.partition("=")
    k = key.strip()
    if _SENSITIVE_KEY.search(k):
        return f"{key}=***"
    ku = k.upper()
    if ku.endswith(("_TOKEN", "_SECRET", "_PASSWORD")):
        return f"{key}=***"
    if ku.endswith(("_API_KEY", "_ACCESS_KEY", "_PRIVATE_KEY")):
        return f"{key}=***"
    return line


def _filter_env_output(raw: str) -> str:
    lines = raw.splitlines()
    masked = [_mask_env_line(ln) for ln in lines]
    return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(masked), max_len=240))


def _run_env_listing(args: list[str]) -> tuple[str, str, int]:
    """Run `env` or a platform fallback for variable listing."""
    env_bin = shutil.which("env")
    if env_bin:
        return run_capturing([env_bin, *args])
    if args:
        return (
            "",
            "ptk env: `env` not found on PATH; install coreutils or use a Unix shell.",
            127,
        )
    if sys.platform == "win32":
        return run_capturing(["cmd", "/c", "set"])
    return "", "ptk env: `env` not found.", 127


def _filter_tree_output(raw: str) -> str:
    lines = raw.splitlines()
    tail = 400
    if len(lines) > tail:
        extra = len(lines) - tail
        body = "\n".join(
            FilterStrategy.truncate(FilterStrategy.deduplicate(lines[-tail:]), max_len=200)
        )
        return f"{body}\n... [{extra} lines truncated]"
    return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines), max_len=200))


def _filter_plain_diff(raw: str) -> str:
    """Keep unified-diff structure and changed lines; drop context."""
    lines = raw.splitlines()
    out: list[str] = []
    for line in lines:
        if (
            line.startswith("--- ")
            or line.startswith("+++ ")
            or line.startswith("@@ ")
            or (line.startswith("+") and not line.startswith("+++"))
            or (line.startswith("-") and not line.startswith("---"))
        ):
            out.append(line)
    return "\n".join(out) if out else raw


env_app = typer.Typer(
    help="Environment listing with sensitive values masked",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

tree_app = typer.Typer(
    help="tree(1) with deduplicated, width-capped lines",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

diff_app = typer.Typer(
    help="diff(1) with unified-diff lines only (no context)",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


@env_app.callback(invoke_without_command=True)
def env_cmd(
    _ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to env when available",
    ),
) -> None:
    """Print environment; mask likely secrets in KEY=value lines."""
    timer = TimedExecution.start()
    label = ("env " + " ".join(args)).strip() or "env"
    raw, err, code = _run_env_listing(args)
    merged = raw + (f"\n{err}" if err.strip() else "")
    filtered = _filter_env_output(merged) if merged.strip() else merged
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


@tree_app.callback(invoke_without_command=True)
def tree_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to tree",
    ),
) -> None:
    """Run tree(1) with long output truncated."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    tree_bin = shutil.which("tree")
    if not tree_bin:
        typer.echo("ptk tree: `tree` not found on PATH.", err=True)
        raise typer.Exit(127)

    timer = TimedExecution.start()
    label = "tree " + " ".join(args)
    raw, err, code = run_capturing([tree_bin, *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    filtered = _filter_tree_output(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)


@diff_app.callback(invoke_without_command=True)
def diff_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to diff",
    ),
) -> None:
    """Run diff(1); emit only headers and +/- lines for unified diffs."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    diff_bin = shutil.which("diff")
    if not diff_bin:
        typer.echo("ptk diff: `diff` not found on PATH.", err=True)
        raise typer.Exit(127)

    timer = TimedExecution.start()
    label = "diff " + " ".join(args)
    raw, err, code = run_capturing([diff_bin, *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    filtered = _filter_plain_diff(merged)
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)
