"""`ptk run` — execute any command and apply a matching trusted `.ptk.toml` filter when found."""

from __future__ import annotations

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.toml_filter import apply_filter, find_matching_filter
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing


def cmd_run(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Command and arguments to execute (e.g. mytool build --release)",
    ),
) -> None:
    """Run a command; if `.ptk.toml` defines a matching filter, apply it to stdout+stderr text."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    cmd_str = " ".join(args)
    filt = find_matching_filter(cmd_str)
    timer = TimedExecution.start()
    raw, err, code = run_capturing(args)
    combined = raw + (f"\n{err}" if err.strip() else "")
    filtered = apply_filter(filt, combined) if filt is not None else combined
    emit_filtered_output(combined, filtered)
    timer.track(cmd_str, f"ptk run {cmd_str}", combined, filtered)
    if code != 0:
        raise typer.Exit(code)
