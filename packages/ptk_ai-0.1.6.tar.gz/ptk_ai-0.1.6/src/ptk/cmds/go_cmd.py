"""`ptk go` — compact `go test`, `go build`, and `go vet` output."""

from __future__ import annotations

import json
import re
import shutil

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing, run_streaming

go_app = typer.Typer(
    help="Go toolchain with condensed test/build/vet output",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

_GO_FILE_LOC = re.compile(r"\.go:\d+:")


def _ensure_go_test_json(args: list[str]) -> list[str]:
    if not args or args[0] != "test":
        return args
    if "-json" in args:
        return args
    return ["test", "-json", *args[1:]]


def _filter_go_test_json(raw: str) -> str:
    """Keep failing tests and error-like output from `go test -json` lines."""
    out: list[str] = []
    for line in raw.splitlines():
        if not line.strip():
            continue
        try:
            o = json.loads(line)
        except json.JSONDecodeError:
            out.append(line)
            continue
        act = o.get("Action")
        text = o.get("Output") or "" if act == "output" else ""
        keep = act == "fail" or (
            act == "output"
            and (
                "FAIL" in text
                or "panic:" in text.lower()
                or "--- FAIL:" in text
                or "undefined:" in text
                or "cannot " in text.lower()
            )
        )
        if keep:
            out.append(line)
    if out:
        return "\n".join(out)
    tail = raw.splitlines()[-20:]
    return "\n".join(tail) if tail else raw


def _filter_go_build(raw: str) -> str:
    lines = raw.splitlines()
    picked = [
        ln
        for ln in lines
        if "error:" in ln
        or _GO_FILE_LOC.search(ln)
        or (ln.strip().startswith("# ") and "pkg" in ln)
    ]
    if picked:
        return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(picked), max_len=280))
    return "\n".join(lines[-45:])


def _filter_go_vet(raw: str) -> str:
    lines = raw.splitlines()
    return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines), max_len=260))


@go_app.callback(invoke_without_command=True)
def go_entry(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to go",
    ),
) -> None:
    """Run go; compress test JSON, build errors, and vet diagnostics."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    if not shutil.which("go"):
        typer.echo("ptk go: `go` not found on PATH.", err=True)
        raise typer.Exit(127)

    sub = args[0]
    timer = TimedExecution.start()
    label = "go " + " ".join(args)

    if sub == "test":
        exec_args = _ensure_go_test_json(args)
        raw, err, code = run_capturing(["go", *exec_args])
        merged = raw + (f"\n{err}" if err.strip() else "")
        filtered = _filter_go_test_json(merged)
        emit_filtered_output(merged, filtered)
        timer.track(label, f"ptk {label}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    if sub == "build":
        raw, err, code = run_capturing(["go", *args])
        merged = raw + (f"\n{err}" if err.strip() else "")
        filtered = _filter_go_build(merged)
        emit_filtered_output(merged, filtered)
        timer.track(label, f"ptk {label}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    if sub == "vet":
        raw, err, code = run_capturing(["go", *args])
        merged = raw + (f"\n{err}" if err.strip() else "")
        filtered = _filter_go_vet(merged)
        emit_filtered_output(merged, filtered)
        timer.track(label, f"ptk {label}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    code = run_streaming(["go", *args])
    timer.track(label, f"ptk {label}", "", "")
    if code != 0:
        raise typer.Exit(code)
