"""`ptk trust` / `ptk untrust` — manage `.ptk.toml` trust lockfile."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from ptk.core.trust_store import find_ptk_toml, record_trust, revoke_trust

console = Console()


def cmd_trust(
    path: Path | None = typer.Option(  # noqa: B008
        None,
        "--path",
        "-p",
        help="Directory to treat as project root (default: search upward from cwd)",
    ),
) -> None:
    """Record SHA256 of the nearest `.ptk.toml` so trusted filters can run."""
    start = (path or Path.cwd()).resolve()
    toml = find_ptk_toml(start)
    if toml is None:
        console.print("[red]No .ptk.toml found in this tree.[/red]")
        raise typer.Exit(1)
    project_root = toml.parent
    digest = record_trust(project_root)
    console.print(f"[green]Trusted[/green] {project_root}  [dim](sha256={digest[:12]}…)[/dim]")


def cmd_untrust(
    path: Path | None = typer.Option(  # noqa: B008
        None,
        "--path",
        "-p",
        help="Directory to start search for .ptk.toml (default: cwd)",
    ),
) -> None:
    """Remove trust entry for the project that owns the nearest `.ptk.toml`."""
    start = (path or Path.cwd()).resolve()
    toml = find_ptk_toml(start)
    if toml is None:
        console.print("[yellow]No .ptk.toml found; nothing to untrust.[/yellow]")
        raise typer.Exit(0)
    project_root = toml.parent
    if revoke_trust(project_root):
        console.print(f"[green]Removed trust[/green] for {project_root}")
    else:
        console.print(f"[yellow]No trust entry[/yellow] for {project_root}")
