"""`ptk cat` — token-safe file reading."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing

cat_app = typer.Typer(
    help="Token-safe file reading; truncates massive files by default",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def _is_binary(content: bytes) -> bool:
    """Heuristic check for binary content (null bytes)."""
    return b"\x00" in content


@cat_app.callback(invoke_without_command=True)
def cat_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(
        default_factory=list,
        help="Arguments forwarded to cat",
    ),
    max_lines: int = typer.Option(800, "--max-lines", "-n", help="Max lines to emit before truncating"),
) -> None:
    """Read files with automatic truncation and binary safety."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    cat_bin = shutil.which("cat")
    # On Windows, cat might not exist; we fallback to a native python read if needed
    if not cat_bin and os.name == "nt":
        # Simulate simple cat for the first argument
        timer = TimedExecution.start()
        path = Path(args[0])
        if not path.exists():
            typer.echo(f"ptk cat: {path}: No such file or directory", err=True)
            raise typer.Exit(1)
        
        try:
            raw_bytes = path.read_bytes()
            if _is_binary(raw_bytes[:1024]):
                typer.echo(f"ptk cat: {path}: Binary file detected; skipping.", err=True)
                raise typer.Exit(0)
            
            raw = raw_bytes.decode("utf-8", errors="replace")
            lines = raw.splitlines()
            if len(lines) > max_lines:
                filtered = "\n".join(lines[:max_lines]) + f"\n\n... [{len(lines) - max_lines} lines truncated for token efficiency]"
            else:
                filtered = raw
            
            emit_filtered_output(raw, filtered)
            timer.track(f"cat {args[0]}", f"ptk cat {args[0]}", raw, filtered)
            return
        except Exception as e:
            typer.echo(f"ptk cat: error reading {path}: {e}", err=True)
            raise typer.Exit(1)

    # Standard path: use shell cat and filter output
    if not cat_bin:
        typer.echo("ptk cat: `cat` not found on PATH.", err=True)
        raise typer.Exit(127)

    timer = TimedExecution.start()
    label = "cat " + " ".join(args)
    raw, err, code = run_capturing([cat_bin, *args])
    merged = raw + (f"\n{err}" if err.strip() else "")
    
    # Filter logic: truncate lines
    lines = merged.splitlines()
    if len(lines) > max_lines:
        filtered = "\n".join(lines[:max_lines]) + f"\n\n... [{len(lines) - max_lines} lines truncated for token efficiency]"
    else:
        filtered = merged
    
    emit_filtered_output(merged, filtered)
    timer.track(label, f"ptk {label}", merged, filtered)
    if code != 0:
        raise typer.Exit(code)
