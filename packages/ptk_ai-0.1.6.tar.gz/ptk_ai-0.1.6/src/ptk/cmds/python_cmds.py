"""Python toolchain entry points (pytest, ruff, mypy, pip) and `uv pip`."""

from __future__ import annotations

import re
import sys
from collections import defaultdict

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing, run_streaming

pytest_app = typer.Typer(
    help="Run pytest with compact, failure-focused output",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

ruff_app = typer.Typer(
    help="Run ruff with violations grouped by rule code",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

mypy_app = typer.Typer(
    help="Run mypy with diagnostics grouped by file",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

pip_app = typer.Typer(
    help="Run pip with progress noise stripped",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

uv_app = typer.Typer(
    help="Run uv (compact output when using the pip subcommand)",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def _filter_pytest_output(raw: str) -> str:
    """Keep failure/summary lines; on green runs, keep a short tail."""
    lines = raw.splitlines()
    needles = (
        "failed",
        "error",
        "short test summary",
        "passed in",
        "warnings summary",
        "====",
        "___ ",
    )
    picked = [
        ln
        for ln in lines
        if any(n in ln.lower() for n in needles) or ("FAIL" in ln and "pytest" not in ln.lower())
    ]
    if picked:
        return "\n".join(FilterStrategy.deduplicate(picked))
    return "\n".join(lines[-25:])


_RUFF_RULE = re.compile(r":\s+([A-Z]{1,12}[0-9]+)\s+")


def _filter_ruff_output(raw: str) -> str:
    """Group ruff text diagnostics by rule code (E501, F401, …)."""
    lines = raw.splitlines()
    if not lines:
        return raw
    buckets: dict[str, list[str]] = defaultdict(list)
    order: list[str] = []
    for line in lines:
        m = _RUFF_RULE.search(line)
        key = m.group(1) if m else ""
        if key not in buckets:
            order.append(key)
        buckets[key].append(line)
    out: list[str] = []
    for key in order:
        label = key if key else "(other)"
        out.append(f"--- {label} ---")
        chunk = buckets[key]
        out.extend(chunk[:40])
        extra = len(chunk) - 40
        if extra > 0:
            out.append(f"... {extra} more")
    return "\n".join(out)


_MYPY_LOC = re.compile(r"^(.+?):\d+:\s*(error|note|warning):\s*")


def _filter_mypy_output(raw: str) -> str:
    """Group mypy lines under file path keys."""
    lines = raw.splitlines()
    if not lines:
        return raw
    buckets: dict[str, list[str]] = defaultdict(list)
    order: list[str] = []
    header_key = "__meta__"
    for line in lines:
        m = _MYPY_LOC.match(line)
        if m:
            fp = m.group(1)
            if fp not in buckets:
                order.append(fp)
            buckets[fp].append(line)
        else:
            if header_key not in buckets:
                order.insert(0, header_key)
            buckets[header_key].append(line)
    out: list[str] = []
    for key in order:
        label = "(preamble)" if key == header_key else key
        out.append(f"--- {label} ---")
        chunk = buckets[key]
        out.extend(chunk[:50])
        extra = len(chunk) - 50
        if extra > 0:
            out.append(f"... {extra} more")
    return "\n".join(out)


_PIP_NOISE = re.compile(
    r"^(Collecting|Downloading|Installing|Building wheel for|Getting requirements to build|"
    r"  (Downloading|Installing|Getting requirements)|Requirement already satisfied:|"
    r"Progress|\s*━+)",
    re.I,
)


def _filter_pip_output(raw: str) -> str:
    """Drop common pip / uv pip progress and spinner lines."""
    lines = raw.splitlines()
    kept = [ln for ln in lines if ln.strip() and not _PIP_NOISE.match(ln)]
    if not kept:
        return raw
    deduped = FilterStrategy.deduplicate(kept)
    return "\n".join(FilterStrategy.truncate(deduped, max_len=220))


def _exec_ruff_argv(args: list[str]) -> list[str]:
    return ["ruff", *args]


def _exec_mypy_argv(args: list[str]) -> list[str]:
    return ["mypy", *args]


@pytest_app.callback(invoke_without_command=True)
def pytest_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to pytest",
    ),
) -> None:
    """Run pytest and print a condensed view of failures and summary lines."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    raw, _, code = run_capturing([sys.executable, "-m", "pytest", *args])
    filtered = _filter_pytest_output(raw)
    emit_filtered_output(raw, filtered)
    cmd_label = "pytest " + " ".join(args) if args else "pytest"
    timer.track(cmd_label, f"ptk pytest {' '.join(args)}", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@ruff_app.callback(invoke_without_command=True)
def ruff_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to ruff",
    ),
) -> None:
    """Run ruff; group output by rule code when using text diagnostics."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    raw, _, code = run_capturing(_exec_ruff_argv(args))
    joined = " ".join(args)
    filtered = raw if "--output-format" in joined else _filter_ruff_output(raw)
    emit_filtered_output(raw, filtered)
    label = "ruff " + " ".join(args)
    timer.track(label, f"ptk ruff {' '.join(args)}", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@mypy_app.callback(invoke_without_command=True)
def mypy_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to mypy",
    ),
) -> None:
    """Run mypy; group diagnostics by file."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    raw, _, code = run_capturing(_exec_mypy_argv(args))
    filtered = _filter_mypy_output(raw)
    emit_filtered_output(raw, filtered)
    label = "mypy " + " ".join(args)
    timer.track(label, f"ptk mypy {' '.join(args)}", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@pip_app.callback(invoke_without_command=True)
def pip_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to pip",
    ),
) -> None:
    """Run pip via `python -m pip` with progress noise stripped from stdout."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    raw, _, code = run_capturing([sys.executable, "-m", "pip", *args])
    filtered = _filter_pip_output(raw)
    emit_filtered_output(raw, filtered)
    label = "pip " + " ".join(args)
    timer.track(label, f"ptk pip {' '.join(args)}", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@uv_app.callback(invoke_without_command=True)
def uv_cmd(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to uv",
    ),
) -> None:
    """Run uv; use compact pip-style filtering for `uv pip …` subcommands."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    timer = TimedExecution.start()
    if len(args) >= 2 and args[0] == "pip":
        raw, err, code = run_capturing(["uv", *args])
        merged = raw + (f"\n{err}" if err.strip() else "")
        filtered = _filter_pip_output(merged)
        emit_filtered_output(merged, filtered)
        label = "uv " + " ".join(args)
        timer.track(label, f"ptk uv {' '.join(args)}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    code = run_streaming(["uv", *args])
    label = "uv " + " ".join(args)
    timer.track(label, f"ptk uv {' '.join(args)}", "", "")
    if code != 0:
        raise typer.Exit(code)
