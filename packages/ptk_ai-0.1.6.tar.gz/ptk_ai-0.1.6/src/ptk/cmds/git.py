import re

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing, run_streaming

# Typer app for git
git_app = typer.Typer(
    name="git",
    help="Git commands with compact output",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def _filter_git_status(raw: str) -> str:
    """Filter git status to be compact."""
    lines = raw.splitlines()
    patterns = [
        re.compile(r"^\s*\(use \"git.*\)"),
        re.compile(r"^no changes added to commit"),
    ]
    filtered_lines = FilterStrategy.filter_noise(lines, patterns)
    return "\n".join(filtered_lines)


@git_app.command(
    "status", context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def git_status(
    ctx: typer.Context,
) -> None:
    """Compact status (supports all git status flags)."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["git", "status", *args])
    filtered = _filter_git_status(raw)
    emit_filtered_output(raw, filtered)
    timer.track("git status", "ptk git status", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@git_app.callback(invoke_without_command=True)
def git_fallback(
    ctx: typer.Context,
) -> None:
    """Fallback for unhandled git subcommands (passthrough)."""
    if ctx.invoked_subcommand is not None:
        return

    args = ctx.args
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    # For any other git command, run it via passthrough
    cmd_name = args[0]
    timer = TimedExecution.start()

    code = run_streaming(["git", *args])

    # We didn't capture output to know tokens, so we track 0
    timer.track(f"git {cmd_name}", f"ptk git {cmd_name}", "", "")

    if code != 0:
        raise typer.Exit(code)


def _filter_git_diff(raw: str) -> str:
    """Filter git diff to be compact (e.g. ultra-condensed)."""
    lines = raw.splitlines()
    filtered = []
    # Simplified diff filtering for now: keep lines with +/-/@@ and file headers.
    patterns = [
        re.compile(r"^diff --git"),
        re.compile(r"^--- "),
        re.compile(r"^\+\+\+ "),
        re.compile(r"^@@ "),
        re.compile(r"^\+"),
        re.compile(r"^-"),
    ]
    for line in lines:
        if any(p.search(line) for p in patterns) and not line.startswith("index "):
            # Avoid index lines for token saving
            filtered.append(line)
    return "\n".join(filtered)


@git_app.command(
    "diff", context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def git_diff(
    ctx: typer.Context,
) -> None:
    """Ultra-condensed diff (changed lines only)."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["git", "diff", *args])
    filtered = _filter_git_diff(raw)
    emit_filtered_output(raw, filtered)
    timer.track("git diff", "ptk git diff", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_log(raw: str) -> str:
    """Filter git log to deduplicate and filter noise."""
    lines = raw.splitlines()
    # Simple deduplication, could be enhanced
    filtered = FilterStrategy.deduplicate(lines)
    return "\n".join(filtered)


@git_app.command("log", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def git_log(
    ctx: typer.Context,
) -> None:
    """Deduplicate and filter log noise."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["git", "log", *args])
    filtered = _filter_git_log(raw)
    emit_filtered_output(raw, filtered)
    timer.track("git log", "ptk git log", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_show(raw: str) -> str:
    """Filter git show to be compact, like diff."""
    return _filter_git_diff(raw)


@git_app.command(
    "show",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_show(
    ctx: typer.Context,
) -> None:
    """Ultra-condensed diff for git show."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["git", "show", *args])
    filtered = _filter_git_show(raw)
    emit_filtered_output(raw, filtered)
    timer.track("git show", "ptk git show", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_add(raw: str) -> str:
    """Filter git add noise (usually there is no output, but suppress verbose flags if needed)."""
    return raw.strip()


@git_app.command(
    "add",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_add(
    ctx: typer.Context,
) -> None:
    """Compact git add output."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["git", "add", *args])
    filtered = _filter_git_add(raw)
    if filtered:
        emit_filtered_output(raw, filtered)
    timer.track("git add", "ptk git add", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_commit(raw: str) -> str:
    """Filter git commit output to be brief."""
    lines = raw.splitlines()
    filtered = []
    # Drop "On branch main", etc. just show the commit info
    patterns = [
        re.compile(r"^\[.*\]"),
        re.compile(r"^\s*\d+ file(s)? changed"),
        re.compile(r"^create mode"),
        re.compile(r"^delete mode"),
    ]
    for line in lines:
        if any(p.search(line) for p in patterns):
            filtered.append(line)

    # If we couldn't filter usefully, just return the first few lines
    if not filtered and lines:
        return "\n".join(lines[:3])

    return "\n".join(filtered)


@git_app.command(
    "commit",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_commit(
    ctx: typer.Context,
) -> None:
    """Compact git commit output."""
    args = ctx.args

    # If the user is trying to run an interactive commit without -m, we need to stream
    # so their editor can open properly.
    # A simple heuristic: if "-m" or "--message" or "-F" is not in args, it might be interactive.
    # Actually wait, `git commit -a` without `-m` is also interactive.
    # Safer check: if no message is provided, it's interactive
    has_message = any(a.startswith(("-m", "--message", "-F", "--file", "-C")) for a in args)

    timer = TimedExecution.start()

    if not has_message:
        code = run_streaming(["git", "commit", *args])
        timer.track("git commit", "ptk git commit", "", "")
        if code != 0:
            raise typer.Exit(code)
        return

    raw, _, code = run_capturing(["git", "commit", *args])
    filtered = _filter_git_commit(raw)
    emit_filtered_output(raw, filtered)
    timer.track("git commit", "ptk git commit", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_transfer(raw: str) -> str:
    """Filter git push, pull, fetch noise."""
    lines = raw.splitlines()
    filtered = []
    # Drop "Enumerating objects...", "Counting objects..." etc.
    patterns = [
        re.compile(r"^Enumerating objects:"),
        re.compile(r"^Counting objects:"),
        re.compile(r"^Compressing objects:"),
        re.compile(r"^Writing objects:"),
        re.compile(r"^Total \d+ \("),
        re.compile(r"^remote:"),
        re.compile(r"^Delta compression"),
        re.compile(r"^POST git-"),
    ]
    for line in lines:
        if not any(p.search(line) for p in patterns):
            filtered.append(line)

    # Sometimes just returns blank if everything was noise. Let's make sure there's at least "ok"
    if not filtered:
        return "ok"

    return "\n".join(filtered)


@git_app.command(
    "push",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_push(
    ctx: typer.Context,
) -> None:
    """Compact git push output."""
    args = ctx.args
    timer = TimedExecution.start()
    out, err, code = run_capturing(["git", "push", *args])

    # Git transfer commands often write progress to stderr
    raw = out + "\n" + err if err else out
    filtered = _filter_git_transfer(raw)

    if filtered.strip():
        emit_filtered_output(raw, filtered.strip())

    timer.track("git push", "ptk git push", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@git_app.command(
    "pull",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_pull(
    ctx: typer.Context,
) -> None:
    """Compact git pull output."""
    args = ctx.args
    timer = TimedExecution.start()
    out, err, code = run_capturing(["git", "pull", *args])

    raw = out + "\n" + err if err else out
    filtered = _filter_git_transfer(raw)

    if filtered.strip():
        emit_filtered_output(raw, filtered.strip())

    timer.track("git pull", "ptk git pull", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@git_app.command(
    "fetch",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_fetch(
    ctx: typer.Context,
) -> None:
    """Compact git fetch output."""
    args = ctx.args
    timer = TimedExecution.start()
    out, err, code = run_capturing(["git", "fetch", *args])

    raw = out + "\n" + err if err else out
    filtered = _filter_git_transfer(raw)

    if filtered.strip():
        emit_filtered_output(raw, filtered.strip())

    timer.track("git fetch", "ptk git fetch", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_branch(raw: str) -> str:
    """Filter git branch output (mostly just strip empty lines)."""
    return "\n".join(line for line in raw.splitlines() if line.strip())


@git_app.command(
    "branch",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_branch(
    ctx: typer.Context,
) -> None:
    """Compact git branch output."""
    args = ctx.args
    timer = TimedExecution.start()
    out, err, code = run_capturing(["git", "branch", *args])
    raw = out + "\n" + err if err else out
    filtered = _filter_git_branch(raw)
    if filtered:
        emit_filtered_output(raw, filtered)
    timer.track("git branch", "ptk git branch", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_stash(raw: str) -> str:
    """Filter git stash output (mostly just pass it through compactly)."""
    return "\n".join(line for line in raw.splitlines() if line.strip())


@git_app.command(
    "stash",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_stash(
    ctx: typer.Context,
) -> None:
    """Compact git stash output."""
    args = ctx.args
    timer = TimedExecution.start()
    out, err, code = run_capturing(["git", "stash", *args])
    raw = out + "\n" + err if err else out
    filtered = _filter_git_stash(raw)
    if filtered:
        emit_filtered_output(raw, filtered)
    timer.track("git stash", "ptk git stash", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


def _filter_git_worktree(raw: str) -> str:
    """Filter git worktree output."""
    return "\n".join(line for line in raw.splitlines() if line.strip())


@git_app.command(
    "worktree",
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def git_worktree(
    ctx: typer.Context,
) -> None:
    """Compact git worktree output."""
    args = ctx.args
    timer = TimedExecution.start()
    out, err, code = run_capturing(["git", "worktree", *args])
    raw = out + "\n" + err if err else out
    filtered = _filter_git_worktree(raw)
    if filtered:
        emit_filtered_output(raw, filtered)
    timer.track("git worktree", "ptk git worktree", raw, filtered)
    if code != 0:
        raise typer.Exit(code)
