import re

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing, run_streaming

npm_app = typer.Typer(
    name="npm",
    help="Node Package Manager with compact output",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

pnpm_app = typer.Typer(
    name="pnpm",
    help="Fast, disk space efficient package manager with compact output",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

npx_app = typer.Typer(
    name="npx",
    help="Execute npm package binaries with intelligent routing",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)


def _filter_npm_run(raw: str) -> str:
    """Filter npm run to remove boilerplate."""
    lines = raw.splitlines()
    filtered_lines = []

    # We want to match boilerplate like:
    # > my-project@1.0.0 build
    # > tsc && vite build

    pattern_pkg = re.compile(r"^> \S+@\S+ \S+$")

    skip_next = False

    for i, line in enumerate(lines):
        if skip_next:
            skip_next = False
            continue

        if pattern_pkg.search(line):
            # If we matched the package@version line, the next line is usually the command itself
            if i + 1 < len(lines) and lines[i + 1].startswith("> "):
                skip_next = True
            continue

        filtered_lines.append(line)

    return "\n".join(filtered_lines)


@npm_app.command("run", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def npm_run(
    ctx: typer.Context,
) -> None:
    """Run an npm script with compact output."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["npm", "run", *args])
    filtered = _filter_npm_run(raw)
    emit_filtered_output(raw, filtered)
    timer.track("npm run", "ptk npm run", raw, filtered)
    if code != 0:
        raise typer.Exit(code)


@npm_app.callback(invoke_without_command=True)
def npm_fallback(
    ctx: typer.Context,
) -> None:
    """Fallback for unhandled npm subcommands (passthrough)."""
    if ctx.invoked_subcommand is not None:
        return

    args = ctx.args
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    cmd_name = args[0]
    timer = TimedExecution.start()
    code = run_streaming(["npm", *args])
    timer.track(f"npm {cmd_name}", f"ptk npm {cmd_name}", "", "")
    if code != 0:
        raise typer.Exit(code)


@pnpm_app.command(
    "list", context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def pnpm_list(
    ctx: typer.Context,
) -> None:
    """List pnpm packages with minimal filtering."""
    args = ctx.args
    timer = TimedExecution.start()
    code = run_streaming(["pnpm", "list", *args])
    timer.track("pnpm list", "ptk pnpm list", "", "")
    if code != 0:
        raise typer.Exit(code)


@pnpm_app.command(
    "outdated", context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def pnpm_outdated(
    ctx: typer.Context,
) -> None:
    """List outdated pnpm packages with minimal filtering."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["pnpm", "outdated", *args])
    typer.echo(raw)  # No filtering defined for pnpm outdated yet
    timer.track("pnpm outdated", "ptk pnpm outdated", raw, raw)
    if code != 0:
        raise typer.Exit(code)


@pnpm_app.command(
    "install", context_settings={"allow_extra_args": True, "ignore_unknown_options": True}
)
def pnpm_install(
    ctx: typer.Context,
) -> None:
    """Install pnpm packages with minimal filtering."""
    args = ctx.args
    timer = TimedExecution.start()
    raw, _, code = run_capturing(["pnpm", "install", *args])
    typer.echo(raw)  # No filtering defined for pnpm install yet
    timer.track("pnpm install", "ptk pnpm install", raw, raw)
    if code != 0:
        raise typer.Exit(code)


@pnpm_app.callback(invoke_without_command=True)
def pnpm_fallback(
    ctx: typer.Context,
) -> None:
    """Fallback for unhandled pnpm subcommands (passthrough)."""
    if ctx.invoked_subcommand is not None:
        return

    args = ctx.args
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    cmd_name = args[0]
    timer = TimedExecution.start()
    code = run_streaming(["pnpm", *args])
    timer.track(f"pnpm {cmd_name}", f"ptk pnpm {cmd_name}", "", "")
    if code != 0:
        raise typer.Exit(code)


_NPX_LINE_ERR = re.compile(r"^\s*\d+:\d+\s+(error|warning)\s")
_TSC_ERR = re.compile(r"error TS\d+", re.IGNORECASE)


def _filter_eslint_style(raw: str) -> str:
    lines = raw.splitlines()
    grouped = FilterStrategy.group_by_pattern(lines, _NPX_LINE_ERR, max_per_group=5)
    return "\n".join(FilterStrategy.truncate(grouped, max_len=240))


def _filter_tsc_style(raw: str) -> str:
    lines = raw.splitlines()
    grouped = FilterStrategy.group_by_pattern(lines, _TSC_ERR, max_per_group=5)
    return "\n".join(FilterStrategy.truncate(grouped, max_len=240))


def _filter_vitest_failures(raw: str) -> str:
    lines = raw.splitlines()
    hits = [
        ln
        for ln in lines
        if any(
            mark in ln
            for mark in (
                " FAIL ",
                "× ",
                "AssertionError",
                "Error:",
                "failed",
                "Test Files",
                "Tests ",
            )
        )
    ]
    body = "\n".join(hits) if hits else raw
    lines = FilterStrategy.deduplicate(body.splitlines())
    return "\n".join(FilterStrategy.truncate(lines, max_len=240))


def _filter_generic_compact(raw: str) -> str:
    lines = FilterStrategy.deduplicate(raw.splitlines())
    return "\n".join(FilterStrategy.truncate(lines, max_len=220))


def _npx_tool_key(first: str) -> str:
    return first.removeprefix("./").lower().removesuffix(".cmd")


@npx_app.callback(invoke_without_command=True)
def npx_fallback(
    ctx: typer.Context,
) -> None:
    """Run npx with compact output for common dev tools when possible."""
    args = ctx.args
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    tool = _npx_tool_key(args[0])
    timer = TimedExecution.start()

    capture_tools = {
        "eslint": _filter_eslint_style,
        "tsc": _filter_tsc_style,
        "typescript": _filter_tsc_style,
        "vitest": _filter_vitest_failures,
        "prettier": _filter_generic_compact,
        "prisma": _filter_generic_compact,
        "next": _filter_generic_compact,
        "playwright": _filter_generic_compact,
    }

    handler = capture_tools.get(tool)
    if handler is None and tool.startswith("eslint"):
        handler = _filter_eslint_style
    elif handler is None and tool.startswith("vitest"):
        handler = _filter_vitest_failures

    if handler is not None:
        raw, _, code = run_capturing(["npx", *args])
        filtered = handler(raw)
        emit_filtered_output(raw, filtered)
        timer.track(f"npx {' '.join(args)}", f"ptk npx {' '.join(args)}", raw, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    code = run_streaming(["npx", *args])
    timer.track(f"npx {tool}", f"ptk npx {tool}", "", "")
    if code != 0:
        raise typer.Exit(code)
