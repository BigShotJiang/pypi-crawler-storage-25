"""`ptk cargo` — compact Rust/cargo output (build, test, clippy, …)."""

from __future__ import annotations

import re

import typer

from ptk.core.emit import emit_filtered_output
from ptk.core.filter import FilterStrategy
from ptk.core.tracking import TimedExecution
from ptk.core.utils import run_capturing, run_streaming

cargo_app = typer.Typer(
    help="Run cargo with condensed output for common subcommands",
    add_completion=False,
    invoke_without_command=True,
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)

_CARGO_PROGRESS_PREFIXES = (
    "Compiling ",
    "Blocking ",
    "Downloading ",
    "Documenting ",
    "Fresh ",
    "Updating ",
)


def _filter_cargo_build_like(raw: str) -> str:
    """Strip progress lines; keep errors, warnings, and Finished."""
    lines = raw.splitlines()
    kept: list[str] = []
    for ln in lines:
        stripped = ln.strip()
        if any(stripped.startswith(p) for p in _CARGO_PROGRESS_PREFIXES):
            continue
        kept.append(ln)
    return "\n".join(kept) if kept else raw


def _filter_cargo_test(raw: str) -> str:
    """Keep failures, panics, and the final test summary."""
    lines = raw.splitlines()
    keys = (
        "FAILED",
        "error[",
        "error:",
        "failures:",
        "test result",
        "panicked",
        "thread '",
        "---- ",
        "running ",
        "test ",
        "assertion",
    )
    picked = [ln for ln in lines if any(k in ln for k in keys)]
    if picked:
        return "\n".join(FilterStrategy.deduplicate(picked))
    return "\n".join(lines[-45:])


_CHECK_LINE = re.compile(r"^\s*Checking\s")


def _filter_cargo_clippy(raw: str) -> str:
    """Drop repetitive Checking lines; truncate long diagnostics."""
    lines = [ln for ln in raw.splitlines() if not _CHECK_LINE.match(ln)]
    return "\n".join(FilterStrategy.truncate(FilterStrategy.deduplicate(lines), max_len=260))


@cargo_app.callback(invoke_without_command=True)
def cargo_entry(
    ctx: typer.Context,
    args: list[str] = typer.Argument(  # noqa: B008
        default_factory=list,
        help="Arguments forwarded to cargo",
    ),
) -> None:
    """Dispatch cargo subcommands to capture+filter or streaming passthrough."""
    if not args:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    sub = args[0]
    timer = TimedExecution.start()
    label = "cargo " + " ".join(args)

    filter_fn = None
    if sub in ("build", "check", "install", "clean"):
        filter_fn = _filter_cargo_build_like
    elif sub == "test" or (sub == "nextest" and len(args) > 1 and args[1] == "run"):
        filter_fn = _filter_cargo_test
    elif sub == "clippy":
        filter_fn = _filter_cargo_clippy

    if filter_fn is not None:
        raw, err, code = run_capturing(["cargo", *args])
        merged = raw + (f"\n{err}" if err.strip() else "")
        filtered = filter_fn(merged)
        emit_filtered_output(merged, filtered)
        timer.track(label, f"ptk {label}", merged, filtered)
        if code != 0:
            raise typer.Exit(code)
        return

    code = run_streaming(["cargo", *args])
    timer.track(label, f"ptk {label}", "", "")
    if code != 0:
        raise typer.Exit(code)
