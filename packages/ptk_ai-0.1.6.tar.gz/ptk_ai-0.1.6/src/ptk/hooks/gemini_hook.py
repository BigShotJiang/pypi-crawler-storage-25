"""Gemini CLI BeforeTool hook: JSON stdin -> JSON stdout (rtk `hook gemini` parity)."""

from __future__ import annotations

import json
from typing import Any


def gemini_hook_output_for_payload(payload: dict[str, Any]) -> str:
    """Return the JSON string Gemini CLI expects for a parsed hook payload."""
    from ptk.hooks.init import find_rewrite

    tool_name = payload.get("tool_name") or ""
    if tool_name != "run_shell_command":
        return '{"decision":"allow"}'

    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict):
        return '{"decision":"allow"}'

    cmd = tool_input.get("command") or ""
    if not isinstance(cmd, str) or not cmd.strip():
        return '{"decision":"allow"}'

    if "<<" in cmd:
        return '{"decision":"allow"}'

    rewritten = find_rewrite(cmd.strip())
    if not rewritten or rewritten == cmd:
        return '{"decision":"allow"}'

    out = {
        "decision": "allow",
        "hookSpecificOutput": {"tool_input": {"command": rewritten}},
    }
    return json.dumps(out, separators=(",", ":"))


def gemini_hook_output_for_stdin(raw: str) -> str:
    """Parse hook JSON from a string (typically stdin); tolerate empty/invalid input."""
    text = raw.strip()
    if not text:
        return '{"decision":"allow"}'
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return '{"decision":"allow"}'
    if not isinstance(payload, dict):
        return '{"decision":"allow"}'
    return gemini_hook_output_for_payload(payload)
