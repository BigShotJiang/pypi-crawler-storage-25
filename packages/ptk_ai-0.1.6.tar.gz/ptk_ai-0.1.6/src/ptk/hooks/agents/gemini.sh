#!/bin/bash
# ptk Gemini BeforeTool hook (Bash)
# Protocol: Reads JSON from stdin, prints JSON to stdout (delegates to `ptk hook-gemini`).

# Gemini CLI sends tool call context via stdin
RAW_JSON=$(cat)

# Use `ptk hook-gemini` to process the JSON; it handles parsing and rewriting.
# Results are printed to stdout, which Gemini captures.
echo "$RAW_JSON" | ptk hook-gemini 2>/dev/null
exit 0
