"""Per-agent hook installers."""

from . import claude, codex, cursor, gemini

__all__ = [
    "claude",
    "codex",
    "cursor",
    "gemini",
]

AGENT_INSTALLERS = {
    "claude": claude,
    "codex": codex,
    "cursor": cursor,
    "gemini": gemini,
}
