"""OpenAI Codex CLI — prompt-level PTK awareness (PTK.md + AGENTS.md)."""

from __future__ import annotations

from pathlib import Path

from rich.console import Console

from ptk.hooks.agents import utils as hook_utils

AGENTS_MD = "AGENTS.md"
PTK_MD = "PTK.md"
PTK_MD_REF = "@PTK.md"
RTK_MD_REF = "@RTK.md"

PTK_CODEX_AWARENESS = """# PTK — Python Token Killer (Codex CLI)

**Usage:** Token-optimized CLI proxy for shell commands.

## Rule

Always prefix shell commands with `ptk`.

Examples:

```bash
ptk git status
ptk cargo test
ptk npm run build
ptk pytest -q
```

```powershell
ptk git status
ptk cargo test
```

## Meta commands

```bash
ptk gain            # Token savings analytics
ptk gain --history  # Recent command savings history
ptk proxy <cmd>     # Run raw command without filtering
```

## Verification

```bash
ptk --version
ptk gain
```
"""


def _remove_marked_block(content: str, start: str, end: str) -> tuple[str, bool]:
    """Strip a fenced HTML comment block if both markers exist."""
    if start not in content or end not in content:
        return content, False
    i = content.find(start)
    j = content.find(end)
    if j == -1 or j < i:
        return content, False
    j_end = j + len(end)
    before = content[:i].rstrip()
    after = content[j_end:].lstrip()
    if not before and not after:
        return "", True
    if not before:
        return after, True
    if not after:
        return before, True
    return f"{before}\n\n{after}", True


def _strip_rtk_reference_lines(content: str) -> tuple[str, bool]:
    lines_out: list[str] = []
    changed = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped == RTK_MD_REF or stripped.startswith(f"{RTK_MD_REF} "):
            changed = True
            continue
        lines_out.append(line)
    return "\n".join(lines_out), changed


def _has_ptk_reference(content: str) -> bool:
    for line in content.splitlines():
        s = line.strip()
        if s == PTK_MD_REF or s.startswith(f"{PTK_MD_REF} "):
            return True
    return False


def _patch_agents_md(agents_path: Path, *, console: Console | None = None) -> bool:
    """Ensure AGENTS.md references @PTK.md; migrate legacy RTK blocks. Returns True if file changed."""
    c = console
    content = agents_path.read_text(encoding="utf-8") if agents_path.exists() else ""
    original = content
    changed = False

    content, did = _remove_marked_block(
        content,
        "<!-- rtk-instructions",
        "<!-- /rtk-instructions -->",
    )
    changed = changed or did

    content, did = _remove_marked_block(
        content,
        "<!-- ptk-instructions",
        "<!-- /ptk-instructions -->",
    )
    changed = changed or did

    content, did = _strip_rtk_reference_lines(content)
    changed = changed or did

    if _has_ptk_reference(content):
        if changed:
            hook_utils.ensure_parent(agents_path)
            hook_utils.backup_existing(agents_path, console=c)
            agents_path.write_text(content.rstrip() + "\n", encoding="utf-8")
            if c:
                c.print("[dim]Updated AGENTS.md (migration only).[/dim]")
        return changed

    new_content = f"{PTK_MD_REF}\n" if not content.strip() else f"{content.strip()}\n\n{PTK_MD_REF}\n"
    hook_utils.ensure_parent(agents_path)
    hook_utils.backup_existing(agents_path, console=c)
    agents_path.write_text(new_content, encoding="utf-8")
    if c:
        c.print(f"[dim]Added {PTK_MD_REF} to {agents_path}[/dim]")
    return True


def _write_ptk_md(ptk_path: Path, *, console: Console | None = None) -> bool:
    """Write PTK.md if missing or content differs."""
    desired = PTK_CODEX_AWARENESS.rstrip() + "\n"
    if ptk_path.exists():
        existing = ptk_path.read_text(encoding="utf-8")
        if existing == desired:
            return False
        hook_utils.backup_existing(ptk_path, console=console)
    else:
        hook_utils.ensure_parent(ptk_path)

    ptk_path.write_text(desired, encoding="utf-8")
    return True


def install(
    *,
    global_: bool = False,
    home: Path | None = None,
    cwd: Path | None = None,
    console: Console | None = None,
) -> None:
    """
    Install Codex CLI instruction files.

    Global: ``~/.codex/PTK.md`` and ``~/.codex/AGENTS.md``.
    Project: ``./PTK.md`` and ``./AGENTS.md`` (relative to ``cwd``).
    """
    c = console or Console()
    root_home = home if home is not None else Path.home()
    base = (root_home / ".codex") if global_ else (cwd or Path.cwd())

    if global_:
        base.mkdir(parents=True, exist_ok=True)

    ptk_path = base / PTK_MD
    agents_path = base / AGENTS_MD

    wrote_ptk = _write_ptk_md(ptk_path, console=c)
    added_ref = _patch_agents_md(agents_path, console=c)

    c.print("\n[bold green]PTK configured for Codex CLI.[/bold green]\n")
    c.print(f"  {PTK_MD}:    {ptk_path.resolve()}")
    if added_ref or wrote_ptk:
        c.print(f"  {AGENTS_MD}: {agents_path.resolve()} ({PTK_MD_REF} reference)")
    else:
        c.print(f"  {AGENTS_MD}: {agents_path.resolve()} (already up to date)")
    c.print("\n[dim]Restart Codex CLI so it reloads instructions.[/dim]")
