from __future__ import annotations

import json
import shutil
from pathlib import Path

from rich.console import Console

from ptk.hooks.powershell import build_powershell_hook_command

console = Console()


def install(
    config_path: Path,
    *,
    hook_key: str = "hookCommand",
    command_env_var: str = "CMD",
    backup: bool = True,
    force: bool = False,
) -> None:
    """Write a PowerShell hook command into an agent configuration file."""
    config_path.parent.mkdir(parents=True, exist_ok=True)

    if config_path.exists() and backup:
        backup_path = config_path.parent / f"{config_path.name}.bak"
        shutil.copy2(config_path, backup_path)
        console.print(f"[dim]Backed up existing config to {backup_path}[/dim]")

    settings: dict[str, object]
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            settings = json.load(f)
    else:
        settings = {}

    if hook_key in settings and not force:
        console.print(f"[dim]{config_path.name} already contains {hook_key}; skipped update.[/dim]")
    else:
        settings[hook_key] = build_powershell_hook_command(command_env_var=command_env_var)
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2)
