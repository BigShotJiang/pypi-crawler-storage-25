"""Cursor IDE hook installation (PowerShell preToolUse)."""

from __future__ import annotations

import shutil
import sys
from pathlib import Path
from typing import Any

from rich.console import Console

from ptk.hooks.agents import utils as hook_utils
from ptk.hooks.powershell import find_powershell_executable

CURSOR_SCRIPT_NAME = "ptk-rewrite.ps1"
CURSOR_BASH_NAME = "ptk-rewrite.sh"
CURSOR_RULES_FILE = ".cursorrules"

PTK_HOOK_MARKER = "ptk-rewrite" # Shared substring for both .ps1 and .sh

# Mirrors hooks/cursor/rtk-rewrite.sh from maravedi/ptk: JSON on stdin, JSON on stdout.
CURSOR_PRETOOL_PS1 = r"""
# ptk Cursor preToolUse hook — deny original, instruct agent to use ptk equivalent.
$raw = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($raw)) { Write-Output '{}'; exit 0 }
try {
    $obj = $raw | ConvertFrom-Json
} catch {
    Write-Output '{}'
    exit 0
}
$cmd = $obj.tool_input.command
if ([string]::IsNullOrWhiteSpace($cmd)) { Write-Output '{}'; exit 0 }
if ($cmd -match '<<') { Write-Output '{}'; exit 0 }
$rewritten = & '{python_abs}' -m ptk --agent cursor rewrite -- $cmd
if ($LASTEXITCODE -ne 0) {
    Write-Output '{}'
    exit 0
}
if ($cmd -eq $rewritten) { Write-Output '{}'; exit 0 }
$output = [ordered]@{
    permission = 'allow'
    updated_input = [ordered]@{ command = $rewritten }
}
Write-Output ($output | ConvertTo-Json -Compress -Depth 5)
exit 0
""".strip()

CURSOR_RULES_CONTENT = """
# PTK Token Optimization Rules
# ALWAYS use these commands instead of raw git/ls/cat to minimize token usage.

## Required Command Format
Use this exact prefix for all terminal commands:
  & '{python_abs}' -m ptk --agent cursor <subcommand> [args]

## Command Mappings (use LEFT side, not right)
- `& '{python_abs}' -m ptk --agent cursor git status`   → NOT `git status`
- `& '{python_abs}' -m ptk --agent cursor git diff`     → NOT `git diff`
- `& '{python_abs}' -m ptk --agent cursor git log ...`  → NOT `git log ...`
- `& '{python_abs}' -m ptk --agent cursor ls <path>`    → NOT `ls <path>`
- `& '{python_abs}' -m ptk --agent cursor cat <file>`   → NOT `cat <file>`

## Why
PTK filters and compresses output for 60-90% token reduction.
Using raw commands wastes tokens and defeats the purpose of this project.
""".strip()

CURSOR_BASH_HOOK_CONTENT = r"""
#!/bin/bash
# ptk Cursor preToolUse hook (Bash)
export PTK_SHELL=bash
raw=$(cat)
if [ -z "$raw" ]; then echo "{}"; exit 0; fi

# Detection for the Windows drive mount point
WIN_DRIVE="/c"
if [ ! -d "$WIN_DRIVE" ]; then WIN_DRIVE="/mnt/c"; fi

# Resolve the ptk command using the dynamic mount point
# Placeholder __PTK_PATH__ is the windows path without the C: prefix (e.g. /Users/David/...)
PTK_CMD="'$WIN_DRIVE__PTK_PATH__' -m ptk --agent cursor"

if command -v jq >/dev/null 2>&1; then
    cmd=$(echo "$raw" | jq -r '.tool_input.command // empty')
else
    cmd=$(echo "$raw" | grep -oP '"command"\s*:\s*"\K[^"]+')
fi
if [ -z "$cmd" ] || [[ "$cmd" == *'<<'* ]]; then echo "{}"; exit 0; fi

# Hardened rewrite command for bash on windows — --bash emits /mnt/c/ style paths
rewritten=$(eval $PTK_CMD rewrite --bash -- "$cmd")

if [ $? -ne 0 ] || [ -z "$rewritten" ] || [ "$cmd" = "$rewritten" ]; then
    echo "{}"
    exit 0
fi

# Escape backslashes first, then escape double quotes for JSON
escaped_bs=$(echo "$rewritten" | sed 's/\\/\\\\/g')
escaped=$(echo "$escaped_bs" | sed 's/"/\\"/g')
echo "{\"permission\":\"allow\",\"updated_input\":{\"command\":\"$escaped\"}}"
exit 0
""".strip()


def _command_line_for_script(script_path: Path, shell_exe: str) -> str:
    resolved = script_path.resolve()
    return f'{shell_exe} -NoLogo -NoProfile -ExecutionPolicy Bypass -File "{resolved}"'


def _hooks_reference_ptk(data: dict[str, Any]) -> bool:
    hooks_block = data.get("hooks")
    if not isinstance(hooks_block, dict):
        return False
    entries = hooks_block.get("preToolUse")
    if not isinstance(entries, list):
        return False
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        cmd = entry.get("command", "")
        if isinstance(cmd, str) and PTK_HOOK_MARKER in cmd:
            return True
    return False


def install_powershell(*, home: Path | None = None, console: Console | None = None, force: bool = False) -> None:
    """Install ~/.cursor/hooks/ptk-rewrite.ps1 and register it in ~/.cursor/hooks.json."""
    c = console or Console()
    root = home if home is not None else Path.home()
    hooks_dir = root / ".cursor" / "hooks"
    hook_utils.ensure_parent(hooks_dir / ".keep")
    script_path = hooks_dir / CURSOR_SCRIPT_NAME

    python_abs = Path(sys.executable).resolve()
    shell_exe = find_powershell_executable() or "pwsh"
    # Resolve absolute path for script to be ASR-friendly
    script_abs = script_path.resolve()

    hook_command = f'{shell_exe} -NoLogo -NoProfile -ExecutionPolicy Bypass -File "{script_abs}"'
    # Substitute the placeholder in the template with the real absolute python path
    script_content = CURSOR_PRETOOL_PS1.replace("{python_abs}", str(python_abs))
    script_path.write_text(script_content + "\n", encoding="utf-8")

    hooks_json = root / ".cursor" / "hooks.json"
    data = hook_utils.read_json(hooks_json)
    if not data:
        data = {"version": 1, "hooks": {}}

    if "hooks" not in data or not isinstance(data["hooks"], dict):
        data["hooks"] = {}
    if "version" not in data:
        data["version"] = 1

    pre = data["hooks"].get("preToolUse")
    if not isinstance(pre, list):
        pre = []
        data["hooks"]["preToolUse"] = pre

    if _hooks_reference_ptk(data) and not force:
        c.print(f"[dim]Cursor hooks.json already lists {CURSOR_SCRIPT_NAME}; skipped update.[/dim]")
    else:
        # If forcing, remove previous ptk entries first to avoid duplicates
        if force:
            pre = [h for h in pre if PTK_HOOK_MARKER not in str(h.get("command", ""))]
            data["hooks"]["preToolUse"] = pre

        pre.append({"command": hook_command})
        hook_utils.write_json(hooks_json, data, console=c)

    c.print("[green]✓ Cursor PowerShell hook installed.[/green]")
    install_rules(console=c)


def install_bash(*, home: Path | None = None, console: Console | None = None, force: bool = False) -> None:
    """Install ~/.cursor/hooks/ptk-rewrite.sh and register it in ~/.cursor/hooks.json."""
    c = console or Console()
    root = home if home is not None else Path.home()
    
    python_abs = Path(sys.executable).resolve()
    
    hooks_dir = root / ".cursor" / "hooks"
    hook_utils.ensure_parent(hooks_dir / ".keep")
    script_path = hooks_dir / CURSOR_BASH_NAME
    
    # Handle bash-style path conversion if on Windows for Cursor Bash hook
    python_bash = str(python_abs).replace('\\', '/')
    if python_bash[1] == ':':
        python_bash = f"/{python_bash[0].lower()}{python_bash[2:]}"
    
    ptk_cmd = f"'{python_bash}' -m ptk --agent cursor"
    
    # Provide the drive-relative path for the bash hook to resolve dynamically
    python_path = str(python_abs)[2:].replace('\\', '/')
    script_content = CURSOR_BASH_HOOK_CONTENT.replace('__PTK_PATH__', python_path)
    
    # Force Unix-style line endings (LF) for bash compatibility on Windows/WSL
    with open(script_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(script_content + "\n")
    
    script_path.chmod(0o755)

    # Explicitly invoke bash to run the script — avoids Windows file-association
    # opening the .sh file with the default handler (e.g. Notepad / VS Code).
    bash_exe = shutil.which("bash") or "bash"
    script_forward = str(script_path.resolve()).replace("\\", "/")
    hook_command = f'{bash_exe} "{script_forward}"'

    hooks_json = root / ".cursor" / "hooks.json"
    data = hook_utils.read_json(hooks_json)
    if not data:
        data = {"version": 1, "hooks": {}}

    if "hooks" not in data or not isinstance(data["hooks"], dict):
        data["hooks"] = {}
    if "version" not in data:
        data["version"] = 1

    pre = data["hooks"].get("preToolUse")
    if not isinstance(pre, list):
        pre = []
        data["hooks"]["preToolUse"] = pre

    if _hooks_reference_ptk(data) and not force:
        c.print(f"[dim]Cursor hooks.json already lists {CURSOR_BASH_NAME}; skipped update.[/dim]")
    else:
        # If forcing, remove previous ptk entries first to avoid duplicates
        if force:
            pre = [h for h in pre if PTK_HOOK_MARKER not in str(h.get("command", ""))]
            data["hooks"]["preToolUse"] = pre

        pre.append({"command": hook_command})
        hook_utils.write_json(hooks_json, data, console=c)

    c.print("[green]✓ Cursor Bash hook installed.[/green]")
    install_rules(console=c)


def install_rules(*, console: Console | None = None) -> None:
    """Generate .cursorrules in the current directory."""
    c = console or Console()
    python_abs = Path(sys.executable).resolve()
    rules_content = CURSOR_RULES_CONTENT.replace("{python_abs}", str(python_abs))
    rules_path = Path(CURSOR_RULES_FILE)
    rules_path.write_text(rules_content + "\n", encoding="utf-8")
    c.print(f"[green]✓ {CURSOR_RULES_FILE} generated for Cursor.[/green]")
