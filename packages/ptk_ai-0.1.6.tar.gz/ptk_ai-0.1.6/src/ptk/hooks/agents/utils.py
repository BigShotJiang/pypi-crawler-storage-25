from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Callable

from rich.console import Console


def ensure_parent(path: Path) -> None:
    """Make sure the parent directory exists."""
    path.parent.mkdir(parents=True, exist_ok=True)


def backup_existing(path: Path, *, console: Console | None = None) -> Path | None:
    """Copy the existing file to `<name>.bak` for safety."""
    if not path.exists():
        return None
    backup = path.parent / f"{path.name}.bak"
    shutil.copy2(path, backup)
    console.print(f"[dim]Backed up {path} to {backup}[/dim]") if console else None
    return backup


def read_json(path: Path) -> dict[str, Any]:
    """Load JSON from the path, or return an empty dict if missing/corrupt."""
    if not path.exists():
        return {}
    try:
        with path.open(encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        return {}


def write_json(
    path: Path,
    data: dict[str, Any],
    *,
    backup: bool = True,
    console: Console | None = None,
) -> None:
    """Write JSON to a file with optional backup and parent creation."""
    ensure_parent(path)
    if backup:
        backup_existing(path, console=console)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
