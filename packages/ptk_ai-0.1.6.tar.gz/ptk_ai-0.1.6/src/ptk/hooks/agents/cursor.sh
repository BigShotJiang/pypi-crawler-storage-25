#!/bin/bash
# ptk Cursor preToolUse hook (Bash)
# Protocol: Reads JSON from stdin, prints JSON to stdout for command rewriting.

# Read stdin
RAW_JSON=$(cat)
if [ -z "$RAW_JSON" ]; then
    echo "{}"
    exit 0
fi

# Extract command using jq (standard) or grep (fallback)
if command -v jq >/dev/null 2>&1; then
    CMD=$(echo "$RAW_JSON" | jq -r '.tool_input.command // empty')
else
    # Heuristic extraction for: "command": "..."
    # Note: Does not handle escaped quotes or complex nesting perfectly, but fits Cursor hook format.
    CMD=$(echo "$RAW_JSON" | grep -oP '"command"\s*:\s*"\K[^"]+')
fi

# Basic sanity checks
if [ -z "$CMD" ] || [[ "$CMD" == *'<<'* ]]; then
    echo "{}"
    exit 0
fi

# Attempt rewrite
REWRITTEN=$(ptk rewrite -- "$CMD" 2>/dev/null)
EXIT_CODE=$?

# If rewrite failed or returned empty/unchanged, return empty object (passthrough)
if [ $EXIT_CODE -ne 0 ] || [ -z "$REWRITTEN" ] || [ "$CMD" = "$REWRITTEN" ]; then
    echo "{}"
    exit 0
fi

# Return permission + updated instruction
# Escaping the rewritten command for simple JSON output
ESCAPED_REWRITTEN=$(echo "$REWRITTEN" | sed 's/"/\\"/g')
echo "{\"permission\":\"allow\",\"updated_input\":{\"command\":\"$ESCAPED_REWRITTEN\"}}"
exit 0
