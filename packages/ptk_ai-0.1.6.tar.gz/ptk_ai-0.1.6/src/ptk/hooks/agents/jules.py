"""Jules agent support (Google Cloud agent)."""

from __future__ import annotations

from pathlib import Path

from rich.console import Console

JULES_RULES_FILE = ".julesrules"

JULES_RULES_CONTENT = r"""
# PTK Jules Rules
# Minimize token consumption by using the 'ptk-ai' proxy for common commands.

# Instructions for Jules:
# 1. When you need to read a file, use `pipenv run python -m ptk read <file>` instead of `cat`.
# 2. When you need to list directories, use `pipenv run python -m ptk ls <path>` instead of `ls`.
# 3. For any git command (status, diff, log, add, commit), prefix with `pipenv run python -m ptk`.
# 4. For test runners (pytest, cargo test, npm test), use `pipenv run python -m ptk <command>`.
# 5. For cloud tools (docker, kubectl, aws, curl), use `pipenv run python -m ptk <command>`.

# This project uses PTK (Python Token Killer) to optimize LLM context.
# The binary is expected to be available in the environment via pipenv.
""".strip()

SETUP_SCRIPT_FILE = "ptk-setup.sh"

SETUP_SCRIPT_CONTENT = r"""
#!/bin/bash
# ptk-setup.sh — ensure ptk is available in the AI agent environment.
if ! command -v ptk &> /dev/null; then
    echo "ptk not found; installing..."
    pip install ptk || pip install --user ptk
fi
echo "ptk is available: $(ptk --version)"
""".strip()


def install(*, console: Console | None = None, force: bool = False) -> None:
    """Generate .julesrules and ptk-setup.sh in the current directory."""
    c = console or Console()
    rules_path = Path(JULES_RULES_FILE)
    rules_path.write_text(JULES_RULES_CONTENT + "\n", encoding="utf-8")
    c.print(f"[green]✓ {JULES_RULES_FILE} generated for Jules.[/green]")

    setup_path = Path(SETUP_SCRIPT_FILE)
    setup_path.write_text(SETUP_SCRIPT_CONTENT + "\n", encoding="utf-8")
    setup_path.chmod(0o755)
    c.print(f"[green]✓ {SETUP_SCRIPT_FILE} generated for environment setup.[/green]")
