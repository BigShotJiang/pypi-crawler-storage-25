"""Installation and verification of agent hooks."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any, Literal

import typer
from rich.console import Console

from ptk.hooks.agents import (
    claude,
    cline,
    codex,
    cursor,
    gemini,
    jules,
    windsurf,
)
from ptk.hooks.powershell import find_powershell_executable

hook_app = typer.Typer(name="hook", help="Manage agent hooks", add_completion=False)
console = Console()


@hook_app.command("init")
def cmd_init(
    global_: bool = typer.Option(False, "--global", "-g", help="Install globally"),
    shell: Literal["bash", "powershell"] = typer.Option(
        "bash",
        "--shell",
        "-s",
        help="Shell type to target for the hook",
    ),
    codex_only: bool = typer.Option(
        False,
        "--codex",
        help="Install Codex CLI instruction files only (PTK.md + AGENTS.md)",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Force overwrite existing hooks"),
) -> None:
    """Install ptk hooks in supported AI agents."""
    if codex_only:
        console.print("[bold]Installing Codex CLI instructions...[/bold]")
        codex.install(global_=global_, console=console)
        console.print("[bold green]Done.[/bold green]")
        return

    console.print("[bold]Installing agent hooks...[/bold]")
    claude.install(global_=global_, shell=shell, force=force)
    if shell == "powershell":
        cursor.install_powershell(console=console, force=force)
        gemini.install_powershell(console=console, force=force)
    else:
        cursor.install_bash(console=console, force=force)
        gemini.install_bash(console=console, force=force)
    jules.install(console=console, force=force)
    cline.install(console=console, force=force)
    windsurf.install(console=console, force=force)
    console.print("[bold green]Installation complete![/bold green]")


@hook_app.command("install")
def cmd_hook_install(
    agent: str = typer.Argument(..., help="Agent name to hook"),
    shell: Literal["bash", "powershell"] = typer.Option(
        "bash",
        "--shell",
        "-s",
        help="Shell type to target for the hook",
    ),
    global_: bool = typer.Option(
        False,
        "--global",
        "-g",
        help="Use global paths where supported (e.g. ~/.codex, ~/.claude)",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Force overwrite existing hooks"),
) -> None:
    """Install a hook for a specific agent."""
    name = agent.lower()
    if name == "claude":
        claude.install(global_=global_, shell=shell, force=force)
    elif name == "cursor":
        if shell == "powershell":
            cursor.install_powershell(console=console, force=force)
        else:
            cursor.install_bash(console=console, force=force)
    elif name == "gemini":
        if shell == "powershell":
            gemini.install_powershell(console=console, force=force)
        else:
            gemini.install_bash(console=console, force=force)
    elif name == "codex":
        codex.install(global_=global_, console=console)
    elif name in ("jules", "baton"):
        jules.install(console=console)
    elif name in ("cline", "roo-code"):
        cline.install(console=console)
    elif name == "windsurf":
        windsurf.install(console=console)
    else:
        console.print(f"[yellow]Agent '{agent}' not currently supported for manual hook.[/yellow]")


@hook_app.command("gemini-hook")
def cmd_hook_gemini(
    ctx: typer.Context,
) -> None:
    """Entry point for Gemini BeforeTool hook (reads tool JSON from stdin)."""
    import sys
    from ptk.hooks.agents.gemini import gemini_hook_output_for_stdin
    
    # We don't use the standard rewrite flow here because Gemini needs a specific JSON wrapper
    typer.echo(gemini_hook_output_for_stdin(sys.stdin.read()))


@hook_app.command("verify")
def cmd_hook_verify(
    shell: Literal["bash", "powershell"] = typer.Option(
        "bash",
        "--shell",
        "-s",
        help="Shell type to use for verification (bash or powershell)",
    ),
) -> None:
    """Verify that agent hooks are correctly installed and working."""
    console.print("[bold]Batch verifying agent integrations...[/bold]")
    agents = ["claude", "cursor", "jules", "cline", "windsurf"]
    success_count = 0

    for name in agents:
        console.print(f"Verifying {name} hook...")
        result = False

        if name == "claude":
            result = verify_claude()
        elif name == "cursor":
            result = verify_rewriter("cursor", shell)
        elif name == "jules":
            result = verify_rules(".julesrules")
        elif name == "cline":
            result = verify_rules(".clinerules")
        elif name == "windsurf":
            result = verify_rules(".windsurfrules")

        if result:
            success_count += 1
        else:
            # Errors are already printed by the verification functions
            pass

    if success_count == len(agents):
        console.print("\n[bold green]✓ All agents verified successfully![/bold green]")
    else:
        console.print(f"\n[bold red]! {len(agents) - success_count}/{len(agents)} agents failed verification.[/bold red]")
        console.print("[dim]Check the logs above.[/dim]")
        raise typer.Exit(1)


def verify_claude() -> bool:
    """Verify that ~/.claude/settings.json points to ptk rewrite."""
    path = Path.home() / ".claude" / "settings.json"
    if not path.exists():
        console.print(f"[red]! Claude settings not found at {path}[/red]")
        return False

    with open(path, encoding="utf-8") as f:
        try:
            data = json.load(f)
            cmd = data.get("hookCommand", "")
            if "ptk" in cmd and "rewrite" in cmd:
                console.print("[green]✓ Claude Code settings.json correctly references ptk rewrite.[/green]")
                return True
            else:
                console.print(f"[red]! Claude Code hookCommand '{cmd}' does not appear to be ptk.[/red]")
                return False
        except Exception as e:
            console.print(f"[red]! Failed to parse Claude settings: {e}[/red]")
            return False


def verify_rewriter(name: str, shell_type: str) -> bool:
    """Verify script-based rewriters (Cursor/Gemini) by calling them and checking if they rewrite 'git status'."""
    script_path = Path.home() / ".cursor" / "hooks" / ("ptk-rewrite.ps1" if shell_type == "powershell" else "ptk-rewrite.sh")
    if name == "gemini":
        script_path = Path.home() / ".gemini" / "hooks" / ("ptk-hook-gemini.ps1" if shell_type == "powershell" else "ptk-hook-gemini.sh")

    if not script_path.exists():
        console.print(f"[red]! Hook script not found at {script_path}[/red]")
        return False

    # Payload for Cursor/Gemini-style hooks
    test_payload = {"tool_input": {"command": "git status"}}
    if name == "gemini":
        test_payload = {"tool_name": "run_shell_command", "tool_input": {"command": "git status"}}

    test_json = json.dumps(test_payload)

    try:
        if shell_type == "powershell":
            pwsh = find_powershell_executable() or "powershell"
            proc = subprocess.run(
                [pwsh, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path.resolve())],
                input=test_json,
                capture_output=True,
                text=True,
                timeout=5,
            )
        else:
            # Detection for WSL user 'maravedi' in /mnt/c/ or Git Bash in /c/
            diag_proc = subprocess.run(["bash", "-c", "echo \"HOME: $HOME\"; echo \"PWD: $PWD\"; id"], capture_output=True, text=True)
            console.print(f"[dim]Bash Context:\n{diag_proc.stdout.strip()}[/dim]")

            win_abs = str(script_path.resolve())
            path_part = win_abs[2:].replace("\\", "/")
            win_forward = win_abs.replace("\\", "/")
            
            # Broad probe sequence covering both Git Bash and WSL
            bash_cmd = (
                f"for p in '/mnt/c{path_part}' '/c{path_part}' '{win_forward}'; do "
                f"if [ -f \"$p\" ]; then echo \"$p\"; exit 0; fi; done; "
                f"echo '/mnt/c{path_part}'"  # Default fallback if all existence tests fail
            )
            
            resolve_proc = subprocess.run(
                ["bash", "-c", bash_cmd],
                capture_output=True,
                text=True,
                timeout=5,
            )
            bash_script = resolve_proc.stdout.strip()
            
            # Diagnostic: check if script is accessible from within bash
            ls_proc = subprocess.run(["bash", "-c", f"ls -al '{bash_script}'"], capture_output=True, text=True)
            if ls_proc.returncode != 0:
                console.print(f"[red]! Bash cannot find the hook file at: {bash_script}[/red]")
                if ls_proc.stderr:
                    console.print(f"[dim]Bash error: {ls_proc.stderr.strip()}[/dim]")
                return False

            proc = subprocess.run(
                ["bash", bash_script],
                input=test_json,
                capture_output=True,
                text=True,
                timeout=5,
            )

        if proc.returncode == 0:
            output = proc.stdout.strip()
            # Support both direct 'ptk' and absolute-path python -m ptk variants
            if "ptk" in output and "git status" in output:
                console.print(f"[green]✓ {name.title()} hook correctly rewrote 'git status' to ptk format.[/green]")
                return True
            else:
                console.print(f"[red]! {name} hook returned output but command was not correctly rewritten.[/red]")
                console.print(f"[dim]Output: {output}[/dim]")
                return False
        else:
            if proc.stderr:
                console.print(f"[red]{proc.stderr.strip()}[/red]")
            console.print(f"[red]! {name} hook failed with exit code {proc.returncode}[/red]")
            return False
    except Exception as e:
        console.print(f"[red]Failed to verify {name}: {e}[/red]")
        return False


def verify_rules(filename: str) -> bool:
    """Verify that a project-local rules file exists and mentions ptk."""
    path = Path(filename)
    if not path.exists():
        console.print(f"[red]! {filename} missing from current directory.[/red]")
        return False

    content = path.read_text(encoding="utf-8")
    if "ptk" in content.lower():
        console.print(f"[green]✓ {filename} correctly refers to ptk instructions.[/green]")
        return True
    else:
        console.print(f"[red]! {filename} exists but does not mention ptk.[/red]")
        return False


def find_rewrite(cmd: str, agent: str | None = None, bash: bool = False) -> str | None:
    """Map a raw shell command to a `ptk` equivalent when a filter exists."""
    import sys
    from datetime import datetime

    # Use sys.executable for absolute-path bypasses on Windows
    python_abs = Path(sys.executable).resolve()

    # Simple trace logging for diagnostics
    trace_dir = Path.home() / ".ptk"
    trace_dir.mkdir(parents=True, exist_ok=True)
    trace_file = trace_dir / "hook_trace.log"

    c = cmd.strip()

    def _log(tag: str, original: str, result: str | None = None) -> None:
        try:
            with open(trace_file, "a", encoding="utf-8") as f:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                agent_tag = f" [{agent}]" if agent else ""
                res_str = f" -> {result}" if result else ""
                f.write(f"[{now}] [{tag}]{agent_tag} {original}{res_str}\n")
        except:
            pass

    # Strip common agent-orchestrated prefixes like 'cd ... &&'
    if " && " in c:
        parts = c.split(" && ", 1)
        if parts[0].strip().startswith("cd "):
            prefix_stripped = parts[1].strip()
            # If we rewrite the inner command, we re-attach the prefix
            inner_res = find_rewrite(prefix_stripped, agent=agent)
            if inner_res:
                return f"{parts[0]} && {inner_res}"
            return None

    if c.startswith("ptk ") or c.startswith("python -m ptk"):
        _log("ALREADY_PTK", c)
        return None

    parts = c.split()
    if not parts:
        return None

    binary = parts[0]
    subcmds = parts[1:]

    res = None
    supported_git = [
        "status",
        "diff",
        "log",
        "show",
        "add",
        "commit",
        "push",
        "pull",
        "fetch",
        "branch",
        "stash",
        "worktree",
    ]

    # Inject agent flag if provided
    agent_flag = f" --agent {agent}" if agent and agent != "shell" else ""

    # Build the python invocation path.
    # When bash=True (e.g. called from the bash hook via --bash flag),
    # emit a /mnt/c/ style path so WSL bash can execute the rewritten command.
    if bash and str(python_abs)[1:2] == ":":
        # WSL bash: convert C:\foo\bar -> /mnt/c/foo/bar
        drive = str(python_abs)[0].lower()
        rest = str(python_abs)[2:].replace("\\", "/")
        python_invoke = f"/mnt/{drive}{rest}"
        prefix = f"'{python_invoke}' -m ptk{agent_flag}"
    elif sys.platform == "win32":
        # PowerShell: needs the '& ' call operator to invoke a quoted executable path.
        # Without it, 'C:\...\python.exe' is treated as a string literal, not a command.
        python_invoke = str(python_abs)
        prefix = f"& '{python_invoke}' -m ptk{agent_flag}"
    else:
        python_invoke = str(python_abs)
        prefix = f"'{python_invoke}' -m ptk{agent_flag}"


    if binary == "git":
        if subcmds and subcmds[0] in supported_git:
            res = f"{prefix} git {' '.join(subcmds)}"
        else:
            _log("UNSUPPORTED_GIT", c)
            return None

    elif binary in (
        "npm",
        "pnpm",
        "pytest",
        "ruff",
        "mypy",
        "pip",
        "cargo",
        "gh",
        "docker",
        "kubectl",
        "curl",
        "wget",
        "rg",
        "ls",
        "cat",
        "env",
        "tree",
        "diff",
        "grep",
        "find",
        "aws",
        "psql",
        "wc",
        "go",
    ):
        res = f"{prefix} {binary}" + (f" {' '.join(subcmds)}" if subcmds else "")

    elif binary == "uv" and subcmds and subcmds[0] == "pip":
        res = f"{prefix} uv {' '.join(subcmds)}"

    elif binary == "python" and len(subcmds) >= 2 and subcmds[0] == "-m":
        module = subcmds[1]
        rest = subcmds[2:]
        if module in ("pytest", "ruff", "mypy", "pip"):
            res = f"{prefix} {module} {' '.join(rest)}"

    elif binary == "npx" and subcmds:
        tool = subcmds[0].removeprefix("./").lower()
        routed = {"eslint", "tsc", "vitest", "prettier", "prisma", "next", "playwright"}
        if tool in routed or tool.startswith("eslint") or tool.startswith("vitest"):
            res = f"{prefix} npx {' '.join(subcmds)}"

    if res:
        _log("REWRITTEN", c, res)
    else:
        _log("PASSTHROUGH", c)

    return res


def cmd_rewrite(
    ctx: typer.Context,
    args: list[str] = typer.Argument(..., help="Raw command args to rewrite"),
    bash: bool = typer.Option(False, "--bash", help="Emit WSL/bash-compatible /mnt/c/ paths"),
) -> None:
    """Rewrite a raw command to its ptk equivalent. Exit 0 if rewritten, 1 if not."""
    cmd = " ".join(args)
    # Extract agent from context (set by global --agent option)
    agent = ctx.obj.get("agent", "shell")
    rewritten = find_rewrite(cmd, agent=agent, bash=bash)

    if rewritten:
        typer.echo(rewritten)
        raise typer.Exit(0)
    raise typer.Exit(1)
