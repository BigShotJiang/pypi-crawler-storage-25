import re
import time
from pathlib import Path


def get_tee_dir() -> Path:
    """Get the path for tee logs."""
    tee_dir = Path.home() / ".local" / "share" / "ptk" / "tee"
    tee_dir.mkdir(parents=True, exist_ok=True)
    return tee_dir


def _clean_command_name(cmd: str) -> str:
    """Clean a command string to be safe for a filename."""
    # Keep alphanumeric, replace spaces and special chars with underscores
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "_", cmd)
    # Truncate to reasonable length
    return cleaned[:30].strip("_")


def tee_and_hint(raw: str, cmd: str, exit_code: int) -> str | None:
    """
    Write raw output to ~/.local/share/ptk/tee/<timestamp>_<cmd>.log on failure.
    Return a hint line for the LLM.
    """
    if exit_code == 0:
        return None

    if not raw.strip():
        return None

    timestamp = int(time.time())
    safe_cmd = _clean_command_name(cmd)
    filename = f"{timestamp}_{safe_cmd}.log"
    log_path = get_tee_dir() / filename

    try:
        log_path.write_text(raw, encoding="utf-8", errors="replace")
        return f"\n[ptk: exit code {exit_code}. full output logged to {log_path}]"
    except Exception:
        # Fail gracefully if we can't write the log
        return None
