from dataclasses import dataclass
from pathlib import Path
from typing import Literal

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]


def config_path() -> Path:
    """Get the path to the global config file."""
    config_dir = Path.home() / ".config" / "ptk"
    return config_dir / "config.toml"


@dataclass
class Config:
    ultra_compact: bool = False
    telemetry_enabled: bool = True
    token_estimator: Literal["heuristic", "tiktoken"] = "heuristic"
    db_path: str | None = None  # override default analytics path
    trust_level: Literal["ask", "auto", "never"] = "ask"

    @classmethod
    def load(cls, path: Path | None = None) -> "Config":
        """Load configuration from the specified path or default location."""
        cfg_path = path or config_path()
        if not cfg_path.exists():
            return cls()

        try:
            with open(cfg_path, "rb") as f:
                data = tomllib.load(f)
        except Exception:
            return cls()

        kwargs = {}
        if "tracking" in data:
            tracking = data["tracking"]
            if "database_path" in tracking:
                kwargs["db_path"] = tracking["database_path"]

        if "telemetry" in data:
            telemetry = data["telemetry"]
            if "enabled" in telemetry:
                kwargs["telemetry_enabled"] = telemetry["enabled"]

        if "general" in data:
            general = data["general"]
            if "ultra_compact" in general:
                kwargs["ultra_compact"] = general["ultra_compact"]
            if "token_estimator" in general:
                kwargs["token_estimator"] = general["token_estimator"]
            if "trust_level" in general:
                kwargs["trust_level"] = general["trust_level"]

        return cls(**kwargs)
