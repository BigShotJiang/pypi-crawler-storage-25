import re
from enum import StrEnum

from ptk.core.utils import strip_ansi as _strip_ansi_codes


class FilterLevel(StrEnum):
    NONE = "none"
    MINIMAL = "minimal"
    AGGRESSIVE = "aggressive"


class FilterStrategy:
    """Composable filter operations — each takes lines: list[str] and returns list[str]."""

    @staticmethod
    def deduplicate(lines: list[str]) -> list[str]:
        """Remove exact-duplicate consecutive lines."""
        if not lines:
            return []

        result = [lines[0]]
        for line in lines[1:]:
            if line != result[-1]:
                result.append(line)
        return result

    @staticmethod
    def truncate(lines: list[str], max_len: int = 200) -> list[str]:
        """Truncate lines exceeding max_len characters."""
        result = []
        for line in lines:
            if len(line) > max_len:
                result.append(line[:max_len] + "...")
            else:
                result.append(line)
        return result

    @staticmethod
    def group_by_pattern(
        lines: list[str],
        pattern: re.Pattern[str],
        max_per_group: int = 5,
    ) -> list[str]:
        """Group repetitive lines matching pattern; emit "... N more" summary."""
        result = []
        group_count = 0
        in_group = False

        for line in lines:
            if pattern.search(line):
                if not in_group:
                    in_group = True
                    group_count = 1
                    result.append(line)
                else:
                    group_count += 1
                    if group_count <= max_per_group:
                        result.append(line)
            else:
                if in_group:
                    if group_count > max_per_group:
                        result.append(f"... {group_count - max_per_group} more")
                    in_group = False
                    group_count = 0
                result.append(line)

        if in_group and group_count > max_per_group:
            result.append(f"... {group_count - max_per_group} more")

        return result

    @staticmethod
    def strip_ansi(text: str) -> str:
        """Remove ANSI escape codes."""
        return _strip_ansi_codes(text)

    @staticmethod
    def filter_noise(lines: list[str], patterns: list[re.Pattern[str]]) -> list[str]:
        """Drop lines matching any noise pattern."""
        result = []
        for line in lines:
            if not any(p.search(line) for p in patterns):
                result.append(line)
        return result
