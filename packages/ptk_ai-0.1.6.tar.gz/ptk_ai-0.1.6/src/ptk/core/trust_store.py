"""SHA256 trust lockfile for project-local `.ptk.toml` filters (see roadmap Phase 4.7)."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

_TRUST_FILENAME = ".ptk-trusted"


def _default_data_dir() -> Path:
    d = Path.home() / ".local" / "share" / "ptk"
    d.mkdir(parents=True, exist_ok=True)
    return d


def trust_file_path() -> Path:
    """Path to the JSON lockfile mapping project dirs to `.ptk.toml` content hashes."""
    return _default_data_dir() / _TRUST_FILENAME


def sha256_file(path: Path) -> str:
    """SHA256 hex digest of file bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_projects(path: Path | None = None) -> dict[str, str]:
    p = path or trust_file_path()
    if not p.is_file():
        return {}
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if isinstance(raw, dict) and "projects" in raw:
        inner = raw["projects"]
        return dict(inner) if isinstance(inner, dict) else {}
    return dict(raw) if isinstance(raw, dict) else {}


def _save_projects(projects: dict[str, str], path: Path | None = None) -> None:
    p = path or trust_file_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    payload: dict[str, Any] = {"version": 1, "projects": projects}
    p.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def project_key(project_dir: Path) -> str:
    """Stable string key for a project root."""
    return str(project_dir.resolve())


def record_trust(
    project_dir: Path,
    *,
    trust_path: Path | None = None,
) -> str:
    """Trust `.ptk.toml` in `project_dir` (must exist). Returns the SHA256 recorded."""
    root = project_dir.resolve()
    toml = root / ".ptk.toml"
    if not toml.is_file():
        msg = f"No .ptk.toml at {toml}"
        raise FileNotFoundError(msg)
    digest = sha256_file(toml)
    projects = _load_projects(trust_path)
    projects[project_key(root)] = digest
    _save_projects(projects, trust_path)
    return digest


def revoke_trust(project_dir: Path, *, trust_path: Path | None = None) -> bool:
    """Remove trust entry for `project_dir`. Returns True if an entry was removed."""
    root = project_dir.resolve()
    projects = _load_projects(trust_path)
    key = project_key(root)
    if key not in projects:
        return False
    del projects[key]
    _save_projects(projects, trust_path)
    return True


def is_trusted(
    project_dir: Path,
    toml_path: Path,
    *,
    trust_path: Path | None = None,
) -> bool:
    """True if `toml_path` under `project_dir` matches the stored SHA256."""
    root = project_dir.resolve()
    t = toml_path.resolve()
    if not t.is_file():
        return False
    expected = _load_projects(trust_path).get(project_key(root))
    if expected is None:
        return False
    return sha256_file(t) == expected


def find_ptk_toml(start_dir: Path | None = None) -> Path | None:
    """Walk upward from `start_dir` (default cwd) and return the first `.ptk.toml` path."""
    cur = (start_dir or Path.cwd()).resolve()
    while True:
        candidate = cur / ".ptk.toml"
        if candidate.is_file():
            return candidate
        parent = cur.parent
        if parent == cur:
            return None
        cur = parent
