import sqlite3
import time
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path


def get_db_path() -> Path:
    """Resolve analytics DB path (honors config.toml `tracking.database_path` when set)."""
    from ptk.core.config import Config

    cfg = Config.load()
    if cfg.db_path:
        path = Path(cfg.db_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    db_dir = Path.home() / ".local" / "share" / "ptk"
    db_dir.mkdir(parents=True, exist_ok=True)
    return db_dir / "analytics.db"


@contextmanager
def get_db_connection(db_path: Path | None = None) -> Generator[sqlite3.Connection, None, None]:
    """Context manager for SQLite database connection."""
    path = db_path or get_db_path()
    conn = sqlite3.connect(path)
    try:
        # Initialize schema if it doesn't exist
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS commands (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp   INTEGER NOT NULL,
                project     TEXT NOT NULL,
                agent       TEXT DEFAULT 'shell',
                raw_cmd     TEXT NOT NULL,
                ptk_cmd     TEXT NOT NULL,
                raw_tokens  INTEGER NOT NULL,
                ptk_tokens  INTEGER NOT NULL,
                duration_ms INTEGER NOT NULL
            )
            """
        )

        # Migration: Add agent column if it doesn't exist
        try:
            conn.execute("ALTER TABLE commands ADD COLUMN agent TEXT DEFAULT 'shell'")
        except sqlite3.OperationalError:
            pass # column already exists
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS parse_failures (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp   INTEGER NOT NULL,
                raw_cmd     TEXT NOT NULL,
                error       TEXT NOT NULL,
                ran_ok      INTEGER NOT NULL
            )
            """
        )
        conn.commit()
        yield conn
    finally:
        conn.close()


def record_parse_failure(
    raw_cmd: str,
    error: str,
    *,
    ran_ok: bool = False,
    db_path: Path | None = None,
) -> None:
    """Append a row to `parse_failures` (visible via `ptk gain --failures`)."""
    with get_db_connection(db_path) as conn:
        conn.execute(
            """
            INSERT INTO parse_failures (timestamp, raw_cmd, error, ran_ok)
            VALUES (?, ?, ?, ?)
            """,
            (int(time.time()), raw_cmd, error, 1 if ran_ok else 0),
        )
        conn.commit()


class TimedExecution:
    """Track execution time and tokens for analytics."""

    def __init__(self, db_path: Path | None = None) -> None:
        self.start_time = time.time()
        self.db_path = db_path

    @classmethod
    def start(cls, db_path: Path | None = None) -> "TimedExecution":
        return cls(db_path)

    def track(
        self,
        raw_cmd: str,
        ptk_cmd: str,
        raw_output: str,
        filtered_output: str,
        project: str = "unknown",
        agent: str | None = None,
    ) -> None:
        """Record the execution to the database."""
        import os
        if agent is None:
            agent = os.environ.get("PTK_AGENT", "shell")
        
        duration_ms = int((time.time() - self.start_time) * 1000)

        # Simple heuristic token estimation (avg 4 chars per token)
        raw_tokens = len(raw_output) // 4
        ptk_tokens = len(filtered_output) // 4

        with get_db_connection(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO commands
                (timestamp, project, agent, raw_cmd, ptk_cmd, raw_tokens, ptk_tokens, duration_ms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    int(time.time()),
                    project,
                    agent,
                    raw_cmd,
                    ptk_cmd,
                    raw_tokens,
                    ptk_tokens,
                    duration_ms,
                ),
            )
            conn.commit()
