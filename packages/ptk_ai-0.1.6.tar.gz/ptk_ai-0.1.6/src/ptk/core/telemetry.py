"""Opt-in usage ping (roadmap Phase 2.4) — placeholder until policy + transport are defined."""


def maybe_send_daily_ping() -> None:
    """No-op: wire to config.toml `telemetry.enabled` when implemented."""
    return None
