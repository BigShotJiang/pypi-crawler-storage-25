"""Shared CLI output helpers (verbose mode, etc.)."""

from __future__ import annotations

import typer


def emit_filtered_output(raw: str, filtered: str, *, nl: bool = True) -> None:
    """Print filtered output; if verbose mode is on, print raw first (roadmap §3)."""
    from ptk.cli import verbose_flag

    if verbose_flag > 0 and raw:
        typer.echo("[ptk verbose] raw output:", err=False)
        typer.echo(raw, err=False)
        typer.echo("--- filtered ---", err=False)
    typer.echo(filtered, nl=nl, err=False)
