import re
import shlex
import shutil
import subprocess
import sys
from collections.abc import Callable

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[mGKHF]")


def strip_ansi(text: str) -> str:
    """Remove ANSI escape codes."""
    return _ANSI_RE.sub("", text)


def shell_split(cmd: str) -> list[str]:
    """Split a shell command string into arguments."""
    return shlex.split(cmd)


def resolve_command(name: str) -> str:
    """Resolve command to full path, honoring $PATH and shims."""
    resolved = shutil.which(name)
    if not resolved:
        print(f"[ptk: command not found: {name}]", file=sys.stderr)
        sys.exit(127)
    return resolved


def run_capturing(
    args: list[str],
    *,
    env: dict[str, str] | None = None,
    cwd: str | None = None,
) -> tuple[str, str, int]:
    """Run command, capture stdout+stderr, return (stdout, stderr, returncode).
    Uses subprocess.run with text=True, encoding='utf-8', errors='replace'.
    """
    if not args:
        return "", "", 0
    resolved_args = [resolve_command(args[0])] + args[1:]
    try:
        result = subprocess.run(
            resolved_args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
            cwd=cwd,
            check=False,
        )
        return result.stdout, result.stderr, result.returncode
    except FileNotFoundError:
        print(f"[ptk: command not found: {args[0]}]", file=sys.stderr)
        sys.exit(127)


def run_streaming(
    args: list[str],
    *,
    env: dict[str, str] | None = None,
    cwd: str | None = None,
) -> int:
    """Run command with inherited stdio (no capturing). Returns exit code."""
    if not args:
        return 0
    resolved_args = [resolve_command(args[0])] + args[1:]
    try:
        result = subprocess.run(
            resolved_args,
            env=env,
            cwd=cwd,
            check=False,
        )
        return result.returncode
    except FileNotFoundError:
        print(f"[ptk: command not found: {args[0]}]", file=sys.stderr)
        sys.exit(127)


def run_streaming_filter(
    args: list[str],
    filter_fn: Callable[[str], str],
    *,
    env: dict[str, str] | None = None,
) -> int:
    """Stream stdout through filter_fn line-by-line, inherit stderr. Returns exit code."""
    if not args:
        return 0
    resolved_args = [resolve_command(args[0])] + args[1:]
    try:
        with subprocess.Popen(
            resolved_args,
            stdout=subprocess.PIPE,
            stderr=sys.stderr,  # inherit stderr
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,  # line buffered
            env=env,
        ) as proc:
            if proc.stdout:
                for line in proc.stdout:
                    filtered_line = filter_fn(line)
                    if filtered_line:
                        sys.stdout.write(filtered_line)
                        sys.stdout.flush()
            proc.wait()
            return proc.returncode
    except FileNotFoundError:
        print(f"[ptk: command not found: {args[0]}]", file=sys.stderr)
        sys.exit(127)
