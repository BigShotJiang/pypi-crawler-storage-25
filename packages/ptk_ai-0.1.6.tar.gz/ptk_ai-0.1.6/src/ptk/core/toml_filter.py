import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass
class TomlFilter:
    pattern: re.Pattern[str]
    drop_lines: list[re.Pattern[str]]
    group_lines: list[re.Pattern[str]]
    max_lines: int | None = None
    trust_required: bool = True


def select_filter_for_command(data: dict[str, Any], command: str) -> TomlFilter | None:
    """Pick the first filter in an already-loaded TOML document that matches `command`."""
    for toml_filter in _load_toml_filter(data):
        if toml_filter.pattern.search(command):
            return toml_filter
    return None


def _load_toml_filter(data: dict[str, Any]) -> list[TomlFilter]:
    filters = []
    if "filters" in data:
        for f in data["filters"]:
            pattern = re.compile(f["pattern"])
            drop_lines = [re.compile(p) for p in f.get("drop_lines", [])]
            group_lines = [re.compile(p) for p in f.get("group_lines", [])]
            max_lines = f.get("max_lines")
            trust_required = f.get("trust_required", True)
            filters.append(
                TomlFilter(
                    pattern=pattern,
                    drop_lines=drop_lines,
                    group_lines=group_lines,
                    max_lines=max_lines,
                    trust_required=trust_required,
                )
            )
    return filters


def find_matching_filter(command: str, start_dir: Path | None = None) -> TomlFilter | None:
    """Walk up directory tree, load `.ptk.toml`, return first matching trusted filter."""
    from ptk.core.trust_store import is_trusted

    if start_dir is None:
        start_dir = Path.cwd()

    current_dir = start_dir
    while True:
        toml_path = current_dir / ".ptk.toml"
        if toml_path.exists():
            try:
                with open(toml_path, "rb") as f:
                    data = tomllib.load(f)
                project_root = toml_path.parent.resolve()
                for toml_filter in _load_toml_filter(data):
                    if not toml_filter.pattern.search(command):
                        continue
                    if toml_filter.trust_required and not is_trusted(
                        project_root,
                        toml_path,
                    ):
                        continue
                    return toml_filter
            except (OSError, TypeError, ValueError):
                # Malformed TOML or IO — skip this directory and keep walking
                pass

        parent_dir = current_dir.parent
        if parent_dir == current_dir:
            break
        current_dir = parent_dir

    return None


def apply_filter(f: TomlFilter, output: str) -> str:
    lines = output.splitlines()
    result = []

    group_count = 0
    in_group = False

    for line in lines:
        if any(p.search(line) for p in f.drop_lines):
            continue

        is_grouped = any(p.search(line) for p in f.group_lines)
        if is_grouped:
            if not in_group:
                in_group = True
                group_count = 1
                result.append(line)
            else:
                group_count += 1
                if group_count <= 5:  # Default max_per_group
                    result.append(line)
        else:
            if in_group:
                if group_count > 5:
                    result.append(f"... {group_count - 5} more")
                in_group = False
                group_count = 0
            result.append(line)

    if in_group and group_count > 5:
        result.append(f"... {group_count - 5} more")

    if f.max_lines is not None and len(result) > f.max_lines:
        result = result[: f.max_lines] + ["..."]

    return "\n".join(result)
