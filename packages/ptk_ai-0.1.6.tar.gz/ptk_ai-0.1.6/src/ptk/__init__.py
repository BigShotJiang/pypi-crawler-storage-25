"""Python Token Killer (ptk) — token-optimized CLI proxy."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ptk")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["__version__"]
