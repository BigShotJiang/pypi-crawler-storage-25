"""Tests for `ptk env`, `ptk tree`, `ptk diff` helpers."""

from ptk.cmds.system_cmd import (
    _filter_env_output,
    _filter_plain_diff,
    _filter_tree_output,
    _mask_env_line,
)


def test_mask_env_line_secret_suffixes() -> None:
    assert _mask_env_line("MY_API_KEY=abc") == "MY_API_KEY=***"
    assert _mask_env_line("FOO_TOKEN=bar") == "FOO_TOKEN=***"
    assert _mask_env_line("X_SECRET=y") == "X_SECRET=***"
    assert _mask_env_line("PASSWORD=secret") == "PASSWORD=***"


def test_mask_env_line_benign() -> None:
    assert _mask_env_line("PATH=/usr/bin") == "PATH=/usr/bin"
    assert _mask_env_line("NODE_ENV=development") == "NODE_ENV=development"


def test_filter_env_output_masks_and_truncates() -> None:
    raw = "PATH=/x\nMY_API_KEY=secret\nPATH=/x\n" + ("A" * 300 + "=v\n")
    out = _filter_env_output(raw)
    assert "MY_API_KEY=***" in out
    assert "secret" not in out
    assert "PATH=/x" in out


def test_filter_plain_diff_keeps_structure() -> None:
    raw = """--- a.txt
+++ b.txt
@@ -1,3 +1,3 @@
 context
-old
+new
"""
    out = _filter_plain_diff(raw)
    assert "--- a.txt" in out
    assert "+++ b.txt" in out
    assert "@@ -1,3 +1,3 @@" in out
    assert "-old" in out
    assert "+new" in out
    assert "context" not in out


def test_filter_plain_diff_empty_returns_raw() -> None:
    raw = "only context\nno diff markers\n"
    assert _filter_plain_diff(raw) == raw


def test_filter_tree_truncates_tail() -> None:
    lines = [f"line-{i}" for i in range(500)]
    raw = "\n".join(lines)
    out = _filter_tree_output(raw)
    assert "[100 lines truncated]" in out
    assert "line-499" in out
