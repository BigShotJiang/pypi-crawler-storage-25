from ptk.cmds.cloud_cmd import (
    _compact_lines,
    _ensure_aws_json_output,
    _filter_aws_output,
    _filter_psql_output,
    _merge_streams,
)


def test_merge_streams_stderr() -> None:
    assert _merge_streams("a\n", "b\n") == "a\n\nb\n"
    assert _merge_streams("a", "") == "a"


def test_compact_lines_tail() -> None:
    raw = "\n".join(f"line {i}" for i in range(10))
    out = _compact_lines(raw, tail=3, max_len=100)
    assert "line 9" in out
    assert "truncated" in out
    assert "line 0" not in out


def test_ensure_aws_json_output_appends() -> None:
    assert _ensure_aws_json_output(["s3", "ls"]) == ["s3", "ls", "--output", "json"]


def test_ensure_aws_json_output_respects_existing() -> None:
    args = ["s3", "ls", "--output", "text"]
    assert _ensure_aws_json_output(args) == args


def test_ensure_aws_json_output_skips_configure() -> None:
    assert _ensure_aws_json_output(["configure", "list"]) == ["configure", "list"]


def test_filter_aws_output_minifies_json() -> None:
    raw = '{\n  "a": 1\n}\n'
    out = _filter_aws_output(raw, "")
    assert out == '{"a":1}'


def test_filter_psql_strips_box_drawing() -> None:
    v = "\u2502"
    h = "\u2500"
    raw = f"{v} id {v} name {v}\n{h * 5}\n{v} 1  {v} x    {v}\n"
    out = _filter_psql_output(raw)
    assert v not in out
    assert "id" in out and "name" in out
