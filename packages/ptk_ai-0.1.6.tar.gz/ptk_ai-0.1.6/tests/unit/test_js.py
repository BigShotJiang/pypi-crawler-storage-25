from ptk.cmds.js import _filter_npm_run


def test_filter_npm_run_removes_boilerplate() -> None:
    raw_output = """
> my-project@1.0.0 build
> tsc && vite build

vite v4.0.0 building for production...
✓ 123 modules transformed.
dist/index.html   0.45 kB
dist/assets/index-123.js   1.23 kB
"""
    filtered = _filter_npm_run(raw_output)
    assert "> my-project@1.0.0 build" not in filtered
    assert "> tsc && vite build" not in filtered
    assert "vite v4.0.0 building for production..." in filtered
    assert "dist/index.html   0.45 kB" in filtered


def test_filter_npm_run_leaves_normal_output_intact() -> None:
    raw_output = """
Some generic output
> not-a-boilerplate
Another line
"""
    filtered = _filter_npm_run(raw_output)
    assert "Some generic output" in filtered
    assert "> not-a-boilerplate" in filtered
    assert "Another line" in filtered
