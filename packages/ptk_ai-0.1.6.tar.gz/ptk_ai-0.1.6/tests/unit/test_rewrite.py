import pytest

from ptk.hooks.init import find_rewrite


@pytest.mark.parametrize(
    ("cmd", "expected"),
    [
        ("git status -sb", "ptk git status -sb"),
        ("npm run build", "ptk npm run build"),
        ("pnpm install", "ptk pnpm install"),
        ("npx eslint .", "ptk npx eslint ."),
        ("npx vitest run", "ptk npx vitest run"),
        ("pytest -q", "ptk pytest -q"),
        ("python -m pytest tests/unit", "ptk pytest tests/unit"),
        ("ruff check .", "ptk ruff check ."),
        ("python -m ruff check src", "ptk ruff check src"),
        ("mypy pkg", "ptk mypy pkg"),
        ("python -m mypy t.py", "ptk mypy t.py"),
        ("pip install x", "ptk pip install x"),
        ("python -m pip list", "ptk pip list"),
        ("uv pip list", "ptk uv pip list"),
        ("cargo build --release", "ptk cargo build --release"),
        ("cargo build", "ptk cargo build"),
        ("gh pr list", "ptk gh pr list"),
        ("docker ps -a", "ptk docker ps -a"),
        ("kubectl get pods", "ptk kubectl get pods"),
        ("curl -s https://example.com", "ptk curl -s https://example.com"),
        ("wget -q u", "ptk wget -q u"),
        ("rg foo src", "ptk rg foo src"),
        ("ls -la", "ptk ls -la"),
        ("env", "ptk env"),
        ("env FOO=bar cmd", "ptk env FOO=bar cmd"),
        ("tree -L 2", "ptk tree -L 2"),
        ("diff -u a b", "ptk diff -u a b"),
        ("grep -nH foo *.rs", "ptk grep -nH foo *.rs"),
        ("find . -name '*.py'", "ptk find . -name '*.py'"),
        ("aws s3 ls", "ptk aws s3 ls"),
        ("psql -c 'select 1'", "ptk psql -c 'select 1'"),
        ("wc -l foo.txt", "ptk wc -l foo.txt"),
        ("go test ./...", "ptk go test ./..."),
        ("ptk git status", None),
        ("make test", None),
    ],
)
def test_find_rewrite(cmd: str, expected: str | None) -> None:
    assert find_rewrite(cmd) == expected
