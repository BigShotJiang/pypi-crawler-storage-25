import pytest

from ptk.cmds.search_list_cmd import (
    _filter_ls_output,
    _filter_path_lines_output,
    _filter_rg_output,
    _find_gnu_binary,
    _rg_match_path_prefix,
)


def test_rg_path_unix_column_mode() -> None:
    line = "src/lib.rs:10:5: let x = 1;"
    assert _rg_match_path_prefix(line) == "src/lib.rs"


def test_rg_path_windows_drive() -> None:
    line = r"C:\proj\a.rs:12:3: fn main"
    assert _rg_match_path_prefix(line) == r"C:\proj\a.rs"


def test_filter_rg_groups() -> None:
    raw = "src/a.rs:1:3:x\nsrc/a.rs:2:3:y\nsrc/b.rs:1:1:z\n"
    out = _filter_rg_output(raw)
    assert "=== src/a.rs ===" in out
    assert "=== src/b.rs ===" in out


def test_filter_ls_truncates() -> None:
    long_line = "x" * 300
    out = _filter_ls_output(long_line + "\nshort")
    assert "short" in out
    assert len(out) < len(long_line) + 20


def test_filter_path_lines_tail() -> None:
    raw = "\n".join(f"p{i}" for i in range(10))
    out = _filter_path_lines_output(raw, tail=3, max_len=100)
    assert "p9" in out
    assert "truncated" in out
    assert "p0" not in out


def test_find_gnu_binary_skips_windows_host_find(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("ptk.cmds.search_list_cmd.sys.platform", "win32")
    monkeypatch.setattr(
        "ptk.cmds.search_list_cmd.shutil.which",
        lambda _name: r"C:\Windows\System32\find.exe",
    )
    assert _find_gnu_binary() is None
