from pathlib import Path

import pytest
from typer.testing import CliRunner

from ptk.cli import app


def test_verify_cli_passes(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    toml = """[[filters]]
pattern = "^mycmd"
drop_lines = ["^skip:"]
group_lines = []
trust_required = false

[[test]]
name = "drops skip"
match_command = "mycmd"
input = '''
hello
skip: noise
world
'''
expect_contains = "world"
"""
    (tmp_path / ".ptk.toml").write_text(toml, encoding="utf-8")

    result = CliRunner().invoke(app, ["verify"])
    assert result.exit_code == 0
    assert "OK" in result.stdout


def test_verify_cli_failure(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    toml = """[[filters]]
pattern = "^mycmd"
drop_lines = []
group_lines = []
trust_required = false

[[test]]
match_command = "mycmd"
input = "x"
expected = "y"
"""
    (tmp_path / ".ptk.toml").write_text(toml, encoding="utf-8")

    result = CliRunner().invoke(app, ["verify"])
    assert result.exit_code == 1
    assert "FAIL" in result.stdout
