from ptk.cmds.cargo_cmd import _filter_cargo_build_like, _filter_cargo_clippy, _filter_cargo_test


def test_cargo_build_strips_compiling() -> None:
    raw = "\n".join(
        [
            "   Compiling foo v1.0",
            "    Blocking waiting for file lock",
            "error[E0425]: cannot find value `x`",
            "    Finished `dev` profile",
        ]
    )
    out = _filter_cargo_build_like(raw)
    assert "Compiling" not in out
    assert "error[E0425]" in out
    assert "Finished" in out


def test_cargo_test_keeps_failures() -> None:
    raw = "\n".join(
        [
            "running 2 tests",
            "test a ... ok",
            "test b ... FAILED",
            "failures:",
            "---- b stdout ----",
            "thread 'main' panicked",
            "test result: FAILED. 1 passed; 1 failed",
        ]
    )
    out = _filter_cargo_test(raw)
    assert "FAILED" in out
    assert "panicked" in out
    assert "test result" in out


def test_cargo_clippy_drops_checking() -> None:
    raw = "\n".join(
        [
            "    Checking mycrate v0.1.0",
            "warning: unused variable",
            " --> src/lib.rs:1:5",
        ]
    )
    out = _filter_cargo_clippy(raw)
    assert "Checking" not in out
    assert "warning" in out
