from __future__ import annotations

from pathlib import Path

import pytest
from rich.console import Console

from ptk.hooks.agents import codex


def test_codex_global_install_writes_ptk_and_agents(tmp_path: Path) -> None:
    codex.install(global_=True, home=tmp_path, console=Console(record=True))
    ptk = tmp_path / ".codex" / "PTK.md"
    agents = tmp_path / ".codex" / "AGENTS.md"
    assert ptk.is_file()
    assert "ptk git status" in ptk.read_text(encoding="utf-8")
    assert agents.is_file()
    assert "@PTK.md" in agents.read_text(encoding="utf-8")


def test_codex_project_install_uses_cwd(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    codex.install(global_=False, console=Console(record=True))
    assert (tmp_path / "PTK.md").is_file()
    assert (tmp_path / "AGENTS.md").read_text(encoding="utf-8").strip() == "@PTK.md"


def test_codex_idempotent_second_run_no_duplicate_ref(tmp_path: Path) -> None:
    codex.install(global_=True, home=tmp_path, console=Console(record=True))
    text1 = (tmp_path / ".codex" / "AGENTS.md").read_text(encoding="utf-8")
    codex.install(global_=True, home=tmp_path, console=Console(record=True))
    text2 = (tmp_path / ".codex" / "AGENTS.md").read_text(encoding="utf-8")
    assert text1 == text2
    assert text2.count("@PTK.md") == 1


def test_codex_migrates_rtk_block_and_reference(tmp_path: Path) -> None:
    base = tmp_path / ".codex"
    base.mkdir(parents=True)
    agents = base / "AGENTS.md"
    agents.write_text(
        '<!-- rtk-instructions -->\nold\n<!-- /rtk-instructions -->\n\n@RTK.md\n',
        encoding="utf-8",
    )
    (base / "PTK.md").write_text("# old\n", encoding="utf-8")

    codex.install(global_=True, home=tmp_path, console=Console(record=True))

    body = agents.read_text(encoding="utf-8")
    assert "rtk-instructions" not in body
    assert "@RTK.md" not in body
    assert "@PTK.md" in body
