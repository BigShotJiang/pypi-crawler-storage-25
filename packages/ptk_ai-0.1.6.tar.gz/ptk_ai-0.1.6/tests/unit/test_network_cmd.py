from ptk.cmds.network_cmd import (
    _filter_wget_merged,
    _maybe_pretty_json,
    _writes_to_file,
)


def test_writes_to_file_detects_dash_o() -> None:
    assert _writes_to_file(["-o", "/tmp/x", "http://a"])
    assert _writes_to_file(["--output", "f", "u"])
    assert _writes_to_file(["--output=f", "u"])
    assert _writes_to_file(["-O", "u"])
    assert not _writes_to_file(["http://localhost"])


def test_maybe_pretty_json() -> None:
    assert _maybe_pretty_json('  {"a": 1}  ') == '{\n  "a": 1\n}'
    assert _maybe_pretty_json("not json") is None


def test_filter_wget_drops_percent() -> None:
    raw = "50%\n100%\nHTTP request sent\n"
    out = _filter_wget_merged(raw)
    assert "50%" not in out
    assert "HTTP" in out
