from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from ptk.cli import app


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@patch("ptk.cmds.python_cmds.run_capturing")
def test_pytest_subcommand_summary_tail(mock_cap: MagicMock, runner: CliRunner) -> None:
    filler = "\n".join(f"line {i}" for i in range(40))
    mock_cap.return_value = (f"{filler}\nall green\n", "", 0)
    result = runner.invoke(app, ["pytest", "-q", "tests/unit"])
    assert result.exit_code == 0
    mock_cap.assert_called_once()
    assert "line" in result.stdout or "green" in result.stdout


@patch("ptk.cmds.python_cmds.run_capturing")
def test_pytest_subcommand_keeps_failures(mock_cap: MagicMock, runner: CliRunner) -> None:
    mock_cap.return_value = (
        "some noise\nFAILED tests/test_x.py::test_a\nshort test summary info\n",
        "",
        1,
    )
    result = runner.invoke(app, ["pytest", "-q"])
    assert result.exit_code == 1
    assert "FAILED" in result.stdout
