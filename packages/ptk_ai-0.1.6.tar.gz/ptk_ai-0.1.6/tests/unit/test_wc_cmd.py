"""Tests for `ptk wc` helpers."""

from ptk.cmds.wc_cmd import _filter_wc_output


def test_filter_wc_strips_path_when_counts() -> None:
    raw = "  10   20   30  some/long/path.txt\n"
    out = _filter_wc_output(raw)
    assert "path" not in out
    assert "10 20 30" in out


def test_filter_wc_preserves_counts_only_line() -> None:
    assert _filter_wc_output("  1  2  3\n").strip() == "1 2 3"
