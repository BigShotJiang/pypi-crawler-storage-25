from ptk.cmds.git import (
    _filter_git_commit,
    _filter_git_diff,
    _filter_git_status,
    _filter_git_transfer,
)


def test_filter_git_status() -> None:
    raw = """On branch main
Your branch is up to date with 'origin/main'.

Changes to be committed:
  (use "git restore --staged <file>..." to unstage)
	modified:   README.md

no changes added to commit (use "git add" and/or "git commit -a")
"""
    filtered = _filter_git_status(raw)
    assert 'use "git restore' not in filtered
    assert "no changes added to commit" not in filtered
    assert "modified:   README.md" in filtered


def test_filter_git_diff() -> None:
    raw = """diff --git a/test.txt b/test.txt
index 83ea1c2..e69de29 100644
--- a/test.txt
+++ b/test.txt
@@ -1,3 +1,4 @@
 line 1
-line 2
+line 2 mod
 line 3
+line 4
"""
    filtered = _filter_git_diff(raw)
    assert "diff --git" in filtered
    assert "index 83ea1c2" not in filtered
    assert "--- a/" in filtered
    assert "+++ b/" in filtered
    assert "@@ -1,3" in filtered
    assert "-line 2" in filtered
    assert "+line 2 mod" in filtered
    assert "line 1" not in filtered
    assert "line 3" not in filtered


def test_filter_git_commit() -> None:
    raw = """[main 1234567] Some commit message
 1 file changed, 1 insertion(+)
 create mode 100644 new_file.txt"""
    filtered = _filter_git_commit(raw)
    assert "[main 1234567] Some commit message" in filtered
    assert "1 file changed" in filtered


def test_filter_git_transfer() -> None:
    raw = """Enumerating objects: 5, done.
Counting objects: 100% (5/5), done.
Delta compression using up to 8 threads
Compressing objects: 100% (3/3), done.
Writing objects: 100% (3/3), 300 bytes | 300.00 KiB/s, done.
Total 3 (delta 1), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (1/1), completed with 1 local object.
To github.com:user/repo.git
   abcdef1..1234567  main -> main"""
    filtered = _filter_git_transfer(raw)
    assert "Enumerating objects" not in filtered
    assert "Counting objects" not in filtered
    assert "Writing objects" not in filtered
    assert "To github.com" in filtered
    assert "main -> main" in filtered
