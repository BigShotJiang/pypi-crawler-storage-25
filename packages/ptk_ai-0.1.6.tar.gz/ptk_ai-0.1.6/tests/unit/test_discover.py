import json
import time
from pathlib import Path

import pytest

from ptk.discover.discover import scan_history


def test_scan_history_respects_cutoff(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import ptk.discover.discover as d

    hist = tmp_path / "history.jsonl"
    payload = {"timestamp": int(time.time()), "text": "git status on main"}
    hist.write_text(json.dumps(payload) + "\n", encoding="utf-8")

    monkeypatch.setitem(d.HISTORY_PATHS, "claude", hist)

    missed = scan_history("claude", since_days=7)
    assert "git status" in missed


def test_scan_history_skips_stale_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import ptk.discover.discover as d

    hist = tmp_path / "history.jsonl"
    hist.write_text('{"x": "git status"}\n', encoding="utf-8")
    old = time.time() - 30 * 86400
    Path(hist).touch()
    import os

    os.utime(hist, (old, old))

    monkeypatch.setitem(d.HISTORY_PATHS, "claude", hist)

    missed = scan_history("claude", since_days=7)
    assert missed == []
