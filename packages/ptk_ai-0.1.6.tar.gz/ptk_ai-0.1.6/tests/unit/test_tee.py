from pathlib import Path
from unittest.mock import MagicMock, patch

from ptk.core.tee import _clean_command_name, tee_and_hint


def test_clean_command_name() -> None:
    assert _clean_command_name("git status") == "git_status"
    assert _clean_command_name("npm run dev") == "npm_run_dev"
    assert _clean_command_name("echo 'hello world'") == "echo_hello_world"
    assert _clean_command_name("cmd_with_underscores") == "cmd_with_underscores"
    assert _clean_command_name("cmd_with_special!@#chars") == "cmd_with_special_chars"
    # Ensure truncation length
    long_cmd = "a" * 50
    assert _clean_command_name(long_cmd) == "a" * 30


@patch("ptk.core.tee.get_tee_dir")
@patch("ptk.core.tee.time.time")
def test_tee_and_hint_success(
    mock_time: MagicMock, mock_get_dir: MagicMock, tmp_path: Path
) -> None:
    mock_time.return_value = 1234567890.0
    mock_get_dir.return_value = tmp_path

    cmd = "npm run dev"
    raw_output = "Error output\nfrom npm run dev"
    exit_code = 1

    hint = tee_and_hint(raw_output, cmd, exit_code)

    assert hint is not None
    assert f"exit code {exit_code}" in hint
    assert "full output logged to" in hint

    log_file = tmp_path / "1234567890_npm_run_dev.log"
    assert str(log_file) in hint
    assert log_file.exists()
    assert log_file.read_text() == raw_output


def test_tee_and_hint_success_exit_code() -> None:
    assert tee_and_hint("output", "cmd", 0) is None


def test_tee_and_hint_empty_output() -> None:
    assert tee_and_hint("", "cmd", 1) is None
    assert tee_and_hint("   \n  ", "cmd", 1) is None


@patch("ptk.core.tee.get_tee_dir")
@patch("pathlib.Path.write_text")
def test_tee_and_hint_write_error(
    mock_write: MagicMock, mock_get_dir: MagicMock, tmp_path: Path
) -> None:
    mock_get_dir.return_value = tmp_path
    mock_write.side_effect = PermissionError("Access denied")

    hint = tee_and_hint("output", "cmd", 1)

    # Should fail gracefully and return None when it cannot write
    assert hint is None
