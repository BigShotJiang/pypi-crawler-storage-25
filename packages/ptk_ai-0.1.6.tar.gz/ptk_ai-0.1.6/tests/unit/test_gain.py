import json
import sqlite3
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from ptk.analytics.gain import gain_app


@pytest.fixture
def memory_conn() -> Generator[sqlite3.Connection, None, None]:
    conn = sqlite3.connect(":memory:")
    conn.execute(
        """
        CREATE TABLE commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp INTEGER NOT NULL,
            project TEXT NOT NULL,
            raw_cmd TEXT NOT NULL,
            ptk_cmd TEXT NOT NULL,
            raw_tokens INTEGER NOT NULL,
            ptk_tokens INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE parse_failures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp INTEGER NOT NULL,
            raw_cmd TEXT NOT NULL,
            error TEXT NOT NULL,
            ran_ok INTEGER NOT NULL
        )
        """
    )
    conn.commit()
    yield conn
    conn.close()


def test_gain_json_summary(memory_conn: sqlite3.Connection) -> None:
    memory_conn.execute(
        "INSERT INTO commands (timestamp, project, raw_cmd, ptk_cmd, raw_tokens, ptk_tokens, "
        "duration_ms) VALUES (1700000000, 'proj', 'git status', 'ptk git status', 400, 100, 10)",
    )
    memory_conn.commit()

    @contextmanager
    def fake_db() -> Generator[sqlite3.Connection, None, None]:
        yield memory_conn

    with (
        patch("ptk.analytics.gain.get_db_connection", fake_db),
        patch(
            "ptk.analytics.gain.get_db_path",
            return_value=Path("/tmp/x.db"),
        ),
    ):
        runner = CliRunner()
        result = runner.invoke(gain_app, ["--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["tokens_saved"] == 300
    assert data["reduction_percent"] == 75.0


def test_gain_failures_table(memory_conn: sqlite3.Connection) -> None:
    memory_conn.execute(
        "INSERT INTO parse_failures (timestamp, raw_cmd, error, ran_ok) "
        "VALUES (1700000000, 'bad', 'boom', 0)",
    )
    memory_conn.commit()

    @contextmanager
    def fake_db() -> Generator[sqlite3.Connection, None, None]:
        yield memory_conn

    with patch("ptk.analytics.gain.get_db_connection", fake_db):
        runner = CliRunner()
        result = runner.invoke(gain_app, ["--format", "json", "--failures"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert len(data["failures"]) == 1
    assert data["failures"][0]["error"] == "boom"


def test_sparkline_scaling() -> None:
    from ptk.analytics.gain import _sparkline_from_counts

    s = _sparkline_from_counts([0, 5, 10, 10], width=4)
    assert len(s) == 4
