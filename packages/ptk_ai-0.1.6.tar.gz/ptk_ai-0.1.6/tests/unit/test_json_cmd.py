"""Tests for `ptk json` helpers."""

from ptk.cmds.json_cmd import _limit_depth, _schema_skeleton


def test_limit_depth_nested() -> None:
    data = {"a": {"b": {"c": 1}}}
    out = _limit_depth(data, depth=2)
    assert out == {"a": {"b": "…"}}


def test_limit_depth_long_list() -> None:
    out = _limit_depth({"x": list(range(5))}, depth=5, max_list=3)
    assert out["x"][-1].startswith("…(2 more)")


def test_schema_skeleton_types() -> None:
    sk = _schema_skeleton({"n": 1, "s": "a", "b": True, "z": None}, depth=6)
    assert sk["n"] == "int"
    assert sk["s"] == "string"
    assert sk["b"] == "bool"
    assert sk["z"] == "null"
