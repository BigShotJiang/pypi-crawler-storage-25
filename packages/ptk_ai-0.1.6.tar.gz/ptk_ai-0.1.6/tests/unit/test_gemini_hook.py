from __future__ import annotations

import json

from ptk.hooks.gemini_hook import gemini_hook_output_for_payload, gemini_hook_output_for_stdin


def test_gemini_allow_non_shell_tool() -> None:
    raw = json.dumps({"tool_name": "edit", "tool_input": {"command": "x"}})
    assert gemini_hook_output_for_stdin(raw) == '{"decision":"allow"}'


def test_gemini_rewrite_git_status() -> None:
    raw = json.dumps(
        {"tool_name": "run_shell_command", "tool_input": {"command": "git status"}},
    )
    out = json.loads(gemini_hook_output_for_stdin(raw))
    assert out["decision"] == "allow"
    assert out["hookSpecificOutput"]["tool_input"]["command"] == "ptk git status"


def test_gemini_allow_heredoc() -> None:
    payload = {
        "tool_name": "run_shell_command",
        "tool_input": {"command": "cat <<EOF\nx\nEOF"},
    }
    assert gemini_hook_output_for_payload(payload) == '{"decision":"allow"}'


def test_gemini_allow_unsupported_command() -> None:
    raw = json.dumps(
        {"tool_name": "run_shell_command", "tool_input": {"command": "unknown-cmd foo"}},
    )
    assert gemini_hook_output_for_stdin(raw) == '{"decision":"allow"}'


def test_gemini_install_writes_script_and_settings(tmp_path) -> None:
    from rich.console import Console

    from ptk.hooks.agents import gemini

    gemini.install_powershell(home=tmp_path, console=Console(record=True))
    script = tmp_path / ".gemini" / "hooks" / "ptk-hook-gemini.ps1"
    assert script.is_file()
    assert "hook-gemini" in script.read_text(encoding="utf-8")

    settings = json.loads((tmp_path / ".gemini" / "settings.json").read_text(encoding="utf-8"))
    bt = settings["hooks"]["BeforeTool"]
    assert len(bt) == 1
    assert bt[0]["matcher"] == "run_shell_command"
    assert "ptk-hook-gemini.ps1" in bt[0]["hooks"][0]["command"]
