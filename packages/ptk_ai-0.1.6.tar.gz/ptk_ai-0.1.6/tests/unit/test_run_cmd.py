from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from ptk.cli import app


@patch("ptk.cmds.run_cmd.run_capturing")
@patch("ptk.cmds.run_cmd.find_matching_filter")
def test_run_cmd_no_filter_passthrough(
    mock_find: MagicMock,
    mock_run: MagicMock,
) -> None:
    mock_find.return_value = None
    mock_run.return_value = ("hello\n", "", 0)
    result = CliRunner().invoke(app, ["run", "echo", "x"])
    assert result.exit_code == 0
    mock_run.assert_called_once_with(["echo", "x"])
    assert "hello" in result.stdout


@patch("ptk.cmds.run_cmd.apply_filter")
@patch("ptk.cmds.run_cmd.run_capturing")
@patch("ptk.cmds.run_cmd.find_matching_filter")
def test_run_cmd_applies_toml_filter(
    mock_find: MagicMock,
    mock_run: MagicMock,
    mock_apply: MagicMock,
) -> None:
    fake_f = object()
    mock_find.return_value = fake_f
    mock_run.return_value = ("a\nb\n", "", 0)
    mock_apply.return_value = "z"
    result = CliRunner().invoke(app, ["run", "mytool"])
    assert result.exit_code == 0
    mock_apply.assert_called_once_with(fake_f, "a\nb\n")
    assert "z" in result.stdout
