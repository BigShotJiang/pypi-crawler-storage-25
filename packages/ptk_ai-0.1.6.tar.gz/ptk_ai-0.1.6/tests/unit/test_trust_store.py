from pathlib import Path

import pytest

from ptk.core import trust_store as ts


def test_record_and_is_trusted(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ts, "trust_file_path", lambda: tmp_path / ".ptk-trusted")
    (tmp_path / ".ptk.toml").write_text("x = 1\n", encoding="utf-8")
    digest = ts.record_trust(tmp_path)
    assert len(digest) == 64
    toml = tmp_path / ".ptk.toml"
    assert ts.is_trusted(tmp_path, toml) is True


def test_revoke_trust(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ts, "trust_file_path", lambda: tmp_path / ".ptk-trusted")
    (tmp_path / ".ptk.toml").write_text("a", encoding="utf-8")
    ts.record_trust(tmp_path)
    assert ts.revoke_trust(tmp_path) is True
    assert ts.revoke_trust(tmp_path) is False


def test_hash_change_breaks_trust(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ts, "trust_file_path", lambda: tmp_path / ".ptk-trusted")
    (tmp_path / ".ptk.toml").write_text("v1", encoding="utf-8")
    ts.record_trust(tmp_path)
    (tmp_path / ".ptk.toml").write_text("v2", encoding="utf-8")
    assert ts.is_trusted(tmp_path, tmp_path / ".ptk.toml") is False


def test_find_ptk_toml(tmp_path: Path) -> None:
    sub = tmp_path / "a" / "b"
    sub.mkdir(parents=True)
    (tmp_path / ".ptk.toml").write_text("", encoding="utf-8")
    assert ts.find_ptk_toml(sub) == tmp_path / ".ptk.toml"
