from ptk.cmds.python_cmds import _filter_mypy_output, _filter_pip_output, _filter_ruff_output


def test_filter_ruff_groups_by_rule() -> None:
    raw = (
        "src/a.py:1:5: E501 Line too long\n"
        "src/b.py:2:1: F401 imported but unused\n"
        "src/c.py:3:3: E501 another long\n"
    )
    out = _filter_ruff_output(raw)
    assert "--- E501 ---" in out
    assert "--- F401 ---" in out
    assert "Line too long" in out


def test_filter_mypy_groups_by_file() -> None:
    raw = (
        "note: In module imported here\n"
        "pkg/mod.py:10: error: Incompatible types\n"
        "pkg/mod.py:11: note: ...\n"
        "other.py:1: error: Name not defined\n"
    )
    out = _filter_mypy_output(raw)
    assert "pkg/mod.py" in out
    assert "other.py" in out
    assert "Incompatible" in out


def test_filter_pip_drops_collecting() -> None:
    raw = "Collecting foo\n  Downloading foo-1.whl (1 kB)\nSuccessfully installed foo-1\n"
    out = _filter_pip_output(raw)
    assert "Collecting" not in out
    assert "Successfully installed" in out
