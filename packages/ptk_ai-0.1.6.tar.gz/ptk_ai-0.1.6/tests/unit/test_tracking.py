import sqlite3
from pathlib import Path

import pytest

from ptk.core.tracking import (
    TimedExecution,
    get_db_connection,
    record_parse_failure,
)


def test_get_db_connection(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"

    with get_db_connection(db_path) as conn:
        assert isinstance(conn, sqlite3.Connection)

        # Verify schema
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = {row[0] for row in cursor.fetchall()}

        assert "commands" in tables
        assert "parse_failures" in tables

    # Verify connection is closed
    with pytest.raises(sqlite3.ProgrammingError):
        conn.execute("SELECT 1")


def test_timed_execution_track(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"
    timer = TimedExecution.start(db_path)

    timer.track(
        raw_cmd="git status",
        ptk_cmd="ptk git status",
        raw_output="very long raw output text that simulates 1000 characters" * 20,
        filtered_output="short output",
        project="my-project",
    )

    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT project, raw_cmd, ptk_cmd, raw_tokens, ptk_tokens FROM commands")
        rows = cursor.fetchall()

        assert len(rows) == 1
        project, raw_cmd, ptk_cmd, raw_tokens, ptk_tokens = rows[0]

        assert project == "my-project"
        assert raw_cmd == "git status"
        assert ptk_cmd == "ptk git status"
        assert raw_tokens > 0
        assert ptk_tokens > 0
        assert raw_tokens > ptk_tokens


def test_record_parse_failure(tmp_path: Path) -> None:
    db_path = tmp_path / "pf.db"
    record_parse_failure("ptk foo", "boom", ran_ok=False, db_path=db_path)
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute("SELECT raw_cmd, error, ran_ok FROM parse_failures")
        rows = cur.fetchall()
    assert len(rows) == 1
    assert rows[0][0] == "ptk foo"
    assert rows[0][1] == "boom"
    assert rows[0][2] == 0
