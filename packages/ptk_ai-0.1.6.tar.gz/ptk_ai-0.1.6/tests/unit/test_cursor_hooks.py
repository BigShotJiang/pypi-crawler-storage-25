from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console

from ptk.hooks.agents import cursor


def test_install_powershell_writes_script_and_hooks_json(tmp_path: Path) -> None:
    console = Console(record=True)
    cursor.install_powershell(home=tmp_path, console=console)

    script = tmp_path / ".cursor" / "hooks" / "ptk-rewrite.ps1"
    assert script.is_file()
    assert "ptk rewrite" in script.read_text(encoding="utf-8")

    hooks_path = tmp_path / ".cursor" / "hooks.json"
    data = json.loads(hooks_path.read_text(encoding="utf-8"))
    commands = data["hooks"]["preToolUse"]
    assert len(commands) == 1
    assert "ptk-rewrite.ps1" in commands[0]["command"]


def test_install_powershell_idempotent_when_marker_present(tmp_path: Path) -> None:
    hooks_dir = tmp_path / ".cursor" / "hooks"
    hooks_dir.mkdir(parents=True)
    script = hooks_dir / "ptk-rewrite.ps1"
    script.write_text("# stub\n", encoding="utf-8")

    preexisting = {
        "version": 1,
        "hooks": {
            "preToolUse": [{"command": f'pwsh -File "{script}"'}],
        },
    }
    hooks_json = tmp_path / ".cursor" / "hooks.json"
    hooks_json.write_text(json.dumps(preexisting), encoding="utf-8")

    console = Console(record=True)
    cursor.install_powershell(home=tmp_path, console=console)

    data = json.loads(hooks_json.read_text(encoding="utf-8"))
    assert len(data["hooks"]["preToolUse"]) == 1
