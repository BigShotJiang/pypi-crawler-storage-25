import re
from pathlib import Path

import pytest

from ptk.core.toml_filter import TomlFilter, apply_filter, find_matching_filter
from ptk.core.trust_store import record_trust


def test_apply_filter() -> None:
    f = TomlFilter(
        pattern=re.compile(r"mycmd"),
        drop_lines=[re.compile(r"^ignore:")],
        group_lines=[re.compile(r"^group:")],
        max_lines=10,
        trust_required=True,
    )

    output = "\n".join(
        [
            "start",
            "ignore: this",
            "group: 1",
            "group: 2",
            "group: 3",
            "group: 4",
            "group: 5",
            "group: 6",
            "group: 7",
            "end",
        ]
    )

    result = apply_filter(f, output)
    lines = result.splitlines()

    assert "ignore: this" not in lines
    assert "group: 1" in lines
    assert "group: 6" not in lines
    assert "... 2 more" in lines
    assert lines[-1] == "end"


def test_apply_filter_max_lines() -> None:
    f = TomlFilter(
        pattern=re.compile(r"mycmd"),
        drop_lines=[],
        group_lines=[],
        max_lines=3,
        trust_required=True,
    )

    output = "1\n2\n3\n4\n5\n"
    result = apply_filter(f, output)
    assert result == "1\n2\n3\n..."


def test_find_matching_filter(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    toml_content = """
    [[filters]]
    pattern = "^mycmd"
    drop_lines = ["^ignore:"]
    group_lines = ["^group:"]
    max_lines = 10
    trust_required = true
    """
    (tmp_path / ".ptk.toml").write_text(toml_content)

    monkeypatch.setattr(
        "ptk.core.trust_store.trust_file_path",
        lambda: tmp_path / ".ptk-trusted",
    )
    record_trust(tmp_path)

    f = find_matching_filter("mycmd --flag", start_dir=tmp_path)
    assert f is not None
    assert f.pattern.pattern == "^mycmd"
    assert len(f.drop_lines) == 1
    assert f.max_lines == 10
    assert f.trust_required is True

    f_none = find_matching_filter("othercmd", start_dir=tmp_path)
    assert f_none is None


def test_find_matching_filter_not_found(tmp_path: Path) -> None:
    f = find_matching_filter("mycmd", start_dir=tmp_path)
    assert f is None


def test_find_matching_filter_untrusted_not_returned(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    toml_content = """
    [[filters]]
    pattern = "^mycmd"
    drop_lines = []
    group_lines = []
    trust_required = true
    """
    (tmp_path / ".ptk.toml").write_text(toml_content)
    monkeypatch.setattr(
        "ptk.core.trust_store.trust_file_path",
        lambda: tmp_path / ".ptk-trusted-empty",
    )
    assert find_matching_filter("mycmd", start_dir=tmp_path) is None


def test_find_matching_filter_trust_not_required(tmp_path: Path) -> None:
    toml_content = """
    [[filters]]
    pattern = "^mycmd"
    drop_lines = []
    group_lines = []
    trust_required = false
    """
    (tmp_path / ".ptk.toml").write_text(toml_content)
    f = find_matching_filter("mycmd", start_dir=tmp_path)
    assert f is not None
