import re

from ptk.core.filter import FilterLevel, FilterStrategy


def test_filter_level_enum() -> None:
    assert FilterLevel.NONE == "none"
    assert FilterLevel.MINIMAL == "minimal"
    assert FilterLevel.AGGRESSIVE == "aggressive"


def test_deduplicate() -> None:
    assert FilterStrategy.deduplicate([]) == []
    assert FilterStrategy.deduplicate(["a"]) == ["a"]
    assert FilterStrategy.deduplicate(["a", "b", "c"]) == ["a", "b", "c"]
    assert FilterStrategy.deduplicate(["a", "a", "b", "c", "c", "c", "a"]) == ["a", "b", "c", "a"]


def test_truncate() -> None:
    assert FilterStrategy.truncate([]) == []
    assert FilterStrategy.truncate(["hello", "world"], max_len=10) == ["hello", "world"]

    long_line = "a" * 10
    assert FilterStrategy.truncate([long_line], max_len=5) == ["aaaaa..."]
    assert FilterStrategy.truncate(["short", long_line, "short"], max_len=5) == [
        "short",
        "aaaaa...",
        "short",
    ]


def test_group_by_pattern() -> None:
    pattern = re.compile(r"^error:")
    lines = [
        "info: starting",
        "error: file not found",
        "error: access denied",
        "error: timeout",
        "error: disk full",
        "error: memory limit",
        "error: network down",
        "error: db disconnected",
        "info: stopping",
    ]

    result = FilterStrategy.group_by_pattern(lines, pattern, max_per_group=3)

    assert result == [
        "info: starting",
        "error: file not found",
        "error: access denied",
        "error: timeout",
        "... 4 more",
        "info: stopping",
    ]

    # Test when the pattern matches the end of the file
    lines_end = lines[:-1]
    result_end = FilterStrategy.group_by_pattern(lines_end, pattern, max_per_group=3)
    assert result_end == [
        "info: starting",
        "error: file not found",
        "error: access denied",
        "error: timeout",
        "... 4 more",
    ]

    # Test when group is exactly max_per_group
    lines_exact = ["error: 1", "error: 2", "error: 3"]
    result_exact = FilterStrategy.group_by_pattern(lines_exact, pattern, max_per_group=3)
    assert result_exact == ["error: 1", "error: 2", "error: 3"]


def test_strip_ansi() -> None:
    assert FilterStrategy.strip_ansi("\x1b[31mError\x1b[0m") == "Error"
    assert FilterStrategy.strip_ansi("Normal text") == "Normal text"
    assert FilterStrategy.strip_ansi("\x1b[1;32mSuccess\x1b[0m!") == "Success!"


def test_filter_noise() -> None:
    patterns = [re.compile(r"^noise:"), re.compile(r"^debug:")]
    lines = [
        "info: 1",
        "noise: 1",
        "error: 1",
        "debug: 1",
        "warn: 1",
    ]

    result = FilterStrategy.filter_noise(lines, patterns)
    assert result == ["info: 1", "error: 1", "warn: 1"]
