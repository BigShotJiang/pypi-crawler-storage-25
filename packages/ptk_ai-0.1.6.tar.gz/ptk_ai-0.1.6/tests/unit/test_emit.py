import pytest

from ptk.core.emit import emit_filtered_output


def test_emit_filtered_without_verbose(capsys: pytest.CaptureFixture[str]) -> None:
    import ptk.cli as cli_mod

    cli_mod.verbose_flag = 0
    emit_filtered_output("RAW", "OUT")
    out = capsys.readouterr().out
    assert "RAW" not in out
    assert "OUT" in out


def test_emit_filtered_with_verbose(capsys: pytest.CaptureFixture[str]) -> None:
    import ptk.cli as cli_mod

    cli_mod.verbose_flag = 1
    emit_filtered_output("RAW", "OUT")
    out = capsys.readouterr().out
    assert "RAW" in out
    assert "filtered" in out
    assert "OUT" in out
