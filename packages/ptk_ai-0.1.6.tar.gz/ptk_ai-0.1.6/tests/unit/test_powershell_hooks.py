from __future__ import annotations

import re

import pytest

from ptk.hooks.powershell import (
    POWERSHELL_CANDIDATES,
    build_powershell_hook_command,
    find_powershell_executable,
)


def test_find_powershell_executable_prefers_existing(monkeypatch: pytest.MonkeyPatch) -> None:
    """It should return the first candidate whose executable exists."""
    calls: list[str] = []

    def fake_which(name: str) -> str | None:
        calls.append(name)
        return "pwsh" if name == "pwsh" else None

    monkeypatch.setattr("ptk.hooks.powershell.shutil.which", fake_which)
    assert find_powershell_executable() == "pwsh"
    assert calls[: len(POWERSHELL_CANDIDATES)] == POWERSHELL_CANDIDATES[: len(calls)]


def test_find_powershell_executable_falls_back_to_powershell(monkeypatch: pytest.MonkeyPatch) -> None:
    """If pwsh is missing but powershell exists, ports returns powershell."""
    def fake_which(name: str) -> str | None:
        if name == "pwsh":
            return None
        if name == "powershell":
            return "powershell.exe"
        return None

    monkeypatch.setattr("ptk.hooks.powershell.shutil.which", fake_which)
    assert find_powershell_executable() == "powershell"


def test_find_powershell_executable_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    """Return None when no candidate is on PATH."""
    monkeypatch.setattr("ptk.hooks.powershell.shutil.which", lambda _: None)
    assert find_powershell_executable(candidates=["faked"]) is None


def test_build_hook_command_includes_rewrite_snippet() -> None:
    """The hook should invoke `ptk rewrite` and honor the chosen shell."""
    cmd = build_powershell_hook_command(shell="pwsh.exe", command_env_var="PTK_CMD")
    assert "pwsh.exe" in cmd
    assert "$Env:PTK_CMD" in cmd
    assert re.search(r'ptk rewrite -- "\$cmd"', cmd)
    assert "Write-Output $rewritten" in cmd
    assert "Write-Output $cmd" in cmd
