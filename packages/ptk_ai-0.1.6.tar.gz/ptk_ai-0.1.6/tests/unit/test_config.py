from pathlib import Path

from ptk.core.config import Config


def test_config_defaults() -> None:
    config = Config()
    assert config.ultra_compact is False
    assert config.telemetry_enabled is True
    assert config.token_estimator == "heuristic"
    assert config.db_path is None
    assert config.trust_level == "ask"


def test_config_load_nonexistent(tmp_path: Path) -> None:
    config_path = tmp_path / "nonexistent.toml"
    config = Config.load(config_path)
    assert config.telemetry_enabled is True  # Should return defaults


def test_config_load_valid(tmp_path: Path) -> None:
    config_path = tmp_path / "config.toml"
    config_path.write_text(
        """
[general]
ultra_compact = true
token_estimator = "tiktoken"
trust_level = "auto"

[tracking]
database_path = "/custom/path.db"

[telemetry]
enabled = false
        """
    )

    config = Config.load(config_path)
    assert config.ultra_compact is True
    assert config.telemetry_enabled is False
    assert config.token_estimator == "tiktoken"
    assert config.db_path == "/custom/path.db"
    assert config.trust_level == "auto"


def test_config_load_partial(tmp_path: Path) -> None:
    config_path = tmp_path / "config.toml"
    config_path.write_text(
        """
[telemetry]
enabled = false
        """
    )

    config = Config.load(config_path)
    assert config.telemetry_enabled is False
    assert config.ultra_compact is False  # default


def test_config_load_invalid_toml(tmp_path: Path) -> None:
    config_path = tmp_path / "config.toml"
    config_path.write_text("invalid toml content = ]")

    config = Config.load(config_path)
    assert config.telemetry_enabled is True  # falls back to defaults
