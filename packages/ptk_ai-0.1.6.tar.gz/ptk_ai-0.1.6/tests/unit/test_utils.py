from unittest.mock import MagicMock, patch

from ptk.core.utils import (
    resolve_command,
    run_capturing,
    run_streaming,
    run_streaming_filter,
    shell_split,
    strip_ansi,
)


def test_strip_ansi() -> None:
    assert strip_ansi("\x1b[31mError\x1b[0m") == "Error"
    assert strip_ansi("Normal text") == "Normal text"
    assert strip_ansi("\x1b[1;32mSuccess\x1b[0m!") == "Success!"


def test_shell_split() -> None:
    assert shell_split("ls -l") == ["ls", "-l"]
    assert shell_split('git commit -m "my message"') == ["git", "commit", "-m", "my message"]
    assert shell_split("echo 'hello world'") == ["echo", "hello world"]


@patch("shutil.which")
def test_resolve_command_found(mock_which: MagicMock) -> None:
    mock_which.return_value = "/usr/bin/git"
    assert resolve_command("git") == "/usr/bin/git"
    mock_which.assert_called_once_with("git")


@patch("shutil.which")
@patch("sys.exit")
def test_resolve_command_not_found(mock_exit: MagicMock, mock_which: MagicMock) -> None:
    mock_which.return_value = None
    resolve_command("nonexistent_command")
    mock_exit.assert_called_once_with(127)


@patch("ptk.core.utils.subprocess.run")
@patch("ptk.core.utils.resolve_command")
def test_run_capturing(mock_resolve: MagicMock, mock_run: MagicMock) -> None:
    mock_resolve.return_value = "/bin/echo"
    mock_result = MagicMock()
    mock_result.stdout = "hello\n"
    mock_result.stderr = ""
    mock_result.returncode = 0
    mock_run.return_value = mock_result

    stdout, stderr, code = run_capturing(["echo", "hello"])

    assert stdout == "hello\n"
    assert stderr == ""
    assert code == 0
    mock_run.assert_called_once()
    assert mock_run.call_args[0][0] == ["/bin/echo", "hello"]
    assert mock_run.call_args[1]["text"] is True
    assert mock_run.call_args[1]["encoding"] == "utf-8"


def test_run_capturing_empty() -> None:
    stdout, stderr, code = run_capturing([])
    assert stdout == ""
    assert stderr == ""
    assert code == 0


@patch("ptk.core.utils.subprocess.run")
@patch("ptk.core.utils.resolve_command")
@patch("sys.exit")
def test_run_capturing_not_found(
    mock_exit: MagicMock, mock_resolve: MagicMock, mock_run: MagicMock
) -> None:
    mock_resolve.return_value = "/bin/nonexistent"
    mock_run.side_effect = FileNotFoundError()

    run_capturing(["nonexistent"])
    mock_exit.assert_called_once_with(127)


@patch("ptk.core.utils.subprocess.run")
@patch("ptk.core.utils.resolve_command")
def test_run_streaming(mock_resolve: MagicMock, mock_run: MagicMock) -> None:
    mock_resolve.return_value = "/bin/ls"
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_run.return_value = mock_result

    code = run_streaming(["ls", "-l"])

    assert code == 0
    mock_run.assert_called_once()
    assert mock_run.call_args[0][0] == ["/bin/ls", "-l"]
    assert "capture_output" not in mock_run.call_args[1]


def test_run_streaming_empty() -> None:
    assert run_streaming([]) == 0


@patch("ptk.core.utils.subprocess.run")
@patch("ptk.core.utils.resolve_command")
@patch("sys.exit")
def test_run_streaming_not_found(
    mock_exit: MagicMock, mock_resolve: MagicMock, mock_run: MagicMock
) -> None:
    mock_resolve.return_value = "/bin/nonexistent"
    mock_run.side_effect = FileNotFoundError()

    run_streaming(["nonexistent"])
    mock_exit.assert_called_once_with(127)


@patch("ptk.core.utils.subprocess.Popen")
@patch("ptk.core.utils.resolve_command")
def test_run_streaming_filter(mock_resolve: MagicMock, mock_popen: MagicMock) -> None:
    mock_resolve.return_value = "/bin/cat"
    mock_proc = MagicMock()
    mock_proc.stdout = ["line1\n", "line2\n"]
    mock_proc.returncode = 0
    mock_proc.__enter__.return_value = mock_proc
    mock_popen.return_value = mock_proc

    def dummy_filter(line: str) -> str:
        return line.upper()

    with patch("sys.stdout.write") as mock_write:
        code = run_streaming_filter(["cat", "file.txt"], dummy_filter)

    assert code == 0
    mock_write.assert_any_call("LINE1\n")
    mock_write.assert_any_call("LINE2\n")


def test_run_streaming_filter_empty() -> None:
    def dummy_filter(line: str) -> str:
        return line

    assert run_streaming_filter([], dummy_filter) == 0


@patch("ptk.core.utils.subprocess.Popen")
@patch("ptk.core.utils.resolve_command")
@patch("sys.exit")
def test_run_streaming_filter_not_found(
    mock_exit: MagicMock, mock_resolve: MagicMock, mock_popen: MagicMock
) -> None:
    mock_resolve.return_value = "/bin/nonexistent"
    mock_popen.side_effect = FileNotFoundError()

    def dummy_filter(line: str) -> str:
        return line

    run_streaming_filter(["nonexistent"], dummy_filter)
    mock_exit.assert_called_once_with(127)
