"""Tests for `ptk go` helpers."""

import json

from ptk.cmds.go_cmd import (
    _ensure_go_test_json,
    _filter_go_build,
    _filter_go_test_json,
)


def test_ensure_go_test_json_inserts_flag() -> None:
    assert _ensure_go_test_json(["test", "./..."]) == ["test", "-json", "./..."]


def test_ensure_go_test_json_idempotent() -> None:
    args = ["test", "-json", "./pkg"]
    assert _ensure_go_test_json(args) == args


def test_filter_go_test_json_keeps_failures() -> None:
    fail = {"Action": "fail", "Package": "p", "Test": "T"}
    pass_line = {"Action": "pass", "Package": "p", "Test": "T"}
    raw = json.dumps(fail) + "\n" + json.dumps(pass_line) + "\n"
    out = _filter_go_test_json(raw)
    assert '"Action": "fail"' in out
    assert '"Action": "pass"' not in out


def test_filter_go_build_keeps_errors() -> None:
    raw = "foo\n./x.go:3:9: undefined: y\n"
    out = _filter_go_build(raw)
    assert "undefined" in out
    assert "foo" not in out
