from typer.testing import CliRunner

from ptk import cli
from ptk.cli import app

runner = CliRunner()


def test_app_help() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Python Token Killer" in result.stdout


def test_app_no_args() -> None:
    result = runner.invoke(app)
    # Since no_args_is_help is True, Typer exits with code 2 and shows help or error
    # The behavior can vary by Typer version, so we check stdout/stderr for help message
    assert "Python Token Killer" in result.stdout or "Python Token Killer" in result.stderr


def test_app_flags() -> None:
    # Use a dummy command to test flags
    @app.command("dummy")
    def dummy() -> None:
        pass

    result = runner.invoke(app, ["-vv", "--ultra-compact", "dummy"])
    assert result.exit_code == 0
    assert cli.verbose_flag == 2
    assert cli.ultra_compact_flag is True
