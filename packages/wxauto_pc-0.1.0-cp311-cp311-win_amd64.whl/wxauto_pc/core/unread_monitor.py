"""未读监听公开封装。"""

from ._unread_monitor import UnreadMessageMonitor

__all__ = ["UnreadMessageMonitor"]
