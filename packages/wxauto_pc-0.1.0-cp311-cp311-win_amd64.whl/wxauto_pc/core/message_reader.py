"""消息读取公开封装。"""

from ._message_reader import MessageReader

__all__ = ["MessageReader"]
