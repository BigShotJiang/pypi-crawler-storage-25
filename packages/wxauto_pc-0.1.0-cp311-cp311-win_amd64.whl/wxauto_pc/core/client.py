"""微信客户端公开封装。"""

from ._client import WeChatClient

__all__ = ["WeChatClient"]
