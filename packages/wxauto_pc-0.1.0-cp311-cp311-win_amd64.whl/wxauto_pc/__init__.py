"""wxauto_pc 对外入口。"""

from .core.client import WeChatClient
from .core.message_reader import MessageReader
from .core.unread_monitor import UnreadMessageMonitor
from .tools.registry import list_tools

__version__ = "0.1.0"
__all__ = ["WeChatClient", "MessageReader", "UnreadMessageMonitor", "list_tools"]
