from __future__ import annotations

"""MindPack orchestration — MindPackOrchestrator lifecycle manager.

Orchestrates the full consultation lifecycle:
  1. Receive a consultation request (AskMindPackInput).
  2. Select and spawn expert agents via ExpertAgentFactory.
  3. Collect their reports into the ReportStore.
  4. Invoke the judge merger to produce a unified AskMindPackOutput.
  5. Clean up session state.

Data models live in ``schemas.py`` to avoid circular imports.
"""

import asyncio
import json
import logging
import uuid
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from code_puppy.plugins.mindpack.memory import ReportStore
from code_puppy.plugins.mindpack.schemas import MindPackExpertReport as ExpertReport
from code_puppy.plugins.mindpack.schemas import (
    AskMindPackInput,
    AskMindPackOutput,
    ExpertDescriptor,
    MindPackNestedConfig,
    MindPackRankedOption,
)

if TYPE_CHECKING:
    from code_puppy.plugins.mindpack.factory import ExpertAgentFactory
    from code_puppy.plugins.mindpack.tools import MindPackInvocationContext

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Expert selector (pluggable strategy)
# ---------------------------------------------------------------------------


class ExpertSelector(ABC):
    """Strategy for choosing which experts to consult given an input."""

    @abstractmethod
    def select(
        self, request: AskMindPackInput, registry: List[ExpertDescriptor]
    ) -> List[ExpertDescriptor]:
        """Return the subset of experts to consult for this request."""


class DefaultExpertSelector(ExpertSelector):
    """Simple selector: returns up to `max_experts` from the registry.

    For now this is a naive top-N slice. Smarter selection (semantic
    matching, relevance scoring) will come in a later epic.
    """

    def select(
        self, request: AskMindPackInput, registry: List[ExpertDescriptor]
    ) -> List[ExpertDescriptor]:
        cap = request.max_experts or len(registry)
        return registry[:cap]


# ---------------------------------------------------------------------------
# Judge merger (pluggable strategy)
# ---------------------------------------------------------------------------


class JudgeMerger(ABC):
    """Strategy for merging expert reports into a final advisory output.

    All implementations must provide the async ``merge`` method.  The
    ``session_id`` parameter allows mergers to log and emit events in the
    correct consultation context.
    """

    @abstractmethod
    async def merge(
        self,
        request: AskMindPackInput,
        reports: List[ExpertReport],
        session_id: str,
    ) -> AskMindPackOutput:
        """Produce a unified advisory from all expert reports."""


class PlaceholderJudgeMerger(JudgeMerger):
    """Minimal placeholder that echoes back a summary without real merging.

    Kept as an explicit opt-out for cases where the LLM judge should
    not be used (e.g. testing, offline mode).  The ``LLMJudgeMerger``
    is the default production implementation.
    """

    async def merge(
        self,
        request: AskMindPackInput,
        reports: List[ExpertReport],
        session_id: str,
    ) -> AskMindPackOutput:
        expert_names = [r.expert_id for r in reports]
        all_risks = [r for report in reports for r in report.risks]
        all_files = [f for report in reports for f in report.files_to_inspect]
        all_recs = [r for report in reports for r in report.proposed_plan]

        return AskMindPackOutput(
            summary=(
                f"Placeholder merger: consulted {len(reports)} expert(s) "
                f"for '{request.desired_output}' on: "
                f"{request.problem_statement[:200]}"
            ),
            recommended_plan="\n".join(all_recs) or "No recommendations produced.",
            ranked_options=[
                MindPackRankedOption(
                    rank=1,
                    title="Placeholder option",
                    source_experts=expert_names,
                    summary="Placeholder merged option — LLM judge not active.",
                )
            ],
            risks=all_risks or ["Placeholder: no risks identified."],
            tests_to_run=[],
            files_to_inspect_or_change=list(dict.fromkeys(all_files)),
            expert_consensus=(f"Placeholder: {len(reports)} expert(s) consulted."),
            disagreements=[],
            confidence=sum(r.confidence for r in reports) / max(len(reports), 1),
        )


# ---------------------------------------------------------------------------
# MindPackOrchestrator
# ---------------------------------------------------------------------------


class MindPackOrchestrator:
    """Manages the lifecycle of a MindPack consultation.

    Typical usage::

        orchestrator = MindPackOrchestrator()
        result = await orchestrator.consult(request)
    """

    def __init__(
        self,
        report_store: Optional[ReportStore] = None,
        expert_selector: Optional[ExpertSelector] = None,
        judge_merger: Optional[JudgeMerger] = None,
        expert_factory: Optional[ExpertAgentFactory] = None,
    ) -> None:
        self._store = report_store or ReportStore()
        self._selector = expert_selector or DefaultExpertSelector()
        if judge_merger is not None:
            self._merger = judge_merger
        else:
            from code_puppy.plugins.mindpack.judge import LLMJudgeMerger

            self._merger = LLMJudgeMerger()
        if expert_factory is not None:
            self._factory = expert_factory
        else:
            from code_puppy.plugins.mindpack.factory import ExpertAgentFactory

            self._factory = ExpertAgentFactory()
        self._expert_registry: List[ExpertDescriptor] = []

    # -- registry -----------------------------------------------------------

    @staticmethod
    def _get_experts_config_path() -> Path:
        """Return the path to the experts config file."""
        config_dir = Path.home() / ".code_puppy" / "mindpack"
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir / "experts.json"

    def save_experts(self) -> None:
        """Persist current expert registry to disk."""
        config_path = self._get_experts_config_path()
        data = [e.model_dump() for e in self._expert_registry]
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.info("Orchestrator: saved %d experts to %s", len(data), config_path)

    def load_experts(self) -> None:
        """Load custom experts from disk, merging with defaults.

        Preserves experts that were registered before this call
        (i.e., the default experts from tools.py).  Custom experts
        from the config file are added, and any experts with the
        same name are replaced.
        """
        config_path = self._get_experts_config_path()
        if not config_path.exists():
            logger.debug("Orchestrator: no custom experts config found")
            return

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Remove any existing experts that will be replaced
            custom_experts = [ExpertDescriptor(**d) for d in data]
            names_to_replace = {e.name for e in custom_experts}
            self._expert_registry = [
                e for e in self._expert_registry if e.name not in names_to_replace
            ]

            # Add custom experts
            self._expert_registry.extend(custom_experts)
            logger.info(
                "Orchestrator: loaded %d custom expert(s) from %s",
                len(custom_experts),
                config_path,
            )
        except Exception as exc:
            logger.error("Orchestrator: failed to load experts config: %s", exc)

    def register_expert(self, expert: ExpertDescriptor) -> None:
        """Add an expert to the available pool."""
        self._expert_registry.append(expert)
        logger.debug("Orchestrator: registered expert '%s'", expert.name)

    def register_experts(self, experts: List[ExpertDescriptor]) -> None:
        """Bulk-register a list of experts."""
        for e in experts:
            self.register_expert(e)

    def remove_expert(self, name: str) -> bool:
        """Remove an expert from the registry by name.

        Returns:
            True if an expert was removed, False if not found.
        """
        original_len = len(self._expert_registry)
        self._expert_registry = [e for e in self._expert_registry if e.name != name]
        removed = len(self._expert_registry) < original_len
        if removed:
            logger.debug("Orchestrator: removed expert '%s'", name)
        return removed

    @property
    def expert_registry(self) -> List[ExpertDescriptor]:
        """Read-only view of the current expert pool."""
        return list(self._expert_registry)

    # -- consultation lifecycle ---------------------------------------------

    async def consult(
        self,
        request: AskMindPackInput,
        invocation_context: Optional["MindPackInvocationContext"] = None,
        nested_config: Optional[MindPackNestedConfig] = None,
    ) -> AskMindPackOutput:
        """Run a full consultation cycle.

        1. Generate a session ID.
        2. Select experts from the registry.
        3. Spawn experts and collect reports.
        4. Run the judge merger.
        5. Clean up session data.

        Args:
            request: The consultation input.
            invocation_context: Nested-workflow tracking (depth, call counts).
            nested_config: INI-driven nested limits (timeout, max_depth).

        Returns the merged advisory output.
        """
        session_id = uuid.uuid4().hex[:12]
        if invocation_context is not None:
            logger.info(
                "Orchestrator: nested consultation depth=%d/%d session='%s'",
                invocation_context.nested_depth,
                invocation_context.max_depth,
                session_id,
            )
        logger.info(
            "Orchestrator: starting consultation session='%s' "
            "desired_output='%s' problem='%s'",
            session_id,
            request.desired_output,
            request.problem_statement[:120],
        )

        # Select experts
        selected = self._selector.select(request, self._expert_registry)
        logger.info(
            "Orchestrator: selected %d expert(s) for session '%s': %s",
            len(selected),
            session_id,
            [e.name for e in selected],
        )

        # Spawn experts and collect reports (with optional timeout cap)
        timeout = None
        if nested_config is not None:
            timeout = nested_config.timeout_sec

        try:
            if timeout:
                reports = await asyncio.wait_for(
                    self._spawn_and_collect(session_id, request, selected),
                    timeout=timeout,
                )
            else:
                reports = await self._spawn_and_collect(session_id, request, selected)
        except asyncio.TimeoutError:
            logger.error(
                "Orchestrator: consultation session='%s' exceeded timeout (%ss)",
                session_id,
                timeout,
            )
            # Return a graceful timeout advisory instead of crashing
            return AskMindPackOutput(
                summary=f"MindPack consultation timed out after {timeout}s.",
                recommended_plan=(
                    "The expert panel did not finish in time. "
                    "Consider simplifying the problem statement or increasing "
                    "packmind_nested_timeout_sec in your config."
                ),
                ranked_options=[],
                risks=[f"Timeout: expert pool exceeded {timeout}s limit"],
                tests_to_run=[],
                files_to_inspect_or_change=[],
                expert_consensus="No consensus — consultation aborted by timeout.",
                disagreements=[],
                confidence=0.0,
            )

        # Merge via judge (async — LLM-backed or placeholder)
        output = await self._merger.merge(request, reports, session_id)

        # Clean up session memory
        self._store.clear_run(session_id)

        logger.info(
            "Orchestrator: consultation complete session='%s' "
            "experts=%d confidence=%.2f",
            session_id,
            len(reports),
            output.confidence,
        )
        return output

    # -- expert spawning (skeleton) -----------------------------------------

    async def _spawn_and_collect(
        self,
        session_id: str,
        request: AskMindPackInput,
        experts: List[ExpertDescriptor],
    ) -> List[ExpertReport]:
        """Spawn each expert agent and collect their reports in parallel.

        Uses the Factory to prepare and run experts concurrently via asyncio.gather.
        """
        if hasattr(self._factory, "invoke_expert"):
            # If the factory doesn't support batching directly, use gather
            tasks = [
                self._invoke_expert(session_id, request, expert) for expert in experts
            ]
            results = await asyncio.gather(*tasks)
            reports = [r for r in results if r is not None]
            for report in reports:
                self._store.add_report(report)
            return reports
        
        # Fallback to serial for safe implementation if batch API changes
        return await self._spawn_and_collect_serial(session_id, request, experts)

    async def _spawn_and_collect_serial(
        self,
        session_id: str,
        request: AskMindPackInput,
        experts: List[ExpertDescriptor],
    ) -> List[ExpertReport]:
        """Serial fallback for expert invocation."""
        reports: List[ExpertReport] = []
        for expert in experts:
            report = await self._invoke_expert(session_id, request, expert)
            if report is not None:
                self._store.add_report(report)
                reports.append(report)
        return reports

    async def _invoke_expert(
        self,
        session_id: str,
        request: AskMindPackInput,
        expert: ExpertDescriptor,
    ) -> Optional[ExpertReport]:
        """Invoke a single expert via the ExpertAgentFactory.

        The factory creates a read-only sub-agent with the expert's
        system prompt fragment, runs it against the consultation prompt,
        and returns a structured ``ExpertReport``.

        Falls back to a minimal error report if the factory fails entirely.
        """
        logger.info(
            "Orchestrator: invoking expert '%s' for session '%s'",
            expert.name,
            session_id,
        )

        try:
            report = await self._factory.invoke_expert(expert, request, session_id)
        except Exception as exc:
            logger.error(
                "Orchestrator: expert '%s' raised unexpected error: %s",
                expert.name,
                exc,
                exc_info=True,
            )
            report = ExpertReport(
                expert_id=expert.name,
                run_id=session_id,
                lens="error",
                prompt_variant="fallback",
                summary=f"[Error] Unexpected failure: {exc}",
                findings=[],
                proposed_plan=[],
                risks=[f"Expert invocation raised: {exc}"],
                files_to_inspect=[],
                confidence=0.0,
                status="failed",
            )

        return report

    # -- cleanup ------------------------------------------------------------

    async def shutdown(self) -> None:
        """Graceful shutdown — clear all session data."""
        self._store.clear_all()
        logger.info("Orchestrator: shutdown complete")
