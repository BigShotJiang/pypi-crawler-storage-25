"""Expert agent factory — creates read-only sub-agents from ExpertDescriptors.

Follows the same sub-agent construction pattern as
``code_puppy.tools.agent_tools.register_invoke_agent`` but with two key
constraints:

1. **Read-only tool set** — experts can inspect code but never mutate it.
2. **Structured output** — experts return ``ExpertReport`` models, not free
   text, so the judge merger receives machine-parseable data.

The factory is deliberately stateless: it builds an agent per call and
tears it down afterwards.  No session history is persisted to disk because
expert consultations are ephemeral — they exist only for the duration of a
single ``MindPackOrchestrator.consult()`` call.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from contextlib import AsyncExitStack
from functools import partial
from typing import Any, List, Optional, get_args

from pydantic_ai import Agent as PydanticAgent, UsageLimits

from code_puppy.plugins.mindpack.schemas import MindPackExpertReport as ExpertReport
from code_puppy.plugins.mindpack.schemas import (
    AskMindPackInput,
    ExpertDescriptor,
    ExpertSpawnMode,
    MindPackExpertPoolConfig,
)
from code_puppy.tools.subagent_context import subagent_context

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# INI config helpers
# ---------------------------------------------------------------------------


def _get_config_str(key: str, default: str) -> str:
    from code_puppy.config import get_value

    return get_value(key) or default


def _get_config_int(key: str, default: int) -> int:
    from code_puppy.config import get_value

    val = get_value(key)
    if val is None:
        return default
    try:
        return int(val)
    except (ValueError, TypeError):
        logger.warning("Invalid integer config '%s=%s'; using default %s", key, val, default)
        return default


def _get_config_bool(key: str, default: bool) -> bool:
    from code_puppy.config import get_value

    val = get_value(key)
    if val is None:
        return default
    return str(val).lower() in ("1", "true", "yes", "on")


def load_pool_config_from_ini(
    overrides: Optional[MindPackExpertPoolConfig] = None,
) -> MindPackExpertPoolConfig:
    """Build a ``MindPackExpertPoolConfig`` from INI settings.

    Reads ``packmind_expert_spawn_mode``, ``packmind_expert_count``,
    ``packmind_min_experts``, ``packmind_max_experts``, and
    ``packmind_model_strategy`` from the Code Puppy INI config.

    Any caller-supplied ``overrides`` take precedence over INI values.
    """
    spawn_mode_raw = _get_config_str("packmind_expert_spawn_mode", "fixed")
    valid_modes = set(get_args(ExpertSpawnMode))
    if spawn_mode_raw not in valid_modes:
        logger.warning(
            "Invalid packmind_expert_spawn_mode '%s'; falling back to 'fixed'",
            spawn_mode_raw,
        )
        spawn_mode_raw = "fixed"

    config = MindPackExpertPoolConfig(
        spawn_mode=spawn_mode_raw,  # type: ignore[arg-type]
        default_expert_count=_get_config_int("packmind_expert_count", 5),
        min_experts=_get_config_int("packmind_min_experts", 3),
        max_experts=_get_config_int("packmind_max_experts", 7),
        model_strategy=_get_config_str("packmind_model_strategy", "same_model"),  # type: ignore[arg-type]
    )

    if overrides is not None:
        # Apply caller overrides field-by-field
        for field_name in MindPackExpertPoolConfig.model_fields:
            override_val = getattr(overrides, field_name, None)
            if override_val is not None:
                setattr(config, field_name, override_val)

    return config

# ---------------------------------------------------------------------------
# Read-only tool allow-list
# ---------------------------------------------------------------------------

READ_ONLY_TOOLS: List[str] = [
    "list_files",
    "read_file",
    "grep",
    "load_image_for_analysis",
    "list_or_search_skills",
]
"""Tools that an expert agent may use.  All write-capable tools (create_file,
replace_in_file, delete_snippet, delete_file, agent_run_shell_command,
ask_user_question, invoke_agent, list_agents, browser_*, activate_skill,
universal_constructor) are deliberately excluded."""

# ---------------------------------------------------------------------------
# Expert system prompt template
# ---------------------------------------------------------------------------

_EXPERT_SYSTEM_PROMPT_TEMPLATE = """\
You are {expert_name}, a specialist in {speciality}.

{system_prompt_fragment}

## CRITICAL CONSTRAINTS

You are operating in **read-only advisory mode**. You must NEVER:

- Create, modify, or delete any files
- Run shell commands
- Invoke other agents or sub-agents
- Ask the user questions
- Navigate websites or use browser tools

You MAY:
- List and read files
- Search code with grep
- Load images for analysis

Your task is to analyse the problem, explore the relevant code, and produce
a structured report with your findings, recommendations, identified risks,
and confidence level.

## OUTPUT FORMAT

You MUST produce your response as a structured report containing:
- **summary**: Your detailed analysis of the problem
- **findings**: Key findings and observations
- **proposed_plan**: A list of specific, actionable recommendations
- **risks**: A list of risks, edge cases, or failure modes you identified
- **files_to_inspect**: Files you recommend the executor inspect or change
- **tests_to_run**: Tests you recommend running
- **confidence**: Your confidence in your analysis (0.0 to 1.0)
- **assumptions**: Any assumptions you made
"""

# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------


def build_expert_prompt(
    expert: ExpertDescriptor,
    request: AskMindPackInput,
) -> str:
    """Compose the user-facing prompt for an expert consultation.

    The prompt carries the full problem context so the expert can work
    autonomously with only read-only tools.
    """
    parts: list[str] = []

    parts.append(f"## Problem Statement\n{request.problem_statement}")

    parts.append(f"## Current Goal\n{request.current_goal}")

    if request.current_plan:
        parts.append(f"## Current Plan\n{request.current_plan}")

    if request.what_has_been_tried:
        parts.append(
            "## What Has Been Tried\n"
            + "\n".join(f"- {item}" for item in request.what_has_been_tried)
        )

    if request.relevant_files:
        parts.append(
            "## Relevant Files\n" + "\n".join(f"- {f}" for f in request.relevant_files)
        )

    if request.observed_errors:
        parts.append(
            "## Observed Errors\n"
            + "\n".join(f"- {e}" for e in request.observed_errors)
        )

    if request.uncertainty:
        parts.append(f"## Uncertainty\n{request.uncertainty}")

    parts.append(f"## Desired Output Type\n{request.desired_output}")

    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# ExpertAgentFactory
# ---------------------------------------------------------------------------


class ExpertAgentFactory:
    """Creates and runs read-only expert sub-agents.

    Usage::

        factory = ExpertAgentFactory()
        report = await factory.invoke_expert(descriptor, request, session_id)
    """

    def __init__(self) -> None:
        self._concurrency_limit = _get_config_int("packmind_concurrency_limit", 5)
        self._semaphore = asyncio.Semaphore(self._concurrency_limit)
        logger.debug(
            "ExpertAgentFactory: concurrency limit set to %d",
            self._concurrency_limit,
        )

    def create_expert_agent(
        self,
        expert: ExpertDescriptor,
        *,
        session_id: str,
        message_group: Optional[str] = None,
        model_override: Optional[str] = None,
    ) -> PydanticAgent:
        """Build a pydantic-ai agent for the given expert descriptor.

        The agent is configured with:
        - The expert's system prompt (identity + fragment + constraints)
        - Read-only tools only
        - ``ExpertReport`` as the structured output type

        This is a **temporary agent** — it is not registered in the agent
        manager and does not persist across calls.
        """
        from code_puppy.agents._builder import load_puppy_rules
        from code_puppy.model_factory import ModelFactory, make_model_settings
        from code_puppy.model_utils import prepare_prompt_for_model

        # Resolve model
        model_name = model_override or self._resolve_model_name(expert)
        models_config = ModelFactory.load_config()

        if model_name not in models_config:
            raise ValueError(
                f"Model '{model_name}' not found in configuration — "
                "cannot create expert agent"
            )

        model = ModelFactory.get_model(model_name, models_config)

        # Build instructions
        instructions = _EXPERT_SYSTEM_PROMPT_TEMPLATE.format(
            expert_name=expert.name,
            speciality=expert.speciality,
            system_prompt_fragment=expert.system_prompt_fragment,
        )

        # Append AGENTS.md rules if available
        puppy_rules = load_puppy_rules()
        if puppy_rules:
            instructions += f"\n\n{puppy_rules}"

        # Append plugin prompt additions
        from code_puppy import callbacks

        prompt_additions = callbacks.on_load_prompt()
        if prompt_additions:
            instructions += "\n" + "\n".join(prompt_additions)

        # Prepare for model (handles claude-code prepending etc.)
        prepared = prepare_prompt_for_model(
            model_name,
            instructions,
            "",  # user prompt is empty at build time
            prepend_system_to_user=False,
        )
        instructions = prepared.instructions

        model_settings = make_model_settings(model_name)

        # Build the pydantic-ai agent with ExpertReport output type
        temp_agent = PydanticAgent(
            model=model,
            instructions=instructions,
            output_type=ExpertReport,
            retries=2,
            # Explicitly restrict tools via registration later,
            # but ensure this agent has NO access to agent/browser control.
            toolsets=[],
            history_processors=[],
            model_settings=model_settings,
        )

        # Register read-only tools
        from code_puppy.tools import register_tools_for_agent

        tools = list(READ_ONLY_TOOLS)
        register_tools_for_agent(temp_agent, tools, model_name=model_name)

        logger.debug(
            "ExpertAgentFactory: created agent for '%s' with tools=%s session=%s",
            expert.name,
            tools,
            session_id,
        )
        return temp_agent

    async def build_expert_pool(
        self,
        experts: List[ExpertDescriptor],
        request: AskMindPackInput,
        pool_config: MindPackExpertPoolConfig,
        session_id: str,
    ) -> List[tuple[ExpertDescriptor, PydanticAgent]]:
        """Spawns an asynchronous expert pool based on the configured mode."""
        spawn_mode = pool_config.spawn_mode

        if spawn_mode == "fixed":
            logger.info(
                "Spawning fixed pool with default_expert_count=%d",
                pool_config.default_expert_count,
            )
            return await self._build_pool_fixed(experts, request, pool_config, session_id)

        if spawn_mode == "adaptive":
            logger.info(
                "Adaptive mode: initial spawn using min_experts=%d",
                pool_config.min_experts,
            )
            return await self._build_pool_fixed(
                experts, request, pool_config, session_id, count=pool_config.min_experts
            )

        if spawn_mode in ("multi_agent", "hybrid"):
            logger.info(
                "%s mode behaves like fixed pool with default_expert_count=%d",
                spawn_mode,
                pool_config.default_expert_count,
            )
            return await self._build_pool_fixed(experts, request, pool_config, session_id)

        if spawn_mode == "same_agent_replicas":
            logger.info(
                "Same-agent replicas mode: falling back to fixed pool with default_expert_count=%d",
                pool_config.default_expert_count,
            )
            return await self._build_pool_fixed(experts, request, pool_config, session_id)

        if spawn_mode == "multi_model_replicas":
            logger.info(
                "Multi-model replicas mode: falling back to fixed pool with default_expert_count=%d",
                pool_config.default_expert_count,
            )
            return await self._build_pool_fixed(experts, request, pool_config, session_id)

        logger.warning(
            "Unknown spawn mode '%s'; falling back to fixed pool with default_expert_count=%d",
            spawn_mode,
            pool_config.default_expert_count,
        )
        return await self._build_pool_fixed(experts, request, pool_config, session_id)

    async def _build_pool_fixed(
        self,
        experts: List[ExpertDescriptor],
        request: AskMindPackInput,
        pool_config: MindPackExpertPoolConfig,
        session_id: str,
        count: Optional[int] = None,
    ) -> List[tuple[ExpertDescriptor, PydanticAgent]]:
        """Fixed-mode pool builder: spawn up to *count* agents from *experts*."""
        target_count = count if count is not None else pool_config.default_expert_count
        selected = experts[:target_count]
        if len(selected) < target_count:
            logger.warning(
                "Requested %d experts but registry only has %d; using all available",
                target_count,
                len(selected),
            )

        pool: List[tuple[ExpertDescriptor, PydanticAgent]] = []
        global_model = self._resolve_model_name(selected[0]) if selected else None

        for expert in selected:
            model_to_use = global_model
            if pool_config.model_strategy == "per_expert" and expert.model:
                model_to_use = expert.model
            elif pool_config.model_strategy == "model_pool":
                # TODO(Epic 3): Rotate through model_pool entries
                model_to_use = expert.model or global_model

            agent = self.create_expert_agent(
                expert,
                session_id=session_id,
                model_override=model_to_use,
            )
            pool.append((expert, agent))

        return pool

    async def invoke_expert(
        self,
        expert: ExpertDescriptor,
        request: AskMindPackInput,
        session_id: str,
    ) -> Optional[ExpertReport]:
        """Run an expert agent and return its structured report.

        Returns ``None`` if the agent fails to produce a valid report.
        """
        group_id = f"mindpack-{expert.name}-{uuid.uuid4().hex[:6]}"

        try:
            temp_agent = self.create_expert_agent(
                expert, session_id=session_id, message_group=group_id
            )
        except ValueError as exc:
            logger.error(
                "ExpertAgentFactory: failed to create agent for '%s': %s",
                expert.name,
                exc,
            )
            return None

        user_prompt = build_expert_prompt(expert, request)

        return await self._run_expert(
            temp_agent=temp_agent,
            expert=expert,
            user_prompt=user_prompt,
            session_id=session_id,
            group_id=group_id,
        )

    # -- internal -----------------------------------------------------------

    @staticmethod
    def _resolve_model_name(expert: ExpertDescriptor) -> str:
        """Resolve the model name to use for expert agents.

        If the expert descriptor specifies a per-expert model override,
        use that.  Otherwise fall back to the global model name.
        """
        if expert.model:
            return expert.model

        from code_puppy.config import get_global_model_name

        name = get_global_model_name()
        if not name:
            raise ValueError("No global model configured — cannot create expert agent")
        return name

    async def _run_expert(
        self,
        temp_agent: PydanticAgent,
        expert: ExpertDescriptor,
        user_prompt: str,
        session_id: str,
        group_id: str,
    ) -> Optional[ExpertReport]:
        """Execute the expert agent in a subagent context.

        Handles streaming, cancellation, and error recovery.  Falls back
        to a text-parsed report if structured output fails.
        """
        from code_puppy.agents.subagent_stream_handler import (
            subagent_stream_handler,
        )
        from code_puppy.callbacks import on_agent_run_cancel, on_agent_run_context
        from code_puppy.config import get_message_limit
        from code_puppy.messaging import (
            SubAgentInvocationMessage,
            SubAgentResponseMessage,
            emit_success,
            get_message_bus,
        )

        bus = get_message_bus()

        # Emit invocation message for the console
        bus.emit(
            SubAgentInvocationMessage(
                agent_name=f"mindpack-{expert.name}",
                session_id=session_id,
                prompt=user_prompt[:200],
                is_new_session=True,
                message_count=0,
            )
        )

        stream_handler = partial(subagent_stream_handler, session_id=session_id)

        async with self._semaphore:
            with subagent_context(f"mindpack-{expert.name}"):
                run_ctxs = on_agent_run_context(
                    # Provide a minimal agent-like object for the hook
                    _MinimalAgentProxy(expert.name),
                    temp_agent,
                    group_id,
                )

                task = None
                try:
                    async with AsyncExitStack() as stack:
                        for cm in run_ctxs:
                            await stack.enter_async_context(cm)

                        task = asyncio.create_task(
                            temp_agent.run(
                                user_prompt,
                                message_history=[],
                                usage_limits=UsageLimits(request_limit=get_message_limit()),
                                event_stream_handler=stream_handler,
                            )
                        )

                        result = await task

                except asyncio.CancelledError:
                    if task and not task.done():
                        task.cancel()
                    await on_agent_run_cancel(group_id)
                    logger.warning("ExpertAgentFactory: expert '%s' cancelled", expert.name)
                    return None

                except Exception as exc:
                    logger.error(
                        "ExpertAgentFactory: expert '%s' failed: %s",
                        expert.name,
                        exc,
                        exc_info=True,
                    )
                    return self._fallback_report(expert, session_id, str(exc))

        # Extract structured output
        report = self._extract_report(result, expert, session_id)

        # Emit completion message
        bus.emit(
            SubAgentResponseMessage(
                agent_name=f"mindpack-{expert.name}",
                session_id=session_id,
                response=report.summary[:200] if report else "",
                message_count=0,
            )
        )

        emit_success(
            f"✓ mindpack-{expert.name} completed",
            message_group=group_id,
        )

        return report

    @staticmethod
    def _extract_report(
        result: Any,
        expert: ExpertDescriptor,
        session_id: str,
    ) -> Optional[ExpertReport]:
        """Extract an ExpertReport from the pydantic-ai result.

        Tries structured output first (``result.output``), then falls
        back to best-effort text parsing.
        """
        # Structured output path
        if result is not None and hasattr(result, "output"):
            output = result.output
            if isinstance(output, ExpertReport):
                # Ensure run_id is set correctly
                if output.run_id != session_id:
                    output = output.model_copy(update={"run_id": session_id})
                if output.expert_id != expert.name:
                    output = output.model_copy(update={"expert_id": expert.name})
                return output

            # If output is a dict, try to build ExpertReport from it
            if isinstance(output, dict):
                try:
                    report = ExpertReport(
                        expert_id=expert.name,
                        run_id=session_id,
                        **{
                            k: v
                            for k, v in output.items()
                            if k in ExpertReport.model_fields
                        },
                    )
                    return report
                except Exception:
                    pass

        # Text fallback — try to parse the raw output as text
        raw_text = ""
        if result is not None:
            if hasattr(result, "output"):
                raw_text = str(result.output)
            elif hasattr(result, "data"):
                raw_text = str(result.data)
            else:
                raw_text = str(result)

        if raw_text:
            return ExpertReport(
                expert_id=expert.name,
                run_id=session_id,
                lens="unknown",
                prompt_variant="fallback",
                summary=raw_text,
                findings=[],
                proposed_plan=[],
                risks=["Fallback: structured output not produced"],
                files_to_inspect=[],
                confidence=0.3,
                status="partial",
            )

        return None

    @staticmethod
    def _fallback_report(
        expert: ExpertDescriptor,
        session_id: str,
        error_msg: str,
    ) -> ExpertReport:
        """Build a minimal error report when the expert fails entirely."""
        return ExpertReport(
            expert_id=expert.name,
            run_id=session_id,
            lens="error",
            prompt_variant="fallback",
            summary=f"[Error] Expert '{expert.name}' failed: {error_msg}",
            findings=[],
            proposed_plan=[],
            risks=[f"Expert invocation failed: {error_msg}"],
            files_to_inspect=[],
            confidence=0.0,
            status="failed",
        )


# ---------------------------------------------------------------------------
# Minimal agent-like proxy for callback hooks
# ---------------------------------------------------------------------------


class _MinimalAgentProxy:
    """Lightweight object that satisfies the attribute requirements of
    ``on_agent_run_context`` and related hooks without needing a full
    ``BaseAgent`` instance.

    Expert agents are ephemeral — they don't have a real BaseAgent backing
    them, but some callback hooks expect an object with ``name`` and
    ``get_model_name()``.
    """

    def __init__(self, expert_name: str) -> None:
        self.name = f"mindpack-{expert_name}"
        self._model_name: Optional[str] = None

    def get_model_name(self) -> str:
        if self._model_name is None:
            from code_puppy.config import get_global_model_name

            self._model_name = get_global_model_name() or "unknown"
        return self._model_name
