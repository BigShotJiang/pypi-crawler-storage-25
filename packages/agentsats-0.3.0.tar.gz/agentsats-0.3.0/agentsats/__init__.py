"""
AgentSats Python SDK
Tokenized AI compute and identity — powered by Teranodex
pip install agentsats
"""
import hashlib, time, requests
from typing import Optional

class AgentSatsClient:
    def __init__(self, api_key: str = None, base_url: str = "https://api.spark-bsv.uk"):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.address = None
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})

    def _get(self, path, params=None):
        r = self._session.get(f"{self.base_url}{path}", params=params, timeout=30)
        r.raise_for_status()
        return r.json()

    def _post(self, path, data=None):
        r = self._session.post(f"{self.base_url}{path}", json=data, timeout=60)
        r.raise_for_status()
        return r.json()

    def _sha256(self, s: str) -> str:
        return hashlib.sha256(s.encode()).hexdigest()

    def _solve_pow(self, challenge: str, address: str, difficulty: int = 16) -> int:
        target = 2 ** (256 - difficulty)
        nonce = 0
        while True:
            h = int(self._sha256(challenge + address + str(nonce)), 16)
            if h < target:
                return nonce
            nonce += 1

    def register(self, address: str = None, label: str = "agent") -> dict:
        """Register on Teranodex. Handles PoW automatically."""
        if address is None:
            import secrets
            privkey = secrets.token_hex(32)
            address = "1" + self._sha256(privkey)[:25]
        self.address = address

        # Get challenge
        cd = self._get("/register/challenge", {"bsv_address": address})
        challenge = cd["challenge"]
        difficulty = cd.get("difficulty", 16)

        # Solve PoW
        print(f"[AgentSats] Solving PoW (difficulty {difficulty})...")
        nonce = self._solve_pow(challenge, address, difficulty)

        # Wait minimum solve time
        time.sleep(2.1)

        # Register
        result = self._post("/register", {
            "bsv_address": address,
            "challenge": challenge,
            "nonce": str(nonce),
            "label": label
        })
        if "api_key" in result:
            self.api_key = result["api_key"]
            print(f"[AgentSats] Registered. API key: {self.api_key}")
        return result

    def notarize(self, hash: str = None, content: str = None, file_path: str = None) -> dict:
        """Record a hash on Teranodex blockchain. Pass hash, content string, or file path."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")

        if hash is None:
            if content:
                hash = self._sha256(content)
            elif file_path:
                with open(file_path, "rb") as f:
                    import hashlib
                    hash = hashlib.sha256(f.read()).hexdigest()
            else:
                raise ValueError("Pass hash, content, or file_path")

        return self._post("/notarize", {
            "bsv_address": self.address,
            "hash": hash,
            "api_key": self.api_key
        })

    def verify(self, hash: str) -> dict:
        """Check if a hash is recorded on Teranodex blockchain."""
        return self._get("/notarize/status", {"hash": hash})

    def reputation(self, address: str = None) -> dict:
        """Get reputation score for an address."""
        addr = address or self.address
        if not addr:
            raise ValueError("No address provided")
        return self._get(f"/reputation/{addr}")

    def infer(self, prompt: str, model: str = "llama3-8b", max_tokens: int = 256) -> str:
        """Run GPU inference on AgentSats node."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        result = self._post("/tool_call", {
            "name": "agentsats_submit_job",
            "arguments": {
                "api_key": self.api_key,
                "model": model,
                "prompt": prompt,
                "max_tokens": max_tokens
            }
        })
        try:
            import json
            return json.loads(result["content"][0]["content"])["output"]
        except:
            return str(result)

    def balance(self) -> dict:
        """Get current credit balance."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        return self._post("/tool_call", {
            "name": "agentsats_check_balance",
            "arguments": {"api_key": self.api_key}
        })

    def fetch_and_notarize(self, url: str) -> dict:
        """Fetch a URL, hash it, and record on Teranodex in one call."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        # Fetch and hash
        fh = self._post("/fetch_and_hash", {"url": url})
        hash = fh["hash"]
        # Notarize
        result = self.notarize(hash=hash)
        result["hash"] = hash
        result["url"] = url
        result["verify_url"] = f"https://api.spark-bsv.uk/v/{hash}"
        return result


    def registry_list(self, capability: str, description: str, price_per_call: int = 1,
                      price_unit: str = "credits", endpoint: str = "",
                      models: str = "", tags: str = "") -> dict:
        """List a service in the AgentSats registry."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        return self._post("/registry/list", {
            "api_key": self.api_key,
            "capability": capability,
            "description": description,
            "price_per_call": price_per_call,
            "price_unit": price_unit,
            "endpoint": endpoint,
            "models": models,
            "tags": tags
        })

    def registry_browse(self) -> dict:
        """Browse all services in the AgentSats registry."""
        return self._get("/registry")

    def registry_search(self, capability: str = "", tag: str = "") -> dict:
        """Search registry by capability or tag."""
        return self._get("/registry/search", {"capability": capability, "tag": tag})

    def registry_delist(self, capability: str) -> dict:
        """Remove a service from the registry."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        return self._post("/registry/delist", {
            "api_key": self.api_key,
            "capability": capability
        })

    def escrow_create(self, seller_address: str, amount_credits: int, description: str = "") -> dict:
        """Lock credits in escrow until job is complete."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        return self._post("/escrow/create", {
            "api_key": self.api_key,
            "seller_address": seller_address,
            "amount_credits": amount_credits,
            "description": description
        })

    def escrow_release(self, escrow_id: str) -> dict:
        """Release escrowed credits to seller — confirms job complete."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        return self._post("/escrow/release", {
            "api_key": self.api_key,
            "escrow_id": escrow_id
        })

    def escrow_dispute(self, escrow_id: str, reason: str = "") -> dict:
        """Dispute escrow — refunds credits to buyer."""
        if not self.api_key:
            raise ValueError("No API key. Call register() first.")
        return self._post("/escrow/dispute", {
            "api_key": self.api_key,
            "escrow_id": escrow_id,
            "reason": reason
        })

    def escrow_status(self, escrow_id: str) -> dict:
        """Check escrow status."""
        return self._get(f"/escrow/status/{escrow_id}")
    def health(self) -> dict:
        """Check AgentSats node status."""
        return self._get("/health")
