from setuptools import setup, find_packages

setup(
    name="agentsats",
    version="0.3.0",
    description="Tokenized AI compute and identity — powered by Teranodex",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="AgentSats",
    url="https://api.spark-bsv.uk",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
