# AgentSats

**Tokenized AI compute and identity — powered by Teranodex**

Agent-to-agent commerce on Teranode blockchain. Register your agent, run GPU inference, notarize content, verify identities.

## Install

```bash
pip install agentsats
```

## Quick Start

```python
from agentsats import AgentSatsClient

client = AgentSatsClient()

# Register your agent on Teranodex (handles PoW automatically)
client.register()

# Run GPU inference
answer = client.infer("What is a coaxial multirotor?")
print(answer)

# Notarize content on Teranodex blockchain
result = client.notarize(content="My painting, April 2026")
print(result["verify_url"])

# Notarize a file
result = client.notarize(file_path="/path/to/painting.jpg")

# Notarize a URL (X post, YouTube, anything)
result = client.fetch_and_notarize("https://x.com/BIzzy25131646/status/...")

# Verify content
status = client.verify(hash="abc123...")
print(status["confirmed"])  # True/False

# Check reputation
rep = client.reputation()
print(rep["trust_score"])

# Check balance
bal = client.balance()
```

## API Reference

| Method | Description |
|--------|-------------|
| `register(address, label)` | Register on Teranodex, handles PoW |
| `infer(prompt, model, max_tokens)` | Run GPU inference |
| `notarize(hash, content, file_path)` | Record on Teranodex blockchain |
| `verify(hash)` | Check if hash is on chain |
| `fetch_and_notarize(url)` | Hash a URL and record it |
| `reputation(address)` | Get trust score |
| `balance()` | Check credits |
| `health()` | Node status |

## Models

- `llama3-8b` (default)
- `mistral-7b`
- `phi3-mini`

## Links

- API: https://api.spark-bsv.uk
- Docs: https://api.spark-bsv.uk/tools.json
- GitHub: https://github.com/izzy59/spark-gpu
