"""WRITES A REAL TRANSACTION on Ethereum mainnet — moves real funds.

Stake `amount` of `asset` into the Morpheus DepositPool with Hypnex Labs as
the on-chain referrer. The default-referrer override happens via the
HYPNEX_REFERRER env var or the Staker(default_referrer=...) constructor arg.

Always run with --dry-run first. Test against Anvil fork before live.

Run:
    ETH_RPC_URL=https://... \\
    PRIVATE_KEY=0x... \\
    python examples/04_stake.py USDC 100 --dry-run

To broadcast for real, drop the --dry-run flag.
"""

import argparse
import os

from hypnex_staking import Staker


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("asset", choices=["USDC", "USDT", "WBTC", "WETH"])
    p.add_argument("amount", type=float)
    p.add_argument("--claim-lock-end", type=int, default=0,
                   help="Unix timestamp for voluntary additional claim lock; 0 = no extra lock")
    p.add_argument("--referrer", type=str, default=None,
                   help="Override default referrer (HYPNEX_REFERRER env / Staker default)")
    p.add_argument("--dry-run", action="store_true",
                   help="Build but do NOT broadcast — print calldata only")
    args = p.parse_args()

    rpc = os.environ.get("ETH_RPC_URL")
    pk = os.environ.get("PRIVATE_KEY")
    if not rpc or not pk:
        print("error: set ETH_RPC_URL and PRIVATE_KEY")
        return 2

    s = Staker(rpc_url=rpc, private_key=pk)

    print(f"  asset            : {args.asset}")
    print(f"  amount           : {args.amount}")
    print(f"  claim_lock_end   : {args.claim_lock_end}")
    print(f"  referrer         : {args.referrer or s.default_referrer}")
    print(f"  signer           : {s.account.address}")
    print(f"  pool             : {s.get_pool_address(args.asset)}")
    print(f"  dry_run          : {args.dry_run}")
    print()

    out = s.stake(
        asset=args.asset,
        amount=args.amount,
        claim_lock_end=args.claim_lock_end,
        referrer=args.referrer,
        dry_run=args.dry_run,
    )
    if args.dry_run:
        print(f"  encoded calldata : {out}")
    else:
        print(f"  tx hash          : {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
