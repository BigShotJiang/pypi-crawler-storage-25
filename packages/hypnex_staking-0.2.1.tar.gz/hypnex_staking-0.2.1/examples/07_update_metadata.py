"""Update Hypnex subnet metadata on Base + Arbitrum (admin-only).

Use this to change the description, slug, website, or image URL after creation.
The on-chain `name` ("Hypnex") and the resulting `subnet_id` are immutable —
everything else is updateable by the subnet's admin.

Run dry-run first:
    PRIVATE_KEY=0x... python examples/07_update_metadata.py --dry-run

Run for real (will prompt 'UPDATE' to broadcast each chain):
    PRIVATE_KEY=0x... python examples/07_update_metadata.py
"""

from __future__ import annotations

import argparse
import os

from hypnex_staking import BuildersClient, SubnetMetadata


# === EDIT THESE to change what the dashboard displays =======================
NEW_METADATA = SubnetMetadata(
    slug="hypnex",
    description="Wallet-native staking onramp + OpenAI-compatible SDK for Morpheus AI inference. Refer once via MRC 73, earn unlocked MOR.",
    website="https://hypnex.xyz",
    # Use the SQUARE brand logo (1024×1024) — dashboard cards expect a square avatar.
    image="https://hypnex.xyz/square-1024.png",
)
# ============================================================================


def update_chain(chain: str, dry_run: bool, private_key: str) -> int:
    print(f"\n{'='*60}\n{chain.upper()}\n{'='*60}")
    c = BuildersClient(chain=chain, private_key=private_key)
    print(f"signer:             {c.account.address}")
    print(f"chain id:           {c.w3.eth.chain_id}")
    print(f"builders contract:  {c.address}")

    if not c.subnet_exists("Hypnex"):
        print(f"!! subnet 'Hypnex' does NOT exist on {chain} — nothing to update")
        return 1

    sid = c.subnet_id_of("Hypnex")
    s = c.get_subnet(sid)
    print(f"current admin:      {s.admin}")
    if s.admin.lower() != c.account.address.lower():
        print(f"!! signer {c.account.address} is NOT admin of this subnet — tx will revert")
        return 1

    print("\nproposed metadata:")
    print(f"  slug:        {NEW_METADATA.slug}")
    print(f"  description: {NEW_METADATA.description}")
    print(f"  website:     {NEW_METADATA.website}")
    print(f"  image:       {NEW_METADATA.image}")

    if dry_run:
        cd = c.edit_subnet_metadata(sid, NEW_METADATA, dry_run=True)
        print(f"\nDRY RUN — calldata: {cd[:120]}{'...' if len(cd)>120 else ''}")
        return 0

    confirm = input(f"\n>>> Type 'UPDATE' to broadcast on {chain} (any other input skips): ")
    if confirm.strip() != "UPDATE":
        print(f"  skipped {chain}")
        return 0

    tx = c.edit_subnet_metadata(sid, NEW_METADATA)
    explorer = "basescan.org" if chain == "base" else "arbiscan.io"
    print(f"[OK] tx submitted: {tx}")
    print(f"     https://{explorer}/tx/{tx}")
    return 0


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--dry-run", action="store_true", help="encode but do not broadcast")
    p.add_argument("--chain", choices=["base", "arbitrum", "both"], default="both")
    args = p.parse_args()

    pk = os.environ.get("PRIVATE_KEY")
    if not pk:
        print("error: set PRIVATE_KEY env var (the Hypnex admin key 0x22B5...57D8)")
        return 2

    chains = ["base", "arbitrum"] if args.chain == "both" else [args.chain]
    for chain in chains:
        update_chain(chain, args.dry_run, pk)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
