"""WRITES A REAL TRANSACTION — claims your accumulated MRC 73 unlocked-MOR rewards.

Per MRC 73, referrer MOR is unlocked the moment it accrues — no 90-day delay
that capital contributors face under MRC 46. This is the lowest-friction MOR
yield path on the network.

Run:
    ETH_RPC_URL=... PRIVATE_KEY=... \\
    python examples/05_claim_referrer_rewards.py USDC --dry-run
"""

import argparse
import os

from hypnex_staking import Staker


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("asset", choices=["USDC", "USDT", "WBTC", "WETH"])
    p.add_argument("--receiver", type=str, default=None,
                   help="Address to receive the MOR (defaults to signer)")
    p.add_argument("--lz-fee-wei", type=int, default=0,
                   help="LayerZero messaging fee if cross-chain forwarding (default 0)")
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    rpc = os.environ["ETH_RPC_URL"]
    pk = os.environ["PRIVATE_KEY"]
    s = Staker(rpc_url=rpc, private_key=pk)

    out = s.claim_referrer_rewards(
        asset=args.asset,
        receiver=args.receiver,
        layerzero_fee_wei=args.lz_fee_wei,
        dry_run=args.dry_run,
    )
    print(f"{'calldata' if args.dry_run else 'tx hash'}: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
