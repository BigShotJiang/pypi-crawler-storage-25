"""Buy MOR with native ETH via Uniswap V3 (Arbitrum or Base).

This is a real on-chain swap — ETH leaves your wallet, MOR arrives. Uses
Uniswap V3's SwapRouter02 directly (no third-party API). Slippage cap +
deadline + dry-run guard included.

Routes:
  Arbitrum: native ETH → WETH (auto-wrapped) → MOR via 0.3% MOR/WETH pool
            (pool 0xE5Cf22EE4988d54141B77050967E1052Bd9c7F7A, ~$1M liquidity)
  Base:     native ETH → WETH → MOR via 1% MOR/WETH pool on Uniswap V3
            (Aerodrome has more liquidity but uses a different router)

Usage:
    # Dry-run (no broadcast):
    PRIVATE_KEY=0x... python examples/09_buy_mor.py \\
        --chain arbitrum --eth 0.0005 --dry-run

    # Real swap (will prompt 'BUY' before broadcasting):
    PRIVATE_KEY=0x... python examples/09_buy_mor.py \\
        --chain arbitrum --eth 0.0005

After completion, the MOR sits in your wallet. Run example 08 to deposit
into the Hypnex subnet on the same chain.
"""

from __future__ import annotations

import argparse
import os

from web3 import Web3

# === Per-chain config =======================================================
CONFIGS = {
    "arbitrum": {
        "rpc": "https://arb1.arbitrum.io/rpc",
        "chain_id": 42161,
        "weth": "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
        "mor": "0x092baadb7def4c3981454dd9c0a0d7ff07bcfc86",
        "swap_router_02": "0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45",
        "quoter_v2": "0x61fFE014bA17989E743c5F6cB21bF9697530B21e",
        "fee_tier": 3000,  # 0.3% — pool 0xE5Cf22EE...
        "explorer": "arbiscan.io",
    },
    "base": {
        "rpc": "https://mainnet.base.org",
        "chain_id": 8453,
        "weth": "0x4200000000000000000000000000000000000006",
        "mor": "0x7431aDa8a591C955a994a21710752EF9b882b8e3",
        # SwapRouter02 on Base
        "swap_router_02": "0x2626664c2603336E57B271c5C0b26F421741e481",
        "quoter_v2": "0x3d4e44Eb1374240CE5F1B871ab261CD16335B76a",
        "fee_tier": 10000,  # 1% — typical for thinner pools (verify before running)
        "explorer": "basescan.org",
    },
}

SWAP_ROUTER_02_ABI = [
    {
        "name": "exactInputSingle",
        "type": "function",
        "stateMutability": "payable",
        "inputs": [{
            "components": [
                {"name": "tokenIn", "type": "address"},
                {"name": "tokenOut", "type": "address"},
                {"name": "fee", "type": "uint24"},
                {"name": "recipient", "type": "address"},
                {"name": "amountIn", "type": "uint256"},
                {"name": "amountOutMinimum", "type": "uint256"},
                {"name": "sqrtPriceLimitX96", "type": "uint160"},
            ],
            "name": "params",
            "type": "tuple",
        }],
        "outputs": [{"name": "amountOut", "type": "uint256"}],
    }
]

QUOTER_V2_ABI = [
    {
        "name": "quoteExactInputSingle",
        "type": "function",
        "stateMutability": "nonpayable",  # uses revert-with-data, so state-changing in eth_call
        "inputs": [{
            "components": [
                {"name": "tokenIn", "type": "address"},
                {"name": "tokenOut", "type": "address"},
                {"name": "amountIn", "type": "uint256"},
                {"name": "fee", "type": "uint24"},
                {"name": "sqrtPriceLimitX96", "type": "uint160"},
            ],
            "name": "params",
            "type": "tuple",
        }],
        "outputs": [
            {"name": "amountOut", "type": "uint256"},
            {"name": "sqrtPriceX96After", "type": "uint160"},
            {"name": "initializedTicksCrossed", "type": "uint32"},
            {"name": "gasEstimate", "type": "uint256"},
        ],
    }
]


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--chain", choices=["arbitrum", "base"], required=True)
    p.add_argument("--eth", type=float, required=True,
                   help="ETH amount to swap (e.g. 0.0005 ≈ $1.75 at $3500/ETH)")
    p.add_argument("--slippage", type=float, default=1.0,
                   help="Max slippage in %% (default 1.0 — very generous for low-volume MOR)")
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    cfg = CONFIGS[args.chain]
    pk = os.environ.get("PRIVATE_KEY")
    if not pk:
        print(f"error: set PRIVATE_KEY env var (a wallet with {args.eth} ETH + gas on {args.chain})")
        return 2

    w3 = Web3(Web3.HTTPProvider(cfg["rpc"]))
    acct = w3.eth.account.from_key(pk)
    if w3.eth.chain_id != cfg["chain_id"]:
        print(f"!! RPC reports chain_id={w3.eth.chain_id}, expected {cfg['chain_id']}")
        return 1

    eth_wei = w3.to_wei(args.eth, "ether")
    bal = w3.eth.get_balance(acct.address)

    print(f"signer:        {acct.address}")
    print(f"chain:         {args.chain} ({cfg['chain_id']})")
    print(f"router:        {cfg['swap_router_02']}")
    print(f"MOR token:     {cfg['mor']}")
    print(f"fee tier:      {cfg['fee_tier']/10000}%")
    print(f"signer ETH:    {bal/1e18:.6f} ETH")
    print(f"swapping:      {args.eth} ETH ({eth_wei} wei)")
    print(f"slippage cap:  {args.slippage}%")

    if eth_wei > bal and not args.dry_run:
        print(f"!! insufficient ETH (need {args.eth}, have {bal/1e18:.6f}) — fund wallet on {args.chain} first")
        return 1

    # 1. Quote
    quoter = w3.eth.contract(
        address=Web3.to_checksum_address(cfg["quoter_v2"]),
        abi=QUOTER_V2_ABI,
    )
    quote_params = (
        Web3.to_checksum_address(cfg["weth"]),
        Web3.to_checksum_address(cfg["mor"]),
        eth_wei,
        cfg["fee_tier"],
        0,
    )
    try:
        result = quoter.functions.quoteExactInputSingle(quote_params).call()
        amount_out = result[0]
    except Exception as e:
        print(f"!! quote failed: {e}")
        print(f"   Common cause: pool with fee tier {cfg['fee_tier']/10000}% doesn't exist for MOR/WETH on {args.chain}.")
        print("   Try a different fee tier (--help) or use the Uniswap UI manually.")
        return 1

    min_out = amount_out * (10000 - int(args.slippage * 100)) // 10000
    print("\nquote:")
    print(f"  expected MOR: {amount_out/1e18:.6f} MOR")
    print(f"  min accepted: {min_out/1e18:.6f} MOR (after {args.slippage}% slippage cap)")
    print(f"  effective px: ${args.eth * 3500 / (amount_out/1e18):.4f}/MOR (assumes ETH=$3500; check live)")

    # 2. Build swap
    router = w3.eth.contract(
        address=Web3.to_checksum_address(cfg["swap_router_02"]),
        abi=SWAP_ROUTER_02_ABI,
    )
    # SwapRouter02 doesn't take a deadline param (it relies on Multicall+deadline pattern, not used here).
    swap_params = (
        Web3.to_checksum_address(cfg["weth"]),  # tokenIn (WETH; will be wrapped from native ETH via msg.value)
        Web3.to_checksum_address(cfg["mor"]),    # tokenOut
        cfg["fee_tier"],
        acct.address,                            # recipient
        eth_wei,                                 # amountIn (== msg.value)
        min_out,                                 # amountOutMinimum
        0,                                       # sqrtPriceLimitX96 (no limit)
    )

    if args.dry_run:
        cd = router.functions.exactInputSingle(swap_params)._encode_transaction_data()
        print(f"\nDRY RUN — encoded calldata: {cd[:120]}...")
        print(f"           value (msg.value):  {eth_wei} wei = {args.eth} ETH")
        print(f"           to:                 {cfg['swap_router_02']}")
        return 0

    confirm = input(f"\n>>> Type 'BUY' to swap {args.eth} ETH for ~{amount_out/1e18:.4f} MOR on {args.chain}: ")
    if confirm.strip() != "BUY":
        print("aborted.")
        return 1

    # 3. Build, sign, send
    nonce = w3.eth.get_transaction_count(acct.address)
    tx = router.functions.exactInputSingle(swap_params).build_transaction({
        "from": acct.address,
        "value": eth_wei,
        "nonce": nonce,
        "chainId": cfg["chain_id"],
        # gas: let web3 estimate; provide a ceiling
        "gas": 250_000,
    })
    signed = acct.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction).hex()
    print(f"\n[OK] swap tx: 0x{tx_hash}")
    print(f"     https://{cfg['explorer']}/tx/0x{tx_hash}")
    print("\nNext:")
    print("  1. Wait ~30s for confirmation")
    print("  2. Check MOR balance:")
    print(f"     python3 -c \"from hypnex_staking import BuildersClient; c=BuildersClient(chain='{args.chain}', private_key='$PRIVATE_KEY'); print(c.mor_balance(c.account.address)/1e18, 'MOR')\"")
    print("  3. Deposit into the Hypnex subnet:")
    print(f"     python3 examples/08_bootstrap_deposit.py --chain {args.chain} --amount 1.0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
