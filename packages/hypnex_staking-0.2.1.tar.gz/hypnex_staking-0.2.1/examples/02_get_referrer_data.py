"""Read a referrer's data: amount staked under them, virtual amount, pending unlocked MOR.

Read-only.

Run:  python examples/02_get_referrer_data.py 0xReferrerAddress... USDC
"""

import sys

from hypnex_staking import Staker


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: python 02_get_referrer_data.py <referrer> <USDC|USDT|WBTC|WETH>")
        return 2
    referrer, asset = sys.argv[1], sys.argv[2]
    s = Staker()
    d = s.get_referrer_data(referrer, asset)
    decimals = s.get_decimals(asset)
    print(f"Referrer data for {referrer} in {asset.upper()} pool:")
    print(f"  amount staked under referrer  : {d.amount_staked / 10**decimals:,.6f} {asset.upper()}")
    print(f"  virtual amount (after tier)   : {d.virtual_amount_staked / 10**decimals:,.6f}")
    print(f"  pending unlocked MOR rewards  : {d.pending_rewards / 1e18:,.6f} MOR  (MRC 73 — claim anytime)")
    print(f"  last claim                    : {d.last_claim} (unix)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
