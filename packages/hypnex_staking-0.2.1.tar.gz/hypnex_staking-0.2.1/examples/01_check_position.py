"""Read your stake position from the Morpheus capital pool.

Read-only — no key required.

Run:  python examples/01_check_position.py 0xYourAddress... USDC
"""

import sys

from hypnex_staking import Staker


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: python 01_check_position.py <address> <USDC|USDT|WBTC|WETH>")
        return 2
    address, asset = sys.argv[1], sys.argv[2]
    s = Staker()
    p = s.get_position(address, asset)
    decimals = s.get_decimals(asset)
    print(f"Position for {address} in {asset.upper()} pool:")
    print(f"  deposited        : {p.deposited / 10**decimals:,.6f} {asset.upper()}")
    print(f"  pending rewards  : {p.pending_rewards / 1e18:,.6f} MOR")
    print(f"  claim_lock_end   : {p.claim_lock_end} (unix)")
    print(f"  referrer         : {p.referrer}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
