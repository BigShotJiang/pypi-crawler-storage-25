"""Read the live referrer-tier table for each pool and quote which tier a given
virtual stake amount falls in.

Read-only.

Run:  python examples/03_quote_tier.py
"""

from hypnex_staking import Staker


def main() -> None:
    s = Staker()

    for asset in ("USDC", "USDT", "WBTC", "WETH"):
        decimals = s.get_decimals(asset)
        print(f"\n{asset} pool — referrer tiers:")
        tiers = s.get_referrer_tiers(asset)
        if not tiers:
            print("  (no tiers configured on-chain — fall through to base 1% referee bonus)")
            continue
        for i, t in enumerate(tiers):
            # multiplier is PRECISION-scaled (1e25 == 1.0×); convert to bonus %
            multiplier_x = t.multiplier / 1e25
            bonus_pct = (multiplier_x - 1.0) * 100
            print(
                f"  tier {i}: ≥ {t.amount_threshold / 10**decimals:>12,.4f} {asset} "
                f"→ {multiplier_x:.4f}× ({bonus_pct:+.1f}%)"
            )

    print("\nNote: tier thresholds are denominated in the *virtual amount* — i.e. the\n"
          "amount-staked × the referee's claim-lock-time multiplier. Long locks count\n"
          "for more virtual stake, which can push a referrer up a tier.")


if __name__ == "__main__":
    main()
