"""Bootstrap-deposit MOR into the Hypnex subnet (Base or Arbitrum).

This is a real-funds, on-chain MOR deposit. The depositor's MOR moves into
the subnet contract and is locked for `withdraw_lock_after_deposit` (7 days
for Hypnex). Subnet TVL goes up by `amount`. Auto-approves MOR if allowance
is short.

Anyone can run this (depositor doesn't need to be admin). For Hypnex Labs
self-bootstrapping, the signer would be the admin wallet (0x22B5...57D8).

Usage:
    # Dry run — encode but don't broadcast (any private key works)
    PRIVATE_KEY=0x... python examples/08_bootstrap_deposit.py \\
        --chain base --amount 1.0 --dry-run

    # Real deposit — prompts DEPOSIT to confirm
    PRIVATE_KEY=0x... python examples/08_bootstrap_deposit.py \\
        --chain base --amount 1.0
"""

from __future__ import annotations

import argparse
import os

from hypnex_staking import BuildersClient


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--chain", choices=["base", "arbitrum"], required=True,
                   help="which chain's Hypnex subnet to deposit into")
    p.add_argument("--amount", type=float, required=True,
                   help="MOR amount to deposit (e.g. 1.0). Must be >= subnet minimum (1 MOR for Hypnex).")
    p.add_argument("--dry-run", action="store_true",
                   help="encode but do not broadcast")
    p.add_argument("--no-auto-approve", action="store_true",
                   help="skip the auto-approve step (you must approve manually)")
    args = p.parse_args()

    pk = os.environ.get("PRIVATE_KEY")
    if not pk:
        print("error: set PRIVATE_KEY env var (a wallet holding MOR + a tiny amount of",
              args.chain, "ETH for gas)")
        return 2

    c = BuildersClient(chain=args.chain, private_key=pk)
    sid = c.subnet_id_of("Hypnex")

    if not c.subnet_exists("Hypnex"):
        print(f"!! subnet 'Hypnex' does NOT exist on {args.chain}")
        return 1

    s = c.get_subnet(sid)
    amount_wei = int(args.amount * 10**18)

    # MOR balance + allowance check
    mor_balance = c.mor_balance(c.account.address)
    mor_allowance = c.mor_allowance_to_builders(c.account.address)

    print(f"signer:             {c.account.address}")
    print(f"chain:              {args.chain} (chain_id={c.w3.eth.chain_id})")
    print(f"builders contract:  {c.address}")
    print(f"MOR token:          {c.mor_address}")
    print(f"subnet_id:          0x{sid.hex()}")
    print()
    print(f"signer MOR balance: {mor_balance/1e18:.6f} MOR")
    print(f"current allowance:  {mor_allowance/1e18:.6f} MOR")
    print(f"deposit amount:     {amount_wei/1e18} MOR ({amount_wei} wei)")
    print(f"subnet minimum:     {s.minimal_deposit/1e18} MOR")
    print(f"withdraw lock:      {s.withdraw_lock_after_deposit}s ({s.withdraw_lock_after_deposit//86400}d) after deposit")
    print()

    if amount_wei < s.minimal_deposit:
        print(f"!! amount {amount_wei/1e18} < subnet minimum {s.minimal_deposit/1e18}")
        return 1
    if amount_wei > mor_balance and not args.dry_run:
        print(f"!! insufficient MOR: have {mor_balance/1e18}, need {amount_wei/1e18}")
        return 1

    needs_approve = mor_allowance < amount_wei
    if needs_approve:
        print(f"NOTE: allowance is short. {'Auto-approve enabled' if not args.no_auto_approve else 'Manual approve required (--no-auto-approve set)'}")

    if args.dry_run:
        cd = c.deposit(sid, amount_wei, dry_run=True)
        print(f"\nDRY RUN — deposit calldata: {cd[:120]}{'...' if len(cd)>120 else ''}")
        return 0

    confirm = input(f"\n>>> Type 'DEPOSIT' to broadcast {args.amount} MOR into Hypnex on {args.chain}: ")
    if confirm.strip() != "DEPOSIT":
        print("aborted.")
        return 1

    if needs_approve and not args.no_auto_approve:
        print("approving MOR (allowance bump)...")
        # auto_approve=True will issue the approve before deposit

    tx = c.deposit(sid, amount_wei, auto_approve=not args.no_auto_approve)
    explorer = "basescan.org" if args.chain == "base" else "arbiscan.io"
    print(f"\n[OK] deposit tx: {tx}")
    print(f"     https://{explorer}/tx/{tx}")
    print()
    print("Next:")
    print(f"  - Wait ~30s, then refresh dashboard.mor.org/builders — TVL goes up by {args.amount} MOR")
    print(f"  - Withdraw available {s.withdraw_lock_after_deposit//86400}d after this deposit")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
