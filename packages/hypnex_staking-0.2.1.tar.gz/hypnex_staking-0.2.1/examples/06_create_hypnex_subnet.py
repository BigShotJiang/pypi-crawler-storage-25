"""Launch the **Hypnex** subnet on Morpheus Builders V4.

This is a one-time, real-funds-moving transaction on **Base mainnet**
(default; pass `--chain arbitrum` for Arbitrum One). The signer pays gas
(~$0.10) and the subnet `claim_admin` is what earns MOR rewards
proportional to TVL.

The Builders V4 subnet creation fee is currently **0 MOR on both Arbitrum
and Base mainnet** — only gas is required. (Base Sepolia testnet charges
~0.123 MOR for creation; useful for end-to-end SDK rehearsals.) The
script reads the live fee from `subnetCreationFeeAmount()` before the
broadcast, and auto-approves MOR if the fee is non-zero.

Run (dry-run first — prints calldata, no broadcast):

    PRIVATE_KEY=0x... python examples/06_create_hypnex_subnet.py --dry-run

Run for real:

    PRIVATE_KEY=0x... python examples/06_create_hypnex_subnet.py

After success, MOR holders can deposit into the subnet via:

    sid = client.subnet_id_of("Hypnex")
    client.deposit(sid, amount_in_wei)

You (the claim-admin) collect rewards via:

    client.claim(sid)                 # to your own address
    client.claim(sid, "0xreceiver...")
"""

from __future__ import annotations

import argparse
import os

from hypnex_staking import BuildersClient, Subnet, SubnetMetadata

# === EDIT THESE if you want different params ================================
PROJECT_NAME = "Hypnex"
ADMIN = "0x22B5C0075372E743042b2d62b3D254425Eb957D8"   # Hypnex Labs — earns rewards
CLAIM_ADMIN = ADMIN                                    # who can call claim()

# Stakers' funds locked for 7 days after each deposit (matches protocol min).
WITHDRAW_LOCK_AFTER_DEPOSIT = 7 * 24 * 3600

# Stakers must deposit at least 1 MOR (1e18 wei).
MINIMAL_DEPOSIT_WEI = 10 ** 18

# Public-facing metadata indexed by the dashboard subgraph.
DEFAULT_METADATA = SubnetMetadata(
    slug="hypnex",
    description="Wallet-native staking onramp + OpenAI-compatible SDK for Morpheus AI inference. Refer once via MRC 73, earn unlocked MOR.",
    website="https://hypnex.xyz",
    image="https://hypnex.xyz/og-image.png",
)

# Which chain to launch on. "base" = canonical V4 (matches dashboard.mor.org).
# "arbitrum" works too — same V4 implementation, different chain id mixed
# into the subnet id.
DEFAULT_CHAIN = "base"
# ============================================================================


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--dry-run", action="store_true",
                   help="Encode the tx but do NOT broadcast — prints calldata for review")
    p.add_argument("--name", default=PROJECT_NAME)
    p.add_argument("--admin", default=ADMIN)
    p.add_argument("--claim-admin", default=CLAIM_ADMIN)
    p.add_argument("--chain", default=DEFAULT_CHAIN, choices=["arbitrum", "base"])
    p.add_argument("--min-stake-mor", type=float, default=1.0,
                   help="Minimum stake size required from depositors, in MOR (default: 1.0)")
    args = p.parse_args()

    pk = os.environ.get("PRIVATE_KEY")
    if not pk:
        print("error: set PRIVATE_KEY env var (a wallet with a tiny amount of",
              args.chain, "ETH for gas)")
        return 2

    c = BuildersClient(chain=args.chain, private_key=pk)
    print(f"signer:                {c.account.address}")
    print(f"chain:                 {args.chain} (chain_id={c.w3.eth.chain_id})")
    print(f"builders contract:     {c.address}")
    print(f"contract version:      v{c.version()}")
    print(f"MOR token:             {c.mor_address}")

    creation_fee = c.subnet_creation_fee()
    print(f"creation fee:          {creation_fee / 1e18} MOR ({creation_fee} wei)")
    print(f"protocol min lock:     {c.minimal_withdraw_lock_period()} s")

    sid = c.subnet_id_of(args.name)
    if c.subnet_exists(args.name):
        existing = c.get_subnet(sid)
        print(f"\n!! subnet already exists with id 0x{sid.hex()}")
        if existing is not None:
            print(f"   name: {existing.name}")
            print(f"   admin: {existing.admin}")
            print(f"   claim_admin: {existing.claim_admin}")
            print(f"   minimalDeposit: {existing.minimal_deposit / 1e18} MOR")
        return 0

    minimal_deposit_wei = int(args.min_stake_mor * 10 ** 18) if args.min_stake_mor else MINIMAL_DEPOSIT_WEI
    subnet = Subnet(
        name=args.name,
        admin=args.admin,
        withdraw_lock_after_deposit=WITHDRAW_LOCK_AFTER_DEPOSIT,
        minimal_deposit=minimal_deposit_wei,
        claim_admin=args.claim_admin,
    )
    metadata = DEFAULT_METADATA

    print("\nproposed Subnet:")
    print(f"  name:                       {subnet.name!r}")
    print(f"  admin:                      {subnet.admin}")
    print(f"  claim_admin:                {subnet.claim_admin}")
    print(f"  withdraw_lock_after_deposit:{subnet.withdraw_lock_after_deposit} s "
          f"({subnet.withdraw_lock_after_deposit//86400} d)")
    print(f"  minimal_deposit:            {subnet.minimal_deposit / 1e18} MOR")
    print(f"  predicted subnet_id:        0x{sid.hex()}")
    print("metadata:")
    print(f"  slug:        {metadata.slug}")
    print(f"  description: {metadata.description}")
    print(f"  website:     {metadata.website}")
    print(f"  image:       {metadata.image}")

    if args.dry_run:
        calldata = c.create_subnet(subnet, metadata, dry_run=True)
        print("\nDRY RUN — encoded calldata (first 200 chars):")
        print(f"  {calldata[:200]}{'...' if len(calldata) > 200 else ''}")
        print("\nRe-run without --dry-run to broadcast the tx.")
        return 0

    confirm = input("\n>>> Type 'CREATE' to broadcast (any other input cancels): ")
    if confirm.strip() != "CREATE":
        print("aborted.")
        return 1

    tx_hash = c.create_subnet(subnet, metadata)
    print(f"\n[OK] tx submitted: {tx_hash}")
    explorer = "basescan.org" if args.chain == "base" else "arbiscan.io"
    print(f"   https://{explorer}/tx/{tx_hash}")
    print(f"   subnet_id once confirmed: 0x{sid.hex()}")
    print("\nNext steps:")
    print("   1. Wait ~30 sec for confirmation")
    print("   2. Stakers can call BuildersClient.deposit(subnet_id, amount)")
    print("   3. Visit dashboard.mor.org/builders to see the subnet listed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
