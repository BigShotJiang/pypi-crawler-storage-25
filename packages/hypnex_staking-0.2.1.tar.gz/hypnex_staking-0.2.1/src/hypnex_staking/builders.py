"""BuildersClient — Morpheus Builders V4 (a.k.a. "subnets") helpers.

This is **the Code/Builders revenue stream**, separate from the capital pool
(MRC 73 referrals at stake.hypnex.xyz). Subnets live on Arbitrum or Base,
accept MOR deposits, and the project admin earns MOR from a separate
emission pool proportional to TVL.

Status as of 2026-05-07:

- The V3 contract was upgraded to V4 IN PLACE — the proxies still live at
  the same addresses (Arbitrum: 0xC0eD68f1…, Base: 0x42BB446e…) but
  `version()` returns 4 and the function set + struct shape changed.
- Subnet creation fee on **Arbitrum and Base mainnet is currently zero MOR**
  (just gas). The Base Sepolia testnet charges ~0.123 MOR for creation.
- MOR is the deposit/payment token on every chain.
- The protocol-set min withdraw lock is 7 days (604800s).
- Subnet IDs are now derived on-chain via `getSubnetId(string)` and include
  `block.chainid` in the hash — the same name yields a different id on
  Arbitrum vs Base. Always read the id from the contract (or via
  `BuildersClient.subnet_id_of(name)`); do NOT compute it off-chain.

WARNING — write methods send transactions on Arbitrum / Base mainnet:

- `create_subnet(subnet, metadata)` registers a new subnet. One-time per
  project. Pays the current `subnet_creation_fee()` in MOR. Always run
  with `dry_run=True` first to inspect the encoded calldata.
- `deposit(subnet_id, amount)` stakes MOR. Requires ERC20 approve first.
- `withdraw(subnet_id, amount)` unstakes after the per-subnet lock period.
- `claim(subnet_id, receiver)` collects MOR rewards (claim-admin only).
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Optional

from eth_account import Account
from eth_account.signers.local import LocalAccount
from web3 import Web3
from web3.contract import Contract

from ._abi import BUILDERS_ABI, ERC20_ABI
from ._constants import (
    BUILDERS_ADDRESSES,
    BUILDERS_CHAIN_IDS,
    BUILDERS_PROBE_ADDRESS,
    BUILDERS_RPC_FALLBACKS,
    DEFAULT_BUILDERS_CHAIN,
    ENV_BUILDERS_CHAIN,
    ENV_BUILDERS_RPC,
    ENV_PRIVATE_KEY,
    MOR_TOKEN,
    PROBE_CALLDATA,
    ZERO_ADDRESS,
)


# --- Domain models ---------------------------------------------------------
@dataclass
class Subnet:
    """A registered V4 subnet ("builder pool" in V3 terminology).

    The two `unusedStorage*_V4Update` fields are storage placeholders kept
    for upgrade compatibility — leave them at 0. `claimAdmin` is the address
    that can call `claim()`; it defaults to `admin` if you pass the zero
    address.
    """

    name: str
    admin: str
    withdraw_lock_after_deposit: int            # seconds (>= protocol min, currently 7 days)
    minimal_deposit: int                        # wei (1e18-scaled MOR)
    claim_admin: Optional[str] = None           # defaults to admin if not set
    unused_storage_1: int = 0
    unused_storage_2: int = 0

    def to_tuple(self) -> tuple:
        admin = Web3.to_checksum_address(self.admin)
        claim = Web3.to_checksum_address(self.claim_admin) if self.claim_admin else admin
        return (
            self.name,
            admin,
            int(self.unused_storage_1),
            int(self.withdraw_lock_after_deposit),
            int(self.unused_storage_2),
            int(self.minimal_deposit),
            claim,
        )


@dataclass
class SubnetMetadata:
    """Public-facing subnet metadata (indexed by the dashboard's subgraph)."""

    slug: str
    description: str = ""
    website: str = ""
    image: str = ""

    def to_tuple(self) -> tuple:
        return (self.slug, self.description, self.website, self.image)


@dataclass
class UserSubnetData:
    """Per-user, per-subnet deposit state (V4 layout)."""

    last_deposit: int
    deposited: int


@dataclass
class SubnetData:
    """Per-subnet aggregate state."""

    deposited: int
    rate: int
    pending_rewards: int


# Backwards-compat alias for callers that imported the old names. Keeping
# these as aliases avoids breaking any examples or tests written for V3.
BuilderPool = Subnet
UserPoolData = UserSubnetData


# --- Internal helpers ------------------------------------------------------
def _connect_with_fallback(chain: str, timeout: int = 20) -> Web3:
    candidates = BUILDERS_RPC_FALLBACKS.get(chain, ())
    if not candidates:
        raise ValueError(f"Unknown builders chain {chain!r}")
    expected_id = BUILDERS_CHAIN_IDS[chain]
    probe_to = Web3.to_checksum_address(BUILDERS_PROBE_ADDRESS[chain])
    last_err: Optional[Exception] = None
    for url in candidates:
        try:
            w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": timeout}))
            if not w3.is_connected() or w3.eth.chain_id != expected_id:
                continue
            w3.eth.call({"to": probe_to, "data": PROBE_CALLDATA})
            return w3
        except Exception as e:  # noqa: BLE001
            last_err = e
            continue
    raise ConnectionError(
        f"None of the public RPCs for {chain} accepted view calls. "
        f"Pass rpc_url=... or set {ENV_BUILDERS_RPC}. Last error: {last_err!r}"
    )


def _is_zero_address(addr: str) -> bool:
    if not addr:
        return True
    try:
        return int(addr, 16) == 0
    except (TypeError, ValueError):
        return True


# --- Client ---------------------------------------------------------------
class BuildersClient:
    """High-level interface to BuildersV4 on Arbitrum or Base.

    Read methods need just an RPC. Write methods need an account.

    Example:

        c = BuildersClient(chain="base")
        sid = c.subnet_id_of("Hypnex")
        print(c.get_subnet(sid))            # None if not yet created

        c_signed = BuildersClient(chain="base", private_key=...)
        c_signed.create_subnet(
            Subnet(
                name="Hypnex",
                admin="0xYour...Address",
                withdraw_lock_after_deposit=7 * 24 * 3600,
                minimal_deposit=10**18,         # 1 MOR
            ),
            SubnetMetadata(slug="hypnex", website="https://hypnex.xyz"),
            dry_run=True,                       # always dry-run first
        )
    """

    def __init__(
        self,
        chain: Optional[str] = None,
        rpc_url: Optional[str] = None,
        w3: Optional[Web3] = None,
        account: Optional[LocalAccount] = None,
        private_key: Optional[str] = None,
    ) -> None:
        self.chain = chain or os.environ.get(ENV_BUILDERS_CHAIN, DEFAULT_BUILDERS_CHAIN)
        if self.chain not in BUILDERS_ADDRESSES:
            raise ValueError(
                f"Unsupported chain {self.chain!r}. Use one of {list(BUILDERS_ADDRESSES)}"
            )
        self.address = Web3.to_checksum_address(BUILDERS_ADDRESSES[self.chain])
        self.mor_address = Web3.to_checksum_address(MOR_TOKEN[self.chain])

        if w3 is None:
            url = rpc_url or os.environ.get(ENV_BUILDERS_RPC)
            if url:
                w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": 30}))
                if not w3.is_connected():
                    raise ConnectionError(f"Configured RPC {url} did not respond.")
            else:
                w3 = _connect_with_fallback(self.chain)
        self.w3 = w3

        if account is None and private_key is None:
            private_key = os.environ.get(ENV_PRIVATE_KEY)
        if account is None and private_key:
            account = Account.from_key(private_key)
        self.account: Optional[LocalAccount] = account

        self.contract: Contract = w3.eth.contract(address=self.address, abi=BUILDERS_ABI)
        self.mor: Contract = w3.eth.contract(address=self.mor_address, abi=ERC20_ABI)

    # --- read ---------------------------------------------------------------
    def version(self) -> int:
        """Return the contract `version()` (V4 contracts return 4)."""
        return self.contract.functions.version().call()

    def subnet_id_of(self, name: str) -> bytes:
        """Compute the canonical bytes32 subnet id by calling `getSubnetId(name)`.

        V4's id mixes `block.chainid` and other state into the hash, so the
        same name yields different ids on Arbitrum vs Base. Always derive
        ids via this method (or directly via the contract) — never compute
        them off-chain.
        """
        return self.contract.functions.getSubnetId(name).call()

    def get_subnet(self, subnet_id: bytes) -> Optional[Subnet]:
        """Returns the Subnet struct, or None if the subnet doesn't exist."""
        result = self.contract.functions.subnets(subnet_id).call()
        # Empty subnet returns ('', 0x000…0, 0, 0, 0, 0, 0x000…0)
        admin = result[1]
        if result[0] == "" and _is_zero_address(admin):
            return None
        return Subnet(
            name=result[0],
            admin=admin,
            unused_storage_1=result[2],
            withdraw_lock_after_deposit=result[3],
            unused_storage_2=result[4],
            minimal_deposit=result[5],
            claim_admin=result[6],
        )

    def get_subnet_metadata(self, subnet_id: bytes) -> SubnetMetadata:
        result = self.contract.functions.subnetsMetadata(subnet_id).call()
        return SubnetMetadata(
            slug=result[0],
            description=result[1],
            website=result[2],
            image=result[3],
        )

    def get_subnet_data(self, subnet_id: bytes) -> SubnetData:
        """Aggregate deposit state for a subnet."""
        result = self.contract.functions.subnetsData(subnet_id).call()
        return SubnetData(
            deposited=result[1],
            rate=result[3],
            pending_rewards=result[4],
        )

    def subnet_exists(self, name: str) -> bool:
        return self.get_subnet(self.subnet_id_of(name)) is not None

    def minimal_withdraw_lock_period(self) -> int:
        """Protocol-set minimum value for `withdraw_lock_after_deposit` (seconds)."""
        return self.contract.functions.minimalWithdrawLockPeriod().call()

    def subnet_creation_fee(self) -> int:
        """MOR (in wei) required to register a new subnet. Currently 0 on
        Arbitrum + Base mainnet; non-zero on Base Sepolia."""
        return self.contract.functions.subnetCreationFeeAmount().call()

    def deposit_token(self) -> str:
        return self.contract.functions.depositToken().call()

    def fee_config(self) -> str:
        return self.contract.functions.feeConfig().call()

    def builders_treasury(self) -> str:
        return self.contract.functions.buildersTreasury().call()

    def get_user_data(self, user: str, subnet_id: bytes) -> UserSubnetData:
        result = self.contract.functions.usersData(
            Web3.to_checksum_address(user), subnet_id
        ).call()
        return UserSubnetData(last_deposit=result[0], deposited=result[2])

    def current_subnet_reward(self, subnet_id: bytes) -> int:
        """Total accrued MOR rewards for this subnet (claimable by claim-admin)."""
        return self.contract.functions.getCurrentSubnetRewards(subnet_id).call()

    def mor_balance(self, address: str) -> int:
        return self.mor.functions.balanceOf(Web3.to_checksum_address(address)).call()

    def mor_allowance_to_builders(self, owner: str) -> int:
        return self.mor.functions.allowance(
            Web3.to_checksum_address(owner), self.address
        ).call()

    # --- write --------------------------------------------------------------
    def _account(self) -> LocalAccount:
        if self.account is None:
            raise RuntimeError(
                "Write methods require a signer. Pass account= / private_key= or set "
                f"{ENV_PRIVATE_KEY}."
            )
        return self.account

    def _send(self, fn: Any, *, value: int = 0, dry_run: bool = False) -> str:
        acct = self._account()
        nonce = self.w3.eth.get_transaction_count(acct.address)
        tx = fn.build_transaction({
            "from": acct.address,
            "nonce": nonce,
            "value": value,
            "chainId": self.w3.eth.chain_id,
        })
        if dry_run:
            return tx["data"]
        signed = acct.sign_transaction(tx)
        return self.w3.eth.send_raw_transaction(signed.raw_transaction).hex()

    def approve_mor(self, amount: int, *, dry_run: bool = False) -> str:
        """Approve the Builders contract to spend `amount` MOR from your wallet.

        Required before `deposit()` and before `create_subnet()` if the
        creation fee is non-zero.
        """
        fn = self.mor.functions.approve(self.address, int(amount))
        return self._send(fn, dry_run=dry_run)

    def create_subnet(
        self,
        subnet: Subnet,
        metadata: Optional[SubnetMetadata] = None,
        *,
        auto_approve_fee: bool = True,
        dry_run: bool = False,
    ) -> str:
        """Register a new subnet. Pays the current creation fee in MOR (often 0).

        Validation (matches contract's checks):

        - `subnet.name` non-empty
        - `subnet.admin` != 0x0
        - `subnet.withdraw_lock_after_deposit` >= protocol minimum
        - subnet with same name does not already exist (on this chain)

        If `auto_approve_fee=True` and the creation fee is non-zero, this
        will also issue an ERC20 approve() for the fee amount before the
        createSubnet call. Set to False to manage approvals yourself.
        """
        if not subnet.name:
            raise ValueError("subnet.name must be non-empty")
        if _is_zero_address(subnet.admin):
            raise ValueError("subnet.admin must not be the zero address")
        try:
            min_lock = self.minimal_withdraw_lock_period()
            if subnet.withdraw_lock_after_deposit < min_lock:
                raise ValueError(
                    f"subnet.withdraw_lock_after_deposit must be >= "
                    f"protocol minimum ({min_lock} seconds, currently 7 days)"
                )
        except ValueError:
            raise
        except Exception:  # noqa: BLE001 — RPC issue, fall through to contract
            pass
        if self.subnet_exists(subnet.name):
            raise ValueError(
                f"A subnet named {subnet.name!r} already exists on {self.chain}. "
                f"Pick a different name."
            )

        if auto_approve_fee and not dry_run:
            fee = self.subnet_creation_fee()
            if fee > 0:
                acct = self._account()
                allowance = self.mor_allowance_to_builders(acct.address)
                if allowance < fee:
                    approve_hash = self.approve_mor(fee)
                    # Wait for receipt to avoid nonce-race with createSubnet.
                    self.w3.eth.wait_for_transaction_receipt(approve_hash, timeout=120)

        meta = metadata or SubnetMetadata(slug=subnet.name.lower().replace(" ", "-"))
        fn = self.contract.functions.createSubnet(subnet.to_tuple(), meta.to_tuple())
        return self._send(fn, dry_run=dry_run)

    def edit_subnet(
        self,
        subnet_id: bytes,
        new_subnet: Subnet,
        *,
        dry_run: bool = False,
    ) -> str:
        """Edit an existing subnet — admin only."""
        fn = self.contract.functions.editSubnet(subnet_id, new_subnet.to_tuple())
        return self._send(fn, dry_run=dry_run)

    def edit_subnet_metadata(
        self,
        subnet_id: bytes,
        metadata: SubnetMetadata,
        *,
        dry_run: bool = False,
    ) -> str:
        """Edit subnet metadata (slug, description, website, image) — admin only."""
        fn = self.contract.functions.editSubnetMetadata(subnet_id, metadata.to_tuple())
        return self._send(fn, dry_run=dry_run)

    def deposit(
        self,
        subnet_id: bytes,
        amount: int,
        *,
        auto_approve: bool = True,
        dry_run: bool = False,
    ) -> str:
        """Stake `amount` MOR (in wei) into the subnet.

        If `auto_approve=True`, will issue an ERC20 approve() if allowance is short.
        """
        acct = self._account()
        if auto_approve and not dry_run:
            allowance = self.mor_allowance_to_builders(acct.address)
            if allowance < amount:
                approve_hash = self.approve_mor(amount)
                # Wait for the approve receipt so the deposit gets a fresh
                # nonce. Without this, public RPCs that don't reflect pending
                # nonces immediately can race the two txs onto the same nonce
                # and the deposit fails with `nonce too low`.
                self.w3.eth.wait_for_transaction_receipt(approve_hash, timeout=120)
        fn = self.contract.functions.deposit(subnet_id, int(amount))
        return self._send(fn, dry_run=dry_run)

    def withdraw(self, subnet_id: bytes, amount: int, *, dry_run: bool = False) -> str:
        """Unstake MOR from the subnet. Subject to per-subnet withdraw lock."""
        fn = self.contract.functions.withdraw(subnet_id, int(amount))
        return self._send(fn, dry_run=dry_run)

    def claim(
        self,
        subnet_id: bytes,
        receiver: Optional[str] = None,
        *,
        dry_run: bool = False,
    ) -> str:
        """Claim accumulated MOR rewards to `receiver` (defaults to claim-admin).

        Only the subnet's `claim_admin` may successfully claim.
        """
        acct = self._account()
        recv = Web3.to_checksum_address(receiver) if receiver else acct.address
        if _is_zero_address(recv):
            recv = Web3.to_checksum_address(ZERO_ADDRESS)
        fn = self.contract.functions.claim(subnet_id, recv)
        return self._send(fn, dry_run=dry_run)


# --- Module-level helpers --------------------------------------------------
def subnet_id_of(name: str, *, chain: str = DEFAULT_BUILDERS_CHAIN) -> bytes:
    """Convenience helper that opens a read-only client and returns the
    canonical subnet id for `name` on `chain`. Same as
    `BuildersClient(chain).subnet_id_of(name)`."""
    return BuildersClient(chain=chain).subnet_id_of(name)


# Backwards-compat alias.
def pool_id_of(name: str, *, chain: str = DEFAULT_BUILDERS_CHAIN) -> bytes:
    """Deprecated V3 name — calls subnet_id_of(name)."""
    return subnet_id_of(name, chain=chain)
