"""Minimal ABIs for the Morpheus DepositPool + ERC20 token interactions.

Only the function signatures we need are encoded — keeps the package lean.
Full ABIs are at github.com/MorpheusAIs/SmartContracts.
"""

from __future__ import annotations

# Morpheus DepositPool — minimal write + view surface for staking + referrals.
DEPOSIT_POOL_ABI = [
    # stake(rewardPoolIndex, amount, claimLockEnd, referrer)
    {
        "type": "function",
        "name": "stake",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "rewardPoolIndex_", "type": "uint256"},
            {"name": "amount_", "type": "uint256"},
            {"name": "claimLockEnd_", "type": "uint128"},
            {"name": "referrer_", "type": "address"},
        ],
        "outputs": [],
    },
    # claimReferrerTier(rewardPoolIndex, receiver) — payable for LayerZero msg fee
    {
        "type": "function",
        "name": "claimReferrerTier",
        "stateMutability": "payable",
        "inputs": [
            {"name": "rewardPoolIndex_", "type": "uint256"},
            {"name": "receiver_", "type": "address"},
        ],
        "outputs": [],
    },
    # public mapping(address => mapping(uint256 => ReferrerData))
    # auto-generated getter signature
    {
        "type": "function",
        "name": "referrersData",
        "stateMutability": "view",
        "inputs": [
            {"name": "", "type": "address"},
            {"name": "", "type": "uint256"},
        ],
        "outputs": [
            {"name": "amountStaked", "type": "uint256"},
            {"name": "virtualAmountStaked", "type": "uint256"},
            {"name": "rate", "type": "uint256"},
            {"name": "pendingRewards", "type": "uint256"},
            {"name": "lastClaim", "type": "uint128"},
        ],
    },
    # public mapping(uint256 => ReferrerTier[]) — getter takes (poolIndex, tierIndex)
    {
        "type": "function",
        "name": "referrerTiers",
        "stateMutability": "view",
        "inputs": [
            {"name": "", "type": "uint256"},
            {"name": "", "type": "uint256"},
        ],
        "outputs": [
            {"name": "amount", "type": "uint256"},
            {"name": "multiplier", "type": "uint256"},
        ],
    },
    # User stake position view (via usersData mapping)
    {
        "type": "function",
        "name": "usersData",
        "stateMutability": "view",
        "inputs": [
            {"name": "", "type": "address"},
            {"name": "", "type": "uint256"},
        ],
        "outputs": [
            {"name": "lastStake", "type": "uint128"},
            {"name": "deposited", "type": "uint256"},
            {"name": "rate", "type": "uint256"},
            {"name": "virtualDeposited", "type": "uint256"},
            {"name": "pendingRewards", "type": "uint256"},
            {"name": "claimLockStart", "type": "uint128"},
            {"name": "claimLockEnd", "type": "uint128"},
            {"name": "referrer", "type": "address"},
        ],
    },
]

# Minimal ERC20 ABI (approve, balanceOf, allowance) for the underlying tokens.
ERC20_ABI = [
    {
        "type": "function",
        "name": "approve",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "spender", "type": "address"},
            {"name": "amount", "type": "uint256"},
        ],
        "outputs": [{"name": "", "type": "bool"}],
    },
    {
        "type": "function",
        "name": "allowance",
        "stateMutability": "view",
        "inputs": [
            {"name": "owner", "type": "address"},
            {"name": "spender", "type": "address"},
        ],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "balanceOf",
        "stateMutability": "view",
        "inputs": [{"name": "account", "type": "address"}],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "decimals",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint8"}],
    },
]


# Morpheus BuildersV4 — subnet creation + management + staker deposit.
#
# The proxies live at the same addresses as the prior BuildersV3 deployment
# (Arbitrum 0xC0eD68f163d44B6e9985F0041fDf6f67c6BCFF3f, Base
# 0x42BB446eAE6dca7723a9eBdb81EA88aFe77eF4B9), but `version()` now returns 4
# and the implementation has been swapped. The function set, struct shapes
# and the ID-derivation rule are all different from V3 — see SDK README.
#
# ABI extracted from dashboard.mor.org's Next.js bundle (cd0f4b6f85e323f1.js)
# on 2026-05-07 and verified against on-chain bytecode at the proxies above.
# Tuple component definitions used by createSubnet/editSubnet:
_V4_SUBNET_TUPLE = [
    {"name": "name", "type": "string"},
    {"name": "admin", "type": "address"},
    {"name": "unusedStorage1_V4Update", "type": "uint128"},
    {"name": "withdrawLockPeriodAfterDeposit", "type": "uint128"},
    {"name": "unusedStorage2_V4Update", "type": "uint128"},
    {"name": "minimalDeposit", "type": "uint256"},
    {"name": "claimAdmin", "type": "address"},
]
_V4_METADATA_TUPLE = [
    {"name": "slug", "type": "string"},
    {"name": "description", "type": "string"},
    {"name": "website", "type": "string"},
    {"name": "image", "type": "string"},
]

BUILDERS_ABI = [
    # --- writes ----------------------------------------------------------
    {
        "type": "function",
        "name": "createSubnet",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "subnet_", "type": "tuple", "components": _V4_SUBNET_TUPLE},
            {"name": "metadata_", "type": "tuple", "components": _V4_METADATA_TUPLE},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "editSubnet",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "subnetId_", "type": "bytes32"},
            {"name": "newSubnet_", "type": "tuple", "components": _V4_SUBNET_TUPLE},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "editSubnetMetadata",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "subnetId_", "type": "bytes32"},
            {"name": "metadata_", "type": "tuple", "components": _V4_METADATA_TUPLE},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "deposit",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "subnetId_", "type": "bytes32"},
            {"name": "amount_", "type": "uint256"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "withdraw",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "subnetId_", "type": "bytes32"},
            {"name": "amount_", "type": "uint256"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "claim",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "subnetId_", "type": "bytes32"},
            {"name": "receiver_", "type": "address"},
        ],
        "outputs": [],
    },
    # --- reads -----------------------------------------------------------
    {
        "type": "function",
        "name": "getSubnetId",
        "stateMutability": "view",
        "inputs": [{"name": "subnetName_", "type": "string"}],
        "outputs": [{"name": "", "type": "bytes32"}],
    },
    {
        "type": "function",
        "name": "subnets",
        "stateMutability": "view",
        "inputs": [{"name": "subnetId", "type": "bytes32"}],
        "outputs": _V4_SUBNET_TUPLE,
    },
    {
        "type": "function",
        "name": "subnetsMetadata",
        "stateMutability": "view",
        "inputs": [{"name": "subnetId", "type": "bytes32"}],
        "outputs": _V4_METADATA_TUPLE,
    },
    {
        "type": "function",
        "name": "subnetsData",
        "stateMutability": "view",
        "inputs": [{"name": "subnetId", "type": "bytes32"}],
        "outputs": [
            {"name": "unusedStorage1_V4Update", "type": "uint128"},
            {"name": "deposited", "type": "uint256"},
            {"name": "unusedStorage2_V4Update", "type": "uint256"},
            {"name": "rate", "type": "uint256"},
            {"name": "pendingRewards", "type": "uint256"},
        ],
    },
    {
        "type": "function",
        "name": "usersData",
        "stateMutability": "view",
        "inputs": [
            {"name": "user", "type": "address"},
            {"name": "subnetId", "type": "bytes32"},
        ],
        "outputs": [
            {"name": "lastDeposit", "type": "uint128"},
            {"name": "unusedStorage1_V4Update", "type": "uint128"},
            {"name": "deposited", "type": "uint256"},
            {"name": "unusedStorage2_V4Update", "type": "uint256"},
        ],
    },
    {
        "type": "function",
        "name": "getCurrentSubnetRewards",
        "stateMutability": "view",
        "inputs": [{"name": "subnetId_", "type": "bytes32"}],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "subnetCreationFeeAmount",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "minimalWithdrawLockPeriod",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "depositToken",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "feeConfig",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "buildersTreasury",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "version",
        "stateMutability": "pure",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint256"}],
    },
]
