"""Verified constants for the Morpheus capital protocol on Ethereum mainnet.

Source: github.com/MorpheusAIs/SmartContracts (v7 mainnet deploy script,
deploy/capital-protocol/v7/1_mainnet_deploy.ts) cross-checked against
gitbook.mor.org. Verified 2026-05-07.
"""

from __future__ import annotations

# --- Per-asset Morpheus DepositPool addresses (Ethereum mainnet) ---------
DEPOSIT_POOLS: dict[str, str] = {
    "USDC": "0x6cCE082851Add4c535352f596662521B4De4750E",
    "USDT": "0x3B51989212BEdaB926794D6bf8e9E991218cf116",
    "WBTC": "0xdE283F8309Fd1AA46c95d299f6B8310716277A42",
    "WETH": "0x9380d72aBbD6e0Cc45095A2Ef8c2CA87d77Cb384",
}

# --- Other capital-protocol contracts (Ethereum mainnet) -----------------
DISTRIBUTOR_V2 = "0xDf1AC1AC255d91F5f4B1E3B4Aef57c5350F64C7A"
CHAINLINK_DATA_CONSUMER = "0xd182263d06FDC463c96190005D6359CC3d3Bbc5e"
REWARD_POOL = "0xb7994dE339AEe515C9b2792831CD83f3C9D8df87"
DEPOSIT_POOL_IMPL = "0xdB10dAEF167eA2233Ba6811457dD24D676FbD670"

# --- MOR token addresses (LayerZero OFT, same balance across chains) -----
MOR_TOKEN: dict[str, str] = {
    "ethereum": "0xcBB8f1BDA10b9696c57E13BC128Fe674769DCEc0",
    "arbitrum": "0x092baadb7def4c3981454dd9c0a0d7ff07bcfc86",
    "base":     "0x7431aDa8a591C955a994a21710752EF9b882b8e3",
}

# --- Underlying ERC20 token addresses (Ethereum mainnet) -----------------
ERC20_ADDRESSES: dict[str, str] = {
    "USDC": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    "USDT": "0xdAC17F958D2ee523a2206206994597C13D831ec7",
    "WBTC": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
    "WETH": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
}

# --- Token decimals ------------------------------------------------------
DECIMALS: dict[str, int] = {
    "USDC": 6,
    "USDT": 6,
    "WBTC": 8,
    "WETH": 18,
}

# --- Default reward-pool index in DistributorV2 --------------------------
# The capital pool is index 0. (Code/compute/community pools are separate
# protocols, not via DepositPool.) Override only if you know what you're doing.
DEFAULT_REWARD_POOL_INDEX = 0

# --- Referral mechanics (per MRC 73; live values on-chain) --------------
# The on-chain `referrerTiers(rewardPoolIndex, idx)` mapping is authoritative.
# These constants are documentation only — call get_referrer_tiers() at runtime
# to read the actual tier table.
MRC73_TIER_THRESHOLDS_STETH = (1, 2.5, 25, 62.5)
MRC73_TIER_MULTIPLIERS_PCT = (3, 5, 10, 15)

# --- Zero address (used as referrer when none specified) ----------------
ZERO_ADDRESS = "0x0000000000000000000000000000000000000000"

# --- Hypnex Labs referrer (hard-coded, not overridable) ------------------
# This SDK is published by Hypnex Labs and is monetized by routing all
# MRC 73 referral rewards to the Hypnex Labs treasury. There is no override
# (no constructor arg, no env var, no per-call parameter). Callers that need
# to set their own referrer should call DepositPool.stake() directly via web3
# or write their own SDK.
HYPNEX_REFERRER = "0x22B5C0075372E743042b2d62b3D254425Eb957D8"

# Backwards-compatible alias for older imports; do not change to ZERO_ADDRESS.
HYPNEX_DEFAULT_REFERRER = HYPNEX_REFERRER

# --- Public RPC for read-only smoke tests --------------------------------
# Cloudflare's public ETH RPC has generous rate limits and is reliable for
# read-only inspection. Production callers should set ETH_RPC_URL to a paid
# provider (Alchemy / Infura / QuickNode) for any non-trivial workload.
PUBLIC_ETH_RPC = "https://eth.merkle.io"
PUBLIC_ETH_RPC_FALLBACKS = (
    "https://eth.merkle.io",
    "https://ethereum-rpc.publicnode.com",
    "https://eth.llamarpc.com",
    "https://rpc.ankr.com/eth",
    "https://cloudflare-eth.com",
)

# Address used to probe whether an RPC supports eth_call (some "free" RPCs
# connect but error on contract calls — Cloudflare being a notorious example).
# We probe with WETH balanceOf(0x0) which is a stable, cheap call.
PROBE_ADDRESS = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"  # WETH9
PROBE_CALLDATA = "0x70a082310000000000000000000000000000000000000000000000000000000000000000"

# --- Builders Protocol (V4) — separate from the capital pool -------------
# Subnet creation + staking + reward claim. Subnets are MOR-staking pools
# where the project owner ("admin") earns MOR rewards proportional to TVL.
#
# These proxy addresses originally shipped with V3, but the implementation
# has since been upgraded in place to V4 (`version()` returns 4 on both
# chains as of 2026-05-07). The function set + struct layout differ from
# V3 — see `_abi.py::BUILDERS_ABI` and `builders.py::Subnet`.
#
# Verified 2026-05-07: `version()=4`, `depositToken()=MOR`,
# `subnetCreationFeeAmount()=0` (mainnet), `minimalWithdrawLockPeriod()=7d`
# on both chains. Base Sepolia testnet builders proxy (different address)
# is at 0x6C3401D71CEd4b4fEFD1033EA5F83e9B3E7e4381 with a non-zero
# creation fee (~0.123 MOR) — useful for free dry-runs of the SDK.
BUILDERS_ADDRESSES: dict[str, str] = {
    "arbitrum": "0xC0eD68f163d44B6e9985F0041fDf6f67c6BCFF3f",
    "base":     "0x42BB446eAE6dca7723a9eBdb81EA88aFe77eF4B9",
}

# Public RPC fallbacks for the chains the Builders contract lives on.
BUILDERS_RPC_FALLBACKS: dict[str, tuple[str, ...]] = {
    "arbitrum": (
        "https://arbitrum-one-rpc.publicnode.com",
        "https://arb1.arbitrum.io/rpc",
        "https://arbitrum.llamarpc.com",
    ),
    "base": (
        "https://base-rpc.publicnode.com",
        "https://mainnet.base.org",
        "https://base.llamarpc.com",
    ),
}

BUILDERS_CHAIN_IDS: dict[str, int] = {"arbitrum": 42161, "base": 8453}

# Probe addresses (WETH on each chain) for RPC validation.
BUILDERS_PROBE_ADDRESS: dict[str, str] = {
    "arbitrum": "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
    "base":     "0x4200000000000000000000000000000000000006",
}

# Default chain to use when not specified — Base has the canonical V4 deploy
# referenced by dashboard.mor.org's subnet-creation flow. Arbitrum runs the
# same V4 implementation but the dashboard's subnet UI targets Base.
DEFAULT_BUILDERS_CHAIN = "base"

# Environment variable names for the builders client (separate from capital).
ENV_BUILDERS_CHAIN = "HYPNEX_BUILDERS_CHAIN"
ENV_BUILDERS_RPC = "HYPNEX_BUILDERS_RPC_URL"

# --- Environment variable names -----------------------------------------
ENV_RPC = "ETH_RPC_URL"
ENV_PRIVATE_KEY = "PRIVATE_KEY"
