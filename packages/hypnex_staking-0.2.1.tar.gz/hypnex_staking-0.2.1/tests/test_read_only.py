"""Read-only smoke tests against Ethereum mainnet via a public RPC.

These tests do NOT move funds and require no API key. They verify:
  - The package's hardcoded contract addresses have deployed bytecode
  - usersData / referrersData on the zero address returns zeros (sanity check)
  - At least one pool has a referrer-tier table configured

Public RPCs rate-limit; an autouse fixture paces calls to avoid 429s. Write-
method tests live in tests/test_anvil_fork.py (not run in CI).
"""

from __future__ import annotations

import time

import pytest
from web3 import Web3

from hypnex_staking import Staker
from hypnex_staking._constants import DEPOSIT_POOLS, ZERO_ADDRESS


@pytest.fixture(autouse=True)
def _pace() -> None:
    """Tiny delay so we don't hammer the public RPC across parametrized cases."""
    time.sleep(0.25)


@pytest.fixture(scope="module")
def staker() -> Staker:
    return Staker()


def test_can_connect_to_mainnet(staker: Staker) -> None:
    assert staker.w3.is_connected()
    assert staker.w3.eth.chain_id == 1, "expected Ethereum mainnet"


@pytest.mark.parametrize("asset", list(DEPOSIT_POOLS.keys()))
def test_pool_address_is_deployed(staker: Staker, asset: str) -> None:
    """Each DepositPool address should have non-empty bytecode on chain."""
    addr = staker.get_pool_address(asset)
    code = staker.w3.eth.get_code(Web3.to_checksum_address(addr))
    assert len(code) > 2, f"{asset} pool at {addr} has no bytecode"


@pytest.mark.parametrize("asset", list(DEPOSIT_POOLS.keys()))
def test_zero_address_position_is_zero(staker: Staker, asset: str) -> None:
    p = staker.get_position(ZERO_ADDRESS, asset)
    assert p.deposited == 0
    assert p.pending_rewards == 0


@pytest.mark.parametrize("asset", list(DEPOSIT_POOLS.keys()))
def test_zero_address_referrer_data_is_zero(staker: Staker, asset: str) -> None:
    d = staker.get_referrer_data(ZERO_ADDRESS, asset)
    assert d.amount_staked == 0
    assert d.virtual_amount_staked == 0


@pytest.mark.parametrize("asset", list(DEPOSIT_POOLS.keys()))
def test_referrer_tiers_call_succeeds(staker: Staker, asset: str) -> None:
    """get_referrer_tiers must not raise. The list MAY be empty on mainnet if
    the protocol owner has not yet populated tiers for this pool / index — that
    is on-chain state, not an SDK bug. When tiers exist, they must be in
    ascending threshold order.
    """
    tiers = staker.get_referrer_tiers(asset)
    assert isinstance(tiers, list)
    if tiers:
        thresholds = [t.amount_threshold for t in tiers]
        assert thresholds == sorted(thresholds), f"{asset} tiers not ascending"


def test_quote_tier_below_lowest_returns_none(staker: Staker) -> None:
    # virtual_amount_staked = 0 should fall below the lowest tier
    t = staker.quote_tier("USDC", virtual_amount_staked=0)
    assert t is None


def test_write_method_without_account_raises(staker: Staker) -> None:
    """Read-only Staker must refuse write methods."""
    with pytest.raises(RuntimeError, match="moves real funds"):
        staker.stake("USDC", amount=1.0)
