from setuptools import setup
from Cython.Build import cythonize

setup(
    name="smart-aj",
    version="0.7",
    # ext_modules=cythonize("indian_calendar/core.py"),
    packages=["smart"],

    # Eska use eda.py ko .pyd me krne ke liye, jb .pyd create ho jaaye tb comment kro.
    ext_modules=cythonize( 
        "smart/Indian_Calendar.py",
        compiler_directives={
            'language_level': "3"
        }
    ),

    install_requires=[
        "pandas",
        "skyfield"
    ],

    package_data={
        "smart": ["*.pyd"]
    },

    include_package_data=True,

    author="Ajay Sah",
    description="Indian festivals and holidays detection using Panchang & Hijri calendar. Hindus festivals are based on Panchang, Islamic festivals are based on Hijri calendar & holidays are based on common month and day.",
)