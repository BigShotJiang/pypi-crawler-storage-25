import{l as o,a as r}from"../chunks/D2X8AmeL.js";export{o as load_css,r as start};
