from enum import Enum, unique


@unique
class Symbols(str, Enum):
    """Enumeration for symbols used in the frontend."""

    CIRCLE = "●"  # filled circle symbol
    CROSS = "x"  # cross/x symbol
    SQUARE = "■"  # filled square symbol
    TRIANGLE = "▲"  # upward pointing triangle symbol
