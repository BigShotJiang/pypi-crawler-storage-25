from food_web_bifurcation_explorer.enums.colors.diverse_colors import DiverseColors
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.resolutions.layout_resolutions import LayoutResolutions


class Styles:
    """class for group for frontend style configurations."""

    # base styles
    BASE_FONT = {
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE.value,
    }

    BASE_FLEX_COL = {
        "display": "flex",
        "flexDirection": "column",
        "flexShrink": 0,
        "gap": "0px",
        "justifyContent": "flex-start",
        **BASE_FONT,
    }

    BASE_FLEX_ROW = {
        **BASE_FLEX_COL,
        "flexDirection": "row",
    }

    BASE_GRAPH = {
        "backgroundColor": "white",
        "flexShrink": 0,
        "margin": "0",
        "padding": "0",
        "overflow": "hidden",
        **BASE_FONT,
    }

    # Headers & Layouts
    MAIN_TITLE = {
        "width": f"{LayoutResolutions.DEFAULT.value * 10}px",
        "textAlign": "center",
        "WebkitTextSizeAdjust": "none",
        "textSizeAdjust": "none",
        "fontFamily": Font.FONT.value,
        "fontSize": Font.SIZE_TITLE,
    }

    DIV_CONTROL = {
        **BASE_FLEX_ROW,
        "width": f"{LayoutResolutions.DEFAULT.value * 10}px",
        "alignItems": "flex-start",
        "backgroundColor": DiverseColors.DIV_CONTROL.value,
        "borderBottom": "2px solid #ddd",
        "borderTop": "2px solid #ddd",
        "boxSizing": "border-box",
        "flexWrap": "nowrap",
        "justifyContent": "left",
    }

    # Groups & Subgroups
    GROUP_DROPDOWN = {
        **BASE_FLEX_COL,
        "margin": "0 0 0 5px",
        "maxWidth": "210px",
        "minWidth": "210px",
    }

    GROUP_EIGENVALUES = {
        **BASE_FLEX_COL,
        "margin": "0 0 0 5px",
        "maxWidth": "350px",
        "minWidth": "350px",
    }

    SUBGROUP_EIGENVALUES = {
        **BASE_FLEX_ROW,
        "margin": "0",
        "maxWidth": "350px",
        "minWidth": "350px",
    }

    GROUP_CHECKBOX = {
        **BASE_FLEX_COL,
        "margin": "0 0 0 10px",
        "maxWidth": "210px",
        "minWidth": "50px",
    }

    # Graphs Containers
    DIV_GRAPH_SCATTER_TERNARY = {
        **BASE_GRAPH,
        "width": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 2}px",
    }

    DIV_GRAPH_HEATMAP_TERNARY = {
        **BASE_GRAPH,
        "width": f"{(LayoutResolutions.DEFAULT.value * 2) + (LayoutResolutions.DEFAULT.value * 0.2)}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 2}px",
    }

    DIV_GRAPH_SCATTER_PLOT = {
        **BASE_GRAPH,
        "width": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "height": f"{LayoutResolutions.DEFAULT.value}px",
    }

    DIV_GRAPH_DISTRIBUTION_PLOT = {
        **BASE_GRAPH,
        "width": f"{LayoutResolutions.DEFAULT.value * 1.5}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 1.5}px",
    }

    # Divisors & Rows
    DIV_GRAPHS = {
        "width": f"{LayoutResolutions.DEFAULT.value * 4}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "alignItems": "flex-start",
        "backgroundColor": "white",
        "display": "flex",
        "flexDirection": "row",
        "flexWrap": "nowrap",
        "gap": "0",
        "justifyContent": "flex-start",
        "margin": "0",
        "padding": "0",
    }

    DIV_FOUR_PLOTS = {
        **BASE_FLEX_COL,
        "width": f"{LayoutResolutions.DEFAULT.value * 2}px",
        "height": f"{LayoutResolutions.DEFAULT.value * 4}px",
        "alignItems": "flex-start",
        "margin": "0",
        "padding": "0",
    }

    DIV_SMALL_ROW = {
        **BASE_FLEX_ROW,
        "width": f"{LayoutResolutions.DEFAULT.value * 4}px",
        "height": f"{LayoutResolutions.DEFAULT.value}px",
        "alignItems": "flex-start",
        "margin": "0",
        "padding": "0",
    }

    # UI Elements (Labels, Buttons, Lists)
    CHECKBOXLABEL = {
        **BASE_FONT,
        "alignItems": "center",
        "display": "inline-flex",
        "height": "2px",
    }

    BUTTON_EIGENVALUES = {
        **BASE_FONT,
        "width": "32px",
        "alignItems": "center",
        "justifyContent": "center",
        "display": "inline-flex",
        "height": "32px",
        "cursor": "pointer",
        "borderRadius": "4px",
    }

    LABEL = {
        **BASE_FONT,
        "alignItems": "center",
        "display": "flex",
        "height": "32px",
    }

    TERNARY = {
        "width": "100%",
        "height": "100%",
        "marginTop": "-10%",
        "transform": "scale(1.2)",
        "transformOrigin": "center center",
    }

    LIST = {
        "width": "100%",
        "color": "black",
    }

    PLOT = {
        "width": "100%",
        "height": "100%",
    }

    DIV_HEATMAP_NETWORK_LIST = {
        "width": "100%",
        "height": f"{LayoutResolutions.DEFAULT.value}px",
        "overflowY": "auto",
        "backgroundColor": DiverseColors.LIST_BACKGROUND.value,
        "border": "1px solid #ccc",
        "borderRadius": "5px",
        "padding": "10px",
        "marginTop": "20px",
        "boxSizing": "border-box",
    }
