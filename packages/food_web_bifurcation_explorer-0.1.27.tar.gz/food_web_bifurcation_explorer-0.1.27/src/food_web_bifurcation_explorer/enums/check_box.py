from enum import Enum, unique


@unique
class CheckBox(str, Enum):
    """Enumeration for checkbox-specific styles."""

    MARGING_LEFT = ("5px",)  # left margin for checkbox
