from enum import Enum, unique


@unique
class BifurcationCodimensionOneVisualTypes(str, Enum):
    """Enumeration for codimension one bifurcation types."""

    # bifurcations
    SADDLENODE = "saddleNode"
    TRANSCRITICAL = "transcritical"
    HOPF_SUBCRITICAL = "hopfSubcritical"
    HOPF_SUPERCRITICAL = "hopfSupercritical"
