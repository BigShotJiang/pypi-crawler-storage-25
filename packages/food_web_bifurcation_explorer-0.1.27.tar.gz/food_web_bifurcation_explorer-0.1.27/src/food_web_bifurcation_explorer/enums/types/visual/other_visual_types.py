from enum import Enum, unique


@unique
class OtherVisualTypes(str, Enum):
    """Enumeration for termination types."""

    FRONTIER = "frontier"
    INTERNAL_ERROR = "outOfParameters"
