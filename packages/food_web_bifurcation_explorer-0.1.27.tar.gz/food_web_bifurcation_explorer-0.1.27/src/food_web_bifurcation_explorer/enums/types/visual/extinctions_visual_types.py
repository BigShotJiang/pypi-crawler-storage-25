from enum import Enum, unique


@unique
class ExtinctVisualTypes(str, Enum):
    """Enumeration for extinct types."""

    EXTINCT_TRANSCRITICAL = "extinction"
    EXTINCT_EXTENDED = "extinction_extended"
