from enum import Enum, unique


@unique
class HopfParameterTypes(str, Enum):
    """Enumeration for hopf parameter types."""

    L1 = "L1"
    OSCILLATION_FREQUENCY = "oscilationFrequency"
    TRANSVERSAL_CROSSING_SPEED = "disequilibriumSpeed"
    NORMALIZATION_ERROR = "normalizationError"
