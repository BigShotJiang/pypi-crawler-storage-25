from enum import Enum, unique

from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


@unique
class ParameterTypesExtended(str, Enum):
    """Enumeration for parameter types (used loading bifurcation datas)."""

    # parameter types
    DONOR = ParameterTypes.DONOR.value
    RECIPIENT = ParameterTypes.RECIPIENT.value
    LOTKAVOLTERRA = ParameterTypes.LOTKAVOLTERRA.value
    # extra parameter types
    BIOMASS = "biomass"
    LABELS = "labels"
