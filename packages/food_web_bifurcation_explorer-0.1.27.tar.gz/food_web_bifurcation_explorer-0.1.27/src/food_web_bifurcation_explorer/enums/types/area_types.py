from enum import Enum, unique


@unique
class AreaTypes(str, Enum):
    """Enumeration for area types."""

    STABLE = "stable"
    UNSTABLE = "unstable"
