from enum import Enum, unique


@unique
class EigenValuesJump(int, Enum):
    """Enumeration for eigen values jump."""

    A = 0
    B = 1
    C = 2
    D = 3
    E = 4
