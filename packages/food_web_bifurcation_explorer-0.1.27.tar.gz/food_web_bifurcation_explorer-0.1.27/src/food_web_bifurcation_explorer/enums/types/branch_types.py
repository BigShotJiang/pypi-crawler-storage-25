from enum import Enum, unique


@unique
class BranchTypes(str, Enum):
    """Enumeration for basic branch types."""

    EMPIRICAL = "empirical"
    ALTERNATIVE = "alternative"