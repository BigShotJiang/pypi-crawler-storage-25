from enum import Enum, unique


@unique
class ParameterTypes(str, Enum):
    """Enumeration for parameter types."""

    DONOR = "sd"
    RECIPIENT = "sr"
    LOTKAVOLTERRA = "sl"
