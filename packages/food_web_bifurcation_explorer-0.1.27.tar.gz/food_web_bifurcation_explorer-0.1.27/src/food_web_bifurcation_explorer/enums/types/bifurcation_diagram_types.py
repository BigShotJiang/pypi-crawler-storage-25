from enum import Enum, unique


@unique
class BifurcationDiagramTypes(str, Enum):
    """Enumeration for plot types."""

    FIRST = "first"
    SECOND = "second"
