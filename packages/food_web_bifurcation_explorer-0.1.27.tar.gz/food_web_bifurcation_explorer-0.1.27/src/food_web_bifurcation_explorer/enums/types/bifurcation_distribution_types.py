from enum import Enum, unique


@unique
class BifurcationDistributionTypes(str, Enum):
    """Enumeration for bifurcation distribution types."""

    SD_SR = "sd_sr"
    SR_SL = "sr_sl"
    SL_SD = "sl_sd"
