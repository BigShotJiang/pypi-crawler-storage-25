from enum import Enum, unique


@unique
class StabilityColors(str, Enum):
    """Enumeration for colors used for stability"""

    # equilibrium areas
    STABLE_AREA = "rgba(0, 0, 255, 0.1)"
    UNSTABLE_AREA = "rgba(255, 0, 0, 0.1)"
    # equilibrium traces
    STABLE = "blue"
    UNSTABLE = "red"
