from enum import Enum, unique


@unique
class DiverseColors(str, Enum):
    """Enumeration for diverse colors"""

    # control wrapper
    DIV_CONTROL = "#f9f9f9"
    LIST_BACKGROUND = "#f9f9f8"
