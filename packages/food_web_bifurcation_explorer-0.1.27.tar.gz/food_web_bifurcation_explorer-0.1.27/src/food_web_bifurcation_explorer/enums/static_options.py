from food_web_bifurcation_explorer.enums.resolutions.ternary_heatmap_resolutions import TernaryHeatmapResolutions


class StaticOptions:
    # debug for dash
    DEBUG_DASH: bool = False
    # debug for drawing options
    DEBUG_DRAWING_OPTIONS: bool = False
    # generate data
    PRECACHE_ALL_TRACES: bool = False
    GENERATE_GENERAL_BIFURCATION_DATA: bool = False
    # default scatter values
    SCATTER_RESOLUTION = 6
    DEFAULT_SCATTER_COMPARTMENT_FIRST: int = 0
    DEFAULT_SCATTER_COMPARTMENT_SECOND: int = 1
    DEFAULT_SCATTER_NETWORK: str = "Baja_California_417"
    DEFAULT_SCATTER_PARAMETER_VALUE: float = 0.4
    # default heatmap values
    DEFAULT_HEATMAP_RESOLUTION: TernaryHeatmapResolutions = TernaryHeatmapResolutions.FOUR_DECIMALS
    DEFAULT_START_COLOR = "#0000CC"
    DEFAULT_END_COLOR = "#AA0000"
