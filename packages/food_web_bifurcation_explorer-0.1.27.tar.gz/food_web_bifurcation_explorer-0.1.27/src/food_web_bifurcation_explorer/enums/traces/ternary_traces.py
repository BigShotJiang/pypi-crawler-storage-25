from enum import Enum, unique


@unique
class TernaryTraces(str, Enum):
    """Enumeration for drawing trace types."""

    # envelope traces
    HOPF_ENVELOPE_BACKGROUND = "envelope background"
    # equilibria traces
    STABLE_EQUILIBRIA_AREA = "Stable equilibria area"
    UNSTABLE_EQUILIBRIA_AREA = "Unstable equilibria area"
    # equilibria traces
    STABLE_EQUILIBRIA = "Stable equilibria"
    UNSTABLE_EQUILIBRIA = "Unstable equilibria"
    # one codimension bifurcations
    HOPF_SUBCRITICAL_ALTERNATIVE = "Hopf subcritical bifurcation (alternative)"
    HOPF_SUBCRITICAL_EMPIRICAL = "Hopf subcritical bifurcation (empirical)"
    HOPF_SUPERCRITICAL_ALTERNATIVE = "Hopf supercritical bifurcation (alternative)"
    HOPF_SUPERCRITICAL_EMPIRICAL = "Hopf supercritical bifurcation (empirical)"
    SADDLENODE_ALTERNATIVE = "Saddle-node bifurcation (alternative)"
    SADDLENODE_EMPIRICAL = "Saddle-node bifurcation (empirical)"
    TRANSCRITICAL_ALTERNATIVE = "Transcritical bifurcation (alternative)"
    TRANSCRITICAL_EMPIRICAL = "Transcritical bifurcation (empirical)"
    # two codimension bifurcations
    BAUTIN = "Bautin bifurcation"
    BOGDANOV_TAKENS = "Bogdanov-takens bifurcation"
    DOUBLE_HOPF = "Double hopf bifurcation"
    # other
    EXTINCT_TRANSCRITICAL = "Extinct (transcritical)"
    EXTINCT_EXTENDED = "Extinct (extended)"
    INTERNAL_ERROR = "Internal continuation error"
