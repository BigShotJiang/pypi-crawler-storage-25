from enum import Enum, unique


@unique
class TernaryHeatmapResolutions(int, Enum):
    """Enumeration for graph resolutions."""

    ONE_DECIMAL = 1
    TWO_DECIMALS = 2
    THREE_DECIMALS = 3
    FOUR_DECIMALS = 4
