from enum import Enum, unique


@unique
class LayoutResolutions(int, Enum):
    """Enumeration for graph resolutions."""

    MINUSCULE = 50
    TINY = 100
    SMALL = 200
    DEFAULT = 400
    LARGE = 800
    HUGE = 1000
    MASSIVE = 1600
