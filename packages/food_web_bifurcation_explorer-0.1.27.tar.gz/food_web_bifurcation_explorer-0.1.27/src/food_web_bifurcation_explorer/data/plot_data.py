import os
import shutil
import threading
import zipfile

import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.common.files import BifurcationCodimensionOneVisualTypes
from food_web_bifurcation_explorer.data.branch_data import BranchData
from food_web_bifurcation_explorer.data.ternary_data import TernaryData
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_two_visual_types import BifurcationCodimensionTwoVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.other_visual_types import OtherVisualTypes


class PlotData:
    """Class to manage and store plot data for bifurcation and branch analysis."""

    def __init__(self) -> None:
        """Initialize PlotData with default values for all data structures."""
        # loading lock
        self.data_load_lock = threading.RLock()

        # ternary data
        self.ternary_data: TernaryData = TernaryData()

        # basic branch datas (empirical and alternative)
        self.branch_datas: dict[ParameterTypes, dict[BranchTypes, BranchData]] = {}

        # extended branch datas
        self.extended_branch_datas: dict[ParameterTypes, list[BranchData]] = {}

        # create elements for every branch data
        for parameter_type in ParameterTypes:

            # create basic branch types
            self.branch_datas[parameter_type] = {}
            for branch_type in BranchTypes:
                self.branch_datas[parameter_type][branch_type] = BranchData(branch_type, parameter_type)

            # create extended branch datas
            self.extended_branch_datas[parameter_type] = []
            for _ in range (0, IntegerNumbers.EXTENDED_BRANCHES_NUM_MAX):
                self.extended_branch_datas[parameter_type].append(BranchData(BranchTypes.ALTERNATIVE, parameter_type))

        # load data
        self.load_ternary_data()
        self.load_branch_datas()

    def get_num_compartments(self) -> int:
        """Get the number of compartments from food_web_bifurcation_explorer.empirical donor branch data."""
        return self.branch_datas[ParameterTypes.DONOR][BranchTypes.EMPIRICAL].n

    def load_ternary_data(self) -> None:
        """Load ternary data from food_web_bifurcation_explorer.cached files or generate from food_web_bifurcation_explorer.bifurcation data."""
        # lock load branch datas to avoid problems creating branch files
        with self.data_load_lock:
            # declare zip file path for ternary data
            data_ternary_zip_file = glob.files.get_data_ternary_zip_file()
            
            # check if we have cached files
            if os.path.exists(data_ternary_zip_file):
                # open zip file
                with zipfile.ZipFile(data_ternary_zip_file, "r") as ternary_zip_file:
                    # load ternary data from cache
                    self.ternary_data.load_parquet_data(ternary_zip_file)
            else:
                # read continuation files
                self.ternary_data.load_result_files()
                # check if create cache file
                if not os.path.exists(glob.files.get_data_folder()):
                    os.makedirs(glob.files.get_data_folder())
                # check if create network folder
                if not os.path.exists(glob.files.get_data_network_folder()):
                    os.makedirs(glob.files.get_data_network_folder())
                # create temporary directory for parquet files
                temporal_dir = os.path.join(glob.files.get_data_folder(), "temp_parquet_ternary")
                os.makedirs(temporal_dir, exist_ok=True)
                # list to store temporary file paths
                temporal_files = []
                # iterate over parameter types and branch types to read all branch data combinations
                for branch_type in BranchTypes:
                    for parameter_type in ParameterTypes:
                        # codimension one bifurcation types
                        for bifurcation_codimension_one_type in BifurcationCodimensionOneVisualTypes:
                            for index in range(IntegerNumbers.TRACES_NUM_MAX):
                                # first ensure that we have a dataframe
                                if self.ternary_data.codimension_one_bifurcation_dataframes[branch_type][parameter_type][bifurcation_codimension_one_type][index] is not None:
                                    # get parquet file
                                    codimension_one_parquet_file = glob.files.get_ternary_codimension_one_parquet_file(branch_type, parameter_type, bifurcation_codimension_one_type, index)
                                    # create temporary file paths
                                    ternary_temporal_path = os.path.join(temporal_dir, codimension_one_parquet_file)
                                    # save branch dataframe to temporary file
                                    self.ternary_data.codimension_one_bifurcation_dataframes[branch_type][parameter_type][bifurcation_codimension_one_type][index].to_parquet(
                                        ternary_temporal_path
                                    )
                                    # add to temporal files
                                    temporal_files.append((ternary_temporal_path, codimension_one_parquet_file))
            
                # excluse of alternative branches
                for parameter_type in ParameterTypes:
                    # transcritical extinctions
                    for index in range(IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                        # first ensure that we have a dataframe
                        if self.ternary_data.extinction_transcritical_dataframes[parameter_type][index] is not None:
                            # get parquet file
                            extinction_transcritical_parquet_file = glob.files.get_ternary_extinctions_transcritical_parquet_file(parameter_type, index)
                            # create temporary file paths
                            ternary_temporal_path = os.path.join(temporal_dir, extinction_transcritical_parquet_file)
                            # save branch dataframe to temporary file
                            self.ternary_data.extinction_transcritical_dataframes[parameter_type][index].to_parquet(
                                ternary_temporal_path
                            )
                            # add to temporal files
                            temporal_files.append((ternary_temporal_path, extinction_transcritical_parquet_file))

                    # other types
                    for other_type in OtherVisualTypes:
                        # first ensure that we have a dataframe
                        if self.ternary_data.other_dataframes[parameter_type][other_type] is not None:
                            # get parquet file
                            other_parquet_file = glob.files.get_ternary_other_parquet_file(parameter_type, other_type)
                            # create temporary file paths
                            ternary_temporal_path = os.path.join(temporal_dir, other_parquet_file)
                            # save branch dataframe to temporary file
                            self.ternary_data.other_dataframes[parameter_type][other_type].to_parquet(
                                ternary_temporal_path
                            )
                            # add to temporal files
                            temporal_files.append((ternary_temporal_path, other_parquet_file))

                # save codimension two files
                for bifurcation_codimension_two_type in BifurcationCodimensionTwoVisualTypes:
                    # get parquet file
                    codimension_two_parquet_file = glob.files.get_ternary_codimension_two_parquet_file(bifurcation_codimension_two_type)

                    ## CHECK DUPLICATED os.path.join(temporal_dir, codimension_two_parquet_file)

                    # save parquet file
                    self.ternary_data.codimension_two_bifurcation_dataframes[bifurcation_codimension_two_type].to_parquet(os.path.join(temporal_dir, codimension_two_parquet_file))
                    # add to temporal files
                    temporal_files.append((os.path.join(temporal_dir, codimension_two_parquet_file), codimension_two_parquet_file))

                # save extended extinctions
                for parameter_type in ParameterTypes:
                    # get parquet file
                    extended_extinction_parquet_file = glob.files.get_ternary_extinctions_extended_parquet_file(parameter_type)
                    # save parquet file
                    self.ternary_data.extinction_extended_dataframes[parameter_type].to_parquet(os.path.join(temporal_dir, extended_extinction_parquet_file))
                    # add to temporal files
                    temporal_files.append((os.path.join(temporal_dir, extended_extinction_parquet_file), extended_extinction_parquet_file))

                # save shape file
                for area_type in AreaTypes:
                    # get perimeter parquet file
                    perimeter_parquet_file = glob.files.get_ternary_shape_file(area_type)
                    # save parquet file
                    self.ternary_data.shape_data.perimeters[area_type].to_parquet(os.path.join(temporal_dir, perimeter_parquet_file))
                    # add to temporal files
                    temporal_files.append((os.path.join(temporal_dir, perimeter_parquet_file), perimeter_parquet_file))

                # create zip file with all parquet files
                with zipfile.ZipFile(data_ternary_zip_file, "w", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
                    for temporal_path, archive_name in temporal_files:
                        data_zip_file.write(temporal_path, archive_name)

                # remove temporary directory
                shutil.rmtree(temporal_dir)

    def load_branch_datas(self, precache: bool = True) -> None:
        """Load branch data from cached files or read from zip files."""
        # lock load branch datas to avoid problems creating branch files
        with self.data_load_lock:
            
            # iterate over parameter types
            for parameter_type in ParameterTypes:
                
                # reset basic branch datas
                for branch_type in BranchTypes:
                    self.branch_datas[parameter_type][branch_type].clear_data()
                    self.branch_datas[parameter_type][branch_type].fixed_parameter_value = glob.config.fixed_parameter_value_str
                
                # reset extended branch datas
                for i in range (0, IntegerNumbers.EXTENDED_BRANCHES_NUM_MAX):
                    self.extended_branch_datas[parameter_type][i].clear_data()
                    self.extended_branch_datas[parameter_type][i].fixed_parameter_value = glob.config.fixed_parameter_value_str
            
            # get zip file in wich have to be stored the branch data for the current fixed parameter value
            branch_zip_file_path = glob.files.get_data_branch_zip_file(glob.config.fixed_parameter_value_str)
            
            # check if zip file exists
            if os.path.exists(branch_zip_file_path):
                
                # open zip file
                with zipfile.ZipFile(branch_zip_file_path, "r") as branch_zip_file:
                    
                    # get zip files
                    zip_files = set(branch_zip_file.namelist())

                    # iterate over parameter types
                    for parameter_type in ParameterTypes:
                        
                        # load parquet files related with basic branches
                        for branch_type in BranchTypes:
                            
                            # load branch parquet file from zip
                            parquet_file = glob.files.get_branch_parquet_file(parameter_type, branch_type, glob.config.fixed_parameter_value_str)
                            if parquet_file in zip_files:
                                with branch_zip_file.open(parquet_file) as f:
                                    self.branch_datas[parameter_type][branch_type].branch_dataframe = pd.read_parquet(f)
                            
                            # load bifurcation parquet file from zip
                            parquet_file = glob.files.get_bifurcation_parquet_file(parameter_type, branch_type, glob.config.fixed_parameter_value_str)
                            if parquet_file in zip_files:
                                with branch_zip_file.open(parquet_file) as f:
                                    self.branch_datas[parameter_type][branch_type].bifurcations_dataframe = pd.read_parquet(f)
                            
                            # process data
                            self.branch_datas[parameter_type][branch_type].process_data()

                        # load parquet files related with extended branches
                        for i in range (0, IntegerNumbers.EXTENDED_BRANCHES_NUM_MAX):

                            # load branch parquet file from zip
                            parquet_file = glob.files.get_extended_branch_parquet_file(parameter_type, glob.config.fixed_parameter_value_str, i)
                            if parquet_file in zip_files:
                                with branch_zip_file.open(parquet_file) as f:
                                    self.extended_branch_datas[parameter_type][i].branch_dataframe = pd.read_parquet(f)

                            # process data
                            self.extended_branch_datas[parameter_type][i].process_data()

            elif precache:
                # precache all branch data
                print("Precaching branch data...")
                
                # check if create cache folders
                if not os.path.exists(glob.files.get_data_folder()):
                    os.makedirs(glob.files.get_data_folder())
                if not os.path.exists(glob.files.get_data_network_folder()):
                    os.makedirs(glob.files.get_data_network_folder())
                
                # continue depending if we want to precache all traces
                if glob.static_options.PRECACHE_ALL_TRACES:
                    fixed_parameter_values = glob.config.fixed_parameter_values_str
                else:
                    fixed_parameter_values = [glob.config.fixed_parameter_value_str]
                
                # iterate over every fixed parameter value
                for fixed_parameter_value in fixed_parameter_values:
                    
                    # show info
                    print(fixed_parameter_value)
                    
                    # get continuation zip file
                    continuation_zip_file_path: str = glob.files.get_continuation_current_zip_file(fixed_parameter_value)
                    
                    # check if file exist
                    if os.path.isfile(continuation_zip_file_path):
                        
                        # open zip file
                        with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                            
                            # create temporary directory for parquet files
                            temporal_dir = os.path.join(glob.files.get_data_folder(), "temp_parquet_branch")
                            os.makedirs(temporal_dir, exist_ok=True)
                            
                            # list to store temporary file paths
                            temporal_files = []
                            
                            # iterate over parameter types
                            for parameter_type in ParameterTypes:

                                # load basic branch data
                                for branch_type in BranchTypes:
                                    
                                    # read basic branch data
                                    self.branch_datas[parameter_type][branch_type].read_branch_data(continuation_zip_file, parameter_type, fixed_parameter_value)
                                    
                                    # get file names
                                    branch_parquet_file = glob.files.get_branch_parquet_file(parameter_type, branch_type, fixed_parameter_value)
                                    bifurcation_parquet_file = glob.files.get_bifurcation_parquet_file(parameter_type, branch_type, fixed_parameter_value)
                                    
                                    # create temporary file paths
                                    branch_temporal_path = os.path.join(temporal_dir, branch_parquet_file)
                                    bifurcation_temporal_path = os.path.join(temporal_dir, bifurcation_parquet_file)
                                    
                                    # save branch dataframe to temporary file
                                    self.branch_datas[parameter_type][branch_type].branch_dataframe.to_parquet(branch_temporal_path)
                                    temporal_files.append((branch_temporal_path, branch_parquet_file))
                                    
                                    # save bifurcation dataframe to temporary file
                                    self.branch_datas[parameter_type][branch_type].bifurcations_dataframe.to_parquet(bifurcation_temporal_path)
                                    temporal_files.append((bifurcation_temporal_path, bifurcation_parquet_file))
                            
                    # get continuation zip file
                    branches_extended_zip_file_path: str = glob.files.get_branches_extended_current_zip_file(fixed_parameter_value)

                    # check if file exist
                    if os.path.isfile(branches_extended_zip_file_path):
                        
                        # open zip file
                        with zipfile.ZipFile(branches_extended_zip_file_path, "r") as branches_extended_zip_file:

                            # iterate over parameter types
                            for parameter_type in ParameterTypes:

                                # load extended branch data
                                for i in range (0, IntegerNumbers.EXTENDED_BRANCHES_NUM_MAX):
                                    
                                    # read basic branch data
                                    self.extended_branch_datas[parameter_type][i].read_extended_branch_data(branches_extended_zip_file, parameter_type, fixed_parameter_value, i)
                                    
                                    # get file names
                                    extended_branch_parquet_file = glob.files.get_extended_branch_parquet_file(parameter_type, fixed_parameter_value, i)
                                    
                                    # create temporary file paths
                                    extended_branch_temporal_path = os.path.join(temporal_dir, extended_branch_parquet_file)
                                    
                                    # save branch dataframe to temporary file
                                    self.extended_branch_datas[parameter_type][i].branch_dataframe.to_parquet(extended_branch_temporal_path)
                                    temporal_files.append((extended_branch_temporal_path, extended_branch_parquet_file))

                    # create zip file with all parquet files
                    with zipfile.ZipFile(glob.files.get_data_branch_zip_file(fixed_parameter_value), "w", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
                        for temporal_path, archive_name in temporal_files:
                            data_zip_file.write(temporal_path, archive_name)
                            
                    # remove temporary directory
                    shutil.rmtree(temporal_dir)
                
                # finally call again this function to load the desired fixed parameter value
                self.load_branch_datas(False)
