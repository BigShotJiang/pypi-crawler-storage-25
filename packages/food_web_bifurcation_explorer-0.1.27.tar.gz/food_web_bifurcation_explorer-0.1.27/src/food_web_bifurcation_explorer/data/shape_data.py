import copy
import zipfile

import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.area_types import AreaTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class ShapeData:
    def __init__(self) -> None:
        # declare perimeters
        self.perimeters: dict[AreaTypes, pd.DataFrame] = {}
        for area_type in AreaTypes:
            self.perimeters[area_type] = pd.DataFrame()
        # create a left and right vertex of the perimeter for each area type
        self.left_vertex: list[list[float]] = [[], [], []]
        self.right_vertex: list[list[float]] = [[], [], []]
        # iterate over both grid and set the left and right vertex for each area type
        for sl in glob.config.fixed_parameter_values:
            # set left and right vertex
            self.left_vertex[0].append(float(1 - sl))
            self.left_vertex[1].append(0)
            self.left_vertex[2].append(float(sl))
            self.right_vertex[0].append(0)
            self.right_vertex[1].append(float(1 - sl))
            self.right_vertex[2].append(float(sl))
        # set vertex stable
        self.left_vertex_stable = copy.deepcopy(self.left_vertex)
        self.right_vertex_stable = copy.deepcopy(self.right_vertex)
        # we assume that the full system is stable, and therefore we put the stable and unstable hidden
        self.left_vertex_unstable = copy.deepcopy(self.right_vertex)
        self.right_vertex_unstable = copy.deepcopy(self.right_vertex)

    def load_shape_data(self, index: int, fixed_parameter_value: str) -> None:
        """Read branch data using Pandas vectorization and store 3D points."""
        try:
            with zipfile.ZipFile(glob.files.get_continuation_current_zip_file(fixed_parameter_value), "r") as zip_file:
                try:
                    with zip_file.open(
                        f"bifurcations_{BranchTypes.EMPIRICAL.value}_{ParameterTypes.LOTKAVOLTERRA.value}_{fixed_parameter_value}.csv"
                    ) as file:
                        # read bifurcation dataframe
                        dataframe = pd.read_csv(file)
                        # Take the first frontier
                        condition = (dataframe["type"] == "frontier") & (dataframe["index"] == 1)
                        # get sd, sr, sl values (this value mark the frontier)
                        sd_value = dataframe.loc[condition, "sd"].item()
                        sr_value = dataframe.loc[condition, "sr"].item()
                        sl_value = dataframe.loc[condition, "sl"].item()
                        # update values in vertex list
                        self.right_vertex_stable[0][index] = sd_value
                        self.right_vertex_stable[1][index] = sr_value
                        self.right_vertex_stable[2][index] = sl_value
                        self.left_vertex_unstable[0][index] = sd_value
                        self.left_vertex_unstable[1][index] = sr_value
                        self.left_vertex_unstable[2][index] = sl_value
                except Exception:
                    pass
        except Exception:
            pass

    def process_shape_data(self) -> None:
        # transform to pandas
        perimeter_stable: pd.DataFrame = pd.DataFrame(
            {
                "sd": self.left_vertex_stable[0] + self.right_vertex_stable[0][::-1],
                "sr": self.left_vertex_stable[1] + self.right_vertex_stable[1][::-1],
                "sl": self.left_vertex_stable[2] + self.right_vertex_stable[2][::-1],
            }
        )
        perimeter_unstable: pd.DataFrame = pd.DataFrame(
            {
                "sd": self.left_vertex_unstable[0] + self.right_vertex_unstable[0][::-1],
                "sr": self.left_vertex_unstable[1] + self.right_vertex_unstable[1][::-1],
                "sl": self.left_vertex_unstable[2] + self.right_vertex_unstable[2][::-1],
            }
        )
        # close both perimeter
        self.perimeters[AreaTypes.STABLE] = pd.concat([perimeter_stable, perimeter_stable.iloc[[0]]], ignore_index=True)
        self.perimeters[AreaTypes.UNSTABLE] = pd.concat([perimeter_unstable, perimeter_unstable.iloc[[0]]], ignore_index=True)

    def get_perimeter_coordinates(self, area_type: AreaTypes) -> tuple[list[float], list[float], list[float]]:
        """Retrieve sd, sr, sl coordinates for the perimeter."""
        if self.perimeters[area_type].empty:
            return ([], [], [])
        return (self.perimeters[area_type]["sd"].tolist(), self.perimeters[area_type]["sr"].tolist(), self.perimeters[area_type]["sl"].tolist())
