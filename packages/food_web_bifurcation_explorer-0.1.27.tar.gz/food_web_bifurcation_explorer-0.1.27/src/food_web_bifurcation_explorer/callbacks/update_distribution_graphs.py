import plotly.graph_objects as go
from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.graph.bifurcation_distribution.update import update_bifurcation_distribution


# callback to update graphs
@callback(
    # outputs
    [
        Output(IDs.FIGURE_DISTRIBUTION_SD_SR, "figure"),
        Output(IDs.FIGURE_DISTRIBUTION_SR_SL, "figure"),
        Output(IDs.FIGURE_DISTRIBUTION_SL_SD, "figure"),
    ],
    # inputs
    [
        # heatmap options
        Input(IDs.TEXTFIELD_DISTRIBUTION_NUM_BINS, "value"),
        Input(IDs.TEXTFIELD_DISTRIBUTION_NUM_CONTOURS, "value"),
        Input(IDs.TEXTFIELD_DISTRIBUTION_USE_CONTOURS, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_LOGARITHMIC, "value"),
        # codimension one bifurcations
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        # codimension two bifurcations
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_BAUTIN, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_BOGDANOV_TAKENS, "value"),
        Input(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_DOUBLE_HOPF, "value"),
    ],
    # running
    running=[
        # Distribution options
        (Output(IDs.TEXTFIELD_DISTRIBUTION_NUM_BINS, "disabled"), True, False),
        (Output(IDs.TEXTFIELD_DISTRIBUTION_NUM_CONTOURS, "disabled"), True, False),
        (Output(IDs.TEXTFIELD_DISTRIBUTION_USE_CONTOURS, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_LOGARITHMIC, "disabled"), True, False),
        # codimension one bifurcations
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "disabled"), True, False),
        # codimension two bifurcations
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_BAUTIN, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_BOGDANOV_TAKENS, "disabled"), True, False),
        (Output(IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_DOUBLE_HOPF, "disabled"), True, False),
    ],
)
# update heatmap graph
def update_distribution_graphs(
    bifurcation_distribution_num_bins: int,
    bifurcation_distribution_num_contours: int,
    bifurcation_distribution_use_contours: list[bool],
    bifurcation_distribution_logarithmic: list[bool],
    # codimension one bifurcations
    bifurcations_saddlenode_empirical: list[bool],
    bifurcations_saddlenode_alternative: list[bool],
    bifurcations_transcritical_empirical: list[bool],
    bifurcations_transcritical_alternative: list[bool],
    bifurcations_hopf_subcritical_empirical: list[bool],
    bifurcations_hopf_subcritical_alternative: list[bool],
    bifurcations_hopf_supercritical_empirical: list[bool],
    bifurcations_hopf_supercritical_alternative: list[bool],
    # codimension two bifurcations
    bifurcations_bautin: list[bool],
    bifurcations_bogdanov_takens: list[bool],
    bifurcations_double_hopf: list[bool],
) -> tuple[go.Figure, go.Figure, go.Figure]:

    # update hetmap options
    glob.config.bifurcation_distribution_num_bins = bifurcation_distribution_num_bins
    glob.config.bifurcation_distribution_num_contours = bifurcation_distribution_num_contours
    glob.config.bifurcation_distribution_use_contours = bool(bifurcation_distribution_use_contours)
    glob.config.bifurcation_distribution_logarithmic = bool(bifurcation_distribution_logarithmic)

    # update only bifurcation flags
    glob.config.drawing_options.update_distribution_flags(
        bool(bifurcations_saddlenode_empirical),
        bool(bifurcations_saddlenode_alternative),
        bool(bifurcations_transcritical_empirical),
        bool(bifurcations_transcritical_alternative),
        bool(bifurcations_hopf_subcritical_empirical),
        bool(bifurcations_hopf_subcritical_alternative),
        bool(bifurcations_hopf_supercritical_empirical),
        bool(bifurcations_hopf_supercritical_alternative),
        bool(bifurcations_bautin),
        bool(bifurcations_bogdanov_takens),
        bool(bifurcations_double_hopf),
    )

    # update bifurcation distributions
    for bifurcation_distribution_type in BifurcationDistributionTypes:
        glob.figures.bifurcation_distribution[bifurcation_distribution_type] = update_bifurcation_distribution(bifurcation_distribution_type)
    # return all figures
    return (
        # bifurcation distributions
        glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SD_SR],
        glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SR_SL],
        glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SL_SD],
    )
