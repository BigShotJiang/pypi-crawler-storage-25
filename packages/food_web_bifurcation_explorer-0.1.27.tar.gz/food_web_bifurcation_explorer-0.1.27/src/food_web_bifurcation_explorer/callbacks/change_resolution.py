from dash import Input, Output, Patch, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.ids import IDs


# callback to change resolution
@callback(
    # outputs
    Output(IDs.DROPDOWN_SCATTER_SIZE, "value"),
    Output(IDs.FIGURE_SCATTER_TERNARY, "figure", allow_duplicate=True),
    Output(IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_FIRST, "figure", allow_duplicate=True),
    Output(IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_SECOND, "figure", allow_duplicate=True),
    Output(IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL, "figure", allow_duplicate=True),
    Output(IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE, "figure", allow_duplicate=True),
    Output(IDs.DIV_SCATTER_BIFURCATION_DIAGRAM_FIRST, "style"),
    Output(IDs.DIV_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL, "style"),
    Output(IDs.DIV_SCATTER_BIFURCATION_DIAGRAM_SECOND, "style"),
    Output(IDs.DIV_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE, "style"),
    Output(IDs.DIV_DISTRIBUTION_SD_SR, "style"),
    Output(IDs.DIV_DISTRIBUTION_SR_SL, "style"),
    Output(IDs.DIV_DISTRIBUTION_SL_SD, "style"),
    Output(IDs.DIV_MATRIX_01, "style"),
    Output(IDs.DIV_MATRIX_02, "style"),
    Output(IDs.DIV_SCATTER_FOUR_PLOTS_ROW, "style"),
    Output(IDs.DIV_SCATTER_ROW_PLOTS_A, "style"),
    Output(IDs.DIV_SCATTER_ROW_PLOTS_B, "style"),
    Output(IDs.DIV_SCATTER_TERNARY, "style"),
    # inputs
    Input(IDs.DROPDOWN_SCATTER_SIZE, "value"),
    # we don't need an initial call
    prevent_initial_call=True,
)

# change resolution
def change_resolution(size: int):
    # update resolution in config
    glob.config.resolution = size
    # declare patch for ternary
    patched_ternary = Patch()
    patched_ternary["layout"]["width"] = size * 2
    patched_ternary["layout"]["height"] = size * 2
    # declare patch for plots
    patched_plot = Patch()
    patched_plot["layout"]["width"] = size * 2
    patched_plot["layout"]["height"] = size
    # get div styles
    div_graph_plot = Styles.DIV_GRAPH_SCATTER_PLOT
    div_graphs = Styles.DIV_GRAPHS
    div_right_panel = Styles.DIV_FOUR_PLOTS
    div_small_row = Styles.DIV_SMALL_ROW
    div_ternary_graph = Styles.DIV_GRAPH_SCATTER_TERNARY
    # update styles
    div_graph_plot["width"] = f"{size * 2}px"
    div_graph_plot["height"] = f"{size}px"
    div_graphs["width"] = f"{size * 4}px"
    div_graphs["height"] = f"{size * 2}px"
    div_right_panel["width"] = f"{size * 2}px"
    div_right_panel["height"] = f"{size * 4}px"
    div_small_row["width"] = f"{size * 2}px"
    div_small_row["height"] = f"{size}px"
    div_ternary_graph["width"] = f"{size * 2}px"
    div_ternary_graph["height"] = f"{size * 2}px"
    # return values
    return (
        size,
        patched_ternary,
        patched_plot,
        patched_plot,
        patched_plot,
        patched_plot,
        patched_plot,
        patched_plot,
        patched_plot,
        patched_plot,
        div_graph_plot,
        div_graph_plot,
        div_graph_plot,
        div_graph_plot,
        div_graph_plot,
        div_graphs,
        div_right_panel,
        div_small_row,
        div_small_row,
        div_ternary_graph,
    )
