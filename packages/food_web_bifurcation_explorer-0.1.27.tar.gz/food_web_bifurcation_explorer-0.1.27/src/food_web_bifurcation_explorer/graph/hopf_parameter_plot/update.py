import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_one_visual_types import BifurcationCodimensionOneVisualTypes


def update_hopf_parameter_plot(hopf_parameter_type: HopfParameterTypes, hopf_parameter_name: Labels, hopf_parameter_unit: Labels) -> go.Figure:
    # get figure
    fig: go.Figure = glob.figures.hopf_parameters[hopf_parameter_type]

    # check if redraw is needed
    if glob.config.drawing_options.redraw_hopf_bifurcation[hopf_parameter_type]:
        # update both traces
        for hopf_bifurcation in [BifurcationCodimensionOneVisualTypes.HOPF_SUBCRITICAL, BifurcationCodimensionOneVisualTypes.HOPF_SUPERCRITICAL]:
            fig.update_traces(
                selector={"name": hopf_bifurcation.value},
                x=glob.config.fixed_parameter_values,
                y=glob.plot_data.ternary_data.get_hopf_parameter_values(hopf_parameter_type, hopf_bifurcation),
                hovertemplate=(
                    hopf_parameter_type.value
                    + " ("
                    + hopf_bifurcation.value
                    + ")"
                    + "<br>"
                    + "Parameter: %{x}<br>"
                    + "Value: %{y:.10f} "
                    + hopf_parameter_unit.value
                    + " <extra></extra>"
                ),
            )
        glob.config.drawing_options.redraw_hopf_bifurcation[hopf_parameter_type] = False

    # remove old shapes
    if fig.layout.shapes:
        fig.layout.shapes = tuple(s for s in fig.layout.shapes if not (s.type == "line" and s.x0 == s.x1))

    # remove old anotations
    if fig.layout.annotations:
        fig.layout.annotations = tuple(a for a in fig.layout.annotations if a.text != Labels.CURRENT_LOTKA_VOLTERRA.value)

    # add only the vertical line if we selected the lotka-volterra parameter
    if glob.config.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
        fig.add_vline(
            x=glob.config.fixed_parameter_value,
            line_dash="dash",
            line_color="black",
            annotation_text=Labels.CURRENT_LOTKA_VOLTERRA.value,
            annotation_position="top right",
        )

    # update layout
    fig.update_layout(
        title="Evolution of " + hopf_parameter_name + " (" + hopf_parameter_unit + ")",
        xaxis_title=Labels.PARAMETERS_RANGE,
        yaxis_title=hopf_parameter_unit,
    )
    return fig
