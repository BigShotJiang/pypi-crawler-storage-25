from food_web_bifurcation_explorer.enums.labels import Labels


def ternary_hover_template(title: str, resolution: int, show: bool) -> str | None:
    if show:
        return (
            f"{title}<br>"
            + f"{Labels.DONOR_CONTROL.value}: %{{b:.{resolution}f}}<br>"
            + f"{Labels.RECIPIENT_CONTROL.value}: %{{c:.{resolution}f}}<br>"
            + f"{Labels.LOTKAVOLTERRA_CONTROL.value}: %{{a:.{resolution}f}}<br>"
            + "<extra></extra>"
        )
    return None
