import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.enums.labels import Labels


def add_ternary_arrows(fig: go.Figure) -> go.Figure:
    # sd tip coordinates
    sd_tip_x = 0
    sd_tip_y = 0.2

    # sd tail coordinates
    sd_tail_x = 0.375
    sd_tail_y = 0.866

    # draw sd arrow
    fig.add_annotation(
        x=sd_tip_x,
        y=sd_tip_y,
        ax=sd_tail_x,
        ay=sd_tail_y,
        xref="x",
        yref="y",
        axref="x",
        ayref="y",
        showarrow=True,
        arrowhead=2,
        arrowwidth=1.5,
    )

    # draw sd text
    fig.add_annotation(
        x=(sd_tip_x + sd_tail_x) / 2,
        y=(sd_tip_y + sd_tail_y) / 2,
        text=Labels.DONOR_CONTROL_STRENGTH,
        showarrow=False,
        xref="x",
        yref="y",
        textangle=-60,
        font={"size": 15},
        bgcolor="white",
        opacity=1,
    )

    # sl tip coordinates
    sl_tip_x = 0.625
    sl_tip_y = 0.866

    # sl tail coordinates
    sl_tail_x = 1
    sl_tail_y = 0.2

    # draw sl arrow
    fig.add_annotation(
        x=sl_tip_x,
        y=sl_tip_y,
        ax=sl_tail_x,
        ay=sl_tail_y,
        xref="x",
        yref="y",
        axref="x",
        ayref="y",
        showarrow=True,
        arrowhead=2,
        arrowwidth=1.5,
    )

    # draw sl text
    fig.add_annotation(
        x=(sl_tip_x + sl_tail_x) / 2,
        y=(sl_tip_y + sl_tail_y) / 2,
        text=Labels.LOTKAVOLTERRA_CONTROL_STRENGTH,
        showarrow=False,
        xref="x",
        yref="y",
        textangle=60,
        font={"size": 15},
        bgcolor="white",
        opacity=1,
    )

    # sr tip coordinates
    sr_tip_x = 0.9
    sr_tip_y = 0

    # sr tail coordinates
    sr_tail_x = 0.1
    sr_tail_y = 0

    # draw sr arrow
    fig.add_annotation(
        x=sr_tip_x,
        y=sr_tip_y,
        ax=sr_tail_x,
        ay=sr_tail_y,
        xref="x",
        yref="y",
        axref="x",
        ayref="y",
        showarrow=True,
        arrowhead=2,
        arrowwidth=1.5,
    )

    # draw sr text
    fig.add_annotation(
        x=(sr_tip_x + sr_tail_x) / 2,
        y=(sr_tip_y + sr_tail_y) / 2,
        text=Labels.RECIPIENT_CONTROL_STRENGTH,
        showarrow=False,
        xref="x",
        yref="y",
        textangle=0,
        font={"size": 15},
        bgcolor="white",
        opacity=1,
    )
    return fig
