from typing import Any


class TernaryCoordinate:
    def __init__(self) -> None:
        """Ternary coordiantes sd-sr-sl"""
        self.sd: float | None = None
        self.sr: float | None = None
        self.sl: float | None = None

    def update_coordinate(self, click_data: dict[str, Any]):
        """Update coordinates receiving a click data"""
        if click_data is None:
            self.sd = None
            self.sr = None
            self.sl = None
        else:
            point = click_data["points"][0]
            self.sd = float(point.get("b", 0.0))
            self.sr = float(point.get("c", 0.0))
            self.sl = float(point.get("a", 0.0))
