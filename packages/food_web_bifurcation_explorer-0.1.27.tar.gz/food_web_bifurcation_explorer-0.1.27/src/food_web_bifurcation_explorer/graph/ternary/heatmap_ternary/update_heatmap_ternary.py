import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.graph.ternary.add_ternary_arrows import add_ternary_arrows
from food_web_bifurcation_explorer.graph.ternary.ternary_hover_template import ternary_hover_template


def add_heatmap_legend(fig: go.Figure, block_counts: dict[int, int]) -> go.Figure:
    """Add color legend"""
    # position
    legend_x0 = 1.00
    legend_x1 = 1.04
    legend_y0 = 0.05
    legend_y1 = 0.9
    block_height = (legend_y1 - legend_y0) / IntegerNumbers.HEATMAP_COLOR_NUMBER

    shapes_legend = []
    annotations_legend = []

    for index in range(IntegerNumbers.HEATMAP_COLOR_NUMBER):
        color_index = IntegerNumbers.HEATMAP_COLOR_NUMBER - 1 - index
        color = glob.config.heatmap_colors[color_index]
        y_top = legend_y1 - index * block_height
        y_bottom = y_top - block_height
        y_mid = (y_top + y_bottom) / 2

        # rectangle color
        shapes_legend.append(
            dict(
                type="rect",
                xref="paper",
                yref="paper",
                x0=legend_x0,
                x1=legend_x1,
                y0=y_bottom,
                y1=y_top,
                fillcolor=color,
                line={"width": 0},
            )
        )

        # add annotations
        count = block_counts.get(color_index, 0)
        annotations_legend.append(
            dict(
                xref="paper",
                yref="paper",
                x=legend_x1 + 0.01,
                y=y_mid,
                text=f"{color_index + 1} ({count:,})",
                showarrow=False,
                font={"size": 9, "color": "black"},
                xanchor="left",
                yanchor="middle",
                textangle=0,
            )
        )

    # legend title
    annotations_legend.append(
        dict(
            xref="paper",
            yref="paper",
            x=(legend_x0 + legend_x1) / 2,
            y=legend_y1 + 0.03,
            text="<b>N</b>",
            showarrow=False,
            font={"size": 11, "color": "black"},
            xanchor="center",
            yanchor="bottom",
            textangle=0,
        )
    )

    # update layout
    fig.update_layout(
        shapes=shapes_legend,
        annotations=annotations_legend,
        margin={
            "r": (glob.config.resolution * 0.4),
        },
    )

    # add ternary arrows
    fig = add_ternary_arrows(fig)

    # return ternary heatmap figure
    return fig


def update_heatmap_ternary() -> tuple[go.Figure, list[str]]:
    # get ternary
    ternary: go.Figure = glob.figures.heatmap_ternary

    # get grid data for the current resolution
    dataframe_grid = glob.heatmap_ternary_data.data[glob.config.ternary_heatmap_resolution]

    # get enabled bifurcations
    enabled_bifurcations = glob.config.drawing_options.bifurcation_heatmap_ternary.get_enabled_bifurcations()

    # build column names to sum based on enabled bifurcations
    expected_columns = []
    for b in enabled_bifurcations[0]:  # EMPIRICAL bifurcations
        expected_columns.append(f"{BranchTypes.EMPIRICAL.value}_{b.value}")
    for b in enabled_bifurcations[1]:  # ALTERNATIVE bifurcations
        expected_columns.append(f"{BranchTypes.ALTERNATIVE.value}_{b.value}")

    # get existent bifurcation columns
    bifurcation_columns = [col for col in expected_columns if col in dataframe_grid.columns]

    # create a copy of the grid dataframe to avoid modifying the original one
    dataframe_combined = dataframe_grid.copy()

    # calculate total counts de las bifurcaciones ACTIVAS para cada red
    if bifurcation_columns:
        dataframe_combined["total_counts"] = dataframe_combined[bifurcation_columns].sum(axis=1)
    else:
        dataframe_combined["total_counts"] = 0

    # AGRUPAR PARA EL HEATMAP
    heatmap_df = dataframe_combined.groupby(["sd", "sr", "sl"])["total_counts"].sum().reset_index()

    # Aplicar filtro mínimo después del groupby
    heatmap_df = heatmap_df[heatmap_df["total_counts"] >= glob.config.heatmap_ternary_min_value]

    # SACAR LAS REDES VISIBLES (solo las de puntos que superaron el mínimo agrupado)
    visible_networks = []
    if "networks" in dataframe_combined.columns:
        surviving_points = heatmap_df[["sd", "sr", "sl"]]
        active_networks_df = dataframe_combined.merge(surviving_points, on=["sd", "sr", "sl"], how="inner")
        unique_nets = active_networks_df["networks"].dropna().unique()
        visible_networks = sorted([net for net in unique_nets if net])

        # Filtro adicional: si hay coordenada clickeada, solo redes en ese punto
        coord = glob.config.heatmap_clicked_coordinate
        if coord is not None and coord.sd is not None and coord.sr is not None and coord.sl is not None:
            clicked_networks_df = active_networks_df[
                (active_networks_df["sd"] == coord.sd) & (active_networks_df["sr"] == coord.sr) & (active_networks_df["sl"] == coord.sl)
            ]
            unique_nets = clicked_networks_df["networks"].dropna().unique()
            visible_networks = sorted([net for net in unique_nets if net])

    # update color gradient here (to avoid inconsistences)
    glob.config.update_color_gradient()

    # block counts
    block_counts: dict[int, int] = {}

    for index in range(IntegerNumbers.HEATMAP_COLOR_NUMBER):
        df_filtered = heatmap_df[heatmap_df["total_counts"] >= (index + 1)].copy()

        if df_filtered.empty:
            ternary.update_traces(a=[], b=[], c=[], selector={"name": f"color_{index:02d}"})
            block_counts[index] = 0
        else:
            ternary.update_traces(
                a=df_filtered["sl"],
                b=df_filtered["sd"],
                c=df_filtered["sr"],
                marker={
                    "symbol": "hexagon",
                    "color": glob.config.heatmap_colors[index],
                    "size": 4,
                    "line": {"width": 0},
                },
                hovertemplate=ternary_hover_template(Labels.TOTAL_BIFURCATION.value, glob.config.ternary_heatmap_resolution.value, True),
                selector={"name": f"{index:02d}"},
            )
            block_counts[index] = len(df_filtered)

    # update circle trace
    ternary.update_traces(
        a=[glob.config.heatmap_clicked_coordinate.sl],
        b=[glob.config.heatmap_clicked_coordinate.sd],
        c=[glob.config.heatmap_clicked_coordinate.sr],
        marker={
            "symbol": "circle-open",
            "color": "pink",
            "size": 20,
            "line": {"width": 5},
        },
        selector={"name": "Circle"},
    )

    # update size
    ternary.update_layout(width=(glob.config.resolution * 2) + (glob.config.resolution * 0.2), height=glob.config.resolution * 2)

    # add heatmap legend
    ternary = add_heatmap_legend(ternary, block_counts)

    # return new ternary and visible networks list
    return ternary, visible_networks
