import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.graph.ternary.add_ternary_arrows import add_ternary_arrows


def build_heatmap_ternary() -> go.Figure:

    # create figure
    fig = go.Figure()

    # add traces
    for index in range(IntegerNumbers.HEATMAP_COLOR_NUMBER):
        fig.add_trace(
            go.Scatterternary(
                name=f"{index:02d}",
                mode="markers",
                a=[],
                b=[],
                c=[],
            )
        )

    # add circle trace
    fig.add_trace(
        go.Scatterternary(
            name="Circle",
            mode="markers",
            a=[],
            b=[],
            c=[],
        )
    )

    # configure layout
    tick_vals_increase = [round(i * 0.1, 1) for i in range(11)]
    tick_vals_decrease = [round(i * 0.1, 1) for i in range(10, -1, -1)]
    tick_text_decrease = [f"{val:g}" for val in tick_vals_decrease]
    marging = 0.05

    # set ternary layout with custom ticks and gridlines
    fig.update_layout(
        ternary={
            "domain": {"x": [marging, 1 - marging], "y": [marging, 1 - marging]},
            "sum": 1,
            "aaxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": 60,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "baxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": -60,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "caxis": {
                "min": 0,
                "tickvals": tick_vals_increase,
                "ticktext": tick_text_decrease,
                "tickangle": 0,
                "title": "",
                "linecolor": "black",
                "gridcolor": "lightgray",
            },
            "bgcolor": "white",
        },
        xaxis={
            "range": [0, 1],
            "scaleanchor": "y",
            "scaleratio": 1,
            "visible": False,
            "showgrid": False,
            "zeroline": False,
            "showticklabels": False,
            "fixedrange": False,
        },
        yaxis={"range": [0, 1], "visible": False, "showgrid": False, "zeroline": False, "showticklabels": False, "fixedrange": False},
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        showlegend=False,
        uirevision="ternary",
        width=glob.config.resolution * 2,
        height=glob.config.resolution * 2,
    )

    # add ternary arrows
    fig = add_ternary_arrows(fig)

    # return ternary heatmap figure
    return fig
