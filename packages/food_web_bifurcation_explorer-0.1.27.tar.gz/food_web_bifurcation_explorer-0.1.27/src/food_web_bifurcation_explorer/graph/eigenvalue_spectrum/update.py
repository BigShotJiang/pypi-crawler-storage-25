import numpy as np
import plotly.graph_objects as go
import os

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


def update_eigenvalue_spectrum(fig: go.Figure, branch_type: BranchTypes) -> go.Figure:
    # 1. Get the eigenvalue spectrum values
    real_parts, imag_parts, fixed_parameter, dynamic_parameter = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][branch_type].get_eigenvalue_spectrum_values()

    # Clear current figure data safely
    fig.data = []

    if not real_parts:
        return fig

    # 2. Prepare vectorized data to optimize Plotly rendering (reduces DOM nodes)
    x_lines, y_lines = [], []
    marker_colors = []
    text_colors = []
    labels = []

    n = len(real_parts)
    is_conjugated = [False] * n

    # Identify conjugated pairs and build coordinates for a single line trace
    for i in range(n):
        if is_conjugated[i]:
            continue
        for j in range(i + 1, n):
            if is_conjugated[j]:
                continue

            if np.isclose(real_parts[i], real_parts[j]) and np.isclose(imag_parts[i], -imag_parts[j]):
                is_conjugated[i] = is_conjugated[j] = True
                # Plotly draws separate segments if we insert None between coordinates
                x_lines.extend([real_parts[i], real_parts[j], None])
                y_lines.extend([imag_parts[i], imag_parts[j], None])
                break

    # Build marker properties for a single scatter trace
    for i, r in enumerate(real_parts):
        labels.append(str(i + 1))
        if r > 0:
            # Unstable area
            marker_colors.append("pink" if is_conjugated[i] else "red")
            text_colors.append("black" if is_conjugated[i] else "white")
        else:
            # Stable area
            marker_colors.append("cyan" if is_conjugated[i] else "blue")
            text_colors.append("black" if is_conjugated[i] else "white")

    # 3. Draw conjugated pair lines (one trace per pair, colored by stability)
    for i in range(n):
        if is_conjugated[i] and imag_parts[i] >= 0:  # only draw once per pair (positive imag)
            color = "pink" if real_parts[i] > 0 else "cyan"
            j = next(k for k in range(n) if k != i and np.isclose(real_parts[i], real_parts[k]) and np.isclose(imag_parts[i], -imag_parts[k]))
            fig.add_trace(
                go.Scattergl(
                    x=[real_parts[i], real_parts[j]],
                    y=[imag_parts[i], imag_parts[j]],
                    mode="lines",
                    line={"color": color, "width": 4},
                    hoverinfo="skip",
                    showlegend=False,
                )
            )

    # 4. Draw all eigenvalues (single trace)
    fig.add_trace(
        go.Scattergl(
            x=real_parts,
            y=imag_parts,
            mode="markers+text",
            marker={"size": 18, "color": marker_colors, "line": {"width": 1, "color": "black"}},
            text=labels,
            textfont={"color": text_colors, "family": "Arial", "size": 11},
            hovertemplate="λ%{text}: %{x:.4f} + %{y:.4f}i<extra></extra>",  # Custom tooltip
            showlegend=False,
        )
    )

    # We let Plotly use its default template
    fig.update_layout(
        title={"text": f"EV Spectrum, {branch_type.value}, {glob.config.fixed_parameter_type.value}={fixed_parameter}, {glob.config.dynamic_paramameter_type.value}={dynamic_parameter}"},
        uirevision=branch_type.value,
        margin={"l": 40, "r": 40, "t": 40, "b": 40},
    )

    # save current status (temporal)
    # os.makedirs("plots", exist_ok=True)
    # fig.write_image(f"plots/eigenvalue_spectrum_{branch_type.value}.svg")

    return fig


def add_area_labels(fig: go.Figure, y_position: float) -> None:
    """Add area labels ("Unstable area" and "Stable area") to the given figure.
    Positions are relative to the plot area using paper coordinates.
    """
    fig.update_layout(
        annotations=[
            {
                # 2% of the plot width starting from the left
                "x": 0.02,
                "y": y_position,
                "xref": "paper",
                "yref": "y",
                "text": "← Stable area",
                "xanchor": "left",
                "showarrow": False,
                "font": {"color": "blue", "size": 14, "weight": "bold"},
            },
            {
                # 98% of the plot width (aligned to the right)
                "x": 0.98,
                "y": y_position,
                "xref": "paper",
                "yref": "y",
                "text": "Unstable area →",
                "xanchor": "right",
                "showarrow": False,
                "font": {"color": "red", "size": 14, "weight": "bold"},
            },
        ]
    )
