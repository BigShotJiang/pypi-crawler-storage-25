import pandas as pd
import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.common.drawing.drawing_bifurcation_options import DrawingBifurcationOptions
from food_web_bifurcation_explorer.common.drawing.drawing_scatter_options import DrawingScatterOptions
from food_web_bifurcation_explorer.data.plot_data import BranchData
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.traces.bifurcation_diagram_traces import BifurcationDiagramTraces
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_one_visual_types import BifurcationCodimensionOneVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.extinctions_visual_types import ExtinctVisualTypes
from food_web_bifurcation_explorer.enums.types.visual.other_visual_types import OtherVisualTypes


def build_over_template(trace: str, show: bool) -> str | None:
    # check if show over template
    if show:
        # return formatted over template
        return (
            trace
            + "<br>"
            + "Parameter "
            + glob.config.dynamic_paramameter_type
            + ": %{x}<br>"
            + "Biomass: %{y} "
            + Labels.BIOMASS_UNIT
            + " <extra></extra>"
        )
    # skip template
    return None


def clear_branch(
    fig: go.Figure,
    name: str
) -> None:
    """Clears the branch trace with the specified name in the given figure.

    Args:
        fig (go.Figure): The Plotly figure object.
        name (str): The name of the branch trace to clear.

    """
    fig.update_traces(selector={"name": name}, x=[], y=[])


def clear_branch_traces(
    fig: go.Figure,
    branch_data: BranchData,
) -> None:
    # stable
    clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{branch_data.branch_type.value}")
    # unstable
    clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{branch_data.branch_type.value}")
    # stable (transition)
    clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{branch_data.branch_type.value}")
    # unstable (transition)
    clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{branch_data.branch_type.value}")


def clear_extended_branch_traces(
    fig: go.Figure,
    index: int,
) -> None:
    # stable
    clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{BranchTypes.ALTERNATIVE.value}_{index}")
    # unstable
    clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{BranchTypes.ALTERNATIVE.value}_{index}")
    # stable (transition)
    clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{BranchTypes.ALTERNATIVE.value}_{index}")
    # unstable (transition)
    clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{BranchTypes.ALTERNATIVE.value}_{index}")


def draw_branch_data(
    fig: go.Figure,
    bifurcation_diagrams_options: DrawingScatterOptions,
    bifurcation_diagram_type: BifurcationDiagramTypes,
    branch_data: BranchData,
) -> None:
    """Draws branch data for the specified compartment index in the figure.

    Args:
        branch_data: The branch data object containing equilibrium nodes and x values.
        fig (go.Figure): The Plotly figure object.

    """
    # check if show hoverinfo
    show_hoverinfo = "skip"
    if bifurcation_diagrams_options.equilibria_over_information:
        show_hoverinfo = "all"

    # get biomass column name
    biomass_column = f"b_{glob.config.compartment_index[bifurcation_diagram_type] + 1}"

    # check if there is data to draw
    if not branch_data.branch_dataframe.empty:
        # get parameter values
        parameter_values = branch_data.branch_dataframe["parameter_values"].tolist()

        # stable
        if bifurcation_diagrams_options.equilibria_stable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{branch_data.branch_type.value}"},
                x=parameter_values,
                y=branch_data.stablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.STABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{branch_data.branch_type.value}")

        # unstable
        if bifurcation_diagrams_options.equilibria_unstable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{branch_data.branch_type.value}"},
                x=parameter_values,
                y=branch_data.unstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{branch_data.branch_type.value}")

        # stable (transition)
        if bifurcation_diagrams_options.equilibria_stable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{branch_data.branch_type.value}"},
                x=parameter_values,
                y=branch_data.transition_stabletounstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.STABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{branch_data.branch_type.value}")

        # unstable (transition)
        if bifurcation_diagrams_options.equilibria_unstable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{branch_data.branch_type.value}"},
                x=parameter_values,
                y=branch_data.transition_unstabletostablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{branch_data.branch_type.value}")

    else:
        clear_branch_traces(fig, branch_data)


def draw_extended_branch_data(
    fig: go.Figure,
    bifurcation_diagrams_options: DrawingScatterOptions,
    bifurcation_diagram_type: BifurcationDiagramTypes,
    index: int,
) -> None:
    """Draws branch data for the specified compartment index in the figure.

    Args:
        branch_data: The branch data object containing equilibrium nodes and x values.
        fig (go.Figure): The Plotly figure object.

    """
    # check if show hoverinfo
    show_hoverinfo = "skip"
    if bifurcation_diagrams_options.equilibria_over_information:
        show_hoverinfo = "all"

    # get branch data
    extended_branch_data: BranchData = glob.plot_data.extended_branch_datas[glob.config.fixed_parameter_type][index]

    # get biomass column name
    biomass_column = f"b_{glob.config.compartment_index[bifurcation_diagram_type] + 1}"

    # check if there is data to draw
    if not extended_branch_data.branch_dataframe.empty:
        # get parameter values
        parameter_values = extended_branch_data.branch_dataframe["parameter_values"].tolist()

        # stable
        if bifurcation_diagrams_options.equilibria_stable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{extended_branch_data.branch_type.value}_{index}"},
                x=parameter_values,
                y=extended_branch_data.stablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.STABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{extended_branch_data.branch_type.value}_{index}")

        # unstable
        if bifurcation_diagrams_options.equilibria_unstable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{extended_branch_data.branch_type.value}_{index}"},
                x=parameter_values,
                y=extended_branch_data.unstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{extended_branch_data.branch_type.value}_{index}")

        # stable (transition)
        if bifurcation_diagrams_options.equilibria_stable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{extended_branch_data.branch_type.value}_{index}"},
                x=parameter_values,
                y=extended_branch_data.transition_stabletounstablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.STABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{extended_branch_data.branch_type.value}_{index}")

        # unstable (transition)
        if bifurcation_diagrams_options.equilibria_unstable:
            fig.update_traces(
                selector={"name": f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{extended_branch_data.branch_type.value}_{index}"},
                x=parameter_values,
                y=extended_branch_data.transition_unstabletostablenodes_dataframe[biomass_column].tolist(),
                hoverinfo=show_hoverinfo,
                mode=bifurcation_diagrams_options.drawing_mode.get_drawing_mode(),
                hovertemplate=build_over_template(
                    BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value,
                    bifurcation_diagrams_options.equilibria_over_information,
                ),
            )
        else:
            clear_branch(fig, f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{extended_branch_data.branch_type.value}_{index}")

    else:
        clear_extended_branch_traces(fig, index)


def update_bifurcation_diagram(bifurcation_diagram_type: BifurcationDiagramTypes) -> go.Figure:
    """Updates the bifurcation diagram based on the diagram type.

    Args:
        plot_type (PlotTypes): The type of bifurcation diagram to update.

    Returns:
        go.Figure: The updated Plotly figure object.

    """
    # get figure
    fig: go.Figure = glob.figures.bifurcation_diagrams[bifurcation_diagram_type]

    # get branches
    empirical_branch: BranchData = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.EMPIRICAL]
    alternative_branch: BranchData = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.ALTERNATIVE]

    # get drawing options
    bifurcation_diagrams_options: DrawingScatterOptions = glob.config.drawing_options.bifurcation_diagrams_options[bifurcation_diagram_type]
    bifurcation_diagrams_bifurcations: DrawingBifurcationOptions = glob.config.drawing_options.bifurcation_diagrams_bifurcations[
        bifurcation_diagram_type
    ]

    # empirical branch
    if bifurcation_diagrams_options.redraw_ternary_branches:
        # first clear branches
        clear_branch_traces(fig, empirical_branch)
        clear_branch_traces(fig, alternative_branch)
        for i in range (0, IntegerNumbers.EXTENDED_BRANCHES_NUM_MAX):
            clear_extended_branch_traces(fig, i)

        # draw empirical branch
        if glob.config.drawing_options.scatter_ternary_options.branch_empirical:
            # draw branch data
            draw_branch_data(fig, bifurcation_diagrams_options, bifurcation_diagram_type, empirical_branch)

        # draw alternative branch
        if glob.config.drawing_options.scatter_ternary_options.branch_alternative:
            # draw branch data
            draw_branch_data(fig, bifurcation_diagrams_options, bifurcation_diagram_type, alternative_branch)

        # draw extended branches
        for i in range (0, IntegerNumbers.EXTENDED_BRANCHES_NUM_MAX):
            draw_extended_branch_data(fig, bifurcation_diagrams_options, bifurcation_diagram_type, i)

        # reset flag
        bifurcation_diagrams_options.redraw_ternary_branches = False

    # envelope empirical
    if bifurcation_diagrams_options.redraw_hopf_envelope_empirical:
        # clear branches
        clear_branch(fig, BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL.value)
        clear_branch(fig, BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_TOP.value)
        clear_branch(fig, BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_BOT.value)

        # check if draw
        if bifurcation_diagrams_options.hopf_envelope_empirical:
            """
            # get evelope empirical data
            envelope_empirical: EnvelopeData = empirical_branch.envelope_data

            # draw traces
            if False and glob.config.compartment_index[bifurcation_diagram_type] < len(envelope_empirical.envelope_line_y):
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL.value},
                    x=envelope_empirical.envelope_line_x,
                    y=envelope_empirical.envelope_line_y[glob.config.compartment_index[bifurcation_diagram_type]],
                    hovertemplate=build_over_template(
                        BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL.value,
                        bifurcation_diagrams_options.equilibria_over_information,
                    ),
                )


            # draw traces
            if glob.config.compartment_index[bifurcation_diagram_type] < len(envelope_empirical.envelope_top):
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_TOP.value},
                    x=envelope_empirical.x_values,
                    y=envelope_empirical.envelope_top[glob.config.compartment_index[bifurcation_diagram_type]],
                    hovertemplate=build_over_template(
                        BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_TOP.value,
                        bifurcation_diagrams_options.equilibria_over_information,
                    ),
                )

            # draw traces
            if glob.config.compartment_index[bifurcation_diagram_type] < len(envelope_empirical.envelope_bot):
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_BOT.value},
                    x=envelope_empirical.x_values,
                    y=envelope_empirical.envelope_bot[glob.config.compartment_index[bifurcation_diagram_type]],
                    hovertemplate=build_over_template(
                        BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_BOT.value,
                        bifurcation_diagrams_options.equilibria_over_information,
                    ),
                )
            """
            # reset flag
            bifurcation_diagrams_options.redraw_hopf_envelope_empirical = False

    # bifurcation dataframes
    empirical_bifurcations: pd.DataFrame = empirical_branch.bifurcations_dataframe
    alternative_bifurcations: pd.DataFrame = alternative_branch.bifurcations_dataframe

    # get biomass column name
    biomass_column: str = f"b_{glob.config.compartment_index[bifurcation_diagram_type] + 1}"

    # declare x and y values
    x_values: list[float] = []
    y_values: list[float] = []

    # saddle node empirical
    if bifurcation_diagrams_bifurcations.redraw_saddlenode_empirical:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.saddlenode_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.SADDLENODE.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.SADDLENODE_EMPIRICAL.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.SADDLENODE_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_saddlenode_empirical = False

    # saddle node alternative
    if bifurcation_diagrams_bifurcations.redraw_saddlenode_alternative:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.saddlenode_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.SADDLENODE.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.SADDLENODE_ALTERNATIVE.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.SADDLENODE_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_saddlenode_alternative = False

    # transcritical empirical
    if bifurcation_diagrams_bifurcations.redraw_transcritical_empirical:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.transcritical_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.TRANSCRITICAL.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.TRANSCRITICAL_EMPIRICAL.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.TRANSCRITICAL_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_transcritical_empirical = False

    # transcritical alternative
    if bifurcation_diagrams_bifurcations.redraw_transcritical_alternative:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.transcritical_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.TRANSCRITICAL.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.TRANSCRITICAL_ALTERNATIVE.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.TRANSCRITICAL_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_transcritical_alternative = False

    # hopf subcritical empirical
    if bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_empirical:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.hopf_subcritical_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.HOPF_SUBCRITICAL.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUBCRITICAL_EMPIRICAL.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUBCRITICAL_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_empirical = False

    # hopf subcritical alternative
    if bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_alternative:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.hopf_subcritical_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.HOPF_SUBCRITICAL.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUBCRITICAL_ALTERNATIVE.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUBCRITICAL_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_subcritical_alternative = False

    # hopf supercritical empirical
    if bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_empirical:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.hopf_supercritical_empirical and not empirical_bifurcations.empty:
            filtered_data = empirical_bifurcations[empirical_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.HOPF_SUPERCRITICAL.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUPERCRITICAL_EMPIRICAL.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUPERCRITICAL_EMPIRICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_empirical = False

    # hopf supercritical alternative
    if bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_alternative:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_bifurcations.hopf_supercritical_alternative and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == BifurcationCodimensionOneVisualTypes.HOPF_SUPERCRITICAL.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.HOPF_SUPERCRITICAL_ALTERNATIVE.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.HOPF_SUPERCRITICAL_ALTERNATIVE.value, True),
        )

        # reset flag
        bifurcation_diagrams_bifurcations.redraw_hopf_supercritical_alternative = False

    # extinct (transcritical)
    if bifurcation_diagrams_options.redraw_extinct_transcritical:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_options.extinct_transcritical and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == ExtinctVisualTypes.EXTINCT_TRANSCRITICAL.value]
            for index in range(0, IntegerNumbers.TRACES_NUM_MAX_EXTINCTIONS):
                branch_rows = filtered_data[filtered_data["index"] == index]
                if not branch_rows.empty:
                    x_values.extend(branch_rows["parameter_values"].tolist())
                    y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.EXTINCT_TRANSCRITICAL.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.EXTINCT_TRANSCRITICAL.value, True),
        )

        # reset flag
        bifurcation_diagrams_options.redraw_extinct_transcritical = False

    # extinct (extended)
    if bifurcation_diagrams_options.redraw_extinct_extended:
        # reset values
        x_values = []
        y_values = []
        # get values
        if bifurcation_diagrams_options.extinct_extended:
            x_values, y_values = glob.plot_data.ternary_data.get_extinctions_extended_bifurcation_diagram_values(bifurcation_diagram_type)
        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.EXTINCT_EXTENDED.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.EXTINCT_EXTENDED.value, True),
        )

        # reset flag
        bifurcation_diagrams_options.redraw_extinct_extended = False

    # internal_error
    if bifurcation_diagrams_options.redraw_internal_error:
        # reset values
        x_values = []
        y_values = []
        if bifurcation_diagrams_options.internal_error and not alternative_bifurcations.empty:
            filtered_data = alternative_bifurcations[alternative_bifurcations["type"] == OtherVisualTypes.INTERNAL_ERROR.value]
            branch_rows = filtered_data[filtered_data["index"] == 1]
            if not branch_rows.empty:
                x_values.extend(branch_rows["parameter_values"].tolist())
                y_values.extend(branch_rows[biomass_column].tolist())

        # update trace
        fig.update_traces(
            selector={"name": BifurcationDiagramTraces.INTERNAL_ERROR.value},
            x=x_values,
            y=y_values,
            hovertemplate=build_over_template(BifurcationDiagramTraces.INTERNAL_ERROR.value, True),
        )

        # reset flag
        bifurcation_diagrams_options.redraw_internal_error = False

    # draw eingenvalue spectrum only if this is the first bifurcation diagram
    if bifurcation_diagram_type == BifurcationDiagramTypes.FIRST:
        # eigenvalue spectrum index empirical
        if bifurcation_diagrams_options.redraw_eigenvalue_spectrum_symbol_empirical:
            # clear traces
            clear_branch(fig, BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL.value)

            # check eigenvalue spectrum flag
            if bifurcation_diagrams_options.eigenvalue_spectrum_symbols:
                # get empirical branch
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL.value},
                    x=empirical_branch.get_eigenvalue_spectrum_x(),
                    y=empirical_branch.get_eigenvalue_spectrum_y(),
                    hovertemplate=build_over_template(BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL.value, True),
                )

            # reset flag
            bifurcation_diagrams_options.redraw_eigenvalue_spectrum_symbol_empirical = False

        # eigenvalue spectrum index alternative
        if bifurcation_diagrams_options.redraw_eigenvalue_spectrum_symbol_alternative:
            # clear traces
            clear_branch(fig, BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE.value)

            # check eigenvalue spectrum flag
            if bifurcation_diagrams_options.eigenvalue_spectrum_symbols:
                # alternative
                fig.update_traces(
                    selector={"name": BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE.value},
                    x=alternative_branch.get_eigenvalue_spectrum_x(),
                    y=alternative_branch.get_eigenvalue_spectrum_y(),
                    hovertemplate=build_over_template(BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE.value, True),
                )

            # reset flag
            bifurcation_diagrams_options.redraw_eigenvalue_spectrum_symbol_alternative = False

    # get x axis title
    if glob.config.dynamic_paramameter_type == ParameterTypes.DONOR:
        xaxis_title = Labels.DONOR_CONTROL_STRENGTH
    elif glob.config.dynamic_paramameter_type == ParameterTypes.RECIPIENT:
        xaxis_title = Labels.RECIPIENT_CONTROL_STRENGTH
    elif glob.config.dynamic_paramameter_type == ParameterTypes.LOTKAVOLTERRA:
        xaxis_title = Labels.LOTKAVOLTERRA_CONTROL_STRENGTH
    else:
        raise ValueError("Unknown fixed parameter type: " + glob.config.dynamic_paramameter_type)

    # update layout
    fig.update_layout(
        title="Bifurcation diagram for compartment '"
        + str(glob.config.compartment_index[bifurcation_diagram_type] + 1)
        + "' ("
        + glob.config.compartment_value[bifurcation_diagram_type]
        + ")",
        xaxis_title=xaxis_title,
        yaxis_title=glob.config.compartment_value[bifurcation_diagram_type] + " biomass (" + Labels.BIOMASS_UNIT + ")",
    )
    return fig
