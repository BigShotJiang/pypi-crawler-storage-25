"""Build bifurcation diagram plots using Plotly."""

import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.colors.bifurcation_colors import BifurcationColors
from food_web_bifurcation_explorer.enums.colors.stability_colors import StabilityColors
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.symbols import Symbols
from food_web_bifurcation_explorer.enums.traces.bifurcation_diagram_traces import BifurcationDiagramTraces
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


def build_bifurcation_diagram(bifurcation_diagram_type: BifurcationDiagramTypes) -> go.Figure:
    """Build a bifurcation diagram figure with predefined traces.

    Args:
        plot_type: The type of bifurcation diagram to build.

    Returns:
        A Plotly Figure object configured with traces for equilibria,
        bifurcations, and envelopes.

    """
    # declare line width
    line_width = 4
    equilibria_marker_width = 6
    bifurcation_marker_width = 15

    # declare general figure
    fig = go.Figure()

    # branches
    for branch_type in BranchTypes:

        # stable
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{branch_type.value}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.STABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

        # unstable
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{branch_type.value}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.UNSTABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

        # stable (transition)
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{branch_type.value}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.STABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

        # unstable (transition)
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{branch_type.value}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.UNSTABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

    # load extended branch data
    for index in range (0, IntegerNumbers.EXTENDED_BRANCHES_NUM_MAX):

        # stable
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_{BranchTypes.ALTERNATIVE.value}_{index}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.STABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

        # unstable
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_{BranchTypes.ALTERNATIVE.value}_{index}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.UNSTABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

        # stable (transition)
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.STABLE_EQUILIBRIA.value}_transition_{BranchTypes.ALTERNATIVE.value}_{index}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.STABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

        # unstable (transition)
        fig.add_trace(
            go.Scattergl(
                name=f"{BifurcationDiagramTraces.UNSTABLE_EQUILIBRIA.value}_transition_{BranchTypes.ALTERNATIVE.value}_{index}",
                x=[],
                y=[],
                mode="lines",
                line={"color": StabilityColors.UNSTABLE.value, "width": line_width},
                marker={"size": equilibria_marker_width},
                showlegend=False,
            )
        )

    # envelope empirical
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL.value,
            x=[],
            y=[],
            mode="lines",
            line={"color": BifurcationColors.HOPF_ENVELOPE_EMPIRICAL.value, "width": 1},
            marker={"size": equilibria_marker_width},
            showlegend=False,
        )
    )

    # envelope empirical top
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_TOP.value,
            x=[],
            y=[],
            mode="lines",
            line={"color": BifurcationColors.HOPF_ENVELOPE_EMPIRICAL.value, "width": 1},
            marker={"size": equilibria_marker_width},
            showlegend=False,
        )
    )

    # envelope empirical bot
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_ENVELOPE_EMPIRICAL_BOT.value,
            x=[],
            y=[],
            mode="lines",
            line={"color": BifurcationColors.HOPF_ENVELOPE_EMPIRICAL.value, "width": 1},
            marker={"size": equilibria_marker_width},
            showlegend=False,
        )
    )

    # envelope alternative
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_ENVELOPE_ALTERNATIVE.value,
            x=[],
            y=[],
            mode="lines",
            line={"color": BifurcationColors.HOPF_ENVELOPE_ALTERNATIVE.value, "width": 1},
            marker={"size": equilibria_marker_width},
            showlegend=False,
        )
    )

    # envelope alternative top
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_ENVELOPE_ALTERNATIVE_TOP.value,
            x=[],
            y=[],
            mode="lines",
            line={"color": BifurcationColors.HOPF_ENVELOPE_ALTERNATIVE.value, "width": line_width},
            marker={"size": equilibria_marker_width},
            showlegend=False,
        )
    )

    # envelope alternative bot
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_ENVELOPE_ALTERNATIVE_BOT.value,
            x=[],
            y=[],
            mode="lines",
            line={"color": BifurcationColors.HOPF_ENVELOPE_ALTERNATIVE.value, "width": line_width},
            marker={"size": equilibria_marker_width},
            showlegend=False,
        )
    )

    # extinct (transcritical)
    fig.add_trace(
        go.Scatter(  # here we need to use Scatter instead Scattergl due text labels
            name=BifurcationDiagramTraces.EXTINCT_TRANSCRITICAL.value,
            x=[],
            y=[],
            text=[],
            mode="markers+text",
            line={"color": BifurcationColors.EXTINCT.value, "width": line_width},
            marker={"symbol": Symbols.CROSS, "size": bifurcation_marker_width},
            textposition="middle right",
            showlegend=False,
        )
    )

    # extinct (extended)
    fig.add_trace(
        go.Scatter(  # here we need to use Scatter instead Scattergl due text labels
            name=BifurcationDiagramTraces.EXTINCT_EXTENDED.value,
            x=[],
            y=[],
            text=[],
            mode="markers+text",
            line={"color": BifurcationColors.EXTINCT.value, "width": line_width},
            marker={"symbol": Symbols.CROSS, "size": bifurcation_marker_width},
            textposition="middle right",
            showlegend=False,
        )
    )

    # saddle node bifurcation
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.SADDLENODE_EMPIRICAL.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.SADDLENODE_EMPIRICAL.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.SADDLENODE_ALTERNATIVE.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.SADDLENODE_ALTERNATIVE.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )

    # transcritical bifurcation
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.TRANSCRITICAL_EMPIRICAL.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.TRANSCRITICAL_EMPIRICAL.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.TRANSCRITICAL_ALTERNATIVE.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.TRANSCRITICAL_ALTERNATIVE.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )

    # hopf subcritical bifurcation
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_SUBCRITICAL_EMPIRICAL.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.HOPF_SUBCRITICAL_EMPIRICAL.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_SUBCRITICAL_ALTERNATIVE.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.HOPF_SUBCRITICAL_ALTERNATIVE.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )

    # hopf supercritical bifurcation
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_SUPERCRITICAL_EMPIRICAL.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.HOPF_SUPERCRITICAL_EMPIRICAL.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.HOPF_SUPERCRITICAL_ALTERNATIVE.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.HOPF_SUPERCRITICAL_ALTERNATIVE.value, "width": line_width},
            marker={"size": bifurcation_marker_width},
            showlegend=False,
        )
    )

    # internal_error
    fig.add_trace(
        go.Scattergl(
            name=BifurcationDiagramTraces.INTERNAL_ERROR.value,
            x=[],
            y=[],
            mode="markers",
            line={"color": BifurcationColors.INTERNAL_ERROR.value, "width": line_width},
            marker={"symbol": Symbols.CROSS, "size": bifurcation_marker_width},
            showlegend=False,
        )
    )

    # eigenvalue spectrum index empirical
    fig.add_trace(
        go.Scatter(
            name=BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL.value,
            x=[],
            y=[],
            mode="markers",
            marker=dict(
                symbol="square",
                size=bifurcation_marker_width + 3,
                color="rgba(0,0,0,0)",
                line=dict(
                    color=BifurcationColors.EIGENVALUE_SPECTRUM_INDEX.value,
                    width=line_width - 1,
                ),
            ),
            showlegend=False,
        )
    )

    # eigenvalue spectrum index alternative
    fig.add_trace(
        go.Scatter(
            name=BifurcationDiagramTraces.EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE.value,
            x=[],
            y=[],
            mode="markers",
            marker=dict(
                symbol="square",
                size=bifurcation_marker_width + 3,
                color="rgba(0,0,0,0)",
                line=dict(
                    color=BifurcationColors.EIGENVALUE_SPECTRUM_INDEX.value,
                    width=line_width - 1,
                ),
            ),
            showlegend=False,
        )
    )

    # draw extinct line
    fig.add_hline(
        y=0,
        line_dash="dot",
        line_color="black",
        annotation_text="Extinct",
        annotation_position="bottom left",
    )

    # update layout
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 50, "b": 0},
        showlegend=True,
        uirevision="bifurcation_diagram_" + bifurcation_diagram_type.value,
        # set sizes
        width=glob.config.resolution * 2,
        height=glob.config.resolution,
    )
    return fig