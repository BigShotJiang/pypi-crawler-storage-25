import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


# build eigenValueSpectrum
def build_phase_portrait(branch_type: BranchTypes) -> go.Figure:
    # create figure
    fig = go.Figure()
    #  create traces for eigen values
    for i in range(0, glob.plot_data.get_num_compartments()):
        # add trace
        fig.add_trace(go.Scattergl(name=f"λ{i + 1}", x=[], y=[], mode="markers+text", text=[f"{i + 1}"]))
    # configure layout
    fig.update_layout(
        title={"text": "Eigenvalues Spectrum for " + branch_type + " branch"},
        xaxis={
            "title": "Eigenvalues real part",
            "range": [-1, 1],
            "zeroline": True,
            "zerolinecolor": "gray",
            "showticklabels": True,
        },
        yaxis={
            "title": "Eigenvalues imaginary part",
            "range": [-1, 1],
            "zeroline": True,
            "zerolinecolor": "gray",
            "showticklabels": True,
        },
        margin={"l": 0, "r": 0, "t": 50, "b": 0},
        showlegend=True,
        uirevision="eigenvalueSpectrum" + branch_type,
        # set sizes
        width=glob.config.resolution * 2,
        height=glob.config.resolution,
    )
    return fig
