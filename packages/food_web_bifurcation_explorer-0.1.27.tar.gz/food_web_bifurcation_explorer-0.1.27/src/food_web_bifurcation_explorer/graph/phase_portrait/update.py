"""Module for updating and managing phase portrait visualizations."""

import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


def update_phase_portrait(fig: go.Figure, branch_type: BranchTypes) -> go.Figure:
    branch_type
    return fig
