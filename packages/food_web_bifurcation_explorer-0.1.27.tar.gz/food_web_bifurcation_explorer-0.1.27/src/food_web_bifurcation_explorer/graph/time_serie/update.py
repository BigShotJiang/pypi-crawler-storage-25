"""Module for updating and managing time serie visualizations."""

import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


def update_time_serie(fig: go.Figure, branch_type: BranchTypes) -> go.Figure:

    fig.data = []
    branch_type

    return fig
