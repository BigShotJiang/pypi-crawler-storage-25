class DrawingEigenvalueSpectrumOptions:
    def __init__(self) -> None:
        # flags to indicate if redraw is required for eigen value spectrum diagrams
        self.redraw_eigenvalue_spectrum: bool = False

    def update_eigenvalue_spectrum_options_flags(
        self,
    ) -> None:
        """Update eigenvalue spectrum flags"""
        # currently unused

    def redraw_all(self) -> None:
        """Set all redraw flags to True."""
        self.redraw_eigenvalue_spectrum = True

    def is_redraw_required(self, parent: str) -> None:
        """Check if any element requires a redraw, and print a warning with the reasons."""
        # use the items of dictionary vinculated with this
        reasons = [attr.replace("redraw_", "") for attr, value in self.__dict__.items() if attr.startswith("redraw_") and value is True]
        # show info
        if reasons:
            formatted_reasons = "\n".join(f"- {reason}" for reason in reasons)
            print(f"Redraw required in {parent} due to:\n{formatted_reasons}")
