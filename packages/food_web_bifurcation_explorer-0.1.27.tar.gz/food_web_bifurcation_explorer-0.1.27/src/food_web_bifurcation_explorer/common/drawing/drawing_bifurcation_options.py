from food_web_bifurcation_explorer.common.drawing.drawing_mode import DrawingMode
from food_web_bifurcation_explorer.enums.types.visual.bifurcation_codimension_one_visual_types import BifurcationCodimensionOneVisualTypes


class DrawingBifurcationOptions:
    def __init__(self, empirical_enabled: bool, alternative_enabled: bool) -> None:
        # flags to indicate if drawing of specific bifurcation types is enabled for empirical and alternative branches
        self.saddlenode_empirical: bool = empirical_enabled
        self.saddlenode_alternative: bool = alternative_enabled
        self.transcritical_empirical: bool = empirical_enabled
        self.transcritical_alternative: bool = alternative_enabled
        self.hopf_subcritical_empirical: bool = empirical_enabled
        self.hopf_subcritical_alternative: bool = alternative_enabled
        self.hopf_supercritical_empirical: bool = empirical_enabled
        self.hopf_supercritical_alternative: bool = alternative_enabled
        self.hopf_envelope_empirical: bool = empirical_enabled
        self.hopf_envelope_alternative: bool = alternative_enabled
        self.bautin: bool = empirical_enabled
        self.bogdanov_takens: bool = empirical_enabled
        self.double_hopf: bool = empirical_enabled
        # drawing mode for lines and points
        self.drawing_mode: DrawingMode = DrawingMode()
        # flags to indicate if redraw is required for specific bifurcation types in ternary and bifurcation diagrams
        self.redraw_saddlenode_empirical: bool = True
        self.redraw_saddlenode_alternative: bool = True
        self.redraw_transcritical_empirical: bool = True
        self.redraw_transcritical_alternative: bool = True
        self.redraw_hopf_subcritical_empirical: bool = True
        self.redraw_hopf_subcritical_alternative: bool = True
        self.redraw_hopf_supercritical_empirical: bool = True
        self.redraw_hopf_supercritical_alternative: bool = True
        self.redraw_hopf_envelope_empirical: bool = True
        self.redraw_hopf_envelope_alternative: bool = True
        self.redraw_bautin: bool = True
        self.redraw_bogdanov_takens: bool = True
        self.redraw_double_hopf: bool = True

    def update_bifurcation_options_flags(
        self,
        saddlenode_empirical: bool,
        saddlenode_alternative: bool,
        transcritical_empirical: bool,
        transcritical_alternative: bool,
        hopf_subcritical_empirical: bool,
        hopf_subcritical_alternative: bool,
        hopf_supercritical_empirical: bool,
        hopf_supercritical_alternative: bool,
        bautin: bool,
        bogdanov_takens: bool,
        double_hopf: bool,
        lines: bool,
        points: bool,
    ) -> None:
        """Update bifurcation flags"""
        # update values
        self.redraw_saddlenode_empirical = self.redraw_saddlenode_empirical or (self.saddlenode_empirical != saddlenode_empirical)
        self.redraw_saddlenode_alternative = self.redraw_saddlenode_alternative or (self.saddlenode_alternative != saddlenode_alternative)
        self.redraw_transcritical_empirical = self.redraw_transcritical_empirical or (self.transcritical_empirical != transcritical_empirical)
        self.redraw_transcritical_alternative = self.redraw_transcritical_alternative or (self.transcritical_alternative != transcritical_alternative)
        self.redraw_hopf_subcritical_empirical = self.redraw_hopf_subcritical_empirical or (
            self.hopf_subcritical_empirical != hopf_subcritical_empirical
        )
        self.redraw_hopf_subcritical_alternative = self.redraw_hopf_subcritical_alternative or (
            self.hopf_subcritical_alternative != hopf_subcritical_alternative
        )
        self.redraw_hopf_supercritical_empirical = self.redraw_hopf_supercritical_empirical or (
            self.hopf_supercritical_empirical != hopf_supercritical_empirical
        )
        self.redraw_hopf_supercritical_alternative = self.redraw_hopf_supercritical_alternative or (
            self.hopf_supercritical_alternative != hopf_supercritical_alternative
        )
        self.redraw_bautin = self.redraw_bautin or (self.bautin != bautin)
        self.redraw_bogdanov_takens = self.redraw_bogdanov_takens or (self.bogdanov_takens != bogdanov_takens)
        self.redraw_double_hopf = self.redraw_double_hopf or (self.double_hopf != double_hopf)
        # special case for drawing options (this requiere to redraw all)
        if self.drawing_mode.lines != lines:
            self.redraw_all()
        if self.drawing_mode.points != points:
            self.redraw_all()
        # update values
        self.saddlenode_empirical = saddlenode_empirical
        self.saddlenode_alternative = saddlenode_alternative
        self.transcritical_empirical = transcritical_empirical
        self.transcritical_alternative = transcritical_alternative
        self.hopf_subcritical_empirical = hopf_subcritical_empirical
        self.hopf_subcritical_alternative = hopf_subcritical_alternative
        self.hopf_supercritical_empirical = hopf_supercritical_empirical
        self.hopf_supercritical_alternative = hopf_supercritical_alternative
        self.bautin = bautin
        self.bogdanov_takens = bogdanov_takens
        self.double_hopf = double_hopf
        # update drawing mode flags
        self.drawing_mode.update_drawing_mode_flags(lines, points)

    def redraw_all(self) -> None:
        """Set all redraw flags to True."""
        self.redraw_saddlenode_empirical = True
        self.redraw_saddlenode_alternative = True
        self.redraw_transcritical_empirical = True
        self.redraw_transcritical_alternative = True
        self.redraw_hopf_subcritical_empirical = True
        self.redraw_hopf_subcritical_alternative = True
        self.redraw_hopf_supercritical_empirical = True
        self.redraw_hopf_supercritical_alternative = True
        self.redraw_hopf_envelope_empirical = True
        self.redraw_hopf_envelope_alternative = True
        self.redraw_bautin = True
        self.redraw_bogdanov_takens = True
        self.redraw_double_hopf = True

    def is_redraw_required(self, parent: str) -> None:
        """Check if any element requires a redraw, and print a warning with the reasons."""
        # use the items of dictionary vinculated with this
        reasons = [attr.replace("redraw_", "") for attr, value in self.__dict__.items() if attr.startswith("redraw_") and value is True]
        # show info
        if reasons:
            formatted_reasons = "\n".join(f"- {reason}" for reason in reasons)
            print(f"Redraw required in {parent} due to:\n{formatted_reasons}")

    def get_enabled_bifurcations(self) -> tuple[list[BifurcationCodimensionOneVisualTypes], list[BifurcationCodimensionOneVisualTypes]]:
        """Get the enabled bifurcation types for empirical and alternative branches."""
        # empirical bifurcations
        empirical_bifurcations: list[BifurcationCodimensionOneVisualTypes] = []
        if self.saddlenode_empirical:
            empirical_bifurcations.append(BifurcationCodimensionOneVisualTypes.SADDLENODE)
        if self.transcritical_empirical:
            empirical_bifurcations.append(BifurcationCodimensionOneVisualTypes.TRANSCRITICAL)
        if self.hopf_subcritical_empirical:
            empirical_bifurcations.append(BifurcationCodimensionOneVisualTypes.HOPF_SUBCRITICAL)
        if self.hopf_supercritical_empirical:
            empirical_bifurcations.append(BifurcationCodimensionOneVisualTypes.HOPF_SUPERCRITICAL)
        # alternative bifurcations
        alternative_bifurcations = []
        if self.saddlenode_alternative:
            alternative_bifurcations.append(BifurcationCodimensionOneVisualTypes.SADDLENODE)
        if self.transcritical_alternative:
            alternative_bifurcations.append(BifurcationCodimensionOneVisualTypes.TRANSCRITICAL)
        if self.hopf_subcritical_alternative:
            alternative_bifurcations.append(BifurcationCodimensionOneVisualTypes.HOPF_SUBCRITICAL)
        if self.hopf_supercritical_alternative:
            alternative_bifurcations.append(BifurcationCodimensionOneVisualTypes.HOPF_SUPERCRITICAL)
        return (empirical_bifurcations, alternative_bifurcations)
