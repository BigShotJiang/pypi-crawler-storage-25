"""Configuration module for food web bifurcation explorer."""

from food_web_bifurcation_explorer.common.drawing.drawing_options import DrawingOptions
from food_web_bifurcation_explorer.common.exceptions import ParameterTypeError
from food_web_bifurcation_explorer.enums.network_data import NetworkData
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.resolutions.layout_resolutions import LayoutResolutions
from food_web_bifurcation_explorer.enums.resolutions.ternary_heatmap_resolutions import TernaryHeatmapResolutions
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.graph.ternary.ternary_coordinate import TernaryCoordinate


class Config:
    def __init__(self) -> None:
        # fixed parameters in float format
        self.fixed_parameter_values = [
            fixed_parameter / (IntegerNumbers.MAX_FIXED_PARAMETERS - 1) for fixed_parameter in range(0, IntegerNumbers.MAX_FIXED_PARAMETERS)
        ]
        # fixed parameters in string format
        self.fixed_parameter_values_str = [
            f"{fixed_parameter / (IntegerNumbers.MAX_FIXED_PARAMETERS - 1):.5f}" for fixed_parameter in range(0, IntegerNumbers.MAX_FIXED_PARAMETERS)
        ]
        # general options
        self.network: str = StaticOptions.DEFAULT_SCATTER_NETWORK
        self.resolution: int = LayoutResolutions.DEFAULT.value
        self.fixed_parameter_type: ParameterTypes = ParameterTypes.LOTKAVOLTERRA
        self.dynamic_paramameter_type: ParameterTypes = ParameterTypes.RECIPIENT
        self.fixed_parameter_value: float = StaticOptions.DEFAULT_SCATTER_PARAMETER_VALUE
        self.fixed_parameter_value_str: str = f"{self.fixed_parameter_value:.5f}"
        self.scatter_clicked_coordinate: TernaryCoordinate = TernaryCoordinate()
        # bifurcation diagram values
        self.compartment_index: dict[BifurcationDiagramTypes, int] = {}
        self.compartment_value: dict[BifurcationDiagramTypes, str] = {}
        # set initial values for bifurcation diagram compartments
        self.compartment_index[BifurcationDiagramTypes.FIRST] = StaticOptions.DEFAULT_SCATTER_COMPARTMENT_FIRST
        self.compartment_index[BifurcationDiagramTypes.SECOND] = StaticOptions.DEFAULT_SCATTER_COMPARTMENT_SECOND
        compartments_values: list[str] = self.get_current_compartments()
        for bifurcation_diagram_type in BifurcationDiagramTypes:
            self.compartment_value[bifurcation_diagram_type] = compartments_values[self.compartment_index[bifurcation_diagram_type]]
        # eigenValues spectrum options
        self.basic_eigenvalue_spectrum_index: dict[BranchTypes, int] = {}
        for branch_type in BranchTypes:
            self.basic_eigenvalue_spectrum_index[branch_type] = 0
        # drawing options
        self.drawing_options: DrawingOptions = DrawingOptions()
        # heatmap options
        self.heatmap_ternary_min_value: int = IntegerNumbers.HEATMAP_MIN_VALUE
        self.ternary_heatmap_resolution: TernaryHeatmapResolutions = StaticOptions.DEFAULT_HEATMAP_RESOLUTION
        self.heatmap_clicked_coordinate: TernaryCoordinate = TernaryCoordinate()
        # heatmap colors
        self.heatmap_start_color: str = StaticOptions.DEFAULT_START_COLOR
        self.heatmap_end_color: str = StaticOptions.DEFAULT_END_COLOR
        self.heatmap_colors: list[str] = [""] * IntegerNumbers.HEATMAP_COLOR_NUMBER
        self.update_color_gradient()
        # bifurcation distribution options
        self.bifurcation_distribution_num_bins: int = IntegerNumbers.BIFURCATION_DISTRIBUTIONS_BINS_DEFAULT
        self.bifurcation_distribution_num_contours: int = IntegerNumbers.BIFURCATION_DISTRIBUTIONS_CONTOURS_DEFAULT
        self.bifurcation_distribution_use_contours: bool = False
        # logarithmic options
        self.heatmap_ternary_logarithmic: bool = False
        self.bifurcation_distribution_logarithmic: bool = False

    def get_current_compartments(self) -> list[str]:
        """Return the list of current compartments for the selected network."""
        if self.network is not None:
            return NetworkData.VALUES[self.network]
        # return empty list
        return []

    def update_network(self, network: str) -> None:
        """Update the current network and adjust compartment indices if necessary."""
        self.network = network
        # adjust compartments
        for bifurcation_diagram_type in BifurcationDiagramTypes:
            self.update_compartment(bifurcation_diagram_type, self.compartment_index[bifurcation_diagram_type])

    def update_fixed_parameter_type(self, fixed_parameter_type: ParameterTypes) -> None:
        """Update the type of the fixed parameter."""
        self.fixed_parameter_type = fixed_parameter_type
        # set dynamic parameter
        if self.fixed_parameter_type == ParameterTypes.DONOR:
            self.dynamic_paramameter_type = ParameterTypes.LOTKAVOLTERRA
        elif self.fixed_parameter_type == ParameterTypes.RECIPIENT:
            self.dynamic_paramameter_type = ParameterTypes.DONOR
        elif self.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
            self.dynamic_paramameter_type = ParameterTypes.RECIPIENT
        else:
            raise ParameterTypeError("invalid parameter")

    def update_fixed_parameter_value(self, fixed_parameter_value: float) -> float:
        """Update the value of the fixed parameter and its string representation."""
        self.fixed_parameter_value = fixed_parameter_value
        self.fixed_parameter_value_str = f"{fixed_parameter_value:.5f}"
        # return new value
        return self.fixed_parameter_value

    def update_eigenvalue_spectrum_index(self, branch_type: BranchTypes, eigenvalue_spectrum_index: int) -> None:
        """Update the eigenvalue spectrum index for a given branch type."""
        self.basic_eigenvalue_spectrum_index[branch_type] = eigenvalue_spectrum_index

    def update_compartment(self, bifurcation_diagram_type: BifurcationDiagramTypes, compartment_index: int) -> None:
        """Update compartment to the specified value if it exists, otherwise set to the default compartment."""
        # get current compartments
        compartments_values: list[str] = self.get_current_compartments()

        # check if set default value or the specified value
        if compartment_index < len(compartments_values):
            self.compartment_index[bifurcation_diagram_type] = compartment_index
        elif bifurcation_diagram_type == BifurcationDiagramTypes.FIRST:
            self.compartment_index[bifurcation_diagram_type] = StaticOptions.DEFAULT_SCATTER_COMPARTMENT_FIRST
        else:
            self.compartment_index[bifurcation_diagram_type] = StaticOptions.DEFAULT_SCATTER_COMPARTMENT_SECOND

        # update compartment value
        self.compartment_value[bifurcation_diagram_type] = compartments_values[self.compartment_index[bifurcation_diagram_type]]

    def update_color_gradient(self) -> None:

        # renove # and convert hex to RGB
        start_rgb = tuple(int(self.heatmap_start_color.lstrip("#")[i : i + 2], 16) for i in (0, 2, 4))
        end_rgb = tuple(int(self.heatmap_end_color.lstrip("#")[i : i + 2], 16) for i in (0, 2, 4))

        # generate intermediate color
        for i in range(IntegerNumbers.HEATMAP_COLOR_NUMBER):
            # calculate ratio
            ratio = i / (IntegerNumbers.HEATMAP_COLOR_NUMBER - 1)

            # interpolate RGB values
            r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
            g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
            b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)

            # format in hexadecimal
            hex_color = f"#{r:02X}{g:02X}{b:02X}"

            # store in list
            self.heatmap_colors[i] = hex_color
