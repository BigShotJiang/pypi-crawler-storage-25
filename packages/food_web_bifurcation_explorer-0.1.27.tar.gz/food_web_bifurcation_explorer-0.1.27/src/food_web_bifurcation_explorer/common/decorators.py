from typing import TypeVar, Callable

# used for anotation
T = TypeVar("T")

def exact_values(n: int) -> Callable[[type[T]], type[T]]:

    def decorator(cls: type[T]) -> type[T]:

        members = list(cls)  # type: ignore

        if len(members) != n:
            raise ValueError(f"{cls.__name__} must have exactly {n} values, got {len(members)}")
        return cls

    return decorator

def consistent_ids(cls: type[T]) -> type[T]:

    inconsistent = []

    for member in cls:  # type: ignore
        expected = member.name.lower().replace("_", "-")
        if expected != member.value:
            inconsistent.append(f"  {member.name!r}: expected '{expected}', got '{member.value}'")
    if inconsistent:
        raise ValueError(f"{cls.__name__} has inconsistent key-value pairs:\n" + "\n".join(inconsistent))

    return cls