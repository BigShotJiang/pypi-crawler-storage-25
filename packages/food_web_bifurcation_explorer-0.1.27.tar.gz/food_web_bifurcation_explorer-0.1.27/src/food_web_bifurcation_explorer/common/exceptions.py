class BifurcationDiagramTypeError(ValueError):
    pass


class BifurcationDistributionTypeError(ValueError):
    pass


class BifurcationTypeError(ValueError):
    pass


class ParameterTypeError(ValueError):
    pass


class HopfParameterTypeError(ValueError):
    pass


class UpdatingGraphError(ValueError):
    pass