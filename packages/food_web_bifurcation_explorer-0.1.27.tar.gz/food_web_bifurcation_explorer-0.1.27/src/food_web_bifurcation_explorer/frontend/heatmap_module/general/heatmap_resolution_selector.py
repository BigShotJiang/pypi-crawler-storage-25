from dash import dcc

from food_web_bifurcation_explorer.enums.resolutions.ternary_heatmap_resolutions import TernaryHeatmapResolutions
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Dropdown:
    """Build and return the resolution selector dropdown component."""
    return dcc.Dropdown(
        id=IDs.DROPDOWN_HEATMAP_RESOLUTION,
        options=[{"label": resolution.name.replace("_", " ").capitalize(), "value": resolution.value} for resolution in TernaryHeatmapResolutions],
        value=StaticOptions.DEFAULT_HEATMAP_RESOLUTION.value,
        clearable=False,
    )
