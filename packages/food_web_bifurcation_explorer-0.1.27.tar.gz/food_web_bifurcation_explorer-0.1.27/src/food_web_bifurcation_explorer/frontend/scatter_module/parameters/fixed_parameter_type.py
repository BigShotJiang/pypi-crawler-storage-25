from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Dropdown:
    """Builds and returns a dropdown component for selecting the parameter type."""
    return dcc.Dropdown(
        id=IDs.DROPDOWN_SCATTER_PARAMETER_TYPE,
        options=[
            {
                "label": html.Span([Labels.DONOR_CONTROL, " ", html.I("s"), html.Sub("d"), html.I("")]),
                "value": ParameterTypes.DONOR,
            },
            {
                "label": html.Span([Labels.RECIPIENT_CONTROL, " ", html.I("s"), html.Sub("r"), html.I("")]),
                "value": ParameterTypes.RECIPIENT,
            },
            {
                "label": html.Span([Labels.LOTKAVOLTERRA_CONTROL, " ", html.I("s"), html.Sub("l"), html.I("")]),
                "value": ParameterTypes.LOTKAVOLTERRA,
            },
        ],
        value=ParameterTypes.LOTKAVOLTERRA,  # default parameter
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )
