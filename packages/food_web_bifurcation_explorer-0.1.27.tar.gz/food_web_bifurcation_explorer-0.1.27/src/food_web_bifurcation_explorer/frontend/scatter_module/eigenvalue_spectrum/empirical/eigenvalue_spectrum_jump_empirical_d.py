from dash import html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> html.Button:
    return html.Button(
        children=Labels.EIGENVALUE_SPECTRUM_JUMP_D,
        id=IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_D,
        n_clicks=0,
        style=Styles.BUTTON_EIGENVALUES,
    )
