from dash import dcc

from food_web_bifurcation_explorer.enums.network_data import NetworkData
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Dropdown:
    """Build and return the network selector dropdown component."""
    return dcc.Dropdown(
        id=IDs.DROPDOWN_SCATTER_NETWORK,
        options=[{"label": name, "value": name} for name in NetworkData.VALUES],
        value=StaticOptions.DEFAULT_SCATTER_NETWORK,
        clearable=False,
    )
