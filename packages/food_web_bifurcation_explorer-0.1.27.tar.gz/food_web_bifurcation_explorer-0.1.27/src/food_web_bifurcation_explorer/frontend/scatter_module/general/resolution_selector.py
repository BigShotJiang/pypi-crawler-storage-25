from dash import dcc

from food_web_bifurcation_explorer.enums.resolutions.layout_resolutions import LayoutResolutions
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Dropdown:
    """Build and return the resolution dropdown component."""
    return dcc.Dropdown(
        id=IDs.DROPDOWN_SCATTER_SIZE,
        options=[{"label": resolution.name.capitalize(), "value": resolution.value} for resolution in LayoutResolutions],
        value=LayoutResolutions.DEFAULT,
        clearable=False,
    )
