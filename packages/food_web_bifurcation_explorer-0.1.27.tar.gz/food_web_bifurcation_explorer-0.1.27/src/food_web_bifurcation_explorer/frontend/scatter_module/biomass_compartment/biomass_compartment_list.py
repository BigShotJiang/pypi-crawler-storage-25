from food_web_bifurcation_explorer.common import glob


def get_current_compartment_list() -> list[dict[str, object]]:
    """Updates and returns the options for the compartment first dropdown."""
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    # set new options
    options = [{"label": compartments[index] + " (" + str(index + 1) + ")", "value": index} for index in range(0, len(compartments))]
    return options
