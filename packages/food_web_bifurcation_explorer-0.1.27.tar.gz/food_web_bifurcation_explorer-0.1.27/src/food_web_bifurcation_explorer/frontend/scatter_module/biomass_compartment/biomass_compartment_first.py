from dash import dcc

from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.frontend.scatter_module.biomass_compartment import biomass_compartment_list


def build() -> dcc.Dropdown:
    """Builds and returns a Dash Dropdown component for selecting the first compartment."""
    return dcc.Dropdown(
        id=IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST,
        options=biomass_compartment_list.get_current_compartment_list(),
        value=StaticOptions.DEFAULT_SCATTER_COMPARTMENT_FIRST,
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )
