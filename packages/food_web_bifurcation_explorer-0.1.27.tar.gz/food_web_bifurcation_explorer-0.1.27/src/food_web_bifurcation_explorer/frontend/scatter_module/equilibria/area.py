from dash import dcc, html

from food_web_bifurcation_explorer.enums.colors.stability_colors import StabilityColors
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.symbols import Symbols
from food_web_bifurcation_explorer.frontend.ids import IDs


# build
def build() -> dcc.Checklist:
    return dcc.Checklist(
        id=IDs.CHECKBOX_SCATTER_EQUILIBRIA_AREA,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.STABILITY_AREA,
                        # group characters
                        html.Span(
                            [
                                # first triangle
                                html.Span(
                                    Symbols.TRIANGLE,
                                    style={
                                        "color": StabilityColors.STABLE,
                                        "fontSize": Font.SIZE,
                                        "position": "relative",
                                        "clipPath": "inset(0 50% 0 0)",
                                        "display": "inline-block",
                                        "transform": "translateX(7px)",
                                    },
                                ),
                                # second triangle
                                html.Span(
                                    Symbols.TRIANGLE,
                                    style={
                                        "color": StabilityColors.UNSTABLE,
                                        "fontSize": Font.SIZE,
                                        "position": "relative",
                                        "clipPath": "inset(0 0 0 50%)",
                                        "display": "inline-block",
                                        "transform": "translateX(-7px)",
                                    },
                                ),
                            ],
                            style={"whiteSpace": "nowrap", "marginLeft": "-1px"},
                        ),
                    ]
                ),
                "value": True,
            }
        ],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
