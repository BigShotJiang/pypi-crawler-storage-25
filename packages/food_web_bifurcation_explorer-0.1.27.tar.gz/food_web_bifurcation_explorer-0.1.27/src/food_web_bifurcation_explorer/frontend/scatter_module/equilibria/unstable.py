"""Module for building the unstable equilibria checklist component."""

from dash import dcc, html

from food_web_bifurcation_explorer.enums.check_box import CheckBox
from food_web_bifurcation_explorer.enums.colors.stability_colors import StabilityColors
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.symbols import Symbols
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Checklist:
    """Build the checklist component for displaying unstable equilibria branches.

    Returns:
        dash.dcc.Checklist: A Dash checklist component for unstable equilibria.

    """
    return dcc.Checklist(
        id=IDs.CHECKBOX_SCATTER_EQUILIBRIA_UNSTABLE,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.UNSTABLE_EQUILIBRIA,
                        html.Span(
                            Symbols.CIRCLE,
                            style={
                                "color": StabilityColors.UNSTABLE,
                                "fontSize": Font.SIZE,
                                "marginLeft": CheckBox.MARGING_LEFT,
                            },
                        ),
                    ]
                ),
                "value": True,
            }
        ],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
