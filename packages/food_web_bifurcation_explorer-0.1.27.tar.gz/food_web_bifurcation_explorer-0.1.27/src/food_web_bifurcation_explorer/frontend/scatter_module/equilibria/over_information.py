from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.ids import IDs


# build
def build() -> dcc.Checklist:
    """Build the checklist component for displaying unstable equilibria branches.

    Returns:
        dash.dcc.Checklist: A Dash checklist component for unstable equilibria.

    """
    return dcc.Checklist(
        id=IDs.CHECKBOX_SCATTER_EQUILIBRIA_OVERINFORMATION,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.OVER_INFORMATION,
                    ]
                ),
                "value": True,
            }
        ],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
