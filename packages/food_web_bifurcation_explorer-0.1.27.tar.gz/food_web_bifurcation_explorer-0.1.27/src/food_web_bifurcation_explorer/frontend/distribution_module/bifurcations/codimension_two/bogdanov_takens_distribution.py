from dash import dcc, html

from food_web_bifurcation_explorer.enums.check_box import CheckBox
from food_web_bifurcation_explorer.enums.colors.bifurcation_colors import BifurcationColors
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.symbols import Symbols
from food_web_bifurcation_explorer.frontend.ids import IDs


# build
def build() -> dcc.Checklist:
    """Build and return a checklist component for bautin bifurcations."""
    return dcc.Checklist(
        id=IDs.CHECKBOX_DISTRIBUTION_BIFURCATIONS_BOGDANOV_TAKENS,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.BAUTIN,
                        html.Span(
                            Symbols.CIRCLE,
                            style={
                                "color": BifurcationColors.BAUTIN,
                                "fontSize": Font.SIZE,
                                "marginLeft": CheckBox.MARGING_LEFT,
                            },
                        ),
                    ]
                ),
                "value": True,
            }
        ],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
