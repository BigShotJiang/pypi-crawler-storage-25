import pandas as pd
import re,os,json,calendar 
from datetime import datetime, timedelta

def validate_force_fix(data, primary_key, field_names, check_params, source_path, source_type, task_id, data_table):
    # 仅返回空错误，不做任何逐行检查，直接触发修复
    return data, []

def fix_generic_batch(data, primary_key, field_names, fix_params, source_path, source_type, task_id, data_table, checked_output_path):
    # 你的原通用修复函数，完全不变！！！
    fixes = []
    target_field = field_names[0]
    process_func_name = fix_params.get("process_func")
    
    if target_field not in data.columns or not process_func_name:
        return data, fixes
    try:
        process_func = globals()[process_func_name]
    except KeyError:
        print(f"未找到处理函数：{process_func_name}")
        return data, fixes

    # 核心：调用全表处理函数
    data = process_func(data)
    
    fixes.append({
        "task_id": task_id,
        "msg": f"通用处理完成 | 字段：{target_field} | 函数：{process_func_name} | 行数：{len(data)}"
    })
    return data, fixes

def letter_to_num(char):
    if not char or not char.isalpha():
        return 0
    return ord(char.upper()) - ord('A') + 1

def record_filter_page_value(input_str, type_val):
    # 你的原代码，完全不变
    if type_val not in ["segment", "number"]:
        raise ValueError("type_val 只能是 segment 或 number")
    s = str(input_str).strip()
    s = s.replace('——', '-').replace('—', '-')
    if not s: return 1

    if "册" in s or "本" in s:
        s_clean = s.replace("册", "").replace("本", "").strip()
        if "+" in s_clean:
            try:
                n1, n2 = map(int, s_clean.split("+"))
                return max(n1+n2,1)
            except: return 1
        if s_clean.isdigit():
            return 1 if type_val=="segment" else max(int(s_clean),1)

    pattern1 = re.fullmatch(r"(\d+)([A-Za-z])", s)
    pattern2 = re.fullmatch(r"(\d+)-(\d+)([A-Za-z])", s)
    pattern3 = re.fullmatch(r"(\d+)([A-Za-z])-(\d+)", s)
    pattern4 = re.fullmatch(r"(\d+)([A-Za-z])-(\d+)([A-Za-z])", s)

    if pattern1:
        num, lv = int(pattern1.group(1)), letter_to_num(pattern1.group(2))
        return 1 if type_val=="segment" else max(num+lv,1)
    if pattern2:
        h,t,lv = int(pattern2.group(1)),int(pattern2.group(2)),letter_to_num(pattern2.group(3))
        return max((t+lv)-h+1,1) if type_val=="segment" else 1
    if pattern3:
        h,lv,t = int(pattern3.group(1)),letter_to_num(pattern3.group(2)),int(pattern3.group(3))
        return max(t-(h+lv)+1,1) if type_val=="segment" else 1
    if pattern4:
        hn,hl,tn,tl = int(pattern4.group(1)),letter_to_num(pattern4.group(2)),int(pattern4.group(3)),letter_to_num(pattern4.group(4))
        return max((tn+tl)-(hn+hl)+1,1) if type_val=="segment" else 1

    if "-" in s:
        try:
            h,t = map(int, s.split("-"))
            return max(t-h+1,1)
        except: return 1
    if s.isdigit():
        return 1 if type_val=="segment" else max(int(s),1)
    return 1

def check_page_type_by_group(df):
    # 按档号分组标记页数类型
    pattern = re.compile(r"\d+[-—–]+\d+")
    df["_is_seg"] = df["页数"].astype(str).str.contains(pattern, regex=True)
    df["页数类型"] = df.groupby("档号")["_is_seg"].transform(any).map({True:"segment", False:"number"})
    df.drop(columns=["_is_seg"], inplace=True)
    return df

# 封装record全表页码处理函数（供 fix_generic_batch 调用）
def process_page_all(df):
    """
    完整页码处理：按档号分组 → 标记类型 → 重算页数
    这是一个接收/返回 DataFrame 的函数，完美适配 fix_generic_batch
    """
    df = check_page_type_by_group(df)
    df["页数"] = df.apply(lambda row: record_filter_page_value(row["页数"], row["页数类型"]), axis=1)
    return df

# 案卷页码处理函数
def file_filter_page_value(input_str):
    s = input_str.strip()
    s = s.replace('——', '-').replace('—', '-')
    if not s:
        return 1
    match = re.fullmatch(r'(\d+)[册本]', s)
    if match:
        return max(int(match.group(1)), 1)
    if '册' in s or '本' in s:
        num_str = s.replace("册", "").replace("本", "").strip()
        num1, num2 = num_str.split('+')
        return max(int(num1) + int(num2), 1)
    if '-' in s:
        head_num, tail_num = s.split('-')
        return max(int(tail_num) - int(head_num) + 1, 1)
    if s.isdigit():
        return max(int(s), 1)
    return 1

# 页码修复函数
def fix_file_field_page_value(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    fixes = []
    error_level = fix_params.get("level", "")
    handle_suggestion = fix_params.get("handle_suggestion", "")
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")

    try:
        for field in field_names:
            data[field] = data[field].astype(object)

        for index, row in data.iterrows():
            for field in field_names:
                raw_value = row[field]
                raw_value = "" if pd.isna(raw_value) else raw_value
                
                # 核心修复逻辑
                fixed_num = file_filter_page_value(str(raw_value))
                original_value = raw_value

                if str(original_value) != str(fixed_num):
                    data.at[index, field] = fixed_num
                    fixes.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table": data_table,
                        "datetime": current_datetime,
                        "error_id": "PAGE-01",
                        "error_type": "Page Format Error",
                        "level": error_level,
                        "handling_status": "AUTO_FIXED",
                        "resolution": f"页码格式化：{original_value} → {fixed_num}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[archive_number],
                            "affected_field": field,
                            "current_value": fixed_num,
                            "original": data_table,
                            "checked_output_path": checked_output_path,
                            "checked_id": row[primary_key]
                        }
                    })
    except Exception as e:
        print(f"页码修复错误: {e}")

    return data, fixes

# 检查函数：验证指定字段的值是否为空
def validate_field_empty(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段是否存在空值（null 或空字符串）。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查空值的字段名列表。
    check_params (dict): 检查参数，包含错误等级和处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 当前任务的 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        for index, row in data.iterrows():
            for field in field_names:
                value = row[field]
                # 检查值是否为 NaN（缺失值）或者是空字符串（去除前后空格后）
                if pd.isna(value) or (isinstance(value, str) and value.strip() == ""):
                    errors.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "CMP-01",
                        "error_type": "Completeness Error",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"Missing mandatory field: {field}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[archive_number],
                            "affected_field": field,
                            "current_value": row[field],
                            "original":data_table
                        }
                    })
    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


# 修复函数：修正空值
def fix_field_empty(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    """
    此函数用于修复指定 DataFrame 中特定字段的空值。

    参数:
    data (pandas.DataFrame): 要修复的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要修复空值的字段名列表。
    fix_params (dict): 修复参数，包含默认值和处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 当前任务的 ID

    返回:
    tuple: 包含修复后的 DataFrame 和修复信息列表的元组。
    """
    fixes = []
    # 从配置文件获取默认值
    default_value = fix_params["default_value"]
    # 从配置文件获取处理建议
    handle_suggestion = fix_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")
    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        rows_to_delete = []
        for field in field_names:
            # 将列的数据类型转换为 object 类型，以支持任意类型的默认值填充
            data[field] = data[field].astype(object)

        for index, row in data.iterrows():
            for field in field_names:
                value = row[field]
                # 检查值是否为 NaN（缺失值）或者是空字符串（去除前后空格后）
                if pd.isna(value) or (isinstance(value, str) and value.strip() == ""):
                    if handle_suggestion == "delete":
                        rows_to_delete.append(index)
                        fixes.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "CMP-01",
                            "error_type": "Completeness Error",
                            "level": error_level,
                            "handling_status": "DELETED",
                            "resolution": f"Record with missing value in {field} deleted.",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number],
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":row[primary_key]
                            }
                        })
                    else:
                        data.at[index, field] = default_value
                        fixes.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "CMP-01",
                            "error_type": "Completeness Error",
                            "level": error_level,
                            "handling_status": "AUTO_FIXED",
                            "resolution": f"Missing value in {field} replaced with default: {default_value}",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number],
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":row[primary_key]
                            }
                        })
        # 删除有问题的行
        if rows_to_delete:
            data = data.drop(rows_to_delete)
    except Exception as e:
        print(f"发生错误: {e}")

    return data, fixes

# 检查函数：验证指定字段的值是否符合正则表达式
def validate_field_regex(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    errors = []
    # 从配置文件获取正则表达式
    expected_pattern = check_params["expected_pattern"]
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    for index, row in data.iterrows():
        for field in field_names:
            try:
                # 尝试将当前值转换为字符串
                value = str(row[field]) if pd.notna(row[field]) else ""
                # 检查值是否匹配正则表达式
                if not re.fullmatch(expected_pattern, value):
                    errors.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "error_id": "FMT-04",
                        "error_type": "Format Error",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"Invalid format in {field}",
                        "datetime": current_datetime,
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "affected_field": field,
                            "current_value": value,
                            "expected_pattern": expected_pattern,
                            "original":data_table
                        }
                    })
            except Exception as e:
                # 处理异常情况，如无法转换为字符串
                errors.append({
                    "task_id": task_id,
                    "source_type": source_type,
                    "source_path": source_path,
                    "data_table":data_table,
                    "error_id": "FMT-04-E",
                    "error_type": "Format Error",
                    "level": error_level,
                    "handling_status": "check",
                    "datetime": current_datetime,
                    "handle_suggestion": handle_suggestion,
                    "error_reason": f"Error processing {field}: {str(e)}",
                    "record_info": {
                        "primary_key": row[primary_key],
                        "affected_field": field,
                        "current_value": str(row[field]) if pd.notna(row[field]) else "",
                        "expected_pattern": expected_pattern,
                        "original":data_table
                    }
                })
    return data, errors

# 修复函数：修正不符合正则表达式的值
def fix_field_date_format(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    fixes = []
    # 从配置文件获取错误等级
    error_level = fix_params.get("level", "")
    # 从配置文件获取默认值
    default_date = fix_params["default_date"]
    # 从配置文件获取处理建议
    handle_suggestion = fix_params.get("handle_suggestion", "")
    type = fix_params.get("type", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")
    for field in field_names:
        # 将列的数据类型转换为 object 类型
        data[field] = data[field].astype(object)

    for index, row in data.iterrows():
        for field in field_names:
            try:
                # 尝试将当前值转换为字符串
                value = str(row[field])
                # 调用 convert_to_yyyymmdd 函数进行日期格式转换
                fixed_value = convert_to_yyyymmdd(value,type)
                if "Error" in fixed_value:
                    # 如果转换失败，使用默认日期
                    data.at[index, field] = default_date
                    fixes.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-04",
                        "error_type": "Format Error",
                        "level": error_level,
                        "error_reason": f"Invalid format in {field}",
                        "handle_suggestion": handle_suggestion,
                        "handling_status": "AUTO_FIXED",
                        "resolution": f"Date format conversion failed, replaced with default: {default_date}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number],
                                "affected_field": field,
                                "current_value": value,
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":row[primary_key]
                        }
                    })
                else:
                    # 如果转换成功，更新数据
                    data.at[index, field] = fixed_value
                    if value != fixed_value:
                        fixes.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "FMT-04",
                            "error_type": "Format Error",
                            "level": error_level,
                            "error_reason": f"Invalid format in {field}",
                            "handling_status": "AUTO_FIXED",
                            "resolution": f"Converted date format from {value} to {fixed_value}",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number],
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":row[primary_key]
                        }
                        })
            except Exception as e:
                # 处理异常情况，如无法转换为字符串
                data.at[index, field] = default_date
                fixes.append({
                    "task_id": task_id,
                    "source_type": source_type,
                    "source_path": source_path,
                    "data_table":data_table,
                    "datetime": current_datetime,
                    "error_id": "FMT-04-E",
                    "error_type": "Format Error",
                    "level": error_level,
                    "error_reason": f"Invalid format in {field}",
                    "handling_status": "AUTO_FIXED",
                    "resolution": f"Error processing {field}: {str(e)}, replaced with default: {default_date}",
                    "handle_suggestion": handle_suggestion,
                    "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number],
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table
                        }
                })
    return data, fixes
def preprocess_classifyCode_string(s):
    if not s or pd.isna(s):
        return ""
    s = str(s).upper()
    s = s.replace(" ", "")
    
    # 👇 关键：先把所有异形横杠 统一 变成标准短横杠 -
    s = re.sub(r'[_—–―−－━]', '-', s)  # 统一所有横杠/下划线为 -
    
    # 👇 你原来的逻辑（完全不变）
    s = re.sub(r'-[A-Z0-9]', '', s)   # 去掉 -字母 / -数字
    s = s.strip("-/.")                # 去掉首尾 - / .
    
    return s
def fix_classification_code(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    fixes = []
    # 从配置获取参数（和你现有函数一致）
    error_level = fix_params.get("level", "")
    handle_suggestion = fix_params.get("handle_suggestion", "")
    archive_number = fix_params.get("archive_number", "")
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 统一字段类型
    for field in field_names:
        data[field] = data[field].astype(object)

    # 逐行处理（你要求：每行都调用 clean 函数）
    for index, row in data.iterrows():
        for field in field_names:
            try:
                # 取值
                value = str(row[field]) if pd.notna(row[field]) else ""

                # ======================
                # 核心：调用清洗函数
                # ======================
                fixed_value = preprocess_classifyCode_string(value)

                # 覆盖到数据表
                data.at[index, field] = fixed_value

                # 只要值发生变化，就记录修复日志
                if value != fixed_value:
                    fixes.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table": data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-04",
                        "error_type": "Format Error",
                        "level": error_level,
                        "error_reason": f"Invalid format in {field}",
                        "handling_status": "AUTO_FIXED",
                        "resolution": f"Cleaned classification code from '{value}' to '{fixed_value}'",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[archive_number] if archive_number in row else "",
                            "affected_field": field,
                            "current_value": fixed_value,
                            "original": data_table,
                            "checked_output_path": checked_output_path,
                            "checked_id": row[primary_key]
                        }
                    })

            except Exception as e:
                # 异常处理（保持和你原函数一致）
                fixes.append({
                    "task_id": task_id,
                    "source_type": source_type,
                    "source_path": source_path,
                    "data_table": data_table,
                    "datetime": current_datetime,
                    "error_id": "FMT-04-E",
                    "error_type": "Format Error",
                    "level": error_level,
                    "error_reason": f"Error processing {field}",
                    "handling_status": "AUTO_FIXED",
                    "resolution": f"Clean failed: {str(e)}, kept original value",
                    "handle_suggestion": handle_suggestion,
                    "record_info": {
                        "primary_key": row[primary_key],
                        "archive_number": row[archive_number] if archive_number in row else "",
                        "affected_field": field,
                        "current_value": value,
                        "original": data_table,
                        "checked_output_path": checked_output_path,
                        "checked_id": row[primary_key]
                    }
                })

    return data, fixes
def _clean_date_preprocess(date_str: str) -> str:
    """
    私有预处理函数：单一职责
    1. 去除所有空格
    2. 统一所有横杠（全角/半角/下划线）为英文横杠 -
    3. 统一日期分隔符 / . 为 -
    """
    if not isinstance(date_str, str):
        return ""
    # 去除所有空格
    s = date_str.replace(" ", "")
    # 替换全角横杠、下划线等为标准英文横杠
    s = re.sub(r'[_—－——]', '-', s)
    # 去掉字符串首尾的 . - /
    s = s.strip('./-')
    # 删除末尾 **两个及以上 0**，只删结尾，不影响其他位置
    if not re.fullmatch(r'\d{4}-\d{4}', s):
        s = re.sub(r'0{2,}$', '', s)
    return s

def get_year_start(cleaned):
    return f"{cleaned}0101"

def get_year_end(cleaned):
    return f"{cleaned}1231"

def get_month_start(cleaned):
        
# 1. 删除末尾所有字母
    while len(cleaned) > 0 and cleaned[-1].isalpha():
        cleaned = cleaned[:-1]
    # 2. 删除末尾所有 ./- 符号
    while len(cleaned) > 0 and cleaned[-1] in ('.', '-', '/'):
        cleaned = cleaned[:-1]
    ym = cleaned.replace('.', '').replace('-', '').replace('/', '')
    return f"{ym[:4]}{ym[4:].zfill(2)}01"

def get_month_end(cleaned):
    # 1. 删除末尾所有字母
    while len(cleaned) > 0 and cleaned[-1].isalpha():
        cleaned = cleaned[:-1]
    # 2. 删除末尾所有 ./- 符号
    while len(cleaned) > 0 and cleaned[-1] in ('.', '-', '/'):
        cleaned = cleaned[:-1]
    ym = cleaned.replace('.', '').replace('-', '').replace('/', '')
    year = int(ym[:4])
    month = int(ym[4:])
    last_day = calendar.monthrange(year, month)[1]
    return f"{year}{month:02d}{last_day:02d}"

def get_date_standard(cleaned):
    y, m, d = re.split(r'[./-]', cleaned)
    return f"{y}{m.zfill(2)}{d.zfill(2)}"
    
def handle_start(cleaned, pattern_type, match):
    """统一处理所有 start：自动根据模式选择逻辑"""
    if pattern_type == 1:
        return get_year_start(cleaned)
    elif pattern_type == 2:
        return get_month_start(cleaned)
    elif pattern_type == 4:
        return get_date_standard(cleaned)
    elif pattern_type == 5:
        return cleaned
    elif pattern_type == 3:
        return get_year_start(match.group(1))
    elif pattern_type == 6:
        return get_month_start(f"{match.group(1)}.{match.group(2)}")
    elif pattern_type == 7:
        return get_month_start(f"{match.group(1)}.{match.group(2)}")
    elif pattern_type == 8:
        # 左边年月日直接拼接 → 标准化输出
        return get_date_standard(f"{match.group(1)}.{match.group(2)}.{match.group(3)}")
    elif pattern_type == 9:
        # 左边年月 → 月初 1 号
        return get_month_start(f"{match.group(1)}.{match.group(2)}")
    elif pattern_type == 10:
        return get_month_start(f"{match.group(1)}.{match.group(2)}")
    elif pattern_type == 11:
        return get_year_start(match.group(1))
    elif pattern_type == 12:
        return get_month_start(f"{match.group(1)}.{match.group(2)}")
    elif pattern_type == 13:
        return get_month_start(f"{match.group(1)}.{match.group(2)}")
    return ""


def handle_end(cleaned, pattern_type, match):
    """统一处理所有 end：自动根据模式选择逻辑"""
    if pattern_type == 1:
        return get_year_end(cleaned)
    elif pattern_type == 2:
        return get_month_end(cleaned)
    elif pattern_type == 4:
        return get_date_standard(cleaned)
    elif pattern_type == 5:
        return cleaned
    elif pattern_type == 3:
        return get_year_end(match.group(2))
    elif pattern_type == 6:
        return get_date_standard(f"{match.group(3)}.{match.group(4)}.{match.group(5)}")
    elif pattern_type == 7:
        return get_month_end(f"{match.group(3)}.{match.group(4)}")
    elif pattern_type == 8:
        # 右边年月日直接拼接 → 标准化输出
        return get_date_standard(f"{match.group(4)}.{match.group(5)}.{match.group(6)}")
    elif pattern_type == 9:
        # 右边年月 → 月末
        return get_month_end(f"{match.group(3)}.{match.group(4)}")
    elif pattern_type == 10:
        return get_month_end(f"{match.group(1)}.{match.group(3)}")
    elif pattern_type == 11:
        return get_month_end(f"{match.group(2)}.{match.group(3)}")
    elif pattern_type == 12:
        return get_date_standard(f"{match.group(3)}.{match.group(4)}.{match.group(5)}")
    elif pattern_type == 13:
        return get_date_standard(f"{match.group(3)}.{match.group(4)}.{match.group(5)}")
    return ""

PATTERN_MAP = [
    # 1
    (r'^(19\d{2}|2\d{3})$', handle_start, handle_end, 'YYYY', 1),
    # 2
    (r'^(19\d{2}|2\d{3})[./-]?(0?[1-9]|1[0-2])$', handle_start, handle_end, '纯6位数字日期 YYYYMM', 2),
    # 3
    (r'^(19\d{2}|2\d{3})-(19\d{2}|2\d{3})$', handle_start, handle_end, '匹配 YYYY-YYYY', 3),
    # 4
    (r'^(19\d{2}|2\d{3})[./-](0?[1-9]|1[0-2])[./-](3[01]|[12]\d|0?[1-9])$', handle_start, handle_end, '匹配 YYYY.M.D 支持./-分隔符', 4),
    # 5
    (r'^(19\d{2}|2\d{3})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])$', handle_start, handle_end, '纯8位数字日期 YYYYMMDD', 5),
    # 6
    (r'^(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])[./][A-Za-z]{1}-(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])[./](3[01]|[12]\d|0?[1-9])$', handle_start, handle_end, '匹配 YYYY.MM.字母-YYYY.MM.DD', 6),
    # 7
    (r'^(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])[./][A-Za-z]{1}-(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])[./][A-Za-z]{1}$', handle_start, handle_end, '匹配 YYYY.MM.字母-YYYY.MM.字母', 7),
    # 8
    (r'^(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])[./](3[01]|[12]\d|0?[1-9])\.?-(19\d{2}|2\d{3})[./-](0?[1-9]|1[0-2])[./-](3[01]|[12]\d|0?[1-9])$', handle_start, handle_end, '匹配 YYYY.MM.DD-YYYY.MM.DD', 8),
    # 9
    (r'^(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])-(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])$', handle_start, handle_end, '匹配 YYYY.M-YYYY.M', 9),
    # 10
    (r'^(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])-(0?[1-9]|1[0-2])$', handle_start, handle_end, '匹配 YYYY.MM-MM', 10),
    # 11
    (r'^(19\d{2}|2\d{3})-(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])$', handle_start, handle_end, '匹配 YYYY-YYYY.MM', 11),
    # 12
    (r'^(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])-(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])[./](3[01]|[12]\d|0?[1-9])$', handle_start, handle_end, '匹配 YYYY.MM-YYYY.MM.DD', 12),
    # 13
    (r'^(19\d{2}|2\d{3})[./](0[1-9]|1[0-2])(19\d{2}|2\d{3})[./](0?[1-9]|1[0-2])[./](3[01]|[12]\d|0?[1-9])$', handle_start, handle_end, '匹配 YYYY.MMYYYY.MM.DD 无间隔连接', 13),
]


def convert_to_yyyymmdd(date_str: str, type: str):
    cleaned = _clean_date_preprocess(date_str)
    if not cleaned:
        return ""  
    
    for pattern, funcA, funcB, desc, pattern_type in PATTERN_MAP:
        # 先拿到 match 对象
        match = re.fullmatch(pattern, cleaned)
        if match:
            if type == "start":
                # 传给函数：cleaned, pattern_type, match
                return funcA(cleaned, pattern_type, match)
            elif type == "end":
                return funcB(cleaned, pattern_type, match)
    
    return ""

# 检查函数：验证指定字段的值是否重复
def validate_field_duplicate(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段是否存在重复值。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查重复值的字段名列表。
    check_params (dict): 检查参数，包含错误等级和处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        for field in field_names:
            # 统计每列中每个值的出现次数
            value_counts = data[field].value_counts()
            # 筛选出出现次数大于 1 的值（即重复值）
            duplicate_values = value_counts[value_counts > 1].index

            for value in duplicate_values:
                # 找到该重复值在 DataFrame 中的所有行索引
                rows = data[data[field] == value].index
                for row in rows:
                    errors.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "DUP-01",
                        "error_type": "Data Error",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"Duplicate value detected in {field}: {value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": data.at[row, primary_key],
                            "archive_number": data.at[row, archive_number] if archive_number in data.columns else "",
                            "affected_field": field,
                            "current_value": value,
                            "original":data_table
                        },
                    })
    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


# 修复函数：修正重复值
def fix_field_duplicate(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    """
    此函数用于修复指定 DataFrame 中特定字段的重复值。

    参数:
    data (pandas.DataFrame): 要修复的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要修复重复值的字段名列表。
    fix_params (dict): 修复参数，包含默认值和处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含修复后的 DataFrame 和修复信息列表的元组。
    """
    fixes = []
    # 从配置文件获取默认值
    default_value = fix_params["default_value"]
    # 从配置文件获取处理建议
    handle_suggestion = fix_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        rows_to_delete = []
        for field in field_names:
            # 统计每列中每个值的出现次数
            value_counts = data[field].value_counts()
            # 筛选出出现次数大于 1 的值（即重复值）
            duplicate_values = value_counts[value_counts > 1].index

            for value in duplicate_values:
                # 找到该重复值在 DataFrame 中的所有行索引
                rows = data[data[field] == value].index
                for row in rows:
                    if handle_suggestion == "delete":
                        rows_to_delete.append(row)
                        fixes.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "DUP-01",
                            "error_type": "Data Error",
                            "level": error_level,
                             "error_reason": f"Duplicate value detected in {field}: {value}",
                            "handling_status": "DELETED",
                            "resolution": f"Record with duplicate value in {field}: {value} deleted.",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": data.at[row, primary_key],
                                "archive_number": data.at[row, archive_number] if archive_number in data.columns else "",
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":data.at[row, primary_key]
                        },
                        })
                    else:
                        data.at[row, field] = default_value
                        fixes.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "DUP-01",
                            "error_type": "Data Error",
                            "level": error_level,
                            "error_reason": f"Duplicate value detected in {field}: {value}",
                            "handling_status": "AUTO_FIXED",
                            "resolution": f"Duplicate value in {field}: {value} replaced with default: {default_value}",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": data.at[row, primary_key],
                                "archive_number": data.at[row, archive_number] if archive_number in data.columns else "",
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":data.at[row, primary_key]
                        }
                        })

        # 删除有问题的行
        if rows_to_delete:
            data = data.drop(rows_to_delete)
    except Exception as e:
        print(f"发生错误: {e}")

    return data, fixes


# 检查函数：验证指定字段的值是否存在多余空格
def validate_field_extra_spaces(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段是否存在多余空格。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查多余空格的字段名列表。
    check_params (dict): 检查参数，包含错误等级和处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        pattern = re.compile(r'\s{2,}')
        for index, row in data.iterrows():
            for field in field_names:
                value = row[field]
                if isinstance(value, str) and pattern.search(value):
                    errors.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-03",
                        "error_type": "Format Error",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"Extra spaces detected in {field}: {value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[archive_number] if archive_number in data.columns else "",
                            "affected_field": field,
                            "current_value": value,
                            "original":data_table
                        }
                    })
    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


# 修复函数：修正多余空格
def fix_field_extra_spaces(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    """
    此函数用于修复指定 DataFrame 中特定字段的多余空格。

    参数:
    data (pandas.DataFrame): 要修复的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要修复多余空格的字段名列表。
    fix_params (dict): 修复参数，包含默认值和处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含修复后的 DataFrame 和修复信息列表的元组。
    """
    fixes = []
    # 从配置文件获取处理建议
    handle_suggestion = fix_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")
    # 从配置文件获取错误等级
    error_level = fix_params.get("level", "")
    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        pattern = re.compile(r'\s+')
        for index, row in data.iterrows():
            for field in field_names:
                value = row[field]
                if isinstance(value, str) and pattern.search(value):
                    fixed_value = pattern.sub('', value).strip()
                    data.at[index, field] = fixed_value
                    fixes.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-03",
                        "error_type": "Format Error",
                        "level": error_level,
                        "error_reason": f"Extra spaces detected in {field}: {value}",
                        "handling_status": "AUTO_FIXED",
                        "resolution": f"Extra spaces in {field}: {value} removed, new value: {fixed_value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number] if archive_number in data.columns else "",
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":row[primary_key]
                        }
                    })
    except Exception as e:
        print(f"发生错误: {e}")

    return data, fixes


# 检查函数：验证指定字段的值是否为浮点数
def validate_field_float(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段是否存在浮点数。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查浮点数的字段名列表。
    check_params (dict): 检查参数，包含错误等级和处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        for index, row in data.iterrows():
            for field in field_names:
                value = row[field]
                # 检查值是否为浮点数
                if isinstance(value, float):
                    errors.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-01",
                        "error_type": "Format Error",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"Field {field} contains a floating-point number: {value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[archive_number],
                            "affected_field": field,
                            "current_value": row[field],
                            "original":data_table
                        }
                    })
    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


# 修复函数：将浮点数转换为整数
def fix_field_float(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    """
    此函数用于修复指定 DataFrame 中特定字段的浮点数。

    参数:
    data (pandas.DataFrame): 要修复的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要修复浮点数的字段名列表。
    fix_params (dict): 修复参数，包含处理建议。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含修复后的 DataFrame 和修复信息列表的元组。
    """
    fixes = []
    # 从配置文件获取错误等级
    error_level = fix_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = fix_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")
    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        for index, row in data.iterrows():
            for field in field_names:
                value = row[field]
                # 检查值是否为浮点数
                if isinstance(value, float):
                    new_value = int(value)
                    data.at[index, field] = new_value
                    fixes.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-01",
                        "error_type": "Format Error",
                        "level": error_level,
                        "error_reason": f"Field {field} contains a floating-point number: {value}",
                        "handling_status": "AUTO_FIXED",
                        "resolution": f"Floating-point number {value} in {field} converted to integer: {new_value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[archive_number],
                            "affected_field": field,
                            "current_value": row[field],
                            "original":data_table,
                            "checked_output_path":checked_output_path,
                            "checked_id":row[primary_key]
                        }
                    })
    except Exception as e:
        print(f"发生错误: {e}")

    return data, fixes


# 检查函数：验证指定字段的值是否以字符串存储数字且存在前缀0
def validate_field_leading_zeros(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段是否以字符串存储数字且存在前缀0，
    同时检查 daCode 字段值的最后一个点后面的字符串是否存在前缀0。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查前缀0的字段名列表。
    check_params (dict): 检查参数，包含错误等级、处理建议和 daCode 字段。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")
    daCode = check_params.get("daCode", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")
        # 检查 daCode 字段是否存在于 DataFrame 中
        if daCode and daCode not in data.columns:
            raise ValueError(f"daCode 字段 '{daCode}' 不在 DataFrame 的列中。")

        for index, row in data.iterrows():
            for field in field_names:
                value = row[field]
                # 检查值是否为字符串且以 0 开头
                if isinstance(value, str) and value.startswith('0') and value.strip('0').isdigit():
                    errors.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-01",
                        "error_type": "Format Error",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"Field {field} contains a string with leading zeros: {value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[archive_number],
                            "affected_field": field,
                            "current_value": row[field],
                            "original":data_table
                        }
                    })

            if daCode:
                daCode_value = row[daCode]
                if isinstance(daCode_value, str) and '.' in daCode_value:
                    last_dot_index = daCode_value.rfind('.')
                    part_after_dot = daCode_value[last_dot_index + 1:]
                    if part_after_dot.startswith('0') and part_after_dot.strip('0').isdigit():
                        errors.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "FMT-01",
                            "error_type": "Format Error",
                            "level": error_level,
                            "handling_status": "check",
                            "error_reason": f"daCode field {daCode} contains a string with leading zeros after the last dot: {daCode_value}",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number],
                                "affected_field": daCode,
                                "current_value": row[daCode],
                                "original":data_table
                            }
                        })

    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


# 修复函数：去除指定字段值的前缀0
def fix_field_leading_zeros(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    """
    此函数用于修复指定 DataFrame 中特定字段以字符串存储数字的前缀0，
    同时去除 daCode 字段值的最后一个点后面的字符串的前缀0。

    参数:
    data (pandas.DataFrame): 要修复的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要修复前缀0的字段名列表。
    fix_params (dict): 修复参数，包含处理建议和 daCode 字段。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含修复后的 DataFrame 和修复信息列表的元组。
    """
    fixes = []
    # 从配置文件获取错误等级
    error_level = fix_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = fix_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")
    daCode = fix_params.get("daCode", "")

    def process_string(s):
        """处理普通列的前导零"""
        try:
            return str(int(str(s))) if pd.notnull(s) else s
        except (ValueError, TypeError):
            return s

    # def process_da_code(s):
    #     """处理daCode字段的特殊规则，去除最后一个点后面的前缀0"""
    #     if isinstance(s, str) and '.' in s:
    #         last_dot_index = s.rfind('.')
    #         left_part = s[:last_dot_index]
    #         right_part = s[last_dot_index + 1:]
    #         stripped_right = right_part.lstrip('0')
    #         if not stripped_right:
    #             stripped_right = '0'
    #         return f"{left_part}.{stripped_right}"
    #     return s
    def process_da_code(s):
        # 极简逻辑：只处理最后一个横杠后面的内容
        if not isinstance(s, str):
            return s
        # 拆分：最后一个-前面的所有内容 + 最后一段
        parts = s.rsplit('-', 1)
        if len(parts) == 1:
            return s
        front, last = parts[0], parts[1]
        # 只处理最后一段的小数点后0
        if '.' in last:
            num, suffix = last.rsplit('.', 1)
            last = f"{num}.{suffix.lstrip('0')}" if suffix.lstrip('0') else f"{num}.0"
        # 拼接回去，前面完全不变
        return f"{front}-{last}"
    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")
        # 检查 daCode 字段是否存在于 DataFrame 中
        if daCode and daCode not in data.columns:
            raise ValueError(f"daCode 字段 '{daCode}' 不在 DataFrame 的列中。")

        # 处理常规列的前导零
        for col in field_names:
            if col in data.columns:
                for index, value in data[col].items():
                    if isinstance(value, str) and value.startswith('0') and value.strip('0').isdigit():
                        new_value = process_string(value)
                        data.at[index, col] = new_value
                        fixes.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "FMT-01",
                            "error_type": "Format Error",
                            "level": error_level,
                            "handling_status": "AUTO_FIXED",
                            "error_reason": f"Field {field} contains a string with leading zeros: {value}",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": data.at[index, primary_key],
                                "archive_number": data.at[index, archive_number],
                                "affected_field": field,
                                "current_value": data.at[index, field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":data.at[index, primary_key]
                        }
                    })
            else:
                print(f"警告: 列 '{col}' 不存在，已跳过")

        # 处理daCode字段
        if daCode in data.columns:
            for index, value in data[daCode].items():
                new_value = process_da_code(value)
                if new_value != value:
                    data.at[index, daCode] = new_value
                    fixes.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-01",
                        "error_type": "Format Error",
                        "level": error_level,
                        "error_reason": f"daCode field {daCode} contains a string with leading zeros after the last dot: {value}",
                        "handling_status": "AUTO_FIXED",
                        "resolution": f"Leading zeros in {daCode} after the last dot removed: {value} -> {new_value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                                "primary_key": data.at[index, primary_key],
                                "archive_number": data.at[index, archive_number],
                                "affected_field": field,
                                "current_value": data.at[index, field],
                                "original":data_table,
                                "checked_output_path":checked_output_path,
                                "checked_id":data.at[index, primary_key]
                        }
                        
                    })
        else:
            print(f"警告: daCode列 '{daCode}' 不存在，已跳过")

    except Exception as e:
        print(f"发生错误: {e}")

    return data, fixes


def trim_leading_zeros(s):
    # 分割最后一个点的位置
    last_dot_idx = s.rfind('.')

    # 处理无点或点在末尾的特殊情况
    if last_dot_idx == -1 or last_dot_idx == len(s) - 1:
        return s

    left_part = s[:last_dot_idx]
    right_part = s[last_dot_idx + 1:]

    # 去除右侧部分的前导零
    stripped_right = right_part.lstrip('0')
    if not stripped_right:
        stripped_right = '0'

    return f"{left_part}.{stripped_right}"


# 检查函数：验证指定字段的值是否缺失后缀0
def validate_field_missing_trailing_zeros(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段的流水号序列是否缺失后缀0。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查缺失后缀0的字段名列表。
    check_params (dict): 检查参数，包含错误等级、处理建议和 daCode 字段。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")
    daCode = check_params.get("daCode", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")
        # 检查 daCode 字段是否存在于 DataFrame 中
        if daCode and daCode not in data.columns:
            raise ValueError(f"daCode 字段 '{daCode}' 不在 DataFrame 的列中。")

        for field in field_names:
            for i in range(1, len(data) - 1):
                try:
                    prev_num = int(data.at[i - 1, field])
                    current_num = int(data.at[i, field])
                    next_num = int(data.at[i + 1, field])

                    if prev_num + 1 != current_num and next_num - 1 != current_num:
                        errors.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "FMT-02",
                            "error_type": "Format Error",
                            "level": error_level,
                            "handling_status": "check",
                            "error_reason": f"Field {field} at row {i} is missing trailing zeros: {current_num}",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": data.at[i, primary_key],
                                "archive_number": data.at[i, archive_number],
                                "affected_field": field,
                                "current_value": str(current_num),
                                "original":data_table
                            }
                        })
                except ValueError:
                    continue

    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


# 修复函数：修正缺失后缀0的情况
def fix_field_missing_trailing_zeros(
    data,
    primary_key,
    field_names,
    fix_params,
    source_path,
    source_type,
    task_id,
    data_table,
    checked_output_path
):
    """
    此函数用于修复指定 DataFrame 中特定字段流水号序列缺失后缀0的情况，同时处理 daCode 字段。

    参数:
    data (pandas.DataFrame): 要修复的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要修复缺失后缀0的字段名列表。
    fix_params (dict): 修复参数，包含处理建议和 daCode 字段。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含修复后的 DataFrame 和修复信息列表的元组。
    """
    fixes = []
    # 从配置文件获取错误等级
    error_level = fix_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = fix_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = fix_params.get("archive_number", "")
    daCode = fix_params.get("daCode", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        for field in field_names:
            if field not in data.columns:
                raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")
        # 检查 daCode 字段是否存在于 DataFrame 中
        if daCode and daCode not in data.columns:
            raise ValueError(f"daCode 字段 '{daCode}' 不在 DataFrame 的列中。")

        zero_counts = {}  # 记录每个行补零次数

        for field in field_names:
            for i in range(1, len(data) - 1):
                try:
                    prev_num = int(data.at[i - 1, field])
                    current_num = int(data.at[i, field])
                    next_num = int(data.at[i + 1, field])

                    if prev_num + 1 != current_num and next_num - 1 != current_num:
                        num_str = str(current_num)
                        k = 0
                        max_attempts = 10  # 防止无限循环
                        while k < max_attempts:
                            num_str += '0'
                            k += 1
                            try:
                                new_num = int(num_str)
                            except ValueError:
                                break  # 无法转换时停止
                            # 检查是否在前后数值之间
                            if prev_num < new_num < next_num:
                                original_value = str(data.at[i, field])
                                data.at[i, field] = new_num
                                fixes.append({
                                    "task_id": task_id,
                                    "source_type": source_type,
                                    "source_path": source_path,
                                    "data_table":data_table,
                                    "datetime": current_datetime,
                                    "error_id": "FMT-02",
                                    "error_type": "Format Error",
                                    "level": error_level,
                                    "error_reason": f"Field {field} at row {i} is missing trailing zeros: {current_num}",
                                    "handling_status": "AUTO_FIXED",
                                    "resolution": f"Missing trailing zeros in {field} at row {i} added: {original_value} -> {new_num}",
                                    "handle_suggestion": handle_suggestion,
                                    "record_info": {
                                        "primary_key": data.at[i, primary_key],
                                        "archive_number":  data.at[i, archive_number],
                                        "affected_field": field,
                                        "current_value": data.at[i, field],
                                        "original":data_table,
                                        "checked_output_path":checked_output_path,
                                        "checked_id":data.at[i, primary_key]
                                }
                                })
                                zero_counts[(i, field)] = k  # 记录补零次数
                                break
                except ValueError:
                    continue

        # 处理daCode列
        if daCode in data.columns:
            for (i, field), k in zero_counts.items():
                try:
                    original_val = data.at[i, daCode]
                    # 应用相同次数的补零
                    new_val = str(original_val) + '0' * k
                    data.at[i, daCode] = new_val
                    fixes.append({
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table":data_table,
                        "datetime": current_datetime,
                        "error_id": "FMT-02",
                        "error_type": "Format Error",
                        "level": error_level,
                        "error_reason": f"Field {field} at row {i} is missing trailing zeros in archiveCode",
                        "handling_status": "AUTO_FIXED",
                        "resolution": f"Missing trailing zeros in {daCode} at row {i} added: {original_val} -> {new_val}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": data.at[i, primary_key],
                            "archive_number":  data.at[i, archive_number],
                            "affected_field": field,
                            "current_value": data.at[i, field],
                            "original":data_table,
                            "checked_output_path":checked_output_path,
                            "checked_id":data.at[i, primary_key]
                        }
                    })
                except Exception as e:
                    print(f"处理daCode列行{i}时出错: {e}")
        else:
            print(f"警告: daCode列 '{daCode}' 不存在，已跳过")

    except Exception as e:
        print(f"发生错误: {e}")

    return data, fixes


def validate_field_sequence(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段的流水号是否存在中断情况。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查流水号的字段名列表，这里只支持一个字段（流水号字段）。
    check_params (dict): 检查参数，包含错误等级、处理建议和流水号起始值。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")
    start = check_params.get("start", 1)  # 从配置获取流水号起始值
    title_key = check_params.get("title_key", "")  # 从配置获取流水号起始值
    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        if title_key not in data.columns:
            raise ValueError(f"字段 '{title_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        if len(field_names) != 1:
            raise ValueError("field_names 列表中只能包含一个流水号字段。")
        check_field = field_names[0]
        if check_field not in data.columns:
            raise ValueError(f"字段 '{check_field}' 不在 DataFrame 的列中。")

        # 按主键分组
        grouped = data.groupby(title_key)
        for title_key_value, group_df in grouped:
            # 获取当前分组中的检查字段的值，并排序
            sequence = sorted(group_df[check_field].tolist())

            # 如果序列为空，跳过该分组
            if not sequence:
                continue

            # 找到当前分组中检查字段的最大值
            max_value = int(max(sequence))

            # 生成从 start 到 max_value 的正确流水号序列
            correct_sequence = list(range(start, max_value + 1))

            # 找出缺失的流水号
            missing_numbers = [num for num in correct_sequence if num not in sequence]

            # 如果有缺失的流水号
            if missing_numbers:
                sample_row = group_df.iloc[0]  # 取分组中的第一行作为示例
                errors.append({
                    "task_id": task_id,
                    "source_type": source_type,
                    "source_path": source_path,
                    "data_table":data_table,
                    "datetime": current_datetime,
                    "error_id": "FMT-02",
                    "error_type": "Format Error",
                    "level": error_level,
                    "handling_status": "check",
                    "error_reason": f"Invalid serial number sequence in field: {check_field}, missing values: {missing_numbers}",
                    "handle_suggestion": handle_suggestion,
                    "record_info": {
                        "title_key": title_key_value,
                        "archive_number": sample_row[archive_number],
                        "affected_field": check_field,
                        "current_value": sample_row[check_field],
                        "original":data_table
                    }
                })

    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


def validate_field_consistency(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段的值是否与另一个表的指定字段值完全一致。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查的字段名列表，这里应包含两个字段，分别对应两个表的字段。
    check_params (dict): 检查参数，包含错误等级、处理建议、另一个表的路径和另一个表的字段名。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")
    # 获取另一个表的路径
    other_table_path = check_params.get("other_table_path", "")
    # 获取另一个表的字段名
    other_table_field = check_params.get("other_table_field", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        if len(field_names) != 1:
            raise ValueError("field_names 列表中应只包含一个字段。")
        field = field_names[0]
        if field not in data.columns:
            raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")
        # 读取另一个表的数据
        other_data = pd.read_excel(other_table_path)
        if other_table_field not in other_data.columns:
            raise ValueError(f"另一个表中不存在字段 '{other_table_field}'。")

        # 对两个字段分别去重
        unique_self = set(data[field].dropna().unique())
        unique_other = set(other_data[other_table_field].dropna().unique())

        # 找出本字段中存在，但另一个表字段中不存在的记录
        missing_in_other = list(unique_self - unique_other)
        # 找出另一个表字段中存在，但本字段中不存在的记录
        missing_in_self = list(unique_other - unique_self)

        if missing_in_other:
            for value in missing_in_other:
                # 获取source_path文件中对应的值
                source_rows = data[data[field] == value]
                for _, row in source_rows.iterrows():
                    error_info = {
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table": data_table,
                        "datetime": current_datetime,
                        "error_id": "CMP-03",
                        "error_type": "Data Consistency Error, records has no parent file",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"在文件 '{data_table}':'{source_path}' 的字段 '{field}' 中存在，但在文件 '{other_table_path}' 的字段 '{other_table_field}' 中不存在的字段值有: {value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[field],
                            "affected_field": field,
                            "current_value": value,
                            "original": data_table
                        }
                    }
                    errors.append(error_info)

        if missing_in_self:
            # 去掉文件扩展名
            other_table_name = os.path.splitext(os.path.basename(other_table_path))[0]
            for value in missing_in_self:
                # 获取other_table_path文件中对应的值
                other_rows = other_data[other_data[other_table_field] == value]
                for _, row in other_rows.iterrows():
                    error_info = {
                        "task_id": task_id,
                        "source_type": source_type,
                        "source_path": source_path,
                        "data_table": data_table,
                        "datetime": current_datetime,
                        "error_id": "CMP-02",
                        "error_type": "Data Consistency Error",
                        "level": error_level,
                        "handling_status": "check",
                        "error_reason": f"file has no associated records,在文件 '{other_table_path}' 的字段 '{other_table_field}' 中存在，但在文件 '{source_path}' 的字段 '{field}' 中不存在的字段值有: {value}",
                        "handle_suggestion": handle_suggestion,
                        "record_info": {
                            "primary_key": row[primary_key],
                            "archive_number": row[other_table_field],
                            "affected_field": other_table_field,
                            "current_value": value,
                            "original": other_table_name
                        },
                    }
                    errors.append(error_info)

    except FileNotFoundError:
        print(f"未找到另一个表的文件: {other_table_path}")
    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors


# 检查函数：验证指定字段值中的JSON路径列表代表的文件是否存在
def validate_field_file_existence(
    data,
    primary_key,
    field_names,
    check_params,
    source_path,
    source_type,
    task_id,
    data_table
):
    """
    此函数用于检查指定 DataFrame 中特定字段保存的 JSON 格式里多个文件路径对应的文件是否存在。

    参数:
    data (pandas.DataFrame): 要检查的 DataFrame。
    primary_key (str): DataFrame 中的主键字段名。
    field_names (list): 要检查的字段名列表，这里应只包含一个字段。
    check_params (dict): 检查参数，包含错误等级、处理建议、档案编号。
    source_path (str): 数据来源路径
    source_type (str): 数据来源类型
    task_id (str): 任务 ID

    返回:
    tuple: 包含原始 DataFrame 和错误信息列表的元组。
    """
    errors = []
    # 从配置文件获取错误等级
    error_level = check_params.get("level", "")
    # 从配置文件获取处理建议
    handle_suggestion = check_params.get("handle_suggestion", "")
    # 获取当前时间
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    archive_number = check_params.get("archive_number", "")

    try:
        # 检查输入的 data 是否为有效的 DataFrame
        if not isinstance(data, pd.DataFrame):
            raise ValueError("输入的 data 不是有效的 DataFrame。")
        # 检查主键字段是否存在于 DataFrame 中
        if primary_key not in data.columns:
            raise ValueError(f"主键字段 '{primary_key}' 不在 DataFrame 的列中。")
        # 检查要检查的字段列表中的每个字段是否存在于 DataFrame 中
        if len(field_names) != 1:
            raise ValueError("field_names 列表中应只包含一个字段。")
        field = field_names[0]
        if field not in data.columns:
            raise ValueError(f"字段 '{field}' 不在 DataFrame 的列中。")

        for index, row in data.iterrows():
            field_value = row[field]
            # 检查字段值是否为空或空白
            if pd.isna(field_value) or str(field_value).strip() == "":
                continue

            try:
                # 解析 JSON 数据
                json_data = json.loads(field_value)
                # 检查 "files" 键是否存在
                if "files" in json_data:
                    non_existent = []
                    for file_info in json_data["files"]:
                        file_path = file_info.get("file_path")
                        if file_path and not os.path.exists(file_path):
                            non_existent.append(file_path)
                    if non_existent:
                        errors.append({
                            "task_id": task_id,
                            "source_type": source_type,
                            "source_path": source_path,
                            "data_table":data_table,
                            "datetime": current_datetime,
                            "error_id": "FILE-01",
                            "error_type": "File Error",
                            "level": error_level,
                            "handling_status": "check",
                            "error_reason": f"字段 '{field}' 中的 JSON 路径列表包含无效的文件路径: {non_existent}",
                            "handle_suggestion": handle_suggestion,
                            "record_info": {
                                "primary_key": row[primary_key],
                                "archive_number": row[archive_number],
                                "affected_field": field,
                                "current_value": row[field],
                                "original":data_table
                            }
                        })
            except json.JSONDecodeError:
                print(f"在索引 {index} 处的 JSON 数据解析失败: {field_value}")
            except Exception as e:
                print(f"在索引 {index} 处发生未知错误: {e}")

    except Exception as e:
        print(f"发生错误: {e}")

    return data, errors
    
# 加载数据函数
def load_data(source_path, source_type):
    try:
        return pd.read_excel(source_path)
    except Exception as e:
        print(f"Error loading Excel data from {source_path}: {e}")
    return None

# 合并后的日志记录函数
def log_messages(messages, source_path, message_type, output_path):
    file_name, _ = os.path.splitext(os.path.basename(source_path))
    log_file_name = f"{file_name}-log.txt"
    source_dir = os.path.dirname(source_path)
    log_dir = os.path.join(source_dir, "other", "logs")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    log_file_path = os.path.join(log_dir, log_file_name)
    prefix = "Error: " if message_type == "error" else "Fix: "
    with open(log_file_path, 'a') as f:
        for message in messages:
            f.write(f"{prefix}{message}\n")
    return log_file_path


# 提交数据函数
def commit_data(data, output_path, output_type):

    try:
        data.to_excel(output_path, index=False)
        print(f"Data saved to {output_path}")
    except Exception as e:
        print(f"Error saving data to {output_path}: {e}")

    return output_path


def process_data_pipeline(source_path, output_path, config, log_config, other_path, data_table="", suffix="checked", task_id=None):
    """
    主处理流程函数，用于处理多个数据源的数据。

    参数:
    source_path (list/str): 数据源文件路径列表或单个路径，支持处理多个数据源或单个数据源。
    output_path (str): 处理后数据的输出路径。
    config (dict): 配置信息，包含源类型、主键、处理流程等。
    log_config (dict): 日志配置信息，用于记录检查错误和修复记录。
    other_path (list/str): 其他文件路径列表或单个路径，与 source_path 一一对应。
    data_table (str, 可选): 数据表名称，默认为空字符串。
    suffix (str, 可选): 输出文件名的后缀，默认为 "checked"。
    task_id (str, 可选): 任务 ID，默认为 None。

    返回:
    每个数据源对应的 log_file_name 列表和 new_file_name 列表
    """
    # 确保 output_path 存在，如果不存在则创建
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    # 从配置中获取数据源类型
    source_type = config["source_type"]
    if task_id is None:
        # 生成任务 ID，格式为当前时间的字符串
        task_id = datetime.now().strftime("%Y%m%d%H%M%S")

    # 如果 source_path 是字符串，将其转换为包含该字符串的列表
    if isinstance(source_path, str):
        source_path = [source_path]
    # 如果 other_path 是字符串，将其转换为包含该字符串的列表
    if isinstance(other_path, str):
        other_path = [other_path]

    # 将 source_path 和 other_path 中的相对路径转换为绝对路径
    source_path = [os.path.abspath(path) for path in source_path]
    other_path = [os.path.abspath(path) for path in other_path]

    log_file_names = []
    new_file_names = []
    # 循环处理 source_path 列表中的每个路径
    for i, single_source_path in enumerate(source_path):
        # # 修改配置文件里的 fields_to_check 下的 check_params 下的 other_table_path 为对应的 other_path
        # for stage in config["processing_pipeline"]:
        #     for check_config in stage.get("fields_to_check", []):
        #         if check_config["check_function"] == "validate_field_consistency":
        #             # check_config["check_params"]["other_table_path"] = other_path[i]
        #             file_name, file_ext = os.path.splitext(os.path.basename(other_path[i]))
        #             check_config["check_params"]["other_table_path"] = os.path.join(output_path, f"{file_name}-checked{file_ext}")
    
        # 调用 load_data 函数加载单个数据源的数据
        data = load_data(single_source_path, source_type)  # 加载原始数据
        # 根据 source_type 处理 id 字段
        if source_type == "EXCEL":
            # 如果 source_type 是 EXCEL，直接覆盖或添加 id 字段
            # 为数据添加自增的 id 列
            if 'id' not in data.columns:
                data['id'] = range(1, len(data) + 1)
        elif source_type == "DATABASE":
            # 如果 source_type 是 DATABASE，检查 id 是否存在
            if 'id' not in data.columns:
                # 如果 id 不存在，则添加自增的 id 列
                data['id'] = range(1, len(data) + 1)

        # 检查数据是否成功加载
        if data is not None:
            # 遍历配置中的每个处理阶段
            for stage in config["processing_pipeline"]:
                # 处理字段检查
                # 遍历当前阶段需要检查的字段配置
                for check_config in stage.get("fields_to_check", []):
                    # 获取检查函数的名称
                    check_func_name = check_config["check_function"]
                    print(f"尝试获取检查函数: {check_func_name}")
                    try:
                        # 从全局命名空间中获取检查函数
                        check_func = globals()[check_func_name]
                    except KeyError:
                        # 如果未找到函数，打印错误信息并跳过当前检查
                        print(f"未找到函数: {check_func_name}")
                        continue

                    # 调用检查函数进行数据检查
                    # data, errors = check_func(
                    #     data=data,
                    #     primary_key=config["primary_key"],
                    #     field_names=check_config["field_name"],
                    #     check_params=check_config["check_params"],
                    #     source_path=single_source_path,
                    #     source_type=source_type,
                    #     task_id=task_id,
                    #     data_table=data_table
                    # )

                    # ===================== 【总开关优先 + 分开关受控 + 跳过打印】 =====================
                    # 总开关（最高优先级）
                    enable_all_checks = config.get("enable_all_checks", True)
                    # 分开关
                    enable_check = check_config.get("enable_check", True)
                    # 当前检查函数
                    check_name = check_config["check_function"]

                    # 核心逻辑：总开关优先
                    if not enable_all_checks:
                        # 总开关关闭 → 强制跳过所有检查，无视分开关
                        print(f"✅ 总开关已关闭，强制跳过检查：{check_name}")
                        errors = []
                    else:
                        # 总开关开启 → 分开关生效
                        if not enable_check:
                            print(f"✅ 分开关已关闭，跳过检查：{check_name}")
                            errors = []
                        else:
                            # 执行检查
                            print(f"🔍 执行检查：{check_name}")
                            data, errors = check_func(
                                data=data,
                                primary_key=config["primary_key"],
                                field_names=check_config["field_name"],
                                check_params=check_config["check_params"],
                                source_path=single_source_path,
                                source_type=source_type,
                                task_id=task_id,
                                data_table=data_table
                            )

                    # 仅存在错误时写入日志
                    if errors:
                        log_file_name = log_messages(errors, single_source_path, "error", output_path)
                    # ============================================================================

                    # 调用 log_messages 函数记录检查错误
                    log_file_name = log_messages(errors, single_source_path, "error", output_path)  # 记录检查错误
                    file_name, file_ext = os.path.splitext(os.path.basename(single_source_path))
                    new_file_name = f"{file_name}-{suffix}{file_ext}"
                    checked_output_path = os.path.join(output_path, new_file_name)

                    # 执行修复
                    if check_config["action_on_error"] == "fix_and_report":
                        # 获取修复函数的名称
                        fix_func_name = check_config["fix_function"]
                        print(f"尝试获取修复函数: {fix_func_name}")
                        try:
                            # 从全局命名空间中获取修复函数
                            fix_func = globals()[fix_func_name]
                        except KeyError:
                            # 如果未找到函数，打印错误信息并跳过修复
                            print(f"未找到函数: {fix_func_name}")
                            continue
                        # 调用修复函数进行数据修复
                        data, fixes = fix_func(
                            data=data,
                            primary_key=config["primary_key"],
                            field_names=check_config["field_name"],
                            fix_params=check_config["fix_params"],
                            source_path=single_source_path,
                            source_type=source_type,
                            task_id=task_id,
                            data_table=data_table,
                            checked_output_path=checked_output_path
                        )
                        # 调用 log_messages 函数记录修复记录
                        log_file_name = log_messages(fixes, single_source_path, "fix", output_path)  # 记录修复记录
                    else:
                        print("Warning: fix_function is empty, skipping fix.")

                # 处理附加检查（类似逻辑）
                # ...

            # 最终数据输出
            # 调用 commit_data 函数将处理后的数据保存到输出路径
            new_file_name = commit_data(data, checked_output_path, config["output"]["type"])
            log_file_names.append(log_file_name)
            new_file_names.append(new_file_name)

    return log_file_names, new_file_names