"""
afctl broker — local MCP broker for coding agents.

Spawned by coding agents (Claude Code, Cursor, Codex) as a child process.
Communicates over stdio (stdin/stdout) and proxies MCP requests to the AF MCP server.

Usage in Claude Code .claude/mcp.json:
    {"mcpServers": {"agentic-fabriq": {"command": "afctl", "args": ["broker"]}}}
"""

import json
import os
import platform
import signal
import subprocess
import sys
from typing import Optional

import httpx
import typer

from af_cli.core.config import get_config
from af_cli.core.token_storage import get_token_storage

app = typer.Typer(help="Local MCP broker for coding agents")

# Hardcoded allowlist of supported coding agents: process name -> agent name
CODING_AGENTS = {
    "claude": "claude-code",
    "Claude Code": "claude-code",
    "cursor": "cursor",
    "codex": "codex",
}


def _get_parent_process_name() -> Optional[str]:
    """Get the name of the parent process (platform-specific)."""
    ppid = os.getppid()
    try:
        if platform.system() == "Linux":
            with open(f"/proc/{ppid}/comm", "r") as f:
                return f.read().strip()
        else:
            # macOS and other Unix
            result = subprocess.run(
                ["ps", "-p", str(ppid), "-o", "comm="],
                capture_output=True, text=True, timeout=5,
            )
            return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None


def detect_parent_process() -> Optional[str]:
    """Detect which coding agent spawned this broker. Returns agent name or None."""
    proc_name = _get_parent_process_name()
    if not proc_name:
        return None
    # Check exact match first
    if proc_name in CODING_AGENTS:
        return CODING_AGENTS[proc_name]
    # Partial match (e.g., "/path/to/Claude Code" -> "Claude Code")
    for pattern, agent_name in CODING_AGENTS.items():
        if pattern.lower() in proc_name.lower():
            return agent_name
    return None


def make_jsonrpc_error(request_id, code: int, message: str) -> str:
    """Create a JSON-RPC 2.0 error response string."""
    return json.dumps({
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": message},
    })


def make_jsonrpc_result(request_id, result: dict) -> str:
    """Create a JSON-RPC 2.0 result response string."""
    return json.dumps({
        "jsonrpc": "2.0",
        "id": request_id,
        "result": result,
    })


@app.callback(invoke_without_command=True)
def broker(
    skip_detection: bool = typer.Option(
        False, "--skip-detection",
        help="Skip parent process detection (for testing)",
        hidden=True,
    ),
    agent_name: Optional[str] = typer.Option(
        None, "--agent",
        help="Override agent name (for testing)",
        hidden=True,
    ),
):
    """
    Start the local MCP broker. Communicates over stdio.

    This command is meant to be spawned by coding agents, not run manually.
    """
    # 1. Detect parent process
    if agent_name:
        resolved_agent = agent_name
    elif skip_detection:
        resolved_agent = "claude-code"  # Default for testing
    else:
        resolved_agent = detect_parent_process()
        if not resolved_agent:
            print(
                "Error: afctl broker must be spawned by a supported coding agent "
                "(Claude Code, Cursor, or Codex). Detected parent process is not recognized.",
                file=sys.stderr,
            )
            raise typer.Exit(1)

    # 2. Get MCP URL — always use dashboard, not Keycloak auth URL
    mcp_url = os.getenv("AF_MCP_URL", "https://dashboard.agenticfabriq.com/mcp")

    # 3. Enter stdio loop
    session_id = None

    def _cleanup_session():
        """Send broker/cleanup to delete the Redis session. Best-effort."""
        nonlocal session_id
        if not session_id:
            return
        sid = session_id
        session_id = None  # Prevent double-cleanup
        try:
            with httpx.Client(timeout=5.0) as client:
                client.post(
                    mcp_url,
                    json={"jsonrpc": "2.0", "id": "cleanup", "method": "broker/cleanup", "params": {"session_id": sid}},
                    headers={"X-AF-Session": sid},
                )
        except Exception:
            pass

    def _signal_handler(signum, frame):
        """Handle SIGTERM/SIGINT: clean up session then exit."""
        _cleanup_session()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)

    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue

            request_id = msg.get("id", "unknown")
            method = msg.get("method", "")

            # Handle notifications (no id = fire-and-forget)
            if "id" not in msg:
                if session_id:
                    try:
                        _forward_request(mcp_url, msg, resolved_agent, session_id)
                    except Exception:
                        pass
                continue

            # Check for auth tokens
            storage = get_token_storage()
            token_data = storage.load()

            if not token_data or not token_data.access_token:
                if method in ("initialize", "tools/list"):
                    # Return empty tools for initialize/list when not authenticated
                    if method == "initialize":
                        print(make_jsonrpc_result(request_id, {
                            "protocolVersion": "2025-06-18",
                            "capabilities": {"tools": {}},
                            "serverInfo": {"name": "agentic-fabriq-broker", "version": "0.1.0"},
                        }), flush=True)
                    else:
                        print(make_jsonrpc_result(request_id, {"tools": []}), flush=True)
                else:
                    print(make_jsonrpc_error(
                        request_id, 401,
                        "Authentication required. Run `afctl auth login` in a terminal to connect to Agentic Fabriq.",
                    ), flush=True)
                continue

            # Forward to MCP server
            try:
                response = _forward_request(
                    mcp_url, msg, resolved_agent, session_id,
                    idp_token=token_data.access_token,
                )

                # Capture session_id from initialize response
                if method == "initialize" and response.get("result", {}).get("session_id"):
                    session_id = response["result"]["session_id"]
                    # Strip session_id before returning to agent (not part of MCP protocol)
                    result = response.get("result", {})
                    result.pop("session_id", None)
                    response["result"] = result

                # Detect session-expired/revoked 401 and transparently re-establish
                error = response.get("error", {})
                if error.get("code") == 401 and method != "initialize":
                    err_msg = error.get("message", "").lower()
                    if "expired" in err_msg or "revoked" in err_msg:
                        # Re-initialize: get a fresh session
                        session_id = None
                        init_msg = {
                            "jsonrpc": "2.0",
                            "id": f"reinit-{request_id}",
                            "method": "initialize",
                            "params": {},
                        }
                        try:
                            init_resp = _forward_request(
                                mcp_url, init_msg, resolved_agent, None,
                                idp_token=token_data.access_token,
                            )
                            new_sid = init_resp.get("result", {}).get("session_id")
                            if new_sid:
                                session_id = new_sid
                                # Retry the original request with the new session
                                response = _forward_request(
                                    mcp_url, msg, resolved_agent, session_id,
                                    idp_token=token_data.access_token,
                                )
                        except Exception:
                            pass  # Fall through to print the original 401 response

                print(json.dumps(response), flush=True)

            except httpx.ConnectError:
                print(make_jsonrpc_error(
                    request_id, 503,
                    "Cannot reach Agentic Fabriq gateway. Check your network connection.",
                ), flush=True)
            except Exception as e:
                err_msg = str(e)
                if "expired" in err_msg.lower() or "revoked" in err_msg.lower():
                    print(make_jsonrpc_error(request_id, 401, err_msg), flush=True)
                else:
                    print(make_jsonrpc_error(request_id, 500, f"Broker error: {err_msg}"), flush=True)
    finally:
        # Cleanup on stdin EOF, exception, or break
        _cleanup_session()


def _forward_request(
    mcp_url: str,
    msg: dict,
    agent_name: str,
    session_id: Optional[str],
    idp_token: Optional[str] = None,
) -> dict:
    """Forward a JSON-RPC request to the MCP server and return the response."""
    headers = {"Content-Type": "application/json"}

    if idp_token:
        headers["Authorization"] = f"Bearer {idp_token}"
    headers["X-AF-Agent"] = agent_name
    if session_id:
        headers["X-AF-Session"] = session_id

    with httpx.Client(timeout=30.0) as client:
        response = client.post(mcp_url, json=msg, headers=headers)
        response.raise_for_status()
        return response.json()
