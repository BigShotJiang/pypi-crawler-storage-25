pub fn tokio() -> &'static tokio::runtime::Runtime {
    use std::sync::OnceLock;
    use tokio::runtime::Runtime;
    static RT: std::sync::OnceLock<Runtime> = OnceLock::new();
    RT.get_or_init(|| Runtime::new().expect("Failed to create tokio runtime"))
}

#[macro_export]
macro_rules! call_handler_constructor {
    ($self:ident, $constructor:path, $($params:expr),*) => {{
        let client = $self.client.clone();
        let handler = $crate::runtime::tokio()
            .spawn(async move {
                $constructor(client, $($params),*)
                    .await
            })
            .await
            .map_err(anyhow::Error::from)??;

        handler
    }};
}

#[macro_export]
macro_rules! call_handler_method {
    ($handler:expr, $method:path) => ($crate::call_handler_method!($handler, $method,));
    ($handler:expr, $method:path, discard_result) => ($crate::call_handler_method!($handler, $method, discard_result,));
    ($handler:expr, $method:path, $($param:expr),*) => {{
        let result = $crate::runtime::tokio()
            .spawn(async move {
                let result = $method($handler, $($param),*)
                    .await?;

                Ok::<_, tapo::Error>(result)
            })
            .await
            .map_err(anyhow::Error::from)??;

        Ok::<_, pyo3::PyErr>(result)
    }};
    ($handler:expr, $method:path, discard_result, $($param:expr),*) => {{
        let result = $crate::runtime::tokio()
            .spawn(async move {
                $method($handler, $($param),*)
                    .await?;

                Ok::<_, tapo::Error>(())
            })
            .await
            .map_err(anyhow::Error::from)??;

        Ok(result)
    }};
}
