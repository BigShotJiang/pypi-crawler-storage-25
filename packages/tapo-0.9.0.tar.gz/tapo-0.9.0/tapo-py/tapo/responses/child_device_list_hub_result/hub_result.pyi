from tapo.responses.child_device_list_hub_result.status import Status
from tapo.to_dict_ext import ToDictExt

class HubResultBase(ToDictExt):
    """Hub result. This is an abstract base class for all hub results."""

    at_low_battery: bool
    avatar: str
    bind_count: int
    category: str
    device_id: str
    fw_ver: str
    hw_id: str
    hw_ver: str
    jamming_rssi: int
    jamming_signal_level: int
    mac: str
    model: str
    nickname: str
    oem_id: str
    parent_device_id: str
    region: str
    rssi: int
    signal_level: int
    specs: str
    status: Status
    type: str
