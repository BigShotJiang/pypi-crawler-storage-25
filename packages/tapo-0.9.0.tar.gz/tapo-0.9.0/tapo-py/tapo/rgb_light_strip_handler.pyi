from tapo.debug_ext import DebugExt
from tapo.device_management_ext import DeviceManagementExt
from tapo.on_off_ext import OnOffExt
from tapo.refresh_session_ext import RefreshSessionExt
from tapo.requests import Color, ColorLightSetDeviceInfoParams
from tapo.responses import DeviceInfoRgbLightStripResult, DeviceUsageEnergyMonitoringResult

class RgbLightStripHandler(OnOffExt, DeviceManagementExt, RefreshSessionExt, DebugExt):
    """Handler for the [L900](https://www.tapo.com/en/search/?q=L900) devices."""

    def __init__(self, handler: object):
        """Private constructor.
        It should not be called from outside the tapo library.
        """

    async def get_device_info(self) -> DeviceInfoRgbLightStripResult:
        """Returns *device info* as `DeviceInfoRgbLightStripResult`.
        It is not guaranteed to contain all the properties returned from the Tapo API.
        If the deserialization fails, or if a property that you care about it's not present,
        try `RgbLightStripHandler.get_device_info_json`.

        Returns:
            DeviceInfoRgbLightStripResult: Device info of Tapo L900.
        """

    async def get_device_usage(self) -> DeviceUsageEnergyMonitoringResult:
        """Returns *device usage* as `DeviceUsageEnergyMonitoringResult`.

        Returns:
            DeviceUsageEnergyMonitoringResult:
            Contains the time usage, the power consumption, and the energy savings of the device.
        """

    def set(self) -> ColorLightSetDeviceInfoParams:
        """Returns a `ColorLightSetDeviceInfoParams` builder that allows
        multiple properties to be set in a single request.
        `ColorLightSetDeviceInfoParams.send` must be called at the end to apply the changes.

        Returns:
            ColorLightSetDeviceInfoParams: Builder that is used by the
            `RgbLightStripHandler.set` API to set multiple properties in a single request.
        """

    async def set_brightness(self, brightness: int) -> None:
        """Sets the *brightness* and turns *on* the device.

        Args:
            brightness (int): between 1 and 100
        """

    async def set_color(self, color: Color) -> None:
        """Sets the *color* and turns *on* the device.

        Args:
            color (Color): one of `tapo.Color` as defined in the Google Home app.
        """

    async def set_hue_saturation(self, hue: int, saturation: int) -> None:
        """Sets the *hue*, *saturation* and turns *on* the device.

        Args:
            hue (int): between 0 and 360
            saturation (int): between 1 and 100
        """

    async def set_color_temperature(self, color_temperature: int) -> None:
        """Sets the *color temperature* and turns *on* the device.

        Args:
            color_temperature (int): between 2500 and 6500
        """
