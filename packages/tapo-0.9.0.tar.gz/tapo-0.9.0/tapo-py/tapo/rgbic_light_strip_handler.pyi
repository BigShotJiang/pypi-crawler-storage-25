from typing import Union

from tapo.debug_ext import DebugExt
from tapo.device_management_ext import DeviceManagementExt
from tapo.on_off_ext import OnOffExt
from tapo.refresh_session_ext import RefreshSessionExt
from tapo.requests import (
    Color,
    ColorLightSetDeviceInfoParams,
    LightingEffect,
    LightingEffectPreset,
    SegmentEffect,
    SegmentEffectPreset,
)
from tapo.responses import DeviceInfoRgbicLightStripResult, DeviceUsageEnergyMonitoringResult

class RgbicLightStripHandler(OnOffExt, DeviceManagementExt, RefreshSessionExt, DebugExt):
    """Handler for the [L920](https://www.tapo.com/en/search/?q=L920) and
    [L930](https://www.tapo.com/en/search/?q=L930) devices.
    """

    def __init__(self, handler: object):
        """Private constructor.
        It should not be called from outside the tapo library.
        """

    async def get_device_info(self) -> DeviceInfoRgbicLightStripResult:
        """Returns *device info* as `DeviceInfoRgbicLightStripResult`.
        It is not guaranteed to contain all the properties returned from the Tapo API.
        If the deserialization fails, or if a property that you care about it's not present,
        try `RgbicLightStripHandler.get_device_info_json`.

        Returns:
            DeviceInfoRgbicLightStripResult: Device info of Tapo L920 and L930.
        """

    async def get_device_usage(self) -> DeviceUsageEnergyMonitoringResult:
        """Returns *device usage* as `DeviceUsageEnergyMonitoringResult`.

        Returns:
            DeviceUsageEnergyMonitoringResult:
            Contains the time usage, the power consumption, and the energy savings of the device.
        """

    def set(self) -> ColorLightSetDeviceInfoParams:
        """Returns a `ColorLightSetDeviceInfoParams` builder that allows
        multiple properties to be set in a single request.
        `ColorLightSetDeviceInfoParams.send` must be called at the end to apply the changes.

        Returns:
            ColorLightSetDeviceInfoParams: Builder that is used by the
            `RgbicLightStripHandler.set` API to set multiple properties in a single request.
        """

    async def set_brightness(self, brightness: int) -> None:
        """Sets the *brightness* and turns *on* the device.

        Args:
            brightness (int): between 1 and 100
        """

    async def set_color(self, color: Color) -> None:
        """Sets the *color* and turns *on* the device.

        Args:
            color (Color): one of `tapo.Color` as defined in the Google Home app.
        """

    async def set_hue_saturation(self, hue: int, saturation: int) -> None:
        """Sets the *hue*, *saturation* and turns *on* the device.

        Args:
            hue (int): between 0 and 360
            saturation (int): between 1 and 100
        """

    async def set_color_temperature(self, color_temperature: int) -> None:
        """Sets the *color temperature* and turns *on* the device.

        Args:
            color_temperature (int): between 2500 and 6500
        """

    async def set_lighting_effect(
        self, lighting_effect: Union[LightingEffect, LightingEffectPreset]
    ) -> None:
        """Sets a *lighting effect* and turns *on* the device.

        Args:
            lighting_effect (LightingEffect | LightingEffectPreset)
        """

    async def set_segment_effect(
        self, segment_effect: Union[SegmentEffect, SegmentEffectPreset]
    ) -> None:
        """Sets a *segment effect* and turns *on* the device.

        This is used for the newer app-defined RGBIC strip effects that cannot be set by
        `LightingEffect` (for example, "circulating" or "breathe" segment effects).

        Args:
            segment_effect (SegmentEffect | SegmentEffectPreset)
        """
