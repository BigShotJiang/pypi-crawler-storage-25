import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from maria import (
    AuditPolicy,
    BasisProjector,
    GraphModel,
    JuliaBridge,
    LogisticModel,
    MariaLibrary,
    PolynomialModel,
    StreamBuffer,
    StructGraph,
    StructIndex,
    StructureTree,
    TensorModel,
    TimeTrace,
    TraceModel,
    Tunnel,
    RuntimeImportConfig,
    build_credit_border,
    get_backend_status,
    load_entity,
    rate_divergence,
    render_struct_index_viewer,
    render_runtime_viewer_from_path,
    save_entity,
    sbid_score,
    structural_divergence,
    struct_index_from_runtime_path,
)


class FrameworkTests(unittest.TestCase):
    def test_polynomial_divergence(self) -> None:
        reference = PolynomialModel([1, 2, 0, 1])
        candidate = PolynomialModel([1, -1, 0, 1])
        self.assertAlmostEqual(structural_divergence(candidate, reference), 3.0)
        self.assertAlmostEqual(rate_divergence(candidate, reference), 3.0)

    def test_graph_model_divergence(self) -> None:
        reference = GraphModel(edges=[("a", "b"), ("b", "c")], nodes=("a", "b", "c"))
        candidate = GraphModel(edges=[("a", "b"), ("b", "d"), ("d", "c")], nodes=("a", "b", "c", "d"))
        self.assertGreater(structural_divergence(candidate, reference), 0.0)
        self.assertGreaterEqual(rate_divergence(candidate, reference), 0.0)

    def test_tensor_model_divergence(self) -> None:
        reference = TensorModel([[1.0, 2.0], [3.0, 4.0]])
        candidate = TensorModel([[1.0, 2.0], [3.0, 10.0]])
        self.assertGreater(structural_divergence(candidate, reference), 0.0)
        self.assertGreater(rate_divergence(candidate, reference), 0.0)

    def test_trace_model_divergence(self) -> None:
        reference = TraceModel(["load", "normalize", "score", "approve"])
        candidate = TraceModel(["load", "normalize", "manual-review", "approve"])
        self.assertGreater(structural_divergence(candidate, reference), 0.0)
        self.assertGreater(rate_divergence(candidate, reference), 0.0)

    def test_credit_review_scenario(self) -> None:
        library = MariaLibrary()
        border = build_credit_border()
        policy = AuditPolicy(
            warning_varpi=10.0,
            block_varpi=25.0,
            warning_delta_varpi=10.0,
            block_delta_varpi=25.0,
        )
        reference = library.entity(
            border=border,
            tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.03, x0=620.0)),
            context={"age": 28, "credit_score": 605, "credit_policy": "default"},
        )
        candidate = library.entity(
            border=border,
            tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.045, x0=600.0)),
            context={"age": 28, "credit_score": 605, "credit_policy": "default"},
        )
        result = library.audit(candidate, reference, policy=policy)
        self.assertEqual(result.decision, "REVIEW")
        self.assertTrue(result.admissible)

    def test_credit_block_scenario(self) -> None:
        library = MariaLibrary()
        border = build_credit_border()
        policy = AuditPolicy(
            warning_varpi=10.0,
            block_varpi=25.0,
            warning_delta_varpi=10.0,
            block_delta_varpi=25.0,
        )
        reference = library.entity(
            border=border,
            tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.03, x0=620.0)),
            context={"age": 28, "credit_score": 605, "credit_policy": "default"},
        )
        candidate = library.entity(
            border=border,
            tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.045, x0=600.0)),
            context={"age": 28, "credit_score": 590, "credit_policy": "default"},
        )
        result = library.audit(candidate, reference, policy=policy)
        self.assertEqual(result.decision, "BLOCK")
        self.assertFalse(result.admissible)

    def test_flexible_border_can_drift(self) -> None:
        library = MariaLibrary()
        border = build_credit_border()
        entity = library.entity(
            border=border,
            tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.03, x0=620.0)),
            context={"age": 30, "credit_score": 590, "credit_policy": "default"},
        )
        self.assertFalse(entity.is_admissible())

        drifted = entity.with_drifted_border({"age": 30, "credit_score": 590, "credit_policy": "relaxed"})
        self.assertTrue(drifted.is_admissible())

    def test_backend_status_reports_julia_project(self) -> None:
        status = get_backend_status()
        self.assertTrue(status.python_reference)
        self.assertTrue(status.julia_backend_present)
        self.assertTrue(status.julia_project_path.endswith("julia\\Project.toml") or status.julia_project_path.endswith("julia/Project.toml"))
        if status.julia_runtime_available:
            self.assertIsNotNone(status.julia_executable)

    def test_serialization_round_trip(self) -> None:
        library = MariaLibrary()
        entity = library.entity(
            border=build_credit_border(),
            tunnel=library.trace_tunnel(["load", "score", "approve"]),
            context={"age": 30, "credit_score": 610, "credit_policy": "default"},
        )
        path = ROOT / "tests" / "tmp_entity.maria.json"
        try:
            save_entity(entity, path)
            restored = load_entity(path)
            self.assertEqual(restored.context, entity.context)
            self.assertEqual(restored.tunnel.kind, entity.tunnel.kind)
            self.assertEqual(restored.tunnel.model.signature(), entity.tunnel.model.signature())
        finally:
            if path.exists():
                path.unlink()

    def test_julia_bridge_fallback_and_sbid(self) -> None:
        bridge = JuliaBridge()
        self.assertTrue(bridge.available or not bridge.available)
        self.assertAlmostEqual(bridge.lp_distance([1.0, 2.0], [1.0, 5.0]), 3.0, places=5)
        self.assertGreater(bridge.sbid_score([1.0, 2.0], [1.5, 1.5], variance=0.2), 0.0)
        self.assertGreater(sbid_score([1.0, 2.0], [1.5, 1.5], variance=0.2), 0.0)

    def test_structure_tree_query(self) -> None:
        tree = StructureTree(leaf_size=2)
        tree.czvs_target = [0.0, 0.0]
        tree.build(
            [
                ("a", [0.0, 0.0], {"admissible": True, "border_region": "safe"}),
                ("b", [1.0, 1.0], {"admissible": True, "border_region": "safe"}),
                ("c", [5.0, 5.0], {"admissible": False, "border_region": "warning"}),
            ]
        )
        result = tree.query([0.1, 0.1], k=2)
        self.assertEqual(result[0][0], "a")
        self.assertIsNotNone(tree.root)
        self.assertEqual(tree.root.depth, 0)
        self.assertGreaterEqual(len(tree.levels()), 1)
        self.assertIn("node_id", tree.to_dict())
        self.assertEqual(tree.root.admissible_count, 2)
        self.assertEqual(tree.root.dominant_border_region, "safe")
        self.assertIsNotNone(tree.root.representative_id)
        self.assertIsNotNone(tree.root.czvs_mean)

    def test_structure_tree_dynamic_update_without_rebuild(self) -> None:
        tree = StructureTree(leaf_size=2, czvs_target=[0.0, 0.0])
        tree.build([("a", [0.0, 0.0]), ("b", [1.0, 1.0])])
        tree.insert("c", [0.1, 0.1], {"admissible": True, "border_region": "safe"})
        trace = tree.query_trace([0.05, 0.05], k=2)
        self.assertGreaterEqual(len(trace["visited_nodes"]), 1)
        self.assertEqual(trace["neighbors"][0][0], "a")
        tree.update("c", [3.0, 3.0], {"admissible": False, "border_region": "outer"})
        self.assertEqual(tree.entity_metadata["c"]["border_region"], "outer")

    def test_stream_buffer_statistics(self) -> None:
        buffer = StreamBuffer(dim=2, decay=0.9)
        buffer.add_entity([1.0, 2.0])
        buffer.add_entity([3.0, 4.0])
        current = buffer.current_embedding()
        self.assertEqual(len(current), 2)
        self.assertTrue((buffer.current_variance() >= 0).all())
        snapshot = buffer.snapshot([0.0, 0.0])
        self.assertIn("reference_distance", snapshot)

    def test_basis_projector_embed(self) -> None:
        projector = BasisProjector(input_dim=4, basis_size=3, basis_type="fourier")
        embedding = projector.embed([1.0, 0.0, -1.0, 0.5])
        self.assertEqual(len(embedding), 3)
        self.assertGreater(len(projector.to_sparse()), 0)
        self.assertEqual(projector.summary()["basis_type"], "fourier")

    def test_struct_graph_clusters(self) -> None:
        graph = StructGraph()
        graph.add_entity("a", [0.0, 0.0], {"admissible": True, "border_region": "core"})
        graph.add_entity("b", [0.2, 0.1], {"admissible": True, "border_region": "core"})
        graph.add_entity("c", [4.0, 4.0], {"admissible": False, "border_region": "outer"})
        graph.compute_all_divergences(threshold=0.5)
        clusters = graph.find_structural_clusters()
        self.assertGreaterEqual(len(clusters), 2)
        self.assertIn("degree", graph.node_summary("a"))
        self.assertGreaterEqual(len(graph.cluster_summary()), 1)

    def test_time_trace_and_index(self) -> None:
        trace = TimeTrace()
        trace.add_state(0, [0.0, 0.0], {"admissible": True, "border_region": "core"})
        trace.add_state(1, [1.0, 1.0], {"admissible": False, "border_region": "warning"})
        self.assertEqual(len(trace.structural_drift()), 1)
        self.assertIn("admissibility_rate", trace.summary([0.0, 0.0]))

        index = StructIndex(graph_threshold=1.0, czvs_target=[0.0, 0.0])
        index.add_entity("x", [0.0, 0.0], metadata={"admissible": True, "border_region": "core"})
        index.add_entity("y", [0.2, 0.2], metadata={"admissible": False, "border_region": "watch"}, timestamp=1, type="dynamic")
        index.refresh_graph()
        self.assertGreaterEqual(len(index.query_similar([0.1, 0.1], k=1)), 1)
        self.assertEqual(index.summary()["entity_count"], 2)
        self.assertGreaterEqual(len(index.node_summaries()), 1)
        self.assertGreaterEqual(len(index.prototype_entities()), 1)
        self.assertGreaterEqual(len(index.czvs_candidates(limit=2)), 1)
        payload = index.viewer_payload(query_data=[0.1, 0.1], k=1)
        self.assertIn("tree", payload)
        self.assertIn("summary", payload)

    def test_struct_index_recomputes_czvs_distance_on_update(self) -> None:
        index = StructIndex(czvs_target=[0.0, 0.0])
        index.add_entity("x", [0.1, 0.1], metadata={"admissible": True, "border_region": "core"})
        original = index.metadata["x"]["czvs_distance"]
        index.update_entity("x", [3.0, 4.0], metadata={"border_region": "warning"})
        updated = index.metadata["x"]["czvs_distance"]
        self.assertNotEqual(original, updated)
        self.assertAlmostEqual(updated, 5.0)
        self.assertEqual(index.czvs_candidates(limit=1)[0]["entity_id"], "x")

    def test_struct_index_stream_summary_matches_current_entities(self) -> None:
        index = StructIndex(czvs_target=[0.0, 0.0])
        index.add_entity("a", [0.0, 0.0], metadata={"admissible": True, "border_region": "core"})
        index.add_entity("b", [2.0, 0.0], metadata={"admissible": True, "border_region": "watch"})
        initial_stream = index.summary()["stream"]["embedding"]
        self.assertAlmostEqual(initial_stream[0], 1.0256410256410255)
        index.update_entity("b", [4.0, 0.0])
        updated_stream = index.summary()["stream"]["embedding"]
        self.assertGreater(updated_stream[0], initial_stream[0])
        index.remove_entity("a")
        removed_stream = index.summary()["stream"]["embedding"]
        self.assertAlmostEqual(removed_stream[0], 4.0)
        self.assertAlmostEqual(removed_stream[1], 0.0)

    def test_struct_index_viewer_renders_html(self) -> None:
        index = StructIndex(graph_threshold=1.0, czvs_target=[0.0, 0.0])
        index.add_entity("x", [0.0, 0.0], metadata={"admissible": True, "border_region": "core"})
        index.add_entity("y", [0.25, 0.2], metadata={"admissible": True, "border_region": "watch"})
        index.refresh_graph()
        path = ROOT / "tests" / "tmp_structindex_viewer.html"
        try:
            output = render_struct_index_viewer(index, path, query_data=[0.1, 0.1], k=2)
            self.assertEqual(Path(output), path)
            html = path.read_text(encoding="utf-8")
            self.assertIn("Maria StructIndex Viewer", html)
            self.assertIn("CZVS Candidates", html)
        finally:
            if path.exists():
                path.unlink()

    def test_runtime_json_import_builds_index(self) -> None:
        path = ROOT / "tests" / "tmp_runtime.json"
        output = ROOT / "tests" / "tmp_runtime_viewer.html"
        payload = {
            "schema": "maria-runtime-index",
            "czvs_target": [0.0, 0.0, 0.0],
            "query": [0.2, 0.05, 0.3],
            "entities": [
                {
                    "entity_id": "pass-a",
                    "embedding": [0.1, 0.0, 0.2],
                    "timestamp": 0,
                    "type": "dynamic",
                    "admissible": True,
                    "border_region": "core",
                },
                {
                    "entity_id": "pass-b",
                    "embedding": [0.7, 0.6, 0.9],
                    "admissible": False,
                    "border_region": "warning",
                },
            ],
        }
        try:
            path.write_text(json.dumps(payload), encoding="utf-8")
            index, bundle = struct_index_from_runtime_path(path, graph_threshold=1.0)
            self.assertEqual(len(bundle.records), 2)
            self.assertEqual(len(index.entities), 2)
            self.assertGreaterEqual(len(index.czvs_candidates(limit=2)), 1)
            render_runtime_viewer_from_path(path, output, graph_threshold=1.0)
            self.assertTrue(output.exists())
        finally:
            if path.exists():
                path.unlink()
            if output.exists():
                output.unlink()

    def test_runtime_jsonl_import_uses_embedding_fields(self) -> None:
        path = ROOT / "tests" / "tmp_runtime.jsonl"
        config = RuntimeImportConfig(embedding_fields=["latency", "error_rate", "memory_delta"])
        try:
            path.write_text(
                "\n".join(
                    [
                        '{"entity_id":"svc-a","latency":0.1,"error_rate":0.02,"memory_delta":0.3,"timestamp":0,"type":"dynamic","admissible":true,"border_region":"core"}',
                        '{"entity_id":"svc-a","latency":0.2,"error_rate":0.03,"memory_delta":0.4,"timestamp":1,"type":"dynamic","admissible":true,"border_region":"watch"}',
                        '{"entity_id":"svc-b","latency":0.8,"error_rate":0.2,"memory_delta":0.7,"timestamp":1,"type":"dynamic","admissible":false,"border_region":"warning"}',
                    ]
                ),
                encoding="utf-8",
            )
            index, bundle = struct_index_from_runtime_path(path, config=config, graph_threshold=1.0, czvs_target=[0.0, 0.0, 0.0])
            self.assertEqual(len(bundle.records), 3)
            self.assertEqual(len(index.entities), 2)
            self.assertIn("svc-a", index.traces)
            self.assertEqual(index.summary()["entity_count"], 2)
        finally:
            if path.exists():
                path.unlink()


if __name__ == "__main__":
    unittest.main()
