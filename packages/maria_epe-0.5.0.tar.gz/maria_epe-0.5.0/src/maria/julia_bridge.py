from __future__ import annotations

import shutil
import subprocess
import os
import glob
from pathlib import Path
from typing import Sequence

from epe_framework import TensorModel, lp_distance

from .sbid import alignment_similarity, interaction_degree, sbid_score


def _csv(values: Sequence[float]) -> str:
    return ",".join(str(float(value)) for value in values)


class JuliaBridge:
    def __init__(self, executable: str | None = None) -> None:
        self.executable = executable or self._discover_julia()
        root = Path(__file__).resolve().parents[2]
        self.project_path = root / "julia"
        self.runner_path = self.project_path / "runner.jl"

    def _discover_julia(self) -> str | None:
        direct = shutil.which("julia")
        if direct:
            return direct

        search_patterns = [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Julia-*", "bin", "julia.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Julia-*", "bin", "julia.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Julia", "*", "bin", "julia.exe"),
        ]
        candidates: list[str] = []
        for pattern in search_patterns:
            if pattern:
                candidates.extend(glob.glob(pattern))
        if not candidates:
            return None
        candidates.sort()
        return candidates[-1]

    @property
    def available(self) -> bool:
        return self.executable is not None and self.runner_path.exists()

    def _run(self, command: str, *args: str) -> str:
        if not self.available:
            raise RuntimeError("Julia runtime is not available")
        result = subprocess.run(
            [self.executable, str(self.runner_path), command, *args],
            cwd=self.project_path,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()

    def lp_distance(self, left: Sequence[float], right: Sequence[float], p: int = 2, *, fallback: bool = True) -> float:
        if self.available:
            return float(self._run("lp_distance", _csv(left), _csv(right), str(p)))
        if fallback:
            return lp_distance(left, right, p=p)
        raise RuntimeError("Julia runtime is not available")

    def tensor_signature(self, values: Sequence[Sequence[float]], *, fallback: bool = True) -> list[float]:
        model = TensorModel(values)
        if self.available:
            shape = ",".join(str(item) for item in model.resolved_shape())
            output = self._run("tensor_signature", _csv(model.flattened()), shape)
            return [float(piece) for piece in output.split(",") if piece]
        if fallback:
            return model.signature()
        raise RuntimeError("Julia runtime is not available")

    def alignment_similarity(
        self,
        left: Sequence[float],
        right: Sequence[float],
        weights: Sequence[float] | None = None,
        *,
        fallback: bool = True,
    ) -> float:
        weights = list(weights or [1.0] * max(len(left), len(right)))
        if self.available:
            return float(self._run("alignment_similarity", _csv(left), _csv(right), _csv(weights)))
        if fallback:
            return alignment_similarity(left, right, weights)
        raise RuntimeError("Julia runtime is not available")

    def interaction_degree(
        self,
        left: Sequence[float],
        right: Sequence[float],
        threshold: float = 0.05,
        *,
        fallback: bool = True,
    ) -> int:
        if self.available:
            return int(float(self._run("interaction_degree", _csv(left), _csv(right), str(threshold))))
        if fallback:
            return interaction_degree(left, right, threshold=threshold)
        raise RuntimeError("Julia runtime is not available")

    def sbid_score(
        self,
        left: Sequence[float],
        right: Sequence[float],
        *,
        variance: float,
        weights: Sequence[float] | None = None,
        lambda_weight: float = 3.0,
        eta_weight: float = 2.0,
        rho_weight: float = 1.0,
        threshold: float = 0.05,
        fallback: bool = True,
    ) -> float:
        weights = list(weights or [1.0] * max(len(left), len(right)))
        if self.available:
            return float(
                self._run(
                    "sbid_score",
                    _csv(left),
                    _csv(right),
                    _csv(weights),
                    str(variance),
                    str(lambda_weight),
                    str(eta_weight),
                    str(rho_weight),
                    str(threshold),
                )
            )
        if fallback:
            return sbid_score(
                left,
                right,
                variance=variance,
                weights=weights,
                lambda_weight=lambda_weight,
                eta_weight=eta_weight,
                rho_weight=rho_weight,
                threshold=threshold,
            )
        raise RuntimeError("Julia runtime is not available")
