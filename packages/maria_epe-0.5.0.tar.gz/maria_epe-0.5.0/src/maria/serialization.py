from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from epe_framework import (
    Border,
    Constraint,
    EelStructuredEntity,
    ExponentialModel,
    GraphModel,
    LogisticModel,
    PolynomialModel,
    TensorModel,
    TraceModel,
    Tunnel,
    context_min_validator,
    flexible_credit_score_rule,
)


SCHEMA_NAME = "maria-entity-exchange"
SCHEMA_VERSION = "1.0"


def _model_to_payload(model: Any) -> dict[str, Any]:
    if isinstance(model, PolynomialModel):
        return {"type": "polynomial", "coefficients": list(model.coefficients)}
    if isinstance(model, ExponentialModel):
        return {"type": "exponential", "scale": model.scale, "rate": model.rate}
    if isinstance(model, LogisticModel):
        return {"type": "logistic", "L": model.L, "k": model.k, "x0": model.x0}
    if isinstance(model, GraphModel):
        return {
            "type": "graph",
            "edges": [[left, right] for left, right in model.edges],
            "nodes": list(model.nodes),
            "directed": model.directed,
        }
    if isinstance(model, TensorModel):
        return {"type": "tensor", "values": model.values, "shape": list(model.shape) if model.shape is not None else None}
    if isinstance(model, TraceModel):
        return {"type": "trace", "states": list(model.states)}
    raise TypeError(f"Unsupported model type for serialization: {type(model).__name__}")


def _model_from_payload(payload: Mapping[str, Any]) -> Any:
    model_type = payload["type"]
    if model_type == "polynomial":
        return PolynomialModel(payload["coefficients"])
    if model_type == "exponential":
        return ExponentialModel(scale=payload["scale"], rate=payload["rate"])
    if model_type == "logistic":
        return LogisticModel(L=payload["L"], k=payload["k"], x0=payload["x0"])
    if model_type == "graph":
        return GraphModel(edges=[tuple(edge) for edge in payload["edges"]], nodes=payload.get("nodes", ()), directed=payload.get("directed", False))
    if model_type == "tensor":
        return TensorModel(values=payload["values"], shape=payload.get("shape"))
    if model_type == "trace":
        return TraceModel(states=payload["states"])
    raise ValueError(f"Unsupported serialized model type: {model_type}")


def _constraint_to_payload(constraint: Constraint) -> dict[str, Any]:
    if constraint.descriptor is None:
        raise TypeError(f"Constraint '{constraint.name}' cannot be serialized without a descriptor")
    return {
        "name": constraint.name,
        "rigid": constraint.rigid,
        "descriptor": constraint.descriptor,
    }


def _constraint_from_payload(payload: Mapping[str, Any]) -> Constraint:
    descriptor = dict(payload["descriptor"])
    kind = descriptor.get("kind")
    if kind != "context_min":
        raise ValueError(f"Unsupported serialized constraint kind: {kind}")

    validator = context_min_validator(descriptor["context_key"], descriptor["min_value"])
    drift_rule = None
    drift = descriptor.get("drift")
    if drift:
        if drift.get("kind") != "context_switch_min":
            raise ValueError(f"Unsupported serialized drift kind: {drift.get('kind')}")
        relaxed_value = next(iter(drift["cases"].values()))
        drift_rule = flexible_credit_score_rule(drift["default"], relaxed_value)

    return Constraint(
        name=payload["name"],
        validator=validator,
        rigid=payload["rigid"],
        drift_rule=drift_rule,
        descriptor=descriptor,
    )


def entity_to_exchange_dict(entity: EelStructuredEntity) -> dict[str, Any]:
    return {
        "schema": SCHEMA_NAME,
        "version": SCHEMA_VERSION,
        "entity": {
            "context": entity.context,
            "tunnel": {
                "kind": entity.tunnel.kind,
                "metadata": entity.tunnel.metadata,
                "model": _model_to_payload(entity.tunnel.model),
            },
            "border": {
                "constraints": [_constraint_to_payload(constraint) for constraint in entity.border.constraints],
            },
        },
    }


def entity_from_exchange_dict(payload: Mapping[str, Any]) -> EelStructuredEntity:
    if payload.get("schema") != SCHEMA_NAME:
        raise ValueError("Unsupported schema name")
    border = Border(constraints=[_constraint_from_payload(item) for item in payload["entity"]["border"].get("constraints", [])])
    tunnel_payload = payload["entity"]["tunnel"]
    tunnel = Tunnel(model=_model_from_payload(tunnel_payload["model"]), metadata=dict(tunnel_payload.get("metadata", {})))
    return EelStructuredEntity(border=border, tunnel=tunnel, context=dict(payload["entity"].get("context", {})))


def entity_to_json(entity: EelStructuredEntity, *, indent: int = 2) -> str:
    return json.dumps(entity_to_exchange_dict(entity), indent=indent, ensure_ascii=False)


def entity_from_json(text: str) -> EelStructuredEntity:
    return entity_from_exchange_dict(json.loads(text))


def save_entity(entity: EelStructuredEntity, path: str | Path) -> Path:
    path = Path(path)
    path.write_text(entity_to_json(entity), encoding="utf-8")
    return path


def load_entity(path: str | Path) -> EelStructuredEntity:
    path = Path(path)
    return entity_from_json(path.read_text(encoding="utf-8"))
