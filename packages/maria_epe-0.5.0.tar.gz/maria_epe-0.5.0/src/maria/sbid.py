from __future__ import annotations

from typing import Sequence

from epe_framework import lp_distance


def weighted_structural_divergence(
    left: Sequence[float],
    right: Sequence[float],
    weights: Sequence[float] | None = None,
) -> float:
    size = max(len(left), len(right))
    weights = list(weights or [1.0] * size)
    padded_left = list(left) + [0.0] * (len(weights) - len(left))
    padded_right = list(right) + [0.0] * (len(weights) - len(right))
    weighted_difference = [weights[i] * (padded_left[i] - padded_right[i]) for i in range(len(weights))]
    return lp_distance(weighted_difference, [0.0] * len(weighted_difference), p=2)


def alignment_similarity(
    left: Sequence[float],
    right: Sequence[float],
    weights: Sequence[float] | None = None,
) -> float:
    size = max(len(left), len(right))
    weights = list(weights or [1.0] * size)
    padded_left = list(left) + [0.0] * (len(weights) - len(left))
    padded_right = list(right) + [0.0] * (len(weights) - len(right))
    numerator = sum(weights[i] * padded_left[i] * padded_right[i] for i in range(len(weights)))
    left_norm = sum(weights[i] * padded_left[i] * padded_left[i] for i in range(len(weights))) ** 0.5
    right_norm = sum(weights[i] * padded_right[i] * padded_right[i] for i in range(len(weights))) ** 0.5
    if left_norm == 0.0 or right_norm == 0.0:
        return 0.0
    return numerator / (left_norm * right_norm)


def interaction_degree(left: Sequence[float], right: Sequence[float], threshold: float = 0.05) -> int:
    size = max(len(left), len(right))
    padded_left = list(left) + [0.0] * (size - len(left))
    padded_right = list(right) + [0.0] * (size - len(right))
    return 1 + sum(1 for i in range(size) if abs(padded_left[i] * padded_right[i]) > threshold)


def sbid_score(
    left: Sequence[float],
    right: Sequence[float],
    *,
    variance: float,
    weights: Sequence[float] | None = None,
    lambda_weight: float = 3.0,
    eta_weight: float = 2.0,
    rho_weight: float = 1.0,
    threshold: float = 0.05,
) -> float:
    delta_s = weighted_structural_divergence(left, right, weights)
    similarity = alignment_similarity(left, right, weights)
    degree = interaction_degree(left, right, threshold=threshold)
    return delta_s * (1.0 + lambda_weight * variance) * (1.0 + eta_weight * degree) * (1.0 - rho_weight * similarity)
