from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import shutil
import glob
import os


@dataclass(frozen=True, slots=True)
class BackendStatus:
    python_reference: bool
    julia_backend_present: bool
    julia_project_path: str
    julia_executable: str | None
    julia_runtime_available: bool


def get_backend_status() -> BackendStatus:
    root = Path(__file__).resolve().parents[2]
    julia_project = root / "julia" / "Project.toml"
    julia_executable = shutil.which("julia")
    if julia_executable is None:
        patterns = [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Julia-*", "bin", "julia.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Julia-*", "bin", "julia.exe"),
        ]
        candidates: list[str] = []
        for pattern in patterns:
            if pattern:
                candidates.extend(glob.glob(pattern))
        if candidates:
            candidates.sort()
            julia_executable = candidates[-1]
    return BackendStatus(
        python_reference=True,
        julia_backend_present=julia_project.exists(),
        julia_project_path=str(julia_project),
        julia_executable=julia_executable,
        julia_runtime_available=julia_executable is not None and julia_project.exists(),
    )
