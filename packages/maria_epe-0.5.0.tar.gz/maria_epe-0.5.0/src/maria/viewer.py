from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .structures import StructIndex


def render_struct_index_viewer(
    index: StructIndex,
    output_path: str | Path,
    *,
    query_data: Any | None = None,
    k: int = 5,
    title: str = "Maria StructIndex Viewer",
) -> str:
    payload = index.viewer_payload(query_data=query_data, k=k)
    rendered = _render_html(title, payload)
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(rendered, encoding="utf-8")
    return str(target)


def _render_html(title: str, payload: dict[str, Any]) -> str:
    data_json = json.dumps(payload, separators=(",", ":"))
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title}</title>
  <style>
    :root {{
      --ink: #132238;
      --paper: #f6f1e8;
      --panel: rgba(255, 250, 241, 0.78);
      --panel-strong: rgba(255, 248, 236, 0.92);
      --line: rgba(18, 34, 56, 0.16);
      --brand: #1d5c63;
      --brand-bright: #2a9d8f;
      --accent: #d97706;
      --danger: #c44536;
      --glow: rgba(42, 157, 143, 0.2);
      --shadow: 0 24px 60px rgba(17, 29, 48, 0.12);
      --radius: 20px;
      --mono: "Consolas", "Liberation Mono", monospace;
      --ui: "Trebuchet MS", "Segoe UI Variable", "Gill Sans", sans-serif;
      --serif: "Georgia", "Palatino Linotype", serif;
    }}
    * {{
      box-sizing: border-box;
    }}
    body {{
      margin: 0;
      font-family: var(--ui);
      color: var(--ink);
      background:
        radial-gradient(circle at top left, rgba(42, 157, 143, 0.18), transparent 34%),
        radial-gradient(circle at top right, rgba(217, 119, 6, 0.18), transparent 28%),
        linear-gradient(180deg, #f4efe5 0%, #efe6d8 100%);
      min-height: 100vh;
    }}
    .shell {{
      width: min(1540px, calc(100vw - 32px));
      margin: 18px auto 26px;
      display: grid;
      gap: 18px;
    }}
    .hero {{
      position: relative;
      overflow: hidden;
      border-radius: 28px;
      background:
        linear-gradient(145deg, rgba(255,255,255,0.86), rgba(255,248,236,0.74)),
        linear-gradient(90deg, rgba(29,92,99,0.16), rgba(217,119,6,0.1));
      border: 1px solid rgba(19, 34, 56, 0.08);
      box-shadow: var(--shadow);
      padding: 22px 24px;
    }}
    .hero::after {{
      content: "";
      position: absolute;
      inset: auto -80px -80px auto;
      width: 240px;
      height: 240px;
      background: radial-gradient(circle, rgba(42, 157, 143, 0.18), transparent 66%);
      pointer-events: none;
    }}
    .hero h1 {{
      margin: 0;
      font-family: var(--serif);
      font-size: clamp(28px, 4vw, 44px);
      letter-spacing: 0.02em;
      font-weight: 600;
    }}
    .hero p {{
      margin: 10px 0 0;
      max-width: 76ch;
      line-height: 1.55;
      color: rgba(19, 34, 56, 0.8);
    }}
    .summary-grid {{
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 12px;
      margin-top: 18px;
    }}
    .card {{
      background: var(--panel);
      border: 1px solid rgba(19, 34, 56, 0.08);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      backdrop-filter: blur(10px);
    }}
    .metric {{
      padding: 16px 16px 18px;
      transform: translateY(10px);
      opacity: 0;
      animation: rise 0.6s ease forwards;
    }}
    .metric:nth-child(2) {{ animation-delay: 0.06s; }}
    .metric:nth-child(3) {{ animation-delay: 0.12s; }}
    .metric:nth-child(4) {{ animation-delay: 0.18s; }}
    .metric:nth-child(5) {{ animation-delay: 0.24s; }}
    .metric-label {{
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: rgba(19, 34, 56, 0.6);
    }}
    .metric-value {{
      margin-top: 8px;
      font-size: 28px;
      font-weight: 700;
    }}
    .metric-note {{
      margin-top: 6px;
      color: rgba(19, 34, 56, 0.66);
      font-size: 13px;
    }}
    .workspace {{
      display: grid;
      grid-template-columns: minmax(360px, 0.9fr) minmax(460px, 1.2fr) minmax(330px, 0.9fr);
      gap: 18px;
      align-items: start;
    }}
    .panel {{
      padding: 16px;
    }}
    .panel h2 {{
      margin: 0 0 14px;
      font-size: 15px;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: rgba(19, 34, 56, 0.68);
    }}
    svg {{
      width: 100%;
      height: auto;
      display: block;
    }}
    .tree-node {{
      cursor: pointer;
      transition: transform 0.18s ease, filter 0.18s ease;
    }}
    .tree-node:hover,
    .point:hover {{
      filter: drop-shadow(0 6px 16px rgba(0,0,0,0.12));
      transform: translateY(-2px);
    }}
    .point {{
      cursor: pointer;
      transition: transform 0.18s ease, filter 0.18s ease;
    }}
    .pill-row {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 10px;
    }}
    .pill {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 7px 10px;
      border-radius: 999px;
      background: rgba(29, 92, 99, 0.08);
      color: var(--ink);
      font-size: 13px;
      border: 1px solid rgba(29, 92, 99, 0.08);
    }}
    .pill.danger {{
      background: rgba(196, 69, 54, 0.1);
      border-color: rgba(196, 69, 54, 0.12);
    }}
    .pill.warn {{
      background: rgba(217, 119, 6, 0.1);
      border-color: rgba(217, 119, 6, 0.14);
    }}
    .list {{
      display: grid;
      gap: 10px;
    }}
    .list-item {{
      padding: 12px 13px;
      border-radius: 16px;
      background: rgba(255,255,255,0.54);
      border: 1px solid rgba(19, 34, 56, 0.08);
      cursor: pointer;
      transition: border-color 0.18s ease, transform 0.18s ease, background 0.18s ease;
    }}
    .list-item:hover {{
      transform: translateY(-1px);
      border-color: rgba(29, 92, 99, 0.28);
      background: rgba(255,255,255,0.7);
    }}
    .list-item.active {{
      border-color: rgba(29, 92, 99, 0.42);
      background: rgba(42, 157, 143, 0.12);
    }}
    .list-item strong {{
      font-size: 15px;
    }}
    .tiny {{
      display: block;
      margin-top: 4px;
      font-size: 12px;
      color: rgba(19, 34, 56, 0.65);
    }}
    .inspector-title {{
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 12px;
    }}
    .inspector-title h3 {{
      margin: 0;
      font-family: var(--serif);
      font-size: 24px;
      font-weight: 600;
    }}
    .inspector-label {{
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: rgba(19, 34, 56, 0.62);
    }}
    .stats {{
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 10px;
      margin-top: 14px;
    }}
    .stat {{
      padding: 11px 12px;
      border-radius: 14px;
      background: rgba(255,255,255,0.56);
      border: 1px solid rgba(19, 34, 56, 0.06);
    }}
    .stat span {{
      display: block;
      font-size: 12px;
      color: rgba(19, 34, 56, 0.62);
      text-transform: uppercase;
      letter-spacing: 0.08em;
    }}
    .stat strong {{
      display: block;
      margin-top: 6px;
      font-size: 18px;
    }}
    pre {{
      margin: 0;
      padding: 13px;
      overflow: auto;
      border-radius: 16px;
      background: rgba(13, 27, 42, 0.92);
      color: #f8f7f2;
      font-family: var(--mono);
      font-size: 12px;
      line-height: 1.4;
    }}
    .subgrid {{
      display: grid;
      gap: 12px;
      margin-top: 14px;
    }}
    .query-box {{
      padding: 14px;
      border-radius: 16px;
      background: rgba(217, 119, 6, 0.08);
      border: 1px solid rgba(217, 119, 6, 0.12);
      margin-top: 14px;
    }}
    .legend {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 12px;
      color: rgba(19, 34, 56, 0.74);
      font-size: 13px;
    }}
    .dot {{
      width: 11px;
      height: 11px;
      border-radius: 999px;
      display: inline-block;
    }}
    .footer {{
      text-align: center;
      color: rgba(19, 34, 56, 0.56);
      font-size: 13px;
      padding-bottom: 20px;
    }}
    @keyframes rise {{
      from {{
        opacity: 0;
        transform: translateY(10px);
      }}
      to {{
        opacity: 1;
        transform: translateY(0);
      }}
    }}
    @media (max-width: 1180px) {{
      .summary-grid {{
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }}
      .workspace {{
        grid-template-columns: 1fr;
      }}
    }}
    @media (max-width: 720px) {{
      .shell {{
        width: min(100vw - 18px, 100%);
        margin: 10px auto 20px;
      }}
      .hero {{
        padding: 18px;
      }}
      .summary-grid {{
        grid-template-columns: 1fr;
      }}
      .stats {{
        grid-template-columns: 1fr;
      }}
    }}
  </style>
</head>
<body>
  <div class="shell">
    <section class="hero">
      <h1>{title}</h1>
      <p>Live inspection for a Piancé-aware <code>StructIndex</code>. Click a tree node or entity point to inspect prototypes, admissibility, border regions, and CZVS behavior without leaving the index view.</p>
      <div class="summary-grid" id="summary-grid"></div>
    </section>
    <section class="workspace">
      <div class="card panel">
        <h2>Structure Tree</h2>
        <svg id="tree-svg" viewBox="0 0 620 440" role="img" aria-label="Structure tree view"></svg>
        <div class="legend">
          <span><span class="dot" style="background:#245b8a"></span> internal split</span>
          <span><span class="dot" style="background:#d97706"></span> leaf region</span>
          <span><span class="dot" style="background:#2a9d8f"></span> representative prototype</span>
        </div>
        <div class="subgrid">
          <div>
            <h2>Tree Nodes</h2>
            <div id="node-list" class="list"></div>
          </div>
        </div>
      </div>
      <div class="card panel">
        <h2>Entity Field</h2>
        <svg id="entity-svg" viewBox="0 0 700 460" role="img" aria-label="Entity field view"></svg>
        <div class="legend">
          <span><span class="dot" style="background:#1d5c63"></span> admissible</span>
          <span><span class="dot" style="background:#c44536"></span> inadmissible</span>
          <span><span class="dot" style="background:#f4a261"></span> query point</span>
          <span><span class="dot" style="background:#2a9d8f"></span> prototype halo</span>
        </div>
        <div class="subgrid">
          <div>
            <h2>Prototypes</h2>
            <div id="prototype-list" class="list"></div>
          </div>
          <div>
            <h2>CZVS Candidates</h2>
            <div id="czvs-list" class="list"></div>
          </div>
        </div>
      </div>
      <div class="card panel">
        <div class="inspector-title">
          <div>
            <div class="inspector-label">Inspector</div>
            <h3 id="inspector-name">Waiting for selection</h3>
          </div>
          <div class="inspector-label" id="inspector-type">node</div>
        </div>
        <div id="inspector-pills" class="pill-row"></div>
        <div id="inspector-stats" class="stats"></div>
        <div class="subgrid">
          <div>
            <h2>Detail</h2>
            <pre id="inspector-json"></pre>
          </div>
          <div>
            <h2>Graph Clusters</h2>
            <div id="cluster-list" class="list"></div>
          </div>
          <div class="query-box" id="query-box"></div>
        </div>
      </div>
    </section>
    <div class="footer">Maria viewer generated from StructIndex payload. No external dependencies required.</div>
  </div>
  <script>
    const data = {data_json};
    const state = {{
      selectedNodeId: data.tree.root,
      selectedEntityId: data.prototypes.length ? data.prototypes[0].entity_id : (data.entities[0] ? data.entities[0].entity_id : null),
      mode: data.tree.root ? "node" : "entity"
    }};

    const nodeMap = Object.fromEntries((data.tree.nodes || []).map(node => [node.node_id, node]));
    const entityMap = Object.fromEntries((data.entities || []).map(entity => [entity.entity_id, entity]));
    const prototypeIds = new Set((data.prototypes || []).map(item => item.entity_id));
    const queryNeighborIds = new Set((((data.query || {{}}).neighbors) || []).map(item => item.entity_id));

    function fmt(value, digits = 3) {{
      if (value === null || value === undefined) return "n/a";
      if (typeof value === "number") return Number.isInteger(value) ? String(value) : value.toFixed(digits);
      return String(value);
    }}

    function escapeHtml(value) {{
      return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;");
    }}

    function metricCard(label, value, note) {{
      return `
        <div class="card metric">
          <div class="metric-label">${{label}}</div>
          <div class="metric-value">${{escapeHtml(value)}}</div>
          <div class="metric-note">${{escapeHtml(note)}}</div>
        </div>
      `;
    }}

    function renderSummary() {{
      const summary = data.summary || {{}};
      document.getElementById("summary-grid").innerHTML = [
        metricCard("Entities", fmt(summary.entity_count, 0), "indexed structural embeddings"),
        metricCard("Nodes", fmt(summary.node_count, 0), "Piancé tree regions"),
        metricCard("Leaves", fmt(summary.leaf_count, 0), "queryable structural bands"),
        metricCard("Admissibility", `${{fmt((summary.admissibility_rate || 0) * 100, 1)}}%`, "admissible entity share"),
        metricCard("CZVS Mean", fmt(summary.czvs_mean), "average distance to CZVS target"),
      ].join("");
    }}

    function scalePoints(items, width, height, keyX, keyY, padding = 50) {{
      if (!items.length) return [];
      const xs = items.map(item => item[keyX]);
      const ys = items.map(item => item[keyY]);
      const minX = Math.min(...xs);
      const maxX = Math.max(...xs);
      const minY = Math.min(...ys);
      const maxY = Math.max(...ys);
      const xSpan = Math.max(maxX - minX, 1);
      const ySpan = Math.max(maxY - minY, 1);
      return items.map(item => {{
        const x = padding + ((item[keyX] - minX) / xSpan) * (width - padding * 2);
        const y = height - padding - ((item[keyY] - minY) / ySpan) * (height - padding * 2);
        return {{ ...item, __sx: x, __sy: y }};
      }});
    }}

    function renderTree() {{
      const svg = document.getElementById("tree-svg");
      const width = 620;
      const height = 440;
      const nodes = scalePoints(data.tree.nodes || [], width, height, "layout_x", "layout_y", 52);
      const byId = Object.fromEntries(nodes.map(node => [node.node_id, node]));
      const lines = nodes.flatMap(node => {{
        const parts = [];
        if (node.left_id && byId[node.left_id]) {{
          parts.push(`<line x1="${{node.__sx}}" y1="${{node.__sy}}" x2="${{byId[node.left_id].__sx}}" y2="${{byId[node.left_id].__sy}}" stroke="rgba(19,34,56,0.18)" stroke-width="2"/>`);
        }}
        if (node.right_id && byId[node.right_id]) {{
          parts.push(`<line x1="${{node.__sx}}" y1="${{node.__sy}}" x2="${{byId[node.right_id].__sx}}" y2="${{byId[node.right_id].__sy}}" stroke="rgba(19,34,56,0.18)" stroke-width="2"/>`);
        }}
        return parts;
      }}).join("");
      const circles = nodes.map(node => {{
        const selected = state.mode === "node" && state.selectedNodeId === node.node_id;
        const color = node.is_leaf ? "#d97706" : "#245b8a";
        const radius = selected ? 22 : 18;
        const ring = node.representative_id ? `<circle cx="${{node.__sx}}" cy="${{node.__sy}}" r="${{radius + 7}}" fill="none" stroke="rgba(42,157,143,0.32)" stroke-width="4"/>` : "";
        return `
          <g class="tree-node" data-node="${{node.node_id}}">
            ${{ring}}
            <circle cx="${{node.__sx}}" cy="${{node.__sy}}" r="${{radius}}" fill="${{color}}" stroke="white" stroke-width="2.5"/>
            <text x="${{node.__sx}}" y="${{node.__sy - 2}}" fill="white" font-size="11" text-anchor="middle" font-weight="700">${{escapeHtml(node.node_id)}}</text>
            <text x="${{node.__sx}}" y="${{node.__sy + 12}}" fill="white" font-size="10" text-anchor="middle">${{escapeHtml("n=" + node.size)}}</text>
          </g>
        `;
      }}).join("");
      svg.innerHTML = lines + circles;
      svg.querySelectorAll(".tree-node").forEach(group => {{
        group.addEventListener("click", () => {{
          state.selectedNodeId = group.dataset.node;
          state.mode = "node";
          render();
        }});
      }});
    }}

    function renderEntityField() {{
      const svg = document.getElementById("entity-svg");
      const width = 700;
      const height = 460;
      const entities = scalePoints(data.entities || [], width, height, "x", "y", 58);
      const byId = Object.fromEntries(entities.map(entity => [entity.entity_id, entity]));
      const edgeMarkup = (data.graph.edges || []).map(edge => {{
        const left = byId[edge.left];
        const right = byId[edge.right];
        if (!left || !right) return "";
        return `<line x1="${{left.__sx}}" y1="${{left.__sy}}" x2="${{right.__sx}}" y2="${{right.__sy}}" stroke="rgba(29,92,99,0.16)" stroke-width="1.6"/>`;
      }}).join("");
      let queryMarkup = "";
      if (data.query && Array.isArray(data.query.query_embedding)) {{
        const queryPoint = {{
          x: data.query.query_embedding[0] || 0,
          y: data.query.query_embedding[1] || 0
        }};
        const scaled = scalePoints([...entities, queryPoint], width, height, "x", "y", 58).pop();
        queryMarkup = `<polygon points="${{scaled.__sx}},${{scaled.__sy - 14}} ${{scaled.__sx + 12}},${{scaled.__sy + 10}} ${{scaled.__sx - 12}},${{scaled.__sy + 10}}" fill="#f4a261" stroke="white" stroke-width="2"/>`;
      }}
      const pointMarkup = entities.map(entity => {{
        const admissible = Boolean(entity.metadata?.admissible ?? true);
        const selected = state.mode === "entity" && state.selectedEntityId === entity.entity_id;
        const fill = admissible ? "#1d5c63" : "#c44536";
        const radius = selected ? 12 : 8;
        const halo = prototypeIds.has(entity.entity_id) ? `<circle cx="${{entity.__sx}}" cy="${{entity.__sy}}" r="${{radius + 8}}" fill="none" stroke="rgba(42,157,143,0.32)" stroke-width="4"/>` : "";
        const queryHalo = queryNeighborIds.has(entity.entity_id) ? `<circle cx="${{entity.__sx}}" cy="${{entity.__sy}}" r="${{radius + 4}}" fill="none" stroke="rgba(217,119,6,0.58)" stroke-width="3"/>` : "";
        return `
          <g class="point" data-entity="${{entity.entity_id}}">
            ${{halo}}
            ${{queryHalo}}
            <circle cx="${{entity.__sx}}" cy="${{entity.__sy}}" r="${{radius}}" fill="${{fill}}" stroke="white" stroke-width="2.4"/>
            <text x="${{entity.__sx + 14}}" y="${{entity.__sy - 10}}" font-size="11" fill="rgba(19,34,56,0.84)">${{escapeHtml(entity.entity_id)}}</text>
          </g>
        `;
      }}).join("");
      svg.innerHTML = edgeMarkup + queryMarkup + pointMarkup;
      svg.querySelectorAll(".point").forEach(group => {{
        group.addEventListener("click", () => {{
          state.selectedEntityId = group.dataset.entity;
          state.mode = "entity";
          render();
        }});
      }});
    }}

    function renderNodeList() {{
      const list = document.getElementById("node-list");
      list.innerHTML = (data.tree.nodes || []).map(node => `
        <div class="list-item ${{state.mode === "node" && state.selectedNodeId === node.node_id ? "active" : ""}}" data-node="${{node.node_id}}">
          <strong>${{escapeHtml(node.node_id)}}</strong>
          <span class="tiny">depth ${{node.depth}} | size ${{node.size}} | prototype ${{escapeHtml(node.representative_id || "n/a")}}</span>
          <span class="tiny">admissibility ${{fmt((node.admissibility_rate || 0) * 100, 1)}}% | CZVS ${{fmt(node.czvs_mean)}}</span>
        </div>
      `).join("");
      list.querySelectorAll("[data-node]").forEach(item => {{
        item.addEventListener("click", () => {{
          state.selectedNodeId = item.dataset.node;
          state.mode = "node";
          render();
        }});
      }});
    }}

    function renderPrototypeList() {{
      const list = document.getElementById("prototype-list");
      list.innerHTML = (data.prototypes || []).map(item => `
        <div class="list-item ${{state.mode === "entity" && state.selectedEntityId === item.entity_id ? "active" : ""}}" data-entity="${{item.entity_id}}">
          <strong>${{escapeHtml(item.entity_id)}}</strong>
          <span class="tiny">node ${{escapeHtml(item.node_id)}} | depth ${{item.depth}}</span>
          <span class="tiny">${{escapeHtml((item.metadata || {{}}).border_region || "unlabeled")}} | admissible: ${{String((item.metadata || {{}}).admissible ?? true)}}</span>
        </div>
      `).join("") || `<div class="list-item"><strong>No prototypes yet</strong><span class="tiny">Add entities to the index to create representative regions.</span></div>`;
      list.querySelectorAll("[data-entity]").forEach(item => {{
        item.addEventListener("click", () => {{
          state.selectedEntityId = item.dataset.entity;
          state.mode = "entity";
          render();
        }});
      }});
    }}

    function renderCzvsList() {{
      const list = document.getElementById("czvs-list");
      list.innerHTML = (data.czvs_candidates || []).map(item => `
        <div class="list-item ${{state.mode === "entity" && state.selectedEntityId === item.entity_id ? "active" : ""}}" data-entity="${{item.entity_id}}">
          <strong>${{escapeHtml(item.entity_id)}}</strong>
          <span class="tiny">distance ${{fmt(item.czvs_distance)}} | region ${{escapeHtml((item.metadata || {{}}).border_region || "unlabeled")}}</span>
        </div>
      `).join("") || `<div class="list-item"><strong>No CZVS candidates</strong><span class="tiny">Set a CZVS target to see nearest entities here.</span></div>`;
      list.querySelectorAll("[data-entity]").forEach(item => {{
        item.addEventListener("click", () => {{
          state.selectedEntityId = item.dataset.entity;
          state.mode = "entity";
          render();
        }});
      }});
    }}

    function renderClusters() {{
      const list = document.getElementById("cluster-list");
      list.innerHTML = (data.graph.clusters || []).map((cluster, index) => `
        <div class="list-item">
          <strong>Cluster ${{index + 1}}</strong>
          <span class="tiny">prototype ${{escapeHtml(cluster.prototype_id)}} | size ${{cluster.size}} | admissibility ${{fmt((cluster.admissibility_rate || 0) * 100, 1)}}%</span>
          <span class="tiny">${{escapeHtml(JSON.stringify(cluster.border_regions || {{}}))}}</span>
        </div>
      `).join("") || `<div class="list-item"><strong>Graph not refreshed yet</strong><span class="tiny">Call <code>refresh_graph()</code> to populate cluster summaries.</span></div>`;
    }}

    function renderInspector() {{
      const name = document.getElementById("inspector-name");
      const type = document.getElementById("inspector-type");
      const pills = document.getElementById("inspector-pills");
      const stats = document.getElementById("inspector-stats");
      const detail = document.getElementById("inspector-json");
      if (state.mode === "entity" && state.selectedEntityId && entityMap[state.selectedEntityId]) {{
        const entity = entityMap[state.selectedEntityId];
        name.textContent = entity.entity_id;
        type.textContent = "entity";
        pills.innerHTML = `
          <span class="pill ${{entity.metadata?.admissible ? "" : "danger"}}">${{entity.metadata?.admissible ? "admissible" : "inadmissible"}}</span>
          <span class="pill">${{escapeHtml(entity.metadata?.border_region || "unlabeled")}}</span>
          <span class="pill warn">CZVS ${{fmt(entity.metadata?.czvs_distance)}}</span>
          <span class="pill">${{prototypeIds.has(entity.entity_id) ? "prototype" : "member"}}</span>
        `;
        stats.innerHTML = [
          ["x", fmt(entity.x)],
          ["y", fmt(entity.y)],
          ["neighbors", String((entity.neighbors || []).length)],
          ["trace states", String(entity.trace ? entity.trace.length : 0)],
        ].map(([label, value]) => `<div class="stat"><span>${{label}}</span><strong>${{escapeHtml(value)}}</strong></div>`).join("");
        detail.textContent = JSON.stringify(entity, null, 2);
        return;
      }}
      const node = nodeMap[state.selectedNodeId] || (data.tree.nodes || [])[0];
      if (!node) {{
        name.textContent = "No selection";
        type.textContent = "empty";
        pills.innerHTML = "";
        stats.innerHTML = "";
        detail.textContent = JSON.stringify(data.summary || {{}}, null, 2);
        return;
      }}
      state.selectedNodeId = node.node_id;
      name.textContent = node.node_id;
      type.textContent = "node";
      pills.innerHTML = `
        <span class="pill">${{node.is_leaf ? "leaf" : "internal split"}}</span>
        <span class="pill">${{escapeHtml(node.dominant_border_region || "unlabeled")}}</span>
        <span class="pill warn">prototype ${{escapeHtml(node.representative_id || "n/a")}}</span>
        <span class="pill">${{node.sbid_partition_score === null ? "SBID n/a" : "SBID " + fmt(node.sbid_partition_score)}}</span>
      `;
      stats.innerHTML = [
        ["size", fmt(node.size, 0)],
        ["variance", fmt(node.structural_variance)],
        ["admissibility", `${{fmt((node.admissibility_rate || 0) * 100, 1)}}%`],
        ["CZVS mean", fmt(node.czvs_mean)],
      ].map(([label, value]) => `<div class="stat"><span>${{label}}</span><strong>${{escapeHtml(value)}}</strong></div>`).join("");
      detail.textContent = JSON.stringify(node, null, 2);
    }}

    function renderQueryBox() {{
      const box = document.getElementById("query-box");
      if (!data.query) {{
        box.innerHTML = "<strong>No query payload</strong><div class='tiny'>Pass <code>query_data</code> when rendering to inspect a live neighborhood trace.</div>";
        return;
      }}
      const neighbors = (data.query.neighbors || []).map(item => `${{item.entity_id}} (${{fmt(item.distance)}})`).join(", ");
      const visited = (data.query.visited_nodes || []).join(" -> ");
      box.innerHTML = `
        <strong>Query Trace</strong>
        <div class="tiny" style="margin-top:8px">visited nodes: ${{escapeHtml(visited || "none")}}</div>
        <div class="tiny" style="margin-top:6px">nearest neighbors: ${{escapeHtml(neighbors || "none")}}</div>
      `;
    }}

    function render() {{
      renderSummary();
      renderTree();
      renderEntityField();
      renderNodeList();
      renderPrototypeList();
      renderCzvsList();
      renderClusters();
      renderInspector();
      renderQueryBox();
    }}

    render();
  </script>
</body>
</html>
"""
