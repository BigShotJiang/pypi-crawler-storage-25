from .api import MariaLibrary, entity, graph_tunnel, tensor_tunnel, trace_tunnel
from .backends import BackendStatus, get_backend_status
from .julia_bridge import JuliaBridge
from .sbid import alignment_similarity, interaction_degree, sbid_score, weighted_structural_divergence
from .structures import BasisProjector, StreamBuffer, StructGraph, StructIndex, StructureTree, StructureTreeNode, TimeTrace, TimeTraceEntry
from .serialization import (
    SCHEMA_NAME,
    SCHEMA_VERSION,
    entity_from_exchange_dict,
    entity_from_json,
    entity_to_exchange_dict,
    entity_to_json,
    load_entity,
    save_entity,
)
from .version import __version__
from .viewer import render_struct_index_viewer
from epe_framework import (
    AuditPolicy,
    AuditResult,
    Border,
    Constraint,
    EelStructuredEntity,
    ExponentialModel,
    GraphModel,
    LogisticModel,
    PolynomialModel,
    StructuralModel,
    TensorModel,
    TraceModel,
    Tunnel,
    audit_against,
    build_credit_border,
    credit_block_example,
    credit_review_example,
    fused_metric,
    lp_distance,
    polynomial_example,
    rate_divergence,
    structural_divergence,
)

__all__ = [
    "AuditPolicy",
    "AuditResult",
    "BackendStatus",
    "BasisProjector",
    "Border",
    "Constraint",
    "EelStructuredEntity",
    "ExponentialModel",
    "GraphModel",
    "JuliaBridge",
    "LogisticModel",
    "MariaLibrary",
    "PolynomialModel",
    "RuntimeImportBundle",
    "RuntimeImportConfig",
    "StreamBuffer",
    "StructGraph",
    "StructIndex",
    "StructuralModel",
    "StructureTree",
    "StructureTreeNode",
    "TensorModel",
    "TimeTrace",
    "TimeTraceEntry",
    "TraceModel",
    "Tunnel",
    "__version__",
    "alignment_similarity",
    "audit_against",
    "build_credit_border",
    "credit_block_example",
    "credit_review_example",
    "entity",
    "entity_from_exchange_dict",
    "entity_from_json",
    "entity_to_exchange_dict",
    "entity_to_json",
    "fused_metric",
    "get_backend_status",
    "graph_tunnel",
    "interaction_degree",
    "lp_distance",
    "load_entity",
    "polynomial_example",
    "rate_divergence",
    "render_struct_index_viewer",
    "render_runtime_viewer_from_path",
    "runtime_bundle_from_jsonl",
    "runtime_bundle_from_path",
    "runtime_bundle_from_payload",
    "runtime_template",
    "save_entity",
    "sbid_score",
    "SCHEMA_NAME",
    "SCHEMA_VERSION",
    "structural_divergence",
    "struct_index_from_runtime_bundle",
    "struct_index_from_runtime_path",
    "tensor_tunnel",
    "trace_tunnel",
    "weighted_structural_divergence",
]

_RUNTIME_EXPORTS = {
    "RuntimeImportBundle",
    "RuntimeImportConfig",
    "render_runtime_viewer_from_path",
    "runtime_bundle_from_jsonl",
    "runtime_bundle_from_path",
    "runtime_bundle_from_payload",
    "runtime_template",
    "struct_index_from_runtime_bundle",
    "struct_index_from_runtime_path",
}


def __getattr__(name: str):
    if name in _RUNTIME_EXPORTS:
        from . import runtime as _runtime

        value = getattr(_runtime, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module 'maria' has no attribute {name!r}")
