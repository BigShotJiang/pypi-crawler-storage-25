from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from itertools import combinations
from math import cos, pi, sin
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np

from .sbid import alignment_similarity, sbid_score


ArrayLike = Sequence[float] | np.ndarray


def _as_array(values: ArrayLike) -> np.ndarray:
    return np.asarray(values, dtype=float)


def _weighted_distance(left: ArrayLike, right: ArrayLike, weights: ArrayLike | None = None) -> float:
    a = _as_array(left)
    b = _as_array(right)
    size = max(len(a), len(b))
    if len(a) < size:
        a = np.pad(a, (0, size - len(a)))
    if len(b) < size:
        b = np.pad(b, (0, size - len(b)))
    w = np.ones(size) if weights is None else _as_array(weights)
    if len(w) < size:
        w = np.pad(w, (0, size - len(w)), constant_values=1.0)
    diff = (a - b) * w
    return float(np.linalg.norm(diff))


@dataclass(slots=True)
class StructureTreeNode:
    node_id: str
    depth: int
    ids: list[str]
    embeddings: list[np.ndarray]
    axis: int | None = None
    threshold: float | None = None
    centroid: np.ndarray | None = None
    bbox_min: np.ndarray | None = None
    bbox_max: np.ndarray | None = None
    structural_variance: float = 0.0
    admissible_count: int = 0
    inadmissible_count: int = 0
    admissibility_rate: float = 0.0
    border_regions: dict[str, int] = field(default_factory=dict)
    dominant_border_region: str | None = None
    czvs_mean: float | None = None
    czvs_min: float | None = None
    czvs_max: float | None = None
    representative_id: str | None = None
    sbid_partition_score: float | None = None
    left: "StructureTreeNode | None" = None
    right: "StructureTreeNode | None" = None

    @property
    def is_leaf(self) -> bool:
        return self.left is None and self.right is None

    @property
    def size(self) -> int:
        return len(self.ids)

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "depth": self.depth,
            "size": self.size,
            "axis": self.axis,
            "threshold": self.threshold,
            "centroid": self.centroid.tolist() if self.centroid is not None else None,
            "bbox_min": self.bbox_min.tolist() if self.bbox_min is not None else None,
            "bbox_max": self.bbox_max.tolist() if self.bbox_max is not None else None,
            "structural_variance": self.structural_variance,
            "admissible_count": self.admissible_count,
            "inadmissible_count": self.inadmissible_count,
            "admissibility_rate": self.admissibility_rate,
            "border_regions": self.border_regions,
            "dominant_border_region": self.dominant_border_region,
            "czvs_mean": self.czvs_mean,
            "czvs_min": self.czvs_min,
            "czvs_max": self.czvs_max,
            "representative_id": self.representative_id,
            "sbid_partition_score": self.sbid_partition_score,
            "leaf_ids": self.ids if self.is_leaf else [],
            "left": self.left.to_dict() if self.left is not None else None,
            "right": self.right.to_dict() if self.right is not None else None,
        }


@dataclass(slots=True)
class StructureTree:
    leaf_size: int = 8
    weights: Sequence[float] | None = None
    czvs_target: np.ndarray | None = None
    root: StructureTreeNode | None = None
    _node_counter: int = 0
    entity_embeddings: dict[str, np.ndarray] = field(default_factory=dict)
    entity_metadata: dict[str, dict[str, Any]] = field(default_factory=dict)

    def build(self, entities: Sequence[tuple[str, ArrayLike] | tuple[str, ArrayLike, Mapping[str, Any]]]) -> None:
        parsed = [self._normalize_entity(item) for item in entities]
        self.entity_embeddings = {entity_id: embedding for entity_id, embedding, _ in parsed}
        self.entity_metadata = {entity_id: dict(metadata) for entity_id, _, metadata in parsed}
        self._node_counter = 0
        records = [(entity_id, embedding) for entity_id, embedding, _ in parsed]
        self.root = self._build_recursive(records, depth=0)

    def _normalize_entity(
        self,
        item: tuple[str, ArrayLike] | tuple[str, ArrayLike, Mapping[str, Any]],
    ) -> tuple[str, np.ndarray, dict[str, Any]]:
        if len(item) == 2:
            entity_id, embedding = item
            metadata: dict[str, Any] = {}
        elif len(item) == 3:
            entity_id, embedding, metadata = item
            metadata = dict(metadata)
        else:
            raise ValueError("StructureTree entities must be (id, embedding) or (id, embedding, metadata)")
        return str(entity_id), _as_array(embedding), metadata

    def _next_node_id(self) -> str:
        node_id = f"node-{self._node_counter}"
        self._node_counter += 1
        return node_id

    def _summarize_node(
        self,
        ids: list[str],
        embeddings: list[np.ndarray],
    ) -> dict[str, Any]:
        matrix = np.vstack(embeddings) if embeddings else np.zeros((0, 0), dtype=float)
        centroid = matrix.mean(axis=0) if len(embeddings) else None
        bbox_min = matrix.min(axis=0) if len(embeddings) else None
        bbox_max = matrix.max(axis=0) if len(embeddings) else None
        structural_variance = float(np.mean(np.sum((matrix - centroid) ** 2, axis=1))) if len(embeddings) else 0.0

        admissible_count = 0
        border_regions: dict[str, int] = {}
        czvs_distances: list[float] = []
        representative_id = None

        if centroid is not None and ids:
            representative_id = min(ids, key=lambda entity_id: _weighted_distance(self.entity_embeddings[entity_id], centroid, self.weights))

        for entity_id in ids:
            metadata = self.entity_metadata.get(entity_id, {})
            admissible = bool(metadata.get("admissible", True))
            admissible_count += int(admissible)
            region = str(metadata.get("border_region", "unlabeled"))
            border_regions[region] = border_regions.get(region, 0) + 1

            if "czvs_distance" in metadata:
                czvs_distances.append(float(metadata["czvs_distance"]))
            elif self.czvs_target is not None:
                czvs_distances.append(_weighted_distance(self.entity_embeddings[entity_id], self.czvs_target, self.weights))

        size = len(ids)
        inadmissible_count = size - admissible_count
        admissibility_rate = admissible_count / size if size else 0.0
        dominant_border_region = max(border_regions.items(), key=lambda item: item[1])[0] if border_regions else None

        return {
            "centroid": centroid,
            "bbox_min": bbox_min,
            "bbox_max": bbox_max,
            "structural_variance": structural_variance,
            "admissible_count": admissible_count,
            "inadmissible_count": inadmissible_count,
            "admissibility_rate": admissibility_rate,
            "border_regions": border_regions,
            "dominant_border_region": dominant_border_region,
            "czvs_mean": float(np.mean(czvs_distances)) if czvs_distances else None,
            "czvs_min": float(np.min(czvs_distances)) if czvs_distances else None,
            "czvs_max": float(np.max(czvs_distances)) if czvs_distances else None,
            "representative_id": representative_id,
        }

    def _candidate_split(
        self,
        entities: Sequence[tuple[str, np.ndarray]],
    ) -> tuple[int, float, list[tuple[str, np.ndarray]], list[tuple[str, np.ndarray]], float] | None:
        if len(entities) <= self.leaf_size:
            return None

        ids = [entity_id for entity_id, _ in entities]
        embeddings = [embedding for _, embedding in entities]
        matrix = np.vstack(embeddings)
        parent_summary = self._summarize_node(ids, embeddings)
        parent_variance = parent_summary["structural_variance"]

        best: tuple[int, float, list[tuple[str, np.ndarray]], list[tuple[str, np.ndarray]], float] | None = None
        best_score = float("-inf")
        for axis in range(matrix.shape[1]):
            ordered = sorted(entities, key=lambda item: float(item[1][axis]))
            pivot = len(ordered) // 2
            left = ordered[:pivot]
            right = ordered[pivot:]
            if not left or not right:
                continue
            left_max = float(left[-1][1][axis])
            right_min = float(right[0][1][axis])
            threshold = (left_max + right_min) / 2.0
            if left_max == right_min:
                continue

            left_ids = [entity_id for entity_id, _ in left]
            right_ids = [entity_id for entity_id, _ in right]
            left_embeddings = [embedding for _, embedding in left]
            right_embeddings = [embedding for _, embedding in right]
            left_summary = self._summarize_node(left_ids, left_embeddings)
            right_summary = self._summarize_node(right_ids, right_embeddings)

            weighted_child_variance = (
                left_summary["structural_variance"] * len(left) + right_summary["structural_variance"] * len(right)
            ) / len(ordered)
            variance_gain = parent_variance - weighted_child_variance
            balance = 1.0 - abs(len(left) - len(right)) / len(ordered)
            left_centroid = left_summary["centroid"].tolist() if left_summary["centroid"] is not None else []
            right_centroid = right_summary["centroid"].tolist() if right_summary["centroid"] is not None else []
            split_sbid = sbid_score(
                left_centroid,
                right_centroid,
                variance=(left_summary["structural_variance"] + right_summary["structural_variance"]) / 2.0,
                weights=self.weights,
            )
            split_similarity = alignment_similarity(left_centroid, right_centroid, self.weights)
            score = variance_gain + 0.5 * balance - 0.08 * split_sbid + 0.15 * split_similarity
            if score > best_score:
                best_score = score
                best = (axis, threshold, left, right, float(split_sbid))
        return best

    def _make_node(
        self,
        ids: list[str],
        embeddings: list[np.ndarray],
        *,
        depth: int,
        axis: int | None = None,
        threshold: float | None = None,
        sbid_partition_score: float | None = None,
        left: StructureTreeNode | None = None,
        right: StructureTreeNode | None = None,
    ) -> StructureTreeNode:
        summary = self._summarize_node(ids, embeddings)
        return StructureTreeNode(
            node_id=self._next_node_id(),
            depth=depth,
            ids=ids,
            embeddings=embeddings,
            axis=axis,
            threshold=threshold,
            centroid=summary["centroid"],
            bbox_min=summary["bbox_min"],
            bbox_max=summary["bbox_max"],
            structural_variance=summary["structural_variance"],
            admissible_count=summary["admissible_count"],
            inadmissible_count=summary["inadmissible_count"],
            admissibility_rate=summary["admissibility_rate"],
            border_regions=summary["border_regions"],
            dominant_border_region=summary["dominant_border_region"],
            czvs_mean=summary["czvs_mean"],
            czvs_min=summary["czvs_min"],
            czvs_max=summary["czvs_max"],
            representative_id=summary["representative_id"],
            sbid_partition_score=sbid_partition_score,
            left=left,
            right=right,
        )

    def _build_recursive(self, entities: Sequence[tuple[str, np.ndarray]], depth: int) -> StructureTreeNode:
        ids = [entity_id for entity_id, _ in entities]
        embeddings = [embedding for _, embedding in entities]
        split = self._candidate_split(entities)
        if split is None:
            return self._make_node(ids, embeddings, depth=depth)

        axis, threshold, left_records, right_records, split_sbid = split
        left = self._build_recursive(left_records, depth=depth + 1)
        right = self._build_recursive(right_records, depth=depth + 1)
        return self._make_node(
            ids,
            embeddings,
            depth=depth,
            axis=axis,
            threshold=threshold,
            sbid_partition_score=split_sbid,
            left=left,
            right=right,
        )

    def weighted_distance(self, emb1: ArrayLike, emb2: ArrayLike) -> float:
        return _weighted_distance(emb1, emb2, self.weights)

    def iter_nodes(self) -> Iterable[StructureTreeNode]:
        if self.root is None:
            return []
        queue = deque([self.root])
        ordered: list[StructureTreeNode] = []
        while queue:
            node = queue.popleft()
            ordered.append(node)
            if node.left is not None:
                queue.append(node.left)
            if node.right is not None:
                queue.append(node.right)
        return ordered

    def levels(self) -> list[list[StructureTreeNode]]:
        buckets: dict[int, list[StructureTreeNode]] = {}
        for node in self.iter_nodes():
            buckets.setdefault(node.depth, []).append(node)
        return [buckets[depth] for depth in sorted(buckets)]

    def to_dict(self) -> dict[str, Any]:
        return self.root.to_dict() if self.root is not None else {}

    def node_map(self) -> dict[str, StructureTreeNode]:
        return {node.node_id: node for node in self.iter_nodes()}

    def find_node(self, node_id: str) -> StructureTreeNode | None:
        return self.node_map().get(node_id)

    def path_for_embedding(self, query_emb: ArrayLike) -> list[StructureTreeNode]:
        if self.root is None:
            return []
        query = _as_array(query_emb)
        path: list[StructureTreeNode] = []
        node = self.root
        while node is not None:
            path.append(node)
            if node.is_leaf:
                break
            assert node.axis is not None and node.threshold is not None
            node = node.left if query[node.axis] <= node.threshold else node.right
        return path

    def insert(self, entity_id: str, embedding: ArrayLike, metadata: Mapping[str, Any] | None = None) -> None:
        record_id = str(entity_id)
        vector = _as_array(embedding)
        if record_id in self.entity_embeddings:
            self.remove(record_id)
        self.entity_embeddings[record_id] = vector
        self.entity_metadata[record_id] = dict(metadata or {})
        if self.root is None:
            self._node_counter = 0
            self.root = self._make_node([record_id], [vector], depth=0)
            return
        self.root = self._insert_recursive(self.root, record_id, vector)

    def _split_leaf(self, node: StructureTreeNode) -> StructureTreeNode:
        entities = [(entity_id, self.entity_embeddings[entity_id]) for entity_id in node.ids]
        split = self._candidate_split(entities)
        if split is None:
            return self._make_node(node.ids, node.embeddings, depth=node.depth)
        axis, threshold, left_records, right_records, split_sbid = split
        left = self._build_recursive(left_records, depth=node.depth + 1)
        right = self._build_recursive(right_records, depth=node.depth + 1)
        ids = [entity_id for entity_id, _ in entities]
        embeddings = [embedding for _, embedding in entities]
        return self._make_node(
            ids,
            embeddings,
            depth=node.depth,
            axis=axis,
            threshold=threshold,
            sbid_partition_score=split_sbid,
            left=left,
            right=right,
        )

    def _insert_recursive(self, node: StructureTreeNode, entity_id: str, embedding: np.ndarray) -> StructureTreeNode:
        ids = list(node.ids) + [entity_id]
        embeddings = list(node.embeddings) + [embedding]
        if node.is_leaf:
            refreshed = self._make_node(ids, embeddings, depth=node.depth)
            if refreshed.size > self.leaf_size:
                return self._split_leaf(refreshed)
            return refreshed

        assert node.axis is not None and node.threshold is not None and node.left is not None and node.right is not None
        if embedding[node.axis] <= node.threshold:
            left = self._insert_recursive(node.left, entity_id, embedding)
            right = node.right
        else:
            left = node.left
            right = self._insert_recursive(node.right, entity_id, embedding)
        return self._make_node(
            ids,
            embeddings,
            depth=node.depth,
            axis=node.axis,
            threshold=node.threshold,
            sbid_partition_score=node.sbid_partition_score,
            left=left,
            right=right,
        )

    def remove(self, entity_id: str) -> None:
        record_id = str(entity_id)
        if record_id not in self.entity_embeddings or self.root is None:
            return
        self.root = self._remove_recursive(self.root, record_id)
        self.entity_embeddings.pop(record_id, None)
        self.entity_metadata.pop(record_id, None)

    def _remove_recursive(self, node: StructureTreeNode | None, entity_id: str) -> StructureTreeNode | None:
        if node is None or entity_id not in node.ids:
            return node

        ids = [current_id for current_id in node.ids if current_id != entity_id]
        embeddings = [self.entity_embeddings[current_id] for current_id in ids]
        if not ids:
            return None

        if node.is_leaf:
            return self._make_node(ids, embeddings, depth=node.depth)

        left = self._remove_recursive(node.left, entity_id)
        right = self._remove_recursive(node.right, entity_id)
        if left is None:
            return right
        if right is None:
            return left
        if left.is_leaf and right.is_leaf and (left.size + right.size) <= self.leaf_size:
            merged_ids = left.ids + right.ids
            merged_embeddings = left.embeddings + right.embeddings
            return self._make_node(merged_ids, merged_embeddings, depth=node.depth)
        return self._make_node(
            ids,
            embeddings,
            depth=node.depth,
            axis=node.axis,
            threshold=node.threshold,
            sbid_partition_score=node.sbid_partition_score,
            left=left,
            right=right,
        )

    def update(self, entity_id: str, embedding: ArrayLike | None = None, metadata: Mapping[str, Any] | None = None) -> None:
        record_id = str(entity_id)
        if record_id in self.entity_embeddings:
            current_embedding = self.entity_embeddings[record_id]
            current_metadata = dict(self.entity_metadata.get(record_id, {}))
            self.remove(record_id)
        else:
            current_embedding = None
            current_metadata = {}

        if embedding is None and current_embedding is None:
            raise ValueError("update requires an existing entity or a new embedding")
        merged_metadata = current_metadata
        if metadata is not None:
            merged_metadata.update(metadata)
        self.insert(record_id, embedding if embedding is not None else current_embedding, merged_metadata)

    def query(self, query_emb: ArrayLike, k: int = 5) -> list[tuple[str, float]]:
        if self.root is None:
            return []
        query = _as_array(query_emb)
        best: list[tuple[str, float]] = []

        def search(node: StructureTreeNode) -> None:
            if node.is_leaf:
                for entity_id, embedding in zip(node.ids, node.embeddings):
                    distance = self.weighted_distance(query, embedding)
                    best.append((entity_id, distance))
                return

            assert node.axis is not None and node.threshold is not None and node.left is not None and node.right is not None
            primary = node.left if query[node.axis] <= node.threshold else node.right
            secondary = node.right if primary is node.left else node.left
            search(primary)
            best.sort(key=lambda item: item[1])
            if len(best) < k or abs(query[node.axis] - node.threshold) < best[min(len(best), k) - 1][1]:
                search(secondary)

        search(self.root)
        best.sort(key=lambda item: item[1])
        return best[:k]

    def query_trace(self, query_emb: ArrayLike, k: int = 5) -> dict[str, Any]:
        if self.root is None:
            return {"visited_nodes": [], "neighbors": []}
        query = _as_array(query_emb)
        visited_nodes: list[str] = []
        best: list[tuple[str, float]] = []

        def search(node: StructureTreeNode) -> None:
            visited_nodes.append(node.node_id)
            if node.is_leaf:
                for entity_id, embedding in zip(node.ids, node.embeddings):
                    best.append((entity_id, self.weighted_distance(query, embedding)))
                return

            assert node.axis is not None and node.threshold is not None and node.left is not None and node.right is not None
            primary = node.left if query[node.axis] <= node.threshold else node.right
            secondary = node.right if primary is node.left else node.left
            search(primary)
            best.sort(key=lambda item: item[1])
            if len(best) < k or abs(query[node.axis] - node.threshold) < best[min(len(best), k) - 1][1]:
                search(secondary)

        search(self.root)
        best.sort(key=lambda item: item[1])
        return {"visited_nodes": visited_nodes, "neighbors": best[:k]}


@dataclass(slots=True)
class StreamBuffer:
    dim: int
    decay: float = 0.95
    weight: float = 0.0
    sum_vec: np.ndarray = field(init=False)
    sum_sq_vec: np.ndarray = field(init=False)

    def __post_init__(self) -> None:
        self.sum_vec = np.zeros(self.dim, dtype=float)
        self.sum_sq_vec = np.zeros(self.dim, dtype=float)

    def add_entity(self, entity_data: ArrayLike) -> None:
        vector = _as_array(entity_data)
        self.sum_vec = self.decay * self.sum_vec + vector
        self.sum_sq_vec = self.decay * self.sum_sq_vec + vector * vector
        self.weight = self.decay * self.weight + 1.0

    def current_embedding(self) -> np.ndarray:
        if self.weight == 0.0:
            return np.zeros(self.dim, dtype=float)
        return self.sum_vec / self.weight

    def current_variance(self) -> np.ndarray:
        if self.weight == 0.0:
            return np.zeros(self.dim, dtype=float)
        mean = self.current_embedding()
        return np.maximum((self.sum_sq_vec / self.weight) - mean * mean, 0.0)

    def compare_with_reference(self, ref_emb: ArrayLike, weights: ArrayLike | None = None) -> float:
        return _weighted_distance(self.current_embedding(), ref_emb, weights)

    def snapshot(self, ref_emb: ArrayLike | None = None, weights: ArrayLike | None = None) -> dict[str, Any]:
        snapshot = {
            "weight": self.weight,
            "embedding": self.current_embedding().tolist(),
            "variance": self.current_variance().tolist(),
        }
        if ref_emb is not None:
            snapshot["reference_distance"] = self.compare_with_reference(ref_emb, weights)
        return snapshot


@dataclass(slots=True)
class BasisProjector:
    input_dim: int
    basis_size: int
    basis_type: str = "fourier"
    seed: int = 7
    basis_matrix: np.ndarray = field(init=False)

    def __post_init__(self) -> None:
        self.basis_matrix = self._build_basis()

    def _build_basis(self) -> np.ndarray:
        if self.basis_type == "identity":
            return np.eye(self.basis_size, self.input_dim, dtype=float)
        if self.basis_type == "random":
            rng = np.random.default_rng(self.seed)
            return rng.normal(0.0, 1.0, size=(self.basis_size, self.input_dim))
        if self.basis_type == "polynomial":
            grid = np.linspace(-1.0, 1.0, self.input_dim)
            return np.vstack([grid ** power for power in range(self.basis_size)])

        grid = np.arange(1, self.input_dim + 1, dtype=float)
        rows = []
        for index in range(self.basis_size):
            frequency = index // 2 + 1
            if index % 2 == 0:
                rows.append([cos(pi * frequency * value / self.input_dim) for value in grid])
            else:
                rows.append([sin(pi * frequency * value / self.input_dim) for value in grid])
        return np.asarray(rows, dtype=float)

    def embed(self, entity_indicator: ArrayLike) -> np.ndarray:
        vector = _as_array(entity_indicator)
        return self.basis_matrix @ vector

    def embed_batch(self, entities: Sequence[ArrayLike]) -> np.ndarray:
        matrix = np.vstack([_as_array(entity) for entity in entities])
        return matrix @ self.basis_matrix.T

    def to_sparse(self, threshold: float = 1e-9) -> dict[tuple[int, int], float]:
        sparse: dict[tuple[int, int], float] = {}
        for row in range(self.basis_matrix.shape[0]):
            for col in range(self.basis_matrix.shape[1]):
                value = float(self.basis_matrix[row, col])
                if abs(value) > threshold:
                    sparse[(row, col)] = value
        return sparse

    def summary(self) -> dict[str, Any]:
        row_energy = [float(np.linalg.norm(row)) for row in self.basis_matrix]
        return {
            "basis_type": self.basis_type,
            "input_dim": self.input_dim,
            "basis_size": self.basis_size,
            "row_energy": row_energy,
            "sparse_nnz": len(self.to_sparse()),
        }


@dataclass(slots=True)
class StructGraph:
    nodes: dict[str, np.ndarray] = field(default_factory=dict)
    edges: dict[tuple[str, str], float] = field(default_factory=dict)
    metadata: dict[str, dict[str, Any]] = field(default_factory=dict)
    weights: Sequence[float] | None = None

    def add_entity(self, entity_id: str, embedding: ArrayLike, metadata: Mapping[str, Any] | None = None) -> None:
        self.nodes[entity_id] = _as_array(embedding)
        self.metadata[entity_id] = dict(metadata or {})

    def compute_all_divergences(self, weights: ArrayLike | None = None, threshold: float | None = None) -> None:
        self.weights = list(weights) if weights is not None else self.weights
        self.edges.clear()
        for left, right in combinations(self.nodes.keys(), 2):
            distance = _weighted_distance(self.nodes[left], self.nodes[right], self.weights)
            if threshold is None or distance <= threshold:
                self.edges[tuple(sorted((left, right)))] = distance

    def _adjacency(self) -> dict[str, set[str]]:
        adjacency = {node: set() for node in self.nodes}
        for left, right in self.edges:
            adjacency[left].add(right)
            adjacency[right].add(left)
        return adjacency

    def find_structural_clusters(self, method: str = "connected") -> list[list[str]]:
        adjacency = self._adjacency()
        remaining = set(adjacency.keys())
        clusters: list[list[str]] = []
        while remaining:
            start = remaining.pop()
            queue = deque([start])
            cluster = [start]
            while queue:
                current = queue.popleft()
                for neighbor in adjacency[current]:
                    if neighbor in remaining:
                        remaining.remove(neighbor)
                        queue.append(neighbor)
                        cluster.append(neighbor)
            clusters.append(sorted(cluster))
        return sorted(clusters, key=len, reverse=True)

    def k_nearest_neighbors(self, entity_id: str, k: int = 5) -> list[tuple[str, float]]:
        if entity_id not in self.nodes:
            return []
        distances = []
        for other_id, embedding in self.nodes.items():
            if other_id == entity_id:
                continue
            distances.append((other_id, _weighted_distance(self.nodes[entity_id], embedding, self.weights)))
        distances.sort(key=lambda item: item[1])
        return distances[:k]

    def node_summary(self, entity_id: str) -> dict[str, Any]:
        embedding = self.nodes[entity_id]
        metadata = dict(self.metadata.get(entity_id, {}))
        degree = sum(entity_id in edge for edge in self.edges)
        return {
            "entity_id": entity_id,
            "embedding": embedding.tolist(),
            "degree": degree,
            "metadata": metadata,
            "neighbors": self.k_nearest_neighbors(entity_id, k=min(5, max(len(self.nodes) - 1, 0))),
        }

    def prototype_entities(self) -> list[dict[str, Any]]:
        prototypes: list[dict[str, Any]] = []
        for cluster in self.find_structural_clusters():
            if not cluster:
                continue
            if len(cluster) == 1:
                entity_id = cluster[0]
                prototypes.append(
                    {
                        "cluster": cluster,
                        "prototype_id": entity_id,
                        "mean_cluster_distance": 0.0,
                    }
                )
                continue
            scores = []
            for entity_id in cluster:
                distances = [
                    _weighted_distance(self.nodes[entity_id], self.nodes[other_id], self.weights)
                    for other_id in cluster
                    if other_id != entity_id
                ]
                scores.append((entity_id, float(np.mean(distances))))
            prototype_id, mean_distance = min(scores, key=lambda item: item[1])
            prototypes.append(
                {
                    "cluster": cluster,
                    "prototype_id": prototype_id,
                    "mean_cluster_distance": mean_distance,
                }
            )
        return prototypes

    def cluster_summary(self) -> list[dict[str, Any]]:
        summary: list[dict[str, Any]] = []
        for prototype in self.prototype_entities():
            cluster = prototype["cluster"]
            border_regions: dict[str, int] = {}
            admissible = 0
            for entity_id in cluster:
                metadata = self.metadata.get(entity_id, {})
                admissible += int(bool(metadata.get("admissible", True)))
                region = str(metadata.get("border_region", "unlabeled"))
                border_regions[region] = border_regions.get(region, 0) + 1
            summary.append(
                {
                    **prototype,
                    "size": len(cluster),
                    "admissibility_rate": admissible / len(cluster) if cluster else 0.0,
                    "border_regions": border_regions,
                }
            )
        return summary


@dataclass(slots=True)
class TimeTraceEntry:
    timestamp: Any
    embedding: np.ndarray
    metadata: dict[str, Any]


@dataclass(slots=True)
class TimeTrace:
    entries: list[TimeTraceEntry] = field(default_factory=list)
    weights: Sequence[float] | None = None

    def add_state(self, timestamp: Any, entity_state: ArrayLike, metadata: Mapping[str, Any] | None = None) -> None:
        self.entries.append(TimeTraceEntry(timestamp=timestamp, embedding=_as_array(entity_state), metadata=dict(metadata or {})))

    def structural_drift(self, window_size: int = 1) -> list[tuple[Any, float]]:
        drifts: list[tuple[Any, float]] = []
        for index in range(window_size, len(self.entries)):
            current = self.entries[index]
            previous = self.entries[index - window_size]
            drifts.append((current.timestamp, _weighted_distance(current.embedding, previous.embedding, self.weights)))
        return drifts

    def czvs_proximity(self, target_emb: ArrayLike, weights: ArrayLike | None = None) -> list[tuple[Any, float]]:
        return [
            (entry.timestamp, _weighted_distance(entry.embedding, target_emb, weights or self.weights))
            for entry in self.entries
        ]

    def variance_under_perturbations(
        self,
        perturb_gen: Callable[[np.ndarray, int, Mapping[str, Any]], ArrayLike],
        num_samples: int = 10,
    ) -> list[tuple[Any, float]]:
        variances: list[tuple[Any, float]] = []
        for entry in self.entries:
            distances = []
            for sample_idx in range(num_samples):
                perturbed = _as_array(perturb_gen(entry.embedding.copy(), sample_idx, entry.metadata))
                distances.append(_weighted_distance(entry.embedding, perturbed, self.weights))
            variances.append((entry.timestamp, float(np.var(distances))))
        return variances

    def summary(self, target_emb: ArrayLike | None = None) -> dict[str, Any]:
        timestamps = [entry.timestamp for entry in self.entries]
        drift = self.structural_drift()
        border_regions: dict[str, int] = {}
        admissible = 0
        for entry in self.entries:
            admissible += int(bool(entry.metadata.get("admissible", True)))
            region = str(entry.metadata.get("border_region", "unlabeled"))
            border_regions[region] = border_regions.get(region, 0) + 1
        payload = {
            "length": len(self.entries),
            "timestamps": timestamps,
            "latest_embedding": self.entries[-1].embedding.tolist() if self.entries else [],
            "latest_metadata": dict(self.entries[-1].metadata) if self.entries else {},
            "mean_drift": float(np.mean([value for _, value in drift])) if drift else 0.0,
            "max_drift": float(np.max([value for _, value in drift])) if drift else 0.0,
            "admissibility_rate": admissible / len(self.entries) if self.entries else 0.0,
            "border_regions": border_regions,
        }
        if target_emb is not None:
            proximity = self.czvs_proximity(target_emb)
            payload["czvs_latest"] = proximity[-1][1] if proximity else None
            payload["czvs_min"] = min((value for _, value in proximity), default=None)
        return payload


@dataclass(slots=True)
class StructIndex:
    weights: Sequence[float] | None = None
    tree_leaf_size: int = 8
    graph_threshold: float | None = None
    czvs_target: ArrayLike | None = None
    entities: dict[str, np.ndarray] = field(default_factory=dict)
    metadata: dict[str, dict[str, Any]] = field(default_factory=dict)
    projector: BasisProjector | None = None
    tree: StructureTree = field(init=False)
    graph: StructGraph = field(init=False)
    traces: dict[str, TimeTrace] = field(default_factory=dict)
    stream: StreamBuffer | None = field(init=False, default=None)

    def __post_init__(self) -> None:
        self.tree = StructureTree(leaf_size=self.tree_leaf_size, weights=self.weights, czvs_target=_as_array(self.czvs_target) if self.czvs_target is not None else None)
        self.graph = StructGraph(weights=self.weights)

    def _resolve_embedding(self, data: Any) -> np.ndarray:
        if hasattr(data, "signature") and callable(data.signature):
            return _as_array(data.signature())
        vector = _as_array(data)
        if self.projector is not None and vector.ndim == 1 and len(vector) == self.projector.input_dim:
            return self.projector.embed(vector)
        return vector

    def _tree_entities(self) -> list[tuple[str, np.ndarray, dict[str, Any]]]:
        return [
            (entity_id, embedding, dict(self.metadata.get(entity_id, {})))
            for entity_id, embedding in self.entities.items()
        ]

    def _rebuild_tree(self) -> None:
        if not self.entities:
            self.tree.root = None
            self.tree.entity_embeddings.clear()
            self.tree.entity_metadata.clear()
            return
        self.tree.build(self._tree_entities())

    def _ensure_stream(self, dim: int) -> None:
        if self.stream is None or self.stream.dim != dim:
            self.stream = StreamBuffer(dim=dim)

    def _rebuild_stream(self) -> None:
        if not self.entities:
            self.stream = None
            return
        first_embedding = next(iter(self.entities.values()))
        rebuilt = StreamBuffer(dim=len(first_embedding))
        for embedding in self.entities.values():
            rebuilt.add_entity(embedding)
        self.stream = rebuilt

    def _normalize_metadata(self, entity_id: str, metadata: Mapping[str, Any] | None, embedding: np.ndarray) -> dict[str, Any]:
        enriched = dict(metadata or {})
        if "border_region" not in enriched:
            enriched["border_region"] = "unlabeled"
        if "admissible" not in enriched:
            enriched["admissible"] = True
        if self.tree.czvs_target is not None:
            enriched["czvs_distance"] = _weighted_distance(embedding, self.tree.czvs_target, self.weights)
        else:
            enriched.pop("czvs_distance", None)
        enriched.setdefault("prototype_hint", entity_id)
        return enriched

    def add_entity(
        self,
        entity_id: str,
        data: Any,
        metadata: Mapping[str, Any] | None = None,
        type: str = "static",
        timestamp: Any | None = None,
    ) -> None:
        embedding = self._resolve_embedding(data)
        normalized_metadata = self._normalize_metadata(entity_id, metadata, embedding)
        self.entities[entity_id] = embedding
        self.metadata[entity_id] = normalized_metadata
        self.graph.add_entity(entity_id, embedding, normalized_metadata)
        self._rebuild_stream()
        self._rebuild_tree()
        if timestamp is not None or type == "dynamic":
            trace = self.traces.setdefault(entity_id, TimeTrace(weights=self.weights))
            trace.add_state(timestamp if timestamp is not None else len(trace.entries), embedding, normalized_metadata)

    def update_entity(
        self,
        entity_id: str,
        data: Any | None = None,
        metadata: Mapping[str, Any] | None = None,
        timestamp: Any | None = None,
    ) -> None:
        if entity_id not in self.entities and data is None:
            raise ValueError("update_entity requires an existing entity or new data")
        embedding = self.entities[entity_id] if data is None else self._resolve_embedding(data)
        merged_metadata = dict(self.metadata.get(entity_id, {}))
        if metadata is not None:
            merged_metadata.update(metadata)
        self.entities[entity_id] = embedding
        normalized_metadata = self._normalize_metadata(entity_id, merged_metadata, embedding)
        self.metadata[entity_id] = normalized_metadata
        self.graph.add_entity(entity_id, embedding, normalized_metadata)
        self._rebuild_stream()
        self._rebuild_tree()
        if entity_id in self.traces or timestamp is not None:
            trace = self.traces.setdefault(entity_id, TimeTrace(weights=self.weights))
            trace.add_state(timestamp if timestamp is not None else len(trace.entries), embedding, normalized_metadata)

    def remove_entity(self, entity_id: str) -> None:
        self.entities.pop(entity_id, None)
        self.metadata.pop(entity_id, None)
        self.graph.nodes.pop(entity_id, None)
        self.graph.metadata.pop(entity_id, None)
        self.graph.edges = {
            edge: distance for edge, distance in self.graph.edges.items() if entity_id not in edge
        }
        self.traces.pop(entity_id, None)
        self._rebuild_stream()
        self._rebuild_tree()

    def refresh_graph(self, threshold: float | None = None) -> None:
        self.graph.compute_all_divergences(weights=self.weights, threshold=threshold if threshold is not None else self.graph_threshold)

    def query_similar(self, query_data: Any, k: int = 5) -> list[tuple[str, float]]:
        if self.tree.root is None:
            return []
        query_embedding = self._resolve_embedding(query_data)
        return self.tree.query(query_embedding, k=k)

    def query_similar_with_context(self, query_data: Any, k: int = 5) -> dict[str, Any]:
        query_embedding = self._resolve_embedding(query_data)
        neighbors = self.query_similar(query_embedding, k=k)
        trace = self.tree.query_trace(query_embedding, k=k)
        return {
            "query_embedding": query_embedding.tolist(),
            "neighbors": [
                {
                    "entity_id": entity_id,
                    "distance": distance,
                    "metadata": dict(self.metadata.get(entity_id, {})),
                }
                for entity_id, distance in neighbors
            ],
            "visited_nodes": trace["visited_nodes"],
        }

    def structural_divergence(self, id1: str, id2: str) -> float:
        return _weighted_distance(self.entities[id1], self.entities[id2], self.weights)

    def get_time_series(self, entity_id: str) -> TimeTrace | None:
        return self.traces.get(entity_id)

    def find_czvs_pairs(self, target_id: str, eps: float) -> list[tuple[str, float]]:
        results = []
        for entity_id, embedding in self.entities.items():
            if entity_id == target_id:
                continue
            distance = _weighted_distance(self.entities[target_id], embedding, self.weights)
            if distance <= eps:
                results.append((entity_id, distance))
        results.sort(key=lambda item: item[1])
        return results

    def summary(self) -> dict[str, Any]:
        border_regions: dict[str, int] = {}
        admissible = 0
        czvs_distances = []
        for entity_id, metadata in self.metadata.items():
            admissible += int(bool(metadata.get("admissible", True)))
            region = str(metadata.get("border_region", "unlabeled"))
            border_regions[region] = border_regions.get(region, 0) + 1
            if "czvs_distance" in metadata:
                czvs_distances.append(float(metadata["czvs_distance"]))
        nodes = list(self.tree.iter_nodes())
        return {
            "entity_count": len(self.entities),
            "node_count": len(nodes),
            "leaf_count": sum(node.is_leaf for node in nodes),
            "admissibility_rate": admissible / len(self.entities) if self.entities else 0.0,
            "inadmissible_entities": [entity_id for entity_id, metadata in self.metadata.items() if not bool(metadata.get("admissible", True))],
            "border_regions": border_regions,
            "czvs_min": min(czvs_distances) if czvs_distances else None,
            "czvs_mean": float(np.mean(czvs_distances)) if czvs_distances else None,
            "stream": self.stream.snapshot(self.tree.czvs_target, self.weights) if self.stream is not None else None,
            "graph_clusters": self.graph.cluster_summary() if self.graph.edges else [],
        }

    def _node_record(self, node: StructureTreeNode) -> dict[str, Any]:
        return {
            "node_id": node.node_id,
            "depth": node.depth,
            "size": node.size,
            "axis": node.axis,
            "threshold": node.threshold,
            "centroid": node.centroid.tolist() if node.centroid is not None else None,
            "bbox_min": node.bbox_min.tolist() if node.bbox_min is not None else None,
            "bbox_max": node.bbox_max.tolist() if node.bbox_max is not None else None,
            "structural_variance": node.structural_variance,
            "admissible_count": node.admissible_count,
            "inadmissible_count": node.inadmissible_count,
            "admissibility_rate": node.admissibility_rate,
            "border_regions": dict(node.border_regions),
            "dominant_border_region": node.dominant_border_region,
            "czvs_mean": node.czvs_mean,
            "czvs_min": node.czvs_min,
            "czvs_max": node.czvs_max,
            "representative_id": node.representative_id,
            "sbid_partition_score": node.sbid_partition_score,
            "leaf_ids": list(node.ids) if node.is_leaf else [],
            "left_id": node.left.node_id if node.left is not None else None,
            "right_id": node.right.node_id if node.right is not None else None,
            "is_leaf": node.is_leaf,
        }

    def node_summaries(self) -> list[dict[str, Any]]:
        return [self._node_record(node) for node in self.tree.iter_nodes()]

    def prototype_entities(self) -> list[dict[str, Any]]:
        prototypes: list[dict[str, Any]] = []
        seen: set[str] = set()
        for node in self.tree.iter_nodes():
            if node.representative_id is None or node.representative_id in seen:
                continue
            seen.add(node.representative_id)
            prototypes.append(
                {
                    "entity_id": node.representative_id,
                    "depth": node.depth,
                    "node_id": node.node_id,
                    "metadata": dict(self.metadata.get(node.representative_id, {})),
                    "embedding": self.entities[node.representative_id].tolist(),
                }
            )
        return prototypes

    def border_region_summary(self) -> dict[str, Any]:
        summary = self.summary()
        return {
            "border_regions": summary["border_regions"],
            "inadmissible_entities": summary["inadmissible_entities"],
        }

    def czvs_candidates(self, eps: float | None = None, limit: int = 10) -> list[dict[str, Any]]:
        candidates = []
        for entity_id, metadata in self.metadata.items():
            distance = metadata.get("czvs_distance")
            if distance is None:
                continue
            if eps is not None and float(distance) > eps:
                continue
            candidates.append(
                {
                    "entity_id": entity_id,
                    "czvs_distance": float(distance),
                    "metadata": dict(metadata),
                }
            )
        candidates.sort(key=lambda item: item["czvs_distance"])
        return candidates[:limit]

    def trace_summaries(self) -> dict[str, dict[str, Any]]:
        return {
            entity_id: trace.summary(self.tree.czvs_target)
            for entity_id, trace in self.traces.items()
        }

    def viewer_payload(self, query_data: Any | None = None, k: int = 5) -> dict[str, Any]:
        def tree_layout() -> dict[str, tuple[float, float]]:
            if self.tree.root is None:
                return {}
            positions: dict[str, tuple[float, float]] = {}
            counter = {"x": 0.0}

            def walk(node: StructureTreeNode | None) -> float:
                if node is None:
                    return 0.0
                if node.is_leaf:
                    x_coord = counter["x"]
                    counter["x"] += 1.0
                    positions[node.node_id] = (x_coord, -float(node.depth))
                    return x_coord
                left_x = walk(node.left)
                right_x = walk(node.right)
                x_coord = (left_x + right_x) / 2.0
                positions[node.node_id] = (x_coord, -float(node.depth))
                return x_coord

            walk(self.tree.root)
            return positions

        query_payload = None
        if query_data is not None:
            query_payload = self.query_similar_with_context(query_data, k=k)

        layout = tree_layout()
        return {
            "summary": self.summary(),
            "query": query_payload,
            "tree": {
                "root": self.tree.root.node_id if self.tree.root is not None else None,
                "nodes": [
                    {
                        **self._node_record(node),
                        "layout_x": layout.get(node.node_id, (0.0, 0.0))[0],
                        "layout_y": layout.get(node.node_id, (0.0, 0.0))[1],
                    }
                    for node in self.tree.iter_nodes()
                ],
            },
            "entities": [
                {
                    "entity_id": entity_id,
                    "embedding": embedding.tolist(),
                    "x": float(embedding[0]) if len(embedding) > 0 else 0.0,
                    "y": float(embedding[1]) if len(embedding) > 1 else 0.0,
                    "metadata": dict(self.metadata.get(entity_id, {})),
                    "neighbors": self.graph.k_nearest_neighbors(entity_id, k=min(5, max(len(self.entities) - 1, 0))),
                    "trace": self.traces[entity_id].summary(self.tree.czvs_target) if entity_id in self.traces else None,
                }
                for entity_id, embedding in self.entities.items()
            ],
            "graph": {
                "edges": [
                    {"left": left, "right": right, "distance": distance}
                    for (left, right), distance in self.graph.edges.items()
                ],
                "clusters": self.graph.cluster_summary(),
            },
            "prototypes": self.prototype_entities(),
            "czvs_candidates": self.czvs_candidates(limit=k),
            "traces": self.trace_summaries(),
        }
