from . import MariaLibrary, AuditPolicy, build_credit_border


def main() -> None:
    library = MariaLibrary(
        default_policy=AuditPolicy(
            warning_varpi=10.0,
            block_varpi=25.0,
            warning_delta_varpi=10.0,
            block_delta_varpi=25.0,
        )
    )
    border = build_credit_border()
    reference = library.entity(
        border=border,
        tunnel=library.trace_tunnel(["load", "normalize", "score", "approve"]),
        context={"age": 30, "credit_score": 610, "credit_policy": "default"},
    )
    candidate = library.entity(
        border=border,
        tunnel=library.trace_tunnel(["load", "normalize", "shadow-score", "approve"]),
        context={"age": 30, "credit_score": 610, "credit_policy": "default"},
    )
    result = library.audit(candidate, reference)
    print("Maria trace audit:", result)


if __name__ == "__main__":
    main()
