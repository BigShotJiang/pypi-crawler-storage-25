from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .structures import StructIndex
from .viewer import render_struct_index_viewer


@dataclass(slots=True)
class RuntimeImportConfig:
    entity_id_field: str = "entity_id"
    embedding_field: str = "embedding"
    embedding_fields: Sequence[str] | None = None
    metadata_field: str = "metadata"
    timestamp_field: str = "timestamp"
    type_field: str = "type"
    admissible_field: str = "admissible"
    border_region_field: str = "border_region"
    trace_field: str = "trace"
    query_field: str = "query"
    entities_field: str = "entities"
    czvs_target_field: str = "czvs_target"
    include_extra_metadata: bool = True


@dataclass(slots=True)
class RuntimeRecord:
    entity_id: str
    embedding: list[float]
    metadata: dict[str, Any]
    timestamp: Any | None = None
    kind: str = "static"


@dataclass(slots=True)
class RuntimeImportBundle:
    records: list[RuntimeRecord]
    query: list[float] | None = None
    czvs_target: list[float] | None = None
    source_schema: str | None = None


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _normalize_embedding(value: Sequence[Any]) -> list[float]:
    return [float(item) for item in value]


def _infer_embedding(record: Mapping[str, Any], config: RuntimeImportConfig) -> list[float]:
    if config.embedding_field in record:
        value = record[config.embedding_field]
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
            raise ValueError(f"Embedding field '{config.embedding_field}' must be a numeric sequence")
        return _normalize_embedding(value)

    if config.embedding_fields:
        return [float(record[field]) for field in config.embedding_fields]

    reserved = {
        config.entity_id_field,
        config.metadata_field,
        config.timestamp_field,
        config.type_field,
        config.trace_field,
        config.query_field,
        config.entities_field,
        config.czvs_target_field,
    }
    embedding = [float(value) for key, value in record.items() if key not in reserved and _is_number(value)]
    if not embedding:
        raise ValueError(
            "Could not infer embedding. Provide an 'embedding' field or configure explicit embedding_fields."
        )
    return embedding


def _extract_metadata(record: Mapping[str, Any], config: RuntimeImportConfig) -> dict[str, Any]:
    metadata = dict(record.get(config.metadata_field, {}))
    for field in (config.admissible_field, config.border_region_field):
        if field in record:
            metadata[field] = record[field]
    if config.include_extra_metadata:
        reserved = {
            config.entity_id_field,
            config.embedding_field,
            config.metadata_field,
            config.timestamp_field,
            config.type_field,
            config.trace_field,
            config.query_field,
            config.entities_field,
            config.czvs_target_field,
        }
        if config.embedding_fields:
            reserved.update(config.embedding_fields)
        for key, value in record.items():
            if key not in reserved:
                metadata.setdefault(key, value)
    return metadata


def _record_from_mapping(record: Mapping[str, Any], config: RuntimeImportConfig) -> RuntimeRecord:
    if config.entity_id_field not in record:
        raise ValueError(f"Missing required id field '{config.entity_id_field}'")
    return RuntimeRecord(
        entity_id=str(record[config.entity_id_field]),
        embedding=_infer_embedding(record, config),
        metadata=_extract_metadata(record, config),
        timestamp=record.get(config.timestamp_field),
        kind=str(record.get(config.type_field, "dynamic" if config.timestamp_field in record else "static")),
    )


def runtime_bundle_from_payload(payload: Mapping[str, Any], config: RuntimeImportConfig | None = None) -> RuntimeImportBundle:
    resolved = config or RuntimeImportConfig()
    schema = payload.get("schema")
    records_payload = payload.get(resolved.entities_field)
    if not isinstance(records_payload, Sequence):
        raise ValueError(f"Payload must contain a sequence field '{resolved.entities_field}'")
    records = [_record_from_mapping(record, resolved) for record in records_payload]
    query = payload.get(resolved.query_field)
    czvs_target = payload.get(resolved.czvs_target_field)
    return RuntimeImportBundle(
        records=records,
        query=_normalize_embedding(query) if isinstance(query, Sequence) and not isinstance(query, (str, bytes, bytearray)) else None,
        czvs_target=_normalize_embedding(czvs_target) if isinstance(czvs_target, Sequence) and not isinstance(czvs_target, (str, bytes, bytearray)) else None,
        source_schema=str(schema) if schema is not None else None,
    )


def runtime_bundle_from_jsonl(text: str, config: RuntimeImportConfig | None = None) -> RuntimeImportBundle:
    resolved = config or RuntimeImportConfig()
    records: list[RuntimeRecord] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped:
            continue
        payload = json.loads(stripped)
        if not isinstance(payload, Mapping):
            raise ValueError(f"JSONL line {line_no} must decode to an object")
        records.append(_record_from_mapping(payload, resolved))
    return RuntimeImportBundle(records=records)


def runtime_bundle_from_path(path: str | Path, config: RuntimeImportConfig | None = None) -> RuntimeImportBundle:
    source = Path(path)
    text = source.read_text(encoding="utf-8")
    if source.suffix.lower() == ".jsonl":
        return runtime_bundle_from_jsonl(text, config=config)
    payload = json.loads(text)
    if isinstance(payload, Mapping):
        if "schema" in payload or (config or RuntimeImportConfig()).entities_field in payload:
            return runtime_bundle_from_payload(payload, config=config)
        return RuntimeImportBundle(records=[_record_from_mapping(payload, config or RuntimeImportConfig())])
    if isinstance(payload, Sequence):
        records = [_record_from_mapping(item, config or RuntimeImportConfig()) for item in payload]
        return RuntimeImportBundle(records=records)
    raise ValueError("Unsupported runtime input format")


def struct_index_from_runtime_records(
    records: Iterable[RuntimeRecord],
    *,
    weights: Sequence[float] | None = None,
    tree_leaf_size: int = 8,
    graph_threshold: float | None = None,
    czvs_target: Sequence[float] | None = None,
) -> StructIndex:
    index = StructIndex(
        weights=weights,
        tree_leaf_size=tree_leaf_size,
        graph_threshold=graph_threshold,
        czvs_target=czvs_target,
    )
    for record in records:
        index.add_entity(
            record.entity_id,
            record.embedding,
            metadata=record.metadata,
            type=record.kind,
            timestamp=record.timestamp,
        )
    index.refresh_graph()
    return index


def struct_index_from_runtime_bundle(
    bundle: RuntimeImportBundle,
    *,
    weights: Sequence[float] | None = None,
    tree_leaf_size: int = 8,
    graph_threshold: float | None = None,
    czvs_target: Sequence[float] | None = None,
) -> StructIndex:
    effective_czvs_target = czvs_target if czvs_target is not None else bundle.czvs_target
    return struct_index_from_runtime_records(
        bundle.records,
        weights=weights,
        tree_leaf_size=tree_leaf_size,
        graph_threshold=graph_threshold,
        czvs_target=effective_czvs_target,
    )


def struct_index_from_runtime_path(
    path: str | Path,
    *,
    config: RuntimeImportConfig | None = None,
    weights: Sequence[float] | None = None,
    tree_leaf_size: int = 8,
    graph_threshold: float | None = None,
    czvs_target: Sequence[float] | None = None,
) -> tuple[StructIndex, RuntimeImportBundle]:
    bundle = runtime_bundle_from_path(path, config=config)
    index = struct_index_from_runtime_bundle(
        bundle,
        weights=weights,
        tree_leaf_size=tree_leaf_size,
        graph_threshold=graph_threshold,
        czvs_target=czvs_target,
    )
    return index, bundle


def render_runtime_viewer_from_path(
    input_path: str | Path,
    output_path: str | Path,
    *,
    config: RuntimeImportConfig | None = None,
    weights: Sequence[float] | None = None,
    tree_leaf_size: int = 8,
    graph_threshold: float | None = None,
    czvs_target: Sequence[float] | None = None,
    query: Sequence[float] | None = None,
    k: int = 5,
    title: str = "Maria Runtime Viewer",
) -> str:
    index, bundle = struct_index_from_runtime_path(
        input_path,
        config=config,
        weights=weights,
        tree_leaf_size=tree_leaf_size,
        graph_threshold=graph_threshold,
        czvs_target=czvs_target,
    )
    query_vector = list(query) if query is not None else bundle.query
    return render_struct_index_viewer(index, output_path, query_data=query_vector, k=k, title=title)


def runtime_template() -> dict[str, Any]:
    return {
        "schema": "maria-runtime-index",
        "version": "1.0",
        "czvs_target": [0.0, 0.0, 0.0],
        "query": [0.15, 0.05, 0.2],
        "entities": [
            {
                "entity_id": "compiler-pass-1",
                "embedding": [0.12, 0.04, 0.19],
                "timestamp": 0,
                "type": "dynamic",
                "admissible": True,
                "border_region": "core",
                "metadata": {
                    "phase": "parse",
                    "runtime": "internal",
                    "compiler": "maria-demo",
                },
            },
            {
                "entity_id": "compiler-pass-1",
                "embedding": [0.18, 0.06, 0.27],
                "timestamp": 1,
                "type": "dynamic",
                "admissible": True,
                "border_region": "watch",
                "metadata": {
                    "phase": "optimize",
                    "runtime": "internal",
                    "compiler": "maria-demo",
                },
            },
            {
                "entity_id": "runtime-node-7",
                "embedding": [0.82, 0.74, 0.68],
                "admissible": False,
                "border_region": "warning",
                "metadata": {
                    "phase": "execute",
                    "runtime": "external",
                    "compiler": "target-x",
                },
            },
        ],
    }


def parse_vector(text: str | None) -> list[float] | None:
    if text is None:
        return None
    parts = [item.strip() for item in text.split(",") if item.strip()]
    return [float(item) for item in parts]


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build a Piance-aware StructIndex viewer from runtime/compiler output.")
    parser.add_argument("input", nargs="?", help="Path to a JSON or JSONL runtime export.")
    parser.add_argument("--output", default="examples/plots/runtime_viewer.html", help="Output HTML path for the viewer.")
    parser.add_argument("--embedding-fields", help="Comma-separated numeric fields to use as the embedding when no embedding vector is present.")
    parser.add_argument("--czvs-target", help="Comma-separated CZVS target vector.")
    parser.add_argument("--query", help="Comma-separated query vector for neighborhood inspection.")
    parser.add_argument("--graph-threshold", type=float, default=None, help="Optional graph threshold.")
    parser.add_argument("--tree-leaf-size", type=int, default=8, help="StructureTree leaf size.")
    parser.add_argument("--title", default="Maria Runtime Viewer", help="Viewer title.")
    parser.add_argument("--write-template", help="Write a starter JSON template to the given path and exit.")
    args = parser.parse_args(list(argv) if argv is not None else None)

    if args.write_template:
        target = Path(args.write_template)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(runtime_template(), indent=2), encoding="utf-8")
        print(target)
        return 0

    if not args.input:
        parser.error("input is required unless --write-template is used")

    config = RuntimeImportConfig(
        embedding_fields=[field.strip() for field in args.embedding_fields.split(",") if field.strip()]
        if args.embedding_fields
        else None
    )
    output = render_runtime_viewer_from_path(
        args.input,
        args.output,
        config=config,
        tree_leaf_size=args.tree_leaf_size,
        graph_threshold=args.graph_threshold,
        czvs_target=parse_vector(args.czvs_target),
        query=parse_vector(args.query),
        title=args.title,
    )
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
