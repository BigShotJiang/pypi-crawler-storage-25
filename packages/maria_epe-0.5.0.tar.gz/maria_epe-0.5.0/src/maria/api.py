from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Mapping, Sequence

from epe_framework import (
    AuditPolicy,
    AuditResult,
    Border,
    EelStructuredEntity,
    Tunnel,
    audit_against,
    graph_tunnel as _graph_tunnel,
    tensor_tunnel as _tensor_tunnel,
    trace_tunnel as _trace_tunnel,
)
from .julia_bridge import JuliaBridge
from .structures import BasisProjector, StreamBuffer, StructGraph, StructIndex, StructureTree, TimeTrace
from .viewer import render_struct_index_viewer

if TYPE_CHECKING:
    from .runtime import RuntimeImportBundle, RuntimeImportConfig


def entity(border: Border | None = None, tunnel: Tunnel | None = None, context: Mapping[str, Any] | None = None) -> EelStructuredEntity:
    if tunnel is None:
        raise ValueError("tunnel is required")
    return EelStructuredEntity(border=border or Border(), tunnel=tunnel, context=dict(context or {}))


def graph_tunnel(
    edges: Sequence[tuple[Any, Any]],
    *,
    nodes: Sequence[Any] = (),
    directed: bool = False,
    metadata: Mapping[str, Any] | None = None,
) -> Tunnel:
    return _graph_tunnel(edges, nodes=nodes, directed=directed, metadata=metadata)


def tensor_tunnel(values: Any, *, shape: Sequence[int] | None = None, metadata: Mapping[str, Any] | None = None) -> Tunnel:
    return _tensor_tunnel(values, shape=shape, metadata=metadata)


def trace_tunnel(states: Sequence[Any], *, metadata: Mapping[str, Any] | None = None) -> Tunnel:
    return _trace_tunnel(states, metadata=metadata)


@dataclass(slots=True)
class MariaLibrary:
    default_policy: AuditPolicy | None = None
    julia: JuliaBridge = field(default_factory=JuliaBridge)

    def entity(
        self,
        *,
        border: Border | None = None,
        tunnel: Tunnel | None = None,
        context: Mapping[str, Any] | None = None,
    ) -> EelStructuredEntity:
        return entity(border=border, tunnel=tunnel, context=context)

    def graph_tunnel(
        self,
        edges: Sequence[tuple[Any, Any]],
        *,
        nodes: Sequence[Any] = (),
        directed: bool = False,
        metadata: Mapping[str, Any] | None = None,
    ) -> Tunnel:
        return graph_tunnel(edges, nodes=nodes, directed=directed, metadata=metadata)

    def tensor_tunnel(
        self,
        values: Any,
        *,
        shape: Sequence[int] | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> Tunnel:
        return tensor_tunnel(values, shape=shape, metadata=metadata)

    def trace_tunnel(self, states: Sequence[Any], *, metadata: Mapping[str, Any] | None = None) -> Tunnel:
        return trace_tunnel(states, metadata=metadata)

    def structure_tree(
        self,
        *,
        leaf_size: int = 8,
        weights: Sequence[float] | None = None,
        czvs_target: Sequence[float] | None = None,
    ) -> StructureTree:
        return StructureTree(leaf_size=leaf_size, weights=weights, czvs_target=czvs_target)

    def stream_buffer(self, *, dim: int, decay: float = 0.95) -> StreamBuffer:
        return StreamBuffer(dim=dim, decay=decay)

    def basis_projector(
        self,
        *,
        input_dim: int,
        basis_size: int,
        basis_type: str = "fourier",
        seed: int = 7,
    ) -> BasisProjector:
        return BasisProjector(input_dim=input_dim, basis_size=basis_size, basis_type=basis_type, seed=seed)

    def struct_graph(self, *, weights: Sequence[float] | None = None) -> StructGraph:
        return StructGraph(weights=weights)

    def time_trace(self, *, weights: Sequence[float] | None = None) -> TimeTrace:
        return TimeTrace(weights=weights)

    def struct_index(
        self,
        *,
        weights: Sequence[float] | None = None,
        tree_leaf_size: int = 8,
        graph_threshold: float | None = None,
        czvs_target: Sequence[float] | None = None,
        projector: BasisProjector | None = None,
    ) -> StructIndex:
        return StructIndex(
            weights=weights,
            tree_leaf_size=tree_leaf_size,
            graph_threshold=graph_threshold,
            czvs_target=czvs_target,
            projector=projector,
        )

    def render_struct_index_viewer(
        self,
        index: StructIndex,
        output_path: str,
        *,
        query_data: Any | None = None,
        k: int = 5,
        title: str = "Maria StructIndex Viewer",
    ) -> str:
        return render_struct_index_viewer(index, output_path, query_data=query_data, k=k, title=title)

    def struct_index_from_runtime_path(
        self,
        path: str,
        *,
        config: RuntimeImportConfig | None = None,
        weights: Sequence[float] | None = None,
        tree_leaf_size: int = 8,
        graph_threshold: float | None = None,
        czvs_target: Sequence[float] | None = None,
    ) -> tuple[StructIndex, RuntimeImportBundle]:
        from .runtime import struct_index_from_runtime_path

        return struct_index_from_runtime_path(
            path,
            config=config,
            weights=weights,
            tree_leaf_size=tree_leaf_size,
            graph_threshold=graph_threshold,
            czvs_target=czvs_target,
        )

    def struct_index_from_runtime_bundle(
        self,
        bundle: RuntimeImportBundle,
        *,
        weights: Sequence[float] | None = None,
        tree_leaf_size: int = 8,
        graph_threshold: float | None = None,
        czvs_target: Sequence[float] | None = None,
    ) -> StructIndex:
        from .runtime import struct_index_from_runtime_bundle

        return struct_index_from_runtime_bundle(
            bundle,
            weights=weights,
            tree_leaf_size=tree_leaf_size,
            graph_threshold=graph_threshold,
            czvs_target=czvs_target,
        )

    def render_runtime_viewer_from_path(
        self,
        input_path: str,
        output_path: str,
        *,
        config: RuntimeImportConfig | None = None,
        weights: Sequence[float] | None = None,
        tree_leaf_size: int = 8,
        graph_threshold: float | None = None,
        czvs_target: Sequence[float] | None = None,
        query: Sequence[float] | None = None,
        k: int = 5,
        title: str = "Maria Runtime Viewer",
    ) -> str:
        from .runtime import render_runtime_viewer_from_path

        return render_runtime_viewer_from_path(
            input_path,
            output_path,
            config=config,
            weights=weights,
            tree_leaf_size=tree_leaf_size,
            graph_threshold=graph_threshold,
            czvs_target=czvs_target,
            query=query,
            k=k,
            title=title,
        )

    def audit(
        self,
        candidate: EelStructuredEntity,
        reference: EelStructuredEntity,
        *,
        policy: AuditPolicy | None = None,
        alpha: float = 1.0,
        beta: float = 1.0,
        p: int = 2,
    ) -> AuditResult:
        resolved_policy = policy or self.default_policy
        if resolved_policy is None:
            raise ValueError("policy is required when no default_policy is configured")
        return audit_against(candidate, reference, resolved_policy, alpha=alpha, beta=beta, p=p)
