from __future__ import annotations

from dataclasses import dataclass, field
from math import exp
from typing import Any, Callable, Hashable, Iterable, Mapping, Sequence


Vector = list[float]


def _pad_right(left: Sequence[float], right: Sequence[float]) -> tuple[Vector, Vector]:
    size = max(len(left), len(right))
    a = list(left) + [0.0] * (size - len(left))
    b = list(right) + [0.0] * (size - len(right))
    return a, b


def _safe_mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _adjacent_differences(values: Sequence[float]) -> Vector:
    if len(values) < 2:
        return [0.0]
    return [float(values[index + 1] - values[index]) for index in range(len(values) - 1)]


def _top_values(values: Sequence[float], limit: int = 5) -> Vector:
    top = list(values[:limit])
    if len(top) < limit:
        top.extend([0.0] * (limit - len(top)))
    return top


def _flatten_tensor(values: Any) -> Vector:
    if isinstance(values, (int, float)):
        return [float(values)]
    flattened: Vector = []
    for item in values:
        flattened.extend(_flatten_tensor(item))
    return flattened


def _infer_tensor_shape(values: Any) -> tuple[int, ...]:
    if isinstance(values, (int, float)):
        return ()
    values = list(values)
    if not values:
        return (0,)
    return (len(values),) + _infer_tensor_shape(values[0])


def _token_value(token: Any) -> float:
    if isinstance(token, (int, float)):
        return float(token)
    text = repr(token)
    if not text:
        return 0.0
    return float(sum(ord(char) for char in text) / len(text))


def lp_distance(left: Sequence[float], right: Sequence[float], p: int = 2) -> float:
    if p <= 0:
        raise ValueError("p must be positive")
    a, b = _pad_right(left, right)
    if p == 1:
        return sum(abs(x - y) for x, y in zip(a, b))
    return sum(abs(x - y) ** p for x, y in zip(a, b)) ** (1.0 / p)


class StructuralModel:
    kind = "generic"

    def signature(self) -> Vector:
        raise NotImplementedError

    def derivative_signature(self) -> Vector:
        raise NotImplementedError


@dataclass(slots=True)
class PolynomialModel(StructuralModel):
    coefficients: Sequence[float]
    kind = "polynomial"

    def signature(self) -> Vector:
        return list(float(x) for x in self.coefficients)

    def derivative_signature(self) -> Vector:
        coeffs = list(float(x) for x in self.coefficients)
        if len(coeffs) <= 1:
            return [0.0]
        return [power * coeffs[power] for power in range(1, len(coeffs))]


@dataclass(slots=True)
class ExponentialModel(StructuralModel):
    scale: float
    rate: float
    kind = "exponential"

    def signature(self) -> Vector:
        return [float(self.scale), float(self.rate)]

    def derivative_signature(self) -> Vector:
        return [float(self.scale * self.rate), float(self.rate)]


@dataclass(slots=True)
class LogisticModel(StructuralModel):
    L: float
    k: float
    x0: float
    kind = "logistic"

    def signature(self) -> Vector:
        return [float(self.L), float(self.k), float(self.x0)]

    def derivative_signature(self) -> Vector:
        return [float(self.L), float(self.k), float(self.x0), float(self.L * self.k / 4.0)]

    def predict(self, x: float) -> float:
        return self.L / (1.0 + exp(-self.k * (x - self.x0)))


@dataclass(slots=True)
class GraphModel(StructuralModel):
    edges: Sequence[tuple[Hashable, Hashable]]
    nodes: Sequence[Hashable] = field(default_factory=tuple)
    directed: bool = False
    kind = "graph"

    def _node_list(self) -> list[Hashable]:
        seen: dict[Hashable, None] = {}
        for node in self.nodes:
            seen[node] = None
        for left, right in self.edges:
            seen[left] = None
            seen[right] = None
        return list(seen.keys())

    def _adjacency(self) -> dict[Hashable, set[Hashable]]:
        adjacency = {node: set() for node in self._node_list()}
        for left, right in self.edges:
            adjacency.setdefault(left, set()).add(right)
            adjacency.setdefault(right, set())
            if not self.directed:
                adjacency.setdefault(right, set()).add(left)
            else:
                adjacency[right] = adjacency.get(right, set())
        return adjacency

    def _degree_sequence(self) -> list[float]:
        adjacency = self._adjacency()
        degrees = [float(len(neighbors)) for neighbors in adjacency.values()]
        return sorted(degrees, reverse=True)

    def _component_count(self) -> int:
        adjacency = self._adjacency()
        remaining = set(adjacency.keys())
        components = 0
        while remaining:
            components += 1
            stack = [remaining.pop()]
            while stack:
                node = stack.pop()
                for neighbor in adjacency.get(node, set()):
                    if neighbor in remaining:
                        remaining.remove(neighbor)
                        stack.append(neighbor)
        return components

    def signature(self) -> Vector:
        nodes = self._node_list()
        node_count = float(len(nodes))
        edge_count = float(len(self.edges))
        degrees = self._degree_sequence()
        average_degree = _safe_mean(degrees)
        max_degree = max(degrees, default=0.0)
        density_denominator = node_count * max(node_count - 1.0, 1.0)
        if not self.directed:
            density_denominator /= 2.0
        density = edge_count / density_denominator if density_denominator else 0.0
        return [
            node_count,
            edge_count,
            density,
            average_degree,
            max_degree,
            float(self._component_count()),
            1.0 if self.directed else 0.0,
            *_top_values(degrees),
        ]

    def derivative_signature(self) -> Vector:
        degrees = self._degree_sequence()
        differences = [abs(value) for value in _adjacent_differences(degrees)]
        return [
            _safe_mean(differences),
            max(differences, default=0.0),
            float(len(differences)),
            *_top_values(differences),
        ]


@dataclass(slots=True)
class TensorModel(StructuralModel):
    values: Any
    shape: Sequence[int] | None = None
    kind = "tensor"

    def resolved_shape(self) -> tuple[int, ...]:
        if self.shape is not None:
            return tuple(int(value) for value in self.shape)
        return _infer_tensor_shape(self.values)

    def flattened(self) -> Vector:
        return _flatten_tensor(self.values)

    def signature(self) -> Vector:
        flattened = self.flattened()
        shape = [float(value) for value in self.resolved_shape()]
        absolute = [abs(value) for value in flattened]
        l2 = sum(value * value for value in flattened) ** 0.5
        return [
            *shape,
            float(len(flattened)),
            _safe_mean(flattened),
            sum(absolute),
            l2,
            max(absolute, default=0.0),
            min(flattened, default=0.0),
            max(flattened, default=0.0),
        ]

    def derivative_signature(self) -> Vector:
        flattened = self.flattened()
        differences = [abs(value) for value in _adjacent_differences(flattened)]
        return [
            *[float(value) for value in self.resolved_shape()],
            _safe_mean(differences),
            max(differences, default=0.0),
            sum(differences),
            float(len(differences)),
        ]


@dataclass(slots=True)
class TraceModel(StructuralModel):
    states: Sequence[Any]
    kind = "trace"

    def _encoded(self) -> Vector:
        return [_token_value(state) for state in self.states]

    def signature(self) -> Vector:
        encoded = self._encoded()
        transitions = [abs(value) for value in _adjacent_differences(encoded)]
        unique_states = float(len({repr(state) for state in self.states}))
        revisits = float(max(len(self.states) - int(unique_states), 0))
        return [
            float(len(self.states)),
            unique_states,
            revisits,
            _safe_mean(encoded),
            _safe_mean(transitions),
            max(transitions, default=0.0),
            *_top_values(transitions),
        ]

    def derivative_signature(self) -> Vector:
        encoded = self._encoded()
        differences = [abs(value) for value in _adjacent_differences(encoded)]
        return [
            float(len(differences)),
            _safe_mean(differences),
            max(differences, default=0.0),
            sum(differences),
            *_top_values(differences),
        ]


def structural_divergence(candidate: StructuralModel, reference: StructuralModel, p: int = 2) -> float:
    return lp_distance(candidate.signature(), reference.signature(), p=p)


def rate_divergence(candidate: StructuralModel, reference: StructuralModel, p: int = 2) -> float:
    return lp_distance(candidate.derivative_signature(), reference.derivative_signature(), p=p)


def fused_metric(
    candidate: StructuralModel,
    reference: StructuralModel,
    alpha: float = 1.0,
    beta: float = 1.0,
    p: int = 2,
) -> float:
    return alpha * structural_divergence(candidate, reference, p=p) + beta * rate_divergence(
        candidate, reference, p=p
    )


ConstraintValidator = Callable[[StructuralModel, Mapping[str, Any]], bool]
DriftRule = Callable[[Any], Any]


@dataclass(slots=True)
class Constraint:
    name: str
    validator: ConstraintValidator
    rigid: bool = True
    drift_rule: DriftRule | None = None
    descriptor: dict[str, Any] | None = None

    def evaluate(self, model: StructuralModel, context: Mapping[str, Any]) -> bool:
        return bool(self.validator(model, context))

    def drift(self, context_value: Any) -> "Constraint":
        if self.rigid or self.drift_rule is None:
            return self

        drifted_validator = self.drift_rule(context_value)
        if not callable(drifted_validator):
            raise TypeError("drift_rule must return a callable validator")

        return Constraint(
            name=self.name,
            validator=drifted_validator,
            rigid=False,
            drift_rule=self.drift_rule,
            descriptor=self.descriptor,
        )


@dataclass(slots=True)
class Border:
    constraints: list[Constraint] = field(default_factory=list)

    def rigid_constraints(self) -> list[Constraint]:
        return [constraint for constraint in self.constraints if constraint.rigid]

    def flexible_constraints(self) -> list[Constraint]:
        return [constraint for constraint in self.constraints if not constraint.rigid]

    def apply_drift(self, context: Mapping[str, Any]) -> "Border":
        drifted: list[Constraint] = []
        for constraint in self.constraints:
            if constraint.rigid:
                drifted.append(constraint)
                continue
            context_value = context.get(constraint.name)
            drifted.append(constraint.drift(context_value))
        return Border(constraints=drifted)


@dataclass(slots=True)
class Tunnel:
    model: StructuralModel
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def kind(self) -> str:
        return getattr(self.model, "kind", "generic")


def graph_tunnel(
    edges: Sequence[tuple[Hashable, Hashable]],
    *,
    nodes: Sequence[Hashable] = (),
    directed: bool = False,
    metadata: Mapping[str, Any] | None = None,
) -> Tunnel:
    return Tunnel(model=GraphModel(edges=edges, nodes=nodes, directed=directed), metadata=dict(metadata or {}))


def tensor_tunnel(values: Any, *, shape: Sequence[int] | None = None, metadata: Mapping[str, Any] | None = None) -> Tunnel:
    return Tunnel(model=TensorModel(values=values, shape=shape), metadata=dict(metadata or {}))


def trace_tunnel(states: Sequence[Any], *, metadata: Mapping[str, Any] | None = None) -> Tunnel:
    return Tunnel(model=TraceModel(states=states), metadata=dict(metadata or {}))


@dataclass(slots=True)
class EelStructuredEntity:
    border: Border
    tunnel: Tunnel
    context: dict[str, Any] = field(default_factory=dict)

    def admissibility_report(self) -> dict[str, bool]:
        report: dict[str, bool] = {}
        for constraint in self.border.constraints:
            report[constraint.name] = constraint.evaluate(self.tunnel.model, self.context)
        return report

    def is_admissible(self) -> bool:
        return all(self.admissibility_report().values())

    def rigid_violations(self) -> list[str]:
        violations: list[str] = []
        for constraint in self.border.rigid_constraints():
            if not constraint.evaluate(self.tunnel.model, self.context):
                violations.append(constraint.name)
        return violations

    def with_drifted_border(self, context: Mapping[str, Any]) -> "EelStructuredEntity":
        return EelStructuredEntity(
            border=self.border.apply_drift(context),
            tunnel=self.tunnel,
            context=dict(context),
        )


@dataclass(slots=True)
class AuditPolicy:
    warning_varpi: float
    block_varpi: float
    warning_delta_varpi: float
    block_delta_varpi: float

    def decide(self, varpi: float, delta_varpi: float, admissible: bool, rigid_violations: Sequence[str]) -> str:
        if rigid_violations or not admissible:
            return "BLOCK"
        if varpi >= self.block_varpi or delta_varpi >= self.block_delta_varpi:
            return "BLOCK"
        if varpi >= self.warning_varpi or delta_varpi >= self.warning_delta_varpi:
            return "REVIEW"
        return "APPROVE"


@dataclass(slots=True)
class AuditResult:
    decision: str
    structural_divergence: float
    rate_divergence: float
    fused_metric: float
    admissible: bool
    rigid_violations: list[str]
    report: dict[str, bool]


def audit_against(
    candidate: EelStructuredEntity,
    reference: EelStructuredEntity,
    policy: AuditPolicy,
    alpha: float = 1.0,
    beta: float = 1.0,
    p: int = 2,
) -> AuditResult:
    varpi = structural_divergence(candidate.tunnel.model, reference.tunnel.model, p=p)
    delta = rate_divergence(candidate.tunnel.model, reference.tunnel.model, p=p)
    fused = alpha * varpi + beta * delta
    report = candidate.admissibility_report()
    admissible = all(report.values())
    rigid_violations = candidate.rigid_violations()
    decision = policy.decide(varpi, delta, admissible, rigid_violations)
    return AuditResult(
        decision=decision,
        structural_divergence=varpi,
        rate_divergence=delta,
        fused_metric=fused,
        admissible=admissible,
        rigid_violations=rigid_violations,
        report=report,
    )


def context_min_validator(context_key: str, min_value: float) -> ConstraintValidator:
    def validator(model: StructuralModel, context: Mapping[str, Any]) -> bool:
        observed_value = context.get(context_key)
        if observed_value is None:
            return True
        return float(observed_value) >= float(min_value)

    return validator


def credit_score_min_validator(min_score: float) -> ConstraintValidator:
    return context_min_validator("credit_score", min_score)


def age_min_validator(min_age: float) -> ConstraintValidator:
    return context_min_validator("age", min_age)


def flexible_credit_score_rule(default_min: float, relaxed_min: float) -> DriftRule:
    def drift(context_value: Any) -> ConstraintValidator:
        min_score = relaxed_min if context_value == "relaxed" else default_min
        return credit_score_min_validator(min_score)

    return drift


def build_credit_border(default_score_min: float = 600.0) -> Border:
    return Border(
        constraints=[
            Constraint(
                name="age_gate",
                validator=age_min_validator(18.0),
                rigid=True,
                descriptor={"kind": "context_min", "context_key": "age", "min_value": 18.0},
            ),
            Constraint(
                name="credit_policy",
                validator=credit_score_min_validator(default_score_min),
                rigid=False,
                drift_rule=flexible_credit_score_rule(default_score_min, 580.0),
                descriptor={
                    "kind": "context_min",
                    "context_key": "credit_score",
                    "min_value": default_score_min,
                    "drift": {
                        "kind": "context_switch_min",
                        "context_key": "credit_policy",
                        "target_key": "credit_score",
                        "default": default_score_min,
                        "cases": {"relaxed": 580.0},
                    },
                },
            ),
        ]
    )


def polynomial_example() -> AuditResult:
    reference = EelStructuredEntity(
        border=Border(),
        tunnel=Tunnel(model=PolynomialModel([1, 2, 0, 1])),
    )
    candidate = EelStructuredEntity(
        border=Border(),
        tunnel=Tunnel(model=PolynomialModel([1, -1, 0, 1])),
    )
    policy = AuditPolicy(
        warning_varpi=2.0,
        block_varpi=5.0,
        warning_delta_varpi=2.0,
        block_delta_varpi=5.0,
    )
    return audit_against(candidate, reference, policy)


def credit_review_example() -> AuditResult:
    border = build_credit_border()
    reference = EelStructuredEntity(
        border=border,
        tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.03, x0=620.0)),
        context={"age": 30, "credit_score": 610, "credit_policy": "default"},
    )
    candidate = EelStructuredEntity(
        border=border,
        tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.04, x0=605.0)),
        context={"age": 30, "credit_score": 610, "credit_policy": "default"},
    )
    policy = AuditPolicy(
        warning_varpi=10.0,
        block_varpi=25.0,
        warning_delta_varpi=10.0,
        block_delta_varpi=25.0,
    )
    return audit_against(candidate, reference, policy)


def credit_block_example() -> AuditResult:
    border = build_credit_border()
    reference = EelStructuredEntity(
        border=border,
        tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.03, x0=620.0)),
        context={"age": 30, "credit_score": 610, "credit_policy": "default"},
    )
    candidate = EelStructuredEntity(
        border=border,
        tunnel=Tunnel(model=LogisticModel(L=1.0, k=0.04, x0=605.0)),
        context={"age": 30, "credit_score": 590, "credit_policy": "default"},
    )
    policy = AuditPolicy(
        warning_varpi=10.0,
        block_varpi=25.0,
        warning_delta_varpi=10.0,
        block_delta_varpi=25.0,
    )
    return audit_against(candidate, reference, policy)


if __name__ == "__main__":
    print("Polynomial example:", polynomial_example())
    print("Credit review example:", credit_review_example())
    print("Credit block example:", credit_block_example())
