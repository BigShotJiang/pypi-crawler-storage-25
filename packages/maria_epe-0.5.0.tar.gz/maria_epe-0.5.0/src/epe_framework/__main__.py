from .core import credit_block_example, credit_review_example, polynomial_example


def main() -> None:
    print("Polynomial example:", polynomial_example())
    print("Credit review example:", credit_review_example())
    print("Credit block example:", credit_block_example())


if __name__ == "__main__":
    main()

