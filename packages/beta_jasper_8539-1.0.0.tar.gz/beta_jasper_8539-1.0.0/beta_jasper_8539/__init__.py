"""The Quartz Query Path"""
__version__ = "1.0.0"
