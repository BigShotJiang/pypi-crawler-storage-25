"""
时序预测处理模块

负责时序预测任务的全部专有逻辑：
- ForecastModelWrapper: MLflow pyfunc 模型包装器
- 数据预处理：频率推断、缺失时间点填充
- 预测结果保存到 DLC 表
- 时序预测模型的 MLflow 记录
"""
import logging
from typing import List, Optional

import mlflow
import numpy as np
import pandas as pd

from wedata_automl.utils.print_utils import safe_print, print_separator

logger = logging.getLogger(__name__)


# ============================================================================
# 频率映射基础设施
# ============================================================================

# 统一的频率映射表：用户友好名 + 旧别名 → pandas 2.x 标准 freq
# 同时完成两个映射：① 用户友好名→pandas freq；② 旧别名→新别名（消除 FutureWarning）
FREQ_MAP: dict[str, str] = {
    "D": "D", "days": "D", "day": "D",
    "W": "W", "weeks": "W", "week": "W",
    "M": "ME", "month": "ME", "months": "ME",
    "Q": "QE", "quarter": "QE", "quarters": "QE",
    "Y": "YE", "year": "YE", "years": "YE",
    "H": "h", "hours": "h", "hour": "h", "hr": "h", "h": "h",
    "T": "min", "min": "min", "minute": "min", "minutes": "min", "m": "min",
    "S": "s", "sec": "s", "second": "s", "seconds": "s",
}


def resolve_frequency(frequency: str) -> str:
    """
    将用户友好名或旧别名映射为 pandas 2.x 标准 freq 字符串

    映射规则：
    - 用户友好名（"M", "month", "months" 等）→ pandas 标准 freq（"MS"）
    - 旧别名（"H", "T", "S" 等）→ 新别名（"h", "min", "s"）
    - 已标准化的 freq → 原样返回（幂等）
    - 未识别的自定义 freq → 原样透传（由 pandas to_offset 兜底）

    Args:
        frequency: 频率字符串

    Returns:
        pandas 2.x 标准 freq 字符串
    """
    return FREQ_MAP.get(frequency, frequency)


def frequency_to_offset(frequency: str) -> pd.DateOffset:
    """
    将频率字符串转换为 pandas DateOffset 对象

    解决 pd.Timedelta(1, unit=...) 无法处理月/季/年（非固定长度）的问题，
    改用 pd.tseries.frequencies.to_offset() 返回正确的 DateOffset。

    Args:
        frequency: 频率字符串（可以是用户友好名或 pandas 标准 freq）

    Returns:
        对应的 pandas DateOffset 对象
    """
    resolved = resolve_frequency(frequency)
    return pd.tseries.frequencies.to_offset(resolved)


# ============================================================================
# Forecast 模型 MLflow PythonModel 包装器
# ============================================================================

class ForecastModelWrapper(mlflow.pyfunc.PythonModel):
    """
    时序预测模型的 MLflow PythonModel 包装器

    将 FLAML 训练的时序预测模型包装为标准的 MLflow pyfunc 模型，
    支持通过 mlflow.pyfunc.load_model() 加载和预测。

    Attributes:
        model: FLAML 训练的时序预测模型（或 Pipeline）
        horizon: 预测时间范围
        frequency: 时间频率（D/W/M/H 等）
        time_col: 时间列名
        target_col: 目标列名
        estimator: 最佳估计器名称

    Example:
        >>> # 加载模型
        >>> model = mlflow.pyfunc.load_model("runs:/xxx/model")
        >>> # 预测
        >>> future_dates = pd.DataFrame({"ds": pd.date_range("2024-01-01", periods=6, freq="D")})
        >>> predictions = model.predict(future_dates)
    """

    def __init__(
        self,
        model=None,
        horizon: int = 1,
        frequency: str = "D",
        time_col: str = "ds",
        target_col: str = "y",
        estimator: str = "unknown",
    ):
        """
        初始化 ForecastModelWrapper

        Args:
            model: FLAML 训练的时序预测模型
            horizon: 预测时间范围
            frequency: 时间频率
            time_col: 时间列名
            target_col: 目标列名
            estimator: 最佳估计器名称
        """
        self.model = model
        self.horizon = horizon
        self.frequency = frequency
        self.time_col = time_col
        self.target_col = target_col
        self.estimator = estimator

    def predict(self, context, model_input: pd.DataFrame) -> pd.DataFrame:
        """
        执行预测

        Args:
            context: MLflow 模型上下文（包含 artifacts 路径等）
            model_input: 输入数据，应包含时间列

        Returns:
            预测结果 DataFrame，包含时间列和预测值列
        """
        if self.model is None:
            raise ValueError("Model not loaded. Please load the model first.")

        # 防御性频率映射：兼容旧模型（frequency 可能存的是用户原始值如 "M"/"H"）
        resolved_freq = resolve_frequency(self.frequency)

        # 获取输入的时间列
        if self.time_col in model_input.columns:
            future_dates = pd.to_datetime(model_input[self.time_col])
        else:
            # 如果没有时间列，使用默认的未来日期
            future_dates = pd.date_range(
                start=pd.Timestamp.now(),
                periods=self.horizon,
                freq=resolved_freq
            )

        # 构造预测输入
        future_X = pd.DataFrame({self.time_col: future_dates})

        # 执行预测
        try:
            predictions = self.model.predict(future_X)
        except Exception as e:
            # 某些模型可能不支持传入时间列，尝试直接预测
            try:
                predictions = self.model.predict(model_input)
            except Exception:
                raise ValueError(f"Prediction failed: {e}")

        # 确保预测结果长度与输入一致
        n_predictions = len(future_dates)
        if len(predictions) > n_predictions:
            predictions = predictions[:n_predictions]
        elif len(predictions) < n_predictions:
            # 填充不足的部分
            predictions = np.pad(
                predictions,
                (0, n_predictions - len(predictions)),
                mode='edge'
            )

        # 构造输出 DataFrame
        result = pd.DataFrame({
            self.time_col: future_dates,
            f"predicted_{self.target_col}": predictions
        })

        return result


# ============================================================================
# 时序数据预处理
# ============================================================================

def infer_frequency(df: pd.DataFrame, time_col: str) -> str:  # noqa: C901
    """
    自动推断时间序列的频率

    Args:
        df: 时序数据 DataFrame
        time_col: 时间列名

    Returns:
        推断出的频率字符串（pandas freq 格式）
    """
    if len(df) < 2:
        safe_print("⚠️  Not enough data points to infer frequency, defaulting to 'D'")
        return "D"

    # 计算时间差
    time_diffs = df[time_col].diff().dropna()

    if len(time_diffs) == 0:
        return "D"

    # 获取最常见的时间差
    mode_diff = time_diffs.mode()
    if len(mode_diff) == 0:
        median_diff = time_diffs.median()
    else:
        median_diff = mode_diff.iloc[0]

    # 转换为秒
    total_seconds = median_diff.total_seconds()

    # 推断频率
    if total_seconds < 60:  # 秒级
        freq = "s"
    elif total_seconds < 3600:  # 分钟级
        freq = "min"
    elif total_seconds < 86400:  # 小时级
        freq = "h"
    elif total_seconds < 86400 * 7:  # 天级
        freq = "D"
    elif total_seconds < 86400 * 28:  # 周级
        freq = "W"
    elif total_seconds < 86400 * 90:  # 月级
        freq = "ME"
    elif total_seconds < 86400 * 365:  # 季度级
        freq = "QE"
    else:  # 年级
        freq = "YE"

    safe_print(f"📊 Inferred frequency: {freq} (median interval: {median_diff})")
    return freq


def fill_missing_timestamps(df: pd.DataFrame, time_col: str, frequency: str) -> tuple:
    """
    填充缺失的时间点并设置规则频率（参考 Databricks/Azure AutoML 策略）

    Args:
        df: 时序数据 DataFrame
        time_col: 时间列名
        frequency: 时间频率

    Returns:
        (filled_df, inferred_frequency) 元组
    """
    # 如果 frequency 是 "auto" 或无法识别，自动推断
    inferred_frequency = None
    if frequency.lower() == "auto" or frequency not in FREQ_MAP:
        safe_print(f"ℹ️  Frequency '{frequency}' not recognized or set to auto, inferring from data...")
        pd_freq = infer_frequency(df, time_col)
        inferred_frequency = pd_freq
    else:
        pd_freq = resolve_frequency(frequency)

    date_min = df[time_col].min()
    date_max = df[time_col].max()

    # 创建完整的日期范围（带有 freq 属性）
    full_date_range = pd.date_range(start=date_min, end=date_max, freq=pd_freq)

    existing_dates = set(df[time_col])
    missing_dates = set(full_date_range) - existing_dates

    if missing_dates:
        safe_print(f"⚠️  Found {len(missing_dates)} missing time points, filling with forward fill...")

    # 设置时间列为索引
    df = df.set_index(time_col)

    # 重建索引为完整的日期范围（这会自动设置 freq 属性）
    df = df.reindex(full_date_range)
    df.index.name = time_col

    # 确保索引有 freq 属性
    if df.index.freq is None:
        df.index = pd.DatetimeIndex(df.index, freq=pd_freq)
        safe_print(f"✅ Set time index frequency to: {pd_freq}")

    # 前向填充 + 后向填充
    df = df.ffill().bfill()

    # 重置索引
    df = df.reset_index()

    if missing_dates:
        safe_print(f"✅ Missing time points filled. New shape: {df.shape}")
    else:
        safe_print(f"✅ Time series regularized with frequency: {pd_freq}")

    return df, inferred_frequency


def prepare_forecast_data(
    pdf: pd.DataFrame,
    target_col: str,
    features: List[str],
    settings: dict,
    time_col: Optional[str] = None,
    horizon: int = 1,
    frequency: str = "auto",
) -> tuple:
    """
    准备时序预测任务的数据和 fit 参数

    自动进行以下预处理：
    1. 转换时间列为 datetime 类型
    2. 按时间排序
    3. 自动推断频率（如果设置为 "auto" 或未识别）
    4. 填充缺失时间点
    5. 设置规则频率索引

    Args:
        pdf: 完整数据 DataFrame
        target_col: 目标列名
        features: 特征列列表
        settings: FLAML 设置
        time_col: 时间列名
        horizon: 预测时间范围
        frequency: 时间频率

    Returns:
        (fit_kwargs, inferred_frequency) 元组
    """
    # 使用完整的连续数据
    train_df = pdf.copy()

    # 确保时间列是 datetime 类型
    if time_col and time_col in train_df.columns:
        if not pd.api.types.is_datetime64_any_dtype(train_df[time_col]):
            safe_print(f"Converting time column '{time_col}' to datetime...")
            train_df[time_col] = pd.to_datetime(train_df[time_col])

    # 选择需要的列（排除内部列）
    internal_cols = {"_automl_split_col", "_automl_sample_weight"}
    forecast_cols = [time_col, target_col] + [
        f for f in features if f not in internal_cols and f != time_col
    ]
    forecast_cols = list(dict.fromkeys(forecast_cols))
    train_df_for_flaml = train_df[forecast_cols].copy()

    # 按时间排序并去重（保留最后一个重复时间点）
    train_df_for_flaml = train_df_for_flaml.sort_values(by=time_col)
    if train_df_for_flaml[time_col].duplicated().any():
        dup_count = train_df_for_flaml[time_col].duplicated().sum()
        safe_print(f"⚠️  Found {dup_count} duplicate timestamps, keeping last occurrence...")
        train_df_for_flaml = train_df_for_flaml.drop_duplicates(subset=[time_col], keep='last')
    train_df_for_flaml = train_df_for_flaml.reset_index(drop=True)

    # 缺失时间点补充 + 设置规则频率
    train_df_for_flaml, inferred_frequency = fill_missing_timestamps(
        train_df_for_flaml, time_col, frequency
    )

    # 获取实际使用的频率
    actual_freq = inferred_frequency if inferred_frequency else frequency

    safe_print("Forecast task: using dataframe + label mode")
    safe_print(f"  Time column: {time_col}")
    safe_print(f"  Horizon: {horizon}")
    safe_print(f"  Frequency: {actual_freq}")
    safe_print(f"  DataFrame shape: {train_df_for_flaml.shape}")
    safe_print(f"  Date range: {train_df_for_flaml[time_col].min()} to {train_df_for_flaml[time_col].max()}")

    fit_kwargs = {
        "dataframe": train_df_for_flaml,
        "label": target_col,
        "time_col": time_col,
        "period": horizon,
        **settings,
    }

    return fit_kwargs, inferred_frequency


# ============================================================================
# 时序预测模型 MLflow 记录
# ============================================================================

def get_package_version(package_name: str) -> Optional[str]:
    """
    获取已安装包的版本号

    Args:
        package_name: 包名（如 pandas, numpy, scikit-learn）

    Returns:
        版本号字符串，如果包未安装则返回 None
    """
    try:
        from importlib.metadata import version
        return version(package_name)
    except Exception:
        return None


def get_forecast_pip_requirements() -> List[str]:
    """
    根据使用的估计器动态生成 pip 依赖列表

    Returns:
        pip 依赖列表
    """
    extra_requirements = []

    # 添加本包（包含 ForecastModelWrapper，加载模型时必需）
    pkg_version = get_package_version("tencent-wedata3-auto-ml")
    if pkg_version:
        extra_requirements.append(f"tencent-wedata3-auto-ml=={pkg_version}")
    else:
        extra_requirements.append("tencent-wedata3-auto-ml")

    if extra_requirements:
        safe_print("📦 Extra pip requirements for forecast model:")
        for req in extra_requirements:
            safe_print(f"   - {req}")

    return extra_requirements


def log_forecast_model(
    automl,
    pipeline,
    parent_run_id: str,
    task: str,
    target_col: str,
    name_suffix: str = "",
    registered_model_name: Optional[str] = None,
    **kwargs
) -> tuple:
    """
    使用 mlflow.pyfunc.log_model 方式记录时序预测模型

    时序预测模型（如 ARIMA, Prophet）不兼容 sklearn，需要使用 pyfunc 方式记录。
    使用标准 MLflow pyfunc 格式，生成完整的 MLmodel 结构。

    Args:
        automl: FLAML AutoML 实例
        pipeline: 训练好的模型 pipeline
        parent_run_id: 父 run 的 ID
        task: 任务类型
        target_col: 目标列名
        name_suffix: 模型名称后缀
        registered_model_name: 注册模型的名称（可选）
        **kwargs: 额外参数 (horizon, frequency, time_col 等)

    Returns:
        (model_uri, model_version) 元组
    """
    from mlflow.models import infer_signature
    from wedata_automl.engines.mlflow_manager import set_model_version_wedata_tags

    # 获取模型元数据
    best_estimator = automl.best_estimator if hasattr(automl, 'best_estimator') else "unknown"
    horizon = kwargs.get("horizon", 1)
    frequency = kwargs.get("frequency", "D")
    time_col = kwargs.get("time_col")

    # 映射频率为 pandas 2.x 标准 freq
    resolved_freq = resolve_frequency(frequency)

    # 创建 ForecastModelWrapper 实例（存储映射后的频率）
    forecast_wrapper = ForecastModelWrapper(
        model=pipeline,
        horizon=horizon,
        frequency=resolved_freq,
        time_col=time_col,
        target_col=target_col,
        estimator=best_estimator,
    )

    # 创建输入示例和签名（使用映射后的频率）
    input_example = pd.DataFrame({
        time_col: pd.date_range(start="2024-01-01", periods=3, freq=resolved_freq)
    })

    # 推断签名
    signature = None
    try:
        output_example = pd.DataFrame({
            f"predicted_{target_col}": [0.0] * horizon,
            f"{time_col}": pd.date_range(start="2024-01-01", periods=horizon, freq=resolved_freq)
        })
        signature = infer_signature(input_example, output_example)
        safe_print("✅ Forecast model signature inferred successfully")
    except Exception as e:
        safe_print(f"⚠️  Failed to infer forecast model signature: {e}")

    # 获取额外依赖
    extra_pip_requirements = get_forecast_pip_requirements()

    # 使用 mlflow.pyfunc.log_model 记录模型（注册一把过：与 classification/regression 链路保持一致，
    # 避免在 log_model 之后再次调用 mlflow.register_model 触发额外的 tencentcloud Credential 链
    # （读取 TENCENTCLOUD_SECRET_ID）导致 register 失败而 LoggedModel 状态被置为 UPLOAD_FAILED）。
    log_model_kwargs = dict(
        artifact_path=f"model{name_suffix}",
        python_model=forecast_wrapper,
        signature=signature,
        input_example=input_example,
        extra_pip_requirements=extra_pip_requirements,
        metadata={
            "task": task,
            "estimator": best_estimator,
            "horizon": horizon,
            "frequency": resolved_freq,
            "time_col": time_col,
            "target_col": target_col,
        },
    )
    if registered_model_name:
        log_model_kwargs["registered_model_name"] = registered_model_name

    mlflow.pyfunc.log_model(**log_model_kwargs)

    model_uri = f"runs:/{parent_run_id}/model{name_suffix}"
    safe_print(f"✅ Forecast model logged to MLflow (pyfunc): {model_uri}")

    # 取版本号 + 设置 WeData 平台 tags（与 flaml_trainer.py 中分类/回归分支保持一致）
    model_version = None
    if registered_model_name:
        try:
            client = mlflow.tracking.MlflowClient()
            versions = client.search_model_versions(
                filter_string=f"name='{registered_model_name}'"
            )
            if versions:
                model_version = max(int(v.version) for v in versions)
            safe_print(
                f"✅ Forecast model registered: '{registered_model_name}' version {model_version}"
            )
            mlflow.set_tag("wedata.has_registered_model", "true")
            if model_version:
                set_model_version_wedata_tags(
                    registered_model_name=registered_model_name,
                    model_version=model_version,
                    task=task,
                )
        except Exception as e:
            # 即使 version 查询或 wedata tag 设置失败，log_model 已经把 register 顺带做完了，
            # 因此 has_registered_model 仍然标记为 true，与分类/回归分支语义一致。
            safe_print(f"⚠️  Could not get forecast model version or set wedata tags: {e}")
            mlflow.set_tag("wedata.has_registered_model", "true")
    else:
        safe_print("ℹ️  Model not registered (no model name provided)")
        mlflow.set_tag("wedata.has_registered_model", "false")

    return model_uri, model_version


# ============================================================================
# 时序预测结果保存
# ============================================================================

def save_forecast_predictions(  # noqa: C901
    automl,
    parent_run_id: str,
    pdf: pd.DataFrame,
    prediction_result_storage: str,
    target_col: str,
    time_col: Optional[str] = None,
    horizon: int = 1,
    frequency: str = "D",
    spark=None
):
    """
    保存时序预测结果到 DLC 表

    支持预测区间（prediction interval）：
    - Prophet: 原生支持 yhat_lower, yhat_upper
    - ARIMA/SARIMAX: 通过 get_forecast 支持置信区间
    - 其他模型: 仅返回点预测

    Args:
        automl: FLAML AutoML 实例
        parent_run_id: 父 run ID
        pdf: 原始数据
        prediction_result_storage: 存储路径
        target_col: 目标列名
        time_col: 时间列名
        horizon: 预测时间范围
        frequency: 频率
        spark: Spark session
    """
    safe_print("", show_timestamp=False, show_level=False)
    print_separator()
    safe_print("📤 Saving Forecast Predictions")
    print_separator()

    if spark is None:
        safe_print("⚠️  Spark session not available, skipping prediction save")
        return

    try:
        from datetime import datetime

        best_estimator = automl.best_estimator if hasattr(automl, 'best_estimator') else "unknown"

        safe_print(f"Best estimator: {best_estimator}")
        safe_print(f"Generating predictions for {horizon} periods...")

        # 映射频率为 pandas 2.x 标准 freq，修复月/季/年偏移错误
        resolved_freq = resolve_frequency(frequency)
        freq_offset = frequency_to_offset(frequency)

        # 生成未来时间序列
        future_dates = pd.date_range(
            start=pdf[time_col].max() + freq_offset,
            periods=horizon,
            freq=resolved_freq
        )

        # 获取预测值和预测区间
        predictions = None
        predictions_lower = None
        predictions_upper = None

        # Prophet 原生支持预测区间
        if best_estimator == "prophet" and hasattr(automl, 'model'):
            try:
                model = automl.model
                if hasattr(model, 'model') and hasattr(model.model, 'predict'):
                    prophet_model = model.model
                    future_df = prophet_model.make_future_dataframe(periods=horizon, freq=resolved_freq)
                    forecast_df = prophet_model.predict(future_df)
                    forecast_tail = forecast_df.tail(horizon)
                    predictions = forecast_tail['yhat'].values
                    predictions_lower = forecast_tail['yhat_lower'].values
                    predictions_upper = forecast_tail['yhat_upper'].values
                    safe_print("✅ Prophet prediction interval obtained (80% confidence)")
            except Exception as e:
                safe_print(f"⚠️  Failed to get Prophet prediction interval: {e}")

        # ARIMA/SARIMAX 支持预测区间
        elif best_estimator in ["arima", "sarimax"] and hasattr(automl, 'model'):
            try:
                model = automl.model
                if hasattr(model, 'model') and hasattr(model.model, 'get_forecast'):
                    arima_model = model.model
                    forecast_result = arima_model.get_forecast(steps=horizon)
                    predictions = forecast_result.predicted_mean.values
                    conf_int = forecast_result.conf_int(alpha=0.2)  # 80% confidence
                    predictions_lower = conf_int.iloc[:, 0].values
                    predictions_upper = conf_int.iloc[:, 1].values
                    safe_print("✅ ARIMA/SARIMAX prediction interval obtained (80% confidence)")
            except Exception as e:
                safe_print(f"⚠️  Failed to get ARIMA prediction interval: {e}")

        # 如果没有获取到预测区间，使用普通预测
        if predictions is None:
            try:
                future_X = pd.DataFrame({time_col: future_dates})
                predictions = automl.predict(future_X)
                safe_print(f"ℹ️  Using point predictions (no prediction interval for {best_estimator})")
            except Exception as e:
                safe_print(f"⚠️  Failed to predict with future time only: {e}")
                safe_print("   This model may require exogenous features for prediction.")
                safe_print(f"   Skipping prediction save for {best_estimator}.")
                return

        # 创建预测结果 DataFrame
        pred_df = pd.DataFrame({
            time_col: future_dates,
            f"predicted_{target_col}": predictions,
            "run_id": parent_run_id,
            "predicted_at": datetime.now()
        })

        # 添加预测区间（如果有）
        if predictions_lower is not None and predictions_upper is not None:
            pred_df[f"predicted_{target_col}_lower"] = predictions_lower
            pred_df[f"predicted_{target_col}_upper"] = predictions_upper
            safe_print(
                "✅ Prediction interval columns added: "
                f"predicted_{target_col}_lower, predicted_{target_col}_upper"
            )

        # 解析三段式表路径
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_id_short = parent_run_id[:8]
        storage_path = prediction_result_storage.strip()

        # 解析三段式路径 (catalog.database.table)
        path_parts = storage_path.split(".")
        if len(path_parts) == 3:
            catalog, database, table_prefix = path_parts
            table_name = f"{catalog}.{database}.{table_prefix}_{run_id_short}_{timestamp}"
        elif len(path_parts) == 2:
            database, table_prefix = path_parts
            table_name = f"{database}.{table_prefix}_{run_id_short}_{timestamp}"
        else:
            table_name = f"default.{storage_path}_{run_id_short}_{timestamp}"

        safe_print(f"Saving to table: {table_name}")

        # 转换为 Spark DataFrame 并保存
        spark_df = spark.createDataFrame(pred_df)
        spark_df.write.mode("overwrite").saveAsTable(table_name)

        # 记录存储位置到 MLflow
        mlflow.log_param("prediction_table", table_name)
        mlflow.set_tag("wedata.prediction_table", table_name)

        safe_print(f"✅ Predictions saved to: {table_name}")
        safe_print(f"   Rows: {len(pred_df)}")

    except Exception as e:
        safe_print(f"⚠️  Failed to save predictions: {e}")
        import traceback
        safe_print(f"   {traceback.format_exc()}")
