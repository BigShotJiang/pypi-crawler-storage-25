"""Smoke tests for TradeChart public API surface."""

import pytest

import tradechart as tc
from tradechart.utils.validation import (
    validate_ticker,
    validate_duration,
    validate_chart_type,
    validate_format,
    validate_indicators,
)
from tradechart.utils.formatting import sanitize_filename, build_default_filename
from tradechart.charts.themes import get_theme
from tradechart.config.settings import get_settings


# ── Validation ───────────────────────────────────────────────────────────────

class TestValidation:

    def test_valid_ticker(self):
        assert validate_ticker("AAPL") == "AAPL"
        assert validate_ticker("btc-usd") == "BTC-USD"

    def test_invalid_ticker_empty(self):
        with pytest.raises(ValueError):
            validate_ticker("")

    def test_valid_durations(self):
        for d in ("1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "10y", "max"):
            assert validate_duration(d) == d

    def test_invalid_duration(self):
        with pytest.raises(ValueError):
            validate_duration("42y")

    def test_valid_chart_types(self):
        for ct in ("candle", "line", "ohlc", "area", "heikin_ashi"):
            assert validate_chart_type(ct) == ct

    def test_invalid_chart_type(self):
        with pytest.raises(ValueError):
            validate_chart_type("pie")

    def test_valid_formats(self):
        for f in ("png", "jpg", "svg", "pdf", "webp"):
            assert validate_format(f) == f

    def test_invalid_format(self):
        with pytest.raises(ValueError):
            validate_format("bmp")

    def test_valid_indicators(self):
        result = validate_indicators(["sma", "rsi", "macd"])
        assert result == ["sma", "rsi", "macd"]

    def test_invalid_indicator(self):
        with pytest.raises(ValueError):
            validate_indicators(["sma", "nonexistent"])

    def test_none_indicators(self):
        assert validate_indicators(None) == []


# ── Formatting ───────────────────────────────────────────────────────────────

class TestFormatting:

    def test_sanitize(self):
        assert sanitize_filename("BTC/USD") == "BTC_USD"

    def test_default_filename(self):
        name = build_default_filename("AAPL", "1mo", "candle", "png")
        assert name == "AAPL_1mo_candle.png"


# ── Themes ───────────────────────────────────────────────────────────────────

class TestThemes:

    def test_known_themes(self):
        for t in ("dark", "light", "classic"):
            theme = get_theme(t)
            assert theme.name == t

    def test_unknown_theme(self):
        with pytest.raises(ValueError):
            get_theme("neon")


# ── Settings ─────────────────────────────────────────────────────────────────

class TestSettings:

    def test_default_theme(self):
        s = get_settings()
        assert s.theme == "dark"

    def test_set_dpi(self):
        s = get_settings()
        s.dpi = 200
        assert s.dpi == 200
        s.dpi = 150  # reset

    def test_invalid_dpi(self):
        s = get_settings()
        with pytest.raises(ValueError):
            s.dpi = 9999


# ── Public API surface ──────────────────────────────────────────────────────

class TestPublicAPI:

    def test_version(self):
        assert tc.__version__ == "2.0.0"

    def test_exports(self):
        for name in ("chart", "compare", "data", "export",
                      "terminal", "theme", "watermark", "config", "clear_cache"):
            assert hasattr(tc, name), f"Missing public API: {name}"
