import asyncio
import csv
import io
import json
import re
import sys
from logging import Logger
from pathlib import Path
from typing import Any, AsyncGenerator, cast
from xml.etree import ElementTree

import httpx
import pandas as pd
import polars as pl
from tabulate import tabulate

from bizutl.config.base_config import (
    clean_up_dir,
    convert_from_dt_type_to_str_type,
    get_log_extra,
)


class GetJapanGovernmentStatistics:
    """
    Get statistical data from the Japan government.
    """

    def __init__(self, logger: Logger):
        """Constructor"""
        self.logger: Logger = logger
        self.timeout: httpx.Timeout = httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=10.0)
        # Credit text
        self.credit_text: tuple = (
            "クレジット表示",
            "このサービスは、政府統計総合窓口(e-Stat)のAPI機能を使用していますが、",
            "サービスの内容は国によって保証されたものではありません。",
        )
        # Dictionary of all methods for retrieving the list of statistics table IDs
        self.dct_of_get_type: dict = {
            "Async": "Executes without waiting for completion.",
            "Sync": "Waits for completion before continuing.",
        }
        # Dictionary of all data formats to retrieve
        self.dct_of_data_type: dict = {
            "xml": "Tag structure data",
            "json": "Key-value pair data",
            "csv": "Comma-separated data",
        }
        # Dictionary of all search methods
        self.dct_of_match_type: dict = {
            "Partial match": "The field value contains the keyword.",
            "Exact match": "The field value must match the keyword exactly.",
        }
        # Dictionary of all extraction methods (when there are two or more keywords)
        self.dct_of_logic_type: dict = {
            "OR extraction": "Contain any of some keywords.",
            "AND extraction": "Contain all of some keywords.",
        }
        # Key number of the list variable
        self.KEY: int = 0
        # Description number of the list variable
        self.DESCRIPTION: int = 1
        # List of selected methods for retrieving the list of statistics table IDs
        self.lst_of_get_type: list = []
        # List of selected data formats to retrieve
        self.lst_of_data_type: list = []
        # List of selected search methods
        self.lst_of_match_type: list = []
        # List of entered keywords to extract
        self.lst_of_keyword: list = []
        # List of selected extraction methods
        self.lst_of_logic_type: list = []
        # Header of the CSV file for the list of statistics table IDs
        self.header_of_ids_l: list = ["統計表ID", "統計名", "表題"]
        self.header_of_ids_s: str = ",".join(self.header_of_ids_l)
        # API version
        self.VERSION: float = 3.0
        # Application ID
        self.APP_ID: str = ""
        # Statistics table ID
        self.STATS_DATA_ID: str = ""
        # Statistics name
        self.STAT_NAME: str = ""
        # Title
        self.TITLE: str = ""
        # Number of records in the specified statistics table
        self.DATA_COUNT: int = 0
        # Pandas dataframe of the specified statistics table
        self.pd_df: pd.DataFrame | None = None
        # Distinguish between when it is compiled as an exe and when it is not
        exe_path: Path = Path(sys.executable) if getattr(sys, "frozen", False) else Path(__file__)
        # Directory for storing the CSV file of the list of statistics table IDs
        self.directory_p_of_ids: Path = exe_path.parent / "__stats_table_ids__"
        self.directory_s_of_ids: str = str(self.directory_p_of_ids)
        # Directory for storing the CSV file of the specified statistics table
        self.directory_p_of_table: Path = exe_path.parent / "__output__"
        self.directory_s_of_table: str = str(self.directory_p_of_table)

    def append_log_for_constructor(self) -> bool:
        """Append log for the constructor."""
        result: bool = False
        try:
            self.logger.info(f"{self.__class__.__qualname__}: {self.__class__.__doc__}")
            self.logger.info("\n".join(self.credit_text))
            self.logger.info(
                "Path to the directory "
                "that contains CSV files with a list of statistical table IDs: \n"
                f"{self.directory_s_of_ids}"
            )
            self.logger.info(
                "Path to the directory "
                "that contains CSV files with the user-specified statistical table: \n"
                f"{self.directory_s_of_table}"
            )
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    async def get_stats_table_ids(self) -> AsyncGenerator[dict, None]:
        """Get a list of statistical table IDs (asynchronous version)."""

        def _parse_xml_data(res: httpx.Response) -> tuple[dict, int]:
            """Parse XML data (common to synchronous and asynchronous versions)."""
            page_dct: dict = {}
            try:
                root: ElementTree.Element[str] = ElementTree.fromstring(res.text)
                table_lst: list[ElementTree.Element[str]] = root.findall(".//TABLE_INF")
                for t in table_lst:
                    stat_id: str = (t.attrib.get("id", "") or "") if t is not None else ""
                    element_of_stat_name: ElementTree.Element | None = t.find("STAT_NAME")
                    stat_name: str = (
                        (element_of_stat_name.text or "") if element_of_stat_name is not None else ""
                    )
                    element_of_title: ElementTree.Element | None = t.find("TITLE")
                    title: str = (element_of_title.text or "") if element_of_title is not None else ""
                    page_dct[stat_id] = {"stat_name": stat_name, "title": title}
            except asyncio.CancelledError:
                raise
            except KeyboardInterrupt:
                raise
            except Exception:
                # Debug
                self.logger.debug("***Failed***", extra=get_log_extra(func_flag=True))
                self.logger.debug(res.text)
                raise
            else:
                pass
            finally:
                pass
            return page_dct, len(table_lst)

        def _parse_json_data(res: httpx.Response) -> tuple[dict, int]:
            """Parse JSON data (common to synchronous and asynchronous versions)."""
            page_dct: dict = {}
            try:
                data: Any = res.json()
                table_data: Any = data["GET_STATS_LIST"]["DATALIST_INF"]["TABLE_INF"]
                table_lst = [table_data] if isinstance(table_data, dict) else table_data
                for t in table_lst:
                    stat_id: str = t.get("@id", "")
                    statistics_name: str = t.get("STATISTICS_NAME", {})
                    title: str = t.get("TITLE", {})
                    page_dct[stat_id] = {
                        "statistics_name": statistics_name,
                        "title": title,
                    }
            except asyncio.CancelledError:
                raise
            except KeyboardInterrupt:
                raise
            except Exception:
                # Debug
                self.logger.debug("***Failed***", extra=get_log_extra(func_flag=True))
                self.logger.debug(json.dumps(data, indent=4, ensure_ascii=False))
                raise
            else:
                pass
            finally:
                pass
            return page_dct, len(table_lst)

        def _parse_csv_data(res: httpx.Response) -> tuple[dict, int]:
            """Parse CSV data (common to synchronous and asynchronous versions)."""
            page_dct: dict = {}
            row_count: int = 0
            try:
                lines: list = res.text.splitlines()
                # Search for the header row
                start_idx: int = 0
                for i, line in enumerate(lines):
                    if "STAT_INF" in line:
                        # Move to the next row
                        start_idx = i + 1
                        break
                if start_idx == 0:
                    raise Exception("The header row is missing from the CSV file.")
                csv_text: str = "\n".join(lines[start_idx:])
                reader: csv.DictReader[str] = csv.DictReader(io.StringIO(csv_text))
                for row in reader:
                    row_count += 1
                    stat_id: str = row.get("TABLE_INF", "")
                    stat_name: str = row.get("STAT_NAME", "")
                    title: str = row.get("TITLE", "")
                    page_dct[stat_id] = {"stat_name": stat_name, "title": title}
            except asyncio.CancelledError:
                raise
            except KeyboardInterrupt:
                raise
            except Exception:
                # Debug
                self.logger.debug("***Failed***", extra=get_log_extra(func_flag=True))
                self.logger.debug(res.text)
                raise
            else:
                pass
            finally:
                pass
            return page_dct, row_count

        try:
            parser_map: dict = {
                "xml": _parse_xml_data,
                "json": _parse_json_data,
                "csv": _parse_csv_data,
            }
            # Dictionary of API URLs for retrieving the list of statistics table IDs
            dct_of_ids_url: dict = {
                "xml": f"http://api.e-stat.go.jp/rest/{self.VERSION}/app/getStatsList",
                "json": f"http://api.e-stat.go.jp/rest/{self.VERSION}/app/json/getStatsList",
                "csv": f"http://api.e-stat.go.jp/rest/{self.VERSION}/app/getSimpleStatsList",
            }
            data_type: str = self.lst_of_data_type[self.KEY]
            parser: Any = parser_map.get(data_type)
            if not parser:
                raise Exception("That data type is invalid.")
            url: str = dct_of_ids_url[data_type]
            start: int = 1
            limit: int = 100
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                while True:
                    params: dict = {
                        "appId": self.APP_ID,
                        "lang": "J",
                        "limit": limit,
                        "startPosition": start,
                    }
                    res: httpx.Response = await client.get(url, params=params)
                    res.encoding = "utf-8"
                    res.raise_for_status()
                    page_dct, count = parser(res)
                    if count == 0:
                        break
                    yield page_dct
                    start += limit
        except asyncio.CancelledError:
            raise
        except httpx.HTTPStatusError:
            raise
        except httpx.RequestError:
            raise
        except Exception:
            raise
        else:
            pass
        finally:
            pass

    async def export_stats_table_ids_to_csv_file(self, chunk_size: int = 100) -> bool:
        """Export a list of statistical table IDs to a CSV file (asynchronous version)."""

        def write_stats_table_ids_to_csv_file(file_index: int, buffer: list) -> None:
            """Write a list of statistical table IDs to a CSV file."""
            file_p_of_ids = self.directory_p_of_ids / f"list_of_stats_table_ids_{file_index}.csv"
            file_p_of_ids.write_text("\n".join(buffer), encoding="utf-8")

        result: bool = False
        try:
            self.logger.info(f"{self.export_stats_table_ids_to_csv_file.__doc__} => Processing...")
            self.directory_p_of_ids.mkdir(parents=True, exist_ok=True)
            clean_up_dir(self.directory_p_of_ids)
            buffer: list = [self.header_of_ids_s]
            file_index: int = 1
            async for page in self.get_stats_table_ids():
                for stat_id, info in page.items():
                    col2: str = info.get("stat_name", info.get("statistics_name", ""))
                    col3: str = info.get("title", "")
                    if col3:
                        # Data cleansing
                        col3 = col3.replace("\u002c", "\u3001").replace("\uff0c", "\u3001")
                    buffer.append(f"{stat_id},{col2},{col3}")
                    if len(buffer) >= chunk_size:
                        write_stats_table_ids_to_csv_file(file_index, buffer)
                        buffer.clear()
                        buffer.append(self.header_of_ids_s)
                        file_index += 1
            if len(buffer) > 1:
                write_stats_table_ids_to_csv_file(file_index, buffer)
        except asyncio.CancelledError:
            self.logger.info("***Cancelled***", extra=get_log_extra(func_flag=True))
            raise
        except httpx.HTTPStatusError:
            raise
        except httpx.RequestError:
            raise
        except Exception:
            self.logger.error("***Failed***", extra=get_log_extra(func_flag=True))
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def find_stat_info(self) -> tuple[str, str]:
        """
        Search CSV files in the specified directory and return the
        stat name and title corresponding to the given stats data ID.
        """
        result: bool = False
        STAT_NAME: str = ""
        TITLE: str = ""
        try:
            for filepath in self.directory_p_of_ids.glob("*.csv"):
                with filepath.open(encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        if row["統計表ID"] == self.STATS_DATA_ID:
                            result = True
                            STAT_NAME = row["統計名"]
                            TITLE = row["表題"]
            if not result:
                raise FileNotFoundError(
                    f"Stats data ID '{self.STATS_DATA_ID}' was not found "
                    f"in any CSV file under '{self.directory_s_of_ids}'."
                )
        except Exception:
            raise
        else:
            pass
        finally:
            pass
        return STAT_NAME, TITLE

    def get_user_specified_stats_table(self) -> bool:
        """Get the user-specified statistics table (synchronous version)."""

        def _get_params_of_url() -> dict:
            """Get the parameters of the API URL."""
            # Dictionary of API URL parameters
            params: dict = {
                "appId": self.APP_ID,  # Application ID
                "statsDataId": self.STATS_DATA_ID,  # Statistics table ID
                "lang": "J",  # Language
                "limit": 100,
                "metaGetFlg": "Y",  # Flag for retrieving meta information
                "cntGetFlg": "N",  # Flag for retrieving the record count
                "explanationGetFlg": "N",  # Flag for the presence of explanatory information
                "annotationGetFlg": "N",  # Flag for the presence of annotation information
                "sectionHeaderFlg": 1,  # Flag for the presence of header rows
                "replaceSpChars": 0,  # Flag for escaping special characters
            }
            return params

        def _as_xml_data(client: httpx.Client, dct_of_params: dict) -> pd.DataFrame:
            """Get the user-specified statistics table as XML data."""
            try:
                id_url: str = f"http://api.e-stat.go.jp/rest/{self.VERSION}/app/getStatsData"
                # Send the request
                res: httpx.Response = client.get(id_url, params=dct_of_params)
                # Parse and retrieve the root element
                root: ElementTree.Element[str] = ElementTree.fromstring(res.text)
                # Create a mapping of codes and names from CLASS_OBJ
                mapping: dict = {}
                for obj in root.findall(".//CLASS_OBJ"):
                    obj_id: str = obj.attrib["id"]
                    code_map: dict = {}
                    for cls in obj.findall("CLASS"):
                        # Create a dictionary with code as the key and name as the value
                        code_map[cls.attrib["code"]] = cls.attrib.get("name", cls.attrib["code"])
                    mapping[obj_id] = code_map
                # Retrieve VALUE and convert it to a dictionary per row
                rows: list = []
                for element in root.findall(".//VALUE"):
                    row: dict = {}
                    for key, value in element.attrib.items():
                        if key in mapping:
                            row[key] = mapping[key].get(value, value)
                        else:
                            row[key] = value
                    # Add the text of VALUE
                    row["値"] = (element.text or "").strip()
                    rows.append(row)
                pd_df: pd.DataFrame = pd.DataFrame(rows)
                # Convert column names to Japanese
                id2name: dict = {}
                for obj in root.findall(".//CLASS_OBJ"):
                    obj_id: str = obj.attrib["id"]
                    obj_name: str = obj.attrib.get("name", obj_id)
                    id2name[obj_id] = obj_name
                id2name["unit"] = "単位"
                pd_df.rename(columns=id2name, inplace=True)
                # Convert value columns to numeric type
                if "値" in pd_df.columns:
                    pd_df["値"] = pd.to_numeric(pd_df["値"], errors="coerce")
            except Exception:
                # Debug
                self.logger.debug("***Failed***", extra=get_log_extra(func_flag=True))
                self.logger.debug(res.text)
                raise
            else:
                pass
            finally:
                pass
            return pd_df

        def _as_json_data(client: httpx.Client, dct_of_params: dict) -> pd.DataFrame:
            """Get the user-specified statistics table as JSON data."""
            try:
                id_url: str = f"http://api.e-stat.go.jp/rest/{self.VERSION}/app/json/getStatsData"
                # Send the request
                res: httpx.Response = client.get(id_url, params=dct_of_params)
                data: Any = res.json()
                # Extract CLASS_OBJ and VALUE
                class_inf: Any = data["GET_STATS_DATA"]["STATISTICAL_DATA"]["CLASS_INF"]["CLASS_OBJ"]
                values: Any = data["GET_STATS_DATA"]["STATISTICAL_DATA"]["DATA_INF"]["VALUE"]
                # Create a correspondence table of IDs and column names
                col_name_map: dict = {obj["@id"]: obj["@name"] for obj in class_inf}
                col_name_map["unit"] = "単位"
                # Create a dictionary to replace codes in CLASS_OBJ with Japanese names
                code_to_name: dict = {}
                for obj in class_inf:
                    cid: str = obj["@id"]
                    cls: Any = obj["CLASS"]
                    if isinstance(cls, list):
                        code_to_name[cid] = {c["@code"]: c["@name"] for c in cls}
                    else:
                        code_to_name[cid] = {cls["@code"]: cls["@name"]}
                # Convert each row of VALUE to Japanese
                translated_rows: list = []
                for value in values:
                    row: dict = {}
                    for k, v in value.items():
                        jp_col: str = ""
                        if k.startswith("@") and k[1:] in code_to_name:
                            jp_col: Any = col_name_map.get(k[1:], k[1:])
                            row[jp_col] = code_to_name[k[1:]].get(v, v)
                        elif k == "@unit":
                            row["単位"] = v
                        elif k == "$":
                            row["値"] = v
                        else:
                            row[k] = v
                    translated_rows.append(row)
                pd_df: pd.DataFrame = pd.DataFrame(translated_rows)
                # Convert value columns to numeric type
                if "値" in pd_df.columns:
                    pd_df["値"] = pd.to_numeric(pd_df["値"], errors="coerce")
            except Exception:
                # Debug
                self.logger.debug("***Failed***", extra=get_log_extra(func_flag=True))
                self.logger.debug(json.dumps(res.json(), indent=4, ensure_ascii=False))
                raise
            else:
                pass
            finally:
                pass
            return pd_df

        def _as_csv_data(client: httpx.Client, dct_of_params: dict) -> pd.DataFrame:
            """Get the user-specified statistics table as CSV data."""
            try:
                id_url: str = f"http://api.e-stat.go.jp/rest/{self.VERSION}/app/getSimpleStatsData"
                # Send the request
                res: httpx.Response = client.get(id_url, params=dct_of_params)
                lines: list[str] = res.text.splitlines()
                # Search for the position of VALUE rows
                value_idx: int = 0
                for i, line in enumerate(lines):
                    if line.strip().replace('"', "") == "VALUE":
                        value_idx = i
                        break
                if value_idx == 0:
                    raise Exception("The 'VALUE' row was not found in the CSV.")
                # Retrieve the header row
                header_cols: list[str] = [h.strip('"') for h in lines[value_idx + 1].split(",")]
                # Extract the data body as a string
                csv_body: str = "\n".join(lines[value_idx + 2 :])
                pd_df: pd.DataFrame = pd.read_csv(io.StringIO(csv_body), header=None)
                pd_df.columns = header_cols
                # Replace column names with Japanese
                # Delete unnecessary English code columns
                rename_map: dict = {}
                drop_cols: list = []
                i: int = 0
                while i < len(header_cols):
                    eng: str = header_cols[i]
                    if eng.endswith("_code") and i + 1 < len(header_cols):
                        drop_cols.append(eng)
                        i += 2
                        continue
                    # Process single columns
                    elif eng == "unit":
                        rename_map[eng] = "単位"
                    elif eng == "value":
                        rename_map[eng] = "値"
                    else:
                        rename_map[eng] = eng
                    i += 1
                pd_df = pd_df.rename(columns=rename_map)
                pd_df = pd_df.drop(columns=drop_cols)
                # Convert value columns to numeric type
                if "値" in pd_df.columns:
                    pd_df["値"] = pd.to_numeric(pd_df["値"], errors="coerce")
            except Exception:
                # Debug
                self.logger.debug("***Failed***", extra=get_log_extra(func_flag=True))
                self.logger.debug(res.text)
                raise
            else:
                pass
            finally:
                pass
            return pd_df

        result: bool = False
        try:
            dct_of_params: dict = _get_params_of_url()
            # Manage the session
            with httpx.Client(timeout=self.timeout) as client:
                match self.lst_of_data_type[self.KEY]:
                    case "xml":
                        self.pd_df = _as_xml_data(client, dct_of_params)
                    case "json":
                        self.pd_df = _as_json_data(client, dct_of_params)
                    case "csv":
                        self.pd_df = _as_csv_data(client, dct_of_params)
                    case _:
                        raise Exception("That data type is invalid.")
        except Exception:
            raise
        else:
            result = True
            self.DATA_COUNT = len(self.pd_df)
        finally:
            pass
        return result

    def filter_pd_df(self, pd_df: pd.DataFrame) -> pd.DataFrame:
        """Filter the DataFrame."""
        filtered_pd_df: pd.DataFrame | None = None
        filtered_pl_df: pl.DataFrame | None = None
        filtered_pl_lazy_df: pl.LazyFrame | None = None
        try:
            match_type: str = self.lst_of_match_type[self.KEY]
            logic_type: str = self.lst_of_logic_type[self.KEY]
            keywords: list = list(map(str, self.lst_of_keyword))
            # pandas => polars
            pl_df: pl.DataFrame = pl.from_pandas(pd_df)
            pl_lazy_df: pl.LazyFrame = pl_df.lazy()
            # Treat all columns as strings
            str_cols: pl.Expr = pl.all().cast(pl.Utf8)
            match match_type:
                # Partial match
                case "Partial match":
                    # OR
                    if len(keywords) == 1 or logic_type == "OR extraction":
                        pattern: str = "|".join(re.escape(k) for k in keywords)
                        filtered_pl_lazy_df = pl_lazy_df.filter(
                            pl.any_horizontal(str_cols.str.contains(f"(?i){pattern}"))
                        )
                    # AND
                    elif logic_type == "AND extraction":
                        filtered_pl_lazy_df = pl_lazy_df.filter(
                            pl.all_horizontal(
                                [
                                    pl.any_horizontal(str_cols.str.contains(f"(?i){re.escape(k)}"))
                                    for k in keywords
                                ]
                            )
                        )
                    else:
                        raise Exception(f"That logic type is invalid: {logic_type}")
                # Exact match
                case "Exact match":
                    # OR
                    if len(keywords) == 1 or logic_type == "OR extraction":
                        filtered_pl_lazy_df = pl_lazy_df.filter(pl.any_horizontal(str_cols.is_in(keywords)))
                    # AND
                    elif logic_type == "AND extraction":
                        filtered_pl_lazy_df = pl_lazy_df.filter(
                            pl.all_horizontal([pl.any_horizontal(str_cols.eq(k)) for k in keywords])
                        )
                    else:
                        raise Exception(f"That logic type is invalid: {logic_type}")
                case _:
                    raise Exception(f"That match type is invalid: {match_type}")
            # polars => pandas
            filtered_pl_df = cast(pl.DataFrame, filtered_pl_lazy_df.collect())
            filtered_pd_df = filtered_pl_df.to_pandas()
        except Exception:
            raise
        else:
            self.DATA_COUNT = len(filtered_pd_df)
        finally:
            pass
        return filtered_pd_df

    def print_user_specified_stats_table(self) -> bool:
        """Print the user-specified statistical table."""
        result: bool = False
        try:
            self.logger.info(
                f"\n{tabulate(self.pd_df, headers="keys", tablefmt="simple", showindex=False)}\n"
            )
            self.logger.info(f"Statistics table ID => {self.STATS_DATA_ID}")
            self.logger.info(f"Statistics name => {self.STAT_NAME if self.STAT_NAME else "Not found"}")
            self.logger.info(f"Title => {self.TITLE if self.TITLE else "Not found"}")
            self.logger.info(f"Data type => {': '.join(self.lst_of_data_type)}")
            self.logger.info(
                f"Match type => {': '.join(self.lst_of_match_type) if self.lst_of_match_type else "None"}"
            )
            self.logger.info(
                "Keywords to filtered => "
                f"{', '.join(map(str, self.lst_of_keyword)) if self.lst_of_keyword else "None"}"
            )
            self.logger.info(
                f"Logic type => {': '.join(self.lst_of_logic_type) if self.lst_of_logic_type else "None"}"
            )
            self.logger.info(f"Data count of user-specified stats table => {self.DATA_COUNT}")
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def export_user_specified_stats_table_to_csv_file(self) -> bool:
        """Export the user-specified statistical table to a csv file."""
        result: bool = False
        try:
            if self.pd_df is None:
                raise Exception("DataFrame is none.")
            self.directory_p_of_table.mkdir(parents=True, exist_ok=True)
            file_p_of_table: Path = (
                self.directory_p_of_table
                / f"stats_table_{self.STATS_DATA_ID}_{convert_from_dt_type_to_str_type("for_file_name")}.csv"
            )
            file_s_of_table: str = str(file_p_of_table)
            self.pd_df.to_csv(file_s_of_table, index=False, encoding="utf-8")
        except Exception:
            raise
        else:
            result = True
            self.logger.info(f"Path to CSV file with the user-specified statistical table: {file_s_of_table}")
        finally:
            pass
        return result
