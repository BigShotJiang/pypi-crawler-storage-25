from typing import Callable
from urllib.parse import quote, unquote
import logging
import sys
import re

log = logging.getLogger("JSU")

# simplistic typing
type JsonArray = list[Jsonable]
type JsonObject = dict[str, Jsonable]
type Jsonable = None|bool|int|float|str|JsonArray|JsonObject
type JsonSchema = dict[str, Jsonable]|bool
# type JsonPath = tuple[str|int, ...]
type SchemaPathSegment = str|tuple[str, str]|tuple[str, int]
type SchemaPath = tuple[SchemaPathSegment, ...]
type FilterFun = Callable[[JsonSchema, SchemaPath], bool]
type RewriteFun = Callable[[JsonSchema, SchemaPath], JsonSchema]

ALL_TYPES: set[str] = {"null", "boolean", "integer", "number", "string", "array", "object"}

# keywords specific to a type, including some old keywords (draft3 divisibleBy)
TYPED_KEYWORDS: dict[str, list[str]] = {
    "number": ["minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum", "multipleOf",
               "divisibleBy"],
    "string": ["minLength", "maxLength", "pattern"],
    "array": ["minItems", "maxItems", "uniqueItems", "items", "prefixItems", "contains",
              "minContains", "maxContains", "additionalItems", "unevaluatedItems"],
    "object": ["properties", "required", "additionalProperties", "minProperties", "maxProperties",
               "patternProperties", "propertyNames", "unevaluatedProperties"],
}

KEYWORD_TYPE: dict[str, str] = {}

# keyword that can always be dropped
NO_SEMANTICS = [
    "title", "description", "default", "examples", "deprecated", "readOnly", "writeOnly",
    "$comment",
]

FORMAT_HINT = "$__jsu_format__"

# FIXME ref should be out
META_KEYS = NO_SEMANTICS + [
    "$schema", "$id", "id", "$dynamicAnchor", "$dynamicRef",
    # OLD?
    "context", "notes", "$recursiveAnchor", "$recursiveRef",
    # extensions and strange stuff?
    "markdownDescription", "deprecationMessage", "scope", "body", "example", "private",
    # internal information about format assertion
    FORMAT_HINT,
]

IGNORE = META_KEYS + ["$defs", "definitions"]

for k in TYPED_KEYWORDS.keys():
    for n in TYPED_KEYWORDS[k]:
        KEYWORD_TYPE[n] = k


class JSUError(BaseException):
    pass


# similar to has_only but with a message
def only(schema, *props) -> bool:
    """Tell whether schema only contains these props."""
    assert isinstance(schema, dict)
    ok = set(schema.keys()).issubset(set(props))
    if not ok:
        ttype = schema.get("type", "<>")
        log.debug(f"BAD SCHEMA {ttype}: {list(schema.keys())} {props}")
    return ok

def used_props(schema, *props) -> set[str]:
    """Return occuring properties among props."""
    assert isinstance(schema, dict)
    return set(props) & schema.keys()


def has_all(schema, *props) -> bool:
    """Tell whether schema has all of these props."""
    assert isinstance(schema, dict)
    for p in props:
        if p not in schema:
            return False
    return True

def has_only(schema, *props) -> bool:
    """Tell whether schema has only these props."""
    assert isinstance(schema, dict)
    for p in schema:
        if p not in props:
            return False
    return True

def has_none(schema, *props) -> bool:
    """Tell whether schema has none of these props."""
    assert isinstance(schema, dict)
    for p in props:
        if p in schema:
            return False
    return True

def has_any(schema, *props) -> bool:
    """Tell whether schema has any of these props (reverse of previous)."""
    assert isinstance(schema, dict)
    for p in props:
        if p in schema:
            return True
    return False

def has_count(schema, *props) -> int:
    """Tell the number of props found in schema."""
    assert isinstance(schema, dict)
    count: int = 0
    for p in props:
        if p in schema:
            count += 1
    return count

def openfiles(args: list[str] = []):
    if not args:  # empty list is same as stdin
        args = ["-"]
    for fn in args:
        if fn == "-":
            yield fn, sys.stdin
        else:
            with open(fn) as fh:
                yield fn, fh

def encode_url(segment: str) -> str:
    """Encode path: why not rely simply on URL encoding?!"""
    return quote(segment.replace("~", "~0").replace("/", "~1"))

def decode_url(segment: str) -> str:
    """Decode strange url-and-more path."""
    if "~0" in segment or "~1" in segment or "%" in segment:
        return unquote(segment).replace("~1", "/").replace("~0", "~")
    else:
        return segment

def schemapath_to_urlpath(path: SchemaPath) -> str:
    """Encode a schema path as a url path."""
    return "/".join(encode_url(s) if isinstance(s, str) else
                    f"{encode_url(str(s[0]))}/{encode_url(str(s[1]))}"
                        for s in path)

_IS_ABS_URL = re.compile(r"((https?|file)://|urn:)").match

def is_abs_url(s: str) -> bool:
    """Guess if a reference is some kind of absolute URL."""
    return _IS_ABS_URL(s) is not None

def is_any(schema: JsonSchema) -> bool:
    """Tell whether this schema accepts anything."""
    if isinstance(schema, bool):
        return schema
    assert isinstance(schema, dict), f"unexpected schema={schema}"
    if only(schema, "type", *IGNORE):
        if "type" in schema:
            types = schema["type"]
            return isinstance(types, list) and set(types) == ALL_TYPES
        else:
            return True

def is_none(schema: JsonSchema) -> bool:
    """Tell if this schema accepts nothing at all."""
    if isinstance(schema, bool):
        return not schema
    assert isinstance(schema, dict)
    if "type" in schema and isinstance(schema["type"], list) and not schema["type"]:
        return True
    return False
