dev : sib
tele : @sin_php 
Explanation of the tool : A useful tool for intelligence; its function is to retrieve a person's information using their phone number. 
