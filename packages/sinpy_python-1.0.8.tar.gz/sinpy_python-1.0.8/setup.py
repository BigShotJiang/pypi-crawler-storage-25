from setuptools import setup, find_packages

setup(
    name='sinpy-python',
    version='1.0.8',
    author='sin_php',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'sin': ['*.so'],
    },
    install_requires=[
        'requests',
        'pycryptodome',
    ],
)
