"""Configuration loader for .consync.yaml files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from consync.models import ConsyncConfig, MappingConfig, SyncDirection

DEFAULT_CONFIG_NAME = ".consync.yaml"

# Format auto-detection from file extensions
EXTENSION_TO_FORMAT: dict[str, str] = {
    ".xlsx": "xlsx",
    ".xls": "xlsx",
    ".csv": "csv",
    ".json": "json",
    ".toml": "toml",
    ".h": "c_header",
    ".hpp": "c_header",
    ".hh": "c_header",
    ".c": "c_header",
    ".cs": "csharp",
    ".py": "python",
    ".rs": "rust",
    ".v": "verilog",
    ".sv": "verilog",
    ".vhd": "vhdl",
    ".vhdl": "vhdl",
}


def find_config(start_dir: Path | None = None) -> Path | None:
    """Walk up from start_dir looking for .consync.yaml.

    Similar to how .gitignore or pyproject.toml are found.
    """
    if start_dir is None:
        start_dir = Path.cwd()
    start_dir = start_dir.resolve()

    for directory in [start_dir, *start_dir.parents]:
        candidate = directory / DEFAULT_CONFIG_NAME
        if candidate.exists():
            return candidate
    return None


def detect_format(filepath: str) -> str:
    """Auto-detect format from file extension."""
    ext = Path(filepath).suffix.lower()
    fmt = EXTENSION_TO_FORMAT.get(ext, "")
    if not fmt:
        raise ValueError(
            f"Cannot auto-detect format for '{filepath}'. "
            f"Supported extensions: {', '.join(sorted(EXTENSION_TO_FORMAT.keys()))}. "
            f"Specify format explicitly in .consync.yaml."
        )
    return fmt


def _parse_direction(raw: str) -> SyncDirection:
    """Parse direction string from YAML config."""
    mapping = {
        "source_to_target": SyncDirection.SOURCE_TO_TARGET,
        "target_to_source": SyncDirection.TARGET_TO_SOURCE,
        "both": SyncDirection.BOTH,
        "s2t": SyncDirection.SOURCE_TO_TARGET,
        "t2s": SyncDirection.TARGET_TO_SOURCE,
        "bidirectional": SyncDirection.BOTH,
    }
    normalized = raw.lower().strip().replace("-", "_").replace(" ", "_")
    if normalized not in mapping:
        raise ValueError(
            f"Invalid direction '{raw}'. "
            f"Use: source_to_target, target_to_source, or both."
        )
    return mapping[normalized]


def _format_matches_extension(format_name: str, filepath: str) -> bool:
    """Check if a format name is compatible with a file's extension."""
    ext = Path(filepath).suffix.lower()
    # Map format names to compatible extensions
    FORMAT_COMPATIBLE_EXTENSIONS: dict[str, set[str]] = {
        "c_header": {".c", ".h", ".hpp", ".hh"},
        "c_struct_table": {".c", ".h", ".hpp", ".hh"},
        "xlsx": {".xlsx", ".xls"},
        "csv": {".csv"},
        "json": {".json"},
        "verilog": {".v", ".sv"},
        "vhdl": {".vhd", ".vhdl"},
        "python": {".py"},
        "rust": {".rs"},
        "csharp": {".cs"},
    }
    compatible = FORMAT_COMPATIBLE_EXTENSIONS.get(format_name, set())
    return ext in compatible


def _parse_mapping(raw: dict[str, Any], config_dir: Path) -> MappingConfig:
    """Parse a single mapping entry from YAML."""
    source = raw.get("source", "")
    target = raw.get("target", "")

    if not source:
        raise ValueError("Each mapping must have a 'source' field.")
    if not target:
        raise ValueError("Each mapping must have a 'target' field.")

    generic_format = raw.get("format", "")
    source_format = raw.get("source_format", "") or raw.get("format_source", "")
    target_format = raw.get("target_format", "") or raw.get("format_target", "")

    # If generic 'format' is specified, assign it to the side whose extension matches
    if generic_format:
        if not source_format and _format_matches_extension(generic_format, source):
            source_format = generic_format
        elif not target_format and _format_matches_extension(generic_format, target):
            target_format = generic_format
        elif not target_format:
            # Legacy fallback: assign to target_format (backward compat)
            target_format = generic_format

    # Auto-detect formats if not specified
    if not source_format:
        source_format = detect_format(source)
    if not target_format:
        target_format = detect_format(target)

    direction = _parse_direction(raw.get("direction", "source_to_target"))

    # Normalize parser_options — handle None (empty YAML value) and promote
    # common parser keys (variant, table_var, fields) from mapping level
    parser_options = raw.get("parser_options") or {}
    _PROMOTABLE_PARSER_KEYS = ("variant", "table_var", "fields")
    for key in _PROMOTABLE_PARSER_KEYS:
        if key not in parser_options and key in raw:
            parser_options[key] = raw[key]

    # protect_target is mandatory when direction is not 'both'
    protect_target_raw = raw.get("protect_target")
    if direction != SyncDirection.BOTH:
        if protect_target_raw is None:
            raise ValueError(
                f"Mapping '{source}' → '{target}': 'protect_target' is required "
                f"when direction is '{raw.get('direction', 'source_to_target')}' (not 'both'). "
                f"Set protect_target: true to make the destination file read-only after sync, "
                f"or protect_target: false to allow manual edits."
            )
    protect_target = bool(protect_target_raw) if protect_target_raw is not None else False

    return MappingConfig(
        source=source,
        target=target,
        source_format=source_format,
        target_format=target_format,
        direction=direction,
        precision=int(raw.get("precision", 17)),
        header_guard=raw.get("header_guard", ""),
        namespace=raw.get("namespace", ""),
        module_name=raw.get("module_name", ""),
        prefix=raw.get("prefix", ""),
        uppercase_names=raw.get("uppercase_names", True),
        output_style=raw.get("output_style", "const"),
        static_const=raw.get("static_const", False),
        typed_ints=raw.get("typed_ints", True),
        protect_target=protect_target,
        parser_options=parser_options,
        renderer_options=raw.get("renderer_options") or {},
        validators=raw.get("validators") or {},
    )


def load_config(config_path: Path | str | None = None) -> ConsyncConfig:
    """Load and validate a .consync.yaml configuration.

    Args:
        config_path: Explicit path to config file. If None, searches
                     upward from CWD.

    Returns:
        Parsed ConsyncConfig.

    Raises:
        FileNotFoundError: If no config file found.
        ValueError: If config is invalid.
    """
    if config_path is None:
        found = find_config()
        if found is None:
            raise FileNotFoundError(
                f"No {DEFAULT_CONFIG_NAME} found. Run 'consync init' to create one."
            )
        config_path = found
    else:
        config_path = Path(config_path)

    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    config_dir = config_path.parent

    with open(config_path) as f:
        raw = yaml.safe_load(f) or {}

    if not isinstance(raw, dict):
        raise ValueError(f"Invalid config: expected a YAML mapping, got {type(raw).__name__}")

    raw_mappings = raw.get("mappings", [])
    if not raw_mappings:
        raise ValueError("Config must have at least one entry in 'mappings'.")

    mappings = [_parse_mapping(m, config_dir) for m in raw_mappings]

    return ConsyncConfig(
        mappings=mappings,
        state_file=raw.get("state_file", ".consync.state.json"),
        watch_debounce=float(raw.get("watch_debounce", 2.0)),
        on_conflict=raw.get("on_conflict", "source_wins"),
    )


def generate_default_config() -> str:
    """Generate a default .consync.yaml template for `consync init`."""
    return """\
# consync configuration — https://github.com/naveenkumarbaskaran/consync
# Sync constants between spreadsheets and source code with full decimal precision.

mappings:
  # ─── Pattern 1: Spreadsheet → Code ───
  # Excel is the source of truth, code is generated from it.
  - source: constants.xlsx          # Where constants are defined (spreadsheet)
    target: include/constants.h     # Generated code file
    direction: both                 # source_to_target | target_to_source | both
    precision: 17                   # Significant digits (17 = full IEEE 754 double)
    header_guard: HW_CONSTANTS_H   # C header include guard

  # ─── Pattern 2: C struct table → Excel ───
  # Existing C file with struct arrays — generate Excel for review/editing.
  # - source: MotorParams.c           # Existing C file with struct array
  #   target: MotorParams.xlsx        # Excel generated from C (created if missing)
  #   direction: both                 # Edit either side, sync keeps them matched
  #   format: c_struct_table          # Parser for #if/#elif struct arrays
  #   variant: all                    # Extract ALL #if/#elif variants (one sheet each)
  #   # table_var: MyStructLUT        # Optional: struct array name (auto-detected)
  #   # fields: [R_Phase, L_d, Psi]   # Optional: field names (auto-detected)
  #   # parser_options:               # Alternative: nest parser keys here
  #   #   variant: all

  # ─── Pattern 3: Code → Spreadsheet (bootstrap) ───
  # - source: params.csv              # Will be created from your existing code
  #   target: legacy/params.h         # Already exists
  #   direction: target_to_source     # First sync creates the CSV from the .h
  #   protect_target: true            # REQUIRED when direction is not 'both'

    # Optional:
    # prefix: ""                    # Prefix all constant names (e.g., "HW_")
    # uppercase_names: true         # Force UPPER_CASE names in output
    # protect_target: true          # Make destination file read-only after sync
    #                               # (mandatory when direction is not 'both')

# Global settings:
# state_file: .consync.state.json   # Track sync state (gitignore this)
# watch_debounce: 2.0               # Seconds to wait before re-syncing
# on_conflict: source_wins          # source_wins | target_wins | fail
"""
