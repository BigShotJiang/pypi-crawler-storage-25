"""Shell test package namespace."""
