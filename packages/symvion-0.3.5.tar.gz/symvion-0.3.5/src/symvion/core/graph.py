import os
import logging
import time
from typing import Dict, List, Any, TypedDict, Annotated, Optional
from typing_extensions import NotRequired
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from symvion.agents.registry import AgentRegistry
from symvion.tools.registry import ToolRegistry
from symvion.config.models import AgentRegistration, TenantConfig
from symvion.core.context import TenantContext
from symvion.core.logger import logger
from symvion.providers.factory import ProviderFactory
from symvion.tools.base import ToolSafetyWrapper
from symvion.utils.helpers import ensure_messages, merge_usage
from symvion.routers.default import KeywordRouter, LLMRouter

class GraphState(TypedDict):
    messages: Annotated[List[BaseMessage], "Conversation messages"]
    tenant_id: str
    conversation_id: str
    current_agent: str
    agent_response: str
    agent_type: str
    tool_calls: List[Dict[str, Any]]
    context: Dict[str, Any]
    cross_sell_opportunity: Dict[str, Any]
    previous_agent: str
    token_usage: NotRequired[Dict[str, Any]]
    summary: NotRequired[str]
    tenant_context: TenantContext # Structured context
    tools_called: NotRequired[bool]

class GraphFactory:
    @staticmethod
    def build_graph(
        tenant_id: str,
        agents: AgentRegistry,
        tools: ToolRegistry,
        tenant_config: TenantConfig
    ) -> StateGraph:
        # Resolve LLM using ProviderFactory
        llm = ProviderFactory.get_provider(tenant_config.llm_provider, tenant_config.llm_config)
        
        workflow = StateGraph(GraphState)
        
        # Router node
        workflow.add_node("router", GraphFactory._create_router_node(llm, agents, tenant_config.router_type))
        
        # Load all agents
        registered_agent_keys = agents.get_all_agent_names()
        for agent_name in registered_agent_keys:
            agent_obj = agents.get_agent(agent_name)
            workflow.add_node(
                f"{agent_name}_agent",
                GraphFactory._create_agent_node(agent_name, agent_obj, llm, tools)
            )

        workflow.add_node("default_agent", GraphFactory._create_default_agent_node(llm, tenant_id, tenant_config, agents))
        workflow.add_node("tool_executor", GraphFactory._create_tool_executor_node(tools))
        workflow.add_node("final_response", GraphFactory._create_final_response_node())

        workflow.set_entry_point("router")

        # Routing edges
        routing_map = {name: f"{name}_agent" for name in registered_agent_keys}
        routing_map["general"] = "default_agent"
        routing_map["tools"] = "tool_executor"
        workflow.add_conditional_edges("router", lambda x: x.get("current_agent", "general"), routing_map)

        # Agent edges
        for name in registered_agent_keys:
            workflow.add_edge(f"{name}_agent", "final_response")
        workflow.add_edge("default_agent", "final_response")
        workflow.add_edge("tool_executor", "final_response")

        workflow.add_edge("final_response", END)
        return workflow.compile()

    @staticmethod
    def _create_router_node(llm, agents: AgentRegistry, router_type: str):
        # Initialize the router based on type
        if router_type == "llm":
            router = LLMRouter(llm)
        else:
            router = KeywordRouter()
            
        async def router_node(state: GraphState, config: RunnableConfig) -> GraphState:
            ctx = state["tenant_context"]
            messages = state["messages"]
            last_message = messages[-1].content if messages and isinstance(messages[-1], HumanMessage) else ""
            
            agent_names = agents.get_all_agent_names()
            
            if router_type == "llm":
                # For LLM routing, we need descriptions
                agent_info = []
                for name in agent_names:
                    agent_obj = agents.get_agent(name)
                    agent_info.append({
                        "name": name,
                        "description": agent_obj.description if hasattr(agent_obj, "description") else "No description available."
                    })
                
                route_result = await router.route(ctx, last_message, agent_info, config=config)
            else:
                # Standard keyword routing
                route_result = await router.route(ctx, last_message, agent_names)
            
            selected_agent = route_result.get("agent", "general")
            usage = route_result.get("token_usage", {})
            
            return {
                **state, 
                "current_agent": selected_agent, 
                "agent_type": selected_agent,
                "token_usage": usage
            }
        return router_node

    @staticmethod
    def _create_agent_node(agent_name: str, agent_obj: Any, llm: Any, tools: ToolRegistry):
        async def agent_node(state: GraphState, config: RunnableConfig) -> GraphState:
            ctx = state["tenant_context"]
            messages = state["messages"]
            
            from symvion.agents.base import BaseAgent
            
            input_data = {
                "message": messages[-1].content if messages else "",
                "history": messages[:-1],
                "context": state.get("context", {})
            }
            
            tools_called = False
            if isinstance(agent_obj, BaseAgent):
                # New v0.3 Agent with Lifecycle and Registry-based Tools
                result = await agent_obj.run(ctx, input_data, tools=tools, config=config)
                response_text = result.get("agent_response", "")
                usage = result.get("token_usage") or result.get("usage_metadata") or result.get("usage") or {}
                tools_called = result.get("tools_called", False)
            else:
                # Legacy / Dynamic Agent support
                logger.info("LEGACY_AGENT_INVOKED", ctx, agent_name=agent_name)
                if hasattr(agent_obj, "process"):
                    # Process takes dict and returns dict
                    res = await agent_obj.process(input_data, config=config)
                    response_text = res.get("agent_response", res.get("content", res.get("response", "")))
                    usage = res.get("token_usage") or res.get("usage_metadata") or res.get("usage") or {}
                    tools_called = res.get("tools_called", False)
                else:
                    # Pure dynamic registration (AgentRegistration model or dict)
                    if isinstance(agent_obj, dict):
                        system_prompt = agent_obj.get("system_prompt", "You are a helpful assistant.")
                    else:
                        system_prompt = getattr(agent_obj, "system_prompt", "You are a helpful assistant.")
                    
                    sys_msg = SystemMessage(content=system_prompt)
                    llm_messages = [sys_msg] + ensure_messages(messages)
                    
                    # Use astream for dynamic agents
                    response_text = ""
                    usage = {}
                    async for chunk in llm.astream(llm_messages, config=config):
                        response_text += chunk.content
                        if hasattr(chunk, "usage_metadata") and chunk.usage_metadata:
                             usage = chunk.usage_metadata
                    
                    tools_called = False

            # Aggregate usage with previous nodes (e.g. router) safely
            current_usage = state.get("token_usage", {})
            merged_usage = merge_usage(current_usage, usage)

            return {
                **state,
                "agent_response": response_text,
                "current_agent": agent_name,
                "agent_type": agent_name,
                "token_usage": merged_usage,
                "tools_called": tools_called,
                "previous_agent": state.get("current_agent", "")
            }
        return agent_node

    @staticmethod
    def _create_default_agent_node(llm, tenant_id, tenant_config, agents: AgentRegistry):
        async def default_agent_node(state: GraphState, config: RunnableConfig) -> GraphState:
            ctx = state["tenant_context"]
            messages = state["messages"]
            
            if tenant_config.system_prompt:
                system_prompt = tenant_config.system_prompt
            else:
                system_prompt = f"You are a general assistant for {tenant_id}. Help with greetings and basic questions."
                
            llm_messages = [SystemMessage(content=system_prompt)] + ensure_messages(messages)
            
            logger.info("DEFAULT_AGENT_INVOKED", ctx)
            
            # Use astream for default agent
            response_text = ""
            usage = {}
            async for chunk in llm.astream(llm_messages, config=config):
                response_text += chunk.content
                if hasattr(chunk, "usage_metadata") and chunk.usage_metadata:
                    usage = chunk.usage_metadata
            
            # Aggregate usage safely
            current_usage = state.get("token_usage", {})
            merged_usage = merge_usage(current_usage, usage)

            return {
                **state,
                "agent_response": response_text,
                "current_agent": "default",
                "agent_type": "default",
                "token_usage": merged_usage
            }
        return default_agent_node

    @staticmethod
    def _create_tool_executor_node(registry):
        async def tool_node(state: GraphState) -> GraphState:
            ctx = state["tenant_context"]
            # Tool execution via Safe Wrapper (Simulated here for breadcrumb)
            logger.info("TOOL_EXECUTOR_INVOKED", ctx)
            return {**state, "agent_response": "Tools execution safety layer active."}
        return tool_node

    @staticmethod
    def _create_final_response_node():
        async def final_node(state: GraphState) -> GraphState:
            return state
        return final_node
