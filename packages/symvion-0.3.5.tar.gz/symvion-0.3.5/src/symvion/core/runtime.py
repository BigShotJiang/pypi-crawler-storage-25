from symvion.config.models import TenantConfig, AgentRegistration
from symvion.agents.registry import AgentRegistry
from symvion.tools.registry import ToolRegistry
from symvion.core.graph import GraphFactory, GraphState
from symvion.memory.memory_store import get_memory_store
from symvion.core.context import TenantContext
from symvion.utils.helpers import ensure_messages, calculate_usage
from symvion.core.logger import logger
from symvion.core.exceptions import AgentExecutionError, RoutingError
from symvion.providers.factory import ProviderFactory
from symvion.core.middleware import MiddlewareChain, PIIMasker, UsageValidator, HallucinationValidator

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from typing import Dict, Any, Optional, Union, List
import time

class Symvion:
    """
    Main entry point for the Symvion AI Orchestration Platform.
    Refactored in v0.3 for production-grade multi-tenancy and observability.
    """
    def __init__(self, config: TenantConfig):
        self.config = config
        self.agents = AgentRegistry(
            tenant_id=self.config.tenant_id, 
            llm_provider=self.config.llm_provider,
            llm_config=self.config.llm_config,
            streaming=self.config.streaming,
            enabled_agents=self.config.enabled_agents,
            agent_configs=self.config.agent_configs
        )
        self.tools = ToolRegistry(iam_policies=self.config.iam_policies)
        self.memory_store = get_memory_store(self.config.tenant_id, self.config.memory)

        self.graph = None
        
        # Apply logging configuration
        logger.configure(
            enabled=self.config.logging.enabled,
            level=self.config.logging.level,
            file_path=self.config.logging.file_path,
            show_json=self.config.logging.show_json
        )

        # Initialize Middleware Chain (Stage 1)
        enabled_mw = self.config.governance.enabled_middleware
        middleware = []
        
        if "pii" in enabled_mw:
            middleware.append(PIIMasker(self.config.governance.pii_patterns))
            
        if "usage" in enabled_mw:
            middleware.append(UsageValidator())
            
        if "policies" in enabled_mw:
            # Convert Pydantic models to dicts for the middleware
            policies_dict = [p.model_dump() for p in self.config.governance.policies]
            from symvion.core.middleware import PolicyMiddleware
            middleware.append(PolicyMiddleware(policies_dict))
            
        if self.config.enable_hallucination_check or "hallucination" in enabled_mw:
            middleware.append(HallucinationValidator(self.config.llm_provider, self.config.llm_config))
            
        self.middleware = MiddlewareChain(middleware)

        logger.info("ENGINE_INITIALIZED", None, tenant_id=self.config.tenant_id)
        
    def register_agent(self, payload: Union[Dict[str, Any], AgentRegistration, Any]):
        """
        Register a new agent. Supports registration dicts, AgentRegistration models, or direct Agent objects.
        """
        if isinstance(payload, dict):
            if "name" in payload and (hasattr(payload.get("agent_class"), "process") or "agent_class" in payload):
                # Custom object registration via dict
                name = payload["name"]
                agent_class = payload.get("agent_class")
                if agent_class:
                    config = self.config.agent_configs.get(name, {})
                    instance = agent_class(self.config.tenant_id, config)
                    self.agents._agents[name] = instance
                    logger.info("CUSTOM_AGENT_REGISTERED", None, tenant_id=self.config.tenant_id, agent_name=name)
                    self.graph = None
                    return
            registration = AgentRegistration(**payload)
        elif isinstance(payload, AgentRegistration):
            registration = payload
        else:
            # Direct object registration (assuming it has a 'name' attribute)
            name = getattr(payload, "name", getattr(payload, "__name__", "unknown"))
            self.agents._agents[name] = payload
            logger.info("DIRECT_AGENT_REGISTERED", None, tenant_id=self.config.tenant_id, agent_name=name)
            self.graph = None
            return
            
        self.agents.register_via_api(registration)
        logger.info("AGENT_REGISTERED", None, tenant_id=self.config.tenant_id, agent_name=registration.name)
        self.graph = None # Require recompile

    async def chat(self, tenant: str, message: str = "", session_id: str = "default", metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Main chat execution entry point with full observability.
        """
        if tenant != self.config.tenant_id:
            raise ValueError(f"Tenant mismatch. Expected {self.config.tenant_id}, got {tenant}")
            
        # Initialize Request Context
        ctx_meta = metadata or {}
        if "user_role" not in ctx_meta:
             ctx_meta["user_role"] = "user"
             
        ctx = TenantContext(
            tenant_id=tenant, 
            metadata={
                **ctx_meta,
                "last_query": message,
                "iam_policies": self.config.iam_policies,
                "token_limit": self.config.token_limit,
                "current_usage": self.config.current_usage
            }
        )
        logger.info("REQUEST_START", ctx, session_id=session_id)
        
        # Run Middleware Preprocessing
        ctx, data = await self.middleware.run_preprocess(ctx, {"message": message})
        message = data["message"]
        
        if not self.graph:
            self.graph = GraphFactory.build_graph(self.config.tenant_id, self.agents, self.tools, self.config)

        # Retrieve session history from memory_store
        session_data = await self.memory_store.get(session_id) or {"history": [], "current_agent": "default", "summary": "", "tools_used": False}
        history = session_data.get("history", [])
        last_agent = session_data.get("current_agent", "default")
        current_summary = session_data.get("summary", "")
        tools_used_in_session = session_data.get("tools_used", False)
        
        # Prepare messages
        current_message = HumanMessage(content=message)
        all_messages = history + [current_message]

        initial_state = GraphState(
            messages=all_messages,
            tenant_id=tenant,
            conversation_id=session_id,
            current_agent=last_agent,
            agent_response="",
            agent_type=last_agent,
            tool_calls=[],
            context={},
            cross_sell_opportunity={},
            previous_agent=last_agent,
            token_usage={"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
            summary=current_summary,
            tenant_context=ctx
        )
        
        try:
            result = await self.graph.ainvoke(
                initial_state,
                config={"metadata": {"tenant_id": tenant, "session_id": session_id}}
            )
        except Exception as e:
            logger.error("REQUEST_FAILED", ctx, error=str(e))
            raise AgentExecutionError(f"Request failed: {str(e)}") from e
        
        # Save updated history (including assistant response)
        summ_happened = False
        if "agent_response" in result and result["agent_response"]:
            new_history = all_messages + [AIMessage(content=result["agent_response"])]
            
            # Check for summarization threshold
            # If tools were used, threshold is 5 (per user request). Otherwise use global config.
            tools_called = result.get("tools_called", False)
            tools_used_in_session = tools_used_in_session or tools_called
            threshold = 5 if tools_used_in_session else self.config.summary_threshold
            
            if len(new_history) >= threshold:
                logger.info("SUMMARIZATION_START", ctx, threshold=threshold, tools_called=tools_called, tools_used_session=tools_used_in_session)
                current_summary = await self._summarize_history(ctx, new_history, current_summary)
                # Clear previous history and put summary as a new entry
                new_history = [SystemMessage(content=f"SUMMARY OF PREVIOUS CONVERSATION: {current_summary}")]
                summ_happened = True
                
            await self.memory_store.set(session_id, {
                "history": new_history,
                "current_agent": result.get("current_agent", "default"),
                "summary": current_summary,
                "tools_used": tools_used_in_session
            })
        
        logger.info("REQUEST_SUCCESS", ctx, agent=result.get("current_agent"))
        
        # Finalize and Postprocess
        final_result = {
            "status": "success", 
            "data": result.get("agent_response", ""),
            "agent": result.get("current_agent", "unknown"),
            "tokens": result.get("token_usage", {}),
            "summarized": summ_happened,
            "request_id": ctx.request_id
        }
        
        final_result = await self.middleware.run_postprocess(ctx, final_result)
        
        return final_result

    async def chat_stream(self, tenant: str, message: str = "", session_id: str = "default", metadata: Optional[Dict[str, Any]] = None):
        """
        Streamed chat execution entry point.
        Yields events/tokens as they happen.
        """
        if tenant != self.config.tenant_id:
            raise ValueError(f"Tenant mismatch. Expected {self.config.tenant_id}, got {tenant}")
            
        ctx_meta = metadata or {}
        if "user_role" not in ctx_meta:
             ctx_meta["user_role"] = "user"

        ctx = TenantContext(
            tenant_id=tenant, 
            metadata={
                **ctx_meta,
                "last_query": message,
                "iam_policies": self.config.iam_policies,
                "token_limit": self.config.token_limit,
                "current_usage": self.config.current_usage
            }
        )
        logger.info("STREAM_REQUEST_START", ctx, session_id=session_id)

        # Run Middleware Preprocessing
        ctx, data = await self.middleware.run_preprocess(ctx, {"message": message})
        message = data["message"]
        
        if not self.graph:
            self.graph = GraphFactory.build_graph(self.config.tenant_id, self.agents, self.tools, self.config)

        session_data = await self.memory_store.get(session_id) or {"history": [], "current_agent": "default", "summary": "", "tools_used": False}
        history = session_data.get("history", [])
        last_agent = session_data.get("current_agent", "default")
        current_summary = session_data.get("summary", "")
        
        current_message = HumanMessage(content=message)
        all_messages = history + [current_message]

        initial_state = GraphState(
            messages=all_messages,
            tenant_id=tenant,
            conversation_id=session_id,
            current_agent=last_agent,
            agent_response="",
            agent_type=last_agent,
            tool_calls=[],
            context={},
            cross_sell_opportunity={},
            previous_agent=last_agent,
            token_usage={"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
            summary=current_summary,
            tenant_context=ctx
        )

        total_usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
        final_result = None
        
        try:
            # Stream events from the graph
            async for event in self.graph.astream_events(
                initial_state,
                version="v2",
                config={"metadata": {"tenant_id": tenant, "session_id": session_id}}
            ):
                kind = event.get("event")
                name = event.get("name")
                data = event.get("data", {})
                
                # Handle chat model tokens
                if kind == "on_chat_model_stream":
                    chunk = data.get("chunk")
                    if chunk:
                        content = ""
                        if hasattr(chunk, "content"):
                            content = chunk.content
                        elif isinstance(chunk, dict):
                            content = chunk.get("content", "")
                        
                        if content:
                            yield {"type": "token", "content": content}
                
                # Aggregate token usage from model endings
                elif kind == "on_chat_model_end":
                    output = data.get("output")
                    usage = None
                    if hasattr(output, "usage_metadata"):
                        usage = output.usage_metadata
                    elif isinstance(output, dict):
                        usage = output.get("usage_metadata")
                    
                    if usage and isinstance(usage, dict):
                        for key in ["input_tokens", "output_tokens", "total_tokens"]:
                            total_usage[key] += usage.get(key, 0)
                
                # Handle node transitions
                elif kind == "on_chain_start" and name and name.endswith("_agent"):
                    yield {"type": "agent_start", "agent": name}
                
                # Handle tool calls
                elif kind == "on_tool_start":
                    yield {
                        "type": "tool_start", 
                        "tool": name, 
                        "inputs": data.get("input")
                    }
                
                # Capture the final state - look for the root chain ending
                if kind == "on_chain_end" and not event.get("parent_ids"):
                    final_result = data.get("output")

            # Finalize and yield metadata
            # Track Usage and Update Persistence
            tokens_used = calculate_usage(total_usage)
            self.config.current_usage += tokens_used
            self.config.save()
            
            logger.info("STREAM_USAGE_METRICS_UPDATED", ctx, tokens_used=tokens_used, total_usage=self.config.current_usage)

            # Finalize and Postprocess
            stream_meta = {
                "type": "metadata", 
                "agent": final_result.get("current_agent", "default") if final_result else "default",
                "tokens": total_usage,
                "total_usage": self.config.current_usage,
                "request_id": ctx.request_id
            }
            
            # Postprocess adds fields like 'hallucination_check'
            stream_meta = await self.middleware.run_postprocess(ctx, stream_meta)
            yield stream_meta
                
            # Replicate memory update logic from chat()
            if final_result and "agent_response" in final_result and final_result["agent_response"]:
                yield {"type": "done", "status": "success"}
                
                # Save updated history (same as chat() method)
                new_history = all_messages + [AIMessage(content=final_result.get("agent_response", ""))]
                await self.memory_store.set(session_id, {
                    "history": new_history,
                    "current_agent": final_result.get("current_agent", "default"),
                    "summary": final_result.get("summary", ""),
                    "tools_used": final_result.get("tools_called", False)
                })
            elif not final_result:
                yield {"type": "error", "message": "Graph reached end without final result"}

        except Exception as e:
            logger.error("CHAT_STREAM_ERROR", ctx, error=str(e), exc_info=True)
            yield {"type": "error", "message": str(e)}


    async def _summarize_history(self, context: TenantContext, history: list, existing_summary: str = "") -> str:
        """Use configured LLM to summarize conversation history."""
        llm = ProviderFactory.get_provider(self.config.llm_provider, {**self.config.llm_config, "temperature": 0})
        
        history_str = "\n".join([f"{'User' if isinstance(m, HumanMessage) else 'AI'}: {m.content}" for m in history])
        
        prompt = f"""Summarize the conversation history concisely. 
        Existing summary: {existing_summary}
        
        CONVERSATION:
        {history_str}
        
        NEW SUMMARY:"""
        
        res = await llm.ainvoke([SystemMessage(content=prompt)])
        return res.content
