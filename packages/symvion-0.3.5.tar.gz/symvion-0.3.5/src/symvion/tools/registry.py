from typing import Callable, Dict, Any, Optional, List
from symvion.tools.base import ToolSafetyWrapper
from symvion.core.context import TenantContext

class ToolRegistry:
    def __init__(self, iam_policies: Optional[Dict[str, List[str]]] = None):
        self._tools: Dict[str, Callable] = {}
        self.iam_policies = iam_policies or {}
        
    def register(self, name: str, func: Callable):
        self._tools[name] = func

    def get_tool(self, name: str) -> Callable:
        if name not in self._tools:
            raise ValueError(f"Tool {name} not found.")
        return self._tools[name]

    async def invoke(self, name: str, context: TenantContext, args: Dict[str, Any], timeout: float = 30.0) -> Any:
        """
        Safely invoke a tool by name using the ToolSafetyWrapper with IAM checks.
        """
        tool_func = self.get_tool(name)
        return await ToolSafetyWrapper.invoke(
            tool_func,
            context,
            name,
            args,
            timeout=timeout,
            iam_policies=self.iam_policies
        )

