from typing import Dict, Any, Optional
from langchain_core.language_models.chat_models import BaseChatModel
import os

class ProviderFactory:
    """
    Factory to initialize LangChain LLM providers.
    Ensures the system is LLM-agnostic.
    """
    
    @staticmethod
    def get_provider(provider_name: str, config: Dict[str, Any]) -> BaseChatModel:
        """
        Initialize and return a LangChain BaseChatModel.
        Uses langchain.chat_models.init_chat_model for universal provider support.
        """
        provider_name = provider_name.lower()
        
        if provider_name == "mock":
            from langchain_core.language_models.chat_models import SimpleChatModel
            from langchain_core.messages import BaseMessage
            from typing import List
            
            class MockChatModel(SimpleChatModel):
                def _call(self, messages: List[BaseMessage], stop: Optional[List[str]] = None, **kwargs: Any) -> str:
                    return "Mock response"
                @property
                def _llm_type(self) -> str:
                    return "mock-chat"

            return MockChatModel()
            
        # Use LangChain's universal initializer
        # This supports: openai, anthropic, google_genai, fireworks, together, groq, etc.
        from langchain.chat_models import init_chat_model
        
        # Blacklist of parameters that are for the platform/agent logic, not for the LLM itself
        BLACKLIST = {"model", "provider", "backend_url", "auth_token", "tenant_id", "fraud_scoring", "system_prompt", "name", "description"}
        
        # Extract model name and remove platform-specific keys to avoid duplication/warnings
        model_name = config.get("model", "gpt-4")
        init_config = {k: v for k, v in config.items() if k not in BLACKLIST}
        
        # Ensure token usage is included in streams if the provider supports it
        if provider_name in ["openai", "anthropic", "google_genai"]:
             if "stream_options" not in init_config:
                 init_config["stream_options"] = {"include_usage": True}
        
        return init_chat_model(
            model=model_name,
            model_provider=provider_name,
            **init_config
        )

    @staticmethod
    def from_env(tenant_id: str) -> BaseChatModel:
        """
        Create a provider from environment variables for a specific tenant.
        """
        provider = os.getenv(f"SYM_PROVIDER_{tenant_id.upper()}", os.getenv("SYM_DEFAULT_PROVIDER", "openai"))
        model = os.getenv(f"SYM_MODEL_{tenant_id.upper()}", os.getenv("LLM_MODEL", "gpt-4"))
        temp = float(os.getenv(f"SYM_TEMP_{tenant_id.upper()}", os.getenv("LLM_TEMPERATURE", "0.7")))
        
        config = {
            "model": model,
            "temperature": temp
        }
        
        return ProviderFactory.get_provider(provider, config)
