"""
AI Runtime application package.
"""
