# Symvion AI Runtime

A multi-tenant AI orchestration framework powered by LangGraph.

## Core Capabilities
Symvion provides a clean, modular Python package that supports:
- Multi-tenant orchestration with isolated contexts
- Dynamic agent registration via APIs (stating payloads and expected responses schemas)
- Abstracted Tool/function calling 
- Observability hooks and state routing via LangGraph

## Installation

```bash
# From the repository root
pip install -e .
```

## Example Usage

```python
import asyncio
from symvion import Symvion, TenantConfig

async def main():
    config = TenantConfig(tenant_id="insurance_corp")
    runtime = Symvion(config=config)
    
    runtime.register_agent({
        "name": "claim_processor",
        "description": "Processes basic insurance claims",
        "system_prompt": "You are a claim processor. Summarize the user's claim.",
        "input_schema": {
            "type": "object",
            "properties": {"claim_text": {"type": "string"}}
        },
        "output_schema": {
            "type": "object",
            "properties": {"summary": {"type": "string"}, "is_valid": {"type": "boolean"}}
        },
        "tools": []
    })
    
    response = await runtime.chat(
        tenant="insurance_corp",
        agent_name="claim_processor",
        payload_data={"claim_text": "I crashed my car on the highway"}
    )
    print("Response:")
    print(response)

if __name__ == "__main__":
    asyncio.run(main())
```
