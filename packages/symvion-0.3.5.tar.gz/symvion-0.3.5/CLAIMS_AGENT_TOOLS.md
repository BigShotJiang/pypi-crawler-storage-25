# Claims Agent Tools

This document outlines the tools needed for the Claims Agent to function effectively.

## Overview

The Claims Agent requires tools to interact with a backend claims API. These tools enable the agent to:
- Submit new claims
- Check claim status
- Retrieve claim details
- Update claims
- List claims
- Upload claim documents
- Calculate claim estimates
- View claim timelines

## Tools Created

### 1. **ClaimsTools Class** (`app/runtime/tools/claims_tools.py`)

A collection of async methods that interact with the backend claims API:

#### Core Tools:

1. **`submit_claim`** - Submit a new insurance claim
   - Parameters: policy_number, incident_date, incident_description, claim_type, estimated_amount, contact_info
   - Returns: Claim ID and initial status

2. **`get_claim_status`** - Get the current status of a claim
   - Parameters: claim_id
   - Returns: Claim status and basic info

3. **`get_claim_details`** - Get full details of a claim
   - Parameters: claim_id
   - Returns: Complete claim information

4. **`update_claim`** - Update an existing claim
   - Parameters: claim_id, updates (dict)
   - Returns: Updated claim information

5. **`list_claims`** - List claims with optional filters
   - Parameters: policy_number, status, claim_type, limit, offset
   - Returns: List of claims with pagination

6. **`upload_claim_document`** - Attach documents to a claim
   - Parameters: claim_id, document_url, document_type, description
   - Returns: Document attachment confirmation

7. **`calculate_claim_estimate`** - Estimate claim amount
   - Parameters: claim_type, incident_description, policy_details
   - Returns: Estimated amount and breakdown

8. **`get_claim_timeline`** - Get claim status history
   - Parameters: claim_id
   - Returns: Timeline of claim events

## Integration with Claims Agent

The tools need to be integrated into the Claims Agent using LangChain's tool binding. This allows the LLM to:
- Automatically decide when to use tools
- Call tools with proper parameters
- Use tool results in its responses

## Backend Requirements

To use these tools, you need to create a **Claims Module** in the backend with the following endpoints:

```
POST   /api/v1/claims                    - Submit new claim
GET    /api/v1/claims                    - List claims (with filters)
GET    /api/v1/claims/:id                - Get claim details
PATCH  /api/v1/claims/:id                - Update claim
GET    /api/v1/claims/:id/status         - Get claim status
GET    /api/v1/claims/:id/timeline       - Get claim timeline
POST   /api/v1/claims/:id/documents      - Upload claim document
POST   /api/v1/claims/estimate           - Calculate claim estimate
```

## Next Steps

1. **Create Backend Claims Module** - Implement the claims API endpoints
2. **Update Claims Agent** - Integrate tools using LangChain tool binding
3. **Test Integration** - Verify tools work correctly with the backend
4. **Add Error Handling** - Improve error messages for better UX
5. **Add Authentication** - Ensure tools use proper tenant isolation

## Example Usage

```python
from app.runtime.tools.claims_tools import get_claims_tools

# Initialize tools
claims_tools = get_claims_tools(tenant_id="tenant-123")

# Submit a claim
result = await claims_tools.submit_claim(
    policy_number="POL-12345",
    incident_date="2024-01-15",
    incident_description="Car accident on highway",
    claim_type="auto"
)

# Get claim status
status = await claims_tools.get_claim_status(result["id"])

# List all claims
all_claims = await claims_tools.list_claims(limit=10)
```
