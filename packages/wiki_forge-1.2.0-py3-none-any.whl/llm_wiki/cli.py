"""Typer CLI for llm-wiki."""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import typer
from rich.console import Console

from llm_wiki.config import Settings
from llm_wiki.fix_links import fix_vault
from llm_wiki.linkback import linkback_vault
from llm_wiki.llm.factory import create_llm
from llm_wiki.pipeline.graph import export_graph_html
from llm_wiki.pipeline.ingest import ingest_source
from llm_wiki.pipeline.ingest_code import ingest_code
from llm_wiki.pipeline.lint import lint_vault
from llm_wiki.pipeline.query import query_wiki
from llm_wiki.vault.paths import Vault

app = typer.Typer(
    help="LLM Wiki — Karpathy-style wiki compiler",
    no_args_is_help=True,
)
console = Console()


def _configure_logging(settings: Settings) -> None:
    logging.basicConfig(
        level=settings.log_level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )


def _load_settings(vault: Path) -> Settings:
    return Settings(vault_root=vault)


def _install_ai_hooks(repo: Path) -> None:
    """Auto-install AI IDE hooks (CLAUDE.md, .cursor/rules, PreToolUse)."""
    try:
        from codegraphcontext.tools.indexing.cgc_wiki_cli import (
            _claude_md_section,
            _cursor_rule,
            _agents_md_section,
            _install_pretool_hook,
            _detect_platform,
        )
    except ImportError:
        return  # CGC not installed, skip

    platform = _detect_platform()

    if platform == "claude":
        # CLAUDE.md
        claude_md = repo / "CLAUDE.md"
        section = _claude_md_section()
        if claude_md.exists():
            content = claude_md.read_text()
            if "cgc-wiki" not in content:
                claude_md.write_text(content + "\n\n" + section)
                console.print("  [green]✓[/green] CLAUDE.md updated")
        else:
            claude_md.write_text(section)
            console.print("  [green]✓[/green] CLAUDE.md created")

        # PreToolUse hook
        settings_path = Path.home() / ".claude" / "settings.json"
        _install_pretool_hook(settings_path)
        console.print("  [green]✓[/green] PreToolUse hook installed")

    elif platform == "cursor":
        rules_dir = repo / ".cursor" / "rules"
        rules_dir.mkdir(parents=True, exist_ok=True)
        rule_file = rules_dir / "cgc-wiki.mdc"
        if not rule_file.exists() or "cgc-wiki" not in rule_file.read_text():
            rule_file.write_text(_cursor_rule())
            console.print("  [green]✓[/green] .cursor/rules/cgc-wiki.mdc created")

    else:
        # Codex / Generic → AGENTS.md
        agents_md = repo / "AGENTS.md"
        section = _agents_md_section()
        if agents_md.exists():
            content = agents_md.read_text()
            if "cgc-wiki" not in content:
                agents_md.write_text(content + "\n\n" + section)
                console.print("  [green]✓[/green] AGENTS.md updated")
        else:
            agents_md.write_text(section)
            console.print("  [green]✓[/green] AGENTS.md created")


@app.command()
def init(
    repo: Path = typer.Argument(Path.cwd(), help="Repository / vault root directory"),
    cgc: bool = typer.Option(False, "--cgc", help="Enable CGC code intelligence (DuckDB)"),
    no_llm: bool = typer.Option(False, "--no-llm", help="Index code only (CGC), skip LLM doc generation"),
    cgc_grouping: bool = typer.Option(False, "--cgc-grouping", help="Use CGC deterministic module grouping (0 LLM tokens)"),
):
    """Initialize wiki for a repository — index code + generate docs.

    Examples:
      llm-wiki init                  # init + LLM docs for current dir
      llm-wiki init --cgc            # with CGC code intelligence
      llm-wiki init --cgc --no-llm   # CGC index only (free, no LLM cost)
      llm-wiki init /path/to/repo    # specify repo path
    """
    import json

    repo = repo.resolve()
    v = Vault(repo)
    v.init_dirs()
    if not v.overview.exists():
        v.overview.write_text(
            "---\ntitle: Overview\ntype: synthesis\nsources: []\n---\n\n# Overview\n\n(empty)\n",
            encoding="utf-8",
        )
    if not v.index.exists():
        v.index.write_text(
            "# Wiki Index\n\n## Overview\n- [Overview](overview.md)\n\n"
            "## Sources\n\n## Entities\n\n## Concepts\n\n## Syntheses\n",
            encoding="utf-8",
        )
    console.print(f"[green]✓[/green] Initialized vault at {v.root}")

    # Auto-detect source files → run ingest-code
    _CODE_EXTS = ("*.py", "*.ts", "*.tsx", "*.js", "*.java", "*.go", "*.rs",
                  "*.rb", "*.php", "*.kt", "*.cs", "*.cpp", "*.c", "*.swift")
    _SKIP = {"node_modules", ".venv", "venv", "target", "dist", "build", ".git"}
    src_files = []
    for ext in _CODE_EXTS:
        for f in repo.rglob(ext):
            if not any(s in f.parts for s in _SKIP):
                src_files.append(f)
                if len(src_files) > 5:
                    break  # enough to confirm source exists
        if len(src_files) > 5:
            break
    if not src_files:
        console.print("[dim]No source files found — vault ready for manual ingest[/dim]")
        _register_vault(repo)
        return

    console.print(f"[cyan]Source files detected — indexing...[/cyan]")

    if no_llm:
        # CGC index only (free, no LLM)
        if cgc:
            try:
                from llm_wiki.code.cgc_bridge import CGCBridge
                bridge = CGCBridge(repo)
                if not bridge.available:
                    console.print("[cyan]Indexing codebase...[/cyan]")
                    bridge.auto_index()
                if bridge.available:
                    stats = bridge.get_all_stats()
                    console.print(f"[green]✓[/green] CGC index ready")
                    console.print(f"  Files: {stats.get('files', 0)}")
                    console.print(f"  Functions: {stats.get('functions', 0)}")
                    console.print(f"  CALLS edges: {stats.get('call_edges', 0)}")
                    _install_ai_hooks(repo)
                    bridge.close()
                    console.print(f"\n  Type [bold]/wiki[/bold] in your AI assistant to generate docs.")
                else:
                    console.print(f"[yellow]⚠ {bridge.init_error}[/yellow]")
            except Exception as e:
                console.print(f"[yellow]⚠ CGC index failed: {e}[/yellow]")
        else:
            console.print("[dim]--no-llm without --cgc: nothing to do (use --cgc for free code index)[/dim]")
        _register_vault(repo)
        return

    # Full pipeline: CGC index + LLM doc generation
    settings = _load_settings(repo)
    if cgc:
        settings.cgc_enabled = True
    _configure_logging(settings)

    async def run():
        llm = create_llm(settings)
        try:
            result = await ingest_code(
                repo_path=repo,
                vault_root=repo,
                llm=llm,
                settings=settings,
                use_cgc_grouping=cgc_grouping,
            )
            return result
        finally:
            await llm.close()

    result = asyncio.run(run())
    console.print(f"\n[green]✓[/green] Wiki generated: {result.get('modules', 0)} modules")
    _register_vault(repo)


# ── Global registry ──────────────────────────────────────────────────────────

REGISTRY_PATH = Path.home() / ".llm-wiki" / "registry.json"


def _load_registry() -> dict:
    """Load global vault registry."""
    if REGISTRY_PATH.exists():
        import json
        return json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    return {}


def _save_registry(reg: dict) -> None:
    """Save global vault registry."""
    import json
    REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    REGISTRY_PATH.write_text(json.dumps(reg, indent=2, default=str), encoding="utf-8")


def _register_vault(vault_path: Path) -> None:
    """Register a vault in global registry."""
    from datetime import datetime
    reg = _load_registry()
    key = str(vault_path.resolve())
    wiki_dir = vault_path / "wiki"
    page_count = len(list(wiki_dir.rglob("*.md"))) if wiki_dir.exists() else 0
    reg[key] = {
        "name": vault_path.name,
        "pages": page_count,
        "indexed_at": datetime.now().isoformat(),
    }
    _save_registry(reg)
    console.print(f"[dim]Registered in ~/.llm-wiki/registry.json[/dim]")


@app.command("register")
def cmd_register(
    vault: Path = typer.Argument(Path.cwd(), help="Vault directory to register"),
):
    """Register a vault in global registry (for MCP auto-discover)."""
    vault = vault.resolve()
    wiki_dir = vault / "wiki"
    if not wiki_dir.exists():
        console.print(f"[red]✗[/red] No wiki/ folder found at {vault}")
        console.print("[dim]Run 'llm-wiki init' first[/dim]")
        raise typer.Exit(1)
    _register_vault(vault)
    console.print(f"[green]✓[/green] Registered: {vault.name}")


@app.command("list")
def cmd_list():
    """List all registered vaults."""
    reg = _load_registry()
    if not reg:
        console.print("[dim]No vaults registered. Run 'llm-wiki init' in a repo.[/dim]")
        return
    console.print(f"[bold]Registered vaults ({len(reg)}):[/bold]\n")
    for path, info in reg.items():
        name = info.get("name", "?")
        pages = info.get("pages", 0)
        when = info.get("indexed_at", "?")[:16]
        exists = "✓" if Path(path).exists() else "✗"
        console.print(f"  {exists} [bold]{name}[/bold] ({pages} pages) — {path}")
        console.print(f"    indexed: {when}")


@app.command("update")
def cmd_update(
    repo: Path = typer.Argument(Path.cwd(), help="Repository root"),
    cgc: bool = typer.Option(False, "--cgc", help="Enable CGC code intelligence"),
):
    """Update wiki for changed files only (incremental).

    Examples:
      llm-wiki update              # update current dir
      llm-wiki update --cgc        # with CGC enrichment
    """
    repo = repo.resolve()
    v = Vault(repo)
    if not v.wiki_root.exists():
        console.print(f"[red]✗[/red] No wiki/ found at {repo}. Run 'llm-wiki init' first.")
        raise typer.Exit(1)

    settings = _load_settings(repo)
    if cgc:
        settings.cgc_enabled = True
    _configure_logging(settings)

    async def run():
        llm = create_llm(settings)
        try:
            result = await ingest_code(
                repo_path=repo,
                vault_root=repo,
                llm=llm,
                settings=settings,
                update=True,
            )
            return result
        finally:
            await llm.close()

    result = asyncio.run(run())
    console.print(f"\n[green]✓[/green] Update complete: {result.get('modules', 0)} modules")
    _register_vault(repo)


@app.command()
def ingest(
    source: Path = typer.Argument(..., help="Source file to ingest"),
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    update: bool = typer.Option(
        False, "--update", "-u",
        help="Skip if source file hash is unchanged since last ingest.",
    ),
):
    """Ingest a source file into the wiki."""
    settings = _load_settings(vault)
    _configure_logging(settings)
    v = Vault(vault)

    async def run():
        llm = create_llm(settings)
        try:
            result = await ingest_source(source, v, llm, settings, update=update)
            if result.skipped:
                console.print(f"[dim]– Skipped (unchanged):[/dim] {source.name}")
                return
            console.print(f"[green]✓[/green] Ingested: {result.title}")
            console.print(f"  Slug: {result.slug}")
            console.print(f"  Entities: {len(result.entity_pages)}")
            console.print(f"  Concepts: {len(result.concept_pages)}")
            console.print(f"  Tokens: {result.input_tokens} in / {result.output_tokens} out")
            if result.contradictions:
                console.print("[yellow]⚠ Contradictions detected:[/yellow]")
                for c in result.contradictions:
                    console.print(f"  - {c}")
        finally:
            await llm.close()

    asyncio.run(run())


@app.command()
def query(
    question: str = typer.Argument(..., help="Question to ask the wiki"),
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    save: bool = typer.Option(False, "--save", help="Save answer to syntheses/"),
):
    """Ask a question against the wiki."""
    settings = _load_settings(vault)
    _configure_logging(settings)
    v = Vault(vault)

    async def run():
        llm = create_llm(settings)
        try:
            result = await query_wiki(question, v, llm, settings, save=save)
            console.print(f"[bold]Sources[/bold] ({len(result.sources)}):")
            for p in result.sources:
                console.print(f"  - {p.relative_to(v.root)}")
            console.print()
            console.print(result.answer, markup=False)
        finally:
            await llm.close()

    asyncio.run(run())


@app.command()
def lint(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
):
    """Run structural lint on the wiki."""
    v = Vault(vault)
    report = lint_vault(v)
    console.print(f"[bold]{report.summary()}[/bold]")

    if report.orphans:
        console.print(f"\n[yellow]Orphans ({len(report.orphans)}):[/yellow]")
        for p in report.orphans[:10]:
            console.print(f"  - {p.relative_to(v.root)}")
        if len(report.orphans) > 10:
            console.print(f"  ... and {len(report.orphans) - 10} more")

    if report.broken_links:
        console.print(f"\n[red]Broken links ({len(report.broken_links)}):[/red]")
        for page, link in report.broken_links[:10]:
            console.print(f"  - {page.name}: [[{link}]]")

    if report.missing_entities:
        console.print(f"\n[cyan]Missing entities ({len(report.missing_entities)}):[/cyan]")
        for name, count in report.missing_entities[:10]:
            console.print(f"  - {name} ({count} mentions)")


@app.command("semantic-lint")
def cmd_semantic_lint(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
):
    """Run LLM-powered semantic lint: find contradictions, stale info, missing pages."""
    from llm_wiki.pipeline.lint import semantic_lint

    settings = _load_settings(vault)
    _configure_logging(settings)
    v = Vault(vault)

    async def run():
        llm = create_llm(settings)
        try:
            return await semantic_lint(v, llm, model=settings.heavy_model)
        finally:
            await llm.close()

    report = asyncio.run(run())
    console.print(f"[bold]{report.summary()}[/bold]")
    console.print(f"  Tokens: {report.input_tokens} in / {report.output_tokens} out")

    for issue in report.issues:
        color = "yellow" if issue.severity == "warning" else "cyan"
        console.print(f"\n[{color}][{issue.issue_type}] {issue.title}[/{color}]")
        console.print(f"  {issue.detail}")
        if issue.affected_pages:
            console.print(f"  Pages: {', '.join(issue.affected_pages)}")


@app.command("reviews")
def cmd_reviews(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    status: str = typer.Option("open", help="Filter by status: open/approved/dismissed/all"),
):
    """Show review items flagged by LLM during ingest."""
    from llm_wiki.pipeline.review import ReviewStore
    store = ReviewStore(vault)
    filter_status = None if status == "all" else status
    items = store.all(status=filter_status)

    console.print(f"[bold]Reviews: {store.open_count} open / {store.total_count} total[/bold]")
    for item in items:
        color = {
            "contradiction": "red",
            "duplicate": "yellow",
            "missing-page": "cyan",
            "suggestion": "green",
        }.get(item.review_type, "white")
        console.print(f"\n[{color}][{item.review_type}][/{color}] {item.title}")
        console.print(f"  {item.detail[:200]}")
        if item.affected_pages:
            console.print(f"  Pages: {', '.join(item.affected_pages)}")
        console.print(f"  Status: {item.status} | Created: {item.created}")


@app.command("drift")
def cmd_drift(
    repo: Path = typer.Argument(..., help="Path to the source repository"),
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    extensions: str = typer.Option("", "--extensions", "-e", help="Comma-separated extensions"),
    semantic: bool = typer.Option(False, "--semantic", help="Enable LLM semantic checks (costs tokens)"),
):
    """Detect code-doc drift: find contradictions between code and wiki.

    Without --semantic: fast structural checks only (no LLM cost).
    With --semantic: adds LLM-powered contradiction detection.
    """
    from llm_wiki.pipeline.drift import detect_drift, detect_drift_structural

    settings = _load_settings(vault)
    _configure_logging(settings)
    v = Vault(vault)
    ext_list = [e.strip() for e in extensions.split(",") if e.strip()] or None

    _COLORS = {
        "code_changed": "yellow", "doc_stale": "yellow", "config_drift": "yellow",
        "contradiction": "red", "wiki_conflict": "red",
        "deleted_ref": "red", "missing_doc": "cyan",
    }

    if semantic:
        async def run():
            llm = create_llm(settings)
            try:
                report = await detect_drift(v, repo, llm, model=settings.heavy_model, extensions=ext_list)
                _print_drift(report)
            finally:
                await llm.close()
        asyncio.run(run())
    else:
        report = detect_drift_structural(v, repo, extensions=ext_list)
        _print_drift(report)

def _print_drift(report):
    from llm_wiki.pipeline.drift import DriftReport
    _COLORS = {
        "code_changed": "yellow", "doc_stale": "yellow", "config_drift": "yellow",
        "contradiction": "red", "wiki_conflict": "red",
        "deleted_ref": "red", "missing_doc": "cyan",
    }
    console.print(f"[bold]{report.summary()}[/bold]")
    for item in report.items:
        color = _COLORS.get(item.drift_type, "white")
        sev = "⚠" if item.severity == "warning" else "ℹ"
        console.print(f"\n{sev} [{color}][{item.drift_type}][/{color}] {item.title}")
        console.print(f"  {item.detail[:300]}")
        if item.code_files:
            console.print(f"  Files: {', '.join(item.code_files[:5])}")
        if item.wiki_pages:
            console.print(f"  Wiki: {', '.join(item.wiki_pages[:5])}")


@app.command("enrich")
def cmd_enrich(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    max_pages: int = typer.Option(50, "--max-pages", help="Max pages to enrich"),
):
    """Add missing [[wikilinks]] to existing pages via LLM."""
    from llm_wiki.pipeline.enrich import enrich_wikilinks

    settings = _load_settings(vault)
    _configure_logging(settings)
    v = Vault(vault)

    async def run():
        llm = create_llm(settings)
        try:
            count = await enrich_wikilinks(v, llm, model=settings.heavy_model, max_pages=max_pages)
            console.print(f"[green]✓[/green] Enriched {count} pages with new wikilinks")
        finally:
            await llm.close()

    asyncio.run(run())


@app.command("fix-links")
def cmd_fix_links(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    apply: bool = typer.Option(False, "--apply", help="Write changes to disk"),
):
    """Fix broken wikilinks in the wiki (fuzzy match + strip)."""
    v = Vault(vault)
    stats = fix_vault(v, apply=apply)
    mode = "APPLY" if apply else "DRY-RUN"
    console.print(f"[bold]{mode}[/bold]")
    console.print(f"  Kept valid:     {stats.get('kept', 0)}")
    console.print(f"  Fuzzy-fixed:    {stats.get('fixed', 0)}")
    console.print(f"  Stripped:       {stats.get('stripped', 0)}")
    console.print(f"  Sources linked: {stats.get('sources_linked', 0)}")
    if not apply:
        console.print("\n[dim](re-run with --apply to write changes)[/dim]")


@app.command("linkback")
def cmd_linkback(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    apply: bool = typer.Option(False, "--apply", help="Write changes to disk"),
):
    """Rewrite plain-text mentions of orphan pages as wikilinks."""
    v = Vault(vault)
    stats = linkback_vault(v, apply=apply)
    mode = "APPLY" if apply else "DRY-RUN"
    console.print(f"[bold]{mode}[/bold]")
    console.print(f"  Orphans before: {stats['orphans_before']}")
    console.print(f"  Rewrites:       {stats['rewrites']}")
    if apply:
        console.print(f"  Orphans after:  {stats['orphans_after']}")
    if not apply:
        console.print("\n[dim](re-run with --apply to write changes)[/dim]")


@app.command("ingest-code")
def cmd_ingest_code(
    repo: Path = typer.Argument(..., help="Path to the source repository to analyse"),
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v", help="Vault root directory"),
    update: bool = typer.Option(False, "--update", "-u", help="Only regenerate changed files"),
    extensions: str = typer.Option("", "--extensions", "-e", help="Comma-separated extensions, e.g. .py,.ts"),
    output_dir: str = typer.Option("", "--output-dir", help="Output subdirectory inside vault"),
    project_name: str = typer.Option("", "--project-name", "-n", help="Override project name in generated docs"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show plan without writing files"),
    cgc: bool = typer.Option(False, "--cgc", help="Enable CodeGraphContext augmentation (richer call graph, operational params)"),
):
    """Analyse a code repository and generate wiki documentation (Code-to-Doc)."""
    if not repo.exists():
        console.print(f"[red]✗ Repository path not found: {repo}[/red]")
        raise typer.Exit(1)

    settings = _load_settings(vault)
    if cgc:
        settings.cgc_enabled = True
    _configure_logging(settings)

    ext_list = [e.strip() for e in extensions.split(",") if e.strip()] or None
    out_subdir = output_dir or settings.code_output_subdir

    async def run():
        llm = create_llm(settings)
        try:
            result = await ingest_code(
                repo_path=repo,
                vault_root=vault,
                llm=llm,
                settings=settings,
                update=update,
                extensions=ext_list,
                output_subdir=out_subdir,
                dry_run=dry_run,
                project_name=project_name or None,
            )
        finally:
            await llm.close()
        return result

    result = asyncio.run(run())

    mode = "[dim](dry-run)[/dim] " if dry_run else ""
    console.print(f"\n[green]✓[/green] {mode}Code-to-Doc complete")
    console.print(f"  Repo:    {repo.resolve()}")
    console.print(f"  Modules: {len(result.modules)}")
    for g in result.modules:
        console.print(f"    • {g.name} ({len(g.files)} files) → {g.slug}.md")
    if result.skipped_files:
        console.print(f"  Skipped: {len(result.skipped_files)} unchanged files")
    if result.token_usage:
        total = result.token_usage.get("total", 0)
        console.print(f"  Tokens:  {total:,}")
    if cgc:
        if result.token_usage.get("cgc_active"):
            console.print("  CGC:     [green]active[/green] (enriched call graph + operational params)")
        else:
            console.print("  CGC:     [yellow]unavailable[/yellow] (fell back to built-in extractor)")
        cgc_warnings = result.token_usage.get("cgc_warnings", [])
        if cgc_warnings:
            for w in cgc_warnings:
                console.print(f"  [yellow]⚠ CGC: {w}[/yellow]")
    if not dry_run:
        console.print(f"  Output:  {vault / out_subdir}/")


@app.command("unify")
def cmd_unify(
    project: list[str] = typer.Option(..., "--project", "-p", help="name:vault_path pairs (e.g. backend:./vault-be)"),
    output: Path = typer.Option("unified-wiki", "--output", "-o", help="Output unified vault path"),
    no_llm: bool = typer.Option(False, "--no-llm", help="Skip LLM overview generation"),
):
    """Merge multiple project vaults into one unified wiki.

    Example:
        llm-wiki unify \\
          -p tms-backend:./test-eval-backend \\
          -p tms-frontend:./test-eval-frontend \\
          -p confluence:./test-eval-confluence \\
          -o unified-wiki
    """
    from llm_wiki.pipeline.unify import ProjectSource, unify_vaults

    settings = _load_settings(output)
    _configure_logging(settings)

    # Parse project specs
    projects: list[ProjectSource] = []
    for spec in project:
        if ":" not in spec:
            console.print(f"[red]Invalid project spec: {spec} (use name:vault_path)[/red]")
            raise typer.Exit(1)
        name, vault_path = spec.split(":", 1)
        projects.append(ProjectSource(name=name.strip(), vault_path=Path(vault_path.strip())))

    async def run():
        llm = None
        if not no_llm:
            llm = create_llm(settings)
        try:
            result = await unify_vaults(projects, output, llm=llm, model=settings.heavy_model)
            console.print(f"[green]✓[/green] Unified wiki created at {output}")
            console.print(f"  Projects merged: {result.projects_merged}")
            console.print(f"  Pages copied: {result.pages_copied}")
            console.print(f"  Pages deduplicated: {result.pages_deduplicated}")
            console.print(f"  Cross-links added: {result.cross_links_added}")
            console.print(f"  Overview: {'generated' if result.overview_generated else 'template'}")
        finally:
            if llm:
                await llm.close()

    asyncio.run(run())


@app.command("serve")
def cmd_serve(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    host: str = typer.Option("127.0.0.1", "--host", help="Bind host"),
    port: int = typer.Option(5757, "--port", "-p", help="Bind port"),
    static_dir: Path = typer.Option(None, "--static", help="Path to built Preact UI dist/ folder"),
):
    """Start the llm-wiki web server (sage-wiki UI + REST/SSE API). No extra LLM calls for UI."""
    import uvicorn

    from llm_wiki.server import create_app

    settings = _load_settings(vault)
    _configure_logging(settings)

    # Auto-detect sage-wiki dist relative to this package
    if static_dir is None:
        candidates = [
            # Bundled inside package (src/llm_wiki/static/)
            Path(__file__).parent / "static",
            # Development: monorepo layout
            Path(__file__).parents[3] / "sage-wiki" / "internal" / "web" / "dist",
            Path(__file__).parents[4] / "sage-wiki" / "internal" / "web" / "dist",
            Path(__file__).parents[4] / "example" / "sage-wiki" / "internal" / "web" / "dist",
            Path(__file__).parents[5] / "example" / "sage-wiki" / "internal" / "web" / "dist",
        ]
        for c in candidates:
            if c.exists() and (c / "index.html").exists():
                static_dir = c
                break

    app = create_app(
        vault_root=Path(vault).resolve(),
        gemini_api_key=settings.gemini_api_key,
        static_dir=static_dir,
    )

    url = f"http://{host}:{port}"
    console.print(f"[green]✓[/green] llm-wiki server starting at [bold]{url}[/bold]")
    console.print(f"  Vault: {Path(vault).resolve()}")
    if static_dir and static_dir.exists():
        console.print(f"  UI:    {url}/wiki/")
    else:
        console.print("[yellow]  UI:    not found — API only (pass --static path/to/dist)[/yellow]")
    console.print("  Press Ctrl+C to stop\n")

    uvicorn.run(app, host=host, port=port, log_level="warning")


@app.command("mcp")
def cmd_mcp(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v", help="Vault root directory"),
):
    """Start the MCP server (stdio) for use with Claude Desktop / Cursor.

    Add to claude_desktop_config.json:

    \b
    {
      "mcpServers": {
        "llm-wiki": {
          "command": "llm-wiki",
          "args": ["mcp", "--vault", "/path/to/vault"]
        }
      }
    }
    """
    from llm_wiki.mcp_server import run_mcp_server

    settings = _load_settings(vault)
    _configure_logging(settings)
    asyncio.run(run_mcp_server(Path(vault).resolve(), settings))


@app.command("graph")
def cmd_graph(
    vault: Path = typer.Option(Path.cwd(), "--vault", "-v"),
    output: Path = typer.Option(None, "--output", "-o", help="Output HTML path (default: wiki/graph.html)"),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open in browser after generating"),
):
    """Generate an interactive D3.js graph view of wiki wikilinks. No LLM calls."""
    import webbrowser

    v = Vault(vault)
    out = export_graph_html(v, output)

    from llm_wiki.pipeline.graph import build_graph
    g = build_graph(v)
    console.print(f"[green]✓[/green] Graph generated: {out}")
    console.print(f"  Nodes: {g.node_count}")
    console.print(f"  Edges: {g.edge_count}")

    if open_browser:
        webbrowser.open(out.as_uri())


if __name__ == "__main__":
    app()
