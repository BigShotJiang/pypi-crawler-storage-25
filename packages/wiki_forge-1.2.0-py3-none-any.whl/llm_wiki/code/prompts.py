"""LLM prompt templates for the Code-to-Doc 3-phase pipeline."""
from __future__ import annotations

import re

from llm_wiki.code.models import CodeFileMeta, ModuleGroup

# ── Phase 1: GROUPING ─────────────────────────────────────────────────────────

GROUPING_SYSTEM = (
    "You are a documentation architect. Given a list of source files with their "
    "exported symbols, group them into logical documentation modules.\n\n"
    "Rules:\n"
    "- Each module should represent a cohesive feature, layer, or domain\n"
    "- Every file must appear in exactly one module\n"
    "- Module names should be human-readable (e.g. \"Authentication\", \"Database Layer\", \"API Routes\")\n"
    "- Aim for 5-15 modules for a typical project; fewer for small projects\n"
    "- Group by functionality, not by file type or directory structure alone\n"
    "- Do NOT create modules for tests, config-only files, or non-source files"
)

GROUPING_USER = """\
Group these source files into documentation modules.

**Files and their exported symbols:**
{file_list}

**Directory structure:**
{directory_tree}

Respond with ONLY a JSON object mapping module names to file path arrays.
No markdown fences, no explanation, no extra keys.

Example format:
{{
  "Authentication": ["src/auth/login.py", "src/auth/session.py"],
  "Database Layer": ["src/db/connection.py", "src/db/models.py"]
}}
"""

# ── Phase 2: MODULE_DOC ───────────────────────────────────────────────────────

MODULE_SYSTEM = (
    "You are a technical documentation writer. Write clear, developer-focused "
    "documentation for a code module.\n\n"
    "Rules:\n"
    "- Output ONLY the documentation content — no meta-commentary\n"
    "- Start directly with the module heading and content\n"
    "- Reference actual function and class names — do NOT invent APIs\n"
    "- Include a Mermaid diagram only when it genuinely helps understanding (max 8 nodes)\n"
    "- Structure the document however makes sense for this module\n"
    "- Write for a developer who needs to understand and contribute to this code"
)

MODULE_USER = """\
Write documentation for the **{module_name}** module.

## Source Files

{file_list}

## Exported Symbols

{symbol_list}

## Source Code

{source_code}

## Call Graph (use for accuracy — do NOT list every edge mechanically)

Internal calls (within this module):
{intra_calls}

Outgoing calls (this module calls into):
{outgoing_calls}

Incoming calls (other modules call into this one):
{incoming_calls}

## Other modules in this project

{other_modules}

---

Write comprehensive documentation for this module. Cover its purpose, how it works,
its key components, and how it connects to the rest of the codebase.
Use the call graph to accurately describe data flow and dependencies — but synthesize it
naturally into prose, do NOT mechanically list every edge.
Use whatever structure best fits — you decide the sections and headings.
Include a Mermaid diagram only if it genuinely clarifies the architecture.

IMPORTANT: When you mention another module from the "Other modules" list above, link to it
using wikilink syntax: [[module-slug]] (e.g. [[pipeline]], [[configuration]], [[core-models]]).
The slug is the module name lowercased with spaces replaced by hyphens.
"""

# ── Phase 2 (CGC-augmented): MODULE_DOC with enriched context ─────────────────

MODULE_USER_CGC = """\
Write documentation for the **{module_name}** module.

## Source Files

{file_list}

## Exported Symbols

{symbol_list}

## Function Signatures (with types and decorators)

{function_signatures}

## Class Hierarchy

{class_hierarchy}

## Source Code

{source_code}

## Call Graph (use for accuracy — do NOT list every edge mechanically)

Internal calls (within this module):
{intra_calls}

Outgoing calls (this module calls into):
{outgoing_calls}

Incoming calls (other modules call into this one):
{incoming_calls}

## API Routes / Endpoints

{api_routes}

## Execution Flows (what happens when key functions are called)

{execution_flows}

## Design Rationale (WHY comments, NOTEs, HACKs, TODOs from source code)

{design_rationale}

## Operational Parameters (cron schedules, timeouts, retry counts, env vars, constants)

{operational_params}

## Other modules in this project

{other_modules}

---

Write comprehensive documentation for this module. Cover its purpose, how it works,
its key components, and how it connects to the rest of the codebase.

IMPORTANT additional instructions:
- The "Operational Parameters" section above is CRITICAL. You MUST create a dedicated
  "Configuration & Operational Parameters" section containing a table with EVERY SINGLE
  entry from that section — do NOT skip or summarize any. For each entry, include:
  name | value (exact, copy verbatim) | purpose | source file.
  Pay special attention to:
  * Cron schedules: list EVERY cron() entry with its exact minute/hour values and
    human-readable interval (e.g. "every 3 minutes", "daily at 2 AM")
  * Class source that contains config (e.g. WorkerSettings): extract ALL attributes
    including functions list, cron_jobs list, redis_settings, max_jobs, timeouts
  * Constants: TIMEOUT, MAX_*, COOLDOWN, BATCH_SIZE, etc.
- Use the class hierarchy to accurately describe inheritance relationships.
- Use the function signatures to mention parameter types and decorators accurately.
- Use the call graph to accurately describe data flow and dependencies — but synthesize it
  naturally into prose, do NOT mechanically list every edge.
- The "Design Rationale" section contains WHY/NOTE/HACK/TODO comments from the actual source code.
  These explain the reasoning behind design decisions. Include them in your documentation — they
  answer "why was it done this way?" which is the most valuable information for developers.
- The "Execution Flows" section shows what happens when key entry points are called (step-by-step
  call chains). Use these to write a "How It Works" or "Request Flow" section that explains
  the actual execution path. This is the most valuable information for developers onboarding.
- Use whatever structure best fits — you decide the sections and headings.
- Include a Mermaid diagram only if it genuinely clarifies the architecture.

IMPORTANT: When you mention another module from the "Other modules" list above, link to it
using wikilink syntax: [[module-slug]] (e.g. [[pipeline]], [[configuration]], [[core-models]]).
The slug is the module name lowercased with spaces replaced by hyphens.
"""

# ── Phase 2.5: PARENT HIERARCHY ───────────────────────────────────────────────

PARENT_GROUPING_SYSTEM = (
    "You are a documentation architect. Organize a set of code module pages "
    "into a 2-level hierarchy by grouping related modules under parent categories.\n\n"
    "Rules:\n"
    "- Create 3-7 parent categories that reflect architectural layers or domains\n"
    "- Every module must appear in exactly one parent\n"
    "- Parent names should be broad and human-readable (e.g. 'Core', 'Pipeline', 'Storage')\n"
    "- Do NOT create a parent with only one child — merge small groups\n"
    "- Respond with ONLY a JSON object: { parent_name: [module_slug, ...] }"
)

PARENT_GROUPING_USER = """\
Group these {n_modules} documentation modules into parent categories.

**Modules (slug: name):**
{module_list}

Respond with ONLY a JSON object mapping parent names to arrays of module slugs.
No markdown fences, no explanation.

Example:
{{
  "Core": ["config", "models", "exceptions"],
  "Pipeline": ["ingest", "query", "search"]
}}
"""

PARENT_DOC_SYSTEM = (
    "You are a technical documentation writer. Write a high-level overview page "
    "for a group of related code modules.\n\n"
    "Rules:\n"
    "- Output ONLY the documentation content — no meta-commentary\n"
    "- Start directly with a heading for the parent group\n"
    "- Synthesize from the module summaries — do NOT repeat low-level implementation details\n"
    "- Focus on the shared responsibility and how the modules work together\n"
    "- Keep it concise: 200-400 words\n"
    "- Link to child module pages using [[slug]] wikilinks"
)

PARENT_DOC_USER = """\
Write an overview page for the **{parent_name}** group of modules.

## Child Modules

{child_summaries}

---

Write a brief overview explaining what this group of modules does,
how the child modules relate to each other, and how this group fits into the larger project.
Link to each child module using [[slug]] wikilinks (e.g. [[pipeline]], [[config]]).
"""


# ── Phase 3: OVERVIEW ─────────────────────────────────────────────────────────

OVERVIEW_SYSTEM = (
    "You are a technical documentation writer. Write the top-level overview page "
    "for a repository wiki. This is the first page a new developer sees.\n\n"
    "Rules:\n"
    "- Output ONLY the documentation content — no meta-commentary\n"
    "- Start directly with the project heading and content\n"
    "- Be clear and welcoming — this is the entry point to the entire codebase\n"
    "- Reference actual module names so readers can navigate to their docs\n"
    "- Include a high-level Mermaid architecture diagram (max 10 nodes)\n"
    "- Link to module pages naturally in the text — do NOT create a raw table listing every module"
)

OVERVIEW_USER = """\
Write the overview page for **{project_name}**'s code wiki.

## Module Summaries

{module_summaries}

## Repository Structure

{directory_tree}

---

Write a clear overview: what the project does, how it is architected, and the
key end-to-end flows. Include a simple Mermaid architecture diagram (max 10 nodes).
Link to module pages using markdown links (e.g. `[Module Name](module-slug.md)`)
rather than listing them in a table.
"""

# ── Helpers ───────────────────────────────────────────────────────────────────

def fill_template(template: str, **kwargs: str) -> str:
    """Replace ``{key}`` placeholders in *template*."""
    return template.format(**kwargs)


def format_file_list(files: list[CodeFileMeta]) -> str:
    """One line per file: ``path: sym1, sym2, ...``"""
    lines = []
    for f in files:
        syms = ", ".join(f.symbols[:15]) if f.symbols else "(no exports)"
        lines.append(f"- {f.path}: {syms}")
    return "\n".join(lines) or "(no files)"


def format_symbol_list(files: list[CodeFileMeta]) -> str:
    """Grouped per-file symbol listing."""
    lines = []
    for f in files:
        if f.symbols:
            lines.append(f"**{f.path}**: {', '.join(f.symbols[:20])}")
    return "\n".join(lines) or "(no exported symbols)"


def format_directory_tree(paths: list[str]) -> str:
    """Build a compact directory listing from relative file paths."""
    dirs: set[str] = set()
    for p in paths:
        parts = p.split("/")
        for i in range(1, len(parts)):
            dirs.add("/".join(parts[:i]))

    sorted_dirs = sorted(dirs)
    if not sorted_dirs:
        return "(flat structure)"

    lines = sorted_dirs[:50]
    result = "\n".join(lines)
    if len(sorted_dirs) > 50:
        result += f"\n... and {len(sorted_dirs) - 50} more directories"
    return result


def truncate_source(content: str, max_chars: int = 8000) -> str:
    """Truncate source code to *max_chars*, keeping a tail marker."""
    if len(content) <= max_chars:
        return content
    return content[:max_chars] + "\n\n[...truncated — showing first 8 000 chars...]"


def format_module_source(files: list[CodeFileMeta], max_chars: int = 8000) -> str:
    """Concatenate all file contents for a module, with path headers."""
    parts = []
    remaining = max_chars
    for f in files:
        header = f"### {f.path}\n\n"
        body = truncate_source(f.content, min(remaining, 4000))
        parts.append(header + body)
        remaining -= len(header) + len(body)
        if remaining <= 0:
            parts.append("\n[...remaining files omitted — token limit reached...]")
            break
    return "\n\n---\n\n".join(parts)


def format_call_edges(edges: list, max: int = 20) -> str:
    """Format a list of CallEdge for inclusion in prompts.

    Output: ``caller_name → callee_name (target_file)`` — one per line.
    """
    if not edges:
        return "(none)"
    lines = []
    for e in edges[:max]:
        target = f" ({e.to_file})" if e.to_file else ""
        lines.append(f"  {e.from_name} → {e.to_name}{target}")
    if len(edges) > max:
        lines.append(f"  ... and {len(edges) - max} more")
    return "\n".join(lines)


def format_rationales(rationales: list, max_items: int = 30) -> str:
    """Format design rationale comments for LLM prompts."""
    if not rationales:
        return "(none)"
    lines = []
    for r in rationales[:max_items]:
        tag = r.get("tag", "NOTE")
        text = r.get("text", "")
        file = r.get("file", "")
        line = r.get("line", 0)
        context = r.get("context", "")
        prefix = f"  [{tag}]"
        if context:
            prefix += f" in {context}"
        lines.append(f"{prefix}: {text}")
        lines.append(f"    — {file}:{line}")
    if len(rationales) > max_items:
        lines.append(f"  ... and {len(rationales) - max_items} more")
    return "\n".join(lines)


def format_api_routes(routes: list, max_routes: int = 30) -> str:
    """Format API routes for inclusion in LLM prompts."""
    if not routes:
        return "(none)"
    lines = []
    for r in routes[:max_routes]:
        method = r.get("method", "?")
        path = r.get("path", "?")
        handler = r.get("handler", "")
        file = r.get("file", "")
        framework = r.get("framework", "")
        line = f"  {method:6} {path:40} → {handler}" if handler else f"  {method:6} {path}"
        if file:
            line += f"  ({file})"
        if framework:
            line += f"  [{framework}]"
        lines.append(line)
    if len(routes) > max_routes:
        lines.append(f"  ... and {len(routes) - max_routes} more routes")
    return "\n".join(lines)


def format_execution_flows(flows: list, max_flows: int = 10) -> str:
    """Format execution flows for inclusion in LLM prompts.

    Output:
      **handleLogin** (auth.controller.ts:23)
        1. handleLogin → validateCredentials → hashPassword
        2. → generateToken → signJwt
        3. → saveSession → redisSet
        (8 steps, depth 4)
    """
    if not flows:
        return "(none)"
    lines = []
    for f in flows[:max_flows]:
        entry = f.get("name", "?")
        entry_file = f.get("entry_file", "")
        entry_line = f.get("entry_line", 0)
        steps = f.get("steps", [])
        step_count = f.get("step_count", len(steps))
        depth = f.get("depth", 0)

        lines.append(f"**{entry}** ({entry_file}:{entry_line})")

        # Show steps as chain: step1 → step2 → step3
        step_names = [s.get("name", "?") for s in steps[:8]]
        if step_names:
            chain = " → ".join(step_names)
            if len(steps) > 8:
                chain += f" → ... ({step_count} steps total)"
            lines.append(f"  {chain}")

        lines.append(f"  (depth {depth}, {step_count} steps)")
        lines.append("")

    if len(flows) > max_flows:
        lines.append(f"... and {len(flows) - max_flows} more flows")
    return "\n".join(lines)


def strip_json_fences(text: str) -> str:
    """Remove ```json ... ``` or ``` ... ``` wrappers if present."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()
