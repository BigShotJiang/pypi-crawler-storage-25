"""CodeGraphContext (CGC) bridge — reads from CGC's DuckDB index.

Provides enriched call graphs, class hierarchies, function signatures,
operational parameters, execution flows, routes, and rationale when
a CGC index (.cgc-index/graph.duckdb) exists.

Falls back gracefully when the index is unavailable.

Usage:
    cgc = CGCBridge(Path("/path/to/repo"))
    if cgc.available:
        stats = cgc.get_all_stats()
        routes = cgc.get_routes()
    cgc.close()

Prerequisite: run ``cgc-wiki index /path/to/repo`` to create the index.
"""
from __future__ import annotations

import json as _json
import logging
import os
from pathlib import Path

from llm_wiki.code.models import CallEdge, ModuleCallGraph

log = logging.getLogger(__name__)


class CGCBridge:
    """Read-only bridge to a CGC DuckDB index.

    All CGC interactions go through this class.  Safe to instantiate even
    when the index does not exist — methods return empty/fallback data.

    Error handling strategy:
    - __init__: missing DB → available=False (expected).
    - query methods: failure → returns empty data + logs warning. Never raises.
    - warnings property: accumulated warnings for CLI display.
    """

    def __init__(
        self,
        repo_path: Path,
        duckdb_path: Path | None = None,
    ) -> None:
        self.repo_path = Path(repo_path).resolve()
        self._conn = None
        self._available = False
        self._init_error: str | None = None
        self._warnings: list[str] = []

        # Auto-discover .cgc-index/graph.duckdb
        if duckdb_path is None:
            duckdb_path = self.repo_path / ".cgc-index" / "graph.duckdb"
        else:
            duckdb_path = Path(duckdb_path)
            # If user passed a directory, append graph.duckdb
            if duckdb_path.is_dir():
                duckdb_path = duckdb_path / "graph.duckdb"

        self._duckdb_path = duckdb_path

        if not duckdb_path.exists():
            self._init_error = (
                f"No CGC index found at {duckdb_path}. "
                f"Run: cgc-wiki index {repo_path}"
            )
            log.info("CGC: %s", self._init_error)
            return

        try:
            import duckdb
            self._conn = duckdb.connect(str(duckdb_path), read_only=True)
            self._available = True
            log.info("CGC bridge initialized (DuckDB: %s)", duckdb_path)
        except ImportError:
            self._init_error = "duckdb not installed. Run: pip install duckdb"
            log.info("CGC: %s", self._init_error)
        except Exception as exc:
            self._init_error = f"CGC DuckDB open failed: {exc}"
            log.warning("CGC: %s", self._init_error)

    # ── Properties ────────────────────────────────────────────────

    @property
    def available(self) -> bool:
        return self._available

    @property
    def init_error(self) -> str | None:
        return self._init_error

    @property
    def warnings(self) -> list[str]:
        return list(self._warnings)

    def _warn(self, msg: str) -> None:
        self._warnings.append(msg)
        log.warning("CGC: %s", msg)

    # ── Auto-Index ────────────────────────────────────────────────

    def auto_index(self) -> bool:
        """Run CGC indexing pipeline if no index exists. Returns True on success.

        Requires codegraphcontext-rust to be installed (pip install wiki-forge[cgc]).
        """
        if self._available:
            return True  # already indexed

        try:
            from codegraphcontext.tools.indexing.cgc_wiki_cli import (
                discover_files,
                EXT_LANG,
            )
            from codegraphcontext.tools.indexing.persistence.duckdb_writer import DuckDBGraphWriter

            repo_path = str(self.repo_path)
            log.info("CGC auto-indexing: %s", repo_path)

            # Discover files
            files = discover_files(repo_path)
            if not files:
                self._warn("No source files found")
                return False

            log.info("Found %d files, parsing...", len(files))

            # Parse
            from codegraphcontext._cgc_rust import parse_and_prescan
            specs = [(path, lang, False) for path, lang in files]
            parsed, imports_map = parse_and_prescan(specs)
            valid = [r for r in parsed if "error" not in r]

            # Resolve
            from codegraphcontext._cgc_rust import (
                resolve_call_groups,
                resolve_inheritance as _resolve_inh,
            )
            call_groups = resolve_call_groups(valid, imports_map, False)
            inheritance, _ = _resolve_inh(valid, imports_map)

            # Write to DuckDB
            import os
            output_dir = os.path.join(repo_path, ".cgc-index")
            os.makedirs(output_dir, exist_ok=True)
            db_path = os.path.join(output_dir, "graph.duckdb")

            writer = DuckDBGraphWriter(db_path)
            counts = writer.write_all(valid, repo_path, call_groups, inheritance)
            writer.close()

            # Generate module contexts
            from codegraphcontext.tools.indexing.module_grouping import auto_group_modules, group_parents
            from codegraphcontext.tools.indexing.context_generator import generate_module_contexts
            from codegraphcontext.tools.indexing.execution_flows import detect_execution_flows
            from codegraphcontext.tools.indexing.route_extraction import extract_routes
            from codegraphcontext.tools.indexing.rationale_extraction import extract_rationales
            from codegraphcontext.tools.indexing.op_param_extraction import extract_operational_params

            flows = detect_execution_flows(valid, call_groups, repo_path=repo_path)
            routes = extract_routes(valid, repo_path)
            rationales = extract_rationales(valid, repo_path)
            op_params = extract_operational_params(valid, repo_path)

            modules = auto_group_modules(valid, repo_path)
            ctx_dir = os.path.join(output_dir, "module_contexts")
            generate_module_contexts(
                modules, valid, repo_path, ctx_dir,
                call_groups=call_groups, routes=routes, flows=flows,
                rationales=rationales, op_params=op_params,
            )

            # Save modules.json
            import json as _j
            parent_groups = group_parents(modules)
            with open(os.path.join(output_dir, "modules.json"), "w") as fh:
                _j.dump({"modules": modules, "parent_groups": parent_groups}, fh, indent=2)

            log.info("CGC index complete: %s", counts)

            # Re-init connection
            import duckdb
            self._conn = duckdb.connect(db_path, read_only=True)
            self._available = True
            self._init_error = None
            return True

        except ImportError as exc:
            self._warn(
                f"codegraphcontext-rust not installed: {exc}. "
                f"Install with: pip install wiki-forge[cgc]"
            )
            return False
        except Exception as exc:
            self._warn(f"Auto-index failed: {exc}")
            return False

    # ── Call Graph ────────────────────────────────────────────────

    def get_call_graph_for_module(
        self,
        module_files: list[str],
        all_module_map: dict[str, str],
    ) -> ModuleCallGraph:
        """Query CALLS edges involving files in this module.

        Args:
            module_files: Relative file paths belonging to this module.
            all_module_map: Maps rel_path → module_slug for all modules.

        Returns:
            ModuleCallGraph with intra/outgoing/incoming edges.
        """
        if not self._conn:
            return ModuleCallGraph()

        file_set = set(module_files)

        try:
            rows = self._conn.execute("""
                SELECT DISTINCT caller_name, caller_path,
                       called_name, called_path
                FROM calls
                WHERE caller_type IN ('Function', 'Class', 'File')
                  AND called_type IN ('Function', 'Class')
                  AND caller_name != '' AND called_name != ''
            """).fetchall()
        except Exception as exc:
            self._warn(f"Call graph query failed: {exc}")
            return ModuleCallGraph()

        graph = ModuleCallGraph()
        seen: set[tuple[str, str, str, str]] = set()

        for cn, cp, en, ep in rows:
            caller_in = cp in file_set
            callee_in = ep in file_set
            if not caller_in and not callee_in:
                continue

            edge_key = (cp, cn, ep, en)
            if edge_key in seen:
                continue
            seen.add(edge_key)

            edge = CallEdge(from_file=cp, from_name=cn, to_file=ep, to_name=en)
            if caller_in and callee_in:
                graph.intra.append(edge)
            elif caller_in:
                graph.outgoing.append(edge)
            else:
                graph.incoming.append(edge)

        return graph

    # ── Class Hierarchies ─────────────────────────────────────────

    def get_class_hierarchies(self, class_names: list[str]) -> list[dict]:
        """Get class hierarchy data from inheritance + classes + functions tables.

        Returns list of {class_name, parent_classes, child_classes, methods}.
        """
        if not self._conn or not class_names:
            return []

        results: list[dict] = []
        try:
            # Build maps from inheritance table
            parent_map: dict[str, list[str]] = {}
            child_map: dict[str, list[str]] = {}
            for row in self._conn.execute(
                "SELECT child_name, parent_name FROM inheritance"
            ).fetchall():
                child, parent = row[0], row[1]
                parent_map.setdefault(child, []).append(parent)
                child_map.setdefault(parent, []).append(child)

            # Build methods map from functions table
            methods_map: dict[str, list[str]] = {}
            for row in self._conn.execute(
                "SELECT class_context, name FROM functions WHERE class_context != ''"
            ).fetchall():
                methods_map.setdefault(row[0], []).append(row[1])

            for name in class_names:
                parents = parent_map.get(name, [])
                children = child_map.get(name, [])
                methods = methods_map.get(name, [])
                if parents or children or methods:
                    results.append({
                        "class_name": name,
                        "parent_classes": parents,
                        "child_classes": children,
                        "methods": methods,
                    })
        except Exception as exc:
            log.debug("Class hierarchy query failed: %s", exc)

        return results

    # ── Symbol Signatures ─────────────────────────────────────────

    def get_symbol_signatures(self, file_paths: list[str]) -> dict[str, list[dict]]:
        """Get function signatures for given files.

        Returns {rel_path: [{name, args, decorators, line_number, docstring}]}.
        """
        if not self._conn or not file_paths:
            return {}

        file_set = set(file_paths)
        sigs: dict[str, list[dict]] = {}

        try:
            rows = self._conn.execute("""
                SELECT name, path, line_number, docstring, class_context
                FROM functions
            """).fetchall()

            for name, path, line, doc, cls_ctx in rows:
                if path not in file_set:
                    continue
                sigs.setdefault(path, []).append({
                    "name": name,
                    "line_number": line or 0,
                    "args": [],
                    "decorators": [],
                    "docstring": (doc or "")[:200],
                    "class_context": cls_ctx or "",
                })
        except Exception as exc:
            self._warn(f"Symbol signatures query failed: {exc}")

        return sigs

    # ── Operational Parameters ────────────────────────────────────

    def get_operational_params(self, file_paths: list[str]) -> list[dict]:
        """Get operational parameters (timeouts, cron, retry configs, etc.).

        Returns list of {name, value, path, line_number, category}.
        """
        if not self._conn:
            return []

        try:
            # Try dedicated table first (Phase 1 CGC v0.9.6+)
            if file_paths:
                file_set = set(file_paths)
                rows = self._conn.execute("""
                    SELECT name, value, path, line_number, category
                    FROM operational_params
                    ORDER BY path, line_number
                """).fetchall()
                return [
                    {"name": r[0], "value": r[1], "path": r[2],
                     "line_number": r[3], "category": r[4] or "config"}
                    for r in rows if r[2] in file_set
                ]
            else:
                rows = self._conn.execute("""
                    SELECT name, value, path, line_number, category
                    FROM operational_params
                    ORDER BY path, line_number
                """).fetchall()
                return [
                    {"name": r[0], "value": r[1], "path": r[2],
                     "line_number": r[3], "category": r[4] or "config"}
                    for r in rows
                ]
        except Exception:
            pass

        # Fallback: scan variables table with pattern match
        try:
            rows = self._conn.execute("""
                SELECT name, type, path, line_number
                FROM variables
                WHERE LOWER(name) SIMILAR TO
                    '.*(timeout|cron|schedule|interval|retry|retries|max_|min_|'
                    'port|host|redis|celery|ttl|cooldown|batch|concurren|'
                    'threshold|limit|delay|period|frequency|worker|queue|'
                    'pool_size|backoff).*'
            """).fetchall()
            file_set = set(file_paths) if file_paths else None
            return [
                {"name": r[0], "value": r[1] or "", "path": r[2],
                 "line_number": r[3] or 0, "category": "config"}
                for r in rows
                if file_set is None or r[2] in file_set
            ]
        except Exception as exc:
            log.debug("Operational params query failed: %s", exc)
            return []

    # ── Execution Flows ───────────────────────────────────────────

    def get_execution_flows(
        self, file_paths: list[str] | None = None, limit: int = 20,
    ) -> list[dict]:
        """Get execution flows from entry points through call chains.

        Returns list of {name, entry_file, entry_line, entry_class,
                         step_count, depth, score, steps}.
        """
        if not self._conn:
            return []

        try:
            if file_paths:
                file_set = set(file_paths)
                rows = self._conn.execute("""
                    SELECT name, entry_file, entry_line, entry_class,
                           step_count, depth, score, steps_json
                    FROM execution_flows
                    ORDER BY score DESC, step_count DESC
                """).fetchall()
                # Filter in Python (DuckDB IN clause with many params is slow)
                rows = [r for r in rows if r[1] in file_set][:limit]
            else:
                rows = self._conn.execute("""
                    SELECT name, entry_file, entry_line, entry_class,
                           step_count, depth, score, steps_json
                    FROM execution_flows
                    ORDER BY score DESC, step_count DESC
                    LIMIT ?
                """, [limit]).fetchall()

            return [
                {
                    "name": r[0],
                    "entry_file": r[1],
                    "entry_line": r[2],
                    "entry_class": r[3] or "",
                    "step_count": r[4],
                    "depth": r[5],
                    "score": r[6],
                    "steps": _json.loads(r[7]) if r[7] else [],
                }
                for r in rows
            ]
        except Exception as exc:
            log.debug("Execution flows query failed: %s", exc)
            return []

    # ── Rationales ────────────────────────────────────────────────

    def get_rationales(
        self, file_paths: list[str] | None = None, limit: int = 50,
    ) -> list[dict]:
        """Get design rationale comments (NOTE, WHY, HACK, TODO, etc.)."""
        if not self._conn:
            return []
        try:
            if file_paths:
                placeholders = ",".join(["?"] * len(file_paths))
                rows = self._conn.execute(f"""
                    SELECT tag, text, file, line, context
                    FROM rationales WHERE file IN ({placeholders})
                    ORDER BY file, line LIMIT ?
                """, file_paths + [limit]).fetchall()
            else:
                rows = self._conn.execute("""
                    SELECT tag, text, file, line, context
                    FROM rationales ORDER BY file, line LIMIT ?
                """, [limit]).fetchall()
            return [
                {"tag": r[0], "text": r[1], "file": r[2],
                 "line": r[3], "context": r[4]}
                for r in rows
            ]
        except Exception:
            return []

    # ── Routes ────────────────────────────────────────────────────

    def get_routes(self, limit: int = 50) -> list[dict]:
        """Get detected API routes."""
        if not self._conn:
            return []
        try:
            rows = self._conn.execute("""
                SELECT method, path, handler, file, line, framework
                FROM routes ORDER BY path, method LIMIT ?
            """, [limit]).fetchall()
            return [
                {"method": r[0], "path": r[1], "handler": r[2],
                 "file": r[3], "line": r[4], "framework": r[5]}
                for r in rows
            ]
        except Exception:
            return []

    # ── Stats ─────────────────────────────────────────────────────

    def get_all_stats(self) -> dict:
        """Return aggregate counts from the CGC graph."""
        if not self._conn:
            return {}

        stats: dict = {}
        for table, key in [
            ("files", "files"), ("functions", "functions"),
            ("classes", "classes"), ("variables", "variables"),
            ("modules", "modules"),
        ]:
            try:
                r = self._conn.execute(f"SELECT count(*) FROM {table}").fetchone()
                stats[key] = r[0] if r else 0
            except Exception:
                stats[key] = 0

        try:
            r = self._conn.execute("""
                SELECT count(*) FROM (
                    SELECT DISTINCT caller_name, caller_path, called_name, called_path
                    FROM calls WHERE caller_name != '' AND called_name != ''
                )
            """).fetchone()
            stats["call_edges"] = r[0] if r else 0
        except Exception:
            stats["call_edges"] = 0

        return stats

    # ── Top Connected ─────────────────────────────────────────────

    def get_top_connected(self, limit: int = 10) -> list[dict]:
        """Return most-connected functions (by caller + callee count).

        Returns list of {name, path, callers, callees, total}.
        """
        if not self._conn:
            return []

        try:
            rows = self._conn.execute("""
                SELECT called_name AS name, called_path AS path,
                       count(*) AS callers
                FROM calls
                WHERE called_type IN ('Function', 'Class')
                  AND called_name != ''
                  AND called_path NOT LIKE '%.min.js'
                  AND called_path NOT LIKE '%vendor%'
                  AND called_path NOT LIKE '%node_modules%'
                GROUP BY called_name, called_path
                ORDER BY callers DESC
                LIMIT ?
            """, [limit * 2]).fetchall()

            # Count callees
            callee_rows = self._conn.execute("""
                SELECT caller_name, caller_path, count(*) AS cnt
                FROM calls
                WHERE caller_type IN ('Function', 'Class')
                  AND caller_name != ''
                GROUP BY caller_name, caller_path
            """).fetchall()
            callee_map = {f"{r[0]}@{r[1]}": r[2] for r in callee_rows}

            results = []
            for name, path, callers in rows:
                callees = callee_map.get(f"{name}@{path}", 0)
                results.append({
                    "name": name, "path": path,
                    "callers": callers, "callees": callees,
                    "total": callers + callees,
                })

            results.sort(key=lambda x: x["total"], reverse=True)
            return results[:limit]
        except Exception as exc:
            self._warn(f"Top connected query failed: {exc}")
            return []

    # ── Graph Edges (for visualization) ───────────────────────────

    # React hooks and common noise to filter from graph visualization
    _GRAPH_NOISE_NAMES = frozenset({
        "useState", "useEffect", "useRef", "useCallback", "useMemo",
        "useContext", "useReducer", "useLayoutEffect",
        "console", "log", "warn", "error", "info", "debug",
        "require", "module", "exports",
        "toString", "valueOf", "hasOwnProperty",
        "parseInt", "parseFloat", "isNaN", "isFinite",
        "setTimeout", "setInterval", "clearTimeout", "clearInterval",
        "Promise", "then", "catch", "finally",
    })

    def get_duckdb_edges(self, limit: int = 5000) -> list[dict]:
        """Query deduplicated CALLS edges for graph visualization."""
        if not self._conn:
            return []
        try:
            rows = self._conn.execute("""
                SELECT caller_name, caller_path, caller_type,
                       called_name, called_path, called_type,
                       count(*) AS weight
                FROM calls
                WHERE caller_name != '' AND called_name != ''
                  AND caller_type IN ('Function', 'Class')
                  AND called_type IN ('Function', 'Class')
                  AND caller_path NOT LIKE '%.min.js'
                  AND called_path NOT LIKE '%.min.js'
                  AND caller_path NOT LIKE '%vendor%'
                  AND caller_path NOT LIKE '%node_modules%'
                GROUP BY caller_name, caller_path, caller_type,
                         called_name, called_path, called_type
                ORDER BY weight DESC
                LIMIT ?
            """, [limit]).fetchall()
            return [
                {"src": r[0], "src_path": r[1], "src_type": r[2],
                 "tgt": r[3], "tgt_path": r[4], "tgt_type": r[5],
                 "weight": r[6]}
                for r in rows
            ]
        except Exception as exc:
            log.warning("DuckDB edge query failed: %s", exc)
            return []

    # ── Module Grouping (from CGC index) ──────────────────────────

    def get_module_grouping(self) -> dict | None:
        """Read modules.json from CGC index directory.

        Returns {modules: [...], parent_groups: [...]} or None.
        """
        modules_json = self._duckdb_path.parent / "modules.json"
        if not modules_json.exists():
            return None
        try:
            with open(modules_json) as fh:
                return _json.load(fh)
        except Exception:
            return None

    # ── File Metadata ─────────────────────────────────────────────

    def get_all_files(self) -> list[dict]:
        """Return [{path, name, is_dependency}] from files table."""
        if not self._conn:
            return []
        try:
            rows = self._conn.execute("""
                SELECT relative_path, name, is_dependency
                FROM files
                ORDER BY relative_path
            """).fetchall()
            return [
                {"path": r[0], "name": r[1], "is_dependency": r[2]}
                for r in rows
            ]
        except Exception:
            return []

    def get_file_symbols(self) -> dict[str, list[str]]:
        """Return {rel_path: [function_names + class_names]}."""
        if not self._conn:
            return {}

        symbols: dict[str, list[str]] = {}
        try:
            for row in self._conn.execute(
                "SELECT name, path FROM functions"
            ).fetchall():
                symbols.setdefault(row[1], []).append(row[0])
            for row in self._conn.execute(
                "SELECT name, path FROM classes"
            ).fetchall():
                symbols.setdefault(row[1], []).append(row[0])
        except Exception:
            pass
        return symbols

    # ── Cleanup ───────────────────────────────────────────────────

    def close(self) -> None:
        """Close DuckDB connection."""
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None
