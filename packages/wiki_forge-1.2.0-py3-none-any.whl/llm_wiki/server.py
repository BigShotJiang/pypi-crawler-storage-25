"""FastAPI server for llm-wiki — serves sage-wiki Preact UI + REST/SSE API.

Endpoints (match sage-wiki frontend expectations):
  GET  /api/tree               → sidebar file tree
  GET  /api/articles/{path}    → page content + frontmatter
  GET  /api/search?q=&limit=   → keyword search
  GET  /api/graph?center=&depth= → wikilink graph
  GET  /api/status             → vault stats
  POST /api/query              → SSE streaming Q&A
  GET  /wiki/{path}            → SPA route (serve index.html)
  GET  /                       → redirect to /wiki/
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import AsyncIterator

log = logging.getLogger(__name__)


# ── Request models (module-level so Pydantic can fully resolve them) ─────────

try:
    from pydantic import BaseModel as _BaseModel

    class QueryRequest(_BaseModel):
        question: str
        top_k: int = 5

except ImportError:
    QueryRequest = None  # type: ignore


# ── Lazy imports for optional deps ───────────────────────────────────────────

def _require_fastapi():
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        raise ImportError(
            "Server dependencies missing. Install with:\n"
            "  pip install 'llm-wiki[serve]'\n"
            "or: pip install fastapi 'uvicorn[standard]'"
        )


# ── App factory ──────────────────────────────────────────────────────────────

def create_app(vault_root: Path, gemini_api_key: str = "", static_dir: Path | None = None):
    """Create and return a FastAPI application bound to *vault_root*."""
    _require_fastapi()

    from fastapi import Body, FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
    from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, StreamingResponse
    from fastapi.staticfiles import StaticFiles

    from llm_wiki.config import Settings
    from llm_wiki.llm.factory import create_llm
    from llm_wiki.pipeline.graph import build_graph
    from llm_wiki.pipeline.graph_relevance import WikiGraph
    from llm_wiki.pipeline.query import _find_relevant_pages, query_wiki
    from llm_wiki.pipeline.search import WikiSearchIndex
    from llm_wiki.vault.paths import Vault
    from llm_wiki.vault.wikilinks import extract_wikilinks

    settings = Settings(vault_root=vault_root)
    if gemini_api_key:
        settings.gemini_api_key = gemini_api_key
    vault = Vault(vault_root)

    # Build BM25 index on startup
    search_index = WikiSearchIndex()
    search_index.build(vault)
    log.info("BM25 index ready: %d pages", len(search_index._pages))

    # Build wiki graph for retrieval re-ranking
    wiki_graph = WikiGraph()
    wiki_graph.build(vault)
    log.info("Wiki graph ready: %d nodes", len(wiki_graph.nodes))

    # QMD search disabled — BM25+Graph provides equivalent results without overhead
    # To re-enable: uncomment and install QMD (see pipeline/qmd_search.py)
    qmd_searcher = None

    # Mutable state container for vault switching
    class _VaultState:
        """Mutable wrapper so vault can be swapped at runtime."""
        def __init__(self):
            self.vault = vault
            self.settings = settings
            self.search_index = search_index
            self.wiki_graph = wiki_graph
            self.vault_root = vault_root

        def switch(self, new_root: Path):
            """Switch to a different vault, rebuild all indices."""
            from llm_wiki.pipeline.review import ReviewStore as _ReviewStore
            self.vault_root = new_root
            self.settings = Settings(vault_root=new_root)
            if gemini_api_key:
                self.settings.gemini_api_key = gemini_api_key
            self.vault = Vault(new_root)
            self.search_index = WikiSearchIndex()
            self.search_index.build(self.vault)
            self.wiki_graph = WikiGraph()
            self.wiki_graph.build(self.vault)
            # Update outer closure refs (including review_store)
            nonlocal vault, settings, search_index, wiki_graph, review_store
            vault = self.vault
            settings = self.settings
            search_index = self.search_index
            wiki_graph = self.wiki_graph
            review_store = _ReviewStore(new_root)
            log.info("Switched vault to %s (%d pages, %d nodes)",
                     new_root.name, len(self.search_index._pages), len(self.wiki_graph.nodes))

    _state = _VaultState()

    app = FastAPI(title="llm-wiki server", docs_url=None, redoc_url=None)

    # ── CORS — allow MCP SSE clients (Cursor extensions, browser-based tools) ──
    from fastapi.middleware.cors import CORSMiddleware

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # permissive for internal deployment; tighten in prod
        allow_credentials=False,  # cannot combine True with allow_origins=["*"]
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["*"],
    )

    # ── /ws — hot-reload stub (sage-wiki frontend expects this) ───────────────

    @app.websocket("/ws")
    async def ws_hotreload(websocket: WebSocket):
        """Accept and hold WebSocket connection; never sends reload — silences console errors."""
        await websocket.accept()
        try:
            while True:
                await websocket.receive_bytes()  # blocks until message or disconnect
        except WebSocketDisconnect:
            pass
        except Exception:
            pass

    # ── /api/tree ─────────────────────────────────────────────────────────────

    @app.get("/api/tree")
    def api_tree():
        def _entries(pages):
            return [{"name": p.stem, "path": str(p.relative_to(vault.wiki))} for p in sorted(pages)]

        concepts = _entries(vault.concept_pages())
        entities = _entries(vault.entity_pages())
        sources  = _entries(vault.source_pages())
        synths   = _entries(sorted(vault.syntheses.glob("*.md")) if vault.syntheses.exists() else [])

        # Code-to-Doc output: wiki/outputs/code/**/*.md (supports per-project subfolders)
        code_dir = vault.wiki / "outputs" / "code"
        if code_dir.exists():
            # Group by project subfolder: {project: [entries]}
            # Flat files (no subfolder) go to "_flat" bucket
            code_by_project: dict[str, list] = {}
            for p in sorted(code_dir.rglob("*.md")):
                rel = p.relative_to(code_dir)
                parts = rel.parts
                project = parts[0] if len(parts) > 1 else "_flat"
                entry = {"name": p.stem, "path": str(p.relative_to(vault.wiki))}
                code_by_project.setdefault(project, []).append(entry)
            # Flatten for sidebar: prefix name with project if multi-project
            multi = len([k for k in code_by_project if k != "_flat"]) > 0
            code_pages = []
            for project, entries in code_by_project.items():
                for e in entries:
                    if multi and project != "_flat":
                        e = {**e, "project": project}
                    code_pages.append(e)

            # Build parent hierarchy from frontmatter of parent-*.md files
            # Returns code_tree: flat list where parent pages carry a `children` list
            import re as _re
            code_tree: list[dict] = []
            parent_child_map: dict[str, list[str]] = {}  # parent_slug → [child_slug]

            for p in sorted(code_dir.rglob("parent-*.md")):
                try:
                    raw = p.read_text(encoding="utf-8")
                    fm_match = _re.match(r"^---\s*\n(.*?)\n---\s*\n", raw, _re.DOTALL)
                    if fm_match:
                        children: list[str] = []
                        in_children = False
                        for line in fm_match.group(1).splitlines():
                            if line.strip() == "children:":
                                in_children = True
                            elif in_children and line.startswith("  - "):
                                children.append(line.strip()[2:])
                            elif in_children and not line.startswith(" "):
                                in_children = False
                        # stem is "parent-{slug}" — expose as parent entry
                        parent_slug = p.stem[len("parent-"):]
                        parent_child_map[parent_slug] = children
                except OSError:
                    pass

            if parent_child_map:
                # Emit parent entries (with children slugs) + orphan module entries
                all_child_slugs = {s for children in parent_child_map.values() for s in children}
                for p in sorted(code_dir.rglob("parent-*.md")):
                    parent_slug = p.stem[len("parent-"):]
                    children = parent_child_map.get(parent_slug, [])
                    rel_path = str(p.relative_to(vault.wiki))
                    # Title from frontmatter
                    try:
                        raw = p.read_text(encoding="utf-8")
                        fm_title = _re.search(r'^title:\s*"?(.+?)"?\s*$', raw, _re.MULTILINE)
                        parent_label = fm_title.group(1) if fm_title else parent_slug
                    except OSError:
                        parent_label = parent_slug

                    child_entries = []
                    for slug in children:
                        child_path_candidates = list(code_dir.rglob(f"{slug}.md"))
                        if child_path_candidates:
                            cp = child_path_candidates[0]
                            child_entries.append({
                                "name": cp.stem,
                                "path": str(cp.relative_to(vault.wiki)),
                            })
                    code_tree.append({
                        "type": "parent",
                        "name": parent_label,
                        "path": rel_path,
                        "children": child_entries,
                    })
                # Add any modules not covered by a parent
                for p in sorted(code_dir.glob("*.md")):
                    if p.stem.startswith("parent-") or p.stem == "overview":
                        continue
                    if p.stem not in all_child_slugs:
                        code_tree.append({
                            "type": "module",
                            "name": p.stem,
                            "path": str(p.relative_to(vault.wiki)),
                        })
                # Always add overview last
                overview_p = code_dir / "overview.md"
                if overview_p.exists():
                    code_tree.append({
                        "type": "overview",
                        "name": "overview",
                        "path": str(overview_p.relative_to(vault.wiki)),
                    })
        else:
            code_pages = []
            code_tree = []

        return {
            "concepts":  concepts,
            "summaries": sources,
            "outputs":   synths,
            "entities":  entities,
            "code":      code_pages,
            "code_tree": code_tree,   # hierarchical view (populated when parent pages exist)
            "stats": {
                "concepts":  len(concepts),
                "summaries": len(sources),
                "code":      len(code_pages),
            },
        }

    # ── /api/articles/{path} ─────────────────────────────────────────────────

    def _slugify(text: str) -> str:
        """Normalize text to slug: lowercase, strip accents, replace non-alnum with hyphen."""
        import unicodedata
        nfkd = unicodedata.normalize("NFKD", text)
        ascii_str = nfkd.encode("ascii", "ignore").decode("ascii")
        return re.sub(r"[^a-z0-9]+", "-", ascii_str.lower()).strip("-")

    def _resolve_article(path: str):
        """Resolve path → file, with slug fallback for wikilinks with Vietnamese/spaces."""
        # 1. Exact match
        target = vault.wiki / path
        if target.exists() and target.is_file():
            return target

        # 2. Add .md if missing
        if not path.endswith(".md"):
            target2 = vault.wiki / (path + ".md")
            if target2.exists() and target2.is_file():
                return target2

        # 3. Slug match: compare requested stem slug against all page stems
        parts = path.rsplit("/", 1)
        folder = parts[0] if len(parts) == 2 else ""
        req_stem = re.sub(r"\.md$", "", parts[-1])
        req_slug = _slugify(req_stem)

        search_dir = vault.wiki / folder if folder else vault.wiki
        if search_dir.exists():
            for f in search_dir.glob("*.md"):
                if _slugify(f.stem) == req_slug:
                    return f

        # 4. Global slug search across all pages
        for page in vault.all_pages():
            if _slugify(page.stem) == req_slug:
                return page

        return None

    @app.get("/api/articles/{path:path}")
    def api_article(path: str):
        target = _resolve_article(path)
        if target is None:
            raise HTTPException(status_code=404, detail=f"Article not found: {path}")

        raw = target.read_text(encoding="utf-8")

        # Parse frontmatter
        fm: dict = {}
        body = raw
        fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n", raw, re.DOTALL)
        if fm_match:
            for line in fm_match.group(1).splitlines():
                if ":" in line:
                    k, _, v = line.partition(":")
                    fm[k.strip()] = v.strip().strip("\"'")
            body = raw[fm_match.end():]

        return {"path": path, "frontmatter": fm, "body": body}

    # ── /api/search ──────────────────────────────────────────────────────────

    @app.get("/api/search")
    def api_search(q: str = "", limit: int = 10):
        if not q or len(q) < 2:
            return {"results": [], "total": 0}

        hits = search_index.search(q, limit=limit)
        results = [
            {
                "id": r.path.stem,
                "path": r.rel_path,
                "snippet": r.snippet,
                "score": round(r.score, 4),
            }
            for r in hits
        ]
        return {"results": results, "total": len(results)}

    # ── /api/graph ───────────────────────────────────────────────────────────

    @app.get("/api/graph")
    def api_graph(center: str | None = None, depth: int = 2):
        graph = build_graph(vault)

        if center:
            # BFS from center node up to `depth` hops
            adj: dict[str, set[str]] = {}
            for e in graph.edges:
                adj.setdefault(e["source"], set()).add(e["target"])
                adj.setdefault(e["target"], set()).add(e["source"])

            visited = {center}
            frontier = {center}
            for _ in range(depth):
                next_frontier = set()
                for n in frontier:
                    next_frontier.update(adj.get(n, set()) - visited)
                visited.update(next_frontier)
                frontier = next_frontier

            node_ids = visited
            nodes = [n for n in graph.nodes if n["id"] in node_ids]
            edges = [e for e in graph.edges
                     if e["source"] in node_ids and e["target"] in node_ids]
        else:
            nodes = graph.nodes
            edges = graph.edges

        # Adapt to sage-wiki's GraphData shape
        adapted_nodes = [
            {
                "id": n["id"],
                "type": n["layer"],           # concept/entity/source…
                "name": n["label"],
                "connections": n["inbound"],
            }
            for n in nodes
        ]
        adapted_edges = [
            {"source": e["source"], "target": e["target"], "relation": "links"}
            for e in edges
        ]

        return {"nodes": adapted_nodes, "edges": adapted_edges, "total": len(adapted_nodes)}

    # ── /api/status ──────────────────────────────────────────────────────────

    @app.get("/api/status")
    def api_status():
        all_pages = vault.all_pages()
        entities  = vault.entity_pages()
        edges_count = 0
        for p in all_pages:
            try:
                edges_count += len(extract_wikilinks(p.read_text(encoding="utf-8")))
            except OSError:
                pass
        return {
            "project":    vault.root.name,
            "entries":    len(all_pages),
            "vectors":    0,      # no embeddings yet
            "dimensions": 0,
            "entities":   len(entities),
            "relations":  edges_count,
        }

    # ── MCP SSE endpoint — remote MCP for Claude Desktop / Cursor ─────────────

    try:
        from mcp.server.sse import SseServerTransport
        from starlette.requests import Request as StarletteRequest
        from starlette.routing import Mount
        from llm_wiki.mcp_server import build_mcp_server

        _mcp_server, _, _ = build_mcp_server(vault_root, settings)
        _sse = SseServerTransport("/mcp/messages/")

        async def mcp_sse_endpoint(request: StarletteRequest):
            """SSE endpoint for MCP clients. Claude/Cursor connect here."""
            async with _sse.connect_sse(
                request.scope, request.receive, request._send
            ) as (read_stream, write_stream):
                await _mcp_server.run(
                    read_stream,
                    write_stream,
                    _mcp_server.create_initialization_options(),
                )

        # Register via Starlette route (bypass FastAPI param parsing)
        from starlette.routing import Route
        app.router.routes.append(Route("/mcp/sse", endpoint=mcp_sse_endpoint))
        app.router.routes.append(
            Mount("/mcp/messages/", app=_sse.handle_post_message)
        )
        log.info("MCP SSE endpoint: /mcp/sse (messages: /mcp/messages/)")
    except ImportError:
        log.info("MCP SSE not available (install: pip install mcp)")

    # ── /api/vaults — list available vaults ────────────────────────────────────

    @app.get("/api/vaults")
    def api_vaults():
        """List vault directories available for switching.

        Scans the parent directory of the current vault for sibling folders
        that contain a ``wiki/`` subdirectory.
        """
        parent = _state.vault_root.parent
        vaults = []
        for d in sorted(parent.iterdir()):
            if not d.is_dir():
                continue
            wiki_dir = d / "wiki"
            if not wiki_dir.exists():
                continue
            # Count pages
            pages = list(wiki_dir.rglob("*.md"))
            has_code = (wiki_dir / "outputs" / "code").exists() or (wiki_dir / "projects").exists()
            vaults.append({
                "name": d.name,
                "path": str(d),
                "pages": len(pages),
                "has_code": has_code,
                "active": str(d) == str(_state.vault_root),
            })
        return {"vaults": vaults}

    # ── /api/switch-vault — switch to a different vault ─────────────────────

    @app.post("/api/switch-vault")
    def api_switch_vault(vault_path: str = Body(..., embed=True)):
        """Switch the server to serve a different vault.

        Rebuilds BM25 search index and wiki graph for the new vault.
        """
        new_root = Path(vault_path)
        if not new_root.exists():
            raise HTTPException(404, f"Vault not found: {vault_path}")
        if not (new_root / "wiki").exists():
            raise HTTPException(400, f"Not a valid vault (no wiki/ dir): {vault_path}")

        _state.switch(new_root)

        # Return new status
        all_pages = vault.all_pages()
        entities = vault.entity_pages()
        edges_count = 0
        for p in all_pages:
            try:
                edges_count += len(extract_wikilinks(p.read_text(encoding="utf-8")))
            except OSError:
                pass
        return {
            "ok": True,
            "project": vault.root.name,
            "entries": len(all_pages),
            "entities": len(entities),
            "relations": edges_count,
        }

    # ── /api/vaults/create — create a new vault in the workspaces directory ──

    @app.post("/api/vaults/create")
    def api_vaults_create(
        name: str = Body(..., embed=True),
        switch: bool = Body(True, embed=True),
    ):
        """Create a new empty vault in the workspaces directory.

        Args:
            name: Vault folder name (alphanumeric, dashes, underscores only).
            switch: If True, auto-switch to the new vault after creation.
        """
        import re
        # Validate name (filesystem-safe)
        clean = name.strip()
        if not clean:
            raise HTTPException(400, "Vault name is required")
        if not re.fullmatch(r"[a-zA-Z0-9_\-]{1,64}", clean):
            raise HTTPException(
                400, "Name must be 1-64 chars, alphanumeric + dash + underscore only"
            )

        parent = _state.vault_root.parent
        new_root = parent / clean
        if new_root.exists():
            raise HTTPException(409, f"Vault already exists: {clean}")

        try:
            # Create vault structure: wiki/{entities,concepts,sources,syntheses,raw/sources}
            new_vault = Vault(new_root)
            new_vault.init_dirs()

            # Create an empty overview.md so the vault has content
            overview = new_vault.wiki / "overview.md"
            if not overview.exists():
                overview.write_text(
                    f"---\ntitle: {clean}\ntype: overview\n---\n\n# {clean}\n\nEmpty wiki. Start by ingesting sources.\n",
                    encoding="utf-8",
                )

            log.info("Created new vault: %s", new_root)
        except OSError as exc:
            raise HTTPException(500, f"Failed to create vault: {exc}")

        result = {
            "ok": True,
            "name": clean,
            "path": str(new_root),
        }

        if switch:
            _state.switch(new_root)
            result["switched"] = True
            result["entries"] = len(vault.all_pages())
        return result

    # ── /api/query (SSE streaming) ────────────────────────────────────────────

    @app.post("/api/query")
    async def api_query(payload: QueryRequest = Body(...)):
        question = payload.question.strip()
        if not question:
            raise HTTPException(status_code=400, detail="question is required")

        async def event_stream() -> AsyncIterator[str]:
            llm = create_llm(settings)
            try:
                # Find relevant pages via BM25 (reuse server index)
                pages = _find_relevant_pages(
                    question, vault,
                    _bm25_index=search_index,
                    _wiki_graph=wiki_graph,
                    _qmd_searcher=qmd_searcher,
                )
                source_paths = [str(p.relative_to(vault.wiki)) for p in pages]

                # Run query directly (query_wiki is async)
                result = await query_wiki(
                    question, vault, llm, settings,
                    _bm25_index=search_index,
                    _wiki_graph=wiki_graph,
                    _qmd_searcher=qmd_searcher,
                )

                # Emit sources first
                yield f"event: sources\ndata: {json.dumps({'paths': source_paths})}\n\n"

                # Stream answer token by token (word-level simulation since Gemini is non-streaming)
                words = result.answer.split(" ")
                for i, word in enumerate(words):
                    chunk = word + ("" if i == len(words) - 1 else " ")
                    yield f"event: token\ndata: {json.dumps({'text': chunk})}\n\n"
                    await asyncio.sleep(0.01)  # pacing for smooth render

                yield f"event: done\ndata: {{}}\n\n"

            except Exception as exc:
                log.exception("Query error")
                yield f"event: error\ndata: {json.dumps({'error': str(exc)})}\n\n"
            finally:
                await llm.close()

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    # ── /api/reviews (review system) ──────────────────────────────────────────

    from llm_wiki.pipeline.review import ReviewStore
    review_store = ReviewStore(vault.root)

    @app.get("/api/reviews")
    async def api_reviews(status: str = Query("")):
        """Get review items, optionally filtered by status (open/approved/dismissed)."""
        review_store._load()  # reload from disk (picks up items added by CLI/ingest)
        items = review_store.all(status=status or None)
        return {
            "total": review_store.total_count,
            "open": review_store.open_count,
            "items": [i.model_dump() for i in items],
        }

    @app.post("/api/reviews/{title}/approve")
    async def api_review_approve(title: str):
        """Approve a review item."""
        if review_store.update_status(title, "approved"):
            return {"ok": True}
        raise HTTPException(404, "Review item not found")

    @app.post("/api/reviews/{title}/dismiss")
    async def api_review_dismiss(title: str):
        """Dismiss a review item."""
        if review_store.update_status(title, "dismissed"):
            return {"ok": True}
        raise HTTPException(404, "Review item not found")

    # ── /api/related (graph-based) ────────────────────────────────────────────

    @app.get("/api/related")
    async def api_related(page: str = Query(""), limit: int = Query(5)):
        """Get pages related to a given page via 4-signal graph relevance."""
        if not page:
            raise HTTPException(400, "page parameter required")
        related = wiki_graph.get_related(page, limit=limit)
        return {
            "page": page,
            "related": [
                {"id": rid, "score": round(score, 2)}
                for rid, score in related
            ],
        }

    # ── /api/fs/* — Filesystem adapter for nashsu UI ─────────────────────────

    def _resolve_fs_path(path_str: str) -> Path:
        """Resolve path — absolute, relative to vault root, or inside wiki/.

        Security: all resolved paths MUST be within the current vault root.
        """
        vault_resolved = vault.root.resolve()
        p = Path(path_str)
        if p.is_absolute():
            resolved = p.resolve()
            # Security: reject paths outside vault root
            if not str(resolved).startswith(str(vault_resolved) + "/") and resolved != vault_resolved:
                raise HTTPException(403, f"Access denied: path outside vault")
            return resolved
        # Try vault root first
        direct = vault.root / p
        if direct.resolve().exists():
            return direct.resolve()
        # Try inside wiki/ subdir (tree API returns paths like concepts/X.md)
        wiki_path = vault.root / "wiki" / p
        if wiki_path.resolve().exists():
            return wiki_path.resolve()
        # Try outputs/code/ for code module paths
        code_path = vault.root / "wiki" / "outputs" / "code" / p
        if code_path.resolve().exists():
            return code_path.resolve()
        # Return direct (will 404)
        return direct.resolve()

    def _build_file_tree(root: Path) -> list[dict]:
        """Recursively build FileNode-compatible tree."""
        items = []
        try:
            SKIP_DIRS = {".git", ".github", "__pycache__", "node_modules", "graphify-out", ".obsidian", ".llm-wiki"}
            for child in sorted(root.iterdir()):
                if child.name.startswith(".") or child.name in SKIP_DIRS:
                    continue
                node: dict = {
                    "name": child.name,
                    "path": str(child),
                    "is_dir": child.is_dir(),
                }
                if child.is_dir():
                    node["children"] = _build_file_tree(child)
                items.append(node)
        except PermissionError:
            pass
        return items

    @app.post("/api/fs/read")
    async def api_fs_read(body: dict = Body(...)):
        path_str = body.get("path", "")
        target = _resolve_fs_path(path_str)
        if not target.exists():
            # Graceful: return empty for persistence files, 404 for others
            if ".llm-wiki" in path_str or path_str.endswith(".json"):
                return {"content": ""}
            raise HTTPException(404, f"Not found: {path_str}")
        return {"content": target.read_text(encoding="utf-8")}

    @app.post("/api/fs/write")
    async def api_fs_write(body: dict = Body(...)):
        target = _resolve_fs_path(body.get("path", ""))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(body.get("contents", ""), encoding="utf-8")
        return {"ok": True}

    @app.post("/api/fs/list")
    async def api_fs_list(body: dict = Body(...)):
        target = _resolve_fs_path(body.get("path", "."))
        if not target.exists():
            return {"tree": []}
        return {"tree": _build_file_tree(target)}

    @app.post("/api/fs/delete")
    async def api_fs_delete(body: dict = Body(...)):
        target = _resolve_fs_path(body.get("path", ""))
        if target.exists() and target.is_file():
            target.unlink()
        return {"ok": True}

    @app.post("/api/fs/copy")
    async def api_fs_copy(body: dict = Body(...)):
        import shutil
        src = _resolve_fs_path(body.get("source", ""))
        dst = _resolve_fs_path(body.get("destination", ""))
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(src), str(dst))
        return {"ok": True}

    @app.post("/api/fs/mkdir")
    async def api_fs_mkdir(body: dict = Body(...)):
        target = _resolve_fs_path(body.get("path", ""))
        target.mkdir(parents=True, exist_ok=True)
        return {"ok": True}

    # ── PDF → Markdown helper (pdfplumber, MIT license) ────────────────────

    def _pdfplumber_to_markdown(pdf_path: str) -> tuple:
        """Convert PDF to Markdown using pdfplumber (MIT). Returns (md, pages, metadata)."""
        import pdfplumber

        lines: list[str] = []
        with pdfplumber.open(pdf_path) as pdf:
            page_count = len(pdf.pages)
            metadata = pdf.metadata or {}

            for i, page in enumerate(pdf.pages):
                if i > 0:
                    lines.append("\n---\n")

                tables = page.extract_tables() or []
                table_cells: set[str] = set()
                for table in tables:
                    for row in table:
                        for cell in (row or []):
                            if cell:
                                table_cells.add(cell.strip())

                # Extract text (skip content already in tables)
                text = page.extract_text() or ""
                for line in text.strip().split("\n"):
                    line = line.strip()
                    if not line or line in table_cells:
                        continue
                    if len(line) < 80 and line.isupper():
                        lines.append(f"## {line}\n")
                    elif len(line) < 100 and line[:3].replace(".", "").replace(" ", "").isdigit():
                        lines.append(f"### {line}\n")
                    else:
                        lines.append(f"{line}\n")

                # Render tables as markdown
                for table in tables:
                    if not table or not table[0]:
                        continue
                    header = table[0]
                    lines.append("| " + " | ".join(str(c or "").replace("\n", " ") for c in header) + " |")
                    lines.append("| " + " | ".join("---" for _ in header) + " |")
                    for row in table[1:]:
                        lines.append("| " + " | ".join(str(c or "").replace("\n", " ") for c in row) + " |")
                    lines.append("")

        return "\n".join(lines), page_count, metadata

    # ── /api/convert-pdf — upload PDF → convert to Markdown ──────────────

    @app.post("/api/convert-pdf")
    async def api_convert_pdf(
        file: bytes = Body(...),
        filename: str = Query("upload.pdf"),
        engine: str = Query("pdf_oxide"),
    ):
        """Convert uploaded PDF to Markdown.
        Engine: 'pdf_oxide' (MIT, default), 'pdfplumber' (MIT), or 'pymupdf' (AGPL).
        Send raw PDF bytes as body, filename as query param."""
        import tempfile

        if not filename.lower().endswith(".pdf"):
            raise HTTPException(400, "Only PDF files are supported")

        content = file
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        try:
            if engine == "pdf_oxide":
                try:
                    from pdf_oxide import PdfDocument
                except ImportError:
                    raise HTTPException(500, "pdf_oxide not installed. Run: pip install pdf_oxide")
                doc = PdfDocument(tmp_path)
                page_count = doc.page_count()
                md_text = doc.to_markdown_all()
                metadata = {}
                used_engine = "pdf_oxide"
            elif engine == "pymupdf":
                try:
                    import pymupdf4llm
                    import pymupdf
                except ImportError:
                    raise HTTPException(500, "pymupdf4llm not installed. Run: pip install pymupdf4llm")
                md_text = pymupdf4llm.to_markdown(tmp_path)
                doc = pymupdf.open(tmp_path)
                page_count = len(doc)
                metadata = doc.metadata or {}
                doc.close()
                used_engine = "pymupdf4llm"
            else:
                # pdfplumber (MIT license — safe for commercial use)
                try:
                    import pdfplumber
                except ImportError:
                    raise HTTPException(500, "pdfplumber not installed. Run: pip install pdfplumber")
                md_text, page_count, metadata = _pdfplumber_to_markdown(tmp_path)
                used_engine = "pdfplumber"

            word_count = len(md_text.split())
            table_count = md_text.count("|---|")
            image_count = md_text.count("![")

            return {
                "markdown": md_text,
                "filename": filename,
                "converter": used_engine,
                "stats": {
                    "pages": page_count,
                    "words": word_count,
                    "tables": table_count,
                    "images": image_count,
                    "size_bytes": len(content),
                    "title": metadata.get("title", ""),
                    "author": metadata.get("author", ""),
                },
            }
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(500, f"PDF conversion failed: {str(e)}")
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    # ── /api/convert-doc — convert DOCX/PPTX/HTML/PDF via Microsoft markitdown ──

    @app.post("/api/convert-doc")
    async def api_convert_doc(file: bytes = Body(...), filename: str = Query("upload.docx")):
        """Convert uploaded document to Markdown using Microsoft markitdown.
        Supports: PDF, DOCX, PPTX, XLSX, HTML, CSV, JSON, XML, images."""
        import tempfile
        try:
            from markitdown import MarkItDown
        except ImportError:
            raise HTTPException(500, "markitdown not installed. Run: pip install markitdown")

        suffix = Path(filename).suffix.lower()
        supported = {".pdf", ".docx", ".pptx", ".xlsx", ".html", ".htm",
                     ".csv", ".json", ".xml", ".jpg", ".jpeg", ".png",
                     ".txt", ".rtf", ".epub"}
        if suffix not in supported:
            raise HTTPException(400, f"Unsupported format: {suffix}. Supported: {', '.join(sorted(supported))}")

        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp.write(file)
            tmp_path = tmp.name

        try:
            md = MarkItDown()
            result = md.convert(tmp_path)
            md_text = result.text_content or ""

            word_count = len(md_text.split())
            table_count = md_text.count("|---|")

            return {
                "markdown": md_text,
                "filename": filename,
                "converter": "markitdown",
                "stats": {
                    "words": word_count,
                    "tables": table_count,
                    "size_bytes": len(file),
                    "format": suffix.lstrip("."),
                },
            }
        except Exception as e:
            raise HTTPException(500, f"Document conversion failed: {str(e)}")
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    # ── /api/fs/pages — batch read all wiki page metadata (avoids N+1) ──────

    @app.get("/api/fs/pages")
    async def api_fs_pages():
        """Return all wiki pages with frontmatter — single call instead of N reads."""
        import re as _re
        pages = vault.all_pages()
        result = []
        for p in pages:
            try:
                content = p.read_text(encoding="utf-8")
            except OSError:
                continue
            # Extract frontmatter
            fm: dict = {}
            fm_match = _re.match(r"^---\n(.*?)\n---", content, _re.DOTALL)
            if fm_match:
                for line in fm_match.group(1).split("\n"):
                    if ":" in line:
                        key, val = line.split(":", 1)
                        fm[key.strip()] = val.strip().strip("\"'")
            result.append({
                "name": p.name,
                "path": str(p),
                "stem": p.stem,
                "type": fm.get("type", "other"),
                "title": fm.get("title", p.stem),
                "tags": fm.get("tags", ""),
                "project": fm.get("project", ""),
                "origin": fm.get("origin", ""),
            })
        return {"pages": result}

    # ── /api/wiki-graph — server-side graph for Sigma.js ─────────────────────

    @app.get("/api/wiki-graph")
    async def api_wiki_graph():
        """Build full wiki graph server-side (avoids N+1 client reads)."""
        import re as _re
        from llm_wiki.vault.wikilinks import extract_wikilinks

        pages = vault.all_pages()
        nodes_list = []
        edges_list = []
        node_map: dict[str, dict] = {}       # node_id → node
        stem_to_id: dict[str, str] = {}       # stem.lower() → node_id (for wikilink resolution)

        # Build nodes — use stem as ID, add suffix for duplicates
        for p in pages:
            try:
                content = p.read_text(encoding="utf-8")
            except OSError:
                continue

            stem = p.stem
            stem_lower = stem.lower().replace(" ", "-")

            # Unique ID: use stem, add parent prefix for collisions
            node_id = stem_lower
            if node_id in node_map:
                # Collision — use dir/stem format
                parent = p.parent.name.lower()
                node_id = f"{parent}--{stem_lower}"

            # Extract type
            fm_type = "other"
            m = _re.search(r"^type:\s*[\"']?(.+?)[\"']?\s*$", content, _re.MULTILINE | _re.IGNORECASE)
            if m:
                fm_type = m.group(1).strip().lower()
            elif "entities" in p.parts:
                fm_type = "entity"
            elif "concepts" in p.parts:
                fm_type = "concept"
            elif "sources" in p.parts:
                fm_type = "source"
            elif p.name == "overview.md":
                fm_type = "overview"

            # Extract title
            title = stem
            tm = _re.search(r"^title:\s*[\"']?(.+?)[\"']?\s*$", content, _re.MULTILINE | _re.IGNORECASE)
            if tm:
                title = tm.group(1).strip()

            links = extract_wikilinks(content)

            node = {
                "id": node_id,
                "label": title,
                "type": fm_type,
                "path": str(p),
                "linkCount": 0,
                "links": [l.lower().replace(" ", "-") for l in links],
            }
            node_map[node_id] = node
            nodes_list.append(node)

            # Register stem → id mapping (first one wins for wikilink resolution)
            if stem_lower not in stem_to_id:
                stem_to_id[stem_lower] = node_id

        # Build edges using stem_to_id for wikilink resolution
        seen_edges: set[str] = set()
        for node in nodes_list:
            for target_raw in node["links"]:
                # Resolve wikilink target: try exact stem first, then fuzzy
                target_id = stem_to_id.get(target_raw)
                if not target_id:
                    # Try without hyphens
                    normalized = target_raw.replace("-", "")
                    for s, nid in stem_to_id.items():
                        if s.replace("-", "") == normalized:
                            target_id = nid
                            break
                if not target_id or target_id == node["id"]:
                    continue

                edge_key = f"{node['id']}:::{target_id}"
                rev_key = f"{target_id}:::{node['id']}"
                if edge_key not in seen_edges and rev_key not in seen_edges:
                    seen_edges.add(edge_key)
                    edges_list.append({"source": node["id"], "target": target_id, "weight": 1})
                node["linkCount"] = node.get("linkCount", 0) + 1
                node_map[target_id]["linkCount"] = node_map[target_id].get("linkCount", 0) + 1

        # Clean internal links from output
        for n in nodes_list:
            del n["links"]

        result = {
            "nodes": nodes_list,
            "edges": edges_list,
            "communities": [],
            "god_nodes": [],
        }

        # Merge graphify data if available
        try:
            from llm_wiki.pipeline.graphify_integration import load_graphify_output, merge_into_wiki_graph
            gf_out = vault.root / "graphify-out"
            if gf_out.exists():
                gf_report = load_graphify_output(gf_out)
                if gf_report:
                    result = merge_into_wiki_graph(result, gf_report)
                    log.info("Graphify merged: +%d communities, %d god nodes",
                             len(result.get("communities", [])),
                             len(result.get("god_nodes", [])))
        except Exception as e:
            log.warning("Graphify merge failed: %s", e)

        return result

    # ── /api/lint (structural + semantic) ─────────────────────────────────────

    @app.get("/api/lint")
    async def api_lint():
        """Run structural lint and return results."""
        from llm_wiki.pipeline.lint import lint_vault as _lint_vault
        report = _lint_vault(vault)
        return {
            "pages_scanned": report.pages_scanned,
            "health_score": round(report.health_score, 1),
            "orphans": [str(p.relative_to(vault.root)) for p in report.orphans[:20]],
            "broken_links": [
                {"page": p.name, "link": link}
                for p, link in report.broken_links[:20]
            ],
            "missing_entities": [
                {"name": n, "count": c}
                for n, c in report.missing_entities[:20]
            ],
        }

    # ── /api/upload — browser file upload + auto-ingest ──────────────────────

    @app.post("/api/upload")
    async def api_upload(file: bytes = Body(...), filename: str = Query("")):
        """Upload a source file and auto-ingest into wiki."""
        if not filename:
            raise HTTPException(400, "filename required")

        # Save to raw/sources/
        raw_dir = vault.root / "raw" / "sources"
        raw_dir.mkdir(parents=True, exist_ok=True)
        dest = raw_dir / filename
        # Avoid overwrite
        if dest.exists():
            stem = dest.stem
            suffix = dest.suffix
            counter = 1
            while dest.exists():
                dest = raw_dir / f"{stem}-{counter}{suffix}"
                counter += 1
        dest.write_bytes(file)
        log.info("Uploaded: %s (%d bytes)", dest.name, len(file))

        # Auto-ingest (background — don't block response)
        # Snapshot current vault state to avoid race condition if vault is switched
        # while background ingest is running.
        import asyncio
        _bg_vault = vault
        _bg_settings = settings
        _bg_search_index = search_index
        _bg_wiki_graph = wiki_graph
        async def _bg_ingest():
            try:
                from llm_wiki.pipeline.ingest import ingest_source
                llm = create_llm(_bg_settings)
                try:
                    await ingest_source(dest, _bg_vault, llm, _bg_settings)
                finally:
                    await llm.close()
                # Rebuild indexes (only if vault hasn't been switched)
                if vault.root == _bg_vault.root:
                    _bg_search_index.build(_bg_vault)
                    _bg_wiki_graph.build(_bg_vault)
                    log.info("Auto-ingest complete: %s", dest.name)
                else:
                    log.info("Auto-ingest complete for %s but vault was switched, skipping index rebuild", dest.name)
            except Exception as e:
                log.warning("Auto-ingest failed for %s: %s", dest.name, e)

        asyncio.create_task(_bg_ingest())

        return {
            "ok": True,
            "path": str(dest.relative_to(vault.root)),
            "filename": dest.name,
            "size": len(file),
            "status": "ingesting",
        }

    @app.post("/api/fix-links")
    async def api_fix_links():
        """Auto-fix broken wikilinks (fuzzy match + strip)."""
        from llm_wiki.fix_links import fix_vault as _fix_vault
        stats = _fix_vault(vault, apply=True)
        # Rebuild search index after fixes
        search_index.build(vault)
        wiki_graph.build(vault)
        return {
            "kept": stats.get("kept", 0),
            "fixed": stats.get("fixed", 0),
            "stripped": stats.get("stripped", 0),
            "sources_linked": stats.get("sources_linked", 0),
        }

    @app.post("/api/enrich-links")
    async def api_enrich_links():
        """Add missing [[wikilinks]] via LLM."""
        from llm_wiki.pipeline.enrich import enrich_wikilinks
        llm = create_llm(settings)
        try:
            count = await enrich_wikilinks(vault, llm, model=settings.heavy_model, max_pages=30)
        finally:
            await llm.close()
        # Rebuild indexes
        search_index.build(vault)
        wiki_graph.build(vault)
        return {"enriched": count}

    @app.post("/api/semantic-lint")
    async def api_semantic_lint():
        """Run LLM-powered semantic lint (contradictions, stale, missing)."""
        from llm_wiki.pipeline.lint import semantic_lint as _semantic_lint
        llm = create_llm(settings)
        try:
            report = await _semantic_lint(vault, llm, model=settings.heavy_model)
        finally:
            await llm.close()
        return {
            "pages_scanned": report.pages_scanned,
            "issues": [
                {
                    "type": i.issue_type,
                    "severity": i.severity,
                    "title": i.title,
                    "detail": i.detail,
                    "affected_pages": i.affected_pages,
                }
                for i in report.issues
            ],
            "tokens": {
                "input": report.input_tokens,
                "output": report.output_tokens,
            },
        }

    # ── CGC Code Intelligence API ──────────────────────────────────────────

    @app.post("/api/cgc/upload")
    async def api_cgc_upload(
        file: bytes = Body(...),
        filename: str = Query("repo.zip"),
    ):
        """Upload ZIP repo, extract to temp, return repo_id + basic stats."""
        import uuid
        import zipfile
        import io
        import shutil
        import time as _time
        from collections import Counter
        from llm_wiki.code.extractor import scan_repo as _scan_repo

        t_upload_start = _time.time()

        # Cleanup old temp dirs (keep max 2 most recent)
        cgc_temp_root = vault.root / ".cgc_temp"
        if cgc_temp_root.exists():
            old_dirs = sorted(
                [d for d in cgc_temp_root.iterdir() if d.is_dir()],
                key=lambda d: d.stat().st_mtime,
            )
            for old_dir in old_dirs[:-1]:  # keep only newest
                try:
                    shutil.rmtree(old_dir)
                    log.info("Cleaned up stale temp dir: %s", old_dir.name)
                except OSError:
                    pass

        repo_id = uuid.uuid4().hex[:12]
        temp_root = vault.root / ".cgc_temp" / repo_id
        temp_root.mkdir(parents=True, exist_ok=True)

        # Extract ZIP
        try:
            with zipfile.ZipFile(io.BytesIO(file)) as zf:
                zf.extractall(temp_root)
        except zipfile.BadZipFile:
            raise HTTPException(400, "Invalid ZIP file")

        # Detect repo root (if ZIP has single top-level dir)
        children = [p for p in temp_root.iterdir() if p.name != "__MACOSX"]
        if len(children) == 1 and children[0].is_dir():
            repo_path = children[0]
        else:
            repo_path = temp_root

        repo_name = repo_path.name if repo_path != temp_root else filename.replace(".zip", "")

        # Scan for stats
        try:
            files = _scan_repo(repo_path)
        except Exception:
            files = []

        lang_counter: Counter = Counter()
        for f in files:
            ext = f.path.rsplit(".", 1)[-1] if "." in f.path else "other"
            lang_counter[ext] += 1

        # Check CGC availability (import only, no DB connection)
        try:
            from codegraphcontext.tools.graph_builder import GraphBuilder  # noqa: F401
            cgc_available = True
        except Exception as e:
            log.warning("CGC not available: %s", e)
            cgc_available = False

        t_upload = _time.time() - t_upload_start
        log.info("[CGC-TIMING] Upload+extract: %.1fs (repo=%s, files=%d, size=%.1fMB)",
                 t_upload, repo_name, len(files),
                 sum(f.size_bytes for f in files) / 1024 / 1024)

        return {
            "repo_id": repo_id,
            "repo_name": repo_name,
            "repo_path": str(repo_path),
            "stats": {
                "files": len(files),
                "dirs": len(set(f.path.rsplit("/", 1)[0] for f in files if "/" in f.path)),
                "languages": dict(lang_counter.most_common(20)),
                "total_size_bytes": sum(f.size_bytes for f in files),
            },
            "cgc_available": cgc_available,
            "upload_duration_sec": round(t_upload, 2),
        }

    @app.post("/api/cgc/index")
    async def api_cgc_index(repo_id: str = Body(..., embed=True)):
        """Run CGC indexing on extracted repo. Returns SSE progress stream."""
        from llm_wiki.code.cgc_bridge import CGCBridge

        temp_root = vault.root / ".cgc_temp" / repo_id
        if not temp_root.exists():
            raise HTTPException(404, f"Repo {repo_id} not found")

        # Find repo_path
        children = [p for p in temp_root.iterdir() if p.name != "__MACOSX"]
        repo_path = children[0] if len(children) == 1 and children[0].is_dir() else temp_root

        db_marker_path = temp_root / ".cgc_db.indexed"  # marker only, not DB path

        async def event_stream():
            yield f"data: {json.dumps({'phase': 'start', 'message': 'Starting CGC indexing...'})}\n\n"

            cgc = CGCBridge(repo_path)  # use global DB
            if not cgc.available:
                yield f"data: {json.dumps({'phase': 'error', 'message': cgc.init_error or 'CGC unavailable'})}\n\n"
                return

            progress_queue: asyncio.Queue = asyncio.Queue()

            def on_index_progress(current: int, total: int, message: str):
                progress_queue.put_nowait({
                    "phase": "indexing", "current": current, "total": total,
                    "message": message,
                })

            import time
            t0 = time.time()
            log.info("[CGC] Index start: repo=%s path=%s", repo_id, repo_path)

            # Run indexing in background task so we can drain progress
            task = asyncio.create_task(cgc.ensure_indexed(on_progress=on_index_progress))

            while not task.done():
                try:
                    evt = await asyncio.wait_for(progress_queue.get(), timeout=5.0)
                    yield f"data: {json.dumps(evt)}\n\n"
                except asyncio.TimeoutError:
                    # Send SSE keepalive comment to prevent browser/proxy timeout
                    yield ": keepalive\n\n"

            # Drain remaining events
            while not progress_queue.empty():
                evt = progress_queue.get_nowait()
                yield f"data: {json.dumps(evt)}\n\n"

            duration = round(time.time() - t0, 1)
            indexed = task.result()

            if indexed:
                db_marker_path.parent.mkdir(parents=True, exist_ok=True)
                db_marker_path.write_text(str(repo_path))
                log.info("[CGC] Index done: repo=%s duration=%.1fs", repo_id, duration)
                yield f"data: {json.dumps({'phase': 'done', 'indexed': True, 'duration_sec': duration})}\n\n"
            else:
                warnings = cgc.warnings
                msg = warnings[-1] if warnings else "Indexing failed"
                log.warning("[CGC] Index failed: repo=%s duration=%.1fs msg=%s", repo_id, duration, msg)
                yield f"data: {json.dumps({'phase': 'error', 'message': msg})}\n\n"

            cgc.close()

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    @app.get("/api/cgc/preview/{repo_id}")
    async def api_cgc_preview(repo_id: str):
        """Return CGC intelligence preview data (free, no LLM)."""
        from llm_wiki.code.cgc_bridge import CGCBridge
        from llm_wiki.code.extractor import scan_repo as _scan_repo
        from collections import Counter

        temp_root = vault.root / ".cgc_temp" / repo_id
        if not temp_root.exists():
            raise HTTPException(404, f"Repo {repo_id} not found")

        children = [p for p in temp_root.iterdir() if p.name not in ("__MACOSX", ".cgc_db", ".cgc_db.indexed")]
        repo_path = children[0] if len(children) == 1 and children[0].is_dir() else temp_root

        cgc = CGCBridge(repo_path)
        if not cgc.available:
            raise HTTPException(503, "CGC not available")

        # Gather data
        stats = cgc.get_all_stats()
        top_connected = cgc.get_top_connected(limit=10)

        files = _scan_repo(repo_path)
        all_file_paths = [f.path for f in files]
        operational_params = cgc.get_operational_params(all_file_paths)

        class_names = [s for f in files for s in f.symbols if s and s[0].isupper()]
        class_hierarchies = cgc.get_class_hierarchies(class_names[:30])

        # Language breakdown
        lang_counter: Counter = Counter()
        for f in files:
            ext = f.path.rsplit(".", 1)[-1] if "." in f.path else "other"
            lang_counter[ext] += 1

        # Module suggestions based on top-level dirs
        dir_groups: dict[str, list[str]] = {}
        for f in files:
            parts = f.path.split("/")
            group_name = parts[0] if len(parts) > 1 else "(root)"
            dir_groups.setdefault(group_name, []).append(f.path)

        modules_suggestion = [
            {"name": name, "files": paths, "file_count": len(paths), "selected": True}
            for name, paths in sorted(dir_groups.items(), key=lambda x: -len(x[1]))
        ]

        # Cost estimate based on actual model pricing
        n_modules = max(len(modules_suggestion), 1)
        est_input = len(files) * 800 + n_modules * 4000  # source + prompt tokens
        est_output = n_modules * 1200  # ~1200 output tokens per module doc
        est_tokens = est_input + est_output

        # Model pricing (per 1M tokens)
        MODEL_PRICING = {
            # Gemini 3.x
            "gemini-3.1-flash-lite": (0.01, 0.04),
            "gemini-3.1-flash-lite-preview": (0.01, 0.04),
            "gemini-3-flash-preview": (0.05, 0.20),
            # Gemini 2.x
            "gemini-2.5-flash-lite": (0.01, 0.04),
            "gemini-2.5-flash": (0.15, 0.60),
            "gemini-2.0-flash": (0.10, 0.40),
            "gemini-2.0-flash-lite": (0.01, 0.04),
            # OpenAI compatible
            "gpt-4o-mini": (0.15, 0.60),
            "gpt-4o": (2.50, 10.00),
        }
        model_name = settings.fast_model or settings.heavy_model or ""
        input_price, output_price = MODEL_PRICING.get(model_name, (0.01, 0.04))
        est_cost = (est_input / 1_000_000 * input_price) + (est_output / 1_000_000 * output_price)
        est_time = n_modules * 0.3  # ~20s per module

        # Execution flows + routes
        execution_flows = cgc.get_execution_flows(limit=50)
        api_routes = cgc.get_routes(limit=200)

        cgc.close()

        return {
            "repo_id": repo_id,
            "repo_name": repo_path.name,
            "stats": {**stats, "languages": dict(lang_counter.most_common(20))},
            "top_connected": top_connected,
            "execution_flows": [
                {
                    "name": f["name"],
                    "entry_file": f["entry_file"],
                    "entry_class": f.get("entry_class", ""),
                    "step_count": f["step_count"],
                    "depth": f["depth"],
                    "score": f["score"],
                    "steps": [s["name"] for s in f.get("steps", [])[:8]],
                }
                for f in execution_flows
            ],
            "api_routes": api_routes,
            "operational_params": [
                {**p, "value": str(p.get("value", ""))[:200]} for p in operational_params[:30]
            ],
            "class_hierarchies": class_hierarchies[:20],
            "modules_suggestion": modules_suggestion,
            "estimate": {
                "tokens": est_tokens,
                "cost_usd": round(est_cost, 4),
                "time_minutes": round(est_time, 1),
            },
            "warnings": cgc.warnings,
        }

    @app.get("/api/cgc/graph/{repo_id}")
    async def api_cgc_graph(repo_id: str, limit: int = 300):
        """Return CGC call graph as nodes + edges for Sigma.js visualization."""
        from llm_wiki.code.cgc_bridge import CGCBridge

        temp_root = vault.root / ".cgc_temp" / repo_id
        if not temp_root.exists():
            raise HTTPException(404, f"Repo {repo_id} not found")

        db_marker = temp_root / ".cgc_db.indexed"
        if not db_marker.exists():
            raise HTTPException(404, f"Repo {repo_id} not indexed yet")

        children = [p for p in temp_root.iterdir() if p.name not in ("__MACOSX", ".cgc_db", ".cgc_db.indexed")]
        repo_path = children[0] if len(children) == 1 and children[0].is_dir() else temp_root

        # Use global DB (CGC writes to ~/.codegraphcontext/global/kuzudb)
        cgc = CGCBridge(repo_path)
        if not cgc.available:
            raise HTTPException(503, "CGC not available")

        try:
            # Use CGCBridge.get_top_connected() which handles all CALLS types
            top = cgc.get_top_connected(limit=limit)
            repo_str = str(repo_path)

            def _rel(abs_path: str) -> str:
                try:
                    return str(Path(abs_path).relative_to(repo_str))
                except ValueError:
                    return Path(abs_path).name

            nodes = []
            node_ids = set()
            node_name_set = set()  # for edge matching

            # Track name occurrences to detect duplicates needing disambiguation
            name_count: dict[str, int] = {}
            for fn in top:
                name_count[fn["name"]] = name_count.get(fn["name"], 0) + 1

            for fn in top:
                rel_path = fn.get("path", "")
                nid = f"{fn['name']}@{rel_path}:{fn.get('line', 0)}"
                if nid in node_ids:
                    continue
                node_ids.add(nid)
                node_name_set.add(fn["name"])
                link_count = fn.get("callers", 0) + fn.get("callees", 0)
                # Disambiguate label when multiple functions share the same name
                label = fn["name"]
                if name_count.get(fn["name"], 0) > 1 and rel_path:
                    parent_dir = Path(rel_path).parent.name
                    if parent_dir and parent_dir != ".":
                        label = f"{fn['name']} ({parent_dir})"
                nodes.append({
                    "id": nid,
                    "label": label,
                    "type": "function",
                    "path": rel_path,
                    "file": Path(rel_path).parts[0] if "/" in rel_path else rel_path,
                    "linkCount": link_count,
                })

            # Add top classes (by method count) and class→method containment edges
            class_method_edges: list[tuple[str, str]] = []  # (class_nid, method_nid)
            duck = cgc._get_duckdb()
            if duck:
                try:
                    # Find ALL classes with methods (skip minified/vendor)
                    cls_rows = duck.execute("""
                        SELECT class_context AS cls_name, path,
                               count(*) AS method_count
                        FROM functions
                        WHERE class_context != '' AND class_context IS NOT NULL
                          AND path NOT LIKE '%.min.js'
                          AND path NOT LIKE '%vendor%'
                          AND path NOT LIKE '%node_modules%'
                        GROUP BY class_context, path
                        HAVING count(*) >= 2
                        ORDER BY method_count DESC
                    """).fetchall()
                    for cls_name, cls_path, method_count in cls_rows:
                        rel_path = _rel(cls_path) if cls_path else cls_name
                        cls_nid = f"{cls_name}@{rel_path}:0"
                        if cls_nid not in node_ids:
                            node_ids.add(cls_nid)
                            parent = Path(rel_path).parent.name if "/" in rel_path else ""
                            label = f"{cls_name} ({parent})" if parent else cls_name
                            nodes.append({
                                "id": cls_nid, "label": label,
                                "type": "class", "path": rel_path,
                                "file": Path(rel_path).name if rel_path else cls_name,
                                "linkCount": method_count,
                            })

                        # Find methods of this class that are in graph nodes
                        # Node IDs use line=0 (from get_top_connected), so match by name@path:0
                        methods = duck.execute("""
                            SELECT DISTINCT name, path FROM functions
                            WHERE class_context = ? AND path = ?
                        """, [cls_name, cls_path]).fetchall()
                        for m_name, m_path in methods:
                            m_rel = _rel(m_path)
                            m_nid = f"{m_name}@{m_rel}:0"
                            if m_nid in node_ids and m_nid != cls_nid:
                                class_method_edges.append((cls_nid, m_nid))
                    log.info("[CGC-GRAPH] Added %d class nodes, %d class→method edges",
                             sum(1 for n in nodes if n.get("type") == "class"),
                             len(class_method_edges))
                except Exception as exc:
                    log.warning("[CGC-GRAPH] Class query failed: %s", exc)
                finally:
                    duck.close()

            # Build name|path→nid lookup for edge matching (path-aware to avoid collisions)
            namepath_to_nid: dict[str, str] = {}  # "funcName|rel/path" → nid
            name_to_nids: dict[str, list[str]] = {}  # "funcName" → [nid, ...] (fallback)
            for n in nodes:
                key = f"{n['label']}|{n['path']}"
                namepath_to_nid[key] = n["id"]
                name_to_nids.setdefault(n["label"], []).append(n["id"])

            def _resolve_nid(name: str, abs_path: str) -> str | None:
                """Resolve a node id by name+path, falling back to name-only if unique."""
                rel = _rel(abs_path) if abs_path else ""
                key = f"{name}|{rel}"
                nid = namepath_to_nid.get(key)
                if nid:
                    return nid
                # Fallback: name-only match if unambiguous
                nids = name_to_nids.get(name, [])
                return nids[0] if len(nids) == 1 else None

            # Query edges — try DuckDB first, then KuzuDB
            edges = []
            edge_seen = set()
            edge_rows = cgc.get_duckdb_edges(limit=3000)
            if not edge_rows:
                # Fallback: KuzuDB Cypher
                try:
                    driver = cgc._db_manager.get_driver()
                    with driver.session() as session:
                        for r in session.run(
                            "MATCH (a)-[:CALLS]->(b) "
                            "RETURN a.name AS src, a.path AS src_path, "
                            "       b.name AS tgt, b.path AS tgt_path "
                            "LIMIT 20000"
                        ):
                            edge_rows.append({
                                "src": r.get("src", ""), "src_path": r.get("src_path", ""),
                                "tgt": r.get("tgt", ""), "tgt_path": r.get("tgt_path", ""),
                            })
                except Exception as exc:
                    log.warning("CGC KuzuDB edge query failed: %s", exc)

            try:
                for r in edge_rows:
                    src_name = r.get("src", "")
                    tgt_name = r.get("tgt", "")
                    src_path = r.get("src_path", "")
                    tgt_path = r.get("tgt_path", "")

                    src_id = _resolve_nid(src_name, src_path)
                    tgt_id = _resolve_nid(tgt_name, tgt_path)

                    if src_id and tgt_id and src_id != tgt_id:
                        ek = f"{src_id}→{tgt_id}"
                        if ek not in edge_seen:
                            edge_seen.add(ek)
                            edges.append({"source": src_id, "target": tgt_id, "weight": r.get("weight", 1)})
                    elif not src_id and tgt_id:
                        src_rel = _rel(src_path) if src_path else src_name
                        src_key = f"{src_name}|{src_rel}"
                        src_type = r.get("src_type", "function").lower()
                        node_type = "class" if src_type == "class" else "function"
                        if src_key not in namepath_to_nid and src_name and len(src_name) > 2:
                            src_nid = f"{src_name}@{src_rel}:0"
                            if src_nid not in node_ids:
                                node_ids.add(src_nid)
                                namepath_to_nid[src_key] = src_nid
                                parent = Path(src_rel).parent.name if "/" in src_rel else ""
                                label = f"{src_name} ({parent})" if parent else src_name
                                nodes.append({
                                    "id": src_nid, "label": label,
                                    "type": node_type, "path": src_rel,
                                    "file": src_name, "linkCount": 1,
                                })
                            else:
                                src_nid = namepath_to_nid.get(src_key, src_nid)
                            ek = f"{src_nid}→{tgt_id}"
                            if ek not in edge_seen:
                                edge_seen.add(ek)
                                edges.append({"source": src_nid, "target": tgt_id, "weight": 1})
                    elif src_id and not tgt_id:
                        # Target not in top connected — create lightweight node
                        tgt_rel = _rel(tgt_path) if tgt_path else tgt_name
                        tgt_key = f"{tgt_name}|{tgt_rel}"
                        tgt_type = r.get("tgt_type", "function").lower()
                        node_type = "class" if tgt_type == "class" else "function"
                        if tgt_key not in namepath_to_nid and tgt_name and len(tgt_name) > 2:
                            tgt_nid = f"{tgt_name}@{tgt_rel}:0"
                            if tgt_nid not in node_ids:
                                node_ids.add(tgt_nid)
                                namepath_to_nid[tgt_key] = tgt_nid
                                parent = Path(tgt_rel).parent.name if "/" in tgt_rel else ""
                                label = f"{tgt_name} ({parent})" if parent else tgt_name
                                nodes.append({
                                    "id": tgt_nid, "label": label,
                                    "type": node_type, "path": tgt_rel,
                                    "file": tgt_name, "linkCount": 1,
                                })
                            else:
                                tgt_nid = namepath_to_nid.get(tgt_key, tgt_nid)
                            ek = f"{src_id}→{tgt_nid}"
                            if ek not in edge_seen:
                                edge_seen.add(ek)
                                edges.append({"source": src_id, "target": tgt_nid, "weight": 1})
            except Exception as exc:
                log.warning("CGC graph edge query failed: %s", exc)

            # Add class→method containment edges
            for cls_nid, m_nid in class_method_edges:
                ek = f"{cls_nid}→{m_nid}"
                if ek not in edge_seen:
                    edge_seen.add(ek)
                    edges.append({"source": cls_nid, "target": m_nid, "weight": 1})

            # Remove orphan function nodes; keep all classes (OOP architecture)
            connected_ids = set()
            for e in edges:
                connected_ids.add(e["source"])
                connected_ids.add(e["target"])
            nodes = [n for n in nodes if n["id"] in connected_ids or n.get("type") == "class"]

            cgc.close()
            return {"nodes": nodes, "edges": edges}

        except Exception as exc:
            cgc.close()
            raise HTTPException(500, str(exc))

    @app.post("/api/cgc/process/{repo_id}")
    async def api_cgc_process(
        repo_id: str,
        selected_dirs: list[str] | None = Body(default=None, embed=True),
    ):
        """Run ingest-code pipeline with LLM. Returns SSE progress stream."""
        from llm_wiki.pipeline.ingest_code import ingest_code as _ingest_code

        temp_root = vault.root / ".cgc_temp" / repo_id
        if not temp_root.exists():
            raise HTTPException(404, f"Repo {repo_id} not found")

        children = [p for p in temp_root.iterdir()
                    if p.name not in ("__MACOSX", ".cgc_db", ".cgc_db.indexed", ".DS_Store")
                    and not p.name.startswith(".")]
        repo_path = children[0] if len(children) == 1 and children[0].is_dir() else temp_root

        settings.cgc_enabled = True
        settings.cgc_db_path = str(temp_root / ".cgc_db")

        async def event_stream():
            progress_queue: asyncio.Queue = asyncio.Queue()

            def on_progress(phase: str, data: dict):
                progress_queue.put_nowait({"phase": phase, **data})

            llm = create_llm(settings)
            try:
                yield f"data: {json.dumps({'phase': 'start', 'message': 'Starting code-to-doc pipeline...'})}\n\n"

                # Run pipeline in background task so we can drain queue
                # Output to projects/{repo_name}/ subfolder for proper isolation
                project_output = f"wiki/projects/{repo_path.name}/outputs/code"
                task = asyncio.create_task(_ingest_code(
                    repo_path=repo_path,
                    vault_root=vault.root,
                    llm=llm,
                    settings=settings,
                    project_name=repo_path.name,
                    output_subdir=project_output,
                    on_progress=on_progress,
                    include_dirs=selected_dirs,
                ))

                # Drain progress events while pipeline runs
                while not task.done():
                    try:
                        evt = await asyncio.wait_for(progress_queue.get(), timeout=5.0)
                        yield f"data: {json.dumps(evt)}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"

                # Drain remaining events
                while not progress_queue.empty():
                    evt = progress_queue.get_nowait()
                    yield f"data: {json.dumps(evt)}\n\n"

                result = task.result()
                yield f"data: {json.dumps({'phase': 'complete', 'modules': len(result.modules), 'tokens': result.token_usage.get('total', 0)})}\n\n"

                # Rebuild search index + graph
                nonlocal search_index, wiki_graph
                search_index = WikiSearchIndex()
                search_index.build(vault)
                wiki_graph = WikiGraph()
                wiki_graph.build(vault)
                log.info("Search index + wiki graph rebuilt after CGC process")

            except Exception as exc:
                yield f"data: {json.dumps({'phase': 'error', 'message': str(exc)})}\n\n"
            finally:
                await llm.close()

            # Cleanup temp
            import shutil
            try:
                shutil.rmtree(temp_root)
                log.info("Cleaned up temp dir: %s", temp_root)
            except Exception:
                pass

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    # ── Resolve wiki page name → full path ─────────────────────────────────
    @app.get("/api/resolve-page")
    def resolve_page(name: str, context: str = ""):
        """Find a wiki page by name, searching all directories."""
        import re
        from urllib.parse import unquote
        # Decode URL-encoded characters (handles double-encoding)
        decoded = unquote(unquote(name))
        target = decoded.replace(".md", "").strip()
        slug = re.sub(r"\s+", "-", target).lower()
        # Also try dashes→spaces (e.g. "Người-sử-dụng" → "Người sử dụng")
        unslug = target.replace("-", " ")
        wiki_dir = vault.root / "wiki"

        # All name variants to try
        variants = list(dict.fromkeys([
            target,           # exact as received
            slug,             # lowercase-dashed
            unslug,           # dashes→spaces
            target.lower(),   # lowercase exact
            unslug.lower(),   # lowercase spaces
        ]))

        # Search dirs
        search_dirs = ["concepts", "entities", "sources", "projects", ""]
        if context:
            ctx_dir = context.replace(".md", "")
            ctx_dir = "/".join(ctx_dir.split("/")[:-1]) if "/" in ctx_dir else ""
            if ctx_dir:
                search_dirs.insert(0, ctx_dir)

        for d in search_dirs:
            base = wiki_dir / d if d else wiki_dir
            if not base.exists():
                continue
            # Try direct file matches
            for v in variants:
                p = base / f"{v}.md"
                if p.exists():
                    return {"found": True, "path": str(p)}

        # Fallback: rglob case-insensitive across all wiki
        variant_set = {v.lower() for v in variants}
        for p in wiki_dir.rglob("*.md"):
            stem_lower = p.stem.lower()
            stem_slug = re.sub(r"\s+", "-", stem_lower)
            if stem_lower in variant_set or stem_slug in variant_set:
                return {"found": True, "path": str(p)}

        return {"found": False, "path": None, "searched": target}

    # ── Static files + SPA fallback ───────────────────────────────────────────

    if static_dir and static_dir.exists():
        index_html = static_dir / "index.html"

        @app.get("/")
        def root():
            return RedirectResponse(url="/wiki/")

        @app.get("/wiki/{path:path}")
        def spa_route(path: str):
            return FileResponse(index_html)

        # Mount assets AFTER explicit routes
        app.mount("/assets", StaticFiles(directory=static_dir / "assets"), name="assets")

        @app.get("/favicon.svg")
        def favicon():
            f = static_dir / "favicon.svg"
            return FileResponse(f) if f.exists() else JSONResponse({}, status_code=404)

    return app
