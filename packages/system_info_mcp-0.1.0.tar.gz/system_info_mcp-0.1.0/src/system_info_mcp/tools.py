# src/system_info_mcp/tools.py
import platform
import os
import shutil
from typing import Dict, Any


def get_system_info() -> Dict[str, Any]:
    """获取系统基本信息并返回JSON。兼容 Windows/Darwin/Linux。"""
    try:
        # 获取shell信息
        shell = ""
        system = platform.system()
        if system == "Windows":
            shell = os.environ.get("COMSPEC", "cmd.exe")
            # 尝试检测 PowerShell
            if "powershell" in os.environ.get("PSModulePath", "").lower():
                shell = "powershell.exe"
        else:  # Unix-like (Darwin, Linux)
            shell = os.environ.get("SHELL", "")
            # 如果SHELL为空，尝试检测默认shell
            if not shell and shutil.which("bash"):
                shell = shutil.which("bash")
            elif not shell and shutil.which("sh"):
                shell = shutil.which("sh")

        return {
            "os": system,
            "os_version": platform.version(),
            "os_release": platform.release(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "shell": shell,
        }
    except Exception as e:
        return {
            "error": "Failed to get system info",
            "details": str(e),
            "suggestion": "Check system permissions or platform compatibility",
        }
