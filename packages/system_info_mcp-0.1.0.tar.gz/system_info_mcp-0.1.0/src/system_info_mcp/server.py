# src/system_info_mcp/server.py
from fastmcp import FastMCP
from .tools import get_system_info

mcp = FastMCP("system-info")
mcp.tool()(get_system_info)

if __name__ == "__main__":
    mcp.run()
