# System Info MCP Server

A Model Context Protocol (MCP) server that provides system information tools.

## Features

- Cross-platform support (Windows, macOS, Linux)
- Basic system information: OS, architecture, shell
- FastMCP-based implementation
- Comprehensive error handling

## Installation

```bash
uv sync
```

## Usage

```bash
uv run python -m system_info_mcp.server
```

## Development

```bash
# Install dependencies
uv sync

# Run tests
pytest tests/ -v

# Format code
ruff format src/ tests/
```

## Tool Specification

**Tool Name:** `get_system_info`

**Description:** 获取系统基本信息并返回JSON

**Response Format:**
```json
{
  "os": "Darwin",
  "os_version": "Darwin Kernel Version 23.4.0",
  "os_release": "23.4.0",
  "architecture": "arm64",
  "processor": "arm",
  "shell": "/bin/zsh"
}
```