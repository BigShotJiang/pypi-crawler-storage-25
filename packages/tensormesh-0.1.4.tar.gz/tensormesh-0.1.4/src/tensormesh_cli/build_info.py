from __future__ import annotations

PACKAGE_NAME = "tensormesh"
REQUIRES_PYTHON = ">=3.12"
DISTRIBUTION_MODEL = "standalone-binary"
INSTALL_GUIDE = "/cli/guides/installation"
VERSION_SOURCE = "tensormesh.build_info.__version__"
PUBLIC_RELEASE_REPO = "Tensormesh-Production/tensormesh-sdk"
INSTALLER_PATH = "scripts/install-tm.sh"
