from __future__ import annotations

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def test_cli_installation_guide_prefers_pypi_for_combined_sdk_and_cli_install(
) -> None:
    text = (REPO_ROOT / "docs" / "cli" / "guides" /
            "installation.mdx").read_text(encoding="utf-8")

    assert "official one-click install path for the SDK and bundled CLI" in text
    assert "Install with pip when you want the Python SDK and `tm` together." in text
    assert "curl -fsSL" in text
    assert "install-tm.sh" in text
    assert "If your release channel publishes standalone CLI binaries" in text
    assert "GitHub Releases remain the supported alternate CLI-only install surface." not in text


def test_sdk_index_keeps_pypi_as_primary_install_surface() -> None:
    text = (REPO_ROOT / "docs" / "sdk" /
            "index.mdx").read_text(encoding="utf-8")

    assert "pip install tensormesh" in text
    assert "The SDK and `tm` CLI ship in the same Python distribution." in text
    assert "CLI is distributed separately" not in text
