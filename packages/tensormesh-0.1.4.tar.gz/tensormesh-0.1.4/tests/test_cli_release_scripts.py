from __future__ import annotations

import json
from pathlib import Path
import subprocess
import textwrap
import tomllib

import yaml

from tensormesh.build_info import __version__
from tests.script_test_utils import load_script_module

REPO_ROOT = Path(__file__).resolve().parents[1]
RELEASE_READINESS_SCRIPT = REPO_ROOT / "scripts" / "check-release-readiness.py"


def test_build_and_smoke_test_cli_dist_scripts() -> None:
    dist_dir = REPO_ROOT / "dist" / "python-test"

    build = subprocess.run(
        ["./scripts/build-python-dist.sh",
         str(dist_dir)],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert build.returncode == 0, build.stderr

    wheel_paths = sorted(dist_dir.glob("*.whl"))
    assert wheel_paths
    assert (dist_dir / "SHA256SUMS").exists()
    manifest_path = dist_dir / "RELEASE-MANIFEST.json"
    assert manifest_path.exists()

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest["surface"] == "sdk"
    assert manifest["package_name"] == "tensormesh"
    assert manifest["package_version"] == __version__
    assert manifest["cli_version"] == __version__
    assert manifest["manifest_version"] == 2
    assert manifest["git_tag"] == f"v{__version__}"
    assert manifest["requires_python"] == ">=3.12"
    assert manifest["distribution_model"] == "pypi"
    assert manifest["install_guide"] == "/cli/guides/installation"
    assert manifest["changelog_path"] == "CHANGELOG.md"
    assert manifest["release_policy_path"] == "dev/sdk-release-policy.md"
    assert manifest["artifacts"][0]["filename"] == wheel_paths[-1].name
    assert not (REPO_ROOT / "build").exists()

    smoke = subprocess.run(
        ["./scripts/smoke-test-python-dist.sh",
         str(wheel_paths[-1])],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert smoke.returncode == 0, smoke.stderr
    assert "ok: smoke-tested" in smoke.stdout
    assert "help" in smoke.stdout
    assert "client construction" in smoke.stdout

    build_sdist = subprocess.run(
        ["./scripts/build-python-sdist.sh",
         str(dist_dir)],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert build_sdist.returncode == 0, build_sdist.stderr

    sdist_paths = sorted(dist_dir.glob("*.tar.gz"))
    assert sdist_paths

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    artifact_names = {item["filename"] for item in manifest["artifacts"]}
    assert wheel_paths[-1].name in artifact_names
    assert sdist_paths[-1].name in artifact_names

    checksums = (dist_dir / "SHA256SUMS").read_text(encoding="utf-8")
    assert wheel_paths[-1].name in checksums
    assert sdist_paths[-1].name in checksums

    smoke_sdist = subprocess.run(
        ["./scripts/smoke-test-python-sdist.sh",
         str(sdist_paths[-1])],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert smoke_sdist.returncode == 0, smoke_sdist.stderr
    assert "ok: smoke-tested" in smoke_sdist.stdout
    assert "help" in smoke_sdist.stdout
    assert "client construction" in smoke_sdist.stdout


def test_release_workflow_builds_and_publishes_sdk_and_cli_dist() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "release.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    build_sdk_job = payload["jobs"]["build-sdk"]
    build_cli_job = payload["jobs"]["build-cli"]
    release_job = payload["jobs"]["release"]
    publish_job = payload["jobs"]["publish-pypi"]
    sdk_steps = build_sdk_job["steps"]
    sdk_by_name = {
        step["name"]: step
        for step in sdk_steps if isinstance(step, dict) and "name" in step
    }

    assert sdk_by_name["Build Python dist artifacts"][
        "run"] == "./scripts/build-python-dist.sh dist/python"
    assert sdk_by_name["Smoke test Python dist artifacts"][
        "run"] == "./scripts/smoke-test-python-dist.sh"
    assert sdk_by_name["Smoke test published Python wheel artifact"][
        "run"] == "./scripts/smoke-test-python-dist.sh dist/python/*.whl"
    assert sdk_by_name["Smoke test Python source distributions"][
        "run"] == "./scripts/smoke-test-python-sdist.sh dist/python/*.tar.gz"
    assert sdk_by_name["Check SDK release readiness"]["run"] == (
        'python ./scripts/check-release-readiness.py --tag "${{ github.ref_name }}" '
        '--dist-dir dist/python --require-artifacts --surface sdk')
    assert sdk_by_name["Upload verified Python distributions"]["with"][
        "name"] == "verified-python-dist-${{ github.ref_name }}"
    assert sdk_by_name["Upload verified Python distributions"]["with"][
        "path"] == "dist/python"

    cli_steps = build_cli_job["steps"]
    cli_by_name = {
        step["name"]: step
        for step in cli_steps if isinstance(step, dict) and "name" in step
    }
    assert build_cli_job["strategy"]["matrix"]["include"] == [
        {
            "runner": "ubuntu-latest",
            "platform": "linux-amd64",
        },
        {
            "runner": "ubuntu-24.04-arm",
            "platform": "linux-arm64",
        },
        {
            "runner": "macos-15-intel",
            "platform": "darwin-amd64",
        },
        {
            "runner": "macos-14",
            "platform": "darwin-arm64",
        },
    ]
    assert cli_by_name["Build CLI dist artifacts"][
        "run"] == "./scripts/build-cli-dist.sh dist/cli"
    assert cli_by_name["Smoke test CLI dist artifacts"][
        "run"] == "./scripts/smoke-test-cli-dist.sh"
    assert cli_by_name["Check CLI release readiness"]["run"] == (
        'python ./scripts/check-release-readiness.py --tag "${{ github.ref_name }}" '
        '--dist-dir dist/cli --require-artifacts --surface cli')
    assert cli_by_name["Upload verified CLI artifacts"]["with"][
        "name"] == "verified-cli-dist-${{ matrix.platform }}-${{ github.ref_name }}"
    assert cli_by_name["Upload verified CLI artifacts"]["with"][
        "path"] == "dist/cli/tm-*.tar.gz"

    steps = release_job["steps"]
    step_by_name = {
        step["name"]: step
        for step in steps if isinstance(step, dict) and "name" in step
    }

    assert release_job["needs"] == ["build-sdk", "build-cli"]
    assert step_by_name["Download verified Python distributions"][
        "uses"] == "actions/download-artifact@v4"
    assert step_by_name["Download verified Python distributions"]["with"][
        "name"] == "verified-python-dist-${{ github.ref_name }}"
    assert step_by_name["Download verified Python distributions"]["with"][
        "path"] == "dist/python"
    assert step_by_name["Download verified CLI artifacts"][
        "uses"] == "actions/download-artifact@v4"
    assert step_by_name["Download verified CLI artifacts"]["with"][
        "pattern"] == "verified-cli-dist-*-${{ github.ref_name }}"
    assert step_by_name["Download verified CLI artifacts"]["with"][
        "path"] == "dist/cli"
    assert step_by_name["Download verified CLI artifacts"]["with"][
        "merge-multiple"] is True
    assert step_by_name["Generate CLI release manifest"][
        "run"] == "python ./scripts/build-cli-release-manifest.py dist/cli"
    assert step_by_name["Write CLI checksums"]["run"] == (
        "python ./scripts/write-sha256sums.py dist/cli 'tm-*.tar.gz'")
    assert "CHANGELOG.md" in step_by_name["Package repo snapshot"]["run"]

    release_step = step_by_name["Create GitHub release"]
    files = release_step["with"]["files"]
    assert "dist/python/*.whl" in files
    assert "dist/python/*.tar.gz" in files
    assert "dist/python/SHA256SUMS" in files
    assert "dist/python/RELEASE-MANIFEST.json" in files
    assert "dist/cli/tm-*.tar.gz" in files
    assert "dist/cli/SHA256SUMS" in files
    assert "dist/cli/RELEASE-MANIFEST.json" in files
    assert step_by_name["Generate release notes"]["run"] == (
        'python ./scripts/build-release-notes.py '
        '--tag "${{ github.ref_name }}" '
        '--output dist/release-notes.md')
    assert release_step["with"]["body_path"] == "dist/release-notes.md"
    assert "generate_release_notes" not in release_step["with"]
    assert step_by_name["Verify public CLI release surface"]["if"] == (
        "${{ vars.PUBLIC_CLI_RELEASE_VERIFY == 'true' }}")
    assert step_by_name["Verify public CLI release surface"]["run"] == (
        'python ./scripts/verify-public-cli-release-surface.py '
        '--dist-dir dist/cli --tag "${{ github.ref_name }}" '
        '--attempts 10 --delay-seconds 6')
    publish_steps = publish_job["steps"]
    publish_by_name = {
        step["name"]: step
        for step in publish_steps if isinstance(step, dict) and "name" in step
    }
    assert publish_job["permissions"] == {
        "contents": "read",
        "id-token": "write",
    }
    assert "Build Python distributions" not in publish_by_name
    assert publish_by_name["Download verified Python distributions"][
        "uses"] == "actions/download-artifact@v4"
    assert publish_by_name["Download verified Python distributions"]["with"][
        "name"] == "verified-python-dist-${{ github.ref_name }}"
    assert publish_by_name["Download verified Python distributions"]["with"][
        "path"] == "dist/python"
    assert publish_by_name["Prepare PyPI package directory"]["run"] == (
        "mkdir -p dist/pypi && "
        "cp dist/python/*.whl dist/python/*.tar.gz dist/pypi/")
    assert publish_by_name["Publish to PyPI (trusted publishing)"]["with"][
        "packages-dir"] == "dist/pypi"


def test_package_json_verify_dist_builds_then_smoke_tests() -> None:
    package_json_path = REPO_ROOT / "package.json"
    payload = json.loads(package_json_path.read_text(encoding="utf-8"))

    assert payload["scripts"][
        "build:python-dist"] == "./scripts/build-python-dist.sh"
    assert payload["scripts"][
        "build:python-sdist"] == "./scripts/build-python-sdist.sh"
    assert payload["scripts"][
        "build:cli-dist"] == "./scripts/build-cli-dist.sh"
    assert payload["scripts"][
        "verify:cli-dist"] == "./scripts/build-cli-dist.sh && ./scripts/smoke-test-cli-dist.sh"
    assert payload["scripts"][
        "verify:docs-rendered"] == "bash ./scripts/verify-rendered-doc-routes.sh"
    assert payload["scripts"][
        "verify:released-client-compatibility"] == "./scripts/verify-released-client-compatibility.sh"
    assert payload["scripts"][
        "verify:dist"] == "./scripts/build-python-dist.sh && ./scripts/build-python-sdist.sh dist/python && ./scripts/smoke-test-python-dist.sh && ./scripts/smoke-test-python-sdist.sh dist/python/*.tar.gz && ./scripts/build-cli-dist.sh && ./scripts/smoke-test-cli-dist.sh"


def test_install_tm_script_targets_public_release_repo_and_latest_assets(
) -> None:
    install_script = (REPO_ROOT / "scripts" /
                      "install-tm.sh").read_text(encoding="utf-8")

    assert 'REPO_SLUG="Tensormesh-Production/tensormesh-sdk"' in install_script
    assert 'RELEASE_BASE="https://github.com/$REPO_SLUG/releases"' in install_script
    assert 'TM_VERSION="${TM_VERSION:-latest}"' in install_script
    assert 'tm-${platform}.tar.gz' in install_script
    assert 'SHA256SUMS' in install_script
    assert 'raw.githubusercontent.com' not in install_script


def test_public_cli_release_surface_verifier_script_defaults_to_public_repo_metadata(
) -> None:
    script = (REPO_ROOT / "scripts" /
              "verify-public-cli-release-surface.py").read_text(
                  encoding="utf-8")

    assert "PUBLIC_RELEASE_REPO" in script
    assert "INSTALLER_PATH" in script
    assert "releases/download" in script
    assert "raw.githubusercontent.com" in script


def test_direct_sdist_scripts_default_to_dist_python() -> None:
    build_script = (REPO_ROOT / "scripts" /
                    "build-python-sdist.sh").read_text(encoding="utf-8")
    smoke_script = (REPO_ROOT / "scripts" /
                    "smoke-test-python-sdist.sh").read_text(encoding="utf-8")

    assert 'OUTPUT_DIR="${1:-$ROOT_DIR/dist/python}"' in build_script
    assert 'DEFAULT_DIST_DIR="$ROOT_DIR/dist/python"' in smoke_script


def test_verify_workflow_includes_sync_docs_and_python_gates() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "verify.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    sync_docs_steps = payload["jobs"]["verify-sync-docs"]["steps"]
    python_steps = payload["jobs"]["verify-python"]["steps"]
    sync_docs_by_name = {
        step["name"]: step
        for step in sync_docs_steps
        if isinstance(step, dict) and "name" in step
    }
    python_by_name = {
        step["name"]: step
        for step in python_steps if isinstance(step, dict) and "name" in step
    }

    assert "Verify rendered docs routes" not in sync_docs_by_name
    assert sync_docs_by_name["Install Python dependencies"][
        "run"] == "python -m pip install -U pip && python -m pip install -e ."
    assert sync_docs_by_name["Verify docs/spec sync and local validation"][
        "run"] == "VERIFY_PYTHON=0 npm run verify"
    assert python_by_name["Check control-plane resource generation drift"][
        "run"] == "python ./scripts/generate-control-plane-resources.py --check"
    assert python_by_name["Check async SDK generation drift"][
        "run"] == "python ./scripts/generate-async-sdk.py --check"
    assert python_by_name["Check CLI docs generation drift"][
        "run"] == "python ./scripts/generate-cli-docs.py --check --reference-dir ./docs/cli/reference"
    assert python_by_name["Ruff"][
        "run"] == "ruff check src/tensormesh src/tensormesh_cli tests scripts"
    assert python_by_name["Unit tests with coverage gate (network-free)"][
        "run"] == "pytest -q --cov=tensormesh --cov=tensormesh_cli --cov-report=term-missing --cov-fail-under=80"
    assert python_by_name["Compatibility tests"][
        "run"] == "./scripts/verify-compatibility.sh"


def test_pyproject_uses_stricter_default_quality_gates() -> None:
    payload = tomllib.loads(
        (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8"))

    assert set(payload["tool"]["ruff"]["lint"]["select"]) == {"B", "E9", "F"}

    verify_python = (REPO_ROOT / "scripts" /
                     "verify-python.sh").read_text(encoding="utf-8")
    assert '--cov-fail-under="${PYTEST_COV_FAIL_UNDER:-80}"' in verify_python


def test_verify_workflow_dist_job_uses_shared_dist_scripts_only() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "verify.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    steps = payload["jobs"]["verify-dist"]["steps"]
    step_by_name = {
        step["name"]: step
        for step in steps if isinstance(step, dict) and "name" in step
    }

    assert "Build Python distributions" not in step_by_name
    assert step_by_name["Build and smoke-test Python dist artifacts"][
        "run"] == "npm run verify:dist"


def test_verify_workflow_includes_bootstrap_smoke_job() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "verify.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    bootstrap_job = payload["jobs"]["bootstrap-smoke"]
    steps = bootstrap_job["steps"]
    step_by_name = {
        step["name"]: step
        for step in steps if isinstance(step, dict) and "name" in step
    }

    assert bootstrap_job["runs-on"] == "ubuntu-latest"
    assert step_by_name["Run bootstrap newcomer path"][
        "run"] == "npm run bootstrap"


def test_release_workflow_installs_python_before_docs_spec_verify() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "release.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    release_steps = payload["jobs"]["build-sdk"]["steps"]
    step_by_name = {
        step["name"]: step
        for step in release_steps if isinstance(step, dict) and "name" in step
    }

    assert step_by_name["Install Python dependencies (docs/spec verify)"][
        "run"] == "python -m pip install -U pip && python -m pip install -e ."
    assert step_by_name["Verify docs/spec sync and local validation"][
        "run"] == "VERIFY_PYTHON=0 npm run verify"


def test_released_client_compatibility_workflow_exists_and_is_reusable(
) -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "released-client-compatibility.yml"

    assert workflow_path.exists()

    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    assert "workflow_call" in payload["on"]
    assert "workflow_dispatch" in payload["on"]
    assert payload["permissions"] == {"contents": "read"}
    assert "released-client-compatibility" in payload["jobs"]


def test_released_client_compatibility_workflow_runs_npm_gate() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "released-client-compatibility.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    steps = payload["jobs"]["released-client-compatibility"]["steps"]
    step_by_name = {
        step["name"]: step
        for step in steps if isinstance(step, dict) and "name" in step
    }

    assert step_by_name["Run released client compatibility gate"][
        "run"] == "npm run verify:released-client-compatibility"


def test_released_client_compatibility_workflow_wires_env_and_installs_deps(
) -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "released-client-compatibility.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    job = payload["jobs"]["released-client-compatibility"]
    steps = job["steps"]
    step_by_name = {
        step["name"]: step
        for step in steps if isinstance(step, dict) and "name" in step
    }

    assert job["env"] == {
        "TM_RELEASE_REPO": "${{ github.repository }}",
        "GITHUB_TOKEN": "${{ github.token }}",
        "TM_COMPAT_CONTROL_PLANE_TOKEN":
        "${{ secrets.TM_COMPAT_CONTROL_PLANE_TOKEN }}",
        "TM_COMPAT_INFERENCE_API_KEY":
        "${{ secrets.TM_COMPAT_INFERENCE_API_KEY }}",
        "TM_COMPAT_CONTROL_PLANE_BASE_URL":
        "${{ secrets.TM_COMPAT_CONTROL_PLANE_BASE_URL }}",
        "TM_COMPAT_GATEWAY_BASE_URL":
        "${{ secrets.TM_COMPAT_GATEWAY_BASE_URL }}",
        "TM_COMPAT_ON_DEMAND_USER_ID":
        "${{ secrets.TM_COMPAT_ON_DEMAND_USER_ID }}",
        "TM_COMPAT_GATEWAY_MODEL_ID":
        "${{ secrets.TM_COMPAT_GATEWAY_MODEL_ID }}",
    }
    assert step_by_name["Install Node devDependencies"]["run"] == "npm ci"
    assert step_by_name["Install Python dependencies"][
        "run"] == "python -m pip install -U pip && python -m pip install -e '.[dev]'"


def test_live_verify_workflow_exists_for_manual_runs_only() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "live-verify.yml"

    assert workflow_path.exists()

    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    assert "workflow_dispatch" in payload["on"]
    assert "schedule" not in payload["on"]
    dispatch = payload["on"]["workflow_dispatch"]
    assert dispatch["inputs"]["target_environment"]["type"] == "choice"
    assert dispatch["inputs"]["target_environment"]["default"] == "dev"
    assert dispatch["inputs"]["target_environment"]["options"] == [
        "dev",
        "staging",
    ]


def test_live_verify_workflow_uses_shared_network_gate_and_materializes_cli_state(
) -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "live-verify.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    job = payload["jobs"]["live-verify"]
    steps = job["steps"]
    step_by_name = {
        step["name"]: step
        for step in steps if isinstance(step, dict) and "name" in step
    }

    assert job["env"]["TM_CONFIG_HOME"] == "${{ runner.temp }}/tm-live-state"
    assert step_by_name["Install Node devDependencies"]["run"] == "npm ci"
    assert step_by_name["Install Python dependencies"][
        "run"] == "python -m pip install -U pip && python -m pip install -e '.[dev]'"
    assert step_by_name["Run live network verification"][
        "run"] == "npm run verify:network"

    setup_run = step_by_name["Materialize CLI state for live verification"][
        "run"]
    assert 'mkdir -p "$TM_CONFIG_HOME"' in setup_run
    assert 'cat > "$TM_CONFIG_HOME/auth.json"' in setup_run
    assert 'cat > "$TM_CONFIG_HOME/config.toml"' in setup_run
    assert "gateway_api_key" not in setup_run
    assert "gateway_user_id" not in setup_run
    assert "gateway_model_id" not in setup_run
    assert "controlplane_base" in setup_run
    assert step_by_name["Sync managed gateway state for live verification"][
        "run"] == "tm init --sync"


def test_live_verify_workflow_selects_dev_or_staging_secret_bundle() -> None:
    workflow_path = REPO_ROOT / ".github" / "workflows" / "live-verify.yml"
    payload = yaml.safe_load(workflow_path.read_text(encoding="utf-8"))

    job = payload["jobs"]["live-verify"]
    steps = job["steps"]
    step_by_name = {
        step["name"]: step
        for step in steps if isinstance(step, dict) and "name" in step
    }

    select_step = step_by_name["Select live target credentials"]
    select_env = select_step["env"]
    select_run = select_step["run"]

    assert select_env["TM_LIVE_DEV_CONTROL_PLANE_TOKEN"] == (
        "${{ secrets.TM_LIVE_DEV_CONTROL_PLANE_TOKEN }}")
    assert select_env["TM_LIVE_STAGING_CONTROL_PLANE_TOKEN"] == (
        "${{ secrets.TM_LIVE_STAGING_CONTROL_PLANE_TOKEN }}")
    assert "TM_LIVE_DEV_INFERENCE_API_KEY" not in select_env
    assert "TM_LIVE_STAGING_INFERENCE_API_KEY" not in select_env
    assert "TM_LIVE_DEV_ON_DEMAND_USER_ID" not in select_env
    assert "TM_LIVE_STAGING_ON_DEMAND_USER_ID" not in select_env
    assert "TM_LIVE_DEV_GATEWAY_MODEL_ID" not in select_env
    assert "TM_LIVE_STAGING_GATEWAY_MODEL_ID" not in select_env
    assert "case \"$TARGET_ENV\" in" in select_run
    assert "staging)" in select_run
    assert "dev)" in select_run
    assert "TM_LIVE_CONTROL_PLANE_BASE_URL" in select_run
    assert "TM_LIVE_CONTROL_PLANE_TOKEN" in select_run
    assert "TM_LIVE_INFERENCE_API_KEY" not in select_run
    assert "TM_LIVE_ON_DEMAND_USER_ID" not in select_run
    assert "TM_LIVE_GATEWAY_MODEL_ID" not in select_run


def test_workflow_docs_reference_live_verify_workflow_and_keep_verify_yml_network_free(
) -> None:
    workflow_docs = (REPO_ROOT / "dev" /
                     "workflows.md").read_text(encoding="utf-8")

    assert ".github/workflows/live-verify.yml" in workflow_docs
    assert "manual GitHub path for ad hoc dev or staging verification" in workflow_docs
    assert "`verify.yml` is network-free" in workflow_docs


def test_dist_smoke_scripts_use_shared_harness() -> None:
    dist_script = (REPO_ROOT / "scripts" /
                   "smoke-test-python-dist.sh").read_text(encoding="utf-8")
    sdist_script = (REPO_ROOT / "scripts" /
                    "smoke-test-python-sdist.sh").read_text(encoding="utf-8")

    assert "lib/smoke-test-python-package.sh" in dist_script
    assert "tm_smoke_test_python_package" in dist_script
    assert "lib/smoke-test-python-package.sh" in sdist_script
    assert "tm_smoke_test_python_package" in sdist_script


def test_vendored_tar_compat_supports_commonjs_require(tmp_path: Path) -> None:
    compat_dir = tmp_path / "tar-default-compat"
    compat_dir.mkdir()
    compat_dir.joinpath("package.json").write_text(
        (REPO_ROOT / "vendor" / "tar-default-compat" /
         "package.json").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    compat_dir.joinpath("index.cjs").write_text(
        (REPO_ROOT / "vendor" / "tar-default-compat" /
         "index.cjs").read_text(encoding="utf-8"),
        encoding="utf-8",
    )

    upstream_dir = compat_dir / "node_modules" / "tar-upstream"
    upstream_dir.mkdir(parents=True)
    upstream_dir.joinpath("package.json").write_text(
        '{"name":"tar-upstream","main":"./index.js"}\n',
        encoding="utf-8",
    )
    upstream_dir.joinpath("index.js").write_text(
        """
        const api = {};
        Object.defineProperty(api, 'c', {
          enumerable: true,
          configurable: true,
          get() {
            return () => 'c';
          },
        });
        Object.defineProperty(api, 'x', {
          enumerable: true,
          configurable: true,
          get() {
            return () => 'x';
          },
        });
        Object.defineProperty(api, 'create', {
          enumerable: true,
          configurable: false,
          get() {
            return api.c;
          },
        });
        Object.defineProperty(api, 'extract', {
          enumerable: true,
          configurable: false,
          get() {
            return api.x;
          },
        });
        module.exports = api;
        """.strip() + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            "node",
            "-e",
            ("const tar = require('./tar-default-compat');"
             "if (typeof tar.x !== 'function' || typeof tar.create !== 'function') {"
             "  throw new Error('expected tar compat methods to be available');"
             "}"),
        ],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr


def test_pyproject_dev_tools_include_build_and_shellcheck() -> None:
    pyproject_path = REPO_ROOT / "pyproject.toml"
    contents = pyproject_path.read_text(encoding="utf-8")

    assert 'name = "tensormesh"' in contents
    assert 'requires-python = ">=3.12"' in contents
    assert 'target-version = "py312"' in contents
    assert 'package-dir = {"" = "src"}' in contents
    assert 'version = {attr = "tensormesh.build_info.__version__"}' in contents
    assert 'where = ["src"]' in contents
    assert 'tensormesh = ["py.typed"]' in contents
    assert '"build>=1.2"' in contents
    assert '"shellcheck-py>=0.10.0.1"' in contents


def test_release_docs_exist() -> None:
    assert (REPO_ROOT / "CHANGELOG.md").exists()
    assert (REPO_ROOT / "dev" / "sdk-release-policy.md").exists()


def test_sdk_package_declares_py_typed_marker() -> None:
    assert (REPO_ROOT / "src" / "tensormesh" / "py.typed").exists()


def test_sync_script_regenerates_async_sdk_mirrors() -> None:
    sync_script = (REPO_ROOT / "scripts" /
                   "sync-tensormesh-api.sh").read_text(encoding="utf-8")

    assert '"$PYTHON_BIN" ./scripts/validate-sdk-codegen-manifest.py' in sync_script
    assert '"$PYTHON_BIN" ./scripts/generate-control-plane-resources.py' in sync_script
    assert '"$PYTHON_BIN" ./scripts/generate-async-sdk.py' in sync_script
    assert sync_script.index(
        "validate-sdk-codegen-manifest.py") < sync_script.index(
            "generate-control-plane-resources.py")
    assert sync_script.index("generate-control-plane-resources.py"
                             ) < sync_script.index("generate-async-sdk.py")


def test_release_readiness_passes_for_current_repo_state() -> None:
    mod = load_script_module(RELEASE_READINESS_SCRIPT)

    errors = mod.validate_release_readiness(
        REPO_ROOT,
        version=__version__,
        tag=f"v{__version__}",
    )

    assert errors == []


def test_release_readiness_validates_manifest_and_dist_artifacts(
    tmp_path: Path, ) -> None:
    repo_root = tmp_path / "repo"
    build_info_dir = repo_root / "src" / "tensormesh"
    build_info_dir.mkdir(parents=True)
    build_info_dir.joinpath("build_info.py").write_text(
        '__version__ = "0.2.0"\n',
        encoding="utf-8",
    )
    repo_root.joinpath("CHANGELOG.md").write_text(
        "# Changelog\n\n## 0.2.0\n\n- release\n",
        encoding="utf-8",
    )
    policy_dir = repo_root / "dev"
    policy_dir.mkdir()
    (policy_dir / "sdk-release-policy.md").write_text("# policy\n",
                                                      encoding="utf-8")
    dist_dir = repo_root / "dist" / "python"
    dist_dir.mkdir(parents=True)
    wheel_name = "tensormesh-0.2.0-py3-none-any.whl"
    sdist_name = "tensormesh-0.2.0.tar.gz"
    wheel_contents = "wheel"
    sdist_contents = "sdist"
    (dist_dir / wheel_name).write_text(wheel_contents, encoding="utf-8")
    (dist_dir / sdist_name).write_text(sdist_contents, encoding="utf-8")
    checksums = subprocess.run(
        [
            "python3",
            "-c",
            ("from hashlib import sha256;"
             "print(sha256(b'wheel').hexdigest());"
             "print(sha256(b'sdist').hexdigest())"),
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip().splitlines()
    wheel_sha, sdist_sha = checksums
    (dist_dir / "SHA256SUMS").write_text(
        f"{wheel_sha}  {wheel_name}\n{sdist_sha}  {sdist_name}\n",
        encoding="utf-8",
    )
    (dist_dir / "RELEASE-MANIFEST.json").write_text(
        json.dumps({
            "surface":
            "sdk",
            "package_name":
            "tensormesh",
            "package_version":
            "0.2.0",
            "cli_version":
            "0.2.0",
            "git_tag":
            "v0.2.0",
            "changelog_path":
            "CHANGELOG.md",
            "release_policy_path":
            "dev/sdk-release-policy.md",
            "artifacts": [
                {
                    "filename": wheel_name,
                    "sha256": wheel_sha,
                },
                {
                    "filename": sdist_name,
                    "sha256": sdist_sha,
                },
            ],
        }),
        encoding="utf-8",
    )

    mod = load_script_module(RELEASE_READINESS_SCRIPT,
                             module_name="check_release_readiness_manifest")
    errors = mod.validate_release_readiness(
        repo_root,
        version="0.2.0",
        tag="v0.2.0",
        dist_dir=dist_dir,
        require_artifacts=True,
    )

    assert errors == []


def test_release_readiness_reports_checksum_mismatch(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    build_info_dir = repo_root / "src" / "tensormesh"
    build_info_dir.mkdir(parents=True)
    build_info_dir.joinpath("build_info.py").write_text(
        '__version__ = "0.2.0"\n',
        encoding="utf-8",
    )
    repo_root.joinpath("CHANGELOG.md").write_text(
        "# Changelog\n\n## 0.2.0\n\n- release\n",
        encoding="utf-8",
    )
    policy_dir = repo_root / "dev"
    policy_dir.mkdir()
    (policy_dir / "sdk-release-policy.md").write_text("# policy\n",
                                                      encoding="utf-8")
    dist_dir = repo_root / "dist" / "python"
    dist_dir.mkdir(parents=True)
    wheel_name = "tensormesh-0.2.0-py3-none-any.whl"
    sdist_name = "tensormesh-0.2.0.tar.gz"
    (dist_dir / wheel_name).write_text("wheel", encoding="utf-8")
    (dist_dir / sdist_name).write_text("sdist", encoding="utf-8")
    (dist_dir / "SHA256SUMS").write_text(
        f"{'0' * 64}  {wheel_name}\n{'1' * 64}  {sdist_name}\n",
        encoding="utf-8",
    )
    (dist_dir / "RELEASE-MANIFEST.json").write_text(
        json.dumps({
            "surface":
            "sdk",
            "package_name":
            "tensormesh",
            "package_version":
            "0.2.0",
            "cli_version":
            "0.2.0",
            "git_tag":
            "v0.2.0",
            "changelog_path":
            "CHANGELOG.md",
            "release_policy_path":
            "dev/sdk-release-policy.md",
            "artifacts": [
                {
                    "filename": wheel_name,
                    "sha256": "0" * 64,
                },
                {
                    "filename": sdist_name,
                    "sha256": "1" * 64,
                },
            ],
        }),
        encoding="utf-8",
    )

    mod = load_script_module(RELEASE_READINESS_SCRIPT,
                             module_name="check_release_readiness_checksums")
    errors = mod.validate_release_readiness(
        repo_root,
        version="0.2.0",
        tag="v0.2.0",
        dist_dir=dist_dir,
        require_artifacts=True,
    )

    assert "SHA256SUMS does not match the built release artifacts" in errors


def test_release_readiness_reports_manifest_checksum_mismatch(
    tmp_path: Path, ) -> None:
    repo_root = tmp_path / "repo"
    build_info_dir = repo_root / "src" / "tensormesh"
    build_info_dir.mkdir(parents=True)
    build_info_dir.joinpath("build_info.py").write_text(
        '__version__ = "0.2.0"\n',
        encoding="utf-8",
    )
    repo_root.joinpath("CHANGELOG.md").write_text(
        "# Changelog\n\n## 0.2.0\n\n- release\n",
        encoding="utf-8",
    )
    policy_dir = repo_root / "dev"
    policy_dir.mkdir()
    (policy_dir / "sdk-release-policy.md").write_text("# policy\n",
                                                      encoding="utf-8")
    dist_dir = repo_root / "dist" / "python"
    dist_dir.mkdir(parents=True)
    wheel_name = "tensormesh-0.2.0-py3-none-any.whl"
    sdist_name = "tensormesh-0.2.0.tar.gz"
    (dist_dir / wheel_name).write_text("wheel", encoding="utf-8")
    (dist_dir / sdist_name).write_text("sdist", encoding="utf-8")
    (dist_dir / "SHA256SUMS").write_text(
        f"{'a' * 64}  {wheel_name}\n{'b' * 64}  {sdist_name}\n",
        encoding="utf-8",
    )
    (dist_dir / "RELEASE-MANIFEST.json").write_text(
        json.dumps({
            "surface":
            "sdk",
            "package_name":
            "tensormesh",
            "package_version":
            "0.2.0",
            "cli_version":
            "0.2.0",
            "git_tag":
            "v0.2.0",
            "changelog_path":
            "CHANGELOG.md",
            "release_policy_path":
            "dev/sdk-release-policy.md",
            "artifacts": [
                {
                    "filename": wheel_name,
                    "sha256": "c" * 64,
                },
                {
                    "filename": sdist_name,
                    "sha256": "d" * 64,
                },
            ],
        }),
        encoding="utf-8",
    )

    mod = load_script_module(
        RELEASE_READINESS_SCRIPT,
        module_name="check_release_readiness_manifest_checksums",
    )
    errors = mod.validate_release_readiness(
        repo_root,
        version="0.2.0",
        tag="v0.2.0",
        dist_dir=dist_dir,
        require_artifacts=True,
    )

    assert "RELEASE-MANIFEST.json sha256 values do not match the built release artifacts" in errors


def test_release_readiness_reports_mismatched_tag_and_missing_changelog(
    tmp_path: Path, ) -> None:
    repo_root = tmp_path / "repo"
    build_info_dir = repo_root / "src" / "tensormesh"
    build_info_dir.mkdir(parents=True)
    build_info_dir.joinpath("build_info.py").write_text(
        '__version__ = "0.2.0"\n',
        encoding="utf-8",
    )
    repo_root.joinpath("CHANGELOG.md").write_text(
        textwrap.dedent("""\
        # Changelog

        ## Unreleased

        - pending
        """),
        encoding="utf-8",
    )
    (repo_root / "dev").mkdir()
    (repo_root / "dev" / "sdk-release-policy.md").write_text(
        "# policy\n",
        encoding="utf-8",
    )

    mod = load_script_module(RELEASE_READINESS_SCRIPT,
                             module_name="check_release_readiness_tmp")
    errors = mod.validate_release_readiness(
        repo_root,
        version="0.2.1",
        tag="v0.2.1",
    )

    assert "requested version '0.2.1' does not match package version '0.2.0'" in errors
    assert "tag 'v0.2.1' does not match expected release tag 'v0.2.0'" in errors
    assert "CHANGELOG.md does not contain a release section for 0.2.0" in errors


def test_release_readiness_reports_missing_manifest_or_artifact_mismatch(
    tmp_path: Path, ) -> None:
    repo_root = tmp_path / "repo"
    build_info_dir = repo_root / "src" / "tensormesh"
    build_info_dir.mkdir(parents=True)
    build_info_dir.joinpath("build_info.py").write_text(
        '__version__ = "0.3.0"\n',
        encoding="utf-8",
    )
    repo_root.joinpath("CHANGELOG.md").write_text(
        "# Changelog\n\n## 0.3.0\n\n- release\n",
        encoding="utf-8",
    )
    (repo_root / "dev").mkdir()
    (repo_root / "dev" / "sdk-release-policy.md").write_text("# policy\n",
                                                             encoding="utf-8")
    dist_dir = repo_root / "dist" / "python"
    dist_dir.mkdir(parents=True)

    mod = load_script_module(RELEASE_READINESS_SCRIPT,
                             module_name="check_release_readiness_missing")
    errors = mod.validate_release_readiness(
        repo_root,
        version="0.3.0",
        tag="v0.3.0",
        dist_dir=dist_dir,
        require_artifacts=True,
    )

    assert "dist/python/RELEASE-MANIFEST.json is missing" in errors
    assert "dist/python does not contain any wheel artifacts" in errors
    assert "dist/python does not contain a source distribution for 0.3.0" in errors
