"""Pytest plugin for Pintest (smart test selection and duration tracking)."""
import json
import sys
from pathlib import Path

# Stores test_node_id -> duration_ms
test_durations = {}


def pytest_addoption(parser):
    """Add Pintest command line options."""
    group = parser.getgroup("pintest")
    group.addoption(
        "--pintest",
        action="store_true",
        default=False,
        help="Enable Pintest smart test selection (run only affected tests)",
    )
    group.addoption(
        "--pintest-base",
        action="store",
        default="master",
        help="Base branch for Pintest git diffing (default: master)",
    )


def pytest_collection_modifyitems(session, config, items):
    """Filter collected tests if --pintest is enabled."""
    if not config.getoption("--pintest"):
        return

    from pintest.config import Config
    from pintest.cloud_mapping_db import CloudMappingDB
    from pintest.test_mapping_db_v2 import TestMappingDBV2
    from pintest.cli import PintestRunner

    repo_root = Path(config.rootdir).resolve()
    base_branch = config.getoption("--pintest-base")

    # ── Mapping source detection ───────────────────────────────────────────
    mapping_db_obj = None

    # 1. Try Cloud Mode
    cfg = Config.load()
    use_cloud = cfg.is_cloud_enabled and bool(cfg.cloud.repo_id)

    if use_cloud:
        print(f"☁️  Mapping Service: Pintest Cloud (repo {cfg.cloud.repo_id[:8]}...)", file=sys.stderr)
        mapping_db_obj = CloudMappingDB(cfg.cloud)
    else:
        # 2. Try Local V2 Mapping DB
        mapping_db = repo_root / ".pintest" / "test_mapping.db"
        legacy_db = repo_root / ".test_mapping.db"
        if not mapping_db.exists() and legacy_db.exists():
            mapping_db.parent.mkdir(parents=True, exist_ok=True)
            try:
                legacy_db.rename(mapping_db)
            except Exception:
                mapping_db = legacy_db

        if not mapping_db.exists():
            print("🏗️  No local mapping DB found. Initializing build...", file=sys.stderr)
            from pintest.build_mapping_iterative import build_mapping_iteratively

            default_test_dir = "tests"
            if getattr(cfg.cloud, "test_dir", None):
                default_test_dir = cfg.cloud.test_dir

            exit_code = build_mapping_iteratively(
                repo_root,
                mapping_db,
                test_dir=default_test_dir,
                verbose=False
            )
            if exit_code != 0:
                print("❌ Failed to build mapping DB.", file=sys.stderr)
                sys.exit(exit_code)

        print(f"🖥️  Local mode: {mapping_db}", file=sys.stderr)
        mapping_db_obj = TestMappingDBV2(mapping_db)
        mapping_db_obj.connect()

    try:
        if base_branch == "master" and cfg.is_cloud_enabled and getattr(cfg.cloud, "branch", None):
            base_branch = cfg.cloud.branch

        # Initialize runner
        runner = PintestRunner(
            repo_root,
            mapping_db=mapping_db_obj,
            verbose=False
        )

        # Find affected tests
        affected_tests = runner.find_affected_tests(base_branch)

        # Unmapped tests discovery (Cloud mode only)
        if use_cloud:
            from pintest.pre_commit_hook import find_unmapped_tests
            unmapped = find_unmapped_tests(
                repo_root,
                mapping_db_obj,
                verbose=False
            )
            if unmapped:
                affected_tests.update(unmapped)

        # Filter items in-place
        selected_items = []
        deselected_items = []

        for item in items:
            # Check exact nodeid match
            match = item.nodeid in affected_tests

            # Check file match (nodeid prefix before ::)
            if not match:
                file_part = item.nodeid.split("::")[0]
                if file_part in affected_tests:
                    match = True

            # Check fspath/path relative match
            if not match:
                try:
                    item_path = getattr(item, 'path', None)
                    if not item_path and hasattr(item, 'fspath'):
                        item_path = Path(item.fspath)
                    if item_path:
                        rel_path = str(item_path.relative_to(repo_root))
                        if rel_path in affected_tests:
                            match = True
                except Exception:
                    pass

            if match:
                selected_items.append(item)
            else:
                deselected_items.append(item)

        items[:] = selected_items
        if deselected_items:
            config.hook.pytest_deselected(items=deselected_items)

    finally:
        if mapping_db_obj and hasattr(mapping_db_obj, 'close'):
            mapping_db_obj.close()


def pytest_runtest_makereport(item, call):
    """Record test execution time during the 'call' phase."""
    if call.when == "call":
        # call.duration is a float representing exact seconds
        test_durations[item.nodeid] = int(call.duration * 1000)


def pytest_sessionfinish(session, exitstatus):
    """Dump durations to a temporary file for the CLI push phase."""
    try:
        pintest_dir = Path(session.config.rootdir) / ".pintest"
        pintest_dir.mkdir(parents=True, exist_ok=True)
        out_file = pintest_dir / "durations.json"
        with open(out_file, "w") as f:
            json.dump(test_durations, f)
    except Exception as e:
        # Silently pass if we cannot write to rootdir
        pass
