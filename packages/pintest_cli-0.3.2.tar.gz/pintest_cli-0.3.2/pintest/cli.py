"""CLI for Pintest."""

import argparse
import getpass
import subprocess
import sys
from pathlib import Path
from typing import Set

from .git_diff_parser import GitDiffParser
from .coverage_mapper import CoverageMapper
from .config import Config
from .cloud_mapping_db import CloudMappingDB
from .test_mapping_db_v2 import TestMappingDBV2


class PintestRunner:
    """Select and run tests based on code coverage and git changes."""
    
    def __init__(self, repo_root: Path, mapping_db=None, verbose: bool = False):
        """
        Initialize runner.
        
        Args:
            repo_root: Repository root directory
            mapping_db: Mapping database object (TestMappingDBV2 or CloudMappingDB)
            verbose: Enable verbose output
        """
        self.repo_root = Path(repo_root).resolve()
        self.git_parser = GitDiffParser(self.repo_root)
        self.mapping_db = mapping_db
        self.verbose = verbose
        
    def find_affected_tests(self, base_branch: str = "master") -> Set[str]:
        """
        Find all tests affected by changes since base_branch.
        
        Returns:
            Set of test identifiers (pytest format)
        """
        # Get git diff
        try:
            diff_output = self.git_parser.get_diff(base_branch)
        except RuntimeError as e:
            print(f"Error getting git diff: {e}", file=sys.stderr)
            return set()
        
        changes = self.git_parser.parse_diff(diff_output)
        python_changes = self.git_parser.filter_python_files(changes)
        
        if self.verbose:
            print(f"🔍 Found {len(python_changes)} changed Python files", file=sys.stderr)
        
        # Get changed test files (always run these)
        changed_test_files = self.git_parser.get_changed_test_files(python_changes)
        
        if self.verbose and changed_test_files:
            print(f"🔍 Changed test files: {len(changed_test_files)}", file=sys.stderr)
            for test_file in sorted(changed_test_files):
                print(f"  - {test_file}", file=sys.stderr)
        
        # Find tests that cover changed lines
        affected_tests = set()
        
        if self.mapping_db:
            if not python_changes:
                if self.verbose:
                    print("ℹ️  No Python source changes detected. Skipping mapping query.", file=sys.stderr)
            elif hasattr(self.mapping_db, 'find_tests_for_changes'):
                # CloudMappingDB or optimized interface
                # Format changes for the API: [{"file": "path", "lines": [1, 2]}, ...]
                formatted_changes = [
                    {"file": path, "lines": list(change.get_all_changed_lines())}
                    for path, change in python_changes.items()
                    if not change.is_new and change.get_all_changed_lines()
                ]
                
                if formatted_changes:
                    # Pass base_branch as the target branch for mapping lookup
                    affected_tests, unmapped = self.mapping_db.find_tests_for_changes(
                        formatted_changes, 
                        branch=base_branch
                    )
                    if self.verbose and unmapped:
                        print(f"⚠️  {len(unmapped)} files have no coverage mapping", file=sys.stderr)
                elif self.verbose:
                    print("ℹ️  Changes contain no covered lines. Skipping mapping query.", file=sys.stderr)
            else:
                # Local TestMappingDBV2
                for file_path, change in python_changes.items():
                    # Skip test files (we already have them)
                    if file_path in changed_test_files:
                        continue
                    
                    if change.is_new:
                        continue
                    
                    changed_lines = change.get_all_changed_lines()
                    if not changed_lines:
                        continue
                    
                    # Find tests covering these lines
                    tests = self.mapping_db.find_tests_for_file_lines(file_path, changed_lines)
                    affected_tests.update(tests)
                    
                    if self.verbose and tests:
                        print(f"   ✓ {file_path}: {len(tests)} tests affected", file=sys.stderr)
        else:
            print("⚠️  No mapping database found. Only running changed test files.", file=sys.stderr)
            print("   Run 'pintest push' or 'pintest build-mapping' to create one.", file=sys.stderr)
        
        # Always include changed test files
        affected_tests.update(changed_test_files)
        
        return affected_tests
    
    def run_tests(
        self, 
        test_selection: Set[str], 
        dry_run: bool = False, 
        verbose: bool = False,
        pytest_args: list = None
    ) -> int:
        """
        Run selected tests with pytest.
        
        Args:
            test_selection: Set of test identifiers
            dry_run: If True, only print tests without running
            verbose: Show detailed output
            pytest_args: Additional pytest arguments
            
        Returns:
            Exit code from pytest (0 = success)
        """
        if not test_selection:
            if dry_run:
                print("Would run 0 test(s)")
                return 0
            print("No tests to run!")
            return 0

        test_list = sorted(test_selection)
        chunk_size = 500
        needs_chunking = len(test_list) > chunk_size

        # Base pytest command
        base_cmd = [sys.executable, "-m", "pytest", "-p", "pintest.pytest_plugin"]
        base_cmd.extend(["--cov", "--cov-context=test", "--cov-append", "--cov-report="])
        if verbose:
            base_cmd.append("-v")
        if pytest_args:
            base_cmd.extend(pytest_args)

        if dry_run:
            print(f"Would run {len(test_selection)} test(s):")
            for test in test_list[:10]:
                print(f"  {test}")
            if len(test_list) > 10:
                print(f"  ... and {len(test_list) - 10} more")
            print(f"\nBase Command: {' '.join(base_cmd)}")
            return 0

        if needs_chunking:
            print(f"Running {len(test_selection)} selected test(s) in chunks of {chunk_size}...")
            total_chunks = (len(test_list) + chunk_size - 1) // chunk_size
            final_returncode = 0
            fail_fast = pytest_args and any(arg == '-x' or arg.startswith('--maxfail') for arg in pytest_args)
            
            for i in range(0, len(test_list), chunk_size):
                chunk = test_list[i:i + chunk_size]
                chunk_num = (i // chunk_size) + 1
                print(f"\n📦 Running chunk {chunk_num}/{total_chunks} ({len(chunk)} tests)...", flush=True)
                cmd = base_cmd + chunk
                result = subprocess.run(cmd, cwd=self.repo_root)
                if result.returncode != 0:
                    if final_returncode == 0:
                        final_returncode = result.returncode
                    if fail_fast:
                        print(f"\n⚠️ Fail-fast enabled (-x / --maxfail). Aborting remaining {total_chunks - chunk_num} chunk(s).", file=sys.stderr)
                        break
            return final_returncode
        else:
            print(f"Running {len(test_selection)} selected test(s)...")
            cmd = base_cmd + test_list
            result = subprocess.run(cmd, cwd=self.repo_root)
            return result.returncode


def cmd_run(args):
    """Run affected tests."""
    repo_root = args.repo_root.resolve()
    if not repo_root.exists():
        print(f"❌ Error: Repository not found: {repo_root}", file=sys.stderr)
        sys.exit(1)
    
    # ── Mapping source detection ───────────────────────────────────────────
    mapping_db_obj = None
    
    # 1. Try Cloud Mode
    cfg = Config.load()
    use_cloud = cfg.is_cloud_enabled and bool(cfg.cloud.repo_id)
    
    if use_cloud:
        if args.verbose:
            print(f"☁️  Mapping Service: Pintest Cloud (repo {cfg.cloud.repo_id[:8]}...)", file=sys.stderr)
        mapping_db_obj = CloudMappingDB(cfg.cloud)
    else:
        # 2. Try Local V2 Mapping DB
        mapping_db = args.mapping_db if hasattr(args, 'mapping_db') else None
        if not mapping_db:
            mapping_db = repo_root / ".pintest" / "test_mapping.db"
            legacy_db = repo_root / ".test_mapping.db"
            if not mapping_db.exists() and legacy_db.exists():
                mapping_db.parent.mkdir(parents=True, exist_ok=True)
                try:
                    legacy_db.rename(mapping_db)
                except Exception:
                    mapping_db = legacy_db
            
        if not mapping_db.exists():
            print("🏗️  No local mapping DB found. Initializing build...", file=sys.stderr)
            from .build_mapping_iterative import build_mapping_iteratively
            
            # Use test_dir from config or default "tests"
            cfg_local = Config.load()
            default_test_dir = "tests"
            if getattr(cfg_local.cloud, "test_dir", None):
                default_test_dir = cfg_local.cloud.test_dir
                
            exit_code = build_mapping_iteratively(
                repo_root,
                mapping_db,
                test_dir=default_test_dir,
                verbose=args.verbose
            )
            sys.exit(exit_code)
            
        if args.verbose:
            print(f"🖥️  Local mode: {mapping_db}", file=sys.stderr)
        mapping_db_obj = TestMappingDBV2(mapping_db)
        mapping_db_obj.connect()

    # Initialize runner
    runner = PintestRunner(
        repo_root, 
        mapping_db=mapping_db_obj,
        verbose=args.verbose
    )
    
    try:
        base_branch = args.base_branch
        if base_branch == "master" and cfg.is_cloud_enabled and getattr(cfg.cloud, "branch", None):
            base_branch = cfg.cloud.branch

        # Find affected tests
        affected_tests = runner.find_affected_tests(
            base_branch
        )
        
        # Determine test_dir
        test_dir = args.test_dir
        if not test_dir and cfg.is_cloud_enabled and getattr(cfg.cloud, "test_dir", None):
            test_dir = cfg.cloud.test_dir
        if not test_dir:
            test_dir = "tests"

        # Unmapped tests discovery (Cloud mode only)
        if use_cloud:
            from .pre_commit_hook import find_unmapped_tests
            unmapped = find_unmapped_tests(
                repo_root,
                mapping_db_obj,
                test_dir=test_dir,
                verbose=args.verbose
            )
            if unmapped:
                if args.verbose:
                    print(f"⚠️  Found {len(unmapped)} unmapped tests", file=sys.stderr)
                affected_tests.update(unmapped)
        
        # Check minimum threshold
        if args.min_tests > 0 and len(affected_tests) < args.min_tests:
            print(
                f"Only {len(affected_tests)} test(s) found, below minimum {args.min_tests}",
                file=sys.stderr
            )
            print("Exiting with error (run full test suite instead)", file=sys.stderr)
            sys.exit(1)
        
        # Remove '--' separator if present in pytest_args
        pytest_extra_args = args.pytest_args
        if pytest_extra_args and pytest_extra_args[0] == '--':
            pytest_extra_args = pytest_extra_args[1:]
        
        # Run tests
        exit_code = runner.run_tests(
            affected_tests, 
            dry_run=args.dry_run,
            verbose=args.verbose,
            pytest_args=pytest_extra_args
        )
        
        # Auto-update the local database with the new coverage
        if not use_cloud and not args.dry_run:
            print("\n🔄 Updating mapping database with new coverage...")
            from .update_mapping import update_mapping
            update_mapping(repo_root, mapping_db=mapping_db, verbose=args.verbose)
            
        sys.exit(exit_code)
        
    except KeyboardInterrupt:
        print("\nInterrupted by user", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)
    finally:
        if mapping_db_obj and hasattr(mapping_db_obj, 'close'):
            mapping_db_obj.close()


def cmd_update_mapping(args):
    """Update test mapping database from coverage."""
    from .update_mapping import update_mapping
    sys.exit(update_mapping(
        args.repo_root,
        args.coverage_file,
        args.mapping_db,
        args.verbose
    ))


def cmd_build_mapping(args):
    """Build test mapping database iteratively (resumable)."""
    from .build_mapping_iterative import build_mapping_iteratively
    
    repo_root = args.repo_root.resolve()
    if args.mapping_db:
        mapping_db = args.mapping_db
    else:
        mapping_db = repo_root / ".pintest" / "test_mapping.db"
        legacy_db = repo_root / ".test_mapping.db"
        if not mapping_db.exists() and legacy_db.exists():
            mapping_db.parent.mkdir(parents=True, exist_ok=True)
            try:
                legacy_db.rename(mapping_db)
            except Exception:
                mapping_db = legacy_db
    
    # Load config to get default test_dir if it was saved during track
    from .config import Config
    cfg = Config.load()
    default_test_dir = "tests"
    if cfg.is_cloud_enabled and getattr(cfg.cloud, "test_dir", None):
        default_test_dir = cfg.cloud.test_dir

    # Use args.test_dir if explicitly provided and not the default "tests", otherwise use config
    final_test_dir = args.test_dir if args.test_dir != "tests" else default_test_dir

    sys.exit(build_mapping_iteratively(
        repo_root,
        mapping_db,
        test_dir=final_test_dir,
        verbose=args.verbose
    ))


def cmd_login(args):
    """Authenticate with Pintest and save API key to ~/.pintest/config.toml."""
    from .config import Config, CloudConfig, CONFIG_FILE

    api_url = args.api_url.rstrip("/")

    print(f"\n🔐 Pintest Login ({api_url})")
    print("────────────────────────────────────────")

    # Offer two paths: API key directly, or email/password
    print("\nOptions:")
    print("  1) Paste an existing API key (from https://pintest.dev/dashboard/keys)")
    print("  2) Login with email + password to generate a new key")
    choice = input("\nChoice [1/2]: ").strip()

    try:
        import requests
    except ImportError:
        print("❌ 'requests' is required: pip install requests")
        sys.exit(1)

    if choice == "1":
        api_key = getpass.getpass("Paste API key (pt_live_...): ").strip()
        if not api_key.startswith("pt_live_"):
            print("❌ Invalid key format — expected 'pt_live_...'")
            sys.exit(1)
    else:
        email = input("Email: ").strip()
        password = getpass.getpass("Password: ")

        # Login to get JWT, then create a new API key
        resp = requests.post(
            f"{api_url}/api/v1/auth/login",
            json={"email": email, "password": password},
            timeout=15,
        )
        if resp.status_code == 401:
            print("❌ Invalid email or password")
            sys.exit(1)
        resp.raise_for_status()
        jwt_token = resp.json()["access_token"]

        # Create a new API key scoped to query + push
        key_resp = requests.post(
            f"{api_url}/api/v1/auth/keys",
            json={"name": "cli-key", "scopes": ["query", "push"]},
            headers={"Authorization": f"Bearer {jwt_token}"},
            timeout=15,
        )
        key_resp.raise_for_status()
        api_key = key_resp.json()["key"]
        print(f"✓ New API key created (ID: {key_resp.json()['id']})")

    # Save to config
    cfg = Config.load()
    cfg.cloud = CloudConfig(api_key=api_key, api_url=api_url)
    cfg.save()

    print(f"\n✅ Logged in! Config saved to {CONFIG_FILE}")
    print(f"   Next step: pintest track")


def cmd_register(args):
    """Register a new account with Pintest."""
    api_url = args.api_url.rstrip("/")
    print(f"\n📝 Pintest Registration ({api_url})")
    print("────────────────────────────────────────")
    
    email = input("Email: ").strip()
    password = getpass.getpass("Password: ")
    org_name = input("Organization Name: ").strip()
    
    try:
        import requests
        resp = requests.post(
            f"{api_url}/api/v1/auth/register",
            json={"email": email, "password": password, "org_name": org_name},
            timeout=15,
        )
        if resp.status_code == 400:
            print(f"❌ {resp.json().get('detail', 'Registration failed')}")
            sys.exit(1)
        resp.raise_for_status()
        print("✅ Account created successfully!")
        print(f"   Organization '{org_name}' registered on the Free plan.")
        print("   You can now log in using 'pintest login'")
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


def cmd_track(args):
    """Register a repository with Pintest and save repo_id to config."""
    import os
    import sys
    from .config import Config

    repo_name = args.name
    if not repo_name:
        repo_name = os.path.basename(os.getcwd())

    branch = args.branch
    if not branch:
        try:
            branch = input("🌿 Target branch to track [main]: ").strip()
            if not branch:
                branch = "main"
        except (KeyboardInterrupt, EOFError):
            print("\n❌ Cancelled")
            sys.exit(1)
            
    try:
        test_dir = input("📁 Test directory [tests]: ").strip()
        if not test_dir:
            test_dir = "tests"
    except (KeyboardInterrupt, EOFError):
        print("\n❌ Cancelled")
        sys.exit(1)

    cfg = Config.load()
    if not cfg.is_cloud_enabled:
        print("❌ Not logged in. Run: pintest login")
        sys.exit(1)

    try:
        import requests
    except ImportError:
        print("❌ 'requests' is required: pip install requests")
        sys.exit(1)

    api_url = cfg.cloud.api_url
    headers = {
        "Authorization": f"Bearer {cfg.cloud.api_key}",
        "Content-Type": "application/json",
    }

    print(f"\n📦 Registering repo '{repo_name}' with Pintest...")

    resp = requests.post(
        f"{api_url}/api/v1/repos",
        json={
            "name": repo_name,
            "remote_url": args.remote_url,
            "default_branch": branch,
        },
        headers=headers,
        timeout=15,
    )

    if resp.status_code == 400:
        detail = resp.json().get("detail", "")
        print(f"❌ {detail}")
        sys.exit(1)
    
    if resp.status_code == 402:
        detail = resp.json().get("detail", "")
        print(f"\n❌ {detail}")
        sys.exit(1)
        
    resp.raise_for_status()

    repo = resp.json()
    repo_id = repo["id"]

    # Save repo_id, branch, and test_dir to config
    cfg.cloud.repo_id = repo_id
    cfg.cloud.branch = branch
    cfg.cloud.test_dir = test_dir
    cfg.save()
    
    print(f"✅ Success! Repository mapped to {branch} branch")
    print(f"   Name:    {repo['name']}")
    print(f"   ID:      {repo_id}")
    print(f"   Branch:  {branch}")
    print(f"   Config:  ~/.pintest/config.toml")
    print(f"\n   Your pre-commit hook will now use the Pintest cloud API automatically.")


def cmd_push(args):
    """Sync local coverage mappings to Pintest cloud."""
    from .cloud_mapping_db import CloudMappingDB
    from .config import Config

    repo_root = Path.cwd()
    config = Config.load()
    
    if not config.is_cloud_enabled or not config.cloud.repo_id:
        print("❌ Repository not registered. Run 'pintest track' first.")
        sys.exit(1)

    coverage_file = repo_root / ".coverage"
    if not coverage_file.exists() and (repo_root / "coverage" / ".coverage").exists():
        coverage_file = repo_root / "coverage" / ".coverage"
    if not coverage_file.exists():
        print(f"❌ Coverage file not found at {coverage_file}")
        print("Run your tests first (e.g. 'pytest --cov --cov-context=test')")
        sys.exit(1)

    print(f"☁️  Pintest Cloud Sync (repo: {config.cloud.repo_id[:8]}...)")
    db = CloudMappingDB(config.cloud)
    
    success = db.push_coverage(coverage_file, verbose=args.verbose)
    
    if success:
        print("✅ Success!")
    else:
        print("❌ Push failed.")
        sys.exit(1)


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Pintest - Run only tests affected by code changes",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Run command (default behavior)
    run_parser = subparsers.add_parser(
        'run',
        help='Run affected tests',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pintest run --repo-root ~/workspace/myproject
  pintest run --repo-root ~/workspace/myproject --dry-run
  pintest run --repo-root ~/workspace/myproject --base-branch develop
        """
    )
    run_parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path.cwd(),
        help="Repository root directory (default: current directory)"
    )
    run_parser.add_argument(
        "--base-branch",
        default="master",
        help="Base branch to compare against (default: master)"
    )
    run_parser.add_argument(
        "--coverage-file",
        type=Path,
        help="Path to coverage database file (default: <repo>/.coverage)"
    )
    run_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print tests without running them"
    )
    run_parser.add_argument(
        "--min-tests",
        type=int,
        default=0,
        help="Minimum number of tests to run (exit with error if below)"
    )
    run_parser.add_argument(
        "--test-dir",
        help="Directory containing tests (default: read from config or tests/)"
    )
    run_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show detailed output"
    )
    run_parser.add_argument(
        "pytest_args",
        nargs=argparse.REMAINDER,
        help="Additional arguments to pass to pytest (after --)"
    )
    run_parser.set_defaults(func=cmd_run)
    
    # Update mapping command
    update_parser = subparsers.add_parser(
        'update-mapping',
        help='Update test mapping database from coverage',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pintest update-mapping --repo-root ~/workspace/myproject
  pintest update-mapping --repo-root ~/workspace/myproject --verbose
        """
    )
    update_parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path.cwd(),
        help="Repository root directory (default: current directory)"
    )
    update_parser.add_argument(
        "--coverage-file",
        type=Path,
        help="Path to .coverage file (default: <repo>/.coverage)"
    )
    update_parser.add_argument(
        "--mapping-db",
        type=Path,
        help="Path to mapping database (default: <repo>/.pintest/test_mapping.db)"
    )
    update_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output"
    )
    update_parser.set_defaults(func=cmd_update_mapping)
    
    # Build mapping iteratively command
    build_parser = subparsers.add_parser(
        'build-mapping',
        help='Build test mapping database iteratively (resumable)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pintest build-mapping --repo-root ~/workspace/myproject
  pintest build-mapping --repo-root ~/workspace/myproject --resume
  pintest build-mapping --repo-root ~/workspace/myproject --verbose
        """
    )
    build_parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path.cwd(),
        help="Repository root directory (default: current directory)"
    )
    build_parser.add_argument(
        "--mapping-db",
        type=Path,
        help="Path to mapping database (default: <repo>/.pintest/test_mapping.db)"
    )
    build_parser.add_argument(
        "--test-dir",
        default="tests",
        help="Directory containing tests (default: tests)"
    )
    build_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output"
    )
    build_parser.set_defaults(func=cmd_build_mapping)

    # Login command
    login_parser = subparsers.add_parser(
        'login',
        help='Authenticate with Pintest cloud (saves API key to ~/.pintest/config.toml)',
    )
    login_parser.add_argument(
        "--api-url",
        default="https://api.pintest.dev",
        help="Pintest API URL (default: https://api.pintest.dev)"
    )
    login_parser.set_defaults(func=cmd_login)

    # Register command
    register_parser = subparsers.add_parser(
        'register',
        help='Create a new Pintest account',
    )
    register_parser.add_argument(
        "--api-url",
        default="https://api.pintest.dev",
        help="Pintest API URL (default: https://api.pintest.dev)"
    )
    register_parser.set_defaults(func=cmd_register)

    # Track command
    track_parser = subparsers.add_parser(
        'track',
        help='Register this repository with Pintest cloud to track it',
    )
    track_parser.add_argument(
        '--name', required=False,
        help='Repository name (defaults to current directory name)'
    )
    track_parser.add_argument(
        '--branch', '-b', default=None,
        help='Default branch to track (prompts if not provided)'
    )
    track_parser.add_argument(
        '--remote-url',
        default=None,
        help='Remote URL (e.g. https://github.com/org/repo) — optional'
    )
    track_parser.set_defaults(func=cmd_track)
    
    # Push command
    push_parser = subparsers.add_parser(
        'push',
        help='Sync local coverage mappings to Pintest cloud',
    )
    push_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output"
    )
    push_parser.set_defaults(func=cmd_push)
    
    # Parse arguments
    args = parser.parse_args()
    
    # If no command specified, default to 'run'
    if not args.command:
        # Parse as 'run' command for backward compatibility
        run_args = ['run'] + sys.argv[1:]
        args = parser.parse_args(run_args)
    
    # Execute command
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
