#!/usr/bin/env python3
"""
Post-commit hook that automatically pushes commits.

This hook runs after a successful commit and pushes the changes to the remote repository.
Includes the updated test mapping database if it was modified.
"""

import subprocess
import sys
from pathlib import Path


def main():
    """
    Post-commit hook: automatically push changes to remote.
    """
    # Get repository root
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
        check=False
    )
    
    if result.returncode != 0:
        print("❌ Failed to find git repository root", file=sys.stderr)
        return 1
    
    repo_root = Path(result.stdout.strip())
    
    # Get current branch
    result = subprocess.run(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False
    )
    
    if result.returncode != 0:
        print("❌ Failed to get current branch", file=sys.stderr)
        return 1
    
    current_branch = result.stdout.strip()
    
    # Check if we have a remote configured
    result = subprocess.run(
        ["git", "remote"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False
    )
    
    if not result.stdout.strip():
        # No remote configured - skip push
        return 0
    
    # Push to remote
    print(f"\n🚀 Pushing to remote: {current_branch}...")
    
    result = subprocess.run(
        ["git", "push", "origin", current_branch],
        cwd=repo_root
    )
    
    if result.returncode == 0:
        print("✅ Successfully pushed to remote")
        return 0
    else:
        print("⚠️  Push failed - you may need to pull or resolve conflicts", file=sys.stderr)
        print("   Run 'git push' manually when ready", file=sys.stderr)
        return 0  # Don't fail the commit if push fails


if __name__ == "__main__":
    sys.exit(main())
