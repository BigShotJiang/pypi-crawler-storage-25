from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pintest-cli",
    version="0.3.2",
    description="Run only the tests affected by your code changes.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Pintest Contributors",
    packages=find_packages(),
    install_requires=[
        "pytest>=7.0.0",
        "pytest-cov>=4.0.0",
        "coverage[toml]>=7.0.0",
        "requests>=2.25.0",
    ],
    entry_points={
        "console_scripts": [
            "pintest=pintest.cli:main",
        ],
        "pytest11": [
            "pintest.pytest_plugin = pintest.pytest_plugin",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
