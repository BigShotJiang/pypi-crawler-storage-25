"""Tests for pintest package."""
