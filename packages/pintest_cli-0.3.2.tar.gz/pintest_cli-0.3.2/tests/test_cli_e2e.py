import os
import subprocess
import pytest
import sys

@pytest.fixture
def dummy_repo(tmp_path):
    # 1. Create a dummy Python project in tmp_path
    repo_dir = tmp_path / "dummy_repo"
    repo_dir.mkdir()
    
    # 2. Initialize git
    subprocess.run(["git", "init", "-b", "main"], cwd=repo_dir, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=repo_dir, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test User"], cwd=repo_dir, check=True, capture_output=True)
    
    # 3. Create pintest.toml
    pintest_toml = repo_dir / "pintest.toml"
    pintest_toml.write_text("""
[cloud]
enabled = false
[local]
test_dir = "tests"
""")

    # 4. Create source files
    src_dir = repo_dir / "src"
    src_dir.mkdir()
    
    math_py = src_dir / "math_utils.py"
    math_py.write_text("""def add(a, b):
    return a + b

def subtract(a, b):
    return a - b
""")

    string_py = src_dir / "string_utils.py"
    string_py.write_text("""def to_upper(s):
    return s.upper()
""")

    # 5. Create test files
    tests_dir = repo_dir / "tests"
    tests_dir.mkdir()
    
    test_math_py = tests_dir / "test_math.py"
    test_math_py.write_text("""import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.math_utils import add, subtract

def test_add():
    assert add(1, 2) == 3

def test_subtract():
    assert subtract(2, 1) == 1
""")

    test_string_py = tests_dir / "test_string.py"
    test_string_py.write_text("""import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.string_utils import to_upper

def test_to_upper():
    assert to_upper("a") == "A"
""")

    # 6. Commit everything
    subprocess.run(["git", "add", "."], cwd=repo_dir, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=repo_dir, check=True, capture_output=True)
    
    return repo_dir

def run_pintest(args, cwd):
    env = os.environ.copy()
    env["HOME"] = str(cwd)  # Prevent reading global ~/.pintest/config.toml
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    env["PYTHONPATH"] = repo_root + (os.pathsep + env["PYTHONPATH"] if "PYTHONPATH" in env else "")
    cmd = [sys.executable, "-m", "pintest.cli"] + args
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, env=env)
    return result

def test_pintest_track_and_run(dummy_repo):
    # Scenario A (Baseline): Run pintest build-mapping
    res = run_pintest(["build-mapping"], cwd=dummy_repo)
    assert res.returncode == 0
    
    # Check if mapping db is created
    db_path = dummy_repo / ".pintest" / "test_mapping.db"
    assert db_path.exists()
    
    # Verify nothing to run on clean working tree
    res = run_pintest(["run", "--dry-run", "--base-branch=main"], cwd=dummy_repo)
    assert res.returncode == 0
    # Expected: "Would run 0 test" or "No tests to run!" or "Running 0 selected"
    # Actually, current code outputs "Would run 0 test(s)" if test_selection is not empty but dry-run is provided?
    # No, cli.py has `if not test_selection: print("No tests to run!"); return 0`
    assert "No tests to run" in res.stdout or "0 test(s)" in res.stdout

    # Scenario C (True Positive): Modify a tracked line
    math_py = dummy_repo / "src" / "math_utils.py"
    content = math_py.read_text()
    # Change add function
    content = content.replace("return a + b", "return a + b + 0")
    math_py.write_text(content)
    
    res = run_pintest(["run", "--dry-run", "--base-branch=main", "-v"], cwd=dummy_repo)
    print("STDOUT:", res.stdout)
    print("STDERR:", res.stderr)
    assert res.returncode == 0
    assert "tests/test_math.py::test_add" in res.stdout or "test_math.py" in res.stdout
    assert "test_string.py" not in res.stdout
    
    # Revert math.py
    subprocess.run(["git", "checkout", "--", "src/math_utils.py"], cwd=dummy_repo, check=True)

    # Scenario D (True Negative): Add a comment
    content = math_py.read_text()
    content += "\n# This is a comment\n"
    math_py.write_text(content)
    
    res = run_pintest(["run", "--dry-run", "--base-branch=main"], cwd=dummy_repo)
    assert res.returncode == 0
    # The comment line was never executed, so adding it shouldn't trigger any tests.
    assert "No tests to run" in res.stdout or "0 test(s)" in res.stdout

    # Revert math.py
    subprocess.run(["git", "checkout", "--", "src/math_utils.py"], cwd=dummy_repo, check=True)

    # Scenario E (New Test Discovery): Add a new test file
    test_new_py = dummy_repo / "tests" / "test_new.py"
    test_new_py.write_text("""def test_something_new():\n    assert True\n""")
    subprocess.run(["git", "add", "tests/test_new.py"], cwd=dummy_repo, check=True)
    
    res = run_pintest(["run", "--dry-run", "--base-branch=main"], cwd=dummy_repo)
    assert res.returncode == 0
    assert "test_new.py" in res.stdout
    
    # Remove test_new.py and unstage
    subprocess.run(["git", "rm", "-f", "tests/test_new.py"], cwd=dummy_repo, check=True)

    # Scenario F (Deleted File): Delete a test file and modify related source
    os.remove(dummy_repo / "tests" / "test_string.py")
    subprocess.run(["git", "add", "."], cwd=dummy_repo, check=True)
    subprocess.run(["git", "commit", "-m", "Remove test_string.py"], cwd=dummy_repo, check=True)
    
    # Modify string_utils.py which used to be covered by the deleted test
    string_py = dummy_repo / "src" / "string_utils.py"
    content = string_py.read_text()
    content = content.replace("return s.upper()", "return s.upper() + ''")
    string_py.write_text(content)
    
    res = run_pintest(["run", "--dry-run", "--base-branch=main"], cwd=dummy_repo)
    assert res.returncode == 0
    # test_string_py is gone. pintest run shouldn't crash trying to find it.
    assert "Exception" not in res.stderr
    assert "Traceback" not in res.stderr


def test_pintest_chunking_and_fail_fast(dummy_repo):
    from pintest.cli import PintestRunner
    runner = PintestRunner(dummy_repo, verbose=True)
    
    # Generate 505 dummy test names
    dummy_tests = {f"tests/test_math.py::test_dummy_{i}" for i in range(505)}
    
    # Run with fail-fast (-x)
    # Since these dummy tests don't exist, pytest will fail on the first chunk.
    # PintestRunner should catch the failure and abort the second chunk.
    import io
    from unittest.mock import patch
    
    # Capture stderr to verify the abort message
    stderr_buf = io.StringIO()
    with patch("sys.stderr", stderr_buf):
        returncode = runner.run_tests(dummy_tests, dry_run=False, verbose=True, pytest_args=["-x"])
    
    assert returncode != 0
    stderr_output = stderr_buf.getvalue()
    assert "Fail-fast enabled" in stderr_output
    assert "Aborting remaining 1 chunk(s)" in stderr_output

