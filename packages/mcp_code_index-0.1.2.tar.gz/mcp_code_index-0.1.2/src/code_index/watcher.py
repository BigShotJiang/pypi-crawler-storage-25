"""Filesystem watcher that pushes change events to the indexer."""

from __future__ import annotations

import logging
import queue
import threading
import time
from pathlib import Path

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from .indexer import Indexer
from .parser import language_for_path
from .walker import load_ignore_spec

log = logging.getLogger(__name__)

DEBOUNCE_SEC = 0.4


class _Handler(FileSystemEventHandler):
    def __init__(self, q: "queue.Queue[tuple[str, Path]]", root: Path) -> None:
        self.q = q
        self.root = root
        self.spec = load_ignore_spec(root)

    def _emit(self, kind: str, path_str: str) -> None:
        path = Path(path_str)
        try:
            rel = path.resolve().relative_to(self.root)
        except ValueError:
            return
        if self.spec.match_file(str(rel)):
            return
        if language_for_path(path) is None:
            return
        self.q.put((kind, path))

    def on_created(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._emit("upsert", event.src_path)

    def on_modified(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._emit("upsert", event.src_path)

    def on_moved(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        self._emit("delete", event.src_path)
        dest = getattr(event, "dest_path", None)
        if dest:
            self._emit("upsert", dest)

    def on_deleted(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._emit("delete", event.src_path)


def run_watcher(root: Path) -> None:
    """Block forever, watching `root` and reindexing changed files in a worker thread."""
    root = root.resolve()
    indexer = Indexer(root=root)

    events: "queue.Queue[tuple[str, Path]]" = queue.Queue()
    handler = _Handler(events, root)
    observer = Observer()
    observer.schedule(handler, str(root), recursive=True)
    observer.start()
    log.info("watcher started at %s", root)

    pending: dict[Path, tuple[str, float]] = {}
    stop = threading.Event()

    def worker() -> None:
        while not stop.is_set():
            now = time.monotonic()
            ready = [(p, kind) for p, (kind, ts) in list(pending.items()) if now - ts >= DEBOUNCE_SEC]
            for path, kind in ready:
                pending.pop(path, None)
                try:
                    if kind == "delete":
                        _delete_path(indexer, path)
                    else:
                        indexer.reindex_file(path)
                except Exception as exc:  # noqa: BLE001
                    log.warning("watcher: failed on %s: %s", path, exc)
            try:
                kind, path = events.get(timeout=DEBOUNCE_SEC / 2)
            except queue.Empty:
                continue
            pending[path] = (kind, time.monotonic())

    t = threading.Thread(target=worker, daemon=True)
    t.start()

    try:
        while True:
            time.sleep(1.0)
    except KeyboardInterrupt:
        log.info("watcher stopping")
    finally:
        stop.set()
        observer.stop()
        observer.join()
        indexer.close()


def _delete_path(indexer: Indexer, path: Path) -> None:
    """Remove a deleted file from the index."""
    try:
        rel = str(path.resolve().relative_to(indexer.root))
    except ValueError:
        return
    indexer.conn.execute("DELETE FROM files WHERE path = ?", (rel,))
    indexer.conn.commit()
