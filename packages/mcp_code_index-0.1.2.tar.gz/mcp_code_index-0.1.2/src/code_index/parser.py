"""Tree-sitter parsing: language detection, symbol and edge extraction."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import tree_sitter_go
import tree_sitter_python
import tree_sitter_rust
import tree_sitter_typescript
from tree_sitter import Language, Node, Parser

log = logging.getLogger(__name__)

PY_LANG = Language(tree_sitter_python.language())
TS_LANG = Language(tree_sitter_typescript.language_typescript())
TSX_LANG = Language(tree_sitter_typescript.language_tsx())
GO_LANG = Language(tree_sitter_go.language())
RUST_LANG = Language(tree_sitter_rust.language())

EXT_TO_LANG = {
    ".py": "python",
    ".pyi": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "typescript",
    ".jsx": "tsx",
    ".mjs": "typescript",
    ".cjs": "typescript",
    ".go": "go",
    ".rs": "rust",
}

LANG_TO_TS_LANG = {
    "python": PY_LANG,
    "typescript": TS_LANG,
    "tsx": TSX_LANG,
    "go": GO_LANG,
    "rust": RUST_LANG,
}


def language_for_path(path: Path) -> str | None:
    return EXT_TO_LANG.get(path.suffix.lower())


# Symbol kinds we track.
KIND_FUNCTION = "function"
KIND_METHOD = "method"
KIND_CLASS = "class"
KIND_STRUCT = "struct"
KIND_ENUM = "enum"
KIND_TRAIT = "trait"
KIND_INTERFACE = "interface"
KIND_TYPE = "type"
KIND_CONST = "const"
KIND_IMPL = "impl"

# Edge kinds.
EDGE_CALLS = "calls"
EDGE_IMPORTS = "imports"
EDGE_INHERITS = "inherits"
EDGE_REFERENCES = "references"


@dataclass
class Symbol:
    name: str
    qualified_name: str
    kind: str
    start_line: int
    end_line: int
    signature: str | None = None
    docstring: str | None = None
    parent_idx: int | None = None  # index into symbols list, resolved to db id later


@dataclass
class Reference:
    """An unresolved reference from one symbol to a name in another file."""
    src_idx: int  # index into symbols list
    target_name: str
    kind: str  # EDGE_CALLS | EDGE_INHERITS | EDGE_REFERENCES


@dataclass
class FileImport:
    """A best-effort module/path import to be resolved later."""
    target: str  # module path or relative file path
    is_relative: bool = False


@dataclass
class ParseResult:
    lang: str
    symbols: list[Symbol] = field(default_factory=list)
    refs: list[Reference] = field(default_factory=list)
    imports: list[FileImport] = field(default_factory=list)


def parse_source(source: bytes, lang: str) -> ParseResult:
    """Parse source code and extract symbols, references, and imports."""
    ts_lang = LANG_TO_TS_LANG.get(lang)
    if ts_lang is None:
        return ParseResult(lang=lang)
    parser = Parser(ts_lang)
    tree = parser.parse(source)
    extractor = _EXTRACTORS[lang](source, tree.root_node)
    extractor.run()
    return ParseResult(
        lang=lang,
        symbols=extractor.symbols,
        refs=extractor.refs,
        imports=extractor.imports,
    )


def parse_file(path: Path) -> ParseResult | None:
    lang = language_for_path(path)
    if lang is None:
        return None
    try:
        source = path.read_bytes()
    except OSError as exc:
        log.warning("could not read %s: %s", path, exc)
        return None
    return parse_source(source, lang)


# -- Extractors ----------------------------------------------------------------


class _BaseExtractor:
    """Walks a tree-sitter tree, populating symbols / refs / imports."""

    function_kinds: set[str] = set()  # node types that introduce a function-like scope

    def __init__(self, source: bytes, root: Node) -> None:
        self.source = source
        self.root = root
        self.symbols: list[Symbol] = []
        self.refs: list[Reference] = []
        self.imports: list[FileImport] = []
        self._scope_stack: list[str] = []  # qualified name parts
        self._parent_stack: list[int] = []  # symbol indices

    # --- helpers
    def _text(self, node: Node | None) -> str:
        if node is None:
            return ""
        return self.source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")

    def _add_symbol(
        self,
        name: str,
        kind: str,
        node: Node,
        signature: str | None = None,
        docstring: str | None = None,
    ) -> int:
        qname = ".".join(self._scope_stack + [name])
        sym = Symbol(
            name=name,
            qualified_name=qname,
            kind=kind,
            start_line=node.start_point[0] + 1,
            end_line=node.end_point[0] + 1,
            signature=signature,
            docstring=docstring,
            parent_idx=self._parent_stack[-1] if self._parent_stack else None,
        )
        self.symbols.append(sym)
        return len(self.symbols) - 1

    # --- subclasses override
    def run(self) -> None:
        self._walk(self.root)

    def _walk(self, node: Node) -> None:
        raise NotImplementedError


# -- Python --------------------------------------------------------------------


class PythonExtractor(_BaseExtractor):
    def _walk(self, node: Node) -> None:
        for child in node.named_children:
            t = child.type
            if t == "function_definition":
                self._handle_function(child)
            elif t == "class_definition":
                self._handle_class(child)
            elif t == "decorated_definition":
                inner = child.child_by_field_name("definition")
                if inner is not None:
                    if inner.type == "function_definition":
                        self._handle_function(inner)
                    elif inner.type == "class_definition":
                        self._handle_class(inner)
            elif t in ("import_statement", "import_from_statement"):
                self._handle_import(child)
            elif t == "expression_statement":
                # module-level constants: NAME = value
                inner = child.named_child(0)
                if inner is not None and inner.type == "assignment":
                    self._handle_assignment(inner)
            else:
                self._walk(child)

    def _handle_function(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        params = node.child_by_field_name("parameters")
        ret = node.child_by_field_name("return_type")
        if name_node is None:
            return
        name = self._text(name_node)
        signature = f"def {name}{self._text(params)}"
        if ret is not None:
            signature += f" -> {self._text(ret)}"
        kind = KIND_METHOD if self._parent_stack else KIND_FUNCTION
        body = node.child_by_field_name("body")
        docstring = _python_docstring(body, self.source)
        idx = self._add_symbol(name, kind, node, signature=signature, docstring=docstring)
        self._scope_stack.append(name)
        self._parent_stack.append(idx)
        if body is not None:
            self._collect_calls_and_refs(body, idx)
        self._parent_stack.pop()
        self._scope_stack.pop()

    def _handle_class(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        name = self._text(name_node)
        super_args = node.child_by_field_name("superclasses")
        signature = f"class {name}{self._text(super_args)}".rstrip()
        body = node.child_by_field_name("body")
        docstring = _python_docstring(body, self.source)
        idx = self._add_symbol(name, KIND_CLASS, node, signature=signature, docstring=docstring)

        # superclass references
        if super_args is not None:
            for ch in super_args.named_children:
                base = self._text(ch)
                if base:
                    self.refs.append(Reference(idx, base, EDGE_INHERITS))

        self._scope_stack.append(name)
        self._parent_stack.append(idx)
        if body is not None:
            self._walk(body)
        self._parent_stack.pop()
        self._scope_stack.pop()

    def _handle_assignment(self, node: Node) -> None:
        if self._parent_stack:
            return  # only track module-level constants
        left = node.child_by_field_name("left")
        if left is None or left.type != "identifier":
            return
        name = self._text(left)
        # Track ALL_CAPS / UPPER_SNAKE only.
        if len(name) < 2 or not name.replace("_", "").isupper() or not any(c.isalpha() for c in name):
            return
        self._add_symbol(name, KIND_CONST, node, signature=f"{name} = ...")

    def _handle_import(self, node: Node) -> None:
        if node.type == "import_statement":
            for child in node.named_children:
                target = self._text(child)
                if target:
                    self.imports.append(FileImport(target=target, is_relative=False))
        else:  # import_from_statement
            module = node.child_by_field_name("module_name")
            target = self._text(module) if module else ""
            if not target:
                return
            is_relative = target.startswith(".")
            self.imports.append(FileImport(target=target, is_relative=is_relative))

    def _collect_calls_and_refs(self, body: Node, src_idx: int) -> None:
        # Walk only this function body; recurse into nested defs separately.
        stack: list[Node] = [body]
        while stack:
            n = stack.pop()
            t = n.type
            if t in ("function_definition", "class_definition"):
                # Nested defs are handled by the outer walk.
                if n is not body:
                    self._walk(n)
                    continue
            if t == "call":
                fn = n.child_by_field_name("function")
                target = _python_call_target(fn, self.source)
                if target:
                    self.refs.append(Reference(src_idx, target, EDGE_CALLS))
            for ch in n.named_children:
                stack.append(ch)


def _python_docstring(body: Node | None, source: bytes) -> str | None:
    if body is None:
        return None
    first = body.named_child(0)
    if first is None or first.type != "expression_statement":
        return None
    inner = first.named_child(0)
    if inner is None or inner.type != "string":
        return None
    raw = source[inner.start_byte:inner.end_byte].decode("utf-8", errors="replace")
    return raw.strip().strip('"').strip("'")[:500]


def _python_call_target(fn: Node | None, source: bytes) -> str | None:
    if fn is None:
        return None
    if fn.type == "identifier":
        return source[fn.start_byte:fn.end_byte].decode("utf-8", errors="replace")
    if fn.type == "attribute":
        attr = fn.child_by_field_name("attribute")
        if attr is not None:
            return source[attr.start_byte:attr.end_byte].decode("utf-8", errors="replace")
    return None


# -- TypeScript / JavaScript ---------------------------------------------------


class TypeScriptExtractor(_BaseExtractor):
    def _walk(self, node: Node) -> None:
        for child in node.named_children:
            self._dispatch(child)

    def _dispatch(self, node: Node) -> None:
        t = node.type
        if t == "function_declaration":
            self._handle_function(node)
        elif t == "class_declaration":
            self._handle_class(node)
        elif t == "interface_declaration":
            self._handle_interface(node)
        elif t == "type_alias_declaration":
            self._handle_type_alias(node)
        elif t == "method_definition":
            self._handle_method(node)
        elif t in ("lexical_declaration", "variable_declaration"):
            self._handle_var(node)
        elif t == "import_statement":
            self._handle_import(node)
        elif t == "export_statement":
            inner = node.named_child(0)
            if inner is not None:
                self._dispatch(inner)
        elif t == "ambient_declaration":
            for ch in node.named_children:
                self._dispatch(ch)
        else:
            self._walk(node)

    def _handle_function(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        params = node.child_by_field_name("parameters")
        ret = node.child_by_field_name("return_type")
        if name_node is None:
            return
        name = self._text(name_node)
        sig = f"function {name}{self._text(params)}"
        if ret is not None:
            sig += f" {self._text(ret)}"
        idx = self._add_symbol(name, KIND_FUNCTION, node, signature=sig)
        body = node.child_by_field_name("body")
        if body is not None:
            self._scope_stack.append(name)
            self._parent_stack.append(idx)
            self._collect_body(body, idx)
            self._parent_stack.pop()
            self._scope_stack.pop()

    def _handle_class(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        name = self._text(name_node)
        heritage = node.child_by_field_name("class_heritage")
        sig = f"class {name}{self._text(heritage)}".rstrip()
        idx = self._add_symbol(name, KIND_CLASS, node, signature=sig)
        if heritage is not None:
            for ch in _walk_descendants(heritage):
                if ch.type in ("identifier", "type_identifier"):
                    base = self._text(ch)
                    if base:
                        self.refs.append(Reference(idx, base, EDGE_INHERITS))
        body = node.child_by_field_name("body")
        if body is not None:
            self._scope_stack.append(name)
            self._parent_stack.append(idx)
            for ch in body.named_children:
                self._dispatch(ch)
            self._parent_stack.pop()
            self._scope_stack.pop()

    def _handle_method(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        params = node.child_by_field_name("parameters")
        ret = node.child_by_field_name("return_type")
        if name_node is None:
            return
        name = self._text(name_node)
        sig = f"{name}{self._text(params)}"
        if ret is not None:
            sig += f" {self._text(ret)}"
        idx = self._add_symbol(name, KIND_METHOD, node, signature=sig)
        body = node.child_by_field_name("body")
        if body is not None:
            self._scope_stack.append(name)
            self._parent_stack.append(idx)
            self._collect_body(body, idx)
            self._parent_stack.pop()
            self._scope_stack.pop()

    def _handle_interface(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        name = self._text(name_node)
        self._add_symbol(name, KIND_INTERFACE, node, signature=f"interface {name}")

    def _handle_type_alias(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        name = self._text(name_node)
        self._add_symbol(name, KIND_TYPE, node, signature=f"type {name}")

    def _handle_var(self, node: Node) -> None:
        # Match arrow-function declarations: const foo = (x) => ...
        for declarator in node.named_children:
            if declarator.type != "variable_declarator":
                continue
            name_node = declarator.child_by_field_name("name")
            value = declarator.child_by_field_name("value")
            if name_node is None or value is None:
                continue
            if value.type in ("arrow_function", "function_expression"):
                name = self._text(name_node)
                params = value.child_by_field_name("parameters")
                ret = value.child_by_field_name("return_type")
                sig = f"const {name} = {self._text(params)} =>"
                if ret is not None:
                    sig = f"const {name}: {self._text(ret)} = {self._text(params)} =>"
                idx = self._add_symbol(name, KIND_FUNCTION, declarator, signature=sig)
                body = value.child_by_field_name("body")
                if body is not None:
                    self._scope_stack.append(name)
                    self._parent_stack.append(idx)
                    self._collect_body(body, idx)
                    self._parent_stack.pop()
                    self._scope_stack.pop()

    def _handle_import(self, node: Node) -> None:
        source = node.child_by_field_name("source")
        if source is None:
            return
        target = self._text(source).strip("'\"`")
        if target:
            self.imports.append(
                FileImport(target=target, is_relative=target.startswith("."))
            )

    def _collect_body(self, body: Node, src_idx: int) -> None:
        stack: list[Node] = [body]
        while stack:
            n = stack.pop()
            t = n.type
            if t == "call_expression":
                fn = n.child_by_field_name("function")
                target = _ts_call_target(fn, self.source)
                if target:
                    self.refs.append(Reference(src_idx, target, EDGE_CALLS))
            elif t == "new_expression":
                ctor = n.child_by_field_name("constructor")
                target = _ts_call_target(ctor, self.source)
                if target:
                    self.refs.append(Reference(src_idx, target, EDGE_CALLS))
            for ch in n.named_children:
                stack.append(ch)


def _ts_call_target(fn: Node | None, source: bytes) -> str | None:
    if fn is None:
        return None
    if fn.type == "identifier":
        return source[fn.start_byte:fn.end_byte].decode("utf-8", errors="replace")
    if fn.type == "member_expression":
        prop = fn.child_by_field_name("property")
        if prop is not None:
            return source[prop.start_byte:prop.end_byte].decode("utf-8", errors="replace")
    return None


def _walk_descendants(node: Node):
    stack: list[Node] = [node]
    while stack:
        n = stack.pop()
        yield n
        for ch in n.named_children:
            stack.append(ch)


# -- Go ------------------------------------------------------------------------


class GoExtractor(_BaseExtractor):
    def _walk(self, node: Node) -> None:
        for child in node.named_children:
            t = child.type
            if t == "function_declaration":
                self._handle_function(child, is_method=False)
            elif t == "method_declaration":
                self._handle_function(child, is_method=True)
            elif t == "type_declaration":
                self._handle_type_decl(child)
            elif t == "import_declaration":
                self._handle_import(child)
            else:
                self._walk(child)

    def _handle_function(self, node: Node, *, is_method: bool) -> None:
        name_node = node.child_by_field_name("name")
        params = node.child_by_field_name("parameters")
        result = node.child_by_field_name("result")
        if name_node is None:
            return
        name = self._text(name_node)
        receiver = node.child_by_field_name("receiver") if is_method else None
        prefix = f"func {self._text(receiver)} " if receiver is not None else "func "
        sig = f"{prefix}{name}{self._text(params)}"
        if result is not None:
            sig += f" {self._text(result)}"
        kind = KIND_METHOD if is_method else KIND_FUNCTION
        idx = self._add_symbol(name, kind, node, signature=sig)
        body = node.child_by_field_name("body")
        if body is not None:
            self._collect_body(body, idx)

    def _handle_type_decl(self, node: Node) -> None:
        for spec in node.named_children:
            if spec.type != "type_spec":
                continue
            name_node = spec.child_by_field_name("name")
            type_node = spec.child_by_field_name("type")
            if name_node is None:
                continue
            name = self._text(name_node)
            if type_node is not None and type_node.type == "struct_type":
                self._add_symbol(name, KIND_STRUCT, spec, signature=f"type {name} struct")
            elif type_node is not None and type_node.type == "interface_type":
                self._add_symbol(name, KIND_INTERFACE, spec, signature=f"type {name} interface")
            else:
                self._add_symbol(name, KIND_TYPE, spec, signature=f"type {name} {self._text(type_node)}")

    def _handle_import(self, node: Node) -> None:
        for ch in _walk_descendants(node):
            if ch.type == "interpreted_string_literal":
                target = self._text(ch).strip('"')
                if target:
                    self.imports.append(
                        FileImport(target=target, is_relative=target.startswith("."))
                    )

    def _collect_body(self, body: Node, src_idx: int) -> None:
        stack: list[Node] = [body]
        while stack:
            n = stack.pop()
            if n.type == "call_expression":
                fn = n.child_by_field_name("function")
                target = _go_call_target(fn, self.source)
                if target:
                    self.refs.append(Reference(src_idx, target, EDGE_CALLS))
            for ch in n.named_children:
                stack.append(ch)


def _go_call_target(fn: Node | None, source: bytes) -> str | None:
    if fn is None:
        return None
    if fn.type == "identifier":
        return source[fn.start_byte:fn.end_byte].decode("utf-8", errors="replace")
    if fn.type == "selector_expression":
        field = fn.child_by_field_name("field")
        if field is not None:
            return source[field.start_byte:field.end_byte].decode("utf-8", errors="replace")
    return None


# -- Rust ----------------------------------------------------------------------


class RustExtractor(_BaseExtractor):
    def _walk(self, node: Node) -> None:
        for child in node.named_children:
            t = child.type
            if t == "function_item":
                self._handle_function(child)
            elif t == "struct_item":
                self._handle_struct(child)
            elif t == "enum_item":
                self._handle_enum(child)
            elif t == "trait_item":
                self._handle_trait(child)
            elif t == "impl_item":
                self._handle_impl(child)
            elif t == "use_declaration":
                self._handle_use(child)
            elif t == "mod_item":
                self._handle_mod(child)
            else:
                self._walk(child)

    def _handle_function(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        params = node.child_by_field_name("parameters")
        ret = node.child_by_field_name("return_type")
        if name_node is None:
            return
        name = self._text(name_node)
        sig = f"fn {name}{self._text(params)}"
        if ret is not None:
            sig += f" -> {self._text(ret)}"
        kind = KIND_METHOD if self._parent_stack else KIND_FUNCTION
        idx = self._add_symbol(name, kind, node, signature=sig)
        body = node.child_by_field_name("body")
        if body is not None:
            self._collect_body(body, idx)

    def _handle_struct(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        name = self._text(name_node)
        self._add_symbol(name, KIND_STRUCT, node, signature=f"struct {name}")

    def _handle_enum(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        name = self._text(name_node)
        self._add_symbol(name, KIND_ENUM, node, signature=f"enum {name}")

    def _handle_trait(self, node: Node) -> None:
        name_node = node.child_by_field_name("name")
        if name_node is None:
            return
        name = self._text(name_node)
        idx = self._add_symbol(name, KIND_TRAIT, node, signature=f"trait {name}")
        body = node.child_by_field_name("body")
        if body is not None:
            self._scope_stack.append(name)
            self._parent_stack.append(idx)
            self._walk(body)
            self._parent_stack.pop()
            self._scope_stack.pop()

    def _handle_impl(self, node: Node) -> None:
        type_node = node.child_by_field_name("type")
        trait_node = node.child_by_field_name("trait")
        type_name = self._text(type_node) if type_node else "?"
        trait_name = self._text(trait_node) if trait_node else None
        impl_name = f"impl {trait_name} for {type_name}" if trait_name else f"impl {type_name}"
        idx = self._add_symbol(impl_name, KIND_IMPL, node, signature=impl_name)
        if trait_node is not None:
            self.refs.append(Reference(idx, self._text(trait_node), EDGE_INHERITS))
        body = node.child_by_field_name("body")
        if body is not None:
            self._scope_stack.append(type_name)
            self._parent_stack.append(idx)
            self._walk(body)
            self._parent_stack.pop()
            self._scope_stack.pop()

    def _handle_mod(self, node: Node) -> None:
        body = node.child_by_field_name("body")
        if body is not None:
            name_node = node.child_by_field_name("name")
            name = self._text(name_node) if name_node else "mod"
            self._scope_stack.append(name)
            self._walk(body)
            self._scope_stack.pop()

    def _handle_use(self, node: Node) -> None:
        for ch in _walk_descendants(node):
            if ch.type in ("scoped_identifier", "identifier"):
                target = self._text(ch)
                if target:
                    self.imports.append(
                        FileImport(target=target, is_relative=target.startswith(("crate", "super", "self")))
                    )
                    return  # one import per use_declaration

    def _collect_body(self, body: Node, src_idx: int) -> None:
        stack: list[Node] = [body]
        while stack:
            n = stack.pop()
            if n.type == "call_expression":
                fn = n.child_by_field_name("function")
                target = _rust_call_target(fn, self.source)
                if target:
                    self.refs.append(Reference(src_idx, target, EDGE_CALLS))
            for ch in n.named_children:
                stack.append(ch)


def _rust_call_target(fn: Node | None, source: bytes) -> str | None:
    if fn is None:
        return None
    if fn.type == "identifier":
        return source[fn.start_byte:fn.end_byte].decode("utf-8", errors="replace")
    if fn.type == "field_expression":
        field = fn.child_by_field_name("field")
        if field is not None:
            return source[field.start_byte:field.end_byte].decode("utf-8", errors="replace")
    if fn.type == "scoped_identifier":
        name = fn.child_by_field_name("name")
        if name is not None:
            return source[name.start_byte:name.end_byte].decode("utf-8", errors="replace")
    return None


_EXTRACTORS = {
    "python": PythonExtractor,
    "typescript": TypeScriptExtractor,
    "tsx": TypeScriptExtractor,
    "go": GoExtractor,
    "rust": RustExtractor,
}
