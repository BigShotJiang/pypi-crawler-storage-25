"""Index pipeline: walk, parse, chunk, embed, and write to SQLite."""

from __future__ import annotations

import hashlib
import logging
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from . import db as dbm
from .chunker import Chunk, chunk_file
from .embedder import Embedder, make_embedder
from .parser import (
    EDGE_CALLS,
    EDGE_IMPORTS,
    EDGE_INHERITS,
    ParseResult,
    Reference,
    Symbol,
    parse_source,
)
from .walker import load_ignore_spec, walk_indexable

log = logging.getLogger(__name__)


@dataclass
class FileIndexResult:
    path: Path
    indexed: bool          # actually re-embedded (changed or new)
    chunk_count: int
    symbol_count: int
    elapsed_ms: int


@dataclass
class IndexStats:
    files_seen: int = 0
    files_indexed: int = 0
    files_skipped: int = 0
    chunks_written: int = 0
    elapsed_ms: int = 0


class Indexer:
    """Stateful indexer rooted at a repo path. Manages a single DB connection."""

    def __init__(
        self,
        root: Path,
        embedder: Embedder | None = None,
        conn: sqlite3.Connection | None = None,
    ) -> None:
        self.root = root.resolve()
        self.embedder = embedder or make_embedder()
        self.conn = conn or dbm.connect()
        dbm.init_schema(self.conn, self.embedder.dim)
        self._verify_dim()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:  # noqa: BLE001 — best effort
            pass

    def _verify_dim(self) -> None:
        stored = dbm.get_meta(self.conn, "embed_dim")
        if stored is not None and int(stored) != self.embedder.dim:
            raise RuntimeError(
                f"Embedding dim mismatch: DB has {stored}, embedder has {self.embedder.dim}. "
                f"Delete .claude/index.db and reindex."
            )
        dbm.set_meta(self.conn, "embed_model", self.embedder.model_name)

    # -- Public API ----------------------------------------------------------

    def reindex_all(self) -> IndexStats:
        """Walk the repo and (re)index every changed file, then resolve cross-refs."""
        t0 = time.perf_counter()
        stats = IndexStats()
        spec = load_ignore_spec(self.root)
        seen_paths: set[str] = set()
        for path, _lang in walk_indexable(self.root, spec):
            stats.files_seen += 1
            try:
                result = self.reindex_file(path)
            except Exception as exc:  # noqa: BLE001 — keep going
                log.exception("failed to index %s: %s", path, exc)
                continue
            seen_paths.add(self._rel(path))
            if result is None:
                continue
            if result.indexed:
                stats.files_indexed += 1
                stats.chunks_written += result.chunk_count
            else:
                stats.files_skipped += 1

        self._delete_missing_files(seen_paths)
        self._resolve_cross_refs()
        stats.elapsed_ms = int((time.perf_counter() - t0) * 1000)
        return stats

    def reindex_file(self, path: Path) -> FileIndexResult | None:
        """Reindex a single file. Returns None if path is not indexable."""
        path = path.resolve()
        try:
            relative = path.relative_to(self.root)
        except ValueError:
            log.warning("skip %s: outside root %s", path, self.root)
            return None

        from .parser import language_for_path
        lang = language_for_path(path)
        if lang is None:
            return None

        rel = str(relative)
        t0 = time.perf_counter()
        try:
            source = path.read_bytes()
        except OSError as exc:
            log.warning("could not read %s: %s", path, exc)
            self._delete_file_by_path(rel)
            return FileIndexResult(path=path, indexed=False, chunk_count=0, symbol_count=0, elapsed_ms=0)

        file_hash = _hash_bytes(source)
        existing = self._get_file_row(rel)
        if existing is not None and existing["hash"] == file_hash:
            return FileIndexResult(
                path=path, indexed=False, chunk_count=0, symbol_count=0, elapsed_ms=0
            )

        parse_result = parse_source(source, lang)
        chunks = chunk_file(rel, source, parse_result)

        embeddings: list[list[float]] = []
        if chunks:
            embeddings = self.embedder.embed_documents([c.embedded_text for c in chunks])

        with dbm.transaction(self.conn):
            if existing is not None:
                self._delete_file_rows(existing["id"])
            file_id = self._insert_file_row(rel, file_hash, lang, int(path.stat().st_mtime))
            symbol_ids = self._insert_symbols(file_id, parse_result.symbols)
            self._insert_chunks(file_id, chunks, embeddings, symbol_ids)
            self._insert_unresolved_refs(parse_result.refs, symbol_ids)
            self._insert_file_imports(file_id, parse_result.imports, lang, rel)

        elapsed = int((time.perf_counter() - t0) * 1000)
        return FileIndexResult(
            path=path,
            indexed=True,
            chunk_count=len(chunks),
            symbol_count=len(parse_result.symbols),
            elapsed_ms=elapsed,
        )

    # -- Internals -----------------------------------------------------------

    def _rel(self, path: Path) -> str:
        return str(path.resolve().relative_to(self.root))

    def _get_file_row(self, rel: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT id, hash FROM files WHERE path = ?", (rel,)
        ).fetchone()

    def _delete_file_by_path(self, rel: str) -> None:
        self.conn.execute("DELETE FROM files WHERE path = ?", (rel,))
        self.conn.commit()

    def _delete_file_rows(self, file_id: int) -> None:
        # Cascade handles symbols, chunks, edges, file_imports.
        # chunks_vec is NOT cascaded — clean it up explicitly.
        self.conn.execute(
            "DELETE FROM chunks_vec WHERE chunk_id IN "
            "(SELECT id FROM chunks WHERE file_id = ?)",
            (file_id,),
        )
        self.conn.execute("DELETE FROM files WHERE id = ?", (file_id,))

    def _delete_missing_files(self, seen: set[str]) -> None:
        rows = self.conn.execute("SELECT id, path FROM files").fetchall()
        for row in rows:
            if row["path"] not in seen:
                self._delete_file_rows(row["id"])
        self.conn.commit()

    def _insert_file_row(self, rel: str, file_hash: str, lang: str, mtime: int) -> int:
        cur = self.conn.execute(
            "INSERT INTO files(path, hash, lang, mtime) VALUES(?, ?, ?, ?)",
            (rel, file_hash, lang, mtime),
        )
        return cur.lastrowid

    def _insert_symbols(self, file_id: int, symbols: list[Symbol]) -> list[int]:
        """Insert symbols, resolving parent_idx → DB symbol id. Returns id list aligned with input."""
        ids: list[int] = [0] * len(symbols)
        for i, sym in enumerate(symbols):
            parent_db_id = ids[sym.parent_idx] if sym.parent_idx is not None else None
            cur = self.conn.execute(
                "INSERT INTO symbols(file_id, name, qualified_name, kind, parent_id, "
                "start_line, end_line, signature, docstring) "
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    file_id,
                    sym.name,
                    sym.qualified_name,
                    sym.kind,
                    parent_db_id,
                    sym.start_line,
                    sym.end_line,
                    sym.signature,
                    sym.docstring,
                ),
            )
            ids[i] = cur.lastrowid
        return ids

    def _insert_chunks(
        self,
        file_id: int,
        chunks: list[Chunk],
        embeddings: list[list[float]],
        symbol_ids: list[int],
    ) -> None:
        for chunk, emb in zip(chunks, embeddings):
            symbol_db_id = (
                symbol_ids[chunk.symbol_idx]
                if chunk.symbol_idx is not None and chunk.symbol_idx < len(symbol_ids)
                else None
            )
            cur = self.conn.execute(
                "INSERT INTO chunks(file_id, symbol_id, start_line, end_line, content) "
                "VALUES(?, ?, ?, ?, ?)",
                (file_id, symbol_db_id, chunk.start_line, chunk.end_line, chunk.content),
            )
            chunk_id = cur.lastrowid
            self.conn.execute(
                "INSERT INTO chunks_vec(chunk_id, embedding) VALUES(?, ?)",
                (chunk_id, dbm.serialize_vector(emb)),
            )

    def _insert_unresolved_refs(
        self, refs: list[Reference], symbol_ids: list[int]
    ) -> None:
        if not refs:
            return
        # Drop refs whose source symbol couldn't be resolved (shouldn't happen, but guard).
        rows = []
        for ref in refs:
            if ref.src_idx >= len(symbol_ids):
                continue
            rows.append((symbol_ids[ref.src_idx], ref.target_name, ref.kind))
        self.conn.executemany(
            "INSERT INTO unresolved_refs(src_symbol, target_name, kind) VALUES(?, ?, ?)",
            rows,
        )

    def _insert_file_imports(
        self,
        file_id: int,
        imports: list,
        lang: str,
        src_rel: str,
    ) -> None:
        from .parser import FileImport
        if not imports:
            return
        seen: set[int] = set()
        src_path = Path(src_rel)
        for imp in imports:  # type: FileImport
            target_id = self._resolve_import(imp, lang, src_path)
            if target_id is None or target_id == file_id or target_id in seen:
                continue
            seen.add(target_id)
            self.conn.execute(
                "INSERT OR IGNORE INTO file_imports(src_file, dst_file) VALUES(?, ?)",
                (file_id, target_id),
            )

    def _resolve_import(self, imp, lang: str, src_path: Path) -> int | None:
        """Best-effort resolution from import target → file_id."""
        target = imp.target
        candidates: list[str] = []
        if lang == "python":
            candidates = self._python_import_candidates(target, src_path, imp.is_relative)
        elif lang in ("typescript", "tsx"):
            candidates = self._ts_import_candidates(target, src_path)
        elif lang == "go":
            candidates = self._go_import_candidates(target)
        elif lang == "rust":
            candidates = self._rust_import_candidates(target, src_path)

        for cand in candidates:
            row = self.conn.execute(
                "SELECT id FROM files WHERE path = ?", (cand,)
            ).fetchone()
            if row is not None:
                return row["id"]
        return None

    def _python_import_candidates(self, target: str, src: Path, is_relative: bool) -> list[str]:
        if is_relative:
            # leading dots count = how many parents to climb (dot count - 1)
            dots = len(target) - len(target.lstrip("."))
            mod = target[dots:]
            base = src.parent
            for _ in range(max(dots - 1, 0)):
                base = base.parent if base.parts else base
            parts = mod.split(".") if mod else []
        else:
            base = Path()
            parts = target.split(".")
        if not parts and not is_relative:
            return []
        rel_path = base.joinpath(*parts) if parts else base
        return [
            f"{rel_path.as_posix()}.py",
            f"{rel_path.as_posix()}/__init__.py",
        ]

    def _ts_import_candidates(self, target: str, src: Path) -> list[str]:
        if not target.startswith("."):
            return []  # bare imports: not a same-repo file
        base = (src.parent / target).resolve(strict=False)
        try:
            base = base.relative_to(self.root)
        except ValueError:
            return []
        b = base.as_posix()
        return [
            b,
            f"{b}.ts",
            f"{b}.tsx",
            f"{b}.js",
            f"{b}.jsx",
            f"{b}/index.ts",
            f"{b}/index.tsx",
            f"{b}/index.js",
            f"{b}/index.jsx",
        ]

    def _go_import_candidates(self, target: str) -> list[str]:
        # Best-effort: match suffix of import path with a directory in the repo.
        # If target ends in "/foo", look for files in any directory ending with /foo.
        # We can't easily resolve module paths without parsing go.mod, so skip cross-module.
        return []

    def _rust_import_candidates(self, target: str, src: Path) -> list[str]:
        # Best-effort: ignore for v1.
        return []

    def _resolve_cross_refs(self) -> None:
        """Second pass: resolve unresolved_refs into edges via name lookup."""
        rows = self.conn.execute(
            "SELECT u.id, u.src_symbol, u.target_name, u.kind, "
            "       s.file_id AS src_file "
            "FROM unresolved_refs u "
            "JOIN symbols s ON s.id = u.src_symbol"
        ).fetchall()
        if not rows:
            return

        edges: list[tuple[int, int, str]] = []
        resolved_ids: list[int] = []
        for row in rows:
            target = row["target_name"]
            src_file = row["src_file"]
            # Prefer same-file matches first.
            same = self.conn.execute(
                "SELECT id FROM symbols WHERE name = ? AND file_id = ? LIMIT 1",
                (target, src_file),
            ).fetchone()
            dst_id: int | None = None
            if same is not None and same["id"] != row["src_symbol"]:
                dst_id = same["id"]
            else:
                # Fall back to global match. If multiple, take all up to a small cap.
                others = self.conn.execute(
                    "SELECT id FROM symbols WHERE name = ? AND id != ? LIMIT 5",
                    (target, row["src_symbol"]),
                ).fetchall()
                for o in others:
                    edges.append((row["src_symbol"], o["id"], row["kind"]))
                if others:
                    resolved_ids.append(row["id"])
                continue
            if dst_id is not None:
                edges.append((row["src_symbol"], dst_id, row["kind"]))
                resolved_ids.append(row["id"])

        if edges:
            self.conn.executemany(
                "INSERT OR IGNORE INTO edges(src_symbol, dst_symbol, kind) VALUES(?, ?, ?)",
                edges,
            )
        if resolved_ids:
            placeholders = ",".join("?" * len(resolved_ids))
            self.conn.execute(
                f"DELETE FROM unresolved_refs WHERE id IN ({placeholders})",
                resolved_ids,
            )
        self.conn.commit()


def _hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
