"""Hybrid retrieval: vector + FTS5 with Reciprocal Rank Fusion."""

from __future__ import annotations

import logging
import re
import sqlite3
from dataclasses import dataclass
from typing import Literal

from . import db as dbm

log = logging.getLogger(__name__)

RRF_K = 60  # Standard constant for Reciprocal Rank Fusion.
DEFAULT_TOP_K = 8
INTERNAL_FETCH = 30  # Fetch this many from each index, then fuse and re-rank.

Mode = Literal["hybrid", "semantic", "lexical"]


@dataclass
class SearchHit:
    chunk_id: int
    file_path: str
    start_line: int
    end_line: int
    symbol_id: int | None
    symbol_name: str | None
    symbol_qname: str | None
    symbol_kind: str | None
    snippet: str
    score: float


def hybrid_search(
    conn: sqlite3.Connection,
    query: str,
    query_embedding: list[float] | None,
    *,
    k: int = DEFAULT_TOP_K,
    mode: Mode = "hybrid",
) -> list[SearchHit]:
    """Run a search and return up to `k` ranked hits."""
    semantic_ranks: dict[int, int] = {}
    lexical_ranks: dict[int, int] = {}

    if mode in ("hybrid", "semantic") and query_embedding is not None:
        for rank, chunk_id in enumerate(_vector_search(conn, query_embedding, INTERNAL_FETCH)):
            semantic_ranks[chunk_id] = rank
    if mode in ("hybrid", "lexical"):
        for rank, chunk_id in enumerate(_fts_search(conn, query, INTERNAL_FETCH)):
            lexical_ranks[chunk_id] = rank

    fused: dict[int, float] = {}
    for cid, rank in semantic_ranks.items():
        fused[cid] = fused.get(cid, 0.0) + 1.0 / (RRF_K + rank + 1)
    for cid, rank in lexical_ranks.items():
        fused[cid] = fused.get(cid, 0.0) + 1.0 / (RRF_K + rank + 1)

    if not fused:
        return []
    top = sorted(fused.items(), key=lambda x: x[1], reverse=True)[:k]
    chunk_ids = [cid for cid, _ in top]
    score_by_id = {cid: score for cid, score in top}
    return _hydrate_hits(conn, chunk_ids, score_by_id)


def _vector_search(
    conn: sqlite3.Connection, embedding: list[float], limit: int
) -> list[int]:
    cur = conn.execute(
        "SELECT chunk_id FROM chunks_vec "
        "WHERE embedding MATCH ? AND k = ? "
        "ORDER BY distance",
        (dbm.serialize_vector(embedding), limit),
    )
    return [row["chunk_id"] for row in cur]


_FTS_SAFE = re.compile(r"[^A-Za-z0-9_\s]")


def _fts_search(conn: sqlite3.Connection, query: str, limit: int) -> list[int]:
    sanitized = _FTS_SAFE.sub(" ", query).strip()
    if not sanitized:
        return []
    # Wrap each word as a phrase to keep FTS5 syntax happy with trigram tokenizer.
    fts_query = " ".join(f'"{w}"' for w in sanitized.split() if w)
    if not fts_query:
        return []
    try:
        cur = conn.execute(
            "SELECT rowid FROM chunks_fts WHERE chunks_fts MATCH ? "
            "ORDER BY rank LIMIT ?",
            (fts_query, limit),
        )
        return [row["rowid"] for row in cur]
    except sqlite3.OperationalError as exc:
        log.warning("FTS5 query failed (%s) for input %r", exc, query)
        return []


def _hydrate_hits(
    conn: sqlite3.Connection,
    chunk_ids: list[int],
    score_by_id: dict[int, float],
) -> list[SearchHit]:
    if not chunk_ids:
        return []
    placeholders = ",".join("?" * len(chunk_ids))
    rows = conn.execute(
        f"""
        SELECT
            c.id, c.start_line, c.end_line, c.content,
            f.path AS file_path,
            s.id AS symbol_id, s.name AS symbol_name,
            s.qualified_name AS symbol_qname, s.kind AS symbol_kind
        FROM chunks c
        JOIN files f ON f.id = c.file_id
        LEFT JOIN symbols s ON s.id = c.symbol_id
        WHERE c.id IN ({placeholders})
        """,
        chunk_ids,
    ).fetchall()
    by_id = {row["id"]: row for row in rows}
    hits: list[SearchHit] = []
    for cid in chunk_ids:
        row = by_id.get(cid)
        if row is None:
            continue
        hits.append(
            SearchHit(
                chunk_id=row["id"],
                file_path=row["file_path"],
                start_line=row["start_line"],
                end_line=row["end_line"],
                symbol_id=row["symbol_id"],
                symbol_name=row["symbol_name"],
                symbol_qname=row["symbol_qname"],
                symbol_kind=row["symbol_kind"],
                snippet=row["content"],
                score=score_by_id[cid],
            )
        )
    return hits


# -- Symbol-oriented lookups ----------------------------------------------------


@dataclass
class SymbolRow:
    id: int
    name: str
    qualified_name: str | None
    kind: str
    file_path: str
    start_line: int
    end_line: int
    signature: str | None


def lookup_symbol(
    conn: sqlite3.Connection,
    name: str,
    *,
    kind: str | None = None,
    fuzzy: bool = False,
    limit: int = 25,
) -> list[SymbolRow]:
    if fuzzy:
        sql = (
            "SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line, "
            "       s.signature, f.path AS file_path "
            "FROM symbols s JOIN files f ON f.id = s.file_id "
            "WHERE (s.name LIKE ? OR s.qualified_name LIKE ?) "
        )
        params: list = [f"%{name}%", f"%{name}%"]
    else:
        sql = (
            "SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line, "
            "       s.signature, f.path AS file_path "
            "FROM symbols s JOIN files f ON f.id = s.file_id "
            "WHERE (s.name = ? OR s.qualified_name = ?) "
        )
        params = [name, name]
    if kind is not None:
        sql += "AND s.kind = ? "
        params.append(kind)
    sql += "ORDER BY length(s.qualified_name), s.qualified_name LIMIT ?"
    params.append(limit)

    rows = conn.execute(sql, params).fetchall()
    return [
        SymbolRow(
            id=r["id"],
            name=r["name"],
            qualified_name=r["qualified_name"],
            kind=r["kind"],
            file_path=r["file_path"],
            start_line=r["start_line"],
            end_line=r["end_line"],
            signature=r["signature"],
        )
        for r in rows
    ]


def file_outline(conn: sqlite3.Connection, path: str) -> list[SymbolRow]:
    rows = conn.execute(
        """
        SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line,
               s.signature, f.path AS file_path
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE f.path = ?
        ORDER BY s.start_line
        """,
        (path,),
    ).fetchall()
    return [
        SymbolRow(
            id=r["id"],
            name=r["name"],
            qualified_name=r["qualified_name"],
            kind=r["kind"],
            file_path=r["file_path"],
            start_line=r["start_line"],
            end_line=r["end_line"],
            signature=r["signature"],
        )
        for r in rows
    ]


def get_symbol_body(conn: sqlite3.Connection, symbol_id: int) -> dict | None:
    row = conn.execute(
        """
        SELECT s.start_line, s.end_line, s.signature, s.qualified_name, s.kind,
               f.path AS file_path, f.id AS file_id
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE s.id = ?
        """,
        (symbol_id,),
    ).fetchone()
    if row is None:
        return None
    # Largest single chunk that covers this symbol (the per-symbol chunk).
    chunk = conn.execute(
        """
        SELECT content, start_line, end_line FROM chunks
        WHERE symbol_id = ? AND file_id = ?
        ORDER BY (end_line - start_line) DESC, start_line
        LIMIT 1
        """,
        (symbol_id, row["file_id"]),
    ).fetchone()
    if chunk is None:
        return {
            "path": row["file_path"],
            "lines": f"{row['start_line']}-{row['end_line']}",
            "qualified_name": row["qualified_name"],
            "kind": row["kind"],
            "signature": row["signature"],
            "content": "",
        }
    return {
        "path": row["file_path"],
        "lines": f"{chunk['start_line']}-{chunk['end_line']}",
        "qualified_name": row["qualified_name"],
        "kind": row["kind"],
        "signature": row["signature"],
        "content": chunk["content"],
    }


# -- Graph queries --------------------------------------------------------------


def callers(
    conn: sqlite3.Connection, symbol_id: int, *, depth: int = 1, limit: int = 50
) -> list[SymbolRow]:
    return _graph_query(conn, symbol_id, depth, limit, direction="callers")


def callees(
    conn: sqlite3.Connection, symbol_id: int, *, depth: int = 1, limit: int = 50
) -> list[SymbolRow]:
    return _graph_query(conn, symbol_id, depth, limit, direction="callees")


def _graph_query(
    conn: sqlite3.Connection,
    seed: int,
    depth: int,
    limit: int,
    *,
    direction: str,
) -> list[SymbolRow]:
    visited: set[int] = {seed}
    frontier: set[int] = {seed}
    collected: list[int] = []
    for _ in range(max(1, depth)):
        if not frontier:
            break
        placeholders = ",".join("?" * len(frontier))
        if direction == "callers":
            rows = conn.execute(
                f"SELECT src_symbol AS s FROM edges "
                f"WHERE dst_symbol IN ({placeholders}) AND kind = 'calls'",
                tuple(frontier),
            ).fetchall()
        else:
            rows = conn.execute(
                f"SELECT dst_symbol AS s FROM edges "
                f"WHERE src_symbol IN ({placeholders}) AND kind = 'calls'",
                tuple(frontier),
            ).fetchall()
        next_frontier: set[int] = set()
        for r in rows:
            sid = r["s"]
            if sid in visited:
                continue
            visited.add(sid)
            collected.append(sid)
            if len(collected) >= limit:
                break
            next_frontier.add(sid)
        frontier = next_frontier
        if len(collected) >= limit:
            break

    if not collected:
        return []
    placeholders = ",".join("?" * len(collected))
    rows = conn.execute(
        f"""
        SELECT s.id, s.name, s.qualified_name, s.kind, s.start_line, s.end_line,
               s.signature, f.path AS file_path
        FROM symbols s JOIN files f ON f.id = s.file_id
        WHERE s.id IN ({placeholders})
        """,
        collected,
    ).fetchall()
    by_id = {r["id"]: r for r in rows}
    out: list[SymbolRow] = []
    for sid in collected:
        r = by_id.get(sid)
        if r is None:
            continue
        out.append(
            SymbolRow(
                id=r["id"],
                name=r["name"],
                qualified_name=r["qualified_name"],
                kind=r["kind"],
                file_path=r["file_path"],
                start_line=r["start_line"],
                end_line=r["end_line"],
                signature=r["signature"],
            )
        )
    return out


def dependencies(conn: sqlite3.Connection, path: str, *, limit: int = 200) -> list[str]:
    rows = conn.execute(
        """
        SELECT f2.path AS path
        FROM files f
        JOIN file_imports fi ON fi.src_file = f.id
        JOIN files f2 ON f2.id = fi.dst_file
        WHERE f.path = ?
        ORDER BY f2.path
        LIMIT ?
        """,
        (path, limit),
    ).fetchall()
    return [r["path"] for r in rows]


def dependents(conn: sqlite3.Connection, path: str, *, limit: int = 200) -> list[str]:
    rows = conn.execute(
        """
        SELECT f2.path AS path
        FROM files f
        JOIN file_imports fi ON fi.dst_file = f.id
        JOIN files f2 ON f2.id = fi.src_file
        WHERE f.path = ?
        ORDER BY f2.path
        LIMIT ?
        """,
        (path, limit),
    ).fetchall()
    return [r["path"] for r in rows]
