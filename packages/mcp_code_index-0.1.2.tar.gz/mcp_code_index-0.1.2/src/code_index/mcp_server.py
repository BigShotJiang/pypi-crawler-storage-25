"""MCP server exposing 8 retrieval tools + 2 admin tools (init, setup_check) to Claude Code."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from . import db as dbm
from . import retriever
from .embedder import make_embedder

log = logging.getLogger(__name__)

# Hard caps on response size to stay within Claude Code's expected envelope.
SEARCH_SNIPPET_MAX_LINES = 12
SEARCH_SNIPPET_MAX_CHARS = 600
DEFAULT_K = 8

server = Server("code-index")
_state: dict[str, Any] = {}


def _conn() -> sqlite3.Connection:
    """Lazy, single-connection accessor."""
    conn = _state.get("conn")
    if conn is None:
        conn = dbm.connect(read_only=False)  # need writes for staleness reindex
        _state["conn"] = conn
    return conn


def _embedder():
    emb = _state.get("embedder")
    if emb is None:
        emb = make_embedder()
        _state["embedder"] = emb
    return emb


def _truncate_snippet(text: str) -> str:
    if not text:
        return ""
    lines = text.splitlines()
    if len(lines) > SEARCH_SNIPPET_MAX_LINES:
        lines = lines[:SEARCH_SNIPPET_MAX_LINES] + [f"... (+{len(lines) - SEARCH_SNIPPET_MAX_LINES} more lines, use get_symbol_body for full content)"]
    snippet = "\n".join(lines)
    if len(snippet) > SEARCH_SNIPPET_MAX_CHARS:
        snippet = snippet[:SEARCH_SNIPPET_MAX_CHARS].rstrip() + "\n... (truncated, use get_symbol_body for full content)"
    return snippet


def _maybe_reindex_stale(conn: sqlite3.Connection, file_path: str) -> bool:
    """If the on-disk mtime is newer than what's stored, reindex synchronously."""
    row = conn.execute(
        "SELECT id, mtime FROM files WHERE path = ?", (file_path,)
    ).fetchone()
    if row is None:
        return False
    abs_path = Path(os.environ.get("CODE_INDEX_ROOT", ".")) / file_path
    try:
        disk_mtime = int(abs_path.stat().st_mtime)
    except OSError:
        return False
    if disk_mtime <= (row["mtime"] or 0):
        return False
    log.info("file %s is stale (disk %d > db %d); reindexing", file_path, disk_mtime, row["mtime"])
    try:
        from .indexer import Indexer
        # Use a separate Indexer that shares no connection state.
        idx = Indexer(root=Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve(), embedder=_embedder())
        idx.reindex_file(abs_path)
        idx.close()
    except Exception as exc:  # noqa: BLE001
        log.warning("staleness reindex failed for %s: %s", file_path, exc)
        return False
    return True


# ---------------------------------------------------------------------------
# Tool definitions and descriptions
# ---------------------------------------------------------------------------

TOOL_DESCRIPTIONS = {
    "init": (
        "Build or refresh the project's code index. Call once on first use of the MCP "
        "in a repo, and again after a branch checkout, mass `mv`, or refactor that "
        "may have moved files (otherwise other tools may return stale paths). "
        "force=false (default) is incremental — only files whose content hash changed "
        "are re-embedded, so it's cheap on a clean tree. force=true deletes "
        ".claude/index.db and rebuilds from scratch (use after changing the embedding "
        "model or if the index is suspected corrupt). Returns build statistics."
    ),
    "setup_check": (
        "Diagnose the project's setup. Reports (1) whether the auto-reindex hook is "
        "wired in .claude/settings.json — without it the index drifts when files "
        "change outside the agent — and (2) whether the embedder is configured "
        "(VOYAGE_API_KEY when CODE_INDEX_EMBEDDER=voyage, OLLAMA_URL when ollama) — "
        "without it init/code_search fail with auth errors. Returns "
        "{status, hook_installed, embedder_backend, embedder_ready, instructions, "
        "recommended_hook_block}. Call on first interaction with a new project."
    ),
    "code_search": (
        "Hybrid (vector + FTS) code search. Use for CONCEPTUAL queries — "
        "'authentication flow', 'rate limiting', 'where do we parse markdown'. "
        "For exact identifiers (camelCase, snake_case, ALL_CAPS), prefer "
        "`symbol_lookup` first. Returns line-bounded snippets, NOT full files. "
        "Call `get_symbol_body` if you need the full chunk for one hit."
    ),
    "symbol_lookup": (
        "Exact-name lookup of functions, classes, methods, types. "
        "ALWAYS prefer this over `code_search` when you have an identifier. "
        "Set fuzzy=true for substring match. Cheaper and more precise than search."
    ),
    "file_outline": (
        "Lists the symbols (with signatures) in a file, in source order. "
        "Use INSTEAD of Read when you only need to know what a file contains. "
        "Returns signatures only — no bodies."
    ),
    "get_symbol_body": (
        "Returns the chunk for a symbol_id from `symbol_lookup` or `code_search`. "
        "Cheaper than Read because it returns one bounded chunk, not the whole file."
    ),
    "callers": (
        "Symbols that CALL the given symbol. depth=2 expands transitive callers. "
        "Use to assess blast-radius of a change."
    ),
    "callees": (
        "Symbols that the given symbol CALLS. Use to map out what a function depends on."
    ),
    "dependents": (
        "Files that import the given file. Use to find places that consume this module."
    ),
    "dependencies": (
        "Files that the given file imports. Use to map upstream dependencies of a module."
    ),
}


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="init",
            description=TOOL_DESCRIPTIONS["init"],
            inputSchema={
                "type": "object",
                "properties": {
                    "force": {
                        "type": "boolean",
                        "default": False,
                        "description": (
                            "If true, delete the existing index and rebuild from "
                            "scratch. If false, incrementally reindex changed files."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="setup_check",
            description=TOOL_DESCRIPTIONS["setup_check"],
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="code_search",
            description=TOOL_DESCRIPTIONS["code_search"],
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Natural language or substring query.",
                    },
                    "k": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 30,
                        "default": DEFAULT_K,
                    },
                    "mode": {
                        "type": "string",
                        "enum": ["hybrid", "semantic", "lexical"],
                        "default": "hybrid",
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="symbol_lookup",
            description=TOOL_DESCRIPTIONS["symbol_lookup"],
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "kind": {
                        "type": "string",
                        "description": "Optional: function | method | class | struct | interface | type | const | enum | trait | impl",
                    },
                    "fuzzy": {"type": "boolean", "default": False},
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="file_outline",
            description=TOOL_DESCRIPTIONS["file_outline"],
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Repo-relative path.",
                    },
                },
                "required": ["path"],
            },
        ),
        Tool(
            name="get_symbol_body",
            description=TOOL_DESCRIPTIONS["get_symbol_body"],
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol_id": {"type": "integer"},
                },
                "required": ["symbol_id"],
            },
        ),
        Tool(
            name="callers",
            description=TOOL_DESCRIPTIONS["callers"],
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol_id": {"type": "integer"},
                    "depth": {"type": "integer", "minimum": 1, "maximum": 5, "default": 1},
                },
                "required": ["symbol_id"],
            },
        ),
        Tool(
            name="callees",
            description=TOOL_DESCRIPTIONS["callees"],
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol_id": {"type": "integer"},
                    "depth": {"type": "integer", "minimum": 1, "maximum": 5, "default": 1},
                },
                "required": ["symbol_id"],
            },
        ),
        Tool(
            name="dependents",
            description=TOOL_DESCRIPTIONS["dependents"],
            inputSchema={
                "type": "object",
                "properties": {"path": {"type": "string"}},
                "required": ["path"],
            },
        ),
        Tool(
            name="dependencies",
            description=TOOL_DESCRIPTIONS["dependencies"],
            inputSchema={
                "type": "object",
                "properties": {"path": {"type": "string"}},
                "required": ["path"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    try:
        result = await asyncio.to_thread(_dispatch, name, arguments or {})
    except Exception as exc:  # noqa: BLE001
        log.exception("tool %s failed", name)
        result = {"error": str(exc)}
    payload = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    return [TextContent(type="text", text=payload)]


def _dispatch(name: str, args: dict[str, Any]) -> Any:
    if name == "init":
        return _do_init(force=bool(args.get("force")))
    if name == "setup_check":
        return _do_setup_check()
    if name == "code_search":
        return _do_search(
            query=args["query"],
            k=int(args.get("k") or DEFAULT_K),
            mode=args.get("mode") or "hybrid",
        )
    if name == "symbol_lookup":
        return _do_symbol_lookup(
            name=args["name"],
            kind=args.get("kind"),
            fuzzy=bool(args.get("fuzzy")),
        )
    if name == "file_outline":
        return _do_file_outline(path=args["path"])
    if name == "get_symbol_body":
        return _do_get_symbol_body(symbol_id=int(args["symbol_id"]))
    if name == "callers":
        return _do_graph(symbol_id=int(args["symbol_id"]),
                         depth=int(args.get("depth") or 1),
                         direction="callers")
    if name == "callees":
        return _do_graph(symbol_id=int(args["symbol_id"]),
                         depth=int(args.get("depth") or 1),
                         direction="callees")
    if name == "dependents":
        return {"dependents": retriever.dependents(_conn(), args["path"])}
    if name == "dependencies":
        return {"dependencies": retriever.dependencies(_conn(), args["path"])}
    return {"error": f"unknown tool: {name}"}


def _do_setup_check() -> dict:
    """Diagnose hook + embedder configuration. Returns status, issues, and fixes."""
    root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()
    settings_path = root / ".claude" / "settings.json"

    out: dict[str, Any] = {
        "repo_root": str(root),
        "settings_path": str(settings_path),
        "settings_exists": settings_path.exists(),
        "hook_installed": False,
    }
    issues: list[str] = []

    # ---- Hook detection ----
    settings: dict[str, Any] = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(f"Could not read {settings_path}: {exc}")

    for entry in (settings.get("hooks", {}).get("PostToolUse") or []):
        matcher = entry.get("matcher") or ""
        if not any(t in matcher for t in ("Edit", "Write", "MultiEdit")):
            continue
        for h in (entry.get("hooks") or []):
            cmd = h.get("command") or ""
            if "code-index" in cmd or "reindex" in cmd:
                out["hook_installed"] = True
                out["matched_matcher"] = matcher
                out["matched_command"] = cmd
                break
        if out["hook_installed"]:
            break

    if not out["hook_installed"]:
        issues.append(
            "Auto-reindex hook missing. Without it the index drifts when files "
            "change outside the agent until `init` is called again. Add "
            "recommended_hook_block (in this response) to .claude/settings.json "
            "under hooks.PostToolUse, or see the README install section."
        )
        out["recommended_hook_block"] = _RECOMMENDED_HOOK_BLOCK

    # ---- Embedder check ----
    backend = (os.environ.get("CODE_INDEX_EMBEDDER") or "voyage").lower()
    out["embedder_backend"] = backend
    if backend == "voyage":
        out["voyage_api_key_present"] = bool(os.environ.get("VOYAGE_API_KEY"))
        out["embedder_ready"] = out["voyage_api_key_present"]
        if not out["voyage_api_key_present"]:
            issues.append(
                "VOYAGE_API_KEY is not set in the MCP server's environment. "
                "init / code_search will fail with an auth error. Add the key to "
                "your MCP registration's env block (e.g., in ~/.claude.json set "
                "mcpServers['code-index'].env.VOYAGE_API_KEY), or set "
                "CODE_INDEX_EMBEDDER=ollama for local embeddings."
            )
    elif backend == "ollama":
        out["ollama_url"] = os.environ.get("OLLAMA_URL") or "http://localhost:11434"
        out["embedder_ready"] = True
    else:
        out["embedder_ready"] = False
        issues.append(
            f"Unknown CODE_INDEX_EMBEDDER value: '{backend}'. Use 'voyage' or 'ollama'."
        )

    out["status"] = "ok" if not issues else "needs_setup"
    if issues:
        out["instructions"] = issues
    return out


_RECOMMENDED_HOOK_BLOCK = {
    "matcher": "Edit|Write|MultiEdit",
    "hooks": [
        {
            "type": "command",
            "command": (
                "python -c 'import json,os,subprocess,sys; "
                "p=json.load(sys.stdin) if not sys.stdin.isatty() else {}; "
                "fp=(p.get(\"tool_input\") or {}).get(\"file_path\"); "
                "cwd=p.get(\"cwd\") or os.getcwd(); "
                "fp and subprocess.Popen([\"code-index\",\"--root\",cwd,\"reindex\",\"--file\",fp],"
                "stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,"
                "stdin=subprocess.DEVNULL,cwd=cwd,start_new_session=True)'"
            ),
        }
    ],
}


def _do_init(*, force: bool) -> dict:
    """Build or refresh the project index. Mirrors `code-index init`."""
    from .indexer import Indexer

    root = Path(os.environ.get("CODE_INDEX_ROOT", ".")).resolve()

    if force:
        # Drop the shared connection/embedder before deleting the DB file,
        # otherwise the cached conn would point at a deleted inode.
        conn = _state.pop("conn", None)
        if conn is not None:
            try:
                conn.close()
            except Exception:  # noqa: BLE001 — best effort
                pass
        _state.pop("embedder", None)
        db_file = dbm.db_path()
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(db_file) + suffix)
            if p.exists():
                p.unlink()

    embedder = _embedder()  # cached, or fresh after force-clear
    indexer = Indexer(root=root, embedder=embedder)
    try:
        stats = indexer.reindex_all()
    finally:
        indexer.close()

    # Force a clean reopen of the shared conn so subsequent tools see the rebuilt DB
    # on the right inode (especially after force=true).
    conn = _state.pop("conn", None)
    if conn is not None:
        try:
            conn.close()
        except Exception:  # noqa: BLE001
            pass

    return {
        "force": force,
        "root": str(root),
        "db_path": str(dbm.db_path()),
        "embed_model": embedder.model_name,
        "embed_dim": embedder.dim,
        "files_seen": stats.files_seen,
        "files_indexed": stats.files_indexed,
        "files_skipped": stats.files_skipped,
        "chunks_written": stats.chunks_written,
        "elapsed_ms": stats.elapsed_ms,
    }


def _do_search(*, query: str, k: int, mode: str) -> dict:
    conn = _conn()
    embedder = _embedder() if mode != "lexical" else None
    embedding = embedder.embed_query(query) if embedder is not None else None
    hits = retriever.hybrid_search(conn, query, embedding, k=k, mode=mode)  # type: ignore[arg-type]
    return {
        "query": query,
        "mode": mode,
        "results": [
            {
                "symbol_id": h.symbol_id,
                "symbol": h.symbol_qname or h.symbol_name,
                "kind": h.symbol_kind,
                "path": h.file_path,
                "lines": f"{h.start_line}-{h.end_line}",
                "snippet": _truncate_snippet(h.snippet),
                "score": round(h.score, 4),
            }
            for h in hits
        ],
    }


def _do_symbol_lookup(*, name: str, kind: str | None, fuzzy: bool) -> dict:
    rows = retriever.lookup_symbol(_conn(), name, kind=kind, fuzzy=fuzzy)
    return {
        "matches": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "path": r.file_path,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ]
    }


def _do_file_outline(*, path: str) -> dict:
    conn = _conn()
    _maybe_reindex_stale(conn, path)
    rows = retriever.file_outline(conn, path)
    if not rows:
        return {"path": path, "outline": [], "note": "file not in index"}
    return {
        "path": path,
        "outline": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ],
    }


def _do_get_symbol_body(*, symbol_id: int) -> dict:
    conn = _conn()
    body = retriever.get_symbol_body(conn, symbol_id)
    if body is None:
        return {"error": f"symbol_id {symbol_id} not found"}
    _maybe_reindex_stale(conn, body["path"])
    return body


def _do_graph(*, symbol_id: int, depth: int, direction: str) -> dict:
    conn = _conn()
    rows = (
        retriever.callers(conn, symbol_id, depth=depth)
        if direction == "callers"
        else retriever.callees(conn, symbol_id, depth=depth)
    )
    return {
        "symbol_id": symbol_id,
        "direction": direction,
        "depth": depth,
        "results": [
            {
                "symbol_id": r.id,
                "name": r.name,
                "qualified_name": r.qualified_name,
                "kind": r.kind,
                "path": r.file_path,
                "lines": f"{r.start_line}-{r.end_line}",
                "signature": r.signature,
            }
            for r in rows
        ],
    }


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


async def _serve() -> None:
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("CODE_INDEX_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    asyncio.run(_serve())


if __name__ == "__main__":
    main()
