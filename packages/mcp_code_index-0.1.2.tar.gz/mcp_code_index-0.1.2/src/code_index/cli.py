"""Command-line entry point: init, reindex, watch, stats."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import click

from . import db as dbm
from .embedder import make_embedder
from .indexer import Indexer

log = logging.getLogger(__name__)


@click.group()
@click.option("--root", type=click.Path(exists=True, file_okay=False, path_type=Path),
              default=Path.cwd, show_default="cwd",
              help="Repo root to operate on.")
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging.")
@click.pass_context
def cli(ctx: click.Context, root: Path, verbose: bool) -> None:
    """SQLite-backed code index for Claude Code."""
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    ctx.ensure_object(dict)
    ctx.obj["root"] = root.resolve()


@cli.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Build the index from scratch (or refresh changed files)."""
    root = ctx.obj["root"]
    embedder = make_embedder()
    click.echo(f"Indexing {root} (embedder={embedder.model_name}, dim={embedder.dim})")
    indexer = Indexer(root=root, embedder=embedder)
    try:
        stats = indexer.reindex_all()
    finally:
        indexer.close()
    click.echo(
        f"  files seen:    {stats.files_seen}\n"
        f"  files indexed: {stats.files_indexed}\n"
        f"  files skipped: {stats.files_skipped}\n"
        f"  chunks added:  {stats.chunks_written}\n"
        f"  elapsed:       {stats.elapsed_ms} ms"
    )


@cli.command()
@click.option("--file", "file_path", type=click.Path(path_type=Path),
              help="Reindex one file (used by the PostToolUse hook).")
@click.option("--all", "all_files", is_flag=True, help="Reindex everything that changed.")
@click.pass_context
def reindex(ctx: click.Context, file_path: Path | None, all_files: bool) -> None:
    """Reindex one file or the whole repo."""
    root = ctx.obj["root"]
    embedder = make_embedder()
    indexer = Indexer(root=root, embedder=embedder)
    try:
        if file_path:
            target = file_path.resolve()
            result = indexer.reindex_file(target)
            if result is None:
                click.echo(f"skip {target} (not indexable)", err=True)
                return
            verb = "indexed" if result.indexed else "unchanged"
            click.echo(
                f"{verb}: {target} ({result.chunk_count} chunks, "
                f"{result.symbol_count} symbols, {result.elapsed_ms} ms)"
            )
            return
        if all_files:
            stats = indexer.reindex_all()
            click.echo(
                f"reindexed: {stats.files_indexed} indexed, {stats.files_skipped} unchanged, "
                f"{stats.chunks_written} chunks, {stats.elapsed_ms} ms"
            )
            return
        click.echo("Specify --file PATH or --all", err=True)
        sys.exit(2)
    finally:
        indexer.close()


@cli.command()
@click.pass_context
def watch(ctx: click.Context) -> None:
    """Run a foreground file watcher. Reindexes files on edit."""
    from .watcher import run_watcher
    run_watcher(ctx.obj["root"])


@cli.command()
@click.pass_context
def stats(ctx: click.Context) -> None:
    """Print index summary."""
    conn = dbm.connect(read_only=True)
    try:
        meta = {
            row["key"]: row["value"]
            for row in conn.execute("SELECT key, value FROM meta")
        }
        f = conn.execute("SELECT COUNT(*) AS c FROM files").fetchone()["c"]
        s = conn.execute("SELECT COUNT(*) AS c FROM symbols").fetchone()["c"]
        c = conn.execute("SELECT COUNT(*) AS c FROM chunks").fetchone()["c"]
        e = conn.execute("SELECT COUNT(*) AS c FROM edges").fetchone()["c"]
        i = conn.execute("SELECT COUNT(*) AS c FROM file_imports").fetchone()["c"]
        last = conn.execute(
            "SELECT path, indexed_at FROM files ORDER BY indexed_at DESC LIMIT 1"
        ).fetchone()
    finally:
        conn.close()

    click.echo(f"db:           {dbm.db_path()}")
    click.echo(f"embed_model:  {meta.get('embed_model', '?')}")
    click.echo(f"embed_dim:    {meta.get('embed_dim', '?')}")
    click.echo(f"files:        {f}")
    click.echo(f"symbols:      {s}")
    click.echo(f"chunks:       {c}")
    click.echo(f"edges:        {e}")
    click.echo(f"file_imports: {i}")
    if last:
        click.echo(f"last update:  {last['path']} (epoch {last['indexed_at']})")


@cli.command()
def serve() -> None:
    """Start the MCP server on stdio (same as `code-index-mcp`)."""
    from .mcp_server import main as mcp_main
    mcp_main()


def main() -> None:
    cli(obj={})


if __name__ == "__main__":
    main()
