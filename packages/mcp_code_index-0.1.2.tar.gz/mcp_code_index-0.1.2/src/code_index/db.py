"""SQLite schema, connection management, sqlite-vec loading."""

from __future__ import annotations

import os
import sqlite3
import struct
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

import sqlite_vec

DEFAULT_DB_PATH = ".claude/index.db"


def db_path() -> Path:
    """Resolve the configured database path."""
    raw = os.environ.get("CODE_INDEX_DB", DEFAULT_DB_PATH)
    return Path(raw).expanduser().resolve()


def serialize_vector(vec: list[float]) -> bytes:
    """Pack a list of floats as little-endian float32 bytes for sqlite-vec."""
    return struct.pack(f"{len(vec)}f", *vec)


def connect(path: Path | None = None, *, read_only: bool = False) -> sqlite3.Connection:
    """Open a connection with sqlite-vec loaded and pragmas applied."""
    target = path or db_path()
    target.parent.mkdir(parents=True, exist_ok=True)

    if read_only and target.exists():
        uri = f"file:{target}?mode=ro"
        conn = sqlite3.connect(uri, uri=True, check_same_thread=False)
    else:
        conn = sqlite3.connect(str(target), check_same_thread=False)

    conn.row_factory = sqlite3.Row
    if not hasattr(conn, "enable_load_extension"):
        raise RuntimeError(
            "Your Python's sqlite3 module was built without loadable extension support. "
            "Use a Python built with --enable-loadable-sqlite-extensions "
            "(e.g. python.org installer, pyenv with PYTHON_CONFIGURE_OPTS, or Python 3.13)."
        )
    conn.enable_load_extension(True)
    sqlite_vec.load(conn)
    conn.enable_load_extension(False)

    if not read_only:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA temp_store = MEMORY")
        conn.execute("PRAGMA mmap_size = 268435456")  # 256MB
    return conn


def init_schema(conn: sqlite3.Connection, embed_dim: int) -> None:
    """Create all tables, indexes, and virtual tables. Idempotent."""
    cur = conn.cursor()
    cur.executescript(SCHEMA_SQL)

    # Vector virtual table dimension is baked in at creation time.
    existing = cur.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='chunks_vec'"
    ).fetchone()
    if existing is None:
        cur.execute(
            f"CREATE VIRTUAL TABLE chunks_vec USING vec0("
            f"chunk_id INTEGER PRIMARY KEY, embedding FLOAT[{embed_dim}])"
        )

    # Persist the embedding dim so callers can detect mismatches.
    cur.execute(
        "INSERT INTO meta(key, value) VALUES('embed_dim', ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (str(embed_dim),),
    )
    conn.commit()


def get_meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO meta(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Single-statement transaction wrapper. Commits on success, rolls back on error."""
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY,
  path TEXT UNIQUE NOT NULL,
  hash TEXT NOT NULL,
  lang TEXT,
  mtime INTEGER,
  indexed_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_files_path ON files(path);

CREATE TABLE IF NOT EXISTS symbols (
  id INTEGER PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  qualified_name TEXT,
  kind TEXT NOT NULL,
  parent_id INTEGER REFERENCES symbols(id) ON DELETE CASCADE,
  start_line INTEGER NOT NULL,
  end_line INTEGER NOT NULL,
  signature TEXT,
  docstring TEXT
);

CREATE INDEX IF NOT EXISTS idx_symbols_name ON symbols(name);
CREATE INDEX IF NOT EXISTS idx_symbols_qname ON symbols(qualified_name);
CREATE INDEX IF NOT EXISTS idx_symbols_file ON symbols(file_id);
CREATE INDEX IF NOT EXISTS idx_symbols_kind ON symbols(kind);

CREATE TABLE IF NOT EXISTS unresolved_refs (
  id INTEGER PRIMARY KEY,
  src_symbol INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  target_name TEXT NOT NULL,
  kind TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_unresolved_target ON unresolved_refs(target_name);

CREATE TABLE IF NOT EXISTS edges (
  src_symbol INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  dst_symbol INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  PRIMARY KEY (src_symbol, dst_symbol, kind)
);

CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_symbol, kind);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_symbol, kind);

CREATE TABLE IF NOT EXISTS file_imports (
  src_file INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  dst_file INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  PRIMARY KEY (src_file, dst_file)
);

CREATE INDEX IF NOT EXISTS idx_fimp_src ON file_imports(src_file);
CREATE INDEX IF NOT EXISTS idx_fimp_dst ON file_imports(dst_file);

CREATE TABLE IF NOT EXISTS chunks (
  id INTEGER PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  symbol_id INTEGER REFERENCES symbols(id) ON DELETE CASCADE,
  start_line INTEGER NOT NULL,
  end_line INTEGER NOT NULL,
  content TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file_id);
CREATE INDEX IF NOT EXISTS idx_chunks_symbol ON chunks(symbol_id);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
  content, content='chunks', content_rowid='id', tokenize='trigram'
);

CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
  INSERT INTO chunks_fts(rowid, content) VALUES (new.id, new.content);
END;

CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, content) VALUES('delete', old.id, old.content);
END;

CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, content) VALUES('delete', old.id, old.content);
  INSERT INTO chunks_fts(rowid, content) VALUES (new.id, new.content);
END;
"""
