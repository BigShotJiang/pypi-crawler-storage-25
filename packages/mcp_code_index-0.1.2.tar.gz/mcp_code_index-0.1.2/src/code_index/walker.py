"""Repo walking with .gitignore-aware filtering."""

from __future__ import annotations

from pathlib import Path
from typing import Iterator

from pathspec import PathSpec

from .parser import language_for_path

# Always-ignored directories regardless of .gitignore presence.
DEFAULT_IGNORES = [
    ".git/",
    ".hg/",
    ".svn/",
    "node_modules/",
    "__pycache__/",
    ".mypy_cache/",
    ".pytest_cache/",
    ".ruff_cache/",
    ".tox/",
    ".venv/",
    "venv/",
    "env/",
    "dist/",
    "build/",
    "target/",
    "out/",
    ".next/",
    ".nuxt/",
    ".turbo/",
    ".cache/",
    ".idea/",
    ".vscode/",
    "*.pyc",
    "*.pyo",
    "*.so",
    "*.dylib",
    ".DS_Store",
    ".claude/index.db*",
]


def load_ignore_spec(root: Path) -> PathSpec:
    """Load `.gitignore` plus our defaults. Subdirectory .gitignores are not honored."""
    patterns = list(DEFAULT_IGNORES)
    gi = root / ".gitignore"
    if gi.exists():
        try:
            patterns.extend(gi.read_text(encoding="utf-8").splitlines())
        except OSError:
            pass
    return PathSpec.from_lines("gitwildmatch", patterns)


def walk_indexable(
    root: Path, spec: PathSpec | None = None
) -> Iterator[tuple[Path, str]]:
    """Yield (path, language) for every indexable file under `root`."""
    spec = spec or load_ignore_spec(root)
    root = root.resolve()
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        try:
            rel = path.relative_to(root)
        except ValueError:
            continue
        rel_str = str(rel)
        if spec.match_file(rel_str):
            continue
        lang = language_for_path(path)
        if lang is None:
            continue
        yield path, lang
