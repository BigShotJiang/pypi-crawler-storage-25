#!/usr/bin/env bash
# Wire the code-index MCP server, PostToolUse hook, CLAUDE.md snippet, and SKILL.md
# into the project at $1 (default: $PWD). Idempotent.

set -euo pipefail

REPO_ROOT="${1:-$PWD}"
INDEX_PKG_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mkdir -p "$REPO_ROOT/.claude/skills/code-search"

SETTINGS="$REPO_ROOT/.claude/settings.json"
HOOK_SCRIPT="$INDEX_PKG_ROOT/scripts/reindex-hook.py"

if [[ ! -f "$SETTINGS" ]]; then
  echo '{}' > "$SETTINGS"
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "error: jq is required to merge .claude/settings.json safely. Install it with: brew install jq" >&2
  exit 1
fi

tmp="$(mktemp)"
jq --arg cmd "code-index-mcp" \
   --arg hook "$HOOK_SCRIPT" \
'
  .mcpServers = (.mcpServers // {}) |
  .mcpServers["code-index"] = {
    "type": "stdio",
    "command": $cmd,
    "args": []
  } |
  .hooks = (.hooks // {}) |
  .hooks.PostToolUse = (.hooks.PostToolUse // []) |
  (.hooks.PostToolUse |= map(select(.matcher != "Edit|Write|MultiEdit"))) |
  .hooks.PostToolUse += [{
    "matcher": "Edit|Write|MultiEdit",
    "hooks": [{
      "type": "command",
      "command": $hook
    }]
  }]
' "$SETTINGS" > "$tmp"
mv "$tmp" "$SETTINGS"
echo "wrote $SETTINGS"

CLAUDE_MD="$REPO_ROOT/CLAUDE.md"
SNIPPET="$INDEX_PKG_ROOT/docs/CLAUDE.md.snippet"
if [[ -f "$CLAUDE_MD" ]]; then
  if ! grep -q "## Code navigation" "$CLAUDE_MD"; then
    printf "\n" >> "$CLAUDE_MD"
    cat "$SNIPPET" >> "$CLAUDE_MD"
    echo "appended Code navigation section to $CLAUDE_MD"
  else
    echo "$CLAUDE_MD already has a Code navigation section; skipped"
  fi
else
  cat "$SNIPPET" > "$CLAUDE_MD"
  echo "created $CLAUDE_MD with Code navigation section"
fi

SKILL_DEST="$REPO_ROOT/.claude/skills/code-search/SKILL.md"
cp "$INDEX_PKG_ROOT/docs/SKILL.md" "$SKILL_DEST"
chmod +x "$HOOK_SCRIPT" 2>/dev/null || true
echo "installed skill at $SKILL_DEST"
echo
echo "Done. Next steps:"
echo "  1. export VOYAGE_API_KEY=..."
echo "  2. cd \"$REPO_ROOT\" && code-index init"
echo "  3. (optional) code-index watch &"
