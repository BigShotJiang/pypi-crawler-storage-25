#!/usr/bin/env python3
"""Claude Code PostToolUse hook: extract file_path from JSON stdin, reindex async.

Wired up in `.claude/settings.json` against the Edit/Write/MultiEdit matchers.
Always exits 0 so the agent flow is never blocked by a hook failure.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys


def main() -> int:
    try:
        payload = json.load(sys.stdin) if not sys.stdin.isatty() else {}
    except (json.JSONDecodeError, ValueError):
        return 0

    tool_input = payload.get("tool_input") or {}
    file_path = tool_input.get("file_path")
    if not file_path:
        return 0

    cwd = payload.get("cwd") or os.getcwd()
    try:
        subprocess.Popen(
            ["code-index", "--root", cwd, "reindex", "--file", file_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            cwd=cwd,
            start_new_session=True,
        )
    except (OSError, FileNotFoundError):
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
