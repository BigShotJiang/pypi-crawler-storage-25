"""Regression tests for the binary-library signature detector.

These tests use crafted byte fixtures so they run with no network and
no external binaries — every format we support is exercised against a
minimal hand-built sample.
"""
from __future__ import annotations

import io
import struct
import zipfile
from pathlib import Path

import pytest

from hiddenshadow.signatures import (
    _extract_cn_from_subject,
    _find_sidecar_signature,
    _inspect_macho,
    _inspect_pe,
    _inspect_zip,
    _read_pe_security_dir,
    inspect_file,
    records_to_findings,
    scan_repo_for_signatures,
    SignatureRecord,
)
from hiddenshadow.signatures_origin import (
    _infer_from_filename,
    _infer_from_path,
    _publisher_matches,
    annotate_origins_from_paths,
)


# ── PE fixture helpers ──────────────────────────────────────────────────

def _build_pe(security_size: int, security_payload: bytes = b"") -> bytes:
    """Build a minimal PE32+ image with a security data directory entry.

    Layout we lay down:
        [DOS header (64 B)] -> e_lfanew = 0x80
        [PE\0\0 + COFF (4+20) + OptHeader (PE32+, 240 B)]
            magic = 0x20b ; data dirs at opt+112, security at +112+32
        [security payload at file_offset SECURITY_OFFSET]
    """
    SECURITY_OFFSET = 0x400
    buf = bytearray(SECURITY_OFFSET + max(security_size, len(security_payload) + 8))
    # DOS
    buf[0:2] = b"MZ"
    struct.pack_into("<I", buf, 0x3C, 0x80)
    # PE sig
    buf[0x80:0x84] = b"PE\x00\x00"
    coff = 0x84
    # COFF: machine, nsec, time, ptrSym, nsym, sizeOpt, characteristics
    struct.pack_into("<HHIIIHH", buf, coff, 0x8664, 0, 0, 0, 0, 240, 0)
    opt = coff + 20
    # Optional header PE32+
    struct.pack_into("<H", buf, opt, 0x20B)
    # Skip filling all other fields; just the data dir offsets matter.
    dd_off = opt + 112
    sec_off = dd_off + 4 * 8  # 5th entry
    struct.pack_into("<II", buf, sec_off, SECURITY_OFFSET, security_size)
    # Lay down the WIN_CERTIFICATE if a payload was given.
    if security_size:
        cert_len = max(security_size, 8 + len(security_payload))
        struct.pack_into("<IHH", buf, SECURITY_OFFSET,
                         cert_len, 0x0200, 0x0002)  # rev 2.0, PKCS#7
        buf[SECURITY_OFFSET + 8:SECURITY_OFFSET + 8 + len(security_payload)] = security_payload
    return bytes(buf)


def test_pe_unsigned_has_zero_security_dir():
    blob = _build_pe(security_size=0)
    assert _read_pe_security_dir(blob) == (0x400, 0)


def test_pe_signed_security_dir_nonzero(tmp_path: Path):
    blob = _build_pe(security_size=64, security_payload=b"")
    p = tmp_path / "signed.dll"
    p.write_bytes(blob)
    signed, sig_type, subj = _inspect_pe(p)
    assert signed is True
    assert sig_type == "authenticode"


def test_pe_signed_with_extractable_cn(tmp_path: Path):
    # Synth a DER chunk containing OID 2.5.4.3 followed by a UTF8String CN.
    cn_value = b"DarkShadowSec LLC"
    der = (
        b"\x06\x03\x55\x04\x03"  # OID 2.5.4.3
        b"\x0C" + bytes([len(cn_value)]) + cn_value  # UTF8String
    )
    blob = _build_pe(security_size=8 + len(der) + 4, security_payload=der)
    p = tmp_path / "vendor.dll"
    p.write_bytes(blob)
    signed, sig_type, subj = _inspect_pe(p)
    assert signed is True
    assert subj == "DarkShadowSec LLC"


def test_pe_with_non_pe_magic_returns_unsigned(tmp_path: Path):
    p = tmp_path / "fake.dll"
    p.write_bytes(b"NOT-A-PE-FILE-AT-ALL" + b"\x00" * 200)
    signed, _, _ = _inspect_pe(p)
    assert signed is False


# ── ASN.1 walker ────────────────────────────────────────────────────────

def test_extract_cn_utf8():
    der = b"\x06\x03\x55\x04\x03\x0c\x07acme.io"
    assert _extract_cn_from_subject(der) == "acme.io"


def test_extract_cn_printable():
    der = b"\x06\x03\x55\x04\x03\x13\x06Vendor"
    assert _extract_cn_from_subject(der) == "Vendor"


def test_extract_cn_bmpstring():
    val = "MyCorp".encode("utf-16-be")
    der = b"\x06\x03\x55\x04\x03\x1e" + bytes([len(val)]) + val
    assert _extract_cn_from_subject(der) == "MyCorp"


def test_extract_cn_missing():
    assert _extract_cn_from_subject(b"\x00" * 50) == ""


# ── JAR / ZIP-based ─────────────────────────────────────────────────────

def _build_jar(tmp_path: Path, signed: bool) -> Path:
    p = tmp_path / "sample.jar"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr("META-INF/MANIFEST.MF", "Manifest-Version: 1.0\n")
        zf.writestr("hello/Main.class", b"\xca\xfe\xba\xbe")
        if signed:
            zf.writestr("META-INF/SIG.SF", "Signature-Version: 1.0\n")
            # A token DER blob that contains a CN we can extract.
            der = b"\x06\x03\x55\x04\x03\x0c\x06Acme!!"
            zf.writestr("META-INF/SIG.RSA", der + b"\x00" * 100)
    return p


def test_jar_signed(tmp_path: Path):
    p = _build_jar(tmp_path, signed=True)
    signed, sig_type, subj = _inspect_zip(p, "zip-jar")
    assert signed is True
    assert sig_type == "jar"
    assert subj == "Acme!!"


def test_jar_unsigned(tmp_path: Path):
    p = _build_jar(tmp_path, signed=False)
    signed, _, _ = _inspect_zip(p, "zip-jar")
    assert signed is False


def test_nupkg_signed(tmp_path: Path):
    p = tmp_path / "lib.1.0.0.nupkg"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr("lib.nuspec", "<package/>")
        zf.writestr(".signature.p7s",
                    b"\x06\x03\x55\x04\x03\x0c\x08NuVendor" + b"\x00" * 50)
    signed, sig_type, subj = _inspect_zip(p, "zip-nupkg")
    assert signed is True
    assert sig_type == "nupkg"
    assert subj == "NuVendor"


def test_nupkg_unsigned(tmp_path: Path):
    p = tmp_path / "lib.1.0.0.nupkg"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr("lib.nuspec", "<package/>")
    signed, _, _ = _inspect_zip(p, "zip-nupkg")
    assert signed is False


def test_whl_with_jws(tmp_path: Path):
    p = tmp_path / "pkg-1.0-py3-none-any.whl"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr("pkg/__init__.py", "")
        zf.writestr("pkg-1.0.dist-info/RECORD.jws", "{}")
    signed, sig_type, _ = _inspect_zip(p, "zip-whl")
    assert signed is True
    assert sig_type == "pep740"


def test_whl_unsigned(tmp_path: Path):
    p = tmp_path / "pkg-1.0-py3-none-any.whl"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr("pkg/__init__.py", "")
    signed, _, _ = _inspect_zip(p, "zip-whl")
    assert signed is False


# ── Mach-O ──────────────────────────────────────────────────────────────

def _build_macho64(with_codesign: bool) -> bytes:
    """Single-arch little-endian Mach-O 64."""
    # mach_header_64: magic, cputype, cpusubtype, filetype, ncmds,
    # sizeofcmds, flags, reserved
    ncmds = 1 if with_codesign else 0
    if with_codesign:
        # LC_CODE_SIGNATURE record: cmd, cmdsize, dataoff, datasize
        cmd = struct.pack("<IIII", 0x1D, 16, 0, 0)
    else:
        cmd = b""
    header = struct.pack("<IIIIIIII",
                         0xFEEDFACF, 0x01000007, 3, 6,
                         ncmds, len(cmd), 0, 0)
    return header + cmd


def test_macho_codesign_detected(tmp_path: Path):
    p = tmp_path / "lib.dylib"
    p.write_bytes(_build_macho64(with_codesign=True) + b"\x00" * 64)
    signed, sig_type, _ = _inspect_macho(p)
    assert signed is True
    assert sig_type == "macho-codesign"


def test_macho_unsigned(tmp_path: Path):
    p = tmp_path / "lib.dylib"
    p.write_bytes(_build_macho64(with_codesign=False) + b"\x00" * 64)
    signed, _, _ = _inspect_macho(p)
    assert signed is False


# ── Sidecar detection ──────────────────────────────────────────────────

def test_sidecar_asc(tmp_path: Path):
    lib = tmp_path / "lib.so"
    lib.write_bytes(b"\x7fELF" + b"\x00" * 100)
    sidecar = tmp_path / "lib.so.asc"
    sidecar.write_text("-----BEGIN PGP SIGNATURE-----\n...\n")
    assert _find_sidecar_signature(lib) == ".asc"


def test_no_sidecar(tmp_path: Path):
    lib = tmp_path / "lib.so"
    lib.write_bytes(b"\x7fELF" + b"\x00" * 100)
    assert _find_sidecar_signature(lib) == ""


def test_inspect_file_elf_with_sidecar(tmp_path: Path):
    lib = tmp_path / "libfoo.so"
    lib.write_bytes(b"\x7fELF" + b"\x00" * 100)
    (tmp_path / "libfoo.so.minisig").write_text("untrusted comment: ...\n")
    signed, sig_type, _, _ = inspect_file(lib, "elf")
    assert signed is True
    assert sig_type == "sidecar.minisig"


# ── Path / filename origin inference ────────────────────────────────────

@pytest.mark.parametrize("path,expected", [
    ("node_modules/lodash/dist/lodash.js",         ("npm", "lodash", "")),
    ("node_modules/@scope/pkg/lib/binding.node",   ("npm", "@scope/pkg", "")),
    ("venv/lib/python3.11/site-packages/numpy/foo.so",
        ("pypi", "numpy", "")),
    ("venv/lib/python3.11/site-packages/numpy-1.26.0.dist-info/RECORD",
        ("pypi", "numpy", "1.26.0")),
    ("src/main.py", ("", "", "")),
])
def test_infer_from_path(path, expected):
    assert _infer_from_path(path) == expected


@pytest.mark.parametrize("fn,expected", [
    ("requests-2.31.0-py3-none-any.whl", ("pypi", "requests", "2.31.0")),
    ("Newtonsoft.Json.13.0.3.nupkg",     ("nuget", "Newtonsoft.Json", "13.0.3")),
    ("commons-lang3-3.12.0.jar",          ("maven", "commons-lang3", "3.12.0")),
    ("random.dll",                        ("", "", "")),
])
def test_infer_from_filename(fn, expected):
    assert _infer_from_filename(fn) == expected


def test_annotate_origins_from_paths_mutates_records():
    recs = [
        SignatureRecord(repo="r", path="node_modules/lodash/lib.js"),
        SignatureRecord(repo="r", path="random/loose.dll"),
    ]
    annotate_origins_from_paths(recs)
    assert recs[0].origin_registry == "npm"
    assert recs[0].origin_package == "lodash"
    assert recs[1].origin_registry == ""


# ── Publisher matching ──────────────────────────────────────────────────

@pytest.mark.parametrize("signer,expected,result", [
    ("DarkShadowSec LLC", "darkshadowsec", True),
    ("acme.io", "Acme Inc.", True),                      # share "acme"
    ("Microsoft Corporation", "Microsoft", True),
    ("Bob's Cert", "Alice", False),
    ("", "Whatever", False),
])
def test_publisher_matches(signer, expected, result):
    assert _publisher_matches(signer, expected) is result


# ── End-to-end repo scan ────────────────────────────────────────────────

def test_scan_repo_for_signatures_emits_records(tmp_path: Path):
    # An unsigned wheel
    whl = tmp_path / "node_modules" / "x" / "x-1.0-py3-none-any.whl"
    whl.parent.mkdir(parents=True)
    with zipfile.ZipFile(whl, "w") as zf:
        zf.writestr("x/__init__.py", "")
    # A signed JAR
    jar = tmp_path / "libs" / "sample.jar"
    jar.parent.mkdir(parents=True)
    with zipfile.ZipFile(jar, "w") as zf:
        zf.writestr("META-INF/MANIFEST.MF", "")
        zf.writestr("META-INF/SIG.SF", "")
        zf.writestr("META-INF/SIG.RSA",
                    b"\x06\x03\x55\x04\x03\x0c\x05Vend1" + b"\x00" * 40)

    records = scan_repo_for_signatures(tmp_path, "myrepo")
    by_path = {r.path: r for r in records}
    assert any(p.endswith(".whl") for p in by_path)
    assert any(p.endswith(".jar") for p in by_path)
    jar_rec = next(r for r in records if r.path.endswith(".jar"))
    assert jar_rec.signed is True
    assert jar_rec.signer_subject == "Vend1"


def test_records_to_findings_severity_split():
    recs = [
        SignatureRecord(repo="r", path="a.dll", signed=False),  # unknown origin
        SignatureRecord(repo="r", path="b.dll", signed=False,
                        origin_registry="npm", origin_package="x@1"),
        SignatureRecord(repo="r", path="c.dll", signed=True,
                        signer_verified="verified",
                        signer_subject="acme",
                        origin_registry="npm", origin_package="x@1"),
        SignatureRecord(repo="r", path="d.dll", signed=True,
                        signer_verified="publisher-mismatch",
                        signer_subject="evil",
                        expected_publisher="acme",
                        origin_registry="npm", origin_package="x@1"),
    ]
    fs = records_to_findings(recs)
    sevs = sorted(f.severity for f in fs)
    assert "high" in sevs       # a.dll  (origin unknown)
    assert "medium" in sevs     # b.dll  (located by hash)
    assert "info" in sevs       # c.dll  (verified)
    # at least two highs (a + d)
    assert sevs.count("high") >= 2
