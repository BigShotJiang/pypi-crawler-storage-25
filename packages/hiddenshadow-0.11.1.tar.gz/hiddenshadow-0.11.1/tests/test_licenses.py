"""Regression tests for license detection patterns."""
import pytest
from hiddenshadow.licenses import (
    detect_license_from_text, classify, LICENSE_CLASS,
)


@pytest.mark.parametrize("text,expected", [
    ("Apache License, Version 2.0", "Apache-2.0"),
    ("MIT License\n\nPermission is hereby granted, free of charge", "MIT"),
    ("Permission is hereby granted, free of charge, to any person obtaining a copy",
     "MIT"),
    ("GNU General Public License Version 2", "GPL-2.0"),
    ("GNU General Public License Version 3", "GPL-3.0"),
    ("GNU Affero General Public License", "AGPL-3.0"),
    ("Mozilla Public License Version 2.0", "MPL-2.0"),
    ("Business Source License 1.1", "BUSL-1.1"),
    ("Server Side Public License", "SSPL-1.0"),
    ("Elastic License 2.0", "Elastic-2.0"),
    ("PostgreSQL Database Management System", "PostgreSQL"),
    ("Detection Rule License", "DRL-1.1"),
    ("The MITRE Corporation (MITRE) hereby grants you a non-exclusive, royalty-free license",
     "MITRE-ATT&CK-License"),
])
def test_detect(text, expected):
    assert detect_license_from_text(text) == expected


def test_unknown_text():
    assert detect_license_from_text("This is some random text") is None


@pytest.mark.parametrize("spdx,expected_decision", [
    ("MIT", "adopt"),
    ("Apache-2.0", "adopt"),
    ("BSD-3-Clause", "adopt"),
    ("MPL-2.0", "library"),
    ("LGPL-3.0", "library"),
    ("GPL-2.0", "avoid"),
    ("GPL-3.0", "avoid"),
    ("AGPL-3.0", "avoid"),
    ("BUSL-1.1", "avoid"),
    ("SSPL-1.0", "avoid"),
])
def test_classify(spdx, expected_decision):
    info = classify(spdx)
    assert info.decision == expected_decision


def test_classify_unknown():
    info = classify("Some-Unknown-License")
    assert info.decision == "unknown"
