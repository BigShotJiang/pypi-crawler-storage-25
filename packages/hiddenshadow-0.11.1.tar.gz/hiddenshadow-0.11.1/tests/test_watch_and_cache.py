"""Tests for the watch (recurring rescan + history + diff) command
and the cache-TTL controls on CachedHttp.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

from hiddenshadow.network import CachedHttp, _DEFAULT_TTL_BY_SERVICE
from hiddenshadow import watch as watch_mod


# ── Cache TTL behavior ──────────────────────────────────────────────────

def test_cached_response_within_ttl_is_hit(tmp_path: Path):
    http = CachedHttp(tmp_path, service="testservice",
                      ttl_seconds=3600, request_delay_ms=0)
    # Pre-seed a cache entry
    cp = http._cache_path("k1")
    cp.write_text(json.dumps({
        "key": "k1", "fetched_at": time.time(),
        "status": 200, "data": {"value": 42}, "error": "",
    }), encoding="utf-8")
    result = http._read_cache("k1")
    assert result is not None
    assert result.status == 200
    assert result.data == {"value": 42}


def test_cached_response_past_ttl_is_miss(tmp_path: Path):
    http = CachedHttp(tmp_path, service="testservice",
                      ttl_seconds=100, request_delay_ms=0)
    cp = http._cache_path("k2")
    # 200 seconds old, TTL is 100 → expired
    cp.write_text(json.dumps({
        "key": "k2", "fetched_at": time.time() - 200,
        "status": 200, "data": {"value": 99}, "error": "",
    }), encoding="utf-8")
    assert http._read_cache("k2") is None
    assert http.stats.cache_expired == 1


def test_negative_response_has_shorter_ttl(tmp_path: Path):
    # ttl_seconds = 1 week, but negative (non-200) responses are
    # capped at the negative TTL (6h) by default. So an 8-hour-old
    # 404 should be a MISS even though 8h < 7d.
    http = CachedHttp(tmp_path, service="testservice",
                      ttl_seconds=7 * 24 * 3600, request_delay_ms=0)
    cp = http._cache_path("k3")
    cp.write_text(json.dumps({
        "key": "k3", "fetched_at": time.time() - 8 * 3600,
        "status": 404, "data": None, "error": "HTTP 404: Not Found",
    }), encoding="utf-8")
    assert http._read_cache("k3") is None


def test_refresh_flag_bypasses_cache(tmp_path: Path):
    http = CachedHttp(tmp_path, service="testservice",
                      ttl_seconds=3600, refresh=True,
                      request_delay_ms=0)
    cp = http._cache_path("k4")
    cp.write_text(json.dumps({
        "key": "k4", "fetched_at": time.time(),
        "status": 200, "data": {"value": 1}, "error": "",
    }), encoding="utf-8")
    assert http._read_cache("k4") is None  # refresh=True ignores cache


def test_default_ttls_per_service():
    """Service-specific TTL defaults are wired in."""
    assert _DEFAULT_TTL_BY_SERVICE["osv"] == 24 * 3600
    assert _DEFAULT_TTL_BY_SERVICE["depsdev"] == 7 * 24 * 3600


# ── Watch diff behavior ─────────────────────────────────────────────────

def _make_doc(*findings: dict, stamp: str = "2026-05-15T14:30:00Z") -> dict:
    return {
        "generated_at": stamp,
        "findings": list(findings),
    }


def _f(repo: str, sev: str, title: str, method: str = "test:rule",
       loc: str = "x", cat: str = "test") -> dict:
    return {
        "repo": repo, "severity": sev, "category": cat,
        "method": method, "title": title, "location": loc,
        "detail": "ignored", "recommendation": "ignored",
    }


def test_initial_run_all_findings_are_new():
    cur = _make_doc(_f("r", "high", "F1"), _f("r", "medium", "F2"))
    diff = watch_mod.diff_runs(prior=None, current=cur)
    assert len(diff.new_findings) == 2
    assert diff.resolved_findings == []
    assert diff.unchanged == 0


def test_no_change_between_runs():
    a = _f("r", "high", "F1")
    b = _f("r", "medium", "F2")
    prior = _make_doc(a, b)
    cur = _make_doc(a, b)
    diff = watch_mod.diff_runs(prior=prior, current=cur)
    assert diff.new_findings == []
    assert diff.resolved_findings == []
    assert diff.unchanged == 2


def test_new_finding_detected():
    a = _f("r", "high", "F1")
    prior = _make_doc(a)
    new = _f("r", "critical", "F2-NEW")
    cur = _make_doc(a, new)
    diff = watch_mod.diff_runs(prior=prior, current=cur)
    assert len(diff.new_findings) == 1
    assert diff.new_findings[0]["title"] == "F2-NEW"
    assert diff.unchanged == 1


def test_resolved_finding_detected():
    a = _f("r", "high", "F1")
    b = _f("r", "medium", "F2")
    prior = _make_doc(a, b)
    cur = _make_doc(a)
    diff = watch_mod.diff_runs(prior=prior, current=cur)
    assert diff.new_findings == []
    assert len(diff.resolved_findings) == 1
    assert diff.resolved_findings[0]["title"] == "F2"


def test_severity_change_treated_as_new_and_resolved():
    """A finding whose severity changes is logically a different identity."""
    prior = _make_doc(_f("r", "medium", "F1"))
    cur = _make_doc(_f("r", "high", "F1"))
    diff = watch_mod.diff_runs(prior=prior, current=cur)
    assert len(diff.new_findings) == 1
    assert len(diff.resolved_findings) == 1


def test_new_by_severity_aggregation():
    diff = watch_mod.diff_runs(
        prior=_make_doc(),
        current=_make_doc(
            _f("r", "critical", "A"),
            _f("r", "critical", "B"),
            _f("r", "high", "C"),
            _f("r", "info", "D"),
        ),
    )
    sevs = diff.new_by_severity
    assert sevs.get("critical") == 2
    assert sevs.get("high") == 1
    assert sevs.get("info") == 1


# ── History persistence ────────────────────────────────────────────────

def test_history_save_and_load_cycle(tmp_path: Path):
    doc1 = _make_doc(_f("r", "high", "F1"))
    p1 = watch_mod._save_run(tmp_path, doc1)
    assert p1.exists()
    assert (tmp_path / watch_mod.HISTORY_DIRNAME / "latest.json").exists()
    # Saving another run picks it up as prior
    time.sleep(1.1)  # ensure a different timestamp slug
    doc2 = _make_doc(_f("r", "high", "F1"), _f("r", "critical", "F2"))
    watch_mod._save_run(tmp_path, doc2)
    runs = watch_mod._list_history(
        watch_mod._history_dir(tmp_path))
    assert len(runs) == 2


def test_prior_run_returns_most_recent(tmp_path: Path):
    hd = watch_mod._history_dir(tmp_path)
    # Write two history files; older should be sorted before newer.
    old = hd / "20260515T100000Z.json"
    new = hd / "20260516T100000Z.json"
    old.write_text(json.dumps(_make_doc(_f("r", "low", "old"))))
    new.write_text(json.dumps(_make_doc(_f("r", "high", "new"))))
    prior = watch_mod._prior_run(hd)
    assert prior is not None
    assert prior["findings"][0]["title"] == "new"


# ── Integration with run_once via a stub scan ─────────────────────────

def test_run_once_persists_and_diffs(tmp_path: Path, monkeypatch):
    """run_once should call scan.run, persist the result, and diff."""
    call_count = {"n": 0}

    def fake_run(*, source_root, output_root, quiet=True, **kwargs):
        call_count["n"] += 1
        # Each call returns one MORE finding than the previous, so the
        # diff for the second call has exactly one new finding.
        findings = [_f("r", "high", f"F{i}") for i in range(call_count["n"])]
        return {
            "findings": {
                "generated_at": f"2026-05-15T14:{call_count['n']:02}:00Z",
                "findings": findings,
            },
        }

    monkeypatch.setattr(watch_mod.scan_mod, "run", fake_run)

    # First run: 1 finding, all new (initial).
    _, diff1 = watch_mod.run_once(tmp_path, tmp_path)
    assert len(diff1.new_findings) == 1
    assert diff1.prior_stamp == ""
    # Second run: 2 findings, one new since prior.
    time.sleep(1.1)
    _, diff2 = watch_mod.run_once(tmp_path, tmp_path)
    assert len(diff2.new_findings) == 1
    assert diff2.unchanged == 1
