"""Regression tests for the secret/credential detector."""
from __future__ import annotations
import textwrap
from pathlib import Path

import pytest

from hiddenshadow.secrets import (
    _scan_file_text, scan_repo_for_secrets, _is_placeholder,
)


# ── Positive cases: each input should produce >= 1 finding ─────────────

POSITIVE_CASES = [
    # Provider tokens
    ("aws", 'AWS_KEY = "AKIAIOSFODNN7EXAMPLE"', "AWS access key id"),
    ("github_pat", 'token = "ghp_abcdefghijklmnopqrstuvwxyz0123456789"',
     "GitHub PAT (classic)"),
    ("github_finegrained",
     'GH = "github_pat_11ABCDE2A0' + 'a' * 72 + '"',  # 10 + 72 = 82 chars after `_`
     "GitHub PAT (fine-grained)"),
    ("google_api", 'g = "AIzaSyBVf' + 'a' * 30 + '"', "Google API key"),  # 5 + 30 = 35 chars after `AIza`
    ("stripe_live", 'k = "sk_live_' + 'a' * 30 + '"', "Stripe live secret key"),
    ("slack", 'tok = "xoxb-1234567890-abcdefghijklm"', "Slack token"),
    ("npm",  'registry = "npm_' + 'A' * 36 + '"', "npm access token"),

    # Connection string with embedded password
    ("mongo_uri",
     'DB = "mongodb://admin:s3cret-pa55!@db.example.com:27017/myapp"',
     "Connection string with embedded password"),
    ("postgres_uri",
     'url = "postgres://user:hunter2@localhost:5432/db"',
     "Connection string with embedded password"),

    # Private key block
    ("private_key",
     "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA...\n-----END RSA PRIVATE KEY-----",
     "Hardcoded private key block"),

    # Generic credential assignment
    ("plain_password_py",
     'PASSWORD = "Sup3rSecret-prod-2025"',
     "Hardcoded credential"),
    ("plain_password_yaml",
     'database_password: "L1ve-Pr0d-Pa55phra5e"',
     "Hardcoded credential"),
    ("api_key_kwarg",
     "client = Client(api_key='ak_live_real-customer-key-123456')",
     "Hardcoded credential"),
]


@pytest.mark.parametrize("name,text,expected_substring", POSITIVE_CASES,
                         ids=[c[0] for c in POSITIVE_CASES])
def test_detects(name, text, expected_substring):
    findings = _scan_file_text("repo", "src/app.py", text)
    titles = " | ".join(f.title for f in findings)
    assert findings, f"expected a finding for {name!r}, got none"
    assert expected_substring in titles, (
        f"expected {expected_substring!r} in finding titles, got: {titles}")


# ── Negative cases: each input should produce zero findings ────────────

NEGATIVE_CASES = [
    # Empty / placeholder values
    ("empty",         'PASSWORD = ""'),
    ("placeholder1",  'PASSWORD = "<your-password>"'),
    ("placeholder2",  'API_KEY = "${API_KEY}"'),
    ("placeholder3",  'token = "{{TOKEN}}"'),
    ("placeholder4",  'secret = "REPLACE_ME"'),
    ("placeholder5",  'auth_token = "your-token-here"'),
    ("placeholder6",  'PASSWORD = "changeme"'),
    ("placeholder7",  'PASSWORD = "example"'),
    ("envvar",        'PASSWORD = os.environ["DB_PASSWORD"]'),
    ("envvar2",       'pwd = process.env.DB_PASSWORD'),
    ("vault",         'password = vault.read("secret/data/db").data["password"]'),
    ("dollar_var",    'API_KEY = "$API_KEY"'),

    # Comments / docstrings should still be scanned, but plain text isn't
    # a credential (no keyword=value structure).
    ("plain_prose", "This file talks about passwords and API keys."),

    # All-same-character noise
    ("xxx",  'password = "xxxxxxxx"'),
    ("zero", 'password = "00000000"'),
]


@pytest.mark.parametrize("name,text", NEGATIVE_CASES,
                         ids=[c[0] for c in NEGATIVE_CASES])
def test_no_false_positive(name, text):
    findings = _scan_file_text("repo", "src/app.py", text)
    assert not findings, (
        f"expected no findings for {name!r}, got: "
        + ", ".join(f.title for f in findings))


# ── Output safety: the redacted secret never echoes the full value ─────

def test_redaction():
    pw = "TopSecretProductionPassword2025"
    findings = _scan_file_text("repo", "src/app.py", f'PASSWORD = "{pw}"')
    assert findings
    for f in findings:
        assert pw not in f.detail, (
            f"detail leaked the full secret: {f.detail!r}")


# ── Repo-level walk picks up files and applies extension filters ───────

def test_scan_repo_for_secrets(tmp_path: Path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "config.py").write_text(
        'PASSWORD = "Real-Looking-Secret-2025"', encoding="utf-8")
    (tmp_path / "src" / "image.bin").write_bytes(b"AKIAIOSFODNN7EXAMPLE")
    (tmp_path / "package-lock.json").write_text(
        '{"integrity":"sha512-AKIAIOSFODNN7EXAMPLE-abcdef"}', encoding="utf-8")

    findings = scan_repo_for_secrets(tmp_path, "demo")
    titles = [f.title for f in findings]
    locs = [f.location for f in findings]

    # Picked up the .py credential.
    assert any("Hardcoded credential" in t for t in titles), titles
    assert any("config.py" in loc for loc in locs), locs

    # Did NOT scan the binary (no extension match) or the lockfile (skip-list).
    assert not any("image.bin" in loc for loc in locs)
    assert not any("package-lock.json" in loc for loc in locs)


def test_is_placeholder_basics():
    assert _is_placeholder("")
    assert _is_placeholder("   ")
    assert _is_placeholder("***")
    assert _is_placeholder("xxxx")
    assert _is_placeholder("<password>")
    assert _is_placeholder("${PASSWORD}")
    assert _is_placeholder("changeme")
    assert _is_placeholder("your-token-here")
    assert not _is_placeholder("Sup3rSecret-prod-2025")
    assert not _is_placeholder("AKIAQF7XK4ZBYP3HW2NK")
    # Strings containing the literal word "example" are deliberately treated
    # as placeholders so AWS docs samples don't drown real findings.
    assert _is_placeholder("AKIAIOSFODNN7EXAMPLE")
