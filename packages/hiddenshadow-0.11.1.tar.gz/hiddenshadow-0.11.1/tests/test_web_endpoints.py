"""Flask-test-client tests for the new web endpoints.

Covers the happy path for tfscan, containerscan, ci-scan, check, and
watch (start/diff/stop), plus the auth-token gate.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import pytest

flask = pytest.importorskip("flask")  # web extras may not be installed

from hiddenshadow import web as web_mod
from hiddenshadow import web_endpoints


@pytest.fixture
def app():
    """Fresh Flask app per test (clears the aux job registry too)."""
    web_endpoints._aux_jobs.clear()
    web_endpoints.set_auth_token(None)
    yield web_mod.create_app()


@pytest.fixture
def client(app):
    return app.test_client()


def _wait_for_complete(client, job_id: str, timeout: float = 20.0) -> dict:
    """Poll /api/aux/<id>/status until it reaches a terminal state."""
    start = time.time()
    while time.time() - start < timeout:
        r = client.get(f"/api/aux/{job_id}/status")
        data = r.get_json()
        if data.get("status") in ("complete", "error"):
            return data
        time.sleep(0.05)
    raise AssertionError("job did not complete within timeout")


def _seed_tf(tmp_path: Path) -> None:
    (tmp_path / "main.tf").write_text("""
resource "aws_s3_bucket" "logs" {
  bucket = "x"
  acl    = "public-read"
}
""")


def _seed_dockerfile(tmp_path: Path) -> None:
    (tmp_path / "Dockerfile").write_text(
        "FROM nginx:latest\nUSER root\nEXPOSE 22\n"
    )


def _seed_ghactions(tmp_path: Path) -> None:
    d = tmp_path / ".github" / "workflows"
    d.mkdir(parents=True)
    (d / "ci.yml").write_text(
        "on: pull_request_target\n"
        "jobs:\n"
        "  x:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "        with:\n"
        "          ref: ${{ github.event.pull_request.head.sha }}\n"
    )


# ── tfscan ──────────────────────────────────────────────────────────

def test_tfscan_happy_path(client, tmp_path):
    _seed_tf(tmp_path)
    resp = client.post("/api/tfscan", json={
        "source_root": str(tmp_path), "clouds": "aws",
        "emit_sarif": True,
    })
    assert resp.status_code == 200
    job_id = resp.get_json()["job_id"]
    status = _wait_for_complete(client, job_id)
    assert status["status"] == "complete"
    assert "tfscan-findings.json" in status["artifacts"]
    assert "tfscan-findings.sarif" in status["artifacts"]

    findings = client.get(f"/api/aux/{job_id}/findings").get_json()
    sevs = {f["severity"] for f in findings["findings"]}
    assert "high" in sevs  # public S3 ACL is high

    # SARIF artifact is downloadable + valid JSON
    sarif = client.get(
        f"/api/aux/{job_id}/artifact?name=tfscan-findings.sarif")
    assert sarif.status_code == 200
    sdoc = json.loads(sarif.data)
    assert sdoc["version"] == "2.1.0"


def test_tfscan_missing_source_400(client):
    resp = client.post("/api/tfscan", json={})
    assert resp.status_code == 400


def test_tfscan_bad_path_400(client, tmp_path):
    resp = client.post("/api/tfscan", json={
        "source_root": str(tmp_path / "does-not-exist"),
    })
    assert resp.status_code == 400


# ── containerscan ───────────────────────────────────────────────────

def test_containerscan_static_only(client, tmp_path):
    _seed_dockerfile(tmp_path)
    resp = client.post("/api/containerscan", json={
        "source_root": str(tmp_path),
        "scan_layers": False,  # offline
        "cve_lookup": False,
    })
    assert resp.status_code == 200
    job_id = resp.get_json()["job_id"]
    status = _wait_for_complete(client, job_id)
    assert status["status"] == "complete"

    findings = client.get(f"/api/aux/{job_id}/findings").get_json()
    rule_ids = {(f.get("method") or "").rsplit(":", 1)[-1]
                for f in findings["findings"]}
    assert "df-latest-tag" in rule_ids
    assert "df-user-explicit-root" in rule_ids


# ── ci-scan ─────────────────────────────────────────────────────────

def test_ciscan_happy_path(client, tmp_path):
    _seed_ghactions(tmp_path)
    resp = client.post("/api/ci-scan", json={
        "source_root": str(tmp_path), "emit_sarif": True,
    })
    assert resp.status_code == 200
    job_id = resp.get_json()["job_id"]
    status = _wait_for_complete(client, job_id)
    assert status["status"] == "complete"

    findings = client.get(f"/api/aux/{job_id}/findings").get_json()
    rule_ids = {(f.get("method") or "").rsplit(":", 1)[-1]
                for f in findings["findings"]}
    assert "gha-pr-target-checkout-head" in rule_ids


# ── check ───────────────────────────────────────────────────────────

def test_check_runs_everything(client, tmp_path):
    _seed_tf(tmp_path)
    _seed_dockerfile(tmp_path)
    _seed_ghactions(tmp_path)
    # Add a LICENSE so the main scan finds the repo.
    (tmp_path / "LICENSE").write_text("MIT")
    resp = client.post("/api/check", json={"source_root": str(tmp_path)})
    assert resp.status_code == 200
    job_id = resp.get_json()["job_id"]
    status = _wait_for_complete(client, job_id, timeout=40.0)
    assert status["status"] == "complete"
    # Should have produced both kinds of findings
    findings = client.get(f"/api/aux/{job_id}/findings").get_json()
    categories = {f["category"] for f in findings["findings"]}
    assert "iac" in categories or "container" in categories or "cicd" in categories


# ── watch ───────────────────────────────────────────────────────────

def test_watch_start_diff_stop(client, tmp_path):
    _seed_tf(tmp_path)
    (tmp_path / "LICENSE").write_text("MIT")
    resp = client.post("/api/watch/start", json={
        "source_root": str(tmp_path),
        "interval_s": 60,  # min, but we'll stop before it actually elapses
    })
    assert resp.status_code == 200
    job_id = resp.get_json()["job_id"]

    # Wait for the FIRST tick to complete (history populated).
    deadline = time.time() + 25.0
    runs = []
    while time.time() < deadline:
        hist = client.get(f"/api/watch/{job_id}/history").get_json()
        runs = hist.get("runs", [])
        if runs:
            break
        time.sleep(0.1)
    assert runs, "watch never produced a tick"

    diff = client.get(f"/api/watch/{job_id}/diff").get_json()
    assert diff["diff"] is not None
    assert "new_findings" in diff["diff"]

    stop = client.post(f"/api/watch/{job_id}/stop")
    assert stop.status_code == 200


def test_watch_unknown_id_404(client):
    r = client.post("/api/watch/nonexistent/stop")
    assert r.status_code == 404
    r = client.get("/api/watch/nonexistent/diff")
    assert r.status_code == 404


# ── auth-token gate ────────────────────────────────────────────────

def test_auth_token_required(client, tmp_path):
    _seed_tf(tmp_path)
    web_endpoints.set_auth_token("s3cret")
    try:
        # No token: 401
        r = client.post("/api/tfscan",
                        json={"source_root": str(tmp_path)})
        assert r.status_code == 401
        # Wrong token: 401
        r = client.post("/api/tfscan",
                        json={"source_root": str(tmp_path)},
                        headers={"X-HS-Token": "wrong"})
        assert r.status_code == 401
        # Correct token: 200
        r = client.post("/api/tfscan",
                        json={"source_root": str(tmp_path)},
                        headers={"X-HS-Token": "s3cret"})
        assert r.status_code == 200
    finally:
        web_endpoints.set_auth_token(None)


def test_index_always_reachable_under_auth(client):
    web_endpoints.set_auth_token("s3cret")
    try:
        r = client.get("/")
        assert r.status_code == 200
        r = client.get("/api/ping")
        assert r.status_code == 200
    finally:
        web_endpoints.set_auth_token(None)


# ── aux job listing ─────────────────────────────────────────────────

def test_aux_jobs_listing(client, tmp_path):
    _seed_tf(tmp_path)
    r = client.post("/api/tfscan",
                    json={"source_root": str(tmp_path), "clouds": "aws"})
    jid = r.get_json()["job_id"]
    _wait_for_complete(client, jid)
    listing = client.get("/api/aux/jobs").get_json()
    assert any(j["job_id"] == jid for j in listing["jobs"])
