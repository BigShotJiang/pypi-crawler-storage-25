"""Tests for the SARIF formatter, diff-mode filter, and webhook payloads."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from hiddenshadow.findings import Finding
from hiddenshadow import sarif as sarif_mod
from hiddenshadow import diffmode
from hiddenshadow import webhooks
from hiddenshadow.watch import WatchDiff


def _f(severity: str, title: str, location: str = "src/x.py:42",
       method: str = "test:rule", category: str = "test") -> Finding:
    return Finding(
        repo="r", severity=severity, category=category,
        title=title, location=location, detail="d", recommendation="r",
        method=method,
    )


# ── SARIF formatter ────────────────────────────────────────────────────

def test_sarif_basic_shape(tmp_path: Path):
    doc = sarif_mod.findings_to_sarif(
        [_f("critical", "T1"), _f("medium", "T2")],
        tool_version="0.0.1", source_root=tmp_path,
    )
    assert doc["version"] == "2.1.0"
    assert doc["runs"][0]["tool"]["driver"]["name"] == "HiddenShadow"
    assert len(doc["runs"][0]["results"]) == 2
    assert len(doc["runs"][0]["tool"]["driver"]["rules"]) == 1


def test_sarif_level_mapping():
    doc = sarif_mod.findings_to_sarif([
        _f("critical", "C"), _f("high", "H"),
        _f("medium", "M"), _f("low", "L"), _f("info", "I"),
    ])
    levels = [r["level"] for r in doc["runs"][0]["results"]]
    assert levels == ["error", "error", "warning", "note", "note"]


def test_sarif_location_parsed():
    doc = sarif_mod.findings_to_sarif([
        _f("high", "T", location="path/to/file.py:123"),
    ])
    locs = doc["runs"][0]["results"][0]["locations"]
    assert locs[0]["physicalLocation"]["artifactLocation"]["uri"] == "path/to/file.py"
    assert locs[0]["physicalLocation"]["region"]["startLine"] == 123


def test_sarif_rollup_location_keeps_finding():
    doc = sarif_mod.findings_to_sarif([_f("medium", "T", location="(rollup)")])
    # Aggregate locations -> no physicalLocation entry, but the finding
    # itself must still be present.
    assert len(doc["runs"][0]["results"]) == 1


def test_sarif_distinct_methods_get_distinct_rules():
    doc = sarif_mod.findings_to_sarif([
        _f("high", "A", method="cat:rule-a"),
        _f("high", "B", method="cat:rule-b"),
        _f("high", "C", method="cat:rule-a"),
    ])
    rules = doc["runs"][0]["tool"]["driver"]["rules"]
    assert {r["id"] for r in rules} == {"cat:rule-a", "cat:rule-b"}


def test_sarif_write_to_disk(tmp_path: Path):
    out = sarif_mod.write_sarif(
        [_f("high", "T")], tmp_path / "out.sarif",
        tool_version="0.0.1", source_root=tmp_path,
    )
    assert out.exists()
    doc = json.loads(out.read_text())
    assert doc["version"] == "2.1.0"


# ── Diff mode ──────────────────────────────────────────────────────────

def _init_git(tmp_path: Path) -> None:
    subprocess.run(["git", "init", "-q"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.email", "t@example.com"],
                   cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "commit.gpgsign", "false"],
                   cwd=tmp_path, check=True)


def _commit_all(tmp_path: Path, msg: str) -> None:
    subprocess.run(["git", "add", "-A"], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-q", "-m", msg], cwd=tmp_path, check=True)


def test_changed_files_basic(tmp_path: Path):
    _init_git(tmp_path)
    (tmp_path / "a.py").write_text("# a\n")
    (tmp_path / "b.py").write_text("# b\n")
    _commit_all(tmp_path, "init")
    base = subprocess.run(["git", "rev-parse", "HEAD"],
                          cwd=tmp_path, capture_output=True, text=True,
                          check=True).stdout.strip()
    (tmp_path / "b.py").write_text("# b changed\n")
    (tmp_path / "c.py").write_text("# c new\n")
    _commit_all(tmp_path, "change")
    changed = diffmode.changed_files(tmp_path, base_ref=base)
    assert changed is not None
    assert "b.py" in changed
    assert "c.py" in changed
    assert "a.py" not in changed


def test_changed_files_unknown_ref_returns_none(tmp_path: Path):
    _init_git(tmp_path)
    (tmp_path / "a.py").write_text("# a\n")
    _commit_all(tmp_path, "init")
    assert diffmode.changed_files(
        tmp_path, base_ref="nonexistent-ref") is None


def test_changed_files_non_repo_returns_none(tmp_path: Path):
    # No git init at all → must return None gracefully.
    assert diffmode.changed_files(tmp_path, base_ref="HEAD") is None


def test_filter_findings_by_files():
    findings = [
        _f("high", "T1", location="src/a.py:10"),
        _f("high", "T2", location="src/b.py:20"),
        _f("high", "T3", location="(rollup)"),
        _f("high", "T4", location="src/c.py:30"),
    ]
    kept = diffmode.filter_findings_by_files(
        findings, changed={"src/a.py", "src/c.py"})
    titles = {f.title for f in kept}
    # rollup always passes through
    assert titles == {"T1", "T3", "T4"}


def test_filter_findings_no_location_kept():
    findings = [_f("low", "T", location="")]
    kept = diffmode.filter_findings_by_files(findings, changed={"x.py"})
    assert len(kept) == 1


# ── Webhooks ───────────────────────────────────────────────────────────

def _diff(new=None, prior_stamp="2026-05-15T00:00:00Z") -> WatchDiff:
    return WatchDiff(
        prior_stamp=prior_stamp,
        current_stamp="2026-05-16T00:00:00Z",
        new_findings=new or [],
    )


def test_webhook_no_new_skips(monkeypatch):
    posted = []

    def fake_post(*a, **kw):
        posted.append(a)
        return webhooks.NotifyResult(status=200)
    monkeypatch.setattr(webhooks, "_post_json", fake_post)
    r = webhooks.notify(_diff([]),
                        "https://hooks.slack.com/services/x")
    assert r.status == 204
    assert posted == []


def test_webhook_slack_payload_shape(monkeypatch):
    captured = {}

    def fake_post(url, body, **kw):
        captured["url"] = url
        captured["body"] = body
        return webhooks.NotifyResult(status=200)
    monkeypatch.setattr(webhooks, "_post_json", fake_post)
    diff = _diff([
        {"severity": "critical", "title": "T1", "location": "x:1",
         "method": "m"},
        {"severity": "high", "title": "T2", "location": "y:2", "method": "m"},
    ])
    webhooks.notify(diff, "https://hooks.slack.com/services/abc")
    assert "blocks" in captured["body"]
    header = captured["body"]["blocks"][0]
    assert header["type"] == "header"
    assert "2 new finding" in header["text"]["text"]


def test_webhook_github_pr_requires_token(monkeypatch):
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.delenv("GH_TOKEN", raising=False)
    r = webhooks.notify(
        _diff([{"severity": "high", "title": "X", "location": "x:1"}]),
        "https://api.github.com/repos/o/r/pulls/1/comments",
    )
    assert r.status == 0
    assert "GITHUB_TOKEN" in r.error


def test_webhook_github_pr_with_token(monkeypatch):
    captured = {}

    def fake_post(url, body, headers=None, **kw):
        captured["url"] = url
        captured["body"] = body
        captured["headers"] = headers
        return webhooks.NotifyResult(status=201)
    monkeypatch.setattr(webhooks, "_post_json", fake_post)
    monkeypatch.setenv("GITHUB_TOKEN", "test-token-123")
    r = webhooks.notify(
        _diff([{"severity": "critical", "title": "X",
                "location": "x:1", "method": "m"}]),
        "https://api.github.com/repos/o/r/pulls/1/comments",
    )
    assert r.status == 201
    assert "Bearer test-token-123" in captured["headers"]["Authorization"]
    assert "1 new finding" in captured["body"]["body"]


def test_webhook_generic_json(monkeypatch):
    captured = {}

    def fake_post(url, body, **kw):
        captured["url"] = url
        captured["body"] = body
        return webhooks.NotifyResult(status=200)
    monkeypatch.setattr(webhooks, "_post_json", fake_post)
    diff = _diff([
        {"severity": "high", "title": "T", "location": "x:1", "method": "m"},
    ])
    webhooks.notify(diff, "https://example.com/incoming",
                    tool_version="9.9.9")
    assert captured["body"]["tool"] == "hiddenshadow"
    assert captured["body"]["version"] == "9.9.9"
    assert captured["body"]["diff"]["new_count"] == 1
