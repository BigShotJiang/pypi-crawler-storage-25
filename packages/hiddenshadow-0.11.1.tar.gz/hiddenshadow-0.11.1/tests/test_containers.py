"""Regression tests for the container security scanner."""
from __future__ import annotations

import gzip
import io
import tarfile
import textwrap
from pathlib import Path

import pytest

from hiddenshadow.containers import scan_path
from hiddenshadow.containers import dockerfile as df_mod
from hiddenshadow.containers import compose as compose_mod
from hiddenshadow.containers import layers as layers_mod


# ── Dockerfile parser ─────────────────────────────────────────────────

def test_parse_simple_dockerfile():
    text = textwrap.dedent("""
        FROM python:3.11-slim
        RUN pip install requests
        USER 1001
        CMD ["python", "app.py"]
    """).strip()
    pd = df_mod.parse_dockerfile(text, Path("Dockerfile"))
    assert len(pd.stages) == 1
    cmds = [i.cmd for i in pd.stages[0].instructions]
    assert "FROM" in cmds
    assert "RUN" in cmds
    assert "USER" in cmds
    assert pd.stages[0].base_image == "python:3.11-slim"


def test_parse_multistage_with_args():
    text = textwrap.dedent("""
        ARG GO_VERSION=1.21
        FROM golang:${GO_VERSION} AS build
        RUN go build -o app
        FROM gcr.io/distroless/static AS final
        COPY --from=build /app /app
    """).strip()
    pd = df_mod.parse_dockerfile(text, Path("Dockerfile"))
    assert len(pd.stages) == 2
    assert pd.stages[0].name == "build"
    assert pd.stages[0].base_image == "golang:1.21"
    assert pd.stages[1].name == "final"
    assert pd.stages[1].base_image == "gcr.io/distroless/static"


def test_parse_continuation_lines():
    text = textwrap.dedent("""
        FROM debian:bookworm
        RUN apt-get update \\
            && apt-get install -y curl \\
            && rm -rf /var/lib/apt/lists/*
    """).strip()
    pd = df_mod.parse_dockerfile(text, Path("Dockerfile"))
    runs = [i for i in pd.stages[0].instructions if i.cmd == "RUN"]
    assert len(runs) == 1
    assert "apt-get install" in runs[0].args


# ── Image-ref parser ────────────────────────────────────────────────────

@pytest.mark.parametrize("raw,expected", [
    ("nginx", ("docker.io", "library/nginx", "latest", "")),
    ("nginx:1.21", ("docker.io", "library/nginx", "1.21", "")),
    ("library/nginx:1.21", ("docker.io", "library/nginx", "1.21", "")),
    ("ghcr.io/foo/bar:tag", ("ghcr.io", "foo/bar", "tag", "")),
    ("ghcr.io/foo/bar@sha256:abc",
     ("ghcr.io", "foo/bar", "", "sha256:abc")),
    ("nginx:1.21@sha256:xyz",
     ("docker.io", "library/nginx", "1.21", "sha256:xyz")),
    ("gcr.io/distroless/static",
     ("gcr.io", "distroless/static", "latest", "")),
    ("localhost:5000/myimg:tag",
     ("localhost:5000", "myimg", "tag", "")),
])
def test_parse_image_ref(raw, expected):
    ref = df_mod.parse_image_ref(raw)
    assert (ref.registry, ref.repository, ref.tag, ref.digest) == expected


def test_image_ref_latest_detection():
    assert df_mod.parse_image_ref("nginx").is_latest
    assert df_mod.parse_image_ref("nginx:latest").is_latest
    assert not df_mod.parse_image_ref("nginx:1.21").is_latest
    assert df_mod.parse_image_ref("nginx@sha256:abc").is_digest_pinned


# ── Dockerfile rules ────────────────────────────────────────────────────

def _scan_dockerfile(tmp_path: Path, body: str):
    f = tmp_path / "Dockerfile"
    f.write_text(textwrap.dedent(body).strip())
    pd, fs = df_mod.scan_file(f, "test")
    return fs


def _has_rule(findings, frag: str) -> bool:
    return any(frag in (f.method or "") for f in findings)


def test_rule_user_root_when_missing(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:bookworm
        RUN apt-get update
    """)
    assert _has_rule(fs, "df-user-root")


def test_rule_user_explicit_root(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:bookworm
        USER root
    """)
    assert _has_rule(fs, "df-user-explicit-root")


def test_rule_no_user_root_when_uid_set(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:bookworm
        USER 1001
    """)
    assert not _has_rule(fs, "df-user-root")
    assert not _has_rule(fs, "df-user-explicit-root")


def test_rule_latest_tag(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM nginx:latest
        USER 1001
    """)
    assert _has_rule(fs, "df-latest-tag")


def test_rule_no_tag_implies_latest(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM nginx
        USER 1001
    """)
    assert _has_rule(fs, "df-no-tag") or _has_rule(fs, "df-latest-tag")


def test_rule_floating_major(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM nginx:1
        USER 1001
    """)
    assert _has_rule(fs, "df-floating-major")


def test_rule_digest_pinned_no_finding(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM nginx:1.21@sha256:abcdef
        USER 1001
    """)
    assert not _has_rule(fs, "df-not-digest-pinned")
    assert not _has_rule(fs, "df-latest-tag")


def test_rule_add_remote(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        ADD https://example.com/x.tgz /tmp/
        USER 1001
    """)
    assert _has_rule(fs, "df-add-remote")


def test_rule_curl_pipe_sh_critical(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        RUN curl -sL https://ex.com/install.sh | sh
        USER 1001
    """)
    assert _has_rule(fs, "df-curl-pipe-sh")
    f = next(x for x in fs if "df-curl-pipe-sh" in (x.method or ""))
    assert f.severity == "critical"


def test_rule_apt_no_recommends(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        RUN apt-get update && apt-get install -y curl
        USER 1001
    """)
    assert _has_rule(fs, "df-apt-no-recommends")
    assert _has_rule(fs, "df-apt-no-cleanup")


def test_rule_apt_clean_no_finding(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        RUN apt-get update \\
            && apt-get install -y --no-install-recommends curl \\
            && rm -rf /var/lib/apt/lists/*
        USER 1001
    """)
    assert not _has_rule(fs, "df-apt-no-recommends")
    assert not _has_rule(fs, "df-apt-no-cleanup")


def test_rule_pip_trusted_host(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM python:3.11-slim
        RUN pip install --trusted-host pypi.org requests
        USER 1001
    """)
    assert _has_rule(fs, "df-pip-trusted-host")


def test_rule_secret_in_env(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        ENV API_KEY=ak_live_abcdef1234567890
        USER 1001
    """)
    assert _has_rule(fs, "df-secret-in-env")


def test_rule_secret_in_env_var_indirection_no_finding(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        ARG API_KEY
        ENV API_KEY=$API_KEY
        USER 1001
    """)
    assert not _has_rule(fs, "df-secret-in-env")


def test_rule_expose_sensitive(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        EXPOSE 22
        USER 1001
    """)
    assert _has_rule(fs, "df-expose-sensitive")


def test_rule_ssh_installed(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        RUN apt-get install -y openssh-server
        USER 1001
    """)
    assert _has_rule(fs, "df-ssh-installed")


def test_rule_chmod_777(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        RUN chmod -R 777 /opt
        USER 1001
    """)
    assert _has_rule(fs, "df-chmod-777")


def test_rule_maintainer_deprecated(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        MAINTAINER alice@example.com
        USER 1001
    """)
    assert _has_rule(fs, "df-maintainer-deprecated")


def test_rule_healthcheck_missing(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        USER 1001
    """)
    assert _has_rule(fs, "df-no-healthcheck")


def test_rule_healthcheck_present_no_finding(tmp_path: Path):
    fs = _scan_dockerfile(tmp_path, """
        FROM debian:12
        HEALTHCHECK --interval=30s CMD curl -f http://localhost || exit 1
        USER 1001
    """)
    assert not _has_rule(fs, "df-no-healthcheck")


# ── Compose YAML parser ────────────────────────────────────────────────

def test_compose_parser_basic():
    text = textwrap.dedent("""
        version: "3.9"
        services:
          web:
            image: nginx:1.21
            ports:
              - "8080:80"
              - "5432"
    """)
    root = compose_mod.parse_yaml(text)
    services = compose_mod._get(root, "services")
    assert services is not None
    web = services.value["web"]
    assert compose_mod._value(compose_mod._get(web, "image")) == "nginx:1.21"
    ports = compose_mod._items(compose_mod._get(web, "ports"))
    assert len(ports) == 2


def test_compose_parser_inline_flow_list():
    text = textwrap.dedent("""
        services:
          x:
            cap_add: [SYS_ADMIN, NET_ADMIN]
    """)
    root = compose_mod.parse_yaml(text)
    x = compose_mod._get(root, "services").value["x"]
    caps = compose_mod._to_list(compose_mod._get(x, "cap_add"))
    assert caps == ["SYS_ADMIN", "NET_ADMIN"]


def test_compose_rule_privileged(tmp_path: Path):
    text = textwrap.dedent("""
        services:
          x:
            image: alpine:3.18
            privileged: true
    """)
    f = tmp_path / "docker-compose.yml"
    f.write_text(text)
    fs = compose_mod.scan_compose_file(f, "test")
    assert any("compose-privileged" in (x.method or "") for x in fs)
    fp = next(x for x in fs if "compose-privileged" in (x.method or ""))
    assert fp.severity == "critical"


def test_compose_rule_docker_sock_mount(tmp_path: Path):
    text = textwrap.dedent("""
        services:
          x:
            image: alpine:3.18
            user: "1001"
            volumes:
              - /var/run/docker.sock:/var/run/docker.sock
    """)
    f = tmp_path / "docker-compose.yml"
    f.write_text(text)
    fs = compose_mod.scan_compose_file(f, "test")
    assert any("compose-docker-sock" in (x.method or "") for x in fs)


def test_compose_rule_host_network(tmp_path: Path):
    text = textwrap.dedent("""
        services:
          x:
            image: alpine:3.18
            user: "1001"
            network_mode: host
    """)
    f = tmp_path / "docker-compose.yml"
    f.write_text(text)
    fs = compose_mod.scan_compose_file(f, "test")
    assert any("compose-network-host" in (x.method or "") for x in fs)


def test_compose_rule_cap_add_sys_admin(tmp_path: Path):
    text = textwrap.dedent("""
        services:
          x:
            image: alpine:3.18
            user: "1001"
            cap_add: [SYS_ADMIN]
    """)
    f = tmp_path / "docker-compose.yml"
    f.write_text(text)
    fs = compose_mod.scan_compose_file(f, "test")
    assert any("compose-cap-add" in (x.method or "") for x in fs)


def test_compose_rule_secret_env(tmp_path: Path):
    text = textwrap.dedent("""
        services:
          x:
            image: alpine:3.18
            user: "1001"
            environment:
              DATABASE_PASSWORD: "hunter2"
    """)
    f = tmp_path / "docker-compose.yml"
    f.write_text(text)
    fs = compose_mod.scan_compose_file(f, "test")
    assert any("compose-secret-env" in (x.method or "") for x in fs)


def test_compose_rule_secret_env_var_indirection_no_finding(tmp_path: Path):
    text = textwrap.dedent("""
        services:
          x:
            image: alpine:3.18
            user: "1001"
            environment:
              DATABASE_PASSWORD: ${DB_PASSWORD}
    """)
    f = tmp_path / "docker-compose.yml"
    f.write_text(text)
    fs = compose_mod.scan_compose_file(f, "test")
    assert not any("compose-secret-env" in (x.method or "") for x in fs)


def test_compose_rule_no_user(tmp_path: Path):
    text = textwrap.dedent("""
        services:
          x:
            image: alpine:3.18
    """)
    f = tmp_path / "docker-compose.yml"
    f.write_text(text)
    fs = compose_mod.scan_compose_file(f, "test")
    assert any("compose-no-user" in (x.method or "") for x in fs)


# ── dpkg / apk parsing ─────────────────────────────────────────────────

def test_parse_dpkg_status():
    sample = (
        "Package: libc6\n"
        "Status: install ok installed\n"
        "Architecture: amd64\n"
        "Version: 2.36-9+deb12u4\n"
        "Description: GNU C Library\n"
        "\n"
        "Package: removed-pkg\n"
        "Status: deinstall ok config-files\n"
        "Architecture: amd64\n"
        "Version: 1.0\n"
        "\n"
        "Package: openssl\n"
        "Status: install ok installed\n"
        "Architecture: amd64\n"
        "Version: 3.0.11-1~deb12u2\n"
    )
    pkgs = layers_mod.parse_dpkg_status(sample)
    names = sorted(p.name for p in pkgs)
    assert names == ["libc6", "openssl"]  # 'removed-pkg' excluded


def test_parse_apk_installed():
    sample = (
        "P:musl\n"
        "V:1.2.4_git20230717-r4\n"
        "A:x86_64\n"
        "T:musl libc\n"
        "\n"
        "P:openssl\n"
        "V:3.1.4-r3\n"
        "A:x86_64\n"
    )
    pkgs = layers_mod.parse_apk_installed(sample)
    names = sorted(p.name for p in pkgs)
    assert names == ["musl", "openssl"]
    musl = next(p for p in pkgs if p.name == "musl")
    assert musl.version.startswith("1.2.4")


def test_parse_os_release():
    text = textwrap.dedent("""
        PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"
        NAME="Debian GNU/Linux"
        VERSION_ID="12"
        ID=debian
    """).strip()
    distro, ver = layers_mod.parse_os_release(text)
    assert distro == "debian"
    assert ver == "12"


def test_parse_os_release_alpine():
    text = 'NAME="Alpine Linux"\nID=alpine\nVERSION_ID=3.18.4\n'
    distro, _ = layers_mod.parse_os_release(text)
    assert distro == "alpine"


def test_distro_to_ecosystem():
    assert layers_mod.distro_to_ecosystem("debian") == "Debian"
    assert layers_mod.distro_to_ecosystem("ubuntu") == "Ubuntu"
    assert layers_mod.distro_to_ecosystem("alpine") == "Alpine"
    assert layers_mod.distro_to_ecosystem("rhel") == "Red Hat"
    assert layers_mod.distro_to_ecosystem("nonsense") == ""


# ── Layer tar walk with whiteouts ──────────────────────────────────────

def _make_tar_layer(files: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tf:
        for path, body in files.items():
            info = tarfile.TarInfo(name=path)
            info.size = len(body)
            tf.addfile(info, io.BytesIO(body))
    raw = buf.getvalue()
    return gzip.compress(raw)


def test_walk_layer_extracts_interest_files():
    blob = _make_tar_layer({
        "var/lib/dpkg/status": b"Package: libc6\nStatus: install ok installed\nVersion: 2.0\n",
        "etc/os-release": b'ID=debian\nVERSION_ID="12"\n',
        "usr/bin/some-binary": b"\x00binary",
    })
    files, whiteouts = layers_mod._walk_layer_blob(blob)
    assert "var/lib/dpkg/status" in files
    assert "etc/os-release" in files
    assert "usr/bin/some-binary" not in files  # not in interest set
    assert whiteouts == set()


def test_walk_layer_handles_whiteout():
    # OCI whiteouts: ``<dir>/.wh.<filename>`` marks <dir>/<filename> deleted.
    blob = _make_tar_layer({
        "var/lib/dpkg/.wh.status": b"",
    })
    _, whiteouts = layers_mod._walk_layer_blob(blob)
    assert "var/lib/dpkg/status" in whiteouts


def test_walk_layer_opaque_whiteout():
    # ``.wh..wh..opq`` empties the entire directory at that location.
    blob = _make_tar_layer({
        "etc/.wh..wh..opq": b"",
    })
    _, whiteouts = layers_mod._walk_layer_blob(blob)
    assert any(w.endswith("/*") for w in whiteouts)


# ── End-to-end (offline, no registry) ──────────────────────────────────

def test_end_to_end_dockerfile_only(tmp_path: Path):
    (tmp_path / "Dockerfile").write_text(textwrap.dedent("""
        FROM nginx:latest
        ENV API_TOKEN=tok_abcd1234
        RUN apt-get install -y openssh-server
        EXPOSE 22
    """).strip())
    findings = scan_path(tmp_path, repo_name="t",
                         scan_layers=False, cve_lookup=False)
    rules = {f.rule_id for f in findings}
    assert "df-user-root" in rules
    assert "df-latest-tag" in rules
    assert "df-secret-in-env" in rules
    assert "df-ssh-installed" in rules
    assert "df-expose-sensitive" in rules


def test_end_to_end_compose_only(tmp_path: Path):
    (tmp_path / "docker-compose.yml").write_text(textwrap.dedent("""
        services:
          web:
            image: nginx:latest
            privileged: true
            volumes:
              - /var/run/docker.sock:/var/run/docker.sock
            environment:
              DB_PASSWORD: "production-creds"
    """))
    findings = scan_path(tmp_path, repo_name="t",
                         scan_layers=False, cve_lookup=False)
    rules = {f.rule_id for f in findings}
    assert "compose-privileged" in rules
    assert "compose-docker-sock" in rules
    assert "compose-secret-env" in rules


def test_clean_dockerfile_low_critical_count(tmp_path: Path):
    (tmp_path / "Dockerfile").write_text(textwrap.dedent("""
        FROM nginx:1.25.3@sha256:0d51b0c3d9c0ad3a32c5a7e4e43b3ef0a1234567890abcdef1234567890abcdef
        USER 1001
        HEALTHCHECK --interval=30s CMD curl -f http://localhost/ || exit 1
        EXPOSE 8080
        CMD ["nginx", "-g", "daemon off;"]
    """).strip())
    findings = scan_path(tmp_path, repo_name="clean",
                         scan_layers=False, cve_lookup=False)
    crit_high = [f for f in findings if f.severity in ("critical", "high")]
    assert crit_high == [], f"unexpected critical/high: {[f.title for f in crit_high]}"
