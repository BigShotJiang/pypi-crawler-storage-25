"""Regression tests for the Terraform / IaC security scanner."""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from hiddenshadow import iac
from hiddenshadow.iac import (
    Block, find_tf_files, get_attr, get_bool, get_list,
    get_nested, parse_file, scan_path, unquote,
)


# ── Parser tests ────────────────────────────────────────────────────────

def test_parse_simple_resource(tmp_path: Path):
    f = tmp_path / "main.tf"
    f.write_text(textwrap.dedent('''
        resource "aws_s3_bucket" "logs" {
          bucket = "my-logs"
          acl    = "private"
        }
    '''))
    blocks = parse_file(f)
    assert len(blocks) == 1
    assert blocks[0].kind == "resource"
    assert blocks[0].type == "aws_s3_bucket"
    assert blocks[0].name == "logs"
    assert "bucket" in blocks[0].body


def test_parse_multiple_blocks(tmp_path: Path):
    f = tmp_path / "main.tf"
    f.write_text(textwrap.dedent('''
        resource "aws_s3_bucket" "a" { acl = "private" }
        resource "aws_s3_bucket" "b" { acl = "public-read" }
        data "aws_caller_identity" "c" {}
    '''))
    blocks = parse_file(f)
    types = [(b.kind, b.type, b.name) for b in blocks]
    assert ("resource", "aws_s3_bucket", "a") in types
    assert ("resource", "aws_s3_bucket", "b") in types
    assert ("data", "aws_caller_identity", "c") in types


def test_parse_nested_braces(tmp_path: Path):
    f = tmp_path / "main.tf"
    f.write_text(textwrap.dedent('''
        resource "aws_s3_bucket" "x" {
          tags = {
            Name = "x"
            Env  = "prod"
          }
          versioning {
            enabled = true
          }
        }
    '''))
    blocks = parse_file(f)
    assert len(blocks) == 1
    nested = get_nested(blocks[0].body, "versioning")
    assert nested
    assert get_bool(nested[0], "enabled") is True


def test_parse_tf_json(tmp_path: Path):
    f = tmp_path / "main.tf.json"
    f.write_text(json.dumps({
        "resource": {
            "aws_s3_bucket": {
                "logs": {"acl": "public-read", "bucket": "x"}
            }
        }
    }))
    blocks = parse_file(f)
    assert len(blocks) == 1
    assert blocks[0].type == "aws_s3_bucket"
    assert unquote(get_attr(blocks[0].body, "acl")) == "public-read"


def test_parse_skips_terraform_dir(tmp_path: Path):
    (tmp_path / ".terraform").mkdir()
    inside = tmp_path / ".terraform" / "ignored.tf"
    inside.write_text('resource "aws_s3_bucket" "x" {}')
    outside = tmp_path / "main.tf"
    outside.write_text('resource "aws_s3_bucket" "y" {}')
    files = find_tf_files(tmp_path)
    assert outside in files
    assert inside not in files


def test_attribute_helpers():
    body = textwrap.dedent('''
        enabled = true
        retention = 7
        name = "prod"
        cidrs = ["10.0.0.0/8", "192.168.1.0/24"]
        empty_list = []
        bare = some_var.ref
    ''')
    assert get_bool(body, "enabled") is True
    assert get_attr(body, "retention") == "7"
    assert unquote(get_attr(body, "name")) == "prod"
    assert get_list(body, "cidrs") == ["10.0.0.0/8", "192.168.1.0/24"]
    assert get_list(body, "empty_list") == []
    assert get_list(body, "missing") is None


# ── Helper to run rule scan against a single Block ──────────────────────

def _scan_text(tmp_path: Path, hcl: str, cloud: str = "all"
               ) -> list[iac.IacFinding]:
    f = tmp_path / "main.tf"
    f.write_text(hcl)
    clouds = ("aws", "gcp") if cloud == "all" else (cloud,)
    return scan_path(tmp_path, clouds=clouds)


def _has_rule(findings, rule_id: str) -> bool:
    return any(f.rule_id == rule_id for f in findings)


# ── AWS rule tests ──────────────────────────────────────────────────────

def test_aws_s3_public_acl(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_s3_bucket" "x" {
          bucket = "x"
          acl    = "public-read"
        }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-s3-acl-public")


def test_aws_s3_no_encryption(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_s3_bucket" "x" { bucket = "x" }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-s3-no-encryption")


def test_aws_s3_pab_permissive(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_s3_bucket_public_access_block" "x" {
          bucket = "x"
          block_public_acls = false
        }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-s3-pab-permissive")


def test_aws_sg_world_open_ssh(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_security_group" "x" {
          ingress {
            from_port   = 22
            to_port     = 22
            protocol    = "tcp"
            cidr_blocks = ["0.0.0.0/0"]
          }
        }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-sg-world-open-sensitive")
    # Severity should be high (sensitive port)
    f = next(x for x in fs if x.rule_id == "aws-sg-world-open-sensitive")
    assert f.severity == "high"


def test_aws_sg_all_ports_to_world_is_critical(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_security_group" "x" {
          ingress {
            protocol    = "-1"
            from_port   = 0
            to_port     = 0
            cidr_blocks = ["0.0.0.0/0"]
          }
        }
    ''', cloud="aws")
    f = next(x for x in fs if x.rule_id == "aws-sg-world-open-sensitive")
    assert f.severity == "critical"


def test_aws_iam_wildcard_admin_is_critical(tmp_path: Path):
    # The policy attribute is a JSON string; we just look for Action=* + Resource=*
    fs = _scan_text(tmp_path, '''
        resource "aws_iam_role_policy" "admin" {
          name = "x"
          role = "x"
          policy = "{\\"Statement\\":[{\\"Action\\":\\"*\\",\\"Resource\\":\\"*\\"}]}"
        }
    ''', cloud="aws")
    f = next(x for x in fs if x.rule_id == "aws-iam-role-policy-wildcards")
    assert f.severity == "critical"


def test_aws_rds_public_is_critical(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_db_instance" "x" {
          engine = "postgres"
          publicly_accessible = true
          storage_encrypted = true
        }
    ''', cloud="aws")
    f = next(x for x in fs if x.rule_id == "aws-rds-public")
    assert f.severity == "critical"


def test_aws_rds_unencrypted(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_db_instance" "x" {
          engine = "postgres"
        }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-rds-unencrypted")


def test_aws_ebs_unencrypted(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_ebs_volume" "x" { size = 10 }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-ebs-unencrypted")


def test_aws_instance_no_imdsv2(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_instance" "x" { ami = "ami-x" }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-instance-no-imdsv2")


def test_aws_instance_imdsv2_enforced_no_finding(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_instance" "x" {
          ami = "ami-x"
          metadata_options { http_tokens = "required" }
        }
    ''', cloud="aws")
    assert not _has_rule(fs, "aws-instance-no-imdsv2")


def test_aws_kms_no_rotation(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_kms_key" "x" { description = "x" }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-kms-no-rotation")


def test_aws_eks_public_endpoint(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_eks_cluster" "x" {
          name = "x"
          vpc_config {
            endpoint_public_access = true
          }
        }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-eks-public-endpoint")


def test_aws_lb_cleartext_http(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_lb_listener" "x" {
          protocol = "HTTP"
          port = 80
        }
    ''', cloud="aws")
    assert _has_rule(fs, "aws-lb-listener-no-tls")


def test_aws_lb_http_redirect_no_finding(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "aws_lb_listener" "x" {
          protocol = "HTTP"
          default_action {
            type = "redirect"
            redirect { protocol = "HTTPS" port = "443" }
          }
        }
    ''', cloud="aws")
    assert not _has_rule(fs, "aws-lb-listener-no-tls")


# ── GCP rule tests ──────────────────────────────────────────────────────

def test_gcp_gcs_no_uniform_access(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_storage_bucket" "x" {
          name     = "x"
          location = "US"
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-gcs-no-uniform-access")


def test_gcp_gcs_public_iam_member_is_critical(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_storage_bucket_iam_member" "x" {
          bucket = "x"
          role   = "roles/storage.objectViewer"
          member = "allUsers"
        }
    ''', cloud="gcp")
    f = next(x for x in fs if x.rule_id == "gcp-gcs-public-iam-member")
    assert f.severity == "critical"


def test_gcp_firewall_world_open_ssh(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_compute_firewall" "x" {
          name          = "x"
          source_ranges = ["0.0.0.0/0"]
          allow {
            protocol = "tcp"
            ports    = ["22"]
          }
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-fw-world-open")


def test_gcp_firewall_world_open_all_protocols_critical(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_compute_firewall" "x" {
          name          = "x"
          source_ranges = ["0.0.0.0/0"]
          allow {
            protocol = "all"
          }
        }
    ''', cloud="gcp")
    f = next(x for x in fs if x.rule_id == "gcp-fw-world-open")
    assert f.severity == "critical"


def test_gcp_firewall_restricted_no_finding(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_compute_firewall" "x" {
          name          = "x"
          source_ranges = ["10.0.0.0/8"]
          allow { protocol = "tcp" ports = ["22"] }
        }
    ''', cloud="gcp")
    assert not _has_rule(fs, "gcp-fw-world-open")


def test_gcp_iam_owner_to_allusers_critical(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_project_iam_member" "x" {
          project = "x"
          role    = "roles/owner"
          member  = "allUsers"
        }
    ''', cloud="gcp")
    f = next(x for x in fs if x.rule_id == "gcp-iam-public-member")
    assert f.severity == "critical"


def test_gcp_sa_user_managed_key(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_service_account_key" "x" {
          service_account_id = "x"
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-sa-user-managed-key")


def test_gcp_sql_public_no_authorized(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_sql_database_instance" "x" {
          name = "x"
          settings {
            tier = "db-f1-micro"
            ip_configuration {
              ipv4_enabled = true
            }
          }
        }
    ''', cloud="gcp")
    f = next(x for x in fs if x.rule_id == "gcp-sql-public")
    assert f.severity == "critical"


def test_gcp_sql_authorized_0_0_0_0(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_sql_database_instance" "x" {
          name = "x"
          settings {
            tier = "db-f1-micro"
            ip_configuration {
              ipv4_enabled = true
              authorized_networks {
                value = "0.0.0.0/0"
              }
            }
          }
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-sql-public")


def test_gcp_gke_public_endpoint(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_container_cluster" "x" {
          name = "x"
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-gke-public-endpoint")


def test_gcp_gke_basic_auth_set(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_container_cluster" "x" {
          name = "x"
          master_auth {
            username = "admin"
            password = "hunter2"
          }
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-gke-basic-auth")


def test_gcp_compute_default_sa(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_compute_instance" "x" {
          name = "x"
          machine_type = "n1-standard-1"
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-compute-default-sa")


def test_gcp_kms_no_rotation(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_kms_crypto_key" "x" {
          name     = "x"
          key_ring = "x"
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-kms-no-rotation")


def test_gcp_kms_rotation_too_long(tmp_path: Path):
    fs = _scan_text(tmp_path, '''
        resource "google_kms_crypto_key" "x" {
          name = "x"
          key_ring = "x"
          rotation_period = "31536000s"
        }
    ''', cloud="gcp")
    assert _has_rule(fs, "gcp-kms-no-rotation")
    f = next(x for x in fs if x.rule_id == "gcp-kms-no-rotation")
    assert f.severity == "low"


# ── End-to-end multi-file scan ──────────────────────────────────────────

def test_multifile_repo_scan(tmp_path: Path):
    """A small Terraform module with mixed AWS+GCP resources."""
    (tmp_path / "aws.tf").write_text(textwrap.dedent('''
        resource "aws_s3_bucket" "evil" {
          bucket = "evil"
          acl    = "public-read"
        }
        resource "aws_security_group" "open" {
          ingress {
            from_port   = 3306
            to_port     = 3306
            protocol    = "tcp"
            cidr_blocks = ["0.0.0.0/0"]
          }
        }
    '''))
    (tmp_path / "gcp.tf").write_text(textwrap.dedent('''
        resource "google_storage_bucket_iam_member" "public" {
          bucket = "x"
          role   = "roles/storage.objectViewer"
          member = "allUsers"
        }
        resource "google_container_cluster" "exposed" {
          name = "x"
        }
    '''))
    fs = scan_path(tmp_path, clouds=("aws", "gcp"))
    rule_ids = {f.rule_id for f in fs}
    assert "aws-s3-acl-public" in rule_ids
    assert "aws-sg-world-open-sensitive" in rule_ids
    assert "gcp-gcs-public-iam-member" in rule_ids
    assert "gcp-gke-public-endpoint" in rule_ids
    # Critical findings should be present
    severities = {f.severity for f in fs}
    assert "critical" in severities or "high" in severities


def test_clean_terraform_low_noise(tmp_path: Path):
    """A well-configured AWS module should produce few or no findings."""
    (tmp_path / "clean.tf").write_text(textwrap.dedent('''
        resource "aws_kms_key" "x" {
          enable_key_rotation = true
        }
        resource "aws_db_instance" "x" {
          storage_encrypted   = true
          backup_retention_period = 14
          deletion_protection = true
          publicly_accessible = false
        }
        resource "aws_security_group" "x" {
          ingress {
            from_port   = 443
            to_port     = 443
            protocol    = "tcp"
            cidr_blocks = ["10.0.0.0/8"]
          }
        }
    '''))
    fs = scan_path(tmp_path, clouds=("aws",))
    critical_or_high = [f for f in fs if f.severity in ("critical", "high")]
    assert critical_or_high == []


def test_iac_findings_carry_iac_category(tmp_path: Path):
    (tmp_path / "x.tf").write_text('''
        resource "aws_s3_bucket" "x" {
          bucket = "x"
          acl    = "public-read"
        }
    ''')
    findings = iac.scan_path_as_findings(tmp_path, "myrepo")
    assert findings
    for f in findings:
        assert f.category == "iac"
        assert f.method.startswith("iac:")
        assert f.repo == "myrepo"


def test_rule_counts():
    """Smoke check: rule registry has not regressed below baseline."""
    iac._ensure_rulesets_loaded()
    assert len(iac.get_rules("aws")) >= 40
    assert len(iac.get_rules("gcp")) >= 30
