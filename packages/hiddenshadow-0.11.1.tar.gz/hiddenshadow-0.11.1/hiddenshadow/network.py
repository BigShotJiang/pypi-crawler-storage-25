"""Shared HTTP client with on-disk cache + concurrency.

Used by registry.py (license lookups via deps.dev) and osv.py (CVE
lookups via osv.dev). Stdlib-only — no requests/httpx dependency.

Cache layout:
    <cache_dir>/<service>/<sha256-of-key>.json

Cache entries are JSON: {"key": "...", "fetched_at": "...", "data": {...},
"status": 200}. Negative responses (404, error) are also cached so re-runs
don't re-hammer.
"""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from threading import Lock
from typing import Any, Callable, Iterable

USER_AGENT = "hiddenshadow/0.2.0 (+internal)"


@dataclass
class HttpResult:
    status: int
    data: Any
    error: str = ""


@dataclass
class FetchStats:
    requested: int = 0
    cache_hit: int = 0
    cache_miss: int = 0
    cache_expired: int = 0
    success: int = 0
    not_found: int = 0
    errors: int = 0
    bytes_received: int = 0
    elapsed_s: float = 0.0


# Per-service cache TTL defaults (seconds). Negative responses get a
# shorter TTL so a transient 5xx doesn't poison the cache for the full
# success window. Override per-instance via the ttl_seconds kwarg.
_DEFAULT_TTL_BY_SERVICE: dict[str, int] = {
    "osv":            24 * 3600,        # CVE data — refresh daily
    "osv-container":  24 * 3600,
    "depsdev":        7 * 24 * 3600,    # license / version metadata — weekly
    "signatures":     24 * 3600,        # publisher metadata + Rekor lookups
}
_DEFAULT_TTL_FALLBACK = 24 * 3600
_NEGATIVE_TTL = 6 * 3600                # 404 / error responses


class CachedHttp:
    """Thread-safe HTTP client with disk cache and concurrency control."""

    def __init__(self, cache_dir: Path, *, service: str, max_workers: int = 8,
                 request_timeout: float = 10.0, request_delay_ms: int = 50,
                 ttl_seconds: int | None = None,
                 refresh: bool = False):
        self.cache_dir = cache_dir / service
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.service = service
        self.max_workers = max_workers
        self.request_timeout = request_timeout
        self.request_delay_ms = request_delay_ms
        # TTL precedence: explicit kwarg > per-service default > fallback.
        self.ttl_seconds = (
            ttl_seconds
            if ttl_seconds is not None
            else _DEFAULT_TTL_BY_SERVICE.get(service, _DEFAULT_TTL_FALLBACK)
        )
        self.refresh = refresh   # when True, ignore disk cache (still writes)
        self.stats = FetchStats()
        self._lock = Lock()
        self._last_request_time = 0.0

    def _cache_path(self, key: str) -> Path:
        h = hashlib.sha256(key.encode("utf-8")).hexdigest()[:32]
        return self.cache_dir / f"{h}.json"

    def _is_expired(self, fetched_at: float, status: int) -> bool:
        """Has this cache entry passed its TTL?"""
        ttl = (
            _NEGATIVE_TTL
            if status != 200 and self.ttl_seconds > _NEGATIVE_TTL
            else self.ttl_seconds
        )
        return (time.time() - fetched_at) > ttl

    def _read_cache(self, key: str) -> HttpResult | None:
        if self.refresh:
            return None
        cp = self._cache_path(key)
        if not cp.exists():
            return None
        try:
            d = json.loads(cp.read_text(encoding="utf-8"))
        except Exception:
            return None
        fetched_at = d.get("fetched_at", 0.0)
        status = d.get("status", 0)
        if self._is_expired(fetched_at, status):
            with self._lock:
                self.stats.cache_expired += 1
            return None
        return HttpResult(status=status, data=d.get("data"),
                          error=d.get("error", ""))

    def _write_cache(self, key: str, result: HttpResult) -> None:
        cp = self._cache_path(key)
        cp.write_text(json.dumps({
            "key": key, "fetched_at": time.time(),
            "status": result.status, "data": result.data,
            "error": result.error,
        }), encoding="utf-8")

    def _throttle(self) -> None:
        with self._lock:
            now = time.time()
            since_last = (now - self._last_request_time) * 1000
            if since_last < self.request_delay_ms:
                time.sleep((self.request_delay_ms - since_last) / 1000)
            self._last_request_time = time.time()

    def _do_request(self, url: str, *, method: str = "GET",
                    body: bytes | None = None,
                    headers: dict[str, str] | None = None) -> HttpResult:
        self._throttle()
        req_headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        if headers:
            req_headers.update(headers)
        if body is not None:
            req_headers.setdefault("Content-Type", "application/json")
        req = urllib.request.Request(url, data=body, headers=req_headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.request_timeout) as resp:
                raw = resp.read()
                with self._lock:
                    self.stats.bytes_received += len(raw)
                try:
                    data = json.loads(raw.decode("utf-8"))
                except Exception:
                    data = None
                return HttpResult(status=resp.status, data=data)
        except urllib.error.HTTPError as e:
            return HttpResult(status=e.code, data=None,
                              error=f"HTTP {e.code}: {e.reason}")
        except urllib.error.URLError as e:
            return HttpResult(status=0, data=None, error=f"URL error: {e.reason}")
        except Exception as e:
            return HttpResult(status=0, data=None, error=f"{type(e).__name__}: {e}")

    def fetch(self, key: str, url: str, *, method: str = "GET",
              body: dict | None = None,
              headers: dict[str, str] | None = None) -> HttpResult:
        """Fetch a single URL with caching. `key` is the cache key (usually url)."""
        with self._lock:
            self.stats.requested += 1
        cached = self._read_cache(key)
        if cached is not None:
            with self._lock:
                self.stats.cache_hit += 1
                if cached.status == 200:
                    self.stats.success += 1
                elif cached.status == 404:
                    self.stats.not_found += 1
                else:
                    self.stats.errors += 1
            return cached
        with self._lock:
            self.stats.cache_miss += 1
        body_bytes = json.dumps(body).encode("utf-8") if body is not None else None
        result = self._do_request(url, method=method, body=body_bytes, headers=headers)
        self._write_cache(key, result)
        with self._lock:
            if result.status == 200:
                self.stats.success += 1
            elif result.status == 404:
                self.stats.not_found += 1
            else:
                self.stats.errors += 1
        return result

    def fetch_many(self, items: Iterable[tuple[str, str, dict | None]],
                   *, progress: Callable[[int, int], None] | None = None,
                   ) -> dict[str, HttpResult]:
        """Fetch many URLs concurrently. Items are (key, url, body) tuples.

        Returns {key: HttpResult}.
        """
        items_list = list(items)
        results: dict[str, HttpResult] = {}
        started = time.time()
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as ex:
            futures = {
                ex.submit(self.fetch, key, url,
                          method="POST" if body is not None else "GET",
                          body=body): key
                for key, url, body in items_list
            }
            done = 0
            for fut in concurrent.futures.as_completed(futures):
                key = futures[fut]
                try:
                    results[key] = fut.result()
                except Exception as e:
                    results[key] = HttpResult(status=0, data=None,
                                              error=str(e))
                done += 1
                if progress and done % 50 == 0:
                    progress(done, len(items_list))
        with self._lock:
            self.stats.elapsed_s = time.time() - started
        if progress:
            progress(len(items_list), len(items_list))
        return results
