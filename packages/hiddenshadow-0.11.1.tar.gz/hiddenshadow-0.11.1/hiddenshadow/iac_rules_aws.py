"""AWS Terraform security rules.

Each rule is registered against a specific ``aws_*`` resource type and
returns a :class:`CheckResult` when the configuration is insecure.

References are CIS AWS Foundations Benchmark sections (CIS-AWS) and
AWS Security Hub control IDs where applicable.
"""
from __future__ import annotations

import re

from .iac import (
    Block, CheckResult, fail, register,
    get_attr, get_bool, get_list, get_nested, unquote,
)


# ────────────────────────────────────────────────────────────────────────
# S3
# ────────────────────────────────────────────────────────────────────────

@register("aws", "aws_s3_bucket", "aws-s3-acl-public")
def s3_acl_public(b: Block) -> CheckResult | None:
    acl = unquote(get_attr(b.body, "acl"))
    if acl in ("public-read", "public-read-write", "authenticated-read"):
        return fail(
            "aws-s3-acl-public", "high",
            f"S3 bucket uses public ACL '{acl}'",
            f"The bucket ACL is set to '{acl}', which exposes the bucket "
            f"to the public Internet.",
            "Set acl = \"private\" and use an explicit bucket policy / "
            "aws_s3_bucket_public_access_block to gate any sharing.",
            "CIS-AWS 2.1.5",
        )
    return None


@register("aws", "aws_s3_bucket_acl", "aws-s3-bucket-acl-public")
def s3_bucket_acl_public(b: Block) -> CheckResult | None:
    acl = unquote(get_attr(b.body, "acl"))
    if acl in ("public-read", "public-read-write", "authenticated-read"):
        return fail(
            "aws-s3-bucket-acl-public", "high",
            f"S3 bucket ACL resource grants '{acl}'",
            f"aws_s3_bucket_acl is set to '{acl}', exposing bucket contents.",
            "Use 'private' and rely on explicit IAM policies for sharing.",
        )
    return None


@register("aws", "aws_s3_bucket", "aws-s3-no-encryption")
def s3_no_encryption(b: Block) -> CheckResult | None:
    if "server_side_encryption_configuration" not in b.body \
       and "aws_s3_bucket_server_side_encryption_configuration" not in b.body:
        return fail(
            "aws-s3-no-encryption", "high",
            "S3 bucket has no server-side encryption configured",
            "No server_side_encryption_configuration block is present on this "
            "bucket. Objects will be stored unencrypted unless the writer "
            "opts in.",
            "Add an aws_s3_bucket_server_side_encryption_configuration "
            "resource (or inline block) with sse_algorithm AES256 or "
            "aws:kms.",
            "CIS-AWS 2.1.1",
        )
    return None


@register("aws", "aws_s3_bucket", "aws-s3-no-versioning")
def s3_no_versioning(b: Block) -> CheckResult | None:
    nested = get_nested(b.body, "versioning")
    if not nested:
        # Could be in a sibling aws_s3_bucket_versioning resource - that's
        # fine; we can't be sure here. Emit info-level pointer.
        return fail(
            "aws-s3-no-versioning", "low",
            "S3 bucket has no inline versioning block",
            "Couldn't confirm versioning is enabled. If a sibling "
            "aws_s3_bucket_versioning resource exists this can be ignored.",
            "Enable versioning to recover from accidental deletes and "
            "ransomware encryption.",
            "CIS-AWS 2.1.3",
        )
    enabled = get_bool(nested[0], "enabled")
    if enabled is False:
        return fail(
            "aws-s3-no-versioning", "medium",
            "S3 bucket versioning explicitly disabled",
            "Versioning is set to false on this bucket.",
            "Set versioning.enabled = true.",
            "CIS-AWS 2.1.3",
        )
    return None


@register("aws", "aws_s3_bucket_versioning", "aws-s3-versioning-disabled")
def s3_versioning_resource_disabled(b: Block) -> CheckResult | None:
    nested = get_nested(b.body, "versioning_configuration")
    for body in nested:
        status = unquote(get_attr(body, "status"))
        if status and status not in ("Enabled", "Suspended"):
            continue
        if status == "Suspended" or status is None:
            return fail(
                "aws-s3-versioning-disabled", "medium",
                "S3 bucket versioning not Enabled",
                f"Versioning status is '{status or 'not set'}'.",
                "Set versioning_configuration.status = \"Enabled\".",
            )
    return None


@register("aws", "aws_s3_bucket_public_access_block", "aws-s3-pab-permissive")
def s3_pab_permissive(b: Block) -> CheckResult | None:
    weak = []
    for key in ("block_public_acls", "block_public_policy",
                "ignore_public_acls", "restrict_public_buckets"):
        val = get_bool(b.body, key)
        if val is False:
            weak.append(key)
    if weak:
        return fail(
            "aws-s3-pab-permissive", "high",
            "S3 public access block is permissive",
            f"The following public-access controls are explicitly false: "
            f"{', '.join(weak)}.",
            "Set all four block flags to true unless the bucket genuinely "
            "needs to host public content (in which case scope via IAM/CDN).",
            "CIS-AWS 2.1.5",
        )
    return None


@register("aws", "aws_s3_bucket", "aws-s3-no-logging")
def s3_no_logging(b: Block) -> CheckResult | None:
    if "logging" not in b.body \
       and "aws_s3_bucket_logging" not in b.body:
        return fail(
            "aws-s3-no-logging", "medium",
            "S3 bucket has no access logging configured",
            "No logging block or sibling aws_s3_bucket_logging resource "
            "found. Bucket access events will not be recorded.",
            "Add aws_s3_bucket_logging pointing at a dedicated logs bucket.",
            "CIS-AWS 2.1.2",
        )
    return None


@register("aws", "aws_s3_bucket", "aws-s3-mfa-delete")
def s3_no_mfa_delete(b: Block) -> CheckResult | None:
    nested = get_nested(b.body, "versioning")
    if nested:
        mfa = get_bool(nested[0], "mfa_delete")
        if mfa is False:
            return fail(
                "aws-s3-mfa-delete", "low",
                "S3 versioning has MFA delete disabled",
                "Object deletion does not require MFA on this bucket.",
                "For buckets holding production data, set mfa_delete = true "
                "and protect the root account with hardware MFA.",
            )
    return None


# ────────────────────────────────────────────────────────────────────────
# EC2 / EBS / VPC
# ────────────────────────────────────────────────────────────────────────

_SENSITIVE_PORTS = {
    22:    "SSH",
    23:    "Telnet",
    135:   "RPC",
    137:   "NetBIOS",
    139:   "SMB",
    445:   "SMB",
    1433:  "MSSQL",
    1521:  "Oracle DB",
    2375:  "Docker daemon",
    2376:  "Docker TLS",
    3306:  "MySQL",
    3389:  "RDP",
    5432:  "PostgreSQL",
    5601:  "Kibana",
    5984:  "CouchDB",
    6379:  "Redis",
    7474:  "Neo4j",
    8086:  "InfluxDB",
    9000:  "Portainer",
    9092:  "Kafka",
    9200:  "Elasticsearch",
    9300:  "Elasticsearch",
    11211: "Memcached",
    27017: "MongoDB",
    50070: "Hadoop NameNode",
}


def _world_open(cidrs: list[str] | None) -> bool:
    if not cidrs:
        return False
    return any(c in ("0.0.0.0/0", "::/0") for c in cidrs)


def _check_open_port(body: str) -> tuple[bool, int, int, str]:
    """Return (world_open, from_port, to_port, protocol) for a single rule body."""
    cidrs = get_list(body, "cidr_blocks") or []
    cidrs6 = get_list(body, "ipv6_cidr_blocks") or []
    open_ = _world_open(cidrs + cidrs6)
    if not open_:
        return False, 0, 0, ""
    try:
        fp = int(unquote(get_attr(body, "from_port")) or "0")
        tp = int(unquote(get_attr(body, "to_port")) or "0")
    except (TypeError, ValueError):
        fp, tp = 0, 0
    proto = unquote(get_attr(body, "protocol")) or ""
    return True, fp, tp, proto


@register("aws", "aws_security_group", "aws-sg-world-open-sensitive")
def sg_world_open(b: Block) -> CheckResult | None:
    ingress_blocks = get_nested(b.body, "ingress")
    exposed: list[str] = []
    for ing in ingress_blocks:
        open_, fp, tp, proto = _check_open_port(ing)
        if not open_:
            continue
        if proto in ("-1", "all"):
            exposed.append("ALL PORTS")
            continue
        for port, name in _SENSITIVE_PORTS.items():
            if fp <= port <= tp:
                exposed.append(f"{port}/{name}")
    if exposed:
        sev = "critical" if "ALL PORTS" in exposed else "high"
        return fail(
            "aws-sg-world-open-sensitive", sev,
            "Security group exposes sensitive ports to 0.0.0.0/0",
            f"Ingress allows traffic from anywhere to: "
            f"{', '.join(sorted(set(exposed)))}.",
            "Restrict cidr_blocks to a specific corporate / VPN range, or "
            "front the workload with a bastion / SSM Session Manager.",
            "CIS-AWS 5.2",
        )
    return None


@register("aws", "aws_security_group_rule", "aws-sgr-world-open")
def sgr_world_open(b: Block) -> CheckResult | None:
    type_ = unquote(get_attr(b.body, "type"))
    if type_ != "ingress":
        return None
    open_, fp, tp, proto = _check_open_port(b.body)
    if not open_:
        return None
    if proto in ("-1", "all"):
        return fail(
            "aws-sgr-world-open", "critical",
            "Security group rule opens ALL ports to 0.0.0.0/0",
            "An ingress rule allows protocol = -1 (all) from anywhere.",
            "Replace with explicit per-port rules and CIDR-scoped sources.",
            "CIS-AWS 5.2",
        )
    for port, name in _SENSITIVE_PORTS.items():
        if fp <= port <= tp:
            return fail(
                "aws-sgr-world-open", "high",
                f"Security group rule opens {port}/{name} to 0.0.0.0/0",
                f"Port {port} ({name}) is reachable from any source IP.",
                "Restrict cidr_blocks to a trusted range.",
                "CIS-AWS 5.2",
            )
    return None


@register("aws", "aws_default_security_group", "aws-default-sg-permissive")
def default_sg_permissive(b: Block) -> CheckResult | None:
    if get_nested(b.body, "ingress") or get_nested(b.body, "egress"):
        return fail(
            "aws-default-sg-permissive", "medium",
            "Default security group has rules attached",
            "The default VPC security group should deny all traffic; "
            "ingress / egress rules on it imply it is being used as a "
            "real SG.",
            "Leave aws_default_security_group with no ingress/egress blocks; "
            "create a named aws_security_group for actual workloads.",
            "CIS-AWS 5.3",
        )
    return None


@register("aws", "aws_ebs_volume", "aws-ebs-unencrypted")
def ebs_unencrypted(b: Block) -> CheckResult | None:
    enc = get_bool(b.body, "encrypted")
    if enc is False or enc is None:
        return fail(
            "aws-ebs-unencrypted", "high",
            "EBS volume is not encrypted",
            "encrypted is not explicitly true on this volume.",
            "Set encrypted = true and (recommended) kms_key_id to a "
            "customer-managed CMK.",
            "CIS-AWS 2.2.1",
        )
    return None


@register("aws", "aws_ebs_snapshot", "aws-ebs-snapshot-unencrypted")
def ebs_snapshot_unencrypted(b: Block) -> CheckResult | None:
    enc = get_bool(b.body, "encrypted")
    if enc is False:
        return fail(
            "aws-ebs-snapshot-unencrypted", "high",
            "EBS snapshot is not encrypted",
            "encrypted = false on this snapshot.",
            "Set encrypted = true.",
        )
    return None


@register("aws", "aws_instance", "aws-instance-no-imdsv2")
def instance_no_imdsv2(b: Block) -> CheckResult | None:
    nested = get_nested(b.body, "metadata_options")
    if not nested:
        return fail(
            "aws-instance-no-imdsv2", "high",
            "EC2 instance does not require IMDSv2",
            "No metadata_options block found; instance defaults to IMDSv1 "
            "which is exploitable via SSRF.",
            "Add metadata_options { http_tokens = \"required\" } to "
            "enforce IMDSv2.",
            "CIS-AWS 5.6",
        )
    http_tokens = unquote(get_attr(nested[0], "http_tokens"))
    if http_tokens != "required":
        return fail(
            "aws-instance-no-imdsv2", "high",
            "EC2 instance metadata service allows IMDSv1",
            f"metadata_options.http_tokens is '{http_tokens or 'unset'}', "
            f"not 'required'.",
            "Set http_tokens = \"required\" to enforce IMDSv2.",
            "CIS-AWS 5.6",
        )
    return None


@register("aws", "aws_instance", "aws-instance-public-ip")
def instance_public_ip(b: Block) -> CheckResult | None:
    if get_bool(b.body, "associate_public_ip_address") is True:
        return fail(
            "aws-instance-public-ip", "medium",
            "EC2 instance is launched with a public IP",
            "associate_public_ip_address = true exposes the instance to "
            "the Internet directly.",
            "Place workloads in private subnets behind an ALB / NAT gateway "
            "and reach them via Session Manager.",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# IAM
# ────────────────────────────────────────────────────────────────────────

_WILDCARD_RE = re.compile(r'"\*"|"[^"]*\*[^"]*"')


def _iam_doc_text(b: Block) -> str:
    """Return text of any embedded IAM policy document on this block.

    Falls back to the full block body so we still see policies that
    were declared via a sibling ``data.aws_iam_policy_document`` block
    that's been inlined into the same file.
    """
    parts: list[str] = [b.body]
    for key in ("policy", "assume_role_policy"):
        v = get_attr(b.body, key)
        if v:
            unwrapped = unquote(v) or ""
            # Strip HCL-level escape backslashes ("\"Action\"" -> "Action")
            parts.append(unwrapped.replace('\\"', '"'))
    return "\n".join(parts)


def _has_action_resource_wildcard(text: str) -> tuple[bool, bool]:
    """Heuristic: look for Action='*' and Resource='*' in any IAM doc form.

    Tolerates both the JSON-policy form (``"Action": "*"``) and the
    HCL data.aws_iam_policy_document form (``actions = ["*"]``).
    """
    # JSON policy form
    json_action = (re.search(r'"Action"\s*:\s*"\*"', text)
                   or re.search(r'"Action"\s*:\s*\[\s*"\*"', text))
    json_resource = (re.search(r'"Resource"\s*:\s*"\*"', text)
                     or re.search(r'"Resource"\s*:\s*\[\s*"\*"', text))
    # HCL policy-document form
    hcl_action = re.search(r'\bactions\s*=\s*\[\s*"\*"\s*\]', text)
    hcl_resource = re.search(r'\bresources\s*=\s*\[\s*"\*"\s*\]', text)
    return (bool(json_action or hcl_action),
            bool(json_resource or hcl_resource))


def _check_iam_wildcards(b: Block, rule_id: str) -> CheckResult | None:
    text = _iam_doc_text(b) or b.body
    action_star, resource_star = _has_action_resource_wildcard(text)
    if action_star and resource_star:
        return fail(
            rule_id, "critical",
            "IAM policy grants Action='*' on Resource='*'",
            "This is an unrestricted admin grant. Any principal attached "
            "to it can perform any operation on any resource.",
            "Scope Action and Resource to the minimum the workload needs. "
            "Use IAM Access Analyzer to discover what is actually used.",
            "CIS-AWS 1.16",
        )
    if action_star:
        return fail(
            rule_id, "high",
            "IAM policy grants wildcard Action='*'",
            "All AWS API actions are permitted on the listed resources.",
            "Replace '*' with the specific actions the workload calls.",
            "CIS-AWS 1.16",
        )
    if resource_star:
        return fail(
            rule_id, "medium",
            "IAM policy grants Resource='*' on a specific Action",
            "The action(s) are permitted on every resource of that type. "
            "For data services (S3, DynamoDB, KMS) this can leak data.",
            "Scope Resource to specific ARNs.",
            "CIS-AWS 1.16",
        )
    return None


@register("aws", "aws_iam_policy", "aws-iam-policy-wildcards")
def iam_policy_wildcards(b: Block) -> CheckResult | None:
    return _check_iam_wildcards(b, "aws-iam-policy-wildcards")


@register("aws", "aws_iam_role_policy", "aws-iam-role-policy-wildcards")
def iam_role_policy_wildcards(b: Block) -> CheckResult | None:
    return _check_iam_wildcards(b, "aws-iam-role-policy-wildcards")


@register("aws", "aws_iam_user_policy", "aws-iam-user-policy-wildcards")
def iam_user_policy_wildcards(b: Block) -> CheckResult | None:
    return _check_iam_wildcards(b, "aws-iam-user-policy-wildcards")


@register("aws", "aws_iam_group_policy", "aws-iam-group-policy-wildcards")
def iam_group_policy_wildcards(b: Block) -> CheckResult | None:
    return _check_iam_wildcards(b, "aws-iam-group-policy-wildcards")


@register("aws", "aws_iam_access_key", "aws-iam-user-access-key")
def iam_access_key(b: Block) -> CheckResult | None:
    return fail(
        "aws-iam-user-access-key", "medium",
        "Long-lived IAM user access key declared in Terraform",
        "aws_iam_access_key creates a static access key. These are the "
        "credentials most commonly leaked in GitHub commits and used in "
        "real intrusions.",
        "Replace with IAM roles + STS / IAM Identity Center / GitHub OIDC. "
        "If a user-bound key is unavoidable, set it to rotate via "
        "Secrets Manager.",
        "CIS-AWS 1.4",
    )


@register("aws", "aws_iam_account_password_policy",
          "aws-iam-pwd-policy-weak")
def iam_password_policy_weak(b: Block) -> CheckResult | None:
    issues: list[str] = []
    try:
        min_len = int(unquote(get_attr(b.body, "minimum_password_length")) or "0")
    except (TypeError, ValueError):
        min_len = 0
    if min_len and min_len < 14:
        issues.append(f"minimum_password_length={min_len} (<14)")
    for key, expected, label in (
        ("require_uppercase_characters", True, "uppercase"),
        ("require_lowercase_characters", True, "lowercase"),
        ("require_numbers", True, "numbers"),
        ("require_symbols", True, "symbols"),
        ("allow_users_to_change_password", True, "user-change"),
    ):
        if get_bool(b.body, key) is False:
            issues.append(f"{key}={expected!s}")
    try:
        reuse = int(unquote(get_attr(b.body, "password_reuse_prevention")) or "0")
    except (TypeError, ValueError):
        reuse = 0
    if reuse and reuse < 24:
        issues.append(f"password_reuse_prevention={reuse} (<24)")
    if issues:
        return fail(
            "aws-iam-pwd-policy-weak", "medium",
            "IAM account password policy weaker than CIS baseline",
            "; ".join(issues),
            "Match the CIS AWS Foundations password baseline: ≥14 chars, "
            "all character classes required, reuse prevention 24, max age 90.",
            "CIS-AWS 1.8-1.11",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# RDS / Aurora
# ────────────────────────────────────────────────────────────────────────

@register("aws", "aws_db_instance", "aws-rds-unencrypted")
def rds_unencrypted(b: Block) -> CheckResult | None:
    if get_bool(b.body, "storage_encrypted") is not True:
        return fail(
            "aws-rds-unencrypted", "high",
            "RDS instance does not have storage encryption enabled",
            "storage_encrypted is not true. Backups and snapshots will "
            "also be unencrypted.",
            "Set storage_encrypted = true and ideally kms_key_id to a "
            "customer-managed CMK.",
            "CIS-AWS 2.3.1",
        )
    return None


@register("aws", "aws_db_instance", "aws-rds-public")
def rds_public(b: Block) -> CheckResult | None:
    if get_bool(b.body, "publicly_accessible") is True:
        return fail(
            "aws-rds-public", "critical",
            "RDS instance is publicly accessible",
            "publicly_accessible = true. The DB endpoint is reachable from "
            "the Internet.",
            "Set publicly_accessible = false and reach the DB via the VPC.",
            "CIS-AWS 2.3.3",
        )
    return None


@register("aws", "aws_db_instance", "aws-rds-no-backup")
def rds_no_backup(b: Block) -> CheckResult | None:
    try:
        ret = int(unquote(get_attr(b.body, "backup_retention_period")) or "0")
    except (TypeError, ValueError):
        ret = 0
    if ret == 0:
        return fail(
            "aws-rds-no-backup", "medium",
            "RDS instance has backups disabled",
            "backup_retention_period = 0 disables automated backups.",
            "Set backup_retention_period ≥ 7 (CIS recommends 7 days).",
            "CIS-AWS 2.3.2",
        )
    return None


@register("aws", "aws_db_instance", "aws-rds-no-deletion-protection")
def rds_no_deletion_protection(b: Block) -> CheckResult | None:
    if get_bool(b.body, "deletion_protection") is not True:
        return fail(
            "aws-rds-no-deletion-protection", "medium",
            "RDS instance deletion protection disabled",
            "deletion_protection is not true; the database can be deleted "
            "with a single terraform destroy.",
            "Set deletion_protection = true on production databases.",
        )
    return None


@register("aws", "aws_rds_cluster", "aws-rds-cluster-unencrypted")
def rds_cluster_unencrypted(b: Block) -> CheckResult | None:
    if get_bool(b.body, "storage_encrypted") is not True:
        return fail(
            "aws-rds-cluster-unencrypted", "high",
            "Aurora cluster storage encryption not enabled",
            "storage_encrypted is not true.",
            "Set storage_encrypted = true and use a CMK.",
            "CIS-AWS 2.3.1",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# VPC / Networking
# ────────────────────────────────────────────────────────────────────────

@register("aws", "aws_vpc", "aws-vpc-no-flow-logs")
def vpc_no_flow_logs(b: Block) -> CheckResult | None:
    return fail(
        "aws-vpc-no-flow-logs", "low",
        "VPC defined without an explicit aws_flow_log resource nearby",
        "VPCs need flow logs for incident response. We can't tell from the "
        "VPC block alone whether a sibling aws_flow_log exists - confirm "
        "manually.",
        "Add aws_flow_log { vpc_id = aws_vpc.this.id, traffic_type = "
        "\"ALL\", log_destination_type = \"cloud-watch-logs\" }.",
        "CIS-AWS 3.9",
    )


@register("aws", "aws_lb", "aws-lb-no-deletion-protection")
def lb_no_deletion_protection(b: Block) -> CheckResult | None:
    if get_bool(b.body, "enable_deletion_protection") is not True:
        return fail(
            "aws-lb-no-deletion-protection", "low",
            "Load balancer deletion protection not enabled",
            "enable_deletion_protection is not true.",
            "Set enable_deletion_protection = true for production load "
            "balancers.",
        )
    return None


@register("aws", "aws_lb_listener", "aws-lb-listener-no-tls")
def lb_listener_no_tls(b: Block) -> CheckResult | None:
    proto = unquote(get_attr(b.body, "protocol"))
    if proto in ("HTTP", "TCP"):
        # Allow if it's redirecting to HTTPS (default_action.type = "redirect")
        if 'type = "redirect"' in b.body and 'protocol = "HTTPS"' in b.body:
            return None
        return fail(
            "aws-lb-listener-no-tls", "high",
            f"Load balancer listener uses cleartext {proto}",
            f"Listener protocol is {proto}; traffic is not encrypted.",
            "Use protocol = \"HTTPS\" (ALB) or \"TLS\" (NLB) with a valid "
            "ACM certificate; redirect HTTP→HTTPS.",
            "CIS-AWS 4.x",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# KMS
# ────────────────────────────────────────────────────────────────────────

@register("aws", "aws_kms_key", "aws-kms-no-rotation")
def kms_no_rotation(b: Block) -> CheckResult | None:
    if get_bool(b.body, "enable_key_rotation") is not True:
        return fail(
            "aws-kms-no-rotation", "medium",
            "KMS key has automatic rotation disabled",
            "enable_key_rotation is not true. Customer-managed keys should "
            "rotate at least annually.",
            "Set enable_key_rotation = true.",
            "CIS-AWS 3.8",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# Lambda
# ────────────────────────────────────────────────────────────────────────

@register("aws", "aws_lambda_function", "aws-lambda-env-unencrypted")
def lambda_env_unencrypted(b: Block) -> CheckResult | None:
    envs = get_nested(b.body, "environment")
    if envs and "kms_key_arn" not in b.body:
        return fail(
            "aws-lambda-env-unencrypted", "medium",
            "Lambda environment variables not encrypted with CMK",
            "Function has environment variables but no kms_key_arn is set; "
            "AWS uses an account-default key.",
            "Set kms_key_arn to a customer-managed CMK to bind decrypt "
            "permission to specific principals.",
        )
    return None


@register("aws", "aws_lambda_function", "aws-lambda-no-tracing")
def lambda_no_tracing(b: Block) -> CheckResult | None:
    nested = get_nested(b.body, "tracing_config")
    if not nested:
        return fail(
            "aws-lambda-no-tracing", "low",
            "Lambda function has no X-Ray tracing configured",
            "Missing tracing_config block.",
            "Add tracing_config { mode = \"Active\" } so request traces are "
            "available for incident analysis.",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# CloudTrail
# ────────────────────────────────────────────────────────────────────────

@register("aws", "aws_cloudtrail", "aws-cloudtrail-no-encryption")
def cloudtrail_no_encryption(b: Block) -> CheckResult | None:
    if not get_attr(b.body, "kms_key_id"):
        return fail(
            "aws-cloudtrail-no-encryption", "medium",
            "CloudTrail logs not encrypted with a CMK",
            "kms_key_id is not set; logs are encrypted with the AWS-managed "
            "default key, which can be read by any principal with "
            "kms:Decrypt on the default key.",
            "Set kms_key_id to a customer-managed CMK with a key policy "
            "that restricts who can decrypt trail logs.",
            "CIS-AWS 3.7",
        )
    return None


@register("aws", "aws_cloudtrail", "aws-cloudtrail-single-region")
def cloudtrail_single_region(b: Block) -> CheckResult | None:
    if get_bool(b.body, "is_multi_region_trail") is not True:
        return fail(
            "aws-cloudtrail-single-region", "medium",
            "CloudTrail is not multi-region",
            "is_multi_region_trail is not true; API calls in other regions "
            "won't be captured.",
            "Set is_multi_region_trail = true.",
            "CIS-AWS 3.1",
        )
    return None


@register("aws", "aws_cloudtrail", "aws-cloudtrail-no-log-validation")
def cloudtrail_no_log_validation(b: Block) -> CheckResult | None:
    if get_bool(b.body, "enable_log_file_validation") is not True:
        return fail(
            "aws-cloudtrail-no-log-validation", "low",
            "CloudTrail log file validation disabled",
            "enable_log_file_validation is not true; tampered logs cannot "
            "be detected.",
            "Set enable_log_file_validation = true.",
            "CIS-AWS 3.2",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# DynamoDB, ECR, EKS, SQS, SNS, Redshift, ElastiCache, Secrets Manager
# ────────────────────────────────────────────────────────────────────────

@register("aws", "aws_dynamodb_table", "aws-dynamodb-no-encryption")
def dynamodb_no_encryption(b: Block) -> CheckResult | None:
    sse = get_nested(b.body, "server_side_encryption")
    if not sse:
        return fail(
            "aws-dynamodb-no-encryption", "low",
            "DynamoDB table uses AWS-owned key encryption",
            "No server_side_encryption block; the table uses an AWS-owned "
            "key whose deletion can affect data recovery.",
            "Add server_side_encryption { enabled = true, kms_key_arn = ... }"
            " with a customer-managed CMK.",
        )
    return None


@register("aws", "aws_dynamodb_table", "aws-dynamodb-no-pitr")
def dynamodb_no_pitr(b: Block) -> CheckResult | None:
    pitr = get_nested(b.body, "point_in_time_recovery")
    if not pitr:
        return fail(
            "aws-dynamodb-no-pitr", "low",
            "DynamoDB table has no point-in-time recovery",
            "Missing point_in_time_recovery block.",
            "Add point_in_time_recovery { enabled = true }.",
        )
    return None


@register("aws", "aws_ecr_repository", "aws-ecr-no-scan")
def ecr_no_scan(b: Block) -> CheckResult | None:
    scan = get_nested(b.body, "image_scanning_configuration")
    if not scan or get_bool(scan[0], "scan_on_push") is not True:
        return fail(
            "aws-ecr-no-scan", "medium",
            "ECR repository does not scan images on push",
            "image_scanning_configuration.scan_on_push is not true. Newly "
            "published images won't be scanned for known CVEs.",
            "Set image_scanning_configuration { scan_on_push = true }.",
        )
    return None


@register("aws", "aws_ecr_repository", "aws-ecr-tag-mutable")
def ecr_tag_mutable(b: Block) -> CheckResult | None:
    mut = unquote(get_attr(b.body, "image_tag_mutability"))
    if mut and mut != "IMMUTABLE":
        return fail(
            "aws-ecr-tag-mutable", "low",
            "ECR repository allows mutable image tags",
            f"image_tag_mutability is '{mut}'. Existing tags can be "
            f"overwritten with new image digests.",
            "Set image_tag_mutability = \"IMMUTABLE\".",
        )
    return None


@register("aws", "aws_eks_cluster", "aws-eks-public-endpoint")
def eks_public_endpoint(b: Block) -> CheckResult | None:
    vpc = get_nested(b.body, "vpc_config")
    if vpc and get_bool(vpc[0], "endpoint_public_access") is True:
        cidrs = get_list(vpc[0], "public_access_cidrs") or []
        if not cidrs or "0.0.0.0/0" in cidrs:
            return fail(
                "aws-eks-public-endpoint", "high",
                "EKS cluster API endpoint is publicly accessible",
                "endpoint_public_access is true with no CIDR restriction. "
                "The Kubernetes API is reachable from anywhere.",
                "Set endpoint_public_access = false (private only) or "
                "scope public_access_cidrs to a corporate range.",
                "CIS-EKS 5.4.1",
            )
    return None


@register("aws", "aws_eks_cluster", "aws-eks-no-secrets-encryption")
def eks_no_secrets_encryption(b: Block) -> CheckResult | None:
    enc = get_nested(b.body, "encryption_config")
    if not enc:
        return fail(
            "aws-eks-no-secrets-encryption", "high",
            "EKS cluster has no Kubernetes secrets encryption",
            "No encryption_config block. Secrets are stored unencrypted in "
            "etcd.",
            "Add encryption_config { provider { key_arn = ... }, resources "
            "= [\"secrets\"] }.",
            "CIS-EKS 2.7",
        )
    return None


@register("aws", "aws_sqs_queue", "aws-sqs-no-encryption")
def sqs_no_encryption(b: Block) -> CheckResult | None:
    if not get_attr(b.body, "kms_master_key_id") \
       and get_bool(b.body, "sqs_managed_sse_enabled") is not True:
        return fail(
            "aws-sqs-no-encryption", "medium",
            "SQS queue is not encrypted",
            "No kms_master_key_id and sqs_managed_sse_enabled not true.",
            "Set kms_master_key_id to a CMK or sqs_managed_sse_enabled = true.",
        )
    return None


@register("aws", "aws_sns_topic", "aws-sns-no-encryption")
def sns_no_encryption(b: Block) -> CheckResult | None:
    if not get_attr(b.body, "kms_master_key_id"):
        return fail(
            "aws-sns-no-encryption", "medium",
            "SNS topic is not encrypted",
            "No kms_master_key_id set.",
            "Set kms_master_key_id to a customer-managed CMK.",
        )
    return None


@register("aws", "aws_redshift_cluster", "aws-redshift-unencrypted")
def redshift_unencrypted(b: Block) -> CheckResult | None:
    if get_bool(b.body, "encrypted") is not True:
        return fail(
            "aws-redshift-unencrypted", "high",
            "Redshift cluster is not encrypted",
            "encrypted is not true.",
            "Set encrypted = true and kms_key_id to a CMK.",
        )
    return None


@register("aws", "aws_redshift_cluster", "aws-redshift-public")
def redshift_public(b: Block) -> CheckResult | None:
    if get_bool(b.body, "publicly_accessible") is True:
        return fail(
            "aws-redshift-public", "high",
            "Redshift cluster is publicly accessible",
            "publicly_accessible = true.",
            "Set publicly_accessible = false; use VPC peering or a bastion.",
        )
    return None


@register("aws", "aws_elasticache_replication_group",
          "aws-elasticache-no-transit-encryption")
def elasticache_no_transit_encryption(b: Block) -> CheckResult | None:
    if get_bool(b.body, "transit_encryption_enabled") is not True:
        return fail(
            "aws-elasticache-no-transit-encryption", "high",
            "ElastiCache replication group lacks in-transit encryption",
            "transit_encryption_enabled is not true.",
            "Set transit_encryption_enabled = true and at_rest_encryption_"
            "enabled = true.",
        )
    return None


@register("aws", "aws_secretsmanager_secret", "aws-secret-no-rotation")
def secretsmanager_no_rotation(b: Block) -> CheckResult | None:
    if not get_attr(b.body, "rotation_lambda_arn") \
       and "aws_secretsmanager_secret_rotation" not in b.body:
        return fail(
            "aws-secret-no-rotation", "low",
            "Secrets Manager secret has no rotation configured",
            "No rotation_lambda_arn and no aws_secretsmanager_secret_rotation "
            "sibling resource.",
            "Configure automated rotation via aws_secretsmanager_secret_"
            "rotation.",
        )
    return None


@register("aws", "aws_api_gateway_stage", "aws-apigw-no-logging")
def apigw_no_logging(b: Block) -> CheckResult | None:
    if not get_nested(b.body, "access_log_settings"):
        return fail(
            "aws-apigw-no-logging", "medium",
            "API Gateway stage has no access logging",
            "No access_log_settings block.",
            "Add access_log_settings { destination_arn = ..., format = ... } "
            "pointing at a CloudWatch Logs group.",
        )
    return None


@register("aws", "aws_api_gateway_stage", "aws-apigw-no-xray")
def apigw_no_xray(b: Block) -> CheckResult | None:
    if get_bool(b.body, "xray_tracing_enabled") is not True:
        return fail(
            "aws-apigw-no-xray", "low",
            "API Gateway stage has X-Ray tracing disabled",
            "xray_tracing_enabled is not true.",
            "Set xray_tracing_enabled = true.",
        )
    return None
