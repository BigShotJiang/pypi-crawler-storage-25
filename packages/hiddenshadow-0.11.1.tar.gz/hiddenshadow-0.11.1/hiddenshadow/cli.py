"""hiddenshadow CLI."""
from __future__ import annotations
import sys
from pathlib import Path

# Reconfigure stdio to UTF-8 for Windows
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass

import click
from rich.console import Console
from rich.table import Table
from rich import box

from . import __version__
from . import scan as scan_mod
from . import licenses as license_mod

console = Console(legacy_windows=False)
err_console = Console(stderr=True, style="red", legacy_windows=False)


@click.group(help="hiddenshadow — license + SBOM + dependency analyzer.")
@click.version_option(__version__, prog_name="hiddenshadow")
def main() -> None:
    pass


@main.command("scan", help="Scan a directory tree of cloned source repos.")
@click.argument("source_root", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--output", "-o",
              type=click.Path(file_okay=False, path_type=Path),
              default=None,
              help="Where to write scan artifacts (defaults to <source_root>).")
@click.option("--only", multiple=True, help="Only scan named repo(s).")
@click.option("--skip", multiple=True, help="Skip named repo(s).")
@click.option("--quiet", "-q", is_flag=True, help="Suppress per-repo output.")
@click.option("--ignore-metadata", is_flag=True,
              help="Disable METADATA-based finding suppression. Use to see "
                   "the raw view (every finding, even ones already documented "
                   "in METADATA.yaml).")
@click.option("--no-secrets", is_flag=True,
              help="Disable hardcoded-credential / cleartext-secret detection. "
                   "By default each repo is scanned for private keys, cloud and "
                   "SaaS tokens, connection strings with embedded passwords, and "
                   "generic password = '...' assignments.")
@click.option("--no-sast", is_flag=True,
              help="Disable SAST / code-quality rules (dangerous functions, "
                   "shell injection, broken crypto, etc.).")
@click.option("--no-cves", is_flag=True,
              help="Disable OSV.dev CVE lookup. CVE checks require network "
                   "and add 30-90s on a typical repo set.")
@click.option("--no-behavior", is_flag=True,
              help="Disable behavioral-inference rules (the 'as-if-running' "
                   "view of network egress, sensitive FS access, process "
                   "spawns, env-var reads, persistence mechanisms, and "
                   "privilege escalation). No code is executed by these "
                   "rules — they are purely static pattern matches.")
@click.option("--no-signatures", is_flag=True,
              help="Disable binary library signature inspection (Authenticode "
                   "on PE, JAR signatures, NuGet .signature.p7s, Mach-O "
                   "LC_CODE_SIGNATURE, detached .asc/.sig sidecars) and the "
                   "registry-attestation audit for declared dependencies.")
@click.option("--no-signature-network", is_flag=True,
              help="Run signature inspection offline only. Skips npm/PyPI "
                   "publisher cross-checks, the Sigstore Rekor hash lookup, "
                   "and the declared-dependency provenance audit.")
@click.option("--no-install-scripts", is_flag=True,
              help="Disable install/build script analysis (npm scripts.*, "
                   "setup.py body, Cargo build.rs). This detector composes "
                   "capability triggers (network, dynamic-exec, env-read, "
                   "fs-sensitive, persistence, decode-blob, bidi/homoglyph) "
                   "into the attack patterns used by real supply-chain "
                   "incidents (event-stream, ua-parser-js, xz-utils).")
@click.option("--detect-iac", is_flag=True,
              help="Also scan Terraform (.tf / .tf.json) files for insecure "
                   "AWS / GCP configuration. Off by default since IaC "
                   "scanning is meant as a separate workflow; the dedicated "
                   "`tfscan` command produces its own report.")
@click.option("--detect-containers", is_flag=True,
              help="Also scan Dockerfile / Containerfile / docker-compose "
                   "files for insecure container configuration. Off by "
                   "default; the dedicated `containerscan` command also "
                   "supports pulling and scanning OCI image layers for CVEs.")
@click.option("--sarif", "sarif_path", default=None,
              type=click.Path(dir_okay=False, path_type=Path),
              help="Also write findings as SARIF 2.1.0 to this path so "
                   "they show up in GitHub's code-scanning tab.")
@click.option("--diff", "diff_base", default=None,
              help="Filter to findings on files changed since this git ref "
                   "(e.g. origin/main). Useful in PR-triggered CI.")
@click.option("--fail-on", type=click.Choice(["critical", "high", "medium", "low", "any"]),
              default=None,
              help="Exit non-zero if findings of this severity (or worse) "
                   "are present. Useful in CI.")
def scan_cmd(source_root: Path, output: Path | None,
             only: tuple[str, ...], skip: tuple[str, ...], quiet: bool,
             ignore_metadata: bool, no_secrets: bool, no_sast: bool,
             no_cves: bool, no_behavior: bool,
             no_signatures: bool, no_signature_network: bool,
             no_install_scripts: bool, detect_iac: bool,
             detect_containers: bool, sarif_path: Path | None,
             diff_base: str | None,
             fail_on: str | None) -> None:
    output_root = output or source_root
    summary = scan_mod.run(
        source_root=source_root,
        output_root=output_root,
        only=list(only) if only else None,
        skip=list(skip) if skip else None,
        quiet=quiet,
        respect_metadata=not ignore_metadata,
        detect_secrets=not no_secrets,
        detect_sast=not no_sast,
        detect_cves=not no_cves,
        detect_behavior=not no_behavior,
        detect_signatures=not no_signatures,
        signature_network_lookup=not no_signature_network,
        detect_install_scripts=not no_install_scripts,
        detect_iac=detect_iac,
        detect_containers=detect_containers,
    )

    # Optional SARIF + diff-mode post-processing on the main scan output.
    if sarif_path is not None or diff_base is not None:
        from .findings import Finding
        from . import diffmode
        from . import sarif as sarif_mod
        from . import __version__
        all_findings = [Finding(**f)
                        for f in summary["findings"]["findings"]]
        if diff_base is not None:
            changed = diffmode.changed_files(source_root, base_ref=diff_base)
            if changed is not None:
                pre = len(all_findings)
                all_findings = diffmode.filter_findings_by_files(
                    all_findings, changed)
                console.print(
                    f"[dim]Diff mode kept {len(all_findings)} of {pre} "
                    f"findings (changed since {diff_base}).[/]")
                # Re-tally severity counts for the gate below.
                summary["findings"]["by_severity"] = {
                    s: sum(1 for f in all_findings if f.severity == s)
                    for s in ("critical", "high", "medium", "low", "info")
                }
        if sarif_path is not None:
            sarif_mod.write_sarif(all_findings, sarif_path,
                                  tool_version=__version__,
                                  source_root=source_root)
            console.print(f"  SARIF: {sarif_path}")

    if fail_on:
        by_sev = summary["findings"]["by_severity"]
        thresholds = ("critical", "high", "medium", "low")
        if fail_on == "any":
            triggers = [s for s in thresholds if by_sev.get(s, 0) > 0]
        else:
            idx = thresholds.index(fail_on)
            triggers = [s for s in thresholds[: idx + 1] if by_sev.get(s, 0) > 0]
        if triggers:
            counts = ", ".join(f"{s}={by_sev[s]}" for s in triggers)
            err_console.print(
                f"[red bold]FAIL:[/] severity threshold '{fail_on}' tripped — {counts}"
            )
            raise click.exceptions.Exit(1)
        console.print(
            f"[green]OK:[/] no findings at severity '{fail_on}' or worse."
        )


@main.command("tfscan",
              help="Inspect Terraform (.tf / .tf.json) configurations for "
                   "insecure AWS / GCP defaults.")
@click.argument("source_root", type=click.Path(exists=True, file_okay=False,
                                                path_type=Path))
@click.option("--output", "-o",
              type=click.Path(file_okay=False, path_type=Path),
              default=None,
              help="Where to write tfscan-findings.json / .csv (defaults to "
                   "<source_root>/_logs).")
@click.option("--cloud", type=click.Choice(["aws", "gcp", "all"]),
              default="all",
              help="Which cloud rule set to run.")
@click.option("--quiet", "-q", is_flag=True,
              help="Suppress per-file output.")
@click.option("--fail-on", type=click.Choice(
                  ["critical", "high", "medium", "low", "any"]),
              default=None,
              help="Exit non-zero if findings of this severity (or worse) "
                   "are present.")
def tfscan_cmd(source_root: Path, output: Path | None, cloud: str,
               quiet: bool, fail_on: str | None) -> None:
    import csv
    import json as _json
    from dataclasses import asdict
    from datetime import datetime, timezone

    from . import iac as iac_mod

    clouds = ("aws", "gcp") if cloud == "all" else (cloud,)
    iac_mod._ensure_rulesets_loaded()

    if not quiet:
        rule_count = sum(len(iac_mod.get_rules(c)) for c in clouds)
        console.print(
            f"[bold]Scanning Terraform under[/] {source_root} "
            f"[dim]with {rule_count} rule(s) across {', '.join(clouds)}[/]"
        )

    tf_files = iac_mod.find_tf_files(source_root)
    if not quiet:
        console.print(f"[dim]Discovered {len(tf_files)} Terraform file(s).[/]")

    findings = iac_mod.scan_path(source_root, clouds=clouds)

    log_dir = (output or source_root) / "_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    json_path = log_dir / "tfscan-findings.json"
    csv_path = log_dir / "tfscan-findings.csv"

    by_sev = {s: 0 for s in ("critical", "high", "medium", "low", "info")}
    for f in findings:
        by_sev[f.severity] = by_sev.get(f.severity, 0) + 1

    json_path.write_text(_json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_root": str(source_root),
        "clouds": list(clouds),
        "files_scanned": len(tf_files),
        "rules_loaded": sum(len(iac_mod.get_rules(c)) for c in clouds),
        "by_severity": by_sev,
        "findings": [asdict(f) for f in findings],
    }, indent=2), encoding="utf-8")

    cols = ["cloud", "rule_id", "severity", "resource_type", "resource_name",
            "file", "line", "title", "detail", "recommendation", "reference"]
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for fi in findings:
            w.writerow({k: getattr(fi, k, "") for k in cols})

    if not quiet:
        console.print()
        for sev in ("critical", "high", "medium", "low", "info"):
            console.print(f"  [bold]{sev:8}[/]: {by_sev[sev]}")
        console.print()
        console.print(f"  tfscan-findings.json: {json_path}")
        console.print(f"  tfscan-findings.csv:  {csv_path}")

    if fail_on:
        thresholds = ("critical", "high", "medium", "low")
        if fail_on == "any":
            triggers = [s for s in thresholds if by_sev.get(s, 0) > 0]
        else:
            idx = thresholds.index(fail_on)
            triggers = [s for s in thresholds[: idx + 1]
                        if by_sev.get(s, 0) > 0]
        if triggers:
            counts = ", ".join(f"{s}={by_sev[s]}" for s in triggers)
            err_console.print(
                f"[red bold]FAIL:[/] severity threshold '{fail_on}' tripped — {counts}"
            )
            raise click.exceptions.Exit(1)


@main.command("containerscan",
              help="Scan Dockerfiles + docker-compose for insecure config "
                   "and (optionally) walk image layers for CVEs.")
@click.argument("source_root", type=click.Path(exists=True, file_okay=False,
                                                path_type=Path))
@click.option("--output", "-o",
              type=click.Path(file_okay=False, path_type=Path),
              default=None,
              help="Where to write containerscan-findings.json/.csv "
                   "(defaults to <source_root>/_logs).")
@click.option("--scan-layers/--no-scan-layers", default=True,
              help="Pull each FROM image from its registry and walk its "
                   "OCI layers to extract installed OS packages. Default "
                   "on; pass --no-scan-layers for an offline run.")
@click.option("--cve-lookup/--no-cve-lookup", default=True,
              help="When --scan-layers is on, query OSV.dev for each "
                   "extracted package + version. Default on.")
@click.option("--quiet", "-q", is_flag=True, help="Suppress output.")
@click.option("--fail-on", type=click.Choice(
                  ["critical", "high", "medium", "low", "any"]),
              default=None,
              help="Exit non-zero if findings of this severity (or worse) "
                   "are present.")
def containerscan_cmd(source_root: Path, output: Path | None,
                      scan_layers: bool, cve_lookup: bool, quiet: bool,
                      fail_on: str | None) -> None:
    import csv
    import json as _json
    from dataclasses import asdict
    from datetime import datetime, timezone

    from . import containers as cont_mod

    if not quiet:
        console.print(
            f"[bold]Scanning containers under[/] {source_root} "
            f"[dim](scan_layers={scan_layers}, cve_lookup={cve_lookup})[/]"
        )

    cache_dir = (output or source_root) / "_cache"
    findings = cont_mod.scan_path(
        source_root, repo_name=source_root.name,
        scan_layers=scan_layers, cve_lookup=cve_lookup,
        cache_dir=cache_dir,
    )

    log_dir = (output or source_root) / "_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    json_path = log_dir / "containerscan-findings.json"
    csv_path = log_dir / "containerscan-findings.csv"

    by_sev = {s: 0 for s in ("critical", "high", "medium", "low", "info")}
    for f in findings:
        by_sev[f.severity] = by_sev.get(f.severity, 0) + 1

    json_path.write_text(_json.dumps({
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_root": str(source_root),
        "scan_layers": scan_layers,
        "cve_lookup": cve_lookup,
        "by_severity": by_sev,
        "findings": [asdict(f) for f in findings],
    }, indent=2), encoding="utf-8")

    cols = ["repo", "source", "severity", "rule_id", "title",
            "location", "image", "package", "package_version",
            "cve_id", "detail", "recommendation", "references"]
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for fi in findings:
            w.writerow({k: getattr(fi, k, "") for k in cols})

    if not quiet:
        console.print()
        for sev in ("critical", "high", "medium", "low", "info"):
            console.print(f"  [bold]{sev:8}[/]: {by_sev[sev]}")
        console.print()
        console.print(f"  containerscan-findings.json: {json_path}")
        console.print(f"  containerscan-findings.csv:  {csv_path}")

    if fail_on:
        thresholds = ("critical", "high", "medium", "low")
        if fail_on == "any":
            triggers = [s for s in thresholds if by_sev.get(s, 0) > 0]
        else:
            idx = thresholds.index(fail_on)
            triggers = [s for s in thresholds[: idx + 1]
                        if by_sev.get(s, 0) > 0]
        if triggers:
            counts = ", ".join(f"{s}={by_sev[s]}" for s in triggers)
            err_console.print(
                f"[red bold]FAIL:[/] severity threshold '{fail_on}' tripped — {counts}"
            )
            raise click.exceptions.Exit(1)


@main.command("ci-scan",
              help="Scan CI/CD pipeline configs (GitHub Actions, GitLab, "
                   "Azure, Jenkins, CircleCI) for insecure patterns.")
@click.argument("source_root", type=click.Path(exists=True, file_okay=False,
                                                path_type=Path))
@click.option("--output", "-o",
              type=click.Path(file_okay=False, path_type=Path),
              default=None,
              help="Where to write cipipeline-findings.json/.csv/.sarif "
                   "(defaults to <source_root>/_logs).")
@click.option("--format", "output_format",
              type=click.Choice(["json", "csv", "sarif", "all"]),
              default="all", help="Output format(s) to write.")
@click.option("--diff", "diff_base", default=None,
              help="Filter to findings on files changed since this git ref "
                   "(e.g. origin/main).")
@click.option("--quiet", "-q", is_flag=True, help="Suppress output.")
@click.option("--fail-on", type=click.Choice(
                  ["critical", "high", "medium", "low", "any"]),
              default=None,
              help="Exit non-zero if findings of this severity (or worse) "
                   "are present.")
def ciscan_cmd(source_root: Path, output: Path | None,
               output_format: str, diff_base: str | None, quiet: bool,
               fail_on: str | None) -> None:
    import csv
    import json as _json
    from dataclasses import asdict
    from datetime import datetime, timezone

    from . import ci_pipelines as cip
    from . import ci_misc
    from . import diffmode
    from . import sarif as sarif_mod
    from . import __version__

    if not quiet:
        console.print(f"[bold]Scanning CI/CD configs under[/] {source_root}")

    ci_findings = cip.scan_path(source_root,
                                repo_name=source_root.name)
    misc_findings = ci_misc.scan_path(source_root, repo=source_root.name)
    # Convert CiFinding → Finding for unified post-processing.
    all_findings = [c.to_finding() for c in ci_findings] + misc_findings

    if diff_base:
        changed = diffmode.changed_files(source_root, base_ref=diff_base)
        if changed is not None:
            pre = len(all_findings)
            all_findings = diffmode.filter_findings_by_files(
                all_findings, changed)
            if not quiet:
                console.print(
                    f"[dim]Diff mode kept {len(all_findings)} of {pre} "
                    f"findings (changed since {diff_base}).[/]")
        elif not quiet:
            console.print(
                f"[yellow]--diff:[/] git unavailable or ref '{diff_base}' "
                f"could not be resolved; reporting all findings.")

    log_dir = (output or source_root) / "_logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    by_sev = {s: 0 for s in ("critical", "high", "medium", "low", "info")}
    for f in all_findings:
        by_sev[f.severity] = by_sev.get(f.severity, 0) + 1

    if output_format in ("json", "all"):
        (log_dir / "cipipeline-findings.json").write_text(_json.dumps({
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "source_root": str(source_root),
            "by_severity": by_sev,
            "findings": [asdict(f) for f in all_findings],
        }, indent=2), encoding="utf-8")

    if output_format in ("csv", "all"):
        cols = ["repo", "severity", "category", "title", "location",
                "detail", "recommendation", "method"]
        with (log_dir / "cipipeline-findings.csv").open(
                "w", newline="", encoding="utf-8") as fp:
            w = csv.DictWriter(fp, fieldnames=cols)
            w.writeheader()
            for f in all_findings:
                w.writerow({k: getattr(f, k, "") for k in cols})

    if output_format in ("sarif", "all"):
        sarif_mod.write_sarif(
            all_findings,
            log_dir / "cipipeline-findings.sarif",
            tool_version=__version__,
            source_root=source_root,
        )

    if not quiet:
        console.print()
        for sev in ("critical", "high", "medium", "low", "info"):
            console.print(f"  [bold]{sev:8}[/]: {by_sev[sev]}")

    if fail_on:
        thresholds = ("critical", "high", "medium", "low")
        if fail_on == "any":
            trip = sum(by_sev.values()) > 0
        else:
            idx = thresholds.index(fail_on)
            trip = any(by_sev.get(s, 0) > 0 for s in thresholds[: idx + 1])
        if trip:
            err_console.print(
                f"[red bold]FAIL:[/] severity threshold '{fail_on}' tripped"
            )
            raise click.exceptions.Exit(1)


@main.command("check",
              help="One-shot CI-friendly scan. Runs the full battery (scan + "
                   "tfscan + containerscan + ci-scan), prints a compact "
                   "summary, exits non-zero on high+ findings.")
@click.argument("source_root", type=click.Path(exists=True, file_okay=False,
                                                path_type=Path))
@click.option("--diff", "diff_base", default=None,
              help="Filter to findings on files changed since this git ref.")
@click.option("--threshold", default="high",
              type=click.Choice(["critical", "high", "medium", "low", "any"]),
              help="Severity that triggers non-zero exit.")
@click.option("--sarif", "sarif_path", default=None,
              type=click.Path(dir_okay=False, path_type=Path),
              help="Write SARIF output for GitHub code-scanning to this path.")
def check_cmd(source_root: Path, diff_base: str | None,
              threshold: str, sarif_path: Path | None) -> None:
    """Terse CI wrapper. Designed to be the single line in a pipeline yaml."""
    from . import scan as scan_mod
    from . import ci_pipelines as cip
    from . import ci_misc
    from . import diffmode
    from . import sarif as sarif_mod
    from . import __version__
    from .findings import Finding
    from dataclasses import asdict

    summary = scan_mod.run(
        source_root=source_root, output_root=source_root,
        quiet=True, detect_iac=True, detect_containers=True,
    )
    all_findings = [Finding(**f) for f in summary["findings"]["findings"]]
    ci_findings = cip.scan_path(source_root, repo_name=source_root.name)
    all_findings.extend(c.to_finding() for c in ci_findings)
    all_findings.extend(ci_misc.scan_path(source_root,
                                          repo=source_root.name))

    if diff_base:
        changed = diffmode.changed_files(source_root, base_ref=diff_base)
        if changed is not None:
            all_findings = diffmode.filter_findings_by_files(
                all_findings, changed)

    by_sev = {s: 0 for s in ("critical", "high", "medium", "low", "info")}
    for f in all_findings:
        by_sev[f.severity] = by_sev.get(f.severity, 0) + 1

    console.print(
        f"hiddenshadow check: critical={by_sev['critical']} "
        f"high={by_sev['high']} medium={by_sev['medium']} "
        f"low={by_sev['low']} info={by_sev['info']}"
    )

    if sarif_path is not None:
        sarif_mod.write_sarif(all_findings, sarif_path,
                              tool_version=__version__,
                              source_root=source_root)
        console.print(f"  SARIF: {sarif_path}")

    severities = ("critical", "high", "medium", "low")
    if threshold == "any":
        fail = sum(by_sev.values()) > 0
    else:
        idx = severities.index(threshold)
        fail = any(by_sev[s] > 0 for s in severities[: idx + 1])
    if fail:
        raise click.exceptions.Exit(1)


@main.command("watch",
              help="Run a recurring scan, save history, and report only "
                   "NEW findings since the previous run.")
@click.argument("source_root", type=click.Path(exists=True, file_okay=False,
                                                path_type=Path))
@click.option("--output", "-o",
              type=click.Path(file_okay=False, path_type=Path),
              default=None,
              help="Output root for scan artifacts + _scan_history/. "
                   "Defaults to <source_root>.")
@click.option("--interval", default=86400, show_default=True,
              help="Seconds between runs in --loop mode (default 24h). "
                   "Ignored in --once mode.")
@click.option("--once", is_flag=True,
              help="Run a single iteration and exit. Use this with "
                   "cron / Windows Task Scheduler / systemd timers for "
                   "unattended scheduling.")
@click.option("--refresh-cache", is_flag=True,
              help="Ignore the on-disk HTTP cache for this run. CVE / "
                   "license / signature lookups always hit the network.")
@click.option("--fail-on-new", type=click.Choice(
                  ["critical", "high", "medium", "low", "any"]),
              default=None,
              help="Exit non-zero if any NEW finding of this severity "
                   "(or worse) appeared since the previous run.")
@click.option("--notify", "notify_url", default=None,
              help="POST a summary of new findings to this URL. Slack "
                   "webhook URLs and GitHub PR comment endpoints are "
                   "auto-detected; anything else gets a generic JSON "
                   "payload. GITHUB_TOKEN env var required for GitHub.")
def watch_cmd(source_root: Path, output: Path | None,
              interval: int, once: bool, refresh_cache: bool,
              fail_on_new: str | None, notify_url: str | None) -> None:
    from . import watch as watch_mod
    from .network import CachedHttp

    output_root = output or source_root

    # Apply --refresh-cache by mutating the default-fetcher behavior
    # for this process: monkeypatch CachedHttp to default refresh=True.
    if refresh_cache:
        orig_init = CachedHttp.__init__

        def _refresh_init(self, *args, **kwargs):
            kwargs.setdefault("refresh", True)
            orig_init(self, *args, **kwargs)
        CachedHttp.__init__ = _refresh_init  # type: ignore[assignment]

    def _report(diff: "watch_mod.WatchDiff") -> None:
        if not diff.prior_stamp:
            console.print(
                f"[yellow]Initial run[/]: {len(diff.new_findings)} "
                f"finding(s) baselined.")
            return
        if not diff.has_new and not diff.resolved_findings:
            console.print(
                f"[green]No change[/] since {diff.prior_stamp} "
                f"({diff.unchanged} findings carried forward).")
            return
        if diff.has_new:
            sevs = diff.new_by_severity
            sev_str = ", ".join(f"{s}={n}" for s, n in sevs.items())
            console.print(
                f"[red bold]{len(diff.new_findings)} NEW finding(s)[/] "
                f"since {diff.prior_stamp} ({sev_str}).")
            for f in diff.new_findings[:25]:
                console.print(
                    f"  [{f.get('severity', '?'):8}] "
                    f"{f.get('repo', ''):20} "
                    f"{f.get('title', '')}")
                console.print(f"             at {f.get('location', '')}")
            if len(diff.new_findings) > 25:
                console.print(
                    f"  ... and {len(diff.new_findings) - 25} more.")
        if diff.resolved_findings:
            console.print(
                f"[green]{len(diff.resolved_findings)} finding(s) resolved[/].")

    def _notify(diff: "watch_mod.WatchDiff") -> None:
        if not notify_url or not diff.has_new:
            return
        from . import webhooks
        from . import __version__
        result = webhooks.notify(diff, notify_url, tool_version=__version__)
        if result.error:
            err_console.print(f"[yellow]notify:[/] {result.error}")
        else:
            console.print(f"[dim]notify: posted to {notify_url} "
                          f"(HTTP {result.status}).[/]")

    if once:
        _, diff = watch_mod.run_once(source_root, output_root)
        _report(diff)
        _notify(diff)
        _maybe_fail_on_new(diff, fail_on_new)
        return

    def _on_diff(diff: "watch_mod.WatchDiff") -> None:
        _report(diff)
        _notify(diff)
        _maybe_fail_on_new(diff, fail_on_new)

    console.print(
        f"[bold]Watching[/] {source_root} every {interval}s "
        f"(Ctrl+C to stop). History: {output_root / '_scan_history'}")
    try:
        watch_mod.watch_loop(source_root, output_root,
                             interval_seconds=interval,
                             on_diff=_on_diff)
    except KeyboardInterrupt:
        console.print("[yellow]Watch stopped.[/]")


def _maybe_fail_on_new(diff, threshold: str | None) -> None:
    if not threshold or not diff.has_new:
        return
    severities = ("critical", "high", "medium", "low")
    if threshold == "any":
        trip = diff.has_new
    else:
        idx = severities.index(threshold)
        wanted = set(severities[: idx + 1])
        trip = any(f.get("severity") in wanted for f in diff.new_findings)
    if trip:
        err_console.print(
            f"[red bold]FAIL:[/] new findings at severity '{threshold}' "
            f"or worse appeared since the previous run."
        )
        raise click.exceptions.Exit(1)


@main.command("self-update",
              help="Refresh on-disk caches (and check for newer hiddenshadow "
                   "releases on PyPI).")
@click.option("--cache-dir", type=click.Path(file_okay=False, path_type=Path),
              default=None,
              help="Cache root to clear. Defaults to the current "
                   "directory's _cache/.")
@click.option("--check-pypi/--no-check-pypi", default=True,
              help="Query PyPI for the latest published hiddenshadow "
                   "version and report if newer than this one.")
def self_update_cmd(cache_dir: Path | None, check_pypi: bool) -> None:
    import shutil
    from . import __version__

    cd = cache_dir or Path("./_cache")
    if cd.exists():
        # Walk and delete each cache subdir, leaving the root.
        removed = 0
        for child in cd.iterdir():
            if child.is_dir():
                shutil.rmtree(child)
                removed += 1
        console.print(
            f"[green]Cleared[/] {removed} cache subdirectory(ies) under {cd}.")
    else:
        console.print(f"[dim]No cache at {cd} - nothing to clear.[/]")

    if check_pypi:
        import urllib.request
        import urllib.error
        try:
            req = urllib.request.Request(
                "https://pypi.org/pypi/hiddenshadow/json",
                headers={"User-Agent": "hiddenshadow-self-update"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            latest = (data.get("info") or {}).get("version", "")
            if latest and latest != __version__:
                console.print(
                    f"[yellow]Update available:[/] hiddenshadow {latest} "
                    f"(you have {__version__}).")
            elif latest:
                console.print(
                    f"[green]Up to date:[/] hiddenshadow {__version__} "
                    f"is the latest published.")
            else:
                console.print(
                    "[dim]Couldn't read latest version from PyPI.[/]")
        except (urllib.error.URLError, urllib.error.HTTPError,
                TimeoutError, json.JSONDecodeError) as exc:
            console.print(
                f"[dim]PyPI check skipped: {type(exc).__name__}: {exc}[/]")


@main.command("classify", help="Show classification for one SPDX license id.")
@click.argument("spdx")
def classify_cmd(spdx: str) -> None:
    info = license_mod.classify(spdx)
    color = {
        "adopt":    "green",
        "library":  "yellow",
        "avoid":    "red",
        "unknown":  "magenta",
    }.get(info.decision, "white")
    console.print()
    console.print(f"  [bold]SPDX:[/]            [magenta]{info.spdx}[/]")
    console.print(f"  [bold]Classification:[/]  {info.classification}")
    console.print(f"  [bold]Decision:[/]        [{color} bold]{info.decision}[/]")
    console.print()


@main.command("licenses", help="Print the full license policy table.")
def licenses_cmd() -> None:
    table = Table(box=box.SIMPLE_HEAD, header_style="bold cyan")
    table.add_column("SPDX", style="magenta")
    table.add_column("Classification")
    table.add_column("Decision", justify="center")
    for spdx in sorted(license_mod.LICENSE_CLASS.keys()):
        cls, dec = license_mod.LICENSE_CLASS[spdx]
        color = {
            "adopt":    "green",
            "library":  "yellow",
            "avoid":    "red",
            "unknown":  "magenta",
        }.get(dec, "white")
        table.add_row(spdx, cls, f"[{color}]{dec}[/]")
    console.print(table)


@main.command("lookup-licenses",
              help="Resolve declared licenses for unknown deps via deps.dev.")
@click.option("--rollup", type=click.Path(exists=True, dir_okay=False, path_type=Path),
              required=True, help="Path to library-rollup.csv.")
@click.option("--cache", type=click.Path(file_okay=False, path_type=Path),
              default=None, help="Cache directory (defaults to <rollup-dir>/_cache).")
@click.option("--max-rows", type=int, default=None,
              help="Limit lookup to top N most-used deps (skips the long tail).")
def lookup_licenses_cmd(rollup: Path, cache: Path | None, max_rows: int | None) -> None:
    """Fill in declared_license column using deps.dev (NPM/PyPI/Cargo/Go/Maven)."""
    import csv
    from . import registry as reg_mod

    cache_dir = cache or rollup.parent / "_cache"
    rows = list(csv.DictReader(rollup.open(encoding="utf-8")))
    target_rows = rows[:max_rows] if max_rows else rows

    console.print(f"Loaded {len(rows)} rollup rows. "
                  f"Looking up licenses for {len(target_rows)} (top by occurrence).")
    console.print(f"Cache: {cache_dir}")
    console.print()

    def progress(done, total):
        if total > 0 and done % 100 == 0:
            console.print(f"  ... {done}/{total}")

    licenses_map, stats = reg_mod.lookup_licenses(target_rows, cache_dir, progress=progress)

    console.print()
    console.print(f"  Lookups requested: {stats.requested}")
    console.print(f"    cache hits:      {stats.cache_hit}")
    console.print(f"    fetched:         {stats.cache_miss}")
    console.print(f"    success (200):   {stats.success}")
    console.print(f"    not found (404): {stats.not_found}")
    console.print(f"    errors:          {stats.errors}")
    console.print(f"    bytes received:  {stats.bytes_received:,}")
    console.print(f"    elapsed:         {stats.elapsed_s:.1f}s")
    resolved = sum(1 for v in licenses_map.values() if v)
    console.print()
    console.print(f"  Licenses found:    {resolved}/{len(licenses_map)} entries resolved")

    # Write back
    counts = reg_mod.write_rollup_with_licenses(rows, licenses_map, rollup)
    console.print()
    console.print(f"  Wrote {rollup}:")
    console.print(f"    resolved:   {counts['resolved']}")
    console.print(f"    unresolved: {counts['unresolved']}")
    console.print(f"    skipped (already had license): {counts['skipped']}")


@main.command("scan-cves",
              help="Query OSV.dev for CVEs against every dep in the rollup.")
@click.option("--rollup", type=click.Path(exists=True, dir_okay=False, path_type=Path),
              required=True, help="Path to library-rollup.csv.")
@click.option("--out", type=click.Path(dir_okay=False, path_type=Path),
              default=None, help="Output CVE findings JSON (default: <rollup-dir>/cve-findings.json).")
@click.option("--cache", type=click.Path(file_okay=False, path_type=Path),
              default=None, help="Cache directory (defaults to <rollup-dir>/_cache).")
@click.option("--max-rows", type=int, default=None,
              help="Limit query to top N most-used deps.")
def scan_cves_cmd(rollup: Path, out: Path | None, cache: Path | None,
                  max_rows: int | None) -> None:
    """Query OSV.dev for CVEs across every (name, version) in the rollup."""
    import csv
    import json
    from . import osv as osv_mod

    cache_dir = cache or rollup.parent / "_cache"
    out_path = out or rollup.parent / "cve-findings.json"
    rows = list(csv.DictReader(rollup.open(encoding="utf-8")))
    target_rows = rows[:max_rows] if max_rows else rows

    console.print(f"Loaded {len(rows)} rollup rows. "
                  f"Querying OSV.dev for {len(target_rows)} packages.")
    console.print(f"Cache: {cache_dir}")
    console.print()

    def progress(done, total):
        if total > 0 and done % 100 == 0:
            console.print(f"  ... {done}/{total}")

    findings, stats = osv_mod.scan_cves(target_rows, cache_dir, progress=progress)

    # Add recommendation per finding
    for f in findings:
        f["recommendation"] = osv_mod.cve_recommendation(f)

    # Sort by severity
    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    findings.sort(key=lambda f: (sev_order.get(f["severity"], 5), f["package"]))

    output = {
        "generated_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
        "source": "osv.dev",
        "total_findings": len(findings),
        "by_severity": {
            sev: sum(1 for f in findings if f["severity"] == sev)
            for sev in ("critical", "high", "medium", "low", "info")
        },
        "findings": findings,
    }
    out_path.write_text(json.dumps(output, indent=2), encoding="utf-8")

    console.print()
    console.print(f"  Queries: {stats.requested}  "
                  f"(cache hits {stats.cache_hit}, fetched {stats.cache_miss})")
    console.print(f"  Success/Not-found/Error: "
                  f"{stats.success}/{stats.not_found}/{stats.errors}")
    console.print(f"  Elapsed: {stats.elapsed_s:.1f}s")
    console.print()
    console.print(f"  CVE findings: {len(findings)}")
    for sev in ("critical", "high", "medium", "low", "info"):
        n = output['by_severity'][sev]
        if n:
            console.print(f"    {sev:8}: {n}")
    console.print()
    console.print(f"  Wrote {out_path}")


@main.command("web", help="Launch the web UI for running scans.")
@click.option("--host", default="127.0.0.1", show_default=True,
              help="Bind address. Use 0.0.0.0 to expose on the LAN.")
@click.option("--port", default=7878, show_default=True, type=int,
              help="HTTP port.")
@click.option("--debug", is_flag=True, help="Enable Flask debug mode.")
@click.option("--auth-token", "auth_token", default=None,
              help="Require this value in the X-HS-Token header on every "
                   "API request. Pass 'GENERATE' to print a random token "
                   "on startup. Strongly recommended when --host is not "
                   "127.0.0.1.")
def web_cmd(host: str, port: int, debug: bool,
            auth_token: str | None) -> None:
    try:
        from . import web as web_mod
    except ImportError as e:
        err_console.print(
            "[red]Flask is not installed.[/] Install the web extra:\n"
            "    pip install -e \".[web]\"\n"
            f"  ({e})"
        )
        raise click.exceptions.Exit(1)
    if auth_token == "GENERATE":
        import secrets
        auth_token = secrets.token_urlsafe(32)
    web_mod.serve(host=host, port=port, debug=debug, auth_token=auth_token)


@main.command("findings", help="Print findings from the most recent scan.")
@click.option("--source-root", type=click.Path(exists=True, file_okay=False, path_type=Path),
              required=True, help="The source root used in the scan.")
@click.option("--severity",
              type=click.Choice(["critical", "high", "medium", "low", "info"]),
              help="Filter to one severity.")
def findings_cmd(source_root: Path, severity: str | None) -> None:
    import json
    findings_path = source_root / "_logs" / "scan-findings.json"
    if not findings_path.exists():
        err_console.print(f"No scan-findings.json at {findings_path}")
        raise click.exceptions.Exit(2)
    data = json.loads(findings_path.read_text(encoding="utf-8"))
    findings = data["findings"]
    if severity:
        findings = [f for f in findings if f["severity"] == severity]
    table = Table(box=box.SIMPLE_HEAD, header_style="bold cyan")
    table.add_column("Sev", justify="center")
    table.add_column("Repo")
    table.add_column("Title")
    table.add_column("Location", style="dim")
    sev_color = {"critical": "red bold", "high": "red", "medium": "yellow",
                 "low": "blue", "info": "cyan"}
    for f in findings:
        s = f["severity"]
        table.add_row(
            f"[{sev_color.get(s,'white')}]{s}[/]",
            f["repo"],
            f["title"][:80],
            f["location"][:60],
        )
    console.print(table)
    console.print(f"[dim]{len(findings)} findings[/]")


if __name__ == "__main__":
    main()
