"""Hardcoded-credential / cleartext-secret detection.

Walks a repository's source + config files and emits Findings for anything
that looks like a credential left in the tree:

* Private-key blocks (RSA / EC / OpenSSH / PGP / generic).
* Provider tokens with distinctive prefixes (AWS, GitHub, Google, Stripe,
  Slack, Twilio, SendGrid, npm, PyPI, ...).
* Connection strings with an embedded password
  (``mongodb://user:<password>@host``, ``postgres://…``, etc.).
* JSON Web Tokens.
* Generic credential assignments
  (``password = "<value>"``, ``API_KEY: '<value>'`` and so on).

Each match is recorded with the matched secret **redacted** — only the
first three and last three characters are kept, so the findings file is
itself safe to share.

Heuristic filters cull obvious placeholders (``"<password>"``,
``"${PASSWORD}"``, ``"changeme"``, ``"example"``, environment-variable
references, empty strings) so a repo full of templates does not drown the
real findings.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from .findings import Finding
from .manifests import SKIP_DIRS


# ────────────────────────────────────────────────────────────────────────
# File-selection rules
# ────────────────────────────────────────────────────────────────────────

# Source + config extensions that are worth scanning.
SCANNED_EXTS: set[str] = {
    # general source
    ".py", ".rs", ".go", ".java", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
    ".c", ".h", ".cpp", ".hpp", ".cc", ".cs", ".rb", ".php", ".scala", ".kt",
    ".swift", ".m", ".mm", ".pl", ".pm", ".lua", ".dart", ".r", ".jl",
    # shells / scripts
    ".sh", ".bash", ".zsh", ".ps1", ".psm1", ".bat", ".cmd",
    # config / data
    ".yml", ".yaml", ".json", ".jsonc", ".toml", ".ini", ".cfg", ".conf",
    ".config", ".env", ".properties", ".xml", ".plist",
    ".tf", ".tfvars", ".hcl", ".nomad", ".sql", ".graphql", ".gql",
    # web / templates
    ".html", ".htm", ".vue", ".svelte", ".ejs",
    # certificate-ish text
    ".pem", ".key", ".crt", ".cer",
}

# Files without an extension that are still worth scanning.
SCANNED_FILENAMES: set[str] = {
    "Dockerfile", "Containerfile", "Makefile", "Jenkinsfile",
    ".env", ".npmrc", ".pypirc", ".netrc",
    "config", "credentials",
}

# Lockfiles and dependency snapshots are dense with hex/base64 strings that
# look uncomfortably like secrets but are just integrity hashes. Skip them.
SKIP_FILE_NAMES: set[str] = {
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "poetry.lock", "Pipfile.lock", "Cargo.lock",
    "go.sum", "composer.lock", "Gemfile.lock", "mix.lock",
}

# Hard ceiling: don't read very large files looking for short secrets.
MAX_FILE_BYTES = 1_000_000


# ────────────────────────────────────────────────────────────────────────
# Detection patterns
# ────────────────────────────────────────────────────────────────────────

_RE_PRIVATE_KEY = re.compile(
    r"-----BEGIN (?:RSA |DSA |EC |OPENSSH |ENCRYPTED |PGP )?PRIVATE KEY"
)


# (label, severity, regex). Severities follow the project's existing scale.
TOKEN_PATTERNS: list[tuple[str, str, re.Pattern[str]]] = [
    # ── Cloud providers ─────────────────────────────────────────────
    ("AWS access key id",          "critical",
        re.compile(r"\b(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASCA)[0-9A-Z]{16}\b")),
    ("Google API key",             "critical",
        re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("Google OAuth client secret", "critical",
        re.compile(r"\bGOCSPX-[A-Za-z0-9_\-]{28}\b")),
    ("Azure storage key",          "high",
        re.compile(
            r"(?i)Defaults?Endpoints?Protocol\s*=\s*https?;\s*"
            r"AccountName\s*=\s*[a-z0-9]+;\s*AccountKey\s*=\s*[A-Za-z0-9+/=]{60,}"
        )),

    # ── GitHub ──────────────────────────────────────────────────────
    ("GitHub PAT (classic)",       "critical",
        re.compile(r"\bghp_[A-Za-z0-9]{36}\b")),
    ("GitHub PAT (fine-grained)",  "critical",
        re.compile(r"\bgithub_pat_[A-Za-z0-9_]{82}\b")),
    ("GitHub OAuth token",         "critical",
        re.compile(r"\bgho_[A-Za-z0-9]{36}\b")),
    ("GitHub user-server token",   "critical",
        re.compile(r"\b(?:ghu|ghs)_[A-Za-z0-9]{36}\b")),
    ("GitHub refresh token",       "critical",
        re.compile(r"\bghr_[A-Za-z0-9]{36}\b")),

    # ── SaaS APIs ───────────────────────────────────────────────────
    ("Slack token",                "high",
        re.compile(r"\bxox[baprs]-[A-Za-z0-9\-]{10,}\b")),
    ("Slack webhook URL",          "high",
        re.compile(r"https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]{20,}")),
    ("Stripe live secret key",     "critical",
        re.compile(r"\b(?:sk|rk)_live_[0-9a-zA-Z]{24,}\b")),
    ("Stripe test secret key",     "high",
        re.compile(r"\b(?:sk|rk)_test_[0-9a-zA-Z]{24,}\b")),
    ("Twilio API key SID",         "high",
        re.compile(r"\bSK[0-9a-fA-F]{32}\b")),
    ("Twilio account SID",         "medium",
        re.compile(r"\bAC[0-9a-fA-F]{32}\b")),
    ("SendGrid API key",           "high",
        re.compile(r"\bSG\.[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{40,}\b")),
    ("Mailgun API key",            "high",
        re.compile(r"\bkey-[0-9a-zA-Z]{32}\b")),
    ("Mailchimp API key",          "high",
        re.compile(r"\b[0-9a-f]{32}-us[0-9]{1,2}\b")),
    ("Square access token",        "high",
        re.compile(r"\bsq0atp-[0-9A-Za-z\-_]{22}\b")),
    ("Square OAuth secret",        "high",
        re.compile(r"\bsq0csp-[0-9A-Za-z\-_]{43}\b")),

    # ── Package registries ──────────────────────────────────────────
    ("npm access token",           "high",
        re.compile(r"\bnpm_[A-Za-z0-9]{36}\b")),
    ("PyPI upload token",          "high",
        re.compile(r"\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9\-_]{50,}\b")),

    # ── Generic ─────────────────────────────────────────────────────
    ("JSON Web Token",             "medium",
        re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b")),
    ("Connection string with embedded password", "high",
        re.compile(
            r"\b(?:mongodb(?:\+srv)?|postgres(?:ql)?|mysql|mariadb|redis|amqp|amqps|ftp|smtp|ldap|ldaps)"
            r"://[A-Za-z0-9._\-]{1,64}:([^@\s/'\"`]{4,128})@",
            re.IGNORECASE,
        )),
]


# Generic ``password = "<value>"`` / ``api_key: '<value>'`` / ``token = `<value>` ``
# style assignments, in source-code OR config files. Anchored to a known
# credential keyword so we don't flag every quoted string in the codebase.
_KEYWORDS = (
    r"passwd|password|passphrase|pwd|secret|"
    r"api[_-]?key|apikey|access[_-]?key|access[_-]?token|"
    r"auth[_-]?token|auth[_-]?key|bearer[_-]?token|"
    r"client[_-]?secret|consumer[_-]?secret|"
    r"private[_-]?key|priv[_-]?key|"
    r"db[_-]?pass(?:word)?|database[_-]?password"
)
_RE_KEY_VALUE = re.compile(
    rf"""(?ix)
    \b(?P<keyword>{_KEYWORDS})
    \s*[:=]\s*
    (?P<quote>['"`])(?P<value>[^'"`\n\r]{{4,200}})(?P=quote)
    """
)


# Strings that almost certainly *aren't* a real secret value. Used to
# downgrade noise — any value matching here is dropped, not reported.
_RE_PLACEHOLDER = re.compile(
    r"""(?ix)
    ^(
        \*+ | x+ | \.+ | -+ | _+ | \?+
      | <[^>]+>                    # <password>
      | \$\{[^}]+\}                # ${PASSWORD}
      | \{\{[^}]+\}\}              # {{password}}
      | %\([^)]+\)s?               # %(password)s
      | \$[A-Z][A-Z0-9_]+          # $PASSWORD
      | (?:none|null|nil|undefined|empty|n/a|na|todo|tbd|tba)
      | (?:your|my|the)[-_ ].*
      | .*?(?:example|sample|placeholder|dummy|fake|mock|test|demo
              |change[-_ ]?me|fill[-_ ]?in|replace[-_ ]?me|insert[-_ ]?here
              |provide|enter|put|put[-_ ]?your).*?
      | \s*
    )$
    """
)

# Indicators inside the value that it's a runtime lookup, not a literal.
_RE_RUNTIME_REF = re.compile(
    r"(?i)("
    r"os\.environ|getenv|process\.env|System\.getenv|Environment\.GetEnvironmentVariable"
    r"|secrets?manager|secret-manager|vault\.|keyvault|keychain|kms\.|param(?:eter)?store"
    r")"
)


# ────────────────────────────────────────────────────────────────────────
# Helpers
# ────────────────────────────────────────────────────────────────────────

def _is_placeholder(value: str) -> bool:
    v = value.strip()
    if len(v) < 4:
        return True
    if _RE_PLACEHOLDER.match(v):
        return True
    if _RE_RUNTIME_REF.search(v):
        return True
    # All-same-character strings ("xxxxxxxx", "00000000")
    if len(set(v)) <= 2:
        return True
    return False


def _redact(s: str) -> str:
    """Return a partial-display form of a matched secret.

    Keeps the first 3 and last 3 characters so reviewers can confirm the
    finding without the artifact carrying the full credential.
    """
    s = s.strip()
    if len(s) <= 8:
        return "***"
    return f"{s[:3]}…{s[-3:]} ({len(s)} chars)"


def _line_no(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def _method_slug(label: str) -> str:
    """Slugify a human-readable label into a method-id fragment.

    "AWS access key id" -> "aws-access-key-id"
    "GitHub PAT (classic)" -> "github-pat-classic"
    """
    s = label.lower().strip()
    out = []
    for ch in s:
        if ch.isalnum():
            out.append(ch)
        elif out and out[-1] != "-":
            out.append("-")
    return "".join(out).strip("-")


def _scan_file_text(repo_name: str, rel_path: str, text: str) -> list[Finding]:
    out: list[Finding] = []

    # Private-key block.
    m = _RE_PRIVATE_KEY.search(text)
    if m:
        out.append(Finding(
            repo=repo_name,
            severity="critical",
            category="secret",
            title="Hardcoded private key block detected",
            location=f"{rel_path}:{_line_no(text, m.start())}",
            detail=("File contains a `-----BEGIN ... PRIVATE KEY-----` "
                    "block. Private keys must never live in source control."),
            recommendation=("Rotate the key immediately. Move it into a "
                            "secret manager / KMS / SSH agent and load at "
                            "runtime. Purge from git history."),
            method="secret:private-key-block",
        ))

    # Provider/SaaS token patterns.
    seen_spans: set[tuple[int, int]] = set()
    for label, severity, pattern in TOKEN_PATTERNS:
        for m in pattern.finditer(text):
            span = (m.start(), m.end())
            if span in seen_spans:
                continue
            seen_spans.add(span)
            matched = m.group(0)
            # For URI-with-password matches, redact the password group, not the URL.
            redacted_value: str
            if m.lastindex:
                captured = m.group(m.lastindex)
                if _is_placeholder(captured):
                    continue
                redacted_value = _redact(captured)
            else:
                redacted_value = _redact(matched)
            out.append(Finding(
                repo=repo_name,
                severity=severity,
                category="secret",
                title=f"{label} detected in source",
                location=f"{rel_path}:{_line_no(text, m.start())}",
                detail=f"Match: {redacted_value}",
                recommendation=("Treat the credential as compromised and "
                                "rotate it. Replace the literal with an "
                                "environment-variable or secret-manager "
                                "lookup. Remove from git history."),
                method=f"secret:{_method_slug(label)}",
            ))

    # Generic credential assignments.
    for m in _RE_KEY_VALUE.finditer(text):
        value = m.group("value")
        if _is_placeholder(value):
            continue
        keyword = m.group("keyword")
        out.append(Finding(
            repo=repo_name,
            severity="high",
            category="secret",
            title=f"Hardcoded credential ({keyword.lower()})",
            location=f"{rel_path}:{_line_no(text, m.start())}",
            detail=(f"Assignment of `{keyword}` to a literal string "
                    f"({_redact(value)})."),
            recommendation=("Replace the literal with an environment "
                            "variable or secret-manager lookup. Rotate the "
                            "value if this commit was ever pushed."),
            method=f"secret:credential-keyword:{_method_slug(keyword)}",
        ))

    return out


# ────────────────────────────────────────────────────────────────────────
# Public entry point
# ────────────────────────────────────────────────────────────────────────

def scan_repo_for_secrets(repo_dir: Path, repo_name: str) -> list[Finding]:
    """Walk repo_dir and return a list of secret-related Findings."""
    findings: list[Finding] = []
    for dirpath, dirnames, filenames in os.walk(repo_dir):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if fn in SKIP_FILE_NAMES:
                continue
            ext = Path(fn).suffix.lower()
            base = fn
            if ext not in SCANNED_EXTS and base not in SCANNED_FILENAMES:
                continue
            full = Path(dirpath) / fn
            try:
                if full.stat().st_size > MAX_FILE_BYTES:
                    continue
                text = full.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            rel = full.relative_to(repo_dir).as_posix()
            findings.extend(_scan_file_text(repo_name, rel, text))
    return findings
