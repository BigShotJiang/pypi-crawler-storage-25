"""CVE / vulnerability lookup via osv.dev API.

Endpoint:
    POST https://api.osv.dev/v1/query
    Body: {"package": {"name": ..., "ecosystem": ...}, "version": ...}

Response: {"vulns": [
    {
        "id": "GHSA-...",
        "summary": "...",
        "details": "...",
        "aliases": ["CVE-..."],
        "severity": [{"type": "CVSS_V3", "score": "..."}],
        "affected": [...],
        "references": [...],
    },
    ...
]}

Free service, no auth required.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Iterable

from .network import CachedHttp


# Map our package_manager → OSV ecosystem
PM_TO_OSV: dict[str, str] = {
    "npm":      "npm",
    "pypi":     "PyPI",
    "cargo":    "crates.io",
    "go":       "Go",
    "maven":    "Maven",
    "composer": "Packagist",
}


def _osv_query(name: str, version: str, ecosystem: str) -> dict:
    return {
        "package": {"name": name, "ecosystem": ecosystem},
        "version": version,
    }


def _cache_key(name: str, version: str, ecosystem: str) -> str:
    return f"osv|{ecosystem}|{name}|{version}"


def _maven_normalize(name: str) -> str:
    """Maven names in OSV are 'group:artifact' just like ours."""
    return name


def _cvss_to_severity(cvss_score: float | None,
                      osv_db_severity: str | None) -> str:
    """Map a CVSS score (or fallback string) to our severity bucket."""
    if cvss_score is not None:
        if cvss_score >= 9.0:
            return "critical"
        if cvss_score >= 7.0:
            return "high"
        if cvss_score >= 4.0:
            return "medium"
        if cvss_score >= 0.1:
            return "low"
    if osv_db_severity:
        s = osv_db_severity.upper()
        if "CRITICAL" in s:
            return "critical"
        if "HIGH" in s:
            return "high"
        if "MODERATE" in s or "MEDIUM" in s:
            return "medium"
        if "LOW" in s:
            return "low"
    return "info"


_CVSS_RE = re.compile(r"CVSS:[\d.]+/.*?\bAV:")
_SCORE_RE = re.compile(r"\b(\d+\.\d+)\b")


def _extract_cvss(severity_field: list[dict] | None) -> float | None:
    """OSV severity is a list of {type, score} objects.

    The `score` for CVSS_V3 is sometimes a vector ('CVSS:3.1/AV:N/...')
    rather than a number. We pull the numeric score from the database
    severity if available.
    """
    if not severity_field:
        return None
    for s in severity_field:
        score = s.get("score", "")
        if not isinstance(score, str):
            continue
        # If it's a number-like string
        try:
            return float(score)
        except ValueError:
            pass
        # Look for embedded score
        m = _SCORE_RE.search(score)
        if m:
            try:
                return float(m.group(1))
            except ValueError:
                pass
    return None


def scan_cves(rollup_rows: list[dict], cache_dir: Path,
              progress=None) -> tuple[list[dict], object]:
    """Query OSV for every (name, ver, ecosystem) in rollup_rows.

    Returns (findings_list, http_stats).
    Each finding: {repo, package, ecosystem, version, vuln_id, cve_id,
                   summary, severity, fix_versions, references}
    """
    http = CachedHttp(cache_dir, service="osv-dev",
                      max_workers=8, request_delay_ms=40)

    # Build a list of unique (name, version, ecosystem) tuples
    items: list[tuple[str, str, dict]] = []
    item_keys: set[str] = set()
    item_to_meta: dict[str, dict] = {}

    for r in rollup_rows:
        name = r["name"]
        pm = r["package_manager"]
        if pm not in PM_TO_OSV:
            continue
        ecosystem = PM_TO_OSV[pm]
        # First valid version
        from .registry import normalize_version
        ver = ""
        for v in (r.get("versions") or "").split(","):
            v = normalize_version(v.strip())
            if v:
                ver = v
                break
        if not ver:
            continue
        if pm == "maven":
            qname = _maven_normalize(name)
        else:
            qname = name
        key = _cache_key(qname, ver, ecosystem)
        if key in item_keys:
            continue
        item_keys.add(key)
        items.append((key, "https://api.osv.dev/v1/query",
                      _osv_query(qname, ver, ecosystem)))
        item_to_meta[key] = {
            "name": qname, "version": ver, "ecosystem": ecosystem,
            "package_manager": pm,
            "repos": r["repos"],
            "occurrences": r["occurrences"],
        }

    if progress:
        progress(0, len(items))
    results = http.fetch_many(items, progress=progress)

    findings: list[dict] = []
    for key, result in results.items():
        meta = item_to_meta[key]
        if result.status != 200 or not result.data:
            continue
        vulns = result.data.get("vulns") or []
        for v in vulns:
            sev_score = _extract_cvss(v.get("severity"))
            db_sev = v.get("database_specific", {}).get("severity") if isinstance(v.get("database_specific"), dict) else None
            severity = _cvss_to_severity(sev_score, db_sev)
            cves = [a for a in (v.get("aliases") or []) if a.startswith("CVE-")]
            cve = cves[0] if cves else ""
            # Extract fix versions
            fix_versions: list[str] = []
            for af in (v.get("affected") or []):
                for r2 in (af.get("ranges") or []):
                    for ev in (r2.get("events") or []):
                        if "fixed" in ev:
                            fix_versions.append(ev["fixed"])
            findings.append({
                "package": meta["name"],
                "ecosystem": meta["ecosystem"],
                "package_manager": meta["package_manager"],
                "version": meta["version"],
                "occurrences": meta["occurrences"],
                "repos": meta["repos"],
                "vuln_id": v.get("id", ""),
                "cve_id": cve,
                "summary": (v.get("summary") or "")[:300],
                "severity": severity,
                "cvss_score": sev_score if sev_score is not None else "",
                "fix_versions": ", ".join(sorted(set(fix_versions))[:5]),
                "references": ", ".join(
                    [r2.get("url", "") for r2 in (v.get("references") or [])][:3]
                ),
            })
    return findings, http.stats


def cve_recommendation(finding: dict) -> str:
    """Generate the recommended-fix string for a CVE finding."""
    fix = finding.get("fix_versions", "").strip()
    pkg = finding["package"]
    pm = finding["package_manager"]
    ver = finding["version"]
    sev = finding["severity"]
    if fix:
        return (
            f"Upgrade `{pkg}` from {ver} to {fix} (or any later patched version). "
            f"For each fork pinning this dependency, the fork owner runs the "
            f"package-manager update locally and re-tests. SLA: "
            f"{'7d for critical' if sev == 'critical' else '14d for high' if sev == 'high' else '30d for medium'}."
        )
    return (
        f"No upstream fix available for `{pkg}` {ver} ({pm}). Options: "
        f"(1) wait for upstream patch and track via OSPO; "
        f"(2) replace with a permissive equivalent; "
        f"(3) if exploit unlikely, document and accept risk in METADATA. "
        f"Escalate to OSPO if {sev}/critical."
    )
