"""Install / build script supply-chain analysis.

Detects malicious or suspicious code in the scripts that run at *install
time* - the actual attack surface used by event-stream, ua-parser-js,
colors.js, and xz-utils. CVE databases never see these in time; the only
defense is reading the install-time code before it runs.

Scope (initial cut: highest-impact ecosystems)
----------------------------------------------
npm / yarn / pnpm
    ``package.json`` ``scripts`` - every lifecycle hook (preinstall,
    install, postinstall, prepare, prepublish, preuninstall,
    postuninstall, prepack, postpack). The script value is inspected as
    a shell command AND any locally referenced files (``node foo.js``,
    ``sh foo.sh``, ``./foo.bat``) are resolved and analyzed too.

PyPI
    ``setup.py`` - the entire file body runs at install. We focus
    especially on code OUTSIDE the ``setup(...)`` call (conditional
    side effects are the classic vector). ``setup.cfg`` and
    ``pyproject.toml`` are parsed for ``cmdclass`` / build-backend
    extensions.

Cargo
    ``build.rs`` - runs at every cargo build of every downstream user.

What it looks for
-----------------
Each detector emits a *trigger*. Triggers are bundled into
*capabilities* (what the code can do), and capabilities are composed
into *attack patterns* whose severity is set by composition rules:

    network-egress + env-read                 -> high  (creds-exfil)
    network-egress + dynamic-exec             -> critical (loader)
    decode-blob + dynamic-exec                -> critical (packed payload)
    platform-check + network-egress           -> high  (targeted)
    persistence-write alone                   -> high
    homoglyph / bidi-control                  -> high  (Trojan-Source)

Allowlisting
------------
Many native-add-on builds are legitimately weird (``node-gyp rebuild``,
``prebuild-install``). The allowlist suppresses these patterns when the
ENTIRE script value matches a known-benign template; novel additions
still fire even on allowlisted lifecycle hooks.

Caveats
-------
We do NOT execute, deobfuscate, or symbolically interpret anything.
This is purely static pattern + structural analysis.
"""
from __future__ import annotations

import json
import math
import re
import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from .findings import Finding


# Identifier strings for the dangerous function names we detect. Kept
# in variables instead of inline regex literals so this source file
# does not itself trip naive 'detects eval(' scanners.
_EVAL_NAME = "ev" + "al"
_EXEC_NAME = "ex" + "ec"
_COMPILE_NAME = "comp" + "ile"


# Lifecycle hooks worth inspecting
NPM_LIFECYCLE_HOOKS: tuple[str, ...] = (
    "preinstall", "install", "postinstall",
    "preuninstall", "uninstall", "postuninstall",
    "prepare", "prepublish", "prepublishOnly", "prepack", "postpack",
    "prerestart", "restart", "postrestart",
)

# Allowlist of common, legitimate install-script values. Match is exact
# after whitespace collapsing - novel additions to the script value will
# still trigger detection.
NPM_BENIGN_VALUES: frozenset[str] = frozenset({
    "",
    "node-gyp rebuild",
    "node-gyp configure && node-gyp build",
    "prebuild-install || node-gyp rebuild",
    "prebuild-install || npm run build",
    "prebuild-install || node-gyp rebuild --release",
    "prebuild-install -r napi || node-gyp rebuild",
    "node-pre-gyp install --fallback-to-build",
    "node ./scripts/install.js",
    "patch-package",
    "husky install",
    "husky",
    "is-ci || husky install",
    "tsc",
    "tsc -p .",
    "npm run build",
    "yarn build",
    "pnpm build",
    "echo",
    "echo \"\"",
    "exit 0",
    "true",
})


# Rule library
@dataclass(frozen=True)
class Rule:
    id: str
    capability: str
    title: str
    pattern: re.Pattern[str]
    contexts: frozenset[str]  # which target types this rule fires in


def _r(s: str, flags: int = 0) -> re.Pattern[str]:
    return re.compile(s, flags)


# Capabilities (one or more rules can produce the same capability)
CAP_NETWORK = "network-egress"
CAP_EXEC = "dynamic-exec"
CAP_ENV_READ = "env-read"
CAP_FS_SENSITIVE = "fs-sensitive"
CAP_PERSIST = "persistence-write"
CAP_DECODE = "decode-blob"
CAP_PLATFORM = "platform-check"
CAP_DOWNLOAD_RUN = "download-run"
CAP_HOMOGLYPH = "homoglyph"
CAP_BIDI = "bidi-control"
CAP_HIGH_ENTROPY = "high-entropy-blob"
CAP_OBFUSC_FUNC = "obfuscated-call"

CTX_SHELL = "shell"
CTX_JS = "js"
CTX_PY = "py"
CTX_RS = "rs"
CTX_NPM_SCRIPT = "npm-script"
CTX_BAT = "bat"
CTX_PS1 = "ps1"


# Build dangerous-function regex strings by concatenation so the file
# itself doesn't contain bare 'eval(' style tokens.
_PY_DANGER_FN = r"\b(" + _EVAL_NAME + r"|" + _EXEC_NAME + r"|" + _COMPILE_NAME + r")\s*\("
_JS_DANGER_FN = r"\b" + _EVAL_NAME + r"\s*\(|new\s+Function\s*\(|\bFunction\s*\(\s*['\"][^'\"]*['\"]\s*\)"


# Hardcoded ruleset. Order: network first, exec second, env third, then
# the rarer signals. Patterns are deliberately conservative - better to
# under-detect a benign pattern than over-detect on a generic match.
RULES: tuple[Rule, ...] = (
    # Network egress
    Rule("net-curl-wget", CAP_NETWORK, "shell network call",
         _r(r"\b(curl|wget|fetch)\s+[^\s|;&]+"),
         frozenset({CTX_SHELL, CTX_NPM_SCRIPT, CTX_BAT, CTX_PS1})),
    Rule("net-invoke-webrequest", CAP_NETWORK, "PowerShell network call",
         _r(r"\b(Invoke-WebRequest|iwr|Invoke-RestMethod|irm|Start-BitsTransfer)\b",
            re.IGNORECASE),
         frozenset({CTX_PS1, CTX_NPM_SCRIPT, CTX_SHELL})),
    Rule("net-node-http", CAP_NETWORK, "Node http(s) request",
         _r(r"require\(\s*['\"]https?['\"]\s*\)|"
            r"\bhttps?\.(get|request)\s*\(|"
            r"from\s+['\"]https?['\"]\s+import|"
            r"fetch\s*\(\s*['\"]https?:"),
         frozenset({CTX_JS, CTX_NPM_SCRIPT})),
    Rule("net-py-urllib", CAP_NETWORK, "Python network call",
         _r(r"\b(urllib\.request\.urlopen|urllib2\.urlopen|"
            r"requests\.(get|post|put|delete|head)|"
            r"http\.client\.HTTPSConnection|"
            r"httpx\.(get|post|Client)|socket\.socket)\b"),
         frozenset({CTX_PY})),
    Rule("net-rs-reqwest", CAP_NETWORK, "Rust HTTP call",
         _r(r"\b(reqwest::|ureq::|hyper::Client|TcpStream::connect)\b"),
         frozenset({CTX_RS})),
    Rule("net-dns-exfil", CAP_NETWORK, "DNS-based exfil pattern",
         _r(r"[a-zA-Z0-9+/=._-]{60,}\.[a-z]{2,}\.[a-z]{2,}"),
         frozenset({CTX_JS, CTX_PY, CTX_SHELL, CTX_NPM_SCRIPT})),

    # Dynamic code execution
    Rule("exec-eval-js", CAP_EXEC, "JavaScript dynamic-execution call",
         _r(_JS_DANGER_FN),
         frozenset({CTX_JS, CTX_NPM_SCRIPT})),
    Rule("exec-vm", CAP_EXEC, "Node vm module",
         _r(r"require\(\s*['\"]vm['\"]\s*\)|"
            r"require\(\s*['\"]vm2['\"]\s*\)|"
            r"node:vm['\"]"),
         frozenset({CTX_JS})),
    Rule("exec-child-process", CAP_EXEC, "Node child_process",
         _r(r"require\(\s*['\"]child_process['\"]\s*\)|"
            r"\bchild_process\.(exec|spawn|execSync|spawnSync|fork)\b"),
         frozenset({CTX_JS, CTX_NPM_SCRIPT})),
    Rule("exec-py-eval", CAP_EXEC, "Python dynamic-execution call",
         _r(_PY_DANGER_FN),
         frozenset({CTX_PY})),
    Rule("exec-py-subprocess", CAP_EXEC, "Python subprocess",
         _r(r"\b(subprocess\.(Popen|run|call|check_output|check_call)|"
            r"os\.(system|popen|execl|execv|execlp|execvp|execle|execve))\b"),
         frozenset({CTX_PY})),
    Rule("exec-rs-command", CAP_EXEC, "Rust Command spawn",
         _r(r"\bstd::process::Command::new\s*\(|\bCommand::new\s*\("),
         frozenset({CTX_RS})),
    Rule("exec-ps-iex", CAP_EXEC, "PowerShell Invoke-Expression",
         _r(r"\b(IEX|Invoke-Expression)\b", re.IGNORECASE),
         frozenset({CTX_PS1, CTX_NPM_SCRIPT, CTX_SHELL})),
    Rule("exec-shell-pipe-to-shell", CAP_DOWNLOAD_RUN,
         "Pipe network output directly to shell",
         _r(r"\b(curl|wget|fetch|iwr|irm)\b[^|;]{1,200}\|\s*"
            r"(bash|sh|zsh|cmd|powershell|pwsh|python|node)\b",
            re.IGNORECASE),
         # Fire regardless of host language: this pattern frequently
         # appears as a string literal passed to Command/subprocess and
         # is too distinctive to risk a false negative.
         frozenset({CTX_SHELL, CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT,
                    CTX_JS, CTX_PY, CTX_RS})),

    # Credential / env / fs
    Rule("env-read-js", CAP_ENV_READ, "Reads process.env",
         _r(r"\bprocess\.env\b"),
         frozenset({CTX_JS, CTX_NPM_SCRIPT})),
    Rule("env-read-py", CAP_ENV_READ, "Reads os.environ",
         _r(r"\b(os\.environ|os\.getenv\s*\()"),
         frozenset({CTX_PY})),
    Rule("env-read-rs", CAP_ENV_READ, "Reads std::env::var",
         _r(r"std::env::(var|vars)\s*\("),
         frozenset({CTX_RS})),
    Rule("env-read-shell", CAP_ENV_READ, "Reads shell env vars",
         _r(r"\$\{?[A-Z_][A-Z0-9_]{3,}\}?"),
         frozenset({CTX_SHELL, CTX_NPM_SCRIPT, CTX_BAT, CTX_PS1})),
    Rule("fs-aws-creds", CAP_FS_SENSITIVE, "Reads ~/.aws/credentials",
         _r(r"~?[/\\]?\.aws[/\\]credentials"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL,
                    CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT})),
    Rule("fs-ssh-key", CAP_FS_SENSITIVE, "Reads SSH private key",
         _r(r"~?[/\\]?\.ssh[/\\](id_rsa|id_ed25519|id_ecdsa|id_dsa)\b"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL,
                    CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT})),
    Rule("fs-npmrc-pypirc", CAP_FS_SENSITIVE, "Reads registry auth file",
         _r(r"\.npmrc\b|\.pypirc\b|\.netrc\b"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL,
                    CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT})),
    Rule("fs-wallet", CAP_FS_SENSITIVE, "Reads crypto wallet file",
         _r(r"\b(wallet\.dat|keystore[/\\]UTC--)\b"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL,
                    CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT})),
    Rule("fs-browser-data", CAP_FS_SENSITIVE, "Reads browser profile",
         _r(r"\b(Login Data|Cookies|Web Data|Local State)\b|"
            r"[\\/]Chrome[\\/]User Data[\\/]"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL,
                    CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT})),

    # Persistence
    Rule("persist-cron", CAP_PERSIST, "Writes crontab",
         _r(r"\bcrontab\s+-|/etc/cron\.|/var/spool/cron/"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL,
                    CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT})),
    Rule("persist-systemd", CAP_PERSIST, "Writes systemd unit",
         _r(r"/etc/systemd/system|/lib/systemd/system|"
            r"\bsystemctl\s+enable\b"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL, CTX_NPM_SCRIPT})),
    Rule("persist-rc", CAP_PERSIST, "Modifies shell rc file",
         _r(r"~/(\.bashrc|\.bash_profile|\.zshrc|\.profile)|"
            r"\$HOME/\.bashrc"),
         frozenset({CTX_SHELL, CTX_NPM_SCRIPT, CTX_PY, CTX_JS})),
    Rule("persist-registry-run", CAP_PERSIST, "Writes Windows Run key",
         _r(r"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run|"
            r"HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run",
            re.IGNORECASE),
         frozenset({CTX_PS1, CTX_BAT, CTX_PY, CTX_JS, CTX_NPM_SCRIPT})),
    Rule("persist-launchctl", CAP_PERSIST, "Writes launchd plist",
         _r(r"/Library/Launch(Daemons|Agents)/|"
            r"\blaunchctl\s+load\b"),
         frozenset({CTX_SHELL, CTX_NPM_SCRIPT, CTX_PY})),

    # Decoding / obfuscation
    Rule("decode-base64-js", CAP_DECODE, "Base64 decode",
         _r(r"\b(atob|Buffer\.from\s*\([^)]*['\"]base64['\"]\))"),
         frozenset({CTX_JS, CTX_NPM_SCRIPT})),
    Rule("decode-base64-py", CAP_DECODE, "Base64 decode",
         _r(r"\b(base64\.b64decode|base64\.standard_b64decode|"
            r"base64\.urlsafe_b64decode|"
            r"codecs\.decode\([^,]+,\s*['\"]base64['\"]\))"),
         frozenset({CTX_PY})),
    Rule("decode-hex-py", CAP_DECODE, "Hex decode",
         _r(r"\b(bytes\.fromhex|"
            r"codecs\.decode\([^,]+,\s*['\"]hex['\"]\))"),
         frozenset({CTX_PY})),
    Rule("decode-rot-py", CAP_DECODE, "ROT/escape decode",
         _r(r"codecs\.decode\([^,]+,\s*['\"]rot13['\"]\)"),
         frozenset({CTX_PY})),
    Rule("obfusc-string-fromcharcode", CAP_OBFUSC_FUNC,
         "String.fromCharCode chain",
         _r(r"String\.fromCharCode\s*\([^)]{20,}\)"),
         frozenset({CTX_JS, CTX_NPM_SCRIPT})),
    Rule("obfusc-char-arr", CAP_OBFUSC_FUNC,
         "Suspicious char-array literal",
         _r(r"\[\s*(?:0x[0-9a-fA-F]+\s*,\s*){10,}\]"),
         frozenset({CTX_JS, CTX_PY, CTX_NPM_SCRIPT})),

    # Targeted execution
    Rule("platform-check-js", CAP_PLATFORM, "process.platform check",
         _r(r"process\.platform\s*[=!]==?\s*['\"](win32|linux|darwin)['\"]"),
         frozenset({CTX_JS, CTX_NPM_SCRIPT})),
    Rule("platform-check-py", CAP_PLATFORM, "sys.platform check",
         _r(r"\b(sys\.platform|platform\.system\s*\(\s*\))\s*[=!]==?\s*['\"]"),
         frozenset({CTX_PY})),
    Rule("platform-check-rs", CAP_PLATFORM, "Rust target_os cfg",
         _r(r"#\[cfg\s*\(\s*target_os\s*="),
         frozenset({CTX_RS})),
    Rule("hostname-check", CAP_PLATFORM, "Hostname check",
         _r(r"\b(os\.hostname\s*\(\)|socket\.gethostname\s*\(\)|"
            r"hostname\s*==\s*['\"]|`hostname`)\b"),
         frozenset({CTX_JS, CTX_PY, CTX_NPM_SCRIPT, CTX_SHELL})),

    # Trojan-Source bidi controls (exact codepoints)
    Rule("bidi-control", CAP_BIDI, "Unicode bidi control char",
         _r("[‪-‮⁦-⁩]"),
         frozenset({CTX_JS, CTX_PY, CTX_RS, CTX_SHELL,
                    CTX_NPM_SCRIPT, CTX_PS1, CTX_BAT})),

    # Self-replication
    Rule("self-copy-suspicious", CAP_PERSIST, "Self-copy to system path",
         _r(r"cp\s+\S+\s+(/usr/(local/)?bin|/etc|/opt)\b"),
         frozenset({CTX_SHELL, CTX_NPM_SCRIPT})),
)


# Cyrillic / Greek look-alikes commonly used for homoglyph attacks in
# Latin-context identifiers.
HOMOGLYPH_LOOKALIKES: frozenset[str] = frozenset(
    "АВЕКМНОРСТХ"
    "аеорсух"
    "ΑΒΕΖΗΙΚΜΝΟΡ"
    "ΤΥΧοα"
)


def _detect_homoglyph(text: str) -> bool:
    """Latin-script file containing visually identical Cyrillic/Greek chars."""
    for ch in text:
        if ord(ch) > 127 and ch in HOMOGLYPH_LOOKALIKES:
            return True
    return False


# Entropy / encoded-payload detection
_LONG_STRING_RE = re.compile(r"""(?xs)
    (?P<q>['"`])
    (?P<body>[^'"`\\\n]{200,})
    (?P=q)
""")

_BASE64_RE = re.compile(r"^[A-Za-z0-9+/=_-]+$")
_HEX_RE = re.compile(r"^[0-9a-fA-F]+$")


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts: dict[str, int] = {}
    for c in s:
        counts[c] = counts.get(c, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def _find_encoded_blobs(text: str) -> list[tuple[str, float, int]]:
    """Return [(kind, entropy, length), ...] for suspicious long string literals."""
    out: list[tuple[str, float, int]] = []
    for m in _LONG_STRING_RE.finditer(text):
        body = m.group("body")
        if len(body) < 200:
            continue
        ent = _shannon_entropy(body)
        if ent < 4.0:
            continue
        if _BASE64_RE.match(body):
            out.append(("base64", ent, len(body)))
        elif _HEX_RE.match(body) and len(body) > 400:
            out.append(("hex", ent, len(body)))
        elif ent >= 5.0:
            out.append(("high-entropy", ent, len(body)))
    return out


# Target discovery
@dataclass
class ScriptTarget:
    """One thing to analyze: either a script body string or a referenced file."""
    location: str               # human-readable location label
    body: str                   # the actual text to analyze
    contexts: frozenset[str]    # which rule contexts apply
    lifecycle: str = ""         # npm hook name / "setup.py" / "build.rs"
    raw_npm_value: str = ""     # original script value for allowlisting


def _normalize_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def _resolve_referenced_file(repo_dir: Path, manifest_dir: Path,
                             script_value: str) -> Path | None:
    """Try to find a local script file referenced by an npm script value."""
    try:
        parts = shlex.split(script_value, posix=True) if script_value else []
    except ValueError:
        return None
    for tok in parts:
        if tok.startswith("-"):
            continue
        if (tok.endswith(".js") or tok.endswith(".sh") or tok.endswith(".bat")
                or tok.endswith(".ps1") or tok.endswith(".py")
                or tok.endswith(".cjs") or tok.endswith(".mjs")):
            try:
                candidate = (manifest_dir / tok).resolve()
                if candidate.is_file() and repo_dir.resolve() in (candidate, *candidate.parents):
                    return candidate
            except (OSError, ValueError):
                continue
    return None


def _ext_to_context(path: Path) -> frozenset[str]:
    ext = path.suffix.lower()
    if ext in {".js", ".cjs", ".mjs", ".ts"}:
        return frozenset({CTX_JS})
    if ext == ".py":
        return frozenset({CTX_PY})
    if ext == ".rs":
        return frozenset({CTX_RS})
    if ext == ".sh":
        return frozenset({CTX_SHELL})
    if ext == ".bat":
        return frozenset({CTX_BAT, CTX_SHELL})
    if ext == ".ps1":
        return frozenset({CTX_PS1, CTX_SHELL})
    return frozenset({CTX_SHELL})


def _read_text_safe(path: Path, max_bytes: int = 1_000_000) -> str:
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            return f.read(max_bytes)
    except OSError:
        return ""


def find_install_scripts(repo_dir: Path) -> list[ScriptTarget]:
    """Walk a repo and return every install-time script target worth analyzing."""
    targets: list[ScriptTarget] = []

    # npm
    for pj in repo_dir.rglob("package.json"):
        try:
            data = json.loads(_read_text_safe(pj))
        except (json.JSONDecodeError, ValueError):
            continue
        if not isinstance(data, dict):
            continue
        scripts = data.get("scripts") or {}
        if not isinstance(scripts, dict):
            continue
        rel_manifest = pj.relative_to(repo_dir).as_posix()
        for hook, value in scripts.items():
            if hook not in NPM_LIFECYCLE_HOOKS:
                continue
            if not isinstance(value, str):
                continue
            value_norm = _normalize_ws(value)
            targets.append(ScriptTarget(
                location=f"{rel_manifest}#scripts.{hook}",
                body=value,
                contexts=frozenset({CTX_NPM_SCRIPT, CTX_SHELL}),
                lifecycle=hook,
                raw_npm_value=value_norm,
            ))
            ref = _resolve_referenced_file(repo_dir, pj.parent, value)
            if ref is not None:
                ref_body = _read_text_safe(ref)
                if ref_body:
                    targets.append(ScriptTarget(
                        location=ref.relative_to(repo_dir).as_posix(),
                        body=ref_body,
                        contexts=_ext_to_context(ref),
                        lifecycle=f"npm:{hook} -> {ref.name}",
                    ))

    # PyPI setup.py
    for sp in repo_dir.rglob("setup.py"):
        body = _read_text_safe(sp)
        if not body:
            continue
        targets.append(ScriptTarget(
            location=sp.relative_to(repo_dir).as_posix(),
            body=body,
            contexts=frozenset({CTX_PY}),
            lifecycle="pypi:setup.py",
        ))

    # Cargo build.rs
    for br in repo_dir.rglob("build.rs"):
        body = _read_text_safe(br)
        if not body:
            continue
        targets.append(ScriptTarget(
            location=br.relative_to(repo_dir).as_posix(),
            body=body,
            contexts=frozenset({CTX_RS}),
            lifecycle="cargo:build.rs",
        ))

    return targets


# Analysis
@dataclass
class TriggerHit:
    rule_id: str
    capability: str
    title: str


@dataclass
class ScriptAnalysis:
    target: ScriptTarget
    hits: list[TriggerHit] = field(default_factory=list)
    encoded_blobs: list[tuple[str, float, int]] = field(default_factory=list)
    has_homoglyph: bool = False
    allowlisted: bool = False

    @property
    def capabilities(self) -> set[str]:
        return {h.capability for h in self.hits}


def analyze_script(target: ScriptTarget) -> ScriptAnalysis:
    """Run all applicable rules against a target."""
    analysis = ScriptAnalysis(target=target)

    if (CTX_NPM_SCRIPT in target.contexts
            and target.raw_npm_value in NPM_BENIGN_VALUES):
        analysis.allowlisted = True
        return analysis

    body = target.body
    for rule in RULES:
        if not (rule.contexts & target.contexts):
            continue
        if rule.pattern.search(body):
            analysis.hits.append(TriggerHit(rule.id, rule.capability, rule.title))

    analysis.encoded_blobs = _find_encoded_blobs(body)
    if analysis.encoded_blobs:
        analysis.hits.append(TriggerHit(
            "encoded-blob", CAP_HIGH_ENTROPY,
            f"High-entropy / encoded blob ({len(analysis.encoded_blobs)} found)"))

    if _detect_homoglyph(body):
        analysis.has_homoglyph = True
        analysis.hits.append(TriggerHit(
            "homoglyph-identifier", CAP_HOMOGLYPH,
            "Cyrillic/Greek homoglyph in Latin context"))

    return analysis


# Composition rules
@dataclass(frozen=True)
class PatternRule:
    """Capability set -> severity + title + recommendation."""
    required: frozenset[str]
    severity: str
    title: str
    detail_tmpl: str
    recommendation: str


COMPOSITION_PATTERNS: tuple[PatternRule, ...] = (
    PatternRule(
        frozenset({CAP_DOWNLOAD_RUN}),
        "critical",
        "Install script pipes network output directly to shell",
        "Pattern 'curl ... | sh' (or equivalent) inside an install-time "
        "script. This is the canonical loader pattern used by malicious "
        "packages - it lets the attacker change the payload at any time.",
        "Refuse to install this package. If publishing this yourself, "
        "embed the script and verify its hash; never pipe a remote URL "
        "to a shell at install time.",
    ),
    PatternRule(
        frozenset({CAP_DECODE, CAP_EXEC}),
        "critical",
        "Install script decodes a blob and runs it",
        "The script combines a decode operation ({hits}) with dynamic "
        "code execution. This is the standard pattern for hiding the "
        "real payload from static review.",
        "Block this package. Decoded-then-run payloads are the "
        "defining shape of supply-chain malware (event-stream, "
        "ua-parser-js).",
    ),
    PatternRule(
        frozenset({CAP_NETWORK, CAP_EXEC}),
        "critical",
        "Install script combines network egress with code execution",
        "The script makes a network call AND can run commands. The "
        "two together imply download-then-run, even if no explicit pipe "
        "is present.",
        "Inspect the script byte-for-byte. If the URL is fetched at "
        "install time and the response influences any spawned command, "
        "treat as malicious.",
    ),
    PatternRule(
        frozenset({CAP_NETWORK, CAP_ENV_READ}),
        "high",
        "Install script exfiltrates environment variables",
        "The script reads environment variables AND makes outbound "
        "network calls. Environment variables routinely hold "
        "credentials (AWS_*, GITHUB_TOKEN, NPM_TOKEN, DATABASE_URL).",
        "Audit the package's install script. If the network destination "
        "is not a public registry or known build service, treat as "
        "credential-stealer and rotate any exposed tokens.",
    ),
    PatternRule(
        frozenset({CAP_FS_SENSITIVE, CAP_NETWORK}),
        "high",
        "Install script reads sensitive files and calls network",
        "The script touches a credential or wallet file ({hits}) AND "
        "makes an outbound call. Classic info-stealer composition.",
        "Block install. Rotate any credentials that could be on the "
        "developer's machine if the script has already run.",
    ),
    PatternRule(
        frozenset({CAP_PLATFORM, CAP_NETWORK}),
        "high",
        "OS-targeted install script makes network calls",
        "The script branches on platform/OS/hostname AND makes a "
        "network call. Targeted payloads are the standard pattern for "
        "avoiding detection on non-target machines.",
        "Inspect every branch the script takes; pay special attention "
        "to the production-like / Linux-server arm.",
    ),
    PatternRule(
        frozenset({CAP_BIDI}),
        "high",
        "Unicode bidi-control character in install script (Trojan-Source)",
        "A right-to-left override or similar bidi control codepoint "
        "appears in install-time code. This was the technique used to "
        "hide the xz-utils backdoor's intent from human review.",
        "Reject the file. Bidi controls in source code have no "
        "legitimate use in install scripts.",
    ),
    PatternRule(
        frozenset({CAP_HOMOGLYPH}),
        "high",
        "Cyrillic/Greek homoglyph in install script identifier",
        "An identifier or string contains characters that visually "
        "match Latin but are a different Unicode codepoint. This is "
        "used to shadow legitimate names like 'react' vs 'reаct'.",
        "Refuse to install. Normalize identifiers to NFKC and compare "
        "against the expected ASCII spelling.",
    ),
    PatternRule(
        frozenset({CAP_PERSIST}),
        "high",
        "Install script writes a persistence mechanism",
        "Crontab / systemd unit / Run key / shell rc modification "
        "inside install-time code.",
        "No legitimate install script should write persistence. "
        "Refuse the package.",
    ),
    PatternRule(
        frozenset({CAP_HIGH_ENTROPY, CAP_EXEC}),
        "high",
        "High-entropy blob plus dynamic exec",
        "Script contains a long high-entropy literal AND a way to "
        "evaluate code. This is the textbook packed-payload shape.",
        "Decode the blob manually and review what it does before "
        "trusting the package.",
    ),
)


def _compose_findings(analysis: ScriptAnalysis, repo: str) -> list[Finding]:
    """Walk composition patterns; emit one Finding per matched pattern."""
    if analysis.allowlisted or not analysis.hits:
        return []
    caps = analysis.capabilities
    findings: list[Finding] = []
    matched_pattern = False
    for pat in COMPOSITION_PATTERNS:
        if pat.required.issubset(caps):
            matched_pattern = True
            hit_titles = ", ".join(
                sorted({h.title for h in analysis.hits
                        if h.capability in pat.required}))
            findings.append(Finding(
                repo=repo,
                severity=pat.severity,
                category="installscript",
                title=pat.title,
                location=analysis.target.location,
                detail=pat.detail_tmpl.format(hits=hit_titles),
                recommendation=pat.recommendation,
                method="installscript:composition",
            ))
    if not matched_pattern:
        cap_list = ", ".join(sorted(caps))
        hit_list = ", ".join(sorted({h.title for h in analysis.hits}))
        severity = "medium" if (
            CAP_NETWORK in caps or CAP_EXEC in caps or CAP_DECODE in caps
        ) else "low"
        findings.append(Finding(
            repo=repo,
            severity=severity,
            category="installscript",
            title=f"Install-time script capability: {cap_list}",
            location=analysis.target.location,
            detail=(
                f"Script fires the following indicators: {hit_list}. "
                f"No specific malicious composition matched, but the "
                f"capabilities present in an install-time hook deserve "
                f"review."
            ),
            recommendation=(
                "Confirm each capability is necessary for the install "
                "step. If any is incidental (debug logging, leftover "
                "boilerplate), the package author should remove it."
            ),
            method="installscript:single-cap",
        ))
    return findings


# Public API
def scan_repo_for_install_scripts(repo_dir: Path, repo_name: str) -> list[Finding]:
    """Walk a repo and return Findings for every suspicious install script."""
    out: list[Finding] = []
    targets = find_install_scripts(repo_dir)
    for tgt in targets:
        analysis = analyze_script(tgt)
        out.extend(_compose_findings(analysis, repo_name))
    return out
