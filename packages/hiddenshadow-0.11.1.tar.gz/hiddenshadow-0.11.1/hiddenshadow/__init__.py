"""hiddenshadow — license + SBOM + dependency analyzer.

Scans any directory tree of cloned source repositories and produces:
    - Per-repo CycloneDX SBOMs
    - Aggregated dependency rollup
    - Findings list (license violations, unrecognized licenses, etc.)
       with severity and recommended fix per finding.

The scanner is a DarkShadowSec LLC internal tool but operates on any source tree.
"""
__version__ = "0.11.1"
