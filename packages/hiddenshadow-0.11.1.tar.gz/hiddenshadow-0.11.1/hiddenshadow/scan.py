"""Top-level scan orchestration.

Walks a directory tree of cloned repos (one repo per subdirectory under
each top-level category), runs license + manifest detection, emits per-repo
SBOMs, aggregates a dependency rollup, and produces findings.
"""
from __future__ import annotations
import csv
import json
import os
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Any

from .licenses import (
    LICENSE_FILE_NAMES, NON_AUTHORITATIVE_LICENSE_PATHS,
    detect_license_from_text, classify, is_authoritative_license_path,
)
from .manifests import (
    SKIP_DIRS, find_manifests, parse_all_manifests, Dep,
)
from .findings import (
    Finding,
    analyze_root_license, analyze_nested_licenses, analyze_spdx_headers,
    analyze_manifests, analyze_dep_rollup,
)
from .sbom import emit as emit_sbom
from .dual_license import detect_dual_license_dirs, DualLicense
from .metadata_aware import load_metadata_dispositions, DocumentedDisposition
from .secrets import scan_repo_for_secrets
from .sast import scan_repo_for_sast
from .behavior import (
    scan_repo_for_behavior, behavior_summary, behavior_highlights,
)
from .signatures import (
    SignatureRecord, scan_repo_for_signatures, records_to_findings,
)
from .install_scripts import scan_repo_for_install_scripts
from . import iac as iac_mod
from . import containers as containers_mod

import re

# SPDX header pattern in source files
_SPDX_HEADER_RE = re.compile(
    r"SPDX-License-Identifier\s*:\s*([A-Za-z0-9.\-+()\s]+?)(?:\s*$|\*/|-->|\n)",
)
_SPDX_FILE_EXTS = {
    ".py", ".rs", ".go", ".java", ".js", ".ts", ".jsx", ".tsx",
    ".c", ".h", ".cpp", ".hpp", ".cc", ".cs", ".rb", ".php",
    ".scala", ".kt", ".swift", ".m", ".mm",
}


@dataclass
class RepoScan:
    repo: str
    category: str
    root_path: str
    declared_license_files: list[dict] = field(default_factory=list)
    nested_license_files: list[dict] = field(default_factory=list)
    spdx_header_counts: dict[str, int] = field(default_factory=dict)
    manifests_found: dict[str, int] = field(default_factory=dict)
    direct_deps: list[Dep] = field(default_factory=list)
    self_declared_license: str | None = None
    findings: list[Finding] = field(default_factory=list)
    dual_license_dirs: dict[str, DualLicense] = field(default_factory=dict)
    # Per-subcategory counts of behavioral observations (net/fs/proc/env/...)
    behavior_profile: dict[str, int] = field(default_factory=dict)
    # Binary library signature records (one per inspected file)
    signature_records: list[SignatureRecord] = field(default_factory=list)


def _find_license_files(repo_root: Path) -> list[tuple[Path, bool]]:
    found: list[tuple[Path, bool]] = []
    for dirpath, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if not LICENSE_FILE_NAMES.match(fn):
                continue
            full = Path(dirpath) / fn
            rel_parts = full.relative_to(repo_root).parts
            authoritative = is_authoritative_license_path(rel_parts)
            found.append((full, authoritative))
    return found


def _sample_spdx_headers(repo_root: Path, *, max_files: int = 200) -> dict[str, int]:
    counts: dict[str, int] = {}
    seen = 0
    for dirpath, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            ext = Path(fn).suffix.lower()
            if ext not in _SPDX_FILE_EXTS:
                continue
            seen += 1
            if seen > max_files:
                return counts
            try:
                with (Path(dirpath) / fn).open("r", encoding="utf-8", errors="ignore") as f:
                    head = f.read(4096)
                m = _SPDX_HEADER_RE.search(head)
                if m:
                    spdx = m.group(1).strip()
                    counts[spdx] = counts.get(spdx, 0) + 1
            except (OSError, UnicodeDecodeError):
                pass
    return counts


def scan_repo(repo_dir: Path, category: str, name: str,
              documented_dispositions: dict | None = None,
              detect_secrets: bool = True,
              detect_sast: bool = True,
              detect_behavior: bool = True,
              detect_signatures: bool = True,
              detect_install_scripts: bool = True,
              detect_iac: bool = False,
              detect_containers: bool = False) -> RepoScan:
    rs = RepoScan(repo=name, category=category, root_path=str(repo_dir))
    documented_dispositions = documented_dispositions or {}

    # ── License files ──
    root_license: str | None = None
    for lf, authoritative in _find_license_files(repo_dir):
        try:
            text = lf.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        spdx = detect_license_from_text(text)
        rel = lf.relative_to(repo_dir).as_posix()
        depth = rel.count("/")
        record = {
            "path": rel, "spdx": spdx or "unknown", "depth": depth,
            "size_bytes": lf.stat().st_size,
            "authoritative": authoritative,
        }
        if depth == 0:
            rs.declared_license_files.append(record)
            if root_license is None and spdx:
                root_license = spdx
                rs.self_declared_license = spdx
        else:
            rs.nested_license_files.append(record)

    # ── SPDX headers ──
    rs.spdx_header_counts = _sample_spdx_headers(repo_dir)

    # ── Manifests + deps ──
    manifests = find_manifests(repo_dir)
    rs.manifests_found = {k: len(v) for k, v in manifests.items() if v}
    deps, manifest_self_lic = parse_all_manifests(manifests)
    rs.direct_deps = deps
    if not rs.self_declared_license and manifest_self_lic:
        rs.self_declared_license = manifest_self_lic

    # ── Dual-license dirs (informs analyze_nested_licenses) ──
    all_license_records = list(rs.declared_license_files) + list(rs.nested_license_files)
    rs.dual_license_dirs = detect_dual_license_dirs(all_license_records, repo_dir)

    # ── Findings ──
    rs.findings.extend(analyze_root_license(name, rs.declared_license_files))
    rs.findings.extend(analyze_nested_licenses(
        name, root_license, rs.nested_license_files,
        dual_license_dirs=rs.dual_license_dirs,
        documented_dispositions=documented_dispositions,
    ))
    rs.findings.extend(analyze_spdx_headers(name, root_license, rs.spdx_header_counts))
    rs.findings.extend(analyze_manifests(name, rs.manifests_found))

    # ── Cleartext secrets / credentials ──
    if detect_secrets:
        rs.findings.extend(scan_repo_for_secrets(repo_dir, name))

    # ── Code-quality / SAST rules ──
    if detect_sast:
        rs.findings.extend(scan_repo_for_sast(repo_dir, name))

    # ── Behavioral inference (would-run-time profile) ──
    if detect_behavior:
        behavior_findings = scan_repo_for_behavior(repo_dir, name)
        rs.findings.extend(behavior_findings)
        rs.behavior_profile = behavior_summary(behavior_findings)

    # ── Binary library signature inspection ──
    # Offline pass only here. Origin annotation + Rekor lookups happen
    # later in run() so we can batch the network calls across repos.
    if detect_signatures:
        rs.signature_records = scan_repo_for_signatures(repo_dir, name)

    # ── Install / build script supply-chain analysis ──
    if detect_install_scripts:
        rs.findings.extend(scan_repo_for_install_scripts(repo_dir, name))

    # ── Terraform / IaC scan (opt-in via --detect-iac) ──
    if detect_iac:
        rs.findings.extend(iac_mod.scan_path_as_findings(repo_dir, name))

    # ── Container scan (opt-in via --detect-containers) ──
    # Defaults to offline (no layer fetches) when invoked from the main
    # scan flow; the dedicated `containerscan` command runs full layer +
    # CVE.
    if detect_containers:
        rs.findings.extend(containers_mod.scan_path_as_findings(
            repo_dir, name, scan_layers=False, cve_lookup=False))

    return rs


# Project / tooling markers — exact filenames that always signal "repo".
_REPO_TOOLING_MARKERS = ("METADATA.yaml", ".git", "BUILD.darkshadow")

# Manifest markers — a directory containing one of these is something we
# can SBOM/scan even if it lacks a LICENSE file (e.g. Rust crates whose
# only license info is LICENSE-MIT + LICENSE-APACHE, or Node packages
# that declare license in package.json, etc.).
_REPO_MANIFEST_MARKERS = (
    "package.json",
    "Cargo.toml",
    "go.mod",
    "pyproject.toml",
    "setup.py", "setup.cfg",
    "pom.xml",
    "build.gradle", "build.gradle.kts",
    "Gemfile",
    "requirements.txt",
)


def _looks_like_repo(d: Path) -> bool:
    """A directory is a repo if it contains:
       - a project / tooling marker (.git, METADATA.yaml, BUILD.darkshadow), or
       - a recognized manifest (package.json, Cargo.toml, go.mod, ...), or
       - any file matching LICENSE_FILE_NAMES (LICENSE, LICENCE, COPYING,
         COPYRIGHT, NOTICE, UNLICENSE — with or without an extension, and
         including dual-license variants like LICENSE-MIT, LICENSE.BSD,
         COPYING.LESSER).
    """
    for m in _REPO_TOOLING_MARKERS:
        if (d / m).exists():
            return True
    for m in _REPO_MANIFEST_MARKERS:
        if (d / m).exists():
            return True
    try:
        with os.scandir(d) as it:
            for entry in it:
                if not entry.is_file():
                    continue
                name = entry.name
                if LICENSE_FILE_NAMES.match(name):
                    return True
                # Python: requirements-*.txt is a manifest convention.
                if name.startswith("requirements") and name.endswith(".txt"):
                    return True
    except OSError:
        return False
    return False


def discover_repos(source_root: Path) -> list[tuple[str, str, Path]]:
    """Walk a source tree and return (category, name, path) tuples.

    Heuristic for "is this a repo":
      A directory is a repo if it contains any of: .git, METADATA.yaml,
      LICENSE/LICENSE.txt/LICENSE.md, COPYING, or BUILD.darkshadow.

    Layout cases handled:
      - source_root IS a single repo               → return one tuple
      - source_root contains repos directly        → category = "(root)"
      - source_root contains category dirs of repos → category = the category name
    """
    repos: list[tuple[str, str, Path]] = []
    if not source_root.exists():
        return repos
    # Case 1: source_root is itself a repo
    if _looks_like_repo(source_root):
        repos.append(("(root)", source_root.name, source_root))
        return repos
    for child in sorted(source_root.iterdir()):
        if not child.is_dir() or child.name.startswith("_"):
            continue
        if child.name in SKIP_DIRS:
            continue
        if _looks_like_repo(child):
            # Case 2: direct repo child
            repos.append(("(root)", child.name, child))
        else:
            # Case 3: category dir — recurse one level
            for sub in sorted(child.iterdir()):
                if not sub.is_dir() or sub.name.startswith("_"):
                    continue
                if sub.name in SKIP_DIRS:
                    continue
                repos.append((child.name, sub.name, sub))
    return repos


def run(source_root: Path, output_root: Path,
        only: list[str] | None = None,
        skip: list[str] | None = None,
        quiet: bool = False,
        respect_metadata: bool = True,
        detect_secrets: bool = True,
        detect_sast: bool = True,
        detect_cves: bool = True,
        detect_behavior: bool = True,
        detect_signatures: bool = True,
        signature_network_lookup: bool = True,
        detect_install_scripts: bool = True,
        detect_iac: bool = False,
        detect_containers: bool = False,
        progress_callback: Callable[[dict[str, Any]], None] | None = None) -> dict:
    """Scan a directory tree of cloned repos. Returns the summary dict.

    If respect_metadata=True (the default), each repo's METADATA.yaml is
    loaded and findings whose location matches a documented entry in
    license.files_with_other_licenses are suppressed (replaced with a
    single info-level "Documented in METADATA" entry). Pass False for a
    raw scan that ignores METADATA.

    progress_callback, if given, is invoked with event dicts at each
    phase boundary. Events all carry a "type" key; current types:
        {"type": "discovery_start", "source_root": str}
        {"type": "discovered", "total": int}
        {"type": "repo_start", "index": int, "total": int,
         "category": str, "name": str}
        {"type": "repo_done", "index": int, "total": int,
         "category": str, "name": str,
         "findings": {"critical": int, "high": int, ...},
         "duration_s": float}
        {"type": "phase", "name": str, "message": str}
        {"type": "complete", "summary": dict}
    Exceptions raised in the callback are swallowed.
    """
    def emit(event: dict[str, Any]) -> None:
        if progress_callback is None:
            return
        try:
            progress_callback(event)
        except Exception:
            pass

    output_root.mkdir(parents=True, exist_ok=True)
    log_dir = output_root / "_logs"
    sbom_dir = output_root / "sboms"
    log_dir.mkdir(exist_ok=True)
    sbom_dir.mkdir(exist_ok=True)

    started = time.time()

    emit({"type": "discovery_start", "source_root": str(source_root)})
    all_repos = discover_repos(source_root)
    if only:
        all_repos = [r for r in all_repos if r[1] in only]
    if skip:
        all_repos = [r for r in all_repos if r[1] not in skip]
    emit({"type": "discovered", "total": len(all_repos)})

    # Load documented dispositions per-category. Each top-level category
    # (forked-oss, foundational-infra, ...) may contain METADATA files.
    dispositions: dict[str, list] = {}
    if respect_metadata:
        for child in source_root.iterdir():
            if not child.is_dir() or child.name.startswith("_"):
                continue
            dispositions.update(load_metadata_dispositions(child))
        # Also try direct subdirs (in case source_root IS the third_party dir)
        dispositions.update(load_metadata_dispositions(source_root))

    if not quiet:
        print(f"Source root: {source_root}")
        print(f"Output root: {output_root}")
        print(f"Scanning {len(all_repos)} repos...")
        if respect_metadata and dispositions:
            total = sum(len(v) for v in dispositions.values())
            print(f"METADATA dispositions loaded: {total} entries across "
                  f"{len(dispositions)} repos.")
        print()

    all_findings: list[Finding] = []
    summaries: list[dict] = []
    all_deps: list[dict] = []
    all_signature_records: list[SignatureRecord] = []

    for i, (cat, name, repo_dir) in enumerate(all_repos, start=1):
        if not quiet:
            print(f"  [{i:2}/{len(all_repos)}] {cat}/{name}")
        emit({"type": "repo_start", "index": i, "total": len(all_repos),
              "category": cat, "name": name})
        t0 = time.time()
        rs = scan_repo(repo_dir, cat, name,
                       documented_dispositions=dispositions,
                       detect_secrets=detect_secrets,
                       detect_sast=detect_sast,
                       detect_behavior=detect_behavior,
                       detect_signatures=detect_signatures,
                       detect_install_scripts=detect_install_scripts,
                       detect_iac=detect_iac,
                       detect_containers=detect_containers)
        all_signature_records.extend(rs.signature_records)
        # Stream a few behavioral observations per repo so the UI can
        # render the scan as a live monitor (Phase 3 of the design).
        if detect_behavior:
            for hl in behavior_highlights(rs.findings, limit=6):
                emit({"type": "behavior_observed",
                      "repo": name, "category": cat,
                      "subcat": hl["subcat"], "severity": hl["severity"],
                      "title": hl["title"], "location": hl["location"]})
        emit_sbom(rs.repo, rs.self_declared_license, rs.direct_deps,
                  sbom_dir / f"{name}.cdx.json")
        for d in rs.direct_deps:
            all_deps.append({
                "repo": name, "category": cat, "name": d.name,
                "version": d.version or "",
                "declared_license": d.declared_license or "",
                "package_manager": d.package_manager,
                "source_manifest": d.source_manifest,
            })
        all_findings.extend(rs.findings)
        repo_sev = {
            sev: sum(1 for f in rs.findings if f.severity == sev)
            for sev in ("critical", "high", "medium", "low", "info")
        }
        emit({"type": "repo_done", "index": i, "total": len(all_repos),
              "category": cat, "name": name,
              "findings": repo_sev,
              "behavior": rs.behavior_profile,
              "behavior_highlights": behavior_highlights(rs.findings, limit=6),
              "duration_s": round(time.time() - t0, 2)})
        summaries.append({
            "repo": name, "category": cat,
            "self_license": rs.self_declared_license or "",
            "license_files": (
                len(rs.declared_license_files) + len(rs.nested_license_files)
            ),
            "spdx_headers_total": sum(rs.spdx_header_counts.values()),
            "manifests": json.dumps(rs.manifests_found),
            "direct_deps": len(rs.direct_deps),
            "findings_critical": sum(1 for f in rs.findings if f.severity == "critical"),
            "findings_high":     sum(1 for f in rs.findings if f.severity == "high"),
            "findings_medium":   sum(1 for f in rs.findings if f.severity == "medium"),
            "findings_low":      sum(1 for f in rs.findings if f.severity == "low"),
            "findings_info":     sum(1 for f in rs.findings if f.severity == "info"),
            "behavior_profile":  json.dumps(rs.behavior_profile),
            "scan_duration_s": round(time.time() - t0, 2),
        })

    # ── Library rollup ──
    emit({"type": "phase", "name": "rollup",
          "message": "Aggregating dependency rollup..."})
    rollup_map: dict[tuple[str, str], dict] = {}
    for d in all_deps:
        key = (d["name"], d["package_manager"])
        if key not in rollup_map:
            rollup_map[key] = {
                "name": d["name"], "package_manager": d["package_manager"],
                "occurrences": 0, "repos": set(), "versions": set(),
                "declared_license": d["declared_license"],
            }
        rollup_map[key]["occurrences"] += 1
        rollup_map[key]["repos"].add(d["repo"])
        if d["version"]:
            rollup_map[key]["versions"].add(d["version"])
    rollup_list = sorted(
        [
            {
                "name": v["name"], "package_manager": v["package_manager"],
                "occurrences": v["occurrences"],
                "repo_count": len(v["repos"]),
                "versions": ", ".join(sorted(v["versions"]))[:200],
                "repos": ", ".join(sorted(v["repos"]))[:200],
                "declared_license": v["declared_license"] or "",
            }
            for v in rollup_map.values()
        ],
        key=lambda r: -r["occurrences"],
    )
    all_findings.extend(analyze_dep_rollup(rollup_list))

    # ── Library signature audit ──
    declared_audit_rows: list[dict] = []
    if detect_signatures and all_signature_records:
        emit({"type": "phase", "name": "signatures",
              "message": f"Auditing signatures on {len(all_signature_records)} binary libraries..."})
        try:
            from . import signatures_origin as sig_origin
            sig_origin.annotate_origins_from_paths(all_signature_records)
            if signature_network_lookup:
                cache_dir = output_root / "_cache"
                sig_origin.annotate_origins_via_registry(
                    all_signature_records, cache_dir,
                    rekor_lookup=True,
                )
                if rollup_list:
                    declared_audit_rows = sig_origin.audit_declared_deps(
                        rollup_list, cache_dir)
                    all_findings.extend(
                        sig_origin.declared_deps_to_findings(declared_audit_rows)
                    )
        except Exception as exc:  # pragma: no cover — defensive
            emit({"type": "phase", "name": "signatures",
                  "message": f"Signature origin lookup failed: {exc}"})
        all_findings.extend(records_to_findings(all_signature_records))

    # ── CVE lookup against OSV.dev ──
    if detect_cves and rollup_list:
        emit({"type": "phase", "name": "cves",
              "message": f"Querying OSV.dev for CVEs in {len(rollup_list)} libraries..."})
        try:
            from . import osv as osv_mod
            cache_dir = output_root / "_cache"
            cve_findings, _stats = osv_mod.scan_cves(rollup_list, cache_dir)
            for cf in cve_findings:
                title = cf.get("cve_id") or cf.get("vuln_id") or "(unknown vuln)"
                summary = cf.get("summary") or "(no summary)"
                refs = cf.get("references") or ""
                fix = cf.get("fix_versions") or ""
                cvss = cf.get("cvss_score")
                detail_lines = [
                    f"{cf['package']}@{cf['version']} ({cf['ecosystem']})",
                    summary,
                ]
                if cvss not in ("", None):
                    detail_lines.append(f"CVSS: {cvss}")
                if fix:
                    detail_lines.append(f"Fixed in: {fix}")
                if refs:
                    detail_lines.append(f"Refs: {refs}")
                affected_repos = (cf.get("repos") or "").strip()
                repo_label = affected_repos.split(",", 1)[0].strip() if affected_repos else "(rollup)"
                if "," in affected_repos:
                    repo_label += f" (+{affected_repos.count(',')} more)"
                all_findings.append(Finding(
                    repo=repo_label,
                    severity=cf.get("severity") or "info",
                    category="cve",
                    title=f"{title}: {cf['package']} {cf['version']}",
                    location=f"{cf['package_manager']}:{cf['package']}@{cf['version']}",
                    detail=" — ".join(detail_lines),
                    recommendation=osv_mod.cve_recommendation(cf),
                    method="cve:osv.dev",
                ))
            if not quiet:
                print(f"  CVE findings:      {len(cve_findings)}")
        except Exception as exc:  # pragma: no cover — network failures
            emit({"type": "phase", "name": "cves",
                  "message": f"CVE lookup failed: {exc}"})

    # ── Write artifacts ──
    emit({"type": "phase", "name": "writing",
          "message": "Writing scan artifacts..."})
    findings_data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_root": str(source_root),
        "repos_scanned": len(all_repos),
        "total_findings": len(all_findings),
        "by_severity": {
            sev: sum(1 for f in all_findings if f.severity == sev)
            for sev in ("critical", "high", "medium", "low", "info")
        },
        "findings": [asdict(f) for f in all_findings],
        "summaries": summaries,
    }
    (log_dir / "scan-findings.json").write_text(
        json.dumps(findings_data, indent=2), encoding="utf-8")

    sum_path = log_dir / "scan-summary.csv"
    cols = ["repo", "category", "self_license", "license_files",
            "spdx_headers_total", "manifests", "direct_deps",
            "findings_critical", "findings_high", "findings_medium",
            "findings_low", "findings_info", "behavior_profile",
            "scan_duration_s"]
    with sum_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for s in summaries:
            w.writerow(s)

    rollup_path = log_dir / "library-rollup.csv"
    cols = ["name", "package_manager", "occurrences", "repo_count",
            "versions", "repos", "declared_license"]
    with rollup_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rollup_list:
            w.writerow(r)

    # ── Signature report ──
    sig_csv_path = None
    sig_json_path = None
    if detect_signatures and (all_signature_records or declared_audit_rows):
        sig_csv_path = log_dir / "signature-report.csv"
        sig_cols = [
            "repo", "path", "format", "size_bytes", "sha256",
            "signed", "signature_type", "signer_subject",
            "signer_verified", "expected_publisher",
            "origin_registry", "origin_package", "origin_method",
            "notes",
        ]
        with sig_csv_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=sig_cols)
            w.writeheader()
            for r in all_signature_records:
                row = asdict(r)
                row["signed"] = "yes" if row["signed"] else "no"
                w.writerow({k: row.get(k, "") for k in sig_cols})

        sig_json_path = log_dir / "signature-report.json"
        signed_count = sum(1 for r in all_signature_records if r.signed)
        unsigned_unknown = sum(
            1 for r in all_signature_records
            if not r.signed and not r.origin_registry
        )
        sig_summary = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "binary_libraries_scanned": len(all_signature_records),
            "signed": signed_count,
            "unsigned": len(all_signature_records) - signed_count,
            "unsigned_origin_unknown": unsigned_unknown,
            "publisher_verified": sum(
                1 for r in all_signature_records
                if r.signer_verified == "verified"),
            "publisher_mismatch": sum(
                1 for r in all_signature_records
                if r.signer_verified == "publisher-mismatch"),
            "binary_records": [asdict(r) for r in all_signature_records],
            "declared_dep_audit": declared_audit_rows,
        }
        sig_json_path.write_text(
            json.dumps(sig_summary, indent=2), encoding="utf-8")

    duration = time.time() - started
    if not quiet:
        print()
        print("=" * 60)
        print(f"DONE in {duration:.1f}s")
        print(f"  Repos scanned:     {len(all_repos)}")
        print(f"  Per-repo SBOMs:    {sbom_dir}")
        print(f"  Findings:          {len(all_findings)} total")
        for sev in ("critical", "high", "medium", "low", "info"):
            print(f"    {sev:8}: {findings_data['by_severity'][sev]}")
        print(f"  Direct deps:       {len(all_deps)}")
        print(f"  Unique deps:       {len(rollup_map)}")
        print()
        print(f"  scan-findings.json:  {log_dir / 'scan-findings.json'}")
        print(f"  scan-summary.csv:    {sum_path}")
        print(f"  library-rollup.csv:  {rollup_path}")
        if sig_csv_path:
            print(f"  signature-report.csv:  {sig_csv_path}")
            print(f"  signature-report.json: {sig_json_path}")

    summary = {
        "duration_s": duration,
        "repos_scanned": len(all_repos),
        "findings": findings_data,
        "rollup_count": len(rollup_map),
        "log_dir": str(log_dir),
        "sbom_dir": str(sbom_dir),
        "signature_summary": {
            "binary_libraries_scanned": len(all_signature_records),
            "signed": sum(1 for r in all_signature_records if r.signed),
            "unsigned_origin_unknown": sum(
                1 for r in all_signature_records
                if not r.signed and not r.origin_registry),
        } if detect_signatures else None,
    }
    emit({"type": "complete", "summary": {
        "duration_s": duration,
        "repos_scanned": len(all_repos),
        "rollup_count": len(rollup_map),
        "by_severity": findings_data["by_severity"],
        "log_dir": str(log_dir),
        "sbom_dir": str(sbom_dir),
    }})
    return summary
