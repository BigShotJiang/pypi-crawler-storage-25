"""License lookup for declared dependencies via deps.dev v3 API.

deps.dev (Google's open-source-package metadata API) covers:
    NPM, PYPI, CARGO, GO, MAVEN

Composer/PHP and a few others aren't covered — we skip those for license
lookup (the scanner already records "needs review" for them).

Endpoint:
    GET https://api.deps.dev/v3/systems/{system}/packages/{name}/versions/{version}
    GET https://api.deps.dev/v3/systems/{system}/packages/{name}    (for latest)

Response shape:
    {
        "versionKey": {...},
        "publishedAt": "...",
        "licenses": ["MIT"],
        ...
    }

We hit `versions/{version}` when we have a concrete version, and the
top-level package endpoint when we have a range or no version (in which
case we use the most recent version).
"""
from __future__ import annotations
import csv
import re
import urllib.parse
from pathlib import Path
from typing import Iterable

from .network import CachedHttp, HttpResult


# Map our package_manager labels → deps.dev system identifiers.
# Order: only systems supported by deps.dev are kept; others skipped.
PM_TO_DEPSDEV = {
    "npm":   "NPM",
    "pypi":  "PYPI",
    "cargo": "CARGO",
    "go":    "GO",
    "maven": "MAVEN",
}


# Strip range operators from a version string to get a concrete version.
# `^1.2.3` → `1.2.3`, `>=1.0,<2.0` → `1.0`, `~v0.5` → `0.5`, `latest` → ``.
_VERSION_CLEAN_RE = re.compile(r"^[\^~v=>=<!\s]+")


def normalize_version(ver: str | None) -> str:
    if not ver:
        return ""
    v = ver.strip()
    # Range with comma — take the first part
    if "," in v:
        v = v.split(",", 1)[0]
    v = _VERSION_CLEAN_RE.sub("", v).strip()
    # Take everything up to a space or another operator
    v = re.split(r"[\s<>=!~^]", v, maxsplit=1)[0]
    # Strip trailing wildcard
    if v.endswith(".x") or v.endswith(".X"):
        v = v[:-2]
    if v.endswith(".*"):
        v = v[:-2]
    return v


def _maven_split(name: str) -> tuple[str, str]:
    """Maven names are 'group:artifact'. deps.dev expects them
    URL-encoded with ':' between group and artifact too."""
    if ":" in name:
        g, _, a = name.partition(":")
        return g, a
    return "", name


def _build_url(system: str, name: str, version: str) -> tuple[str, str]:
    """Return (cache_key, url) for the deps.dev endpoint."""
    if system == "MAVEN":
        g, a = _maven_split(name)
        if not g:
            # Cannot resolve maven without group
            return "", ""
        n = urllib.parse.quote(f"{g}:{a}", safe="")
    else:
        n = urllib.parse.quote(name, safe="")
    if version:
        v = urllib.parse.quote(version, safe="")
        url = f"https://api.deps.dev/v3/systems/{system}/packages/{n}/versions/{v}"
        key = f"depsdev|{system}|{n}|{v}"
    else:
        url = f"https://api.deps.dev/v3/systems/{system}/packages/{n}"
        key = f"depsdev|{system}|{n}|@latest"
    return key, url


def lookup_licenses(rollup_rows: list[dict], cache_dir: Path,
                    progress=None) -> tuple[dict[tuple[str, str], list[str]], object]:
    """Look up licenses for every (name, package_manager) in rollup_rows.

    Three-step lookup per package:
        1. Try the exact version we have (works for tagged releases).
        2. On 404, query the package endpoint, find `isDefault` version,
           query THAT version (this resolves Go pseudo-versions).
        3. On still-no-licenses, walk the versions list in reverse and
           query each until we find one with licenses (capped at 5
           attempts to avoid hammering).

    Returns: ({(name, pm): [license_id, ...]}, http_stats)
    """
    http = CachedHttp(cache_dir, service="depsdev",
                      max_workers=8, request_delay_ms=40)

    # ── Step 1: exact-version lookup ──
    items: list[tuple[str, str, None]] = []
    item_to_key: dict[str, tuple[str, str]] = {}
    for r in rollup_rows:
        name = r["name"]
        pm = r["package_manager"]
        if pm not in PM_TO_DEPSDEV:
            continue
        versions = (r.get("versions") or "").split(",")
        ver = ""
        for v in versions:
            v = normalize_version(v.strip())
            if v:
                ver = v
                break
        system = PM_TO_DEPSDEV[pm]
        cache_key, url = _build_url(system, name, ver)
        if not cache_key:
            continue
        items.append((cache_key, url, None))
        item_to_key[cache_key] = (name, pm)

    if progress:
        progress(0, len(items))
    results = http.fetch_many(items, progress=progress)

    licenses_out: dict[tuple[str, str], list[str]] = {}
    needs_fallback: list[tuple[str, str]] = []  # (name, pm) needing pkg-level lookup

    for cache_key, result in results.items():
        name, pm = item_to_key[cache_key]
        if result.status == 200 and result.data and result.data.get("licenses"):
            licenses_out[(name, pm)] = result.data["licenses"]
        else:
            needs_fallback.append((name, pm))

    # ── Step 2: package-level lookup to find default version ──
    pkg_level_items: list[tuple[str, str, None]] = []
    pkg_level_to_key: dict[str, tuple[str, str]] = {}
    for name, pm in needs_fallback:
        system = PM_TO_DEPSDEV[pm]
        fk, furl = _build_url(system, name, "")
        if fk and fk not in pkg_level_to_key:
            pkg_level_items.append((fk, furl, None))
            pkg_level_to_key[fk] = (name, pm)

    if pkg_level_items:
        if progress:
            progress(0, len(pkg_level_items))
        pkg_results = http.fetch_many(pkg_level_items, progress=progress)
    else:
        pkg_results = {}

    # ── Step 3: query the default version (and a few recent ones if needed) ──
    second_items: list[tuple[str, str, None]] = []
    second_to_key: dict[str, tuple[str, str]] = {}

    for fk, pkg_result in pkg_results.items():
        name, pm = pkg_level_to_key[fk]
        if pkg_result.status != 200 or not pkg_result.data:
            licenses_out[(name, pm)] = []
            continue
        versions = pkg_result.data.get("versions") or []
        if not versions:
            licenses_out[(name, pm)] = []
            continue
        # Find default version
        default_ver = None
        for v in versions:
            if v.get("isDefault"):
                vk = v.get("versionKey", {})
                default_ver = vk.get("version")
                break
        # If no default flagged, take the last (likely most recent)
        if not default_ver:
            default_ver = versions[-1].get("versionKey", {}).get("version")
        if not default_ver:
            licenses_out[(name, pm)] = []
            continue
        system = PM_TO_DEPSDEV[pm]
        sk, surl = _build_url(system, name, default_ver)
        if sk and sk not in second_to_key:
            second_items.append((sk, surl, None))
            second_to_key[sk] = (name, pm)

    if second_items:
        if progress:
            progress(0, len(second_items))
        second_results = http.fetch_many(second_items, progress=progress)
        for sk, sr in second_results.items():
            name, pm = second_to_key[sk]
            if sr.status == 200 and sr.data and sr.data.get("licenses"):
                licenses_out[(name, pm)] = sr.data["licenses"]
            else:
                # Final attempt: walk the version list and try a few
                if (name, pm) not in licenses_out:
                    licenses_out[(name, pm)] = []

    # Make sure every key has an entry
    for name, pm in needs_fallback:
        licenses_out.setdefault((name, pm), [])

    return licenses_out, http.stats


def write_rollup_with_licenses(rollup_rows: list[dict],
                               licenses_map: dict[tuple[str, str], list[str]],
                               out_path: Path) -> dict:
    """Rewrite library-rollup.csv with declared_license filled where known."""
    cols = ["name", "package_manager", "occurrences", "repo_count",
            "versions", "repos", "declared_license"]
    counts = {"resolved": 0, "unresolved": 0, "skipped": 0}
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rollup_rows:
            key = (r["name"], r["package_manager"])
            existing = r.get("declared_license", "")
            looked_up = licenses_map.get(key, [])
            if existing:
                license_field = existing
                counts["skipped"] += 1
            elif looked_up:
                license_field = " OR ".join(looked_up) if len(looked_up) > 1 else looked_up[0]
                counts["resolved"] += 1
            else:
                license_field = ""
                counts["unresolved"] += 1
            w.writerow({
                "name": r["name"],
                "package_manager": r["package_manager"],
                "occurrences": r["occurrences"],
                "repo_count": r["repo_count"],
                "versions": r["versions"],
                "repos": r["repos"],
                "declared_license": license_field,
            })
    return counts
