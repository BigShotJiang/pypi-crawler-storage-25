"""Excel + PowerPoint exporters for scan findings.

Both functions take the in-memory findings list (as produced by scan.run /
loaded from scan-findings.json) plus an optional summary dict, and return
raw bytes ready to stream to the browser.

XLSX layout
-----------
  Sheet "Summary": scan metadata + severity counts table
  Sheet "Findings": every finding as a row
      severity | repo | category | title | location | detail | recommendation

PPTX layout (executive deck)
----------------------------
  Slide 1: Title — "HiddenShadow Scan Report" + scan timestamp/source
  Slide 2: Severity summary — bar list, totals, scan duration
  Slide 3..N: One summary slide per repository:
      repo name + category, finding count, severity tiles, top findings
"""
from __future__ import annotations

import datetime as _dt
import io
from typing import Any

# Imported lazily inside the functions so a missing optional dep gives a
# clean error from the endpoint instead of crashing app boot.


SEV_ORDER = ["critical", "high", "medium", "low", "info"]
SEV_COLORS_HEX = {
    "critical": "B00020",
    "high":     "D32F2F",
    "medium":   "F57C00",
    "low":      "1976D2",
    "info":     "455A64",
}


def _ts() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _sort_findings(findings: list[dict]) -> list[dict]:
    sev_idx = {s: i for i, s in enumerate(SEV_ORDER)}
    return sorted(
        findings,
        key=lambda f: (sev_idx.get(f.get("severity", "info"), 99),
                       f.get("repo") or "",
                       f.get("title") or ""),
    )


def _by_severity(findings: list[dict]) -> dict[str, int]:
    out = {s: 0 for s in SEV_ORDER}
    for f in findings:
        s = f.get("severity", "info")
        if s in out:
            out[s] += 1
    return out


# ── XLSX ────────────────────────────────────────────────────────────────

def build_xlsx(findings: list[dict], summary: dict[str, Any] | None = None) -> bytes:
    """Build an .xlsx with a Summary sheet and a Findings sheet."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    findings = _sort_findings(findings)
    counts = _by_severity(findings)

    wb = Workbook()

    # ── Summary sheet ──────────────────────────────────────────────
    ws = wb.active
    ws.title = "Summary"

    bold = Font(bold=True)
    title = Font(bold=True, size=14, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="263238")
    thin = Side(border_style="thin", color="CFD8DC")
    border = Border(top=thin, left=thin, right=thin, bottom=thin)

    ws["A1"] = "HiddenShadow Scan Report"
    ws["A1"].font = title
    ws["A1"].fill = header_fill
    ws.merge_cells("A1:C1")
    ws.row_dimensions[1].height = 24

    rows = [
        ("Generated",       _ts()),
        ("Total findings",  len(findings)),
    ]
    if summary:
        if summary.get("repos_scanned") is not None:
            rows.append(("Repos scanned", summary["repos_scanned"]))
        if summary.get("duration_s") is not None:
            rows.append(("Scan duration (s)", round(summary["duration_s"], 1)))
        if summary.get("log_dir"):
            rows.append(("Log directory", summary["log_dir"]))
    for i, (k, v) in enumerate(rows, start=3):
        ws.cell(row=i, column=1, value=k).font = bold
        ws.cell(row=i, column=2, value=v)

    # Severity table
    table_start = 3 + len(rows) + 1
    ws.cell(row=table_start, column=1, value="Severity").font = bold
    ws.cell(row=table_start, column=2, value="Count").font = bold
    ws.cell(row=table_start, column=1).fill = header_fill
    ws.cell(row=table_start, column=2).fill = header_fill
    ws.cell(row=table_start, column=1).font = Font(bold=True, color="FFFFFF")
    ws.cell(row=table_start, column=2).font = Font(bold=True, color="FFFFFF")
    for i, sev in enumerate(SEV_ORDER, start=1):
        r = table_start + i
        ws.cell(row=r, column=1, value=sev).fill = PatternFill(
            "solid", fgColor=SEV_COLORS_HEX[sev])
        ws.cell(row=r, column=1).font = Font(bold=True, color="FFFFFF")
        ws.cell(row=r, column=2, value=counts[sev])
        ws.cell(row=r, column=1).border = border
        ws.cell(row=r, column=2).border = border

    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 60

    # ── Findings sheet ─────────────────────────────────────────────
    fs = wb.create_sheet("Findings")
    headers = ["Severity", "Repo", "Category", "Method", "Title",
               "Location", "Detail", "Recommendation"]
    for col, h in enumerate(headers, start=1):
        c = fs.cell(row=1, column=col, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = header_fill
        c.alignment = Alignment(vertical="center")
    fs.row_dimensions[1].height = 22
    fs.freeze_panes = "A2"

    widths = [10, 28, 12, 32, 50, 48, 60, 60]
    for i, w in enumerate(widths, start=1):
        fs.column_dimensions[get_column_letter(i)].width = w

    wrap = Alignment(wrap_text=True, vertical="top")
    for i, f in enumerate(findings, start=2):
        sev = f.get("severity", "info")
        sev_cell = fs.cell(row=i, column=1, value=sev)
        sev_cell.fill = PatternFill("solid",
                                    fgColor=SEV_COLORS_HEX.get(sev, "455A64"))
        sev_cell.font = Font(bold=True, color="FFFFFF")
        sev_cell.alignment = Alignment(horizontal="center", vertical="center")

        for col, key in enumerate(
                ["repo", "category", "method", "title", "location",
                 "detail", "recommendation"], start=2):
            c = fs.cell(row=i, column=col, value=f.get(key) or "")
            c.alignment = wrap

    fs.auto_filter.ref = f"A1:H{len(findings) + 1}"

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ── PPTX ────────────────────────────────────────────────────────────────

def build_pptx(findings: list[dict], summary: dict[str, Any] | None = None) -> bytes:
    """Executive-deck PPTX: title + severity summary + one summary slide per repo."""
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import PP_ALIGN

    findings = _sort_findings(findings)
    counts = _by_severity(findings)
    # Group findings by repo for the per-repo summary slides.
    repo_groups: dict[str, list[dict]] = {}
    for f in findings:
        repo_groups.setdefault(f.get("repo") or "(unknown repo)", []).append(f)
    # Stable repo order: most severe first (uses sort already applied above).
    repo_order: list[str] = []
    seen: set[str] = set()
    for f in findings:
        r = f.get("repo") or "(unknown repo)"
        if r not in seen:
            seen.add(r)
            repo_order.append(r)

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]  # truly blank layout

    def add_textbox(slide, left, top, width, height, text,
                    *, size=18, bold=False, color=None, align=PP_ALIGN.LEFT):
        tb = slide.shapes.add_textbox(left, top, width, height)
        tf = tb.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = align
        run = p.add_run()
        run.text = text
        run.font.size = Pt(size)
        run.font.bold = bold
        if color is not None:
            run.font.color.rgb = color
        return tb

    def add_filled_rect(slide, left, top, width, height, hex_color):
        shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                       left, top, width, height)
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor.from_string(hex_color)
        shape.line.fill.background()
        return shape

    # ── Slide 1: Title ─────────────────────────────────────────────
    s = prs.slides.add_slide(blank)
    add_filled_rect(s, 0, 0, prs.slide_width, Inches(7.5), "0E1A2B")
    add_textbox(s, Inches(0.7), Inches(2.4), Inches(12), Inches(1.2),
                "HiddenShadow Scan Report",
                size=44, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
    open_count = counts["critical"] + counts["high"]
    sub = []
    if summary and summary.get("repos_scanned") is not None:
        sub.append(f"{summary['repos_scanned']} repos scanned")
    sub.append(f"{len(findings)} findings ({open_count} critical/high)")
    sub.append(f"Generated {_ts()}")
    add_textbox(s, Inches(0.7), Inches(3.8), Inches(12), Inches(0.6),
                " · ".join(sub),
                size=20, color=RGBColor(0xB0, 0xBE, 0xC5))
    add_textbox(s, Inches(0.7), Inches(6.6), Inches(12), Inches(0.4),
                "DarkShadowSec LLC",
                size=12, color=RGBColor(0x78, 0x90, 0x9C))

    # ── Slide 2: Severity summary ──────────────────────────────────
    s = prs.slides.add_slide(blank)
    add_textbox(s, Inches(0.6), Inches(0.4), Inches(12), Inches(0.7),
                "Severity Summary", size=32, bold=True,
                color=RGBColor(0x1A, 0x23, 0x7E))

    # Severity bars
    max_count = max(counts.values()) or 1
    bar_max_w = Inches(8.5)
    row_h = Inches(0.65)
    top0 = Inches(1.4)
    for i, sev in enumerate(SEV_ORDER):
        n = counts[sev]
        y = top0 + row_h * i
        # label
        add_textbox(s, Inches(0.6), y, Inches(1.5), row_h,
                    sev.upper(), size=16, bold=True,
                    color=RGBColor.from_string(SEV_COLORS_HEX[sev]))
        # bar
        if n > 0:
            w = max(int(bar_max_w * (n / max_count)), Inches(0.15))
            add_filled_rect(s, Inches(2.2), y + Inches(0.08),
                            w, Inches(0.4), SEV_COLORS_HEX[sev])
        # count
        add_textbox(s, Inches(2.2) + bar_max_w + Inches(0.2), y,
                    Inches(1.0), row_h, str(n), size=18, bold=True)

    # Footer summary line
    foot = []
    if summary and summary.get("repos_scanned") is not None:
        foot.append(f"{summary['repos_scanned']} repos")
    if summary and summary.get("duration_s") is not None:
        foot.append(f"{round(summary['duration_s'], 1)}s scan")
    foot.append(f"{open_count} open critical/high items")
    add_textbox(s, Inches(0.6), Inches(6.7), Inches(12), Inches(0.5),
                " · ".join(foot), size=14,
                color=RGBColor(0x60, 0x6B, 0x77))

    # ── Slides 3..N: one summary slide per repository ──────────────
    if not repo_order:
        s = prs.slides.add_slide(blank)
        add_textbox(s, Inches(0.6), Inches(3.0), Inches(12), Inches(1.0),
                    "No findings.",
                    size=28, bold=True,
                    color=RGBColor(0x2E, 0x7D, 0x32),
                    align=PP_ALIGN.CENTER)
    else:
        TOP_N = 8  # cap top-findings list so the slide always fits
        for r_idx, repo in enumerate(repo_order, start=1):
            r_findings = repo_groups[repo]
            r_counts = _by_severity(r_findings)
            # High-water severity drives the accent color on this slide
            top_sev = next(
                (sev for sev in SEV_ORDER if r_counts.get(sev, 0) > 0),
                "info",
            )
            accent = SEV_COLORS_HEX[top_sev]
            category = r_findings[0].get("category") or ""

            s = prs.slides.add_slide(blank)

            # Accent bar at top
            add_filled_rect(s, 0, 0, prs.slide_width, Inches(0.35), accent)

            # Slide index in upper right
            add_textbox(s, Inches(11.0), Inches(0.45), Inches(2.0),
                        Inches(0.4),
                        f"{r_idx} of {len(repo_order)}",
                        size=12, bold=False,
                        color=RGBColor(0x78, 0x90, 0x9C),
                        align=PP_ALIGN.RIGHT)

            # Repo name
            add_textbox(s, Inches(0.6), Inches(0.55), Inches(11),
                        Inches(0.9), repo,
                        size=30, bold=True,
                        color=RGBColor(0x0E, 0x1A, 0x2B))

            # Subtitle: category · N findings
            sub_bits = []
            if category:
                sub_bits.append(category)
            sub_bits.append(
                f"{len(r_findings)} finding{'s' if len(r_findings) != 1 else ''}"
            )
            r_open = r_counts.get("critical", 0) + r_counts.get("high", 0)
            if r_open:
                sub_bits.append(f"{r_open} critical/high")
            add_textbox(s, Inches(0.6), Inches(1.55), Inches(12),
                        Inches(0.45),
                        "  ·  ".join(sub_bits),
                        size=14,
                        color=RGBColor(0x60, 0x6B, 0x77))

            # Severity tiles row
            tile_y = Inches(2.25)
            tile_w = Inches(2.3)
            tile_h = Inches(0.95)
            tile_gap = Inches(0.15)
            tile_x = Inches(0.6)
            for sev in SEV_ORDER:
                n = r_counts.get(sev, 0)
                hex_color = SEV_COLORS_HEX[sev]
                # Faded tile when zero so the eye skips it
                if n == 0:
                    add_filled_rect(s, tile_x, tile_y, tile_w, tile_h, "1A2733")
                    add_textbox(s, tile_x, tile_y + Inches(0.12),
                                tile_w, Inches(0.35),
                                sev.upper(), size=10, bold=True,
                                color=RGBColor(0x60, 0x6B, 0x77),
                                align=PP_ALIGN.CENTER)
                    add_textbox(s, tile_x, tile_y + Inches(0.4),
                                tile_w, Inches(0.55),
                                "0", size=22, bold=True,
                                color=RGBColor(0x60, 0x6B, 0x77),
                                align=PP_ALIGN.CENTER)
                else:
                    add_filled_rect(s, tile_x, tile_y, tile_w, tile_h, hex_color)
                    add_textbox(s, tile_x, tile_y + Inches(0.12),
                                tile_w, Inches(0.35),
                                sev.upper(), size=10, bold=True,
                                color=RGBColor(0xFF, 0xFF, 0xFF),
                                align=PP_ALIGN.CENTER)
                    add_textbox(s, tile_x, tile_y + Inches(0.4),
                                tile_w, Inches(0.55),
                                str(n), size=24, bold=True,
                                color=RGBColor(0xFF, 0xFF, 0xFF),
                                align=PP_ALIGN.CENTER)
                tile_x = tile_x + tile_w + tile_gap

            # Top findings header
            add_textbox(s, Inches(0.6), Inches(3.55), Inches(12),
                        Inches(0.35),
                        "TOP FINDINGS",
                        size=11, bold=True,
                        color=RGBColor(0x60, 0x6B, 0x77))
            add_filled_rect(s, Inches(0.6), Inches(3.9),
                            Inches(12.1), Inches(0.02), accent)

            # Top findings list (already severity-sorted)
            top = r_findings[:TOP_N]
            row_y = Inches(4.05)
            line_h = Inches(0.4)
            for tf in top:
                sev = tf.get("severity", "info")
                sev_c = SEV_COLORS_HEX.get(sev, "455A64")
                # Severity chip
                add_filled_rect(s, Inches(0.6), row_y + Inches(0.06),
                                Inches(0.85), Inches(0.26), sev_c)
                add_textbox(s, Inches(0.6), row_y + Inches(0.04),
                            Inches(0.85), Inches(0.3),
                            sev.upper()[:4],
                            size=9, bold=True,
                            color=RGBColor(0xFF, 0xFF, 0xFF),
                            align=PP_ALIGN.CENTER)
                # Title + location
                title_text = tf.get("title") or "(untitled)"
                loc = tf.get("location") or ""
                line = title_text if not loc else f"{title_text}  —  {loc}"
                if len(line) > 130:
                    line = line[:127] + "…"
                add_textbox(s, Inches(1.55), row_y, Inches(11.2), line_h,
                            line, size=12,
                            color=RGBColor(0x21, 0x21, 0x21))
                row_y = row_y + line_h

            # "… N more" footer if we truncated
            if len(r_findings) > TOP_N:
                add_textbox(s, Inches(0.6), Inches(7.05), Inches(12),
                            Inches(0.35),
                            f"… and {len(r_findings) - TOP_N} more "
                            f"(see Excel report for full list)",
                            size=11,
                            color=RGBColor(0x78, 0x90, 0x9C))

    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()
