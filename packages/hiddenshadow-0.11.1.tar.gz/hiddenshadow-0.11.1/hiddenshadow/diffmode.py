"""Git-diff aware finding filtering.

Lets CI runs scan the whole tree but only *report* findings whose
location lies inside a file that changed in the current PR. Cuts CI
runtime impact and keeps PR review focused.

Usage::

    changed = changed_files(repo_root, base_ref="origin/main")
    if changed is not None:
        findings = filter_findings_by_files(findings, changed)

If ``changed_files`` returns ``None`` (no git repo, shallow clone, or
git not on PATH) the caller should report ALL findings as if diff mode
were disabled. Silent fall-through is the desired behaviour because
the alternative — failing the CI run — would prevent any analysis from
landing.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import Iterable

from .findings import Finding


_LOC_FILE_RE = re.compile(r"^(?P<file>[^:\n#\s(]+)(?:[:#]|$|\s|\()")


def _location_to_file(loc: str) -> str:
    """Best-effort extract the file portion from a finding's location."""
    if not loc:
        return ""
    m = _LOC_FILE_RE.match(loc.strip())
    if m:
        return m.group("file").replace("\\", "/")
    return ""


def changed_files(repo_root: Path, *, base_ref: str,
                  head_ref: str = "HEAD") -> set[str] | None:
    """Return the set of repo-relative paths that differ between
    ``base_ref`` and ``head_ref``.

    Returns ``None`` if git can't answer (not a repo, missing ref,
    shallow clone). Callers should treat ``None`` as "diff mode
    unavailable" and not filter anything out.
    """
    if not _is_git_repo(repo_root):
        return None
    # Make sure both refs are reachable. ``rev-parse --verify`` returns
    # non-zero if a ref doesn't resolve.
    if not _rev_exists(repo_root, base_ref):
        return None
    if not _rev_exists(repo_root, head_ref):
        return None
    try:
        r = subprocess.run(
            ["git", "-C", str(repo_root), "diff", "--name-only",
             f"{base_ref}...{head_ref}"],
            check=False, capture_output=True, text=True, timeout=30,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    return {line.strip().replace("\\", "/")
            for line in r.stdout.split("\n") if line.strip()}


def _is_git_repo(repo_root: Path) -> bool:
    try:
        r = subprocess.run(
            ["git", "-C", str(repo_root), "rev-parse", "--is-inside-work-tree"],
            check=False, capture_output=True, text=True, timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0 and r.stdout.strip() == "true"


def _rev_exists(repo_root: Path, ref: str) -> bool:
    try:
        r = subprocess.run(
            ["git", "-C", str(repo_root), "rev-parse", "--verify", "--quiet",
             ref],
            check=False, capture_output=True, text=True, timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0


# Locations that should always pass through diff filtering even when
# none of their files changed. These are aggregate findings produced by
# the rollup analyzer that don't correspond to any single file.
_ALWAYS_PASS_LOCATIONS = ("(rollup)", "(repo root)", "(unknown)", "")


def filter_findings_by_files(findings: Iterable[Finding],
                             changed: set[str]) -> list[Finding]:
    """Keep only findings whose file is in ``changed``.

    Findings whose location resolves to no file (rollup-level,
    cross-file aggregates) always pass through so we don't silently
    hide them when a PR happens to not touch the file they were
    derived from.
    """
    kept: list[Finding] = []
    changed_norm = {p.replace("\\", "/").lstrip("./") for p in changed}
    for f in findings:
        file = _location_to_file(f.location or "")
        if not file:
            kept.append(f)
            continue
        if file.startswith("("):
            kept.append(f)
            continue
        normalized = file.replace("\\", "/").lstrip("./")
        # Match either exactly, or as a suffix (finding file may be
        # relative to a sub-repo while changed is repo-root-relative).
        if normalized in changed_norm:
            kept.append(f)
            continue
        if any(c.endswith("/" + normalized) or normalized.endswith("/" + c)
               for c in changed_norm):
            kept.append(f)
            continue
    return kept
