"""Binary library signature detection + origin lookup.

Walks a repository for shipped binary library files and determines
whether each is digitally signed, by whom, and — for unsigned files —
whether the file can be located in a public registry by hash.

Formats handled
---------------
PE (.dll, .exe, .sys, .ocx, .pyd, .node, .cpl, .drv, .efi)
    Reads the Optional Header's IMAGE_DIRECTORY_ENTRY_SECURITY entry.
    A non-empty security directory means an Authenticode signature is
    embedded. A minimal ASN.1 walker extracts the signer's commonName
    (OID 2.5.4.3) from the embedded PKCS#7 certificate chain.

ZIP-based (.jar, .whl, .nupkg, .aar, .apk, .xpi, .msix, .appx, .ipa)
    Inspects the central directory for canonical signature entries:
        .jar / .aar / .apk : META-INF/*.SF + META-INF/*.RSA|.DSA|.EC
        .nupkg             : .signature.p7s
        .whl               : RECORD.jws or a sibling .whl.attestation
                             (PEP 740 / sigstore attestations)
        .msix / .appx      : AppxSignature.p7x
        .xpi               : META-INF/mozilla.rsa + .sf

Mach-O (.dylib, .so on macOS, no-extension Mach-O binaries)
    Looks for LC_CODE_SIGNATURE (0x1D) load command in any architecture
    slice (handles FAT/universal binaries).

ELF (.so, .so.<ver>)
    Linux shared libraries are almost never signed inline; this module
    flags them unsigned and looks for sibling detached signatures.

Detached sidecar signatures
    For ANY library file we also probe these sibling files:
        <file>.asc       PGP cleartext armored
        <file>.sig       binary signature (PGP / minisign / signify)
        <file>.minisig   minisign
        <file>.cms       CMS / PKCS#7
        <file>.sigstore  sigstore bundle
        <file>.intoto.jsonl  in-toto attestation

When a sidecar is present we report the file as "signed (detached)".

Origin lookup
-------------
For unsigned binaries we compute SHA-256 and query npm/PyPI registries
by hash to attempt to locate the originating package. When the file is
signed but the signer subject is present, we record the subject so the
operator can confirm it matches the expected publisher.

The full per-file table is written to ``signature-report.csv`` and
``signature-report.json`` in the scan output dir; high-severity outcomes
(``unsigned and origin unknown``) also surface as Findings in the main
scan stream.
"""
from __future__ import annotations

import hashlib
import os
import re
import struct
import zipfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterable

from .findings import Finding


# ── File-selection rules ────────────────────────────────────────────────

# Extensions whose primary purpose is "shippable binary library".
BINARY_LIB_EXTS: dict[str, str] = {
    # Windows / PE
    ".dll": "pe", ".exe": "pe", ".sys": "pe", ".ocx": "pe",
    ".pyd": "pe", ".node": "pe", ".cpl": "pe", ".drv": "pe",
    ".efi": "pe", ".scr": "pe",
    # Linux / ELF
    ".so": "elf",
    # macOS / Mach-O
    ".dylib": "macho",
    # JVM
    ".jar": "zip-jar", ".war": "zip-jar", ".ear": "zip-jar",
    ".aar": "zip-jar",
    # Android / mobile
    ".apk": "zip-jar", ".xapk": "zip-jar", ".aab": "zip-jar",
    ".ipa": "zip-jar",
    # Python wheels / eggs
    ".whl": "zip-whl", ".egg": "zip-whl",
    # NuGet
    ".nupkg": "zip-nupkg", ".snupkg": "zip-nupkg",
    # Windows installer / packages
    ".msi": "msi", ".msix": "zip-msix", ".appx": "zip-msix",
    ".cab": "cab",
    # Browser extensions
    ".xpi": "zip-xpi", ".crx": "crx",
}

# Files without a recognizable extension that we still treat as PE.
PE_MAGIC = b"MZ"
ELF_MAGIC = b"\x7fELF"
MACHO_MAGICS = (
    b"\xfe\xed\xfa\xce",  # 32-bit big-endian
    b"\xce\xfa\xed\xfe",  # 32-bit little-endian
    b"\xfe\xed\xfa\xcf",  # 64-bit big-endian
    b"\xcf\xfa\xed\xfe",  # 64-bit little-endian
    b"\xca\xfe\xba\xbe",  # FAT big-endian
    b"\xbe\xba\xfe\xca",  # FAT little-endian
)
ZIP_MAGIC = b"PK\x03\x04"

# Sidecar signature extensions probed for ANY library file.
SIDECAR_SIG_EXTS: tuple[str, ...] = (
    ".asc", ".sig", ".minisig", ".cms", ".p7s",
    ".sigstore", ".intoto.jsonl", ".attestation",
)

# Directories to skip when walking for binary library files. Unlike
# manifests.SKIP_DIRS, we deliberately DO descend into node_modules,
# site-packages, vendor/, etc. — those are exactly where bundled
# third-party binaries hide.
EXTRA_SKIP_DIRS: set[str] = {
    ".git", "__pycache__", ".idea", ".vscode", ".pytest_cache",
}

# Cap to keep big repos sane.
MAX_FILES_SCANNED = 500
MAX_FILE_BYTES_FOR_HASH = 200 * 1024 * 1024   # 200 MB
MAX_FILE_BYTES_FOR_PARSE = 100 * 1024 * 1024  # 100 MB


# ── Result records ──────────────────────────────────────────────────────

@dataclass
class SignatureRecord:
    """One row in the signature report."""
    repo: str = ""
    path: str = ""                  # relative to repo root
    format: str = ""                # pe / elf / macho / zip-jar / zip-whl / ...
    size_bytes: int = 0
    sha256: str = ""
    signed: bool = False
    signature_type: str = ""        # authenticode / jar / pep740 / nupkg / sidecar-pgp / ...
    signer_subject: str = ""        # commonName from cert subject (Authenticode), key id (PGP), etc.
    signer_verified: str = ""       # "verified" | "publisher-mismatch" | "subject-only" | ""
    expected_publisher: str = ""    # from registry, when we can look it up
    origin_registry: str = ""       # "npm" | "pypi" | "maven" | "nuget" | ""
    origin_package: str = ""        # e.g. "lodash@4.17.21"
    origin_method: str = ""         # "hash-lookup" | "filename" | "embedded-metadata"
    notes: str = ""                 # free-form (parse errors, etc.)


# ── PE / Authenticode parsing ───────────────────────────────────────────

def _read_pe_security_dir(data: bytes) -> tuple[int, int]:
    """Return (offset, size) of the PE security directory, or (0, 0).

    A non-zero size indicates an embedded Authenticode signature.
    """
    if len(data) < 0x40 or data[:2] != PE_MAGIC:
        return 0, 0
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    if e_lfanew + 24 > len(data):
        return 0, 0
    if data[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
        return 0, 0
    coff = e_lfanew + 4
    # COFF header is 20 bytes; Optional header magic right after.
    opt = coff + 20
    if opt + 2 > len(data):
        return 0, 0
    magic = struct.unpack_from("<H", data, opt)[0]
    # PE32 → 0x10b, PE32+ → 0x20b. Security dir is the 5th data directory.
    # Offset of data directories: PE32 = opt + 96, PE32+ = opt + 112.
    if magic == 0x10b:
        dd_off = opt + 96
    elif magic == 0x20b:
        dd_off = opt + 112
    else:
        return 0, 0
    sec_off = dd_off + 4 * 8  # 5th entry (index 4), each entry is 8 bytes
    if sec_off + 8 > len(data):
        return 0, 0
    rva, size = struct.unpack_from("<II", data, sec_off)
    return rva, size


def _extract_cn_from_subject(blob: bytes) -> str:
    """Tiny ASN.1 walker: find the first commonName (OID 2.5.4.3) in a
    DER-encoded blob and return the UTF-8 string value.

    This is intentionally lenient — we just scan for the OID byte
    sequence and read the subsequent OCTET/UTF8/PRINTABLE string.
    """
    # OID 2.5.4.3 encoded as ASN.1 OID octets is 06 03 55 04 03
    needle = b"\x06\x03\x55\x04\x03"
    idx = 0
    best = ""
    while True:
        i = blob.find(needle, idx)
        if i < 0:
            break
        # After the OID, a SET/SEQUENCE wrapper holds the value. The
        # value tag immediately following is one of: 0c (UTF8String),
        # 13 (PrintableString), 16 (IA5String), 1e (BMPString).
        j = i + len(needle)
        if j + 2 > len(blob):
            break
        tag = blob[j]
        # Length encoding: short form (< 0x80) or long form.
        lenbyte = blob[j + 1]
        if lenbyte < 0x80:
            l = lenbyte
            voff = j + 2
        else:
            n = lenbyte & 0x7F
            if n == 0 or j + 2 + n > len(blob):
                idx = j + 1
                continue
            l = int.from_bytes(blob[j + 2:j + 2 + n], "big")
            voff = j + 2 + n
        if tag in (0x0C, 0x13, 0x16, 0x14):
            value = blob[voff:voff + l]
            try:
                s = value.decode("utf-8", errors="replace").strip()
            except Exception:
                s = ""
            if s and not best:
                best = s
                # Don't break — keep scanning to prefer a non-empty one,
                # but the first is usually right.
                return best
        elif tag == 0x1E:  # BMPString → UTF-16 BE
            try:
                s = blob[voff:voff + l].decode("utf-16-be", errors="replace").strip()
            except Exception:
                s = ""
            if s and not best:
                return s
        idx = j + 1
    return best


def _inspect_pe(path: Path) -> tuple[bool, str, str]:
    """Return (signed, signature_type, signer_subject) for a PE file."""
    try:
        with path.open("rb") as f:
            head = f.read(min(path.stat().st_size, MAX_FILE_BYTES_FOR_PARSE))
    except OSError:
        return False, "", ""
    rva, size = _read_pe_security_dir(head)
    if size == 0 or rva == 0:
        return False, "", ""
    # The security directory uses a file offset (not RVA) and points to
    # a WIN_CERTIFICATE: dwLength(4) + wRevision(2) + wCertificateType(2)
    # + bCertificate[]. The bCertificate is a PKCS#7 SignedData (CMS).
    if rva + 8 > len(head):
        return True, "authenticode", ""
    cert_len, _rev, cert_type = struct.unpack_from("<IHH", head, rva)
    cert_blob = head[rva + 8:rva + cert_len]
    if cert_type == 0x0002 and cert_blob:  # WIN_CERT_TYPE_PKCS_SIGNED_DATA
        cn = _extract_cn_from_subject(cert_blob)
        return True, "authenticode", cn
    return True, "authenticode", ""


# ── ZIP-based formats (JAR, WHL, NUPKG, MSIX, AAR, XPI, APK) ────────────

_JAR_SF_RE = re.compile(r"^META-INF/[^/]+\.SF$", re.IGNORECASE)
_JAR_KEY_RE = re.compile(r"^META-INF/[^/]+\.(RSA|DSA|EC)$", re.IGNORECASE)


def _inspect_zip(path: Path, fmt: str) -> tuple[bool, str, str]:
    """Return (signed, signature_type, signer_subject) for a ZIP-based archive."""
    try:
        with zipfile.ZipFile(path, "r") as zf:
            names = zf.namelist()
            name_set = set(names)
            # ── JAR / AAR / APK ──
            if fmt == "zip-jar":
                has_sf = any(_JAR_SF_RE.match(n) for n in names)
                has_key = any(_JAR_KEY_RE.match(n) for n in names)
                if has_sf and has_key:
                    # Read the first key block and try to pull a CN.
                    for n in names:
                        if _JAR_KEY_RE.match(n):
                            try:
                                cn = _extract_cn_from_subject(zf.read(n))
                            except Exception:
                                cn = ""
                            return True, "jar", cn
                    return True, "jar", ""
                # APK v2/v3 block is in the ZIP comment / end-of-central-
                # -directory; presence of META-INF/CERT.SF is the v1 path.
                return False, "", ""
            # ── Python wheel ──
            if fmt == "zip-whl":
                # RECORD.jws is signed RECORD; PEP 740 attestation is a
                # sibling file outside the wheel, but some wheels embed
                # signature blobs in *.dist-info/.
                for n in names:
                    lower = n.lower()
                    if lower.endswith("record.jws"):
                        return True, "pep740", ""
                    if lower.endswith(".asc") or lower.endswith(".sig"):
                        return True, "pgp-embedded", ""
                return False, "", ""
            # ── NuGet ──
            if fmt == "zip-nupkg":
                if ".signature.p7s" in name_set:
                    try:
                        cn = _extract_cn_from_subject(zf.read(".signature.p7s"))
                    except Exception:
                        cn = ""
                    return True, "nupkg", cn
                return False, "", ""
            # ── MSIX / APPX ──
            if fmt == "zip-msix":
                if "AppxSignature.p7x" in name_set:
                    try:
                        # .p7x is 4-byte magic ("PKCX") + DER PKCS#7
                        blob = zf.read("AppxSignature.p7x")
                        if blob.startswith(b"PKCX"):
                            blob = blob[4:]
                        cn = _extract_cn_from_subject(blob)
                    except Exception:
                        cn = ""
                    return True, "msix", cn
                return False, "", ""
            # ── Firefox XPI ──
            if fmt == "zip-xpi":
                has_sf = any(n.lower().endswith(".sf") for n in names if n.startswith("META-INF/"))
                has_key = any(n.lower().endswith((".rsa", ".dsa", ".ec"))
                              for n in names if n.startswith("META-INF/"))
                if has_sf and has_key:
                    return True, "xpi", ""
                return False, "", ""
    except (zipfile.BadZipFile, OSError):
        return False, "", ""
    return False, "", ""


# ── Mach-O detection ────────────────────────────────────────────────────

LC_CODE_SIGNATURE = 0x1D


def _inspect_macho(path: Path) -> tuple[bool, str, str]:
    """Look for LC_CODE_SIGNATURE in a Mach-O (or FAT-wrapped) binary."""
    try:
        with path.open("rb") as f:
            head = f.read(min(path.stat().st_size, 8 * 1024 * 1024))
    except OSError:
        return False, "", ""
    if len(head) < 8:
        return False, "", ""
    magic = head[:4]
    arches: list[tuple[int, bool]] = []  # (offset, is_64)
    if magic in (b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca"):
        # FAT/universal — walk fat_arch entries (big-endian).
        nfat = struct.unpack(">I", head[4:8])[0]
        for i in range(min(nfat, 32)):
            off = 8 + i * 20
            if off + 20 > len(head):
                break
            _cpu, _sub, offset, _size, _align = struct.unpack(">IIIII", head[off:off + 20])
            if offset + 32 < len(head):
                arches.append((offset, False))  # detect 32/64 by magic below
    else:
        arches.append((0, False))
    for off, _ in arches:
        if off + 28 > len(head):
            continue
        m = head[off:off + 4]
        if m in (b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe"):
            is_64 = True
        elif m in (b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe"):
            is_64 = False
        else:
            continue
        little = m in (b"\xce\xfa\xed\xfe", b"\xcf\xfa\xed\xfe")
        endian = "<" if little else ">"
        # mach_header / mach_header_64: magic, cputype, cpusubtype, filetype,
        # ncmds, sizeofcmds, flags, [reserved if 64]
        ncmds = struct.unpack_from(endian + "I", head, off + 16)[0]
        sizeofcmds = struct.unpack_from(endian + "I", head, off + 20)[0]
        cmds_off = off + (32 if is_64 else 28)
        cursor = cmds_off
        end = cmds_off + min(sizeofcmds, len(head) - cmds_off)
        for _ in range(min(ncmds, 4096)):
            if cursor + 8 > end:
                break
            cmd, cmdsize = struct.unpack_from(endian + "II", head, cursor)
            if cmd == LC_CODE_SIGNATURE:
                return True, "macho-codesign", ""
            if cmdsize == 0:
                break
            cursor += cmdsize
    return False, "", ""


# ── Format dispatch ─────────────────────────────────────────────────────

def _detect_format(path: Path, declared_ext: str) -> str:
    """Return the format key, sniffing magic if the extension is ambiguous."""
    fmt = BINARY_LIB_EXTS.get(declared_ext, "")
    # ".so" can also be a Mach-O on macOS — sniff to be sure.
    try:
        with path.open("rb") as f:
            magic = f.read(8)
    except OSError:
        return fmt
    if magic[:4] in MACHO_MAGICS:
        return "macho"
    if magic[:4] == ELF_MAGIC:
        return "elf"
    if magic[:2] == PE_MAGIC and fmt in ("", "pe", "elf"):
        return "pe"
    if magic[:4] == ZIP_MAGIC and fmt.startswith("zip"):
        return fmt
    return fmt


# ── Sidecar signature detection ─────────────────────────────────────────

def _find_sidecar_signature(path: Path) -> str:
    """If <path>.<sig-ext> exists, return the extension; else ''."""
    for ext in SIDECAR_SIG_EXTS:
        sidecar = path.with_name(path.name + ext)
        if sidecar.exists() and sidecar.is_file() and sidecar.stat().st_size > 0:
            return ext
    return ""


# ── Hashing + walking ───────────────────────────────────────────────────

def _sha256_file(path: Path) -> str:
    try:
        size = path.stat().st_size
    except OSError:
        return ""
    if size > MAX_FILE_BYTES_FOR_HASH:
        return ""
    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
    except OSError:
        return ""
    return h.hexdigest()


def _iter_library_files(repo_dir: Path) -> Iterable[tuple[Path, str]]:
    """Yield (path, format) for every binary library file in the tree."""
    yielded = 0
    for dirpath, dirnames, filenames in os.walk(repo_dir):
        dirnames[:] = [d for d in dirnames if d not in EXTRA_SKIP_DIRS]
        for fn in filenames:
            ext = Path(fn).suffix.lower()
            # Handle ".so.<version>" → still ELF.
            if not ext and fn.startswith("lib") and ".so." in fn:
                ext = ".so"
            if ext not in BINARY_LIB_EXTS:
                continue
            full = Path(dirpath) / fn
            try:
                if not full.is_file():
                    continue
            except OSError:
                continue
            fmt = _detect_format(full, ext)
            if not fmt:
                continue
            yield full, fmt
            yielded += 1
            if yielded >= MAX_FILES_SCANNED:
                return


# ── Public API ──────────────────────────────────────────────────────────

def inspect_file(path: Path, fmt: str) -> tuple[bool, str, str, str]:
    """Inspect a single library file.

    Returns (signed, signature_type, signer_subject, notes).
    """
    notes = ""
    try:
        if fmt == "pe":
            signed, sig_type, subject = _inspect_pe(path)
        elif fmt.startswith("zip"):
            signed, sig_type, subject = _inspect_zip(path, fmt)
        elif fmt == "macho":
            signed, sig_type, subject = _inspect_macho(path)
        elif fmt == "elf":
            signed, sig_type, subject = False, "", ""
        else:
            signed, sig_type, subject = False, "", ""
    except Exception as exc:  # pragma: no cover — defensive
        notes = f"parse error: {type(exc).__name__}: {exc}"
        signed, sig_type, subject = False, "", ""

    # Sidecar detection augments any format.
    if not signed:
        sidecar = _find_sidecar_signature(path)
        if sidecar:
            signed = True
            sig_type = f"sidecar{sidecar}"
            subject = ""
    return signed, sig_type, subject, notes


def scan_repo_for_signatures(repo_dir: Path, repo_name: str) -> list[SignatureRecord]:
    """Walk a repo, inspect every binary library file, return one record per file.

    No network calls. Origin-lookup augmentation happens in a separate
    pass (see ``annotate_origins_via_registry``) so the per-repo loop
    stays fast and offline by default.
    """
    records: list[SignatureRecord] = []
    for path, fmt in _iter_library_files(repo_dir):
        try:
            size = path.stat().st_size
        except OSError:
            continue
        signed, sig_type, subject, notes = inspect_file(path, fmt)
        rec = SignatureRecord(
            repo=repo_name,
            path=str(path.relative_to(repo_dir)).replace("\\", "/"),
            format=fmt,
            size_bytes=size,
            sha256=_sha256_file(path),
            signed=signed,
            signature_type=sig_type,
            signer_subject=subject,
            notes=notes,
        )
        records.append(rec)
    return records


def records_to_findings(records: Iterable[SignatureRecord]) -> list[Finding]:
    """Convert per-file records into Finding entries for the main scan stream.

    Severity mapping:
        unsigned AND origin unknown                      → high
        unsigned but origin identified (hash-located)    → medium
        signed but publisher mismatch vs registry        → high
        signed (subject only, no registry comparison)    → low (info-ish)
        signed AND publisher verified                    → info
    """
    out: list[Finding] = []
    for r in records:
        method = "signature:" + (r.signature_type or "none")
        loc = r.path
        if not r.signed:
            if r.origin_registry and r.origin_package:
                out.append(Finding(
                    repo=r.repo,
                    severity="medium",
                    category="signature",
                    title=f"Unsigned binary library ({r.format})",
                    location=loc,
                    detail=(
                        f"{r.path} is not digitally signed. "
                        f"Origin identified by SHA-256 hash lookup: "
                        f"{r.origin_package} (registry: {r.origin_registry})."
                    ),
                    recommendation=(
                        "Replace with a signed/published artifact, or verify the "
                        "build is reproducible and matches the registry hash. "
                        "If this is a vendored binary, confirm provenance before "
                        "shipping."
                    ),
                    method=method,
                ))
            else:
                out.append(Finding(
                    repo=r.repo,
                    severity="high",
                    category="signature",
                    title=f"Unsigned library, origin unknown ({r.format})",
                    location=loc,
                    detail=(
                        f"{r.path} is not digitally signed and could not be "
                        f"located in any known public registry by hash "
                        f"(SHA-256 {r.sha256[:16] or '?'}...). "
                        f"This binary's provenance is unverifiable."
                    ),
                    recommendation=(
                        "Identify where this binary came from. If it is a build "
                        "artifact, rebuild from source and sign it. If it was "
                        "downloaded, replace it with a signed release from the "
                        "official vendor. Untraceable binaries should not ship."
                    ),
                    method=method,
                ))
            continue
        # signed branch
        if r.signer_verified == "publisher-mismatch":
            out.append(Finding(
                repo=r.repo,
                severity="high",
                category="signature",
                title=f"Signed library: publisher mismatch ({r.format})",
                location=loc,
                detail=(
                    f"{r.path} is signed by '{r.signer_subject}', but the "
                    f"expected publisher per registry ({r.origin_registry}) "
                    f"is '{r.expected_publisher}'."
                ),
                recommendation=(
                    "Investigate whether this binary was rebundled or repackaged "
                    "by a third party. Confirm the signing identity with the "
                    "upstream maintainer before trusting it."
                ),
                method=method,
            ))
        elif r.signer_verified == "verified":
            out.append(Finding(
                repo=r.repo,
                severity="info",
                category="signature",
                title=f"Signed library, publisher verified ({r.format})",
                location=loc,
                detail=(
                    f"{r.path} signed by '{r.signer_subject}'. Matches the "
                    f"expected publisher for {r.origin_package} "
                    f"({r.origin_registry})."
                ),
                recommendation="No action — signature and publisher both verified.",
                method=method,
            ))
        else:
            # signed but no registry comparison was done (or signer unknown)
            sev = "low" if r.signer_subject else "medium"
            subj = r.signer_subject or "(signer subject not extractable)"
            out.append(Finding(
                repo=r.repo,
                severity=sev,
                category="signature",
                title=f"Signed library, publisher unverified ({r.format})",
                location=loc,
                detail=(
                    f"{r.path} carries a {r.signature_type} signature "
                    f"(signer: {subj}). The publisher was not cross-checked "
                    f"against a public registry (no match by hash, or the "
                    f"ecosystem does not publish signer metadata)."
                ),
                recommendation=(
                    "Manually confirm the signer matches the expected upstream "
                    "vendor. For Authenticode, compare the CN against the "
                    "vendor's published certificate."
                ),
                method=method,
            ))
    return out
