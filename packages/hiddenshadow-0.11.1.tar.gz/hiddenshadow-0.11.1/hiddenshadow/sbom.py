"""CycloneDX 1.5 SBOM emission."""
from __future__ import annotations
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .manifests import Dep


def _purl(d: Dep) -> str:
    type_map = {
        "npm": "npm", "pypi": "pypi", "cargo": "cargo",
        "go": "golang", "maven": "maven", "composer": "composer",
    }
    pkg_type = type_map.get(d.package_manager, "generic")
    name = d.name
    ver = (d.version or "").lstrip("v ").strip()
    if pkg_type == "maven" and ":" in name:
        ns, _, n = name.partition(":")
        purl = f"pkg:maven/{ns}/{n}"
    else:
        purl = f"pkg:{pkg_type}/{name}"
    if ver and not any(c in ver for c in "<>=!~^"):
        purl += f"@{ver}"
    return purl


def emit(repo_name: str, self_license: str | None, deps: list[Dep],
         out_path: Path) -> None:
    """Write a minimal valid CycloneDX 1.5 JSON SBOM."""
    components = []
    seen = set()
    for d in deps:
        key = (d.name, d.version or "")
        if key in seen:
            continue
        seen.add(key)
        comp: dict = {
            "type": "library",
            "name": d.name,
            "purl": _purl(d),
        }
        if d.version:
            comp["version"] = d.version
        components.append(comp)

    licenses = []
    if self_license:
        # CycloneDX wants either a license id or name
        if " " in self_license:
            licenses = [{"license": {"name": self_license}}]
        else:
            licenses = [{"license": {"id": self_license}}]

    sbom = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.5",
        "serialNumber": f"urn:uuid:{uuid.uuid4()}",
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "tools": [{
                "vendor": "DarkShadowSec LLC",
                "name": "hiddenshadow",
                "version": "0.4.0",
            }],
            "component": {
                "type": "application",
                "name": repo_name,
                "purl": f"pkg:generic/{repo_name}",
                "licenses": licenses,
            },
        },
        "components": components,
    }
    out_path.write_text(json.dumps(sbom, indent=2), encoding="utf-8")
