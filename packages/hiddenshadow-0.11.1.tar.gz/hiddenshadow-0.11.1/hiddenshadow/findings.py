"""Finding model + analysis rules.

A Finding describes one observed issue with severity + recommended fix.
The analyzer functions in this module take a scanned repo's data and
emit Findings.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Optional

from .licenses import classify, LICENSE_CLASS


# Sample of well-known package name → license map for the rollup analyzer.
# This is intentionally small; it's used to flag obviously-permissive deps
# vs. deps that need lookup. Not a substitute for real registry queries.
KNOWN_PERMISSIVE_DEPS: dict[str, str] = {
    # npm
    "react": "MIT", "next": "MIT", "@apollo/server": "MIT",
    "@apollo/client": "MIT", "graphql": "MIT", "express": "MIT",
    "fastify": "MIT", "lodash": "MIT", "axios": "MIT",
    "typescript": "Apache-2.0", "puppeteer": "Apache-2.0",
    "exceljs": "MIT", "pdfkit": "MIT",
    # pypi
    "fastapi": "MIT", "click": "BSD-3-Clause", "pyyaml": "MIT",
    "jsonschema": "MIT", "rich": "MIT", "openpyxl": "MIT",
    "python-docx": "MIT", "python-pptx": "MIT", "markdown": "BSD-3-Clause",
    "beautifulsoup4": "MIT",
    # cargo
    "serde": "MIT OR Apache-2.0", "tokio": "MIT", "hyper": "MIT",
    "tower": "MIT", "rustls": "Apache-2.0 OR ISC OR MIT",
    "anyhow": "MIT OR Apache-2.0", "thiserror": "MIT OR Apache-2.0",
    "clap": "MIT OR Apache-2.0",
    # go
    "github.com/spf13/cobra": "Apache-2.0",
    "github.com/spf13/viper": "MIT",
    "github.com/stretchr/testify": "MIT",
    "google.golang.org/grpc": "Apache-2.0",
    "google.golang.org/protobuf": "BSD-3-Clause",
}


# Known non-permissive deps to flag aggressively
KNOWN_PROBLEMATIC_DEPS: dict[str, str] = {
    # GPL-licensed npm packages occasionally show up — flag any
    "ghostscript4js": "GPL-3.0",   # example
}


@dataclass
class Finding:
    repo: str
    severity: str           # critical | high | medium | low | info
    category: str           # license | sbom | dep | config | sast | secret | behavior | cve
    title: str
    location: str           # file or path or "(rollup)"
    detail: str
    recommendation: str
    # Short identifier of the detection technique, e.g.
    #   sast:py-md5-sha1, behavior:net-host-suspicious,
    #   secret:aws-access-key-id, license:nested-license-mismatch,
    #   cve:osv.dev, policy:dep-rollup
    # Optional for backwards compat with pre-0.4.3 scan-findings.json
    # artifacts that don't carry the field; UI/exporters tolerate empty.
    method: str = ""


# ── Analysis rules ───────────────────────────────────────────────────────


def analyze_root_license(repo: str, declared: list[dict]) -> list[Finding]:
    findings: list[Finding] = []
    if not declared:
        findings.append(Finding(
            repo=repo, severity="high", category="license",
            title="No root LICENSE file detected",
            location="(repo root)",
            detail="No LICENSE / COPYING file at the repo root.",
            recommendation=(
                "Confirm with upstream; if the project has no LICENSE we "
                "cannot legally adopt. Request upstream add one or drop the "
                "project from the import list."
            ),
            method="license:no-root-license",
        ))
        return findings
    if all(d["spdx"] == "unknown" for d in declared):
        findings.append(Finding(
            repo=repo, severity="medium", category="license",
            title="Root LICENSE present but unrecognized",
            location=declared[0]["path"],
            detail=("LICENSE file exists but its content does not match any "
                    "well-known license pattern."),
            recommendation=(
                "Manually inspect the LICENSE file. Add the pattern to "
                "licenses.py LICENSE_PATTERNS if recurring (project may use "
                "a custom but legitimate license like MITRE-ATT&CK or DRL)."
            ),
            method="license:root-license-unknown-spdx",
        ))
    return findings


def analyze_nested_licenses(repo: str, root_license: str | None,
                            nested: list[dict],
                            dual_license_dirs: dict | None = None,
                            documented_dispositions: dict | None = None) -> list[Finding]:
    """Emit findings for non-permissive licenses found below the repo root.

    Args:
      repo: repo name
      root_license: SPDX of the repo's root LICENSE
      nested: list of license-file records (dicts with path/spdx/depth/authoritative)
      dual_license_dirs: optional {dir: DualLicense} from
        hiddenshadow.dual_license.detect_dual_license_dirs(). If a
        nested-license file is inside a dual-license directory, its finding
        is demoted to INFO with a "documented elected license" note.
      documented_dispositions: optional {repo: [DocumentedDisposition]} from
        hiddenshadow.metadata_aware.load_metadata_dispositions(). When
        a finding's location matches a documented file, it is suppressed
        and replaced with a single info entry referencing the METADATA.
    """
    from .dual_license import find_within_dual_dir  # avoid circular at import time
    from .metadata_aware import find_disposition
    dual_license_dirs = dual_license_dirs or {}
    documented_dispositions = documented_dispositions or {}
    findings: list[Finding] = []
    for nf in nested:
        nspdx = nf["spdx"]
        if nspdx in ("unknown", root_license):
            continue
        cls, dec = LICENSE_CLASS.get(nspdx, ("unknown", "unknown"))
        non_authoritative = not nf.get("authoritative", True)

        # METADATA-aware suppression: if METADATA documents this file's
        # disposition, we emit a single suppressed-info entry and stop.
        # CI scans against the monorepo will then show only NEW findings
        # that weren't documented at fork import time.
        doc = find_disposition(repo, nf["path"], documented_dispositions)
        if doc is not None:
            elected = doc.selection or doc.license
            findings.append(Finding(
                repo=repo, severity="info", category="license",
                title=(f"Documented in METADATA: {nspdx} — action={doc.action}"),
                location=nf["path"],
                detail=(
                    f"This file's disposition is recorded in "
                    f"third_party/{repo}/METADATA.yaml. License: {doc.license}; "
                    f"action: {doc.action}; elected: {elected or 'n/a'}. "
                    f"{doc.note[:160]}{'...' if len(doc.note) > 160 else ''}"
                ),
                recommendation=(
                    "No action required — finding was OSPO-approved at fork "
                    "import. To re-open the discussion, update the entry "
                    "in METADATA.yaml's files_with_other_licenses."
                ),
                method="license:metadata-documented",
            ))
            continue  # do not emit higher-severity finding

        # Dual-license demotion: if this file lives inside a dual-license
        # directory, the finding is INFO regardless of license class —
        # because the dual-license fact already documents both licenses,
        # and the elected license is policy-compliant.
        dl = find_within_dual_dir(nf["path"], dual_license_dirs)
        if dl is not None and nspdx in dl.licenses:
            elected = next(
                (l for l in dl.licenses if LICENSE_CLASS.get(l, ("","unknown"))[1] == "adopt"),
                dl.licenses[0],
            )
            findings.append(Finding(
                repo=repo, severity="info", category="license",
                title=(f"Dual-license file: {nspdx} (alongside "
                       f"{', '.join(l for l in dl.licenses if l != nspdx)})"),
                location=nf["path"],
                detail=(
                    f"Directory `{dl.directory}` is dual-licensed "
                    f"({dl.spdx_expression}) — detected via "
                    f"{dl.detection_method}. Evidence: {dl.evidence_files}."
                ),
                recommendation=(
                    f"Document the license election in METADATA.yaml's "
                    f"license.files_with_other_licenses array. Recommended "
                    f"election: {elected} (the permissive option). Mark all "
                    f"dual-license files in this directory with action: "
                    f"`kept` (elected) or `kept-but-not-elected` (other)."
                ),
                method="license:dual-license-detected",
            ))
            continue  # do not also emit the higher-severity finding

        if dec == "avoid":
            base_sev = "critical" if cls in ("network-copyleft", "source-available") else "high"
            sev = "info" if non_authoritative else base_sev
            title_suffix = " (in docs/test path — likely informational)" if non_authoritative else ""
            rec = (
                "In a docs/test/example path — likely just license-text-as-data "
                "or a test fixture, not authoritative. Verify by inspection."
                if non_authoritative else
                f"Quarantine the affected directory in PATCHES/ at fork "
                f"import, or exclude it from the build. Document in "
                f"METADATA.yaml's license.files_with_other_licenses array. "
                f"If unavoidable in the build, escalate to OSPO."
            )
            findings.append(Finding(
                repo=repo, severity=sev, category="license",
                title=f"Non-permissive license inside repo: {nspdx}{title_suffix}",
                location=nf["path"],
                detail=(f"Found {nspdx} ({cls}) at depth {nf['depth']} inside an "
                        f"otherwise-{root_license or 'unknown'} repo."),
                recommendation=rec,
                method="license:nested-non-permissive",
            ))
        elif dec == "library":
            sev = "info" if non_authoritative else "medium"
            rec = (
                "In a docs/test path — likely informational. Verify if uncertain."
                if non_authoritative else
                f"Verify the {nspdx} content is used as a separate library, "
                f"not statically linked into permissive code paths. Document "
                f"in METADATA.yaml. MPL/LGPL at module boundary is policy-OK; "
                f"static inclusion is not."
            )
            findings.append(Finding(
                repo=repo, severity=sev, category="license",
                title=f"Weak-copyleft license inside repo: {nspdx}",
                location=nf["path"],
                detail=(f"{nspdx} ({cls}) found at depth {nf['depth']}. "
                        f"Acceptable only at module boundary."),
                recommendation=rec,
                method="license:nested-weak-copyleft",
            ))
    return findings


def analyze_spdx_headers(repo: str, root_license: str | None,
                         counts: dict[str, int]) -> list[Finding]:
    findings: list[Finding] = []
    if not counts or not root_license:
        return findings
    for spdx, count in counts.items():
        spdx_norm = spdx.split(" ")[0].split(",")[0].strip()
        if not spdx_norm or spdx_norm == root_license:
            continue
        cls, dec = LICENSE_CLASS.get(spdx_norm, ("unknown", "unknown"))
        if dec == "avoid":
            findings.append(Finding(
                repo=repo, severity="high", category="license",
                title=f"Source files claim non-permissive license: {spdx}",
                location="(SPDX-License-Identifier headers)",
                detail=(f"{count} source file(s) carry SPDX-License-Identifier: "
                        f"{spdx} (root license is {root_license})."),
                recommendation=(
                    "Audit those files. Either remove them, replace with "
                    "permissive equivalents, or quarantine. Record in "
                    "METADATA.yaml's license.files_with_other_licenses."
                ),
                method="license:spdx-header-non-permissive",
            ))
        elif dec != "unknown":
            findings.append(Finding(
                repo=repo, severity="info", category="license",
                title=f"Mixed SPDX headers: {spdx}",
                location="(SPDX-License-Identifier headers)",
                detail=f"{count} source file(s) declare {spdx}.",
                recommendation=(
                    "Likely intentional (vendored sub-libraries with "
                    "compatible licenses). Document in METADATA."
                ),
                method="license:spdx-header-mixed",
            ))
    return findings


def analyze_manifests(repo: str, manifests: dict[str, int]) -> list[Finding]:
    findings: list[Finding] = []
    if not manifests:
        findings.append(Finding(
            repo=repo, severity="info", category="sbom",
            title="No package-manager manifests detected",
            location="(repo root)",
            detail=("No package.json, Cargo.toml, pyproject.toml, etc. "
                    "found in the repo."),
            recommendation=(
                "OK if the project doesn't use a standard manifest (pure C "
                "with hand-rolled Make, etc.). Note in METADATA.yaml that "
                "SBOM must be generated from build artifacts (e.g., via "
                "syft on the compiled binary)."
            ),
            method="sbom:no-manifests-detected",
        ))
    return findings


def analyze_dep_rollup(rollup: list[dict]) -> list[Finding]:
    """Across-repo dep rollup. Flag deps that need license review and
    deps known to be problematic."""
    findings: list[Finding] = []
    for r in rollup:
        name = r["name"]
        # Direct match against problematic list
        if name in KNOWN_PROBLEMATIC_DEPS:
            findings.append(Finding(
                repo="(rollup)", severity="high", category="dep",
                title=f"Dependency known to be non-permissive: {name}",
                location=r["package_manager"],
                detail=(f"`{name}` declared license: "
                        f"{KNOWN_PROBLEMATIC_DEPS[name]}. Used in "
                        f"{r['occurrences']} manifests."),
                recommendation=(
                    f"Replace `{name}` with a permissive equivalent before "
                    f"vendoring. Document the substitution in PATCHES/."
                ),
                method="policy:problematic-dep",
            ))
            continue
        # Skip well-known-permissive
        if name in KNOWN_PERMISSIVE_DEPS:
            continue
        # Top-N for review
        if r.get("declared_license"):
            continue  # already known via manifest
        if r["occurrences"] >= 5:
            findings.append(Finding(
                repo="(rollup)", severity="info", category="dep",
                title=f"Top dep needs license lookup: {name}",
                location=r["package_manager"],
                detail=(f"Used in {r['occurrences']} manifests across "
                        f"{r['repo_count']} repos. Versions: "
                        f"{r['versions'][:80]}"
                        f"{'...' if len(r['versions']) > 80 else ''}"),
                recommendation=(
                    f"Look up `{name}` on the upstream {r['package_manager']} "
                    f"registry. If non-permissive, OSPO must approve. If "
                    f"transitive only, document in NOTICE."
                ),
                method="policy:dep-needs-license-lookup",
            ))
    return findings
