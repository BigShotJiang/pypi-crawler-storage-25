"""METADATA-aware finding suppression.

When a fork has been imported into the monorepo, its third_party/<fork>/
directory typically contains a METADATA.yaml whose
license.files_with_other_licenses array enumerates known non-permissive
files and the OSPO-approved disposition for each (e.g., "kept", "kept-
but-not-elected", "vendored-unmodified", "excluded-from-build").

This module loads those declarations and returns a map the analyzer
uses to suppress (or demote) findings that match a documented entry.

Effect on findings:
  - Finding location MATCHES a documented file → finding is replaced
    with a single info-level entry that says "Documented in METADATA"
    plus the disposition.
  - Finding location DOES NOT match any METADATA entry → emitted as
    normal (this is the "new finding since last import" case CI catches).
"""
from __future__ import annotations
import fnmatch
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

try:
    import yaml
    _HAVE_YAML = True
except ImportError:
    _HAVE_YAML = False


@dataclass
class DocumentedDisposition:
    """One row from license.files_with_other_licenses."""
    path: str               # path inside the fork, possibly with glob
    license: str            # SPDX or compound expression
    action: str             # kept, kept-but-not-elected, vendored-unmodified,
                            # excluded-from-build, removed, quarantined
    selection: str = ""     # darkshadow_license_selection — which we elect
    note: str = ""


def load_metadata_dispositions(third_party_root: Path) -> dict[str, list[DocumentedDisposition]]:
    """Walk third_party/<repo>/METADATA.yaml and return per-repo dispositions.

    Returns: {repo_name: [DocumentedDisposition, ...]}
    Repos without METADATA.yaml or without files_with_other_licenses
    are absent from the result.
    """
    result: dict[str, list[DocumentedDisposition]] = {}
    if not _HAVE_YAML or not third_party_root.exists():
        return result
    for child in third_party_root.iterdir():
        if not child.is_dir():
            continue
        meta_path = child / "METADATA.yaml"
        if not meta_path.exists():
            continue
        try:
            data = yaml.safe_load(meta_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        license_block = (data.get("license") or {})
        entries = license_block.get("files_with_other_licenses") or []
        items: list[DocumentedDisposition] = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            items.append(DocumentedDisposition(
                path=str(entry.get("path", "")).rstrip("/"),
                license=str(entry.get("license", "")),
                action=str(entry.get("action", "")),
                selection=str(entry.get("darkshadow_license_selection",
                                        entry.get("nuperion_license_selection", ""))),
                note=str(entry.get("note", "")),
            ))
        if items:
            result[child.name] = items
    return result


def find_disposition(repo: str, location: str,
                     dispositions: dict[str, list[DocumentedDisposition]]
                     ) -> DocumentedDisposition | None:
    """Return the disposition that covers `location` (a file path within
    the repo), if any. Glob and prefix matching supported.

    Match semantics:
      - Exact path match: 'lib/zstd-1.5.7/COPYING' == 'lib/zstd-1.5.7/COPYING'
      - Directory prefix: 'vendor/cyphar.com/go-pathrs/'
        matches anything under that path
      - Glob: 'lib/zstd-*/*' matches via fnmatch
    """
    if repo not in dispositions:
        return None
    norm_loc = location.replace("\\", "/").lstrip("./")
    for d in dispositions[repo]:
        pat = d.path.replace("\\", "/").lstrip("./")
        if not pat:
            continue
        if pat == norm_loc:
            return d
        # Directory prefix
        if pat.endswith("/") or "*" not in pat:
            if norm_loc.startswith(pat.rstrip("/") + "/"):
                return d
        # Glob
        if "*" in pat or "?" in pat:
            if fnmatch.fnmatch(norm_loc, pat):
                return d
    return None
