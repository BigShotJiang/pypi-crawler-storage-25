"""Additional web endpoints for tfscan, containerscan, ci-scan, check, watch.

These extend the existing :mod:`hiddenshadow.web` Flask app with routes
for every scanner added since 0.5.0. The job-queue + SSE pattern from
``web.ScanJob`` is reused; each new endpoint kicks off a background
thread that records events and findings on a job object the frontend
can poll or stream.

A separate registry (``_aux_jobs``) keeps the new jobs isolated from the
main-scan registry so the existing UI behavior is unchanged.
"""
from __future__ import annotations

import json
import os
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from queue import Queue, Empty
from typing import Any, Callable

from flask import Flask, jsonify, request, Response, send_file, abort

from .findings import Finding


# ── Generic auxiliary-job model ────────────────────────────────────────

@dataclass
class AuxJob:
    """A background job for any non-main-scan command."""
    job_id: str
    kind: str                              # 'tfscan' | 'containerscan' | ...
    source_root: str
    output_root: str
    started_at: float = field(default_factory=time.time)
    status: str = "queued"                 # queued | running | complete | error
    error: str | None = None
    summary: dict[str, Any] | None = None
    findings: list[dict[str, Any]] = field(default_factory=list)
    artifacts: dict[str, str] = field(default_factory=dict)  # name -> abs path
    history: list[dict[str, Any]] = field(default_factory=list)
    subscribers: list[Queue] = field(default_factory=list)
    finished: bool = False
    lock: threading.Lock = field(default_factory=threading.Lock)


_aux_jobs: dict[str, AuxJob] = {}
_aux_jobs_lock = threading.Lock()
_END = object()


def _emit(job: AuxJob, event: dict[str, Any]) -> None:
    with job.lock:
        job.history.append(event)
        subs = list(job.subscribers)
    for q in subs:
        q.put(event)


def _finish(job: AuxJob) -> None:
    with job.lock:
        job.finished = True
        subs = list(job.subscribers)
    for q in subs:
        q.put(_END)


def _subscribe(job: AuxJob) -> tuple[list[dict[str, Any]], Queue | None]:
    with job.lock:
        backlog = list(job.history)
        if job.finished:
            return backlog, None
        q: Queue = Queue()
        job.subscribers.append(q)
        return backlog, q


def _unsubscribe(job: AuxJob, q: Queue) -> None:
    with job.lock:
        try:
            job.subscribers.remove(q)
        except ValueError:
            pass


def _validate_source(body: dict, key: str = "source_root") -> tuple[Path, str | None]:
    """Common request-shape validation. Returns (path, error_message)."""
    raw = (body.get(key) or "").strip()
    if not raw:
        return Path(), f"{key} is required"
    p = Path(raw)
    if not p.exists():
        return Path(), f"Path does not exist: {raw}"
    if not p.is_dir():
        return Path(), f"Not a directory: {raw}"
    return p.resolve(), None


def _job_response(job: AuxJob) -> dict[str, Any]:
    return {
        "job_id": job.job_id, "kind": job.kind,
        "source_root": job.source_root,
        "output_root": job.output_root,
    }


def _spawn(job: AuxJob, target: Callable[[AuxJob], None]) -> None:
    """Run ``target(job)`` in a daemon thread with the queued/running/
    complete/error lifecycle handled here."""
    def runner() -> None:
        job.status = "running"
        _emit(job, {"type": "status", "status": "running"})
        try:
            target(job)
            job.status = "complete"
            _emit(job, {"type": "status", "status": "complete",
                        "summary": job.summary or {}})
        except Exception as e:
            job.error = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
            job.status = "error"
            _emit(job, {"type": "error", "message": str(e)})
            _emit(job, {"type": "status", "status": "error"})
        finally:
            _finish(job)

    threading.Thread(target=runner, daemon=True,
                     name=f"{job.kind}-{job.job_id[:8]}").start()


# ── Auth gate (X-HS-Token header) ──────────────────────────────────────

_auth_token: str | None = None
_auth_lock = threading.Lock()


def set_auth_token(token: str | None) -> None:
    """Configure (or clear) the required X-HS-Token header value."""
    global _auth_token
    with _auth_lock:
        _auth_token = token


def get_auth_token() -> str | None:
    with _auth_lock:
        return _auth_token


def _auth_required() -> Response | None:
    """Returns a 401 response if the request lacks the configured token."""
    expected = get_auth_token()
    if expected is None:
        return None
    got = request.headers.get("X-HS-Token", "")
    if got != expected:
        return jsonify({"error": "missing or invalid X-HS-Token"}), 401
    return None


# ── Findings helpers (shared between scanners) ─────────────────────────

def _findings_to_payload(findings: list[Finding]) -> list[dict[str, Any]]:
    return [asdict(f) for f in findings]


def _by_severity(findings: list[Finding]) -> dict[str, int]:
    out = {s: 0 for s in ("critical", "high", "medium", "low", "info")}
    for f in findings:
        out[f.severity] = out.get(f.severity, 0) + 1
    return out


def _write_artifact(job: AuxJob, name: str, body: bytes | str) -> None:
    out_root = Path(job.output_root)
    log_dir = out_root / "_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    p = log_dir / name
    if isinstance(body, str):
        p.write_text(body, encoding="utf-8")
    else:
        p.write_bytes(body)
    job.artifacts[name] = str(p)


# ── Scanner runners ────────────────────────────────────────────────────

def _run_tfscan(job: AuxJob, options: dict[str, Any]) -> None:
    """Body for tfscan jobs."""
    from . import iac as iac_mod
    from . import sarif as sarif_mod
    from . import diffmode
    from . import __version__

    clouds = tuple(options.get("clouds") or ("aws", "gcp"))
    src = Path(job.source_root)

    _emit(job, {"type": "phase", "name": "discovery",
                "message": "Discovering .tf files..."})
    iac_findings = iac_mod.scan_path(src, clouds=clouds)
    findings = [f.to_finding(src.name) for f in iac_findings]

    if options.get("diff_base"):
        changed = diffmode.changed_files(src, base_ref=options["diff_base"])
        if changed is not None:
            findings = diffmode.filter_findings_by_files(findings, changed)
            _emit(job, {"type": "phase", "name": "diff",
                        "message": f"Diff-mode kept {len(findings)} findings"})

    by_sev = _by_severity(findings)
    job.findings = _findings_to_payload(findings)
    job.summary = {
        "files_scanned": len(iac_mod.find_tf_files(src)),
        "clouds": list(clouds),
        "by_severity": by_sev,
        "total_findings": len(findings),
    }

    _write_artifact(job, "tfscan-findings.json",
                    json.dumps({
                        "generated_at": datetime.now(timezone.utc).isoformat(),
                        "source_root": str(src),
                        "clouds": list(clouds),
                        "by_severity": by_sev,
                        "findings": job.findings,
                    }, indent=2))

    if options.get("emit_sarif"):
        sarif_doc = sarif_mod.findings_to_sarif(
            findings, tool_version=__version__, source_root=src)
        _write_artifact(job, "tfscan-findings.sarif",
                        json.dumps(sarif_doc, indent=2))


def _run_containerscan(job: AuxJob, options: dict[str, Any]) -> None:
    """Body for containerscan jobs."""
    from . import containers as cont_mod
    from . import sarif as sarif_mod
    from . import diffmode
    from . import __version__

    src = Path(job.source_root)
    scan_layers = bool(options.get("scan_layers", True))
    cve_lookup = bool(options.get("cve_lookup", True))
    cache_dir = src / "_cache"

    _emit(job, {"type": "phase", "name": "static",
                "message": "Running Dockerfile + compose rules..."})
    container_findings = cont_mod.scan_path(
        src, repo_name=src.name,
        scan_layers=scan_layers, cve_lookup=cve_lookup,
        cache_dir=cache_dir,
    )
    findings = [c.to_finding() for c in container_findings]

    if options.get("diff_base"):
        changed = diffmode.changed_files(src, base_ref=options["diff_base"])
        if changed is not None:
            findings = diffmode.filter_findings_by_files(findings, changed)
            _emit(job, {"type": "phase", "name": "diff",
                        "message": f"Diff-mode kept {len(findings)} findings"})

    by_sev = _by_severity(findings)
    job.findings = _findings_to_payload(findings)
    job.summary = {
        "scan_layers": scan_layers, "cve_lookup": cve_lookup,
        "by_severity": by_sev,
        "total_findings": len(findings),
    }

    _write_artifact(job, "containerscan-findings.json",
                    json.dumps({
                        "generated_at": datetime.now(timezone.utc).isoformat(),
                        "source_root": str(src),
                        "scan_layers": scan_layers, "cve_lookup": cve_lookup,
                        "by_severity": by_sev,
                        "findings": job.findings,
                    }, indent=2))

    if options.get("emit_sarif"):
        sarif_doc = sarif_mod.findings_to_sarif(
            findings, tool_version=__version__, source_root=src)
        _write_artifact(job, "containerscan-findings.sarif",
                        json.dumps(sarif_doc, indent=2))


def _run_ciscan(job: AuxJob, options: dict[str, Any]) -> None:
    """Body for ci-scan jobs."""
    from . import ci_pipelines as cip
    from . import ci_misc
    from . import sarif as sarif_mod
    from . import diffmode
    from . import __version__

    src = Path(job.source_root)
    _emit(job, {"type": "phase", "name": "pipelines",
                "message": "Scanning CI/CD pipeline configs..."})
    ci_findings = cip.scan_path(src, repo_name=src.name)
    misc_findings = ci_misc.scan_path(src, repo=src.name)
    findings = [c.to_finding() for c in ci_findings] + misc_findings

    if options.get("diff_base"):
        changed = diffmode.changed_files(src, base_ref=options["diff_base"])
        if changed is not None:
            findings = diffmode.filter_findings_by_files(findings, changed)
            _emit(job, {"type": "phase", "name": "diff",
                        "message": f"Diff-mode kept {len(findings)} findings"})

    by_sev = _by_severity(findings)
    job.findings = _findings_to_payload(findings)
    job.summary = {
        "by_severity": by_sev,
        "total_findings": len(findings),
    }

    _write_artifact(job, "cipipeline-findings.json",
                    json.dumps({
                        "generated_at": datetime.now(timezone.utc).isoformat(),
                        "source_root": str(src),
                        "by_severity": by_sev,
                        "findings": job.findings,
                    }, indent=2))

    if options.get("emit_sarif"):
        sarif_doc = sarif_mod.findings_to_sarif(
            findings, tool_version=__version__, source_root=src)
        _write_artifact(job, "cipipeline-findings.sarif",
                        json.dumps(sarif_doc, indent=2))


def _run_check(job: AuxJob, options: dict[str, Any]) -> None:
    """Body for the one-shot 'check' job (scan + iac + container + ci)."""
    from . import scan as scan_mod
    from . import ci_pipelines as cip
    from . import ci_misc
    from . import sarif as sarif_mod
    from . import diffmode
    from . import __version__
    from .findings import Finding

    src = Path(job.source_root)
    _emit(job, {"type": "phase", "name": "main-scan",
                "message": "Running main scan..."})
    summary = scan_mod.run(
        source_root=src, output_root=src, quiet=True,
        detect_iac=True, detect_containers=True,
    )
    all_findings: list[Finding] = [
        Finding(**f) for f in summary["findings"]["findings"]
    ]
    _emit(job, {"type": "phase", "name": "ci",
                "message": "Running CI pipeline scan..."})
    ci_findings = cip.scan_path(src, repo_name=src.name)
    all_findings.extend(c.to_finding() for c in ci_findings)
    all_findings.extend(ci_misc.scan_path(src, repo=src.name))

    if options.get("diff_base"):
        changed = diffmode.changed_files(src, base_ref=options["diff_base"])
        if changed is not None:
            all_findings = diffmode.filter_findings_by_files(
                all_findings, changed)

    by_sev = _by_severity(all_findings)
    job.findings = _findings_to_payload(all_findings)
    job.summary = {
        "by_severity": by_sev,
        "total_findings": len(all_findings),
    }

    if options.get("emit_sarif", True):  # default ON for check
        sarif_doc = sarif_mod.findings_to_sarif(
            all_findings, tool_version=__version__, source_root=src)
        _write_artifact(job, "check-findings.sarif",
                        json.dumps(sarif_doc, indent=2))
    _write_artifact(job, "check-findings.json",
                    json.dumps({
                        "generated_at": datetime.now(timezone.utc).isoformat(),
                        "source_root": str(src),
                        "by_severity": by_sev,
                        "findings": job.findings,
                    }, indent=2))


# ── Watch jobs (long-running, periodic) ────────────────────────────────

@dataclass
class WatchJob(AuxJob):
    interval_s: int = 86400
    runs: list[dict[str, Any]] = field(default_factory=list)
    diffs: list[dict[str, Any]] = field(default_factory=list)
    stop_event: threading.Event = field(default_factory=threading.Event)


def _watch_loop(job: WatchJob) -> None:
    """Background body for a watch job."""
    from . import watch as watch_mod
    src = Path(job.source_root)
    out = Path(job.output_root)
    while not job.stop_event.is_set():
        try:
            _emit(job, {"type": "phase", "name": "scan",
                        "message": "Watch tick: running scan..."})
            artifact, diff = watch_mod.run_once(src, out)
            run_record = {
                "artifact": str(artifact),
                "stamp": diff.current_stamp,
                "new_count": len(diff.new_findings),
                "resolved_count": len(diff.resolved_findings),
                "unchanged": diff.unchanged,
                "by_severity": diff.new_by_severity,
            }
            with job.lock:
                job.runs.append(run_record)
                job.diffs.append({
                    "stamp": diff.current_stamp,
                    "prior_stamp": diff.prior_stamp,
                    "new_findings": diff.new_findings,
                    "resolved_findings": diff.resolved_findings,
                    "unchanged": diff.unchanged,
                })
                job.findings = list(diff.new_findings)
            _emit(job, {"type": "watch_tick", **run_record})
        except Exception as e:
            _emit(job, {"type": "error", "message": str(e)})
        # Interruptible sleep
        if job.stop_event.wait(job.interval_s):
            break


# ── Public: register routes on an existing Flask app ──────────────────

def register(app: Flask) -> None:
    """Add the new endpoints to an existing Flask app.

    Called from :func:`hiddenshadow.web.create_app` after the main
    routes are registered."""

    # ── Auth-token application as a before_request hook ──
    @app.before_request
    def _check_auth() -> Response | None:
        # GET / and static assets are always reachable so the SPA loads.
        if request.method == "GET" and request.path in ("/", "/api/ping"):
            return None
        if request.path.startswith("/static/"):
            return None
        return _auth_required()

    # ── tfscan ──
    @app.post("/api/tfscan")
    def api_tfscan() -> Any:
        body = request.get_json(silent=True) or {}
        src, err = _validate_source(body)
        if err:
            return jsonify({"error": err}), 400
        clouds_raw = body.get("clouds") or "all"
        clouds = (("aws", "gcp")
                  if clouds_raw == "all" else (clouds_raw,)
                  if isinstance(clouds_raw, str) else tuple(clouds_raw))
        job = AuxJob(
            job_id=uuid.uuid4().hex, kind="tfscan",
            source_root=str(src), output_root=str(src),
        )
        with _aux_jobs_lock:
            _aux_jobs[job.job_id] = job
        _spawn(job, lambda j: _run_tfscan(j, {
            "clouds": clouds,
            "diff_base": body.get("diff_base"),
            "emit_sarif": bool(body.get("emit_sarif", False)),
        }))
        return jsonify(_job_response(job))

    # ── containerscan ──
    @app.post("/api/containerscan")
    def api_containerscan() -> Any:
        body = request.get_json(silent=True) or {}
        src, err = _validate_source(body)
        if err:
            return jsonify({"error": err}), 400
        job = AuxJob(
            job_id=uuid.uuid4().hex, kind="containerscan",
            source_root=str(src), output_root=str(src),
        )
        with _aux_jobs_lock:
            _aux_jobs[job.job_id] = job
        _spawn(job, lambda j: _run_containerscan(j, {
            "scan_layers": bool(body.get("scan_layers", True)),
            "cve_lookup": bool(body.get("cve_lookup", True)),
            "diff_base": body.get("diff_base"),
            "emit_sarif": bool(body.get("emit_sarif", False)),
        }))
        return jsonify(_job_response(job))

    # ── ci-scan ──
    @app.post("/api/ci-scan")
    def api_ciscan() -> Any:
        body = request.get_json(silent=True) or {}
        src, err = _validate_source(body)
        if err:
            return jsonify({"error": err}), 400
        job = AuxJob(
            job_id=uuid.uuid4().hex, kind="ci-scan",
            source_root=str(src), output_root=str(src),
        )
        with _aux_jobs_lock:
            _aux_jobs[job.job_id] = job
        _spawn(job, lambda j: _run_ciscan(j, {
            "diff_base": body.get("diff_base"),
            "emit_sarif": bool(body.get("emit_sarif", False)),
        }))
        return jsonify(_job_response(job))

    # ── one-shot 'check' (everything) ──
    @app.post("/api/check")
    def api_check() -> Any:
        body = request.get_json(silent=True) or {}
        src, err = _validate_source(body)
        if err:
            return jsonify({"error": err}), 400
        job = AuxJob(
            job_id=uuid.uuid4().hex, kind="check",
            source_root=str(src), output_root=str(src),
        )
        with _aux_jobs_lock:
            _aux_jobs[job.job_id] = job
        _spawn(job, lambda j: _run_check(j, {
            "diff_base": body.get("diff_base"),
            "emit_sarif": bool(body.get("emit_sarif", True)),
        }))
        return jsonify(_job_response(job))

    # ── watch start / stop / status ──
    @app.post("/api/watch/start")
    def api_watch_start() -> Any:
        body = request.get_json(silent=True) or {}
        src, err = _validate_source(body)
        if err:
            return jsonify({"error": err}), 400
        try:
            interval = int(body.get("interval_s", 86400))
        except (TypeError, ValueError):
            interval = 86400
        interval = max(60, min(interval, 86400 * 7))  # clamp [1m, 7d]
        job = WatchJob(
            job_id=uuid.uuid4().hex, kind="watch",
            source_root=str(src), output_root=str(src),
            interval_s=interval,
        )
        with _aux_jobs_lock:
            _aux_jobs[job.job_id] = job

        def runner() -> None:
            job.status = "running"
            _emit(job, {"type": "status", "status": "running",
                        "interval_s": interval})
            try:
                _watch_loop(job)
                job.status = "complete"
                _emit(job, {"type": "status", "status": "complete"})
            except Exception as e:
                job.error = f"{type(e).__name__}: {e}"
                job.status = "error"
                _emit(job, {"type": "error", "message": str(e)})
            finally:
                _finish(job)

        threading.Thread(target=runner, daemon=True,
                         name=f"watch-{job.job_id[:8]}").start()
        return jsonify({**_job_response(job), "interval_s": interval})

    @app.post("/api/watch/<job_id>/stop")
    def api_watch_stop(job_id: str) -> Any:
        job = _aux_jobs.get(job_id)
        if not job or not isinstance(job, WatchJob):
            return jsonify({"error": "unknown watch job"}), 404
        job.stop_event.set()
        return jsonify({"stopping": True})

    @app.get("/api/watch/<job_id>/diff")
    def api_watch_diff(job_id: str) -> Any:
        job = _aux_jobs.get(job_id)
        if not job or not isinstance(job, WatchJob):
            return jsonify({"error": "unknown watch job"}), 404
        with job.lock:
            latest = job.diffs[-1] if job.diffs else None
        return jsonify({"diff": latest})

    @app.get("/api/watch/<job_id>/history")
    def api_watch_history(job_id: str) -> Any:
        job = _aux_jobs.get(job_id)
        if not job or not isinstance(job, WatchJob):
            return jsonify({"error": "unknown watch job"}), 404
        with job.lock:
            return jsonify({"runs": list(job.runs)})

    # ── Generic status / findings / events / artifact for aux jobs ──

    @app.get("/api/aux/<job_id>/status")
    def api_aux_status(job_id: str) -> Any:
        job = _aux_jobs.get(job_id)
        if not job:
            return jsonify({"error": "unknown job"}), 404
        return jsonify({
            "job_id": job.job_id, "kind": job.kind,
            "status": job.status, "started_at": job.started_at,
            "error": job.error, "summary": job.summary,
            "artifacts": list(job.artifacts),
        })

    @app.get("/api/aux/<job_id>/findings")
    def api_aux_findings(job_id: str) -> Any:
        job = _aux_jobs.get(job_id)
        if not job:
            return jsonify({"error": "unknown job"}), 404
        return jsonify({
            "job_id": job.job_id,
            "kind": job.kind,
            "summary": job.summary,
            "findings": job.findings,
        })

    @app.get("/api/aux/<job_id>/events")
    def api_aux_events(job_id: str) -> Any:
        job = _aux_jobs.get(job_id)
        if not job:
            return jsonify({"error": "unknown job"}), 404

        def stream() -> Any:
            backlog, queue = _subscribe(job)
            try:
                for ev in backlog:
                    yield f"data: {json.dumps(ev)}\n\n"
                if queue is None:
                    return
                while True:
                    try:
                        ev = queue.get(timeout=15.0)
                    except Empty:
                        yield ": keep-alive\n\n"
                        continue
                    if ev is _END:
                        return
                    yield f"data: {json.dumps(ev)}\n\n"
            finally:
                if queue is not None:
                    _unsubscribe(job, queue)

        return Response(stream(), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache",
                                 "X-Accel-Buffering": "no"})

    @app.get("/api/aux/<job_id>/artifact")
    def api_aux_artifact(job_id: str) -> Any:
        job = _aux_jobs.get(job_id)
        if not job:
            abort(404)
        name = request.args.get("name", "")
        if not name:
            abort(400)
        path_s = job.artifacts.get(name)
        if not path_s:
            abort(404)
        p = Path(path_s)
        if not p.is_file():
            abort(404)
        return send_file(p, as_attachment=True, download_name=p.name)

    @app.get("/api/aux/jobs")
    def api_aux_list() -> Any:
        """Return the list of aux jobs for the History tab."""
        out = []
        for j in _aux_jobs.values():
            out.append({
                "job_id": j.job_id, "kind": j.kind,
                "source_root": j.source_root,
                "started_at": j.started_at,
                "status": j.status,
                "by_severity": (j.summary or {}).get("by_severity")
                if j.summary else None,
            })
        out.sort(key=lambda x: -x["started_at"])
        return jsonify({"jobs": out})
