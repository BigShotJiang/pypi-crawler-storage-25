"""Desktop launcher for the HiddenShadow web UI.

Used as the entry point for the bundled Windows installer build:
  - Honors config (web_host, web_port, single_instance).
  - If single_instance is enabled and another HiddenShadow is already
    running on the configured port, opens the browser to it and exits 0.
  - Otherwise picks a free port (preferring the configured one), starts
    the Flask app in a background thread, opens the user's default
    browser, and runs silently until the user clicks Stop in the UI
    (which calls /api/shutdown and terminates the process).

Works in both a normal Python env and a PyInstaller --onedir windowed
build (where sys.stdout / sys.stderr may be None).
"""
from __future__ import annotations

import json
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser

from . import __version__
from . import config as config_mod


def _say(msg: str) -> None:
    """print() that's safe when stdout is None (PyInstaller windowed mode)."""
    try:
        if sys.stdout is not None:
            print(msg)
    except Exception:
        pass


def _probe_existing_instance(host: str, port: int,
                             timeout: float = 0.6) -> dict | None:
    """If a HiddenShadow server is already running at host:port, return its
    /api/ping payload. Otherwise return None.

    Conservative: only returns a hit if the response's "app" field is
    "hiddenshadow", so the launcher never hijacks an unrelated server
    that happens to be on the same port.
    """
    url = f"http://{host}:{port}/api/ping"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, OSError, ValueError, TimeoutError):
        return None
    if not isinstance(data, dict) or data.get("app") != "hiddenshadow":
        return None
    return data


def _pick_free_port(host: str, preferred: int) -> int:
    """Return preferred if available on host, else any free ephemeral port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((host, preferred))
            return preferred
        except OSError:
            pass
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((host, 0))
        return s.getsockname()[1]


def _wait_for_port(host: str, port: int, timeout: float = 10.0) -> bool:
    """Poll until the server accepts connections, or give up."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.25)
            try:
                s.connect((host, port))
                return True
            except OSError:
                time.sleep(0.1)
    return False


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        if stream is None:
            continue
        try:
            stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        except Exception:
            pass

    cfg = config_mod.load()
    host = cfg.web_host
    preferred_port = cfg.web_port

    # ── Single-instance: detect an existing HiddenShadow + reuse it ────
    if cfg.single_instance:
        existing = _probe_existing_instance(host, preferred_port)
        if existing is not None:
            url = f"http://{host}:{preferred_port}"
            _say(f"HiddenShadow {__version__} — another instance is already "
                 f"running (pid {existing.get('pid')}, v{existing.get('version')}).")
            _say(f"Opening {url} in the existing instance.")
            try:
                webbrowser.open(url)
            except Exception:
                pass
            return 0

    # ── Otherwise: bring up our own server ─────────────────────────────
    from . import web as web_mod

    port = _pick_free_port(host, preferred_port)
    url = f"http://{host}:{port}"
    app = web_mod.create_app()

    def serve() -> None:
        app.run(host=host, port=port, debug=False,
                threaded=True, use_reloader=False)

    server = threading.Thread(target=serve, daemon=True, name="flask-serve")
    server.start()

    _say(f"HiddenShadow {__version__}  ({cfg.deployment_tier})")
    _say(f"  Web UI: {url}")

    if _wait_for_port(host, port, timeout=10.0):
        try:
            webbrowser.open(url)
        except Exception as e:
            _say(f"  (could not open browser automatically: {e})")
            _say(f"  Open {url} manually.")
    else:
        _say("  Server did not become ready in 10s. Aborting.")
        return 1

    try:
        while server.is_alive():
            server.join(timeout=1.0)
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
