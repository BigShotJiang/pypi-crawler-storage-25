"""File-backed scan-history index — the small-org/individual default.

Implements ``HistoryStorage`` against a single JSON file at the path
specified by ``Config.history_path`` (defaults to
``~/.hiddenshadow/scan-history.json``).

Entries are *metadata only*: source/output paths, timestamps, finding
counts. They don't duplicate the on-disk artifacts (which still live
under each scan's output_root).

Enterprise deployments may swap this for a DB-backed implementation —
see ``hiddenshadow/storage.py``. The module-level functions (``load_all``,
``record``, ``delete``, ``delete_with_artifacts``, ``clear_all``) remain
the *public API* and dispatch to whichever backend the configuration has
selected, so callers (the web layer) never need to know which is active.
"""
from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from . import config as config_mod
from .storage import (
    HistoryEntry, HistoryStorage,
    register_history_backend, get_history_storage,
)

# Re-export so existing call sites keep working unchanged.
__all__ = [
    "HistoryEntry",
    "load_all", "record", "delete", "delete_with_artifacts",
    "clear_all", "history_file_path",
    "FileHistoryStorage",
]


class FileHistoryStorage(HistoryStorage):
    """Single-JSON-file backend. Process-safe via an in-process lock;
    cross-process safety relies on atomic os.replace on the rename step."""

    def __init__(self, path: str | None = None, max_entries: int | None = None):
        cfg = config_mod.load()
        self._path = Path(path or cfg.history_path).expanduser()
        self._max = int(max_entries if max_entries is not None
                        else cfg.history_max_entries)
        self._lock = threading.Lock()

    @property
    def path(self) -> Path:
        return self._path

    def _ensure_dir(self) -> Path:
        """Ensure the parent directory exists; fall back to CWD if HOME isn't
        writable (some sandboxed launcher environments)."""
        p = self._path
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            probe = p.parent / ".write-probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            return p
        except OSError:
            fallback = Path.cwd() / ".hiddenshadow" / p.name
            fallback.parent.mkdir(parents=True, exist_ok=True)
            self._path = fallback
            return fallback

    def load_all(self) -> list[HistoryEntry]:
        p = self._path
        if not p.exists():
            return []
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        if not isinstance(data, list):
            return []
        out: list[HistoryEntry] = []
        for raw in data:
            if not isinstance(raw, dict):
                continue
            try:
                out.append(HistoryEntry(
                    job_id=str(raw.get("job_id", "")),
                    source_root=str(raw.get("source_root", "")),
                    output_root=str(raw.get("output_root", "")),
                    started_at=float(raw.get("started_at", 0.0)),
                    finished_at=float(raw.get("finished_at", 0.0)),
                    duration_s=float(raw.get("duration_s", 0.0)),
                    status=str(raw.get("status", "complete")),
                    repos_scanned=int(raw.get("repos_scanned", 0)),
                    total_findings=int(raw.get("total_findings", 0)),
                    by_severity=dict(raw.get("by_severity") or {}),
                    behavior_profile=dict(raw.get("behavior_profile") or {}),
                    error=raw.get("error"),
                    label=raw.get("label"),
                ))
            except (TypeError, ValueError):
                continue
        out.sort(key=lambda e: e.finished_at, reverse=True)
        return out

    def _save_all(self, entries: list[HistoryEntry]) -> None:
        p = self._ensure_dir()
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps([asdict(e) for e in entries], indent=2),
                       encoding="utf-8")
        os.replace(tmp, p)

    def record(self, entry: HistoryEntry) -> None:
        with self._lock:
            entries = self.load_all()
            entries = [e for e in entries if e.job_id != entry.job_id]
            entries.append(entry)
            entries.sort(key=lambda e: e.finished_at, reverse=True)
            if len(entries) > self._max:
                entries = entries[: self._max]
            self._save_all(entries)

    def delete(self, job_id: str) -> bool:
        with self._lock:
            entries = self.load_all()
            before = len(entries)
            entries = [e for e in entries if e.job_id != job_id]
            if len(entries) == before:
                return False
            self._save_all(entries)
            return True

    def delete_with_artifacts(self, job_id: str) -> dict[str, Any]:
        with self._lock:
            entries = self.load_all()
            target = next((e for e in entries if e.job_id == job_id), None)
            result: dict[str, Any] = {
                "removed_entry": False,
                "removed_files": [],
                "errors": [],
            }
            if target is None:
                return result

            out_root = Path(target.output_root)
            candidates = [
                out_root / "_logs" / "scan-findings.json",
                out_root / "_logs" / "scan-summary.csv",
                out_root / "_logs" / "library-rollup.csv",
            ]
            for cand in candidates:
                if cand.exists():
                    try:
                        cand.unlink()
                        result["removed_files"].append(str(cand))
                    except OSError as e:
                        result["errors"].append(f"{cand}: {e}")

            entries = [e for e in entries if e.job_id != job_id]
            self._save_all(entries)
            result["removed_entry"] = True
            return result

    def clear_all(self) -> int:
        with self._lock:
            entries = self.load_all()
            self._save_all([])
            return len(entries)

    def describe(self) -> dict[str, Any]:
        return {
            "backend": "file",
            "path": str(self._path),
            "max_entries": self._max,
            "deployment_tier": config_mod.load().deployment_tier,
        }


# Register so config_history_backend = "file" resolves to this class.
register_history_backend("file", FileHistoryStorage)


# ── Module-level facade (unchanged public API) ───────────────────────────

def load_all() -> list[HistoryEntry]:
    return get_history_storage().load_all()


def record(entry: HistoryEntry) -> None:
    get_history_storage().record(entry)


def delete(job_id: str) -> bool:
    return get_history_storage().delete(job_id)


def delete_with_artifacts(job_id: str) -> dict[str, Any]:
    return get_history_storage().delete_with_artifacts(job_id)


def clear_all() -> int:
    return get_history_storage().clear_all()


def history_file_path() -> str:
    """Return a human-readable description of where history is stored.

    Backwards-compatible name: when the file backend is active it returns
    the JSON file path; for other backends it returns the connection
    description (e.g. 'postgres://...').
    """
    s = get_history_storage()
    info = s.describe()
    return info.get("path") or info.get("backend", "unknown")
