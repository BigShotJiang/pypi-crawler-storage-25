"""SQLite-backed scan-history storage.

Demonstrates the ``HistoryStorage`` plug-in pattern. The small-org
installer doesn't use this — it ships ``history_backend = "file"`` —
but it's bundled in the package so an enterprise deployment can flip a
single config key:

    {"history_backend": "sqlite",
     "sqlite_path": "/var/lib/hiddenshadow/history.db"}

A real Postgres / MySQL backend follows the same shape: register a new
``HistoryStorage`` implementation under a unique name and point the
config at it. The web layer is unchanged.

Concurrency: a single ``sqlite3.Connection`` is shared across threads
with ``check_same_thread=False``; mutating calls serialize on an internal
lock. WAL journal mode is enabled for reader/writer concurrency.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any

from . import config as config_mod
from .storage import (
    HistoryEntry, HistoryStorage, register_history_backend,
)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    job_id           TEXT PRIMARY KEY,
    source_root      TEXT NOT NULL,
    output_root      TEXT NOT NULL,
    started_at       REAL NOT NULL,
    finished_at      REAL NOT NULL,
    duration_s       REAL NOT NULL,
    status           TEXT NOT NULL,
    repos_scanned    INTEGER NOT NULL DEFAULT 0,
    total_findings   INTEGER NOT NULL DEFAULT 0,
    by_severity_json TEXT NOT NULL DEFAULT '{}',
    behavior_json    TEXT NOT NULL DEFAULT '{}',
    error            TEXT,
    label            TEXT
);

CREATE INDEX IF NOT EXISTS scans_finished_at_idx
    ON scans (finished_at DESC);
"""


class SqliteHistoryStorage(HistoryStorage):
    """SQLite-backed HistoryStorage.

    Config keys consulted (all optional):
      sqlite_path        — path to the .db file. Default: <data dir>/history.db
      history_max_entries — soft cap; oldest dropped on overflow.
    """

    def __init__(self, db_path: str | None = None,
                 max_entries: int | None = None):
        cfg = config_mod.load()
        raw = db_path or getattr(cfg, "sqlite_path", None) or (
            str(Path(cfg.history_path).expanduser().parent / "history.db")
        )
        self._path = Path(raw).expanduser()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._max = int(max_entries if max_entries is not None
                        else cfg.history_max_entries)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(
            str(self._path),
            check_same_thread=False,
            isolation_level=None,           # autocommit; explicit BEGIN below
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(_SCHEMA)

    @property
    def path(self) -> Path:
        return self._path

    # ── Row mapping ────────────────────────────────────────────────────

    @staticmethod
    def _row_to_entry(r: sqlite3.Row) -> HistoryEntry:
        return HistoryEntry(
            job_id=r["job_id"],
            source_root=r["source_root"],
            output_root=r["output_root"],
            started_at=float(r["started_at"]),
            finished_at=float(r["finished_at"]),
            duration_s=float(r["duration_s"]),
            status=r["status"],
            repos_scanned=int(r["repos_scanned"]),
            total_findings=int(r["total_findings"]),
            by_severity=json.loads(r["by_severity_json"] or "{}"),
            behavior_profile=json.loads(r["behavior_json"] or "{}"),
            error=r["error"],
            label=r["label"],
        )

    # ── HistoryStorage ─────────────────────────────────────────────────

    def load_all(self) -> list[HistoryEntry]:
        rows = self._conn.execute(
            "SELECT * FROM scans ORDER BY finished_at DESC"
        ).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def record(self, entry: HistoryEntry) -> None:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                self._conn.execute(
                    """
                    INSERT INTO scans (
                        job_id, source_root, output_root, started_at,
                        finished_at, duration_s, status, repos_scanned,
                        total_findings, by_severity_json, behavior_json,
                        error, label
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(job_id) DO UPDATE SET
                        source_root      = excluded.source_root,
                        output_root      = excluded.output_root,
                        started_at       = excluded.started_at,
                        finished_at      = excluded.finished_at,
                        duration_s       = excluded.duration_s,
                        status           = excluded.status,
                        repos_scanned    = excluded.repos_scanned,
                        total_findings   = excluded.total_findings,
                        by_severity_json = excluded.by_severity_json,
                        behavior_json    = excluded.behavior_json,
                        error            = excluded.error,
                        label            = excluded.label
                    """,
                    (
                        entry.job_id, entry.source_root, entry.output_root,
                        entry.started_at, entry.finished_at, entry.duration_s,
                        entry.status, entry.repos_scanned, entry.total_findings,
                        json.dumps(entry.by_severity),
                        json.dumps(entry.behavior_profile),
                        entry.error, entry.label,
                    ),
                )
                # Enforce the rolling cap.
                count = self._conn.execute(
                    "SELECT COUNT(*) FROM scans"
                ).fetchone()[0]
                if count > self._max:
                    self._conn.execute(
                        """
                        DELETE FROM scans WHERE job_id IN (
                            SELECT job_id FROM scans
                            ORDER BY finished_at ASC
                            LIMIT ?
                        )
                        """,
                        (count - self._max,),
                    )
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def delete(self, job_id: str) -> bool:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM scans WHERE job_id = ?", (job_id,)
            )
            return cur.rowcount > 0

    def delete_with_artifacts(self, job_id: str) -> dict[str, Any]:
        result: dict[str, Any] = {
            "removed_entry": False, "removed_files": [], "errors": [],
        }
        with self._lock:
            row = self._conn.execute(
                "SELECT output_root FROM scans WHERE job_id = ?", (job_id,)
            ).fetchone()
            if row is None:
                return result
            out_root = Path(row["output_root"])
            for cand in (
                out_root / "_logs" / "scan-findings.json",
                out_root / "_logs" / "scan-summary.csv",
                out_root / "_logs" / "library-rollup.csv",
            ):
                if cand.exists():
                    try:
                        cand.unlink()
                        result["removed_files"].append(str(cand))
                    except OSError as e:
                        result["errors"].append(f"{cand}: {e}")
            self._conn.execute("DELETE FROM scans WHERE job_id = ?", (job_id,))
            result["removed_entry"] = True
        return result

    def clear_all(self) -> int:
        with self._lock:
            cur = self._conn.execute("DELETE FROM scans")
            return cur.rowcount

    def describe(self) -> dict[str, Any]:
        return {
            "backend": "sqlite",
            "path": str(self._path),
            "max_entries": self._max,
            "deployment_tier": config_mod.load().deployment_tier,
        }


# Register so config history_backend = "sqlite" resolves to this class.
register_history_backend("sqlite", SqliteHistoryStorage)
