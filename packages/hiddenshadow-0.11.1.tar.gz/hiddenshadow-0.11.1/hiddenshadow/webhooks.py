"""Post a summary of NEW findings to Slack / generic JSON / GitHub PR.

Designed to pair with the `watch` command. Each `WatchDiff` becomes a
single notification with the new finding count, severity breakdown,
and the first N findings inline.

The destination is selected by URL shape:

    https://hooks.slack.com/services/...     -> Slack incoming webhook
    https://api.github.com/repos/.../pulls/<n>/comments  -> GitHub PR
    anything else https://...                -> generic JSON POST

The generic JSON shape is::

    {
      "tool": "hiddenshadow",
      "version": "...",
      "diff": {
        "prior_stamp": "...",
        "current_stamp": "...",
        "new_count": <n>,
        "by_severity": {"critical": ..., "high": ..., ...},
        "findings": [<first 50>]
      }
    }
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass
class NotifyResult:
    status: int
    error: str = ""


def _post_json(url: str, body: dict[str, Any], *,
               headers: dict[str, str] | None = None,
               timeout: float = 10.0) -> NotifyResult:
    data = json.dumps(body).encode("utf-8")
    hdrs = {"Content-Type": "application/json",
            "User-Agent": "hiddenshadow-webhook"}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return NotifyResult(status=resp.status)
    except urllib.error.HTTPError as e:
        return NotifyResult(status=e.code, error=f"HTTP {e.code}: {e.reason}")
    except urllib.error.URLError as e:
        return NotifyResult(status=0, error=f"URL error: {e.reason}")
    except Exception as e:  # pragma: no cover
        return NotifyResult(status=0, error=f"{type(e).__name__}: {e}")


# ── Destination-specific formatters ────────────────────────────────────

def _slack_payload(diff) -> dict[str, Any]:
    """Build a Slack incoming-webhook payload."""
    by_sev = diff.new_by_severity
    sev_text = "  •  ".join(
        f"*{n}* {s}" for s, n in by_sev.items() if n
    ) or "no breakdown"
    blocks: list[dict[str, Any]] = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"HiddenShadow: {len(diff.new_findings)} new finding(s)",
            },
        },
        {
            "type": "section",
            "text": {"type": "mrkdwn",
                     "text": f"Since `{diff.prior_stamp or 'initial run'}`\n{sev_text}"},
        },
    ]
    for f in diff.new_findings[:8]:
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (f"*[{f.get('severity', '?')}]* "
                         f"{f.get('title', '(no title)')}\n"
                         f"`{f.get('location', '')}` — "
                         f"`{f.get('method', '')}`"),
            },
        })
    if len(diff.new_findings) > 8:
        blocks.append({
            "type": "context",
            "elements": [
                {"type": "mrkdwn",
                 "text": f"... and {len(diff.new_findings) - 8} more"},
            ],
        })
    return {"blocks": blocks}


def _github_comment_body(diff) -> str:
    by_sev = diff.new_by_severity
    lines: list[str] = [
        f"### HiddenShadow: {len(diff.new_findings)} new finding(s)",
        f"_Since {diff.prior_stamp or 'initial run'}_",
        "",
        "| Severity | Count |",
        "|---|---|",
    ]
    for s in ("critical", "high", "medium", "low", "info"):
        if by_sev.get(s):
            lines.append(f"| **{s}** | {by_sev[s]} |")
    lines.append("")
    lines.append("| Severity | Title | Location | Rule |")
    lines.append("|---|---|---|---|")
    for f in diff.new_findings[:25]:
        loc = (f.get("location") or "").replace("|", "\\|")
        title = (f.get("title") or "").replace("|", "\\|")
        lines.append(
            f"| {f.get('severity', '?')} | {title} | `{loc}` "
            f"| `{f.get('method', '')}` |"
        )
    if len(diff.new_findings) > 25:
        lines.append("")
        lines.append(f"_... and {len(diff.new_findings) - 25} more_")
    return "\n".join(lines)


def _generic_payload(diff, tool_version: str) -> dict[str, Any]:
    by_sev = diff.new_by_severity
    return {
        "tool": "hiddenshadow",
        "version": tool_version,
        "diff": {
            "prior_stamp": diff.prior_stamp,
            "current_stamp": diff.current_stamp,
            "new_count": len(diff.new_findings),
            "by_severity": by_sev,
            "findings": diff.new_findings[:50],
        },
    }


# ── Public API ─────────────────────────────────────────────────────────

def notify(diff, url: str, *, tool_version: str = "",
           github_token: str | None = None) -> NotifyResult:
    """Send a NEW-findings notification to ``url``.

    The destination format is inferred from the URL. GitHub PR comments
    additionally require a token (``github_token=`` or env var
    ``GITHUB_TOKEN`` / ``GH_TOKEN``).
    """
    if not diff.has_new:
        return NotifyResult(status=204, error="no new findings; skipped")

    low = url.lower()
    if "hooks.slack.com" in low:
        return _post_json(url, _slack_payload(diff))
    if "api.github.com" in low and "/pulls/" in low and "/comments" in low:
        tok = (github_token or os.environ.get("GITHUB_TOKEN")
               or os.environ.get("GH_TOKEN"))
        if not tok:
            return NotifyResult(
                status=0,
                error="GitHub PR comment requires GITHUB_TOKEN / GH_TOKEN",
            )
        body = {"body": _github_comment_body(diff)}
        return _post_json(url, body, headers={
            "Authorization": f"Bearer {tok}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        })
    return _post_json(url, _generic_payload(diff, tool_version))
