"""GitHub Actions workflow security rules.

Operates on a parsed workflow YAML tree (using the YAML subset parser
from ``containers.compose``). Each rule consumes the parsed structure
and emits a :class:`hiddenshadow.findings.Finding` when an insecure
pattern is detected.

Rule taxonomy
-------------
Rule IDs are prefixed ``gha-`` and grouped by attack class:

  gha-action-not-pinned          mutable @vN action ref
  gha-action-pin-to-tag          @vX.Y.Z (concrete tag, not SHA)
  gha-pr-target-checkout-head    pull_request_target + checkout PR head
  gha-no-permissions             top-level / job-level permissions missing
  gha-permissions-write-all      permissions: write-all
  gha-script-injection           ${{ }} of attacker-controlled context in run:
  gha-secrets-to-third-party     job secrets passed to a non-local action
  gha-self-hosted-public         self-hosted runner on a public-shaped repo
  gha-no-timeout                 job without timeout-minutes
  gha-workflow-run-untrusted     workflow_run on an arbitrary other workflow
  gha-run-curl-pipe-sh           curl | sh inside a run block
  gha-cache-with-secrets         actions/cache + secret-shaped env value
  gha-no-concurrency-on-deploy   deploy-shaped job without concurrency group
  gha-debug-mode                 ACTIONS_STEP_DEBUG / RUNNER_DEBUG = 1

Each rule returns either ``None`` or a :class:`GhaRuleHit`. The caller
in :mod:`scanner` wraps the hits into findings.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..containers.compose import parse_yaml, _get, _value, _items, _to_list, _Node


# ── Rule result type ───────────────────────────────────────────────────

@dataclass
class GhaRuleHit:
    rule_id: str
    severity: str          # critical | high | medium | low | info
    title: str
    detail: str
    recommendation: str
    line: int = 0          # line in the source file (1-based)


# ── Helpers on the parsed tree ──────────────────────────────────────────

def _jobs(workflow: _Node) -> list[tuple[str, _Node]]:
    """Return [(job_name, job_node), ...] from a parsed workflow."""
    jobs = _get(workflow, "jobs")
    if jobs is None or not isinstance(jobs.value, dict):
        return []
    out: list[tuple[str, _Node]] = []
    for name, node in jobs.value.items():
        if isinstance(node, _Node) and isinstance(node.value, dict):
            out.append((str(name), node))
    return out


def _steps(job: _Node) -> list[_Node]:
    """Return the list of step Nodes from a job."""
    steps = _get(job, "steps")
    if steps is None:
        return []
    return [n for n in _items(steps) if isinstance(n, _Node)]


def _on(workflow: _Node) -> list[str]:
    """Return the list of trigger event names for the workflow.

    Handles all three valid forms::

        on: push
        on: [push, pull_request]
        on:
          push:
            branches: [main]
          workflow_run:
            workflows: [CI]
    """
    on = _get(workflow, "on")
    if on is None:
        return []
    v = on.value
    if isinstance(v, str):
        return [v]
    if isinstance(v, list):
        return [str(_value(x)) for x in v
                if isinstance(x, _Node) and _value(x) is not None]
    if isinstance(v, dict):
        return list(v.keys())
    return []


# ── Attacker-controllable expression contexts ─────────────────────────

# These github expression paths are populated from un-trusted user input
# and so any use of them inside a ``run:`` block without sanitisation is
# a script-injection vulnerability.
_ATTACKER_CONTEXTS = re.compile(
    r"\$\{\{\s*"
    r"(github\.event\.(?:pull_request|issue|comment|review|"
    r"discussion|workflow_run)\.[^}]*"
    r"(?:title|body|head_ref|name|email|login|message)|"
    r"github\.head_ref|github\.event\.head_commit\.message|"
    r"github\.event\.commits\.[^}]*\.message|"
    r"github\.event\.pages\.[^}]*\.page_name)"
    r"\s*\}\}"
)

_RUN_CURL_PIPE_SH = re.compile(
    r"\b(curl|wget|fetch|iwr|irm)\b[^|;]{1,300}\|\s*"
    r"(bash|sh|zsh|cmd|powershell|pwsh|python|node)\b",
    re.IGNORECASE,
)

_SECRET_NAME_RE = re.compile(
    r"(?:^|[_\-])(PASSWORD|PASSWD|SECRET|TOKEN|API_KEY|PRIVATE_KEY|"
    r"CREDENTIAL|AUTH|AWS_ACCESS|AWS_SECRET)(?:$|[_\-])",
    re.IGNORECASE,
)

# Sha-1 / sha-256 commit ref pattern. Tags like v1, v1.2 are NOT shas.
_SHA_RE = re.compile(r"^[0-9a-f]{40}$|^[0-9a-f]{64}$")


# ── Per-step action-pinning analysis ────────────────────────────────────

def _check_action_pinning(uses: str, line: int) -> GhaRuleHit | None:
    """Inspect a ``uses: owner/repo@ref`` string."""
    if not uses or "@" not in uses:
        return None
    # Ignore local actions (./.github/actions/foo) — they aren't pinnable.
    if uses.startswith("./") or uses.startswith(".\\"):
        return None
    # Ignore docker:// + composite that don't use refs the same way.
    if uses.startswith("docker://"):
        return None
    repo, _, ref = uses.partition("@")
    if not ref:
        return None
    if _SHA_RE.match(ref):
        return None  # SHA-pinned - good
    # vN form (`@v3`) is a mutable major-version pointer.
    if re.match(r"^v\d+(\.\d+)?$", ref):
        return GhaRuleHit(
            rule_id="gha-action-not-pinned",
            severity="high",
            title=f"Action '{repo}' pinned by mutable major-version ref '{ref}'",
            detail=(
                f"`uses: {uses}` points at a moving major-version tag. "
                f"Many high-impact GitHub Actions supply-chain incidents "
                f"(e.g. tj-actions/changed-files) propagated through "
                f"these floating tags."
            ),
            recommendation=(
                "Pin to a full 40-character commit SHA: "
                f"`uses: {repo}@<sha>`. Dependabot can keep the SHA up to "
                "date with a comment showing the corresponding tag."
            ),
            line=line,
        )
    # Concrete vX.Y.Z tag — still mutable on most repos, but much less risk.
    if re.match(r"^v?\d+\.\d+\.\d+", ref):
        return GhaRuleHit(
            rule_id="gha-action-pin-to-tag",
            severity="low",
            title=f"Action '{repo}' pinned by tag '{ref}', not SHA",
            detail=(
                f"`uses: {uses}` is pinned by tag. Tags are mutable on "
                f"GitHub - a maintainer (or attacker) can re-point a "
                f"published tag at a different commit."
            ),
            recommendation=("Pin to a 40-character commit SHA instead "
                            "of a tag."),
            line=line,
        )
    # Anything else (branch name, "main", etc.) is bad.
    return GhaRuleHit(
        rule_id="gha-action-not-pinned",
        severity="high",
        title=f"Action '{repo}' pinned by branch / un-versioned ref '{ref}'",
        detail=(f"`uses: {uses}` resolves whatever commit '{ref}' points "
                f"at the moment the workflow runs."),
        recommendation="Pin to a 40-character commit SHA.",
        line=line,
    )


# ── Workflow-level rule: pull_request_target dangers ──────────────────

def _check_pr_target(workflow: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    events = _on(workflow)
    if "pull_request_target" not in events:
        return out
    # Inspect every step for actions/checkout that pulls the PR head.
    for _, job in _jobs(workflow):
        for st in _steps(job):
            uses = _value(_get(st, "uses")) or ""
            if not isinstance(uses, str):
                continue
            if not uses.startswith("actions/checkout"):
                continue
            with_ = _get(st, "with")
            ref = ""
            if with_ and isinstance(with_.value, dict):
                ref_node = with_.value.get("ref")
                if isinstance(ref_node, _Node):
                    ref = str(_value(ref_node) or "")
            if (
                "pull_request.head" in ref
                or "github.event.pull_request.head" in ref
                or "head.sha" in ref
                or "head_ref" in ref
            ):
                out.append(GhaRuleHit(
                    rule_id="gha-pr-target-checkout-head",
                    severity="critical",
                    title=("pull_request_target combined with checkout of "
                           "PR head"),
                    detail=(
                        "Workflow triggers on pull_request_target (which "
                        "runs with the repository's secrets) AND checks "
                        "out the PR head commit. Any attacker who opens a "
                        "PR can inject code that runs with full repo "
                        "credentials."
                    ),
                    recommendation=(
                        "Either drop pull_request_target (use plain "
                        "pull_request), or check out the base ref / a "
                        "trusted commit; never combine the two."
                    ),
                    line=st.line,
                ))
    return out


# ── Workflow-level rule: missing permissions ──────────────────────────

def _check_permissions(workflow: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    top_perms = _get(workflow, "permissions")
    if top_perms is None:
        # Per-job permissions can compensate. Only fire if NO job sets it.
        any_job_perms = False
        for _, job in _jobs(workflow):
            if _get(job, "permissions") is not None:
                any_job_perms = True
                break
        if not any_job_perms:
            out.append(GhaRuleHit(
                rule_id="gha-no-permissions",
                severity="medium",
                title="Workflow has no `permissions:` declaration",
                detail=("Neither the workflow nor any job declares a "
                        "`permissions:` block. The default is "
                        "read-and-write on `contents:`, which means a "
                        "compromised step can push to the repo."),
                recommendation=(
                    "Add a top-level `permissions: { contents: read }` and "
                    "broaden per-job where needed (e.g. "
                    "contents: write only on the release job)."
                ),
                line=workflow.line,
            ))
    elif isinstance(top_perms.value, str):
        if top_perms.value in ("write-all", "write"):
            out.append(GhaRuleHit(
                rule_id="gha-permissions-write-all",
                severity="high",
                title=f"Workflow grants permissions: {top_perms.value}",
                detail=(f"Top-level permissions are set to "
                        f"'{top_perms.value}', granting every API "
                        f"scope to every step."),
                recommendation=(
                    "Replace with a least-privilege map: declare each "
                    "scope (contents, issues, packages, ...) and set the "
                    "minimum (read/write/none) the workflow needs."
                ),
                line=top_perms.line,
            ))
    return out


# ── Step-level rules over run blocks ──────────────────────────────────

def _check_run_step(step: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    run_node = _get(step, "run")
    if run_node is None:
        return out
    run = _value(run_node) or ""
    if not isinstance(run, str):
        return out
    # 1. Script injection: ${{ <attacker context> }} inside run:
    m = _ATTACKER_CONTEXTS.search(run)
    if m:
        out.append(GhaRuleHit(
            rule_id="gha-script-injection",
            severity="critical",
            title="run: interpolates attacker-controllable context",
            detail=(
                f"The run block contains `{m.group(0)}`. This GitHub "
                f"expression is populated from attacker-controllable PR "
                f"data and is substituted into the shell before "
                f"execution, allowing arbitrary command injection."
            ),
            recommendation=(
                "Don't inline attacker-controlled context into run:. "
                "Read it via an env: var on the step, then reference "
                "$VAR inside the shell - that keeps the value in the "
                "process environment instead of the shell script."
            ),
            line=run_node.line,
        ))
    # 2. curl | sh
    if _RUN_CURL_PIPE_SH.search(run):
        out.append(GhaRuleHit(
            rule_id="gha-run-curl-pipe-sh",
            severity="critical",
            title="run: pipes a network fetch directly into a shell",
            detail=("Pattern 'curl ... | sh' inside a step. Whatever the "
                    "URL returns runs with the workflow's permissions and "
                    "secrets."),
            recommendation=("Download the script, verify its hash, then "
                            "execute. Better: vendor it into the repo."),
            line=run_node.line,
        ))
    return out


# ── Workflow-level rule: third-party action with secret-bearing env ──

def _check_secrets_to_third_party(workflow: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    for _, job in _jobs(workflow):
        for st in _steps(job):
            uses = _value(_get(st, "uses")) or ""
            if not isinstance(uses, str) or "@" not in uses:
                continue
            # Trust first-party (actions/*, github/*) and local actions.
            if (uses.startswith("./") or uses.startswith("actions/")
                    or uses.startswith("github/")):
                continue
            # Check `env:` and `with:` for secret-shaped keys.
            for parent_key in ("env", "with"):
                parent = _get(st, parent_key)
                if parent is None or not isinstance(parent.value, dict):
                    continue
                for k, vnode in parent.value.items():
                    if not _SECRET_NAME_RE.search(str(k)):
                        continue
                    val = _value(vnode) if isinstance(vnode, _Node) else vnode
                    val_str = str(val) if val is not None else ""
                    if "secrets." in val_str or "${{ secrets" in val_str:
                        out.append(GhaRuleHit(
                            rule_id="gha-secrets-to-third-party",
                            severity="high",
                            title=("Repository secret passed to "
                                   "third-party action"),
                            detail=(
                                f"Step uses `{uses}` (a third-party "
                                f"action) and passes secret `{k}` via "
                                f"`{parent_key}:`. If that action is "
                                f"ever compromised your secret leaks."
                            ),
                            recommendation=(
                                "Pin the action by 40-character SHA, audit "
                                "its source, and scope the passed secret "
                                "to the minimum (e.g. use a token with "
                                "only the required GitHub scopes)."
                            ),
                            line=st.line,
                        ))
                        break  # one finding per step is enough
    return out


# ── Workflow-level rule: missing timeout ──────────────────────────────

def _check_timeouts(workflow: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    for name, job in _jobs(workflow):
        if _get(job, "timeout-minutes") is None:
            out.append(GhaRuleHit(
                rule_id="gha-no-timeout",
                severity="low",
                title=f"Job '{name}' has no timeout-minutes",
                detail=("A misbehaving or attacker-controlled step can "
                        "exhaust runner minutes."),
                recommendation=("Add `timeout-minutes: <n>` (e.g. 30) at "
                                "the job level."),
                line=job.line,
            ))
    return out


# ── Workflow-level rule: workflow_run on untrusted ────────────────────

def _check_workflow_run(workflow: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    events = _on(workflow)
    if "workflow_run" not in events:
        return out
    on = _get(workflow, "on")
    wr = _get(on, "workflow_run") if on else None
    if wr is None or not isinstance(wr.value, dict):
        return out
    out.append(GhaRuleHit(
        rule_id="gha-workflow-run-untrusted",
        severity="medium",
        title="workflow_run trigger - ensure target workflow is trusted",
        detail=("workflow_run runs in the context of the default branch "
                "(with secrets) but is triggered by another workflow's "
                "completion. If the source workflow can be triggered by "
                "an attacker the secrets are accessible to them."),
        recommendation=(
            "Restrict the source workflows listed in `workflows:`, and "
            "validate that the triggering workflow's payload "
            "(`github.event.workflow_run.head_branch`) matches a trusted "
            "branch before using secrets."
        ),
        line=wr.line,
    ))
    return out


# ── Workflow-level rule: self-hosted runners ──────────────────────────

def _check_self_hosted(workflow: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    for name, job in _jobs(workflow):
        runs_on = _get(job, "runs-on")
        if runs_on is None:
            continue
        values = []
        v = runs_on.value
        if isinstance(v, str):
            values = [v]
        elif isinstance(v, list):
            values = [str(_value(x)) for x in v if isinstance(x, _Node)]
        if any(("self-hosted" in str(x).lower()) for x in values):
            out.append(GhaRuleHit(
                rule_id="gha-self-hosted-public",
                severity="medium",
                title=f"Job '{name}' uses a self-hosted runner",
                detail=("Self-hosted runners on a public repository will "
                        "execute arbitrary code from any PR. Even on a "
                        "private repo, runners must be ephemeral and "
                        "network-isolated."),
                recommendation=(
                    "Use ephemeral self-hosted runners (e.g. via "
                    "actions-runner-controller); restrict job triggers "
                    "to trusted events; isolate runners from any "
                    "production network."
                ),
                line=runs_on.line,
            ))
    return out


# ── Workflow-level rule: deploy without concurrency lock ──────────────

_DEPLOY_HINT_RE = re.compile(r"deploy|publish|release|prod", re.IGNORECASE)


def _check_concurrency(workflow: _Node) -> list[GhaRuleHit]:
    name = _value(_get(workflow, "name")) or ""
    top_conc = _get(workflow, "concurrency")
    for jname, job in _jobs(workflow):
        if not (_DEPLOY_HINT_RE.search(jname or "")
                or _DEPLOY_HINT_RE.search(str(name))):
            continue
        if top_conc is not None or _get(job, "concurrency") is not None:
            continue
        return [GhaRuleHit(
            rule_id="gha-no-concurrency-on-deploy",
            severity="low",
            title=(f"Deploy-shaped job '{jname}' has no concurrency lock"),
            detail=("A second push during an in-flight deploy can race the "
                    "first one, producing an inconsistent prod state."),
            recommendation=(
                "Add `concurrency: { group: deploy-${{ github.ref }}, "
                "cancel-in-progress: false }`."
            ),
            line=job.line,
        )]
    return []


# ── Workflow-level rule: debug mode ───────────────────────────────────

def _check_debug_env(workflow: _Node) -> list[GhaRuleHit]:
    out: list[GhaRuleHit] = []
    env = _get(workflow, "env")
    if env and isinstance(env.value, dict):
        for k in ("ACTIONS_STEP_DEBUG", "ACTIONS_RUNNER_DEBUG",
                  "RUNNER_DEBUG"):
            if k in env.value:
                node = env.value[k]
                val = _value(node) if isinstance(node, _Node) else node
                if str(val).lower() in ("true", "1"):
                    out.append(GhaRuleHit(
                        rule_id="gha-debug-mode",
                        severity="medium",
                        title=f"{k} is enabled at workflow level",
                        detail=(f"{k} is true, which logs sensitive "
                                f"runner internals (including secret "
                                f"masking diagnostics)."),
                        recommendation=("Disable debug logging in the "
                                        "checked-in workflow; if you need "
                                        "it for one run, use the secrets "
                                        "panel instead."),
                        line=node.line if isinstance(node, _Node) else 0,
                    ))
    return out


# ── Top-level entrypoint ───────────────────────────────────────────────

def analyze_workflow(text: str) -> list[GhaRuleHit]:
    """Apply every rule to a parsed workflow text."""
    root = parse_yaml(text)
    hits: list[GhaRuleHit] = []

    # Workflow-level
    hits.extend(_check_permissions(root))
    hits.extend(_check_pr_target(root))
    hits.extend(_check_secrets_to_third_party(root))
    hits.extend(_check_timeouts(root))
    hits.extend(_check_workflow_run(root))
    hits.extend(_check_self_hosted(root))
    hits.extend(_check_concurrency(root))
    hits.extend(_check_debug_env(root))

    # Step-level: action pinning + run inspection
    for _, job in _jobs(root):
        for st in _steps(job):
            uses = _value(_get(st, "uses"))
            if isinstance(uses, str):
                hit = _check_action_pinning(uses, st.line)
                if hit is not None:
                    hits.append(hit)
            hits.extend(_check_run_step(st))

    return hits


def find_workflow_files(root: Path) -> list[Path]:
    """Return the list of .github/workflows/*.yml and .yaml files."""
    out: list[Path] = []
    wf_dir = root / ".github" / "workflows"
    if not wf_dir.is_dir():
        return out
    for f in wf_dir.iterdir():
        if f.is_file() and f.suffix.lower() in (".yml", ".yaml"):
            out.append(f)
    return out
