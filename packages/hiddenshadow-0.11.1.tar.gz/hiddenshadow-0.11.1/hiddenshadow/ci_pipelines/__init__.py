"""CI/CD pipeline security scanner.

Walks a repo for CI/CD configuration files and applies platform-specific
security rules. Supported platforms:

* GitHub Actions       (``.github/workflows/*.yml``)
* GitLab CI            (``.gitlab-ci.yml``)
* Azure Pipelines      (``azure-pipelines.yml`` and friends)
* Jenkins              (``Jenkinsfile`` / ``*.jenkinsfile``)
* CircleCI             (``.circleci/config.yml``)

Findings carry ``category="cicd"`` and ``method="cicd:<platform>:<rule_id>"``.
"""
from __future__ import annotations

from .scanner import scan_path, scan_path_as_findings, CiFinding

__all__ = ["scan_path", "scan_path_as_findings", "CiFinding"]
