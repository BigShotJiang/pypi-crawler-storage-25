"""GitLab CI, Azure Pipelines, Jenkins, CircleCI rules.

Smaller per-platform rulesets than GitHub Actions (which gets the
deepest coverage given its dominant market share and attack history).
Each section returns a list of :class:`CiFinding` directly.
"""
from __future__ import annotations

import re
from pathlib import Path

from ..containers.compose import parse_yaml, _get, _value, _items, _to_list, _Node
from .scanner import CiFinding


_CURL_PIPE = re.compile(
    r"\b(curl|wget|fetch|iwr|irm)\b[^|;]{1,300}\|\s*"
    r"(bash|sh|zsh|cmd|powershell|pwsh|python|node)\b",
    re.IGNORECASE,
)
_SECRET_NAME_RE = re.compile(
    r"(?:^|[_\-])(PASSWORD|PASSWD|SECRET|TOKEN|API_KEY|PRIVATE_KEY|"
    r"CREDENTIAL|AUTH)(?:$|[_\-])",
    re.IGNORECASE,
)


def _f(repo: str, platform: str, rid: str, sev: str, title: str,
       detail: str, rec: str, file: str, line: int = 0) -> CiFinding:
    return CiFinding(repo=repo, platform=platform, rule_id=rid,
                     severity=sev, title=title, detail=detail,
                     recommendation=rec, file=file, line=line)


# ─── GitLab CI ─────────────────────────────────────────────────────────

def _scan_gitlab(path: Path, root: Path, repo: str) -> list[CiFinding]:
    out: list[CiFinding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    doc = parse_yaml(text)
    if not isinstance(doc.value, dict):
        return out

    # Top-level image: latest
    top_image = _value(_get(doc, "image"))
    if isinstance(top_image, str) and (top_image.endswith(":latest")
                                       or ":" not in top_image):
        out.append(_f(repo, "gitlab-ci", "gl-image-latest", "medium",
                      f"Pipeline image uses ':latest' or no tag ({top_image})",
                      "Top-level image is a moving reference.",
                      "Pin image to a specific tag and digest.",
                      rel, _get(doc, "image").line))

    # Each job (anything that's a dict and has 'script', 'image', etc.)
    for name, node in doc.value.items():
        if not isinstance(node, _Node) or not isinstance(node.value, dict):
            continue
        # Reserved keys are not jobs.
        if name in ("stages", "variables", "include", "default", "image",
                    "before_script", "after_script", "workflow", "cache",
                    "services"):
            continue
        # services: docker:dind  → privileged DinD warning
        svcs = _to_list(_get(node, "services"))
        for s in svcs:
            if "docker" in s.lower() and ("dind" in s.lower()
                                          or s.endswith(":dind")):
                out.append(_f(repo, "gitlab-ci", "gl-privileged-dind", "high",
                              f"Job '{name}' uses Docker-in-Docker service",
                              "DinD runners typically run in privileged "
                              "mode, which is equivalent to root on the "
                              "host.",
                              "Use Kaniko or BuildKit's rootless mode "
                              "instead of docker:dind.",
                              rel, node.line))
        # script: with curl | sh
        for key in ("script", "before_script", "after_script"):
            sk = _get(node, key)
            if sk is None:
                continue
            for item in _items(sk):
                v = _value(item) if isinstance(item, _Node) else item
                if isinstance(v, str) and _CURL_PIPE.search(v):
                    out.append(_f(repo, "gitlab-ci", "gl-curl-pipe-sh",
                                  "critical",
                                  f"Job '{name}' pipes network output to shell",
                                  f"`{key}` contains a curl|sh pattern.",
                                  "Download, verify, then execute.",
                                  rel, item.line if isinstance(item, _Node)
                                  else node.line))
        # variables: secret-shaped literal
        vars_node = _get(node, "variables")
        if vars_node and isinstance(vars_node.value, dict):
            for k, vnode in vars_node.value.items():
                if not _SECRET_NAME_RE.search(str(k)):
                    continue
                v = _value(vnode) if isinstance(vnode, _Node) else vnode
                vs = str(v) if v is not None else ""
                if vs and not vs.startswith("$") and not vs.startswith("${"):
                    out.append(_f(repo, "gitlab-ci", "gl-secret-literal",
                                  "high",
                                  f"Job '{name}' has literal secret-shaped variable",
                                  f"variables.{k} is set to a literal value. "
                                  "Use CI/CD masked variables instead.",
                                  "Move the value to CI/CD settings → "
                                  "Variables (masked, protected).",
                                  rel, vnode.line if isinstance(vnode, _Node)
                                  else node.line))

    # include: from un-pinned external
    inc = _get(doc, "include")
    if inc is not None:
        for entry in _items(inc):
            ev = _value(entry) if isinstance(entry, _Node) else entry
            if isinstance(ev, str) and ev.startswith(("http://", "https://")):
                if "@" not in ev and "?ref=" not in ev:
                    out.append(_f(repo, "gitlab-ci", "gl-include-unpinned",
                                  "medium",
                                  "include: from a remote URL without a ref",
                                  f"include: {ev}", "Append ?ref=<sha> or "
                                  "vendor the file into the repo.", rel,
                                  entry.line if isinstance(entry, _Node) else 0))
    return out


# ─── Azure Pipelines ───────────────────────────────────────────────────

def _scan_azure(path: Path, root: Path, repo: str) -> list[CiFinding]:
    out: list[CiFinding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    doc = parse_yaml(text)
    if not isinstance(doc.value, dict):
        return out

    # Resources / repositories: missing ref → mutable
    res = _get(doc, "resources")
    if res and isinstance(res.value, dict):
        reps = res.value.get("repositories")
        if isinstance(reps, _Node):
            for item in _items(reps):
                if isinstance(item, _Node) and isinstance(item.value, dict):
                    if "ref" not in item.value:
                        repo_name = _value(item.value.get("repository")) or "?"
                        out.append(_f(repo, "azure-pipelines",
                                      "az-ext-template-no-ref", "medium",
                                      f"External resource '{repo_name}' has no ref",
                                      "External template/repository without "
                                      "a ref defaults to the default branch.",
                                      "Add `ref: refs/tags/<sha-or-tag>`.",
                                      rel, item.line))

    # Walk steps recursively under stages → jobs → steps.
    def walk_steps(parent: _Node, container: str = "") -> None:
        steps = _get(parent, "steps")
        if steps is None:
            return
        for s in _items(steps):
            if not isinstance(s, _Node) or not isinstance(s.value, dict):
                continue
            # task: VersionedTask@1.* → ok; @* or no version → mutable
            task = _value(_get(s, "task")) or ""
            if isinstance(task, str) and "@" in task:
                _, _, ver = task.partition("@")
                if ver in ("", "*") or ver.endswith(".*"):
                    out.append(_f(repo, "azure-pipelines",
                                  "az-task-mutable-version", "medium",
                                  f"Task version is mutable: {task}",
                                  f"task: {task} uses a wildcard or empty version.",
                                  "Pin task to a specific major version, "
                                  f"e.g. {task.split('@')[0]}@1.",
                                  rel, s.line))
            # script: with curl|sh
            for k in ("script", "bash", "powershell", "pwsh"):
                sk = _value(_get(s, k))
                if isinstance(sk, str) and _CURL_PIPE.search(sk):
                    out.append(_f(repo, "azure-pipelines",
                                  "az-curl-pipe-sh", "critical",
                                  f"Step pipes network output to shell ({k})",
                                  f"`{k}:` contains a curl|sh pattern.",
                                  "Download, verify, then execute.",
                                  rel, s.line))

    walk_steps(doc)
    # stages → jobs → steps
    stages = _get(doc, "stages")
    if stages:
        for st in _items(stages):
            if not isinstance(st, _Node):
                continue
            walk_steps(st)
            jobs = _get(st, "jobs")
            if jobs:
                for j in _items(jobs):
                    if isinstance(j, _Node):
                        walk_steps(j)
    jobs = _get(doc, "jobs")
    if jobs:
        for j in _items(jobs):
            if isinstance(j, _Node):
                walk_steps(j)

    return out


# ─── Jenkins ───────────────────────────────────────────────────────────

# Jenkins isn't YAML, so we use focused regex rules over the Groovy
# source. These intentionally err on the side of high precision so we
# don't get drowned in false positives on shared library code.

_JENKINS_SH_INTERPOLATED = re.compile(
    r"""(?x)
    \bsh\b\s*[\(]?\s*               # sh ( or sh "
    ["']                            # opening quote
    [^"'\n]*?                       # anything (lazy)
    \$\{[A-Za-z_][\w.]*\}           # ${interp} or ${env.X}
    """
)
_JENKINS_WITH_CREDENTIALS = re.compile(
    r"\bwithCredentials\b\s*\(\s*\[(?P<body>[^\]]+)\]"
)
_JENKINS_UNSTASH = re.compile(r"\bunstash\b\s*['\"]([^'\"]+)['\"]")


def _scan_jenkins(path: Path, root: Path, repo: str) -> list[CiFinding]:
    out: list[CiFinding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    lines = text.split("\n")

    def _line_of(pos: int) -> int:
        return text.count("\n", 0, pos) + 1

    for m in _JENKINS_SH_INTERPOLATED.finditer(text):
        out.append(_f(repo, "jenkins", "jk-sh-interpolated", "high",
                      "sh step interpolates Groovy variable into shell",
                      f"Match: {m.group(0)[:80]}. "
                      "If the variable is attacker-controlled (PR title, "
                      "branch, etc.) this is command injection.",
                      "Use the array form: `sh script: ['./run.sh', "
                      "param]` or pass values via env: to avoid shell "
                      "interpolation.",
                      rel, _line_of(m.start())))

    for m in _CURL_PIPE.finditer(text):
        out.append(_f(repo, "jenkins", "jk-curl-pipe-sh", "critical",
                      "Pipeline pipes network output directly to shell",
                      f"Match: {m.group(0)[:80]}",
                      "Download, verify, then execute.",
                      rel, _line_of(m.start())))

    for m in _JENKINS_UNSTASH.finditer(text):
        ref = m.group(1)
        out.append(_f(repo, "jenkins", "jk-unstash", "info",
                      f"unstash '{ref}'",
                      ("unstash reuses artifacts from a previous stage; "
                       "make sure that stage runs in a trusted context."),
                      "Audit the producing stage to confirm only trusted "
                      "code wrote the stash.",
                      rel, _line_of(m.start())))

    # withCredentials block — flag unscoped GLOBAL credential bindings.
    for m in _JENKINS_WITH_CREDENTIALS.finditer(text):
        body = m.group("body")
        if "string(credentialsId:" in body and "variable:" not in body:
            out.append(_f(repo, "jenkins", "jk-creds-unbound", "low",
                          "withCredentials block missing 'variable:' binding",
                          f"Match: {body[:80]}", "Bind the secret to a "
                          "scoped variable name and only use $VAR inside "
                          "the block.", rel, _line_of(m.start())))
    return out


# ─── CircleCI ──────────────────────────────────────────────────────────

def _scan_circle(path: Path, root: Path, repo: str) -> list[CiFinding]:
    out: list[CiFinding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    doc = parse_yaml(text)
    if not isinstance(doc.value, dict):
        return out

    # orbs: namespace/orb@volatile or @dev: → flag
    orbs = _get(doc, "orbs")
    if orbs and isinstance(orbs.value, dict):
        for alias, vnode in orbs.value.items():
            v = _value(vnode) if isinstance(vnode, _Node) else vnode
            if not isinstance(v, str):
                continue
            if "@volatile" in v or "@dev:" in v or "@" not in v:
                out.append(_f(repo, "circleci", "cc-orb-mutable", "high",
                              f"Orb '{alias}' uses mutable / no version: {v}",
                              "Volatile or dev orbs change without notice "
                              "and have been abused in past supply-chain "
                              "incidents.",
                              "Pin orb to a SemVer release tag.",
                              rel, vnode.line if isinstance(vnode, _Node)
                              else 0))

    # jobs: docker image latest
    jobs = _get(doc, "jobs")
    if jobs and isinstance(jobs.value, dict):
        for jname, jnode in jobs.value.items():
            if not isinstance(jnode, _Node):
                continue
            docker = _get(jnode, "docker")
            if docker is None:
                continue
            for item in _items(docker):
                if not isinstance(item, _Node):
                    continue
                img = _value(_get(item, "image")) if isinstance(item.value,
                                                                 dict) else None
                if isinstance(img, str) and (img.endswith(":latest")
                                             or ":" not in img):
                    out.append(_f(repo, "circleci", "cc-image-latest", "medium",
                                  f"Job '{jname}' docker image is :latest / untagged",
                                  f"image: {img}", "Pin to a tag + digest.",
                                  rel, item.line))
            # steps: run with curl|sh
            steps = _get(jnode, "steps")
            if steps:
                for st in _items(steps):
                    if not isinstance(st, _Node):
                        continue
                    run = _get(st, "run") if isinstance(st.value, dict) else None
                    if run is None:
                        continue
                    rv = _value(run)
                    if isinstance(rv, dict):
                        rv = rv.get("command") or ""
                    if isinstance(rv, str) and _CURL_PIPE.search(rv):
                        out.append(_f(repo, "circleci", "cc-curl-pipe-sh",
                                      "critical",
                                      f"Job '{jname}' pipes network to shell",
                                      f"Match in run command.",
                                      "Download, verify, then execute.",
                                      rel, st.line))
    return out


# ─── Discovery + dispatch ──────────────────────────────────────────────

def scan_other_platforms(root: Path, repo: str) -> list[CiFinding]:
    out: list[CiFinding] = []
    import os
    SKIP = {".git", "node_modules", "__pycache__"}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP]
        for fn in filenames:
            full = Path(dirpath) / fn
            lower = fn.lower()
            if lower == ".gitlab-ci.yml":
                out.extend(_scan_gitlab(full, root, repo))
            elif lower in ("azure-pipelines.yml", "azure-pipelines.yaml") \
                    or lower.endswith(".azure-pipelines.yml"):
                out.extend(_scan_azure(full, root, repo))
            elif lower == "jenkinsfile" or lower.endswith(".jenkinsfile"):
                out.extend(_scan_jenkins(full, root, repo))
            # CircleCI: only the canonical location.
        # CircleCI config sits at <root>/.circleci/config.yml
    cc = root / ".circleci" / "config.yml"
    if cc.is_file():
        out.extend(_scan_circle(cc, root, repo))
    cc_yaml = root / ".circleci" / "config.yaml"
    if cc_yaml.is_file():
        out.extend(_scan_circle(cc_yaml, root, repo))
    return out
