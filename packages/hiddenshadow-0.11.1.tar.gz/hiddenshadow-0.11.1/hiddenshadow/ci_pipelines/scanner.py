"""CI/CD pipeline scanner orchestrator.

Walks the repo for known pipeline-config locations and dispatches each
file to the platform-specific analyzer. Findings are returned as both a
rich :class:`CiFinding` (for the dedicated ``cipipeline-findings.json``
report) and as plain :class:`hiddenshadow.findings.Finding` objects (so
they can flow into the main scan stream when invoked via
``scan --detect-ci``).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ..findings import Finding
from . import github_actions as gha


@dataclass
class CiFinding:
    repo: str
    platform: str            # 'github-actions' | 'gitlab' | 'azure' | ...
    rule_id: str
    severity: str
    title: str
    detail: str
    recommendation: str
    file: str
    line: int

    def to_finding(self) -> Finding:
        return Finding(
            repo=self.repo,
            severity=self.severity,
            category="cicd",
            title=f"{self.platform}: {self.title}",
            location=f"{self.file}:{self.line}",
            detail=self.detail,
            recommendation=self.recommendation,
            method=f"cicd:{self.platform}:{self.rule_id}",
        )


def scan_path(root: Path, repo_name: str = "(local)") -> list[CiFinding]:
    """Walk ``root`` for CI/CD config and apply platform rules."""
    out: list[CiFinding] = []

    # GitHub Actions
    for wf in gha.find_workflow_files(root):
        try:
            text = wf.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rel = wf.relative_to(root).as_posix()
        for hit in gha.analyze_workflow(text):
            out.append(CiFinding(
                repo=repo_name,
                platform="github-actions",
                rule_id=hit.rule_id,
                severity=hit.severity,
                title=hit.title,
                detail=hit.detail,
                recommendation=hit.recommendation,
                file=rel,
                line=hit.line,
            ))

    # GitLab / Azure / Jenkins / CircleCI rules will be appended here
    # by their respective modules in the next commit.
    from . import other_platforms as op
    out.extend(op.scan_other_platforms(root, repo_name))

    return out


def scan_path_as_findings(root: Path, repo_name: str = "(local)"
                          ) -> list[Finding]:
    return [c.to_finding() for c in scan_path(root, repo_name)]
