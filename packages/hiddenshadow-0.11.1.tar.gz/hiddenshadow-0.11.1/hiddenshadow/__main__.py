"""Entry point: python -m hiddenshadow ..."""
from .cli import main

if __name__ == "__main__":
    main()
