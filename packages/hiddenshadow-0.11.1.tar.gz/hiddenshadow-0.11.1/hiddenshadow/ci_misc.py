"""Misc CI/CD-adjacent rules.

Covers smaller-but-real attack surfaces that don't justify their own
package:

* ``.pre-commit-config.yaml``  - unpinned ``rev:`` on third-party hooks
* ``CODEOWNERS``               - missing default rule / blanket owner
* ``renovate.json``            - automerge enabled on major bumps
* ``.github/dependabot.yml``   - automerge on majors (community action pattern)
* ``.env*`` files              - committed runtime env, not just .env.example
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .findings import Finding
from .containers.compose import parse_yaml, _get, _value, _items, _Node


SKIP_DIRS = {".git", "node_modules", "__pycache__", ".terraform"}


def _finding(repo: str, rid: str, sev: str, title: str, detail: str,
             rec: str, file: str, line: int = 0) -> Finding:
    return Finding(
        repo=repo, severity=sev, category="cicd",
        title=title, location=f"{file}:{line}" if line else file,
        detail=detail, recommendation=rec,
        method=f"cicd:misc:{rid}",
    )


# ── pre-commit ────────────────────────────────────────────────────────

def _check_precommit(path: Path, root: Path, repo: str) -> list[Finding]:
    out: list[Finding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    doc = parse_yaml(text)
    repos = _get(doc, "repos")
    if repos is None:
        return out
    for entry in _items(repos):
        if not isinstance(entry, _Node) or not isinstance(entry.value, dict):
            continue
        repo_url = _value(_get(entry, "repo")) or ""
        rev = _value(_get(entry, "rev")) or ""
        if not isinstance(repo_url, str) or not isinstance(rev, str):
            continue
        # Local / meta repos have no rev expectation.
        if repo_url in ("local", "meta"):
            continue
        if not rev:
            out.append(_finding(repo, "precommit-no-rev", "high",
                                f"pre-commit hook from {repo_url} has no rev",
                                "Without a rev, pre-commit pulls the "
                                "default branch every install.",
                                "Pin rev to a tag or commit SHA.",
                                rel, entry.line))
            continue
        # Branch names look like words; tags / SHAs are versioned.
        if rev in ("main", "master", "HEAD", "trunk"):
            out.append(_finding(repo, "precommit-rev-branch", "high",
                                f"pre-commit hook rev is a branch ('{rev}')",
                                "Branches move; this resolves to whatever "
                                "the upstream maintainer last pushed.",
                                "Pin rev to a SHA or release tag.",
                                rel, entry.line))
    return out


# ── CODEOWNERS ────────────────────────────────────────────────────────

def _check_codeowners(path: Path, root: Path, repo: str) -> list[Finding]:
    out: list[Finding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    lines = [line.strip() for line in text.split("\n")]
    # Strip comments / blanks.
    rules = [line for line in lines
             if line and not line.startswith("#")]
    if not rules:
        out.append(_finding(repo, "codeowners-empty", "medium",
                            "CODEOWNERS file is empty / all-comments",
                            "No effective owner rules, so PR review can be "
                            "approved by anyone with write access.",
                            "Add at least a `* @org/security-team` "
                            "fallback rule.",
                            rel, 1))
        return out
    has_default = any(line.startswith("*") for line in rules)
    if not has_default:
        out.append(_finding(repo, "codeowners-no-default", "low",
                            "CODEOWNERS has no default `*` rule",
                            "Without a default rule, files matching no "
                            "pattern have no required reviewer.",
                            "Add `* @org/<fallback-team>` at the end.",
                            rel, 1))
    # Look for blanket * → @org/everyone style: ok by itself but flag
    # the team being something obviously broad.
    for i, line in enumerate(rules, start=1):
        m = re.match(r"^\*\s+(@?[\w/@.-]+)", line)
        if not m:
            continue
        owner = m.group(1)
        low = owner.lower()
        if low in ("@everyone", "@org/everyone", "@all"):
            out.append(_finding(repo, "codeowners-blanket-owner", "medium",
                                f"CODEOWNERS default rule grants ownership "
                                f"to '{owner}'",
                                "Blanket owners aren't a meaningful gate.",
                                "Scope to a security or platform team.",
                                rel, i))
    return out


# ── Renovate ─────────────────────────────────────────────────────────

def _check_renovate(path: Path, root: Path, repo: str) -> list[Finding]:
    out: list[Finding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    try:
        # Renovate config can be JSON5; we tolerate trailing commas etc.
        # by best-effort regex inspection without a full parse.
        pass
    except Exception:
        return out

    if re.search(r'"automerge"\s*:\s*true', text):
        # Look for the dangerous combination: automerge=true AND a
        # rule that matches major updates (or no rule scope at all).
        if (re.search(r'"updateTypes"\s*:\s*\[\s*[^\]]*"major"', text)
                or re.search(r'"matchUpdateTypes"\s*:\s*\[\s*[^\]]*"major"', text)
                or '"matchUpdateTypes"' not in text):
            out.append(_finding(repo, "renovate-automerge-major", "high",
                                "Renovate config automerges (possibly major) updates",
                                "automerge=true on a rule that includes "
                                "major bumps means breaking changes can "
                                "land without human review.",
                                "Scope automerge to patch (and maybe minor) "
                                "with matchUpdateTypes=[patch].",
                                rel, _find_line(text, '"automerge"')))
    return out


# ── Dependabot ───────────────────────────────────────────────────────

def _check_dependabot(path: Path, root: Path, repo: str) -> list[Finding]:
    """Dependabot uses YAML. The dangerous-automerge pattern is when a
    user adds a separate GitHub Actions workflow that auto-approves +
    auto-merges Dependabot PRs without filtering by update-type.

    We can't see the workflow from here, but we can flag the config
    when ``open-pull-requests-limit`` is high (>20) without
    ``versioning-strategy: lockfile-only`` - which means a wave of
    unfiltered PRs that might be set to automerge elsewhere.
    """
    out: list[Finding] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return out
    rel = path.relative_to(root).as_posix()
    doc = parse_yaml(text)
    updates = _get(doc, "updates")
    if updates is None:
        return out
    for entry in _items(updates):
        if not isinstance(entry, _Node) or not isinstance(entry.value, dict):
            continue
        limit = _value(_get(entry, "open-pull-requests-limit"))
        strat = _value(_get(entry, "versioning-strategy")) or ""
        try:
            limit_i = int(limit) if limit is not None else 5
        except (TypeError, ValueError):
            limit_i = 5
        if limit_i > 20 and strat != "lockfile-only":
            out.append(_finding(repo, "dependabot-loose-limit", "low",
                                f"Dependabot update has a high PR limit ({limit_i})",
                                "Combined with workflows that auto-merge "
                                "Dependabot PRs, this can flood prod with "
                                "minor/major bumps.",
                                "Lower the limit or set versioning-strategy "
                                "= lockfile-only.",
                                rel, entry.line))
    return out


# ── .env leaks ───────────────────────────────────────────────────────

_ENV_FILES_OK = (".env.example", ".env.sample", ".env.template",
                 ".env.test", ".env.development.sample")


def _check_env_files(root: Path, repo: str) -> list[Finding]:
    out: list[Finding] = []
    import os
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if not fn.startswith(".env"):
                continue
            if fn in _ENV_FILES_OK:
                continue
            full = Path(dirpath) / fn
            rel = full.relative_to(root).as_posix()
            try:
                text = full.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            # If it's only commented/empty, skip.
            non_comment = [line for line in text.split("\n")
                           if line.strip() and not line.strip().startswith("#")]
            if not non_comment:
                continue
            out.append(_finding(
                repo, "env-file-committed", "high",
                f".env file committed: {fn}",
                f"`{fn}` looks like a runtime env file with "
                f"{len(non_comment)} non-comment line(s). Production "
                f"environment files routinely contain credentials and "
                f"should never be committed.",
                f"Rename to {fn}.example (with placeholder values), add "
                f"`{fn}` to .gitignore, and rotate any secrets that may "
                f"have been exposed.",
                rel, 1,
            ))
    return out


def _find_line(text: str, needle: str) -> int:
    idx = text.find(needle)
    if idx < 0:
        return 0
    return text.count("\n", 0, idx) + 1


# ── Public entrypoint ────────────────────────────────────────────────

def scan_path(root: Path, repo: str = "(local)") -> list[Finding]:
    out: list[Finding] = []
    for cand in (root / ".pre-commit-config.yaml",
                 root / ".pre-commit-config.yml"):
        if cand.is_file():
            out.extend(_check_precommit(cand, root, repo))
    for cand in (root / "CODEOWNERS",
                 root / ".github" / "CODEOWNERS",
                 root / "docs" / "CODEOWNERS"):
        if cand.is_file():
            out.extend(_check_codeowners(cand, root, repo))
    for cand in (root / "renovate.json", root / ".renovaterc",
                 root / ".renovaterc.json",
                 root / ".github" / "renovate.json"):
        if cand.is_file():
            out.extend(_check_renovate(cand, root, repo))
    for cand in (root / ".github" / "dependabot.yml",
                 root / ".github" / "dependabot.yaml"):
        if cand.is_file():
            out.extend(_check_dependabot(cand, root, repo))
    out.extend(_check_env_files(root, repo))
    return out
