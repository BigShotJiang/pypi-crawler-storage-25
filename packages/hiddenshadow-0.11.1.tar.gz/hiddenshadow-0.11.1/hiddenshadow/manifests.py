"""Package-manager manifest discovery + parsing.

For each supported manifest type, parse the file and extract the direct
dependencies (names, versions, declared license if any).

Supported:
    - npm (package.json)
    - PyPI (pyproject.toml, requirements.txt, requirements-*.txt)
    - Cargo (Cargo.toml)
    - Go modules (go.mod)
    - Maven (pom.xml)
    - Gradle (build.gradle, build.gradle.kts) — heuristic
    - Composer / PHP (composer.json)
"""
from __future__ import annotations
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path

# Skip these directory names entirely
SKIP_DIRS = {
    ".git", "node_modules", ".gradle", ".m2", "target", "build",
    "dist", "out", ".venv", "venv", "__pycache__", ".idea",
    ".vscode", ".pytest_cache", ".tox",
}


@dataclass
class Dep:
    name: str
    version: str | None
    declared_license: str | None
    source_manifest: str
    package_manager: str  # 'npm', 'pypi', 'cargo', 'go', 'maven', 'composer'


# ── Per-manifest parsers ─────────────────────────────────────────────────


def parse_package_json(path: Path) -> tuple[list[Dep], str | None]:
    deps: list[Dep] = []
    self_license = None
    try:
        d = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return deps, None
    self_license = d.get("license")
    if isinstance(self_license, dict):
        self_license = self_license.get("type")
    for section in ("dependencies", "devDependencies", "peerDependencies",
                    "optionalDependencies"):
        for name, ver in (d.get(section) or {}).items():
            if not isinstance(ver, str):
                continue
            deps.append(Dep(
                name=name, version=ver, declared_license=None,
                source_manifest=str(path), package_manager="npm",
            ))
    return deps, self_license


def parse_pyproject_toml(path: Path) -> tuple[list[Dep], str | None]:
    deps: list[Dep] = []
    self_license = None
    try:
        import tomllib
        d = tomllib.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return deps, None
    project = d.get("project", {})
    license_field = project.get("license")
    if isinstance(license_field, dict):
        self_license = license_field.get("text") or license_field.get("file")
    elif isinstance(license_field, str):
        self_license = license_field
    for spec in (project.get("dependencies") or []):
        m = re.match(r"^\s*([A-Za-z0-9_.\-]+)\s*([<>=!~^].*)?$", spec)
        if not m:
            continue
        deps.append(Dep(
            name=m.group(1), version=(m.group(2) or "").strip(),
            declared_license=None, source_manifest=str(path),
            package_manager="pypi",
        ))
    poetry = d.get("tool", {}).get("poetry", {})
    if poetry:
        if not self_license:
            self_license = poetry.get("license")
        for name, spec in (poetry.get("dependencies") or {}).items():
            ver = spec if isinstance(spec, str) else (
                spec.get("version") if isinstance(spec, dict) else None
            )
            deps.append(Dep(
                name=name, version=ver, declared_license=None,
                source_manifest=str(path), package_manager="pypi",
            ))
    return deps, self_license


def parse_requirements_txt(path: Path) -> list[Dep]:
    deps: list[Dep] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return deps
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        m = re.match(r"^([A-Za-z0-9_.\-]+)\s*([<>=!~^].*)?", line)
        if m:
            deps.append(Dep(
                name=m.group(1), version=(m.group(2) or "").strip(),
                declared_license=None, source_manifest=str(path),
                package_manager="pypi",
            ))
    return deps


def parse_cargo_toml(path: Path) -> tuple[list[Dep], str | None]:
    deps: list[Dep] = []
    self_license = None
    try:
        import tomllib
        d = tomllib.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return deps, None
    pkg = d.get("package", {})
    self_license = pkg.get("license")
    for section in ("dependencies", "dev-dependencies", "build-dependencies"):
        for name, spec in (d.get(section) or {}).items():
            ver = spec if isinstance(spec, str) else (
                spec.get("version") if isinstance(spec, dict) else None
            )
            deps.append(Dep(
                name=name, version=ver, declared_license=None,
                source_manifest=str(path), package_manager="cargo",
            ))
    return deps, self_license


def parse_go_mod(path: Path) -> list[Dep]:
    deps: list[Dep] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return deps
    in_block = False
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("require ("):
            in_block = True
            continue
        if in_block and s == ")":
            in_block = False
            continue
        if in_block or s.startswith("require "):
            m = re.match(r"^(?:require\s+)?(\S+)\s+(\S+)", s)
            if m:
                deps.append(Dep(
                    name=m.group(1), version=m.group(2),
                    declared_license=None, source_manifest=str(path),
                    package_manager="go",
                ))
    return deps


def parse_pom_xml(path: Path) -> tuple[list[Dep], str | None]:
    """Light XML parse — looks for <dependency> blocks. Real Maven
    resolution requires the build; this is manifest-level only."""
    deps: list[Dep] = []
    self_license = None
    try:
        import xml.etree.ElementTree as ET
        tree = ET.parse(path)
        root = tree.getroot()
        # Strip XML namespace
        for el in root.iter():
            if "}" in el.tag:
                el.tag = el.tag.split("}", 1)[1]
        lics = root.find(".//licenses")
        if lics is not None:
            n = lics.find(".//license/name")
            if n is not None and n.text:
                self_license = n.text.strip()
        for dep_el in root.iter("dependency"):
            g = dep_el.find("groupId")
            a = dep_el.find("artifactId")
            v = dep_el.find("version")
            if a is not None and a.text:
                name = (g.text + ":" if g is not None and g.text else "") + a.text
                ver = v.text if v is not None and v.text else None
                deps.append(Dep(
                    name=name, version=ver, declared_license=None,
                    source_manifest=str(path), package_manager="maven",
                ))
    except Exception:
        pass
    return deps, self_license


def parse_gradle(path: Path) -> list[Dep]:
    """Captures `implementation 'group:artifact:version'`-style strings."""
    deps: list[Dep] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return deps
    for m in re.finditer(
        r"""(?:implementation|compile|api|testImplementation|"""
        r"""testCompile|runtimeOnly|compileOnly)\s*[(\s]\s*"""
        r"""['"]([^:'"]+):([^:'"]+):([^'"]+)['"]""",
        text,
    ):
        deps.append(Dep(
            name=f"{m.group(1)}:{m.group(2)}", version=m.group(3),
            declared_license=None, source_manifest=str(path),
            package_manager="maven",
        ))
    return deps


def parse_composer_json(path: Path) -> tuple[list[Dep], str | None]:
    deps: list[Dep] = []
    self_license = None
    try:
        d = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return deps, None
    lic = d.get("license")
    if isinstance(lic, list):
        self_license = " OR ".join(lic)
    elif isinstance(lic, str):
        self_license = lic
    for section in ("require", "require-dev"):
        for name, ver in (d.get(section) or {}).items():
            deps.append(Dep(
                name=name, version=ver, declared_license=None,
                source_manifest=str(path), package_manager="composer",
            ))
    return deps, self_license


# ── Discovery + collection ───────────────────────────────────────────────


def find_manifests(repo_root: Path) -> dict[str, list[Path]]:
    """Locate package manager manifests in a repo."""
    manifests: dict[str, list[Path]] = {
        "npm": [], "pypi-pyproject": [], "pypi-requirements": [],
        "cargo": [], "go": [], "maven": [], "gradle": [], "composer": [],
    }
    for dirpath, dirnames, filenames in os.walk(repo_root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            p = Path(dirpath) / fn
            f = fn.lower()
            if f == "package.json":
                manifests["npm"].append(p)
            elif f == "pyproject.toml":
                manifests["pypi-pyproject"].append(p)
            elif f.startswith("requirements") and f.endswith(".txt"):
                manifests["pypi-requirements"].append(p)
            elif f == "cargo.toml":
                manifests["cargo"].append(p)
            elif f == "go.mod":
                manifests["go"].append(p)
            elif f == "pom.xml":
                manifests["maven"].append(p)
            elif f in ("build.gradle", "build.gradle.kts"):
                manifests["gradle"].append(p)
            elif f == "composer.json":
                manifests["composer"].append(p)
    return manifests


def parse_all_manifests(manifests: dict[str, list[Path]]) -> tuple[list[Dep], str | None]:
    """Parse every found manifest; return all deps + the most authoritative
    self-declared license (preferring root-level manifests)."""
    all_deps: list[Dep] = []
    self_license: str | None = None
    for p in manifests["npm"]:
        ds, sl = parse_package_json(p)
        all_deps.extend(ds)
        if not self_license:
            self_license = sl
    for p in manifests["pypi-pyproject"]:
        ds, sl = parse_pyproject_toml(p)
        all_deps.extend(ds)
        if not self_license:
            self_license = sl
    for p in manifests["pypi-requirements"]:
        all_deps.extend(parse_requirements_txt(p))
    for p in manifests["cargo"]:
        ds, sl = parse_cargo_toml(p)
        all_deps.extend(ds)
        if not self_license:
            self_license = sl
    for p in manifests["go"]:
        all_deps.extend(parse_go_mod(p))
    for p in manifests["maven"]:
        ds, sl = parse_pom_xml(p)
        all_deps.extend(ds)
        if not self_license:
            self_license = sl
    for p in manifests["gradle"]:
        all_deps.extend(parse_gradle(p))
    for p in manifests["composer"]:
        ds, sl = parse_composer_json(p)
        all_deps.extend(ds)
        if not self_license:
            self_license = sl
    return all_deps, self_license
