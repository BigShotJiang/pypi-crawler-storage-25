"""Origin / publisher lookup for binary library signatures.

Two complementary techniques:

1. **Path-based inference** (offline). Many binaries are shipped inside
   conventional package directories whose path encodes the originating
   package:

       node_modules/<name>/...                 → npm/<name>
       site-packages/<name>/...                → pypi/<name>
       vendor/<name>/...                       → vendored, name only
       <name>-<version>.dist-info/...          → pypi/<name>@<version>
       <name>-<version>-*.whl                  → pypi (filename only)
       <name>.<version>.nupkg                  → nuget
       <group>-<artifact>-<version>.jar (Maven layout) → maven

   For .whl / .jar / .nupkg the filename itself encodes name+version.

2. **Registry lookups** (network, opt-in). When path-based inference
   identifies a candidate package:

       - npm: GET https://registry.npmjs.org/<pkg>/<ver>
              → ``dist.shasum`` (SHA-1 of tarball) and
                ``dist.signatures`` / ``dist.attestations`` (since 2023).
                A package with attestations means the build is signed
                by GitHub Actions or another OIDC issuer via npm
                provenance.
       - pypi: GET https://pypi.org/pypi/<pkg>/<ver>/json
              → per-file digests (``digests.sha256``). Per-file
                PEP 740 attestations live at
                ``https://pypi.org/integrity/<pkg>/<ver>/<file>/provenance``.
       - maven: artifact URLs at repo1.maven.org always have a
                sibling ``.asc`` PGP signature.

3. **Sigstore Rekor by hash** (network, opt-in). For any binary whose
   origin we could NOT infer, we POST the SHA-256 to Rekor's index
   endpoint::

       POST https://rekor.sigstore.dev/api/v1/index/retrieve
       Body: {"hash": "sha256:<hex>"}

   A non-empty response means the artifact's hash is recorded in the
   public transparency log, which usually implies it was signed via
   sigstore (cosign, npm provenance, PyPI attestations, etc.).

This module mutates ``SignatureRecord`` objects in place — populating
``origin_registry``, ``origin_package``, ``origin_method``,
``expected_publisher``, and ``signer_verified``.
"""
from __future__ import annotations

import re
import urllib.parse
from pathlib import Path
from typing import Iterable

from .network import CachedHttp
from .signatures import SignatureRecord


# ── Filename / path patterns ────────────────────────────────────────────

# foo-1.2.3-py3-none-any.whl  → ("foo", "1.2.3")
_WHL_RE = re.compile(r"^(?P<name>[A-Za-z0-9_.]+?)-(?P<ver>[0-9][^-]*)-")

# foo.1.2.3.nupkg → ("foo", "1.2.3")
_NUPKG_RE = re.compile(r"^(?P<name>[A-Za-z0-9_.\-]+?)\.(?P<ver>[0-9][0-9A-Za-z.\-+]*)\.nupkg$")

# spring-core-5.3.20.jar (group inferred from path), commons-lang3-3.12.0.jar
_JAR_RE = re.compile(r"^(?P<name>[A-Za-z0-9_\-]+?)-(?P<ver>[0-9][0-9A-Za-z.\-+]*)\.jar$")


def _infer_from_filename(path: str) -> tuple[str, str, str]:
    """Return (registry, name, version) from a filename. ('','','') if unknown."""
    fn = path.rsplit("/", 1)[-1]
    if fn.endswith(".whl"):
        m = _WHL_RE.match(fn)
        if m:
            return "pypi", m.group("name").replace("_", "-"), m.group("ver")
    if fn.endswith(".nupkg") or fn.endswith(".snupkg"):
        m = _NUPKG_RE.match(fn)
        if m:
            return "nuget", m.group("name"), m.group("ver")
    if fn.endswith(".jar"):
        m = _JAR_RE.match(fn)
        if m:
            # Without group coords we can't fully resolve; expose what we know.
            return "maven", m.group("name"), m.group("ver")
    return "", "", ""


def _infer_from_path(rel_path: str) -> tuple[str, str, str]:
    """Return (registry, name, version) inferred from a path.

    Examples:
        node_modules/lodash/dist/foo.js                   → npm, lodash, ""
        node_modules/@scope/pkg/lib/foo.so                → npm, @scope/pkg, ""
        venv/lib/python3.11/site-packages/numpy/foo.so    → pypi, numpy, ""
        venv/lib/python3.11/site-packages/numpy-1.26.0.dist-info/RECORD
                                                          → pypi, numpy, 1.26.0
    """
    parts = rel_path.replace("\\", "/").split("/")
    # node_modules
    for i, p in enumerate(parts):
        if p == "node_modules" and i + 1 < len(parts):
            nxt = parts[i + 1]
            if nxt.startswith("@") and i + 2 < len(parts):
                return "npm", f"{nxt}/{parts[i + 2]}", ""
            if not nxt.startswith("."):
                return "npm", nxt, ""
    # site-packages
    for i, p in enumerate(parts):
        if p == "site-packages" and i + 1 < len(parts):
            nxt = parts[i + 1]
            # Skip dist-info / egg-info, we'll capture from those below
            if nxt.endswith(".dist-info") or nxt.endswith(".egg-info"):
                stem = nxt.rsplit(".", 1)[0]
                if "-" in stem:
                    nm, _, ver = stem.rpartition("-")
                    return "pypi", nm.replace("_", "-"), ver
                return "pypi", stem, ""
            if not nxt.startswith("_"):
                return "pypi", nxt.replace("_", "-"), ""
    return "", "", ""


def annotate_origins_from_paths(records: Iterable[SignatureRecord]) -> None:
    """Offline pass: fill origin_* from filename + filesystem path."""
    for r in records:
        if r.origin_registry:
            continue
        reg, name, ver = _infer_from_filename(r.path)
        method = "filename"
        if not reg:
            reg, name, ver = _infer_from_path(r.path)
            method = "path"
        if reg and name:
            r.origin_registry = reg
            r.origin_package = f"{name}@{ver}" if ver else name
            r.origin_method = method


# ── Registry lookups ────────────────────────────────────────────────────

def _check_npm(http: CachedHttp, name: str, version: str) -> dict:
    """Return {'attested': bool, 'signed': bool, 'publisher': str} for an npm pkg."""
    if version:
        url = f"https://registry.npmjs.org/{urllib.parse.quote(name, safe='@/')}/{urllib.parse.quote(version)}"
        key = f"npm|{name}|{version}"
    else:
        url = f"https://registry.npmjs.org/{urllib.parse.quote(name, safe='@/')}"
        key = f"npm|{name}|latest"
    r = http.fetch(key, url)
    if r.status != 200 or not isinstance(r.data, dict):
        return {}
    d = r.data
    # If we got the package doc back, drill into latest.
    if "dist-tags" in d:
        latest = d.get("dist-tags", {}).get("latest")
        versions = d.get("versions") or {}
        d = versions.get(latest) or {}
    dist = d.get("dist") or {}
    attestations = dist.get("attestations")
    signatures = dist.get("signatures")
    maintainers = d.get("maintainers") or []
    publisher = ""
    if maintainers:
        m = maintainers[0]
        publisher = m.get("name") or m.get("email") or ""
    return {
        "attested": bool(attestations),
        "signed": bool(signatures) or bool(attestations),
        "publisher": publisher,
        "shasum": dist.get("shasum") or "",
        "integrity": dist.get("integrity") or "",
    }


def _check_pypi(http: CachedHttp, name: str, version: str) -> dict:
    if version:
        url = f"https://pypi.org/pypi/{urllib.parse.quote(name)}/{urllib.parse.quote(version)}/json"
        key = f"pypi|{name}|{version}"
    else:
        url = f"https://pypi.org/pypi/{urllib.parse.quote(name)}/json"
        key = f"pypi|{name}|latest"
    r = http.fetch(key, url)
    if r.status != 200 or not isinstance(r.data, dict):
        return {}
    info = r.data.get("info") or {}
    urls = r.data.get("urls") or []
    sha256s = []
    has_pgp = False
    for u in urls:
        digests = u.get("digests") or {}
        if digests.get("sha256"):
            sha256s.append(digests["sha256"])
        if u.get("has_sig"):
            has_pgp = True
    return {
        "publisher": info.get("author") or info.get("maintainer") or "",
        "signed": has_pgp,
        "sha256s": sha256s,
    }


def _rekor_lookup(http: CachedHttp, sha256_hex: str) -> bool:
    """Return True if Rekor has any entry indexed by sha256:<hex>."""
    if not sha256_hex:
        return False
    body = {"hash": f"sha256:{sha256_hex}"}
    key = f"rekor|{sha256_hex}"
    r = http.fetch(key, "https://rekor.sigstore.dev/api/v1/index/retrieve",
                   method="POST", body=body,
                   headers={"Content-Type": "application/json"})
    if r.status == 200 and isinstance(r.data, list) and r.data:
        return True
    return False


def annotate_origins_via_registry(records: Iterable[SignatureRecord],
                                  cache_dir: Path,
                                  rekor_lookup: bool = True,
                                  progress=None) -> None:
    """Network pass: confirm origin + compare signer subject vs publisher.

    Safe to skip — if network is unavailable the records are left as-is.
    """
    http = CachedHttp(cache_dir, service="signatures",
                      max_workers=8, request_delay_ms=80)
    items = list(records)
    total = len(items)
    for idx, r in enumerate(items, start=1):
        if progress:
            try:
                progress(idx, total)
            except Exception:
                pass
        # 1. Confirm origin where we have a candidate.
        info: dict = {}
        if r.origin_registry == "npm":
            name, _, ver = r.origin_package.partition("@")
            info = _check_npm(http, name, ver)
        elif r.origin_registry == "pypi":
            name, _, ver = r.origin_package.partition("@")
            info = _check_pypi(http, name, ver)
        if info:
            r.expected_publisher = info.get("publisher") or ""
            # If the registry says the package is signed/attested and we
            # parsed a signer subject locally, compare them.
            if r.signed and r.signer_subject and r.expected_publisher:
                if _publisher_matches(r.signer_subject, r.expected_publisher):
                    r.signer_verified = "verified"
                else:
                    r.signer_verified = "publisher-mismatch"
            elif r.signed and r.signer_subject and not r.expected_publisher:
                r.signer_verified = "subject-only"
            # PyPI sha256 cross-check: if the file's hash matches a
            # registry-listed sha256, that strongly confirms origin.
            if r.origin_registry == "pypi" and r.sha256:
                if r.sha256 in (info.get("sha256s") or []):
                    r.origin_method = (r.origin_method or "") + "+sha256-match"

        # 2. For everything still origin-unknown, try Rekor.
        if rekor_lookup and not r.origin_registry and r.sha256:
            try:
                if _rekor_lookup(http, r.sha256):
                    r.origin_registry = "sigstore-rekor"
                    r.origin_package = f"sha256:{r.sha256[:16]}..."
                    r.origin_method = "rekor-hash"
                    if not r.signed:
                        # File hash is in the transparency log even
                        # though there's no embedded signature — it
                        # was likely signed via a detached sigstore
                        # bundle elsewhere.
                        r.signed = True
                        r.signature_type = "sigstore-detached"
            except Exception:
                pass


# ── Publisher matching ──────────────────────────────────────────────────

def _publisher_matches(signer_subject: str, expected_publisher: str) -> bool:
    """Loose match: signer CN often differs in surface form from a
    registry publisher username. We normalize and look for any shared
    significant token (length >= 4)."""
    if not signer_subject or not expected_publisher:
        return False
    a = signer_subject.lower()
    b = expected_publisher.lower()
    if a == b or a in b or b in a:
        return True
    tokens_a = {t for t in re.split(r"[^a-z0-9]+", a) if len(t) >= 4}
    tokens_b = {t for t in re.split(r"[^a-z0-9]+", b) if len(t) >= 4}
    return bool(tokens_a & tokens_b)


# ── Manifest-level signature audit ──────────────────────────────────────

def audit_declared_deps(rollup_rows: list[dict], cache_dir: Path,
                        progress=None) -> list[dict]:
    """For each declared dependency, ask whether the published artifact
    is signed / attested. Returns a list of records the caller can
    convert into Findings or write to the signature report.

    Each result row:
        {
            'name': str, 'package_manager': str, 'version': str,
            'attested': bool, 'signed': bool, 'publisher': str,
            'registry': str, 'status': 'attested'|'signed'|'unsigned'|'unknown'
        }
    """
    http = CachedHttp(cache_dir, service="signatures",
                      max_workers=8, request_delay_ms=80)
    out: list[dict] = []
    total = len(rollup_rows)
    for idx, r in enumerate(rollup_rows, start=1):
        if progress:
            try:
                progress(idx, total)
            except Exception:
                pass
        pm = r.get("package_manager", "")
        name = r.get("name", "")
        versions = (r.get("versions") or "").split(",")
        version = (versions[0] if versions else "").strip().lstrip("^~v=>=< ").strip()
        if pm == "npm":
            info = _check_npm(http, name, version)
            if not info:
                status = "unknown"
            elif info.get("attested"):
                status = "attested"
            elif info.get("signed"):
                status = "signed"
            else:
                status = "unsigned"
            out.append({
                "name": name, "package_manager": pm, "version": version,
                "registry": "npm",
                "attested": bool(info.get("attested")),
                "signed": bool(info.get("signed")),
                "publisher": info.get("publisher", ""),
                "status": status,
            })
        elif pm == "pypi":
            info = _check_pypi(http, name, version)
            if not info:
                status = "unknown"
            elif info.get("signed"):
                status = "signed"
            else:
                status = "unsigned"
            out.append({
                "name": name, "package_manager": pm, "version": version,
                "registry": "pypi",
                "attested": False,
                "signed": bool(info.get("signed")),
                "publisher": info.get("publisher", ""),
                "status": status,
            })
        # Maven / Cargo / Go can be added later — Maven Central always
        # has a sibling .asc which is too brittle to validate over HTTP
        # without parsing the actual artifact path.
    return out


def declared_deps_to_findings(audit_rows: Iterable[dict]) -> list:
    """Convert audit rows into Findings. Imported lazily to avoid a cycle."""
    from .findings import Finding
    out = []
    for r in audit_rows:
        if r["status"] == "unsigned":
            out.append(Finding(
                repo="(rollup)",
                severity="medium",
                category="signature",
                title=f"Declared dependency has no published signature ({r['registry']})",
                location=f"{r['package_manager']}:{r['name']}@{r['version']}",
                detail=(
                    f"{r['registry']} publishes {r['name']}@{r['version']} "
                    f"without provenance attestations or PGP signatures. "
                    f"Publisher: {r['publisher'] or '(unknown)'}."
                ),
                recommendation=(
                    "Prefer versions with signed provenance (npm provenance, "
                    "PEP 740 attestations). Track upstream's signing roadmap."
                ),
                method="signature:registry-audit",
            ))
        elif r["status"] == "attested":
            out.append(Finding(
                repo="(rollup)",
                severity="info",
                category="signature",
                title=f"Declared dependency has provenance attestation ({r['registry']})",
                location=f"{r['package_manager']}:{r['name']}@{r['version']}",
                detail=(
                    f"{r['name']}@{r['version']} carries a build-provenance "
                    f"attestation on {r['registry']}. Publisher: "
                    f"{r['publisher'] or '(unknown)'}."
                ),
                recommendation="No action — attested by the registry.",
                method="signature:registry-audit",
            ))
    return out
