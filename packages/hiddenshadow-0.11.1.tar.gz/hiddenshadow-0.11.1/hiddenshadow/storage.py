"""Storage backends for the scan-history index.

The application logic uses ``get_history_storage()`` and calls the
HistoryStorage protocol — it never touches a filesystem path directly.
The small-org installer ships the file-backed implementation; an
enterprise deployment overrides ``Config.history_backend`` (or provides
its own backend via the registry) so the SAME application code talks to
a DB / network store instead.

To plug in a new backend:

    from hiddenshadow.storage import register_history_backend, HistoryStorage

    class PostgresHistoryStorage(HistoryStorage):
        ...

    register_history_backend("postgres", PostgresHistoryStorage)

then set ``history_backend = "postgres"`` (and any backend-specific
keys) in the config.
"""
from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable

from . import config as config_mod


@dataclass
class HistoryEntry:
    job_id: str
    source_root: str
    output_root: str
    started_at: float
    finished_at: float
    duration_s: float
    status: str                            # complete | error
    repos_scanned: int = 0
    total_findings: int = 0
    by_severity: dict[str, int] = field(default_factory=dict)
    behavior_profile: dict[str, int] = field(default_factory=dict)
    error: str | None = None
    label: str | None = None

    def display_name(self) -> str:
        from pathlib import Path
        return self.label or Path(self.source_root).name or self.source_root


class HistoryStorage(ABC):
    """Protocol for scan-history persistence.

    Implementations MUST be thread-safe. The web UI hits these methods
    concurrently from request threads + a background scan worker.
    """

    @abstractmethod
    def load_all(self) -> list[HistoryEntry]:
        """Return all entries, newest first."""

    @abstractmethod
    def record(self, entry: HistoryEntry) -> None:
        """Insert (or replace, by job_id) one entry. Caps to max_entries."""

    @abstractmethod
    def delete(self, job_id: str) -> bool:
        """Remove one entry. Returns True if anything was removed."""

    @abstractmethod
    def delete_with_artifacts(self, job_id: str) -> dict[str, Any]:
        """Remove one entry AND any scan-specific artifact files it
        produced (NEVER the user's source tree). Returns a result dict
        with keys 'removed_entry', 'removed_files', 'errors'."""

    @abstractmethod
    def clear_all(self) -> int:
        """Remove every entry. Returns the count removed."""

    @abstractmethod
    def describe(self) -> dict[str, Any]:
        """Return a small dict describing where data lives, for diagnostics."""


# ── Backend registry ─────────────────────────────────────────────────────

_backends: dict[str, Callable[[], HistoryStorage]] = {}
_instance_lock = threading.Lock()
_instance: HistoryStorage | None = None


def register_history_backend(name: str,
                             factory: Callable[[], HistoryStorage]) -> None:
    """Make a backend available under config key history_backend = <name>.

    factory() must return a fresh HistoryStorage instance.
    """
    _backends[name] = factory


def _try_lazy_import(backend_name: str) -> None:
    """If a backend name isn't registered yet, try ``hiddenshadow.storage_<name>``.

    This lets the small-org installer skip the import cost of every
    optional backend, while enterprise deployments only need to flip
    one config key.
    """
    if backend_name in _backends:
        return
    if not backend_name.isidentifier():
        return
    try:
        __import__(f"hiddenshadow.storage_{backend_name}")
    except ImportError:
        pass


def get_history_storage() -> HistoryStorage:
    """Return the configured HistoryStorage singleton.

    Lazily constructs it on first access using the registry + config.
    Subsequent calls return the same instance for the process lifetime.
    """
    global _instance
    with _instance_lock:
        if _instance is not None:
            return _instance
        cfg = config_mod.load()
        backend_name = cfg.history_backend
        _try_lazy_import(backend_name)
        factory = _backends.get(backend_name)
        if factory is None:
            raise RuntimeError(
                f"Unknown history_backend '{backend_name}'. "
                f"Registered: {list(_backends)}"
            )
        _instance = factory()
        return _instance


def reset_for_tests() -> None:
    """Drop the cached HistoryStorage instance. Tests only."""
    global _instance
    with _instance_lock:
        _instance = None
