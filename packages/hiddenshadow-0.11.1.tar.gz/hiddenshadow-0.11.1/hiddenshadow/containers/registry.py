"""OCI Registry v2 client (stdlib HTTP, no external deps).

Implements the subset of the Distribution v2 spec needed for security
scanning:

* Token-auth challenge flow (HTTP 401 + ``WWW-Authenticate: Bearer
  realm=...`` -> GET token endpoint -> retry with Bearer).
* Anonymous token requests (no creds) which work for public images on
  Docker Hub, GHCR public repos, gcr.io, quay.io, and registry.k8s.io.
* Manifest fetch with multi-Accept (Docker manifest v2, OCI image
  manifest, OCI image index, Docker fat manifest list) and follow-on
  resolution for multi-arch (picks linux/amd64 by default).
* Blob fetch with size cap.

We intentionally do NOT implement push, signed manifests, or chunked
upload. We do NOT pull images from registries that require login (ECR,
private GCR/ACR) - those raise a ``RegistryAuthError``.
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any

# Media types we accept on a manifest fetch (priority high-to-low).
_MANIFEST_ACCEPTS = ", ".join([
    "application/vnd.oci.image.index.v1+json",
    "application/vnd.docker.distribution.manifest.list.v2+json",
    "application/vnd.oci.image.manifest.v1+json",
    "application/vnd.docker.distribution.manifest.v2+json",
])

USER_AGENT = "hiddenshadow-containerscan/0.1"

# Default platform we resolve to in a multi-arch index.
DEFAULT_PLATFORM = ("linux", "amd64")


class RegistryError(Exception):
    """Generic registry failure."""


class RegistryAuthError(RegistryError):
    """The registry requires credentials we don't have."""


class RegistryNotFoundError(RegistryError):
    """The image / manifest doesn't exist or is not visible anonymously."""


@dataclass
class Layer:
    digest: str            # 'sha256:...'
    size: int              # bytes
    media_type: str


@dataclass
class ImageManifest:
    image_ref: str             # original "registry/repo:tag" string
    digest: str                # the manifest digest (sha256:...)
    layers: list[Layer] = field(default_factory=list)
    config_digest: str = ""
    architecture: str = ""
    os_name: str = ""


def _registry_host(registry: str) -> str:
    """Normalize a registry hostname for the v2 API."""
    if registry == "docker.io":
        return "registry-1.docker.io"
    return registry


def _scheme_for(registry: str) -> str:
    if registry == "localhost" or registry.startswith("localhost:"):
        return "http"
    return "https"


def _url(registry: str, path: str) -> str:
    return f"{_scheme_for(registry)}://{_registry_host(registry)}{path}"


def _http_get(url: str, headers: dict[str, str] | None = None,
              timeout: float = 15.0) -> tuple[int, dict[str, str], bytes]:
    req_headers = {"User-Agent": USER_AGENT}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return (resp.status,
                    {k.lower(): v for k, v in resp.headers.items()},
                    resp.read())
    except urllib.error.HTTPError as e:
        body = b""
        try:
            body = e.read()
        except Exception:  # pragma: no cover
            pass
        return (e.code,
                {k.lower(): v for k, v in e.headers.items()} if e.headers else {},
                body)


_BEARER_RE = re.compile(r'Bearer\s+(.*)$', re.IGNORECASE)
_BEARER_KV_RE = re.compile(r'(\w+)\s*=\s*"([^"]*)"')


def _parse_www_authenticate(header_value: str) -> dict[str, str]:
    """Parse Bearer challenge into {realm: ..., service: ..., scope: ...}."""
    m = _BEARER_RE.match(header_value or "")
    if not m:
        return {}
    out: dict[str, str] = {}
    for k, v in _BEARER_KV_RE.findall(m.group(1)):
        out[k.lower()] = v
    return out


def _get_anonymous_token(challenge: dict[str, str]) -> str:
    """Exchange a Bearer challenge for an anonymous token."""
    realm = challenge.get("realm")
    if not realm:
        raise RegistryAuthError("WWW-Authenticate had no realm")
    params: list[tuple[str, str]] = []
    if "service" in challenge:
        params.append(("service", challenge["service"]))
    if "scope" in challenge:
        params.append(("scope", challenge["scope"]))
    url = realm + ("?" + urllib.parse.urlencode(params) if params else "")
    status, _hdrs, body = _http_get(url)
    if status != 200:
        raise RegistryAuthError(
            f"Token endpoint returned {status} for {url}")
    try:
        data = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as e:
        raise RegistryAuthError(f"Token endpoint returned non-JSON: {e}")
    tok = data.get("token") or data.get("access_token")
    if not tok:
        raise RegistryAuthError("Token endpoint returned no token field")
    return tok


def _registry_get(registry: str, path: str, *,
                  accept: str | None = None,
                  token: str | None = None,
                  ) -> tuple[int, dict[str, str], bytes, str]:
    """GET against the registry, doing the Bearer challenge dance once.

    Returns (status, headers, body, token_used). If the request was
    challenged we return the token we resolved so the caller can reuse it
    for follow-up requests (same registry + same scope).
    """
    headers = {}
    if accept:
        headers["Accept"] = accept
    if token:
        headers["Authorization"] = f"Bearer {token}"
    url = _url(registry, path)
    status, hdrs, body = _http_get(url, headers=headers)
    if status == 401 and token is None:
        challenge = _parse_www_authenticate(hdrs.get("www-authenticate", ""))
        if not challenge:
            raise RegistryAuthError(
                f"401 from {url} but no Bearer challenge")
        token = _get_anonymous_token(challenge)
        headers["Authorization"] = f"Bearer {token}"
        status, hdrs, body = _http_get(url, headers=headers)
    return status, hdrs, body, token or ""


def fetch_manifest(image_ref) -> ImageManifest:
    """Resolve and fetch an image manifest. ``image_ref`` is an
    :class:`hiddenshadow.containers.dockerfile.ImageRef` instance.

    On a multi-arch index, we follow to the linux/amd64 manifest.
    """
    reference = image_ref.digest or image_ref.tag or "latest"
    path = f"/v2/{image_ref.repository}/manifests/{reference}"
    status, hdrs, body, token = _registry_get(
        image_ref.registry, path, accept=_MANIFEST_ACCEPTS)
    if status == 404:
        raise RegistryNotFoundError(
            f"Manifest not found: {image_ref.raw} ({status})")
    if status == 401 or status == 403:
        raise RegistryAuthError(
            f"Registry requires authentication: {image_ref.raw}")
    if status != 200:
        raise RegistryError(
            f"Manifest fetch returned {status} for {image_ref.raw}")
    digest = hdrs.get("docker-content-digest", "") or _digest_of(body)
    try:
        data = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as e:
        raise RegistryError(f"Manifest is not JSON: {e}")
    media_type = (
        data.get("mediaType")
        or hdrs.get("content-type", "").split(";")[0].strip()
    )
    # Multi-arch index → follow to the right platform.
    if media_type in (
        "application/vnd.oci.image.index.v1+json",
        "application/vnd.docker.distribution.manifest.list.v2+json",
    ):
        chosen = _pick_platform(data.get("manifests") or [])
        if not chosen:
            raise RegistryError(
                f"No {DEFAULT_PLATFORM[0]}/{DEFAULT_PLATFORM[1]} platform "
                f"in index for {image_ref.raw}")
        sub_digest = chosen.get("digest")
        if not sub_digest:
            raise RegistryError("Index entry missing digest")
        # Recursive fetch of the per-platform manifest.
        sub_path = f"/v2/{image_ref.repository}/manifests/{sub_digest}"
        status2, hdrs2, body2, _ = _registry_get(
            image_ref.registry, sub_path, accept=_MANIFEST_ACCEPTS,
            token=token)
        if status2 != 200:
            raise RegistryError(
                f"Per-platform manifest fetch returned {status2}")
        digest = hdrs2.get("docker-content-digest", "") or sub_digest
        data = json.loads(body2.decode("utf-8"))
        media_type = data.get("mediaType") or media_type

    layers_raw = data.get("layers") or []
    layers: list[Layer] = []
    for L in layers_raw:
        layers.append(Layer(
            digest=L.get("digest", ""),
            size=int(L.get("size", 0)),
            media_type=L.get("mediaType", ""),
        ))
    config_digest = (data.get("config") or {}).get("digest", "")
    return ImageManifest(
        image_ref=image_ref.raw,
        digest=digest,
        layers=layers,
        config_digest=config_digest,
    )


def _pick_platform(entries: list[dict[str, Any]]) -> dict[str, Any] | None:
    want_os, want_arch = DEFAULT_PLATFORM
    for e in entries:
        plat = e.get("platform") or {}
        if (plat.get("os") == want_os
                and plat.get("architecture") == want_arch
                and not plat.get("variant", "")):
            return e
    # Fall back to any matching arch with a variant (e.g. amd64/v2).
    for e in entries:
        plat = e.get("platform") or {}
        if (plat.get("os") == want_os
                and plat.get("architecture") == want_arch):
            return e
    return None


def _digest_of(blob: bytes) -> str:
    import hashlib
    return "sha256:" + hashlib.sha256(blob).hexdigest()


def fetch_blob(registry: str, repository: str, digest: str,
               *, max_size: int = 100 * 1024 * 1024,
               token: str | None = None) -> bytes:
    """Download a blob (typically a layer tarball). Caps at ``max_size``."""
    path = f"/v2/{repository}/blobs/{digest}"
    status, hdrs, body, _ = _registry_get(registry, path, token=token)
    if status == 404:
        raise RegistryNotFoundError(
            f"Blob not found: {repository}@{digest}")
    if status != 200:
        raise RegistryError(
            f"Blob fetch returned {status} for {repository}@{digest}")
    if len(body) > max_size:
        raise RegistryError(
            f"Blob {digest[:16]} exceeds max_size ({len(body)} > {max_size})")
    return body
