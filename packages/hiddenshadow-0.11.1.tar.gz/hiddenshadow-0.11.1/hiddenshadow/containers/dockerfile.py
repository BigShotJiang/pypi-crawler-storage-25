"""Dockerfile / Containerfile parser + static security rules.

Parser
------
Handles:
* Line continuations (``\\``)
* Comments (``#``)
* Multi-stage builds (``FROM ... AS stage_name``)
* Heredoc syntax in RUN (``<<EOF`` ... ``EOF``)
* ``ARG`` defaults and ``$VAR`` / ``${VAR}`` expansions (best-effort)

Rules
-----
~30 rules covering image hygiene, secret leakage, network-fetched-and-run,
unrestricted privileges, and missing build hardening. Severity reflects
real exploitability, not best-practice purity.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from ..findings import Finding


# ── Parsed instruction model ────────────────────────────────────────────

@dataclass
class Instruction:
    """One Dockerfile instruction after line-continuation and comment stripping."""
    cmd: str               # e.g. "FROM", "RUN", "ENV"
    args: str              # everything after the command
    line: int              # 1-based line in the original file
    stage: str = ""        # named stage if FROM ... AS x; defaults to ""


@dataclass
class Stage:
    """A parsed multi-stage build stage."""
    name: str              # name from FROM ... AS x ; "" if unnamed
    base_image: str        # the base FROM image (after ARG expansion if simple)
    base_image_raw: str    # the raw FROM token
    instructions: list[Instruction] = field(default_factory=list)
    line_start: int = 0


@dataclass
class ParsedDockerfile:
    file: Path
    stages: list[Stage] = field(default_factory=list)
    args: dict[str, str] = field(default_factory=dict)  # ARG defaults seen


# ── Parser ──────────────────────────────────────────────────────────────

_DOCKER_CMDS = (
    "FROM", "RUN", "CMD", "LABEL", "MAINTAINER", "EXPOSE", "ENV", "ADD",
    "COPY", "ENTRYPOINT", "VOLUME", "USER", "WORKDIR", "ARG", "ONBUILD",
    "STOPSIGNAL", "HEALTHCHECK", "SHELL",
)
_CMD_PAT = re.compile(
    r"^\s*(?P<cmd>" + "|".join(_DOCKER_CMDS) + r")\s+(?P<args>.*)$",
    re.IGNORECASE,
)


def _expand_simple_var(s: str, env: dict[str, str]) -> str:
    """Substitute $VAR / ${VAR} when the value is known. Untouched otherwise."""
    def repl(m: re.Match) -> str:
        name = m.group(1) or m.group(2)
        return env.get(name, m.group(0))
    return re.sub(r"\$\{([A-Za-z_][\w]*)\}|\$([A-Za-z_][\w]*)", repl, s)


def parse_dockerfile(text: str, file: Path) -> ParsedDockerfile:
    """Parse a Dockerfile into stages and instructions."""
    pd = ParsedDockerfile(file=file)
    # Join continuations into logical lines, but keep track of line numbers.
    raw_lines = text.split("\n")
    logical: list[tuple[int, str]] = []  # (start_line, joined_content)
    buf: list[str] = []
    buf_start = 0
    for i, raw in enumerate(raw_lines, start=1):
        stripped = raw.rstrip()
        if not buf and (not stripped or stripped.lstrip().startswith("#")):
            continue
        if not buf:
            buf_start = i
        # Strip trailing-comment? Dockerfile doesn't allow inline comments
        # except in heredocs; we leave it alone.
        if stripped.endswith("\\"):
            buf.append(stripped[:-1])
        else:
            buf.append(stripped)
            logical.append((buf_start, " ".join(buf).strip()))
            buf = []
    if buf:
        logical.append((buf_start, " ".join(buf).strip()))

    current_stage: Stage | None = None
    arg_env: dict[str, str] = {}
    for line_no, content in logical:
        m = _CMD_PAT.match(content)
        if not m:
            continue
        cmd = m.group("cmd").upper()
        args = m.group("args").strip()
        ins = Instruction(cmd=cmd, args=args, line=line_no)
        if cmd == "ARG":
            # Form: NAME or NAME=DEFAULT
            for piece in args.split():
                if "=" in piece:
                    k, _, v = piece.partition("=")
                    arg_env[k.strip()] = v.strip().strip('"').strip("'")
                    pd.args[k.strip()] = arg_env[k.strip()]
                else:
                    arg_env.setdefault(piece.strip(), "")
                    pd.args.setdefault(piece.strip(), "")
            if current_stage is None:
                # ARGs before the first FROM are global; attach to a synthetic
                # stage so they show up in iteration.
                continue
        if cmd == "FROM":
            stage_name = ""
            base_raw = args
            # FROM <image> AS <name>
            m2 = re.match(r"^(?P<img>\S+)(?:\s+AS\s+(?P<name>\S+))?$",
                          args, re.IGNORECASE)
            if m2:
                base_raw = m2.group("img")
                stage_name = (m2.group("name") or "").strip()
            base_expanded = _expand_simple_var(base_raw, arg_env)
            current_stage = Stage(
                name=stage_name,
                base_image=base_expanded,
                base_image_raw=base_raw,
                line_start=line_no,
            )
            pd.stages.append(current_stage)
        ins.stage = current_stage.name if current_stage else ""
        if current_stage is not None:
            current_stage.instructions.append(ins)
    return pd


# ── Image-reference helpers ─────────────────────────────────────────────

@dataclass
class ImageRef:
    registry: str          # e.g. 'docker.io', 'ghcr.io', 'gcr.io'
    repository: str        # e.g. 'library/nginx', 'org/app'
    tag: str               # e.g. 'latest', '1.21', '' if digest-only
    digest: str            # e.g. 'sha256:...'
    raw: str

    @property
    def is_digest_pinned(self) -> bool:
        return bool(self.digest)

    @property
    def is_latest(self) -> bool:
        return self.tag == "latest"


def parse_image_ref(s: str) -> ImageRef:
    """Parse an image reference like Docker's resolver does (best effort).

    Accepts: ``nginx``, ``nginx:1.21``, ``library/nginx:1.21``,
    ``ghcr.io/foo/bar:tag``, ``foo@sha256:...``, ``foo:tag@sha256:...``.
    """
    raw = s.strip()
    digest = ""
    if "@" in raw:
        ref, _, digest = raw.partition("@")
    else:
        ref = raw
    tag = ""
    # First slash decides whether the part before is a registry or a user.
    # If it contains '.' or ':' or is 'localhost', it's a registry.
    if "/" in ref:
        head, _, rest = ref.partition("/")
        if head == "localhost" or "." in head or ":" in head:
            registry = head
            repo_tag = rest
        else:
            registry = "docker.io"
            repo_tag = ref
    else:
        registry = "docker.io"
        repo_tag = "library/" + ref
    if ":" in repo_tag:
        repository, _, tag = repo_tag.rpartition(":")
    else:
        repository = repo_tag
        tag = "latest" if not digest else ""
    if registry == "docker.io" and "/" not in repository:
        repository = "library/" + repository
    return ImageRef(registry=registry, repository=repository,
                    tag=tag, digest=digest, raw=raw)


# ── Rules ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class DockerfileRule:
    id: str
    severity: str
    title: str
    detail_tmpl: str
    recommendation: str
    reference: str = ""


def _finding(rule: DockerfileRule, _path: Path, line: int,
             repo: str, **kwargs) -> Finding:
    return Finding(
        repo=repo,
        severity=rule.severity,
        category="container",
        title=rule.title,
        location=f"{_path.name}:{line}",
        detail=rule.detail_tmpl.format(**kwargs),
        recommendation=rule.recommendation,
        method=f"container:dockerfile:{rule.id}",
    )


# Sensitive ports - same set used elsewhere in the codebase.
_SENSITIVE_PORTS = {
    22, 23, 135, 137, 139, 445, 1433, 1521, 2375, 2376, 3306, 3389,
    5432, 5601, 6379, 8086, 9092, 9200, 9300, 11211, 27017,
}

_SECRET_NAME_RE = re.compile(
    r"(?:^|[_\-])(PASSWORD|PASSWD|SECRET|TOKEN|APIKEY|API_KEY|API-KEY|"
    r"PRIVATEKEY|PRIVATE_KEY|PRIVATE-KEY|CREDENTIAL|AUTH|"
    r"AWS_ACCESS|AWS_SECRET|AWS-ACCESS|AWS-SECRET)(?:$|[_\-])",
    re.IGNORECASE,
)
_SECRET_VALUE_RE = re.compile(
    r"=\s*[\"']?([A-Za-z0-9_\-+/=]{16,})[\"']?(?:\s|$)"
)

# Rule library (constants used by both parse pass and tests).
RULE_LATEST_TAG = DockerfileRule(
    "df-latest-tag", "medium",
    "Base image uses ':latest' tag",
    "FROM {image} pulls a moving tag. Builds are not reproducible and may "
    "silently inherit new vulnerabilities or behavioral changes.",
    "Pin to a specific version tag and (best) a digest "
    "(image:1.2.3@sha256:...) so rebuilds are reproducible.",
    "CIS-Docker 4.6",
)
RULE_NO_TAG = DockerfileRule(
    "df-no-tag", "medium",
    "Base image has no tag (implicit ':latest')",
    "FROM {image} omits the tag, which docker resolves to ':latest'.",
    "Add an explicit version tag and (best) a digest.",
    "CIS-Docker 4.6",
)
RULE_FLOATING_MAJOR = DockerfileRule(
    "df-floating-major", "low",
    "Base image tag is a single floating number",
    "FROM {image} pins only a major version; minor/patch updates flow in "
    "automatically.",
    "Pin a more specific tag (e.g. 1.21.6) and ideally a digest.",
)
RULE_NOT_DIGEST_PINNED = DockerfileRule(
    "df-not-digest-pinned", "low",
    "Base image is not pinned by digest",
    "FROM {image} resolves a tag at build time. Tags are mutable on most "
    "registries, so the image you build today may not match the one you "
    "build tomorrow.",
    "Append @sha256:<digest> to the image reference.",
    "CIS-Docker 4.5",
)
RULE_USER_ROOT = DockerfileRule(
    "df-user-root", "high",
    "Final stage runs as root (no USER directive)",
    "No USER instruction in the final stage of {file}. The container "
    "process inherits root, which combined with any escape becomes a host "
    "compromise.",
    "Add `USER <non-root-uid>` (e.g. USER 1001) before the ENTRYPOINT.",
    "CIS-Docker 4.1",
)
RULE_USER_EXPLICIT_ROOT = DockerfileRule(
    "df-user-explicit-root", "high",
    "USER directive sets root explicitly",
    "USER root in the final stage. The container will run privileged "
    "even if Docker's --user flag is not used.",
    "Use a non-root UID (e.g. USER 1001).",
    "CIS-Docker 4.1",
)
RULE_ADD_REMOTE = DockerfileRule(
    "df-add-remote", "high",
    "ADD downloads a remote URL",
    "ADD {url} ... fetches a remote file at build time. ADD does no "
    "checksum, no signature, and the source can change between builds.",
    "Use COPY for local files; for remote downloads, RUN curl with a "
    "verified hash (sha256sum -c) or pin the URL to an immutable artifact.",
    "CIS-Docker 4.9",
)
RULE_CURL_PIPE_SH = DockerfileRule(
    "df-curl-pipe-sh", "critical",
    "RUN pipes network output directly into a shell",
    "Pattern 'curl ... | sh' (or wget|sh, etc.) runs whatever the URL "
    "returns. The image you build is at the mercy of every later content "
    "change at that URL.",
    "Download to a file, verify its hash, then execute. Better: vendor "
    "the script into the build context.",
    "CIS-Docker 4.9",
)
RULE_PKG_NO_NO_RECOMMENDS = DockerfileRule(
    "df-apt-no-recommends", "low",
    "apt-get install without --no-install-recommends",
    "{cmd}. Recommended packages bloat the image and add attack surface.",
    "Pass --no-install-recommends. Combine with `rm -rf /var/lib/apt/lists/*` "
    "in the same RUN.",
)
RULE_APT_NO_CLEANUP = DockerfileRule(
    "df-apt-no-cleanup", "low",
    "apt-get install without /var/lib/apt/lists cleanup",
    "{cmd}. The package index is left in the image, growing it without "
    "necessity.",
    "Append `&& rm -rf /var/lib/apt/lists/*` in the same RUN layer.",
)
RULE_APT_GET_UPGRADE = DockerfileRule(
    "df-apt-upgrade", "medium",
    "apt-get upgrade / dist-upgrade in image build",
    "{cmd}. Upgrading packages at build time produces non-reproducible "
    "images that drift from the base.",
    "Pin specific package versions instead of bulk-upgrading.",
)
RULE_PIP_TRUSTED_HOST = DockerfileRule(
    "df-pip-trusted-host", "high",
    "pip install with --trusted-host",
    "{cmd}. --trusted-host disables TLS verification for the named index, "
    "which permits MITM injection of arbitrary packages.",
    "Remove --trusted-host. If a private index lacks a valid certificate, "
    "fix the certificate, not the client.",
)
RULE_PIP_INSECURE = DockerfileRule(
    "df-pip-index-http", "high",
    "pip --index-url uses cleartext HTTP",
    "{cmd}. The package source is unauthenticated; an on-path attacker "
    "can substitute any package contents.",
    "Use https:// for any --index-url.",
)
RULE_NPM_UNSAFE_PERM = DockerfileRule(
    "df-npm-unsafe-perm", "medium",
    "npm install with --unsafe-perm",
    "{cmd}. --unsafe-perm runs install scripts as root regardless of the "
    "effective user, restoring the privilege npm was trying to drop.",
    "Remove --unsafe-perm and ensure the install runs under a non-root user.",
)
RULE_NPM_INSTALL_NO_LOCK = DockerfileRule(
    "df-npm-no-lock", "low",
    "npm install instead of npm ci",
    "{cmd}. npm install can pull new versions that don't match the "
    "lockfile, breaking reproducibility.",
    "Use `npm ci` (or `pnpm install --frozen-lockfile`).",
)
RULE_HEALTHCHECK_MISSING = DockerfileRule(
    "df-no-healthcheck", "low",
    "Image declares no HEALTHCHECK",
    "No HEALTHCHECK instruction. Orchestrators cannot detect a hung "
    "process.",
    "Add a HEALTHCHECK appropriate to the workload.",
    "CIS-Docker 4.6",
)
RULE_MAINTAINER = DockerfileRule(
    "df-maintainer-deprecated", "info",
    "MAINTAINER directive is deprecated",
    "MAINTAINER {who}. Replace with LABEL maintainer.",
    "Use `LABEL maintainer=\"...\"` instead.",
)
RULE_SUDO_INSTALL = DockerfileRule(
    "df-sudo-installed", "low",
    "Image installs sudo",
    "{cmd}. sudo inside a container is almost always wrong - it allows "
    "an attacker who lands shell to become a different user, potentially "
    "root.",
    "Run the process directly under the desired UID; don't install sudo.",
)
RULE_CHMOD_777 = DockerfileRule(
    "df-chmod-777", "medium",
    "World-writable chmod (777 / a+w) in build",
    "{cmd}. World-writable files allow any process inside the container "
    "to overwrite them.",
    "Use the minimum mode required (commonly 750 / 755).",
)
RULE_SECRET_IN_ENV = DockerfileRule(
    "df-secret-in-env", "high",
    "Secret-shaped value in ENV",
    "ENV {key}=... appears to set a credential. Anyone with `docker "
    "history` can read it; the layer is also published to any registry.",
    "Pass secrets via build-time --secret mounts or runtime env vars; "
    "never bake them into a layer.",
    "CIS-Docker 4.10",
)
RULE_SECRET_IN_ARG = DockerfileRule(
    "df-secret-in-arg", "high",
    "Secret-shaped value as ARG default",
    "ARG {key} carries a credential as a build-arg default. Build args "
    "are visible in `docker history` and to anyone running --build-arg "
    "with --no-cache.",
    "Use BuildKit secrets (--mount=type=secret); never set a credential "
    "as an ARG default.",
    "CIS-Docker 4.10",
)
RULE_EXPOSE_SENSITIVE = DockerfileRule(
    "df-expose-sensitive", "medium",
    "EXPOSE on a sensitive port",
    "EXPOSE {port}. Even though EXPOSE is documentary, advertising "
    "{port_name} suggests this image hosts a service that is rarely safe "
    "to expose without strong network controls.",
    "Verify the port is intentional and document the access controls "
    "around it.",
)
RULE_RUN_SSH = DockerfileRule(
    "df-ssh-installed", "high",
    "Image installs / runs SSH server",
    "{cmd}. SSH inside a container is almost always wrong - it bypasses "
    "the orchestrator's access controls.",
    "Use `kubectl exec` / `docker exec` for management; remove the SSH "
    "server.",
    "CIS-Docker 4.2",
)
RULE_PRIVILEGED_CMD = DockerfileRule(
    "df-cap-add-shell", "low",
    "RUN sets capabilities at install time",
    "{cmd}. Setting capabilities inside RUN cannot be enforced at runtime "
    "by the orchestrator; it's at best documentation.",
    "Use the orchestrator's securityContext / docker run --cap-add to "
    "scope capabilities.",
)


def _check_image_ref(image_raw: str, file: Path, line: int, repo: str
                     ) -> list[Finding]:
    out: list[Finding] = []
    ref = parse_image_ref(image_raw)
    if not ref.is_digest_pinned:
        out.append(_finding(RULE_NOT_DIGEST_PINNED, file, line, repo,
                            image=image_raw))
    if ref.is_latest and "@" not in image_raw:
        out.append(_finding(RULE_LATEST_TAG, file, line, repo,
                            image=image_raw))
    elif ref.tag == "" and not ref.is_digest_pinned:
        out.append(_finding(RULE_NO_TAG, file, line, repo, image=image_raw))
    elif (ref.tag and re.match(r"^\d+$", ref.tag)
          and not ref.is_digest_pinned):
        out.append(_finding(RULE_FLOATING_MAJOR, file, line, repo,
                            image=image_raw))
    return out


def analyze_dockerfile(pd: ParsedDockerfile, repo: str) -> list[Finding]:
    """Run every rule against the parsed Dockerfile and return Findings."""
    out: list[Finding] = []
    if not pd.stages:
        return out

    for stage in pd.stages:
        out.extend(_check_image_ref(stage.base_image_raw, pd.file,
                                    stage.line_start, repo))

    final_stage = pd.stages[-1]

    # USER analysis on final stage only.
    final_users = [i for i in final_stage.instructions if i.cmd == "USER"]
    if not final_users:
        # Walk EARLIER stages to find inherited USER from a base image
        # we can't introspect; emit the missing-USER finding.
        out.append(_finding(RULE_USER_ROOT, pd.file, final_stage.line_start,
                            repo, file=pd.file.name))
    else:
        # Last USER directive controls the final state.
        last = final_users[-1]
        u = last.args.split()[0].strip().strip('"').strip("'")
        if u in ("root", "0", "0:0"):
            out.append(_finding(RULE_USER_EXPLICIT_ROOT, pd.file,
                                last.line, repo))

    # HEALTHCHECK on final stage only.
    if not any(i.cmd == "HEALTHCHECK" for i in final_stage.instructions):
        out.append(_finding(RULE_HEALTHCHECK_MISSING, pd.file,
                            final_stage.line_start, repo))

    # Walk every instruction across all stages for the per-instruction rules.
    for stage in pd.stages:
        for ins in stage.instructions:
            args = ins.args
            args_lower = args.lower()

            if ins.cmd == "MAINTAINER":
                out.append(_finding(RULE_MAINTAINER, pd.file, ins.line, repo,
                                    who=args.strip()))
            if ins.cmd == "ADD":
                # If first arg is a URL → ADD-remote
                first = args.split()[0] if args.split() else ""
                if first.startswith(("http://", "https://", "ftp://")):
                    out.append(_finding(RULE_ADD_REMOTE, pd.file, ins.line,
                                        repo, url=first))
            if ins.cmd == "RUN":
                if re.search(
                    r"\b(curl|wget|fetch)\b[^|;]{1,300}\|\s*"
                    r"(bash|sh|zsh|cmd|powershell|pwsh|python|node)\b",
                    args, re.IGNORECASE,
                ):
                    out.append(_finding(RULE_CURL_PIPE_SH, pd.file, ins.line,
                                        repo))
                if "apt-get install" in args_lower \
                   and "--no-install-recommends" not in args_lower:
                    out.append(_finding(RULE_PKG_NO_NO_RECOMMENDS, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if "apt-get install" in args_lower \
                   and "rm -rf /var/lib/apt/lists" not in args_lower:
                    out.append(_finding(RULE_APT_NO_CLEANUP, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if re.search(r"\bapt-get\s+(?:dist-)?upgrade\b", args_lower):
                    out.append(_finding(RULE_APT_GET_UPGRADE, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if "--trusted-host" in args_lower:
                    out.append(_finding(RULE_PIP_TRUSTED_HOST, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if re.search(r"--index-url\s+http://", args_lower):
                    out.append(_finding(RULE_PIP_INSECURE, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if "--unsafe-perm" in args_lower:
                    out.append(_finding(RULE_NPM_UNSAFE_PERM, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if re.search(r"\bnpm\s+install\b", args_lower) \
                   and "npm ci" not in args_lower:
                    out.append(_finding(RULE_NPM_INSTALL_NO_LOCK, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if re.search(r"\b(apt|apt-get|yum|apk|dnf|microdnf)\s+"
                             r"install\b[^&;|\n]*\bsudo\b", args_lower):
                    out.append(_finding(RULE_SUDO_INSTALL, pd.file,
                                        ins.line, repo, cmd=args[:160]))
                if re.search(r"\bchmod(?:\s+-\S+)*\s+(?:777|a\+w)\b",
                             args_lower):
                    out.append(_finding(RULE_CHMOD_777, pd.file, ins.line,
                                        repo, cmd=args[:160]))
                if re.search(r"\b(?:apt|apt-get|yum|apk|dnf)\s+install\b"
                             r"[^&;|\n]*\b(openssh-server|sshd)\b",
                             args_lower):
                    out.append(_finding(RULE_RUN_SSH, pd.file, ins.line,
                                        repo, cmd=args[:160]))
                if re.search(r"setcap\s+\S+", args_lower):
                    out.append(_finding(RULE_PRIVILEGED_CMD, pd.file,
                                        ins.line, repo, cmd=args[:160]))
            if ins.cmd == "ENV":
                # ENV may be `K=V K2=V2` or `K V`
                for k, v in _split_env_args(args):
                    if _SECRET_NAME_RE.search(k) and v \
                       and not _looks_like_var_ref(v):
                        out.append(_finding(RULE_SECRET_IN_ENV, pd.file,
                                            ins.line, repo, key=k))
            if ins.cmd == "ARG":
                for piece in args.split():
                    if "=" in piece:
                        k, _, v = piece.partition("=")
                    else:
                        k, v = piece, ""
                    if _SECRET_NAME_RE.search(k) and v \
                       and not _looks_like_var_ref(v):
                        out.append(_finding(RULE_SECRET_IN_ARG, pd.file,
                                            ins.line, repo, key=k))
            if ins.cmd == "EXPOSE":
                for tok in args.split():
                    port_str = tok.split("/")[0]
                    try:
                        port = int(port_str)
                    except ValueError:
                        continue
                    if port in _SENSITIVE_PORTS:
                        port_name = _PORT_NAMES.get(port, "")
                        out.append(_finding(
                            RULE_EXPOSE_SENSITIVE, pd.file, ins.line, repo,
                            port=port, port_name=port_name or "(unknown)"
                        ))
    return out


_PORT_NAMES = {
    22: "SSH", 23: "Telnet", 135: "RPC", 137: "NetBIOS", 139: "SMB",
    445: "SMB", 1433: "MSSQL", 1521: "Oracle", 2375: "Docker daemon",
    2376: "Docker TLS", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
    5601: "Kibana", 6379: "Redis", 8086: "InfluxDB", 9092: "Kafka",
    9200: "Elasticsearch", 9300: "Elasticsearch", 11211: "Memcached",
    27017: "MongoDB",
}


def _split_env_args(args: str) -> list[tuple[str, str]]:
    """Split an ENV instruction's args into (key, value) pairs."""
    out: list[tuple[str, str]] = []
    s = args.strip()
    # Form 1: `K=V K2=V2 ...`
    if "=" in s and not s.startswith('"'):
        for piece in re.findall(r'([A-Za-z_][\w]*)=("(?:[^"\\]|\\.)*"|\S+)',
                                s):
            k, v = piece
            v = v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
                v = v[1:-1]
            out.append((k, v))
        if out:
            return out
    # Form 2: `K V`
    parts = s.split(None, 1)
    if len(parts) == 2:
        k, v = parts
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
            v = v[1:-1]
        return [(k, v)]
    return out


def _looks_like_var_ref(v: str) -> bool:
    """True if the value looks like a $VAR / ${VAR} reference rather than a literal."""
    s = v.strip().strip('"').strip("'")
    return bool(re.match(r"^\$\{?[A-Za-z_][\w]*\}?$", s))


# ── Discovery ───────────────────────────────────────────────────────────

def find_dockerfiles(root: Path) -> list[Path]:
    """Walk the tree for Dockerfile / Containerfile / *.Dockerfile."""
    out: list[Path] = []
    SKIP = {".git", "node_modules", "__pycache__", ".terraform"}
    import os
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP]
        for fn in filenames:
            lower = fn.lower()
            if (lower == "dockerfile"
                    or lower == "containerfile"
                    or lower.endswith(".dockerfile")
                    or lower.endswith(".containerfile")):
                out.append(Path(dirpath) / fn)
    return out


def scan_file(path: Path, repo_name: str) -> tuple[ParsedDockerfile, list[Finding]]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ParsedDockerfile(file=path), []
    pd = parse_dockerfile(text, path)
    return pd, analyze_dockerfile(pd, repo_name)
