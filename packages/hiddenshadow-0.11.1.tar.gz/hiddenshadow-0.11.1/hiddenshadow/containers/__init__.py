"""Container security scanning: Dockerfile + compose + OCI image layers.

Public API
----------
:func:`scan_path` walks a directory for Dockerfiles, Containerfiles, and
docker-compose YAML, runs static rules against each, optionally pulls the
referenced base images from public registries, walks their layers, extracts
installed OS packages (dpkg / apk), and chains the result into OSV CVE
queries.

Outputs flow through :class:`hiddenshadow.findings.Finding` with
``category="container"`` and ``method="container:<source>:<rule_id>"``.
"""
from __future__ import annotations

from .scanner import (
    ContainerFinding,
    scan_path,
    scan_path_as_findings,
)

__all__ = ["ContainerFinding", "scan_path", "scan_path_as_findings"]
