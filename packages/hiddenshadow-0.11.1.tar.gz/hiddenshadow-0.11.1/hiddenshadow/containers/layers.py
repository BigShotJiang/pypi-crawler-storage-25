"""Walk OCI image layers, extract OS package metadata.

For each layer (a gzipped tar) we look inside for the well-known
package-database files used by the major distros:

    Debian / Ubuntu : ``var/lib/dpkg/status``
    Alpine          : ``lib/apk/db/installed``
    OS detection    : ``etc/os-release`` or ``usr/lib/os-release``

We also honor *whiteouts* (``.wh.<name>`` and ``.wh..wh..opq``) so
files removed in a later layer don't show as still-present.

Returned :class:`Package` records carry the OSV ecosystem field already
filled in so the CVE step can query directly.
"""
from __future__ import annotations

import gzip
import io
import re
import tarfile
from dataclasses import dataclass, field
from typing import Iterable

from . import registry as reg


@dataclass
class Package:
    name: str
    version: str
    architecture: str = ""
    ecosystem: str = ""        # 'Debian', 'Ubuntu', 'Alpine'
    layer_digest: str = ""     # the layer it appeared in (latest wins)


@dataclass
class ImageContents:
    image_ref: str
    manifest_digest: str
    distro: str = ""           # 'debian', 'ubuntu', 'alpine', ...
    distro_version: str = ""
    packages: list[Package] = field(default_factory=list)
    layer_count: int = 0
    bytes_downloaded: int = 0
    skipped_layers: int = 0    # over size cap or unsupported media type
    notes: list[str] = field(default_factory=list)


# ── dpkg parsing ────────────────────────────────────────────────────────

def parse_dpkg_status(text: str) -> list[Package]:
    """Parse a Debian/Ubuntu /var/lib/dpkg/status file."""
    out: list[Package] = []
    for entry in re.split(r"\n\n+", text):
        if not entry.strip():
            continue
        fields: dict[str, str] = {}
        cur_key = None
        for line in entry.splitlines():
            if line.startswith((" ", "\t")) and cur_key:
                fields[cur_key] += "\n" + line.strip()
                continue
            if ":" in line:
                k, _, v = line.partition(":")
                cur_key = k.strip()
                fields[cur_key] = v.strip()
        # Some packages are 'deinstall'/'config-files' - skip not-installed.
        status = fields.get("Status", "")
        if "installed" not in status.split():
            continue
        name = fields.get("Package", "")
        version = fields.get("Version", "")
        arch = fields.get("Architecture", "")
        if name and version:
            out.append(Package(name=name, version=version, architecture=arch))
    return out


# ── apk parsing ─────────────────────────────────────────────────────────

def parse_apk_installed(text: str) -> list[Package]:
    """Parse Alpine's /lib/apk/db/installed format.

    Format is record-per-package, fields are 'X:value' where X is a
    one-letter key (P=name, V=version, A=arch, etc.). Records are
    separated by blank lines.
    """
    out: list[Package] = []
    for entry in re.split(r"\n\n+", text):
        name = ""
        version = ""
        arch = ""
        for line in entry.splitlines():
            if len(line) < 2 or line[1] != ":":
                continue
            k = line[0]
            v = line[2:].strip()
            if k == "P":
                name = v
            elif k == "V":
                version = v
            elif k == "A":
                arch = v
        if name and version:
            out.append(Package(name=name, version=version, architecture=arch))
    return out


# ── OS / distro detection from os-release ──────────────────────────────

_OS_RELEASE_KV_RE = re.compile(r'^([A-Za-z_][\w]*)=(.*)$')


def parse_os_release(text: str) -> tuple[str, str]:
    """Return (id, version_id) from the contents of /etc/os-release."""
    id_ = ""
    ver = ""
    for line in text.splitlines():
        m = _OS_RELEASE_KV_RE.match(line.strip())
        if not m:
            continue
        k, v = m.group(1), m.group(2).strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
            v = v[1:-1]
        if k == "ID":
            id_ = v.lower()
        elif k == "VERSION_ID":
            ver = v
    return id_, ver


def distro_to_ecosystem(distro_id: str) -> str:
    """Map os-release ID to OSV ecosystem name."""
    if distro_id in ("debian",):
        return "Debian"
    if distro_id in ("ubuntu",):
        return "Ubuntu"
    if distro_id in ("alpine",):
        return "Alpine"
    if distro_id in ("rhel", "centos", "almalinux", "rocky", "fedora",
                     "oracle"):
        return "Red Hat"
    return ""


# ── Tar walking with whiteout handling ─────────────────────────────────

# Files we extract from each layer.
_INTEREST_FILES = (
    "var/lib/dpkg/status",
    "lib/apk/db/installed",
    "etc/os-release",
    "usr/lib/os-release",
)


def _normalize(p: str) -> str:
    """Normalize a tar member name (strip leading ./ and /)."""
    return p.lstrip("./").lstrip("/")


def _walk_layer_blob(blob: bytes
                     ) -> tuple[dict[str, bytes], set[str]]:
    """Extract interesting files + whiteout markers from a single layer.

    Returns (files-by-path, whiteout-paths).
    """
    files: dict[str, bytes] = {}
    whiteouts: set[str] = set()
    try:
        gz_or_tar = io.BytesIO(blob)
        if blob[:2] == b"\x1f\x8b":
            gz_or_tar = io.BytesIO(gzip.decompress(blob))
        with tarfile.open(fileobj=gz_or_tar, mode="r:") as tf:
            for member in tf:
                name = _normalize(member.name)
                base = name.rsplit("/", 1)[-1]
                # Whiteout markers
                if base.startswith(".wh."):
                    if base == ".wh..wh..opq":
                        # opaque-dir whiteout: drop everything beneath
                        whiteouts.add(name.rsplit("/", 1)[0] + "/*")
                    else:
                        target = name[:-len(base)] + base[len(".wh."):]
                        whiteouts.add(target)
                    continue
                if name in _INTEREST_FILES and member.isfile():
                    f = tf.extractfile(member)
                    if f is not None:
                        try:
                            files[name] = f.read()
                        except Exception:  # pragma: no cover
                            pass
    except (tarfile.TarError, OSError, EOFError, gzip.BadGzipFile):
        return {}, set()
    return files, whiteouts


def extract_image(image_ref) -> ImageContents:
    """Pull the image's manifest, walk all layers, return its installed
    package list. ``image_ref`` is a
    :class:`hiddenshadow.containers.dockerfile.ImageRef`.
    """
    manifest = reg.fetch_manifest(image_ref)
    contents = ImageContents(
        image_ref=image_ref.raw,
        manifest_digest=manifest.digest,
        layer_count=len(manifest.layers),
    )

    # Walk layers in order, applying whiteouts. Last writer wins for
    # interesting files.
    accumulated: dict[str, tuple[str, bytes]] = {}  # path -> (layer_digest, bytes)
    suppressed: set[str] = set()
    for L in manifest.layers:
        if L.size > 80 * 1024 * 1024:  # 80 MB per-layer cap
            contents.skipped_layers += 1
            contents.notes.append(
                f"Skipped layer {L.digest[:18]} (size {L.size} > cap)")
            continue
        try:
            blob = reg.fetch_blob(image_ref.registry, image_ref.repository,
                                  L.digest, max_size=100 * 1024 * 1024)
        except reg.RegistryError as e:
            contents.notes.append(f"Layer {L.digest[:18]} fetch failed: {e}")
            continue
        contents.bytes_downloaded += len(blob)
        files, whiteouts = _walk_layer_blob(blob)
        for w in whiteouts:
            if w.endswith("/*"):
                prefix = w[:-1]
                accumulated = {p: v for p, v in accumulated.items()
                               if not p.startswith(prefix)}
                suppressed.add(prefix)
            else:
                accumulated.pop(w, None)
                suppressed.add(w)
        for path, body in files.items():
            if path in suppressed and path not in files:
                continue
            accumulated[path] = (L.digest, body)

    # Distro detection
    for path in ("etc/os-release", "usr/lib/os-release"):
        if path in accumulated:
            text = accumulated[path][1].decode("utf-8", errors="replace")
            distro, ver = parse_os_release(text)
            if distro:
                contents.distro = distro
                contents.distro_version = ver
                break

    # Package extraction
    if "var/lib/dpkg/status" in accumulated:
        layer, body = accumulated["var/lib/dpkg/status"]
        text = body.decode("utf-8", errors="replace")
        eco = distro_to_ecosystem(contents.distro) or "Debian"
        for p in parse_dpkg_status(text):
            p.ecosystem = eco
            p.layer_digest = layer
            contents.packages.append(p)
    elif "lib/apk/db/installed" in accumulated:
        layer, body = accumulated["lib/apk/db/installed"]
        text = body.decode("utf-8", errors="replace")
        for p in parse_apk_installed(text):
            p.ecosystem = "Alpine"
            p.layer_digest = layer
            contents.packages.append(p)

    return contents
