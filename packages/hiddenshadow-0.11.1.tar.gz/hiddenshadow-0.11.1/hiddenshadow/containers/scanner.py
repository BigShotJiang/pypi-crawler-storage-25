"""Container-scan orchestrator: walk repo, run static rules, optionally
walk image layers and chain OS packages into OSV CVE queries.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterable

from ..findings import Finding
from ..network import CachedHttp
from . import compose as compose_mod
from . import dockerfile as df_mod
from . import layers as layers_mod
from . import registry as reg


@dataclass
class ContainerFinding:
    """The scanner's native finding type, richer than Finding for the
    dedicated containerscan-findings.json output."""
    repo: str
    source: str                  # 'dockerfile' | 'compose' | 'image'
    severity: str
    rule_id: str
    title: str
    detail: str
    recommendation: str
    location: str                # file:line or image ref
    image: str = ""
    package: str = ""
    package_version: str = ""
    cve_id: str = ""
    references: str = ""

    def to_finding(self) -> Finding:
        return Finding(
            repo=self.repo,
            severity=self.severity,
            category="container",
            title=self.title,
            location=self.location,
            detail=self.detail,
            recommendation=self.recommendation,
            method=f"container:{self.source}:{self.rule_id}",
        )


def _finding_to_container(repo: str, source: str, f: Finding,
                          rule_id_fallback: str = "") -> ContainerFinding:
    rid = f.method.rsplit(":", 1)[-1] if f.method else rule_id_fallback
    return ContainerFinding(
        repo=repo,
        source=source,
        severity=f.severity,
        rule_id=rid,
        title=f.title,
        detail=f.detail,
        recommendation=f.recommendation,
        location=f.location,
    )


def scan_path(root: Path, repo_name: str = "(local)",
              *,
              scan_layers: bool = True,
              cve_lookup: bool = True,
              cache_dir: Path | None = None,
              max_image_size_mb: int = 500,
              ) -> list[ContainerFinding]:
    """Run the full container scan over ``root``.

    * Always runs Dockerfile + compose static rules (offline).
    * If ``scan_layers`` is True, resolves each FROM image and walks
      its OCI layers to extract installed OS packages.
    * If ``cve_lookup`` is True, queries OSV.dev for each extracted
      package and emits a Finding per vulnerability.
    """
    out: list[ContainerFinding] = []

    # ── Dockerfile rules ──
    df_paths = df_mod.find_dockerfiles(root)
    parsed_dfs: list[df_mod.ParsedDockerfile] = []
    for p in df_paths:
        pd, fs = df_mod.scan_file(p, repo_name)
        parsed_dfs.append(pd)
        for f in fs:
            out.append(_finding_to_container(repo_name, "dockerfile", f))

    # ── Compose rules ──
    for cp in compose_mod.find_compose_files(root):
        for f in compose_mod.scan_compose_file(cp, repo_name):
            out.append(_finding_to_container(repo_name, "compose", f))

    if not scan_layers:
        return out

    # ── Image layer scan ──
    seen_images: set[str] = set()
    for pd in parsed_dfs:
        for stage in pd.stages:
            ref_str = stage.base_image
            # Skip stage-name FROMs (like 'FROM build AS final').
            if ref_str in {s.name for s in pd.stages if s.name}:
                continue
            if not ref_str or ref_str in seen_images:
                continue
            seen_images.add(ref_str)
            ref = df_mod.parse_image_ref(ref_str)
            try:
                contents = layers_mod.extract_image(ref)
            except reg.RegistryAuthError as e:
                out.append(ContainerFinding(
                    repo=repo_name, source="image", severity="info",
                    rule_id="image-auth-required",
                    title=f"Image requires auth: {ref_str}",
                    detail=f"Could not pull image manifest: {e}",
                    recommendation=("Authenticate to the registry "
                                    "manually or skip --scan-layers."),
                    location=f"{pd.file.name}:{stage.line_start}",
                    image=ref_str,
                ))
                continue
            except reg.RegistryNotFoundError as e:
                out.append(ContainerFinding(
                    repo=repo_name, source="image", severity="medium",
                    rule_id="image-not-found",
                    title=f"Base image not found: {ref_str}",
                    detail=str(e),
                    recommendation=("Verify the image reference. The "
                                    "image may have been deleted, renamed, "
                                    "or made private."),
                    location=f"{pd.file.name}:{stage.line_start}",
                    image=ref_str,
                ))
                continue
            except reg.RegistryError as e:
                out.append(ContainerFinding(
                    repo=repo_name, source="image", severity="info",
                    rule_id="image-fetch-error",
                    title=f"Image fetch failed: {ref_str}",
                    detail=str(e),
                    recommendation="Re-run with network access; check the registry.",
                    location=f"{pd.file.name}:{stage.line_start}",
                    image=ref_str,
                ))
                continue

            if not contents.distro and contents.packages:
                contents.distro = "(unknown)"

            if not contents.packages:
                out.append(ContainerFinding(
                    repo=repo_name, source="image", severity="info",
                    rule_id="image-no-packages",
                    title=f"No OS package DB found in image {ref_str}",
                    detail=("The image's layers contained no dpkg / apk "
                            "package database. This is normal for "
                            "distroless / scratch / FROM scratch builds. "
                            f"Layers walked: {contents.layer_count}, "
                            f"skipped: {contents.skipped_layers}, "
                            f"bytes: {contents.bytes_downloaded}."),
                    recommendation=("If you expected packages, the base "
                                    "image may use rpm (not yet supported) "
                                    "or a layer may have exceeded the "
                                    "size cap."),
                    location=f"{pd.file.name}:{stage.line_start}",
                    image=ref_str,
                ))
                continue

            if not cve_lookup:
                out.append(ContainerFinding(
                    repo=repo_name, source="image", severity="info",
                    rule_id="image-packages-found",
                    title=f"Image {ref_str}: {len(contents.packages)} OS packages",
                    detail=(f"Distro {contents.distro} {contents.distro_version}; "
                            f"{len(contents.packages)} installed packages "
                            f"found in {contents.layer_count} layers."),
                    recommendation="Pass --cve-lookup to query OSV.dev for CVEs.",
                    location=f"{pd.file.name}:{stage.line_start}",
                    image=ref_str,
                ))
                continue

            cache = cache_dir or (root / "_cache")
            for cf in _query_cves_for_image(contents, repo_name, ref_str,
                                            f"{pd.file.name}:{stage.line_start}",
                                            cache):
                out.append(cf)

    return out


def _query_cves_for_image(contents: layers_mod.ImageContents,
                          repo: str, image_ref: str, location: str,
                          cache_dir: Path) -> list[ContainerFinding]:
    """Query OSV.dev for every package in the image."""
    out: list[ContainerFinding] = []
    if not contents.packages:
        return out
    http = CachedHttp(cache_dir, service="osv-container",
                      max_workers=8, request_delay_ms=80)
    items: list[tuple[str, str, dict]] = []
    item_to_pkg: dict[str, layers_mod.Package] = {}
    for pkg in contents.packages:
        if not pkg.ecosystem:
            continue
        body = {
            "package": {"name": pkg.name, "ecosystem": pkg.ecosystem},
            "version": pkg.version,
        }
        key = f"osv|{pkg.ecosystem}|{pkg.name}|{pkg.version}"
        items.append((key, "https://api.osv.dev/v1/query", body))
        item_to_pkg[key] = pkg
    if not items:
        return out
    results = http.fetch_many(items)
    for key, result in results.items():
        if result.status != 200 or not result.data:
            continue
        vulns = result.data.get("vulns") or []
        if not vulns:
            continue
        pkg = item_to_pkg[key]
        for v in vulns:
            sev = _osv_severity(v)
            cve = _pick_cve_id(v)
            summary = v.get("summary") or "(no summary)"
            refs_raw = v.get("references") or []
            refs = ", ".join(r.get("url", "") for r in refs_raw[:3])
            out.append(ContainerFinding(
                repo=repo,
                source="image",
                severity=sev,
                rule_id="cve-osv",
                title=f"CVE in image {image_ref}: {cve} ({pkg.name} {pkg.version})",
                detail=(f"{cve} - {summary} "
                        f"[ecosystem={pkg.ecosystem}, "
                        f"layer={pkg.layer_digest[:18]}...]"),
                recommendation=(f"Upgrade {pkg.name} past the affected "
                                f"version, rebuild against a patched base "
                                f"image, or pin to a known-clean digest."),
                location=location,
                image=image_ref,
                package=pkg.name,
                package_version=pkg.version,
                cve_id=cve,
                references=refs,
            ))
    return out


def _osv_severity(vuln: dict) -> str:
    """Map an OSV record's CVSS score to our severity bucket."""
    score = None
    for sev in (vuln.get("severity") or []):
        if sev.get("type", "").startswith("CVSS"):
            try:
                # Score may be a number string or full vector. Pull the
                # 'V' base score by parsing the leading number if any.
                s = sev.get("score", "")
                # If it's a vector like 'CVSS:3.1/AV:N/...' we have no
                # number; in that case fall back to db-flag below.
                if s and not s.startswith("CVSS"):
                    score = float(s)
                    break
            except (TypeError, ValueError):
                pass
    if score is None:
        # Fall back to database-specific severity field.
        db = vuln.get("database_specific") or {}
        text = (db.get("severity") or "").upper()
        if "CRITICAL" in text:
            return "critical"
        if "HIGH" in text:
            return "high"
        if "MODERATE" in text or "MEDIUM" in text:
            return "medium"
        if "LOW" in text:
            return "low"
        return "info"
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    if score >= 0.1:
        return "low"
    return "info"


def _pick_cve_id(vuln: dict) -> str:
    aliases = vuln.get("aliases") or []
    for a in aliases:
        if a.startswith("CVE-"):
            return a
    return vuln.get("id") or "(unknown)"


def scan_path_as_findings(root: Path, repo_name: str = "(local)",
                          *,
                          scan_layers: bool = False,
                          cve_lookup: bool = False,
                          cache_dir: Path | None = None,
                          ) -> list[Finding]:
    """Convenience wrapper that returns plain ``Finding`` objects ready
    to flow into the main scan stream. Defaults differ from
    :func:`scan_path` - the main scanner uses an offline-friendly
    profile (no layer fetches by default) so a `scan --detect-containers`
    won't suddenly try to pull every base image off the Internet."""
    out = scan_path(root, repo_name, scan_layers=scan_layers,
                    cve_lookup=cve_lookup, cache_dir=cache_dir)
    return [c.to_finding() for c in out]
