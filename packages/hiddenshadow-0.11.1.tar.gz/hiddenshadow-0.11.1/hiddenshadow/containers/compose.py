"""docker-compose.yml security rules.

Implements a focused YAML parser sufficient for docker-compose files (no
PyYAML dependency to keep the project stdlib-only). Compose YAML is well-
behaved: nested indented mappings, simple lists, scalar literals, and
``key: value`` pairs - we don't need anchors, aliases, flow style, or
multi-document streams.

Rules cover the most damaging compose-level mistakes:

* ``privileged: true``                          critical
* Mount of ``/var/run/docker.sock``             critical
* ``host_network`` / ``network_mode: host``      high
* ``host_pid`` / ``host_ipc`` / ``pid: host``    high
* ``cap_add: [SYS_ADMIN, NET_ADMIN, ...]``      high (specific caps elevate)
* Mount of ``/`` or ``/etc`` from host           high
* No ``user:`` directive (runs as root)         medium
* No ``read_only: true``                        low
* ``image: ...:latest``                         medium
* ``ports:`` exposing sensitive ports           medium
* ``environment:`` containing secret-shaped keys high
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..findings import Finding


# ── Tiny YAML subset parser ─────────────────────────────────────────────

@dataclass
class _Node:
    """One parsed YAML value with its source line."""
    value: Any                       # dict | list | str | bool | int | float | None
    line: int


def _parse_scalar(s: str) -> Any:
    """Parse a YAML scalar from a single line (best effort)."""
    s = s.strip()
    if not s:
        return None
    # Strip surrounding quotes if matched
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ("'", '"'):
        return s[1:-1]
    low = s.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if low in ("null", "~", ""):
        return None
    if re.match(r"^-?\d+$", s):
        try:
            return int(s)
        except ValueError:
            pass
    if re.match(r"^-?\d+\.\d+$", s):
        try:
            return float(s)
        except ValueError:
            pass
    # Strip inline comments
    in_str = False
    quote = ""
    out = []
    for c in s:
        if in_str:
            out.append(c)
            if c == quote:
                in_str = False
            continue
        if c in ("'", '"'):
            in_str = True
            quote = c
            out.append(c)
            continue
        if c == "#" and (not out or out[-1] in (" ", "\t")):
            break
        out.append(c)
    return "".join(out).rstrip()


def _indent_of(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def parse_yaml(text: str) -> _Node:
    """Parse a YAML-like document into a tree. Returns the root node."""
    raw_lines = text.split("\n")
    lines: list[tuple[int, int, str]] = []  # (line_no, indent, content)
    for i, raw in enumerate(raw_lines, start=1):
        # Drop full-line comments and blanks
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        ind = _indent_of(raw)
        content = raw[ind:].rstrip()
        lines.append((i, ind, content))

    pos = [0]

    def parse_block(min_indent: int) -> _Node:
        if pos[0] >= len(lines):
            return _Node(None, 0)
        line_no, ind, content = lines[pos[0]]
        if ind < min_indent:
            return _Node(None, line_no)
        if content.startswith("- "):
            return parse_list(ind)
        # Mapping
        return parse_map(ind)

    def parse_map(indent: int) -> _Node:
        out: dict[str, _Node] = {}
        first_line = lines[pos[0]][0] if pos[0] < len(lines) else 0
        while pos[0] < len(lines):
            line_no, ind, content = lines[pos[0]]
            if ind < indent:
                break
            if ind > indent:
                # Shouldn't happen if siblings align; treat as nested.
                break
            if content.startswith("- "):
                # Map sibling can't start with list dash at this indent.
                break
            if ":" not in content:
                # Skip unparseable line
                pos[0] += 1
                continue
            key, _, rest = content.partition(":")
            key = key.strip()
            rest = rest.strip()
            pos[0] += 1
            if rest == "":
                # Block child or empty
                child = parse_block(indent + 1)
                out[key] = child
            elif rest in ("|", "|-", "|+", ">", ">-", ">+"):
                # YAML block scalar. Collect every following line whose
                # indent exceeds the parent. We do not distinguish
                # literal-vs-folded for the scanner's purposes.
                lines_collected: list[str] = []
                base_indent: int | None = None
                while pos[0] < len(lines):
                    l2, i2, c2 = lines[pos[0]]
                    if i2 <= indent:
                        break
                    if base_indent is None:
                        base_indent = i2
                    rel = max(i2 - base_indent, 0)
                    lines_collected.append(" " * rel + c2)
                    pos[0] += 1
                out[key] = _Node("\n".join(lines_collected), line_no)
            elif rest.startswith("[") and rest.endswith("]"):
                # Inline flow list: [a, b, c]
                out[key] = _Node(_parse_flow_list(rest), line_no)
            elif rest.startswith("{") and rest.endswith("}"):
                # Inline flow map - rare in compose; degrade to scalar.
                out[key] = _Node(rest, line_no)
            else:
                out[key] = _Node(_parse_scalar(rest), line_no)
        return _Node(out, first_line or 0)

    def parse_list(indent: int) -> _Node:
        out: list[_Node] = []
        first_line = lines[pos[0]][0] if pos[0] < len(lines) else 0
        while pos[0] < len(lines):
            line_no, ind, content = lines[pos[0]]
            if ind < indent or not content.startswith("- "):
                break
            item_text = content[2:].lstrip()
            pos[0] += 1
            # Distinguish "key: value" (inline mapping) from a string
            # scalar that happens to contain a colon (e.g. a volume mount
            # like /host:/container or a port spec). A real inline-mapping
            # key is an identifier (no slashes / leading dot).
            looks_like_inline_mapping = (
                ":" in item_text
                and not item_text.startswith(("{", "/", ".", "$", '"', "'"))
                and re.match(r'^[A-Za-z_][\w-]*\s*:(\s|$)', item_text)
                is not None
            )
            if looks_like_inline_mapping:
                # Inline mapping item: "- key: value [further keys nested]"
                # Re-inject as a child-mapping starting at this line.
                key, _, rest = item_text.partition(":")
                key = key.strip()
                rest = rest.strip()
                inline_map: dict[str, _Node] = {}
                child_indent = indent + 2
                if rest in ("|", "|-", "|+", ">", ">-", ">+"):
                    # Block scalar as the first field's value.
                    bs_lines: list[str] = []
                    bs_base: int | None = None
                    while pos[0] < len(lines):
                        bl, bi, bc = lines[pos[0]]
                        if bi <= child_indent:
                            break
                        if bs_base is None:
                            bs_base = bi
                        rel = max(bi - bs_base, 0)
                        bs_lines.append(" " * rel + bc)
                        pos[0] += 1
                    inline_map[key] = _Node("\n".join(bs_lines), line_no)
                elif rest:
                    inline_map[key] = _Node(_parse_scalar(rest), line_no)
                else:
                    child = parse_block(indent + 2)
                    inline_map[key] = child
                # Continue collecting fields aligned at indent + 2
                while pos[0] < len(lines):
                    l2, i2, c2 = lines[pos[0]]
                    if i2 < child_indent:
                        break
                    if i2 > child_indent and ":" not in c2:
                        # Likely deeper structure; stop
                        break
                    if c2.startswith("- "):
                        break
                    if ":" not in c2:
                        pos[0] += 1
                        continue
                    k2, _, r2 = c2.partition(":")
                    k2 = k2.strip()
                    r2 = r2.strip()
                    pos[0] += 1
                    if r2 == "":
                        inline_map[k2] = parse_block(child_indent + 1)
                    elif r2.startswith("[") and r2.endswith("]"):
                        inline_map[k2] = _Node(_parse_flow_list(r2), l2)
                    elif r2 in ("|", "|-", "|+", ">", ">-", ">+"):
                        lines_collected: list[str] = []
                        base_indent: int | None = None
                        while pos[0] < len(lines):
                            ll, ii, cc = lines[pos[0]]
                            if ii <= child_indent:
                                break
                            if base_indent is None:
                                base_indent = ii
                            rel = max(ii - base_indent, 0)
                            lines_collected.append(" " * rel + cc)
                            pos[0] += 1
                        inline_map[k2] = _Node(
                            "\n".join(lines_collected), l2)
                    else:
                        inline_map[k2] = _Node(_parse_scalar(r2), l2)
                out.append(_Node(inline_map, line_no))
            else:
                out.append(_Node(_parse_scalar(item_text), line_no))
        return _Node(out, first_line or 0)

    return parse_block(0)


def _parse_flow_list(s: str) -> list[_Node]:
    inner = s[1:-1].strip()
    if not inner:
        return []
    out: list[_Node] = []
    for raw in _split_flow(inner, ","):
        out.append(_Node(_parse_scalar(raw), 0))
    return out


def _split_flow(s: str, sep: str) -> list[str]:
    out: list[str] = []
    buf: list[str] = []
    depth = 0
    in_str = False
    quote = ""
    for c in s:
        if in_str:
            buf.append(c)
            if c == quote:
                in_str = False
            continue
        if c in ("'", '"'):
            in_str = True
            quote = c
            buf.append(c)
            continue
        if c in "([{":
            depth += 1
            buf.append(c)
            continue
        if c in ")]}":
            depth -= 1
            buf.append(c)
            continue
        if c == sep and depth == 0:
            out.append("".join(buf).strip())
            buf = []
        else:
            buf.append(c)
    if buf:
        out.append("".join(buf).strip())
    return out


# ── Helpers to walk the parsed tree ─────────────────────────────────────

def _get(node: _Node | None, key: str) -> _Node | None:
    if node is None or not isinstance(node.value, dict):
        return None
    return node.value.get(key)


def _value(node: _Node | None) -> Any:
    return node.value if node else None


def _items(node: _Node | None) -> list:
    if node is None:
        return []
    if isinstance(node.value, list):
        return node.value
    return []


def _to_list(node: _Node | None) -> list[str]:
    """Coerce a list-shaped node into [str, ...]."""
    if node is None:
        return []
    if isinstance(node.value, list):
        return [str(_value(x) if isinstance(x, _Node) else x)
                for x in node.value]
    return []


# ── Rules ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ComposeRule:
    id: str
    severity: str
    title: str
    detail_tmpl: str
    recommendation: str


def _finding(rule: ComposeRule, file: Path, line: int, repo: str,
             service: str, **kwargs) -> Finding:
    return Finding(
        repo=repo,
        severity=rule.severity,
        category="container",
        title=f"compose service '{service}': {rule.title}",
        location=f"{file.name}:{line}",
        detail=rule.detail_tmpl.format(service=service, **kwargs),
        recommendation=rule.recommendation,
        method=f"container:compose:{rule.id}",
    )


_DANGEROUS_CAPS = {
    "SYS_ADMIN":   "high",     # near-root
    "NET_ADMIN":   "high",     # firewall manipulation
    "SYS_PTRACE":  "high",     # debugger across processes
    "SYS_MODULE":  "critical", # load kernel modules
    "DAC_READ_SEARCH": "high", # bypass file read perms
    "DAC_OVERRIDE": "medium",
    "SETUID":      "low",
    "SETGID":      "low",
    "ALL":         "critical",
}

_SECRET_NAME_RE = re.compile(
    r"(?:^|[_\-])(PASSWORD|PASSWD|SECRET|TOKEN|APIKEY|API_KEY|API-KEY|"
    r"PRIVATEKEY|PRIVATE_KEY|PRIVATE-KEY|CREDENTIAL|AUTH|"
    r"AWS_ACCESS|AWS_SECRET|AWS-ACCESS|AWS-SECRET)(?:$|[_\-])",
    re.IGNORECASE,
)

_SENSITIVE_HOST_PATHS = (
    "/", "/etc", "/etc/", "/var/lib/", "/var/run/docker.sock",
    "/proc", "/sys", "/root", "/home",
)


def analyze_service(name: str, svc: _Node, file: Path, repo: str
                    ) -> list[Finding]:
    out: list[Finding] = []
    line = svc.line if svc else 0

    if not isinstance(svc.value, dict):
        return out

    # privileged
    priv = _value(_get(svc, "privileged"))
    if priv is True:
        out.append(_finding(
            ComposeRule(
                "compose-privileged", "critical",
                "Service runs in privileged mode",
                "privileged: true on service '{service}'. The container "
                "gets all capabilities and is effectively root on the host.",
                "Remove privileged: true and grant the minimum capabilities "
                "the workload needs via cap_add.",
            ), file, _get(svc, "privileged").line, repo, service=name))

    # network_mode: host / host_network
    net = _value(_get(svc, "network_mode"))
    if net == "host":
        out.append(_finding(
            ComposeRule(
                "compose-network-host", "high",
                "Service uses host networking",
                "network_mode: host on '{service}'. The container shares "
                "the host's network namespace - no port isolation, no NAT.",
                "Use bridged networking and expose only the required ports.",
            ), file, _get(svc, "network_mode").line, repo, service=name))

    # pid / ipc host
    for ns_key, sev in (("pid", "high"), ("ipc", "medium")):
        v = _value(_get(svc, ns_key))
        if v == "host":
            out.append(_finding(
                ComposeRule(
                    f"compose-{ns_key}-host", sev,
                    f"Service shares host {ns_key.upper()} namespace",
                    f"{ns_key}: host on '{{service}}'. Container processes "
                    f"share the host's {ns_key.upper()} namespace.",
                    f"Remove the '{ns_key}: host' setting.",
                ), file, _get(svc, ns_key).line, repo, service=name))

    # cap_add
    for cap in _to_list(_get(svc, "cap_add")):
        cap_norm = cap.upper().replace("CAP_", "")
        sev = _DANGEROUS_CAPS.get(cap_norm)
        if sev:
            out.append(_finding(
                ComposeRule(
                    "compose-cap-add", sev,
                    f"Service adds dangerous capability {cap_norm}",
                    f"cap_add includes {cap_norm} on '{{service}}'. This "
                    f"capability is rarely needed by application workloads.",
                    "Drop the capability or replace with a narrower set.",
                ), file, line, repo, service=name))

    # volumes - sensitive host paths and Docker socket
    for v_node in _items(_get(svc, "volumes")):
        v = _value(v_node) if isinstance(v_node, _Node) else v_node
        if not isinstance(v, str):
            continue
        host, _, _ = v.partition(":")
        host = host.strip()
        if host == "/var/run/docker.sock":
            out.append(_finding(
                ComposeRule(
                    "compose-docker-sock", "critical",
                    "Service mounts the Docker socket",
                    "Mount of {host} on '{{service}}'. Anything in the "
                    "container can control the Docker daemon, which is "
                    "equivalent to root on the host.",
                    "Don't mount the Docker socket. If you need to launch "
                    "containers, use a separate orchestrator with scoped "
                    "credentials.",
                ), file, v_node.line if isinstance(v_node, _Node) else line,
                repo, service=name, host=host))
        elif host in _SENSITIVE_HOST_PATHS:
            out.append(_finding(
                ComposeRule(
                    "compose-host-mount", "high",
                    f"Service mounts sensitive host path {host}",
                    f"Volume mount of {host} on '{{service}}'.",
                    "Mount only the specific subdirectory the workload "
                    "requires; never mount /, /etc, /proc, /sys, or /var/lib.",
                ), file, v_node.line if isinstance(v_node, _Node) else line,
                repo, service=name))

    # user
    if _get(svc, "user") is None and priv is not True:
        out.append(_finding(
            ComposeRule(
                "compose-no-user", "medium",
                "Service has no explicit user (runs as root)",
                "No 'user:' directive on '{service}'. The container runs "
                "as the image's default user, which is usually root.",
                "Add `user: \"1001:1001\"` (or another non-root UID).",
            ), file, line, repo, service=name))

    # read_only
    ro = _value(_get(svc, "read_only"))
    if ro is not True and priv is not True:
        out.append(_finding(
            ComposeRule(
                "compose-no-readonly", "low",
                "Service does not enable a read-only root filesystem",
                "read_only is not true on '{service}'.",
                "Set `read_only: true`; mount tmpfs for any required "
                "writable paths.",
            ), file, line, repo, service=name))

    # image: latest
    img = _value(_get(svc, "image"))
    if isinstance(img, str):
        if img.endswith(":latest") or ":" not in img.rsplit("/", 1)[-1]:
            out.append(_finding(
                ComposeRule(
                    "compose-image-latest", "medium",
                    "Service uses :latest (or no) image tag",
                    "Service '{service}' references image '{image}'. The "
                    "tag is mutable and not reproducible.",
                    "Pin the tag and (best) the digest.",
                ), file, _get(svc, "image").line, repo,
                service=name, image=img))

    # ports - sensitive port exposure
    for p_node in _items(_get(svc, "ports")):
        p = _value(p_node) if isinstance(p_node, _Node) else p_node
        port_str = ""
        if isinstance(p, str):
            # Forms: "8080", "8080:80", "127.0.0.1:8080:80", "8080:80/tcp"
            tail = p.split(":")[-1].split("/")[0]
            port_str = tail
        elif isinstance(p, int):
            port_str = str(p)
        try:
            port = int(port_str)
        except (TypeError, ValueError):
            continue
        from .dockerfile import _SENSITIVE_PORTS, _PORT_NAMES
        if port in _SENSITIVE_PORTS:
            out.append(_finding(
                ComposeRule(
                    "compose-expose-sensitive", "medium",
                    f"Service exposes sensitive port {port}",
                    f"Port {port} ({_PORT_NAMES.get(port, '?')}) is exposed "
                    f"on '{{service}}'.",
                    "Confirm the exposure is intentional and the upstream "
                    "service is hardened (auth, TLS, no defaults).",
                ), file, p_node.line if isinstance(p_node, _Node) else line,
                repo, service=name))

    # environment - secret-shaped names
    env_node = _get(svc, "environment")
    env_pairs: list[tuple[str, str, int]] = []
    if env_node is not None:
        if isinstance(env_node.value, dict):
            for k, vn in env_node.value.items():
                v = _value(vn) if isinstance(vn, _Node) else vn
                env_pairs.append((str(k), str(v) if v is not None else "",
                                  vn.line if isinstance(vn, _Node) else line))
        elif isinstance(env_node.value, list):
            for item in env_node.value:
                v = _value(item) if isinstance(item, _Node) else item
                if isinstance(v, str) and "=" in v:
                    k, _, val = v.partition("=")
                    env_pairs.append((k.strip(), val.strip(),
                                      item.line if isinstance(item, _Node) else line))
    for k, v, ln in env_pairs:
        if not _SECRET_NAME_RE.search(k):
            continue
        if not v or v.startswith("$") or v.startswith("${"):
            continue  # values via env var indirection are OK
        out.append(_finding(
            ComposeRule(
                "compose-secret-env", "high",
                "Service environment carries a secret-shaped value",
                "environment.{key} on '{service}' is set to a literal value. "
                "Secrets in compose files end up in version control.",
                "Reference an external secret store; never inline.",
            ), file, ln, repo, service=name, key=k))

    return out


# ── File discovery + scan ───────────────────────────────────────────────

def find_compose_files(root: Path) -> list[Path]:
    out: list[Path] = []
    SKIP = {".git", "node_modules", "__pycache__", ".terraform"}
    import os
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP]
        for fn in filenames:
            lower = fn.lower()
            if (lower in ("docker-compose.yml", "docker-compose.yaml",
                          "compose.yml", "compose.yaml")
                    or lower.startswith("docker-compose.")
                    and (lower.endswith(".yml") or lower.endswith(".yaml"))):
                out.append(Path(dirpath) / fn)
    return out


def scan_compose_file(path: Path, repo_name: str) -> list[Finding]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    root = parse_yaml(text)
    services = _get(root, "services")
    out: list[Finding] = []
    if services is None or not isinstance(services.value, dict):
        return out
    for name, svc in services.value.items():
        out.extend(analyze_service(str(name), svc, path, repo_name))
    return out
