"""SARIF 2.1.0 output formatter for HiddenShadow findings.

SARIF (Static Analysis Results Interchange Format) is the format
GitHub's *Security* / *Code scanning* tab consumes natively. Producing
SARIF means findings show up inline on PRs and in the repo's security
dashboard without any glue code.

Reference: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

from .findings import Finding


_SARIF_VERSION = "2.1.0"
_SARIF_SCHEMA = (
    "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/"
    "Documents/CommitteeSpecifications/2.1.0/sarif-schema-2.1.0.json"
)

# Severity → SARIF level. SARIF level is one of: none, note, warning, error.
_SEV_TO_LEVEL = {
    "critical": "error",
    "high":     "error",
    "medium":   "warning",
    "low":      "note",
    "info":     "note",
}
# Severity → SARIF security-severity (CVSS-like 0-10 scale used by
# GitHub for security-tab severity display).
_SEV_TO_SECURITY_SEVERITY = {
    "critical": "9.5",
    "high":     "7.5",
    "medium":   "5.0",
    "low":      "3.0",
    "info":     "1.0",
}


# Location strings in our Findings vary by category. Common shapes:
#   "Dockerfile:12"
#   "main.tf:42 (aws_s3_bucket.logs)"
#   "package.json#scripts.postinstall"
#   "(rollup)"
#   "(repo root)"
_LOC_LINE_RE = re.compile(r"^(?P<file>[^:\n]+):(?P<line>\d+)")


def _parse_location(loc: str, source_root: Path) -> tuple[str, int]:
    """Return (uri, startLine) — both are best-effort, SARIF accepts ''/0."""
    if not loc:
        return "", 0
    m = _LOC_LINE_RE.match(loc)
    if not m:
        # Locations like "package.json#scripts.postinstall" or
        # "(rollup)" → best we can do is the file portion if any.
        file_part = loc.split("#", 1)[0].split(" ", 1)[0]
        if file_part and not file_part.startswith("("):
            return _make_uri(file_part, source_root), 0
        return "", 0
    file = m.group("file")
    try:
        line = int(m.group("line"))
    except ValueError:
        line = 0
    return _make_uri(file, source_root), line


def _make_uri(path: str, source_root: Path) -> str:
    """Build a relative URI from a source path."""
    p = Path(path)
    if p.is_absolute():
        try:
            return p.relative_to(source_root).as_posix()
        except ValueError:
            return p.as_posix()
    return p.as_posix()


def _rule_for(method: str, finding: Finding) -> tuple[str, dict[str, Any]]:
    """Build a SARIF rule descriptor keyed off the finding's method string.

    Returns (rule_id, rule_object). Multiple findings sharing a method
    map to the same rule so the SARIF rules[] array stays compact.
    """
    rid = method or f"{finding.category}:rule"
    return rid, {
        "id": rid,
        "name": rid.replace(":", "_"),
        "shortDescription": {"text": finding.title or rid},
        "fullDescription": {
            "text": (finding.recommendation or finding.title or rid)[:600]
        },
        "helpUri": "",
        "defaultConfiguration": {
            "level": _SEV_TO_LEVEL.get(finding.severity, "warning"),
        },
        "properties": {
            "category": finding.category,
            "security-severity": _SEV_TO_SECURITY_SEVERITY.get(
                finding.severity, "5.0"),
            "tags": [finding.category, "security"],
        },
    }


def findings_to_sarif(findings: Iterable[Finding], *,
                      tool_name: str = "HiddenShadow",
                      tool_version: str = "",
                      source_root: Path | None = None,
                      ) -> dict[str, Any]:
    """Build a SARIF 2.1.0 log document from a Finding iterable.

    The resulting dict can be ``json.dumps``-ed directly.
    """
    src = source_root or Path.cwd()
    findings = list(findings)

    # Build the per-rule descriptor map (one rule per distinct method).
    rules_by_id: dict[str, dict[str, Any]] = {}
    for f in findings:
        rid, r = _rule_for(f.method, f)
        if rid not in rules_by_id:
            rules_by_id[rid] = r

    rules_list = list(rules_by_id.values())
    rule_id_to_index = {r["id"]: i for i, r in enumerate(rules_list)}

    results: list[dict[str, Any]] = []
    for f in findings:
        uri, line = _parse_location(f.location or "", src)
        rid, _ = _rule_for(f.method, f)
        res: dict[str, Any] = {
            "ruleId": rid,
            "ruleIndex": rule_id_to_index.get(rid, 0),
            "level": _SEV_TO_LEVEL.get(f.severity, "warning"),
            "message": {
                "text": f"{f.title}\n\n{f.detail}".strip(),
            },
            "properties": {
                "severity": f.severity,
                "repo": f.repo,
                "category": f.category,
                "recommendation": f.recommendation,
                "security-severity": _SEV_TO_SECURITY_SEVERITY.get(
                    f.severity, "5.0"),
            },
        }
        if uri or line:
            loc: dict[str, Any] = {
                "physicalLocation": {
                    "artifactLocation": {"uri": uri or "(unknown)"},
                }
            }
            if line > 0:
                loc["physicalLocation"]["region"] = {"startLine": line}
            res["locations"] = [loc]
        results.append(res)

    return {
        "$schema": _SARIF_SCHEMA,
        "version": _SARIF_VERSION,
        "runs": [{
            "tool": {
                "driver": {
                    "name": tool_name,
                    "version": tool_version,
                    "informationUri": "https://github.com/DarkShadowSecurity/hiddenshadow",
                    "rules": rules_list,
                }
            },
            "results": results,
            "columnKind": "utf16CodeUnits",
        }],
    }


def write_sarif(findings: Iterable[Finding], out_path: Path, *,
                tool_name: str = "HiddenShadow",
                tool_version: str = "",
                source_root: Path | None = None) -> Path:
    doc = findings_to_sarif(findings, tool_name=tool_name,
                            tool_version=tool_version,
                            source_root=source_root)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    return out_path
