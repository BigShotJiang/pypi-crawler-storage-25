"""Dual-license detection — recognize when a directory ships under
multiple licenses simultaneously.

Three patterns we detect:

  1. **Sibling LICENSE files** — a directory contains both `LICENSE`
     and `COPYING` (or `LICENSE.BSD` + `LICENSE.MPL-2.0`, or
     `LICENSE.txt` + `COPYING.txt`, etc.) with DIFFERENT licenses.
     The classic "user picks one" pattern (zstd, OpenJDK, many others).

  2. **SPDX-expression marker file** — a `COPYING.md`, `LICENSE.md`,
     or `LICENSE` file that declares an SPDX expression like
     `BSD-3-Clause AND MPL-2.0` or `Apache-2.0 OR GPL-2.0`.

  3. **Per-file dual-licensing** — files declare their license via
     SPDX-License-Identifier comments; the project as a whole has no
     single license. This is detected from the COPYING.md narrative
     pattern.

When any of these patterns is detected for a directory, the analyzer
demotes findings inside that directory:
  - HIGH ("non-permissive license inside repo") → INFO with a
    note that the directory is dual-licensed
  - MEDIUM ("weak-copyleft license inside repo") → INFO with the same
    note
  - The recommended action becomes "Document the elected license in
    METADATA.yaml's `files_with_other_licenses` array" rather than
    "Quarantine".
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path

from .licenses import detect_license_from_text, classify, LICENSE_CLASS


# Filename patterns that indicate a license-marker file.
# These match the same set as licenses.LICENSE_FILE_NAMES but also
# accept license-named-by-spdx variants (LICENSE.BSD, LICENSE.MPL-2.0).
_LICENSE_FILE_NAME_RE = re.compile(
    r"^(LICENSE|LICENCE|COPYING|COPYRIGHT|UNLICENSE)"
    r"(\.[A-Za-z0-9_.\-]+)?$",
)

# SPDX expression in a COPYING.md / LICENSE.md narrative
_SPDX_EXPR_RE = re.compile(
    r"SPDX-License-Identifier\s*[:`]+\s*"
    r"`?([A-Za-z0-9.\-+()]+(?:\s+(?:OR|AND|WITH)\s+[A-Za-z0-9.\-+()]+)+)`?",
)


@dataclass
class DualLicense:
    directory: str          # repo-relative directory path containing the dual license
    spdx_expression: str    # e.g., "BSD-3-Clause OR GPL-2.0" or "BSD-3-Clause AND MPL-2.0"
    operator: str           # 'OR' or 'AND' (per-file)
    licenses: list[str]     # the individual SPDX ids
    evidence_files: list[str]  # paths of the files that established the dual license
    detection_method: str   # 'sibling-files', 'spdx-expression', 'narrative'


def _is_license_filename(name: str) -> bool:
    return bool(_LICENSE_FILE_NAME_RE.match(name))


def _read_truncated(path: Path, max_bytes: int = 16_000) -> str:
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            return f.read(max_bytes)
    except Exception:
        return ""


def _detect_spdx_expression(text: str) -> tuple[str, str, list[str]] | None:
    """Look for an SPDX-License-Identifier expression in narrative text.

    Returns (expression, operator, [license_ids]) or None.
    Operator is 'OR' or 'AND' depending on the connector found.
    """
    m = _SPDX_EXPR_RE.search(text)
    if not m:
        return None
    expr = m.group(1).strip()
    if " OR " in expr:
        op = "OR"
    elif " AND " in expr:
        op = "AND"
    elif " WITH " in expr:
        op = "WITH"
    else:
        return None
    parts = [p.strip() for p in re.split(r"\s+(?:OR|AND|WITH)\s+", expr)]
    return expr, op, parts


def _detect_sibling_pair(license_files_in_dir: list[tuple[Path, str]]) -> DualLicense | None:
    """Two LICENSE files in the same dir with different SPDXs → OR-dual.

    Heuristic: if both files have detectable but different licenses, and
    one of them is permissive while the other is copyleft (or vice
    versa), it's a "user picks one" dual-license pattern.

    license_files_in_dir is [(path, detected_spdx)].
    """
    files_with_spdx = [(p, s) for p, s in license_files_in_dir if s]
    if len(files_with_spdx) < 2:
        return None
    spdx_set = {s for _, s in files_with_spdx}
    if len(spdx_set) < 2:
        return None
    # Verify the licenses are policy-compatible (i.e., AT LEAST ONE is
    # permissive, so we have a real choice).
    classifications = [classify(s).decision for s in spdx_set]
    has_permissive_choice = any(c == "adopt" for c in classifications)
    if not has_permissive_choice:
        return None
    return DualLicense(
        directory=str(files_with_spdx[0][0].parent),
        spdx_expression=" OR ".join(sorted(spdx_set)),
        operator="OR",
        licenses=sorted(spdx_set),
        evidence_files=[str(p) for p, _ in files_with_spdx],
        detection_method="sibling-files",
    )


def _detect_marker_file(license_files_in_dir: list[tuple[Path, str]]) -> DualLicense | None:
    """A COPYING.md / LICENSE.md with explicit SPDX expression → AND/OR dual.

    Only considers files whose extension is .md / .rst / .txt.
    """
    for path, _ in license_files_in_dir:
        if path.suffix.lower() not in (".md", ".rst", ".txt", ""):
            continue
        text = _read_truncated(path)
        result = _detect_spdx_expression(text)
        if result:
            expr, op, parts = result
            return DualLicense(
                directory=str(path.parent),
                spdx_expression=expr,
                operator=op,
                licenses=parts,
                evidence_files=[str(path)],
                detection_method="spdx-expression",
            )
    return None


def detect_dual_license_dirs(license_records: list[dict],
                             root: Path) -> dict[str, DualLicense]:
    """Walk the discovered LICENSE files and identify dual-licensed dirs.

    Args:
      license_records: combined declared + nested license file records,
        each containing keys 'path' (repo-relative) and 'spdx'.
      root: the repo root, so we can read each file's content.

    Returns:
      {repo_relative_dir: DualLicense}
    """
    # Group license records by their parent directory
    by_dir: dict[str, list[tuple[Path, str]]] = {}
    for rec in license_records:
        rel = rec["path"]
        full = root / rel
        parent = str(Path(rel).parent.as_posix() or ".")
        by_dir.setdefault(parent, []).append((full, rec["spdx"]))

    dual: dict[str, DualLicense] = {}
    for d, files in by_dir.items():
        # Try sibling-pair detection first (cheaper)
        sib = _detect_sibling_pair(files)
        if sib:
            dual[d] = sib
            continue
        # Then check for SPDX-expression marker file
        marker = _detect_marker_file(files)
        if marker:
            dual[d] = marker
            continue
    return dual


def find_within_dual_dir(file_path: str, dual_dirs: dict[str, DualLicense]) -> DualLicense | None:
    """Return the DualLicense covering a file, or None.

    A file is "covered" if it lives in a dual-license directory or a
    sub-directory of one (so a license file inside a sub-package of a
    dual-licensed project is still recognized).
    """
    fp = Path(file_path).as_posix()
    # Match longest containing prefix
    matches: list[tuple[str, DualLicense]] = []
    for d, dl in dual_dirs.items():
        d_rel = Path(d).as_posix()
        if d_rel == "." or fp == d_rel or fp.startswith(d_rel + "/"):
            matches.append((d_rel, dl))
    if not matches:
        return None
    # Pick deepest match
    matches.sort(key=lambda m: -len(m[0]))
    return matches[0][1]
