"""GCP Terraform security rules.

References are CIS GCP Foundations Benchmark sections (CIS-GCP) and
Google Cloud Security Command Center finding categories where useful.
"""
from __future__ import annotations

import re

from .iac import (
    Block, CheckResult, fail, register,
    get_attr, get_bool, get_list, get_nested, unquote,
)


# ────────────────────────────────────────────────────────────────────────
# Cloud Storage
# ────────────────────────────────────────────────────────────────────────

@register("gcp", "google_storage_bucket", "gcp-gcs-no-uniform-access")
def gcs_no_uniform_access(b: Block) -> CheckResult | None:
    if get_bool(b.body, "uniform_bucket_level_access") is not True:
        return fail(
            "gcp-gcs-no-uniform-access", "high",
            "GCS bucket does not enforce uniform bucket-level access",
            "uniform_bucket_level_access is not true. Object-level ACLs "
            "can override bucket IAM and create unexpected public exposure.",
            "Set uniform_bucket_level_access = true.",
            "CIS-GCP 5.2",
        )
    return None


@register("gcp", "google_storage_bucket", "gcp-gcs-no-versioning")
def gcs_no_versioning(b: Block) -> CheckResult | None:
    nested = get_nested(b.body, "versioning")
    if not nested or get_bool(nested[0], "enabled") is not True:
        return fail(
            "gcp-gcs-no-versioning", "medium",
            "GCS bucket has no object versioning",
            "versioning block missing or enabled is not true.",
            "Add versioning { enabled = true }.",
            "CIS-GCP 5.3",
        )
    return None


@register("gcp", "google_storage_bucket_iam_member",
          "gcp-gcs-public-iam-member")
def gcs_public_iam_member(b: Block) -> CheckResult | None:
    member = unquote(get_attr(b.body, "member"))
    if member in ("allUsers", "allAuthenticatedUsers"):
        return fail(
            "gcp-gcs-public-iam-member", "critical",
            f"GCS bucket grants role to '{member}'",
            f"A google_storage_bucket_iam_member binding assigns access to "
            f"'{member}', meaning anyone on the Internet (allUsers) or any "
            f"authenticated Google user (allAuthenticatedUsers) can use the "
            f"role.",
            "Replace with specific user, group, or service-account "
            "principals.",
            "CIS-GCP 5.1",
        )
    return None


@register("gcp", "google_storage_bucket_iam_binding",
          "gcp-gcs-public-iam-binding")
def gcs_public_iam_binding(b: Block) -> CheckResult | None:
    members = get_list(b.body, "members") or []
    bad = [m for m in members if m in ("allUsers", "allAuthenticatedUsers")]
    if bad:
        return fail(
            "gcp-gcs-public-iam-binding", "critical",
            "GCS bucket binding includes a public principal",
            f"members includes {bad}, exposing the bucket to anyone.",
            "Remove allUsers / allAuthenticatedUsers from members.",
            "CIS-GCP 5.1",
        )
    return None


@register("gcp", "google_storage_bucket", "gcp-gcs-no-encryption-key")
def gcs_no_cmek(b: Block) -> CheckResult | None:
    if not get_nested(b.body, "encryption"):
        return fail(
            "gcp-gcs-no-encryption-key", "low",
            "GCS bucket uses Google-managed encryption keys (no CMEK)",
            "No encryption block; the bucket relies on Google-managed keys.",
            "For sensitive data, add encryption { default_kms_key_name = ... }"
            " pointing at a customer-managed key.",
            "CIS-GCP 5.5",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# Compute Engine
# ────────────────────────────────────────────────────────────────────────

@register("gcp", "google_compute_instance", "gcp-compute-public-ip")
def compute_public_ip(b: Block) -> CheckResult | None:
    nics = get_nested(b.body, "network_interface")
    for n in nics:
        if get_nested(n, "access_config"):
            return fail(
                "gcp-compute-public-ip", "medium",
                "Compute instance has an external IP",
                "An access_config block is present inside network_interface, "
                "which assigns a public IP.",
                "Remove access_config; reach the instance via IAP TCP "
                "forwarding or a bastion in a peered VPC.",
                "CIS-GCP 4.9",
            )
    return None


@register("gcp", "google_compute_instance", "gcp-compute-no-shielded")
def compute_no_shielded(b: Block) -> CheckResult | None:
    if not get_nested(b.body, "shielded_instance_config"):
        return fail(
            "gcp-compute-no-shielded", "medium",
            "Compute instance does not enable Shielded VM",
            "No shielded_instance_config block.",
            "Add shielded_instance_config { enable_secure_boot = true, "
            "enable_vtpm = true, enable_integrity_monitoring = true }.",
            "CIS-GCP 4.8",
        )
    return None


@register("gcp", "google_compute_instance", "gcp-compute-os-login")
def compute_no_os_login(b: Block) -> CheckResult | None:
    md = get_nested(b.body, "metadata")
    enabled = False
    for body in md:
        if re.search(r'enable-oslogin\s*=\s*"true"', body, re.IGNORECASE):
            enabled = True
            break
    if not enabled:
        if re.search(r'enable-oslogin\s*=\s*"true"', b.body, re.IGNORECASE):
            enabled = True
    if not enabled:
        return fail(
            "gcp-compute-os-login", "low",
            "Compute instance does not enable OS Login",
            "metadata does not contain enable-oslogin = \"true\".",
            "Set metadata = { enable-oslogin = \"true\" } to gate SSH on "
            "IAM identities rather than per-instance keys.",
            "CIS-GCP 4.3",
        )
    return None


@register("gcp", "google_compute_instance", "gcp-compute-ip-forwarding")
def compute_ip_forwarding(b: Block) -> CheckResult | None:
    if get_bool(b.body, "can_ip_forward") is True:
        return fail(
            "gcp-compute-ip-forwarding", "medium",
            "Compute instance has IP forwarding enabled",
            "can_ip_forward = true. This allows the VM to act as a router, "
            "which expands lateral-movement potential if compromised.",
            "Set can_ip_forward = false unless the workload requires it.",
            "CIS-GCP 4.6",
        )
    return None


@register("gcp", "google_compute_instance", "gcp-compute-default-sa")
def compute_default_sa(b: Block) -> CheckResult | None:
    sa_blocks = get_nested(b.body, "service_account")
    if not sa_blocks:
        return fail(
            "gcp-compute-default-sa", "high",
            "Compute instance uses the default service account",
            "No explicit service_account block; the instance will use the "
            "Compute Engine default SA which has broad Editor role.",
            "Create a least-privilege service account and bind it via "
            "service_account { email = ..., scopes = [\"cloud-platform\"] }.",
            "CIS-GCP 4.1",
        )
    for body in sa_blocks:
        scopes = get_list(body, "scopes") or []
        if "https://www.googleapis.com/auth/cloud-platform" in scopes:
            return fail(
                "gcp-compute-default-sa", "medium",
                "Compute instance scopes include full cloud-platform",
                "service_account.scopes grants cloud-platform, which "
                "is full-access. The instance can call any API the bound "
                "SA has IAM for.",
                "Use narrowly-scoped OAuth scopes (e.g. devstorage.read_only) "
                "or rely on IAM bindings on a dedicated SA.",
                "CIS-GCP 4.1",
            )
    return None


@register("gcp", "google_compute_instance", "gcp-compute-serial-port")
def compute_serial_port(b: Block) -> CheckResult | None:
    if re.search(r'serial-port-enable\s*=\s*"(?:TRUE|1|true)"',
                 b.body, re.IGNORECASE):
        return fail(
            "gcp-compute-serial-port", "high",
            "Compute instance has serial port access enabled",
            "metadata.serial-port-enable is set to true. The serial console "
            "can be used to bypass network controls.",
            "Set serial-port-enable = \"false\" or remove the metadata key.",
            "CIS-GCP 4.5",
        )
    return None


@register("gcp", "google_compute_disk", "gcp-disk-no-cmek")
def disk_no_cmek(b: Block) -> CheckResult | None:
    if not get_nested(b.body, "disk_encryption_key"):
        return fail(
            "gcp-disk-no-cmek", "low",
            "Compute disk uses Google-managed encryption keys",
            "No disk_encryption_key block. Disk uses Google-managed key, "
            "which cannot be revoked independently.",
            "Add disk_encryption_key { kms_key_self_link = ... } pointing at "
            "a customer-managed CMEK.",
            "CIS-GCP 4.7",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# Firewall
# ────────────────────────────────────────────────────────────────────────

_SENSITIVE_PORTS_GCP = {
    22: "SSH", 23: "Telnet", 135: "RPC", 139: "SMB", 445: "SMB",
    1433: "MSSQL", 1521: "Oracle", 2375: "Docker", 3306: "MySQL",
    3389: "RDP", 5432: "PostgreSQL", 5601: "Kibana", 6379: "Redis",
    8086: "InfluxDB", 9092: "Kafka", 9200: "Elasticsearch",
    11211: "Memcached", 27017: "MongoDB",
}


def _ports_to_ints(raw: list[str]) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    for p in raw:
        if "-" in p:
            a, _, c = p.partition("-")
            try:
                out.append((int(a), int(c)))
            except ValueError:
                continue
        else:
            try:
                v = int(p)
                out.append((v, v))
            except ValueError:
                continue
    return out


@register("gcp", "google_compute_firewall", "gcp-fw-world-open")
def fw_world_open(b: Block) -> CheckResult | None:
    src = get_list(b.body, "source_ranges") or []
    if not any(s in ("0.0.0.0/0", "::/0") for s in src):
        return None
    # If 'deny' block is present, this is a deny rule - not a finding.
    if get_nested(b.body, "deny"):
        return None
    allow_blocks = get_nested(b.body, "allow")
    exposed: list[str] = []
    for ab in allow_blocks:
        proto = unquote(get_attr(ab, "protocol"))
        ports = get_list(ab, "ports") or []
        if proto in ("all", "-1") or (proto and not ports):
            exposed.append(f"all {proto or 'protocols'}")
            continue
        for lo, hi in _ports_to_ints(ports):
            for port, name in _SENSITIVE_PORTS_GCP.items():
                if lo <= port <= hi:
                    exposed.append(f"{port}/{name}")
    if exposed:
        sev = "critical" if any("all" in e for e in exposed) else "high"
        return fail(
            "gcp-fw-world-open", sev,
            "Firewall rule exposes sensitive ports to the Internet",
            f"source_ranges includes 0.0.0.0/0 (or ::/0) AND allows: "
            f"{', '.join(sorted(set(exposed)))}.",
            "Restrict source_ranges to a corporate / VPN CIDR, or use "
            "IAP TCP forwarding for SSH/RDP instead of opening ports.",
            "CIS-GCP 3.6 / 3.7",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# IAM
# ────────────────────────────────────────────────────────────────────────

_PRIMITIVE_ROLES = {
    "roles/owner": "critical",
    "roles/editor": "high",
    "roles/viewer": "low",
}


@register("gcp", "google_project_iam_member", "gcp-iam-public-member")
def iam_public_member(b: Block) -> CheckResult | None:
    member = unquote(get_attr(b.body, "member"))
    role = unquote(get_attr(b.body, "role")) or ""
    if member in ("allUsers", "allAuthenticatedUsers"):
        sev = _PRIMITIVE_ROLES.get(role, "high")
        return fail(
            "gcp-iam-public-member", sev,
            f"Project IAM grants {role or 'a role'} to '{member}'",
            f"google_project_iam_member binds role '{role}' to '{member}'. "
            f"Any user on the Internet (allUsers) or any Google user "
            f"(allAuthenticatedUsers) inherits this role at the project "
            f"level.",
            "Replace with a specific principal. Public access at project "
            "level is almost never intentional.",
            "CIS-GCP 1.1",
        )
    return None


@register("gcp", "google_project_iam_binding", "gcp-iam-public-binding")
def iam_public_binding(b: Block) -> CheckResult | None:
    members = get_list(b.body, "members") or []
    role = unquote(get_attr(b.body, "role")) or ""
    bad = [m for m in members if m in ("allUsers", "allAuthenticatedUsers")]
    if bad:
        sev = _PRIMITIVE_ROLES.get(role, "high")
        return fail(
            "gcp-iam-public-binding", sev,
            f"Project IAM binding grants {role} to public principal(s)",
            f"members includes {bad} on role '{role}'.",
            "Remove allUsers / allAuthenticatedUsers from members.",
            "CIS-GCP 1.1",
        )
    return None


@register("gcp", "google_project_iam_member", "gcp-iam-primitive-role")
def iam_primitive_role(b: Block) -> CheckResult | None:
    role = unquote(get_attr(b.body, "role")) or ""
    if role in ("roles/owner", "roles/editor"):
        member = unquote(get_attr(b.body, "member")) or ""
        if member.startswith(("allUsers", "allAuthenticatedUsers")):
            return None  # handled by gcp-iam-public-member
        return fail(
            "gcp-iam-primitive-role", "medium",
            f"IAM binding uses primitive role {role}",
            f"Primitive roles (owner/editor/viewer) are not least-privilege. "
            f"'{role}' grants very broad permissions.",
            "Replace with predefined roles (or a custom role) scoped to "
            "the principal's actual needs.",
            "CIS-GCP 1.5",
        )
    return None


@register("gcp", "google_service_account_key", "gcp-sa-user-managed-key")
def sa_user_managed_key(b: Block) -> CheckResult | None:
    return fail(
        "gcp-sa-user-managed-key", "high",
        "User-managed service account key declared",
        "google_service_account_key creates a long-lived JSON key. These "
        "leak in source control, CI logs, and laptops. Google's own "
        "guidance is to avoid them.",
        "Use Workload Identity Federation, Workload Identity for GKE, or "
        "the metadata server. If unavoidable, rotate via google_service_"
        "account_key_iam and short keepers.",
        "CIS-GCP 1.4",
    )


# ────────────────────────────────────────────────────────────────────────
# Cloud SQL
# ────────────────────────────────────────────────────────────────────────

@register("gcp", "google_sql_database_instance", "gcp-sql-public")
def sql_public(b: Block) -> CheckResult | None:
    settings = get_nested(b.body, "settings")
    for body in settings:
        ip_cfg = get_nested(body, "ip_configuration")
        for ic in ip_cfg:
            if get_bool(ic, "ipv4_enabled") is True:
                # Public IP enabled - check authorized_networks
                auth = get_nested(ic, "authorized_networks")
                if not auth:
                    return fail(
                        "gcp-sql-public", "critical",
                        "Cloud SQL instance has a public IP with no IP allow-list",
                        "ipv4_enabled = true and no authorized_networks "
                        "block. The DB is reachable from the entire "
                        "Internet (modulo SSL).",
                        "Set ipv4_enabled = false and reach via private IP "
                        "+ VPC peering, or restrict authorized_networks.",
                        "CIS-GCP 6.5",
                    )
                for a in auth:
                    val = unquote(get_attr(a, "value"))
                    if val == "0.0.0.0/0":
                        return fail(
                            "gcp-sql-public", "critical",
                            "Cloud SQL authorized_networks includes 0.0.0.0/0",
                            "An authorized_networks entry of 0.0.0.0/0 "
                            "permits all source IPs.",
                            "Remove 0.0.0.0/0; restrict to specific CIDRs.",
                            "CIS-GCP 6.5",
                        )
    return None


@register("gcp", "google_sql_database_instance", "gcp-sql-no-ssl")
def sql_no_ssl(b: Block) -> CheckResult | None:
    settings = get_nested(b.body, "settings")
    for body in settings:
        ip_cfg = get_nested(body, "ip_configuration")
        for ic in ip_cfg:
            if get_bool(ic, "require_ssl") is not True \
               and unquote(get_attr(ic, "ssl_mode")) not in (
                   "ENCRYPTED_ONLY", "TRUSTED_CLIENT_CERTIFICATE_REQUIRED"):
                return fail(
                    "gcp-sql-no-ssl", "high",
                    "Cloud SQL instance does not require SSL",
                    "Neither require_ssl = true nor a strict ssl_mode is "
                    "set. Clients may connect in cleartext.",
                    "Set ip_configuration { require_ssl = true } (or "
                    "ssl_mode = \"ENCRYPTED_ONLY\").",
                    "CIS-GCP 6.4",
                )
    return None


@register("gcp", "google_sql_database_instance", "gcp-sql-no-backup")
def sql_no_backup(b: Block) -> CheckResult | None:
    settings = get_nested(b.body, "settings")
    for body in settings:
        bc = get_nested(body, "backup_configuration")
        if not bc or get_bool(bc[0], "enabled") is not True:
            return fail(
                "gcp-sql-no-backup", "medium",
                "Cloud SQL instance has no automated backups",
                "backup_configuration block missing or enabled is not true.",
                "Add settings { backup_configuration { enabled = true, "
                "point_in_time_recovery_enabled = true } }.",
                "CIS-GCP 6.7",
            )
    return None


# ────────────────────────────────────────────────────────────────────────
# GKE
# ────────────────────────────────────────────────────────────────────────

@register("gcp", "google_container_cluster", "gcp-gke-legacy-abac")
def gke_legacy_abac(b: Block) -> CheckResult | None:
    if get_bool(b.body, "enable_legacy_abac") is True:
        return fail(
            "gcp-gke-legacy-abac", "high",
            "GKE cluster has legacy ABAC enabled",
            "enable_legacy_abac = true. This pre-RBAC authorization model "
            "is far more permissive than required.",
            "Set enable_legacy_abac = false and rely on RBAC.",
            "CIS-GCP 7.12",
        )
    return None


@register("gcp", "google_container_cluster", "gcp-gke-public-endpoint")
def gke_public_endpoint(b: Block) -> CheckResult | None:
    pcc = get_nested(b.body, "private_cluster_config")
    if not pcc or get_bool(pcc[0], "enable_private_endpoint") is not True:
        return fail(
            "gcp-gke-public-endpoint", "high",
            "GKE cluster control plane is publicly accessible",
            "private_cluster_config block missing or "
            "enable_private_endpoint is not true. The Kubernetes API is "
            "reachable from the Internet.",
            "Set private_cluster_config { enable_private_endpoint = true, "
            "enable_private_nodes = true } and configure "
            "master_authorized_networks_config for management access.",
            "CIS-GCP 7.6",
        )
    return None


@register("gcp", "google_container_cluster", "gcp-gke-basic-auth")
def gke_basic_auth(b: Block) -> CheckResult | None:
    ma = get_nested(b.body, "master_auth")
    for body in ma:
        user = unquote(get_attr(body, "username")) or ""
        pwd = unquote(get_attr(body, "password")) or ""
        if user or pwd:
            return fail(
                "gcp-gke-basic-auth", "high",
                "GKE cluster has master basic auth configured",
                "master_auth.username/password are non-empty. Basic auth "
                "to the GKE API was deprecated and is exploitable.",
                "Remove username/password (set both to empty strings) and "
                "rely on Google Cloud IAM via gcloud.",
                "CIS-GCP 7.8",
            )
    return None


@register("gcp", "google_container_cluster", "gcp-gke-no-network-policy")
def gke_no_network_policy(b: Block) -> CheckResult | None:
    np = get_nested(b.body, "network_policy")
    if not np or get_bool(np[0], "enabled") is not True:
        return fail(
            "gcp-gke-no-network-policy", "medium",
            "GKE cluster has no NetworkPolicy enforcement",
            "network_policy block missing or enabled is not true. Pods "
            "can reach any other pod by default.",
            "Set network_policy { enabled = true, provider = \"CALICO\" }.",
            "CIS-GCP 7.7",
        )
    return None


@register("gcp", "google_container_cluster",
          "gcp-gke-no-workload-identity")
def gke_no_workload_identity(b: Block) -> CheckResult | None:
    wi = get_nested(b.body, "workload_identity_config")
    if not wi:
        return fail(
            "gcp-gke-no-workload-identity", "medium",
            "GKE cluster has no Workload Identity",
            "No workload_identity_config block. Pods cannot map to GCP IAM "
            "identities without it - the common alternative is node-level "
            "service accounts which over-grant.",
            "Add workload_identity_config { workload_pool = "
            "\"PROJECT.svc.id.goog\" }.",
            "CIS-GCP 7.10",
        )
    return None


@register("gcp", "google_container_cluster",
          "gcp-gke-no-shielded-nodes")
def gke_no_shielded_nodes(b: Block) -> CheckResult | None:
    if get_bool(b.body, "enable_shielded_nodes") is not True:
        return fail(
            "gcp-gke-no-shielded-nodes", "medium",
            "GKE cluster does not enable shielded nodes",
            "enable_shielded_nodes is not true.",
            "Set enable_shielded_nodes = true.",
            "CIS-GCP 7.13",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# BigQuery
# ────────────────────────────────────────────────────────────────────────

@register("gcp", "google_bigquery_dataset", "gcp-bq-public")
def bq_public(b: Block) -> CheckResult | None:
    accesses = get_nested(b.body, "access")
    for body in accesses:
        for key in ("user_by_email", "group_by_email", "special_group",
                    "domain"):
            val = unquote(get_attr(body, key)) or ""
            if val in ("allUsers", "allAuthenticatedUsers"):
                return fail(
                    "gcp-bq-public", "critical",
                    f"BigQuery dataset grants access to '{val}'",
                    f"An access block on this dataset sets {key} = "
                    f"'{val}'. The dataset is publicly readable.",
                    "Remove allUsers / allAuthenticatedUsers. BigQuery data "
                    "is almost never appropriate to share publicly.",
                    "CIS-GCP 7.1",
                )
    return None


@register("gcp", "google_bigquery_dataset", "gcp-bq-no-cmek")
def bq_no_cmek(b: Block) -> CheckResult | None:
    if not get_nested(b.body, "default_encryption_configuration"):
        return fail(
            "gcp-bq-no-cmek", "low",
            "BigQuery dataset uses Google-managed encryption",
            "No default_encryption_configuration block.",
            "Add default_encryption_configuration { kms_key_name = ... } "
            "with a CMEK.",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# KMS, PubSub, DNS, Cloud Functions
# ────────────────────────────────────────────────────────────────────────

@register("gcp", "google_kms_crypto_key", "gcp-kms-no-rotation")
def kms_no_rotation(b: Block) -> CheckResult | None:
    rp = unquote(get_attr(b.body, "rotation_period"))
    if not rp:
        return fail(
            "gcp-kms-no-rotation", "medium",
            "KMS crypto key has no rotation period",
            "rotation_period is not set; the key never rotates.",
            "Set rotation_period = \"7776000s\" (90 days) or shorter.",
            "CIS-GCP 1.10",
        )
    # 7776000s = 90 days, 31536000s = 365 days
    try:
        seconds = int(rp.rstrip("s"))
        if seconds > 7776000:  # > 90 days
            return fail(
                "gcp-kms-no-rotation", "low",
                "KMS crypto key rotation period exceeds 90 days",
                f"rotation_period = {rp} (> 90 days).",
                "Reduce rotation_period to 7776000s (90 days) or shorter.",
                "CIS-GCP 1.10",
            )
    except ValueError:
        pass
    return None


@register("gcp", "google_pubsub_topic", "gcp-pubsub-no-cmek")
def pubsub_no_cmek(b: Block) -> CheckResult | None:
    if not get_attr(b.body, "kms_key_name"):
        return fail(
            "gcp-pubsub-no-cmek", "low",
            "Pub/Sub topic uses Google-managed encryption",
            "kms_key_name is not set.",
            "Set kms_key_name to a CMEK for sensitive topics.",
        )
    return None


@register("gcp", "google_dns_managed_zone", "gcp-dns-no-dnssec")
def dns_no_dnssec(b: Block) -> CheckResult | None:
    dnssec = get_nested(b.body, "dnssec_config")
    if not dnssec:
        return fail(
            "gcp-dns-no-dnssec", "medium",
            "DNS managed zone has DNSSEC disabled",
            "No dnssec_config block.",
            "Add dnssec_config { state = \"on\" } for any public zone.",
            "CIS-GCP 3.3",
        )
    for body in dnssec:
        state = unquote(get_attr(body, "state"))
        if state and state != "on":
            return fail(
                "gcp-dns-no-dnssec", "medium",
                "DNS managed zone has DNSSEC disabled",
                f"dnssec_config.state = '{state}'.",
                "Set dnssec_config { state = \"on\" }.",
                "CIS-GCP 3.3",
            )
    return None


@register("gcp", "google_cloudfunctions_function", "gcp-cf-public-invoke")
def cf_public_invoke(b: Block) -> CheckResult | None:
    """Detect the 'allUsers can invoke' pattern often added in a sibling
    google_cloudfunctions_function_iam_member resource. This rule
    checks the function block only - the IAM resource rule below covers
    the binding itself."""
    return None  # placeholder; the IAM rule below catches the real case


@register("gcp", "google_cloudfunctions_function_iam_member",
          "gcp-cf-iam-public")
def cf_iam_public(b: Block) -> CheckResult | None:
    member = unquote(get_attr(b.body, "member"))
    if member in ("allUsers", "allAuthenticatedUsers"):
        return fail(
            "gcp-cf-iam-public", "high",
            "Cloud Function is invokable by public principal",
            f"google_cloudfunctions_function_iam_member assigns the "
            f"invoker role to '{member}'. Anyone can call the function.",
            "If the function must be public, ensure it validates its "
            "input strictly and is rate-limited. Otherwise restrict to "
            "specific principals.",
        )
    return None


# ────────────────────────────────────────────────────────────────────────
# Logging
# ────────────────────────────────────────────────────────────────────────

@register("gcp", "google_logging_project_sink", "gcp-logging-no-unique-writer")
def logging_no_unique_writer(b: Block) -> CheckResult | None:
    if get_bool(b.body, "unique_writer_identity") is not True:
        return fail(
            "gcp-logging-no-unique-writer", "low",
            "Logging sink does not use a unique writer identity",
            "unique_writer_identity is not true; the project's default "
            "service account is reused, which expands the blast radius "
            "if it leaks.",
            "Set unique_writer_identity = true.",
            "CIS-GCP 2.2",
        )
    return None
