"""Recurring rescans + history + diff.

`hiddenshadow watch <path>` runs the scan, persists every run into a
history directory, and on each subsequent run reports only the *new*
findings since the previous one. Useful for catching newly-published
CVEs against unchanged code (which the scan would otherwise re-emit
identically every time).

Persistence layout::

    <output>/_scan_history/
        20260515T143000Z.json    # full scan-findings shape
        20260515T200000Z.json
        20260516T143000Z.json
        latest.json -> ...       # not a real symlink; just a copy

Diff semantics
--------------
A "finding identity" key is built from (repo, category, method, title,
location, severity). Two runs that produce findings with the same
identity are treated as the same finding even if the wall-clock detail
text changed. New / removed sets are reported per category.

Scheduling
----------
Built-in: ``--interval <seconds>`` runs the loop in this process. For
unattended scheduling, register the one-shot mode (``--once``) with
your OS scheduler - cron / Windows Task Scheduler / systemd timer -
which is more robust than holding a long-running process.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import scan as scan_mod


HISTORY_DIRNAME = "_scan_history"


def _finding_key(f: dict) -> str:
    """Stable identity for a finding across runs."""
    parts = (
        f.get("repo", ""),
        f.get("category", ""),
        f.get("method", ""),
        f.get("title", ""),
        f.get("location", ""),
        f.get("severity", ""),
    )
    return hashlib.sha256(
        "\x1f".join(parts).encode("utf-8")).hexdigest()


def _history_dir(output_root: Path) -> Path:
    d = output_root / HISTORY_DIRNAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def _now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _list_history(hd: Path) -> list[Path]:
    return sorted(p for p in hd.iterdir()
                  if p.suffix == ".json" and p.name != "latest.json")


def _prior_run(hd: Path) -> dict | None:
    runs = _list_history(hd)
    if not runs:
        return None
    try:
        return json.loads(runs[-1].read_text(encoding="utf-8"))
    except Exception:
        return None


@dataclass
class WatchDiff:
    """Diff between the prior and current run."""
    prior_stamp: str
    current_stamp: str
    new_findings: list[dict] = field(default_factory=list)
    resolved_findings: list[dict] = field(default_factory=list)
    unchanged: int = 0

    @property
    def new_by_severity(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for f in self.new_findings:
            sev = f.get("severity", "info")
            out[sev] = out.get(sev, 0) + 1
        return out

    @property
    def has_new(self) -> bool:
        return bool(self.new_findings)


def diff_runs(prior: dict | None, current: dict) -> WatchDiff:
    """Return the new + resolved findings between two scan-findings docs."""
    cur_list = current.get("findings", []) or []
    cur_index = {_finding_key(f): f for f in cur_list}
    if prior is None:
        return WatchDiff(
            prior_stamp="",
            current_stamp=current.get("generated_at", ""),
            new_findings=cur_list,
        )
    prior_list = prior.get("findings", []) or []
    prior_index = {_finding_key(f): f for f in prior_list}
    new_keys = set(cur_index) - set(prior_index)
    resolved_keys = set(prior_index) - set(cur_index)
    unchanged = len(set(cur_index) & set(prior_index))
    return WatchDiff(
        prior_stamp=prior.get("generated_at", ""),
        current_stamp=current.get("generated_at", ""),
        new_findings=[cur_index[k] for k in new_keys],
        resolved_findings=[prior_index[k] for k in resolved_keys],
        unchanged=unchanged,
    )


def _save_run(output_root: Path, findings_doc: dict) -> Path:
    hd = _history_dir(output_root)
    stamp = _now_stamp()
    path = hd / f"{stamp}.json"
    path.write_text(json.dumps(findings_doc, indent=2), encoding="utf-8")
    # Mirror to latest.json so downstream tooling has a stable filename.
    (hd / "latest.json").write_text(
        json.dumps(findings_doc, indent=2), encoding="utf-8")
    return path


def run_once(source_root: Path, output_root: Path,
             *, scan_kwargs: dict[str, Any] | None = None
             ) -> tuple[Path, WatchDiff]:
    """Run a single scan, persist it, return (artifact_path, diff)."""
    hd = _history_dir(output_root)
    prior = _prior_run(hd)
    scan_kwargs = dict(scan_kwargs or {})
    scan_kwargs.setdefault("quiet", True)
    summary = scan_mod.run(
        source_root=source_root,
        output_root=output_root,
        **scan_kwargs,
    )
    findings_doc = summary.get("findings") or {}
    findings_doc["watch_run_stamp"] = _now_stamp()
    artifact = _save_run(output_root, findings_doc)
    diff = diff_runs(prior, findings_doc)
    return artifact, diff


def watch_loop(source_root: Path, output_root: Path,
               interval_seconds: int,
               *, scan_kwargs: dict[str, Any] | None = None,
               on_diff=None,
               max_iterations: int | None = None) -> None:
    """Run :func:`run_once` repeatedly with sleep in between.

    ``on_diff`` is invoked with each :class:`WatchDiff`. Use it to log,
    notify, or break out of the loop on critical findings. The loop runs
    forever unless ``max_iterations`` is supplied (mostly for tests).
    """
    i = 0
    while True:
        _, diff = run_once(source_root, output_root,
                           scan_kwargs=scan_kwargs)
        if on_diff is not None:
            try:
                on_diff(diff)
            except Exception:
                pass
        i += 1
        if max_iterations and i >= max_iterations:
            return
        time.sleep(interval_seconds)
