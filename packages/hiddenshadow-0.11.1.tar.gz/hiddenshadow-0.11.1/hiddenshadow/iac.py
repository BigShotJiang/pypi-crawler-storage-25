"""Terraform / IaC security configuration scanner.

Reads HCL (.tf) and HCL-JSON (.tf.json) Terraform sources, parses out
top-level ``resource`` / ``data`` / ``module`` / ``provider`` blocks,
and applies a curated rule set per cloud (AWS, GCP) to flag insecure
configurations - public buckets, world-open security groups, IAM
wildcards, unencrypted databases, missing audit logging, etc.

Design
------
Stdlib-only by project convention. The HCL parser is intentionally
*not* a full HCL implementation - it's a focused block / attribute
extractor good enough for security scanning:

* Detects top-level ``resource "TYPE" "NAME" { ... }`` blocks with
  brace-depth tracking.
* Pulls simple ``key = "value"`` / ``key = true`` / ``key = 123``
  attributes out of a block body.
* Recognizes list literals ``key = ["a", "b"]``.
* Recognizes nested blocks ``versioning { enabled = true }``.
* Strips line and ``/* ... */`` comments before matching.
* Skips Terraform variable interpolations ``var.x`` and resource
  references ``aws_iam_role.foo.arn`` - rules that need a concrete
  value report "unknown" rather than firing a false positive.

For complex expressions (locals, for_each, dynamic blocks) we keep
the source line range so a human reviewer can jump to the file.

Rule structure
--------------
Each rule is a callable ``(Block) -> CheckResult | None`` registered
against one resource type. Rules return ``None`` to abstain or a
:class:`CheckResult` to fire. Severity and recommendation are encoded
in the result so a rule can dynamically downgrade (e.g. "encryption
present but using default KMS key" -> medium instead of high).

Outputs
-------
Findings flow through the existing :class:`hiddenshadow.findings.Finding`
with ``category="iac"`` and ``method="iac:<cloud>:<rule_id>"`` so they
appear in the main report stream. The dedicated CLI ``tfscan`` writes
``tfscan-findings.json`` and ``tfscan-findings.csv`` for IaC-only use.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from .findings import Finding


# ── File discovery ──────────────────────────────────────────────────────

TF_SKIP_DIRS: set[str] = {
    ".git", ".terraform", "node_modules", "__pycache__",
    ".idea", ".vscode", ".pytest_cache",
}


def find_tf_files(root: Path) -> list[Path]:
    """Return every .tf / .tf.json / .tfvars under ``root``."""
    out: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in TF_SKIP_DIRS]
        for fn in filenames:
            if fn.endswith(".tf") or fn.endswith(".tf.json"):
                out.append(Path(dirpath) / fn)
    return out


# ── HCL block parser ────────────────────────────────────────────────────

# Matches the start of a top-level block:
#   resource "type" "name" {
#   data     "type" "name" {
#   module   "name" {
#   provider "name" {
#   locals   {
#   variable "name" {
#   output   "name" {
_BLOCK_START_RE = re.compile(
    r"""(?xm)
    ^(?P<indent>[ \t]*)
    (?P<kind>resource|data|module|provider|locals|variable|output|terraform)
    (?:\s+(?P<l1>"[^"]+"|[A-Za-z_][\w.\-]*))?
    (?:\s+(?P<l2>"[^"]+"))?
    \s*\{
    """
)

# Strip /* ... */ block comments and // / # single-line comments.
_BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
_LINE_COMMENT_RE = re.compile(r"(^|\s)(//|#)[^\n]*", re.MULTILINE)


def _strip_comments(src: str) -> str:
    s = _BLOCK_COMMENT_RE.sub("", src)
    s = _LINE_COMMENT_RE.sub("", s)
    return s


@dataclass
class Block:
    kind: str                 # 'resource' | 'data' | 'module' | ...
    type: str                 # e.g. 'aws_s3_bucket' (only resource/data)
    name: str                 # the user's local name
    body: str                 # raw text inside the outer braces
    file: Path
    line_start: int
    line_end: int

    @property
    def location(self) -> str:
        return f"{self.file.name}:{self.line_start}:{self.kind}.{self.type}.{self.name}"


def _scan_blocks(src: str, file: Path) -> list[Block]:
    """Walk ``src`` and return every top-level block with its raw body."""
    blocks: list[Block] = []
    s = src
    i = 0
    # Strip comments only for the matcher, but keep original for line nums.
    cleaned = _strip_comments(s)
    n = len(cleaned)
    while i < n:
        m = _BLOCK_START_RE.search(cleaned, i)
        if not m:
            break
        open_brace = m.end() - 1  # position of '{' (search ends after '{')
        depth = 1
        j = open_brace + 1
        while j < n and depth > 0:
            c = cleaned[j]
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
            elif c == '"':
                # skip string literal
                j += 1
                while j < n and cleaned[j] != '"':
                    if cleaned[j] == '\\' and j + 1 < n:
                        j += 2
                        continue
                    j += 1
            j += 1
        # body is between open_brace+1 and j-1 (the matching '}')
        body = cleaned[open_brace + 1:j - 1]
        line_start = cleaned.count("\n", 0, m.start()) + 1
        line_end = cleaned.count("\n", 0, j) + 1
        kind = m.group("kind")
        l1 = (m.group("l1") or "").strip('"')
        l2 = (m.group("l2") or "").strip('"')
        if kind in ("resource", "data"):
            type_, name = l1, l2
        elif kind in ("module", "provider", "variable", "output"):
            type_, name = "", l1
        else:
            type_, name = "", ""
        blocks.append(Block(
            kind=kind, type=type_, name=name,
            body=body, file=file,
            line_start=line_start, line_end=line_end,
        ))
        i = j
    return blocks


def _scan_json_blocks(data: dict, file: Path) -> list[Block]:
    """Parse Terraform JSON syntax (.tf.json) into Block objects.

    JSON shape::

        {
          "resource": {
            "aws_s3_bucket": {
              "example": { ...attrs... }
            }
          }
        }
    """
    blocks: list[Block] = []
    for kind, contents in (data or {}).items():
        if kind not in ("resource", "data", "module", "provider"):
            continue
        if not isinstance(contents, dict):
            continue
        if kind in ("resource", "data"):
            for type_, named in contents.items():
                if not isinstance(named, dict):
                    continue
                for name, attrs in named.items():
                    body = _json_attrs_to_hcl(attrs if isinstance(attrs, dict) else {})
                    blocks.append(Block(
                        kind=kind, type=type_, name=name,
                        body=body, file=file,
                        line_start=1, line_end=1,
                    ))
        else:
            for name, attrs in contents.items():
                body = _json_attrs_to_hcl(attrs if isinstance(attrs, dict) else {})
                blocks.append(Block(
                    kind=kind, type="", name=name,
                    body=body, file=file,
                    line_start=1, line_end=1,
                ))
    return blocks


def _json_attrs_to_hcl(attrs: dict) -> str:
    """Serialize a JSON-form attribute dict back to HCL-ish text so the
    same regex helpers work on it."""
    out: list[str] = []
    for k, v in attrs.items():
        if isinstance(v, bool):
            out.append(f"{k} = {str(v).lower()}")
        elif isinstance(v, (int, float)):
            out.append(f"{k} = {v}")
        elif isinstance(v, str):
            out.append(f'{k} = "{v}"')
        elif isinstance(v, list):
            inner = ", ".join(json.dumps(x) for x in v)
            out.append(f"{k} = [{inner}]")
        elif isinstance(v, dict):
            sub = _json_attrs_to_hcl(v)
            out.append(f"{k} {{\n{sub}\n}}")
    return "\n".join(out)


def parse_file(path: Path) -> list[Block]:
    """Parse a .tf or .tf.json file and return its top-level blocks."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    if path.name.endswith(".tf.json"):
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []
        if isinstance(data, dict):
            return _scan_json_blocks(data, path)
        return []
    return _scan_blocks(text, path)


# ── Attribute helpers ───────────────────────────────────────────────────

# Match `key = "value"` or `key = value` or `key = 123` etc.
_ATTR_RE_TMPL = (
    r"(?m)^[ \t]*{key}[ \t]*=[ \t]*"
    r"(?P<val>"
    r'"(?:[^"\\]|\\.)*"|'  # string
    r"'[^']*'|"            # single-quoted
    r"true|false|"
    r"\d+(?:\.\d+)?|"
    r"\[[^\]\n]*\]|"        # inline list
    r"[A-Za-z_][\w.\-:/]*"  # bareword (var ref, etc.)
    r")"
)


def get_attr(body: str, key: str) -> str | None:
    """Return the raw RHS of ``key = ...`` in ``body``, or None.

    Strings keep their surrounding quotes. Use :func:`unquote` to clean
    them up before string comparisons.
    """
    m = re.search(_ATTR_RE_TMPL.format(key=re.escape(key)), body)
    return m.group("val") if m else None


def unquote(s: str | None) -> str | None:
    if s is None:
        return None
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ("'", '"'):
        return s[1:-1]
    return s


def get_bool(body: str, key: str, default: bool | None = None) -> bool | None:
    """Return the boolean value of ``key`` if it is literally ``true`` /
    ``false``. References (``var.x``) return ``None`` (= unknown)."""
    raw = get_attr(body, key)
    if raw is None:
        return default
    if raw == "true":
        return True
    if raw == "false":
        return False
    return None


def get_list(body: str, key: str) -> list[str] | None:
    """Return the elements of an inline list literal, or None.

    Multi-line lists or lists containing references are not flattened
    here - rules should fall back to substring search for those.
    """
    raw = get_attr(body, key)
    if not raw or not (raw.startswith("[") and raw.endswith("]")):
        return None
    inner = raw[1:-1].strip()
    if not inner:
        return []
    out: list[str] = []
    for part in re.findall(
            r'"(?:[^"\\]|\\.)*"|\'[^\']*\'|[A-Za-z0-9_.\-:/]+', inner):
        out.append(unquote(part) or "")
    return out


# Nested-block matcher (anchors on a `<name> {` introducer at the start
# of a line). Walks the body with a brace counter so arbitrary depth is
# supported.
_NESTED_START_TMPL = r"(?m)(?:^|\n)[ \t]*{name}[ \t]*\{{"


def get_nested(body: str, name: str) -> list[str]:
    """Return the bodies of any nested block named ``name`` inside ``body``.

    Uses brace counting (not just regex) so arbitrarily deep nested
    blocks are extracted correctly. Skips over string literals and
    comments to avoid being confused by braces inside them.
    """
    pat = re.compile(_NESTED_START_TMPL.format(name=re.escape(name)))
    out: list[str] = []
    n = len(body)
    pos = 0
    while True:
        m = pat.search(body, pos)
        if not m:
            break
        i = m.end()        # one past the opening '{'
        depth = 1
        start = i
        while i < n and depth > 0:
            c = body[i]
            if c == '"':
                i += 1
                while i < n and body[i] != '"':
                    if body[i] == '\\' and i + 1 < n:
                        i += 2
                        continue
                    i += 1
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
            i += 1
        if depth == 0:
            out.append(body[start:i - 1])
        pos = i
    return out


# ── Rule library ────────────────────────────────────────────────────────

@dataclass
class CheckResult:
    rule_id: str
    severity: str           # critical | high | medium | low | info
    title: str
    detail: str
    recommendation: str
    reference: str = ""     # CIS section / vendor docs


@dataclass
class IacRule:
    id: str
    cloud: str              # 'aws' | 'gcp'
    resource_type: str      # e.g. 'aws_s3_bucket' (use '*' to match any)
    check: Callable[[Block], "CheckResult | None"]


# Module-level rule registry. AWS / GCP rule modules append to this on import.
_REGISTRY: dict[str, list[IacRule]] = {"aws": [], "gcp": []}


def register(cloud: str, resource_type: str, rule_id: str
             ) -> Callable[[Callable], Callable]:
    """Decorator: register a check function as a rule."""
    def deco(fn: Callable[[Block], "CheckResult | None"]) -> Callable:
        _REGISTRY.setdefault(cloud, []).append(
            IacRule(id=rule_id, cloud=cloud, resource_type=resource_type, check=fn)
        )
        return fn
    return deco


def get_rules(cloud: str) -> list[IacRule]:
    return list(_REGISTRY.get(cloud, []))


# ── Result helpers (convenience for rule authors) ───────────────────────

def fail(rule_id: str, severity: str, title: str, detail: str,
         recommendation: str, reference: str = "") -> CheckResult:
    return CheckResult(rule_id=rule_id, severity=severity, title=title,
                       detail=detail, recommendation=recommendation,
                       reference=reference)


# ── Top-level scanner ───────────────────────────────────────────────────

@dataclass
class IacFinding:
    """An IaC-specific finding shape with file + line info."""
    cloud: str
    rule_id: str
    severity: str
    resource_type: str
    resource_name: str
    file: str
    line: int
    title: str
    detail: str
    recommendation: str
    reference: str = ""

    def to_finding(self, repo: str) -> Finding:
        return Finding(
            repo=repo,
            severity=self.severity,
            category="iac",
            title=f"{self.cloud.upper()}: {self.title}",
            location=f"{self.file}:{self.line} ({self.resource_type}.{self.resource_name})",
            detail=self.detail,
            recommendation=self.recommendation,
            method=f"iac:{self.cloud}:{self.rule_id}",
        )


def scan_path(root: Path, clouds: Iterable[str] = ("aws", "gcp")
              ) -> list[IacFinding]:
    """Walk ``root``, parse every .tf file, run all rules, return findings."""
    _ensure_rulesets_loaded()
    findings: list[IacFinding] = []
    rules_by_cloud = {c: get_rules(c) for c in clouds}
    for f in find_tf_files(root):
        for block in parse_file(f):
            if block.kind not in ("resource", "data"):
                continue
            for cloud, rules in rules_by_cloud.items():
                for rule in rules:
                    if rule.resource_type not in ("*", block.type):
                        continue
                    try:
                        res = rule.check(block)
                    except Exception:  # pragma: no cover - defensive
                        continue
                    if res is None:
                        continue
                    findings.append(IacFinding(
                        cloud=cloud,
                        rule_id=res.rule_id,
                        severity=res.severity,
                        resource_type=block.type,
                        resource_name=block.name,
                        file=str(block.file),
                        line=block.line_start,
                        title=res.title,
                        detail=res.detail,
                        recommendation=res.recommendation,
                        reference=res.reference,
                    ))
    return findings


_rulesets_loaded = False


def _ensure_rulesets_loaded() -> None:
    """Import AWS / GCP rule modules so their @register decorators fire."""
    global _rulesets_loaded
    if _rulesets_loaded:
        return
    # Side-effect imports; these modules don't expose anything besides
    # their registered rules.
    from . import iac_rules_aws  # noqa: F401
    from . import iac_rules_gcp  # noqa: F401
    _rulesets_loaded = True


def scan_path_as_findings(root: Path, repo_name: str,
                          clouds: Iterable[str] = ("aws", "gcp")
                          ) -> list[Finding]:
    """Convenience: run the IaC scan and convert results into Findings."""
    return [f.to_finding(repo_name) for f in scan_path(root, clouds)]
