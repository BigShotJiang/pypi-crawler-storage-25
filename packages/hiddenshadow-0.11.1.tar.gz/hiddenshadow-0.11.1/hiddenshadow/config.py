"""Minimal config layer.

Resolution order, highest precedence first:
    1. Environment variables (HIDDENSHADOW_*)
    2. Config file at ``$HIDDENSHADOW_CONFIG`` (if set)
    3. Config file at ``~/.hiddenshadow/config.json`` (if present)
    4. Built-in defaults

The small-org installer ships no config file; defaults apply. Enterprise
deployments place a config.json (or set env vars in their service manager)
and override individual keys. Both tiers run the SAME application code —
only the backing services differ.

Schema (all keys optional in the file; defaults below):

    {
      "history_backend": "file",            // "file" | future: "sqlite" | "postgres"
      "history_path": "~/.hiddenshadow/scan-history.json",
      "history_max_entries": 200,

      "web_host": "127.0.0.1",
      "web_port": 7878,
      "single_instance": true,              // launcher probes for existing server

      "deployment_tier": "small-org"        // small-org | enterprise (advisory only)
    }
"""
from __future__ import annotations

import json
import os
import threading
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any


CONFIG_ENV_VAR = "HIDDENSHADOW_CONFIG"
DEFAULT_USER_CONFIG = Path.home() / ".hiddenshadow" / "config.json"


@dataclass
class Config:
    # Storage
    history_backend: str = "file"
    history_path: str = str(Path.home() / ".hiddenshadow" / "scan-history.json")
    history_max_entries: int = 200

    # Web / launcher
    web_host: str = "127.0.0.1"
    web_port: int = 7878
    single_instance: bool = True

    # Deployment metadata
    deployment_tier: str = "small-org"

    # Where this config was actually loaded from (informational).
    loaded_from: list[str] = field(default_factory=list)


_lock = threading.Lock()
_cached: Config | None = None


def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _coerce(field_name: str, raw: Any, default: Any) -> Any:
    """Best-effort coerce env-string values into the right type."""
    if raw is None:
        return default
    if isinstance(default, bool):
        return str(raw).strip().lower() in {"1", "true", "yes", "on"}
    if isinstance(default, int):
        try:
            return int(raw)
        except (TypeError, ValueError):
            return default
    return str(raw)


def _apply_overrides(cfg: Config, overrides: dict[str, Any], source: str) -> None:
    touched = False
    for k, v in overrides.items():
        if not hasattr(cfg, k) or k == "loaded_from":
            continue
        current = getattr(cfg, k)
        new = _coerce(k, v, current)
        if new != current:
            setattr(cfg, k, new)
            touched = True
    if touched:
        cfg.loaded_from.append(source)


def load(force: bool = False) -> Config:
    """Return the current Config. Cached for the process lifetime unless
    force=True. Thread-safe."""
    global _cached
    with _lock:
        if _cached is not None and not force:
            return _cached

        cfg = Config()

        # 3. Default user config file
        if DEFAULT_USER_CONFIG.exists():
            _apply_overrides(cfg, _read_json(DEFAULT_USER_CONFIG),
                             str(DEFAULT_USER_CONFIG))

        # 2. Explicit config file via env var
        env_path = os.environ.get(CONFIG_ENV_VAR, "").strip()
        if env_path:
            p = Path(env_path).expanduser()
            if p.exists():
                _apply_overrides(cfg, _read_json(p), str(p))

        # 1. Individual env-var overrides (highest precedence)
        env_overrides: dict[str, Any] = {}
        for field_name in cfg.__dataclass_fields__:
            if field_name == "loaded_from":
                continue
            env_key = "HIDDENSHADOW_" + field_name.upper()
            if env_key in os.environ:
                env_overrides[field_name] = os.environ[env_key]
        if env_overrides:
            _apply_overrides(cfg, env_overrides, "env")

        # Expand ~ in any path-shaped strings.
        cfg.history_path = str(Path(cfg.history_path).expanduser())

        _cached = cfg
        return cfg


def reset() -> None:
    """Drop the cached Config. Tests + reload scenarios only."""
    global _cached
    with _lock:
        _cached = None


def as_dict(cfg: Config | None = None) -> dict[str, Any]:
    """Serialize the config for diagnostics (e.g. /api/config)."""
    if cfg is None:
        cfg = load()
    return asdict(cfg)
