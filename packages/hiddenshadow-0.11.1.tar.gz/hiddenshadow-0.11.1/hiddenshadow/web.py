"""Flask web interface for hiddenshadow.

Endpoints
---------
GET  /                         main page
GET  /api/drives               list available filesystem roots (Windows drives, or "/" elsewhere)
GET  /api/browse?path=<p>      list immediate subdirectories of <p>
POST /api/scan                 start a scan; returns {"job_id": ...}
GET  /api/scan/<id>/events     Server-Sent Events stream of progress updates
GET  /api/scan/<id>/findings   final findings JSON (after complete)
GET  /api/scan/<id>/artifact   download an artifact file from the scan output

The scan runs in a background thread per job. Progress events flow from
scan.run()'s progress_callback into a per-job Queue, which the SSE
endpoint drains and forwards to the browser.
"""
from __future__ import annotations

import json
import os
import string
import sys  # noqa: F401  (kept for shutdown future-proofing)
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from queue import Queue, Empty
from typing import Any

from flask import (
    Flask, jsonify, request, Response, render_template, send_file, abort,
)

from . import scan as scan_mod
from . import history as history_mod
from . import config as config_mod
from . import __version__


# ── Job registry ─────────────────────────────────────────────────────────

@dataclass
class ScanJob:
    job_id: str
    source_root: str
    output_root: str
    started_at: float = field(default_factory=time.time)
    status: str = "queued"   # queued | running | complete | error
    error: str | None = None
    summary: dict[str, Any] | None = None
    history: list[dict[str, Any]] = field(default_factory=list)
    subscribers: list[Queue] = field(default_factory=list)
    finished: bool = False
    lock: threading.Lock = field(default_factory=threading.Lock)


_jobs: dict[str, ScanJob] = {}
_jobs_lock = threading.Lock()

# Process start time, used by /api/ping for an uptime reading.
_APP_STARTED = time.time()

# Sentinel pushed to subscriber queues when the job ends so SSE generators
# can return cleanly.
_END = object()


def _record_event(job: ScanJob, event: dict[str, Any]) -> None:
    """Append to history and fan out to all live subscribers atomically."""
    with job.lock:
        job.history.append(event)
        subs = list(job.subscribers)
    for q in subs:
        q.put(event)


def _mark_finished(job: ScanJob) -> None:
    """Signal terminal state to all subscribers, refuse new ones."""
    with job.lock:
        job.finished = True
        subs = list(job.subscribers)
    for q in subs:
        q.put(_END)


def _subscribe(job: ScanJob) -> tuple[list[dict[str, Any]], Queue | None]:
    """Atomically snapshot the history and register a new live queue.

    If the job is already finished, returns (history, None) so the caller
    can replay history without waiting on a queue.
    """
    with job.lock:
        backlog = list(job.history)
        if job.finished:
            return backlog, None
        q: Queue = Queue()
        job.subscribers.append(q)
        return backlog, q


def _unsubscribe(job: ScanJob, q: Queue) -> None:
    with job.lock:
        try:
            job.subscribers.remove(q)
        except ValueError:
            pass


# ── Filesystem helpers ───────────────────────────────────────────────────

def _list_drives() -> list[dict[str, str]]:
    """Return filesystem roots. Windows: drive letters; else: '/'."""
    roots: list[dict[str, str]] = []
    if os.name == "nt":
        for letter in string.ascii_uppercase:
            p = f"{letter}:\\"
            if os.path.exists(p):
                roots.append({"path": p, "label": f"{letter}:\\"})
    else:
        roots.append({"path": "/", "label": "/"})
    return roots


def _safe_browse(path: str) -> dict[str, Any]:
    """Return a directory listing for the path picker."""
    p = Path(path)
    if not p.exists():
        return {"error": f"Path does not exist: {path}"}
    if not p.is_dir():
        return {"error": f"Not a directory: {path}"}
    entries: list[dict[str, Any]] = []
    try:
        for child in sorted(p.iterdir(), key=lambda c: c.name.lower()):
            if not child.is_dir():
                continue
            if child.name.startswith("$"):
                continue
            entries.append({
                "name": child.name,
                "path": str(child),
            })
    except PermissionError:
        return {"error": f"Permission denied: {path}"}
    parent = str(p.parent) if p.parent != p else None
    return {
        "path": str(p.resolve()),
        "parent": parent,
        "entries": entries,
    }


# ── Scan worker ──────────────────────────────────────────────────────────

def _run_scan(job: ScanJob, options: dict[str, Any]) -> None:
    job.status = "running"
    _record_event(job, {"type": "status", "status": "running"})

    def cb(event: dict[str, Any]) -> None:
        _record_event(job, event)

    behavior_totals: dict[str, int] = {}
    def aggregate_behavior(event: dict[str, Any]) -> None:
        if event.get("type") == "repo_done":
            for k, v in (event.get("behavior") or {}).items():
                behavior_totals[k] = behavior_totals.get(k, 0) + int(v)

    def cb_wrapped(event: dict[str, Any]) -> None:
        aggregate_behavior(event)
        cb(event)

    try:
        summary = scan_mod.run(
            source_root=Path(job.source_root),
            output_root=Path(job.output_root),
            quiet=True,
            respect_metadata=options.get("respect_metadata", True),
            detect_secrets=options.get("detect_secrets", True),
            detect_sast=options.get("detect_sast", True),
            detect_cves=options.get("detect_cves", True),
            detect_behavior=options.get("detect_behavior", True),
            detect_signatures=options.get("detect_signatures", True),
            signature_network_lookup=options.get("signature_network_lookup", True),
            detect_install_scripts=options.get("detect_install_scripts", True),
            detect_iac=options.get("detect_iac", False),
            detect_containers=options.get("detect_containers", False),
            progress_callback=cb_wrapped,
        )
        job.summary = {
            "duration_s": summary["duration_s"],
            "repos_scanned": summary["repos_scanned"],
            "rollup_count": summary["rollup_count"],
            "by_severity": summary["findings"]["by_severity"],
            "total_findings": summary["findings"]["total_findings"],
            "log_dir": summary["log_dir"],
            "sbom_dir": summary["sbom_dir"],
        }
        job.status = "complete"
        _record_event(job, {"type": "status", "status": "complete",
                            "summary": job.summary})
        try:
            history_mod.record(history_mod.HistoryEntry(
                job_id=job.job_id,
                source_root=job.source_root,
                output_root=job.output_root,
                started_at=job.started_at,
                finished_at=time.time(),
                duration_s=float(summary["duration_s"]),
                status="complete",
                repos_scanned=int(summary["repos_scanned"]),
                total_findings=int(summary["findings"]["total_findings"]),
                by_severity=dict(summary["findings"]["by_severity"]),
                behavior_profile=dict(behavior_totals),
            ))
        except Exception:
            pass  # history write must never fail the scan
    except Exception as e:
        job.error = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        job.status = "error"
        _record_event(job, {"type": "error", "message": str(e)})
        _record_event(job, {"type": "status", "status": "error"})
        try:
            history_mod.record(history_mod.HistoryEntry(
                job_id=job.job_id,
                source_root=job.source_root,
                output_root=job.output_root,
                started_at=job.started_at,
                finished_at=time.time(),
                duration_s=time.time() - job.started_at,
                status="error",
                error=str(e),
            ))
        except Exception:
            pass
    finally:
        _mark_finished(job)


# ── App factory ──────────────────────────────────────────────────────────

def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )

    @app.get("/")
    def index() -> Any:
        return render_template("index.html")

    @app.get("/api/ping")
    def api_ping() -> Any:
        """Identity probe used by the single-instance launcher and any
        external orchestration. Stable shape; safe to depend on."""
        cfg = config_mod.load()
        return jsonify({
            "app": "hiddenshadow",
            "version": __version__,
            "deployment_tier": cfg.deployment_tier,
            "pid": os.getpid(),
            "uptime_s": round(time.time() - _APP_STARTED, 2),
        })

    @app.get("/api/config")
    def api_config() -> Any:
        """Return the active configuration (for diagnostics)."""
        cfg = config_mod.load()
        return jsonify(config_mod.as_dict(cfg))

    @app.get("/api/drives")
    def api_drives() -> Any:
        return jsonify({"drives": _list_drives()})

    @app.get("/api/browse")
    def api_browse() -> Any:
        path = request.args.get("path", "")
        if not path:
            return jsonify({"error": "Missing 'path' query parameter"}), 400
        return jsonify(_safe_browse(path))

    @app.post("/api/scan")
    def api_scan() -> Any:
        body = request.get_json(silent=True) or {}
        source_root = (body.get("source_root") or "").strip()
        output_root = (body.get("output_root") or "").strip() or source_root
        respect_metadata = bool(body.get("respect_metadata", True))
        detect_secrets = bool(body.get("detect_secrets", True))
        detect_sast = bool(body.get("detect_sast", True))
        detect_cves = bool(body.get("detect_cves", True))
        detect_behavior = bool(body.get("detect_behavior", True))
        detect_signatures = bool(body.get("detect_signatures", True))
        signature_network_lookup = bool(body.get("signature_network_lookup", True))
        detect_install_scripts = bool(body.get("detect_install_scripts", True))
        detect_iac = bool(body.get("detect_iac", False))
        detect_containers = bool(body.get("detect_containers", False))

        if not source_root:
            return jsonify({"error": "source_root is required"}), 400
        if not Path(source_root).exists():
            return jsonify({"error": f"Path does not exist: {source_root}"}), 400
        if not Path(source_root).is_dir():
            return jsonify({"error": f"Not a directory: {source_root}"}), 400

        job_id = uuid.uuid4().hex
        job = ScanJob(
            job_id=job_id,
            source_root=str(Path(source_root).resolve()),
            output_root=str(Path(output_root).resolve()),
        )
        with _jobs_lock:
            _jobs[job_id] = job

        threading.Thread(
            target=_run_scan,
            args=(job, {
                "respect_metadata": respect_metadata,
                "detect_secrets": detect_secrets,
                "detect_sast": detect_sast,
                "detect_cves": detect_cves,
                "detect_behavior": detect_behavior,
                "detect_signatures": detect_signatures,
                "signature_network_lookup": signature_network_lookup,
                "detect_install_scripts": detect_install_scripts,
                "detect_iac": detect_iac,
                "detect_containers": detect_containers,
            }),
            daemon=True, name=f"scan-{job_id[:8]}",
        ).start()
        return jsonify({"job_id": job_id, "source_root": job.source_root,
                        "output_root": job.output_root})

    @app.get("/api/scan/<job_id>/events")
    def api_scan_events(job_id: str) -> Any:
        job = _jobs.get(job_id)
        if not job:
            return jsonify({"error": "unknown job_id"}), 404

        def stream() -> Any:
            backlog, queue = _subscribe(job)
            try:
                for ev in backlog:
                    yield f"data: {json.dumps(ev)}\n\n"
                if queue is None:
                    return
                while True:
                    try:
                        ev = queue.get(timeout=15.0)
                    except Empty:
                        yield ": keep-alive\n\n"
                        continue
                    if ev is _END:
                        return
                    yield f"data: {json.dumps(ev)}\n\n"
            finally:
                if queue is not None:
                    _unsubscribe(job, queue)

        return Response(stream(), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache",
                                 "X-Accel-Buffering": "no"})

    @app.get("/api/scan/<job_id>/findings")
    def api_scan_findings(job_id: str) -> Any:
        job = _jobs.get(job_id)
        if not job:
            return jsonify({"error": "unknown job_id"}), 404
        if job.status != "complete":
            return jsonify({"error": f"job status is {job.status}"}), 409
        log_path = Path(job.output_root) / "_logs" / "scan-findings.json"
        if not log_path.exists():
            return jsonify({"error": "scan-findings.json missing"}), 500
        return Response(
            log_path.read_text(encoding="utf-8"),
            mimetype="application/json",
        )

    def _resolve_scan_output(job_id: str) -> tuple[Path | None, dict[str, Any] | None, Response | None]:
        """Locate the output_root for either an active job or a historical
        scan. Returns (output_root, summary, error_response). Exactly one
        of (output_root, error_response) is non-None on success."""
        job = _jobs.get(job_id)
        if job is not None:
            if job.status != "complete":
                return None, None, (jsonify({"error": f"job status is {job.status}"}), 409)
            return Path(job.output_root), job.summary, None

        # Fall through to the persisted history index — lets past scans
        # remain viewable / exportable across server restarts.
        entries = history_mod.load_all()
        entry = next((e for e in entries if e.job_id == job_id), None)
        if entry is None:
            return None, None, (jsonify({"error": "unknown job_id"}), 404)
        if entry.status != "complete":
            return None, None, (jsonify({"error": f"job status is {entry.status}"}), 409)
        synthesized = {
            "duration_s": entry.duration_s,
            "repos_scanned": entry.repos_scanned,
            "by_severity": entry.by_severity,
            "total_findings": entry.total_findings,
            "log_dir": str(Path(entry.output_root) / "_logs"),
            "sbom_dir": str(Path(entry.output_root) / "sboms"),
        }
        return Path(entry.output_root), synthesized, None

    def _load_findings_for_export(job_id: str) -> tuple[list[dict[str, Any]], dict[str, Any] | None] | tuple[None, Response]:
        """Resolve the findings list + summary for any completed scan
        (active job OR history entry)."""
        output_root, summary, err = _resolve_scan_output(job_id)
        if err is not None:
            return None, err
        log_path = output_root / "_logs" / "scan-findings.json"
        if not log_path.exists():
            return None, (jsonify({
                "error": "artifacts no longer present",
                "detail": f"scan-findings.json missing under {output_root}",
            }), 410)
        data = json.loads(log_path.read_text(encoding="utf-8"))
        return data.get("findings", []), summary

    @app.get("/api/scan/<job_id>/export.xlsx")
    def api_scan_export_xlsx(job_id: str) -> Any:
        findings, summary = _load_findings_for_export(job_id)
        if findings is None:
            return summary  # error tuple
        from . import exporters
        blob = exporters.build_xlsx(findings, summary)
        return Response(
            blob,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition":
                    f'attachment; filename="hiddenshadow-scan-{job_id[:8]}.xlsx"',
            },
        )

    @app.get("/api/scan/<job_id>/export.pptx")
    def api_scan_export_pptx(job_id: str) -> Any:
        findings, summary = _load_findings_for_export(job_id)
        if findings is None:
            return summary  # error tuple
        from . import exporters
        blob = exporters.build_pptx(findings, summary)
        return Response(
            blob,
            mimetype="application/vnd.openxmlformats-officedocument.presentationml.presentation",
            headers={
                "Content-Disposition":
                    f'attachment; filename="hiddenshadow-scan-{job_id[:8]}.pptx"',
            },
        )

    @app.post("/api/scan/<job_id>/save_report")
    def api_scan_save_report(job_id: str) -> Any:
        """Write an Excel or PowerPoint report to a server-side folder
        chosen by the user, instead of streaming to the browser's Downloads.

        Body: {"format": "xlsx"|"pptx", "dir": "<absolute folder path>"}
        Returns: {"path": "<full file path written>"}
        """
        body = request.get_json(silent=True) or {}
        fmt = (body.get("format") or "").lower()
        out_dir = (body.get("dir") or "").strip()
        if fmt not in ("xlsx", "pptx"):
            return jsonify({"error": "format must be 'xlsx' or 'pptx'"}), 400
        if not out_dir:
            return jsonify({"error": "dir is required"}), 400

        out_path = Path(out_dir)
        try:
            out_path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return jsonify({"error": f"cannot create folder: {e}"}), 400
        if not out_path.is_dir():
            return jsonify({"error": f"not a directory: {out_dir}"}), 400

        findings, summary = _load_findings_for_export(job_id)
        if findings is None:
            return summary  # error tuple

        from . import exporters
        if fmt == "xlsx":
            blob = exporters.build_xlsx(findings, summary)
        else:
            blob = exporters.build_pptx(findings, summary)

        ts = time.strftime("%Y%m%d-%H%M%S")
        fname = f"hiddenshadow-scan-{job_id[:8]}-{ts}.{fmt}"
        target = out_path / fname
        try:
            target.write_bytes(blob)
        except OSError as e:
            return jsonify({"error": f"failed to write file: {e}"}), 500
        return jsonify({"path": str(target)})

    @app.get("/api/scans")
    def api_scans_list() -> Any:
        """Return the persistent scan-history index, newest first."""
        entries = history_mod.load_all()
        return jsonify({
            "history_file": history_mod.history_file_path(),
            "count": len(entries),
            "scans": [
                {
                    "job_id": e.job_id,
                    "source_root": e.source_root,
                    "output_root": e.output_root,
                    "display_name": e.display_name(),
                    "started_at": e.started_at,
                    "finished_at": e.finished_at,
                    "duration_s": e.duration_s,
                    "status": e.status,
                    "repos_scanned": e.repos_scanned,
                    "total_findings": e.total_findings,
                    "by_severity": e.by_severity,
                    "behavior_profile": e.behavior_profile,
                    "error": e.error,
                    "label": e.label,
                    # The findings file may or may not still exist on disk;
                    # this lets the UI offer a "View artifacts" link that the
                    # /artifact endpoint can resolve.
                    "artifacts_present": (
                        Path(e.output_root) / "_logs" / "scan-findings.json"
                    ).exists(),
                }
                for e in entries
            ],
        })

    @app.get("/api/scans/<job_id>/findings")
    def api_scans_findings(job_id: str) -> Any:
        """Load the persisted findings.json for a historical scan.

        Differs from ``/api/scan/<job_id>/findings`` (singular "scan"),
        which only reads from in-memory job state and 404s as soon as
        the launcher restarts. This endpoint resolves output_root from
        the history index and reads the artifact off disk, so past
        scans remain viewable across server restarts.
        """
        entries = history_mod.load_all()
        entry = next((e for e in entries if e.job_id == job_id), None)
        if entry is None:
            return jsonify({"error": "no such scan"}), 404
        findings_path = Path(entry.output_root) / "_logs" / "scan-findings.json"
        if not findings_path.exists():
            return jsonify({
                "error": "artifacts no longer present",
                "detail": f"scan-findings.json missing under {entry.output_root}. "
                          "The output directory was likely overwritten by a "
                          "later scan or removed manually.",
            }), 410   # Gone — entry exists but the linked artifact does not.
        return Response(
            findings_path.read_text(encoding="utf-8"),
            mimetype="application/json",
        )

    @app.delete("/api/scans/<job_id>")
    def api_scans_delete(job_id: str) -> Any:
        """Delete one history entry. With ?artifacts=1, also remove the
        scan-specific artifact files under that scan's output_root."""
        also_artifacts = request.args.get("artifacts", "").lower() in {"1", "true", "yes"}
        if also_artifacts:
            result = history_mod.delete_with_artifacts(job_id)
            if not result["removed_entry"]:
                return jsonify({"error": "no such scan"}), 404
            return jsonify(result)
        ok = history_mod.delete(job_id)
        if not ok:
            return jsonify({"error": "no such scan"}), 404
        return jsonify({"removed_entry": True})

    @app.delete("/api/scans")
    def api_scans_clear() -> Any:
        """Wipe the entire scan history. Does not touch any artifacts."""
        n = history_mod.clear_all()
        return jsonify({"removed": n})

    @app.post("/api/shutdown")
    def api_shutdown() -> Any:
        """Stop the launcher process. Used by the UI's Stop button so the
        windowed (no-console) build can be quit cleanly."""
        def _kill() -> None:
            time.sleep(0.2)  # let the response flush
            os._exit(0)
        threading.Thread(target=_kill, daemon=True).start()
        return jsonify({"stopping": True})

    @app.get("/api/scan/<job_id>/artifact")
    def api_scan_artifact(job_id: str) -> Any:
        """Download a scan artifact. Resolves the scan's output_root via
        either the active job table or the persistent history index (so
        artifacts of past scans remain downloadable across restarts).
        Restricted to files under that scan's output_root."""
        # Active job?
        job = _jobs.get(job_id)
        out_root: Path | None = None
        if job is not None:
            out_root = Path(job.output_root).resolve()
        else:
            entry = next(
                (e for e in history_mod.load_all() if e.job_id == job_id),
                None,
            )
            if entry is not None:
                out_root = Path(entry.output_root).resolve()
        if out_root is None:
            abort(404)
        rel = request.args.get("file", "")
        if not rel:
            abort(400)
        target = (out_root / rel).resolve()
        # Refuse path traversal outside the scan's output_root.
        if out_root not in target.parents and target != out_root:
            abort(403)
        if not target.exists() or not target.is_file():
            abort(404)
        return send_file(target, as_attachment=True,
                         download_name=target.name)

    # Register the aux-scanner endpoints (tfscan, containerscan, ci-scan,
    # check, watch) from web_endpoints. Keeps the new code isolated from
    # the main-scan flow above.
    from . import web_endpoints
    web_endpoints.register(app)

    return app


def serve(host: str = "127.0.0.1", port: int = 7878,
          debug: bool = False, auth_token: str | None = None) -> None:
    from . import web_endpoints
    web_endpoints.set_auth_token(auth_token)
    app = create_app()
    print(f"hiddenshadow web UI -> http://{host}:{port}")
    if auth_token:
        print(f"  auth: requires header X-HS-Token: {auth_token}")
    elif host not in ("127.0.0.1", "localhost"):
        print("  WARNING: bound to non-localhost without --auth-token; "
              "anyone on the network can trigger scans.")
    app.run(host=host, port=port, debug=debug, threaded=True)
