"""License detection patterns + classification policy.

Detects SPDX license from LICENSE-file content using regex patterns.
Classifies SPDX ids per ARCHITECTURE.md §1.2 policy: permissive,
weak-copyleft, strong-copyleft, network-copyleft, source-available,
public-domain.

This module is the canonical license-knowledge for the scanner. To
extend support for a new license, add a pattern here.
"""
from __future__ import annotations
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class LicenseInfo:
    spdx: str
    classification: str
    decision: str  # adopt | library | avoid | unknown
    notes: str = ""


# Order matters — most-specific patterns first so generic phrases
# (e.g., "MIT License") don't shadow more specific ones (e.g., BUSL).
LICENSE_PATTERNS: list[tuple[str, list[re.Pattern]]] = [
    # ─── Source-available (must come BEFORE Apache/MIT) ───────────────
    ("BUSL-1.1", [
        re.compile(r"Business Source License", re.I),
        re.compile(r"BUSL[\s-]?1\.1", re.I),
    ]),
    ("SSPL-1.0", [
        re.compile(r"Server Side Public License", re.I),
        re.compile(r"\bSSPL\b", re.I),
    ]),
    ("Elastic-2.0", [
        re.compile(r"Elastic License\s+2\.0", re.I),
        re.compile(r"\bELv2\b", re.I),
    ]),
    ("Confluent-Community-License", [
        re.compile(r"Confluent Community License", re.I),
    ]),

    # ─── Network copyleft ──────────────────────────────────────────────
    ("AGPL-3.0", [
        re.compile(r"GNU Affero General Public License", re.I),
        re.compile(r"\bAGPL\b", re.I),
    ]),

    # ─── Strong copyleft ───────────────────────────────────────────────
    ("GPL-3.0", [
        re.compile(r"GNU General Public License[\s\n]+(?:.+\s+)?[Vv]ersion 3", re.I | re.DOTALL),
        re.compile(r"GPL-?3\b", re.I),
    ]),
    ("GPL-2.0", [
        re.compile(r"GNU General Public License[\s\n]+(?:.+\s+)?[Vv]ersion 2", re.I | re.DOTALL),
        re.compile(r"GPL-?2\b", re.I),
    ]),

    # ─── Weak copyleft ─────────────────────────────────────────────────
    ("LGPL-3.0", [
        re.compile(r"GNU Lesser General Public License[\s\n]+(?:.+\s+)?[Vv]ersion 3", re.I | re.DOTALL),
        re.compile(r"LGPL-?3\b", re.I),
    ]),
    ("LGPL-2.1", [
        re.compile(r"GNU Lesser General Public License[\s\n]+(?:.+\s+)?[Vv]ersion 2\.1", re.I | re.DOTALL),
        re.compile(r"LGPL-?2\.1\b", re.I),
    ]),
    ("LGPL-2.0", [
        re.compile(r"GNU Library General Public License", re.I),
    ]),
    ("MPL-2.0", [
        re.compile(r"Mozilla Public License,?\s+v\.\s*2\.0", re.I),
        re.compile(r"Mozilla Public License\s+Version 2\.0", re.I),
    ]),
    ("EPL-2.0", [
        re.compile(r"Eclipse Public License\s+-?\s*v?\s*2\.0", re.I),
    ]),

    # ─── Permissive ────────────────────────────────────────────────────
    ("Apache-2.0", [
        re.compile(r"Apache License,?\s+Version 2\.0", re.I),
        re.compile(r"licensed under the Apache", re.I),
    ]),
    ("MIT", [
        re.compile(r"MIT License", re.I),
        re.compile(
            r"Permission is hereby granted, free of charge, to any person obtaining",
            re.I,
        ),
    ]),
    ("BSD-3-Clause", [
        # The "no endorsement" clause distinguishes 3-Clause from 2-Clause.
        # Variant 1 — boilerplate: "Neither the name of <holder>, nor the names of"
        # Variant 2 — Meta/zstd-style: "Neither the name Facebook, nor Meta, nor the names of"
        re.compile(
            r"Redistribution and use in source and binary forms.+"
            r"[Nn]either the name(?:s)?(?:\s+(?:of|[A-Z][A-Za-z]*))",
            re.I | re.DOTALL,
        ),
    ]),
    ("BSD-2-Clause", [
        re.compile(
            r"Redistribution and use in source and binary forms.+"
            r"this list of conditions and the following disclaimer",
            re.I | re.DOTALL,
        ),
    ]),
    ("ISC", [
        re.compile(r"Permission to use, copy, modify, and(/or)? distribute", re.I),
    ]),
    ("PostgreSQL", [
        re.compile(r"PostgreSQL Database Management System", re.I),
        re.compile(r"PostgreSQL is released under the PostgreSQL License", re.I),
    ]),
    ("Zlib", [
        re.compile(r"This software is provided 'as-is', without any express or implied", re.I),
    ]),

    # ─── Public domain / dedications ───────────────────────────────────
    ("Unlicense", [
        re.compile(r"This is free and unencumbered software released into the public domain", re.I),
    ]),
    ("CC0-1.0", [
        re.compile(r"Creative Commons CC0\s+1\.0\s+Universal", re.I),
        re.compile(r"\bCC0\s+1\.0\b", re.I),
    ]),
    ("CC-BY-4.0", [
        re.compile(r"Creative Commons Attribution 4\.0", re.I),
    ]),

    # ─── Special-purpose ───────────────────────────────────────────────
    ("DRL-1.1", [
        re.compile(r"Detection Rule License", re.I),
        re.compile(r"DRL-?1\.1", re.I),
    ]),
    ("MITRE-ATT&CK-License", [
        re.compile(
            r"The MITRE Corporation \(MITRE\) hereby grants you a non-exclusive, royalty-free license",
            re.I,
        ),
        re.compile(r"non-exclusive,?\s+royalty-free license to use ATT", re.I),
    ]),
    ("CIS-Use-Agreement", [
        re.compile(r"Center for Internet Security[^.]*Terms of Use", re.I),
        re.compile(r"CIS Controls", re.I),
    ]),

    # ─── First-party proprietary ───────────────────────────────────────
    # Marks the host project's own internal license; not a third-party
    # adoption decision — these classify as "proprietary / first-party".
    ("LicenseRef-DarkShadowSec-Proprietary", [
        re.compile(r"DarkShadowSec(?:\s+LLC)?\s*[-–—]?\s*Proprietary", re.I),
        re.compile(r"Proprietary\s*[-–—]?\s*DarkShadowSec(?:\s+LLC)?", re.I),
        re.compile(r"HiddenShadow\s*[-–—]?\s*Proprietary License", re.I),
        re.compile(r"Copyright\s*\(c\)\s*DarkShadowSec\s+LLC", re.I),
    ]),
]


# SPDX → (classification, decision)
LICENSE_CLASS: dict[str, tuple[str, str]] = {
    "MIT":           ("permissive",       "adopt"),
    "Apache-2.0":    ("permissive",       "adopt"),
    "BSD-2-Clause":  ("permissive",       "adopt"),
    "BSD-3-Clause":  ("permissive",       "adopt"),
    "ISC":           ("permissive",       "adopt"),
    "Zlib":          ("permissive",       "adopt"),
    "PostgreSQL":    ("permissive",       "adopt"),
    "Unlicense":     ("public-domain",    "adopt"),
    "CC0-1.0":       ("public-domain",    "adopt"),
    "CC-BY-4.0":     ("permissive",       "adopt"),
    "DRL-1.1":       ("permissive",       "adopt"),
    "MITRE-ATT&CK-License":  ("permissive", "adopt"),
    "CIS-Use-Agreement":     ("permissive", "adopt"),
    "MPL-2.0":       ("weak-copyleft",    "library"),
    "LGPL-2.0":      ("weak-copyleft",    "library"),
    "LGPL-2.1":      ("weak-copyleft",    "library"),
    "LGPL-3.0":      ("weak-copyleft",    "library"),
    "EPL-2.0":       ("weak-copyleft",    "library"),
    "GPL-2.0":       ("strong-copyleft",  "avoid"),
    "GPL-3.0":       ("strong-copyleft",  "avoid"),
    "AGPL-3.0":      ("network-copyleft", "avoid"),
    "BUSL-1.1":      ("source-available", "avoid"),
    "SSPL-1.0":      ("source-available", "avoid"),
    "Elastic-2.0":   ("source-available", "avoid"),
    "Confluent-Community-License":
                     ("source-available", "avoid"),
    "LicenseRef-DarkShadowSec-Proprietary":
                     ("proprietary",      "first-party"),
}


def detect_license_from_text(text: str) -> str | None:
    """Return the SPDX id for the first matching license pattern."""
    snippet = text[:50_000]
    for spdx_id, patterns in LICENSE_PATTERNS:
        for p in patterns:
            if p.search(snippet):
                return spdx_id
    return None


def classify(spdx: str) -> LicenseInfo:
    """Return the classification + policy decision for an SPDX id."""
    spdx = (spdx or "").strip()
    cls, dec = LICENSE_CLASS.get(spdx, ("unknown", "unknown"))
    return LicenseInfo(spdx=spdx, classification=cls, decision=dec)


# ─── License-file & path detection rules ──────────────────────────────────


# Files that are LICENSE/COPYING/etc. Case-sensitive uppercase prefix so
# source files such as `internal/spdxlicense/license.go` (which contain
# license *data* rather than being license declarations) are not
# misidentified.
#
# Accepts both doc-style extensions (LICENSE.txt, LICENSE.md) and
# dual-license naming variants (LICENSE-MIT, LICENSE-Apache-2.0,
# LICENSE.BSD, COPYING.LESSER). The optional suffix may use '-' or '.'
# as the separator and may itself include extra '.'/'-' characters.
LICENSE_FILE_NAMES = re.compile(
    r"^(LICENSE|LICENCE|COPYING|COPYRIGHT|NOTICE|UNLICENSE)"
    r"([-.][A-Za-z0-9][\w.+\-]*)?$",
)

# Path components that mean a file is *about* licenses (documentation)
# or is a test fixture, rather than governing the project.
NON_AUTHORITATIVE_LICENSE_PATHS = {
    "docs", "doc", "documentation",
    "examples", "example",
    "samples", "sample",
    "tutorial", "tutorials",
    "testdata", "test_data", "test-data",
    "tests", "test",       # common Python/JS/Go convention
    "t",                   # Perl/C convention (e.g., libmaxminddb's t/)
    "fixtures",
    "spec", "specs",
    "scripts",
    "vendor",              # vendored deps live in vendor/; their LICENSE files are informational, not the project's
}


def is_authoritative_license_path(rel_path_parts: tuple[str, ...]) -> bool:
    """A LICENSE file is authoritative unless it's inside a docs/test path.

    rel_path_parts is the path components of the LICENSE file relative to
    the repo root, including the filename. We exclude the filename itself
    and check whether any parent directory is in NON_AUTHORITATIVE_LICENSE_PATHS.
    """
    return not any(
        part.lower() in NON_AUTHORITATIVE_LICENSE_PATHS
        for part in rel_path_parts[:-1]
    )
