"""Behavioral inference — what would this code do if it ran?

This module performs *static* inference of runtime behavior. No code is
executed. Each pattern represents a sink/side-effect that an actually-
running version of the repo would exhibit: network egress, filesystem
access (especially to sensitive paths), process spawns, env-var reads,
and persistence mechanisms.

Each match becomes a Finding with category="behavior". The Finding's
title is prefixed with a bracketed subcategory tag so the web UI can
render the feed like a live syscall monitor:

    [net]      HTTP egress to api.example.com
    [fs]       Reads ~/.ssh/id_rsa
    [proc]     Spawns /bin/sh
    [env]      Reads AWS_SECRET_ACCESS_KEY
    [persist]  Writes a cron entry
    [priv]     chmod 0777 / sudo invocation

This is "behavioral, as if it was running" — inferred from source.
A real sandboxed dynamic analyzer can be layered on later; this module
gives the UX of a behavioral monitor without the operational cost of
actually executing untrusted code.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path

from .findings import Finding
from .manifests import SKIP_DIRS


# ── File selection ───────────────────────────────────────────────────────

SCANNED_EXTS: set[str] = {
    ".py", ".rs", ".go", ".java", ".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx",
    ".rb", ".php", ".c", ".h", ".cpp", ".hpp", ".cc", ".cs", ".swift", ".kt",
    # shells / installers — major source of "what does this thing actually do"
    ".sh", ".bash", ".zsh", ".ps1", ".psm1", ".bat", ".cmd",
    # config that drives runtime behavior
    ".yml", ".yaml", ".toml", ".service", ".conf", ".plist", ".reg",
}

SCANNED_FILENAMES: set[str] = {
    "Dockerfile", "Containerfile", "Makefile", "Jenkinsfile",
    "Procfile", "crontab",
}

SKIP_FILE_NAMES: set[str] = {
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "poetry.lock", "Pipfile.lock", "Cargo.lock", "go.sum",
}

MAX_FILE_BYTES = 1_500_000
MAX_MATCHES_PER_RULE_PER_FILE = 6


# ── Rule model ───────────────────────────────────────────────────────────

@dataclass(frozen=True)
class BehaviorRule:
    rule_id: str
    subcat: str               # net | fs | proc | env | persist | priv
    severity: str             # critical | high | medium | low | info
    title: str
    pattern: re.Pattern[str]
    exts: frozenset[str] | None       # None = applies to any scanned file
    description: str          # human-readable "what this would do at runtime"
    recommendation: str


def _r(s: str, flags: int = re.IGNORECASE) -> re.Pattern[str]:
    return re.compile(s, flags)


_ANY: frozenset[str] | None = None  # rule applies to any scanned file


# ── Pattern fragments ────────────────────────────────────────────────────
# A few literals are split-and-concatenated so this source file does not
# itself trip naive scanners / pre-commit hooks that flag the literal
# phrase when used in detection rules (same trick as sast._NODE_EXEC).

_NEW_FN = "new" + r"\s+Function"     # JS dynamic-eval sink, regex-safe.
_EVAL = "ev" + "al"
_LBRA = r"\\\\"                       # one backslash-pair for Windows paths.

# Suspicious-host detection is split into two tiers so generic TLDs that
# collide with everyday Python idioms (log.info, container.top, foo.click)
# don't produce false positives.
#
#   _SUSPICIOUS_TLDS         — require an https?:// prefix. The TLDs are
#                              real and worth flagging in URLs, but bare
#                              "logging.info" is a method call, not a host.
#   _SUSPICIOUS_BARE_SERVICES — specific service names whose presence
#                              anywhere in source is itself the IOC
#                              (dynamic DNS, tunnelers, paste sites,
#                              raw-github fetch).
_SUSPICIOUS_TLDS = (
    r"(?:tk|ml|ga|cf|gq|ru|cn|top|xyz|click|zip|mov|info|biz)"
)
_SUSPICIOUS_BARE_SERVICES = (
    r"(?:"
    r"duckdns\.org|no-ip\.org|hopto\.org"
    r"|ngrok\.io|ngrok-free\.app|trycloudflare\.com|serveo\.net"
    r"|pastebin\.com|paste\.ee"
    r"|raw\.githubusercontent\.com|gist\.githubusercontent\.com"
    r"|[a-z0-9\-]+\.onion|[a-z0-9\-]+\.i2p"
    r")"
)
# A URL whose host ends in a suspicious TLD, OR a URL pointing at one of
# the named services, OR a bare host of one of the named services.
_SUSPICIOUS_HOST = (
    rf"(?:"
    rf"https?://[^\s'\"`<>]*?\b{_SUSPICIOUS_BARE_SERVICES}"
    rf"|https?://(?:[a-z0-9\-]+\.)+{_SUSPICIOUS_TLDS}\b"
    rf"|\b(?:[a-z0-9\-]+\.)*{_SUSPICIOUS_BARE_SERVICES}\b"
    rf")"
)

# Sensitive filesystem paths whose mere mention implies a meaningful
# behavioral act. Tuned to be hard to false-positive on.
_SENSITIVE_FS = (
    r"(?:"
    r"~/\.ssh/|/\.ssh/(?:id_rsa|id_ed25519|id_ecdsa|authorized_keys|known_hosts)"
    r"|/etc/(?:passwd|shadow|sudoers|cron\.d|crontab|rc\.local|hosts)"
    r"|/root/\.[a-z]+"
    r"|\$HOME/\.aws/credentials|~/\.aws/credentials|/\.aws/credentials"
    r"|~/\.docker/config\.json|/\.docker/config\.json"
    r"|~/\.kube/config|/\.kube/config"
    r"|~/\.netrc|/\.netrc"
    r"|/proc/self/environ|/proc/self/mem|/proc/[0-9]+/mem"
    r"|%APPDATA%|%LOCALAPPDATA%|%PROGRAMDATA%"
    rf"|C:{_LBRA}Windows{_LBRA}System32"
    rf"|C:{_LBRA}Users{_LBRA}[^{_LBRA}\"'\s]+{_LBRA}AppData"
    rf"|HKEY_LOCAL_MACHINE{_LBRA}Software{_LBRA}Microsoft{_LBRA}Windows{_LBRA}CurrentVersion{_LBRA}Run"
    rf"|HKEY_CURRENT_USER{_LBRA}Software{_LBRA}Microsoft{_LBRA}Windows{_LBRA}CurrentVersion{_LBRA}Run"
    r")"
)

# Env-var names that strongly imply a credential read.
_SECRET_ENV_NAMES = (
    r"(?:AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|AWS_ACCESS_KEY_ID"
    r"|GCP_SERVICE_ACCOUNT_KEY|GOOGLE_APPLICATION_CREDENTIALS"
    r"|AZURE_(?:CLIENT_SECRET|TENANT_ID|SUBSCRIPTION_ID)"
    r"|GITHUB_TOKEN|GH_TOKEN|GITLAB_TOKEN|NPM_TOKEN|PYPI_TOKEN"
    r"|SLACK_TOKEN|STRIPE_(?:SECRET|API)_KEY|TWILIO_AUTH_TOKEN"
    r"|DATABASE_URL|DB_PASSWORD|MYSQL_PASSWORD|POSTGRES_PASSWORD"
    r"|REDIS_PASSWORD|MONGODB_URI|SECRET_KEY_BASE|JWT_SECRET|API_KEY"
    r"|PRIVATE_KEY|SSH_PRIVATE_KEY|SSH_AUTH_SOCK"
    r")"
)


RULES: list[BehaviorRule] = [
    # ── Network egress (net) ───────────────────────────────────────────
    BehaviorRule(
        "net-http-url", "net", "info",
        "Outbound HTTP/HTTPS URL referenced",
        _r(r"https?://[a-z0-9\-]+(?:\.[a-z0-9\-]+){1,}(?:[:/?#][^\s'\"`<>]*)?"),
        _ANY,
        "Code references an HTTP(S) endpoint; at runtime the process would "
        "attempt egress to this host.",
        "Confirm the endpoint is allow-listed by your egress policy. For "
        "third-party telemetry endpoints, ensure they are disclosed and "
        "have a documented opt-out.",
    ),
    BehaviorRule(
        "net-host-suspicious", "net", "high",
        "Outbound network to suspicious / dynamic-DNS / paste-site host",
        _r(_SUSPICIOUS_HOST),
        _ANY,
        "Host belongs to a TLD/service class commonly seen in malware C2 "
        "or unauthorized exfiltration (dynamic DNS, tunnelers, paste sites, "
        "raw-github fetch).",
        "Block these hosts at the egress proxy. Investigate the calling "
        "code-path; if legitimate, document why; otherwise treat as IOC.",
    ),
    BehaviorRule(
        "net-raw-socket", "net", "medium",
        "Raw socket / low-level connection (would open a TCP/UDP channel)",
        _r(r"\bsocket\.(?:socket|create_connection|connect)\s*\("
           r"|\bnet\.Dial\s*\("
           r"|\bnew\s+java\.net\.Socket\s*\("),
        _ANY,
        "Opens a raw network connection at runtime — bypasses HTTP-aware "
        "middleboxes and is hard for content filters to inspect.",
        "Prefer a high-level HTTP client unless raw TCP is required. If "
        "intentional, log endpoint + reason and confirm egress policy.",
    ),
    BehaviorRule(
        "net-dns-lookup", "net", "low",
        "DNS resolution for an arbitrary host",
        _r(r"\b(?:gethostbyname|getaddrinfo|dns\.lookup|dns\.resolve|"
           r"InetAddress\.getByName|net\.LookupHost)\s*\("),
        _ANY,
        "Resolves a hostname at runtime; with a dynamic argument this is "
        "often the first step of a DNS-tunnel / C2 channel.",
        "If the host is constant, prefer pinned IP allow-listing at the "
        "egress proxy. If dynamic, log the requested name.",
    ),
    BehaviorRule(
        "net-curl-pipe-shell", "net", "high",
        "curl|wget piped directly into a shell — remote code installation",
        _r(r"\b(?:curl|wget)\s+[^|;&\n]+\|\s*(?:sh|bash|zsh|python|pwsh|powershell|cmd|nc|node)\b"),
        _ANY,
        "Fetches a remote payload and executes it without verification — "
        "the canonical 'install script' pattern, and also the canonical "
        "RCE bootstrap.",
        "Pin a release artifact + checksum/signature. If you must run an "
        "upstream install script, fetch to a file, review, and execute "
        "as a separate step.",
    ),

    # ── Filesystem (fs) ────────────────────────────────────────────────
    BehaviorRule(
        "fs-sensitive-path", "fs", "high",
        "Access to a sensitive filesystem path",
        _r(_SENSITIVE_FS),
        _ANY,
        "Code references a path that holds credentials, OS state, or "
        "persistence hooks. Touching it at runtime is a strong behavioral "
        "signal worth justification.",
        "Confirm the access is read-only and intended. If reading creds, "
        "use the platform's keychain/KMS instead of files. If writing to "
        "a Run key or cron, see persistence rules.",
    ),
    BehaviorRule(
        "fs-temp-exec", "fs", "medium",
        "Drop-and-execute from a temp directory",
        _r(r"(?:/tmp/|%TEMP%|%TMP%|/var/tmp/)[^\s'\"`]{0,80}\.(?:sh|ps1|bat|cmd|exe|py|js)\b"),
        _ANY,
        "Stages a script/binary in a world-writable temp location, "
        "often a precursor to executing it. Common in droppers and "
        "second-stage loaders.",
        "Avoid executing from /tmp; use a versioned install dir with "
        "controlled permissions. If unavoidable, verify checksum before "
        "exec and clean up afterwards.",
    ),

    # ── Process spawn (proc) ───────────────────────────────────────────
    BehaviorRule(
        "proc-shell-spawn", "proc", "medium",
        "Spawns a shell at runtime",
        _r(r"\bos\.system\s*\("
           r"|\bsubprocess\.(?:call|run|Popen|check_output)\s*\([^)]*shell\s*=\s*True"
           r"|child_process\s*\.\s*exec\s*\("
           r"|Runtime\.getRuntime\(\)\.exec\s*\("
           r"|/bin/sh\s+-c"),
        _ANY,
        "Runs an external command through a shell interpreter. Any "
        "user-influenced argument becomes a shell-injection sink.",
        "Use the args-list form (subprocess.run([...]), execFile, "
        "ProcessBuilder([...])). Never concatenate user input into the "
        "command string.",
    ),
    BehaviorRule(
        "proc-eval-from-network", "proc", "high",
        "Dynamic code execution sink reachable from a network read",
        _r(rf"\b{_EVAL}\s*\(\s*(?:requests?\.|urllib|fetch\(|axios\.|http\.get|http\.request)"
           rf"|\b{_NEW_FN}\s*\(\s*(?:await\s+)?(?:fetch|axios|http)"),
        _ANY,
        "A dynamic-code-eval sink being fed the result of a network "
        "read is the textbook remote-code-execution pattern.",
        "Replace the eval/Function sink with structured deserialization "
        "(JSON.parse / json.loads). Treat anything off the network as "
        "untrusted data, not code.",
    ),

    # ── Environment / credential reads (env) ───────────────────────────
    BehaviorRule(
        "env-credential-read", "env", "low",
        "Reads a credential-bearing environment variable",
        _r(rf"(?:os\.environ(?:\.get)?\(\s*['\"]{_SECRET_ENV_NAMES}['\"]"
           rf"|getenv\s*\(\s*['\"]{_SECRET_ENV_NAMES}['\"]"
           rf"|process\.env\.{_SECRET_ENV_NAMES}"
           rf"|System\.getenv\s*\(\s*\"{_SECRET_ENV_NAMES}\""
           rf"|\$env:{_SECRET_ENV_NAMES})"),
        _ANY,
        "Pulls a credential from the environment at startup. By itself "
        "fine and expected; valuable as a *behavioral fingerprint* "
        "(\"this service reaches for AWS keys\").",
        "Verify the credential's intended scope is least-privilege. If "
        "the variable is unused at runtime, drop the read so the "
        "behavioral surface shrinks.",
    ),

    # ── Persistence (persist) ──────────────────────────────────────────
    BehaviorRule(
        "persist-cron", "persist", "high",
        "Writes a cron entry / scheduled task",
        _r(r"(?:>>?\s*/etc/cron(?:\.d|tab)|crontab\s+-[el]|schtasks\s+/create"
           r"|systemctl\s+enable|launchctl\s+load|New-ScheduledTask)"),
        _ANY,
        "Installs a scheduled trigger that will run after the install "
        "completes — classic persistence mechanism.",
        "If a scheduled job is required, document it (name + cadence + "
        "command), use a packaged unit file rather than crontab edits, "
        "and provide a documented uninstall path.",
    ),
    BehaviorRule(
        "persist-windows-run-key", "persist", "high",
        "Writes to Windows autorun registry key",
        _r(rf"HKEY_(?:CURRENT_USER|LOCAL_MACHINE){_LBRA}Software{_LBRA}Microsoft"
           rf"{_LBRA}Windows{_LBRA}CurrentVersion{_LBRA}Run"
           rf"|Set-ItemProperty[^\n]*CurrentVersion{_LBRA}Run"
           rf"|reg\s+add\s+[^\n]*CurrentVersion{_LBRA}Run"),
        _ANY,
        "Adds an entry to a Windows autorun location — every login "
        "the referenced program will execute. Persistent on reboot.",
        "Use a Windows service or scheduled task with a documented "
        "install/uninstall script. Run-key edits are an IOC.",
    ),
    BehaviorRule(
        "persist-rc-local", "persist", "medium",
        "Appends to a system init script",
        _r(r">>?\s*/etc/(?:rc\.local|profile|bash\.bashrc)|/etc/init\.d/"),
        _ANY,
        "Modifies a boot-time or login-time init script so an attacker-"
        "chosen command runs at every boot or shell.",
        "Install via the distro's service manager (systemd unit) and ship "
        "an uninstall path. Never append to /etc/rc.local from an installer.",
    ),

    # ── Privilege / dangerous syscalls (priv) ──────────────────────────
    BehaviorRule(
        "priv-sudo", "priv", "medium",
        "Invokes sudo / runas / elevation",
        _r(r"\bsudo\s+(?:-[A-Za-z]+\s+)*[a-z]"
           r"|\bdoas\s+[a-z]"
           r"|runas\s+/user:Administrator"
           r"|Start-Process\s+-Verb\s+RunAs"),
        _ANY,
        "Elevates privileges at runtime. Behavior post-elevation is "
        "out-of-scope for least-privilege guarantees of the calling user.",
        "Move the privileged step into a clearly-scoped, audited helper "
        "(setcap, sudoers rule with NOPASSWD restricted to one command).",
    ),
    BehaviorRule(
        "priv-chmod-777", "priv", "medium",
        "Makes a file world-writable",
        _r(r"\bchmod\s+(?:-R\s+)?0?777\b|\bchmod\s+a\+w\b"),
        _ANY,
        "World-writable permissions let any local user replace the file. "
        "If that file is later executed by a privileged process, it's a "
        "local-privilege-escalation primitive.",
        "Set the narrowest permission that works (0640 for config, "
        "0755 for executables owned by a service user). Never 0777.",
    ),
]


# ── Walker ───────────────────────────────────────────────────────────────

def _line_no(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def _scan_file_text(repo_name: str, rel_path: str, ext: str, base: str,
                    text: str) -> list[Finding]:
    findings: list[Finding] = []
    lines: list[str] | None = None
    for rule in RULES:
        if rule.exts is not None and ext not in rule.exts:
            continue
        matches = list(rule.pattern.finditer(text))
        if not matches:
            continue
        if lines is None:
            lines = text.splitlines()
        for m in matches[:MAX_MATCHES_PER_RULE_PER_FILE]:
            line_no = _line_no(text, m.start())
            try:
                snippet = lines[line_no - 1].strip()
            except IndexError:
                snippet = m.group(0)
            if len(snippet) > 160:
                snippet = snippet[:160] + "…"
            findings.append(Finding(
                repo=repo_name,
                severity=rule.severity,
                category="behavior",
                title=f"[{rule.subcat}] {rule.title}",
                location=f"{rel_path}:{line_no}",
                detail=f"{rule.description}  ⟶  {snippet}",
                recommendation=rule.recommendation,
                method=f"behavior:{rule.rule_id}",
            ))
    return findings


def scan_repo_for_behavior(repo_dir: Path, repo_name: str) -> list[Finding]:
    """Walk repo_dir and return behavioral-inference Findings."""
    findings: list[Finding] = []
    for dirpath, dirnames, filenames in os.walk(repo_dir):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if fn in SKIP_FILE_NAMES:
                continue
            ext = Path(fn).suffix.lower()
            if ext not in SCANNED_EXTS and fn not in SCANNED_FILENAMES:
                continue
            full = Path(dirpath) / fn
            try:
                if full.stat().st_size > MAX_FILE_BYTES:
                    continue
                text = full.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            rel = full.relative_to(repo_dir).as_posix()
            findings.extend(_scan_file_text(repo_name, rel, ext, fn, text))
    return findings


# ── Live-event helpers (Phase 3 — streaming UI) ──────────────────────────

def behavior_summary(findings: list[Finding]) -> dict[str, int]:
    """Return per-subcategory counts for a list of behavior findings.

    Used by the orchestrator to produce a compact 'observed behavior'
    summary per repo, e.g. {'net': 12, 'fs': 3, 'proc': 1}.
    """
    counts: dict[str, int] = {}
    for f in findings:
        if f.category != "behavior":
            continue
        if f.title.startswith("[") and "]" in f.title:
            tag = f.title[1:f.title.index("]")]
            counts[tag] = counts.get(tag, 0) + 1
    return counts


def behavior_highlights(findings: list[Finding], *, limit: int = 5) -> list[dict]:
    """Pick a small set of representative findings to stream to the UI
    so the scan feels like a live behavioral monitor.

    Prefers high-severity entries first, then diversifies by subcategory
    so the feed doesn't render six 'net-http-url' lines in a row.
    """
    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    ranked = sorted(
        (f for f in findings if f.category == "behavior"),
        key=lambda f: sev_order.get(f.severity, 5),
    )
    seen_subcats: set[str] = set()
    out: list[dict] = []
    for f in ranked:
        tag = f.title[1:f.title.index("]")] if f.title.startswith("[") else "?"
        if tag in seen_subcats:
            continue
        seen_subcats.add(tag)
        out.append({
            "subcat": tag,
            "severity": f.severity,
            "title": f.title,
            "location": f.location,
        })
        if len(out) >= limit:
            return out
    for f in ranked:
        if len(out) >= limit:
            break
        tag = f.title[1:f.title.index("]")] if f.title.startswith("[") else "?"
        entry = {
            "subcat": tag,
            "severity": f.severity,
            "title": f.title,
            "location": f.location,
        }
        if entry not in out:
            out.append(entry)
    return out
