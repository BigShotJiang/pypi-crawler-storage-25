// aux.js — UI for the new scanner tabs (tfscan, containerscan, ci-scan,
// check, watch). Self-contained; doesn't touch app.js's globals.
//
// All rendering uses safe DOM APIs (createElement + replaceChildren +
// textContent). No innerHTML use, so finding text (which may contain
// HTML-significant characters) is never interpreted as markup.

(function () {
  'use strict';

  // ── Tab switching ─────────────────────────────────────────────────

  function switchTab(name) {
    document.querySelectorAll('.tab').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === name);
    });
    document.querySelectorAll('.tab-content').forEach(div => {
      div.classList.toggle('hidden', div.id !== 'tab-' + name);
    });
  }

  document.querySelectorAll('#tabbar .tab').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // ── Render per-tab forms ──────────────────────────────────────────

  const SEVERITY_ORDER = ['critical', 'high', 'medium', 'low', 'info'];

  function el(tag, attrs, children) {
    const e = document.createElement(tag);
    if (attrs) {
      for (const k in attrs) {
        const v = attrs[k];
        if (v == null) continue;
        if (k === 'class') e.className = v;
        else if (k === 'style') e.setAttribute('style', v);
        else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
        else e.setAttribute(k, v);
      }
    }
    if (children) {
      (Array.isArray(children) ? children : [children]).forEach(c => {
        if (c == null) return;
        if (typeof c === 'string') e.appendChild(document.createTextNode(c));
        else e.appendChild(c);
      });
    }
    return e;
  }

  function clear(node) {
    if (node) node.replaceChildren();
  }

  function buildForm(kind, container) {
    const isWatch = kind === 'watch';
    const isContainer = kind === 'containerscan';
    const isTf = kind === 'tfscan';
    const card = el('section', { class: 'card' }, [
      el('div', { class: 'card-head' }, [
        el('h2', null, [headingFor(kind)]),
        el('p', { class: 'card-sub' }, [subFor(kind)]),
      ]),
      el('div', { class: 'field' }, [
        el('label', { for: kind + '-src' }, ['Source root']),
        el('input', {
          id: kind + '-src', type: 'text', spellcheck: 'false',
          autocomplete: 'off',
          placeholder: 'C:\\path\\to\\repo or /path/to/repo',
        }),
      ]),

      isTf ? el('div', { class: 'field' }, [
        el('label', { for: 'tfscan-cloud' }, ['Cloud']),
        (() => {
          const s = el('select', { id: 'tfscan-cloud' });
          ['all', 'aws', 'gcp'].forEach(v => {
            s.appendChild(el('option', { value: v }, [v]));
          });
          return s;
        })(),
      ]) : null,

      isContainer ? el('div', { class: 'field' }, [
        el('label', null, ['Container layer options']),
        el('label', { class: 'check' }, [
          el('input', { type: 'checkbox', id: 'cs-layers', checked: 'checked' }),
          ' Pull image layers from registries',
        ]),
        el('label', { class: 'check' }, [
          el('input', { type: 'checkbox', id: 'cs-cve', checked: 'checked' }),
          ' Query OSV.dev for per-package CVEs',
        ]),
      ]) : null,

      isWatch ? el('div', { class: 'field' }, [
        el('label', { for: 'watch-interval' }, ['Interval (seconds)']),
        el('input', {
          id: 'watch-interval', type: 'number', value: '86400',
          min: '60', max: '604800',
        }),
        el('div', { class: 'hint' }, [
          'Time between scan iterations. Min 60s, max 7d.',
        ]),
      ]) : null,

      !isWatch ? el('div', { class: 'field' }, [
        el('label', { for: kind + '-diff' }, ['Diff base (optional)']),
        el('input', {
          id: kind + '-diff', type: 'text', placeholder: 'origin/main',
        }),
        el('div', { class: 'hint' }, [
          'Filter to findings on files changed since this git ref.',
        ]),
      ]) : null,

      !isWatch ? el('div', { class: 'field' }, [
        el('label', { class: 'check' }, [
          el('input', {
            type: 'checkbox', id: kind + '-sarif',
            checked: kind === 'check' ? 'checked' : null,
          }),
          ' Also emit SARIF 2.1.0 artifact',
        ]),
      ]) : null,

      el('div', { class: 'field actions' }, [
        el('button', {
          class: 'btn btn-primary', id: kind + '-run', type: 'button',
          onclick: () => runJob(kind, container),
        }, [isWatch ? 'Start watch' : 'Run']),
        isWatch ? el('button', {
          class: 'btn btn-secondary', id: kind + '-stop', type: 'button',
          disabled: 'disabled', onclick: () => stopWatch(container),
        }, ['Stop']) : null,
      ]),
    ]);
    container.appendChild(card);

    const results = el('section', {
      class: 'card', id: kind + '-results-card', style: 'display:none',
    }, [
      el('div', { class: 'card-head' }, [
        el('h2', null, ['Results']),
        el('p', { class: 'card-sub', id: kind + '-status' }, ['']),
      ]),
      el('div', { class: 'sev-summary', id: kind + '-sev' }),
      el('div', { class: 'artifact-row', id: kind + '-artifacts' }),
      el('div', { class: 'findings-table-wrap' }, [
        el('table', { class: 'findings-table' }, [
          el('thead', null, [
            el('tr', null, [
              el('th', { class: 'col-sev' }, ['Severity']),
              el('th', { class: 'col-title' }, ['Finding']),
              el('th', { class: 'col-loc' }, ['Location']),
            ]),
          ]),
          el('tbody', { id: kind + '-tbody' }),
        ]),
      ]),
    ]);
    container.appendChild(results);

    if (isWatch) {
      const histCard = el('section', {
        class: 'card', id: 'watch-history-card', style: 'display:none',
      }, [
        el('div', { class: 'card-head' }, [
          el('h2', null, ['Watch history']),
          el('p', { class: 'card-sub' }, [
            'Each completed tick with severity counts.',
          ]),
        ]),
        el('div', { id: 'watch-history-body' }),
      ]);
      container.appendChild(histCard);
    }
  }

  function headingFor(kind) {
    return {
      tfscan: 'Terraform / IaC scan (AWS + GCP)',
      containerscan: 'Container scan (Dockerfile + compose + image layers)',
      'ci-scan': 'CI/CD pipeline scan (GitHub Actions, GitLab, etc.)',
      check: 'One-shot full battery (scan + IaC + container + CI)',
      watch: 'Recurring rescan with diff alerts',
    }[kind] || kind;
  }

  function subFor(kind) {
    return {
      tfscan: 'Walk .tf / .tf.json and apply 80+ CIS-aligned rules.',
      containerscan: 'Parse Dockerfile/compose and optionally pull image layers for OSV CVE chaining.',
      'ci-scan': 'Audit workflow YAML for action pinning, script injection, secrets-to-third-party, etc.',
      check: 'Run everything. Recommended single command for CI gates.',
      watch: 'Periodically rescan the project and report only NEW findings.',
    }[kind] || '';
  }

  // ── Run a job ─────────────────────────────────────────────────────

  let watchJobId = null;
  let sseSource = null;

  async function runJob(kind, container) {
    const src = container.querySelector('#' + kind + '-src').value.trim();
    if (!src) {
      alert('Source root is required.');
      return;
    }
    const body = { source_root: src };
    if (kind === 'tfscan') {
      body.clouds = container.querySelector('#tfscan-cloud').value;
      body.diff_base = container.querySelector('#tfscan-diff').value.trim() || null;
      body.emit_sarif = container.querySelector('#tfscan-sarif').checked;
    } else if (kind === 'containerscan') {
      body.scan_layers = container.querySelector('#cs-layers').checked;
      body.cve_lookup = container.querySelector('#cs-cve').checked;
      body.diff_base = container.querySelector('#containerscan-diff').value.trim() || null;
      body.emit_sarif = container.querySelector('#containerscan-sarif').checked;
    } else if (kind === 'ci-scan') {
      body.diff_base = container.querySelector('#ci-scan-diff').value.trim() || null;
      body.emit_sarif = container.querySelector('#ci-scan-sarif').checked;
    } else if (kind === 'check') {
      body.diff_base = container.querySelector('#check-diff').value.trim() || null;
      body.emit_sarif = container.querySelector('#check-sarif').checked;
    } else if (kind === 'watch') {
      body.interval_s = parseInt(
        container.querySelector('#watch-interval').value || '86400', 10);
    }

    const endpoint = kind === 'watch' ? '/api/watch/start' :
                     kind === 'check' ? '/api/check' :
                     '/api/' + kind;
    let resp;
    try {
      resp = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
    } catch (e) {
      alert('Network error: ' + e);
      return;
    }
    const data = await resp.json();
    if (!resp.ok) {
      alert('Error: ' + (data.error || resp.statusText));
      return;
    }
    if (kind === 'watch') {
      watchJobId = data.job_id;
      container.querySelector('#watch-stop').disabled = false;
      container.querySelector('#watch-run').disabled = true;
    }
    showResults(kind, container, data.job_id);
  }

  async function stopWatch(container) {
    if (!watchJobId) return;
    await fetch('/api/watch/' + watchJobId + '/stop', { method: 'POST' });
    container.querySelector('#watch-stop').disabled = true;
    container.querySelector('#watch-run').disabled = false;
    if (sseSource) sseSource.close();
    sseSource = null;
  }

  // ── Stream events + render results ────────────────────────────────

  function showResults(kind, container, jobId) {
    const card = container.querySelector('#' + kind + '-results-card');
    card.style.display = '';
    const status = container.querySelector('#' + kind + '-status');
    status.textContent = 'Job ' + jobId.slice(0, 12) + '… running.';
    clear(container.querySelector('#' + kind + '-tbody'));
    clear(container.querySelector('#' + kind + '-sev'));
    clear(container.querySelector('#' + kind + '-artifacts'));

    if (sseSource) sseSource.close();
    sseSource = new EventSource('/api/aux/' + jobId + '/events');
    sseSource.onmessage = ev => {
      let data;
      try { data = JSON.parse(ev.data); } catch { return; }
      if (data.type === 'status') {
        status.textContent = 'Status: ' + data.status;
        if (data.status === 'complete' || data.status === 'error') {
          loadResults(kind, container, jobId);
          if (kind !== 'watch') sseSource.close();
        }
      } else if (data.type === 'phase') {
        status.textContent = '[' + data.name + '] ' + data.message;
      } else if (data.type === 'watch_tick') {
        loadResults(kind, container, jobId);
        loadWatchHistory(container, jobId);
      } else if (data.type === 'error') {
        status.textContent = 'Error: ' + data.message;
      }
    };
    sseSource.onerror = () => { /* SSE auto-reconnects */ };
  }

  async function loadResults(kind, container, jobId) {
    const resp = await fetch('/api/aux/' + jobId + '/findings');
    if (!resp.ok) return;
    const data = await resp.json();
    renderSeverityChips(container.querySelector('#' + kind + '-sev'),
                        (data.summary && data.summary.by_severity) || {});
    renderArtifacts(container.querySelector('#' + kind + '-artifacts'),
                    jobId);
    renderFindings(container.querySelector('#' + kind + '-tbody'),
                   data.findings || []);
  }

  function renderSeverityChips(container, bySev) {
    clear(container);
    SEVERITY_ORDER.forEach(s => {
      const n = bySev[s] || 0;
      container.appendChild(
        el('span', { class: 'sev-chip sev-' + s }, [s + ': ' + n]));
    });
  }

  async function renderArtifacts(container, jobId) {
    clear(container);
    const resp = await fetch('/api/aux/' + jobId + '/status');
    if (!resp.ok) return;
    const data = await resp.json();
    (data.artifacts || []).forEach(name => {
      const link = el('a', {
        class: 'artifact-link',
        href: '/api/aux/' + jobId + '/artifact?name=' + encodeURIComponent(name),
        download: name,
      }, [name]);
      container.appendChild(link);
    });
  }

  function renderFindings(tbody, findings) {
    clear(tbody);
    const order = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };
    findings.sort((a, b) =>
      (order[a.severity] !== undefined ? order[a.severity] : 99)
      - (order[b.severity] !== undefined ? order[b.severity] : 99));
    findings.slice(0, 500).forEach(f => {
      const row = el('tr', null, [
        el('td', null, [
          el('span', { class: 'sev-chip sev-' + f.severity }, [f.severity]),
        ]),
        el('td', null, [f.title || '']),
        el('td', { class: 'cell-loc' }, [f.location || '']),
      ]);
      row.addEventListener('click', () => toggleDetail(row, f));
      tbody.appendChild(row);
    });
    if (findings.length > 500) {
      tbody.appendChild(el('tr', null, [
        el('td', { colspan: '3', class: 'cell-note' }, [
          '…and ' + (findings.length - 500) + ' more (download the JSON artifact for the full list)',
        ]),
      ]));
    }
  }

  function toggleDetail(row, f) {
    const next = row.nextElementSibling;
    if (next && next.classList.contains('detail-row')) {
      next.remove();
      return;
    }
    const detail = el('tr', { class: 'detail-row' }, [
      el('td', { colspan: '3' }, [
        el('div', { class: 'detail-block' }, [
          el('div', { class: 'detail-label' }, ['Detail']),
          el('div', null, [f.detail || '(none)']),
          el('div', { class: 'detail-label', style: 'margin-top:8px' }, ['Recommendation']),
          el('div', null, [f.recommendation || '(none)']),
          el('div', { class: 'detail-label', style: 'margin-top:8px' }, ['Method / rule']),
          el('div', { style: 'font-family:monospace;font-size:12px' },
             [f.method || '']),
        ]),
      ]),
    ]);
    row.parentNode.insertBefore(detail, row.nextElementSibling);
  }

  async function loadWatchHistory(container, jobId) {
    const resp = await fetch('/api/watch/' + jobId + '/history');
    if (!resp.ok) return;
    const data = await resp.json();
    const card = container.querySelector('#watch-history-card');
    const body = container.querySelector('#watch-history-body');
    if (!data.runs || !data.runs.length) {
      card.style.display = 'none';
      return;
    }
    card.style.display = '';
    clear(body);
    data.runs.slice().reverse().forEach(r => {
      const sev = r.by_severity || {};
      const parts = SEVERITY_ORDER.map(s => s + '=' + (sev[s] || 0)).join('  ');
      body.appendChild(el('div', { class: 'history-row' }, [
        el('span', { class: 'history-stamp' }, [r.stamp]),
        el('span', { class: 'history-counts' }, [
          'new=' + r.new_count + '  resolved=' + r.resolved_count
          + '  carried=' + r.unchanged + '  (' + parts + ')',
        ]),
      ]));
    });
  }

  // ── Bootstrap ─────────────────────────────────────────────────────

  ['tfscan', 'containerscan', 'ci-scan', 'check', 'watch'].forEach(kind => {
    const container = document.getElementById('tab-' + kind);
    if (container) buildForm(kind, container);
  });
})();
