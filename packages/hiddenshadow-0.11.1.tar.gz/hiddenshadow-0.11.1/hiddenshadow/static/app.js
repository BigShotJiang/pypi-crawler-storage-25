/* hiddenshadow web UI */
(function () {
  'use strict';

  // ── Element handles ──────────────────────────────────────────────
  const $ = (sel) => document.querySelector(sel);

  const sourceInput      = $('#source-root');
  const outputInput      = $('#output-root');
  const respectMetaInput = $('#respect-metadata');
  const detectSecretsInput = $('#detect-secrets');
  const detectSastInput = $('#detect-sast');
  const detectCvesInput = $('#detect-cves');
  const detectBehaviorInput = $('#detect-behavior');
  const behaviorPanel    = $('#behavior-panel');
  const behaviorFeed     = $('#behavior-feed');
  const behaviorCounts   = $('#behavior-counts');
  const drivesEl         = $('#drives');
  const browseBtn        = $('#browse-btn');
  const scanBtn          = $('#scan-btn');
  const setupError       = $('#setup-error');

  const setupCard        = $('#setup-card');
  const progressCard     = $('#progress-card');
  const resultsCard      = $('#results-card');

  const progressSource   = $('#progress-source');
  const progressBar      = $('#progress-bar');
  const progressPhase    = $('#progress-phase');
  const progressCount    = $('#progress-count');
  const progressCurrent  = $('#progress-current');
  const elapsedEl        = $('#elapsed');
  const logEl            = $('#log');

  const resultsSummary   = $('#results-summary');
  const exportFolder     = $('#export-folder');
  const exportBrowseBtn  = $('#export-browse-btn');
  const exportXlsxBtn    = $('#export-xlsx-btn');
  const exportPptxBtn    = $('#export-pptx-btn');
  const exportStatus     = $('#export-status');
  const exportRawLinks   = $('#export-raw-links');
  const findingsTbody    = $('#findings-tbody');
  const findingsEmpty    = $('#findings-empty');
  const filterText       = $('#filter-text');
  const filterPills      = $('#filter-pills');

  // History panel
  const historyList      = $('#history-list');
  const historyEmpty     = $('#history-empty');
  const historyRefresh   = $('#history-refresh');
  const historyClearAll  = $('#history-clear-all');

  // Modal
  const browseModal      = $('#browse-modal');
  const browseClose      = $('#browse-close');
  const browseCancel     = $('#browse-cancel');
  const browsePick       = $('#browse-pick');
  const browseUp         = $('#browse-up');
  const browseGo         = $('#browse-go');
  const browsePath       = $('#browse-path');
  const dirList          = $('#dir-list');
  const browseError      = $('#browse-error');
  const modalDrives      = $('#modal-drives');

  // ── State ────────────────────────────────────────────────────────
  let jobId = null;
  let elapsedTimer = null;
  let scanStartTs = null;
  let totalRepos = 0;
  let allFindings = [];
  let activeSeverity = 'all';
  let activeCategory = null;
  let cumulativeSev = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  let cumulativeBehavior = { net: 0, fs: 0, proc: 0, env: 0, persist: 0, priv: 0 };
  const BEHAVIOR_LABELS = {
    net: 'network', fs: 'filesystem', proc: 'process',
    env: 'env/creds', persist: 'persistence', priv: 'privilege',
  };
  const MAX_BEHAVIOR_FEED_LINES = 80;
  let sortKey = 'severity';   // 'severity' | 'repo' | 'title' | 'location'
  let sortDir = 'asc';        // 'asc' = critical→info / A→Z; 'desc' = reverse
  const SEV_ORDER = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };

  // ── DOM helpers ─────────────────────────────────────────────────
  function el(tag, attrs, ...children) {
    const e = document.createElement(tag);
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (k === 'class') e.className = v;
        else if (k === 'dataset') Object.assign(e.dataset, v);
        else if (k.startsWith('on') && typeof v === 'function') {
          e.addEventListener(k.slice(2).toLowerCase(), v);
        } else if (v !== null && v !== undefined && v !== false) {
          e.setAttribute(k, v);
        }
      }
    }
    for (const c of children) {
      if (c == null || c === false) continue;
      e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return e;
  }

  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  // ── Stop button: shut down the launcher process ────────────────
  const stopBtn = $('#stop-btn');
  if (stopBtn) {
    stopBtn.addEventListener('click', () => {
      if (!confirm('Stop the HiddenShadow server? You will need to relaunch from the Start Menu / desktop shortcut to use it again.')) return;
      fetch('/api/shutdown', { method: 'POST' })
        .catch(() => { /* server may close before responding — that's fine */ })
        .finally(() => {
          clear(document.body);
          const msg = el('div', null,
            'HiddenShadow stopped. You can close this tab.');
          msg.style.padding = '48px';
          msg.style.font = '16px system-ui,sans-serif';
          msg.style.color = '#607078';
          document.body.appendChild(msg);
        });
    });
  }

  // ── Boot: load drive chips ──────────────────────────────────────
  fetch('/api/drives').then(r => r.json()).then(data => {
    clear(drivesEl);
    clear(modalDrives);
    (data.drives || []).forEach(d => {
      drivesEl.appendChild(el('div', {
        class: 'drive-chip',
        onclick: () => { sourceInput.value = d.path; },
      }, d.label));
      modalDrives.appendChild(el('div', {
        class: 'drive-chip',
        onclick: () => loadDir(d.path),
      }, d.label));
    });
  }).catch(() => { /* not fatal */ });

  // ── Scan ────────────────────────────────────────────────────────
  scanBtn.addEventListener('click', startScan);
  sourceInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') startScan();
  });

  function startScan() {
    setupError.textContent = '';
    const source_root = sourceInput.value.trim();
    if (!source_root) { setupError.textContent = 'Source root is required.'; return; }

    scanBtn.disabled = true;
    scanBtn.textContent = 'Starting…';

    fetch('/api/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source_root,
        output_root: outputInput.value.trim() || null,
        respect_metadata: respectMetaInput.checked,
        detect_secrets: detectSecretsInput.checked,
        detect_sast: detectSastInput ? detectSastInput.checked : true,
        detect_cves: detectCvesInput ? detectCvesInput.checked : true,
        detect_behavior: detectBehaviorInput ? detectBehaviorInput.checked : true,
      }),
    })
    .then(async r => {
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
      return data;
    })
    .then(data => {
      jobId = data.job_id;
      progressSource.textContent = data.source_root;
      onScanStarted();
      subscribeEvents(data.job_id);
    })
    .catch(err => {
      setupError.textContent = err.message;
      scanBtn.disabled = false;
      scanBtn.textContent = 'Start scan';
    });
  }

  function onScanStarted() {
    progressCard.classList.remove('hidden');
    resultsCard.classList.add('hidden');
    setupCard.classList.add('hidden');
    progressBar.classList.add('indeterminate', 'scanning');
    elapsedEl.parentElement.classList.add('scanning');
    progressBar.style.width = '0%';
    progressPhase.textContent = 'Discovering repos…';
    progressCount.textContent = '';
    progressCurrent.textContent = '';
    clear(logEl);
    cumulativeSev = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
    cumulativeBehavior = { net: 0, fs: 0, proc: 0, env: 0, persist: 0, priv: 0 };
    if (behaviorFeed) clear(behaviorFeed);
    refreshSevTiles();
    refreshBehaviorCounts();
    totalRepos = 0;

    scanStartTs = Date.now();
    elapsedEl.textContent = '0:00';
    if (elapsedTimer) clearInterval(elapsedTimer);
    elapsedTimer = setInterval(() => {
      const s = Math.floor((Date.now() - scanStartTs) / 1000);
      const m = Math.floor(s / 60);
      const r = s % 60;
      elapsedEl.textContent = `${m}:${String(r).padStart(2, '0')}`;
    }, 1000);
  }

  function subscribeEvents(id) {
    const es = new EventSource(`/api/scan/${id}/events`);
    es.onmessage = (msg) => {
      try { handleEvent(JSON.parse(msg.data)); }
      catch (e) { console.error('bad event', msg.data, e); }
    };
    es.onerror = () => { es.close(); };
  }

  function handleEvent(ev) {
    switch (ev.type) {
      case 'discovery_start':
        progressPhase.textContent = 'Discovering repos…';
        appendLog(`Source root: ${ev.source_root}`);
        break;
      case 'discovered':
        totalRepos = ev.total;
        progressBar.classList.remove('indeterminate');
        progressPhase.textContent = totalRepos === 0
          ? 'No repositories found in source root.'
          : `Scanning ${totalRepos} repositor${totalRepos === 1 ? 'y' : 'ies'}…`;
        progressCount.textContent = totalRepos > 0 ? `0 / ${totalRepos}` : '';
        appendLog(`Discovered ${totalRepos} repos.`);
        break;
      case 'repo_start':
        progressCurrent.textContent = `→ ${ev.category}/${ev.name}`;
        progressCount.textContent = `${ev.index - 1} / ${ev.total}`;
        break;
      case 'repo_done': {
        const pct = ev.total > 0 ? (ev.index / ev.total) * 100 : 0;
        progressBar.style.width = `${pct.toFixed(1)}%`;
        progressCount.textContent = `${ev.index} / ${ev.total}`;
        for (const sev of ['critical','high','medium','low','info']) {
          cumulativeSev[sev] += (ev.findings && ev.findings[sev]) || 0;
        }
        refreshSevTiles();
        const fp = ev.findings || {};
        const summary = ['critical','high','medium','low','info']
          .filter(s => fp[s])
          .map(s => `${fp[s]}${s[0]}`)
          .join(' ');
        appendLog(
          `[${ev.index}/${ev.total}] ${ev.category}/${ev.name} `
          + `(${ev.duration_s}s)${summary ? '  ' + summary : ''}`,
          'repo-done'
        );
        break;
      }
      case 'phase':
        progressPhase.textContent = ev.message || ev.name;
        progressCurrent.textContent = '';
        appendLog(ev.message || ev.name, 'phase');
        break;
      case 'behavior_observed':
        appendBehaviorEvent(ev);
        break;
      case 'status':
        if (ev.status === 'complete') {
          finishScan(ev.summary);
        } else if (ev.status === 'error') {
          progressPhase.textContent = 'Scan failed.';
          appendLog('Scan failed (see error above).', 'error');
          if (elapsedTimer) clearInterval(elapsedTimer);
          progressBar.classList.remove('indeterminate', 'scanning');
          elapsedEl.parentElement.classList.remove('scanning');
          scanBtn.disabled = false;
          scanBtn.textContent = 'Start scan';
          setupCard.classList.remove('hidden');
        }
        break;
      case 'error':
        appendLog(`ERROR: ${ev.message}`, 'error');
        break;
    }
  }

  function refreshSevTiles() {
    document.querySelectorAll('.sev-count').forEach(elx => {
      elx.textContent = cumulativeSev[elx.dataset.sev] || 0;
    });
  }

  function refreshBehaviorCounts() {
    if (!behaviorCounts) return;
    clear(behaviorCounts);
    Object.keys(BEHAVIOR_LABELS).forEach(k => {
      const n = cumulativeBehavior[k] || 0;
      const chip = el('span', {
        class: 'behavior-chip behavior-chip-' + k + (n > 0 ? ' has' : ''),
      },
        el('span', { class: 'behavior-chip-label' }, BEHAVIOR_LABELS[k]),
        el('span', { class: 'behavior-chip-count' }, String(n)),
      );
      behaviorCounts.appendChild(chip);
    });
  }

  function appendBehaviorEvent(ev) {
    if (!behaviorFeed) return;
    const subcat = ev.subcat || '?';
    if (cumulativeBehavior.hasOwnProperty(subcat)) {
      cumulativeBehavior[subcat] += 1;
      refreshBehaviorCounts();
    }
    const now = new Date();
    const ts = `${String(now.getHours()).padStart(2,'0')}:` +
               `${String(now.getMinutes()).padStart(2,'0')}:` +
               `${String(now.getSeconds()).padStart(2,'0')}.` +
               `${String(now.getMilliseconds()).padStart(3,'0')}`;
    // ev.title looks like "[net] Outbound HTTP/HTTPS URL referenced" —
    // strip the leading bracketed tag, it's already shown in the tag chip.
    const cleanTitle = (ev.title || '').replace(/^\[[^\]]+\]\s*/, '');
    const line = el('div', {
      class: `behavior-line behavior-sev-${ev.severity} behavior-sub-${subcat}`,
    },
      el('span', { class: 'behavior-ts' }, ts),
      el('span', { class: 'behavior-tag behavior-tag-' + subcat }, subcat),
      el('span', { class: 'behavior-sev sev-badge sev-' + ev.severity }, ev.severity),
      el('span', { class: 'behavior-repo' }, ev.repo || ''),
      el('span', { class: 'behavior-msg' }, cleanTitle),
      el('span', { class: 'behavior-loc' }, ev.location || ''),
    );
    behaviorFeed.appendChild(line);
    while (behaviorFeed.childElementCount > MAX_BEHAVIOR_FEED_LINES) {
      behaviorFeed.removeChild(behaviorFeed.firstChild);
    }
    behaviorFeed.scrollTop = behaviorFeed.scrollHeight;
  }

  function appendLog(msg, cls) {
    const div = el('div', { class: 'log-line' + (cls ? ' ' + cls : '') }, msg);
    logEl.appendChild(div);
    logEl.scrollTop = logEl.scrollHeight;
  }

  function finishScan(summary) {
    if (elapsedTimer) clearInterval(elapsedTimer);
    progressBar.style.width = '100%';
    progressBar.classList.remove('indeterminate', 'scanning');
    elapsedEl.parentElement.classList.remove('scanning');
    progressPhase.textContent = 'Scan complete.';
    progressCurrent.textContent = '';

    if (summary && summary.by_severity) {
      cumulativeSev = Object.assign(
        { critical:0, high:0, medium:0, low:0, info:0 },
        summary.by_severity
      );
      refreshSevTiles();
    }

    fetch(`/api/scan/${jobId}/findings`)
      .then(r => r.json())
      .then(data => renderResults(data, summary));

    // Persistent history now has a new entry — refresh the panel.
    loadHistory();

    setupCard.classList.remove('hidden');
    scanBtn.disabled = false;
    scanBtn.textContent = 'Start new scan';
  }

  // ── Results ─────────────────────────────────────────────────────
  function renderResults(data, summary) {
    allFindings = data.findings || [];
    const dur = summary ? summary.duration_s.toFixed(1) : '?';
    resultsSummary.textContent =
      `${data.repos_scanned} repos · ${data.total_findings} findings · ${dur}s`;

    // Default the export folder to the scan's output_root (handy: lands
    // alongside _logs/ and sboms/) — user can change before exporting.
    if (exportFolder && !exportFolder.value && summary && summary.log_dir) {
      exportFolder.value = summary.log_dir.replace(/[\\/]_logs[\\/]?$/, '');
    }
    setExportStatus('', '');

    // Raw scan artifacts (de-emphasized links, separate from primary buttons)
    if (exportRawLinks) {
      clear(exportRawLinks);
      const artifacts = [
        { file: '_logs/scan-findings.json', label: 'findings.json' },
        { file: '_logs/scan-summary.csv',   label: 'summary.csv' },
        { file: '_logs/library-rollup.csv', label: 'rollup.csv' },
      ];
      artifacts.forEach((a, i) => {
        if (i > 0) exportRawLinks.appendChild(document.createTextNode(' · '));
        exportRawLinks.appendChild(el('a', {
          class: 'download-link',
          href: `/api/scan/${jobId}/artifact?file=${encodeURIComponent(a.file)}`,
        }, a.label));
      });
    }

    resultsCard.classList.remove('hidden');
    activeSeverity = 'all';
    activeCategory = null;
    filterPills.querySelectorAll('.pill').forEach(p =>
      p.classList.toggle('active', p.dataset.sev === 'all')
    );
    filterText.value = '';
    updateSortIndicators();
    renderFindingsTable();
  }

  function compareFindings(a, b) {
    let cmp;
    if (sortKey === 'severity') {
      const sa = SEV_ORDER[a.severity] ?? 5;
      const sb = SEV_ORDER[b.severity] ?? 5;
      cmp = sa - sb;
      if (cmp === 0) cmp = (a.repo || '').localeCompare(b.repo || '');
    } else {
      cmp = (a[sortKey] || '').localeCompare(b[sortKey] || '',
        undefined, { numeric: true, sensitivity: 'base' });
      if (cmp === 0) {
        // stable secondary sort by severity so ties stay readable
        cmp = (SEV_ORDER[a.severity] ?? 5) - (SEV_ORDER[b.severity] ?? 5);
      }
    }
    return sortDir === 'desc' ? -cmp : cmp;
  }

  function updateSortIndicators() {
    document.querySelectorAll('.findings-table th.sortable').forEach(th => {
      const ind = th.querySelector('.sort-ind');
      if (th.dataset.sort === sortKey) {
        th.classList.add('sort-active');
        if (ind) ind.textContent = sortDir === 'asc' ? '▲' : '▼';
      } else {
        th.classList.remove('sort-active');
        if (ind) ind.textContent = '';
      }
    });
  }

  document.querySelectorAll('.findings-table th.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const newKey = th.dataset.sort;
      if (!newKey) return;
      if (sortKey === newKey) {
        sortDir = sortDir === 'asc' ? 'desc' : 'asc';
      } else {
        sortKey = newKey;
        sortDir = 'asc';
      }
      updateSortIndicators();
      renderFindingsTable();
    });
  });

  function renderFindingsTable() {
    const q = filterText.value.trim().toLowerCase();
    const filtered = allFindings.filter(f => {
      if (activeCategory && f.category !== activeCategory) return false;
      if (activeSeverity !== 'all' && f.severity !== activeSeverity) return false;
      if (!q) return true;
      const hay = `${f.repo} ${f.title} ${f.location} ${f.detail || ''}`.toLowerCase();
      return hay.includes(q);
    });

    filtered.sort(compareFindings);

    clear(findingsTbody);
    if (filtered.length === 0) {
      findingsEmpty.classList.remove('hidden');
      return;
    }
    findingsEmpty.classList.add('hidden');

    filtered.forEach(f => {
      const tr = el('tr', { class: 'expandable' },
        el('td', null,
          el('span', { class: `sev-badge sev-${f.severity}` }, f.severity)),
        el('td', null, f.repo || ''),
        el('td', null, f.title || ''),
        el('td', null, f.location || ''),
      );
      tr.addEventListener('click', () => toggleDetail(tr, f));
      findingsTbody.appendChild(tr);
    });
  }

  function toggleDetail(tr, f) {
    const next = tr.nextElementSibling;
    if (next && next.classList.contains('detail-row')) {
      next.remove();
      return;
    }
    const blocks = [];
    blocks.push(el('div', { class: 'detail-block' },
      el('div', { class: 'lbl' }, 'Detail'),
      el('div', { class: 'val' }, f.detail || '(none)'),
    ));
    if (f.recommendation) {
      blocks.push(el('div', { class: 'detail-block' },
        el('div', { class: 'lbl' }, 'Recommendation'),
        el('div', { class: 'val' }, f.recommendation),
      ));
    }
    if (f.location) {
      blocks.push(el('div', { class: 'detail-block' },
        el('div', { class: 'lbl' }, 'Location'),
        el('div', { class: 'val' }, f.location),
      ));
    }
    if (f.method) {
      blocks.push(el('div', { class: 'detail-block' },
        el('div', { class: 'lbl' }, 'Detection method'),
        el('div', { class: 'val val-mono' }, f.method),
      ));
    }
    const td = el('td', { colspan: '4' }, ...blocks);
    const detail = el('tr', { class: 'detail-row' }, td);
    tr.parentNode.insertBefore(detail, tr.nextSibling);
  }

  filterText.addEventListener('input', renderFindingsTable);
  filterPills.addEventListener('click', (e) => {
    const btn = e.target.closest('.pill');
    if (!btn) return;
    if (btn.dataset.cat) {
      activeCategory = activeCategory === btn.dataset.cat ? null : btn.dataset.cat;
      btn.classList.toggle('active', activeCategory === btn.dataset.cat);
    } else {
      activeSeverity = btn.dataset.sev;
      filterPills.querySelectorAll('.pill[data-sev]').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
    }
    renderFindingsTable();
  });

  // ── Directory browser modal ─────────────────────────────────────
  let modalSelectedPath = null;
  let modalTargetInput  = sourceInput;  // which input receives the picked path

  function openBrowse(targetInput) {
    modalTargetInput = targetInput || sourceInput;
    browseModal.classList.remove('hidden');
    const start = (modalTargetInput.value || '').trim();
    if (start) loadDir(start);
    else if (modalDrives.firstChild) {
      loadDir(modalDrives.firstChild.textContent);
    }
  }

  browseBtn.addEventListener('click', () => openBrowse(sourceInput));
  if (exportBrowseBtn) {
    exportBrowseBtn.addEventListener('click', () => openBrowse(exportFolder));
  }
  browseClose.addEventListener('click', () => browseModal.classList.add('hidden'));
  browseCancel.addEventListener('click', () => browseModal.classList.add('hidden'));
  browseModal.addEventListener('click', (e) => {
    if (e.target === browseModal) browseModal.classList.add('hidden');
  });
  browseUp.addEventListener('click', () => {
    if (modalSelectedPath) {
      fetch(`/api/browse?path=${encodeURIComponent(modalSelectedPath)}`)
        .then(r => r.json())
        .then(d => { if (d.parent) loadDir(d.parent); });
    }
  });
  browseGo.addEventListener('click', () => loadDir(browsePath.value.trim()));
  browsePath.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') loadDir(browsePath.value.trim());
  });
  browsePick.addEventListener('click', () => {
    if (modalSelectedPath) {
      modalTargetInput.value = modalSelectedPath;
      browseModal.classList.add('hidden');
    }
  });

  // ── Export reports (Excel / PowerPoint) ─────────────────────────
  function setExportStatus(msg, kind) {
    if (!exportStatus) return;
    exportStatus.textContent = msg;
    exportStatus.classList.remove('success', 'error');
    if (kind) exportStatus.classList.add(kind);
  }

  function triggerBlobDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  async function readError(r) {
    try {
      const data = await r.json();
      if (data && data.error) return data.error;
    } catch (_) { /* not JSON */ }
    return `HTTP ${r.status}`;
  }

  function exportReport(fmt, label) {
    if (!jobId) { setExportStatus('Run a scan first.', 'error'); return; }
    const dir = (exportFolder && exportFolder.value || '').trim();
    if (!dir) {
      // No folder picked → stream to memory, then trigger a browser download.
      // (Using fetch+blob instead of window.location.href so any error stays
      // on this page in the status line instead of replacing the UI.)
      setExportStatus(`Preparing ${label}…`, '');
      fetch(`/api/scan/${jobId}/export.${fmt}`)
        .then(async r => {
          if (!r.ok) throw new Error(await readError(r));
          return r.blob();
        })
        .then(blob => {
          const fname = `hiddenshadow-scan-${jobId.slice(0, 8)}.${fmt}`;
          triggerBlobDownload(blob, fname);
          setExportStatus(`Downloaded ${fname}.`, 'success');
        })
        .catch(err => setExportStatus(err.message, 'error'));
      return;
    }
    setExportStatus(`Writing ${label}…`, '');
    fetch(`/api/scan/${jobId}/save_report`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ format: fmt, dir }),
    })
      .then(async r => {
        if (!r.ok) throw new Error(await readError(r));
        return r.json();
      })
      .then(data => {
        setExportStatus(`Saved: ${data.path}`, 'success');
      })
      .catch(err => setExportStatus(err.message, 'error'));
  }

  if (exportXlsxBtn) {
    exportXlsxBtn.addEventListener('click', () => exportReport('xlsx', 'Excel report'));
  }
  if (exportPptxBtn) {
    exportPptxBtn.addEventListener('click', () => exportReport('pptx', 'PowerPoint deck'));
  }

  // ── Recent scans (persistent history) ──────────────────────────
  function fmtTimestamp(t) {
    if (!t) return '';
    const d = new Date(t * 1000);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ` +
           `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function fmtSevSummary(by) {
    if (!by) return '';
    const order = ['critical', 'high', 'medium', 'low', 'info'];
    return order.filter(s => (by[s] || 0) > 0)
      .map(s => `${by[s]}${s[0]}`).join(' ');
  }

  function fmtBehaviorSummary(b) {
    if (!b) return '';
    const order = ['net', 'fs', 'proc', 'env', 'persist', 'priv'];
    return order.filter(k => (b[k] || 0) > 0)
      .map(k => `${k}:${b[k]}`).join('  ');
  }

  function loadHistory() {
    if (!historyList) return;
    fetch('/api/scans')
      .then(r => r.json())
      .then(data => renderHistory(data))
      .catch(err => {
        clear(historyList);
        historyEmpty.classList.remove('hidden');
        historyEmpty.textContent = `Could not load scan history: ${err.message}`;
      });
  }

  function renderHistory(data) {
    const scans = (data && data.scans) || [];
    clear(historyList);
    if (scans.length === 0) {
      historyEmpty.classList.remove('hidden');
      historyEmpty.textContent = 'No scans recorded yet. Run a scan to create one.';
      return;
    }
    historyEmpty.classList.add('hidden');
    scans.forEach(s => {
      const sevClass = s.status === 'error' ? 'history-row-error'
                     : (s.by_severity && (s.by_severity.critical || s.by_severity.high))
                       ? 'history-row-warn' : '';
      const row = el('div', { class: 'history-row ' + sevClass },
        el('div', { class: 'history-when' }, fmtTimestamp(s.finished_at)),
        el('div', { class: 'history-main' },
          el('div', { class: 'history-name' }, s.display_name || s.source_root),
          el('div', { class: 'history-path' }, s.source_root),
          el('div', { class: 'history-meta' },
            el('span', null, `${s.repos_scanned} repos`),
            el('span', null, `${s.total_findings} findings`),
            el('span', null, `${(s.duration_s || 0).toFixed(1)}s`),
            s.status === 'error'
              ? el('span', { class: 'history-status-error' }, 'ERROR')
              : null,
          ),
          fmtSevSummary(s.by_severity)
            ? el('div', { class: 'history-sev' }, fmtSevSummary(s.by_severity))
            : null,
          fmtBehaviorSummary(s.behavior_profile)
            ? el('div', { class: 'history-behavior' },
                el('span', { class: 'history-behavior-label' }, 'behavior:'),
                fmtBehaviorSummary(s.behavior_profile))
            : null,
        ),
        el('div', { class: 'history-side' },
          el('button', {
            class: 'btn btn-primary btn-sm',
            type: 'button',
            disabled: !s.artifacts_present || s.status !== 'complete',
            title: s.artifacts_present && s.status === 'complete'
              ? 'Open this scan’s findings in the results table'
              : (s.status !== 'complete'
                  ? 'Scan did not complete — no findings to view'
                  : 'Findings file is no longer on disk'),
            onclick: () => viewHistoryEntry(s),
          }, 'View'),
          el('button', {
            class: 'btn btn-secondary btn-sm',
            type: 'button',
            title: 'Pre-fill the scan form with this source root',
            onclick: () => { sourceInput.value = s.source_root; window.scrollTo({top: 0, behavior: 'smooth'}); },
          }, 'Re-scan'),
          el('button', {
            class: 'btn btn-danger btn-sm',
            type: 'button',
            title: 'Remove this entry from history',
            onclick: () => deleteHistoryEntry(s),
          }, 'Delete'),
        ),
      );
      historyList.appendChild(row);
    });
  }

  function viewHistoryEntry(scan) {
    // Hook past scans into the same Results pipeline the live scan uses.
    // We synthesize a summary from the history row (renderResults needs it
    // for the header line and the default export folder) and set jobId
    // so the Export buttons + raw-artifact links resolve to this scan.
    fetch(`/api/scans/${encodeURIComponent(scan.job_id)}/findings`)
      .then(async r => {
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          throw new Error(d.detail || d.error || `HTTP ${r.status}`);
        }
        return r.json();
      })
      .then(data => {
        jobId = scan.job_id;
        const synthesizedSummary = {
          duration_s: scan.duration_s || 0,
          repos_scanned: scan.repos_scanned || 0,
          by_severity: scan.by_severity || {},
          total_findings: scan.total_findings || 0,
          log_dir: (scan.output_root || '').replace(/[\\/]?$/, '') + '/_logs',
        };
        // Hide the active-scan progress card; show results. Reset filter state.
        progressCard.classList.add('hidden');
        renderResults(data, synthesizedSummary);
        // Show a small banner above the table so the user knows they're
        // looking at a historical scan, not a freshly-completed one.
        resultsSummary.textContent =
          `Viewing past scan — ${scan.display_name || scan.source_root} · ` +
          `${synthesizedSummary.repos_scanned} repos · ` +
          `${synthesizedSummary.total_findings} findings · ` +
          `${synthesizedSummary.duration_s.toFixed(1)}s · ` +
          fmtTimestamp(scan.finished_at);
        // Scroll the results card into view.
        resultsCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
      })
      .catch(err => alert(`Could not load past scan: ${err.message}`));
  }

  function explainFetchError(err) {
    // TypeError("Failed to fetch") is the browser's catch-all for any
    // network-layer failure (server down, blocked by extension, wrong
    // port). Tell the user what to actually try, instead of just echoing
    // the unhelpful default message.
    const msg = (err && err.message) || String(err);
    if (/failed to fetch|networkerror|load failed/i.test(msg)) {
      return (
        'The browser could not reach the HiddenShadow server.\n\n' +
        'Try:\n' +
        '  1. Hard-refresh this tab (Ctrl + F5).\n' +
        '  2. Close the tab and re-open HiddenShadow from the Start Menu.\n' +
        '  3. Confirm the address bar shows http://127.0.0.1:7878.\n\n' +
        '(Underlying error: ' + msg + ')'
      );
    }
    return msg;
  }

  function deleteHistoryEntry(scan) {
    const ok = confirm(
      `Delete this scan record?\n\n${scan.display_name || scan.source_root}\n${fmtTimestamp(scan.finished_at)}\n\n` +
      `(Removes the entry from history. On-disk artifacts under ${scan.output_root} are left in place.)`
    );
    if (!ok) return;
    fetch(`/api/scans/${encodeURIComponent(scan.job_id)}`, { method: 'DELETE' })
      .then(async r => {
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          throw new Error(d.error || `HTTP ${r.status}`);
        }
        return r.json();
      })
      .then(() => loadHistory())
      .catch(err => alert('Delete failed.\n\n' + explainFetchError(err)));
  }

  if (historyRefresh) historyRefresh.addEventListener('click', loadHistory);
  if (historyClearAll) {
    historyClearAll.addEventListener('click', () => {
      if (!confirm('Clear ALL scan history? Entries cannot be recovered. (Artifacts on disk are left untouched.)')) return;
      fetch('/api/scans', { method: 'DELETE' })
        .then(r => r.json())
        .then(() => loadHistory())
        .catch(err => alert(`Clear failed: ${err.message}`));
    });
  }

  // Load on startup, and after every completed scan.
  loadHistory();

  function loadDir(path) {
    if (!path) return;
    browseError.textContent = '';
    fetch(`/api/browse?path=${encodeURIComponent(path)}`)
      .then(r => r.json())
      .then(data => {
        if (data.error) {
          browseError.textContent = data.error;
          return;
        }
        modalSelectedPath = data.path;
        browsePath.value = data.path;
        clear(dirList);
        if (data.entries.length === 0) {
          const li = el('li', null, '(no subdirectories)');
          li.style.cursor = 'default';
          li.style.color = 'var(--text-faint)';
          dirList.appendChild(li);
          return;
        }
        data.entries.forEach(entry => {
          const li = el('li', null, entry.name);
          li.addEventListener('click', () => loadDir(entry.path));
          dirList.appendChild(li);
        });
      })
      .catch(err => {
        const msg = explainFetchError(err);
        // Multi-line in the modal: use newlines so it doesn't overflow.
        browseError.textContent = msg.split('\n')[0];
        // Full guidance still useful — drop it into the console for power users.
        console.warn('directory browse failed:', err, msg);
      });
  }
})();
