"""Smoke tests for the `conjure-eval` CLI."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from conjure_eval.cli import main
from conjure_eval.corpus import public_instance_ids


def test_cli_list_public_prints_358_ids(capsys: pytest.CaptureFixture):
    rc = main(["list-public"])
    assert rc == 0
    lines = [l for l in capsys.readouterr().out.splitlines() if l.strip()]
    assert len(lines) == 358


def test_cli_show_prints_axis_and_some_body(capsys: pytest.CaptureFixture):
    iid = public_instance_ids()[0]
    rc = main(["show", iid])
    assert rc == 0
    out = capsys.readouterr().out
    assert iid in out
    assert "axis:" in out


def test_cli_show_unknown_id_returns_2(capsys: pytest.CaptureFixture):
    rc = main(["show", "Not-A-Real-Id"])
    assert rc == 2
    err = capsys.readouterr().err
    assert "not in the public slice" in err


def test_cli_provenance_prints_split_seed(capsys: pytest.CaptureFixture):
    rc = main(["provenance"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "split_seed:" in out
    assert "4317" in out


def test_cli_verify_submission_accepts_well_formed_jsonl(
    tmp_path: Path, capsys: pytest.CaptureFixture
):
    iid = public_instance_ids()[0]
    p = tmp_path / "sub.jsonl"
    p.write_text(json.dumps({"instance_id": iid, "submission": "def P := True"}) + "\n")
    rc = main(["verify-submission", str(p)])
    assert rc == 0
    out = capsys.readouterr().out
    assert "well-formed: 1" in out
    assert "failed:     0" in out


def test_cli_verify_submission_rejects_unknown_id(
    tmp_path: Path, capsys: pytest.CaptureFixture
):
    p = tmp_path / "sub.jsonl"
    p.write_text(json.dumps({"instance_id": "Not-A-Real-Id", "submission": "x"}) + "\n")
    rc = main(["verify-submission", str(p)])
    assert rc == 1
    out = capsys.readouterr().out
    assert "not in the public slice" in out


def test_cli_verify_submission_rejects_malformed_json(
    tmp_path: Path, capsys: pytest.CaptureFixture
):
    p = tmp_path / "sub.jsonl"
    p.write_text("not json at all\n")
    rc = main(["verify-submission", str(p)])
    assert rc == 1
    out = capsys.readouterr().out
    assert "invalid JSON" in out


def test_cli_verify_submission_missing_file_returns_2(
    tmp_path: Path, capsys: pytest.CaptureFixture
):
    rc = main(["verify-submission", str(tmp_path / "nope.jsonl")])
    assert rc == 2
    err = capsys.readouterr().err
    assert "no such file" in err
