import json

class User:
    def __init__(self, data: dict):
        self.id = data.get('id')
        self.is_bot = data.get('is_bot', False)
        self.first_name = data.get('first_name', '')
        self.last_name = data.get('last_name')
        self.username = data.get('username')
        self.language_code = data.get('language_code')

    @property
    def full_name(self) -> str:
        if self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name

class Chat:
    def __init__(self, data: dict):
        self.id = data.get('id')
        self.type = data.get('type') 
        self.title = data.get('title')
        self.username = data.get('username')
        self.first_name = data.get('first_name')
        self.last_name = data.get('last_name')

class DiceObj:
    def __init__(self, data: dict):
        self.emoji = data.get('emoji', '🎲')
        self.value = data.get('value')

class Message:
    def __init__(self, data: dict, bot=None):
        self._bot = bot
        self.message_id = data.get('message_id')
        self.text = data.get('text', '')
        
        chat_data = data.get('chat', {})
        self.chat = Chat(chat_data) if chat_data else None
        
        user_data = data.get('from', {})
        self.f_user = User(user_data) if user_data else None
        
        self.chat_id = self.chat.id if self.chat else None
        self.user_id = self.f_user.id if self.f_user else None
        
        self.dice = DiceObj(data['dice']) if 'dice' in data else None
        
        # Если это сообщение - ответ на другое сообщение
        reply_data = data.get('reply_to_message')
        self.reply_to_msg = Message(reply_data, bot) if reply_data else None

    async def reply(self, text: str, **kwargs):
        """Быстрый ответ на это сообщение текстом"""
        if not self._bot:
            raise RuntimeError("Экземпляр бота не передан в объект Message.")
        return await self._bot.send_message(
            chat_id=self.chat.id,
            text=text,
            reply_to_message_id=self.message_id,
            **kwargs
        )

class CallbackQuery:
    def __init__(self, data: dict, bot):
        self.id = data.get('id')
        
        user_data = data.get('from', {})
        self.f_user = User(user_data) if user_data else None
        self.user_id = self.f_user.id if self.f_user else None
        
        self.message = Message(data.get('message'), bot) if 'message' in data else None
        self.data = data.get('data', '')
        self._bot = bot

    async def respond(self, text=None, show_alert=False, url=None, cache_time=0):
        await self._bot.answer_callback_query(
            callback_query_id=self.id,
            text=text,
            show_alert=show_alert,
            url=url,
            cache_time=cache_time
        )

# --- Keyboards ---
class BaseKeyboard:
    def to_json(self):
        return json.dumps(self.to_dict())

class InlineKeyboardButton:
    def __init__(self, text: str, callback_data: str = None, url: str = None, pay: bool = False, 
                 switch_inline_query: str = None, switch_inline_query_current_chat: str = None):
        self.text = text
        self.callback_data = callback_data
        self.url = url
        self.pay = pay
        # Новые параметры для подстановки текста:
        self.switch_inline_query = switch_inline_query
        self.switch_inline_query_current_chat = switch_inline_query_current_chat

    def to_dict(self):
        d = {"text": self.text}
        if self.callback_data: d["callback_data"] = self.callback_data
        if self.url: d["url"] = self.url
        if self.pay: d["pay"] = self.pay
        
        # Добавляем в итоговый JSON, если параметры переданы:
        if self.switch_inline_query is not None: 
            d["switch_inline_query"] = self.switch_inline_query
        if self.switch_inline_query_current_chat is not None: 
            d["switch_inline_query_current_chat"] = self.switch_inline_query_current_chat
            
        return d

class InlineKeyboardMarkup(BaseKeyboard):
    def __init__(self, inline_keyboard=None):
        self.inline_keyboard = inline_keyboard or []

    def add(self, *buttons: InlineKeyboardButton):
        self.inline_keyboard.append(list(buttons))

    def to_dict(self):
        return {"inline_keyboard": [[btn.to_dict() for btn in row] for row in self.inline_keyboard]}

class KeyboardButton:
    def __init__(self, text: str):
        self.text = text

    def to_dict(self):
        return {"text": self.text}

class ReplyKeyboardMarkup(BaseKeyboard):
    def __init__(self, keyboard=None, resize_keyboard=True, one_time_keyboard=False):
        self.keyboard = keyboard or []
        self.resize_keyboard = resize_keyboard
        self.one_time_keyboard = one_time_keyboard

    def add(self, *buttons: KeyboardButton):
        self.keyboard.append(list(buttons))

    def to_dict(self):
        return {
            "keyboard": [[btn.to_dict() for btn in row] for row in self.keyboard],
            "resize_keyboard": self.resize_keyboard,
            "one_time_keyboard": self.one_time_keyboard
        }
        
class ReplyKeyboardRemove(BaseKeyboard):
    def to_dict(self):
        return {"remove_keyboard": True}