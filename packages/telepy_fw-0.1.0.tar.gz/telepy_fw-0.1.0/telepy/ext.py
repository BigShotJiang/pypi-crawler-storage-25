class ParseData:
    HTML = "HTML"
    MD = "Markdown"
    MDV2 = "MarkdownV2"