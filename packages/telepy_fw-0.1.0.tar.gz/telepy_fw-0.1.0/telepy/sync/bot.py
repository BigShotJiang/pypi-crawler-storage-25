import requests
from ..types import BaseKeyboard, DiceObj

class SyncBot:
    def __init__(self, token: str):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{self.token}/"

    def request(self, method: str, data: dict = None):
        if data and 'reply_markup' in data and isinstance(data['reply_markup'], BaseKeyboard):
            data['reply_markup'] = data['reply_markup'].to_json()
            
        resp = requests.post(self.base_url + method, json=data)
        result = resp.json()
        if not result.get("ok"):
            print(f"Telegram API Error: {result}")
        return result.get("result")

    def send_message(self, chat_id: int, text: str, reply_markup=None, **kwargs):
        payload = {"chat_id": chat_id, "text": text}
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        return self.request("sendMessage", payload)
        
    def send_sticker(self, chat_id: int, sticker: str, reply_markup=None, **kwargs):
        """Отправляет стикер (sticker — это file_id или URL)"""
        payload = {"chat_id": chat_id, "sticker": sticker}
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        return self.request("sendSticker", payload)

    def send_photo(self, chat_id: int, photo: str, caption: str = None, reply_markup=None, **kwargs):
        payload = {"chat_id": chat_id, "photo": photo}
        if caption: payload["caption"] = caption
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        return self.request("sendPhoto", payload)

    def send_invoice(self, chat_id: int, title: str, description: str, payload: str, 
                     provider_token: str, currency: str, prices: list, reply_markup=None, **kwargs):
        data = {
            "chat_id": chat_id, "title": title, "description": description,
            "payload": payload, "provider_token": provider_token, "currency": currency,
            "prices": prices
        }
        if reply_markup: data["reply_markup"] = reply_markup
        data.update(kwargs)
        return self.request("sendInvoice", data)

    def refund_stars_payment(self, user_id: int, telegram_payment_charge_id: str):
        payload = {
            "user_id": user_id,
            "telegram_payment_charge_id": telegram_payment_charge_id
        }
        return self.request("refundStarPayment", payload)

    def send_dice(self, chat_id: int, emoji: str = "🎲", reply_markup=None, **kwargs):
        payload = {"chat_id": chat_id, "emoji": emoji}
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        
        result = self.request("sendDice", payload)
        if result and "dice" in result:
            return DiceObj(result["dice"])
        return None

    def set_chat_member_tag(self, chat_id: int, user_id: int, tag: str, **kwargs):
        if len(tag) > 16:
            raise ValueError(f"Длина тега не может превышать 16 символов. Получено: {len(tag)}")
            
        payload = {
            "chat_id": chat_id,
            "user_id": user_id,
            "tag": tag
        }
        payload.update(kwargs)
        return self.request("setChatMemberTag", payload)