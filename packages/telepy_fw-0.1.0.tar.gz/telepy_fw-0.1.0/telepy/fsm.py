class State:
    def __init__(self, name: str):
        self.name = name

class StateGroup:
    pass

class MemoryStorage:
    def __init__(self):
        self.data = {} # {chat_id: {user_id: {'state': str, 'data': dict}}}

    async def get_state(self, chat_id: int, user_id: int):
        return self.data.get(chat_id, {}).get(user_id, {}).get('state')

    async def set_state(self, chat_id: int, user_id: int, state: State = None):
        if chat_id not in self.data: self.data[chat_id] = {}
        if user_id not in self.data[chat_id]: self.data[chat_id][user_id] = {'data': {}}
        self.data[chat_id][user_id]['state'] = state.name if state else None

    async def get_data(self, chat_id: int, user_id: int):
        return self.data.get(chat_id, {}).get(user_id, {}).get('data', {})

    async def update_data(self, chat_id: int, user_id: int, **kwargs):
        if chat_id not in self.data: self.data[chat_id] = {}
        if user_id not in self.data[chat_id]: self.data[chat_id][user_id] = {'state': None, 'data': {}}
        self.data[chat_id][user_id]['data'].update(kwargs)

    async def clear(self, chat_id: int, user_id: int):
        if chat_id in self.data and user_id in self.data[chat_id]:
            self.data[chat_id][user_id] = {'state': None, 'data': {}}

class FSMContext:
    def __init__(self, storage: MemoryStorage, chat_id: int, user_id: int):
        self.storage = storage
        self.chat_id = chat_id
        self.user_id = user_id

    async def get_state(self):
        return await self.storage.get_state(self.chat_id, self.user_id)

    async def set_state(self, state: State):
        await self.storage.set_state(self.chat_id, self.user_id, state)

    async def get_data(self):
        return await self.storage.get_data(self.chat_id, self.user_id)

    async def update_data(self, **kwargs):
        await self.storage.update_data(self.chat_id, self.user_id, **kwargs)

    async def clear(self):
        await self.storage.clear(self.chat_id, self.user_id)