import aiohttp
from .types import BaseKeyboard, DiceObj

class Bot:
    def __init__(self, token: str):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{self.token}/"
        self._session = None

    async def get_session(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def request(self, method: str, data: dict = None):
        session = await self.get_session()
        if data and 'reply_markup' in data and isinstance(data['reply_markup'], BaseKeyboard):
            data['reply_markup'] = data['reply_markup'].to_json()
            
        async with session.post(self.base_url + method, json=data) as resp:
            result = await resp.json()
            if not result.get("ok"):
                print(f"Telegram API Error: {result}")
            return result.get("result")

    async def send_message(self, chat_id: int, text: str, reply_markup=None, **kwargs):
        payload = {"chat_id": chat_id, "text": text}
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        return await self.request("sendMessage", payload)
        
    async def send_sticker(self, chat_id: int, sticker: str, reply_markup=None, **kwargs):
        """Отправляет стикер (sticker — это file_id или URL)"""
        payload = {"chat_id": chat_id, "sticker": sticker}
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        return await self.request("sendSticker", payload)

    async def send_photo(self, chat_id: int, photo: str, caption: str = None, reply_markup=None, **kwargs):
        payload = {"chat_id": chat_id, "photo": photo}
        if caption: payload["caption"] = caption
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        return await self.request("sendPhoto", payload)

    async def send_invoice(self, chat_id: int, title: str, description: str, payload: str, 
                           provider_token: str, currency: str, prices: list, reply_markup=None, **kwargs):
        data = {
            "chat_id": chat_id, "title": title, "description": description,
            "payload": payload, "provider_token": provider_token, "currency": currency,
            "prices": prices
        }
        if reply_markup: data["reply_markup"] = reply_markup
        data.update(kwargs)
        return await self.request("sendInvoice", data)

    async def refund_stars_payment(self, user_id: int, telegram_payment_charge_id: str):
        payload = {
            "user_id": user_id,
            "telegram_payment_charge_id": telegram_payment_charge_id
        }
        return await self.request("refundStarPayment", payload)

    async def send_dice(self, chat_id: int, emoji: str = "🎲", reply_markup=None, **kwargs):
        payload = {"chat_id": chat_id, "emoji": emoji}
        if reply_markup: payload["reply_markup"] = reply_markup
        payload.update(kwargs)
        
        result = await self.request("sendDice", payload)
        if result and "dice" in result:
            return DiceObj(result["dice"])
        return None

    async def set_chat_member_tag(self, chat_id: int, user_id: int, tag: str, **kwargs):
        """Устанавливает тег участника чата (от 0 до 16 символов)"""
        if len(tag) > 16:
            raise ValueError(f"Длина тега не может превышать 16 символов. Получено: {len(tag)}")
            
        payload = {
            "chat_id": chat_id,
            "user_id": user_id,
            "tag": tag
        }
        payload.update(kwargs)
        return await self.request("setChatMemberTag", payload)

    async def answer_callback_query(self, callback_query_id: str, text: str = None, show_alert: bool = False, url: str = None, cache_time: int = 0):
        payload = {"callback_query_id": callback_query_id, "show_alert": show_alert, "cache_time": cache_time}
        if text: payload["text"] = text
        if url: payload["url"] = url
        return await self.request("answerCallbackQuery", payload)

    async def get_updates(self, offset=None, timeout=20):
        payload = {"timeout": timeout}
        if offset: payload["offset"] = offset
        return await self.request("getUpdates", payload)

    async def close(self):
        if self._session:
            await self._session.close()