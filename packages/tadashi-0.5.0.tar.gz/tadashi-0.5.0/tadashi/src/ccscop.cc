#include <cassert>
#include <cstring>
#include <iostream>
#include <isl/map_type.h>
#include <isl/point.h>
#include <ostream>

#include <isl/aff.h>
#include <isl/ctx.h>
#include <isl/flow.h>
#include <isl/id.h>
#include <isl/map.h>
#include <isl/schedule.h>
#include <isl/schedule_node.h>
#include <isl/set.h>
#include <isl/union_map.h>
#include <isl/union_set.h>
#include <isl/val.h>

#include "ccscop.h"
#include "pet.h"

// === PET RELATED HELPER FUNCTIONS ===================================== //
// ====================================================================== //

;
/* Is "stmt" not a kill statement? */
static int
is_not_kill(struct pet_stmt *stmt) {
  return !pet_stmt_is_kill(stmt);
}

/* Collect the iteration domains of the statements in "scop" that
 * satisfy "pred".
 */
static __isl_give isl_union_set *
collect_domains(struct pet_scop *scop, int (*pred)(struct pet_stmt *stmt)) {
  int i;
  isl_set *domain_i;
  isl_union_set *domain;

  if (!scop)
    return NULL;

  domain = isl_union_set_empty(isl_set_get_space(scop->context));

  for (i = 0; i < scop->n_stmt; ++i) {
    struct pet_stmt *stmt = scop->stmts[i];

    if (!pred(stmt))
      continue;

    if (stmt->n_arg > 0) {
      printf("loc: %d\n", pet_loc_get_line(scop->loc));
      isl_die(isl_union_set_get_ctx(domain), isl_error_unsupported,
              "data dependent conditions not supported",
              return isl_union_set_free(domain));
    }

    domain_i = isl_set_copy(scop->stmts[i]->domain);
    domain = isl_union_set_add_set(domain, domain_i);
  }

  return domain;
}

/* Collect the iteration domains of the statements in "scop",
 * skipping kill statements.
 */
static __isl_give isl_union_set *
collect_non_kill_domains(struct pet_scop *scop) {
  return collect_domains(scop, &is_not_kill);
}

/* This function is used as a callback to pet_expr_foreach_call_expr
 * to detect if there is any call expression in the input expression.
 * Assign the value 1 to the integer that "user" points to and
 * abort the search since we have found what we were looking for.
 */
static int
set_has_call(__isl_keep pet_expr *expr, void *user) {
  int *has_call = (int *)user;

  *has_call = 1;

  return -1;
}

/* Does "expr" contain any call expressions?
 */
static int
expr_has_call(__isl_keep pet_expr *expr) {
  int has_call = 0;

  if (pet_expr_foreach_call_expr(expr, &set_has_call, &has_call) < 0 &&
      !has_call)
    return -1;

  return has_call;
}

/* This function is a callback for pet_tree_foreach_expr.
 * If "expr" contains any call (sub)expressions, then set *has_call
 * and abort the search.
 */
static int
check_call(__isl_keep pet_expr *expr, void *user) {
  int *has_call = (int *)user;

  if (expr_has_call(expr))
    *has_call = 1;

  return *has_call ? -1 : 0;
}

/* Does "stmt" contain any call expressions?
 */
static int
has_call(struct pet_stmt *stmt) {
  int has_call = 0;

  if (pet_tree_foreach_expr(stmt->body, &check_call, &has_call) < 0 &&
      !has_call)
    return -1;

  return has_call;
}

/* Collect the iteration domains of the statements in "scop"
 * that contain a call expression.
 */
static __isl_give isl_union_set *
collect_call_domains(struct pet_scop *scop) {
  return collect_domains(scop, &has_call);
}

/* Compute the live out accesses, i.e., the writes that are
 * potentially not killed by any kills or any other writes, and
 * store them in ps->live_out.
 *
 * We compute the "dependence" of any "kill" (an explicit kill
 * or a must write) on any may write.
 * The elements accessed by the may writes with a "depending" kill
 * also accessing the element are definitely killed.
 * The remaining may writes can potentially be live out.
 *
 * The result of the dependence analysis is
 *
 *	{ IW -> [IK -> A] }
 *
 * with IW the instance of the write statement, IK the instance of kill
 * statement and A the element that was killed.
 * The range factor range is
 *
 *	{ IW -> A }
 *
 * containing all such pairs for which there is a kill statement instance,
 * i.e., all pairs that have been killed.
 */
void
ccScop::_pet_compute_live_out() {
  isl_schedule *sched;
  isl_union_map *kills;
  isl_union_map *exposed;
  isl_union_map *covering;
  isl_union_access_info *access;
  isl_union_flow *flow;

  sched = isl_schedule_copy(this->schedule);
  kills = isl_union_map_union(isl_union_map_copy(this->must_writes),
                              isl_union_map_copy(this->must_kills));
  access = isl_union_access_info_from_sink(kills);
  access = isl_union_access_info_set_may_source(
      access, isl_union_map_copy(this->may_writes));
  access = isl_union_access_info_set_schedule(access, sched);
  flow = isl_union_access_info_compute_flow(access);
  covering = isl_union_flow_get_full_may_dependence(flow);
  isl_union_flow_free(flow);

  covering = isl_union_map_range_factor_range(covering);
  exposed = isl_union_map_copy(this->may_writes);
  exposed = isl_union_map_subtract(exposed, covering);
  this->live_out = exposed;
}

static __isl_give isl_union_set *
shared_constraints(__isl_take isl_union_set *old,
                   __isl_take isl_union_set *extended) {
  isl_union_set *hull, *gist;

  hull = isl_union_set_plain_unshifted_simple_hull(old);
  gist = isl_union_set_copy(hull);
  gist = isl_union_set_gist(gist, extended);
  return isl_union_set_gist(hull, gist);
}

void
ccScop::_pet_eliminate_dead_code() {
  isl_union_set *live;
  isl_union_map *dep;
  // isl_union_pw_multi_aff *tagger;

  live = isl_union_map_domain(isl_union_map_copy(this->live_out));
  if (!isl_union_set_is_empty(this->call)) {
    live = isl_union_set_union(live, isl_union_set_copy(this->call));
    live = isl_union_set_coalesce(live);
  }

  dep = isl_union_map_copy(this->dep_flow);
  dep = isl_union_map_reverse(dep);

  for (;;) {
    isl_union_set *extra, *universe, *same_space, *other_space;
    isl_union_set *prev, *valid;

    extra =
        isl_union_set_apply(isl_union_set_copy(live), isl_union_map_copy(dep));
    if (isl_union_set_is_subset(extra, live)) {
      isl_union_set_free(extra);
      break;
    }

    universe = isl_union_set_universe(isl_union_set_copy(live));
    same_space = isl_union_set_intersect(isl_union_set_copy(extra),
                                         isl_union_set_copy(universe));
    other_space = isl_union_set_subtract(extra, universe);

    prev = isl_union_set_copy(live);
    live = isl_union_set_union(live, same_space);
    valid = shared_constraints(prev, isl_union_set_copy(live));

    live = isl_union_set_affine_hull(live);
    live = isl_union_set_intersect(live, valid);
    live = isl_union_set_intersect(live, isl_union_set_copy(this->domain));
    live = isl_union_set_union(live, other_space);
  }

  isl_union_map_free(dep);

  /* report_dead_code(ps, live); */

  this->domain =
      isl_union_set_intersect(this->domain, isl_union_set_copy(live));
  this->schedule =
      isl_schedule_intersect_domain(this->schedule, isl_union_set_copy(live));
  this->dep_flow = isl_union_map_intersect_range(this->dep_flow, live);
  /* tagger = isl_union_pw_multi_aff_copy(ps->tagger); */
  /* live = isl_union_set_preimage_union_pw_multi_aff(live, tagger); */
  /* ps->tagged_dep_flow = isl_union_map_intersect_range(ps->tagged_dep_flow, */
  /* 					live); */
}

static __isl_give isl_union_map *
get_dependencies(
    __isl_keep struct pet_scop *scop,
    __isl_give isl_union_map *(*get_sink)(__isl_keep pet_scop *scop),
    __isl_give isl_union_map *(*get_may_source)(__isl_keep pet_scop *scop),
    __isl_give isl_union_map *(*get_must_source)(__isl_keep pet_scop *scop)) {
  isl_union_map *dep;
  isl_union_flow *flow;
  isl_union_map *kills;
  isl_union_access_info *access;
  isl_schedule *schedule;

  access = isl_union_access_info_from_sink(get_sink(scop));
  kills = pet_scop_get_must_kills(scop);
  kills = isl_union_map_union(kills, pet_scop_get_must_writes(scop));
  access = isl_union_access_info_set_kill(access, kills);
  access = isl_union_access_info_set_may_source(access, get_may_source(scop));
  if (get_must_source) {
    isl_union_map *must_source = get_must_source(scop);
    access = isl_union_access_info_set_must_source(access, must_source);
  }
  schedule = pet_scop_get_schedule(scop);
  access = isl_union_access_info_set_schedule(access, schedule);

  flow = isl_union_access_info_compute_flow(access);
  dep = isl_union_flow_get_may_dependence(flow);
  isl_union_flow_free(flow);
  return dep;
}

// === METHOD IMPLEMETATIONS ============================================ //
// ====================================================================== //

ccScop::ccScop()
    : schedule(nullptr),     // 1.
      dep_flow(nullptr),     // 2.
      domain(nullptr),       // 3.
      call(nullptr),         // 4.
      may_writes(nullptr),   // 5.
      must_writes(nullptr),  // 6.
      must_kills(nullptr),   // 7.
      may_reads(nullptr),    // 8.
      live_out(nullptr),     // 9.
      current_node(nullptr), // 10.
      tmp_node(nullptr),     // 11.
      current_legal(true),   // 12.
      tmp_legal(true),       // 13.
      modified(0),           // 14.
      war(nullptr),          // 15.
      waw(nullptr)           // 16.
{
#ifndef NDEBUG
  std::cout << ">>> [c]Default()... DONE!" << std::endl;
#endif // NDEBUG
}

ccScop::ccScop(pet_scop *ps)
    : schedule(nullptr),     // 1.
      dep_flow(nullptr),     // 2.
      domain(nullptr),       // 3.
      call(nullptr),         // 4.
      may_writes(nullptr),   // 5.
      must_writes(nullptr),  // 6.
      must_kills(nullptr),   // 7.
      may_reads(nullptr),    // 8.
      live_out(nullptr),     // 9.
      current_node(nullptr), // 10.
      tmp_node(nullptr),     // 11.
      current_legal(true),   // 12.
      tmp_legal(true),       // 13.
      modified(0),           // 14.
      war(nullptr),          // 15.
      waw(nullptr)           // 16.
{
#ifndef NDEBUG
  std::cout << ">>> [c]PetPtr()... ";
#endif // NDEBUG
  this->schedule = pet_scop_get_schedule(ps);
  this->dep_flow = get_dependencies(ps, /* sink: */ pet_scop_get_may_reads,
                                    /* may_source: */ pet_scop_get_may_writes,
                                    /* must_source: */ nullptr);
  this->war = get_dependencies(ps, /* sink: */ pet_scop_get_may_writes,
                               /* may_source: */ pet_scop_get_may_reads,
                               /* must_source: */ nullptr);
  this->waw = get_dependencies(ps, /* sink: */ pet_scop_get_may_writes,
                               /* may_source: */ pet_scop_get_may_writes,
                               /* must_source: */ nullptr);
  this->domain = collect_non_kill_domains(ps);
  this->call = collect_call_domains(ps);
  this->may_writes = pet_scop_get_may_writes(ps);
  this->must_writes = pet_scop_get_must_writes(ps);
  this->must_kills = pet_scop_get_must_kills(ps);
  this->may_reads = pet_scop_get_may_reads(ps);
  this->_pet_compute_live_out();
  if (this->domain == nullptr)
    this->domain = isl_schedule_get_domain(this->schedule);
  else
    this->_pet_eliminate_dead_code();
  this->current_node = isl_schedule_get_root(this->schedule);
  if (ps != nullptr)
    pet_scop_free(ps);
#ifndef NDEBUG
  std::cout << "DONE!" << std::endl;
#endif // NDEBUG
}

static __isl_give isl_schedule_node *
_build_schedule(__isl_take isl_schedule_node *node,
                __isl_keep isl_multi_union_pw_aff *mupa, unsigned int pos,
                unsigned int num_dims);

static isl_bool
_pw_aff_is_cst(__isl_keep isl_pw_aff *pa, void *user) {
  isl_bool target = (isl_bool)(user != 0);
  return (isl_bool)(isl_pw_aff_is_cst(pa) == target);
}

static int
_cmp(struct isl_set *a, struct isl_set *b, void *user) {
  isl_val *va = isl_set_plain_get_val_if_fixed(a, isl_dim_set, 0);
  isl_val *vb = isl_set_plain_get_val_if_fixed(b, isl_dim_set, 0);
  isl_val *diff = isl_val_sub(va, vb);
  int rv = isl_val_sgn(diff);
  isl_val_free(diff);
  return rv;
}

static isl_stat
_add_point(__isl_take isl_point *pnt, void *user) {
  isl_set_list **set_list = (isl_set_list **)user;
  *set_list = isl_set_list_add(*set_list, isl_set_from_point(pnt));
  return isl_stat_ok;
}

static __isl_give isl_union_set_list *
_filters_from_cst_upa(__isl_take isl_union_pw_aff *upa) {
#ifndef NDEBUG
  std::cout << "--------------------" << std::endl;
#endif // NDEBUG
  isl_ctx *ctx = isl_union_pw_aff_get_ctx(upa);
  isl_pw_aff_list *pa_list = isl_union_pw_aff_get_pw_aff_list(upa);
  isl_union_map *umap = isl_union_map_from_union_pw_aff(upa);
  isl_union_set *urange = isl_union_map_range(isl_union_map_copy(umap));
  isl_set *range = isl_set_from_union_set(urange);
  isl_set_list *set_list = isl_set_list_alloc(ctx, 1);
#ifndef NDEBUG
  isl_basic_set_list *bsl = isl_set_get_basic_set_list(range);
  std::cout << "***** bsl: " << isl_basic_set_list_to_str(bsl) << std::endl;
  std::cout << "range: " << isl_set_to_str(range) << std::endl;
  std::cout << "bounded: " << isl_set_is_bounded(range) << std::endl;
  isl_basic_set_list_free(bsl);
#endif // NDEBUG
  range = isl_set_coalesce(range);
  range = isl_set_drop_unused_params(range);
  range = isl_set_project_out_all_params(range);
#ifndef NDEBUG
  std::cout << "range: " << isl_set_to_str(range) << std::endl;
#endif // NDEBUG
  isl_set_foreach_point(range, _add_point, &set_list);
  isl_set_free(range);
  isl_size n_points = isl_set_list_size(set_list);
#ifndef NDEBUG
  std::cout << "set_list: " << isl_set_list_to_str(set_list) << std::endl;
#endif // NDEBUG
  isl_set_list_sort(set_list, _cmp, nullptr);
  isl_union_set_list *filters = isl_union_set_list_alloc(ctx, n_points);
  for (isl_size i = 0; i < n_points; i++) {
    isl_set *set = isl_set_list_get_at(set_list, i);
    isl_pw_multi_aff *pma = isl_pw_multi_aff_from_set(set);
    isl_union_map *preimage = isl_union_map_preimage_range_pw_multi_aff(
        isl_union_map_copy(umap), pma);
    isl_union_set *dmn = isl_union_map_domain(preimage);
    filters = isl_union_set_list_add(filters, dmn);
  };
  isl_union_map_free(umap);
  isl_set_list_free(set_list);
  isl_pw_aff_list_free(pa_list);
  return filters;
}

static __isl_give isl_schedule_node *
_insert_sequence(__isl_take isl_schedule_node *node,
                 __isl_take isl_union_pw_aff *upa,
                 __isl_keep isl_multi_union_pw_aff *mupa, int pos,
                 unsigned int num_dims) {
#ifndef NDEBUG
  std::cout << "------------------------------" << std::endl;
#endif // NDEBUG
  if (isl_union_pw_aff_n_pw_aff(upa) == 1) {
    isl_union_pw_aff_free(upa);
    return node;
  }
  isl_union_set_list *filters = _filters_from_cst_upa(upa);
  node = isl_schedule_node_insert_sequence(node, filters);
  isl_size num_children = isl_schedule_node_n_children(node);
  for (isl_size i = 0; i < num_children; ++i) {
    node = isl_schedule_node_child(node, i);
    isl_multi_union_pw_aff *branch = isl_multi_union_pw_aff_intersect_domain(
        isl_multi_union_pw_aff_copy(mupa),
        isl_schedule_node_filter_get_filter(node));
    node = _build_schedule(node, branch, pos + 1, num_dims);
    isl_multi_union_pw_aff_free(branch);
    node = isl_schedule_node_parent(node);
  }
  return node;
}

static __isl_give isl_schedule_node *
_build_schedule(__isl_take isl_schedule_node *node,
                __isl_keep isl_multi_union_pw_aff *mupa, unsigned int pos,
                unsigned int num_dims) {
#ifndef NDEBUG
  std::cout << "========================================" << std::endl;
  std::cout << "_build_sched::BEGIN node" << isl_schedule_node_to_str(node)
            << std::endl;
  std::cout << "_build_sched::BEGIN mupa" << isl_multi_union_pw_aff_to_str(mupa)
            << std::endl;
  std::cout << "_build_sched::BEGIN pos/num_dims" << pos << "/" << num_dims
            << std::endl;
#endif // NDEBUG
  if (pos >= num_dims)
    return node;
  isl_union_pw_aff *upa = isl_multi_union_pw_aff_get_at(mupa, pos);
#ifndef NDEBUG
  std::cout << "_build_sched::BEGIN upa" << isl_union_pw_aff_to_str(upa)
            << std::endl;
#endif // NDEBUG
  node = isl_schedule_node_first_child(node);
  if (isl_union_pw_aff_every_pw_aff(upa, _pw_aff_is_cst, (void *)1)) {
    node = _insert_sequence(node, upa, mupa, pos, num_dims);
  } else {
    node = isl_schedule_node_insert_partial_schedule(
        node, isl_multi_union_pw_aff_from_union_pw_aff(upa));
    node = _build_schedule(node, mupa, pos + 1, num_dims);
  }

  node = isl_schedule_node_parent(node);
#ifndef NDEBUG
  std::cout << "END" << isl_schedule_node_to_str(node) << std::endl;
#endif // NDEBUG
  return node;
}

isl_schedule *
build_schedule_from_umap(__isl_take isl_union_set *domain,
                         __isl_take isl_union_map *map) {
#ifndef NDEBUG
  std::cout << "[DOMANIN] >>> " << isl_union_set_to_str(domain) << std::endl;
  std::cout << "[  MAP  ] >>> " << isl_union_map_to_str(map) << std::endl;
#endif // NDEBUG
  isl_schedule *schedule = isl_schedule_from_domain(domain);
  isl_schedule_node *root = isl_schedule_get_root(schedule);
  schedule = isl_schedule_free(schedule);

  isl_multi_union_pw_aff *mupa = isl_multi_union_pw_aff_from_union_map(map);
  isl_size num_dims = isl_multi_union_pw_aff_dim(mupa, isl_dim_out);
  root = _build_schedule(root, mupa, 0, num_dims);
  isl_multi_union_pw_aff_free(mupa);

  schedule = isl_schedule_node_get_schedule(root);
  isl_schedule_node_free(root);
  return schedule;
}

ccScop::ccScop(isl_union_set *domain, isl_union_map *sched, isl_union_map *read,
               isl_union_map *write)
    : schedule(
          build_schedule_from_umap(isl_union_set_copy(domain), sched)), // 1.
      dep_flow(nullptr),                                                // 2.
      domain(domain),                                                   // 3.
      call(nullptr),                                                    // 4.
      may_writes(write),                                                // 5.
      must_writes(nullptr),                                             // 6.
      must_kills(nullptr),                                              // 7.
      may_reads(read),                                                  // 8.
      live_out(nullptr),                                                // 9.
      current_node(nullptr),                                            // 10.
      tmp_node(nullptr),                                                // 11.
      current_legal(true),                                              // 12.
      tmp_legal(true),                                                  // 13.
      modified(0),                                                      // 14.
      war(nullptr),                                                     // 15.
      waw(nullptr)                                                      // 16.
{
#ifndef NDEBUG
  std::cout << ">>> [c]Polly()... ";
#endif // NDEBUG
  this->current_node = isl_schedule_get_root(this->schedule);
#ifndef NDEBUG
  std::cout << "DONE!" << std::endl;
#endif // NDEBUG
}

void
ccScop::_dealloc() {
  if (this->waw != nullptr) { // 16.
    isl_union_map_free(this->waw);
    this->waw = nullptr;
  }
  if (this->war != nullptr) { // 15.
    isl_union_map_free(this->war);
    this->war = nullptr;
  }
  // 14-12 need no freeing!
  if (this->tmp_node != nullptr) { // 11.
    isl_schedule_node_free(this->tmp_node);
    this->tmp_node = nullptr;
  }
  if (this->current_node != nullptr) { // 10.
    isl_schedule_node_free(this->current_node);
    this->current_node = nullptr;
  }
  if (this->live_out != nullptr) { // 9.
    isl_union_map_free(this->live_out);
    this->live_out = nullptr;
  }
  if (this->may_reads != nullptr) { // 8.
    isl_union_map_free(this->may_reads);
    this->may_reads = nullptr;
  }
  if (this->must_kills != nullptr) { // 7.
    isl_union_map_free(this->must_kills);
    this->must_kills = nullptr;
  }
  if (this->must_writes != nullptr) { // 6.
    isl_union_map_free(this->must_writes);
    this->must_writes = nullptr;
  }
  if (this->may_writes != nullptr) { // 5.
    isl_union_map_free(this->may_writes);
    this->may_writes = nullptr;
  }
  if (this->call != nullptr) { // 4.
    isl_union_set_free(this->call);
    this->call = nullptr;
  }
  if (this->domain != nullptr) { // 3.
    isl_union_set_free(this->domain);
    this->domain = nullptr;
  }
  if (this->dep_flow != nullptr) { // 2.
    isl_union_map_free(this->dep_flow);
    this->dep_flow = nullptr;
  }
  if (this->schedule != nullptr) { // 1.
    isl_schedule_free(this->schedule);
    this->schedule = nullptr;
  }
}

ccScop::~ccScop() {
#ifndef NDEBUG
  std::cout << "<<< [~]***destructor***()... ";
#endif // NDEBUG
  this->_dealloc();
#ifndef NDEBUG
  std::cout << "DONE!" << std::endl;
#endif // NDEBUG
}

void
ccScop::_copy(const ccScop &other) {
  this->_dealloc();
  if (other.schedule != nullptr) // 1.
    this->schedule = isl_schedule_copy(other.schedule);
  if (other.dep_flow != nullptr) // 2.
    this->dep_flow = isl_union_map_copy(other.dep_flow);
  if (other.domain != nullptr) // 3.
    this->domain = isl_union_set_copy(other.domain);
  if (other.call != nullptr) // 4.
    this->call = isl_union_set_copy(other.call);
  if (other.may_writes != nullptr) // 5.
    this->may_writes = isl_union_map_copy(other.may_writes);
  if (other.must_writes != nullptr) // 6.
    this->must_writes = isl_union_map_copy(other.must_writes);
  if (other.must_kills != nullptr) // 7.
    this->must_kills = isl_union_map_copy(other.must_kills);
  if (other.may_reads != nullptr) // 8.
    this->may_reads = isl_union_map_copy(other.may_reads);
  if (other.live_out != nullptr) // 9.
    this->live_out = isl_union_map_copy(other.live_out);
  if (other.current_node != nullptr) // 10.
    this->current_node = isl_schedule_node_copy(other.current_node);
  if (other.tmp_node != nullptr) // 11.
    this->tmp_node = isl_schedule_node_copy(other.tmp_node);
  this->current_legal = other.current_legal; // 12.
  this->tmp_legal = other.tmp_legal;         // 13.
  this->modified = other.modified;           // 14.
  if (other.war != nullptr)                  // 15.
    this->war = isl_union_map_copy(other.war);
  if (other.waw != nullptr) // 16.
    this->waw = isl_union_map_copy(other.waw);
}

ccScop::ccScop(const ccScop &other)
    : schedule(nullptr),     // 1.
      dep_flow(nullptr),     // 2.
      domain(nullptr),       // 3.
      call(nullptr),         // 4.
      may_writes(nullptr),   // 5.
      must_writes(nullptr),  // 6.
      must_kills(nullptr),   // 7.
      may_reads(nullptr),    // 8.
      live_out(nullptr),     // 9.
      current_node(nullptr), // 10.
      tmp_node(nullptr),     // 11.
      current_legal(true),   // 12.
      tmp_legal(true),       // 13.
      modified(0),           // 14.
      war(nullptr),          // 15.
      waw(nullptr)           // 16.
{
#ifndef NDEBUG
  std::cout << ">>> [c]Copy()... ";
#endif // NDEBUG
  this->_copy(other);
#ifndef NDEBUG
  std::cout << "DONE!" << std::endl;
#endif // NDEBUG
}

void
ccScop::_set_nullptr(ccScop *scop) {
  scop->schedule = nullptr;     // 1.
  scop->dep_flow = nullptr;     // 2.
  scop->domain = nullptr;       // 3.
  scop->call = nullptr;         // 4.
  scop->may_writes = nullptr;   // 5.
  scop->must_writes = nullptr;  // 6.
  scop->must_kills = nullptr;   // 7.
  scop->may_reads = nullptr;    // 8.
  scop->live_out = nullptr;     // 9.
  scop->current_node = nullptr; // 10.
  scop->tmp_node = nullptr;     // 11.
  scop->current_legal = true;   // 12.
  scop->tmp_legal = true;       // 13.
  scop->modified = 0;           // 14.
  scop->war = nullptr;          // 15.
  scop->waw = nullptr;          // 16.
}

ccScop::ccScop(ccScop &&other) noexcept
    : schedule(other.schedule),           // 1.
      dep_flow(other.dep_flow),           // 2.
      domain(other.domain),               // 3.
      call(other.call),                   // 4.
      may_writes(other.may_writes),       // 5.
      must_writes(other.must_writes),     // 6.
      must_kills(other.must_kills),       // 7.
      may_reads(other.may_reads),         // 8.
      live_out(other.live_out),           // 9.
      current_node(other.current_node),   // 10.
      tmp_node(other.tmp_node),           // 11.
      current_legal(other.current_legal), // 12.
      tmp_legal(other.tmp_legal),         // 13.
      modified(other.modified),           // 14.
      war(other.war),                     // 15.
      waw(other.waw)                      // 16.
{
#ifndef NDEBUG
  std::cout << ">>> [c]Move()... ";
#endif // NDEBUG
  _set_nullptr(&other);
#ifndef NDEBUG
  std::cout << "DONE!" << std::endl;
#endif // NDEBUG
}

ccScop &
ccScop::operator=(const ccScop &other) {
#ifndef NDEBUG
  std::cout << ">>> [op=]Copy()... ";
#endif // NDEBUG
  if (this == &other)
    return *this;
  this->_copy(other);
#ifndef NDEBUG
  std::cout << "DONE!" << std::endl;
#endif // NDEBUG
  return *this;
}

ccScop &
ccScop::operator=(ccScop &&other) noexcept {
#ifndef NDEBUG
  std::cout << ">>> [op=]Move()... ";
#endif // NDEBUG
  if (this == &other)
    return *this;
  this->_dealloc();
  this->schedule = other.schedule;           // 1.
  this->dep_flow = other.dep_flow;           // 2.
  this->domain = other.domain;               // 3.
  this->call = other.call;                   // 4.
  this->may_writes = other.may_writes;       // 5.
  this->must_writes = other.must_writes;     // 6.
  this->must_kills = other.must_kills;       // 7.
  this->may_reads = other.may_reads;         // 8.
  this->live_out = other.live_out;           // 9.
  this->current_node = other.current_node;   // 10.
  this->tmp_node = other.tmp_node;           // 11.
  this->current_legal = other.current_legal; // 12.
  this->tmp_legal = other.tmp_legal;         // 13.
  this->modified = other.modified;           // 14.
  this->war = other.war;                     // 15.
  this->waw = other.waw;                     // 16.
  //
  _set_nullptr(&other);
#ifndef NDEBUG
  std::cout << "DONE!" << std::endl;
#endif // NDEBUG
  return *this;
}

void
ccScop::rollback() {
  if (!this->modified)
    return;
  std::swap(this->current_legal, this->tmp_legal);
  std::swap(this->current_node, this->tmp_node);
}

void
ccScop::reset() {
  if (!this->modified)
    return;
  this->current_node = isl_schedule_node_free(this->current_node);
  this->current_node = isl_schedule_get_root(this->schedule);
  this->current_legal = true;
  this->tmp_node = isl_schedule_node_free(this->tmp_node);
  this->tmp_node = nullptr;
  this->tmp_legal = false;
  this->modified = false;
}

static __isl_give isl_union_set *
_get_zeros_on_union_set(__isl_take isl_union_set *delta_uset) {
  isl_set *delta_set;
  isl_multi_aff *ma;

  delta_set = isl_set_from_union_set(delta_uset);
  ma = isl_multi_aff_zero(isl_set_get_space(delta_set));
  isl_set_free(delta_set);
  return isl_union_set_from_set(isl_set_from_multi_aff(ma));
}

static __isl_give isl_bool
_check_legality(__isl_keep isl_schedule_node *node,
                __isl_keep isl_union_map *dep) {
  isl_union_map *domain, *le;
  isl_union_set *delta, *zeros;
  if (isl_union_map_is_empty(dep))
    return isl_bool_true;
  isl_schedule *schedule = isl_schedule_node_get_schedule(node);
  isl_union_map *map = isl_schedule_get_map(schedule);
  isl_schedule_free(schedule);
  dep = isl_union_map_copy(dep);
  domain = isl_union_map_apply_domain(dep, isl_union_map_copy(map));
  domain = isl_union_map_apply_range(domain, map);
  delta = isl_union_map_deltas(domain);
  zeros = _get_zeros_on_union_set(isl_union_set_copy(delta));
  le = isl_union_set_lex_le_union_set(delta, zeros);
  isl_bool retval = isl_union_map_is_empty(le);
  isl_union_map_free(le);
  return retval;
}

static bool
_check_legality_parallel(__isl_keep isl_schedule_node *node,
                         __isl_keep isl_union_map *dep) {
  isl_union_map *map;
  bool retval;
  isl_union_map *domain, *cmp;
  isl_union_set *delta, *zeros;
  if (isl_union_map_is_empty(dep))
    return isl_bool_true;
  node = isl_schedule_node_copy(node);
  node = isl_schedule_node_first_child(node);
  map = isl_schedule_node_band_get_partial_schedule_union_map(node);
  node = isl_schedule_node_free(node);

  dep = isl_union_map_copy(dep);
  domain = isl_union_map_apply_domain(dep, isl_union_map_copy(map));
  domain = isl_union_map_apply_range(domain, map);
  delta = isl_union_map_deltas(domain);
  if (isl_union_set_is_empty(delta)) {
    delta = isl_union_set_free(delta);
    return isl_bool_true;
  }
  zeros = _get_zeros_on_union_set(isl_union_set_copy(delta));
  cmp = isl_union_set_lex_lt_union_set(isl_union_set_copy(delta),
                                       isl_union_set_copy(zeros));
  retval = isl_union_map_is_empty(cmp);
  cmp = isl_union_map_free(cmp);
  cmp = isl_union_set_lex_gt_union_set(delta, zeros);
  retval = retval && isl_union_map_is_empty(cmp);
  isl_union_map_free(cmp);
  return retval;
}

bool
ccScop::check_legality() {
  isl_schedule_node_type current_node_type;
  current_node_type = isl_schedule_node_get_type(this->current_node);
  bool is_parallel = false;
  if (current_node_type == isl_schedule_node_mark) {
    isl_id *id = isl_schedule_node_mark_get_id(this->current_node);
    const char *name = isl_id_get_name(id);
    if (0 == strncmp("pragma_parallel_", name, 16))
      is_parallel = true;
    isl_id_free(id);
  }
  if (is_parallel) {
    if (not _check_legality_parallel(this->current_node, this->dep_flow))
      return false;
    if (not _check_legality_parallel(this->current_node, this->war))
      return false;
    if (not _check_legality_parallel(this->current_node, this->waw))
      return false;
  } else {
    if (not _check_legality(this->current_node, this->dep_flow))
      return false;
    if (not _check_legality(this->current_node, this->war))
      return false;
    if (not _check_legality(this->current_node, this->waw))
      return false;
  }
  return true;
}
