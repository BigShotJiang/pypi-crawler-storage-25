# Copyright 2026 James G Willmore
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Unit tests for the Config class."""
import os
from pathlib import Path

from yamlsub import Config


class TestConfig:
    """Unit tests for the Config class."""

    def test_config(self):
        """Test the Config class."""
        # path valid when running test from top level directory
        env_path = Path(os.getcwd()) / "tests" / "resources" / ".test_env"
        yaml_path = Path(os.getcwd()) / "tests" / "resources" / "test-config.yaml"

        cfg = Config(yaml_path=os.fspath(yaml_path), env_path=os.fspath(env_path))

        assert cfg.get_config() is not None
        empty_key = cfg.get_config_key("empty_key")
        assert empty_key is None

        auth_keys = cfg.get_config_key("auth_keys")
        assert isinstance(auth_keys, dict)
        key2 = auth_keys.get("key2")
        assert isinstance(key2, str) and key2 == "env_test_key2"
        key3 = auth_keys.get("key3")
        assert isinstance(key3, dict) and len(key3) == 2
        assert key3.get("user") == "test_user"
        assert key3.get("password") == "key3_password"

        server = cfg.get_config_key("server")
        assert isinstance(server, dict)

        databases = server.get("database")
        assert isinstance(databases, dict) and len(databases) == 1

        db1 = databases.get("db1")
        assert isinstance(db1, dict) and len(db1) == 2
        assert db1.get("user") == "test_db1_user"
        assert db1.get("password") == "test_db1_password"
