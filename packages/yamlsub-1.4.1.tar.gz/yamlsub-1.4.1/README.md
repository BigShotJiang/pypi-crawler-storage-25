# yamlsub

YAML configuration with environment variable substitution.

## Project Shields

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Supported Python Versions][img_pyversions]][url_pyversions]
[![PyPI Releases][img_pypi]][url_pypi]

[img_pyversions]: https://img.shields.io/pypi/pyversions/yamlsub.svg
[url_pyversions]: https://pypi.python.org/pypi/yamlsub
[img_pypi]: https://img.shields.io/badge/PyPI-wheels-green.svg
[url_pypi]: https://pypi.org/project/yamlsub/#files

## Table of Contents

- [About](#about)
- [Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Installing](#installing)
- [Usage](#usage)

## About

A wrapper around the [python-dotenv](https://pypi.org/project/python-dotenv/) and [pyaml-env](https://pypi.org/project/pyaml-env/) packages that loads environment variables from a `.env` file and substitutes them into a YAML configuration file.

## Getting Started

### Prerequisites

- Python 3.12+

### Installing

Using pip:

```sh
pip install yamlsub
```

Using uv:

```sh
uv add yamlsub
```

To install directly from GitHub:

```sh
pip install yamlsub@git+https://github.com/willmorejg/yamlsub.git
```

## Usage

Review the documentation for [pyaml-env](https://pypi.org/project/pyaml-env/) and [python-dotenv](https://pypi.org/project/python-dotenv/) for additional information on how to incorporate this project into other projects.

Given a `.env` file:

```sh
DB_HOST=localhost
DB_USER=root
DB_PASS=123456
```

And a `config.yaml` file:

```yaml
database:
  host: !ENV ${DB_HOST}
  user: !ENV ${DB_USER}
  pass: !ENV ${DB_PASS}
```

Load and access the configuration:

```python
from yamlsub.config import Config

cfg = Config(yaml_path='config.yaml', env_path='.env')

# Retrieve the full configuration
full_config = cfg.get_config()

# Retrieve a specific top-level key
database_config = cfg.get_config_key('database')
dbhost = database_config['host']
dbuser = database_config['user']
dbpass = database_config['pass']

print(f'Host: {dbhost}, User: {dbuser}, Pass: {dbpass}')
```
