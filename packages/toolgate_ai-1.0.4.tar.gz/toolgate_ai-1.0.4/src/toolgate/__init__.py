"""
ToolGate — Optimistic execution middleware for autonomous agents.

Let your agent run freely — reads execute instantly, every other action
(writes, deletes, sends, deploys) is silently intercepted, recorded,
and held for human approval. The agent never knows the difference.

Usage:
    from toolgate import ToolGate, cli_approval

    async def execute(tool: str, params: dict) -> any:
        ...

    gate = ToolGate(execute, api_key="tg_live_...", agent_name="my-agent")
    result = await gate.proxy("listEmails", {})
    await gate.finalize()
"""

from toolgate.types import (
    ToolIntent,
    ToolClassification,
    ToolCall,
    ExecutedRead,
    PendingAction,
    Session,
    SessionStatus,
    ApprovalRequest,
    ApprovalResult,
    ActionDecision,
    MCPToolDef,
    MCPServerDef,
    ToolGateConfig,
)
from toolgate.classify import classify_tool
from toolgate.toolgate import ToolGate
from toolgate.cli_approval import cli_approval
from toolgate.dashboard_approval import dashboard_approval, DashboardApprovalConfig
from toolgate.mcp import mcp_tool_gate, discover_mcp_tools, auto_config_from_mcp

__all__ = [
    # Core
    "ToolGate",
    # Approval methods
    "cli_approval",
    "dashboard_approval",
    "DashboardApprovalConfig",
    # Classifier
    "classify_tool",
    # MCP
    "mcp_tool_gate",
    "discover_mcp_tools",
    "auto_config_from_mcp",
    # Types
    "ToolIntent",
    "ToolClassification",
    "ToolCall",
    "ExecutedRead",
    "PendingAction",
    "Session",
    "SessionStatus",
    "ApprovalRequest",
    "ApprovalResult",
    "ActionDecision",
    "MCPToolDef",
    "MCPServerDef",
    "ToolGateConfig",
]

__version__ = "1.0.4"
