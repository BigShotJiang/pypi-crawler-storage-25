"""
MCP integration helpers — auto-classify MCP tools by name + description.

Usage::

    from toolgate import mcp_tool_gate, auto_config_from_mcp

    gate = mcp_tool_gate(mcp_executor, api_key="tg_live_...", mcp_servers=[...])

    config = await auto_config_from_mcp([
        {"name": "gmail", "url": "https://gmail.mcp.example.com/sse"},
    ])
"""

from __future__ import annotations

from typing import Any, Optional

import httpx

from toolgate.toolgate import ToolGate
from toolgate.types import ToolGateConfig, MCPServerDef, MCPToolDef, RealExecutor


def mcp_tool_gate(
    executor: RealExecutor,
    *,
    api_key: Optional[str] = None,
    mcp_servers: Optional[list[MCPServerDef]] = None,
    **kwargs: Any,
) -> ToolGate:
    """
    Create a ToolGate specifically for MCP-based agents.

    Pass your MCP server definitions (with tool lists) and ToolGate will
    auto-classify every tool by analyzing its name + description.
    """
    return ToolGate(
        executor,
        api_key=api_key,
        mcp_servers=mcp_servers,
        **kwargs,
    )


async def discover_mcp_tools(server_url: str) -> list[MCPToolDef]:
    """
    Fetch MCP tool definitions from a running MCP server.
    Calls the standard `tools/list` JSON-RPC method.
    """
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            server_url,
            json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
            headers={"Content-Type": "application/json"},
        )

    if resp.status_code >= 400:
        raise RuntimeError(f"MCP discovery failed: {resp.status_code}")

    data = resp.json()
    tools = [
        MCPToolDef(
            name=t["name"],
            description=t.get("description", ""),
            input_schema=t.get("inputSchema"),
        )
        for t in data.get("result", {}).get("tools", [])
    ]
    return tools


async def auto_config_from_mcp(
    servers: list[dict[str, str]],
    **overrides: Any,
) -> ToolGateConfig:
    """
    Auto-discover tools from all MCP servers and return a fully configured ToolGateConfig.

    Args:
        servers: List of {"name": "...", "url": "..."} dicts
        **overrides: Additional ToolGateConfig fields
    """
    mcp_servers: list[MCPServerDef] = []
    for s in servers:
        try:
            tools = await discover_mcp_tools(s["url"])
            mcp_servers.append(MCPServerDef(name=s["name"], url=s["url"], tools=tools))
        except Exception:
            import warnings
            warnings.warn(f"[toolgate] Could not discover tools from {s['name']} ({s['url']})")
            mcp_servers.append(MCPServerDef(name=s["name"], url=s["url"], tools=[]))

    return ToolGateConfig(mcp_servers=mcp_servers, **overrides)
