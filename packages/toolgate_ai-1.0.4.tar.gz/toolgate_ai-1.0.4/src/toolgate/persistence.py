"""
Supabase persistence layer — handles saving/updating/fetching sessions.
Supports both API key auth (preferred) and legacy direct Supabase creds.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional
from dataclasses import asdict

import httpx

from toolgate.types import Session, ToolIntent, SessionStatus


# Default Supabase URL for ToolGate's hosted instance
_TOOLGATE_SUPABASE_URL = "https://jjigktmmlluzliqlnnny.supabase.co"
_TOOLGATE_SUPABASE_ANON_KEY = (
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
    "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpqaWdrdG1tbGx1emxpcWxubm55Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU1MjYzMTYsImV4cCI6MjA5MTEwMjMxNn0."
    "q5rckF4YhRs4KEyg5c1F93Deq8Qhf7li540XfhZdhas"
)


def _ts_to_iso(ts: Optional[float]) -> Optional[str]:
    """Convert a Unix timestamp (ms) to ISO 8601 string."""
    if ts is None:
        return None
    return datetime.fromtimestamp(ts / 1000, tz=timezone.utc).isoformat()


def _serialize_session_data(session: Session) -> dict:
    """Serialize session reads/pending_actions for JSON storage."""
    reads = []
    for r in session.reads:
        reads.append({
            "id": r.id,
            "name": r.name,
            "params": r.params,
            "timestamp": r.timestamp,
            "classification": {
                "intent": r.classification.intent.value,
                "isPassthrough": r.classification.is_passthrough,
                "confidence": r.classification.confidence,
                "reason": r.classification.reason,
            },
            "result": r.result,
        })

    pending = []
    for a in session.pending_actions:
        pending.append({
            "id": a.id,
            "name": a.name,
            "params": a.params,
            "timestamp": a.timestamp,
            "classification": {
                "intent": a.classification.intent.value,
                "isPassthrough": a.classification.is_passthrough,
                "confidence": a.classification.confidence,
                "reason": a.classification.reason,
            },
            "phantomResult": a.phantom_result,
            "approved": a.approved,
            "editedParams": a.edited_params,
        })

    return {"reads": reads, "pending_actions": pending}


class SupabasePersistence:
    """Handles saving ToolGate sessions to Supabase."""

    def __init__(
        self,
        url: str,
        key: str,
        api_key: Optional[str] = None,
    ):
        self._url = url.rstrip("/")
        self._key = key
        self._api_key = api_key
        self._cached_user_id: Optional[str] = None

    @classmethod
    def from_api_key(cls, api_key: str) -> "SupabasePersistence":
        """Create a persistence instance from a ToolGate API key."""
        return cls(_TOOLGATE_SUPABASE_URL, _TOOLGATE_SUPABASE_ANON_KEY, api_key)

    @property
    def user_id(self) -> Optional[str]:
        return self._cached_user_id

    # ─── RPC-based methods (API key auth) ─────────────────────────────

    async def _rpc_call(self, fn_name: str, params: dict) -> Any:
        endpoint = f"{self._url}/rest/v1/rpc/{fn_name}"
        headers = {
            "apikey": self._key,
            "Authorization": f"Bearer {self._key}",
            "Content-Type": "application/json",
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(endpoint, headers=headers, json=params)
        if resp.status_code >= 400:
            raise RuntimeError(f"ToolGate RPC {fn_name} failed: {resp.status_code} {resp.text}")
        return resp.json()

    async def save_session(self, session: Session) -> None:
        serialized = _serialize_session_data(session)

        if self._api_key:
            result = await self._rpc_call("create_session_with_api_key", {
                "p_api_key": self._api_key,
                "p_session_id": session.id,
                "p_agent_name": session.agent_name,
                "p_task_desc": session.task_description or None,
                "p_status": session.status.value,
                "p_started_at": _ts_to_iso(session.started_at),
                "p_completed_at": _ts_to_iso(session.completed_at),
                "p_reads": serialized["reads"],
                "p_pending": serialized["pending_actions"],
                "p_metadata": session.metadata,
            })
            if isinstance(result, dict) and result.get("error"):
                raise RuntimeError(f"ToolGate API key error: {result['error']}")
            if isinstance(result, dict) and result.get("user_id"):
                self._cached_user_id = result["user_id"]
            return

        # Legacy: direct insert
        await self._direct_rpc("toolgate_sessions", "POST", {
            "id": session.id,
            "agent_name": session.agent_name,
            "task_description": session.task_description,
            "status": session.status.value,
            "started_at": _ts_to_iso(session.started_at),
            "completed_at": _ts_to_iso(session.completed_at),
            "reads": json.dumps(serialized["reads"]),
            "pending_actions": json.dumps(serialized["pending_actions"]),
            "metadata": json.dumps(session.metadata) if session.metadata else None,
        })

    async def get_session(self, session_id: str) -> Optional[dict]:
        if self._api_key:
            result = await self._rpc_call("get_session_with_api_key", {
                "p_api_key": self._api_key,
                "p_session_id": session_id,
            })
            if not result or (isinstance(result, dict) and result.get("error")):
                return None
            return result

        endpoint = f"{self._url}/rest/v1/toolgate_sessions?id=eq.{session_id}&select=*"
        headers = {
            "apikey": self._key,
            "Authorization": f"Bearer {self._key}",
        }
        async with httpx.AsyncClient() as client:
            resp = await client.get(endpoint, headers=headers)
        if resp.status_code >= 400:
            return None
        rows = resp.json()
        return rows[0] if rows else None

    async def update_session(self, session: Session) -> None:
        serialized = _serialize_session_data(session)

        if self._api_key:
            result = await self._rpc_call("update_session_with_api_key", {
                "p_api_key": self._api_key,
                "p_session_id": session.id,
                "p_status": session.status.value,
                "p_completed_at": _ts_to_iso(session.completed_at),
                "p_pending": serialized["pending_actions"],
            })
            if isinstance(result, dict) and result.get("error"):
                raise RuntimeError(f"ToolGate API key error: {result['error']}")
            return

        await self._direct_rpc(
            "toolgate_sessions",
            "PATCH",
            {
                "status": session.status.value,
                "completed_at": _ts_to_iso(session.completed_at),
                "pending_actions": json.dumps(serialized["pending_actions"]),
            },
            match={"id": session.id},
        )

    # ─── Legacy direct REST calls ─────────────────────────────────────

    async def _direct_rpc(
        self,
        table: str,
        method: str,
        body: dict,
        match: Optional[dict[str, str]] = None,
    ) -> Any:
        endpoint = f"{self._url}/rest/v1/{table}"
        headers = {
            "apikey": self._key,
            "Authorization": f"Bearer {self._key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation",
        }
        if match:
            qs = "&".join(f"{k}=eq.{v}" for k, v in match.items())
            endpoint += f"?{qs}"

        async with httpx.AsyncClient() as client:
            resp = await client.request(method, endpoint, headers=headers, json=body)
        if resp.status_code >= 400:
            raise RuntimeError(f"Supabase {method} {table} failed: {resp.status_code} {resp.text}")
        return resp.json()
