"""Type definitions for ToolGate — mirrors the TypeScript types exactly."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Awaitable, Optional


# ─── Tool Classification ────────────────────────────────────────────

class ToolIntent(str, Enum):
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    CREATE = "create"
    UPDATE = "update"
    EXECUTE = "execute"
    SEND = "send"
    UNKNOWN = "unknown"


@dataclass
class ToolClassification:
    intent: ToolIntent
    is_passthrough: bool  # True = read-like, execute immediately
    confidence: float     # 0-1
    reason: str


# ─── Tool Call Representation ───────────────────────────────────────

@dataclass
class ToolCall:
    id: str
    name: str
    params: dict[str, Any]
    timestamp: float
    classification: ToolClassification


@dataclass
class ExecutedRead(ToolCall):
    result: Any = None


@dataclass
class PendingAction(ToolCall):
    phantom_result: Any = None  # what we told the agent happened
    approved: Optional[bool] = None
    edited_params: Optional[dict[str, Any]] = None


# ─── Session ────────────────────────────────────────────────────────

class SessionStatus(str, Enum):
    RUNNING = "running"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    PARTIAL = "partial"


@dataclass
class Session:
    id: str
    agent_name: str
    task_description: str
    started_at: float
    status: SessionStatus
    reads: list[ExecutedRead] = field(default_factory=list)
    pending_actions: list[PendingAction] = field(default_factory=list)
    completed_at: Optional[float] = None
    user_id: Optional[str] = None
    api_key_id: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None


# ─── Approval ───────────────────────────────────────────────────────

@dataclass
class ApprovalRequest:
    session_id: str
    agent_name: str
    task_description: str
    reads: list[ExecutedRead]
    pending_actions: list[PendingAction]
    created_at: float


@dataclass
class ActionDecision:
    action: str  # "approve" | "reject" | "edit"
    action_id: Optional[str] = None
    new_params: Optional[dict[str, Any]] = None


@dataclass
class ApprovalResult:
    session_id: str
    decisions: dict[str, ActionDecision]
    approved_at: float


# ─── MCP ────────────────────────────────────────────────────────────

@dataclass
class MCPToolDef:
    name: str
    description: str
    input_schema: Optional[dict[str, Any]] = None


@dataclass
class MCPServerDef:
    name: str
    url: str
    tools: Optional[list[MCPToolDef]] = None


# ─── Configuration ──────────────────────────────────────────────────

# Type aliases for callables
RealExecutor = Callable[[str, dict[str, Any]], Awaitable[Any]]
ClassifierFn = Callable[[str, dict[str, Any]], ToolClassification]
PhantomResponseFn = Callable[[ToolCall], Any]
ApprovalCallback = Callable[[ApprovalRequest], Awaitable[ApprovalResult]]


@dataclass
class ToolGateConfig:
    """Configuration for ToolGate."""

    # Your ToolGate API key (get one from the dashboard)
    api_key: Optional[str] = None

    # Custom classifier — override the built-in heuristic
    classifier: Optional[ClassifierFn] = None

    # Explicit read tool names (always passthrough)
    read_tools: Optional[list[str]] = None

    # Explicit write/action tool names (always intercept)
    action_tools: Optional[list[str]] = None

    # What to return to the agent when an action is intercepted
    phantom_response: Optional[PhantomResponseFn] = None

    # Called when session completes and needs approval
    on_approval_needed: Optional[ApprovalCallback] = None

    # Agent display name
    agent_name: str = "agent"

    # MCP server definitions for auto-classification
    mcp_servers: Optional[list[MCPServerDef]] = None

    # Supabase URL (deprecated — use api_key instead)
    supabase_url: Optional[str] = None

    # Supabase anon key (deprecated — use api_key instead)
    supabase_key: Optional[str] = None
