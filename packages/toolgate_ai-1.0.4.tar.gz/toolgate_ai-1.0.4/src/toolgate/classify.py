"""
Multi-layer tool classifier — determines if a tool call is a read (passthrough)
or an action (intercept). Exact port of the TypeScript classifier.
"""

from __future__ import annotations

import re
from typing import Optional

from toolgate.types import ToolClassification, ToolIntent, MCPToolDef


# ─── Pattern Dictionaries ───────────────────────────────────────────

READ_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(get|read|fetch|list|search|find|query|lookup|describe|show|view|check|"
        r"inspect|retrieve|browse|scan|count|exists|head|peek|poll|watch|observe|select|load)",
        re.IGNORECASE,
    ),
    re.compile(
        r"([-_]get$|[-_]read$|[-_]list$|[-_]fetch$|[-_]search$|[-_]find$|"
        r"[-_]query$|[-_]describe$|[-_]show$|[-_]view$|[-_]check$)",
        re.IGNORECASE,
    ),
    re.compile(r"^(is[-_]|has[-_]|can[-_]|does[-_])", re.IGNORECASE),
]

WRITE_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(create|write|put|set|add|insert|post|save|store|upload|push|append|"
        r"upsert|make|generate|build|init|register|submit|publish)",
        re.IGNORECASE,
    ),
    re.compile(
        r"([-_]create$|[-_]write$|[-_]add$|[-_]insert$|[-_]post$|[-_]save$|"
        r"[-_]upload$|[-_]push$|[-_]set$|[-_]submit$|[-_]publish$)",
        re.IGNORECASE,
    ),
]

DELETE_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(delete|remove|destroy|drop|purge|clear|clean|unset|revoke|cancel|"
        r"terminate|kill|close|archive|trash|wipe|reset)",
        re.IGNORECASE,
    ),
    re.compile(
        r"([-_]delete$|[-_]remove$|[-_]destroy$|[-_]drop$|[-_]clear$|"
        r"[-_]cancel$|[-_]revoke$|[-_]close$|[-_]archive$|[-_]trash$)",
        re.IGNORECASE,
    ),
]

UPDATE_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(update|edit|modify|patch|change|alter|replace|rename|move|merge|"
        r"assign|reassign|transfer|swap|toggle|enable|disable|approve|reject|resolve|reopen)",
        re.IGNORECASE,
    ),
    re.compile(
        r"([-_]update$|[-_]edit$|[-_]modify$|[-_]patch$|[-_]change$|"
        r"[-_]rename$|[-_]move$|[-_]merge$|[-_]assign$|[-_]toggle$)",
        re.IGNORECASE,
    ),
]

EXECUTE_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(run|exec|execute|invoke|trigger|fire|dispatch|emit|call|start|restart|"
        r"stop|deploy|rollback|migrate|sync|process|transform|convert|compile|evaluate)",
        re.IGNORECASE,
    ),
    re.compile(
        r"([-_]run$|[-_]exec$|[-_]execute$|[-_]trigger$|[-_]deploy$|"
        r"[-_]start$|[-_]stop$|[-_]restart$)",
        re.IGNORECASE,
    ),
]

SEND_PATTERNS: list[re.Pattern] = [
    re.compile(
        r"^(send|email|mail|notify|message|broadcast|forward|reply|share|"
        r"invite|alert|ping|sms|slack|tweet|dm|comment)",
        re.IGNORECASE,
    ),
    re.compile(
        r"([-_]send$|[-_]email$|[-_]notify$|[-_]message$|[-_]share$|"
        r"[-_]forward$|[-_]reply$|[-_]comment$|[-_]invite$)",
        re.IGNORECASE,
    ),
]


# ─── MCP Description Analysis ───────────────────────────────────────

READ_DESCRIPTION_SIGNALS = [
    "retrieve", "get", "fetch", "list", "search", "find", "query",
    "read", "show", "view", "check", "look up", "returns", "display",
    "browse", "inspect", "describe", "status", "info", "details",
]

MUTATE_DESCRIPTION_SIGNALS = [
    "create", "update", "delete", "remove", "modify", "write", "set",
    "send", "post", "put", "patch", "add", "insert", "push", "publish",
    "execute", "run", "trigger", "invoke", "deploy", "move", "rename",
    "edit", "change", "assign", "transfer", "submit", "approve", "reject",
    "archive", "trash", "clear", "revoke", "cancel", "forward", "reply",
    "share", "invite", "notify", "message", "email", "broadcast",
]


def _classify_from_description(description: str) -> tuple[ToolIntent, float]:
    lower = description.lower()
    read_score = sum(1 for s in READ_DESCRIPTION_SIGNALS if s in lower)
    mutate_score = sum(1 for s in MUTATE_DESCRIPTION_SIGNALS if s in lower)

    if read_score > 0 and mutate_score == 0:
        return ToolIntent.READ, 0.8
    if mutate_score > 0 and read_score == 0:
        return ToolIntent.WRITE, 0.8
    if mutate_score > read_score:
        return ToolIntent.WRITE, 0.6
    if read_score > mutate_score:
        return ToolIntent.READ, 0.6
    return ToolIntent.UNKNOWN, 0.3


# ─── HTTP Method Heuristic ──────────────────────────────────────────

def _classify_from_http_hints(params: dict) -> Optional[ToolIntent]:
    method = params.get("method")
    if not isinstance(method, str):
        return None
    method = method.upper()
    if method in ("GET", "HEAD", "OPTIONS"):
        return ToolIntent.READ
    if method == "POST":
        return ToolIntent.CREATE
    if method in ("PUT", "PATCH"):
        return ToolIntent.UPDATE
    if method == "DELETE":
        return ToolIntent.DELETE
    return None


# ─── Main Classifier ────────────────────────────────────────────────

def classify_tool(
    tool_name: str,
    params: dict,
    mcp_tool_def: Optional[MCPToolDef] = None,
) -> ToolClassification:
    """
    Classify a tool call as read (passthrough) or action (intercept).

    Classification layers:
    1. HTTP method hints in params
    2. Tool name pattern matching
    3. MCP tool description analysis
    4. Safe default — unknown tools are intercepted
    """
    # 1. Check HTTP method hints in params
    http_intent = _classify_from_http_hints(params)
    if http_intent is not None:
        return ToolClassification(
            intent=http_intent,
            is_passthrough=http_intent == ToolIntent.READ,
            confidence=0.85,
            reason=f"HTTP method in params indicates {http_intent.value}",
        )

    # 2. Pattern match on tool name
    pattern_checks: list[tuple[list[re.Pattern], ToolIntent, bool, float]] = [
        (READ_PATTERNS, ToolIntent.READ, True, 0.9),
        (DELETE_PATTERNS, ToolIntent.DELETE, False, 0.9),
        (SEND_PATTERNS, ToolIntent.SEND, False, 0.9),
        (WRITE_PATTERNS, ToolIntent.WRITE, False, 0.9),
        (UPDATE_PATTERNS, ToolIntent.UPDATE, False, 0.9),
        (EXECUTE_PATTERNS, ToolIntent.EXECUTE, False, 0.85),
    ]

    for patterns, intent, passthrough, confidence in pattern_checks:
        for pat in patterns:
            if pat.search(tool_name):
                return ToolClassification(
                    intent=intent,
                    is_passthrough=passthrough,
                    confidence=confidence,
                    reason=f"Tool name matches {intent.value} pattern: {pat.pattern}",
                )

    # 3. If MCP tool definition exists, analyze description
    if mcp_tool_def and mcp_tool_def.description:
        desc_intent, desc_confidence = _classify_from_description(mcp_tool_def.description)
        return ToolClassification(
            intent=desc_intent,
            is_passthrough=desc_intent == ToolIntent.READ,
            confidence=desc_confidence,
            reason=f'MCP tool description analysis: "{mcp_tool_def.description[:80]}..."',
        )

    # 4. Fallback: unknown = intercept (safe default)
    return ToolClassification(
        intent=ToolIntent.UNKNOWN,
        is_passthrough=False,
        confidence=0.2,
        reason="Could not classify tool — intercepting as precaution",
    )
