"""
ToolGate — Core class.

The main entry point for the library. Create a ToolGate instance,
hand gate.proxy to your agent, and call gate.finalize() when done.
"""

from __future__ import annotations

import copy
import time
import uuid
from typing import Any, Optional

from toolgate.types import (
    ToolGateConfig,
    ToolCall,
    ExecutedRead,
    PendingAction,
    Session,
    SessionStatus,
    ApprovalRequest,
    ApprovalResult,
    ToolClassification,
    ToolIntent,
    MCPToolDef,
    RealExecutor,
)
from toolgate.classify import classify_tool
from toolgate.persistence import SupabasePersistence


class ToolGate:
    """
    Optimistic execution middleware for autonomous agents.

    Usage::

        gate = ToolGate(execute, api_key="tg_live_...", agent_name="my-agent")

        # Give your agent gate.proxy instead of the real executor
        result = await gate.proxy("listEmails", {})

        # When done, finalize — triggers the approval flow
        await gate.finalize()
    """

    def __init__(
        self,
        executor: RealExecutor,
        *,
        api_key: Optional[str] = None,
        agent_name: str = "agent",
        classifier: Optional[Any] = None,
        read_tools: Optional[list[str]] = None,
        action_tools: Optional[list[str]] = None,
        phantom_response: Optional[Any] = None,
        on_approval_needed: Optional[Any] = None,
        mcp_servers: Optional[list] = None,
        supabase_url: Optional[str] = None,
        supabase_key: Optional[str] = None,
        config: Optional[ToolGateConfig] = None,
    ):
        # Allow passing a config object or individual kwargs
        if config:
            self._config = config
        else:
            self._config = ToolGateConfig(
                api_key=api_key,
                classifier=classifier,
                read_tools=read_tools,
                action_tools=action_tools,
                phantom_response=phantom_response,
                on_approval_needed=on_approval_needed,
                agent_name=agent_name,
                mcp_servers=mcp_servers,
                supabase_url=supabase_url,
                supabase_key=supabase_key,
            )

        self._executor = executor
        self._read_set: set[str] = set(self._config.read_tools or [])
        self._action_set: set[str] = set(self._config.action_tools or [])

        # Index MCP tools for fast lookup
        self._mcp_tool_index: dict[str, MCPToolDef] = {}
        for server in self._config.mcp_servers or []:
            for tool in server.tools or []:
                self._mcp_tool_index[tool.name] = tool

        # Persistence — prefer API key, fall back to direct Supabase creds
        self._persistence: Optional[SupabasePersistence] = None
        if self._config.api_key:
            self._persistence = SupabasePersistence.from_api_key(self._config.api_key)
        elif self._config.supabase_url and self._config.supabase_key:
            self._persistence = SupabasePersistence(
                self._config.supabase_url, self._config.supabase_key
            )

        self._session = Session(
            id=str(uuid.uuid4()),
            agent_name=self._config.agent_name,
            task_description="",
            started_at=time.time() * 1000,
            status=SessionStatus.RUNNING,
            reads=[],
            pending_actions=[],
        )

    # ─── Public API ───────────────────────────────────────────────────

    def describe(self, task_description: str) -> "ToolGate":
        """Set a human-readable description for this task/session."""
        self._session.task_description = task_description
        return self

    async def proxy(self, tool_name: str, params: dict[str, Any]) -> Any:
        """The proxy function you hand to the agent instead of the real executor."""
        return await self._handle(tool_name, params)

    def wrap_tools(self, tools: dict[str, Any]) -> dict[str, Any]:
        """Wrap an existing tool map (name → function) into a proxied tool map."""
        proxied = {}
        for name in tools:
            async def _proxy(params: dict = {}, _name: str = name) -> Any:
                return await self._handle(_name, params)
            proxied[name] = _proxy
        return proxied

    # ─── Core: classify and either passthrough or intercept ───────────

    async def _handle(self, tool_name: str, params: dict[str, Any]) -> Any:
        classification = self._classify(tool_name, params)

        call = ToolCall(
            id=str(uuid.uuid4()),
            name=tool_name,
            params=copy.deepcopy(params),
            timestamp=time.time() * 1000,
            classification=classification,
        )

        if classification.is_passthrough:
            # ✅ READ — execute for real, record it
            result = await self._executor(tool_name, params)
            read = ExecutedRead(
                id=call.id,
                name=call.name,
                params=call.params,
                timestamp=call.timestamp,
                classification=call.classification,
                result=result,
            )
            self._session.reads.append(read)
            return result

        # 🛑 ACTION — intercept, return phantom
        if self._config.phantom_response:
            phantom_result = self._config.phantom_response(call)
        else:
            phantom_result = self._default_phantom(call)

        pending = PendingAction(
            id=call.id,
            name=call.name,
            params=call.params,
            timestamp=call.timestamp,
            classification=call.classification,
            phantom_result=phantom_result,
        )
        self._session.pending_actions.append(pending)

        return phantom_result

    def _classify(self, tool_name: str, params: dict) -> ToolClassification:
        # Explicit overrides first
        if tool_name in self._read_set:
            return ToolClassification(
                intent=ToolIntent.READ,
                is_passthrough=True,
                confidence=1.0,
                reason="Explicitly listed as read tool",
            )
        if tool_name in self._action_set:
            return ToolClassification(
                intent=ToolIntent.WRITE,
                is_passthrough=False,
                confidence=1.0,
                reason="Explicitly listed as action tool",
            )

        # Custom classifier
        if self._config.classifier:
            return self._config.classifier(tool_name, params)

        # Built-in classifier
        mcp_def = self._mcp_tool_index.get(tool_name)
        return classify_tool(tool_name, params, mcp_def)

    def _default_phantom(self, call: ToolCall) -> dict:
        intent = call.classification.intent
        base = {"success": True, "_phantom": True, "toolCallId": call.id}

        if intent in (ToolIntent.CREATE, ToolIntent.WRITE):
            return {**base, "id": f"phantom_{uuid.uuid4().hex[:8]}", "message": "Created successfully"}
        elif intent == ToolIntent.UPDATE:
            return {**base, "message": "Updated successfully"}
        elif intent == ToolIntent.DELETE:
            return {**base, "message": "Deleted successfully"}
        elif intent == ToolIntent.SEND:
            return {**base, "message": "Sent successfully", "messageId": f"msg_{uuid.uuid4().hex[:8]}"}
        elif intent == ToolIntent.EXECUTE:
            return {**base, "message": "Executed successfully", "exitCode": 0}
        else:
            return {**base, "message": "Completed successfully"}

    # ─── Finalization ─────────────────────────────────────────────────

    async def finalize(self) -> ApprovalRequest:
        """Call when agent is done. Returns the approval request."""
        self._session.completed_at = time.time() * 1000
        self._session.status = SessionStatus.PENDING_APPROVAL

        request = ApprovalRequest(
            session_id=self._session.id,
            agent_name=self._session.agent_name,
            task_description=self._session.task_description,
            reads=self._session.reads,
            pending_actions=self._session.pending_actions,
            created_at=time.time() * 1000,
        )

        # Persist to Supabase if configured
        if self._persistence:
            await self._persistence.save_session(self._session)

        # If callback is registered, wait for approval
        if self._config.on_approval_needed:
            result = await self._config.on_approval_needed(request)
            await self.execute_approval(result)

        return request

    async def execute_approval(self, result: ApprovalResult) -> dict[str, Any]:
        """Execute approved actions for real."""
        results: dict[str, Any] = {}

        for action in self._session.pending_actions:
            decision = result.decisions.get(action.id)

            if not decision or decision.action == "reject":
                action.approved = False
                continue

            if decision.action == "approve":
                action.approved = True
                real_result = await self._executor(action.name, action.params)
                results[action.id] = real_result

            if decision.action == "edit" and decision.new_params:
                action.approved = True
                action.edited_params = decision.new_params
                real_result = await self._executor(action.name, decision.new_params)
                results[action.id] = real_result

        if all(a.approved for a in self._session.pending_actions):
            self._session.status = SessionStatus.APPROVED
        elif any(a.approved for a in self._session.pending_actions):
            self._session.status = SessionStatus.PARTIAL
        else:
            self._session.status = SessionStatus.REJECTED

        if self._persistence:
            await self._persistence.update_session(self._session)

        return results

    async def approve_all(self) -> dict[str, Any]:
        """Approve all pending actions at once."""
        from toolgate.types import ActionDecision

        decisions = {
            a.id: ActionDecision(action="approve")
            for a in self._session.pending_actions
        }
        return await self.execute_approval(
            ApprovalResult(
                session_id=self._session.id,
                decisions=decisions,
                approved_at=time.time() * 1000,
            )
        )

    async def reject_all(self) -> None:
        """Reject all pending actions."""
        for action in self._session.pending_actions:
            action.approved = False
        self._session.status = SessionStatus.REJECTED
        if self._persistence:
            await self._persistence.update_session(self._session)

    # ─── Inspection ───────────────────────────────────────────────────

    @property
    def session_id(self) -> str:
        return self._session.id

    @property
    def reads(self) -> list:
        return self._session.reads

    @property
    def pending(self) -> list:
        return self._session.pending_actions

    @property
    def current_session(self) -> Session:
        return copy.deepcopy(self._session)

    def summary(self) -> str:
        """Pretty-print a summary for CLI / logging."""
        lines = [
            f"\n╔══════════════════════════════════════════════════╗",
            f"║  ToolGate Session: {self._session.id[:8]}…",
            f"║  Agent: {self._session.agent_name}",
            f"║  Task: {self._session.task_description or '(none)'}",
            f"╠══════════════════════════════════════════════════╣",
            f"║  ✅ Reads executed: {len(self._session.reads)}",
        ]

        for r in self._session.reads:
            params_str = str(r.params)[:60]
            lines.append(f"║    • {r.name}({params_str}…)")

        lines.append(f"║  ⏸  Actions pending approval: {len(self._session.pending_actions)}")

        for a in self._session.pending_actions:
            badge = a.classification.intent.value.upper()
            params_str = str(a.params)[:70]
            lines.append(f"║    🔶 [{badge}] {a.name}")
            lines.append(f"║      params: {params_str}…")

        lines.append(f"╚══════════════════════════════════════════════════╝\n")
        return "\n".join(lines)
