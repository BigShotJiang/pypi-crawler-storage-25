"""
Dashboard approval — polls Supabase until a human acts in the web dashboard.

Usage::

    gate = ToolGate(
        execute,
        **dashboard_approval(DashboardApprovalConfig(api_key="tg_live_..."))
    )
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Optional

from toolgate.types import (
    ApprovalRequest,
    ApprovalResult,
    ActionDecision,
)
from toolgate.persistence import SupabasePersistence


@dataclass
class DashboardApprovalConfig:
    """Configuration for dashboard-based approval."""

    # Your ToolGate API key (preferred)
    api_key: Optional[str] = None
    # Legacy Supabase URL
    supabase_url: Optional[str] = None
    # Legacy Supabase anon key
    supabase_key: Optional[str] = None
    # Polling interval in seconds (default: 2)
    poll_interval: float = 2.0
    # Timeout in seconds — reject all if no response (default: 10 minutes)
    timeout: float = 600.0
    # Called each poll cycle — for logging
    on_poll: Optional[object] = None


def dashboard_approval(config: DashboardApprovalConfig) -> dict:
    """
    Returns kwargs to spread into ToolGate constructor.

    Creates an `on_approval_needed` callback that:
    1. Saves the session to Supabase (so it appears in the dashboard)
    2. Polls until a human approves/rejects via the dashboard UI
    3. Returns the decisions so ToolGate can execute approved actions
    """
    # Create persistence from API key or legacy creds
    if config.api_key:
        persistence = SupabasePersistence.from_api_key(config.api_key)
    elif config.supabase_url and config.supabase_key:
        persistence = SupabasePersistence(config.supabase_url, config.supabase_key)
    else:
        raise ValueError(
            "dashboard_approval requires either `api_key` or `supabase_url` + `supabase_key`"
        )

    async def on_approval_needed(request: ApprovalRequest) -> ApprovalResult:
        print(f"\n🌐 Session saved to dashboard — waiting for approval...")
        print(f"   Open your dashboard and review session {request.session_id[:8]}…\n")

        start = time.time()

        while True:
            elapsed = time.time() - start

            if elapsed > config.timeout:
                print("⏰ Timeout — rejecting all actions.")
                decisions = {
                    a.id: ActionDecision(action="reject")
                    for a in request.pending_actions
                }
                return ApprovalResult(
                    session_id=request.session_id,
                    decisions=decisions,
                    approved_at=time.time() * 1000,
                )

            # Poll Supabase
            row = await persistence.get_session(request.session_id)

            if row and row.get("status") != "pending_approval":
                print(f"✅ Dashboard response received: {row['status']}")

                actions = row.get("pending_actions", [])
                if isinstance(actions, str):
                    actions = json.loads(actions)

                decisions: dict[str, ActionDecision] = {}
                for a in actions:
                    if a.get("approved") and a.get("editedParams"):
                        decisions[a["id"]] = ActionDecision(
                            action="edit",
                            action_id=a["id"],
                            new_params=a["editedParams"],
                        )
                    elif a.get("approved"):
                        decisions[a["id"]] = ActionDecision(action="approve")
                    else:
                        decisions[a["id"]] = ActionDecision(action="reject")

                return ApprovalResult(
                    session_id=request.session_id,
                    decisions=decisions,
                    approved_at=time.time() * 1000,
                )

            if config.on_poll and callable(config.on_poll):
                config.on_poll(elapsed)

            await asyncio.sleep(config.poll_interval)

    # Return kwargs to spread into ToolGate constructor
    result: dict = {"on_approval_needed": on_approval_needed}
    if config.api_key:
        result["api_key"] = config.api_key
    else:
        result["supabase_url"] = config.supabase_url
        result["supabase_key"] = config.supabase_key
    return result
