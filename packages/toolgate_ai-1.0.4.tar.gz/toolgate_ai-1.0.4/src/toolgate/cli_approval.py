"""
Interactive CLI approval flow.

Pass cli_approval as `on_approval_needed` in ToolGateConfig to get a
terminal-based approval UI.

Usage::

    gate = ToolGate(execute, api_key="tg_live_...", on_approval_needed=cli_approval)
"""

from __future__ import annotations

import json
from typing import Any

from toolgate.types import (
    ApprovalRequest,
    ApprovalResult,
    ActionDecision,
    PendingAction,
)

INTENT_COLORS = {
    "write":   "\033[33m",   # yellow
    "create":  "\033[32m",   # green
    "delete":  "\033[31m",   # red
    "update":  "\033[36m",   # cyan
    "send":    "\033[35m",   # magenta
    "execute": "\033[34m",   # blue
    "unknown": "\033[37m",   # white
}
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"


def _badge(intent: str) -> str:
    color = INTENT_COLORS.get(intent, INTENT_COLORS["unknown"])
    return f"{color}{BOLD}[{intent.upper()}]{RESET}"


import time


async def cli_approval(request: ApprovalRequest) -> ApprovalResult:
    """
    Interactive CLI approval flow.
    Prints a summary and asks the user to approve/reject/edit each action.
    """
    print(f"\n{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{BOLD}  🛡️  ToolGate — Approval Required{RESET}")
    print(f"{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"  Agent:   {request.agent_name}")
    print(f"  Task:    {request.task_description or '(no description)'}")
    print(f"  Session: {request.session_id[:8]}…")
    print()

    # Show reads
    print(f"{DIM}── Reads performed ({len(request.reads)}) ──{RESET}")
    for r in request.reads:
        params_str = json.dumps(r.params)[:80]
        print(f"  ✅ {r.name}({params_str})")
    print()

    # Show pending actions
    print(f"{BOLD}── Actions awaiting approval ({len(request.pending_actions)}) ──{RESET}")
    for i, a in enumerate(request.pending_actions):
        intent_str = a.classification.intent.value if hasattr(a.classification.intent, 'value') else str(a.classification.intent)
        print(f"  {i + 1}. {_badge(intent_str)} {a.name}")
        params_pretty = json.dumps(a.params, indent=2).replace("\n", "\n     ")
        print(f"     {DIM}params:{RESET} {params_pretty}")
        print()

    print(f"{BOLD}Options:{RESET}")
    print(f"  {BOLD}a{RESET} = approve all    {BOLD}r{RESET} = reject all    {BOLD}i{RESET} = review individually")
    choice = input("\n> ").strip().lower()

    decisions: dict[str, ActionDecision] = {}

    if choice == "a":
        for a in request.pending_actions:
            decisions[a.id] = ActionDecision(action="approve")
        print("\n✅ All actions approved.")
    elif choice == "r":
        for a in request.pending_actions:
            decisions[a.id] = ActionDecision(action="reject")
        print("\n❌ All actions rejected.")
    else:
        # Individual review
        for i, a in enumerate(request.pending_actions):
            intent_str = a.classification.intent.value if hasattr(a.classification.intent, 'value') else str(a.classification.intent)
            print(f"\n{_badge(intent_str)} {a.name}")
            print(f"  params: {json.dumps(a.params, indent=2)}")
            d = input("  [a]pprove / [r]eject / [e]dit > ").strip().lower()

            if d in ("a", "approve"):
                decisions[a.id] = ActionDecision(action="approve")
            elif d in ("e", "edit"):
                print("  Enter new params as JSON:")
                raw = input("  > ")
                try:
                    new_params = json.loads(raw)
                    decisions[a.id] = ActionDecision(
                        action="edit", action_id=a.id, new_params=new_params
                    )
                except json.JSONDecodeError:
                    print("  ⚠️  Invalid JSON — rejecting this action.")
                    decisions[a.id] = ActionDecision(action="reject")
            else:
                decisions[a.id] = ActionDecision(action="reject")

    return ApprovalResult(
        session_id=request.session_id,
        decisions=decisions,
        approved_at=time.time() * 1000,
    )
