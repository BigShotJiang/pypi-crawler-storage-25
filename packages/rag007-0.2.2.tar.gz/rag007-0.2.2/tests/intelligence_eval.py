"""
Comprehensive RAG Intelligence Benchmark — multi-collection HitRate@5 + BoostScore@5 + FilterQuality
Collections: onetrade_articles (DE/FR), supplier_catalogs (DE/FR),
             customer, rag_multilingual, rag_benchmark (MTEB LegalQuAD)

Run:  uv run python intelligence_eval.py
Last line: Total=X/N=0.XXX
"""

from __future__ import annotations

import asyncio
import meilisearch
import os
import sys
import warnings
from pathlib import Path
from typing import Any, Callable

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings(
    "ignore",
    message="Core Pydantic V1 functionality",
    category=UserWarning,
    module="langchain_core",
)

from dotenv import load_dotenv  # noqa: E402

load_dotenv(".env")

from rag007 import AgenticRAG, _make_azure_embed_fn  # noqa: E402

# ── Test case types ────────────────────────────────────────────────────────────

# (query, expected_ids, id_field)  — HIT if ANY expected id appears in top-5
HIT_CASE = tuple[str, list[str], str]
# (query, high_id, low_id, id_field) — HIT if high ranks above low AND high in top-5
BOOST_CASE = tuple[str, str, str, str]
# (query, filter_expr, index, check_field, check_fn, min_in_top5, label)
# HIT if at least min_in_top5 of the filtered results satisfy check_fn(value)
FILTER_CASE = tuple[str, str, str, str, Callable[[Any], bool], int, str]


# ── onetrade_articles_de ───────────────────────────────────────────────────────

ONETRADE_DE_HITS: list[HIT_CASE] = [
    # legacy retrieval failure cases
    (
        "bieröffner",
        [
            "9173945",
            "9174113",
            "9167728",
            "01619310",
            "7794905",
        ],  # 7794905 = ProOne Multi-Tool 12 in 1 (has integrated Flaschenöffner)
        "article_id",
    ),
    ("proone kübel", ["9056369", "4477144", "9242698"], "article_id"),
    ("trockenbeton proone 016", ["4457227"], "article_id"),
    # high-volume articles — should rank top-5 on any reasonable query
    ("Geberit Dusch-WC Wandklosett spülrandlos", ["7501020", "9002696"], "article_id"),
    (
        "Laufen Wandklosett rimless Einbauspülkasten",
        ["5414193", "7889588", "7889601"],
        "article_id",
    ),
    ("Holcim OPTIMO Zement Siloware", ["2031524", "2045769"], "article_id"),
    # brand + product type
    (
        "Geberit Spülkasten AP Zweimengenbetätigung",
        ["7501080", "6142928", "01527103", "01527073"],
        "article_id",
    ),
    ("SPAX Inox A4 Schrauben Torx", ["1118554", "1118557"], "article_id"),
    ("Isolierband PVC schwarz Tesa", ["1138472", "1138303"], "article_id"),
    # synonym / variant coverage — tests whether multi-query bridges lexical gaps
    (
        "fertigbeton",  # synonym: Fertigbeton ≡ Trockenbeton
        ["4509217", "2028807", "4118137", "4457227"],
        "article_id",
    ),
    (
        "bohr maschine",  # compound-split: "bohr maschine" → Bohrmaschine
        ["8106841", "7972539", "9024565", "1141717", "4456685"],
        "article_id",
    ),
    (
        "bohrer",  # related term: Bohrer → Spiralbohrer / drill bits
        ["9164853", "4477207", "8188433", "7993397"],
        "article_id",
    ),
    # intent-based queries — tests HyDE semantic bridging
    (
        "zement für eine mauer",  # intent → finds Zement-Mauermörtel
        ["8147884", "7972267", "1015814", "1000434"],
        "article_id",
    ),
    (
        "rohr verstopft",  # problem description → finds Rohrreiniger
        ["7500071", "5376463", "5376464"],
        "article_id",
    ),
    (
        "dach abdichten",  # use-case → finds Dachabdichtung / Dampfbremse
        ["7913372", "1008566", "1008568", "1008709", "23028002", "1027085"],
        "article_id",
    ),
    (
        "heizung reparatur ventil",  # repair intent → finds heating valves
        ["8110729", "7204491", "3813974", "3813975"],
        "article_id",
    ),
    # compound word splits — query uses split form, catalog has fused compound
    (
        "stein bohrer",  # "stein bohrer" → SDS-Plus Betonbohrer (Bosch Expert)
        ["7011372", "7011346", "7011365", "7011347", "7834271"],
        "article_id",
    ),
    (
        "gewebeschlauch wasser",  # compound → Gewebe-Wasserschlauch (reinforced hose)
        ["7913461", "01583935", "7913460", "5418822"],
        "article_id",
    ),
    # abbreviations + technical specs
    (
        "SDS Plus Bohrer",  # SDS+ = Slotted Drive System → Bosch Expert Betonbohrer
        ["7011349", "7011348", "7011371", "7011364", "7834271"],
        "article_id",
    ),
    (
        "PE-X Rohr 16mm",  # PE-X = cross-linked polyethylene pipe
        ["9148133", "3812629", "3812631"],
        "article_id",
    ),
    (
        "M10 Sechskantschraube",  # M10 = thread size spec → hex bolt DIN 933/931
        ["1077123", "1077129", "1077220", "1077124", "1077127"],
        "article_id",
    ),
    # exact product name — must always rank top (fundamental precision test)
    ("Bosch Expert Hammerbohrer SDS-Plus 7X 10x200x265mm", ["7011372"], "article_id"),
    (
        "ProOne Trockenbeton 016 Sack 25 kg",  # exact ProOne concrete → must find 4457227
        ["4457227"],
        "article_id",
    ),
    (
        "ProOne SCC Trockenbeton 016 selbstverdichtend",  # SCC variant — selbstverdichtend disambiguates
        ["8121487"],
        "article_id",
    ),
    (
        "Kies Körnung 8/16",  # dimensional spec → rounded gravel 8-16mm
        ["9150107", "1000014", "01561897"],
        "article_id",
    ),
    # more intent / problem-description queries
    (
        "fliesen kleben boden",  # intent → Fliesenkleber (tile adhesive)
        ["7203758", "8140724", "9002950", "7500028"],
        "article_id",
    ),
    (
        "schimmel bad entfernen",  # problem → Schimmel-EX / anti-mold products
        ["01522642", "9200538", "9200541", "9200540"],
        "article_id",
    ),
    (
        "maurerkelle metall",  # tool lookup → masonry trowel
        ["1050322", "1050325", "1050326", "1050327"],
        "article_id",
    ),
    # basement waterproofing intent → Kellerabdichtung products (not mirror cabinets / Keller brand)
    (
        "Keller abdichten",
        ["7520537", "6187250", "7520344", "7521005", "7925844"],
        "article_id",
    ),
    # demolition tool + chisel accessory
    ("Abbruchhammer Meißel", ["2033912", "8067824", "1142377"], "article_id"),
    # drain pipe spec — HT high-temp drain, DN100 = 110mm OD
    ("HT Rohr DN100", ["2038190", "3810402"], "article_id"),
    # outdoor wood protection → Saicos Holzlasur / Holzöl / Imprägnierung
    (
        "Holzlasur Aussen Schutz",
        ["21015713", "21015712", "9138103", "9138349", "1006902", "8106911"],
        "article_id",
    ),
    # roof insulation — glass wool batts (Knauf Unifit)
    ("Glaswolle Dach", ["1008341", "1008347", "9242654", "9242652"], "article_id"),
    # basement wall insulation → Multitherm 110 or Gutex DW panels
    (
        "Dämmplatte Keller Wand",
        ["7849875", "7849872", "7849869", "7849878", "23027253", "7913418"],
        "article_id",
    ),
    # nails + driving tool — Baustifte (wire nails) ARE the product
    (
        "Nägel Einschlagen Stahl",
        [
            "1073129",
            "1061533",
            "8108989",
            "1061531",
            "2012854",
            "2012856",
            "2016107",
            "8109048",
        ],
        "article_id",
    ),
    # ── intent / need-based queries — user describes WHAT they need to DO ────
    # "Dämmplatten kleben auf Beton Keller" → PCI Dämmplattenkleber / Bitumen-Kleber
    (
        "Dämmplatten kleben auf Beton Keller",
        ["4477111", "7012343", "1003694", "1003696", "1003693", "7849875", "7849872"],
        "article_id",
    ),
    # "Boden muss eben sein" → Nivelliermasse / Ausgleichsmasse
    (
        "Boden muss eben sein vor Fliesen legen",
        [
            "8107629",
            "9002824",
            "1015808",
            "7925801",  # Fliessestrich
            "7203762",
            "7203758",
            "7511132",
            "7511134",
            "01522955",
            "7499633",
            "7794475",
            "5418792",
        ],
        "article_id",
    ),
    # "Abfluss verstopft" → ProOne Rohrreiniger / Abfluss-Hurrikan / Bodenablauf
    (
        "Abfluss verstopft was hilft",
        [
            "5376463",
            "5376464",
            "7500071",
            "7500065",  # ProOne Rohrreiniger
            "1048201",
            "8138966",
            "4475859",
            "4475862",
        ],
        "article_id",
    ),
    # "Silikon für Dusche" → ProOne Sanitärsilikon / Universalsilikon
    (
        "Silikon für Dusche transparent",
        ["8147886", "1003220", "8149034", "8147885"],
        "article_id",
    ),
    # "LED Strahler Baustelle" → Brennenstuhl LED Strahler
    (
        "LED Strahler Baustelle",
        ["7840110", "7933941", "7933940", "7933929"],
        "article_id",
    ),
    # "WC Deckel Softclose" → Klosettsitz mit Absenkautomatik
    (
        "WC Deckel Softclose",
        ["01739883", "01812722", "01680073", "6208099", "3805697", "4482591"],
        "article_id",
    ),
    # "Parkett Eiche geölt" → 3-Schicht Parkett Eiche
    (
        "Parkett Eiche geölt",
        ["7925810", "7925808", "7925813", "6143554", "7931575", "7557106"],
        "article_id",
    ),
    # "Estrich giessen Sack" → Fliessestrich (Fixit 830 / Ardex)
    (
        "Estrich Fließestrich Sack 25 kg",
        ["8107629", "9002824", "1015808"],
        "article_id",
    ),
    # "Fugenmörtel grau" → Ecopierre / Schönox fugenmörtel
    ("Fugenmörtel grau Fliesen", ["9002477", "7984577", "7984548"], "article_id"),
    # ── typo-tolerant queries — misspelled but should still find product ─────
    # "Fliesenklber" (missing 'e') → Fliesenkleber
    (
        "Fliesenklber für Boden",
        ["7203758", "8140724", "01521901", "01521893", "01521869", "9002950"],
        "article_id",
    ),
    # "Schraubendräher" (ä instead of e, missing 't') → Schraubendreher
    ("Schraubendräher Kreuzschliz", ["1144127", "1144199", "1144068"], "article_id"),
    # "Betonmiscer" (missing 'h') → Betonmischer
    ("Betonmiscer 250 Liter", ["4457299", "4457300", "1050554"], "article_id"),
    # "Waschbeken" (missing 'c') → Waschtischsifon
    ("Waschbeken Siphon", ["7020066", "7020065", "01632816"], "article_id"),
    # "Silikkon Kartuche" (double k, missing s) → Silikon Kartusche
    (
        "Silikkon Kartuche transparent",
        ["8147886", "8149034", "1006783", "01521516"],
        "article_id",
    ),
    # ── direct product queries — diverse categories ──────────────────────────
    # Wasserzähler DN20 — water meter
    ("Wasserzähler DN20", ["5356854", "5356856", "2039824", "1031222"], "article_id"),
    # Kalkzement Grundputz — lime cement render
    (
        "Putz Kalkzement Sack 25 kg",
        ["9058313", "7972302", "9058314", "1000424"],
        "article_id",
    ),
    # Geberit Rohrschelle — pipe clamp
    ("Rohrschelle Edelstahl Geberit", ["2038687", "3810714", "5713721"], "article_id"),
    # ProOne Kabelbinder — cable ties
    ("Kabelbinder schwarz 200mm", ["1050154", "1154948", "1050155"], "article_id"),
    # Kupfer Reduktion 22-15 — copper reducer fitting
    ("Reduzierstück Kupfer 22-15", ["1028009", "1028010", "1028008"], "article_id"),
    # Pflasterstein Granit grau
    (
        "Pflasterstein Granit grau",
        ["1013577", "9120508", "9147828", "9120509"],
        "article_id",
    ),
    # Dachrinne Zink
    (
        "Dachrinne Zink halbrund",
        ["3816005", "3816007", "3816004", "3816006"],
        "article_id",
    ),
    # Heizung Pressfitting → Übergangsverschraubung
    (
        "Rohre verbinden Heizung Pressfitting",
        ["8057175", "8057172", "8057171", "8057169"],
        "article_id",
    ),
    # ── more intent / problem-description queries ────────────────────────────
    # "Beton mischen Baustelle" → Betonmischer
    (
        "Beton mischen auf der Baustelle was brauche ich",
        ["4457299", "4457300", "1050554", "1050558"],
        "article_id",
    ),
    # "Kupferrohr löten" → Kupferrohre Cuprolife
    (
        "Kupferrohr löten Zubehör",
        ["3815722", "3815720", "3815724", "7514524"],
        "article_id",
    ),
    # "Parkett schleifen" → Parkett products
    (
        "Boden schleifen Parkett",
        ["7938447", "7938446", "4476559", "7557107", "7021506"],
        "article_id",
    ),
]

# Boost: high-sales / own-brand should rank above comparable competitor
ONETRADE_DE_BOOSTS: list[BOOST_CASE] = [
    # ProOne 016 (own=True, 5.6M) > ProOne 008 (own=True, 3.3M) — intra-brand sales signal
    ("ProOne trockenbeton", "4457227", "4477141", "article_id"),
    # Procasa Duschsystem (own=True, 993k, boost=2.58) > Senzes (own=False, 2.1M, boost=2.21)
    # Own-brand 1.2× multiplier overcomes Senzes' 2× sales advantage
    ("duschsystem thermostat", "7956825", "7956824", "article_id"),
    # ProOne Universalsilikon (own=True, 209k) > Sista Sanitär Fugendichter (own=False, 85k)
    # Own-brand 1.2× multiplier keeps ProOne top when both appear for generic silikon query
    ("Silikon transparent Sanitär Kartusche", "8147886", "01568680", "article_id"),
]


# ── onetrade_articles_fr ───────────────────────────────────────────────────────

ONETRADE_FR_HITS: list[HIT_CASE] = [
    (
        "robinet machine à laver",
        ["3843246", "01629097", "01628528", "01730439"],
        "article_id",
    ),
    ("colle carrelage SIKA flex", ["6191479"], "article_id"),
    (
        "isolant laine de verre cloison",
        [
            "9235401",
            "9235407",
            "9235408",
            "1003693",
            "1003694",
            "1003696",
            "1003704",
            "1003706",
        ],
        "article_id",
    ),
    (
        "tuyau descente cuivre",
        [
            "1017242",
            "1017247",
            "1017248",
            "1017245",
            "1017246",
            "1017240",
            "1017244",
            "1017239",
        ],
        "article_id",
    ),
    ("enduit façade hydrofuge extérieur", ["1012611"], "article_id"),
    # intent / problem-description queries — tests HyDE semantic bridging
    (
        "robinet qui goutte",  # problem → finds regulation taps/faucets
        ["01631325", "01631322", "7020034", "7020031"],
        "article_id",
    ),
    (
        "imperméabiliser terrasse",  # use-case → finds waterproofing products
        ["1003241", "1003242", "1003240", "7965637"],
        "article_id",
    ),
    (
        "tuyau chauffage",  # product category in context → heating pipe
        ["9123824", "9123808", "9123812", "9123822"],
        "article_id",
    ),
    # Swiss French synonym test — "mélangeur" = standard FR "mitigeur"
    (
        "robinet mélangeur lavabo",  # Swiss FR "mélangeur" → Procasa Uno lavabo mixer
        ["7831344", "7020023", "7831345", "7831342"],
        "article_id",
    ),
    # type + attribute queries
    (
        "carrelage sol antidérapant",  # spec → non-slip floor tiles (R-rated)
        ["2040726", "2040735", "2040727", "2026357"],
        "article_id",
    ),
    # abbreviations FR
    (
        "PE-X tube 16mm",  # PE-X pipe (FR spelling → same product family)
        ["7965137", "9148133", "1027640", "9168182", "9168184"],
        "article_id",
    ),  # Sanipex BIO-PE-Xa d16mm
    # intent → product
    (
        "fixation béton ancrage",  # intent → PCI anchor adhesive + SPIT concrete nails
        ["8001119", "1059891", "1059889", "7520342"],
        "article_id",
    ),
    (
        "colle PVC tuyau pression",  # use-case → PVC pressure pipe adhesive / collet PE
        ["1138198", "1138195", "29013600", "1001609", "1028940", "3814272", "3814275"],
        "article_id",
    ),
    # exact product name — must always rank top (fundamental precision test)
    (
        "Mélangeur de lavabo Procasa Uno 17 saillie 140 mm",
        ["7831344", "7020023"],
        "article_id",
    ),
    # copper tube spec — Cuprolife 22mm / Procasa cuivre / coupe-tube
    (
        "tube cuivre 22mm",
        ["3815722", "1032370", "3820466", "7514524", "7514526", "1148502", "1027673"],
        "article_id",
    ),
    # wood screws Torx drive
    ("vis à bois Torx", ["1061812", "1061811", "1061816"], "article_id"),
    # plaster finishing coat → Fixit Planofix / Lissage
    ("enduit plâtre lissage", ["01572926", "1000163", "1000429"], "article_id"),
    # floating floor adhesive → SikaBond AT-80N / PCI
    ("colle parquet flottant", ["27206535", "8119158", "27206545"], "article_id"),
    # PVC conduit/sleeve — IFIT tube + Geberit gaine
    ("gaine technique PVC", ["3814045", "3814046", "2038648"], "article_id"),
    # dual-flush WC carrier element → Geberit DUOFIX
    ("chasse eau WC double touche", ["9169052", "7995638", "9150037"], "article_id"),
    # ── intent / need-based queries — user describes problem, not product ────
    # "mon évier est bouché" → ventouse débouche-évier / déboucheur
    ("déboucher évier produit", ["3842303", "3842302", "1148674"], "article_id"),
    # "je dois poser du carrelage" → colle carrelage / mortier colle
    (
        "je dois poser du carrelage au sol",
        ["7938555", "7938559", "8179615", "7938558", "7803217"],
        "article_id",
    ),
    # "enduit lissage intérieur" → Fixit Planofix (high-tx product)
    ("enduit intérieur lissage mur", ["01572926", "25251209"], "article_id"),
    # "robinet thermostatique douche" → mélangeur thermostatique (VOLA, Procasa, QUADRIGA)
    (
        "robinet thermostatique douche",
        ["01529630", "7826474", "7826463", "7956825", "7794166", "7895919"],
        "article_id",
    ),
    # "raccord coudé 90°" → raccord coudé 90° (PE/Mapress/multicouche)
    (
        "raccord coudé 90 degrés sertir multicouche",
        [
            "1160435",
            "1160438",
            "8104494",
            "8104499",
            "8104490",
            "8104488",
            "8104495",
            "8104496",
            "1015341",
            "2038291",
            "1001930",
            "2038994",
            "2038923",
        ],
        "article_id",
    ),
    # "panneau OSB 18mm" → panneau construction OSB / fibre de bois
    (
        "panneau OSB construction 18mm",
        ["1003119", "9138030", "9138031", "9138349", "8990289", "9150109"],
        "article_id",
    ),
    # ── direct product queries — diverse categories FR ───────────────────────
    # tuyau PVC évacuation → Canplast PVC drain
    (
        "tuyau PVC évacuation DN100",
        ["1018218", "1018217", "1018219", "1001332"],
        "article_id",
    ),
    # mastic polyuréthane noir → Sikaflex / ProOne
    (
        "mastic polyuréthane noir",
        ["1138229", "8172006", "8172005", "8172013"],
        "article_id",
    ),
    # mortier colle carrelage → Sopro / MAPEI / Cermicol
    (
        "mortier colle flexible carrelage",
        ["01521502", "01521901", "8079486", "9164289"],
        "article_id",
    ),
    # clé à molette 300mm → wrench
    ("clé à molette 300mm", ["1057092", "3812443", "1147823"], "article_id"),
    # disque diamant béton → ProOne diamond disc
    ("disque diamant béton 230mm", ["8110230", "8110235", "8110240"], "article_id"),
    # ── typo FR ──────────────────────────────────────────────────────────────
    # "robinnet" (double n) → mélangeur/robinet lavabo
    (
        "robinnet lavabo chromé",
        ["8135393", "8999343", "7514512", "7831344", "5421927", "7831345"],
        "article_id",
    ),  # + Procasa faucets
    # "silikone" (German spelling) → ProOne Silicone
    ("silikone sanitaire blanc", ["8147885", "8147886", "8149032"], "article_id"),
    # ── accent-stripped queries — same product without French accents ────────
    # "etancheite liquide" (no accents) → étanchéité liquide Fermacell / Sika
    (
        "etancheite liquide",
        ["25252485", "25252480", "6144081", "7521004", "9183235", "3806390"],
        "article_id",
    ),
    # "beton pret a l emploi" (no accents) → ProOne béton
    ("beton pret a l emploi sac", ["4477141", "4457227", "8121487"], "article_id"),
    # "cle a molette" (no accent) → clé à molette (any size variant is valid)
    (
        "cle a molette",
        [
            "1145941",
            "1145943",
            "1145953",
            "1057092",
            "1145884",
            "1145882",
            "1145883",
            "7965109",
            "7965106",
            "7965107",
            "3812443",
        ],
        "article_id",
    ),
    # "melangeur lavabo" (no accent) → mélangeur lavabo (any brand is valid)
    (
        "melangeur lavabo",
        [
            "7541147",
            "7540998",
            "7541179",
            "7831344",
            "7020023",
            "7878258",
            "7878242",
            "7514512",
        ],
        "article_id",
    ),
    # "tuyau evacuation" (no accent) → tuyau d'évacuation
    ("tuyau evacuation", ["7500925", "7500924", "3813702"], "article_id"),
    # "vis a bois inox" (no accent) → vis à bois inox (any DIN/spec is valid)
    (
        "vis a bois inox",
        [
            "1005153",
            "1006218",
            "1092063",
            "1085147",
            "1085146",
            "1089050",
            "1089059",
            "1061812",
        ],
        "article_id",
    ),
    # "gouttiere zinc" (no accent) → gouttière zinc
    ("gouttiere zinc", ["1016360", "1017190", "1016361"], "article_id"),
    # "fenetre toit" (no accent) → fenêtre toit Velux (any window/accessory)
    (
        "fenetre toit velux",
        [
            "8102045",
            "9199613",
            "9199607",
            "9226133",
            "9226134",
            "8097315",
            "8098155",
            "8098194",
        ],
        "article_id",
    ),
]

ONETRADE_FR_BOOSTS: list[BOOST_CASE] = [
    # ProOne 016 (own=True, 5.6M) > ProOne 008 (own=True, 3.3M)
    ("beton pret", "4457227", "4477141", "article_id"),
    # Procasa robinet 1/2 joint (own=True, 2.1M) > robinet SILOR (own=False, 1.6M)
    # Own-brand 1.2× makes Procasa win despite similar raw sales
    ("robinet réglage Procasa", "01631322", "01629097", "article_id"),
    # ProOne béton 25kg sac (own=True, 5.6M) > Sakret/Holcim non-own (generic cement)
    ("béton prêt à l emploi sac 25 kg", "4457227", "25580418", "article_id"),
]


# ── supplier_catalogs_de ──────────────────────────────────────────────────────

CATALOG_DE_HITS: list[HIT_CASE] = [
    ("Rigips Megaclip Dämmungshalter Mégastil", ["1272085028854136823"], "id"),
    (
        "Bauder PIR Flachdach Hochleistungsdämmplatten",
        [
            "9006969403767851093",
            "-3126657321039083045",
            "-8126639905585233378",
            "-242571357555733534",
        ],
        "id",
    ),
    ("Protektor Blechschraube Flachkopf verzinkt TX30", ["-6924936125137738507"], "id"),
    # Q&A style: specific technical question matching catalog content
    (
        "Was ist die Wärmeleitfähigkeit λ von BauderPIR MAX Hochleistungsdämmplatten?",
        ["9006969403767851093"],
        "id",
    ),
    # ── intent / technical queries against catalogs ──────────────────────────
    # Protektor UA-Profil for drywall — catalog has detailed technical specs
    (
        "Protektor Deckenprofil CD 60-27 abgehängte Decke",
        ["4033114738368435775", "7117334967899713914", "-7795066138733011637"],
        "id",
    ),
    # Bossard DIN 933 hex bolt — price list lookup
    (
        "Bossard Sechskantschraube DIN 933 verzinkt",
        ["4927289442990916188", "-7639415399995315803", "-7219263247246561517"],
        "id",
    ),
    # Braas BMI bitumen roofing membrane — technical spec sheet
    (
        "Dichtungsbahn Bitumen Flachdach aufschweissbar",
        ["1333637394004169946", "5965416240421704974", "-4926685132173323949"],
        "id",
    ),
    # Protektor UA profile wall thickness — structural drywall
    (
        "Protektor UA Profil Wandstärke 2mm Trockenbau",
        ["1098969790193074220", "-3891619992652901074", "5580095178466637062"],
        "id",
    ),
]


# ── supplier_catalogs_fr ──────────────────────────────────────────────────────

CATALOG_FR_HITS: list[HIT_CASE] = [
    (
        "Velux store solaire fenêtre toit plat",
        [
            "532277671457561788",
            "4573780760365682635",
            "2843558547400454987",
            "1478676219375858394",
        ],
        "id",
    ),
    (
        "Thumag HighLine évacuation linéaire prix CHF",
        [
            "8349347093257653229",
            "-3068571755115887195",
            "-3648534474999751967",
            "2632219463731072571",
            "8019680900010419006",
        ],
        "id",
    ),
    (
        "Ampack sous-toiture lé soudable diffusion",
        ["-2213863312253065875", "-3096590377103008272"],
        "id",
    ),
    # Q&A style: Thumag installation question matching specific catalog page
    (
        "Comment installer le siphon ThumaFix light receveur de douche mesure hauteur?",
        ["5453684086568616604"],
        "id",
    ),
    (
        "Quels sont les avantages du produit Ampack Ampatop Seal GHS préfabriqué livraison?",
        ["-5607468432344351781"],
        "id",
    ),
    # ── intent / technical queries against FR catalogs ───────────────────────
    # Velux window dimensions + pricing — catalog lookup
    (
        "Velux fenêtre toit dimensions prix catalogue",
        [
            "-1981569073443083933",
            "-821883392767947215",
            "-5678433109388863526",
            "6700333040947569125",
        ],
        "id",
    ),
    # Ampack sous-toiture étanchéité — waterproofing membrane spec
    (
        "Ampack sous-toiture étanchéité membrane",
        ["5910542839630069239", "-6561556117643914405", "1369906332861968080"],
        "id",
    ),
    # Betontec béton préfabriqué — FR concrete prefab catalog (Betontec/Be-Fix/Helfer)
    (
        "béton préfabriqué éléments catalogue prix",
        [
            "4634137602988331476",
            "4419991165364173107",
            "-1355317074184631059",
            "4488931306594804244",
            "8265184955809184662",
            "6170516158287238171",
            "-3534877768081769651",
            "9108079773528609969",
        ],
        "id",
    ),
    # Braas BMI isolation thermique panneau — FR insulation catalog
    (
        "panneau isolation thermique toit plat Braas",
        ["-7895432836420075139", "6837148758624484814"],
        "id",
    ),
]


# ── customer ──────────────────────────────────────────────────────────────────

CUSTOMER_HITS: list[HIT_CASE] = [
    ("Bourqui Michel Agriculteur Mézières FR", ["820001141"], "id"),
    ("Holinger AG Ingenieurunternehmen Bern", ["416393", "543636", "543288"], "id"),
    ("Baumann Haustechnik Sanitär Fulenbach", ["00239225", "314476"], "id"),
    ("Götz Elektro Zürich AG", ["00209419"], "id"),
]


# ── rag_multilingual ──────────────────────────────────────────────────────────

MULTILINGUAL_HITS: list[HIT_CASE] = [
    (
        "Beton Herstellung Zement Rohstoffe",
        ["6e101e40ff6aa7e0acc20a36d5243031e53238ea"],
        "id",
    ),
    (
        "Architecture bâtiment construction France",
        ["dd463963f90d46c1685185c778f5de8d1c8a0ae2"],
        "id",
    ),
    (
        "Baugesuche Zürich Kanton Gemeinde",
        ["3d1f21d1ed9a41f5d1626a24f39d000e1de2f1d4"],
        "id",
    ),
]


# ── rag_benchmark (MTEB LegalQuAD — DE legal case retrieval) ─────────────────
# Hardcoded from mteb/LegalQuAD to avoid HuggingFace download on every run.
# corpus_id field holds the MTEB document ID inside rag_benchmark.

MTEB_LEGALQUAD_HITS: list[HIT_CASE] = [
    (
        "Wie wurde über die Revision im Urteil des Landesgerichts Berlin-Brandenburg entschieden?",
        ["4efLerNHu9"],
        "corpus_id",
    ),
    (
        "Welche Rechtsgrundlage legt den Anspruch auf Ersatz von erforderlichen Reparaturkosten fest?",
        ["pkObaWoukd"],
        "corpus_id",
    ),
    (
        "Auf Basis welcher Regelung im Sozialgerichtsgesetz (SGG) kann ein Gericht einstweiligen Rechtsschutz gewähren?",
        ["td26fEeVVh"],
        "corpus_id",
    ),
    ("Was ist der Zweck eines Vollstreckungsermessens?", ["7nvdE2ODH0"], "corpus_id"),
    (
        "Auf welchem Grundsatz beruht die Berufszulassung nach VwGO?",
        ["Xoblu17rNy"],
        "corpus_id",
    ),
    (
        "Muss der Beauftragte dem Auftraggeber erhaltene Gegenstände zur Ausführung des Auftrags herausgeben?",
        ["zgEz6cwB61"],
        "corpus_id",
    ),
    (
        "Auf welcher Rechtsgrundlage im SGB basieren die Grenzen für eine Mitwirkung?",
        ["B19sMLT6mn"],
        "corpus_id",
    ),
    (
        "Womit hat der Rechtsmittelführer die Klage erhoben?",
        ["ZESFqZ8pIx"],
        "corpus_id",
    ),
    (
        "Wie hoch ist der Anspruch auf Verzugszinsen nach dem BGB?",
        ["YxPY8EcFK1"],
        "corpus_id",
    ),
    (
        "Wann enthalten Hilfebedürftige krankheitsbedingten Ernährungsmehrbedarf?",
        ["2BGCSzOjD8"],
        "corpus_id",
    ),
    (
        "Wie lang ist die Frist für einen Leistungsberechtigten zur Suche einer anderen Unterkunft?",
        ["GCLgR0OVSn"],
        "corpus_id",
    ),
    (
        "Wer sieht keine Grundlage zur Abweichung des vorherigen Urteils?",
        ["WvTMVTucHY"],
        "corpus_id",
    ),
    (
        "Wie lautet die Definition und Rechtsgrundlage zur Einordnung eines Produktes als Arzneimittel?",
        ["JtVEFEtb6F"],
        "corpus_id",
    ),
    (
        "Wonach bemisst sich die Dauer einer vorübergehend ausgesetzten Abschiebung?",
        ["nabsPHGZpv"],
        "corpus_id",
    ),
    (
        "Welches Gericht hat über die Ablehnung eines Ablehnungsgesuchs zu entscheiden?",
        ["6kH0hbG6i1"],
        "corpus_id",
    ),
]


# ── FilterQuality tests ───────────────────────────────────────────────────────
# (query, filter_expr, index, check_field, check_fn, min_in_top5, label)
# HIT if ≥ min_in_top5 docs in the filtered result set satisfy check_fn(field_value).
# Tests that Meilisearch CONTAINS / equality / comparison filters work correctly
# AND that the results make business sense (right supplier, own-brand, sales threshold).

FILTER_QUALITY_CASES: list[FILTER_CASE] = [
    # ── own-brand filter ──────────────────────────────────────────────────────
    # Query: generic cement query + is_own_brand=true filter
    # All returned docs must have is_own_brand=True
    (
        "beton 25 kg",
        "is_own_brand = true",
        "onetrade_articles_de",
        "is_own_brand",
        lambda v: v is True,
        4,  # 4/5 must be own-brand
        "DE own-brand filter: beton",
    ),
    # FR own-brand + high-sales filter (sales_l12m is NOT filterable; use transactions_l12m)
    (
        "robinet réglage chromé",
        "is_own_brand = true",
        "onetrade_articles_fr",
        "is_own_brand",
        lambda v: v is True,
        4,
        "FR own-brand filter: robinet",
    ),
    # ── supplier CONTAINS filter ──────────────────────────────────────────────
    # All returned docs must be from Geberit supplier
    (
        "Spülkasten Montage",
        'supplier_name CONTAINS "Geberit"',
        "onetrade_articles_de",
        "supplier_name",
        lambda v: "Geberit" in str(v),
        4,
        "DE supplier CONTAINS: Geberit Spülkasten",
    ),
    # FR catalog: Velux supplier filter
    (
        "store fenêtre toit",
        'supplier_name CONTAINS "Velux"',
        "supplier_catalogs_fr",
        "supplier_name",
        lambda v: "Velux" in str(v),
        4,
        "FR catalog supplier CONTAINS: Velux",
    ),
    # DE catalog: Rigips supplier filter
    (
        "Dämmung Gipsplatte Montage",
        'supplier_name CONTAINS "Rigips"',
        "supplier_catalogs_de",
        "supplier_name",
        lambda v: "Rigips" in str(v),
        4,
        "DE catalog supplier CONTAINS: Rigips",
    ),
    # ── numeric threshold filter ──────────────────────────────────────────────
    # Only articles with high transaction volume (popular items)
    (
        "Sanitärartikel",
        "transactions_l12m > 5000",
        "onetrade_articles_de",
        "transactions_l12m",
        lambda v: isinstance(v, (int, float)) and v > 5000,
        4,
        "DE numeric filter: transactions_l12m > 5000",
    ),
    # ── combined filter ───────────────────────────────────────────────────────
    # own-brand AND high transactions: toughest combined constraint
    (
        "beton sac ProOne",
        "is_own_brand = true AND transactions_l12m > 100",
        "onetrade_articles_de",
        "is_own_brand",
        lambda v: v is True,
        3,  # 3/5 must pass (combined filter may reduce recall)
        "DE combined: own-brand AND transactions > 100",
    ),
    # customer: specific canton filter — min_n=1 since search pool may be small
    (
        "Bauunternehmen Handwerker",
        'canton = "BE"',
        "customer",
        "canton",
        lambda v: v == "BE",
        1,
        "Customer canton filter: BE",
    ),
]

# ── Agentic Filter Intent tests ──────────────────────────────────────────────
# (question, index, expected_field_or_none, expected_value_substring, label)
# Tests whether the AI correctly decides WHEN to filter and extracts the right field/value.
FILTER_INTENT_CASE = tuple[str, str, str | None, str, str]

FILTER_INTENT_CASES: list[FILTER_INTENT_CASE] = [
    # Should detect supplier filter
    (
        "Geberit Spülkasten aufputz",
        "onetrade_articles_de",
        "supplier_name",
        "Geberit",
        "DE detect supplier: Geberit",
    ),
    # Should detect own-brand filter
    (
        "ProOne Eigenmarke Beton",
        "onetrade_articles_de",
        "is_own_brand",
        "",
        "DE detect own-brand: ProOne",
    ),
    # Should NOT filter — broad query, no specific entity
    (
        "Beton mischen auf der Baustelle",
        "onetrade_articles_de",
        None,
        "",
        "DE no filter: broad intent query",
    ),
    # Should detect supplier filter FR — Sika is a real supplier
    (
        "colle Sika carrelage",
        "onetrade_articles_fr",
        "supplier_name",
        "Sika",
        "FR detect supplier: Sika",
    ),
    # Should NOT filter — generic product search
    (
        "vis à bois inox",
        "onetrade_articles_fr",
        None,
        "",
        "FR no filter: generic product",
    ),
    # Should detect canton filter on customer (ZH or Zürich both valid)
    (
        "Bauunternehmen Kanton Zürich",
        "customer",
        "canton",
        "",
        "Customer detect canton: Zürich",
    ),
    # Should detect supplier_name filter for Velux
    (
        "produits Velux pour fenêtre de toit",
        "supplier_catalogs_fr",
        "supplier_name",
        "Velux",
        "FR catalog detect supplier: Velux",
    ),
    # Should NOT filter — no entity named
    (
        "isolant thermique toit plat",
        "supplier_catalogs_fr",
        None,
        "",
        "FR catalog no filter: broad query",
    ),
]

# NOTE: A negative test for bieröffner (SK-BETONNAGEL should NOT appear) cannot be
# expressed as a filter-quality case because group_name/product_group fields are not
# filterable attributes in Meilisearch. Cohere reranking already handles this — the
# SK-BETONNAGEL items do not appear in the RAG top-5 results.


# ── Benchmark helpers ─────────────────────────────────────────────────────────


async def _aretrieved_ids(rag: AgenticRAG, query: str, id_field: str) -> list[str]:
    _, docs = await rag._aretrieve_documents(query)
    return [str(d.metadata.get(id_field, "")) for d in docs]


async def _arun_hits(
    label: str,
    rag: AgenticRAG,
    cases: list[HIT_CASE],
    semaphore: asyncio.Semaphore,
) -> tuple[int, int]:
    """HitRate@5 — async parallel across cases. Returns (hits, total)."""
    hits = 0
    print(f"\n── {label} HitRate@5 ─────────────────────────────────────────────")

    async def _one(case: HIT_CASE) -> tuple[HIT_CASE, list[str]]:
        query, _, id_field = case
        async with semaphore:
            return case, await _aretrieved_ids(rag, query, id_field)

    results = await asyncio.gather(*[_one(c) for c in cases])
    for (query, expected_ids, _), retrieved in results:
        found = any(str(eid) in retrieved for eid in expected_ids)
        status = "HIT " if found else "MISS"
        short_q = (query[:50] + "…") if len(query) > 50 else query
        print(f"  {status} | {short_q!r:53s} → top ids: {retrieved[:5]}")
        if found:
            matched = [e for e in expected_ids if str(e) in retrieved]
            print(f"         matched: {matched}")
        hits += found

    return hits, len(cases)


async def _arun_boosts(
    label: str,
    rag: AgenticRAG,
    cases: list[BOOST_CASE],
    semaphore: asyncio.Semaphore,
) -> tuple[int, int]:
    """BoostScore@5 — high-sales/own-brand should outrank lower-signal. Returns (hits, total)."""
    hits = 0
    print(f"\n── {label} BoostScore@5 ──────────────────────────────────────────")

    async def _one(case: BOOST_CASE) -> tuple[BOOST_CASE, list[str]]:
        query, _, _, id_field = case
        async with semaphore:
            return case, await _aretrieved_ids(rag, query, id_field)

    results = await asyncio.gather(*[_one(c) for c in cases])
    for (query, high_id, low_id, _), retrieved in results:
        top5 = retrieved[:5]
        hi_rank = top5.index(high_id) + 1 if high_id in top5 else 99
        lo_rank = top5.index(low_id) + 1 if low_id in top5 else 99
        ok = hi_rank < lo_rank and hi_rank <= 5
        status = "HIT " if ok else "MISS"
        print(
            f"  {status} | {query!r:30s} → {high_id}@{hi_rank} vs {low_id}@{lo_rank}  top5={top5}"
        )
        hits += ok

    return hits, len(cases)


async def _arun_filter_intent(
    rags: dict[str, AgenticRAG],
    cases: list[FILTER_INTENT_CASE],
    semaphore: asyncio.Semaphore,
) -> tuple[int, int]:
    """FilterIntent — test AI's ability to decide WHEN to filter and extract field/value."""
    hits = 0
    print("\n── FilterIntent (Agentic) ────────────────────────────────────────")

    async def _one(case: FILTER_INTENT_CASE) -> tuple[FILTER_INTENT_CASE, Any]:
        question, index, _, _, _ = case
        rag = rags[index]
        async with semaphore:
            try:
                intent = await rag._adetect_filter_intent(question)
                return case, intent
            except Exception as e:
                return case, e

    results = await asyncio.gather(*[_one(c) for c in cases])
    for (question, _, expected_field, expected_value, label), intent in results:
        if isinstance(intent, Exception):
            print(f"  MISS | {label:45s} → error: {intent}")
            continue

        if expected_field is None:
            # Should NOT filter
            ok = intent.field is None or not intent.field
            status = "HIT " if ok else "MISS"
            print(f"  {status} | {label:45s} → field={intent.field} (expected None)")
        else:
            # Should filter with correct field and value substring
            field_ok = intent.field == expected_field
            value_ok = (
                not expected_value
                or expected_value.lower() in (intent.value or "").lower()
            )
            ok = field_ok and value_ok
            status = "HIT " if ok else "MISS"
            print(
                f"  {status} | {label:45s} → field={intent.field} value={intent.value!r} op={intent.operator}"
            )
        hits += ok

    return hits, len(cases)


async def _arun_filter_quality(
    cases: list[FILTER_CASE],
) -> tuple[int, int]:
    """FilterQuality — directly apply filter_expr, check property distribution.

    Uses raw Meilisearch BM25 (no LLM, fast). Each case verifies that the filter
    mechanism works correctly and returns semantically appropriate results.
    Returns (hits, total).
    """
    ms_url = os.getenv("MEILI_URL", "http://localhost:7700")
    ms_key = os.getenv("MEILI_KEY", "masterKey")
    ms = meilisearch.Client(ms_url, ms_key)
    hits = 0
    print("\n── FilterQuality ─────────────────────────────────────────────────")
    loop = asyncio.get_running_loop()

    async def _one(case: FILTER_CASE) -> tuple[FILTER_CASE, list[dict]]:
        query, filter_expr, index, *_ = case
        try:
            docs = await loop.run_in_executor(
                None,
                lambda: ms.index(index).search(
                    query, {"limit": 5, "filter": filter_expr}
                )["hits"],
            )
        except Exception as e:
            print(f"    filter error: {e}")
            docs = []
        return case, docs

    results = await asyncio.gather(*[_one(c) for c in cases])
    for (_, _, _, check_field, check_fn, min_n, label), docs in results:
        satisfied = sum(1 for d in docs[:5] if check_fn(d.get(check_field)))
        ok = satisfied >= min_n
        status = "HIT " if ok else "MISS"
        sample_vals = [d.get(check_field) for d in docs[:3]]
        print(
            f"  {status} | {label:45s} → {satisfied}/{min(5, len(docs))} satisfy  sample={sample_vals}"
        )
        hits += ok

    return hits, len(cases)


# ── Main benchmark ────────────────────────────────────────────────────────────


async def run_benchmark() -> None:
    embed_fn = _make_azure_embed_fn()
    sem = asyncio.Semaphore(20)

    rags: dict[str, AgenticRAG] = {
        "onetrade_articles_de": AgenticRAG(
            "onetrade_articles_de", embed_fn=embed_fn, embedder_name="azure_openai"
        ),
        "onetrade_articles_fr": AgenticRAG(
            "onetrade_articles_fr", embed_fn=embed_fn, embedder_name="azure_openai"
        ),
        "supplier_catalogs_de": AgenticRAG(
            "supplier_catalogs_de", embed_fn=embed_fn, embedder_name="azure_openai"
        ),
        "supplier_catalogs_fr": AgenticRAG(
            "supplier_catalogs_fr", embed_fn=embed_fn, embedder_name="azure_openai"
        ),
        "customer": AgenticRAG(
            "customer", embed_fn=embed_fn, embedder_name="azure_openai"
        ),
        "rag_multilingual": AgenticRAG(
            "rag_multilingual", embed_fn=embed_fn, embedder_name="azure_openai"
        ),
        "rag_benchmark": AgenticRAG(
            "rag_benchmark",
            embed_fn=embed_fn,
            embedder_name="azure_openai",
            base_filter='source = "rteb/mteb/LegalQuAD"',
            retrieval_factor=8,
        ),
    }

    hit_collections: list[tuple[str, str, list[HIT_CASE]]] = [
        ("onetrade_articles_de", "DE Articles", ONETRADE_DE_HITS),
        ("onetrade_articles_fr", "FR Articles", ONETRADE_FR_HITS),
        ("supplier_catalogs_de", "Catalog DE", CATALOG_DE_HITS),
        ("supplier_catalogs_fr", "Catalog FR", CATALOG_FR_HITS),
        ("customer", "Customer", CUSTOMER_HITS),
        ("rag_multilingual", "Multilingual", MULTILINGUAL_HITS),
        ("rag_benchmark", "MTEB LegalQuAD (DE)", MTEB_LEGALQUAD_HITS),
    ]
    boost_collections: list[tuple[str, str, list[BOOST_CASE]]] = [
        ("onetrade_articles_de", "DE Boost", ONETRADE_DE_BOOSTS),
        ("onetrade_articles_fr", "FR Boost", ONETRADE_FR_BOOSTS),
    ]

    all_tasks = [
        *[
            _arun_hits(label, rags[idx], cases, sem)
            for idx, label, cases in hit_collections
        ],
        *[
            _arun_boosts(label, rags[idx], cases, sem)
            for idx, label, cases in boost_collections
        ],
        _arun_filter_quality(FILTER_QUALITY_CASES),
        _arun_filter_intent(rags, FILTER_INTENT_CASES, sem),
    ]
    results: list[tuple[int, int]] = await asyncio.gather(*all_tasks)

    labels = (
        [label for _, label, _ in hit_collections]
        + [label for _, label, _ in boost_collections]
        + ["FilterQuality", "FilterIntent"]
    )
    for label, (h, n) in zip(labels, results):
        print(f"  → {label}: {h}/{n} = {h / n:.3f}")

    total_hits = sum(h for h, _ in results)
    total_n = sum(n for _, n in results)
    print(f"\nTotal={total_hits}/{total_n}={total_hits / total_n:.3f}")


if __name__ == "__main__":
    asyncio.run(run_benchmark())
