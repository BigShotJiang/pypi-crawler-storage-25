"""
RAG Benchmark – MTEB ground truth + LLM-as-judge evaluation
─────────────────────────────────────────────────────────────
Two evaluation modes:

  qrel    – NDCG@10 / MRR@10 / Recall@10 against MTEB ground truth
  llm     – GPT judges each answer 0-3 on relevance, faithfulness, completeness

Two retrievers:
  baseline  – Meilisearch BM25 only
  rerank    – Meilisearch BM25 + Cohere rerank + GPT generate (full pipeline)

Usage:
  python eval.py                           # qrel mode, both retrievers, all tasks
  python eval.py --mode llm --n 20         # LLM judge on 20 sampled queries
  python eval.py --tasks LegalQuAD         # single task
  python eval.py --retriever baseline      # skip reranking
"""

from __future__ import annotations

import argparse
import asyncio
import concurrent.futures
import json
import math
import os
import random
import socket
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, TypedDict

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

socket.setdefaulttimeout(30)  # caps all raw socket ops: Cohere, Meilisearch, Azure

import meilisearch
from dotenv import load_dotenv
from datasets import load_dataset  # type: ignore
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import BaseModel
from langchain_core.documents import Document
from rag007 import AgenticRAG, RAGState, _make_azure_embed_fn, _rrf_fuse

load_dotenv(".env")

# ── Config ────────────────────────────────────────────────────────────────────

MS_URL = os.getenv("MEILI_URL", "http://localhost:7700")
MS_KEY = os.getenv("MEILI_KEY", "masterKey")
INDEX = "rag_benchmark"
TOP_K = 25  # retrieve N, rerank down to RERANK_N
RERANK_N = 10


class _TaskConfigBase(TypedDict):
    hf_id: str
    corpus_config: str
    corpus_split: str
    queries_config: str
    queries_split: str
    qrels_split: str
    lang: str
    corpus_id_field: str


class TaskConfig(_TaskConfigBase, total=False):
    qrels_config: str  # optional; present only for tasks with a separate qrels config


# MTEB tasks with ground truth (qrels). corpus_id_field = Meilisearch field holding MTEB _id.
def _t(
    hf_id: str, lang: str, corpus_id_field: str = "corpus_id", qrels_split: str = "test"
) -> TaskConfig:
    return {
        "hf_id": hf_id,
        "corpus_config": "corpus",
        "corpus_split": "corpus",
        "queries_config": "queries",
        "queries_split": "queries",
        "qrels_split": qrels_split,
        "lang": lang,
        "corpus_id_field": corpus_id_field,
    }


TASKS: dict[str, TaskConfig] = {
    # German
    "LegalQuAD": _t("mteb/LegalQuAD", "de"),
    # English — legal
    "AILACasedocs": _t("mteb/AILA_casedocs", "en"),
    "AILAStatutes": _t("mteb/AILA_statutes", "en"),
    "LegalSummarization": _t("mteb/legal_summarization", "en"),
    # Science (BEIR SciFact)
    "SciFact": _t("mteb/scifact", "en"),
    # Finance (BEIR FiQA)
    "FiQA": _t("mteb/fiqa", "en"),
    # Medical (BEIR NFCorpus)
    "NFCorpus": _t("mteb/nfcorpus", "en"),
    # Wikipedia / General QA
    "NQ": _t("mteb/nq", "en"),
    # Multi-hop general knowledge
    "HotpotQA": _t("mteb/hotpotqa", "en"),
    # Diverse community questions
    "Quora": _t("mteb/quora", "en"),
    # French medical
    "CUREv1": {
        "hf_id": "clinia/CUREv1",
        "corpus_config": "corpus",
        "corpus_split": "dentistry_and_oral_health",
        "queries_config": "queries-fr",
        "queries_split": "dentistry_and_oral_health",
        "qrels_config": "qrels",
        "qrels_split": "dentistry_and_oral_health",
        "lang": "fr",
        "corpus_id_field": "corpus_id",
    },
}


# ── Clients ───────────────────────────────────────────────────────────────────


def make_clients() -> tuple[meilisearch.index.Index, AgenticRAG]:
    ms = meilisearch.Client(MS_URL, MS_KEY).index(INDEX)
    rag = AgenticRAG(
        index=INDEX,
        top_k=TOP_K,
        rerank_top_n=RERANK_N,
        retrieval_factor=1.5,  # retrieve TOP_K*1.5 → int(37) Cohere candidates
        embed_fn=_make_azure_embed_fn(),  # None → pure BM25
        embedder_name="azure_openai",
    )
    return ms, rag


def batch_embed_queries(
    embed_fn: Callable[[str], list[float]] | None,
    texts: list[str],
) -> dict[str, list[float]]:
    """Embed all texts in ONE Azure OpenAI API call (batched input).

    Azure embedding endpoint accepts up to 2048 inputs per request.
    Returns {text: vector} — falls back to {} (BM25 mode) on any error.
    """
    if not embed_fn or not texts:
        return {}
    endpoint = (os.getenv("AZURE_OPENAI_ENDPOINT") or "").rstrip("/")
    api_key = os.getenv("AZURE_OPENAI_API_KEY") or ""
    deploy = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small")
    api_ver = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")
    url = f"{endpoint}/openai/deployments/{deploy}/embeddings?api-version={api_ver}"

    import requests as _requests

    result: dict[str, list[float]] = {}
    batch_size = 256  # safe batch size
    for i in range(0, len(texts), batch_size):
        chunk = texts[i : i + batch_size]
        try:
            resp = _requests.post(
                url,
                headers={"api-key": api_key, "Content-Type": "application/json"},
                json={"input": chunk},
                timeout=30,
            )
            resp.raise_for_status()
            for item in resp.json()["data"]:
                result[chunk[item["index"]]] = item["embedding"]
        except Exception as e:
            print(f"  batch_embed warning: {e}")
    return result


async def batch_generate_hyde_async(
    rag: AgenticRAG,
    queries: list[str],
    concurrency: int = 16,
) -> dict[str, str]:
    """HyDE: async batch LLM calls; returns {query: hypothetical_doc_text}."""
    loop = asyncio.get_event_loop()
    sem = asyncio.Semaphore(concurrency)

    async def _one(q: str) -> tuple[str, str]:
        async with sem:
            try:
                return q, await asyncio.wait_for(
                    loop.run_in_executor(None, rag._hypothetical_doc, q), 15.0
                )
            except Exception:
                return q, q

    return dict(await asyncio.gather(*[_one(q) for q in queries]))


def search_hybrid_with_vector(
    rag: AgenticRAG,
    query: str,
    vector: list[float] | None,
    top_k: int,
    lang: str | None = None,
) -> list[dict]:
    """Dual-ratio multi-search (BM25 + HyDE semantic) → score-weighted RRF fusion."""
    limit = int(top_k * rag.retrieval_factor)
    queries = [
        {
            **rag._build_search_entry(query, None, limit, lang, index_uid=rag.index),
            "showRankingScore": True,
        },
        {
            **rag._build_search_entry(
                query, vector, limit, lang, index_uid=rag.index, semantic_ratio=0.9
            ),
            "showRankingScore": True,
        },
    ]
    results = rag._multi_search_with_retry(queries)
    if results:
        return _rrf_fuse([r["hits"] for r in results], ranking_score_weight=1.0)[:limit]
    # last-resort single BM25
    params: dict[str, Any] = {"limit": limit, "matchingStrategy": "frequency"}
    if lang:
        params["filter"] = f"language = {lang}"
    try:
        return rag._ms_client().index(rag.index).search(query, params)["hits"]
    except Exception:
        return []


# ── Retrieval ─────────────────────────────────────────────────────────────────


async def rerank_hits_async(
    rag: AgenticRAG,
    query: str,
    hits: list[dict],
) -> list[dict]:
    """Async rerank via AgenticRAG._rerank_async — asyncio.wait_for provides the timeout."""
    if not hits:
        return hits
    docs = [
        Document(page_content=h.get("content", h.get("title", "")), metadata=h)
        for h in hits
    ]
    state: RAGState = {
        "question": query,
        "query": query,
        "documents": docs,
        "answer": None,
        "iterations": 0,
    }
    result_state = await rag._rerank_async(state)  # timeout handled inside
    return [d.metadata for d in result_state["documents"]]


# ── Metrics ───────────────────────────────────────────────────────────────────


def _dcg(scores: list[float]) -> float:
    return sum(v / math.log2(i + 2) for i, v in enumerate(scores))


def ndcg_at_k(retrieved: list[str], relevant: dict[str, float], k: int) -> float:
    gains = [relevant.get(d, 0.0) for d in retrieved[:k]]
    idcg = _dcg(sorted(relevant.values(), reverse=True)[:k])
    return _dcg(gains) / idcg if idcg > 0 else 0.0


def mrr_at_k(retrieved: list[str], relevant: dict[str, float], k: int) -> float:
    for i, d in enumerate(retrieved[:k]):
        if relevant.get(d, 0.0) > 0:
            return 1.0 / (i + 1)
    return 0.0


def recall_at_k(retrieved: list[str], relevant: dict[str, float], k: int) -> float:
    n_rel = sum(1 for v in relevant.values() if v > 0)
    if n_rel == 0:
        return 0.0
    hits = sum(1 for d in retrieved[:k] if relevant.get(d, 0.0) > 0)
    return hits / n_rel


# ── Ground truth loader ───────────────────────────────────────────────────────


def load_ground_truth(
    task: TaskConfig,
) -> tuple[dict[str, str], dict[str, dict[str, float]]]:
    """Returns (queries {qid: text}, qrels {qid: {corpus_id: score}})."""
    hf_id = task["hf_id"]

    queries_ds = load_dataset(
        hf_id, task["queries_config"], split=task["queries_split"], streaming=False
    )
    queries = {row["_id"]: row["text"] for row in queries_ds}

    qrels_config = task.get("qrels_config")  # optional; None → default config
    qrels_ds = load_dataset(
        hf_id, qrels_config, split=task["qrels_split"], streaming=False
    )
    qrels: dict[str, dict[str, float]] = defaultdict(dict)
    for row in qrels_ds:
        qrels[row["query-id"]][row["corpus-id"]] = float(row["score"])

    return queries, dict(qrels)


# ── LLM judge ────────────────────────────────────────────────────────────────


class Judgment(BaseModel):
    relevance: int  # 0-3: how well retrieved docs address the question
    faithfulness: int  # 0-3: answer is grounded in retrieved docs (no hallucination)
    completeness: int  # 0-3: answer fully resolves the question
    reasoning: str


JUDGE_SYSTEM = """\
You are an expert evaluator for a Retrieval-Augmented Generation system.
Given a question, the retrieved context passages, and a generated answer, score:

  relevance    0-3  (0=docs unrelated, 3=docs directly answer the question)
  faithfulness 0-3  (0=answer contradicts/ignores docs, 3=answer fully grounded in docs)
  completeness 0-3  (0=answer missing key info, 3=answer fully resolves the question)

Return JSON only: {"relevance": <int>, "faithfulness": <int>, "completeness": <int>, "reasoning": "<one sentence>"}
"""


async def llm_judge_async(
    llm: AzureChatOpenAI, question: str, context_docs: list[str], answer: str
) -> Judgment:
    context = "\n\n---\n\n".join(context_docs[:5])
    prompt = f"Question: {question}\n\nContext:\n{context}\n\nAnswer: {answer}"
    try:
        raw = await llm.ainvoke([SystemMessage(JUDGE_SYSTEM), HumanMessage(prompt)])
        data = json.loads(raw.content)
        return Judgment(**data)
    except Exception:
        return Judgment(
            relevance=0, faithfulness=0, completeness=0, reasoning="parse error"
        )


def make_judge_llm() -> AzureChatOpenAI:
    return AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


# ── LLM-mode evaluation (full RAG pipeline) ───────────────────────────────────


async def evaluate_llm(
    task_name: str,
    task: TaskConfig,
    idx: meilisearch.index.Index,
    rag: AgenticRAG,
    llm: AzureChatOpenAI,
    n_samples: int,
    top_k: int,
    concurrency: int = 4,
) -> dict[str, float]:
    # idx and top_k are accepted for signature parity with evaluate_task; the full
    # rag.ainvoke() pipeline owns its own retrieval, so they are unused here.
    """Run full RAG pipeline concurrently and have the judge LLM score each result.

    Uses asyncio.gather with a semaphore to run up to `concurrency` queries in parallel.
    rag.invoke() runs in a thread pool (run_in_executor) since the graph nodes are sync;
    the judge LLM call uses ainvoke() for true async I/O.
    """
    print(f"  Loading queries for {task_name} …")
    queries_ds = load_dataset(
        task["hf_id"],
        task["queries_config"],
        split=task["queries_split"],
        streaming=False,
    )
    queries = [(row["_id"], row["text"]) for row in queries_ds]
    if len(queries) > n_samples:
        queries = random.sample(queries, n_samples)

    sem = asyncio.Semaphore(concurrency)
    total = len(queries)
    completed = 0

    async def _run_one(qtext: str) -> tuple[str, Judgment]:
        nonlocal completed
        async with sem:
            result = await rag.ainvoke(qtext)
            docs = result.get("documents", [])
            answer = result.get("answer", "") or "No answer."
            context_docs = [d.page_content for d in docs]
            j = await llm_judge_async(llm, qtext, context_docs, answer)
            completed += 1
            print(
                f"  [{completed}/{total}] rel={j.relevance} faith={j.faithfulness} "
                f"comp={j.completeness}  {qtext[:50]}…"
            )
            return qtext, j

    pairs = await asyncio.gather(*[_run_one(qtext) for _, qtext in queries])

    totals: dict[str, float] = defaultdict(float)
    for _, j in pairs:
        totals["relevance"] += j.relevance / 3
        totals["faithfulness"] += j.faithfulness / 3
        totals["completeness"] += j.completeness / 3

    n = len(pairs)
    return {k: v / n if n else 0.0 for k, v in totals.items()}


# ── Evaluate one task — all retrievers are LLM-free ──────────────────────────


async def evaluate_task(
    task_name: str,
    task: TaskConfig,
    idx: meilisearch.index.Index,
    rag: AgenticRAG,
    retriever: str,
    top_k: int,
    sample: int = 0,
) -> dict[str, float]:
    print(f"\n  Loading ground truth for {task_name} …")
    queries, qrels = load_ground_truth(task)
    corpus_id_field = task["corpus_id_field"]
    lang = task.get("lang")

    valid_qids = [qid for qid in queries if qrels.get(qid)]
    if sample and len(valid_qids) > sample:
        random.seed(42)
        valid_qids = random.sample(valid_qids, sample)
    print(f"  Evaluating {len(valid_qids)} queries with retriever='{retriever}'")

    # HyDE: batch-generate hypothetical answer docs, then batch-embed them for semantic arm
    vectors: dict[str, list[float]] = {}
    hyde_map: dict[str, str] = {}
    if retriever in ("hybrid", "hybrid_rerank") and rag.embed_fn:
        query_texts = [queries[qid] for qid in valid_qids]
        print(f"  Generating {len(query_texts)} HyDE docs …")
        hyde_map = await batch_generate_hyde_async(rag, query_texts)
        hyde_texts = [hyde_map[q] for q in query_texts]
        n_with_hyde = sum(1 for q in query_texts if hyde_map[q] != q)
        print(f"  HyDE: {n_with_hyde}/{len(query_texts)} queries got hypothetical docs")
        print(f"  Batch-embedding {len(hyde_texts)} HyDE docs …")
        # Map original query → HyDE vector so search_hybrid_with_vector can look up by qtext.
        hyde_vectors = batch_embed_queries(rag.embed_fn, hyde_texts)
        vectors = {
            q: hyde_vectors[hyde_map[q]]
            for q in query_texts
            if hyde_map[q] in hyde_vectors
        }
        print(f"  Embedded {len(vectors)}/{len(query_texts)} HyDE docs")

    # Retrieve hits for every query — parallelised with ThreadPoolExecutor so all
    # Meilisearch round-trips fire concurrently instead of serially.
    hits_per_qid: dict[str, list[dict]] = {}

    def _retrieve_one(qid: str) -> tuple[str, list[dict]]:
        qtext = queries[qid]
        if retriever in ("hybrid", "hybrid_rerank"):
            return qid, search_hybrid_with_vector(
                rag, qtext, vectors.get(qtext), top_k, lang
            )
        limit = int(top_k * rag.retrieval_factor)
        params: dict[str, Any] = {"limit": limit}
        if lang:
            params["filter"] = f"language = {lang}"
        return qid, idx.search(qtext, params)["hits"]

    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as ex:
        for qid, hits in ex.map(_retrieve_one, valid_qids):
            hits_per_qid[qid] = hits

    # Rerank concurrently with asyncio.gather (Cohere rate-limits; semaphore keeps it polite)
    if retriever in ("rerank", "hybrid_rerank"):
        sem = asyncio.Semaphore(8)  # max 8 concurrent Cohere calls

        async def _rerank_one(qid: str) -> tuple[str, list[dict]]:
            async with sem:
                qtext = queries[qid]
                hyde = hyde_map.get(qtext, "")
                # Augment with full HyDE text — with 1-sentence generation this is
                # already concise so the 150-char cap is no longer needed.
                cohere_q = f"{qtext}\n\n{hyde}" if hyde and hyde != qtext else qtext
                return qid, await rerank_hits_async(rag, cohere_q, hits_per_qid[qid])

        reranked_pairs = await asyncio.gather(*[_rerank_one(qid) for qid in valid_qids])
        for qid, ranked_hits in reranked_pairs:
            hits_per_qid[qid] = ranked_hits

    metrics: dict[str, list[float]] = defaultdict(list)
    for qid in valid_qids:
        rel = qrels.get(qid, {})
        hits = hits_per_qid[qid]
        retrieved_ids = [
            h.get(corpus_id_field, "") for h in hits[:top_k] if h.get(corpus_id_field)
        ]
        metrics["ndcg@10"].append(ndcg_at_k(retrieved_ids, rel, 10))
        metrics["mrr@10"].append(mrr_at_k(retrieved_ids, rel, 10))
        metrics["recall@10"].append(recall_at_k(retrieved_ids, rel, 10))

    return {k: sum(v) / len(v) if v else 0.0 for k, v in metrics.items()}


async def async_main() -> None:
    parser = argparse.ArgumentParser()
    _RETRIEVERS = ["baseline", "rerank", "hybrid", "hybrid_rerank"]
    parser.add_argument("--tasks", default=",".join(TASKS))
    parser.add_argument("--mode", default="qrel", choices=["qrel", "llm", "both"])
    parser.add_argument(
        "--retriever", default="baseline", choices=_RETRIEVERS + ["all"]
    )
    parser.add_argument("--top-k", type=int, default=TOP_K)
    parser.add_argument(
        "--timeout",
        type=int,
        default=180,
        help="Kill task eval after N seconds (default 180)",
    )
    parser.add_argument(
        "--sample",
        type=int,
        default=200,
        help="Max queries per task (0=all). Default 200 for speed.",
    )
    parser.add_argument(
        "--n", type=int, default=25, help="Queries to sample for LLM-judge mode"
    )
    args = parser.parse_args()

    idx, rag = make_clients()
    task_names = args.tasks.split(",")
    retrievers = _RETRIEVERS if args.retriever == "all" else [args.retriever]
    run_qrel = args.mode in ("qrel", "both")
    run_llm = args.mode in ("llm", "both")

    llm = make_judge_llm() if run_llm else None
    results: dict[str, dict[str, dict[str, float]]] = {}

    for task_name in task_names:
        task = TASKS.get(task_name)
        if task is None:
            print(f"Unknown task '{task_name}'. Available: {list(TASKS)}")
            continue

        print(f"\n{'─' * 60}")
        print(f"Task: {task_name}  ({task['lang'].upper()})")
        results[task_name] = {}

        if run_qrel:
            for ret in retrievers:
                effective_sample = (
                    min(args.sample, 50)
                    if ret in ("rerank", "hybrid_rerank")
                    else args.sample
                )
                try:
                    scores = await evaluate_task(
                        task_name,
                        task,
                        idx,
                        rag,
                        ret,
                        args.top_k,
                        effective_sample,
                    )
                except Exception as e:
                    print(f"  [qrel/{ret:8s}]  ERROR: {e}")
                    continue
                results[task_name][f"qrel/{ret}"] = scores
                print(
                    f"  [qrel/{ret:8s}]  NDCG@10={scores['ndcg@10']:.4f}  "
                    f"MRR@10={scores['mrr@10']:.4f}  "
                    f"Recall@10={scores['recall@10']:.4f}"
                )

        if run_llm and llm is not None:
            scores = await evaluate_llm(
                task_name, task, idx, rag, llm, args.n, args.top_k
            )
            results[task_name]["llm/rag"] = scores
            print(
                f"  [llm/rag  ]  relevance={scores['relevance']:.3f}  "
                f"faithfulness={scores['faithfulness']:.3f}  "
                f"completeness={scores['completeness']:.3f}"
            )

    # Summary table
    print(f"\n{'\u2550' * 60}")
    print("SUMMARY")
    header_metrics = (
        list(next(iter(next(iter(results.values())).values())).keys())
        if results
        else []
    )
    col_w = 10
    print(
        f"{'Task':<22} {'Mode':<16}", "  ".join(f"{m:>{col_w}}" for m in header_metrics)
    )
    print("─" * (22 + 16 + col_w * len(header_metrics) + 4))
    for task_name, modes in results.items():
        for mode, scores in modes.items():
            vals = "  ".join(f"{scores.get(m, 0):{col_w}.4f}" for m in header_metrics)
            print(f"{task_name:<22} {mode:<16} {vals}")


def main() -> None:
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
