from __future__ import annotations

import asyncio
import json
import math
import os
import warnings
from typing import Any, Callable, Literal, cast

import numpy as np
from langchain.agents import create_agent
from langchain.agents.middleware import (
    ModelRetryMiddleware,
    ToolCallLimitMiddleware,
    ToolRetryMiddleware,
)
from langchain_core.documents import Document
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from tenacity import retry, stop_after_attempt, wait_exponential

from .backend import InMemoryBackend, SearchBackend, SearchRequest
from .models import (
    ConversationTurn,
    FilterIntent,
    MultiQuery,
    QualityAssessment,
    RAGState,
    Reranker,
    SearchQuery,
)
from .rerankers import CohereReranker, LLMReranker
from .tools import RAGToolset
from .utils import (
    _SKIP_FIELDS,
    _dbsf_fuse,
    _doc_id,
    _embed_all_async,
    _rrf_fuse,
    _strip_stop_words,
)

warnings.filterwarnings(
    "ignore",
    message="Pydantic serializer warnings",
    category=UserWarning,
    module="pydantic",
)
warnings.filterwarnings(
    "ignore",
    message="Core Pydantic V1 functionality",
    category=UserWarning,
    module="langchain_core",
)

_ID_SUFFIXES = ("_id", "_code", "_key", "_num")

_llm_retry = retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    reraise=True,
)


def _detect_index_signals(
    backend: SearchBackend,
) -> tuple[list[str] | None, Callable[[dict], float] | None]:
    config = backend.get_index_config()
    sortable = config.sortable_attributes
    if not sortable:
        return None, None

    samples = backend.sample_documents(limit=20)
    if not samples:
        return None, None

    field_sample: dict[str, Any] = {}
    for doc in samples:
        for f in sortable:
            if f not in field_sample and doc.get(f) is not None:
                field_sample[f] = doc[f]
        if len(field_sample) == len(sortable):
            break

    bool_fields: list[str] = []
    num_fields: list[str] = []
    for f in sortable:
        value = field_sample.get(f)
        if isinstance(value, bool):
            bool_fields.append(f)
        elif (
            isinstance(value, (int, float))
            and value >= 0
            and not any(f.endswith(s) for s in _ID_SUFFIXES)
        ):
            num_fields.append(f)

    if not bool_fields and not num_fields:
        return None, None

    sort_fields = [f"{f}:desc" for f in bool_fields] + [f"{f}:desc" for f in num_fields]

    def boost_fn(meta: dict) -> float:
        binary_boost = 1.2 if any(meta.get(f) for f in bool_fields) else 1.0
        top_num = float(
            np.max([float(meta.get(f, 0) or 0) for f in num_fields])
            if num_fields
            else 0.0
        )
        top_num = top_num if top_num >= 150_000 else 0.0
        return binary_boost * (1.0 + math.log1p(top_num) / 50)

    return sort_fields, boost_fn


class AgenticRAG:
    """Autonomous retrieval-augmented generation agent built on LangGraph.

    rag007 is not a search pipeline — it is an agent. Given a question it
    thinks, searches, judges the results, rewrites the query if needed, and
    keeps going until it is confident enough to generate a grounded, cited
    answer. All of this happens autonomously, without any orchestration code
    on your side.

    Two operating modes
    -------------------
    **Graph mode** (``chat`` / ``invoke``)
        A LangGraph state machine runs the full pipeline:

        1. *Preprocess* — extract keywords, detect semantic/BM25 ratio, pick
           RRF or DBSF fusion strategy.
        2. *HyDE* — generate a hypothetical document to improve vector recall
           on vague queries (runs in parallel with preprocessing).
        3. *Hybrid search* — multi-query BM25 + vector search across N query
           variants, fused with Reciprocal Rank Fusion or Distribution-Based
           Score Fusion.
        4. *Rerank* — Cohere, HuggingFace cross-encoder, Jina, or any custom
           reranker surfaces the most relevant hits.
        5. *Quality gate* — an LLM judges whether the retrieved documents
           actually answer the question.
        6. *Generate or rewrite* — if quality is sufficient, generate a cited
           answer; otherwise rewrite the query and loop (up to ``max_iter``
           times). If all attempts fail, swarm retrieval fans out to parallel
           strategies before giving up.

    **Tool-calling agent mode** (``invoke_agent``)
        The LLM receives a toolset and reasons step-by-step, calling tools in
        whatever order makes sense. No fixed pipeline — the agent inspects the
        index schema, samples real field values, builds precise filter
        expressions on the fly, and decides whether to boost by business
        signals such as popularity or recency.

        Available tools: ``get_index_settings``, ``get_filter_values``,
        ``search_hybrid``, ``search_bm25``, ``rerank_results``.

    Parameters
    ----------
    index:
        Collection / index name in the backend.
    backend:
        A ``SearchBackend`` instance. Defaults to ``InMemoryBackend``
        (zero dependencies, useful for testing and quick prototyping).
    llm:
        Fast LLM used for query preprocessing, rewriting, and the quality
        gate. Defaults to Azure OpenAI if ``AZURE_OPENAI_ENDPOINT`` is set,
        otherwise OpenAI.
    gen_llm:
        Generation LLM used for the final answer. Defaults to ``llm`` with a
        longer timeout. Useful to separate a cheap routing model from a
        powerful generation model.
    reranker:
        Reranker instance. Defaults to ``CohereReranker`` if the ``cohere``
        package is installed, otherwise ``LLMReranker``.
    top_k:
        Number of documents returned after reranking. Default: 10
        (``RAG_TOP_K``).
    rerank_top_n:
        Number of candidates passed to the reranker. Default: 5
        (``RAG_RERANK_TOP_N``).
    retrieval_factor:
        Over-retrieval multiplier — ``top_k * retrieval_factor`` documents
        are fetched before reranking. Default: 4 (``RAG_RETRIEVAL_FACTOR``).
    max_iter:
        Maximum retrieve-rewrite cycles before giving up. Default: 20
        (``RAG_MAX_ITER``).
    semantic_ratio:
        Hybrid search semantic weight (0.0 = pure BM25, 1.0 = pure vector).
        Overridden per query by the preprocessor when ``auto_strategy=True``.
        Default: 0.5 (``RAG_SEMANTIC_RATIO``).
    fusion:
        Score fusion strategy: ``"rrf"`` (Reciprocal Rank Fusion, rank-based,
        stable) or ``"dbsf"`` (Distribution-Based Score Fusion,
        score-normalised). Default: ``"rrf"`` (``RAG_FUSION``).
    instructions:
        Extra text appended to the system prompt for answer generation.
        Use to inject domain-specific constraints or tone requirements.
    embed_fn:
        Callable ``(str) -> list[float]`` used to embed queries for vector
        search and HyDE. If ``None`` and the backend supports server-side
        vectorisation (e.g. Azure AI Search integrated vectorizer), no
        client-side embedding is performed.
    boost_fn:
        Callable ``(doc_dict) -> float`` applied after reranking to boost
        documents by business signals (e.g. in-stock flag, sales rank).
    base_filter:
        Filter expression applied to every search request — useful for
        tenant isolation or always-on category filters.
    hyde_min_words:
        Minimum query word count to trigger HyDE expansion. Default: 8
        (``RAG_HYDE_MIN_WORDS``).
    hyde_style_hint:
        Short phrase injected into the HyDE prompt to match the document
        style, e.g. ``"German product spec sheet"``.
    auto_strategy:
        If ``True``, sample documents at init time and let an LLM detect
        ``hyde_style_hint``, ``hyde_min_words``, and a ``domain_hint`` that
        guides query preprocessing — no hardcoded domain logic required.
    group_field:
        Metadata field used to detect query-group mismatches during
        boost-aware reranking.
    name_field:
        Metadata field used as the document name for token-overlap boosting.

    Examples
    --------
    Minimal — in-memory backend, default LLM from env vars:

    >>> from rag007 import Agent, InMemoryBackend
    >>> rag = Agent(index="docs", backend=InMemoryBackend(embed_fn=my_embed))
    >>> print(rag.query("What is hybrid search?"))

    Azure AI Search with native server-side vectorisation:

    >>> from rag007 import Agent, AzureAISearchBackend
    >>> rag = Agent(
    ...     index="my-index",
    ...     backend=AzureAISearchBackend(
    ...         "my-index",
    ...         endpoint="https://my-search.search.windows.net",
    ...         api_key="...",
    ...     ),
    ...     auto_strategy=True,
    ... )
    >>> state = rag.chat("Find the latest compliance report", history=[])

    Tool-calling agent mode for dynamic filtering:

    >>> result = rag.invoke_agent("Show me the top rated products from Bosch")
    """

    @staticmethod
    def _default_llm(
        *,
        timeout: int = 30,
    ) -> BaseChatModel:
        """Create default LLM from environment variables.

        Tries Azure OpenAI first (if AZURE_OPENAI_ENDPOINT set),
        falls back to OpenAI (if OPENAI_API_KEY set).
        """
        if os.getenv("AZURE_OPENAI_ENDPOINT"):
            from langchain_openai import AzureChatOpenAI

            deploy = os.getenv("AZURE_OPENAI_FAST_DEPLOYMENT") or os.getenv(
                "AZURE_OPENAI_DEPLOYMENT"
            )
            return AzureChatOpenAI(  # type: ignore[call-arg]
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                azure_deployment=deploy,
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                temperature=0,
                request_timeout=timeout,  # type: ignore[call-arg]
            )

        from langchain_openai import ChatOpenAI

        return ChatOpenAI(  # type: ignore[call-arg]
            model=os.getenv("OPENAI_MODEL", "gpt-4o"),
            api_key=os.getenv("OPENAI_API_KEY"),
            temperature=0,
            request_timeout=timeout,  # type: ignore[call-arg]
        )

    @staticmethod
    def _default_gen_llm() -> BaseChatModel:
        """Create default generation LLM (higher timeout)."""
        if os.getenv("AZURE_OPENAI_ENDPOINT"):
            from langchain_openai import AzureChatOpenAI

            deploy = os.getenv("AZURE_OPENAI_GENERATION_DEPLOYMENT") or os.getenv(
                "AZURE_OPENAI_DEPLOYMENT"
            )
            return AzureChatOpenAI(  # type: ignore[call-arg]
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                azure_deployment=deploy,
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                temperature=0,
                request_timeout=60,  # type: ignore[call-arg]
            )

        from langchain_openai import ChatOpenAI

        return ChatOpenAI(  # type: ignore[call-arg]
            model=os.getenv("OPENAI_MODEL", "gpt-4o"),
            api_key=os.getenv("OPENAI_API_KEY"),
            temperature=0,
            request_timeout=60,  # type: ignore[call-arg]
        )

    @staticmethod
    def _default_reranker() -> CohereReranker | LLMReranker:
        """Create default reranker: Cohere if available, else LLM-based."""
        try:
            return CohereReranker()
        except (ImportError, Exception):
            return LLMReranker()

    @classmethod
    def from_model(
        cls,
        model: str,
        index: str,
        *,
        gen_model: str | None = None,
        configurable_fields: str | list[str] | None = None,
        **kwargs: Any,
    ) -> "AgenticRAG":
        """Create an AgenticRAG from a provider-prefixed model string.

        Wraps LangChain's ``init_chat_model`` so you never have to import
        provider-specific classes.  Pass ``"provider:model-name"`` and the
        right LangChain package is selected automatically.

        Supported providers (same as ``init_chat_model``):
            openai, anthropic, azure_openai, google_vertexai, google_genai,
            bedrock, mistralai, groq, ollama, fireworks, together, …

        Parameters
        ----------
        model:
            Model string, either ``"provider:model-name"`` (e.g.
            ``"openai:gpt-5.4"``, ``"anthropic:claude-sonnet-4-6"``,
            ``"ollama:llama3"``) or a bare model name when the provider can
            be inferred from installed packages.
        index:
            Collection / index name in the backend.
        gen_model:
            Optional separate generation model string in the same format.
            Defaults to ``model``.
        configurable_fields:
            Passed through to ``init_chat_model`` for runtime configurability.
        **kwargs:
            All other ``AgenticRAG.__init__`` keyword arguments (``backend``,
            ``reranker``, ``top_k``, ``instructions``, ``embed_fn``, …).

        Examples
        --------
        >>> from rag007 import Agent
        >>> rag = Agent.from_model("openai:gpt-5.4", index="docs")
        >>> rag = Agent.from_model(
        ...     "anthropic:claude-sonnet-4-6",
        ...     index="docs",
        ...     gen_model="anthropic:claude-opus-4-6",
        ...     instructions="Answer only in English.",
        ... )
        >>> rag = Agent.from_model("ollama:llama3", index="docs")
        """
        from langchain.chat_models import init_chat_model  # type: ignore[import-untyped]

        init_kwargs: dict[str, Any] = {"temperature": 0}
        if configurable_fields is not None:
            init_kwargs["configurable_fields"] = configurable_fields

        llm = init_chat_model(model, **init_kwargs)
        gen_llm = init_chat_model(gen_model, **init_kwargs) if gen_model else llm
        return cls(index=index, llm=llm, gen_llm=gen_llm, **kwargs)

    def __init__(
        self,
        index: str,
        *,
        backend: SearchBackend | None = None,
        llm: BaseChatModel | None = None,
        gen_llm: BaseChatModel | None = None,
        reranker: Reranker | CohereReranker | LLMReranker | None = None,
        top_k: int | None = None,
        rerank_top_n: int | None = None,
        retrieval_factor: int | None = None,
        max_iter: int | None = None,
        instructions: str = "",
        n_swarm_queries: int | None = None,
        embed_fn: Callable[[str], list[float]] | None = None,
        embedder_name: str | None = None,
        semantic_ratio: float | None = None,
        boost_fn: Callable[[dict], float] | None = None,
        sort_fields: list[str] | None = None,
        base_filter: str | None = None,
        rerank_chars: int | None = None,
        hyde_min_words: int | None = None,
        hyde_style_hint: str = "",
        auto_strategy: bool = False,
        group_field: str = "",
        name_field: str = "",
        fusion: Literal["rrf", "dbsf"] | None = None,
    ):
        self.index = index
        self.backend = backend or InMemoryBackend()
        self.top_k = top_k or int(os.getenv("RAG_TOP_K", "10"))
        self.rerank_top_n = rerank_top_n or int(os.getenv("RAG_RERANK_TOP_N", "5"))
        self.retrieval_factor = retrieval_factor or int(
            os.getenv("RAG_RETRIEVAL_FACTOR", "4")
        )
        self.max_iter = max_iter or int(os.getenv("RAG_MAX_ITER", "20"))
        self.n_swarm_queries = n_swarm_queries or int(
            os.getenv("RAG_N_SWARM_QUERIES", "4")
        )
        self.embedder_name = embedder_name or os.getenv(
            "RAG_EMBEDDER_NAME", "azure_openai"
        )
        self.semantic_ratio = (
            semantic_ratio
            if semantic_ratio is not None
            else float(os.getenv("RAG_SEMANTIC_RATIO", "0.5"))
        )
        self.rerank_chars = (
            rerank_chars
            if rerank_chars is not None
            else int(os.getenv("RAG_RERANK_CHARS", "2048"))
        )
        self.hyde_min_words = (
            hyde_min_words
            if hyde_min_words is not None
            else int(os.getenv("RAG_HYDE_MIN_WORDS", "8"))
        )
        self.fusion: Literal["rrf", "dbsf"] = fusion or os.getenv("RAG_FUSION", "rrf")  # type: ignore[assignment]
        self.instructions = instructions
        self.embed_fn = embed_fn
        self.hyde_style_hint = hyde_style_hint
        self.group_field = group_field
        self.name_field = name_field

        if sort_fields is None and boost_fn is None:
            sort_fields, boost_fn = _detect_index_signals(self.backend)
        self.boost_fn = boost_fn
        self.sort_fields = sort_fields
        self.base_filter = base_filter

        self._llm = llm or self._default_llm()
        self._gen_llm = gen_llm or self._default_gen_llm()
        self._reranker = reranker or self._default_reranker()

        self._domain_hint: str = ""

        if auto_strategy:
            self._auto_configure(override_hyde_min_words=hyde_min_words is None)

        self._search_query_chain = self._llm.with_structured_output(
            SearchQuery, method="json_schema"
        )
        self._quality_chain = self._llm.with_structured_output(
            QualityAssessment, method="json_schema"
        )
        self._multi_query_chain = self._llm.with_structured_output(
            MultiQuery, method="json_schema"
        )
        self._filter_intent_chain = self._llm.with_structured_output(
            FilterIntent, method="json_schema"
        )

        self._toolset = RAGToolset(self)
        self._tools = self._toolset.as_tools()
        self._graph = self._build_graph()
        self._agent = self._build_agent()

    def _auto_configure(self, override_hyde_min_words: bool = True) -> None:
        try:
            sample = self.backend.sample_documents(
                limit=5,
                filter_expr=self.base_filter,
            )
            if not sample:
                return
            previews = [
                str(
                    {
                        k: str(v)[:120]
                        for k, v in h.items()
                        if k not in _SKIP_FIELDS
                        and v
                        and isinstance(v, (str, int, float))
                    }
                )
                for h in sample[:5]
            ]
            result = self._llm.invoke(
                [
                    SystemMessage(
                        "Analyze these sample documents and return ONLY a JSON object (no markdown) with:\n"
                        "- hyde_style_hint: str — one short phrase for HyDE prompt, e.g. "
                        "'German legal ruling', 'product spec sheet', 'customer address record', "
                        "'Wikipedia article', 'medical Q&A'\n"
                        "- hyde_min_words: int 3–12 — min query words to trigger HyDE expansion. "
                        "Lower (3–5) for factual Q&A / legal where even short questions need expansion. "
                        "Higher (8–12) for keyword search / products where short queries are already precise.\n"
                        "- domain_hint: str — 1-2 sentences describing what kind of content is stored, "
                        "what identifiers or codes exist (e.g. article numbers, case IDs), what language "
                        "the content is in, and any query preprocessing tips specific to this domain "
                        "(e.g. verb-to-noun normalisation for German product queries, case number format, "
                        "medical abbreviations). Leave empty string if no domain-specific tips apply."
                    ),
                    HumanMessage("Sample documents:\n" + "\n---\n".join(previews)),
                ]
            )
            config = json.loads(str(result.content).strip())
            if "hyde_style_hint" in config:
                self.hyde_style_hint = str(config["hyde_style_hint"])
            if "hyde_min_words" in config and override_hyde_min_words:
                self.hyde_min_words = int(config["hyde_min_words"])
            if "domain_hint" in config:
                self._domain_hint = str(config["domain_hint"])
            print(f"  [{self.index}] strategy: {config}")
        except Exception as e:
            print(f"  [{self.index}] auto-strategy failed ({e}), using defaults")

    def _sys(self, prompt: str) -> SystemMessage:
        if self.instructions:
            return SystemMessage(f"{self.instructions}\n\n{prompt}")
        return SystemMessage(prompt)

    def _hit_to_text(self, h: dict) -> str:
        if "content" in h:
            return h["content"]
        return "\n".join(
            f"{k}: {v.strip() if isinstance(v, str) else v}"
            for k, v in h.items()
            if k not in _SKIP_FIELDS
            and (isinstance(v, str) and v.strip() or isinstance(v, (int, float)) and v)
        )

    def _make_search_request(
        self,
        query: str,
        limit: int,
        *,
        vector: list[float] | None = None,
        semantic_ratio: float | None = None,
        filter_expr: str | None = None,
        sort_fields: list[str] | None = None,
        show_ranking_score: bool = False,
    ) -> SearchRequest:
        filters = [f for f in [self.base_filter, filter_expr] if f]
        return SearchRequest(
            query=query,
            limit=limit,
            vector=vector,
            semantic_ratio=semantic_ratio
            if semantic_ratio is not None
            else self.semantic_ratio,
            filter_expr=" AND ".join(filters) if filters else None,
            sort_fields=sort_fields,
            show_ranking_score=show_ranking_score,
            embedder_name=self.embedder_name,
            index_uid=self.index,
        )

    @_llm_retry
    async def _ahypothetical_doc(self, query: str) -> str:
        style = f" ({self.hyde_style_hint})" if self.hyde_style_hint else ""
        result = await self._llm.ainvoke(
            [
                self._sys(
                    f"Write 1-2 sentences from a relevant document{style}. "
                    "Use domain terminology. No questions — write as extracted text."
                ),
                HumanMessage(query),
            ]
        )
        return str(result.content).strip() or query

    def _multi_search(
        self,
        queries: list[str],
        lang: str | None = None,
        vectors: list[list[float] | None] | None = None,
        filter_expr: str | None = None,
    ) -> list[Document]:
        limit = int(self.top_k * self.retrieval_factor)
        vecs: list[list[float] | None] = vectors if vectors else [None] * len(queries)
        # lang filter and explicit filter_expr can be combined
        parts = [p for p in [f"language = {lang}" if lang else None, filter_expr] if p]
        combined_filter = " AND ".join(f"({p})" for p in parts) if parts else None

        requests = [
            self._make_search_request(q, limit, vector=v, filter_expr=combined_filter)
            for q, v in zip(queries, vecs)
        ]
        results = self.backend.batch_search(requests)
        fused = _rrf_fuse(results)
        return [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in fused[:limit]
        ]

    async def _apreprocess(self, state: RAGState) -> RAGState:
        try:
            result = cast(
                SearchQuery,
                await self._search_query_chain.ainvoke(
                    [
                        self._sys(
                            "Extract 2-5 concise search keywords from the user's question. "
                            "Return ONLY essential nouns, entities, and technical terms. "
                            "Omit question words, common verbs, and stop words (e.g. find, search, what, how, give me). "
                            "Preserve identifiers, codes, and specialized terms exactly. "
                            + (
                                f"Domain context: {self._domain_hint} "
                                if self._domain_hint
                                else ""
                            )
                            + "Also set 'variants': 2-3 more specific alternative keyword phrasings — "
                            "use technical names, codes, or narrower terminology for the same concept. "
                            "Avoid broader synonyms. Keep keywords in the same language as the query. "
                            "Also set 'semantic_ratio' (0.0-1.0): how much to weight semantic/vector "
                            "search vs keyword/BM25. "
                            "- Exact identifiers, codes, names → 0.1-0.2 (BM25 excels) "
                            "- Specific nouns, mixed queries → 0.3-0.5 (balanced) "
                            "- Intent/need-based queries → 0.6-0.8 (semantic helps) "
                            "- Abstract/conceptual questions → 0.7-0.9 (semantic dominant) "
                            "Also set 'fusion' ('rrf' or 'dbsf'): how to fuse multi-arm search results. "
                            "- 'rrf': Reciprocal Rank Fusion — rank-based, best for keyword-heavy queries. "
                            "- 'dbsf': Distribution-Based Score Fusion — score-normalised, best for semantic queries."
                        ),
                        HumanMessage(state.question),
                    ]
                ),
            )
            raw = _strip_stop_words(state.question)
            variants = result.variants[:3]
            if raw and raw.lower() != result.query.lower():
                variants = [raw] + variants
            return state.model_copy(
                update={
                    "query": result.query,
                    "query_variants": variants[:4],
                    "adaptive_semantic_ratio": result.semantic_ratio,
                    "adaptive_fusion": result.fusion,
                }
            )
        except Exception:
            return state.model_copy(update={"query": state.question})

    async def _asearch(
        self,
        query: str,
        question: str | None = None,
        lang: str | None = None,
        extra_bm25: list[str] | None = None,
        factor: int | None = None,
        adaptive_semantic_ratio: float | None = None,
        adaptive_fusion: str | None = None,
        hyde_text: str | None = None,
    ) -> list[Document]:
        limit = int(self.top_k * (factor or self.retrieval_factor))
        hyde_source = question or query

        if hyde_text is None:
            if self.embed_fn and len(hyde_source.split()) >= self.hyde_min_words:
                try:
                    hyde_text = await self._ahypothetical_doc(hyde_source)
                except Exception:
                    hyde_text = hyde_source
            else:
                hyde_text = hyde_source
        loop = asyncio.get_running_loop()
        vector: list[float] | None = None
        if self.embed_fn:
            try:
                vector = await loop.run_in_executor(None, self.embed_fn, hyde_text)
            except Exception:
                vector = None

        lang_filter = f"language = {lang}" if lang else None
        hyde_bm25 = hyde_text if hyde_text != hyde_source else query
        hybrid_ratio = (
            adaptive_semantic_ratio
            if adaptive_semantic_ratio is not None
            else self.semantic_ratio
        )

        requests = [
            self._make_search_request(
                query,
                limit,
                sort_fields=self.sort_fields,
                show_ranking_score=True,
                filter_expr=lang_filter,
            ),
            self._make_search_request(
                hyde_bm25,
                limit,
                sort_fields=self.sort_fields,
                show_ranking_score=True,
                filter_expr=lang_filter,
            ),
            self._make_search_request(
                query,
                limit,
                vector=vector,
                semantic_ratio=hybrid_ratio,
                sort_fields=self.sort_fields,
                show_ranking_score=True,
                filter_expr=lang_filter,
            ),
        ]
        seen = {query, hyde_bm25}
        for v in extra_bm25 or []:
            if v and v not in seen:
                requests.append(
                    self._make_search_request(
                        v,
                        limit,
                        sort_fields=self.sort_fields,
                        show_ranking_score=True,
                        filter_expr=lang_filter,
                    )
                )
                seen.add(v)

        results = await loop.run_in_executor(None, self.backend.batch_search, requests)
        fuse_method = adaptive_fusion or self.fusion
        if results:
            if fuse_method == "dbsf":
                fused = _dbsf_fuse(results)
            else:
                fused = _rrf_fuse(results, ranking_score_weight=1.0)
        else:
            fused = await loop.run_in_executor(
                None,
                self.backend.search,
                self._make_search_request(query, limit, filter_expr=lang_filter),
            )

        return [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in fused[:limit]
        ]

    async def _aparallel_start(self, state: RAGState) -> RAGState:
        pre_state, ret_state = await asyncio.gather(
            self._apreprocess(state),
            self._aretrieve_node(state),
        )
        return ret_state.model_copy(
            update={
                "query": pre_state.query or state.question,
                "query_variants": pre_state.query_variants,
                "adaptive_semantic_ratio": pre_state.adaptive_semantic_ratio,
                "adaptive_fusion": pre_state.adaptive_fusion,
            }
        )

    async def _aswarm_retrieve(self, state: RAGState) -> RAGState:
        # Generate query variants AND detect filter intent in parallel
        async def _gen_variants() -> list[str]:
            try:
                result = cast(
                    MultiQuery,
                    await self._multi_query_chain.ainvoke(
                        [
                            self._sys(
                                f"Generate {self.n_swarm_queries} distinct search query variants for the question. "
                                "Each should use different keywords, synonyms, or angles to maximise recall. "
                                f"Return JSON with a 'queries' list of {self.n_swarm_queries} strings."
                            ),
                            HumanMessage(state.question),
                        ]
                    ),
                )
                return result.queries[: self.n_swarm_queries] or [state.query]
            except Exception:
                return [state.query]

        queries, filter_intent = await asyncio.gather(
            _gen_variants(),
            self._adetect_filter_intent(state.question),
        )

        vectors: list[list[float] | None] | None = None
        if self.embed_fn:
            try:
                vectors = await _embed_all_async(self.embed_fn, queries)
            except Exception:
                vectors = None

        loop = asyncio.get_running_loop()

        has_filter = (
            filter_intent.field and filter_intent.value and filter_intent.operator
        )
        if has_filter:
            f_expr = f'{filter_intent.field} {filter_intent.operator} "{filter_intent.value}"'

            def _filtered_search() -> list[Document]:
                return self._multi_search(queries, vectors=vectors, filter_expr=f_expr)

            def _broad_search() -> list[Document]:
                return self._multi_search(queries, vectors=vectors)

            # Run filtered + unfiltered swarm in parallel, merge via RRF
            broad_docs, filtered_docs = await asyncio.gather(
                loop.run_in_executor(None, _broad_search),
                loop.run_in_executor(None, _filtered_search),
            )
            docs = (
                self._merge_doc_lists(filtered_docs, broad_docs)
                if filtered_docs
                else broad_docs
            )
        else:
            docs = await loop.run_in_executor(
                None, self._multi_search, queries, None, vectors
            )

        return state.model_copy(
            update={"documents": docs, "iterations": state.iterations + 1}
        )

    async def _aretrieve_node(self, state: RAGState) -> RAGState:
        factor = (
            self.retrieval_factor * 2
            if state.iterations >= 1
            else self.retrieval_factor
        )
        if state.iterations == 0:
            # First attempt: run broad search + filter-intent search in parallel
            broad_docs, filter_docs = await asyncio.gather(
                self._asearch(
                    state.query,
                    question=state.question,
                    extra_bm25=state.query_variants,
                    factor=factor,
                    adaptive_semantic_ratio=state.adaptive_semantic_ratio,
                    adaptive_fusion=state.adaptive_fusion,
                ),
                self._afilter_search(state.question, state.query),
            )
            docs = (
                self._merge_doc_lists(filter_docs, broad_docs)
                if filter_docs
                else broad_docs
            )
        else:
            # Rewrite iteration — query changed, skip filter re-detection
            docs = await self._asearch(
                state.query,
                question=state.question,
                extra_bm25=state.query_variants,
                factor=factor,
                adaptive_semantic_ratio=state.adaptive_semantic_ratio,
                adaptive_fusion=state.adaptive_fusion,
            )
        return state.model_copy(
            update={"documents": docs, "iterations": state.iterations + 1}
        )

    def _make_rerank_docs(self, docs: list[Document]) -> list[str]:
        return [
            " | ".join(
                f"{k}: {v}"
                for k, v in d.metadata.items()
                if isinstance(v, (str, int, float)) and v and k not in _SKIP_FIELDS
            )[: self.rerank_chars]
            for d in docs
        ]

    def _apply_boost(
        self,
        docs: list[Document],
        indexed: list[tuple[int, float]],
        query: str = "",
    ) -> list[Document]:
        if not self.boost_fn:
            return [docs[i] for i, _ in indexed]
        scored = sorted(
            [(docs[i], s * self.boost_fn(docs[i].metadata)) for i, s in indexed],
            key=lambda x: x[1],
            reverse=True,
        )
        if query and self.group_field and self.name_field and len(scored) >= 5:
            top_groups = {d.metadata.get(self.group_field, "") for d, _ in scored[:5]}
            if len(top_groups) == 1 and next(iter(top_groups)):
                tokens = {t for t in query.lower().split() if len(t) > 3}
                if tokens:
                    scored = sorted(
                        [
                            (
                                d,
                                s
                                * (
                                    1.5
                                    if all(
                                        t
                                        in (
                                            d.metadata.get(self.name_field, "") or ""
                                        ).lower()
                                        for t in tokens
                                    )
                                    else 1.0
                                ),
                            )
                            for d, s in scored
                        ],
                        key=lambda x: x[1],
                        reverse=True,
                    )
        return [d for d, _ in scored[: self.top_k]]

    async def _arerank(self, state: RAGState) -> RAGState:
        if not state.documents:
            return state
        rerank_docs = self._make_rerank_docs(state.documents)
        effective_top_n = len(rerank_docs) if self.boost_fn else self.rerank_top_n
        rerank_query = state.question or state.query

        try:
            loop = asyncio.get_running_loop()
            # Use async rerank if available (CohereReranker), else run sync in executor
            arerank_fn = getattr(self._reranker, "arerank", None)
            if arerank_fn is not None:
                results = await asyncio.wait_for(
                    arerank_fn(rerank_query, rerank_docs, effective_top_n),
                    timeout=30.0,
                )
            else:
                results = await asyncio.wait_for(
                    loop.run_in_executor(
                        None,
                        self._reranker.rerank,
                        rerank_query,
                        rerank_docs,
                        effective_top_n,
                    ),
                    timeout=30.0,
                )
            indexed = [(r.index, r.relevance_score) for r in results]
            return state.model_copy(
                update={
                    "documents": self._apply_boost(
                        state.documents, indexed, state.query
                    )
                }
            )
        except (asyncio.TimeoutError, Exception):
            return state

    async def _agenerate(self, state: RAGState) -> RAGState:
        numbered = "\n\n---\n\n".join(
            f"[{i + 1}] {d.page_content}" for i, d in enumerate(state.documents)
        )
        messages: list = [
            self._sys(
                "Answer using only the provided context. "
                "Cite sources inline using [n] numbers that match the context blocks. "
                "Say so if the context is insufficient."
            ),
        ]
        for turn in state.history:
            messages.append(HumanMessage(turn.question))
            messages.append(AIMessage(turn.answer))
        messages.append(
            HumanMessage(f"Context:\n{numbered}\n\nQuestion: {state.question}")
        )
        response = await self._gen_llm.ainvoke(messages)
        return state.model_copy(update={"answer": str(response.content)})

    async def _arewrite(self, state: RAGState) -> RAGState:
        if state.iterations >= 2 and not state.documents:
            return await self._aswarm_retrieve(state)

        prompt = (
            "The search returned documents but they are NOT relevant to the question. "
            "Rewrite the query using different keywords, synonyms, or a narrower angle. "
            "Return only 1-4 keywords — no filler words."
            if state.quality_ok is False
            else "The previous search returned NO results. Rewrite the query using different words, "
            "synonyms, or a broader term. Return only 1-3 short keywords — no filler."
        )

        try:
            result = cast(
                SearchQuery,
                await self._search_query_chain.ainvoke(
                    [
                        self._sys(prompt),
                        HumanMessage(state.question),
                    ]
                ),
            )
            return state.model_copy(update={"query": result.query, "quality_ok": None})
        except Exception:
            return state

    def _give_up(self, state: RAGState) -> RAGState:
        return state.model_copy(
            update={
                "answer": f"No relevant documents found after {state.iterations} attempts."
            }
        )

    async def _aquality_gate(self, state: RAGState) -> RAGState:
        if not state.documents or state.iterations >= self.max_iter:
            return state.model_copy(update={"quality_ok": bool(state.documents)})

        if state.iterations == 1 and len(state.documents) >= self.rerank_top_n:
            return state.model_copy(update={"quality_ok": True})

        snippets = "\n\n".join(
            f"[{i + 1}] {d.page_content[:300]}"
            for i, d in enumerate(state.documents[:5])
        )
        try:
            assessment = cast(
                QualityAssessment,
                await self._quality_chain.ainvoke(
                    [
                        self._sys(
                            "You are a retrieval quality judge. "
                            "Given a question and the top-5 retrieved document snippets, "
                            "decide if the documents are sufficient to answer the question. "
                            "Return sufficient=true only if at least one document directly addresses the question. "
                            "Return sufficient=false if the documents are off-topic, too vague, or clearly wrong."
                        ),
                        HumanMessage(
                            f"Question: {state.question}\n\nRetrieved snippets:\n{snippets}"
                        ),
                    ]
                ),
            )
            ok = assessment.sufficient
        except Exception:
            ok = True

        return state.model_copy(update={"quality_ok": ok})

    def _route(self, state: RAGState) -> Literal["generate", "rewrite", "give_up"]:
        if not state.documents:
            return "give_up" if state.iterations >= self.max_iter else "rewrite"
        return "generate"

    def _quality_route(
        self, state: RAGState
    ) -> Literal["generate", "rewrite", "give_up"]:
        if state.quality_ok is not False:
            return "generate"
        return "give_up" if state.iterations >= self.max_iter else "rewrite"

    def _build_graph(self) -> Any:
        g = StateGraph(RAGState)
        for name, fn in [
            ("smart_entry", lambda state: state),
            ("preprocess", self._apreprocess),
            ("retrieve", self._aretrieve_node),
            ("rerank", self._arerank),
            ("quality_gate", self._aquality_gate),
            ("generate", self._agenerate),
            ("rewrite", self._arewrite),
            ("give_up", self._give_up),
        ]:
            g.add_node(name, fn)

        g.add_edge(START, "smart_entry")
        g.add_conditional_edges(
            "smart_entry",
            lambda s: "rerank" if s.documents else "preprocess",
            {"rerank": "rerank", "preprocess": "preprocess"},
        )
        g.add_edge("preprocess", "retrieve")
        g.add_conditional_edges(
            "retrieve",
            self._route,
            {"generate": "rerank", "rewrite": "rewrite", "give_up": "give_up"},
        )
        g.add_edge("rerank", "quality_gate")
        g.add_conditional_edges(
            "quality_gate",
            self._quality_route,
            {"generate": "generate", "rewrite": "rewrite", "give_up": "give_up"},
        )
        g.add_edge("rewrite", "retrieve")
        g.add_edge("generate", END)
        g.add_edge("give_up", END)
        compiled = g.compile(checkpointer=None)
        compiled.step_timeout = 30.0
        return compiled

    def _build_agent(self) -> Any:
        system_prompt = (
            "You are a retrieval agent with intelligent filtering. For each user question:\n"
            "\n"
            "1. Call get_index_settings to discover filterable, sortable, and boost fields.\n"
            "   Use ONLY the field names returned — never invent field names.\n"
            "\n"
            "2. DECIDE whether to apply a filter (fast precision boost):\n"
            "   - If the user names a specific entity that maps to a filterable field,\n"
            "     call get_filter_values(field) to see real stored values.\n"
            "     Then build a filter expression using the closest matching value.\n"
            "   - Use CONTAINS for partial name matches.\n"
            "   - Use exact = for booleans, IDs, and known precise values.\n"
            "   - Combine with AND/OR when multiple constraints apply.\n"
            "   - SKIP the filter step for broad or ambiguous queries where no entity is named.\n"
            "\n"
            "3. Call search_hybrid with the query and any filter_expr you decided to apply.\n"
            "   If the question implies popularity/preference, also pass sort_fields from\n"
            "   'boost_fields' (e.g. sort_fields=['field_name:desc']).\n"
            "\n"
            "4. If results are poor (< 3 hits), call search_bm25 as fallback (drop the filter\n"
            "   if the previous filtered search was empty).\n"
            "\n"
            "5. Call rerank_results to get the top semantically-ranked hits.\n"
            "\n"
            "6. Summarise results. When boost/filter fields influenced ranking, explain why.\n"
            f"{self.instructions}"
        )

        agent = create_agent(
            self._llm,
            self._tools,
            system_prompt=system_prompt,
            middleware=[
                ToolCallLimitMiddleware(run_limit=10, exit_behavior="end"),  # type: ignore[arg-type]
                ToolRetryMiddleware(
                    max_retries=5,
                    tools=["search_hybrid", "rerank_results", "get_filter_values"],
                    retry_on=(Exception,),
                    backoff_factor=2.0,
                    initial_delay=1.0,
                    max_delay=30.0,
                    jitter=True,
                    on_failure="continue",
                ),
                ModelRetryMiddleware(
                    max_retries=5,
                    backoff_factor=2.0,
                    initial_delay=1.0,
                    max_delay=30.0,
                    on_failure="continue",
                ),
            ],
        )
        agent.step_timeout = 30.0
        return agent

    def _sample_field_values(self, fields: list[str], limit: int = 30) -> dict[str, list]:
        """Sample real stored values for filterable fields (like agent's get_filter_values)."""
        field_values: dict[str, list] = {}
        for field in fields:
            samples = self.backend.sample_documents(
                limit=limit, attributes_to_retrieve=[field]
            )
            seen: set[str] = set()
            values: list = []
            for doc in samples:
                v = doc.get(field)
                if v is None:
                    continue
                items = v if isinstance(v, list) else [v]
                for item in items:
                    k = str(item)
                    if k not in seen:
                        seen.add(k)
                        values.append(item)
            if values:
                field_values[field] = values[:limit]
        return field_values

    async def _adetect_filter_intent(self, question: str) -> FilterIntent:
        config = self.backend.get_index_config()
        filterable = config.filterable_attributes
        if not filterable:
            return FilterIntent(field=None, value="", operator="")

        # Sample real stored values so the LLM can match entities precisely
        loop = asyncio.get_running_loop()
        field_values = await loop.run_in_executor(
            None, self._sample_field_values, filterable
        )

        values_block = "\n".join(
            f"  {field}: {vals[:15]}"  # show up to 15 sample values
            for field, vals in field_values.items()
        )

        try:
            return cast(
                FilterIntent,
                await self._filter_intent_chain.ainvoke(
                    [
                        self._sys(
                            f"You help build filter expressions for a search backend.\n"
                            f"Filterable fields in this index: {filterable}\n\n"
                            f"Sample values per field:\n{values_block}\n\n"
                            "If the user's question names a SPECIFIC entity that maps to one of these\n"
                            "fields, return that field + the EXACT stored value (from the samples above)\n"
                            "that best matches + the best operator:\n"
                            "  CONTAINS — for partial name matches\n"
                            "  =        — for exact values (boolean, known exact string, numeric)\n"
                            "  IN       — for multiple values\n"
                            "If NO specific entity is named (broad/generic query), return field=null, value='', operator=''."
                        ),
                        HumanMessage(question),
                    ]
                ),
            )
        except Exception:
            return FilterIntent(field=None, value="", operator="")

    async def _afilter_search(self, question: str, query: str) -> list[Document]:
        intent = await self._adetect_filter_intent(question)
        if not intent.field or not intent.value or not intent.operator:
            return []

        filter_expr = f'{intent.field} {intent.operator} "{intent.value}"'
        limit = int(self.top_k * self.retrieval_factor)

        loop = asyncio.get_running_loop()
        vector: list[float] | None = None
        if self.embed_fn:
            try:
                vector = await loop.run_in_executor(None, self.embed_fn, query)
            except Exception:
                pass

        hits = await loop.run_in_executor(
            None,
            self.backend.search,
            self._make_search_request(
                query, limit, vector=vector, filter_expr=filter_expr
            ),
        )
        return [
            Document(page_content=self._hit_to_text(h), metadata=h)
            for h in hits[:limit]
        ]

    def _merge_doc_lists(self, *doc_lists: list[Document]) -> list[Document]:
        raw = [[d.metadata for d in dl] for dl in doc_lists]
        fused_meta = _rrf_fuse(raw)
        id_to_doc: dict[str, Document] = {}
        for dl in doc_lists:
            for d in dl:
                id_to_doc.setdefault(_doc_id(d.metadata), d)
        result = []
        for meta in fused_meta:
            key = _doc_id(meta)
            result.append(
                id_to_doc.get(key)
                or Document(page_content=self._hit_to_text(meta), metadata=meta)
            )
        return result

    async def ainvoke_parallel_agent(self, question: str) -> str:
        init = RAGState(question=question, query=question)
        pre_state, broad_docs = await asyncio.gather(
            self._apreprocess(init),
            self._asearch(question),
        )
        extracted_q = pre_state.query or question
        filter_docs = await self._afilter_search(question, extracted_q)

        merged = (
            self._merge_doc_lists(filter_docs, broad_docs)
            if filter_docs
            else broad_docs
        )
        merged_state = RAGState(
            question=question,
            query=extracted_q,
            documents=merged,
            iterations=1,
        )
        merged_state = await self._arerank(merged_state)
        if not merged_state.documents:
            merged_state = await self._aswarm_retrieve(
                RAGState(question=question, query=extracted_q, iterations=1),
            )
            merged_state = await self._arerank(merged_state)
        gen_state = await self._agenerate(merged_state)
        return str(gen_state.answer or "")

    def invoke_parallel_agent(self, question: str) -> str:
        return asyncio.run(self.ainvoke_parallel_agent(question))

    async def _acompute_hyde(self, question: str) -> str:
        """Pre-compute HyDE text, to be run concurrently with preprocessing."""
        if self.embed_fn and len(question.split()) >= self.hyde_min_words:
            try:
                return await self._ahypothetical_doc(question)
            except Exception:
                return question
        return question

    async def _aretrieve_documents(
        self, query: str, top_k: int | None = None
    ) -> tuple[str, list[Document]]:
        init = RAGState(question=query, query=query)
        # Fire preprocess + HyDE + filter-intent concurrently
        (state, hyde_text, filter_docs) = await asyncio.gather(
            self._apreprocess(init),
            self._acompute_hyde(query),
            self._afilter_search(query, query),
        )
        broad_docs = await self._asearch(
            state.query,
            question=state.question,
            extra_bm25=state.query_variants,
            factor=self.retrieval_factor,
            adaptive_semantic_ratio=state.adaptive_semantic_ratio,
            adaptive_fusion=state.adaptive_fusion,
            hyde_text=hyde_text,
        )
        docs = (
            self._merge_doc_lists(filter_docs, broad_docs)
            if filter_docs
            else broad_docs
        )
        state = state.model_copy(update={"documents": docs, "iterations": 1})
        if not state.documents:
            state = await self._aswarm_retrieve(state)
        state = await self._arerank(state)
        k = top_k or self.top_k
        return state.query, state.documents[:k]

    def retrieve_documents(
        self, query: str, top_k: int | None = None
    ) -> tuple[str, list[Document]]:
        return asyncio.run(self._aretrieve_documents(query, top_k=top_k))

    async def ainvoke(self, question: str) -> RAGState:
        init = RAGState(question=question, query=question)
        state = await self._aparallel_start(init)
        return cast(RAGState, await self._graph.ainvoke(state))

    def invoke(self, question: str) -> RAGState:
        return asyncio.run(self.ainvoke(question))

    async def achat(
        self,
        question: str,
        history: list[ConversationTurn] | None = None,
    ) -> RAGState:
        return cast(
            RAGState,
            await self._graph.ainvoke(
                RAGState(question=question, history=history or [])
            ),
        )

    def chat(
        self,
        question: str,
        history: list[ConversationTurn] | None = None,
    ) -> RAGState:
        return asyncio.run(self.achat(question, history))

    async def ainvoke_agent(self, question: str) -> str:
        result = await self._agent.ainvoke({"messages": [HumanMessage(question)]})
        msgs = result.get("messages", [])
        return str(msgs[-1].content) if msgs else ""

    def invoke_agent(self, question: str) -> str:
        return asyncio.run(self.ainvoke_agent(question))

    def query(self, question: str) -> str:
        return self.invoke(question).answer or ""
