from __future__ import annotations

import asyncio
import concurrent.futures
import os

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage

from .models import RerankResult


class CohereReranker:
    """Cohere reranker — default when cohere is installed.

    Works with both Cohere API and Azure Cohere deployments.
    """

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
    ):
        try:
            import cohere as _cohere
        except ImportError as e:
            raise ImportError(
                "cohere is required for CohereReranker. "
                "Install it with: pip install agenticrag[cohere]"
            ) from e

        endpoint = base_url or os.getenv("AZURE_COHERE_ENDPOINT", "")
        _base = (
            endpoint.removesuffix("/v2/rerank").removesuffix("/rerank")
            if endpoint
            else ""
        )
        key = (
            api_key or os.getenv("AZURE_COHERE_API_KEY") or os.getenv("COHERE_API_KEY")
        )

        self._client = _cohere.AsyncClientV2(
            api_key=key,
            base_url=_base or None,
        )
        self._model = model or os.getenv("AZURE_COHERE_DEPLOYMENT", "rerank-v3.5")

    def rerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        async def _do() -> list[RerankResult]:
            response = await self._client.rerank(
                model=self._model,
                query=query,
                documents=documents,
                top_n=top_n,
            )
            return [
                RerankResult(index=r.index, relevance_score=r.relevance_score)
                for r in response.results
            ]

        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(_do())

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, _do())
            return future.result(timeout=30)

    async def arerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        response = await self._client.rerank(
            model=self._model,
            query=query,
            documents=documents,
            top_n=top_n,
        )
        return [
            RerankResult(index=r.index, relevance_score=r.relevance_score)
            for r in response.results
        ]


class RerankersReranker:
    """Bridge to the `rerankers` library by answer.ai.

    Single interface for cross-encoders, ColBERT, RankGPT, Flashrank, and API models.
    See: https://github.com/AnswerDotAI/rerankers

    Requires: pip install rerankers  (or rerankers[transformers], rerankers[flashrank], etc.)

    Examples:
        RerankersReranker("cross-encoder/ms-marco-MiniLM-L-6-v2", model_type="cross-encoder")
        RerankersReranker("colbert-ir/colbertv2.0", model_type="colbert")
        RerankersReranker("flashrank", model_type="flashrank")
        RerankersReranker("gpt-4o-mini", model_type="rankgpt", api_key="...")
    """

    def __init__(self, model: str, model_type: str | None = None, **kwargs: object):
        try:
            from rerankers import Reranker  # type: ignore[import-untyped]
        except ImportError as e:
            raise ImportError(
                "rerankers is required for RerankersReranker. "
                "Install it with: pip install rerankers"
            ) from e

        self._ranker = Reranker(model, model_type=model_type, **kwargs)

    def rerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        if not documents:
            return []
        results = self._ranker.rank(query=query, docs=documents)
        top = results.top_k(top_n)
        return [
            RerankResult(index=r.doc_id, relevance_score=float(r.score)) for r in top
        ]

    async def arerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.rerank, query, documents, top_n)


class JinaReranker:
    """Jina AI reranker — REST API, strong multilingual support.

    Models: jina-reranker-v2-base-multilingual (default), jina-reranker-v1-base-en
    API key: https://jina.ai (free tier available)

    Requires: pip install httpx
    """

    _API_URL = "https://api.jina.ai/v1/rerank"

    def __init__(
        self,
        model: str = "jina-reranker-v2-base-multilingual",
        api_key: str | None = None,
    ):
        try:
            import httpx as _httpx  # noqa: F401
        except ImportError as e:
            raise ImportError(
                "httpx is required for JinaReranker. Install it with: pip install httpx"
            ) from e

        self._model = model
        self._api_key = api_key or os.getenv("JINA_API_KEY", "")

    def rerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        import httpx

        payload = {
            "model": self._model,
            "query": query,
            "documents": documents,
            "top_n": top_n,
        }
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        response = httpx.post(self._API_URL, json=payload, headers=headers, timeout=30)
        response.raise_for_status()
        results = response.json()["results"]
        return [
            RerankResult(index=r["index"], relevance_score=r["relevance_score"])
            for r in results
        ]

    async def arerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        import httpx

        payload = {
            "model": self._model,
            "query": query,
            "documents": documents,
            "top_n": top_n,
        }
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(self._API_URL, json=payload, headers=headers)
            response.raise_for_status()
        results = response.json()["results"]
        return [
            RerankResult(index=r["index"], relevance_score=r["relevance_score"])
            for r in results
        ]


class HuggingFaceReranker:
    """Cross-encoder reranker using a local HuggingFace model.

    Runs entirely locally — no API key, no network calls after model download.
    Default model: cross-encoder/ms-marco-MiniLM-L-6-v2 (fast, good quality).
    For multilingual: cross-encoder/mmarco-mMiniLMv2-L12-H384-v1

    Requires: pip install sentence-transformers
    """

    def __init__(
        self,
        model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2",
        device: str | None = None,
        max_length: int = 512,
    ):
        try:
            from sentence_transformers import CrossEncoder
        except ImportError as e:
            raise ImportError(
                "sentence-transformers is required for HuggingFaceReranker. "
                "Install it with: pip install sentence-transformers"
            ) from e

        self._model = CrossEncoder(model, device=device, max_length=max_length)

    def rerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        if not documents:
            return []
        pairs = [[query, doc] for doc in documents]
        scores = self._model.predict(pairs).tolist()
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:top_n]
        return [RerankResult(index=i, relevance_score=float(s)) for i, s in ranked]

    async def arerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self.rerank, query, documents, top_n)


class LLMReranker:
    """LLM-based reranker — uses any LangChain chat model to score relevance."""

    def __init__(self, llm: BaseChatModel | None = None):
        self._llm = llm

    def rerank(
        self,
        query: str,
        documents: list[str],
        top_n: int,
    ) -> list[RerankResult]:
        if not self._llm or not documents:
            return [
                RerankResult(index=i, relevance_score=1.0 / (i + 1))
                for i in range(min(top_n, len(documents)))
            ]

        numbered = "\n".join(f"[{i}] {doc[:500]}" for i, doc in enumerate(documents))
        prompt = (
            f"Rate relevance of each document to the query on a scale 0.0-1.0.\n"
            f"Query: {query}\n\nDocuments:\n{numbered}\n\n"
            f"Return ONLY a JSON list of objects with 'index' (int) and 'score' (float). "
            f"Example: [{{'index': 0, 'score': 0.9}}, {{'index': 1, 'score': 0.3}}]"
        )
        try:
            result = self._llm.invoke([HumanMessage(prompt)])
            import json as _json

            content = str(result.content).strip()
            start = content.index("[")
            end = content.rindex("]") + 1
            scores = _json.loads(content[start:end])
            ranked = sorted(scores, key=lambda x: x["score"], reverse=True)[:top_n]
            return [
                RerankResult(index=int(r["index"]), relevance_score=float(r["score"]))
                for r in ranked
            ]
        except Exception:
            return [
                RerankResult(index=i, relevance_score=1.0 / (i + 1))
                for i in range(min(top_n, len(documents)))
            ]
