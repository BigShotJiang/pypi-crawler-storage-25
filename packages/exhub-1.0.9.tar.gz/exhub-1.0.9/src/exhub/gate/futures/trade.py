from loguru import logger
from exhub.config import Config
from exhub.common import Common
from decimal import Decimal

class FuturesTrade:
    """Gate.io 合约交易实现"""
    def __init__(self, client, market=None):
        self.client = client
        self._market = market

    def _get_quanto(self, coin):
        """获取 1张合约 = 多少个币 (quanto_multiplier), 用于持仓展示"""
        info = self._market.get_coin_info_futures(coin)
        return float(info.get("GATE", {}).get("ct_val", 1))

    @staticmethod
    def _normalize_open_side(side: str) -> bool:
        """
        开仓方向转换：用于 order_futures 开仓。
        :return: bool 是否为买单 (True=买/开多, False=卖/开空)
        """
        s = side.upper()
        if s in ("LONG", "BUY"):
            return True
        else:
            return False

    @staticmethod
    def _normalize_close_side(side: str) -> bool:
        """
        平仓/止盈止损方向转换：用户传入开仓方向，内部反转为平仓方向。
        :return: bool 是否为买单 (True=买/平空, False=卖/平多)
        """
        s = side.upper()
        if s in ("LONG", "BUY"):
            return False # 持有多仓 -> 平仓需要卖 (False)
        else:
            return True  # 持有空仓 -> 平仓需要买 (True)

    @staticmethod
    def _get_auto_size(side: str) -> str:
        """
        根据开仓方向返回双向持仓模式下的 auto_size 平仓方向。
        :param side: 开仓方向 LONG/BUY/SHORT/SELL
        :return: close_long 或 close_short
        """
        s = side.upper()
        if s in ("LONG", "BUY"):
            return "close_long"
        else:
            return "close_short"

    def order_futures(self, coin, side, order_type, size, stop_loss_price=None):
        """
        下单 (TRADE)
        POST /api/v4/futures/usdt/orders
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")

        path = "/futures/usdt/orders"

        buy_side = self._normalize_open_side(side)
        lots = abs(int(float(size)))
        if lots == 0:
            lots = 1
        qty_out = lots if buy_side else -lots

        body = {
            "contract": symbol,
            "size": qty_out,
            "price": "0",
            "tif": "ioc",
        }
        res = self.client.post(path, body=body, signed=True)
        logger.debug(res)
        return Common().return_futures_order_struct("GATE", coin, side, order_type, size, res.get("id"), res)

    def close_position_futures(self, coin, side, order_type, size):
        """
        平仓 (Close Position)
        双向持仓模式：size=0 + auto_size 指定平仓方向 + reduce_only=True
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")

        path = "/futures/usdt/orders"

        buy_side = self._normalize_close_side(side)
        lots = abs(int(float(size))) if size and float(size) > 0 else 0
        if lots > 0:
            qty_out = lots if buy_side else -lots
            body = {
                "contract": symbol,
                "size": qty_out,
                "price": "0",
                "tif": "ioc",
                "reduce_only": True
            }
        else:
            # 全部平仓：size=0 + auto_size + reduce_only
            body = {
                "contract": symbol,
                "size": 0,
                "price": "0",
                "tif": "ioc",
                "auto_size": self._get_auto_size(side),
                "reduce_only": True
            }

        res = self.client.post(path, body=body, signed=True)
        logger.debug(res)
        logger.success(f'平仓成功: {res.get("id")}')
        return Common().return_futures_order_struct("GATE", coin, side, order_type, size, res.get("id"), res)

    def get_position_futures(self, coin):
        """
        获取仓位信息 (Get Position)
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")

        quanto_multiplier = self._get_quanto(coin)

        path = f"/futures/usdt/positions/{symbol}"
        res = self.client.get(path, signed=True)
        logger.debug(res)

        positions = []
        if isinstance(res, list):
            items = res
        elif isinstance(res, dict):
            items = [res]
        else:
            items = []

        # 查询当前合约的活跃条件单（止盈止损）
        price_orders = []
        try:
            params = {"contract": symbol, "status": "open"}
            price_orders = self.client.get("/futures/usdt/price_orders", params=params, signed=True)
            if not isinstance(price_orders, list):
                price_orders = []
        except Exception as e:
            logger.warning(f"Gate 查询条件单异常: {e}")

        for item in items:
            raw_size = float(item.get("size", 0))
            if raw_size != 0:
                size = raw_size * quanto_multiplier
                pos_side = "LONG" if size > 0 else "SHORT"
                entry_price = float(item.get("entry_price", 0))
                unrealized_profit = item.get("unrealised_pnl", 0)
                liquidation_price = item.get("liq_price", 0)

                all_sl_price = "0"
                all_tp_price = "0"
                partial_sl = {"size": "0", "price": "0"}
                partial_tp = {"size": "0", "price": "0"}
                
                if pos_side == "LONG":
                    full_types = ["close-long-position"]
                    plan_types = ["plan-close-long-position"]
                    sl_rule = 2  # 价格 <= 触发价
                    tp_rule = 1  # 价格 >= 触发价
                else:
                    full_types = ["close-short-position"]
                    plan_types = ["plan-close-short-position"]
                    sl_rule = 1  # 价格 >= 触发价
                    tp_rule = 2  # 价格 <= 触发价
                
                for po in price_orders:
                    ot = po.get("order_type", "")
                    rule = po.get("trigger", {}).get("rule")
                    trigger_price = po.get("trigger", {}).get("price", "0")
                    po_size = abs(float(po.get("initial", {}).get("size", 0))) * quanto_multiplier
                    
                    if ot in full_types and rule == sl_rule:
                        all_sl_price = trigger_price
                    elif ot in full_types and rule == tp_rule:
                        all_tp_price = trigger_price
                    elif ot in plan_types and rule == sl_rule:
                        partial_sl = {"size": str(po_size), "price": trigger_price}
                    elif ot in plan_types and rule == tp_rule:
                        partial_tp = {"size": str(po_size), "price": trigger_price}
                
                pos_info = Common().return_futures_position_struct(
                    coin, abs(size), entry_price, pos_side, unrealized_profit, liquidation_price, 
                    all_sl_price, all_tp_price, partial_sl, partial_tp, item
                )
                positions.append(pos_info)

        return {"GATE": positions}

    def set_stop_loss_futures(self, coin, side, size, stop_price):
        """
        设置止损
        双向持仓模式下 size=None 时使用 size=0 + auto_size 全仓平仓
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")

        buy_side = self._normalize_close_side(side)
        rule = 1 if buy_side else 2

        qty = abs(float(size)) if size else 0
        s = side.upper()
        if qty > 0:
            order_type = "plan-close-long-position" if s in ("LONG", "BUY") else "plan-close-short-position"
            quanto_multiplier = self._get_quanto(coin)
            lots = max(1, int(Decimal(str(qty)) / Decimal(str(quanto_multiplier))))
            qty_out = lots if buy_side else -lots
            initial = {
                "contract": symbol,
                "size": qty_out,
                "price": "0",
                "tif": "ioc",
                "reduce_only": True
            }
        else:
            order_type = "close-long-position" if s in ("LONG", "BUY") else "close-short-position"
            initial = {
                "contract": symbol,
                "size": 0,
                "price": "0",
                "tif": "ioc",
                "auto_size": self._get_auto_size(side),
                "reduce_only": True
            }

        body = {
            "initial": initial,
            "trigger": {
                "strategy_type": 0,
                "price_type": 0,
                "price": str(stop_price),
                "rule": rule
            },
            "order_type": order_type
        }
        path = "/futures/usdt/price_orders"
        res = self.client.post(path, body=body, signed=True)
        logger.debug(res)
        status = "id" in res or res.get("id") is not None
        return Common().return_set_stop_loss_struct("GATE", coin, status, res)

    def set_take_profit_futures(self, coin, side, size, tp_price):
        """
        设置止盈
        双向持仓模式下 size=None 时使用 size=0 + auto_size 全仓平仓
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")

        buy_side = self._normalize_close_side(side)
        rule = 2 if buy_side else 1

        qty = abs(float(size)) if size else 0
        s = side.upper()
        if qty > 0:
            order_type = "plan-close-long-position" if s in ("LONG", "BUY") else "plan-close-short-position"
            quanto_multiplier = self._get_quanto(coin)
            lots = max(1, int(Decimal(str(qty)) / Decimal(str(quanto_multiplier))))
            qty_out = lots if buy_side else -lots
            initial = {
                "contract": symbol, "size": qty_out,
                "price": "0", "tif": "ioc", "reduce_only": True
            }
        else:
            order_type = "close-long-position" if s in ("LONG", "BUY") else "close-short-position"
            initial = {
                "contract": symbol, "size": 0,
                "price": "0", "tif": "ioc",
                "auto_size": self._get_auto_size(side), "reduce_only": True
            }

        body = {
            "initial": initial,
            "trigger": {"strategy_type": 0, "price_type": 0, "price": str(tp_price), "rule": rule},
            "order_type": order_type
        }
        path = "/futures/usdt/price_orders"
        res = self.client.post(path, body=body, signed=True)
        logger.debug(res)
        status = "id" in res or res.get("id") is not None
        return Common().return_set_take_profit_struct("GATE", coin, status, res)

    def update_stop_loss_futures(self, coin, side, size, stop_price):
        """修改止损：先撤同类旧止损单再挂新单"""
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")
        
        s = side.upper()
        qty = abs(float(size)) if size else 0
        # 根据 size 精确匹配：全仓只撤全仓，部分只撤部分
        if qty > 0:
            target_type = "plan-close-long-position" if s in ("LONG", "BUY") else "plan-close-short-position"
        else:
            target_type = "close-long-position" if s in ("LONG", "BUY") else "close-short-position"
        
        buy_side = self._normalize_close_side(side)
        sl_rule = 1 if buy_side else 2
        
        try:
            params = {"contract": symbol, "status": "open"}
            algos = self.client.get("/futures/usdt/price_orders", params=params, signed=True)
            if isinstance(algos, list):
                for a in algos:
                    if (a.get("order_type", "") == target_type
                            and a.get("trigger", {}).get("rule") == sl_rule):
                        order_id = a.get("id")
                        self.client.delete(f"/futures/usdt/price_orders/{order_id}", signed=True)
                        logger.info(f"Gate 撤销旧止损单: {order_id} (type={target_type})")
        except Exception as e:
            logger.warning(f"Gate 更新止损撤旧单异常: {e}")

        return self.set_stop_loss_futures(coin, side, size, stop_price)

    def update_take_profit_futures(self, coin, side, size, tp_price):
        """修改止盈：先撤同类旧止盈单再挂新单"""
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")
        
        s = side.upper()
        qty = abs(float(size)) if size else 0
        # 根据 size 精确匹配：全仓只撤全仓，部分只撤部分
        if qty > 0:
            target_type = "plan-close-long-position" if s in ("LONG", "BUY") else "plan-close-short-position"
        else:
            target_type = "close-long-position" if s in ("LONG", "BUY") else "close-short-position"
        
        buy_side = self._normalize_close_side(side)
        tp_rule = 2 if buy_side else 1
        
        try:
            params = {"contract": symbol, "status": "open"}
            algos = self.client.get("/futures/usdt/price_orders", params=params, signed=True)
            if isinstance(algos, list):
                for a in algos:
                    if (a.get("order_type", "") == target_type
                            and a.get("trigger", {}).get("rule") == tp_rule):
                        order_id = a.get("id")
                        self.client.delete(f"/futures/usdt/price_orders/{order_id}", signed=True)
                        logger.info(f"Gate 撤销旧止盈单: {order_id} (type={target_type})")
        except Exception as e:
            logger.warning(f"Gate 更新止盈撤旧单异常: {e}")

        return self.set_take_profit_futures(coin, side, size, tp_price)

    def get_recent_pnl(self, coin):
        """获取最近一笔平仓的已实现盈亏"""
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")
            
        params = {"contract": symbol, "limit": 1}
        try:
            res = self.client.get("/futures/usdt/position_close", params=params, signed=True)
            pnl = 0.0
            if isinstance(res, list) and len(res) > 0:
                pnl = float(res[0].get("pnl", 0))
            return Common().return_pnl_struct("GATE", coin, pnl)
        except Exception as e:
            logger.warning(f"Gate PNL Error: {e}")
            return Common().return_pnl_struct("GATE", coin, 0.0)
