from loguru import logger
from exhub.common import Common

class FuturesTrade:
    """OKX 合约交易实现"""
    def __init__(self, client):
        self.client = client

    @staticmethod
    def _normalize_open_sides(side: str) -> tuple[str, str]:
        """
        开仓方向转换：用于 order_futures 开仓。
        用户传入开仓方向 (BUY/SELL)，内部转成 OKX 开仓所需的 side 和 posSide。
        :return: (order_side=buy/sell, pos_side=long/short)
        """
        s = side.upper()
        if s in ("LONG", "BUY"):   # 开多: side=buy, posSide=long
            return "buy", "long"
        else:                       # 开空: side=sell, posSide=short
            return "sell", "short"

    @staticmethod
    def _normalize_sl_tp_sides(side: str) -> tuple[str, str]:
        """
        止损/止盈单方向转换：用于 set_stop_loss / set_take_profit。
        用户传入开仓方向 (BUY/SELL)，内部自动反转为平仓方向。
        XXX: OKX 止损/止盈单的 side 是「平仓方向」（与持仓相反），posSide 是「持仓方向」
        :return: (order_side=平仓buy/sell, pos_side=long/short)
        """
        s = side.upper()
        if s in ("LONG", "BUY"):   # 持有多仓 → 止损需要 SELL 平多
            return "sell", "long"
        else:                       # 持有空仓 → 止损需要 BUY 平空
            return "buy", "short"

    def order_futures(self, coin, side, order_type, size, stop_loss_price=None):
        """
        开仓下单 (TRADE)
        POST /api/v5/trade/order
        :param stop_loss_price: 预设止损价（通过 attachAlgoOrds 附带，触发后全平该仓位）
        XXX: OKX attachAlgoOrds 中的 slTriggerPx 是针对本次开仓全部仓位的止损
        """
        path = "/api/v5/trade/order"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
        # order_futures 是开仓操作，使用 _normalize_open_sides
        order_side, pos_side = self._normalize_open_sides(side)

        body = {
            "instId": symbol,
            "tdMode": "isolated",
            "side": order_side,
            "posSide": pos_side,
            "ordType": "market",
            "sz": str(size)
        }

        res = self.client.post(path, body=body)
        logger.debug(res)
        if res.get("code") == "0":
            order_id = res.get("data")[0].get("ordId")
            logger.success(f'开仓成功: {order_id}')
            return Common().return_futures_order_struct("OKX", coin, side, order_type, size, order_id, res)
        else:
            raise Exception(res.get("msg", "Unknown error"))


    def close_position_futures(self, coin, side, order_type, size):
        """
        平仓 (Close Position)
        POST /api/v5/trade/order
        :param coin: 币本位合约 (如 BTCUSDT)
        :param side: 开仓方向 (BUY/SELL) 或持仓方向 (LONG/SHORT)
        :param order_type: 订单类型 market
        :param size: 数量
        """
        path = "/api/v5/trade/order"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        if not symbol.endswith("-SWAP"):
            symbol = symbol.replace("USDT", "USDT-SWAP")

        order_side, pos_side = self._normalize_sl_tp_sides(side)

        body = {
            "instId": symbol,
            "tdMode": "isolated",
            "side": order_side,
            "ordType": order_type.lower(),
            "sz": str(size),
            "posSide": pos_side
        }
        res = self.client.post(path, body=body)
        logger.debug(res)
        if res.get("code") == "0":
            order_id = res.get("data")[0].get("ordId")
            logger.success(f'平仓成功: {order_id}')
            return Common().return_futures_order_struct("OKX", coin, side, order_type, size, order_id, res)
        else:
            raise Exception(res.get("msg", "Unknown error"))

    def get_position_futures(self, coin):
        """
        获取仓位信息 (Get Position)
        GET /api/v5/account/positions
        :param coin: 币本位合约 (如 BTCUSDT)
        :return: list of positions [dict] or []
        """
        path = "/api/v5/account/positions"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        if not symbol.endswith("-SWAP"):
            symbol = symbol.replace("USDT", "USDT-SWAP")

        params = {"instId": symbol}
        res = self.client.get(path, params=params)
        logger.debug(res)
        
        pending_algos = []
        try:
            res_pending = self.client.get("/api/v5/trade/orders-algo-pending", params={"instId": symbol, "ordType": "conditional"})
            if res_pending.get("code") == "0" and res_pending.get("data"):
                pending_algos = res_pending["data"]
        except Exception as e:
            logger.warning(f"OKX 获取当前挂单(止盈止损)失败: {e}")

        positions = []
        if res.get("code") == "0" and res.get("data"):
            for item in res["data"]:
                size = float(item.get("pos", 0))
                if size != 0:
                    okx_side = item.get("posSide", "")
                    # OKX 返回的 posSide 可能是 long, short, 或 net。如果是 net 则通过 size 正负判断。
                    if okx_side == "net":
                        pos_side = "LONG" if size > 0 else "SHORT"
                    else:
                        pos_side = okx_side.upper()

                    entry_price = float(item.get("avgPx", 0))
                    unrealized_profit = item.get("upl", 0)
                    liquidation_price = item.get("liqPx", 0)
                    
                    all_stop_loss_price = ""
                    all_take_profit_price = ""
                    partial_stop_loss = {"size": "0", "price": "0"}
                    partial_take_profit = {"size": "0", "price": "0"}
                    
                    if item.get("closeOrderAlgo"):
                        for algo in item["closeOrderAlgo"]:
                            frac = algo.get("closeFraction", "")
                            if frac == "1.0" or frac == "1":
                                sl = algo.get("slTriggerPx", "")
                                tp = algo.get("tpTriggerPx", "")
                                if sl and sl != "0": all_stop_loss_price = sl
                                if tp and tp != "0": all_take_profit_price = tp
                                
                    for a in pending_algos:
                        if a.get("posSide") == okx_side and a.get("closeFraction") != "1" and a.get("closeFraction") != "1.0":
                            sl = a.get("slTriggerPx", "")
                            tp = a.get("tpTriggerPx", "")
                            sz = a.get("sz", "")
                            if sl and sl != "0": partial_stop_loss = {"size": str(sz), "price": str(sl)}
                            if tp and tp != "0": partial_take_profit = {"size": str(sz), "price": str(tp)}
                    
                    pos_info = Common().return_futures_position_struct(
                        coin, abs(size), entry_price, pos_side, unrealized_profit, liquidation_price, 
                        all_stop_loss_price, all_take_profit_price, partial_stop_loss, partial_take_profit, item
                    )
                    positions.append(pos_info)

        return {"OKX": positions}

    def set_stop_loss_futures(self, coin, side, size, stop_price):
        """
        设置/修改止损 (策略委托)
        :param side: 开仓方向，兼容 BUY/SELL 与 LONG/SHORT
        :param size: 数量，如果为 None/0 则全平 (closeFraction="1")
        """
        path = "/api/v5/trade/order-algo"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        if not symbol.endswith("-SWAP"):
            symbol = symbol.replace("USDT", "USDT-SWAP")
        # set_stop_loss 是平仓操作，使用 _normalize_sl_tp_sides 自动反转方向
        order_side, pos_side = self._normalize_sl_tp_sides(side)

        body = {
            "instId": symbol,
            "tdMode": "isolated",
            "side": order_side,
            "posSide": pos_side,
            "ordType": "conditional",
            "slTriggerPx": str(stop_price),
            "slOrdPx": "-1",
            "slTriggerPxType": "mark"
        }

        if size:
            body["sz"] = str(size)
        else:
            body["closeFraction"] = "1"
            params = {"instId": symbol, "ordType": "conditional"}
            res_pending = self.client.get("/api/v5/trade/orders-algo-pending", params=params)
            if res_pending.get("code") == "0" and res_pending.get("data"):
                for item in res_pending["data"]:
                    if item.get("closeFraction") == "1" and item.get("posSide") == pos_side:
                        if item.get("tpTriggerPx") and item.get("tpTriggerPx") != "0" and item.get("tpTriggerPx") != "":
                            body["tpTriggerPx"] = item["tpTriggerPx"]
                            body["tpOrdPx"] = item.get("tpOrdPx", "-1")
                            body["tpTriggerPxType"] = item.get("tpTriggerPxType", "mark")
                        self.client.post("/api/v5/trade/cancel-algos", body=[{"algoId": item["algoId"], "instId": symbol}])
        

        if body.get("tpTriggerPx") and body.get("slTriggerPx"):
            body["ordType"] = "oco"
        
        logger.debug(f"OKX Final StopLoss Body: {body}")
        res = self.client.post(path, body=body)
        logger.debug(f"OKX set stop loss: {res}")
        status = res.get("code") == "0"
        return Common().return_set_stop_loss_struct("OKX", coin, status, res)

    def set_take_profit_futures(self, coin, side, size, tp_price):
        """
        设置/修改止盈 (策略委托)
        :param side: 开仓方向，兼容 BUY/SELL 与 LONG/SHORT
        :param size: 数量，如果为 None/0 则全平 (closeFraction="1")
        """
        path = "/api/v5/trade/order-algo"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        if not symbol.endswith("-SWAP"):
            symbol = symbol.replace("USDT", "USDT-SWAP")
        order_side, pos_side = self._normalize_sl_tp_sides(side)

        body = {
            "instId": symbol,
            "tdMode": "isolated",
            "side": order_side,
            "posSide": pos_side,
            "ordType": "conditional",
            "tpTriggerPx": str(tp_price),
            "tpOrdPx": "-1",
            "tpTriggerPxType": "mark"
        }

        if size:
            body["sz"] = str(size)
        else:
            body["closeFraction"] = "1"
            params = {"instId": symbol, "ordType": "conditional"}
            res_pending = self.client.get("/api/v5/trade/orders-algo-pending", params=params)
            if res_pending.get("code") == "0" and res_pending.get("data"):
                for item in res_pending["data"]:
                    if item.get("closeFraction") == "1" and item.get("posSide") == pos_side:
                        if item.get("slTriggerPx") and item.get("slTriggerPx") != "0" and item.get("slTriggerPx") != "":
                            body["slTriggerPx"] = item["slTriggerPx"]
                            body["slOrdPx"] = item.get("slOrdPx", "-1")
                            body["slTriggerPxType"] = item.get("slTriggerPxType", "mark")
                        # 撤销旧单
                        self.client.post("/api/v5/trade/cancel-algos", body=[{"algoId": item["algoId"], "instId": symbol}])
        
        if body.get("tpTriggerPx") and body.get("slTriggerPx"):
            body["ordType"] = "oco"

        logger.debug(f"OKX Final TakeProfit Body: {body}")
        res = self.client.post(path, body=body)
        logger.debug(f"OKX set take profit: {res}")
        status = res.get("code") == "0"
        return Common().return_set_take_profit_struct("OKX", coin, status, res)

    def update_take_profit_futures(self, coin, side, size, tp_price):
        """修改止盈"""
        if size:
            symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
            if not symbol.endswith("-SWAP"):
                symbol = symbol.replace("USDT", "USDT-SWAP")
            _, pos_side = self._normalize_sl_tp_sides(side)

            params = {"instId": symbol, "ordType": "conditional"}
            res_pending = self.client.get("/api/v5/trade/orders-algo-pending", params=params)
            if res_pending.get("code") == "0" and res_pending.get("data"):
                algo_ids = []
                for item in res_pending["data"]:
                    if item.get("tpTriggerPx") and item.get("posSide") == pos_side and item.get("closeFraction") != "1":
                        algo_ids.append({"algoId": item["algoId"], "instId": symbol})
                if algo_ids:
                    self.client.post("/api/v5/trade/cancel-algos", body=algo_ids)

        return self.set_take_profit_futures(coin, side, size, tp_price)

    def get_recent_pnl(self, coin):
        """
        获取最近一笔平仓的已实现盈亏
        GET /api/v5/account/positions-history
        """
        path = "/api/v5/account/positions-history"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        if not symbol.endswith("-SWAP"):
            symbol = symbol.replace("USDT", "USDT-SWAP")
            
        params = {"instId": symbol, "limit": "1"}
        res = self.client.get(path, params=params)
        logger.debug(res)
        pnl = 0.0
        if res.get("code") == "0" and res.get("data"):
            pnl = float(res["data"][0].get("realizedPnl", 0))
        return Common().return_pnl_struct("OKX", coin, pnl)

    def update_stop_loss_futures(self, coin, side, size, stop_price):
        """修改止损"""
        if size:
            symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
            if not symbol.endswith("-SWAP"):
                symbol = symbol.replace("USDT", "USDT-SWAP")
            _, pos_side = self._normalize_sl_tp_sides(side)

            params = {"instId": symbol, "ordType": "conditional"}
            res_pending = self.client.get("/api/v5/trade/orders-algo-pending", params=params)
            if res_pending.get("code") == "0" and res_pending.get("data"):
                algo_ids = []
                for item in res_pending["data"]:
                    if item.get("slTriggerPx") and item.get("posSide") == pos_side and item.get("closeFraction") != "1":
                        algo_ids.append({"algoId": item["algoId"], "instId": symbol})
                if algo_ids:
                    self.client.post("/api/v5/trade/cancel-algos", body=algo_ids)

        return self.set_stop_loss_futures(coin, side, size, stop_price)
