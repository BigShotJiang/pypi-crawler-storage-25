# TruthScan Image Detection — Python Client

Python client for the [TruthScan AI Image Detection API](https://truthscan.com/truthscan-ai-image-detection-api-documentation). Detect whether images are AI-generated, real, digitally edited, or AI-edited.

## Requirements

- Python 3.9+
- A TruthScan API key ([get one here](https://truthscan.com))

## Installation

```bash
pip install truthscan-image-detector-client
```

## Quick start

```python
import os

from ai_image_detection import ImageDetectionClient

api_key = os.environ.get("TRUTHSCAN_API_KEY", "your_api_key_here")
client = ImageDetectionClient(api_key=api_key)

result = client.detect("path/to/image.jpg")

print(f"Status: {result['status']}")
print(f"Score: {result.get('result', 'N/A')}")
print(f"Final: {(result.get('result_details') or {}).get('final_result', '')}")
```

`detect()` runs presign → upload → detect → poll until complete.

## Configuration

```python
from ai_image_detection import ImageDetectionClient, DefaultConsoleLogger

client = ImageDetectionClient(
    api_key="YOUR_API_KEY",
    base_url=None,  # optional API base URL
    timeout=60,
    logger=DefaultConsoleLogger("info"),
)
```

## API reference

### ImageDetectionClient

| Method | Description |
|--------|-------------|
| `detect(image, email?, generate_preview?, max_poll_attempts?, poll_interval_seconds?)` | Full workflow: presign, upload, detect, poll. Returns `DetectionResult`. |
| `check_user_credits()` | Returns credit balance for the API key. |

### ImageDetectionService (low-level)

For advanced use, import `ImageDetectionService` and call presign, upload, detect, query, and poll directly.

## Supported file formats

JPG, JPEG, PNG, WebP, JFIF, HEIC, HEIF, AVIF, BMP, TIFF, TIF, GIF, SVG, PDF

**File size limits:** 1 KB – 10 MB

**Note:** Remove spaces from filenames before uploading.

## Development

```bash
cd python
pip install -e .
python tests/test_client.py
```

## License

MIT
