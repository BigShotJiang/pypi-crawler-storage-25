class ApiClientError(Exception):
    """Base exception for API client errors."""
    pass


class PresignError(ApiClientError):
    """Exception raised when presign operation fails."""
    pass


class UploadError(ApiClientError):
    """Exception raised when upload operation fails."""
    pass


class DetectError(ApiClientError):
    """Exception raised when detect operation fails."""
    pass


class QueryError(ApiClientError):
    """Exception raised when query operation fails."""
    pass


class CreditCheckError(ApiClientError):
    """Exception raised when credit check operation fails."""
    pass
