from typing import TypedDict, Optional, Dict, Any, List, Tuple


class PresignResponse(TypedDict):
    """Response from presign endpoint"""
    status: str
    presigned_url: str
    file_path: str
    document_id: Optional[str]


class DetectResponse(TypedDict):
    """Response from detect endpoint"""
    id: str
    status: str


class ResultDetails(TypedDict, total=False):
    """Detailed detection results"""
    is_valid: Optional[bool]
    detection_step: Optional[int]
    final_result: Optional[str]
    metadata: Optional[List[Tuple[str, str]]]
    metadata_basic_source: Optional[str]
    ocr: Optional[List[Tuple[str, int]]]
    ml_model: Optional[List[Tuple[str, int]]]
    confidence: Optional[int]
    analysis_results: Optional[Dict[str, Any]]
    analysis_results_status: Optional[str]
    heatmap_url: Optional[str]
    heatmap_status: Optional[str]


class QueryResponse(TypedDict, total=False):
    """Response from query endpoint"""
    id: str
    status: str
    result: Optional[int]
    result_details: Optional[ResultDetails]
    preview_url: Optional[str]


class CreditCheckResponse(TypedDict):
    """Response from credit check endpoint"""
    baseCredits: int
    boostCredits: int
    credits: int


# Type aliases
Image = str
DetectionResult = QueryResponse
