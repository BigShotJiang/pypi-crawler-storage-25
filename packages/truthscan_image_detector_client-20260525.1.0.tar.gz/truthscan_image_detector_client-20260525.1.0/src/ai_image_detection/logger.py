from typing import Protocol
from datetime import datetime


class Logger(Protocol):
    """Logger interface for the Image Detection Client"""
    
    def info(self, message: str) -> None:
        """Log an info message"""
        ...
    
    def debug(self, message: str) -> None:
        """Log a debug message"""
        ...
    
    def warn(self, message: str) -> None:
        """Log a warning message"""
        ...
    
    def error(self, message: str) -> None:
        """Log an error message"""
        ...


class DefaultConsoleLogger:
    """
    Default console logger implementation
    """
    
    def __init__(self, log_level: str = "info") -> None:
        """
        Initialize the default console logger.
        
        Args:
            log_level: Logging level ('debug', 'info', 'warn', 'error', default: 'info')
        """
        self.log_level = log_level
    
    def _timestamp(self) -> str:
        """Generate ISO timestamp"""
        return datetime.now().isoformat()
    
    def _should_log(self, level: str) -> bool:
        """
        Check if a message at the given level should be logged.
        
        Args:
            level: Log level to check
            
        Returns:
            True if the message should be logged
        """
        levels = {
            'debug': 0,
            'info': 1,
            'warn': 2,
            'error': 3,
        }
        return levels.get(level, 1) >= levels.get(self.log_level, 1)
    
    def info(self, message: str) -> None:
        """Log an info message"""
        if self._should_log('info'):
            print(f"[{self._timestamp()}] INFO: {message}")
    
    def debug(self, message: str) -> None:
        """Log a debug message"""
        if self._should_log('debug'):
            print(f"[{self._timestamp()}] DEBUG: {message}")
    
    def warn(self, message: str) -> None:
        """Log a warning message"""
        if self._should_log('warn'):
            print(f"[{self._timestamp()}] WARN: {message}")
    
    def error(self, message: str) -> None:
        """Log an error message"""
        if self._should_log('error'):
            print(f"[{self._timestamp()}] ERROR: {message}")
