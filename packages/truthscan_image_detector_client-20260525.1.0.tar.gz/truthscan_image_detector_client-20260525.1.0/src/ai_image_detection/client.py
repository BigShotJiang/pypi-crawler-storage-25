import os
from typing import Optional

from .service import ImageDetectionService
from .logger import Logger, DefaultConsoleLogger
from .errors import QueryError, CreditCheckError
from .api_types import Image, DetectionResult, CreditCheckResponse


class ImageDetectionClient:
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
        logger: Optional[Logger] = None
    ) -> None:
        """
        Initialize the Image Detection Client.
        
        Args:
            api_key: API key for authentication
            base_url: Base URL of the API server (optional, default: 'https://ai-image-detect.undetectable.ai')
            timeout: Default timeout for requests in seconds (optional, default: 60)
            logger: Logger instance (optional, default: DefaultConsoleLogger("info"))
        """
        self.base_url = base_url or 'https://ai-image-detect.undetectable.ai'
        resolved_logger = logger if logger is not None else DefaultConsoleLogger("info")
        self.service = ImageDetectionService(
            self.base_url,
            api_key,
            timeout or 60,
            resolved_logger
        )
    
    def detect(
        self,
        image: Image,
        email: Optional[str] = None,
        generate_preview: bool = True,
        max_poll_attempts: int = 60,
        poll_interval_seconds: float = 0.5
    ) -> DetectionResult:
        """
        Detect AI-generated content in an image.
        
        This method handles the entire workflow:
        1. Presign - Get presigned URL for upload
        2. Upload - Upload the image file
        3. Detect - Submit the image for detection
        4. Poll - Wait for detection results
        
        Args:
            image: File path to the image to detect
            email: Optional email address for processing
            generate_preview: Optional flag to generate preview (default: True)
            max_poll_attempts: Maximum number of polling attempts (default: 60)
            poll_interval_seconds: Seconds to sleep between polling attempts (default: 0.5)
            
        Returns:
            DetectionResult containing detection status and results
            
        Raises:
            QueryError: If polling times out or other errors occur
        """
        # 1. Extract filename from path
        file_name = os.path.basename(image).replace(' ', '')
        
        # 2. Presign - Get presigned URL
        presign_result = self.service.get_presigned_url(file_name)
        
        # 3. Upload - Upload the file
        self.service.upload(presign_result["presigned_url"], image)
        
        # 4. Build file URL for detect operation
        # Determine CDN base URL based on the baseUrl (dev vs prod)
        cdn_base_url = self._get_cdn_base_url()
        file_path_remote_full = f"{cdn_base_url}{presign_result['file_path']}"
        file_url = ImageDetectionService.build_detect_file_url(
            file_path_remote_full,
            presign_result["presigned_url"]
        )
        
        # 5. Detect - Submit for detection
        detect_result = self.service.detect(
            file_url,
            email,
            generate_preview
        )
        
        # 6. Poll for result - Wait for completion
        final_result = self.service.poll_for_result(
            detect_result["id"],
            max_poll_attempts,
            poll_interval_seconds
        )
        
        if final_result is None:
            raise QueryError('Polling timeout - detection result not available')
        
        return final_result
    
    def check_user_credits(self) -> CreditCheckResponse:
        """
        Check user credits for the API key.
        
        Returns:
            CreditCheckResponse containing credit information
            
        Raises:
            CreditCheckError: If the credit check operation fails
        """
        try:
            return self.service.check_user_credits()
        except Exception as e:
            raise CreditCheckError(str(e)) from e
    
    def _get_cdn_base_url(self) -> str:
        """
        Get the CDN base URL based on the configured baseUrl.
        
        Returns:
            CDN base URL string
        """
        if 'undetectable.ai' in self.base_url:
            return 'https://ai-image-detector-prod.nyc3.digitaloceanspaces.com/'
        else:
            return 'https://ai-image-detector-dev.nyc3.digitaloceanspaces.com/'
