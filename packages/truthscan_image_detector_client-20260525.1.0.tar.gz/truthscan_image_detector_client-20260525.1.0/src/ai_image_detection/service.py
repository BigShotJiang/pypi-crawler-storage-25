import os
import time
import requests
import mimetypes
from urllib.parse import urlparse
from typing import Dict, Optional, Any, Callable

from .logger import Logger, DefaultConsoleLogger
from .errors import PresignError, UploadError, DetectError, QueryError, CreditCheckError
from .api_types import PresignResponse, DetectResponse, QueryResponse, CreditCheckResponse

class ImageDetectionService:
    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: int = 60,
        logger: Optional[Logger] = None
    ) -> None:
        """
        Initialize the API client interface.
        
        Args:
            base_url: Base URL of the API server
            api_key: API key for authentication
            timeout: Default timeout for requests in seconds (default: 60)
            logger: Logger instance (optional, default: DefaultConsoleLogger("info"))
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout  # Timeout in seconds for requests library
        self.logger = logger if logger is not None else DefaultConsoleLogger("info")
    
    @staticmethod
    def guess_mime_type(file_name: str) -> str:
        """
        Guess MIME type from file name.
        
        Args:
            file_name: Name of the file
            
        Returns:
            MIME type string
        """
        mime, _ = mimetypes.guess_type(file_name)
        if mime:
            return mime
        
        ext = os.path.splitext(file_name)[1].lower().lstrip('.')
        mime_map = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'jfif': 'image/jpeg',
            'png': 'image/png',
            'webp': 'image/webp',
            'heic': 'image/heic',
            'heif': 'image/heif',
            'avif': 'image/avif',
            'bmp': 'image/bmp',
            'tiff': 'image/tiff',
            'tif': 'image/tiff',
            'svg': 'image/svg+xml',
            'gif': 'image/gif',
            'pdf': 'application/pdf',
        }
        return mime_map.get(ext, "application/octet-stream")
    
    def get_presigned_url(self, file_name: str) -> PresignResponse:
        """
        Get a presigned URL for file upload.
        
        Args:
            file_name: Name of the file to upload
            
        Returns:
            PresignResponse containing presigned_url and file_path
            
        Raises:
            PresignError: If the presign operation fails
        """
        self.logger.info(f"Requesting presigned URL for file: {file_name}")
        
        try:
            url = f"{self.base_url}/get-presigned-url"
            response = requests.get(
                url,
                headers={'apikey': self.api_key},
                params={'file_name': file_name},
                timeout=self.timeout,
            )
            
            self.logger.debug(f"Presign response status: {response.status_code}")
            
            if not response.ok:
                error_msg = f"Presign failed with status {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_msg)
                except Exception:
                    error_msg = f"{error_msg}: {response.text}"
                
                self.logger.error(error_msg)
                raise PresignError(error_msg)
            
            result = response.json()
            
            if "presigned_url" not in result or "file_path" not in result:
                error_msg = "Invalid presign response: missing required fields"
                self.logger.error(error_msg)
                raise PresignError(error_msg)
            
            self.logger.info(f"Presigned URL obtained successfully for {file_name}")
            return result
            
        except PresignError:
            raise
        except requests.exceptions.RequestException as e:
            error_msg = f"Network error during presign: {str(e)}"
            self.logger.error(error_msg)
            raise PresignError(error_msg) from e
        except Exception as e:
            error_msg = f"Unexpected error during presign: {str(e)}"
            self.logger.error(error_msg)
            raise PresignError(error_msg) from e
    
    def upload(
        self,
        presigned_url: str,
        file_path: str,
        mime_type: Optional[str] = None
    ) -> bool:
        """
        Upload a file to the presigned URL.
        
        Args:
            presigned_url: Presigned URL obtained from get_presigned_url() method
            file_path: Local path to the file to upload
            mime_type: MIME type of the file (auto-detected if not provided)
            
        Returns:
            True if upload was successful
            
        Raises:
            UploadError: If the upload operation fails
        """
        if not os.path.exists(file_path):
            error_msg = f"File not found: {file_path}"
            self.logger.error(error_msg)
            raise UploadError(error_msg)
        
        if mime_type is None:
            mime_type = ImageDetectionService.guess_mime_type(file_path)
        
        self.logger.info(f"Uploading file {file_path} (MIME type: {mime_type})")
        
        try:
            file_stats = os.stat(file_path)
            file_size = file_stats.st_size
            
            with open(file_path, "rb") as f:
                response = requests.put(
                    presigned_url,
                    headers={
                        'Content-Type': mime_type,
                        'x-amz-acl': 'private',
                        'Content-Length': str(file_size),
                    },
                    data=f,
                    timeout=300,  # 5 minutes for file uploads
                )
            
            self.logger.debug(f"Upload response status: {response.status_code}")
            
            if response.status_code not in (200, 204):
                error_msg = f"Upload failed with status {response.status_code}"
                self.logger.error(error_msg)
                raise UploadError(error_msg)
            
            self.logger.info(f"File uploaded successfully: {file_path}")
            return True
            
        except UploadError:
            raise
        except requests.exceptions.RequestException as e:
            error_msg = f"Network error during upload: {str(e)}"
            self.logger.error(error_msg)
            raise UploadError(error_msg) from e
        except Exception as e:
            error_msg = f"Unexpected error during upload: {str(e)}"
            self.logger.error(error_msg)
            raise UploadError(error_msg) from e
    
    def detect(
        self,
        file_url: str,
        email: Optional[str] = None,
        generate_preview: bool = False
    ) -> DetectResponse:
        """
        Submit an image for AI detection.
        
        Args:
            file_url: URL of the uploaded file
            email: Optional email address for processing
            generate_preview: Optional flag to generate preview (default: False)
            
        Returns:
            DetectResponse containing detection ID and status
            
        Raises:
            DetectError: If the detect operation fails
        """
        self.logger.info(f"Submitting detect request for URL: {file_url}")
        
        payload: Dict[str, Any] = {
            "key": self.api_key,
            "url": file_url,
            "document_type": "Image",
            "model": "generic",
            "generate_preview": generate_preview,
        }
        
        if email:
            payload["email"] = email
        
        try:
            response = requests.post(
                f"{self.base_url}/detect",
                headers={'Content-Type': 'application/json'},
                json=payload,
                timeout=120,  # 2 minutes for detect requests
            )
            
            self.logger.debug(f"Detect response status: {response.status_code}")
            
            if not response.ok:
                error_msg = f"Detect failed with status {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_msg)
                except Exception:
                    error_msg = f"{error_msg}: {response.text}"
                
                self.logger.error(error_msg)
                raise DetectError(error_msg)
            
            result = response.json()
            
            if "id" not in result:
                error_msg = "Invalid detect response: missing detection ID"
                self.logger.error(error_msg)
                raise DetectError(error_msg)
            
            detect_id = result.get("id")
            self.logger.info(f"Detect request submitted successfully. ID: {detect_id}")
            return result
            
        except DetectError:
            raise
        except Exception as e:
            if isinstance(e, DetectError):
                raise
            
            error_msg = (
                f"Network error during detect: {str(e)}"
                if hasattr(e, 'message') and e.message
                else f"Unexpected error during detect: {str(e)}"
            )
            self.logger.error(error_msg)
            raise DetectError(error_msg) from e
    
    def query(self, detect_id: str) -> QueryResponse:
        """
        Query the detection status and results.
        
        Args:
            detect_id: Detection ID returned from detect() method
            
        Returns:
            QueryResponse containing detection status and results
            
        Raises:
            QueryError: If the query operation fails
        """
        self.logger.debug(f"Querying detection status for ID: {detect_id}")
        
        try:
            response = requests.post(
                f"{self.base_url}/query",
                headers={'Content-Type': 'application/json'},
                json={'id': detect_id},
                timeout=self.timeout,
            )
            
            self.logger.debug(f"Query response status: {response.status_code}")
            
            if not response.ok:
                error_msg = f"Query failed with status {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_msg)
                except Exception:
                    error_msg = f"{error_msg}: {response.text}"
                
                self.logger.error(error_msg)
                raise QueryError(error_msg)
            
            response_text = response.text
            if response_text.strip() == "null" or not response_text.strip():
                self.logger.warn(f"Document not found for ID: {detect_id}")
                return {"id": detect_id, "status": "not_found"}
            
            result = response.json()
            
            if result is None:
                self.logger.warn(f"Document not found for ID: {detect_id}")
                return {"id": detect_id, "status": "not_found"}
            
            status = result.get("status", "unknown")
            self.logger.debug(f"Query result status: {status}")
            return result
            
        except QueryError:
            raise
        except requests.exceptions.RequestException as e:
            error_msg = f"Network error during query: {str(e)}"
            self.logger.error(error_msg)
            raise QueryError(error_msg) from e
        except Exception as e:
            error_msg = f"Unexpected error during query: {str(e)}"
            self.logger.error(error_msg)
            raise QueryError(error_msg) from e
    
    def poll_for_result(
        self,
        detect_id: str,
        max_attempts: int = 60,
        sleep_seconds: float = 0.5,
        callback: Optional[Callable[[int, QueryResponse], None]] = None
    ) -> Optional[QueryResponse]:
        """
        Poll for detection results until completion.
        
        Continues polling until status is "done" or "failed"
        or until max_attempts is reached.
        
        Args:
            detect_id: Detection ID returned from detect() method
            max_attempts: Maximum number of polling attempts (default: 60)
            sleep_seconds: Seconds to sleep between attempts (default: 0.5)
            callback: Optional callback function called on each attempt
            
        Returns:
            Final result if status reached completion, None if timeout
        """
        self.logger.info(f"Starting to poll for detection ID: {detect_id}")
        
        final_result: Optional[QueryResponse] = None
        
        for attempt_idx in range(1, max_attempts + 1):
            try:
                result = self.query(detect_id)
                
                if callback:
                    try:
                        callback(attempt_idx, result)
                    except Exception as e:
                        self.logger.warn(f"Callback error: {e}")
                
                status = result.get("status", "unknown")
                
                if status == "done" or status == "failed":
                    final_result = result
                    self.logger.info(
                        f"Polling completed. Status: {status} "
                        f"(attempt {attempt_idx}/{max_attempts})"
                    )
                    break
                
                if attempt_idx < max_attempts:
                    time.sleep(sleep_seconds)
                    
            except QueryError as e:
                self.logger.warn(f"Query error on attempt {attempt_idx}: {e}")
                time.sleep(sleep_seconds)
                continue
            except Exception as e:
                self.logger.warn(
                    f"Unexpected error on attempt {attempt_idx}: "
                    f"{str(e) if hasattr(e, '__str__') else 'Unknown error'}"
                )
                time.sleep(sleep_seconds)
                continue
        
        if final_result is None:
            self.logger.warn(
                f"Polling timeout reached for detection ID: {detect_id} "
                f"(max attempts: {max_attempts})"
            )
        
        return final_result
    
    def check_user_credits(self) -> CreditCheckResponse:
        """
        Check user credits for the API key.
        
        Returns:
            CreditCheckResponse containing credit information
            
        Raises:
            CreditCheckError: If the credit check operation fails
        """
        self.logger.info(f"Requesting credit check for API key: {self.api_key}")
        
        try:
            response = requests.get(
                f"{self.base_url}/check-user-credits",
                headers={'apikey': self.api_key},
                timeout=self.timeout,
            )
            
            self.logger.debug(f"Credit check response status: {response.status_code}")
            
            if not response.ok:
                error_msg = f"Credit check failed with status {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_msg)
                except Exception:
                    error_msg = f"{error_msg}: {response.text}"
                
                self.logger.error(error_msg)
                raise CreditCheckError(error_msg)
            
            result = response.json()
            
            # Check if response has required fields
            if not result or not isinstance(result, dict):
                error_msg = (
                    f"Invalid credit check response: unexpected response format. "
                    f"Response: {result}"
                )
                self.logger.error(error_msg)
                raise CreditCheckError(error_msg)
            
            # Check for required fields (allow 0 values but not undefined/null)
            if (
                result.get("baseCredits") is None
                or result.get("boostCredits") is None
                or result.get("credits") is None
            ):
                error_msg = (
                    f"Invalid credit check response: missing required fields. "
                    f"Response: {result}"
                )
                self.logger.error(error_msg)
                raise CreditCheckError(error_msg)
            
            self.logger.info("Credit check obtained successfully")
            return result
            
        except CreditCheckError:
            raise
        except requests.exceptions.RequestException as e:
            error_msg = f"Network error during credit check: {str(e)}"
            self.logger.error(error_msg)
            raise CreditCheckError(error_msg) from e
        except Exception as e:
            error_msg = f"Unexpected error during credit check: {str(e)}"
            self.logger.error(error_msg)
            raise CreditCheckError(error_msg) from e
    
    @staticmethod
    def build_detect_file_url(
        file_path_remote: str,
        presigned_url: str
    ) -> str:
        """
        Build the full file URL for detect operation.
        
        If file_path_remote is already a full URL, returns it as-is.
        Otherwise, constructs URL from presigned URL origin.
        
        Args:
            file_path_remote: Remote file path or full URL
            presigned_url: Presigned URL to extract origin from
            
        Returns:
            Full URL to the file
        """
        if file_path_remote.startswith("http://") or file_path_remote.startswith("https://"):
            return file_path_remote
        
        parsed = urlparse(presigned_url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        return f"{origin}/{file_path_remote.lstrip('/')}"
