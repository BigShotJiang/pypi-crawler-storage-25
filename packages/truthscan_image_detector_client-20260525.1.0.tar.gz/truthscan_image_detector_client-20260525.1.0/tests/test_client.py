import os
import sys
import json
import time
from pathlib import Path
from typing import List, Dict, Optional, Any

from ai_image_detection import ImageDetectionClient

def log(message: str) -> None:
    """Log a message with timestamp."""
    timestamp = time.strftime('%H:%M:%S')
    print(f"[{timestamp}] {message}")


def discover_image_files(
    folder: str,
    allowed_exts: set,
    min_bytes: int,
    max_bytes: int
) -> List[str]:
    """
    Discover image files in the specified folder.
    
    Args:
        folder: Folder path to search
        allowed_exts: Set of allowed file extensions
        min_bytes: Minimum file size in bytes
        max_bytes: Maximum file size in bytes
        
    Returns:
        List of image file names
    """
    files: List[str] = []
    
    if not os.path.exists(folder):
        return files
    
    entries = os.listdir(folder)
    
    for entry in entries:
        entry_path = os.path.join(folder, entry)
        
        try:
            stats = os.stat(entry_path)
            if os.path.isdir(entry_path):
                continue
        except Exception:
            continue
        
        ext = os.path.splitext(entry)[1].lower()
        if ext not in allowed_exts:
            continue
        
        try:
            file_size = stats.st_size
            if file_size < min_bytes or file_size > max_bytes:
                continue
        except Exception:
            continue
        
        files.append(entry)
    
    return files


def process_file(
    client: ImageDetectionClient,
    folder: str,
    file_name: str
) -> Dict[str, Any]:
    """
    Process a single image file through the complete workflow.
    
    Args:
        client: ImageDetectionClient instance
        folder: Folder containing the image
        file_name: Name of the image file
        
    Returns:
        Dictionary containing processing results and timing information
    """
    log(f"Processing file: {file_name}")
    
    file_start_time = time.time()
    full_path = os.path.join(folder, file_name)
    
    result_data: Dict[str, Any] = {
        "filename": file_name,
        "detect_id": None,
        "status": "error",
        "error_message": None,
        "query_result": None,
        "total_time": 0,
    }
    
    try:
        log(f"Starting detection for {file_name}...")
        final_result = client.detect(full_path)
        
        result_data["total_time"] = time.time() - file_start_time
        result_data["detect_id"] = final_result.get("id")
        result_data["query_result"] = final_result
        result_data["status"] = final_result.get("status", "unknown")
        
        status = final_result.get("status")
        result_value = final_result.get("result")
        log(f"Detection completed. Status: {status}, Result: {result_value}")
        log(f"Total time: {result_data['total_time']:.3f}s")
        
        return result_data
    except Exception as e:
        result_data["total_time"] = time.time() - file_start_time
        if e is not None:
            result_data["error_message"] = f"Query error: {str(e)}"
            result_data["status"] = "query_error"
        else:
            result_data["error_message"] = f"Error: {str(e)}"
            result_data["status"] = "error"
        log(f"Error: {result_data['error_message']}")
        return result_data


def print_summary(results: List[Dict[str, Any]]) -> None:
    """Print a summary of all processing results."""
    print("\n" + "=" * 70)
    print("  PROCESSING SUMMARY")
    print("=" * 70)
    
    total_files = len(results)
    successful_submissions = sum(1 for r in results if r.get("detect_id"))
    errors = sum(1 for r in results if r.get("status") == "error")
    completed = sum(1 for r in results if r.get("status") in ("done", "failed"))
    pending = sum(1 for r in results if r.get("status") in ("submitted", "pending"))
    
    print(f"\nTotal files processed: {total_files}")
    print(f"Successful submissions: {successful_submissions}")
    print(f"Errors: {errors}")
    print(f"Completed (done/failed): {completed}")
    print(f"Pending/Submitted: {pending}")
    
    if successful_submissions > 0:
        total_processing_time = sum(r.get("total_time", 0) for r in results)
        
        print("\n" + "-" * 70)
        print("Timing Statistics:")
        print(f"  Average total time: {(total_processing_time / successful_submissions):.3f}s")
    
    failed_files = [r for r in results if r.get("status") == "error" or r.get("error_message")]
    if failed_files:
        print("\n" + "-" * 70)
        print("Failed Files:")
        for result in failed_files:
            filename = result.get("filename", "unknown")
            error = result.get("error_message", "Unknown error")
            print(f"  - {filename}: {error}")
    
    print("\n" + "=" * 70)


def main() -> None:
    """Main test function."""
    print("\n" + "=" * 70)
    print("  Image Detection Client Test Script - Batch Processing")
    print("=" * 70)
    
    # For local testing
    # BASE_URL = 'http://localhost:8000'
    
    # For development
    # BASE_URL = 'https://ai-image-detector-dev-api-server-zo6e9.ondigitalocean.app'
    
    # For production
    BASE_URL = 'https://ai-image-detect.undetectable.ai'
    
    API_KEY = "<YOUR API KEY>"
    
    # Folder path
    FOLDER = "./test_images/"
    
    # Allow folder path as command line argument
    if len(sys.argv) > 1:
        folder_arg = sys.argv[1]
        try:
            stats = os.stat(folder_arg)
            if os.path.isdir(folder_arg):
                FOLDER = folder_arg
            elif os.path.isfile(folder_arg):
                FOLDER = os.path.dirname(folder_arg)
            else:
                print(f"Invalid path: {folder_arg}")
                sys.exit(1)
        except Exception:
            print(f"Invalid path: {folder_arg}")
            sys.exit(1)
    
    ALLOWED_EXTS = {
        '.jpg',
        '.jpeg',
        '.png',
        '.bmp',
        '.tiff',
        '.webp',
        '.heic',
        '.heif',
        '.avif',
        '.jfif',
        '.tif',
        '.svg',
        '.gif',
    }
    MIN_BYTES = 1 * 1024
    MAX_BYTES = 10 * 1024 * 1024
    
    log('Initializing ImageDetectionClient...')
    client = ImageDetectionClient(API_KEY, BASE_URL)
    
    initial_credits = None
    try:
        log('Checking initial credits...')
        initial_credits = client.check_user_credits()
        log(
            f"Initial credits - Base: {initial_credits['baseCredits']}, "
            f"Boost: {initial_credits['boostCredits']}, "
            f"Total: {initial_credits['credits']}"
        )
    except Exception as e:
        if e is not None:
            log(f"Warning: Could not check initial credits: {str(e)}")
        else:
            log(f"Warning: Could not check initial credits: {str(e)}")
    
    log(f"\nSearching for image files in: {FOLDER}")
    if not os.path.exists(FOLDER):
        print(f"Folder not found: {FOLDER}")
        print('\nUsage:')
        print('  python test_api_client.py [folder_path]')
        sys.exit(1)
    
    files = discover_image_files(FOLDER, ALLOWED_EXTS, MIN_BYTES, MAX_BYTES)
    
    if len(files) == 0:
        print(f"No valid image files found in: {FOLDER}")
        print(f"\nAllowed extensions: {', '.join(sorted(ALLOWED_EXTS))}")
        print(f"File size limits: {MIN_BYTES} bytes - {MAX_BYTES} bytes")
        sys.exit(1)
    
    log(f"Found {len(files)} files to process")
    
    results: List[Dict[str, Any]] = []
    
    for file_name in files:
        result = process_file(client, FOLDER, file_name)
        results.append(result)
        print()  # Empty line between files
    
    print_summary(results)
    
    final_credits = None
    try:
        log('\nChecking final credits...')
        final_credits = client.check_user_credits()
        log(
            f"Final credits - Base: {final_credits['baseCredits']}, "
            f"Boost: {final_credits['boostCredits']}, "
            f"Total: {final_credits['credits']}"
        )
        
        if initial_credits and final_credits:
            credits_charged = initial_credits['credits'] - final_credits['credits']
            print('\n' + '-' * 70)
            print('CREDIT USAGE SUMMARY')
            print('-' * 70)
            print(f"Initial Credits: {initial_credits['credits']}")
            print(f"Final Credits: {final_credits['credits']}")
            print(f"Credits Used: {credits_charged}")
            print('-' * 70)
    except Exception as e:
        if e is not None:
            log(f"Warning: Could not check final credits: {str(e)}")
        else:
            log(f"Warning: Could not check final credits: {str(e)}")
    
    output_file = 'api_client_test_results.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    log(f"\nResults saved to: {output_file}")
    
    print('\n' + '=' * 70)
    print('  All processing completed!')
    print('=' * 70)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n Processing interrupted by user")
        sys.exit(1)
    except Exception as error:
        print(f"\n Unexpected error: {error}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
