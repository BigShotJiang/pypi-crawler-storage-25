"""Test suite for pydmdeeg."""
