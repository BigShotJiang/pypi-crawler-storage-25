from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.import_status_kind import ImportStatusKind
from ..models.import_step import ImportStep
from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="ImportStatus")


@_attrs_define
class ImportStatus:
    """Status response for an import.

    Attributes:
        created_at (str): When the import was requested.
        status (ImportStatusKind): High-level status of an import.
        step (ImportStep): Current pipeline step of an import.
        error (None | str | Unset):
        partition_count (int | None | Unset): Number of partitions created (populated after import).
    """

    created_at: str
    status: ImportStatusKind
    step: ImportStep
    error: None | str | Unset = UNSET
    partition_count: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        created_at = self.created_at

        status = self.status.value

        step = self.step.value

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        partition_count: int | None | Unset
        if isinstance(self.partition_count, Unset):
            partition_count = UNSET
        else:
            partition_count = self.partition_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_at": created_at,
                "status": status,
                "step": step,
            }
        )
        if error is not UNSET:
            field_dict["error"] = error
        if partition_count is not UNSET:
            field_dict["partition_count"] = partition_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        created_at = d.pop("created_at")

        status = ImportStatusKind(d.pop("status"))

        step = ImportStep(d.pop("step"))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_partition_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        partition_count = _parse_partition_count(d.pop("partition_count", UNSET))

        import_status = cls(
            created_at=created_at,
            status=status,
            step=step,
            error=error,
            partition_count=partition_count,
        )

        import_status.additional_properties = d
        return import_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
