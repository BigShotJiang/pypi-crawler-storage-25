from enum import Enum


class ImportStep(str, Enum):
    COMMITTED = "committed"
    DOWNLOADING = "downloading"
    FAILED = "failed"
    IMPORTING_PARTITIONS = "importing_partitions"
    PARTITIONING = "partitioning"
    QUEUED = "queued"

    def __str__(self) -> str:
        return str(self.value)
