from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.s3_auth_type_0 import S3AuthType0
    from ..models.s3_auth_type_1 import S3AuthType1
    from ..models.s3_endpoint import S3Endpoint


T = TypeVar("T", bound="S3BucketAccess")


@_attrs_define
class S3BucketAccess:
    """
    Attributes:
        auth (S3AuthType0 | S3AuthType1): How a Dagger client should authenticate when accessing an object space
            stored in S3.
        bucket (str):
        endpoint (S3Endpoint):
        prefix (str): Prefix of accessible objects in [`Self::bucket`].

            [`Self::auth`] SHOULD only allow access to object paths matching `$prefix/*`.
        region (str):
    """

    auth: S3AuthType0 | S3AuthType1
    bucket: str
    endpoint: S3Endpoint
    prefix: str
    region: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.s3_auth_type_0 import S3AuthType0
        from ..models.s3_auth_type_1 import S3AuthType1
        from ..models.s3_endpoint import S3Endpoint

        auth: dict[str, Any]
        if isinstance(self.auth, S3AuthType0):
            auth = self.auth.to_dict()
        else:
            auth = self.auth.to_dict()

        bucket = self.bucket

        endpoint = self.endpoint.to_dict()

        prefix = self.prefix

        region = self.region

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "auth": auth,
                "bucket": bucket,
                "endpoint": endpoint,
                "prefix": prefix,
                "region": region,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.s3_auth_type_0 import S3AuthType0
        from ..models.s3_auth_type_1 import S3AuthType1
        from ..models.s3_endpoint import S3Endpoint

        d = dict(src_dict)

        def _parse_auth(data: object) -> S3AuthType0 | S3AuthType1:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_s3_auth_type_0 = S3AuthType0.from_dict(data)

                return componentsschemas_s3_auth_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_s3_auth_type_1 = S3AuthType1.from_dict(data)

            return componentsschemas_s3_auth_type_1

        auth = _parse_auth(d.pop("auth"))

        bucket = d.pop("bucket")

        endpoint = S3Endpoint.from_dict(d.pop("endpoint"))

        prefix = d.pop("prefix")

        region = d.pop("region")

        s3_bucket_access = cls(
            auth=auth,
            bucket=bucket,
            endpoint=endpoint,
            prefix=prefix,
            region=region,
        )

        s3_bucket_access.additional_properties = d
        return s3_bucket_access

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
