from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="CurrentFormatVersions")


@_attrs_define
class CurrentFormatVersions:
    """The *current* format version for each model type.

    This is the only version that can be used for model creation.

        Attributes:
            linear_bvh (int):
            pop_trimesh (int):
    """

    linear_bvh: int
    pop_trimesh: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        linear_bvh = self.linear_bvh

        pop_trimesh = self.pop_trimesh

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "linear_bvh": linear_bvh,
                "pop_trimesh": pop_trimesh,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        linear_bvh = d.pop("linear_bvh")

        pop_trimesh = d.pop("pop_trimesh")

        current_format_versions = cls(
            linear_bvh=linear_bvh,
            pop_trimesh=pop_trimesh,
        )

        current_format_versions.additional_properties = d
        return current_format_versions

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
