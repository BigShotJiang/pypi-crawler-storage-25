from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset


T = TypeVar("T", bound="ObjectSpaceAccessType2")


@_attrs_define
class ObjectSpaceAccessType2:
    """This is here to allow successful deserialization on old clients even
    when new variants are added to this enum.

    Rather than raising a deserialization error from the client, we can
    raise a more appropriate "unsupported variant" error.

        Attributes:
            unknown (Any): This is here to allow successful deserialization on old clients even
                when new variants are added to this enum.

                Rather than raising a deserialization error from the client, we can
                raise a more appropriate "unsupported variant" error.
    """

    unknown: Any
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        unknown = self.unknown

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "Unknown": unknown,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        unknown = d.pop("Unknown")

        object_space_access_type_2 = cls(
            unknown=unknown,
        )

        object_space_access_type_2.additional_properties = d
        return object_space_access_type_2

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
