from enum import Enum


class FseAttributeTypeType1(str, Enum):
    STRING = "String"

    def __str__(self) -> str:
        return str(self.value)
