from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.real_measurement import RealMeasurement


T = TypeVar("T", bound="FseAttributeTypeType0")


@_attrs_define
class FseAttributeTypeType0:
    """
    Attributes:
        real (RealMeasurement): How a real quantity is measured with respect to the geometry.

            This affects how CSG operates on these attributes.
    """

    real: RealMeasurement
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        real = self.real.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "Real": real,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        real = RealMeasurement(d.pop("Real"))

        fse_attribute_type_type_0 = cls(
            real=real,
        )

        fse_attribute_type_type_0.additional_properties = d
        return fse_attribute_type_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
