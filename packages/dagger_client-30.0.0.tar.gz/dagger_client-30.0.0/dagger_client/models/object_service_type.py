from enum import Enum


class ObjectServiceType(str, Enum):
    AZUREBLOB = "AzureBlob"
    S3 = "S3"

    def __str__(self) -> str:
        return str(self.value)
