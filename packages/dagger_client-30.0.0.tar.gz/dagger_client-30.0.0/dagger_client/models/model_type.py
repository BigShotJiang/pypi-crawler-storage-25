from enum import Enum


class ModelType(str, Enum):
    BALLCLOUD = "BallCloud"
    BLOCKMODEL = "BlockModel"
    POINTCLOUD = "PointCloud"
    POPTRIMESH = "PopTriMesh"

    def __str__(self) -> str:
        return str(self.value)
