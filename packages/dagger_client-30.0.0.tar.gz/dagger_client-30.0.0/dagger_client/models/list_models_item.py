from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.model_type import ModelType
from uuid import UUID


T = TypeVar("T", bound="ListModelsItem")


@_attrs_define
class ListModelsItem:
    """List item returned from `GET /models`.

    Attributes:
        guid (UUID):
        model_type (ModelType): Enumerate all model types supported by Dagger.
        newest_format (int):
        object_service (UUID):
        object_space (UUID):
        tenant (UUID):
    """

    guid: UUID
    model_type: ModelType
    newest_format: int
    object_service: UUID
    object_space: UUID
    tenant: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        guid = str(self.guid)

        model_type = self.model_type.value

        newest_format = self.newest_format

        object_service = str(self.object_service)

        object_space = str(self.object_space)

        tenant = str(self.tenant)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "guid": guid,
                "model_type": model_type,
                "newest_format": newest_format,
                "object_service": object_service,
                "object_space": object_space,
                "tenant": tenant,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        guid = UUID(d.pop("guid"))

        model_type = ModelType(d.pop("model_type"))

        newest_format = d.pop("newest_format")

        object_service = UUID(d.pop("object_service"))

        object_space = UUID(d.pop("object_space"))

        tenant = UUID(d.pop("tenant"))

        list_models_item = cls(
            guid=guid,
            model_type=model_type,
            newest_format=newest_format,
            object_service=object_service,
            object_space=object_space,
            tenant=tenant,
        )

        list_models_item.additional_properties = d
        return list_models_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
