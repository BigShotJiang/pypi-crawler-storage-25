from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.fse_attribute_type_type_1 import FseAttributeTypeType1
from ..models.fse_attribute_type_type_2 import FseAttributeTypeType2
from ..models.fse_attribute_type_type_3 import FseAttributeTypeType3
from ..models.fse_attribute_type_type_4 import FseAttributeTypeType4
from ..models.fse_attribute_type_type_5 import FseAttributeTypeType5
from typing import cast

if TYPE_CHECKING:
    from ..models.fse_attribute_type_type_0 import FseAttributeTypeType0


T = TypeVar("T", bound="FseHeader")


@_attrs_define
class FseHeader:
    """Attribute header used by the Foresight Solids Engine.

    Attributes:
        name (str):
        ty (FseAttributeTypeType0 | FseAttributeTypeType1 | FseAttributeTypeType2 | FseAttributeTypeType3 |
            FseAttributeTypeType4 | FseAttributeTypeType5): Attribute type used by the Foresight Solids Engine.

            The set of attribute types used by FSE
    """

    name: str
    ty: (
        FseAttributeTypeType0
        | FseAttributeTypeType1
        | FseAttributeTypeType2
        | FseAttributeTypeType3
        | FseAttributeTypeType4
        | FseAttributeTypeType5
    )
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.fse_attribute_type_type_0 import FseAttributeTypeType0

        name = self.name

        ty: dict[str, Any] | str
        if isinstance(self.ty, FseAttributeTypeType0):
            ty = self.ty.to_dict()
        elif isinstance(self.ty, FseAttributeTypeType1):
            ty = self.ty.value
        elif isinstance(self.ty, FseAttributeTypeType2):
            ty = self.ty.value
        elif isinstance(self.ty, FseAttributeTypeType3):
            ty = self.ty.value
        elif isinstance(self.ty, FseAttributeTypeType4):
            ty = self.ty.value
        else:
            ty = self.ty.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "ty": ty,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.fse_attribute_type_type_0 import FseAttributeTypeType0

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_ty(
            data: object,
        ) -> (
            FseAttributeTypeType0
            | FseAttributeTypeType1
            | FseAttributeTypeType2
            | FseAttributeTypeType3
            | FseAttributeTypeType4
            | FseAttributeTypeType5
        ):
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_fse_attribute_type_type_0 = FseAttributeTypeType0.from_dict(data)

                return componentsschemas_fse_attribute_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, str):
                    raise TypeError()
                componentsschemas_fse_attribute_type_type_1 = FseAttributeTypeType1(data)

                return componentsschemas_fse_attribute_type_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, str):
                    raise TypeError()
                componentsschemas_fse_attribute_type_type_2 = FseAttributeTypeType2(data)

                return componentsschemas_fse_attribute_type_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, str):
                    raise TypeError()
                componentsschemas_fse_attribute_type_type_3 = FseAttributeTypeType3(data)

                return componentsschemas_fse_attribute_type_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, str):
                    raise TypeError()
                componentsschemas_fse_attribute_type_type_4 = FseAttributeTypeType4(data)

                return componentsschemas_fse_attribute_type_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, str):
                raise TypeError()
            componentsschemas_fse_attribute_type_type_5 = FseAttributeTypeType5(data)

            return componentsschemas_fse_attribute_type_type_5

        ty = _parse_ty(d.pop("ty"))

        fse_header = cls(
            name=name,
            ty=ty,
        )

        fse_header.additional_properties = d
        return fse_header

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
