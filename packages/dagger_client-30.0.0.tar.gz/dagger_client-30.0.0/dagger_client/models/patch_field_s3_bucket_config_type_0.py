from enum import Enum


class PatchFieldS3BucketConfigType0(str, Enum):
    NOCHANGE = "NoChange"

    def __str__(self) -> str:
        return str(self.value)
