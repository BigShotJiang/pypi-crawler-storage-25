from enum import Enum


class GeometryType(str, Enum):
    AABB = "Aabb"
    BALL = "Ball"
    POINT = "Point"

    def __str__(self) -> str:
        return str(self.value)
