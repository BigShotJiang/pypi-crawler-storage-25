from enum import Enum


class FseAttributeTypeType2(str, Enum):
    RGB = "Rgb"

    def __str__(self) -> str:
        return str(self.value)
