from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.patch_field_s3_bucket_config_type_0 import PatchFieldS3BucketConfigType0
from ..models.patch_field_s3_bucket_config_type_2 import PatchFieldS3BucketConfigType2
from typing import cast

if TYPE_CHECKING:
    from ..models.patch_field_s3_bucket_config_type_1 import PatchFieldS3BucketConfigType1


T = TypeVar("T", bound="TenantConfigPatch")


@_attrs_define
class TenantConfigPatch:
    """Patch type for [`TenantConfig`] using JSON merge patch semantics.

    Attributes:
        s3 (PatchFieldS3BucketConfigType0 | PatchFieldS3BucketConfigType1 | PatchFieldS3BucketConfigType2): Patch
            operation: NoChange, Put(value), or Delete.
    """

    s3: PatchFieldS3BucketConfigType0 | PatchFieldS3BucketConfigType1 | PatchFieldS3BucketConfigType2
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.patch_field_s3_bucket_config_type_1 import PatchFieldS3BucketConfigType1

        s3: dict[str, Any] | str
        if isinstance(self.s3, PatchFieldS3BucketConfigType0):
            s3 = self.s3.value
        elif isinstance(self.s3, PatchFieldS3BucketConfigType1):
            s3 = self.s3.to_dict()
        else:
            s3 = self.s3.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "s3": s3,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.patch_field_s3_bucket_config_type_1 import PatchFieldS3BucketConfigType1

        d = dict(src_dict)

        def _parse_s3(
            data: object,
        ) -> PatchFieldS3BucketConfigType0 | PatchFieldS3BucketConfigType1 | PatchFieldS3BucketConfigType2:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                componentsschemas_patch_field_s3_bucket_config_type_0 = PatchFieldS3BucketConfigType0(data)

                return componentsschemas_patch_field_s3_bucket_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_patch_field_s3_bucket_config_type_1 = PatchFieldS3BucketConfigType1.from_dict(data)

                return componentsschemas_patch_field_s3_bucket_config_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, str):
                raise TypeError()
            componentsschemas_patch_field_s3_bucket_config_type_2 = PatchFieldS3BucketConfigType2(data)

            return componentsschemas_patch_field_s3_bucket_config_type_2

        s3 = _parse_s3(d.pop("s3"))

        tenant_config_patch = cls(
            s3=s3,
        )

        tenant_config_patch.additional_properties = d
        return tenant_config_patch

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
