from enum import Enum


class FseAttributeTypeType5(str, Enum):
    BOOL = "Bool"

    def __str__(self) -> str:
        return str(self.value)
