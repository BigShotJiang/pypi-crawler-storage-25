from enum import Enum


class SamplerType(str, Enum):
    AND = "And"
    MAX = "Max"
    MEAN = "Mean"
    MIN = "Min"
    MODE = "Mode"
    OR = "Or"

    def __str__(self) -> str:
        return str(self.value)
