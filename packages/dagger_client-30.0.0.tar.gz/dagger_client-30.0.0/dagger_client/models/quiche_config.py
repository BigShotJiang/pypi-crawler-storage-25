from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="QuicheConfig")


@_attrs_define
class QuicheConfig:
    """Quiche partitioning configuration.

    Attributes:
        max_buckets (int | None | Unset):
        partition_max_leaves (int | None | Unset):
        rows_per_batch (int | None | Unset):
        rows_per_bucket (int | None | Unset):
        target_partition_fill (float | None | Unset):
    """

    max_buckets: int | None | Unset = UNSET
    partition_max_leaves: int | None | Unset = UNSET
    rows_per_batch: int | None | Unset = UNSET
    rows_per_bucket: int | None | Unset = UNSET
    target_partition_fill: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        max_buckets: int | None | Unset
        if isinstance(self.max_buckets, Unset):
            max_buckets = UNSET
        else:
            max_buckets = self.max_buckets

        partition_max_leaves: int | None | Unset
        if isinstance(self.partition_max_leaves, Unset):
            partition_max_leaves = UNSET
        else:
            partition_max_leaves = self.partition_max_leaves

        rows_per_batch: int | None | Unset
        if isinstance(self.rows_per_batch, Unset):
            rows_per_batch = UNSET
        else:
            rows_per_batch = self.rows_per_batch

        rows_per_bucket: int | None | Unset
        if isinstance(self.rows_per_bucket, Unset):
            rows_per_bucket = UNSET
        else:
            rows_per_bucket = self.rows_per_bucket

        target_partition_fill: float | None | Unset
        if isinstance(self.target_partition_fill, Unset):
            target_partition_fill = UNSET
        else:
            target_partition_fill = self.target_partition_fill

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if max_buckets is not UNSET:
            field_dict["max_buckets"] = max_buckets
        if partition_max_leaves is not UNSET:
            field_dict["partition_max_leaves"] = partition_max_leaves
        if rows_per_batch is not UNSET:
            field_dict["rows_per_batch"] = rows_per_batch
        if rows_per_bucket is not UNSET:
            field_dict["rows_per_bucket"] = rows_per_bucket
        if target_partition_fill is not UNSET:
            field_dict["target_partition_fill"] = target_partition_fill

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_max_buckets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_buckets = _parse_max_buckets(d.pop("max_buckets", UNSET))

        def _parse_partition_max_leaves(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        partition_max_leaves = _parse_partition_max_leaves(d.pop("partition_max_leaves", UNSET))

        def _parse_rows_per_batch(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        rows_per_batch = _parse_rows_per_batch(d.pop("rows_per_batch", UNSET))

        def _parse_rows_per_bucket(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        rows_per_bucket = _parse_rows_per_bucket(d.pop("rows_per_bucket", UNSET))

        def _parse_target_partition_fill(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        target_partition_fill = _parse_target_partition_fill(d.pop("target_partition_fill", UNSET))

        quiche_config = cls(
            max_buckets=max_buckets,
            partition_max_leaves=partition_max_leaves,
            rows_per_batch=rows_per_batch,
            rows_per_bucket=rows_per_bucket,
            target_partition_fill=target_partition_fill,
        )

        quiche_config.additional_properties = d
        return quiche_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
