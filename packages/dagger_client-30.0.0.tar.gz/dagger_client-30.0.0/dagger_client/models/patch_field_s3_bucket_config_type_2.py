from enum import Enum


class PatchFieldS3BucketConfigType2(str, Enum):
    DELETE = "Delete"

    def __str__(self) -> str:
        return str(self.value)
