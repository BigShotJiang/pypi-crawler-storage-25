from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.s3_bucket_access import S3BucketAccess


T = TypeVar("T", bound="ObjectSpaceAccessType1")


@_attrs_define
class ObjectSpaceAccessType1:
    """
    Attributes:
        s3 (S3BucketAccess):
    """

    s3: S3BucketAccess
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.s3_bucket_access import S3BucketAccess

        s3 = self.s3.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "S3": s3,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.s3_bucket_access import S3BucketAccess

        d = dict(src_dict)
        s3 = S3BucketAccess.from_dict(d.pop("S3"))

        object_space_access_type_1 = cls(
            s3=s3,
        )

        object_space_access_type_1.additional_properties = d
        return object_space_access_type_1

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
