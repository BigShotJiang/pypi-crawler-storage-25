from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID

if TYPE_CHECKING:
    from ..models.list_object_spaces_response_200_item_object_space_type_0 import (
        ListObjectSpacesResponse200ItemObjectSpaceType0,
    )
    from ..models.list_object_spaces_response_200_item_object_space_type_1 import (
        ListObjectSpacesResponse200ItemObjectSpaceType1,
    )
    from ..models.list_object_spaces_response_200_item_object_space_type_2 import (
        ListObjectSpacesResponse200ItemObjectSpaceType2,
    )


T = TypeVar("T", bound="ListObjectSpacesResponse200Item")


@_attrs_define
class ListObjectSpacesResponse200Item:
    """
    Attributes:
        id (UUID): Object space UUID
        object_space (ListObjectSpacesResponse200ItemObjectSpaceType0 | ListObjectSpacesResponse200ItemObjectSpaceType1
            | ListObjectSpacesResponse200ItemObjectSpaceType2):
    """

    id: UUID
    object_space: (
        ListObjectSpacesResponse200ItemObjectSpaceType0
        | ListObjectSpacesResponse200ItemObjectSpaceType1
        | ListObjectSpacesResponse200ItemObjectSpaceType2
    )
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.list_object_spaces_response_200_item_object_space_type_0 import (
            ListObjectSpacesResponse200ItemObjectSpaceType0,
        )
        from ..models.list_object_spaces_response_200_item_object_space_type_1 import (
            ListObjectSpacesResponse200ItemObjectSpaceType1,
        )
        from ..models.list_object_spaces_response_200_item_object_space_type_2 import (
            ListObjectSpacesResponse200ItemObjectSpaceType2,
        )

        id = str(self.id)

        object_space: dict[str, Any]
        if isinstance(self.object_space, ListObjectSpacesResponse200ItemObjectSpaceType0):
            object_space = self.object_space.to_dict()
        elif isinstance(self.object_space, ListObjectSpacesResponse200ItemObjectSpaceType1):
            object_space = self.object_space.to_dict()
        else:
            object_space = self.object_space.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "object_space": object_space,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any] | list[Any]) -> T:
        # The server serializes (ObjectSpaceId, ObjectSpace) as a JSON
        # 2-element array: [uuid_str, variant_obj]. Convert to dict form.
        if isinstance(src_dict, list):
            src_dict = {"id": src_dict[0], "object_space": src_dict[1]}
        from ..models.list_object_spaces_response_200_item_object_space_type_0 import (
            ListObjectSpacesResponse200ItemObjectSpaceType0,
        )
        from ..models.list_object_spaces_response_200_item_object_space_type_1 import (
            ListObjectSpacesResponse200ItemObjectSpaceType1,
        )
        from ..models.list_object_spaces_response_200_item_object_space_type_2 import (
            ListObjectSpacesResponse200ItemObjectSpaceType2,
        )

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        def _parse_object_space(
            data: object,
        ) -> (
            ListObjectSpacesResponse200ItemObjectSpaceType0
            | ListObjectSpacesResponse200ItemObjectSpaceType1
            | ListObjectSpacesResponse200ItemObjectSpaceType2
        ):
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                object_space_type_0 = ListObjectSpacesResponse200ItemObjectSpaceType0.from_dict(data)

                return object_space_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                object_space_type_1 = ListObjectSpacesResponse200ItemObjectSpaceType1.from_dict(data)

                return object_space_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            object_space_type_2 = ListObjectSpacesResponse200ItemObjectSpaceType2.from_dict(data)

            return object_space_type_2

        object_space = _parse_object_space(d.pop("object_space"))

        list_object_spaces_response_200_item = cls(
            id=id,
            object_space=object_space,
        )

        list_object_spaces_response_200_item.additional_properties = d
        return list_object_spaces_response_200_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
