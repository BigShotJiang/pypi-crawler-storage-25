from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.azure_blob_container import AzureBlobContainer


T = TypeVar("T", bound="ListObjectSpacesResponse200ItemObjectSpaceType0")


@_attrs_define
class ListObjectSpacesResponse200ItemObjectSpaceType0:
    """
    Attributes:
        azure_blob (AzureBlobContainer):
    """

    azure_blob: AzureBlobContainer
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.azure_blob_container import AzureBlobContainer

        azure_blob = self.azure_blob.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "AzureBlob": azure_blob,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.azure_blob_container import AzureBlobContainer

        d = dict(src_dict)
        azure_blob = AzureBlobContainer.from_dict(d.pop("AzureBlob"))

        list_object_spaces_response_200_item_object_space_type_0 = cls(
            azure_blob=azure_blob,
        )

        list_object_spaces_response_200_item_object_space_type_0.additional_properties = d
        return list_object_spaces_response_200_item_object_space_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
