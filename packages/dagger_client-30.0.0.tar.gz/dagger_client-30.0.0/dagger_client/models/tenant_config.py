from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.s3_bucket_config import S3BucketConfig


T = TypeVar("T", bound="TenantConfig")


@_attrs_define
class TenantConfig:
    """Tenant-level configuration.

    When new schema versions are added on the server side, they are upgraded
    transparently on read, so application code always sees this type.

        Attributes:
            s3 (None | S3BucketConfig | Unset):
    """

    s3: None | S3BucketConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.s3_bucket_config import S3BucketConfig

        s3: dict[str, Any] | None | Unset
        if isinstance(self.s3, Unset):
            s3 = UNSET
        elif isinstance(self.s3, S3BucketConfig):
            s3 = self.s3.to_dict()
        else:
            s3 = self.s3

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if s3 is not UNSET:
            field_dict["s3"] = s3

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.s3_bucket_config import S3BucketConfig

        d = dict(src_dict)

        def _parse_s3(data: object) -> None | S3BucketConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                s3_type_1 = S3BucketConfig.from_dict(data)

                return s3_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | S3BucketConfig | Unset, data)

        s3 = _parse_s3(d.pop("s3", UNSET))

        tenant_config = cls(
            s3=s3,
        )

        tenant_config.additional_properties = d
        return tenant_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
