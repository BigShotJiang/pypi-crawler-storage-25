from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast


T = TypeVar("T", bound="ColumnSelection")


@_attrs_define
class ColumnSelection:
    """Column indices within a row for each column type.

    Column ordering: `[geometry] [real] [int] [string] [rgb] [normal] [bool]`
    Quiche imposes no actual requirement on what attributes you have or their order,
    it only requires that attributes must be after geometry. However, all the other
    quiche crates assume exactly these attributes exist in this order, so we keep this here.

        Attributes:
            bool_ (list[int]): The indices of the boolean attribute columns.
            geometry (list[int]): The indices of the geometry columns.
                - Point: [X, Y, Z] (3 columns)
                - Ball: [X, Y, Z, R] (4 columns)
                - Aabb: [X, Y, Z, Dx, Dy, Dz] (6 columns in center+half-extents format)
            int_ (list[int]): The indices of the integer attribute columns.
            normal (list[int]): The indices of the normal attribute columns.
            real (list[int]): The indices of the real attribute columns.
            rgb (list[int]): The indices of the RGB attribute columns.
            string (list[int]): The indices of the string attribute columns.
    """

    bool_: list[int]
    geometry: list[int]
    int_: list[int]
    normal: list[int]
    real: list[int]
    rgb: list[int]
    string: list[int]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        bool_ = self.bool_

        geometry = self.geometry

        int_ = self.int_

        normal = self.normal

        real = self.real

        rgb = self.rgb

        string = self.string

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bool": bool_,
                "geometry": geometry,
                "int": int_,
                "normal": normal,
                "real": real,
                "rgb": rgb,
                "string": string,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        bool_ = cast(list[int], d.pop("bool"))

        geometry = cast(list[int], d.pop("geometry"))

        int_ = cast(list[int], d.pop("int"))

        normal = cast(list[int], d.pop("normal"))

        real = cast(list[int], d.pop("real"))

        rgb = cast(list[int], d.pop("rgb"))

        string = cast(list[int], d.pop("string"))

        column_selection = cls(
            bool_=bool_,
            geometry=geometry,
            int_=int_,
            normal=normal,
            real=real,
            rgb=rgb,
            string=string,
        )

        column_selection.additional_properties = d
        return column_selection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
