from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.object_service_type import ObjectServiceType
from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="PutObjectSpaceRequest")


@_attrs_define
class PutObjectSpaceRequest:
    """
    Attributes:
        service (None | ObjectServiceType | Unset):
    """

    service: None | ObjectServiceType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        service: None | str | Unset
        if isinstance(self.service, Unset):
            service = UNSET
        elif isinstance(self.service, ObjectServiceType):
            service = self.service.value
        else:
            service = self.service

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if service is not UNSET:
            field_dict["service"] = service

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_service(data: object) -> None | ObjectServiceType | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                service_type_1 = ObjectServiceType(data)

                return service_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ObjectServiceType | Unset, data)

        service = _parse_service(d.pop("service", UNSET))

        put_object_space_request = cls(
            service=service,
        )

        put_object_space_request.additional_properties = d
        return put_object_space_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
