from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.s3_endpoint import S3Endpoint


T = TypeVar("T", bound="S3Prefix")


@_attrs_define
class S3Prefix:
    """
    Attributes:
        endpoint (S3Endpoint):
        region (str):
        bucket (str):
        prefix (str):
    """

    endpoint: S3Endpoint
    region: str
    bucket: str
    prefix: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.s3_endpoint import S3Endpoint

        endpoint = self.endpoint.to_dict()

        region = self.region

        bucket = self.bucket

        prefix = self.prefix

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "endpoint": endpoint,
                "region": region,
                "bucket": bucket,
                "prefix": prefix,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.s3_endpoint import S3Endpoint

        d = dict(src_dict)
        endpoint = S3Endpoint.from_dict(d.pop("endpoint"))

        region = d.pop("region")

        bucket = d.pop("bucket")

        prefix = d.pop("prefix")

        s3_prefix = cls(
            endpoint=endpoint,
            region=region,
            bucket=bucket,
            prefix=prefix,
        )

        s3_prefix.additional_properties = d
        return s3_prefix

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
