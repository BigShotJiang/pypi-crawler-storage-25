from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast


T = TypeVar("T", bound="S3BucketConfig")


@_attrs_define
class S3BucketConfig:
    """Configuration for a customer-provided S3 bucket.

    Attributes:
        bucket_name (str): The S3 bucket name.
        region (str): The AWS region.
        role_arn (str): The IAM role ARN for cross-account access via STS AssumeRole.
        endpoint_url (None | str | Unset): Optional custom S3 endpoint URL.
    """

    bucket_name: str
    region: str
    role_arn: str
    endpoint_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        bucket_name = self.bucket_name

        region = self.region

        role_arn = self.role_arn

        endpoint_url: None | str | Unset
        if isinstance(self.endpoint_url, Unset):
            endpoint_url = UNSET
        else:
            endpoint_url = self.endpoint_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bucket_name": bucket_name,
                "region": region,
                "role_arn": role_arn,
            }
        )
        if endpoint_url is not UNSET:
            field_dict["endpoint_url"] = endpoint_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        bucket_name = d.pop("bucket_name")

        region = d.pop("region")

        role_arn = d.pop("role_arn")

        def _parse_endpoint_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        endpoint_url = _parse_endpoint_url(d.pop("endpoint_url", UNSET))

        s3_bucket_config = cls(
            bucket_name=bucket_name,
            region=region,
            role_arn=role_arn,
            endpoint_url=endpoint_url,
        )

        s3_bucket_config.additional_properties = d
        return s3_bucket_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
