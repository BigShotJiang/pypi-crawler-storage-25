from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.azure_blob_auth_type_0 import AzureBlobAuthType0
    from ..models.azure_blob_endpoint import AzureBlobEndpoint


T = TypeVar("T", bound="AzureBlobContainerAccess")


@_attrs_define
class AzureBlobContainerAccess:
    """
    Attributes:
        auth (AzureBlobAuthType0): How a Dagger client should authenticate when accessing an object space
            stored in Azure BLOB.
        container (str):
        endpoint (AzureBlobEndpoint):
    """

    auth: AzureBlobAuthType0
    container: str
    endpoint: AzureBlobEndpoint
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.azure_blob_auth_type_0 import AzureBlobAuthType0
        from ..models.azure_blob_endpoint import AzureBlobEndpoint

        auth: dict[str, Any]
        if isinstance(self.auth, AzureBlobAuthType0):
            auth = self.auth.to_dict()

        container = self.container

        endpoint = self.endpoint.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "auth": auth,
                "container": container,
                "endpoint": endpoint,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.azure_blob_auth_type_0 import AzureBlobAuthType0
        from ..models.azure_blob_endpoint import AzureBlobEndpoint

        d = dict(src_dict)

        def _parse_auth(data: object) -> AzureBlobAuthType0:
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_azure_blob_auth_type_0 = AzureBlobAuthType0.from_dict(data)

            return componentsschemas_azure_blob_auth_type_0

        auth = _parse_auth(d.pop("auth"))

        container = d.pop("container")

        endpoint = AzureBlobEndpoint.from_dict(d.pop("endpoint"))

        azure_blob_container_access = cls(
            auth=auth,
            container=container,
            endpoint=endpoint,
        )

        azure_blob_container_access.additional_properties = d
        return azure_blob_container_access

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
