from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.geometry_type import GeometryType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
    from ..models.archetype import Archetype
    from ..models.column_selection import ColumnSelection
    from ..models.quiche_config import QuicheConfig


T = TypeVar("T", bound="ImportRequest")


@_attrs_define
class ImportRequest:
    """Request body for starting a model import.

    Attributes:
        archetype (Archetype): The set of [`Attribute`] stored in some table.
        columns (ColumnSelection): Column indices within a row for each column type.

            Column ordering: `[geometry] [real] [int] [string] [rgb] [normal] [bool]`
            Quiche imposes no actual requirement on what attributes you have or their order,
            it only requires that attributes must be after geometry. However, all the other
            quiche crates assume exactly these attributes exist in this order, so we keep this here.
        geometry_type (GeometryType): A runtime label for implementers of [`LeafGeometry`].
        source_uri (str): Self-authorized URI to the source data (e.g. SAS URL).
        quiche_config (None | QuicheConfig | Unset):
    """

    archetype: Archetype
    columns: ColumnSelection
    geometry_type: GeometryType
    source_uri: str
    quiche_config: None | QuicheConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.archetype import Archetype
        from ..models.column_selection import ColumnSelection
        from ..models.quiche_config import QuicheConfig

        archetype = self.archetype.to_dict()

        columns = self.columns.to_dict()

        geometry_type = self.geometry_type.value

        source_uri = self.source_uri

        quiche_config: dict[str, Any] | None | Unset
        if isinstance(self.quiche_config, Unset):
            quiche_config = UNSET
        elif isinstance(self.quiche_config, QuicheConfig):
            quiche_config = self.quiche_config.to_dict()
        else:
            quiche_config = self.quiche_config

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "archetype": archetype,
                "columns": columns,
                "geometry_type": geometry_type,
                "source_uri": source_uri,
            }
        )
        if quiche_config is not UNSET:
            field_dict["quiche_config"] = quiche_config

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.archetype import Archetype
        from ..models.column_selection import ColumnSelection
        from ..models.quiche_config import QuicheConfig

        d = dict(src_dict)
        archetype = Archetype.from_dict(d.pop("archetype"))

        columns = ColumnSelection.from_dict(d.pop("columns"))

        geometry_type = GeometryType(d.pop("geometry_type"))

        source_uri = d.pop("source_uri")

        def _parse_quiche_config(data: object) -> None | QuicheConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                quiche_config_type_1 = QuicheConfig.from_dict(data)

                return quiche_config_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | QuicheConfig | Unset, data)

        quiche_config = _parse_quiche_config(d.pop("quiche_config", UNSET))

        import_request = cls(
            archetype=archetype,
            columns=columns,
            geometry_type=geometry_type,
            source_uri=source_uri,
            quiche_config=quiche_config,
        )

        import_request.additional_properties = d
        return import_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
