from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.sts_temporary_credentials import StsTemporaryCredentials


T = TypeVar("T", bound="S3AuthType1")


@_attrs_define
class S3AuthType1:
    """
    Attributes:
        temporary (StsTemporaryCredentials):
    """

    temporary: StsTemporaryCredentials
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.sts_temporary_credentials import StsTemporaryCredentials

        temporary = self.temporary.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "Temporary": temporary,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.sts_temporary_credentials import StsTemporaryCredentials

        d = dict(src_dict)
        temporary = StsTemporaryCredentials.from_dict(d.pop("Temporary"))

        s3_auth_type_1 = cls(
            temporary=temporary,
        )

        s3_auth_type_1.additional_properties = d
        return s3_auth_type_1

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
