from enum import Enum


class FseAttributeTypeType4(str, Enum):
    NORMAL = "Normal"

    def __str__(self) -> str:
        return str(self.value)
