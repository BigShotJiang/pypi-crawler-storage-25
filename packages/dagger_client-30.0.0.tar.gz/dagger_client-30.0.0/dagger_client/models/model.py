from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.model_type import ModelType
from ..models.object_service_type import ObjectServiceType
from typing import cast
from uuid import UUID


T = TypeVar("T", bound="Model")


@_attrs_define
class Model:
    """
    Attributes:
        format_versions (list[int]): Using plain integers so that:
            - older clients don't have trouble deserializing new versions
            - we can support multiple model types
        model_type (ModelType): Enumerate all model types supported by Dagger.
        object_service (ObjectServiceType):
        object_space (UUID): The object space where this model's objects are stored.
    """

    format_versions: list[int]
    model_type: ModelType
    object_service: ObjectServiceType
    object_space: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        format_versions = self.format_versions

        model_type = self.model_type.value

        object_service = self.object_service.value

        object_space = str(self.object_space)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "format_versions": format_versions,
                "model_type": model_type,
                "object_service": object_service,
                "object_space": object_space,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        format_versions = cast(list[int], d.pop("format_versions"))

        model_type = ModelType(d.pop("model_type"))

        object_service = ObjectServiceType(d.pop("object_service"))

        object_space = UUID(d.pop("object_space"))

        model = cls(
            format_versions=format_versions,
            model_type=model_type,
            object_service=object_service,
            object_space=object_space,
        )

        model.additional_properties = d
        return model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
