from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.sampler_type import SamplerType
from typing import cast

if TYPE_CHECKING:
    from ..models.fse_header import FseHeader


T = TypeVar("T", bound="Attribute")


@_attrs_define
class Attribute:
    """A named data column with a set of samplers used for creating reductions for LOD.

    Attributes:
        header (FseHeader): Attribute header used by the Foresight Solids Engine.
        reductions (list[SamplerType]):
    """

    header: FseHeader
    reductions: list[SamplerType]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.fse_header import FseHeader

        header = self.header.to_dict()

        reductions = []
        for reductions_item_data in self.reductions:
            reductions_item = reductions_item_data.value
            reductions.append(reductions_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "header": header,
                "reductions": reductions,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.fse_header import FseHeader

        d = dict(src_dict)
        header = FseHeader.from_dict(d.pop("header"))

        reductions = []
        _reductions = d.pop("reductions")
        for reductions_item_data in _reductions:
            reductions_item = SamplerType(reductions_item_data)

            reductions.append(reductions_item)

        attribute = cls(
            header=header,
            reductions=reductions,
        )

        attribute.additional_properties = d
        return attribute

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
