from enum import Enum


class FseAttributeTypeType3(str, Enum):
    INT = "Int"

    def __str__(self) -> str:
        return str(self.value)
