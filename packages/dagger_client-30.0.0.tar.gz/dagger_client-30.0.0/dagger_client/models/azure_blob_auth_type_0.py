from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
    from ..models.ser_token import SerToken


T = TypeVar("T", bound="AzureBlobAuthType0")


@_attrs_define
class AzureBlobAuthType0:
    """
    Attributes:
        sas_token (SerToken): A secret access token that is still serializable specifically so it can be
            encoded in an HTTP response.
    """

    sas_token: SerToken
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.ser_token import SerToken

        sas_token = self.sas_token.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "SasToken": sas_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ser_token import SerToken

        d = dict(src_dict)
        sas_token = SerToken.from_dict(d.pop("SasToken"))

        azure_blob_auth_type_0 = cls(
            sas_token=sas_token,
        )

        azure_blob_auth_type_0.additional_properties = d
        return azure_blob_auth_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
