from enum import Enum


class RealMeasurement(str, Enum):
    DENSITY = "Density"
    INDEPENDENTVALUE = "IndependentValue"
    VALUEBYVOLUME = "ValueByVolume"
    VALUEBYWEIGHT = "ValueByWeight"

    def __str__(self) -> str:
        return str(self.value)
