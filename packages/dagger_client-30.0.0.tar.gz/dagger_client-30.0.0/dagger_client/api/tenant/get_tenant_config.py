from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.tenant_config import TenantConfig
from typing import cast
from uuid import UUID


def _get_kwargs(
    tenant: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/tenants/{tenant}/config".format(
            tenant=quote(str(tenant), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | TenantConfig | None:
    if response.status_code == 200:
        response_200 = TenantConfig.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | TenantConfig]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tenant: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | TenantConfig]:
    """Get tenant config.

     Service hosts MUST restrict access to admin-only roles.

    Args:
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | TenantConfig]
    """

    kwargs = _get_kwargs(
        tenant=tenant,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    tenant: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Any | TenantConfig | None:
    """Get tenant config.

     Service hosts MUST restrict access to admin-only roles.

    Args:
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | TenantConfig
    """

    return sync_detailed(
        tenant=tenant,
        client=client,
    ).parsed


async def asyncio_detailed(
    tenant: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | TenantConfig]:
    """Get tenant config.

     Service hosts MUST restrict access to admin-only roles.

    Args:
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | TenantConfig]
    """

    kwargs = _get_kwargs(
        tenant=tenant,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    tenant: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Any | TenantConfig | None:
    """Get tenant config.

     Service hosts MUST restrict access to admin-only roles.

    Args:
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | TenantConfig
    """

    return (
        await asyncio_detailed(
            tenant=tenant,
            client=client,
        )
    ).parsed
