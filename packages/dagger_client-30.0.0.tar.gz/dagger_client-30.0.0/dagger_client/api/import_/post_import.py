from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.import_request import ImportRequest
from typing import cast
from uuid import UUID


def _get_kwargs(
    model_uuid: UUID,
    *,
    body: ImportRequest,
    tenant: UUID,
    object_space: UUID,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_tenant = str(tenant)
    params["tenant"] = json_tenant

    json_object_space = str(object_space)
    params["object-space"] = json_object_space

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/imports/{model_uuid}".format(
            model_uuid=quote(str(model_uuid), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 202:
        return None

    if response.status_code == 400:
        return None

    if response.status_code == 409:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    model_uuid: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ImportRequest,
    tenant: UUID,
    object_space: UUID,
) -> Response[Any]:
    """Start a model import from a URI.

    Args:
        model_uuid (UUID):
        tenant (UUID):
        object_space (UUID):
        body (ImportRequest): Request body for starting a model import.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        model_uuid=model_uuid,
        body=body,
        tenant=tenant,
        object_space=object_space,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    model_uuid: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: ImportRequest,
    tenant: UUID,
    object_space: UUID,
) -> Response[Any]:
    """Start a model import from a URI.

    Args:
        model_uuid (UUID):
        tenant (UUID):
        object_space (UUID):
        body (ImportRequest): Request body for starting a model import.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        model_uuid=model_uuid,
        body=body,
        tenant=tenant,
        object_space=object_space,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
