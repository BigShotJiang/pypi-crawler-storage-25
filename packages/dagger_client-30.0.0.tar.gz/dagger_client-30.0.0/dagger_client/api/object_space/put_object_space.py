from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.object_space_access_type_0 import ObjectSpaceAccessType0
from ...models.object_space_access_type_1 import ObjectSpaceAccessType1
from ...models.object_space_access_type_2 import ObjectSpaceAccessType2
from ...models.put_object_space_request import PutObjectSpaceRequest
from typing import cast
from uuid import UUID


def _get_kwargs(
    id: UUID,
    *,
    body: PutObjectSpaceRequest,
    tenant: UUID,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_tenant = str(tenant)
    params["tenant"] = json_tenant

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/object-spaces/{id}".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2 | None:
    if response.status_code == 200:

        def _parse_response_200(
            data: object,
        ) -> ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_object_space_access_type_0 = ObjectSpaceAccessType0.from_dict(data)

                return componentsschemas_object_space_access_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_object_space_access_type_1 = ObjectSpaceAccessType1.from_dict(data)

                return componentsschemas_object_space_access_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_object_space_access_type_2 = ObjectSpaceAccessType2.from_dict(data)

            return componentsschemas_object_space_access_type_2

        response_200 = _parse_response_200(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutObjectSpaceRequest,
    tenant: UUID,
) -> Response[ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2]:
    """Create a new object space if it doesn't already exist.
    Returns credentials to be used when accessing directly from the object storage.

    Args:
        id (UUID):
        tenant (UUID):
        body (PutObjectSpaceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
        tenant=tenant,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutObjectSpaceRequest,
    tenant: UUID,
) -> ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2 | None:
    """Create a new object space if it doesn't already exist.
    Returns credentials to be used when accessing directly from the object storage.

    Args:
        id (UUID):
        tenant (UUID):
        body (PutObjectSpaceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
        tenant=tenant,
    ).parsed


async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutObjectSpaceRequest,
    tenant: UUID,
) -> Response[ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2]:
    """Create a new object space if it doesn't already exist.
    Returns credentials to be used when accessing directly from the object storage.

    Args:
        id (UUID):
        tenant (UUID):
        body (PutObjectSpaceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
        tenant=tenant,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: PutObjectSpaceRequest,
    tenant: UUID,
) -> ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2 | None:
    """Create a new object space if it doesn't already exist.
    Returns credentials to be used when accessing directly from the object storage.

    Args:
        id (UUID):
        tenant (UUID):
        body (PutObjectSpaceRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ObjectSpaceAccessType0 | ObjectSpaceAccessType1 | ObjectSpaceAccessType2
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
            tenant=tenant,
        )
    ).parsed
