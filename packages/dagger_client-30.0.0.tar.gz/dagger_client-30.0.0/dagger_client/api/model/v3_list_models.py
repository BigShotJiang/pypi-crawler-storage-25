from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_models_item import ListModelsItem
from ...types import UNSET, Unset
from typing import cast
from uuid import UUID


def _get_kwargs(
    *,
    tenant: UUID,
    object_space: None | Unset | UUID = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_tenant = str(tenant)
    params["tenant"] = json_tenant

    json_object_space: None | str | Unset
    if isinstance(object_space, Unset):
        json_object_space = UNSET
    elif isinstance(object_space, UUID):
        json_object_space = str(object_space)
    else:
        json_object_space = object_space
    params["object-space"] = json_object_space

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v3/models/",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> list[ListModelsItem] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ListModelsItem.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[ListModelsItem]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
    object_space: None | Unset | UUID = UNSET,
) -> Response[list[ListModelsItem]]:
    """List all models with some metadata.

    Args:
        tenant (UUID):
        object_space (None | Unset | UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListModelsItem]]
    """

    kwargs = _get_kwargs(
        tenant=tenant,
        object_space=object_space,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
    object_space: None | Unset | UUID = UNSET,
) -> list[ListModelsItem] | None:
    """List all models with some metadata.

    Args:
        tenant (UUID):
        object_space (None | Unset | UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListModelsItem]
    """

    return sync_detailed(
        client=client,
        tenant=tenant,
        object_space=object_space,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
    object_space: None | Unset | UUID = UNSET,
) -> Response[list[ListModelsItem]]:
    """List all models with some metadata.

    Args:
        tenant (UUID):
        object_space (None | Unset | UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[ListModelsItem]]
    """

    kwargs = _get_kwargs(
        tenant=tenant,
        object_space=object_space,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
    object_space: None | Unset | UUID = UNSET,
) -> list[ListModelsItem] | None:
    """List all models with some metadata.

    Args:
        tenant (UUID):
        object_space (None | Unset | UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[ListModelsItem]
    """

    return (
        await asyncio_detailed(
            client=client,
            tenant=tenant,
            object_space=object_space,
        )
    ).parsed
