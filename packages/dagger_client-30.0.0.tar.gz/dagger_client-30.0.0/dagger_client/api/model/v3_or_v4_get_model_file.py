from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from typing import cast
from uuid import UUID


def _get_kwargs(
    id: UUID,
    *,
    tenant: UUID,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_tenant = str(tenant)
    params["tenant"] = json_tenant

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v4/models/{id}/file".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> list[int] | None:
    if response.status_code == 200:
        response_200 = cast(list[int], response.content)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[list[int]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
) -> Response[list[int]]:
    """Returns the serialized bytes of a model file at the given format version.

    Args:
        id (UUID):
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[int]]
    """

    kwargs = _get_kwargs(
        id=id,
        tenant=tenant,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
) -> list[int] | None:
    """Returns the serialized bytes of a model file at the given format version.

    Args:
        id (UUID):
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[int]
    """

    return sync_detailed(
        id=id,
        client=client,
        tenant=tenant,
    ).parsed


async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
) -> Response[list[int]]:
    """Returns the serialized bytes of a model file at the given format version.

    Args:
        id (UUID):
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[int]]
    """

    kwargs = _get_kwargs(
        id=id,
        tenant=tenant,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient | Client,
    tenant: UUID,
) -> list[int] | None:
    """Returns the serialized bytes of a model file at the given format version.

    Args:
        id (UUID):
        tenant (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[int]
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            tenant=tenant,
        )
    ).parsed
