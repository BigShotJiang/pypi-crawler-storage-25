import sys
if sys.version_info < (3, 11):
    raise RuntimeError(
        f"Kipu Quantum Hub SDK requires Python 3.11 or higher; "
        f"you are running {sys.version_info.major}.{sys.version_info.minor}."
    )


"""
Kipu Quantum Hub SDK module providing unified access to quantum providers.
"""

from ._version import __version__

# Type annotations for IDE support
from typing import Type

HubQiskitProvider: Type['HubQiskitProvider']
HubBraketProvider: Type['HubBraketProvider']
HubQiskitRuntimeService: Type['HubQiskitRuntimeService']

# Submodules will be available via lazy loading

__all__ = [
    'HubQiskitProvider',
    'HubBraketProvider',
    'HubQiskitRuntimeService',

    '__version__',
    'braket', 'qiskit',
]


def __getattr__(name: str):
    import sys
    current_module = sys.modules[__name__]

    if name == "HubBraketProvider":
        from .braket.braket_provider import HubBraketProvider
        setattr(current_module, name, HubBraketProvider)
        return HubBraketProvider
    elif name == "HubQiskitProvider":
        from .qiskit.provider import HubQiskitProvider
        setattr(current_module, name, HubQiskitProvider)
        return HubQiskitProvider
    elif name == "HubQiskitRuntimeService":
        from qhub.quantum.sdk.qiskit.hub_qiskit_runtime_service import HubQiskitRuntimeService
        setattr(current_module, name, HubQiskitRuntimeService)
        return HubQiskitRuntimeService
    elif name == "braket":
        from . import braket
        setattr(current_module, name, braket)
        return braket
    elif name == "qiskit":
        from . import qiskit
        setattr(current_module, name, qiskit)
        return qiskit
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
