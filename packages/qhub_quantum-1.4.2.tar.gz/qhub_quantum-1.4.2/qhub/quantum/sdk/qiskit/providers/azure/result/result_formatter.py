from abc import ABC, abstractmethod
from typing import List, Dict, Any

from qhub.quantum.sdk.qiskit import HubQiskitJob


class ResultFormatter(ABC):

    def __init__(self, results: any, job: HubQiskitJob):
        self.results = results
        self.job = job

    @abstractmethod
    def format_result(self) -> List[Dict[str, Any]]:
        pass
