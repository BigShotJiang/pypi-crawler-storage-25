from typing import Optional

from qiskit.circuit import Gate
from qiskit.circuit.library import get_standard_gate_name_mapping

from qhub.quantum.sdk.qiskit import HubQiskitBackend


class HubAzureQiskitBackend(HubQiskitBackend):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def _to_gate(self, name: str) -> Optional[Gate]:
        name = name.lower()

        qiskit_gate_mapping = get_standard_gate_name_mapping()
        if name in qiskit_gate_mapping:
            return qiskit_gate_mapping[name]

    def _get_multi_qubit_gate_properties(self) -> dict:
        return {None: None}
