from typing import Optional, Union

from qiskit.providers import Backend

from qhub.api.quantum import HubQuantumClient, Job as JobModel
from qhub.quantum.sdk.job import JobRequest
from qhub.quantum.sdk.qiskit import HubQiskitJob


class HubQudoraQiskitJob(HubQiskitJob):

    def __init__(self, backend: Optional[Backend], job_id: Optional[str] = None,
                 job_details: Optional[Union[JobModel, JobRequest]] = None,
                 hub_client: Optional[HubQuantumClient] = None):

        super().__init__(backend, job_id, job_details, hub_client)
