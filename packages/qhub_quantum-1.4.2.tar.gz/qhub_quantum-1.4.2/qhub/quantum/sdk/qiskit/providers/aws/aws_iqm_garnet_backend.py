from typing import List, Dict

from qhub.api.quantum import Qubit, Connectivity
from qhub.quantum.sdk.qiskit.provider import HubQiskitProvider
from qhub.quantum.sdk.qiskit.providers.aws.aws_backend import HubAwsBackend


@HubQiskitProvider.register_backend("aws.iqm.garnet")
class HubAwsIqmGarnetBackend(HubAwsBackend):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def _normalize_qubit_indices(self):
        """Remap IQM Garnet's 1-based qubit indices to 0-based.

        qhub-api models are frozen, so we store zero-based copies as
        instance attributes for use in target construction.
        """
        qubits = self.backend_info.configuration.qubits
        self._zero_based_qubits = [Qubit(id=str(int(q.id) - 1)) for q in qubits]

        graph = self.backend_info.configuration.connectivity.graph
        updated_graph: Dict[str, List[str]] = {}
        for src, targets in graph.items():
            updated_graph[str(int(src) - 1)] = [str(int(t) - 1) for t in targets]
        self._zero_based_connectivity_graph = updated_graph

    @property
    def num_qubits(self) -> int:
        return len(self._zero_based_qubits)
