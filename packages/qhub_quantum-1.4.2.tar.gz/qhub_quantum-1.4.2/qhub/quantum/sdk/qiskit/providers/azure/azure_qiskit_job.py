from typing import Optional, Union

from qiskit.result.models import ExperimentResult

from qhub.api.quantum import HubQuantumClient, Job as JobModel
from qhub.quantum.sdk.job import JobRequest
from qhub.quantum.sdk.qiskit import HubQiskitJob, HubQiskitBackend
from qhub.quantum.sdk.qiskit.providers.azure.result.ionq_result_formatter import IonqResultFormatter


class HubAzureQiskitJob(HubQiskitJob):

    def __init__(self, backend: Optional[HubQiskitBackend], job_id: Optional[str] = None,
                 job_details: Optional[Union[JobModel, JobRequest]] = None,
                 hub_client: Optional[HubQuantumClient] = None):

        super().__init__(backend, job_id, job_details, hub_client)

    def _create_experiment_result(self, provider_result: dict) -> ExperimentResult:
        backend: HubQiskitBackend = self.backend()
        hw_provider = backend.backend_info.hardware_provider

        if hw_provider == "IONQ":
            formatter = IonqResultFormatter(provider_result, self)
        else:
            raise NotImplementedError(f"Hardware provider {hw_provider} not supported")

        return formatter.format_result()
