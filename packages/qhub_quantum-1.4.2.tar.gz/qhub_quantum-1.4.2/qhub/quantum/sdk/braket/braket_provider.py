from typing import Dict, Type, List

from qhub.api.quantum import Backend as BackendModel
from qhub.api.quantum.errors import NotFoundError
from qhub.quantum.sdk.braket.aws_device import HubAwsDevice
from qhub.quantum.sdk.exceptions import BackendNotFoundError
from qhub.quantum.sdk.qiskit.provider import _HubProvider


class HubBraketProvider(_HubProvider):
    _device_mapping: Dict[str, Type[HubAwsDevice]] = {}

    @classmethod
    def register_device(cls, device_id: str):
        """For internal use only. Binds a device class to a Kipu Quantum Hub backend id."""

        def decorator(device_cls: Type[HubAwsDevice]):
            cls._device_mapping[device_id] = device_cls
            return device_cls

        return decorator

    @classmethod
    def get_device_class(cls, backend_id: str) -> Type[HubAwsDevice]:
        device_class = cls._device_mapping.get(backend_id)
        if device_class is None:
            raise BackendNotFoundError(f"Backend '{backend_id}' is not supported by Kipu Quantum Hub Braket.")
        return device_class

    def get_device(self, backend_id: str) -> HubAwsDevice:
        """
        Retrieves an AWS Braket Device based on the provided Kipu Quantum Hub backend id.

        Args:
            backend_id (str): The Kipu Quantum Hub backend (device) id.

        Returns:
            HubAwsDevice: The AWS Braket device corresponding to the backend id.

        Raises:
            BackendNotFoundError: If the backend with the given id cannot be found or is not supported by the Braket SDK.

        Note:
            An overview of the supported backends and their IDs can be found at: https://platform.planqk.de/quantum-backends
        """
        backend_info = self._get_backend_info(backend_id)
        return self._get_hub_braket_device(backend_info)

    def devices(self) -> List[str]:
        """
        Retrieves a list of all AWS Braket devices (backends) provided through Kipu Quantum Hub that can be accessed using this SDK.

        Returns:
            List[str]: A list of supported AWS Braket device IDs.
        """
        return list(self._device_mapping.keys())

    def _get_backend_info(self, backend_id):
        try:
            return self._client.backends.get_backend(backend_id)
        except NotFoundError:
            raise BackendNotFoundError(f"Kipu Quantum Hub device with id {backend_id} not found.")

    def _get_hub_braket_device(self, backend_info: BackendModel) -> HubAwsDevice:
        device_class = self.get_device_class(backend_info.id)
        return device_class(hub_client=self._client, backend_info=backend_info)
