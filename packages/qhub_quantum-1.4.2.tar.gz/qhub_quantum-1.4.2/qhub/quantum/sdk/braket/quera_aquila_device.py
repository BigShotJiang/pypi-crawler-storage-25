import json
from typing import Union, Optional, Any, cast

from braket.ahs.analog_hamiltonian_simulation import AnalogHamiltonianSimulation
from braket.circuits import GateCalibrations
from braket.device_schema.pulse.frame_v1 import Frame
from braket.device_schema.pulse.port_v1 import Port
from braket.device_schema.quera import QueraDeviceCapabilities
from networkx import DiGraph
from qiskit import QuantumCircuit

from qhub.quantum.sdk.backend import HubBackend
from qhub.quantum.sdk.braket.aws_device import HubAwsDevice
from qhub.quantum.sdk.braket.braket_provider import HubBraketProvider
from qhub.quantum.sdk.braket.hub_quantum_task import HubAwsQuantumTask


@HubBraketProvider.register_device("aws.quera.aquila")
class HubQueraAquilaDevice(HubAwsDevice):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @property
    def properties(self) -> QueraDeviceCapabilities:
        """QueraDeviceCapabilities: Return the device properties"""
        config = self._get_backend_config()
        return QueraDeviceCapabilities.parse_raw(json.dumps(config))

    @property
    def name(self) -> str:
        return "Aquila"

    @property
    def provider_name(self) -> str:
        return "QuEra"

    @property
    def topology_graph(self) -> DiGraph:
        return None

    @property
    def frames(self) -> dict[str, Frame]:
        return {}

    @property
    def gate_calibrations(self) -> Optional[GateCalibrations]:
        return None

    @property
    def ports(self) -> dict[str, Port]:
        return {}

    def run(self, task_specification: AnalogHamiltonianSimulation, shots: Optional[int] = None, *args: Any, **kwargs: Any) -> HubAwsQuantumTask:
        shots = shots if shots else HubAwsDevice.DEFAULT_SHOTS_QPU
        # deactivate type hinting as generics are not supported in Python
        task = HubBackend.run(self, job_input=task_specification, shots=shots, sdk_provider="BRAKET", *args, **kwargs)

        return cast(HubAwsQuantumTask, task)

    def _convert_to_job_input(self, job_input: Union[QuantumCircuit, AnalogHamiltonianSimulation], options=None) -> dict:
        input_json = job_input.to_ir().json(exclude={'braketSchemaHeader'})
        return {"ahs_program": json.loads(input_json)}

    def _get_job_input_format(self) -> str:
        return "BRAKET_AHS_PROGRAM"
