import json

from braket.device_schema.ionq import IonqDeviceCapabilities

from qhub.quantum.sdk.braket.braket_provider import HubBraketProvider
from qhub.quantum.sdk.braket.gate_based_device import HubAwsGateBasedDevice


class HubAwsIonqDevice(HubAwsGateBasedDevice):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @property
    def properties(self) -> IonqDeviceCapabilities:
        """IonqDeviceCapabilities: Return the device properties"""
        config = self._get_backend_config()
        return IonqDeviceCapabilities.parse_raw(json.dumps(config))

    @property
    def provider_name(self) -> str:
        return "IonQ"


@HubBraketProvider.register_device("aws.ionq.forte")
class HubAwsIonqForteDevice(HubAwsIonqDevice):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @property
    def name(self) -> str:
        return "Forte 1"
