"""Compatibility shim — stub for dto_utils. Will be removed."""

from dataclasses import fields as dataclass_fields


def init_with_defined_params(cls, data):
    valid_keys = {f.name for f in dataclass_fields(cls)}
    filtered = {k: v for k, v in data.items() if k in valid_keys}
    return cls(**filtered)
