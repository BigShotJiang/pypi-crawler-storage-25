"""
Compatibility shim — re-exports old session DTO types.
Will be removed once braket migration is complete.
"""
from enum import Enum
from typing import Optional, Dict

from pydantic import BaseModel


class SessionMode(Enum):
    BATCH = "batch"
    DEDICATED = "dedicated"


class SessionStatus(Enum):
    UNKNOWN = "UNKNOWN"
    ABORTED = "ABORTED"
    OPEN = "OPEN"
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    DRAINING = "DRAINING"
    CLOSED = "CLOSED"


class SessionResponse(BaseModel):
    id: str
    backend_id: str = ""
    provider: str = "UNKNOWN"
    status: SessionStatus = SessionStatus.UNKNOWN
    mode: SessionMode = SessionMode.DEDICATED
    created_at: Optional[str] = None
    started_at: Optional[str] = None
    closed_at: Optional[str] = None
    expires_at: Optional[str] = None
    usage_time_millis: Optional[int] = None
    provider_id: Optional[str] = None
    metadata: Optional[Dict] = None
    sdk_provider: Optional[str] = None
