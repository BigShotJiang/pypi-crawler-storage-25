class HubError(Exception):
    def __init__(self, *message):
        super().__init__(' '.join(message))
        self.message = ' '.join(message)

    def __str__(self):
        return repr(self.message)


class BackendNotFoundError(HubError):
    pass


# Kept for backward compatibility with braket providers (will be removed after braket migration)
class CredentialUnavailableError(HubError):
    pass


class InvalidAccessTokenError(HubError):
    def __init__(self, value="Invalid personal access token"):
        self.value = value
        super().__init__(self.value)


class HubClientError(Exception):
    """Compatibility shim for braket providers."""
    def __init__(self, response=None):
        super().__init__(response)
        self.response = response

    def __str__(self):
        if self.response and hasattr(self.response, 'text') and self.response.text:
            import json
            error_json = json.loads(self.response.text)
            error_msg = error_json.get('error_message', error_json.get('detail', None))
            status = error_json.get('status', None)
            return f'{error_msg} (HTTP error: {status})'
        elif self.response and hasattr(self.response, 'status_code'):
            return f'HTTP error code: {self.response.status_code}'
        return str(self.response)
