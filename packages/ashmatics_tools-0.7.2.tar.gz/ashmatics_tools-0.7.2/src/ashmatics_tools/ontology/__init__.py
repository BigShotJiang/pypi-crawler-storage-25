# Copyright (c) 2025, Asher Informatics PBC
"""
Ashmatics Ontology Tools - Medical Ontology Management SDK

This package provides comprehensive ontology management functionality for medical
terminologies including SNOMED CT, RADLEX, LOINC, and custom Ashmatics ontologies.

Modules:
    terms: Term resolution and management (MongoDB-based), ASHCAI schemas
    categories: Hierarchical category management
    core: External ontology integration (BioPortal), ASHMATICS and ASHCAI ontologies
    tags: Tag management patterns
    storage: MongoDB storage abstractions

Usage:
    from ashmatics_tools.ontology import (
        TermResolver,
        CategoryManager,
        BioPortalClient,
        AshmaticsOntology,
        AshcaiOntology,
    )

    # MongoDB term resolution
    term_resolver = TermResolver(mongodb_client=mongo_client)

    # Hierarchical category management
    category_manager = CategoryManager(
        mongodb_database=mongo_db,
        term_resolver=term_resolver
    )

    # External ontology validation via BioPortal
    bioportal = BioPortalClient(api_key="your-key")
    exists, ontologies = await bioportal.check_term_in_ontology("Breast Cancer")

    # Custom ASHMATICS ontology management (medical imaging AI)
    ashmatics = AshmaticsOntology(mongodb_database=mongo_db)
    concept = await ashmatics.create_concept(
        prefLabel="AI Breast Cancer Detector",
        definition="AI model for detecting breast cancer"
    )

    # ASHCAI governance ontology management (Clinical AI Framework)
    ashcai = AshcaiOntology(mongodb_database=mongo_db)
    policy = await ashcai.create_policy_domain(
        domain_id="MMP-001",
        domain_code="MMP",
        label="Model Monitoring Policy",
        description="Policy governing AI model monitoring"
    )
"""

from .terms.resolver import TermResolver
from .categories.manager import CategoryManager
from .core import BioPortalClient, AshmaticsOntology, AshcaiOntology

__all__ = [
    "TermResolver",
    "CategoryManager",
    "BioPortalClient",
    "AshmaticsOntology",
    "AshcaiOntology",
]

__version__ = "0.4.0"
