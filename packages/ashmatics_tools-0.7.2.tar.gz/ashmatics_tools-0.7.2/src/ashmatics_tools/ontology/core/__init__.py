# Copyright (c) 2025, Asher Informatics PBC
"""
Ontology Core Module - External ontology integration and custom ontology management.

This module provides three key components:

1. BioPortalClient: Interface to NCBO BioPortal API for validating terms against
   external medical ontologies (SNOMED CT, RADLEX, LOINC, NCIT).

2. AshmaticsOntology: Manager for the custom ASHMATICS domain-specific ontology
   for medical imaging AI concepts.

3. AshcaiOntology: Manager for the ASHCAI (Clinical AI Governance) ontology
   for healthcare AI governance concepts (policies, processes, controls, etc.).

Usage:
    from ashmatics_tools.ontology.core import BioPortalClient, AshmaticsOntology, AshcaiOntology

    # External ontology validation
    bioportal = BioPortalClient(api_key="your-key")
    exists, ontologies = await bioportal.check_term_in_ontology("Breast Cancer")

    # Custom ASHMATICS ontology management
    ashmatics = AshmaticsOntology(mongodb_database=db)
    concept = await ashmatics.create_concept(
        prefLabel="AI Breast Cancer Detector",
        definition="AI model for breast cancer detection"
    )

    # ASHCAI governance ontology management
    ashcai = AshcaiOntology(mongodb_database=db)
    policy = await ashcai.create_policy_domain(
        domain_id="MMP-001",
        domain_code="MMP",
        label="Model Monitoring Policy",
        description="Policy governing AI model monitoring"
    )
"""

from .bioportal_client import BioPortalClient, BioPortalAPIError
from .ashmatics_ontology import AshmaticsOntology, AshmaticsOntologyError
from .ashcai_ontology import AshcaiOntology, AshcaiOntologyError

__all__ = [
    "BioPortalClient",
    "BioPortalAPIError",
    "AshmaticsOntology",
    "AshmaticsOntologyError",
    "AshcaiOntology",
    "AshcaiOntologyError",
]
