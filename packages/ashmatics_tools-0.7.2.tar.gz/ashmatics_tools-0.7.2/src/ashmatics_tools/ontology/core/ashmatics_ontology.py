# Copyright (c) 2025, Asher Informatics PBC
"""
AshmaticsOntology - Manager for the custom ASHMATICS domain ontology.

This module provides functionality for creating and managing the ASHMATICS
custom ontology for medical imaging AI. The ontology represents domain-specific
concepts like Product, AI Application, AI Model, etc. with their relationships
and properties.

Usage:
    from ashmatics_tools.ontology.core import AshmaticsOntology
    from motor.motor_asyncio import AsyncIOMotorClient

    client = AsyncIOMotorClient("mongodb://localhost:27017")
    db = client["ashmatics_ontology"]

    ontology = AshmaticsOntology(
        mongodb_database=db,
        ontology_version="v20250616"
    )

    # Initialize ontology
    await ontology.initialize_ontology()

    # Create a concept
    concept = await ontology.create_concept(
        prefLabel="AI Breast Cancer Detector",
        definition="AI model for detecting breast cancer in mammograms",
        concept_type="technical"
    )

    # Search concepts
    results = await ontology.search_concepts(query="breast cancer")
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from zoneinfo import ZoneInfo

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

# Setup logging
logger = logging.getLogger(__name__)


class AshmaticsOntologyError(Exception):
    """Exception raised for ASHMATICS ontology errors"""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"ASHMATICS Ontology Error {status_code}: {detail}")


def load_ontology_definition(
    version: str = "v20250616", ontology_path: Path | None = None
) -> dict[str, Any]:
    """
    Load the ASHMATICS ontology definition from JSON file.

    Args:
        version: Version of the ontology to load
        ontology_path: Optional path to ontology file (defaults to package data/)

    Returns:
        Dict containing the ontology definition

    Raises:
        FileNotFoundError: If the ontology file doesn't exist
        ValueError: If the JSON is invalid or missing required keys
    """
    try:
        # Construct filename
        filename = f"ashmatics-ontology-{version}.json"

        if ontology_path:
            ontology_file = ontology_path / filename
        else:
            # Look in package data directory
            package_dir = Path(__file__).parent.parent
            ontology_file = package_dir / "data" / filename

            # Fallback to current working directory
            if not ontology_file.exists():
                ontology_file = Path.cwd() / filename

        if not ontology_file.exists():
            raise FileNotFoundError(f"Ontology file not found: {filename}")

        # Load and parse JSON
        with open(ontology_file, encoding="utf-8") as f:
            ontology_data = json.load(f)

        # Validate required keys
        required_keys = [
            "ontology",
            "semantic_types",
            "relationship_types",
            "core_concepts",
            "id_ranges",
        ]
        missing_keys = [key for key in required_keys if key not in ontology_data]

        if missing_keys:
            raise ValueError(f"Missing required keys: {missing_keys}")

        logger.info(f"Loaded ASHMATICS ontology {version} from {ontology_file}")
        return ontology_data

    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in ontology file: {e}")
        raise ValueError(f"Invalid JSON in ontology file: {e}")
    except Exception as e:
        logger.error(f"Error loading ontology definition: {e}")
        raise


class AshmaticsOntology:
    """
    Manager for the ASHMATICS custom ontology.

    Provides functionality to create, update, query, and manage custom
    ontology concepts specific to the medical imaging AI domain.
    """

    def __init__(
        self,
        mongodb_database: AsyncIOMotorDatabase,
        ontology_version: str = "v20250616",
        ontology_path: Path | None = None,
    ):
        """
        Initialize the ASHMATICS ontology manager.

        Args:
            mongodb_database: MongoDB database instance
            ontology_version: Version of the ontology to load
            ontology_path: Optional path to ontology definition file
        """
        self.db = mongodb_database
        self.ontology_collection = self.db.ashmatics_ontology
        self.id_counter_collection = self.db.ashmatics_id_counters

        # Load ontology definition
        try:
            self.ontology_data = load_ontology_definition(
                ontology_version, ontology_path
            )
            self.ontology_metadata = self.ontology_data["ontology"]
            self.ontology_version = self.ontology_metadata.get(
                "version", ontology_version
            )
            self.ontology_revision = self.ontology_metadata.get("revision", "1.0")

            logger.info(
                f"Loaded ASHMATICS ontology version {self.ontology_version}, "
                f"revision {self.ontology_revision}"
            )

        except (FileNotFoundError, ValueError) as e:
            logger.error(f"Failed to load ontology definition: {e}")
            # Fallback to minimal structures
            self.ontology_data = {
                "ontology": {"version": ontology_version, "revision": "1.0"},
                "semantic_types": {},
                "relationship_types": [],
                "core_concepts": [],
                "id_ranges": {
                    "core": {"start": 1000, "end": 1999},
                    "regulatory": {"start": 2000, "end": 2999},
                    "technical": {"start": 3000, "end": 3999},
                    "clinical": {"start": 4000, "end": 4999},
                    "value": {"start": 5000, "end": 9999},
                    "instance": {"start": 10000, "end": 99999},
                },
            }
            self.ontology_metadata = self.ontology_data["ontology"]
            self.ontology_version = ontology_version
            self.ontology_revision = "1.0"

        # Load ontology components
        self.id_ranges = self._convert_id_ranges(self.ontology_data["id_ranges"])
        self.semantic_types = self.ontology_data["semantic_types"]
        self.core_concepts = self.ontology_data["core_concepts"]
        self.relationship_types = self.ontology_data["relationship_types"]

    def _convert_id_ranges(
        self, id_ranges_data: dict[str, Any]
    ) -> dict[str, tuple[int, int]]:
        """
        Convert ID ranges from JSON format to tuple format.

        Args:
            id_ranges_data: Dictionary with dict/list values from JSON

        Returns:
            Dictionary with tuple values (start, end)
        """
        converted = {}
        for concept_type, range_data in id_ranges_data.items():
            try:
                if isinstance(range_data, dict) and "start" in range_data:
                    converted[concept_type] = (
                        range_data["start"],
                        range_data["end"],
                    )
                elif isinstance(range_data, list) and len(range_data) == 2:
                    converted[concept_type] = (range_data[0], range_data[1])
                else:
                    raise ValueError("Invalid range format")
            except (KeyError, TypeError, ValueError) as e:
                logger.warning(f"Invalid ID range for {concept_type}: {e}")
                converted[concept_type] = (1000, 1999)  # Default range

        return converted

    def get_ontology_info(self) -> dict[str, Any]:
        """
        Get information about the loaded ontology.

        Returns:
            Dictionary containing ontology metadata and component counts
        """
        return {
            "version": self.ontology_version,
            "revision": self.ontology_revision,
            "metadata": self.ontology_metadata,
            "loaded_components": {
                "semantic_types_count": len(self.semantic_types),
                "relationship_types_count": len(self.relationship_types),
                "core_concepts_count": len(self.core_concepts),
                "id_ranges": list(self.id_ranges.keys()),
            },
        }

    def reload_ontology(
        self, version: str | None = None, ontology_path: Path | None = None
    ) -> bool:
        """
        Reload the ontology definition from file.

        Args:
            version: Optional version to load (defaults to current version)
            ontology_path: Optional path to ontology file

        Returns:
            True if reload was successful
        """
        try:
            version_to_load = version or self.ontology_version

            # Load new ontology data
            new_ontology_data = load_ontology_definition(version_to_load, ontology_path)

            # Update instance variables
            self.ontology_data = new_ontology_data
            self.ontology_metadata = new_ontology_data["ontology"]
            self.ontology_version = self.ontology_metadata.get(
                "version", version_to_load
            )
            self.ontology_revision = self.ontology_metadata.get("revision", "1.0")

            # Reload components
            self.id_ranges = self._convert_id_ranges(new_ontology_data["id_ranges"])
            self.semantic_types = new_ontology_data["semantic_types"]
            self.core_concepts = new_ontology_data["core_concepts"]
            self.relationship_types = new_ontology_data["relationship_types"]

            logger.info(f"Successfully reloaded ontology to version {self.ontology_version}")
            return True

        except Exception as e:
            logger.error(f"Failed to reload ontology: {e}")
            return False

    async def initialize_ontology(
        self,
        new_semantic_types: dict[str, Any] | None = None,
        new_relationship_types: list[dict[str, Any]] | None = None,
        init_relationships: bool = False,
        override_existing: bool = False,
    ) -> bool:
        """
        Initialize the ASHMATICS ontology with core concepts.

        Args:
            new_semantic_types: Additional semantic types to add
            new_relationship_types: Additional relationship types to add
            init_relationships: Whether to initialize relationship types
            override_existing: Whether to override existing concepts

        Returns:
            True if initialization was successful
        """
        try:
            # Check if ontology already exists
            count = await self.ontology_collection.count_documents({})
            if count > 0:
                logger.info("ASHMATICS ontology already initialized")

                if override_existing:
                    logger.info("Overriding existing concepts")
                    await self.ontology_collection.delete_many({})
                else:
                    logger.info("Skipping initialization")
                    return False

            ont_doc_count = 0

            # Create relationship types
            if init_relationships or new_relationship_types:
                relationship_types = self.relationship_types.copy()
                if new_relationship_types:
                    relationship_types.extend(new_relationship_types)

                for rel_type in relationship_types:
                    await self.create_relationship_type(rel_type)
                    logger.info(f"Created relationship type: {rel_type['name']}")
                    ont_doc_count += 1

            # Create semantic types
            semantic_types = self.semantic_types.copy()
            if new_semantic_types:
                semantic_types.update(new_semantic_types)

            for type_id, type_data in semantic_types.items():
                await self.create_semantic_type(
                    type_id=type_id,
                    prefLabel=type_data["prefLabel"],
                    definition=type_data["definition"],
                    umls_equivalent=type_data.get("umls_equivalent", False),
                    parent=type_data.get("parent"),
                    mappings=type_data.get("mappings"),
                )
                logger.info(f"Created semantic type: {type_data['prefLabel']}")
                ont_doc_count += 1

            # Create core concepts
            for concept in self.core_concepts:
                await self.create_concept(
                    prefLabel=concept["prefLabel"],
                    definition=concept["definition"],
                    category_type="concept",
                    concept_type=concept.get("concept_type", "core"),
                    semantic_type=concept.get("semantic_type"),
                    properties={"allowed_values": concept.get("allowed_values", [])},
                )
                logger.info(f"Created concept: {concept['prefLabel']}")
                ont_doc_count += 1

            logger.info(
                f"Successfully initialized ASHMATICS ontology: {ont_doc_count} documents"
            )
            return True

        except Exception as e:
            logger.error(f"Error initializing ontology: {str(e)}")
            return False

    async def create_concept(
        self,
        prefLabel: str,
        definition: str,
        category_type: str = "concept",
        parents: list[str] | None = None,
        concept_type: str = "core",
        properties: dict[str, Any] | None = None,
        semantic_type: str | None = None,
        altLabel: list[str] | None = None,
        mappings: dict[str, str] | None = None,
        creator_id: str = "system",
    ) -> dict[str, Any]:
        """
        Create a new concept in the ASHMATICS ontology.

        Args:
            prefLabel: Primary human-readable label
            definition: Detailed definition
            category_type: Type (concept, relationship, semantic_type)
            parents: List of parent class_ids
            concept_type: Type for ID allocation (core, regulatory, technical, etc.)
            properties: Additional properties
            semantic_type: Reference to semantic type ID
            altLabel: Alternative labels/synonyms
            mappings: External ontology mappings
            creator_id: ID of creator

        Returns:
            New concept with assigned class_id

        Raises:
            AshmaticsOntologyError: If validation fails or creation fails
        """
        if concept_type not in self.id_ranges:
            raise AshmaticsOntologyError(400, f"Invalid concept type: {concept_type}")

        if semantic_type and semantic_type not in self.semantic_types:
            raise AshmaticsOntologyError(400, f"Invalid semantic type: {semantic_type}")

        # Generate unique class_id
        class_id = await self.generate_class_id(concept_type)

        eastern = ZoneInfo("America/New_York")
        now_eastern = datetime.now(eastern)

        concept = {
            "class_id": class_id,
            "prefLabel": prefLabel,
            "altLabel": altLabel or [],
            "definition": definition,
            "category_type": category_type,
            "semantic_type": semantic_type,
            "concept_type": concept_type,
            "parents": parents or [],
            "mappings": mappings or {},
            "properties": properties or {},
            "status": "active",
            "created_at": now_eastern.isoformat(),
            "updated_at": now_eastern.isoformat(),
            "created_by": creator_id,
            "version": 1,
        }

        try:
            result = await self.ontology_collection.insert_one(concept)
            concept["cui"] = str(result.inserted_id)  # MongoDB ObjectId as CUI
            return concept

        except Exception as e:
            logger.error(f"Error creating concept: {str(e)}")
            raise AshmaticsOntologyError(500, f"Error creating concept: {str(e)}")

    async def update_concept(
        self, class_id: str, updates: dict[str, Any]
    ) -> dict[str, Any] | None:
        """
        Update an existing concept.

        Args:
            class_id: The class_id of the concept to update
            updates: Dictionary of fields to update

        Returns:
            Updated concept or None if not found
        """
        try:
            # Don't allow modifying class_id
            updates_copy = updates.copy()
            updates_copy.pop("class_id", None)

            # Set updated timestamp
            eastern = ZoneInfo("America/New_York")
            updates_copy["updated_at"] = datetime.now(eastern).isoformat()

            # Update version
            concept = await self.get_concept(class_id)
            if not concept:
                return None

            updates_copy["version"] = concept.get("version", 0) + 1

            # Update in database
            result = await self.ontology_collection.update_one(
                {"class_id": class_id}, {"$set": updates_copy}
            )

            if result.matched_count == 0:
                return None

            # Get updated concept
            updated = await self.ontology_collection.find_one({"class_id": class_id})
            return updated

        except Exception as e:
            logger.error(f"Error updating concept: {str(e)}")
            raise AshmaticsOntologyError(500, f"Error updating concept: {str(e)}")

    async def deprecate_concept(
        self, class_id: str, reason: str, replacement_id: str | None = None
    ) -> dict[str, Any] | None:
        """
        Deprecate a concept and optionally suggest replacement.

        Args:
            class_id: The class_id to deprecate
            reason: Reason for deprecation
            replacement_id: Optional replacement class_id

        Returns:
            Updated concept with deprecated status
        """
        updates = {
            "status": "deprecated",
            "deprecation_reason": reason,
        }

        if replacement_id:
            updates["replaced_by"] = replacement_id

        return await self.update_concept(class_id, updates)

    async def get_concept(self, class_id: str) -> dict[str, Any] | None:
        """
        Get a concept by class_id.

        Args:
            class_id: The class_id to retrieve

        Returns:
            Concept dictionary or None if not found
        """
        try:
            concept = await self.ontology_collection.find_one({"class_id": class_id})
            return concept

        except Exception as e:
            logger.error(f"Error getting concept: {str(e)}")
            return None

    async def get_all_entities(
        self, category_type: str | None = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        """
        Get all entities, optionally filtered by category type.

        Args:
            category_type: Optional filter (concept, relationship, semantic_type)
            limit: Maximum number of results

        Returns:
            List of entities
        """
        try:
            query = {}
            if category_type:
                query["category_type"] = category_type

            cursor = self.ontology_collection.find(query).limit(limit)
            entities = await cursor.to_list(length=limit)
            return entities

        except Exception as e:
            logger.error(f"Error getting entities: {str(e)}")
            return []

    async def search_concepts(
        self, query: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """
        Search for concepts by text query.

        Args:
            query: Search text
            limit: Maximum results

        Returns:
            List of matching concepts
        """
        try:
            # Search in prefLabel, altLabel, and definition
            search_query = {
                "$or": [
                    {"prefLabel": {"$regex": query, "$options": "i"}},
                    {"altLabel": {"$regex": query, "$options": "i"}},
                    {"definition": {"$regex": query, "$options": "i"}},
                ]
            }

            cursor = self.ontology_collection.find(search_query).limit(limit)
            results = await cursor.to_list(length=limit)
            return results

        except Exception as e:
            logger.error(f"Error searching concepts: {str(e)}")
            return []

    async def get_concept_hierarchy(self, class_id: str) -> dict[str, Any]:
        """
        Get the complete hierarchy for a concept (parents, children, siblings).

        Args:
            class_id: The class_id to get hierarchy for

        Returns:
            Dictionary with hierarchy information
        """
        try:
            concept = await self.get_concept(class_id)
            if not concept:
                return {}

            # Get parents
            parents = []
            if concept.get("parents"):
                for parent_id in concept["parents"]:
                    parent = await self.get_concept(parent_id)
                    if parent:
                        parents.append(parent)

            # Get children (concepts that list this as parent)
            children_cursor = self.ontology_collection.find(
                {"parents": class_id}
            )
            children = await children_cursor.to_list(length=100)

            # Get siblings (same parents)
            siblings = []
            if concept.get("parents"):
                siblings_cursor = self.ontology_collection.find(
                    {"parents": {"$in": concept["parents"]}, "class_id": {"$ne": class_id}}
                )
                siblings = await siblings_cursor.to_list(length=100)

            return {
                "concept": concept,
                "parents": parents,
                "children": children,
                "siblings": siblings,
            }

        except Exception as e:
            logger.error(f"Error getting hierarchy: {str(e)}")
            return {}

    async def create_relationship(
        self,
        source_id: str,
        target_id: str,
        relationship_type: str,
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Create a relationship between two concepts.

        Args:
            source_id: Source concept class_id
            target_id: Target concept class_id
            relationship_type: Type of relationship
            properties: Additional properties

        Returns:
            Created relationship document
        """
        eastern = ZoneInfo("America/New_York")
        now_eastern = datetime.now(eastern)

        relationship = {
            "category_type": "relationship",
            "source_id": source_id,
            "target_id": target_id,
            "relationship_type": relationship_type,
            "properties": properties or {},
            "created_at": now_eastern.isoformat(),
            "created_by": "system",
        }

        try:
            result = await self.ontology_collection.insert_one(relationship)
            relationship["_id"] = str(result.inserted_id)
            return relationship

        except Exception as e:
            logger.error(f"Error creating relationship: {str(e)}")
            raise AshmaticsOntologyError(500, f"Error creating relationship: {str(e)}")

    async def generate_class_id(self, concept_type: str = "core") -> str:
        """
        Generate a new unique class_id.

        Args:
            concept_type: Type for range allocation

        Returns:
            New unique class_id (format: ASH0001234)

        Raises:
            AshmaticsOntologyError: If ID range exhausted
        """
        try:
            if concept_type not in self.id_ranges:
                raise AshmaticsOntologyError(400, f"Invalid concept type: {concept_type}")

            range_start, range_end = self.id_ranges[concept_type]

            # Get or create counter
            counter = await self.id_counter_collection.find_one(
                {"concept_type": concept_type}
            )

            if counter:
                current_id = counter["current_id"] + 1

                if current_id > range_end:
                    raise AshmaticsOntologyError(
                        500, f"ID range exhausted for: {concept_type}"
                    )

                await self.id_counter_collection.update_one(
                    {"concept_type": concept_type}, {"$set": {"current_id": current_id}}
                )
            else:
                current_id = range_start
                await self.id_counter_collection.insert_one(
                    {
                        "concept_type": concept_type,
                        "current_id": current_id,
                        "range_start": range_start,
                        "range_end": range_end,
                    }
                )

            # Format with leading zeros (7 digits)
            return f"ASH{current_id:07d}"

        except Exception as e:
            logger.error(f"Error generating class_id: {str(e)}")
            raise AshmaticsOntologyError(500, f"Error generating class_id: {str(e)}")

    async def create_relationship_type(self, relationship_type: dict[str, Any]) -> None:
        """
        Create a relationship type in the ontology.

        Args:
            relationship_type: Dictionary defining the relationship type
        """
        try:
            await self.ontology_collection.insert_one(
                {
                    "category_type": "relationship_type",
                    "type_id": relationship_type["type_id"],
                    "name": relationship_type["name"],
                    "inverse": relationship_type.get("inverse"),
                    "source_type": relationship_type.get("source_type"),
                    "target_type": relationship_type.get("target_type"),
                    "created_at": datetime.now(ZoneInfo("America/New_York")).isoformat(),
                    "created_by": "system",
                }
            )
        except Exception as e:
            logger.error(f"Error creating relationship type: {str(e)}")

    async def create_semantic_type(
        self,
        type_id: str,
        prefLabel: str,
        definition: str,
        umls_equivalent: bool = False,
        parent: str | None = None,
        mappings: dict[str, str] | None = None,
    ) -> None:
        """
        Create a semantic type in the ontology.

        Args:
            type_id: Unique identifier
            prefLabel: Name of the semantic type
            definition: Description
            umls_equivalent: Whether it has UMLS equivalent
            parent: Parent semantic type
            mappings: External mappings
        """
        try:
            semantic_type = {
                "type_id": type_id,
                "category_type": "semantic_type",
                "prefLabel": prefLabel,
                "definition": definition,
                "umls_equivalent": umls_equivalent,
                "parent": parent,
                "mappings": mappings or {},
            }
            await self.ontology_collection.insert_one(semantic_type)

        except Exception as e:
            logger.error(f"Error creating semantic type: {str(e)}")

    async def export_ontology(self, format: str = "json") -> dict[str, Any]:
        """
        Export the entire ontology.

        Args:
            format: Export format (json, rdf, owl) - only json supported currently

        Returns:
            Ontology data in requested format
        """
        try:
            cursor = self.ontology_collection.find({})
            concepts = await cursor.to_list(length=None)

            if format.lower() == "json":
                return {
                    "ontology": "ASHMATICS",
                    "version": self.ontology_version,
                    "exported_at": datetime.now().isoformat(),
                    "concepts": concepts,
                }
            else:
                raise AshmaticsOntologyError(400, f"Unsupported format: {format}")

        except Exception as e:
            logger.error(f"Error exporting ontology: {str(e)}")
            raise AshmaticsOntologyError(500, f"Error exporting ontology: {str(e)}")

    async def import_ontology(
        self, ontology_data: dict[str, Any], format: str = "json"
    ) -> bool:
        """
        Import ontology data.

        Args:
            ontology_data: Data to import
            format: Data format (only json supported)

        Returns:
            True if import was successful
        """
        try:
            if format.lower() != "json":
                raise AshmaticsOntologyError(400, f"Unsupported format: {format}")

            if "concepts" not in ontology_data:
                raise AshmaticsOntologyError(400, "Invalid ontology data format")

            # Import concepts
            for concept in ontology_data["concepts"]:
                existing = await self.get_concept(concept["class_id"])

                if existing:
                    await self.update_concept(concept["class_id"], concept)
                else:
                    await self.ontology_collection.insert_one(concept)

            return True

        except Exception as e:
            logger.error(f"Error importing ontology: {str(e)}")
            raise AshmaticsOntologyError(500, f"Error importing ontology: {str(e)}")
