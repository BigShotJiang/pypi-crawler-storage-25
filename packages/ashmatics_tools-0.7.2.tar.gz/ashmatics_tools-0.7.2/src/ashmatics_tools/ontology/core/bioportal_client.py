# Copyright (c) 2025, Asher Informatics PBC
"""
BioPortalClient - Client for NCBO BioPortal API.

This module provides a clean interface to the NCBO BioPortal API for validating
medical terms against external ontologies like SNOMED CT, RADLEX, LOINC, and NCIT.

Usage:
    from ashmatics_tools.ontology.core import BioPortalClient

    client = BioPortalClient(
        api_key="your-api-key",
        supported_ontologies=["SNOMEDCT", "RADLEX"]
    )

    # Check if term exists
    exists, ontologies = await client.check_term_in_ontology("Breast Cancer")

    # Search for classes
    results = await client.search_classes("diabetes", ["SNOMEDCT"])

    # Get hierarchy
    success, children = await client.get_hierarchy(
        class_id="73211009",
        level="children",
        ontology="SNOMEDCT"
    )
"""

import asyncio
import logging
import os
import urllib.parse
from typing import Any, Optional

import httpx

# Setup logging
logger = logging.getLogger(__name__)


class BioPortalAPIError(Exception):
    """Exception raised for BioPortal API errors"""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"BioPortal API Error {status_code}: {detail}")


class BioPortalClient:
    """
    Client for interacting with the NCBO BioPortal API.

    This client provides methods to validate medical terms, search ontologies,
    fetch class hierarchies, and manage synonyms using the BioPortal service.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://data.bioontology.org",
        supported_ontologies: list[str] | None = None,
    ):
        """
        Initialize the BioPortal client.

        Args:
            api_key: BioPortal API key (if None, reads from ONTO_API_KEY env var)
            base_url: Base URL for BioPortal API
            supported_ontologies: List of ontology acronyms to support
        """
        self.api_key = api_key or os.getenv(
            "ONTO_API_KEY", "eb1b237e-2870-4602-9069-344993ef09f8"
        )
        self.base_url = base_url or os.getenv(
            "ONTO_API_URL", "https://data.bioontology.org"
        )
        self.supported_ontologies = supported_ontologies or [
            "SNOMEDCT",
            "RADLEX",
            "LOINC",
            "NCIT",
        ]

    def _format_label(self, text: str) -> str:
        """
        Format a text label for API queries.

        Converts underscores and hyphens to spaces, capitalizes first word,
        and lowercases the rest. This matches SNOMED CT preferred format.

        Args:
            text: Raw text to format

        Returns:
            Formatted text suitable for ontology queries
        """
        if not text:
            return ""

        # Remove leading/trailing whitespace
        text = text.strip()

        # Replace underscores and hyphens with spaces
        text = text.replace("_", " ").replace("-", " ")

        # Split into words
        words = text.split()

        if not words:
            return ""

        # Capitalize first word, lowercase the rest
        formatted_words = [words[0].capitalize()] + [w.lower() for w in words[1:]]

        return " ".join(formatted_words)

    async def check_term_in_ontology(
        self,
        term: str,
        ontologies: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> tuple[bool, list[dict[str, Any]]]:
        """
        Check if a term exists in specified ontologies using BioPortal recommender.

        Args:
            term: The term to validate
            ontologies: List of ontology acronyms to search (defaults to supported_ontologies)
            options: Search options (includeSynonyms, requireExactMatch)

        Returns:
            Tuple of (match_found, list of matching ontologies with scores)

        Raises:
            BioPortalAPIError: If the API request fails
        """
        if not ontologies:
            ontologies = self.supported_ontologies

        if not options:
            options = {
                "includeSynonyms": True,
                "requireExactMatch": True,
            }

        if not term:
            raise BioPortalAPIError(400, "Term cannot be empty")

        formatted_term = self._format_label(term)

        params = {
            "input": formatted_term,
            "apikey": self.api_key,
            "ontologies": ontologies,
            "includeSynonyms": options.get("includeSynonyms", True),
            "requireExactMatch": options.get("requireExactMatch", True),
        }

        try:
            response = await self._make_api_request(endpoint="/recommender", params=params)

            if not response:
                return False, []

            result = response[0]
            normalized_score = result.get("detailResult", {}).get("normalizedScore", 0)

            matching_ontologies = []
            if normalized_score > 0.0:
                for ontology in result.get("ontologies", []):
                    if ontology.get("acronym") in ontologies:
                        matching_ontologies.append(
                            {
                                "ontology": ontology.get("acronym", ""),
                                "norm_score": normalized_score,
                            }
                        )

                # Consider match successful if score > 0.30
                is_match = normalized_score > 0.30

                if is_match:
                    logger.info(
                        f"Term '{term}' found in ontologies with score: {normalized_score}"
                    )
                else:
                    logger.warning(
                        f"Term '{term}' found but with low confidence: {normalized_score}"
                    )

                return is_match, matching_ontologies

            logger.info(f"Term '{term}' not found in specified ontologies")
            return False, []

        except BioPortalAPIError:
            raise
        except Exception as e:
            logger.error(f"Error checking term in ontology: {str(e)}")
            raise BioPortalAPIError(500, f"Unexpected error: {str(e)}")

    async def search_classes(
        self,
        query: str,
        ontologies: list[str] | None = None,
        search_options: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """
        Search for ontology classes using BioPortal search endpoint.

        Args:
            query: Search query string
            ontologies: List of ontology acronyms to search
            search_options: Additional options (require_exact_match, pagesize, etc.)

        Returns:
            List of matching ontology classes

        Raises:
            BioPortalAPIError: If the API request fails
        """
        if not ontologies:
            ontologies = self.supported_ontologies

        if not query:
            raise BioPortalAPIError(400, "Query string cannot be empty")

        formatted_query = self._format_label(query)

        params = {
            "q": formatted_query,
            "apikey": self.api_key,
            "ontologies": ontologies,
        }

        if search_options:
            params.update(search_options)

        try:
            response = await self._make_api_request(endpoint="/search", params=params)

            collection = response.get("collection", [])
            page_count = response.get("pageCount", 1)

            # Fetch additional pages if needed
            if page_count > 1:
                next_page_uri = response.get("links", {}).get("next")
                if next_page_uri:
                    for page in range(2, page_count + 1):
                        page_response = await self._make_api_request(
                            uri=next_page_uri, params={"page": page}
                        )
                        collection.extend(page_response.get("collection", []))

            return collection

        except BioPortalAPIError:
            raise
        except Exception as e:
            logger.error(f"Error searching classes: {str(e)}")
            raise BioPortalAPIError(500, f"Unexpected error: {str(e)}")

    async def fetch_class(
        self,
        class_id: str | None = None,
        class_uri: str | None = None,
        ontology: str = "SNOMEDCT",
    ) -> dict[str, Any] | None:
        """
        Fetch detailed information about an ontology class.

        Args:
            class_id: The ontology concept ID (e.g., SNOMED CT concept ID)
            class_uri: Alternative: Full URI to the class
            ontology: Ontology acronym (default: SNOMEDCT)

        Returns:
            Dictionary containing class details, or None if not found

        Raises:
            BioPortalAPIError: If both class_id and class_uri are provided or neither
        """
        if not class_uri and not class_id:
            raise BioPortalAPIError(
                400, "Either class_id or class_uri must be provided"
            )

        if class_id and class_uri:
            raise BioPortalAPIError(
                400, "Only one of class_id or class_uri should be provided"
            )

        try:
            if class_id:
                endpoint = f"/ontologies/{ontology}/classes/{class_id}"
                params = {"display": "full"}

            else:  # class_uri provided
                # Encode URI as expected by API
                encoded_uri = urllib.parse.quote(class_uri, safe="")
                endpoint = f"/ontologies/{ontology}/classes/{encoded_uri}"
                params = {"display": "full"}

            term_class = await self._make_api_request(endpoint=endpoint, params=params)
            return term_class

        except BioPortalAPIError:
            raise
        except Exception as e:
            logger.error(f"Error fetching class {class_id or class_uri}: {str(e)}")
            return None

    async def get_hierarchy(
        self,
        class_id: str,
        level: str = "children",
        ontology: str = "SNOMEDCT",
        category_mappings: dict[str, str] | None = None,
    ) -> tuple[bool, list[dict[str, Any]] | None]:
        """
        Get hierarchical relationships (children or descendants) for a class.

        Args:
            class_id: The ontology class ID or category key
            level: "children" or "descendants"
            ontology: Ontology acronym
            category_mappings: Optional dict mapping category keys to class IDs

        Returns:
            Tuple of (success, list of child/descendant classes)

        Raises:
            BioPortalAPIError: If level is invalid or API request fails
        """
        if level not in {"children", "descendants"}:
            raise BioPortalAPIError(
                400, "Invalid level. Must be 'children' or 'descendants'"
            )

        if isinstance(ontology, list):
            logger.warning(f"Multiple ontologies provided: {ontology}. Using first.")
            ontology = ontology[0]

        if ontology not in self.supported_ontologies:
            raise BioPortalAPIError(
                400,
                f"Unsupported ontology: {ontology}. Supported: {self.supported_ontologies}",
            )

        # Format class_id if it looks like a category key
        formatted_id = self._format_label(class_id)

        # Try to resolve category key to class_id if mappings provided
        if category_mappings and formatted_id in category_mappings:
            resolved_class_id = category_mappings[formatted_id]
        else:
            # Try searching for the class
            try:
                search_results = await self.search_classes(
                    formatted_id, [ontology], {"require_exact_match": True}
                )
                if search_results:
                    class_id_uri = search_results[0].get("@id", "")
                    resolved_class_id = class_id_uri.split("/")[-1] if class_id_uri else None
                else:
                    resolved_class_id = class_id  # Use as-is
            except Exception:
                resolved_class_id = class_id  # Fallback to original

        if not resolved_class_id:
            logger.error(f"Could not resolve class ID for: {class_id}")
            return False, None

        try:
            # First fetch the class to get hierarchy links
            endpoint = f"/ontologies/{ontology}/classes/{resolved_class_id}"
            response = await self._make_api_request(
                endpoint=endpoint,
                params={
                    "display": "full",
                    "includeSynonyms": "true",
                    "includeChildren": "true" if level == "children" else "false",
                    "includeDescendants": "true" if level == "descendants" else "false",
                },
            )

            hierarchy_uri = response.get("links", {}).get(level)
            if not hierarchy_uri:
                logger.info(f"No {level} found for class {resolved_class_id}")
                return False, None

            # Fetch hierarchy data
            hierarchy_response = await self._make_api_request(uri=hierarchy_uri)
            page_count = hierarchy_response.get("pageCount", 1)

            if page_count > 1:
                # Fetch all pages
                all_results = list(hierarchy_response.get("collection", []))
                next_page_uri = hierarchy_response.get("links", {}).get("next")

                for page in range(2, page_count + 1):
                    page_response = await self._make_api_request(
                        uri=next_page_uri, params={"page": page}
                    )
                    all_results.extend(page_response.get("collection", []))

                return True, all_results
            else:
                results = hierarchy_response.get("collection", [])
                return True, results

        except BioPortalAPIError:
            raise
        except Exception as e:
            logger.error(f"Error fetching hierarchy for {class_id}: {str(e)}")
            return False, None

    async def get_class_by_label(
        self,
        term_label: str,
        ontologies: list[str] | str | None = None,
        search_options: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """
        Get full ontology class information by searching for a label.

        Args:
            term_label: Label to search for
            ontologies: Ontology(ies) to search in
            search_options: Additional search parameters

        Returns:
            Dictionary with class information including hierarchy links

        Raises:
            BioPortalAPIError: If term_label is empty or API request fails
        """
        if not term_label:
            raise BioPortalAPIError(400, "Term label cannot be empty")

        if not ontologies:
            ontologies = ["SNOMEDCT"]
        elif isinstance(ontologies, str):
            ontologies = [ontologies]

        formatted_label = self._format_label(term_label)

        try:
            search_results = await self.search_classes(
                formatted_label, ontologies, search_options
            )

            if not search_results:
                return None

            # Get first result (most relevant)
            first_result = search_results[0]

            # Extract basic info
            class_id_uri = first_result.get("@id", "")
            class_id = class_id_uri.split("/")[-1] if class_id_uri else None

            if not class_id:
                return None

            # Fetch full class details
            ontology_class = await self.fetch_class(
                class_id=class_id, ontology=ontologies[0]
            )

            if not ontology_class:
                return None

            # Extract hierarchy links
            links = ontology_class.get("links", {})

            # Build comprehensive response
            return {
                "prefLabel": first_result.get("prefLabel", ""),
                "class_id": class_id,
                "cui": first_result.get("cui", [""])[0]
                if isinstance(first_result.get("cui"), list)
                else first_result.get("cui", ""),
                "definition": first_result.get("definition", ""),
                "semantic_type": first_result.get("semanticType", [""])[0]
                if isinstance(first_result.get("semanticType"), list)
                else first_result.get("semanticType", ""),
                "synonyms": first_result.get("synonym", []),
                "@id": class_id_uri,
                "links": {
                    "children": links.get("children"),
                    "descendants": links.get("descendants"),
                    "parents": links.get("parents"),
                    "tree": links.get("tree"),
                },
            }

        except BioPortalAPIError:
            raise
        except Exception as e:
            logger.error(f"Error getting class by label: {str(e)}")
            raise BioPortalAPIError(500, f"Unexpected error: {str(e)}")

    async def get_synonyms(
        self, class_id: str, ontology: str = "SNOMEDCT"
    ) -> list[str]:
        """
        Get synonyms for a specific term.

        Args:
            class_id: The ontology concept ID
            ontology: Ontology acronym (default: SNOMEDCT)

        Returns:
            List of synonym strings
        """
        try:
            endpoint = f"/ontologies/{ontology}/classes/{class_id}"
            term_data = await self._make_api_request(
                endpoint=endpoint,
                params={"display": "full", "includeSynonyms": "true"},
            )

            # Extract synonyms (handle different response formats)
            synonyms = term_data.get("synonym", []) or term_data.get("synonyms", [])

            # Clean and standardize
            cleaned = [syn.strip() for syn in synonyms if syn and isinstance(syn, str)]
            return cleaned

        except Exception as e:
            logger.error(f"Error fetching synonyms for {class_id}: {str(e)}")
            return []

    async def search_by_synonym(
        self, synonym: str, ontology: str = "SNOMEDCT"
    ) -> list[dict[str, str]]:
        """
        Find terms that have a specific synonym.

        Args:
            synonym: Synonym text to search for
            ontology: Ontology acronym (default: SNOMEDCT)

        Returns:
            List of matching terms with class_id, label, ontology
        """
        if not synonym:
            raise BioPortalAPIError(400, "Synonym cannot be empty")

        formatted_synonym = self._format_label(synonym)

        try:
            response = await self._make_api_request(
                endpoint="/search",
                params={
                    "q": formatted_synonym,
                    "ontologies": ontology,
                    "require_exact_match": "true",
                    "include_synonyms": "true",
                },
            )

            matches = []
            for item in response.get("collection", []):
                # Check if synonym matches
                item_synonyms = item.get("synonym", []) + item.get("synonyms", [])
                if any(
                    syn.lower() == formatted_synonym.lower() for syn in item_synonyms
                ):
                    matches.append(
                        {
                            "class_id": item.get("@id", "").split("/")[-1],
                            "label": item.get("prefLabel", ""),
                            "ontology": ontology,
                        }
                    )

            return matches

        except Exception as e:
            logger.error(f"Error searching for synonym '{synonym}': {str(e)}")
            return []

    async def _make_api_request(
        self,
        uri: str | None = None,
        endpoint: str | None = None,
        params: dict[str, Any] | None = None,
        method: str = "GET",
        timeout: int = 30,
        retry_attempts: int = 3,
    ) -> dict[str, Any]:
        """
        Internal method to make HTTP requests to BioPortal API.

        Args:
            uri: Full URI (overrides endpoint)
            endpoint: API endpoint path
            params: Query parameters
            method: HTTP method (GET, POST)
            timeout: Request timeout in seconds
            retry_attempts: Number of retries for transient failures

        Returns:
            Parsed JSON response

        Raises:
            BioPortalAPIError: For API errors
        """
        # Construct URL
        if uri:
            url = uri
        elif endpoint:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
        else:
            raise BioPortalAPIError(400, "Either uri or endpoint must be provided")

        # Ensure API key is included
        request_params = params.copy() if params else {}
        if "apikey" not in request_params:
            request_params["apikey"] = self.api_key

        logger.debug(f"Making {method} request to {url}")

        attempts = 0
        last_exception = None

        while attempts < retry_attempts:
            try:
                async with httpx.AsyncClient(timeout=timeout) as client:
                    if method.upper() == "GET":
                        response = await client.get(url, params=request_params)
                    elif method.upper() == "POST":
                        response = await client.post(url, json=request_params)
                    else:
                        raise BioPortalAPIError(
                            500, f"Unsupported HTTP method: {method}"
                        )

                    response.raise_for_status()
                    return response.json()

            except httpx.TimeoutException as e:
                attempts += 1
                last_exception = e
                wait_time = 2**attempts  # Exponential backoff
                logger.warning(
                    f"Timeout (attempt {attempts}/{retry_attempts}). "
                    f"Retrying in {wait_time}s..."
                )
                await asyncio.sleep(wait_time)

            except httpx.HTTPStatusError as e:
                status_code = e.response.status_code

                # Handle specific status codes
                if status_code == 401:
                    raise BioPortalAPIError(401, "Authentication failed. Check API key.")
                elif status_code == 404:
                    raise BioPortalAPIError(404, f"Resource not found: {endpoint or uri}")
                elif status_code == 429:
                    raise BioPortalAPIError(
                        429, "Rate limit exceeded. Try again later."
                    )
                elif status_code >= 500:
                    # Retry server errors
                    attempts += 1
                    last_exception = e
                    wait_time = 2**attempts
                    logger.warning(
                        f"Server error (attempt {attempts}/{retry_attempts}). "
                        f"Retrying in {wait_time}s..."
                    )
                    await asyncio.sleep(wait_time)
                else:
                    # Other client errors - don't retry
                    raise BioPortalAPIError(status_code, e.response.text)

            except httpx.RequestError as e:
                attempts += 1
                last_exception = e
                wait_time = 2**attempts
                logger.warning(
                    f"Request error (attempt {attempts}/{retry_attempts}). "
                    f"Retrying in {wait_time}s..."
                )
                await asyncio.sleep(wait_time)

        # All retries exhausted
        logger.error(f"All {retry_attempts} attempts failed: {str(last_exception)}")
        raise BioPortalAPIError(
            500, f"Failed to connect to BioPortal after {retry_attempts} attempts"
        )
