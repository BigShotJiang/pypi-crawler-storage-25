# Copyright (c) 2025-2026, Asher Informatics PBC
"""
AshcaiOntology - Manager for the ASHCAI Clinical AI Governance ontology.

Last Updated: 2026-01-20
- Added documentation clarifying _id uniqueness strategy and index design decisions

This module provides functionality for creating and managing the ASHCAI
(AshMatics Clinical AI Governance) ontology for healthcare AI governance.
The ontology represents domain-specific concepts like PolicyDomain, ProcessDomain,
BasePractice, SOPTemplate, WorkProductTemplate, ExemplarControl, etc.

The ASHCAI ontology uses natural business IDs (MMP-001, MON, SOP-MON-01) rather
than auto-generated numeric IDs, with `ontology: "ashcai"` for type discrimination.

ID Strategy & Uniqueness:
    All ASHCAI entities use `_id` as the natural business ID field. MongoDB
    automatically enforces uniqueness on `_id` (primary key), so no explicit
    unique index is needed for the primary identifier. Additional unique
    constraints are only added where a secondary field must also be unique
    (e.g., PolicyDomain.domainCode).

Usage:
    from ashmatics_tools.ontology.core import AshcaiOntology
    from motor.motor_asyncio import AsyncIOMotorClient

    client = AsyncIOMotorClient("mongodb://localhost:27017")
    db = client["ashmatics_knowledgebase"]

    ontology = AshcaiOntology(
        mongodb_database=db,
        ontology_version="v1.0"
    )

    # Initialize ontology
    await ontology.initialize_ontology()

    # Create a policy domain
    policy = await ontology.create_policy_domain(
        domain_id="MMP-001",
        domain_code="MMP",
        label="Model Monitoring Policy",
        description="Policy governing AI model monitoring requirements"
    )

    # Create a process domain
    process = await ontology.create_process_domain(
        domain_id="MON",
        label="Model Monitoring",
        primary_function="Continuous monitoring of AI model performance"
    )

    # Link policy to process
    await ontology.link_policy_to_process("MMP-001", "MON")
"""

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Literal
from zoneinfo import ZoneInfo

from motor.motor_asyncio import AsyncIOMotorDatabase

# Setup logging
logger = logging.getLogger(__name__)


class AshcaiOntologyError(Exception):
    """Exception raised for ASHCAI ontology errors"""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"ASHCAI Ontology Error {status_code}: {detail}")


def load_ashcai_ontology_definition(
    version: str = "v1.0", ontology_path: Path | None = None
) -> dict[str, Any]:
    """
    Load the ASHCAI ontology definition from JSON file.

    Args:
        version: Version of the ontology to load
        ontology_path: Optional path to ontology file (defaults to package data/)

    Returns:
        Dict containing the ontology definition

    Raises:
        FileNotFoundError: If the ontology file doesn't exist
        ValueError: If the JSON is invalid or missing required keys
    """
    try:
        # Construct filename
        filename = f"ashcai-ontology-{version}.json"

        if ontology_path:
            ontology_file = ontology_path / filename
        else:
            # Look in package data directory
            package_dir = Path(__file__).parent.parent
            ontology_file = package_dir / "data" / filename

            # Fallback to current working directory
            if not ontology_file.exists():
                ontology_file = Path.cwd() / filename

        if not ontology_file.exists():
            raise FileNotFoundError(f"ASHCAI ontology file not found: {filename}")

        # Load and parse JSON
        with open(ontology_file, encoding="utf-8") as f:
            ontology_data = json.load(f)

        # Validate required keys
        required_keys = [
            "ontology",
            "semantic_types",
            "relationship_types",
            "id_patterns",
        ]
        missing_keys = [key for key in required_keys if key not in ontology_data]

        if missing_keys:
            raise ValueError(f"Missing required keys: {missing_keys}")

        logger.info(f"Loaded ASHCAI ontology {version} from {ontology_file}")
        return ontology_data

    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in ontology file: {e}")
        raise ValueError(f"Invalid JSON in ontology file: {e}")
    except Exception as e:
        logger.error(f"Error loading ASHCAI ontology definition: {e}")
        raise


class AshcaiOntology:
    """
    Manager for the ASHCAI Clinical AI Governance ontology.

    Provides functionality to create, update, query, and manage governance
    concepts specific to the Clinical AI Framework domain.

    Key Features:
    - Natural business IDs (MMP-001, MON, SOP-MON-01) instead of auto-generated IDs
    - Type discrimination via `ontology: "ashcai"` field
    - Bidirectional relationship management
    - Traversal helpers for policy hierarchies and regulatory crosswalks
    - OWL/RDF export utilities
    """

    # Collection names for ASHCAI entities
    COLLECTIONS = {
        "policy_domains": "ashcai_policy_domains",
        "process_domains": "ashcai_process_domains",
        "base_practices": "ashcai_base_practices",
        "sop_templates": "ashcai_sop_templates",
        "work_product_templates": "ashcai_work_product_templates",
        "exemplar_controls": "ashcai_exemplar_controls",
        "regulatory_frameworks": "ashcai_regulatory_frameworks",
        "regulatory_requirements": "ashcai_regulatory_requirements",
        "relationships": "ashcai_relationships",
        "regulatory_crosswalks": "ashcai_regulatory_crosswalks",
    }

    # Namespace for OWL/RDF export
    NAMESPACE = "http://asherinformatics.com/ontology/ashcai/"

    def __init__(
        self,
        mongodb_database: AsyncIOMotorDatabase,
        ontology_version: str = "v1.0",
        ontology_path: Path | None = None,
    ):
        """
        Initialize the ASHCAI ontology manager.

        Args:
            mongodb_database: MongoDB database instance
            ontology_version: Version of the ontology to load
            ontology_path: Optional path to ontology definition file
        """
        self.db = mongodb_database
        self.ontology_version = ontology_version

        # Load ontology definition
        try:
            self.ontology_data = load_ashcai_ontology_definition(
                ontology_version, ontology_path
            )
            self.ontology_metadata = self.ontology_data["ontology"]
            self.semantic_types = self.ontology_data["semantic_types"]
            self.relationship_types = {
                rt["prefLabel"]: rt for rt in self.ontology_data["relationship_types"]
            }
            self.id_patterns = self.ontology_data["id_patterns"]
            self.id_ranges = self.ontology_data.get("id_ranges", {})

            logger.info(
                f"Loaded ASHCAI ontology version {self.ontology_version}, "
                f"{len(self.semantic_types)} semantic types, "
                f"{len(self.relationship_types)} relationship types"
            )

        except (FileNotFoundError, ValueError) as e:
            logger.error(f"Failed to load ASHCAI ontology definition: {e}")
            raise

        # Initialize collection references
        self._init_collections()

    def _init_collections(self):
        """Initialize MongoDB collection references."""
        self.policy_domains = self.db[self.COLLECTIONS["policy_domains"]]
        self.process_domains = self.db[self.COLLECTIONS["process_domains"]]
        self.base_practices = self.db[self.COLLECTIONS["base_practices"]]
        self.sop_templates = self.db[self.COLLECTIONS["sop_templates"]]
        self.work_product_templates = self.db[self.COLLECTIONS["work_product_templates"]]
        self.exemplar_controls = self.db[self.COLLECTIONS["exemplar_controls"]]
        self.regulatory_frameworks = self.db[self.COLLECTIONS["regulatory_frameworks"]]
        self.regulatory_requirements = self.db[self.COLLECTIONS["regulatory_requirements"]]
        self.relationships = self.db[self.COLLECTIONS["relationships"]]

    def _get_timestamp(self) -> str:
        """Get current timestamp in Eastern timezone."""
        eastern = ZoneInfo("America/New_York")
        return datetime.now(eastern).isoformat()

    def _validate_id(self, entity_type: str, entity_id: str) -> bool:
        """
        Validate that an ID matches the expected pattern for its entity type.

        Args:
            entity_type: Type of entity (PolicyDomain, ProcessDomain, etc.)
            entity_id: The ID to validate

        Returns:
            True if valid, False otherwise
        """
        if entity_type not in self.id_patterns:
            logger.warning(f"No ID pattern defined for entity type: {entity_type}")
            return True  # Allow if no pattern defined

        pattern = self.id_patterns[entity_type]["pattern"]
        return bool(re.match(pattern, entity_id))

    def _create_base_document(
        self,
        entity_id: str,
        entity_type: str,
        semantic_type: str,
        label: str,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a base document with common fields.

        Args:
            entity_id: Natural business ID
            entity_type: Type of entity
            semantic_type: Semantic type ID (T92xx)
            label: Human-readable label
            **kwargs: Additional fields

        Returns:
            Base document dictionary
        """
        now = self._get_timestamp()
        doc = {
            "_id": entity_id,
            "ontology": "ashcai",
            "entity_type": entity_type,
            "semantic_type": semantic_type,
            "prefLabel": label,
            "status": "active",
            "created_at": now,
            "updated_at": now,
            "created_by": kwargs.pop("created_by", "system"),
            "version": 1,
        }
        doc.update(kwargs)
        return doc

    def get_ontology_info(self) -> dict[str, Any]:
        """
        Get information about the loaded ontology.

        Returns:
            Dictionary containing ontology metadata and component counts
        """
        return {
            "name": "ASHCAI",
            "version": self.ontology_version,
            "namespace": self.NAMESPACE,
            "metadata": self.ontology_metadata,
            "loaded_components": {
                "semantic_types_count": len(self.semantic_types),
                "relationship_types_count": len(self.relationship_types),
                "id_patterns": list(self.id_patterns.keys()),
            },
        }

    # =========================================================================
    # POLICY DOMAIN OPERATIONS
    # =========================================================================

    async def create_policy_domain(
        self,
        domain_id: str,
        domain_code: str,
        label: str,
        description: str,
        framework_version: str = "v0.8.0",
        specifies: list[str] | None = None,
        validated_by: list[str] | None = None,
        overview_summary: str | None = None,
        template_path: str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new policy domain.

        Args:
            domain_id: Natural business ID (e.g., "MMP-001")
            domain_code: Short code (e.g., "MMP")
            label: Human-readable label
            description: Full description
            framework_version: CAI Framework version
            specifies: List of process domain IDs this policy specifies
            validated_by: List of exemplar control IDs that validate this policy
            overview_summary: Path to overview summary document
            template_path: Path to policy template

        Returns:
            Created policy domain document

        Raises:
            AshcaiOntologyError: If validation fails or creation fails
        """
        if not self._validate_id("PolicyDomain", domain_id):
            raise AshcaiOntologyError(
                400, f"Invalid PolicyDomain ID format: {domain_id}"
            )

        # Check for existing
        existing = await self.policy_domains.find_one({"_id": domain_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"PolicyDomain already exists: {domain_id}"
            )

        doc = self._create_base_document(
            entity_id=domain_id,
            entity_type="PolicyDomain",
            semantic_type="T9202",
            label=label,
            domainCode=domain_code,
            description=description,
            frameworkVersion=framework_version,
            specifies=specifies or [],
            validatedBy=validated_by or [],
            hasOverviewSummary=overview_summary,
            hasTemplate=template_path,
            **kwargs,
        )

        try:
            await self.policy_domains.insert_one(doc)
            logger.info(f"Created PolicyDomain: {domain_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating PolicyDomain: {e}")
            raise AshcaiOntologyError(500, f"Error creating PolicyDomain: {e}")

    async def get_policy_domain(self, domain_id: str) -> dict[str, Any] | None:
        """Get a policy domain by ID."""
        return await self.policy_domains.find_one({"_id": domain_id})

    async def list_policy_domains(self, limit: int = 100) -> list[dict[str, Any]]:
        """List all policy domains."""
        cursor = self.policy_domains.find({"status": "active"}).limit(limit)
        return await cursor.to_list(length=limit)

    # =========================================================================
    # PROCESS DOMAIN OPERATIONS
    # =========================================================================

    async def create_process_domain(
        self,
        domain_id: str,
        label: str,
        primary_function: str,
        description: str | None = None,
        integrates_with: list[str] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new process domain.

        Args:
            domain_id: Natural business ID (e.g., "MON")
            label: Human-readable label
            primary_function: Primary function description
            description: Full description
            integrates_with: List of other process domain IDs this integrates with

        Returns:
            Created process domain document
        """
        if not self._validate_id("ProcessDomain", domain_id):
            raise AshcaiOntologyError(
                400, f"Invalid ProcessDomain ID format: {domain_id}"
            )

        existing = await self.process_domains.find_one({"_id": domain_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"ProcessDomain already exists: {domain_id}"
            )

        doc = self._create_base_document(
            entity_id=domain_id,
            entity_type="ProcessDomain",
            semantic_type="T9203",
            label=label,
            primaryFunction=primary_function,
            description=description or "",
            integratesWith=integrates_with or [],
            **kwargs,
        )

        try:
            await self.process_domains.insert_one(doc)
            logger.info(f"Created ProcessDomain: {domain_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating ProcessDomain: {e}")
            raise AshcaiOntologyError(500, f"Error creating ProcessDomain: {e}")

    async def get_process_domain(self, domain_id: str) -> dict[str, Any] | None:
        """Get a process domain by ID."""
        return await self.process_domains.find_one({"_id": domain_id})

    async def list_process_domains(self, limit: int = 100) -> list[dict[str, Any]]:
        """List all process domains."""
        cursor = self.process_domains.find({"status": "active"}).limit(limit)
        return await cursor.to_list(length=limit)

    # =========================================================================
    # BASE PRACTICE OPERATIONS
    # =========================================================================

    async def create_base_practice(
        self,
        practice_id: str,
        label: str,
        process_domain: str,
        duration: str | None = None,
        sequence_order: int | None = None,
        description: str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new base practice.

        Args:
            practice_id: Natural business ID (e.g., "MON.BP01")
            label: Human-readable label
            process_domain: Parent process domain ID
            duration: Expected duration
            sequence_order: Order within the process domain
            description: Full description

        Returns:
            Created base practice document
        """
        if not self._validate_id("BasePractice", practice_id):
            raise AshcaiOntologyError(
                400, f"Invalid BasePractice ID format: {practice_id}"
            )

        existing = await self.base_practices.find_one({"_id": practice_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"BasePractice already exists: {practice_id}"
            )

        doc = self._create_base_document(
            entity_id=practice_id,
            entity_type="BasePractice",
            semantic_type="T9204",
            label=label,
            processDomain=process_domain,
            duration=duration,
            sequenceOrder=sequence_order,
            description=description or "",
            **kwargs,
        )

        try:
            await self.base_practices.insert_one(doc)
            logger.info(f"Created BasePractice: {practice_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating BasePractice: {e}")
            raise AshcaiOntologyError(500, f"Error creating BasePractice: {e}")

    async def get_base_practice(self, practice_id: str) -> dict[str, Any] | None:
        """Get a base practice by ID."""
        return await self.base_practices.find_one({"_id": practice_id})

    async def list_base_practices(
        self, process_domain: str | None = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        """List base practices, optionally filtered by process domain."""
        query: dict[str, Any] = {"status": "active"}
        if process_domain:
            query["processDomain"] = process_domain
        cursor = self.base_practices.find(query).limit(limit)
        return await cursor.to_list(length=limit)

    # =========================================================================
    # SOP TEMPLATE OPERATIONS
    # =========================================================================

    async def create_sop_template(
        self,
        sop_id: str,
        label: str,
        purpose: str,
        base_practice: str | None = None,
        produces: list[str] | None = None,
        requires_tools: list[str] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new SOP template.

        Args:
            sop_id: Natural business ID (e.g., "SOP-MON-01")
            label: Human-readable label
            purpose: Purpose statement
            base_practice: ID of the base practice this SOP realizes
            produces: List of work product template IDs this SOP produces
            requires_tools: List of tools required

        Returns:
            Created SOP template document
        """
        if not self._validate_id("SOPTemplate", sop_id):
            raise AshcaiOntologyError(
                400, f"Invalid SOPTemplate ID format: {sop_id}"
            )

        existing = await self.sop_templates.find_one({"_id": sop_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"SOPTemplate already exists: {sop_id}"
            )

        doc = self._create_base_document(
            entity_id=sop_id,
            entity_type="SOPTemplate",
            semantic_type="T9205",
            label=label,
            purpose=purpose,
            basePractice=base_practice,
            produces=produces or [],
            requiresTools=requires_tools or [],
            **kwargs,
        )

        try:
            await self.sop_templates.insert_one(doc)
            logger.info(f"Created SOPTemplate: {sop_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating SOPTemplate: {e}")
            raise AshcaiOntologyError(500, f"Error creating SOPTemplate: {e}")

    async def get_sop_template(self, sop_id: str) -> dict[str, Any] | None:
        """Get an SOP template by ID."""
        return await self.sop_templates.find_one({"_id": sop_id})

    # =========================================================================
    # WORK PRODUCT TEMPLATE OPERATIONS
    # =========================================================================

    async def create_work_product_template(
        self,
        wp_id: str,
        label: str,
        evidence_type: str,
        format: str | None = None,
        produced_by: str | None = None,
        serves_as_evidence_for: list[str] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new work product template.

        Args:
            wp_id: Natural business ID (e.g., "WP-MON-01-Dashboard")
            label: Human-readable label
            evidence_type: Type of evidence (e.g., "Document", "Report", "Dashboard")
            format: File format or structure
            produced_by: SOP template ID that produces this work product
            serves_as_evidence_for: List of control IDs this provides evidence for

        Returns:
            Created work product template document
        """
        if not self._validate_id("WorkProductTemplate", wp_id):
            raise AshcaiOntologyError(
                400, f"Invalid WorkProductTemplate ID format: {wp_id}"
            )

        existing = await self.work_product_templates.find_one({"_id": wp_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"WorkProductTemplate already exists: {wp_id}"
            )

        doc = self._create_base_document(
            entity_id=wp_id,
            entity_type="WorkProductTemplate",
            semantic_type="T9206",
            label=label,
            evidenceType=evidence_type,
            format=format,
            producedBy=produced_by,
            servesAsEvidenceFor=serves_as_evidence_for or [],
            **kwargs,
        )

        try:
            await self.work_product_templates.insert_one(doc)
            logger.info(f"Created WorkProductTemplate: {wp_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating WorkProductTemplate: {e}")
            raise AshcaiOntologyError(500, f"Error creating WorkProductTemplate: {e}")

    async def get_work_product_template(self, wp_id: str) -> dict[str, Any] | None:
        """Get a work product template by ID."""
        return await self.work_product_templates.find_one({"_id": wp_id})

    # =========================================================================
    # EXEMPLAR CONTROL OPERATIONS
    # =========================================================================

    async def create_exemplar_control(
        self,
        control_id: str,
        label: str,
        iso_control: str | None = None,
        description: str | None = None,
        evidenced_by: list[str] | None = None,
        validates_policies: list[str] | None = None,
        implements_requirements: list[str] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new exemplar control.

        Args:
            control_id: Natural business ID (e.g., "EXC-A7-04")
            label: Human-readable label
            iso_control: Corresponding ISO 42001 control reference
            description: Full description
            evidenced_by: List of work product template IDs that provide evidence
            validates_policies: List of policy domain IDs this control validates
            implements_requirements: List of regulatory requirement IDs this implements

        Returns:
            Created exemplar control document
        """
        if not self._validate_id("ExemplarControl", control_id):
            raise AshcaiOntologyError(
                400, f"Invalid ExemplarControl ID format: {control_id}"
            )

        existing = await self.exemplar_controls.find_one({"_id": control_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"ExemplarControl already exists: {control_id}"
            )

        doc = self._create_base_document(
            entity_id=control_id,
            entity_type="ExemplarControl",
            semantic_type="T9208",
            label=label,
            isoControl=iso_control,
            description=description or "",
            evidencedBy=evidenced_by or [],
            validatesPolicies=validates_policies or [],
            implementsRequirements=implements_requirements or [],
            **kwargs,
        )

        try:
            await self.exemplar_controls.insert_one(doc)
            logger.info(f"Created ExemplarControl: {control_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating ExemplarControl: {e}")
            raise AshcaiOntologyError(500, f"Error creating ExemplarControl: {e}")

    async def get_exemplar_control(self, control_id: str) -> dict[str, Any] | None:
        """Get an exemplar control by ID."""
        return await self.exemplar_controls.find_one({"_id": control_id})

    # =========================================================================
    # REGULATORY FRAMEWORK OPERATIONS
    # =========================================================================

    async def create_regulatory_framework(
        self,
        framework_id: str,
        label: str,
        authority: str,
        version: str | None = None,
        total_requirements: int | None = None,
        description: str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new regulatory framework.

        Args:
            framework_id: Natural business ID (e.g., "NIST-AI-RMF")
            label: Human-readable label
            authority: Issuing authority
            version: Framework version
            total_requirements: Total number of requirements
            description: Full description

        Returns:
            Created regulatory framework document
        """
        existing = await self.regulatory_frameworks.find_one({"_id": framework_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"RegulatoryFramework already exists: {framework_id}"
            )

        doc = self._create_base_document(
            entity_id=framework_id,
            entity_type="RegulatoryFramework",
            semantic_type="T9209",
            label=label,
            authority=authority,
            frameworkVersion=version,
            totalRequirements=total_requirements,
            description=description or "",
            **kwargs,
        )

        try:
            await self.regulatory_frameworks.insert_one(doc)
            logger.info(f"Created RegulatoryFramework: {framework_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating RegulatoryFramework: {e}")
            raise AshcaiOntologyError(500, f"Error creating RegulatoryFramework: {e}")

    async def get_regulatory_framework(self, framework_id: str) -> dict[str, Any] | None:
        """Get a regulatory framework by ID."""
        return await self.regulatory_frameworks.find_one({"_id": framework_id})

    # =========================================================================
    # REGULATORY REQUIREMENT OPERATIONS
    # =========================================================================

    async def create_regulatory_requirement(
        self,
        requirement_id: str,
        label: str,
        framework_id: str,
        description: str | None = None,
        function: str | None = None,
        category: str | None = None,
        topics: list[str] | None = None,
        crosswalk: dict[str, list[str]] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Create a new regulatory requirement.

        Args:
            requirement_id: Natural business ID (e.g., "NIST-MAP-4.2")
            label: Human-readable label
            framework_id: Parent regulatory framework ID
            description: Full description
            function: Function within framework (e.g., "MAP", "GOVERN")
            category: Category within function (e.g., "MAP-4")
            topics: List of topics covered
            crosswalk: Dict with addressedBy, implementedThrough, operationalizedIn, evidencedBy

        Returns:
            Created regulatory requirement document
        """
        if not self._validate_id("RegulatoryRequirement", requirement_id):
            raise AshcaiOntologyError(
                400, f"Invalid RegulatoryRequirement ID format: {requirement_id}"
            )

        existing = await self.regulatory_requirements.find_one({"_id": requirement_id})
        if existing:
            raise AshcaiOntologyError(
                409, f"RegulatoryRequirement already exists: {requirement_id}"
            )

        crosswalk_data = crosswalk or {}
        doc = self._create_base_document(
            entity_id=requirement_id,
            entity_type="RegulatoryRequirement",
            semantic_type="T9210",
            label=label,
            framework=framework_id,
            function=function,
            category=category,
            description=description or "",
            topics=topics or [],
            crosswalk={
                "addressedBy": crosswalk_data.get("addressedBy", []),
                "implementedThrough": crosswalk_data.get("implementedThrough", []),
                "operationalizedIn": crosswalk_data.get("operationalizedIn", []),
                "evidencedBy": crosswalk_data.get("evidencedBy", []),
            },
            **kwargs,
        )

        try:
            await self.regulatory_requirements.insert_one(doc)
            logger.info(f"Created RegulatoryRequirement: {requirement_id}")
            return doc
        except Exception as e:
            logger.error(f"Error creating RegulatoryRequirement: {e}")
            raise AshcaiOntologyError(500, f"Error creating RegulatoryRequirement: {e}")

    async def get_regulatory_requirement(
        self, requirement_id: str
    ) -> dict[str, Any] | None:
        """Get a regulatory requirement by ID."""
        return await self.regulatory_requirements.find_one({"_id": requirement_id})

    # =========================================================================
    # RELATIONSHIP OPERATIONS
    # =========================================================================

    async def create_relationship(
        self,
        source_id: str,
        target_id: str,
        relationship_type: str,
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Create a relationship between two entities.

        Args:
            source_id: Source entity ID
            target_id: Target entity ID
            relationship_type: Type of relationship (must be defined in ontology)
            properties: Additional relationship properties

        Returns:
            Created relationship document

        Raises:
            AshcaiOntologyError: If relationship type is invalid
        """
        if relationship_type not in self.relationship_types:
            raise AshcaiOntologyError(
                400, f"Invalid relationship type: {relationship_type}"
            )

        rel_def = self.relationship_types[relationship_type]
        now = self._get_timestamp()

        relationship = {
            "ontology": "ashcai",
            "source_id": source_id,
            "target_id": target_id,
            "relationship_type": relationship_type,
            "inverse_type": rel_def.get("inverse"),
            "symmetric": rel_def.get("symmetric", False),
            "properties": properties or {},
            "created_at": now,
            "created_by": "system",
        }

        try:
            result = await self.relationships.insert_one(relationship)
            relationship["_id"] = str(result.inserted_id)
            logger.info(f"Created relationship: {source_id} --{relationship_type}--> {target_id}")
            return relationship
        except Exception as e:
            logger.error(f"Error creating relationship: {e}")
            raise AshcaiOntologyError(500, f"Error creating relationship: {e}")

    async def get_relationships(
        self,
        entity_id: str,
        relationship_type: str | None = None,
        direction: Literal["outgoing", "incoming", "both"] = "both",
    ) -> list[dict[str, Any]]:
        """
        Get relationships for an entity.

        Args:
            entity_id: Entity ID to query
            relationship_type: Optional filter by relationship type
            direction: Direction of relationships to return

        Returns:
            List of relationship documents
        """
        queries = []

        if direction in ("outgoing", "both"):
            q = {"source_id": entity_id}
            if relationship_type:
                q["relationship_type"] = relationship_type
            queries.append(q)

        if direction in ("incoming", "both"):
            q = {"target_id": entity_id}
            if relationship_type:
                q["relationship_type"] = relationship_type
            queries.append(q)

        if len(queries) == 1:
            cursor = self.relationships.find(queries[0])
        else:
            cursor = self.relationships.find({"$or": queries})

        return await cursor.to_list(length=1000)

    # =========================================================================
    # CONVENIENCE LINKING METHODS
    # =========================================================================

    async def link_policy_to_process(
        self, policy_id: str, process_id: str
    ) -> dict[str, Any]:
        """Create a 'specifies' relationship between a policy and process domain."""
        return await self.create_relationship(policy_id, process_id, "specifies")

    async def link_process_to_practice(
        self, process_id: str, practice_id: str
    ) -> dict[str, Any]:
        """Create a 'containsBasePractice' relationship."""
        return await self.create_relationship(process_id, practice_id, "containsBasePractice")

    async def link_practice_to_sop(
        self, practice_id: str, sop_id: str
    ) -> dict[str, Any]:
        """Create a 'realizedBy' relationship."""
        return await self.create_relationship(practice_id, sop_id, "realizedBy")

    async def link_sop_to_workproduct(
        self, sop_id: str, wp_id: str
    ) -> dict[str, Any]:
        """Create a 'produces' relationship."""
        return await self.create_relationship(sop_id, wp_id, "produces")

    async def link_workproduct_to_control(
        self, wp_id: str, control_id: str
    ) -> dict[str, Any]:
        """Create a 'servesAsEvidenceFor' relationship."""
        return await self.create_relationship(wp_id, control_id, "servesAsEvidenceFor")

    async def link_control_to_iso(
        self, control_id: str, iso_control_ref: str
    ) -> dict[str, Any]:
        """Create a 'mapsToISO' relationship."""
        return await self.create_relationship(control_id, iso_control_ref, "mapsToISO")

    async def link_requirement_to_policy(
        self, requirement_id: str, policy_id: str
    ) -> dict[str, Any]:
        """Create an 'addressedBy' relationship."""
        return await self.create_relationship(requirement_id, policy_id, "addressedBy")

    async def link_requirement_to_control(
        self, requirement_id: str, control_id: str
    ) -> dict[str, Any]:
        """Create an 'implementedThrough' relationship."""
        return await self.create_relationship(requirement_id, control_id, "implementedThrough")

    async def link_requirement_to_process(
        self, requirement_id: str, process_id: str
    ) -> dict[str, Any]:
        """Create an 'operationalizedIn' relationship."""
        return await self.create_relationship(requirement_id, process_id, "operationalizedIn")

    # =========================================================================
    # TRAVERSAL HELPERS
    # =========================================================================

    async def get_policy_hierarchy(self, policy_id: str) -> dict[str, Any]:
        """
        Get the complete implementation hierarchy for a policy domain.

        Returns all process domains, base practices, SOPs, and work products
        that implement this policy.

        Args:
            policy_id: Policy domain ID

        Returns:
            Dictionary with hierarchy structure
        """
        policy = await self.get_policy_domain(policy_id)
        if not policy:
            return {"error": f"Policy not found: {policy_id}"}

        # Get process domains specified by this policy
        process_ids = policy.get("specifies", [])
        processes = []
        for pid in process_ids:
            process = await self.get_process_domain(pid)
            if process:
                # Get base practices for this process
                practices = await self.list_base_practices(process_domain=pid)
                process["basePractices"] = practices

                # Get SOPs for each practice
                for practice in practices:
                    # Find SOPs that realize this practice
                    sop_cursor = self.sop_templates.find(
                        {"basePractice": practice["_id"]}
                    )
                    sops = await sop_cursor.to_list(length=100)
                    practice["sops"] = sops

                    # Get work products for each SOP
                    for sop in sops:
                        wp_cursor = self.work_product_templates.find(
                            {"producedBy": sop["_id"]}
                        )
                        work_products = await wp_cursor.to_list(length=100)
                        sop["workProducts"] = work_products

                processes.append(process)

        # Get exemplar controls that validate this policy
        control_ids = policy.get("validatedBy", [])
        controls = []
        for cid in control_ids:
            control = await self.get_exemplar_control(cid)
            if control:
                controls.append(control)

        return {
            "policy": policy,
            "processes": processes,
            "controls": controls,
        }

    async def get_evidence_chain(self, control_id: str) -> dict[str, Any]:
        """
        Get the evidence chain for an exemplar control.

        Returns all work products, SOPs, practices, and processes
        that provide evidence for this control.

        Args:
            control_id: Exemplar control ID

        Returns:
            Dictionary with evidence chain
        """
        control = await self.get_exemplar_control(control_id)
        if not control:
            return {"error": f"Control not found: {control_id}"}

        # Get work products that evidence this control
        wp_ids = control.get("evidencedBy", [])
        work_products = []
        for wp_id in wp_ids:
            wp = await self.get_work_product_template(wp_id)
            if wp:
                # Get the SOP that produces this work product
                if wp.get("producedBy"):
                    sop = await self.get_sop_template(wp["producedBy"])
                    if sop:
                        wp["sop"] = sop
                        # Get the practice this SOP realizes
                        if sop.get("basePractice"):
                            practice = await self.get_base_practice(sop["basePractice"])
                            if practice:
                                wp["sop"]["practice"] = practice
                work_products.append(wp)

        return {
            "control": control,
            "workProducts": work_products,
        }

    async def get_regulatory_crosswalk(
        self, requirement_id: str
    ) -> dict[str, Any]:
        """
        Get the full regulatory crosswalk for a requirement.

        Returns all policies, controls, processes, and evidence
        that address this regulatory requirement.

        Args:
            requirement_id: Regulatory requirement ID

        Returns:
            Dictionary with crosswalk mappings
        """
        requirement = await self.get_regulatory_requirement(requirement_id)
        if not requirement:
            return {"error": f"Requirement not found: {requirement_id}"}

        crosswalk = requirement.get("crosswalk", {})

        # Resolve policy references
        policies = []
        for pid in crosswalk.get("addressedBy", []):
            policy = await self.get_policy_domain(pid)
            if policy:
                policies.append(policy)

        # Resolve control references
        controls = []
        for cid in crosswalk.get("implementedThrough", []):
            control = await self.get_exemplar_control(cid)
            if control:
                controls.append(control)

        # Resolve process references
        processes = []
        for pid in crosswalk.get("operationalizedIn", []):
            process = await self.get_process_domain(pid)
            if process:
                processes.append(process)

        # Resolve evidence references
        evidence = []
        for wp_id in crosswalk.get("evidencedBy", []):
            wp = await self.get_work_product_template(wp_id)
            if wp:
                evidence.append(wp)

        return {
            "requirement": requirement,
            "addressedBy": policies,
            "implementedThrough": controls,
            "operationalizedIn": processes,
            "evidencedBy": evidence,
        }

    async def find_evidence_for_requirement(
        self, requirement_id: str
    ) -> list[dict[str, Any]]:
        """
        Find all work products that serve as evidence for a requirement.

        Args:
            requirement_id: Regulatory requirement ID

        Returns:
            List of work product templates
        """
        requirement = await self.get_regulatory_requirement(requirement_id)
        if not requirement:
            return []

        crosswalk = requirement.get("crosswalk", {})
        wp_ids = crosswalk.get("evidencedBy", [])

        work_products = []
        for wp_id in wp_ids:
            wp = await self.get_work_product_template(wp_id)
            if wp:
                work_products.append(wp)

        return work_products

    async def find_control_implementations(
        self, control_id: str
    ) -> list[dict[str, Any]]:
        """
        Find all SOPs that implement a specific control.

        Args:
            control_id: Exemplar control ID

        Returns:
            List of SOP templates with their work products
        """
        control = await self.get_exemplar_control(control_id)
        if not control:
            return []

        # Get work products that evidence this control
        wp_ids = control.get("evidencedBy", [])

        # Find SOPs that produce these work products
        sops = []
        seen_sop_ids = set()
        for wp_id in wp_ids:
            wp = await self.get_work_product_template(wp_id)
            if wp and wp.get("producedBy"):
                sop_id = wp["producedBy"]
                if sop_id not in seen_sop_ids:
                    sop = await self.get_sop_template(sop_id)
                    if sop:
                        sop["relevantWorkProducts"] = [wp]
                        sops.append(sop)
                        seen_sop_ids.add(sop_id)
                else:
                    # Add work product to existing SOP entry
                    for s in sops:
                        if s["_id"] == sop_id:
                            s["relevantWorkProducts"].append(wp)
                            break

        return sops

    # =========================================================================
    # OWL/RDF EXPORT UTILITIES
    # =========================================================================

    def generate_uri(self, entity_id: str) -> str:
        """
        Generate an OWL/RDF URI from a natural business ID.

        Args:
            entity_id: Natural business ID

        Returns:
            Full URI string
        """
        return f"{self.NAMESPACE}{entity_id}"

    async def export_to_owl_triples(self) -> list[tuple[str, str, str]]:
        """
        Export ontology entities as OWL/RDF triples.

        Returns:
            List of (subject, predicate, object) triples
        """
        triples = []

        # Export relationships as triples
        cursor = self.relationships.find({})
        async for rel in cursor:
            subject = self.generate_uri(rel["source_id"])
            predicate = f"{self.NAMESPACE}{rel['relationship_type']}"
            obj = self.generate_uri(rel["target_id"])
            triples.append((subject, predicate, obj))

        return triples

    async def export_ontology(self, format: str = "json") -> dict[str, Any]:
        """
        Export the entire ASHCAI ontology.

        Args:
            format: Export format (json, triples)

        Returns:
            Ontology data in requested format
        """
        if format == "triples":
            triples = await self.export_to_owl_triples()
            return {
                "ontology": "ASHCAI",
                "version": self.ontology_version,
                "namespace": self.NAMESPACE,
                "exported_at": self._get_timestamp(),
                "triples": triples,
            }

        # Default JSON export
        data = {
            "ontology": "ASHCAI",
            "version": self.ontology_version,
            "namespace": self.NAMESPACE,
            "exported_at": self._get_timestamp(),
            "entities": {
                "policy_domains": await self.list_policy_domains(limit=1000),
                "process_domains": await self.list_process_domains(limit=1000),
            },
            "relationships": await self.relationships.find({}).to_list(length=10000),
        }

        return data

    # =========================================================================
    # INITIALIZATION
    # =========================================================================

    async def initialize_ontology(
        self,
        create_indexes: bool = True,
        override_existing: bool = False,
    ) -> bool:
        """
        Initialize the ASHCAI ontology collections and indexes.

        Args:
            create_indexes: Whether to create database indexes
            override_existing: Whether to drop existing collections first

        Returns:
            True if initialization was successful
        """
        try:
            if override_existing:
                logger.warning("Dropping existing ASHCAI collections")
                for collection_name in self.COLLECTIONS.values():
                    await self.db.drop_collection(collection_name)

            if create_indexes:
                # =============================================================
                # INDEX STRATEGY DOCUMENTATION
                # =============================================================
                # All ASHCAI entities use `_id` as the natural business ID:
                #   - PolicyDomain: _id = "MMP-001" (full ID pattern)
                #   - ProcessDomain: _id = "MON" (short code IS the ID)
                #   - BasePractice: _id = "MON.BP01"
                #   - SOPTemplate: _id = "SOP-MON-01"
                #   - WorkProductTemplate: _id = "WP-MON-01-Dashboard"
                #   - ExemplarControl: _id = "EXC-A7-04"
                #   - RegulatoryRequirement: _id = "NIST-MAP-4.2"
                #
                # MongoDB automatically enforces uniqueness on `_id` (primary key),
                # so NO explicit unique index is needed for the primary identifier.
                #
                # Additional unique constraints are ONLY added where a secondary
                # field must also be unique (e.g., PolicyDomain has both _id and
                # domainCode, and we need domainCode to be unique too).
                # =============================================================

                # PolicyDomain: _id="MMP-001", domainCode="MMP" (both must be unique)
                # domainCode needs explicit unique index since it's separate from _id
                await self.policy_domains.create_index("domainCode", unique=True)
                await self.policy_domains.create_index("status")

                # ProcessDomain: _id="MON" (short code IS the _id, no extra unique needed)
                await self.process_domains.create_index("status")

                # BasePractice: _id="MON.BP01" (unique by _id)
                await self.base_practices.create_index("processDomain")
                await self.base_practices.create_index("status")

                # SOPTemplate: _id="SOP-MON-01" (unique by _id)
                await self.sop_templates.create_index("basePractice")
                await self.sop_templates.create_index("status")

                # WorkProductTemplate: _id="WP-MON-01-Dashboard" (unique by _id)
                await self.work_product_templates.create_index("producedBy")
                await self.work_product_templates.create_index("servesAsEvidenceFor")
                await self.work_product_templates.create_index("status")

                # ExemplarControl: _id="EXC-A7-04" (unique by _id)
                await self.exemplar_controls.create_index("isoControl")
                await self.exemplar_controls.create_index("status")

                # RegulatoryRequirement: _id="NIST-MAP-4.2" (unique by _id)
                await self.regulatory_requirements.create_index("framework")
                await self.regulatory_requirements.create_index("function")
                await self.regulatory_requirements.create_index("category")
                await self.regulatory_requirements.create_index("status")

                # Relationships: Use auto-generated ObjectId for _id
                # Indexed by source/target for traversal queries
                await self.relationships.create_index("source_id")
                await self.relationships.create_index("target_id")
                await self.relationships.create_index("relationship_type")
                await self.relationships.create_index(
                    [("source_id", 1), ("relationship_type", 1)]
                )

                logger.info("Created ASHCAI ontology indexes")

            logger.info("ASHCAI ontology initialized successfully")
            return True

        except Exception as e:
            logger.error(f"Error initializing ASHCAI ontology: {e}")
            return False
