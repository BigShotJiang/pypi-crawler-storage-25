# Copyright (c) 2025, Asher Informatics PBC
"""
Category Manager - Hierarchical category management for document tagging.

This module provides category management functionality that can be used across
multiple Ashmatics applications. It handles category creation, retrieval,
updates, and integration with term services for ontology-based categorization.

Usage:
    from ashmatics_tools.ontology.categories import CategoryManager
    from ashmatics_tools.ontology.terms import TermResolver

    term_resolver = TermResolver(mongodb_client=mongo_client)
    category_manager = CategoryManager(
        mongodb_database=mongo_db,
        term_resolver=term_resolver  # Optional
    )

    result = await category_manager.get_or_create_category(
        category_key="clinical_finding",
        class_id="404684003",
        ontology="SNOMEDCT"
    )
"""

import logging
from datetime import datetime
from typing import Any, Optional
from zoneinfo import ZoneInfo

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

from .schemas import (
    CategoryCreate,
    CategoryDB,
    CategoryOperationResult,
    CategoryResponse,
    CategoryUpdate,
)

logger = logging.getLogger(__name__)


class CategoryManager:
    """
    Service for managing hierarchical tag categories.

    This class provides category management without application-specific
    dependencies. Applications can provide an optional TermResolver
    to enable term service integration.

    Attributes:
        db: MongoDB database instance
        collection: MongoDB collection for categories
        term_resolver: Optional TermResolver for ontology integration
    """

    def __init__(
        self,
        mongodb_client: Optional[AsyncIOMotorClient] = None,
        mongodb_database: Optional[AsyncIOMotorDatabase] = None,
        database_name: str = "ashmatics_ontology",
        term_resolver: Optional[object] = None,
    ):
        """
        Initialize the CategoryManager.

        Args:
            mongodb_client: AsyncIOMotorClient instance (optional)
            mongodb_database: AsyncIOMotorDatabase instance (optional)
            database_name: Name of the database (default: ashmatics_ontology)
            term_resolver: Optional TermResolver for term service integration
        """
        if mongodb_database:
            self.db = mongodb_database
        elif mongodb_client:
            self.db = mongodb_client[database_name]
        else:
            raise ValueError(
                "Either mongodb_client or mongodb_database must be provided"
            )

        self.collection = self.db.categories
        self.term_resolver = term_resolver

    async def get_or_create_category(
        self,
        category_key: str,
        class_id: str,
        ontology: str = "SNOMEDCT",
        name: Optional[str] = None,
        definition: Optional[str] = None,
        applicable_document_types: Optional[list[str]] = None,
    ) -> CategoryOperationResult:
        """
        Get existing category or create it.

        Args:
            category_key: Unique key for the category (e.g., "clinical_finding")
            class_id: The ontology class ID
            ontology: The ontology to use (default: SNOMEDCT)
            name: Optional display name (auto-generated from key if not provided)
            definition: Optional category definition
            applicable_document_types: Optional list of document types

        Returns:
            CategoryOperationResult with the category
        """
        # Check if category exists
        existing = await self.collection.find_one({"key": category_key})

        if existing:
            category_response = self._doc_to_response(existing)
            logger.info(f"Category {category_key} found in database")
            return CategoryOperationResult(
                success=True,
                category=category_response,
                message=None,
                category_id=str(existing.get("_id", "")),
            )

        # Create new category
        eastern = ZoneInfo("America/New_York")
        now_eastern = datetime.now(eastern)

        # Format display name from category key if not provided
        if not name:
            name = self._format_label(category_key)

        category_value = name

        # If term_resolver is available, try to get term details
        if self.term_resolver:
            try:
                term_result = await self.term_resolver.get_term(
                    key=category_key, ontology=ontology
                )

                if term_result.success and term_result.term:
                    term_data = term_result.term
                    category_value = term_data.prefLabel
                    if not definition and term_data.definition:
                        definition = term_data.definition
                else:
                    logger.info(
                        f"No existing term found for {category_key}, category will be created without term data"
                    )
            except Exception as e:
                logger.warning(
                    f"Could not fetch term data for {category_key}: {str(e)}"
                )

        # Create category
        category_create = CategoryCreate(
            name=name,
            category_key=category_key,
            category_value=category_value,
            definition=definition,
            ontology=ontology,
            applicable_document_types=applicable_document_types or [],
        )

        # Convert to CategoryDB for database insertion
        category_db = CategoryDB(
            **category_create.model_dump(),
            created_at=now_eastern,
            updated_at=now_eastern,
        )

        # Insert into database
        result = await self._create_category(category_db)

        if result.success:
            category_response = CategoryResponse(
                _id=str(result.category_id),
                **category_create.model_dump(),
                created_at=now_eastern,
                updated_at=now_eastern,
            )

            logger.info(f"Category {category_key} created successfully")
            return CategoryOperationResult(
                success=True,
                category=category_response,
                message="Category created successfully",
                category_id=result.category_id,
            )
        else:
            logger.error(f"Error creating category {category_key}")
            return CategoryOperationResult(
                success=False,
                category=None,
                message="Failed to create category in database",
                category_id=None,
            )

    async def get_categories(
        self,
        document_type: Optional[str] = None,
        ontology: Optional[str] = None,
    ) -> list[CategoryResponse]:
        """
        Get all categories, optionally filtered.

        Args:
            document_type: Optional document type filter
            ontology: Optional ontology filter

        Returns:
            List of CategoryResponse objects
        """
        query = {}

        if document_type:
            query["applicable_document_types"] = document_type

        if ontology:
            query["ontology"] = ontology

        result = await self.collection.find(query).to_list(length=None)

        return [self._doc_to_response(item) for item in result]

    async def update_category(
        self,
        category_key: str,
        category_data: CategoryUpdate | dict,
    ) -> CategoryOperationResult:
        """
        Update an existing category.

        Args:
            category_key: The key of the category to update
            category_data: Update data as CategoryUpdate model or dict

        Returns:
            CategoryOperationResult with updated category
        """
        # Convert Pydantic model to dict if needed
        if isinstance(category_data, CategoryUpdate):
            update_dict = category_data.model_dump(exclude_none=True)
        else:
            update_dict = category_data

        # Update timestamp
        eastern = ZoneInfo("America/New_York")
        update_dict["updated_at"] = datetime.now(eastern)

        try:
            result = await self.collection.update_one(
                {"key": category_key},
                {"$set": update_dict},
            )

            if result.matched_count == 0:
                return CategoryOperationResult(
                    success=False,
                    message=f"Category with key {category_key} not found",
                    category=None,
                    category_id=None,
                )

            # Get updated category
            updated_category = await self.collection.find_one({"key": category_key})

            if updated_category:
                category_response = self._doc_to_response(updated_category)
                return CategoryOperationResult(
                    success=True,
                    message=f"Category {category_key} updated successfully",
                    category=category_response,
                    category_id=str(updated_category.get("_id", "")),
                )
            else:
                return CategoryOperationResult(
                    success=True,
                    message=f"Category {category_key} updated but could not retrieve",
                    category=None,
                    category_id=None,
                )

        except Exception as e:
            logger.error(f"Error updating category {category_key}: {str(e)}")
            return CategoryOperationResult(
                success=False,
                message=f"Error updating category: {str(e)}",
                category=None,
                category_id=None,
            )

    async def delete_category(self, category_key: str) -> CategoryOperationResult:
        """
        Delete a category.

        Args:
            category_key: The key of the category to delete

        Returns:
            CategoryOperationResult with success status
        """
        try:
            category = await self.collection.find_one({"key": category_key})

            if not category:
                return CategoryOperationResult(
                    success=False,
                    message=f"Category with key {category_key} not found",
                    category=None,
                    category_id=None,
                )

            result = await self.collection.delete_one({"key": category_key})

            if result.deleted_count == 0:
                return CategoryOperationResult(
                    success=False,
                    message=f"Category with key {category_key} not found",
                    category=None,
                    category_id=None,
                )

            return CategoryOperationResult(
                success=True,
                message=f"Category {category_key} deleted successfully",
                category=None,
                category_id=str(category.get("_id", "")),
            )

        except Exception as e:
            logger.error(f"Error deleting category {category_key}: {str(e)}")
            return CategoryOperationResult(
                success=False,
                message=f"Error deleting category: {str(e)}",
                category=None,
                category_id=None,
            )

    async def _create_category(
        self,
        category: CategoryDB | CategoryCreate | dict,
    ) -> CategoryOperationResult:
        """
        Create a new category in the database.

        Args:
            category: Category data as CategoryDB, CategoryCreate, or dict

        Returns:
            CategoryOperationResult with created category ID
        """
        eastern = ZoneInfo("America/New_York")
        now_eastern = datetime.now(eastern)

        # Convert Pydantic model to dict if needed
        if isinstance(category, (CategoryDB, CategoryCreate)):
            category_dict = category.model_dump(exclude_none=True)
        else:
            category_dict = category

        # Validate required fields
        if "category_key" not in category_dict and "key" not in category_dict:
            return CategoryOperationResult(
                success=False,
                message="Category must have a key",
                category=None,
                category_id=None,
            )

        # Ensure key consistency
        if "category_key" in category_dict and "key" not in category_dict:
            category_dict["key"] = category_dict["category_key"]
        elif "key" in category_dict and "category_key" not in category_dict:
            category_dict["category_key"] = category_dict["key"]

        # Set timestamps if not present
        if "created_at" not in category_dict:
            category_dict["created_at"] = now_eastern
        if "updated_at" not in category_dict:
            category_dict["updated_at"] = now_eastern

        try:
            result = await self.collection.insert_one(category_dict)
            return CategoryOperationResult(
                success=True,
                message="Category created in database",
                category=None,
                category_id=str(result.inserted_id),
            )

        except Exception as e:
            logger.error(f"Error creating category: {str(e)}")
            return CategoryOperationResult(
                success=False,
                message=f"Error creating category: {str(e)}",
                category=None,
                category_id=None,
            )

    def _doc_to_response(self, doc: dict) -> CategoryResponse:
        """Convert MongoDB document to CategoryResponse."""
        return CategoryResponse(
            _id=str(doc.get("_id", "")),
            name=doc.get("name", ""),
            category_key=doc.get("key", doc.get("category_key", "")),
            category_value=doc.get("category_value", ""),
            definition=doc.get("definition", ""),
            ontology=doc.get("ontology", ""),
            applicable_document_types=doc.get("applicable_document_types", []),
            created_at=doc.get("created_at"),
            updated_at=doc.get("updated_at"),
        )

    def _format_label(self, key: str) -> str:
        """Format a key into a human-readable label."""
        if "_" in key:
            words = key.replace("_", " ").split()
            return words[0].capitalize() + " " + " ".join(word.lower() for word in words[1:])
        else:
            return key.capitalize()
