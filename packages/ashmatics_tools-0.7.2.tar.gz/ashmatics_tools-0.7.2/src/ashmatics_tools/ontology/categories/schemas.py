# Copyright (c) 2025, Asher Informatics PBC JFK
# Pydantic models for Category and Categroies in the KB tagging system - referred mostly by the CategoryManager class in the tagging service
# 5/14/25 - cretion JFK

from datetime import datetime  # This imports the datetime class

from bson import ObjectId
from pydantic import BaseModel, Field, model_validator

from ..terms.schemas import TermValue

# DO I NEED display name??


class CategoryBase(BaseModel):
    name: str | None
    category_key: str
    category_value: TermValue | str | None
    category_value: str | TermValue
    definition: str
    ontology: str
    applicable_document_types: list[str] | str


class CategoryDB(CategoryBase):
    created_at: datetime
    updated_at: datetime

    model_config = {
        "arbitrary_types_allowed": True  # Added for Pydantic V2 compatibility
    }


class CategoryCreate(CategoryBase):
    """
    Schema for creating a new category
    Inherits all fields from CategoryBase
    """

    # Fields needed only for creation, if any
    pass


class CategoryResponse(CategoryBase):
    """
    Schema for returning a category to clients
    Includes database ID and timestamps
    """

    id: str = Field(alias="_id")
    name: str
    applicable_document_types: list[str] | str
    created_at: datetime
    updated_at: datetime
    category_value: TermValue | None = None

    @model_validator(mode="before")
    def convert_object_id(cls, values):
        if (
            isinstance(values, dict)
            and "_id" in values
            and isinstance(values["_id"], (ObjectId, str))
        ):
            values["_id"] = str(values["_id"])
            return values

    model_config = {
        # Allows the model to accept _id from MongoDB
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }


class CategoryOperationResult(BaseModel):
    """
    Response model for category operations (create, update, delete)
    """

    success: bool
    category: CategoryResponse | None = None
    message: str | None = None
    category_id: str | None = None


class CategoryUpdate(BaseModel):
    """
    Schema for updating a category
    All fields are optional since only provided fields will be updated
    """

    name: str | None = None
    definition: str | None = None
    category_value: TermValue | None = None
    ontology: str | None = None
    # Note: category_key typically shouldn't be updated as it's an identifier


class CategoryList(BaseModel):
    """
    Schema for returning a list of categories
    """

    items: list[CategoryResponse]
    total: int
    page: int = 1
    size: int = 100
