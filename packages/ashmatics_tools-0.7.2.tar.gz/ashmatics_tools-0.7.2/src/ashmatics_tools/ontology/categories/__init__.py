# Copyright (c) 2025, Asher Informatics PBC
"""
Category Management Module

Provides hierarchical category management for document tagging and classification.
"""

from .manager import CategoryManager
from .schemas import (
    CategoryBase,
    CategoryCreate,
    CategoryUpdate,
    CategoryResponse,
    CategoryOperationResult,
    CategoryDB,
)

__all__ = [
    "CategoryManager",
    "CategoryBase",
    "CategoryCreate",
    "CategoryUpdate",
    "CategoryResponse",
    "CategoryOperationResult",
    "CategoryDB",
]
