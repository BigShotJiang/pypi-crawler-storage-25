# Copyright (c) 2025-2026, Asher Informatics PBC
"""
Ontology Data Package

Contains JSON definition files for ASHMATICS ontologies:
- ashmatics-ontology-v20250616.json: Base ASHMATICS ontology
- ashcai-ontology-v1.0.json: ASHCAI Clinical AI Governance ontology

These files are loaded via importlib.resources by dependent packages.
"""
