# Copyright (c) 2025, Asher Informatics PBC
"""
Term Resolver - Core term lookup and resolution functionality.

This module provides the core term resolution functionality that can be used
across multiple Ashmatics applications. It handles term lookup, validation,
and relationship management for medical ontologies including SNOMED CT,
RADLEX, LOINC, and custom Ashmatics ontologies.

Usage:
    from ashmatics_tools.ontology.terms import TermResolver

    resolver = TermResolver(mongodb_client=mongo_client)
    term_result = await resolver.get_term(class_id="24136001", ontology="SNOMED_CT")
"""

import logging
from datetime import datetime
from typing import Any, Optional
from zoneinfo import ZoneInfo

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

from .schemas import (
    TermBase,
    TermCreate,
    TermOperationResult,
    TermRelationship,
    TermResponse,
    TermUpdate,
    utc_now,
)

logger = logging.getLogger(__name__)


class TermResolver:
    """
    Core term resolution service for medical ontologies.

    This class provides fundamental term lookup, validation, and relationship
    management without application-specific dependencies. Applications should
    wrap this class to add caching, authentication, and other app-specific features.

    Attributes:
        db: MongoDB database instance
        collection: MongoDB collection for terms
    """

    def __init__(
        self,
        mongodb_client: Optional[AsyncIOMotorClient] = None,
        mongodb_database: Optional[AsyncIOMotorDatabase] = None,
        database_name: str = "ashmatics_ontology",
    ):
        """
        Initialize the TermResolver.

        Args:
            mongodb_client: AsyncIOMotorClient instance (optional)
            mongodb_database: AsyncIOMotorDatabase instance (optional)
            database_name: Name of the database to use (default: ashmatics_ontology)
        """
        if mongodb_database:
            self.db = mongodb_database
        elif mongodb_client:
            self.db = mongodb_client[database_name]
        else:
            raise ValueError("Either mongodb_client or mongodb_database must be provided")

        self.collection = self.db.terms
        self.relationships_collection = self.db.term_relationships

    async def get_term(self, **term_data) -> TermOperationResult:
        """
        Retrieve a term from the database using flexible search criteria.

        Args:
            **term_data: Keyword arguments for term lookup.
                Supported keys: class_id, key, prefLabel, ontology, uid

        Returns:
            TermOperationResult with the found term or error

        Examples:
            >>> result = await resolver.get_term(class_id="24136001", ontology="SNOMED_CT")
            >>> result = await resolver.get_term(key="hip_joint")
        """
        try:
            # Build query from provided term_data
            query = {}

            if "class_id" in term_data and term_data["class_id"]:
                query["class_id"] = term_data["class_id"]

            if "key" in term_data and term_data["key"]:
                query["key"] = term_data["key"]

            if "prefLabel" in term_data and term_data["prefLabel"]:
                query["prefLabel"] = term_data["prefLabel"]

            if "ontology" in term_data and term_data["ontology"]:
                query["ontology"] = term_data["ontology"]

            if "uid" in term_data and term_data["uid"]:
                query["uid"] = term_data["uid"]

            if not query:
                return TermOperationResult(
                    success=False,
                    term=None,
                    message="No valid search criteria provided",
                    term_id=None,
                )

            # Query database
            term_doc = await self.collection.find_one(query)

            if not term_doc:
                return TermOperationResult(
                    success=False,
                    term=None,
                    message=f"Term not found with criteria: {query}",
                    term_id=None,
                )

            # Convert to TermResponse
            term_response = self._doc_to_response(term_doc)

            return TermOperationResult(
                success=True,
                term=term_response,
                message=None,
                term_id=str(term_doc["_id"]),
            )

        except Exception as e:
            logger.error(f"Error retrieving term: {e}", exc_info=True)
            return TermOperationResult(
                success=False,
                term=None,
                message=f"Error retrieving term: {str(e)}",
                term_id=None,
            )

    async def get_all_terms(
        self,
        ontology: Optional[str] = None,
        semantic_type: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> list[TermResponse]:
        """
        Retrieve multiple terms with optional filtering.

        Args:
            ontology: Filter by ontology (e.g., "SNOMED_CT", "RADLEX")
            semantic_type: Filter by semantic type
            skip: Number of records to skip (for pagination)
            limit: Maximum number of records to return

        Returns:
            List of TermResponse objects
        """
        try:
            query = {}

            if ontology:
                query["ontology"] = ontology

            if semantic_type:
                query["semantic_type"] = semantic_type

            cursor = self.collection.find(query).skip(skip).limit(limit)
            terms = await cursor.to_list(length=limit)

            return [self._doc_to_response(term) for term in terms]

        except Exception as e:
            logger.error(f"Error retrieving terms: {e}", exc_info=True)
            return []

    async def search_by_text(
        self,
        text: str,
        include_synonyms: bool = True,
        ontology: Optional[str] = None,
        limit: int = 20,
    ) -> list[TermResponse]:
        """
        Search for terms by text (supports fuzzy matching).

        Args:
            text: Search text
            include_synonyms: Whether to search in synonyms/altLabels
            ontology: Filter by specific ontology
            limit: Maximum number of results

        Returns:
            List of matching TermResponse objects
        """
        try:
            # Build search query
            search_conditions = [
                {"prefLabel": {"$regex": text, "$options": "i"}},
                {"key": {"$regex": text.lower().replace(" ", "_"), "$options": "i"}},
            ]

            if include_synonyms:
                search_conditions.append(
                    {"altLabel": {"$regex": text, "$options": "i"}}
                )
                search_conditions.append(
                    {"synonyms": {"$regex": text, "$options": "i"}}
                )

            query = {"$or": search_conditions}

            if ontology:
                query["ontology"] = ontology

            cursor = self.collection.find(query).limit(limit)
            terms = await cursor.to_list(length=limit)

            return [self._doc_to_response(term) for term in terms]

        except Exception as e:
            logger.error(f"Error searching terms: {e}", exc_info=True)
            return []

    async def create_term(self, term_data: TermCreate) -> TermOperationResult:
        """
        Create a new term in the database.

        Args:
            term_data: TermCreate instance with term information

        Returns:
            TermOperationResult with created term
        """
        try:
            # Check if term already exists
            existing = await self.collection.find_one({
                "key": term_data.key,
                "ontology": term_data.ontology,
            })

            if existing:
                return TermOperationResult(
                    success=False,
                    term=None,
                    message=f"Term already exists: {term_data.key}",
                    term_id=str(existing["_id"]),
                )

            # Prepare document
            term_dict = term_data.model_dump(exclude_unset=True)
            term_dict["created_at"] = utc_now()
            term_dict["updated_at"] = utc_now()

            # Insert into database
            result = await self.collection.insert_one(term_dict)

            # Retrieve created term
            created_term = await self.collection.find_one({"_id": result.inserted_id})
            term_response = self._doc_to_response(created_term)

            return TermOperationResult(
                success=True,
                term=term_response,
                message="Term created successfully",
                term_id=str(result.inserted_id),
            )

        except Exception as e:
            logger.error(f"Error creating term: {e}", exc_info=True)
            return TermOperationResult(
                success=False,
                term=None,
                message=f"Error creating term: {str(e)}",
                term_id=None,
            )

    async def update_term(
        self,
        term_id: str,
        update_data: TermUpdate,
    ) -> TermOperationResult:
        """
        Update an existing term.

        Args:
            term_id: MongoDB ObjectId as string
            update_data: TermUpdate instance with updated fields

        Returns:
            TermOperationResult with updated term
        """
        try:
            # Prepare update document
            update_dict = update_data.model_dump(exclude_unset=True)
            update_dict["updated_at"] = utc_now()

            # Update in database
            result = await self.collection.update_one(
                {"_id": ObjectId(term_id)},
                {"$set": update_dict},
            )

            if result.matched_count == 0:
                return TermOperationResult(
                    success=False,
                    term=None,
                    message=f"Term not found: {term_id}",
                    term_id=term_id,
                )

            # Retrieve updated term
            updated_term = await self.collection.find_one({"_id": ObjectId(term_id)})
            term_response = self._doc_to_response(updated_term)

            return TermOperationResult(
                success=True,
                term=term_response,
                message="Term updated successfully",
                term_id=term_id,
            )

        except Exception as e:
            logger.error(f"Error updating term: {e}", exc_info=True)
            return TermOperationResult(
                success=False,
                term=None,
                message=f"Error updating term: {str(e)}",
                term_id=term_id,
            )

    async def add_term_relationship(
        self,
        relationship: TermRelationship,
    ) -> bool:
        """
        Add a relationship between two terms.

        Args:
            relationship: TermRelationship instance

        Returns:
            True if successful, False otherwise
        """
        try:
            relationship_dict = relationship.model_dump()
            relationship_dict["created_at"] = utc_now()

            await self.relationships_collection.insert_one(relationship_dict)
            return True

        except Exception as e:
            logger.error(f"Error adding relationship: {e}", exc_info=True)
            return False

    async def get_term_relationships(
        self,
        term_id: str,
        relationship_type: Optional[str] = None,
    ) -> list[TermRelationship]:
        """
        Get all relationships for a term.

        Args:
            term_id: Term identifier
            relationship_type: Optional filter by relationship type

        Returns:
            List of TermRelationship objects
        """
        try:
            query = {
                "$or": [
                    {"source_term_id": term_id},
                    {"target_term_id": term_id},
                ]
            }

            if relationship_type:
                query["relationship_type"] = relationship_type

            cursor = self.relationships_collection.find(query)
            relationships = await cursor.to_list(length=None)

            return [TermRelationship(**rel) for rel in relationships]

        except Exception as e:
            logger.error(f"Error retrieving relationships: {e}", exc_info=True)
            return []

    def _doc_to_response(self, doc: dict) -> TermResponse:
        """
        Convert MongoDB document to TermResponse.

        Args:
            doc: MongoDB document dictionary

        Returns:
            TermResponse instance
        """
        return TermResponse(
            id=str(doc.get("_id", "")),
            class_id=doc.get("class_id"),
            type_id=doc.get("type_id"),
            uid=doc.get("uid"),
            key=doc.get("key", ""),
            prefLabel=doc.get("prefLabel", ""),
            altLabel=doc.get("altLabel"),
            ontology=doc.get("ontology", ""),
            category_type=doc.get("category_type"),
            semantic_type=doc.get("semantic_type"),
            definition=doc.get("definition"),
            has_children=doc.get("has_children", False),
            properties=doc.get("properties"),
            parent_uri=doc.get("parent_uri"),
            children_uri=doc.get("children_uri"),
            uri=doc.get("uri"),
            synonyms=doc.get("synonyms"),
            mappings=doc.get("mappings"),
            created_at=doc.get("created_at"),
            updated_at=doc.get("updated_at"),
        )
