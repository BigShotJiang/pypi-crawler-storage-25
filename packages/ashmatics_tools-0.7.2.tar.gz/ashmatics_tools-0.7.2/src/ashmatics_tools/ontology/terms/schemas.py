# 4/17/25 Copyright (c) 2025, Asher Informatics PBC
"""A schema for the Term model."""

import json
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID

from bson import ObjectId
from pydantic import BaseModel, Field, model_validator

# ====================================
# Term Service API Schemas
#
# -- This module defines the schemas used in the Term Service API.
# -- The schemas are used to validate and serialize/deserialize data for the API endpoints.
# -- The schemas are based on the Pydantic library, which provides data validation and settings management using Python type annotations.
# -- The schemas include:
# -- 1. TermCreate: A schema for creating a new term in the ontology.
# -- 2. TermUpdate: A schema for updating an existing term in the ontology.
# -- 3. TermResponse: A schema for the response when retrieving a term from the ontology.
# -- 4. TermValidationResponse: A schema for validating a term against the ontology.
# -- 5. TermRelationship: A schema for representing a relationship between two terms.
# -- 6. TermWithRelationships: A schema for representing a term with its relationships.
# -- 7. MappingAddRequest: A schema for adding a mapping to a term.
# -- 8. MappingRemoveRequest: A schema for removing a mapping from a term.
# -- 9. OntologyMapping: A schema for representing a mapping between a term in one ontology and a term in another ontology.
# -- 10. Term: A schema for representing a term in the ontology.

# ======================================


# == HELPER CLASSES ==
# JSON encoder to handle datetime serialization
class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)


# Helper function to get current UTC time
def utc_now() -> datetime:
    return datetime.now(UTC)


# Helper function to get current Eastern time
def eastern_now() -> datetime:
    """Get current time in Eastern timezone"""
    from zoneinfo import ZoneInfo  # Use zoneinfo instead of manual offset calculation

    # Use ZoneInfo for proper timezone handling
    eastern = ZoneInfo("America/New_York")
    return datetime.now(eastern)


# Custom ObjectId field for MongoDB - new 5/14/25 JFK
# 5/15/25 - not the deprecation of __modify_schema__ in Pydantic v2
class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid objectid")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, _schema_generator, _field):
        return {"type": "string"}

    @classmethod
    def __get_pydantic_core_schema__(cls, _source_type, _handler):
        # Import locally to avoid issues
        try:
            from pydantic_core import core_schema
            # For newer versions with string_schema

            return core_schema.str_schema(pattern=r"^[0-9a-fA-F]{24}$")

        except ImportError:
            # Fallback for older Pydantic versions
            return {"type": "string", "pattern": r"^[0-9a-fA-F]{24}$"}


# == BASE MODELS ==


# -- Base Ontology Mapping Class  for connecting across different ontologies
# -- This is used to represent a mapping between a term in one ontology and a term in another ontology.
# -- It includes the label, ontology, class ID, and an optional URI.
# --
class OntologyMapping(BaseModel):
    prefLabel: str = Field(..., description="Primary label of the mapped term")
    ontology: str = Field(
        ..., description="Source ontology (e.g., SNOMED, UMLS, RADLEX)"
    )
    class_id: str = Field(..., description="Unique identifier in the source ontology")
    uri: str | None = Field(None, description="URI for the mapped term if available")

    model_config = {
        "json_schema_extra": {
            "example": {
                "prefLabel": "Hip Joint",
                "ontology": "RADLEX",
                "class_id": "RID39298",
                "uri": "http://radlex.org/RID39298",
            }
        }
    }


# ==============================================
# Term Service API Schemas
# ==============================================
class TermBase(BaseModel):
    class_id: str | None = (
        None  # Optional only if type_id is not provided; used for concept_type
    )
    type_id: str | None = (
        None  # Optional only if class_if is not provided; used for relationship_type and semantic_type
    )
    uid: str | None = Field(
        None,
        description="For OBO ontologies, this should be the CUI; for ASHMATICS it will be the string portion of the ObjectId",
    )  # for snomed and other bioportal ontologies, this should be the "C" number that is unique to their data.  For ASHMATICS, it will be string portion of the ObjectId
    key: str = Field(
        ...,
        description="key is the harmonized term with lower-case and _ connectors as the common key across ASHMATICS",
    )  # Unique identifier for the term
    prefLabel: str = Field(
        ...,
        description="Primary human-readable label following W3C/OBO standards - typically First capital rest lower",
    )  # Primary human-readable name of the term
    altLabel: list[str] | None = Field(
        None, description="Alternative labels and synonyms for the term"
    )  # Alternative labels/synonyms
    ontology: str
    category_type: str | None = Field(
        default="concept_type",
        description="One of concept_type, relationship_type, or semantic_type",
    )
    semantic_type: str | None = None
    definition: str | None = None
    has_children: bool | None = False
    properties: dict[str, Any] | None = None  # Additional properties for the term
    parent_uri: str | None = None
    children_uri: str | None = None  # List of URIs for child terms
    # URI for the term in the ontology, if applicable
    uri: str | None = None
    synonyms: list[str] | None = None
    mappings: list[OntologyMapping] | None = Field(
        None, description="External ontology mappings to other terminologies"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "uuid": "ObjectId(e1d7a3b2-c6f8-4d29-8b3e-f4a9c2d1e0b7)",
                "class_id": "24136001",
                "uid": "e1d7a3b2-c6f8-4d29-8b3e-f4a9c2d1e0b7",
                "label": "Hip Joint",
                "ontology": "SNOMED_CT",
                "semantic_type": "T023",
                "definition": "Joint between the femur and os coxae",
                "has_children": True,
                "properties": {"cuid": "12345fsdgerg", "tree": "https://example.com"},
                "parent_uri": "http://data.bioontology.org/ontologies/SNOMEDCT/classes/39352004",
                "children_uri": [
                    "http://data.bioontology.org/ontologies/SNOMEDCT/classes/24136001",
                    "http://data.bioontology.org/ontologies/SNOMEDCT/classes/39352004",
                ],
                "uri": "http://data.bioontology.org/ontologies/SNOMEDCT/classes/24136001",
                "synonyms": ["Articulation of femur with os coxae", "Hip articulation"],
                "mappings": [
                    {
                        "prefLabel": "Hip Joint",
                        "ontology": "RADLEX",
                        "class_id": "RID39298",
                        "uri": "http://radlex.org/RID39298",
                    }
                ],
            }
        }
    }


# ===========================
# -- TermCreate: A schema for creating a new term in the ontology. updatet 5/15/25
class TermCreate(TermBase):
    class_id: str | None = None  # Optional on create, can be auto-generated
    type_id: str | None = None  # Optional on create, can be auto-generated
    ontology: str | None = None  # Optional on create, can have default
    prefLabel: str = Field(..., description="Primary human-readable label")
    altLabel: list[str] | None = Field(
        None, description="Alternative labels and synonyms"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "prefLabel": "Hip Joint",
                "altLabel": ["Hip articulation"],
                "ontology": "SNOMED_CT",
                "class_id": "24136001",
                "definition": "Joint between the femur and os coxae",
                "mappings": [
                    {
                        "prefLabel": "Hip Joint",
                        "ontology": "RADLEX",
                        "class_id": "RID39298",
                        "uri": "http://radlex.org/RID39298",
                    }
                ],
            }
        }
    }


# ====
# Use For term operations with database (with MongoDB _id)
class TermDB(TermBase):
    id: PyObjectId | str = Field(default_factory=PyObjectId, alias="_id")
    created_at: datetime = Field(default_factory=eastern_now)
    updated_at: datetime = Field(default_factory=eastern_now)
    # NOTE - it seems that the json_encoders are not working for the _id so using root_validator also

    @model_validator(mode="before")
    def convert_object_id(cls, values):
        # Convert _id from ObjectId/PyObjectId to string if needed during serialization
        if "_id" in values and isinstance(values["_id"], (ObjectId, PyObjectId)):
            values["_id"] = str(values["_id"])

        # Also handle the case where the key is 'id' instead of '_id'
        if "id" in values and isinstance(values["id"], (ObjectId, PyObjectId)):
            values["id"] = str(values["id"])

        return values

    model_config = {
        "arbitrary_types_allowed": True,
        "populate_by_name": True,
    }


# ===========================
# For API responses
class TermResponse(TermBase):
    id: str = Field(alias="_id")  # String representation of MongoDB ObjectId
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="before")
    def convert_object_id(cls, values):
        # Convert _id from ObjectId/PyObjectId to string if needed
        if "_id" in values and isinstance(values["_id"], (ObjectId, PyObjectId)):
            values["_id"] = str(values["_id"])
        return values

    model_config = {
        "populate_by_name": True,
        "arbitrary_types_allowed": True,  # to allows arbitrary types
        "json_schema_extra": {
            "example": {
                "_id": "507f1f77bcf86cd799439011",
                "class_id": "24136001",
                "prefLabel": "Hip Joint",
                "altLabel": ["Hip articulation", "Articulation of femur with os coxae"],
                "ontology": "SNOMED_CT",
                "semantic_type": "T023",
                "definition": "Joint between the femur and os coxae",
                "has_children": True,
                "parent_uri": "http://data.bioontology.org/ontologies/SNOMEDCT/classes/39352004",
                "children_uri": [
                    "http://data.bioontology.org/ontologies/SNOMEDCT/classes/24136001",
                    "http://data.bioontology.org/ontologies/SNOMEDCT/classes/39352004",
                ],
                "uri": "http://data.bioontology.org/ontologies/SNOMEDCT/classes/24136001",
                "synonyms": ["Articulation of femur with os coxae", "Hip articulation"],
                "mappings": [
                    {
                        "prefLabel": "Hip Joint",
                        "ontology": "RADLEX",
                        "class_id": "RID39298",
                        "uri": "http://radlex.org/RID39298",
                    }
                ],
                "created_at": "2023-01-01T00:00:00",
                "updated_at": "2023-01-01T00:00:00",
            }
        },
    }


# ===========================
# -- use this class for responses from methods that generate an operation to/in the DB.
class TermOperationResult(BaseModel):
    success: bool
    term: TermResponse | None = None
    error_message: str | None = None


# ==========================
# For term value items in valuesets and Categories?
class TermValue(BaseModel):
    prefLabel: str = Field(..., description="Primary label for the term value")
    altLabel: list[str] | None = Field(
        None, description="Alternative labels for the term value"
    )
    uid: str = Field(..., description="String representation of MongoDB _id")
    class_id: str = Field("", description="Ontology class identifier")
    ontology: str | None = Field(None, description="Source ontology name")


# -- TermUpdate: A schema for updating an existing term in the ontology., update 5/15/25 JFK
# -- This schema allows for partial updates to the term's properties.
# ============================
class TermUpdate(BaseModel):
    prefLabel: str | None = Field(None, description="Update primary label")
    altLabel: list[str] | None = Field(None, description="Update alternative labels")
    ontology: str | None = None
    semantic_type: str | None = None
    definition: str | None = None
    has_children: bool | None = None
    parent_uri: str | None = None
    children_uri: list[str] | None = None
    uri: str | None = None
    synonyms: list[str] | None = None
    add_mappings: list[OntologyMapping] | None = None
    remove_mappings: list[str] | None = None  # List of class_ids to remove

    model_config = {
        "json_schema_extra": {  # Changed from schema_extra to json_schema_extra
            "example": {
                "prefLabel": "Updated Hip Joint",
                "altLabel": ["Updated Hip articulation"],
                "definition": "Joint between the femur and acetabulum of the os coxae",
                "has_children": True,
                "children_uri": [
                    "http://data.bioontology.org/ontologies/SNOMEDCT/classes/24136001"
                ],
                "add_mappings": [
                    {
                        "prefLabel": "Hip Joint",
                        "ontology": "UMLS",
                        "class_id": "C0019552",
                        "uri": "http://linkedlifedata.com/resource/umls/id/C0019552",
                    }
                ],
                "remove_mappings": ["RID39298"],
            }
        }
    }


# ==========================
# -- TermResponse: A schema for the response when retrieving a term from the ontology.
# -- This schema includes all the properties of the term, including its UUID - which is the Object_ID in the DataStore usually .. and mappings.
class TermValidationResponse(BaseModel):
    prefLabel: str = Field(..., description="Primary label of the validated term")
    altLabel: list[str] | None = Field(
        None, description="Alternative labels if found"
    )
    exists: bool
    in_ontology: bool
    ontology_id: str | None = None
    class_id: str | None = None
    type_id: str | None = None
    confidence: float | None = None

    # Add a root validator to check the constraint
    @model_validator(mode="before")
    def validate_id_fields(cls, values):
        class_id = values.get("class_id")
        type_id = values.get("type_id")

        # Case 1: Both are None or empty strings
        if (class_id is None or class_id == "") and (type_id is None or type_id == ""):
            raise ValueError("At least one of 'class_id' or 'type_id' must be provided")

        # Case 2: Both have values
        if class_id and type_id:
            raise ValueError(
                "Only one of 'class_id' or 'type_id' should be provided, not both"
            )

        return values


# ============================


# ==============================================
#   TermRelationship
# ==============================================

# -- TermRelationship: A schema for representing a relationship between two terms.
# NOTE: Did RESOLVED 5/15/25 todo: Make a class for relationship_type (I think), because realtionship_types should be constrained by ontology and CVs


class TermRelationshipType(str, Enum):
    IS_A = "is_a"
    PART_OF = "part_of"
    HAS_PART = "has_part"
    BROADER = "broader"
    NARROWER = "narrower"
    SYNONYM = "synonym"
    SIBLING = "sibling"


# =============================
class TermRelationship(BaseModel):
    relationship_type: TermRelationshipType
    source_term_id: str
    target_term_id: str

    model_config = {
        "json_schema_extra": {
            "example": {
                "relationship_type": "is_a",
                "source_term_id": "507f1f77bcf86cd799439011",
                "target_term_id": "507f1f77bcf86cd799439012",
            }
        }
    }


# =============================
class TermWithRelationships(TermBase):
    relationships: list[TermRelationship] = []


# =============================
# classes for mapping operations
class MappingAddRequest(BaseModel):
    term_uuid: UUID
    mapping: OntologyMapping

    model_config = {
        "json_schema_extra": {
            "example": {
                "term_uuid": "e1d7a3b2-c6f8-4d29-8b3e-f4a9c2d1e0b7",
                "mapping": {
                    "prefLabel": "Hip Joint",
                    "ontology": "RADLEX",
                    "class_id": "RID39298",
                    "uri": "http://radlex.org/RID39298",
                },
            }
        }
    }


# =============================
# -- MappingRemoveRequest: A schema for removing a mapping from a term.
class MappingRemoveRequest(BaseModel):
    term_uuid: UUID
    mapping_class_id: str
    mapping_ontology: str | None = (
        None  # Optional to further constrain which mapping to remove
    )
    model_config = {
        "json_schema_extra": {
            "example": {
                "term_uuid": "e1d7a3b2-c6f8-4d29-8b3e-f4a9c2d1e0b7",
                "mapping_class_id": "RID39298",
                "mapping_ontology": "RADLEX",
            }
        }
    }


# Alias for backward compatibility
Term = TermResponse
