# Copyright (c) 2025-2026, Asher Informatics PBC
"""
ASHCAI Pydantic Schemas - Validation schemas for ASHCAI Clinical AI Governance ontology.

Last Updated: 2026-01-20
- Added field_validator for datetime parsing to handle ISO string timestamps from MongoDB

This module defines Pydantic schemas for validating ASHCAI governance entities:
- PolicyDomain, ProcessDomain, BasePractice
- SOPTemplate, WorkProductTemplate, ExemplarControl
- RegulatoryFramework, RegulatoryRequirement
- Customer implementation instances

All schemas include:
- `ontology: Literal["ashcai"]` for type discrimination
- Validators for natural business ID patterns
- MongoDB ObjectId handling
- ISO string to datetime parsing for timestamp fields

Usage:
    from ashmatics_tools.ontology.terms.ashcai_schemas import (
        PolicyDomainCreate,
        PolicyDomainResponse,
        ProcessDomainCreate,
        RegulatoryRequirementCreate,
    )

    # Validate incoming data
    policy_data = PolicyDomainCreate(
        domain_id="MMP-001",
        domain_code="MMP",
        label="Model Monitoring Policy",
        description="Policy governing AI model monitoring"
    )

    # Convert to response format
    response = PolicyDomainResponse.model_validate(db_document)
"""

import re
from datetime import datetime
from enum import Enum
from typing import Any, Literal

from bson import ObjectId
from pydantic import BaseModel, Field, field_validator, model_validator

# ============================================================================
# ID PATTERN VALIDATORS
# ============================================================================

# Regex patterns for natural business IDs
ID_PATTERNS = {
    "PolicyDomain": re.compile(r"^[A-Z]{2,4}-\d{3}$"),
    "ProcessDomain": re.compile(r"^[A-Z]{2,3}$"),
    "BasePractice": re.compile(r"^[A-Z]{2,3}\.BP\d{2}$"),
    "SOPTemplate": re.compile(r"^SOP-[A-Z]{2,3}-\d{2}$"),
    "WorkProductTemplate": re.compile(r"^WP-[A-Z]{2,3}-\d{2}(-[A-Za-z0-9-]+)?$"),
    "ExemplarControl": re.compile(r"^EXC-A\d{1,2}-\d{2}$"),
    "RegulatoryRequirement": re.compile(r"^[A-Z]+-[A-Z0-9.-]+$"),
    "AIManagementSystem": re.compile(r"^[A-Za-z0-9]+-AIMS(-v\d+\.\d+)?$"),
}


def validate_id_pattern(entity_type: str, value: str) -> str:
    """Validate that an ID matches the expected pattern for its entity type."""
    if entity_type not in ID_PATTERNS:
        return value  # Allow if no pattern defined

    pattern = ID_PATTERNS[entity_type]
    if not pattern.match(value):
        raise ValueError(
            f"Invalid {entity_type} ID format: '{value}'. "
            f"Expected pattern: {pattern.pattern}"
        )
    return value


# ============================================================================
# ENUMS
# ============================================================================

class EntityType(str, Enum):
    """ASHCAI entity types."""
    POLICY_DOMAIN = "PolicyDomain"
    PROCESS_DOMAIN = "ProcessDomain"
    BASE_PRACTICE = "BasePractice"
    SOP_TEMPLATE = "SOPTemplate"
    WORK_PRODUCT_TEMPLATE = "WorkProductTemplate"
    PROCESS_OUTPUT = "ProcessOutput"
    EXEMPLAR_CONTROL = "ExemplarControl"
    REGULATORY_FRAMEWORK = "RegulatoryFramework"
    REGULATORY_FUNCTION = "RegulatoryFunction"
    REGULATORY_CATEGORY = "RegulatoryCategory"
    REGULATORY_REQUIREMENT = "RegulatoryRequirement"
    AI_MANAGEMENT_SYSTEM = "AIManagementSystem"
    POLICY_DOCUMENT = "PolicyDocument"
    SOP_EXECUTION = "SOPExecution"
    WORK_PRODUCT = "WorkProduct"
    CONTROL_ASSESSMENT = "ControlAssessment"
    AUDIT_EVIDENCE = "AuditEvidence"


class EntityStatus(str, Enum):
    """Status values for ASHCAI entities."""
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    DRAFT = "draft"
    ARCHIVED = "archived"


class AshcaiRelationshipType(str, Enum):
    """ASHCAI relationship types (from TDD-001)."""
    # Policy to Process
    SPECIFIES = "specifies"
    SPECIFIED_BY = "specifiedBy"

    # Process to Practice
    CONTAINS_BASE_PRACTICE = "containsBasePractice"
    BELONGS_TO_PROCESS_DOMAIN = "belongsToProcessDomain"

    # Practice to SOP
    REALIZED_BY = "realizedBy"
    REALIZES = "realizes"

    # SOP to Work Product
    PRODUCES = "produces"
    PRODUCED_BY = "producedBy"

    # SOP to Tool
    REQUIRES = "requires"
    REQUIRED_BY = "requiredBy"

    # Work Product to Output
    COMPOSED_INTO = "composedInto"
    COMPOSED_FROM = "composedFrom"

    # Evidence relationships
    SERVES_AS_EVIDENCE_FOR = "servesAsEvidenceFor"
    EVIDENCED_BY = "evidencedBy"

    # Control mappings
    MAPS_TO_ISO = "mapsToISO"
    MAPPED_FROM = "mappedFrom"
    VALIDATES_COMPLIANCE_WITH = "validatesComplianceWith"
    VALIDATED_BY = "validatedBy"

    # Cross-domain
    INTEGRATES_WITH = "integratesWith"
    TRIGGERS_ACTIVITY = "triggersActivity"
    TRIGGERED_BY = "triggeredBy"

    # Regulatory crosswalk
    ADDRESSED_BY = "addressedBy"
    ADDRESSES = "addresses"
    IMPLEMENTED_THROUGH = "implementedThrough"
    IMPLEMENTS = "implements"
    OPERATIONALIZED_IN = "operationalizedIn"
    OPERATIONALIZES = "operationalizes"

    # Template/Instance
    INSTANTIATED_FROM = "instantiatedFrom"
    HAS_INSTANCE = "hasInstance"
    PART_OF_AIMS = "partOfAIMS"
    CONTAINS = "contains"

    # Hierarchy
    HAS_FUNCTION = "hasFunction"
    FUNCTION_OF = "functionOf"
    HAS_CATEGORY = "hasCategory"
    CATEGORY_OF = "categoryOf"
    HAS_REQUIREMENT = "hasRequirement"
    REQUIREMENT_OF = "requirementOf"

    # General
    RELATED_TO = "relatedTo"
    HAS_OVERVIEW_SUMMARY = "hasOverviewSummary"
    OVERVIEW_OF = "overviewOf"
    HAS_TEMPLATE = "hasTemplate"
    TEMPLATE_FOR = "templateFor"
    DERIVED_INTO = "derivedInto"
    DERIVED_FROM = "derivedFrom"


# ============================================================================
# BASE MODELS
# ============================================================================

class AshcaiBaseModel(BaseModel):
    """Base model for all ASHCAI entities."""

    ontology: Literal["ashcai"] = Field(
        default="ashcai",
        description="Ontology discriminator - always 'ashcai' for ASHCAI entities"
    )
    entity_type: EntityType = Field(..., description="Type of ASHCAI entity")
    semantic_type: str = Field(..., description="Semantic type ID (T92xx)")
    prefLabel: str = Field(..., description="Primary human-readable label")
    status: EntityStatus = Field(
        default=EntityStatus.ACTIVE,
        description="Entity lifecycle status"
    )

    model_config = {
        "use_enum_values": True,
        "populate_by_name": True,
    }


class AshcaiBaseCreate(BaseModel):
    """Base model for creating ASHCAI entities."""

    ontology: Literal["ashcai"] = Field(default="ashcai")
    prefLabel: str = Field(..., description="Primary human-readable label")
    description: str | None = Field(None, description="Full description")

    model_config = {
        "use_enum_values": True,
    }


class AshcaiBaseDB(AshcaiBaseModel):
    """Base model for ASHCAI entities stored in MongoDB."""

    id: str = Field(alias="_id", description="Natural business ID")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")
    created_by: str = Field(default="system", description="Creator identifier")
    version: int = Field(default=1, description="Document version")

    @field_validator("created_at", "updated_at", mode="before")
    @classmethod
    def parse_datetime(cls, v: Any) -> datetime:
        """Parse ISO string timestamps to datetime objects."""
        if v is None:
            return v
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            # Handle ISO format strings (with or without timezone)
            return datetime.fromisoformat(v.replace("Z", "+00:00"))
        return v

    @model_validator(mode="before")
    @classmethod
    def convert_object_id(cls, values: dict[str, Any]) -> dict[str, Any]:
        """Convert MongoDB ObjectId to string if present."""
        if "_id" in values and isinstance(values["_id"], ObjectId):
            values["_id"] = str(values["_id"])
        if "id" in values and isinstance(values["id"], ObjectId):
            values["id"] = str(values["id"])
        return values

    model_config = {
        "arbitrary_types_allowed": True,
        "populate_by_name": True,
    }


class AshcaiBaseResponse(AshcaiBaseModel):
    """Base model for ASHCAI API responses."""

    id: str = Field(alias="_id", description="Natural business ID")
    created_at: datetime
    updated_at: datetime

    @field_validator("created_at", "updated_at", mode="before")
    @classmethod
    def parse_datetime(cls, v: Any) -> datetime:
        """Parse ISO string timestamps to datetime objects."""
        if v is None:
            return v
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            return datetime.fromisoformat(v.replace("Z", "+00:00"))
        return v

    @model_validator(mode="before")
    @classmethod
    def convert_object_id(cls, values: dict[str, Any]) -> dict[str, Any]:
        """Convert MongoDB ObjectId to string if present."""
        if "_id" in values and isinstance(values["_id"], ObjectId):
            values["_id"] = str(values["_id"])
        return values

    model_config = {
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }


# ============================================================================
# POLICY DOMAIN SCHEMAS
# ============================================================================

class PolicyDomainCreate(AshcaiBaseCreate):
    """Schema for creating a PolicyDomain."""

    domain_id: str = Field(
        ...,
        description="Natural business ID (e.g., MMP-001)",
        json_schema_extra={"examples": ["MMP-001", "TPP-001", "AGP-001"]}
    )
    domain_code: str = Field(
        ...,
        description="Short code (e.g., MMP)",
        min_length=2,
        max_length=4
    )
    framework_version: str = Field(
        default="v0.8.0",
        description="CAI Framework version"
    )
    specifies: list[str] = Field(
        default_factory=list,
        description="List of ProcessDomain IDs this policy specifies"
    )
    validated_by: list[str] = Field(
        default_factory=list,
        description="List of ExemplarControl IDs that validate this policy"
    )
    overview_summary: str | None = Field(
        None,
        description="Path to overview summary document"
    )
    template_path: str | None = Field(
        None,
        description="Path to policy template"
    )

    @field_validator("domain_id")
    @classmethod
    def validate_domain_id(cls, v: str) -> str:
        return validate_id_pattern("PolicyDomain", v)

    model_config = {
        "json_schema_extra": {
            "example": {
                "domain_id": "MMP-001",
                "domain_code": "MMP",
                "prefLabel": "Model Monitoring Policy",
                "description": "Policy governing AI model monitoring requirements",
                "framework_version": "v0.8.0",
                "specifies": ["MON"],
                "validated_by": ["EXC-A7-04", "EXC-A6-02"]
            }
        }
    }


class PolicyDomainDB(AshcaiBaseDB):
    """PolicyDomain as stored in MongoDB."""

    entity_type: Literal[EntityType.POLICY_DOMAIN] = EntityType.POLICY_DOMAIN
    semantic_type: str = "T9202"
    domainCode: str
    description: str = ""
    frameworkVersion: str = "v0.8.0"
    specifies: list[str] = Field(default_factory=list)
    validatedBy: list[str] = Field(default_factory=list)
    hasOverviewSummary: str | None = None
    hasTemplate: str | None = None


class PolicyDomainResponse(AshcaiBaseResponse):
    """PolicyDomain API response."""

    entity_type: Literal[EntityType.POLICY_DOMAIN] = EntityType.POLICY_DOMAIN
    semantic_type: str = "T9202"
    domainCode: str
    description: str
    frameworkVersion: str
    specifies: list[str]
    validatedBy: list[str]
    hasOverviewSummary: str | None
    hasTemplate: str | None


# ============================================================================
# PROCESS DOMAIN SCHEMAS
# ============================================================================

class ProcessDomainCreate(AshcaiBaseCreate):
    """Schema for creating a ProcessDomain."""

    domain_id: str = Field(
        ...,
        description="Natural business ID (e.g., MON)",
        json_schema_extra={"examples": ["MON", "RM", "SA", "OVR", "PV"]}
    )
    primary_function: str = Field(
        ...,
        description="Primary function description"
    )
    integrates_with: list[str] = Field(
        default_factory=list,
        description="List of other ProcessDomain IDs this integrates with"
    )

    @field_validator("domain_id")
    @classmethod
    def validate_domain_id(cls, v: str) -> str:
        return validate_id_pattern("ProcessDomain", v)

    model_config = {
        "json_schema_extra": {
            "example": {
                "domain_id": "MON",
                "prefLabel": "Model Monitoring",
                "description": "Continuous monitoring of AI model performance",
                "primary_function": "Monitor AI model performance and trigger responses",
                "integrates_with": ["RM", "SA", "OVR"]
            }
        }
    }


class ProcessDomainDB(AshcaiBaseDB):
    """ProcessDomain as stored in MongoDB."""

    entity_type: Literal[EntityType.PROCESS_DOMAIN] = EntityType.PROCESS_DOMAIN
    semantic_type: str = "T9203"
    primaryFunction: str
    description: str = ""
    integratesWith: list[str] = Field(default_factory=list)


class ProcessDomainResponse(AshcaiBaseResponse):
    """ProcessDomain API response."""

    entity_type: Literal[EntityType.PROCESS_DOMAIN] = EntityType.PROCESS_DOMAIN
    semantic_type: str = "T9203"
    primaryFunction: str
    description: str
    integratesWith: list[str]


# ============================================================================
# BASE PRACTICE SCHEMAS
# ============================================================================

class BasePracticeCreate(AshcaiBaseCreate):
    """Schema for creating a BasePractice."""

    practice_id: str = Field(
        ...,
        description="Natural business ID (e.g., MON.BP01)",
        json_schema_extra={"examples": ["MON.BP01", "RM.BP03", "SA.BP02"]}
    )
    process_domain: str = Field(
        ...,
        description="Parent ProcessDomain ID"
    )
    duration: str | None = Field(
        None,
        description="Expected duration"
    )
    sequence_order: int | None = Field(
        None,
        description="Order within the process domain",
        ge=1
    )

    @field_validator("practice_id")
    @classmethod
    def validate_practice_id(cls, v: str) -> str:
        return validate_id_pattern("BasePractice", v)

    model_config = {
        "json_schema_extra": {
            "example": {
                "practice_id": "MON.BP01",
                "prefLabel": "Rollout and Change Management",
                "description": "Managing AI model rollout and changes",
                "process_domain": "MON",
                "duration": "Ongoing",
                "sequence_order": 1
            }
        }
    }


class BasePracticeDB(AshcaiBaseDB):
    """BasePractice as stored in MongoDB."""

    entity_type: Literal[EntityType.BASE_PRACTICE] = EntityType.BASE_PRACTICE
    semantic_type: str = "T9204"
    processDomain: str
    description: str = ""
    duration: str | None = None
    sequenceOrder: int | None = None


class BasePracticeResponse(AshcaiBaseResponse):
    """BasePractice API response."""

    entity_type: Literal[EntityType.BASE_PRACTICE] = EntityType.BASE_PRACTICE
    semantic_type: str = "T9204"
    processDomain: str
    description: str
    duration: str | None
    sequenceOrder: int | None


# ============================================================================
# SOP TEMPLATE SCHEMAS
# ============================================================================

class SOPTemplateCreate(AshcaiBaseCreate):
    """Schema for creating an SOPTemplate."""

    sop_id: str = Field(
        ...,
        description="Natural business ID (e.g., SOP-MON-01)",
        json_schema_extra={"examples": ["SOP-MON-01", "SOP-RM-02", "SOP-SA-01"]}
    )
    purpose: str = Field(
        ...,
        description="Purpose statement"
    )
    base_practice: str | None = Field(
        None,
        description="ID of the BasePractice this SOP realizes"
    )
    produces: list[str] = Field(
        default_factory=list,
        description="List of WorkProductTemplate IDs this SOP produces"
    )
    requires_tools: list[str] = Field(
        default_factory=list,
        description="List of tools required"
    )

    @field_validator("sop_id")
    @classmethod
    def validate_sop_id(cls, v: str) -> str:
        return validate_id_pattern("SOPTemplate", v)

    model_config = {
        "json_schema_extra": {
            "example": {
                "sop_id": "SOP-MON-01",
                "prefLabel": "Model Deployment SOP",
                "purpose": "Standard procedure for deploying AI models to production",
                "description": "Detailed procedure for AI model deployment",
                "base_practice": "MON.BP01",
                "produces": ["WP-MON-01-Communication-Plan", "WP-MON-01-Training-Materials"]
            }
        }
    }


class SOPTemplateDB(AshcaiBaseDB):
    """SOPTemplate as stored in MongoDB."""

    entity_type: Literal[EntityType.SOP_TEMPLATE] = EntityType.SOP_TEMPLATE
    semantic_type: str = "T9205"
    purpose: str
    description: str = ""
    basePractice: str | None = None
    produces: list[str] = Field(default_factory=list)
    requiresTools: list[str] = Field(default_factory=list)


class SOPTemplateResponse(AshcaiBaseResponse):
    """SOPTemplate API response."""

    entity_type: Literal[EntityType.SOP_TEMPLATE] = EntityType.SOP_TEMPLATE
    semantic_type: str = "T9205"
    purpose: str
    description: str
    basePractice: str | None
    produces: list[str]
    requiresTools: list[str]


# ============================================================================
# WORK PRODUCT TEMPLATE SCHEMAS
# ============================================================================

class WorkProductTemplateCreate(AshcaiBaseCreate):
    """Schema for creating a WorkProductTemplate."""

    wp_id: str = Field(
        ...,
        description="Natural business ID (e.g., WP-MON-01-Dashboard)",
        json_schema_extra={"examples": ["WP-MON-01", "WP-MON-02-Dashboard", "WP-RM-01-RiskRegister"]}
    )
    evidence_type: str = Field(
        ...,
        description="Type of evidence (Document, Report, Dashboard, etc.)"
    )
    format: str | None = Field(
        None,
        description="File format or structure"
    )
    produced_by: str | None = Field(
        None,
        description="SOPTemplate ID that produces this work product"
    )
    serves_as_evidence_for: list[str] = Field(
        default_factory=list,
        description="List of ExemplarControl IDs this provides evidence for"
    )

    @field_validator("wp_id")
    @classmethod
    def validate_wp_id(cls, v: str) -> str:
        return validate_id_pattern("WorkProductTemplate", v)

    model_config = {
        "json_schema_extra": {
            "example": {
                "wp_id": "WP-MON-02-Dashboard",
                "prefLabel": "Monitoring Dashboard",
                "description": "Real-time dashboard for AI model performance monitoring",
                "evidence_type": "Dashboard",
                "format": "Web Application",
                "produced_by": "SOP-MON-02",
                "serves_as_evidence_for": ["EXC-A7-04"]
            }
        }
    }


class WorkProductTemplateDB(AshcaiBaseDB):
    """WorkProductTemplate as stored in MongoDB."""

    entity_type: Literal[EntityType.WORK_PRODUCT_TEMPLATE] = EntityType.WORK_PRODUCT_TEMPLATE
    semantic_type: str = "T9206"
    evidenceType: str
    format: str | None = None
    description: str = ""
    producedBy: str | None = None
    servesAsEvidenceFor: list[str] = Field(default_factory=list)


class WorkProductTemplateResponse(AshcaiBaseResponse):
    """WorkProductTemplate API response."""

    entity_type: Literal[EntityType.WORK_PRODUCT_TEMPLATE] = EntityType.WORK_PRODUCT_TEMPLATE
    semantic_type: str = "T9206"
    evidenceType: str
    format: str | None
    description: str
    producedBy: str | None
    servesAsEvidenceFor: list[str]


# ============================================================================
# EXEMPLAR CONTROL SCHEMAS
# ============================================================================

class ExemplarControlCreate(AshcaiBaseCreate):
    """Schema for creating an ExemplarControl."""

    control_id: str = Field(
        ...,
        description="Natural business ID (e.g., EXC-A7-04)",
        json_schema_extra={"examples": ["EXC-A7-04", "EXC-A10-02", "EXC-A6-02"]}
    )
    iso_control: str | None = Field(
        None,
        description="Corresponding ISO 42001 control reference"
    )
    evidenced_by: list[str] = Field(
        default_factory=list,
        description="List of WorkProductTemplate IDs that provide evidence"
    )
    validates_policies: list[str] = Field(
        default_factory=list,
        description="List of PolicyDomain IDs this control validates"
    )
    implements_requirements: list[str] = Field(
        default_factory=list,
        description="List of RegulatoryRequirement IDs this implements"
    )

    @field_validator("control_id")
    @classmethod
    def validate_control_id(cls, v: str) -> str:
        return validate_id_pattern("ExemplarControl", v)

    model_config = {
        "json_schema_extra": {
            "example": {
                "control_id": "EXC-A7-04",
                "prefLabel": "Performance Monitoring Control",
                "description": "Control for monitoring AI model performance",
                "iso_control": "A.7.5",
                "evidenced_by": ["WP-MON-02-Dashboard", "WP-MON-02-Report"],
                "validates_policies": ["MMP-001"]
            }
        }
    }


class ExemplarControlDB(AshcaiBaseDB):
    """ExemplarControl as stored in MongoDB."""

    entity_type: Literal[EntityType.EXEMPLAR_CONTROL] = EntityType.EXEMPLAR_CONTROL
    semantic_type: str = "T9208"
    isoControl: str | None = None
    description: str = ""
    evidencedBy: list[str] = Field(default_factory=list)
    validatesPolicies: list[str] = Field(default_factory=list)
    implementsRequirements: list[str] = Field(default_factory=list)


class ExemplarControlResponse(AshcaiBaseResponse):
    """ExemplarControl API response."""

    entity_type: Literal[EntityType.EXEMPLAR_CONTROL] = EntityType.EXEMPLAR_CONTROL
    semantic_type: str = "T9208"
    isoControl: str | None
    description: str
    evidencedBy: list[str]
    validatesPolicies: list[str]
    implementsRequirements: list[str]


# ============================================================================
# REGULATORY FRAMEWORK SCHEMAS
# ============================================================================

class RegulatoryFrameworkCreate(AshcaiBaseCreate):
    """Schema for creating a RegulatoryFramework."""

    framework_id: str = Field(
        ...,
        description="Natural business ID (e.g., NIST-AI-RMF)"
    )
    authority: str = Field(
        ...,
        description="Issuing authority"
    )
    framework_version: str | None = Field(
        None,
        description="Framework version"
    )
    total_requirements: int | None = Field(
        None,
        description="Total number of requirements",
        ge=0
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "framework_id": "NIST-AI-RMF",
                "prefLabel": "NIST AI Risk Management Framework",
                "description": "NIST AI RMF 1.0 for managing risks in AI systems",
                "authority": "National Institute of Standards and Technology",
                "framework_version": "1.0",
                "total_requirements": 72
            }
        }
    }


class RegulatoryFrameworkDB(AshcaiBaseDB):
    """RegulatoryFramework as stored in MongoDB."""

    entity_type: Literal[EntityType.REGULATORY_FRAMEWORK] = EntityType.REGULATORY_FRAMEWORK
    semantic_type: str = "T9209"
    authority: str
    description: str = ""
    frameworkVersion: str | None = None
    totalRequirements: int | None = None


class RegulatoryFrameworkResponse(AshcaiBaseResponse):
    """RegulatoryFramework API response."""

    entity_type: Literal[EntityType.REGULATORY_FRAMEWORK] = EntityType.REGULATORY_FRAMEWORK
    semantic_type: str = "T9209"
    authority: str
    description: str
    frameworkVersion: str | None
    totalRequirements: int | None


# ============================================================================
# REGULATORY REQUIREMENT SCHEMAS
# ============================================================================

class RegulatoryCrosswalk(BaseModel):
    """Crosswalk mappings for a regulatory requirement."""

    addressedBy: list[str] = Field(
        default_factory=list,
        description="PolicyDomain IDs that address this requirement"
    )
    implementedThrough: list[str] = Field(
        default_factory=list,
        description="ExemplarControl IDs that implement this requirement"
    )
    operationalizedIn: list[str] = Field(
        default_factory=list,
        description="ProcessDomain IDs where this is operationalized"
    )
    evidencedBy: list[str] = Field(
        default_factory=list,
        description="WorkProductTemplate IDs that evidence this requirement"
    )


class RegulatoryRequirementCreate(AshcaiBaseCreate):
    """Schema for creating a RegulatoryRequirement."""

    requirement_id: str = Field(
        ...,
        description="Natural business ID (e.g., NIST-MAP-4.2)",
        json_schema_extra={"examples": ["NIST-MAP-4.2", "JC-RUAIH-3", "ISO-A.6.1"]}
    )
    framework_id: str = Field(
        ...,
        description="Parent RegulatoryFramework ID"
    )
    function: str | None = Field(
        None,
        description="Function within framework (e.g., MAP, GOVERN)"
    )
    category: str | None = Field(
        None,
        description="Category within function (e.g., MAP-4)"
    )
    topics: list[str] = Field(
        default_factory=list,
        description="List of topics covered"
    )
    crosswalk: RegulatoryCrosswalk | None = Field(
        None,
        description="Crosswalk mappings to ASHCAI framework"
    )

    @field_validator("requirement_id")
    @classmethod
    def validate_requirement_id(cls, v: str) -> str:
        return validate_id_pattern("RegulatoryRequirement", v)

    model_config = {
        "json_schema_extra": {
            "example": {
                "requirement_id": "NIST-MAP-4.2",
                "prefLabel": "MAP 4.2",
                "description": "Internal risk controls for third-party AI resources",
                "framework_id": "NIST-AI-RMF",
                "function": "MAP",
                "category": "MAP-4",
                "topics": ["Third-party", "Pre-trained models", "Risk controls"],
                "crosswalk": {
                    "addressedBy": ["TPP-001", "MMP-001"],
                    "implementedThrough": ["EXC-A10-02", "EXC-A6-02"],
                    "operationalizedIn": ["MON", "PV"],
                    "evidencedBy": ["WP-MON-01", "WP-PV-03"]
                }
            }
        }
    }


class RegulatoryRequirementDB(AshcaiBaseDB):
    """RegulatoryRequirement as stored in MongoDB."""

    entity_type: Literal[EntityType.REGULATORY_REQUIREMENT] = EntityType.REGULATORY_REQUIREMENT
    semantic_type: str = "T9210"
    framework: str
    function: str | None = None
    category: str | None = None
    description: str = ""
    topics: list[str] = Field(default_factory=list)
    crosswalk: RegulatoryCrosswalk = Field(default_factory=RegulatoryCrosswalk)


class RegulatoryRequirementResponse(AshcaiBaseResponse):
    """RegulatoryRequirement API response."""

    entity_type: Literal[EntityType.REGULATORY_REQUIREMENT] = EntityType.REGULATORY_REQUIREMENT
    semantic_type: str = "T9210"
    framework: str
    function: str | None
    category: str | None
    description: str
    topics: list[str]
    crosswalk: RegulatoryCrosswalk


# ============================================================================
# RELATIONSHIP SCHEMAS
# ============================================================================

class AshcaiRelationshipCreate(BaseModel):
    """Schema for creating an ASHCAI relationship."""

    source_id: str = Field(..., description="Source entity ID")
    target_id: str = Field(..., description="Target entity ID")
    relationship_type: AshcaiRelationshipType = Field(
        ...,
        description="Type of relationship"
    )
    properties: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional relationship properties"
    )

    model_config = {
        "use_enum_values": True,
        "json_schema_extra": {
            "example": {
                "source_id": "MMP-001",
                "target_id": "MON",
                "relationship_type": "specifies",
                "properties": {}
            }
        }
    }


class AshcaiRelationshipDB(BaseModel):
    """ASHCAI relationship as stored in MongoDB."""

    id: str = Field(alias="_id")
    ontology: Literal["ashcai"] = "ashcai"
    source_id: str
    target_id: str
    relationship_type: str
    inverse_type: str | None = None
    symmetric: bool = False
    properties: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    created_by: str = "system"

    @field_validator("created_at", mode="before")
    @classmethod
    def parse_datetime(cls, v: Any) -> datetime:
        """Parse ISO string timestamps to datetime objects."""
        if v is None:
            return v
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            return datetime.fromisoformat(v.replace("Z", "+00:00"))
        return v

    @model_validator(mode="before")
    @classmethod
    def convert_object_id(cls, values: dict[str, Any]) -> dict[str, Any]:
        if "_id" in values and isinstance(values["_id"], ObjectId):
            values["_id"] = str(values["_id"])
        return values

    model_config = {
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }


class AshcaiRelationshipResponse(BaseModel):
    """ASHCAI relationship API response."""

    id: str = Field(alias="_id")
    ontology: Literal["ashcai"] = "ashcai"
    source_id: str
    target_id: str
    relationship_type: str
    inverse_type: str | None
    symmetric: bool
    properties: dict[str, Any]
    created_at: datetime

    @field_validator("created_at", mode="before")
    @classmethod
    def parse_datetime(cls, v: Any) -> datetime:
        """Parse ISO string timestamps to datetime objects."""
        if v is None:
            return v
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            return datetime.fromisoformat(v.replace("Z", "+00:00"))
        return v

    @model_validator(mode="before")
    @classmethod
    def convert_object_id(cls, values: dict[str, Any]) -> dict[str, Any]:
        if "_id" in values and isinstance(values["_id"], ObjectId):
            values["_id"] = str(values["_id"])
        return values

    model_config = {
        "populate_by_name": True,
    }


# ============================================================================
# TRAVERSAL RESPONSE SCHEMAS
# ============================================================================

class PolicyHierarchyResponse(BaseModel):
    """Response for policy hierarchy traversal."""

    policy: PolicyDomainResponse
    processes: list[ProcessDomainResponse] = Field(default_factory=list)
    controls: list[ExemplarControlResponse] = Field(default_factory=list)


class EvidenceChainResponse(BaseModel):
    """Response for evidence chain traversal."""

    control: ExemplarControlResponse
    workProducts: list[WorkProductTemplateResponse] = Field(default_factory=list)


class RegulatoryCrosswalkResponse(BaseModel):
    """Response for regulatory crosswalk traversal."""

    requirement: RegulatoryRequirementResponse
    addressedBy: list[PolicyDomainResponse] = Field(default_factory=list)
    implementedThrough: list[ExemplarControlResponse] = Field(default_factory=list)
    operationalizedIn: list[ProcessDomainResponse] = Field(default_factory=list)
    evidencedBy: list[WorkProductTemplateResponse] = Field(default_factory=list)


# ============================================================================
# OPERATION RESULT SCHEMAS
# ============================================================================

class AshcaiOperationResult(BaseModel):
    """Result of an ASHCAI ontology operation."""

    success: bool
    message: str | None = None
    entity_id: str | None = None
    entity_type: str | None = None
    error_message: str | None = None


class AshcaiListResponse(BaseModel):
    """Paginated list response for ASHCAI entities."""

    items: list[dict[str, Any]]
    total: int
    limit: int
    offset: int
