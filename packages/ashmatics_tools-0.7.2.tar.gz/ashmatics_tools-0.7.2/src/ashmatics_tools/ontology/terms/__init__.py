# Copyright (c) 2025, Asher Informatics PBC
"""
Term Resolution Module

Provides core term lookup and resolution functionality for medical ontologies.
Also includes ASHCAI (Clinical AI Governance) schemas for the CAI Framework.
"""

from .resolver import TermResolver
from .schemas import (
    TermBase,
    TermCreate,
    TermUpdate,
    TermResponse,
    TermOperationResult,
    TermRelationship,
    TermValue,
    OntologyMapping,
)
from .valueset_schemas import (
    ValuesetBase,
    ValuesetDB,
    ValuesetCreate,
    ValuesetOperationResult,
    ValuesetResponse,
)
from .ashcai_schemas import (
    # Enums
    EntityType,
    EntityStatus,
    AshcaiRelationshipType,
    # Policy Domain
    PolicyDomainCreate,
    PolicyDomainDB,
    PolicyDomainResponse,
    # Process Domain
    ProcessDomainCreate,
    ProcessDomainDB,
    ProcessDomainResponse,
    # Base Practice
    BasePracticeCreate,
    BasePracticeDB,
    BasePracticeResponse,
    # SOP Template
    SOPTemplateCreate,
    SOPTemplateDB,
    SOPTemplateResponse,
    # Work Product Template
    WorkProductTemplateCreate,
    WorkProductTemplateDB,
    WorkProductTemplateResponse,
    # Exemplar Control
    ExemplarControlCreate,
    ExemplarControlDB,
    ExemplarControlResponse,
    # Regulatory Framework
    RegulatoryFrameworkCreate,
    RegulatoryFrameworkDB,
    RegulatoryFrameworkResponse,
    # Regulatory Requirement
    RegulatoryRequirementCreate,
    RegulatoryRequirementDB,
    RegulatoryRequirementResponse,
    RegulatoryCrosswalk,
    # Relationships
    AshcaiRelationshipCreate,
    AshcaiRelationshipDB,
    AshcaiRelationshipResponse,
    # Traversal Responses
    PolicyHierarchyResponse,
    EvidenceChainResponse,
    RegulatoryCrosswalkResponse,
    # Operation Results
    AshcaiOperationResult,
    AshcaiListResponse,
)

__all__ = [
    # Term resolver
    "TermResolver",
    # Term schemas
    "TermBase",
    "TermCreate",
    "TermUpdate",
    "TermResponse",
    "TermOperationResult",
    "TermRelationship",
    "TermValue",
    "OntologyMapping",
    # Valueset schemas
    "ValuesetBase",
    "ValuesetDB",
    "ValuesetCreate",
    "ValuesetOperationResult",
    "ValuesetResponse",
    # ASHCAI Enums
    "EntityType",
    "EntityStatus",
    "AshcaiRelationshipType",
    # ASHCAI Policy Domain
    "PolicyDomainCreate",
    "PolicyDomainDB",
    "PolicyDomainResponse",
    # ASHCAI Process Domain
    "ProcessDomainCreate",
    "ProcessDomainDB",
    "ProcessDomainResponse",
    # ASHCAI Base Practice
    "BasePracticeCreate",
    "BasePracticeDB",
    "BasePracticeResponse",
    # ASHCAI SOP Template
    "SOPTemplateCreate",
    "SOPTemplateDB",
    "SOPTemplateResponse",
    # ASHCAI Work Product Template
    "WorkProductTemplateCreate",
    "WorkProductTemplateDB",
    "WorkProductTemplateResponse",
    # ASHCAI Exemplar Control
    "ExemplarControlCreate",
    "ExemplarControlDB",
    "ExemplarControlResponse",
    # ASHCAI Regulatory Framework
    "RegulatoryFrameworkCreate",
    "RegulatoryFrameworkDB",
    "RegulatoryFrameworkResponse",
    # ASHCAI Regulatory Requirement
    "RegulatoryRequirementCreate",
    "RegulatoryRequirementDB",
    "RegulatoryRequirementResponse",
    "RegulatoryCrosswalk",
    # ASHCAI Relationships
    "AshcaiRelationshipCreate",
    "AshcaiRelationshipDB",
    "AshcaiRelationshipResponse",
    # ASHCAI Traversal Responses
    "PolicyHierarchyResponse",
    "EvidenceChainResponse",
    "RegulatoryCrosswalkResponse",
    # ASHCAI Operation Results
    "AshcaiOperationResult",
    "AshcaiListResponse",
]
