# Copyright (c) 2025, Asher Informatics PBC JFK
# Pydantic models for Valuset in the KB tagging system

from datetime import datetime

from bson import ObjectId
from pydantic import BaseModel, Field, model_validator

from .schemas import TermValue


class ValuesetBase(BaseModel):
    name: str
    category_key: str
    description: str | None = None
    values: list[TermValue]
    ontology: str


class ValuesetDB(ValuesetBase):
    created_at: datetime
    updated_at: datetime


class ValuesetCreate(ValuesetBase):
    # Fields needed only for creation
    pass


class ValuesetOperationResult(BaseModel):
    success: bool
    valueset: ValuesetBase = None
    message: str | None = None
    valueset_id: str | None = None


class ValuesetResponse(ValuesetBase):
    id: str = Field(alias="_id")
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="before")
    def convert_object_id(cls, values):
        if (
            isinstance(values, dict)
            and "_id" in values
            and isinstance(values["_id"], (ObjectId, str))
        ):
            values["_id"] = str(values["_id"])
            return values

    model_config = {
        # Allows the model to accept _id from MongoDB
        "populate_by_name": True,
        "arbitrary_types_allowed": True,  # Added for Pydantic V2 compatibility
    }
