"""Azure-compatible document chunker with advanced strategies.

This implementation extracts and modernizes the chunking functionality from the
Ashmatics Knowledgebase project, making it reusable across all Ashmatics applications.

Key Features:
- Tiktoken-based token counting (accurate for OpenAI/Azure models)
- Multiple chunking strategies (semantic, fixed, sliding window, paragraph, sentence)
- Intelligent overlap handling
- Sentence-aware splitting
- Structure preservation
- Compatible with Azure OpenAI embedding models

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
from typing import Any

import nltk
import tiktoken

from .base import ChunkingConfig, ChunkingStrategy, DocumentChunk, DocumentChunker

logger = logging.getLogger(__name__)


class AzureChunker(DocumentChunker):
    """
    Azure-compatible document chunker with tiktoken support.

    This chunker provides production-ready document chunking with accurate
    token counting using tiktoken, which is essential for Azure OpenAI
    embedding models.

    Features:
    - Tiktoken tokenization (cl100k_base encoding for GPT-3.5/4)
    - Multiple chunking strategies
    - Semantic boundary preservation
    - Sentence-aware splitting (uses NLTK)
    - Configurable overlap
    - Structure preservation

    Chunking Strategies:
    - SEMANTIC: Intelligent chunking based on paragraphs and sentences
    - FIXED: Fixed-size chunks with overlap
    - SLIDING: Sliding window approach
    - PARAGRAPH: One paragraph per chunk
    - SENTENCE: One sentence per chunk

    Example:
        >>> config = ChunkingConfig(
        ...     strategy=ChunkingStrategy.DOCLING,
        ...     max_tokens=512,
        ...     chunk_overlap=50
        ... )
        >>> chunker = AzureChunker(config)
        >>> chunks = await chunker.chunk_document(
        ...     content="Long document text...",
        ...     title="My Document",
        ...     source="document.pdf"
        ... )
    """

    # Add Azure-specific strategies
    STRATEGY_SEMANTIC = "semantic"
    STRATEGY_SLIDING_WINDOW = "sliding_window"
    STRATEGY_PARAGRAPH = "paragraph"
    STRATEGY_SENTENCE = "sentence"

    def __init__(self, config: ChunkingConfig):
        """
        Initialize Azure chunker with tiktoken support.

        Args:
            config: Chunking configuration

        Raises:
            ValueError: If configuration is invalid
        """
        super().__init__(config)

        # Initialize tiktoken encoder
        # cl100k_base is used by GPT-3.5-turbo, GPT-4, text-embedding-ada-002
        self.encoding_name = config.extra_config.get("encoding_name", "cl100k_base")

        try:
            self.tokenizer = tiktoken.get_encoding(self.encoding_name)
            logger.info(f"Initialized Azure chunker with tiktoken encoding: {self.encoding_name}")
        except Exception as e:
            logger.error(f"Failed to initialize tiktoken: {e}")
            raise

        # Initialize NLTK for sentence tokenization
        self._ensure_nltk_data()

        # Map config strategy to internal strategy
        self.chunking_strategy = self._map_strategy(config.strategy)

        logger.info(
            f"Azure chunker initialized: strategy={self.chunking_strategy}, "
            f"max_tokens={config.max_tokens}, overlap={config.chunk_overlap}"
        )

    def _ensure_nltk_data(self):
        """Ensure NLTK punkt tokenizer is available."""
        try:
            nltk.data.find("tokenizers/punkt")
        except LookupError:
            logger.info("Downloading NLTK punkt tokenizer...")
            nltk.download("punkt", quiet=True)

    def _map_strategy(self, strategy: ChunkingStrategy) -> str:
        """Map ChunkingStrategy enum to internal strategy string."""
        # Map the existing strategies
        if strategy == ChunkingStrategy.DOCLING:
            # Docling maps to semantic for Azure chunker
            return self.STRATEGY_SEMANTIC
        elif strategy == ChunkingStrategy.SIMPLE:
            return self.STRATEGY_PARAGRAPH
        elif strategy == ChunkingStrategy.FIXED:
            return self.STRATEGY_SLIDING_WINDOW
        else:
            return self.STRATEGY_SEMANTIC

    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text using tiktoken.

        Args:
            text: Text to count tokens for

        Returns:
            Number of tokens
        """
        try:
            return len(self.tokenizer.encode(text))
        except Exception as e:
            logger.warning(f"Token counting failed: {e}, using character estimate")
            # Fallback: rough estimate (4 chars ≈ 1 token)
            return len(text) // 4

    async def chunk_document(
        self,
        content: str,
        title: str,
        source: str,
        metadata: dict[str, Any] | None = None,
        **kwargs,
    ) -> list[DocumentChunk]:
        """
        Chunk a document using the configured strategy.

        Args:
            content: Document content (markdown or text)
            title: Document title
            source: Document source identifier
            metadata: Additional metadata to attach to chunks
            **kwargs: Additional arguments (e.g., document_id, custom_strategy)

        Returns:
            List of document chunks
        """
        if not content or not content.strip():
            logger.warning(f"Empty content for document: {title}")
            return []

        # Allow strategy override
        strategy = kwargs.get("custom_strategy", self.chunking_strategy)

        logger.info(
            f"Chunking document '{title}' using strategy: {strategy}, length: {len(content)} chars"
        )

        # Base metadata
        base_metadata = {
            "title": title,
            "source": source,
            "chunking_strategy": strategy,
            "max_tokens": self.config.max_tokens,
            "overlap_chars": self.config.chunk_overlap,
            "encoding": self.encoding_name,
        }

        if metadata:
            base_metadata.update(metadata)

        # Route to appropriate chunking method
        if strategy == self.STRATEGY_SEMANTIC:
            chunks = await self._chunk_semantic(content, base_metadata)
        elif strategy == self.STRATEGY_SLIDING_WINDOW:
            chunks = await self._chunk_sliding_window(content, base_metadata)
        elif strategy == self.STRATEGY_PARAGRAPH:
            chunks = await self._chunk_by_paragraph(content, base_metadata)
        elif strategy == self.STRATEGY_SENTENCE:
            chunks = await self._chunk_by_sentence(content, base_metadata)
        else:
            # Default to semantic
            logger.warning(f"Unknown strategy '{strategy}', using semantic")
            chunks = await self._chunk_semantic(content, base_metadata)

        logger.info(f"Created {len(chunks)} chunks for document '{title}'")
        return chunks

    async def _chunk_semantic(self, text: str, metadata: dict[str, Any]) -> list[DocumentChunk]:
        """
        Chunk text based on semantic boundaries (paragraphs and sentences).

        This is the most intelligent chunking strategy that:
        - Respects paragraph boundaries
        - Splits large paragraphs by sentences
        - Maintains token limits
        - Preserves document structure

        Args:
            text: Text to chunk
            metadata: Base metadata for chunks

        Returns:
            List of document chunks
        """
        chunks = []
        paragraphs = text.split("\n\n")

        current_chunk = ""
        current_tokens = 0
        chunk_index = 0
        start_char = 0

        for paragraph in paragraphs:
            paragraph = paragraph.strip()
            if not paragraph:
                continue

            paragraph_tokens = self.count_tokens(paragraph)

            # If paragraph alone exceeds max size, split it by sentences
            if paragraph_tokens > self.config.max_tokens:
                # First, add current chunk if it exists
                if current_chunk and current_tokens >= self.config.min_chunk_size:
                    chunk = self._create_chunk(current_chunk, chunk_index, start_char, metadata)
                    chunks.append(chunk)
                    chunk_index += 1
                    start_char += len(current_chunk)
                    current_chunk = ""
                    current_tokens = 0

                # Split large paragraph by sentences
                from nltk.tokenize import sent_tokenize

                sentences = sent_tokenize(paragraph)
                for sentence in sentences:
                    sentence_tokens = self.count_tokens(sentence)

                    if current_tokens + sentence_tokens > self.config.max_tokens:
                        if current_chunk:
                            chunk = self._create_chunk(
                                current_chunk, chunk_index, start_char, metadata
                            )
                            chunks.append(chunk)
                            chunk_index += 1
                            start_char += len(current_chunk)

                        current_chunk = sentence
                        current_tokens = sentence_tokens
                    else:
                        current_chunk = (
                            current_chunk + " " + sentence if current_chunk else sentence
                        )
                        current_tokens += sentence_tokens
            else:
                # Check if adding this paragraph would exceed max size
                if current_tokens + paragraph_tokens > self.config.max_tokens:
                    if current_chunk and current_tokens >= self.config.min_chunk_size:
                        chunk = self._create_chunk(current_chunk, chunk_index, start_char, metadata)
                        chunks.append(chunk)
                        chunk_index += 1
                        start_char += len(current_chunk)

                    current_chunk = paragraph
                    current_tokens = paragraph_tokens
                else:
                    current_chunk = (
                        current_chunk + "\n\n" + paragraph if current_chunk else paragraph
                    )
                    current_tokens += paragraph_tokens

        # Add final chunk
        if current_chunk and len(current_chunk.strip()) >= self.config.min_chunk_size:
            chunk = self._create_chunk(current_chunk, chunk_index, start_char, metadata)
            chunks.append(chunk)

        return chunks

    async def _chunk_sliding_window(
        self, text: str, metadata: dict[str, Any]
    ) -> list[DocumentChunk]:
        """
        Chunk text using sliding window approach with token-based overlap.

        This creates overlapping chunks which can help maintain context
        across chunk boundaries.

        Args:
            text: Text to chunk
            metadata: Base metadata for chunks

        Returns:
            List of document chunks
        """
        chunks = []
        tokens = self.tokenizer.encode(text)

        chunk_index = 0
        start_token = 0

        # Calculate step size (advance by this many tokens each time)
        # Convert overlap from characters to approximate tokens
        overlap_tokens = max(1, self.config.chunk_overlap // 4)
        step_size = self.config.max_tokens - overlap_tokens

        while start_token < len(tokens):
            # Extract chunk tokens
            end_token = min(start_token + self.config.max_tokens, len(tokens))
            chunk_tokens = tokens[start_token:end_token]

            # Decode to text
            chunk_text = self.tokenizer.decode(chunk_tokens)

            # Calculate character positions
            start_char = len(self.tokenizer.decode(tokens[:start_token]))
            end_char = len(self.tokenizer.decode(tokens[:end_token]))

            # Create chunk
            chunk_metadata = {
                **metadata,
                "step_size_tokens": step_size,
                "overlap_tokens": overlap_tokens,
            }

            chunk = DocumentChunk(
                content=chunk_text,
                index=chunk_index,
                start_char=start_char,
                end_char=end_char,
                metadata=chunk_metadata,
                token_count=len(chunk_tokens),
            )

            chunks.append(chunk)

            # Move to next chunk
            if end_token >= len(tokens):
                break

            start_token += step_size
            chunk_index += 1

        return chunks

    async def _chunk_by_paragraph(self, text: str, metadata: dict[str, Any]) -> list[DocumentChunk]:
        """
        Chunk text by paragraphs, one paragraph per chunk.

        Useful for documents with well-defined paragraph structure.

        Args:
            text: Text to chunk
            metadata: Base metadata for chunks

        Returns:
            List of document chunks
        """
        chunks = []
        paragraphs = text.split("\n\n")

        chunk_index = 0
        start_char = 0

        for paragraph in paragraphs:
            paragraph = paragraph.strip()

            # Skip empty or too-small paragraphs
            if not paragraph or len(paragraph) < self.config.min_chunk_size:
                start_char += len(paragraph) + 2  # Account for \n\n
                continue

            token_count = self.count_tokens(paragraph)

            # If paragraph is too large, split it
            if token_count > self.config.max_tokens:
                # Split by sentences and create multiple chunks
                from nltk.tokenize import sent_tokenize

                sentences = sent_tokenize(paragraph)
                current_chunk = ""
                current_tokens = 0

                for sentence in sentences:
                    sentence_tokens = self.count_tokens(sentence)

                    if current_tokens + sentence_tokens > self.config.max_tokens:
                        if current_chunk:
                            chunk = self._create_chunk(
                                current_chunk, chunk_index, start_char, metadata
                            )
                            chunks.append(chunk)
                            chunk_index += 1
                            start_char += len(current_chunk)

                        current_chunk = sentence
                        current_tokens = sentence_tokens
                    else:
                        current_chunk = (
                            current_chunk + " " + sentence if current_chunk else sentence
                        )
                        current_tokens += sentence_tokens

                if current_chunk:
                    chunk = self._create_chunk(current_chunk, chunk_index, start_char, metadata)
                    chunks.append(chunk)
                    chunk_index += 1
                    start_char += len(current_chunk)
            else:
                # Create chunk for this paragraph
                chunk = DocumentChunk(
                    content=paragraph,
                    index=chunk_index,
                    start_char=start_char,
                    end_char=start_char + len(paragraph),
                    metadata={**metadata, "paragraph_index": chunk_index},
                    token_count=token_count,
                )

                chunks.append(chunk)
                chunk_index += 1
                start_char += len(paragraph) + 2  # Account for \n\n

        return chunks

    async def _chunk_by_sentence(self, text: str, metadata: dict[str, Any]) -> list[DocumentChunk]:
        """
        Chunk text by sentences, one sentence per chunk.

        Useful for fine-grained analysis or when sentences are long enough.

        Args:
            text: Text to chunk
            metadata: Base metadata for chunks

        Returns:
            List of document chunks
        """
        from nltk.tokenize import sent_tokenize

        chunks = []
        sentences = sent_tokenize(text)

        chunk_index = 0
        start_char = 0

        for sentence in sentences:
            sentence = sentence.strip()

            # Skip empty or too-small sentences
            if not sentence or len(sentence) < self.config.min_chunk_size:
                start_char += len(sentence) + 1  # Account for space
                continue

            token_count = self.count_tokens(sentence)

            # If sentence is too large, it needs to be split (rare)
            if token_count > self.config.max_tokens:
                logger.warning(
                    f"Sentence exceeds max_tokens ({token_count} > {self.config.max_tokens}), "
                    "splitting by words"
                )
                # Split by words as last resort
                words = sentence.split()
                current_chunk = ""
                current_tokens = 0

                for word in words:
                    word_tokens = self.count_tokens(word)

                    if current_tokens + word_tokens > self.config.max_tokens:
                        if current_chunk:
                            chunk = self._create_chunk(
                                current_chunk, chunk_index, start_char, metadata
                            )
                            chunks.append(chunk)
                            chunk_index += 1
                            start_char += len(current_chunk)

                        current_chunk = word
                        current_tokens = word_tokens
                    else:
                        current_chunk = current_chunk + " " + word if current_chunk else word
                        current_tokens += word_tokens

                if current_chunk:
                    chunk = self._create_chunk(current_chunk, chunk_index, start_char, metadata)
                    chunks.append(chunk)
                    chunk_index += 1
                    start_char += len(current_chunk)
            else:
                # Create chunk for this sentence
                chunk = DocumentChunk(
                    content=sentence,
                    index=chunk_index,
                    start_char=start_char,
                    end_char=start_char + len(sentence),
                    metadata={**metadata, "sentence_index": chunk_index},
                    token_count=token_count,
                )

                chunks.append(chunk)
                chunk_index += 1
                start_char += len(sentence) + 1  # Account for space

        return chunks

    def _create_chunk(
        self, text: str, index: int, start_char: int, metadata: dict[str, Any]
    ) -> DocumentChunk:
        """
        Helper method to create a DocumentChunk.

        Args:
            text: Chunk text
            index: Chunk index
            start_char: Start character position
            metadata: Chunk metadata

        Returns:
            DocumentChunk instance
        """
        token_count = self.count_tokens(text)

        return DocumentChunk(
            content=text,
            index=index,
            start_char=start_char,
            end_char=start_char + len(text),
            metadata=metadata,
            token_count=token_count,
        )

    def get_stats(self) -> dict[str, Any]:
        """
        Get chunker statistics and configuration.

        Returns:
            Dictionary with chunker stats
        """
        return {
            "chunker_type": "AzureChunker",
            "strategy": self.chunking_strategy,
            "encoding": self.encoding_name,
            "max_tokens": self.config.max_tokens,
            "min_chunk_size": self.config.min_chunk_size,
            "chunk_overlap": self.config.chunk_overlap,
            "preserve_structure": self.config.preserve_structure,
        }

    def __repr__(self) -> str:
        """String representation of chunker."""
        return (
            f"AzureChunker(strategy={self.chunking_strategy}, "
            f"max_tokens={self.config.max_tokens}, "
            f"encoding={self.encoding_name})"
        )
