"""Factory for creating chunker instances.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging

from .base import ChunkingConfig, ChunkingStrategy, DocumentChunker

logger = logging.getLogger(__name__)


def create_chunker(
    config: ChunkingConfig | None = None, strategy: str | None = None
) -> DocumentChunker:
    """
    Create a chunker instance.

    Args:
        config: Chunking configuration. If None, uses default config.
        strategy: Chunking strategy override ("docling", "simple", "fixed")

    Returns:
        Initialized chunker instance

    Raises:
        ValueError: If strategy is not recognized

    Example:
        >>> # Create a docling chunker with default config
        >>> chunker = create_chunker()
        >>>
        >>> # Create with custom config
        >>> config = ChunkingConfig(max_tokens=512, strategy=ChunkingStrategy.DOCLING)
        >>> chunker = create_chunker(config)
        >>>
        >>> # Override strategy
        >>> chunker = create_chunker(strategy="simple")
        >>>
        >>> # Chunk a document
        >>> chunks = await chunker.chunk_document(
        ...     content=markdown_text,
        ...     title="Document",
        ...     source="doc.pdf"
        ... )
    """
    # Create default config if not provided
    if config is None:
        config = ChunkingConfig()

    # Override strategy if provided
    if strategy is not None:
        try:
            config.strategy = ChunkingStrategy(strategy.lower())
        except ValueError:
            available = ", ".join([s.value for s in ChunkingStrategy])
            raise ValueError(
                f"Unknown chunking strategy: {strategy}. Available strategies: {available}"
            )

    # Create chunker based on strategy
    if config.strategy == ChunkingStrategy.DOCLING:
        from .docling_chunker import DoclingChunker

        return DoclingChunker(config)

    elif config.strategy == ChunkingStrategy.SIMPLE:
        from .simple_chunker import SimpleChunker

        return SimpleChunker(config)

    elif config.strategy == ChunkingStrategy.FIXED:
        # TODO: Implement FixedSizeChunker if needed
        logger.warning("Fixed-size chunker not yet implemented, using simple chunker")
        from .simple_chunker import SimpleChunker

        return SimpleChunker(config)

    elif config.strategy == ChunkingStrategy.AZURE:
        from .azure_chunker import AzureChunker

        return AzureChunker(config)

    else:
        raise ValueError(f"Unknown chunking strategy: {config.strategy}")
