"""Document chunking utilities with pluggable chunker implementations.

This module provides abstract base classes and concrete implementations for
chunking documents into smaller pieces suitable for embedding and retrieval.

Supported Chunkers:
- DoclingChunker: Uses Docling's HybridChunker for token-aware semantic chunking
- SimpleChunker: Basic paragraph-based chunking without Docling dependency
- FixedSizeChunker: Simple fixed-size chunking with overlap
- AzureChunker: Azure-compatible chunker with tiktoken and multiple strategies

Usage:
    from common.chunkers import create_chunker, ChunkingConfig

    # Create a chunker
    config = ChunkingConfig(max_tokens=512, use_semantic_splitting=True)
    chunker = create_chunker(config)

    # Chunk a document
    chunks = await chunker.chunk_document(
        content=markdown_text,
        title="Document Title",
        source="document.pdf"
    )

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from .base import (
    ChunkingConfig,
    ChunkingStrategy,
    DocumentChunk,
)
from .factory import create_chunker

__all__ = [
    "ChunkingConfig",
    "DocumentChunk",
    "ChunkingStrategy",
    "create_chunker",
]
