"""Docling DoclingChunker implementation for intelligent document splitting.

This chunker uses Docling's built-in HybridChunker which combines:
- Token-aware chunking (uses actual tokenizer)
- Document structure preservation (headings, sections, tables)
- Semantic boundary respect (paragraphs, code blocks)
- Contextualized output (chunks include heading hierarchy)

Requires optional dependencies: pip install ashmatics-tools[chunkers,parsers]

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
from typing import TYPE_CHECKING, Any

from .base import ChunkingConfig, DocumentChunk, DocumentChunker

logger = logging.getLogger(__name__)

# Track availability of optional dependencies
_DOCLING_AVAILABLE = False
_TRANSFORMERS_AVAILABLE = False

try:
    from docling.chunking import HybridChunker as DoclingHybridChunker

    _DOCLING_AVAILABLE = True
except ImportError:
    DoclingHybridChunker = None  # type: ignore[misc, assignment]
    logger.debug("docling not available - DoclingChunker will not work")

try:
    from transformers import AutoTokenizer

    _TRANSFORMERS_AVAILABLE = True
except ImportError:
    AutoTokenizer = None  # type: ignore[misc, assignment]
    logger.debug("transformers not available - DoclingChunker will not work")

# Use TYPE_CHECKING for type hints only
if TYPE_CHECKING:
    from docling_core.types.doc import DoclingDocument


def _check_dependencies() -> None:
    """Check that required dependencies are available."""
    missing = []
    if not _DOCLING_AVAILABLE:
        missing.append("docling")
    if not _TRANSFORMERS_AVAILABLE:
        missing.append("transformers")

    if missing:
        raise ImportError(
            f"DoclingChunker requires optional dependencies: {', '.join(missing)}. "
            f"Install with: pip install ashmatics-tools[chunkers,parsers]"
        )


class DoclingChunker(DocumentChunker):
    """
    Docling DoclingChunker wrapper for intelligent document splitting.

    This chunker uses Docling's built-in HybridChunker which:
    - Respects document structure (sections, paragraphs, tables)
    - Is token-aware (fits embedding model limits)
    - Preserves semantic coherence
    - Includes heading context in chunks
    """

    def __init__(self, config: ChunkingConfig):
        """
        Initialize docling chunker.

        Args:
            config: Chunking configuration

        Raises:
            ImportError: If required dependencies (docling, transformers) are not installed
        """
        # Check dependencies before initialization
        _check_dependencies()

        super().__init__(config)

        # Initialize tokenizer for token-aware chunking
        logger.info(f"Initializing tokenizer: {config.tokenizer_model}")
        self.tokenizer = AutoTokenizer.from_pretrained(config.tokenizer_model)  # type: ignore[misc]

        # Create HybridChunker
        self.chunker = DoclingHybridChunker(
            tokenizer=self.tokenizer,
            max_tokens=config.max_tokens,
            merge_peers=config.merge_small_chunks,
        )

        logger.info(f"DoclingChunker initialized (max_tokens={config.max_tokens})")

    async def chunk_document(
        self,
        content: str,
        title: str,
        source: str,
        metadata: dict[str, Any] | None = None,
        docling_doc: "DoclingDocument | None" = None,
        **kwargs,
    ) -> list[DocumentChunk]:
        """
        Chunk a document using Docling's HybridChunker.

        Args:
            content: Document content (markdown format)
            title: Document title
            source: Document source
            metadata: Additional metadata
            docling_doc: Optional pre-converted DoclingDocument (for efficiency)
            **kwargs: Additional arguments

        Returns:
            List of document chunks with contextualized content
        """
        if not content.strip():
            return []

        base_metadata = {
            "title": title,
            "source": source,
            "chunk_method": "hybrid",
            **(metadata or {}),
        }

        # If we don't have a DoclingDocument, we need to create one from markdown
        if docling_doc is None:
            logger.warning("No DoclingDocument provided, using simple chunking fallback")
            return await self._simple_fallback_chunk(content, base_metadata)

        try:
            # Use HybridChunker to chunk the DoclingDocument
            chunk_iter = self.chunker.chunk(dl_doc=docling_doc)
            chunks = list(chunk_iter)

            # Convert Docling chunks to DocumentChunk objects
            document_chunks = []
            current_pos = 0

            for i, chunk in enumerate(chunks):
                # Get contextualized text (includes heading hierarchy)
                contextualized_text = self.chunker.contextualize(chunk=chunk)

                # Count actual tokens
                token_count = len(self.tokenizer.encode(contextualized_text))

                # Create chunk metadata
                chunk_metadata = {
                    **base_metadata,
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    "token_count": token_count,
                    "has_context": True,  # Flag indicating contextualized chunk
                }

                # Estimate character positions
                start_char = current_pos
                end_char = start_char + len(contextualized_text)

                document_chunks.append(
                    DocumentChunk(
                        content=contextualized_text.strip(),
                        index=i,
                        start_char=start_char,
                        end_char=end_char,
                        metadata=chunk_metadata,
                        token_count=token_count,
                    )
                )

                current_pos = end_char

            logger.info(f"Created {len(document_chunks)} chunks using Docling's HybridChunker")
            return document_chunks

        except Exception as e:
            logger.error(f"Docling's HybridChunker failed: {e}, falling back to simple chunking")
            return await self._simple_fallback_chunk(content, base_metadata)

    async def _simple_fallback_chunk(
        self, content: str, base_metadata: dict[str, Any]
    ) -> list[DocumentChunk]:
        """
        Simple fallback chunking when Docling's HybridChunker can't be used.

        Args:
            content: Content to chunk
            base_metadata: Base metadata for chunks

        Returns:
            List of document chunks
        """
        chunks = []
        chunk_size = self.config.chunk_size
        overlap = self.config.chunk_overlap

        # Simple sliding window approach
        start = 0
        chunk_index = 0

        while start < len(content):
            end = start + chunk_size

            if end >= len(content):
                # Last chunk
                chunk_text = content[start:]
            else:
                # Try to end at sentence boundary
                chunk_end = end
                for i in range(end, max(start + self.config.min_chunk_size, end - 200), -1):
                    if i < len(content) and content[i] in ".!?\n":
                        chunk_end = i + 1
                        break
                chunk_text = content[start:chunk_end]
                end = chunk_end

            if chunk_text.strip():
                token_count = len(self.tokenizer.encode(chunk_text))

                chunks.append(
                    DocumentChunk(
                        content=chunk_text.strip(),
                        index=chunk_index,
                        start_char=start,
                        end_char=end,
                        metadata={
                            **base_metadata,
                            "chunk_method": "simple_fallback",
                            "chunk_index": chunk_index,
                            "total_chunks": -1,  # Will update after
                        },
                        token_count=token_count,
                    )
                )

                chunk_index += 1

            # Move forward with overlap
            start = end - overlap

        # Update total chunks
        for chunk in chunks:
            chunk.metadata["total_chunks"] = len(chunks)

        logger.info(f"Created {len(chunks)} chunks using simple fallback")
        return chunks
