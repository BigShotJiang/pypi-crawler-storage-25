"""Abstract base classes for document chunkers.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ChunkingStrategy(str, Enum):
    """Chunking strategies."""

    DOCLING = "docling"  # Docling HybridChunker (token-aware, structure-preserving)
    SIMPLE = "simple"  # Paragraph-based chunking
    FIXED = "fixed"  # Fixed-size chunks with overlap
    AZURE = "azure"  # Azure-compatible chunker with tiktoken and multiple strategies


@dataclass
class ChunkingConfig:
    """
    Configuration for document chunking.

    This configuration is used across all chunker types to maintain consistency.
    Chunker-specific settings can be passed via `extra_config`.
    """

    # Strategy
    strategy: ChunkingStrategy = ChunkingStrategy.DOCLING

    # Size settings
    chunk_size: int = 1000  # Target characters per chunk (for simple/fixed)
    chunk_overlap: int = 200  # Character overlap between chunks
    max_chunk_size: int = 2000  # Maximum chunk size
    min_chunk_size: int = 100  # Minimum chunk size

    # Token settings (for docling chunker)
    max_tokens: int = 512  # Maximum tokens for embedding models
    tokenizer_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    # Behavior
    use_semantic_splitting: bool = True  # Use Docling's HybridChunker (recommended)
    preserve_structure: bool = True  # Preserve document structure
    merge_small_chunks: bool = True  # Merge chunks smaller than min_chunk_size

    # Chunker-specific settings
    extra_config: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration."""
        if self.chunk_overlap >= self.chunk_size:
            raise ValueError("Chunk overlap must be less than chunk size")
        if self.min_chunk_size <= 0:
            raise ValueError("Minimum chunk size must be positive")
        if self.max_tokens <= 0:
            raise ValueError("max_tokens must be positive")


@dataclass
class DocumentChunk:
    """Represents a document chunk with optional embedding."""

    content: str
    index: int
    start_char: int
    end_char: int
    metadata: dict[str, Any]
    token_count: int | None = None
    embedding: list[float] | None = None  # For embedder compatibility

    def __post_init__(self):
        """Calculate token count if not provided."""
        if self.token_count is None:
            # Rough estimation: ~4 characters per token
            self.token_count = len(self.content) // 4

    def to_dict(self) -> dict[str, Any]:
        """Convert chunk to dictionary."""
        return {
            "content": self.content,
            "index": self.index,
            "start_char": self.start_char,
            "end_char": self.end_char,
            "metadata": self.metadata,
            "token_count": self.token_count,
            "has_embedding": self.embedding is not None,
        }


class DocumentChunker(ABC):
    """
    Abstract base class for document chunkers.

    All chunker implementations must inherit from this class and implement
    its abstract methods.
    """

    def __init__(self, config: ChunkingConfig):
        """
        Initialize chunker with configuration.

        Args:
            config: Chunking configuration
        """
        self.config = config

    @abstractmethod
    async def chunk_document(
        self,
        content: str,
        title: str,
        source: str,
        metadata: dict[str, Any] | None = None,
        **kwargs,
    ) -> list[DocumentChunk]:
        """
        Chunk a document.

        Args:
            content: Document content (markdown or text)
            title: Document title
            source: Document source identifier
            metadata: Additional metadata to attach to chunks
            **kwargs: Additional chunker-specific arguments

        Returns:
            List of document chunks
        """

    def get_strategy(self) -> ChunkingStrategy:
        """
        Get the chunking strategy.

        Returns:
            ChunkingStrategy enum value
        """
        return self.config.strategy

    def __repr__(self) -> str:
        """String representation of chunker."""
        return f"{self.__class__.__name__}(strategy={self.config.strategy})"
