# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""Table storage manager for document processing pipelines.

Handles:
- Saving tables in Markdown format (with YAML frontmatter)
- Saving tables in JSON format (structured data)
- Table metadata tracking (classification, merge info)
"""

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class StoredTable:
    """Table ready for storage with dual-format output.

    Attributes:
        table_id: Unique identifier (e.g., 'table_1')
        caption: Table caption/title
        markdown: Table in markdown format
        data: Structured table data (headers + rows), if parseable
        classification: Table category (performance_metrics, study_design, etc.)
        merged_from: List of table IDs if this is a consolidated table
        merge_method: Consolidation method used (heuristic_first_row, etc.)
        merge_confidence: Confidence score for merge
        original_indices: Original indices in parsed_doc.tables
        md_path: Path to saved .md file (after storage)
        json_path: Path to saved .json file (after storage)
    """

    table_id: str
    caption: Optional[str]
    markdown: str
    data: Optional[Dict[str, Any]] = None  # {"headers": [...], "rows": [[...], ...]}
    classification: Optional[str] = None
    merged_from: List[str] = field(default_factory=list)
    merge_method: Optional[str] = None
    merge_confidence: Optional[float] = None
    original_indices: List[int] = field(default_factory=list)
    md_path: Optional[Path] = None
    json_path: Optional[Path] = None


class TableStorageManager:
    """Manages table storage in both Markdown and JSON formats.

    Creates two files per table:
    - {table_id}.md: Markdown with YAML frontmatter (human-readable)
    - {table_id}.json: Structured JSON (machine-readable)

    Plus a manifest file:
    - tables_manifest.json: Summary of all tables

    Usage:
        >>> manager = TableStorageManager()
        >>> tables = manager.process_tables(consolidated_tables, table_classifications)
        >>> saved = manager.save_tables(tables, output_dir / 'tables', doc_id)
    """

    def process_tables(
        self,
        consolidated_tables: List[Any],
        table_classifications: Optional[Dict[str, str]] = None,
    ) -> List[StoredTable]:
        """Process consolidated tables for storage.

        Args:
            consolidated_tables: ConsolidatedTable objects from TableConsolidator
            table_classifications: Dict mapping table_id to classification string

        Returns:
            List of StoredTable objects ready for saving
        """
        if not consolidated_tables:
            logger.debug("No tables to process")
            return []

        classifications = table_classifications or {}
        stored_tables = []

        for table in consolidated_tables:
            # Helper to get attribute from either object or dict
            def get_attr(name: str, default=None):
                if hasattr(table, name):
                    val = getattr(table, name)
                    return val if val is not None else default
                elif isinstance(table, dict):
                    return table.get(name, default)
                return default

            # Get table_id
            table_id = get_attr("table_id", f"table_{len(stored_tables) + 1}")

            # Get markdown
            markdown = get_attr("markdown", "")

            # Parse markdown to structured data
            structured_data = self._parse_markdown_to_data(markdown)

            # Get merge info
            merged_from = get_attr("merged_from", [])
            merge_method = get_attr("merge_method")
            merge_confidence = get_attr("merge_confidence")
            original_indices = get_attr("original_indices", [])

            # Get caption
            caption = get_attr("caption")

            stored_table = StoredTable(
                table_id=table_id,
                caption=caption,
                markdown=markdown,
                data=structured_data,
                classification=classifications.get(table_id),
                merged_from=merged_from if merged_from else [],
                merge_method=merge_method,
                merge_confidence=merge_confidence,
                original_indices=original_indices if original_indices else [],
            )

            stored_tables.append(stored_table)

        logger.info(f"Processed {len(stored_tables)} tables for storage")
        return stored_tables

    def save_tables(
        self,
        tables: List[StoredTable],
        output_dir: Path,
        document_id: str,
    ) -> List[StoredTable]:
        """Save tables in both Markdown and JSON formats.

        Args:
            tables: StoredTable objects to save
            output_dir: Directory for table files (e.g., batch/DOC123/tables/)
            document_id: Document identifier for manifest

        Returns:
            Updated tables with md_path and json_path set
        """
        if not tables:
            logger.debug("No tables to save")
            return tables

        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        for table in tables:
            # Save Markdown
            md_filename = f"{table.table_id}.md"
            md_path = output_dir / md_filename

            md_content = self._build_markdown_file(table)
            with open(md_path, "w", encoding="utf-8") as f:
                f.write(md_content)
            table.md_path = md_path

            # Save JSON
            json_filename = f"{table.table_id}.json"
            json_path = output_dir / json_filename

            json_content = self._build_json_file(table)
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(json_content, f, indent=2)
            table.json_path = json_path

            logger.debug(f"Saved {table.table_id} to {md_path} and {json_path}")

        # Save tables manifest
        self._save_tables_manifest(tables, output_dir, document_id)

        logger.info(f"Saved {len(tables)} tables to {output_dir}")
        return tables

    def _parse_markdown_to_data(self, markdown: str) -> Optional[Dict[str, Any]]:
        """Parse markdown table to structured data.

        Args:
            markdown: Table in markdown format

        Returns:
            Dict with 'headers' and 'rows' keys, or None if parsing fails
        """
        if not markdown:
            return None

        rows = []
        lines = [line.strip() for line in markdown.split("\n") if line.strip()]

        for line in lines:
            if not line.startswith("|"):
                continue

            # Skip separator rows (|---|---|)
            if "---" in line:
                continue

            # Parse cells
            cells = [cell.strip() for cell in line.split("|")[1:-1]]
            if cells:
                rows.append(cells)

        if not rows:
            return None

        # First row is headers, rest are data
        headers = rows[0] if rows else []
        data_rows = rows[1:] if len(rows) > 1 else []

        return {
            "headers": headers,
            "rows": data_rows,
            "row_count": len(data_rows),
            "column_count": len(headers),
        }

    def _build_markdown_file(self, table: StoredTable) -> str:
        """Build complete markdown file with YAML frontmatter.

        Args:
            table: StoredTable to serialize

        Returns:
            Markdown string with frontmatter
        """
        lines = []

        # YAML frontmatter
        lines.append("---")
        lines.append(f"table_id: {table.table_id}")
        if table.caption:
            # Escape quotes in caption for YAML
            escaped_caption = table.caption.replace('"', '\\"')
            lines.append(f'caption: "{escaped_caption}"')
        if table.classification:
            lines.append(f"classification: {table.classification}")
        if table.merged_from:
            lines.append(f"merged_from: {json.dumps(table.merged_from)}")
        if table.merge_method:
            lines.append(f"merge_method: {table.merge_method}")
        if table.merge_confidence is not None:
            lines.append(f"merge_confidence: {table.merge_confidence}")
        if table.original_indices:
            lines.append(f"original_indices: {json.dumps(table.original_indices)}")
        lines.append("---")
        lines.append("")

        # Caption as header
        if table.caption:
            lines.append(f"# {table.caption}")
            lines.append("")

        # Table content
        lines.append(table.markdown)

        return "\n".join(lines)

    def _build_json_file(self, table: StoredTable) -> Dict[str, Any]:
        """Build JSON representation with metadata and structured data.

        Args:
            table: StoredTable to serialize

        Returns:
            Dict ready for JSON serialization
        """
        result: Dict[str, Any] = {
            "table_id": table.table_id,
            "caption": table.caption,
            "classification": table.classification,
            "markdown": table.markdown,
        }

        # Add consolidation info if table was merged
        if table.merged_from:
            result["consolidation"] = {
                "merged_from": table.merged_from,
                "merge_method": table.merge_method,
                "merge_confidence": table.merge_confidence,
                "original_indices": table.original_indices,
            }
        else:
            result["consolidation"] = None

        # Add structured data if available
        if table.data:
            result["data"] = table.data
        else:
            result["data"] = None

        return result

    def _save_tables_manifest(
        self,
        tables: List[StoredTable],
        output_dir: Path,
        document_id: str,
    ) -> None:
        """Save tables manifest JSON with metadata.

        Args:
            tables: List of stored tables
            output_dir: Directory where tables are saved
            document_id: Document identifier
        """
        manifest: Dict[str, Any] = {
            "document_id": document_id,
            "total_tables": len(tables),
            "consolidated_count": sum(1 for t in tables if t.merged_from),
            "tables": [],
        }

        for table in tables:
            table_entry: Dict[str, Any] = {
                "table_id": table.table_id,
                "caption": table.caption,
                "classification": table.classification,
                "md_file": table.md_path.name if table.md_path else None,
                "json_file": table.json_path.name if table.json_path else None,
                "is_consolidated": bool(table.merged_from),
            }

            if table.merged_from:
                table_entry["merged_from"] = table.merged_from
                table_entry["merge_method"] = table.merge_method
                table_entry["merge_confidence"] = table.merge_confidence

            if table.data:
                table_entry["row_count"] = table.data.get("row_count", 0)
                table_entry["column_count"] = table.data.get("column_count", 0)

            manifest["tables"].append(table_entry)

        manifest_path = output_dir / "tables_manifest.json"
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        logger.debug(f"Saved tables manifest to {manifest_path}")
