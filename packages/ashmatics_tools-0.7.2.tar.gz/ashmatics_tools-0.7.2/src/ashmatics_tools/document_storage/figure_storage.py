# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""Figure storage manager for document processing pipelines.

Handles:
- Figure filtering (exclude logos/headers by size)
- PNG file saving with content-addressed hashing
- Caption extraction from markdown
- URL generation for storage schemas
"""

import hashlib
import io
import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from PIL import Image
except ImportError:
    Image = None  # type: ignore

logger = logging.getLogger(__name__)


@dataclass
class ProcessedFigure:
    """Processed figure ready for storage.

    Attributes:
        figure_id: Unique identifier (e.g., 'figure_1')
        image_data: PIL Image object (may be None if only bytes available)
        image_bytes: PNG bytes for storage
        caption: Extracted or provided caption
        dimensions: (width, height) in pixels
        is_significant: True if not a logo/header (passed size filter)
        file_hash: Content hash for deduplication (8 char MD5)
        local_path: Path where figure was saved (after storage)
        blob_url: Cloud blob URL (after cloud storage)
        metadata: Additional metadata (format, original_index, source_page)
    """

    figure_id: str
    image_data: Optional[Any]  # PIL.Image.Image, but optional import
    image_bytes: bytes
    caption: Optional[str]
    dimensions: Tuple[int, int]
    is_significant: bool
    file_hash: str
    local_path: Optional[Path] = None
    blob_url: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class FigureStorageManager:
    """Manages figure filtering, storage, and URL generation.

    Supports:
    - Local filesystem storage (batch mode)
    - Cloud storage (Azure Blob, S3 - via storage client)

    Usage:
        >>> manager = FigureStorageManager(min_size=200, storage_mode='local')
        >>> processed = manager.process_figures(parsed_doc.figures, document_markdown)
        >>> saved = manager.save_figures(processed, output_dir / 'figures', doc_id)
    """

    # Regex patterns for extracting figure captions from markdown
    CAPTION_PATTERNS = [
        # "Figure X: Caption text" or "Figure X. Caption text"
        re.compile(r"(?:Figure|Fig\.?)\s*(\d+)[:\.\s]+(.+?)(?:\n|$)", re.IGNORECASE),
        # "## Figure X: Caption" (markdown header)
        re.compile(r"^#+\s*(?:Figure|Fig\.?)\s*(\d+)[:\.\s]*(.+?)$", re.MULTILINE | re.IGNORECASE),
    ]

    def __init__(
        self,
        min_size: int = 200,
        storage_mode: str = "local",
        storage_client: Optional[Any] = None,
        additional_caption_patterns: Optional[List[re.Pattern]] = None,
    ):
        """Initialize figure storage manager.

        Args:
            min_size: Minimum width/height (pixels) to consider significant.
                      Images smaller than this are filtered out (logos, headers).
            storage_mode: 'local' or 'cloud'
            storage_client: Optional storage client for cloud uploads
            additional_caption_patterns: Extra regex patterns for caption extraction
        """
        self.min_size = min_size
        self.storage_mode = storage_mode
        self.storage_client = storage_client

        self.caption_patterns = list(self.CAPTION_PATTERNS)
        if additional_caption_patterns:
            self.caption_patterns.extend(additional_caption_patterns)

        if Image is None:
            logger.warning("PIL/Pillow not installed. Figure processing will be limited.")

    def process_figures(
        self,
        raw_figures: List[Any],
        document_markdown: Optional[str] = None,
    ) -> List[ProcessedFigure]:
        """Process raw figures from parser, filtering and extracting metadata.

        Args:
            raw_figures: Figures from ParsedDocument.figures (Docling output)
            document_markdown: Full document markdown for caption extraction

        Returns:
            List of ProcessedFigure objects (only significant figures that pass size filter)
        """
        if not raw_figures:
            logger.debug("No figures to process")
            return []

        processed = []
        figure_num = 1

        # Extract captions from markdown if available
        caption_map: Dict[int, str] = {}
        if document_markdown:
            caption_map = self._extract_captions_from_markdown(document_markdown)

        for idx, figure in enumerate(raw_figures):
            # Get image data from figure object
            image_data = getattr(figure, "image_data", None)
            if image_data is None:
                # Try alternative attribute names
                image_data = getattr(figure, "image", None)
                if image_data is None:
                    logger.debug(f"Figure {idx} has no image data, skipping")
                    continue

            # Get dimensions
            try:
                if hasattr(image_data, "size"):
                    width, height = image_data.size
                elif hasattr(image_data, "width") and hasattr(image_data, "height"):
                    width, height = image_data.width, image_data.height
                else:
                    logger.debug(f"Cannot determine dimensions for figure {idx}, skipping")
                    continue
            except Exception as e:
                logger.debug(f"Error getting dimensions for figure {idx}: {e}")
                continue

            # Filter small images (logos, headers, decorations)
            if width < self.min_size or height < self.min_size:
                logger.debug(f"Skipping small image {idx}: {width}x{height} (min: {self.min_size})")
                continue

            # Convert to PNG bytes
            try:
                image_bytes = self._image_to_png_bytes(image_data)
            except Exception as e:
                logger.warning(f"Error converting figure {idx} to PNG: {e}")
                continue

            # Generate content hash for deduplication and filename
            file_hash = hashlib.md5(image_bytes).hexdigest()[:8]

            # Get caption from figure object or extracted from markdown
            caption = getattr(figure, "caption", None)
            if not caption and figure_num in caption_map:
                caption = caption_map[figure_num]

            # Get image mode/format info
            image_mode = getattr(image_data, "mode", "unknown")

            processed_figure = ProcessedFigure(
                figure_id=f"figure_{figure_num}",
                image_data=image_data,
                image_bytes=image_bytes,
                caption=caption,
                dimensions=(width, height),
                is_significant=True,
                file_hash=file_hash,
                metadata={
                    "format": "PNG",
                    "mode": image_mode,
                    "original_index": idx,
                },
            )

            processed.append(processed_figure)
            figure_num += 1

        logger.info(f"Processed {len(processed)} significant figures from {len(raw_figures)} total")
        return processed

    def save_figures(
        self,
        figures: List[ProcessedFigure],
        output_dir: Path,
        document_id: str,
    ) -> List[ProcessedFigure]:
        """Save figures to local filesystem.

        Args:
            figures: Processed figures to save
            output_dir: Directory for figure files (e.g., batch/DOC123/figures/)
            document_id: Document identifier for manifest

        Returns:
            Updated figures with local_path set
        """
        if not figures:
            logger.debug("No figures to save")
            return figures

        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        for figure in figures:
            # Generate filename with hash for uniqueness
            filename = f"{figure.figure_id}_{figure.file_hash}.png"
            file_path = output_dir / filename

            # Save PNG
            with open(file_path, "wb") as f:
                f.write(figure.image_bytes)

            figure.local_path = file_path
            logger.debug(f"Saved {figure.figure_id} to {file_path}")

        # Save figures manifest
        self._save_figures_manifest(figures, output_dir, document_id)

        logger.info(f"Saved {len(figures)} figures to {output_dir}")
        return figures

    def get_figure_urls(
        self,
        figures: List[ProcessedFigure],
        base_url: Optional[str] = None,
    ) -> Dict[str, str]:
        """Get URLs for figures (local paths or blob URLs).

        Args:
            figures: Processed figures with local_path or blob_url set
            base_url: Optional base URL for constructing full URLs

        Returns:
            Dict mapping figure_id to URL/path string
        """
        urls: Dict[str, str] = {}

        for fig in figures:
            if fig.blob_url:
                urls[fig.figure_id] = fig.blob_url
            elif fig.local_path:
                if base_url:
                    urls[fig.figure_id] = f"{base_url}/{fig.local_path.name}"
                else:
                    urls[fig.figure_id] = str(fig.local_path)

        return urls

    def _image_to_png_bytes(self, image_data: Any) -> bytes:
        """Convert PIL Image or image-like object to PNG bytes.

        Args:
            image_data: PIL Image or compatible object

        Returns:
            PNG bytes
        """
        buffer = io.BytesIO()

        if hasattr(image_data, "save"):
            # PIL Image
            image_data.save(buffer, format="PNG")
        elif hasattr(image_data, "tobytes") and hasattr(image_data, "size"):
            # Raw image data - need to construct PNG
            if Image is not None:
                # Use PIL to create proper PNG
                img = Image.frombytes(
                    getattr(image_data, "mode", "RGB"),
                    image_data.size,
                    image_data.tobytes(),
                )
                img.save(buffer, format="PNG")
            else:
                raise ValueError("PIL required to convert raw image data")
        else:
            raise ValueError(f"Unknown image type: {type(image_data)}")

        return buffer.getvalue()

    def _extract_captions_from_markdown(self, markdown: str) -> Dict[int, str]:
        """Extract figure captions from document markdown.

        Patterns matched:
        - "Figure X: Caption text"
        - "Fig. X: Caption text"
        - "## Figure X Caption"

        Args:
            markdown: Full document markdown content

        Returns:
            Dict mapping figure number (int) to caption text
        """
        captions: Dict[int, str] = {}

        for pattern in self.caption_patterns:
            for match in pattern.finditer(markdown):
                try:
                    fig_num = int(match.group(1))
                    caption = match.group(2).strip()
                    # Don't overwrite if we already found a caption
                    if fig_num not in captions and caption:
                        captions[fig_num] = caption
                except (ValueError, IndexError):
                    continue

        if captions:
            logger.debug(f"Extracted {len(captions)} figure captions from markdown")

        return captions

    def _save_figures_manifest(
        self,
        figures: List[ProcessedFigure],
        output_dir: Path,
        document_id: str,
    ) -> None:
        """Save figures manifest JSON with metadata.

        Args:
            figures: List of processed figures
            output_dir: Directory where figures are saved
            document_id: Document identifier
        """
        manifest = {
            "document_id": document_id,
            "total_figures": len(figures),
            "figures": [],
        }

        for fig in figures:
            manifest["figures"].append(
                {
                    "figure_id": fig.figure_id,
                    "filename": fig.local_path.name if fig.local_path else None,
                    "caption": fig.caption,
                    "dimensions": {
                        "width": fig.dimensions[0],
                        "height": fig.dimensions[1],
                    },
                    "file_hash": fig.file_hash,
                    "is_significant": fig.is_significant,
                    "metadata": fig.metadata,
                }
            )

        manifest_path = output_dir / "figures_manifest.json"
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        logger.debug(f"Saved figures manifest to {manifest_path}")
