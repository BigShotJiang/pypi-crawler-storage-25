# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""Document artifact storage managers.

This module provides storage managers for document artifacts extracted during
parsing and enrichment pipelines:

- **FigureStorageManager**: Handle figure filtering, PNG conversion, and storage
- **TableStorageManager**: Store tables in Markdown and JSON formats
- **BatchOutputManager**: Coordinate batch processing output organization

These managers work with any document type and support both local filesystem
and cloud storage backends.

Example - Figure Storage:
    >>> from ashmatics_tools.document_storage import FigureStorageManager
    >>> manager = FigureStorageManager(min_size=200)
    >>> processed = manager.process_figures(parsed_doc.figures, document_markdown)
    >>> saved = manager.save_figures(processed, output_dir / 'figures', doc_id)

Example - Table Storage:
    >>> from ashmatics_tools.document_storage import TableStorageManager
    >>> manager = TableStorageManager()
    >>> tables = manager.process_tables(consolidated_tables, classifications)
    >>> saved = manager.save_tables(tables, output_dir / 'tables', doc_id)

Example - Batch Output:
    >>> from ashmatics_tools.document_storage import BatchOutputManager
    >>> batch = BatchOutputManager(base_output_dir)
    >>> doc_dir = batch.get_document_output_dir(doc_id)
    >>> batch.write_manifest(results)
"""

from .figure_storage import FigureStorageManager, ProcessedFigure
from .table_storage import StoredTable, TableStorageManager

__all__ = [
    # Figure Storage
    "FigureStorageManager",
    "ProcessedFigure",
    # Table Storage
    "TableStorageManager",
    "StoredTable",
]
