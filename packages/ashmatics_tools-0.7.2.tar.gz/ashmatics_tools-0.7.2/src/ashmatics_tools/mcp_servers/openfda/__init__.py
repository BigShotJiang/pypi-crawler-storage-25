# Copyright 2025 Asher Informatics PBC
"""OpenFDA MCP server for ashmatics-tools.

This module provides an MCP server that exposes OpenFDA API capabilities
to LLMs via the Model Context Protocol.

Example usage:
    ```python
    from ashmatics_tools.mcp_servers.openfda import OpenFDAMCPServer, OpenFDAMCPConfig

    # Create server
    config = OpenFDAMCPConfig(api_key="your_key")
    server = OpenFDAMCPServer(config)

    # Get available tools
    tools = server.get_tools()

    # Call a tool
    result = await server.call_tool(
        "search_devices",
        {"query": "pacemaker", "limit": 10}
    )
    ```
"""

from .config import OpenFDAMCPConfig
from .server import OpenFDAMCPServer

__all__ = [
    "OpenFDAMCPServer",
    "OpenFDAMCPConfig",
]
