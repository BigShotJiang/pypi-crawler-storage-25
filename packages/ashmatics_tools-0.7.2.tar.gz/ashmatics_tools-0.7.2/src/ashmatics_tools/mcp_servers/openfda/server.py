# Copyright 2025 Asher Informatics PBC
"""OpenFDA MCP server implementation."""

import json
import logging
from typing import Any

from ...external_apis.openfda import OpenFDAClient, OpenFDAEndpoint
from ..base import BaseMCPServer
from .config import OpenFDAMCPConfig

logger = logging.getLogger(__name__)


class OpenFDAMCPServer(BaseMCPServer):
    """
    MCP server for OpenFDA API.

    Exposes OpenFDA capabilities as MCP tools including:
    - search_devices: Search device databases (510k, events, recalls, etc.)
    - search_drugs: Search drug databases (labels, adverse events, etc.)
    - count_by_field: Aggregate counts for analytics

    Example:
        ```python
        config = OpenFDAMCPConfig(
            api_config=OpenFDAConfig(api_key="your_key")
        )
        server = OpenFDAMCPServer(config)

        # Search for device events
        result = await server.call_tool(
            "search_devices",
            {
                "endpoint": "device_event",
                "query": "device_name:pacemaker",
                "limit": 10
            }
        )

        # Count devices by class
        counts = await server.call_tool(
            "count_by_field",
            {
                "endpoint": "device_event",
                "query": "*",
                "count_field": "device.device_class.exact"
            }
        )
        ```
    """

    def __init__(self, config: OpenFDAMCPConfig):
        """Initialize OpenFDA MCP server.

        Args:
            config: Server configuration
        """
        super().__init__(config)
        self.config: OpenFDAMCPConfig = config  # Type hint for IDE
        assert self.config.api_config is not None
        self.client = OpenFDAClient(self.config.api_config)

    def get_tools(self) -> list[dict[str, Any]]:
        """
        Get list of available tools.

        Returns:
            List of tool definitions with JSON schemas
        """
        return [
            {
                "name": "search_devices",
                "description": (
                    "Search FDA device databases including 510(k) clearances, "
                    "adverse events, recalls, and registrations. "
                    "Supports complex queries with date ranges, boolean operators, and wildcards. "
                    "Can return typed responses using ashmatics-datamodels for 510(k) and PMA endpoints."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "endpoint": {
                            "type": "string",
                            "enum": [
                                "device_510k",
                                "device_class",
                                "device_event",
                                "device_pma",
                                "device_recall",
                                "device_registration",
                                "device_udi",
                            ],
                            "description": "Device endpoint to search",
                            "default": "device_510k",
                        },
                        "query": {
                            "type": "string",
                            "description": (
                                "OpenFDA search query. Examples: "
                                "'device_name:pacemaker', "
                                "'date_received:[20200101 TO 20231231]', "
                                "'product_code:OZP AND device_class:3'"
                            ),
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Results per page (max 1000)",
                            "default": 100,
                            "minimum": 1,
                            "maximum": 1000,
                        },
                        "max_records": {
                            "type": "integer",
                            "description": "Maximum total records to return",
                            "default": 1000,
                            "minimum": 1,
                        },
                        "typed": {
                            "type": "boolean",
                            "description": (
                                "Return typed responses using ashmatics-datamodels schemas. "
                                "Supported for device_510k and device_pma endpoints."
                            ),
                            "default": False,
                        },
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "search_drugs",
                "description": (
                    "Search FDA drug databases including labels, adverse events (FAERS), "
                    "enforcement actions, and NDC directory."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "endpoint": {
                            "type": "string",
                            "enum": [
                                "drug_event",
                                "drug_label",
                                "drug_ndc",
                                "drug_enforcement",
                                "drug_recall",
                            ],
                            "description": "Drug endpoint to search",
                            "default": "drug_event",
                        },
                        "query": {
                            "type": "string",
                            "description": (
                                "OpenFDA search query. Examples: "
                                "'patient.drug.medicinalproduct:aspirin', "
                                "'receivedate:[20200101 TO 20231231]'"
                            ),
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Results per page (max 1000)",
                            "default": 100,
                            "minimum": 1,
                            "maximum": 1000,
                        },
                        "max_records": {
                            "type": "integer",
                            "description": "Maximum total records to return",
                            "default": 1000,
                            "minimum": 1,
                        },
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "count_by_field",
                "description": (
                    "Perform aggregated counts on FDA data by a specific field. "
                    "Useful for analytics and understanding data distribution."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "endpoint": {
                            "type": "string",
                            "description": "OpenFDA endpoint (e.g., 'device_event', 'drug_event')",
                        },
                        "query": {
                            "type": "string",
                            "description": "Search query (use '*' for all records)",
                        },
                        "count_field": {
                            "type": "string",
                            "description": (
                                "Field to count by. Examples: "
                                "'device.device_class.exact', "
                                "'patient.patientsex', "
                                "'receivedate'"
                            ),
                        },
                    },
                    "required": ["endpoint", "query", "count_field"],
                },
            },
        ]

    async def call_tool(
        self, tool_name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Execute a tool and return results.

        Args:
            tool_name: Name of the tool to execute
            arguments: Tool arguments

        Returns:
            Tool execution results

        Raises:
            ValueError: If tool not found or invalid arguments
            RuntimeError: On tool execution errors
        """
        try:
            if tool_name == "search_devices":
                return await self._search_devices(arguments)
            elif tool_name == "search_drugs":
                return await self._search_drugs(arguments)
            elif tool_name == "count_by_field":
                return await self._count_by_field(arguments)
            else:
                raise ValueError(f"Unknown tool: {tool_name}")

        except Exception as e:
            logger.error(f"Error executing tool {tool_name}: {e}", exc_info=True)
            return self._format_error(e)

    async def _search_devices(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute device search with optional typed responses."""
        # Map endpoint string to enum
        endpoint_map = {
            "device_510k": OpenFDAEndpoint.DEVICE_510K,
            "device_class": OpenFDAEndpoint.DEVICE_CLASS,
            "device_event": OpenFDAEndpoint.DEVICE_EVENT,
            "device_pma": OpenFDAEndpoint.DEVICE_PMA,
            "device_recall": OpenFDAEndpoint.DEVICE_RECALL,
            "device_registration": OpenFDAEndpoint.DEVICE_REGISTRATION,
            "device_udi": OpenFDAEndpoint.DEVICE_UDI,
        }

        endpoint_str = arguments.get("endpoint", "device_510k")
        endpoint = endpoint_map.get(endpoint_str)
        if endpoint is None:
            raise ValueError(f"Invalid device endpoint: {endpoint_str}")

        query = arguments["query"]
        limit = arguments.get("limit", 100)
        max_records = arguments.get("max_records", 1000)
        use_typed_response = arguments.get("typed", False)

        # Collect results - use typed methods for 510(k) and PMA if requested
        results = []
        async with self.client:
            if use_typed_response and endpoint_str == "device_510k":
                # Use typed 510(k) search
                async for metadata in self.client.search_510k_typed(
                    query=query, limit=limit, max_records=max_records
                ):
                    # Convert to dict for JSON serialization with date handling
                    results.append(metadata.model_dump(mode='json', by_alias=True, exclude_none=True))
            elif use_typed_response and endpoint_str == "device_pma":
                # Use typed PMA search
                async for metadata in self.client.search_pma_typed(
                    query=query, limit=limit, max_records=max_records
                ):
                    results.append(metadata.model_dump(mode='json', by_alias=True, exclude_none=True))
            else:
                # Use raw search for other endpoints
                async for item in self.client.search(
                    endpoint=endpoint, query=query, limit=limit, max_records=max_records
                ):
                    results.append(item)

        # Truncate results array if needed (before JSON serialization)
        truncated_results, was_truncated = self._truncate_results(results)

        return {
            "success": True,
            "endpoint": endpoint_str,
            "query": query,
            "count": len(results),
            "returned_count": len(truncated_results),
            "typed": use_typed_response,
            "truncated": was_truncated,
            "results": truncated_results,
        }

    async def _search_drugs(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute drug search."""
        # Map endpoint string to enum
        endpoint_map = {
            "drug_event": OpenFDAEndpoint.DRUG_ADVERSE_EVENT,
            "drug_label": OpenFDAEndpoint.DRUG_LABEL,
            "drug_ndc": OpenFDAEndpoint.DRUG_NDC,
            "drug_enforcement": OpenFDAEndpoint.DRUG_ENFORCEMENT,
            "drug_recall": OpenFDAEndpoint.DRUG_RECALL,
        }

        endpoint_str = arguments.get("endpoint", "drug_event")
        endpoint = endpoint_map.get(endpoint_str)
        if endpoint is None:
            raise ValueError(f"Invalid drug endpoint: {endpoint_str}")

        query = arguments["query"]
        limit = arguments.get("limit", 100)
        max_records = arguments.get("max_records", 1000)

        # Collect results
        results = []
        async with self.client:
            async for item in self.client.search(
                endpoint=endpoint, query=query, limit=limit, max_records=max_records
            ):
                results.append(item)

        # Truncate results array if needed (before JSON serialization)
        truncated_results, was_truncated = self._truncate_results(results)

        return {
            "success": True,
            "endpoint": endpoint_str,
            "query": query,
            "count": len(results),
            "returned_count": len(truncated_results),
            "truncated": was_truncated,
            "results": truncated_results,
        }

    async def _count_by_field(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute count query."""
        endpoint_str = arguments["endpoint"]
        query = arguments["query"]
        count_field = arguments["count_field"]

        # Try to map to known endpoint enum
        # For count queries, we can use the endpoint string directly
        async with self.client:
            results = await self.client.count(
                endpoint=endpoint_str, query=query, count_field=count_field
            )

        return {
            "success": True,
            "endpoint": endpoint_str,
            "query": query,
            "count_field": count_field,
            "count": len(results),
            "results": results,
        }

    def _truncate_results(self, results: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], bool]:
        """
        Truncate results array to fit within max response size.

        Unlike _truncate_response which truncates JSON strings (breaking JSON),
        this truncates the array before serialization to maintain valid JSON.

        Args:
            results: List of result dictionaries

        Returns:
            Tuple of (truncated_results, was_truncated)
        """
        if not results:
            return results, False

        # Try serializing full results
        full_json = json.dumps(results, indent=2)
        if len(full_json) <= self.config.max_response_size:
            return results, False

        # Binary search to find how many results fit
        logger.warning(
            f"Response too large ({len(full_json)} chars), truncating to fit "
            f"{self.config.max_response_size} chars"
        )

        left, right = 1, len(results)
        best_fit = 1

        while left <= right:
            mid = (left + right) // 2
            truncated = results[:mid]
            test_json = json.dumps(truncated, indent=2)

            if len(test_json) <= self.config.max_response_size:
                best_fit = mid
                left = mid + 1
            else:
                right = mid - 1

        truncated_results = results[:best_fit]
        logger.warning(
            f"Returning {best_fit} of {len(results)} results "
            f"({len(json.dumps(truncated_results, indent=2))} chars)"
        )

        return truncated_results, True
