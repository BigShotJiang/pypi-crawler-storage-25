# Copyright 2025 Asher Informatics PBC
"""OpenFDA MCP server configuration."""

from dataclasses import dataclass

from ...external_apis.openfda import OpenFDAConfig
from ..base import MCPServerConfig


@dataclass
class OpenFDAMCPConfig(MCPServerConfig):
    """
    Configuration for OpenFDA MCP server.

    Combines MCP server settings with OpenFDA API configuration.

    Attributes:
        name: Server name (default: "openfda")
        version: Server version
        description: Server description
        max_response_size: Maximum response size in characters
        streaming_enabled: Whether to support streaming
        api_config: OpenFDA API client configuration

    Example:
        ```python
        # Basic configuration
        config = OpenFDAMCPConfig(
            api_config=OpenFDAConfig(api_key="your_key")
        )

        # Custom configuration
        config = OpenFDAMCPConfig(
            name="fda-api",
            max_response_size=200_000,
            api_config=OpenFDAConfig(
                api_key="your_key",
                timeout=60.0
            )
        )
        ```
    """

    # MCP server settings
    name: str = "openfda"
    version: str = "1.0.0"
    description: str = "MCP server for US FDA Open Data Portal"
    max_response_size: int = 50_000  # 50KB - reasonable for MCP clients (increase if needed)

    # OpenFDA API configuration
    api_config: OpenFDAConfig | None = None

    def __post_init__(self):
        """Initialize with default API config if not provided."""
        # Create default API config if not provided
        if self.api_config is None:
            self.api_config = OpenFDAConfig()

        # Call parent validation
        super().__post_init__()
