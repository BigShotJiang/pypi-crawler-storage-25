# Copyright 2025 Asher Informatics PBC
"""
Entry point for running AccessGUDID MCP server.

This module allows running the MCP server directly via:
    python -m ashmatics_tools.mcp_servers.accessgudid

Or with uv:
    uv run python -m ashmatics_tools.mcp_servers.accessgudid
"""

import asyncio
import json
import logging
import os
import sys
from typing import Any

from ...external_apis.accessgudid import AccessGUDIDConfig
from .config import AccessGUDIDMCPConfig
from .server import AccessGUDIDMCPServer

# Configure logging - send to stderr and only log warnings/errors by default
# This prevents INFO logs from interfering with JSON-RPC stdio communication
logging.basicConfig(
    level=logging.WARNING,  # Only show warnings and errors by default
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,  # Explicitly send to stderr (not stdout)
)
logger = logging.getLogger(__name__)

# Allow debug logging via environment variable
if os.getenv("MCP_DEBUG"):
    logging.getLogger().setLevel(logging.DEBUG)
    logger.debug("Debug logging enabled")


async def handle_mcp_request(
    server: AccessGUDIDMCPServer, request: dict[str, Any]
) -> dict[str, Any]:
    """
    Handle an MCP protocol request.

    Args:
        server: MCP server instance
        request: MCP request message

    Returns:
        MCP response message
    """
    method = request.get("method")
    params = request.get("params", {})

    try:
        if method == "initialize":
            # Handle initialization handshake
            return {
                "jsonrpc": "2.0",
                "id": request.get("id"),
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {},
                        "resources": {},
                        "prompts": {},
                    },
                    "serverInfo": {
                        "name": server.config.name,
                        "version": server.config.version,
                    },
                },
            }

        elif method == "tools/list":
            # Return list of available tools
            tools = server.get_tools()
            return {
                "jsonrpc": "2.0",
                "id": request.get("id"),
                "result": {"tools": tools},
            }

        elif method == "tools/call":
            # Execute a tool
            tool_name = params.get("name")
            arguments = params.get("arguments", {})

            # Execute with timeout (60 seconds)
            try:
                result = await asyncio.wait_for(
                    server.call_tool(tool_name, arguments), timeout=60.0
                )
            except asyncio.TimeoutError:
                return {
                    "jsonrpc": "2.0",
                    "id": request.get("id"),
                    "error": {
                        "code": -32000,
                        "message": "Tool execution timed out after 60 seconds",
                        "data": {
                            "tool": tool_name,
                            "user_message": (
                                "The request took too long. "
                                "Try using a more specific identifier."
                            ),
                        },
                    },
                }

            # Check if the result is an error from _format_error
            if isinstance(result, dict) and result.get("error") is True:
                # Return as JSON-RPC error
                return {
                    "jsonrpc": "2.0",
                    "id": request.get("id") or -1,
                    "error": {
                        "code": -32603,
                        "message": result.get("message", "Unknown error"),
                        "data": {
                            "type": result.get("type"),
                            "user_message": result.get("user_message"),
                        },
                    },
                }
            else:
                # Return successful result
                return {
                    "jsonrpc": "2.0",
                    "id": request.get("id") or -1,
                    "result": {
                        "content": [{"type": "text", "text": json.dumps(result, indent=2)}]
                    },
                }

        elif method == "resources/list":
            # Return list of available resources
            resources = server.get_resources()
            return {
                "jsonrpc": "2.0",
                "id": request.get("id"),
                "result": {"resources": resources},
            }

        elif method == "prompts/list":
            # Return list of available prompts
            prompts = server.get_prompts()
            return {
                "jsonrpc": "2.0",
                "id": request.get("id"),
                "result": {"prompts": prompts},
            }

        else:
            return {
                "jsonrpc": "2.0",
                "id": request.get("id"),
                "error": {"code": -32601, "message": f"Method not found: {method}"},
            }

    except Exception as e:
        logger.error(f"Error handling request: {e}", exc_info=True)
        return {
            "jsonrpc": "2.0",
            "id": request.get("id"),
            "error": {"code": -32603, "message": f"Internal error: {str(e)}"},
        }


async def run_stdio_server():
    """
    Run MCP server using stdio transport (standard input/output).

    This is the standard way MCP servers communicate with clients.
    """
    # Get UMLS API key from environment (optional, for SNOMED lookups)
    umls_api_key = os.getenv("UMLS_API_KEY")
    if not umls_api_key:
        logger.debug(
            "UMLS_API_KEY not set. SNOMED lookups will require passing "
            "umls_api_key parameter explicitly."
        )

    # Create server instance
    api_config = AccessGUDIDConfig(umls_api_key=umls_api_key)
    mcp_config = AccessGUDIDMCPConfig(api_config=api_config)
    server = AccessGUDIDMCPServer(mcp_config)

    # Log startup only in debug mode
    logger.debug("AccessGUDID MCP Server started")
    logger.debug(
        "Available tools: lookup_device, parse_udi, get_device_history, "
        "get_device_snomed, list_implantable_devices"
    )
    logger.debug("Listening on stdin/stdout for MCP protocol messages")

    # Read from stdin, write to stdout
    while True:
        try:
            # Read line from stdin
            line = sys.stdin.readline()
            if not line:
                break

            # Parse JSON-RPC message
            message = json.loads(line)

            # Check if this is a notification (no id or id is None)
            # Per JSON-RPC 2.0 spec, notifications MUST NOT receive a response
            message_id = message.get("id")
            is_notification = message_id is None

            if is_notification:
                # Handle notification silently - no response needed
                method = message.get("method", "")
                logger.debug(f"Received notification: {method}")
                continue

            # Handle request (has an id, expects a response)
            response = await handle_mcp_request(server, message)

            # Write response to stdout
            print(json.dumps(response), flush=True)

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON: {e}")
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": "Parse error"},
            }
            print(json.dumps(error_response), flush=True)

        except KeyboardInterrupt:
            logger.info("Server stopped by user")
            break

        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)


def main():
    """Main entry point."""
    try:
        asyncio.run(run_stdio_server())
    except KeyboardInterrupt:
        logger.info("Server shutdown")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
