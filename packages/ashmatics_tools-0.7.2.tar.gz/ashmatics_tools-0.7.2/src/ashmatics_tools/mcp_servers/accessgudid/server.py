# Copyright 2025 Asher Informatics PBC
"""AccessGUDID MCP server implementation."""

import json
import logging
from typing import Any

from ...external_apis.accessgudid import AccessGUDIDClient
from ..base import BaseMCPServer
from .config import AccessGUDIDMCPConfig

logger = logging.getLogger(__name__)


class AccessGUDIDMCPServer(BaseMCPServer):
    """
    MCP server for AccessGUDID API.

    Exposes AccessGUDID capabilities as MCP tools including:
    - lookup_device: Look up device by DI, UDI, or record key
    - parse_udi: Parse UDI string into components
    - get_device_history: Get device version history
    - get_device_snomed: Get SNOMED CT codes for device
    - list_implantable_devices: List implantable devices

    Example:
        ```python
        config = AccessGUDIDMCPConfig(
            api_config=AccessGUDIDConfig()
        )
        server = AccessGUDIDMCPServer(config)

        # Lookup a device by DI
        result = await server.call_tool(
            "lookup_device",
            {"di": "08717648200274"}
        )

        # Parse a UDI string
        result = await server.call_tool(
            "parse_udi",
            {"udi": "(01)00844588012919(17)141231(10)A213B1"}
        )
        ```
    """

    def __init__(self, config: AccessGUDIDMCPConfig):
        """Initialize AccessGUDID MCP server.

        Args:
            config: Server configuration
        """
        super().__init__(config)
        self.config: AccessGUDIDMCPConfig = config  # Type hint for IDE
        assert self.config.api_config is not None
        self.client = AccessGUDIDClient(self.config.api_config)

    def get_tools(self) -> list[dict[str, Any]]:
        """
        Get list of available tools.

        Returns:
            List of tool definitions with JSON schemas
        """
        return [
            {
                "name": "lookup_device",
                "description": (
                    "Look up a medical device in the FDA GUDID database by Device Identifier (DI), "
                    "Unique Device Identifier (UDI), or record key. "
                    "Returns comprehensive device information including brand name, company, "
                    "product codes, GMDN terms, and regulatory status."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "di": {
                            "type": "string",
                            "description": (
                                "Device Identifier - the portion of the UDI that identifies "
                                "the labeler and the specific version/model of a device"
                            ),
                        },
                        "udi": {
                            "type": "string",
                            "description": (
                                "Full Unique Device Identifier string. Can be in GS1, HIBCC, "
                                "or ICCBBA format. Will be automatically URL-encoded."
                            ),
                        },
                        "record_key": {
                            "type": "string",
                            "description": "Public Device Record Key unique to this device record",
                        },
                    },
                    "anyOf": [
                        {"required": ["di"]},
                        {"required": ["udi"]},
                        {"required": ["record_key"]},
                    ],
                },
            },
            {
                "name": "parse_udi",
                "description": (
                    "Parse a Unique Device Identifier (UDI) string into its components. "
                    "Supports GS1, HIBCC, and ICCBBA formats. "
                    "Returns the issuing agency, device identifier, serial number, lot number, "
                    "manufacturing date, expiration date, and other encoded information."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "udi": {
                            "type": "string",
                            "description": (
                                "Full Unique Device Identifier string to parse. "
                                "Examples: '(01)00844588012919(17)141231(10)A213B1' (GS1), "
                                "'+H123ABC456/$$420020216LOT123' (HIBCC)"
                            ),
                        },
                    },
                    "required": ["udi"],
                },
            },
            {
                "name": "get_device_history",
                "description": (
                    "Get the version history for a medical device. "
                    "Returns all historical versions of the device record with dates "
                    "and version numbers. Useful for tracking regulatory changes over time."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "di": {
                            "type": "string",
                            "description": "Device Identifier",
                        },
                        "udi": {
                            "type": "string",
                            "description": "Full Unique Device Identifier string",
                        },
                        "record_key": {
                            "type": "string",
                            "description": "Public Device Record Key",
                        },
                    },
                    "anyOf": [
                        {"required": ["di"]},
                        {"required": ["udi"]},
                        {"required": ["record_key"]},
                    ],
                },
            },
            {
                "name": "get_device_snomed",
                "description": (
                    "Get SNOMED CT codes associated with a medical device. "
                    "Requires a valid UMLS API key (configured in server or passed as parameter). "
                    "Returns SNOMED CT concept names and identifiers for clinical terminology mapping."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "di": {
                            "type": "string",
                            "description": "Device Identifier",
                        },
                        "udi": {
                            "type": "string",
                            "description": "Full Unique Device Identifier string",
                        },
                        "record_key": {
                            "type": "string",
                            "description": "Public Device Record Key",
                        },
                        "umls_api_key": {
                            "type": "string",
                            "description": (
                                "UMLS API key for SNOMED access. "
                                "If not provided, uses the key configured in the server."
                            ),
                        },
                    },
                    "anyOf": [
                        {"required": ["di"]},
                        {"required": ["udi"]},
                        {"required": ["record_key"]},
                    ],
                },
            },
            {
                "name": "list_implantable_devices",
                "description": (
                    "List medical devices flagged as implantable or accessories to implant systems. "
                    "Supports date filtering and pagination. "
                    "Returns device metadata including brand name, company, MRI safety status, and GMDN terms."
                ),
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "from_date": {
                            "type": "string",
                            "description": (
                                "Filter devices updated after this date (inclusive). "
                                "Format: YYYY-MM-DD"
                            ),
                        },
                        "to_date": {
                            "type": "string",
                            "description": (
                                "Filter devices updated before this date (inclusive). "
                                "Format: YYYY-MM-DD"
                            ),
                        },
                        "max_records": {
                            "type": "integer",
                            "description": "Maximum number of records to return",
                            "default": 100,
                            "minimum": 1,
                            "maximum": 1000,
                        },
                    },
                },
            },
        ]

    async def call_tool(
        self, tool_name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Execute a tool and return results.

        Args:
            tool_name: Name of the tool to execute
            arguments: Tool arguments

        Returns:
            Tool execution results

        Raises:
            ValueError: If tool not found or invalid arguments
            RuntimeError: On tool execution errors
        """
        try:
            if tool_name == "lookup_device":
                return await self._lookup_device(arguments)
            elif tool_name == "parse_udi":
                return await self._parse_udi(arguments)
            elif tool_name == "get_device_history":
                return await self._get_device_history(arguments)
            elif tool_name == "get_device_snomed":
                return await self._get_device_snomed(arguments)
            elif tool_name == "list_implantable_devices":
                return await self._list_implantable_devices(arguments)
            else:
                raise ValueError(f"Unknown tool: {tool_name}")

        except Exception as e:
            logger.error(f"Error executing tool {tool_name}: {e}", exc_info=True)
            return self._format_error(e)

    async def _lookup_device(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute device lookup."""
        di = arguments.get("di")
        udi = arguments.get("udi")
        record_key = arguments.get("record_key")

        if not any([di, udi, record_key]):
            raise ValueError("At least one of di, udi, or record_key must be provided")

        async with self.client:
            result = await self.client.lookup_device(
                di=di, udi=udi, record_key=record_key
            )

        # Extract key device info for summary
        device_info = result.get("gudid", {}).get("device", {})
        summary = {
            "brandName": device_info.get("brandName"),
            "companyName": device_info.get("companyName"),
            "deviceId": device_info.get("deviceId"),
            "versionModelNumber": device_info.get("versionModelNumber"),
            "deviceDescription": device_info.get("deviceDescription"),
        }

        # Truncate full result if needed
        result_json = json.dumps(result, indent=2)
        if len(result_json) > self.config.max_response_size:
            # Return summary with note about truncation
            return {
                "success": True,
                "summary": summary,
                "truncated": True,
                "message": "Full result truncated. Key device info shown in summary.",
                "full_result_size": len(result_json),
            }

        return {
            "success": True,
            "summary": summary,
            "result": result,
        }

    async def _parse_udi(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute UDI parsing."""
        udi = arguments.get("udi")
        if not udi:
            raise ValueError("udi parameter is required")

        async with self.client:
            result = await self.client.parse_udi(udi=udi)

        return {
            "success": True,
            "udi": udi,
            "parsed": result,
        }

    async def _get_device_history(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute device history lookup."""
        di = arguments.get("di")
        udi = arguments.get("udi")
        record_key = arguments.get("record_key")

        if not any([di, udi, record_key]):
            raise ValueError("At least one of di, udi, or record_key must be provided")

        async with self.client:
            result = await self.client.get_device_history(
                di=di, udi=udi, record_key=record_key
            )

        # Extract version count for summary
        history = result.get("deviceHistory", [])
        version_count = len(history) if isinstance(history, list) else 0

        return {
            "success": True,
            "version_count": version_count,
            "result": result,
        }

    async def _get_device_snomed(self, arguments: dict[str, Any]) -> dict[str, Any]:
        """Execute SNOMED lookup."""
        di = arguments.get("di")
        udi = arguments.get("udi")
        record_key = arguments.get("record_key")
        umls_api_key = arguments.get("umls_api_key")

        if not any([di, udi, record_key]):
            raise ValueError("At least one of di, udi, or record_key must be provided")

        async with self.client:
            result = await self.client.get_device_snomed(
                di=di, udi=udi, record_key=record_key, umls_api_key=umls_api_key
            )

        # Extract concept count for summary
        concepts = result.get("concepts", [])
        concept_count = len(concepts) if isinstance(concepts, list) else 0

        return {
            "success": True,
            "concept_count": concept_count,
            "concepts": concepts,
            "result": result,
        }

    async def _list_implantable_devices(
        self, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        """Execute implantable device listing."""
        from_date = arguments.get("from_date")
        to_date = arguments.get("to_date")
        max_records = arguments.get("max_records", 100)

        results = []
        async with self.client:
            async for device in self.client.list_implantable_devices(
                from_date=from_date,
                to_date=to_date,
                max_records=max_records,
            ):
                results.append(device)

        # Truncate results array if needed
        truncated_results, was_truncated = self._truncate_results(results)

        return {
            "success": True,
            "count": len(results),
            "returned_count": len(truncated_results),
            "truncated": was_truncated,
            "from_date": from_date,
            "to_date": to_date,
            "results": truncated_results,
        }

    def _truncate_results(
        self, results: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], bool]:
        """
        Truncate results array to fit within max response size.

        Args:
            results: List of result dictionaries

        Returns:
            Tuple of (truncated_results, was_truncated)
        """
        if not results:
            return results, False

        # Try serializing full results
        full_json = json.dumps(results, indent=2)
        if len(full_json) <= self.config.max_response_size:
            return results, False

        # Binary search to find how many results fit
        logger.warning(
            f"Response too large ({len(full_json)} chars), truncating to fit "
            f"{self.config.max_response_size} chars"
        )

        left, right = 1, len(results)
        best_fit = 1

        while left <= right:
            mid = (left + right) // 2
            truncated = results[:mid]
            test_json = json.dumps(truncated, indent=2)

            if len(test_json) <= self.config.max_response_size:
                best_fit = mid
                left = mid + 1
            else:
                right = mid - 1

        truncated_results = results[:best_fit]
        logger.warning(
            f"Returning {best_fit} of {len(results)} results "
            f"({len(json.dumps(truncated_results, indent=2))} chars)"
        )

        return truncated_results, True
