# Copyright 2025 Asher Informatics PBC
"""AccessGUDID MCP server for device identifier lookup.

This module provides an MCP server that exposes AccessGUDID API capabilities
to LLMs via the Model Context Protocol.

Available tools:
- lookup_device: Look up device by DI, UDI, or record key
- parse_udi: Parse UDI string into components
- get_device_history: Get device version history
- get_device_snomed: Get SNOMED CT codes for device (requires UMLS key)
- list_implantable_devices: List implantable devices with filtering

Example usage:
    ```python
    from ashmatics_tools.mcp_servers.accessgudid import (
        AccessGUDIDMCPConfig,
        AccessGUDIDMCPServer,
    )
    from ashmatics_tools.external_apis.accessgudid import AccessGUDIDConfig

    config = AccessGUDIDMCPConfig(
        api_config=AccessGUDIDConfig()
    )
    server = AccessGUDIDMCPServer(config)

    # Call a tool
    result = await server.call_tool(
        "lookup_device",
        {"di": "08717648200274"}
    )
    ```

See https://accessgudid.nlm.nih.gov/resources/developers for full API documentation.
"""

from .config import AccessGUDIDMCPConfig
from .server import AccessGUDIDMCPServer

__all__ = [
    "AccessGUDIDMCPConfig",
    "AccessGUDIDMCPServer",
]
