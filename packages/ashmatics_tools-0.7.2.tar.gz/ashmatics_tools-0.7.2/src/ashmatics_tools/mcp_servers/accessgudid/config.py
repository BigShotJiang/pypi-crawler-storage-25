# Copyright 2025 Asher Informatics PBC
"""AccessGUDID MCP server configuration."""

from dataclasses import dataclass

from ...external_apis.accessgudid import AccessGUDIDConfig
from ..base import MCPServerConfig


@dataclass
class AccessGUDIDMCPConfig(MCPServerConfig):
    """
    Configuration for AccessGUDID MCP server.

    Combines MCP server settings with AccessGUDID API configuration.

    Attributes:
        name: Server name (default: "accessgudid")
        version: Server version
        description: Server description
        max_response_size: Maximum response size in characters
        streaming_enabled: Whether to support streaming
        api_config: AccessGUDID API client configuration

    Example:
        ```python
        # Basic configuration
        config = AccessGUDIDMCPConfig(
            api_config=AccessGUDIDConfig()
        )

        # With UMLS API key for SNOMED lookups
        config = AccessGUDIDMCPConfig(
            api_config=AccessGUDIDConfig(umls_api_key="your_key")
        )

        # Custom configuration
        config = AccessGUDIDMCPConfig(
            name="gudid-api",
            max_response_size=200_000,
            api_config=AccessGUDIDConfig(
                timeout=60.0
            )
        )
        ```
    """

    # MCP server settings
    name: str = "accessgudid"
    version: str = "1.0.0"
    description: str = "MCP server for NIH/FDA AccessGUDID Device Database"
    max_response_size: int = 50_000  # 50KB - reasonable for MCP clients

    # AccessGUDID API configuration
    api_config: AccessGUDIDConfig | None = None

    def __post_init__(self):
        """Initialize with default API config if not provided."""
        # Create default API config if not provided
        if self.api_config is None:
            self.api_config = AccessGUDIDConfig()

        # Call parent validation
        super().__post_init__()
