# Copyright 2025 Asher Informatics PBC
"""MCP (Model Context Protocol) servers for ashmatics-tools.

This module provides MCP servers for external data sources. Each MCP server
wraps an API client and exposes tools/resources for LLM consumption.

MCP servers are thin adapters that:
1. Expose API capabilities as tools
2. Handle input validation and sanitization
3. Format responses for LLM consumption
4. Provide streaming for large datasets

Example usage:
    ```python
    from ashmatics_tools.mcp_servers import create_mcp_server, OpenFDAMCPConfig

    # Create OpenFDA MCP server
    config = OpenFDAMCPConfig(api_key="your_key")
    server = create_mcp_server("openfda", config)

    # Run server (typically via MCP runtime)
    await server.run()

    # Create AccessGUDID MCP server
    from ashmatics_tools.mcp_servers import AccessGUDIDMCPConfig

    config = AccessGUDIDMCPConfig()
    server = create_mcp_server("accessgudid", config)
    ```

Note: This module provides server implementations. To deploy MCP servers,
use the MCP runtime or your preferred deployment method (FastAPI, etc.).
"""

from .base import BaseMCPServer, MCPServerConfig
from .factory import create_mcp_server, list_mcp_servers, register_mcp_server

# OpenFDA MCP server
from .openfda import OpenFDAMCPConfig, OpenFDAMCPServer

# AccessGUDID MCP server
from .accessgudid import AccessGUDIDMCPConfig, AccessGUDIDMCPServer

# Register MCP servers
from .factory import _MCP_REGISTRY, _MCP_CONFIG_REGISTRY

_MCP_REGISTRY["openfda"] = OpenFDAMCPServer
_MCP_CONFIG_REGISTRY["openfda"] = OpenFDAMCPConfig

_MCP_REGISTRY["accessgudid"] = AccessGUDIDMCPServer
_MCP_CONFIG_REGISTRY["accessgudid"] = AccessGUDIDMCPConfig

__all__ = [
    # Base classes
    "BaseMCPServer",
    "MCPServerConfig",
    # Factory functions
    "create_mcp_server",
    "register_mcp_server",
    "list_mcp_servers",
    # OpenFDA MCP
    "OpenFDAMCPServer",
    "OpenFDAMCPConfig",
    # AccessGUDID MCP
    "AccessGUDIDMCPServer",
    "AccessGUDIDMCPConfig",
]
