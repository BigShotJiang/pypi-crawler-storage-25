# Copyright 2025 Asher Informatics PBC
"""Abstract base class for MCP servers.

This module defines the common interface for MCP servers that expose
external API capabilities to LLMs via the Model Context Protocol.
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class MCPServerConfig:
    """
    Base configuration for MCP servers.

    Attributes:
        name: Server name/identifier
        version: Server version
        description: Human-readable description
        max_response_size: Maximum response size in characters
        streaming_enabled: Whether to support streaming responses
        extra_config: Additional provider-specific configuration
    """

    name: str
    version: str = "1.0.0"
    description: str = ""
    max_response_size: int = 100_000  # 100K characters
    streaming_enabled: bool = True
    extra_config: dict[str, Any] | None = None

    def __post_init__(self):
        """Validate configuration."""
        if self.max_response_size <= 0:
            raise ValueError("max_response_size must be positive")


class BaseMCPServer(ABC):
    """
    Abstract base class for MCP servers.

    MCP servers expose API capabilities as tools that can be called by LLMs.
    They handle:
    - Tool registration and discovery
    - Input validation and sanitization
    - Response formatting for LLM consumption
    - Error handling and user-friendly messages
    - Optional streaming for large datasets

    Subclasses must implement:
    - get_tools(): Return list of available tools
    - call_tool(): Execute a tool and return results
    - get_resources(): Return list of available resources (optional)
    - get_prompts(): Return list of available prompts (optional)
    """

    def __init__(self, config: MCPServerConfig):
        """Initialize MCP server.

        Args:
            config: Server configuration
        """
        self.config = config
        logger.debug(f"Initialized MCP server: {config.name} v{config.version}")

    @abstractmethod
    def get_tools(self) -> list[dict[str, Any]]:
        """
        Get list of available tools.

        Returns:
            List of tool definitions with schema

        Example:
            ```python
            return [
                {
                    "name": "search_devices",
                    "description": "Search FDA device database",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Search query"},
                            "limit": {"type": "integer", "default": 100}
                        },
                        "required": ["query"]
                    }
                }
            ]
            ```
        """
        pass

    @abstractmethod
    async def call_tool(
        self, tool_name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Execute a tool and return results.

        Args:
            tool_name: Name of the tool to execute
            arguments: Tool arguments

        Returns:
            Tool execution results

        Raises:
            ValueError: If tool not found or invalid arguments
            RuntimeError: On tool execution errors

        Example:
            ```python
            result = await server.call_tool(
                "search_devices",
                {"query": "pacemaker", "limit": 10}
            )
            ```
        """
        pass

    def get_resources(self) -> list[dict[str, Any]]:
        """
        Get list of available resources.

        Resources are static or semi-static data that can be retrieved.
        Override this method if your server provides resources.

        Returns:
            List of resource definitions
        """
        return []

    def get_prompts(self) -> list[dict[str, Any]]:
        """
        Get list of available prompts.

        Prompts are pre-defined prompt templates for common tasks.
        Override this method if your server provides prompts.

        Returns:
            List of prompt definitions
        """
        return []

    async def run(self) -> None:
        """
        Run the MCP server.

        This method should be implemented by deployment-specific subclasses
        (e.g., FastAPI-based MCP server, stdio MCP server).

        Base implementation is a no-op placeholder.
        """
        logger.warning(
            f"Base run() called for {self.config.name} - override for actual deployment"
        )

    def _truncate_response(self, response: str) -> tuple[str, bool]:
        """
        Truncate response if it exceeds max size.

        Args:
            response: Response string

        Returns:
            Tuple of (truncated_response, was_truncated)
        """
        if len(response) <= self.config.max_response_size:
            return response, False

        truncated = response[: self.config.max_response_size]
        logger.warning(
            f"Response truncated from {len(response)} to {self.config.max_response_size} characters"
        )
        return truncated, True

    def _format_error(self, error: Exception) -> dict[str, Any]:
        """
        Format error for LLM consumption.

        Args:
            error: Exception to format

        Returns:
            Formatted error response
        """
        return {
            "error": True,
            "type": type(error).__name__,
            "message": str(error),
            "user_message": (
                "An error occurred while processing your request. "
                "Please check your input and try again."
            ),
        }
