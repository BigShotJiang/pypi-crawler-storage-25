# Copyright 2025 Asher Informatics PBC
"""Factory functions for creating MCP servers.

This module provides a registry-based factory pattern for creating MCP servers.
"""

import logging
from typing import Any, Type

from .base import BaseMCPServer, MCPServerConfig

logger = logging.getLogger(__name__)

# Global registry for MCP servers
_MCP_REGISTRY: dict[str, Type[BaseMCPServer]] = {}
_MCP_CONFIG_REGISTRY: dict[str, Type[MCPServerConfig]] = {}


def register_mcp_server(
    name: str,
    server_class: Type[BaseMCPServer],
    config_class: Type[MCPServerConfig] | None = None,
) -> None:
    """
    Register a new MCP server.

    Args:
        name: Server identifier (e.g., "openfda", "census")
        server_class: MCP server class (must extend BaseMCPServer)
        config_class: Configuration class (must extend MCPServerConfig)

    Example:
        ```python
        class CustomMCPServer(BaseMCPServer):
            pass

        @dataclass
        class CustomMCPConfig(MCPServerConfig):
            pass

        register_mcp_server("custom", CustomMCPServer, CustomMCPConfig)
        ```
    """
    if not issubclass(server_class, BaseMCPServer):
        raise TypeError(f"server_class must extend BaseMCPServer, got {server_class}")

    if config_class is not None and not issubclass(config_class, MCPServerConfig):
        raise TypeError(f"config_class must extend MCPServerConfig, got {config_class}")

    _MCP_REGISTRY[name] = server_class
    if config_class is not None:
        _MCP_CONFIG_REGISTRY[name] = config_class

    logger.info(f"Registered MCP server: {name}")


def unregister_mcp_server(name: str) -> None:
    """
    Unregister an MCP server.

    Args:
        name: Server identifier to remove
    """
    _MCP_REGISTRY.pop(name, None)
    _MCP_CONFIG_REGISTRY.pop(name, None)
    logger.info(f"Unregistered MCP server: {name}")


def list_mcp_servers() -> list[str]:
    """
    List all registered MCP servers.

    Returns:
        List of server identifiers
    """
    return list(_MCP_REGISTRY.keys())


def get_mcp_config_class(name: str) -> Type[MCPServerConfig] | None:
    """
    Get the configuration class for an MCP server.

    Args:
        name: Server identifier

    Returns:
        Configuration class or None if not registered
    """
    return _MCP_CONFIG_REGISTRY.get(name)


def create_mcp_server(name: str, config: Any) -> BaseMCPServer:
    """
    Create an MCP server for the specified provider.

    Args:
        name: MCP server identifier (e.g., "openfda")
        config: Server-specific configuration object

    Returns:
        Initialized MCP server

    Raises:
        ValueError: If server not registered

    Example:
        ```python
        from ashmatics_tools.mcp_servers import create_mcp_server, OpenFDAMCPConfig

        config = OpenFDAMCPConfig(api_key="your_key")
        server = create_mcp_server("openfda", config)

        # Use server
        tools = server.get_tools()
        result = await server.call_tool("search_devices", {"query": "pacemaker"})
        ```
    """
    if name not in _MCP_REGISTRY:
        available = ", ".join(_MCP_REGISTRY.keys())
        raise ValueError(
            f"Unknown MCP server: {name}. Available servers: {available}"
        )

    server_class = _MCP_REGISTRY[name]
    logger.info(f"Creating MCP server: {name}")
    return server_class(config)
