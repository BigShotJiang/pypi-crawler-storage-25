"""GraphQL client utilities for Hasura endpoints.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from .client import GraphQLClient

__all__ = ["GraphQLClient"]
