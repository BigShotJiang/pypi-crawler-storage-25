"""Generic GraphQL client for Hasura endpoints.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
import os
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Load environment variables from .env file if it exists
dotenv_path = Path.cwd() / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)


class GraphQLClient:
    """
    Generic GraphQL client for executing queries and mutations.

    Provides a simple interface for interacting with GraphQL endpoints,
    particularly useful for Hasura APIs.
    """

    def __init__(
        self,
        endpoint: str | None = None,
        headers: dict[str, str] | None = None,
        admin_secret: str | None = None,
        verify_ssl: bool = True,
    ):
        """
        Initialize the GraphQL client.

        Args:
            endpoint: GraphQL endpoint URL (default: from HASURA_GRAPHQL_ENDPOINT env)
            headers: Custom headers dictionary
            admin_secret: Hasura admin secret (default: from HASURA_ADMIN_SECRET env)
                        Will be added to headers as 'X-Hasura-Admin-Secret'
            verify_ssl: Whether to verify SSL certificates (default: True)

        Raises:
            ValueError: If endpoint is not provided
        """
        endpoint_str = endpoint or os.getenv("HASURA_GRAPHQL_ENDPOINT")

        if not endpoint_str:
            raise ValueError(
                "GraphQL endpoint required. Provide via endpoint parameter "
                "or HASURA_GRAPHQL_ENDPOINT environment variable."
            )

        self.endpoint: str = endpoint_str
        self.verify_ssl = verify_ssl

        # Log warning if SSL verification is disabled
        if not verify_ssl:
            logger.warning(
                "SSL certificate verification is DISABLED. "
                "This is insecure and should only be used in development/testing."
            )

        # Setup headers
        if headers:
            self.headers = headers.copy()
        else:
            self.headers = {"Content-Type": "application/json"}

        # Add admin secret to headers if provided
        admin_secret = admin_secret or os.getenv("HASURA_ADMIN_SECRET")
        if admin_secret:
            self.headers["X-Hasura-Admin-Secret"] = admin_secret

        logger.info(f"Initialized GraphQLClient (endpoint: {self.endpoint}, SSL: {verify_ssl})")

    def execute(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        """
        Execute a GraphQL query or mutation.

        Args:
            query: GraphQL query or mutation string
            variables: Variables dictionary for the query
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Response data dictionary containing 'data' and optionally 'errors'

        Raises:
            httpx.HTTPError: If HTTP request fails
            ValueError: If response cannot be parsed as JSON
        """
        payload: dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables

        try:
            logger.debug(f"Executing GraphQL operation: {query[:100]}...")

            response = httpx.post(
                self.endpoint,
                headers=self.headers,
                json=payload,
                verify=self.verify_ssl,
                timeout=timeout,
            )

            response.raise_for_status()

            data: dict[str, Any] = response.json()

            if "errors" in data:
                logger.warning(f"GraphQL errors in response: {data['errors']}")

            return data

        except httpx.HTTPError as e:
            logger.error(f"HTTP request failed: {str(e)}", exc_info=True)
            raise
        except ValueError as e:
            logger.error(f"Failed to parse response as JSON: {str(e)}", exc_info=True)
            raise

    def execute_query(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any] | None:
        """
        Execute a GraphQL query and return the data.

        Args:
            query: GraphQL query string
            variables: Variables dictionary for the query
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Data dictionary from response, or None if errors occurred
        """
        result = self.execute(query, variables, timeout)

        if "errors" in result:
            logger.error(f"GraphQL query failed: {result['errors']}")
            return None

        return result.get("data")

    def execute_mutation(
        self,
        mutation: str,
        variables: dict[str, Any] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any] | None:
        """
        Execute a GraphQL mutation and return the data.

        Args:
            mutation: GraphQL mutation string
            variables: Variables dictionary for the mutation
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Data dictionary from response, or None if errors occurred
        """
        result = self.execute(mutation, variables, timeout)

        if "errors" in result:
            logger.error(f"GraphQL mutation failed: {result['errors']}")
            return None

        return result.get("data")

    def insert_one(
        self,
        table_name: str,
        object_data: dict[str, Any],
        return_fields: list[str] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any] | None:
        """
        Insert a single record into a table.

        Args:
            table_name: Name of the table
            object_data: Data to insert
            return_fields: Fields to return (default: ["id"])
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Inserted record data, or None if insertion failed
        """
        if return_fields is None:
            return_fields = ["id"]

        return_fields_str = " ".join(return_fields)

        mutation = f"""
        mutation insert_{table_name}_one($object: {table_name}_insert_input!) {{
          insert_{table_name}_one(object: $object) {{
            {return_fields_str}
          }}
        }}
        """

        variables = {"object": object_data}
        result = self.execute_mutation(mutation, variables, timeout)

        if result:
            return result.get(f"insert_{table_name}_one")
        return None

    def upsert_one(
        self,
        table_name: str,
        object_data: dict[str, Any],
        constraint: str,
        update_columns: list[str],
        return_fields: list[str] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any] | None:
        """
        Upsert (insert or update) a single record.

        Args:
            table_name: Name of the table
            object_data: Data to insert/update
            constraint: Constraint name for conflict detection
            update_columns: Columns to update on conflict
            return_fields: Fields to return (default: ["id"])
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Upserted record data, or None if operation failed
        """
        if return_fields is None:
            return_fields = ["id"]

        return_fields_str = " ".join(return_fields)
        update_columns_str = ", ".join(update_columns)

        mutation = f"""
        mutation upsert_{table_name}_one($object: {table_name}_insert_input!) {{
          insert_{table_name}_one(
            object: $object,
            on_conflict: {{
              constraint: {constraint},
              update_columns: [{update_columns_str}]
            }}
          ) {{
            {return_fields_str}
          }}
        }}
        """

        variables = {"object": object_data}
        result = self.execute_mutation(mutation, variables, timeout)

        if result:
            return result.get(f"insert_{table_name}_one")
        return None

    def insert_many(
        self,
        table_name: str,
        objects: list[dict[str, Any]],
        return_fields: list[str] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any] | None:
        """
        Insert multiple records into a table.

        Args:
            table_name: Name of the table
            objects: List of objects to insert
            return_fields: Fields to return for each record (default: ["id"])
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Result data with affected_rows and returning array, or None if failed
        """
        if return_fields is None:
            return_fields = ["id"]

        return_fields_str = " ".join(return_fields)

        mutation = f"""
        mutation insert_{table_name}($objects: [{table_name}_insert_input!]!) {{
          insert_{table_name}(objects: $objects) {{
            affected_rows
            returning {{
              {return_fields_str}
            }}
          }}
        }}
        """

        variables = {"objects": objects}
        result = self.execute_mutation(mutation, variables, timeout)

        if result:
            return result.get(f"insert_{table_name}")
        return None

    def update_by_pk(
        self,
        table_name: str,
        pk_columns: dict[str, Any],
        set_data: dict[str, Any],
        return_fields: list[str] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any] | None:
        """
        Update a record by primary key.

        Args:
            table_name: Name of the table
            pk_columns: Primary key column(s) and value(s)
            set_data: Data to update
            return_fields: Fields to return (default: ["id"])
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Updated record data, or None if update failed
        """
        if return_fields is None:
            return_fields = ["id"]

        return_fields_str = " ".join(return_fields)

        # Build pk_columns argument string
        pk_signature = ", ".join([f"${k}: {self._infer_type(v)}" for k, v in pk_columns.items()])

        mutation = f"""
        mutation update_{table_name}_by_pk({pk_signature}, $_set: {table_name}_set_input!) {{
          update_{table_name}_by_pk(
            pk_columns: {{ {", ".join([f"{k}: ${k}" for k in pk_columns.keys()])} }},
            _set: $_set
          ) {{
            {return_fields_str}
          }}
        }}
        """

        variables = {**pk_columns, "_set": set_data}
        result = self.execute_mutation(mutation, variables, timeout)

        if result:
            return result.get(f"update_{table_name}_by_pk")
        return None

    def delete_by_pk(
        self,
        table_name: str,
        pk_columns: dict[str, Any],
        return_fields: list[str] | None = None,
        timeout: int = 30,
    ) -> dict[str, Any] | None:
        """
        Delete a record by primary key.

        Args:
            table_name: Name of the table
            pk_columns: Primary key column(s) and value(s)
            return_fields: Fields to return from deleted record (default: ["id"])
            timeout: Request timeout in seconds (default: 30)

        Returns:
            Deleted record data, or None if deletion failed
        """
        if return_fields is None:
            return_fields = ["id"]

        return_fields_str = " ".join(return_fields)

        # Build pk_columns argument string
        pk_signature = ", ".join([f"${k}: {self._infer_type(v)}" for k, v in pk_columns.items()])

        mutation = f"""
        mutation delete_{table_name}_by_pk({pk_signature}) {{
          delete_{table_name}_by_pk(
            {", ".join([f"{k}: ${k}" for k in pk_columns.keys()])}
          ) {{
            {return_fields_str}
          }}
        }}
        """

        variables = pk_columns
        result = self.execute_mutation(mutation, variables, timeout)

        if result:
            return result.get(f"delete_{table_name}_by_pk")
        return None

    def _infer_type(self, value: Any) -> str:
        """Infer GraphQL type from Python value."""
        if isinstance(value, bool):
            return "Boolean!"
        elif isinstance(value, int):
            return "Int!"
        elif isinstance(value, float):
            return "Float!"
        elif isinstance(value, str):
            return "String!"
        else:
            return "String!"  # Default fallback
