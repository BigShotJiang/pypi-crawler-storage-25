# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""
Table classification enricher for document processing.

Reusable enrichment component that classifies tables by content type using LLM.
Works across all document types (regulatory, research papers, guidelines, etc.).

This enables:
- Automated performance metrics extraction from tables
- Study design identification in research papers
- Technical specification discovery
- Predicate device extraction (regulatory documents)
- Comparative analysis table identification

Example:
    >>> from ashmatics_tools.enrichers import TableClassifier, TableCategory
    >>> classifier = TableClassifier()
    >>> tables = [
    ...     {'table_id': 'table_1', 'caption': 'Device Comparison', 'markdown': '...'},
    ...     {'table_id': 'table_2', 'caption': 'Performance Results', 'markdown': '...'}
    ... ]
    >>> classifications, tokens = await classifier.classify_tables(tables)
    >>> # [TableCategory.COMPARISON, TableCategory.PERFORMANCE_METRICS]
"""

import asyncio
from enum import Enum
from typing import Dict, List, Optional, Tuple

from ..llm import BaseLLMClient, LLMMessage, create_llm_client, get_config_class


class TableCategory(str, Enum):
    """
    Classification categories for tables in regulatory/research documents.

    These categories enable downstream extraction and analysis tasks:
    - COMPARISON: Extract comparative information (device vs predicate, treatment vs control)
    - PERFORMANCE_METRICS: Extract quantitative test results
    - STUDY_DESIGN: Identify clinical study parameters
    - TECHNICAL_SPECS: Extract device/system specifications
    - REGULATORY_INFO: Extract regulatory identifiers
    - DESCRIPTION: Extract device/product characteristics
    - DEMOGRAPHICS: Patient/sample demographics
    - OTHER: Uncategorized or mixed content
    """

    COMPARISON = "comparison"
    """Tables comparing entities (devices, treatments, methods)."""

    PERFORMANCE_METRICS = "performance_metrics"
    """Tables with quantitative test results, measurements, or metrics."""

    STUDY_DESIGN = "study_design"
    """Tables describing study methodology, patient cohorts, endpoints."""

    TECHNICAL_SPECS = "technical_specs"
    """Tables with specifications, materials, dimensions, etc."""

    REGULATORY_INFO = "regulatory_info"
    """Tables with regulatory identifiers, clearances, classifications."""

    DESCRIPTION = "description"
    """Tables describing features, components, or configuration."""

    DEMOGRAPHICS = "demographics"
    """Tables with patient/sample demographics and characteristics."""

    OTHER = "other"
    """Tables that don't fit other categories or have mixed content."""


class TableClassifier:
    """
    LLM-based table classifier for regulatory and research documents.

    Uses LLM to classify tables by content type, enabling downstream
    extraction tasks like metrics extraction and study design identification.

    Designed as reusable enricher that works across all document types.

    Usage:
        >>> classifier = TableClassifier(provider="azure_openai")
        >>> classifications, tokens = await classifier.classify_tables(tables)
        >>>
        >>> # Classify single table
        >>> category = await classifier.classify_single_table(table)
        >>> if category == TableCategory.PERFORMANCE_METRICS:
        ...     # Extract performance metrics from this table
        ...     metrics = extract_metrics_from_table(table)

    Attributes:
        llm_client: LLM client for table classification
        batch_size: Number of tables to classify in parallel
    """

    # Default classification prompt - can be customized per domain
    DEFAULT_CATEGORIES_DESCRIPTION = """
Categories:
- comparison: Tables comparing entities (subject vs predicate, treatment vs control, before vs after)
- performance_metrics: Tables with quantitative test results, measurements, or metrics
- study_design: Tables describing study methodology, patient cohorts, endpoints
- technical_specs: Tables with specifications, materials, dimensions
- regulatory_info: Tables with regulatory identifiers, clearances, classifications
- description: Tables describing features, components, configuration
- demographics: Tables with patient/sample demographics and characteristics
- other: Tables that don't fit other categories or have mixed content
"""

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure_openai",
        llm_config_overrides: Optional[Dict] = None,
        batch_size: int = 5,
        categories_description: Optional[str] = None,
    ):
        """
        Initialize table classifier.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client (default: azure_openai)
            llm_config_overrides: Optional config overrides (e.g., {'deployment_name': 'chat'})
            batch_size: Number of tables to classify concurrently (default: 5)
            categories_description: Optional custom categories description for the prompt
        """
        if llm_client:
            self.llm_client = llm_client
        else:
            # Create LLM client with provider-specific config
            config_class = get_config_class(provider)
            overrides = llm_config_overrides or {}
            llm_config = config_class(**overrides)  # Loads from environment variables
            self.llm_client = create_llm_client(provider, llm_config)

        self.batch_size = batch_size
        self.categories_description = categories_description or self.DEFAULT_CATEGORIES_DESCRIPTION

    async def classify_tables(
        self, tables: List[Dict]
    ) -> Tuple[List[TableCategory], int]:
        """
        Classify a list of tables by content type.

        Opens LLM client context once for efficiency when processing multiple tables.

        Args:
            tables: List of table dictionaries with keys:
                - table_id: Unique identifier
                - caption: Table caption/title (optional)
                - markdown: Table content in markdown format

        Returns:
            Tuple of (categories, total_tokens):
                - categories: List of TableCategory enums in same order as input
                - total_tokens: Total tokens used for all classifications

        Example:
            >>> tables = [
            ...     {'table_id': 'table_1', 'caption': 'Device Comparison', 'markdown': '...'},
            ...     {'table_id': 'table_2', 'caption': 'Test Results', 'markdown': '...'}
            ... ]
            >>> categories, tokens = await classifier.classify_tables(tables)
            >>> # ([TableCategory.COMPARISON, ...], 1234)
        """
        if not tables:
            return [], 0

        total_tokens = 0

        # Open LLM client context once for all classifications (more efficient)
        async with self.llm_client as client:
            # Process in batches to avoid rate limits
            results = []
            for i in range(0, len(tables), self.batch_size):
                batch = tables[i : i + self.batch_size]
                batch_results = await asyncio.gather(
                    *[self._classify_with_client(table, client) for table in batch]
                )
                # Unpack categories and tokens
                for category, tokens in batch_results:
                    results.append(category)
                    total_tokens += tokens

        return results, total_tokens

    async def classify_single_table(self, table: Dict) -> TableCategory:
        """
        Classify a single table by content type.

        Opens its own LLM client context for single-table use case.

        Args:
            table: Table dictionary with keys:
                - table_id: Unique identifier
                - caption: Table caption/title (optional)
                - markdown: Table content in markdown format

        Returns:
            TableCategory enum value

        Example:
            >>> table = {
            ...     'table_id': 'table_1',
            ...     'caption': 'Comparison to Predicate Devices',
            ...     'markdown': '| Feature | Subject Device | Predicate K123456 |\\n...'
            ... }
            >>> category = await classifier.classify_single_table(table)
            >>> # TableCategory.COMPARISON
        """
        # Open LLM client context for single classification
        async with self.llm_client as client:
            category, _ = await self._classify_with_client(table, client)
            return category

    async def _classify_with_client(
        self, table: Dict, client
    ) -> Tuple[TableCategory, int]:
        """
        Internal method: Classify table using an already-open LLM client.

        Args:
            table: Table dictionary
            client: Open LLM client instance

        Returns:
            Tuple of (category, tokens_used)
        """
        # Build input for LLM
        caption = table.get('caption', 'No caption')
        markdown = table.get('markdown', '')

        # Truncate very long tables to stay within token limits
        max_chars = 2000
        if len(markdown) > max_chars:
            markdown = markdown[:max_chars] + "\n... (truncated)"

        prompt = self._build_classification_prompt(caption, markdown)

        # Call LLM using ashmatics_tools client
        messages = [
            LLMMessage(
                role="system",
                content=(
                    "You are a specialized classifier for tables in regulatory "
                    "and research documents. Classify tables into specific "
                    "content categories to enable automated extraction."
                ),
            ),
            LLMMessage(role="user", content=prompt),
        ]

        # Call LLM with already-open client
        response = await client.complete_with_messages(
            messages=messages,
            temperature=0.0,  # Deterministic classification
        )

        # Parse response
        category_str = response.text.strip().lower()
        category = self._parse_category(category_str)

        # Extract token usage
        tokens_used = response.tokens.total_tokens if response.tokens else 0

        return category, tokens_used

    def _build_classification_prompt(
        self, caption: str, markdown: str
    ) -> str:
        """
        Build LLM prompt for table classification.

        Args:
            caption: Table caption/title
            markdown: Table content in markdown

        Returns:
            Formatted prompt string
        """
        return f"""Classify the following table into ONE category.

{self.categories_description}

Table Caption: {caption}

Table Content (markdown):
{markdown}

Respond with ONLY the category name (e.g., "comparison", "performance_metrics", etc.).
No explanation needed."""

    def _parse_category(self, category_str: str) -> TableCategory:
        """
        Parse LLM response to TableCategory enum.

        Args:
            category_str: Category string from LLM

        Returns:
            TableCategory enum value (defaults to OTHER if invalid)
        """
        # Normalize string
        category_str = category_str.strip().lower().replace(" ", "_")

        # Try exact match
        try:
            return TableCategory(category_str)
        except ValueError:
            pass

        # Try fuzzy match (handle LLM variations)
        if "predicate" in category_str or "comparison" in category_str or "compare" in category_str:
            return TableCategory.COMPARISON
        elif "performance" in category_str or "metrics" in category_str or "result" in category_str:
            return TableCategory.PERFORMANCE_METRICS
        elif "study" in category_str or "design" in category_str or "method" in category_str:
            return TableCategory.STUDY_DESIGN
        elif "spec" in category_str or "technical" in category_str:
            return TableCategory.TECHNICAL_SPECS
        elif "regulatory" in category_str or "clearance" in category_str:
            return TableCategory.REGULATORY_INFO
        elif "description" in category_str or "feature" in category_str:
            return TableCategory.DESCRIPTION
        elif "demographic" in category_str or "population" in category_str or "patient" in category_str:
            return TableCategory.DEMOGRAPHICS
        else:
            return TableCategory.OTHER

    async def classify_with_confidence(
        self, table: Dict
    ) -> Tuple[TableCategory, float]:
        """
        Classify table and return confidence score.

        Args:
            table: Table dictionary

        Returns:
            Tuple of (category, confidence_score)
            where confidence_score is 0.0-1.0

        Example:
            >>> category, confidence = await classifier.classify_with_confidence(table)
            >>> if confidence > 0.8:
            ...     # High confidence classification
            ...     process_table(table, category)

        Note:
            This requires LLM to output structured JSON with confidence.
            Not implemented in initial version - returns (category, 1.0).
        """
        # TODO Phase 2B: Add confidence scoring
        # For now, return deterministic classification with max confidence
        category = await self.classify_single_table(table)
        return (category, 1.0)
