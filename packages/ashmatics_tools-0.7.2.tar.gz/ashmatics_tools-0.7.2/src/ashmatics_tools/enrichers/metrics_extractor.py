# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""
Performance metrics extractor for document processing.

Extracts structured performance/validation data from regulatory documents,
research papers, and clinical studies. Provides base functionality that
can be extended with domain-specific knowledge.

Extracts:
- Performance metrics (sensitivity, specificity, AUC, DICE, accuracy, etc.)
- Validation study characteristics
- Statistical measures (confidence intervals, p-values)
- Stratified results
- Acceptance criteria

Example:
    >>> from ashmatics_tools.enrichers import MetricsExtractor
    >>> extractor = MetricsExtractor()
    >>> metrics = await extractor.extract_from_tables(performance_tables)
    >>> for metric in metrics.performance_metrics:
    ...     print(f"{metric['name']}: {metric['value']}")
"""

import json
import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..llm import BaseLLMClient, LLMMessage, create_llm_client, get_config_class

logger = logging.getLogger(__name__)


@dataclass
class ExtractedMetric:
    """
    A single extracted performance metric.

    Attributes:
        metric_name: Exact name from document
        metric_type: Standardized type (sensitivity, specificity, auc, etc.)
        value: Numeric value (as proportion 0-1 for percentages)
        unit: Unit if applicable (e.g., "seconds", "mm")
        ci_lower: Lower bound of 95% CI (as proportion)
        ci_upper: Upper bound of 95% CI (as proportion)
        p_value: p-value if present
        sample_size: N or sample size
        stratification: Dict of stratification dimensions
        source_table: Table ID if from a table
        source_section: Section name if from text
    """

    metric_name: str
    metric_type: str
    value: float
    unit: Optional[str] = None
    ci_lower: Optional[float] = None
    ci_upper: Optional[float] = None
    p_value: Optional[float] = None
    sample_size: Optional[int] = None
    stratification: Optional[Dict[str, str]] = None
    source_table: Optional[str] = None
    source_section: Optional[str] = None


@dataclass
class ExtractedStudy:
    """
    An extracted validation/performance study.

    Attributes:
        study_name: Name/title of the study
        study_type: Type (standalone, reader_study, pivotal_study, etc.)
        study_description: Brief description
        prospective: True if prospective study
        blinding: Blinding type (single_blind, double_blind, unblinded)
        num_readers: Number of readers (for reader studies)
        num_cases: Number of cases/subjects
        num_sites: Number of clinical sites
        data_source: Description of data sources
        acceptance_criteria: Performance goals/thresholds
        acceptance_met: Whether criteria were met
    """

    study_name: Optional[str] = None
    study_type: str = "unknown"
    study_description: Optional[str] = None
    prospective: Optional[bool] = None
    blinding: Optional[str] = None
    num_readers: Optional[int] = None
    num_cases: Optional[int] = None
    num_sites: Optional[int] = None
    data_source: Optional[str] = None
    acceptance_criteria: Optional[str] = None
    acceptance_met: Optional[bool] = None


@dataclass
class MetricsExtractionResult:
    """
    Result of metrics extraction from a document.

    Attributes:
        has_metrics: Whether any metrics were found
        validation_studies: List of extracted studies
        performance_metrics: List of extracted metrics
        comparison_to_baseline: Description of comparison result
        baseline_metrics: Metrics from baseline/predicate/control
        extraction_confidence: Confidence score (0-100)
        source_tables: Table IDs used for extraction
        token_usage: Token usage for LLM calls
    """

    has_metrics: bool = False
    validation_studies: List[ExtractedStudy] = field(default_factory=list)
    performance_metrics: List[ExtractedMetric] = field(default_factory=list)
    comparison_to_baseline: Optional[str] = None
    baseline_metrics: List[ExtractedMetric] = field(default_factory=list)
    extraction_confidence: float = 0.0
    source_tables: List[str] = field(default_factory=list)
    token_usage: Optional[Dict[str, int]] = None


class DomainKnowledgeProvider(ABC):
    """
    Abstract base class for domain-specific knowledge providers.

    Subclass this to provide domain-specific context for metrics extraction.
    For example, FDA regulatory documents vs research papers vs clinical guidelines.

    Example:
        >>> class FDADomainKnowledge(DomainKnowledgeProvider):
        ...     def format_context_for_llm(self, product_code, submission_type):
        ...         return f"This is an FDA {submission_type} for product code {product_code}..."
    """

    @abstractmethod
    def format_context_for_llm(
        self,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
    ) -> str:
        """Format domain-specific context for LLM prompt."""
        pass

    @abstractmethod
    def get_confidence_adjustment(
        self,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
    ) -> int:
        """Get confidence adjustment based on domain expectations."""
        pass

    @abstractmethod
    def get_expected_metrics(
        self,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
    ) -> List[str]:
        """Get list of expected metric types for this domain/document."""
        pass

    @abstractmethod
    def is_missing_notable(
        self,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
    ) -> bool:
        """Whether missing metrics is notable for this domain/document."""
        pass


class MetricsExtractor:
    """
    LLM-based extractor for performance/validation metrics.

    Extracts structured performance information from tables and document text.
    Can be extended with domain-specific knowledge providers.

    Usage:
        >>> extractor = MetricsExtractor(provider="azure_openai")
        >>> result = await extractor.extract_from_tables(tables)
        >>> for metric in result.performance_metrics:
        ...     print(f"{metric.metric_name}: {metric.value}")

        # With domain knowledge
        >>> from my_domain import MyDomainKnowledge
        >>> extractor = MetricsExtractor(domain_knowledge=MyDomainKnowledge())
        >>> result = await extractor.extract_from_tables(
        ...     tables,
        ...     identifier="POK",
        ...     document_type="510k"
        ... )
    """

    # Standard metric types
    STANDARD_METRIC_TYPES = [
        "sensitivity",
        "specificity",
        "auc",
        "dice",
        "accuracy",
        "ppv",
        "npv",
        "f1_score",
        "precision",
        "recall",
        "hausdorff_distance",
        "time_to_detection",
        "other",
    ]

    # Study types
    STUDY_TYPES = [
        "standalone",
        "clinical_validation",
        "reader_study",
        "pivotal_study",
        "pilot_study",
        "retrospective",
        "prospective",
        "unknown",
    ]

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure_openai",
        llm_config_overrides: Optional[Dict] = None,
        domain_knowledge: Optional[DomainKnowledgeProvider] = None,
    ):
        """
        Initialize metrics extractor.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client (default: azure_openai)
            llm_config_overrides: Optional config overrides
            domain_knowledge: Optional domain-specific knowledge provider
        """
        if llm_client:
            self.llm_client = llm_client
        else:
            config_class = get_config_class(provider)
            overrides = llm_config_overrides or {}
            llm_config = config_class(**overrides)
            self.llm_client = create_llm_client(provider, llm_config)

        self.domain_knowledge = domain_knowledge

    async def extract_from_tables(
        self,
        tables: List[Dict],
        document_text: Optional[str] = None,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
        client=None,
        debug: bool = False,
    ) -> MetricsExtractionResult:
        """
        Extract performance metrics from tables and optional document text.

        Args:
            tables: Tables with keys: table_id, caption, markdown
            document_text: Optional additional context text
            identifier: Domain-specific identifier (e.g., product code)
            document_type: Document type (e.g., "510k", "research_paper")
            client: Optional open LLM client for batch processing
            debug: Print debug information

        Returns:
            MetricsExtractionResult with extracted data
        """
        # Build domain context if available
        domain_context = ""
        confidence_adjustment = 0
        missing_is_notable = False

        if self.domain_knowledge and (identifier or document_type):
            domain_context = self.domain_knowledge.format_context_for_llm(
                identifier, document_type
            )
            confidence_adjustment = self.domain_knowledge.get_confidence_adjustment(
                identifier, document_type
            )
            missing_is_notable = self.domain_knowledge.is_missing_notable(
                identifier, document_type
            )

            if debug:
                logger.info(f"Domain context: identifier={identifier}, type={document_type}")
                logger.info(f"Confidence adjustment: {confidence_adjustment:+d}")

        # Combine table content
        combined_content = self._combine_table_content(tables)

        # Add document text if provided
        if document_text:
            relevant_text = self._extract_relevant_context(document_text)
            if relevant_text:
                combined_content = f"{combined_content}\n\n## Additional Context:\n{relevant_text}"

        if debug:
            logger.info(f"Combined content length: {len(combined_content)} chars")

        # Prepend domain context
        content_for_llm = combined_content
        if domain_context:
            content_for_llm = f"{domain_context}\n\n{combined_content}"

        # Run extraction
        async def run_extraction(content: str, llm_client) -> Optional[Dict]:
            if llm_client:
                return await self._llm_extract_metrics(content, llm_client)
            else:
                async with self.llm_client as new_client:
                    return await self._llm_extract_metrics(content, new_client)

        extracted_data = await run_extraction(content_for_llm, client)

        if not extracted_data:
            if missing_is_notable:
                return MetricsExtractionResult(
                    has_metrics=False,
                    extraction_confidence=0.0,
                    source_tables=[t.get("table_id", "unknown") for t in tables],
                )
            return MetricsExtractionResult()

        # Apply confidence adjustment
        if confidence_adjustment and "extraction_confidence" in extracted_data:
            original_conf = extracted_data["extraction_confidence"]
            extracted_data["extraction_confidence"] = min(
                100, max(0, original_conf + confidence_adjustment)
            )

        # Build result object
        return self._build_result(extracted_data, tables)

    async def extract_from_text(
        self,
        text: str,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
        client=None,
        debug: bool = False,
    ) -> MetricsExtractionResult:
        """
        Extract performance metrics from free text.

        Convenience method for text-only extraction.

        Args:
            text: Document text content
            identifier: Domain-specific identifier
            document_type: Document type
            client: Optional open LLM client
            debug: Print debug information

        Returns:
            MetricsExtractionResult with extracted data
        """
        return await self.extract_from_tables(
            tables=[],
            document_text=text,
            identifier=identifier,
            document_type=document_type,
            client=client,
            debug=debug,
        )

    def _combine_table_content(self, tables: List[Dict]) -> str:
        """Combine table captions and markdown content."""
        if not tables:
            return ""

        combined = []
        for table in tables:
            table_id = table.get("table_id", "unknown")
            caption = table.get("caption", "No caption")
            markdown = table.get("markdown", "")

            if len(markdown) > 3000:
                markdown = markdown[:3000] + "\n... (truncated)"

            combined.append(f"## {table_id}: {caption}\n{markdown}")

        return "\n\n".join(combined)

    def _extract_relevant_context(self, document_text: str) -> str:
        """Extract relevant context from document text."""
        # Performance-specific phrases
        performance_phrases = [
            "performance", "validation", "sensitivity", "specificity",
            "auc", "auroc", "roc", "dice", "accuracy", "ppv", "npv",
            "confidence interval", "95% ci", "pivotal study", "reader study",
            "mrmc", "multi-reader", "standalone", "clinical study",
            "performance goal", "acceptance criteria", "p-value", "p value",
        ]

        lines = document_text.split("\n")
        matched_indices = set()

        for i, line in enumerate(lines):
            line_lower = line.lower()
            if any(phrase in line_lower for phrase in performance_phrases):
                start = max(0, i - 3)
                end = min(len(lines), i + 4)
                for j in range(start, end):
                    matched_indices.add(j)

        relevant_lines = [lines[i].strip() for i in sorted(matched_indices) if lines[i].strip()]
        relevant_text = "\n".join(relevant_lines)

        if len(relevant_text) > 8000:
            relevant_text = relevant_text[:8000] + "\n... (truncated)"

        return relevant_text

    async def _llm_extract_metrics(self, content: str, client) -> Optional[Dict]:
        """Call LLM to extract structured metrics data."""
        prompt = self._build_extraction_prompt(content)

        messages = [
            LLMMessage(
                role="system",
                content=(
                    "You are an expert at extracting performance and validation data "
                    "from scientific and regulatory documents. Extract structured information "
                    "about validation studies, performance metrics, and statistical measures. "
                    "Be precise and only extract information explicitly present. "
                    "Convert percentages to proportions (e.g., 90.6% → 0.906)."
                ),
            ),
            LLMMessage(role="user", content=prompt),
        ]

        try:
            response = await client.complete_with_messages(
                messages=messages,
                temperature=0.0,
                response_format={"type": "json_object"},
                max_tokens=4096,
            )

            token_usage = None
            if hasattr(response, 'tokens') and response.tokens:
                token_usage = {
                    'prompt_tokens': response.tokens.prompt_tokens,
                    'completion_tokens': response.tokens.completion_tokens,
                    'total_tokens': response.tokens.total_tokens,
                }

            result = json.loads(response.text)
            if token_usage:
                result['_token_usage'] = token_usage
            return result

        except Exception as e:
            logger.error(f"Error extracting metrics: {e}")
            return None

    def _build_extraction_prompt(self, content: str) -> str:
        """Build LLM prompt for metrics extraction."""
        return f"""Extract performance/validation data from the following document content.

Content (tables and text):
{content}

**INSTRUCTIONS:**

## STEP 1: IDENTIFY VALIDATION STUDIES

Look for distinct validation studies:
- **Standalone Testing**: Device/algorithm performance with ground truth
- **Reader Study / MRMC**: Multi-reader multi-case comparing aided vs unaided performance
- **Pivotal Study**: Definitive validation study
- **Clinical Validation**: Clinical evaluation study
- **Retrospective/Prospective Study**: Historical or prospective data analysis

For each study, extract:
- study_name: Name/title
- study_type: One of [standalone, clinical_validation, reader_study, pivotal_study, pilot_study, retrospective, prospective, unknown]
- prospective: true/false/null
- blinding: "single_blind", "double_blind", "unblinded", or null
- num_readers: Number of readers (for reader studies)
- num_cases: Number of cases/subjects
- num_sites: Number of clinical sites
- acceptance_criteria: Performance goals/thresholds
- acceptance_met: Whether criteria were met

## STEP 2: EXTRACT PERFORMANCE METRICS

For each metric (sensitivity, specificity, AUC, DICE, accuracy, etc.):
- metric_name: Exact name from document
- metric_type: Standardized type [sensitivity, specificity, auc, dice, accuracy, ppv, npv, f1_score, precision, recall, other]
- value: Numeric value as PROPORTION (0-1), convert percentages
- unit: Unit if applicable
- ci_lower: Lower bound of 95% CI (as proportion)
- ci_upper: Upper bound of 95% CI (as proportion)
- p_value: p-value if present
- sample_size: N or sample size
- stratification: Stratification dimensions
- source_table: Table ID if from a table

## STEP 3: EXTRACT COMPARISON DATA

If comparing to baseline/predicate/control:
- comparison_to_baseline: Description of comparison result
- baseline_metrics: Metrics from the baseline

Return JSON:
{{
  "has_metrics": true/false,
  "validation_studies": [...],
  "performance_metrics": [...],
  "comparison_to_baseline": "<string or null>",
  "baseline_metrics": [...],
  "extraction_confidence": <float 0-100>,
  "source_tables": ["<table_id>", ...]
}}

**Decision Rules:**
- has_metrics=true if ANY performance metrics or studies found
- Convert ALL percentages to proportions (0-1 range)
- extraction_confidence < 30 if minimal/ambiguous
- extraction_confidence 30-70 if moderate detail
- extraction_confidence > 70 if comprehensive with CIs
"""

    def _build_result(
        self,
        extracted_data: Dict,
        source_tables: List[Dict],
    ) -> MetricsExtractionResult:
        """Build MetricsExtractionResult from extracted data."""
        if not extracted_data.get("has_metrics", False):
            return MetricsExtractionResult()

        # Build studies
        studies = []
        for study_data in extracted_data.get("validation_studies", []):
            studies.append(ExtractedStudy(
                study_name=study_data.get("study_name"),
                study_type=study_data.get("study_type", "unknown"),
                study_description=study_data.get("study_description"),
                prospective=study_data.get("prospective"),
                blinding=study_data.get("blinding"),
                num_readers=study_data.get("num_readers"),
                num_cases=study_data.get("num_cases"),
                num_sites=study_data.get("num_sites"),
                data_source=study_data.get("data_source"),
                acceptance_criteria=study_data.get("acceptance_criteria"),
                acceptance_met=study_data.get("acceptance_met"),
            ))

        # Build metrics
        metrics = []
        for metric_data in extracted_data.get("performance_metrics", []):
            if "value" not in metric_data:
                continue
            metrics.append(ExtractedMetric(
                metric_name=metric_data.get("metric_name", "unknown"),
                metric_type=metric_data.get("metric_type", "other"),
                value=float(metric_data["value"]),
                unit=metric_data.get("unit"),
                ci_lower=metric_data.get("ci_lower"),
                ci_upper=metric_data.get("ci_upper"),
                p_value=self._parse_p_value(metric_data.get("p_value")),
                sample_size=metric_data.get("sample_size"),
                stratification=metric_data.get("stratification"),
                source_table=metric_data.get("source_table"),
                source_section=metric_data.get("source_section"),
            ))

        # Build baseline metrics
        baseline_metrics = []
        for metric_data in extracted_data.get("baseline_metrics", []):
            if "value" not in metric_data:
                continue
            baseline_metrics.append(ExtractedMetric(
                metric_name=metric_data.get("metric_name", "unknown"),
                metric_type=metric_data.get("metric_type", "other"),
                value=float(metric_data["value"]),
                unit=metric_data.get("unit"),
                ci_lower=metric_data.get("ci_lower"),
                ci_upper=metric_data.get("ci_upper"),
            ))

        return MetricsExtractionResult(
            has_metrics=True,
            validation_studies=studies,
            performance_metrics=metrics,
            comparison_to_baseline=extracted_data.get("comparison_to_baseline"),
            baseline_metrics=baseline_metrics,
            extraction_confidence=extracted_data.get("extraction_confidence", 0.0),
            source_tables=extracted_data.get(
                "source_tables",
                [t.get("table_id", "unknown") for t in source_tables]
            ),
            token_usage=extracted_data.get("_token_usage"),
        )

    def _parse_p_value(self, p_value_raw: Any) -> Optional[float]:
        """Parse p-value from various formats."""
        if p_value_raw is None:
            return None
        if isinstance(p_value_raw, (int, float)):
            return float(p_value_raw)
        if isinstance(p_value_raw, str):
            cleaned = p_value_raw.lower().strip().replace("p", "").replace("<", "").replace(">", "").strip()
            try:
                return float(cleaned)
            except ValueError:
                return None
        return None
