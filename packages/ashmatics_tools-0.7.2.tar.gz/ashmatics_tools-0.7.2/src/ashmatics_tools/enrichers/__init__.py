# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""Document enrichers for post-parsing content analysis.

This module provides reusable enrichment components that work across all document types
(regulatory submissions, research papers, clinical guidelines, etc.).

Enrichers operate on parsed documents to extract structured insights:

- **Table Classification**: Categorize tables by content type (metrics, study design, etc.)
- **Table Consolidation**: Merge multi-page tables split by PDF parsers
- **Metrics Extraction**: Extract quantitative performance/validation data
- **Training Data Extraction**: Extract AI/ML training dataset characteristics

Example - Table Classification:
    >>> from ashmatics_tools.enrichers import TableClassifier, TableCategory
    >>> classifier = TableClassifier(provider="azure_openai")
    >>> categories, tokens = await classifier.classify_tables(parsed_doc.tables)
    >>> for table, category in zip(parsed_doc.tables, categories):
    ...     print(f"{table.caption}: {category.value}")

Example - Table Consolidation:
    >>> from ashmatics_tools.enrichers import TableConsolidator
    >>> consolidator = TableConsolidator()
    >>> consolidated = await consolidator.consolidate_tables(parsed_doc.tables)

Example - Metrics Extraction:
    >>> from ashmatics_tools.enrichers import MetricsExtractor
    >>> extractor = MetricsExtractor()
    >>> result = await extractor.extract_from_tables(performance_tables)
    >>> for metric in result.performance_metrics:
    ...     print(f"{metric.metric_name}: {metric.value}")

Example - Training Data Extraction:
    >>> from ashmatics_tools.enrichers import TrainingDataExtractor
    >>> extractor = TrainingDataExtractor()
    >>> result = await extractor.extract_from_text(document_text)
    >>> if result.has_training_data:
    ...     print(f"Dataset size: {result.dataset_characteristics.dataset_size}")
"""

from .metrics_extractor import (
    DomainKnowledgeProvider,
    ExtractedMetric,
    ExtractedStudy,
    MetricsExtractionResult,
    MetricsExtractor,
)
from .table_classifier import TableCategory, TableClassifier
from .table_consolidator import ConsolidatedTable, TableCandidate, TableConsolidator
from .training_data_extractor import (
    DatasetCharacteristics,
    PatientDemographics,
    TrainingDataExtractor,
    TrainingDataResult,
)

__all__ = [
    # Table Classification
    "TableClassifier",
    "TableCategory",
    # Table Consolidation
    "TableConsolidator",
    "TableCandidate",
    "ConsolidatedTable",
    # Metrics Extraction
    "MetricsExtractor",
    "MetricsExtractionResult",
    "ExtractedMetric",
    "ExtractedStudy",
    "DomainKnowledgeProvider",
    # Training Data Extraction
    "TrainingDataExtractor",
    "TrainingDataResult",
    "DatasetCharacteristics",
    "PatientDemographics",
]
