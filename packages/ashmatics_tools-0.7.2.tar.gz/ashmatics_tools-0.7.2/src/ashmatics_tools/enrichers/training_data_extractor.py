# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""
Training data characteristics extractor for AI/ML documents.

Extracts structured training data information from documents describing
AI/ML systems. Critical for assessing model generalizability, potential bias,
and applicability to specific populations.

Extracts:
- Training dataset size
- Patient/sample demographics
- Data sources (institutions, public datasets)
- Inclusion/exclusion criteria
- Ground truth/reference standard methodology

Example:
    >>> from ashmatics_tools.enrichers import TrainingDataExtractor
    >>> extractor = TrainingDataExtractor()
    >>> result = await extractor.extract_from_text(document_text)
    >>> if result.has_training_data:
    ...     print(f"Dataset size: {result.dataset_characteristics.dataset_size}")
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..llm import BaseLLMClient, LLMMessage, create_llm_client, get_config_class
from .metrics_extractor import DomainKnowledgeProvider

logger = logging.getLogger(__name__)


@dataclass
class DatasetCharacteristics:
    """
    Characteristics of a training dataset.

    Attributes:
        dataset_size: Number of samples/images/patients
        data_source: Description of data sources
        multi_site: Whether data from multiple sites
        num_sites: Number of sites
        imaging_modality: Imaging modality if applicable
        ground_truth_method: How ground truth was established
    """

    dataset_size: Optional[int] = None
    data_source: Optional[str] = None
    multi_site: Optional[bool] = None
    num_sites: Optional[int] = None
    imaging_modality: Optional[str] = None
    ground_truth_method: Optional[str] = None


@dataclass
class PatientDemographics:
    """
    Patient/sample demographics.

    Attributes:
        age_range: Age range description
        gender_distribution: Dict mapping gender to proportion
        race_ethnicity_distribution: Dict mapping race/ethnicity to proportion
    """

    age_range: Optional[str] = None
    gender_distribution: Optional[Dict[str, float]] = None
    race_ethnicity_distribution: Optional[Dict[str, float]] = None


@dataclass
class TrainingDataResult:
    """
    Result of training data extraction.

    Attributes:
        has_training_data: Whether training data info was found
        dataset_characteristics: Dataset size and source info
        patient_demographics: Demographics if available
        inclusion_criteria: Inclusion criteria
        exclusion_criteria: Exclusion criteria
        disease_characteristics: Disease/condition info
        data_collection_period: Data collection timeframe
        extraction_confidence: Confidence score (0-100)
        source_tables: Table IDs used for extraction
        token_usage: Token usage for LLM calls
    """

    has_training_data: bool = False
    dataset_characteristics: Optional[DatasetCharacteristics] = None
    patient_demographics: Optional[PatientDemographics] = None
    inclusion_criteria: Optional[str] = None
    exclusion_criteria: Optional[str] = None
    disease_characteristics: Optional[str] = None
    data_collection_period: Optional[str] = None
    extraction_confidence: float = 0.0
    source_tables: List[str] = field(default_factory=list)
    token_usage: Optional[Dict[str, int]] = None
    # Flag for notable absence
    notable_missing: bool = False


class TrainingDataExtractor:
    """
    LLM-based extractor for AI/ML training data characteristics.

    Extracts structured training data information from study design tables
    and document sections. Critical for assessing model generalizability.

    **IMPORTANT**: This extractor distinguishes between TRAINING data
    (used to build the model) and VALIDATION/TEST data (used to evaluate it).
    Only training data is extracted.

    Usage:
        >>> extractor = TrainingDataExtractor(provider="azure_openai")
        >>> result = await extractor.extract_from_text(document_text)
        >>> if result.has_training_data:
        ...     print(f"Dataset: {result.dataset_characteristics.dataset_size}")

        # With domain knowledge
        >>> extractor = TrainingDataExtractor(domain_knowledge=MyDomainKnowledge())
        >>> result = await extractor.extract_from_tables(
        ...     tables,
        ...     identifier="POK",
        ...     document_type="510k"
        ... )
    """

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure_openai",
        llm_config_overrides: Optional[Dict] = None,
        domain_knowledge: Optional[DomainKnowledgeProvider] = None,
    ):
        """
        Initialize training data extractor.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client
            llm_config_overrides: Optional config overrides
            domain_knowledge: Optional domain-specific knowledge provider
        """
        if llm_client:
            self.llm_client = llm_client
        else:
            config_class = get_config_class(provider)
            overrides = llm_config_overrides or {}
            llm_config = config_class(**overrides)
            self.llm_client = create_llm_client(provider, llm_config)

        self.domain_knowledge = domain_knowledge

    async def extract_from_tables(
        self,
        tables: List[Dict],
        document_text: Optional[str] = None,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
        client=None,
        debug: bool = False,
    ) -> TrainingDataResult:
        """
        Extract training data characteristics from tables and text.

        Args:
            tables: Tables with keys: table_id, caption, markdown
            document_text: Optional additional context text
            identifier: Domain-specific identifier
            document_type: Document type
            client: Optional open LLM client
            debug: Print debug information

        Returns:
            TrainingDataResult with extracted data
        """
        # Build domain context if available
        domain_context = ""
        confidence_adjustment = 0
        missing_is_notable = False

        if self.domain_knowledge and (identifier or document_type):
            domain_context = self.domain_knowledge.format_context_for_llm(
                identifier, document_type
            )
            confidence_adjustment = self.domain_knowledge.get_confidence_adjustment(
                identifier, document_type
            )
            missing_is_notable = self.domain_knowledge.is_missing_notable(
                identifier, document_type
            )

            if debug:
                logger.info(f"Domain context: identifier={identifier}, type={document_type}")
                logger.info(f"Confidence adjustment: {confidence_adjustment:+d}")

        # Combine table content
        combined_content = self._combine_table_content(tables)

        # Add relevant document text
        if document_text:
            relevant_text = self._extract_relevant_context(document_text)
            if relevant_text:
                combined_content = f"{combined_content}\n\n## Additional Context:\n{relevant_text}"

        if not combined_content.strip():
            if missing_is_notable:
                return TrainingDataResult(
                    has_training_data=False,
                    extraction_confidence=0.0,
                    notable_missing=True,
                )
            return TrainingDataResult()

        if debug:
            logger.info(f"Combined content length: {len(combined_content)} chars")

        # Prepend domain context
        content_for_llm = combined_content
        if domain_context:
            content_for_llm = f"{domain_context}\n\n{combined_content}"

        # Run extraction
        async def run_extraction(content: str, llm_client) -> Optional[Dict]:
            if llm_client:
                return await self._llm_extract_training_data(content, llm_client)
            else:
                async with self.llm_client as new_client:
                    return await self._llm_extract_training_data(content, new_client)

        extracted_data = await run_extraction(content_for_llm, client)

        if not extracted_data or not extracted_data.get("has_training_data", False):
            if missing_is_notable:
                return TrainingDataResult(
                    has_training_data=False,
                    extraction_confidence=0.0,
                    notable_missing=True,
                )
            return TrainingDataResult()

        # Apply confidence adjustment
        if confidence_adjustment and "extraction_confidence" in extracted_data:
            original_conf = extracted_data["extraction_confidence"]
            extracted_data["extraction_confidence"] = min(
                100, max(0, original_conf + confidence_adjustment)
            )

        return self._build_result(extracted_data, tables)

    async def extract_from_text(
        self,
        text: str,
        identifier: Optional[str] = None,
        document_type: Optional[str] = None,
        client=None,
        debug: bool = False,
    ) -> TrainingDataResult:
        """
        Extract training data from free text.

        Convenience method for text-only extraction.

        Args:
            text: Document text content
            identifier: Domain-specific identifier
            document_type: Document type
            client: Optional open LLM client
            debug: Print debug information

        Returns:
            TrainingDataResult with extracted data
        """
        return await self.extract_from_tables(
            tables=[],
            document_text=text,
            identifier=identifier,
            document_type=document_type,
            client=client,
            debug=debug,
        )

    def _combine_table_content(self, tables: List[Dict]) -> str:
        """Combine table captions and markdown content."""
        if not tables:
            return ""

        combined = []
        for table in tables:
            table_id = table.get("table_id", "unknown")
            caption = table.get("caption", "No caption")
            markdown = table.get("markdown", "")

            if len(markdown) > 2000:
                markdown = markdown[:2000] + "\n... (truncated)"

            combined.append(f"## {table_id}: {caption}\n{markdown}")

        return "\n\n".join(combined)

    def _extract_relevant_context(self, document_text: str) -> str:
        """Extract relevant ML training context from document text."""
        # ML-specific training phrases
        ml_training_phrases = [
            "training dataset",
            "training data",
            "trained on",
            "trained using",
            "algorithm trained",
            "model training",
            "training set",
            "labeled images",
            "tagged images",
            "algorithm development",
            "model development",
            "development dataset",
            "learning dataset",
            "deep learning",
            "machine learning",
            "neural network",
            "ground truth",
            "reference standard",
            "labeled by",
            "annotated by",
        ]

        # Lines to exclude (validation data indicators)
        exclude_patterns = [
            "validation study",
            "pivotal study",
            "retrospective study",
            "performance evaluation",
            "test dataset",
            "trained radiologist",  # Human training, not ML
            "trained clinician",
        ]

        lines = document_text.split('\n')
        matched_indices = set()

        for i, line in enumerate(lines):
            line_lower = line.lower()

            # Skip lines with exclude patterns
            if any(pattern in line_lower for pattern in exclude_patterns):
                continue

            # Include lines with ML training phrases
            if any(phrase in line_lower for phrase in ml_training_phrases):
                start = max(0, i - 2)
                end = min(len(lines), i + 3)
                for j in range(start, end):
                    matched_indices.add(j)

        relevant_lines = [lines[i].strip() for i in sorted(matched_indices) if lines[i].strip()]
        relevant_text = '\n'.join(relevant_lines)

        if len(relevant_text) > 4000:
            relevant_text = relevant_text[:4000] + "\n... (truncated)"

        return relevant_text

    async def _llm_extract_training_data(self, content: str, client) -> Optional[Dict]:
        """Call LLM to extract structured training data."""
        prompt = self._build_extraction_prompt(content)

        messages = [
            LLMMessage(
                role="system",
                content=(
                    "You are an expert at extracting AI/ML training data characteristics "
                    "from scientific and regulatory documents. Extract structured information "
                    "about training datasets, patient demographics, and study design. "
                    "Be precise and only extract information explicitly present. "
                    "IMPORTANT: Distinguish between TRAINING data and VALIDATION/TEST data."
                ),
            ),
            LLMMessage(role="user", content=prompt),
        ]

        try:
            response = await client.complete_with_messages(
                messages=messages,
                temperature=0.0,
                response_format={"type": "json_object"},
            )

            token_usage = None
            if hasattr(response, 'tokens') and response.tokens:
                token_usage = {
                    'prompt_tokens': response.tokens.prompt_tokens,
                    'completion_tokens': response.tokens.completion_tokens,
                    'total_tokens': response.tokens.total_tokens,
                }

            result = json.loads(response.text)
            if token_usage:
                result['_token_usage'] = token_usage
            return result

        except Exception as e:
            logger.error(f"Error extracting training data: {e}")
            return None

    def _build_extraction_prompt(self, content: str) -> str:
        """Build LLM prompt for training data extraction."""
        return f"""Extract ONLY AI/ML TRAINING data characteristics from the following content.

Content (tables and text):
{content}

**CRITICAL INSTRUCTIONS:**

## DISTINGUISH TRAINING vs VALIDATION DATA

Documents describe TWO types of datasets - you MUST distinguish them:

**TRAINING DATA** (what we want):
- Used to BUILD/DEVELOP the algorithm BEFORE testing
- Keywords: "training dataset", "algorithm development", "trained on", "labeled images"
- Often minimally described

**VALIDATION/TEST DATA** (DO NOT EXTRACT):
- Used to EVALUATE/TEST the algorithm AFTER it was built
- Keywords: "pivotal study", "retrospective study", "validation", "performance evaluation"
- Usually richly described with demographics, sample sizes, sites

## COMMON TRAPS TO AVOID

1. "Retrospective study with X cases from Y sites" → VALIDATION (NOT training)
2. Demographics tables with age/gender → Usually VALIDATION
3. "Cases distinct from training" confirms data is VALIDATION
4. Performance metrics (sensitivity, AUC) → Always from VALIDATION

## WHAT TO EXTRACT (TRAINING ONLY)

Only extract if you find EXPLICIT training data descriptions like:
- "The algorithm was trained on [X] labeled images"
- "Training dataset consisted of [X] samples from [source]"

Return JSON:
{{
  "has_training_data": true/false,
  "training_data_description": "<brief quote if found, or null>",
  "dataset_characteristics": {{
    "dataset_size": <integer or null>,
    "data_source": "<string or null>",
    "multi_site": <boolean or null>,
    "num_sites": <integer or null>,
    "imaging_modality": "<string or null>",
    "ground_truth_method": "<string or null>"
  }},
  "patient_demographics": {{
    "age_range": "<string or null>",
    "gender_distribution": {{"male": <float 0-1>, "female": <float 0-1>}} or null,
    "race_ethnicity_distribution": {{...}} or null
  }},
  "inclusion_criteria": "<string or null>",
  "exclusion_criteria": "<string or null>",
  "disease_characteristics": "<string or null>",
  "data_collection_period": "<string or null>",
  "extraction_confidence": <float 0-100>,
  "reasoning": "<explain why this is training vs validation data>"
}}

**Decision Rules:**
- has_training_data=false if only validation/test data described
- Use null for ALL fields where training info not explicitly present
- extraction_confidence < 30 if only mentioned generically
- extraction_confidence > 70 only if explicit size AND source provided
"""

    def _build_result(
        self,
        extracted_data: Dict,
        source_tables: List[Dict],
    ) -> TrainingDataResult:
        """Build TrainingDataResult from extracted data."""
        if not extracted_data.get("has_training_data", False):
            return TrainingDataResult()

        # Build dataset characteristics
        dataset_char_data = extracted_data.get("dataset_characteristics", {})
        dataset_characteristics = None
        if any(dataset_char_data.values()):
            dataset_characteristics = DatasetCharacteristics(
                dataset_size=dataset_char_data.get("dataset_size"),
                data_source=dataset_char_data.get("data_source"),
                multi_site=dataset_char_data.get("multi_site"),
                num_sites=dataset_char_data.get("num_sites"),
                imaging_modality=dataset_char_data.get("imaging_modality"),
                ground_truth_method=dataset_char_data.get("ground_truth_method"),
            )

        # Build demographics
        demo_data = extracted_data.get("patient_demographics", {})
        patient_demographics = None
        if any(v for v in demo_data.values() if v is not None):
            gender_dist = demo_data.get("gender_distribution")
            if gender_dist and isinstance(gender_dist, dict):
                gender_dist = {k: float(v) for k, v in gender_dist.items() if v is not None}

            race_dist = demo_data.get("race_ethnicity_distribution")
            if race_dist and isinstance(race_dist, dict):
                race_dist = {k: float(v) for k, v in race_dist.items() if v is not None}

            patient_demographics = PatientDemographics(
                age_range=demo_data.get("age_range"),
                gender_distribution=gender_dist,
                race_ethnicity_distribution=race_dist,
            )

        return TrainingDataResult(
            has_training_data=True,
            dataset_characteristics=dataset_characteristics,
            patient_demographics=patient_demographics,
            inclusion_criteria=extracted_data.get("inclusion_criteria"),
            exclusion_criteria=extracted_data.get("exclusion_criteria"),
            disease_characteristics=extracted_data.get("disease_characteristics"),
            data_collection_period=extracted_data.get("data_collection_period"),
            extraction_confidence=extracted_data.get("extraction_confidence", 0.0),
            source_tables=[t.get("table_id", "unknown") for t in source_tables],
            token_usage=extracted_data.get("_token_usage"),
        )
