# Copyright 2025 Asher Informatics PBC
#
# Licensed under the Proprietary License.
# See LICENSE file for full license details.

"""
Multi-page table consolidation enricher for document processing.

Handles parser fragmentation where single logical tables are split across pages:
- Detects split tables using heuristics (column headers, captions, continuation markers)
- Smart first-row comparison (handles whitespace/character variations)
- Filters parser artifacts (page headers/footers, image placeholders, logos)
- Merges split tables into consolidated markdown
- Uses LLM validation for ambiguous cases
- Tracks audit trail (merged_from table IDs)

Example:
    >>> from ashmatics_tools.enrichers import TableConsolidator
    >>> consolidator = TableConsolidator()
    >>> consolidated = await consolidator.consolidate_tables(parsed_doc.tables)
    >>> # Returns list of ConsolidatedTable objects with merge metadata
"""

import asyncio
import json
import logging
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Dict, List, Optional, Set, Tuple

from ..llm import BaseLLMClient, LLMMessage, create_llm_client, get_config_class

logger = logging.getLogger(__name__)


@dataclass
class TableCandidate:
    """
    Individual table candidate for consolidation.

    Attributes:
        table_id: Unique identifier (e.g., "table_1")
        caption: Table caption/title
        markdown: Table content in markdown format
        index: Original index in parsed_doc.tables list
        column_headers: Extracted column headers from first row
        first_data_row: First data row (for smart comparison)
        is_continuation: Whether table has continuation markers
    """

    table_id: str
    caption: Optional[str]
    markdown: str
    index: int
    column_headers: List[str] = field(default_factory=list)
    first_data_row: Optional[str] = None
    is_continuation: bool = False


@dataclass
class ConsolidatedTable:
    """
    Result of table consolidation.

    Attributes:
        table_id: Primary table ID (first table in merge group)
        caption: Merged caption
        markdown: Consolidated markdown content
        merged_from: List of table IDs that were merged (empty if not merged)
        merge_confidence: Confidence score (0-100) for merge decision
        merge_method: Method used: "heuristic", "llm_validated", "none"
        original_indices: Original indices in parsed_doc.tables
    """

    table_id: str
    caption: Optional[str]
    markdown: str
    merged_from: List[str] = field(default_factory=list)
    merge_confidence: float = 100.0
    merge_method: str = "none"
    original_indices: List[int] = field(default_factory=list)


class TableConsolidator:
    """
    Multi-page table consolidation enricher with incremental complexity.

    Strategy:
    1. Fast heuristics (regex, column header matching, continuation markers, first-row matching)
    2. Parser artifact filtering (headers/footers, image placeholders)
    3. LLM validation for ambiguous cases (optional)

    Usage:
        >>> consolidator = TableConsolidator(provider="azure_openai")
        >>> tables = parsed_doc.tables  # List of table objects from DocLing
        >>> consolidated = await consolidator.consolidate_tables(tables)
        >>> # Returns list with merged tables and metadata

    Attributes:
        llm_client: Optional LLM client for ambiguous case validation
        use_llm_validation: Whether to use LLM for ambiguous merges
        column_similarity_threshold: Min similarity (0-1) for column header matching
        caption_similarity_threshold: Min similarity (0-1) for caption matching
        first_row_similarity_threshold: Min similarity (0-1) for first data row matching
    """

    # Continuation markers that indicate split tables
    CONTINUATION_MARKERS = [
        r"\(cont['']?d\)",
        r'\(continued\)',
        r'- continued',
        r'table \d+ \(cont',
        r'continuation of table',
    ]

    # Parser artifacts to filter from table rows
    ARTIFACT_PATTERNS = [
        r'<!--\s*image\s*-->',  # Image placeholders
        r'^\s*Page \d+\s*of\s*\d+\s*$',  # Page numbers
        r'^\s*\d+\s*$',  # Lone page numbers
        r'^\s*CONFIDENTIAL\s*$',  # Document headers
        r'^\s*PROPRIETARY\s*$',
    ]

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        provider: str = "azure_openai",
        llm_config_overrides: Optional[Dict] = None,
        use_llm_validation: bool = True,
        column_similarity_threshold: float = 0.85,
        caption_similarity_threshold: float = 0.75,
        first_row_similarity_threshold: float = 0.90,
        batch_size: int = 5,
        additional_artifact_patterns: Optional[List[str]] = None,
        additional_continuation_markers: Optional[List[str]] = None,
    ):
        """
        Initialize table consolidator.

        Args:
            llm_client: Optional pre-configured LLM client
            provider: LLM provider if creating new client (default: azure_openai)
            llm_config_overrides: Optional config overrides
            use_llm_validation: Use LLM for ambiguous merge validation (default: True)
            column_similarity_threshold: Min similarity for column header match (0.85)
            caption_similarity_threshold: Min similarity for caption match (0.75)
            first_row_similarity_threshold: Min similarity for first data row match (0.90)
            batch_size: Number of LLM validations to run concurrently (default: 5)
            additional_artifact_patterns: Extra patterns to filter from tables
            additional_continuation_markers: Extra continuation marker patterns
        """
        self.use_llm_validation = use_llm_validation

        if use_llm_validation:
            if llm_client:
                self.llm_client = llm_client
            else:
                # Create LLM client with provider-specific config
                config_class = get_config_class(provider)
                overrides = llm_config_overrides or {}
                llm_config = config_class(**overrides)
                self.llm_client = create_llm_client(provider, llm_config)
        else:
            self.llm_client = None

        self.column_similarity_threshold = column_similarity_threshold
        self.caption_similarity_threshold = caption_similarity_threshold
        self.first_row_similarity_threshold = first_row_similarity_threshold
        self.batch_size = batch_size

        # Allow custom artifact/continuation patterns
        self.artifact_patterns = list(self.ARTIFACT_PATTERNS)
        if additional_artifact_patterns:
            self.artifact_patterns.extend(additional_artifact_patterns)

        self.continuation_markers = list(self.CONTINUATION_MARKERS)
        if additional_continuation_markers:
            self.continuation_markers.extend(additional_continuation_markers)

    async def consolidate_tables(
        self, tables: List, parsed_doc_markdown: Optional[str] = None
    ) -> List[ConsolidatedTable]:
        """
        Consolidate split tables from parsed document.

        Main entry point for table consolidation. Processes tables using:
        1. Heuristic detection (fast, high confidence)
        2. LLM validation for ambiguous cases (optional, slower)

        Args:
            tables: List of table objects from ParsedDocument.tables
                    Each table should have: caption, markdown attributes
            parsed_doc_markdown: Optional full document markdown for caption extraction
                                (fixes DocLing limitation where table captions are not extracted)

        Returns:
            List of ConsolidatedTable objects with merge metadata

        Example:
            >>> tables = parsed_doc.tables
            >>> markdown = parsed_doc.markdown
            >>> consolidated = await consolidator.consolidate_tables(tables, markdown)
            >>> for table in consolidated:
            ...     if table.merged_from:
            ...         print(f"{table.table_id} merged from {table.merged_from}")
        """
        if not tables:
            return []

        # Step 1: Convert to TableCandidate objects with preprocessing
        # Pass markdown to extract captions (DocLing doesn't extract them)
        candidates = self._prepare_candidates(tables, parsed_doc_markdown)

        # Step 2: Detect merge groups using heuristics
        merge_groups = self._detect_merge_groups(candidates)

        # Step 3: Validate ambiguous merges with LLM (if enabled)
        if self.use_llm_validation and self.llm_client:
            merge_groups = await self._validate_merge_groups(merge_groups, candidates)

        # Step 4: Build consolidated tables from merge groups
        consolidated = self._build_consolidated_tables(merge_groups, candidates)

        return consolidated

    def _prepare_candidates(self, tables: List, parsed_doc_markdown: Optional[str] = None) -> List[TableCandidate]:
        """
        Prepare table candidates with preprocessing.

        - Extracts captions from parsed document markdown (if available)
        - Extracts column headers from first row
        - Extracts first data row for smart comparison
        - Detects continuation markers in caption/content
        - Cleans parser artifacts from markdown

        Args:
            tables: Raw table objects from parser
            parsed_doc_markdown: Optional full document markdown for caption extraction

        Returns:
            List of TableCandidate objects
        """
        # Extract captions from document markdown if available
        table_captions = {}
        if parsed_doc_markdown:
            table_captions = self._extract_captions_from_markdown(parsed_doc_markdown, len(tables))

        candidates = []

        for idx, table in enumerate(tables):
            table_id = f"table_{idx + 1}"

            # Try parser caption first, then extracted caption, then None
            caption = getattr(table, 'caption', None)
            if not caption and table_id in table_captions:
                caption = table_captions[table_id]

            markdown = getattr(table, 'markdown', '')

            if not markdown:
                continue

            # Clean markdown (remove artifacts)
            markdown = self._clean_markdown(markdown)

            # Extract column headers from first row
            headers = self._extract_column_headers(markdown)

            # Extract first data row (row after header and separator)
            first_data_row = self._extract_first_data_row(markdown)

            # Check for continuation markers
            is_continuation = self._has_continuation_marker(caption, markdown)

            candidates.append(
                TableCandidate(
                    table_id=table_id,
                    caption=caption,
                    markdown=markdown,
                    index=idx,
                    column_headers=headers,
                    first_data_row=first_data_row,
                    is_continuation=is_continuation,
                )
            )

        return candidates

    def _clean_markdown(self, markdown: str) -> str:
        """
        Remove parser artifacts from table markdown.

        Filters out:
        - Image placeholders (<!-- image -->)
        - Page headers/footers
        - Watermarks and logos
        - Repeated header rows in continuation tables

        Args:
            markdown: Raw table markdown

        Returns:
            Cleaned markdown
        """
        lines = markdown.split('\n')
        cleaned_lines = []

        for line in lines:
            # Skip lines matching artifact patterns
            is_artifact = False
            for pattern in self.artifact_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    is_artifact = True
                    break

            if not is_artifact:
                cleaned_lines.append(line)

        return '\n'.join(cleaned_lines)

    def _extract_column_headers(self, markdown: str) -> List[str]:
        """
        Extract column headers from markdown table first row.

        Handles markdown table format:
        | Header 1 | Header 2 | Header 3 |
        |----------|----------|----------|
        | data ... | data ... | data ... |

        Args:
            markdown: Table markdown content

        Returns:
            List of column header strings (normalized to lowercase)
        """
        lines = [line.strip() for line in markdown.split('\n') if line.strip()]

        if not lines:
            return []

        # First non-empty line should be headers
        first_line = lines[0]

        if not first_line.startswith('|'):
            return []

        # Extract headers (split by |, strip whitespace)
        headers = [
            h.strip().lower()
            for h in first_line.split('|')[1:-1]  # Skip first/last empty elements
            if h.strip()
        ]

        return headers

    def _extract_first_data_row(self, markdown: str) -> Optional[str]:
        """
        Extract first data row from markdown table.

        Skips:
        - Header row (line 0)
        - Separator row (line 1, contains dashes)
        - Returns line 2 if it exists

        Args:
            markdown: Table markdown content

        Returns:
            First data row string or None
        """
        lines = [line.strip() for line in markdown.split('\n') if line.strip()]

        if len(lines) < 3:
            return None  # No data rows

        # Line 2 is first data row (after header and separator)
        return lines[2]

    def _has_continuation_marker(
        self, caption: Optional[str], markdown: str
    ) -> bool:
        """
        Check if table has continuation markers.

        Searches caption and first few rows for common continuation patterns:
        - "(cont'd)", "(continued)"
        - "Table X (cont)"
        - "- continued"

        Args:
            caption: Table caption/title
            markdown: Table markdown content

        Returns:
            True if continuation marker found
        """
        # Check caption
        if caption:
            for pattern in self.continuation_markers:
                if re.search(pattern, caption, re.IGNORECASE):
                    return True

        # Check first 200 chars of markdown
        markdown_sample = markdown[:200].lower()
        for pattern in self.continuation_markers:
            if re.search(pattern, markdown_sample, re.IGNORECASE):
                return True

        return False

    def _detect_merge_groups(
        self, candidates: List[TableCandidate]
    ) -> List[List[int]]:
        """
        Detect merge groups using heuristic rules.

        Heuristics (in order of confidence):
        1. First data row match (HIGHEST confidence - same row = same table across pages)
        2. Continuation markers + column header match (high confidence)
        3. Sequential IDs + caption similarity + column match (medium confidence)
        4. Identical column headers on consecutive tables (medium confidence)

        Args:
            candidates: List of TableCandidate objects

        Returns:
            List of merge groups, where each group is a list of candidate indices
            Example: [[0, 1], [2, 3, 4], [5]] means:
                - tables 0,1 merge
                - tables 2,3,4 merge
                - table 5 standalone
        """
        merge_groups = []
        merged_indices: Set[int] = set()

        for i in range(len(candidates)):
            if i in merged_indices:
                continue  # Already part of a merge group

            current_group = [i]
            current = candidates[i]

            # Look ahead for continuation tables
            for j in range(i + 1, len(candidates)):
                if j in merged_indices:
                    continue

                next_table = candidates[j]

                # Rule 0: Smart first data row comparison (HIGHEST confidence)
                # If first data row of table N+1 matches first data row of table N,
                # they are very likely the same table split across pages
                if j == i + len(current_group):  # Only check adjacent tables
                    if self._first_row_matches(current, next_table):
                        current_group.append(j)
                        merged_indices.add(j)
                        current = next_table  # Update current for chaining
                        continue

                # Rule 1: Continuation marker + column header match
                if next_table.is_continuation:
                    col_similarity = self._column_similarity(
                        current.column_headers, next_table.column_headers
                    )

                    if col_similarity >= self.column_similarity_threshold:
                        current_group.append(j)
                        merged_indices.add(j)
                        current = next_table  # Update current for chaining
                        continue

                # Rule 2: Sequential tables + caption similarity + column match
                # Only check if tables are adjacent (j == i + len(current_group))
                if j == i + len(current_group):
                    col_similarity = self._column_similarity(
                        current.column_headers, next_table.column_headers
                    )
                    cap_similarity = self._caption_similarity(
                        current.caption, next_table.caption
                    )

                    # High column similarity OR high caption similarity + good columns
                    if (
                        col_similarity >= self.column_similarity_threshold
                        and cap_similarity >= self.caption_similarity_threshold
                    ):
                        current_group.append(j)
                        merged_indices.add(j)
                        current = next_table
                        continue

                # Rule 3: Perfect column header match on consecutive tables
                if j == i + len(current_group):
                    if (
                        current.column_headers
                        and next_table.column_headers
                        and current.column_headers == next_table.column_headers
                    ):
                        current_group.append(j)
                        merged_indices.add(j)
                        current = next_table
                        continue

                # If we didn't merge, and this was the next table, stop looking
                # (don't skip over tables when building chains)
                if j == i + len(current_group):
                    break

            # Add group (even if single table)
            merge_groups.append(current_group)
            merged_indices.update(current_group)

        return merge_groups

    def _first_row_matches(
        self, table1: TableCandidate, table2: TableCandidate
    ) -> bool:
        """
        Smart comparison of first data rows between two tables.

        Handles parser variations:
        - Whitespace differences (extra spaces, tabs, newlines)
        - Minor character variations (stray punctuation, encoding issues)
        - Uses fuzzy string matching with high threshold

        Args:
            table1: First table candidate
            table2: Second table candidate

        Returns:
            True if first data rows match (indicating same table split across pages)
        """
        if not table1.first_data_row or not table2.first_data_row:
            return False

        # Normalize rows for comparison
        def normalize_row(row: str) -> str:
            """Normalize row for fuzzy comparison."""
            # Remove all whitespace variations
            normalized = ' '.join(row.split())
            # Lowercase
            normalized = normalized.lower()
            # Remove common markdown table delimiters
            normalized = normalized.replace('|', ' ').strip()
            # Remove extra whitespace again
            normalized = ' '.join(normalized.split())
            return normalized

        norm1 = normalize_row(table1.first_data_row)
        norm2 = normalize_row(table2.first_data_row)

        # Use SequenceMatcher for fuzzy comparison
        matcher = SequenceMatcher(None, norm1, norm2)
        similarity = matcher.ratio()

        # High threshold (0.90) to avoid false positives
        return similarity >= self.first_row_similarity_threshold

    def _column_similarity(
        self, headers1: List[str], headers2: List[str]
    ) -> float:
        """
        Calculate column header similarity (0.0 to 1.0).

        Uses sequence matching on normalized header lists.

        Args:
            headers1: First table's column headers
            headers2: Second table's column headers

        Returns:
            Similarity score (0.0 = completely different, 1.0 = identical)
        """
        if not headers1 or not headers2:
            return 0.0

        # Use SequenceMatcher for fuzzy list comparison
        matcher = SequenceMatcher(None, headers1, headers2)
        return matcher.ratio()

    def _caption_similarity(
        self, caption1: Optional[str], caption2: Optional[str]
    ) -> float:
        """
        Calculate caption similarity (0.0 to 1.0).

        Handles cases like:
        - "Table 1: Device Comparison" vs "Table 1: Device Comparison (cont'd)"
        - "Performance Results" vs "Performance Results - Continued"

        Args:
            caption1: First table's caption
            caption2: Second table's caption

        Returns:
            Similarity score (0.0 = completely different, 1.0 = identical)
        """
        if not caption1 or not caption2:
            return 0.0

        # Normalize captions (lowercase, remove continuation markers)
        def normalize(caption: str) -> str:
            caption = caption.lower().strip()
            # Remove continuation markers
            for pattern in self.continuation_markers:
                caption = re.sub(pattern, '', caption, flags=re.IGNORECASE)
            # Remove table numbering (e.g., "Table 1:", "Table 18:")
            caption = re.sub(r'^table\s+\d+[:\s]*', '', caption)
            return caption.strip()

        norm1 = normalize(caption1)
        norm2 = normalize(caption2)

        matcher = SequenceMatcher(None, norm1, norm2)
        return matcher.ratio()

    async def _validate_merge_groups(
        self,
        merge_groups: List[List[int]],
        candidates: List[TableCandidate],
    ) -> List[List[int]]:
        """
        Validate merge groups using LLM for ambiguous cases.

        Only validates groups that meet ambiguity criteria:
        - Groups with 2+ tables (potential merges)
        - Column similarity in gray zone (0.70-0.85)
        - No continuation markers (uncertain)
        - No first-row match (uncertain)

        Args:
            merge_groups: Initial merge groups from heuristics
            candidates: Table candidates

        Returns:
            Refined merge groups after LLM validation
        """
        # Identify ambiguous merge groups
        ambiguous_groups = []
        for group_idx, group in enumerate(merge_groups):
            if len(group) < 2:
                continue  # Single table, no ambiguity

            # Check if group has low-confidence merge
            # (column similarity in gray zone, no continuation markers, no first-row match)
            for i in range(len(group) - 1):
                idx1, idx2 = group[i], group[i + 1]
                table1, table2 = candidates[idx1], candidates[idx2]

                col_sim = self._column_similarity(
                    table1.column_headers, table2.column_headers
                )

                # Skip if we have high-confidence signals
                if table2.is_continuation:
                    continue
                if self._first_row_matches(table1, table2):
                    continue

                # Gray zone: 0.70-0.85 similarity (uncertain)
                if 0.70 <= col_sim < self.column_similarity_threshold:
                    ambiguous_groups.append((group_idx, group, i, i + 1))
                    break  # One ambiguity per group is enough

        if not ambiguous_groups:
            return merge_groups  # No ambiguous cases

        # Validate with LLM
        async with self.llm_client as client:
            # Process in batches
            validated_decisions = []
            for i in range(0, len(ambiguous_groups), self.batch_size):
                batch = ambiguous_groups[i : i + self.batch_size]
                batch_results = await asyncio.gather(
                    *[
                        self._llm_validate_merge(
                            candidates[group[pair_idx1]],
                            candidates[group[pair_idx2]],
                            client,
                        )
                        for group_idx, group, pair_idx1, pair_idx2 in batch
                    ]
                )
                validated_decisions.extend(zip(batch, batch_results))

        # Apply LLM decisions to refine merge groups
        refined_groups = list(merge_groups)  # Copy

        # Collect all splits to apply
        splits_to_apply = []
        for (group_idx, group, pair_idx1, pair_idx2), should_merge in validated_decisions:
            if not should_merge:
                split_point = pair_idx2
                new_group = group[split_point:]
                left_group = group[:split_point]
                splits_to_apply.append((group_idx, left_group, new_group))

        # Apply splits in reverse order of group_idx to avoid index shifting
        for group_idx, left_group, new_group in sorted(splits_to_apply, key=lambda x: -x[0]):
            refined_groups[group_idx] = left_group
            refined_groups.insert(group_idx + 1, new_group)
        return refined_groups

    async def _llm_validate_merge(
        self,
        table1: TableCandidate,
        table2: TableCandidate,
        client,
    ) -> bool:
        """
        Use LLM to validate if two tables should be merged.

        Args:
            table1: First table candidate
            table2: Second table candidate
            client: Open LLM client instance

        Returns:
            True if tables should be merged, False otherwise
        """
        # Truncate markdown to stay within token limits
        max_chars = 1000
        markdown1 = table1.markdown[:max_chars]
        markdown2 = table2.markdown[:max_chars]

        prompt = f"""You are analyzing two consecutive tables from a parsed PDF document to determine if they are parts of a single logical table that was split across pages.

Table 1:
Caption: {table1.caption or "No caption"}
Markdown:
{markdown1}

Table 2:
Caption: {table2.caption or "No caption"}
Markdown:
{markdown2}

Should these tables be merged into a single logical table?

Consider:
- Do they have the same or very similar column headers?
- Is Table 2 a continuation of Table 1's data?
- Are the captions similar or related?
- Does Table 2 have continuation markers like "(cont'd)" or "(continued)"?

Respond with ONLY a JSON object:
{{"should_merge": true}} or {{"should_merge": false}}

No explanation needed."""

        messages = [
            LLMMessage(
                role="system",
                content="You are an expert at analyzing table structure in documents.",
            ),
            LLMMessage(role="user", content=prompt),
        ]

        try:
            response = await client.complete_with_messages(
                messages=messages,
                temperature=0.0,
            )

            result = json.loads(response.text)
            return result.get('should_merge', False)

        except (json.JSONDecodeError, ValueError, KeyError) as e:
            # LLM failed - default to not merging (conservative)
            logger.warning(f"LLM validation failed for {table1.table_id} + {table2.table_id}: {e}")
            return False

    def _build_consolidated_tables(
        self,
        merge_groups: List[List[int]],
        candidates: List[TableCandidate],
    ) -> List[ConsolidatedTable]:
        """
        Build final consolidated tables from merge groups.

        Args:
            merge_groups: List of merge groups (lists of candidate indices)
            candidates: Table candidates

        Returns:
            List of ConsolidatedTable objects
        """
        consolidated = []

        for group in merge_groups:
            if not group:
                continue

            # Primary table (first in group)
            primary_idx = group[0]
            primary = candidates[primary_idx]

            if len(group) == 1:
                # Single table, no merge
                consolidated.append(
                    ConsolidatedTable(
                        table_id=primary.table_id,
                        caption=primary.caption,
                        markdown=primary.markdown,
                        merged_from=[],
                        merge_confidence=100.0,
                        merge_method="none",
                        original_indices=[primary.index],
                    )
                )
            else:
                # Merge multiple tables
                merged_markdown = self._merge_markdown_tables(
                    [candidates[idx] for idx in group]
                )

                merged_caption = self._merge_captions(
                    [candidates[idx].caption for idx in group]
                )

                merged_from = [candidates[idx].table_id for idx in group[1:]]

                # Determine merge method and confidence
                # Check for high-confidence signals
                has_continuation = any(
                    candidates[idx].is_continuation for idx in group
                )
                has_first_row_match = any(
                    self._first_row_matches(candidates[group[i]], candidates[group[i+1]])
                    for i in range(len(group) - 1)
                )

                if has_first_row_match:
                    merge_method = "heuristic_first_row"
                    merge_confidence = 98.0
                elif has_continuation:
                    merge_method = "heuristic_continuation"
                    merge_confidence = 95.0
                else:
                    merge_method = "heuristic_columns"
                    merge_confidence = 85.0

                consolidated.append(
                    ConsolidatedTable(
                        table_id=primary.table_id,
                        caption=merged_caption,
                        markdown=merged_markdown,
                        merged_from=merged_from,
                        merge_confidence=merge_confidence,
                        merge_method=merge_method,
                        original_indices=[candidates[idx].index for idx in group],
                    )
                )

        return consolidated

    def _merge_markdown_tables(
        self, tables: List[TableCandidate]
    ) -> str:
        """
        Merge markdown tables into single table.

        Strategy:
        - Use first table's header row
        - Append data rows from all tables (skip duplicate headers)
        - Preserve separator row after headers

        Args:
            tables: List of TableCandidate objects to merge

        Returns:
            Merged markdown table
        """
        if not tables:
            return ""

        if len(tables) == 1:
            return tables[0].markdown

        # Parse first table to get header and separator
        lines1 = [line.strip() for line in tables[0].markdown.split('\n') if line.strip()]

        if len(lines1) < 2:
            # Malformed table, return as-is
            return tables[0].markdown

        header_row = lines1[0]
        separator_row = lines1[1] if len(lines1) > 1 else None

        # Collect all data rows (skip headers and separators from subsequent tables)
        all_data_rows = []

        # Add data rows from first table
        if len(lines1) > 2:
            all_data_rows.extend(lines1[2:])

        # Add data rows from subsequent tables
        for table in tables[1:]:
            lines = [line.strip() for line in table.markdown.split('\n') if line.strip()]

            # Skip header (first 2 rows) from continuation tables
            data_rows = lines[2:] if len(lines) > 2 else lines

            # Filter out duplicate header rows (sometimes parsers repeat them)
            filtered_rows = [
                row for row in data_rows
                if not self._is_header_row(row, header_row)
            ]

            all_data_rows.extend(filtered_rows)

        # Build merged table
        merged_lines = [header_row]
        if separator_row:
            merged_lines.append(separator_row)
        merged_lines.extend(all_data_rows)

        return '\n'.join(merged_lines)

    def _is_header_row(self, row: str, header_row: str) -> bool:
        """
        Check if a row is a duplicate header row.

        Args:
            row: Row to check
            header_row: Known header row

        Returns:
            True if row is a duplicate header
        """
        # Normalize rows (lowercase, remove extra whitespace)
        def normalize(r: str) -> str:
            return ' '.join(r.lower().split())

        return normalize(row) == normalize(header_row)

    def _merge_captions(self, captions: List[Optional[str]]) -> Optional[str]:
        """
        Merge captions from multiple tables.

        Strategy:
        - Use first non-None caption as base
        - Remove continuation markers
        - Add note about merged tables if captions differ

        Args:
            captions: List of caption strings (may contain None)

        Returns:
            Merged caption string or None
        """
        # Get first non-None caption
        base_caption = None
        for caption in captions:
            if caption:
                base_caption = caption
                break

        if not base_caption:
            return None

        # Remove continuation markers
        merged = base_caption
        for pattern in self.continuation_markers:
            merged = re.sub(pattern, '', merged, flags=re.IGNORECASE)

        merged = merged.strip()

        # Check if captions are all similar (no need to note merge)
        all_similar = True
        for caption in captions[1:]:
            if caption:
                sim = self._caption_similarity(base_caption, caption)
                if sim < 0.9:  # Not very similar
                    all_similar = False
                    break

        # If captions differ significantly, add note
        if not all_similar:
            merged += " (consolidated from multiple pages)"

        return merged

    def _extract_captions_from_markdown(
        self, markdown: str, table_count: int
    ) -> Dict[str, str]:
        """
        Extract table captions from document markdown.

        DocLing doesn't extract table captions, but they appear as markdown headers
        like "## Table 1 Comparison of general information" before tables.

        Args:
            markdown: Full document markdown
            table_count: Expected number of tables

        Returns:
            Dict mapping table_id to caption (e.g., {"table_1": "Table 1 Comparison..."})
        """
        captions = {}
        lines = markdown.split('\n')

        table_num = 0
        last_table_header = None

        for i, line in enumerate(lines):
            # Check for table caption (markdown header with "Table")
            if line.strip().startswith('## Table'):
                # Extract caption text (e.g., "## Table 1 Comparison..." → "Table 1 Comparison...")
                last_table_header = line.strip().lstrip('#').strip()

            # Check if this is a markdown table start
            elif line.strip().startswith('|') and line.count('|') >= 2:
                # Check if this is a new table (not continuation of previous)
                if i > 0:
                    prev_line = lines[i - 1].strip()
                    # If previous line is not a table row, this is a new table
                    if not prev_line.startswith('|'):
                        table_num += 1
                        table_id = f"table_{table_num}"

                        # Associate last seen header with this table
                        if last_table_header and table_id not in captions:
                            captions[table_id] = last_table_header
                            last_table_header = None  # Reset for next table

        return captions
