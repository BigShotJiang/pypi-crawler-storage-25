"""PostgreSQL vector storage using pgvector extension.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import json
import logging
import os
from collections.abc import Callable
from typing import Any

import asyncpg

from ..chunkers.base import DocumentChunk
from .base import (
    DistanceMetric,
    IndexInfo,
    IndexType,
    SearchResult,
    VectorStore,
    VectorStoreConfig,
)

logger = logging.getLogger(__name__)


class PgVectorStore(VectorStore):
    """
    PostgreSQL vector storage using pgvector extension.

    This implementation uses PostgreSQL with the pgvector extension for vector
    similarity search. Phase 1 focuses on basic functionality with cosine similarity.

    Features:
    - Basic vector storage and retrieval
    - Cosine similarity search
    - Metadata filtering
    - Batch operations
    - Simple indexing

    Future enhancements (Phase 2):
    - HNSW indexes for faster search
    - Multiple distance metrics (L2, inner product)
    - Hybrid text+vector search

    Environment Variables:
    - PGVECTOR_CONNECTION_STRING: PostgreSQL connection string
    - PGVECTOR_TABLE_NAME: Table name for embeddings
    """

    def __init__(self, config: VectorStoreConfig | None = None):
        """
        Initialize PostgreSQL pgvector store.

        Args:
            config: Vector store configuration
        """
        super().__init__(config)

        # Get connection string from config or environment
        self.connection_string = config.connection_string or os.getenv("PGVECTOR_CONNECTION_STRING")
        if not self.connection_string:
            raise ValueError(
                "PostgreSQL connection string not provided. Set via config or "
                "PGVECTOR_CONNECTION_STRING environment variable."
            )

        # Table name
        self.table_name = config.collection_name or os.getenv(
            "PGVECTOR_TABLE_NAME", "document_embeddings"
        )

        # Connection pool
        self.pool: asyncpg.Pool | None = None

        # Statistics tracking
        self.stats = {
            "documents_stored": 0,
            "searches_performed": 0,
            "errors_encountered": 0,
        }

    async def _get_pool(self) -> asyncpg.Pool:
        """Get or create connection pool."""
        if self.pool is None:
            self.pool = await asyncpg.create_pool(
                self.connection_string,
                min_size=2,
                max_size=10,
                command_timeout=self.config.timeout,
            )
            logger.info(f"Connected to PostgreSQL: table={self.table_name}")

            # Ensure pgvector extension is enabled
            async with self.pool.acquire() as conn:
                await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")

            # Ensure table exists
            await self._create_table_if_not_exists()

        return self.pool

    async def _create_table_if_not_exists(self):
        """Create embeddings table if it doesn't exist."""
        async with self.pool.acquire() as conn:
            await conn.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {self.table_name} (
                    document_id TEXT PRIMARY KEY,
                    content TEXT NOT NULL,
                    embedding vector({self.config.dimensions}),
                    metadata JSONB DEFAULT '{{}}'::jsonb,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            logger.info(f"Ensured table exists: {self.table_name}")

    def _map_distance_operator(self, metric: DistanceMetric) -> str:
        """Map DistanceMetric to pgvector operator."""
        mapping = {
            DistanceMetric.COSINE: "<=>",  # Cosine distance
            DistanceMetric.EUCLIDEAN: "<->",  # L2 distance
            DistanceMetric.DOT_PRODUCT: "<#>",  # Negative inner product
        }
        return mapping.get(metric, "<=>")

    async def store_embedding(
        self,
        document_id: str,
        embedding: list[float],
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """
        Store a single document embedding.

        Args:
            document_id: Unique identifier for the document
            embedding: Vector embedding
            content: Document text content
            metadata: Optional metadata to store with the document

        Returns:
            True if successful, False otherwise
        """
        try:
            pool = await self._get_pool()

            # Convert embedding to string format for pgvector
            embedding_str = "[" + ",".join(map(str, embedding)) + "]"

            # Convert metadata to JSON
            metadata_json = json.dumps(metadata or {})

            async with pool.acquire() as conn:
                await conn.execute(
                    f"""
                    INSERT INTO {self.table_name} (document_id, content, embedding, metadata)
                    VALUES ($1, $2, $3::vector, $4::jsonb)
                    ON CONFLICT (document_id)
                    DO UPDATE SET
                        content = EXCLUDED.content,
                        embedding = EXCLUDED.embedding,
                        metadata = EXCLUDED.metadata
                    """,
                    document_id,
                    content,
                    embedding_str,
                    metadata_json,
                )

            self.stats["documents_stored"] += 1
            logger.debug(f"Stored document: {document_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to store document {document_id}: {e}")
            self.stats["errors_encountered"] += 1
            return False

    async def store_embeddings_batch(
        self,
        chunks: list[DocumentChunk],
        progress_callback: Callable | None = None,
    ) -> tuple[int, int]:
        """
        Store multiple document embeddings in batch.

        Args:
            chunks: List of DocumentChunk objects with embeddings
            progress_callback: Optional callback for progress updates

        Returns:
            Tuple of (successful_count, failed_count)
        """
        if not chunks:
            return (0, 0)

        # Ensure all chunks have embeddings
        chunks_with_embeddings = [c for c in chunks if c.embedding is not None]
        if len(chunks_with_embeddings) < len(chunks):
            logger.warning(f"{len(chunks) - len(chunks_with_embeddings)} chunks missing embeddings")

        pool = await self._get_pool()
        successful = 0
        failed = 0
        total_batches = (
            len(chunks_with_embeddings) + self.config.batch_size - 1
        ) // self.config.batch_size

        # Process in batches
        for batch_idx in range(0, len(chunks_with_embeddings), self.config.batch_size):
            batch = chunks_with_embeddings[batch_idx : batch_idx + self.config.batch_size]

            try:
                async with pool.acquire() as conn:
                    # Use transaction for batch insert
                    async with conn.transaction():
                        for chunk in batch:
                            doc_id = f"{chunk.metadata.get('source', 'unknown')}_{chunk.index}"
                            embedding_str = "[" + ",".join(map(str, chunk.embedding)) + "]"

                            metadata = {
                                **chunk.metadata,
                                "chunk_index": chunk.index,
                                "start_char": chunk.start_char,
                                "end_char": chunk.end_char,
                                "token_count": chunk.token_count,
                            }
                            metadata_json = json.dumps(metadata)

                            await conn.execute(
                                f"""
                                INSERT INTO {self.table_name}
                                (document_id, content, embedding, metadata)
                                VALUES ($1, $2, $3::vector, $4::jsonb)
                                ON CONFLICT (document_id)
                                DO UPDATE SET
                                    content = EXCLUDED.content,
                                    embedding = EXCLUDED.embedding,
                                    metadata = EXCLUDED.metadata
                                """,
                                doc_id,
                                chunk.content,
                                embedding_str,
                                metadata_json,
                            )

                successful += len(batch)
                logger.debug(
                    f"Batch {batch_idx // self.config.batch_size + 1}: "
                    f"Stored {len(batch)} documents"
                )

            except Exception as e:
                failed += len(batch)
                logger.error(f"Batch {batch_idx // self.config.batch_size + 1} failed: {e}")

            # Progress callback
            if progress_callback:
                current_batch = (batch_idx // self.config.batch_size) + 1
                progress_callback(current_batch, total_batches)

        self.stats["documents_stored"] += successful
        self.stats["errors_encountered"] += failed

        logger.info(f"Batch storage complete: {successful} succeeded, {failed} failed")
        return (successful, failed)

    async def similarity_search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        min_score: float | None = None,
    ) -> list[SearchResult]:
        """
        Perform vector similarity search.

        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            filters: Optional metadata filters (PostgreSQL JSONB query syntax)
            min_score: Optional minimum similarity score threshold

        Returns:
            List of SearchResult objects, ranked by similarity

        Note:
            For cosine similarity, distance is converted to similarity score (1 - distance).
            Lower distance = higher similarity.
        """
        try:
            pool = await self._get_pool()

            # Convert embedding to string format
            embedding_str = "[" + ",".join(map(str, query_embedding)) + "]"

            # Get distance operator
            distance_op = self._map_distance_operator(self.config.distance_metric)

            # Build WHERE clause for metadata filters
            where_clause = ""
            filter_params = []
            if filters:
                # Simple metadata filtering using JSONB contains operator
                where_clause = "WHERE metadata @> $2::jsonb"
                filter_params = [json.dumps(filters)]

            # Build query
            query = f"""
                SELECT
                    document_id,
                    content,
                    metadata,
                    embedding {distance_op} $1::vector AS distance
                FROM {self.table_name}
                {where_clause}
                ORDER BY embedding {distance_op} $1::vector
                LIMIT {top_k}
            """

            async with pool.acquire() as conn:
                params = [embedding_str] + filter_params
                rows = await conn.fetch(query, *params)

            # Convert to SearchResult objects
            search_results = []
            for rank, row in enumerate(rows, start=1):
                distance = float(row["distance"])

                # Convert distance to similarity score
                # For cosine: similarity = 1 - distance
                # For euclidean: use raw distance (smaller is better)
                if self.config.distance_metric == DistanceMetric.COSINE:
                    score = 1.0 - distance
                else:
                    score = 1.0 / (1.0 + distance)  # Normalize euclidean

                # Apply score threshold if provided
                if min_score is not None and score < min_score:
                    continue

                result = SearchResult(
                    document_id=row["document_id"],
                    content=row["content"],
                    score=score,
                    distance=distance,
                    rank=rank,
                    metadata=dict(row["metadata"]) if row["metadata"] else {},
                )
                search_results.append(result)

            self.stats["searches_performed"] += 1
            logger.debug(f"Vector search returned {len(search_results)} results")

            return search_results

        except Exception as e:
            logger.error(f"Vector search failed: {e}")
            self.stats["errors_encountered"] += 1
            raise

    async def create_index(
        self,
        index_name: str | None = None,
        index_type: IndexType | None = None,
        force_recreate: bool = False,
    ) -> bool:
        """
        Create vector index.

        Phase 1: Basic ivfflat index for cosine similarity.
        Phase 2 will add HNSW and other advanced indexing.

        Args:
            index_name: Optional custom index name
            index_type: Optional index type override
            force_recreate: If True, drop existing index and recreate

        Returns:
            True if index created successfully
        """
        try:
            pool = await self._get_pool()

            idx_name = index_name or f"{self.table_name}_embedding_idx"
            idx_type = index_type or self.config.index_type

            async with pool.acquire() as conn:
                # Drop existing index if force_recreate
                if force_recreate:
                    try:
                        await conn.execute(f"DROP INDEX IF EXISTS {idx_name}")
                        logger.info(f"Dropped existing index: {idx_name}")
                    except Exception:
                        pass

                # Create index based on type (Phase 1: basic support)
                if idx_type == IndexType.IVF:
                    # IVF Flat index
                    distance_op = self._map_distance_operator(self.config.distance_metric)
                    await conn.execute(
                        f"""
                        CREATE INDEX IF NOT EXISTS {idx_name}
                        ON {self.table_name}
                        USING ivfflat (embedding {distance_op})
                        WITH (lists = {self.config.num_lists})
                        """
                    )
                    logger.info(f"Created IVF index: {idx_name}")

                else:
                    # Fallback to basic index
                    distance_op = self._map_distance_operator(self.config.distance_metric)
                    await conn.execute(
                        f"""
                        CREATE INDEX IF NOT EXISTS {idx_name}
                        ON {self.table_name}
                        USING ivfflat (embedding {distance_op})
                        """
                    )
                    logger.info(f"Created basic vector index: {idx_name}")

            return True

        except Exception as e:
            logger.error(f"Failed to create vector index: {e}")
            self.stats["errors_encountered"] += 1
            return False

    async def delete_index(self, index_name: str | None = None) -> bool:
        """
        Delete vector index.

        Args:
            index_name: Optional index name (uses default if not provided)

        Returns:
            True if deleted successfully
        """
        try:
            pool = await self._get_pool()

            idx_name = index_name or f"{self.table_name}_embedding_idx"

            async with pool.acquire() as conn:
                await conn.execute(f"DROP INDEX IF EXISTS {idx_name}")

            logger.info(f"Deleted vector index: {idx_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to delete index: {e}")
            return False

    async def get_index_info(self, index_name: str | None = None) -> IndexInfo | None:
        """
        Get information about a vector index.

        Args:
            index_name: Optional index name (uses default if not provided)

        Returns:
            IndexInfo object if index exists, None otherwise
        """
        try:
            pool = await self._get_pool()

            idx_name = index_name or f"{self.table_name}_embedding_idx"

            async with pool.acquire() as conn:
                # Query pg_indexes for index information
                row = await conn.fetchrow(
                    """
                    SELECT
                        indexname,
                        tablename,
                        indexdef
                    FROM pg_indexes
                    WHERE indexname = $1
                    """,
                    idx_name,
                )

                if not row:
                    return None

                # Get document count
                count = await conn.fetchval(f"SELECT COUNT(*) FROM {self.table_name}")

                # Parse index type from definition
                idx_def = row["indexdef"]
                if "ivfflat" in idx_def.lower():
                    idx_type = IndexType.IVF
                elif "hnsw" in idx_def.lower():
                    idx_type = IndexType.HNSW
                else:
                    idx_type = IndexType.FLAT

                return IndexInfo(
                    name=idx_name,
                    collection_name=self.table_name,
                    index_type=idx_type,
                    dimensions=self.config.dimensions,
                    distance_metric=self.config.distance_metric,
                    num_vectors=count,
                    metadata={"index_definition": idx_def},
                )

        except Exception as e:
            logger.error(f"Failed to get index info: {e}")
            return None

    async def health_check(self) -> bool:
        """
        Check if PostgreSQL vector store is operational.

        Returns:
            True if store is healthy and accessible
        """
        try:
            pool = await self._get_pool()

            async with pool.acquire() as conn:
                # Simple query to verify connection
                await conn.fetchval("SELECT 1")

            logger.debug("PostgreSQL health check: OK")
            return True

        except Exception as e:
            logger.error(f"PostgreSQL health check failed: {e}")
            return False

    async def delete_document(self, document_id: str) -> bool:
        """
        Delete a document by ID.

        Args:
            document_id: Document identifier

        Returns:
            True if deleted successfully
        """
        try:
            pool = await self._get_pool()

            async with pool.acquire() as conn:
                result = await conn.execute(
                    f"DELETE FROM {self.table_name} WHERE document_id = $1",
                    document_id,
                )

            # Check if any rows were deleted
            return "DELETE" in result and int(result.split()[-1]) > 0

        except Exception as e:
            logger.error(f"Failed to delete document {document_id}: {e}")
            return False

    async def count_documents(self) -> int:
        """
        Count total documents in the table.

        Returns:
            Total number of documents
        """
        try:
            pool = await self._get_pool()

            async with pool.acquire() as conn:
                count = await conn.fetchval(f"SELECT COUNT(*) FROM {self.table_name}")

            return count

        except Exception as e:
            logger.error(f"Failed to count documents: {e}")
            return 0

    def get_stats(self) -> dict[str, Any]:
        """
        Get usage statistics.

        Returns:
            Dictionary with usage statistics
        """
        return {
            **self.stats,
            "provider": self.config.provider.value,
            "table": self.table_name,
        }

    async def close(self):
        """Close connection pool."""
        if self.pool is not None:
            await self.pool.close()
            self.pool = None
            logger.info("PostgreSQL connection closed")
