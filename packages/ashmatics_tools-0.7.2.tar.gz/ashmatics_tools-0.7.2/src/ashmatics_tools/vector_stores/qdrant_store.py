"""Qdrant vector storage implementation.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
import os
from collections.abc import Callable
from typing import Any

from qdrant_client import AsyncQdrantClient, models
from qdrant_client.http.exceptions import UnexpectedResponse

from ..chunkers.base import DocumentChunk
from .base import (
    DistanceMetric,
    IndexInfo,
    IndexType,
    SearchResult,
    VectorStore,
    VectorStoreConfig,
)

logger = logging.getLogger(__name__)


class QdrantVectorStore(VectorStore):
    """
    Qdrant vector storage implementation.

    Qdrant is a high-performance vector database with excellent filtering
    capabilities and support for multiple distance metrics.

    Features:
    - Native vector search with HNSW indexing
    - Rich metadata filtering
    - Batch operations
    - Self-hosted or cloud options
    - Automatic sharding and replication

    Environment Variables:
    - QDRANT_HOST: Qdrant server host (default: localhost)
    - QDRANT_PORT: Qdrant server port (default: 6333)
    - QDRANT_API_KEY: Optional API key for authentication
    - QDRANT_COLLECTION_NAME: Collection name
    """

    def __init__(self, config: VectorStoreConfig | None = None):
        """
        Initialize Qdrant vector store.

        Args:
            config: Vector store configuration
        """
        super().__init__(config)

        # Get connection parameters
        host = os.getenv("QDRANT_HOST", "localhost")
        port = int(os.getenv("QDRANT_PORT", "6333"))
        api_key = os.getenv("QDRANT_API_KEY")

        # Collection name
        self.collection_name = config.collection_name or os.getenv(
            "QDRANT_COLLECTION_NAME", "ashmatics_docs"
        )

        # Initialize Qdrant client
        self.client = AsyncQdrantClient(
            host=host,
            port=port,
            api_key=api_key,
            timeout=config.timeout,
        )

        # Statistics tracking
        self.stats = {
            "documents_stored": 0,
            "searches_performed": 0,
            "errors_encountered": 0,
        }

        logger.info(f"Initialized Qdrant client: {host}:{port}, collection={self.collection_name}")

    def _map_distance_metric(self, metric: DistanceMetric) -> models.Distance:
        """Map DistanceMetric enum to Qdrant Distance."""
        mapping = {
            DistanceMetric.COSINE: models.Distance.COSINE,
            DistanceMetric.EUCLIDEAN: models.Distance.EUCLID,
            DistanceMetric.DOT_PRODUCT: models.Distance.DOT,
            DistanceMetric.MANHATTAN: models.Distance.MANHATTAN,
        }
        return mapping.get(metric, models.Distance.COSINE)

    async def _ensure_collection_exists(self):
        """Ensure the collection exists, create if not."""
        try:
            # Check if collection exists
            collections = await self.client.get_collections()
            collection_names = [c.name for c in collections.collections]

            if self.collection_name not in collection_names:
                # Create collection with vector configuration
                await self.client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=models.VectorParams(
                        size=self.config.dimensions,
                        distance=self._map_distance_metric(self.config.distance_metric),
                    ),
                    # HNSW index configuration
                    hnsw_config=models.HnswConfigDiff(
                        m=self.config.m,
                        ef_construct=self.config.ef_construction,
                    ),
                )
                logger.info(f"Created Qdrant collection: {self.collection_name}")

        except UnexpectedResponse as e:
            logger.error(f"Failed to ensure collection exists: {e}")
            raise

    async def store_embedding(
        self,
        document_id: str,
        embedding: list[float],
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """
        Store a single document embedding.

        Args:
            document_id: Unique identifier for the document
            embedding: Vector embedding
            content: Document text content
            metadata: Optional metadata to store with the document

        Returns:
            True if successful, False otherwise
        """
        try:
            # Ensure collection exists
            await self._ensure_collection_exists()

            # Prepare payload
            payload = {
                "document_id": document_id,
                "content": content,
                **(metadata or {}),
            }

            # Store point
            await self.client.upsert(
                collection_name=self.collection_name,
                points=[
                    models.PointStruct(
                        id=document_id,  # Use document_id as point ID
                        vector=embedding,
                        payload=payload,
                    )
                ],
            )

            self.stats["documents_stored"] += 1
            logger.debug(f"Stored document: {document_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to store document {document_id}: {e}")
            self.stats["errors_encountered"] += 1
            return False

    async def store_embeddings_batch(
        self,
        chunks: list[DocumentChunk],
        progress_callback: Callable | None = None,
    ) -> tuple[int, int]:
        """
        Store multiple document embeddings in batch.

        Args:
            chunks: List of DocumentChunk objects with embeddings
            progress_callback: Optional callback for progress updates

        Returns:
            Tuple of (successful_count, failed_count)
        """
        if not chunks:
            return (0, 0)

        # Ensure all chunks have embeddings
        chunks_with_embeddings = [c for c in chunks if c.embedding is not None]
        if len(chunks_with_embeddings) < len(chunks):
            logger.warning(f"{len(chunks) - len(chunks_with_embeddings)} chunks missing embeddings")

        # Ensure collection exists
        await self._ensure_collection_exists()

        successful = 0
        failed = 0
        total_batches = (
            len(chunks_with_embeddings) + self.config.batch_size - 1
        ) // self.config.batch_size

        # Process in batches
        for batch_idx in range(0, len(chunks_with_embeddings), self.config.batch_size):
            batch = chunks_with_embeddings[batch_idx : batch_idx + self.config.batch_size]

            try:
                # Prepare points for batch
                points = []
                for chunk in batch:
                    # Generate unique point ID
                    doc_id = f"{chunk.metadata.get('source', 'unknown')}_{chunk.index}"

                    payload = {
                        "document_id": doc_id,
                        "content": chunk.content,
                        "chunk_index": chunk.index,
                        "start_char": chunk.start_char,
                        "end_char": chunk.end_char,
                        "token_count": chunk.token_count,
                        **chunk.metadata,
                    }

                    points.append(
                        models.PointStruct(
                            id=doc_id,
                            vector=chunk.embedding,
                            payload=payload,
                        )
                    )

                # Batch upsert
                await self.client.upsert(
                    collection_name=self.collection_name,
                    points=points,
                )

                successful += len(points)
                logger.debug(
                    f"Batch {batch_idx // self.config.batch_size + 1}: "
                    f"Stored {len(points)} documents"
                )

            except Exception as e:
                failed += len(batch)
                logger.error(f"Batch {batch_idx // self.config.batch_size + 1} failed: {e}")

            # Progress callback
            if progress_callback:
                current_batch = (batch_idx // self.config.batch_size) + 1
                progress_callback(current_batch, total_batches)

        self.stats["documents_stored"] += successful
        self.stats["errors_encountered"] += failed

        logger.info(f"Batch storage complete: {successful} succeeded, {failed} failed")
        return (successful, failed)

    async def similarity_search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        min_score: float | None = None,
    ) -> list[SearchResult]:
        """
        Perform vector similarity search.

        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            filters: Optional metadata filters (Qdrant filter syntax)
            min_score: Optional minimum similarity score threshold

        Returns:
            List of SearchResult objects, ranked by similarity
        """
        try:
            # Ensure collection exists
            await self._ensure_collection_exists()

            # Build filter conditions
            query_filter = None
            if filters:
                # Convert simple dict filters to Qdrant filter conditions
                must_conditions = []
                for key, value in filters.items():
                    must_conditions.append(
                        models.FieldCondition(
                            key=key,
                            match=models.MatchValue(value=value),
                        )
                    )
                if must_conditions:
                    query_filter = models.Filter(must=must_conditions)

            # Perform search
            search_results = await self.client.search(
                collection_name=self.collection_name,
                query_vector=query_embedding,
                limit=top_k,
                query_filter=query_filter,
                score_threshold=min_score,
            )

            # Convert to SearchResult objects
            results = []
            for rank, result in enumerate(search_results, start=1):
                payload = result.payload or {}

                search_result = SearchResult(
                    document_id=payload.get("document_id", str(result.id)),
                    content=payload.get("content", ""),
                    score=result.score,
                    rank=rank,
                    metadata={
                        k: v for k, v in payload.items() if k not in ["document_id", "content"]
                    },
                )
                results.append(search_result)

            self.stats["searches_performed"] += 1
            logger.debug(f"Vector search returned {len(results)} results")

            return results

        except Exception as e:
            logger.error(f"Vector search failed: {e}")
            self.stats["errors_encountered"] += 1
            raise

    async def create_index(
        self,
        index_name: str | None = None,
        index_type: IndexType | None = None,
        force_recreate: bool = False,
    ) -> bool:
        """
        Create or update vector index.

        Note: Qdrant automatically creates HNSW indexes. This method is mainly
        for consistency with the VectorStore interface.

        Args:
            index_name: Optional custom index name (not used in Qdrant)
            index_type: Optional index type override (not used in Qdrant)
            force_recreate: If True, recreate the collection

        Returns:
            True if successful
        """
        try:
            if force_recreate:
                # Delete and recreate collection
                try:
                    await self.client.delete_collection(self.collection_name)
                    logger.info(f"Deleted collection: {self.collection_name}")
                except Exception:
                    pass  # Collection doesn't exist

            # Ensure collection exists (will create with HNSW index)
            await self._ensure_collection_exists()

            logger.info(f"Qdrant collection ready: {self.collection_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to create index: {e}")
            self.stats["errors_encountered"] += 1
            return False

    async def delete_index(self, index_name: str | None = None) -> bool:
        """
        Delete vector index (deletes entire collection in Qdrant).

        Args:
            index_name: Optional index name (not used in Qdrant)

        Returns:
            True if deleted successfully
        """
        try:
            await self.client.delete_collection(self.collection_name)
            logger.info(f"Deleted collection: {self.collection_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to delete collection: {e}")
            return False

    async def get_index_info(self, index_name: str | None = None) -> IndexInfo | None:
        """
        Get information about the vector index (collection).

        Args:
            index_name: Optional index name (not used in Qdrant)

        Returns:
            IndexInfo object if collection exists, None otherwise
        """
        try:
            # Get collection info
            collection_info = await self.client.get_collection(self.collection_name)

            # Extract information
            config = collection_info.config
            vectors_config = config.params.vectors

            return IndexInfo(
                name=self.collection_name,
                collection_name=self.collection_name,
                index_type=IndexType.HNSW,  # Qdrant uses HNSW
                dimensions=vectors_config.size,
                distance_metric=self.config.distance_metric,
                num_vectors=collection_info.points_count,
                metadata={
                    "vectors_count": collection_info.vectors_count,
                    "indexed_vectors_count": collection_info.indexed_vectors_count,
                    "segments_count": collection_info.segments_count,
                    "status": collection_info.status,
                },
            )

        except Exception as e:
            logger.error(f"Failed to get index info: {e}")
            return None

    async def health_check(self) -> bool:
        """
        Check if Qdrant vector store is operational.

        Returns:
            True if store is healthy and accessible
        """
        try:
            # Check if client can connect
            await self.client.get_collections()
            logger.debug("Qdrant health check: OK")
            return True

        except Exception as e:
            logger.error(f"Qdrant health check failed: {e}")
            return False

    async def delete_document(self, document_id: str) -> bool:
        """
        Delete a document by ID.

        Args:
            document_id: Document identifier

        Returns:
            True if deleted successfully
        """
        try:
            await self.client.delete(
                collection_name=self.collection_name,
                points_selector=models.PointIdsList(
                    points=[document_id],
                ),
            )
            logger.debug(f"Deleted document: {document_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to delete document {document_id}: {e}")
            return False

    async def count_documents(self) -> int:
        """
        Count total documents in the collection.

        Returns:
            Total number of documents
        """
        try:
            collection_info = await self.client.get_collection(self.collection_name)
            return collection_info.points_count

        except Exception as e:
            logger.error(f"Failed to count documents: {e}")
            return 0

    def get_stats(self) -> dict[str, Any]:
        """
        Get usage statistics.

        Returns:
            Dictionary with usage statistics
        """
        return {
            **self.stats,
            "provider": self.config.provider.value,
            "collection": self.collection_name,
        }

    async def close(self):
        """Close Qdrant client connection."""
        if self.client is not None:
            await self.client.close()
            logger.info("Qdrant connection closed")
