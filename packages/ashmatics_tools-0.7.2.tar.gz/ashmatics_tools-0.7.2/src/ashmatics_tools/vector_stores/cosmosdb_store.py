"""CosmosDB vector storage using MongoDB vCore API.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
import os
from collections.abc import Callable
from typing import Any

from pymongo import MongoClient
from pymongo.errors import PyMongoError

from ..chunkers.base import DocumentChunk
from .base import (
    DistanceMetric,
    IndexInfo,
    IndexType,
    SearchResult,
    VectorStore,
    VectorStoreConfig,
)

logger = logging.getLogger(__name__)


class CosmosDBVectorStore(VectorStore):
    """
    CosmosDB vector storage using MongoDB vCore API.

    This implementation uses Azure CosmosDB for MongoDB vCore with native vector search
    capabilities via the $vectorSearch aggregation operator.

    Features:
    - Native vector indexing (IVF, HNSW)
    - Metadata filtering during vector search
    - Batch operations with error handling
    - Automatic retry logic
    - Connection pooling

    Environment Variables (2026-01-25: standardized with fallback chain):
    - Connection string: MONGO_URL (canonical) -> AZ_MONGO_CONNECTION_STRING ->
      COSMOS_VECTOR_CONNECTION_STRING (deprecated)
    - Database: MONGO_DB (canonical) -> COSMOS_VECTOR_DATABASE (deprecated)
    - Collection: COSMOS_VECTOR_COLLECTION
    """

    def __init__(self, config: VectorStoreConfig | None = None):
        """
        Initialize CosmosDB vector store.

        Args:
            config: Vector store configuration
        """
        super().__init__(config)

        # Get connection string from config or environment (standardized fallback chain)
        # 2026-01-25: MONGO_URL is canonical, with backward-compatible fallbacks
        self.connection_string = (
            config.connection_string
            or os.getenv("MONGO_URL")
            or os.getenv("AZ_MONGO_CONNECTION_STRING")
            or os.getenv("COSMOS_VECTOR_CONNECTION_STRING")
        )
        if not self.connection_string:
            raise ValueError(
                "CosmosDB connection string not provided. Set via config or "
                "MONGO_URL (preferred), AZ_MONGO_CONNECTION_STRING, or "
                "COSMOS_VECTOR_CONNECTION_STRING environment variable."
            )

        # Database and collection names (standardized fallback chain)
        # 2026-01-25: MONGO_DB is canonical, with backward-compatible fallback
        self.database_name = (
            config.database_name
            or os.getenv("MONGO_DB")
            or os.getenv("COSMOS_VECTOR_DATABASE", "ashmatics_vectors")
        )
        self.collection_name = config.collection_name or os.getenv(
            "COSMOS_VECTOR_COLLECTION", "embedded_documents"
        )

        # Initialize MongoDB client
        self.client: MongoClient | None = None
        self.db = None
        self.collection = None

        # Statistics tracking
        self.stats = {
            "documents_stored": 0,
            "searches_performed": 0,
            "errors_encountered": 0,
        }

    def _get_client(self) -> MongoClient:
        """Get or create MongoDB client."""
        if self.client is None:
            self.client = MongoClient(self.connection_string)
            self.db = self.client[self.database_name]
            self.collection = self.db[self.collection_name]
            logger.info(f"Connected to CosmosDB: {self.database_name}.{self.collection_name}")
        return self.client

    def _map_distance_metric(self, metric: DistanceMetric) -> str:
        """Map DistanceMetric enum to CosmosDB distance metric string."""
        mapping = {
            DistanceMetric.COSINE: "COS",
            DistanceMetric.EUCLIDEAN: "L2",
            DistanceMetric.DOT_PRODUCT: "IP",
        }
        return mapping.get(metric, "COS")

    def _map_index_type(self, index_type: IndexType) -> str:
        """Map IndexType enum to CosmosDB vector index type."""
        mapping = {
            IndexType.IVF: "vector-ivf",
            IndexType.HNSW: "vector-hnsw",
            IndexType.FLAT: "vector-flat",
        }
        return mapping.get(index_type, "vector-ivf")

    async def store_embedding(
        self,
        document_id: str,
        embedding: list[float],
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """
        Store a single document embedding.

        Args:
            document_id: Unique identifier for the document
            embedding: Vector embedding
            content: Document text content
            metadata: Optional metadata to store with the document

        Returns:
            True if successful, False otherwise
        """
        try:
            # Ensure client is connected
            self._get_client()

            # Prepare document
            document = {
                "_id": document_id,
                "content": content,
                "embedding": embedding,
                "metadata": metadata or {},
            }

            # Insert or update document
            self.collection.replace_one({"_id": document_id}, document, upsert=True)

            self.stats["documents_stored"] += 1
            logger.debug(f"Stored document: {document_id}")
            return True

        except PyMongoError as e:
            logger.error(f"Failed to store document {document_id}: {e}")
            self.stats["errors_encountered"] += 1
            return False

    async def store_embeddings_batch(
        self,
        chunks: list[DocumentChunk],
        progress_callback: Callable | None = None,
    ) -> tuple[int, int]:
        """
        Store multiple document embeddings in batch.

        Args:
            chunks: List of DocumentChunk objects with embeddings
            progress_callback: Optional callback for progress updates

        Returns:
            Tuple of (successful_count, failed_count)
        """
        if not chunks:
            return (0, 0)

        # Ensure all chunks have embeddings
        chunks_with_embeddings = [c for c in chunks if c.embedding is not None]
        if len(chunks_with_embeddings) < len(chunks):
            logger.warning(f"{len(chunks) - len(chunks_with_embeddings)} chunks missing embeddings")

        # Ensure client is connected
        self._get_client()

        successful = 0
        failed = 0
        total_batches = (
            len(chunks_with_embeddings) + self.config.batch_size - 1
        ) // self.config.batch_size

        # Process in batches
        for batch_idx in range(0, len(chunks_with_embeddings), self.config.batch_size):
            batch = chunks_with_embeddings[batch_idx : batch_idx + self.config.batch_size]

            try:
                # Prepare documents for batch
                documents = []
                for chunk in batch:
                    doc_id = f"{chunk.metadata.get('source', 'unknown')}_{chunk.index}"
                    doc = {
                        "_id": doc_id,
                        "content": chunk.content,
                        "embedding": chunk.embedding,
                        "metadata": {
                            **chunk.metadata,
                            "chunk_index": chunk.index,
                            "start_char": chunk.start_char,
                            "end_char": chunk.end_char,
                            "token_count": chunk.token_count,
                        },
                    }
                    documents.append(doc)

                # Bulk insert with ordered=False to continue on errors
                result = self.collection.insert_many(documents, ordered=False)
                successful += len(result.inserted_ids)
                logger.debug(
                    f"Batch {batch_idx // self.config.batch_size + 1}: Stored {len(result.inserted_ids)} documents"
                )

            except Exception as e:
                # Handle partial failures in batch
                if hasattr(e, "details") and "writeErrors" in e.details:
                    # Some documents succeeded, count them
                    num_errors = len(e.details["writeErrors"])
                    batch_success = len(batch) - num_errors
                    successful += batch_success
                    failed += num_errors
                    logger.warning(
                        f"Batch {batch_idx // self.config.batch_size + 1}: {batch_success} succeeded, {num_errors} failed"
                    )
                else:
                    # Entire batch failed
                    failed += len(batch)
                    logger.error(f"Batch {batch_idx // self.config.batch_size + 1} failed: {e}")

            # Progress callback
            if progress_callback:
                current_batch = (batch_idx // self.config.batch_size) + 1
                progress_callback(current_batch, total_batches)

        self.stats["documents_stored"] += successful
        self.stats["errors_encountered"] += failed

        logger.info(f"Batch storage complete: {successful} succeeded, {failed} failed")
        return (successful, failed)

    async def similarity_search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        min_score: float | None = None,
    ) -> list[SearchResult]:
        """
        Perform vector similarity search using $search with cosmosSearch operator.

        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            filters: Optional metadata filters (MongoDB query syntax)
            min_score: Optional minimum similarity score threshold

        Returns:
            List of SearchResult objects, ranked by similarity
        """
        try:
            # Ensure client is connected
            self._get_client()

            # Build $search pipeline stage using cosmosSearch operator
            search_stage = {
                "$search": {
                    "cosmosSearch": {
                        "vector": query_embedding,
                        "path": "embedding",
                        "k": top_k,
                    },
                    "returnStoredSource": True,
                }
            }

            # Add filters if provided
            if filters:
                search_stage["$search"]["cosmosSearch"]["filter"] = filters

            # Build aggregation pipeline
            pipeline = [
                search_stage,
                {
                    "$project": {
                        "_id": 1,
                        "content": 1,
                        "metadata": 1,
                        "score": {"$meta": "searchScore"},
                        "document": "$$ROOT",
                    }
                },
            ]

            # Add score filter if provided
            if min_score is not None:
                pipeline.append({"$match": {"score": {"$gte": min_score}}})

            # Execute search
            results = list(self.collection.aggregate(pipeline))

            # Convert to SearchResult objects
            search_results = []
            for rank, doc in enumerate(results, start=1):
                result = SearchResult(
                    document_id=doc["_id"],
                    content=doc.get("content", ""),
                    score=doc.get("score", 0.0),
                    rank=rank,
                    metadata=doc.get("metadata", {}),
                )
                search_results.append(result)

            self.stats["searches_performed"] += 1
            logger.debug(f"Vector search returned {len(search_results)} results")

            return search_results

        except PyMongoError as e:
            logger.error(f"Vector search failed: {e}")
            self.stats["errors_encountered"] += 1
            raise

    async def create_index(
        self,
        index_name: str | None = None,
        index_type: IndexType | None = None,
        force_recreate: bool = False,
    ) -> bool:
        """
        Create or update vector index.

        Args:
            index_name: Optional custom index name
            index_type: Optional index type override
            force_recreate: If True, drop existing index and recreate

        Returns:
            True if index created/updated successfully
        """
        try:
            # Ensure client is connected
            self._get_client()

            # Determine index name and type
            idx_name = index_name or f"{self.collection_name}_vector_index"
            idx_type = index_type or self.config.index_type

            # Drop existing index if force_recreate
            if force_recreate:
                try:
                    self.collection.drop_index(idx_name)
                    logger.info(f"Dropped existing index: {idx_name}")
                except PyMongoError:
                    pass  # Index doesn't exist, continue

            # Create vector index using CosmosDB createIndexes command
            cosmos_search_options = {
                "kind": self._map_index_type(idx_type),
                "dimensions": self.config.dimensions,
                "similarity": self._map_distance_metric(self.config.distance_metric),
            }

            # Add index-specific parameters
            if idx_type == IndexType.IVF:
                cosmos_search_options["numLists"] = self.config.num_lists
            elif idx_type == IndexType.HNSW:
                cosmos_search_options["m"] = self.config.m
                cosmos_search_options["efConstruction"] = self.config.ef_construction

            # Use db.command() with createIndexes for CosmosDB
            create_indexes_command = {
                "createIndexes": self.collection_name,
                "indexes": [
                    {
                        "name": idx_name,
                        "key": {"embedding": "cosmosSearch"},
                        "cosmosSearchOptions": cosmos_search_options,
                    }
                ],
            }

            # Execute the command
            result = self.db.command(create_indexes_command)

            if result.get("ok", 0) == 1:
                logger.info(f"Created vector index: {idx_name} (type: {idx_type.value})")
                return True
            else:
                logger.error(f"Failed to create vector index: {result}")
                return False

        except PyMongoError as e:
            logger.error(f"Failed to create vector index: {e}")
            self.stats["errors_encountered"] += 1
            return False

    async def create_metadata_indexes(self, metadata_fields: list[str]) -> bool:
        """
        Create indexes for metadata fields to support filtering.

        Args:
            metadata_fields: List of metadata field names to index (e.g., ['category', 'source'])

        Returns:
            True if all indexes created successfully
        """
        try:
            # Ensure client is connected
            self._get_client()

            success_count = 0
            for field in metadata_fields:
                index_name = f"metadata_{field}_index"

                # Check if index already exists
                existing_indexes = list(self.collection.list_indexes())
                if any(idx.get("name") == index_name for idx in existing_indexes):
                    logger.info(f"Index {index_name} already exists, skipping")
                    success_count += 1
                    continue

                # Create index for metadata field
                create_indexes_command = {
                    "createIndexes": self.collection_name,
                    "indexes": [
                        {
                            "name": index_name,
                            "key": {f"metadata.{field}": 1},
                        }
                    ],
                }

                result = self.db.command(create_indexes_command)

                if result.get("ok", 0) == 1:
                    logger.info(f"Created metadata index: {index_name}")
                    success_count += 1
                else:
                    logger.error(f"Failed to create metadata index {index_name}: {result}")

            return success_count == len(metadata_fields)

        except PyMongoError as e:
            logger.error(f"Failed to create metadata indexes: {e}")
            self.stats["errors_encountered"] += 1
            return False

    async def delete_index(self, index_name: str | None = None) -> bool:
        """
        Delete vector index.

        Args:
            index_name: Optional index name (uses default if not provided)

        Returns:
            True if deleted successfully
        """
        try:
            # Ensure client is connected
            self._get_client()

            idx_name = index_name or f"{self.collection_name}_vector_index"
            self.collection.drop_index(idx_name)

            logger.info(f"Deleted vector index: {idx_name}")
            return True

        except PyMongoError as e:
            logger.error(f"Failed to delete index: {e}")
            return False

    async def get_index_info(self, index_name: str | None = None) -> IndexInfo | None:
        """
        Get information about a vector index.

        Args:
            index_name: Optional index name (uses default if not provided)

        Returns:
            IndexInfo object if index exists, None otherwise
        """
        try:
            # Ensure client is connected
            self._get_client()

            idx_name = index_name or f"{self.collection_name}_vector_index"

            # Get index information
            indexes = list(self.collection.list_indexes())
            for idx in indexes:
                if idx.get("name") == idx_name:
                    # Extract index details
                    cosmos_opts = idx.get("cosmosSearchOptions", {})

                    # Map back to our enums
                    idx_type = IndexType.IVF  # Default
                    if cosmos_opts.get("kind") == "vector-hnsw":
                        idx_type = IndexType.HNSW
                    elif cosmos_opts.get("kind") == "vector-flat":
                        idx_type = IndexType.FLAT

                    distance = DistanceMetric.COSINE  # Default
                    if cosmos_opts.get("similarity") == "euclidean":
                        distance = DistanceMetric.EUCLIDEAN
                    elif cosmos_opts.get("similarity") == "dotProduct":
                        distance = DistanceMetric.DOT_PRODUCT

                    # Get document count
                    num_vectors = self.collection.count_documents({})

                    return IndexInfo(
                        name=idx_name,
                        collection_name=self.collection_name,
                        index_type=idx_type,
                        dimensions=cosmos_opts.get("dimensions", self.config.dimensions),
                        distance_metric=distance,
                        num_vectors=num_vectors,
                        metadata=cosmos_opts,
                    )

            return None

        except PyMongoError as e:
            logger.error(f"Failed to get index info: {e}")
            return None

    async def health_check(self) -> bool:
        """
        Check if CosmosDB vector store is operational.

        Returns:
            True if store is healthy and accessible
        """
        try:
            # Ensure client is connected
            self._get_client()

            # Simple ping command
            self.db.command("ping")

            logger.debug("CosmosDB health check: OK")
            return True

        except PyMongoError as e:
            logger.error(f"CosmosDB health check failed: {e}")
            return False

    async def delete_document(self, document_id: str) -> bool:
        """
        Delete a document by ID.

        Args:
            document_id: Document identifier

        Returns:
            True if deleted successfully
        """
        try:
            # Ensure client is connected
            self._get_client()

            result = self.collection.delete_one({"_id": document_id})
            return result.deleted_count > 0

        except PyMongoError as e:
            logger.error(f"Failed to delete document {document_id}: {e}")
            return False

    async def count_documents(self) -> int:
        """
        Count total documents in the collection.

        Returns:
            Total number of documents
        """
        try:
            # Ensure client is connected
            self._get_client()

            count = self.collection.count_documents({})
            return count

        except PyMongoError as e:
            logger.error(f"Failed to count documents: {e}")
            return 0

    def get_stats(self) -> dict[str, Any]:
        """
        Get usage statistics.

        Returns:
            Dictionary with usage statistics
        """
        return {
            **self.stats,
            "provider": self.config.provider.value,
            "database": self.database_name,
            "collection": self.collection_name,
        }

    def close(self):
        """Close MongoDB client connection."""
        if self.client is not None:
            self.client.close()
            self.client = None
            self.db = None
            self.collection = None
            logger.info("CosmosDB connection closed")
