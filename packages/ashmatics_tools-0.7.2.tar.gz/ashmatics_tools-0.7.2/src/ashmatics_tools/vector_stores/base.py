"""Abstract base classes for vector storage.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..chunkers.base import DocumentChunk


class VectorStoreProvider(str, Enum):
    """Supported vector store providers."""

    COSMOSDB = "cosmosdb"  # Azure CosmosDB with MongoDB vCore API
    PGVECTOR = "pgvector"  # PostgreSQL with pgvector extension
    QDRANT = "qdrant"  # Qdrant vector database


class DistanceMetric(str, Enum):
    """Vector distance/similarity metrics."""

    COSINE = "cosine"  # Cosine similarity (default, normalized)
    EUCLIDEAN = "euclidean"  # L2 distance
    DOT_PRODUCT = "dot_product"  # Inner product
    MANHATTAN = "manhattan"  # L1 distance


class IndexType(str, Enum):
    """Vector index types."""

    FLAT = "flat"  # Flat index (exact search, no approximation)
    IVF = "ivf"  # Inverted file index (CosmosDB)
    HNSW = "hnsw"  # Hierarchical Navigable Small World graph
    NONE = "none"  # No index (for small collections)


@dataclass
class VectorStoreConfig:
    """
    Configuration for vector storage.

    This configuration is used across all vector store types to maintain consistency.
    Provider-specific settings can be passed via `extra_config`.
    """

    # Provider
    provider: VectorStoreProvider = VectorStoreProvider.COSMOSDB

    # Connection settings
    connection_string: str | None = None  # Database connection string
    database_name: str | None = None  # Database/collection namespace
    collection_name: str = "embedded_documents"  # Collection/table name

    # Vector settings
    dimensions: int = 1536  # Embedding dimensions (text-embedding-3-small default)
    distance_metric: DistanceMetric = DistanceMetric.COSINE
    index_type: IndexType = IndexType.IVF

    # Performance settings
    batch_size: int = 100  # Batch size for bulk operations
    max_retries: int = 3  # Maximum retry attempts
    retry_delay: float = 1.0  # Delay between retries in seconds
    timeout: float = 30.0  # Operation timeout in seconds

    # Index settings
    num_lists: int = 100  # Number of clusters for IVF index (CosmosDB)
    ef_construction: int = 200  # HNSW construction parameter
    m: int = 16  # HNSW connections per layer

    # Provider-specific settings
    extra_config: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration."""
        if self.dimensions <= 0:
            raise ValueError("dimensions must be positive")
        if self.batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if self.retry_delay < 0:
            raise ValueError("retry_delay must be non-negative")
        if self.timeout <= 0:
            raise ValueError("timeout must be positive")


@dataclass
class SearchResult:
    """Represents a vector search result.

    Includes optional ADR-045 compliant governance metadata fields for
    integration with AshMatics governance frameworks (ISO 42001, etc.).
    These fields are optional and backward compatible - existing code
    that doesn't use them will continue to work.
    """

    # Document identification
    document_id: str  # Unique document/chunk identifier
    content: str  # Document/chunk text content

    # Search metadata
    score: float  # Similarity score (higher is more similar)
    distance: float | None = None  # Distance metric value (if available)
    rank: int = 0  # Result rank (1-indexed)

    # Document metadata (generic, provider-agnostic)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Vector data (optional, for debugging)
    embedding: list[float] | None = None

    # ==========================================================================
    # ADR-045 Governance Metadata (optional, backward compatible)
    # These fields support integration with AshMatics governance frameworks
    # ==========================================================================

    # Domain classification for governance artifacts
    # Values: "policy", "process", "control", "sop", "template", etc.
    domain: str | None = None

    # ISO 42001 / governance control references
    # Example: ["5.1", "6.2.1", "7.3"]
    control_refs: list[str] = field(default_factory=list)

    # Governance framework token references
    # Example: ["TK-001", "TK-042", "TK-RISK-001"]
    token_refs: list[str] = field(default_factory=list)

    # Document type classification
    # Values: "template", "exemplar", "guidance", "procedure", etc.
    document_type: str | None = None

    # Original document URI/path
    source_uri: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert result to dictionary."""
        result = {
            "document_id": self.document_id,
            "content": self.content,
            "score": self.score,
            "distance": self.distance,
            "rank": self.rank,
            "metadata": self.metadata,
            "has_embedding": self.embedding is not None,
        }

        # Include ADR-045 fields only if set (backward compatible)
        if self.domain:
            result["domain"] = self.domain
        if self.control_refs:
            result["control_refs"] = self.control_refs
        if self.token_refs:
            result["token_refs"] = self.token_refs
        if self.document_type:
            result["document_type"] = self.document_type
        if self.source_uri:
            result["source_uri"] = self.source_uri

        return result


@dataclass
class IndexInfo:
    """Information about a vector index."""

    name: str  # Index name
    collection_name: str  # Collection/table name
    index_type: IndexType  # Index type
    dimensions: int  # Vector dimensions
    distance_metric: DistanceMetric  # Distance metric
    num_vectors: int | None = None  # Number of vectors indexed
    index_size_bytes: int | None = None  # Index size in bytes
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert index info to dictionary."""
        return {
            "name": self.name,
            "collection_name": self.collection_name,
            "index_type": self.index_type.value,
            "dimensions": self.dimensions,
            "distance_metric": self.distance_metric.value,
            "num_vectors": self.num_vectors,
            "index_size_bytes": self.index_size_bytes,
            "metadata": self.metadata,
        }


class VectorStore(ABC):
    """
    Abstract base class for vector storage.

    All vector store implementations must inherit from this class and implement
    its abstract methods.
    """

    def __init__(self, config: VectorStoreConfig | None = None):
        """
        Initialize vector store with configuration.

        Args:
            config: Vector store configuration. If None, uses default config.
        """
        self.config = config or VectorStoreConfig()

    @abstractmethod
    async def store_embedding(
        self,
        document_id: str,
        embedding: list[float],
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """
        Store a single document embedding.

        Args:
            document_id: Unique identifier for the document
            embedding: Vector embedding
            content: Document text content
            metadata: Optional metadata to store with the document

        Returns:
            True if successful, False otherwise

        Raises:
            Exception: If storage fails after retries
        """

    @abstractmethod
    async def store_embeddings_batch(
        self,
        chunks: list[DocumentChunk],
        progress_callback: Callable | None = None,
    ) -> tuple[int, int]:
        """
        Store multiple document embeddings in batch.

        Args:
            chunks: List of DocumentChunk objects with embeddings
            progress_callback: Optional callback for progress updates

        Returns:
            Tuple of (successful_count, failed_count)

        Raises:
            Exception: If batch storage fails critically
        """

    @abstractmethod
    async def similarity_search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        min_score: float | None = None,
    ) -> list[SearchResult]:
        """
        Perform vector similarity search.

        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            filters: Optional metadata filters (provider-specific syntax)
            min_score: Optional minimum similarity score threshold

        Returns:
            List of SearchResult objects, ranked by similarity

        Raises:
            Exception: If search fails
        """

    @abstractmethod
    async def create_index(
        self,
        index_name: str | None = None,
        index_type: IndexType | None = None,
        force_recreate: bool = False,
    ) -> bool:
        """
        Create or update vector index.

        Args:
            index_name: Optional custom index name
            index_type: Optional index type override
            force_recreate: If True, drop existing index and recreate

        Returns:
            True if index created/updated successfully

        Raises:
            Exception: If index creation fails
        """

    @abstractmethod
    async def delete_index(self, index_name: str | None = None) -> bool:
        """
        Delete vector index.

        Args:
            index_name: Optional index name (uses default if not provided)

        Returns:
            True if deleted successfully

        Raises:
            Exception: If deletion fails
        """

    @abstractmethod
    async def get_index_info(self, index_name: str | None = None) -> IndexInfo | None:
        """
        Get information about a vector index.

        Args:
            index_name: Optional index name (uses default if not provided)

        Returns:
            IndexInfo object if index exists, None otherwise
        """

    @abstractmethod
    async def health_check(self) -> bool:
        """
        Check if vector store is operational.

        Returns:
            True if store is healthy and accessible

        Raises:
            Exception: If health check fails critically
        """

    async def delete_document(self, document_id: str) -> bool:
        """
        Delete a document by ID (optional, may not be supported by all providers).

        Args:
            document_id: Document identifier

        Returns:
            True if deleted successfully
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support document deletion")

    async def count_documents(self) -> int:
        """
        Count total documents in the collection (optional).

        Returns:
            Total number of documents
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support document counting")

    def get_provider(self) -> VectorStoreProvider:
        """
        Get the vector store provider.

        Returns:
            VectorStoreProvider enum value
        """
        return self.config.provider

    def __repr__(self) -> str:
        """String representation of vector store."""
        return (
            f"{self.__class__.__name__}("
            f"provider={self.config.provider}, "
            f"collection={self.config.collection_name})"
        )
