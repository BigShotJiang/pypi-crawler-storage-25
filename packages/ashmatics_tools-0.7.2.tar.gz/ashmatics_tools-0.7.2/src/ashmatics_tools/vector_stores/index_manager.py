"""Vector index management utilities for MongoDB/CosmosDB.

last updated: 2025-12-22, VectorIndexManager created.

This module provides synchronous, CLI-friendly utilities for managing vector
indexes on MongoDB/CosmosDB collections. It complements the async VectorStore
classes which are designed for programmatic pipeline use.

Features:
- Create/drop vector indexes (IVF, HNSW)
- Create metadata indexes for filtering
- Collection statistics and health checks
- Batch document clearing with filters

Usage:
    >>> from ashmatics_tools.vector_stores import VectorIndexManager
    >>>
    >>> manager = VectorIndexManager(
    ...     uri="mongodb://...",
    ...     db_name="ai_strategy",
    ...     collection_name="my_vectors",
    ... )
    >>> manager.connect()
    >>> manager.create_vector_index(index_type="ivf")
    >>> stats = manager.get_stats()
    >>> manager.close()

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
from dataclasses import dataclass
from typing import Any

from pymongo import MongoClient
from pymongo.errors import OperationFailure

logger = logging.getLogger(__name__)


@dataclass
class VectorCollectionStats:
    """Statistics for a vector collection."""

    document_count: int
    has_vector_index: bool
    index_type: str | None
    index_name: str | None
    index_count: int
    indexes: list[str]
    has_embeddings: bool
    actual_dimensions: int | None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document_count": self.document_count,
            "has_vector_index": self.has_vector_index,
            "index_type": self.index_type,
            "index_name": self.index_name,
            "index_count": self.index_count,
            "indexes": self.indexes,
            "has_embeddings": self.has_embeddings,
            "actual_dimensions": self.actual_dimensions,
        }


class VectorIndexManager:
    """
    Synchronous vector index manager for MongoDB/CosmosDB collections.

    This utility class provides CLI-friendly operations for managing vector
    indexes and collections. For async programmatic use, see CosmosDBVectorStore.

    Supports:
    - CosmosDB vCore with native vector search (cosmosSearch)
    - MongoDB Atlas with Atlas Vector Search
    - Index types: HNSW (fast queries) and IVF (memory efficient)
    - Similarity metrics: Cosine, Euclidean (L2), Inner Product

    Note: CosmosDB M25 tier supports IVF only; HNSW requires M40+.
    """

    def __init__(
        self,
        uri: str,
        db_name: str,
        collection_name: str,
        embedding_field: str = "embedding",
        dimensions: int = 1536,
        index_name: str = "vector_search_index",
    ):
        """
        Initialize the vector index manager.

        Args:
            uri: MongoDB/CosmosDB connection string
            db_name: Database name
            collection_name: Collection name containing embeddings
            embedding_field: Name of the field containing vectors (default: embedding)
            dimensions: Embedding dimensions (default: 1536 for text-embedding-3-small)
            index_name: Name for the vector index (default: vector_search_index)
        """
        self.uri = uri
        self.db_name = db_name
        self.collection_name = collection_name
        self.embedding_field = embedding_field
        self.dimensions = dimensions
        self.index_name = index_name

        self._client: MongoClient | None = None
        self._collection = None

    def connect(self) -> None:
        """
        Establish MongoDB connection.

        Raises:
            Exception: If connection fails
        """
        self._client = MongoClient(self.uri)
        self._collection = self._client[self.db_name][self.collection_name]

        # Test connection
        self._client.admin.command("ping")
        logger.info(f"Connected to {self.db_name}.{self.collection_name}")

    def close(self) -> None:
        """Close the MongoDB connection."""
        if self._client:
            self._client.close()
            self._client = None
            self._collection = None

    def _ensure_connected(self) -> None:
        """Ensure we have an active connection."""
        if self._collection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    def get_stats(self) -> VectorCollectionStats:
        """
        Get collection statistics.

        Returns:
            VectorCollectionStats with document count, index info, etc.
        """
        self._ensure_connected()

        count = self._collection.count_documents({})
        indexes = list(self._collection.list_indexes())

        # Detect vector index
        vector_index_info = None
        for idx in indexes:
            if idx.get("name") == self.index_name:
                opts = idx.get("cosmosSearchOptions", {})
                vector_index_info = {
                    "name": idx.get("name"),
                    "type": opts.get("kind", "unknown"),
                    "dimensions": opts.get("dimensions"),
                    "similarity": opts.get("similarity"),
                }
                break

        # Sample document to verify embedding field
        sample = self._collection.find_one({self.embedding_field: {"$exists": True}})
        has_embeddings = sample is not None
        actual_dimensions = len(sample.get(self.embedding_field, [])) if sample else None

        return VectorCollectionStats(
            document_count=count,
            has_vector_index=vector_index_info is not None,
            index_type=vector_index_info["type"] if vector_index_info else None,
            index_name=vector_index_info["name"] if vector_index_info else None,
            index_count=len(indexes),
            indexes=[idx.get("name") for idx in indexes],
            has_embeddings=has_embeddings,
            actual_dimensions=actual_dimensions,
        )

    def list_indexes(self) -> list[dict]:
        """List all indexes on the collection."""
        self._ensure_connected()
        return list(self._collection.list_indexes())

    def check_vector_index_exists(self) -> bool:
        """Check if vector search index exists."""
        indexes = self.list_indexes()
        return any(idx.get("name") == self.index_name for idx in indexes)

    def create_vector_index(
        self,
        index_type: str = "ivf",
        similarity: str = "COS",
        force: bool = False,
        hnsw_m: int = 16,
        hnsw_ef_construction: int = 64,
        ivf_num_lists: int = 100,
    ) -> bool:
        """
        Create vector search index on the embedding field.

        Args:
            index_type: "ivf" (CosmosDB compatible) or "hnsw" (requires higher tier)
            similarity: "COS" (cosine), "L2" (euclidean), or "IP" (inner product)
            force: If True, drop existing index first
            hnsw_m: HNSW max connections per layer (default: 16)
            hnsw_ef_construction: HNSW construction list size (default: 64)
            ivf_num_lists: IVF number of clusters (default: 100)

        Returns:
            True if index was created or already exists

        Raises:
            OperationFailure: If index creation fails (e.g., HNSW not supported on tier)
        """
        self._ensure_connected()

        # Check existing
        if self.check_vector_index_exists():
            if force:
                logger.info(f"Dropping existing index: {self.index_name}")
                try:
                    self._collection.drop_index(self.index_name)
                except Exception as e:
                    logger.error(f"Failed to drop index: {e}")
                    return False
            else:
                logger.info(f"Vector index already exists: {self.index_name}")
                return True

        # Build index definition for CosmosDB vCore
        if index_type.lower() == "hnsw":
            index_definition = {
                "name": self.index_name,
                "key": {self.embedding_field: "cosmosSearch"},
                "cosmosSearchOptions": {
                    "kind": "vector-hnsw",
                    "m": hnsw_m,
                    "efConstruction": hnsw_ef_construction,
                    "similarity": similarity,
                    "dimensions": self.dimensions,
                },
            }
        else:
            index_definition = {
                "name": self.index_name,
                "key": {self.embedding_field: "cosmosSearch"},
                "cosmosSearchOptions": {
                    "kind": "vector-ivf",
                    "numLists": ivf_num_lists,
                    "similarity": similarity,
                    "dimensions": self.dimensions,
                },
            }

        logger.info(f"Creating {index_type.upper()} vector index on {self.embedding_field}")

        try:
            self._collection.database.command(
                "createIndexes",
                self._collection.name,
                indexes=[index_definition],
            )
            logger.info(f"Vector index '{self.index_name}' created successfully")
            return True

        except OperationFailure as e:
            if "already exists" in str(e):
                logger.info("Index already exists (created by another process)")
                return True
            logger.error(f"Failed to create index: {e}")
            raise

    def create_metadata_indexes(self, fields: list[str] | None = None) -> int:
        """
        Create indexes on metadata fields for efficient filtering.

        Args:
            fields: List of field names to index. If None, uses common defaults:
                    ['artifact_id', 'metadata.process_domain', 'metadata.content_format']

        Returns:
            Number of indexes created
        """
        self._ensure_connected()

        if fields is None:
            fields = [
                "artifact_id",
                "metadata.process_domain",
                "metadata.content_format",
                "section_title",
            ]

        created = 0
        for field in fields:
            try:
                self._collection.create_index([(field, 1)])
                logger.info(f"Created index on {field}")
                created += 1
            except Exception as e:
                logger.warning(f"Failed to create index on {field}: {e}")

        return created

    def drop_vector_index(self) -> bool:
        """
        Drop the vector search index (keeps data, removes index).

        Returns:
            True if dropped successfully or didn't exist
        """
        self._ensure_connected()

        if not self.check_vector_index_exists():
            logger.info("No vector index to drop")
            return True

        try:
            self._collection.drop_index(self.index_name)
            logger.info(f"Dropped vector index: {self.index_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to drop index: {e}")
            return False

    def drop_index(self, index_name: str) -> bool:
        """
        Drop a specific index by name.

        Args:
            index_name: Name of the index to drop

        Returns:
            True if dropped successfully
        """
        self._ensure_connected()

        try:
            self._collection.drop_index(index_name)
            logger.info(f"Dropped index: {index_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to drop index {index_name}: {e}")
            return False

    def clear_documents(self, filter_query: dict[str, Any] | None = None) -> int:
        """
        Delete documents from the collection.

        Args:
            filter_query: MongoDB filter query. If None, deletes ALL documents.

        Returns:
            Number of documents deleted
        """
        self._ensure_connected()

        query = filter_query or {}
        result = self._collection.delete_many(query)
        logger.info(f"Deleted {result.deleted_count} documents")
        return result.deleted_count

    def clear_by_prefix(self, field: str, prefix: str) -> int:
        """
        Delete documents where a field starts with a prefix.

        Args:
            field: Field name to match (e.g., 'artifact_id')
            prefix: Prefix to match (e.g., 'SOP-PV')

        Returns:
            Number of documents deleted
        """
        query = {field: {"$regex": f"^{prefix}"}}
        return self.clear_documents(query)

    def reset(self, keep_index: bool = False) -> bool:
        """
        Full reset: delete all documents and optionally the index.

        Args:
            keep_index: If True, only delete documents but keep the index structure

        Returns:
            True if reset was successful
        """
        logger.warning("Resetting vector collection...")

        # Delete all documents
        self.clear_documents()

        # Optionally drop index
        if not keep_index:
            self.drop_vector_index()

        logger.info("Reset complete")
        return True

    def __enter__(self) -> "VectorIndexManager":
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()

    def __repr__(self) -> str:
        """String representation."""
        return f"VectorIndexManager({self.db_name}.{self.collection_name})"
