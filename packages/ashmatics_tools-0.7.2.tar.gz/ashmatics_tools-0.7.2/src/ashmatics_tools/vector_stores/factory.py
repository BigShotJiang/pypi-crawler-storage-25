"""Factory for creating vector store instances.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging

from .base import VectorStore, VectorStoreConfig, VectorStoreProvider

logger = logging.getLogger(__name__)


def create_vector_store(
    provider: str = "cosmosdb", config: VectorStoreConfig | None = None
) -> VectorStore:
    """
    Create a vector store instance.

    Args:
        provider: Vector store provider ("cosmosdb", "pgvector", "qdrant")
        config: Vector store configuration. If None, uses default config.

    Returns:
        Initialized vector store instance

    Raises:
        ValueError: If provider is not recognized
        ImportError: If required provider library is not installed

    Example:
        >>> # Create a CosmosDB vector store with default config
        >>> vector_store = create_vector_store("cosmosdb")
        >>>
        >>> # Create with custom config
        >>> config = VectorStoreConfig(
        ...     provider=VectorStoreProvider.COSMOSDB,
        ...     connection_string=os.getenv("COSMOS_CONNECTION_STRING"),
        ...     database_name="ashmatics_vectors",
        ...     collection_name="embedded_documents",
        ...     dimensions=1536
        ... )
        >>> vector_store = create_vector_store("cosmosdb", config)
        >>>
        >>> # Store embeddings
        >>> await vector_store.store_embeddings_batch(embedded_chunks)
        >>>
        >>> # Search
        >>> results = await vector_store.similarity_search(
        ...     query_embedding=query_embedding,
        ...     top_k=10
        ... )
    """
    provider = provider.lower()

    # Create default config if not provided
    if config is None:
        try:
            provider_enum = VectorStoreProvider(provider)
            config = VectorStoreConfig(provider=provider_enum)
        except ValueError:
            available = ", ".join([p.value for p in VectorStoreProvider])
            raise ValueError(
                f"Unknown vector store provider: {provider}. Available providers: {available}"
            )

    # Create vector store based on provider
    if provider == "cosmosdb" or config.provider == VectorStoreProvider.COSMOSDB:
        try:
            from .cosmosdb_store import CosmosDBVectorStore

            return CosmosDBVectorStore(config)
        except ImportError as e:
            raise ImportError(
                "CosmosDB vector store requires 'pymongo' package. "
                "Install with: pip install pymongo"
            ) from e

    elif provider == "pgvector" or config.provider == VectorStoreProvider.PGVECTOR:
        try:
            from .pgvector_store import PgVectorStore

            return PgVectorStore(config)
        except ImportError as e:
            raise ImportError(
                "PgVector store requires 'asyncpg' and 'pgvector' packages. "
                "Install with: pip install asyncpg pgvector"
            ) from e

    elif provider == "qdrant" or config.provider == VectorStoreProvider.QDRANT:
        try:
            from .qdrant_store import QdrantVectorStore

            return QdrantVectorStore(config)
        except ImportError as e:
            raise ImportError(
                "Qdrant vector store requires 'qdrant-client' package. "
                "Install with: pip install qdrant-client"
            ) from e

    else:
        available = ", ".join([p.value for p in VectorStoreProvider])
        raise ValueError(
            f"Unknown vector store provider: {provider}. Available providers: {available}"
        )
