"""Vector storage implementations for document embeddings.

This module provides a unified interface for storing and searching document embeddings
across multiple vector database providers.

Supported Providers:
- CosmosDB (MongoDB vCore API) - Azure-native vector storage
- PostgreSQL pgvector - Open-source vector extension for PostgreSQL
- Qdrant - High-performance vector database

Usage:
    >>> from src.common.vector_stores import create_vector_store, VectorStoreConfig
    >>>
    >>> # Create a vector store
    >>> config = VectorStoreConfig(
    ...     connection_string="mongodb://...",
    ...     database_name="ashmatics_vectors",
    ...     collection_name="embedded_documents",
    ...     dimensions=1536
    ... )
    >>> vector_store = create_vector_store("cosmosdb", config)
    >>>
    >>> # Store embeddings
    >>> await vector_store.store_embeddings_batch(embedded_chunks)
    >>>
    >>> # Search
    >>> results = await vector_store.similarity_search(
    ...     query_embedding=query_vector,
    ...     top_k=10
    ... )

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

# Base classes and enums
from .base import (
    DistanceMetric,
    IndexInfo,
    IndexType,
    SearchResult,
    VectorStore,
    VectorStoreConfig,
    VectorStoreProvider,
)

# Factory function
from .factory import create_vector_store

# Index management utilities
from .index_manager import VectorCollectionStats, VectorIndexManager

# Provider implementations (optional direct imports)
try:
    from .cosmosdb_store import CosmosDBVectorStore
except ImportError:
    CosmosDBVectorStore = None

try:
    from .pgvector_store import PgVectorStore
except ImportError:
    PgVectorStore = None

try:
    from .qdrant_store import QdrantVectorStore
except ImportError:
    QdrantVectorStore = None

__all__ = [
    # Factory
    "create_vector_store",
    # Base classes
    "VectorStore",
    "VectorStoreConfig",
    "SearchResult",
    "IndexInfo",
    # Enums
    "VectorStoreProvider",
    "DistanceMetric",
    "IndexType",
    # Index management utilities
    "VectorIndexManager",
    "VectorCollectionStats",
    # Provider implementations (if available)
    "CosmosDBVectorStore",
    "PgVectorStore",
    "QdrantVectorStore",
]

__version__ = "1.0.0"
