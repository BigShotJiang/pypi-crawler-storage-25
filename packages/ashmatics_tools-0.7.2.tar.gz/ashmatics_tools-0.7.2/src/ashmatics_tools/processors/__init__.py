"""Document processors for MongoDB integration.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from .base import DocumentProcessor

__all__ = ["DocumentProcessor"]
