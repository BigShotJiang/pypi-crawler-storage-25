"""Abstract base class for document processors with MongoDB integration.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import json
import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

logger = logging.getLogger(__name__)

# Check if pymongo is available
try:
    from pymongo import MongoClient  # type: ignore[import-not-found]

    PYMONGO_AVAILABLE = True
except ImportError:
    PYMONGO_AVAILABLE = False
    MongoClient = None  # type: ignore


class DocumentProcessor(ABC):
    """
    Abstract base class for document processors.

    Each subclass handles a specific type of document with its own parsing logic.
    Provides MongoDB integration for document storage and retrieval.

    Note: Requires pymongo to be installed. Install with: pip install ashmatics-tools[mongodb]
    """

    def __init__(
        self, mongo_client: Any, db_name: str = "ai_strategy", collection_name: str | None = None
    ):
        """
        Initialize the document processor.

        Args:
            mongo_client: MongoDB client connection (pymongo.MongoClient instance)
            db_name: Name of the database (default: "ai_strategy")
            collection_name: Name of the collection to store documents in.
                           If not provided, uses lowercase class name.

        Raises:
            ImportError: If pymongo is not installed
        """
        if not PYMONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for DocumentProcessor. "
                "Install with: pip install ashmatics-tools[mongodb]"
            )

        self.mongo_client = mongo_client
        self.db = mongo_client[db_name]
        # Use class name as default collection name if not provided
        self.collection_name = collection_name or self.__class__.__name__.lower()
        logger.info(
            f"Initialized {self.__class__.__name__} with collection: {self.collection_name}"
        )

    @abstractmethod
    def extract_metadata(self, content: str) -> dict[str, Any]:
        """
        Extract metadata from document content.
        Must be implemented by subclasses.

        Args:
            content: Document content to extract metadata from

        Returns:
            Dictionary of extracted metadata

        Example:
            >>> def extract_metadata(self, content: str) -> dict:
            ...     return {"title": "...", "author": "..."}
        """
        pass

    @abstractmethod
    def clean_text(self, text: str) -> str:
        """
        Clean and format extracted text.
        Must be implemented by subclasses.

        Args:
            text: Text to clean

        Returns:
            Cleaned text

        Example:
            >>> def clean_text(self, text: str) -> str:
            ...     return text.strip().lower()
        """
        pass

    @abstractmethod
    def get_identifier_key(self) -> str:
        """
        Get the key to use as a unique identifier for documents.
        Must be implemented by subclasses.

        Returns:
            String name of the identifier field

        Example:
            >>> def get_identifier_key(self) -> str:
            ...     return "document_id"
        """
        pass

    @abstractmethod
    def get_document_type(self) -> str:
        """
        Get the document type for categorization.
        Must be implemented by subclasses.

        Returns:
            String name of the document type

        Example:
            >>> def get_document_type(self) -> str:
            ...     return "fda_clearance"
        """
        pass

    @abstractmethod
    def process_document(self, content: dict[str, Any]) -> dict[str, Any]:
        """
        Process a single document.
        Must be implemented by subclasses.

        Args:
            content: Document content and metadata

        Returns:
            Processed document data ready for storage

        Example:
            >>> def process_document(self, content: dict) -> dict:
            ...     return {"id": content["id"], "text": self.clean_text(content["text"])}
        """
        pass

    @abstractmethod
    def process_documents_from_path(self, path: str) -> list:
        """
        Process documents from a directory path.
        Must be implemented by subclasses.

        Args:
            path: Path to directory containing documents to be ingested

        Returns:
            List of processed documents

        Example:
            >>> def process_documents_from_path(self, path: str) -> list:
            ...     documents = []
            ...     for file in os.listdir(path):
            ...         documents.append(self.process_document(load_file(file)))
            ...     return documents
        """
        pass

    def update_document(
        self, document_data: dict[str, Any], additional_metadata_fields: list[str] | None = None
    ) -> tuple[bool, Any | None]:
        """
        Update or insert document in MongoDB collection using upsert.

        Args:
            document_data: Document data to update/insert
            additional_metadata_fields: Optional list of field names to include
                                       in metadata extraction (for SQL sync)

        Returns:
            tuple: (success, document_id) where success is a boolean indicating
                  if the update was successful, and document_id is the MongoDB
                  ObjectId of the document

        Raises:
            ValueError: If no valid identifier is found in document_data
        """
        try:
            collection = self.db[self.collection_name]

            # Use the document identifier as a unique key for upsert
            identifier_key = self.get_identifier_key()
            identifier_value = document_data.get(identifier_key)

            if not identifier_value:
                logger.warning(
                    f"No identifier ({identifier_key}) found in document data, "
                    f"attempting fallback to 'pdf_path'"
                )
                # Fall back to using the file path if available
                identifier_key = "pdf_path"
                identifier_value = document_data.get(identifier_key)

                if not identifier_value:
                    logger.error("No valid identifier found for document")
                    raise ValueError(
                        f"Document must contain either '{self.get_identifier_key()}' "
                        f"or 'pdf_path' field"
                    )

            # Add standard metadata fields
            document_data.update(
                {
                    "document_type": self.get_document_type(),
                    "updated_at": datetime.utcnow(),
                    "indexed_at": datetime.utcnow(),
                }
            )

            result = collection.update_one(
                {identifier_key: identifier_value}, {"$set": document_data}, upsert=True
            )

            # Get the MongoDB ID of the document
            if result.upserted_id:
                # If this was a new document (insert)
                document_id = result.upserted_id
                logger.info(
                    f"Inserted new document in {self.collection_name}: "
                    f"{identifier_value}, MongoDB ID: {document_id}"
                )
            else:
                # If this was an update to an existing document
                doc = collection.find_one({identifier_key: identifier_value})
                document_id = doc.get("_id") if doc else None
                logger.info(
                    f"Updated existing document in {self.collection_name}: "
                    f"{identifier_value}, MongoDB ID: {document_id}"
                )

            return result.acknowledged, document_id

        except Exception as e:
            logger.error(
                f"Error updating document in {self.collection_name}: {str(e)}", exc_info=True
            )
            return False, None

    def process_document_from_dict(
        self, doc: dict[str, Any], metadata_fields: list[str] | None = None
    ) -> list[tuple[bool, Any | None, dict[str, Any]]]:
        """
        Process one or more documents from a dictionary.

        Args:
            doc: Dictionary mapping keys to document content
            metadata_fields: Optional list of field names to extract for metadata

        Returns:
            List of tuples (success, document_id, metadata) for each processed document
        """
        results: list[tuple[bool, Any | None, dict[str, Any]]] = []
        metadata_fields = metadata_fields or []

        for key, content in doc.items():
            try:
                document_data = self.process_document(content)
                if document_data:
                    success, doc_id = self.update_document(document_data)
                    if success:
                        # Create metadata entry with document ID and key fields
                        metadata = {
                            "file_path": key,
                            self.get_identifier_key(): document_data.get(self.get_identifier_key()),
                        }
                        # Add requested metadata fields
                        for field in metadata_fields:
                            if field in document_data:
                                metadata[field] = document_data[field]

                        results.append((success, doc_id, metadata))
            except Exception as e:
                logger.error(f"Error processing document {key}: {e}", exc_info=True)
                continue

        return results

    def process_documents_from_json(
        self, json_path: str, metadata_fields: list[str] | None = None
    ) -> list[tuple[bool, Any | None, dict[str, Any]]]:
        """
        Process documents from a JSON file.

        Args:
            json_path: Path to JSON file containing documents
            metadata_fields: Optional list of field names to extract for metadata

        Returns:
            List of tuples (success, document_id, metadata) for each processed document
        """
        results: list[tuple[bool, Any | None, dict[str, Any]]] = []
        metadata_fields = metadata_fields or []

        try:
            with open(json_path) as f:
                documents = json.load(f)

            logger.info(f"Processing documents from {json_path}")

            for doc in documents:
                for file_path, content in doc.items():
                    try:
                        document_data = self.process_document(content)
                        if document_data:
                            success, doc_id = self.update_document(document_data)
                            if success:
                                # Create metadata entry with document ID and key fields
                                metadata = {
                                    "file_path": file_path,
                                    self.get_identifier_key(): document_data.get(
                                        self.get_identifier_key()
                                    ),
                                }
                                # Add requested metadata fields
                                for field in metadata_fields:
                                    if field in document_data:
                                        metadata[field] = document_data[field]

                                results.append((success, doc_id, metadata))

                    except Exception as e:
                        logger.error(f"Error processing document {file_path}: {e}", exc_info=True)
                        continue

            logger.info(f"Successfully processed {len(results)} documents from {json_path}")
            return results

        except Exception as e:
            logger.error(f"Error loading JSON file {json_path}: {e}", exc_info=True)
            return results
