"""Document parsing utilities with pluggable parser implementations.

This module provides abstract base classes and concrete implementations for
parsing various document formats (PDF, DOCX, etc.) into structured markdown.

Supported Parsers:
- DoclingParser: Uses Docling for advanced PDF parsing with table/figure extraction
- LlamaParser: Uses LlamaParse cloud service for high-quality parsing
- SimpleParser: Basic fallback parser for simple documents

Usage:
    from common.parsers import create_parser

    # Create a parser
    parser = create_parser("docling")

    # Parse a document
    result = await parser.parse_file("document.pdf")
    print(result.markdown)

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from .base import (
    DocumentParser,
    ParsedDocument,
    ParsedSection,
    TableData,
    FigureData,
    ParseError,
    ParserCapabilities,
    ParserConfig,
    ParserType,
)
from .factory import create_parser, get_available_parsers

__all__ = [
    "DocumentParser",
    "ParsedDocument",
    "ParsedSection",
    "TableData",
    "FigureData",
    "ParserConfig",
    "ParserType",
    "ParseError",
    "ParserCapabilities",
    "create_parser",
    "get_available_parsers",
]
