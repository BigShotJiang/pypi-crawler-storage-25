"""Docling-based document parser with M1 Mac optimizations.

This parser uses the Docling library for advanced PDF parsing with:
- Table extraction and preservation
- Figure/image extraction
- Multi-column layout handling
- Section hierarchy detection
- Optimized for Apple Silicon (M1/M2/M3) performance

Requires optional dependencies: pip install ashmatics-tools[parsers]

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import asyncio
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from .base import (
    DocumentParser,
    FigureData,
    ParsedDocument,
    ParsedSection,
    ParseError,
    ParserCapabilities,
    ParserConfig,
    TableData,
)

logger = logging.getLogger(__name__)

# Track availability of optional dependencies
_DOCLING_AVAILABLE = False

try:
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import (
        PdfPipelineOptions,
        TableFormerMode,
    )
    from docling.document_converter import DocumentConverter, PdfFormatOption

    _DOCLING_AVAILABLE = True
except ImportError:
    InputFormat = None  # type: ignore[misc, assignment]
    PdfPipelineOptions = None  # type: ignore[misc, assignment]
    TableFormerMode = None  # type: ignore[misc, assignment]
    DocumentConverter = None  # type: ignore[misc, assignment]
    PdfFormatOption = None  # type: ignore[misc, assignment]
    logger.debug("docling not available - DoclingParser will not work")

# Use TYPE_CHECKING for type hints only
if TYPE_CHECKING:
    from docling_core.types.doc import DoclingDocument


def _check_dependencies() -> None:
    """Check that required dependencies are available."""
    if not _DOCLING_AVAILABLE:
        raise ImportError(
            "DoclingParser requires the 'docling' package. "
            "Install with: pip install ashmatics-tools[parsers]"
        )


class DoclingParser(DocumentParser):
    """
    Docling-based parser for PDF documents.

    Optimized for:
    - M1 Mac performance (uses PyTorch MPS backend)
    - Table extraction (preserves structure)
    - Figure extraction (with captions)
    - Section hierarchy detection
    - Multi-column layouts
    """

    def __init__(self, config: ParserConfig | None = None):
        """
        Initialize Docling parser.

        Args:
            config: Parser configuration

        Raises:
            ImportError: If docling package is not installed
        """
        # Check dependencies before initialization
        _check_dependencies()

        super().__init__(config)

        # Configure pipeline options for M1 Mac optimization
        pipeline_options = PdfPipelineOptions()  # type: ignore[misc]

        # Table extraction settings
        if self.config.extract_tables:
            pipeline_options.do_table_structure = True
            # Use FAST mode for M1 optimization (ACCURATE is slower but more precise)
            # Can be overridden via extra_config
            table_mode = self.config.extra_config.get("table_mode", TableFormerMode.FAST)
            pipeline_options.table_structure_options.mode = table_mode
        else:
            pipeline_options.do_table_structure = False

        # OCR settings
        pipeline_options.do_ocr = self.config.enable_ocr
        if self.config.enable_ocr:
            pipeline_options.ocr_options.lang = [self.config.ocr_language]

        # Figure extraction
        pipeline_options.images_scale = (
            2.0 if self.config.extract_figures else 1.0
        )  # Higher resolution for figures
        pipeline_options.generate_picture_images = self.config.extract_figures

        # Configure format options
        format_options = {InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)}

        # Initialize converter
        # Note: Docling will automatically use MPS (Metal Performance Shaders) on M1 Macs
        # if PyTorch is installed with MPS support
        self.converter = DocumentConverter(format_options=format_options)

        logger.info(
            f"Docling parser initialized with table_mode={pipeline_options.table_structure_options.mode}"
        )

    def get_capabilities(self) -> ParserCapabilities:
        """Get capabilities of Docling parser."""
        return ParserCapabilities(
            supports_tables=True,
            supports_figures=True,
            supports_ocr=self.config.enable_ocr,
            supports_multi_column=True,
            supports_batch=True,
            supports_async=True,
            max_file_size_mb=None,  # No hard limit
            supported_formats=[".pdf", ".docx", ".pptx", ".html", ".md"],
        )

    async def parse_file(self, file_path: str | Path, **kwargs) -> ParsedDocument:
        """
        Parse a document file using Docling.

        Args:
            file_path: Path to the document file
            **kwargs: Additional arguments (ignored)

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
            FileNotFoundError: If file doesn't exist
        """
        file_path = Path(file_path)

        # Validate file
        if not self.validate_file(file_path):
            raise ParseError(f"File cannot be parsed by Docling: {file_path.suffix} format")

        start_time = time.time()

        try:
            logger.info(f"Parsing document: {file_path}")

            # Run Docling conversion in thread pool (it's CPU-intensive)
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, self._convert_document, str(file_path))

            # Extract document content
            docling_doc = result.document

            # Run all CPU-intensive extraction operations in thread pool for true concurrency
            markdown, text, sections, tables, figures, metadata = await loop.run_in_executor(
                None,
                self._extract_all_data,
                docling_doc
            )

            processing_time = time.time() - start_time

            logger.info(
                f"Parsed {file_path.name} in {processing_time:.2f}s "
                f"({len(sections)} sections, {len(tables)} tables, {len(figures)} figures)"
            )

            return ParsedDocument(
                markdown=markdown,
                text=text,
                sections=sections,
                tables=tables,
                figures=figures,
                title=metadata.get("title"),
                num_pages=metadata.get("num_pages"),
                metadata=metadata,
                parser_type="docling",
                parsed_at=datetime.now().isoformat(),
                processing_time_seconds=processing_time,
                docling_document=docling_doc,
            )

        except Exception as e:
            logger.error(f"Failed to parse {file_path}: {e}")
            raise ParseError(f"Docling parsing failed: {str(e)}", original_error=e)

    async def parse_bytes(
        self, content: bytes, filename: str | None = None, **kwargs
    ) -> ParsedDocument:
        """
        Parse document from bytes.

        Args:
            content: Document content as bytes
            filename: Optional filename (for format detection)
            **kwargs: Additional arguments

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
        """
        # Docling requires a file path, so we need to write to temp file
        import tempfile

        suffix = Path(filename).suffix if filename else ".pdf"

        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp_file:
            tmp_file.write(content)
            tmp_path = tmp_file.name

        try:
            result = await self.parse_file(tmp_path, **kwargs)
            return result
        finally:
            # Clean up temp file
            Path(tmp_path).unlink(missing_ok=True)

    async def parse_batch(self, file_paths: list[str | Path], **kwargs) -> list[ParsedDocument]:
        """
        Parse multiple documents with optimized batch processing.

        Args:
            file_paths: List of file paths to parse
            **kwargs: Additional arguments

        Returns:
            List of ParsedDocument objects
        """
        if not file_paths:
            return []

        logger.info(f"Batch parsing {len(file_paths)} documents")

        # Use semaphore to limit concurrent processing (M1 optimization)
        semaphore = asyncio.Semaphore(self.config.max_concurrent)

        async def parse_with_semaphore(file_path):
            async with semaphore:
                try:
                    return await self.parse_file(file_path, **kwargs)
                except Exception as e:
                    logger.error(f"Failed to parse {file_path}: {e}")
                    return None

        # Process all files concurrently (but limited by semaphore)
        tasks = [parse_with_semaphore(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks, return_exceptions=False)

        # Filter out failed parses
        successful = [r for r in results if r is not None]

        logger.info(f"Batch parsing complete: {len(successful)}/{len(file_paths)} successful")

        return successful

    def _convert_document(self, file_path: str):
        """
        Synchronous document conversion (runs in thread pool).

        Args:
            file_path: Path to document

        Returns:
            Conversion result
        """
        return self.converter.convert(file_path)

    def _extract_all_data(self, docling_doc: "DoclingDocument"):
        """
        Extract all data from docling document in one synchronous call.
        This runs in thread pool to avoid blocking the event loop.

        Args:
            docling_doc: Docling document

        Returns:
            Tuple of (markdown, text, sections, tables, figures, metadata)
        """
        markdown = docling_doc.export_to_markdown()
        text = docling_doc.export_to_text()
        sections = self._extract_sections(docling_doc)
        tables = self._extract_tables(docling_doc) if self.config.extract_tables else []
        figures = self._extract_figures(docling_doc) if self.config.extract_figures else []
        metadata = self._extract_metadata(docling_doc)

        return markdown, text, sections, tables, figures, metadata

    def _extract_sections(self, doc: "DoclingDocument") -> list[ParsedSection]:
        """
        Extract document sections with hierarchy.

        Args:
            doc: Docling document

        Returns:
            List of parsed sections
        """
        sections = []
        section_index = 0

        # Use the direct texts list from the document to find headers
        for text_item in doc.texts:
            # Get the item type name to determine if it's a heading
            item_type = type(text_item).__name__

            # Check if item is a heading/title type
            if item_type in ["TitleItem", "SectionHeaderItem"]:
                # Determine heading level based on type
                if item_type == "TitleItem":
                    level = 1
                elif item_type == "SectionHeaderItem":
                    level = 2
                else:
                    level = 3  # Default for other header types

                # Extract text content
                text_content = ""
                if hasattr(text_item, "text"):
                    text_content = text_item.text
                elif hasattr(text_item, "export_to_text"):
                    text_content = text_item.export_to_text()

                if text_content.strip():  # Only add if there's actual text
                    sections.append(
                        ParsedSection(
                            title=text_content.strip(),
                            content="",  # Content would need to be extracted from following items
                            level=level,
                            index=section_index,
                            metadata={
                                "item_type": item_type,
                                "label": getattr(text_item, "label", None),
                            },
                        )
                    )
                    section_index += 1

        return sections

    def _extract_tables(self, doc: "DoclingDocument") -> list[TableData]:
        """
        Extract tables from document.

        Args:
            doc: Docling document

        Returns:
            List of extracted tables
        """
        tables = []

        # Use the direct tables list from the document
        for table_index, table_item in enumerate(doc.tables):
            # Extract table as markdown with doc parameter to avoid deprecation warning
            table_md = table_item.export_to_markdown(doc=doc)

            # Get caption if available
            caption = getattr(table_item, "caption", None)
            if caption and hasattr(caption, "text"):
                caption = caption.text

            tables.append(
                TableData(
                    index=table_index,
                    caption=caption,
                    markdown=table_md,
                    metadata={
                        "num_rows": getattr(table_item.data, "num_rows", None),
                        "num_cols": getattr(table_item.data, "num_cols", None),
                    },
                )
            )

        return tables

    def _extract_figures(self, doc: "DoclingDocument") -> list[FigureData]:
        """
        Extract figures/images from document.

        Args:
            doc: Docling document

        Returns:
            List of extracted figures
        """
        figures = []

        # Use the direct pictures list from the document
        for figure_index, picture_item in enumerate(doc.pictures):
            # Get caption if available
            caption = getattr(picture_item, "caption", None)
            if caption and hasattr(caption, "text"):
                caption = caption.text

            # Get image data if available
            image_data = None
            if hasattr(picture_item, "image") and picture_item.image is not None:
                # Image data is available
                image_data = (
                    picture_item.image.pil_image
                    if hasattr(picture_item.image, "pil_image")
                    else None
                )

            figures.append(
                FigureData(
                    index=figure_index,
                    caption=caption,
                    image_data=image_data,
                    metadata={"uri": getattr(picture_item, "uri", None)},
                )
            )

        return figures

    def _extract_metadata(self, doc: "DoclingDocument") -> dict:
        """
        Extract document metadata from DoclingDocument and its origin.

        Args:
            doc: Docling document

        Returns:
            Metadata dictionary
        """
        metadata = {}

        # Extract metadata from document origin
        if doc.origin:
            origin = doc.origin
            metadata["filename"] = origin.filename
            metadata["mimetype"] = origin.mimetype
            metadata["binary_hash"] = origin.binary_hash
            if origin.uri:
                metadata["uri"] = str(origin.uri)

        # Extract document-level metadata
        metadata["document_name"] = doc.name
        metadata["schema_name"] = doc.schema_name
        metadata["version"] = doc.version

        # Get number of pages
        if doc.pages:
            metadata["num_pages"] = len(doc.pages)

        # Get title from document name or first heading/title item
        title = None
        if doc.name and doc.name.strip():
            title = doc.name
        else:
            # Look for title items in the document
            for item in doc.iterate_items():
                if hasattr(item, "text") and hasattr(item, "label"):
                    label_str = str(item.label).lower()
                    if "title" in label_str or "heading" in label_str:
                        title = item.text
                        break

        if title:
            metadata["title"] = title

        # Count different types of items
        item_counts = {}
        for item in doc.iterate_items():
            item_type = type(item).__name__
            item_counts[item_type] = item_counts.get(item_type, 0) + 1

        metadata["item_counts"] = item_counts

        return metadata

    async def health_check(self) -> bool:
        """
        Check if Docling parser is operational.

        Returns:
            True if parser is ready
        """
        try:
            # Simple check that converter is initialized
            return self.converter is not None
        except Exception as e:
            logger.error(f"Docling health check failed: {e}")
            return False
