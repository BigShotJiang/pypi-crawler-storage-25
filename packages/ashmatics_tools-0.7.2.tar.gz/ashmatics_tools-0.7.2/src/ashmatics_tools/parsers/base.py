"""Abstract base classes for document parsers.

This module defines the core interfaces that all parser implementations must follow,
ensuring consistency across different parsing backends (Docling, LlamaParse, etc.).

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

# Use TYPE_CHECKING to avoid importing heavy docling_core at runtime
# This allows the base module to be imported without pulling in torch/CUDA
if TYPE_CHECKING:
    from docling_core.types.doc import DoclingDocument


class ParserType(str, Enum):
    """Supported parser types."""

    DOCLING = "docling"
    LLAMA = "llama"
    SIMPLE = "simple"


class ParseError(Exception):
    """Exception raised when document parsing fails."""

    def __init__(self, message: str, original_error: Exception | None = None):
        super().__init__(message)
        self.original_error = original_error


@dataclass
class ParserCapabilities:
    """Describes capabilities of a parser implementation."""

    supports_tables: bool = False
    supports_figures: bool = False
    supports_ocr: bool = False
    supports_multi_column: bool = False
    supports_batch: bool = False
    supports_async: bool = True
    max_file_size_mb: int | None = None
    supported_formats: list[str] = field(default_factory=lambda: [".pdf"])


@dataclass
class TableData:
    """Represents an extracted table."""

    index: int
    caption: str | None = None
    markdown: str | None = None
    rows: list[list[str]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class FigureData:
    """Represents an extracted figure/image."""

    index: int
    caption: str | None = None
    image_data: bytes | None = None
    image_path: str | None = None
    alt_text: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParsedSection:
    """Represents a document section with hierarchy."""

    title: str
    content: str
    level: int  # Heading level (1-6)
    index: int
    start_page: int | None = None
    end_page: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParsedDocument:
    """
    Result of document parsing operation.

    This is the standard output format for all parsers, ensuring consistency
    regardless of the underlying parsing engine.
    """

    # Core content
    markdown: str  # Full document in markdown format
    text: str  # Plain text without markdown formatting

    # Structure
    sections: list[ParsedSection] = field(default_factory=list)
    tables: list[TableData] = field(default_factory=list)
    figures: list[FigureData] = field(default_factory=list)

    # Metadata
    title: str | None = None
    num_pages: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    # Processing info
    parser_type: str | None = None
    parsed_at: datetime = field(default_factory=datetime.utcnow)
    processing_time_seconds: float | None = None

    # Original Docling document (if applicable)
    # Type is forward-referenced to avoid importing docling_core at runtime
    docling_document: "DoclingDocument | None" = None

    def __post_init__(self):
        """Ensure text is derived from markdown if not provided."""
        if not self.text and self.markdown:
            # Simple markdown to text conversion (remove markdown syntax)
            import re

            text = self.markdown
            # Remove markdown headers
            text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
            # Remove bold/italic
            text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
            text = re.sub(r"\*(.+?)\*", r"\1", text)
            # Remove links but keep text
            text = re.sub(r"\[(.+?)\]\(.+?\)", r"\1", text)
            self.text = text


@dataclass
class ParserConfig:
    """
    Configuration for document parsing.

    This configuration is used across all parser types to maintain consistency.
    Parser-specific settings can be passed via `extra_config`.
    """

    # General settings
    parser_type: ParserType = ParserType.DOCLING
    extract_tables: bool = True
    extract_figures: bool = True
    extract_sections: bool = True

    # OCR settings
    enable_ocr: bool = False
    ocr_language: str = "eng"

    # Performance
    max_concurrent: int = 4  # For batch processing
    timeout_seconds: int = 300  # 5 minutes default

    # Output format
    markdown_format: str = "github"  # github, commonmark, etc.
    preserve_formatting: bool = True

    # Parser-specific settings
    extra_config: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration."""
        if self.max_concurrent < 1:
            raise ValueError("max_concurrent must be at least 1")
        if self.timeout_seconds < 1:
            raise ValueError("timeout_seconds must be positive")


class DocumentParser(ABC):
    """
    Abstract base class for document parsers.

    All parser implementations (Docling, LlamaParse, etc.) must inherit from this
    class and implement its abstract methods.
    """

    def __init__(self, config: ParserConfig | None = None):
        """
        Initialize parser with configuration.

        Args:
            config: Parser configuration. If None, uses default config.
        """
        self.config = config or ParserConfig()

    @abstractmethod
    def get_capabilities(self) -> ParserCapabilities:
        """
        Get capabilities of this parser.

        Returns:
            ParserCapabilities describing what this parser can do
        """

    @abstractmethod
    async def parse_file(self, file_path: str | Path, **kwargs) -> ParsedDocument:
        """
        Parse a document file.

        Args:
            file_path: Path to the document file
            **kwargs: Additional parser-specific arguments

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
            FileNotFoundError: If file doesn't exist
        """

    @abstractmethod
    async def parse_bytes(
        self, content: bytes, filename: str | None = None, **kwargs
    ) -> ParsedDocument:
        """
        Parse document from bytes.

        Args:
            content: Document content as bytes
            filename: Optional filename (for format detection)
            **kwargs: Additional parser-specific arguments

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
        """

    async def parse_batch(self, file_paths: list[str | Path], **kwargs) -> list[ParsedDocument]:
        """
        Parse multiple documents.

        Default implementation processes files sequentially. Parsers that support
        batch processing should override this for better performance.

        Args:
            file_paths: List of file paths to parse
            **kwargs: Additional parser-specific arguments

        Returns:
            List of ParsedDocument objects

        Raises:
            ParseError: If any parsing fails (behavior depends on implementation)
        """
        results = []
        for file_path in file_paths:
            result = await self.parse_file(file_path, **kwargs)
            results.append(result)
        return results

    def validate_file(self, file_path: str | Path) -> bool:
        """
        Validate if file can be parsed by this parser.

        Args:
            file_path: Path to file

        Returns:
            True if file can be parsed

        Raises:
            FileNotFoundError: If file doesn't exist
        """
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if not path.is_file():
            raise ValueError(f"Not a file: {file_path}")

        # Check file extension
        capabilities = self.get_capabilities()
        if path.suffix.lower() not in capabilities.supported_formats:
            return False

        # Check file size
        if capabilities.max_file_size_mb is not None:
            size_mb = path.stat().st_size / (1024 * 1024)
            if size_mb > capabilities.max_file_size_mb:
                return False

        return True

    async def health_check(self) -> bool:
        """
        Check if parser is operational.

        Returns:
            True if parser is ready to use
        """
        return True

    def __repr__(self) -> str:
        """String representation of parser."""
        return f"{self.__class__.__name__}(config={self.config})"
