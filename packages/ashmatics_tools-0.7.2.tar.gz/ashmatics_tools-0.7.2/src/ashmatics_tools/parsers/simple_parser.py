"""Simple fallback parser using unstructured library.

This parser provides a lightweight fallback option when more advanced
parsers (Docling, LlamaParse) are not available or fail.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
import time
from pathlib import Path

from .base import (
    DocumentParser,
    ParsedDocument,
    ParseError,
    ParserCapabilities,
    ParserConfig,
)

logger = logging.getLogger(__name__)


class SimpleParser(DocumentParser):
    """
    Simple parser using basic PDF extraction.

    This is a lightweight fallback parser that doesn't require
    external services or heavy dependencies.
    """

    def __init__(self, config: ParserConfig | None = None):
        """
        Initialize simple parser.

        Args:
            config: Parser configuration
        """
        super().__init__(config)

        # Try to import unstructured (optional dependency)
        try:
            from unstructured.partition.pdf import partition_pdf

            self.partition_pdf = partition_pdf
            self.has_unstructured = True
        except ImportError:
            logger.warning(
                "unstructured library not available. Install with: pip install unstructured"
            )
            self.has_unstructured = False

        logger.info("Simple parser initialized")

    def get_capabilities(self) -> ParserCapabilities:
        """Get capabilities of simple parser."""
        return ParserCapabilities(
            supports_tables=False,
            supports_figures=False,
            supports_ocr=False,
            supports_multi_column=False,
            supports_batch=True,
            supports_async=True,
            max_file_size_mb=None,
            supported_formats=[".pdf", ".txt", ".md"],
        )

    async def parse_file(self, file_path: str | Path, **kwargs) -> ParsedDocument:
        """
        Parse a document file using simple extraction.

        Args:
            file_path: Path to the document file
            **kwargs: Additional arguments

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
            FileNotFoundError: If file doesn't exist
        """
        file_path = Path(file_path)

        # Validate file
        if not self.validate_file(file_path):
            raise ParseError(f"File cannot be parsed by SimpleParser: {file_path.suffix} format")

        start_time = time.time()

        try:
            logger.info(f"Parsing document with SimpleParser: {file_path}")

            if file_path.suffix.lower() == ".pdf":
                text = await self._parse_pdf(file_path)
            elif file_path.suffix.lower() in [".txt", ".md"]:
                text = file_path.read_text(encoding="utf-8")
            else:
                raise ParseError(f"Unsupported file format: {file_path.suffix}")

            processing_time = time.time() - start_time

            logger.info(f"Parsed {file_path.name} with SimpleParser in {processing_time:.2f}s")

            return ParsedDocument(
                markdown=text,
                text=text,
                sections=[],
                tables=[],
                figures=[],
                title=file_path.stem,
                num_pages=None,
                metadata={
                    "filename": file_path.name,
                    "file_size_bytes": file_path.stat().st_size,
                },
                parser_type="simple",
                processing_time_seconds=processing_time,
            )

        except Exception as e:
            logger.error(f"SimpleParser failed for {file_path}: {e}")
            raise ParseError(f"Simple parsing failed: {str(e)}", original_error=e)

    async def parse_bytes(
        self, content: bytes, filename: str | None = None, **kwargs
    ) -> ParsedDocument:
        """
        Parse document from bytes.

        Args:
            content: Document content as bytes
            filename: Optional filename
            **kwargs: Additional arguments

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
        """
        import tempfile

        suffix = Path(filename).suffix if filename else ".pdf"

        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp_file:
            tmp_file.write(content)
            tmp_path = tmp_file.name

        try:
            result = await self.parse_file(tmp_path, **kwargs)
            if filename:
                result.metadata["filename"] = filename
            return result
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def _parse_pdf(self, file_path: Path) -> str:
        """
        Parse PDF file.

        Args:
            file_path: Path to PDF

        Returns:
            Extracted text
        """
        if self.has_unstructured:
            # Use unstructured library
            import asyncio

            loop = asyncio.get_event_loop()
            elements = await loop.run_in_executor(
                None, self.partition_pdf, str(file_path), "fast", True
            )

            # Convert elements to text
            text = "\n\n".join([str(element) for element in elements])
            return text
        else:
            # Fallback to PyPDF2
            try:
                import PyPDF2

                with open(file_path, "rb") as f:
                    reader = PyPDF2.PdfReader(f)
                    text = ""
                    for page in reader.pages:
                        text += page.extract_text() + "\n\n"
                return text
            except ImportError:
                raise ParseError(
                    "No PDF parsing library available. "
                    "Install unstructured or PyPDF2: pip install unstructured PyPDF2"
                )

    async def health_check(self) -> bool:
        """
        Check if simple parser is operational.

        Returns:
            True if parser is ready
        """
        return True  # Simple parser is always ready
