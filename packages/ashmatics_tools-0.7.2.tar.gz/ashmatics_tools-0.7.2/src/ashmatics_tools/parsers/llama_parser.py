"""LlamaParse adapter for the unified parser architecture.

This parser uses the LlamaParse cloud service for high-quality PDF parsing.
It adapts the existing LlamaParse functionality to the new parser interface.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import asyncio
import logging
import os
import time
from pathlib import Path

from .base import (
    DocumentParser,
    ParsedDocument,
    ParseError,
    ParserCapabilities,
    ParserConfig,
)

logger = logging.getLogger(__name__)


class LlamaParser(DocumentParser):
    """
    LlamaParse cloud-based parser adapter.

    This parser uses the LlamaParse API for high-quality document parsing.
    Requires LLAMA_CLOUD_API_KEY environment variable.
    """

    def __init__(self, config: ParserConfig | None = None):
        """
        Initialize LlamaParse parser.

        Args:
            config: Parser configuration

        Raises:
            ValueError: If LLAMA_CLOUD_API_KEY is not set
        """
        super().__init__(config)

        # Get API key
        self.api_key = os.getenv("LLAMA_CLOUD_API_KEY")
        if not self.api_key:
            raise ValueError("LLAMA_CLOUD_API_KEY environment variable is required for LlamaParser")

        # Import LlamaParse (lazy import to avoid dependency if not used)
        try:
            from megaparse import MegaParse
            from megaparse.parser.llama import LlamaParser as LlamaParserBackend

            self.backend = LlamaParserBackend(api_key=self.api_key)
            self.megaparse = MegaParse(self.backend)

        except ImportError as e:
            raise ImportError(
                "megaparse and llama-parse packages are required for LlamaParser. "
                "Install with: pip install megaparse llama-parse"
            ) from e

        logger.info("LlamaParse parser initialized")

    def get_capabilities(self) -> ParserCapabilities:
        """Get capabilities of LlamaParse."""
        return ParserCapabilities(
            supports_tables=True,
            supports_figures=False,  # LlamaParse doesn't extract images
            supports_ocr=True,  # LlamaParse has built-in OCR
            supports_multi_column=True,
            supports_batch=True,
            supports_async=True,
            max_file_size_mb=50,  # LlamaParse API limit
            supported_formats=[".pdf"],
        )

    async def parse_file(self, file_path: str | Path, **kwargs) -> ParsedDocument:
        """
        Parse a document file using LlamaParse.

        Args:
            file_path: Path to the document file
            **kwargs: Additional arguments

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
            FileNotFoundError: If file doesn't exist
        """
        file_path = Path(file_path)

        # Validate file
        if not self.validate_file(file_path):
            raise ParseError(f"File cannot be parsed by LlamaParse: {file_path.suffix} format")

        start_time = time.time()

        try:
            logger.info(f"Parsing document with LlamaParse: {file_path}")

            # LlamaParse's aload method is async
            response = await self.megaparse.aload(str(file_path))

            # Extract markdown content
            if isinstance(response, dict) and "text" in response:
                markdown = response["text"]
            elif hasattr(response, "text"):
                markdown = response.text
            else:
                markdown = str(response)

            processing_time = time.time() - start_time

            logger.info(f"Parsed {file_path.name} with LlamaParse in {processing_time:.2f}s")

            # Create ParsedDocument
            # Note: LlamaParse doesn't provide structured sections/tables,
            # just high-quality markdown
            return ParsedDocument(
                markdown=markdown,
                text=markdown,  # LlamaParse output is already clean
                sections=[],  # Could parse from markdown headers if needed
                tables=[],  # Tables are in markdown but not structured
                figures=[],
                title=file_path.stem,
                num_pages=None,  # LlamaParse doesn't provide page count
                metadata={
                    "filename": file_path.name,
                    "file_size_bytes": file_path.stat().st_size,
                },
                parser_type="llama",
                processing_time_seconds=processing_time,
            )

        except Exception as e:
            logger.error(f"LlamaParse failed for {file_path}: {e}")
            raise ParseError(f"LlamaParse parsing failed: {str(e)}", original_error=e)

    async def parse_bytes(
        self, content: bytes, filename: str | None = None, **kwargs
    ) -> ParsedDocument:
        """
        Parse document from bytes.

        Args:
            content: Document content as bytes
            filename: Optional filename
            **kwargs: Additional arguments

        Returns:
            ParsedDocument containing the parsed content

        Raises:
            ParseError: If parsing fails
        """
        # LlamaParse requires a file path, so write to temp file
        import tempfile

        suffix = Path(filename).suffix if filename else ".pdf"

        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp_file:
            tmp_file.write(content)
            tmp_path = tmp_file.name

        try:
            result = await self.parse_file(tmp_path, **kwargs)
            # Update filename in metadata
            if filename:
                result.metadata["filename"] = filename
            return result
        finally:
            # Clean up temp file
            Path(tmp_path).unlink(missing_ok=True)

    async def parse_batch(self, file_paths: list[str | Path], **kwargs) -> list[ParsedDocument]:
        """
        Parse multiple documents with rate limiting.

        LlamaParse is a cloud service, so we implement rate limiting
        to avoid overwhelming the API.

        Args:
            file_paths: List of file paths to parse
            **kwargs: Additional arguments

        Returns:
            List of ParsedDocument objects
        """
        if not file_paths:
            return []

        logger.info(f"Batch parsing {len(file_paths)} documents with LlamaParse")

        # Use semaphore to limit concurrent API calls
        # LlamaParse has rate limits, so be conservative
        max_concurrent = min(self.config.max_concurrent, 3)  # Max 3 concurrent
        semaphore = asyncio.Semaphore(max_concurrent)

        async def parse_with_semaphore(file_path):
            async with semaphore:
                try:
                    result = await self.parse_file(file_path, **kwargs)
                    # Small delay between requests to respect rate limits
                    await asyncio.sleep(0.5)
                    return result
                except Exception as e:
                    logger.error(f"Failed to parse {file_path}: {e}")
                    return None

        # Process all files
        tasks = [parse_with_semaphore(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks, return_exceptions=False)

        # Filter out failed parses
        successful = [r for r in results if r is not None]

        logger.info(f"Batch parsing complete: {len(successful)}/{len(file_paths)} successful")

        return successful

    async def health_check(self) -> bool:
        """
        Check if LlamaParse API is accessible.

        Returns:
            True if API is accessible
        """
        try:
            # Simple check that API key is set and backend is initialized
            return self.megaparse is not None and self.api_key is not None
        except Exception as e:
            logger.error(f"LlamaParse health check failed: {e}")
            return False
