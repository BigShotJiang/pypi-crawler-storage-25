"""Factory for creating parser instances.

This module provides a simple factory pattern for creating parsers,
making it easy to switch between different parsing backends.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging

from .base import DocumentParser, ParserConfig, ParserType

logger = logging.getLogger(__name__)

# Registry of available parsers
_PARSER_REGISTRY: dict[str, type[DocumentParser]] = {}


def register_parser(parser_type: str, parser_class: type[DocumentParser]):
    """
    Register a parser implementation.

    Args:
        parser_type: Parser type identifier (e.g., "docling", "llama")
        parser_class: Parser class to register
    """
    _PARSER_REGISTRY[parser_type.lower()] = parser_class
    logger.debug(f"Registered parser: {parser_type}")


def get_available_parsers() -> dict[str, type[DocumentParser]]:
    """
    Get all registered parsers.

    Returns:
        Dictionary mapping parser types to parser classes
    """
    return _PARSER_REGISTRY.copy()


def create_parser(
    parser_type: str = "docling", config: ParserConfig | None = None
) -> DocumentParser:
    """
    Create a parser instance.

    Args:
        parser_type: Type of parser to create ("docling", "llama", or "simple")
        config: Parser configuration. If None, uses default config.

    Returns:
        Initialized parser instance

    Raises:
        ValueError: If parser_type is not recognized

    Example:
        >>> # Create a Docling parser with default config
        >>> parser = create_parser("docling")
        >>>
        >>> # Create with custom config
        >>> config = ParserConfig(extract_tables=True, extract_figures=True)
        >>> parser = create_parser("docling", config)
        >>>
        >>> # Parse a document
        >>> result = await parser.parse_file("document.pdf")
    """
    parser_type = parser_type.lower()

    # Lazy load parsers to avoid importing dependencies unless needed
    if parser_type not in _PARSER_REGISTRY:
        _load_parser(parser_type)

    if parser_type not in _PARSER_REGISTRY:
        available = ", ".join(_PARSER_REGISTRY.keys())
        raise ValueError(f"Unknown parser type: {parser_type}. Available parsers: {available}")

    parser_class = _PARSER_REGISTRY[parser_type]

    # Create config if not provided
    if config is None:
        config = ParserConfig(parser_type=ParserType(parser_type))

    try:
        parser = parser_class(config)
        logger.info(f"Created {parser_type} parser")
        return parser
    except Exception as e:
        logger.error(f"Failed to create {parser_type} parser: {e}")
        raise


def _load_parser(parser_type: str):
    """
    Lazy load parser implementation.

    Args:
        parser_type: Parser type to load
    """
    try:
        if parser_type == "docling":
            from .docling_parser import DoclingParser

            register_parser("docling", DoclingParser)

        elif parser_type == "llama":
            from .llama_parser import LlamaParser

            register_parser("llama", LlamaParser)

        elif parser_type == "simple":
            from .simple_parser import SimpleParser

            register_parser("simple", SimpleParser)

        else:
            logger.warning(f"No parser implementation for type: {parser_type}")

    except ImportError as e:
        logger.error(f"Failed to import {parser_type} parser: {e}")
        logger.warning(
            f"Parser {parser_type} is not available. Make sure required dependencies are installed."
        )


# Pre-register known parsers (lazy loading will happen on first use)
# This allows get_available_parsers() to return the full list
_KNOWN_PARSERS = ["docling", "llama", "simple"]
