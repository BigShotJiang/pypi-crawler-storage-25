"""Embedding pipelines for knowledge base content.

This module provides pipelines for embedding structured content from MongoDB
and unstructured documents. Supports governance framework, use cases, AI cards,
and other knowledge base content types.

Public API:
    - MongoDBEmbeddingPipeline: Generic pipeline for MongoDB content
    - create_framework_pipeline: Convenience function for framework content
    - create_usecase_pipeline: Convenience function for use cases
    - create_ai_card_pipeline: Convenience function for AI cards
    - create_manufacturer_card_pipeline: Convenience function for manufacturer cards

Example:
    >>> from src.common.embedding import create_framework_pipeline
    >>> pipeline = create_framework_pipeline()
    >>> await pipeline.initialize()
    >>> results = await pipeline.embed_collection(query={"semver": "2025.08.18"})

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from .base import (
    ChunkingStrategyType,
    ContentExtractor,
    EmbeddingResult,
    MetadataEnricher,
)
from .mongodb_pipeline import MongoDBEmbeddingPipeline
from .specialized import (
    create_ai_card_pipeline,
    create_framework_pipeline,
    create_manufacturer_card_pipeline,
    create_usecase_pipeline,
)

__all__ = [
    # Base types
    "EmbeddingResult",
    "ContentExtractor",
    "MetadataEnricher",
    "ChunkingStrategyType",
    # Core pipeline
    "MongoDBEmbeddingPipeline",
    # Convenience functions
    "create_framework_pipeline",
    "create_usecase_pipeline",
    "create_ai_card_pipeline",
    "create_manufacturer_card_pipeline",
]
