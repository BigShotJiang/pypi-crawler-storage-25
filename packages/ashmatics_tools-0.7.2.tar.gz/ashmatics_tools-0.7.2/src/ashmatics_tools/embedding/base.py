"""Base classes, types, and interfaces for embedding pipelines.

This module defines the core types and interfaces used by all embedding pipelines.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.

Last Updated: 2026-01-24
Changes: Standardized environment variable names for Ashmatics consistency
         - Changed AZ_MONGO_CONNECTION_STRING -> MONGO_URL (with backward-compatible fallback)
         - Changed MONGO_DATABASE -> MONGO_DB (with backward-compatible fallback)
"""

import os
import warnings
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from ..chunkers.base import DocumentChunk

# Type aliases for clarity
ContentExtractor = Callable[[dict[str, Any]], str]
MetadataEnricher = Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]]
ChunkingStrategyType = str  # "semantic", "section", "paragraph", etc.


@dataclass
class EmbeddingResult:
    """
    Result of embedding operation for a single document.

    Attributes:
        artifact_id: Unique identifier for the document
        version: Version/semver of the document
        chunks_created: Number of chunks created
        embeddings_generated: Number of embeddings generated
        token_count: Total token count across all chunks
        metadata: Additional metadata about the embedding operation
        chunks: Optional list of embedded chunks (if requested)
    """

    artifact_id: str
    version: str
    chunks_created: int
    embeddings_generated: int
    token_count: int
    metadata: dict[str, Any] = field(default_factory=dict)
    chunks: list[DocumentChunk] | None = None


@dataclass
class PipelineConfig:
    """
    Configuration for embedding pipeline.

    Attributes:
        mongo_connection_string: MongoDB connection string
        mongo_database: Database name
        mongo_collection: Collection name
        chunking_strategy: Strategy for chunking ("semantic", "section", etc.)
        max_tokens: Maximum tokens per chunk
        min_chunk_size: Minimum chunk size in characters
        batch_size: Batch size for processing documents
        embedding_model: Embedding model name
        include_chunks: Whether to include chunks in results
    """

    # MongoDB configuration
    mongo_connection_string: str | None = None
    mongo_database: str | None = None
    mongo_collection: str | None = None

    # Chunking configuration
    chunking_strategy: str = "semantic"
    max_tokens: int = 512
    min_chunk_size: int = 100
    chunk_overlap: int = 50

    # Processing configuration
    batch_size: int = 10
    include_chunks: bool = False

    # Embedding configuration
    embedding_model: str = "text-embedding-3-small"

    def __post_init__(self):
        """Load from environment if not provided.

        Uses standardized variable names with backward-compatible fallbacks:
        - MONGO_URL (canonical) -> AZ_MONGO_CONNECTION_STRING (deprecated)
        - MONGO_DB (canonical) -> MONGO_DATABASE (deprecated)
        """
        if self.mongo_connection_string is None:
            # Try canonical name first, then deprecated names with warnings
            self.mongo_connection_string = os.getenv("MONGO_URL")
            if not self.mongo_connection_string:
                # Check deprecated names with deprecation warning
                for deprecated_name in ["AZ_MONGO_CONNECTION_STRING", "MONGO_CONNECTION_STRING", "COSMOSDB_CONNECTION_STRING"]:
                    value = os.getenv(deprecated_name)
                    if value:
                        warnings.warn(
                            f"{deprecated_name} is deprecated, use MONGO_URL instead",
                            DeprecationWarning,
                            stacklevel=2
                        )
                        self.mongo_connection_string = value
                        break

        if self.mongo_database is None:
            # Try canonical name first
            self.mongo_database = os.getenv("MONGO_DB")
            if not self.mongo_database:
                # Check deprecated name with warning
                deprecated_value = os.getenv("MONGO_DATABASE")
                if deprecated_value:
                    warnings.warn(
                        "MONGO_DATABASE is deprecated, use MONGO_DB instead",
                        DeprecationWarning,
                        stacklevel=2
                    )
                    self.mongo_database = deprecated_value
                else:
                    self.mongo_database = "ashmatics_kb"  # Default

        # Note: mongo_collection should be provided by specialized pipelines
