"""Generic MongoDB embedding pipeline.

This module provides a generic pipeline for embedding any structured content
stored in MongoDB. Can be customized through configuration rather than inheritance.

Works for:
    - Governance framework content
    - Use cases
    - AI cards
    - Manufacturer cards
    - Any future MongoDB collections

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
from typing import Any

from pymongo import MongoClient

from ..chunkers import ChunkingConfig, ChunkingStrategy, create_chunker
from ..embedders import EmbeddingConfig, EmbeddingProvider, create_embedder
from .base import (
    ChunkingStrategyType,
    ContentExtractor,
    EmbeddingResult,
    MetadataEnricher,
    PipelineConfig,
)

logger = logging.getLogger(__name__)


class MongoDBEmbeddingPipeline:
    """
    Generic pipeline for embedding structured MongoDB content.

    This pipeline can handle any MongoDB collection through customization
    via content extractors and metadata enrichers. No subclassing needed.

    Example:
        >>> pipeline = MongoDBEmbeddingPipeline(
        ...     collection_name="my_collection",
        ...     content_extractor=lambda doc: doc["content"],
        ...     metadata_enricher=lambda doc, meta: {**meta, "custom": doc["field"]}
        ... )
        >>> await pipeline.initialize()
        >>> results = await pipeline.embed_collection(query={"status": "active"})
    """

    def __init__(
        self,
        collection_name: str,
        content_extractor: ContentExtractor | None = None,
        metadata_enricher: MetadataEnricher | None = None,
        chunking_strategy: ChunkingStrategyType | None = None,
        config: PipelineConfig | None = None,
    ):
        """
        Initialize MongoDB embedding pipeline.

        Args:
            collection_name: MongoDB collection to process
            content_extractor: Custom function to extract text from document
                             Signature: (doc: Dict) -> str
            metadata_enricher: Custom function to enrich chunk metadata
                              Signature: (doc: Dict, chunk_meta: Dict) -> Dict
            chunking_strategy: Strategy for chunking ("semantic", "section", etc.)
            config: Optional pipeline configuration (uses defaults if not provided)
        """
        self.collection_name = collection_name
        self.content_extractor = content_extractor or self._default_extractor
        self.metadata_enricher = metadata_enricher or self._default_metadata_enricher
        self.chunking_strategy = chunking_strategy or "semantic"

        # Configuration
        self.config = config or PipelineConfig()
        self.config.mongo_collection = collection_name

        # Components (initialized in initialize())
        self.chunker = None
        self.embedder = None
        self.mongo_client = None
        self.collection = None

        logger.info(f"Created MongoDB embedding pipeline for collection: {collection_name}")

    async def initialize(self):
        """
        Initialize pipeline components.

        Creates chunker, embedder, and MongoDB connection.
        Must be called before embed_collection().
        """
        # Create chunker
        chunking_config = ChunkingConfig(
            strategy=ChunkingStrategy.AZURE,
            max_tokens=self.config.max_tokens,
            min_chunk_size=self.config.min_chunk_size,
            chunk_overlap=self.config.chunk_overlap,
            preserve_structure=True,
        )
        self.chunker = create_chunker(chunking_config)

        # Create embedder
        embedding_config = EmbeddingConfig(
            provider=EmbeddingProvider.AZURE, model=self.config.embedding_model
        )
        self.embedder = create_embedder("azure", embedding_config)
        await self.embedder.initialize()

        # Connect to MongoDB
        if not self.config.mongo_connection_string:
            raise ValueError(
                "MongoDB connection string not provided and AZ_MONGO_CONNECTION_STRING not set"
            )

        self.mongo_client = MongoClient(self.config.mongo_connection_string)
        db = self.mongo_client[self.config.mongo_database]
        self.collection = db[self.collection_name]

        logger.info(f"Initialized pipeline: {self.config.mongo_database}.{self.collection_name}")

    async def embed_collection(
        self,
        query: dict[str, Any] | None = None,
        batch_size: int | None = None,
        limit: int | None = None,
    ) -> list[EmbeddingResult]:
        """
        Embed all documents matching query.

        Args:
            query: MongoDB query filter (default: all documents)
            batch_size: Batch size for processing (default: from config)
            limit: Maximum number of documents to process (default: no limit)

        Returns:
            List of EmbeddingResult objects

        Raises:
            ValueError: If pipeline not initialized
        """
        if not self.chunker or not self.embedder or not self.collection:
            raise ValueError("Pipeline not initialized. Call initialize() first.")

        query = query or {}
        batch_size = batch_size or self.config.batch_size

        # Fetch documents
        cursor = self.collection.find(query)
        if limit:
            cursor = cursor.limit(limit)

        documents = list(cursor)
        logger.info(f"Found {len(documents)} documents in {self.collection_name} matching query")

        if not documents:
            logger.warning(f"No documents found for query: {query}")
            return []

        # Process in batches
        results = []
        for i in range(0, len(documents), batch_size):
            batch = documents[i : i + batch_size]
            logger.info(
                f"Processing batch {i // batch_size + 1}/{(len(documents) + batch_size - 1) // batch_size}"
            )

            batch_results = await self._process_batch(batch)
            results.extend(batch_results)

        logger.info(f"Completed embedding {len(results)} documents from {self.collection_name}")
        return results

    async def embed_document(self, doc: dict[str, Any]) -> EmbeddingResult:
        """
        Embed a single document.

        Args:
            doc: MongoDB document to embed

        Returns:
            EmbeddingResult for the document

        Raises:
            ValueError: If pipeline not initialized
        """
        if not self.chunker or not self.embedder:
            raise ValueError("Pipeline not initialized. Call initialize() first.")

        return await self._process_document(doc)

    async def _process_batch(self, documents: list[dict[str, Any]]) -> list[EmbeddingResult]:
        """Process a batch of documents."""
        results = []

        for doc in documents:
            try:
                result = await self._process_document(doc)
                results.append(result)
            except Exception as e:
                logger.error(
                    f"Failed to process document {doc.get('_id', 'unknown')}: {e}",
                    exc_info=True,
                )

        return results

    async def _process_document(self, doc: dict[str, Any]) -> EmbeddingResult:
        """
        Process a single document through the pipeline.

        Args:
            doc: MongoDB document

        Returns:
            EmbeddingResult with chunks and embeddings
        """
        # Extract content using custom extractor
        content = self.content_extractor(doc)

        if not content or not content.strip():
            logger.warning(f"Empty content for document: {doc.get('_id')}")
            return EmbeddingResult(
                artifact_id=str(doc.get("_id", "unknown")),
                version=doc.get("semver", doc.get("version", "unknown")),
                chunks_created=0,
                embeddings_generated=0,
                token_count=0,
                metadata={"error": "empty_content"},
            )

        # Base metadata
        base_metadata = {
            "source_collection": self.collection_name,
            "source_id": str(doc.get("_id")),
        }

        # Enrich metadata using custom enricher
        enriched_metadata = self.metadata_enricher(doc, base_metadata)

        # Chunk the content
        chunks = await self.chunker.chunk_document(
            content=content,
            title=doc.get("title", "Document"),
            source=doc.get("source", doc.get("source_blob_path", "mongodb")),
            metadata=enriched_metadata,
            custom_strategy=self.chunking_strategy,
        )

        total_tokens = sum(c.token_count for c in chunks)

        # Generate embeddings
        embedded_chunks = await self.embedder.embed_chunks(chunks)

        # Build result
        result = EmbeddingResult(
            artifact_id=doc.get("artifact_id", str(doc.get("_id"))),
            version=doc.get("semver", doc.get("version", "unknown")),
            chunks_created=len(chunks),
            embeddings_generated=len(embedded_chunks),
            token_count=total_tokens,
            metadata={
                "title": doc.get("title"),
                "category": doc.get("category"),
                "collection": self.collection_name,
            },
            chunks=embedded_chunks if self.config.include_chunks else None,
        )

        logger.info(
            f"Processed {result.artifact_id}: {result.chunks_created} chunks, {result.token_count} tokens"
        )

        return result

    def _default_extractor(self, doc: dict[str, Any]) -> str:
        """
        Default content extractor.

        Tries common patterns for extracting text from MongoDB documents:
        1. Sectioned documents (framework-style with sections array)
        2. Simple content field
        3. Description field
        """
        # Pattern 1: Sectioned documents (like framework content)
        if "sections" in doc and isinstance(doc["sections"], list):
            return self._extract_sections(doc)

        # Pattern 2: Simple content field
        if "content" in doc:
            return str(doc["content"])

        # Pattern 3: Description field
        if "description" in doc:
            return str(doc["description"])

        # Pattern 4: Text field
        if "text" in doc:
            return str(doc["text"])

        # Could not find content
        logger.warning(
            f"Could not extract content from document {doc.get('_id')} - no recognized content fields"
        )
        return ""

    def _extract_sections(self, doc: dict[str, Any]) -> str:
        """
        Extract text from sectioned documents.

        Expects document with structure:
        {
            "sections": [
                {"heading": "...", "content": "...", "level": 2},
                ...
            ]
        }
        """
        sections = doc.get("sections", [])
        parts = []

        for section in sections:
            level = section.get("level", 2)
            heading = section.get("heading", "")
            content = section.get("content", "")

            # Format as markdown
            parts.append(f"{'#' * level} {heading}\n\n{content}")

        return "\n\n".join(parts)

    def _default_metadata_enricher(
        self, doc: dict[str, Any], chunk_metadata: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Default metadata enricher.

        Adds common fields if they exist in the document.
        """
        enriched = {**chunk_metadata}

        # Add common fields if present
        common_fields = [
            "artifact_id",
            "category",
            "semver",
            "version",
            "title",
            "source",
            "source_blob_path",
        ]

        for field in common_fields:
            if field in doc:
                enriched[field] = doc[field]

        return enriched

    async def close(self):
        """Clean up resources."""
        if self.embedder:
            await self.embedder.close()

        if self.mongo_client:
            self.mongo_client.close()

        logger.info(f"Closed pipeline for {self.collection_name}")

    def get_stats(self) -> dict[str, Any]:
        """Get pipeline statistics."""
        return {
            "collection_name": self.collection_name,
            "database": self.config.mongo_database,
            "chunking_strategy": self.chunking_strategy,
            "max_tokens": self.config.max_tokens,
            "embedding_model": self.config.embedding_model,
            "batch_size": self.config.batch_size,
        }
