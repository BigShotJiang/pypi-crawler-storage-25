"""AI Card and Manufacturer Card embedding configuration.

Provides specialized configurations for embedding AI model cards and
manufacturer device cards from MongoDB.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import os
from typing import Any

from ..mongodb_pipeline import MongoDBEmbeddingPipeline


def extract_ai_card_content(doc: dict[str, Any]) -> str:
    """
    Extract content from AI card document.

    AI card documents typically have:
    {
        "model_name": "...",
        "manufacturer": "...",
        "version": "...",
        "intended_use": "...",
        "performance_characteristics": "...",
        "limitations": "...",
        "regulatory_status": "...",
        "risk_classification": "..."
    }

    Args:
        doc: AI card document from MongoDB

    Returns:
        Formatted markdown text with all card fields
    """
    parts = []

    # Title
    model_name = doc.get("model_name", "AI Model")
    parts.append(f"# {model_name}")
    parts.append("")

    # Header metadata
    manufacturer = doc.get("manufacturer", "N/A")
    version = doc.get("version", "N/A")
    regulatory_status = doc.get("regulatory_status", "N/A")

    parts.append(f"**Manufacturer**: {manufacturer}")
    parts.append(f"**Version**: {version}")
    parts.append(f"**Regulatory Status**: {regulatory_status}")
    parts.append("")

    # Intended use
    if "intended_use" in doc:
        parts.append("## Intended Use")
        parts.append("")
        parts.append(doc["intended_use"])
        parts.append("")

    # Performance characteristics
    if "performance_characteristics" in doc:
        parts.append("## Performance Characteristics")
        parts.append("")
        parts.append(doc["performance_characteristics"])
        parts.append("")

    # Limitations and warnings
    if "limitations" in doc:
        parts.append("## Limitations")
        parts.append("")
        parts.append(doc["limitations"])
        parts.append("")

    # Training data
    if "training_data" in doc:
        parts.append("## Training Data")
        parts.append("")
        parts.append(doc["training_data"])
        parts.append("")

    # Validation data
    if "validation_data" in doc:
        parts.append("## Validation Data")
        parts.append("")
        parts.append(doc["validation_data"])
        parts.append("")

    return "\n".join(parts)


def enrich_ai_card_metadata(doc: dict[str, Any], chunk_metadata: dict[str, Any]) -> dict[str, Any]:
    """
    Enrich metadata with AI card-specific fields.

    Args:
        doc: AI card document
        chunk_metadata: Base chunk metadata

    Returns:
        Enriched metadata dictionary
    """
    enriched = {**chunk_metadata}

    # AI card-specific fields
    enriched.update(
        {
            "card_type": "ai_card",
            "model_name": doc.get("model_name"),
            "manufacturer": doc.get("manufacturer"),
            "version": doc.get("version"),
            "regulatory_status": doc.get("regulatory_status"),
            "risk_classification": doc.get("risk_classification"),
            "content_type": "ai_model_card",
        }
    )

    # Additional fields
    if "intended_use_category" in doc:
        enriched["intended_use_category"] = doc["intended_use_category"]

    if "clinical_specialty" in doc:
        enriched["clinical_specialty"] = doc["clinical_specialty"]

    if "algorithm_type" in doc:
        enriched["algorithm_type"] = doc["algorithm_type"]

    return enriched


def extract_manufacturer_card_content(doc: dict[str, Any]) -> str:
    """
    Extract content from manufacturer card document.

    Manufacturer card documents typically have:
    {
        "device_name": "...",
        "manufacturer": "...",
        "model_number": "...",
        "description": "...",
        "indications_for_use": "...",
        "contraindications": "...",
        "warnings": "...",
        "510k_number": "..."
    }

    Args:
        doc: Manufacturer card document from MongoDB

    Returns:
        Formatted markdown text with all card fields
    """
    parts = []

    # Title
    device_name = doc.get("device_name", doc.get("product_name", "Medical Device"))
    parts.append(f"# {device_name}")
    parts.append("")

    # Header metadata
    manufacturer = doc.get("manufacturer", "N/A")
    model_number = doc.get("model_number", "N/A")
    regulatory_id = doc.get("510k_number", doc.get("pma_number", "N/A"))

    parts.append(f"**Manufacturer**: {manufacturer}")
    parts.append(f"**Model Number**: {model_number}")
    parts.append(f"**Regulatory ID**: {regulatory_id}")
    parts.append("")

    # Description
    if "description" in doc:
        parts.append("## Description")
        parts.append("")
        parts.append(doc["description"])
        parts.append("")

    # Indications for use
    if "indications_for_use" in doc:
        parts.append("## Indications for Use")
        parts.append("")
        parts.append(doc["indications_for_use"])
        parts.append("")

    # Contraindications
    if "contraindications" in doc:
        parts.append("## Contraindications")
        parts.append("")
        parts.append(doc["contraindications"])
        parts.append("")

    # Warnings and precautions
    if "warnings" in doc:
        parts.append("## Warnings and Precautions")
        parts.append("")
        parts.append(doc["warnings"])
        parts.append("")

    return "\n".join(parts)


def enrich_manufacturer_card_metadata(
    doc: dict[str, Any], chunk_metadata: dict[str, Any]
) -> dict[str, Any]:
    """
    Enrich metadata with manufacturer card-specific fields.

    Args:
        doc: Manufacturer card document
        chunk_metadata: Base chunk metadata

    Returns:
        Enriched metadata dictionary
    """
    enriched = {**chunk_metadata}

    # Manufacturer card-specific fields
    enriched.update(
        {
            "card_type": "manufacturer_card",
            "device_name": doc.get("device_name", doc.get("product_name")),
            "manufacturer": doc.get("manufacturer"),
            "model_number": doc.get("model_number"),
            "regulatory_id": doc.get("510k_number", doc.get("pma_number")),
            "device_class": doc.get("device_class"),
            "content_type": "manufacturer_device_card",
        }
    )

    # Additional fields
    if "product_code" in doc:
        enriched["product_code"] = doc["product_code"]

    if "submission_type" in doc:
        enriched["submission_type"] = doc["submission_type"]

    return enriched


def create_ai_card_pipeline(**kwargs) -> MongoDBEmbeddingPipeline:
    """
    Create embedding pipeline for AI card content.

    Args:
        **kwargs: Additional arguments passed to MongoDBEmbeddingPipeline

    Returns:
        Configured MongoDBEmbeddingPipeline instance

    Example:
        >>> pipeline = create_ai_card_pipeline()
        >>> await pipeline.initialize()
        >>> results = await pipeline.embed_collection(
        ...     query={"regulatory_status": "cleared"}
        ... )
    """
    collection_name = kwargs.pop("collection_name", os.getenv("AI_CARD_COLLECTION", "ai_cards"))

    return MongoDBEmbeddingPipeline(
        collection_name=collection_name,
        content_extractor=extract_ai_card_content,
        metadata_enricher=enrich_ai_card_metadata,
        chunking_strategy=kwargs.pop("chunking_strategy", "semantic"),
        **kwargs,
    )


def create_manufacturer_card_pipeline(**kwargs) -> MongoDBEmbeddingPipeline:
    """
    Create embedding pipeline for manufacturer card content.

    Args:
        **kwargs: Additional arguments passed to MongoDBEmbeddingPipeline

    Returns:
        Configured MongoDBEmbeddingPipeline instance

    Example:
        >>> pipeline = create_manufacturer_card_pipeline()
        >>> await pipeline.initialize()
        >>> results = await pipeline.embed_collection(
        ...     query={"device_class": "II"}
        ... )
    """
    collection_name = kwargs.pop(
        "collection_name", os.getenv("MANUFACTURER_CARD_COLLECTION", "manufacturer_cards")
    )

    return MongoDBEmbeddingPipeline(
        collection_name=collection_name,
        content_extractor=extract_manufacturer_card_content,
        metadata_enricher=enrich_manufacturer_card_metadata,
        chunking_strategy=kwargs.pop("chunking_strategy", "semantic"),
        **kwargs,
    )
