"""Specialized embedding pipeline configurations.

This module provides convenience functions for creating embedding pipelines
for specific content types (framework, use cases, cards, etc.).

These are just thin configuration wrappers around MongoDBEmbeddingPipeline -
the core logic is in the generic pipeline.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from .cards import create_ai_card_pipeline, create_manufacturer_card_pipeline
from .framework import create_framework_pipeline
from .usecases import create_usecase_pipeline

__all__ = [
    "create_framework_pipeline",
    "create_usecase_pipeline",
    "create_ai_card_pipeline",
    "create_manufacturer_card_pipeline",
]
