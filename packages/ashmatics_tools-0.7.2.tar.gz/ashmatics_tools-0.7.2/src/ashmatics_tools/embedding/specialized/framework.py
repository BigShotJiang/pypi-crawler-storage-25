"""Clinical AI Governance Framework embedding configuration.

Provides specialized configuration for embedding governance framework content
from MongoDB compiled views.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import os
from typing import Any

from ..mongodb_pipeline import MongoDBEmbeddingPipeline


def extract_framework_content(doc: dict[str, Any]) -> str:
    """
    Extract content from framework compiled view.

    Framework documents have this structure:
    {
        "artifact_id": "...",
        "semver": "2025.08.18-090325",
        "sections": [
            {"heading": "Purpose", "content": "...", "level": 2},
            {"heading": "Scope", "content": "...", "level": 2},
            ...
        ],
        "placeholders": [...],
        "policy_bindings": [...],
        "traceability": {...}
    }

    Args:
        doc: Framework document from MongoDB

    Returns:
        Formatted markdown text with all sections
    """
    sections = doc.get("sections", [])

    if not sections:
        # Fallback to content field if no sections
        return doc.get("content", "")

    parts = []
    for section in sections:
        level = section.get("level", 2)
        heading = section.get("heading", "")
        content = section.get("content", "")

        # Format as markdown with proper heading levels
        parts.append(f"{'#' * level} {heading}\n\n{content}")

    return "\n\n".join(parts)


def enrich_framework_metadata(
    doc: dict[str, Any], chunk_metadata: dict[str, Any]
) -> dict[str, Any]:
    """
    Enrich metadata with framework-specific fields.

    Adds:
    - Framework domain (PV, SA, MON, etc.)
    - Framework practice
    - Policy bindings
    - Placeholder information
    - ISO control mappings
    - Traceability information

    Args:
        doc: Framework document
        chunk_metadata: Base chunk metadata

    Returns:
        Enriched metadata dictionary
    """
    enriched = {**chunk_metadata}

    # Framework-specific fields
    enriched.update(
        {
            "artifact_id": doc.get("artifact_id"),
            "category": doc.get("category"),
            "semver": doc.get("semver"),
            "framework_domain": doc.get("domain"),
            "framework_practice": doc.get("practice"),
            "content_type": "governance_framework",
        }
    )

    # Policy bindings (if present)
    policy_bindings = doc.get("policy_bindings", [])
    if policy_bindings:
        enriched["policy_bindings"] = policy_bindings
        enriched["has_policy_bindings"] = True

    # Placeholder information
    placeholders = doc.get("placeholders", [])
    enriched["placeholder_count"] = len(placeholders)
    enriched["has_placeholders"] = len(placeholders) > 0

    # Traceability (ISO controls, NIST mappings, etc.)
    traceability = doc.get("traceability", {})
    if traceability:
        enriched["iso_controls"] = traceability.get("iso_controls", [])
        enriched["nist_mappings"] = traceability.get("nist_mappings", [])
        enriched["fda_references"] = traceability.get("fda_references", [])

    # Source information
    enriched["source_blob_path"] = doc.get("source_blob_path", "")

    return enriched


def create_framework_pipeline(**kwargs) -> MongoDBEmbeddingPipeline:
    """
    Create embedding pipeline for Clinical AI Governance Framework content.

    This is a convenience function that configures MongoDBEmbeddingPipeline
    with framework-specific extractors and enrichers.

    Args:
        **kwargs: Additional arguments passed to MongoDBEmbeddingPipeline
                 Can override collection_name, chunking_strategy, etc.

    Returns:
        Configured MongoDBEmbeddingPipeline instance

    Example:
        >>> pipeline = create_framework_pipeline()
        >>> await pipeline.initialize()
        >>> results = await pipeline.embed_collection(
        ...     query={"semver": "2025.08.18-090325"}
        ... )
    """
    # Get collection name from environment or use default
    collection_name = kwargs.pop(
        "collection_name",
        os.getenv("MONGO_COLLECTION", "aigov_framework_content"),
    )

    return MongoDBEmbeddingPipeline(
        collection_name=collection_name,
        content_extractor=extract_framework_content,
        metadata_enricher=enrich_framework_metadata,
        chunking_strategy=kwargs.pop("chunking_strategy", "semantic"),
        **kwargs,
    )
