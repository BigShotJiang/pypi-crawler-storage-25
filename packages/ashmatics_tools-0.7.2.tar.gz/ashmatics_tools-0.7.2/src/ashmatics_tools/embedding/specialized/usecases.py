"""Use case embedding configuration.

Provides specialized configuration for embedding clinical use case content
from MongoDB.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import os
from typing import Any

from ..mongodb_pipeline import MongoDBEmbeddingPipeline


def extract_usecase_content(doc: dict[str, Any]) -> str:
    """
    Extract content from use case document.

    Use case documents typically have:
    {
        "usecase_id": "UC001",
        "title": "...",
        "domain": "...",
        "clinical_area": "...",
        "description": "...",
        "clinical_context": "...",
        "implementation_details": "...",
        "risk_level": "...",
        "regulatory_category": "..."
    }

    Args:
        doc: Use case document from MongoDB

    Returns:
        Formatted markdown text with all use case fields
    """
    parts = []

    # Title
    title = doc.get("title", "Use Case")
    parts.append(f"# {title}")
    parts.append("")

    # Metadata section
    usecase_id = doc.get("usecase_id", "N/A")
    domain = doc.get("domain", "N/A")
    clinical_area = doc.get("clinical_area", "N/A")

    parts.append(f"**Use Case ID**: {usecase_id}")
    parts.append(f"**Domain**: {domain}")
    parts.append(f"**Clinical Area**: {clinical_area}")
    parts.append("")

    # Description
    if "description" in doc:
        parts.append("## Description")
        parts.append("")
        parts.append(doc["description"])
        parts.append("")

    # Clinical context
    if "clinical_context" in doc:
        parts.append("## Clinical Context")
        parts.append("")
        parts.append(doc["clinical_context"])
        parts.append("")

    # Implementation details
    if "implementation_details" in doc:
        parts.append("## Implementation Details")
        parts.append("")
        parts.append(doc["implementation_details"])
        parts.append("")

    # Expected outcomes
    if "expected_outcomes" in doc:
        parts.append("## Expected Outcomes")
        parts.append("")
        parts.append(doc["expected_outcomes"])
        parts.append("")

    # Risks and considerations
    if "risks" in doc:
        parts.append("## Risks and Considerations")
        parts.append("")
        parts.append(doc["risks"])
        parts.append("")

    return "\n".join(parts)


def enrich_usecase_metadata(doc: dict[str, Any], chunk_metadata: dict[str, Any]) -> dict[str, Any]:
    """
    Enrich metadata with use case-specific fields.

    Adds:
    - Use case ID
    - Clinical area
    - Domain
    - Risk level
    - Regulatory category
    - Implementation status

    Args:
        doc: Use case document
        chunk_metadata: Base chunk metadata

    Returns:
        Enriched metadata dictionary
    """
    enriched = {**chunk_metadata}

    # Use case-specific fields
    enriched.update(
        {
            "usecase_id": doc.get("usecase_id"),
            "title": doc.get("title"),
            "clinical_area": doc.get("clinical_area"),
            "domain": doc.get("domain"),
            "risk_level": doc.get("risk_level"),
            "regulatory_category": doc.get("regulatory_category"),
            "implementation_status": doc.get("status", doc.get("implementation_status")),
            "content_type": "clinical_usecase",
        }
    )

    # Additional context fields
    if "specialty" in doc:
        enriched["specialty"] = doc["specialty"]

    if "care_setting" in doc:
        enriched["care_setting"] = doc["care_setting"]

    if "patient_population" in doc:
        enriched["patient_population"] = doc["patient_population"]

    # Tags/keywords
    if "tags" in doc:
        enriched["tags"] = doc["tags"]

    if "keywords" in doc:
        enriched["keywords"] = doc["keywords"]

    return enriched


def create_usecase_pipeline(**kwargs) -> MongoDBEmbeddingPipeline:
    """
    Create embedding pipeline for clinical use case content.

    This is a convenience function that configures MongoDBEmbeddingPipeline
    with use case-specific extractors and enrichers.

    Args:
        **kwargs: Additional arguments passed to MongoDBEmbeddingPipeline
                 Can override collection_name, chunking_strategy, etc.

    Returns:
        Configured MongoDBEmbeddingPipeline instance

    Example:
        >>> pipeline = create_usecase_pipeline()
        >>> await pipeline.initialize()
        >>> results = await pipeline.embed_collection(
        ...     query={"status": "approved"}
        ... )
    """
    # Get collection name from environment or use default
    collection_name = kwargs.pop("collection_name", os.getenv("USECASE_COLLECTION", "usecases"))

    return MongoDBEmbeddingPipeline(
        collection_name=collection_name,
        content_extractor=extract_usecase_content,
        metadata_enricher=enrich_usecase_metadata,
        chunking_strategy=kwargs.pop("chunking_strategy", "semantic"),
        **kwargs,
    )
