"""Factory for creating embedder instances.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging

from .base import DocumentEmbedder, EmbeddingConfig, EmbeddingProvider

logger = logging.getLogger(__name__)


def create_embedder(
    provider: str = "openai", config: EmbeddingConfig | None = None
) -> DocumentEmbedder:
    """
    Create an embedder instance.

    Args:
        provider: Embedding provider ("openai", "local", "azure")
        config: Embedding configuration. If None, uses default config.

    Returns:
        Initialized embedder instance

    Raises:
        ValueError: If provider is not recognized

    Example:
        >>> # Create an OpenAI embedder with default config
        >>> embedder = create_embedder("openai")
        >>>
        >>> # Create with custom config
        >>> config = EmbeddingConfig(
        ...     provider=EmbeddingProvider.OPENAI,
        ...     model="text-embedding-3-large",
        ...     batch_size=50
        ... )
        >>> embedder = create_embedder("openai", config)
        >>>
        >>> # Embed some text
        >>> embedding = await embedder.generate_embedding("Hello world")
        >>> print(len(embedding))  # Should be 3072 for text-embedding-3-large
    """
    provider = provider.lower()

    # Create default config if not provided
    if config is None:
        try:
            provider_enum = EmbeddingProvider(provider)
            config = EmbeddingConfig(provider=provider_enum)
        except ValueError:
            available = ", ".join([p.value for p in EmbeddingProvider])
            raise ValueError(
                f"Unknown embedding provider: {provider}. Available providers: {available}"
            )

    # Create embedder based on provider
    if provider == "openai" or config.provider == EmbeddingProvider.OPENAI:
        from .openai_embedder import OpenAIEmbedder

        return OpenAIEmbedder(config)

    elif provider == "local" or config.provider == EmbeddingProvider.LOCAL:
        # TODO: Implement local embedder using sentence-transformers
        logger.warning("Local embedder not yet implemented, using OpenAI")
        from .openai_embedder import OpenAIEmbedder

        return OpenAIEmbedder(config)

    elif provider == "azure" or config.provider == EmbeddingProvider.AZURE:
        from .azure_embedder import AzureEmbedder

        return AzureEmbedder(config)

    else:
        available = ", ".join([p.value for p in EmbeddingProvider])
        raise ValueError(
            f"Unknown embedding provider: {provider}. Available providers: {available}"
        )
