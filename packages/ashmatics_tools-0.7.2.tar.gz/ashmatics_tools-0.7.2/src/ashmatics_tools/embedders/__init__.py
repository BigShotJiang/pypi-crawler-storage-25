"""Document embedding generation for vector search.

This module provides abstract base classes and concrete implementations for
generating embeddings from document chunks.

Supported Embedders:
- OpenAIEmbedder: Uses OpenAI's embedding models
- AzureEmbedder: Uses Azure OpenAI embedding models with enterprise features
- LocalEmbedder: Uses local sentence-transformers models (future)

Usage:
    from common.embedders import create_embedder, EmbeddingConfig, EmbeddingProvider

    # Create an Azure embedder with default config
    embedder = create_embedder("azure")
    await embedder.initialize()

    # Or create with custom config
    config = EmbeddingConfig(
        provider=EmbeddingProvider.AZURE,
        model="text-embedding-ada-002",
        batch_size=50
    )
    embedder = create_embedder("azure", config)
    await embedder.initialize()

    # Embed chunks
    embedded_chunks = await embedder.embed_chunks(chunks)

    # Get usage statistics
    stats = await embedder.get_usage_stats()

    # Health check
    is_healthy = await embedder.health_check()

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from .base import EmbeddingConfig, EmbeddingProvider
from .factory import create_embedder

__all__ = [
    "EmbeddingConfig",
    "EmbeddingProvider",
    "create_embedder",
]
