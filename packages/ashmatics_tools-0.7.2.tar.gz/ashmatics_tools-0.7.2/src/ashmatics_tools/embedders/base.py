"""Abstract base classes for embedding generators.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..chunkers.base import DocumentChunk


class EmbeddingProvider(str, Enum):
    """Supported embedding providers."""

    OPENAI = "openai"
    LOCAL = "local"  # sentence-transformers
    AZURE = "azure"


@dataclass
class EmbeddingConfig:
    """
    Configuration for embedding generation.

    This configuration is used across all embedder types to maintain consistency.
    """

    # Provider - set default to azure, but it can be overridden
    provider: EmbeddingProvider = EmbeddingProvider.AZURE

    # Model settings
    model: str = "text-embedding-3-small"
    dimensions: int | None = None  # For models that support dimension reduction

    # Performance
    batch_size: int = 100  # Number of texts to process in parallel
    max_retries: int = 3  # Maximum number of retry attempts
    retry_delay: float = 1.0  # Delay between retries in seconds

    # Advanced
    use_cache: bool = True  # Enable embedding caching
    cache_size: int = 1000  # Maximum cache entries

    # Provider-specific settings
    extra_config: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration."""
        if self.batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if self.retry_delay < 0:
            raise ValueError("retry_delay must be non-negative")


class DocumentEmbedder(ABC):
    """
    Abstract base class for embedding generators.

    All embedder implementations must inherit from this class and implement
    its abstract methods.
    """

    def __init__(self, config: EmbeddingConfig | None = None):
        """
        Initialize embedder with configuration.

        Args:
            config: Embedding configuration. If None, uses default config.
        """
        self.config = config or EmbeddingConfig()

    @abstractmethod
    async def generate_embedding(self, text: str) -> list[float]:
        """
        Generate embedding for a single text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector

        Raises:
            Exception: If embedding generation fails
        """

    @abstractmethod
    async def generate_embeddings_batch(self, texts: list[str]) -> list[list[float]]:
        """
        Generate embeddings for a batch of texts.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors

        Raises:
            Exception: If embedding generation fails
        """

    @abstractmethod
    def get_embedding_dimension(self) -> int:
        """
        Get the dimension of embeddings for this model.

        Returns:
            Embedding dimension
        """

    async def embed_chunks(
        self,
        chunks: list[DocumentChunk],
        progress_callback: Callable | None = None,
    ) -> list[DocumentChunk]:
        """
        Generate embeddings for document chunks.

        Args:
            chunks: List of document chunks
            progress_callback: Optional callback for progress updates

        Returns:
            Chunks with embeddings added
        """
        if not chunks:
            return chunks

        # Extract texts from chunks
        texts = [chunk.content for chunk in chunks]

        # Process in batches
        all_embeddings = []
        total_batches = (len(texts) + self.config.batch_size - 1) // self.config.batch_size

        for i in range(0, len(texts), self.config.batch_size):
            batch_texts = texts[i : i + self.config.batch_size]

            # Generate embeddings for this batch
            embeddings = await self.generate_embeddings_batch(batch_texts)
            all_embeddings.extend(embeddings)

            # Progress callback
            current_batch = (i // self.config.batch_size) + 1
            if progress_callback:
                progress_callback(current_batch, total_batches)

        # Add embeddings to chunks
        for chunk, embedding in zip(chunks, all_embeddings):
            chunk.embedding = embedding
            chunk.metadata["embedding_model"] = self.config.model
            chunk.metadata["embedding_provider"] = self.config.provider

        return chunks

    async def embed_query(self, query: str) -> list[float]:
        """
        Generate embedding for a search query.

        Args:
            query: Search query

        Returns:
            Query embedding
        """
        return await self.generate_embedding(query)

    async def health_check(self) -> bool:
        """
        Check if embedder is operational.

        Returns:
            True if embedder is ready to use
        """
        return True

    def __repr__(self) -> str:
        """String representation of embedder."""
        return f"{self.__class__.__name__}(model={self.config.model})"
