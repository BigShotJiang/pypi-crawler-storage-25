"""OpenAI-based embedding generator.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import asyncio
import logging
import os

from openai import APIError, AsyncOpenAI, RateLimitError

from .base import DocumentEmbedder, EmbeddingConfig, EmbeddingProvider

logger = logging.getLogger(__name__)


class OpenAIEmbedder(DocumentEmbedder):
    """
    OpenAI-based embedding generator.

    Uses OpenAI's embedding API for high-quality embeddings.
    Requires OPENAI_API_KEY environment variable.
    """

    # Model configurations
    MODEL_CONFIGS = {
        "text-embedding-3-small": {"dimensions": 1536, "max_tokens": 8191},
        "text-embedding-3-large": {"dimensions": 3072, "max_tokens": 8191},
        "text-embedding-ada-002": {"dimensions": 1536, "max_tokens": 8191},
    }

    def __init__(self, config: EmbeddingConfig | None = None):
        """
        Initialize OpenAI embedder.

        Args:
            config: Embedding configuration

        Raises:
            ValueError: If OPENAI_API_KEY is not set
        """
        if config is None:
            config = EmbeddingConfig(provider=EmbeddingProvider.OPENAI)

        super().__init__(config)

        # Get API key
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable is required for OpenAIEmbedder")

        # Initialize OpenAI client
        self.client = AsyncOpenAI(api_key=api_key)

        # Get model configuration
        if self.config.model not in self.MODEL_CONFIGS:
            logger.warning(f"Unknown model {self.config.model}, using default config")
            self.model_config = {"dimensions": 1536, "max_tokens": 8191}
        else:
            self.model_config = self.MODEL_CONFIGS[self.config.model]

        # Override dimensions if specified in config
        if self.config.dimensions is not None:
            self.model_config["dimensions"] = self.config.dimensions

        # Initialize cache if enabled
        self.cache = {} if self.config.use_cache else None

        logger.info(
            f"OpenAI embedder initialized with model={self.config.model}, "
            f"dimensions={self.get_embedding_dimension()}"
        )

    async def generate_embedding(self, text: str) -> list[float]:
        """
        Generate embedding for a single text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector

        Raises:
            Exception: If embedding generation fails after all retries
        """
        # Check cache first
        if self.cache is not None:
            cache_key = self._hash_text(text)
            if cache_key in self.cache:
                return self.cache[cache_key]

        # Truncate text if too long
        if len(text) > self.model_config["max_tokens"] * 4:  # Rough estimation
            text = text[: self.model_config["max_tokens"] * 4]

        for attempt in range(self.config.max_retries):
            try:
                response = await self.client.embeddings.create(model=self.config.model, input=text)

                embedding = response.data[0].embedding

                # Cache the result
                if self.cache is not None:
                    self._cache_embedding(text, embedding)

                return embedding

            except RateLimitError:
                if attempt == self.config.max_retries - 1:
                    raise

                # Exponential backoff for rate limits
                delay = self.config.retry_delay * (2**attempt)
                logger.warning(f"Rate limit hit, retrying in {delay}s")
                await asyncio.sleep(delay)

            except APIError as e:
                logger.error(f"OpenAI API error: {e}")
                if attempt == self.config.max_retries - 1:
                    raise
                await asyncio.sleep(self.config.retry_delay)

            except Exception as e:
                logger.error(f"Unexpected error generating embedding: {e}")
                if attempt == self.config.max_retries - 1:
                    raise
                await asyncio.sleep(self.config.retry_delay)

        raise Exception("Failed to generate embedding after all retries")

    async def generate_embeddings_batch(self, texts: list[str]) -> list[list[float]]:
        """
        Generate embeddings for a batch of texts.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors

        Raises:
            Exception: If embedding generation fails
        """
        if not texts:
            return []

        # Filter and truncate texts
        processed_texts = []
        for text in texts:
            if not text or not text.strip():
                processed_texts.append(" ")  # Use space for empty text
                continue

            # Truncate if too long
            if len(text) > self.model_config["max_tokens"] * 4:
                text = text[: self.model_config["max_tokens"] * 4]

            processed_texts.append(text)

        for attempt in range(self.config.max_retries):
            try:
                response = await self.client.embeddings.create(
                    model=self.config.model, input=processed_texts
                )

                embeddings = [data.embedding for data in response.data]

                # Cache results
                if self.cache is not None:
                    for text, embedding in zip(processed_texts, embeddings):
                        self._cache_embedding(text, embedding)

                return embeddings

            except RateLimitError:
                if attempt == self.config.max_retries - 1:
                    raise

                delay = self.config.retry_delay * (2**attempt)
                logger.warning(f"Rate limit hit, retrying batch in {delay}s")
                await asyncio.sleep(delay)

            except APIError as e:
                logger.error(f"OpenAI API error in batch: {e}")
                if attempt == self.config.max_retries - 1:
                    # Fallback to individual processing
                    return await self._process_individually(processed_texts)
                await asyncio.sleep(self.config.retry_delay)

            except Exception as e:
                logger.error(f"Unexpected error in batch embedding: {e}")
                if attempt == self.config.max_retries - 1:
                    return await self._process_individually(processed_texts)
                await asyncio.sleep(self.config.retry_delay)

        raise Exception("Failed to generate batch embeddings after all retries")

    async def _process_individually(self, texts: list[str]) -> list[list[float]]:
        """
        Process texts individually as fallback.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        embeddings = []

        for text in texts:
            try:
                if not text or not text.strip():
                    # Use zero vector for empty text
                    embeddings.append([0.0] * self.get_embedding_dimension())
                    continue

                embedding = await self.generate_embedding(text)
                embeddings.append(embedding)

                # Small delay to avoid overwhelming the API
                await asyncio.sleep(0.1)

            except Exception as e:
                logger.error(f"Failed to embed text: {e}")
                # Use zero vector as fallback
                embeddings.append([0.0] * self.get_embedding_dimension())

        return embeddings

    def get_embedding_dimension(self) -> int:
        """Get the dimension of embeddings for this model."""
        return self.model_config["dimensions"]

    def _hash_text(self, text: str) -> str:
        """Generate hash for text (for caching)."""
        import hashlib

        return hashlib.md5(text.encode()).hexdigest()

    def _cache_embedding(self, text: str, embedding: list[float]):
        """Store embedding in cache."""
        if self.cache is None:
            return

        cache_key = self._hash_text(text)

        # Evict oldest entries if cache is full
        if len(self.cache) >= self.config.cache_size:
            # Simple FIFO eviction (could be improved with LRU)
            first_key = next(iter(self.cache))
            del self.cache[first_key]

        self.cache[cache_key] = embedding

    async def health_check(self) -> bool:
        """
        Check if OpenAI API is accessible.

        Returns:
            True if API is accessible
        """
        try:
            # Simple check with minimal text
            await self.generate_embedding("test")
            return True
        except Exception as e:
            logger.error(f"OpenAI embedder health check failed: {e}")
            return False
