"""Azure OpenAI-based embedding generator.

This implementation extracts and modernizes the Azure AI functionality from the
Ashmatics Knowledgebase project, making it reusable across all Ashmatics applications.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import asyncio
import logging
import os
from datetime import datetime
from typing import Any

from openai import APIError, AsyncAzureOpenAI, RateLimitError

from .base import DocumentEmbedder, EmbeddingConfig, EmbeddingProvider

logger = logging.getLogger(__name__)


class AzureEmbedder(DocumentEmbedder):
    """
    Azure OpenAI-based embedding generator with enterprise features.

    This embedder provides:
    - Azure OpenAI API integration for embeddings
    - Usage tracking and statistics
    - Batch processing with rate limit handling
    - Connection health monitoring
    - Automatic retry logic with exponential backoff

    Environment Variables Required:
        AZURE_OPENAI_API_KEY: Azure OpenAI API key
        AZURE_OPENAI_ENDPOINT: Azure OpenAI endpoint URL
        AZURE_OPENAI_DEPLOYMENT_NAME: Deployment name for embeddings (optional, uses model name if not set)
        AZURE_OPENAI_API_VERSION: API version (default: 2024-02-01)

    Note:
        Environment variables must be set by the consuming application.
        This library does not load .env files automatically.

    Example:
        >>> config = EmbeddingConfig(
        ...     provider=EmbeddingProvider.AZURE,
        ...     model="text-embedding-ada-002",
        ...     batch_size=100
        ... )
        >>> embedder = AzureEmbedder(config)
        >>> await embedder.initialize()
        >>> embeddings = await embedder.generate_embeddings_batch(["Hello", "World"])
    """

    # Model configurations for Azure OpenAI
    MODEL_CONFIGS = {
        "text-embedding-3-small": {"dimensions": 1536, "max_tokens": 8191},
        "text-embedding-3-large": {"dimensions": 3072, "max_tokens": 8191},
        "text-embedding-ada-002": {"dimensions": 1536, "max_tokens": 8191},
    }

    def __init__(self, config: EmbeddingConfig | None = None):
        """
        Initialize Azure OpenAI embedder.

        Args:
            config: Embedding configuration

        Raises:
            ValueError: If required environment variables are not set
        """
        if config is None:
            config = EmbeddingConfig(provider=EmbeddingProvider.AZURE)

        super().__init__(config)

        # Get Azure configuration from environment
        self.api_key = os.getenv("AZURE_OPENAI_API_KEY")
        self.endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")

        # Get deployment name (optional, defaults to model name)
        # Azure deployments can have different names than the model
        self.deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")

        if not self.api_key or not self.endpoint:
            raise ValueError(
                "AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT environment "
                "variables are required for AzureEmbedder. "
                "Please set these in your application's environment."
            )

        # Client will be initialized lazily
        self._client: AsyncAzureOpenAI | None = None
        self._initialized = False

        # Get model configuration
        if self.config.model not in self.MODEL_CONFIGS:
            logger.warning(f"Unknown model {self.config.model}, using default config")
            self.model_config = {"dimensions": 1536, "max_tokens": 8191}
        else:
            self.model_config = self.MODEL_CONFIGS[self.config.model]

        # Override dimensions if specified in config
        if self.config.dimensions is not None:
            self.model_config["dimensions"] = self.config.dimensions

        # Initialize cache if enabled
        self.cache = {} if self.config.use_cache else None

        # Usage tracking
        self._usage_stats = {
            "total_requests": 0,
            "total_tokens": 0,
            "embeddings_requests": 0,
            "failed_requests": 0,
            "last_reset": datetime.utcnow(),
            "last_request": None,
        }

        logger.info(
            f"Azure embedder initialized with endpoint={self.endpoint}, "
            f"model={self.config.model}, "
            f"deployment={self.deployment_name or self.config.model}, "
            f"dimensions={self.get_embedding_dimension()}"
        )

    async def initialize(self) -> None:
        """
        Initialize the Azure OpenAI client and test connection.

        This method should be called before using the embedder.
        It's safe to call multiple times (idempotent).

        Raises:
            Exception: If initialization or connection test fails
        """
        if self._initialized:
            return

        try:
            self._client = AsyncAzureOpenAI(
                api_key=self.api_key,
                azure_endpoint=self.endpoint,
                api_version=self.api_version,
            )

            # Test connection with a minimal request
            await self._test_connection()

            self._initialized = True
            logger.info("Azure embedder successfully initialized and tested")

        except Exception as e:
            logger.error(f"Failed to initialize Azure embedder: {e}")
            raise

    async def _test_connection(self) -> None:
        """
        Test the Azure OpenAI connection with a minimal request.

        Raises:
            Exception: If connection test fails
        """
        try:
            # Use deployment name if available, otherwise use model name
            model_or_deployment = self.deployment_name or self.config.model

            test_response = await self._client.embeddings.create(
                model=model_or_deployment, input=["connection test"]
            )

            if not test_response.data:
                raise ValueError("Invalid response from Azure OpenAI")

            logger.info("Azure OpenAI connection test successful")

        except Exception as e:
            logger.error(f"Azure OpenAI connection test failed: {e}")
            raise

    async def _ensure_initialized(self) -> None:
        """Ensure the client is initialized before use."""
        if not self._initialized:
            await self.initialize()

    async def generate_embedding(self, text: str) -> list[float]:
        """
        Generate embedding for a single text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector

        Raises:
            ValueError: If text is empty
            Exception: If embedding generation fails after all retries
        """
        await self._ensure_initialized()

        if not text or not text.strip():
            raise ValueError("Text cannot be empty")

        # Check cache first
        if self.cache is not None:
            cache_key = self._hash_text(text)
            if cache_key in self.cache:
                logger.debug("Cache hit for text embedding")
                return self.cache[cache_key]

        # Truncate text if too long
        if len(text) > self.model_config["max_tokens"] * 4:  # Rough estimation
            logger.warning(
                f"Text truncated from {len(text)} to {self.model_config['max_tokens'] * 4} chars"
            )
            text = text[: self.model_config["max_tokens"] * 4]

        for attempt in range(self.config.max_retries):
            try:
                # Use deployment name if available, otherwise use model name
                model_or_deployment = self.deployment_name or self.config.model

                response = await self._client.embeddings.create(
                    model=model_or_deployment, input=text
                )

                embedding = response.data[0].embedding

                # Update usage statistics
                self._update_usage_stats(response.usage.total_tokens)

                # Cache the result
                if self.cache is not None:
                    self._cache_embedding(text, embedding)

                return embedding

            except RateLimitError:
                if attempt == self.config.max_retries - 1:
                    self._usage_stats["failed_requests"] += 1
                    raise

                # Exponential backoff for rate limits
                delay = self.config.retry_delay * (2**attempt)
                logger.warning(
                    f"Rate limit hit (attempt {attempt + 1}/{self.config.max_retries}), "
                    f"retrying in {delay}s"
                )
                await asyncio.sleep(delay)

            except APIError as e:
                logger.error(f"Azure OpenAI API error: {e}")
                if attempt == self.config.max_retries - 1:
                    self._usage_stats["failed_requests"] += 1
                    raise
                await asyncio.sleep(self.config.retry_delay)

            except Exception as e:
                logger.error(f"Unexpected error generating embedding: {e}")
                if attempt == self.config.max_retries - 1:
                    self._usage_stats["failed_requests"] += 1
                    raise
                await asyncio.sleep(self.config.retry_delay)

        self._usage_stats["failed_requests"] += 1
        raise Exception("Failed to generate embedding after all retries")

    async def generate_embeddings_batch(self, texts: list[str]) -> list[list[float]]:
        """
        Generate embeddings for a batch of texts.

        This method handles:
        - Empty text filtering
        - Text truncation
        - Automatic retry with exponential backoff
        - Fallback to individual processing on failure

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors

        Raises:
            Exception: If embedding generation fails
        """
        await self._ensure_initialized()

        if not texts:
            return []

        # Azure OpenAI batch limit
        if len(texts) > 100:
            logger.warning(
                f"Batch size {len(texts)} exceeds Azure limit of 100, will process in chunks"
            )
            # Process in chunks of 100
            all_embeddings = []
            for i in range(0, len(texts), 100):
                chunk = texts[i : i + 100]
                embeddings = await self.generate_embeddings_batch(chunk)
                all_embeddings.extend(embeddings)
            return all_embeddings

        # Filter and truncate texts
        processed_texts = []
        for text in texts:
            if not text or not text.strip():
                processed_texts.append(" ")  # Use space for empty text
                continue

            # Truncate if too long
            if len(text) > self.model_config["max_tokens"] * 4:
                text = text[: self.model_config["max_tokens"] * 4]

            processed_texts.append(text)

        for attempt in range(self.config.max_retries):
            try:
                # Use deployment name if available, otherwise use model name
                model_or_deployment = self.deployment_name or self.config.model

                response = await self._client.embeddings.create(
                    model=model_or_deployment, input=processed_texts
                )

                embeddings = [data.embedding for data in response.data]

                # Update usage statistics
                self._update_usage_stats(response.usage.total_tokens)

                # Cache results
                if self.cache is not None:
                    for text, embedding in zip(processed_texts, embeddings):
                        self._cache_embedding(text, embedding)

                return embeddings

            except RateLimitError:
                if attempt == self.config.max_retries - 1:
                    self._usage_stats["failed_requests"] += 1
                    raise

                delay = self.config.retry_delay * (2**attempt)
                logger.warning(
                    f"Rate limit hit on batch (attempt {attempt + 1}/{self.config.max_retries}), "
                    f"retrying in {delay}s"
                )
                await asyncio.sleep(delay)

            except APIError as e:
                logger.error(f"Azure OpenAI API error in batch: {e}")
                if attempt == self.config.max_retries - 1:
                    # Fallback to individual processing
                    logger.warning("Falling back to individual text processing")
                    return await self._process_individually(processed_texts)
                await asyncio.sleep(self.config.retry_delay)

            except Exception as e:
                logger.error(f"Unexpected error in batch embedding: {e}")
                if attempt == self.config.max_retries - 1:
                    logger.warning("Falling back to individual text processing")
                    return await self._process_individually(processed_texts)
                await asyncio.sleep(self.config.retry_delay)

        self._usage_stats["failed_requests"] += 1
        raise Exception("Failed to generate batch embeddings after all retries")

    async def _process_individually(self, texts: list[str]) -> list[list[float]]:
        """
        Process texts individually as fallback when batch processing fails.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        embeddings = []

        for i, text in enumerate(texts):
            try:
                if not text or not text.strip():
                    # Use zero vector for empty text
                    embeddings.append([0.0] * self.get_embedding_dimension())
                    continue

                embedding = await self.generate_embedding(text)
                embeddings.append(embedding)

                # Small delay to avoid overwhelming the API
                if i < len(texts) - 1:  # Don't delay after last item
                    await asyncio.sleep(0.1)

            except Exception as e:
                logger.error(f"Failed to embed text individually (index {i}): {e}")
                # Use zero vector as fallback
                embeddings.append([0.0] * self.get_embedding_dimension())

        return embeddings

    def get_embedding_dimension(self) -> int:
        """
        Get the dimension of embeddings for this model.

        Returns:
            Embedding dimension
        """
        return self.model_config["dimensions"]

    def _hash_text(self, text: str) -> str:
        """
        Generate hash for text (for caching).

        Args:
            text: Text to hash

        Returns:
            MD5 hash of text
        """
        import hashlib

        return hashlib.md5(text.encode()).hexdigest()

    def _cache_embedding(self, text: str, embedding: list[float]) -> None:
        """
        Store embedding in cache with LRU-style eviction.

        Args:
            text: Original text
            embedding: Generated embedding
        """
        if self.cache is None:
            return

        cache_key = self._hash_text(text)

        # Evict oldest entries if cache is full
        if len(self.cache) >= self.config.cache_size:
            # Simple FIFO eviction (could be improved with LRU)
            first_key = next(iter(self.cache))
            del self.cache[first_key]

        self.cache[cache_key] = embedding

    def _update_usage_stats(self, tokens: int) -> None:
        """
        Update usage statistics after a successful request.

        Args:
            tokens: Number of tokens used
        """
        self._usage_stats["total_requests"] += 1
        self._usage_stats["embeddings_requests"] += 1
        self._usage_stats["total_tokens"] += tokens
        self._usage_stats["last_request"] = datetime.utcnow()

    async def get_usage_stats(self) -> dict[str, Any]:
        """
        Get current usage statistics.

        Returns:
            Dict containing usage statistics including:
            - total_requests: Total number of requests made
            - embeddings_requests: Number of embedding requests
            - failed_requests: Number of failed requests
            - total_tokens: Total tokens processed
            - uptime_hours: Hours since stats were reset
            - cache_size: Current cache size (if caching enabled)
        """
        stats = {
            **self._usage_stats,
            "uptime_hours": (datetime.utcnow() - self._usage_stats["last_reset"]).total_seconds()
            / 3600,
        }

        if self.cache is not None:
            stats["cache_size"] = len(self.cache)
            stats["cache_hit_rate"] = "N/A"  # Could be enhanced with hit tracking

        return stats

    async def reset_usage_stats(self) -> None:
        """Reset usage statistics to zero."""
        self._usage_stats = {
            "total_requests": 0,
            "total_tokens": 0,
            "embeddings_requests": 0,
            "failed_requests": 0,
            "last_reset": datetime.utcnow(),
            "last_request": None,
        }
        logger.info("Usage statistics reset")

    async def health_check(self) -> bool:
        """
        Check if Azure OpenAI API is accessible and functioning.

        Returns:
            True if API is accessible and working
        """
        try:
            await self._ensure_initialized()

            # Simple check with minimal text
            test_embedding = await self.generate_embedding("health check")

            # Verify embedding has correct dimensions
            if len(test_embedding) != self.get_embedding_dimension():
                logger.error(
                    f"Health check failed: expected {self.get_embedding_dimension()} "
                    f"dimensions, got {len(test_embedding)}"
                )
                return False

            logger.info("Azure embedder health check passed")
            return True

        except Exception as e:
            logger.error(f"Azure embedder health check failed: {e}")
            return False

    async def get_detailed_health(self) -> dict[str, Any]:
        """
        Get detailed health information including connectivity and statistics.

        Returns:
            Dict containing detailed health information:
            - status: "healthy" or "unhealthy"
            - service: Service name
            - initialized: Whether client is initialized
            - endpoint: Azure endpoint URL
            - model: Model being used
            - dimensions: Embedding dimensions
            - usage_stats: Current usage statistics
            - last_error: Last error if any
        """
        try:
            is_healthy = await self.health_check()

            return {
                "status": "healthy" if is_healthy else "unhealthy",
                "service": "azure_openai_embeddings",
                "initialized": self._initialized,
                "endpoint": self.endpoint,
                "model": self.config.model,
                "dimensions": self.get_embedding_dimension(),
                "usage_stats": await self.get_usage_stats(),
                "last_error": None,
            }

        except Exception as e:
            return {
                "status": "unhealthy",
                "service": "azure_openai_embeddings",
                "initialized": self._initialized,
                "endpoint": self.endpoint,
                "model": self.config.model,
                "error": str(e),
                "last_error": datetime.utcnow().isoformat(),
            }

    async def close(self) -> None:
        """
        Close the Azure OpenAI client and cleanup resources.

        This should be called when the embedder is no longer needed,
        typically at application shutdown.
        """
        if self._client:
            await self._client.close()
            self._client = None
            self._initialized = False
            logger.info("Azure embedder closed and cleaned up")

    def __repr__(self) -> str:
        """String representation of embedder."""
        return (
            f"AzureEmbedder(model={self.config.model}, "
            f"dimensions={self.get_embedding_dimension()}, "
            f"endpoint={self.endpoint})"
        )
