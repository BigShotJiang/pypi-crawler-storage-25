# Copyright 2025 Asher Informatics PBC
"""Custom exceptions for search/RAG operations."""

from typing import Any


class RAGError(Exception):
    """Base exception for RAG operations."""

    pass


class RetrievalError(RAGError):
    """Error during document retrieval from vector store."""

    def __init__(self, message: str, backend: str | None = None):
        """Initialize retrieval error.

        Args:
            message: Error description
            backend: Vector store backend name (e.g., "cosmosdb", "qdrant")
        """
        super().__init__(message)
        self.backend = backend


class NoSourcesFoundError(RAGError):
    """No relevant sources found for the query."""

    def __init__(self, query: str, search_params: dict[str, Any] | None = None):
        """Initialize no sources found error.

        Args:
            query: The search query that returned no results
            search_params: Search parameters used (top_k, min_score, etc.)
        """
        super().__init__(f"No sources found for query: {query}")
        self.query = query
        self.search_params = search_params or {}


class GenerationError(RAGError):
    """Error during answer generation from LLM."""

    def __init__(self, message: str, provider: str | None = None):
        """Initialize generation error.

        Args:
            message: Error description
            provider: LLM provider name (e.g., "azure_openai", "ollama")
        """
        super().__init__(message)
        self.provider = provider


class ContextWindowExceededError(RAGError):
    """Query and context exceed the model's context window."""

    def __init__(
        self,
        message: str,
        required_tokens: int,
        available_tokens: int,
    ):
        """Initialize context window exceeded error.

        Args:
            message: Error description
            required_tokens: Number of tokens needed
            available_tokens: Maximum tokens available
        """
        super().__init__(message)
        self.required_tokens = required_tokens
        self.available_tokens = available_tokens
