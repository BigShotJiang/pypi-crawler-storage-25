# Copyright 2025 Asher Informatics PBC
"""Search & RAG Module for AshMatics Suite.

Provides:
- Multiple RAG strategies (simple, multi-query)
- Standard prompt templates
- Factory with plugin registry for custom strategies
- MCP tool definitions for agent integration

Example:
    ```python
    from ashmatics_tools.llm import create_llm_client, AzureOpenAIConfig
    from ashmatics_tools.embedders import create_embedder
    from ashmatics_tools.vector_stores import create_vector_store
    from ashmatics_tools.search import create_search_strategy, RAGConfig

    # Create components (existing patterns)
    llm = create_llm_client("azure_openai", AzureOpenAIConfig(...))
    embedder = create_embedder("azure")
    vector_store = create_vector_store("cosmosdb", VectorStoreConfig(...))

    # Create RAG strategy
    rag = create_search_strategy(
        "simple_rag",
        llm=llm,
        vector_store=vector_store,
        embedder=embedder,
        config=RAGConfig(top_k=10)
    )

    # Query
    result = await rag.query("What are ISO 42001 requirements?")
    print(result.answer)
    print(f"Sources: {len(result.sources)}")
    print(f"Cost: ${result.metrics.estimated_cost:.4f}")

    # Streaming
    async for chunk in rag.stream_query("Explain risk management"):
        print(chunk.text, end="", flush=True)

    # Multi-query RAG for better coverage
    from ashmatics_tools.search.strategies import MultiQueryConfig

    multi_rag = create_search_strategy(
        "multi_query_rag",
        llm=llm,
        vector_store=vector_store,
        embedder=embedder,
        config=MultiQueryConfig(num_query_variants=4, top_k=10)
    )
    result = await multi_rag.query("What are ISO 42001 requirements?")
    print(f"Expanded queries: {result.metadata['expanded_queries']}")
    ```
"""

from .base import (
    RAGConfig,
    RAGMetrics,
    RAGResult,
    RAGStrategy,
    RAGStreamChunk,
)
from .exceptions import (
    ContextWindowExceededError,
    GenerationError,
    NoSourcesFoundError,
    RAGError,
    RetrievalError,
)
from .factory import (
    create_search_strategy,
    get_registered_strategies,
    register_search_strategy,
    unregister_search_strategy,
)
from .strategies import MultiQueryConfig, MultiQueryRAGStrategy, SimpleRAGStrategy

__all__ = [
    # Base classes
    "RAGStrategy",
    "RAGConfig",
    "RAGResult",
    "RAGMetrics",
    "RAGStreamChunk",
    # Strategies
    "SimpleRAGStrategy",
    "MultiQueryRAGStrategy",
    "MultiQueryConfig",
    # Factory
    "create_search_strategy",
    "register_search_strategy",
    "unregister_search_strategy",
    "get_registered_strategies",
    # Exceptions
    "RAGError",
    "RetrievalError",
    "NoSourcesFoundError",
    "GenerationError",
    "ContextWindowExceededError",
]
