# Copyright 2025 Asher Informatics PBC
"""Factory and plugin registry for RAG strategies.

Follows the same factory + registry pattern as other ashmatics-tools modules
(llm, vector_stores, embedders) for consistency.

See ADR-ASHTOOLS-5 for design decisions.
"""

import logging
from typing import TYPE_CHECKING, Any

from .base import RAGConfig, RAGStrategy

if TYPE_CHECKING:
    from ..embedders.base import DocumentEmbedder
    from ..llm.base import BaseLLMClient
    from ..vector_stores.base import VectorStore

logger = logging.getLogger(__name__)

# Registry of RAG strategy classes
_STRATEGY_REGISTRY: dict[str, type[RAGStrategy]] = {}


def register_search_strategy(name: str, strategy_class: type[RAGStrategy]) -> None:
    """Register a custom RAG strategy.

    Example:
        ```python
        from ashmatics_tools.search import RAGStrategy, register_search_strategy

        class MyCustomRAGStrategy(RAGStrategy):
            async def query(self, query: str, **kwargs):
                # Custom implementation
                pass

        register_search_strategy("my_custom", MyCustomRAGStrategy)
        ```

    Args:
        name: Strategy name for use with create_search_strategy()
        strategy_class: Class implementing RAGStrategy
    """
    logger.info(f"Registering RAG strategy: {name}")
    _STRATEGY_REGISTRY[name] = strategy_class


def unregister_search_strategy(name: str) -> None:
    """Unregister a RAG strategy.

    Args:
        name: Strategy name to remove

    Raises:
        ValueError: If strategy is not registered
    """
    if name not in _STRATEGY_REGISTRY:
        raise ValueError(f"Strategy '{name}' is not registered")
    del _STRATEGY_REGISTRY[name]
    logger.info(f"Unregistered RAG strategy: {name}")


def get_registered_strategies() -> list[str]:
    """Return list of registered strategy names.

    Returns:
        List of available strategy names
    """
    return list(_STRATEGY_REGISTRY.keys())


def create_search_strategy(
    strategy: str,
    llm: "BaseLLMClient",
    vector_store: "VectorStore",
    embedder: "DocumentEmbedder",
    config: RAGConfig | None = None,
    **kwargs: Any,
) -> RAGStrategy:
    """Create a RAG strategy instance.

    Args:
        strategy: Name of the strategy (e.g., "simple_rag", "multi_query_rag")
        llm: LLM client for answer generation
        vector_store: Vector store for document retrieval
        embedder: Embedder for query embedding
        config: RAG configuration (uses defaults if None)
        **kwargs: Additional strategy-specific parameters

    Returns:
        Configured RAG strategy instance

    Raises:
        ValueError: If strategy is not registered

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client
        from ashmatics_tools.embedders import create_embedder
        from ashmatics_tools.vector_stores import create_vector_store
        from ashmatics_tools.search import create_search_strategy, RAGConfig

        llm = create_llm_client("azure_openai", llm_config)
        embedder = create_embedder("azure")
        vector_store = create_vector_store("cosmosdb", vs_config)

        rag = create_search_strategy(
            "simple_rag",
            llm=llm,
            vector_store=vector_store,
            embedder=embedder,
            config=RAGConfig(top_k=10, temperature=0.7)
        )

        result = await rag.query("What are the requirements?")
        ```
    """
    if strategy not in _STRATEGY_REGISTRY:
        available = ", ".join(_STRATEGY_REGISTRY.keys()) or "none"
        raise ValueError(f"Unknown strategy: '{strategy}'. Available: {available}")

    config = config or RAGConfig()
    strategy_class = _STRATEGY_REGISTRY[strategy]

    logger.debug(
        f"Creating RAG strategy: {strategy}",
        extra={
            "strategy": strategy,
            "top_k": config.top_k,
            "temperature": config.temperature,
        },
    )

    return strategy_class(llm, vector_store, embedder, config, **kwargs)


def _register_builtin_strategies() -> None:
    """Register built-in RAG strategies."""
    from .strategies.simple_rag import SimpleRAGStrategy

    register_search_strategy("simple_rag", SimpleRAGStrategy)

    # Multi-query strategy (registered if available)
    try:
        from .strategies.multi_query_rag import MultiQueryRAGStrategy

        register_search_strategy("multi_query_rag", MultiQueryRAGStrategy)
    except ImportError:
        logger.debug("MultiQueryRAGStrategy not available")


# Auto-register built-in strategies at module load
_register_builtin_strategies()
