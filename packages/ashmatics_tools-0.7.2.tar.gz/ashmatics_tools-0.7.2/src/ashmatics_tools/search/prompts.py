# Copyright 2025 Asher Informatics PBC
"""Standard prompt templates for RAG operations.

These prompts are designed to be customizable while providing sensible defaults.
Use {context} and {query} placeholders that will be filled by RAG strategies.
"""

DEFAULT_RAG_SYSTEM_PROMPT = """You are a helpful assistant. Answer the question based on the provided context.
If the context doesn't contain enough information to fully answer the question, acknowledge what you can determine from the context and note what information is missing.

Context:
{context}

Guidelines:
- Be concise and accurate
- Cite source numbers when referencing specific information (e.g., "[Source 1]")
- If unsure, express uncertainty rather than speculating
- Do not make up information not present in the context
"""

QUERY_EXPANSION_PROMPT = """Generate {num_queries} alternative search queries for the following question.
The queries should approach the topic from different angles or use different terminology to improve search coverage.

Original question: {query}

Return ONLY a JSON array of strings, no other text or explanation:
["alternative query 1", "alternative query 2", "alternative query 3"]
"""

MULTI_SOURCE_SYNTHESIS_PROMPT = """Given search results from multiple sources, synthesize a comprehensive answer.

Original question: {query}

Search results:
{results}

Provide a clear, well-organized answer that:
1. Addresses the question directly
2. Integrates information from multiple sources where relevant
3. Notes any conflicting information between sources
4. Cites sources by number when making specific claims (e.g., "[Source 1]")
"""

RERANKING_PROMPT = """Rate the relevance of each document to the query on a scale of 1-10.
A score of 10 means the document directly and completely answers the query.
A score of 1 means the document is completely irrelevant.

Query: {query}

Documents:
{documents}

Return ONLY a JSON object mapping document IDs to scores:
{{"doc_1": 8, "doc_2": 3, "doc_3": 6}}
"""

# Governance-specific prompt (for AshMatics governance applications)
GOVERNANCE_RAG_SYSTEM_PROMPT = """You are a governance and compliance assistant for AI systems.
Answer questions based on the provided governance artifacts (policies, procedures, controls).

Context:
{context}

Guidelines:
- Reference specific control numbers (e.g., "ISO 42001 Section 5.1")
- Cite document sources when referencing requirements
- Distinguish between mandatory requirements ("shall") and recommendations ("should")
- If the context doesn't address the question, say so clearly
- Do not provide legal or regulatory advice beyond what's in the documents
"""
