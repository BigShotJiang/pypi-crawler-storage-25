# Copyright 2025 Asher Informatics PBC
"""MCP tool definitions for RAG and search operations.

This module provides generic MCP (Model Context Protocol) tool definitions
that can be used by consuming applications to expose RAG and search
capabilities to LLM agents.

These are tool DEFINITIONS only - the actual implementation is handled by
the consuming application's MCP server, which uses the RAG strategies from
this module.

Example:
    ```python
    from ashmatics_tools.search.mcp_tools import (
        RAG_SEARCH_TOOL,
        SEMANTIC_SEARCH_TOOL,
        get_tool_definitions,
    )

    # Get all tool definitions for your MCP server
    tools = get_tool_definitions()

    # Or export as YAML for configuration
    yaml_config = export_tools_yaml()
    ```
"""

import json
from dataclasses import dataclass, field
from typing import Any

import yaml


@dataclass
class MCPToolDefinition:
    """Definition of an MCP tool for agent discovery.

    This follows the MCP tool schema specification for tool definitions
    that can be registered with MCP servers.

    Attributes:
        name: Tool name (lowercase, underscores allowed)
        description: Human-readable description of what the tool does
        input_schema: JSON Schema for tool input parameters
        output_schema: JSON Schema for tool output (optional)
        version: Tool version string
        tags: Optional tags for categorization
    """

    name: str
    description: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any] = field(default_factory=dict)
    version: str = "1.0.0"
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary format for MCP registration."""
        result = {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
            "version": self.version,
        }
        if self.output_schema:
            result["outputSchema"] = self.output_schema
        if self.tags:
            result["tags"] = self.tags
        return result

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    def to_yaml(self) -> str:
        """Convert to YAML string."""
        return yaml.dump(self.to_dict(), default_flow_style=False, sort_keys=False)


# =============================================================================
# Generic RAG/Search Tool Definitions
# =============================================================================

RAG_SEARCH_TOOL = MCPToolDefinition(
    name="rag_search",
    description=(
        "Perform RAG-enhanced search with answer generation. "
        "Retrieves relevant documents from the knowledge base and generates "
        "a natural language answer with source citations. Use this when you "
        "need to answer questions using the organization's knowledge base."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural language question or search query",
            },
            "top_k": {
                "type": "integer",
                "description": "Maximum number of source documents to retrieve",
                "default": 10,
                "minimum": 1,
                "maximum": 50,
            },
            "strategy": {
                "type": "string",
                "description": "RAG strategy to use",
                "enum": ["simple_rag", "multi_query_rag"],
                "default": "simple_rag",
            },
            "include_sources": {
                "type": "boolean",
                "description": "Whether to include source documents in response",
                "default": True,
            },
            "filters": {
                "type": "object",
                "description": "Optional metadata filters for retrieval",
                "additionalProperties": True,
            },
        },
        "required": ["query"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "answer": {
                "type": "string",
                "description": "Generated answer with source citations",
            },
            "sources": {
                "type": "array",
                "description": "Source documents used for the answer",
                "items": {
                    "type": "object",
                    "properties": {
                        "document_id": {"type": "string"},
                        "content": {"type": "string"},
                        "score": {"type": "number"},
                        "metadata": {"type": "object"},
                    },
                },
            },
            "metrics": {
                "type": "object",
                "description": "Performance and cost metrics",
                "properties": {
                    "total_tokens": {"type": "integer"},
                    "latency_ms": {"type": "number"},
                    "num_sources": {"type": "integer"},
                },
            },
        },
        "required": ["answer"],
    },
    version="1.0.0",
    tags=["search", "rag", "knowledge-base"],
)

SEMANTIC_SEARCH_TOOL = MCPToolDefinition(
    name="semantic_search",
    description=(
        "Perform semantic similarity search without answer generation. "
        "Returns the most relevant documents from the knowledge base based on "
        "semantic similarity to the query. Use this when you need to find "
        "relevant documents without generating an answer."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural language search query",
            },
            "top_k": {
                "type": "integer",
                "description": "Maximum number of documents to return",
                "default": 10,
                "minimum": 1,
                "maximum": 100,
            },
            "min_score": {
                "type": "number",
                "description": "Minimum similarity score threshold (0.0-1.0)",
                "default": 0.0,
                "minimum": 0.0,
                "maximum": 1.0,
            },
            "filters": {
                "type": "object",
                "description": "Optional metadata filters",
                "additionalProperties": True,
            },
        },
        "required": ["query"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "results": {
                "type": "array",
                "description": "Matching documents ordered by relevance",
                "items": {
                    "type": "object",
                    "properties": {
                        "document_id": {"type": "string"},
                        "content": {"type": "string"},
                        "score": {"type": "number"},
                        "rank": {"type": "integer"},
                        "metadata": {"type": "object"},
                    },
                },
            },
            "total_found": {
                "type": "integer",
                "description": "Total number of matching documents",
            },
        },
        "required": ["results"],
    },
    version="1.0.0",
    tags=["search", "semantic", "knowledge-base"],
)

MULTI_QUERY_SEARCH_TOOL = MCPToolDefinition(
    name="multi_query_search",
    description=(
        "Advanced RAG search that expands the query into multiple variants "
        "to improve retrieval coverage. Useful for complex queries that might "
        "use different terminology than the source documents."
    ),
    input_schema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural language question or search query",
            },
            "num_variants": {
                "type": "integer",
                "description": "Number of query variants to generate",
                "default": 3,
                "minimum": 1,
                "maximum": 5,
            },
            "top_k": {
                "type": "integer",
                "description": "Maximum number of source documents per variant",
                "default": 10,
                "minimum": 1,
                "maximum": 50,
            },
            "include_sources": {
                "type": "boolean",
                "description": "Whether to include source documents in response",
                "default": True,
            },
            "filters": {
                "type": "object",
                "description": "Optional metadata filters for retrieval",
                "additionalProperties": True,
            },
        },
        "required": ["query"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "answer": {
                "type": "string",
                "description": "Generated answer with source citations",
            },
            "expanded_queries": {
                "type": "array",
                "description": "Query variants used for retrieval",
                "items": {"type": "string"},
            },
            "sources": {
                "type": "array",
                "description": "Deduplicated source documents",
                "items": {
                    "type": "object",
                    "properties": {
                        "document_id": {"type": "string"},
                        "content": {"type": "string"},
                        "score": {"type": "number"},
                        "metadata": {"type": "object"},
                    },
                },
            },
            "metrics": {
                "type": "object",
                "description": "Performance metrics including expansion stats",
            },
        },
        "required": ["answer"],
    },
    version="1.0.0",
    tags=["search", "rag", "multi-query", "knowledge-base"],
)

# All tool definitions
_TOOL_DEFINITIONS: list[MCPToolDefinition] = [
    RAG_SEARCH_TOOL,
    SEMANTIC_SEARCH_TOOL,
    MULTI_QUERY_SEARCH_TOOL,
]


def get_tool_definitions() -> list[MCPToolDefinition]:
    """Get all available MCP tool definitions.

    Returns:
        List of MCPToolDefinition objects
    """
    return _TOOL_DEFINITIONS.copy()


def get_tool_by_name(name: str) -> MCPToolDefinition | None:
    """Get a specific tool definition by name.

    Args:
        name: Tool name

    Returns:
        MCPToolDefinition or None if not found
    """
    for tool in _TOOL_DEFINITIONS:
        if tool.name == name:
            return tool
    return None


def export_tools_json(indent: int = 2) -> str:
    """Export all tool definitions as JSON.

    Args:
        indent: JSON indentation level

    Returns:
        JSON string with all tool definitions
    """
    return json.dumps(
        [tool.to_dict() for tool in _TOOL_DEFINITIONS],
        indent=indent,
    )


def export_tools_yaml() -> str:
    """Export all tool definitions as YAML.

    Returns:
        YAML string with all tool definitions
    """
    return yaml.dump(
        [tool.to_dict() for tool in _TOOL_DEFINITIONS],
        default_flow_style=False,
        sort_keys=False,
    )
