# Copyright 2025 Asher Informatics PBC
"""Base interfaces for RAG strategies.

This module provides abstract base classes and data structures for RAG
(Retrieval-Augmented Generation) implementations. Designed to work with
existing ashmatics-tools modules:
- LLM clients (ashmatics_tools.llm)
- Vector stores (ashmatics_tools.vector_stores)
- Embedders (ashmatics_tools.embedders)
"""

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..embedders.base import DocumentEmbedder
    from ..llm.base import BaseLLMClient
    from ..vector_stores.base import SearchResult, VectorStore


@dataclass
class RAGConfig:
    """Configuration for RAG strategies.

    Attributes:
        top_k: Number of documents to retrieve
        temperature: LLM sampling temperature (0.0 to 2.0)
        max_tokens: Maximum tokens for LLM response
        include_sources: Whether to include source documents in result
        min_score_threshold: Minimum similarity score for retrieved documents
        system_prompt: Custom system prompt (uses default if None)
        max_context_tokens: Maximum tokens for context (None = no limit)
    """

    top_k: int = 10
    temperature: float = 0.7
    max_tokens: int = 1000
    include_sources: bool = True
    min_score_threshold: float = 0.0
    system_prompt: str | None = None
    max_context_tokens: int | None = None


@dataclass
class RAGMetrics:
    """Performance and cost metrics for RAG operations.

    Attributes:
        total_tokens: Total tokens used (prompt + completion)
        prompt_tokens: Tokens in the prompt
        completion_tokens: Tokens in the completion
        estimated_cost: Estimated cost in USD
        latency_ms: Total latency in milliseconds
        num_sources: Number of source documents used
        retrieval_latency_ms: Time spent on retrieval
        generation_latency_ms: Time spent on generation
    """

    total_tokens: int
    prompt_tokens: int
    completion_tokens: int
    estimated_cost: float
    latency_ms: float
    num_sources: int
    retrieval_latency_ms: float = 0.0
    generation_latency_ms: float = 0.0


@dataclass
class RAGResult:
    """Complete result from a RAG query.

    Attributes:
        answer: The generated answer
        sources: List of source documents used
        query: The original query
        metrics: Performance and cost metrics
        metadata: Additional metadata (e.g., expanded_queries for multi-query RAG)
    """

    answer: str
    sources: list["SearchResult"]
    query: str
    metrics: RAGMetrics
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RAGStreamChunk:
    """Single chunk from a streaming RAG response.

    Attributes:
        text: The text content of this chunk
        is_final: Whether this is the final chunk
        sources: Source documents (populated on final chunk)
        metrics: Metrics (populated on final chunk)
    """

    text: str
    is_final: bool = False
    sources: list["SearchResult"] = field(default_factory=list)
    metrics: RAGMetrics | None = None


class RAGStrategy(ABC):
    """Abstract base class for RAG strategies.

    RAG strategies define how to retrieve context and generate answers.
    All strategies use composition to work with existing ashmatics-tools
    components (LLM clients, vector stores, embedders).

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client, AzureOpenAIConfig
        from ashmatics_tools.embedders import create_embedder
        from ashmatics_tools.vector_stores import create_vector_store
        from ashmatics_tools.search import create_search_strategy, RAGConfig

        # Create components
        llm = create_llm_client("azure_openai", config)
        embedder = create_embedder("azure")
        vector_store = create_vector_store("cosmosdb", vs_config)

        # Create RAG strategy
        rag = create_search_strategy(
            "simple_rag",
            llm=llm,
            vector_store=vector_store,
            embedder=embedder,
            config=RAGConfig(top_k=10)
        )

        # Query
        result = await rag.query("What are ISO 42001 requirements?")
        print(result.answer)
        ```
    """

    def __init__(
        self,
        llm: "BaseLLMClient",
        vector_store: "VectorStore",
        embedder: "DocumentEmbedder",
        config: RAGConfig | None = None,
    ):
        """Initialize RAG strategy.

        Args:
            llm: LLM client for answer generation
            vector_store: Vector store for document retrieval
            embedder: Embedder for query embedding
            config: RAG configuration (uses defaults if None)
        """
        self.llm = llm
        self.vector_store = vector_store
        self.embedder = embedder
        self.config = config or RAGConfig()

    @abstractmethod
    async def query(self, query: str, **kwargs: Any) -> RAGResult:
        """Execute RAG query and return complete result.

        Args:
            query: Natural language query
            **kwargs: Additional strategy-specific parameters

        Returns:
            RAGResult with answer, sources, and metrics

        Raises:
            RetrievalError: If document retrieval fails
            GenerationError: If answer generation fails
            NoSourcesFoundError: If no relevant sources found
        """

    async def stream_query(
        self, query: str, **kwargs: Any
    ) -> AsyncIterator[RAGStreamChunk]:
        """Stream RAG response, yielding chunks as they arrive.

        Default implementation falls back to non-streaming query() and yields
        the complete response as a single chunk. Subclasses should override
        for true streaming support.

        Args:
            query: Natural language query
            **kwargs: Additional strategy-specific parameters

        Yields:
            RAGStreamChunk objects with text fragments

        Raises:
            RetrievalError: If document retrieval fails
            GenerationError: If answer generation fails
        """
        # Default: fall back to non-streaming and yield single chunk
        result = await self.query(query, **kwargs)
        yield RAGStreamChunk(
            text=result.answer,
            is_final=True,
            sources=result.sources,
            metrics=result.metrics,
        )
