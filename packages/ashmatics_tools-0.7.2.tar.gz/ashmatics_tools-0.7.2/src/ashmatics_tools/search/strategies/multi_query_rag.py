# Copyright 2025 Asher Informatics PBC
"""Multi-Query RAG strategy implementation.

This module provides an advanced RAG strategy that expands the original query
into multiple variants to improve retrieval coverage. Key features:
- Query expansion via LLM
- Parallel retrieval across query variants
- Result deduplication and ranking
- Reciprocal Rank Fusion (RRF) for scoring
"""

import asyncio
import json
import logging
import time
from collections import defaultdict
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ..base import RAGConfig, RAGMetrics, RAGResult, RAGStrategy, RAGStreamChunk
from ..exceptions import GenerationError, NoSourcesFoundError, RetrievalError
from ..prompts import DEFAULT_RAG_SYSTEM_PROMPT, QUERY_EXPANSION_PROMPT

if TYPE_CHECKING:
    from ...embedders.base import DocumentEmbedder
    from ...llm.base import BaseLLMClient, LLMMessage, TokenUsage
    from ...vector_stores.base import SearchResult, VectorStore

logger = logging.getLogger(__name__)


@dataclass
class MultiQueryConfig(RAGConfig):
    """Configuration for Multi-Query RAG strategy.

    Extends RAGConfig with multi-query specific settings.

    Attributes:
        num_query_variants: Number of query variants to generate (default: 3)
        rrf_k: RRF constant for ranking (default: 60)
        dedupe_by_content: Also dedupe by content similarity (default: False)
        parallel_retrieval: Run retrievals in parallel (default: True)
    """

    num_query_variants: int = 3
    rrf_k: int = 60  # RRF constant (commonly 60)
    dedupe_by_content: bool = False
    parallel_retrieval: bool = True


class MultiQueryRAGStrategy(RAGStrategy):
    """Multi-Query RAG strategy with query expansion and parallel retrieval.

    This strategy improves retrieval coverage by:
    1. Expanding the original query into multiple variants using an LLM
    2. Running retrieval for each variant (optionally in parallel)
    3. Deduplicating and ranking results using Reciprocal Rank Fusion
    4. Generating an answer from the combined, ranked context

    This approach helps find relevant documents that might use different
    terminology or phrasing than the original query.

    Example:
        ```python
        from ashmatics_tools.search import create_search_strategy
        from ashmatics_tools.search.strategies.multi_query_rag import MultiQueryConfig

        config = MultiQueryConfig(
            num_query_variants=4,
            top_k=10,
            rrf_k=60,
        )

        rag = create_search_strategy(
            "multi_query_rag",
            llm=llm,
            vector_store=vector_store,
            embedder=embedder,
            config=config,
        )

        result = await rag.query("What are ISO 42001 requirements?")
        print(f"Expanded queries: {result.metadata['expanded_queries']}")
        ```
    """

    def __init__(
        self,
        llm: "BaseLLMClient",
        vector_store: "VectorStore",
        embedder: "DocumentEmbedder",
        config: RAGConfig | MultiQueryConfig | None = None,
        **kwargs: Any,
    ):
        """Initialize MultiQueryRAGStrategy.

        Args:
            llm: LLM client for query expansion and answer generation
            vector_store: Vector store for document retrieval
            embedder: Embedder for query embedding
            config: RAG configuration (RAGConfig or MultiQueryConfig)
            **kwargs: Additional strategy-specific parameters
        """
        # Convert RAGConfig to MultiQueryConfig if needed
        if config is None:
            config = MultiQueryConfig()
        elif isinstance(config, RAGConfig) and not isinstance(config, MultiQueryConfig):
            # Preserve RAGConfig fields, add MultiQueryConfig defaults
            config = MultiQueryConfig(
                top_k=config.top_k,
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                include_sources=config.include_sources,
                min_score_threshold=config.min_score_threshold,
                system_prompt=config.system_prompt,
                max_context_tokens=config.max_context_tokens,
            )

        super().__init__(llm, vector_store, embedder, config)
        self.multi_config: MultiQueryConfig = config  # type: ignore

        logger.debug(
            f"Initialized MultiQueryRAGStrategy with "
            f"num_variants={self.multi_config.num_query_variants}, "
            f"rrf_k={self.multi_config.rrf_k}"
        )

    async def query(self, query: str, **kwargs: Any) -> RAGResult:
        """Execute multi-query RAG and return complete result.

        Args:
            query: Natural language query
            **kwargs: Additional parameters:
                - filters: Optional metadata filters for retrieval
                - override_system_prompt: Override the default system prompt
                - skip_expansion: If True, skip query expansion (use original only)

        Returns:
            RAGResult with answer, sources, metrics, and expanded_queries metadata

        Raises:
            RetrievalError: If document retrieval fails
            GenerationError: If answer generation fails
            NoSourcesFoundError: If no relevant sources found
        """
        start_time = time.perf_counter()
        filters = kwargs.get("filters")
        override_system_prompt = kwargs.get("override_system_prompt")
        skip_expansion = kwargs.get("skip_expansion", False)

        # Step 1: Expand query into variants
        expansion_start = time.perf_counter()
        if skip_expansion:
            expanded_queries = [query]
        else:
            try:
                expanded_queries = await self._expand_query(query)
            except Exception as e:
                logger.warning(f"Query expansion failed, using original: {e}")
                expanded_queries = [query]

        expansion_time = (time.perf_counter() - expansion_start) * 1000
        logger.debug(f"Query expansion took {expansion_time:.1f}ms, got {len(expanded_queries)} variants")

        # Step 2: Retrieve for each query variant
        retrieval_start = time.perf_counter()
        try:
            all_results = await self._retrieve_for_queries(
                expanded_queries, filters=filters
            )
        except Exception as e:
            logger.error(f"Multi-query retrieval failed: {e}")
            raise RetrievalError(f"Multi-query retrieval failed: {e}") from e

        retrieval_latency = (time.perf_counter() - retrieval_start) * 1000

        # Step 3: Deduplicate and rank results
        ranked_sources = self._dedupe_and_rank(all_results)

        if not ranked_sources:
            raise NoSourcesFoundError(
                f"No relevant sources found for query: {query[:100]}...",
                {"expanded_queries": expanded_queries},
            )

        # Limit to top_k after ranking
        top_sources = ranked_sources[: self.config.top_k]
        logger.debug(
            f"Retrieved {len(all_results)} total, "
            f"{len(ranked_sources)} unique, "
            f"keeping top {len(top_sources)}"
        )

        # Step 4: Build context and generate answer
        context = self._build_context(top_sources)

        generation_start = time.perf_counter()
        try:
            answer, tokens = await self._generate_answer(
                query=query,
                context=context,
                override_system_prompt=override_system_prompt,
            )
        except Exception as e:
            logger.error(f"Failed to generate answer: {e}")
            raise GenerationError(f"Answer generation failed: {e}") from e

        generation_latency = (time.perf_counter() - generation_start) * 1000
        total_latency = (time.perf_counter() - start_time) * 1000

        # Build metrics
        metrics = RAGMetrics(
            total_tokens=tokens.total_tokens,
            prompt_tokens=tokens.prompt_tokens,
            completion_tokens=tokens.completion_tokens,
            estimated_cost=tokens.estimated_cost,
            latency_ms=total_latency,
            num_sources=len(top_sources),
            retrieval_latency_ms=retrieval_latency,
            generation_latency_ms=generation_latency,
        )

        result_sources = top_sources if self.config.include_sources else []

        return RAGResult(
            answer=answer,
            sources=result_sources,
            query=query,
            metrics=metrics,
            metadata={
                "strategy": "multi_query_rag",
                "expanded_queries": expanded_queries,
                "num_variants": len(expanded_queries),
                "total_retrieved": len(all_results),
                "unique_sources": len(ranked_sources),
                "expansion_time_ms": expansion_time,
            },
        )

    async def stream_query(
        self, query: str, **kwargs: Any
    ) -> AsyncIterator[RAGStreamChunk]:
        """Stream multi-query RAG response.

        Query expansion and retrieval happen upfront, then answer generation
        is streamed. The final chunk includes sources and metrics.

        Args:
            query: Natural language query
            **kwargs: Additional parameters (same as query())

        Yields:
            RAGStreamChunk objects with text fragments
        """
        start_time = time.perf_counter()
        filters = kwargs.get("filters")
        override_system_prompt = kwargs.get("override_system_prompt")
        skip_expansion = kwargs.get("skip_expansion", False)

        # Step 1: Expand query
        expansion_start = time.perf_counter()
        if skip_expansion:
            expanded_queries = [query]
        else:
            try:
                expanded_queries = await self._expand_query(query)
            except Exception as e:
                logger.warning(f"Query expansion failed, using original: {e}")
                expanded_queries = [query]
        expansion_time = (time.perf_counter() - expansion_start) * 1000
        logger.debug("Query expansion completed in %.2f ms", expansion_time)

        # Step 2: Retrieve for each query variant
        retrieval_start = time.perf_counter()
        try:
            all_results = await self._retrieve_for_queries(
                expanded_queries, filters=filters
            )
        except Exception as e:
            logger.error(f"Multi-query retrieval failed: {e}")
            raise RetrievalError(f"Multi-query retrieval failed: {e}") from e

        retrieval_latency = (time.perf_counter() - retrieval_start) * 1000

        # Step 3: Deduplicate and rank
        ranked_sources = self._dedupe_and_rank(all_results)

        if not ranked_sources:
            raise NoSourcesFoundError(
                f"No relevant sources found for query: {query[:100]}...",
                {"expanded_queries": expanded_queries},
            )

        top_sources = ranked_sources[: self.config.top_k]

        # Step 4: Stream answer generation
        context = self._build_context(top_sources)
        generation_start = time.perf_counter()
        full_answer = ""

        try:
            messages = self._build_messages(query, context, override_system_prompt)

            from ...llm.base import LLMMessage

            llm_messages = [
                LLMMessage(role=m["role"], content=m["content"]) for m in messages
            ]

            async for chunk in self.llm.stream_complete_with_messages(
                messages=llm_messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            ):
                full_answer += chunk.text

                if chunk.is_final:
                    generation_latency = (time.perf_counter() - generation_start) * 1000
                    total_latency = (time.perf_counter() - start_time) * 1000

                    prompt_tokens = await self.llm.count_tokens(
                        messages[0]["content"] + messages[1]["content"]
                    )
                    completion_tokens = await self.llm.count_tokens(full_answer)

                    metrics = RAGMetrics(
                        total_tokens=prompt_tokens + completion_tokens,
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        estimated_cost=0.0,
                        latency_ms=total_latency,
                        num_sources=len(top_sources),
                        retrieval_latency_ms=retrieval_latency,
                        generation_latency_ms=generation_latency,
                    )

                    result_sources = top_sources if self.config.include_sources else []

                    yield RAGStreamChunk(
                        text=chunk.text,
                        is_final=True,
                        sources=result_sources,
                        metrics=metrics,
                    )
                else:
                    yield RAGStreamChunk(text=chunk.text, is_final=False)

        except Exception as e:
            logger.error(f"Streaming generation failed: {e}")
            raise GenerationError(f"Streaming generation failed: {e}") from e

    async def _expand_query(self, query: str) -> list[str]:
        """Expand a query into multiple variants using LLM.

        Args:
            query: Original user query

        Returns:
            List of query variants including the original
        """
        from ...llm.base import LLMMessage

        prompt = QUERY_EXPANSION_PROMPT.format(
            num_queries=self.multi_config.num_query_variants,
            query=query,
        )

        messages = [
            LLMMessage(role="user", content=prompt),
        ]

        response = await self.llm.complete_with_messages(
            messages=messages,
            temperature=0.7,  # Some creativity for variant generation
            max_tokens=500,
        )

        # Parse JSON response
        try:
            # Try to extract JSON array from response
            text = response.text.strip()

            # Handle markdown code blocks
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0].strip()
            elif "```" in text:
                text = text.split("```")[1].split("```")[0].strip()

            variants = json.loads(text)

            if not isinstance(variants, list):
                raise ValueError("Expected JSON array")

            # Always include original query first
            result = [query]
            for v in variants:
                if isinstance(v, str) and v.strip() and v.strip() != query:
                    result.append(v.strip())

            return result[: self.multi_config.num_query_variants + 1]

        except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Failed to parse query expansion response: {e}")
            # Fall back to just the original query
            return [query]

    async def _retrieve_for_queries(
        self,
        queries: list[str],
        filters: dict[str, Any] | None = None,
    ) -> list[tuple["SearchResult", int]]:
        """Retrieve documents for multiple queries.

        Args:
            queries: List of query variants
            filters: Optional metadata filters

        Returns:
            List of (SearchResult, query_index) tuples
        """
        async def retrieve_single(query: str, query_idx: int) -> list[tuple["SearchResult", int]]:
            """Retrieve for a single query."""
            try:
                embedding = await self.embedder.embed_query(query)
                results = await self.vector_store.similarity_search(
                    query_embedding=embedding,
                    top_k=self.config.top_k,
                    filters=filters,
                    min_score=self.config.min_score_threshold
                    if self.config.min_score_threshold > 0
                    else None,
                )
                return [(r, query_idx) for r in results]
            except Exception as e:
                logger.warning(f"Retrieval failed for query {query_idx}: {e}")
                return []

        if self.multi_config.parallel_retrieval:
            # Run all retrievals in parallel
            tasks = [
                retrieve_single(q, i) for i, q in enumerate(queries)
            ]
            results_nested = await asyncio.gather(*tasks, return_exceptions=True)

            all_results = []
            for result in results_nested:
                if isinstance(result, Exception):
                    logger.warning(f"Parallel retrieval error: {result}")
                else:
                    all_results.extend(result)
        else:
            # Sequential retrieval
            all_results = []
            for i, q in enumerate(queries):
                results = await retrieve_single(q, i)
                all_results.extend(results)

        return all_results

    def _dedupe_and_rank(
        self, results: list[tuple["SearchResult", int]]
    ) -> list["SearchResult"]:
        """Deduplicate and rank results using Reciprocal Rank Fusion.

        RRF score = sum(1 / (k + rank)) across all queries where doc appears

        Args:
            results: List of (SearchResult, query_index) tuples

        Returns:
            Deduplicated and ranked list of SearchResults
        """
        # Group by document_id
        doc_results: dict[str, list[tuple["SearchResult", int, int]]] = defaultdict(list)

        for result, query_idx in results:
            # Track position within this query's results
            rank = len([r for r in doc_results[result.document_id] if r[1] == query_idx])
            doc_results[result.document_id].append((result, query_idx, rank))

        # Calculate RRF scores
        rrf_scores: dict[str, float] = {}
        best_result: dict[str, "SearchResult"] = {}

        for doc_id, occurrences in doc_results.items():
            # RRF score across all occurrences
            rrf_score = sum(
                1.0 / (self.multi_config.rrf_k + rank)
                for _, _, rank in occurrences
            )
            rrf_scores[doc_id] = rrf_score

            # Keep the result with highest original score
            best = max(occurrences, key=lambda x: x[0].score)
            best_result[doc_id] = best[0]

        # Sort by RRF score descending
        ranked_doc_ids = sorted(
            rrf_scores.keys(),
            key=lambda x: rrf_scores[x],
            reverse=True,
        )

        # Build ranked list with updated scores
        ranked_results = []
        for i, doc_id in enumerate(ranked_doc_ids, start=1):
            result = best_result[doc_id]
            # Update rank to reflect RRF ranking
            result.rank = i
            ranked_results.append(result)

        return ranked_results

    def _build_context(self, sources: list["SearchResult"]) -> str:
        """Build context string from retrieved sources."""
        context_parts = []

        for i, source in enumerate(sources, start=1):
            header_parts = [f"[Source {i}]"]

            if source.source_uri:
                header_parts.append(f"URI: {source.source_uri}")
            if source.domain:
                header_parts.append(f"Domain: {source.domain}")
            if source.document_type:
                header_parts.append(f"Type: {source.document_type}")
            if source.control_refs:
                header_parts.append(f"Controls: {', '.join(source.control_refs)}")

            header = " | ".join(header_parts)
            content = source.content.strip()

            context_parts.append(f"{header}\n{content}")

        return "\n\n".join(context_parts)

    def _build_messages(
        self,
        query: str,
        context: str,
        override_system_prompt: str | None = None,
    ) -> list[dict[str, str]]:
        """Build messages for LLM completion."""
        system_template = (
            override_system_prompt
            or self.config.system_prompt
            or DEFAULT_RAG_SYSTEM_PROMPT
        )
        system_prompt = system_template.format(context=context)

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
        ]

    async def _generate_answer(
        self,
        query: str,
        context: str,
        override_system_prompt: str | None = None,
    ) -> tuple[str, "TokenUsage"]:
        """Generate answer using LLM."""
        from ...llm.base import LLMMessage

        messages = self._build_messages(query, context, override_system_prompt)
        llm_messages = [
            LLMMessage(role=m["role"], content=m["content"]) for m in messages
        ]

        response = await self.llm.complete_with_messages(
            messages=llm_messages,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        )

        return response.text, response.tokens
