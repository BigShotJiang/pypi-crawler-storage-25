# Copyright 2025 Asher Informatics PBC
"""Simple RAG strategy implementation.

This module provides a straightforward RAG (Retrieval-Augmented Generation)
strategy that:
1. Embeds the query
2. Retrieves relevant documents via similarity search
3. Builds context from retrieved documents
4. Generates an answer using an LLM

This is the baseline RAG implementation suitable for most use cases.
"""

import logging
import time
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

from ..base import RAGConfig, RAGMetrics, RAGResult, RAGStrategy, RAGStreamChunk
from ..exceptions import GenerationError, NoSourcesFoundError, RetrievalError
from ..prompts import DEFAULT_RAG_SYSTEM_PROMPT

if TYPE_CHECKING:
    from ...embedders.base import DocumentEmbedder
    from ...llm.base import BaseLLMClient, LLMMessage
    from ...vector_stores.base import SearchResult, VectorStore

logger = logging.getLogger(__name__)


class SimpleRAGStrategy(RAGStrategy):
    """Simple RAG strategy with retrieval + generation.

    This strategy follows the standard RAG pattern:
    1. Embed the user query
    2. Retrieve top-k similar documents from vector store
    3. Build context from retrieved documents
    4. Generate answer using LLM with context

    Supports both synchronous (query) and streaming (stream_query) modes.

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client, AzureOpenAIConfig
        from ashmatics_tools.embedders import create_embedder
        from ashmatics_tools.vector_stores import create_vector_store
        from ashmatics_tools.search import create_search_strategy, RAGConfig

        llm = create_llm_client("azure_openai", config)
        embedder = create_embedder("azure")
        vector_store = create_vector_store("cosmosdb", vs_config)

        rag = create_search_strategy(
            "simple_rag",
            llm=llm,
            vector_store=vector_store,
            embedder=embedder,
            config=RAGConfig(top_k=10)
        )

        # Non-streaming
        result = await rag.query("What are ISO 42001 requirements?")
        print(result.answer)

        # Streaming
        async for chunk in rag.stream_query("Explain risk management"):
            print(chunk.text, end="", flush=True)
        ```
    """

    def __init__(
        self,
        llm: "BaseLLMClient",
        vector_store: "VectorStore",
        embedder: "DocumentEmbedder",
        config: RAGConfig | None = None,
        **kwargs: Any,
    ):
        """Initialize SimpleRAGStrategy.

        Args:
            llm: LLM client for answer generation
            vector_store: Vector store for document retrieval
            embedder: Embedder for query embedding
            config: RAG configuration (uses defaults if None)
            **kwargs: Additional strategy-specific parameters (unused)
        """
        super().__init__(llm, vector_store, embedder, config)
        logger.debug(
            f"Initialized SimpleRAGStrategy with top_k={self.config.top_k}, "
            f"temperature={self.config.temperature}"
        )

    async def query(self, query: str, **kwargs: Any) -> RAGResult:
        """Execute RAG query and return complete result.

        Args:
            query: Natural language query
            **kwargs: Additional parameters:
                - filters: Optional metadata filters for retrieval
                - override_system_prompt: Override the default system prompt

        Returns:
            RAGResult with answer, sources, and metrics

        Raises:
            RetrievalError: If document retrieval fails
            GenerationError: If answer generation fails
            NoSourcesFoundError: If no relevant sources found
        """
        start_time = time.perf_counter()
        filters = kwargs.get("filters")
        override_system_prompt = kwargs.get("override_system_prompt")

        # Step 1: Embed the query
        retrieval_start = time.perf_counter()
        try:
            query_embedding = await self.embedder.embed_query(query)
        except Exception as e:
            logger.error(f"Failed to embed query: {e}")
            raise RetrievalError(f"Query embedding failed: {e}") from e

        # Step 2: Retrieve relevant documents
        try:
            sources = await self.vector_store.similarity_search(
                query_embedding=query_embedding,
                top_k=self.config.top_k,
                filters=filters,
                min_score=self.config.min_score_threshold
                if self.config.min_score_threshold > 0
                else None,
            )
        except Exception as e:
            logger.error(f"Failed to retrieve documents: {e}")
            raise RetrievalError(f"Document retrieval failed: {e}") from e

        retrieval_latency = (time.perf_counter() - retrieval_start) * 1000

        # Check if we found any sources
        if not sources:
            raise NoSourcesFoundError(
                f"No relevant sources found for query: {query[:100]}..."
            )

        logger.debug(f"Retrieved {len(sources)} sources in {retrieval_latency:.1f}ms")

        # Step 3: Build context from sources
        context = self._build_context(sources)

        # Step 4: Generate answer
        generation_start = time.perf_counter()
        try:
            answer, tokens = await self._generate_answer(
                query=query,
                context=context,
                override_system_prompt=override_system_prompt,
            )
        except Exception as e:
            logger.error(f"Failed to generate answer: {e}")
            raise GenerationError(f"Answer generation failed: {e}") from e

        generation_latency = (time.perf_counter() - generation_start) * 1000
        total_latency = (time.perf_counter() - start_time) * 1000

        # Build metrics
        metrics = RAGMetrics(
            total_tokens=tokens.total_tokens,
            prompt_tokens=tokens.prompt_tokens,
            completion_tokens=tokens.completion_tokens,
            estimated_cost=tokens.estimated_cost,
            latency_ms=total_latency,
            num_sources=len(sources),
            retrieval_latency_ms=retrieval_latency,
            generation_latency_ms=generation_latency,
        )

        # Return result (exclude sources if configured)
        result_sources = sources if self.config.include_sources else []

        return RAGResult(
            answer=answer,
            sources=result_sources,
            query=query,
            metrics=metrics,
            metadata={
                "strategy": "simple_rag",
                "top_k": self.config.top_k,
                "temperature": self.config.temperature,
            },
        )

    async def stream_query(
        self, query: str, **kwargs: Any
    ) -> AsyncIterator[RAGStreamChunk]:
        """Stream RAG response, yielding chunks as they arrive.

        Retrieval happens upfront, then answer generation is streamed.
        The final chunk includes sources and metrics.

        Args:
            query: Natural language query
            **kwargs: Additional parameters (same as query())

        Yields:
            RAGStreamChunk objects with text fragments

        Raises:
            RetrievalError: If document retrieval fails
            GenerationError: If answer generation fails
            NoSourcesFoundError: If no relevant sources found
        """
        start_time = time.perf_counter()
        filters = kwargs.get("filters")
        override_system_prompt = kwargs.get("override_system_prompt")

        # Step 1: Embed the query
        retrieval_start = time.perf_counter()
        try:
            query_embedding = await self.embedder.embed_query(query)
        except Exception as e:
            logger.error(f"Failed to embed query: {e}")
            raise RetrievalError(f"Query embedding failed: {e}") from e

        # Step 2: Retrieve relevant documents
        try:
            sources = await self.vector_store.similarity_search(
                query_embedding=query_embedding,
                top_k=self.config.top_k,
                filters=filters,
                min_score=self.config.min_score_threshold
                if self.config.min_score_threshold > 0
                else None,
            )
        except Exception as e:
            logger.error(f"Failed to retrieve documents: {e}")
            raise RetrievalError(f"Document retrieval failed: {e}") from e

        retrieval_latency = (time.perf_counter() - retrieval_start) * 1000

        # Check if we found any sources
        if not sources:
            raise NoSourcesFoundError(
                f"No relevant sources found for query: {query[:100]}..."
            )

        logger.debug(f"Retrieved {len(sources)} sources in {retrieval_latency:.1f}ms")

        # Step 3: Build context from sources
        context = self._build_context(sources)

        # Step 4: Stream answer generation
        generation_start = time.perf_counter()
        full_answer = ""
        prompt_tokens = 0
        completion_tokens = 0

        try:
            messages = self._build_messages(query, context, override_system_prompt)

            # Import here to avoid circular imports
            from ...llm.base import LLMMessage

            llm_messages = [
                LLMMessage(role=m["role"], content=m["content"]) for m in messages
            ]

            async for chunk in self.llm.stream_complete_with_messages(
                messages=llm_messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            ):
                full_answer += chunk.text

                if chunk.is_final:
                    # Final chunk - calculate metrics and include sources
                    generation_latency = (
                        time.perf_counter() - generation_start
                    ) * 1000
                    total_latency = (time.perf_counter() - start_time) * 1000

                    # Estimate tokens (streaming may not provide exact counts)
                    prompt_tokens = await self.llm.count_tokens(
                        messages[0]["content"] + messages[1]["content"]
                    )
                    completion_tokens = await self.llm.count_tokens(full_answer)

                    metrics = RAGMetrics(
                        total_tokens=prompt_tokens + completion_tokens,
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        estimated_cost=0.0,  # Hard to estimate for streaming
                        latency_ms=total_latency,
                        num_sources=len(sources),
                        retrieval_latency_ms=retrieval_latency,
                        generation_latency_ms=generation_latency,
                    )

                    result_sources = sources if self.config.include_sources else []

                    yield RAGStreamChunk(
                        text=chunk.text,
                        is_final=True,
                        sources=result_sources,
                        metrics=metrics,
                    )
                else:
                    yield RAGStreamChunk(text=chunk.text, is_final=False)

        except Exception as e:
            logger.error(f"Failed to generate streaming answer: {e}")
            raise GenerationError(f"Streaming answer generation failed: {e}") from e

    def _build_context(self, sources: list["SearchResult"]) -> str:
        """Build context string from retrieved sources.

        Args:
            sources: List of retrieved search results

        Returns:
            Formatted context string with numbered sources
        """
        context_parts = []

        for i, source in enumerate(sources, start=1):
            # Build source header with metadata
            header_parts = [f"[Source {i}]"]

            if source.source_uri:
                header_parts.append(f"URI: {source.source_uri}")
            if source.domain:
                header_parts.append(f"Domain: {source.domain}")
            if source.document_type:
                header_parts.append(f"Type: {source.document_type}")
            if source.control_refs:
                header_parts.append(f"Controls: {', '.join(source.control_refs)}")

            header = " | ".join(header_parts)
            content = source.content.strip()

            context_parts.append(f"{header}\n{content}")

        return "\n\n".join(context_parts)

    def _build_messages(
        self,
        query: str,
        context: str,
        override_system_prompt: str | None = None,
    ) -> list[dict[str, str]]:
        """Build messages for LLM completion.

        Args:
            query: User query
            context: Formatted context from sources
            override_system_prompt: Optional custom system prompt

        Returns:
            List of message dictionaries for LLM
        """
        # Use custom prompt if provided, otherwise use default
        system_template = (
            override_system_prompt or self.config.system_prompt or DEFAULT_RAG_SYSTEM_PROMPT
        )

        # Format the system prompt with context
        system_prompt = system_template.format(context=context)

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query},
        ]

    async def _generate_answer(
        self,
        query: str,
        context: str,
        override_system_prompt: str | None = None,
    ) -> tuple[str, "TokenUsage"]:
        """Generate answer using LLM.

        Args:
            query: User query
            context: Formatted context from sources
            override_system_prompt: Optional custom system prompt

        Returns:
            Tuple of (answer text, token usage)
        """
        from ...llm.base import LLMMessage, TokenUsage

        messages = self._build_messages(query, context, override_system_prompt)
        llm_messages = [
            LLMMessage(role=m["role"], content=m["content"]) for m in messages
        ]

        response = await self.llm.complete_with_messages(
            messages=llm_messages,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        )

        return response.text, response.tokens
