"""Abstract base classes for storage clients.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class StorageProvider(str, Enum):
    """Supported storage providers."""

    ADLS = "adls"  # Azure Data Lake Storage Gen2
    MINIO = "minio"  # MinIO (S3-compatible)
    S3 = "s3"  # AWS S3 (reserved for future)


class AuthType(str, Enum):
    """Authentication types for storage providers."""

    CONNECTION_STRING = "connection_string"  # Azure connection string
    DEFAULT_CREDENTIAL = "default_credential"  # Azure DefaultAzureCredential
    ACCESS_KEY = "access_key"  # MinIO/S3 access key + secret


@dataclass
class StorageConfig:
    """
    Configuration for storage clients.

    This configuration is used across all storage types to maintain consistency.
    Provider-specific settings can be passed via `extra_config`.
    """

    # Provider
    provider: StorageProvider = StorageProvider.ADLS

    # Connection settings
    connection_string: str | None = None  # Azure connection string (for dev)
    account_url: str | None = None  # Azure account URL (for DefaultAzureCredential)
    endpoint: str | None = None  # MinIO/S3 endpoint URL

    # Container/bucket
    container_name: str | None = None  # Azure container or MinIO bucket

    # Authentication
    auth_type: AuthType = AuthType.DEFAULT_CREDENTIAL
    access_key: str | None = None  # MinIO/S3 access key
    secret_key: str | None = None  # MinIO/S3 secret key
    use_ssl: bool = True  # Use SSL/TLS for connections
    verify_ssl: bool = True  # Verify SSL certificates

    # Performance settings
    chunk_size: int = 4 * 1024 * 1024  # 4MB chunks for streaming
    timeout: float = 30.0  # Operation timeout in seconds
    max_retries: int = 3  # Maximum retry attempts
    retry_delay: float = 1.0  # Delay between retries in seconds

    # Provider-specific settings
    extra_config: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration."""
        if self.chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        if self.timeout <= 0:
            raise ValueError("timeout must be positive")
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if self.retry_delay < 0:
            raise ValueError("retry_delay must be non-negative")

        # Provider-specific validation
        if self.provider == StorageProvider.ADLS:
            if self.auth_type == AuthType.CONNECTION_STRING and not self.connection_string:
                raise ValueError("connection_string required for CONNECTION_STRING auth")
            if self.auth_type == AuthType.DEFAULT_CREDENTIAL and not self.account_url:
                raise ValueError("account_url required for DEFAULT_CREDENTIAL auth")
        elif self.provider in (StorageProvider.MINIO, StorageProvider.S3):
            if not self.endpoint:
                raise ValueError(f"endpoint required for {self.provider.value}")
            if self.auth_type == AuthType.ACCESS_KEY:
                if not self.access_key or not self.secret_key:
                    raise ValueError("access_key and secret_key required for ACCESS_KEY auth")


@dataclass
class StorageObject:
    """Represents a storage object (file/blob) with metadata."""

    # Object identification
    path: str  # Full path/key to the object
    name: str  # Object name (filename)

    # Object metadata
    size: int  # Size in bytes
    modified_time: datetime | None = None  # Last modified timestamp
    created_time: datetime | None = None  # Creation timestamp
    etag: str | None = None  # ETag for versioning/caching
    content_type: str | None = None  # MIME type

    # Additional metadata
    metadata: dict[str, Any] = field(default_factory=dict)
    is_directory: bool = False  # True if this represents a directory/prefix

    def to_dict(self) -> dict[str, Any]:
        """Convert object to dictionary."""
        return {
            "path": self.path,
            "name": self.name,
            "size": self.size,
            "modified_time": self.modified_time.isoformat() if self.modified_time else None,
            "created_time": self.created_time.isoformat() if self.created_time else None,
            "etag": self.etag,
            "content_type": self.content_type,
            "metadata": self.metadata,
            "is_directory": self.is_directory,
        }


class StorageClient(ABC):
    """
    Abstract base class for storage clients.

    All storage implementations must inherit from this class and implement
    its abstract methods. The API is async-only for consistency with modern
    Python best practices.
    """

    def __init__(self, config: StorageConfig | None = None):
        """
        Initialize storage client with configuration.

        Args:
            config: Storage configuration. If None, uses default config.
        """
        self.config = config or StorageConfig()

    @abstractmethod
    async def read_object(self, path: str) -> bytes:
        """
        Read entire object as bytes.

        Args:
            path: Path to the object (e.g., "folder/file.pdf")

        Returns:
            Object content as bytes

        Raises:
            FileNotFoundError: If object does not exist
            Exception: If read operation fails
        """

    @abstractmethod
    async def read_object_text(self, path: str, encoding: str = "utf-8") -> str:
        """
        Read entire object as text.

        Args:
            path: Path to the object
            encoding: Text encoding (default: utf-8)

        Returns:
            Object content as string

        Raises:
            FileNotFoundError: If object does not exist
            UnicodeDecodeError: If content cannot be decoded
            Exception: If read operation fails
        """

    @abstractmethod
    async def read_object_stream(self, path: str) -> AsyncIterator[bytes]:
        """
        Read object as a stream of bytes chunks.

        Useful for large files to avoid loading entire content into memory.

        Args:
            path: Path to the object

        Yields:
            Chunks of bytes

        Raises:
            FileNotFoundError: If object does not exist
            Exception: If streaming fails
        """

    @abstractmethod
    async def write_object(
        self,
        path: str,
        data: bytes | str,
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> bool:
        """
        Write object from bytes or string.

        Args:
            path: Destination path
            data: Content to write (bytes or string)
            content_type: Optional MIME type
            metadata: Optional metadata key-value pairs

        Returns:
            True if successful

        Raises:
            Exception: If write operation fails
        """

    @abstractmethod
    async def write_object_stream(
        self,
        path: str,
        stream: AsyncIterator[bytes],
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> bool:
        """
        Write object from a stream of bytes.

        Useful for large files or when data is generated/processed in chunks.

        Args:
            path: Destination path
            stream: Async iterator yielding bytes chunks
            content_type: Optional MIME type
            metadata: Optional metadata key-value pairs

        Returns:
            True if successful

        Raises:
            Exception: If streaming write fails
        """

    @abstractmethod
    async def list_objects(
        self,
        prefix: str = "",
        pattern: str = "*",
        recursive: bool = True,
        include_metadata: bool = False,
    ) -> list[StorageObject]:
        """
        List objects matching prefix and pattern.

        Args:
            prefix: Path prefix to filter objects (e.g., "fda-510k/")
            pattern: Glob pattern to match (e.g., "*.pdf", "**/K*.pdf")
            recursive: If True, search recursively; if False, only immediate children
            include_metadata: If True, fetch full metadata for each object

        Returns:
            List of StorageObject instances

        Raises:
            Exception: If listing fails
        """

    @abstractmethod
    async def exists(self, path: str) -> bool:
        """
        Check if object exists at path.

        Args:
            path: Path to check

        Returns:
            True if object exists, False otherwise

        Raises:
            Exception: If existence check fails
        """

    @abstractmethod
    async def get_metadata(self, path: str) -> StorageObject | None:
        """
        Get object metadata.

        Args:
            path: Path to the object

        Returns:
            StorageObject with metadata, or None if not found

        Raises:
            Exception: If metadata retrieval fails
        """

    @abstractmethod
    async def delete_object(self, path: str) -> bool:
        """
        Delete object at path.

        Args:
            path: Path to the object

        Returns:
            True if deleted successfully, False if object did not exist

        Raises:
            Exception: If deletion fails
        """

    @abstractmethod
    async def copy_object(self, src_path: str, dest_path: str) -> bool:
        """
        Copy object from source to destination.

        Args:
            src_path: Source path
            dest_path: Destination path

        Returns:
            True if successful

        Raises:
            FileNotFoundError: If source does not exist
            Exception: If copy operation fails
        """

    @abstractmethod
    async def health_check(self) -> bool:
        """
        Check if storage backend is operational.

        Returns:
            True if healthy and accessible

        Raises:
            Exception: If health check fails critically
        """

    @abstractmethod
    async def create_container(self, container_name: str) -> bool:
        """
        Create a new container/bucket.

        This is essential for multi-tenant architectures where containers
        are dynamically created per client/organization.

        Args:
            container_name: Name of the container to create

        Returns:
            True if created successfully, False if already exists

        Raises:
            ValueError: If container name is invalid
            Exception: If creation fails
        """

    @abstractmethod
    async def delete_container(self, container_name: str, force: bool = False) -> bool:
        """
        Delete a container/bucket.

        Args:
            container_name: Name of the container to delete
            force: If True, delete even if container is not empty.
                   If False, only delete if empty.

        Returns:
            True if deleted successfully, False if container did not exist

        Raises:
            ValueError: If trying to delete non-empty container without force=True
            Exception: If deletion fails
        """

    @abstractmethod
    async def container_exists(self, container_name: str) -> bool:
        """
        Check if a container/bucket exists.

        Args:
            container_name: Name of the container to check

        Returns:
            True if container exists, False otherwise

        Raises:
            Exception: If check fails
        """

    @abstractmethod
    async def list_containers(self) -> list[str]:
        """
        List all containers/buckets in the storage account.

        Returns:
            List of container names

        Raises:
            Exception: If listing fails
        """

    async def list_directories(self, prefix: str = "") -> list[str]:
        """
        List directories/prefixes (optional, may not be supported by all providers).

        Args:
            prefix: Path prefix

        Returns:
            List of directory paths

        Raises:
            NotImplementedError: If provider does not support directory listing
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support directory listing"
        )

    async def create_directory(self, path: str) -> bool:
        """
        Create a directory (optional, may not be needed for flat namespaces).

        Args:
            path: Directory path

        Returns:
            True if successful

        Raises:
            NotImplementedError: If provider does not support directory creation
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support directory creation"
        )

    def get_provider(self) -> StorageProvider:
        """
        Get the storage provider.

        Returns:
            StorageProvider enum value
        """
        return self.config.provider

    def __repr__(self) -> str:
        """String representation of storage client."""
        return (
            f"{self.__class__.__name__}("
            f"provider={self.config.provider}, "
            f"container={self.config.container_name})"
        )
