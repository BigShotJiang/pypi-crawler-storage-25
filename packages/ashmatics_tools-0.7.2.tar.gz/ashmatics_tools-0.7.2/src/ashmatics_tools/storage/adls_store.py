"""Azure Data Lake Storage Gen2 implementation.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import fnmatch
import logging
from collections.abc import AsyncIterator
from datetime import UTC

from azure.core.exceptions import ResourceNotFoundError
from azure.identity.aio import DefaultAzureCredential
from azure.storage.filedatalake.aio import DataLakeServiceClient

from .base import AuthType, StorageClient, StorageConfig, StorageObject

logger = logging.getLogger(__name__)


class ADLSStorageClient(StorageClient):
    """
    Azure Data Lake Storage Gen2 client.

    Supports both connection string (development) and DefaultAzureCredential
    (production/staging) authentication.
    """

    def __init__(self, config: StorageConfig | None = None):
        """
        Initialize ADLS storage client.

        Args:
            config: Storage configuration

        Raises:
            ValueError: If configuration is invalid
        """
        super().__init__(config)

        if not self.config.container_name:
            raise ValueError("container_name is required for ADLS storage")

        # Initialize client based on auth type
        self._service_client: DataLakeServiceClient | None = None
        self._credential: DefaultAzureCredential | None = None
        self._initialized = False

        logger.info(
            f"ADLSStorageClient initialized: container={self.config.container_name}, "
            f"auth_type={self.config.auth_type}"
        )

    async def _ensure_initialized(self):
        """Ensure service client is initialized (lazy initialization)."""
        if self._initialized:
            return

        if self.config.auth_type == AuthType.CONNECTION_STRING:
            if not self.config.connection_string:
                raise ValueError("connection_string required for CONNECTION_STRING auth")

            logger.info("Using Azure connection string authentication")
            self._service_client = DataLakeServiceClient.from_connection_string(
                self.config.connection_string
            )

        elif self.config.auth_type == AuthType.DEFAULT_CREDENTIAL:
            if not self.config.account_url:
                raise ValueError("account_url required for DEFAULT_CREDENTIAL auth")

            logger.info("Using Azure DefaultAzureCredential authentication")
            self._credential = DefaultAzureCredential()
            self._service_client = DataLakeServiceClient(
                account_url=self.config.account_url, credential=self._credential
            )

        else:
            raise ValueError(f"Unsupported auth type for ADLS: {self.config.auth_type}")

        self._initialized = True

    def _get_file_system_client(self):
        """Get file system (container) client."""
        if not self._service_client:
            raise RuntimeError("Service client not initialized")
        return self._service_client.get_file_system_client(self.config.container_name)

    def _get_file_client(self, path: str):
        """Get file client for a specific path."""
        file_system_client = self._get_file_system_client()
        return file_system_client.get_file_client(path)

    async def read_object(self, path: str) -> bytes:
        """
        Read entire object as bytes.

        Args:
            path: Path to the object

        Returns:
            Object content as bytes

        Raises:
            FileNotFoundError: If object does not exist
        """
        await self._ensure_initialized()

        try:
            file_client = self._get_file_client(path)
            download = await file_client.download_file()
            content = await download.readall()

            logger.debug(f"Read {len(content)} bytes from {path}")
            return content

        except ResourceNotFoundError as e:
            raise FileNotFoundError(f"Object not found: {path}") from e
        except Exception as e:
            logger.error(f"Failed to read object {path}: {e}", exc_info=True)
            raise

    async def read_object_text(self, path: str, encoding: str = "utf-8") -> str:
        """
        Read entire object as text.

        Args:
            path: Path to the object
            encoding: Text encoding (default: utf-8)

        Returns:
            Object content as string

        Raises:
            FileNotFoundError: If object does not exist
            UnicodeDecodeError: If content cannot be decoded
        """
        content_bytes = await self.read_object(path)
        return content_bytes.decode(encoding)

    async def read_object_stream(self, path: str) -> AsyncIterator[bytes]:
        """
        Read object as a stream of bytes chunks.

        Args:
            path: Path to the object

        Yields:
            Chunks of bytes

        Raises:
            FileNotFoundError: If object does not exist
        """
        await self._ensure_initialized()

        try:
            file_client = self._get_file_client(path)
            download = await file_client.download_file()

            # Stream in chunks
            async for chunk in download.chunks():
                yield chunk

            logger.debug(f"Streamed object {path}")

        except ResourceNotFoundError as e:
            raise FileNotFoundError(f"Object not found: {path}") from e
        except Exception as e:
            logger.error(f"Failed to stream object {path}: {e}", exc_info=True)
            raise

    async def write_object(
        self,
        path: str,
        data: bytes | str,
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> bool:
        """
        Write object from bytes or string.

        Args:
            path: Destination path
            data: Content to write (bytes or string)
            content_type: Optional MIME type
            metadata: Optional metadata key-value pairs

        Returns:
            True if successful
        """
        await self._ensure_initialized()

        try:
            # Convert string to bytes if needed
            if isinstance(data, str):
                data = data.encode("utf-8")

            file_client = self._get_file_client(path)

            # Create or overwrite file
            await file_client.create_file()

            # Upload data
            await file_client.upload_data(
                data, overwrite=True, metadata=metadata or {}
            )

            # Set content type if provided
            if content_type:
                properties = await file_client.get_file_properties()
                properties.content_settings.content_type = content_type
                await file_client.set_http_headers(properties.content_settings)

            logger.debug(f"Wrote {len(data)} bytes to {path}")
            return True

        except Exception as e:
            logger.error(f"Failed to write object {path}: {e}", exc_info=True)
            raise

    async def write_object_stream(
        self,
        path: str,
        stream: AsyncIterator[bytes],
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> bool:
        """
        Write object from a stream of bytes.

        Args:
            path: Destination path
            stream: Async iterator yielding bytes chunks
            content_type: Optional MIME type
            metadata: Optional metadata key-value pairs

        Returns:
            True if successful
        """
        await self._ensure_initialized()

        try:
            file_client = self._get_file_client(path)

            # Create file
            await file_client.create_file()

            # Set metadata if provided
            if metadata:
                await file_client.set_metadata(metadata)

            # Stream upload
            offset = 0
            async for chunk in stream:
                if chunk:
                    await file_client.append_data(chunk, offset=offset, length=len(chunk))
                    offset += len(chunk)

            # Flush to finalize upload
            await file_client.flush_data(offset)

            # Set content type if provided
            if content_type:
                properties = await file_client.get_file_properties()
                properties.content_settings.content_type = content_type
                await file_client.set_http_headers(properties.content_settings)

            logger.debug(f"Streamed {offset} bytes to {path}")
            return True

        except Exception as e:
            logger.error(f"Failed to stream write object {path}: {e}", exc_info=True)
            raise

    async def list_objects(
        self,
        prefix: str = "",
        pattern: str = "*",
        recursive: bool = True,
        include_metadata: bool = False,
    ) -> list[StorageObject]:
        """
        List objects matching prefix and pattern.

        Args:
            prefix: Path prefix to filter objects
            pattern: Glob pattern to match
            recursive: If True, search recursively
            include_metadata: If True, fetch full metadata (slower)

        Returns:
            List of StorageObject instances
        """
        await self._ensure_initialized()

        try:
            file_system_client = self._get_file_system_client()

            objects: list[StorageObject] = []

            # List paths with prefix
            async for path_properties in file_system_client.get_paths(
                path=prefix if prefix else None, recursive=recursive
            ):
                # Skip directories unless we want them
                if path_properties.is_directory:
                    continue

                path_name = path_properties.name

                # Apply glob pattern matching
                if not fnmatch.fnmatch(path_name, pattern):
                    # Check if pattern has path separators (e.g., "**/*.pdf")
                    if "/" in pattern or "*" in pattern:
                        # Extract just the filename for matching
                        filename = path_name.split("/")[-1]
                        if not fnmatch.fnmatch(filename, pattern.split("/")[-1]):
                            continue
                    else:
                        continue

                # Create StorageObject
                storage_obj = StorageObject(
                    path=path_name,
                    name=path_name.split("/")[-1],
                    size=path_properties.content_length or 0,
                    modified_time=(
                        path_properties.last_modified.astimezone(UTC)
                        if path_properties.last_modified
                        else None
                    ),
                    etag=path_properties.etag,
                    is_directory=path_properties.is_directory,
                )

                # Fetch full metadata if requested
                if include_metadata:
                    file_client = self._get_file_client(path_name)
                    properties = await file_client.get_file_properties()
                    storage_obj.content_type = properties.content_settings.content_type
                    storage_obj.metadata = properties.metadata or {}
                    storage_obj.created_time = (
                        properties.creation_time.astimezone(UTC)
                        if properties.creation_time
                        else None
                    )

                objects.append(storage_obj)

            logger.debug(f"Listed {len(objects)} objects with prefix='{prefix}', pattern='{pattern}'")
            return objects

        except Exception as e:
            logger.error(f"Failed to list objects: {e}", exc_info=True)
            raise

    async def exists(self, path: str) -> bool:
        """
        Check if object exists at path.

        Args:
            path: Path to check

        Returns:
            True if object exists, False otherwise
        """
        await self._ensure_initialized()

        try:
            file_client = self._get_file_client(path)
            await file_client.get_file_properties()
            return True
        except ResourceNotFoundError:
            return False
        except Exception as e:
            logger.error(f"Failed to check existence of {path}: {e}", exc_info=True)
            raise

    async def get_metadata(self, path: str) -> StorageObject | None:
        """
        Get object metadata.

        Args:
            path: Path to the object

        Returns:
            StorageObject with metadata, or None if not found
        """
        await self._ensure_initialized()

        try:
            file_client = self._get_file_client(path)
            properties = await file_client.get_file_properties()

            return StorageObject(
                path=path,
                name=path.split("/")[-1],
                size=properties.size,
                modified_time=(
                    properties.last_modified.astimezone(UTC)
                    if properties.last_modified
                    else None
                ),
                created_time=(
                    properties.creation_time.astimezone(UTC)
                    if properties.creation_time
                    else None
                ),
                etag=properties.etag,
                content_type=properties.content_settings.content_type,
                metadata=properties.metadata or {},
            )

        except ResourceNotFoundError:
            return None
        except Exception as e:
            logger.error(f"Failed to get metadata for {path}: {e}", exc_info=True)
            raise

    async def delete_object(self, path: str) -> bool:
        """
        Delete object at path.

        Args:
            path: Path to the object

        Returns:
            True if deleted successfully, False if object did not exist
        """
        await self._ensure_initialized()

        try:
            file_client = self._get_file_client(path)
            await file_client.delete_file()
            logger.debug(f"Deleted object {path}")
            return True

        except ResourceNotFoundError:
            logger.debug(f"Object not found for deletion: {path}")
            return False
        except Exception as e:
            logger.error(f"Failed to delete object {path}: {e}", exc_info=True)
            raise

    async def copy_object(self, src_path: str, dest_path: str) -> bool:
        """
        Copy object from source to destination.

        Args:
            src_path: Source path
            dest_path: Destination path

        Returns:
            True if successful

        Raises:
            FileNotFoundError: If source does not exist
        """
        await self._ensure_initialized()

        try:
            # Read source
            content = await self.read_object(src_path)

            # Get source metadata
            src_metadata = await self.get_metadata(src_path)

            # Write to destination
            await self.write_object(
                dest_path,
                content,
                content_type=src_metadata.content_type if src_metadata else None,
                metadata=src_metadata.metadata if src_metadata else None,
            )

            logger.debug(f"Copied object from {src_path} to {dest_path}")
            return True

        except FileNotFoundError:
            raise
        except Exception as e:
            logger.error(f"Failed to copy object from {src_path} to {dest_path}: {e}", exc_info=True)
            raise

    async def health_check(self) -> bool:
        """
        Check if storage backend is operational.

        Returns:
            True if healthy and accessible
        """
        await self._ensure_initialized()

        try:
            file_system_client = self._get_file_system_client()
            # Simple check: verify container exists
            await file_system_client.get_file_system_properties()
            logger.debug(f"Health check passed for container {self.config.container_name}")
            return True

        except Exception as e:
            logger.error(f"Health check failed: {e}", exc_info=True)
            return False

    async def create_container(self, container_name: str) -> bool:
        """
        Create a new container (file system) in ADLS Gen2.

        Args:
            container_name: Name of the container to create

        Returns:
            True if created successfully, False if already exists
        """
        await self._ensure_initialized()

        if not container_name:
            raise ValueError("Container name cannot be empty")

        try:
            file_system_client = self._service_client.get_file_system_client(container_name)
            await file_system_client.create_file_system()
            logger.info(f"Container created: {container_name}")
            return True

        except Exception as e:
            # Check if container already exists
            if "ContainerAlreadyExists" in str(e) or "The specified container already exists" in str(e):
                logger.warning(f"Container already exists: {container_name}")
                return False
            logger.error(f"Failed to create container {container_name}: {e}", exc_info=True)
            raise

    async def delete_container(self, container_name: str, force: bool = False) -> bool:
        """
        Delete a container (file system) in ADLS Gen2.

        Args:
            container_name: Name of the container to delete
            force: If True, delete even if container is not empty.
                   If False, only delete if empty.

        Returns:
            True if deleted successfully, False if container did not exist
        """
        await self._ensure_initialized()

        if not container_name:
            raise ValueError("Container name cannot be empty")

        try:
            file_system_client = self._service_client.get_file_system_client(container_name)

            # If not force, check if container is empty
            if not force:
                # List files to check if empty
                paths = file_system_client.get_paths(max_results=1)
                has_files = False
                async for _ in paths:
                    has_files = True
                    break

                if has_files:
                    raise ValueError(
                        f"Container '{container_name}' is not empty. "
                        "Use force=True to delete non-empty container."
                    )

            await file_system_client.delete_file_system()
            logger.info(f"Container deleted: {container_name}")
            return True

        except Exception as e:
            # Check if container doesn't exist
            if "ContainerNotFound" in str(e) or "The specified container does not exist" in str(e):
                logger.warning(f"Container does not exist: {container_name}")
                return False
            # Re-raise ValueError from empty check
            if isinstance(e, ValueError):
                raise
            logger.error(f"Failed to delete container {container_name}: {e}", exc_info=True)
            raise

    async def container_exists(self, container_name: str) -> bool:
        """
        Check if a container (file system) exists in ADLS Gen2.

        Args:
            container_name: Name of the container to check

        Returns:
            True if container exists, False otherwise
        """
        await self._ensure_initialized()

        if not container_name:
            raise ValueError("Container name cannot be empty")

        try:
            file_system_client = self._service_client.get_file_system_client(container_name)
            await file_system_client.get_file_system_properties()
            return True

        except Exception as e:
            if "ContainerNotFound" in str(e) or "The specified container does not exist" in str(e):
                return False
            logger.error(f"Failed to check container existence {container_name}: {e}", exc_info=True)
            raise

    async def list_containers(self) -> list[str]:
        """
        List all containers (file systems) in the ADLS Gen2 account.

        Returns:
            List of container names
        """
        await self._ensure_initialized()

        try:
            containers = []
            async for file_system in self._service_client.list_file_systems():
                containers.append(file_system.name)

            logger.debug(f"Listed {len(containers)} containers")
            return containers

        except Exception as e:
            logger.error(f"Failed to list containers: {e}", exc_info=True)
            raise

    async def close(self):
        """Close connections and cleanup resources."""
        if self._service_client:
            await self._service_client.close()
        if self._credential:
            await self._credential.close()

        self._service_client = None
        self._credential = None
        self._initialized = False

        logger.debug("ADLS storage client closed")

    async def __aenter__(self):
        """Async context manager entry."""
        await self._ensure_initialized()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
