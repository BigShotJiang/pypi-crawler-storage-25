"""MinIO storage implementation (S3-compatible).

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import asyncio
import fnmatch
import io
import logging
from collections.abc import AsyncIterator
from datetime import UTC

from minio import Minio
from minio.error import S3Error

from .base import AuthType, StorageClient, StorageConfig, StorageObject

logger = logging.getLogger(__name__)


class MinIOStorageClient(StorageClient):
    """
    MinIO storage client (S3-compatible).

    Uses the MinIO Python SDK which is synchronous, with async wrappers
    for compatibility with the StorageClient interface.
    """

    def __init__(self, config: StorageConfig | None = None):
        """
        Initialize MinIO storage client.

        Args:
            config: Storage configuration

        Raises:
            ValueError: If configuration is invalid
        """
        super().__init__(config)

        if not self.config.endpoint:
            raise ValueError("endpoint is required for MinIO storage")

        if not self.config.container_name:
            raise ValueError("container_name (bucket) is required for MinIO storage")

        if self.config.auth_type != AuthType.ACCESS_KEY:
            raise ValueError("MinIO only supports ACCESS_KEY auth type")

        if not self.config.access_key or not self.config.secret_key:
            raise ValueError("access_key and secret_key are required for MinIO")

        # Initialize MinIO client
        self._client = Minio(
            self.config.endpoint,
            access_key=self.config.access_key,
            secret_key=self.config.secret_key,
            secure=self.config.use_ssl,
        )

        logger.info(
            f"MinIOStorageClient initialized: endpoint={self.config.endpoint}, "
            f"bucket={self.config.container_name}, ssl={self.config.use_ssl}"
        )

    async def _ensure_bucket_exists(self):
        """Ensure bucket exists (create if needed)."""
        bucket_name = self.config.container_name

        def _check_and_create():
            if not self._client.bucket_exists(bucket_name):
                logger.info(f"Creating bucket: {bucket_name}")
                self._client.make_bucket(bucket_name)
            return True

        return await asyncio.to_thread(_check_and_create)

    async def read_object(self, path: str) -> bytes:
        """
        Read entire object as bytes.

        Args:
            path: Path to the object

        Returns:
            Object content as bytes

        Raises:
            FileNotFoundError: If object does not exist
        """
        try:

            def _read():
                response = self._client.get_object(self.config.container_name, path)
                try:
                    return response.read()
                finally:
                    response.close()
                    response.release_conn()

            content = await asyncio.to_thread(_read)
            logger.debug(f"Read {len(content)} bytes from {path}")
            return content

        except S3Error as e:
            if e.code == "NoSuchKey":
                raise FileNotFoundError(f"Object not found: {path}") from e
            logger.error(f"Failed to read object {path}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Failed to read object {path}: {e}", exc_info=True)
            raise

    async def read_object_text(self, path: str, encoding: str = "utf-8") -> str:
        """
        Read entire object as text.

        Args:
            path: Path to the object
            encoding: Text encoding (default: utf-8)

        Returns:
            Object content as string

        Raises:
            FileNotFoundError: If object does not exist
            UnicodeDecodeError: If content cannot be decoded
        """
        content_bytes = await self.read_object(path)
        return content_bytes.decode(encoding)

    async def read_object_stream(self, path: str) -> AsyncIterator[bytes]:
        """
        Read object as a stream of bytes chunks.

        Args:
            path: Path to the object

        Yields:
            Chunks of bytes

        Raises:
            FileNotFoundError: If object does not exist
        """
        try:

            def _get_response():
                return self._client.get_object(self.config.container_name, path)

            response = await asyncio.to_thread(_get_response)

            try:
                chunk_size = self.config.chunk_size
                while True:
                    chunk = await asyncio.to_thread(response.read, chunk_size)
                    if not chunk:
                        break
                    yield chunk

                logger.debug(f"Streamed object {path}")

            finally:
                response.close()
                response.release_conn()

        except S3Error as e:
            if e.code == "NoSuchKey":
                raise FileNotFoundError(f"Object not found: {path}") from e
            logger.error(f"Failed to stream object {path}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Failed to stream object {path}: {e}", exc_info=True)
            raise

    async def write_object(
        self,
        path: str,
        data: bytes | str,
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> bool:
        """
        Write object from bytes or string.

        Args:
            path: Destination path
            data: Content to write (bytes or string)
            content_type: Optional MIME type
            metadata: Optional metadata key-value pairs

        Returns:
            True if successful
        """
        await self._ensure_bucket_exists()

        try:
            # Convert string to bytes if needed
            if isinstance(data, str):
                data = data.encode("utf-8")

            # Create BytesIO stream
            data_stream = io.BytesIO(data)
            data_length = len(data)

            def _put():
                return self._client.put_object(
                    self.config.container_name,
                    path,
                    data_stream,
                    length=data_length,
                    content_type=content_type or "application/octet-stream",
                    metadata=metadata,
                )

            await asyncio.to_thread(_put)

            logger.debug(f"Wrote {data_length} bytes to {path}")
            return True

        except Exception as e:
            logger.error(f"Failed to write object {path}: {e}", exc_info=True)
            raise

    async def write_object_stream(
        self,
        path: str,
        stream: AsyncIterator[bytes],
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> bool:
        """
        Write object from a stream of bytes.

        For MinIO, we buffer the stream and then upload (MinIO SDK requires
        knowing content length upfront for efficient uploads).

        Args:
            path: Destination path
            stream: Async iterator yielding bytes chunks
            content_type: Optional MIME type
            metadata: Optional metadata key-value pairs

        Returns:
            True if successful
        """
        await self._ensure_bucket_exists()

        try:
            # Buffer stream into BytesIO
            # (MinIO requires length for efficient multipart upload)
            buffer = io.BytesIO()
            total_size = 0

            async for chunk in stream:
                if chunk:
                    chunk_size = len(chunk)
                    await asyncio.to_thread(buffer.write, chunk)
                    total_size += chunk_size

            # Reset buffer position
            buffer.seek(0)

            # Upload buffered data
            def _put():
                return self._client.put_object(
                    self.config.container_name,
                    path,
                    buffer,
                    length=total_size,
                    content_type=content_type or "application/octet-stream",
                    metadata=metadata,
                )

            await asyncio.to_thread(_put)

            logger.debug(f"Streamed {total_size} bytes to {path}")
            return True

        except Exception as e:
            logger.error(f"Failed to stream write object {path}: {e}", exc_info=True)
            raise

    async def list_objects(
        self,
        prefix: str = "",
        pattern: str = "*",
        recursive: bool = True,
        include_metadata: bool = False,
    ) -> list[StorageObject]:
        """
        List objects matching prefix and pattern.

        Args:
            prefix: Path prefix to filter objects
            pattern: Glob pattern to match
            recursive: If True, search recursively
            include_metadata: If True, fetch full metadata (slower)

        Returns:
            List of StorageObject instances
        """
        try:

            def _list():
                return list(
                    self._client.list_objects(
                        self.config.container_name,
                        prefix=prefix,
                        recursive=recursive,
                    )
                )

            minio_objects = await asyncio.to_thread(_list)

            objects: list[StorageObject] = []

            for obj in minio_objects:
                # Skip directories
                if obj.is_dir:
                    continue

                object_name = obj.object_name

                # Apply glob pattern matching
                if not fnmatch.fnmatch(object_name, pattern):
                    # Check if pattern has path separators
                    if "/" in pattern or "*" in pattern:
                        filename = object_name.split("/")[-1]
                        if not fnmatch.fnmatch(filename, pattern.split("/")[-1]):
                            continue
                    else:
                        continue

                # Create StorageObject
                storage_obj = StorageObject(
                    path=object_name,
                    name=object_name.split("/")[-1],
                    size=obj.size or 0,
                    modified_time=(
                        obj.last_modified.astimezone(UTC) if obj.last_modified else None
                    ),
                    etag=obj.etag,
                    is_directory=obj.is_dir,
                )

                # Fetch full metadata if requested
                if include_metadata:

                    def _stat():
                        return self._client.stat_object(self.config.container_name, object_name)

                    stat = await asyncio.to_thread(_stat)
                    storage_obj.content_type = stat.content_type
                    storage_obj.metadata = stat.metadata or {}

                objects.append(storage_obj)

            logger.debug(f"Listed {len(objects)} objects with prefix='{prefix}', pattern='{pattern}'")
            return objects

        except Exception as e:
            logger.error(f"Failed to list objects: {e}", exc_info=True)
            raise

    async def exists(self, path: str) -> bool:
        """
        Check if object exists at path.

        Args:
            path: Path to check

        Returns:
            True if object exists, False otherwise
        """
        try:

            def _stat():
                return self._client.stat_object(self.config.container_name, path)

            await asyncio.to_thread(_stat)
            return True

        except S3Error as e:
            if e.code == "NoSuchKey":
                return False
            logger.error(f"Failed to check existence of {path}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Failed to check existence of {path}: {e}", exc_info=True)
            raise

    async def get_metadata(self, path: str) -> StorageObject | None:
        """
        Get object metadata.

        Args:
            path: Path to the object

        Returns:
            StorageObject with metadata, or None if not found
        """
        try:

            def _stat():
                return self._client.stat_object(self.config.container_name, path)

            stat = await asyncio.to_thread(_stat)

            return StorageObject(
                path=path,
                name=path.split("/")[-1],
                size=stat.size,
                modified_time=(
                    stat.last_modified.astimezone(UTC) if stat.last_modified else None
                ),
                etag=stat.etag,
                content_type=stat.content_type,
                metadata=stat.metadata or {},
            )

        except S3Error as e:
            if e.code == "NoSuchKey":
                return None
            logger.error(f"Failed to get metadata for {path}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Failed to get metadata for {path}: {e}", exc_info=True)
            raise

    async def delete_object(self, path: str) -> bool:
        """
        Delete object at path.

        Args:
            path: Path to the object

        Returns:
            True if deleted successfully, False if object did not exist
        """
        try:

            def _remove():
                self._client.remove_object(self.config.container_name, path)

            await asyncio.to_thread(_remove)

            logger.debug(f"Deleted object {path}")
            return True

        except S3Error as e:
            if e.code == "NoSuchKey":
                logger.debug(f"Object not found for deletion: {path}")
                return False
            logger.error(f"Failed to delete object {path}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Failed to delete object {path}: {e}", exc_info=True)
            raise

    async def copy_object(self, src_path: str, dest_path: str) -> bool:
        """
        Copy object from source to destination.

        Args:
            src_path: Source path
            dest_path: Destination path

        Returns:
            True if successful

        Raises:
            FileNotFoundError: If source does not exist
        """
        try:
            from minio import CopySource

            def _copy():
                copy_source = CopySource(self.config.container_name, src_path)
                return self._client.copy_object(
                    self.config.container_name, dest_path, copy_source
                )

            await asyncio.to_thread(_copy)

            logger.debug(f"Copied object from {src_path} to {dest_path}")
            return True

        except S3Error as e:
            if e.code == "NoSuchKey":
                raise FileNotFoundError(f"Source object not found: {src_path}") from e
            logger.error(f"Failed to copy object from {src_path} to {dest_path}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Failed to copy object from {src_path} to {dest_path}: {e}", exc_info=True)
            raise

    async def health_check(self) -> bool:
        """
        Check if storage backend is operational.

        Returns:
            True if healthy and accessible
        """
        try:

            def _check():
                return self._client.bucket_exists(self.config.container_name)

            exists = await asyncio.to_thread(_check)

            if exists:
                logger.debug(f"Health check passed for bucket {self.config.container_name}")
                return True
            else:
                logger.warning(f"Bucket does not exist: {self.config.container_name}")
                return False

        except Exception as e:
            logger.error(f"Health check failed: {e}", exc_info=True)
            return False

    async def create_container(self, container_name: str) -> bool:
        """
        Create a new bucket in MinIO.

        Args:
            container_name: Name of the bucket to create

        Returns:
            True if created successfully, False if already exists
        """
        if not container_name:
            raise ValueError("Container name cannot be empty")

        try:

            def _create():
                # Check if bucket exists first
                if self._client.bucket_exists(container_name):
                    return False
                self._client.make_bucket(container_name)
                return True

            created = await asyncio.to_thread(_create)

            if created:
                logger.info(f"Bucket created: {container_name}")
            else:
                logger.warning(f"Bucket already exists: {container_name}")

            return created

        except S3Error as e:
            if e.code == "BucketAlreadyOwnedByYou" or e.code == "BucketAlreadyExists":
                logger.warning(f"Bucket already exists: {container_name}")
                return False
            logger.error(f"Failed to create bucket {container_name}: {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"Failed to create bucket {container_name}: {e}", exc_info=True)
            raise

    async def delete_container(self, container_name: str, force: bool = False) -> bool:
        """
        Delete a bucket in MinIO.

        Args:
            container_name: Name of the bucket to delete
            force: If True, delete even if bucket is not empty.
                   If False, only delete if empty.

        Returns:
            True if deleted successfully, False if bucket did not exist
        """
        if not container_name:
            raise ValueError("Container name cannot be empty")

        try:

            def _delete():
                # Check if bucket exists
                if not self._client.bucket_exists(container_name):
                    return False

                # If not force, check if bucket is empty
                if not force:
                    objects = list(self._client.list_objects(container_name, max_keys=1))
                    if objects:
                        raise ValueError(
                            f"Bucket '{container_name}' is not empty. "
                            "Use force=True to delete non-empty bucket."
                        )

                # If force, delete all objects first
                if force:
                    objects = self._client.list_objects(container_name, recursive=True)
                    for obj in objects:
                        self._client.remove_object(container_name, obj.object_name)

                self._client.remove_bucket(container_name)
                return True

            deleted = await asyncio.to_thread(_delete)

            if deleted:
                logger.info(f"Bucket deleted: {container_name}")
            else:
                logger.warning(f"Bucket does not exist: {container_name}")

            return deleted

        except S3Error as e:
            if e.code == "NoSuchBucket":
                logger.warning(f"Bucket does not exist: {container_name}")
                return False
            # Re-raise ValueError from empty check
            if isinstance(e, ValueError):
                raise
            logger.error(f"Failed to delete bucket {container_name}: {e}", exc_info=True)
            raise
        except ValueError:
            # Re-raise ValueError from empty check
            raise
        except Exception as e:
            logger.error(f"Failed to delete bucket {container_name}: {e}", exc_info=True)
            raise

    async def container_exists(self, container_name: str) -> bool:
        """
        Check if a bucket exists in MinIO.

        Args:
            container_name: Name of the bucket to check

        Returns:
            True if bucket exists, False otherwise
        """
        if not container_name:
            raise ValueError("Container name cannot be empty")

        try:

            def _check():
                return self._client.bucket_exists(container_name)

            exists = await asyncio.to_thread(_check)
            return exists

        except Exception as e:
            logger.error(f"Failed to check bucket existence {container_name}: {e}", exc_info=True)
            raise

    async def list_containers(self) -> list[str]:
        """
        List all buckets in the MinIO instance.

        Returns:
            List of bucket names
        """
        try:

            def _list():
                buckets = self._client.list_buckets()
                return [bucket.name for bucket in buckets]

            bucket_names = await asyncio.to_thread(_list)

            logger.debug(f"Listed {len(bucket_names)} buckets")
            return bucket_names

        except Exception as e:
            logger.error(f"Failed to list buckets: {e}", exc_info=True)
            raise
