"""Storage abstraction module for cloud-agnostic storage operations.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.

This module provides a unified interface for interacting with different storage
backends including Azure Data Lake Storage Gen2 (ADLS), MinIO, and AWS S3.

Example:
    >>> from ashmatics_tools.storage import create_storage_client, StorageConfig
    >>>
    >>> # Create ADLS client with DefaultAzureCredential
    >>> config = StorageConfig(
    ...     provider="adls",
    ...     account_url="https://mystorageaccount.dfs.core.windows.net",
    ...     container_name="my-container",
    ...     auth_type="default_credential"
    ... )
    >>> storage = create_storage_client("adls", config)
    >>>
    >>> # Use the client
    >>> await storage.write_object("path/file.txt", b"Hello, World!")
    >>> content = await storage.read_object("path/file.txt")
    >>> objects = await storage.list_objects(prefix="path/", pattern="*.txt")
"""

from .adls_store import ADLSStorageClient
from .base import (
    AuthType,
    StorageClient,
    StorageConfig,
    StorageObject,
    StorageProvider,
)
from .factory import create_storage_client
from .minio_store import MinIOStorageClient

__all__ = [
    # Factory function
    "create_storage_client",
    # Base classes and enums
    "StorageClient",
    "StorageConfig",
    "StorageObject",
    "StorageProvider",
    "AuthType",
    # Concrete implementations
    "ADLSStorageClient",
    "MinIOStorageClient",
]
