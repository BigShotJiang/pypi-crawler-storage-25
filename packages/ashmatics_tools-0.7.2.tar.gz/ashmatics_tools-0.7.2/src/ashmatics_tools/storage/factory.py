"""Factory for creating storage client instances.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging

from .base import StorageClient, StorageConfig, StorageProvider

logger = logging.getLogger(__name__)


def create_storage_client(
    provider: str = "adls", config: StorageConfig | None = None
) -> StorageClient:
    """
    Create a storage client instance.

    Args:
        provider: Storage provider ("adls", "minio", "s3")
        config: Storage configuration. If None, uses default config.

    Returns:
        Initialized storage client instance

    Raises:
        ValueError: If provider is not recognized
        ImportError: If required provider library is not installed

    Example:
        >>> import os
        >>> from ashmatics_tools.storage import create_storage_client, StorageConfig
        >>>
        >>> # Create ADLS client with connection string (development)
        >>> config = StorageConfig(
        ...     provider="adls",
        ...     connection_string=os.getenv("AZURE_STORAGE_CONNECTION_STRING"),
        ...     container_name="my-container",
        ...     auth_type="connection_string"
        ... )
        >>> storage = create_storage_client("adls", config)
        >>>
        >>> # Create ADLS client with DefaultAzureCredential (production)
        >>> config = StorageConfig(
        ...     provider="adls",
        ...     account_url="https://mystorageaccount.dfs.core.windows.net",
        ...     container_name="my-container",
        ...     auth_type="default_credential"
        ... )
        >>> storage = create_storage_client("adls", config)
        >>>
        >>> # Create MinIO client
        >>> config = StorageConfig(
        ...     provider="minio",
        ...     endpoint="minio.example.com:9000",
        ...     access_key=os.getenv("MINIO_ACCESS_KEY"),
        ...     secret_key=os.getenv("MINIO_SECRET_KEY"),
        ...     container_name="my-bucket",
        ...     auth_type="access_key"
        ... )
        >>> storage = create_storage_client("minio", config)
        >>>
        >>> # Use the client
        >>> await storage.write_object("path/to/file.txt", b"Hello, World!")
        >>> content = await storage.read_object("path/to/file.txt")
        >>> objects = await storage.list_objects(prefix="path/", pattern="*.txt")
    """
    provider = provider.lower()

    # Create default config if not provided
    if config is None:
        try:
            provider_enum = StorageProvider(provider)
            config = StorageConfig(provider=provider_enum)
        except ValueError:
            available = ", ".join([p.value for p in StorageProvider])
            raise ValueError(
                f"Unknown storage provider: {provider}. Available providers: {available}"
            )

    # Create storage client based on provider
    if provider == "adls" or config.provider == StorageProvider.ADLS:
        try:
            from .adls_store import ADLSStorageClient

            return ADLSStorageClient(config)
        except ImportError as e:
            raise ImportError(
                "ADLS storage requires 'azure-storage-file-datalake' and 'azure-identity' packages. "
                "Install with: pip install azure-storage-file-datalake azure-identity"
            ) from e

    elif provider == "minio" or config.provider == StorageProvider.MINIO:
        try:
            from .minio_store import MinIOStorageClient

            return MinIOStorageClient(config)
        except ImportError as e:
            raise ImportError(
                "MinIO storage requires 'minio' package. "
                "Install with: pip install minio"
            ) from e

    elif provider == "s3" or config.provider == StorageProvider.S3:
        raise NotImplementedError("AWS S3 support coming soon")

    else:
        available = ", ".join([p.value for p in StorageProvider])
        raise ValueError(
            f"Unknown storage provider: {provider}. Available providers: {available}"
        )
