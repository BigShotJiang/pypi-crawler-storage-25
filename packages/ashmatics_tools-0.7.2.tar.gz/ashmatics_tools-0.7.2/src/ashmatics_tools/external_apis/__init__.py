# Copyright 2025 Asher Informatics PBC
"""External API clients for ashmatics-tools.

This module provides clients for external data sources including FDA, Census, CMS, etc.
Each client implements common patterns for rate limiting, retry logic, pagination,
and error handling.

Example usage:
    ```python
    from ashmatics_tools.external_apis import create_api_client, OpenFDAConfig

    # Create OpenFDA client
    config = OpenFDAConfig(api_key="your_key")
    client = create_api_client("openfda", config)

    # Search for devices
    async with client:
        async for result in client.search("device", "implant", limit=100):
            process(result)

    # Create AccessGUDID client
    from ashmatics_tools.external_apis import AccessGUDIDClient, AccessGUDIDConfig

    config = AccessGUDIDConfig()
    async with AccessGUDIDClient(config) as client:
        device = await client.lookup_device(di="08717648200274")
        print(device)
    ```
"""

from .base import (
    APIProvider,
    BaseAPIClient,
    BaseAPIConfig,
    PaginationInfo,
    RateLimitConfig,
)
from .factory import create_api_client, list_api_providers, register_api_provider

# OpenFDA provider
from .openfda import (
    OpenFDAClient,
    OpenFDAConfig,
    OpenFDAEndpoint,
    extract_predicates,
    parse_fda_date,
    transform_510k_to_regulatory_document,
    transform_510k_to_regulatory_metadata,
    transform_pma_to_regulatory_metadata,
)

# AccessGUDID provider
from .accessgudid import (
    AccessGUDIDClient,
    AccessGUDIDConfig,
    AccessGUDIDEndpoint,
)

# Register providers
from .factory import _API_REGISTRY, _CONFIG_REGISTRY

_API_REGISTRY["openfda"] = OpenFDAClient
_CONFIG_REGISTRY["openfda"] = OpenFDAConfig

_API_REGISTRY["accessgudid"] = AccessGUDIDClient
_CONFIG_REGISTRY["accessgudid"] = AccessGUDIDConfig

__all__ = [
    # Base classes
    "BaseAPIClient",
    "BaseAPIConfig",
    "APIProvider",
    "PaginationInfo",
    "RateLimitConfig",
    # Factory functions
    "create_api_client",
    "register_api_provider",
    "list_api_providers",
    # OpenFDA
    "OpenFDAClient",
    "OpenFDAConfig",
    "OpenFDAEndpoint",
    # OpenFDA transformations
    "parse_fda_date",
    "extract_predicates",
    "transform_510k_to_regulatory_metadata",
    "transform_510k_to_regulatory_document",
    "transform_pma_to_regulatory_metadata",
    # AccessGUDID
    "AccessGUDIDClient",
    "AccessGUDIDConfig",
    "AccessGUDIDEndpoint",
]
