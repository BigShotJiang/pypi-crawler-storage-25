# Copyright 2025 Asher Informatics PBC
"""AccessGUDID API client for device identifier lookup.

AccessGUDID is the public-facing portal to the FDA's Global Unique Device
Identification Database (GUDID). It provides APIs for looking up medical
device information by UDI, DI, or record key.

This module provides:
- AccessGUDIDClient: Async client for AccessGUDID API v3
- AccessGUDIDConfig: Configuration for the client
- AccessGUDIDEndpoint: Enum of available endpoints
- Typed models: GUDIDDevice, ParsedUDI, etc. for type-safe data handling
- Transform functions: Convert raw API responses to typed models

Example usage:
    ```python
    from ashmatics_tools.external_apis.accessgudid import (
        AccessGUDIDClient,
        AccessGUDIDConfig,
        AccessGUDIDEndpoint,
    )

    config = AccessGUDIDConfig()
    async with AccessGUDIDClient(config) as client:
        # Lookup device by DI (raw JSON response)
        device = await client.lookup_device(di="08717648200274")
        print(device)

        # Lookup device with typed response
        result = await client.lookup_device_typed(di="08717648200274")
        print(f"Brand: {result.device.brand_name}")

        # Parse a UDI string (typed)
        parsed = await client.parse_udi_typed(udi="(01)00844588012919(17)141231(10)A213B1")
        print(f"DI: {parsed.di}, Lot: {parsed.lot_number}")

        # Get device history
        history = await client.get_device_history_typed(di="08717648200274")
        for version in history.versions:
            print(f"Version {version.public_version_number}")
    ```

See https://accessgudid.nlm.nih.gov/resources/developers for full API documentation.
"""

from .client import AccessGUDIDClient
from .config import AccessGUDIDConfig, AccessGUDIDEndpoint

# Typed models
from .models import (
    DeviceHistory,
    DeviceHistoryVersion,
    DeviceIdentifier,
    DeviceLookupResult,
    DeviceRecordStatus,
    DeviceSNOMED,
    GMDNTerm,
    GUDIDDevice,
    ImplantableDevice,
    ParsedUDI,
    SNOMEDConcept,
    UDIIssuingAgency,
)

# Transform functions
from .transforms import (
    parse_gudid_date,
    transform_device,
    transform_device_history,
    transform_device_lookup,
    transform_device_snomed,
    transform_implantable_device,
    transform_parsed_udi,
)

__all__ = [
    # Client and config
    "AccessGUDIDClient",
    "AccessGUDIDConfig",
    "AccessGUDIDEndpoint",
    # Enums
    "UDIIssuingAgency",
    "DeviceRecordStatus",
    # Typed models
    "ParsedUDI",
    "GMDNTerm",
    "DeviceIdentifier",
    "GUDIDDevice",
    "DeviceLookupResult",
    "DeviceHistoryVersion",
    "DeviceHistory",
    "SNOMEDConcept",
    "DeviceSNOMED",
    "ImplantableDevice",
    # Transform functions
    "parse_gudid_date",
    "transform_parsed_udi",
    "transform_device",
    "transform_device_lookup",
    "transform_device_history",
    "transform_device_snomed",
    "transform_implantable_device",
]
