# Copyright 2025 Asher Informatics PBC
"""
Typed data models for AccessGUDID API responses.

This module provides Pydantic models for AccessGUDID data structures,
enabling type-safe handling of device information, parsed UDIs, and
SNOMED concepts.

These models can be used directly or via the typed transformation functions
in the transforms module.

Reference: https://accessgudid.nlm.nih.gov/resources/developers/v3
"""

from datetime import date
from enum import Enum
from typing import Any, Optional

from pydantic import Field

from ashmatics_datamodels.common.base import AshMaticsBaseModel


class UDIIssuingAgency(str, Enum):
    """UDI Issuing Agencies (Accredited Issuing Agencies for UDIs)."""

    GS1 = "GS1"  # GS1 (formerly EAN.UCC)
    HIBCC = "HIBCC"  # Health Industry Business Communications Council
    ICCBBA = "ICCBBA"  # International Council for Commonality in Blood Banking Automation
    IFA = "IFA"  # Informationsstelle für Arzneispezialitäten (Germany)


class DeviceRecordStatus(str, Enum):
    """Status of the device record in GUDID."""

    PUBLISHED = "Published"
    UNPUBLISHED = "Unpublished"


# =============================================================================
# Parsed UDI Models
# =============================================================================


class ParsedUDI(AshMaticsBaseModel):
    """
    Parsed components of a Unique Device Identifier (UDI).

    The UDI is parsed by the AccessGUDID API into its constituent parts
    including the device identifier, production identifiers (lot, serial,
    expiration, manufacturing date), and issuing agency.

    Reference: https://accessgudid.nlm.nih.gov/resources/developers/v3/parse_udi_api
    """

    udi: str = Field(
        ...,
        description="The full Unique Device Identifier string",
    )
    issuing_agency: Optional[UDIIssuingAgency] = Field(
        None,
        description="The Issuing Agency of this UDI (GS1, HIBCC, ICCBBA)",
    )
    di: Optional[str] = Field(
        None,
        description="Device Identifier - identifies the labeler and device version/model",
    )

    # Production Identifiers (PI)
    serial_number: Optional[str] = Field(
        None,
        description="Serial number of the device (if encoded in UDI)",
    )
    lot_number: Optional[str] = Field(
        None,
        description="Lot/batch number of the device (if encoded in UDI)",
    )
    manufacturing_date: Optional[date] = Field(
        None,
        description="Manufacturing/production date (normalized YYYY-MM-DD)",
    )
    expiration_date: Optional[date] = Field(
        None,
        description="Expiration date (normalized YYYY-MM-DD)",
    )

    # Original date formats (for reference)
    manufacturing_date_original: Optional[str] = Field(
        None,
        description="Manufacturing date as encoded in UDI (original format)",
    )
    manufacturing_date_original_format: Optional[str] = Field(
        None,
        description="Format specification for original manufacturing date",
    )
    expiration_date_original: Optional[str] = Field(
        None,
        description="Expiration date as encoded in UDI (original format)",
    )
    expiration_date_original_format: Optional[str] = Field(
        None,
        description="Format specification for original expiration date",
    )

    # ICCBBA-specific fields
    donation_id: Optional[str] = Field(
        None,
        description="Donation Identification Number (ICCBBA issuing agency only)",
    )
    mpho_lot_number: Optional[str] = Field(
        None,
        description="MPHO Lot Number (ICCBBA issuing agency only)",
    )


# =============================================================================
# GMDN Models
# =============================================================================


class GMDNTerm(AshMaticsBaseModel):
    """
    Global Medical Device Nomenclature (GMDN) term.

    GMDN provides standardized terminology for medical devices,
    used for classification and regulatory purposes.
    """

    gmdn_preferred_term_name: Optional[str] = Field(
        None,
        description="GMDN Preferred Term Name (PT Name)",
    )
    gmdn_preferred_term_code: Optional[str] = Field(
        None,
        description="GMDN Preferred Term Code",
    )
    gmdn_code_status: Optional[str] = Field(
        None,
        description="GMDN Code Status (Active or Obsolete)",
    )
    gmdn_implantable: Optional[bool] = Field(
        None,
        description="Whether GMDN term indicates implantable device",
    )


# =============================================================================
# Device Identifier Models
# =============================================================================


class DeviceIdentifier(AshMaticsBaseModel):
    """
    Device identifier information from GUDID.

    Contains the various identifiers used to track a medical device
    including DI, primary DI, and record key.
    """

    device_id: Optional[str] = Field(
        None,
        description="Device identifier (DI) string",
    )
    primary_di: Optional[str] = Field(
        None,
        description="Primary Device Identifier for this device package",
    )
    record_key: Optional[str] = Field(
        None,
        description="Public Device Record Key (unique identifier in GUDID)",
    )
    issuing_agency: Optional[UDIIssuingAgency] = Field(
        None,
        description="Issuing Agency for this DI",
    )


# =============================================================================
# Device Models
# =============================================================================


class GUDIDDevice(AshMaticsBaseModel):
    """
    Complete device information from AccessGUDID.

    Represents a medical device record from the FDA's Global Unique Device
    Identification Database (GUDID).

    Reference: https://accessgudid.nlm.nih.gov/resources/developers/v3/device_lookup_api
    """

    # Identifiers
    device_id: Optional[str] = Field(
        None,
        description="Device identifier (DI)",
    )
    primary_di: Optional[str] = Field(
        None,
        description="Primary Device Identifier",
    )
    record_key: Optional[str] = Field(
        None,
        description="Public Device Record Key",
    )
    issuing_agency: Optional[UDIIssuingAgency] = Field(
        None,
        description="Issuing Agency for UDI",
    )

    # Device Information
    brand_name: Optional[str] = Field(
        None,
        description="Brand name of the device",
    )
    device_description: Optional[str] = Field(
        None,
        description="Description of the device",
    )
    company_name: Optional[str] = Field(
        None,
        description="Name of the company/labeler",
    )
    version_model_number: Optional[str] = Field(
        None,
        description="Version or model number",
    )
    catalog_number: Optional[str] = Field(
        None,
        description="Catalog number",
    )

    # GMDN Classification
    gmdn_terms: list[GMDNTerm] = Field(
        default_factory=list,
        description="Associated GMDN terms",
    )

    # FDA Product Codes
    product_codes: list[str] = Field(
        default_factory=list,
        description="FDA three-letter product codes",
    )

    # Device Characteristics
    is_single_use: Optional[bool] = Field(
        None,
        description="Whether device is single-use",
    )
    is_kit: Optional[bool] = Field(
        None,
        description="Whether device is a kit",
    )
    is_combination_product: Optional[bool] = Field(
        None,
        description="Whether device is a combination product",
    )
    is_pm_exempt: Optional[bool] = Field(
        None,
        description="Whether device is exempt from premarket notification",
    )
    has_lot_batch: Optional[bool] = Field(
        None,
        description="Whether lot/batch number is required on device label",
    )
    has_serial_number: Optional[bool] = Field(
        None,
        description="Whether serial number is required on device label",
    )
    has_manufacturing_date: Optional[bool] = Field(
        None,
        description="Whether manufacturing date is required on device label",
    )
    has_expiration_date: Optional[bool] = Field(
        None,
        description="Whether expiration date is required on device label",
    )

    # Implantable/Safety Information
    is_labeled_as_nrl: Optional[bool] = Field(
        None,
        description="Whether device is labeled as containing natural rubber latex",
    )
    labeled_contains_nrl: Optional[bool] = Field(
        None,
        description="Whether device is labeled as containing natural rubber latex (GUDID field name)",
    )
    mri_safety_status: Optional[str] = Field(
        None,
        description="MRI Safety status (MR Safe, MR Conditional, MR Unsafe, etc.)",
    )

    # Sterilization
    is_sterile: Optional[bool] = Field(
        None,
        description="Whether device is sterile",
    )
    is_rx: Optional[bool] = Field(
        None,
        description="Whether device requires prescription",
    )
    is_otc: Optional[bool] = Field(
        None,
        description="Whether device is over-the-counter",
    )

    # Record metadata
    device_record_status: Optional[DeviceRecordStatus] = Field(
        None,
        description="Status of the device record (Published/Unpublished)",
    )
    public_version_number: Optional[str] = Field(
        None,
        description="Public version number of the device record",
    )
    public_version_date: Optional[date] = Field(
        None,
        description="Date of the current public version",
    )
    publish_date: Optional[date] = Field(
        None,
        description="Date when record was first published",
    )

    # Additional raw data
    additional_data: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional fields from API response not mapped to typed fields",
    )


# =============================================================================
# Device History Models
# =============================================================================


class DeviceHistoryVersion(AshMaticsBaseModel):
    """A single version in a device's history."""

    public_version_number: Optional[str] = Field(
        None,
        description="Version number of this historical record",
    )
    public_version_date: Optional[date] = Field(
        None,
        description="Date of this version",
    )
    xml_record: Optional[str] = Field(
        None,
        description="Full XML record for this version (if requested)",
    )


class DeviceHistory(AshMaticsBaseModel):
    """Complete version history for a device."""

    device_id: Optional[str] = Field(
        None,
        description="Device identifier",
    )
    versions: list[DeviceHistoryVersion] = Field(
        default_factory=list,
        description="List of historical versions",
    )
    parsed_udi: Optional[ParsedUDI] = Field(
        None,
        description="Parsed UDI information (if UDI was used for lookup)",
    )


# =============================================================================
# SNOMED Models
# =============================================================================


class SNOMEDConcept(AshMaticsBaseModel):
    """
    SNOMED CT concept associated with a medical device.

    SNOMED CT (Systematized Nomenclature of Medicine - Clinical Terms)
    provides clinical terminology for interoperability.
    """

    snomed_ct_name: str = Field(
        ...,
        description="SNOMED CT concept name/description",
    )
    snomed_identifier: str = Field(
        ...,
        description="SNOMED CT concept identifier (numeric code)",
    )


class DeviceSNOMED(AshMaticsBaseModel):
    """SNOMED CT concepts associated with a device."""

    device_id: Optional[str] = Field(
        None,
        description="Device identifier",
    )
    concepts: list[SNOMEDConcept] = Field(
        default_factory=list,
        description="List of associated SNOMED CT concepts",
    )
    parsed_udi: Optional[ParsedUDI] = Field(
        None,
        description="Parsed UDI information (if UDI was used for lookup)",
    )


# =============================================================================
# Implantable Device Models
# =============================================================================


class ImplantableDevice(AshMaticsBaseModel):
    """
    Implantable device summary from the implantable list API.

    Contains key information about devices flagged as implantable
    or accessories to implant systems.
    """

    device_id: Optional[str] = Field(
        None,
        description="Device identifier",
    )
    brand_name: Optional[str] = Field(
        None,
        description="Brand name",
    )
    company_name: Optional[str] = Field(
        None,
        description="Company/labeler name",
    )
    version_model_number: Optional[str] = Field(
        None,
        description="Version or model number",
    )
    mri_safety_status: Optional[str] = Field(
        None,
        description="MRI Safety status",
    )
    labeled_contains_nrl: Optional[bool] = Field(
        None,
        description="Whether device contains natural rubber latex",
    )
    device_record_status: Optional[DeviceRecordStatus] = Field(
        None,
        description="Status of the device record",
    )
    gmdn_terms: list[GMDNTerm] = Field(
        default_factory=list,
        description="Associated GMDN terms",
    )
    snomed_concepts: list[SNOMEDConcept] = Field(
        default_factory=list,
        description="Associated SNOMED concepts (requires UMLS ticket)",
    )


# =============================================================================
# Lookup Result Models
# =============================================================================


class DeviceLookupResult(AshMaticsBaseModel):
    """
    Result of a device lookup operation.

    Combines the device information with any parsed UDI data
    (when UDI was used for the lookup).
    """

    device: GUDIDDevice = Field(
        ...,
        description="Device information from GUDID",
    )
    parsed_udi: Optional[ParsedUDI] = Field(
        None,
        description="Parsed UDI information (if UDI was used for lookup)",
    )


# Export all models
__all__ = [
    # Enums
    "UDIIssuingAgency",
    "DeviceRecordStatus",
    # UDI Models
    "ParsedUDI",
    # GMDN Models
    "GMDNTerm",
    # Device Models
    "DeviceIdentifier",
    "GUDIDDevice",
    "DeviceLookupResult",
    # History Models
    "DeviceHistoryVersion",
    "DeviceHistory",
    # SNOMED Models
    "SNOMEDConcept",
    "DeviceSNOMED",
    # Implantable Device Models
    "ImplantableDevice",
]
