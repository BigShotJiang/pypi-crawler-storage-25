# Copyright 2025 Asher Informatics PBC
"""AccessGUDID API configuration and endpoint definitions."""

from dataclasses import dataclass, field
from enum import Enum

from ..base import BaseAPIConfig, RateLimitConfig


class AccessGUDIDEndpoint(str, Enum):
    """AccessGUDID API v3 endpoints.

    See https://accessgudid.nlm.nih.gov/resources/developers for full documentation.
    """

    # Device endpoints
    DEVICE_LOOKUP = "devices/lookup"  # Lookup device by DI, UDI, or record_key
    DEVICE_HISTORY = "devices/history"  # Get device version history
    DEVICE_SNOMED = "devices/snomed"  # Get SNOMED CT codes for device (requires UMLS ticket)
    IMPLANTABLE_LIST = "devices/implantable/list"  # List implantable devices

    # UDI parsing
    PARSE_UDI = "parse_udi"  # Parse UDI string into components


@dataclass
class AccessGUDIDConfig(BaseAPIConfig):
    """
    Configuration for AccessGUDID API client.

    AccessGUDID is a public API and does not require an API key for basic operations.
    However, SNOMED lookups require a UMLS API key.

    Rate limits are not strictly documented, but we apply conservative defaults
    to be a good API citizen.

    Attributes:
        base_url: AccessGUDID API base URL (default: https://accessgudid.nlm.nih.gov/api/v3)
        umls_api_key: UMLS API key for SNOMED lookups (optional)
        timeout: Request timeout in seconds
        max_retries: Maximum retry attempts
        retry_delay: Initial retry delay in seconds
        rate_limit: Rate limiting configuration
        verify_ssl: Verify SSL certificates
        extra_headers: Additional HTTP headers

    Example:
        ```python
        # Basic configuration (no SNOMED access)
        config = AccessGUDIDConfig()

        # With UMLS API key for SNOMED lookups
        config = AccessGUDIDConfig(umls_api_key="your_umls_key")

        # Custom rate limiting
        config = AccessGUDIDConfig(
            rate_limit=RateLimitConfig(
                requests_per_second=2.0,
                burst_size=5
            )
        )
        ```
    """

    base_url: str = "https://accessgudid.nlm.nih.gov/api/v3"
    umls_api_key: str | None = None  # Required for SNOMED lookups

    # Default rate limiting - conservative since limits not documented
    rate_limit: RateLimitConfig = field(default=None)  # type: ignore

    def __post_init__(self):
        """Set default rate limiting."""
        # Set default rate limit if not provided
        if self.rate_limit is None:
            # Conservative rate limiting since AccessGUDID limits aren't documented
            self.rate_limit = RateLimitConfig(
                requests_per_second=2.0,  # 2 requests per second
                burst_size=5,
                use_rate_limiting=True,
            )

        # Call parent validation
        super().__post_init__()
