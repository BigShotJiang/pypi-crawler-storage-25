# Copyright 2025 Asher Informatics PBC
"""
Transformation utilities for converting AccessGUDID API responses to typed models.

This module provides functions to transform raw AccessGUDID JSON responses into
strongly-typed Pydantic models for type-safe data handling.

Example usage:
    ```python
    from ashmatics_tools.external_apis.accessgudid import (
        AccessGUDIDClient,
        AccessGUDIDConfig,
        transform_device_lookup,
        transform_parsed_udi,
    )

    config = AccessGUDIDConfig()
    async with AccessGUDIDClient(config) as client:
        # Get typed device lookup
        raw_response = await client.lookup_device(di="08717648200274")
        device = transform_device_lookup(raw_response)
        print(f"Brand: {device.device.brand_name}")

        # Get typed parsed UDI
        raw_parsed = await client.parse_udi(udi="(01)00844588012919(17)141231(10)A213B1")
        parsed = transform_parsed_udi(raw_parsed)
        print(f"Lot: {parsed.lot_number}")
    ```
"""

import logging
from datetime import date, datetime
from typing import Any, Optional

from .models import (
    DeviceHistory,
    DeviceHistoryVersion,
    DeviceLookupResult,
    DeviceRecordStatus,
    DeviceSNOMED,
    GMDNTerm,
    GUDIDDevice,
    ImplantableDevice,
    ParsedUDI,
    SNOMEDConcept,
    UDIIssuingAgency,
)

logger = logging.getLogger(__name__)


def parse_gudid_date(date_str: Optional[str]) -> Optional[date]:
    """
    Parse AccessGUDID date strings to Python date.

    AccessGUDID uses YYYY-MM-DD format for normalized dates.

    Args:
        date_str: Date string from AccessGUDID

    Returns:
        Python date object or None if parsing fails

    Example:
        >>> parse_gudid_date("2024-12-31")
        date(2024, 12, 31)
    """
    if not date_str:
        return None

    try:
        # AccessGUDID uses YYYY-MM-DD format
        if "-" in date_str:
            return datetime.strptime(date_str, "%Y-%m-%d").date()
        # Fallback for YYYYMMDD format
        elif len(date_str) == 8 and date_str.isdigit():
            return datetime.strptime(date_str, "%Y%m%d").date()
    except (ValueError, AttributeError) as e:
        logger.warning(f"Failed to parse AccessGUDID date '{date_str}': {e}")
        return None

    return None


def _parse_issuing_agency(agency_str: Optional[str]) -> Optional[UDIIssuingAgency]:
    """Parse issuing agency string to enum."""
    if not agency_str:
        return None
    try:
        return UDIIssuingAgency(agency_str.upper())
    except ValueError:
        logger.warning(f"Unknown issuing agency: {agency_str}")
        return None


def _parse_device_record_status(status_str: Optional[str]) -> Optional[DeviceRecordStatus]:
    """Parse device record status string to enum."""
    if not status_str:
        return None
    try:
        return DeviceRecordStatus(status_str)
    except ValueError:
        logger.warning(f"Unknown device record status: {status_str}")
        return None


def transform_parsed_udi(raw_response: dict[str, Any]) -> ParsedUDI:
    """
    Transform raw parse_udi API response to ParsedUDI model.

    Args:
        raw_response: Raw JSON response from AccessGUDID parse_udi endpoint

    Returns:
        Typed ParsedUDI object

    Example:
        ```python
        raw = await client.parse_udi(udi="(01)00844588012919(17)141231(10)A213B1")
        parsed = transform_parsed_udi(raw)
        print(f"DI: {parsed.di}")
        print(f"Lot: {parsed.lot_number}")
        print(f"Expiration: {parsed.expiration_date}")
        ```
    """
    return ParsedUDI(
        udi=raw_response.get("udi", ""),
        issuing_agency=_parse_issuing_agency(raw_response.get("issuingAgency")),
        di=raw_response.get("di"),
        serial_number=raw_response.get("serialNumber"),
        lot_number=raw_response.get("lotNumber"),
        manufacturing_date=parse_gudid_date(raw_response.get("manufacturingDate")),
        expiration_date=parse_gudid_date(raw_response.get("expirationDate")),
        manufacturing_date_original=raw_response.get("manufacturingDateOriginal"),
        manufacturing_date_original_format=raw_response.get("manufacturingDateOriginalFormat"),
        expiration_date_original=raw_response.get("expirationDateOriginal"),
        expiration_date_original_format=raw_response.get("expirationDateOriginalFormat"),
        donation_id=raw_response.get("donationId"),
        mpho_lot_number=raw_response.get("mphoLotNumber"),
    )


def _extract_gmdn_terms(device_data: dict[str, Any]) -> list[GMDNTerm]:
    """Extract GMDN terms from device data."""
    gmdn_terms = []

    # GMDN data can be in various locations
    gmdn_list = device_data.get("gmdnTerms", [])
    if not isinstance(gmdn_list, list):
        gmdn_list = [gmdn_list] if gmdn_list else []

    for gmdn in gmdn_list:
        if isinstance(gmdn, dict):
            gmdn_terms.append(
                GMDNTerm(
                    gmdn_preferred_term_name=gmdn.get("gmdnPTName"),
                    gmdn_preferred_term_code=gmdn.get("gmdnPTDefinition")
                    or gmdn.get("gmdnTermCode"),
                    gmdn_code_status=gmdn.get("gmdnCodeStatus"),
                    gmdn_implantable=gmdn.get("implantable"),
                )
            )

    return gmdn_terms


def _extract_product_codes(device_data: dict[str, Any]) -> list[str]:
    """Extract FDA product codes from device data."""
    product_codes = []

    # Product codes can be in various locations
    codes = device_data.get("productCodes", {})
    if isinstance(codes, dict):
        # Nested structure: {"fdaProductCode": [...]}
        code_list = codes.get("fdaProductCode", [])
        if isinstance(code_list, list):
            for code in code_list:
                if isinstance(code, dict):
                    pc = code.get("productCode")
                    if pc:
                        product_codes.append(pc)
                elif isinstance(code, str):
                    product_codes.append(code)
    elif isinstance(codes, list):
        product_codes = [c for c in codes if isinstance(c, str)]

    return product_codes


def transform_device(device_data: dict[str, Any]) -> GUDIDDevice:
    """
    Transform raw device data to GUDIDDevice model.

    Args:
        device_data: Device data from AccessGUDID (nested under 'device' key)

    Returns:
        Typed GUDIDDevice object
    """
    # Extract nested data
    gmdn_terms = _extract_gmdn_terms(device_data)
    product_codes = _extract_product_codes(device_data)

    # Build typed device
    return GUDIDDevice(
        device_id=device_data.get("deviceId") or device_data.get("primaryDi"),
        primary_di=device_data.get("primaryDi"),
        record_key=device_data.get("deviceRecordKey") or device_data.get("publicDeviceRecordKey"),
        issuing_agency=_parse_issuing_agency(device_data.get("issuingAgency")),
        brand_name=device_data.get("brandName"),
        device_description=device_data.get("deviceDescription"),
        company_name=device_data.get("companyName"),
        version_model_number=device_data.get("versionModelNumber"),
        catalog_number=device_data.get("catalogNumber"),
        gmdn_terms=gmdn_terms,
        product_codes=product_codes,
        is_single_use=device_data.get("singleUse"),
        is_kit=device_data.get("deviceKit"),
        is_combination_product=device_data.get("combinationProduct"),
        is_pm_exempt=device_data.get("preMarketExempt"),
        has_lot_batch=device_data.get("hasLotBatch"),
        has_serial_number=device_data.get("hasSerialNumber"),
        has_manufacturing_date=device_data.get("hasManufacturingDate"),
        has_expiration_date=device_data.get("hasExpirationDate"),
        is_labeled_as_nrl=device_data.get("labeledAsNRL"),
        labeled_contains_nrl=device_data.get("labeledContainsNRL"),
        mri_safety_status=device_data.get("MRISafetyStatus"),
        is_sterile=device_data.get("sterilization", {}).get("deviceSterile")
        if isinstance(device_data.get("sterilization"), dict)
        else None,
        is_rx=device_data.get("rx"),
        is_otc=device_data.get("otc"),
        device_record_status=_parse_device_record_status(device_data.get("deviceRecordStatus")),
        public_version_number=device_data.get("publicVersionNumber"),
        public_version_date=parse_gudid_date(device_data.get("publicVersionDate")),
        publish_date=parse_gudid_date(device_data.get("publishDate")),
    )


def transform_device_lookup(raw_response: dict[str, Any]) -> DeviceLookupResult:
    """
    Transform raw device lookup API response to DeviceLookupResult model.

    Args:
        raw_response: Raw JSON response from AccessGUDID device lookup endpoint

    Returns:
        Typed DeviceLookupResult object with device and optional parsed UDI

    Example:
        ```python
        raw = await client.lookup_device(di="08717648200274")
        result = transform_device_lookup(raw)
        print(f"Brand: {result.device.brand_name}")
        print(f"Company: {result.device.company_name}")
        ```
    """
    # Extract device data from nested structure
    gudid = raw_response.get("gudid", {})
    device_data = gudid.get("device", {})

    # Transform device
    device = transform_device(device_data)

    # Check for parsed UDI (when UDI parameter was used)
    parsed_udi = None
    udi_data = raw_response.get("udi") or gudid.get("udi")
    if udi_data:
        # UDI parsing data may be at top level of response
        parsed_udi = transform_parsed_udi(raw_response)

    return DeviceLookupResult(
        device=device,
        parsed_udi=parsed_udi,
    )


def transform_device_history(raw_response: dict[str, Any]) -> DeviceHistory:
    """
    Transform raw device history API response to DeviceHistory model.

    Args:
        raw_response: Raw JSON response from AccessGUDID device history endpoint

    Returns:
        Typed DeviceHistory object with version list

    Example:
        ```python
        raw = await client.get_device_history(di="08717648200274")
        history = transform_device_history(raw)
        for version in history.versions:
            print(f"Version {version.public_version_number}: {version.public_version_date}")
        ```
    """
    # Extract history data
    history_list = raw_response.get("deviceHistory", [])
    if not isinstance(history_list, list):
        history_list = [history_list] if history_list else []

    versions = []
    for entry in history_list:
        if isinstance(entry, dict):
            versions.append(
                DeviceHistoryVersion(
                    public_version_number=entry.get("publicVersionNumber"),
                    public_version_date=parse_gudid_date(entry.get("publicVersionDate")),
                    xml_record=entry.get("xml"),
                )
            )

    # Check for parsed UDI
    parsed_udi = None
    if raw_response.get("udi") or raw_response.get("di"):
        parsed_udi = transform_parsed_udi(raw_response)

    return DeviceHistory(
        device_id=raw_response.get("di"),
        versions=versions,
        parsed_udi=parsed_udi,
    )


def transform_device_snomed(raw_response: dict[str, Any]) -> DeviceSNOMED:
    """
    Transform raw SNOMED API response to DeviceSNOMED model.

    Args:
        raw_response: Raw JSON response from AccessGUDID device SNOMED endpoint

    Returns:
        Typed DeviceSNOMED object with SNOMED concepts

    Example:
        ```python
        raw = await client.get_device_snomed(di="08717648200274")
        snomed = transform_device_snomed(raw)
        for concept in snomed.concepts:
            print(f"{concept.snomed_ct_name}: {concept.snomed_identifier}")
        ```
    """
    # Extract concepts
    concepts_list = raw_response.get("concepts", [])
    if not isinstance(concepts_list, list):
        concepts_list = [concepts_list] if concepts_list else []

    concepts = []
    for concept in concepts_list:
        if isinstance(concept, dict):
            ct_name = concept.get("snomedCTName")
            identifier = concept.get("snomedIdentifier")
            if ct_name and identifier:
                concepts.append(
                    SNOMEDConcept(
                        snomed_ct_name=ct_name,
                        snomed_identifier=str(identifier),
                    )
                )

    # Check for parsed UDI
    parsed_udi = None
    if raw_response.get("udi") or raw_response.get("di"):
        parsed_udi = transform_parsed_udi(raw_response)

    return DeviceSNOMED(
        device_id=raw_response.get("di"),
        concepts=concepts,
        parsed_udi=parsed_udi,
    )


def transform_implantable_device(raw_device: dict[str, Any]) -> ImplantableDevice:
    """
    Transform raw implantable device list item to ImplantableDevice model.

    Args:
        raw_device: Single device from implantable list API response

    Returns:
        Typed ImplantableDevice object

    Example:
        ```python
        async for raw_device in client.list_implantable_devices(max_records=10):
            device = transform_implantable_device(raw_device)
            print(f"{device.brand_name} - {device.company_name}")
        ```
    """
    # Extract GMDN terms
    gmdn_terms = _extract_gmdn_terms(raw_device)

    # Extract SNOMED concepts if present
    concepts = []
    snomed_list = raw_device.get("snomedConcepts", [])
    if isinstance(snomed_list, list):
        for concept in snomed_list:
            if isinstance(concept, dict):
                ct_name = concept.get("snomedCTName")
                identifier = concept.get("snomedIdentifier")
                if ct_name and identifier:
                    concepts.append(
                        SNOMEDConcept(
                            snomed_ct_name=ct_name,
                            snomed_identifier=str(identifier),
                        )
                    )

    return ImplantableDevice(
        device_id=raw_device.get("deviceId") or raw_device.get("primaryDi"),
        brand_name=raw_device.get("brandName"),
        company_name=raw_device.get("companyName"),
        version_model_number=raw_device.get("versionModelNumber"),
        mri_safety_status=raw_device.get("MRISafetyStatus"),
        labeled_contains_nrl=raw_device.get("labeledContainsNRL"),
        device_record_status=_parse_device_record_status(raw_device.get("deviceRecordStatus")),
        gmdn_terms=gmdn_terms,
        snomed_concepts=concepts,
    )


# Export all transformation functions
__all__ = [
    "parse_gudid_date",
    "transform_parsed_udi",
    "transform_device",
    "transform_device_lookup",
    "transform_device_history",
    "transform_device_snomed",
    "transform_implantable_device",
]
