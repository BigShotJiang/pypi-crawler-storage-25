# Copyright 2025 Asher Informatics PBC
"""AccessGUDID API client implementation."""

import logging
from collections.abc import AsyncIterator
from typing import Any
from urllib.parse import quote

from ..base import BaseAPIClient, PaginationInfo
from .config import AccessGUDIDConfig, AccessGUDIDEndpoint

logger = logging.getLogger(__name__)


class AccessGUDIDClient(BaseAPIClient):
    """
    Client for the AccessGUDID API (accessgudid.nlm.nih.gov).

    Provides access to FDA's Global Unique Device Identification Database including:
    - Device lookup by DI, UDI, or record key
    - UDI parsing (GS1, HIBCC, ICCBBA formats)
    - Device version history
    - SNOMED CT mappings (requires UMLS API key)
    - Implantable device listings

    Features:
    - Automatic pagination for list endpoints
    - Rate limiting
    - Retry with exponential backoff
    - Support for both JSON and XML responses

    Example:
        ```python
        from ashmatics_tools.external_apis.accessgudid import (
            AccessGUDIDClient,
            AccessGUDIDConfig,
        )

        config = AccessGUDIDConfig()
        async with AccessGUDIDClient(config) as client:
            # Lookup device by Device Identifier
            device = await client.lookup_device(di="08717648200274")
            print(f"Brand: {device.get('gudid', {}).get('device', {}).get('brandName')}")

            # Parse a UDI string
            parsed = await client.parse_udi(
                udi="(01)00844588012919(17)141231(10)A213B1"
            )
            print(f"DI: {parsed.get('di')}")
            print(f"Expiration: {parsed.get('expirationDate')}")

            # List implantable devices with pagination
            async for device in client.list_implantable_devices(max_records=100):
                print(device.get('brandName'))
        ```

    See https://accessgudid.nlm.nih.gov/resources/developers for full documentation.
    """

    def __init__(self, config: AccessGUDIDConfig):
        """Initialize AccessGUDID client.

        Args:
            config: AccessGUDID configuration
        """
        super().__init__(config)
        self.config: AccessGUDIDConfig = config  # Type hint for IDE support

    def get_endpoint_path(self, endpoint: str | AccessGUDIDEndpoint) -> str:
        """
        Get the full API path for an endpoint.

        Args:
            endpoint: Endpoint identifier (string or AccessGUDIDEndpoint enum)

        Returns:
            Full API path (e.g., "/devices/lookup.json")
        """
        if isinstance(endpoint, AccessGUDIDEndpoint):
            endpoint = endpoint.value
        return f"/{endpoint}.json"

    def _build_query_params(
        self,
        endpoint: str,
        query: str,
        limit: int,
        skip: int,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Build AccessGUDID query parameters.

        Note: AccessGUDID uses page-based pagination rather than skip/limit.

        Args:
            endpoint: API endpoint
            query: Not used for AccessGUDID (kept for interface compatibility)
            limit: Results per page (per_page parameter)
            skip: Used to calculate page number
            **kwargs: Additional parameters (di, udi, record_key, etc.)

        Returns:
            Dictionary of query parameters
        """
        params: dict[str, Any] = {}

        # For list endpoints, use pagination parameters
        if "list" in endpoint:
            params["per_page"] = min(limit, 100)  # Max 100 per page
            if skip > 0:
                params["page"] = (skip // limit) + 1
            else:
                params["page"] = 1

        # Pass through any additional parameters
        for key, value in kwargs.items():
            if value is not None:
                params[key] = value

        return params

    def _parse_response(self, response: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Parse AccessGUDID response format.

        Args:
            response: Raw API response

        Returns:
            List of result items
        """
        # For list endpoints, results are in a 'devices' array
        if "devices" in response:
            return response.get("devices", [])

        # For single-item endpoints, wrap in list
        if "gudid" in response:
            return [response]

        # For parse_udi, the response is the parsed data
        if "udi" in response or "di" in response:
            return [response]

        # For SNOMED responses
        if "concepts" in response:
            return [response]

        # Default: return as single-item list if non-empty
        if response:
            return [response]

        return []

    def _extract_pagination(self, response: dict[str, Any]) -> PaginationInfo:
        """
        Extract pagination information from AccessGUDID response.

        AccessGUDID uses X-Total-Pages, X-Total headers for pagination.
        These are returned in the response metadata for list endpoints.

        Args:
            response: Raw API response

        Returns:
            Pagination metadata
        """
        # For list endpoints, pagination info may be in response metadata
        # AccessGUDID returns pagination in headers, but we don't have access here
        # So we check if there are more results based on response content
        devices = response.get("devices", [])
        total = response.get("total", len(devices))
        page = response.get("page", 1)
        per_page = response.get("per_page", 100)

        has_more = len(devices) >= per_page

        return PaginationInfo(
            total_results=total if isinstance(total, int) else None,
            current_skip=(page - 1) * per_page,
            current_limit=per_page,
            has_more=has_more,
        )

    async def search(
        self,
        endpoint: str | AccessGUDIDEndpoint,
        query: str,
        limit: int = 100,
        max_records: int = 1000,
        **kwargs,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Search an AccessGUDID endpoint with automatic pagination.

        Note: AccessGUDID doesn't have a general search endpoint. This method
        is primarily used for list endpoints (e.g., implantable devices).
        For device lookups, use lookup_device(), parse_udi(), etc.

        Args:
            endpoint: AccessGUDID endpoint
            query: Not used for AccessGUDID
            limit: Results per page (max 100)
            max_records: Maximum total records to return
            **kwargs: Additional parameters

        Yields:
            Individual result items
        """
        # Validate limit (AccessGUDID max is 100)
        if limit > 100:
            logger.warning(f"Limit {limit} exceeds AccessGUDID maximum of 100, using 100")
            limit = 100

        path = self.get_endpoint_path(endpoint)
        page = 1
        fetched = 0

        while fetched < max_records:
            params = self._build_query_params(
                endpoint if isinstance(endpoint, str) else endpoint.value,
                query,
                limit,
                (page - 1) * limit,
                **kwargs,
            )

            logger.debug(f"Fetching {path} (page={page}, per_page={limit}, fetched={fetched}/{max_records})")
            response = await self._get_with_retry(path, params)

            results = self._parse_response(response)
            if not results:
                logger.debug("No more results available")
                break

            for item in results:
                yield item
                fetched += 1
                if fetched >= max_records:
                    logger.debug(f"Reached max_records limit ({max_records})")
                    return

            pagination = self._extract_pagination(response)
            if not pagination.has_more:
                logger.debug("No more pages available")
                break

            page += 1

        logger.info(f"Search complete: fetched {fetched} records")

    async def lookup_device(
        self,
        di: str | None = None,
        udi: str | None = None,
        record_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Look up a device by DI, UDI, or record key.

        At least one identifier must be provided.

        Args:
            di: Device Identifier
            udi: Full Unique Device Identifier (will be URL-encoded)
            record_key: Public Device Record Key

        Returns:
            Device record with full GUDID information

        Raises:
            ValueError: If no identifier provided
            httpx.HTTPError: On HTTP errors

        Example:
            ```python
            # By Device Identifier
            device = await client.lookup_device(di="08717648200274")

            # By UDI (automatically URL-encoded)
            device = await client.lookup_device(
                udi="(01)00844588012919(17)141231(10)A213B1"
            )

            # Access device info
            brand = device.get('gudid', {}).get('device', {}).get('brandName')
            company = device.get('gudid', {}).get('device', {}).get('companyName')
            ```
        """
        if not any([di, udi, record_key]):
            raise ValueError("At least one of di, udi, or record_key must be provided")

        params: dict[str, Any] = {}
        if di:
            params["di"] = di
        if udi:
            params["udi"] = quote(udi, safe="")
        if record_key:
            params["record_key"] = record_key

        path = self.get_endpoint_path(AccessGUDIDEndpoint.DEVICE_LOOKUP)
        logger.debug(f"Looking up device: {params}")

        return await self._get_with_retry(path, params)

    async def parse_udi(self, udi: str) -> dict[str, Any]:
        """
        Parse a UDI string into its components.

        Supports GS1, HIBCC, and ICCBBA UDI formats.

        Args:
            udi: Full Unique Device Identifier string

        Returns:
            Parsed UDI components including:
            - issuingAgency: GS1, HIBCC, or ICCBBA
            - di: Device Identifier
            - serialNumber: Serial number (if present)
            - lotNumber: Lot/batch number (if present)
            - manufacturingDate: Manufacturing date (YYYY-MM-DD, if present)
            - expirationDate: Expiration date (YYYY-MM-DD, if present)
            - donationId: Donation ID (ICCBBA only)
            - mphoLotNumber: MPHO lot number (ICCBBA only)

        Example:
            ```python
            parsed = await client.parse_udi(
                udi="(01)00844588012919(17)141231(10)A213B1"
            )
            print(f"Issuing Agency: {parsed.get('issuingAgency')}")
            print(f"DI: {parsed.get('di')}")
            print(f"Expiration: {parsed.get('expirationDate')}")
            print(f"Lot: {parsed.get('lotNumber')}")
            ```
        """
        params = {"udi": quote(udi, safe="")}
        path = self.get_endpoint_path(AccessGUDIDEndpoint.PARSE_UDI)
        logger.debug(f"Parsing UDI: {udi[:50]}...")

        return await self._get_with_retry(path, params)

    async def get_device_history(
        self,
        di: str | None = None,
        udi: str | None = None,
        record_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Get the version history for a device.

        Returns all historical versions of the device record.

        Args:
            di: Device Identifier
            udi: Full Unique Device Identifier (will be URL-encoded)
            record_key: Public Device Record Key

        Returns:
            Device history with version information

        Raises:
            ValueError: If no identifier provided
            httpx.HTTPError: On HTTP errors

        Example:
            ```python
            history = await client.get_device_history(di="08717648200274")
            for version in history.get('deviceHistory', []):
                print(f"Version {version.get('publicVersionNumber')}: "
                      f"{version.get('publicVersionDate')}")
            ```
        """
        if not any([di, udi, record_key]):
            raise ValueError("At least one of di, udi, or record_key must be provided")

        params: dict[str, Any] = {}
        if di:
            params["di"] = di
        if udi:
            params["udi"] = quote(udi, safe="")
        if record_key:
            params["record_key"] = record_key

        path = self.get_endpoint_path(AccessGUDIDEndpoint.DEVICE_HISTORY)
        logger.debug(f"Getting device history: {params}")

        return await self._get_with_retry(path, params)

    async def get_device_snomed(
        self,
        di: str | None = None,
        udi: str | None = None,
        record_key: str | None = None,
        umls_api_key: str | None = None,
    ) -> dict[str, Any]:
        """
        Get SNOMED CT codes associated with a device.

        Requires a valid UMLS API key.

        Args:
            di: Device Identifier
            udi: Full Unique Device Identifier (will be URL-encoded)
            record_key: Public Device Record Key
            umls_api_key: UMLS API key (uses config key if not provided)

        Returns:
            SNOMED CT concepts for the device

        Raises:
            ValueError: If no identifier or API key provided
            httpx.HTTPError: On HTTP errors

        Example:
            ```python
            # With API key in config
            snomed = await client.get_device_snomed(di="08717648200274")

            # With explicit API key
            snomed = await client.get_device_snomed(
                di="08717648200274",
                umls_api_key="your_key"
            )

            for concept in snomed.get('concepts', []):
                print(f"{concept.get('snomedCTName')}: "
                      f"{concept.get('snomedIdentifier')}")
            ```
        """
        if not any([di, udi, record_key]):
            raise ValueError("At least one of di, udi, or record_key must be provided")

        api_key = umls_api_key or self.config.umls_api_key
        if not api_key:
            raise ValueError("UMLS API key is required for SNOMED lookups")

        params: dict[str, Any] = {"apiKey": api_key}
        if di:
            params["di"] = di
        if udi:
            params["udi"] = quote(udi, safe="")
        if record_key:
            params["record_key"] = record_key

        path = self.get_endpoint_path(AccessGUDIDEndpoint.DEVICE_SNOMED)
        logger.debug(f"Getting device SNOMED: {params.get('di') or params.get('udi', '')[:20]}")

        return await self._get_with_retry(path, params)

    async def list_implantable_devices(
        self,
        from_date: str | None = None,
        to_date: str | None = None,
        per_page: int = 100,
        max_records: int = 1000,
        umls_api_key: str | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        List implantable devices with optional date filtering.

        Returns a paginated list of devices flagged as implantable or
        accessories to implant systems.

        Args:
            from_date: Filter devices updated after this date (inclusive)
            to_date: Filter devices updated before this date (inclusive)
            per_page: Results per page (max 100)
            max_records: Maximum total records to return
            umls_api_key: UMLS API key for SNOMED data (optional)

        Yields:
            Device records with implantable device information

        Example:
            ```python
            # Get recent implantable devices
            async for device in client.list_implantable_devices(
                from_date="2024-01-01",
                max_records=500
            ):
                print(f"{device.get('brandName')} - {device.get('companyName')}")
            ```
        """
        kwargs: dict[str, Any] = {}
        if from_date:
            kwargs["from_date"] = from_date
        if to_date:
            kwargs["to_date"] = to_date

        api_key = umls_api_key or self.config.umls_api_key
        if api_key:
            kwargs["ticket"] = api_key  # Uses 'ticket' parameter for this endpoint

        async for device in self.search(
            endpoint=AccessGUDIDEndpoint.IMPLANTABLE_LIST,
            query="",  # Not used
            limit=per_page,
            max_records=max_records,
            **kwargs,
        ):
            yield device

    # =========================================================================
    # Typed Response Methods (using ashmatics-datamodels integration)
    # =========================================================================

    async def lookup_device_typed(
        self,
        di: str | None = None,
        udi: str | None = None,
        record_key: str | None = None,
    ) -> "DeviceLookupResult":
        """
        Look up a device and return a typed DeviceLookupResult.

        Same as lookup_device() but returns a strongly-typed Pydantic model
        instead of raw JSON.

        Args:
            di: Device Identifier
            udi: Full Unique Device Identifier (will be URL-encoded)
            record_key: Public Device Record Key

        Returns:
            Typed DeviceLookupResult with device and optional parsed UDI

        Example:
            ```python
            result = await client.lookup_device_typed(di="08717648200274")
            print(f"Brand: {result.device.brand_name}")
            print(f"Company: {result.device.company_name}")
            for gmdn in result.device.gmdn_terms:
                print(f"GMDN: {gmdn.gmdn_preferred_term_name}")
            ```
        """
        from .transforms import transform_device_lookup

        raw_response = await self.lookup_device(di=di, udi=udi, record_key=record_key)
        return transform_device_lookup(raw_response)

    async def parse_udi_typed(self, udi: str) -> "ParsedUDI":
        """
        Parse a UDI string and return a typed ParsedUDI.

        Same as parse_udi() but returns a strongly-typed Pydantic model
        instead of raw JSON.

        Args:
            udi: Full Unique Device Identifier string

        Returns:
            Typed ParsedUDI with all parsed components

        Example:
            ```python
            parsed = await client.parse_udi_typed(
                udi="(01)00844588012919(17)141231(10)A213B1"
            )
            print(f"Issuing Agency: {parsed.issuing_agency}")
            print(f"DI: {parsed.di}")
            print(f"Expiration: {parsed.expiration_date}")
            print(f"Lot: {parsed.lot_number}")
            ```
        """
        from .transforms import transform_parsed_udi

        raw_response = await self.parse_udi(udi=udi)
        return transform_parsed_udi(raw_response)

    async def get_device_history_typed(
        self,
        di: str | None = None,
        udi: str | None = None,
        record_key: str | None = None,
    ) -> "DeviceHistory":
        """
        Get device history and return a typed DeviceHistory.

        Same as get_device_history() but returns a strongly-typed Pydantic model
        instead of raw JSON.

        Args:
            di: Device Identifier
            udi: Full Unique Device Identifier (will be URL-encoded)
            record_key: Public Device Record Key

        Returns:
            Typed DeviceHistory with version list

        Example:
            ```python
            history = await client.get_device_history_typed(di="08717648200274")
            for version in history.versions:
                print(f"Version {version.public_version_number}: {version.public_version_date}")
            ```
        """
        from .transforms import transform_device_history

        raw_response = await self.get_device_history(di=di, udi=udi, record_key=record_key)
        return transform_device_history(raw_response)

    async def get_device_snomed_typed(
        self,
        di: str | None = None,
        udi: str | None = None,
        record_key: str | None = None,
        umls_api_key: str | None = None,
    ) -> "DeviceSNOMED":
        """
        Get SNOMED CT codes and return a typed DeviceSNOMED.

        Same as get_device_snomed() but returns a strongly-typed Pydantic model
        instead of raw JSON.

        Args:
            di: Device Identifier
            udi: Full Unique Device Identifier (will be URL-encoded)
            record_key: Public Device Record Key
            umls_api_key: UMLS API key (uses config key if not provided)

        Returns:
            Typed DeviceSNOMED with SNOMED concepts

        Example:
            ```python
            snomed = await client.get_device_snomed_typed(di="08717648200274")
            for concept in snomed.concepts:
                print(f"{concept.snomed_ct_name}: {concept.snomed_identifier}")
            ```
        """
        from .transforms import transform_device_snomed

        raw_response = await self.get_device_snomed(
            di=di, udi=udi, record_key=record_key, umls_api_key=umls_api_key
        )
        return transform_device_snomed(raw_response)

    async def list_implantable_devices_typed(
        self,
        from_date: str | None = None,
        to_date: str | None = None,
        per_page: int = 100,
        max_records: int = 1000,
        umls_api_key: str | None = None,
    ) -> AsyncIterator["ImplantableDevice"]:
        """
        List implantable devices and yield typed ImplantableDevice objects.

        Same as list_implantable_devices() but yields strongly-typed Pydantic models
        instead of raw JSON.

        Args:
            from_date: Filter devices updated after this date (inclusive)
            to_date: Filter devices updated before this date (inclusive)
            per_page: Results per page (max 100)
            max_records: Maximum total records to return
            umls_api_key: UMLS API key for SNOMED data (optional)

        Yields:
            Typed ImplantableDevice objects

        Example:
            ```python
            async for device in client.list_implantable_devices_typed(
                from_date="2024-01-01",
                max_records=100
            ):
                print(f"{device.brand_name} - {device.company_name}")
                print(f"MRI Safety: {device.mri_safety_status}")
            ```
        """
        from .transforms import transform_implantable_device

        async for raw_device in self.list_implantable_devices(
            from_date=from_date,
            to_date=to_date,
            per_page=per_page,
            max_records=max_records,
            umls_api_key=umls_api_key,
        ):
            yield transform_implantable_device(raw_device)


# Type hints for forward references
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import (
        DeviceHistory,
        DeviceLookupResult,
        DeviceSNOMED,
        ImplantableDevice,
        ParsedUDI,
    )
