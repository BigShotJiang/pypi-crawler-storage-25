# Copyright 2025 Asher Informatics PBC
"""OpenFDA API client implementation."""

import logging
from collections.abc import AsyncIterator
from typing import Any

from ashmatics_datamodels.documents.regulatory import (
    RegulatoryDocument,
    RegulatoryMetadataContent,
)

from ..base import BaseAPIClient, PaginationInfo
from .config import OpenFDAConfig, OpenFDAEndpoint

logger = logging.getLogger(__name__)


class OpenFDAClient(BaseAPIClient):
    """
    Client for the OpenFDA API (open.fda.gov).

    Provides access to FDA data including:
    - Device 510(k) clearances, adverse events, recalls
    - Drug labels, adverse events, enforcement actions
    - Food recalls and adverse events

    Features:
    - Automatic pagination
    - Rate limiting (respects FDA API limits)
    - Retry with exponential backoff
    - Supports all major OpenFDA endpoints

    Example:
        ```python
        from ashmatics_tools.external_apis.openfda import OpenFDAClient, OpenFDAConfig

        config = OpenFDAConfig(api_key="your_key")
        async with OpenFDAClient(config) as client:
            # Search for device adverse events
            async for event in client.search(
                endpoint=OpenFDAEndpoint.DEVICE_EVENT,
                query="device_name:pacemaker AND date_received:[20200101 TO 20231231]",
                limit=100
            ):
                print(event)

            # Search 510(k) clearances
            async for clearance in client.search(
                endpoint=OpenFDAEndpoint.DEVICE_510K,
                query="product_code:OZP",
                limit=100
            ):
                print(clearance)
        ```

    OpenFDA Query Syntax:
        - Field search: field:value
        - Exact phrase: field:"exact phrase"
        - Range: field:[min TO max]
        - Date range: date_field:[20200101 TO 20231231]
        - Boolean: AND, OR, NOT
        - Wildcards: field:val*
        - Grouping: (field1:val1 OR field2:val2) AND field3:val3

    See https://open.fda.gov/apis/query-syntax/ for full documentation.
    """

    def __init__(self, config: OpenFDAConfig):
        """Initialize OpenFDA client.

        Args:
            config: OpenFDA configuration
        """
        super().__init__(config)
        self.config: OpenFDAConfig = config  # Type hint for IDE support

    def get_endpoint_path(self, endpoint: str | OpenFDAEndpoint) -> str:
        """
        Get the full API path for an endpoint.

        Args:
            endpoint: Endpoint identifier (string or OpenFDAEndpoint enum)

        Returns:
            Full API path (e.g., "/device/event.json")
        """
        if isinstance(endpoint, OpenFDAEndpoint):
            endpoint = endpoint.value
        return f"/{endpoint}.json"

    def _build_query_params(
        self,
        endpoint: str,
        query: str,
        limit: int,
        skip: int,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Build OpenFDA query parameters.

        Args:
            endpoint: API endpoint (not used, kept for interface compatibility)
            query: OpenFDA search query
            limit: Number of results per page
            skip: Number of results to skip
            **kwargs: Additional parameters (count, sort, etc.)

        Returns:
            Dictionary of query parameters
        """
        params: dict[str, Any] = {
            "search": query,
            "limit": limit,
            "skip": skip,
        }

        # Add API key if available
        if self.config.api_key:
            params["api_key"] = self.config.api_key

        # Add optional parameters
        if "count" in kwargs:
            params["count"] = kwargs["count"]
        if "sort" in kwargs:
            params["sort"] = kwargs["sort"]

        return params

    def _parse_response(self, response: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Parse OpenFDA response format.

        Args:
            response: Raw API response

        Returns:
            List of result items
        """
        return response.get("results", [])

    def _extract_pagination(self, response: dict[str, Any]) -> PaginationInfo:
        """
        Extract pagination information from OpenFDA response.

        OpenFDA responses include metadata like:
        {
            "meta": {
                "disclaimer": "...",
                "terms": "...",
                "license": "...",
                "last_updated": "2023-12-31",
                "results": {
                    "skip": 0,
                    "limit": 100,
                    "total": 50000
                }
            },
            "results": [...]
        }

        Args:
            response: Raw API response

        Returns:
            Pagination metadata
        """
        meta = response.get("meta", {})
        results_meta = meta.get("results", {})

        total = results_meta.get("total")
        skip = results_meta.get("skip", 0)
        limit = results_meta.get("limit", 100)

        # OpenFDA has a hard limit on total results accessible via pagination
        # Usually limited to first 25,000 results (250 pages at 100/page)
        # has_more is true if we haven't reached the total yet
        has_more = total is not None and skip + limit < total

        return PaginationInfo(
            total_results=total, current_skip=skip, current_limit=limit, has_more=has_more
        )

    async def search(
        self,
        endpoint: str | OpenFDAEndpoint,
        query: str,
        limit: int = 100,
        max_records: int = 1000,
        **kwargs,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Search an OpenFDA endpoint with automatic pagination.

        Args:
            endpoint: OpenFDA endpoint to search
            query: OpenFDA search query
            limit: Results per page (max 1000, default 100)
            max_records: Maximum total records to return
            **kwargs: Additional parameters (count, sort, etc.)

        Yields:
            Individual result items

        Raises:
            httpx.HTTPError: On HTTP errors
            RuntimeError: On persistent API errors

        Example:
            ```python
            # Search for device adverse events
            async for event in client.search(
                endpoint=OpenFDAEndpoint.DEVICE_EVENT,
                query="device_name:pacemaker",
                limit=100,
                max_records=1000
            ):
                device_name = event.get("device", {}).get("device_name")
                print(f"Device: {device_name}")

            # Search 510(k) with date range
            async for clearance in client.search(
                endpoint=OpenFDAEndpoint.DEVICE_510K,
                query="decision_date:[20200101 TO 20231231]",
                limit=100
            ):
                print(clearance)
            ```
        """
        # Validate limit (OpenFDA max is 1000)
        if limit > 1000:
            logger.warning(f"Limit {limit} exceeds OpenFDA maximum of 1000, using 1000")
            limit = 1000

        # Get endpoint path
        path = self.get_endpoint_path(endpoint)

        skip = 0
        fetched = 0

        while fetched < max_records:
            # Build query parameters
            params = self._build_query_params(
                endpoint if isinstance(endpoint, str) else endpoint.value,
                query,
                limit,
                skip,
                **kwargs,
            )

            # Make request
            logger.debug(
                f"Fetching {path} (skip={skip}, limit={limit}, fetched={fetched}/{max_records})"
            )
            response = await self._get_with_retry(path, params)

            # Parse results
            results = self._parse_response(response)
            if not results:
                logger.debug("No more results available")
                break

            # Yield results
            for item in results:
                yield item
                fetched += 1
                if fetched >= max_records:
                    logger.debug(f"Reached max_records limit ({max_records})")
                    return

            # Check if more results available
            pagination = self._extract_pagination(response)
            if not pagination.has_more:
                logger.debug("No more pages available")
                break

            # Move to next page
            skip += limit

        logger.info(f"Search complete: fetched {fetched} records")

    async def count(
        self,
        endpoint: str | OpenFDAEndpoint,
        query: str,
        count_field: str,
        **kwargs,
    ) -> list[dict[str, Any]]:
        """
        Perform a count query on an OpenFDA endpoint.

        Count queries return aggregated counts by field value, useful for analytics.

        Args:
            endpoint: OpenFDA endpoint
            query: Search query (use "*" for all)
            count_field: Field to count by
            **kwargs: Additional parameters

        Returns:
            List of count results with 'term' and 'count' fields

        Example:
            ```python
            # Count device events by product code
            counts = await client.count(
                endpoint=OpenFDAEndpoint.DEVICE_EVENT,
                query="date_received:[20230101 TO 20231231]",
                count_field="device.openfda.device_class.exact"
            )
            for item in counts:
                print(f"{item['term']}: {item['count']}")
            ```
        """
        path = self.get_endpoint_path(endpoint)
        params = {
            "search": query,
            "count": count_field,
        }

        if self.config.api_key:
            params["api_key"] = self.config.api_key

        # Add any additional parameters
        params.update(kwargs)

        logger.debug(f"Count query: {path} by {count_field}")
        response = await self._get_with_retry(path, params)

        # Count queries return results in a different format
        return response.get("results", [])

    async def search_510k_typed(
        self,
        query: str,
        limit: int = 100,
        max_records: int = 1000,
        **kwargs,
    ) -> AsyncIterator[RegulatoryMetadataContent]:
        """
        Search 510(k) clearances with typed responses.

        Returns RegulatoryMetadataContent objects instead of raw dictionaries.
        This provides type safety and validation using ashmatics-datamodels schemas.

        Args:
            query: OpenFDA search query
            limit: Results per page (max 1000, default 100)
            max_records: Maximum total records to return
            **kwargs: Additional parameters

        Yields:
            RegulatoryMetadataContent objects for each 510(k) clearance

        Example:
            ```python
            async with client:
                async for metadata in client.search_510k_typed(
                    query="product_code:OZP",
                    limit=100
                ):
                    print(f"K-Number: {metadata.k_number}")
                    print(f"Device: {metadata.device_name}")
                    print(f"Clearance Date: {metadata.clearance_date}")
            ```
        """
        from .transforms import transform_510k_to_regulatory_metadata

        async for raw_record in self.search(
            endpoint=OpenFDAEndpoint.DEVICE_510K,
            query=query,
            limit=limit,
            max_records=max_records,
            **kwargs,
        ):
            try:
                yield transform_510k_to_regulatory_metadata(raw_record)
            except Exception as e:
                logger.warning(f"Failed to transform 510(k) record: {e}", exc_info=True)
                continue

    async def search_510k_documents(
        self,
        query: str,
        limit: int = 100,
        max_records: int = 1000,
        **kwargs,
    ) -> AsyncIterator[RegulatoryDocument]:
        """
        Search 510(k) clearances with full document objects.

        Returns complete RegulatoryDocument objects ready for MongoDB storage.

        Args:
            query: OpenFDA search query
            limit: Results per page (max 1000, default 100)
            max_records: Maximum total records to return
            **kwargs: Additional parameters

        Yields:
            RegulatoryDocument objects for each 510(k) clearance

        Example:
            ```python
            async with client:
                async for doc in client.search_510k_documents(
                    query="product_code:OZP",
                    limit=100
                ):
                    # Store in MongoDB
                    await mongodb_collection.insert_one(doc.model_dump(by_alias=True))
            ```
        """
        from .transforms import transform_510k_to_regulatory_document

        async for raw_record in self.search(
            endpoint=OpenFDAEndpoint.DEVICE_510K,
            query=query,
            limit=limit,
            max_records=max_records,
            **kwargs,
        ):
            try:
                yield transform_510k_to_regulatory_document(raw_record)
            except Exception as e:
                logger.warning(f"Failed to transform 510(k) document: {e}", exc_info=True)
                continue

    async def search_pma_typed(
        self,
        query: str,
        limit: int = 100,
        max_records: int = 1000,
        **kwargs,
    ) -> AsyncIterator[RegulatoryMetadataContent]:
        """
        Search PMA approvals with typed responses.

        Returns RegulatoryMetadataContent objects instead of raw dictionaries.

        Args:
            query: OpenFDA search query
            limit: Results per page (max 1000, default 100)
            max_records: Maximum total records to return
            **kwargs: Additional parameters

        Yields:
            RegulatoryMetadataContent objects for each PMA approval

        Example:
            ```python
            async with client:
                async for metadata in client.search_pma_typed(
                    query="product_code:NLX",
                    limit=100
                ):
                    print(f"PMA Number: {metadata.pma_number}")
                    print(f"Device: {metadata.device_name}")
            ```
        """
        from .transforms import transform_pma_to_regulatory_metadata

        async for raw_record in self.search(
            endpoint=OpenFDAEndpoint.DEVICE_PMA,
            query=query,
            limit=limit,
            max_records=max_records,
            **kwargs,
        ):
            try:
                yield transform_pma_to_regulatory_metadata(raw_record)
            except Exception as e:
                logger.warning(f"Failed to transform PMA record: {e}", exc_info=True)
                continue
