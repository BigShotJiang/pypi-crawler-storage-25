# Copyright 2025 Asher Informatics PBC
"""OpenFDA API configuration and endpoint definitions."""

from dataclasses import dataclass, field
from enum import Enum

from ..base import BaseAPIConfig, RateLimitConfig


class OpenFDAEndpoint(str, Enum):
    """OpenFDA API endpoints.

    See https://open.fda.gov/apis/ for full documentation.
    """

    # Animal & Veterinary
    ANIMAL_EVENT = "animalandveterinary/event"  # Adverse event reports

    # Device
    DEVICE_510K = "device/510k"  # 510(k) clearances
    DEVICE_CLASS = "device/classification"  # Device classification
    DEVICE_COVID19_SEROLOGICAL = "device/covid19serology"  # COVID-19 serological testing
    DEVICE_ENFORCEMENT = "device/enforcement"  # Enforcement reports
    DEVICE_EVENT = "device/event"  # Adverse event reports
    DEVICE_PMA = "device/pma"  # Premarket approval
    DEVICE_RECALL = "device/recall"  # Recall reports
    DEVICE_REGISTRATION = "device/registrationlisting"  # Registration and listing
    DEVICE_UDI = "device/udi"  # Unique Device Identifier

    # Drug
    DRUG_ADVERSE_EVENT = "drug/event"  # Adverse event reports (FAERS)
    DRUG_LABEL = "drug/label"  # Drug labeling (SPL)
    DRUG_NDC = "drug/ndc"  # National Drug Code directory
    DRUG_ENFORCEMENT = "drug/enforcement"  # Enforcement reports
    DRUG_RECALL = "drug/drugsfda"  # Drugs@FDA

    # Food
    FOOD_ENFORCEMENT = "food/enforcement"  # Enforcement reports
    FOOD_EVENT = "food/event"  # Adverse event reports

    # Other
    OTHER_NSDE = "other/nsde"  # NSDE (Non-Steroidal Anti-Inflammatory Drug)
    OTHER_SUBSTANCE = "other/substance"  # Substance data


@dataclass
class OpenFDAConfig(BaseAPIConfig):
    """
    Configuration for OpenFDA API client.

    The OpenFDA API has different rate limits depending on API key usage:
    - With API key: 240 requests/minute (4 requests/second)
    - Without API key: 40 requests/minute (0.67 requests/second)

    Attributes:
        api_key: OpenFDA API key (get from https://open.fda.gov/apis/authentication/)
        base_url: OpenFDA API base URL (default: https://api.fda.gov)
        timeout: Request timeout in seconds
        max_retries: Maximum retry attempts
        retry_delay: Initial retry delay in seconds
        rate_limit: Rate limiting configuration
        verify_ssl: Verify SSL certificates
        extra_headers: Additional HTTP headers

    Example:
        ```python
        # With API key (recommended for production)
        config = OpenFDAConfig(api_key="your_api_key_here")

        # Without API key (limited rate)
        config = OpenFDAConfig()

        # Custom rate limiting
        config = OpenFDAConfig(
            api_key="key",
            rate_limit=RateLimitConfig(
                requests_per_second=3.0,
                burst_size=10
            )
        )
        ```
    """

    base_url: str = "https://api.fda.gov"
    api_key: str | None = None

    # Default rate limiting based on API key presence
    # Will be set in __post_init__ if not explicitly provided
    rate_limit: RateLimitConfig = field(default=None)  # type: ignore

    def __post_init__(self):
        """Set default rate limiting based on API key presence."""
        # Set default rate limit if not provided
        if self.rate_limit is None:
            if self.api_key:
                # With API key: 240 requests/minute = 4 requests/second
                self.rate_limit = RateLimitConfig(
                    requests_per_second=3.5,  # Slightly below limit for safety
                    burst_size=10,
                    use_rate_limiting=True,
                )
            else:
                # Without API key: 40 requests/minute = 0.67 requests/second
                self.rate_limit = RateLimitConfig(
                    requests_per_second=0.6,  # Slightly below limit for safety
                    burst_size=3,
                    use_rate_limiting=True,
                )

        # Call parent validation
        super().__post_init__()
