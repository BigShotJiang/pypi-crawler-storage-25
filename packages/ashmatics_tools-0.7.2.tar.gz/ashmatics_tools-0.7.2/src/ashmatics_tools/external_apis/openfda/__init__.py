# Copyright 2025 Asher Informatics PBC
"""OpenFDA API client for ashmatics-tools.

This module provides a client for the US FDA Open Data Portal (open.fda.gov).
It includes:
- Support for all major OpenFDA endpoints (device, drug, food, etc.)
- Automatic retry with exponential backoff
- Rate limiting (240 requests/minute with API key, 40/minute without)
- Pagination handling
- Integration with ashmatics-datamodels vocabulary
- Transformation utilities for converting API responses to typed models

Example usage:
    ```python
    from ashmatics_tools.external_apis.openfda import (
        OpenFDAClient,
        OpenFDAConfig,
        OpenFDAEndpoint,
        transform_510k_to_regulatory_document
    )

    # Create client with API key
    config = OpenFDAConfig(api_key="your_key")
    client = OpenFDAClient(config)

    # Search for 510(k) clearances with typed responses
    async with client:
        async for fda_record in client.search(
            endpoint=OpenFDAEndpoint.DEVICE_510K,
            query="product_code:OZP",
            limit=100
        ):
            # Transform to typed document
            doc = transform_510k_to_regulatory_document(fda_record)
            print(f"K-Number: {doc.metadata_content.k_number}")
    ```
"""

from .client import OpenFDAClient
from .config import OpenFDAConfig, OpenFDAEndpoint
from .transforms import (
    extract_predicates,
    parse_fda_date,
    transform_510k_to_regulatory_document,
    transform_510k_to_regulatory_metadata,
    transform_pma_to_regulatory_metadata,
)

__all__ = [
    "OpenFDAClient",
    "OpenFDAConfig",
    "OpenFDAEndpoint",
    # Transformation utilities
    "parse_fda_date",
    "extract_predicates",
    "transform_510k_to_regulatory_metadata",
    "transform_510k_to_regulatory_document",
    "transform_pma_to_regulatory_metadata",
]
