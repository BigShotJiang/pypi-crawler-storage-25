# Copyright 2025 Asher Informatics PBC
"""
Transformation utilities for converting OpenFDA API responses to ashmatics-datamodels.

This module provides functions to transform raw OpenFDA JSON responses into
strongly-typed Pydantic models from the ashmatics-datamodels package.
"""

import logging
from datetime import date, datetime
from typing import Any, Optional

from ashmatics_datamodels.documents.regulatory import (
    PredicateDeviceInfo,
    RegulatoryDocument,
    RegulatoryMetadataContent,
)

logger = logging.getLogger(__name__)


def parse_fda_date(date_str: Optional[str]) -> Optional[date]:
    """
    Parse FDA date strings (YYYYMMDD format) to Python date.

    Args:
        date_str: FDA date string in YYYYMMDD format

    Returns:
        Python date object or None if parsing fails

    Example:
        >>> parse_fda_date("20240115")
        date(2024, 1, 15)
    """
    if not date_str:
        return None

    try:
        # FDA dates are typically YYYYMMDD
        if len(date_str) == 8 and date_str.isdigit():
            return datetime.strptime(date_str, "%Y%m%d").date()
        # Sometimes with dashes
        elif "-" in date_str:
            return datetime.strptime(date_str, "%Y-%m-%d").date()
    except (ValueError, AttributeError) as e:
        logger.warning(f"Failed to parse FDA date '{date_str}': {e}")
        return None

    return None


def extract_predicates(fda_response: dict[str, Any]) -> list[PredicateDeviceInfo]:
    """
    Extract predicate device information from FDA 510(k) response.

    Args:
        fda_response: Raw OpenFDA 510(k) response

    Returns:
        List of predicate device info objects

    Example:
        >>> predicates = extract_predicates(fda_510k_record)
    """
    predicates = []

    # OpenFDA stores predicates in various fields
    # Try to extract from known locations
    predicate_data = fda_response.get("k_number_predicate", [])
    if isinstance(predicate_data, str):
        predicate_data = [predicate_data]

    for k_num in predicate_data:
        if k_num:
            predicates.append(
                PredicateDeviceInfo(
                    k_number=k_num,
                    device_name=None,  # Not always available in API
                    manufacturer=None,
                    comparison_summary=None,
                )
            )

    return predicates


def transform_510k_to_regulatory_metadata(
    fda_510k: dict[str, Any],
) -> RegulatoryMetadataContent:
    """
    Transform OpenFDA 510(k) response to RegulatoryMetadataContent.

    Maps OpenFDA field names to ashmatics-datamodels regulatory metadata schema.

    Args:
        fda_510k: Raw OpenFDA 510(k) clearance record

    Returns:
        Typed RegulatoryMetadataContent object

    OpenFDA Field Mapping:
        - k_number → k_number
        - decision_date → clearance_date
        - applicant → applicant
        - device_name → device_name
        - device_class → device_class
        - product_code → product_code
        - advisory_committee → advisory_committee

    Example:
        ```python
        async with client:
            async for fda_record in client.search(
                endpoint=OpenFDAEndpoint.DEVICE_510K,
                query="product_code:OZP",
                limit=10
            ):
                metadata = transform_510k_to_regulatory_metadata(fda_record)
                print(f"K-Number: {metadata.k_number}")
        ```
    """
    # Extract OpenFDA fields
    k_number = fda_510k.get("k_number")
    decision_date_str = fda_510k.get("decision_date")
    applicant = fda_510k.get("applicant")
    device_name = fda_510k.get("device_name")

    # Parse clearance date
    clearance_date = parse_fda_date(decision_date_str)

    # Extract device classification info
    # OpenFDA may nest this in openfda object
    openfda = fda_510k.get("openfda", {})
    device_class = fda_510k.get("device_class") or (
        openfda.get("device_class", [None])[0] if openfda.get("device_class") else None
    )
    product_code = fda_510k.get("product_code")

    # Advisory committee code
    advisory_committee = fda_510k.get("advisory_committee") or (
        openfda.get("medical_specialty_description", [None])[0]
        if openfda.get("medical_specialty_description")
        else None
    )

    # Create metadata object
    return RegulatoryMetadataContent(
        k_number=k_number,
        clearance_date=clearance_date,
        applicant=applicant,
        device_name=device_name,
        device_class=device_class,
        product_code=product_code,
        advisory_committee=advisory_committee,
        title=device_name or f"510(k) {k_number}" if k_number else "510(k) Summary",
    )


def transform_510k_to_regulatory_document(
    fda_510k: dict[str, Any],
) -> RegulatoryDocument:
    """
    Transform complete OpenFDA 510(k) response to RegulatoryDocument.

    Creates a full regulatory document with metadata and content sections.
    This is useful for storing FDA data in MongoDB using the standardized schema.

    Args:
        fda_510k: Raw OpenFDA 510(k) clearance record

    Returns:
        Complete RegulatoryDocument ready for MongoDB storage

    Example:
        ```python
        from ashmatics_tools.external_apis import create_api_client, OpenFDAConfig
        from ashmatics_tools.external_apis.openfda import transform_510k_to_regulatory_document

        config = OpenFDAConfig(api_key="your_key")
        async with create_api_client("openfda", config) as client:
            async for fda_record in client.search(
                endpoint=OpenFDAEndpoint.DEVICE_510K,
                query="product_code:OZP",
                limit=10
            ):
                # Transform to typed document
                doc = transform_510k_to_regulatory_document(fda_record)

                # Store in MongoDB
                await mongodb_collection.insert_one(doc.model_dump(by_alias=True))
        ```
    """
    from ashmatics_datamodels.documents.regulatory import (
        PredicatesSection,
        RegulatoryContent,
    )

    # Transform metadata
    metadata = transform_510k_to_regulatory_metadata(fda_510k)

    # Extract predicates for content
    predicates = extract_predicates(fda_510k)

    # Create content with predicates section
    content = RegulatoryContent()
    if predicates:
        content.sections["3_predicate_devices"] = PredicatesSection(
            title="Predicate Devices",
            order=3,
            predicates=predicates,
        )

    # Create complete document
    return RegulatoryDocument(
        metadata_content=metadata,
        content=content,
    )


def transform_pma_to_regulatory_metadata(fda_pma: dict[str, Any]) -> RegulatoryMetadataContent:
    """
    Transform OpenFDA PMA response to RegulatoryMetadataContent.

    Maps OpenFDA PMA field names to ashmatics-datamodels regulatory metadata schema.

    Args:
        fda_pma: Raw OpenFDA PMA approval record

    Returns:
        Typed RegulatoryMetadataContent object

    OpenFDA Field Mapping:
        - pma_number → pma_number
        - decision_date → clearance_date
        - applicant → applicant
        - product_code → product_code
    """
    pma_number = fda_pma.get("pma_number")
    decision_date_str = fda_pma.get("decision_date")
    applicant = fda_pma.get("applicant")

    # Parse clearance date
    clearance_date = parse_fda_date(decision_date_str)

    # Extract device info
    openfda = fda_pma.get("openfda", {})
    device_name = fda_pma.get("trade_name") or (
        openfda.get("device_name", [None])[0] if openfda.get("device_name") else None
    )
    product_code = fda_pma.get("product_code")
    device_class = openfda.get("device_class", [None])[0] if openfda.get("device_class") else None

    # Create metadata object
    return RegulatoryMetadataContent(
        pma_number=pma_number,
        clearance_date=clearance_date,
        applicant=applicant,
        device_name=device_name,
        device_class=device_class or "III",  # PMAs are typically Class III
        product_code=product_code,
        title=device_name or f"PMA {pma_number}" if pma_number else "PMA Summary",
    )


# Export all transformation functions
__all__ = [
    "parse_fda_date",
    "extract_predicates",
    "transform_510k_to_regulatory_metadata",
    "transform_510k_to_regulatory_document",
    "transform_pma_to_regulatory_metadata",
]
