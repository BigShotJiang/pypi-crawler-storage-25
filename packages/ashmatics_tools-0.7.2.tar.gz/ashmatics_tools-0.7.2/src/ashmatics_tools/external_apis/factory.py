# Copyright 2025 Asher Informatics PBC
"""Factory functions for creating external API clients.

This module provides a registry-based factory pattern for creating API clients,
similar to the LLM and storage modules.
"""

import logging
from typing import Any, Type

from .base import APIProvider, BaseAPIClient, BaseAPIConfig

logger = logging.getLogger(__name__)

# Global registries for API providers and their configurations
_API_REGISTRY: dict[str, Type[BaseAPIClient]] = {}
_CONFIG_REGISTRY: dict[str, Type[BaseAPIConfig]] = {}


def register_api_provider(
    provider: str,
    client_class: Type[BaseAPIClient],
    config_class: Type[BaseAPIConfig] | None = None,
) -> None:
    """
    Register a new API provider.

    This allows adding custom API clients at runtime.

    Args:
        provider: Provider identifier (e.g., "openfda", "census")
        client_class: API client class (must extend BaseAPIClient)
        config_class: Configuration class (must extend BaseAPIConfig)

    Example:
        ```python
        class CustomAPIClient(BaseAPIClient):
            pass

        @dataclass
        class CustomAPIConfig(BaseAPIConfig):
            pass

        register_api_provider("custom", CustomAPIClient, CustomAPIConfig)
        ```
    """
    if not issubclass(client_class, BaseAPIClient):
        raise TypeError(f"client_class must extend BaseAPIClient, got {client_class}")

    if config_class is not None and not issubclass(config_class, BaseAPIConfig):
        raise TypeError(f"config_class must extend BaseAPIConfig, got {config_class}")

    _API_REGISTRY[provider] = client_class
    if config_class is not None:
        _CONFIG_REGISTRY[provider] = config_class

    logger.info(f"Registered API provider: {provider}")


def unregister_api_provider(provider: str) -> None:
    """
    Unregister an API provider.

    Args:
        provider: Provider identifier to remove
    """
    _API_REGISTRY.pop(provider, None)
    _CONFIG_REGISTRY.pop(provider, None)
    logger.info(f"Unregistered API provider: {provider}")


def list_api_providers() -> list[str]:
    """
    List all registered API providers.

    Returns:
        List of provider identifiers
    """
    return list(_API_REGISTRY.keys())


def get_config_class(provider: str) -> Type[BaseAPIConfig] | None:
    """
    Get the configuration class for a provider.

    Args:
        provider: Provider identifier

    Returns:
        Configuration class or None if not registered
    """
    return _CONFIG_REGISTRY.get(provider)


def create_api_client(provider: str | APIProvider, config: Any) -> BaseAPIClient:
    """
    Create an API client for the specified provider.

    Args:
        provider: API provider identifier (e.g., "openfda", "census")
        config: Provider-specific configuration object

    Returns:
        Initialized API client

    Raises:
        ValueError: If provider is not registered

    Example:
        ```python
        from ashmatics_tools.external_apis import create_api_client, OpenFDAConfig

        config = OpenFDAConfig(api_key="your_key")
        client = create_api_client("openfda", config)

        async with client:
            async for result in client.search("device", "implant"):
                print(result)
        ```
    """
    # Convert enum to string if needed
    if isinstance(provider, APIProvider):
        provider = provider.value

    if provider not in _API_REGISTRY:
        available = ", ".join(_API_REGISTRY.keys())
        raise ValueError(
            f"Unknown API provider: {provider}. Available providers: {available}"
        )

    client_class = _API_REGISTRY[provider]
    logger.info(f"Creating {provider} API client")
    return client_class(config)
