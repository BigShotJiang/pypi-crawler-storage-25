# Copyright 2025 Asher Informatics PBC
"""Abstract base classes for external API clients.

This module defines the common interface for all external API clients,
including retry logic, rate limiting, pagination, and error handling.
"""

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class APIProvider(str, Enum):
    """Supported external API providers."""

    OPENFDA = "openfda"  # US FDA Open Data Portal
    ACCESSGUDID = "accessgudid"  # NIH/FDA AccessGUDID Device Database
    CENSUS = "census"  # US Census Bureau API (reserved for future)
    CMS = "cms"  # Centers for Medicare & Medicaid Services (reserved for future)


@dataclass
class RateLimitConfig:
    """Rate limiting configuration for API clients."""

    # Rate limit settings
    requests_per_second: float = 1.0  # Max requests per second
    burst_size: int = 5  # Max burst requests
    use_rate_limiting: bool = True  # Enable client-side rate limiting

    # Token bucket state (initialized at runtime)
    _tokens: float = field(default=0.0, init=False, repr=False)
    _last_update: float = field(default=0.0, init=False, repr=False)

    def __post_init__(self):
        """Initialize token bucket."""
        self._tokens = float(self.burst_size)
        self._last_update = time.monotonic()

    async def acquire(self) -> None:
        """Acquire a token from the rate limiter (blocks if necessary)."""
        if not self.use_rate_limiting:
            return

        now = time.monotonic()
        elapsed = now - self._last_update
        self._last_update = now

        # Add tokens based on elapsed time
        self._tokens = min(
            self.burst_size, self._tokens + elapsed * self.requests_per_second
        )

        # Wait if no tokens available
        if self._tokens < 1.0:
            wait_time = (1.0 - self._tokens) / self.requests_per_second
            logger.debug(f"Rate limit: waiting {wait_time:.2f}s")
            await asyncio.sleep(wait_time)
            self._tokens = 0.0
        else:
            self._tokens -= 1.0


@dataclass
class PaginationInfo:
    """Pagination metadata for API responses."""

    total_results: int | None = None  # Total number of results available
    current_skip: int = 0  # Current offset
    current_limit: int = 100  # Current page size
    has_more: bool = True  # Whether more results are available


@dataclass
class BaseAPIConfig:
    """
    Base configuration for external API clients.

    Attributes:
        base_url: API base URL
        api_key: API key for authentication (optional)
        timeout: Request timeout in seconds
        max_retries: Maximum number of retry attempts
        retry_delay: Initial delay between retries (exponential backoff)
        rate_limit: Rate limiting configuration
        verify_ssl: Whether to verify SSL certificates
        extra_headers: Additional HTTP headers
    """

    base_url: str
    api_key: str | None = None
    timeout: float = 30.0
    max_retries: int = 5
    retry_delay: float = 1.0
    rate_limit: RateLimitConfig = field(default_factory=RateLimitConfig)
    verify_ssl: bool = True
    extra_headers: dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        """Validate configuration."""
        if self.timeout <= 0:
            raise ValueError("timeout must be positive")
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if self.retry_delay < 0:
            raise ValueError("retry_delay must be non-negative")
        if not self.verify_ssl:
            logger.warning("SSL verification is disabled - use only in development")


class BaseAPIClient(ABC):
    """
    Abstract base class for external API clients.

    Provides common functionality for:
    - HTTP request handling with httpx
    - Retry logic with exponential backoff
    - Rate limiting
    - Error handling
    - Pagination support

    Subclasses must implement:
    - _build_query_params(): Build provider-specific query parameters
    - _parse_response(): Parse provider-specific response format
    - _extract_pagination(): Extract pagination info from response
    """

    def __init__(self, config: BaseAPIConfig):
        """Initialize API client with configuration.

        Args:
            config: API client configuration
        """
        self.config = config
        self._client: httpx.AsyncClient | None = None
        self._closed = False

    async def __aenter__(self) -> "BaseAPIClient":
        """Async context manager entry."""
        await self._ensure_client()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()

    async def _ensure_client(self) -> None:
        """Ensure httpx client is initialized."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.config.base_url,
                timeout=self.config.timeout,
                verify=self.config.verify_ssl,
                headers=self.config.extra_headers,
            )

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None and not self._closed:
            await self._client.aclose()
            self._closed = True
            self._client = None  # Reset so _ensure_client can create a new one
        # Reset _closed so we can reopen
        self._closed = False

    async def _get_with_retry(
        self, path: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Execute GET request with retry logic and rate limiting.

        Args:
            path: API endpoint path
            params: Query parameters

        Returns:
            Parsed JSON response

        Raises:
            httpx.HTTPError: On persistent HTTP errors
            RuntimeError: On quota exceeded or persistent rate limit errors
        """
        await self._ensure_client()
        assert self._client is not None

        for attempt in range(self.config.max_retries):
            try:
                # Apply rate limiting
                await self.config.rate_limit.acquire()

                # Make request
                logger.debug(f"GET {path} (attempt {attempt + 1}/{self.config.max_retries})")
                response = await self._client.get(path, params=params)

                # Handle rate limiting
                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", "1"))
                    wait_time = retry_after or (2**attempt * self.config.retry_delay)
                    logger.warning(f"Rate limited, waiting {wait_time}s before retry")
                    await asyncio.sleep(wait_time)
                    continue

                # Handle server errors with retry
                if response.status_code >= 500:
                    wait_time = 2**attempt * self.config.retry_delay
                    logger.warning(
                        f"Server error {response.status_code}, waiting {wait_time}s before retry"
                    )
                    await asyncio.sleep(wait_time)
                    continue

                # Raise for other HTTP errors
                response.raise_for_status()
                return response.json()

            except httpx.HTTPError as e:
                if attempt == self.config.max_retries - 1:
                    logger.error(f"HTTP request failed after {self.config.max_retries} attempts")
                    raise
                wait_time = 2**attempt * self.config.retry_delay
                logger.warning(f"HTTP error: {e}, waiting {wait_time}s before retry")
                await asyncio.sleep(wait_time)

        raise RuntimeError("API request failed after maximum retries")

    @abstractmethod
    def _build_query_params(
        self, endpoint: str, query: str, limit: int, skip: int, **kwargs
    ) -> dict[str, Any]:
        """
        Build provider-specific query parameters.

        Args:
            endpoint: API endpoint identifier
            query: Search query
            limit: Number of results per page
            skip: Number of results to skip
            **kwargs: Additional provider-specific parameters

        Returns:
            Dictionary of query parameters
        """
        pass

    @abstractmethod
    def _parse_response(self, response: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Parse provider-specific response format.

        Args:
            response: Raw API response

        Returns:
            List of result items
        """
        pass

    @abstractmethod
    def _extract_pagination(self, response: dict[str, Any]) -> PaginationInfo:
        """
        Extract pagination information from response.

        Args:
            response: Raw API response

        Returns:
            Pagination metadata
        """
        pass

    @abstractmethod
    async def search(
        self,
        endpoint: str,
        query: str,
        limit: int = 100,
        max_records: int = 1000,
        **kwargs,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Search API endpoint with automatic pagination.

        Args:
            endpoint: API endpoint to search
            query: Search query
            limit: Results per page
            max_records: Maximum total results to return
            **kwargs: Additional provider-specific parameters

        Yields:
            Individual result items
        """
        pass

    @abstractmethod
    def get_endpoint_path(self, endpoint: str) -> str:
        """
        Get the full API path for an endpoint.

        Args:
            endpoint: Endpoint identifier

        Returns:
            Full API path
        """
        pass
