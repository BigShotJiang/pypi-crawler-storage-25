"""Export data from the Ashmatics Knowledge Base to JSON files for backup.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import json
import logging
import os
from datetime import datetime
from pathlib import Path

import httpx
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Load environment variables from .env file if it exists
dotenv_path = Path.cwd() / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)


class DataExporter:
    """
    Knowledge Base Data Exporter for backing up data from Hasura GraphQL API.

    Provides methods for exporting table data to JSON files with schema introspection.
    """

    def __init__(
        self,
        graphql_endpoint: str | None = None,
        admin_secret: str | None = None,
        verify_ssl: bool = True,
        output_dir: str | None = None,
    ):
        """
        Initialize the Data Exporter with API endpoints and authentication.

        Args:
            graphql_endpoint: The Hasura GraphQL endpoint (default: from HASURA_GRAPHQL_ENDPOINT env)
            admin_secret: The Hasura admin secret (default: from HASURA_ADMIN_SECRET env)
            verify_ssl: Whether to verify SSL certificates (default: True)
            output_dir: Directory to save exported files (default: ./exports)

        Raises:
            ValueError: If required configuration is missing
        """
        graphql_endpoint_str = graphql_endpoint or os.getenv("HASURA_GRAPHQL_ENDPOINT")
        admin_secret_str = admin_secret or os.getenv("HASURA_ADMIN_SECRET")

        if not graphql_endpoint_str:
            raise ValueError(
                "GraphQL endpoint required. Provide via graphql_endpoint parameter "
                "or HASURA_GRAPHQL_ENDPOINT environment variable."
            )

        if not admin_secret_str:
            raise ValueError(
                "Admin secret required. Provide via admin_secret parameter "
                "or HASURA_ADMIN_SECRET environment variable."
            )

        self.graphql_endpoint: str = graphql_endpoint_str
        self.admin_secret: str = admin_secret_str
        self.verify_ssl = verify_ssl
        self.output_dir = Path(output_dir) if output_dir else Path.cwd() / "exports"

        # Log warning if SSL verification is disabled
        if not verify_ssl:
            logger.warning(
                "SSL certificate verification is DISABLED. "
                "This is insecure and should only be used in development/testing."
            )

        self.headers = {
            "Content-Type": "application/json",
            "X-Hasura-Admin-Secret": self.admin_secret,
        }

        logger.info(
            f"Initialized DataExporter (endpoint: {self.graphql_endpoint}, "
            f"SSL: {verify_ssl}, output: {self.output_dir})"
        )

    def get_table_columns(self, table_name: str) -> list[str] | None:
        """
        Get column names for a table using GraphQL introspection.

        Args:
            table_name: Name of the table

        Returns:
            List of column names, or None if introspection fails
        """
        introspection_query = """
        query get_columns($table_name: String!) {
          __type(name: $table_name) {
            fields {
              name
            }
          }
        }
        """

        variables = {"table_name": table_name}

        try:
            response = httpx.post(
                self.graphql_endpoint,
                headers=self.headers,
                json={"query": introspection_query, "variables": variables},
                verify=self.verify_ssl,
                timeout=30,
            )

            if response.status_code != 200 or "errors" in response.json():
                logger.error(f"Failed to get columns for table {table_name}: {response.text}")
                return None

            data = response.json().get("data", {}).get("__type", {}).get("fields", [])

            if not data:
                logger.warning(f"No column information found for table {table_name}")
                return ["id"]  # Fallback to just ID

            columns = [field["name"] for field in data]
            logger.debug(f"Found {len(columns)} columns for table {table_name}")
            return columns

        except Exception as e:
            logger.error(f"Error getting columns for {table_name}: {str(e)}", exc_info=True)
            return None

    def export_table(
        self,
        table_name: str,
        limit: int = 1000,
        offset: int = 0,
        output_file: str | None = None,
    ) -> Path | None:
        """
        Export data from a table to a JSON file.

        Args:
            table_name: Name of the table to export
            limit: Maximum number of records to export (default: 1000)
            offset: Number of records to skip (default: 0)
            output_file: Custom output filename (default: auto-generated with timestamp)

        Returns:
            Path to the exported JSON file, or None if export fails
        """
        try:
            # Create exports directory if it doesn't exist
            self.output_dir.mkdir(parents=True, exist_ok=True)

            # Generate filename with timestamp if not provided
            if output_file:
                file_path = self.output_dir / output_file
            else:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{table_name}_{timestamp}.json"
                file_path = self.output_dir / filename

            # Get column names via introspection
            columns = self.get_table_columns(table_name)
            if not columns:
                logger.error(f"Could not determine columns for table {table_name}")
                return None

            # Build the query with all columns
            column_list = " ".join(columns)
            query = f"""
            query get_{table_name} {{
              {table_name}(limit: {limit}, offset: {offset}) {{
                {column_list}
              }}
            }}
            """

            logger.info(f"Exporting {table_name} (limit: {limit}, offset: {offset})...")

            # Execute the query
            response = httpx.post(
                self.graphql_endpoint,
                headers=self.headers,
                json={"query": query},
                verify=self.verify_ssl,
                timeout=60,
            )

            if response.status_code != 200:
                logger.error(f"Failed to export {table_name}: {response.text}")
                return None

            data = response.json()

            if "errors" in data:
                logger.error(f"GraphQL errors while exporting {table_name}: {data['errors']}")
                return None

            records = data.get("data", {}).get(table_name, [])

            if not records:
                logger.warning(f"No records found in table {table_name}")

            # Write records to JSON file
            with open(file_path, "w") as f:
                json.dump(records, f, indent=2)

            logger.info(f"Exported {len(records)} records from {table_name} to {file_path}")
            return file_path

        except Exception as e:
            logger.error(f"Error exporting {table_name}: {str(e)}", exc_info=True)
            return None

    def export_table_all(
        self,
        table_name: str,
        batch_size: int = 1000,
    ) -> Path | None:
        """
        Export all data from a table in batches.

        Args:
            table_name: Name of the table to export
            batch_size: Number of records per batch (default: 1000)

        Returns:
            Path to the exported JSON file, or None if export fails
        """
        try:
            all_records = []
            offset = 0
            batch_number = 1

            # Create output directory
            self.output_dir.mkdir(parents=True, exist_ok=True)

            # Generate filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{table_name}_full_{timestamp}.json"
            file_path = self.output_dir / filename

            # Get columns
            columns = self.get_table_columns(table_name)
            if not columns:
                logger.error(f"Could not determine columns for table {table_name}")
                return None

            column_list = " ".join(columns)

            logger.info(f"Starting full export of {table_name}...")

            while True:
                logger.info(f"Fetching batch {batch_number} (offset: {offset})...")

                query = f"""
                query get_{table_name} {{
                  {table_name}(limit: {batch_size}, offset: {offset}) {{
                    {column_list}
                  }}
                }}
                """

                response = httpx.post(
                    self.graphql_endpoint,
                    headers=self.headers,
                    json={"query": query},
                    verify=self.verify_ssl,
                    timeout=60,
                )

                if response.status_code != 200:
                    logger.error(f"Failed to export batch: {response.text}")
                    break

                data = response.json()

                if "errors" in data:
                    logger.error(f"GraphQL errors: {data['errors']}")
                    break

                records = data.get("data", {}).get(table_name, [])

                if not records:
                    logger.info("No more records to fetch")
                    break

                all_records.extend(records)
                logger.info(f"Batch {batch_number} complete. Total records: {len(all_records)}")

                if len(records) < batch_size:
                    # Last batch
                    break

                offset += batch_size
                batch_number += 1

            # Write all records to file
            with open(file_path, "w") as f:
                json.dump(all_records, f, indent=2)

            logger.info(
                f"Full export complete: {len(all_records)} records from {table_name} to {file_path}"
            )
            return file_path

        except Exception as e:
            logger.error(f"Error during full export of {table_name}: {str(e)}", exc_info=True)
            return None
