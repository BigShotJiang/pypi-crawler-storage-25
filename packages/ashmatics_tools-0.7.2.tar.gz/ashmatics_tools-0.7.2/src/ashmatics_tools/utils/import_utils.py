"""Utility functions for importing data into the Ashmatics Knowledge Base.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx
import numpy as np
import pandas as pd
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Load environment variables from .env file if it exists
dotenv_path = Path.cwd() / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)


class KBImporter:
    """
    Knowledge Base Importer for uploading data to Hasura GraphQL/REST APIs.

    Provides methods for loading data from Excel files and importing to the
    Knowledge Base via GraphQL mutations or REST API endpoints.
    """

    def __init__(
        self,
        table_name: str,
        graphql_endpoint: str | None = None,
        rest_endpoint: str | None = None,
        admin_secret: str | None = None,
        verify_ssl: bool = True,
    ):
        """
        Initialize the KB Importer with API endpoints and authentication.

        Args:
            table_name: The table name in the database
            graphql_endpoint: The Hasura GraphQL endpoint (default: from HASURA_GRAPHQL_ENDPOINT env)
            rest_endpoint: The Hasura REST endpoint (optional, constructed from graphql_endpoint if not provided)
            admin_secret: The Hasura admin secret (default: from HASURA_ADMIN_SECRET env)
            verify_ssl: Whether to verify SSL certificates (default: True)

        Raises:
            ValueError: If required configuration is missing
        """
        self.table_name = table_name

        # Get configuration from environment or parameters
        graphql_endpoint_str = graphql_endpoint or os.getenv("HASURA_GRAPHQL_ENDPOINT")
        admin_secret_str = admin_secret or os.getenv("HASURA_ADMIN_SECRET")

        if not graphql_endpoint_str:
            raise ValueError(
                "GraphQL endpoint required. Provide via graphql_endpoint parameter "
                "or HASURA_GRAPHQL_ENDPOINT environment variable."
            )

        if not admin_secret_str:
            raise ValueError(
                "Admin secret required. Provide via admin_secret parameter "
                "or HASURA_ADMIN_SECRET environment variable."
            )

        self.graphql_endpoint: str = graphql_endpoint_str
        self.admin_secret: str = admin_secret_str

        # Set REST endpoint if provided, otherwise construct from GraphQL endpoint
        if rest_endpoint:
            self.rest_endpoint = rest_endpoint
        elif "HASURA_REST_BASE_ENDPOINT" in os.environ:
            base_url = os.getenv("HASURA_REST_BASE_ENDPOINT")
            self.rest_endpoint = f"{base_url}/{table_name}"
        else:
            base_url = self.graphql_endpoint.replace("/v1/graphql", "/api/rest")
            self.rest_endpoint = f"{base_url}/{table_name}"

        self.verify_ssl = verify_ssl

        # Log warning if SSL verification is disabled
        if not verify_ssl:
            logger.warning(
                "SSL certificate verification is DISABLED. "
                "This is insecure and should only be used in development/testing."
            )

        self.headers = {
            "Content-Type": "application/json",
            "X-Hasura-Admin-Secret": self.admin_secret,
        }

        logger.info(
            f"Initialized KBImporter for table '{table_name}' "
            f"(endpoint: {self.graphql_endpoint}, SSL: {verify_ssl})"
        )

    def validate_records(
        self, records: list[dict[str, Any]], required_fields: list[str] | None = None
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """
        Validate records before import.

        Args:
            records: List of records to validate
            required_fields: List of fields that must be present and non-empty

        Returns:
            Tuple of (valid_records, invalid_records)
        """
        valid_records = []
        invalid_records = []

        # If no required fields specified, consider all records valid
        if not required_fields:
            return records, []

        for record in records:
            is_valid = True

            # Check required fields
            for field in required_fields:
                if field not in record or record[field] is None or record[field] == "":
                    is_valid = False
                    break

            if is_valid:
                valid_records.append(record)
            else:
                invalid_records.append(record)

        if invalid_records:
            logger.warning(
                f"Found {len(invalid_records)} invalid records out of {len(records)} total"
            )

        return valid_records, invalid_records

    def load_excel_data(
        self,
        file_path: str,
        column_mapping: dict[str, str] | None = None,
        add_metadata: bool = True,
        sheet_name: int | str = 0,
    ) -> list[dict[str, Any]]:
        """
        Load data from Excel file and convert to list of dictionaries.

        Args:
            file_path: Path to the Excel file (absolute or relative to cwd)
            column_mapping: Mapping from Excel column names to database column names
            add_metadata: Whether to add metadata columns (created_at, updated_at)
            sheet_name: Sheet name or index to read (default: 0)

        Returns:
            List of dictionaries representing records

        Raises:
            FileNotFoundError: If file doesn't exist
            Exception: For other errors during loading
        """
        try:
            # Resolve file path
            file_path_obj = Path(file_path)
            if not file_path_obj.is_absolute():
                file_path_obj = Path.cwd() / file_path

            if not file_path_obj.exists():
                raise FileNotFoundError(f"Excel file not found: {file_path_obj}")

            logger.info(f"Loading Excel file: {file_path_obj}")
            df = pd.read_excel(file_path_obj, sheet_name=sheet_name)

            # Convert column names to snake_case
            df.columns = [col.lower().replace(" ", "_") for col in df.columns]

            # Apply column mapping if provided
            if column_mapping:
                for excel_col, db_col in column_mapping.items():
                    if excel_col in df.columns and excel_col != db_col:
                        df.rename(columns={excel_col: db_col}, inplace=True)

            # Add metadata columns if requested
            if add_metadata:
                now = datetime.now().isoformat()
                df["created_at"] = now
                df["updated_at"] = now
                df["last_updated"] = now
                df["updated_by_id"] = "system"

            # Clean up any non-JSON compliant values
            for col in df.columns:
                # Replace NaN with None (will become null in JSON)
                if df[col].isna().any():
                    df[col] = df[col].where(pd.notna(df[col]), None)

                # Check if column contains float values
                if pd.api.types.is_float_dtype(df[col]):
                    # Check if all values are actually integers
                    if df[col].dropna().apply(lambda x: x.is_integer()).all():
                        # Convert to integer
                        df[col] = df[col].astype("Int64")  # nullable integer type
                    else:
                        # Convert special float values (Infinity, -Infinity) to None
                        df[col] = df[col].replace([np.inf, -np.inf], None)
                        # Round to a reasonable precision
                        df[col] = df[col].round(6)

                # Ensure object columns with mixed types are converted to strings
                if pd.api.types.is_object_dtype(df[col]):
                    df[col] = df[col].apply(lambda x: str(x) if x is not None else None)

            # Convert DataFrame to list of dictionaries
            records: list[dict[str, Any]] = df.to_dict(orient="records")  # type: ignore[assignment]

            # Final pass to catch any remaining non-JSON-compliant values
            for record in records:
                for key, value in record.items():
                    if isinstance(value, float):
                        if pd.isna(value) or np.isinf(value) or abs(value) > 1e308:
                            record[key] = None

            logger.info(f"Loaded {len(records)} records from Excel")
            return records

        except Exception as e:
            logger.error(f"Error loading Excel data: {str(e)}", exc_info=True)
            raise

    def check_json_compliance(
        self, records: list[dict[str, Any]], max_records: int = 5
    ) -> tuple[bool, str]:
        """
        Check if records are JSON compliant by attempting to serialize them.

        Args:
            records: List of records to check
            max_records: Maximum number of records to check (0 = check all)

        Returns:
            Tuple of (is_compliant, error_message)
        """
        try:
            # Check all records if max_records is 0 or None
            if max_records is None or max_records <= 0:
                check_records = records
            else:
                check_records = records[:max_records]

            # Try to serialize each record
            for i, record in enumerate(check_records):
                try:
                    json.dumps(record)
                except (TypeError, OverflowError, ValueError) as e:
                    # Identify problematic fields
                    problem_fields = []
                    for key, value in record.items():
                        try:
                            json.dumps({key: value})
                        except (TypeError, OverflowError, ValueError):
                            problem_fields.append((key, value))

                    problem_info = "\n".join(
                        [f"  - Field '{k}': {v} ({type(v).__name__})" for k, v in problem_fields]
                    )

                    return (
                        False,
                        f"Record {i} is not JSON compliant:\n{problem_info}\nError: {str(e)}",
                    )

            return True, "All checked records are JSON compliant"

        except Exception as e:
            return False, f"Error checking JSON compliance: {str(e)}"

    def insert_record_graphql(self, record: dict[str, Any]) -> tuple[bool, str]:
        """
        Insert a single record using GraphQL mutation.

        Args:
            record: Record to insert

        Returns:
            Tuple of (success, message)
        """
        mutation = f"""
        mutation insert_{self.table_name}_one($object: {self.table_name}_insert_input!) {{
          insert_{self.table_name}_one(object: $object) {{
            id
          }}
        }}
        """

        variables = {"object": record}
        payload = {"query": mutation, "variables": variables}

        try:
            response = httpx.post(
                self.graphql_endpoint,
                headers=self.headers,
                json=payload,
                verify=self.verify_ssl,
                timeout=30,
            )

            if response.status_code == 200 and "errors" not in response.json():
                return True, "Success"
            else:
                error_msg = response.text
                return False, f"API Error: {error_msg}"

        except Exception as e:
            logger.error(f"Exception during GraphQL insert: {str(e)}", exc_info=True)
            return False, f"Exception: {str(e)}"

    def insert_records_graphql(self, records: list[dict[str, Any]]) -> tuple[int, int]:
        """
        Insert multiple records using GraphQL mutations (one by one).

        Args:
            records: List of records to insert

        Returns:
            Tuple of (successful_count, failed_count)
        """
        successful = 0
        failed = 0

        logger.info(f"Inserting {len(records)} records via GraphQL")

        for i, record in enumerate(records):
            success, message = self.insert_record_graphql(record)

            if success:
                successful += 1
                if successful % 10 == 0:
                    logger.info(f"Inserted {successful} records...")
            else:
                failed += 1
                id_field = record.get("id") or record.get("code") or i
                logger.error(f"Failed to insert record {id_field}: {message}")

        logger.info(f"GraphQL insert complete. Success: {successful}, Failed: {failed}")
        return successful, failed

    def insert_records_rest(
        self, records: list[dict[str, Any]], batch_size: int = 100
    ) -> tuple[int, int]:
        """
        Insert multiple records using REST API.

        Args:
            records: List of records to insert
            batch_size: Number of records to process in each batch

        Returns:
            Tuple of (successful_count, failed_count)
        """
        try:
            total_records = len(records)
            logger.info(f"Inserting {total_records} records via REST API")

            successful = 0
            failed = 0

            if batch_size <= 0:
                batch_size = total_records

            for i in range(0, total_records, batch_size):
                batch = records[i : i + batch_size]
                batch_number = (i // batch_size) + 1
                total_batches = (total_records + batch_size - 1) // batch_size
                batch_size_actual = len(batch)

                logger.info(
                    f"Processing batch {batch_number}/{total_batches} "
                    f"with {batch_size_actual} records"
                )

                # Verify batch is JSON-serializable
                is_compliant, error_message = self.check_json_compliance(batch, max_records=0)
                if not is_compliant:
                    logger.error(f"Cannot send batch {batch_number}: {error_message}")
                    failed += batch_size_actual
                    continue

                # Process records individually
                for j, record in enumerate(batch):
                    try:
                        response = httpx.post(
                            self.rest_endpoint,
                            headers=self.headers,
                            json=record,
                            verify=self.verify_ssl,
                            timeout=30,
                        )

                        if response.status_code == 200:
                            successful += 1
                            if (j + 1) % 10 == 0:
                                logger.info(
                                    f"Processed {j + 1}/{batch_size_actual} records "
                                    f"in current batch"
                                )
                        else:
                            error_msg = response.text
                            try:
                                error_json = response.json()
                                if "error" in error_json:
                                    error_msg = error_json["error"]
                            except json.JSONDecodeError:
                                pass

                            logger.error(
                                f"Failed to insert record: {error_msg} "
                                f"(status: {response.status_code})"
                            )
                            failed += 1

                    except httpx.HTTPError as e:
                        logger.error(f"HTTP request failed: {str(e)}", exc_info=True)
                        failed += 1

                logger.info(
                    f"Batch {batch_number} complete. Total success: {successful}, failed: {failed}"
                )

            logger.info(f"All batches complete. Successful: {successful}, Failed: {failed}")
            return successful, failed

        except Exception as e:
            logger.error(f"Exception during batch insert: {str(e)}", exc_info=True)
            return 0, len(records)

    def upsert_records_rest(
        self,
        records: list[dict[str, Any]],
        conflict_fields: list[str],
        update_columns: list[str] | None = None,
        batch_size: int = 100,
        dry_run: bool = False,
    ) -> tuple[int, int]:
        """
        Upsert multiple records using REST API.

        Args:
            records: List of records to upsert
            conflict_fields: List of field names to use for conflict detection
            update_columns: List of column names to update on conflict
                          (defaults to all columns except id)
            batch_size: Number of records to process in each batch
            dry_run: If True, prepare but don't send requests

        Returns:
            Tuple of (successful_count, failed_count)
        """
        try:
            # If no conflict fields provided, do regular insert
            if not conflict_fields:
                logger.warning("No conflict fields provided, falling back to insert")
                return self.insert_records_rest(records, batch_size)

            primary_conflict = conflict_fields[0]
            total_records = len(records)

            logger.info(
                f"Upserting {total_records} records via REST API "
                f"(conflict field: {primary_conflict})"
            )

            successful = 0
            failed = 0

            if batch_size <= 0:
                batch_size = total_records

            for i in range(0, total_records, batch_size):
                batch = records[i : i + batch_size]
                batch_number = (i // batch_size) + 1
                total_batches = (total_records + batch_size - 1) // batch_size

                logger.info(
                    f"Processing batch {batch_number}/{total_batches} with {len(batch)} records"
                )

                for record in batch:
                    if dry_run:
                        logger.info(
                            f"DRY RUN: Would upsert record: "
                            f"{record.get('code', record.get('id', 'unknown'))}"
                        )
                        if total_records <= 5:
                            logger.debug(json.dumps(record, indent=2))
                        successful += 1
                        continue

                    # Construct URL with on_conflict parameter
                    upsert_url = f"{self.rest_endpoint}?on_conflict={primary_conflict}"

                    try:
                        response = httpx.post(
                            upsert_url,
                            headers=self.headers,
                            json=record,
                            verify=self.verify_ssl,
                            timeout=30,
                        )

                        if response.status_code == 200:
                            successful += 1
                            if successful % 10 == 0:
                                logger.info(f"Successfully processed {successful} records")
                        else:
                            error_msg = response.text
                            try:
                                error_json = response.json()
                                if "error" in error_json:
                                    error_msg = error_json["error"]
                            except json.JSONDecodeError:
                                pass

                            record_id = record.get("code", record.get("id", "unknown"))
                            logger.error(
                                f"Failed to upsert record {record_id}: {error_msg} "
                                f"(status: {response.status_code})"
                            )
                            failed += 1

                    except httpx.HTTPError as e:
                        record_id = record.get("code", record.get("id", "unknown"))
                        logger.error(
                            f"HTTP request failed for record {record_id}: {str(e)}", exc_info=True
                        )
                        failed += 1

                logger.info(
                    f"Batch {batch_number} complete. Total success: {successful}, failed: {failed}"
                )

            logger.info(f"All batches complete. Successful: {successful}, Failed: {failed}")
            return successful, failed

        except Exception as e:
            logger.error(f"Exception during batch upsert: {str(e)}", exc_info=True)
            return 0, len(records)
