"""GraphQL schema inspection utilities for Hasura.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import logging
import os
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Load environment variables from .env file if it exists
dotenv_path = Path.cwd() / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)


class SchemaInspector:
    """
    GraphQL schema inspector for Hasura endpoints.

    Provides methods to introspect GraphQL schema, discover types,
    and inspect table/type field information.
    """

    def __init__(
        self,
        graphql_endpoint: str | None = None,
        admin_secret: str | None = None,
        verify_ssl: bool = True,
    ):
        """
        Initialize the Schema Inspector.

        Args:
            graphql_endpoint: The Hasura GraphQL endpoint (default: from HASURA_GRAPHQL_ENDPOINT env)
            admin_secret: The Hasura admin secret (default: from HASURA_ADMIN_SECRET env)
            verify_ssl: Whether to verify SSL certificates (default: True)

        Raises:
            ValueError: If required configuration is missing
        """
        graphql_endpoint_str = graphql_endpoint or os.getenv("HASURA_GRAPHQL_ENDPOINT")
        admin_secret_str = admin_secret or os.getenv("HASURA_ADMIN_SECRET")

        if not graphql_endpoint_str:
            raise ValueError(
                "GraphQL endpoint required. Provide via graphql_endpoint parameter "
                "or HASURA_GRAPHQL_ENDPOINT environment variable."
            )

        if not admin_secret_str:
            raise ValueError(
                "Admin secret required. Provide via admin_secret parameter "
                "or HASURA_ADMIN_SECRET environment variable."
            )

        self.graphql_endpoint: str = graphql_endpoint_str
        self.admin_secret: str = admin_secret_str
        self.verify_ssl = verify_ssl

        # Log warning if SSL verification is disabled
        if not verify_ssl:
            logger.warning(
                "SSL certificate verification is DISABLED. "
                "This is insecure and should only be used in development/testing."
            )

        self.headers = {
            "Content-Type": "application/json",
            "X-Hasura-Admin-Secret": self.admin_secret,
        }

        logger.info(
            f"Initialized SchemaInspector (endpoint: {self.graphql_endpoint}, SSL: {verify_ssl})"
        )

    def inspect_type(self, type_name: str) -> dict[str, Any] | None:
        """
        Inspect a specific GraphQL type to get its fields and structure.

        Args:
            type_name: Name of the type/table to inspect

        Returns:
            Dictionary containing type information with name and fields,
            or None if inspection fails
        """
        query = """
        query IntrospectType($typeName: String!) {
          __type(name: $typeName) {
            name
            kind
            description
            fields {
              name
              description
              type {
                name
                kind
                ofType {
                  name
                  kind
                }
              }
            }
          }
        }
        """

        variables = {"typeName": type_name}
        payload = {"query": query, "variables": variables}

        try:
            logger.debug(f"Inspecting type: {type_name}")

            response = httpx.post(
                self.graphql_endpoint,
                headers=self.headers,
                json=payload,
                verify=self.verify_ssl,
                timeout=30,
            )

            if response.status_code == 200:
                data: dict[str, Any] = response.json()
                if "data" in data and "__type" in data["data"]:
                    type_info: dict[str, Any] | None = data["data"]["__type"]
                    if type_info:
                        logger.info(f"Successfully inspected type: {type_name}")
                        return type_info
                    else:
                        logger.error(f"Type '{type_name}' not found in schema")
                        return None
                else:
                    logger.error(f"Unexpected response format: {data}")
                    return None
            else:
                logger.error(
                    f"Request failed with status code {response.status_code}: {response.text}"
                )
                return None

        except Exception as e:
            logger.error(f"Error inspecting type {type_name}: {str(e)}", exc_info=True)
            return None

    def get_type_fields(self, type_name: str) -> list[dict[str, Any]] | None:
        """
        Get the fields for a specific GraphQL type.

        Args:
            type_name: Name of the type/table

        Returns:
            List of field dictionaries with name and type information,
            or None if inspection fails
        """
        type_info = self.inspect_type(type_name)
        if type_info and "fields" in type_info:
            fields: list[dict[str, Any]] = type_info["fields"]
            return fields
        return None

    def print_type_info(self, type_name: str) -> bool:
        """
        Print detailed information about a GraphQL type.

        Args:
            type_name: Name of the type/table to inspect

        Returns:
            True if successful, False otherwise
        """
        type_info = self.inspect_type(type_name)

        if not type_info:
            return False

        print(f"\nType: {type_info['name']}")
        print(f"Kind: {type_info.get('kind', 'N/A')}")

        if type_info.get("description"):
            print(f"Description: {type_info['description']}")

        print("\nFields:")
        fields = type_info.get("fields", [])

        if not fields:
            print("  No fields found")
            return True

        for field in fields:
            field_name = field["name"]
            field_type = field["type"]

            # Get type information
            type_name = field_type.get("name")
            kind = field_type.get("kind")

            # Handle non-nullable types (NON_NULL wrapper)
            nullable = True
            if not type_name and "ofType" in field_type and field_type["ofType"]:
                of_type = field_type["ofType"]
                type_name = of_type.get("name")
                kind = of_type.get("kind")
                nullable = False

            nullable_str = "nullable" if nullable else "NOT NULL"
            print(f"  {field_name}: {type_name} ({kind}, {nullable_str})")

            if field.get("description"):
                print(f"    Description: {field['description']}")

        return True

    def list_all_types(self) -> list[str] | None:
        """
        List all available types in the GraphQL schema.

        Returns:
            List of type names, or None if query fails
        """
        query = """
        query ListAllTypes {
          __schema {
            types {
              name
              kind
            }
          }
        }
        """

        try:
            logger.debug("Listing all types in schema")

            response = httpx.post(
                self.graphql_endpoint,
                headers=self.headers,
                json={"query": query},
                verify=self.verify_ssl,
                timeout=30,
            )

            if response.status_code == 200:
                data = response.json()
                if "data" in data and "__schema" in data["data"]:
                    types = data["data"]["__schema"]["types"]
                    # Filter out internal GraphQL types (start with __)
                    type_names = [t["name"] for t in types if not t["name"].startswith("__")]
                    logger.info(f"Found {len(type_names)} types in schema")
                    return sorted(type_names)
                else:
                    logger.error(f"Unexpected response format: {data}")
                    return None
            else:
                logger.error(
                    f"Request failed with status code {response.status_code}: {response.text}"
                )
                return None

        except Exception as e:
            logger.error(f"Error listing types: {str(e)}", exc_info=True)
            return None

    def find_tables(self) -> list[str] | None:
        """
        Find all table types (OBJECT kind) in the schema.

        Returns:
            List of table names, or None if query fails
        """
        query = """
        query FindTables {
          __schema {
            types {
              name
              kind
            }
          }
        }
        """

        try:
            logger.debug("Finding all tables in schema")

            response = httpx.post(
                self.graphql_endpoint,
                headers=self.headers,
                json={"query": query},
                verify=self.verify_ssl,
                timeout=30,
            )

            if response.status_code == 200:
                data = response.json()
                if "data" in data and "__schema" in data["data"]:
                    types = data["data"]["__schema"]["types"]
                    # Filter for OBJECT types (tables) excluding internal types
                    table_names = [
                        t["name"]
                        for t in types
                        if t["kind"] == "OBJECT" and not t["name"].startswith("__")
                    ]
                    logger.info(f"Found {len(table_names)} tables in schema")
                    return sorted(table_names)
                else:
                    logger.error(f"Unexpected response format: {data}")
                    return None
            else:
                logger.error(
                    f"Request failed with status code {response.status_code}: {response.text}"
                )
                return None

        except Exception as e:
            logger.error(f"Error finding tables: {str(e)}", exc_info=True)
            return None
