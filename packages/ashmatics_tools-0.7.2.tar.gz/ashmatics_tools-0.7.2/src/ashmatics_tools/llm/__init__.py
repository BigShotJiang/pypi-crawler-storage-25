# Copyright 2025 Asher Informatics PBC
"""LLM client abstraction for ashmatics-tools.

This module provides a unified interface for working with various LLM providers:
- Azure OpenAI (Azure AI Foundry)
- OpenAI
- HuggingFace (Inference API and local models)
- Custom providers via plugin registry

Example usage:
    ```python
    from ashmatics_tools.llm import create_llm_client, AzureOpenAIConfig

    # Create a client
    config = AzureOpenAIConfig(
        endpoint="https://my-resource.openai.azure.com/",
        api_key="sk-...",
        deployment_name="gpt-4"
    )

    llm = create_llm_client("azure_openai", config)

    # Use the client
    async with llm:
        response = await llm.complete(
            prompt="What is asthma?",
            temperature=0.7,
            max_tokens=500
        )
        print(response.text)
        print(f"Cost: ${response.tokens.estimated_cost:.4f}")
    ```

For custom providers:
    ```python
    from ashmatics_tools.llm import BaseLLMClient, register_llm_provider

    class MyCustomLLM(BaseLLMClient):
        # Implement abstract methods
        pass

    register_llm_provider("my_custom", MyCustomLLM)
    llm = create_llm_client("my_custom", config)
    ```
"""

# Core providers (always available)
from .azure_openai import AzureOpenAIClient, AzureOpenAIConfig
from .base import (
    BaseLLMClient,
    LLMAPIError,
    LLMContextLengthError,
    LLMError,
    LLMMessage,
    LLMRateLimitError,
    LLMResponse,
    StreamChunk,
    TokenUsage,
)
from .factory import (
    _CONFIG_REGISTRY,
    _LLM_REGISTRY,
    create_llm_client,
    get_config_class,
    list_llm_providers,
    register_llm_provider,
    unregister_llm_provider,
)

# Context window management
from .context import ContextWindowManager, ModelContextLimits, ModelFamily

# Retry utilities with exponential backoff
from .retry import (
    RetryConfig,
    calculate_backoff_delay,
    call_with_backoff,
    call_with_backoff_and_fallback,
)

# Ollama provider (requires ollama extra for full features)
from .llamacpp import LlamaCppClient, LlamaCppConfig
from .ollama import OllamaClient, OllamaConfig, OllamaTool, OllamaToolCall, OllamaToolParameter
from .openai import OpenAIClient, OpenAIConfig

_LLM_REGISTRY["ollama"] = OllamaClient
_CONFIG_REGISTRY["ollama"] = OllamaConfig

_LLM_REGISTRY["llamacpp"] = LlamaCppClient
_CONFIG_REGISTRY["llamacpp"] = LlamaCppConfig

# =============================================================================
# OPTIONAL PROVIDERS - Registered lazily to avoid loading torch at import time
# =============================================================================
# HuggingFace and Azure AI Foundry providers are NOT imported at module load
# time. They are registered on-demand when create_llm_client() is called with
# their provider names. This prevents loading torch/CUDA when not needed.
#
# See factory.py _register_lazy_providers() for the lazy registration logic.

# Build __all__ - optional providers are available but lazily imported
__all__ = [
    # Base classes
    "BaseLLMClient",
    "LLMMessage",
    "LLMResponse",
    "StreamChunk",
    "TokenUsage",
    # Exceptions
    "LLMError",
    "LLMAPIError",
    "LLMRateLimitError",
    "LLMContextLengthError",
    # Context management
    "ContextWindowManager",
    "ModelContextLimits",
    "ModelFamily",
    # Factory functions
    "create_llm_client",
    "register_llm_provider",
    "unregister_llm_provider",
    "list_llm_providers",
    "get_config_class",
    # Core providers (always available)
    "AzureOpenAIClient",
    "AzureOpenAIConfig",
    "OpenAIClient",
    "OpenAIConfig",
    "OllamaClient",
    "OllamaConfig",
    "OllamaTool",
    "OllamaToolCall",
    "OllamaToolParameter",
    "LlamaCppClient",
    "LlamaCppConfig",
    # Retry utilities
    "RetryConfig",
    "calculate_backoff_delay",
    "call_with_backoff",
    "call_with_backoff_and_fallback",
]

# Optional providers (HuggingFace, Azure AI Foundry) are NOT in __all__ to avoid
# triggering imports at module load time. They can be imported directly:
#
#   from ashmatics_tools.llm.huggingface import HuggingFaceInferenceClient
#   from ashmatics_tools.llm.azure_ai_foundry import AzureAIClient
#
# Or used via factory (which handles lazy registration):
#
#   llm = create_llm_client("huggingface_inference", config)
