# Copyright 2025 Asher Informatics PBC
"""Factory and registry for LLM clients.

This module provides a factory pattern with extensible registry for creating
LLM clients. Applications and customers can register custom providers.
"""

import logging
from typing import Any

from .azure_openai import AzureOpenAIClient, AzureOpenAIConfig
from .base import BaseLLMClient
from .llamacpp import LlamaCppClient, LlamaCppConfig
from .openai import OpenAIClient, OpenAIConfig

logger = logging.getLogger(__name__)

# Global registry of LLM providers
_LLM_REGISTRY: dict[str, type[BaseLLMClient]] = {
    "azure_openai": AzureOpenAIClient,
    "openai": OpenAIClient,
    "llamacpp": LlamaCppClient,
}

# Config classes for each provider
_CONFIG_REGISTRY: dict[str, type] = {
    "azure_openai": AzureOpenAIConfig,
    "openai": OpenAIConfig,
    "llamacpp": LlamaCppConfig,
}

# Track if lazy providers have been registered
_LAZY_PROVIDERS_REGISTERED = False


def _register_lazy_providers() -> None:
    """Register optional providers on first access.

    This function is called when a provider is not found in the registry,
    attempting to import and register optional providers (like HuggingFace)
    that require heavy dependencies.
    """
    global _LAZY_PROVIDERS_REGISTERED

    if _LAZY_PROVIDERS_REGISTERED:
        return

    _LAZY_PROVIDERS_REGISTERED = True

    # Azure AI Foundry
    try:
        from .azure_ai_foundry import AzureAIClient, AzureAIConfig

        _LLM_REGISTRY["azure_ai_foundry"] = AzureAIClient
        _CONFIG_REGISTRY["azure_ai_foundry"] = AzureAIConfig
        logger.debug("Registered optional provider: azure_ai_foundry")
    except ImportError:
        logger.debug("azure_ai_foundry not available (missing azure-ai-inference)")

    # HuggingFace (pulls torch - only import when explicitly requested)
    try:
        from .huggingface import (
            HuggingFaceFineTunedClient,
            HuggingFaceInferenceClient,
            HuggingFaceInferenceConfig,
            HuggingFaceLocalClient,
            HuggingFaceLocalConfig,
        )

        _LLM_REGISTRY["huggingface_inference"] = HuggingFaceInferenceClient
        _LLM_REGISTRY["huggingface_local"] = HuggingFaceLocalClient
        _LLM_REGISTRY["huggingface_finetuned"] = HuggingFaceFineTunedClient

        _CONFIG_REGISTRY["huggingface_inference"] = HuggingFaceInferenceConfig
        _CONFIG_REGISTRY["huggingface_local"] = HuggingFaceLocalConfig
        logger.debug("Registered optional providers: huggingface_*")
    except ImportError:
        logger.debug("huggingface providers not available (missing transformers/torch)")


def register_llm_provider(
    name: str,
    client_class: type[BaseLLMClient],
    config_class: type[Any] = None,
) -> None:
    """Register a custom LLM provider.

    This allows applications and customers to extend ashmatics-tools with
    custom LLM providers without modifying the package.

    Args:
        name: Provider name (e.g., 'custom_internal', 'anthropic')
        client_class: LLM client class (must inherit from BaseLLMClient)
        config_class: Optional configuration class for the provider

    Raises:
        ValueError: If the client class doesn't inherit from BaseLLMClient

    Example:
        ```python
        from ashmatics_tools.llm import BaseLLMClient, register_llm_provider

        class CustomLLMClient(BaseLLMClient):
            def __init__(self, config):
                self.endpoint = config.endpoint

            async def complete(self, prompt, **kwargs):
                # Custom implementation
                pass

            async def complete_with_messages(self, messages, **kwargs):
                # Custom implementation
                pass

        register_llm_provider("custom", CustomLLMClient)

        # Now can be used with factory
        llm = create_llm_client("custom", config)
        ```
    """
    if not issubclass(client_class, BaseLLMClient):
        raise ValueError(f"Client class {client_class.__name__} must inherit from BaseLLMClient")

    if name in _LLM_REGISTRY:
        logger.warning(
            f"Overwriting existing LLM provider: {name}",
            extra={"existing": _LLM_REGISTRY[name].__name__, "new": client_class.__name__},
        )

    _LLM_REGISTRY[name] = client_class

    if config_class:
        _CONFIG_REGISTRY[name] = config_class

    logger.info(
        f"Registered LLM provider: {name}",
        extra={"client_class": client_class.__name__},
    )


def unregister_llm_provider(name: str) -> None:
    """Unregister an LLM provider.

    Args:
        name: Provider name to unregister

    Raises:
        ValueError: If the provider is not registered
    """
    if name not in _LLM_REGISTRY:
        raise ValueError(f"LLM provider not registered: {name}")

    del _LLM_REGISTRY[name]
    if name in _CONFIG_REGISTRY:
        del _CONFIG_REGISTRY[name]

    logger.info(f"Unregistered LLM provider: {name}")


def list_llm_providers() -> list[str]:
    """List all registered LLM providers.

    Returns:
        List of provider names

    Example:
        ```python
        providers = list_llm_providers()
        print(f"Available providers: {providers}")
        # Output: ['azure_openai', 'openai', 'huggingface_inference', ...]
        ```
    """
    return list(_LLM_REGISTRY.keys())


def create_llm_client(provider: str, config: Any) -> BaseLLMClient:
    """Create an LLM client using the factory pattern.

    Args:
        provider: Provider name (e.g., 'azure_openai', 'openai', 'huggingface_inference')
        config: Provider-specific configuration object

    Returns:
        Initialized LLM client

    Raises:
        ValueError: If the provider is not registered

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client, AzureOpenAIConfig

        # Create Azure OpenAI client
        config = AzureOpenAIConfig(
            endpoint="https://my-resource.openai.azure.com/",
            api_key="sk-...",
            deployment_name="gpt-4"
        )
        llm = create_llm_client("azure_openai", config)

        # Use the client
        async with llm:
            response = await llm.complete("What is asthma?")
            print(response.text)
        ```
    """
    # First check core providers
    if provider not in _LLM_REGISTRY:
        # Try registering optional providers (HuggingFace, Azure AI)
        _register_lazy_providers()

    if provider not in _LLM_REGISTRY:
        available = ", ".join(_LLM_REGISTRY.keys())
        raise ValueError(
            f"Unknown LLM provider: {provider}. "
            f"Available providers: {available}. "
            f"Use register_llm_provider() to add custom providers."
        )

    client_class = _LLM_REGISTRY[provider]

    logger.debug(
        "Creating LLM client",
        extra={"provider": provider, "client_class": client_class.__name__},
    )

    return client_class(config)


def get_config_class(provider: str) -> type:
    """Get the configuration class for a provider.

    Args:
        provider: Provider name

    Returns:
        Configuration class for the provider

    Raises:
        ValueError: If the provider is not registered or has no config class
    """
    if provider not in _CONFIG_REGISTRY:
        raise ValueError(f"No config class registered for provider: {provider}")

    return _CONFIG_REGISTRY[provider]
