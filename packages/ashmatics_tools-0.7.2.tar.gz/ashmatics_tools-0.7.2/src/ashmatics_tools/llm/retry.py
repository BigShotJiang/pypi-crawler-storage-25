# Copyright 2025 Asher Informatics PBC
"""Retry utilities with exponential backoff for LLM API calls.

This module provides robust retry logic for handling rate limits and transient
failures when calling LLM APIs (Azure OpenAI, OpenAI, Ollama, etc.).

Features:
- Exponential backoff with configurable base and max delay
- Random jitter to prevent thundering herd
- Support for API-provided retry_after hints
- Configurable max attempts
- Works with any async callable

Example usage:
    ```python
    from ashmatics_tools.llm import LLMRateLimitError
    from ashmatics_tools.llm.retry import RetryConfig, call_with_backoff

    config = RetryConfig(
        max_attempts=5,
        initial_delay=2.0,
        max_delay=60.0,
        exponential_base=2.0,
        jitter=0.3,
    )

    async def my_llm_call():
        return await llm_client.complete_with_messages(messages)

    result = await call_with_backoff(
        my_llm_call,
        config=config,
        item_id="K123456",  # For logging
    )
    ```
"""

import asyncio
import logging
import random
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, TypeVar

from .base import LLMRateLimitError

logger = logging.getLogger(__name__)

T = TypeVar("T")


@dataclass
class RetryConfig:
    """Configuration for retry behavior with exponential backoff.

    Attributes:
        max_attempts: Maximum number of retry attempts (including initial call).
            Default: 5
        initial_delay: Initial delay in seconds before first retry.
            Default: 2.0
        max_delay: Maximum delay between retries (caps exponential growth).
            Default: 60.0
        exponential_base: Base for exponential backoff (delay * base^attempt).
            Default: 2.0
        jitter: Random jitter factor (0.0-1.0) to prevent thundering herd.
            Default: 0.3 (30% jitter)
        request_delay: Fixed delay in seconds before each request (proactive rate limiting).
            Default: 0.0 (no delay)
    """

    max_attempts: int = 5
    initial_delay: float = 2.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: float = 0.3
    request_delay: float = 0.0

    @classmethod
    def aggressive(cls) -> "RetryConfig":
        """Create a more aggressive retry config for long-running batch operations.

        Longer delays, more retries - suitable for background processing.
        """
        return cls(
            max_attempts=8,
            initial_delay=5.0,
            max_delay=120.0,
            exponential_base=2.0,
            jitter=0.4,
            request_delay=0.5,
        )

    @classmethod
    def conservative(cls) -> "RetryConfig":
        """Create a conservative retry config for interactive use.

        Fewer retries, shorter delays - fails faster for user-facing operations.
        """
        return cls(
            max_attempts=3,
            initial_delay=1.0,
            max_delay=10.0,
            exponential_base=2.0,
            jitter=0.2,
            request_delay=0.0,
        )


def calculate_backoff_delay(
    attempt: int,
    config: RetryConfig,
) -> float:
    """Calculate delay for exponential backoff with jitter.

    Uses the formula: delay = min(initial * base^attempt, max_delay) * (1 + jitter)

    Args:
        attempt: The current retry attempt number (0-indexed).
        config: Retry configuration.

    Returns:
        Delay in seconds before next retry.

    Example:
        With default config (initial=2, base=2, max=60, jitter=0.3):
        - Attempt 0: 2.0 * (1 + 0-0.3) = 2.0 - 2.6s
        - Attempt 1: 4.0 * (1 + 0-0.3) = 4.0 - 5.2s
        - Attempt 2: 8.0 * (1 + 0-0.3) = 8.0 - 10.4s
        - Attempt 3: 16.0 * (1 + 0-0.3) = 16.0 - 20.8s
        - Attempt 4: 32.0 * (1 + 0-0.3) = 32.0 - 41.6s
    """
    # Calculate exponential delay
    delay = config.initial_delay * (config.exponential_base**attempt)

    # Cap at max delay
    delay = min(delay, config.max_delay)

    # Add jitter to prevent thundering herd
    if config.jitter > 0:
        jitter = random.uniform(0, config.jitter)
        delay = delay * (1 + jitter)

    return delay


async def call_with_backoff(
    func: Callable[[], Awaitable[T]],
    config: RetryConfig | None = None,
    item_id: str | None = None,
    on_retry: Callable[[int, float, Exception], None] | None = None,
) -> T:
    """Execute an async LLM call with exponential backoff retry on rate limits.

    This wrapper handles LLMRateLimitError exceptions and implements exponential
    backoff with jitter to avoid thundering herd when multiple concurrent requests
    hit rate limits.

    Args:
        func: Async callable that makes the LLM request (no arguments).
        config: Retry configuration. If None, uses default RetryConfig().
        item_id: Optional item identifier for logging (e.g., "K123456").
        on_retry: Optional callback called before each retry with
            (attempt_number, delay_seconds, exception).

    Returns:
        The result of the LLM call.

    Raises:
        LLMRateLimitError: If max retries exceeded.
        Exception: Any other exception from the LLM call (not retried).

    Example:
        ```python
        async def my_llm_call():
            return await client.complete_with_messages(messages)

        result = await call_with_backoff(
            my_llm_call,
            config=RetryConfig(max_attempts=5),
            item_id="K123456",
        )
        ```
    """
    if config is None:
        config = RetryConfig()

    last_exception: LLMRateLimitError | None = None
    item_label = f" for {item_id}" if item_id else ""

    for attempt in range(config.max_attempts):
        try:
            # Add proactive request delay if configured (only on first attempt)
            if config.request_delay > 0 and attempt == 0:
                await asyncio.sleep(config.request_delay)

            return await func()

        except LLMRateLimitError as e:
            last_exception = e
            delay = calculate_backoff_delay(attempt, config)

            # Check if we have retry_after hint from the API
            if e.retry_after and e.retry_after > delay:
                delay = e.retry_after

            if attempt < config.max_attempts - 1:
                logger.warning(
                    f"Rate limited{item_label} (attempt {attempt + 1}/"
                    f"{config.max_attempts}), retrying in {delay:.1f}s"
                )

                # Call the optional retry callback
                if on_retry:
                    on_retry(attempt, delay, e)

                await asyncio.sleep(delay)
            else:
                logger.error(
                    f"Rate limit exceeded{item_label} after "
                    f"{config.max_attempts} attempts"
                )

    # If we exhausted all retries, raise the last exception
    if last_exception:
        raise last_exception

    # This should never happen, but satisfies type checker
    raise RuntimeError("Unexpected state in call_with_backoff")


async def call_with_backoff_and_fallback(
    primary_func: Callable[[], Awaitable[T]],
    fallback_func: Callable[[], T | Awaitable[T]],
    config: RetryConfig | None = None,
    item_id: str | None = None,
) -> tuple[T, bool]:
    """Execute an LLM call with backoff, falling back on exhausted retries.

    This is a convenience wrapper that combines retry logic with a fallback
    function for when all retries are exhausted.

    Args:
        primary_func: Async callable for the primary LLM request.
        fallback_func: Sync or async callable to use as fallback.
        config: Retry configuration.
        item_id: Optional item identifier for logging.

    Returns:
        Tuple of (result, used_fallback) where used_fallback is True if
        the fallback was used.

    Example:
        ```python
        async def llm_extract():
            return await client.complete_with_messages(messages)

        def regex_extract():
            return re.findall(pattern, text)

        predicates, used_fallback = await call_with_backoff_and_fallback(
            llm_extract,
            regex_extract,
            item_id="K123456",
        )
        if used_fallback:
            logger.warning("Used regex fallback")
        ```
    """
    try:
        result = await call_with_backoff(
            primary_func,
            config=config,
            item_id=item_id,
        )
        return result, False

    except LLMRateLimitError as e:
        item_label = f" for {item_id}" if item_id else ""
        logger.warning(
            f"Rate limit exhausted{item_label} after retries, using fallback: {e}"
        )

        # Handle both sync and async fallback functions
        fallback_result = fallback_func()
        if asyncio.iscoroutine(fallback_result):
            fallback_result = await fallback_result

        return fallback_result, True
