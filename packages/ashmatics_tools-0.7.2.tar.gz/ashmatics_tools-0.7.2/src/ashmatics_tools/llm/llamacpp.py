# Copyright 2025 Asher Informatics PBC
"""llama.cpp client for local and remote llama.cpp servers.

This module provides a client for llama.cpp server endpoints,
supporting both local (Metal-accelerated on M1 Macs) and remote
(VPS/cloud) deployments.
"""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import httpx

from .base import (
    BaseLLMClient,
    LLMAPIError,
    LLMContextLengthError,
    LLMMessage,
    LLMRateLimitError,
    LLMResponse,
    StreamChunk,
    TokenUsage,
)

logger = logging.getLogger(__name__)


@dataclass
class LlamaCppConfig:
    """Configuration for llama.cpp client.

    Args:
        endpoint: llama.cpp server endpoint (e.g., http://localhost:8080).
                 If not provided, will use LLAMACPP_ENDPOINT environment variable.
                 Defaults to http://localhost:8080 for local Metal inference.
        model: Model identifier (not always used by llama.cpp server but useful for logging).
              Defaults to "llama-cpp-model".
        timeout: Request timeout in seconds. llama.cpp can be slower on CPU.
                Defaults to 120.0 seconds.
        max_retries: Maximum number of retries for failed requests.
                    Defaults to 3.
        verify_ssl: Whether to verify SSL certificates for HTTPS connections.
                   Defaults to True. Set to False for self-signed certs in dev.
        context_size: Model context size in tokens. Used for context length error detection.
                     Defaults to 4096.
        n_gpu_layers: Number of layers to offload to GPU (Metal on M1 Macs).
                     -1 = all layers, 0 = CPU only. Defaults to -1.
    """

    endpoint: str | None = None
    model: str = "llama-cpp-model"
    timeout: float = 120.0
    max_retries: int = 3
    verify_ssl: bool = True
    context_size: int = 4096
    n_gpu_layers: int = -1

    def __post_init__(self) -> None:
        """Validate configuration and load from environment if needed."""
        # Load endpoint from environment if not provided
        if not self.endpoint:
            self.endpoint = os.getenv("LLAMACPP_ENDPOINT", "http://localhost:8080")

        # Normalize endpoint (remove trailing slash)
        if self.endpoint.endswith("/"):
            self.endpoint = self.endpoint[:-1]

        # Log warning if SSL verification is disabled
        if not self.verify_ssl:
            logger.warning(
                "SSL verification disabled for llama.cpp client. "
                "This should only be used in development with self-signed certificates."
            )


class LlamaCppClient(BaseLLMClient):
    """Client for llama.cpp servers.

    Supports both local llama.cpp servers (e.g., Metal-accelerated on M1 Macs)
    and remote deployments (VPS, cloud servers).

    llama.cpp server API reference:
    https://github.com/ggerganov/llama.cpp/blob/master/examples/server/README.md

    Example:
        Local Metal inference on M1 Mac:
        ```python
        config = LlamaCppConfig(
            endpoint="http://localhost:8080",
            n_gpu_layers=-1  # Offload all layers to Metal
        )
        async with LlamaCppClient(config) as llm:
            response = await llm.complete("What is asthma?")
            print(response.text)
        ```

        Remote VPS deployment:
        ```python
        config = LlamaCppConfig(
            endpoint="https://llama.example.com",
            verify_ssl=True
        )
        async with LlamaCppClient(config) as llm:
            response = await llm.complete("What is asthma?")
        ```
    """

    def __init__(self, config: LlamaCppConfig) -> None:
        """Initialize llama.cpp client.

        Args:
            config: llama.cpp configuration.
        """
        self.config = config
        self.http_client: httpx.AsyncClient | None = None
        logger.info(
            "Initialized llama.cpp client",
            extra={
                "endpoint": self.config.endpoint,
                "model": self.config.model,
                "timeout": self.config.timeout,
                "n_gpu_layers": self.config.n_gpu_layers,
            },
        )

    async def __aenter__(self) -> LlamaCppClient:
        """Enter async context manager and initialize HTTP client."""
        await self.start()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager and clean up resources."""
        await self.stop()

    async def start(self) -> None:
        """Initialize resources (HTTP client)."""
        if self.http_client is None:
            self.http_client = httpx.AsyncClient(
                timeout=self.config.timeout,
                verify=self.config.verify_ssl,
            )
            logger.debug("Started llama.cpp HTTP client")

    async def stop(self) -> None:
        """Clean up resources."""
        if self.http_client is not None:
            await self.http_client.aclose()
            self.http_client = None
            logger.debug("Stopped llama.cpp HTTP client")

    def _ensure_client(self) -> None:
        """Ensure HTTP client is initialized."""
        if self.http_client is None:
            msg = (
                "llama.cpp client not started. "
                "Use 'async with LlamaCppClient(config) as client:' "
                "or call 'await client.start()' first."
            )
            raise RuntimeError(msg)

    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate completion for a prompt using llama.cpp.

        Args:
            prompt: Input prompt text.
            temperature: Sampling temperature (0.0 to 2.0).
            max_tokens: Maximum tokens to generate.
            stop: Optional list of stop sequences.
            **kwargs: Additional parameters passed to llama.cpp API.

        Returns:
            LLMResponse containing generated text and metadata.

        Raises:
            LLMAPIError: If API request fails.
            LLMContextLengthError: If prompt exceeds context length.
            LLMRateLimitError: If rate limit is exceeded (remote deployments).
        """
        # Delegate to complete_with_messages by wrapping prompt
        return await self.complete_with_messages(
            messages=[LLMMessage(role="user", content=prompt)],
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            **kwargs,
        )

    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate completion for a list of messages using llama.cpp chat mode.

        Args:
            messages: List of conversation messages.
            temperature: Sampling temperature (0.0 to 2.0).
            max_tokens: Maximum tokens to generate.
            stop: Optional list of stop sequences.
            **kwargs: Additional parameters passed to llama.cpp API.

        Returns:
            LLMResponse containing generated text and metadata.

        Raises:
            LLMAPIError: If API request fails.
            LLMContextLengthError: If messages exceed context length.
            LLMRateLimitError: If rate limit is exceeded (remote deployments).
        """
        self._ensure_client()

        # Build llama.cpp-compatible payload
        # llama.cpp server supports both /completion and /v1/chat/completions
        # We'll use /v1/chat/completions for consistency with OpenAI-compatible API
        payload = {
            "messages": [msg.to_dict() for msg in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,  # Use stream_complete_with_messages() for streaming
        }

        if stop:
            payload["stop"] = stop

        # Add any additional kwargs (e.g., top_p, top_k, repeat_penalty, etc.)
        payload.update(kwargs)

        logger.debug(
            "Sending llama.cpp chat completion request",
            extra={
                "endpoint": self.config.endpoint,
                "model": self.config.model,
                "num_messages": len(messages),
                "temperature": temperature,
                "max_tokens": max_tokens,
            },
        )

        try:
            assert self.http_client is not None  # For type checker
            response = await self.http_client.post(
                f"{self.config.endpoint}/v1/chat/completions",
                json=payload,
            )
            response.raise_for_status()
            result = response.json()

            # Extract response text
            # llama.cpp returns OpenAI-compatible format
            text = result["choices"][0]["message"]["content"]

            # Extract token counts
            # llama.cpp provides usage statistics
            usage = result.get("usage", {})
            prompt_tokens = usage.get("prompt_tokens", 0)
            completion_tokens = usage.get("completion_tokens", 0)
            total_tokens = usage.get("total_tokens", prompt_tokens + completion_tokens)

            # Calculate cost (always 0.0 for self-hosted)
            estimated_cost = await self.estimate_cost(
                TokenUsage(
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_tokens=total_tokens,
                )
            )

            # Extract finish reason
            finish_reason = result["choices"][0].get("finish_reason", "stop")

            logger.info(
                "llama.cpp completion successful",
                extra={
                    "model": self.config.model,
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": total_tokens,
                    "finish_reason": finish_reason,
                },
            )

            return LLMResponse(
                text=text,
                tokens=TokenUsage(
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_tokens=total_tokens,
                    estimated_cost=estimated_cost,
                ),
                model=self.config.model,
                finish_reason=finish_reason,
                metadata={"llama_cpp_response": result},
            )

        except httpx.HTTPStatusError as e:
            # Check for specific error conditions
            error_body = e.response.text

            # Check for context length errors
            if "context" in error_body.lower() or "too long" in error_body.lower():
                logger.error(
                    "llama.cpp context length exceeded",
                    extra={"status_code": e.response.status_code, "error": error_body},
                    exc_info=True,
                )
                raise LLMContextLengthError(
                    message=f"Prompt exceeds llama.cpp context length: {error_body}",
                    max_tokens=self.config.context_size,
                ) from e

            # Check for rate limiting (unlikely in local deployment but possible on remote)
            if e.response.status_code == 429:
                retry_after = e.response.headers.get("retry-after")
                retry_after_int = int(retry_after) if retry_after else None
                logger.error(
                    "llama.cpp rate limit exceeded",
                    extra={"retry_after": retry_after_int},
                    exc_info=True,
                )
                raise LLMRateLimitError(
                    message=f"llama.cpp rate limit exceeded: {error_body}",
                    retry_after=retry_after_int,
                ) from e

            # Generic HTTP error
            logger.error(
                "llama.cpp HTTP error",
                extra={"status_code": e.response.status_code, "error": error_body},
                exc_info=True,
            )
            raise LLMAPIError(
                message=f"llama.cpp HTTP error: {error_body}",
                status_code=e.response.status_code,
                response_body=error_body,
            ) from e

        except httpx.HTTPError as e:
            logger.error("llama.cpp connection error", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp connection error: {e}",
            ) from e

        except Exception as e:
            logger.error("llama.cpp unexpected error", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp unexpected error: {e}",
            ) from e

    async def stream_complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a chat completion, yielding chunks as they arrive.

        Uses llama.cpp's OpenAI-compatible /v1/chat/completions endpoint with
        SSE (Server-Sent Events) streaming.

        Args:
            messages: List of conversation messages.
            temperature: Sampling temperature (0.0 to 2.0).
            max_tokens: Maximum tokens to generate.
            stop: Optional list of stop sequences.
            **kwargs: Additional parameters passed to llama.cpp API.

        Yields:
            StreamChunk objects containing text fragments.

        Raises:
            LLMAPIError: If API request fails.
            LLMContextLengthError: If messages exceed context length.
            LLMRateLimitError: If rate limit is exceeded (remote deployments).
        """
        self._ensure_client()

        # Build llama.cpp-compatible payload with streaming enabled
        payload = {
            "messages": [msg.to_dict() for msg in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }

        if stop:
            payload["stop"] = stop

        # Add any additional kwargs
        payload.update(kwargs)

        logger.debug(
            "Starting llama.cpp streaming chat completion request",
            extra={
                "endpoint": self.config.endpoint,
                "model": self.config.model,
                "num_messages": len(messages),
                "temperature": temperature,
                "max_tokens": max_tokens,
            },
        )

        try:
            assert self.http_client is not None  # For type checker

            # Stream the response using SSE format
            async with self.http_client.stream(
                "POST",
                f"{self.config.endpoint}/v1/chat/completions",
                json=payload,
            ) as response:
                response.raise_for_status()

                finish_reason = None
                async for line in response.aiter_lines():
                    # SSE format: "data: {...}" or "data: [DONE]"
                    if not line:
                        continue

                    if not line.startswith("data:"):
                        continue

                    data_str = line[5:].strip()

                    # Check for end of stream
                    if data_str == "[DONE]":
                        break

                    try:
                        chunk_data = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    # Extract text from the delta
                    choices = chunk_data.get("choices", [])
                    if not choices:
                        continue

                    choice = choices[0]
                    delta = choice.get("delta", {})
                    text = delta.get("content", "")

                    # Track finish reason
                    if choice.get("finish_reason"):
                        finish_reason = choice["finish_reason"]

                    # Yield chunk (skip empty chunks unless it's final)
                    if text or choice.get("finish_reason"):
                        yield StreamChunk(
                            text=text,
                            finish_reason=finish_reason,
                            is_final=choice.get("finish_reason") is not None,
                            metadata={"chunk_id": chunk_data.get("id")}
                            if chunk_data.get("id")
                            else {},
                        )

            logger.info(
                "llama.cpp streaming completion finished",
                extra={"finish_reason": finish_reason},
            )

        except httpx.HTTPStatusError as e:
            error_body = e.response.text

            # Check for context length errors
            if "context" in error_body.lower() or "too long" in error_body.lower():
                logger.error(
                    "llama.cpp context length exceeded during streaming",
                    extra={"status_code": e.response.status_code, "error": error_body},
                    exc_info=True,
                )
                raise LLMContextLengthError(
                    message=f"Prompt exceeds llama.cpp context length: {error_body}",
                    max_tokens=self.config.context_size,
                ) from e

            # Check for rate limiting
            if e.response.status_code == 429:
                retry_after = e.response.headers.get("retry-after")
                retry_after_int = int(retry_after) if retry_after else None
                logger.error(
                    "llama.cpp rate limit exceeded during streaming",
                    extra={"retry_after": retry_after_int},
                    exc_info=True,
                )
                raise LLMRateLimitError(
                    message=f"llama.cpp rate limit exceeded: {error_body}",
                    retry_after=retry_after_int,
                ) from e

            # Generic HTTP error
            logger.error(
                "llama.cpp HTTP error during streaming",
                extra={"status_code": e.response.status_code, "error": error_body},
                exc_info=True,
            )
            raise LLMAPIError(
                message=f"llama.cpp HTTP error: {error_body}",
                status_code=e.response.status_code,
                response_body=error_body,
            ) from e

        except httpx.HTTPError as e:
            logger.error("llama.cpp connection error during streaming", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp connection error: {e}",
            ) from e

        except Exception as e:
            logger.error("llama.cpp unexpected error during streaming", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp unexpected error: {e}",
            ) from e

    async def count_tokens(self, text: str) -> int:
        """Count tokens in text using character-based estimation.

        llama.cpp doesn't expose a tokenization endpoint in the standard API,
        so we use a character-based estimation. This is approximate but sufficient
        for most use cases.

        For exact token counts, consider using the llama.cpp tokenize endpoint
        if available in your deployment.

        Args:
            text: Text to count tokens for.

        Returns:
            Estimated token count.
        """
        # Rough estimate: ~4 characters per token for English text
        # This matches the base class implementation
        estimated_tokens = len(text) // 4
        logger.debug(
            "Estimated token count for text",
            extra={"text_length": len(text), "estimated_tokens": estimated_tokens},
        )
        return estimated_tokens

    async def estimate_cost(self, tokens: TokenUsage) -> float:
        """Estimate cost for token usage.

        llama.cpp is self-hosted, so there's no API cost.
        Always returns 0.0.

        Args:
            tokens: Token usage information.

        Returns:
            Cost estimate (always 0.0 for self-hosted).
        """
        # Self-hosted inference has no cost
        return 0.0

    async def get_server_health(self) -> dict[str, Any]:
        """Get llama.cpp server health status.

        Returns:
            Server health information including available slots, model info, etc.

        Raises:
            LLMAPIError: If health check fails.
        """
        self._ensure_client()

        try:
            assert self.http_client is not None  # For type checker
            response = await self.http_client.get(f"{self.config.endpoint}/health")
            response.raise_for_status()
            health_data = response.json()

            logger.debug(
                "llama.cpp health check successful",
                extra={"health_data": health_data},
            )

            return health_data

        except httpx.HTTPError as e:
            logger.error("llama.cpp health check failed", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp health check failed: {e}",
            ) from e

    async def get_server_props(self) -> dict[str, Any]:
        """Get llama.cpp server properties.

        Returns model information, context size, and other server configuration.

        Returns:
            Server properties including model info, context size, etc.

        Raises:
            LLMAPIError: If properties request fails.
        """
        self._ensure_client()

        try:
            assert self.http_client is not None  # For type checker
            response = await self.http_client.get(f"{self.config.endpoint}/props")
            response.raise_for_status()
            props_data = response.json()

            logger.debug(
                "llama.cpp properties retrieved",
                extra={"props_data": props_data},
            )

            return props_data

        except httpx.HTTPError as e:
            logger.error("llama.cpp properties request failed", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp properties request failed: {e}",
            ) from e

    async def generate_embedding(self, text: str) -> list[float]:
        """Generate embedding vector for a single text.

        Requires llama.cpp server to be started with --embeddings flag.

        Args:
            text: Text to generate embedding for.

        Returns:
            Embedding vector as a list of floats.

        Raises:
            LLMAPIError: If embedding request fails or server doesn't support embeddings.
        """
        embeddings = await self.generate_embeddings([text])
        return embeddings[0]

    async def generate_embeddings(self, texts: list[str]) -> list[list[float]]:
        """Generate embedding vectors for multiple texts.

        Requires llama.cpp server to be started with --embeddings flag.
        Uses the OpenAI-compatible /v1/embeddings endpoint.

        Args:
            texts: List of texts to generate embeddings for.

        Returns:
            List of embedding vectors, one per input text.

        Raises:
            LLMAPIError: If embedding request fails or server doesn't support embeddings.

        Example:
            ```python
            config = LlamaCppConfig(endpoint="http://localhost:9000")
            async with LlamaCppClient(config) as client:
                embeddings = await client.generate_embeddings([
                    "First document text",
                    "Second document text"
                ])
                print(f"Got {len(embeddings)} embeddings")
                print(f"Embedding dimension: {len(embeddings[0])}")
            ```
        """
        self._ensure_client()

        payload = {
            "input": texts,
            "model": self.config.model,
        }

        logger.debug(
            "Sending llama.cpp embeddings request",
            extra={
                "endpoint": self.config.endpoint,
                "num_texts": len(texts),
            },
        )

        try:
            assert self.http_client is not None  # For type checker
            response = await self.http_client.post(
                f"{self.config.endpoint}/v1/embeddings",
                json=payload,
            )
            response.raise_for_status()
            result = response.json()

            # Check for error response (e.g., embeddings not enabled)
            if "detail" in result:
                error_detail = result["detail"]
                if isinstance(error_detail, str) and "not support embeddings" in error_detail:
                    raise LLMAPIError(
                        message=(
                            "llama.cpp server does not support embeddings. "
                            "Start the server with --embeddings flag."
                        ),
                        status_code=501,
                    )
                raise LLMAPIError(
                    message=f"llama.cpp embeddings error: {error_detail}",
                )

            # Extract embeddings from OpenAI-compatible response
            # Response format: {"object": "list", "data": [{"embedding": [...], "index": 0}, ...]}
            data = result.get("data", [])
            embeddings = [item["embedding"] for item in sorted(data, key=lambda x: x["index"])]

            # Get usage info if available
            usage = result.get("usage", {})
            prompt_tokens = usage.get("prompt_tokens", 0)
            total_tokens = usage.get("total_tokens", prompt_tokens)

            logger.info(
                "llama.cpp embeddings successful",
                extra={
                    "num_embeddings": len(embeddings),
                    "embedding_dim": len(embeddings[0]) if embeddings else 0,
                    "prompt_tokens": prompt_tokens,
                    "total_tokens": total_tokens,
                },
            )

            return embeddings

        except httpx.HTTPStatusError as e:
            error_body = e.response.text

            # Check for embeddings not supported error
            if "not support embeddings" in error_body.lower() or e.response.status_code == 501:
                logger.error(
                    "llama.cpp embeddings not supported",
                    extra={"error": error_body},
                )
                raise LLMAPIError(
                    message=(
                        "llama.cpp server does not support embeddings. "
                        "Start the server with --embeddings flag."
                    ),
                    status_code=501,
                    response_body=error_body,
                ) from e

            logger.error(
                "llama.cpp embeddings HTTP error",
                extra={"status_code": e.response.status_code, "error": error_body},
                exc_info=True,
            )
            raise LLMAPIError(
                message=f"llama.cpp embeddings HTTP error: {error_body}",
                status_code=e.response.status_code,
                response_body=error_body,
            ) from e

        except httpx.HTTPError as e:
            logger.error("llama.cpp embeddings connection error", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp embeddings connection error: {e}",
            ) from e

        except Exception as e:
            logger.error("llama.cpp embeddings unexpected error", exc_info=True)
            raise LLMAPIError(
                message=f"llama.cpp embeddings unexpected error: {e}",
            ) from e

    async def get_embedding_dimension(self) -> int:
        """Get the embedding dimension for the current model.

        Generates a test embedding to determine the dimension.
        Requires llama.cpp server to be started with --embeddings flag.

        Returns:
            Embedding dimension (number of floats per embedding).

        Raises:
            LLMAPIError: If embedding request fails.
        """
        test_embedding = await self.generate_embedding("test")
        return len(test_embedding)
