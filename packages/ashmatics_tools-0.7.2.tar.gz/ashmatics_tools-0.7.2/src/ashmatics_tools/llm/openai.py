# Copyright 2025 Asher Informatics PBC
"""OpenAI client implementation.

This module provides integration with OpenAI's direct API.
"""

import logging
import os
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openai import (
    APIConnectionError,
    APIStatusError,
    AsyncOpenAI,
)
from openai import (
    RateLimitError as OpenAIRateLimitError,
)

from .base import (
    BaseLLMClient,
    LLMAPIError,
    LLMContextLengthError,
    LLMMessage,
    LLMRateLimitError,
    LLMResponse,
    StreamChunk,
    TokenUsage,
)

logger = logging.getLogger(__name__)


@dataclass
class OpenAIConfig:
    """Configuration for OpenAI client.

    Attributes:
        api_key: OpenAI API key
        model: Model to use (e.g., 'gpt-4', 'gpt-3.5-turbo')
        organization: Optional organization ID
        max_retries: Maximum number of retries for failed requests
        timeout: Request timeout in seconds
    """

    api_key: str | None = None
    model: str = "gpt-4"
    organization: str | None = None
    max_retries: int = 3
    timeout: float = 60.0

    def __post_init__(self):
        """Validate configuration and load from environment if needed."""
        # Load from environment if not provided
        if not self.api_key:
            self.api_key = os.getenv("OPENAI_API_KEY")

        if not self.organization:
            self.organization = os.getenv("OPENAI_ORGANIZATION")

        # Validate required fields
        if not self.api_key:
            raise ValueError(
                "OpenAI API key must be provided via 'api_key' parameter "
                "or OPENAI_API_KEY environment variable"
            )


class OpenAIClient(BaseLLMClient):
    """Client for OpenAI API.

    Example:
        ```python
        from ashmatics_tools.llm import OpenAIClient, OpenAIConfig

        config = OpenAIConfig(
            api_key="sk-...",
            model="gpt-4"
        )

        async with OpenAIClient(config) as client:
            response = await client.complete(
                prompt="What is asthma?",
                temperature=0.7,
                max_tokens=500
            )
            print(response.text)
        ```
    """

    # Pricing per 1K tokens (as of 2025-12-28) - update as needed
    PRICING = {
            # Legacy models
            "gpt-4": {"prompt": 0.03, "completion": 0.06},
            "gpt-4-32k": {"prompt": 0.06, "completion": 0.12},
            "gpt-4-turbo": {"prompt": 0.01, "completion": 0.03},
            "gpt-4-turbo-preview": {"prompt": 0.01, "completion": 0.03},
            "gpt-3.5-turbo": {"prompt": 0.0005, "completion": 0.0015},
            "gpt-3.5-turbo-16k": {"prompt": 0.003, "completion": 0.004},
            
            # GPT-4o series (Global deployment)
            "gpt-4o": {"prompt": 0.0025, "completion": 0.01},
            "gpt-4o-2024-08-06": {"prompt": 0.0025, "completion": 0.01},
            "gpt-4o-2024-11-20": {"prompt": 0.0025, "completion": 0.01},
            "gpt-4o-mini": {"prompt": 0.00015, "completion": 0.0006},
            
            # GPT-4.1 series (Global deployment)
            "gpt-4.1": {"prompt": 0.002, "completion": 0.008},
            "gpt-4.1-mini": {"prompt": 0.0004, "completion": 0.0016},
            "gpt-4.1-nano": {"prompt": 0.0001, "completion": 0.0004},
            
            # Reasoning models (o-series)
            "o1": {"prompt": 0.015, "completion": 0.06},
            "o1-preview": {"prompt": 0.015, "completion": 0.06},
            "o1-mini": {"prompt": 0.0011, "completion": 0.0044},
            "o3": {"prompt": 0.002, "completion": 0.008},
            "o3-mini": {"prompt": 0.0011, "completion": 0.0044},
            "o4-mini": {"prompt": 0.0011, "completion": 0.0044},
            
            # Embedding models
            "text-embedding-3-large": {"prompt": 0.00013, "completion": 0.0},
            "text-embedding-3-small": {"prompt": 0.00002, "completion": 0.0},
            "text-embedding-ada-002": {"prompt": 0.0001, "completion": 0.0},
    }

    def __init__(self, config: OpenAIConfig):
        """Initialize OpenAI client.

        Args:
            config: OpenAI configuration
        """
        self.config = config
        self.client: AsyncOpenAI | None = None

        logger.info(
            "Initialized OpenAI client",
            extra={
                "model": config.model,
                "organization": config.organization,
            },
        )

    async def __aenter__(self):
        """Enter the async context manager and create the client."""
        self.client = AsyncOpenAI(
            api_key=self.config.api_key,
            organization=self.config.organization,
            max_retries=self.config.max_retries,
            timeout=self.config.timeout,
        )
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit the async context manager and close the client."""
        if self.client:
            await self.client.close()

    def _ensure_client(self):
        """Ensure the client is initialized."""
        if not self.client:
            raise RuntimeError(
                "OpenAIClient must be used as an async context manager "
                "(async with OpenAIClient(...) as client:)"
            )

    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion for a single prompt.

        Args:
            prompt: The input prompt text
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters (top_p, frequency_penalty, presence_penalty, etc.)

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMAPIError: If the API request fails
            LLMRateLimitError: If rate limit is exceeded
            LLMContextLengthError: If input exceeds context length
        """
        self._ensure_client()

        try:
            logger.debug(
                "Sending completion request",
                extra={
                    "prompt_length": len(prompt),
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )

            response = await self.client.completions.create(
                model=self.config.model,
                prompt=prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                **kwargs,
            )

            # Extract response data
            choice = response.choices[0]
            text = choice.text
            finish_reason = choice.finish_reason

            # Extract token usage
            usage = response.usage
            tokens = TokenUsage(
                prompt_tokens=usage.prompt_tokens,
                completion_tokens=usage.completion_tokens,
                total_tokens=usage.total_tokens,
                estimated_cost=await self.estimate_cost(
                    TokenUsage(
                        prompt_tokens=usage.prompt_tokens,
                        completion_tokens=usage.completion_tokens,
                        total_tokens=usage.total_tokens,
                    )
                ),
            )

            logger.info(
                "Completion request successful",
                extra={
                    "tokens_used": tokens.total_tokens,
                    "estimated_cost": tokens.estimated_cost,
                    "finish_reason": finish_reason,
                },
            )

            return LLMResponse(
                text=text,
                tokens=tokens,
                model=self.config.model,
                finish_reason=finish_reason,
                metadata={"response_id": response.id},
            )

        except OpenAIRateLimitError as e:
            logger.warning("Rate limit exceeded", exc_info=True)
            # Try to extract retry_after from headers
            retry_after = None
            if hasattr(e, "response") and e.response:
                retry_after = e.response.headers.get("retry-after")
                if retry_after:
                    retry_after = int(retry_after)
            raise LLMRateLimitError(message=str(e), retry_after=retry_after)
        except APIStatusError as e:
            if e.status_code == 400 and "context_length_exceeded" in str(e):
                logger.error("Context length exceeded", exc_info=True)
                raise LLMContextLengthError(message=str(e))
            logger.error("API status error", exc_info=True)
            raise LLMAPIError(
                message=str(e),
                status_code=e.status_code,
                response_body=e.response.text if e.response else None,
            )
        except APIConnectionError as e:
            logger.error("API connection error", exc_info=True)
            raise LLMAPIError(message=f"Connection error: {e}")
        except Exception as e:
            logger.error("Unexpected error during completion", exc_info=True)
            raise LLMAPIError(message=f"Unexpected error: {e}")

    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion using chat-style messages.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters (top_p, frequency_penalty, presence_penalty, etc.)

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMAPIError: If the API request fails
            LLMRateLimitError: If rate limit is exceeded
            LLMContextLengthError: If input exceeds context length
        """
        self._ensure_client()

        try:
            logger.debug(
                "Sending chat completion request",
                extra={
                    "num_messages": len(messages),
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )

            # Convert LLMMessage to dict format
            message_dicts = [msg.to_dict() for msg in messages]

            response = await self.client.chat.completions.create(
                model=self.config.model,
                messages=message_dicts,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                **kwargs,
            )

            # Extract response data
            choice = response.choices[0]
            text = choice.message.content or ""
            finish_reason = choice.finish_reason

            # Extract token usage
            usage = response.usage
            tokens = TokenUsage(
                prompt_tokens=usage.prompt_tokens,
                completion_tokens=usage.completion_tokens,
                total_tokens=usage.total_tokens,
                estimated_cost=await self.estimate_cost(
                    TokenUsage(
                        prompt_tokens=usage.prompt_tokens,
                        completion_tokens=usage.completion_tokens,
                        total_tokens=usage.total_tokens,
                    )
                ),
            )

            logger.info(
                "Chat completion request successful",
                extra={
                    "tokens_used": tokens.total_tokens,
                    "estimated_cost": tokens.estimated_cost,
                    "finish_reason": finish_reason,
                },
            )

            return LLMResponse(
                text=text,
                tokens=tokens,
                model=self.config.model,
                finish_reason=finish_reason,
                metadata={"response_id": response.id},
            )

        except OpenAIRateLimitError as e:
            logger.warning("Rate limit exceeded", exc_info=True)
            retry_after = None
            if hasattr(e, "response") and e.response:
                retry_after = e.response.headers.get("retry-after")
                if retry_after:
                    retry_after = int(retry_after)
            raise LLMRateLimitError(message=str(e), retry_after=retry_after)
        except APIStatusError as e:
            if e.status_code == 400 and "context_length_exceeded" in str(e):
                logger.error("Context length exceeded", exc_info=True)
                raise LLMContextLengthError(message=str(e))
            logger.error("API status error", exc_info=True)
            raise LLMAPIError(
                message=str(e),
                status_code=e.status_code,
                response_body=e.response.text if e.response else None,
            )
        except APIConnectionError as e:
            logger.error("API connection error", exc_info=True)
            raise LLMAPIError(message=f"Connection error: {e}")
        except Exception as e:
            logger.error("Unexpected error during chat completion", exc_info=True)
            raise LLMAPIError(message=f"Unexpected error: {e}")

    async def stream_complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a chat completion, yielding chunks as they arrive.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters (top_p, frequency_penalty, presence_penalty, etc.)

        Yields:
            StreamChunk objects containing text fragments

        Raises:
            LLMAPIError: If the API request fails
            LLMRateLimitError: If rate limit is exceeded
            LLMContextLengthError: If input exceeds context length
        """
        self._ensure_client()

        try:
            logger.debug(
                "Starting streaming chat completion request",
                extra={
                    "num_messages": len(messages),
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )

            # Convert LLMMessage to dict format
            message_dicts = [msg.to_dict() for msg in messages]

            # Create streaming response
            stream = await self.client.chat.completions.create(
                model=self.config.model,
                messages=message_dicts,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                stream=True,
                **kwargs,
            )

            finish_reason = None
            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    choice = chunk.choices[0]
                    delta = choice.delta

                    # Get text content if available
                    text = delta.content if delta and delta.content else ""

                    # Track finish reason
                    if choice.finish_reason:
                        finish_reason = choice.finish_reason

                    # Yield chunk (skip empty chunks unless it's the final one)
                    if text or choice.finish_reason:
                        yield StreamChunk(
                            text=text,
                            finish_reason=finish_reason,
                            is_final=choice.finish_reason is not None,
                            metadata={"chunk_id": chunk.id} if chunk.id else {},
                        )

            logger.info(
                "Streaming chat completion finished",
                extra={"finish_reason": finish_reason},
            )

        except OpenAIRateLimitError as e:
            logger.warning("Rate limit exceeded during streaming", exc_info=True)
            retry_after = None
            if hasattr(e, "response") and e.response:
                retry_after = e.response.headers.get("retry-after")
                if retry_after:
                    retry_after = int(retry_after)
            raise LLMRateLimitError(message=str(e), retry_after=retry_after)
        except APIStatusError as e:
            if e.status_code == 400 and "context_length_exceeded" in str(e):
                logger.error("Context length exceeded", exc_info=True)
                raise LLMContextLengthError(message=str(e))
            logger.error("API status error during streaming", exc_info=True)
            raise LLMAPIError(
                message=str(e),
                status_code=e.status_code,
                response_body=e.response.text if e.response else None,
            )
        except APIConnectionError as e:
            logger.error("API connection error during streaming", exc_info=True)
            raise LLMAPIError(message=f"Connection error: {e}")
        except Exception as e:
            logger.error("Unexpected error during streaming", exc_info=True)
            raise LLMAPIError(message=f"Unexpected error: {e}")

    async def count_tokens(self, text: str) -> int:
        """Count the number of tokens in the text using tiktoken.

        Args:
            text: The text to tokenize

        Returns:
            Number of tokens
        """
        try:
            import tiktoken

            encoding = tiktoken.encoding_for_model(self.config.model)
            return len(encoding.encode(text))

        except ImportError:
            logger.warning(
                "tiktoken not available, using character-based estimation. "
                "Install tiktoken for accurate token counting."
            )
            return await super().count_tokens(text)
        except Exception as e:
            logger.warning(f"Error counting tokens: {e}, using estimation")
            return await super().count_tokens(text)

    async def estimate_cost(self, tokens: TokenUsage) -> float:
        """Estimate the cost of an API call based on token usage.

        Args:
            tokens: Token usage information

        Returns:
            Estimated cost in USD
        """
        # Try to find pricing for the model
        pricing = self.PRICING.get(self.config.model)

        if not pricing:
            # Try to find by prefix
            for model_prefix, model_pricing in self.PRICING.items():
                if self.config.model.startswith(model_prefix):
                    pricing = model_pricing
                    break

        if not pricing:
            logger.debug(f"No pricing information for model: {self.config.model}")
            return 0.0

        # Calculate cost: (tokens / 1000) * price_per_1k_tokens
        prompt_cost = (tokens.prompt_tokens / 1000) * pricing["prompt"]
        completion_cost = (tokens.completion_tokens / 1000) * pricing["completion"]

        return prompt_cost + completion_cost
