# Copyright 2025 Asher Informatics PBC
"""HuggingFace client implementations.

This module provides integration with HuggingFace models:
- HuggingFace Inference API (cloud-hosted models)
- Local HuggingFace models
- Fine-tuned models with LoRA/PEFT adapters

Note: This module requires optional dependencies. Install with:
    pip install "ashmatics-tools[huggingface]"
"""

import logging
import os
from dataclasses import dataclass
from typing import Any

try:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False

try:
    from peft import PeftModel

    PEFT_AVAILABLE = True
except ImportError:
    PEFT_AVAILABLE = False

import httpx

from .base import (
    BaseLLMClient,
    LLMAPIError,
    LLMMessage,
    LLMResponse,
    TokenUsage,
)

logger = logging.getLogger(__name__)


def _check_transformers():
    """Check if transformers is available."""
    if not TRANSFORMERS_AVAILABLE:
        raise ImportError(
            "HuggingFace support requires additional dependencies. "
            'Install with: pip install "ashmatics-tools[huggingface]"'
        )


def _check_peft():
    """Check if PEFT is available."""
    if not PEFT_AVAILABLE:
        raise ImportError(
            "Fine-tuned model support requires PEFT. "
            'Install with: pip install "ashmatics-tools[huggingface]"'
        )


@dataclass
class HuggingFaceInferenceConfig:
    """Configuration for HuggingFace Inference API.

    Attributes:
        endpoint_url: HuggingFace Inference API endpoint
        api_key: HuggingFace API key (or token)
        model_name: Model identifier (e.g., 'meta-llama/Llama-2-70b-chat-hf')
        timeout: Request timeout in seconds
        max_retries: Maximum number of retries
    """

    endpoint_url: str | None = None
    api_key: str | None = None
    model_name: str = "meta-llama/Llama-2-70b-chat-hf"
    timeout: float = 60.0
    max_retries: int = 3

    def __post_init__(self):
        """Validate configuration and load from environment if needed."""
        if not self.api_key:
            self.api_key = os.getenv("HF_API_KEY") or os.getenv("HUGGINGFACE_API_KEY")

        if not self.endpoint_url:
            # Default to HuggingFace Inference API
            self.endpoint_url = f"https://api-inference.huggingface.co/models/{self.model_name}"

        if not self.api_key:
            logger.warning(
                "No HuggingFace API key provided. "
                "Set HF_API_KEY or HUGGINGFACE_API_KEY environment variable "
                "or provide via api_key parameter."
            )


@dataclass
class HuggingFaceLocalConfig:
    """Configuration for local HuggingFace models.

    Attributes:
        model_name: Model identifier or path (e.g., 'meta-llama/Llama-2-7b-chat-hf')
        device: Device to use ('cuda', 'cpu', 'mps')
        torch_dtype: Torch dtype for model weights
        load_in_8bit: Whether to load model in 8-bit mode (requires bitsandbytes)
        load_in_4bit: Whether to load model in 4-bit mode (requires bitsandbytes)
        trust_remote_code: Whether to trust remote code (use with caution)
        max_memory: Optional max memory per device (e.g., {0: "10GB", "cpu": "30GB"})
    """

    model_name: str = "meta-llama/Llama-2-7b-chat-hf"
    device: str = "cuda"
    torch_dtype: torch.dtype = torch.float16 if TRANSFORMERS_AVAILABLE else None
    load_in_8bit: bool = False
    load_in_4bit: bool = False
    trust_remote_code: bool = False
    max_memory: dict[str, str] | None = None

    def __post_init__(self):
        """Validate configuration."""
        _check_transformers()

        if self.load_in_8bit or self.load_in_4bit:
            try:
                import bitsandbytes  # noqa: F401
            except ImportError:
                raise ImportError(
                    "Quantization requires bitsandbytes. "
                    'Install with: pip install "ashmatics-tools[huggingface]"'
                )


class HuggingFaceInferenceClient(BaseLLMClient):
    """Client for HuggingFace Inference API.

    This client supports cloud-hosted models via the HuggingFace Inference API.

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client, HuggingFaceInferenceConfig

        config = HuggingFaceInferenceConfig(
            model_name="meta-llama/Llama-2-70b-chat-hf",
            api_key="hf_..."
        )

        async with create_llm_client("huggingface_inference", config) as client:
            response = await client.complete("What is asthma?")
            print(response.text)
        ```
    """

    def __init__(self, config: HuggingFaceInferenceConfig):
        """Initialize HuggingFace Inference client.

        Args:
            config: HuggingFace Inference configuration
        """
        self.config = config
        self.http_client: httpx.AsyncClient | None = None

        logger.info(
            "Initialized HuggingFace Inference client",
            extra={
                "model": config.model_name,
                "endpoint": config.endpoint_url,
            },
        )

    async def __aenter__(self):
        """Enter the async context manager and create HTTP client."""
        self.http_client = httpx.AsyncClient(
            timeout=self.config.timeout,
            headers={
                "Authorization": f"Bearer {self.config.api_key}" if self.config.api_key else ""
            },
        )
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit the async context manager and close HTTP client."""
        if self.http_client:
            await self.http_client.aclose()

    def _ensure_client(self):
        """Ensure the HTTP client is initialized."""
        if not self.http_client:
            raise RuntimeError(
                "HuggingFaceInferenceClient must be used as an async context manager"
            )

    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion for a single prompt.

        Args:
            prompt: The input prompt text
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional HuggingFace parameters

        Returns:
            LLMResponse containing the generated text and metadata
        """
        self._ensure_client()

        try:
            payload = {
                "inputs": prompt,
                "parameters": {
                    "temperature": temperature,
                    "max_new_tokens": max_tokens,
                    "return_full_text": False,
                    **kwargs,
                },
            }

            if stop:
                payload["parameters"]["stop_sequences"] = stop

            logger.debug(
                "Sending inference request",
                extra={"prompt_length": len(prompt), "max_tokens": max_tokens},
            )

            response = await self.http_client.post(
                self.config.endpoint_url,
                json=payload,
            )

            response.raise_for_status()
            result = response.json()

            # HuggingFace Inference API returns different formats
            if isinstance(result, list) and len(result) > 0:
                generated_text = result[0].get("generated_text", "")
            elif isinstance(result, dict):
                generated_text = result.get("generated_text", "")
            else:
                generated_text = str(result)

            # Estimate token usage (no exact count from API)
            prompt_tokens = await self.count_tokens(prompt)
            completion_tokens = await self.count_tokens(generated_text)

            tokens = TokenUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
            )

            logger.info(
                "Inference request successful",
                extra={"estimated_tokens": tokens.total_tokens},
            )

            return LLMResponse(
                text=generated_text,
                tokens=tokens,
                model=self.config.model_name,
                finish_reason="stop",  # HF API doesn't provide this
                metadata={"endpoint": self.config.endpoint_url},
            )

        except httpx.HTTPStatusError as e:
            logger.error("HTTP status error", exc_info=True)
            raise LLMAPIError(
                message=f"HuggingFace API error: {e}",
                status_code=e.response.status_code,
                response_body=e.response.text,
            )
        except httpx.HTTPError as e:
            logger.error("HTTP error", exc_info=True)
            raise LLMAPIError(message=f"HTTP error: {e}")
        except Exception as e:
            logger.error("Unexpected error", exc_info=True)
            raise LLMAPIError(message=f"Unexpected error: {e}")

    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion using chat-style messages.

        Note: This converts messages to a single prompt string.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters

        Returns:
            LLMResponse containing the generated text and metadata
        """
        # Convert messages to prompt
        prompt = self._messages_to_prompt(messages)
        return await self.complete(prompt, temperature, max_tokens, stop, **kwargs)

    def _messages_to_prompt(self, messages: list[LLMMessage]) -> str:
        """Convert chat messages to a prompt string.

        This uses a simple format. For production, use model-specific templates.
        """
        prompt_parts = []
        for msg in messages:
            if msg.role == "system":
                prompt_parts.append(f"System: {msg.content}")
            elif msg.role == "user":
                prompt_parts.append(f"User: {msg.content}")
            elif msg.role == "assistant":
                prompt_parts.append(f"Assistant: {msg.content}")

        prompt_parts.append("Assistant:")
        return "\n\n".join(prompt_parts)


class HuggingFaceLocalClient(BaseLLMClient):
    """Client for local HuggingFace models.

    This client loads models locally for inference. Supports quantization
    and efficient loading strategies.

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client, HuggingFaceLocalConfig

        config = HuggingFaceLocalConfig(
            model_name="meta-llama/Llama-2-7b-chat-hf",
            device="cuda",
            load_in_8bit=True
        )

        async with create_llm_client("huggingface_local", config) as client:
            response = await client.complete("What is asthma?")
            print(response.text)
        ```
    """

    def __init__(self, config: HuggingFaceLocalConfig):
        """Initialize local HuggingFace client.

        Args:
            config: Local HuggingFace configuration
        """
        _check_transformers()

        self.config = config
        self._model = None
        self._tokenizer = None

        logger.info(
            "Initialized HuggingFace local client",
            extra={
                "model": config.model_name,
                "device": config.device,
                "load_in_8bit": config.load_in_8bit,
            },
        )

    def _load_model(self):
        """Lazy load the model and tokenizer."""
        if self._model is not None:
            return

        logger.info(f"Loading model: {self.config.model_name}")

        self._tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_name,
            trust_remote_code=self.config.trust_remote_code,
        )

        model_kwargs = {
            "torch_dtype": self.config.torch_dtype,
            "trust_remote_code": self.config.trust_remote_code,
        }

        if self.config.load_in_8bit:
            model_kwargs["load_in_8bit"] = True
        elif self.config.load_in_4bit:
            model_kwargs["load_in_4bit"] = True

        if self.config.max_memory:
            model_kwargs["max_memory"] = self.config.max_memory

        self._model = AutoModelForCausalLM.from_pretrained(self.config.model_name, **model_kwargs)

        if not self.config.load_in_8bit and not self.config.load_in_4bit:
            self._model = self._model.to(self.config.device)

        logger.info("Model loaded successfully")

    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion for a single prompt.

        Args:
            prompt: The input prompt text
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional generation parameters

        Returns:
            LLMResponse containing the generated text and metadata
        """
        self._load_model()

        try:
            logger.debug(
                "Generating completion",
                extra={"prompt_length": len(prompt), "max_tokens": max_tokens},
            )

            # Tokenize input
            inputs = self._tokenizer(prompt, return_tensors="pt").to(self.config.device)

            # Generate
            with torch.no_grad():
                outputs = self._model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temperature,
                    do_sample=temperature > 0,
                    **kwargs,
                )

            # Decode output
            generated_text = self._tokenizer.decode(
                outputs[0][inputs["input_ids"].shape[1] :], skip_special_tokens=True
            )

            # Calculate token usage
            prompt_tokens = inputs["input_ids"].shape[1]
            completion_tokens = outputs.shape[1] - prompt_tokens

            tokens = TokenUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=outputs.shape[1],
            )

            logger.info(
                "Generation successful",
                extra={"total_tokens": tokens.total_tokens},
            )

            return LLMResponse(
                text=generated_text,
                tokens=tokens,
                model=self.config.model_name,
                finish_reason="stop",
                metadata={"device": self.config.device},
            )

        except Exception as e:
            logger.error("Error during generation", exc_info=True)
            raise LLMAPIError(message=f"Generation error: {e}")

    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion using chat-style messages."""
        # Convert messages to prompt
        prompt = self._messages_to_prompt(messages)
        return await self.complete(prompt, temperature, max_tokens, stop, **kwargs)

    def _messages_to_prompt(self, messages: list[LLMMessage]) -> str:
        """Convert chat messages to a prompt string."""
        # Try to use tokenizer's chat template if available
        if hasattr(self._tokenizer, "apply_chat_template"):
            message_dicts = [msg.to_dict() for msg in messages]
            return self._tokenizer.apply_chat_template(
                message_dicts, tokenize=False, add_generation_prompt=True
            )

        # Fallback to simple format
        prompt_parts = []
        for msg in messages:
            if msg.role == "system":
                prompt_parts.append(f"System: {msg.content}")
            elif msg.role == "user":
                prompt_parts.append(f"User: {msg.content}")
            elif msg.role == "assistant":
                prompt_parts.append(f"Assistant: {msg.content}")

        prompt_parts.append("Assistant:")
        return "\n\n".join(prompt_parts)

    async def count_tokens(self, text: str) -> int:
        """Count tokens using the model's tokenizer."""
        self._load_model()
        return len(self._tokenizer.encode(text))


class HuggingFaceFineTunedClient(HuggingFaceLocalClient):
    """Client for fine-tuned HuggingFace models with LoRA/PEFT adapters.

    Example:
        ```python
        config = HuggingFaceFineTunedConfig(
            base_model="meta-llama/Llama-2-7b-chat-hf",
            adapter_path="/path/to/lora/adapter",
            device="cuda"
        )

        async with create_llm_client("huggingface_finetuned", config) as client:
            response = await client.complete("Classify this medical device...")
            print(response.text)
        ```
    """

    def __init__(self, base_model: str, adapter_path: str, **kwargs):
        """Initialize fine-tuned model client.

        Args:
            base_model: Base model identifier
            adapter_path: Path to LoRA/PEFT adapter
            **kwargs: Additional config options (device, load_in_8bit, etc.)
        """
        _check_peft()

        # Create config for base model
        config = HuggingFaceLocalConfig(model_name=base_model, **kwargs)
        super().__init__(config)

        self.adapter_path = adapter_path

        logger.info(
            "Initialized fine-tuned HuggingFace client",
            extra={"base_model": base_model, "adapter_path": adapter_path},
        )

    def _load_model(self):
        """Load the base model and apply the adapter."""
        if self._model is not None:
            return

        # Load base model first
        super()._load_model()

        # Load and apply adapter
        logger.info(f"Loading adapter from: {self.adapter_path}")
        self._model = PeftModel.from_pretrained(self._model, self.adapter_path)

        logger.info("Adapter loaded successfully")
