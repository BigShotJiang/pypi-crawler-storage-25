# Copyright 2025 Asher Informatics PBC
"""Azure AI Foundry client implementation.

This module provides integration with Azure AI Foundry using the azure-ai-inference SDK.
Supports the full model catalog including OpenAI, Meta Llama, Mistral, Cohere, and more.

Note: This module requires optional dependencies. Install with:
    pip install "ashmatics-tools[azure-ai]"
"""

import logging
import os
from dataclasses import dataclass
from typing import Any

try:
    from azure.ai.inference import ChatCompletionsClient
    from azure.ai.inference.models import AssistantMessage, SystemMessage, UserMessage
    from azure.core.credentials import AzureKeyCredential

    AZURE_AI_AVAILABLE = True
except ImportError:
    AZURE_AI_AVAILABLE = False

from .base import (
    BaseLLMClient,
    LLMAPIError,
    LLMMessage,
    LLMResponse,
    TokenUsage,
)

logger = logging.getLogger(__name__)


def _check_azure_ai():
    """Check if azure-ai-inference is available."""
    if not AZURE_AI_AVAILABLE:
        raise ImportError(
            "Azure AI Foundry support requires additional dependencies. "
            'Install with: pip install "ashmatics-tools[azure-ai]"'
        )


@dataclass
class AzureAIConfig:
    """Configuration for Azure AI Foundry client.

    Attributes:
        endpoint: Azure AI Foundry endpoint URL (e.g., https://my-endpoint.inference.ai.azure.com)
        api_key: Azure AI API key
        model: Model to use (e.g., 'gpt-4', 'llama-2-70b', 'mistral-large')
        max_retries: Maximum number of retries for failed requests
        timeout: Request timeout in seconds
    """

    endpoint: str | None = None
    api_key: str | None = None
    model: str = "gpt-4"
    max_retries: int = 3
    timeout: float = 60.0

    def __post_init__(self):
        """Validate configuration and load from environment if needed."""
        _check_azure_ai()

        # Load from environment if not provided
        if not self.endpoint:
            self.endpoint = os.getenv("AZURE_AI_ENDPOINT")
        if not self.api_key:
            self.api_key = os.getenv("AZURE_AI_API_KEY")

        # Validate required fields
        if not self.endpoint:
            raise ValueError(
                "Azure AI endpoint must be provided via 'endpoint' parameter "
                "or AZURE_AI_ENDPOINT environment variable"
            )

        if not self.api_key:
            raise ValueError(
                "Azure AI API key must be provided via 'api_key' parameter "
                "or AZURE_AI_API_KEY environment variable"
            )


class AzureAIClient(BaseLLMClient):
    """Client for Azure AI Foundry.

    This client supports the full Azure AI Foundry model catalog including:
    - OpenAI models (GPT-4, GPT-3.5)
    - Meta Llama models (Llama-2, Llama-3)
    - Mistral models (Mistral-7B, Mistral-Large)
    - Cohere models
    - And any other models deployed in Azure AI Foundry

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client, AzureAIConfig

        config = AzureAIConfig(
            endpoint="https://my-endpoint.inference.ai.azure.com",
            api_key="...",
            model="llama-2-70b-chat"
        )

        async with create_llm_client("azure_ai_foundry", config) as client:
            response = await client.complete("What is asthma?")
            print(response.text)
        ```
    """

    # Model pricing (examples - update as needed)
    PRICING = {
        "gpt-4": {"prompt": 0.03, "completion": 0.06},
        "gpt-3.5-turbo": {"prompt": 0.0005, "completion": 0.0015},
        "llama-2-70b": {"prompt": 0.001, "completion": 0.002},
        "mistral-large": {"prompt": 0.004, "completion": 0.012},
    }

    def __init__(self, config: AzureAIConfig):
        """Initialize Azure AI Foundry client.

        Args:
            config: Azure AI configuration
        """
        _check_azure_ai()

        self.config = config
        self.client: ChatCompletionsClient | None = None

        logger.info(
            "Initialized Azure AI Foundry client",
            extra={
                "endpoint": config.endpoint,
                "model": config.model,
            },
        )

    async def __aenter__(self):
        """Enter the async context manager and create the client."""
        self.client = ChatCompletionsClient(
            endpoint=self.config.endpoint,
            credential=AzureKeyCredential(self.config.api_key),
        )
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit the async context manager and close the client."""
        if self.client:
            self.client.close()

    def _ensure_client(self):
        """Ensure the client is initialized."""
        if not self.client:
            raise RuntimeError(
                "AzureAIClient must be used as an async context manager "
                "(async with AzureAIClient(...) as client:)"
            )

    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion for a single prompt.

        Args:
            prompt: The input prompt text
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMAPIError: If the API request fails
        """
        # Convert to messages format
        messages = [LLMMessage(role="user", content=prompt)]
        return await self.complete_with_messages(messages, temperature, max_tokens, stop, **kwargs)

    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion using chat-style messages.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMAPIError: If the API request fails
        """
        self._ensure_client()

        try:
            logger.debug(
                "Sending chat completion request",
                extra={
                    "num_messages": len(messages),
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )

            # Convert messages to Azure AI format
            azure_messages = []
            for msg in messages:
                if msg.role == "system":
                    azure_messages.append(SystemMessage(content=msg.content))
                elif msg.role == "user":
                    azure_messages.append(UserMessage(content=msg.content))
                elif msg.role == "assistant":
                    azure_messages.append(AssistantMessage(content=msg.content))

            # Make request
            response = self.client.complete(
                messages=azure_messages,
                model=self.config.model,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                **kwargs,
            )

            # Extract response
            text = response.choices[0].message.content or ""
            finish_reason = response.choices[0].finish_reason

            # Extract token usage
            usage = response.usage
            tokens = TokenUsage(
                prompt_tokens=usage.prompt_tokens,
                completion_tokens=usage.completion_tokens,
                total_tokens=usage.total_tokens,
                estimated_cost=await self.estimate_cost(
                    TokenUsage(
                        prompt_tokens=usage.prompt_tokens,
                        completion_tokens=usage.completion_tokens,
                        total_tokens=usage.total_tokens,
                    )
                ),
            )

            logger.info(
                "Chat completion request successful",
                extra={
                    "tokens_used": tokens.total_tokens,
                    "estimated_cost": tokens.estimated_cost,
                    "finish_reason": finish_reason,
                },
            )

            return LLMResponse(
                text=text,
                tokens=tokens,
                model=self.config.model,
                finish_reason=finish_reason,
                metadata={"response_id": response.id},
            )

        except Exception as e:
            logger.error("Azure AI API error", exc_info=True)
            raise LLMAPIError(message=f"Azure AI API error: {e}")

    async def count_tokens(self, text: str) -> int:
        """Count the number of tokens in the text.

        Note: Uses character-based estimation. For accurate counts,
        use model-specific tokenizers.

        Args:
            text: The text to tokenize

        Returns:
            Estimated number of tokens
        """
        # Character-based estimation
        # Different models have different tokenization, so this is approximate
        return len(text) // 4

    async def estimate_cost(self, tokens: TokenUsage) -> float:
        """Estimate the cost of an API call based on token usage.

        Args:
            tokens: Token usage information

        Returns:
            Estimated cost in USD
        """
        # Try to find pricing for the model
        pricing = None
        for model_prefix, model_pricing in self.PRICING.items():
            if self.config.model.startswith(model_prefix):
                pricing = model_pricing
                break

        if not pricing:
            logger.debug(f"No pricing information for model: {self.config.model}")
            return 0.0

        # Calculate cost: (tokens / 1000) * price_per_1k_tokens
        prompt_cost = (tokens.prompt_tokens / 1000) * pricing["prompt"]
        completion_cost = (tokens.completion_tokens / 1000) * pricing["completion"]

        return prompt_cost + completion_cost
