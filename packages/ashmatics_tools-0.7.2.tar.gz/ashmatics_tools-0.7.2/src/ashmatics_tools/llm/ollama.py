# Copyright 2025 Asher Informatics PBC
"""Ollama client implementation using the official Ollama Python SDK.

This module provides integration with Ollama inference servers using the official
ollama Python package. Supports local Ollama, Azure Container Apps (ACA),
Kubernetes (K8s), and bare metal deployments.

Features:
    - Chat completions with streaming
    - Embeddings (single and batch) with dimension control
    - Vision/image support in messages
    - Tool calling support
    - Model lifecycle management (pull, delete, copy, show)
    - Keep-alive control for model memory management

Requirements:
    pip install "ashmatics-tools[ollama]"

Example:
    ```python
    from ashmatics_tools.llm import create_llm_client, OllamaConfig

    config = OllamaConfig(
        endpoint="http://localhost:11434",
        model="llama3.2"
    )

    async with create_llm_client("ollama", config) as client:
        # Chat completion
        response = await client.complete("What is asthma?")
        print(response.text)

        # Embeddings
        embedding = await client.generate_embedding("Hello world")
        print(f"Embedding dimension: {len(embedding)}")

        # Vision
        response = await client.complete_with_vision(
            prompt="Describe this image",
            images=["path/to/image.jpg"]
        )
    ```
"""

from __future__ import annotations

import base64
import logging
import os
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .base import (
    BaseLLMClient,
    LLMAPIError,
    LLMMessage,
    LLMResponse,
    StreamChunk,
    TokenUsage,
)

if TYPE_CHECKING:
    from ollama import AsyncClient

logger = logging.getLogger(__name__)

# Check if ollama SDK is available
_OLLAMA_AVAILABLE = False
try:
    import ollama

    _OLLAMA_AVAILABLE = True
except ImportError:
    ollama = None  # type: ignore[assignment]


def _check_ollama_available() -> None:
    """Check if ollama SDK is available and raise helpful error if not."""
    if not _OLLAMA_AVAILABLE:
        raise ImportError(
            "The ollama package is required for OllamaClient. "
            "Install it with: pip install 'ashmatics-tools[ollama]' "
            "or: pip install ollama"
        )


@dataclass
class OllamaToolParameter:
    """Parameter definition for an Ollama tool.

    Attributes:
        name: Parameter name
        type: Parameter type (string, integer, boolean, etc.)
        description: Parameter description
        required: Whether the parameter is required
        enum: Optional list of allowed values
    """

    name: str
    type: str
    description: str
    required: bool = True
    enum: list[str] | None = None


@dataclass
class OllamaTool:
    """Tool definition for Ollama function calling.

    Attributes:
        name: Tool function name
        description: Description of what the tool does
        parameters: List of parameter definitions
    """

    name: str
    description: str
    parameters: list[OllamaToolParameter] = field(default_factory=list)

    def to_ollama_format(self) -> dict[str, Any]:
        """Convert to Ollama's tool format."""
        properties: dict[str, Any] = {}
        required_params: list[str] = []

        for param in self.parameters:
            prop: dict[str, Any] = {
                "type": param.type,
                "description": param.description,
            }
            if param.enum:
                prop["enum"] = param.enum
            properties[param.name] = prop
            if param.required:
                required_params.append(param.name)

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required_params,
                },
            },
        }


@dataclass
class OllamaToolCall:
    """Result of a tool call from the model.

    Attributes:
        name: Name of the tool that was called
        arguments: Arguments passed to the tool
    """

    name: str
    arguments: dict[str, Any]


@dataclass
class OllamaConfig:
    """Configuration for Ollama client.

    Attributes:
        endpoint: Ollama endpoint URL (e.g., http://localhost:11434)
        model: Model to use (e.g., 'llama3.2', 'mistral', 'codellama')
        timeout: Request timeout in seconds
        verify_ssl: Whether to verify SSL certificates
        keep_alive: How long to keep model in memory (e.g., '5m', '1h', '-1' for forever)
        embedding_model: Model to use for embeddings (defaults to main model)
        embedding_dimensions: Custom embedding dimensions (if model supports)
    """

    endpoint: str | None = None
    model: str = "llama3.2"
    timeout: float = 120.0
    verify_ssl: bool = True
    keep_alive: str | None = None
    embedding_model: str | None = None
    embedding_dimensions: int | None = None

    def __post_init__(self) -> None:
        """Validate configuration and load from environment if needed."""
        if not self.endpoint:
            self.endpoint = os.getenv("OLLAMA_ENDPOINT", "http://localhost:11434")

        # Normalize endpoint (remove trailing slash)
        if self.endpoint.endswith("/"):
            self.endpoint = self.endpoint[:-1]

        # Default embedding model to main model
        if not self.embedding_model:
            self.embedding_model = self.model

        logger.info(
            "Ollama config initialized",
            extra={
                "endpoint": self.endpoint,
                "model": self.model,
                "embedding_model": self.embedding_model,
            },
        )


class OllamaClient(BaseLLMClient):
    """Client for Ollama inference servers using the official SDK.

    Supports local and remote Ollama deployments with full feature set:
    - Chat completions with streaming
    - Embeddings with batch support
    - Vision/image understanding
    - Tool/function calling
    - Model management

    Example:
        ```python
        from ashmatics_tools.llm import create_llm_client, OllamaConfig

        config = OllamaConfig(
            endpoint="http://localhost:11434",
            model="llama3.2"
        )

        async with create_llm_client("ollama", config) as client:
            response = await client.complete("What is Python?")
            print(response.text)
        ```
    """

    def __init__(self, config: OllamaConfig) -> None:
        """Initialize Ollama client.

        Args:
            config: Ollama configuration
        """
        _check_ollama_available()
        self.config = config
        self._client: AsyncClient | None = None

        logger.info(
            "Initialized Ollama client",
            extra={
                "endpoint": config.endpoint,
                "model": config.model,
            },
        )

    async def __aenter__(self) -> OllamaClient:
        """Enter async context manager."""
        await self.start()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit async context manager."""
        await self.stop()

    async def start(self) -> None:
        """Initialize the Ollama AsyncClient."""
        if self._client is None:
            from ollama import AsyncClient

            self._client = AsyncClient(
                host=self.config.endpoint,
                timeout=self.config.timeout,
            )
            logger.debug("Started Ollama AsyncClient")

    async def stop(self) -> None:
        """Clean up resources."""
        # AsyncClient doesn't need explicit cleanup, but we clear the reference
        self._client = None
        logger.debug("Stopped Ollama client")

    def _ensure_client(self) -> AsyncClient:
        """Ensure client is initialized and return it."""
        if self._client is None:
            raise RuntimeError(
                "OllamaClient not started. Use 'async with OllamaClient(config):' "
                "or call 'await client.start()' first."
            )
        return self._client

    def _build_options(
        self,
        temperature: float,
        max_tokens: int,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Build Ollama options dict from parameters."""
        options: dict[str, Any] = {
            "temperature": temperature,
            "num_predict": max_tokens,
        }

        if stop:
            options["stop"] = stop

        # Pass through additional Ollama-specific options
        for key in [
            "top_k",
            "top_p",
            "repeat_penalty",
            "seed",
            "num_ctx",
            "num_batch",
            "num_gpu",
            "main_gpu",
            "low_vram",
            "f16_kv",
            "vocab_only",
            "use_mmap",
            "use_mlock",
            "num_thread",
        ]:
            if key in kwargs:
                options[key] = kwargs[key]

        return options

    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion for a single prompt.

        Args:
            prompt: Input prompt text
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum tokens to generate
            stop: Stop sequences
            **kwargs: Additional Ollama options

        Returns:
            LLMResponse with generated text
        """
        messages = [LLMMessage(role="user", content=prompt)]
        return await self.complete_with_messages(messages, temperature, max_tokens, stop, **kwargs)

    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion using chat-style messages.

        Args:
            messages: List of conversation messages
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stop: Stop sequences
            **kwargs: Additional Ollama options

        Returns:
            LLMResponse with generated text
        """
        client = self._ensure_client()

        try:
            ollama_messages = [msg.to_dict() for msg in messages]
            options = self._build_options(temperature, max_tokens, stop, **kwargs)

            # Build request kwargs
            request_kwargs: dict[str, Any] = {
                "model": self.config.model,
                "messages": ollama_messages,
                "options": options,
                "stream": False,
            }

            if self.config.keep_alive:
                request_kwargs["keep_alive"] = self.config.keep_alive

            logger.debug(
                "Sending Ollama chat request",
                extra={
                    "model": self.config.model,
                    "num_messages": len(messages),
                    "temperature": temperature,
                },
            )

            response = await client.chat(**request_kwargs)

            # Extract response data
            text = response.message.content or ""
            finish_reason = response.done_reason or "stop"

            # Token counts
            prompt_tokens = response.prompt_eval_count or 0
            completion_tokens = response.eval_count or 0

            tokens = TokenUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
                estimated_cost=0.0,  # Self-hosted
            )

            logger.info(
                "Ollama completion successful",
                extra={
                    "model": response.model,
                    "tokens": tokens.total_tokens,
                    "finish_reason": finish_reason,
                },
            )

            return LLMResponse(
                text=text,
                tokens=tokens,
                model=response.model,
                finish_reason=finish_reason,
                metadata={
                    "eval_duration_ns": response.eval_duration,
                    "load_duration_ns": response.load_duration,
                    "total_duration_ns": response.total_duration,
                },
            )

        except Exception as e:
            logger.error("Ollama chat error", exc_info=True)
            raise LLMAPIError(message=f"Ollama chat error: {e}") from e

    async def complete_with_vision(
        self,
        prompt: str,
        images: list[str | bytes | Path],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion with vision/image understanding.

        Requires a vision-capable model like llava, llama3.2-vision, etc.

        Args:
            prompt: Text prompt describing what to do with the image
            images: List of image paths, URLs, or bytes
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stop: Stop sequences
            **kwargs: Additional Ollama options

        Returns:
            LLMResponse with generated text about the image

        Example:
            ```python
            response = await client.complete_with_vision(
                prompt="What objects are in this image?",
                images=["photo.jpg", Path("/path/to/image.png")]
            )
            ```
        """
        client = self._ensure_client()

        try:
            # Convert images to base64
            image_data: list[str] = []
            for img in images:
                if isinstance(img, bytes):
                    image_data.append(base64.b64encode(img).decode("utf-8"))
                elif isinstance(img, (str, Path)):
                    path = Path(img)
                    if path.exists():
                        image_data.append(base64.b64encode(path.read_bytes()).decode("utf-8"))
                    else:
                        # Assume it's already base64 or a URL
                        image_data.append(str(img))

            options = self._build_options(temperature, max_tokens, stop, **kwargs)

            request_kwargs: dict[str, Any] = {
                "model": self.config.model,
                "messages": [{"role": "user", "content": prompt, "images": image_data}],
                "options": options,
                "stream": False,
            }

            if self.config.keep_alive:
                request_kwargs["keep_alive"] = self.config.keep_alive

            logger.debug(
                "Sending Ollama vision request",
                extra={"model": self.config.model, "num_images": len(images)},
            )

            response = await client.chat(**request_kwargs)

            text = response.message.content or ""
            finish_reason = response.done_reason or "stop"

            prompt_tokens = response.prompt_eval_count or 0
            completion_tokens = response.eval_count or 0

            tokens = TokenUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
                estimated_cost=0.0,
            )

            logger.info(
                "Ollama vision completion successful",
                extra={"model": response.model, "tokens": tokens.total_tokens},
            )

            return LLMResponse(
                text=text,
                tokens=tokens,
                model=response.model,
                finish_reason=finish_reason,
                metadata={
                    "eval_duration_ns": response.eval_duration,
                    "num_images": len(images),
                },
            )

        except Exception as e:
            logger.error("Ollama vision error", exc_info=True)
            raise LLMAPIError(message=f"Ollama vision error: {e}") from e

    async def complete_with_tools(
        self,
        messages: list[LLMMessage],
        tools: list[OllamaTool],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        **kwargs: Any,
    ) -> tuple[LLMResponse, list[OllamaToolCall]]:
        """Generate a completion with tool/function calling.

        The model may request to call one or more tools. Returns both the
        response and any tool calls the model wants to make.

        Args:
            messages: Conversation messages
            tools: Available tools the model can call
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            **kwargs: Additional Ollama options

        Returns:
            Tuple of (LLMResponse, list of tool calls)

        Example:
            ```python
            tools = [
                OllamaTool(
                    name="get_weather",
                    description="Get current weather for a location",
                    parameters=[
                        OllamaToolParameter(
                            name="location",
                            type="string",
                            description="City name"
                        )
                    ]
                )
            ]

            response, tool_calls = await client.complete_with_tools(
                messages=[LLMMessage(role="user", content="What's the weather in NYC?")],
                tools=tools
            )

            for call in tool_calls:
                print(f"Tool: {call.name}, Args: {call.arguments}")
            ```
        """
        client = self._ensure_client()

        try:
            ollama_messages = [msg.to_dict() for msg in messages]
            ollama_tools = [tool.to_ollama_format() for tool in tools]
            options = self._build_options(temperature, max_tokens, **kwargs)

            request_kwargs: dict[str, Any] = {
                "model": self.config.model,
                "messages": ollama_messages,
                "tools": ollama_tools,
                "options": options,
                "stream": False,
            }

            if self.config.keep_alive:
                request_kwargs["keep_alive"] = self.config.keep_alive

            logger.debug(
                "Sending Ollama tool call request",
                extra={
                    "model": self.config.model,
                    "num_tools": len(tools),
                },
            )

            response = await client.chat(**request_kwargs)

            text = response.message.content or ""
            finish_reason = response.done_reason or "stop"

            prompt_tokens = response.prompt_eval_count or 0
            completion_tokens = response.eval_count or 0

            tokens = TokenUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
                estimated_cost=0.0,
            )

            # Extract tool calls from response
            tool_calls: list[OllamaToolCall] = []
            if response.message.tool_calls:
                for tc in response.message.tool_calls:
                    tool_calls.append(
                        OllamaToolCall(
                            name=tc.function.name,
                            arguments=tc.function.arguments,
                        )
                    )

            logger.info(
                "Ollama tool completion successful",
                extra={
                    "model": response.model,
                    "tokens": tokens.total_tokens,
                    "num_tool_calls": len(tool_calls),
                },
            )

            llm_response = LLMResponse(
                text=text,
                tokens=tokens,
                model=response.model,
                finish_reason=finish_reason,
                metadata={"tool_calls": len(tool_calls)},
            )

            return llm_response, tool_calls

        except Exception as e:
            logger.error("Ollama tool call error", exc_info=True)
            raise LLMAPIError(message=f"Ollama tool call error: {e}") from e

    async def stream_complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a chat completion, yielding chunks as they arrive.

        Args:
            messages: Conversation messages
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stop: Stop sequences
            **kwargs: Additional Ollama options

        Yields:
            StreamChunk objects containing text fragments
        """
        client = self._ensure_client()

        try:
            ollama_messages = [msg.to_dict() for msg in messages]
            options = self._build_options(temperature, max_tokens, stop, **kwargs)

            request_kwargs: dict[str, Any] = {
                "model": self.config.model,
                "messages": ollama_messages,
                "options": options,
                "stream": True,
            }

            if self.config.keep_alive:
                request_kwargs["keep_alive"] = self.config.keep_alive

            logger.debug(
                "Starting Ollama streaming request",
                extra={"model": self.config.model, "num_messages": len(messages)},
            )

            finish_reason: str | None = None
            async for chunk in await client.chat(**request_kwargs):
                text = chunk.message.content or ""
                is_done = chunk.done

                if is_done:
                    finish_reason = chunk.done_reason or "stop"

                if text or is_done:
                    yield StreamChunk(
                        text=text,
                        finish_reason=finish_reason,
                        is_final=is_done,
                        metadata={
                            "model": chunk.model,
                            "eval_count": chunk.eval_count,
                        }
                        if is_done
                        else {},
                    )

            logger.info(
                "Ollama streaming completed",
                extra={"finish_reason": finish_reason},
            )

        except Exception as e:
            logger.error("Ollama streaming error", exc_info=True)
            raise LLMAPIError(message=f"Ollama streaming error: {e}") from e

    # =========================================================================
    # EMBEDDINGS
    # =========================================================================

    async def generate_embedding(self, text: str) -> list[float]:
        """Generate embedding vector for a single text.

        Args:
            text: Text to embed

        Returns:
            Embedding vector as list of floats
        """
        embeddings = await self.generate_embeddings([text])
        return embeddings[0]

    async def generate_embeddings(self, texts: list[str]) -> list[list[float]]:
        """Generate embedding vectors for multiple texts.

        Uses batch embedding for efficiency.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors

        Example:
            ```python
            embeddings = await client.generate_embeddings([
                "First document",
                "Second document"
            ])
            print(f"Got {len(embeddings)} embeddings")
            print(f"Dimension: {len(embeddings[0])}")
            ```
        """
        client = self._ensure_client()

        try:
            logger.debug(
                "Generating Ollama embeddings",
                extra={
                    "model": self.config.embedding_model,
                    "num_texts": len(texts),
                },
            )

            # Build embed kwargs
            embed_kwargs: dict[str, Any] = {
                "model": self.config.embedding_model,
                "input": texts,
            }

            # Add custom dimensions if specified
            if self.config.embedding_dimensions:
                embed_kwargs["options"] = {"num_ctx": self.config.embedding_dimensions}

            response = await client.embed(**embed_kwargs)

            # Cast to proper type (SDK returns list[Sequence[float]])
            embeddings: list[list[float]] = [list(emb) for emb in response.embeddings]

            logger.info(
                "Ollama embeddings successful",
                extra={
                    "num_embeddings": len(embeddings),
                    "dimension": len(embeddings[0]) if embeddings else 0,
                },
            )

            return embeddings

        except Exception as e:
            logger.error("Ollama embedding error", exc_info=True)
            raise LLMAPIError(message=f"Ollama embedding error: {e}") from e

    async def get_embedding_dimension(self) -> int:
        """Get the embedding dimension for the configured model.

        Returns:
            Number of dimensions in the embedding vector
        """
        test_embedding = await self.generate_embedding("test")
        return len(test_embedding)

    # =========================================================================
    # MODEL MANAGEMENT
    # =========================================================================

    async def list_models(self) -> list[dict[str, Any]]:
        """List available models on the Ollama server.

        Returns:
            List of model info dicts with name, size, modified date, etc.
        """
        client = self._ensure_client()

        try:
            response = await client.list()
            models = [
                {
                    "name": m.model,
                    "size": m.size,
                    "modified_at": m.modified_at,
                    "digest": m.digest,
                    "details": m.details.model_dump() if m.details else {},
                }
                for m in response.models
            ]

            logger.info(f"Listed {len(models)} Ollama models")
            return models

        except Exception as e:
            logger.error("Error listing Ollama models", exc_info=True)
            raise LLMAPIError(message=f"Error listing models: {e}") from e

    async def list_model_names(self) -> list[str]:
        """List just the names of available models.

        Returns:
            List of model names
        """
        models = await self.list_models()
        return [m["name"] for m in models]

    async def pull_model(self, model: str, *, stream: bool = False) -> None:
        """Pull a model from the Ollama library.

        Args:
            model: Model name to pull (e.g., 'llama3.2', 'mistral')
            stream: Whether to stream progress (currently logs progress)
        """
        client = self._ensure_client()

        try:
            logger.info(f"Pulling Ollama model: {model}")

            if stream:
                async for progress in await client.pull(model, stream=True):
                    if progress.status:
                        logger.debug(f"Pull progress: {progress.status}")
            else:
                await client.pull(model, stream=False)

            logger.info(f"Successfully pulled model: {model}")

        except Exception as e:
            logger.error(f"Error pulling model {model}", exc_info=True)
            raise LLMAPIError(message=f"Error pulling model: {e}") from e

    async def delete_model(self, model: str) -> None:
        """Delete a model from the Ollama server.

        Args:
            model: Model name to delete
        """
        client = self._ensure_client()

        try:
            await client.delete(model)
            logger.info(f"Deleted Ollama model: {model}")

        except Exception as e:
            logger.error(f"Error deleting model {model}", exc_info=True)
            raise LLMAPIError(message=f"Error deleting model: {e}") from e

    async def copy_model(self, source: str, destination: str) -> None:
        """Copy a model to a new name.

        Useful for creating named versions or aliases.

        Args:
            source: Source model name
            destination: Destination model name
        """
        client = self._ensure_client()

        try:
            await client.copy(source, destination)
            logger.info(f"Copied Ollama model: {source} -> {destination}")

        except Exception as e:
            logger.error(f"Error copying model {source}", exc_info=True)
            raise LLMAPIError(message=f"Error copying model: {e}") from e

    async def show_model(self, model: str | None = None) -> dict[str, Any]:
        """Show detailed information about a model.

        Args:
            model: Model name (defaults to configured model)

        Returns:
            Model information including license, parameters, template, etc.
        """
        client = self._ensure_client()
        model = model or self.config.model

        try:
            response = await client.show(model)

            info = {
                "license": response.license,
                "modelfile": response.modelfile,
                "parameters": response.parameters,
                "template": response.template,
                "details": response.details.model_dump() if response.details else {},
                "model_info": response.model_info,
            }

            logger.debug(f"Retrieved info for model: {model}")
            return info

        except Exception as e:
            logger.error(f"Error showing model {model}", exc_info=True)
            raise LLMAPIError(message=f"Error showing model: {e}") from e

    async def list_running_models(self) -> list[dict[str, Any]]:
        """List currently running/loaded models.

        Returns:
            List of running model info with memory usage, etc.
        """
        client = self._ensure_client()

        try:
            response = await client.ps()
            models = [
                {
                    "name": m.model,
                    "size": m.size,
                    "digest": m.digest,
                    "expires_at": m.expires_at,
                    "size_vram": m.size_vram,
                }
                for m in response.models
            ]

            logger.debug(f"Found {len(models)} running models")
            return models

        except Exception as e:
            logger.error("Error listing running models", exc_info=True)
            raise LLMAPIError(message=f"Error listing running models: {e}") from e

    # =========================================================================
    # UTILITY METHODS
    # =========================================================================

    async def count_tokens(self, text: str) -> int:
        """Estimate token count for text.

        Uses character-based estimation since Ollama doesn't expose tokenization.

        Args:
            text: Text to count tokens for

        Returns:
            Estimated token count
        """
        # Rough estimate: ~4 characters per token for English
        return len(text) // 4

    async def estimate_cost(self, tokens: TokenUsage) -> float:
        """Estimate cost for token usage.

        Ollama is self-hosted, so always returns 0.0.

        Args:
            tokens: Token usage information

        Returns:
            Cost estimate (always 0.0)
        """
        return 0.0

    async def check_health(self) -> bool:
        """Check if the Ollama server is healthy and responding.

        Returns:
            True if server is healthy, False otherwise
        """
        try:
            # Try to list models as a health check
            await self.list_models()
            return True
        except Exception:
            return False
