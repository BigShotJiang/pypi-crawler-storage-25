# Copyright 2025 Asher Informatics PBC
"""Context window management for LLM operations.

This module provides utilities for managing context windows across different
LLM providers, including:
- Model context limit definitions
- Context fitting algorithms
- Token estimation

Example:
    ```python
    from ashmatics_tools.llm.context import (
        ContextWindowManager,
        ModelContextLimits,
    )

    # Create manager for GPT-4 Turbo
    manager = ContextWindowManager(
        model_limits=ModelContextLimits.GPT4_TURBO,
        reserved_output=2000,
    )

    # Fit sources into available context
    fitted_sources = manager.fit_sources(
        sources=search_results,
        query="What are ISO 42001 requirements?",
        system_prompt=system_prompt,
    )
    ```
"""

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..vector_stores.base import SearchResult


class ModelFamily(str, Enum):
    """LLM model families for context management."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LLAMA = "llama"
    MISTRAL = "mistral"
    OTHER = "other"


@dataclass
class ModelContextLimits:
    """Context window limits for a specific model.

    Attributes:
        model_name: Model identifier
        max_tokens: Maximum context window size
        max_output_tokens: Maximum tokens for output/completion
        family: Model family for tokenizer selection
    """

    model_name: str
    max_tokens: int
    max_output_tokens: int
    family: ModelFamily = ModelFamily.OTHER

    # Common model presets
    @classmethod
    def GPT4_TURBO(cls) -> "ModelContextLimits":
        """GPT-4 Turbo (128k context)."""
        return cls(
            model_name="gpt-4-turbo",
            max_tokens=128000,
            max_output_tokens=4096,
            family=ModelFamily.OPENAI,
        )

    @classmethod
    def GPT4O(cls) -> "ModelContextLimits":
        """GPT-4o (128k context, 16k output)."""
        return cls(
            model_name="gpt-4o",
            max_tokens=128000,
            max_output_tokens=16384,
            family=ModelFamily.OPENAI,
        )

    @classmethod
    def GPT4O_MINI(cls) -> "ModelContextLimits":
        """GPT-4o mini (128k context, 16k output)."""
        return cls(
            model_name="gpt-4o-mini",
            max_tokens=128000,
            max_output_tokens=16384,
            family=ModelFamily.OPENAI,
        )

    @classmethod
    def GPT35_TURBO(cls) -> "ModelContextLimits":
        """GPT-3.5 Turbo (16k context)."""
        return cls(
            model_name="gpt-3.5-turbo",
            max_tokens=16385,
            max_output_tokens=4096,
            family=ModelFamily.OPENAI,
        )

    @classmethod
    def CLAUDE_SONNET(cls) -> "ModelContextLimits":
        """Claude Sonnet (200k context)."""
        return cls(
            model_name="claude-sonnet-4-20250514",
            max_tokens=200000,
            max_output_tokens=64000,
            family=ModelFamily.ANTHROPIC,
        )

    @classmethod
    def CLAUDE_OPUS(cls) -> "ModelContextLimits":
        """Claude Opus (200k context)."""
        return cls(
            model_name="claude-opus-4-20250514",
            max_tokens=200000,
            max_output_tokens=32000,
            family=ModelFamily.ANTHROPIC,
        )

    @classmethod
    def CLAUDE_HAIKU(cls) -> "ModelContextLimits":
        """Claude Haiku (200k context)."""
        return cls(
            model_name="claude-3-5-haiku-20241022",
            max_tokens=200000,
            max_output_tokens=8192,
            family=ModelFamily.ANTHROPIC,
        )

    @classmethod
    def LLAMA_70B(cls) -> "ModelContextLimits":
        """Llama 3 70B (8k context)."""
        return cls(
            model_name="llama-3-70b",
            max_tokens=8192,
            max_output_tokens=4096,
            family=ModelFamily.LLAMA,
        )

    @classmethod
    def LLAMA_8B(cls) -> "ModelContextLimits":
        """Llama 3 8B (8k context)."""
        return cls(
            model_name="llama-3-8b",
            max_tokens=8192,
            max_output_tokens=4096,
            family=ModelFamily.LLAMA,
        )

    @classmethod
    def MISTRAL_LARGE(cls) -> "ModelContextLimits":
        """Mistral Large (32k context)."""
        return cls(
            model_name="mistral-large",
            max_tokens=32768,
            max_output_tokens=8192,
            family=ModelFamily.MISTRAL,
        )

    @classmethod
    def from_model_name(cls, model_name: str) -> "ModelContextLimits":
        """Create limits from model name using best-guess defaults.

        Args:
            model_name: Model identifier string

        Returns:
            ModelContextLimits with reasonable defaults
        """
        model_lower = model_name.lower()

        # OpenAI models
        if "gpt-4o-mini" in model_lower:
            return cls.GPT4O_MINI()
        elif "gpt-4o" in model_lower:
            return cls.GPT4O()
        elif "gpt-4-turbo" in model_lower or "gpt-4-1106" in model_lower:
            return cls.GPT4_TURBO()
        elif "gpt-4" in model_lower:
            return cls(model_name, 8192, 4096, ModelFamily.OPENAI)
        elif "gpt-3.5" in model_lower:
            return cls.GPT35_TURBO()

        # Anthropic models
        elif "claude-3-5-sonnet" in model_lower or "claude-sonnet" in model_lower:
            return cls.CLAUDE_SONNET()
        elif "claude-3-opus" in model_lower or "claude-opus" in model_lower:
            return cls.CLAUDE_OPUS()
        elif "claude-3-5-haiku" in model_lower or "claude-haiku" in model_lower:
            return cls.CLAUDE_HAIKU()
        elif "claude" in model_lower:
            return cls(model_name, 100000, 4096, ModelFamily.ANTHROPIC)

        # Llama models
        elif "llama-3" in model_lower and "70b" in model_lower:
            return cls.LLAMA_70B()
        elif "llama-3" in model_lower:
            return cls.LLAMA_8B()
        elif "llama" in model_lower:
            return cls(model_name, 4096, 2048, ModelFamily.LLAMA)

        # Mistral models
        elif "mistral-large" in model_lower:
            return cls.MISTRAL_LARGE()
        elif "mistral" in model_lower:
            return cls(model_name, 8192, 4096, ModelFamily.MISTRAL)

        # Default fallback
        else:
            return cls(model_name, 4096, 2048, ModelFamily.OTHER)


class ContextWindowManager:
    """Manager for fitting content into LLM context windows.

    This class helps ensure that prompts, context, and expected output
    fit within a model's context window limits.

    Attributes:
        model_limits: Context limits for the target model
        reserved_output: Tokens reserved for output generation
    """

    def __init__(
        self,
        model_limits: ModelContextLimits,
        reserved_output: int = 2000,
    ):
        """Initialize context window manager.

        Args:
            model_limits: Model context window limits
            reserved_output: Tokens to reserve for output (default: 2000)
        """
        self.model_limits = model_limits
        self.reserved_output = min(reserved_output, model_limits.max_output_tokens)

    @property
    def available_context(self) -> int:
        """Available tokens for input (prompt + context)."""
        return self.model_limits.max_tokens - self.reserved_output

    def estimate_tokens(self, text: str) -> int:
        """Estimate token count for text.

        Uses a simple heuristic based on model family.
        For accurate counts, use the LLM client's count_tokens method.

        Args:
            text: Text to estimate tokens for

        Returns:
            Estimated token count
        """
        # Different models have different tokenization characteristics
        if self.model_limits.family == ModelFamily.ANTHROPIC:
            # Anthropic tends to have slightly fewer tokens per char
            return len(text) // 3
        elif self.model_limits.family in (ModelFamily.OPENAI, ModelFamily.MISTRAL):
            # OpenAI/Mistral ~4 chars per token
            return len(text) // 4
        else:
            # Conservative estimate for other models
            return len(text) // 3

    def fit_sources(
        self,
        sources: list["SearchResult"],
        query: str,
        system_prompt: str,
        token_counter: Callable[[str], int] | None = None,
    ) -> list["SearchResult"]:
        """Fit as many sources as possible into the available context.

        Sources are added in order (by rank) until the context window
        would be exceeded.

        Args:
            sources: List of SearchResults ordered by relevance
            query: User query
            system_prompt: System prompt template (may contain {context})
            token_counter: Optional accurate token counting function

        Returns:
            List of sources that fit within context limits
        """
        if not sources:
            return []

        # Use provided counter or fall back to estimation
        count_tokens = token_counter or self.estimate_tokens

        # Calculate fixed overhead (system prompt without context, query)
        # Note: system_prompt may have {context} placeholder
        base_prompt = system_prompt.replace("{context}", "")
        overhead = count_tokens(base_prompt) + count_tokens(query) + 100  # Buffer

        available = self.available_context - overhead
        if available <= 0:
            return []

        fitted_sources: list["SearchResult"] = []
        current_tokens = 0

        for source in sources:
            # Format source as it would appear in context
            source_text = self._format_source_for_counting(source)
            source_tokens = count_tokens(source_text)

            if current_tokens + source_tokens <= available:
                fitted_sources.append(source)
                current_tokens += source_tokens
            else:
                # Can't fit any more sources
                break

        return fitted_sources

    def _format_source_for_counting(self, source: "SearchResult") -> str:
        """Format a source for token counting (same format as context building)."""
        header_parts = [f"[Source]"]
        if source.source_uri:
            header_parts.append(f"URI: {source.source_uri}")
        if source.domain:
            header_parts.append(f"Domain: {source.domain}")

        header = " | ".join(header_parts)
        return f"{header}\n{source.content.strip()}\n\n"

    def check_fits(
        self,
        prompt: str,
        token_counter: Callable[[str], int] | None = None,
    ) -> tuple[bool, int, int]:
        """Check if a prompt fits within the context window.

        Args:
            prompt: Complete prompt to check
            token_counter: Optional accurate token counting function

        Returns:
            Tuple of (fits, prompt_tokens, available_tokens)
        """
        count_tokens = token_counter or self.estimate_tokens
        prompt_tokens = count_tokens(prompt)
        available = self.available_context

        return (prompt_tokens <= available, prompt_tokens, available)

    def get_stats(self) -> dict[str, Any]:
        """Get context window statistics.

        Returns:
            Dictionary with model limits and available space
        """
        return {
            "model_name": self.model_limits.model_name,
            "max_tokens": self.model_limits.max_tokens,
            "max_output_tokens": self.model_limits.max_output_tokens,
            "reserved_output": self.reserved_output,
            "available_context": self.available_context,
            "model_family": self.model_limits.family.value,
        }
