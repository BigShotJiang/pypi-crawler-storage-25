# Copyright 2025 Asher Informatics PBC
"""Azure OpenAI client implementation.

This module provides integration with Azure OpenAI Service (Azure AI Foundry).

Note (2025-12-30): Azure OpenAI chat models (GPT-4o, GPT-4, GPT-3.5-turbo, etc.)
only support the Chat Completions API (/chat/completions endpoint). The legacy
Completions API (/completions endpoint) is not available for these models on Azure.
As a result, the `complete()` method internally converts prompts to chat format
and uses the Chat Completions API for compatibility.
"""

import logging
import os
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openai import (
    APIConnectionError,
    APIStatusError,
    AsyncAzureOpenAI,
)
from openai import (
    RateLimitError as OpenAIRateLimitError,
)

from .base import (
    BaseLLMClient,
    LLMAPIError,
    LLMContextLengthError,
    LLMMessage,
    LLMRateLimitError,
    LLMResponse,
    StreamChunk,
    TokenUsage,
)

logger = logging.getLogger(__name__)


@dataclass
class AzureOpenAIConfig:
    """Configuration for Azure OpenAI client.

    Attributes:
        endpoint: Azure OpenAI endpoint URL (e.g., https://my-resource.openai.azure.com/)
        api_key: Azure OpenAI API key (optional if using Azure AD)
        deployment_name: Name of the deployed model
        api_version: API version to use (default: 2024-02-15-preview)
        azure_ad_token: Azure AD token for authentication (alternative to api_key)
        max_retries: Maximum number of retries for failed requests
        timeout: Request timeout in seconds
    """

    endpoint: str | None = None
    api_key: str | None = None
    deployment_name: str = "gpt-4"
    api_version: str = "2024-02-15-preview"
    azure_ad_token: str | None = None
    max_retries: int = 3
    timeout: float = 60.0

    def __post_init__(self):
        """Validate configuration and load from environment if needed."""
        # Load from environment if not provided
        if not self.endpoint:
            self.endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        if not self.api_key and not self.azure_ad_token:
            self.api_key = os.getenv("AZURE_OPENAI_API_KEY")

        # Validate required fields
        if not self.endpoint:
            raise ValueError(
                "Azure OpenAI endpoint must be provided via 'endpoint' parameter "
                "or AZURE_OPENAI_ENDPOINT environment variable"
            )

        if not self.api_key and not self.azure_ad_token:
            raise ValueError(
                "Azure OpenAI authentication must be provided via 'api_key' parameter, "
                "'azure_ad_token' parameter, or AZURE_OPENAI_API_KEY environment variable"
            )


class AzureOpenAIClient(BaseLLMClient):
    """Client for Azure OpenAI Service.

    This client supports both API key and Azure AD token authentication.
    It is designed to work with Azure AI Foundry deployments.

    Important (2025-12-30): Azure OpenAI chat models (GPT-4o, GPT-4, GPT-3.5-turbo,
    etc.) only support the Chat Completions API. The legacy Completions API is not
    available for these models. Therefore:

    - `complete(prompt)` internally wraps the prompt as a user message and calls
      the Chat Completions API. This provides a simple interface while maintaining
      compatibility with Azure's chat models.
    - `complete_with_messages(messages)` directly uses the Chat Completions API
      with full message history support (system, user, assistant roles).

    Both methods produce equivalent results for single-prompt use cases.

    Example:
        ```python
        from ashmatics_tools.llm import AzureOpenAIClient, AzureOpenAIConfig

        config = AzureOpenAIConfig(
            endpoint="https://my-resource.openai.azure.com/",
            api_key="sk-...",
            deployment_name="gpt-4o"
        )

        async with AzureOpenAIClient(config) as client:
            # Simple prompt (internally uses chat completions)
            response = await client.complete(
                prompt="What is asthma?",
                temperature=0.7,
                max_tokens=500
            )
            print(response.text)

            # Or with full message control
            from ashmatics_tools.llm import LLMMessage
            response = await client.complete_with_messages(
                messages=[
                    LLMMessage(role="system", content="You are a medical expert."),
                    LLMMessage(role="user", content="What is asthma?"),
                ],
                temperature=0.7,
                max_tokens=500
            )
            print(response.text)
        ```
    """

    # Pricing per 1K tokens (as of 2024-02) - update as needed
    PRICING = {
        "gpt-4": {"prompt": 0.03, "completion": 0.06},
        "gpt-4-32k": {"prompt": 0.06, "completion": 0.12},
        "gpt-4-turbo": {"prompt": 0.01, "completion": 0.03},
        "gpt-35-turbo": {"prompt": 0.0005, "completion": 0.0015},
        "gpt-35-turbo-16k": {"prompt": 0.003, "completion": 0.004},
    }

    def __init__(self, config: AzureOpenAIConfig):
        """Initialize Azure OpenAI client.

        Args:
            config: Azure OpenAI configuration
        """
        self.config = config
        self.client: AsyncAzureOpenAI | None = None

        logger.info(
            "Initialized Azure OpenAI client",
            extra={
                "endpoint": config.endpoint,
                "deployment": config.deployment_name,
                "api_version": config.api_version,
            },
        )

    async def __aenter__(self):
        """Enter the async context manager and create the client."""
        self.client = AsyncAzureOpenAI(
            azure_endpoint=self.config.endpoint,
            api_key=self.config.api_key,
            api_version=self.config.api_version,
            azure_ad_token=self.config.azure_ad_token,
            max_retries=self.config.max_retries,
            timeout=self.config.timeout,
        )
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit the async context manager and close the client."""
        if self.client:
            await self.client.close()

    def _ensure_client(self):
        """Ensure the client is initialized."""
        if not self.client:
            raise RuntimeError(
                "AzureOpenAIClient must be used as an async context manager "
                "(async with AzureOpenAIClient(...) as client:)"
            )

    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion for a single prompt.

        This method provides a simple interface for single-prompt completions.
        Internally, it wraps the prompt as a user message and delegates to
        `complete_with_messages()` using the Chat Completions API.

        Note (2025-12-30): Azure OpenAI chat models (GPT-4o, GPT-4, GPT-3.5-turbo)
        do not support the legacy Completions API (/completions endpoint). This
        method automatically converts the prompt to chat format for compatibility.
        For full control over message roles (system, user, assistant), use
        `complete_with_messages()` directly.

        Args:
            prompt: The input prompt text
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters (top_p, frequency_penalty, presence_penalty, etc.)

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMAPIError: If the API request fails
            LLMRateLimitError: If rate limit is exceeded
            LLMContextLengthError: If input exceeds context length

        Example:
            ```python
            async with AzureOpenAIClient(config) as client:
                response = await client.complete(
                    prompt="Explain quantum computing in simple terms.",
                    temperature=0.7,
                    max_tokens=500
                )
                print(response.text)
            ```
        """
        logger.debug(
            "Converting prompt to chat format for Azure chat completions API",
            extra={"prompt_length": len(prompt)},
        )

        # Wrap the prompt as a user message and delegate to chat completions
        # This is required because Azure chat models don't support legacy completions
        return await self.complete_with_messages(
            messages=[LLMMessage(role="user", content=prompt)],
            temperature=temperature,
            max_tokens=max_tokens,
            stop=stop,
            **kwargs,
        )

    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion using chat-style messages.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters (top_p, frequency_penalty, presence_penalty, etc.)

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMAPIError: If the API request fails
            LLMRateLimitError: If rate limit is exceeded
            LLMContextLengthError: If input exceeds context length
        """
        self._ensure_client()

        try:
            logger.debug(
                "Sending chat completion request",
                extra={
                    "num_messages": len(messages),
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )

            # Convert LLMMessage to dict format
            message_dicts = [msg.to_dict() for msg in messages]

            response = await self.client.chat.completions.create(
                model=self.config.deployment_name,
                messages=message_dicts,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                **kwargs,
            )

            # Extract response data
            choice = response.choices[0]
            text = choice.message.content or ""
            finish_reason = choice.finish_reason

            # Extract token usage
            usage = response.usage
            tokens = TokenUsage(
                prompt_tokens=usage.prompt_tokens,
                completion_tokens=usage.completion_tokens,
                total_tokens=usage.total_tokens,
                estimated_cost=await self.estimate_cost(
                    TokenUsage(
                        prompt_tokens=usage.prompt_tokens,
                        completion_tokens=usage.completion_tokens,
                        total_tokens=usage.total_tokens,
                    )
                ),
            )

            logger.info(
                "Chat completion request successful",
                extra={
                    "tokens_used": tokens.total_tokens,
                    "estimated_cost": tokens.estimated_cost,
                    "finish_reason": finish_reason,
                },
            )

            return LLMResponse(
                text=text,
                tokens=tokens,
                model=self.config.deployment_name,
                finish_reason=finish_reason,
                metadata={"response_id": response.id},
            )

        except OpenAIRateLimitError as e:
            logger.warning("Rate limit exceeded", exc_info=True)
            raise LLMRateLimitError(message=str(e), retry_after=None)
        except APIStatusError as e:
            if e.status_code == 400 and "context_length_exceeded" in str(e):
                logger.error("Context length exceeded", exc_info=True)
                raise LLMContextLengthError(message=str(e))
            logger.error("API status error", exc_info=True)
            raise LLMAPIError(
                message=str(e),
                status_code=e.status_code,
                response_body=e.response.text if e.response else None,
            )
        except APIConnectionError as e:
            logger.error("API connection error", exc_info=True)
            raise LLMAPIError(message=f"Connection error: {e}")
        except Exception as e:
            logger.error("Unexpected error during chat completion", exc_info=True)
            raise LLMAPIError(message=f"Unexpected error: {e}")

    async def stream_complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a chat completion, yielding chunks as they arrive.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Additional parameters (top_p, frequency_penalty, presence_penalty, etc.)

        Yields:
            StreamChunk objects containing text fragments

        Raises:
            LLMAPIError: If the API request fails
            LLMRateLimitError: If rate limit is exceeded
            LLMContextLengthError: If input exceeds context length
        """
        self._ensure_client()

        try:
            logger.debug(
                "Starting streaming chat completion request",
                extra={
                    "num_messages": len(messages),
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )

            # Convert LLMMessage to dict format
            message_dicts = [msg.to_dict() for msg in messages]

            # Create streaming response
            stream = await self.client.chat.completions.create(
                model=self.config.deployment_name,
                messages=message_dicts,
                temperature=temperature,
                max_tokens=max_tokens,
                stop=stop,
                stream=True,
                **kwargs,
            )

            finish_reason = None
            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    choice = chunk.choices[0]
                    delta = choice.delta

                    # Get text content if available
                    text = delta.content if delta and delta.content else ""

                    # Track finish reason
                    if choice.finish_reason:
                        finish_reason = choice.finish_reason

                    # Yield chunk (skip empty chunks unless it's the final one)
                    if text or choice.finish_reason:
                        yield StreamChunk(
                            text=text,
                            finish_reason=finish_reason,
                            is_final=choice.finish_reason is not None,
                            metadata={"chunk_id": chunk.id} if chunk.id else {},
                        )

            logger.info(
                "Streaming chat completion finished",
                extra={"finish_reason": finish_reason},
            )

        except OpenAIRateLimitError as e:
            logger.warning("Rate limit exceeded during streaming", exc_info=True)
            raise LLMRateLimitError(message=str(e), retry_after=None)
        except APIStatusError as e:
            if e.status_code == 400 and "context_length_exceeded" in str(e):
                logger.error("Context length exceeded", exc_info=True)
                raise LLMContextLengthError(message=str(e))
            logger.error("API status error during streaming", exc_info=True)
            raise LLMAPIError(
                message=str(e),
                status_code=e.status_code,
                response_body=e.response.text if e.response else None,
            )
        except APIConnectionError as e:
            logger.error("API connection error during streaming", exc_info=True)
            raise LLMAPIError(message=f"Connection error: {e}")
        except Exception as e:
            logger.error("Unexpected error during streaming", exc_info=True)
            raise LLMAPIError(message=f"Unexpected error: {e}")

    async def count_tokens(self, text: str) -> int:
        """Count the number of tokens in the text using tiktoken.

        Args:
            text: The text to tokenize

        Returns:
            Number of tokens
        """
        try:
            import tiktoken

            # Get encoding for the model
            # Map deployment names to model names for tiktoken
            model_map = {
                "gpt-4": "gpt-4",
                "gpt-4-32k": "gpt-4-32k",
                "gpt-4-turbo": "gpt-4-turbo-preview",
                "gpt-35-turbo": "gpt-3.5-turbo",
                "gpt-35-turbo-16k": "gpt-3.5-turbo-16k",
            }

            model_name = model_map.get(self.config.deployment_name, "gpt-4")
            encoding = tiktoken.encoding_for_model(model_name)
            return len(encoding.encode(text))

        except ImportError:
            logger.warning(
                "tiktoken not available, using character-based estimation. "
                "Install tiktoken for accurate token counting."
            )
            return await super().count_tokens(text)
        except Exception as e:
            logger.warning(f"Error counting tokens: {e}, using estimation")
            return await super().count_tokens(text)

    async def estimate_cost(self, tokens: TokenUsage) -> float:
        """Estimate the cost of an API call based on token usage.

        Args:
            tokens: Token usage information

        Returns:
            Estimated cost in USD
        """
        # Try to find pricing for the deployment
        pricing = None
        for model_prefix, model_pricing in self.PRICING.items():
            if self.config.deployment_name.startswith(model_prefix):
                pricing = model_pricing
                break

        if not pricing:
            logger.debug(f"No pricing information for deployment: {self.config.deployment_name}")
            return 0.0

        # Calculate cost: (tokens / 1000) * price_per_1k_tokens
        prompt_cost = (tokens.prompt_tokens / 1000) * pricing["prompt"]
        completion_cost = (tokens.completion_tokens / 1000) * pricing["completion"]

        return prompt_cost + completion_cost
