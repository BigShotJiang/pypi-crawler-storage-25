# Copyright 2025 Asher Informatics PBC
"""Base classes and interfaces for LLM clients.

This module provides the abstract base class and common data structures
for all LLM provider implementations in ashmatics-tools.
"""

import logging
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class TokenUsage:
    """Token usage tracking for LLM requests.

    Attributes:
        prompt_tokens: Number of tokens in the prompt
        completion_tokens: Number of tokens in the completion
        total_tokens: Total tokens used (prompt + completion)
        estimated_cost: Estimated cost in USD (provider-specific)
    """

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    estimated_cost: float = 0.0


@dataclass
class LLMResponse:
    """Standardized response format for LLM completions.

    Attributes:
        text: The generated text response
        tokens: Token usage information
        model: Model identifier used for generation
        finish_reason: Reason the generation stopped (e.g., 'stop', 'length', 'content_filter')
        metadata: Additional provider-specific metadata
    """

    text: str
    tokens: TokenUsage
    model: str
    finish_reason: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMMessage:
    """Structured message for chat-style completions.

    Attributes:
        role: Message role ('system', 'user', 'assistant')
        content: Message content
        name: Optional name for the message sender
    """

    role: str  # 'system', 'user', 'assistant'
    content: str
    name: str | None = None

    def to_dict(self) -> dict[str, str]:
        """Convert to dictionary format for API calls."""
        result = {"role": self.role, "content": self.content}
        if self.name:
            result["name"] = self.name
        return result


@dataclass
class StreamChunk:
    """Single chunk from a streaming LLM response.

    Attributes:
        text: The text content of this chunk (may be partial token)
        finish_reason: Reason generation stopped (only set on final chunk)
        is_final: Whether this is the final chunk in the stream
        metadata: Additional provider-specific metadata
    """

    text: str
    finish_reason: str | None = None
    is_final: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


class BaseLLMClient(ABC):
    """Abstract base class for all LLM provider clients.

    This class defines the common interface that all LLM providers must implement.
    Implementations should support async operations and context manager protocol.

    Example:
        ```python
        async with llm_client:
            response = await llm_client.complete(
                prompt="What is asthma?",
                temperature=0.7,
                max_tokens=500
            )
            print(response.text)
        ```
    """

    @abstractmethod
    async def complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion for a single prompt.

        Args:
            prompt: The input prompt text
            temperature: Sampling temperature (0.0 to 2.0). Higher values make output more random.
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Provider-specific additional parameters

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMError: If the API request fails
        """
        pass

    @abstractmethod
    async def complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate a completion using chat-style messages.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Provider-specific additional parameters

        Returns:
            LLMResponse containing the generated text and metadata

        Raises:
            LLMError: If the API request fails
        """
        pass

    async def stream_complete(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a completion for a single prompt, yielding chunks as they arrive.

        This method provides real-time streaming of generated text, useful for
        interactive applications where you want to display text as it's generated.

        Default implementation falls back to non-streaming complete() and yields
        the full response as a single chunk. Providers should override for true
        streaming support.

        Args:
            prompt: The input prompt text
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Provider-specific additional parameters

        Yields:
            StreamChunk objects containing text fragments

        Raises:
            LLMError: If the API request fails

        Example:
            ```python
            async for chunk in client.stream_complete("Tell me a story"):
                print(chunk.text, end="", flush=True)
                if chunk.is_final:
                    print()  # Newline at end
            ```
        """
        # Default: fall back to non-streaming and yield single chunk
        response = await self.complete(prompt, temperature, max_tokens, stop, **kwargs)
        yield StreamChunk(
            text=response.text,
            finish_reason=response.finish_reason,
            is_final=True,
            metadata=response.metadata,
        )

    async def stream_complete_with_messages(
        self,
        messages: list[LLMMessage],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a chat completion, yielding chunks as they arrive.

        This method provides real-time streaming of generated text for chat-style
        conversations, useful for interactive applications.

        Default implementation falls back to non-streaming complete_with_messages()
        and yields the full response as a single chunk. Providers should override
        for true streaming support.

        Args:
            messages: List of messages in the conversation
            temperature: Sampling temperature (0.0 to 2.0)
            max_tokens: Maximum number of tokens to generate
            stop: List of sequences where generation should stop
            **kwargs: Provider-specific additional parameters

        Yields:
            StreamChunk objects containing text fragments

        Raises:
            LLMError: If the API request fails

        Example:
            ```python
            messages = [
                LLMMessage(role="system", content="You are helpful."),
                LLMMessage(role="user", content="Hello!"),
            ]
            async for chunk in client.stream_complete_with_messages(messages):
                print(chunk.text, end="", flush=True)
            ```
        """
        # Default: fall back to non-streaming and yield single chunk
        response = await self.complete_with_messages(
            messages, temperature, max_tokens, stop, **kwargs
        )
        yield StreamChunk(
            text=response.text,
            finish_reason=response.finish_reason,
            is_final=True,
            metadata=response.metadata,
        )

    async def count_tokens(self, text: str) -> int:
        """Count the number of tokens in the text.

        Default implementation provides a rough estimate using character count.
        Providers should override with model-specific tokenization.

        Args:
            text: The text to tokenize

        Returns:
            Estimated number of tokens
        """
        # Rough estimate: ~4 characters per token for English text
        # Providers should override with accurate tokenization
        return len(text) // 4

    async def estimate_cost(self, tokens: TokenUsage) -> float:
        """Estimate the cost of an API call based on token usage.

        Default implementation returns 0.0. Providers should override with
        accurate pricing models.

        Args:
            tokens: Token usage information

        Returns:
            Estimated cost in USD
        """
        return 0.0

    async def __aenter__(self):
        """Enter the async context manager.

        Subclasses can override to set up resources (e.g., HTTP clients).
        """
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit the async context manager.

        Subclasses can override to clean up resources.
        """
        pass

    async def start(self):
        """Convenience method to start the client for long-lived applications.

        Use this for web applications where you want to initialize the client
        once at startup and keep it alive for multiple requests.

        Example:
            ```python
            # At application startup
            llm_client = create_llm_client("azure_openai", config)
            await llm_client.start()

            # In request handlers (no context manager needed)
            response = await llm_client.complete_with_messages(messages)

            # At application shutdown
            await llm_client.stop()
            ```

        This is equivalent to calling `__aenter__()` directly.
        """
        return await self.__aenter__()

    async def stop(self):
        """Convenience method to stop the client for long-lived applications.

        Use this at application shutdown to properly clean up resources
        (close connection pools, etc.).

        This is equivalent to calling `__aexit__(None, None, None)` directly.
        """
        return await self.__aexit__(None, None, None)


class LLMError(Exception):
    """Base exception for LLM-related errors."""

    pass


class LLMAPIError(LLMError):
    """Exception raised when an LLM API request fails."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: str | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class LLMRateLimitError(LLMError):
    """Exception raised when rate limit is exceeded."""

    def __init__(
        self,
        message: str,
        retry_after: int | None = None,
    ):
        super().__init__(message)
        self.retry_after = retry_after


class LLMContextLengthError(LLMError):
    """Exception raised when input exceeds model's context length."""

    def __init__(
        self,
        message: str,
        max_tokens: int | None = None,
        provided_tokens: int | None = None,
    ):
        super().__init__(message)
        self.max_tokens = max_tokens
        self.provided_tokens = provided_tokens
