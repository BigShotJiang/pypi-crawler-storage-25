# Copyright 2025 Asher Informatics PBC
"""Tests for OpenFDA transformation utilities."""

import pytest
from datetime import date

from ashmatics_datamodels.documents.regulatory import (
    RegulatoryMetadataContent,
    RegulatoryDocument,
    PredicateDeviceInfo,
)
from ashmatics_tools.external_apis.openfda.transforms import (
    parse_fda_date,
    extract_predicates,
    transform_510k_to_regulatory_metadata,
    transform_510k_to_regulatory_document,
    transform_pma_to_regulatory_metadata,
)


class TestParseFDADate:
    """Test FDA date parsing."""

    def test_parse_yyyymmdd_format(self):
        """Test parsing YYYYMMDD format."""
        result = parse_fda_date("20240115")
        assert result == date(2024, 1, 15)

    def test_parse_dashed_format(self):
        """Test parsing YYYY-MM-DD format."""
        result = parse_fda_date("2024-01-15")
        assert result == date(2024, 1, 15)

    def test_parse_none(self):
        """Test parsing None returns None."""
        result = parse_fda_date(None)
        assert result is None

    def test_parse_empty_string(self):
        """Test parsing empty string returns None."""
        result = parse_fda_date("")
        assert result is None

    def test_parse_invalid_format(self):
        """Test parsing invalid format returns None."""
        result = parse_fda_date("not-a-date")
        assert result is None


class TestExtractPredicates:
    """Test predicate extraction."""

    def test_extract_single_predicate(self):
        """Test extracting single predicate."""
        fda_response = {
            "k_number_predicate": "K123456"
        }
        predicates = extract_predicates(fda_response)
        assert len(predicates) == 1
        assert predicates[0].k_number == "K123456"

    def test_extract_multiple_predicates(self):
        """Test extracting multiple predicates."""
        fda_response = {
            "k_number_predicate": ["K123456", "K789012"]
        }
        predicates = extract_predicates(fda_response)
        assert len(predicates) == 2
        assert predicates[0].k_number == "K123456"
        assert predicates[1].k_number == "K789012"

    def test_extract_no_predicates(self):
        """Test extracting when no predicates present."""
        fda_response = {}
        predicates = extract_predicates(fda_response)
        assert len(predicates) == 0


class TestTransform510kMetadata:
    """Test 510(k) to metadata transformation."""

    def test_transform_complete_record(self):
        """Test transforming complete 510(k) record."""
        fda_510k = {
            "k_number": "K240001",
            "decision_date": "20240115",
            "applicant": "Test Medical Inc",
            "device_name": "Test Device",
            "device_class": "2",
            "product_code": "OZP",
            "advisory_committee": "RA",
        }

        metadata = transform_510k_to_regulatory_metadata(fda_510k)

        assert isinstance(metadata, RegulatoryMetadataContent)
        assert metadata.k_number == "K240001"
        assert metadata.clearance_date == date(2024, 1, 15)
        assert metadata.applicant == "Test Medical Inc"
        assert metadata.device_name == "Test Device"
        assert metadata.device_class == "2"
        assert metadata.product_code == "OZP"
        assert metadata.advisory_committee == "RA"
        assert metadata.title == "Test Device"

    def test_transform_minimal_record(self):
        """Test transforming minimal 510(k) record."""
        fda_510k = {
            "k_number": "K240001",
        }

        metadata = transform_510k_to_regulatory_metadata(fda_510k)

        assert isinstance(metadata, RegulatoryMetadataContent)
        assert metadata.k_number == "K240001"
        assert metadata.clearance_date is None
        assert metadata.applicant is None

    def test_transform_with_openfda_object(self):
        """Test transforming record with nested openfda object."""
        fda_510k = {
            "k_number": "K240001",
            "openfda": {
                "device_class": ["2"],
                "medical_specialty_description": ["RA"]  # 2-letter code
            }
        }

        metadata = transform_510k_to_regulatory_metadata(fda_510k)

        assert metadata.device_class == "2"
        assert metadata.advisory_committee == "RA"


class TestTransform510kDocument:
    """Test 510(k) to document transformation."""

    def test_transform_complete_document(self):
        """Test transforming complete 510(k) to document."""
        fda_510k = {
            "k_number": "K240001",
            "decision_date": "20240115",
            "applicant": "Test Medical Inc",
            "device_name": "Test Device",
            "device_class": "2",
            "product_code": "OZP",
            "k_number_predicate": ["K123456", "K789012"],
        }

        doc = transform_510k_to_regulatory_document(fda_510k)

        assert isinstance(doc, RegulatoryDocument)
        assert doc.metadata_content.k_number == "K240001"
        assert doc.metadata_content.device_name == "Test Device"

        # Check predicate section exists
        assert "3_predicate_devices" in doc.content.sections
        predicates_section = doc.content.sections["3_predicate_devices"]
        assert len(predicates_section.predicates) == 2

    def test_transform_without_predicates(self):
        """Test transforming 510(k) without predicates."""
        fda_510k = {
            "k_number": "K240001",
            "device_name": "Test Device",
        }

        doc = transform_510k_to_regulatory_document(fda_510k)

        assert isinstance(doc, RegulatoryDocument)
        # Default sections should still exist
        assert len(doc.content.sections) > 0


class TestTransformPMAMetadata:
    """Test PMA to metadata transformation."""

    def test_transform_complete_record(self):
        """Test transforming complete PMA record."""
        fda_pma = {
            "pma_number": "P240001",
            "decision_date": "20240115",
            "applicant": "Test Medical Inc",
            "trade_name": "Test Device",
            "product_code": "NLX",
            "openfda": {
                "device_class": ["3"],
                "device_name": ["Test Device Model X"]
            }
        }

        metadata = transform_pma_to_regulatory_metadata(fda_pma)

        assert isinstance(metadata, RegulatoryMetadataContent)
        assert metadata.pma_number == "P240001"
        assert metadata.clearance_date == date(2024, 1, 15)
        assert metadata.applicant == "Test Medical Inc"
        assert metadata.device_name == "Test Device"
        assert metadata.device_class == "3"
        assert metadata.product_code == "NLX"

    def test_transform_minimal_record(self):
        """Test transforming minimal PMA record."""
        fda_pma = {
            "pma_number": "P240001",
        }

        metadata = transform_pma_to_regulatory_metadata(fda_pma)

        assert isinstance(metadata, RegulatoryMetadataContent)
        assert metadata.pma_number == "P240001"
        assert metadata.device_class == "III"  # Default for PMA


class TestPredicateDeviceInfo:
    """Test PredicateDeviceInfo model."""

    def test_create_predicate(self):
        """Test creating predicate info."""
        predicate = PredicateDeviceInfo(
            k_number="K123456",
            device_name="Predicate Device",
            manufacturer="Test Mfg",
            comparison_summary="Substantially equivalent"
        )

        assert predicate.k_number == "K123456"
        assert predicate.device_name == "Predicate Device"
        assert predicate.manufacturer == "Test Mfg"
        assert predicate.comparison_summary == "Substantially equivalent"

    def test_create_minimal_predicate(self):
        """Test creating minimal predicate info."""
        predicate = PredicateDeviceInfo(k_number="K123456")

        assert predicate.k_number == "K123456"
        assert predicate.device_name is None
        assert predicate.manufacturer is None
        assert predicate.comparison_summary is None
