"""Tests for storage module.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import pytest

from ashmatics_tools.storage import (
    ADLSStorageClient,
    AuthType,
    MinIOStorageClient,
    StorageConfig,
    StorageProvider,
    create_storage_client,
)


class TestStorageConfig:
    """Test StorageConfig validation."""

    def test_storage_config_defaults(self):
        """Test default configuration."""
        config = StorageConfig(
            provider=StorageProvider.ADLS,
            connection_string="DefaultEndpointsProtocol=https;AccountName=test",
            container_name="test-container",
            auth_type=AuthType.CONNECTION_STRING,
        )

        assert config.provider == StorageProvider.ADLS
        assert config.auth_type == AuthType.CONNECTION_STRING
        assert config.chunk_size == 4 * 1024 * 1024
        assert config.timeout == 30.0
        assert config.max_retries == 3

    def test_adls_connection_string_validation(self):
        """Test ADLS connection string validation."""
        with pytest.raises(ValueError, match="connection_string required"):
            StorageConfig(
                provider=StorageProvider.ADLS,
                container_name="test",
                auth_type=AuthType.CONNECTION_STRING,
                connection_string=None,
            )

    def test_adls_default_credential_validation(self):
        """Test ADLS DefaultAzureCredential validation."""
        with pytest.raises(ValueError, match="account_url required"):
            StorageConfig(
                provider=StorageProvider.ADLS,
                container_name="test",
                auth_type=AuthType.DEFAULT_CREDENTIAL,
                account_url=None,
            )

    def test_minio_endpoint_validation(self):
        """Test MinIO endpoint validation."""
        with pytest.raises(ValueError, match="endpoint required"):
            StorageConfig(
                provider=StorageProvider.MINIO,
                container_name="test",
                auth_type=AuthType.ACCESS_KEY,
                access_key="test",
                secret_key="test",
                endpoint=None,
            )

    def test_minio_access_key_validation(self):
        """Test MinIO access key validation."""
        with pytest.raises(ValueError, match="access_key and secret_key required"):
            StorageConfig(
                provider=StorageProvider.MINIO,
                container_name="test",
                endpoint="localhost:9000",
                auth_type=AuthType.ACCESS_KEY,
                access_key=None,
                secret_key=None,
            )

    def test_invalid_chunk_size(self):
        """Test invalid chunk size."""
        with pytest.raises(ValueError, match="chunk_size must be positive"):
            StorageConfig(
                provider=StorageProvider.ADLS,
                connection_string="test",
                container_name="test",
                auth_type=AuthType.CONNECTION_STRING,
                chunk_size=0,
            )

    def test_invalid_timeout(self):
        """Test invalid timeout."""
        with pytest.raises(ValueError, match="timeout must be positive"):
            StorageConfig(
                provider=StorageProvider.ADLS,
                connection_string="test",
                container_name="test",
                auth_type=AuthType.CONNECTION_STRING,
                timeout=0,
            )


class TestStorageFactory:
    """Test storage factory function."""

    def test_create_adls_client(self):
        """Test creating ADLS client."""
        config = StorageConfig(
            provider=StorageProvider.ADLS,
            connection_string="DefaultEndpointsProtocol=https;AccountName=test",
            container_name="test-container",
            auth_type=AuthType.CONNECTION_STRING,
        )

        client = create_storage_client("adls", config)
        assert isinstance(client, ADLSStorageClient)
        assert client.get_provider() == StorageProvider.ADLS

    def test_create_minio_client(self):
        """Test creating MinIO client."""
        config = StorageConfig(
            provider=StorageProvider.MINIO,
            endpoint="localhost:9000",
            access_key="minioadmin",
            secret_key="minioadmin",
            container_name="test-bucket",
            auth_type=AuthType.ACCESS_KEY,
            use_ssl=False,
        )

        client = create_storage_client("minio", config)
        assert isinstance(client, MinIOStorageClient)
        assert client.get_provider() == StorageProvider.MINIO

    def test_unknown_provider(self):
        """Test unknown provider raises ValueError."""
        with pytest.raises(ValueError, match="Unknown storage provider"):
            create_storage_client("unknown")

    def test_s3_not_implemented(self):
        """Test S3 provider not yet implemented."""
        # Need to provide valid config since S3 requires endpoint in validation
        config = StorageConfig(
            provider=StorageProvider.S3,
            endpoint="s3.amazonaws.com",
            container_name="test-bucket",
            auth_type=AuthType.ACCESS_KEY,
            access_key="test",
            secret_key="test",
        )
        with pytest.raises(NotImplementedError, match="AWS S3 support coming soon"):
            create_storage_client("s3", config)

    def test_case_insensitive_provider(self):
        """Test provider name is case-insensitive."""
        config = StorageConfig(
            provider=StorageProvider.ADLS,
            connection_string="DefaultEndpointsProtocol=https;AccountName=test",
            container_name="test-container",
            auth_type=AuthType.CONNECTION_STRING,
        )

        client = create_storage_client("ADLS", config)
        assert isinstance(client, ADLSStorageClient)


class TestADLSStorageClient:
    """Test ADLS storage client."""

    def test_initialization(self):
        """Test ADLS client initialization."""
        config = StorageConfig(
            provider=StorageProvider.ADLS,
            connection_string="DefaultEndpointsProtocol=https;AccountName=test",
            container_name="test-container",
            auth_type=AuthType.CONNECTION_STRING,
        )

        client = ADLSStorageClient(config)
        assert client.config.container_name == "test-container"
        assert client.config.auth_type == AuthType.CONNECTION_STRING

    def test_missing_container_name(self):
        """Test missing container name raises ValueError."""
        config = StorageConfig(
            provider=StorageProvider.ADLS,
            connection_string="DefaultEndpointsProtocol=https;AccountName=test",
            auth_type=AuthType.CONNECTION_STRING,
        )

        with pytest.raises(ValueError, match="container_name is required"):
            ADLSStorageClient(config)

    def test_repr(self):
        """Test string representation."""
        config = StorageConfig(
            provider=StorageProvider.ADLS,
            connection_string="DefaultEndpointsProtocol=https;AccountName=test",
            container_name="test-container",
            auth_type=AuthType.CONNECTION_STRING,
        )

        client = ADLSStorageClient(config)
        assert "ADLSStorageClient" in repr(client)
        assert "test-container" in repr(client)


class TestMinIOStorageClient:
    """Test MinIO storage client."""

    def test_initialization(self):
        """Test MinIO client initialization."""
        config = StorageConfig(
            provider=StorageProvider.MINIO,
            endpoint="localhost:9000",
            access_key="minioadmin",
            secret_key="minioadmin",
            container_name="test-bucket",
            auth_type=AuthType.ACCESS_KEY,
            use_ssl=False,
        )

        client = MinIOStorageClient(config)
        assert client.config.container_name == "test-bucket"
        assert client.config.endpoint == "localhost:9000"
        assert client.config.use_ssl is False

    def test_missing_endpoint(self):
        """Test missing endpoint raises ValueError during config validation."""
        # Endpoint validation happens in StorageConfig.__post_init__, not client init
        with pytest.raises(ValueError, match="endpoint required for minio"):
            StorageConfig(
                provider=StorageProvider.MINIO,
                access_key="minioadmin",
                secret_key="minioadmin",
                container_name="test-bucket",
                auth_type=AuthType.ACCESS_KEY,
                endpoint=None,
            )

    def test_missing_container_name(self):
        """Test missing container name raises ValueError."""
        config = StorageConfig(
            provider=StorageProvider.MINIO,
            endpoint="localhost:9000",
            access_key="minioadmin",
            secret_key="minioadmin",
            auth_type=AuthType.ACCESS_KEY,
        )

        with pytest.raises(ValueError, match="container_name .* is required"):
            MinIOStorageClient(config)

    def test_unsupported_auth_type(self):
        """Test unsupported auth type raises ValueError."""
        config = StorageConfig(
            provider=StorageProvider.MINIO,
            endpoint="localhost:9000",
            container_name="test-bucket",
            auth_type=AuthType.DEFAULT_CREDENTIAL,  # MinIO only supports ACCESS_KEY
        )

        with pytest.raises(ValueError, match="MinIO only supports ACCESS_KEY"):
            MinIOStorageClient(config)

    def test_repr(self):
        """Test string representation."""
        config = StorageConfig(
            provider=StorageProvider.MINIO,
            endpoint="localhost:9000",
            access_key="minioadmin",
            secret_key="minioadmin",
            container_name="test-bucket",
            auth_type=AuthType.ACCESS_KEY,
            use_ssl=False,
        )

        client = MinIOStorageClient(config)
        assert "MinIOStorageClient" in repr(client)
        assert "test-bucket" in repr(client)
