# Copyright 2025 Asher Informatics PBC
"""Tests for MCP servers."""

import pytest
import respx
from httpx import Response

from ashmatics_tools.external_apis.openfda import OpenFDAConfig
from ashmatics_tools.mcp_servers import (
    OpenFDAMCPConfig,
    OpenFDAMCPServer,
    create_mcp_server,
    list_mcp_servers,
)


@pytest.fixture
def mcp_config():
    """Create test MCP configuration."""
    return OpenFDAMCPConfig(
        api_config=OpenFDAConfig(api_key="test_key", timeout=10.0)
    )


@pytest.fixture
def mcp_server(mcp_config):
    """Create test MCP server."""
    return OpenFDAMCPServer(mcp_config)


def test_mcp_config_defaults():
    """Test MCP configuration defaults."""
    config = OpenFDAMCPConfig()
    assert config.name == "openfda"
    assert config.version == "1.0.0"
    assert config.description == "MCP server for US FDA Open Data Portal"
    assert config.max_response_size == 100_000
    assert config.streaming_enabled is True


def test_mcp_config_with_api_config():
    """Test MCP configuration with custom API config."""
    api_config = OpenFDAConfig(api_key="test_key")
    config = OpenFDAMCPConfig(api_config=api_config)
    assert config.api_config is not None
    assert config.api_config.api_key == "test_key"


def test_get_tools(mcp_server):
    """Test getting available tools."""
    tools = mcp_server.get_tools()

    assert len(tools) == 3
    tool_names = [tool["name"] for tool in tools]
    assert "search_devices" in tool_names
    assert "search_drugs" in tool_names
    assert "count_by_field" in tool_names

    # Check search_devices tool schema
    search_devices_tool = next(t for t in tools if t["name"] == "search_devices")
    assert "description" in search_devices_tool
    assert "inputSchema" in search_devices_tool
    assert "properties" in search_devices_tool["inputSchema"]
    assert "query" in search_devices_tool["inputSchema"]["properties"]


@pytest.mark.asyncio
@respx.mock
async def test_call_search_devices(mcp_server):
    """Test calling search_devices tool."""
    mock_response = {
        "meta": {"results": {"skip": 0, "limit": 10, "total": 2}},
        "results": [
            {"device": {"device_name": "Device 1"}},
            {"device": {"device_name": "Device 2"}},
        ],
    }

    respx.get("https://api.fda.gov/device/event.json").mock(
        return_value=Response(200, json=mock_response)
    )

    result = await mcp_server.call_tool(
        "search_devices",
        {
            "endpoint": "device_event",
            "query": "device_name:pacemaker",
            "limit": 10,
            "max_records": 100,
        },
    )

    assert result["success"] is True
    assert result["endpoint"] == "device_event"
    assert result["query"] == "device_name:pacemaker"
    assert result["count"] == 2
    assert len(result["results"]) == 2


@pytest.mark.asyncio
@respx.mock
async def test_call_search_drugs(mcp_server):
    """Test calling search_drugs tool."""
    mock_response = {
        "meta": {"results": {"skip": 0, "limit": 10, "total": 1}},
        "results": [{"patient": {"drug": {"medicinalproduct": "ASPIRIN"}}}],
    }

    respx.get("https://api.fda.gov/drug/event.json").mock(
        return_value=Response(200, json=mock_response)
    )

    result = await mcp_server.call_tool(
        "search_drugs",
        {
            "endpoint": "drug_event",
            "query": "patient.drug.medicinalproduct:aspirin",
            "limit": 10,
        },
    )

    assert result["success"] is True
    assert result["endpoint"] == "drug_event"
    assert result["count"] == 1


@pytest.mark.asyncio
@respx.mock
async def test_call_count_by_field(mcp_server):
    """Test calling count_by_field tool."""
    mock_response = {
        "results": [
            {"term": "Class I", "count": 100},
            {"term": "Class II", "count": 200},
        ]
    }

    respx.get("https://api.fda.gov/device/event.json").mock(
        return_value=Response(200, json=mock_response)
    )

    result = await mcp_server.call_tool(
        "count_by_field",
        {
            "endpoint": "device/event",
            "query": "*",
            "count_field": "device.device_class.exact",
        },
    )

    assert result["success"] is True
    assert result["count"] == 2
    assert len(result["results"]) == 2
    assert result["results"][0]["term"] == "Class I"


@pytest.mark.asyncio
async def test_call_unknown_tool(mcp_server):
    """Test calling unknown tool."""
    result = await mcp_server.call_tool("unknown_tool", {})

    assert result.get("error") is True
    assert "Unknown tool" in result.get("message", "")


@pytest.mark.asyncio
@respx.mock
async def test_call_tool_with_error(mcp_server):
    """Test tool call with API error."""
    # Mock 500 error
    respx.get("https://api.fda.gov/device/event.json").mock(
        return_value=Response(500, text="Internal Server Error")
    )

    result = await mcp_server.call_tool(
        "search_devices",
        {
            "endpoint": "device_event",
            "query": "*",
            "limit": 10,
        },
    )

    assert result.get("error") is True
    assert "type" in result
    assert "message" in result


def test_factory_create_mcp_server():
    """Test MCP server factory."""
    config = OpenFDAMCPConfig(api_config=OpenFDAConfig(api_key="test_key"))
    server = create_mcp_server("openfda", config)

    assert isinstance(server, OpenFDAMCPServer)
    assert server.config.api_config.api_key == "test_key"


def test_factory_list_servers():
    """Test listing MCP servers."""
    servers = list_mcp_servers()
    assert "openfda" in servers


def test_factory_unknown_server():
    """Test factory with unknown server."""
    with pytest.raises(ValueError, match="Unknown MCP server"):
        create_mcp_server("unknown_server", {})


def test_truncate_response(mcp_server):
    """Test response truncation."""
    # Short response - no truncation
    short_response = "x" * 1000
    truncated, was_truncated = mcp_server._truncate_response(short_response)
    assert truncated == short_response
    assert was_truncated is False

    # Long response - truncation
    long_response = "x" * 200_000
    truncated, was_truncated = mcp_server._truncate_response(long_response)
    assert len(truncated) == mcp_server.config.max_response_size
    assert was_truncated is True


def test_format_error(mcp_server):
    """Test error formatting."""
    error = ValueError("Test error message")
    formatted = mcp_server._format_error(error)

    assert formatted["error"] is True
    assert formatted["type"] == "ValueError"
    assert formatted["message"] == "Test error message"
    assert "user_message" in formatted
