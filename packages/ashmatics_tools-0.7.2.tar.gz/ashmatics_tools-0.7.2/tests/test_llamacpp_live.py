"""Live integration tests for llama.cpp client against local server.

These tests require a running llama.cpp server at localhost:9000.
Run with: uv run pytest tests/test_llamacpp_live.py -v -s

To skip live tests in CI: uv run pytest -m "not live"
"""

import asyncio
import time

import pytest

from ashmatics_tools.llm import (
    LlamaCppClient,
    LlamaCppConfig,
    LLMMessage,
)


# Mark all tests as requiring the live server
pytestmark = pytest.mark.live


@pytest.fixture
def live_config():
    """Configuration for live server at localhost:9000."""
    return LlamaCppConfig(
        endpoint="http://localhost:9000",
        model="kb-llm",
        timeout=120.0,
    )


class TestLlamaCppLiveBasic:
    """Basic live integration tests against local llama.cpp server."""

    @pytest.mark.asyncio
    async def test_health_check(self, live_config):
        """Test server health endpoint."""
        async with LlamaCppClient(live_config) as client:
            health = await client.get_server_health()
            print(f"\nServer health: {health}")
            assert health.get("status") == "ok"

    @pytest.mark.asyncio
    async def test_simple_completion(self, live_config):
        """Test a simple completion request."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="What is 2 + 2? Answer with just the number.",
                temperature=0.1,
                max_tokens=50,
            )
            print(f"\nPrompt: What is 2 + 2?")
            print(f"Response: {response.text}")
            print(f"Tokens: {response.tokens}")
            print(f"Finish reason: {response.finish_reason}")

            assert response.text is not None
            assert len(response.text) > 0
            assert response.tokens.total_tokens > 0

    @pytest.mark.asyncio
    async def test_chat_completion(self, live_config):
        """Test chat completion with messages."""
        async with LlamaCppClient(live_config) as client:
            messages = [
                LLMMessage(role="system", content="You are a helpful assistant. Be concise."),
                LLMMessage(role="user", content="Name 3 primary colors in a comma-separated list."),
            ]

            response = await client.complete_with_messages(
                messages=messages,
                temperature=0.1,
                max_tokens=100,
            )
            print(f"\nChat completion response: {response.text}")
            print(f"Tokens used: {response.tokens}")

            assert response.text is not None
            assert len(response.text) > 0


class TestLlamaCppLiveStopSequences:
    """Test stop sequences with live server."""

    @pytest.mark.asyncio
    async def test_stop_on_newline(self, live_config):
        """Test that stop sequence on newline works."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="List 5 fruits, one per line:\n1.",
                temperature=0.1,
                max_tokens=200,
                stop=["\n2."],  # Stop after first item
            )
            print(f"\nResponse with stop on newline: '{response.text}'")
            print(f"Finish reason: {response.finish_reason}")

            # Should have stopped before listing more
            assert response.text is not None
            # The response should be relatively short due to stop sequence
            assert len(response.text) < 100

    @pytest.mark.asyncio
    async def test_stop_on_keyword(self, live_config):
        """Test that stop sequence on keyword works."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="Count from 1 to 10: 1, 2, 3,",
                temperature=0.1,
                max_tokens=100,
                stop=["5", "6"],  # Stop at 5 or 6
            )
            print(f"\nResponse with keyword stop: '{response.text}'")

            assert response.text is not None
            # Should not contain numbers past our stop
            assert "7" not in response.text
            assert "8" not in response.text

    @pytest.mark.asyncio
    async def test_multiple_stop_sequences(self, live_config):
        """Test multiple stop sequences."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="Write a sentence that ends with a period.",
                temperature=0.1,
                max_tokens=100,
                stop=[".", "!", "?"],  # Stop on any sentence-ending punctuation
            )
            print(f"\nResponse with multiple stops: '{response.text}'")

            assert response.text is not None
            # Response should not contain these punctuation marks (they triggered stop)
            # Though the model might not have included them anyway


class TestLlamaCppLiveLongGeneration:
    """Test longer generations with live server."""

    @pytest.mark.asyncio
    async def test_haiku_generation(self, live_config):
        """Test generating a haiku."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="Write a haiku about programming. Format: three lines, 5-7-5 syllables.",
                temperature=0.7,
                max_tokens=200,
            )
            print(f"\nHaiku about programming:")
            print(f"{response.text}")
            print(f"\nTokens: prompt={response.tokens.prompt_tokens}, completion={response.tokens.completion_tokens}")

            assert response.text is not None
            assert len(response.text) > 10

    @pytest.mark.asyncio
    async def test_paragraph_generation(self, live_config):
        """Test generating a longer paragraph."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="Explain in one paragraph (3-4 sentences) why Python is popular for data science.",
                temperature=0.5,
                max_tokens=300,
            )
            print(f"\nParagraph about Python:")
            print(f"{response.text}")
            print(f"\nTotal tokens: {response.tokens.total_tokens}")

            assert response.text is not None
            assert len(response.text) > 50
            assert response.tokens.completion_tokens > 20

    @pytest.mark.asyncio
    async def test_structured_output(self, live_config):
        """Test generating structured output (JSON-like)."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="""Return a JSON object with the following structure:
{
  "name": "example person name",
  "age": number,
  "city": "example city"
}
Only return the JSON, no explanation.""",
                temperature=0.1,
                max_tokens=150,
            )
            print(f"\nStructured output:")
            print(f"{response.text}")

            assert response.text is not None
            # Should contain JSON-like structure
            assert "{" in response.text or "name" in response.text.lower()


class TestLlamaCppLiveTemperature:
    """Test temperature parameter effects."""

    @pytest.mark.asyncio
    async def test_low_temperature_deterministic(self, live_config):
        """Test that low temperature produces more consistent results."""
        async with LlamaCppClient(live_config) as client:
            prompt = "What is the capital of Japan? One word answer:"
            responses = []

            for i in range(3):
                response = await client.complete(
                    prompt=prompt,
                    temperature=0.0,  # Fully deterministic
                    max_tokens=20,
                )
                responses.append(response.text.strip().lower())
                print(f"  Run {i+1}: {response.text}")

            print(f"\nLow temp responses: {responses}")
            # With temp=0, responses should be identical or very similar
            # (Tokyo in all cases)
            assert all("tokyo" in r for r in responses) or len(set(responses)) <= 2

    @pytest.mark.asyncio
    async def test_high_temperature_variation(self, live_config):
        """Test that high temperature can produce varied results."""
        async with LlamaCppClient(live_config) as client:
            prompt = "Name a random fruit:"
            responses = []

            for i in range(3):
                response = await client.complete(
                    prompt=prompt,
                    temperature=1.2,  # High temperature for variety
                    max_tokens=20,
                )
                responses.append(response.text.strip())
                print(f"  Run {i+1}: {response.text}")

            print(f"\nHigh temp responses: {responses}")
            # Just verify we got valid responses
            assert all(len(r) > 0 for r in responses)


class TestLlamaCppLiveConversation:
    """Test multi-turn conversation capabilities."""

    @pytest.mark.asyncio
    async def test_multi_turn_conversation(self, live_config):
        """Test a multi-turn conversation maintains context."""
        async with LlamaCppClient(live_config) as client:
            # Turn 1
            messages = [
                LLMMessage(role="system", content="You are a helpful math tutor. Be concise."),
                LLMMessage(role="user", content="What is 5 times 3?"),
            ]

            response1 = await client.complete_with_messages(
                messages=messages,
                temperature=0.1,
                max_tokens=50,
            )
            print(f"\nTurn 1 - User: What is 5 times 3?")
            print(f"Turn 1 - Assistant: {response1.text}")

            # Turn 2 - follow up
            messages.append(LLMMessage(role="assistant", content=response1.text))
            messages.append(LLMMessage(role="user", content="Now add 7 to that result."))

            response2 = await client.complete_with_messages(
                messages=messages,
                temperature=0.1,
                max_tokens=50,
            )
            print(f"Turn 2 - User: Now add 7 to that result.")
            print(f"Turn 2 - Assistant: {response2.text}")

            assert response1.text is not None
            assert response2.text is not None
            # The second response should reference 22 (15 + 7)
            assert "22" in response2.text or "twenty" in response2.text.lower()

    @pytest.mark.asyncio
    async def test_system_prompt_influence(self, live_config):
        """Test that system prompt influences response style."""
        async with LlamaCppClient(live_config) as client:
            # Pirate style
            messages_pirate = [
                LLMMessage(role="system", content="You are a pirate. Respond in pirate speak with 'Arr' and nautical terms."),
                LLMMessage(role="user", content="How are you today?"),
            ]

            response = await client.complete_with_messages(
                messages=messages_pirate,
                temperature=0.7,
                max_tokens=100,
            )
            print(f"\nPirate response: {response.text}")

            assert response.text is not None
            # Should have some pirate-like language
            pirate_words = ["arr", "matey", "ahoy", "sea", "ship", "captain", "aye"]
            response_lower = response.text.lower()
            has_pirate_word = any(word in response_lower for word in pirate_words)
            # This is a soft check - LLM might not always follow perfectly
            print(f"Contains pirate language: {has_pirate_word}")


class TestLlamaCppLivePerformance:
    """Performance and timing tests."""

    @pytest.mark.asyncio
    async def test_response_time(self, live_config):
        """Test that responses come back in reasonable time."""
        async with LlamaCppClient(live_config) as client:
            start = time.time()
            response = await client.complete(
                prompt="Say 'hello'",
                temperature=0.1,
                max_tokens=10,
            )
            elapsed = time.time() - start

            print(f"\nSimple response time: {elapsed:.2f}s")
            print(f"Response: {response.text}")

            assert response.text is not None
            # Should respond within 30 seconds for a simple query
            assert elapsed < 30.0

    @pytest.mark.asyncio
    async def test_token_counting(self, live_config):
        """Test token counting estimation."""
        client = LlamaCppClient(live_config)

        test_text = "This is a test sentence with several words."
        token_count = await client.count_tokens(test_text)

        print(f"\nText: '{test_text}'")
        print(f"Estimated tokens: {token_count}")
        print(f"Character count: {len(test_text)}")

        # Should be reasonable estimate (text is ~45 chars, ~11 tokens)
        assert token_count > 5
        assert token_count < 20

    @pytest.mark.asyncio
    async def test_cost_estimation(self, live_config):
        """Test that cost is always 0 for self-hosted."""
        async with LlamaCppClient(live_config) as client:
            response = await client.complete(
                prompt="Test prompt",
                temperature=0.1,
                max_tokens=50,
            )

            cost = await client.estimate_cost(response.tokens)
            print(f"\nTokens used: {response.tokens}")
            print(f"Estimated cost: ${cost}")

            # Self-hosted should always be $0
            assert cost == 0.0
            assert response.tokens.estimated_cost == 0.0


# Quick test that can be run directly
async def quick_test():
    """Quick test function for direct execution."""
    config = LlamaCppConfig(
        endpoint="http://localhost:9000",
        model="kb-llm",
        timeout=120.0,
    )

    print("=" * 60)
    print("Testing llama.cpp client against localhost:9000")
    print("=" * 60)

    async with LlamaCppClient(config) as client:
        # 1. Health check
        print("\n1. Health check...")
        try:
            health = await client.get_server_health()
            print(f"   Status: {health}")
        except Exception as e:
            print(f"   Health check failed: {e}")
            return

        # 2. Simple completion
        print("\n2. Simple completion...")
        response = await client.complete(
            prompt="What is the capital of France? Answer in one word.",
            temperature=0.1,
            max_tokens=20,
        )
        print(f"   Response: {response.text}")
        print(f"   Tokens: {response.tokens}")

        # 3. Chat completion
        print("\n3. Chat completion...")
        messages = [
            LLMMessage(role="system", content="You are a helpful assistant."),
            LLMMessage(role="user", content="Say hello in exactly 3 words."),
        ]
        response = await client.complete_with_messages(
            messages=messages,
            temperature=0.1,
            max_tokens=50,
        )
        print(f"   Response: {response.text}")

        # 4. Stop sequences
        print("\n4. Testing stop sequences...")
        response = await client.complete(
            prompt="Count: 1, 2, 3,",
            temperature=0.1,
            max_tokens=50,
            stop=["6", "7"],
        )
        print(f"   Response: {response.text}")
        print(f"   Finish reason: {response.finish_reason}")

        # 5. Longer generation
        print("\n5. Longer generation (haiku)...")
        response = await client.complete(
            prompt="Write a haiku about coding:",
            temperature=0.7,
            max_tokens=100,
        )
        print(f"   Response:\n{response.text}")

        # 6. Multi-turn conversation
        print("\n6. Multi-turn conversation...")
        messages = [
            LLMMessage(role="system", content="You are a math tutor. Be concise."),
            LLMMessage(role="user", content="What is 10 + 5?"),
        ]
        response1 = await client.complete_with_messages(messages=messages, temperature=0.1, max_tokens=30)
        print(f"   Q: What is 10 + 5?")
        print(f"   A: {response1.text}")

        messages.append(LLMMessage(role="assistant", content=response1.text))
        messages.append(LLMMessage(role="user", content="Double that."))
        response2 = await client.complete_with_messages(messages=messages, temperature=0.1, max_tokens=30)
        print(f"   Q: Double that.")
        print(f"   A: {response2.text}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(quick_test())
