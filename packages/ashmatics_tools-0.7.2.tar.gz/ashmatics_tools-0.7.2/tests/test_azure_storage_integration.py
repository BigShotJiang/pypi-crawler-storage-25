#!/usr/bin/env python3
"""Integration test for Azure ADLS Storage.

This script tests the storage module with real Azure ADLS Gen2.
It uses environment variables from ashmatics-src.env.

Usage:
    python test_azure_storage_integration.py [container_name]

    If container_name is not provided, defaults to '$default'

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import argparse
import asyncio
import os
import sys
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

from ashmatics_tools.storage import (
    AuthType,
    StorageConfig,
    StorageProvider,
    create_storage_client,
)


async def test_azure_storage(container_name: str):
    """Test Azure ADLS storage operations."""
    # Load environment variables
    env_file = Path(__file__).parent / "ashmatics-src.env"
    if not env_file.exists():
        print(f"❌ Environment file not found: {env_file}")
        sys.exit(1)

    load_dotenv(env_file)
    print(f"✅ Loaded environment from: {env_file}")

    # Get configuration from environment
    connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    if not connection_string:
        print("❌ AZURE_STORAGE_CONNECTION_STRING not found in environment")
        sys.exit(1)

    test_prefix = f"integration-test-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    test_container_name = f"test-ashmatics-{datetime.now().strftime('%Y%m%d-%H%M%S')}"

    print(f"\n🔧 Configuration:")
    print(f"   Existing Container: {container_name}")
    print(f"   Test Container: {test_container_name}")
    print(f"   Test prefix: {test_prefix}")
    print(f"   Auth type: CONNECTION_STRING")

    # Create storage client
    config = StorageConfig(
        provider=StorageProvider.ADLS,
        connection_string=connection_string,
        container_name=container_name,
        auth_type=AuthType.CONNECTION_STRING,
    )

    print(f"\n🚀 Creating ADLS storage client...")
    storage = create_storage_client("adls", config)
    print(f"   ✅ Client created: {storage}")

    # Test container lifecycle first (without context manager)
    print(f"\n🏗️  Test Container Lifecycle")

    test_container_name2 = None  # Initialize for cleanup

    try:
        await storage._ensure_initialized()

        # Test: List containers
        print(f"\n📋 Listing all containers")
        all_containers = await storage.list_containers()
        print(f"   ✅ Found {len(all_containers)} containers in account")
        print(f"      First 5: {all_containers[:5]}")

        # Test: Check if test container exists (should not)
        print(f"\n🔍 Check test container existence (before creation)")
        exists = await storage.container_exists(test_container_name)
        if not exists:
            print(f"   ✅ Container does not exist yet: {test_container_name}")
        else:
            print(f"   ⚠️  Container already exists (will try to delete)")
            await storage.delete_container(test_container_name, force=True)

        # Test: Create new container
        print(f"\n🆕 Create new container")
        created = await storage.create_container(test_container_name)
        if created:
            print(f"   ✅ Container created: {test_container_name}")
        else:
            print(f"   ❌ Failed to create container")
            return False

        # Test: Check if test container exists (should exist now)
        print(f"\n🔍 Check test container existence (after creation)")
        exists = await storage.container_exists(test_container_name)
        if exists:
            print(f"   ✅ Container exists: {test_container_name}")
        else:
            print(f"   ❌ Container not found after creation")
            return False

        # Test: Try to create same container again (should return False)
        print(f"\n🔁 Try to create existing container")
        created_again = await storage.create_container(test_container_name)
        if not created_again:
            print(f"   ✅ Correctly returned False for existing container")
        else:
            print(f"   ❌ Should not allow duplicate container creation")
            return False

        # Test: Delete empty container (should work)
        print(f"\n🗑️  Delete empty container")
        deleted = await storage.delete_container(test_container_name, force=False)
        if deleted:
            print(f"   ✅ Empty container deleted: {test_container_name}")
        else:
            print(f"   ❌ Failed to delete empty container")
            return False

        # Test: Check deletion
        print(f"\n🔍 Verify container deletion")
        exists = await storage.container_exists(test_container_name)
        if not exists:
            print(f"   ✅ Container successfully deleted")
        else:
            print(f"   ❌ Container still exists after deletion")
            return False

        # Test: Create container again for non-empty test
        # Use a different name to avoid "ContainerBeingDeleted" timing issue
        test_container_name2 = f"test-ashmatics2-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        print(f"\n🆕 Create new container for non-empty deletion test")
        await storage.create_container(test_container_name2)

        # Write a test file to the new container
        test_storage_config = StorageConfig(
            provider=StorageProvider.ADLS,
            connection_string=connection_string,
            container_name=test_container_name2,
            auth_type=AuthType.CONNECTION_STRING,
        )
        test_storage = create_storage_client("adls", test_storage_config)
        await test_storage._ensure_initialized()
        await test_storage.write_object("test.txt", b"test content")
        print(f"   ✅ Wrote test file to container")

        # Test: Try to delete non-empty container without force (should fail)
        print(f"\n🛑 Try to delete non-empty container without force")
        try:
            await storage.delete_container(test_container_name2, force=False)
            print(f"   ❌ Should have raised ValueError for non-empty container")
            return False
        except ValueError as e:
            if "not empty" in str(e):
                print(f"   ✅ Correctly raised ValueError: {str(e)[:80]}...")
            else:
                print(f"   ❌ Unexpected ValueError: {e}")
                return False

        # Test: Delete non-empty container with force=True
        print(f"\n💪 Delete non-empty container with force=True")
        deleted = await storage.delete_container(test_container_name2, force=True)
        if deleted:
            print(f"   ✅ Non-empty container deleted with force")
        else:
            print(f"   ❌ Failed to force delete non-empty container")
            return False

        await test_storage.close()

    except Exception as e:
        print(f"\n❌ Container lifecycle test failed: {e}")
        import traceback

        traceback.print_exc()
        # Cleanup: try to delete test containers if they exist
        try:
            await storage.delete_container(test_container_name, force=True)
        except:
            pass
        if test_container_name2:
            try:
                await storage.delete_container(test_container_name2, force=True)
            except:
                pass
        await storage.close()
        return False

    # Now test object operations with existing container
    try:
        async with storage:
            # Test 1: Health check
            print(f"\n🏥 Test 1: Health check")
            is_healthy = await storage.health_check()
            if is_healthy:
                print(f"   ✅ Storage is healthy")
            else:
                print(f"   ❌ Storage health check failed")
                return False

            # Test 2: Write object
            print(f"\n✍️  Test 2: Write object")
            test_path = f"{test_prefix}/test-file.txt"
            test_content = f"Hello from ashmatics-tools integration test!\nTimestamp: {datetime.now().isoformat()}"
            test_bytes = test_content.encode("utf-8")

            success = await storage.write_object(
                test_path, test_bytes, content_type="text/plain"
            )
            if success:
                print(f"   ✅ Wrote {len(test_bytes)} bytes to: {test_path}")
            else:
                print(f"   ❌ Failed to write object")
                return False

            # Test 3: Check existence
            print(f"\n🔍 Test 3: Check existence")
            exists = await storage.exists(test_path)
            if exists:
                print(f"   ✅ Object exists: {test_path}")
            else:
                print(f"   ❌ Object not found after writing")
                return False

            # Test 4: Read object
            print(f"\n📖 Test 4: Read object")
            content = await storage.read_object(test_path)
            if content == test_bytes:
                print(f"   ✅ Read {len(content)} bytes (content matches)")
            else:
                print(f"   ❌ Content mismatch!")
                print(f"      Expected: {test_bytes[:50]}...")
                print(f"      Got: {content[:50]}...")
                return False

            # Test 5: Read as text
            print(f"\n📄 Test 5: Read as text")
            text_content = await storage.read_object_text(test_path)
            if text_content == test_content:
                print(f"   ✅ Read text content matches")
            else:
                print(f"   ❌ Text content mismatch")
                return False

            # Test 6: Get metadata
            print(f"\n📊 Test 6: Get metadata")
            metadata = await storage.get_metadata(test_path)
            if metadata:
                print(f"   ✅ Got metadata:")
                print(f"      Size: {metadata.size} bytes")
                print(f"      Modified: {metadata.modified_time}")
                print(f"      Content-Type: {metadata.content_type}")
            else:
                print(f"   ❌ Failed to get metadata")
                return False

            # Test 7: Write multiple objects
            print(f"\n📝 Test 7: Write multiple objects")
            for i in range(3):
                path = f"{test_prefix}/file-{i}.txt"
                content = f"Test file {i}\n"
                await storage.write_object(path, content.encode("utf-8"))
            print(f"   ✅ Wrote 3 test files")

            # Test 8: List objects
            print(f"\n📋 Test 8: List objects")
            objects = await storage.list_objects(prefix=test_prefix, pattern="*.txt")
            print(f"   ✅ Found {len(objects)} objects:")
            for obj in objects:
                print(f"      - {obj.name} ({obj.size} bytes)")

            if len(objects) != 4:  # Original test file + 3 new files
                print(f"   ⚠️  Expected 4 objects, found {len(objects)}")

            # Test 9: Copy object
            print(f"\n📋 Test 9: Copy object")
            src_path = test_path
            dest_path = f"{test_prefix}/test-file-copy.txt"
            success = await storage.copy_object(src_path, dest_path)
            if success:
                print(f"   ✅ Copied: {src_path} → {dest_path}")
            else:
                print(f"   ❌ Failed to copy object")
                return False

            # Test 10: Stream read (for large files)
            print(f"\n🌊 Test 10: Stream read")
            chunks = []
            async for chunk in storage.read_object_stream(test_path):
                chunks.append(chunk)
            streamed_content = b"".join(chunks)
            if streamed_content == test_bytes:
                print(
                    f"   ✅ Streamed {len(chunks)} chunks ({len(streamed_content)} bytes total)"
                )
            else:
                print(f"   ❌ Streamed content mismatch")
                return False

            # Test 11: Cleanup - delete all test objects
            print(f"\n🧹 Test 11: Cleanup")
            all_test_objects = await storage.list_objects(prefix=test_prefix)
            deleted_count = 0
            for obj in all_test_objects:
                success = await storage.delete_object(obj.path)
                if success:
                    deleted_count += 1
            print(f"   ✅ Deleted {deleted_count} test objects")

            # Verify cleanup
            remaining = await storage.list_objects(prefix=test_prefix)
            if len(remaining) == 0:
                print(f"   ✅ All test objects cleaned up")
            else:
                print(f"   ⚠️  {len(remaining)} objects still remain")

            print(f"\n{'=' * 60}")
            print(f"🎉 All integration tests passed!")
            print(f"{'=' * 60}")
            return True

    except Exception as e:
        print(f"\n❌ Integration test failed with error:")
        print(f"   {type(e).__name__}: {e}")
        import traceback

        traceback.print_exc()
        return False


async def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Test Azure ADLS storage integration")
    parser.add_argument(
        "container",
        nargs="?",
        default="$default",
        help="Azure container name (default: $default)",
    )
    args = parser.parse_args()

    print("=" * 60)
    print("Azure ADLS Storage Integration Test")
    print("=" * 60)

    success = await test_azure_storage(args.container)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())
