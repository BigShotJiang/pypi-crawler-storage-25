"""Tests for llama.cpp client."""

import pytest
import respx
from httpx import Response

from ashmatics_tools.llm import (
    LlamaCppClient,
    LlamaCppConfig,
    LLMAPIError,
    LLMContextLengthError,
    LLMMessage,
    LLMRateLimitError,
    create_llm_client,
    list_llm_providers,
)


class TestLlamaCppConfig:
    """Test llama.cpp configuration."""

    def test_config_defaults(self):
        """Test default configuration values."""
        config = LlamaCppConfig()
        assert config.endpoint == "http://localhost:8080"
        assert config.model == "llama-cpp-model"
        assert config.timeout == 120.0
        assert config.max_retries == 3
        assert config.verify_ssl is True
        assert config.context_size == 4096
        assert config.n_gpu_layers == -1

    def test_config_from_parameters(self):
        """Test creating config from parameters."""
        config = LlamaCppConfig(
            endpoint="http://192.168.1.100:8080",
            model="llama-2-7b",
            timeout=60.0,
            n_gpu_layers=32,
        )
        assert config.endpoint == "http://192.168.1.100:8080"
        assert config.model == "llama-2-7b"
        assert config.timeout == 60.0
        assert config.n_gpu_layers == 32

    def test_config_from_environment(self, monkeypatch):
        """Test creating config from environment variables."""
        monkeypatch.setenv("LLAMACPP_ENDPOINT", "http://llama.example.com:8080")

        config = LlamaCppConfig()
        assert config.endpoint == "http://llama.example.com:8080"

    def test_config_normalizes_endpoint(self):
        """Test endpoint normalization (removes trailing slash)."""
        config = LlamaCppConfig(endpoint="http://localhost:8080/")
        assert config.endpoint == "http://localhost:8080"

    def test_config_ssl_warning(self, caplog):
        """Test warning when SSL verification is disabled."""
        config = LlamaCppConfig(verify_ssl=False)
        assert config.verify_ssl is False
        # Warning should be logged (check in caplog if needed)


class TestLlamaCppFactory:
    """Test llama.cpp factory integration."""

    def test_llamacpp_in_providers(self):
        """Test llamacpp is in available providers."""
        providers = list_llm_providers()
        assert "llamacpp" in providers

    def test_create_llamacpp_via_factory(self):
        """Test creating llama.cpp client via factory."""
        config = LlamaCppConfig(endpoint="http://localhost:8080")
        client = create_llm_client("llamacpp", config)
        assert isinstance(client, LlamaCppClient)
        assert client.config.endpoint == "http://localhost:8080"


@pytest.mark.asyncio
class TestLlamaCppClient:
    """Test llama.cpp client."""

    async def test_client_context_manager(self):
        """Test client can be used as context manager."""
        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            assert client.http_client is not None

    async def test_client_start_stop(self):
        """Test client manual start/stop."""
        config = LlamaCppConfig(endpoint="http://localhost:8080")
        client = LlamaCppClient(config)

        assert client.http_client is None

        await client.start()
        assert client.http_client is not None

        await client.stop()
        assert client.http_client is None

    async def test_client_requires_context_manager(self):
        """Test client raises error when used without initialization."""
        config = LlamaCppConfig(endpoint="http://localhost:8080")
        client = LlamaCppClient(config)

        with pytest.raises(RuntimeError, match="llama.cpp client not started"):
            await client.complete("test")

    @respx.mock
    async def test_complete_success(self):
        """Test successful completion request."""
        # Mock llama.cpp server response
        mock_response = {
            "id": "chatcmpl-test-123",
            "object": "chat.completion",
            "created": 1234567890,
            "model": "llama-2-7b",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": "Asthma is a chronic respiratory condition.",
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 15, "total_tokens": 25},
        }

        respx.post("http://localhost:8080/v1/chat/completions").mock(
            return_value=Response(200, json=mock_response)
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            response = await client.complete(
                prompt="What is asthma?", temperature=0.7, max_tokens=500
            )

            assert response.text == "Asthma is a chronic respiratory condition."
            assert response.finish_reason == "stop"
            assert response.tokens.prompt_tokens == 10
            assert response.tokens.completion_tokens == 15
            assert response.tokens.total_tokens == 25
            assert response.tokens.estimated_cost == 0.0  # Self-hosted
            assert response.model == "llama-cpp-model"

    @respx.mock
    async def test_complete_with_messages_success(self):
        """Test successful chat completion with messages."""
        mock_response = {
            "id": "chatcmpl-test-456",
            "object": "chat.completion",
            "created": 1234567890,
            "model": "llama-2-7b",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": "Hello! How can I help you today?",
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 20, "completion_tokens": 12, "total_tokens": 32},
        }

        respx.post("http://localhost:8080/v1/chat/completions").mock(
            return_value=Response(200, json=mock_response)
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            messages = [
                LLMMessage(role="system", content="You are a helpful assistant"),
                LLMMessage(role="user", content="Hi there!"),
            ]

            response = await client.complete_with_messages(
                messages=messages, temperature=0.7, max_tokens=500
            )

            assert response.text == "Hello! How can I help you today?"
            assert response.finish_reason == "stop"
            assert response.tokens.total_tokens == 32

    @respx.mock
    async def test_complete_with_stop_sequences(self):
        """Test completion with stop sequences."""
        mock_response = {
            "id": "chatcmpl-test-789",
            "object": "chat.completion",
            "created": 1234567890,
            "model": "llama-2-7b",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "Test response"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
        }

        # Capture the request to verify stop sequences are sent
        route = respx.post("http://localhost:8080/v1/chat/completions").mock(
            return_value=Response(200, json=mock_response)
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            await client.complete(
                prompt="Test", temperature=0.7, max_tokens=100, stop=["END", "\n\n"]
            )

            # Verify request payload included stop sequences
            assert route.called
            request = route.calls.last.request
            payload = request.read()
            assert b'"stop":' in payload or b"'stop':" in payload

    @respx.mock
    async def test_complete_context_length_error(self):
        """Test context length exceeded error."""
        error_response = "Error: prompt is too long (context exceeded)"

        respx.post("http://localhost:8080/v1/chat/completions").mock(
            return_value=Response(400, text=error_response)
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080", context_size=4096)

        async with LlamaCppClient(config) as client:
            with pytest.raises(LLMContextLengthError) as exc_info:
                await client.complete("Test prompt")

            assert "context length" in str(exc_info.value).lower()
            assert exc_info.value.max_tokens == 4096

    @respx.mock
    async def test_complete_rate_limit_error(self):
        """Test rate limit error (429 status)."""
        respx.post("http://localhost:8080/v1/chat/completions").mock(
            return_value=Response(
                429,
                headers={"retry-after": "60"},
                text="Rate limit exceeded",
            )
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            with pytest.raises(LLMRateLimitError) as exc_info:
                await client.complete("Test prompt")

            assert exc_info.value.retry_after == 60

    @respx.mock
    async def test_complete_http_error(self):
        """Test generic HTTP error."""
        respx.post("http://localhost:8080/v1/chat/completions").mock(
            return_value=Response(500, text="Internal server error")
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            with pytest.raises(LLMAPIError) as exc_info:
                await client.complete("Test prompt")

            assert exc_info.value.status_code == 500
            assert "Internal server error" in exc_info.value.response_body

    @respx.mock
    async def test_complete_connection_error(self):
        """Test connection error."""
        respx.post("http://localhost:8080/v1/chat/completions").mock(
            side_effect=Exception("Connection refused")
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            with pytest.raises(LLMAPIError) as exc_info:
                await client.complete("Test prompt")

            assert "Connection refused" in str(exc_info.value)

    async def test_count_tokens(self):
        """Test token counting (character-based estimation)."""
        config = LlamaCppConfig(endpoint="http://localhost:8080")
        client = LlamaCppClient(config)

        # Test with sample text
        text = "This is a test prompt with multiple words"
        token_count = await client.count_tokens(text)

        # Should use ~4 chars per token estimation
        expected_tokens = len(text) // 4
        assert token_count == expected_tokens

    async def test_estimate_cost(self):
        """Test cost estimation (always 0 for self-hosted)."""
        config = LlamaCppConfig(endpoint="http://localhost:8080")
        client = LlamaCppClient(config)

        from ashmatics_tools.llm import TokenUsage

        tokens = TokenUsage(
            prompt_tokens=1000, completion_tokens=500, total_tokens=1500, estimated_cost=0.0
        )

        cost = await client.estimate_cost(tokens)
        assert cost == 0.0

    @respx.mock
    async def test_get_server_health(self):
        """Test getting server health status."""
        health_data = {
            "status": "ok",
            "slots_idle": 1,
            "slots_processing": 0,
        }

        respx.get("http://localhost:8080/health").mock(
            return_value=Response(200, json=health_data)
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            health = await client.get_server_health()
            assert health["status"] == "ok"
            assert health["slots_idle"] == 1

    @respx.mock
    async def test_get_server_health_error(self):
        """Test server health check failure."""
        respx.get("http://localhost:8080/health").mock(
            return_value=Response(503, text="Service unavailable")
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            with pytest.raises(LLMAPIError):
                await client.get_server_health()

    @respx.mock
    async def test_get_server_props(self):
        """Test getting server properties."""
        props_data = {
            "default_generation_settings": {
                "n_ctx": 4096,
                "model": "llama-2-7b.gguf",
            },
            "total_slots": 1,
        }

        respx.get("http://localhost:8080/props").mock(
            return_value=Response(200, json=props_data)
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            props = await client.get_server_props()
            assert props["default_generation_settings"]["n_ctx"] == 4096
            assert props["total_slots"] == 1

    @respx.mock
    async def test_get_server_props_error(self):
        """Test server properties request failure."""
        respx.get("http://localhost:8080/props").mock(
            return_value=Response(500, text="Internal error")
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            with pytest.raises(LLMAPIError):
                await client.get_server_props()

    @respx.mock
    async def test_complete_with_additional_kwargs(self):
        """Test completion with llama.cpp-specific parameters."""
        mock_response = {
            "id": "test",
            "object": "chat.completion",
            "created": 1234567890,
            "model": "llama-2-7b",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "Response"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 5, "completion_tokens": 5, "total_tokens": 10},
        }

        route = respx.post("http://localhost:8080/v1/chat/completions").mock(
            return_value=Response(200, json=mock_response)
        )

        config = LlamaCppConfig(endpoint="http://localhost:8080")

        async with LlamaCppClient(config) as client:
            # Test with llama.cpp-specific parameters
            await client.complete(
                prompt="Test",
                temperature=0.8,
                max_tokens=100,
                top_p=0.9,
                top_k=40,
                repeat_penalty=1.1,
            )

            # Verify request included custom parameters
            assert route.called
            request = route.calls.last.request
            payload = request.read()
            # Parameters should be in payload
            assert b"top_p" in payload or b"temperature" in payload
