"""Tests for document storage managers.

Tests the functionality of:
- FigureStorageManager
- TableStorageManager
"""

import json
from unittest.mock import MagicMock, patch
from ashmatics_tools.document_storage.figure_storage import (
    FigureStorageManager,
    ProcessedFigure,
)
from ashmatics_tools.document_storage.table_storage import (
    TableStorageManager,
    StoredTable,
)


class TestFigureStorageManager:
    """Tests for FigureStorageManager."""

    def test_process_figures_filtering(self):
        """Test that small figures are filtered out."""
        manager = FigureStorageManager(min_size=100)
        
        # Mock figures
        fig_large = MagicMock()
        # Ensure image_data is None so it falls back to image
        fig_large.image_data = None
        fig_large.image.size = (200, 200)
        fig_large.image.mode = "RGB"
        fig_large.image.tobytes.return_value = b"fake_bytes"
        fig_large.caption = "Large Figure"
        
        fig_small = MagicMock()
        # Ensure image_data is None so it falls back to image
        fig_small.image_data = None
        fig_small.image.size = (50, 50)
        fig_small.image.mode = "RGB"
        fig_small.image.tobytes.return_value = b"fake_bytes"
        fig_small.caption = "Small Figure"
        
        # We need to mock _image_to_png_bytes because it uses PIL
        with patch.object(manager, '_image_to_png_bytes', return_value=b"png_bytes"):
            processed = manager.process_figures([fig_large, fig_small])
            
            assert len(processed) == 1
            assert processed[0].caption == "Large Figure"
            assert processed[0].dimensions == (200, 200)

    def test_save_figures(self, tmp_path):
        """Test saving figures to disk."""
        manager = FigureStorageManager()
        
        figure = ProcessedFigure(
            figure_id="figure_1",
            image_data=None,
            image_bytes=b"fake_png_content",
            caption="Test Figure",
            dimensions=(100, 100),
            is_significant=True,
            file_hash="abc12345",
            metadata={}
        )
        
        # Mock _save_figures_manifest since it's a private method we don't want to test in isolation here
        # or we can let it run if it just writes a JSON file.
        # Let's let it run, but we need to make sure it doesn't fail.
        # The implementation of _save_figures_manifest wasn't fully read, but it likely writes a json file.
        
        # We'll patch it just in case to focus on image saving
        with patch.object(manager, '_save_figures_manifest'):
            saved_figures = manager.save_figures([figure], tmp_path, "doc_123")
            
            assert len(saved_figures) == 1
            assert saved_figures[0].local_path is not None
            assert saved_figures[0].local_path.exists()
            assert saved_figures[0].local_path.read_bytes() == b"fake_png_content"


class TestTableStorageManager:
    """Tests for TableStorageManager."""

    def test_process_tables(self):
        """Test processing tables into StoredTable objects."""
        manager = TableStorageManager()
        
        consolidated_table = MagicMock()
        consolidated_table.table_id = "table_1"
        consolidated_table.caption = "Test Table"
        consolidated_table.markdown = "| Col 1 | Col 2 |\n|---|---|\n| A | 1 |"
        consolidated_table.merged_from = []
        
        # Need to handle getattr for MagicMock correctly or use a simple object/dict
        # The manager uses a helper that checks hasattr then getattr
        
        tables = manager.process_tables([consolidated_table])
        
        assert len(tables) == 1
        assert tables[0].table_id == "table_1"
        assert tables[0].data is not None
        assert tables[0].data["headers"] == ["Col 1", "Col 2"]
        assert len(tables[0].data["rows"]) == 1

    def test_save_tables(self, tmp_path):
        """Test saving tables to Markdown and JSON."""
        manager = TableStorageManager()
        
        table = StoredTable(
            table_id="table_1",
            caption="Test Table",
            markdown="| Header |\n|---|\n| Value |",
            data={"headers": ["Header"], "rows": [["Value"]]},
            classification="performance_metrics"
        )
        
        # Mock _save_tables_manifest
        with patch.object(manager, '_save_tables_manifest'):
            saved_tables = manager.save_tables([table], tmp_path, "doc_123")
            
            assert len(saved_tables) == 1
            
            # Check Markdown file
            md_path = saved_tables[0].md_path
            assert md_path.exists()
            content = md_path.read_text()
            assert "table_id: table_1" in content
            assert "classification: performance_metrics" in content
            assert "| Header |" in content
            
            # Check JSON file
            json_path = saved_tables[0].json_path
            assert json_path.exists()
            data = json.loads(json_path.read_text())
            assert data["table_id"] == "table_1"
            assert data["classification"] == "performance_metrics"
            assert data["data"]["headers"] == ["Header"]
