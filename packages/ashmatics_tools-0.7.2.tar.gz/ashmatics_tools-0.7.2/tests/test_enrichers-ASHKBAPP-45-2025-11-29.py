"""Tests for document enrichers.

Tests the functionality of:
- MetricsExtractor
- TableClassifier
- TableConsolidator
- TrainingDataExtractor
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from ashmatics_tools.enrichers.metrics_extractor import (
    MetricsExtractor,
)
from ashmatics_tools.enrichers.table_classifier import (
    TableClassifier,
    TableCategory,
)
from ashmatics_tools.enrichers.table_consolidator import (
    TableConsolidator,
)
from ashmatics_tools.enrichers.training_data_extractor import (
    TrainingDataExtractor,
)
from ashmatics_tools.llm import LLMResponse, TokenUsage


@pytest.fixture
def mock_llm_client():
    """Create a mock LLM client."""
    client = AsyncMock()
    client.__aenter__.return_value = client
    client.__aexit__.return_value = None
    return client


class TestMetricsExtractor:
    """Tests for MetricsExtractor."""

    @pytest.mark.asyncio
    async def test_extract_from_tables(self, mock_llm_client):
        """Test extracting metrics from tables."""
        # Setup mock response
        mock_response = LLMResponse(
            text="""
            {
                "has_metrics": true,
                "performance_metrics": [
                    {
                        "metric_name": "Sensitivity",
                        "metric_type": "sensitivity",
                        "value": 0.95,
                        "ci_lower": 0.90,
                        "ci_upper": 0.98
                    }
                ],
                "extraction_confidence": 90.0
            }
            """,
            tokens=TokenUsage(total_tokens=100, prompt_tokens=50, completion_tokens=50),
            model="gpt-4",
            finish_reason="stop",
        )
        mock_llm_client.complete_with_messages.return_value = mock_response

        extractor = MetricsExtractor(llm_client=mock_llm_client)
        
        tables = [
            {
                "table_id": "table_1",
                "caption": "Performance Results",
                "markdown": "| Metric | Value | 95% CI |\n|---|---|---|\n| Sensitivity | 95% | 90-98% |"
            }
        ]

        # Mock the internal _llm_extract_metrics method or the LLM call directly
        # Since _llm_extract_metrics is not shown in the read_file output, 
        # I'll assume it calls the LLM and parses the JSON.
        # However, looking at the code structure, I might need to mock the private method 
        # if the public method does complex logic.
        # But let's try mocking the LLM client first.
        
        # Note: The actual implementation of _llm_extract_metrics wasn't fully visible in the read_file output.
        # Assuming it parses the JSON response from the LLM.
        
        # We need to patch the private method because the LLM prompt construction and parsing logic 
        # might be complex and we want to test the flow.
        # But for this test, let's assume we can mock the LLM response text to be valid JSON 
        # that the extractor expects.
        
        # Wait, I need to see the _llm_extract_metrics implementation to know what JSON structure it expects.
        # Since I didn't read the full file, I'll make a safe assumption or patch the private method.
        # Let's patch the private method to return a dict, which is safer.
        
        with patch.object(extractor, '_llm_extract_metrics', new_callable=AsyncMock) as mock_extract:
            mock_extract.return_value = {
                "has_metrics": True,
                "performance_metrics": [
                    {
                        "metric_name": "Sensitivity",
                        "metric_type": "sensitivity",
                        "value": 0.95,
                        "ci_lower": 0.90,
                        "ci_upper": 0.98
                    }
                ],
                "extraction_confidence": 90.0
            }
            
            result = await extractor.extract_from_tables(tables)

            assert result.has_metrics is True
            assert len(result.performance_metrics) == 1
            metric = result.performance_metrics[0]
            assert metric.metric_name == "Sensitivity"
            assert metric.value == 0.95
            assert metric.ci_lower == 0.90


class TestTableClassifier:
    """Tests for TableClassifier."""

    @pytest.mark.asyncio
    async def test_classify_tables(self, mock_llm_client):
        """Test classifying multiple tables."""
        # Setup mock response
        mock_response = LLMResponse(
            text="performance_metrics",
            tokens=TokenUsage(total_tokens=50, prompt_tokens=25, completion_tokens=25),
            model="gpt-4",
            finish_reason="stop",
        )
        mock_llm_client.complete_with_messages.return_value = mock_response

        classifier = TableClassifier(llm_client=mock_llm_client)
        
        tables = [
            {
                "table_id": "table_1",
                "caption": "Performance Results",
                "markdown": "| Metric | Value |"
            }
        ]

        categories, tokens = await classifier.classify_tables(tables)

        assert len(categories) == 1
        assert categories[0] == TableCategory.PERFORMANCE_METRICS
        assert tokens == 50

    @pytest.mark.asyncio
    async def test_classify_single_table(self, mock_llm_client):
        """Test classifying a single table."""
        mock_response = LLMResponse(
            text="comparison",
            tokens=TokenUsage(total_tokens=50, prompt_tokens=25, completion_tokens=25),
            model="gpt-4",
            finish_reason="stop",
        )
        mock_llm_client.complete_with_messages.return_value = mock_response

        classifier = TableClassifier(llm_client=mock_llm_client)
        
        table = {
            "table_id": "table_1",
            "caption": "Device Comparison",
            "markdown": "| Feature | Device A | Device B |"
        }

        category = await classifier.classify_single_table(table)

        assert category == TableCategory.COMPARISON


class TestTableConsolidator:
    """Tests for TableConsolidator."""

    @pytest.mark.asyncio
    async def test_consolidate_tables_heuristic(self):
        """Test consolidating tables using heuristics (continuation markers)."""
        consolidator = TableConsolidator(use_llm_validation=False)
        
        tables = [
            MagicMock(
                caption="Table 1: Results",
                markdown="| Col 1 | Col 2 |\n|---|---|\n| A | 1 |"
            ),
            MagicMock(
                caption="Table 1 (cont'd)",
                markdown="| Col 1 | Col 2 |\n|---|---|\n| B | 2 |"
            )
        ]
        # Mock attributes that might be accessed as dict keys or object attributes
        # The implementation checks getattr first
        
        consolidated = await consolidator.consolidate_tables(tables)

        assert len(consolidated) == 1
        assert consolidated[0].table_id == "table_1"
        assert len(consolidated[0].merged_from) == 1
        # Check if content is merged (implementation detail: it should contain rows from both)
        assert "A" in consolidated[0].markdown
        assert "B" in consolidated[0].markdown


class TestTrainingDataExtractor:
    """Tests for TrainingDataExtractor."""

    @pytest.mark.asyncio
    async def test_extract_from_text(self, mock_llm_client):
        """Test extracting training data from text."""
        extractor = TrainingDataExtractor(llm_client=mock_llm_client)
        
        # Patch the private method to avoid LLM complexity
        with patch.object(extractor, '_llm_extract_training_data', new_callable=AsyncMock) as mock_extract:
            mock_extract.return_value = {
                "has_training_data": True,
                "dataset_characteristics": {
                    "dataset_size": 1000,
                    "data_source": "Public dataset"
                },
                "extraction_confidence": 85.0
            }
            
            result = await extractor.extract_from_text("The model was trained on 1000 images.")

            assert result.has_training_data is True
            assert result.dataset_characteristics.dataset_size == 1000
            assert result.dataset_characteristics.data_source == "Public dataset"
