# Copyright 2025 Asher Informatics PBC
"""Tests for AccessGUDID API client and MCP server."""

from datetime import date

import pytest
import respx
from httpx import Response

from ashmatics_tools.external_apis import (
    AccessGUDIDClient,
    AccessGUDIDConfig,
    AccessGUDIDEndpoint,
    create_api_client,
    list_api_providers,
)
from ashmatics_tools.external_apis.accessgudid import (
    DeviceHistory,
    DeviceLookupResult,
    DeviceSNOMED,
    GUDIDDevice,
    ImplantableDevice,
    ParsedUDI,
    SNOMEDConcept,
    UDIIssuingAgency,
    parse_gudid_date,
    transform_device_history,
    transform_device_lookup,
    transform_device_snomed,
    transform_implantable_device,
    transform_parsed_udi,
)
from ashmatics_tools.mcp_servers import (
    AccessGUDIDMCPConfig,
    AccessGUDIDMCPServer,
    create_mcp_server,
    list_mcp_servers,
)


# ============================================================================
# Configuration Tests
# ============================================================================


@pytest.fixture
def accessgudid_config():
    """Create test AccessGUDID configuration."""
    return AccessGUDIDConfig(timeout=10.0)


@pytest.fixture
def accessgudid_client(accessgudid_config):
    """Create test AccessGUDID client."""
    return AccessGUDIDClient(accessgudid_config)


def test_accessgudid_config_defaults():
    """Test AccessGUDID configuration defaults."""
    config = AccessGUDIDConfig()
    assert config.base_url == "https://accessgudid.nlm.nih.gov/api/v3"
    assert config.umls_api_key is None
    assert config.verify_ssl is True
    assert config.timeout == 30.0


def test_accessgudid_config_with_umls_key():
    """Test AccessGUDID configuration with UMLS API key."""
    config = AccessGUDIDConfig(umls_api_key="test_umls_key")
    assert config.umls_api_key == "test_umls_key"


def test_accessgudid_rate_limits():
    """Test AccessGUDID rate limiting configuration."""
    config = AccessGUDIDConfig()
    # Conservative rate limiting
    assert config.rate_limit.requests_per_second == 2.0
    assert config.rate_limit.burst_size == 5
    assert config.rate_limit.use_rate_limiting is True


# ============================================================================
# Endpoint Tests
# ============================================================================


def test_endpoint_enum():
    """Test AccessGUDID endpoint enum values."""
    assert AccessGUDIDEndpoint.DEVICE_LOOKUP.value == "devices/lookup"
    assert AccessGUDIDEndpoint.DEVICE_HISTORY.value == "devices/history"
    assert AccessGUDIDEndpoint.DEVICE_SNOMED.value == "devices/snomed"
    assert AccessGUDIDEndpoint.IMPLANTABLE_LIST.value == "devices/implantable/list"
    assert AccessGUDIDEndpoint.PARSE_UDI.value == "parse_udi"


def test_endpoint_path(accessgudid_client):
    """Test endpoint path generation."""
    assert (
        accessgudid_client.get_endpoint_path("devices/lookup")
        == "/devices/lookup.json"
    )
    assert (
        accessgudid_client.get_endpoint_path(AccessGUDIDEndpoint.DEVICE_LOOKUP)
        == "/devices/lookup.json"
    )
    assert (
        accessgudid_client.get_endpoint_path(AccessGUDIDEndpoint.PARSE_UDI)
        == "/parse_udi.json"
    )


# ============================================================================
# Response Parsing Tests
# ============================================================================


def test_parse_response_device_lookup(accessgudid_client):
    """Test parsing device lookup response."""
    response = {
        "gudid": {
            "device": {
                "brandName": "Test Device",
                "companyName": "Test Company",
                "deviceId": "12345678901234",
            }
        }
    }

    results = accessgudid_client._parse_response(response)
    assert len(results) == 1
    assert results[0]["gudid"]["device"]["brandName"] == "Test Device"


def test_parse_response_udi_parse(accessgudid_client):
    """Test parsing UDI parse response."""
    response = {
        "udi": "(01)00844588012919(17)141231(10)A213B1",
        "di": "00844588012919",
        "issuingAgency": "GS1",
        "expirationDate": "2014-12-31",
        "lotNumber": "A213B1",
    }

    results = accessgudid_client._parse_response(response)
    assert len(results) == 1
    assert results[0]["di"] == "00844588012919"
    assert results[0]["issuingAgency"] == "GS1"


def test_parse_response_snomed(accessgudid_client):
    """Test parsing SNOMED response."""
    response = {
        "concepts": [
            {"snomedCTName": "Heart pacemaker", "snomedIdentifier": "14106009"},
            {"snomedCTName": "Implantable device", "snomedIdentifier": "72070000"},
        ]
    }

    results = accessgudid_client._parse_response(response)
    assert len(results) == 1
    assert len(results[0]["concepts"]) == 2


def test_parse_response_device_list(accessgudid_client):
    """Test parsing device list response."""
    response = {
        "devices": [
            {"deviceId": "1", "brandName": "Device 1"},
            {"deviceId": "2", "brandName": "Device 2"},
        ],
        "total": 100,
        "page": 1,
        "per_page": 100,
    }

    results = accessgudid_client._parse_response(response)
    assert len(results) == 2
    assert results[0]["brandName"] == "Device 1"


# ============================================================================
# API Client Tests (with mocks)
# ============================================================================


@pytest.mark.asyncio
@respx.mock
async def test_lookup_device_by_di(accessgudid_client):
    """Test device lookup by DI."""
    mock_response = {
        "gudid": {
            "device": {
                "brandName": "Test Pacemaker",
                "companyName": "Test Medical Inc",
                "deviceId": "08717648200274",
                "versionModelNumber": "ABC-123",
            }
        }
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/devices/lookup.json"
    ).mock(return_value=Response(200, json=mock_response))

    async with accessgudid_client:
        result = await accessgudid_client.lookup_device(di="08717648200274")

    assert result["gudid"]["device"]["brandName"] == "Test Pacemaker"
    assert result["gudid"]["device"]["companyName"] == "Test Medical Inc"


@pytest.mark.asyncio
@respx.mock
async def test_parse_udi(accessgudid_client):
    """Test UDI parsing."""
    mock_response = {
        "udi": "(01)00844588012919(17)141231(10)A213B1",
        "di": "00844588012919",
        "issuingAgency": "GS1",
        "expirationDate": "2014-12-31",
        "lotNumber": "A213B1",
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/parse_udi.json"
    ).mock(return_value=Response(200, json=mock_response))

    async with accessgudid_client:
        result = await accessgudid_client.parse_udi(
            udi="(01)00844588012919(17)141231(10)A213B1"
        )

    assert result["di"] == "00844588012919"
    assert result["issuingAgency"] == "GS1"
    assert result["lotNumber"] == "A213B1"


@pytest.mark.asyncio
@respx.mock
async def test_get_device_history(accessgudid_client):
    """Test getting device history."""
    mock_response = {
        "deviceHistory": [
            {
                "publicVersionNumber": "3",
                "publicVersionDate": "2024-06-15",
            },
            {
                "publicVersionNumber": "2",
                "publicVersionDate": "2023-03-10",
            },
            {
                "publicVersionNumber": "1",
                "publicVersionDate": "2022-01-01",
            },
        ]
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/devices/history.json"
    ).mock(return_value=Response(200, json=mock_response))

    async with accessgudid_client:
        result = await accessgudid_client.get_device_history(di="08717648200274")

    assert len(result["deviceHistory"]) == 3
    assert result["deviceHistory"][0]["publicVersionNumber"] == "3"


@pytest.mark.asyncio
@respx.mock
async def test_get_device_snomed():
    """Test getting SNOMED codes."""
    config = AccessGUDIDConfig(umls_api_key="test_key")
    client = AccessGUDIDClient(config)

    mock_response = {
        "concepts": [
            {"snomedCTName": "Cardiac pacemaker", "snomedIdentifier": "14106009"},
        ]
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/devices/snomed.json"
    ).mock(return_value=Response(200, json=mock_response))

    async with client:
        result = await client.get_device_snomed(di="08717648200274")

    assert len(result["concepts"]) == 1
    assert result["concepts"][0]["snomedCTName"] == "Cardiac pacemaker"


@pytest.mark.asyncio
@respx.mock
async def test_list_implantable_devices(accessgudid_client):
    """Test listing implantable devices."""
    mock_response = {
        "devices": [
            {"deviceId": "1", "brandName": "Implant A", "companyName": "Company A"},
            {"deviceId": "2", "brandName": "Implant B", "companyName": "Company B"},
        ],
        "total": 2,
        "page": 1,
        "per_page": 100,
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/devices/implantable/list.json"
    ).mock(return_value=Response(200, json=mock_response))

    results = []
    async with accessgudid_client:
        async for device in accessgudid_client.list_implantable_devices(max_records=10):
            results.append(device)

    assert len(results) == 2
    assert results[0]["brandName"] == "Implant A"


# ============================================================================
# Validation Tests
# ============================================================================


@pytest.mark.asyncio
async def test_lookup_device_requires_identifier(accessgudid_client):
    """Test that lookup_device requires at least one identifier."""
    async with accessgudid_client:
        with pytest.raises(ValueError, match="At least one of"):
            await accessgudid_client.lookup_device()


@pytest.mark.asyncio
async def test_snomed_requires_api_key():
    """Test that SNOMED lookup requires API key."""
    config = AccessGUDIDConfig()  # No UMLS API key
    client = AccessGUDIDClient(config)

    async with client:
        with pytest.raises(ValueError, match="UMLS API key is required"):
            await client.get_device_snomed(di="08717648200274")


# ============================================================================
# Factory Tests
# ============================================================================


def test_factory_create_accessgudid_client():
    """Test API client factory for AccessGUDID."""
    config = AccessGUDIDConfig()
    client = create_api_client("accessgudid", config)

    assert isinstance(client, AccessGUDIDClient)


def test_factory_list_providers_includes_accessgudid():
    """Test listing API providers includes AccessGUDID."""
    providers = list_api_providers()
    assert "accessgudid" in providers
    assert "openfda" in providers


# ============================================================================
# MCP Server Tests
# ============================================================================


@pytest.fixture
def mcp_config():
    """Create test MCP configuration."""
    return AccessGUDIDMCPConfig(
        api_config=AccessGUDIDConfig(timeout=10.0),
        max_response_size=50_000,
    )


@pytest.fixture
def mcp_server(mcp_config):
    """Create test MCP server."""
    return AccessGUDIDMCPServer(mcp_config)


def test_mcp_config_defaults():
    """Test MCP configuration defaults."""
    config = AccessGUDIDMCPConfig()
    assert config.name == "accessgudid"
    assert config.version == "1.0.0"
    assert config.description == "MCP server for NIH/FDA AccessGUDID Device Database"
    assert config.max_response_size == 50_000
    assert config.api_config is not None


def test_mcp_server_get_tools(mcp_server):
    """Test MCP server tools list."""
    tools = mcp_server.get_tools()

    tool_names = [t["name"] for t in tools]
    assert "lookup_device" in tool_names
    assert "parse_udi" in tool_names
    assert "get_device_history" in tool_names
    assert "get_device_snomed" in tool_names
    assert "list_implantable_devices" in tool_names


def test_mcp_tool_schemas(mcp_server):
    """Test MCP tool schemas are valid."""
    tools = mcp_server.get_tools()

    for tool in tools:
        assert "name" in tool
        assert "description" in tool
        assert "inputSchema" in tool
        assert tool["inputSchema"]["type"] == "object"
        assert "properties" in tool["inputSchema"]


@pytest.mark.asyncio
@respx.mock
async def test_mcp_call_lookup_device(mcp_server):
    """Test MCP server lookup_device tool."""
    mock_response = {
        "gudid": {
            "device": {
                "brandName": "Test Device",
                "companyName": "Test Company",
                "deviceId": "12345678901234",
                "versionModelNumber": "V1.0",
                "deviceDescription": "A test medical device",
            }
        }
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/devices/lookup.json"
    ).mock(return_value=Response(200, json=mock_response))

    result = await mcp_server.call_tool("lookup_device", {"di": "12345678901234"})

    assert result["success"] is True
    assert result["summary"]["brandName"] == "Test Device"
    assert result["summary"]["companyName"] == "Test Company"


@pytest.mark.asyncio
@respx.mock
async def test_mcp_call_parse_udi(mcp_server):
    """Test MCP server parse_udi tool."""
    mock_response = {
        "udi": "(01)00844588012919(17)141231(10)A213B1",
        "di": "00844588012919",
        "issuingAgency": "GS1",
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/parse_udi.json"
    ).mock(return_value=Response(200, json=mock_response))

    result = await mcp_server.call_tool(
        "parse_udi",
        {"udi": "(01)00844588012919(17)141231(10)A213B1"},
    )

    assert result["success"] is True
    assert result["parsed"]["di"] == "00844588012919"


@pytest.mark.asyncio
async def test_mcp_unknown_tool(mcp_server):
    """Test MCP server with unknown tool."""
    result = await mcp_server.call_tool("unknown_tool", {})

    assert result["error"] is True
    assert "Unknown tool" in result["message"]


def test_mcp_factory_create_server():
    """Test MCP server factory for AccessGUDID."""
    config = AccessGUDIDMCPConfig()
    server = create_mcp_server("accessgudid", config)

    assert isinstance(server, AccessGUDIDMCPServer)


def test_mcp_factory_list_servers_includes_accessgudid():
    """Test listing MCP servers includes AccessGUDID."""
    servers = list_mcp_servers()
    assert "accessgudid" in servers
    assert "openfda" in servers


# ============================================================================
# Typed Models and Transforms Tests
# ============================================================================


def test_parse_gudid_date():
    """Test date parsing for various formats."""
    # YYYY-MM-DD format
    assert parse_gudid_date("2024-12-31") == date(2024, 12, 31)

    # YYYYMMDD format (fallback)
    assert parse_gudid_date("20241231") == date(2024, 12, 31)

    # None input
    assert parse_gudid_date(None) is None

    # Invalid input
    assert parse_gudid_date("invalid") is None


def test_transform_parsed_udi():
    """Test UDI parsing transformation."""
    raw = {
        "udi": "(01)00844588012919(17)141231(10)A213B1",
        "issuingAgency": "GS1",
        "di": "00844588012919",
        "expirationDate": "2014-12-31",
        "lotNumber": "A213B1",
        "serialNumber": "SN123",
    }

    parsed = transform_parsed_udi(raw)

    assert isinstance(parsed, ParsedUDI)
    assert parsed.udi == "(01)00844588012919(17)141231(10)A213B1"
    assert parsed.issuing_agency == UDIIssuingAgency.GS1
    assert parsed.di == "00844588012919"
    assert parsed.expiration_date == date(2014, 12, 31)
    assert parsed.lot_number == "A213B1"
    assert parsed.serial_number == "SN123"


def test_transform_device_lookup():
    """Test device lookup transformation."""
    raw = {
        "gudid": {
            "device": {
                "brandName": "Test Pacemaker",
                "companyName": "Test Medical Inc",
                "deviceId": "08717648200274",
                "versionModelNumber": "ABC-123",
                "deviceDescription": "Test device description",
                "issuingAgency": "GS1",
                "singleUse": True,
                "rx": True,
            }
        }
    }

    result = transform_device_lookup(raw)

    assert isinstance(result, DeviceLookupResult)
    assert isinstance(result.device, GUDIDDevice)
    assert result.device.brand_name == "Test Pacemaker"
    assert result.device.company_name == "Test Medical Inc"
    assert result.device.device_id == "08717648200274"
    assert result.device.version_model_number == "ABC-123"
    assert result.device.is_single_use is True
    assert result.device.is_rx is True


def test_transform_device_history():
    """Test device history transformation."""
    raw = {
        "di": "08717648200274",
        "deviceHistory": [
            {"publicVersionNumber": "3", "publicVersionDate": "2024-06-15"},
            {"publicVersionNumber": "2", "publicVersionDate": "2023-03-10"},
            {"publicVersionNumber": "1", "publicVersionDate": "2022-01-01"},
        ],
    }

    history = transform_device_history(raw)

    assert isinstance(history, DeviceHistory)
    assert history.device_id == "08717648200274"
    assert len(history.versions) == 3
    assert history.versions[0].public_version_number == "3"
    assert history.versions[0].public_version_date == date(2024, 6, 15)


def test_transform_device_snomed():
    """Test SNOMED transformation."""
    raw = {
        "di": "08717648200274",
        "concepts": [
            {"snomedCTName": "Cardiac pacemaker", "snomedIdentifier": "14106009"},
            {"snomedCTName": "Implantable device", "snomedIdentifier": "72070000"},
        ],
    }

    snomed = transform_device_snomed(raw)

    assert isinstance(snomed, DeviceSNOMED)
    assert snomed.device_id == "08717648200274"
    assert len(snomed.concepts) == 2
    assert isinstance(snomed.concepts[0], SNOMEDConcept)
    assert snomed.concepts[0].snomed_ct_name == "Cardiac pacemaker"
    assert snomed.concepts[0].snomed_identifier == "14106009"


def test_transform_implantable_device():
    """Test implantable device transformation."""
    raw = {
        "deviceId": "12345678901234",
        "brandName": "Implant A",
        "companyName": "Company A",
        "versionModelNumber": "V1.0",
        "MRISafetyStatus": "MR Conditional",
        "labeledContainsNRL": False,
        "deviceRecordStatus": "Published",
    }

    device = transform_implantable_device(raw)

    assert isinstance(device, ImplantableDevice)
    assert device.device_id == "12345678901234"
    assert device.brand_name == "Implant A"
    assert device.company_name == "Company A"
    assert device.mri_safety_status == "MR Conditional"
    assert device.labeled_contains_nrl is False


@pytest.mark.asyncio
@respx.mock
async def test_lookup_device_typed(accessgudid_client):
    """Test typed device lookup."""
    mock_response = {
        "gudid": {
            "device": {
                "brandName": "Test Device Typed",
                "companyName": "Test Company Typed",
                "deviceId": "08717648200274",
            }
        }
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/devices/lookup.json"
    ).mock(return_value=Response(200, json=mock_response))

    async with accessgudid_client:
        result = await accessgudid_client.lookup_device_typed(di="08717648200274")

    assert isinstance(result, DeviceLookupResult)
    assert result.device.brand_name == "Test Device Typed"
    assert result.device.company_name == "Test Company Typed"


@pytest.mark.asyncio
@respx.mock
async def test_parse_udi_typed(accessgudid_client):
    """Test typed UDI parsing."""
    mock_response = {
        "udi": "(01)00844588012919(17)141231(10)A213B1",
        "issuingAgency": "GS1",
        "di": "00844588012919",
        "expirationDate": "2014-12-31",
        "lotNumber": "A213B1",
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/parse_udi.json"
    ).mock(return_value=Response(200, json=mock_response))

    async with accessgudid_client:
        parsed = await accessgudid_client.parse_udi_typed(
            udi="(01)00844588012919(17)141231(10)A213B1"
        )

    assert isinstance(parsed, ParsedUDI)
    assert parsed.issuing_agency == UDIIssuingAgency.GS1
    assert parsed.di == "00844588012919"
    assert parsed.lot_number == "A213B1"
    assert parsed.expiration_date == date(2014, 12, 31)


@pytest.mark.asyncio
@respx.mock
async def test_get_device_history_typed(accessgudid_client):
    """Test typed device history."""
    mock_response = {
        "di": "08717648200274",
        "deviceHistory": [
            {"publicVersionNumber": "2", "publicVersionDate": "2024-01-15"},
            {"publicVersionNumber": "1", "publicVersionDate": "2023-06-01"},
        ],
    }

    respx.get(
        "https://accessgudid.nlm.nih.gov/api/v3/devices/history.json"
    ).mock(return_value=Response(200, json=mock_response))

    async with accessgudid_client:
        history = await accessgudid_client.get_device_history_typed(di="08717648200274")

    assert isinstance(history, DeviceHistory)
    assert len(history.versions) == 2
    assert history.versions[0].public_version_number == "2"
    assert history.versions[0].public_version_date == date(2024, 1, 15)
