"""Tests for embedders module.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import os
from unittest.mock import AsyncMock, patch

import pytest

from ashmatics_tools.chunkers.base import DocumentChunk
from ashmatics_tools.embedders import (
    EmbeddingConfig,
    EmbeddingProvider,
    create_embedder,
)


# Helper fixture to skip OpenAI tests if API key not available
@pytest.fixture
def skip_if_no_openai_key():
    """Skip test if OPENAI_API_KEY environment variable is not set."""
    if not os.getenv("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not available")


class TestEmbeddingConfig:
    """Test EmbeddingConfig validation."""

    def test_config_defaults(self):
        """Test default configuration."""
        config = EmbeddingConfig()

        assert config.provider == EmbeddingProvider.AZURE
        assert config.model == "text-embedding-3-small"
        assert config.dimensions is None
        assert config.batch_size == 100
        assert config.max_retries == 3
        assert config.retry_delay == 1.0
        assert config.use_cache is True
        assert config.cache_size == 1000

    def test_config_custom_values(self):
        """Test configuration with custom values."""
        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            model="text-embedding-3-large",
            dimensions=2048,
            batch_size=50,
            max_retries=5,
            retry_delay=2.0,
            use_cache=False,
            cache_size=500,
        )

        assert config.provider == EmbeddingProvider.OPENAI
        assert config.model == "text-embedding-3-large"
        assert config.dimensions == 2048
        assert config.batch_size == 50
        assert config.max_retries == 5
        assert config.retry_delay == 2.0
        assert config.use_cache is False
        assert config.cache_size == 500

    def test_invalid_batch_size(self):
        """Test batch size must be at least 1."""
        with pytest.raises(ValueError, match="batch_size must be at least 1"):
            EmbeddingConfig(batch_size=0)

        with pytest.raises(ValueError, match="batch_size must be at least 1"):
            EmbeddingConfig(batch_size=-10)

    def test_invalid_max_retries(self):
        """Test max_retries must be non-negative."""
        with pytest.raises(ValueError, match="max_retries must be non-negative"):
            EmbeddingConfig(max_retries=-1)

    def test_invalid_retry_delay(self):
        """Test retry_delay must be non-negative."""
        with pytest.raises(ValueError, match="retry_delay must be non-negative"):
            EmbeddingConfig(retry_delay=-1.0)


class TestEmbedderFactory:
    """Test embedder factory function."""

    def test_create_default_embedder(self):
        """Test creating embedder with default settings."""
        # Use Azure since we have Azure credentials in env
        embedder = create_embedder("azure")
        assert embedder is not None
        assert embedder.config.provider == EmbeddingProvider.AZURE

    def test_create_openai_embedder(self):
        """Test creating OpenAI embedder."""
        import os

        # Skip if OPENAI_API_KEY not available
        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        embedder = create_embedder("openai")
        assert embedder is not None
        assert embedder.config.provider == EmbeddingProvider.OPENAI

    def test_create_azure_embedder(self):
        """Test creating Azure embedder."""
        embedder = create_embedder("azure")
        assert embedder is not None
        assert embedder.config.provider == EmbeddingProvider.AZURE

    def test_create_with_custom_config(self):
        """Test creating embedder with custom config."""
        config = EmbeddingConfig(
            provider=EmbeddingProvider.AZURE,
            model="text-embedding-3-large",
            batch_size=50,
        )
        embedder = create_embedder("azure", config)

        assert embedder.config.model == "text-embedding-3-large"
        assert embedder.config.batch_size == 50

    def test_create_with_unknown_provider(self):
        """Test creating embedder with unknown provider raises ValueError."""
        with pytest.raises(ValueError, match="Unknown embedding provider"):
            create_embedder("unknown_provider")

    def test_create_case_insensitive(self):
        """Test provider name is case-insensitive."""
        embedder = create_embedder("Azure")
        assert embedder.config.provider == EmbeddingProvider.AZURE

    def test_local_embedder_fallback(self):
        """Test local embedder falls back to OpenAI."""
        import os

        # Skip if OPENAI_API_KEY not available
        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        embedder = create_embedder("local")
        # Should fall back to OpenAI (as per factory implementation)
        assert embedder is not None


class TestEmbeddingProvider:
    """Test EmbeddingProvider enum."""

    def test_provider_values(self):
        """Test EmbeddingProvider enum values."""
        assert EmbeddingProvider.OPENAI == "openai"
        assert EmbeddingProvider.AZURE == "azure"
        assert EmbeddingProvider.LOCAL == "local"

    def test_provider_from_string(self):
        """Test creating provider from string."""
        assert EmbeddingProvider("openai") == EmbeddingProvider.OPENAI
        assert EmbeddingProvider("azure") == EmbeddingProvider.AZURE
        assert EmbeddingProvider("local") == EmbeddingProvider.LOCAL

    def test_invalid_provider(self):
        """Test invalid provider raises ValueError."""
        with pytest.raises(ValueError):
            EmbeddingProvider("invalid_provider")


@pytest.mark.asyncio
class TestOpenAIEmbedder:
    """Test OpenAI embedder implementation."""

    async def test_generate_embedding(self):
        """Test generating single embedding."""
        import os

        # Skip if OPENAI_API_KEY not available
        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            model="text-embedding-3-small",
        )

        # Mock the OpenAI client
        with patch("openai.OpenAI") as mock_openai:
            mock_client = mock_openai.return_value
            mock_response = type("Response", (), {})()
            mock_response.data = [type("Embedding", (), {"embedding": [0.1, 0.2, 0.3]})()]

            mock_client.embeddings.create.return_value = mock_response

            embedder = OpenAIEmbedder(config)
            embedding = await embedder.generate_embedding("Test text")

            assert embedding == [0.1, 0.2, 0.3]
            mock_client.embeddings.create.assert_called_once()

    async def test_generate_embeddings_batch(self):
        """Test batch embedding generation."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(provider=EmbeddingProvider.OPENAI)

        with patch("openai.OpenAI") as mock_openai:
            mock_client = mock_openai.return_value
            mock_response = type("Response", (), {})()
            mock_response.data = [
                type("Embedding", (), {"embedding": [0.1, 0.2, 0.3]})(),
                type("Embedding", (), {"embedding": [0.4, 0.5, 0.6]})(),
            ]

            mock_client.embeddings.create.return_value = mock_response

            embedder = OpenAIEmbedder(config)
            embeddings = await embedder.generate_embeddings_batch(["Text 1", "Text 2"])

            assert len(embeddings) == 2
            assert embeddings[0] == [0.1, 0.2, 0.3]
            assert embeddings[1] == [0.4, 0.5, 0.6]

    async def test_get_embedding_dimension(self):
        """Test getting embedding dimension."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            model="text-embedding-3-small",
        )

        embedder = OpenAIEmbedder(config)
        dimension = embedder.get_embedding_dimension()

        # text-embedding-3-small has 1536 dimensions
        assert dimension == 1536

    async def test_embed_chunks(self):
        """Test embedding document chunks."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            batch_size=2,
        )

        chunks = [
            DocumentChunk(
                content="First chunk",
                index=0,
                start_char=0,
                end_char=11,
                metadata={},
            ),
            DocumentChunk(
                content="Second chunk",
                index=1,
                start_char=11,
                end_char=23,
                metadata={},
            ),
        ]

        with patch("openai.OpenAI") as mock_openai:
            mock_client = mock_openai.return_value
            mock_response = type("Response", (), {})()
            mock_response.data = [
                type("Embedding", (), {"embedding": [0.1, 0.2]})(),
                type("Embedding", (), {"embedding": [0.3, 0.4]})(),
            ]

            mock_client.embeddings.create.return_value = mock_response

            embedder = OpenAIEmbedder(config)
            embedded_chunks = await embedder.embed_chunks(chunks)

            assert len(embedded_chunks) == 2
            assert embedded_chunks[0].embedding == [0.1, 0.2]
            assert embedded_chunks[1].embedding == [0.3, 0.4]
            # Metadata should be updated
            assert embedded_chunks[0].metadata["embedding_model"] == "text-embedding-3-small"
            assert embedded_chunks[0].metadata["embedding_provider"] == EmbeddingProvider.OPENAI

    async def test_embed_query(self):
        """Test embedding query text."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(provider=EmbeddingProvider.OPENAI)

        with patch("openai.OpenAI") as mock_openai:
            mock_client = mock_openai.return_value
            mock_response = type("Response", (), {})()
            mock_response.data = [type("Embedding", (), {"embedding": [0.5, 0.6, 0.7]})()]

            mock_client.embeddings.create.return_value = mock_response

            embedder = OpenAIEmbedder(config)
            embedding = await embedder.embed_query("What is FDA guidance?")

            assert embedding == [0.5, 0.6, 0.7]

    async def test_health_check(self):
        """Test health check."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(provider=EmbeddingProvider.OPENAI)
        embedder = OpenAIEmbedder(config)

        is_healthy = await embedder.health_check()
        assert is_healthy is True


@pytest.mark.asyncio
class TestAzureEmbedder:
    """Test Azure embedder implementation."""

    async def test_generate_embedding(self):
        """Test generating single embedding with Azure."""
        from ashmatics_tools.embedders.azure_embedder import AzureEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.AZURE,
            model="text-embedding-3-small",
        )

        with patch("openai.AzureOpenAI") as mock_azure:
            mock_client = mock_azure.return_value
            mock_response = type("Response", (), {})()
            mock_response.data = [type("Embedding", (), {"embedding": [0.7, 0.8, 0.9]})()]

            mock_client.embeddings.create.return_value = mock_response

            embedder = AzureEmbedder(config)
            embedding = await embedder.generate_embedding("Azure test")

            assert embedding == [0.7, 0.8, 0.9]

    async def test_generate_embeddings_batch(self):
        """Test batch embedding generation with Azure."""
        from ashmatics_tools.embedders.azure_embedder import AzureEmbedder

        config = EmbeddingConfig(provider=EmbeddingProvider.AZURE)

        with patch("openai.AzureOpenAI") as mock_azure:
            mock_client = mock_azure.return_value
            mock_response = type("Response", (), {})()
            mock_response.data = [
                type("Embedding", (), {"embedding": [0.1, 0.2]})(),
                type("Embedding", (), {"embedding": [0.3, 0.4]})(),
                type("Embedding", (), {"embedding": [0.5, 0.6]})(),
            ]

            mock_client.embeddings.create.return_value = mock_response

            embedder = AzureEmbedder(config)
            embeddings = await embedder.generate_embeddings_batch(["Text 1", "Text 2", "Text 3"])

            assert len(embeddings) == 3
            assert embeddings[0] == [0.1, 0.2]
            assert embeddings[1] == [0.3, 0.4]
            assert embeddings[2] == [0.5, 0.6]

    async def test_get_embedding_dimension(self):
        """Test getting embedding dimension for Azure."""
        from ashmatics_tools.embedders.azure_embedder import AzureEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.AZURE,
            model="text-embedding-3-large",
        )

        embedder = AzureEmbedder(config)
        dimension = embedder.get_embedding_dimension()

        # text-embedding-3-large has 3072 dimensions
        assert dimension == 3072


@pytest.mark.asyncio
class TestEmbedderBatching:
    """Test embedder batching behavior."""

    async def test_embed_chunks_batching(self):
        """Test that chunks are processed in batches."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            batch_size=2,  # Small batch size for testing
        )

        # Create 5 chunks (should be processed in 3 batches: 2, 2, 1)
        chunks = [
            DocumentChunk(
                content=f"Chunk {i}",
                index=i,
                start_char=i * 10,
                end_char=(i + 1) * 10,
                metadata={},
            )
            for i in range(5)
        ]

        with patch("openai.OpenAI") as mock_openai:
            mock_client = mock_openai.return_value

            # Mock responses for different batch sizes
            def create_mock_response(num_embeddings):
                mock_response = type("Response", (), {})()
                mock_response.data = [
                    type("Embedding", (), {"embedding": [float(i), float(i) + 0.1]})()
                    for i in range(num_embeddings)
                ]
                return mock_response

            # First two calls get 2 embeddings, last call gets 1
            mock_client.embeddings.create.side_effect = [
                create_mock_response(2),
                create_mock_response(2),
                create_mock_response(1),
            ]

            embedder = OpenAIEmbedder(config)
            embedded_chunks = await embedder.embed_chunks(chunks)

            # Should have made 3 API calls (batches of 2, 2, 1)
            assert mock_client.embeddings.create.call_count == 3
            assert len(embedded_chunks) == 5

    async def test_embed_chunks_with_progress_callback(self):
        """Test embedding chunks with progress callback."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            batch_size=2,
        )

        chunks = [
            DocumentChunk(
                content=f"Chunk {i}",
                index=i,
                start_char=0,
                end_char=10,
                metadata={},
            )
            for i in range(4)
        ]

        progress_calls = []

        def progress_callback(current, total):
            progress_calls.append((current, total))

        with patch("openai.OpenAI") as mock_openai:
            mock_client = mock_openai.return_value
            mock_response = type("Response", (), {})()
            mock_response.data = [
                type("Embedding", (), {"embedding": [0.1, 0.2]})(),
                type("Embedding", (), {"embedding": [0.3, 0.4]})(),
            ]

            mock_client.embeddings.create.return_value = mock_response

            embedder = OpenAIEmbedder(config)
            await embedder.embed_chunks(chunks, progress_callback=progress_callback)

            # Should have called progress callback twice (2 batches)
            assert len(progress_calls) == 2
            assert progress_calls[0] == (1, 2)  # First batch
            assert progress_calls[1] == (2, 2)  # Second batch

    async def test_embed_empty_chunks(self):
        """Test embedding empty chunk list."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(provider=EmbeddingProvider.OPENAI)
        embedder = OpenAIEmbedder(config)

        embedded_chunks = await embedder.embed_chunks([])
        assert embedded_chunks == []


class TestEmbedderRepr:
    """Test embedder string representations."""

    def test_embedder_repr(self):
        """Test embedder string representation."""
        import os

        if not os.getenv("OPENAI_API_KEY"):
            pytest.skip("OPENAI_API_KEY not available")

        from ashmatics_tools.embedders.openai_embedder import OpenAIEmbedder

        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            model="text-embedding-3-large",
        )
        embedder = OpenAIEmbedder(config)

        repr_str = repr(embedder)
        assert "OpenAIEmbedder" in repr_str
        assert "text-embedding-3-large" in repr_str
