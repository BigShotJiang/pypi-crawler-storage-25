"""Tests for LLM client module."""

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ashmatics_tools.llm import (
    AzureOpenAIClient,
    AzureOpenAIConfig,
    BaseLLMClient,
    LLMAPIError,
    LLMMessage,
    LLMResponse,
    OpenAIClient,
    OpenAIConfig,
    TokenUsage,
    create_llm_client,
    list_llm_providers,
    register_llm_provider,
    unregister_llm_provider,
)


class TestFactory:
    """Test LLM factory and registry."""

    def test_list_llm_providers(self):
        """Test listing available LLM providers."""
        providers = list_llm_providers()
        assert "azure_openai" in providers
        assert "openai" in providers

    def test_create_azure_openai_client(self):
        """Test creating Azure OpenAI client via factory."""
        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )
        client = create_llm_client("azure_openai", config)
        assert isinstance(client, AzureOpenAIClient)
        assert client.config.endpoint == "https://test.openai.azure.com/"

    def test_create_openai_client(self):
        """Test creating OpenAI client via factory."""
        config = OpenAIConfig(api_key="test-key", model="gpt-4")
        client = create_llm_client("openai", config)
        assert isinstance(client, OpenAIClient)
        assert client.config.model == "gpt-4"

    def test_create_unknown_provider(self):
        """Test creating client with unknown provider raises ValueError."""
        with pytest.raises(ValueError, match="Unknown LLM provider"):
            create_llm_client("unknown_provider", {})

    def test_register_custom_provider(self):
        """Test registering custom LLM provider."""

        class CustomLLM(BaseLLMClient):
            def __init__(self, config):
                self.config = config

            async def complete(self, prompt, **kwargs):
                return LLMResponse(
                    text="test",
                    tokens=TokenUsage(10, 5, 15, 0.0),
                    model="custom",
                    finish_reason="stop",
                )

            async def complete_with_messages(self, messages, **kwargs):
                return await self.complete("", **kwargs)

        # Register provider
        register_llm_provider("custom_test", CustomLLM)

        # Should now be available
        assert "custom_test" in list_llm_providers()

        # Should be able to create client
        client = create_llm_client("custom_test", {"test": "config"})
        assert isinstance(client, CustomLLM)

        # Cleanup
        unregister_llm_provider("custom_test")
        assert "custom_test" not in list_llm_providers()

    def test_register_non_basellm_class(self):
        """Test registering non-BaseLLMClient class raises ValueError."""

        class NotALLM:
            pass

        with pytest.raises(ValueError, match="must inherit from BaseLLMClient"):
            register_llm_provider("invalid", NotALLM)


class TestAzureOpenAIConfig:
    """Test Azure OpenAI configuration."""

    def test_config_from_parameters(self):
        """Test creating config from parameters."""
        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )
        assert config.endpoint == "https://test.openai.azure.com/"
        assert config.api_key == "test-key"
        assert config.deployment_name == "gpt-4"

    def test_config_from_environment(self, monkeypatch):
        """Test creating config from environment variables."""
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://env.openai.azure.com/")
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "env-key")

        config = AzureOpenAIConfig(deployment_name="gpt-4")
        assert config.endpoint == "https://env.openai.azure.com/"
        assert config.api_key == "env-key"

    def test_config_missing_endpoint(self, monkeypatch):
        """Test config raises ValueError when endpoint is missing."""
        # Remove env vars to test validation
        monkeypatch.delenv("AZURE_OPENAI_ENDPOINT", raising=False)
        with pytest.raises(ValueError, match="endpoint must be provided"):
            AzureOpenAIConfig(api_key="test-key")

    def test_config_missing_api_key(self, monkeypatch):
        """Test config raises ValueError when API key is missing."""
        # Remove env vars to test validation
        monkeypatch.delenv("AZURE_OPENAI_API_KEY", raising=False)
        with pytest.raises(ValueError, match="authentication must be provided"):
            AzureOpenAIConfig(endpoint="https://test.openai.azure.com/")


class TestOpenAIConfig:
    """Test OpenAI configuration."""

    def test_config_from_parameters(self):
        """Test creating config from parameters."""
        config = OpenAIConfig(api_key="test-key", model="gpt-4")
        assert config.api_key == "test-key"
        assert config.model == "gpt-4"

    def test_config_from_environment(self, monkeypatch):
        """Test creating config from environment variables."""
        monkeypatch.setenv("OPENAI_API_KEY", "env-key")

        config = OpenAIConfig(model="gpt-4")
        assert config.api_key == "env-key"

    def test_config_missing_api_key(self):
        """Test config raises ValueError when API key is missing."""
        with pytest.raises(ValueError, match="API key must be provided"):
            OpenAIConfig()


class TestLLMMessage:
    """Test LLM message class."""

    def test_message_creation(self):
        """Test creating LLM message."""
        msg = LLMMessage(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.name is None

    def test_message_to_dict(self):
        """Test converting message to dict."""
        msg = LLMMessage(role="user", content="Hello", name="test-user")
        msg_dict = msg.to_dict()
        assert msg_dict == {"role": "user", "content": "Hello", "name": "test-user"}

    def test_message_to_dict_no_name(self):
        """Test converting message to dict without name."""
        msg = LLMMessage(role="user", content="Hello")
        msg_dict = msg.to_dict()
        assert msg_dict == {"role": "user", "content": "Hello"}
        assert "name" not in msg_dict


@pytest.mark.asyncio
class TestAzureOpenAIClient:
    """Test Azure OpenAI client."""

    async def test_client_context_manager(self):
        """Test client can be used as context manager."""
        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )

        async with AzureOpenAIClient(config) as client:
            assert client.client is not None

    async def test_client_requires_context_manager(self):
        """Test client raises error when used without context manager."""
        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )

        client = AzureOpenAIClient(config)
        with pytest.raises(RuntimeError, match="must be used as an async context manager"):
            await client.complete("test")

    @patch("ashmatics_tools.llm.azure_openai.AsyncAzureOpenAI")
    async def test_complete(self, mock_azure_openai):
        """Test completion request."""
        # Setup mock
        mock_client = AsyncMock()
        mock_azure_openai.return_value = mock_client

        mock_response = MagicMock()
        mock_response.id = "test-id"
        mock_response.choices = [
            MagicMock(text="This is a test response", finish_reason="stop")
        ]
        mock_response.usage = MagicMock(
            prompt_tokens=10, completion_tokens=20, total_tokens=30
        )

        mock_client.completions.create = AsyncMock(return_value=mock_response)
        mock_client.close = AsyncMock()

        # Create client and test
        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )

        async with AzureOpenAIClient(config) as client:
            response = await client.complete(
                prompt="What is asthma?", temperature=0.7, max_tokens=500
            )

            assert response.text == "This is a test response"
            assert response.finish_reason == "stop"
            assert response.tokens.prompt_tokens == 10
            assert response.tokens.completion_tokens == 20
            assert response.tokens.total_tokens == 30
            assert response.model == "gpt-4"

    @patch("ashmatics_tools.llm.azure_openai.AsyncAzureOpenAI")
    async def test_complete_with_messages(self, mock_azure_openai):
        """Test chat completion with messages."""
        # Setup mock
        mock_client = AsyncMock()
        mock_azure_openai.return_value = mock_client

        mock_message = MagicMock()
        mock_message.content = "Asthma is a respiratory condition"

        mock_response = MagicMock()
        mock_response.id = "test-id"
        mock_response.choices = [MagicMock(message=mock_message, finish_reason="stop")]
        mock_response.usage = MagicMock(
            prompt_tokens=15, completion_tokens=25, total_tokens=40
        )

        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)
        mock_client.close = AsyncMock()

        # Create client and test
        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )

        async with AzureOpenAIClient(config) as client:
            messages = [
                LLMMessage(role="system", content="You are a helpful assistant"),
                LLMMessage(role="user", content="What is asthma?"),
            ]

            response = await client.complete_with_messages(
                messages=messages, temperature=0.7, max_tokens=500
            )

            assert response.text == "Asthma is a respiratory condition"
            assert response.finish_reason == "stop"
            assert response.tokens.total_tokens == 40

    @patch("tiktoken.encoding_for_model")
    async def test_count_tokens(self, mock_encoding_for_model):
        """Test token counting with tiktoken."""
        # Setup mock
        mock_encoding = MagicMock()
        mock_encoding.encode.return_value = [1, 2, 3, 4, 5]
        mock_encoding_for_model.return_value = mock_encoding

        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )

        client = AzureOpenAIClient(config)
        token_count = await client.count_tokens("This is a test")

        assert token_count == 5
        mock_encoding_for_model.assert_called_once_with("gpt-4")

    async def test_estimate_cost(self):
        """Test cost estimation."""
        config = AzureOpenAIConfig(
            endpoint="https://test.openai.azure.com/",
            api_key="test-key",
            deployment_name="gpt-4",
        )

        client = AzureOpenAIClient(config)

        tokens = TokenUsage(prompt_tokens=1000, completion_tokens=500, total_tokens=1500)

        cost = await client.estimate_cost(tokens)

        # gpt-4: $0.03 per 1K prompt, $0.06 per 1K completion
        expected_cost = (1000 / 1000 * 0.03) + (500 / 1000 * 0.06)
        assert abs(cost - expected_cost) < 0.0001


@pytest.mark.asyncio
class TestOpenAIClient:
    """Test OpenAI client."""

    async def test_client_context_manager(self):
        """Test client can be used as context manager."""
        config = OpenAIConfig(api_key="test-key", model="gpt-4")

        async with OpenAIClient(config) as client:
            assert client.client is not None

    async def test_estimate_cost(self):
        """Test cost estimation."""
        config = OpenAIConfig(api_key="test-key", model="gpt-3.5-turbo")

        client = OpenAIClient(config)

        tokens = TokenUsage(prompt_tokens=1000, completion_tokens=500, total_tokens=1500)

        cost = await client.estimate_cost(tokens)

        # gpt-3.5-turbo: $0.0005 per 1K prompt, $0.0015 per 1K completion
        expected_cost = (1000 / 1000 * 0.0005) + (500 / 1000 * 0.0015)
        assert abs(cost - expected_cost) < 0.00001
