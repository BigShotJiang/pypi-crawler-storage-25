# Copyright 2025 Asher Informatics PBC
"""Tests for external API clients."""

import pytest
import respx
from httpx import Response

from ashmatics_tools.external_apis import (
    OpenFDAClient,
    OpenFDAConfig,
    OpenFDAEndpoint,
    create_api_client,
    list_api_providers,
)


@pytest.fixture
def openfda_config():
    """Create test OpenFDA configuration."""
    return OpenFDAConfig(api_key="test_key", timeout=10.0)


@pytest.fixture
def openfda_client(openfda_config):
    """Create test OpenFDA client."""
    return OpenFDAClient(openfda_config)


def test_openfda_config_defaults():
    """Test OpenFDA configuration defaults."""
    config = OpenFDAConfig()
    assert config.base_url == "https://api.fda.gov"
    assert config.api_key is None
    assert config.verify_ssl is True
    assert config.timeout == 30.0


def test_openfda_config_with_api_key():
    """Test OpenFDA configuration with API key."""
    config = OpenFDAConfig(api_key="test_key")
    assert config.api_key == "test_key"
    # With API key: 3.5 requests/second
    assert config.rate_limit.requests_per_second == 3.5
    assert config.rate_limit.burst_size == 10


def test_openfda_config_without_api_key():
    """Test OpenFDA configuration without API key."""
    config = OpenFDAConfig()
    assert config.api_key is None
    # Without API key: 0.6 requests/second
    assert config.rate_limit.requests_per_second == 0.6
    assert config.rate_limit.burst_size == 3


def test_endpoint_path(openfda_client):
    """Test endpoint path generation."""
    assert openfda_client.get_endpoint_path("device/event") == "/device/event.json"
    assert (
        openfda_client.get_endpoint_path(OpenFDAEndpoint.DEVICE_EVENT)
        == "/device/event.json"
    )
    assert (
        openfda_client.get_endpoint_path(OpenFDAEndpoint.DEVICE_510K)
        == "/device/510k.json"
    )


def test_build_query_params(openfda_client):
    """Test query parameter building."""
    params = openfda_client._build_query_params(
        endpoint="device/event",
        query="device_name:pacemaker",
        limit=100,
        skip=0,
    )

    assert params["search"] == "device_name:pacemaker"
    assert params["limit"] == 100
    assert params["skip"] == 0
    assert params["api_key"] == "test_key"


def test_parse_response(openfda_client):
    """Test response parsing."""
    response = {
        "meta": {"results": {"skip": 0, "limit": 100, "total": 500}},
        "results": [
            {"device": {"device_name": "Test Device 1"}},
            {"device": {"device_name": "Test Device 2"}},
        ],
    }

    results = openfda_client._parse_response(response)
    assert len(results) == 2
    assert results[0]["device"]["device_name"] == "Test Device 1"


def test_extract_pagination(openfda_client):
    """Test pagination info extraction."""
    response = {
        "meta": {"results": {"skip": 0, "limit": 100, "total": 500}},
        "results": [],
    }

    pagination = openfda_client._extract_pagination(response)
    assert pagination.total_results == 500
    assert pagination.current_skip == 0
    assert pagination.current_limit == 100
    assert pagination.has_more is True


@pytest.mark.asyncio
@respx.mock
async def test_search_devices(openfda_client):
    """Test device search."""
    # Mock API response
    mock_response = {
        "meta": {"results": {"skip": 0, "limit": 100, "total": 2}},
        "results": [
            {"device": {"device_name": "Device 1"}},
            {"device": {"device_name": "Device 2"}},
        ],
    }

    respx.get("https://api.fda.gov/device/event.json").mock(
        return_value=Response(200, json=mock_response)
    )

    # Execute search
    results = []
    async with openfda_client:
        async for result in openfda_client.search(
            endpoint=OpenFDAEndpoint.DEVICE_EVENT,
            query="device_name:pacemaker",
            limit=100,
            max_records=10,
        ):
            results.append(result)

    assert len(results) == 2
    assert results[0]["device"]["device_name"] == "Device 1"


@pytest.mark.asyncio
@respx.mock
async def test_search_pagination(openfda_client):
    """Test search with pagination."""
    # Mock first page
    page1_response = {
        "meta": {"results": {"skip": 0, "limit": 2, "total": 5}},
        "results": [{"id": 1}, {"id": 2}],
    }

    # Mock second page
    page2_response = {
        "meta": {"results": {"skip": 2, "limit": 2, "total": 5}},
        "results": [{"id": 3}, {"id": 4}],
    }

    # Mock third page
    page3_response = {
        "meta": {"results": {"skip": 4, "limit": 2, "total": 5}},
        "results": [{"id": 5}],
    }

    respx.get("https://api.fda.gov/device/event.json", params={"skip": 0}).mock(
        return_value=Response(200, json=page1_response)
    )
    respx.get("https://api.fda.gov/device/event.json", params={"skip": 2}).mock(
        return_value=Response(200, json=page2_response)
    )
    respx.get("https://api.fda.gov/device/event.json", params={"skip": 4}).mock(
        return_value=Response(200, json=page3_response)
    )

    # Execute search
    results = []
    async with openfda_client:
        async for result in openfda_client.search(
            endpoint=OpenFDAEndpoint.DEVICE_EVENT,
            query="*",
            limit=2,
            max_records=5,
        ):
            results.append(result)

    assert len(results) == 5
    assert results[0]["id"] == 1
    assert results[4]["id"] == 5


@pytest.mark.asyncio
@respx.mock
async def test_count_query(openfda_client):
    """Test count query."""
    mock_response = {
        "results": [
            {"term": "Class I", "count": 100},
            {"term": "Class II", "count": 200},
            {"term": "Class III", "count": 50},
        ]
    }

    respx.get("https://api.fda.gov/device/event.json").mock(
        return_value=Response(200, json=mock_response)
    )

    # Execute count
    async with openfda_client:
        results = await openfda_client.count(
            endpoint=OpenFDAEndpoint.DEVICE_EVENT,
            query="*",
            count_field="device.device_class.exact",
        )

    assert len(results) == 3
    assert results[0]["term"] == "Class I"
    assert results[0]["count"] == 100


def test_factory_create_api_client():
    """Test API client factory."""
    config = OpenFDAConfig(api_key="test_key")
    client = create_api_client("openfda", config)

    assert isinstance(client, OpenFDAClient)
    assert client.config.api_key == "test_key"


def test_factory_list_providers():
    """Test listing API providers."""
    providers = list_api_providers()
    assert "openfda" in providers


def test_factory_unknown_provider():
    """Test factory with unknown provider."""
    with pytest.raises(ValueError, match="Unknown API provider"):
        create_api_client("unknown_provider", {})
