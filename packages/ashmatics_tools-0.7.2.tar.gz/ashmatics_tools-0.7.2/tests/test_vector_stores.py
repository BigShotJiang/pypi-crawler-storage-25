"""Tests for vector_stores module.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ashmatics_tools.chunkers.base import DocumentChunk
from ashmatics_tools.vector_stores import (
    CosmosDBVectorStore,
    DistanceMetric,
    IndexInfo,
    IndexType,
    PgVectorStore,
    QdrantVectorStore,
    SearchResult,
    VectorStore,
    VectorStoreConfig,
    VectorStoreProvider,
    create_vector_store,
)


class TestVectorStoreConfig:
    """Test VectorStoreConfig validation."""

    def test_config_defaults(self):
        """Test default configuration."""
        config = VectorStoreConfig()

        assert config.provider == VectorStoreProvider.COSMOSDB
        assert config.collection_name == "embedded_documents"
        assert config.dimensions == 1536
        assert config.distance_metric == DistanceMetric.COSINE
        assert config.index_type == IndexType.IVF
        assert config.batch_size == 100
        assert config.max_retries == 3
        assert config.retry_delay == 1.0
        assert config.timeout == 30.0

    def test_config_custom_values(self):
        """Test configuration with custom values."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.PGVECTOR,
            connection_string="postgresql://test",
            database_name="test_db",
            collection_name="test_collection",
            dimensions=768,
            distance_metric=DistanceMetric.EUCLIDEAN,
            index_type=IndexType.HNSW,
            batch_size=50,
        )

        assert config.provider == VectorStoreProvider.PGVECTOR
        assert config.connection_string == "postgresql://test"
        assert config.database_name == "test_db"
        assert config.collection_name == "test_collection"
        assert config.dimensions == 768
        assert config.distance_metric == DistanceMetric.EUCLIDEAN
        assert config.index_type == IndexType.HNSW
        assert config.batch_size == 50

    def test_invalid_dimensions(self):
        """Test invalid dimensions raises ValueError."""
        with pytest.raises(ValueError, match="dimensions must be positive"):
            VectorStoreConfig(dimensions=0)

        with pytest.raises(ValueError, match="dimensions must be positive"):
            VectorStoreConfig(dimensions=-100)

    def test_invalid_batch_size(self):
        """Test invalid batch size raises ValueError."""
        with pytest.raises(ValueError, match="batch_size must be at least 1"):
            VectorStoreConfig(batch_size=0)

    def test_invalid_max_retries(self):
        """Test invalid max retries raises ValueError."""
        with pytest.raises(ValueError, match="max_retries must be non-negative"):
            VectorStoreConfig(max_retries=-1)

    def test_invalid_retry_delay(self):
        """Test invalid retry delay raises ValueError."""
        with pytest.raises(ValueError, match="retry_delay must be non-negative"):
            VectorStoreConfig(retry_delay=-1.0)

    def test_invalid_timeout(self):
        """Test invalid timeout raises ValueError."""
        with pytest.raises(ValueError, match="timeout must be positive"):
            VectorStoreConfig(timeout=0)

        with pytest.raises(ValueError, match="timeout must be positive"):
            VectorStoreConfig(timeout=-5.0)


class TestSearchResult:
    """Test SearchResult dataclass."""

    def test_search_result_creation(self):
        """Test creating search result."""
        result = SearchResult(
            document_id="doc123",
            content="Test content",
            score=0.95,
            rank=1,
            metadata={"source": "test"},
        )

        assert result.document_id == "doc123"
        assert result.content == "Test content"
        assert result.score == 0.95
        assert result.rank == 1
        assert result.metadata == {"source": "test"}
        assert result.distance is None
        assert result.embedding is None

    def test_search_result_to_dict(self):
        """Test converting search result to dict."""
        result = SearchResult(
            document_id="doc123",
            content="Test content",
            score=0.95,
            distance=0.05,
            rank=1,
            metadata={"source": "test"},
        )

        result_dict = result.to_dict()

        assert result_dict["document_id"] == "doc123"
        assert result_dict["content"] == "Test content"
        assert result_dict["score"] == 0.95
        assert result_dict["distance"] == 0.05
        assert result_dict["rank"] == 1
        assert result_dict["metadata"] == {"source": "test"}
        assert result_dict["has_embedding"] is False

    def test_search_result_with_embedding(self):
        """Test search result with embedding."""
        embedding = [0.1, 0.2, 0.3]
        result = SearchResult(
            document_id="doc123",
            content="Test content",
            score=0.95,
            embedding=embedding,
        )

        assert result.embedding == embedding
        assert result.to_dict()["has_embedding"] is True


class TestIndexInfo:
    """Test IndexInfo dataclass."""

    def test_index_info_creation(self):
        """Test creating index info."""
        info = IndexInfo(
            name="test_index",
            collection_name="test_collection",
            index_type=IndexType.HNSW,
            dimensions=1536,
            distance_metric=DistanceMetric.COSINE,
            num_vectors=1000,
            index_size_bytes=1024000,
        )

        assert info.name == "test_index"
        assert info.collection_name == "test_collection"
        assert info.index_type == IndexType.HNSW
        assert info.dimensions == 1536
        assert info.distance_metric == DistanceMetric.COSINE
        assert info.num_vectors == 1000
        assert info.index_size_bytes == 1024000

    def test_index_info_to_dict(self):
        """Test converting index info to dict."""
        info = IndexInfo(
            name="test_index",
            collection_name="test_collection",
            index_type=IndexType.IVF,
            dimensions=768,
            distance_metric=DistanceMetric.EUCLIDEAN,
        )

        info_dict = info.to_dict()

        assert info_dict["name"] == "test_index"
        assert info_dict["collection_name"] == "test_collection"
        assert info_dict["index_type"] == "ivf"
        assert info_dict["dimensions"] == 768
        assert info_dict["distance_metric"] == "euclidean"
        assert info_dict["num_vectors"] is None


class TestVectorStoreFactory:
    """Test vector store factory function."""

    def test_create_cosmosdb_store(self):
        """Test creating CosmosDB vector store."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        store = create_vector_store("cosmosdb", config)

        if CosmosDBVectorStore is not None:
            assert isinstance(store, CosmosDBVectorStore)
            assert store.config.provider == VectorStoreProvider.COSMOSDB

    def test_create_pgvector_store(self):
        """Test creating PgVector store."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.PGVECTOR,
            connection_string="postgresql://test",
            database_name="test_db",
        )

        store = create_vector_store("pgvector", config)

        if PgVectorStore is not None:
            assert isinstance(store, PgVectorStore)
            assert store.config.provider == VectorStoreProvider.PGVECTOR

    def test_create_qdrant_store(self):
        """Test creating Qdrant store."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.QDRANT,
            collection_name="test_collection",
        )

        store = create_vector_store("qdrant", config)

        if QdrantVectorStore is not None:
            assert isinstance(store, QdrantVectorStore)
            assert store.config.provider == VectorStoreProvider.QDRANT

    def test_unknown_provider(self):
        """Test unknown provider raises ValueError."""
        with pytest.raises(ValueError, match="Unknown vector store provider"):
            create_vector_store("unknown_provider")

    def test_case_insensitive_provider(self):
        """Test provider name is case-insensitive."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        store = create_vector_store("COSMOSDB", config)

        if CosmosDBVectorStore is not None:
            assert isinstance(store, CosmosDBVectorStore)


class TestVectorStoreBase:
    """Test base VectorStore class."""

    def test_get_provider(self):
        """Test get_provider method."""
        # Create a mock vector store with proper config
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        # We can't instantiate the abstract base class directly,
        # so we'll test through a concrete implementation
        if CosmosDBVectorStore is not None:
            store = CosmosDBVectorStore(config)
            assert store.get_provider() == VectorStoreProvider.COSMOSDB

    def test_repr(self):
        """Test string representation."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
            collection_name="test_collection",
        )

        if CosmosDBVectorStore is not None:
            store = CosmosDBVectorStore(config)
            repr_str = repr(store)

            assert "CosmosDBVectorStore" in repr_str
            assert "test_collection" in repr_str

    def test_default_config(self):
        """Test vector store with default config from environment."""
        # This test requires COSMOS_VECTOR_CONNECTION_STRING to be set
        import os

        if CosmosDBVectorStore is not None and os.getenv("COSMOS_VECTOR_CONNECTION_STRING"):
            # Provide minimal config, let it use env vars
            config = VectorStoreConfig(
                provider=VectorStoreProvider.COSMOSDB,
                connection_string=os.getenv("COSMOS_VECTOR_CONNECTION_STRING"),
                database_name="test_db",
            )
            store = CosmosDBVectorStore(config)
            assert store.config is not None
            assert store.config.provider == VectorStoreProvider.COSMOSDB


@pytest.mark.asyncio
class TestVectorStoreOperations:
    """Test vector store operations with mocks."""

    async def test_store_embedding_single(self):
        """Test storing a single embedding."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        if CosmosDBVectorStore is not None:
            with patch.object(CosmosDBVectorStore, "store_embedding", new_callable=AsyncMock) as mock_store:
                mock_store.return_value = True

                store = CosmosDBVectorStore(config)
                result = await store.store_embedding(
                    document_id="doc123",
                    embedding=[0.1, 0.2, 0.3],
                    content="Test content",
                    metadata={"source": "test"},
                )

                assert result is True
                mock_store.assert_called_once()

    async def test_store_embeddings_batch(self):
        """Test batch storing embeddings."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        chunks = [
            DocumentChunk(
                content="Content 1",
                index=0,
                start_char=0,
                end_char=9,
                embedding=[0.1, 0.2, 0.3],
                metadata={"source": "test"},
            ),
            DocumentChunk(
                content="Content 2",
                index=1,
                start_char=9,
                end_char=18,
                embedding=[0.4, 0.5, 0.6],
                metadata={"source": "test"},
            ),
        ]

        if CosmosDBVectorStore is not None:
            with patch.object(
                CosmosDBVectorStore, "store_embeddings_batch", new_callable=AsyncMock
            ) as mock_batch:
                mock_batch.return_value = (2, 0)  # 2 successful, 0 failed

                store = CosmosDBVectorStore(config)
                success, failed = await store.store_embeddings_batch(chunks)

                assert success == 2
                assert failed == 0
                mock_batch.assert_called_once()

    async def test_similarity_search(self):
        """Test similarity search."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        mock_results = [
            SearchResult(
                document_id="doc1",
                content="FDA guidance on AI",
                score=0.95,
                rank=1,
            ),
            SearchResult(
                document_id="doc2",
                content="Clinical validation",
                score=0.88,
                rank=2,
            ),
        ]

        if CosmosDBVectorStore is not None:
            with patch.object(
                CosmosDBVectorStore, "similarity_search", new_callable=AsyncMock
            ) as mock_search:
                mock_search.return_value = mock_results

                store = CosmosDBVectorStore(config)
                results = await store.similarity_search(
                    query_embedding=[0.1, 0.2, 0.3],
                    top_k=10,
                    min_score=0.5,
                )

                assert len(results) == 2
                assert results[0].score == 0.95
                assert results[1].score == 0.88
                mock_search.assert_called_once()

    async def test_similarity_search_with_filters(self):
        """Test similarity search with metadata filters."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        filters = {"metadata.category": "regulatory_guidance"}

        if CosmosDBVectorStore is not None:
            with patch.object(
                CosmosDBVectorStore, "similarity_search", new_callable=AsyncMock
            ) as mock_search:
                mock_search.return_value = []

                store = CosmosDBVectorStore(config)
                await store.similarity_search(
                    query_embedding=[0.1, 0.2, 0.3],
                    top_k=5,
                    filters=filters,
                )

                # Verify filters were passed
                call_args = mock_search.call_args
                assert call_args[1]["filters"] == filters

    async def test_create_index(self):
        """Test creating vector index."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        if CosmosDBVectorStore is not None:
            with patch.object(CosmosDBVectorStore, "create_index", new_callable=AsyncMock) as mock_create:
                mock_create.return_value = True

                store = CosmosDBVectorStore(config)
                result = await store.create_index()

                assert result is True
                mock_create.assert_called_once()

    async def test_get_index_info(self):
        """Test getting index information."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        mock_info = IndexInfo(
            name="vector_index",
            collection_name="embedded_documents",
            index_type=IndexType.IVF,
            dimensions=1536,
            distance_metric=DistanceMetric.COSINE,
            num_vectors=1000,
        )

        if CosmosDBVectorStore is not None:
            with patch.object(
                CosmosDBVectorStore, "get_index_info", new_callable=AsyncMock
            ) as mock_info_call:
                mock_info_call.return_value = mock_info

                store = CosmosDBVectorStore(config)
                info = await store.get_index_info()

                assert info is not None
                assert info.name == "vector_index"
                assert info.dimensions == 1536
                assert info.num_vectors == 1000

    async def test_health_check(self):
        """Test health check."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        if CosmosDBVectorStore is not None:
            with patch.object(CosmosDBVectorStore, "health_check", new_callable=AsyncMock) as mock_health:
                mock_health.return_value = True

                store = CosmosDBVectorStore(config)
                is_healthy = await store.health_check()

                assert is_healthy is True
                mock_health.assert_called_once()

    async def test_delete_index(self):
        """Test deleting index."""
        config = VectorStoreConfig(
            provider=VectorStoreProvider.COSMOSDB,
            connection_string="mongodb://test",
            database_name="test_db",
        )

        if CosmosDBVectorStore is not None:
            with patch.object(CosmosDBVectorStore, "delete_index", new_callable=AsyncMock) as mock_delete:
                mock_delete.return_value = True

                store = CosmosDBVectorStore(config)
                result = await store.delete_index("test_index")

                assert result is True
                mock_delete.assert_called_once_with("test_index")


class TestEnumerations:
    """Test enum definitions."""

    def test_vector_store_provider_values(self):
        """Test VectorStoreProvider enum values."""
        assert VectorStoreProvider.COSMOSDB == "cosmosdb"
        assert VectorStoreProvider.PGVECTOR == "pgvector"
        assert VectorStoreProvider.QDRANT == "qdrant"

    def test_distance_metric_values(self):
        """Test DistanceMetric enum values."""
        assert DistanceMetric.COSINE == "cosine"
        assert DistanceMetric.EUCLIDEAN == "euclidean"
        assert DistanceMetric.DOT_PRODUCT == "dot_product"
        assert DistanceMetric.MANHATTAN == "manhattan"

    def test_index_type_values(self):
        """Test IndexType enum values."""
        assert IndexType.FLAT == "flat"
        assert IndexType.IVF == "ivf"
        assert IndexType.HNSW == "hnsw"
        assert IndexType.NONE == "none"
