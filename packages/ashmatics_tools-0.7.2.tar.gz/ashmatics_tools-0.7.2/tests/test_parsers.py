"""Tests for parsers module.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

import tempfile
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ashmatics_tools.parsers import (
    DocumentParser,
    ParsedDocument,
    ParseError,
    ParserCapabilities,
    ParserConfig,
    ParserType,
    create_parser,
    get_available_parsers,
)


class TestParserConfig:
    """Test ParserConfig validation."""

    def test_config_defaults(self):
        """Test default configuration."""
        config = ParserConfig()

        assert config.parser_type == ParserType.DOCLING
        assert config.extract_tables is True
        assert config.extract_figures is True
        assert config.extract_sections is True
        assert config.enable_ocr is False
        assert config.ocr_language == "eng"
        assert config.max_concurrent == 4
        assert config.timeout_seconds == 300
        assert config.markdown_format == "github"
        assert config.preserve_formatting is True

    def test_config_custom_values(self):
        """Test configuration with custom values."""
        config = ParserConfig(
            parser_type=ParserType.LLAMA,
            extract_tables=False,
            extract_figures=False,
            enable_ocr=True,
            ocr_language="fra",
            max_concurrent=8,
            timeout_seconds=600,
            markdown_format="commonmark",
        )

        assert config.parser_type == ParserType.LLAMA
        assert config.extract_tables is False
        assert config.extract_figures is False
        assert config.enable_ocr is True
        assert config.ocr_language == "fra"
        assert config.max_concurrent == 8
        assert config.timeout_seconds == 600
        assert config.markdown_format == "commonmark"

    def test_invalid_max_concurrent(self):
        """Test max_concurrent must be at least 1."""
        with pytest.raises(ValueError, match="max_concurrent must be at least 1"):
            ParserConfig(max_concurrent=0)

        with pytest.raises(ValueError, match="max_concurrent must be at least 1"):
            ParserConfig(max_concurrent=-1)

    def test_invalid_timeout(self):
        """Test timeout_seconds must be positive."""
        with pytest.raises(ValueError, match="timeout_seconds must be positive"):
            ParserConfig(timeout_seconds=0)

        with pytest.raises(ValueError, match="timeout_seconds must be positive"):
            ParserConfig(timeout_seconds=-10)


class TestParsedDocument:
    """Test ParsedDocument dataclass."""

    def test_parsed_document_creation(self):
        """Test creating parsed document."""
        doc = ParsedDocument(
            markdown="# Title\n\nContent here.",
            text="Title\n\nContent here.",
            title="Test Document",
            num_pages=5,
            parser_type="docling",
        )

        assert doc.markdown == "# Title\n\nContent here."
        assert doc.text == "Title\n\nContent here."
        assert doc.title == "Test Document"
        assert doc.num_pages == 5
        assert doc.parser_type == "docling"
        assert isinstance(doc.parsed_at, datetime)

    def test_parsed_document_auto_text_generation(self):
        """Test automatic text generation from markdown."""
        doc = ParsedDocument(
            markdown="# Title\n\n**Bold text** and *italic text*.",
            text="",  # Empty text should be generated
        )

        # Text should be generated from markdown
        assert doc.text
        assert "Title" in doc.text
        assert "Bold text" in doc.text
        # Markdown formatting should be removed
        assert "**" not in doc.text
        assert "*" not in doc.text

    def test_parsed_document_with_sections(self):
        """Test parsed document with sections."""
        from ashmatics_tools.parsers.base import ParsedSection

        sections = [
            ParsedSection(
                title="Introduction",
                content="Intro content",
                level=1,
                index=0,
            ),
            ParsedSection(
                title="Methods",
                content="Methods content",
                level=1,
                index=1,
            ),
        ]

        doc = ParsedDocument(
            markdown="# Introduction\n\n# Methods",
            text="Introduction\n\nMethods",
            sections=sections,
        )

        assert len(doc.sections) == 2
        assert doc.sections[0].title == "Introduction"
        assert doc.sections[1].title == "Methods"

    def test_parsed_document_with_tables(self):
        """Test parsed document with tables."""
        from ashmatics_tools.parsers.base import TableData

        tables = [
            TableData(
                index=0,
                caption="Test Table",
                markdown="| A | B |\n|---|---|\n| 1 | 2 |",
            )
        ]

        doc = ParsedDocument(
            markdown="# Doc\n\nTable content",
            text="Doc\n\nTable content",
            tables=tables,
        )

        assert len(doc.tables) == 1
        assert doc.tables[0].caption == "Test Table"

    def test_parsed_document_with_figures(self):
        """Test parsed document with figures."""
        from ashmatics_tools.parsers.base import FigureData

        figures = [
            FigureData(
                index=0,
                caption="Test Figure",
                alt_text="A test image",
            )
        ]

        doc = ParsedDocument(
            markdown="# Doc\n\nFigure content",
            text="Doc\n\nFigure content",
            figures=figures,
        )

        assert len(doc.figures) == 1
        assert doc.figures[0].caption == "Test Figure"


class TestParserCapabilities:
    """Test ParserCapabilities dataclass."""

    def test_capabilities_defaults(self):
        """Test default capabilities."""
        caps = ParserCapabilities()

        assert caps.supports_tables is False
        assert caps.supports_figures is False
        assert caps.supports_ocr is False
        assert caps.supports_multi_column is False
        assert caps.supports_batch is False
        assert caps.supports_async is True
        assert caps.max_file_size_mb is None
        assert caps.supported_formats == [".pdf"]

    def test_capabilities_custom(self):
        """Test custom capabilities."""
        caps = ParserCapabilities(
            supports_tables=True,
            supports_figures=True,
            supports_ocr=True,
            max_file_size_mb=100,
            supported_formats=[".pdf", ".docx"],
        )

        assert caps.supports_tables is True
        assert caps.supports_figures is True
        assert caps.supports_ocr is True
        assert caps.max_file_size_mb == 100
        assert caps.supported_formats == [".pdf", ".docx"]


class TestParseError:
    """Test ParseError exception."""

    def test_parse_error_creation(self):
        """Test creating parse error."""
        error = ParseError("Failed to parse document")
        assert str(error) == "Failed to parse document"
        assert error.original_error is None

    def test_parse_error_with_original(self):
        """Test parse error with original exception."""
        original = ValueError("Original error")
        error = ParseError("Parse failed", original_error=original)

        assert str(error) == "Parse failed"
        assert error.original_error == original


class TestParserType:
    """Test ParserType enum."""

    def test_parser_type_values(self):
        """Test ParserType enum values."""
        assert ParserType.DOCLING == "docling"
        assert ParserType.LLAMA == "llama"
        assert ParserType.SIMPLE == "simple"

    def test_parser_type_from_string(self):
        """Test creating parser type from string."""
        assert ParserType("docling") == ParserType.DOCLING
        assert ParserType("llama") == ParserType.LLAMA
        assert ParserType("simple") == ParserType.SIMPLE

    def test_invalid_parser_type(self):
        """Test invalid parser type raises ValueError."""
        with pytest.raises(ValueError):
            ParserType("invalid_parser")


class TestParserFactory:
    """Test parser factory functions."""

    def test_create_default_parser(self):
        """Test creating parser with default settings."""
        parser = create_parser()
        assert parser is not None
        assert parser.config.parser_type == ParserType.DOCLING

    def test_create_docling_parser(self):
        """Test creating Docling parser."""
        parser = create_parser("docling")
        assert parser is not None
        capabilities = parser.get_capabilities()
        assert capabilities.supports_tables
        assert capabilities.supports_figures

    def test_create_simple_parser(self):
        """Test creating Simple parser."""
        parser = create_parser("simple")
        assert parser is not None

    def test_create_llama_parser(self):
        """Test creating Llama parser."""
        import os

        # Skip if LLAMA_CLOUD_API_KEY not available
        if not os.getenv("LLAMA_CLOUD_API_KEY"):
            pytest.skip("LLAMA_CLOUD_API_KEY not available")

        # This may require API key, so just test creation
        try:
            parser = create_parser("llama")
            assert parser is not None
        except ImportError:
            # Skip if llama_parse not installed
            pytest.skip("llama_parse not installed")

    def test_create_with_custom_config(self):
        """Test creating parser with custom config."""
        config = ParserConfig(
            parser_type=ParserType.SIMPLE,
            extract_tables=False,
            timeout_seconds=600,
        )
        parser = create_parser("simple", config)

        assert parser.config.extract_tables is False
        assert parser.config.timeout_seconds == 600

    def test_create_unknown_parser(self):
        """Test creating unknown parser raises ValueError."""
        with pytest.raises(ValueError, match="Unknown parser type"):
            create_parser("unknown_parser")

    def test_create_case_insensitive(self):
        """Test parser type is case-insensitive."""
        parser = create_parser("DOCLING")
        assert parser is not None

        parser = create_parser("Simple")
        assert parser is not None

    def test_get_available_parsers(self):
        """Test getting available parsers."""
        parsers = get_available_parsers()
        assert isinstance(parsers, dict)
        # After creating parsers above, registry should have entries
        # Note: This depends on lazy loading


@pytest.mark.asyncio
class TestDoclingParser:
    """Test DoclingParser implementation."""

    async def test_parse_file_basic(self):
        """Test basic file parsing with Docling."""
        from ashmatics_tools.parsers.docling_parser import DoclingParser

        config = ParserConfig(parser_type=ParserType.DOCLING)
        parser = DoclingParser(config)

        # Create a temporary test file
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
            # Note: We would need a real PDF for actual parsing
            # For now, we'll mock the parsing

        try:
            # Mock the actual parsing
            with patch.object(DoclingParser, "parse_file", new_callable=AsyncMock) as mock_parse:
                mock_doc = ParsedDocument(
                    markdown="# Test Document\n\nContent here.",
                    text="Test Document\n\nContent here.",
                    title="Test",
                    parser_type="docling",
                )
                mock_parse.return_value = mock_doc

                result = await parser.parse_file(tmp_path)

                assert result.markdown == "# Test Document\n\nContent here."
                assert result.title == "Test"
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def test_get_capabilities(self):
        """Test getting Docling parser capabilities."""
        from ashmatics_tools.parsers.docling_parser import DoclingParser

        parser = DoclingParser()
        capabilities = parser.get_capabilities()

        assert capabilities.supports_tables is True
        assert capabilities.supports_figures is True
        assert capabilities.supports_async is True


@pytest.mark.asyncio
class TestSimpleParser:
    """Test SimpleParser implementation."""

    async def test_parse_file_basic(self):
        """Test basic file parsing with Simple parser."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        config = ParserConfig(parser_type=ParserType.SIMPLE)
        parser = SimpleParser(config)

        # Create a temporary text file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tmp:
            tmp.write("This is a test document.\n\nWith multiple paragraphs.")
            tmp_path = tmp.name

        try:
            result = await parser.parse_file(tmp_path)

            assert result is not None
            assert "test document" in result.text
            assert result.parser_type == "simple"
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def test_parse_bytes(self):
        """Test parsing from bytes."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        parser = SimpleParser()
        content = b"Test document content"

        result = await parser.parse_bytes(content, filename="test.txt")

        assert result is not None
        assert "Test document" in result.text

    async def test_get_capabilities(self):
        """Test getting Simple parser capabilities."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        parser = SimpleParser()
        capabilities = parser.get_capabilities()

        assert capabilities.supports_async is True
        # Simple parser doesn't support advanced features
        assert capabilities.supports_tables is False
        assert capabilities.supports_figures is False


@pytest.mark.asyncio
class TestDocumentParserBase:
    """Test DocumentParser base class methods."""

    async def test_validate_file_exists(self):
        """Test file validation with existing file."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        parser = SimpleParser()

        # Create a temporary file
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            is_valid = parser.validate_file(tmp_path)
            # Simple parser supports .txt files
            assert is_valid is True or is_valid is False  # Depends on supported formats
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def test_validate_file_not_found(self):
        """Test file validation with non-existent file."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        parser = SimpleParser()

        with pytest.raises(FileNotFoundError):
            parser.validate_file("/nonexistent/file.pdf")

    async def test_validate_file_wrong_format(self):
        """Test file validation with unsupported format."""
        from ashmatics_tools.parsers.docling_parser import DoclingParser

        parser = DoclingParser()

        # Create a temporary file with unsupported extension
        with tempfile.NamedTemporaryFile(suffix=".xyz", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            is_valid = parser.validate_file(tmp_path)
            # Should be invalid for .xyz files
            assert is_valid is False
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def test_parse_batch(self):
        """Test batch parsing."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        parser = SimpleParser()

        # Create temporary files
        files = []
        for i in range(3):
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tmp:
                tmp.write(f"Document {i} content")
                files.append(tmp.name)

        try:
            results = await parser.parse_batch(files)

            assert len(results) == 3
            for i, result in enumerate(results):
                assert f"Document {i}" in result.text
        finally:
            for file_path in files:
                Path(file_path).unlink(missing_ok=True)

    async def test_health_check(self):
        """Test parser health check."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        parser = SimpleParser()
        is_healthy = await parser.health_check()

        assert is_healthy is True

    def test_parser_repr(self):
        """Test parser string representation."""
        from ashmatics_tools.parsers.simple_parser import SimpleParser

        config = ParserConfig(parser_type=ParserType.SIMPLE)
        parser = SimpleParser(config)

        repr_str = repr(parser)
        assert "SimpleParser" in repr_str


class TestParserDataClasses:
    """Test parser-related dataclasses."""

    def test_table_data_creation(self):
        """Test creating TableData."""
        from ashmatics_tools.parsers.base import TableData

        table = TableData(
            index=0,
            caption="Test Table",
            markdown="| A | B |\n|---|---|\n| 1 | 2 |",
            rows=[["A", "B"], ["1", "2"]],
        )

        assert table.index == 0
        assert table.caption == "Test Table"
        assert table.markdown
        assert len(table.rows) == 2

    def test_figure_data_creation(self):
        """Test creating FigureData."""
        from ashmatics_tools.parsers.base import FigureData

        figure = FigureData(
            index=0,
            caption="Test Figure",
            alt_text="A test image",
            image_path="/path/to/image.png",
        )

        assert figure.index == 0
        assert figure.caption == "Test Figure"
        assert figure.alt_text == "A test image"
        assert figure.image_path == "/path/to/image.png"

    def test_parsed_section_creation(self):
        """Test creating ParsedSection."""
        from ashmatics_tools.parsers.base import ParsedSection

        section = ParsedSection(
            title="Introduction",
            content="This is the introduction.",
            level=1,
            index=0,
            start_page=1,
            end_page=2,
        )

        assert section.title == "Introduction"
        assert section.content == "This is the introduction."
        assert section.level == 1
        assert section.index == 0
        assert section.start_page == 1
        assert section.end_page == 2
