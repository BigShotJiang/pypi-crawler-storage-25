"""Tests for chunkers module.

Copyright (c) 2025 Asher Informatics PBC. All Rights Reserved.
See LICENSE file for full license details.
"""

from unittest.mock import AsyncMock, patch

import pytest

from ashmatics_tools.chunkers import (
    ChunkingConfig,
    ChunkingStrategy,
    DocumentChunk,
    create_chunker,
)


class TestChunkingConfig:
    """Test ChunkingConfig validation."""

    def test_config_defaults(self):
        """Test default configuration."""
        config = ChunkingConfig()

        assert config.strategy == ChunkingStrategy.DOCLING
        assert config.chunk_size == 1000
        assert config.chunk_overlap == 200
        assert config.max_chunk_size == 2000
        assert config.min_chunk_size == 100
        assert config.max_tokens == 512
        assert config.use_semantic_splitting is True
        assert config.preserve_structure is True
        assert config.merge_small_chunks is True

    def test_config_custom_values(self):
        """Test configuration with custom values."""
        config = ChunkingConfig(
            strategy=ChunkingStrategy.SIMPLE,
            chunk_size=500,
            chunk_overlap=100,
            max_chunk_size=1000,
            min_chunk_size=50,
            max_tokens=256,
            use_semantic_splitting=False,
        )

        assert config.strategy == ChunkingStrategy.SIMPLE
        assert config.chunk_size == 500
        assert config.chunk_overlap == 100
        assert config.max_chunk_size == 1000
        assert config.min_chunk_size == 50
        assert config.max_tokens == 256
        assert config.use_semantic_splitting is False

    def test_invalid_chunk_overlap(self):
        """Test chunk overlap must be less than chunk size."""
        with pytest.raises(ValueError, match="Chunk overlap must be less than chunk size"):
            ChunkingConfig(chunk_size=500, chunk_overlap=500)

        with pytest.raises(ValueError, match="Chunk overlap must be less than chunk size"):
            ChunkingConfig(chunk_size=500, chunk_overlap=600)

    def test_invalid_min_chunk_size(self):
        """Test minimum chunk size must be positive."""
        with pytest.raises(ValueError, match="Minimum chunk size must be positive"):
            ChunkingConfig(min_chunk_size=0)

        with pytest.raises(ValueError, match="Minimum chunk size must be positive"):
            ChunkingConfig(min_chunk_size=-10)

    def test_invalid_max_tokens(self):
        """Test max_tokens must be positive."""
        with pytest.raises(ValueError, match="max_tokens must be positive"):
            ChunkingConfig(max_tokens=0)

        with pytest.raises(ValueError, match="max_tokens must be positive"):
            ChunkingConfig(max_tokens=-100)


class TestDocumentChunk:
    """Test DocumentChunk dataclass."""

    def test_chunk_creation(self):
        """Test creating document chunk."""
        chunk = DocumentChunk(
            content="This is a test chunk.",
            index=0,
            start_char=0,
            end_char=21,
            metadata={"source": "test.pdf"},
            token_count=5,
        )

        assert chunk.content == "This is a test chunk."
        assert chunk.index == 0
        assert chunk.start_char == 0
        assert chunk.end_char == 21
        assert chunk.metadata == {"source": "test.pdf"}
        assert chunk.token_count == 5
        assert chunk.embedding is None

    def test_chunk_with_embedding(self):
        """Test chunk with embedding."""
        embedding = [0.1, 0.2, 0.3]
        chunk = DocumentChunk(
            content="Test content",
            index=0,
            start_char=0,
            end_char=12,
            metadata={},
            embedding=embedding,
        )

        assert chunk.embedding == embedding

    def test_chunk_token_count_estimation(self):
        """Test automatic token count estimation."""
        # Token count should be estimated as len(content) // 4
        content = "A" * 100  # 100 characters
        chunk = DocumentChunk(
            content=content,
            index=0,
            start_char=0,
            end_char=100,
            metadata={},
        )

        # Should estimate ~25 tokens
        assert chunk.token_count == 25

    def test_chunk_to_dict(self):
        """Test converting chunk to dictionary."""
        chunk = DocumentChunk(
            content="Test content",
            index=1,
            start_char=10,
            end_char=22,
            metadata={"source": "test.pdf", "page": 1},
            token_count=3,
        )

        chunk_dict = chunk.to_dict()

        assert chunk_dict["content"] == "Test content"
        assert chunk_dict["index"] == 1
        assert chunk_dict["start_char"] == 10
        assert chunk_dict["end_char"] == 22
        assert chunk_dict["metadata"] == {"source": "test.pdf", "page": 1}
        assert chunk_dict["token_count"] == 3
        assert chunk_dict["has_embedding"] is False

    def test_chunk_to_dict_with_embedding(self):
        """Test chunk to_dict with embedding."""
        chunk = DocumentChunk(
            content="Test",
            index=0,
            start_char=0,
            end_char=4,
            metadata={},
            embedding=[0.1, 0.2],
        )

        chunk_dict = chunk.to_dict()
        assert chunk_dict["has_embedding"] is True


class TestChunkerFactory:
    """Test chunker factory function."""

    def test_create_default_chunker(self):
        """Test creating chunker with default config."""
        chunker = create_chunker()
        assert chunker is not None
        assert chunker.config.strategy == ChunkingStrategy.DOCLING

    def test_create_docling_chunker(self):
        """Test creating Docling chunker."""
        config = ChunkingConfig(strategy=ChunkingStrategy.DOCLING)
        chunker = create_chunker(config)

        assert chunker is not None
        assert chunker.get_strategy() == ChunkingStrategy.DOCLING

    def test_create_simple_chunker(self):
        """Test creating Simple chunker."""
        config = ChunkingConfig(strategy=ChunkingStrategy.SIMPLE)
        chunker = create_chunker(config)

        assert chunker is not None
        assert chunker.get_strategy() == ChunkingStrategy.SIMPLE

    def test_create_azure_chunker(self):
        """Test creating Azure chunker."""
        config = ChunkingConfig(strategy=ChunkingStrategy.AZURE)
        chunker = create_chunker(config)

        assert chunker is not None
        assert chunker.get_strategy() == ChunkingStrategy.AZURE

    def test_create_with_strategy_override(self):
        """Test creating chunker with strategy override."""
        # Start with DOCLING config
        config = ChunkingConfig(strategy=ChunkingStrategy.DOCLING)

        # Override with simple strategy
        chunker = create_chunker(config, strategy="simple")

        assert chunker.get_strategy() == ChunkingStrategy.SIMPLE

    def test_create_with_unknown_strategy(self):
        """Test creating chunker with unknown strategy raises ValueError."""
        with pytest.raises(ValueError, match="Unknown chunking strategy"):
            create_chunker(strategy="unknown_strategy")

    def test_create_chunker_case_insensitive(self):
        """Test strategy name is case-insensitive."""
        chunker = create_chunker(strategy="SIMPLE")
        assert chunker.get_strategy() == ChunkingStrategy.SIMPLE

        chunker = create_chunker(strategy="Docling")
        assert chunker.get_strategy() == ChunkingStrategy.DOCLING

    def test_fixed_chunker_fallback(self):
        """Test fixed chunker falls back to simple chunker."""
        config = ChunkingConfig(strategy=ChunkingStrategy.FIXED)
        chunker = create_chunker(config)

        # Should fall back to SimpleChunker (as per factory implementation)
        assert chunker is not None
        # The strategy should still be FIXED in config, but implementation is Simple
        assert chunker.config.strategy == ChunkingStrategy.FIXED


@pytest.mark.asyncio
class TestDoclingChunker:
    """Test DoclingChunker implementation."""

    async def test_chunk_document_basic(self):
        """Test basic document chunking."""
        from ashmatics_tools.chunkers.docling_chunker import DoclingChunker

        config = ChunkingConfig(
            strategy=ChunkingStrategy.DOCLING,
            max_tokens=100,
        )
        chunker = DoclingChunker(config)

        # Sample content
        content = """
# FDA Guidance on AI/ML

The FDA has issued guidance on artificial intelligence and machine learning in medical devices.

## Key Recommendations

Manufacturers should demonstrate safety and effectiveness through:
- Data quality assessment
- Algorithm transparency
- Clinical validation
- Post-market monitoring
        """.strip()

        chunks = await chunker.chunk_document(
            content=content,
            title="FDA AI/ML Guidance",
            source="fda_guidance.pdf",
            metadata={"category": "regulatory"},
        )

        # Verify we got chunks
        assert len(chunks) > 0

        # Verify chunk structure
        for i, chunk in enumerate(chunks):
            assert isinstance(chunk, DocumentChunk)
            assert chunk.index == i
            assert chunk.content
            assert chunk.metadata.get("category") == "regulatory"
            assert chunk.metadata.get("title") == "FDA AI/ML Guidance"
            assert chunk.metadata.get("source") == "fda_guidance.pdf"

    async def test_chunk_document_with_custom_metadata(self):
        """Test chunking with custom metadata."""
        from ashmatics_tools.chunkers.docling_chunker import DoclingChunker

        config = ChunkingConfig(strategy=ChunkingStrategy.DOCLING)
        chunker = DoclingChunker(config)

        content = "Short test document."
        metadata = {"author": "Test Author", "date": "2025-01-01"}

        chunks = await chunker.chunk_document(
            content=content,
            title="Test",
            source="test.txt",
            metadata=metadata,
        )

        assert len(chunks) > 0
        # Metadata should be propagated to chunks
        for chunk in chunks:
            assert chunk.metadata.get("author") == "Test Author"
            assert chunk.metadata.get("date") == "2025-01-01"


@pytest.mark.asyncio
class TestSimpleChunker:
    """Test SimpleChunker implementation."""

    async def test_chunk_document_basic(self):
        """Test basic document chunking with simple chunker."""
        from ashmatics_tools.chunkers.simple_chunker import SimpleChunker

        config = ChunkingConfig(
            strategy=ChunkingStrategy.SIMPLE,
            chunk_size=200,
            chunk_overlap=50,
        )
        chunker = SimpleChunker(config)

        content = """
This is paragraph one. It contains some text about FDA regulations.

This is paragraph two. It discusses clinical validation of AI models.

This is paragraph three. It covers post-market monitoring requirements.
        """.strip()

        chunks = await chunker.chunk_document(
            content=content,
            title="Test Document",
            source="test.txt",
        )

        # Verify we got chunks
        assert len(chunks) > 0

        # Verify chunk structure
        for i, chunk in enumerate(chunks):
            assert isinstance(chunk, DocumentChunk)
            assert chunk.index == i
            assert chunk.content
            assert chunk.start_char >= 0
            assert chunk.end_char > chunk.start_char

    async def test_chunk_document_empty_content(self):
        """Test chunking empty content."""
        from ashmatics_tools.chunkers.simple_chunker import SimpleChunker

        config = ChunkingConfig(strategy=ChunkingStrategy.SIMPLE)
        chunker = SimpleChunker(config)

        chunks = await chunker.chunk_document(
            content="",
            title="Empty",
            source="empty.txt",
        )

        # Should return empty list or single empty chunk depending on implementation
        assert isinstance(chunks, list)

    async def test_chunk_preserves_metadata(self):
        """Test that metadata is preserved in chunks."""
        from ashmatics_tools.chunkers.simple_chunker import SimpleChunker

        config = ChunkingConfig(strategy=ChunkingStrategy.SIMPLE)
        chunker = SimpleChunker(config)

        metadata = {"category": "test", "priority": "high"}

        chunks = await chunker.chunk_document(
            content="Test content for metadata preservation.",
            title="Metadata Test",
            source="meta.txt",
            metadata=metadata,
        )

        assert len(chunks) > 0
        for chunk in chunks:
            assert chunk.metadata.get("category") == "test"
            assert chunk.metadata.get("priority") == "high"


@pytest.mark.asyncio
class TestAzureChunker:
    """Test AzureChunker implementation."""

    async def test_chunk_document_basic(self):
        """Test basic document chunking with Azure chunker."""
        from ashmatics_tools.chunkers.azure_chunker import AzureChunker

        config = ChunkingConfig(
            strategy=ChunkingStrategy.AZURE,
            max_tokens=100,
        )
        chunker = AzureChunker(config)

        content = """
# Azure AI Medical Devices

Azure provides comprehensive tools for developing AI-powered medical devices.

## Key Features
- Integration with Azure OpenAI
- Compliance with healthcare regulations
- Scalable infrastructure
        """.strip()

        chunks = await chunker.chunk_document(
            content=content,
            title="Azure AI Guide",
            source="azure_guide.md",
        )

        # Verify we got chunks
        assert len(chunks) > 0

        # Verify chunks have proper structure
        for i, chunk in enumerate(chunks):
            assert isinstance(chunk, DocumentChunk)
            assert chunk.index == i
            assert chunk.content
            assert chunk.token_count is not None

    async def test_azure_chunker_token_awareness(self):
        """Test Azure chunker respects token limits."""
        from ashmatics_tools.chunkers.azure_chunker import AzureChunker

        config = ChunkingConfig(
            strategy=ChunkingStrategy.AZURE,
            max_tokens=50,  # Small token limit
        )
        chunker = AzureChunker(config)

        # Long content that should be split
        content = " ".join(["This is a test sentence."] * 50)

        chunks = await chunker.chunk_document(
            content=content,
            title="Long Document",
            source="long.txt",
        )

        # Should produce multiple chunks due to token limit
        assert len(chunks) > 1

        # Each chunk should respect the token limit (approximately)
        for chunk in chunks:
            # Token count might be slightly over due to chunking strategy,
            # but should be generally in the right ballpark
            assert chunk.token_count is not None


class TestChunkingStrategy:
    """Test ChunkingStrategy enum."""

    def test_strategy_values(self):
        """Test ChunkingStrategy enum values."""
        assert ChunkingStrategy.DOCLING == "docling"
        assert ChunkingStrategy.SIMPLE == "simple"
        assert ChunkingStrategy.FIXED == "fixed"
        assert ChunkingStrategy.AZURE == "azure"

    def test_strategy_from_string(self):
        """Test creating strategy from string."""
        assert ChunkingStrategy("docling") == ChunkingStrategy.DOCLING
        assert ChunkingStrategy("simple") == ChunkingStrategy.SIMPLE
        assert ChunkingStrategy("fixed") == ChunkingStrategy.FIXED
        assert ChunkingStrategy("azure") == ChunkingStrategy.AZURE

    def test_invalid_strategy(self):
        """Test invalid strategy raises ValueError."""
        with pytest.raises(ValueError):
            ChunkingStrategy("invalid_strategy")


class TestChunkerRepr:
    """Test chunker string representations."""

    def test_chunker_repr(self):
        """Test chunker string representation."""
        from ashmatics_tools.chunkers.simple_chunker import SimpleChunker

        config = ChunkingConfig(strategy=ChunkingStrategy.SIMPLE)
        chunker = SimpleChunker(config)

        repr_str = repr(chunker)
        assert "SimpleChunker" in repr_str
        # Can be either "simple" or "ChunkingStrategy.SIMPLE" depending on __repr__ implementation
        assert "simple" in repr_str.lower()
