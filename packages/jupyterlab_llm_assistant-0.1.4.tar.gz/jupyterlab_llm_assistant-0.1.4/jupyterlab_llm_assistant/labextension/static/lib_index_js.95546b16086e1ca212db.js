"use strict";
(self["webpackChunkjupyterlab_llm_assistant"] = self["webpackChunkjupyterlab_llm_assistant"] || []).push([["lib_index_js"],{

/***/ "./lib/components/ChatPanel.js"
/*!*************************************!*\
  !*** ./lib/components/ChatPanel.js ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatPanel: () => (/* binding */ ChatPanel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _InputArea__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./InputArea */ "./lib/components/InputArea.js");
/* harmony import */ var _SettingsPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SettingsPanel */ "./lib/components/SettingsPanel.js");
/* harmony import */ var _MemoryPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./MemoryPanel */ "./lib/components/MemoryPanel.js");
/* harmony import */ var _SessionPanel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SessionPanel */ "./lib/components/SessionPanel.js");
/* harmony import */ var _SkillPanel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./SkillPanel */ "./lib/components/SkillPanel.js");
/* harmony import */ var _UnifiedMessageList__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./UnifiedMessageList */ "./lib/components/UnifiedMessageList.js");
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/api */ "./lib/services/api.js");

/**
 * ChatPanel — Unified message stream with mode-based handlers.
 *
 * New design (v0.8.0):
 * - Single unified message list (no mode switching panels)
 * - Chat/Agent are message HANDLERS, not separate panels
 * - Mode selector only controls how the NEXT message is processed
 * - All messages persist in one history (survives mode switches)
 */








// Session storage - using backend .llm-assistant/sessions/ directory
const DEFAULT_SESSION_ID = 'default';
let currentSessionId = DEFAULT_SESSION_ID;
async function loadSessionFromBackend(rootDir) {
    try {
        const sessions = await _api.listSessions(rootDir);
        if (sessions.length > 0) {
            const latest = sessions[0];
            const session = await _api.loadSession(latest.id, rootDir);
            return { messages: session.messages || [], id: session.id };
        }
    }
    catch { /* no session found, start fresh */ }
    return { messages: [], id: DEFAULT_SESSION_ID };
}
async function saveSessionToBackend(rootDir, messages, mode, sessionId = currentSessionId) {
    // Generate summary from first user message
    const firstUserMsg = messages.find(m => m.role === 'user');
    const summary = firstUserMsg
        ? firstUserMsg.content.slice(0, 50) + (firstUserMsg.content.length > 50 ? '...' : '')
        : 'New conversation';
    try {
        const result = await _api.saveSession({
            id: sessionId,
            summary,
            mode,
            messages: messages.slice(-100),
            history: [],
            rootDir,
        });
        currentSessionId = result.id;
    }
    catch (err) {
        console.error('Failed to save session:', err);
    }
}
const _api = new _services_api__WEBPACK_IMPORTED_MODULE_8__.LLMApiService();
// ─── Helpers ──────────────────────────────────────────────────────────────────
async function buildContextFromAttachments(paths, rootDir) {
    if (paths.length === 0)
        return '';
    const allPaths = [];
    for (const a of paths) {
        if (a.isDir) {
            try {
                const res = await _api.resolveContextPath(a.path, rootDir);
                allPaths.push(...res.paths.slice(0, 20));
            }
            catch { /* skip */ }
        }
        else {
            allPaths.push(a.path);
        }
    }
    if (allPaths.length === 0)
        return '';
    try {
        const res = await _api.readContextFiles(allPaths, rootDir);
        const parts = [];
        for (const f of res.files) {
            if (f.error)
                continue;
            parts.push(`\`\`\`// ${f.path}\n${f.content}\n\`\`\``);
        }
        if (parts.length === 0)
            return '';
        return `<attached_files>\n${parts.join('\n\n')}\n</attached_files>\n\n`;
    }
    catch {
        return '';
    }
}
function uid() {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}
// ─── Component ────────────────────────────────────────────────────────────────
const ChatPanel = ({ settings, onOpenSettings, onSettingsChange }) => {
    const [showSettings, setShowSettings] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showMemory, setShowMemory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showSession, setShowSession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showSkill, setShowSkill] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [currentSettings, setCurrentSettings] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(settings);
    const [sendMode, setSendMode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('agent');
    const [isTestingConnection, setIsTestingConnection] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isSaving, setIsSaving] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [rootDir, setRootDir] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [isLoadingSession, setIsLoadingSession] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    // Unified message state
    const [messages, setMessages] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [isProcessing, setIsProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const abortControllerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const rootDirRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)('');
    // ── Initialize ─────────────────────────────────────────────────────────────
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        // Load workspace and session
        _api.getWorkspaceInfo('').then(info => {
            const dir = info.rootDir || '';
            setRootDir(dir);
            rootDirRef.current = dir;
            // Load session from backend
            return loadSessionFromBackend(dir);
        }).then(sessionData => {
            if (sessionData.messages.length > 0) {
                setMessages(sessionData.messages);
                currentSessionId = sessionData.id;
            }
        }).catch(() => {
            setRootDir('');
        }).finally(() => {
            setIsLoadingSession(false);
        });
    }, []);
    // Sync external settings prop with local currentSettings state
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        setCurrentSettings(prev => ({ ...prev, ...settings }));
    }, [settings]);
    // Persist messages to backend when changed
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (isLoadingSession || !rootDirRef.current || messages.length === 0)
            return;
        const timeoutId = setTimeout(() => {
            saveSessionToBackend(rootDirRef.current, messages, sendMode);
        }, 1000); // Debounce 1 second
        return () => clearTimeout(timeoutId);
    }, [messages, sendMode, isLoadingSession]);
    // ── Mode switching (only affects send handler) ────────────────────────────
    const handleModeChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((m) => {
        // Cancel any ongoing request when switching modes
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
        }
        setSendMode(m);
        // Persist mode to session
        if (rootDirRef.current && messages.length > 0) {
            saveSessionToBackend(rootDirRef.current, messages, m);
        }
    }, [messages]);
    // ── Message handlers ───────────────────────────────────────────────────────
    const addMessage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((msg) => {
        const fullMsg = {
            ...msg,
            id: uid(),
            timestamp: Date.now(),
        };
        setMessages(prev => [...prev, fullMsg]);
        return fullMsg;
    }, []);
    const updateMessage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((id, updates) => {
        setMessages(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));
    }, []);
    // ── Chat handler ───────────────────────────────────────────────────────────
    const handleChatSend = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (text, images, contextText) => {
        const fullText = contextText ? `${contextText}${text}` : text;
        // Add user message
        addMessage({ role: 'user', content: text, mode: 'chat', images });
        setIsProcessing(true);
        setError(null);
        const controller = new AbortController();
        abortControllerRef.current = controller;
        // Build API messages from history
        const apiMessages = messages
            .filter(m => m.role !== 'system')
            .map(m => ({ role: m.role, content: m.content }));
        apiMessages.push({ role: 'user', content: fullText });
        const imageDataUrls = images.map(img => img.dataUrl);
        try {
            if (currentSettings.enableStreaming) {
                const assistantMsg = addMessage({ role: 'assistant', content: '', mode: 'chat', isStreaming: true });
                await _api.streamChat(apiMessages, imageDataUrls.length > 0 ? imageDataUrls : undefined, (chunk) => {
                    if (controller.signal.aborted)
                        return;
                    setMessages(prev => {
                        const idx = prev.findIndex(m => m.id === assistantMsg.id);
                        if (idx === -1)
                            return prev;
                        const next = [...prev];
                        next[idx] = { ...next[idx], content: next[idx].content + chunk };
                        return next;
                    });
                }, currentSettings, controller.signal);
                if (!controller.signal.aborted) {
                    updateMessage(assistantMsg.id, { isStreaming: false });
                }
            }
            else {
                const response = await _api.chat(apiMessages, imageDataUrls.length > 0 ? imageDataUrls : undefined, currentSettings, controller.signal);
                if (!controller.signal.aborted) {
                    addMessage({ role: 'assistant', content: response.content, mode: 'chat' });
                }
            }
        }
        catch (err) {
            if (err instanceof Error && err.name !== 'AbortError') {
                const msg = err instanceof Error ? err.message : 'An error occurred';
                setError(msg);
                addMessage({ role: 'assistant', content: `Error: ${msg}`, mode: 'chat', error: msg });
            }
        }
        finally {
            if (abortControllerRef.current === controller) {
                abortControllerRef.current = null;
            }
            setIsProcessing(false);
        }
    }, [messages, currentSettings, addMessage, updateMessage]);
    // ── Agent handler ──────────────────────────────────────────────────────────
    const handleAgentSend = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (text, contextText) => {
        const fullText = contextText ? `${contextText}${text}` : text;
        // Add user message
        addMessage({ role: 'user', content: text, mode: 'agent' });
        setIsProcessing(true);
        setError(null);
        const controller = new AbortController();
        abortControllerRef.current = controller;
        // Build conversation history
        const history = messages
            .filter(m => m.role === 'user' || m.role === 'assistant')
            .map(m => ({ role: m.role, content: m.content }));
        history.push({ role: 'user', content: fullText });
        let assistantMsgId = uid();
        let currentContent = '';
        const toolMsgMap = {};
        try {
            await _api.runAgent(history, (event) => {
                switch (event.type) {
                    case 'text': {
                        const chunk = event.data?.content || '';
                        currentContent += chunk;
                        setMessages(prev => {
                            const idx = prev.findIndex(m => m.id === assistantMsgId);
                            if (idx === -1) {
                                return [...prev, {
                                        id: assistantMsgId,
                                        role: 'assistant',
                                        content: currentContent,
                                        mode: 'agent',
                                        timestamp: Date.now(),
                                        isStreaming: true,
                                        toolCalls: [],
                                    }];
                            }
                            const next = [...prev];
                            next[idx] = { ...next[idx], content: currentContent, isStreaming: true };
                            return next;
                        });
                        break;
                    }
                    case 'tool_call': {
                        const { id: toolId, name, args } = event.data;
                        const toolUid = uid();
                        toolMsgMap[toolId] = toolUid;
                        setMessages(prev => {
                            const assistantIdx = prev.findIndex(m => m.id === assistantMsgId);
                            const toolCall = {
                                id: toolUid,
                                name,
                                args,
                                status: 'running',
                                startTime: Date.now(),
                            };
                            if (assistantIdx === -1) {
                                // Create assistant message with tool call
                                return [...prev, {
                                        id: assistantMsgId,
                                        role: 'assistant',
                                        content: currentContent,
                                        mode: 'agent',
                                        timestamp: Date.now(),
                                        toolCalls: [toolCall],
                                    }];
                            }
                            else {
                                const next = [...prev];
                                const existing = next[assistantIdx].toolCalls || [];
                                next[assistantIdx] = { ...next[assistantIdx], toolCalls: [...existing, toolCall] };
                                return next;
                            }
                        });
                        break;
                    }
                    case 'tool_result': {
                        const { id: toolId, success, output } = event.data;
                        const msgId = toolMsgMap[toolId];
                        if (!msgId)
                            break;
                        setMessages(prev => {
                            const assistantIdx = prev.findIndex(m => m.id === assistantMsgId);
                            if (assistantIdx === -1)
                                return prev;
                            const next = [...prev];
                            const toolCalls = next[assistantIdx].toolCalls || [];
                            next[assistantIdx] = {
                                ...next[assistantIdx],
                                toolCalls: toolCalls.map(tc => tc.id === msgId
                                    ? { ...tc, status: success ? 'success' : 'error', result: { success, output }, endTime: Date.now() }
                                    : tc),
                            };
                            return next;
                        });
                        break;
                    }
                    case 'iteration': {
                        const { current, max } = event.data;
                        setMessages(prev => {
                            const assistantIdx = prev.findIndex(m => m.id === assistantMsgId);
                            if (assistantIdx === -1)
                                return prev;
                            const next = [...prev];
                            next[assistantIdx] = {
                                ...next[assistantIdx],
                                iteration: { current, max },
                            };
                            return next;
                        });
                        break;
                    }
                    case 'done': {
                        updateMessage(assistantMsgId, { isStreaming: false });
                        break;
                    }
                    case 'error': {
                        setError(event.data?.message || 'An error occurred');
                        updateMessage(assistantMsgId, { isStreaming: false });
                        break;
                    }
                }
            }, rootDir || undefined, currentSettings, 50, controller.signal);
        }
        catch (err) {
            if (err instanceof Error && err.name !== 'AbortError') {
                const msg = err instanceof Error ? err.message : String(err);
                setError(msg);
            }
        }
        finally {
            setIsProcessing(false);
        }
    }, [messages, currentSettings, rootDir, addMessage, updateMessage]);
    // ── Unified send handler ───────────────────────────────────────────────────
    const handleSend = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (text, images, attachedPaths) => {
        const contextText = await buildContextFromAttachments(attachedPaths, rootDir);
        switch (sendMode) {
            case 'chat':
                await handleChatSend(text, images, contextText);
                break;
            case 'agent':
                await handleAgentSend(text, contextText);
                break;
        }
    }, [sendMode, rootDir, handleChatSend, handleAgentSend]);
    const handleStop = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
        }
        setIsProcessing(false);
    }, []);
    const handleClear = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async () => {
        setMessages([]);
        setError(null);
        currentSessionId = DEFAULT_SESSION_ID;
        // Delete session from backend
        try {
            await _api.deleteSession(DEFAULT_SESSION_ID, rootDirRef.current);
        }
        catch { /* ignore if no session to delete */ }
    }, []);
    const handleNewSession = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
        // Clear current messages and reset session id to create a new session
        setMessages([]);
        currentSessionId = DEFAULT_SESSION_ID;
        setShowSession(false);
    }, []);
    const handleRootDirChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((newRootDir) => {
        setRootDir(newRootDir);
        rootDirRef.current = newRootDir;
        // Reload sessions from new directory
        setShowSession(false);
        setTimeout(() => setShowSession(true), 0);
    }, []);
    const handleLoadSession = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (sessionId) => {
        try {
            const session = await _api.loadSession(sessionId, rootDirRef.current);
            if (session.messages && session.messages.length > 0) {
                setMessages(session.messages);
                currentSessionId = sessionId;
                if (session.mode) {
                    setSendMode(session.mode);
                }
            }
            setShowSession(false);
        }
        catch (err) {
            console.error('Failed to load session:', err);
            setError('Failed to load session');
        }
    }, []);
    // ── Settings handlers ──────────────────────────────────────────────────────
    const handleSettingsChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (newSettings) => {
        if (isSaving || !onSettingsChange)
            return;
        setIsSaving(true);
        try {
            await onSettingsChange(newSettings);
            setCurrentSettings(prev => ({ ...prev, ...newSettings }));
        }
        catch (err) {
            console.error('Failed to save settings:', err);
        }
        finally {
            setIsSaving(false);
        }
    }, [isSaving, onSettingsChange]);
    const handleTestConnection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async () => {
        setIsTestingConnection(true);
        try {
            return await _api.testConnection();
        }
        finally {
            setIsTestingConnection(false);
        }
    }, []);
    const hasApiKey = currentSettings.hasApiKey ||
        (currentSettings.apiKey && currentSettings.apiKey.length > 0);
    // ── Header ─────────────────────────────────────────────────────────────────
    const header = ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-chat-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", { children: "LLM Assistant" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-header-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: `llm-header-btn ${showSession ? 'active' : ''}`, onClick: () => setShowSession(v => !v), title: "Sessions", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.22 10.51 20 13 20c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: `llm-header-btn ${showMemory ? 'active' : ''}`, onClick: () => setShowMemory(v => !v), title: "Memory", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z" }) }) }), !showSettings && !showMemory && !showSession && !showSkill && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-header-btn", onClick: handleClear, title: "Clear chat", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" }) }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: `llm-header-btn ${showSkill ? 'active' : ''}`, onClick: () => setShowSkill(v => !v), title: "Skills", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M7.5 4C5.57 4 4 5.57 4 7.5S5.57 11 7.5 11 11 9.43 11 7.5 9.43 4 7.5 4zm0 5C6.67 9 6 9.67 6 10.5S6.67 12 7.5 12 9 11.33 9 10.5 8.33 9 7.5 9zm4.5 4C10.67 13 10 13.67 10 14.5S10.67 16 11.5 16s1.5-.67 1.5-1.5S12.33 13 11.5 13zm4.5 4c-1.83 0-3.5.67-3.5 1.5s1.67 1.5 3.5 1.5 3.5-.67 3.5-1.5-1.67-1.5-3.5-1.5z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: `llm-header-btn ${showSettings ? 'active' : ''}`, onClick: () => setShowSettings(true), title: "Settings", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z" }) }) })] })] }));
    // ── Side panels ────────────────────────────────────────────────────────────
    if (showSettings) {
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-chat-panel", children: [header, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_SettingsPanel__WEBPACK_IMPORTED_MODULE_3__.SettingsPanel, { settings: currentSettings, onSettingsChange: handleSettingsChange, onClose: () => setShowSettings(false), onTestConnection: handleTestConnection, isTestingConnection: isTestingConnection })] }));
    }
    if (showMemory) {
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-chat-panel", children: [header, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_MemoryPanel__WEBPACK_IMPORTED_MODULE_4__.MemoryPanel, { onClose: () => setShowMemory(false) })] }));
    }
    if (showSession) {
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-chat-panel", children: [header, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_SessionPanel__WEBPACK_IMPORTED_MODULE_5__.SessionPanel, { onClose: () => setShowSession(false), onLoadSession: handleLoadSession, onNewSession: handleNewSession, rootDir: rootDir, onRootDirChange: handleRootDirChange })] }));
    }
    if (showSkill) {
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-chat-panel", children: [header, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_SkillPanel__WEBPACK_IMPORTED_MODULE_6__.SkillPanel, { onClose: () => setShowSkill(false), rootDir: rootDir, onRootDirChange: handleRootDirChange })] }));
    }
    // ── Main layout ────────────────────────────────────────────────────────────
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-chat-panel llm-unified-panel", children: [header, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-mode-viewport", children: [error && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-error-banner", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: error }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { onClick: () => setError(null), children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-model-indicator", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-model-name", children: currentSettings.model }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-mode-badge", children: sendMode === 'chat' ? 'Chat' : 'Agent' }), !hasApiKey && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-api-warning", children: "API Key not set" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_UnifiedMessageList__WEBPACK_IMPORTED_MODULE_7__.UnifiedMessageList, { messages: messages, isLoading: isProcessing })] }), isProcessing && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "agent-running-bar", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "agent-thinking-dots", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {}), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {}), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {})] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "agent-thinking-label", children: "Processing..." }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", { className: "agent-stop-btn", onClick: handleStop, children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M6 6h12v12H6z" }) }), "Stop"] })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_InputArea__WEBPACK_IMPORTED_MODULE_2__.InputArea, { onSend: handleSend, disabled: isProcessing || !hasApiKey, mode: sendMode, onModeChange: handleModeChange, rootDir: rootDir })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatPanel);


/***/ },

/***/ "./lib/components/CodeBlock.js"
/*!*************************************!*\
  !*** ./lib/components/CodeBlock.js ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeBlock: () => (/* binding */ CodeBlock),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var highlight_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! highlight.js */ "webpack/sharing/consume/default/highlight.js/highlight.js");

/**
 * Code block component with copy functionality.
 */


/**
 * Code block with syntax highlighting and copy button
 */
const CodeBlock = ({ code, language }) => {
    const [copied, setCopied] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const codeRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // Apply syntax highlighting
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (codeRef.current) {
            highlight_js__WEBPACK_IMPORTED_MODULE_2__["default"].highlightElement(codeRef.current);
        }
    }, [code, language]);
    // Handle copy to clipboard
    const handleCopy = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async () => {
        try {
            await navigator.clipboard.writeText(code);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
        catch (err) {
            console.error('Failed to copy:', err);
        }
    }, [code]);
    // Normalize language name
    const normalizedLanguage = language || 'plaintext';
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-code-block", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-code-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-code-language", children: normalizedLanguage }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", { className: "llm-code-copy-btn", onClick: handleCopy, title: copied ? 'Copied!' : 'Copy code', children: [copied ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z" }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: copied ? 'Copied!' : 'Copy' })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("pre", { className: "llm-code-content", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("code", { ref: codeRef, className: `language-${normalizedLanguage}`, children: code }) })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CodeBlock);


/***/ },

/***/ "./lib/components/InputArea.js"
/*!*************************************!*\
  !*** ./lib/components/InputArea.js ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InputArea: () => (/* binding */ InputArea),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api */ "./lib/services/api.js");

/**
 * InputArea — unified input block for Chat / Agent modes.
 *
 * v0.7.0 changes:
 * - Textarea grows from 120 px (min) to 400 px (max) — suitable for large inputs
 * - Toolbar row: image attach button + file/dir attach button + send button
 * - @ mention: now resolves BOTH files and directories;
 *   selecting a directory opens it inline in the picker (drill-down)
 * - Attachment chip list: selected @-referenced paths shown as dismissable chips
 * - Ctrl+Enter or Cmd+Enter to send (Enter = newline by default at 3+ lines,
 *   Enter still sends on single-line for quick use; configurable)
 * - enableVision is now always true from InputArea perspective — the image
 *   button is always shown (backend handles capability check)
 */


const _api = new _services_api__WEBPACK_IMPORTED_MODULE_2__.LLMApiService();
// ── Utilities ─────────────────────────────────────────────────────────────────
function genId() {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
}
function findAtTrigger(value, cursor) {
    const before = value.slice(0, cursor);
    const idx = before.lastIndexOf('@');
    if (idx === -1)
        return -1;
    const afterAt = before.slice(idx + 1);
    if (/\s/.test(afterAt))
        return -1;
    return idx;
}
function getAtQuery(value, cursor, atIdx) {
    return value.slice(atIdx + 1, cursor);
}
// ── Component ─────────────────────────────────────────────────────────────────
const InputArea = ({ onSend, disabled, mode, onModeChange, rootDir, }) => {
    const [text, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [images, setImages] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [attachedPaths, setAttachedPaths] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const textareaRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const imageInputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const fileInputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // ── @ mention state ──────────────────────────────────────────────────────
    const [atIdx, setAtIdx] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(-1);
    const [atQuery, setAtQuery] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [suggestions, setSuggestions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [suggestionIdx, setSuggestionIdx] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [loadingSuggestions, setLoadingSuggestions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    /** Breadcrumb stack for directory drill-down */
    const [browseDir, setBrowseDir] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const mentionMenuRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const fetchAbortRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // ── Auto-resize textarea (min 120 px, max 400 px) ────────────────────────
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        const ta = textareaRef.current;
        if (!ta)
            return;
        ta.style.height = 'auto';
        const next = Math.max(120, Math.min(ta.scrollHeight, 400));
        ta.style.height = `${next}px`;
    }, [text]);
    // ── Fetch file/dir suggestions ─────────────────────────────────────────
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (atIdx === -1) {
            setSuggestions([]);
            return;
        }
        fetchAbortRef.current?.abort();
        fetchAbortRef.current = new AbortController();
        setLoadingSuggestions(true);
        const query = atQuery;
        const searchPath = browseDir || query || '.';
        const fetchSuggestions = async () => {
            try {
                const result = await _api.resolveContextPath(searchPath, rootDir || '');
                // Build suggestion list
                const items = [];
                if (result.isDir) {
                    // If the resolved path is a directory, list its immediate children
                    const childResult = await _api.listDirContents(searchPath, rootDir || '');
                    for (const item of childResult.entries.slice(0, 30)) {
                        items.push({
                            path: item.path,
                            isDir: item.isDir,
                            label: item.name,
                        });
                    }
                }
                else {
                    // Files matching pattern
                    for (const p of result.paths.slice(0, 30)) {
                        items.push({
                            path: p,
                            isDir: false,
                            label: p.split('/').pop() || p,
                        });
                    }
                }
                // Filter by query if we have one and didn't drill into a dir
                const filtered = query && !browseDir
                    ? items.filter(i => i.label.toLowerCase().includes(query.toLowerCase()) ||
                        i.path.toLowerCase().includes(query.toLowerCase()))
                    : items;
                setSuggestions(filtered);
                setSuggestionIdx(0);
            }
            catch {
                setSuggestions([]);
            }
            finally {
                setLoadingSuggestions(false);
            }
        };
        const timer = setTimeout(fetchSuggestions, 150);
        return () => clearTimeout(timer);
    }, [atIdx, atQuery, browseDir, rootDir]);
    // ── Close @ menu on outside click ─────────────────────────────────────────
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (atIdx === -1)
            return;
        const handler = (e) => {
            if (mentionMenuRef.current &&
                !mentionMenuRef.current.contains(e.target) &&
                textareaRef.current !== e.target) {
                setAtIdx(-1);
                setSuggestions([]);
                setBrowseDir('');
            }
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, [atIdx]);
    // ── Handle text change ────────────────────────────────────────────────────
    const handleTextChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e) => {
        const val = e.target.value;
        const cursor = e.target.selectionStart ?? val.length;
        setText(val);
        const idx = findAtTrigger(val, cursor);
        if (idx !== -1) {
            const q = getAtQuery(val, cursor, idx);
            setAtIdx(idx);
            setAtQuery(q);
            // Reset drill-down when query changes
            setBrowseDir('');
        }
        else {
            setAtIdx(-1);
            setAtQuery('');
            setSuggestions([]);
            setBrowseDir('');
        }
    }, []);
    // ── Select a suggestion ───────────────────────────────────────────────────
    const handleSelectSuggestion = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((suggestion) => {
        if (atIdx === -1)
            return;
        if (suggestion.isDir) {
            // Drill into directory — update browseDir, keep @ menu open
            setBrowseDir(suggestion.path);
            setSuggestions([]);
            setSuggestionIdx(0);
            textareaRef.current?.focus();
            return;
        }
        // File selected: replace @query with chip, remove from text
        const cursor = textareaRef.current?.selectionStart ?? text.length;
        const before = text.slice(0, atIdx);
        const after = text.slice(cursor);
        // Remove the @query part from text — the path becomes a chip
        const newText = before + after;
        setText(newText);
        // Add chip
        setAttachedPaths(prev => {
            if (prev.find(a => a.path === suggestion.path))
                return prev;
            return [...prev, { id: genId(), path: suggestion.path, isDir: false }];
        });
        // Reset mention state
        setAtIdx(-1);
        setAtQuery('');
        setSuggestions([]);
        setBrowseDir('');
        requestAnimationFrame(() => {
            if (textareaRef.current) {
                textareaRef.current.focus();
                const newCursor = before.length;
                textareaRef.current.setSelectionRange(newCursor, newCursor);
            }
        });
    }, [atIdx, text]);
    // ── Attach a whole directory as a chip (from toolbar) ─────────────────────
    const handleAttachDirAsChip = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((suggestion) => {
        setAttachedPaths(prev => {
            if (prev.find(a => a.path === suggestion.path))
                return prev;
            return [...prev, { id: genId(), path: suggestion.path, isDir: suggestion.isDir }];
        });
        setAtIdx(-1);
        setSuggestions([]);
        setBrowseDir('');
    }, []);
    // ── Remove a path chip ────────────────────────────────────────────────────
    const handleRemoveChip = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((id) => setAttachedPaths(prev => prev.filter(a => a.id !== id)), []);
    // ── Image handling ────────────────────────────────────────────────────────
    const handleImageSelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (e) => {
        const files = e.target.files;
        if (!files || files.length === 0)
            return;
        const newImages = [];
        for (const file of Array.from(files)) {
            if (!file.type.startsWith('image/'))
                continue;
            const dataUrl = await new Promise(resolve => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.readAsDataURL(file);
            });
            newImages.push({ id: genId(), dataUrl, file, preview: dataUrl });
        }
        setImages(prev => [...prev, ...newImages]);
        if (imageInputRef.current)
            imageInputRef.current.value = '';
    }, []);
    const handlePaste = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (e) => {
        const items = e.clipboardData.items;
        const newImages = [];
        for (const item of Array.from(items)) {
            if (!item.type.startsWith('image/'))
                continue;
            const file = item.getAsFile();
            if (!file)
                continue;
            const dataUrl = await new Promise(resolve => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.readAsDataURL(file);
            });
            newImages.push({ id: genId(), dataUrl, file, preview: dataUrl });
        }
        if (newImages.length > 0)
            setImages(prev => [...prev, ...newImages]);
    }, []);
    const handleRemoveImage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((id) => setImages(prev => prev.filter(img => img.id !== id)), []);
    // ── Send ──────────────────────────────────────────────────────────────────
    const handleSend = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
        if (disabled)
            return;
        if (!text.trim() && images.length === 0 && attachedPaths.length === 0)
            return;
        onSend(text.trim(), images, attachedPaths);
        setText('');
        setImages([]);
        setAttachedPaths([]);
        setAtIdx(-1);
        setSuggestions([]);
        setBrowseDir('');
        if (textareaRef.current)
            textareaRef.current.style.height = '120px';
    }, [text, images, attachedPaths, disabled, onSend]);
    // ── Keyboard navigation ───────────────────────────────────────────────────
    const handleKeyDown = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e) => {
        // Navigate @ menu
        if (atIdx !== -1 && suggestions.length > 0) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSuggestionIdx(i => Math.min(i + 1, suggestions.length - 1));
                return;
            }
            if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSuggestionIdx(i => Math.max(i - 1, 0));
                return;
            }
            if (e.key === 'Tab' || e.key === 'Enter') {
                e.preventDefault();
                handleSelectSuggestion(suggestions[suggestionIdx]);
                return;
            }
            if (e.key === 'Escape') {
                e.preventDefault();
                setAtIdx(-1);
                setSuggestions([]);
                setBrowseDir('');
                return;
            }
            if (e.key === 'Backspace' && browseDir) {
                e.preventDefault();
                // Go up one level
                const parts = browseDir.split('/');
                parts.pop();
                setBrowseDir(parts.join('/'));
                return;
            }
        }
        // Ctrl+Enter or Cmd+Enter → always send
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            handleSend();
            return;
        }
        // Plain Enter on a short single-line text → send; otherwise newline
        if (e.key === 'Enter' && !e.shiftKey && atIdx === -1) {
            const lineCount = (text.match(/\n/g) || []).length + 1;
            if (lineCount <= 2) {
                e.preventDefault();
                handleSend();
            }
            // 3+ lines: Enter inserts newline (let default happen)
        }
    }, [atIdx, suggestions, suggestionIdx, handleSelectSuggestion, handleSend, browseDir, text]);
    const canSend = !disabled && (text.trim().length > 0 || images.length > 0 || attachedPaths.length > 0);
    // ── Mode label ────────────────────────────────────────────────────────────
    const modeLabel = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => {
        return mode === 'chat' ? 'Chat' : 'Agent';
    }, [mode]);
    // ── Breadcrumb display ────────────────────────────────────────────────────
    const browseDirDisplay = browseDir
        ? browseDir.split('/').filter(Boolean).join(' / ')
        : null;
    // ── Render ────────────────────────────────────────────────────────────────
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-input-area", children: [attachedPaths.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-attached-chips", children: attachedPaths.map(a => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: `llm-chip ${a.isDir ? 'llm-chip-dir' : 'llm-chip-file'}`, children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-chip-icon", children: a.isDir ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "11", height: "11", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z" }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "11", height: "11", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.89 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z" }) })) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-chip-label", title: a.path, children: a.path.split('/').pop() || a.path }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-chip-remove", onMouseDown: e => { e.preventDefault(); handleRemoveChip(a.id); }, title: "Remove", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "10", height: "10", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] }, a.id))) })), images.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-image-previews", children: images.map(image => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-image-preview", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", { src: image.preview, alt: "Preview" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-image-remove", onClick: () => handleRemoveImage(image.id), title: "Remove image", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] }, image.id))) })), atIdx !== -1 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-mention-menu", ref: mentionMenuRef, children: [browseDirDisplay && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-mention-breadcrumb", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-mention-breadcrumb-back", onMouseDown: e => {
                                    e.preventDefault();
                                    const parts = browseDir.split('/');
                                    parts.pop();
                                    setBrowseDir(parts.join('/'));
                                }, title: "Go up", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "12", height: "12", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-mention-breadcrumb-path", children: browseDirDisplay })] })), loadingSuggestions ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-mention-loading", children: "Loading\u2026" })) : suggestions.length === 0 ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-mention-empty", children: "No matches" })) : (suggestions.map((s, i) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: `llm-mention-item ${i === suggestionIdx ? 'active' : ''}`, onMouseDown: e => {
                            e.preventDefault();
                            if (s.isDir) {
                                // Offer two actions: drill-down OR attach whole dir
                                // Single click → drill-down; the "attach dir" chip button on hover
                                handleSelectSuggestion(s);
                            }
                            else {
                                handleSelectSuggestion(s);
                            }
                        }, onMouseEnter: () => setSuggestionIdx(i), children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-mention-icon", children: s.isDir ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "13", height: "13", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z" }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "13", height: "13", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.89 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z" }) })) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-mention-label", title: s.path, children: s.label }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-mention-path", children: s.path }), s.isDir && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-mention-attach-dir", onMouseDown: e => {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    handleAttachDirAsChip(s);
                                }, title: "Attach entire directory", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "11", height: "11", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 13H13v6h-2v-6H5v-2h6V5h2v6h6v2z" }) }) }))] }, s.path)))), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-mention-hint", children: ["\u2191\u2193 navigate \u00B7 Enter/Tab select \u00B7 Esc close \u00B7 Backspace up", ' ', suggestions.some(s => s.isDir) && '· click folder to browse · + to attach dir'] })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", { ref: textareaRef, className: "llm-text-input llm-text-input-large", value: text, onChange: handleTextChange, onKeyDown: handleKeyDown, onPaste: handlePaste, placeholder: `Message (@ to reference files/dirs · paste images · Ctrl+Enter or Enter to send)`, disabled: disabled, rows: 4 }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-input-toolbar", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-mode-selector", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { className: "llm-mode-selector-icon", viewBox: "0 0 24 24", width: "13", height: "13", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15v-4H7l5-8v4h4l-5 8z" }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", { className: "llm-mode-select", value: mode, onChange: e => onModeChange(e.target.value), disabled: disabled, title: "Switch mode", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", { value: "chat", children: "Chat" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", { value: "agent", children: "Agent" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { className: "llm-mode-select-chevron", viewBox: "0 0 24 24", width: "12", height: "12", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M7 10l5 5 5-5z" }) })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "llm-input-hint-text", children: [modeLabel, " \u00B7 Ctrl+Enter to send"] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-input-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { ref: imageInputRef, type: "file", accept: "image/*", multiple: true, onChange: handleImageSelect, style: { display: 'none' } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-toolbar-btn", onClick: () => imageInputRef.current?.click(), disabled: disabled, title: "Attach image", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { ref: fileInputRef, type: "file", multiple: true, onChange: async (e) => {
                                    const files = e.target.files;
                                    if (!files)
                                        return;
                                    for (const f of Array.from(files)) {
                                        if (f.type.startsWith('image/')) {
                                            // Images → inline preview
                                            const dataUrl = await new Promise(resolve => {
                                                const reader = new FileReader();
                                                reader.onload = () => resolve(reader.result);
                                                reader.readAsDataURL(f);
                                            });
                                            setImages(prev => [...prev, { id: genId(), dataUrl, file: f, preview: dataUrl }]);
                                        }
                                        else {
                                            // Non-image files → attach as a path chip using the file name
                                            // (browser File objects don't expose the full server path, so we
                                            // attach by name; the @ picker is preferred for server-side paths)
                                            const chipPath = f.name;
                                            setAttachedPaths(prev => {
                                                if (prev.find(a => a.path === chipPath))
                                                    return prev;
                                                return [...prev, { id: genId(), path: chipPath, isDir: false }];
                                            });
                                        }
                                    }
                                    if (fileInputRef.current)
                                        fileInputRef.current.value = '';
                                }, style: { display: 'none' } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-toolbar-btn", onClick: () => fileInputRef.current?.click(), disabled: disabled, title: "Attach file", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-send-btn", onClick: handleSend, disabled: !canSend, title: "Send (Ctrl+Enter)", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "18", height: "18", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" }) }) })] })] })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputArea);


/***/ },

/***/ "./lib/components/MarkdownRenderer.js"
/*!********************************************!*\
  !*** ./lib/components/MarkdownRenderer.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MarkdownRenderer: () => (/* binding */ MarkdownRenderer),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-markdown */ "webpack/sharing/consume/default/react-markdown/react-markdown");
/* harmony import */ var remark_gfm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! remark-gfm */ "webpack/sharing/consume/default/remark-gfm/remark-gfm");
/* harmony import */ var _CodeBlock__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CodeBlock */ "./lib/components/CodeBlock.js");

/**
 * Markdown renderer component.
 */




/**
 * Custom paragraph component
 */
const Paragraph = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-md-paragraph", children: children });
};
/**
 * Custom link component
 */
const Link = ({ href, children }) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", { href: href, target: "_blank", rel: "noopener noreferrer", className: "llm-md-link", children: children }));
};
/**
 * Custom code component
 */
const Code = ({ inline, className, children }) => {
    const match = /language-(\w+)/.exec(className || '');
    const lang = match ? match[1] : '';
    const codeString = String(children).replace(/\n$/, '');
    if (inline) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("code", { className: "llm-md-code-inline", children: children });
    }
    // Check if it's a code block with language
    if (lang || codeString.includes('\n')) {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_CodeBlock__WEBPACK_IMPORTED_MODULE_4__.CodeBlock, { code: codeString, language: lang });
    }
    // Single line code without language
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("code", { className: "llm-md-code-inline", children: children });
};
/**
 * Custom pre component (we handle this in Code component)
 */
const Pre = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: children });
};
/**
 * Custom list components
 */
const Ul = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("ul", { className: "llm-md-list", children: children });
};
const Ol = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("ol", { className: "llm-md-list llm-md-list-ordered", children: children });
};
const Li = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", { className: "llm-md-list-item", children: children });
};
/**
 * Custom heading components
 */
const Heading = ({ level, children }) => {
    const Tag = `h${level}`;
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Tag, { className: `llm-md-heading llm-md-heading-${level}`, children: children });
};
/**
 * Custom blockquote component
 */
const Blockquote = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("blockquote", { className: "llm-md-blockquote", children: children });
};
/**
 * Custom table components
 */
const Table = ({ children }) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-md-table-wrapper", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("table", { className: "llm-md-table", children: children }) }));
};
const Th = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("th", { className: "llm-md-th", children: children });
};
const Td = ({ children }) => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("td", { className: "llm-md-td", children: children });
};
/**
 * Think block component - collapsible thinking content
 */
const ThinkBlock = ({ content }) => {
    const [expanded, setExpanded] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-think-block", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", { className: "llm-think-header", onClick: () => setExpanded(v => !v), children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-think-icon", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M9 21c0 .5.4 1 1 1h4c.6 0 1-.5 1-1v-1H9v1zm3-19C8.1 2 5 5.1 5 9c0 2.4 1.2 4.5 3 5.7V17c0 .5.4 1 1 1h6c.6 0 1-.5 1-1v-2.3c1.8-1.3 3-3.4 3-5.7 0-3.9-3.1-7-7-7z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-think-label", children: "\u601D\u8003\u8FC7\u7A0B" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-think-chevron", children: expanded ? '▲' : '▼' })] }), expanded && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-think-content", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], { remarkPlugins: [remark_gfm__WEBPACK_IMPORTED_MODULE_3__["default"]], components: {
                        p: Paragraph,
                        a: Link,
                        code: Code,
                        pre: Pre,
                        ul: Ul,
                        ol: Ol,
                        li: Li,
                        h1: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 1, ...props })),
                        h2: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 2, ...props })),
                        h3: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 3, ...props })),
                        blockquote: Blockquote,
                    }, children: content }) }))] }));
};
/**
 * Preprocess content to handle <think> tags
 */
function preprocessThinkTags(content) {
    const result = [];
    let remaining = content;
    while (remaining.length > 0) {
        const thinkStart = remaining.indexOf('<think>');
        if (thinkStart === -1) {
            // No more <think> tags
            if (remaining.trim()) {
                result.push({ type: 'markdown', content: remaining });
            }
            break;
        }
        // Add content before <think>
        if (thinkStart > 0) {
            const before = remaining.slice(0, thinkStart);
            if (before.trim()) {
                result.push({ type: 'markdown', content: before });
            }
        }
        // Find closing </think>
        const thinkEnd = remaining.indexOf('</think>', thinkStart);
        if (thinkEnd === -1) {
            // Unclosed <think> tag - treat rest as think content
            const thinkContent = remaining.slice(thinkStart + 7); // 7 = len('<think>')
            if (thinkContent.trim()) {
                result.push({ type: 'think', content: thinkContent });
            }
            break;
        }
        // Extract think content
        const thinkContent = remaining.slice(thinkStart + 7, thinkEnd);
        if (thinkContent.trim()) {
            result.push({ type: 'think', content: thinkContent });
        }
        remaining = remaining.slice(thinkEnd + 8); // 8 = len('</think>')
    }
    return result;
}
/**
 * Markdown renderer component
 */
const MarkdownRenderer = ({ content }) => {
    // Memoize the components object
    const components = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => ({
        p: Paragraph,
        a: Link,
        code: Code,
        pre: Pre,
        ul: Ul,
        ol: Ol,
        li: Li,
        h1: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 1, ...props })),
        h2: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 2, ...props })),
        h3: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 3, ...props })),
        h4: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 4, ...props })),
        h5: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 5, ...props })),
        h6: ((props) => (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Heading, { level: 6, ...props })),
        blockquote: Blockquote,
        table: Table,
        th: Th,
        td: Td,
    }), []);
    // Process <think> tags
    const segments = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(() => preprocessThinkTags(content), [content]);
    // If no think tags, render normally
    if (segments.length === 1 && segments[0].type === 'markdown') {
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-markdown-content", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], { remarkPlugins: [remark_gfm__WEBPACK_IMPORTED_MODULE_3__["default"]], components: components, children: segments[0].content }) }));
    }
    // Render with think blocks
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-markdown-content", children: segments.map((segment, index) => segment.type === 'think' ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ThinkBlock, { content: segment.content }, index)) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], { remarkPlugins: [remark_gfm__WEBPACK_IMPORTED_MODULE_3__["default"]], components: components, children: segment.content }, index))) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MarkdownRenderer);


/***/ },

/***/ "./lib/components/MemoryPanel.js"
/*!***************************************!*\
  !*** ./lib/components/MemoryPanel.js ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MemoryPanel: () => (/* binding */ MemoryPanel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);

/**
 * MemoryPanel — persistent memory management UI.
 *
 * Allows users to create, edit, enable/disable, and delete named memory entries
 * that are automatically injected into every LLM conversation as extra context.
 *
 * Features:
 *  - List all memories with enable/disable toggle
 *  - Create new memory (title + content + optional tags)
 *  - Inline editing of existing memories
 *  - Delete individual memories
 *  - Auto-reload on open
 */


// ─── API helpers ─────────────────────────────────────────────────────────────
function getXsrfToken() {
    const cookie = document.cookie.split(';').find(c => c.trim().startsWith('_xsrf='));
    return cookie ? decodeURIComponent(cookie.split('=')[1]) : '';
}
function getHeaders() {
    return { 'Content-Type': 'application/json', 'X-XSRFToken': getXsrfToken() };
}
function memoryApiBase() {
    const root = (_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getOption('baseUrl') || '/').replace(/\/$/, '');
    return `${root}/llm-assistant/memory`;
}
async function fetchMemories() {
    const r = await fetch(memoryApiBase(), { headers: getHeaders() });
    if (!r.ok)
        throw new Error(`Failed to load memories: ${r.statusText}`);
    const d = await r.json();
    return d.memories || [];
}
async function createMemory(title, content, tags) {
    const r = await fetch(memoryApiBase(), {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ title, content, tags }),
    });
    if (!r.ok)
        throw new Error(`Failed to create memory: ${r.statusText}`);
    return r.json();
}
async function updateMemory(id, patch) {
    const r = await fetch(`${memoryApiBase()}/${id}`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(patch),
    });
    if (!r.ok)
        throw new Error(`Failed to update memory: ${r.statusText}`);
    return r.json();
}
async function deleteMemory(id) {
    const r = await fetch(`${memoryApiBase()}/${id}`, {
        method: 'DELETE',
        headers: getHeaders(),
    });
    if (!r.ok && r.status !== 204)
        throw new Error(`Failed to delete memory: ${r.statusText}`);
}
const MemoryForm = ({ initial, onSave, onCancel, saving }) => {
    const [title, setTitle] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initial?.title ?? '');
    const [content, setContent] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initial?.content ?? '');
    const [tagsStr, setTagsStr] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)((initial?.tags ?? []).join(', '));
    const handleSubmit = async (e) => {
        e.preventDefault();
        const tags = tagsStr
            .split(',')
            .map(t => t.trim())
            .filter(Boolean);
        await onSave(title.trim(), content.trim(), tags);
    };
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", { className: "memory-form", onSubmit: handleSubmit, children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-form-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { className: "memory-form-label", children: "Title *" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { className: "memory-form-input", type: "text", value: title, onChange: e => setTitle(e.target.value), placeholder: "e.g. My preferred language", required: true, autoFocus: true })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-form-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { className: "memory-form-label", children: "Content *" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", { className: "memory-form-textarea", value: content, onChange: e => setContent(e.target.value), placeholder: "e.g. Always respond in Python unless told otherwise.", required: true, rows: 4 })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-form-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { className: "memory-form-label", children: "Tags (comma-separated, optional)" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { className: "memory-form-input", type: "text", value: tagsStr, onChange: e => setTagsStr(e.target.value), placeholder: "e.g. coding, style" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-form-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { type: "button", className: "memory-btn memory-btn-secondary", onClick: onCancel, disabled: saving, children: "Cancel" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { type: "submit", className: "memory-btn memory-btn-primary", disabled: saving || !title.trim() || !content.trim(), children: saving ? 'Saving…' : initial?.id ? 'Update' : 'Add Memory' })] })] }));
};
// ─── Main MemoryPanel ────────────────────────────────────────────────────────
const MemoryPanel = ({ onClose }) => {
    const [memories, setMemories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [showAddForm, setShowAddForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [editingId, setEditingId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [saving, setSaving] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [confirmDeleteId, setConfirmDeleteId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const load = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async () => {
        setLoading(true);
        setError(null);
        try {
            const mems = await fetchMemories();
            setMemories(mems);
        }
        catch (e) {
            setError(e instanceof Error ? e.message : String(e));
        }
        finally {
            setLoading(false);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => { load(); }, [load]);
    const handleCreate = async (title, content, tags) => {
        setSaving(true);
        try {
            const entry = await createMemory(title, content, tags);
            setMemories(prev => [entry, ...prev]);
            setShowAddForm(false);
        }
        catch (e) {
            setError(e instanceof Error ? e.message : String(e));
        }
        finally {
            setSaving(false);
        }
    };
    const handleUpdate = async (id, title, content, tags) => {
        setSaving(true);
        try {
            const updated = await updateMemory(id, { title, content, tags });
            setMemories(prev => prev.map(m => m.id === id ? updated : m));
            setEditingId(null);
        }
        catch (e) {
            setError(e instanceof Error ? e.message : String(e));
        }
        finally {
            setSaving(false);
        }
    };
    const handleToggleEnabled = async (id, enabled) => {
        try {
            const updated = await updateMemory(id, { enabled });
            setMemories(prev => prev.map(m => m.id === id ? updated : m));
        }
        catch (e) {
            setError(e instanceof Error ? e.message : String(e));
        }
    };
    const handleDelete = async (id) => {
        try {
            await deleteMemory(id);
            setMemories(prev => prev.filter(m => m.id !== id));
            setConfirmDeleteId(null);
        }
        catch (e) {
            setError(e instanceof Error ? e.message : String(e));
        }
    };
    const enabledCount = memories.filter(m => m.enabled).length;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-panel", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-header-left", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", className: "memory-header-icon", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z" }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "memory-header-title", children: "Memory" }), enabledCount > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "memory-count-badge", children: [enabledCount, " active"] }))] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-header-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-icon-btn", onClick: () => { setShowAddForm(v => !v); setEditingId(null); }, title: "Add memory", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "15", height: "15", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-icon-btn", onClick: load, title: "Refresh", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "15", height: "15", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-icon-btn", onClick: onClose, title: "Close", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "15", height: "15", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-info-bar", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "11", height: "11", fill: "currentColor", style: { flexShrink: 0, opacity: 0.6 }, children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "Active memories are injected into every conversation as context." })] }), error && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-error", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: error }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { onClick: () => setError(null), children: "\u2715" })] })), showAddForm && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "memory-form-wrapper", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MemoryForm, { onSave: handleCreate, onCancel: () => setShowAddForm(false), saving: saving }) })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "memory-list", children: loading ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "memory-loading", children: "Loading\u2026" })) : memories.length === 0 ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-empty", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "32", height: "32", fill: "currentColor", opacity: "0.25", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z" }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { children: "No memories yet." }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-btn memory-btn-primary", onClick: () => setShowAddForm(true), children: "Add your first memory" })] })) : (memories.map(m => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: `memory-item ${m.enabled ? '' : 'memory-item-disabled'}`, children: editingId === m.id ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "memory-form-wrapper", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MemoryForm, { initial: m, onSave: (t, c, tags) => handleUpdate(m.id, t, c, tags), onCancel: () => setEditingId(null), saving: saving }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-item-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: `memory-toggle ${m.enabled ? 'memory-toggle-on' : 'memory-toggle-off'}`, onClick: () => handleToggleEnabled(m.id, !m.enabled), title: m.enabled ? 'Disable memory' : 'Enable memory', children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "memory-toggle-thumb" }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "memory-item-title", children: m.title }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "memory-item-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-item-btn", onClick: () => { setEditingId(m.id); setShowAddForm(false); }, title: "Edit", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "13", height: "13", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" }) }) }), confirmDeleteId === m.id ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "memory-confirm-delete", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-item-btn memory-item-btn-danger", onClick: () => handleDelete(m.id), title: "Confirm delete", children: "\u2713" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-item-btn", onClick: () => setConfirmDeleteId(null), title: "Cancel", children: "\u2715" })] })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "memory-item-btn", onClick: () => setConfirmDeleteId(m.id), title: "Delete", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "13", height: "13", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" }) }) }))] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "memory-item-content", children: m.content }), m.tags.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "memory-item-tags", children: m.tags.map(tag => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "memory-tag", children: tag }, tag))) }))] })) }, m.id)))) })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MemoryPanel);


/***/ },

/***/ "./lib/components/SessionPanel.js"
/*!****************************************!*\
  !*** ./lib/components/SessionPanel.js ***!
  \****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SessionPanel: () => (/* binding */ SessionPanel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api */ "./lib/services/api.js");

/**
 * SessionPanel — Session history management panel
 *
 * Displays a list of saved sessions from .llm-assistant/sessions/
 * Allows loading, deleting, and creating new sessions.
 */


const _api = new _services_api__WEBPACK_IMPORTED_MODULE_2__.LLMApiService();
const SessionPanel = ({ onClose, onLoadSession, onNewSession, rootDir, onRootDirChange, }) => {
    const [sessions, setSessions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [deletingId, setDeletingId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [showRootDirEdit, setShowRootDirEdit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [rootDirInput, setRootDirInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(rootDir);
    const loadSessions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const data = await _api.listSessions(rootDir);
            setSessions(data);
        }
        catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to load sessions');
        }
        finally {
            setIsLoading(false);
        }
    }, [rootDir]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        loadSessions();
    }, [loadSessions]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        setRootDirInput(rootDir);
    }, [rootDir]);
    const handleDelete = async (id, e) => {
        e.stopPropagation();
        setDeletingId(id);
        try {
            await _api.deleteSession(id, rootDir);
            await loadSessions();
        }
        catch (err) {
            console.error('Failed to delete session:', err);
        }
        finally {
            setDeletingId(null);
        }
    };
    const handleRootDirSave = () => {
        if (onRootDirChange && rootDirInput !== rootDir) {
            onRootDirChange(rootDirInput);
        }
        setShowRootDirEdit(false);
    };
    const formatDate = (timestamp) => {
        const date = new Date(timestamp);
        return date.toLocaleString();
    };
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-panel", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", { children: "Session History" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-header-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-header-btn llm-new-session-btn", onClick: onNewSession, title: "New Session", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-close-btn", onClick: onClose, title: "Close", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "18", height: "18", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-rootdir-label", children: "Project Directory" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-rootdir-edit-btn", onClick: () => setShowRootDirEdit(!showRootDirEdit), title: "Edit project directory", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" }) }) })] }), showRootDirEdit ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-edit", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "text", className: "llm-rootdir-input", value: rootDirInput, onChange: (e) => setRootDirInput(e.target.value), placeholder: "Enter project directory path...", onKeyDown: (e) => {
                                    if (e.key === 'Enter')
                                        handleRootDirSave();
                                    if (e.key === 'Escape')
                                        setShowRootDirEdit(false);
                                }, autoFocus: true }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-rootdir-save", onClick: handleRootDirSave, children: "Save" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-rootdir-cancel", onClick: () => setShowRootDirEdit(false), children: "Cancel" })] })] })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-rootdir-path", title: rootDir, children: rootDir || 'Using current working directory' }))] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-content", children: [isLoading && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-loading", children: "Loading sessions..." }), error && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-error", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: error }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { onClick: loadSessions, children: "Retry" })] })), !isLoading && !error && sessions.length === 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-empty", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { children: "No saved sessions" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-hint", children: "Chat history is automatically saved to .llm-assistant/sessions/" })] })), !isLoading && !error && sessions.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-session-list", children: sessions.map((session) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-item", onClick: () => onLoadSession(session.id), children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-info", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-session-title", children: session.summary || 'Untitled session' }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-session-meta", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: `llm-session-mode llm-mode-${session.mode}`, children: session.mode }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "llm-session-count", children: [session.messageCount, " messages"] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-session-date", children: formatDate(session.savedAt) })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-session-delete", onClick: (e) => handleDelete(session.id, e), disabled: deletingId === session.id, title: "Delete session", children: deletingId === session.id ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-spinner" })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" }) })) })] }, session.id))) }))] })] }));
};


/***/ },

/***/ "./lib/components/SettingsPanel.js"
/*!*****************************************!*\
  !*** ./lib/components/SettingsPanel.js ***!
  \*****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsPanel: () => (/* binding */ SettingsPanel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api */ "./lib/services/api.js");

/**
 * Settings panel component.
 */


/**
 * Settings panel component
 */
const SettingsPanel = ({ settings, onSettingsChange, onClose, onTestConnection, isTestingConnection, }) => {
    const apiService = new _services_api__WEBPACK_IMPORTED_MODULE_2__.LLMApiService();
    // Find current provider based on endpoint
    const getCurrentProvider = (providers, endpoint) => {
        if (!endpoint)
            return null;
        const cleanEndpoint = endpoint.replace('https://', '').replace('http://', '').split('/')[0];
        return providers.find(p => p.apiEndpoint.includes(cleanEndpoint)) || null;
    };
    const [providers, setProviders] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [localSettings, setLocalSettings] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(() => ({
        ...settings,
        apiKey: settings.apiKey || '',
    }));
    const [currentProvider, setCurrentProvider] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [testResult, setTestResult] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const isTestingRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(false);
    const [hasChanges, setHasChanges] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [showApiKey, setShowApiKey] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isLoadingProviders, setIsLoadingProviders] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    // Fetch providers from backend on mount
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        const fetchProviders = async () => {
            try {
                const data = await apiService.getProviders();
                setProviders(data.providers || []);
            }
            catch (err) {
                console.error('Failed to fetch providers:', err);
                setProviders([]);
            }
            finally {
                setIsLoadingProviders(false);
            }
        };
        fetchProviders();
    }, []);
    // Update current provider when providers or endpoint changes
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (providers.length > 0 && localSettings.apiEndpoint) {
            const provider = getCurrentProvider(providers, localSettings.apiEndpoint);
            setCurrentProvider(provider);
        }
    }, [providers, localSettings.apiEndpoint]);
    // Update local settings when props change (preserve apiKey)
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        setLocalSettings((prev) => ({
            ...settings,
            apiKey: prev.apiKey, // Never overwrite user input
        }));
    }, [settings]);
    // Check for changes
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        const changed = JSON.stringify(localSettings) !== JSON.stringify(settings);
        setHasChanges(changed);
    }, [localSettings, settings]);
    // Handle input change
    const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((key, value) => {
        setLocalSettings((prev) => ({
            ...prev,
            [key]: value,
        }));
    }, []);
    // Handle provider change
    const handleProviderChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((providerId) => {
        const provider = providers.find(p => p.id === providerId);
        if (!provider)
            return;
        setCurrentProvider(provider);
        // Only update endpoint and provider info, preserve user's model choice
        setLocalSettings((prev) => ({
            ...prev,
            provider: provider.id,
            providerName: provider.name,
            apiEndpoint: provider.apiEndpoint,
            // Preserve user's custom model (do not override with default)
            model: prev.model,
            // Auto-enable/disable features based on provider capabilities
            enableStreaming: provider.enableStreaming ?? prev.enableStreaming,
            enableVision: provider.enableVision ?? prev.enableVision,
        }));
    }, [providers]);
    // Handle model change
    const handleModelChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((value) => {
        handleChange('model', value);
    }, [handleChange]);
    // Handle endpoint change
    const handleEndpointChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((value) => {
        setLocalSettings((prev) => ({
            ...prev,
            apiEndpoint: value,
        }));
        // If custom endpoint, clear current provider
        if (providers.length > 0) {
            const provider = getCurrentProvider(providers, value);
            setCurrentProvider(provider);
        }
    }, [providers]);
    // Handle save
    const handleSave = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
        onSettingsChange(localSettings);
        setHasChanges(false);
    }, [localSettings, onSettingsChange]);
    // Handle test connection
    const handleTestConnection = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async () => {
        if (isTestingRef.current)
            return;
        isTestingRef.current = true;
        setTestResult(null);
        try {
            const result = await onTestConnection();
            setTestResult(result);
        }
        catch (err) {
            setTestResult({
                success: false,
                error: err instanceof Error ? err.message : 'Connection test failed',
            });
        }
        finally {
            isTestingRef.current = false;
        }
    }, [onTestConnection]);
    // Check if API key is available
    const isApiKeyAvailable = localSettings.apiKey.trim().length > 0;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-panel", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", { children: "Settings" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-close-btn", onClick: onClose, title: "Close settings", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "18", height: "18", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-content", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", { className: "llm-section-title", children: "API Provider" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { htmlFor: "provider", children: "Select Provider" }), isLoadingProviders ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("select", { id: "provider", disabled: true, children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", { value: "", children: "Loading providers..." }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("select", { id: "provider", value: currentProvider?.id || '', onChange: (e) => handleProviderChange(e.target.value), children: providers.map((provider) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("option", { value: provider.id, children: provider.name }, provider.id))) }))] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { htmlFor: "apiEndpoint", children: "API Endpoint" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { id: "apiEndpoint", type: "text", value: localSettings.apiEndpoint, onChange: (e) => handleEndpointChange(e.target.value), placeholder: "https://api.openai.com/v1" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: "The base URL for the API endpoint" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { htmlFor: "apiKey", children: "API Key" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-input-with-button", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { id: "apiKey", type: showApiKey ? 'text' : 'password', value: localSettings.apiKey, onChange: (e) => handleChange('apiKey', e.target.value), placeholder: currentProvider?.id === 'ollama' ? 'any-value (Ollama local no auth)' : 'sk-...', className: "llm-api-key-input" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-toggle-visibility-btn", onClick: () => setShowApiKey(!showApiKey), title: showApiKey ? 'Hide API key' : 'Show API key', children: showApiKey ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "18", height: "18", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z" }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "18", height: "18", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z" }) })) })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: currentProvider?.id === 'ollama'
                                            ? 'Ollama 本地部署无需认证，填写任意值即可'
                                            : 'Enter your API key' })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", { className: "llm-section-title", children: "Model Configuration" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { htmlFor: "model", children: "Model Name" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { id: "model", type: "text", value: localSettings.model, onChange: (e) => handleModelChange(e.target.value), placeholder: currentProvider?.defaultModel || 'e.g., gpt-4o, llama3, qwen-turbo' }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: "Enter the model name supported by your API provider" })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", { className: "llm-section-title", children: "Generation Parameters" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", { htmlFor: "temperature", children: ["Temperature: ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-value", children: localSettings.temperature })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { id: "temperature", type: "range", min: "0", max: "2", step: "0.1", value: localSettings.temperature, onChange: (e) => handleChange('temperature', parseFloat(e.target.value)) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: "Higher values (0-2) produce more creative outputs" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { htmlFor: "maxTokens", children: "Max Tokens" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { id: "maxTokens", type: "number", min: "1", max: "128000", value: localSettings.maxTokens, onChange: (e) => handleChange('maxTokens', parseInt(e.target.value, 10)) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: "Maximum number of tokens in the response" })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", { className: "llm-section-title", children: "System Prompt" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", { id: "systemPrompt", value: localSettings.systemPrompt, onChange: (e) => handleChange('systemPrompt', e.target.value), rows: 4, placeholder: "You are a helpful AI coding assistant..." }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: "Instructions that define the assistant's behavior" })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", { className: "llm-section-title", children: "Features" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field llm-settings-toggle", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "checkbox", checked: localSettings.enableStreaming, onChange: (e) => handleChange('enableStreaming', e.target.checked) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "Enable streaming responses" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: "Stream responses in real-time" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-field llm-settings-toggle", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "checkbox", checked: localSettings.enableVision, onChange: (e) => handleChange('enableVision', e.target.checked) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: "Enable image input (Vision)" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-settings-hint", children: "Allow sending images to vision-capable models" })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-test-btn", onClick: handleTestConnection, disabled: isTestingConnection || !isApiKeyAvailable, children: isTestingConnection ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-spinner" }), "Testing..."] })) : ('Test Connection') }), testResult && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: `llm-test-result ${testResult.success ? 'llm-test-success' : 'llm-test-error'}`, children: testResult.success ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", { children: ["\u2713 Connection successful! Model: ", testResult.model] })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", { children: ["\u2717 Error: ", testResult.error] })) }))] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-settings-footer", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-cancel-btn", onClick: onClose, children: "Cancel" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-save-btn", onClick: handleSave, disabled: !hasChanges, children: "Save Changes" })] })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingsPanel);


/***/ },

/***/ "./lib/components/SkillPanel.js"
/*!**************************************!*\
  !*** ./lib/components/SkillPanel.js ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SkillPanel: () => (/* binding */ SkillPanel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api */ "./lib/services/api.js");

/**
 * SkillPanel — Skill management panel
 *
 * Displays a list of installed skills from .llm-assistant/skills/
 * Allows enabling, disabling, installing, and deleting skills.
 */


const _api = new _services_api__WEBPACK_IMPORTED_MODULE_2__.LLMApiService();
const SkillPanel = ({ onClose, rootDir, onRootDirChange, }) => {
    const [skills, setSkills] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [deletingName, setDeletingName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [updatingName, setUpdatingName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [showInstallForm, setShowInstallForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [installName, setInstallName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [installManifest, setInstallManifest] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [installUrl, setInstallUrl] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [installError, setInstallError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [installing, setInstalling] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [installMode, setInstallMode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('url');
    const [showRootDirEdit, setShowRootDirEdit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [rootDirInput, setRootDirInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(rootDir);
    const [selectedSkill, setSelectedSkill] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [editingPrompt, setEditingPrompt] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [promptInput, setPromptInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    // Marketplace state
    const [showMarketplace, setShowMarketplace] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [registries, setRegistries] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedRegistry, setSelectedRegistry] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [marketplaceSkills, setMarketplaceSkills] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [loadingMarketplace, setLoadingMarketplace] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [marketplaceError, setMarketplaceError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const loadSkills = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const data = await _api.listSkills(rootDir);
            const skills = data.map(s => ({
                ...s,
                type: s.type,
            }));
            setSkills(skills);
        }
        catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to load skills');
        }
        finally {
            setIsLoading(false);
        }
    }, [rootDir]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        loadSkills();
    }, [loadSkills]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        setRootDirInput(rootDir);
    }, [rootDir]);
    const handleToggleEnabled = async (skill, e) => {
        e.stopPropagation();
        setUpdatingName(skill.name);
        try {
            await _api.updateSkill(skill.name, { enabled: !skill.enabled }, rootDir);
            await loadSkills();
        }
        catch (err) {
            console.error('Failed to toggle skill:', err);
        }
        finally {
            setUpdatingName(null);
        }
    };
    const handleDelete = async (name, e) => {
        e.stopPropagation();
        if (!confirm(`Delete skill "${name}"? This cannot be undone.`)) {
            return;
        }
        setDeletingName(name);
        try {
            await _api.deleteSkill(name, rootDir);
            await loadSkills();
        }
        catch (err) {
            console.error('Failed to delete skill:', err);
        }
        finally {
            setDeletingName(null);
        }
    };
    const handleInstall = async () => {
        setInstalling(true);
        setInstallError(null);
        try {
            if (installMode === 'url') {
                // Install from URL (GitHub or raw)
                if (!installUrl.trim()) {
                    setInstallError('URL is required');
                    setInstalling(false);
                    return;
                }
                let url = installUrl.trim();
                // Handle GitHub shorthand: github:user/repo/skill-name
                if (url.startsWith('github:')) {
                    const parts = url.substring(7).split('/');
                    if (parts.length >= 3) {
                        const [user, repo, ...skillPath] = parts;
                        url = `https://github.com/${user}/${repo}/tree/main/${skillPath.join('/')}`;
                    }
                    else {
                        setInstallError('Invalid GitHub shorthand. Use: github:user/repo/skill-name');
                        setInstalling(false);
                        return;
                    }
                }
                const result = await _api.installSkillFromUrl(url, rootDir);
                setInstallUrl('');
                setShowInstallForm(false);
                await loadSkills();
            }
            else {
                // Install from YAML manifest
                if (!installName.trim()) {
                    setInstallError('Skill name is required');
                    setInstalling(false);
                    return;
                }
                // Parse the YAML manifest
                let manifest = {};
                try {
                    // Simple YAML parsing - in production you'd use a proper YAML parser
                    const lines = installManifest.split('\n');
                    let inSystemPrompt = false;
                    let systemPromptLines = [];
                    for (const line of lines) {
                        if (inSystemPrompt) {
                            if (line.match(/^\s{2,}/) || line.startsWith('\t')) {
                                systemPromptLines.push(line);
                            }
                            else if (line.trim() === '') {
                                inSystemPrompt = false;
                                manifest['system_prompt'] = systemPromptLines.join('\n').trim();
                            }
                            else {
                                inSystemPrompt = false;
                            }
                        }
                        const trimmed = line.trim();
                        if (trimmed.startsWith('name:')) {
                            manifest['name'] = trimmed.substring(5).trim().replace(/^["']|["']$/g, '');
                        }
                        else if (trimmed.startsWith('version:')) {
                            manifest['version'] = trimmed.substring(8).trim().replace(/^["']|["']$/g, '');
                        }
                        else if (trimmed.startsWith('description:')) {
                            manifest['description'] = trimmed.substring(12).trim().replace(/^["']|["']$/g, '');
                        }
                        else if (trimmed.startsWith('author:')) {
                            manifest['author'] = trimmed.substring(7).trim().replace(/^["']|["']$/g, '');
                        }
                        else if (trimmed.startsWith('system_prompt:')) {
                            const rest = trimmed.substring(14).trim();
                            if (rest === '|' || rest === '>' || rest === '|-' || rest === '>-') {
                                inSystemPrompt = true;
                                systemPromptLines = [];
                            }
                            else {
                                manifest['system_prompt'] = rest.replace(/^["']|["']$/g, '');
                            }
                        }
                        else if (trimmed.startsWith('enabled:')) {
                            manifest['enabled'] = trimmed.substring(8).trim().toLowerCase() === 'true';
                        }
                    }
                    if (inSystemPrompt && systemPromptLines.length > 0) {
                        manifest['system_prompt'] = systemPromptLines.join('\n').trim();
                    }
                    manifest['enabled'] = manifest['enabled'] !== false;
                }
                catch (parseErr) {
                    setInstallError('Invalid YAML format');
                    setInstalling(false);
                    return;
                }
                await _api.installSkill(installName.trim(), manifest, rootDir);
                setInstallName('');
                setInstallManifest('');
                setShowInstallForm(false);
                await loadSkills();
            }
        }
        catch (err) {
            setInstallError(err instanceof Error ? err.message : 'Failed to install skill');
        }
        finally {
            setInstalling(false);
        }
    };
    const handleRootDirSave = () => {
        if (onRootDirChange && rootDirInput !== rootDir) {
            onRootDirChange(rootDirInput);
        }
        setShowRootDirEdit(false);
    };
    const handleEditPrompt = (skill) => {
        setSelectedSkill(skill);
        setPromptInput(skill.systemPrompt || '');
        setEditingPrompt(skill.name);
    };
    const handleSavePrompt = async () => {
        if (!selectedSkill)
            return;
        setUpdatingName(selectedSkill.name);
        try {
            await _api.updateSkill(selectedSkill.name, { system_prompt: promptInput }, rootDir);
            setEditingPrompt(null);
            setSelectedSkill(null);
            await loadSkills();
        }
        catch (err) {
            console.error('Failed to save skill prompt:', err);
        }
        finally {
            setUpdatingName(null);
        }
    };
    const formatManifest = (manifest) => {
        let result = '';
        if (manifest.name)
            result += `name: ${manifest.name}\n`;
        if (manifest.version)
            result += `version: "${manifest.version}"\n`;
        if (manifest.description)
            result += `description: "${manifest.description}"\n`;
        if (manifest.author)
            result += `author: "${manifest.author}"\n`;
        if (manifest.system_prompt) {
            result += `system_prompt: |\n${manifest.system_prompt.split('\n').map((l) => '  ' + l).join('\n')}\n`;
        }
        result += `enabled: ${manifest.enabled !== false ? 'true' : 'false'}\n`;
        return result.trim();
    };
    // Marketplace handlers
    const loadRegistries = async () => {
        setLoadingMarketplace(true);
        setMarketplaceError(null);
        try {
            const regs = await _api.listRegistries();
            setRegistries(regs);
        }
        catch (err) {
            setMarketplaceError(err instanceof Error ? err.message : 'Failed to load registries');
        }
        finally {
            setLoadingMarketplace(false);
        }
    };
    const loadRegistrySkills = async (registryId) => {
        setSelectedRegistry(registryId);
        setLoadingMarketplace(true);
        setMarketplaceError(null);
        try {
            const data = await _api.getRegistrySkills(registryId);
            setMarketplaceSkills(data.skills);
        }
        catch (err) {
            setMarketplaceError(err instanceof Error ? err.message : 'Failed to load skills');
        }
        finally {
            setLoadingMarketplace(false);
        }
    };
    const handleInstallFromMarketplace = async (skill) => {
        setInstalling(true);
        setInstallError(null);
        try {
            // Use the URL to install the skill
            let url = skill.url;
            // Handle GitHub shorthand
            if (url.startsWith('github:')) {
                const parts = url.substring(7).split('/');
                if (parts.length >= 3) {
                    const [user, repo, ...skillPath] = parts;
                    url = `https://github.com/${user}/${repo}/tree/main/${skillPath.join('/')}`;
                }
            }
            await _api.installSkillFromUrl(skill.name, url, rootDir);
            await loadSkills();
            setShowMarketplace(false);
            setSelectedRegistry(null);
            setMarketplaceSkills([]);
        }
        catch (err) {
            setInstallError(err instanceof Error ? err.message : 'Failed to install skill');
        }
        finally {
            setInstalling(false);
        }
    };
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-panel", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", { children: "Skills" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-header-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: `llm-header-btn ${showMarketplace ? 'active' : ''}`, onClick: () => {
                                    setShowMarketplace(!showMarketplace);
                                    if (!showMarketplace && registries.length === 0) {
                                        loadRegistries();
                                    }
                                }, title: "Browse Marketplace", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-header-btn", onClick: () => setShowInstallForm(!showInstallForm), title: "Install Skill", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "17", height: "17", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-close-btn", onClick: onClose, title: "Close", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "18", height: "18", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-section", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-rootdir-label", children: "Project Directory" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-rootdir-edit-btn", onClick: () => setShowRootDirEdit(!showRootDirEdit), title: "Edit project directory", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" }) }) })] }), showRootDirEdit ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-edit", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "text", className: "llm-rootdir-input", value: rootDirInput, onChange: (e) => setRootDirInput(e.target.value), placeholder: "Enter project directory path...", onKeyDown: (e) => {
                                    if (e.key === 'Enter')
                                        handleRootDirSave();
                                    if (e.key === 'Escape')
                                        setShowRootDirEdit(false);
                                }, autoFocus: true }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-rootdir-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-rootdir-save", onClick: handleRootDirSave, children: "Save" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-rootdir-cancel", onClick: () => setShowRootDirEdit(false), children: "Cancel" })] })] })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-rootdir-path", title: rootDir, children: rootDir || 'Using current working directory' }))] }), showInstallForm && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-install-form", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h5", { children: "Install Skill" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-install-toggle", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: installMode === 'url' ? 'active' : '', onClick: () => setInstallMode('url'), children: "From URL / GitHub" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: installMode === 'yaml' ? 'active' : '', onClick: () => setInstallMode('yaml'), children: "From YAML" })] }), installMode === 'url' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-install-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { children: "GitHub URL or Raw URL" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "text", value: installUrl, onChange: (e) => setInstallUrl(e.target.value), placeholder: "https://github.com/user/repo/tree/main/skill-name" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", { className: "llm-settings-hint", children: ["Supports GitHub URLs, raw URLs, or shorthand: ", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("code", { children: "github:user/repo/skill" })] })] })), installMode === 'yaml' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-install-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { children: "Skill Name" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", { type: "text", value: installName, onChange: (e) => setInstallName(e.target.value), placeholder: "e.g., code-review, test-generator" })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-install-field", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { children: "YAML Manifest" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", { value: installManifest, onChange: (e) => setInstallManifest(e.target.value), placeholder: `name: my-skill
version: "1.0.0"
description: "Does something useful"
system_prompt: |
  You have access to special tools...
enabled: true`, rows: 8 })] })] })), installError && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-skill-install-error", children: installError }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-install-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-cancel-btn", onClick: () => {
                                    setShowInstallForm(false);
                                    setInstallName('');
                                    setInstallManifest('');
                                    setInstallUrl('');
                                    setInstallError(null);
                                }, children: "Cancel" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-save-btn", onClick: handleInstall, disabled: installing || (installMode === 'url' ? !installUrl.trim() : !installName.trim()), children: installing ? 'Installing...' : 'Install' })] })] })), showMarketplace && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-marketplace", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-marketplace-header", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h5", { children: "Skill Marketplace" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-marketplace-close", onClick: () => {
                                    setShowMarketplace(false);
                                    setSelectedRegistry(null);
                                    setMarketplaceSkills([]);
                                }, children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) }) })] }), loadingMarketplace && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-loading", children: "Loading marketplace..." }), marketplaceError && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-error", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: marketplaceError }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { onClick: loadRegistries, children: "Retry" })] })), !loadingMarketplace && !marketplaceError && !selectedRegistry && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-marketplace-registries", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-marketplace-hint", children: "Select a marketplace to browse skills:" }), registries.map((reg) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-registry-item", onClick: () => loadRegistrySkills(reg.id), children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-registry-name", children: reg.name }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-registry-desc", children: reg.description })] }, reg.id)))] })), !loadingMarketplace && !marketplaceError && selectedRegistry && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-marketplace-skills", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", { className: "llm-marketplace-back", onClick: () => {
                                    setSelectedRegistry(null);
                                    setMarketplaceSkills([]);
                                }, children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" }) }), "Back to marketplaces"] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-marketplace-skill-list", children: marketplaceSkills.length === 0 ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-marketplace-empty", children: "No skills found in this marketplace" })) : (marketplaceSkills.map((skill) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-marketplace-skill-item", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-marketplace-skill-info", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-marketplace-skill-name", children: [skill.name, skill.version && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "llm-skill-version", children: ["v", skill.version] }))] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-marketplace-skill-desc", children: skill.description }), skill.author && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-marketplace-skill-author", children: ["by ", skill.author] })), skill.tags && skill.tags.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-marketplace-skill-tags", children: skill.tags.map((tag) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-marketplace-tag", children: tag }, tag))) }))] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-marketplace-install-btn", onClick: () => handleInstallFromMarketplace(skill), disabled: installing, children: installing ? 'Installing...' : 'Install' })] }, skill.name)))) })] }))] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-content", children: [isLoading && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-loading", children: "Loading skills..." }), error && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-error", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { children: error }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { onClick: loadSkills, children: "Retry" })] })), !isLoading && !error && skills.length === 0 && !showInstallForm && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-empty", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { children: "No skills installed" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-hint", children: "Skills extend the assistant's capabilities" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-install-sample-btn", onClick: () => {
                                    setInstallName('example-skill');
                                    setInstallManifest(`name: example-skill
version: "1.0.0"
description: "An example skill demonstrating the skill system"
system_prompt: |
  You are an AI assistant with expertise in the example skill domain.
  When relevant, apply the following special instructions:
  - Consider best practices for the domain
  - Provide detailed explanations
enabled: true`);
                                    setShowInstallForm(true);
                                }, children: "Install Example Skill" })] })), !isLoading && !error && skills.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-skill-list", children: skills.map((skill) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: `llm-skill-item ${!skill.enabled ? 'llm-skill-disabled' : ''}`, onClick: () => setSelectedSkill(selectedSkill?.name === skill.name ? null : skill), children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-info", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-name", children: [skill.name, skill.version && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "llm-skill-version", children: ["v", skill.version] }))] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-meta", children: [skill.description && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-skill-description", children: skill.description })), skill.author && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "llm-skill-author", children: ["by ", skill.author] }))] })] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: `llm-skill-toggle ${skill.enabled ? 'llm-enabled' : 'llm-disabled'}`, onClick: (e) => handleToggleEnabled(skill, e), disabled: updatingName === skill.name, title: skill.enabled ? 'Disable skill' : 'Enable skill', children: updatingName === skill.name ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-spinner" })) : skill.enabled ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }) })) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-skill-delete", onClick: (e) => handleDelete(skill.name, e), disabled: deletingName === skill.name, title: "Delete skill", children: deletingName === skill.name ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-spinner" })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "16", height: "16", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" }) })) })] })] }, skill.name))) })), selectedSkill && editingPrompt !== selectedSkill.name && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-detail", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h5", { children: selectedSkill.name }), selectedSkill.description && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-skill-detail-desc", children: selectedSkill.description })), selectedSkill.systemPrompt && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-detail-prompt", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("label", { children: "System Prompt" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("pre", { className: "llm-skill-prompt-preview", children: selectedSkill.systemPrompt })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-skill-detail-actions", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-edit-prompt-btn", onClick: () => handleEditPrompt(selectedSkill), children: "Edit System Prompt" }) })] })), editingPrompt && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-edit-prompt", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", { children: ["Edit System Prompt: ", selectedSkill?.name] }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("textarea", { value: promptInput, onChange: (e) => setPromptInput(e.target.value), rows: 10, placeholder: "Enter the system prompt for this skill..." }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-skill-edit-actions", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-cancel-btn", onClick: () => {
                                            setEditingPrompt(null);
                                            setSelectedSkill(null);
                                            setPromptInput('');
                                        }, children: "Cancel" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", { className: "llm-save-btn", onClick: handleSavePrompt, disabled: updatingName !== null, children: updatingName ? 'Saving...' : 'Save' })] })] }))] })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SkillPanel);


/***/ },

/***/ "./lib/components/ToolCallDisplay.js"
/*!*******************************************!*\
  !*** ./lib/components/ToolCallDisplay.js ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ToolCallDisplay: () => (/* binding */ ToolCallDisplay),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

/**
 * ToolCallDisplay component.
 *
 * Shows a single tool call with its arguments and result,
 * collapsible, styled like Claude Code's tool execution view.
 */

/**
 * Icon for each tool
 */
function ToolIcon({ name }) {
    const icons = {
        read_file: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11z" }) })),
        write_file: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" }) })),
        edit_file: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M14.06 9.02l.92.92L5.92 19H5v-.92l9.06-9.06M17.66 3c-.25 0-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29zm-3.6 3.19L3 17.25V21h3.75L14.06 9.94l-3.75-3.75z" }) })),
        bash: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8h16v10zM6 9.5l1.5 1.5L6 12.5l1 1 2.5-2.5L7 8.5 6 9.5zm5 4h6v-1.5h-6V13.5z" }) })),
        notebook_execute: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M8 5v14l11-7z" }) })),
        list_dir: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z" }) })),
        grep_search: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "14", height: "14", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" }) })),
    };
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "agent-tool-icon", children: icons[name] || icons['bash'] });
}
/**
 * Human-readable label for tool name
 */
function toolLabel(name, args) {
    switch (name) {
        case 'read_file':
            return `Read ${args.path || 'file'}`;
        case 'write_file':
            return `Write ${args.path || 'file'}`;
        case 'edit_file':
            return `Edit ${args.path || 'file'}`;
        case 'bash':
            return `Run: ${(args.command || '').slice(0, 60)}${(args.command || '').length > 60 ? '…' : ''}`;
        case 'notebook_execute':
            return `Execute: ${(args.code || '').split('\n')[0].slice(0, 55)}${(args.code || '').length > 55 ? '…' : ''}`;
        case 'list_dir':
            return `List ${args.path || '.'}`;
        case 'grep_search':
            return `Search "${args.pattern || ''}"${args.path ? ` in ${args.path}` : ''}`;
        default:
            return name;
    }
}
/**
 * Status indicator dot
 */
function StatusDot({ status }) {
    const colors = {
        pending: '#888',
        running: '#f0a500',
        success: '#22c55e',
        error: '#ef4444',
    };
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: `agent-tool-status agent-tool-status-${status}`, style: { backgroundColor: colors[status] } }));
}
/**
 * Format args as a compact summary
 */
function ArgsSummary({ name, args }) {
    if (name === 'write_file') {
        const lines = (args.content || '').split('\n').length;
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "agent-tool-args", children: [args.path, " (", lines, " lines)"] });
    }
    if (name === 'edit_file') {
        const preview = (args.old_str || '').split('\n')[0].slice(0, 50);
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "agent-tool-args", children: [args.path, " \u00B7 replace: \"", preview, (args.old_str || '').length > 50 ? '…' : '', "\""] });
    }
    if (name === 'bash') {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("code", { className: "agent-tool-args-code", children: args.command });
    }
    if (name === 'notebook_execute') {
        return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("code", { className: "agent-tool-args-code", children: [(args.code || '').slice(0, 120), (args.code || '').length > 120 ? '\n…' : ''] });
    }
    const primary = args.path || args.pattern || '';
    return primary ? (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "agent-tool-args", children: primary }) : null;
}
const ToolCallDisplay = ({ entry }) => {
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(() => {
        // Auto-expand on error, otherwise collapse by default
        return entry.result ? !entry.result.success : false;
    });
    const duration = entry.endTime
        ? ((entry.endTime - entry.startTime) / 1000).toFixed(1)
        : null;
    const hasOutput = !!entry.result?.output;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: `agent-tool-call agent-tool-call-${entry.status}`, children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", { className: "agent-tool-header", onClick: () => hasOutput && setExpanded(v => !v), disabled: !hasOutput, title: hasOutput ? 'Click to expand/collapse' : undefined, children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(StatusDot, { status: entry.status }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ToolIcon, { name: entry.name }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "agent-tool-label", children: toolLabel(entry.name, entry.args) }), duration && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "agent-tool-duration", children: [duration, "s"] }), entry.status === 'running' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "agent-tool-spinner", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "12", height: "12", fill: "currentColor", className: "agent-spinning", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 4V2C6.48 2 2 6.48 2 12h2c0-4.41 3.59-8 8-8z" }) }) })), hasOutput && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "agent-tool-chevron", children: expanded ? '▲' : '▼' }))] }), entry.name !== 'bash' && entry.name !== 'notebook_execute' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "agent-tool-args-row", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ArgsSummary, { name: entry.name, args: entry.args }) })), (entry.name === 'bash' || entry.name === 'notebook_execute') && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "agent-tool-args-row", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ArgsSummary, { name: entry.name, args: entry.args }) })), expanded && entry.result && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: `agent-tool-output ${entry.result.success ? '' : 'agent-tool-output-error'}`, children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("pre", { children: entry.result.output }) }))] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ToolCallDisplay);


/***/ },

/***/ "./lib/components/UnifiedMessageList.js"
/*!**********************************************!*\
  !*** ./lib/components/UnifiedMessageList.js ***!
  \**********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UnifiedMessageList: () => (/* binding */ UnifiedMessageList),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _MarkdownRenderer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MarkdownRenderer */ "./lib/components/MarkdownRenderer.js");
/* harmony import */ var _ToolCallDisplay__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToolCallDisplay */ "./lib/components/ToolCallDisplay.js");

/**
 * UnifiedMessageList — Renders all messages in a unified stream.
 *
 * Message types:
 * - chat: Simple text + images
 * - agent: Text with inline tool call visualization + iteration indicator
 */



// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString(undefined, {
        hour: '2-digit',
        minute: '2-digit',
    });
}
const ChatMessageContent = ({ message }) => {
    const isStreaming = message.isStreaming;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-text", children: message.content ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_MarkdownRenderer__WEBPACK_IMPORTED_MODULE_2__.MarkdownRenderer, { content: message.content })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-message-placeholder", children: isStreaming ? '...' : 'Empty response' })) }));
};
const AgentMessageContent = ({ message }) => {
    const [showToolCalls, setShowToolCalls] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const hasToolCalls = message.toolCalls && message.toolCalls.length > 0;
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-message-agent-content", children: [message.content && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-text", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_MarkdownRenderer__WEBPACK_IMPORTED_MODULE_2__.MarkdownRenderer, { content: message.content }) })), message.iteration && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-iteration", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", { className: `llm-iteration-badge ${message.isStreaming ? 'llm-iteration-active' : 'llm-iteration-complete'}`, onClick: () => hasToolCalls && setShowToolCalls(v => !v), disabled: !hasToolCalls, title: hasToolCalls ? (showToolCalls ? '点击折叠工具调用' : '点击展开工具调用') : undefined, children: [message.isStreaming ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: ["Thinking... (", message.iteration.current, "/", message.iteration.max, ")"] })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, { children: ["Completed in ", message.iteration.current, " iterations"] })), hasToolCalls && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-iteration-chevron", children: showToolCalls ? '▲' : '▼' }))] }) })), hasToolCalls && showToolCalls && message.toolCalls && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-tool-calls", children: message.toolCalls.map((toolCall) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_ToolCallDisplay__WEBPACK_IMPORTED_MODULE_3__.ToolCallDisplay, { entry: {
                        id: toolCall.id,
                        name: toolCall.name,
                        args: toolCall.args,
                        status: toolCall.status,
                        result: toolCall.result ? {
                            id: toolCall.id,
                            name: toolCall.name,
                            success: toolCall.result.success,
                            output: toolCall.result.output,
                        } : undefined,
                        startTime: toolCall.startTime || Date.now(),
                        endTime: toolCall.endTime,
                    } }, toolCall.id))) }))] }));
};
const UnifiedMessageItem = ({ message, }) => {
    const isUser = message.role === 'user';
    const isAssistant = message.role === 'assistant';
    // Mode badge for assistant messages
    const ModeBadge = () => {
        if (isUser)
            return null;
        const labels = {
            chat: 'Chat',
            agent: 'Agent',
        };
        const icons = {
            chat: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "12", height: "12", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z" }) })),
            agent: ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "12", height: "12", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z" }) })),
        };
        return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: `llm-mode-badge llm-mode-badge-${message.mode}`, children: [icons[message.mode], labels[message.mode]] }));
    };
    // Render content based on mode
    const renderContent = () => {
        switch (message.mode) {
            case 'chat':
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ChatMessageContent, { message: message });
            case 'agent':
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AgentMessageContent, { message: message });
            default:
                return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ChatMessageContent, { message: message });
        }
    };
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: `llm-message-item llm-message-${message.role}`, children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-avatar", children: isUser ? ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "20", height: "20", fill: "currentColor", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" }) })) : ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", { viewBox: "0 0 24 24", width: "20", height: "20", fill: "currentColor", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z" })] })) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-message-content", children: [isUser && message.images && message.images.length > 0 && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-images", children: message.images.map((img, index) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", { src: img.dataUrl, alt: `Attached image ${index + 1}`, className: "llm-message-image" }, index))) })), renderContent(), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-message-meta", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-message-time", children: formatTimestamp(message.timestamp) }), isAssistant && (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ModeBadge, {}), message.isStreaming && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "llm-message-streaming", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-streaming-dot" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-streaming-dot" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-streaming-dot" })] })), message.error && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", { className: "llm-message-error", children: message.error }))] })] })] }));
};
// ─── Main Component ───────────────────────────────────────────────────────────
const UnifiedMessageList = ({ messages, isLoading, }) => {
    const scrollRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const bottomRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // Auto-scroll to bottom when messages change or during streaming
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (bottomRef.current) {
            bottomRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [messages]);
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-message-list", ref: scrollRef, children: [messages.length === 0 && !isLoading && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-empty-state", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-empty-icon", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { viewBox: "0 0 24 24", width: "48", height: "48", fill: "currentColor", opacity: "0.3", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z" }) }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", { className: "llm-empty-title", children: "Start a conversation" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", { className: "llm-empty-hint", children: ["Select a mode (Chat or Agent) and send a message.", (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("br", {}), "Use @ to reference files and directories."] })] })), messages.map((message) => ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(UnifiedMessageItem, { message: message }, message.id))), isLoading && messages.length > 0 && messages[messages.length - 1]?.role === 'user' && ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", { className: "llm-message-item llm-message-assistant llm-message-loading", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-avatar", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", { viewBox: "0 0 24 24", width: "20", height: "20", fill: "currentColor", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z" })] }) }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-content", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { className: "llm-message-text", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", { className: "llm-thinking-dots", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {}), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {}), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {})] }) }) })] })), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { ref: bottomRef })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UnifiedMessageList);


/***/ },

/***/ "./lib/components/icons.js"
/*!*********************************!*\
  !*** ./lib/components/icons.js ***!
  \*********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   chatIcon: () => (/* binding */ chatIcon),
/* harmony export */   checkIcon: () => (/* binding */ checkIcon),
/* harmony export */   clearIcon: () => (/* binding */ clearIcon),
/* harmony export */   copyIcon: () => (/* binding */ copyIcon),
/* harmony export */   imageIcon: () => (/* binding */ imageIcon),
/* harmony export */   sendIcon: () => (/* binding */ sendIcon),
/* harmony export */   settingsIcon: () => (/* binding */ settingsIcon),
/* harmony export */   spinnerIcon: () => (/* binding */ spinnerIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/**
 * Icons for the LLM Assistant extension.
 */

// Chat icon (SVG path)
const chatIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z"/>
  <path fill="currentColor" d="M7 9h2v2H7zm4 0h2v2h-2zm4 0h2v2h-2z"/>
</svg>`;
// Settings icon
const settingsIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>
</svg>`;
// Send icon
const sendIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
</svg>`;
// Clear icon
const clearIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
</svg>`;
// Image icon
const imageIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/>
</svg>`;
// Copy icon
const copyIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
</svg>`;
// Check icon
const checkIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
</svg>`;
// Spinner icon
const spinnerIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z" opacity="0.3"/>
  <path fill="currentColor" d="M12 4V2C6.48 2 2 6.48 2 12h2c0-4.42 3.58-8 8-8z"/>
</svg>`;
// Export icons
const chatIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:chat',
    svgstr: chatIconSvg,
});
const settingsIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:settings',
    svgstr: settingsIconSvg,
});
const sendIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:send',
    svgstr: sendIconSvg,
});
const clearIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:clear',
    svgstr: clearIconSvg,
});
const imageIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:image',
    svgstr: imageIconSvg,
});
const copyIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:copy',
    svgstr: copyIconSvg,
});
const checkIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:check',
    svgstr: checkIconSvg,
});
const spinnerIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'llm-assistant:spinner',
    svgstr: spinnerIconSvg,
});


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatModel: () => (/* reexport safe */ _models_chat__WEBPACK_IMPORTED_MODULE_5__.ChatModel),
/* harmony export */   LLMApiService: () => (/* reexport safe */ _services_api__WEBPACK_IMPORTED_MODULE_7__.LLMApiService),
/* harmony export */   LLMAssistantPanel: () => (/* reexport safe */ _widgets_LLMAssistantPanel__WEBPACK_IMPORTED_MODULE_4__.LLMAssistantPanel),
/* harmony export */   SettingsModel: () => (/* reexport safe */ _models_settings__WEBPACK_IMPORTED_MODULE_6__.SettingsModel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/icons */ "./lib/components/icons.js");
/* harmony import */ var _widgets_LLMAssistantPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./widgets/LLMAssistantPanel */ "./lib/widgets/LLMAssistantPanel.js");
/* harmony import */ var _models_chat__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./models/chat */ "./lib/models/chat.js");
/* harmony import */ var _models_settings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./models/settings */ "./lib/models/settings.js");
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/api */ "./lib/services/api.js");
/**
 * JupyterLab LLM Assistant Extension
 *
 * Main entry point for the extension.
 */





/**
 * The extension ID
 */
const PLUGIN_ID = 'jupyterlab-llm-assistant:plugin';
/**
 * The command IDs
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.openAssistant = 'llm-assistant:open';
    CommandIDs.clearChat = 'llm-assistant:clear';
    CommandIDs.openAgent = 'llm-assistant:open-agent';
})(CommandIDs || (CommandIDs = {}));
/**
 * The JupyterLab plugin
 */
const plugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__.ISettingRegistry],
    optional: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.ICommandPalette, _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__.ILayoutRestorer],
    activate: activatePlugin,
};
/**
 * Activate the plugin
 */
async function activatePlugin(app, settingRegistry, palette, restorer) {
    console.log('JupyterLab LLM Assistant extension is activated!');
    // Create the sidebar panel
    const panel = new _widgets_LLMAssistantPanel__WEBPACK_IMPORTED_MODULE_4__.LLMAssistantPanel();
    panel.id = 'llm-assistant-panel';
    panel.title.icon = _components_icons__WEBPACK_IMPORTED_MODULE_3__.chatIcon;
    panel.title.caption = 'LLM Assistant';
    // Load settings
    let settings = {
        apiEndpoint: 'https://api.openai.com/v1',
        apiKey: '',
        model: 'gpt-4o',
        temperature: 0.7,
        maxTokens: 4096,
        systemPrompt: 'You are a helpful AI coding assistant. Help users with programming questions, explain code, debug issues, and provide code examples. Be concise and accurate.',
        enableStreaming: true,
        enableVision: true,
    };
    try {
        const settingValues = await settingRegistry.load(PLUGIN_ID);
        settings = {
            ...settings,
            ...settingValues.composite,
        };
        // Listen for settings changes
        settingRegistry.pluginChanged.connect(async () => {
            const newSettings = await settingRegistry.load(PLUGIN_ID);
            settings = {
                ...settings,
                ...newSettings.composite,
            };
        });
    }
    catch (error) {
        console.warn('Failed to load settings, using defaults:', error);
    }
    // Add to right sidebar
    app.shell.add(panel, 'right', { rank: 100 });
    // Restore panel state
    if (restorer) {
        restorer.add(panel, 'llm-assistant-panel');
    }
    // Add commands
    app.commands.addCommand(CommandIDs.openAssistant, {
        label: 'Open LLM Assistant',
        icon: _components_icons__WEBPACK_IMPORTED_MODULE_3__.chatIcon,
        execute: () => {
            app.shell.activateById(panel.id);
        },
    });
    app.commands.addCommand(CommandIDs.clearChat, {
        label: 'Clear LLM Assistant Chat',
        execute: () => {
            // This will be handled by the panel
            panel.node.dispatchEvent(new CustomEvent('llm-clear-chat'));
        },
    });
    app.commands.addCommand(CommandIDs.openAgent, {
        label: 'Open Coding Agent',
        execute: () => {
            app.shell.activateById(panel.id);
        },
    });
    // Add to command palette
    if (palette) {
        palette.addItem({
            command: CommandIDs.openAssistant,
            category: 'LLM Assistant',
        });
        palette.addItem({
            command: CommandIDs.openAgent,
            category: 'LLM Assistant',
        });
    }
    console.log('JupyterLab LLM Assistant extension activated successfully!');
}
/**
 * Export the plugin
 */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);
/**
 * Export components and models for external use
 */






/***/ },

/***/ "./lib/models/chat.js"
/*!****************************!*\
  !*** ./lib/models/chat.js ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatModel: () => (/* binding */ ChatModel)
/* harmony export */ });
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/api */ "./lib/services/api.js");
/**
 * Chat model for managing chat state.
 */


/**
 * Generate a unique ID
 */
function generateId() {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
/**
 * Chat model class
 */
class ChatModel {
    constructor(settings) {
        this._messages = [];
        this._isLoading = false;
        this._error = null;
        /**
         * Signal emitted when messages change
         */
        this.messagesChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
        /**
         * Signal emitted when loading state changes
         */
        this.loadingChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
        /**
         * Signal emitted when error changes
         */
        this.errorChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
        this._settings = settings;
        this._apiService = new _services_api__WEBPACK_IMPORTED_MODULE_1__.LLMApiService();
    }
    /**
     * Get all messages
     */
    get messages() {
        return this._messages;
    }
    /**
     * Get loading state
     */
    get isLoading() {
        return this._isLoading;
    }
    /**
     * Get current error
     */
    get error() {
        return this._error;
    }
    /**
     * Get current settings
     */
    get settings() {
        return this._settings;
    }
    /**
     * Update settings
     */
    updateSettings(settings) {
        this._settings = { ...this._settings, ...settings };
    }
    /**
     * Add a user message
     */
    addUserMessage(text, images) {
        const message = {
            id: generateId(),
            role: 'user',
            content: text,
            timestamp: Date.now(),
        };
        this._messages = [...this._messages, message];
        this.messagesChanged.emit(this._messages);
        // Process images if provided and vision is enabled
        if (images && images.length > 0 && this._settings.enableVision) {
            // Images will be sent separately to the API
            // For now, just store the text message
        }
        return message;
    }
    /**
     * Add an assistant message
     */
    addAssistantMessage(content = '', isStreaming = false) {
        const message = {
            id: generateId(),
            role: 'assistant',
            content,
            timestamp: Date.now(),
            isStreaming,
        };
        this._messages = [...this._messages, message];
        this.messagesChanged.emit(this._messages);
        return message;
    }
    /**
     * Update an existing message
     */
    updateMessage(id, updates) {
        this._messages = this._messages.map(msg => msg.id === id ? { ...msg, ...updates } : msg);
        this.messagesChanged.emit(this._messages);
    }
    /**
     * Append content to the last assistant message
     */
    appendToLastAssistant(content) {
        const messages = [...this._messages];
        for (let i = messages.length - 1; i >= 0; i--) {
            if (messages[i].role === 'assistant') {
                const currentContent = messages[i].content;
                messages[i] = {
                    ...messages[i],
                    content: typeof currentContent === 'string'
                        ? currentContent + content
                        : currentContent,
                };
                break;
            }
        }
        this._messages = messages;
        this.messagesChanged.emit(this._messages);
    }
    /**
     * Set loading state
     */
    setLoading(loading) {
        this._isLoading = loading;
        this.loadingChanged.emit(loading);
    }
    /**
     * Set error
     */
    setError(error) {
        this._error = error;
        this.errorChanged.emit(error);
    }
    /**
     * Clear all messages
     */
    clearMessages() {
        this._messages = [];
        this._error = null;
        this.messagesChanged.emit(this._messages);
        this.errorChanged.emit(null);
    }
    /**
     * Send a message and get a response.
     *
     * @param text         The user's message text
     * @param images       Optional images to attach
     * @param contextText  Optional context block (file contents) to prepend on the first user turn
     */
    async sendMessage(text, images = [], contextText) {
        // Add user message (displayed as-is)
        this.addUserMessage(text, images);
        // Set loading state
        this.setLoading(true);
        this.setError(null);
        // Prepare messages for API.
        // If contextText is provided and this is the FIRST user turn (only the message we just
        // added exists), prepend the context block to the content so the LLM sees it.
        const isFirstTurn = this._messages.filter(m => m.role === 'user').length === 1;
        const apiMessages = this._messages
            .filter(msg => msg.role !== 'system')
            .map(msg => {
            if (isFirstTurn &&
                contextText &&
                msg.role === 'user' &&
                typeof msg.content === 'string' &&
                msg.content === text) {
                return {
                    role: msg.role,
                    content: `${contextText}\n\n---\n\n${msg.content}`,
                };
            }
            return {
                role: msg.role,
                content: msg.content,
            };
        });
        // Extract image data URLs
        const imageDataUrls = images.map(img => img.dataUrl);
        try {
            if (this._settings.enableStreaming) {
                // Create assistant message placeholder
                const assistantMsg = this.addAssistantMessage('', true);
                // Stream response
                await this._apiService.streamChat(apiMessages, imageDataUrls.length > 0 ? imageDataUrls : undefined, (chunk) => {
                    this.appendToLastAssistant(chunk);
                }, this._settings);
                // Mark streaming complete
                this.updateMessage(assistantMsg.id, { isStreaming: false });
            }
            else {
                // Non-streaming response
                const response = await this._apiService.chat(apiMessages, imageDataUrls.length > 0 ? imageDataUrls : undefined, this._settings);
                this.addAssistantMessage(response.content);
            }
        }
        catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An error occurred';
            this.setError(errorMessage);
            // Add error message
            this.addAssistantMessage(`Error: ${errorMessage}`);
            this.updateMessage(this._messages[this._messages.length - 1].id, {
                error: errorMessage
            });
        }
        finally {
            this.setLoading(false);
        }
    }
    /**
     * Clear chat history
     */
    clear() {
        this.clearMessages();
    }
}


/***/ },

/***/ "./lib/models/settings.js"
/*!********************************!*\
  !*** ./lib/models/settings.js ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_SETTINGS: () => (/* binding */ DEFAULT_SETTINGS),
/* harmony export */   SettingsModel: () => (/* binding */ SettingsModel)
/* harmony export */ });
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/api */ "./lib/services/api.js");
/**
 * Settings model for managing LLM settings.
 *
 * Uses user-level config (~/.llm-assistant/config.json) for persistence.
 * Project-level overrides (.llm-assistant/config.json) are handled separately.
 */


/**
 * Default settings
 */
const DEFAULT_SETTINGS = {
    apiEndpoint: 'https://api.openai.com/v1',
    apiKey: '',
    model: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 4096,
    systemPrompt: 'You are a helpful AI coding assistant. Help users with programming questions, explain code, debug issues, and provide code examples. Be concise and accurate.',
    enableStreaming: true,
    enableVision: true,
};
/**
 * Settings model class
 */
class SettingsModel {
    constructor(initialSettings) {
        /**
         * Signal emitted when settings change
         */
        this.settingsChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
        this._settings = { ...DEFAULT_SETTINGS, ...initialSettings };
        this._apiService = new _services_api__WEBPACK_IMPORTED_MODULE_1__.LLMApiService();
    }
    /**
     * Get current settings
     */
    get settings() {
        return { ...this._settings };
    }
    /**
     * Update settings locally (without persisting)
     */
    updateSettings(updates) {
        this._settings = { ...this._settings, ...updates };
        this.settingsChanged.emit(this._settings);
    }
    /**
     * Load settings from user-level config (~/.llm-assistant/config.json)
     */
    async loadSettings() {
        try {
            const serverConfig = await this._apiService.getConfig();
            console.log('[SettingsModel] Loaded from server:', JSON.stringify(serverConfig, null, 2));
            // Only use systemPrompt if it's non-empty, otherwise keep DEFAULT_SETTINGS
            const effectiveSystemPrompt = serverConfig.systemPrompt || DEFAULT_SETTINGS.systemPrompt;
            this._settings = {
                ...DEFAULT_SETTINGS,
                ...serverConfig,
                systemPrompt: effectiveSystemPrompt,
                // Don't load apiKey from server (security - it returns empty string)
                apiKey: '',
            };
            console.log('[SettingsModel] Merged settings:', JSON.stringify(this._settings, null, 2));
            return this._settings;
        }
        catch (err) {
            console.error('Failed to load settings:', err);
            return this._settings;
        }
    }
    /**
     * Save settings to user-level config (~/.llm-assistant/config.json)
     */
    async saveSettings(settings) {
        try {
            // Don't save empty apiKey to avoid overwriting existing key on server
            const settingsToSave = {};
            for (const [key, value] of Object.entries(settings)) {
                if (key === 'apiKey' && (!value || value === '')) {
                    // Skip empty apiKey to preserve existing key on server
                    continue;
                }
                settingsToSave[key] = value;
            }
            await this._apiService.setConfig(settingsToSave);
            this._settings = { ...this._settings, ...settings };
            this.settingsChanged.emit(this._settings);
        }
        catch (err) {
            console.error('Failed to save settings:', err);
            throw err;
        }
    }
    /**
     * Test connection
     */
    async testConnection() {
        return this._apiService.testConnection();
    }
    /**
     * Get available models
     */
    async getModels() {
        return this._apiService.getModels();
    }
}


/***/ },

/***/ "./lib/services/api.js"
/*!*****************************!*\
  !*** ./lib/services/api.js ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LLMApiService: () => (/* binding */ LLMApiService)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/**
 * API service for communicating with the backend.
 */

/**
 * Get XSRF token from cookie
 */
function getXsrfToken() {
    const cookie = document.cookie
        .split(';')
        .find(c => c.trim().startsWith('_xsrf='));
    return cookie ? decodeURIComponent(cookie.split('=')[1]) : '';
}
/**
 * Get base headers for API requests
 */
function getHeaders() {
    return {
        'Content-Type': 'application/json',
        'X-XSRFToken': getXsrfToken(),
    };
}
/**
 * LLM API Service
 */
class LLMApiService {
    constructor() {
        // PageConfig.getOption('baseUrl') reads the raw 'baseUrl' value injected by
        // the Jupyter server into the page (e.g. "/" or "/jupyter/").
        // This is the server root, NOT the app UI route (which would include /lab/tree/).
        // Using getBaseUrl() or window.__jupyter_server_root_url can return wrong paths.
        const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getOption('baseUrl') || '/';
        this.baseUrl = serverRoot.replace(/\/$/, '') + '/llm-assistant';
    }
    /**
     * Get current configuration
     */
    async getConfig() {
        const response = await fetch(`${this.baseUrl}/config`, {
            method: 'GET',
            headers: getHeaders(),
        });
        if (!response.ok) {
            throw new Error(`Failed to get config: ${response.statusText}`);
        }
        return response.json();
    }
    /**
     * Set configuration - sends partial settings directly (backend merges with current)
     */
    async setConfig(settings) {
        const response = await fetch(`${this.baseUrl}/config`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify(settings),
        });
        if (!response.ok) {
            throw new Error(`Failed to set config: ${response.statusText}`);
        }
    }
    /**
     * Send a chat request (non-streaming)
     */
    async chat(messages, images, settings, signal) {
        const response = await fetch(`${this.baseUrl}/chat`, {
            method: 'POST',
            headers: getHeaders(),
            signal,
            body: JSON.stringify({
                messages,
                images,
                stream: false,
                ...settings && {
                    model: settings.model,
                    temperature: settings.temperature,
                    maxTokens: settings.maxTokens,
                },
            }),
        });
        if (!response.ok) {
            const error = await response.json().catch(() => ({ error: response.statusText }));
            throw new Error(error.error || `Request failed: ${response.statusText}`);
        }
        return response.json();
    }
    /**
     * Send a streaming chat request
     */
    async streamChat(messages, images, onChunk, settings, signal) {
        const response = await fetch(`${this.baseUrl}/chat`, {
            method: 'POST',
            headers: getHeaders(),
            signal,
            body: JSON.stringify({
                messages,
                images,
                stream: true,
                ...settings && {
                    model: settings.model,
                    temperature: settings.temperature,
                    maxTokens: settings.maxTokens,
                },
            }),
        });
        if (!response.ok) {
            const error = await response.json().catch(() => ({ error: response.statusText }));
            throw new Error(error.error || `Request failed: ${response.statusText}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('No response body');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) {
                    break;
                }
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const data = line.slice(6);
                        if (data === '[DONE]') {
                            return;
                        }
                        try {
                            const parsed = JSON.parse(data);
                            if (parsed.error) {
                                throw new Error(parsed.error);
                            }
                            if (parsed.content) {
                                onChunk(parsed.content);
                            }
                        }
                        catch (e) {
                            // Skip invalid JSON
                            if (e instanceof SyntaxError) {
                                continue;
                            }
                            throw e;
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
        }
    }
    /**
     * Test the API connection
     */
    async testConnection() {
        const response = await fetch(`${this.baseUrl}/test`, {
            method: 'GET',
            headers: getHeaders(),
        });
        if (!response.ok) {
            throw new Error(`Test failed: ${response.statusText}`);
        }
        return response.json();
    }
    /**
     * Get available models
     */
    async getModels() {
        const response = await fetch(`${this.baseUrl}/models`, {
            method: 'GET',
            headers: getHeaders(),
        });
        if (!response.ok) {
            throw new Error(`Failed to get models: ${response.statusText}`);
        }
        return response.json();
    }
    /**
     * Get available providers
     */
    async getProviders() {
        const response = await fetch(`${this.baseUrl}/providers`, {
            method: 'GET',
            headers: getHeaders(),
        });
        if (!response.ok) {
            throw new Error(`Failed to get providers: ${response.statusText}`);
        }
        return response.json();
    }
    /**
     * Run the coding agent with streaming SSE
     *
     * Events are streamed as: data: {"type": "...", "data": {...}}
     *
     * @param messages  Conversation history (user/assistant turns)
     * @param onEvent   Callback for each parsed SSE event
     * @param rootDir   Optional working directory for file tools
     */
    async runAgent(messages, onEvent, rootDir, settings, maxIterations, signal) {
        const response = await fetch(`${this.baseUrl}/agent`, {
            method: 'POST',
            headers: getHeaders(),
            signal,
            body: JSON.stringify({
                messages,
                rootDir,
                maxIterations: maxIterations ?? 50,
                ...settings && {
                    model: settings.model,
                    temperature: settings.temperature,
                    maxTokens: settings.maxTokens,
                },
            }),
        });
        if (!response.ok) {
            const error = await response.json().catch(() => ({ error: response.statusText }));
            throw new Error(error.error || `Agent request failed: ${response.statusText}`);
        }
        await this._readSSEStream(response, onEvent);
    }
    // ── Memory API ────────────────────────────────────────────────────────────
    /**
     * List all memory entries
     */
    async listMemories() {
        const r = await fetch(`${this.baseUrl}/memory`, { headers: getHeaders() });
        if (!r.ok)
            throw new Error(`Failed to list memories: ${r.statusText}`);
        const d = await r.json();
        return d.memories ?? [];
    }
    /**
     * Create a new memory entry
     */
    async createMemory(title, content, tags = []) {
        const r = await fetch(`${this.baseUrl}/memory`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ title, content, tags }),
        });
        if (!r.ok)
            throw new Error(`Failed to create memory: ${r.statusText}`);
        return r.json();
    }
    /**
     * Update an existing memory entry
     */
    async updateMemory(id, patch) {
        const r = await fetch(`${this.baseUrl}/memory/${id}`, {
            method: 'PUT',
            headers: getHeaders(),
            body: JSON.stringify(patch),
        });
        if (!r.ok)
            throw new Error(`Failed to update memory: ${r.statusText}`);
        return r.json();
    }
    /**
     * Delete a memory entry
     */
    async deleteMemory(id) {
        const r = await fetch(`${this.baseUrl}/memory/${id}`, {
            method: 'DELETE',
            headers: getHeaders(),
        });
        if (!r.ok && r.status !== 204)
            throw new Error(`Failed to delete memory: ${r.statusText}`);
    }
    /**
     * Export enabled memories as formatted text
     */
    async exportMemories() {
        const r = await fetch(`${this.baseUrl}/memory/export`, { headers: getHeaders() });
        if (!r.ok)
            throw new Error(`Failed to export memories: ${r.statusText}`);
        return r.json();
    }
    // ── Context File API ──────────────────────────────────────────────────────
    /**
     * Resolve a path (file or directory) to a list of file paths
     */
    async resolveContextPath(path, rootDir = '') {
        const r = await fetch(`${this.baseUrl}/context/resolve`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ path, rootDir }),
        });
        if (!r.ok)
            throw new Error(`Failed to resolve path: ${r.statusText}`);
        return r.json();
    }
    /**
     * List the immediate children of a directory (one level only).
     * Returns both files and subdirectories.
     */
    async listDirContents(dirPath, rootDir = '') {
        const r = await fetch(`${this.baseUrl}/context/listdir`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ path: dirPath, rootDir }),
        });
        if (!r.ok) {
            // Fallback: use resolve which only returns files
            const fallback = await this.resolveContextPath(dirPath, rootDir);
            return {
                entries: fallback.paths.map(p => ({
                    name: p.split('/').pop() || p,
                    path: p,
                    isDir: false,
                })),
            };
        }
        return r.json();
    }
    /**
     * Read one or more files and return their contents
     */
    async readContextFiles(paths, rootDir = '') {
        const r = await fetch(`${this.baseUrl}/context/read`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ paths, rootDir }),
        });
        if (!r.ok)
            throw new Error(`Failed to read context files: ${r.statusText}`);
        return r.json();
    }
    // ── Workspace (.llm-assistant directory) API ─────────────────────────────
    /** Get workspace info for the current project */
    async getWorkspaceInfo(rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/info${params}`, {
            headers: getHeaders(),
        });
        if (!r.ok)
            throw new Error(`Failed to get workspace info: ${r.statusText}`);
        return r.json();
    }
    /** Get ASSISTANT.md content */
    async getAssistantMd(rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/assistant-md${params}`, {
            headers: getHeaders(),
        });
        if (!r.ok)
            throw new Error(`Failed to get ASSISTANT.md: ${r.statusText}`);
        return r.json();
    }
    /** Save ASSISTANT.md content */
    async saveAssistantMd(content, rootDir = '') {
        const r = await fetch(`${this.baseUrl}/workspace/assistant-md`, {
            method: 'PUT',
            headers: getHeaders(),
            body: JSON.stringify({ content, rootDir }),
        });
        if (!r.ok)
            throw new Error(`Failed to save ASSISTANT.md: ${r.statusText}`);
    }
    /** Get workspace config (per-project settings in .llm-assistant/config.json) */
    async getWorkspaceConfig(rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/config${params}`, {
            headers: getHeaders(),
        });
        if (!r.ok)
            throw new Error(`Failed to get workspace config: ${r.statusText}`);
        return r.json();
    }
    /** List saved sessions */
    async listSessions(rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/sessions${params}`, {
            headers: getHeaders(),
        });
        if (!r.ok)
            throw new Error(`Failed to list sessions: ${r.statusText}`);
        const d = await r.json();
        return d.sessions ?? [];
    }
    /** Save a session */
    async saveSession(session) {
        const r = await fetch(`${this.baseUrl}/workspace/sessions`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify(session),
        });
        if (!r.ok)
            throw new Error(`Failed to save session: ${r.statusText}`);
        return r.json();
    }
    /** Load a specific session */
    async loadSession(id, rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/sessions/${encodeURIComponent(id)}${params}`, { headers: getHeaders() });
        if (!r.ok)
            throw new Error(`Failed to load session: ${r.statusText}`);
        return r.json();
    }
    /** Delete a session */
    async deleteSession(id, rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/sessions/${encodeURIComponent(id)}${params}`, { method: 'DELETE', headers: getHeaders() });
        if (!r.ok && r.status !== 404)
            throw new Error(`Failed to delete session: ${r.statusText}`);
    }
    /** List installed skills */
    async listSkills(rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/skills${params}`, {
            headers: getHeaders(),
        });
        if (!r.ok)
            throw new Error(`Failed to list skills: ${r.statusText}`);
        const d = await r.json();
        return d.skills ?? [];
    }
    /** Install a skill from manifest */
    async installSkill(name, manifest, rootDir = '') {
        const r = await fetch(`${this.baseUrl}/workspace/skills/install`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({ name, manifest, rootDir }),
        });
        if (!r.ok)
            throw new Error(`Failed to install skill: ${r.statusText}`);
        return r.json();
    }
    /** Update a skill (enable/disable/system_prompt) */
    async updateSkill(name, patch, rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/skills/${encodeURIComponent(name)}${params}`, {
            method: 'PATCH',
            headers: getHeaders(),
            body: JSON.stringify(patch),
        });
        if (!r.ok)
            throw new Error(`Failed to update skill: ${r.statusText}`);
        return r.json();
    }
    /** Delete a skill */
    async deleteSkill(name, rootDir = '') {
        const params = rootDir ? `?rootDir=${encodeURIComponent(rootDir)}` : '';
        const r = await fetch(`${this.baseUrl}/workspace/skills/${encodeURIComponent(name)}${params}`, {
            method: 'DELETE',
            headers: getHeaders(),
        });
        if (!r.ok && r.status !== 404)
            throw new Error(`Failed to delete skill: ${r.statusText}`);
    }
    // ── Skill Registry (Marketplace) API ───────────────────────────────────
    /** List available skill registries/marketplaces */
    async listRegistries() {
        const r = await fetch(`${this.baseUrl}/workspace/registries`, {
            headers: getHeaders(),
        });
        if (!r.ok)
            throw new Error(`Failed to list registries: ${r.statusText}`);
        const d = await r.json();
        return d.registries ?? [];
    }
    /** Get skills from a specific registry */
    async getRegistrySkills(registryId, refresh = false) {
        const params = refresh ? '?refresh=true' : '';
        const r = await fetch(`${this.baseUrl}/workspace/registries/${encodeURIComponent(registryId)}${params}`, { headers: getHeaders() });
        if (!r.ok)
            throw new Error(`Failed to get registry skills: ${r.statusText}`);
        return r.json();
    }
    /** Install a skill from a GitHub URL or raw manifest URL */
    async installSkillFromUrl(name, url, rootDir = '') {
        // Fetch the raw content from the URL
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Failed to fetch skill manifest from URL: ${response.statusText}`);
        }
        const content = await response.text();
        // Parse as YAML (simple regex-based extraction)
        // In a real implementation, you'd use a YAML parser
        const manifest = {};
        const lines = content.split('\n');
        let inSystemPrompt = false;
        let systemPromptLines = [];
        for (const line of lines) {
            if (inSystemPrompt) {
                if (line.startsWith('    ') || line.startsWith('\t')) {
                    systemPromptLines.push(line);
                }
                else if (line.trim() === '') {
                    inSystemPrompt = false;
                    manifest['system_prompt'] = systemPromptLines.join('\n').trim();
                }
                else {
                    inSystemPrompt = false;
                }
            }
            if (line.startsWith('name:')) {
                manifest['name'] = line.substring(4).trim().replace(/^["']|["']$/g, '');
            }
            else if (line.startsWith('version:')) {
                manifest['version'] = line.substring(8).trim().replace(/^["']|["']$/g, '');
            }
            else if (line.startsWith('description:')) {
                manifest['description'] = line.substring(12).trim().replace(/^["']|["']$/g, '');
            }
            else if (line.startsWith('author:')) {
                manifest['author'] = line.substring(7).trim().replace(/^["']|["']$/g, '');
            }
            else if (line.startsWith('system_prompt:')) {
                const rest = line.substring(14).trim();
                if (rest === '|' || rest === '>' || rest === '|-' || rest === '>-') {
                    inSystemPrompt = true;
                    systemPromptLines = [];
                }
                else {
                    manifest['system_prompt'] = rest.replace(/^["']|["']$/g, '');
                }
            }
            else if (line.startsWith('enabled:')) {
                manifest['enabled'] = line.substring(8).trim().toLowerCase() === 'true';
            }
        }
        manifest['enabled'] = manifest['enabled'] !== false;
        return this.installSkill(name, manifest, rootDir);
    }
    // ── Internal SSE stream reader ────────────────────────────────────────────
    /** Internal SSE stream reader */
    async _readSSEStream(response, onEvent) {
        const reader = response.body?.getReader();
        if (!reader)
            throw new Error('No response body');
        const decoder = new TextDecoder();
        let buffer = '';
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        const raw = line.slice(6).trim();
                        if (raw === '[DONE]')
                            return;
                        try {
                            onEvent(JSON.parse(raw));
                        }
                        catch { /* skip malformed */ }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
        }
    }
}


/***/ },

/***/ "./lib/widgets/LLMAssistantPanel.js"
/*!******************************************!*\
  !*** ./lib/widgets/LLMAssistantPanel.js ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LLMAssistantPanel: () => (/* binding */ LLMAssistantPanel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ChatPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/ChatPanel */ "./lib/components/ChatPanel.js");
/* harmony import */ var _models_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../models/settings */ "./lib/models/settings.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);

/**
 * LLM Assistant sidebar panel widget.
 */





/**
 * LLM Assistant sidebar panel
 */
class LLMAssistantPanel extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Panel {
    /**
     * Create a new LLM Assistant panel
     */
    constructor() {
        super();
        /**
         * Signal emitted when settings change
         */
        this.settingsChanged = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_3__.Signal(this);
        this.addClass('llm-assistant-panel');
        this._settingsModel = new _models_settings__WEBPACK_IMPORTED_MODULE_5__.SettingsModel();
        // Create the main content widget
        const content = this._createContent();
        this.addWidget(content);
    }
    /**
     * Create the main content widget
     */
    _createContent() {
        const content = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.ReactWidget.create((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(ChatPanelWrapper, { settingsModel: this._settingsModel, onSettingsChange: (settings) => this.settingsChanged.emit(settings) }));
        content.addClass('llm-assistant-content');
        return content;
    }
    /**
     * Get current settings
     */
    getSettings() {
        return this._settingsModel.settings;
    }
    /**
     * Update settings
     */
    async updateSettings(settings) {
        await this._settingsModel.saveSettings(settings);
    }
}

const ChatPanelWrapper = ({ settingsModel, onSettingsChange, }) => {
    const [settings, setSettings] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(settingsModel.settings);
    const settingsChangedRef = (0,react__WEBPACK_IMPORTED_MODULE_6__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(() => {
        // Load settings on mount
        settingsModel.loadSettings().then((loaded) => {
            setSettings(loaded);
        });
        // Subscribe to settings changes (use ref to hold stable function reference)
        settingsChangedRef.current = (_, newSettings) => {
            setSettings(newSettings);
        };
        settingsModel.settingsChanged.connect(settingsChangedRef.current);
        return () => {
            // Cleanup: disconnect signal listener to prevent stale closures
            if (settingsChangedRef.current) {
                settingsModel.settingsChanged.disconnect(settingsChangedRef.current);
            }
        };
    }, [settingsModel]);
    const handleSettingsChange = (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)(async (newSettings) => {
        await settingsModel.saveSettings(newSettings);
        onSettingsChange({ ...settings, ...newSettings });
    }, [settingsModel, settings, onSettingsChange]);
    const handleOpenSettings = (0,react__WEBPACK_IMPORTED_MODULE_6__.useCallback)(() => {
        // Settings panel is managed internally by ChatPanel
    }, []);
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_ChatPanel__WEBPACK_IMPORTED_MODULE_4__.ChatPanel, { settings: settings, onOpenSettings: handleOpenSettings, onSettingsChange: handleSettingsChange }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LLMAssistantPanel);


/***/ }

}]);
//# sourceMappingURL=lib_index_js.95546b16086e1ca212db.js.map