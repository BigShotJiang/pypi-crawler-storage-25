"use strict";
(self["webpackChunkjupyterlab_llm_assistant"] = self["webpackChunkjupyterlab_llm_assistant"] || []).push([["style_index_css"],{

/***/ "./node_modules/css-loader/dist/runtime/api.js"
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
(module) {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
module.exports = function (cssWithMappingToString) {
  var list = [];

  // return the list of modules as css string
  list.toString = function toString() {
    return this.map(function (item) {
      var content = "";
      var needLayer = typeof item[5] !== "undefined";
      if (item[4]) {
        content += "@supports (".concat(item[4], ") {");
      }
      if (item[2]) {
        content += "@media ".concat(item[2], " {");
      }
      if (needLayer) {
        content += "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {");
      }
      content += cssWithMappingToString(item);
      if (needLayer) {
        content += "}";
      }
      if (item[2]) {
        content += "}";
      }
      if (item[4]) {
        content += "}";
      }
      return content;
    }).join("");
  };

  // import a list of modules into the list
  list.i = function i(modules, media, dedupe, supports, layer) {
    if (typeof modules === "string") {
      modules = [[null, modules, undefined]];
    }
    var alreadyImportedModules = {};
    if (dedupe) {
      for (var k = 0; k < this.length; k++) {
        var id = this[k][0];
        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }
    for (var _k = 0; _k < modules.length; _k++) {
      var item = [].concat(modules[_k]);
      if (dedupe && alreadyImportedModules[item[0]]) {
        continue;
      }
      if (typeof layer !== "undefined") {
        if (typeof item[5] === "undefined") {
          item[5] = layer;
        } else {
          item[1] = "@layer".concat(item[5].length > 0 ? " ".concat(item[5]) : "", " {").concat(item[1], "}");
          item[5] = layer;
        }
      }
      if (media) {
        if (!item[2]) {
          item[2] = media;
        } else {
          item[1] = "@media ".concat(item[2], " {").concat(item[1], "}");
          item[2] = media;
        }
      }
      if (supports) {
        if (!item[4]) {
          item[4] = "".concat(supports);
        } else {
          item[1] = "@supports (".concat(item[4], ") {").concat(item[1], "}");
          item[4] = supports;
        }
      }
      list.push(item);
    }
  };
  return list;
};

/***/ },

/***/ "./node_modules/css-loader/dist/runtime/sourceMaps.js"
/*!************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/sourceMaps.js ***!
  \************************************************************/
(module) {



module.exports = function (item) {
  var content = item[1];
  var cssMapping = item[3];
  if (!cssMapping) {
    return content;
  }
  if (typeof btoa === "function") {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    return [content].concat([sourceMapping]).join("\n");
  }
  return [content].join("\n");
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
(module) {



var stylesInDOM = [];
function getIndexByIdentifier(identifier) {
  var result = -1;
  for (var i = 0; i < stylesInDOM.length; i++) {
    if (stylesInDOM[i].identifier === identifier) {
      result = i;
      break;
    }
  }
  return result;
}
function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];
  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var indexByIdentifier = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3],
      supports: item[4],
      layer: item[5]
    };
    if (indexByIdentifier !== -1) {
      stylesInDOM[indexByIdentifier].references++;
      stylesInDOM[indexByIdentifier].updater(obj);
    } else {
      var updater = addElementStyle(obj, options);
      options.byIndex = i;
      stylesInDOM.splice(i, 0, {
        identifier: identifier,
        updater: updater,
        references: 1
      });
    }
    identifiers.push(identifier);
  }
  return identifiers;
}
function addElementStyle(obj, options) {
  var api = options.domAPI(options);
  api.update(obj);
  var updater = function updater(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap && newObj.supports === obj.supports && newObj.layer === obj.layer) {
        return;
      }
      api.update(obj = newObj);
    } else {
      api.remove();
    }
  };
  return updater;
}
module.exports = function (list, options) {
  options = options || {};
  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];
    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDOM[index].references--;
    }
    var newLastIdentifiers = modulesToDom(newList, options);
    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];
      var _index = getIndexByIdentifier(_identifier);
      if (stylesInDOM[_index].references === 0) {
        stylesInDOM[_index].updater();
        stylesInDOM.splice(_index, 1);
      }
    }
    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertBySelector.js"
/*!********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertBySelector.js ***!
  \********************************************************************/
(module) {



var memo = {};

/* istanbul ignore next  */
function getTarget(target) {
  if (typeof memo[target] === "undefined") {
    var styleTarget = document.querySelector(target);

    // Special case to return head of iframe instead of iframe itself
    if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
      try {
        // This will throw an exception if access to iframe is blocked
        // due to cross-origin restrictions
        styleTarget = styleTarget.contentDocument.head;
      } catch (e) {
        // istanbul ignore next
        styleTarget = null;
      }
    }
    memo[target] = styleTarget;
  }
  return memo[target];
}

/* istanbul ignore next  */
function insertBySelector(insert, style) {
  var target = getTarget(insert);
  if (!target) {
    throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
  }
  target.appendChild(style);
}
module.exports = insertBySelector;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/insertStyleElement.js"
/*!**********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/insertStyleElement.js ***!
  \**********************************************************************/
(module) {



/* istanbul ignore next  */
function insertStyleElement(options) {
  var element = document.createElement("style");
  options.setAttributes(element, options.attributes);
  options.insert(element, options.options);
  return element;
}
module.exports = insertStyleElement;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js"
/*!**********************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js ***!
  \**********************************************************************************/
(module, __unused_webpack_exports, __webpack_require__) {



/* istanbul ignore next  */
function setAttributesWithoutAttributes(styleElement) {
  var nonce =  true ? __webpack_require__.nc : 0;
  if (nonce) {
    styleElement.setAttribute("nonce", nonce);
  }
}
module.exports = setAttributesWithoutAttributes;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleDomAPI.js"
/*!***************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleDomAPI.js ***!
  \***************************************************************/
(module) {



/* istanbul ignore next  */
function apply(styleElement, options, obj) {
  var css = "";
  if (obj.supports) {
    css += "@supports (".concat(obj.supports, ") {");
  }
  if (obj.media) {
    css += "@media ".concat(obj.media, " {");
  }
  var needLayer = typeof obj.layer !== "undefined";
  if (needLayer) {
    css += "@layer".concat(obj.layer.length > 0 ? " ".concat(obj.layer) : "", " {");
  }
  css += obj.css;
  if (needLayer) {
    css += "}";
  }
  if (obj.media) {
    css += "}";
  }
  if (obj.supports) {
    css += "}";
  }
  var sourceMap = obj.sourceMap;
  if (sourceMap && typeof btoa !== "undefined") {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  }

  // For old IE
  /* istanbul ignore if  */
  options.styleTagTransform(css, styleElement, options.options);
}
function removeStyleElement(styleElement) {
  // istanbul ignore if
  if (styleElement.parentNode === null) {
    return false;
  }
  styleElement.parentNode.removeChild(styleElement);
}

/* istanbul ignore next  */
function domAPI(options) {
  if (typeof document === "undefined") {
    return {
      update: function update() {},
      remove: function remove() {}
    };
  }
  var styleElement = options.insertStyleElement(options);
  return {
    update: function update(obj) {
      apply(styleElement, options, obj);
    },
    remove: function remove() {
      removeStyleElement(styleElement);
    }
  };
}
module.exports = domAPI;

/***/ },

/***/ "./node_modules/style-loader/dist/runtime/styleTagTransform.js"
/*!*********************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/styleTagTransform.js ***!
  \*********************************************************************/
(module) {



/* istanbul ignore next  */
function styleTagTransform(css, styleElement) {
  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css;
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild);
    }
    styleElement.appendChild(document.createTextNode(css));
  }
}
module.exports = styleTagTransform;

/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/agent.css"
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/agent.css ***!
  \***************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Agent panel styles — Claude Code inspired
 */

/* ─── Mode toggle in chat header ─────────────────────────────── */

.llm-mode-toggle {
  display: flex;
  gap: 2px;
  background: var(--jp-layout-color2);
  border-radius: 6px;
  padding: 2px;
  border: 1px solid var(--jp-border-color2);
}

.llm-mode-btn {
  font-size: 11px;
  font-weight: 500;
  padding: 3px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  background: transparent;
  color: var(--jp-content-font-color2);
  transition: background 0.15s, color 0.15s;
}

.llm-mode-btn:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

.llm-mode-btn.active {
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
}

/* ─── Agent panel shell ───────────────────────────────────────── */

.agent-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

/* ─── Header ─────────────────────────────────────────────────── */

.agent-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  flex-shrink: 0;
}

.agent-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
}

.agent-header-icon {
  color: var(--jp-brand-color1, #1976d2);
  display: flex;
  align-items: center;
}

.agent-header-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--jp-content-font-color1);
}

.agent-model-badge {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 10px;
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color2);
  border: 1px solid var(--jp-border-color2);
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.agent-header-actions {
  display: flex;
  gap: 4px;
}

.agent-header-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 4px;
  border: none;
  background: transparent;
  border-radius: 4px;
  cursor: pointer;
  color: var(--jp-content-font-color2);
  transition: background 0.15s;
}

.agent-header-btn:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

.agent-header-btn.active {
  background: var(--jp-brand-color3, #e3f2fd);
  color: var(--jp-brand-color1, #1976d2);
}

body[data-jp-theme-light='false'] .agent-header-btn.active {
  background: #1e3a5f;
  color: var(--jp-brand-color1, #42a5f5);
}

/* ─── History panel ──────────────────────────────────────────── */

.agent-history-panel {
  flex-shrink: 0;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
  max-height: 220px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.agent-history-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px 10px;
  font-size: 10px;
  font-weight: 600;
  color: var(--jp-content-font-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  flex-shrink: 0;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.agent-history-count {
  font-weight: 400;
  font-size: 9px;
}

.agent-history-empty {
  padding: 14px 12px;
  font-size: 11px;
  color: var(--jp-content-font-color3);
  text-align: center;
  font-style: italic;
}

.agent-history-list {
  overflow-y: auto;
  flex: 1;
}

.agent-history-item {
  display: flex;
  align-items: stretch;
  border-bottom: 1px solid var(--jp-border-color2);
}

.agent-history-item:last-child {
  border-bottom: none;
}

.agent-history-restore {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 6px 10px;
  background: transparent;
  border: none;
  cursor: pointer;
  text-align: left;
  transition: background 0.12s;
  min-width: 0;
}

.agent-history-restore:hover {
  background: var(--jp-layout-color3);
}

.agent-history-summary {
  font-size: 11px;
  color: var(--jp-content-font-color1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
}

.agent-history-time {
  font-size: 9px;
  color: var(--jp-content-font-color3);
  display: block;
}

.agent-history-delete {
  flex-shrink: 0;
  width: 28px;
  background: transparent;
  border: none;
  cursor: pointer;
  color: var(--jp-content-font-color3);
  font-size: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: color 0.12s, background 0.12s;
}

.agent-history-delete:hover {
  color: #ef4444;
  background: var(--jp-layout-color3);
}

/* ─── Working directory input ────────────────────────────────── */

.agent-dir-input-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 5px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
  flex-shrink: 0;
}

.agent-dir-label {
  font-size: 10px;
  color: var(--jp-content-font-color2);
  white-space: nowrap;
}

.agent-dir-input {
  flex: 1;
  font-size: 11px;
  padding: 3px 6px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
  outline: none;
}

.agent-dir-input:focus {
  border-color: var(--jp-brand-color1, #1976d2);
}

/* ─── Iteration progress bar ─────────────────────────────────── */

.agent-iteration-bar {
  position: relative;
  height: 20px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  flex-shrink: 0;
  overflow: hidden;
}

.agent-iteration-progress {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  background: var(--jp-brand-color1, #1976d2);
  opacity: 0.2;
  transition: width 0.3s ease;
}

.agent-iteration-label {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 10px;
  color: var(--jp-content-font-color2);
  white-space: nowrap;
}

/* ─── Error banner ───────────────────────────────────────────── */

.agent-error-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 10px;
  background: #ffeaea;
  color: #c62828;
  font-size: 11px;
  border-bottom: 1px solid #ffcdd2;
  flex-shrink: 0;
}

body[data-jp-theme-light='false'] .agent-error-banner {
  background: #3e1a1a;
  color: #ef9a9a;
  border-bottom-color: #5c2626;
}

.agent-error-banner button {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  font-size: 14px;
  padding: 0 2px;
  line-height: 1;
}

/* ─── Messages scroll area ───────────────────────────────────── */

.agent-messages {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
  scroll-behavior: smooth;
}

/* ─── Empty state ────────────────────────────────────────────── */

.agent-empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 16px;
  text-align: center;
  gap: 8px;
}

.agent-empty-icon {
  color: var(--jp-content-font-color2);
  margin-bottom: 4px;
}

.agent-empty-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--jp-content-font-color1);
  margin: 0;
}

.agent-empty-hint {
  font-size: 11px;
  color: var(--jp-content-font-color2);
  line-height: 1.5;
  margin: 0;
  max-width: 220px;
}

.agent-example-prompts {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
  max-width: 240px;
  margin-top: 6px;
}

.agent-example-btn {
  font-size: 11px;
  padding: 5px 10px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 6px;
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
  cursor: pointer;
  text-align: left;
  transition: background 0.15s, border-color 0.15s;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.agent-example-btn:hover:not(:disabled) {
  background: var(--jp-layout-color3);
  border-color: var(--jp-brand-color1, #1976d2);
}

/* ─── Individual messages ────────────────────────────────────── */

.agent-message {
  padding: 2px 0;
}

/* User bubble */
.agent-user-bubble {
  display: flex;
  gap: 6px;
  align-items: flex-start;
  padding: 6px 10px;
  margin: 2px 6px;
  background: var(--jp-brand-color3, #e3f2fd);
  border-radius: 8px;
}

body[data-jp-theme-light='false'] .agent-user-bubble {
  background: #1e3a5f;
}

.agent-user-avatar {
  font-size: 9px;
  font-weight: 700;
  padding: 2px 5px;
  border-radius: 4px;
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
  flex-shrink: 0;
  margin-top: 1px;
}

.agent-user-content {
  font-size: 12px;
  line-height: 1.5;
  color: var(--jp-content-font-color1);
  white-space: pre-wrap;
  word-break: break-word;
}

/* Agent text block */
.agent-text-block {
  display: flex;
  gap: 6px;
  align-items: flex-start;
  padding: 4px 10px;
}

.agent-assistant-avatar {
  color: var(--jp-brand-color1, #1976d2);
  flex-shrink: 0;
  margin-top: 2px;
  display: flex;
  align-items: center;
}

.agent-text-content {
  flex: 1;
  font-size: 12px;
  line-height: 1.6;
  color: var(--jp-content-font-color1);
  min-width: 0;
}

/* Blinking cursor */
.agent-cursor {
  display: inline-block;
  width: 2px;
  height: 14px;
  background: var(--jp-brand-color1, #1976d2);
  margin-left: 2px;
  vertical-align: text-bottom;
  animation: agent-blink 1s step-end infinite;
}

@keyframes agent-blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
}

/* ─── Tool call block ────────────────────────────────────────── */

.agent-tool-call {
  margin: 3px 10px;
  border-radius: 6px;
  border: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  overflow: hidden;
  font-size: 11px;
}

.agent-tool-call-running {
  border-color: #f0a500;
}

.agent-tool-call-success {
  border-color: var(--jp-border-color2);
}

.agent-tool-call-error {
  border-color: #ef4444;
  background: var(--jp-layout-color2);
}

/* Tool header button */
.agent-tool-header {
  display: flex;
  align-items: center;
  gap: 5px;
  width: 100%;
  padding: 5px 8px;
  border: none;
  background: transparent;
  cursor: default;
  text-align: left;
  color: var(--jp-content-font-color1);
  font-size: 11px;
}

.agent-tool-header[disabled] {
  cursor: default;
}

.agent-tool-header:not([disabled]) {
  cursor: pointer;
}

.agent-tool-header:not([disabled]):hover {
  background: var(--jp-layout-color3);
}

/* Collapsed tool call summary */
.agent-tool-summary {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}

.agent-tool-expand-hint {
  font-size: 9px;
  color: var(--jp-content-font-color2);
  opacity: 0.7;
  margin-left: auto;
}

/* Status dot */
.agent-tool-status {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
}

.agent-tool-status-running {
  animation: agent-pulse 1s ease-in-out infinite;
}

@keyframes agent-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}

/* Tool icon */
.agent-tool-icon {
  display: flex;
  align-items: center;
  color: var(--jp-content-font-color2);
  flex-shrink: 0;
}

/* Tool label */
.agent-tool-label {
  flex: 1;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--jp-content-font-color1);
}

.agent-tool-duration {
  font-size: 10px;
  color: var(--jp-content-font-color2);
  flex-shrink: 0;
}

.agent-tool-chevron {
  font-size: 9px;
  color: var(--jp-content-font-color2);
  flex-shrink: 0;
}

.agent-tool-spinner {
  display: flex;
  align-items: center;
  flex-shrink: 0;
}

/* Spinning animation */
.agent-spinning {
  animation: agent-spin 0.8s linear infinite;
  color: #f0a500;
}

@keyframes agent-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* Args row */
.agent-tool-args-row {
  padding: 0 8px 5px 26px;
}

.agent-tool-args {
  font-size: 10px;
  color: var(--jp-content-font-color2);
  font-style: italic;
}

.agent-tool-args-code {
  font-family: var(--jp-code-font-family, monospace);
  font-size: 10px;
  background: var(--jp-layout-color3);
  padding: 1px 4px;
  border-radius: 3px;
  color: var(--jp-content-font-color1);
  display: block;
  overflow-x: auto;
  white-space: pre;
  margin-right: 8px;
}

/* Expanded output */
.agent-tool-output {
  border-top: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
  max-height: 280px;
  overflow-y: auto;
}

.agent-tool-output pre {
  margin: 0;
  padding: 8px 10px;
  font-family: var(--jp-code-font-family, monospace);
  font-size: 10px;
  line-height: 1.5;
  color: var(--jp-content-font-color1);
  white-space: pre-wrap;
  word-break: break-word;
}

.agent-tool-output-error pre {
  color: #ef4444;
}

/* ─── Thinking indicator ─────────────────────────────────────── */

.agent-thinking {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  color: var(--jp-content-font-color2);
  font-size: 11px;
}

.agent-thinking-dots {
  display: flex;
  gap: 4px;
}

.agent-thinking-dots span {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--jp-brand-color1, #1976d2);
  animation: agent-bounce 1.2s ease-in-out infinite;
}

.agent-thinking-dots span:nth-child(2) { animation-delay: 0.15s; }
.agent-thinking-dots span:nth-child(3) { animation-delay: 0.3s; }

@keyframes agent-bounce {
  0%, 80%, 100% { transform: scale(0.7); opacity: 0.5; }
  40% { transform: scale(1); opacity: 1; }
}

.agent-thinking-label {
  font-style: italic;
}

/* ─── Input area ─────────────────────────────────────────────── */

.agent-input-area {
  flex-shrink: 0;
  border-top: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
  padding: 6px 8px 4px;
}

.agent-input-textarea {
  width: 100%;
  box-sizing: border-box;
  padding: 7px 10px;
  padding-right: 38px;
  font-size: 12px;
  font-family: var(--jp-content-font-family);
  line-height: 1.5;
  border: 1px solid var(--jp-border-color2);
  border-radius: 8px;
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
  resize: none;
  outline: none;
  transition: border-color 0.15s;
  min-height: 36px;
  max-height: 150px;
  overflow-y: auto;
}

.agent-input-textarea:focus {
  border-color: var(--jp-brand-color1, #1976d2);
}

.agent-input-textarea:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.agent-input-actions {
  display: flex;
  justify-content: flex-end;
  margin-top: 4px;
  gap: 4px;
}

.agent-send-btn,
.agent-stop-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.15s;
}

.agent-send-btn {
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
}

.agent-send-btn:hover:not(:disabled) {
  background: var(--jp-brand-color0, #1565c0);
}

.agent-send-btn:disabled {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color3);
  cursor: not-allowed;
}

.agent-stop-btn {
  background: #ef4444;
  color: #fff;
}

.agent-stop-btn:hover {
  background: #dc2626;
}

.agent-input-hint {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 9px;
  color: var(--jp-content-font-color3);
  padding: 1px 2px 0;
}

.agent-cwd-label {
  font-size: 9px;
  color: var(--jp-content-font-color2);
  background: var(--jp-layout-color2);
  padding: 1px 5px;
  border-radius: 3px;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
`, "",{"version":3,"sources":["webpack://./style/agent.css"],"names":[],"mappings":"AAAA;;EAEE;;AAEF,mEAAmE;;AAEnE;EACE,aAAa;EACb,QAAQ;EACR,mCAAmC;EACnC,kBAAkB;EAClB,YAAY;EACZ,yCAAyC;AAC3C;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,iBAAiB;EACjB,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,uBAAuB;EACvB,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,2CAA2C;EAC3C,WAAW;AACb;;AAEA,oEAAoE;;AAEpE;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,gBAAgB;AAClB;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,gDAAgD;EAChD,mCAAmC;EACnC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,sCAAsC;EACtC,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,mBAAmB;EACnB,mCAAmC;EACnC,oCAAoC;EACpC,yCAAyC;EACzC,gBAAgB;EAChB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,YAAY;EACZ,YAAY;EACZ,uBAAuB;EACvB,kBAAkB;EAClB,eAAe;EACf,oCAAoC;EACpC,4BAA4B;AAC9B;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,2CAA2C;EAC3C,sCAAsC;AACxC;;AAEA;EACE,mBAAmB;EACnB,sCAAsC;AACxC;;AAEA,mEAAmE;;AAEnE;EACE,cAAc;EACd,gDAAgD;EAChD,mCAAmC;EACnC,iBAAiB;EACjB,aAAa;EACb,sBAAsB;EACtB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,gDAAgD;EAChD,mCAAmC;EACnC,cAAc;EACd,yBAAyB;EACzB,sBAAsB;AACxB;;AAEA;EACE,gBAAgB;EAChB,cAAc;AAChB;;AAEA;EACE,kBAAkB;EAClB,eAAe;EACf,oCAAoC;EACpC,kBAAkB;EAClB,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,OAAO;AACT;;AAEA;EACE,aAAa;EACb,oBAAoB;EACpB,gDAAgD;AAClD;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,OAAO;EACP,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,iBAAiB;EACjB,uBAAuB;EACvB,YAAY;EACZ,eAAe;EACf,gBAAgB;EAChB,4BAA4B;EAC5B,YAAY;AACd;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,eAAe;EACf,oCAAoC;EACpC,mBAAmB;EACnB,gBAAgB;EAChB,uBAAuB;EACvB,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,oCAAoC;EACpC,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,WAAW;EACX,uBAAuB;EACvB,YAAY;EACZ,eAAe;EACf,oCAAoC;EACpC,eAAe;EACf,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,yCAAyC;AAC3C;;AAEA;EACE,cAAc;EACd,mCAAmC;AACrC;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,gDAAgD;EAChD,mCAAmC;EACnC,cAAc;AAChB;;AAEA;EACE,eAAe;EACf,oCAAoC;EACpC,mBAAmB;AACrB;;AAEA;EACE,OAAO;EACP,eAAe;EACf,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,oCAAoC;EACpC,aAAa;AACf;;AAEA;EACE,6CAA6C;AAC/C;;AAEA,mEAAmE;;AAEnE;EACE,kBAAkB;EAClB,YAAY;EACZ,mCAAmC;EACnC,gDAAgD;EAChD,cAAc;EACd,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;EAClB,MAAM;EACN,OAAO;EACP,SAAS;EACT,2CAA2C;EAC3C,YAAY;EACZ,2BAA2B;AAC7B;;AAEA;EACE,kBAAkB;EAClB,QAAQ;EACR,SAAS;EACT,gCAAgC;EAChC,eAAe;EACf,oCAAoC;EACpC,mBAAmB;AACrB;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,mBAAmB;EACnB,cAAc;EACd,eAAe;EACf,gCAAgC;EAChC,cAAc;AAChB;;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,eAAe;EACf,cAAc;EACd,eAAe;EACf,cAAc;EACd,cAAc;AAChB;;AAEA,mEAAmE;;AAEnE;EACE,OAAO;EACP,gBAAgB;EAChB,cAAc;EACd,uBAAuB;AACzB;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,kBAAkB;EAClB,kBAAkB;EAClB,QAAQ;AACV;;AAEA;EACE,oCAAoC;EACpC,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,SAAS;AACX;;AAEA;EACE,eAAe;EACf,oCAAoC;EACpC,gBAAgB;EAChB,SAAS;EACT,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,WAAW;EACX,gBAAgB;EAChB,eAAe;AACjB;;AAEA;EACE,eAAe;EACf,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,oCAAoC;EACpC,eAAe;EACf,gBAAgB;EAChB,gDAAgD;EAChD,mBAAmB;EACnB,gBAAgB;EAChB,uBAAuB;AACzB;;AAEA;EACE,mCAAmC;EACnC,6CAA6C;AAC/C;;AAEA,mEAAmE;;AAEnE;EACE,cAAc;AAChB;;AAEA,gBAAgB;AAChB;EACE,aAAa;EACb,QAAQ;EACR,uBAAuB;EACvB,iBAAiB;EACjB,eAAe;EACf,2CAA2C;EAC3C,kBAAkB;AACpB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,gBAAgB;EAChB,kBAAkB;EAClB,2CAA2C;EAC3C,WAAW;EACX,cAAc;EACd,eAAe;AACjB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,qBAAqB;EACrB,sBAAsB;AACxB;;AAEA,qBAAqB;AACrB;EACE,aAAa;EACb,QAAQ;EACR,uBAAuB;EACvB,iBAAiB;AACnB;;AAEA;EACE,sCAAsC;EACtC,cAAc;EACd,eAAe;EACf,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,OAAO;EACP,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,YAAY;AACd;;AAEA,oBAAoB;AACpB;EACE,qBAAqB;EACrB,UAAU;EACV,YAAY;EACZ,2CAA2C;EAC3C,gBAAgB;EAChB,2BAA2B;EAC3B,2CAA2C;AAC7C;;AAEA;EACE,WAAW,UAAU,EAAE;EACvB,MAAM,UAAU,EAAE;AACpB;;AAEA,mEAAmE;;AAEnE;EACE,gBAAgB;EAChB,kBAAkB;EAClB,yCAAyC;EACzC,mCAAmC;EACnC,gBAAgB;EAChB,eAAe;AACjB;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,qBAAqB;EACrB,mCAAmC;AACrC;;AAEA,uBAAuB;AACvB;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,WAAW;EACX,gBAAgB;EAChB,YAAY;EACZ,uBAAuB;EACvB,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,eAAe;AACjB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,mCAAmC;AACrC;;AAEA,gCAAgC;AAChC;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,OAAO;EACP,YAAY;AACd;;AAEA;EACE,cAAc;EACd,oCAAoC;EACpC,YAAY;EACZ,iBAAiB;AACnB;;AAEA,eAAe;AACf;EACE,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,cAAc;AAChB;;AAEA;EACE,8CAA8C;AAChD;;AAEA;EACE,WAAW,UAAU,EAAE;EACvB,MAAM,YAAY,EAAE;AACtB;;AAEA,cAAc;AACd;EACE,aAAa;EACb,mBAAmB;EACnB,oCAAoC;EACpC,cAAc;AAChB;;AAEA,eAAe;AACf;EACE,OAAO;EACP,gBAAgB;EAChB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;EACnB,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,oCAAoC;EACpC,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,oCAAoC;EACpC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,cAAc;AAChB;;AAEA,uBAAuB;AACvB;EACE,0CAA0C;EAC1C,cAAc;AAChB;;AAEA;EACE,OAAO,uBAAuB,EAAE;EAChC,KAAK,yBAAyB,EAAE;AAClC;;AAEA,aAAa;AACb;EACE,uBAAuB;AACzB;;AAEA;EACE,eAAe;EACf,oCAAoC;EACpC,kBAAkB;AACpB;;AAEA;EACE,kDAAkD;EAClD,eAAe;EACf,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;EAClB,oCAAoC;EACpC,cAAc;EACd,gBAAgB;EAChB,gBAAgB;EAChB,iBAAiB;AACnB;;AAEA,oBAAoB;AACpB;EACE,6CAA6C;EAC7C,mCAAmC;EACnC,iBAAiB;EACjB,gBAAgB;AAClB;;AAEA;EACE,SAAS;EACT,iBAAiB;EACjB,kDAAkD;EAClD,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,qBAAqB;EACrB,sBAAsB;AACxB;;AAEA;EACE,cAAc;AAChB;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,oCAAoC;EACpC,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,2CAA2C;EAC3C,iDAAiD;AACnD;;AAEA,yCAAyC,sBAAsB,EAAE;AACjE,yCAAyC,qBAAqB,EAAE;;AAEhE;EACE,gBAAgB,qBAAqB,EAAE,YAAY,EAAE;EACrD,MAAM,mBAAmB,EAAE,UAAU,EAAE;AACzC;;AAEA;EACE,kBAAkB;AACpB;;AAEA,mEAAmE;;AAEnE;EACE,cAAc;EACd,6CAA6C;EAC7C,mCAAmC;EACnC,oBAAoB;AACtB;;AAEA;EACE,WAAW;EACX,sBAAsB;EACtB,iBAAiB;EACjB,mBAAmB;EACnB,eAAe;EACf,0CAA0C;EAC1C,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,oCAAoC;EACpC,YAAY;EACZ,aAAa;EACb,8BAA8B;EAC9B,gBAAgB;EAChB,iBAAiB;EACjB,gBAAgB;AAClB;;AAEA;EACE,6CAA6C;AAC/C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,yBAAyB;EACzB,eAAe;EACf,QAAQ;AACV;;AAEA;;EAEE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,4BAA4B;AAC9B;;AAEA;EACE,2CAA2C;EAC3C,WAAW;AACb;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;EACpC,mBAAmB;AACrB;;AAEA;EACE,mBAAmB;EACnB,WAAW;AACb;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,cAAc;EACd,oCAAoC;EACpC,kBAAkB;AACpB;;AAEA;EACE,cAAc;EACd,oCAAoC;EACpC,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;EAClB,gBAAgB;EAChB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB","sourcesContent":["/**\r\n * Agent panel styles — Claude Code inspired\r\n */\r\n\r\n/* ─── Mode toggle in chat header ─────────────────────────────── */\r\n\r\n.llm-mode-toggle {\r\n  display: flex;\r\n  gap: 2px;\r\n  background: var(--jp-layout-color2);\r\n  border-radius: 6px;\r\n  padding: 2px;\r\n  border: 1px solid var(--jp-border-color2);\r\n}\r\n\r\n.llm-mode-btn {\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  padding: 3px 10px;\r\n  border: none;\r\n  border-radius: 4px;\r\n  cursor: pointer;\r\n  background: transparent;\r\n  color: var(--jp-content-font-color2);\r\n  transition: background 0.15s, color 0.15s;\r\n}\r\n\r\n.llm-mode-btn:hover {\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.llm-mode-btn.active {\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n}\r\n\r\n/* ─── Agent panel shell ───────────────────────────────────────── */\r\n\r\n.agent-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n  overflow: hidden;\r\n}\r\n\r\n/* ─── Header ─────────────────────────────────────────────────── */\r\n\r\n.agent-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 6px 10px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.agent-header-left {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n}\r\n\r\n.agent-header-icon {\r\n  color: var(--jp-brand-color1, #1976d2);\r\n  display: flex;\r\n  align-items: center;\r\n}\r\n\r\n.agent-header-title {\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.agent-model-badge {\r\n  font-size: 10px;\r\n  padding: 1px 6px;\r\n  border-radius: 10px;\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color2);\r\n  border: 1px solid var(--jp-border-color2);\r\n  max-width: 100px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n\r\n.agent-header-actions {\r\n  display: flex;\r\n  gap: 4px;\r\n}\r\n\r\n.agent-header-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  padding: 4px;\r\n  border: none;\r\n  background: transparent;\r\n  border-radius: 4px;\r\n  cursor: pointer;\r\n  color: var(--jp-content-font-color2);\r\n  transition: background 0.15s;\r\n}\r\n\r\n.agent-header-btn:hover {\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.agent-header-btn.active {\r\n  background: var(--jp-brand-color3, #e3f2fd);\r\n  color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .agent-header-btn.active {\r\n  background: #1e3a5f;\r\n  color: var(--jp-brand-color1, #42a5f5);\r\n}\r\n\r\n/* ─── History panel ──────────────────────────────────────────── */\r\n\r\n.agent-history-panel {\r\n  flex-shrink: 0;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color1);\r\n  max-height: 220px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  overflow: hidden;\r\n}\r\n\r\n.agent-history-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 5px 10px;\r\n  font-size: 10px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color2);\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color2);\r\n  flex-shrink: 0;\r\n  text-transform: uppercase;\r\n  letter-spacing: 0.04em;\r\n}\r\n\r\n.agent-history-count {\r\n  font-weight: 400;\r\n  font-size: 9px;\r\n}\r\n\r\n.agent-history-empty {\r\n  padding: 14px 12px;\r\n  font-size: 11px;\r\n  color: var(--jp-content-font-color3);\r\n  text-align: center;\r\n  font-style: italic;\r\n}\r\n\r\n.agent-history-list {\r\n  overflow-y: auto;\r\n  flex: 1;\r\n}\r\n\r\n.agent-history-item {\r\n  display: flex;\r\n  align-items: stretch;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n}\r\n\r\n.agent-history-item:last-child {\r\n  border-bottom: none;\r\n}\r\n\r\n.agent-history-restore {\r\n  flex: 1;\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 2px;\r\n  padding: 6px 10px;\r\n  background: transparent;\r\n  border: none;\r\n  cursor: pointer;\r\n  text-align: left;\r\n  transition: background 0.12s;\r\n  min-width: 0;\r\n}\r\n\r\n.agent-history-restore:hover {\r\n  background: var(--jp-layout-color3);\r\n}\r\n\r\n.agent-history-summary {\r\n  font-size: 11px;\r\n  color: var(--jp-content-font-color1);\r\n  white-space: nowrap;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  display: block;\r\n}\r\n\r\n.agent-history-time {\r\n  font-size: 9px;\r\n  color: var(--jp-content-font-color3);\r\n  display: block;\r\n}\r\n\r\n.agent-history-delete {\r\n  flex-shrink: 0;\r\n  width: 28px;\r\n  background: transparent;\r\n  border: none;\r\n  cursor: pointer;\r\n  color: var(--jp-content-font-color3);\r\n  font-size: 11px;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  transition: color 0.12s, background 0.12s;\r\n}\r\n\r\n.agent-history-delete:hover {\r\n  color: #ef4444;\r\n  background: var(--jp-layout-color3);\r\n}\r\n\r\n/* ─── Working directory input ────────────────────────────────── */\r\n\r\n.agent-dir-input-row {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  padding: 5px 10px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color1);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.agent-dir-label {\r\n  font-size: 10px;\r\n  color: var(--jp-content-font-color2);\r\n  white-space: nowrap;\r\n}\r\n\r\n.agent-dir-input {\r\n  flex: 1;\r\n  font-size: 11px;\r\n  padding: 3px 6px;\r\n  border: 1px solid var(--jp-border-color2);\r\n  border-radius: 4px;\r\n  background: var(--jp-layout-color2);\r\n  color: var(--jp-content-font-color1);\r\n  outline: none;\r\n}\r\n\r\n.agent-dir-input:focus {\r\n  border-color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n/* ─── Iteration progress bar ─────────────────────────────────── */\r\n\r\n.agent-iteration-bar {\r\n  position: relative;\r\n  height: 20px;\r\n  background: var(--jp-layout-color2);\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  flex-shrink: 0;\r\n  overflow: hidden;\r\n}\r\n\r\n.agent-iteration-progress {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  bottom: 0;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  opacity: 0.2;\r\n  transition: width 0.3s ease;\r\n}\r\n\r\n.agent-iteration-label {\r\n  position: absolute;\r\n  top: 50%;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%);\r\n  font-size: 10px;\r\n  color: var(--jp-content-font-color2);\r\n  white-space: nowrap;\r\n}\r\n\r\n/* ─── Error banner ───────────────────────────────────────────── */\r\n\r\n.agent-error-banner {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 6px 10px;\r\n  background: #ffeaea;\r\n  color: #c62828;\r\n  font-size: 11px;\r\n  border-bottom: 1px solid #ffcdd2;\r\n  flex-shrink: 0;\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .agent-error-banner {\r\n  background: #3e1a1a;\r\n  color: #ef9a9a;\r\n  border-bottom-color: #5c2626;\r\n}\r\n\r\n.agent-error-banner button {\r\n  background: none;\r\n  border: none;\r\n  cursor: pointer;\r\n  color: inherit;\r\n  font-size: 14px;\r\n  padding: 0 2px;\r\n  line-height: 1;\r\n}\r\n\r\n/* ─── Messages scroll area ───────────────────────────────────── */\r\n\r\n.agent-messages {\r\n  flex: 1;\r\n  overflow-y: auto;\r\n  padding: 8px 0;\r\n  scroll-behavior: smooth;\r\n}\r\n\r\n/* ─── Empty state ────────────────────────────────────────────── */\r\n\r\n.agent-empty-state {\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  justify-content: center;\r\n  padding: 30px 16px;\r\n  text-align: center;\r\n  gap: 8px;\r\n}\r\n\r\n.agent-empty-icon {\r\n  color: var(--jp-content-font-color2);\r\n  margin-bottom: 4px;\r\n}\r\n\r\n.agent-empty-title {\r\n  font-size: 13px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color1);\r\n  margin: 0;\r\n}\r\n\r\n.agent-empty-hint {\r\n  font-size: 11px;\r\n  color: var(--jp-content-font-color2);\r\n  line-height: 1.5;\r\n  margin: 0;\r\n  max-width: 220px;\r\n}\r\n\r\n.agent-example-prompts {\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 4px;\r\n  width: 100%;\r\n  max-width: 240px;\r\n  margin-top: 6px;\r\n}\r\n\r\n.agent-example-btn {\r\n  font-size: 11px;\r\n  padding: 5px 10px;\r\n  border: 1px solid var(--jp-border-color2);\r\n  border-radius: 6px;\r\n  background: var(--jp-layout-color2);\r\n  color: var(--jp-content-font-color1);\r\n  cursor: pointer;\r\n  text-align: left;\r\n  transition: background 0.15s, border-color 0.15s;\r\n  white-space: nowrap;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n}\r\n\r\n.agent-example-btn:hover:not(:disabled) {\r\n  background: var(--jp-layout-color3);\r\n  border-color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n/* ─── Individual messages ────────────────────────────────────── */\r\n\r\n.agent-message {\r\n  padding: 2px 0;\r\n}\r\n\r\n/* User bubble */\r\n.agent-user-bubble {\r\n  display: flex;\r\n  gap: 6px;\r\n  align-items: flex-start;\r\n  padding: 6px 10px;\r\n  margin: 2px 6px;\r\n  background: var(--jp-brand-color3, #e3f2fd);\r\n  border-radius: 8px;\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .agent-user-bubble {\r\n  background: #1e3a5f;\r\n}\r\n\r\n.agent-user-avatar {\r\n  font-size: 9px;\r\n  font-weight: 700;\r\n  padding: 2px 5px;\r\n  border-radius: 4px;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n  flex-shrink: 0;\r\n  margin-top: 1px;\r\n}\r\n\r\n.agent-user-content {\r\n  font-size: 12px;\r\n  line-height: 1.5;\r\n  color: var(--jp-content-font-color1);\r\n  white-space: pre-wrap;\r\n  word-break: break-word;\r\n}\r\n\r\n/* Agent text block */\r\n.agent-text-block {\r\n  display: flex;\r\n  gap: 6px;\r\n  align-items: flex-start;\r\n  padding: 4px 10px;\r\n}\r\n\r\n.agent-assistant-avatar {\r\n  color: var(--jp-brand-color1, #1976d2);\r\n  flex-shrink: 0;\r\n  margin-top: 2px;\r\n  display: flex;\r\n  align-items: center;\r\n}\r\n\r\n.agent-text-content {\r\n  flex: 1;\r\n  font-size: 12px;\r\n  line-height: 1.6;\r\n  color: var(--jp-content-font-color1);\r\n  min-width: 0;\r\n}\r\n\r\n/* Blinking cursor */\r\n.agent-cursor {\r\n  display: inline-block;\r\n  width: 2px;\r\n  height: 14px;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  margin-left: 2px;\r\n  vertical-align: text-bottom;\r\n  animation: agent-blink 1s step-end infinite;\r\n}\r\n\r\n@keyframes agent-blink {\r\n  0%, 100% { opacity: 1; }\r\n  50% { opacity: 0; }\r\n}\r\n\r\n/* ─── Tool call block ────────────────────────────────────────── */\r\n\r\n.agent-tool-call {\r\n  margin: 3px 10px;\r\n  border-radius: 6px;\r\n  border: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color2);\r\n  overflow: hidden;\r\n  font-size: 11px;\r\n}\r\n\r\n.agent-tool-call-running {\r\n  border-color: #f0a500;\r\n}\r\n\r\n.agent-tool-call-success {\r\n  border-color: var(--jp-border-color2);\r\n}\r\n\r\n.agent-tool-call-error {\r\n  border-color: #ef4444;\r\n  background: var(--jp-layout-color2);\r\n}\r\n\r\n/* Tool header button */\r\n.agent-tool-header {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 5px;\r\n  width: 100%;\r\n  padding: 5px 8px;\r\n  border: none;\r\n  background: transparent;\r\n  cursor: default;\r\n  text-align: left;\r\n  color: var(--jp-content-font-color1);\r\n  font-size: 11px;\r\n}\r\n\r\n.agent-tool-header[disabled] {\r\n  cursor: default;\r\n}\r\n\r\n.agent-tool-header:not([disabled]) {\r\n  cursor: pointer;\r\n}\r\n\r\n.agent-tool-header:not([disabled]):hover {\r\n  background: var(--jp-layout-color3);\r\n}\r\n\r\n/* Collapsed tool call summary */\r\n.agent-tool-summary {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  flex: 1;\r\n  min-width: 0;\r\n}\r\n\r\n.agent-tool-expand-hint {\r\n  font-size: 9px;\r\n  color: var(--jp-content-font-color2);\r\n  opacity: 0.7;\r\n  margin-left: auto;\r\n}\r\n\r\n/* Status dot */\r\n.agent-tool-status {\r\n  width: 7px;\r\n  height: 7px;\r\n  border-radius: 50%;\r\n  flex-shrink: 0;\r\n}\r\n\r\n.agent-tool-status-running {\r\n  animation: agent-pulse 1s ease-in-out infinite;\r\n}\r\n\r\n@keyframes agent-pulse {\r\n  0%, 100% { opacity: 1; }\r\n  50% { opacity: 0.4; }\r\n}\r\n\r\n/* Tool icon */\r\n.agent-tool-icon {\r\n  display: flex;\r\n  align-items: center;\r\n  color: var(--jp-content-font-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n/* Tool label */\r\n.agent-tool-label {\r\n  flex: 1;\r\n  font-weight: 500;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.agent-tool-duration {\r\n  font-size: 10px;\r\n  color: var(--jp-content-font-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.agent-tool-chevron {\r\n  font-size: 9px;\r\n  color: var(--jp-content-font-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.agent-tool-spinner {\r\n  display: flex;\r\n  align-items: center;\r\n  flex-shrink: 0;\r\n}\r\n\r\n/* Spinning animation */\r\n.agent-spinning {\r\n  animation: agent-spin 0.8s linear infinite;\r\n  color: #f0a500;\r\n}\r\n\r\n@keyframes agent-spin {\r\n  from { transform: rotate(0deg); }\r\n  to { transform: rotate(360deg); }\r\n}\r\n\r\n/* Args row */\r\n.agent-tool-args-row {\r\n  padding: 0 8px 5px 26px;\r\n}\r\n\r\n.agent-tool-args {\r\n  font-size: 10px;\r\n  color: var(--jp-content-font-color2);\r\n  font-style: italic;\r\n}\r\n\r\n.agent-tool-args-code {\r\n  font-family: var(--jp-code-font-family, monospace);\r\n  font-size: 10px;\r\n  background: var(--jp-layout-color3);\r\n  padding: 1px 4px;\r\n  border-radius: 3px;\r\n  color: var(--jp-content-font-color1);\r\n  display: block;\r\n  overflow-x: auto;\r\n  white-space: pre;\r\n  margin-right: 8px;\r\n}\r\n\r\n/* Expanded output */\r\n.agent-tool-output {\r\n  border-top: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color1);\r\n  max-height: 280px;\r\n  overflow-y: auto;\r\n}\r\n\r\n.agent-tool-output pre {\r\n  margin: 0;\r\n  padding: 8px 10px;\r\n  font-family: var(--jp-code-font-family, monospace);\r\n  font-size: 10px;\r\n  line-height: 1.5;\r\n  color: var(--jp-content-font-color1);\r\n  white-space: pre-wrap;\r\n  word-break: break-word;\r\n}\r\n\r\n.agent-tool-output-error pre {\r\n  color: #ef4444;\r\n}\r\n\r\n/* ─── Thinking indicator ─────────────────────────────────────── */\r\n\r\n.agent-thinking {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  padding: 8px 12px;\r\n  color: var(--jp-content-font-color2);\r\n  font-size: 11px;\r\n}\r\n\r\n.agent-thinking-dots {\r\n  display: flex;\r\n  gap: 4px;\r\n}\r\n\r\n.agent-thinking-dots span {\r\n  width: 5px;\r\n  height: 5px;\r\n  border-radius: 50%;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  animation: agent-bounce 1.2s ease-in-out infinite;\r\n}\r\n\r\n.agent-thinking-dots span:nth-child(2) { animation-delay: 0.15s; }\r\n.agent-thinking-dots span:nth-child(3) { animation-delay: 0.3s; }\r\n\r\n@keyframes agent-bounce {\r\n  0%, 80%, 100% { transform: scale(0.7); opacity: 0.5; }\r\n  40% { transform: scale(1); opacity: 1; }\r\n}\r\n\r\n.agent-thinking-label {\r\n  font-style: italic;\r\n}\r\n\r\n/* ─── Input area ─────────────────────────────────────────────── */\r\n\r\n.agent-input-area {\r\n  flex-shrink: 0;\r\n  border-top: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color1);\r\n  padding: 6px 8px 4px;\r\n}\r\n\r\n.agent-input-textarea {\r\n  width: 100%;\r\n  box-sizing: border-box;\r\n  padding: 7px 10px;\r\n  padding-right: 38px;\r\n  font-size: 12px;\r\n  font-family: var(--jp-content-font-family);\r\n  line-height: 1.5;\r\n  border: 1px solid var(--jp-border-color2);\r\n  border-radius: 8px;\r\n  background: var(--jp-layout-color2);\r\n  color: var(--jp-content-font-color1);\r\n  resize: none;\r\n  outline: none;\r\n  transition: border-color 0.15s;\r\n  min-height: 36px;\r\n  max-height: 150px;\r\n  overflow-y: auto;\r\n}\r\n\r\n.agent-input-textarea:focus {\r\n  border-color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.agent-input-textarea:disabled {\r\n  opacity: 0.5;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.agent-input-actions {\r\n  display: flex;\r\n  justify-content: flex-end;\r\n  margin-top: 4px;\r\n  gap: 4px;\r\n}\r\n\r\n.agent-send-btn,\r\n.agent-stop-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 30px;\r\n  height: 30px;\r\n  border: none;\r\n  border-radius: 6px;\r\n  cursor: pointer;\r\n  transition: background 0.15s;\r\n}\r\n\r\n.agent-send-btn {\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n}\r\n\r\n.agent-send-btn:hover:not(:disabled) {\r\n  background: var(--jp-brand-color0, #1565c0);\r\n}\r\n\r\n.agent-send-btn:disabled {\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color3);\r\n  cursor: not-allowed;\r\n}\r\n\r\n.agent-stop-btn {\r\n  background: #ef4444;\r\n  color: #fff;\r\n}\r\n\r\n.agent-stop-btn:hover {\r\n  background: #dc2626;\r\n}\r\n\r\n.agent-input-hint {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  font-size: 9px;\r\n  color: var(--jp-content-font-color3);\r\n  padding: 1px 2px 0;\r\n}\r\n\r\n.agent-cwd-label {\r\n  font-size: 9px;\r\n  color: var(--jp-content-font-color2);\r\n  background: var(--jp-layout-color2);\r\n  padding: 1px 5px;\r\n  border-radius: 3px;\r\n  max-width: 100px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/chat.css"
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/chat.css ***!
  \**************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/* LLM Assistant Chat Panel Styles */

/* ==============================================================================
   Chat Panel Container
   ============================================================================== */

.llm-chat-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  overflow: hidden;
}

/* ==============================================================================
   Header
   ============================================================================== */

.llm-chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border-bottom: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color0);
  flex-shrink: 0;
}

.llm-chat-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--jp-ui-font-color0);
  display: flex;
  align-items: center;
  gap: 8px;
}

.llm-chat-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.llm-icon-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: var(--jp-ui-font-color1);
  cursor: pointer;
  transition: background-color 0.2s, color 0.2s;
}

.llm-icon-btn:hover {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color0);
}

.llm-icon-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.llm-icon-btn.active {
  background-color: var(--jp-brand-color1);
  color: white;
}

/* ─── Header action buttons (chat header) ────────────────────── */

.llm-header-actions {
  display: flex;
  align-items: center;
  gap: 3px;
}

.llm-header-btn {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: var(--jp-content-font-color2);
  cursor: pointer;
  transition: background 0.15s, color 0.15s;
}

.llm-header-btn:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

.llm-header-btn.active {
  background: var(--jp-brand-color3, #e3f2fd);
  color: var(--jp-brand-color1, #1976d2);
}

body[data-jp-theme-light='false'] .llm-header-btn.active {
  background: #1e3a5f;
  color: var(--jp-brand-color1, #42a5f5);
}

/* Badge on context file button */
.llm-context-badge {
  position: absolute;
  top: 1px;
  right: 1px;
  min-width: 13px;
  height: 13px;
  line-height: 13px;
  text-align: center;
  font-size: 8px;
  font-weight: 700;
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
  border-radius: 7px;
  padding: 0 2px;
}

/* Button with active context files */
.llm-header-btn-has-context {
  color: var(--jp-brand-color1, #1976d2);
}

/* ─── Context active indicator bar ──────────────────────────── */

.llm-context-indicator {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  background: var(--jp-brand-color3, #e3f2fd);
  border-bottom: 1px solid var(--jp-brand-color2, #90caf9);
  font-size: 10px;
  color: var(--jp-brand-color1, #1976d2);
  cursor: pointer;
  flex-shrink: 0;
  transition: background 0.12s;
}

.llm-context-indicator:hover {
  background: var(--jp-brand-color2, #90caf9);
}

body[data-jp-theme-light='false'] .llm-context-indicator {
  background: #1a2d45;
  border-bottom-color: #2a4060;
  color: var(--jp-brand-color1, #42a5f5);
}

body[data-jp-theme-light='false'] .llm-context-indicator:hover {
  background: #1e3a5f;
}

/* ─── Agent input hint right side ────────────────────────────── */

.agent-input-hint-right {
  display: flex;
  align-items: center;
  gap: 4px;
}

/* ==============================================================================
   Mode Selector (InputArea footer + AgentPanel footer)
   ============================================================================== */

.llm-input-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 6px;
  gap: 8px;
}

.llm-mode-selector {
  position: relative;
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.llm-mode-selector-icon {
  color: var(--jp-ui-font-color2);
  flex-shrink: 0;
  pointer-events: none;
}

.llm-mode-select {
  /* Reset native appearance */
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;

  padding: 3px 22px 3px 6px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 5px;
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: 11px;
  font-weight: 500;
  cursor: pointer;
  outline: none;
  transition: border-color 0.15s, background-color 0.15s;
  min-width: 80px;
  max-width: 160px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.llm-mode-select:hover:not(:disabled) {
  background-color: var(--jp-layout-color3);
  border-color: var(--jp-brand-color1);
}

.llm-mode-select:focus {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.15);
}

.llm-mode-select:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Custom chevron overlay */
.llm-mode-select-chevron {
  position: absolute;
  right: 5px;
  color: var(--jp-ui-font-color2);
  pointer-events: none;
}

/* ==============================================================================
   @ Mention File Picker
   ============================================================================== */

.llm-mention-menu {
  position: relative;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: var(--jp-layout-color0);
  border: 1px solid var(--jp-border-color1);
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  margin-bottom: 6px;
  max-height: 220px;
  overflow-y: auto;
  z-index: 1000;
}

.llm-mention-item {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 7px 10px;
  cursor: pointer;
  font-size: 12px;
  transition: background-color 0.1s;
  border-bottom: 1px solid var(--jp-border-color2);
}

.llm-mention-item:last-of-type {
  border-bottom: none;
}

.llm-mention-item:hover,
.llm-mention-item.active {
  background-color: var(--jp-brand-color3, #e3f2fd);
  color: var(--jp-brand-color1, #1976d2);
}

body[data-jp-theme-light='false'] .llm-mention-item:hover,
body[data-jp-theme-light='false'] .llm-mention-item.active {
  background-color: #1a2d45;
  color: var(--jp-brand-color1, #42a5f5);
}

.llm-mention-icon {
  flex-shrink: 0;
  color: var(--jp-ui-font-color2);
  display: flex;
  align-items: center;
}

.llm-mention-label {
  font-weight: 500;
  flex-shrink: 0;
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.llm-mention-path {
  flex: 1;
  font-size: 10px;
  color: var(--jp-ui-font-color2);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  direction: rtl;
  text-align: left;
}

.llm-mention-loading,
.llm-mention-empty {
  padding: 10px 14px;
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  font-style: italic;
}

.llm-mention-hint {
  padding: 5px 10px;
  font-size: 10px;
  color: var(--jp-ui-font-color2);
  background-color: var(--jp-layout-color1);
  border-top: 1px solid var(--jp-border-color2);
  border-radius: 0 0 7px 7px;
}

/* Scrollbar in mention menu */
.llm-mention-menu::-webkit-scrollbar {
  width: 6px;
}
.llm-mention-menu::-webkit-scrollbar-thumb {
  background: var(--jp-scrollbar-thumb-color);
  border-radius: 3px;
}

/* ==============================================================================
   Message List
   ============================================================================== */

.llm-message-list {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.llm-message-list-empty {
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ==============================================================================
   Empty State
   ============================================================================== */

.llm-empty-state {
  text-align: center;
  padding: 32px;
  color: var(--jp-ui-font-color2);
}

.llm-empty-icon {
  margin-bottom: 16px;
  opacity: 0.6;
}

.llm-empty-state h3 {
  font-size: 18px;
  font-weight: 500;
  margin: 0 0 8px 0;
  color: var(--jp-ui-font-color1);
}

.llm-empty-state p {
  font-size: 14px;
  margin: 0 0 16px 0;
}

.llm-empty-hints {
  list-style: none;
  padding: 0;
  margin: 0;
  font-size: 13px;
}

.llm-empty-hints li {
  padding: 4px 0;
  position: relative;
  padding-left: 16px;
}

.llm-empty-hints li::before {
  content: "•";
  position: absolute;
  left: 0;
  color: var(--jp-brand-color1);
}

/* ==============================================================================
   Message Item
   ============================================================================== */

.llm-message-item {
  display: flex;
  gap: 12px;
  animation: llm-message-fade-in 0.2s ease-out;
}

@keyframes llm-message-fade-in {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.llm-message-item.user {
  flex-direction: row-reverse;
}

.llm-message-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 14px;
  font-weight: 600;
}

.llm-message-item.user .llm-message-avatar {
  background-color: var(--jp-brand-color1);
  color: white;
}

.llm-message-item.assistant .llm-message-avatar {
  background-color: var(--jp-accent-color1);
  color: white;
}

.llm-message-item.system .llm-message-avatar {
  background-color: var(--jp-warn-color1);
  color: white;
}

.llm-message-content {
  max-width: calc(100% - 56px);
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.llm-message-item.user .llm-message-content {
  align-items: flex-end;
}

.llm-message-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--jp-ui-font-color2);
}

.llm-message-role {
  font-weight: 500;
  color: var(--jp-ui-font-color1);
}

.llm-message-bubble {
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.6;
  word-break: break-word;
}

.llm-message-item.user .llm-message-bubble {
  background-color: var(--jp-brand-color1);
  color: white;
  border-bottom-right-radius: 4px;
}

.llm-message-item.assistant .llm-message-bubble,
.llm-message-item.system .llm-message-bubble {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  border-bottom-left-radius: 4px;
}

/* Error state */
.llm-message-item.error .llm-message-bubble {
  background-color: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
}

/* ==============================================================================
   Input Area
   ============================================================================== */

.llm-input-area {
  padding: 12px 16px;
  border-top: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color0);
  flex-shrink: 0;
}

.llm-image-previews {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 8px;
  padding: 8px;
  background-color: var(--jp-layout-color1);
  border-radius: 8px;
}

.llm-image-preview {
  position: relative;
  width: 80px;
  height: 80px;
  border-radius: 6px;
  overflow: hidden;
  border: 1px solid var(--jp-border-color1);
}

.llm-image-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.llm-image-remove {
  position: absolute;
  top: 2px;
  right: 2px;
  width: 20px;
  height: 20px;
  border: none;
  border-radius: 50%;
  background-color: rgba(0, 0, 0, 0.6);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  opacity: 0;
  transition: opacity 0.2s;
}

.llm-image-preview:hover .llm-image-remove {
  opacity: 1;
}

.llm-image-remove:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

.llm-input-row {
  display: flex;
  align-items: flex-end;
  gap: 8px;
}

.llm-image-btn,
.llm-send-btn {
  width: 36px;
  height: 36px;
  border: none;
  border-radius: 8px;
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-shrink: 0;
  transition: background-color 0.2s, color 0.2s;
}

.llm-image-btn:hover:not(:disabled),
.llm-send-btn:hover:not(:disabled) {
  background-color: var(--jp-layout-color3);
  color: var(--jp-ui-font-color0);
}

.llm-image-btn:disabled,
.llm-send-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.llm-send-btn:not(:disabled) {
  background-color: var(--jp-brand-color1);
  color: white;
}

.llm-send-btn:not(:disabled):hover {
  background-color: var(--jp-brand-color0);
}

.llm-text-input {
  flex: 1;
  min-height: 36px;
  max-height: 200px;
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 8px;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: 14px;
  line-height: 1.5;
  resize: none;
  outline: none;
  transition: border-color 0.2s;
}

.llm-text-input:focus {
  border-color: var(--jp-brand-color1);
}

.llm-text-input:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.llm-input-hint {
  text-align: center;
  margin-top: 8px;
  font-size: 11px;
  color: var(--jp-ui-font-color2);
}

/* ==============================================================================
   Loading Indicator
   ============================================================================== */

.llm-loading-indicator {
  display: flex;
  align-items: center;
  padding: 12px 16px;
}

.llm-loading-dots {
  display: flex;
  gap: 4px;
}

.llm-loading-dots span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: var(--jp-ui-font-color2);
  animation: llm-loading-bounce 1.4s ease-in-out infinite both;
}

.llm-loading-dots span:nth-child(1) {
  animation-delay: -0.32s;
}

.llm-loading-dots span:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes llm-loading-bounce {
  0%,
  80%,
  100% {
    transform: scale(0.6);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}

/* ==============================================================================
   Settings Panel
   ============================================================================== */

.llm-settings-panel {
  padding: 16px;
  overflow-y: auto;
  flex: 1;
}

.llm-settings-section {
  margin-bottom: 24px;
}

.llm-settings-section-title {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--jp-ui-font-color2);
  margin: 0 0 12px 0;
}

.llm-settings-field {
  margin-bottom: 16px;
}

.llm-settings-label {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  margin-bottom: 6px;
}

.llm-settings-description {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  margin: 4px 0 0 0;
}

.llm-settings-input,
.llm-settings-select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 6px;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: 13px;
  outline: none;
  transition: border-color 0.2s;
}

.llm-settings-input:focus,
.llm-settings-select:focus {
  border-color: var(--jp-brand-color1);
}

.llm-settings-checkbox-wrapper {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.llm-settings-checkbox {
  width: 16px;
  height: 16px;
  accent-color: var(--jp-brand-color1);
}

.llm-settings-checkbox-label {
  font-size: 13px;
  color: var(--jp-ui-font-color1);
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.llm-settings-checkbox-label input[type="checkbox"] {
  width: 16px;
  height: 16px;
  accent-color: var(--jp-brand-color1);
  cursor: pointer;
}

.llm-settings-actions {
  display: flex;
  gap: 8px;
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid var(--jp-border-color0);
}

.llm-settings-btn {
  flex: 1;
  padding: 10px 16px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
}

.llm-settings-btn-primary {
  background-color: var(--jp-brand-color1);
  color: white;
}

.llm-settings-btn-primary:hover:not(:disabled) {
  background-color: var(--jp-brand-color0);
}

.llm-settings-btn-secondary {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.llm-settings-btn-secondary:hover {
  background-color: var(--jp-layout-color3);
}

.llm-settings-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.llm-test-status {
  margin-top: 8px;
  padding: 8px 12px;
  border-radius: 6px;
  font-size: 12px;
}

.llm-test-status.success {
  background-color: var(--jp-success-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-test-status.error {
  background-color: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
}

/* ==============================================================================
   New Settings Panel Styles
   ============================================================================== */

.llm-settings-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 0 16px 0;
  border-bottom: 1px solid var(--jp-border-color0);
  margin-bottom: 16px;
}

.llm-settings-header h3 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--jp-ui-font-color0);
}

.llm-close-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  transition: background-color 0.2s, color 0.2s;
}

.llm-close-btn:hover {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color0);
}

.llm-settings-content {
  padding: 0;
}

.llm-section-title {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--jp-ui-font-color2);
  margin: 0 0 12px 0;
  padding-bottom: 8px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.llm-settings-section {
  margin-bottom: 24px;
}

.llm-settings-field {
  margin-bottom: 16px;
}

.llm-settings-field label {
  display: block;
  font-size: 13px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  margin-bottom: 6px;
}

.llm-settings-field input[type="text"],
.llm-settings-field input[type="password"],
.llm-settings-field input[type="number"],
.llm-settings-field select,
.llm-settings-field textarea {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 6px;
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: 13px;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.llm-settings-field input:focus,
.llm-settings-field select:focus,
.llm-settings-field textarea:focus {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 2px rgba(19, 124, 189, 0.2);
}

.llm-input-with-button {
  display: flex;
  gap: 8px;
}

.llm-api-key-input {
  flex: 1;
}

.llm-toggle-visibility-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 6px;
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  cursor: pointer;
  transition: background-color 0.2s;
}

.llm-toggle-visibility-btn:hover {
  background-color: var(--jp-layout-color3);
}

.llm-settings-field input[type="range"] {
  width: 100%;
  height: 6px;
  border-radius: 3px;
  background: var(--jp-layout-color3);
  outline: none;
  -webkit-appearance: none;
}

.llm-settings-field input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--jp-brand-color1);
  cursor: pointer;
}

.llm-settings-hint {
  font-size: 11px;
  color: var(--jp-ui-font-color2);
  margin: 6px 0 0 0;
}

.llm-settings-hint code {
  background-color: var(--jp-layout-color3);
  padding: 2px 4px;
  border-radius: 3px;
  font-family: var(--jp-code-font-family);
}

.llm-settings-toggle label {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-weight: 500;
}

.llm-settings-toggle input[type="checkbox"] {
  width: 16px;
  height: 16px;
  accent-color: var(--jp-brand-color1);
  cursor: pointer;
}

.llm-api-key-status {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  border-radius: 6px;
  font-size: 13px;
  margin-bottom: 8px;
}

.llm-status-ok {
  background-color: var(--jp-success-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-status-error {
  background-color: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-test-btn {
  width: 100%;
  padding: 10px 16px;
  border: none;
  border-radius: 6px;
  background-color: var(--jp-brand-color1);
  color: white;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.llm-test-btn:hover:not(:disabled) {
  background-color: var(--jp-brand-color0);
}

.llm-test-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.llm-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: white;
  border-radius: 50%;
  animation: llm-spin 0.8s linear infinite;
}

@keyframes llm-spin {
  to {
    transform: rotate(360deg);
  }
}

.llm-test-result {
  margin-top: 12px;
  padding: 10px 12px;
  border-radius: 6px;
  font-size: 13px;
}

.llm-test-success {
  background-color: var(--jp-success-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-test-error {
  background-color: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-settings-footer {
  display: flex;
  gap: 12px;
  padding: 16px 0 0 0;
  border-top: 1px solid var(--jp-border-color0);
  margin-top: 24px;
}

.llm-cancel-btn,
.llm-save-btn {
  flex: 1;
  padding: 10px 16px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
}

.llm-cancel-btn {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.llm-cancel-btn:hover {
  background-color: var(--jp-layout-color3);
}

.llm-save-btn {
  background-color: var(--jp-brand-color1);
  color: white;
}

.llm-save-btn:hover:not(:disabled) {
  background-color: var(--jp-brand-color0);
}

.llm-save-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.llm-value {
  font-weight: 600;
  color: var(--jp-brand-color1);
}

/* ==============================================================================
   Markdown Content
   ============================================================================== */

.llm-markdown-content {
  line-height: 1.6;
}

.llm-markdown-content *:first-child {
  margin-top: 0;
}

.llm-markdown-content *:last-child {
  margin-bottom: 0;
}

.llm-md-paragraph {
  margin: 8px 0;
}

.llm-md-link {
  color: var(--jp-link-color);
  text-decoration: none;
}

.llm-md-link:hover {
  text-decoration: underline;
}

.llm-md-code-inline {
  font-family: var(--jp-code-font-family);
  font-size: 0.9em;
  padding: 2px 6px;
  background-color: var(--jp-layout-color3);
  border-radius: 4px;
  color: var(--jp-content-font-color1);
}

.llm-message-item.user .llm-md-code-inline {
  background-color: rgba(255, 255, 255, 0.2);
  color: inherit;
}

.llm-md-list {
  margin: 8px 0;
  padding-left: 24px;
}

.llm-md-list-ordered {
  list-style-type: decimal;
}

.llm-md-list-item {
  margin: 4px 0;
}

.llm-md-heading {
  font-weight: 600;
  margin: 16px 0 8px 0;
  color: var(--jp-content-font-color0);
}

.llm-message-item.user .llm-md-heading {
  color: inherit;
}

.llm-md-heading-1 {
  font-size: 1.5em;
  border-bottom: 1px solid var(--jp-border-color1);
  padding-bottom: 8px;
}

.llm-md-heading-2 {
  font-size: 1.3em;
}

.llm-md-heading-3 {
  font-size: 1.1em;
}

.llm-md-heading-4,
.llm-md-heading-5,
.llm-md-heading-6 {
  font-size: 1em;
}

.llm-md-blockquote {
  margin: 8px 0;
  padding: 8px 16px;
  border-left: 4px solid var(--jp-brand-color1);
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
}

.llm-md-table-wrapper {
  overflow-x: auto;
  margin: 8px 0;
}

.llm-md-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.llm-md-th,
.llm-md-td {
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color1);
  text-align: left;
}

.llm-md-th {
  background-color: var(--jp-layout-color2);
  font-weight: 600;
}

/* ==============================================================================
   Think Block - Collapsible thinking content
   ============================================================================== */

.llm-think-block {
  margin: 12px 0;
  border-radius: 8px;
  overflow: hidden;
  background-color: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color1);
}

.llm-think-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background-color: var(--jp-layout-color3);
  border: none;
  width: 100%;
  cursor: pointer;
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  transition: background-color 0.15s;
}

.llm-think-header:hover {
  background-color: var(--jp-layout-color2);
}

.llm-think-icon {
  display: flex;
  align-items: center;
  color: var(--jp-brand-color1);
}

.llm-think-label {
  flex: 1;
  font-weight: 500;
  text-align: left;
}

.llm-think-chevron {
  font-size: 10px;
  opacity: 0.7;
}

.llm-think-content {
  padding: 12px;
  font-size: 13px;
  line-height: 1.6;
  color: var(--jp-ui-font-color2);
  border-top: 1px solid var(--jp-border-color1);
}

.llm-think-content p {
  margin: 0 0 8px 0;
}

.llm-think-content p:last-child {
  margin-bottom: 0;
}

/* ==============================================================================
   Code Block
   ============================================================================== */

.llm-code-block {
  margin: 12px 0;
  border-radius: 8px;
  overflow: hidden;
  background-color: var(--jp-cell-editor-background);
  border: 1px solid var(--jp-border-color1);
}

.llm-code-block-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  background-color: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color1);
}

.llm-code-language {
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  color: var(--jp-ui-font-color2);
}

.llm-code-copy-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  border: none;
  border-radius: 4px;
  background-color: transparent;
  color: var(--jp-ui-font-color2);
  font-size: 11px;
  cursor: pointer;
  transition: background-color 0.2s, color 0.2s;
}

.llm-code-copy-btn:hover {
  background-color: var(--jp-layout-color3);
  color: var(--jp-ui-font-color0);
}

.llm-code-copy-btn.copied {
  color: var(--jp-success-color1);
}

.llm-code-block pre {
  margin: 0;
  padding: 16px;
  overflow-x: auto;
  font-family: var(--jp-code-font-family);
  font-size: 13px;
  line-height: 1.5;
}

.llm-code-block code {
  font-family: var(--jp-code-font-family);
}

/* ==============================================================================
   Image in Message
   ============================================================================== */

.llm-message-image {
  max-width: 100%;
  max-height: 300px;
  border-radius: 8px;
  margin: 8px 0;
}

/* ==============================================================================
   Scrollbar Styling
   ============================================================================== */

.llm-chat-panel ::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.llm-chat-panel ::-webkit-scrollbar-track {
  background: transparent;
}

.llm-chat-panel ::-webkit-scrollbar-thumb {
  background: var(--jp-scrollbar-thumb-color);
  border-radius: 4px;
}

.llm-chat-panel ::-webkit-scrollbar-thumb:hover {
  background: var(--jp-scrollbar-thumb-hover-color);
}

/* ==============================================================================
   Responsive Adjustments
   ============================================================================== */

@media (max-width: 400px) {
  .llm-message-content {
    max-width: calc(100% - 48px);
  }

  .llm-message-avatar {
    width: 28px;
    height: 28px;
    font-size: 12px;
  }

  .llm-input-area {
    padding: 8px 12px;
  }
}

/* ==============================================================================
   Unified Panel Layout (v0.7.0)
   ============================================================================== */

.llm-unified-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.llm-mode-viewport {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

/* Override input area inside the unified panel — no top padding duplication */
.llm-unified-panel .llm-input-area {
  flex-shrink: 0;
}

/* ── Large textarea ──────────────────────────────────────────────────────── */

.llm-text-input-large {
  width: 100%;
  min-height: 120px;
  max-height: 400px;
  resize: none;
  overflow-y: auto;
  border: 1px solid var(--jp-border-color1);
  border-radius: 8px;
  padding: 10px 12px;
  font-family: var(--jp-ui-font-family);
  font-size: 13px;
  line-height: 1.5;
  color: var(--jp-ui-font-color1);
  background-color: var(--jp-layout-color0);
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s;
  box-sizing: border-box;
}

.llm-text-input-large:focus {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.12);
}

.llm-text-input-large:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  background-color: var(--jp-layout-color2);
}

.llm-text-input-large::placeholder {
  color: var(--jp-ui-font-color3);
  font-size: 12px;
}

/* ── Toolbar at bottom of InputArea ─────────────────────────────────────── */

.llm-input-toolbar {
  display: flex;
  align-items: center;
  gap: 6px;
}

.llm-input-hint-text {
  flex: 1;
  font-size: 10px;
  color: var(--jp-ui-font-color3);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.llm-input-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.llm-toolbar-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  padding: 0;
  border: 1px solid transparent;
  border-radius: 6px;
  background: transparent;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  transition: background-color 0.1s, color 0.1s, border-color 0.1s;
}

.llm-toolbar-btn:hover:not(:disabled) {
  background-color: var(--jp-layout-color3);
  color: var(--jp-ui-font-color1);
  border-color: var(--jp-border-color1);
}

.llm-toolbar-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

/* ── Path attachment chips ──────────────────────────────────────────────── */

.llm-attached-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  padding: 2px 0;
}

.llm-chip {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 3px 7px 3px 6px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: 500;
  border: 1px solid var(--jp-border-color1);
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  max-width: 200px;
  overflow: hidden;
}

.llm-chip-file {
  border-color: var(--jp-brand-color2, #64b5f6);
}

.llm-chip-dir {
  border-color: var(--jp-warn-color2, #ffb74d);
}

.llm-chip-icon {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  opacity: 0.8;
}

.llm-chip-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.llm-chip-remove {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: none;
  border-radius: 50%;
  background: transparent;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  opacity: 0.7;
  transition: opacity 0.1s, background-color 0.1s;
}

.llm-chip-remove:hover {
  opacity: 1;
  background-color: rgba(0,0,0,0.12);
}

/* ── @ mention: breadcrumb header for drill-down ───────────────────────── */

.llm-mention-breadcrumb {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 5px 10px;
  background-color: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  border-radius: 7px 7px 0 0;
}

.llm-mention-breadcrumb-back {
  display: flex;
  align-items: center;
  padding: 2px 4px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: transparent;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  transition: background-color 0.1s;
}

.llm-mention-breadcrumb-back:hover {
  background-color: var(--jp-layout-color3);
}

.llm-mention-breadcrumb-path {
  font-size: 11px;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Attach-dir button that appears on hover over a directory item */
.llm-mention-attach-dir {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 1px solid transparent;
  border-radius: 4px;
  background: transparent;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  margin-left: auto;
  opacity: 0;
  transition: opacity 0.1s, background-color 0.1s, border-color 0.1s;
}

.llm-mention-item:hover .llm-mention-attach-dir,
.llm-mention-item.active .llm-mention-attach-dir {
  opacity: 1;
}

.llm-mention-attach-dir:hover {
  background-color: var(--jp-brand-color3, #e3f2fd);
  border-color: var(--jp-brand-color1);
  color: var(--jp-brand-color1);
}

/* ── Agent running bar (replaces inline input) ──────────────────── */

.agent-running-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background-color: var(--jp-layout-color2);
  border-top: 1px solid var(--jp-border-color1);
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  flex-shrink: 0;
}

.agent-running-bar .agent-stop-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px;
  margin-left: auto;
  border: 1px solid var(--jp-warn-color1, #ff9800);
  border-radius: 5px;
  background: transparent;
  color: var(--jp-warn-color1, #ff9800);
  font-size: 11px;
  cursor: pointer;
  transition: background-color 0.1s;
}

.agent-running-bar .agent-stop-btn:hover {
  background-color: rgba(255, 152, 0, 0.1);
}

/* ── Agent action area (no internal textarea) ────────────────────────────── */



/* ==============================================================================
   Unified Message List (v0.8.0)
   ============================================================================== */

/* Mode badges for messages */
.llm-mode-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 500;
  background: var(--jp-layout-color3);
  color: var(--jp-ui-font-color2);
}

.llm-mode-badge-chat {
  background: var(--jp-brand-color3, #e3f2fd);
  color: var(--jp-brand-color1, #1976d2);
}

.llm-mode-badge-agent {
  background: #e8f5e9;
  color: #e65100;
}

body[data-jp-theme-light='false'] .llm-mode-badge-chat {
  background: #1e3a5f;
  color: var(--jp-brand-color1, #42a5f5);
}

body[data-jp-theme-light='false'] .llm-mode-badge-agent {
  background: #1b3d1b;
  background: #3d2815;
  color: #ffb74d;
}

/* Agent message content */
.llm-message-agent-content {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.llm-message-tool-calls {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.llm-message-iteration {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 6px;
}

.llm-iteration-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  font-weight: 500;
  color: var(--jp-brand-color1, #1976d2);
  background: var(--jp-brand-color3, #e3f2fd);
  padding: 3px 10px;
  border-radius: 12px;
  border: 1px solid var(--jp-brand-color2, #90caf9);
  animation: llm-iteration-pulse 2s ease-in-out infinite;
}

body[data-jp-theme-light='false'] .llm-iteration-badge {
  background: #1e3a5f;
  border-color: var(--jp-brand-color1, #42a5f5);
  color: var(--jp-brand-color1, #42a5f5);
}

@keyframes llm-iteration-pulse {
  0%, 100% { opacity: 0.8; }
  50% { opacity: 1; }
}

.llm-iteration-badge::before {
  content: '';
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--jp-brand-color1, #1976d2);
  animation: llm-iteration-dot 1.4s ease-in-out infinite;
}

@keyframes llm-iteration-dot {
  0%, 100% { transform: scale(0.8); opacity: 0.5; }
  50% { transform: scale(1.2); opacity: 1; }
}

.llm-iteration-active {
  animation: llm-iteration-pulse 2s ease-in-out infinite;
}

.llm-iteration-active::before {
  content: '';
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--jp-brand-color1, #1976d2);
  animation: llm-iteration-dot 1.4s ease-in-out infinite;
}

.llm-iteration-complete {
  opacity: 0.7;
  background: var(--jp-layout-color2);
  border-color: var(--jp-border-color2);
  color: var(--jp-ui-font-color2);
}

.llm-iteration-complete::before {
  content: '';
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #22c55e;
  animation: none;
}

/* Iteration badge as a button */
.llm-iteration-badge {
  cursor: pointer;
  user-select: none;
  transition: background-color 0.15s, transform 0.1s;
}

.llm-iteration-badge:hover:not(:disabled) {
  background: var(--jp-brand-color2, #90caf9);
}

.llm-iteration-badge:disabled {
  cursor: default;
  opacity: 0.8;
}

.llm-iteration-chevron {
  margin-left: 4px;
  font-size: 10px;
  opacity: 0.7;
}

.llm-model-indicator {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color0);
  font-size: 12px;
}

.llm-model-name {
  font-weight: 600;
  color: var(--jp-ui-font-color0);
}

.llm-api-warning {
  color: var(--jp-error-color1);
  font-size: 11px;
}

/* Unified panel */
.llm-unified-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
}

/* Thinking dots for loading */
.llm-thinking-dots {
  display: inline-flex;
  gap: 4px;
}

.llm-thinking-dots span {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--jp-ui-font-color2);
  animation: llm-thinking-bounce 1.4s ease-in-out infinite both;
}

.llm-thinking-dots span:nth-child(1) {
  animation-delay: -0.32s;
}

.llm-thinking-dots span:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes llm-thinking-bounce {
  0%, 80%, 100% {
    transform: scale(0.6);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}

/* Error banner */
.llm-error-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 8px 12px;
  background: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
  font-size: 13px;
}

.llm-error-banner button {
  background: transparent;
  border: none;
  color: inherit;
  cursor: pointer;
  padding: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Message loading state */
.llm-message-loading {
  opacity: 0.7;
}

/* ==============================================================================
   Session Panel
   ============================================================================== */

.llm-session-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--jp-layout-color1);
}

.llm-session-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border-bottom: 1px solid var(--jp-border-color1);
}

.llm-session-header h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.llm-session-content {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}

.llm-session-empty {
  text-align: center;
  padding: 32px 16px;
  color: var(--jp-ui-font-color2);
}

.llm-session-empty .llm-hint {
  font-size: 12px;
  margin-top: 8px;
  opacity: 0.7;
}

.llm-session-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.llm-session-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.15s;
  border: 1px solid transparent;
}

.llm-session-item:hover {
  background: var(--jp-layout-color2);
  border-color: var(--jp-border-color1);
}

.llm-session-info {
  flex: 1;
  min-width: 0;
}

.llm-session-title {
  font-size: 13px;
  font-weight: 500;
  margin-bottom: 4px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.llm-session-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 11px;
  color: var(--jp-ui-font-color2);
}

.llm-session-mode {
  padding: 2px 6px;
  border-radius: 3px;
  background: var(--jp-layout-color3);
  text-transform: uppercase;
  font-weight: 500;
}

.llm-session-mode.llm-mode-chat {
  background: var(--jp-info-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-session-mode.llm-mode-agent {
  background: var(--jp-success-color0);
  color: var(--jp-ui-inverse-font-color0);
}


.llm-session-count {
  opacity: 0.8;
}

.llm-session-date {
  opacity: 0.6;
}

.llm-session-delete {
  background: transparent;
  border: none;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.15s, background 0.15s;
}

.llm-session-item:hover .llm-session-delete {
  opacity: 1;
}

.llm-session-delete:hover {
  background: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-session-error {
  padding: 16px;
  text-align: center;
  color: var(--jp-error-color0);
}

.llm-session-error button {
  margin-top: 8px;
  padding: 6px 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: var(--jp-layout-color2);
  cursor: pointer;
}

.llm-loading {
  padding: 32px;
  text-align: center;
  color: var(--jp-ui-font-color2);
}

/* Session Panel Header Actions */
.llm-session-header-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.llm-new-session-btn {
  color: var(--jp-brand-color1);
}

.llm-new-session-btn:hover {
  background: var(--jp-brand-color0);
  color: var(--jp-ui-inverse-font-color0);
}

/* Project Directory Section */
.llm-rootdir-section {
  padding: 12px 16px;
  border-bottom: 1px solid var(--jp-border-color0);
  background: var(--jp-layout-color0);
}

.llm-rootdir-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}

.llm-rootdir-label {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: var(--jp-ui-font-color2);
}

.llm-rootdir-edit-btn {
  background: transparent;
  border: none;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  padding: 2px 4px;
  border-radius: 3px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: color 0.15s, background 0.15s;
}

.llm-rootdir-edit-btn:hover {
  color: var(--jp-brand-color1);
  background: var(--jp-layout-color2);
}

.llm-rootdir-path {
  font-size: 12px;
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-code-font-family);
  word-break: break-all;
  opacity: 0.8;
}

.llm-rootdir-edit {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.llm-rootdir-input {
  width: 100%;
  padding: 6px 10px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-family: var(--jp-code-font-family);
  font-size: 12px;
  outline: none;
}

.llm-rootdir-input:focus {
  border-color: var(--jp-brand-color1);
}

.llm-rootdir-actions {
  display: flex;
  gap: 8px;
}

.llm-rootdir-save,
.llm-rootdir-cancel {
  flex: 1;
  padding: 6px 12px;
  border: none;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.15s;
}

.llm-rootdir-save {
  background-color: var(--jp-brand-color1);
  color: white;
}

.llm-rootdir-save:hover {
  background-color: var(--jp-brand-color0);
}

.llm-rootdir-cancel {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.llm-rootdir-cancel:hover {
  background-color: var(--jp-layout-color3);
}
`, "",{"version":3,"sources":["webpack://./style/chat.css"],"names":[],"mappings":"AAAA,oCAAoC;;AAEpC;;mFAEmF;;AAEnF;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,yCAAyC;EACzC,+BAA+B;EAC/B,qCAAqC;EACrC,gBAAgB;AAClB;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,kBAAkB;EAClB,gDAAgD;EAChD,yCAAyC;EACzC,cAAc;AAChB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,6CAA6C;AAC/C;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,uBAAuB;EACvB,oCAAoC;EACpC,eAAe;EACf,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,2CAA2C;EAC3C,sCAAsC;AACxC;;AAEA;EACE,mBAAmB;EACnB,sCAAsC;AACxC;;AAEA,iCAAiC;AACjC;EACE,kBAAkB;EAClB,QAAQ;EACR,UAAU;EACV,eAAe;EACf,YAAY;EACZ,iBAAiB;EACjB,kBAAkB;EAClB,cAAc;EACd,gBAAgB;EAChB,2CAA2C;EAC3C,WAAW;EACX,kBAAkB;EAClB,cAAc;AAChB;;AAEA,qCAAqC;AACrC;EACE,sCAAsC;AACxC;;AAEA,kEAAkE;;AAElE;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,2CAA2C;EAC3C,wDAAwD;EACxD,eAAe;EACf,sCAAsC;EACtC,eAAe;EACf,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,mBAAmB;EACnB,4BAA4B;EAC5B,sCAAsC;AACxC;;AAEA;EACE,mBAAmB;AACrB;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,eAAe;EACf,QAAQ;AACV;;AAEA;EACE,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,cAAc;AAChB;;AAEA;EACE,+BAA+B;EAC/B,cAAc;EACd,oBAAoB;AACtB;;AAEA;EACE,4BAA4B;EAC5B,wBAAwB;EACxB,qBAAqB;EACrB,gBAAgB;;EAEhB,yBAAyB;EACzB,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;EACzC,+BAA+B;EAC/B,qCAAqC;EACrC,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,aAAa;EACb,sDAAsD;EACtD,eAAe;EACf,gBAAgB;EAChB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,yCAAyC;EACzC,oCAAoC;AACtC;;AAEA;EACE,oCAAoC;EACpC,8CAA8C;AAChD;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,2BAA2B;AAC3B;EACE,kBAAkB;EAClB,UAAU;EACV,+BAA+B;EAC/B,oBAAoB;AACtB;;AAEA;;mFAEmF;;AAEnF;EACE,kBAAkB;EAClB,SAAS;EACT,OAAO;EACP,QAAQ;EACR,yCAAyC;EACzC,yCAAyC;EACzC,kBAAkB;EAClB,0CAA0C;EAC1C,kBAAkB;EAClB,iBAAiB;EACjB,gBAAgB;EAChB,aAAa;AACf;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,eAAe;EACf,eAAe;EACf,iCAAiC;EACjC,gDAAgD;AAClD;;AAEA;EACE,mBAAmB;AACrB;;AAEA;;EAEE,iDAAiD;EACjD,sCAAsC;AACxC;;AAEA;;EAEE,yBAAyB;EACzB,sCAAsC;AACxC;;AAEA;EACE,cAAc;EACd,+BAA+B;EAC/B,aAAa;EACb,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;EAChB,cAAc;EACd,gBAAgB;EAChB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,OAAO;EACP,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;EACnB,cAAc;EACd,gBAAgB;AAClB;;AAEA;;EAEE,kBAAkB;EAClB,eAAe;EACf,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,iBAAiB;EACjB,eAAe;EACf,+BAA+B;EAC/B,yCAAyC;EACzC,6CAA6C;EAC7C,0BAA0B;AAC5B;;AAEA,8BAA8B;AAC9B;EACE,UAAU;AACZ;AACA;EACE,2CAA2C;EAC3C,kBAAkB;AACpB;;AAEA;;mFAEmF;;AAEnF;EACE,OAAO;EACP,gBAAgB;EAChB,aAAa;EACb,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;;mFAEmF;;AAEnF;EACE,kBAAkB;EAClB,aAAa;EACb,+BAA+B;AACjC;;AAEA;EACE,mBAAmB;EACnB,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,iBAAiB;EACjB,+BAA+B;AACjC;;AAEA;EACE,eAAe;EACf,kBAAkB;AACpB;;AAEA;EACE,gBAAgB;EAChB,UAAU;EACV,SAAS;EACT,eAAe;AACjB;;AAEA;EACE,cAAc;EACd,kBAAkB;EAClB,kBAAkB;AACpB;;AAEA;EACE,YAAY;EACZ,kBAAkB;EAClB,OAAO;EACP,6BAA6B;AAC/B;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,SAAS;EACT,4CAA4C;AAC9C;;AAEA;EACE;IACE,UAAU;IACV,0BAA0B;EAC5B;EACA;IACE,UAAU;IACV,wBAAwB;EAC1B;AACF;;AAEA;EACE,2BAA2B;AAC7B;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;EACd,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,yCAAyC;EACzC,YAAY;AACd;;AAEA;EACE,uCAAuC;EACvC,YAAY;AACd;;AAEA;EACE,4BAA4B;EAC5B,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,qBAAqB;AACvB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,kBAAkB;EAClB,mBAAmB;EACnB,eAAe;EACf,gBAAgB;EAChB,sBAAsB;AACxB;;AAEA;EACE,wCAAwC;EACxC,YAAY;EACZ,+BAA+B;AACjC;;AAEA;;EAEE,yCAAyC;EACzC,+BAA+B;EAC/B,8BAA8B;AAChC;;AAEA,gBAAgB;AAChB;EACE,wCAAwC;EACxC,uCAAuC;AACzC;;AAEA;;mFAEmF;;AAEnF;EACE,kBAAkB;EAClB,6CAA6C;EAC7C,yCAAyC;EACzC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,eAAe;EACf,QAAQ;EACR,kBAAkB;EAClB,YAAY;EACZ,yCAAyC;EACzC,kBAAkB;AACpB;;AAEA;EACE,kBAAkB;EAClB,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,gBAAgB;EAChB,yCAAyC;AAC3C;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,iBAAiB;AACnB;;AAEA;EACE,kBAAkB;EAClB,QAAQ;EACR,UAAU;EACV,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,oCAAoC;EACpC,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,UAAU;EACV,wBAAwB;AAC1B;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,aAAa;EACb,qBAAqB;EACrB,QAAQ;AACV;;AAEA;;EAEE,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,yCAAyC;EACzC,+BAA+B;EAC/B,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,cAAc;EACd,6CAA6C;AAC/C;;AAEA;;EAEE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;;EAEE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,iBAAiB;EACjB,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;EACzC,+BAA+B;EAC/B,qCAAqC;EACrC,eAAe;EACf,gBAAgB;EAChB,YAAY;EACZ,aAAa;EACb,6BAA6B;AAC/B;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,eAAe;EACf,eAAe;EACf,+BAA+B;AACjC;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,0CAA0C;EAC1C,4DAA4D;AAC9D;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE;;;IAGE,qBAAqB;IACrB,YAAY;EACd;EACA;IACE,mBAAmB;IACnB,UAAU;EACZ;AACF;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,gBAAgB;EAChB,OAAO;AACT;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,yBAAyB;EACzB,qBAAqB;EACrB,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,iBAAiB;AACnB;;AAEA;;EAEE,WAAW;EACX,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;EACzC,+BAA+B;EAC/B,qCAAqC;EACrC,eAAe;EACf,aAAa;EACb,6BAA6B;AAC/B;;AAEA;;EAEE,oCAAoC;AACtC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,oCAAoC;EACpC,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,gBAAgB;EAChB,iBAAiB;EACjB,6CAA6C;AAC/C;;AAEA;EACE,OAAO;EACP,kBAAkB;EAClB,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,iCAAiC;AACnC;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,iBAAiB;EACjB,kBAAkB;EAClB,eAAe;AACjB;;AAEA;EACE,0CAA0C;EAC1C,uCAAuC;AACzC;;AAEA;EACE,wCAAwC;EACxC,uCAAuC;AACzC;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,mBAAmB;EACnB,gDAAgD;EAChD,mBAAmB;AACrB;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,6CAA6C;AAC/C;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,yBAAyB;EACzB,qBAAqB;EACrB,+BAA+B;EAC/B,kBAAkB;EAClB,mBAAmB;EACnB,gDAAgD;AAClD;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;;;;;EAKE,WAAW;EACX,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;EACzC,+BAA+B;EAC/B,qCAAqC;EACrC,eAAe;EACf,aAAa;EACb,8CAA8C;AAChD;;AAEA;;;EAGE,oCAAoC;EACpC,6CAA6C;AAC/C;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,OAAO;AACT;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,kBAAkB;EAClB,yCAAyC;EACzC,+BAA+B;EAC/B,eAAe;EACf,iCAAiC;AACnC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,WAAW;EACX,WAAW;EACX,kBAAkB;EAClB,mCAAmC;EACnC,aAAa;EACb,wBAAwB;AAC1B;;AAEA;EACE,wBAAwB;EACxB,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,kCAAkC;EAClC,eAAe;AACjB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,iBAAiB;AACnB;;AAEA;EACE,yCAAyC;EACzC,gBAAgB;EAChB,kBAAkB;EAClB,uCAAuC;AACzC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,oCAAoC;EACpC,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,kBAAkB;EAClB,kBAAkB;EAClB,eAAe;EACf,kBAAkB;AACpB;;AAEA;EACE,0CAA0C;EAC1C,uCAAuC;AACzC;;AAEA;EACE,wCAAwC;EACxC,uCAAuC;AACzC;;AAEA;EACE,WAAW;EACX,kBAAkB;EAClB,YAAY;EACZ,kBAAkB;EAClB,wCAAwC;EACxC,YAAY;EACZ,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,iCAAiC;EACjC,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,QAAQ;AACV;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,0CAA0C;EAC1C,uBAAuB;EACvB,kBAAkB;EAClB,wCAAwC;AAC1C;;AAEA;EACE;IACE,yBAAyB;EAC3B;AACF;;AAEA;EACE,gBAAgB;EAChB,kBAAkB;EAClB,kBAAkB;EAClB,eAAe;AACjB;;AAEA;EACE,0CAA0C;EAC1C,uCAAuC;AACzC;;AAEA;EACE,wCAAwC;EACxC,uCAAuC;AACzC;;AAEA;EACE,aAAa;EACb,SAAS;EACT,mBAAmB;EACnB,6CAA6C;EAC7C,gBAAgB;AAClB;;AAEA;;EAEE,OAAO;EACP,kBAAkB;EAClB,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,iCAAiC;AACnC;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;EAChB,6BAA6B;AAC/B;;AAEA;;mFAEmF;;AAEnF;EACE,gBAAgB;AAClB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,2BAA2B;EAC3B,qBAAqB;AACvB;;AAEA;EACE,0BAA0B;AAC5B;;AAEA;EACE,uCAAuC;EACvC,gBAAgB;EAChB,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,oCAAoC;AACtC;;AAEA;EACE,0CAA0C;EAC1C,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,kBAAkB;AACpB;;AAEA;EACE,wBAAwB;AAC1B;;AAEA;EACE,aAAa;AACf;;AAEA;EACE,gBAAgB;EAChB,oBAAoB;EACpB,oCAAoC;AACtC;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,gBAAgB;EAChB,gDAAgD;EAChD,mBAAmB;AACrB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;;;EAGE,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,iBAAiB;EACjB,6CAA6C;EAC7C,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;EAChB,aAAa;AACf;;AAEA;EACE,WAAW;EACX,yBAAyB;EACzB,eAAe;AACjB;;AAEA;;EAEE,iBAAiB;EACjB,yCAAyC;EACzC,gBAAgB;AAClB;;AAEA;EACE,yCAAyC;EACzC,gBAAgB;AAClB;;AAEA;;mFAEmF;;AAEnF;EACE,cAAc;EACd,kBAAkB;EAClB,gBAAgB;EAChB,yCAAyC;EACzC,yCAAyC;AAC3C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,yCAAyC;EACzC,YAAY;EACZ,WAAW;EACX,eAAe;EACf,eAAe;EACf,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,6BAA6B;AAC/B;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,gBAAgB;AAClB;;AAEA;EACE,eAAe;EACf,YAAY;AACd;;AAEA;EACE,aAAa;EACb,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,6CAA6C;AAC/C;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,gBAAgB;AAClB;;AAEA;;mFAEmF;;AAEnF;EACE,cAAc;EACd,kBAAkB;EAClB,gBAAgB;EAChB,kDAAkD;EAClD,yCAAyC;AAC3C;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,yCAAyC;EACzC,gDAAgD;AAClD;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,yBAAyB;EACzB,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,gBAAgB;EAChB,YAAY;EACZ,kBAAkB;EAClB,6BAA6B;EAC7B,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,6CAA6C;AAC/C;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,SAAS;EACT,aAAa;EACb,gBAAgB;EAChB,uCAAuC;EACvC,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,uCAAuC;AACzC;;AAEA;;mFAEmF;;AAEnF;EACE,eAAe;EACf,iBAAiB;EACjB,kBAAkB;EAClB,aAAa;AACf;;AAEA;;mFAEmF;;AAEnF;EACE,UAAU;EACV,WAAW;AACb;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,2CAA2C;EAC3C,kBAAkB;AACpB;;AAEA;EACE,iDAAiD;AACnD;;AAEA;;mFAEmF;;AAEnF;EACE;IACE,4BAA4B;EAC9B;;EAEA;IACE,WAAW;IACX,YAAY;IACZ,eAAe;EACjB;;EAEA;IACE,iBAAiB;EACnB;AACF;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,gBAAgB;AAClB;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,kBAAkB;EAClB,aAAa;EACb,sBAAsB;EACtB,aAAa;AACf;;AAEA,8EAA8E;AAC9E;EACE,cAAc;AAChB;;AAEA,+EAA+E;;AAE/E;EACE,WAAW;EACX,iBAAiB;EACjB,iBAAiB;EACjB,YAAY;EACZ,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,kBAAkB;EAClB,qCAAqC;EACrC,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,yCAAyC;EACzC,aAAa;EACb,gDAAgD;EAChD,sBAAsB;AACxB;;AAEA;EACE,oCAAoC;EACpC,8CAA8C;AAChD;;AAEA;EACE,YAAY;EACZ,mBAAmB;EACnB,yCAAyC;AAC3C;;AAEA;EACE,+BAA+B;EAC/B,eAAe;AACjB;;AAEA,8EAA8E;;AAE9E;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,OAAO;EACP,eAAe;EACf,+BAA+B;EAC/B,mBAAmB;EACnB,gBAAgB;EAChB,uBAAuB;AACzB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,UAAU;EACV,6BAA6B;EAC7B,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,gEAAgE;AAClE;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;EAC/B,qCAAqC;AACvC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,8EAA8E;;AAE9E;EACE,aAAa;EACb,eAAe;EACf,QAAQ;EACR,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,wBAAwB;EACxB,mBAAmB;EACnB,eAAe;EACf,gBAAgB;EAChB,yCAAyC;EACzC,yCAAyC;EACzC,+BAA+B;EAC/B,gBAAgB;EAChB,gBAAgB;AAClB;;AAEA;EACE,6CAA6C;AAC/C;;AAEA;EACE,4CAA4C;AAC9C;;AAEA;EACE,cAAc;EACd,aAAa;EACb,mBAAmB;EACnB,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,UAAU;EACV,YAAY;EACZ,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,YAAY;EACZ,+CAA+C;AACjD;;AAEA;EACE,UAAU;EACV,kCAAkC;AACpC;;AAEA,6EAA6E;;AAE7E;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,yCAAyC;EACzC,gDAAgD;EAChD,0BAA0B;AAC5B;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,iCAAiC;AACnC;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA,kEAAkE;AAClE;EACE,cAAc;EACd,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,UAAU;EACV,6BAA6B;EAC7B,kBAAkB;EAClB,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,iBAAiB;EACjB,UAAU;EACV,kEAAkE;AACpE;;AAEA;;EAEE,UAAU;AACZ;;AAEA;EACE,iDAAiD;EACjD,oCAAoC;EACpC,6BAA6B;AAC/B;;AAEA,sEAAsE;;AAEtE;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,yCAAyC;EACzC,6CAA6C;EAC7C,eAAe;EACf,+BAA+B;EAC/B,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,gBAAgB;EAChB,iBAAiB;EACjB,gDAAgD;EAChD,kBAAkB;EAClB,uBAAuB;EACvB,qCAAqC;EACrC,eAAe;EACf,eAAe;EACf,iCAAiC;AACnC;;AAEA;EACE,wCAAwC;AAC1C;;AAEA,+EAA+E;;;;AAI/E;;mFAEmF;;AAEnF,6BAA6B;AAC7B;EACE,oBAAoB;EACpB,mBAAmB;EACnB,QAAQ;EACR,gBAAgB;EAChB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA;EACE,2CAA2C;EAC3C,sCAAsC;AACxC;;AAEA;EACE,mBAAmB;EACnB,cAAc;AAChB;;AAEA;EACE,mBAAmB;EACnB,sCAAsC;AACxC;;AAEA;EACE,mBAAmB;EACnB,mBAAmB;EACnB,cAAc;AAChB;;AAEA,0BAA0B;AAC1B;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,gBAAgB;EAChB,sCAAsC;EACtC,2CAA2C;EAC3C,iBAAiB;EACjB,mBAAmB;EACnB,iDAAiD;EACjD,sDAAsD;AACxD;;AAEA;EACE,mBAAmB;EACnB,6CAA6C;EAC7C,sCAAsC;AACxC;;AAEA;EACE,WAAW,YAAY,EAAE;EACzB,MAAM,UAAU,EAAE;AACpB;;AAEA;EACE,WAAW;EACX,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,2CAA2C;EAC3C,sDAAsD;AACxD;;AAEA;EACE,WAAW,qBAAqB,EAAE,YAAY,EAAE;EAChD,MAAM,qBAAqB,EAAE,UAAU,EAAE;AAC3C;;AAEA;EACE,sDAAsD;AACxD;;AAEA;EACE,WAAW;EACX,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,2CAA2C;EAC3C,sDAAsD;AACxD;;AAEA;EACE,YAAY;EACZ,mCAAmC;EACnC,qCAAqC;EACrC,+BAA+B;AACjC;;AAEA;EACE,WAAW;EACX,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,mBAAmB;EACnB,eAAe;AACjB;;AAEA,gCAAgC;AAChC;EACE,eAAe;EACf,iBAAiB;EACjB,kDAAkD;AACpD;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,eAAe;EACf,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,eAAe;EACf,YAAY;AACd;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,mCAAmC;EACnC,gDAAgD;EAChD,eAAe;AACjB;;AAEA;EACE,gBAAgB;EAChB,+BAA+B;AACjC;;AAEA;EACE,6BAA6B;EAC7B,eAAe;AACjB;;AAEA,kBAAkB;AAClB;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;AACd;;AAEA,8BAA8B;AAC9B;EACE,oBAAoB;EACpB,QAAQ;AACV;;AAEA;EACE,UAAU;EACV,WAAW;EACX,kBAAkB;EAClB,oCAAoC;EACpC,6DAA6D;AAC/D;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE,uBAAuB;AACzB;;AAEA;EACE;IACE,qBAAqB;IACrB,YAAY;EACd;EACA;IACE,mBAAmB;IACnB,UAAU;EACZ;AACF;;AAEA,iBAAiB;AACjB;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,QAAQ;EACR,iBAAiB;EACjB,kCAAkC;EAClC,uCAAuC;EACvC,eAAe;AACjB;;AAEA;EACE,uBAAuB;EACvB,YAAY;EACZ,cAAc;EACd,eAAe;EACf,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA,0BAA0B;AAC1B;EACE,YAAY;AACd;;AAEA;;mFAEmF;;AAEnF;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,kBAAkB;EAClB,gDAAgD;AAClD;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,YAAY;AACd;;AAEA;EACE,kBAAkB;EAClB,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;EACE,eAAe;EACf,eAAe;EACf,YAAY;AACd;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,aAAa;EACb,kBAAkB;EAClB,eAAe;EACf,4BAA4B;EAC5B,6BAA6B;AAC/B;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;;AAEA;EACE,OAAO;EACP,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,kBAAkB;EAClB,mBAAmB;EACnB,gBAAgB;EAChB,uBAAuB;AACzB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,gBAAgB;EAChB,kBAAkB;EAClB,mCAAmC;EACnC,yBAAyB;EACzB,gBAAgB;AAClB;;AAEA;EACE,iCAAiC;EACjC,uCAAuC;AACzC;;AAEA;EACE,oCAAoC;EACpC,uCAAuC;AACzC;;;AAGA;EACE,YAAY;AACd;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,uBAAuB;EACvB,YAAY;EACZ,+BAA+B;EAC/B,eAAe;EACf,YAAY;EACZ,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,UAAU;EACV,2CAA2C;AAC7C;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;AACzC;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,6BAA6B;AAC/B;;AAEA;EACE,eAAe;EACf,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA,iCAAiC;AACjC;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,6BAA6B;AAC/B;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;AACzC;;AAEA,8BAA8B;AAC9B;EACE,kBAAkB;EAClB,gDAAgD;EAChD,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,yBAAyB;EACzB,qBAAqB;EACrB,+BAA+B;AACjC;;AAEA;EACE,uBAAuB;EACvB,YAAY;EACZ,+BAA+B;EAC/B,eAAe;EACf,gBAAgB;EAChB,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,yCAAyC;AAC3C;;AAEA;EACE,6BAA6B;EAC7B,mCAAmC;AACrC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,uCAAuC;EACvC,qBAAqB;EACrB,YAAY;AACd;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,WAAW;EACX,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,uCAAuC;EACvC,eAAe;EACf,aAAa;AACf;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;;EAEE,OAAO;EACP,iBAAiB;EACjB,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,kCAAkC;AACpC;;AAEA;EACE,wCAAwC;EACxC,YAAY;AACd;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,yCAAyC;EACzC,+BAA+B;AACjC;;AAEA;EACE,yCAAyC;AAC3C","sourcesContent":["/* LLM Assistant Chat Panel Styles */\r\n\r\n/* ==============================================================================\r\n   Chat Panel Container\r\n   ============================================================================== */\r\n\r\n.llm-chat-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n  background-color: var(--jp-layout-color1);\r\n  color: var(--jp-ui-font-color1);\r\n  font-family: var(--jp-ui-font-family);\r\n  overflow: hidden;\r\n}\r\n\r\n/* ==============================================================================\r\n   Header\r\n   ============================================================================== */\r\n\r\n.llm-chat-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 12px 16px;\r\n  border-bottom: 1px solid var(--jp-border-color0);\r\n  background-color: var(--jp-layout-color0);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.llm-chat-title {\r\n  font-size: 14px;\r\n  font-weight: 600;\r\n  color: var(--jp-ui-font-color0);\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-chat-actions {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n}\r\n\r\n.llm-icon-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 28px;\r\n  height: 28px;\r\n  border: none;\r\n  border-radius: 4px;\r\n  background: transparent;\r\n  color: var(--jp-ui-font-color1);\r\n  cursor: pointer;\r\n  transition: background-color 0.2s, color 0.2s;\r\n}\r\n\r\n.llm-icon-btn:hover {\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color0);\r\n}\r\n\r\n.llm-icon-btn:disabled {\r\n  opacity: 0.4;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.llm-icon-btn.active {\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n}\r\n\r\n/* ─── Header action buttons (chat header) ────────────────────── */\r\n\r\n.llm-header-actions {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 3px;\r\n}\r\n\r\n.llm-header-btn {\r\n  position: relative;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 28px;\r\n  height: 28px;\r\n  border: none;\r\n  border-radius: 4px;\r\n  background: transparent;\r\n  color: var(--jp-content-font-color2);\r\n  cursor: pointer;\r\n  transition: background 0.15s, color 0.15s;\r\n}\r\n\r\n.llm-header-btn:hover {\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.llm-header-btn.active {\r\n  background: var(--jp-brand-color3, #e3f2fd);\r\n  color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .llm-header-btn.active {\r\n  background: #1e3a5f;\r\n  color: var(--jp-brand-color1, #42a5f5);\r\n}\r\n\r\n/* Badge on context file button */\r\n.llm-context-badge {\r\n  position: absolute;\r\n  top: 1px;\r\n  right: 1px;\r\n  min-width: 13px;\r\n  height: 13px;\r\n  line-height: 13px;\r\n  text-align: center;\r\n  font-size: 8px;\r\n  font-weight: 700;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n  border-radius: 7px;\r\n  padding: 0 2px;\r\n}\r\n\r\n/* Button with active context files */\r\n.llm-header-btn-has-context {\r\n  color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n/* ─── Context active indicator bar ──────────────────────────── */\r\n\r\n.llm-context-indicator {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 5px;\r\n  padding: 4px 10px;\r\n  background: var(--jp-brand-color3, #e3f2fd);\r\n  border-bottom: 1px solid var(--jp-brand-color2, #90caf9);\r\n  font-size: 10px;\r\n  color: var(--jp-brand-color1, #1976d2);\r\n  cursor: pointer;\r\n  flex-shrink: 0;\r\n  transition: background 0.12s;\r\n}\r\n\r\n.llm-context-indicator:hover {\r\n  background: var(--jp-brand-color2, #90caf9);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .llm-context-indicator {\r\n  background: #1a2d45;\r\n  border-bottom-color: #2a4060;\r\n  color: var(--jp-brand-color1, #42a5f5);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .llm-context-indicator:hover {\r\n  background: #1e3a5f;\r\n}\r\n\r\n/* ─── Agent input hint right side ────────────────────────────── */\r\n\r\n.agent-input-hint-right {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n}\r\n\r\n/* ==============================================================================\r\n   Mode Selector (InputArea footer + AgentPanel footer)\r\n   ============================================================================== */\r\n\r\n.llm-input-footer {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  margin-top: 6px;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-mode-selector {\r\n  position: relative;\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n  flex-shrink: 0;\r\n}\r\n\r\n.llm-mode-selector-icon {\r\n  color: var(--jp-ui-font-color2);\r\n  flex-shrink: 0;\r\n  pointer-events: none;\r\n}\r\n\r\n.llm-mode-select {\r\n  /* Reset native appearance */\r\n  -webkit-appearance: none;\r\n  -moz-appearance: none;\r\n  appearance: none;\r\n\r\n  padding: 3px 22px 3px 6px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 5px;\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n  font-family: var(--jp-ui-font-family);\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  cursor: pointer;\r\n  outline: none;\r\n  transition: border-color 0.15s, background-color 0.15s;\r\n  min-width: 80px;\r\n  max-width: 160px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n\r\n.llm-mode-select:hover:not(:disabled) {\r\n  background-color: var(--jp-layout-color3);\r\n  border-color: var(--jp-brand-color1);\r\n}\r\n\r\n.llm-mode-select:focus {\r\n  border-color: var(--jp-brand-color1);\r\n  box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.15);\r\n}\r\n\r\n.llm-mode-select:disabled {\r\n  opacity: 0.5;\r\n  cursor: not-allowed;\r\n}\r\n\r\n/* Custom chevron overlay */\r\n.llm-mode-select-chevron {\r\n  position: absolute;\r\n  right: 5px;\r\n  color: var(--jp-ui-font-color2);\r\n  pointer-events: none;\r\n}\r\n\r\n/* ==============================================================================\r\n   @ Mention File Picker\r\n   ============================================================================== */\r\n\r\n.llm-mention-menu {\r\n  position: relative;\r\n  bottom: 0;\r\n  left: 0;\r\n  right: 0;\r\n  background-color: var(--jp-layout-color0);\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 8px;\r\n  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);\r\n  margin-bottom: 6px;\r\n  max-height: 220px;\r\n  overflow-y: auto;\r\n  z-index: 1000;\r\n}\r\n\r\n.llm-mention-item {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  padding: 7px 10px;\r\n  cursor: pointer;\r\n  font-size: 12px;\r\n  transition: background-color 0.1s;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n}\r\n\r\n.llm-mention-item:last-of-type {\r\n  border-bottom: none;\r\n}\r\n\r\n.llm-mention-item:hover,\r\n.llm-mention-item.active {\r\n  background-color: var(--jp-brand-color3, #e3f2fd);\r\n  color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .llm-mention-item:hover,\r\nbody[data-jp-theme-light='false'] .llm-mention-item.active {\r\n  background-color: #1a2d45;\r\n  color: var(--jp-brand-color1, #42a5f5);\r\n}\r\n\r\n.llm-mention-icon {\r\n  flex-shrink: 0;\r\n  color: var(--jp-ui-font-color2);\r\n  display: flex;\r\n  align-items: center;\r\n}\r\n\r\n.llm-mention-label {\r\n  font-weight: 500;\r\n  flex-shrink: 0;\r\n  max-width: 120px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n\r\n.llm-mention-path {\r\n  flex: 1;\r\n  font-size: 10px;\r\n  color: var(--jp-ui-font-color2);\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n  direction: rtl;\r\n  text-align: left;\r\n}\r\n\r\n.llm-mention-loading,\r\n.llm-mention-empty {\r\n  padding: 10px 14px;\r\n  font-size: 12px;\r\n  color: var(--jp-ui-font-color2);\r\n  font-style: italic;\r\n}\r\n\r\n.llm-mention-hint {\r\n  padding: 5px 10px;\r\n  font-size: 10px;\r\n  color: var(--jp-ui-font-color2);\r\n  background-color: var(--jp-layout-color1);\r\n  border-top: 1px solid var(--jp-border-color2);\r\n  border-radius: 0 0 7px 7px;\r\n}\r\n\r\n/* Scrollbar in mention menu */\r\n.llm-mention-menu::-webkit-scrollbar {\r\n  width: 6px;\r\n}\r\n.llm-mention-menu::-webkit-scrollbar-thumb {\r\n  background: var(--jp-scrollbar-thumb-color);\r\n  border-radius: 3px;\r\n}\r\n\r\n/* ==============================================================================\r\n   Message List\r\n   ============================================================================== */\r\n\r\n.llm-message-list {\r\n  flex: 1;\r\n  overflow-y: auto;\r\n  padding: 16px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 16px;\r\n}\r\n\r\n.llm-message-list-empty {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n}\r\n\r\n/* ==============================================================================\r\n   Empty State\r\n   ============================================================================== */\r\n\r\n.llm-empty-state {\r\n  text-align: center;\r\n  padding: 32px;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-empty-icon {\r\n  margin-bottom: 16px;\r\n  opacity: 0.6;\r\n}\r\n\r\n.llm-empty-state h3 {\r\n  font-size: 18px;\r\n  font-weight: 500;\r\n  margin: 0 0 8px 0;\r\n  color: var(--jp-ui-font-color1);\r\n}\r\n\r\n.llm-empty-state p {\r\n  font-size: 14px;\r\n  margin: 0 0 16px 0;\r\n}\r\n\r\n.llm-empty-hints {\r\n  list-style: none;\r\n  padding: 0;\r\n  margin: 0;\r\n  font-size: 13px;\r\n}\r\n\r\n.llm-empty-hints li {\r\n  padding: 4px 0;\r\n  position: relative;\r\n  padding-left: 16px;\r\n}\r\n\r\n.llm-empty-hints li::before {\r\n  content: \"•\";\r\n  position: absolute;\r\n  left: 0;\r\n  color: var(--jp-brand-color1);\r\n}\r\n\r\n/* ==============================================================================\r\n   Message Item\r\n   ============================================================================== */\r\n\r\n.llm-message-item {\r\n  display: flex;\r\n  gap: 12px;\r\n  animation: llm-message-fade-in 0.2s ease-out;\r\n}\r\n\r\n@keyframes llm-message-fade-in {\r\n  from {\r\n    opacity: 0;\r\n    transform: translateY(8px);\r\n  }\r\n  to {\r\n    opacity: 1;\r\n    transform: translateY(0);\r\n  }\r\n}\r\n\r\n.llm-message-item.user {\r\n  flex-direction: row-reverse;\r\n}\r\n\r\n.llm-message-avatar {\r\n  width: 32px;\r\n  height: 32px;\r\n  border-radius: 50%;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  flex-shrink: 0;\r\n  font-size: 14px;\r\n  font-weight: 600;\r\n}\r\n\r\n.llm-message-item.user .llm-message-avatar {\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n}\r\n\r\n.llm-message-item.assistant .llm-message-avatar {\r\n  background-color: var(--jp-accent-color1);\r\n  color: white;\r\n}\r\n\r\n.llm-message-item.system .llm-message-avatar {\r\n  background-color: var(--jp-warn-color1);\r\n  color: white;\r\n}\r\n\r\n.llm-message-content {\r\n  max-width: calc(100% - 56px);\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 4px;\r\n}\r\n\r\n.llm-message-item.user .llm-message-content {\r\n  align-items: flex-end;\r\n}\r\n\r\n.llm-message-header {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  font-size: 12px;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-message-role {\r\n  font-weight: 500;\r\n  color: var(--jp-ui-font-color1);\r\n}\r\n\r\n.llm-message-bubble {\r\n  padding: 12px 16px;\r\n  border-radius: 12px;\r\n  font-size: 14px;\r\n  line-height: 1.6;\r\n  word-break: break-word;\r\n}\r\n\r\n.llm-message-item.user .llm-message-bubble {\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n  border-bottom-right-radius: 4px;\r\n}\r\n\r\n.llm-message-item.assistant .llm-message-bubble,\r\n.llm-message-item.system .llm-message-bubble {\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n  border-bottom-left-radius: 4px;\r\n}\r\n\r\n/* Error state */\r\n.llm-message-item.error .llm-message-bubble {\r\n  background-color: var(--jp-error-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n/* ==============================================================================\r\n   Input Area\r\n   ============================================================================== */\r\n\r\n.llm-input-area {\r\n  padding: 12px 16px;\r\n  border-top: 1px solid var(--jp-border-color0);\r\n  background-color: var(--jp-layout-color0);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.llm-image-previews {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  gap: 8px;\r\n  margin-bottom: 8px;\r\n  padding: 8px;\r\n  background-color: var(--jp-layout-color1);\r\n  border-radius: 8px;\r\n}\r\n\r\n.llm-image-preview {\r\n  position: relative;\r\n  width: 80px;\r\n  height: 80px;\r\n  border-radius: 6px;\r\n  overflow: hidden;\r\n  border: 1px solid var(--jp-border-color1);\r\n}\r\n\r\n.llm-image-preview img {\r\n  width: 100%;\r\n  height: 100%;\r\n  object-fit: cover;\r\n}\r\n\r\n.llm-image-remove {\r\n  position: absolute;\r\n  top: 2px;\r\n  right: 2px;\r\n  width: 20px;\r\n  height: 20px;\r\n  border: none;\r\n  border-radius: 50%;\r\n  background-color: rgba(0, 0, 0, 0.6);\r\n  color: white;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  cursor: pointer;\r\n  opacity: 0;\r\n  transition: opacity 0.2s;\r\n}\r\n\r\n.llm-image-preview:hover .llm-image-remove {\r\n  opacity: 1;\r\n}\r\n\r\n.llm-image-remove:hover {\r\n  background-color: rgba(0, 0, 0, 0.8);\r\n}\r\n\r\n.llm-input-row {\r\n  display: flex;\r\n  align-items: flex-end;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-image-btn,\r\n.llm-send-btn {\r\n  width: 36px;\r\n  height: 36px;\r\n  border: none;\r\n  border-radius: 8px;\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  cursor: pointer;\r\n  flex-shrink: 0;\r\n  transition: background-color 0.2s, color 0.2s;\r\n}\r\n\r\n.llm-image-btn:hover:not(:disabled),\r\n.llm-send-btn:hover:not(:disabled) {\r\n  background-color: var(--jp-layout-color3);\r\n  color: var(--jp-ui-font-color0);\r\n}\r\n\r\n.llm-image-btn:disabled,\r\n.llm-send-btn:disabled {\r\n  opacity: 0.4;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.llm-send-btn:not(:disabled) {\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n}\r\n\r\n.llm-send-btn:not(:disabled):hover {\r\n  background-color: var(--jp-brand-color0);\r\n}\r\n\r\n.llm-text-input {\r\n  flex: 1;\r\n  min-height: 36px;\r\n  max-height: 200px;\r\n  padding: 8px 12px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 8px;\r\n  background-color: var(--jp-layout-color1);\r\n  color: var(--jp-ui-font-color1);\r\n  font-family: var(--jp-ui-font-family);\r\n  font-size: 14px;\r\n  line-height: 1.5;\r\n  resize: none;\r\n  outline: none;\r\n  transition: border-color 0.2s;\r\n}\r\n\r\n.llm-text-input:focus {\r\n  border-color: var(--jp-brand-color1);\r\n}\r\n\r\n.llm-text-input:disabled {\r\n  opacity: 0.6;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.llm-input-hint {\r\n  text-align: center;\r\n  margin-top: 8px;\r\n  font-size: 11px;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n/* ==============================================================================\r\n   Loading Indicator\r\n   ============================================================================== */\r\n\r\n.llm-loading-indicator {\r\n  display: flex;\r\n  align-items: center;\r\n  padding: 12px 16px;\r\n}\r\n\r\n.llm-loading-dots {\r\n  display: flex;\r\n  gap: 4px;\r\n}\r\n\r\n.llm-loading-dots span {\r\n  width: 8px;\r\n  height: 8px;\r\n  border-radius: 50%;\r\n  background-color: var(--jp-ui-font-color2);\r\n  animation: llm-loading-bounce 1.4s ease-in-out infinite both;\r\n}\r\n\r\n.llm-loading-dots span:nth-child(1) {\r\n  animation-delay: -0.32s;\r\n}\r\n\r\n.llm-loading-dots span:nth-child(2) {\r\n  animation-delay: -0.16s;\r\n}\r\n\r\n@keyframes llm-loading-bounce {\r\n  0%,\r\n  80%,\r\n  100% {\r\n    transform: scale(0.6);\r\n    opacity: 0.5;\r\n  }\r\n  40% {\r\n    transform: scale(1);\r\n    opacity: 1;\r\n  }\r\n}\r\n\r\n/* ==============================================================================\r\n   Settings Panel\r\n   ============================================================================== */\r\n\r\n.llm-settings-panel {\r\n  padding: 16px;\r\n  overflow-y: auto;\r\n  flex: 1;\r\n}\r\n\r\n.llm-settings-section {\r\n  margin-bottom: 24px;\r\n}\r\n\r\n.llm-settings-section-title {\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  text-transform: uppercase;\r\n  letter-spacing: 0.5px;\r\n  color: var(--jp-ui-font-color2);\r\n  margin: 0 0 12px 0;\r\n}\r\n\r\n.llm-settings-field {\r\n  margin-bottom: 16px;\r\n}\r\n\r\n.llm-settings-label {\r\n  display: block;\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  color: var(--jp-ui-font-color1);\r\n  margin-bottom: 6px;\r\n}\r\n\r\n.llm-settings-description {\r\n  font-size: 12px;\r\n  color: var(--jp-ui-font-color2);\r\n  margin: 4px 0 0 0;\r\n}\r\n\r\n.llm-settings-input,\r\n.llm-settings-select {\r\n  width: 100%;\r\n  padding: 8px 12px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 6px;\r\n  background-color: var(--jp-layout-color1);\r\n  color: var(--jp-ui-font-color1);\r\n  font-family: var(--jp-ui-font-family);\r\n  font-size: 13px;\r\n  outline: none;\r\n  transition: border-color 0.2s;\r\n}\r\n\r\n.llm-settings-input:focus,\r\n.llm-settings-select:focus {\r\n  border-color: var(--jp-brand-color1);\r\n}\r\n\r\n.llm-settings-checkbox-wrapper {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  cursor: pointer;\r\n}\r\n\r\n.llm-settings-checkbox {\r\n  width: 16px;\r\n  height: 16px;\r\n  accent-color: var(--jp-brand-color1);\r\n}\r\n\r\n.llm-settings-checkbox-label {\r\n  font-size: 13px;\r\n  color: var(--jp-ui-font-color1);\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  cursor: pointer;\r\n}\r\n\r\n.llm-settings-checkbox-label input[type=\"checkbox\"] {\r\n  width: 16px;\r\n  height: 16px;\r\n  accent-color: var(--jp-brand-color1);\r\n  cursor: pointer;\r\n}\r\n\r\n.llm-settings-actions {\r\n  display: flex;\r\n  gap: 8px;\r\n  margin-top: 24px;\r\n  padding-top: 16px;\r\n  border-top: 1px solid var(--jp-border-color0);\r\n}\r\n\r\n.llm-settings-btn {\r\n  flex: 1;\r\n  padding: 10px 16px;\r\n  border: none;\r\n  border-radius: 6px;\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  cursor: pointer;\r\n  transition: background-color 0.2s;\r\n}\r\n\r\n.llm-settings-btn-primary {\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n}\r\n\r\n.llm-settings-btn-primary:hover:not(:disabled) {\r\n  background-color: var(--jp-brand-color0);\r\n}\r\n\r\n.llm-settings-btn-secondary {\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n}\r\n\r\n.llm-settings-btn-secondary:hover {\r\n  background-color: var(--jp-layout-color3);\r\n}\r\n\r\n.llm-settings-btn:disabled {\r\n  opacity: 0.5;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.llm-test-status {\r\n  margin-top: 8px;\r\n  padding: 8px 12px;\r\n  border-radius: 6px;\r\n  font-size: 12px;\r\n}\r\n\r\n.llm-test-status.success {\r\n  background-color: var(--jp-success-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n.llm-test-status.error {\r\n  background-color: var(--jp-error-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n/* ==============================================================================\r\n   New Settings Panel Styles\r\n   ============================================================================== */\r\n\r\n.llm-settings-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 0 0 16px 0;\r\n  border-bottom: 1px solid var(--jp-border-color0);\r\n  margin-bottom: 16px;\r\n}\r\n\r\n.llm-settings-header h3 {\r\n  margin: 0;\r\n  font-size: 16px;\r\n  font-weight: 600;\r\n  color: var(--jp-ui-font-color0);\r\n}\r\n\r\n.llm-close-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 28px;\r\n  height: 28px;\r\n  border: none;\r\n  border-radius: 4px;\r\n  background: transparent;\r\n  color: var(--jp-ui-font-color2);\r\n  cursor: pointer;\r\n  transition: background-color 0.2s, color 0.2s;\r\n}\r\n\r\n.llm-close-btn:hover {\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color0);\r\n}\r\n\r\n.llm-settings-content {\r\n  padding: 0;\r\n}\r\n\r\n.llm-section-title {\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  text-transform: uppercase;\r\n  letter-spacing: 0.5px;\r\n  color: var(--jp-ui-font-color2);\r\n  margin: 0 0 12px 0;\r\n  padding-bottom: 8px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n}\r\n\r\n.llm-settings-section {\r\n  margin-bottom: 24px;\r\n}\r\n\r\n.llm-settings-field {\r\n  margin-bottom: 16px;\r\n}\r\n\r\n.llm-settings-field label {\r\n  display: block;\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  color: var(--jp-ui-font-color1);\r\n  margin-bottom: 6px;\r\n}\r\n\r\n.llm-settings-field input[type=\"text\"],\r\n.llm-settings-field input[type=\"password\"],\r\n.llm-settings-field input[type=\"number\"],\r\n.llm-settings-field select,\r\n.llm-settings-field textarea {\r\n  width: 100%;\r\n  padding: 8px 12px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 6px;\r\n  background-color: var(--jp-layout-color1);\r\n  color: var(--jp-ui-font-color1);\r\n  font-family: var(--jp-ui-font-family);\r\n  font-size: 13px;\r\n  outline: none;\r\n  transition: border-color 0.2s, box-shadow 0.2s;\r\n}\r\n\r\n.llm-settings-field input:focus,\r\n.llm-settings-field select:focus,\r\n.llm-settings-field textarea:focus {\r\n  border-color: var(--jp-brand-color1);\r\n  box-shadow: 0 0 0 2px rgba(19, 124, 189, 0.2);\r\n}\r\n\r\n.llm-input-with-button {\r\n  display: flex;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-api-key-input {\r\n  flex: 1;\r\n}\r\n\r\n.llm-toggle-visibility-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 36px;\r\n  height: 36px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 6px;\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n  cursor: pointer;\r\n  transition: background-color 0.2s;\r\n}\r\n\r\n.llm-toggle-visibility-btn:hover {\r\n  background-color: var(--jp-layout-color3);\r\n}\r\n\r\n.llm-settings-field input[type=\"range\"] {\r\n  width: 100%;\r\n  height: 6px;\r\n  border-radius: 3px;\r\n  background: var(--jp-layout-color3);\r\n  outline: none;\r\n  -webkit-appearance: none;\r\n}\r\n\r\n.llm-settings-field input[type=\"range\"]::-webkit-slider-thumb {\r\n  -webkit-appearance: none;\r\n  width: 16px;\r\n  height: 16px;\r\n  border-radius: 50%;\r\n  background: var(--jp-brand-color1);\r\n  cursor: pointer;\r\n}\r\n\r\n.llm-settings-hint {\r\n  font-size: 11px;\r\n  color: var(--jp-ui-font-color2);\r\n  margin: 6px 0 0 0;\r\n}\r\n\r\n.llm-settings-hint code {\r\n  background-color: var(--jp-layout-color3);\r\n  padding: 2px 4px;\r\n  border-radius: 3px;\r\n  font-family: var(--jp-code-font-family);\r\n}\r\n\r\n.llm-settings-toggle label {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  cursor: pointer;\r\n  font-weight: 500;\r\n}\r\n\r\n.llm-settings-toggle input[type=\"checkbox\"] {\r\n  width: 16px;\r\n  height: 16px;\r\n  accent-color: var(--jp-brand-color1);\r\n  cursor: pointer;\r\n}\r\n\r\n.llm-api-key-status {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  padding: 10px 12px;\r\n  border-radius: 6px;\r\n  font-size: 13px;\r\n  margin-bottom: 8px;\r\n}\r\n\r\n.llm-status-ok {\r\n  background-color: var(--jp-success-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n.llm-status-error {\r\n  background-color: var(--jp-error-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n.llm-test-btn {\r\n  width: 100%;\r\n  padding: 10px 16px;\r\n  border: none;\r\n  border-radius: 6px;\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  cursor: pointer;\r\n  transition: background-color 0.2s;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-test-btn:hover:not(:disabled) {\r\n  background-color: var(--jp-brand-color0);\r\n}\r\n\r\n.llm-test-btn:disabled {\r\n  opacity: 0.5;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.llm-spinner {\r\n  width: 16px;\r\n  height: 16px;\r\n  border: 2px solid rgba(255, 255, 255, 0.3);\r\n  border-top-color: white;\r\n  border-radius: 50%;\r\n  animation: llm-spin 0.8s linear infinite;\r\n}\r\n\r\n@keyframes llm-spin {\r\n  to {\r\n    transform: rotate(360deg);\r\n  }\r\n}\r\n\r\n.llm-test-result {\r\n  margin-top: 12px;\r\n  padding: 10px 12px;\r\n  border-radius: 6px;\r\n  font-size: 13px;\r\n}\r\n\r\n.llm-test-success {\r\n  background-color: var(--jp-success-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n.llm-test-error {\r\n  background-color: var(--jp-error-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n.llm-settings-footer {\r\n  display: flex;\r\n  gap: 12px;\r\n  padding: 16px 0 0 0;\r\n  border-top: 1px solid var(--jp-border-color0);\r\n  margin-top: 24px;\r\n}\r\n\r\n.llm-cancel-btn,\r\n.llm-save-btn {\r\n  flex: 1;\r\n  padding: 10px 16px;\r\n  border: none;\r\n  border-radius: 6px;\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  cursor: pointer;\r\n  transition: background-color 0.2s;\r\n}\r\n\r\n.llm-cancel-btn {\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n}\r\n\r\n.llm-cancel-btn:hover {\r\n  background-color: var(--jp-layout-color3);\r\n}\r\n\r\n.llm-save-btn {\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n}\r\n\r\n.llm-save-btn:hover:not(:disabled) {\r\n  background-color: var(--jp-brand-color0);\r\n}\r\n\r\n.llm-save-btn:disabled {\r\n  opacity: 0.5;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.llm-value {\r\n  font-weight: 600;\r\n  color: var(--jp-brand-color1);\r\n}\r\n\r\n/* ==============================================================================\r\n   Markdown Content\r\n   ============================================================================== */\r\n\r\n.llm-markdown-content {\r\n  line-height: 1.6;\r\n}\r\n\r\n.llm-markdown-content *:first-child {\r\n  margin-top: 0;\r\n}\r\n\r\n.llm-markdown-content *:last-child {\r\n  margin-bottom: 0;\r\n}\r\n\r\n.llm-md-paragraph {\r\n  margin: 8px 0;\r\n}\r\n\r\n.llm-md-link {\r\n  color: var(--jp-link-color);\r\n  text-decoration: none;\r\n}\r\n\r\n.llm-md-link:hover {\r\n  text-decoration: underline;\r\n}\r\n\r\n.llm-md-code-inline {\r\n  font-family: var(--jp-code-font-family);\r\n  font-size: 0.9em;\r\n  padding: 2px 6px;\r\n  background-color: var(--jp-layout-color3);\r\n  border-radius: 4px;\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.llm-message-item.user .llm-md-code-inline {\r\n  background-color: rgba(255, 255, 255, 0.2);\r\n  color: inherit;\r\n}\r\n\r\n.llm-md-list {\r\n  margin: 8px 0;\r\n  padding-left: 24px;\r\n}\r\n\r\n.llm-md-list-ordered {\r\n  list-style-type: decimal;\r\n}\r\n\r\n.llm-md-list-item {\r\n  margin: 4px 0;\r\n}\r\n\r\n.llm-md-heading {\r\n  font-weight: 600;\r\n  margin: 16px 0 8px 0;\r\n  color: var(--jp-content-font-color0);\r\n}\r\n\r\n.llm-message-item.user .llm-md-heading {\r\n  color: inherit;\r\n}\r\n\r\n.llm-md-heading-1 {\r\n  font-size: 1.5em;\r\n  border-bottom: 1px solid var(--jp-border-color1);\r\n  padding-bottom: 8px;\r\n}\r\n\r\n.llm-md-heading-2 {\r\n  font-size: 1.3em;\r\n}\r\n\r\n.llm-md-heading-3 {\r\n  font-size: 1.1em;\r\n}\r\n\r\n.llm-md-heading-4,\r\n.llm-md-heading-5,\r\n.llm-md-heading-6 {\r\n  font-size: 1em;\r\n}\r\n\r\n.llm-md-blockquote {\r\n  margin: 8px 0;\r\n  padding: 8px 16px;\r\n  border-left: 4px solid var(--jp-brand-color1);\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-md-table-wrapper {\r\n  overflow-x: auto;\r\n  margin: 8px 0;\r\n}\r\n\r\n.llm-md-table {\r\n  width: 100%;\r\n  border-collapse: collapse;\r\n  font-size: 13px;\r\n}\r\n\r\n.llm-md-th,\r\n.llm-md-td {\r\n  padding: 8px 12px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  text-align: left;\r\n}\r\n\r\n.llm-md-th {\r\n  background-color: var(--jp-layout-color2);\r\n  font-weight: 600;\r\n}\r\n\r\n/* ==============================================================================\r\n   Think Block - Collapsible thinking content\r\n   ============================================================================== */\r\n\r\n.llm-think-block {\r\n  margin: 12px 0;\r\n  border-radius: 8px;\r\n  overflow: hidden;\r\n  background-color: var(--jp-layout-color2);\r\n  border: 1px solid var(--jp-border-color1);\r\n}\r\n\r\n.llm-think-header {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  padding: 8px 12px;\r\n  background-color: var(--jp-layout-color3);\r\n  border: none;\r\n  width: 100%;\r\n  cursor: pointer;\r\n  font-size: 12px;\r\n  color: var(--jp-ui-font-color2);\r\n  transition: background-color 0.15s;\r\n}\r\n\r\n.llm-think-header:hover {\r\n  background-color: var(--jp-layout-color2);\r\n}\r\n\r\n.llm-think-icon {\r\n  display: flex;\r\n  align-items: center;\r\n  color: var(--jp-brand-color1);\r\n}\r\n\r\n.llm-think-label {\r\n  flex: 1;\r\n  font-weight: 500;\r\n  text-align: left;\r\n}\r\n\r\n.llm-think-chevron {\r\n  font-size: 10px;\r\n  opacity: 0.7;\r\n}\r\n\r\n.llm-think-content {\r\n  padding: 12px;\r\n  font-size: 13px;\r\n  line-height: 1.6;\r\n  color: var(--jp-ui-font-color2);\r\n  border-top: 1px solid var(--jp-border-color1);\r\n}\r\n\r\n.llm-think-content p {\r\n  margin: 0 0 8px 0;\r\n}\r\n\r\n.llm-think-content p:last-child {\r\n  margin-bottom: 0;\r\n}\r\n\r\n/* ==============================================================================\r\n   Code Block\r\n   ============================================================================== */\r\n\r\n.llm-code-block {\r\n  margin: 12px 0;\r\n  border-radius: 8px;\r\n  overflow: hidden;\r\n  background-color: var(--jp-cell-editor-background);\r\n  border: 1px solid var(--jp-border-color1);\r\n}\r\n\r\n.llm-code-block-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 8px 12px;\r\n  background-color: var(--jp-layout-color2);\r\n  border-bottom: 1px solid var(--jp-border-color1);\r\n}\r\n\r\n.llm-code-language {\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  text-transform: uppercase;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-code-copy-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n  padding: 4px 8px;\r\n  border: none;\r\n  border-radius: 4px;\r\n  background-color: transparent;\r\n  color: var(--jp-ui-font-color2);\r\n  font-size: 11px;\r\n  cursor: pointer;\r\n  transition: background-color 0.2s, color 0.2s;\r\n}\r\n\r\n.llm-code-copy-btn:hover {\r\n  background-color: var(--jp-layout-color3);\r\n  color: var(--jp-ui-font-color0);\r\n}\r\n\r\n.llm-code-copy-btn.copied {\r\n  color: var(--jp-success-color1);\r\n}\r\n\r\n.llm-code-block pre {\r\n  margin: 0;\r\n  padding: 16px;\r\n  overflow-x: auto;\r\n  font-family: var(--jp-code-font-family);\r\n  font-size: 13px;\r\n  line-height: 1.5;\r\n}\r\n\r\n.llm-code-block code {\r\n  font-family: var(--jp-code-font-family);\r\n}\r\n\r\n/* ==============================================================================\r\n   Image in Message\r\n   ============================================================================== */\r\n\r\n.llm-message-image {\r\n  max-width: 100%;\r\n  max-height: 300px;\r\n  border-radius: 8px;\r\n  margin: 8px 0;\r\n}\r\n\r\n/* ==============================================================================\r\n   Scrollbar Styling\r\n   ============================================================================== */\r\n\r\n.llm-chat-panel ::-webkit-scrollbar {\r\n  width: 8px;\r\n  height: 8px;\r\n}\r\n\r\n.llm-chat-panel ::-webkit-scrollbar-track {\r\n  background: transparent;\r\n}\r\n\r\n.llm-chat-panel ::-webkit-scrollbar-thumb {\r\n  background: var(--jp-scrollbar-thumb-color);\r\n  border-radius: 4px;\r\n}\r\n\r\n.llm-chat-panel ::-webkit-scrollbar-thumb:hover {\r\n  background: var(--jp-scrollbar-thumb-hover-color);\r\n}\r\n\r\n/* ==============================================================================\r\n   Responsive Adjustments\r\n   ============================================================================== */\r\n\r\n@media (max-width: 400px) {\r\n  .llm-message-content {\r\n    max-width: calc(100% - 48px);\r\n  }\r\n\r\n  .llm-message-avatar {\r\n    width: 28px;\r\n    height: 28px;\r\n    font-size: 12px;\r\n  }\r\n\r\n  .llm-input-area {\r\n    padding: 8px 12px;\r\n  }\r\n}\r\n\r\n/* ==============================================================================\r\n   Unified Panel Layout (v0.7.0)\r\n   ============================================================================== */\r\n\r\n.llm-unified-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n  overflow: hidden;\r\n}\r\n\r\n.llm-mode-viewport {\r\n  flex: 1;\r\n  overflow-y: auto;\r\n  overflow-x: hidden;\r\n  display: flex;\r\n  flex-direction: column;\r\n  min-height: 0;\r\n}\r\n\r\n/* Override input area inside the unified panel — no top padding duplication */\r\n.llm-unified-panel .llm-input-area {\r\n  flex-shrink: 0;\r\n}\r\n\r\n/* ── Large textarea ──────────────────────────────────────────────────────── */\r\n\r\n.llm-text-input-large {\r\n  width: 100%;\r\n  min-height: 120px;\r\n  max-height: 400px;\r\n  resize: none;\r\n  overflow-y: auto;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 8px;\r\n  padding: 10px 12px;\r\n  font-family: var(--jp-ui-font-family);\r\n  font-size: 13px;\r\n  line-height: 1.5;\r\n  color: var(--jp-ui-font-color1);\r\n  background-color: var(--jp-layout-color0);\r\n  outline: none;\r\n  transition: border-color 0.15s, box-shadow 0.15s;\r\n  box-sizing: border-box;\r\n}\r\n\r\n.llm-text-input-large:focus {\r\n  border-color: var(--jp-brand-color1);\r\n  box-shadow: 0 0 0 2px rgba(25, 118, 210, 0.12);\r\n}\r\n\r\n.llm-text-input-large:disabled {\r\n  opacity: 0.6;\r\n  cursor: not-allowed;\r\n  background-color: var(--jp-layout-color2);\r\n}\r\n\r\n.llm-text-input-large::placeholder {\r\n  color: var(--jp-ui-font-color3);\r\n  font-size: 12px;\r\n}\r\n\r\n/* ── Toolbar at bottom of InputArea ─────────────────────────────────────── */\r\n\r\n.llm-input-toolbar {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n}\r\n\r\n.llm-input-hint-text {\r\n  flex: 1;\r\n  font-size: 10px;\r\n  color: var(--jp-ui-font-color3);\r\n  white-space: nowrap;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n}\r\n\r\n.llm-input-actions {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n  flex-shrink: 0;\r\n}\r\n\r\n.llm-toolbar-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 28px;\r\n  height: 28px;\r\n  padding: 0;\r\n  border: 1px solid transparent;\r\n  border-radius: 6px;\r\n  background: transparent;\r\n  color: var(--jp-ui-font-color2);\r\n  cursor: pointer;\r\n  transition: background-color 0.1s, color 0.1s, border-color 0.1s;\r\n}\r\n\r\n.llm-toolbar-btn:hover:not(:disabled) {\r\n  background-color: var(--jp-layout-color3);\r\n  color: var(--jp-ui-font-color1);\r\n  border-color: var(--jp-border-color1);\r\n}\r\n\r\n.llm-toolbar-btn:disabled {\r\n  opacity: 0.4;\r\n  cursor: not-allowed;\r\n}\r\n\r\n/* ── Path attachment chips ──────────────────────────────────────────────── */\r\n\r\n.llm-attached-chips {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  gap: 5px;\r\n  padding: 2px 0;\r\n}\r\n\r\n.llm-chip {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n  padding: 3px 7px 3px 6px;\r\n  border-radius: 12px;\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  border: 1px solid var(--jp-border-color1);\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n  max-width: 200px;\r\n  overflow: hidden;\r\n}\r\n\r\n.llm-chip-file {\r\n  border-color: var(--jp-brand-color2, #64b5f6);\r\n}\r\n\r\n.llm-chip-dir {\r\n  border-color: var(--jp-warn-color2, #ffb74d);\r\n}\r\n\r\n.llm-chip-icon {\r\n  flex-shrink: 0;\r\n  display: flex;\r\n  align-items: center;\r\n  opacity: 0.8;\r\n}\r\n\r\n.llm-chip-label {\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n\r\n.llm-chip-remove {\r\n  flex-shrink: 0;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 14px;\r\n  height: 14px;\r\n  padding: 0;\r\n  border: none;\r\n  border-radius: 50%;\r\n  background: transparent;\r\n  color: var(--jp-ui-font-color2);\r\n  cursor: pointer;\r\n  opacity: 0.7;\r\n  transition: opacity 0.1s, background-color 0.1s;\r\n}\r\n\r\n.llm-chip-remove:hover {\r\n  opacity: 1;\r\n  background-color: rgba(0,0,0,0.12);\r\n}\r\n\r\n/* ── @ mention: breadcrumb header for drill-down ───────────────────────── */\r\n\r\n.llm-mention-breadcrumb {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  padding: 5px 10px;\r\n  background-color: var(--jp-layout-color2);\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  border-radius: 7px 7px 0 0;\r\n}\r\n\r\n.llm-mention-breadcrumb-back {\r\n  display: flex;\r\n  align-items: center;\r\n  padding: 2px 4px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 4px;\r\n  background: transparent;\r\n  color: var(--jp-ui-font-color2);\r\n  cursor: pointer;\r\n  transition: background-color 0.1s;\r\n}\r\n\r\n.llm-mention-breadcrumb-back:hover {\r\n  background-color: var(--jp-layout-color3);\r\n}\r\n\r\n.llm-mention-breadcrumb-path {\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  color: var(--jp-ui-font-color1);\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n\r\n/* Attach-dir button that appears on hover over a directory item */\r\n.llm-mention-attach-dir {\r\n  flex-shrink: 0;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  width: 18px;\r\n  height: 18px;\r\n  padding: 0;\r\n  border: 1px solid transparent;\r\n  border-radius: 4px;\r\n  background: transparent;\r\n  color: var(--jp-ui-font-color2);\r\n  cursor: pointer;\r\n  margin-left: auto;\r\n  opacity: 0;\r\n  transition: opacity 0.1s, background-color 0.1s, border-color 0.1s;\r\n}\r\n\r\n.llm-mention-item:hover .llm-mention-attach-dir,\r\n.llm-mention-item.active .llm-mention-attach-dir {\r\n  opacity: 1;\r\n}\r\n\r\n.llm-mention-attach-dir:hover {\r\n  background-color: var(--jp-brand-color3, #e3f2fd);\r\n  border-color: var(--jp-brand-color1);\r\n  color: var(--jp-brand-color1);\r\n}\r\n\r\n/* ── Agent running bar (replaces inline input) ──────────────────── */\r\n\r\n.agent-running-bar {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  padding: 6px 12px;\r\n  background-color: var(--jp-layout-color2);\r\n  border-top: 1px solid var(--jp-border-color1);\r\n  font-size: 12px;\r\n  color: var(--jp-ui-font-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.agent-running-bar .agent-stop-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n  padding: 3px 8px;\r\n  margin-left: auto;\r\n  border: 1px solid var(--jp-warn-color1, #ff9800);\r\n  border-radius: 5px;\r\n  background: transparent;\r\n  color: var(--jp-warn-color1, #ff9800);\r\n  font-size: 11px;\r\n  cursor: pointer;\r\n  transition: background-color 0.1s;\r\n}\r\n\r\n.agent-running-bar .agent-stop-btn:hover {\r\n  background-color: rgba(255, 152, 0, 0.1);\r\n}\r\n\r\n/* ── Agent action area (no internal textarea) ────────────────────────────── */\r\n\r\n\r\n\r\n/* ==============================================================================\r\n   Unified Message List (v0.8.0)\r\n   ============================================================================== */\r\n\r\n/* Mode badges for messages */\r\n.llm-mode-badge {\r\n  display: inline-flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n  padding: 2px 8px;\r\n  border-radius: 4px;\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-mode-badge-chat {\r\n  background: var(--jp-brand-color3, #e3f2fd);\r\n  color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.llm-mode-badge-agent {\r\n  background: #e8f5e9;\r\n  color: #e65100;\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .llm-mode-badge-chat {\r\n  background: #1e3a5f;\r\n  color: var(--jp-brand-color1, #42a5f5);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .llm-mode-badge-agent {\r\n  background: #1b3d1b;\r\n  background: #3d2815;\r\n  color: #ffb74d;\r\n}\r\n\r\n/* Agent message content */\r\n.llm-message-agent-content {\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-message-tool-calls {\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 4px;\r\n}\r\n\r\n.llm-message-iteration {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n  margin-top: 6px;\r\n}\r\n\r\n.llm-iteration-badge {\r\n  display: inline-flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  color: var(--jp-brand-color1, #1976d2);\r\n  background: var(--jp-brand-color3, #e3f2fd);\r\n  padding: 3px 10px;\r\n  border-radius: 12px;\r\n  border: 1px solid var(--jp-brand-color2, #90caf9);\r\n  animation: llm-iteration-pulse 2s ease-in-out infinite;\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .llm-iteration-badge {\r\n  background: #1e3a5f;\r\n  border-color: var(--jp-brand-color1, #42a5f5);\r\n  color: var(--jp-brand-color1, #42a5f5);\r\n}\r\n\r\n@keyframes llm-iteration-pulse {\r\n  0%, 100% { opacity: 0.8; }\r\n  50% { opacity: 1; }\r\n}\r\n\r\n.llm-iteration-badge::before {\r\n  content: '';\r\n  width: 6px;\r\n  height: 6px;\r\n  border-radius: 50%;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  animation: llm-iteration-dot 1.4s ease-in-out infinite;\r\n}\r\n\r\n@keyframes llm-iteration-dot {\r\n  0%, 100% { transform: scale(0.8); opacity: 0.5; }\r\n  50% { transform: scale(1.2); opacity: 1; }\r\n}\r\n\r\n.llm-iteration-active {\r\n  animation: llm-iteration-pulse 2s ease-in-out infinite;\r\n}\r\n\r\n.llm-iteration-active::before {\r\n  content: '';\r\n  width: 6px;\r\n  height: 6px;\r\n  border-radius: 50%;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  animation: llm-iteration-dot 1.4s ease-in-out infinite;\r\n}\r\n\r\n.llm-iteration-complete {\r\n  opacity: 0.7;\r\n  background: var(--jp-layout-color2);\r\n  border-color: var(--jp-border-color2);\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-iteration-complete::before {\r\n  content: '';\r\n  width: 6px;\r\n  height: 6px;\r\n  border-radius: 50%;\r\n  background: #22c55e;\r\n  animation: none;\r\n}\r\n\r\n/* Iteration badge as a button */\r\n.llm-iteration-badge {\r\n  cursor: pointer;\r\n  user-select: none;\r\n  transition: background-color 0.15s, transform 0.1s;\r\n}\r\n\r\n.llm-iteration-badge:hover:not(:disabled) {\r\n  background: var(--jp-brand-color2, #90caf9);\r\n}\r\n\r\n.llm-iteration-badge:disabled {\r\n  cursor: default;\r\n  opacity: 0.8;\r\n}\r\n\r\n.llm-iteration-chevron {\r\n  margin-left: 4px;\r\n  font-size: 10px;\r\n  opacity: 0.7;\r\n}\r\n\r\n.llm-model-indicator {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  padding: 8px 16px;\r\n  background: var(--jp-layout-color2);\r\n  border-bottom: 1px solid var(--jp-border-color0);\r\n  font-size: 12px;\r\n}\r\n\r\n.llm-model-name {\r\n  font-weight: 600;\r\n  color: var(--jp-ui-font-color0);\r\n}\r\n\r\n.llm-api-warning {\r\n  color: var(--jp-error-color1);\r\n  font-size: 11px;\r\n}\r\n\r\n/* Unified panel */\r\n.llm-unified-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n}\r\n\r\n/* Thinking dots for loading */\r\n.llm-thinking-dots {\r\n  display: inline-flex;\r\n  gap: 4px;\r\n}\r\n\r\n.llm-thinking-dots span {\r\n  width: 6px;\r\n  height: 6px;\r\n  border-radius: 50%;\r\n  background: var(--jp-ui-font-color2);\r\n  animation: llm-thinking-bounce 1.4s ease-in-out infinite both;\r\n}\r\n\r\n.llm-thinking-dots span:nth-child(1) {\r\n  animation-delay: -0.32s;\r\n}\r\n\r\n.llm-thinking-dots span:nth-child(2) {\r\n  animation-delay: -0.16s;\r\n}\r\n\r\n@keyframes llm-thinking-bounce {\r\n  0%, 80%, 100% {\r\n    transform: scale(0.6);\r\n    opacity: 0.5;\r\n  }\r\n  40% {\r\n    transform: scale(1);\r\n    opacity: 1;\r\n  }\r\n}\r\n\r\n/* Error banner */\r\n.llm-error-banner {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  gap: 8px;\r\n  padding: 8px 12px;\r\n  background: var(--jp-error-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n  font-size: 13px;\r\n}\r\n\r\n.llm-error-banner button {\r\n  background: transparent;\r\n  border: none;\r\n  color: inherit;\r\n  cursor: pointer;\r\n  padding: 2px;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n}\r\n\r\n/* Message loading state */\r\n.llm-message-loading {\r\n  opacity: 0.7;\r\n}\r\n\r\n/* ==============================================================================\r\n   Session Panel\r\n   ============================================================================== */\r\n\r\n.llm-session-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n  background: var(--jp-layout-color1);\r\n}\r\n\r\n.llm-session-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 12px 16px;\r\n  border-bottom: 1px solid var(--jp-border-color1);\r\n}\r\n\r\n.llm-session-header h4 {\r\n  margin: 0;\r\n  font-size: 14px;\r\n  font-weight: 600;\r\n}\r\n\r\n.llm-session-content {\r\n  flex: 1;\r\n  overflow-y: auto;\r\n  padding: 8px;\r\n}\r\n\r\n.llm-session-empty {\r\n  text-align: center;\r\n  padding: 32px 16px;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-session-empty .llm-hint {\r\n  font-size: 12px;\r\n  margin-top: 8px;\r\n  opacity: 0.7;\r\n}\r\n\r\n.llm-session-list {\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 4px;\r\n}\r\n\r\n.llm-session-item {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 12px;\r\n  border-radius: 6px;\r\n  cursor: pointer;\r\n  transition: background 0.15s;\r\n  border: 1px solid transparent;\r\n}\r\n\r\n.llm-session-item:hover {\r\n  background: var(--jp-layout-color2);\r\n  border-color: var(--jp-border-color1);\r\n}\r\n\r\n.llm-session-info {\r\n  flex: 1;\r\n  min-width: 0;\r\n}\r\n\r\n.llm-session-title {\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n  margin-bottom: 4px;\r\n  white-space: nowrap;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n}\r\n\r\n.llm-session-meta {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 8px;\r\n  font-size: 11px;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-session-mode {\r\n  padding: 2px 6px;\r\n  border-radius: 3px;\r\n  background: var(--jp-layout-color3);\r\n  text-transform: uppercase;\r\n  font-weight: 500;\r\n}\r\n\r\n.llm-session-mode.llm-mode-chat {\r\n  background: var(--jp-info-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n.llm-session-mode.llm-mode-agent {\r\n  background: var(--jp-success-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n\r\n.llm-session-count {\r\n  opacity: 0.8;\r\n}\r\n\r\n.llm-session-date {\r\n  opacity: 0.6;\r\n}\r\n\r\n.llm-session-delete {\r\n  background: transparent;\r\n  border: none;\r\n  color: var(--jp-ui-font-color2);\r\n  cursor: pointer;\r\n  padding: 4px;\r\n  border-radius: 4px;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  opacity: 0;\r\n  transition: opacity 0.15s, background 0.15s;\r\n}\r\n\r\n.llm-session-item:hover .llm-session-delete {\r\n  opacity: 1;\r\n}\r\n\r\n.llm-session-delete:hover {\r\n  background: var(--jp-error-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n.llm-session-error {\r\n  padding: 16px;\r\n  text-align: center;\r\n  color: var(--jp-error-color0);\r\n}\r\n\r\n.llm-session-error button {\r\n  margin-top: 8px;\r\n  padding: 6px 12px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 4px;\r\n  background: var(--jp-layout-color2);\r\n  cursor: pointer;\r\n}\r\n\r\n.llm-loading {\r\n  padding: 32px;\r\n  text-align: center;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n/* Session Panel Header Actions */\r\n.llm-session-header-actions {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 4px;\r\n}\r\n\r\n.llm-new-session-btn {\r\n  color: var(--jp-brand-color1);\r\n}\r\n\r\n.llm-new-session-btn:hover {\r\n  background: var(--jp-brand-color0);\r\n  color: var(--jp-ui-inverse-font-color0);\r\n}\r\n\r\n/* Project Directory Section */\r\n.llm-rootdir-section {\r\n  padding: 12px 16px;\r\n  border-bottom: 1px solid var(--jp-border-color0);\r\n  background: var(--jp-layout-color0);\r\n}\r\n\r\n.llm-rootdir-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  margin-bottom: 6px;\r\n}\r\n\r\n.llm-rootdir-label {\r\n  font-size: 11px;\r\n  font-weight: 600;\r\n  text-transform: uppercase;\r\n  letter-spacing: 0.5px;\r\n  color: var(--jp-ui-font-color2);\r\n}\r\n\r\n.llm-rootdir-edit-btn {\r\n  background: transparent;\r\n  border: none;\r\n  color: var(--jp-ui-font-color2);\r\n  cursor: pointer;\r\n  padding: 2px 4px;\r\n  border-radius: 3px;\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  transition: color 0.15s, background 0.15s;\r\n}\r\n\r\n.llm-rootdir-edit-btn:hover {\r\n  color: var(--jp-brand-color1);\r\n  background: var(--jp-layout-color2);\r\n}\r\n\r\n.llm-rootdir-path {\r\n  font-size: 12px;\r\n  color: var(--jp-ui-font-color1);\r\n  font-family: var(--jp-code-font-family);\r\n  word-break: break-all;\r\n  opacity: 0.8;\r\n}\r\n\r\n.llm-rootdir-edit {\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-rootdir-input {\r\n  width: 100%;\r\n  padding: 6px 10px;\r\n  border: 1px solid var(--jp-border-color1);\r\n  border-radius: 4px;\r\n  background: var(--jp-layout-color1);\r\n  color: var(--jp-ui-font-color1);\r\n  font-family: var(--jp-code-font-family);\r\n  font-size: 12px;\r\n  outline: none;\r\n}\r\n\r\n.llm-rootdir-input:focus {\r\n  border-color: var(--jp-brand-color1);\r\n}\r\n\r\n.llm-rootdir-actions {\r\n  display: flex;\r\n  gap: 8px;\r\n}\r\n\r\n.llm-rootdir-save,\r\n.llm-rootdir-cancel {\r\n  flex: 1;\r\n  padding: 6px 12px;\r\n  border: none;\r\n  border-radius: 4px;\r\n  font-size: 12px;\r\n  font-weight: 500;\r\n  cursor: pointer;\r\n  transition: background-color 0.15s;\r\n}\r\n\r\n.llm-rootdir-save {\r\n  background-color: var(--jp-brand-color1);\r\n  color: white;\r\n}\r\n\r\n.llm-rootdir-save:hover {\r\n  background-color: var(--jp-brand-color0);\r\n}\r\n\r\n.llm-rootdir-cancel {\r\n  background-color: var(--jp-layout-color2);\r\n  color: var(--jp-ui-font-color1);\r\n}\r\n\r\n.llm-rootdir-cancel:hover {\r\n  background-color: var(--jp-layout-color3);\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/index.css"
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/index.css ***!
  \***************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_chat_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./chat.css */ "./node_modules/css-loader/dist/cjs.js!./style/chat.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_agent_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./agent.css */ "./node_modules/css-loader/dist/cjs.js!./style/agent.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_memory_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./memory.css */ "./node_modules/css-loader/dist/cjs.js!./style/memory.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_skill_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./skill.css */ "./node_modules/css-loader/dist/cjs.js!./style/skill.css");
// Imports






var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_chat_css__WEBPACK_IMPORTED_MODULE_2__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_agent_css__WEBPACK_IMPORTED_MODULE_3__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_memory_css__WEBPACK_IMPORTED_MODULE_4__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_skill_css__WEBPACK_IMPORTED_MODULE_5__["default"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * JupyterLab LLM Assistant Extension Styles
 *
 * This file imports all component styles.
 */

/* Import base styles */

/* Variables */
:root {
  --llm-primary-color: #1976d2;
  --llm-primary-hover: #1565c0;
  --llm-bg-color: var(--jp-layout-color1);
  --llm-text-color: var(--jp-content-font-color1);
  --llm-border-color: var(--jp-border-color1);
  --llm-user-bg: #e3f2fd;
  --llm-assistant-bg: var(--jp-layout-color2);
  --llm-code-bg: var(--jp-layout-color3);
  --llm-success-color: #4caf50;
  --llm-error-color: #f44336;
  --llm-warning-color: #ff9800;
}

/* Dark theme adjustments */
body[data-jp-theme-light='false'] {
  --llm-user-bg: #1e3a5f;
}

/* Main panel container */
.llm-assistant-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: var(--llm-bg-color);
  color: var(--llm-text-color);
}

.llm-assistant-content {
  display: flex;
  flex-direction: column;
  height: 100%;
}`, "",{"version":3,"sources":["webpack://./style/index.css"],"names":[],"mappings":"AAAA;;;;EAIE;;AAEF,uBAAuB;;AAMvB,cAAc;AACd;EACE,4BAA4B;EAC5B,4BAA4B;EAC5B,uCAAuC;EACvC,+CAA+C;EAC/C,2CAA2C;EAC3C,sBAAsB;EACtB,2CAA2C;EAC3C,sCAAsC;EACtC,4BAA4B;EAC5B,0BAA0B;EAC1B,4BAA4B;AAC9B;;AAEA,2BAA2B;AAC3B;EACE,sBAAsB;AACxB;;AAEA,yBAAyB;AACzB;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,qCAAqC;EACrC,4BAA4B;AAC9B;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;AACd","sourcesContent":["/**\r\n * JupyterLab LLM Assistant Extension Styles\r\n *\r\n * This file imports all component styles.\r\n */\r\n\r\n/* Import base styles */\r\n@import './chat.css';\r\n@import './agent.css';\r\n@import './memory.css';\r\n@import './skill.css';\r\n\r\n/* Variables */\r\n:root {\r\n  --llm-primary-color: #1976d2;\r\n  --llm-primary-hover: #1565c0;\r\n  --llm-bg-color: var(--jp-layout-color1);\r\n  --llm-text-color: var(--jp-content-font-color1);\r\n  --llm-border-color: var(--jp-border-color1);\r\n  --llm-user-bg: #e3f2fd;\r\n  --llm-assistant-bg: var(--jp-layout-color2);\r\n  --llm-code-bg: var(--jp-layout-color3);\r\n  --llm-success-color: #4caf50;\r\n  --llm-error-color: #f44336;\r\n  --llm-warning-color: #ff9800;\r\n}\r\n\r\n/* Dark theme adjustments */\r\nbody[data-jp-theme-light='false'] {\r\n  --llm-user-bg: #1e3a5f;\r\n}\r\n\r\n/* Main panel container */\r\n.llm-assistant-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n  background-color: var(--llm-bg-color);\r\n  color: var(--llm-text-color);\r\n}\r\n\r\n.llm-assistant-content {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/memory.css"
/*!****************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/memory.css ***!
  \****************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Memory panel styles
 */

/* ─── Memory Panel Shell ─────────────────────────────────────── */

.memory-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  background: var(--jp-layout-color1);
}

/* ─── Header ─────────────────────────────────────────────────── */

.memory-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  flex-shrink: 0;
}

.memory-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
}

.memory-header-icon {
  color: var(--jp-brand-color1, #1976d2);
}

.memory-header-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--jp-content-font-color1);
}

.memory-count-badge {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 10px;
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
}

.memory-header-actions {
  display: flex;
  gap: 4px;
}

.memory-icon-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 4px;
  border: none;
  background: transparent;
  border-radius: 4px;
  cursor: pointer;
  color: var(--jp-content-font-color2);
  transition: background 0.15s;
}

.memory-icon-btn:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

/* ─── Info bar ───────────────────────────────────────────────── */

.memory-info-bar {
  display: flex;
  align-items: flex-start;
  gap: 5px;
  padding: 5px 10px;
  background: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
  font-size: 10px;
  color: var(--jp-content-font-color2);
  line-height: 1.4;
  flex-shrink: 0;
}

/* ─── Error ──────────────────────────────────────────────────── */

.memory-error {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 10px;
  background: #ffeaea;
  color: #c62828;
  font-size: 11px;
  border-bottom: 1px solid #ffcdd2;
  flex-shrink: 0;
}

body[data-jp-theme-light='false'] .memory-error {
  background: #3e1a1a;
  color: #ef9a9a;
  border-bottom-color: #5c2626;
}

.memory-error button {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  font-size: 14px;
  padding: 0 2px;
  line-height: 1;
  flex-shrink: 0;
}

/* ─── Form ───────────────────────────────────────────────────── */

.memory-form-wrapper {
  flex-shrink: 0;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
}

.memory-form {
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.memory-form-field {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.memory-form-label {
  font-size: 10px;
  font-weight: 600;
  color: var(--jp-content-font-color2);
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.memory-form-input,
.memory-form-textarea {
  font-size: 12px;
  font-family: var(--jp-content-font-family);
  padding: 5px 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
  outline: none;
  transition: border-color 0.15s;
  resize: vertical;
}

.memory-form-input:focus,
.memory-form-textarea:focus {
  border-color: var(--jp-brand-color1, #1976d2);
}

.memory-form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
}

/* ─── Buttons ────────────────────────────────────────────────── */

.memory-btn {
  font-size: 11px;
  font-weight: 500;
  padding: 5px 12px;
  border-radius: 5px;
  border: none;
  cursor: pointer;
  transition: background 0.15s, opacity 0.15s;
}

.memory-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.memory-btn-primary {
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
}

.memory-btn-primary:hover:not(:disabled) {
  background: var(--jp-brand-color0, #1565c0);
}

.memory-btn-secondary {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

.memory-btn-secondary:hover:not(:disabled) {
  background: var(--jp-layout-color4, var(--jp-layout-color3));
}

/* ─── List ───────────────────────────────────────────────────── */

.memory-list {
  flex: 1;
  overflow-y: auto;
}

.memory-loading,
.memory-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 30px 16px;
  font-size: 12px;
  color: var(--jp-content-font-color2);
  text-align: center;
}

.memory-empty p {
  margin: 0;
}

/* ─── Memory item ────────────────────────────────────────────── */

.memory-item {
  padding: 8px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  transition: background 0.12s;
}

.memory-item:hover {
  background: var(--jp-layout-color2);
}

.memory-item-disabled {
  opacity: 0.5;
}

.memory-item-header {
  display: flex;
  align-items: center;
  gap: 6px;
}

.memory-item-title {
  flex: 1;
  font-size: 12px;
  font-weight: 600;
  color: var(--jp-content-font-color1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.memory-item-actions {
  display: flex;
  gap: 2px;
  flex-shrink: 0;
}

.memory-item-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 3px;
  border: none;
  background: transparent;
  border-radius: 3px;
  cursor: pointer;
  color: var(--jp-content-font-color3);
  transition: color 0.12s, background 0.12s;
}

.memory-item-btn:hover {
  color: var(--jp-content-font-color1);
  background: var(--jp-layout-color3);
}

.memory-item-btn-danger:hover {
  color: #ef4444;
}

.memory-confirm-delete {
  display: flex;
  gap: 2px;
}

.memory-item-content {
  font-size: 11px;
  line-height: 1.5;
  color: var(--jp-content-font-color2);
  margin-top: 4px;
  white-space: pre-wrap;
  word-break: break-word;
}

.memory-item-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  margin-top: 5px;
}

.memory-tag {
  font-size: 9px;
  padding: 1px 5px;
  border-radius: 10px;
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color2);
  border: 1px solid var(--jp-border-color2);
}

/* ─── Toggle switch ──────────────────────────────────────────── */

.memory-toggle {
  position: relative;
  width: 26px;
  height: 14px;
  border-radius: 7px;
  border: none;
  cursor: pointer;
  flex-shrink: 0;
  padding: 0;
  transition: background 0.2s;
}

.memory-toggle-on {
  background: var(--jp-brand-color1, #1976d2);
}

.memory-toggle-off {
  background: var(--jp-layout-color4, #bbb);
}

body[data-jp-theme-light='false'] .memory-toggle-off {
  background: #555;
}

.memory-toggle-thumb {
  position: absolute;
  top: 2px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #fff;
  transition: left 0.2s;
}

.memory-toggle-on .memory-toggle-thumb {
  left: 14px;
}

.memory-toggle-off .memory-toggle-thumb {
  left: 2px;
}

/* ══════════════════════════════════════════════════════════════
   Context File Panel
   ══════════════════════════════════════════════════════════════ */

.context-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  background: var(--jp-layout-color1);
}

.context-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  flex-shrink: 0;
}

.context-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
}

.context-header-icon {
  color: var(--jp-brand-color1, #1976d2);
}

.context-header-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--jp-content-font-color1);
}

.context-count-badge {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 10px;
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
}

.context-section {
  padding: 8px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.context-label {
  font-size: 10px;
  font-weight: 600;
  color: var(--jp-content-font-color2);
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.context-input {
  font-size: 12px;
  font-family: var(--jp-content-font-family);
  padding: 5px 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
  outline: none;
  transition: border-color 0.15s;
}

.context-input:focus {
  border-color: var(--jp-brand-color1, #1976d2);
}

.context-input-grow {
  flex: 1;
}

.context-path-row {
  display: flex;
  gap: 6px;
}

.context-resolve-btn {
  font-size: 11px;
  font-weight: 600;
  padding: 5px 12px;
  border: none;
  border-radius: 4px;
  background: var(--jp-brand-color1, #1976d2);
  color: #fff;
  cursor: pointer;
  transition: background 0.15s, opacity 0.15s;
  flex-shrink: 0;
}

.context-resolve-btn:hover:not(:disabled) {
  background: var(--jp-brand-color0, #1565c0);
}

.context-resolve-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* ─── File list ──────────────────────────────────────────────── */

.context-file-list-wrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border-bottom: 1px solid var(--jp-border-color2);
}

.context-file-list-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px 10px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
  flex-shrink: 0;
}

.context-list-actions {
  display: flex;
  gap: 8px;
}

.context-text-btn {
  font-size: 10px;
  font-weight: 600;
  padding: 1px 6px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 3px;
  background: transparent;
  color: var(--jp-content-font-color2);
  cursor: pointer;
  transition: background 0.12s;
}

.context-text-btn:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

.context-file-list {
  flex: 1;
  overflow-y: auto;
}

.context-file-item {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  cursor: pointer;
  transition: background 0.1s;
  font-size: 11px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.context-file-item:hover {
  background: var(--jp-layout-color2);
}

.context-file-checked {
  background: var(--jp-brand-color3, #e3f2fd);
}

body[data-jp-theme-light='false'] .context-file-checked {
  background: #1a2a3a;
}

.context-file-error {
  opacity: 0.6;
}

.context-file-checkbox {
  flex-shrink: 0;
  width: 13px;
  height: 13px;
  accent-color: var(--jp-brand-color1, #1976d2);
}

.context-file-path {
  flex: 1;
  font-family: var(--jp-code-font-family, monospace);
  color: var(--jp-content-font-color1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.context-file-meta {
  font-size: 9px;
  color: var(--jp-content-font-color3);
  flex-shrink: 0;
}

.context-file-err-badge {
  font-size: 9px;
  font-weight: 700;
  color: #ef4444;
  background: #ffeaea;
  padding: 1px 4px;
  border-radius: 3px;
  flex-shrink: 0;
}

body[data-jp-theme-light='false'] .context-file-err-badge {
  background: #3e1a1a;
}

.context-file-remove {
  flex-shrink: 0;
  border: none;
  background: transparent;
  cursor: pointer;
  color: var(--jp-content-font-color3);
  font-size: 13px;
  padding: 0 2px;
  line-height: 1;
  transition: color 0.12s;
}

.context-file-remove:hover {
  color: #ef4444;
}

/* ─── Status bar ─────────────────────────────────────────────── */

.context-status-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 10px;
  font-size: 10px;
  color: var(--jp-content-font-color2);
  background: var(--jp-layout-color2);
  border-top: 1px solid var(--jp-border-color2);
  flex-shrink: 0;
}

.context-truncated-badge {
  font-size: 9px;
  font-weight: 600;
  color: #f0a500;
  background: rgba(240, 165, 0, 0.1);
  padding: 1px 5px;
  border-radius: 3px;
  border: 1px solid rgba(240, 165, 0, 0.3);
}
`, "",{"version":3,"sources":["webpack://./style/memory.css"],"names":[],"mappings":"AAAA;;EAEE;;AAEF,mEAAmE;;AAEnE;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,gBAAgB;EAChB,mCAAmC;AACrC;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,gDAAgD;EAChD,mCAAmC;EACnC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,sCAAsC;AACxC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,mBAAmB;EACnB,2CAA2C;EAC3C,WAAW;AACb;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,YAAY;EACZ,YAAY;EACZ,uBAAuB;EACvB,kBAAkB;EAClB,eAAe;EACf,oCAAoC;EACpC,4BAA4B;AAC9B;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,uBAAuB;EACvB,QAAQ;EACR,iBAAiB;EACjB,mCAAmC;EACnC,gDAAgD;EAChD,eAAe;EACf,oCAAoC;EACpC,gBAAgB;EAChB,cAAc;AAChB;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,mBAAmB;EACnB,cAAc;EACd,eAAe;EACf,gCAAgC;EAChC,cAAc;AAChB;;AAEA;EACE,mBAAmB;EACnB,cAAc;EACd,4BAA4B;AAC9B;;AAEA;EACE,gBAAgB;EAChB,YAAY;EACZ,eAAe;EACf,cAAc;EACd,eAAe;EACf,cAAc;EACd,cAAc;EACd,cAAc;AAChB;;AAEA,mEAAmE;;AAEnE;EACE,cAAc;EACd,gDAAgD;EAChD,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,yBAAyB;EACzB,sBAAsB;AACxB;;AAEA;;EAEE,eAAe;EACf,0CAA0C;EAC1C,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,oCAAoC;EACpC,aAAa;EACb,8BAA8B;EAC9B,gBAAgB;AAClB;;AAEA;;EAEE,6CAA6C;AAC/C;;AAEA;EACE,aAAa;EACb,yBAAyB;EACzB,QAAQ;AACV;;AAEA,mEAAmE;;AAEnE;EACE,eAAe;EACf,gBAAgB;EAChB,iBAAiB;EACjB,kBAAkB;EAClB,YAAY;EACZ,eAAe;EACf,2CAA2C;AAC7C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,2CAA2C;EAC3C,WAAW;AACb;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,4DAA4D;AAC9D;;AAEA,mEAAmE;;AAEnE;EACE,OAAO;EACP,gBAAgB;AAClB;;AAEA;;EAEE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,SAAS;EACT,kBAAkB;EAClB,eAAe;EACf,oCAAoC;EACpC,kBAAkB;AACpB;;AAEA;EACE,SAAS;AACX;;AAEA,mEAAmE;;AAEnE;EACE,iBAAiB;EACjB,gDAAgD;EAChD,4BAA4B;AAC9B;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,OAAO;EACP,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,YAAY;EACZ,YAAY;EACZ,uBAAuB;EACvB,kBAAkB;EAClB,eAAe;EACf,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA;EACE,oCAAoC;EACpC,mCAAmC;AACrC;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,eAAe;EACf,qBAAqB;EACrB,sBAAsB;AACxB;;AAEA;EACE,aAAa;EACb,eAAe;EACf,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,mBAAmB;EACnB,mCAAmC;EACnC,oCAAoC;EACpC,yCAAyC;AAC3C;;AAEA,mEAAmE;;AAEnE;EACE,kBAAkB;EAClB,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,YAAY;EACZ,eAAe;EACf,cAAc;EACd,UAAU;EACV,2BAA2B;AAC7B;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,yCAAyC;AAC3C;;AAEA;EACE,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;EAClB,QAAQ;EACR,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,gBAAgB;EAChB,qBAAqB;AACvB;;AAEA;EACE,UAAU;AACZ;;AAEA;EACE,SAAS;AACX;;AAEA;;mEAEmE;;AAEnE;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,gBAAgB;EAChB,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,gDAAgD;EAChD,mCAAmC;EACnC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,sCAAsC;AACxC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,mBAAmB;EACnB,2CAA2C;EAC3C,WAAW;AACb;;AAEA;EACE,iBAAiB;EACjB,gDAAgD;EAChD,cAAc;EACd,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,oCAAoC;EACpC,yBAAyB;EACzB,sBAAsB;AACxB;;AAEA;EACE,eAAe;EACf,0CAA0C;EAC1C,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,oCAAoC;EACpC,aAAa;EACb,8BAA8B;AAChC;;AAEA;EACE,6CAA6C;AAC/C;;AAEA;EACE,OAAO;AACT;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,iBAAiB;EACjB,YAAY;EACZ,kBAAkB;EAClB,2CAA2C;EAC3C,WAAW;EACX,eAAe;EACf,2CAA2C;EAC3C,cAAc;AAChB;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,mEAAmE;;AAEnE;EACE,OAAO;EACP,aAAa;EACb,sBAAsB;EACtB,gBAAgB;EAChB,gDAAgD;AAClD;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,gDAAgD;EAChD,mCAAmC;EACnC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,uBAAuB;EACvB,oCAAoC;EACpC,eAAe;EACf,4BAA4B;AAC9B;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,OAAO;EACP,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,iBAAiB;EACjB,eAAe;EACf,2BAA2B;EAC3B,eAAe;EACf,gDAAgD;AAClD;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,2CAA2C;AAC7C;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,cAAc;EACd,WAAW;EACX,YAAY;EACZ,6CAA6C;AAC/C;;AAEA;EACE,OAAO;EACP,kDAAkD;EAClD,oCAAoC;EACpC,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,oCAAoC;EACpC,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,cAAc;EACd,mBAAmB;EACnB,gBAAgB;EAChB,kBAAkB;EAClB,cAAc;AAChB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,YAAY;EACZ,uBAAuB;EACvB,eAAe;EACf,oCAAoC;EACpC,eAAe;EACf,cAAc;EACd,cAAc;EACd,uBAAuB;AACzB;;AAEA;EACE,cAAc;AAChB;;AAEA,mEAAmE;;AAEnE;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,eAAe;EACf,oCAAoC;EACpC,mCAAmC;EACnC,6CAA6C;EAC7C,cAAc;AAChB;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,cAAc;EACd,kCAAkC;EAClC,gBAAgB;EAChB,kBAAkB;EAClB,wCAAwC;AAC1C","sourcesContent":["/**\r\n * Memory panel styles\r\n */\r\n\r\n/* ─── Memory Panel Shell ─────────────────────────────────────── */\r\n\r\n.memory-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n  overflow: hidden;\r\n  background: var(--jp-layout-color1);\r\n}\r\n\r\n/* ─── Header ─────────────────────────────────────────────────── */\r\n\r\n.memory-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 6px 10px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.memory-header-left {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n}\r\n\r\n.memory-header-icon {\r\n  color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.memory-header-title {\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.memory-count-badge {\r\n  font-size: 10px;\r\n  padding: 1px 6px;\r\n  border-radius: 10px;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n}\r\n\r\n.memory-header-actions {\r\n  display: flex;\r\n  gap: 4px;\r\n}\r\n\r\n.memory-icon-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  padding: 4px;\r\n  border: none;\r\n  background: transparent;\r\n  border-radius: 4px;\r\n  cursor: pointer;\r\n  color: var(--jp-content-font-color2);\r\n  transition: background 0.15s;\r\n}\r\n\r\n.memory-icon-btn:hover {\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n/* ─── Info bar ───────────────────────────────────────────────── */\r\n\r\n.memory-info-bar {\r\n  display: flex;\r\n  align-items: flex-start;\r\n  gap: 5px;\r\n  padding: 5px 10px;\r\n  background: var(--jp-layout-color2);\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  font-size: 10px;\r\n  color: var(--jp-content-font-color2);\r\n  line-height: 1.4;\r\n  flex-shrink: 0;\r\n}\r\n\r\n/* ─── Error ──────────────────────────────────────────────────── */\r\n\r\n.memory-error {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 6px 10px;\r\n  background: #ffeaea;\r\n  color: #c62828;\r\n  font-size: 11px;\r\n  border-bottom: 1px solid #ffcdd2;\r\n  flex-shrink: 0;\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .memory-error {\r\n  background: #3e1a1a;\r\n  color: #ef9a9a;\r\n  border-bottom-color: #5c2626;\r\n}\r\n\r\n.memory-error button {\r\n  background: none;\r\n  border: none;\r\n  cursor: pointer;\r\n  color: inherit;\r\n  font-size: 14px;\r\n  padding: 0 2px;\r\n  line-height: 1;\r\n  flex-shrink: 0;\r\n}\r\n\r\n/* ─── Form ───────────────────────────────────────────────────── */\r\n\r\n.memory-form-wrapper {\r\n  flex-shrink: 0;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color1);\r\n}\r\n\r\n.memory-form {\r\n  padding: 10px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 8px;\r\n}\r\n\r\n.memory-form-field {\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 3px;\r\n}\r\n\r\n.memory-form-label {\r\n  font-size: 10px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color2);\r\n  text-transform: uppercase;\r\n  letter-spacing: 0.04em;\r\n}\r\n\r\n.memory-form-input,\r\n.memory-form-textarea {\r\n  font-size: 12px;\r\n  font-family: var(--jp-content-font-family);\r\n  padding: 5px 8px;\r\n  border: 1px solid var(--jp-border-color2);\r\n  border-radius: 4px;\r\n  background: var(--jp-layout-color2);\r\n  color: var(--jp-content-font-color1);\r\n  outline: none;\r\n  transition: border-color 0.15s;\r\n  resize: vertical;\r\n}\r\n\r\n.memory-form-input:focus,\r\n.memory-form-textarea:focus {\r\n  border-color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.memory-form-actions {\r\n  display: flex;\r\n  justify-content: flex-end;\r\n  gap: 6px;\r\n}\r\n\r\n/* ─── Buttons ────────────────────────────────────────────────── */\r\n\r\n.memory-btn {\r\n  font-size: 11px;\r\n  font-weight: 500;\r\n  padding: 5px 12px;\r\n  border-radius: 5px;\r\n  border: none;\r\n  cursor: pointer;\r\n  transition: background 0.15s, opacity 0.15s;\r\n}\r\n\r\n.memory-btn:disabled {\r\n  opacity: 0.5;\r\n  cursor: not-allowed;\r\n}\r\n\r\n.memory-btn-primary {\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n}\r\n\r\n.memory-btn-primary:hover:not(:disabled) {\r\n  background: var(--jp-brand-color0, #1565c0);\r\n}\r\n\r\n.memory-btn-secondary {\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.memory-btn-secondary:hover:not(:disabled) {\r\n  background: var(--jp-layout-color4, var(--jp-layout-color3));\r\n}\r\n\r\n/* ─── List ───────────────────────────────────────────────────── */\r\n\r\n.memory-list {\r\n  flex: 1;\r\n  overflow-y: auto;\r\n}\r\n\r\n.memory-loading,\r\n.memory-empty {\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  justify-content: center;\r\n  gap: 10px;\r\n  padding: 30px 16px;\r\n  font-size: 12px;\r\n  color: var(--jp-content-font-color2);\r\n  text-align: center;\r\n}\r\n\r\n.memory-empty p {\r\n  margin: 0;\r\n}\r\n\r\n/* ─── Memory item ────────────────────────────────────────────── */\r\n\r\n.memory-item {\r\n  padding: 8px 10px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  transition: background 0.12s;\r\n}\r\n\r\n.memory-item:hover {\r\n  background: var(--jp-layout-color2);\r\n}\r\n\r\n.memory-item-disabled {\r\n  opacity: 0.5;\r\n}\r\n\r\n.memory-item-header {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n}\r\n\r\n.memory-item-title {\r\n  flex: 1;\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color1);\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n\r\n.memory-item-actions {\r\n  display: flex;\r\n  gap: 2px;\r\n  flex-shrink: 0;\r\n}\r\n\r\n.memory-item-btn {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  padding: 3px;\r\n  border: none;\r\n  background: transparent;\r\n  border-radius: 3px;\r\n  cursor: pointer;\r\n  color: var(--jp-content-font-color3);\r\n  transition: color 0.12s, background 0.12s;\r\n}\r\n\r\n.memory-item-btn:hover {\r\n  color: var(--jp-content-font-color1);\r\n  background: var(--jp-layout-color3);\r\n}\r\n\r\n.memory-item-btn-danger:hover {\r\n  color: #ef4444;\r\n}\r\n\r\n.memory-confirm-delete {\r\n  display: flex;\r\n  gap: 2px;\r\n}\r\n\r\n.memory-item-content {\r\n  font-size: 11px;\r\n  line-height: 1.5;\r\n  color: var(--jp-content-font-color2);\r\n  margin-top: 4px;\r\n  white-space: pre-wrap;\r\n  word-break: break-word;\r\n}\r\n\r\n.memory-item-tags {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  gap: 3px;\r\n  margin-top: 5px;\r\n}\r\n\r\n.memory-tag {\r\n  font-size: 9px;\r\n  padding: 1px 5px;\r\n  border-radius: 10px;\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color2);\r\n  border: 1px solid var(--jp-border-color2);\r\n}\r\n\r\n/* ─── Toggle switch ──────────────────────────────────────────── */\r\n\r\n.memory-toggle {\r\n  position: relative;\r\n  width: 26px;\r\n  height: 14px;\r\n  border-radius: 7px;\r\n  border: none;\r\n  cursor: pointer;\r\n  flex-shrink: 0;\r\n  padding: 0;\r\n  transition: background 0.2s;\r\n}\r\n\r\n.memory-toggle-on {\r\n  background: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.memory-toggle-off {\r\n  background: var(--jp-layout-color4, #bbb);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .memory-toggle-off {\r\n  background: #555;\r\n}\r\n\r\n.memory-toggle-thumb {\r\n  position: absolute;\r\n  top: 2px;\r\n  width: 10px;\r\n  height: 10px;\r\n  border-radius: 50%;\r\n  background: #fff;\r\n  transition: left 0.2s;\r\n}\r\n\r\n.memory-toggle-on .memory-toggle-thumb {\r\n  left: 14px;\r\n}\r\n\r\n.memory-toggle-off .memory-toggle-thumb {\r\n  left: 2px;\r\n}\r\n\r\n/* ══════════════════════════════════════════════════════════════\r\n   Context File Panel\r\n   ══════════════════════════════════════════════════════════════ */\r\n\r\n.context-panel {\r\n  display: flex;\r\n  flex-direction: column;\r\n  height: 100%;\r\n  overflow: hidden;\r\n  background: var(--jp-layout-color1);\r\n}\r\n\r\n.context-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 6px 10px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.context-header-left {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n}\r\n\r\n.context-header-icon {\r\n  color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.context-header-title {\r\n  font-size: 12px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.context-count-badge {\r\n  font-size: 10px;\r\n  padding: 1px 6px;\r\n  border-radius: 10px;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n}\r\n\r\n.context-section {\r\n  padding: 8px 10px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  flex-shrink: 0;\r\n  display: flex;\r\n  flex-direction: column;\r\n  gap: 4px;\r\n}\r\n\r\n.context-label {\r\n  font-size: 10px;\r\n  font-weight: 600;\r\n  color: var(--jp-content-font-color2);\r\n  text-transform: uppercase;\r\n  letter-spacing: 0.04em;\r\n}\r\n\r\n.context-input {\r\n  font-size: 12px;\r\n  font-family: var(--jp-content-font-family);\r\n  padding: 5px 8px;\r\n  border: 1px solid var(--jp-border-color2);\r\n  border-radius: 4px;\r\n  background: var(--jp-layout-color2);\r\n  color: var(--jp-content-font-color1);\r\n  outline: none;\r\n  transition: border-color 0.15s;\r\n}\r\n\r\n.context-input:focus {\r\n  border-color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.context-input-grow {\r\n  flex: 1;\r\n}\r\n\r\n.context-path-row {\r\n  display: flex;\r\n  gap: 6px;\r\n}\r\n\r\n.context-resolve-btn {\r\n  font-size: 11px;\r\n  font-weight: 600;\r\n  padding: 5px 12px;\r\n  border: none;\r\n  border-radius: 4px;\r\n  background: var(--jp-brand-color1, #1976d2);\r\n  color: #fff;\r\n  cursor: pointer;\r\n  transition: background 0.15s, opacity 0.15s;\r\n  flex-shrink: 0;\r\n}\r\n\r\n.context-resolve-btn:hover:not(:disabled) {\r\n  background: var(--jp-brand-color0, #1565c0);\r\n}\r\n\r\n.context-resolve-btn:disabled {\r\n  opacity: 0.5;\r\n  cursor: not-allowed;\r\n}\r\n\r\n/* ─── File list ──────────────────────────────────────────────── */\r\n\r\n.context-file-list-wrapper {\r\n  flex: 1;\r\n  display: flex;\r\n  flex-direction: column;\r\n  overflow: hidden;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n}\r\n\r\n.context-file-list-header {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 5px 10px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n  background: var(--jp-layout-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.context-list-actions {\r\n  display: flex;\r\n  gap: 8px;\r\n}\r\n\r\n.context-text-btn {\r\n  font-size: 10px;\r\n  font-weight: 600;\r\n  padding: 1px 6px;\r\n  border: 1px solid var(--jp-border-color2);\r\n  border-radius: 3px;\r\n  background: transparent;\r\n  color: var(--jp-content-font-color2);\r\n  cursor: pointer;\r\n  transition: background 0.12s;\r\n}\r\n\r\n.context-text-btn:hover {\r\n  background: var(--jp-layout-color3);\r\n  color: var(--jp-content-font-color1);\r\n}\r\n\r\n.context-file-list {\r\n  flex: 1;\r\n  overflow-y: auto;\r\n}\r\n\r\n.context-file-item {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 6px;\r\n  padding: 4px 10px;\r\n  cursor: pointer;\r\n  transition: background 0.1s;\r\n  font-size: 11px;\r\n  border-bottom: 1px solid var(--jp-border-color2);\r\n}\r\n\r\n.context-file-item:hover {\r\n  background: var(--jp-layout-color2);\r\n}\r\n\r\n.context-file-checked {\r\n  background: var(--jp-brand-color3, #e3f2fd);\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .context-file-checked {\r\n  background: #1a2a3a;\r\n}\r\n\r\n.context-file-error {\r\n  opacity: 0.6;\r\n}\r\n\r\n.context-file-checkbox {\r\n  flex-shrink: 0;\r\n  width: 13px;\r\n  height: 13px;\r\n  accent-color: var(--jp-brand-color1, #1976d2);\r\n}\r\n\r\n.context-file-path {\r\n  flex: 1;\r\n  font-family: var(--jp-code-font-family, monospace);\r\n  color: var(--jp-content-font-color1);\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n\r\n.context-file-meta {\r\n  font-size: 9px;\r\n  color: var(--jp-content-font-color3);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.context-file-err-badge {\r\n  font-size: 9px;\r\n  font-weight: 700;\r\n  color: #ef4444;\r\n  background: #ffeaea;\r\n  padding: 1px 4px;\r\n  border-radius: 3px;\r\n  flex-shrink: 0;\r\n}\r\n\r\nbody[data-jp-theme-light='false'] .context-file-err-badge {\r\n  background: #3e1a1a;\r\n}\r\n\r\n.context-file-remove {\r\n  flex-shrink: 0;\r\n  border: none;\r\n  background: transparent;\r\n  cursor: pointer;\r\n  color: var(--jp-content-font-color3);\r\n  font-size: 13px;\r\n  padding: 0 2px;\r\n  line-height: 1;\r\n  transition: color 0.12s;\r\n}\r\n\r\n.context-file-remove:hover {\r\n  color: #ef4444;\r\n}\r\n\r\n/* ─── Status bar ─────────────────────────────────────────────── */\r\n\r\n.context-status-bar {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  padding: 4px 10px;\r\n  font-size: 10px;\r\n  color: var(--jp-content-font-color2);\r\n  background: var(--jp-layout-color2);\r\n  border-top: 1px solid var(--jp-border-color2);\r\n  flex-shrink: 0;\r\n}\r\n\r\n.context-truncated-badge {\r\n  font-size: 9px;\r\n  font-weight: 600;\r\n  color: #f0a500;\r\n  background: rgba(240, 165, 0, 0.1);\r\n  padding: 1px 5px;\r\n  border-radius: 3px;\r\n  border: 1px solid rgba(240, 165, 0, 0.3);\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/skill.css"
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/skill.css ***!
  \***************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/**
 * Skill Panel Styles
 */

.llm-skill-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--jp-layout-color1);
}

.llm-skill-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  border-bottom: 1px solid var(--jp-border-color1);
}

.llm-skill-header h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.llm-skill-header-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.llm-skill-content {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}

.llm-skill-empty {
  text-align: center;
  padding: 32px 16px;
  color: var(--jp-ui-font-color2);
}

.llm-skill-empty .llm-hint {
  font-size: 12px;
  margin-top: 8px;
  opacity: 0.7;
}

.llm-install-sample-btn {
  margin-top: 16px;
  padding: 8px 16px;
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  color: var(--jp-ui-font-color1);
  cursor: pointer;
}

.llm-install-sample-btn:hover {
  background: var(--jp-layout-color3);
}

.llm-skill-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.llm-skill-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
  border: 1px solid transparent;
}

.llm-skill-item:hover {
  background: var(--jp-layout-color2);
  border-color: var(--jp-border-color1);
}

.llm-skill-disabled {
  opacity: 0.6;
}

.llm-skill-info {
  flex: 1;
  min-width: 0;
}

.llm-skill-name {
  font-size: 13px;
  font-weight: 500;
  margin-bottom: 4px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.llm-skill-version {
  font-size: 11px;
  font-weight: 400;
  color: var(--jp-ui-font-color2);
  background: var(--jp-layout-color3);
  padding: 1px 4px;
  border-radius: 2px;
}

.llm-skill-meta {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.llm-skill-description {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.llm-skill-author {
  font-size: 11px;
  color: var(--jp-ui-font-color2);
  opacity: 0.7;
}

.llm-skill-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.llm-skill-toggle,
.llm-skill-delete {
  background: transparent;
  border: none;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  opacity: 0.5;
  transition: opacity 0.15s, background 0.15s;
}

.llm-skill-toggle:hover,
.llm-skill-delete:hover {
  opacity: 1;
}

.llm-skill-toggle.llm-enabled {
  color: var(--jp-success-color0);
}

.llm-skill-toggle.llm-disabled {
  color: var(--jp-ui-font-color2);
}

.llm-skill-toggle:hover {
  background: var(--jp-layout-color3);
}

.llm-skill-delete:hover {
  background: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.llm-skill-error {
  padding: 16px;
  text-align: center;
  color: var(--jp-error-color0);
}

.llm-skill-error button {
  margin-top: 8px;
  padding: 6px 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
  cursor: pointer;
}

/* Install Form */
.llm-skill-install-form {
  padding: 12px;
  border-bottom: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color2);
}

.llm-skill-install-form h5 {
  margin: 0 0 12px 0;
  font-size: 13px;
  font-weight: 600;
}

.llm-skill-install-toggle {
  display: flex;
  gap: 4px;
  margin-bottom: 12px;
  background: var(--jp-layout-color1);
  padding: 4px;
  border-radius: 4px;
}

.llm-skill-install-toggle button {
  flex: 1;
  padding: 6px 12px;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color2);
  font-size: 12px;
  cursor: pointer;
  border-radius: 3px;
  transition: background 0.15s, color 0.15s;
}

.llm-skill-install-toggle button:hover {
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color1);
}

.llm-skill-install-toggle button.active {
  background: var(--jp-layout-color3);
  color: var(--jp-ui-font-color1);
  font-weight: 500;
}

.llm-skill-install-field {
  margin-bottom: 12px;
}

.llm-skill-install-field label {
  display: block;
  font-size: 12px;
  margin-bottom: 4px;
  color: var(--jp-ui-font-color2);
}

.llm-skill-install-field input,
.llm-skill-install-field textarea {
  width: 100%;
  padding: 6px 8px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-size: 12px;
  font-family: monospace;
  box-sizing: border-box;
}

.llm-skill-install-field textarea {
  resize: vertical;
  min-height: 100px;
}

.llm-skill-install-error {
  padding: 8px;
  margin-bottom: 8px;
  background: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
  border-radius: 4px;
  font-size: 12px;
}

.llm-skill-install-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

/* Skill Detail */
.llm-skill-detail {
  padding: 12px;
  border-top: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color2);
}

.llm-skill-detail h5 {
  margin: 0 0 8px 0;
  font-size: 13px;
  font-weight: 600;
}

.llm-skill-detail-desc {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  margin: 0 0 12px 0;
}

.llm-skill-detail-prompt {
  margin-bottom: 12px;
}

.llm-skill-detail-prompt label {
  display: block;
  font-size: 11px;
  color: var(--jp-ui-font-color2);
  margin-bottom: 4px;
}

.llm-skill-prompt-preview {
  padding: 8px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  font-size: 11px;
  font-family: monospace;
  white-space: pre-wrap;
  word-break: break-word;
  max-height: 200px;
  overflow-y: auto;
  margin: 0;
}

.llm-skill-detail-actions {
  display: flex;
  justify-content: flex-end;
}

.llm-edit-prompt-btn {
  padding: 6px 12px;
  background: var(--jp-layout-color3);
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  color: var(--jp-ui-font-color1);
  font-size: 12px;
  cursor: pointer;
}

.llm-edit-prompt-btn:hover {
  background: var(--jp-layout-color2);
}

/* Edit Prompt Form */
.llm-skill-edit-prompt {
  padding: 12px;
  border-top: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color2);
}

.llm-skill-edit-prompt h5 {
  margin: 0 0 8px 0;
  font-size: 13px;
  font-weight: 600;
}

.llm-skill-edit-prompt textarea {
  width: 100%;
  padding: 8px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  font-size: 12px;
  font-family: monospace;
  resize: vertical;
  min-height: 120px;
  box-sizing: border-box;
}

.llm-skill-edit-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 8px;
}

/* Marketplace */
.llm-skill-marketplace {
  padding: 12px;
  border-bottom: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color2);
}

.llm-marketplace-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.llm-marketplace-header h5 {
  margin: 0;
  font-size: 13px;
  font-weight: 600;
}

.llm-marketplace-close {
  background: transparent;
  border: none;
  color: var(--jp-ui-font-color2);
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
}

.llm-marketplace-close:hover {
  background: var(--jp-layout-color3);
}

.llm-marketplace-hint {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  margin: 0 0 12px 0;
}

.llm-marketplace-registries {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.llm-registry-item {
  padding: 10px 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
}

.llm-registry-item:hover {
  background: var(--jp-layout-color3);
  border-color: var(--jp-border-color2);
}

.llm-registry-name {
  font-size: 13px;
  font-weight: 500;
  margin-bottom: 2px;
}

.llm-registry-desc {
  font-size: 11px;
  color: var(--jp-ui-font-color2);
}

.llm-marketplace-back {
  display: flex;
  align-items: center;
  gap: 4px;
  background: transparent;
  border: none;
  color: var(--jp-ui-font-color2);
  font-size: 12px;
  cursor: pointer;
  padding: 4px 0;
  margin-bottom: 12px;
}

.llm-marketplace-back:hover {
  color: var(--jp-ui-font-color1);
}

.llm-marketplace-skill-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-height: 400px;
  overflow-y: auto;
}

.llm-marketplace-empty {
  text-align: center;
  color: var(--jp-ui-font-color2);
  font-size: 12px;
  padding: 16px;
}

.llm-marketplace-skill-item {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding: 10px 12px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  gap: 12px;
}

.llm-marketplace-skill-item:hover {
  border-color: var(--jp-border-color2);
}

.llm-marketplace-skill-info {
  flex: 1;
  min-width: 0;
}

.llm-marketplace-skill-name {
  font-size: 13px;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
}

.llm-marketplace-skill-desc {
  font-size: 12px;
  color: var(--jp-ui-font-color2);
  margin-bottom: 4px;
}

.llm-marketplace-skill-author {
  font-size: 11px;
  color: var(--jp-ui-font-color2);
  opacity: 0.7;
}

.llm-marketplace-skill-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 6px;
}

.llm-marketplace-tag {
  font-size: 10px;
  padding: 2px 6px;
  background: var(--jp-layout-color3);
  border-radius: 3px;
  color: var(--jp-ui-font-color2);
}

.llm-marketplace-install-btn {
  padding: 6px 12px;
  background: var(--jp-layout-color3);
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  color: var(--jp-ui-font-color1);
  font-size: 12px;
  cursor: pointer;
  white-space: nowrap;
}

.llm-marketplace-install-btn:hover {
  background: var(--jp-layout-color2);
  border-color: var(--jp-border-color2);
}

.llm-marketplace-install-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Header button active state */
.llm-header-btn.active {
  background: var(--jp-layout-color3);
  color: var(--jp-ui-font-color1);
}
`, "",{"version":3,"sources":["webpack://./style/skill.css"],"names":[],"mappings":"AAAA;;EAEE;;AAEF;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,gDAAgD;AAClD;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,YAAY;AACd;;AAEA;EACE,kBAAkB;EAClB,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;EACE,eAAe;EACf,eAAe;EACf,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,iBAAiB;EACjB,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;AACjB;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,iBAAiB;EACjB,kBAAkB;EAClB,eAAe;EACf,6BAA6B;AAC/B;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;;AAEA;EACE,YAAY;AACd;;AAEA;EACE,OAAO;EACP,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,+BAA+B;EAC/B,mCAAmC;EACnC,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,YAAY;AACd;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;;EAEE,uBAAuB;EACvB,YAAY;EACZ,+BAA+B;EAC/B,eAAe;EACf,YAAY;EACZ,kBAAkB;EAClB,YAAY;EACZ,2CAA2C;AAC7C;;AAEA;;EAEE,UAAU;AACZ;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;AACzC;;AAEA;EACE,aAAa;EACb,kBAAkB;EAClB,6BAA6B;AAC/B;;AAEA;EACE,eAAe;EACf,iBAAiB;EACjB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;AACjB;;AAEA,iBAAiB;AACjB;EACE,aAAa;EACb,gDAAgD;EAChD,mCAAmC;AACrC;;AAEA;EACE,kBAAkB;EAClB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,mBAAmB;EACnB,mCAAmC;EACnC,YAAY;EACZ,kBAAkB;AACpB;;AAEA;EACE,OAAO;EACP,iBAAiB;EACjB,YAAY;EACZ,uBAAuB;EACvB,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,kBAAkB;EAClB,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA;EACE,mCAAmC;EACnC,+BAA+B;EAC/B,gBAAgB;AAClB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,eAAe;EACf,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;;EAEE,WAAW;EACX,gBAAgB;EAChB,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,sBAAsB;EACtB,sBAAsB;AACxB;;AAEA;EACE,gBAAgB;EAChB,iBAAiB;AACnB;;AAEA;EACE,YAAY;EACZ,kBAAkB;EAClB,kCAAkC;EAClC,uCAAuC;EACvC,kBAAkB;EAClB,eAAe;AACjB;;AAEA;EACE,aAAa;EACb,yBAAyB;EACzB,QAAQ;AACV;;AAEA,iBAAiB;AACjB;EACE,aAAa;EACb,6CAA6C;EAC7C,mCAAmC;AACrC;;AAEA;EACE,iBAAiB;EACjB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,mBAAmB;AACrB;;AAEA;EACE,cAAc;EACd,eAAe;EACf,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,YAAY;EACZ,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,eAAe;EACf,sBAAsB;EACtB,qBAAqB;EACrB,sBAAsB;EACtB,iBAAiB;EACjB,gBAAgB;EAChB,SAAS;AACX;;AAEA;EACE,aAAa;EACb,yBAAyB;AAC3B;;AAEA;EACE,iBAAiB;EACjB,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;EACf,eAAe;AACjB;;AAEA;EACE,mCAAmC;AACrC;;AAEA,qBAAqB;AACrB;EACE,aAAa;EACb,6CAA6C;EAC7C,mCAAmC;AACrC;;AAEA;EACE,iBAAiB;EACjB,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,yCAAyC;EACzC,kBAAkB;EAClB,mCAAmC;EACnC,+BAA+B;EAC/B,eAAe;EACf,sBAAsB;EACtB,gBAAgB;EAChB,iBAAiB;EACjB,sBAAsB;AACxB;;AAEA;EACE,aAAa;EACb,yBAAyB;EACzB,QAAQ;EACR,eAAe;AACjB;;AAEA,gBAAgB;AAChB;EACE,aAAa;EACb,gDAAgD;EAChD,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,mBAAmB;AACrB;;AAEA;EACE,SAAS;EACT,eAAe;EACf,gBAAgB;AAClB;;AAEA;EACE,uBAAuB;EACvB,YAAY;EACZ,+BAA+B;EAC/B,eAAe;EACf,YAAY;EACZ,kBAAkB;AACpB;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,kBAAkB;EAClB,yCAAyC;EACzC,kBAAkB;EAClB,eAAe;EACf,gDAAgD;AAClD;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,uBAAuB;EACvB,YAAY;EACZ,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,cAAc;EACd,mBAAmB;AACrB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,iBAAiB;EACjB,gBAAgB;AAClB;;AAEA;EACE,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;EACf,aAAa;AACf;;AAEA;EACE,aAAa;EACb,uBAAuB;EACvB,8BAA8B;EAC9B,kBAAkB;EAClB,yCAAyC;EACzC,kBAAkB;EAClB,SAAS;AACX;;AAEA;EACE,qCAAqC;AACvC;;AAEA;EACE,OAAO;EACP,YAAY;AACd;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,kBAAkB;AACpB;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,YAAY;AACd;;AAEA;EACE,aAAa;EACb,eAAe;EACf,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,eAAe;EACf,gBAAgB;EAChB,mCAAmC;EACnC,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;EACE,iBAAiB;EACjB,mCAAmC;EACnC,yCAAyC;EACzC,kBAAkB;EAClB,+BAA+B;EAC/B,eAAe;EACf,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA,+BAA+B;AAC/B;EACE,mCAAmC;EACnC,+BAA+B;AACjC","sourcesContent":["/**\n * Skill Panel Styles\n */\n\n.llm-skill-panel {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  background: var(--jp-layout-color1);\n}\n\n.llm-skill-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 8px 12px;\n  border-bottom: 1px solid var(--jp-border-color1);\n}\n\n.llm-skill-header h4 {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 600;\n}\n\n.llm-skill-header-actions {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n\n.llm-skill-content {\n  flex: 1;\n  overflow-y: auto;\n  padding: 8px;\n}\n\n.llm-skill-empty {\n  text-align: center;\n  padding: 32px 16px;\n  color: var(--jp-ui-font-color2);\n}\n\n.llm-skill-empty .llm-hint {\n  font-size: 12px;\n  margin-top: 8px;\n  opacity: 0.7;\n}\n\n.llm-install-sample-btn {\n  margin-top: 16px;\n  padding: 8px 16px;\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  color: var(--jp-ui-font-color1);\n  cursor: pointer;\n}\n\n.llm-install-sample-btn:hover {\n  background: var(--jp-layout-color3);\n}\n\n.llm-skill-list {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n\n.llm-skill-item {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 8px 12px;\n  border-radius: 4px;\n  cursor: pointer;\n  border: 1px solid transparent;\n}\n\n.llm-skill-item:hover {\n  background: var(--jp-layout-color2);\n  border-color: var(--jp-border-color1);\n}\n\n.llm-skill-disabled {\n  opacity: 0.6;\n}\n\n.llm-skill-info {\n  flex: 1;\n  min-width: 0;\n}\n\n.llm-skill-name {\n  font-size: 13px;\n  font-weight: 500;\n  margin-bottom: 4px;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.llm-skill-version {\n  font-size: 11px;\n  font-weight: 400;\n  color: var(--jp-ui-font-color2);\n  background: var(--jp-layout-color3);\n  padding: 1px 4px;\n  border-radius: 2px;\n}\n\n.llm-skill-meta {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n\n.llm-skill-description {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.llm-skill-author {\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n  opacity: 0.7;\n}\n\n.llm-skill-actions {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n\n.llm-skill-toggle,\n.llm-skill-delete {\n  background: transparent;\n  border: none;\n  color: var(--jp-ui-font-color2);\n  cursor: pointer;\n  padding: 4px;\n  border-radius: 4px;\n  opacity: 0.5;\n  transition: opacity 0.15s, background 0.15s;\n}\n\n.llm-skill-toggle:hover,\n.llm-skill-delete:hover {\n  opacity: 1;\n}\n\n.llm-skill-toggle.llm-enabled {\n  color: var(--jp-success-color0);\n}\n\n.llm-skill-toggle.llm-disabled {\n  color: var(--jp-ui-font-color2);\n}\n\n.llm-skill-toggle:hover {\n  background: var(--jp-layout-color3);\n}\n\n.llm-skill-delete:hover {\n  background: var(--jp-error-color0);\n  color: var(--jp-ui-inverse-font-color0);\n}\n\n.llm-skill-error {\n  padding: 16px;\n  text-align: center;\n  color: var(--jp-error-color0);\n}\n\n.llm-skill-error button {\n  margin-top: 8px;\n  padding: 6px 12px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  background: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color1);\n  cursor: pointer;\n}\n\n/* Install Form */\n.llm-skill-install-form {\n  padding: 12px;\n  border-bottom: 1px solid var(--jp-border-color1);\n  background: var(--jp-layout-color2);\n}\n\n.llm-skill-install-form h5 {\n  margin: 0 0 12px 0;\n  font-size: 13px;\n  font-weight: 600;\n}\n\n.llm-skill-install-toggle {\n  display: flex;\n  gap: 4px;\n  margin-bottom: 12px;\n  background: var(--jp-layout-color1);\n  padding: 4px;\n  border-radius: 4px;\n}\n\n.llm-skill-install-toggle button {\n  flex: 1;\n  padding: 6px 12px;\n  border: none;\n  background: transparent;\n  color: var(--jp-ui-font-color2);\n  font-size: 12px;\n  cursor: pointer;\n  border-radius: 3px;\n  transition: background 0.15s, color 0.15s;\n}\n\n.llm-skill-install-toggle button:hover {\n  background: var(--jp-layout-color2);\n  color: var(--jp-ui-font-color1);\n}\n\n.llm-skill-install-toggle button.active {\n  background: var(--jp-layout-color3);\n  color: var(--jp-ui-font-color1);\n  font-weight: 500;\n}\n\n.llm-skill-install-field {\n  margin-bottom: 12px;\n}\n\n.llm-skill-install-field label {\n  display: block;\n  font-size: 12px;\n  margin-bottom: 4px;\n  color: var(--jp-ui-font-color2);\n}\n\n.llm-skill-install-field input,\n.llm-skill-install-field textarea {\n  width: 100%;\n  padding: 6px 8px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-size: 12px;\n  font-family: monospace;\n  box-sizing: border-box;\n}\n\n.llm-skill-install-field textarea {\n  resize: vertical;\n  min-height: 100px;\n}\n\n.llm-skill-install-error {\n  padding: 8px;\n  margin-bottom: 8px;\n  background: var(--jp-error-color0);\n  color: var(--jp-ui-inverse-font-color0);\n  border-radius: 4px;\n  font-size: 12px;\n}\n\n.llm-skill-install-actions {\n  display: flex;\n  justify-content: flex-end;\n  gap: 8px;\n}\n\n/* Skill Detail */\n.llm-skill-detail {\n  padding: 12px;\n  border-top: 1px solid var(--jp-border-color1);\n  background: var(--jp-layout-color2);\n}\n\n.llm-skill-detail h5 {\n  margin: 0 0 8px 0;\n  font-size: 13px;\n  font-weight: 600;\n}\n\n.llm-skill-detail-desc {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  margin: 0 0 12px 0;\n}\n\n.llm-skill-detail-prompt {\n  margin-bottom: 12px;\n}\n\n.llm-skill-detail-prompt label {\n  display: block;\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n  margin-bottom: 4px;\n}\n\n.llm-skill-prompt-preview {\n  padding: 8px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  font-size: 11px;\n  font-family: monospace;\n  white-space: pre-wrap;\n  word-break: break-word;\n  max-height: 200px;\n  overflow-y: auto;\n  margin: 0;\n}\n\n.llm-skill-detail-actions {\n  display: flex;\n  justify-content: flex-end;\n}\n\n.llm-edit-prompt-btn {\n  padding: 6px 12px;\n  background: var(--jp-layout-color3);\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  color: var(--jp-ui-font-color1);\n  font-size: 12px;\n  cursor: pointer;\n}\n\n.llm-edit-prompt-btn:hover {\n  background: var(--jp-layout-color2);\n}\n\n/* Edit Prompt Form */\n.llm-skill-edit-prompt {\n  padding: 12px;\n  border-top: 1px solid var(--jp-border-color1);\n  background: var(--jp-layout-color2);\n}\n\n.llm-skill-edit-prompt h5 {\n  margin: 0 0 8px 0;\n  font-size: 13px;\n  font-weight: 600;\n}\n\n.llm-skill-edit-prompt textarea {\n  width: 100%;\n  padding: 8px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  background: var(--jp-layout-color1);\n  color: var(--jp-ui-font-color1);\n  font-size: 12px;\n  font-family: monospace;\n  resize: vertical;\n  min-height: 120px;\n  box-sizing: border-box;\n}\n\n.llm-skill-edit-actions {\n  display: flex;\n  justify-content: flex-end;\n  gap: 8px;\n  margin-top: 8px;\n}\n\n/* Marketplace */\n.llm-skill-marketplace {\n  padding: 12px;\n  border-bottom: 1px solid var(--jp-border-color1);\n  background: var(--jp-layout-color2);\n}\n\n.llm-marketplace-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n\n.llm-marketplace-header h5 {\n  margin: 0;\n  font-size: 13px;\n  font-weight: 600;\n}\n\n.llm-marketplace-close {\n  background: transparent;\n  border: none;\n  color: var(--jp-ui-font-color2);\n  cursor: pointer;\n  padding: 4px;\n  border-radius: 4px;\n}\n\n.llm-marketplace-close:hover {\n  background: var(--jp-layout-color3);\n}\n\n.llm-marketplace-hint {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  margin: 0 0 12px 0;\n}\n\n.llm-marketplace-registries {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.llm-registry-item {\n  padding: 10px 12px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  cursor: pointer;\n  transition: background 0.15s, border-color 0.15s;\n}\n\n.llm-registry-item:hover {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-border-color2);\n}\n\n.llm-registry-name {\n  font-size: 13px;\n  font-weight: 500;\n  margin-bottom: 2px;\n}\n\n.llm-registry-desc {\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n}\n\n.llm-marketplace-back {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  background: transparent;\n  border: none;\n  color: var(--jp-ui-font-color2);\n  font-size: 12px;\n  cursor: pointer;\n  padding: 4px 0;\n  margin-bottom: 12px;\n}\n\n.llm-marketplace-back:hover {\n  color: var(--jp-ui-font-color1);\n}\n\n.llm-marketplace-skill-list {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  max-height: 400px;\n  overflow-y: auto;\n}\n\n.llm-marketplace-empty {\n  text-align: center;\n  color: var(--jp-ui-font-color2);\n  font-size: 12px;\n  padding: 16px;\n}\n\n.llm-marketplace-skill-item {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  padding: 10px 12px;\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  gap: 12px;\n}\n\n.llm-marketplace-skill-item:hover {\n  border-color: var(--jp-border-color2);\n}\n\n.llm-marketplace-skill-info {\n  flex: 1;\n  min-width: 0;\n}\n\n.llm-marketplace-skill-name {\n  font-size: 13px;\n  font-weight: 500;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 4px;\n}\n\n.llm-marketplace-skill-desc {\n  font-size: 12px;\n  color: var(--jp-ui-font-color2);\n  margin-bottom: 4px;\n}\n\n.llm-marketplace-skill-author {\n  font-size: 11px;\n  color: var(--jp-ui-font-color2);\n  opacity: 0.7;\n}\n\n.llm-marketplace-skill-tags {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px;\n  margin-top: 6px;\n}\n\n.llm-marketplace-tag {\n  font-size: 10px;\n  padding: 2px 6px;\n  background: var(--jp-layout-color3);\n  border-radius: 3px;\n  color: var(--jp-ui-font-color2);\n}\n\n.llm-marketplace-install-btn {\n  padding: 6px 12px;\n  background: var(--jp-layout-color3);\n  border: 1px solid var(--jp-border-color1);\n  border-radius: 4px;\n  color: var(--jp-ui-font-color1);\n  font-size: 12px;\n  cursor: pointer;\n  white-space: nowrap;\n}\n\n.llm-marketplace-install-btn:hover {\n  background: var(--jp-layout-color2);\n  border-color: var(--jp-border-color2);\n}\n\n.llm-marketplace-install-btn:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n/* Header button active state */\n.llm-header-btn.active {\n  background: var(--jp-layout-color3);\n  color: var(--jp-ui-font-color1);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./style/index.css"
/*!*************************!*\
  !*** ./style/index.css ***!
  \*************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./style/index.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }

}]);
//# sourceMappingURL=style_index_css.659ba3ff85b0a139565a.js.map