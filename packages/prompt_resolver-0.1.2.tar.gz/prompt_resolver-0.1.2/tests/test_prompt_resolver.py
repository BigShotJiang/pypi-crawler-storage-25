"""Tests for `prompt_resolver` package."""

from pathlib import Path

import pytest

import prompt_resolver
from prompt_resolver import PromptResolver

FIXTURES = Path(__file__).parent / "fixtures" / "prompts"


def test_version():
    assert prompt_resolver.__version__


def test_loads_manifest_version():
    resolver = PromptResolver(FIXTURES)
    assert resolver.version == "1.0.2"


def test_get_static_prompt():
    """A prompt with no variables renders as-is (falls back through patch versions)."""
    resolver = PromptResolver(FIXTURES)
    # greet.txt exists in v1.0.0 and v1.0.1; v1.0.1 takes priority (highest patch first)
    result = resolver.get("greet", name="Alice")
    assert result == "Hello, Alice!\n"


def test_get_prompt_with_variables():
    resolver = PromptResolver(FIXTURES)
    result = resolver.get("summarize", max_words=50, text="Some long article...")
    assert "50" in result
    assert "Some long article..." in result


def test_version_fallback(tmp_path):
    """Templates missing from the current patch are resolved from earlier patches."""
    # Build a prompts dir where v1.0.2 exists but has no greet.txt — only v1.0.0 does.
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("prompt_version: '1.0.2'\n")
    (tmp_path / "v1.0.2").mkdir()
    (tmp_path / "v1.0.0").mkdir()
    (tmp_path / "v1.0.0" / "greet.txt").write_text("Fallback greeting!\n")

    resolver = PromptResolver(tmp_path)
    assert resolver.get("greet") == "Fallback greeting!\n"


def test_missing_template_raises(tmp_path):
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("prompt_version: '1.0.0'\n")
    (tmp_path / "v1.0.0").mkdir()

    resolver = PromptResolver(tmp_path)
    with pytest.raises(Exception):
        resolver.get("nonexistent")


def test_warm_cache_runs_without_error():
    resolver = PromptResolver(FIXTURES)
    resolver.warm_cache()
