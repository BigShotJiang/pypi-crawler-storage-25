# Installation

## Stable release

To install prompt_resolver, run this command in your terminal:

```sh
uv add prompt-resolver
```

Or if you prefer to use `pip`:

```sh
pip install prompt-resolver
```

## From source

The source files for prompt_resolver can be downloaded from the [Github repo](https://github.com/innivic/prompt_resolver).

You can either clone the public repository:

```sh
git clone https://github.com/innivic/prompt_resolver
```

Or download the [tarball](https://github.com/innivic/prompt_resolver/tarball/main):

```sh
curl -OJL https://github.com/innivic/prompt_resolver/tarball/main
```

Once you have a copy of the source, you can install it with:

```sh
cd prompt_resolver
uv sync
```
