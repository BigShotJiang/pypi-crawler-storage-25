# Usage

To use prompt_resolver in a project:

```python
import prompt_resolver
```
