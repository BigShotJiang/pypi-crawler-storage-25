# API Reference

::: prompt_resolver
