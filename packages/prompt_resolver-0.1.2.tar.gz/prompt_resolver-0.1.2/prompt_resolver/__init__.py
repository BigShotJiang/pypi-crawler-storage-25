import yaml
from pathlib import Path
import logging
from jinja2 import Environment, FileSystemLoader
import importlib.metadata

__version__ = importlib.metadata.version("prompt-resolver")

logger = logging.getLogger(__name__)

class PromptResolver:
    def __init__(self, prompts_dir: Path):
        self._prompts_dir = prompts_dir
        manifest = yaml.safe_load((prompts_dir / "manifest.yaml").read_text())
        self.version = manifest["prompt_version"]
        search_paths = self._build_search_paths(self.version)
        self._env = Environment(
            loader=FileSystemLoader(search_paths),
            keep_trailing_newline=True,
        )

    def _build_search_paths(self, version: str) -> list[str]:
        """Cumulative patches: v1.0.2 falls back to v1.0.1, then v1.0.0."""
        major, minor, patch = (int(x) for x in version.split("."))
        paths = []
        # Walk from current patch down to .0
        for p in range(patch, -1, -1):
            ver_dir = self._prompts_dir / f"v{major}.{minor}.{p}"
            if ver_dir.exists():
                paths.append(str(ver_dir))
                for sub_dir in sorted(ver_dir.iterdir()):
                    if sub_dir.is_dir():
                        paths.append(str(sub_dir))
        return paths

    def get(self, prompt_name: str, **kwargs) -> str:
        """
        Load and render a prompt template via Jinja2.

        Usage:
            prompt_manager.get("my_prompt", a_variable="x variable")

        Templates with no variables are cached automatically by Jinja2's
        bytecode cache; templates with variables are rendered fresh each call.
        """
        template = self._env.get_template(f"{prompt_name}.txt")
        return template.render(**kwargs)

    def warm_cache(self) -> None:
        """Pre-load and compile all templates."""
        count = 0
        for search_path in self._env.loader.searchpath:
            path = Path(search_path)
            for txt_file in path.glob("*.txt"):
                template_name = txt_file.name
                logger.debug("Caching %s", template_name)
                self._env.get_template(template_name)
                count += 1
        logger.debug("Prompt cache warmed: %d templates pre-compiled", count)
