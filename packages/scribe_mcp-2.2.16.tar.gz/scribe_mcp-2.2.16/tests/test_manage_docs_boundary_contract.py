from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from scribe_mcp import server as server_module
from scribe_mcp.shared.logging_utils import LoggingContext
from scribe_mcp.state import StateManager
from scribe_mcp.tools.manage_docs import manage_docs


@contextmanager
def _isolated_server(state_manager: StateManager, *, project_root: Path):
    originals = {
        "state_manager": server_module.state_manager,
        "storage_backend": server_module.storage_backend,
    }
    orig_exec_ctx = getattr(server_module, "get_execution_context", None)
    orig_agent_id = getattr(server_module, "get_agent_identity", None)
    from scribe_mcp.tools import manage_docs as manage_docs_module

    orig_prepare_context = manage_docs_module._MANAGE_DOCS_HELPER.prepare_context
    server_module.state_manager = state_manager
    server_module.storage_backend = None
    server_module.get_execution_context = lambda: SimpleNamespace(
        mode="project",
        session_id="test-session",
        stable_session_id="test-session",
    )
    server_module.get_agent_identity = lambda: None

    from scribe_mcp.config.repo_config import RepoConfig

    fake_root = project_root.resolve()
    fake_config = RepoConfig(repo_slug="test", repo_root=fake_root)

    try:

        async def _prepare_context_stub(**kwargs):
            state = await state_manager.load()
            project_name = state.current_project or (state.recent_projects[0] if state.recent_projects else None)
            current_project = state.get_project(project_name) if project_name else None
            return LoggingContext(
                tool_name=str(kwargs.get("tool_name") or "manage_docs"),
                project=current_project,
                recent_projects=list(getattr(state, "recent_projects", []) or []),
                state_snapshot=kwargs.get("state_snapshot") or {},
                reminders=[],
            )

        manage_docs_module._MANAGE_DOCS_HELPER.prepare_context = _prepare_context_stub
        with patch(
            "scribe_mcp.config.repo_config.get_current_repo_config",
            return_value=(fake_root, fake_config),
        ):
            yield
    finally:
        server_module.state_manager = originals["state_manager"]
        server_module.storage_backend = originals["storage_backend"]
        if orig_exec_ctx is not None:
            server_module.get_execution_context = orig_exec_ctx
        if orig_agent_id is not None:
            server_module.get_agent_identity = orig_agent_id
        manage_docs_module._MANAGE_DOCS_HELPER.prepare_context = orig_prepare_context


async def _setup_project(tmp_path: Path) -> dict:
    project_root = tmp_path / "boundary_contract_repo"
    docs_dir = project_root / ".scribe" / "docs" / "dev_plans" / "test_project"
    docs_dir.mkdir(parents=True, exist_ok=True)
    (docs_dir / "ARCHITECTURE_GUIDE.md").write_text("# Architecture\n", encoding="utf-8")
    (docs_dir / "PHASE_PLAN.md").write_text("# Phase\n", encoding="utf-8")
    (docs_dir / "CHECKLIST.md").write_text("# Checklist\n", encoding="utf-8")
    (docs_dir / "PROGRESS_LOG.md").write_text("# Log\n", encoding="utf-8")
    return {
        "name": "Boundary Contract Project",
        "root": str(project_root),
        "docs_dir": str(docs_dir),
        "progress_log": str(docs_dir / "PROGRESS_LOG.md"),
        "docs": {
            "architecture": str(docs_dir / "ARCHITECTURE_GUIDE.md"),
            "phase_plan": str(docs_dir / "PHASE_PLAN.md"),
            "checklist": str(docs_dir / "CHECKLIST.md"),
            "progress_log": str(docs_dir / "PROGRESS_LOG.md"),
        },
    }


async def _seed_runtime_session(state_manager: StateManager, project_root: str) -> None:
    backend = getattr(state_manager, "_storage_backend", None)
    if backend and hasattr(backend, "upsert_session"):
        await backend.upsert_session(
            session_id="test-session",
            repo_root=project_root,
            mode="project",
        )


@pytest.mark.asyncio
async def test_manage_docs_out_of_project_target_returns_structured_boundary_guidance(tmp_path: Path) -> None:
    project = await _setup_project(tmp_path)
    state_manager = StateManager(path=tmp_path / "state.json")
    await state_manager.set_current_project(project["name"], project)
    await _seed_runtime_session(state_manager, project["root"])

    with _isolated_server(state_manager, project_root=Path(project["root"])):
        result = await manage_docs(
            action="create",
            doc="boundary_note",
            metadata={
                "doc_type": "custom",
                "doc_name": "boundary_note",
                "body": "# Note\nBoundary test.",
                "target_dir": "/tmp",
                "register_doc": True,
            },
            dry_run=False,
        )

    assert result["ok"] is False
    assert "Unexpected error:" not in (result.get("error") or "")
    assert "outside project root" in (result.get("error") or "")
    assert result.get("suggestion")
    boundary_guidance = result.get("boundary_guidance")
    assert isinstance(boundary_guidance, dict)
    assert boundary_guidance.get("project_root") == project["root"]
    assert boundary_guidance.get("rejected_target_dir") == "/tmp"


@pytest.mark.asyncio
async def test_manage_docs_in_project_target_remains_successful(tmp_path: Path) -> None:
    project = await _setup_project(tmp_path)
    state_manager = StateManager(path=tmp_path / "state.json")
    await state_manager.set_current_project(project["name"], project)
    await _seed_runtime_session(state_manager, project["root"])

    in_project_target = Path(project["docs_dir"]) / "custom"

    with _isolated_server(state_manager, project_root=Path(project["root"])):
        result = await manage_docs(
            action="create",
            doc="in_project_note",
            metadata={
                "doc_type": "custom",
                "doc_name": "in_project_note",
                "body": "# Note\nIn project.",
                "target_dir": str(in_project_target),
                "register_doc": False,
            },
            dry_run=False,
        )

    assert result["ok"] is True
    assert Path(result["path"]).is_relative_to(Path(project["root"]))


@pytest.mark.asyncio
async def test_manage_docs_write_fails_closed_when_context_falls_back_to_agent_project(tmp_path: Path) -> None:
    project = await _setup_project(tmp_path)
    state_manager = StateManager(path=tmp_path / "state.json")
    await state_manager.set_current_project(project["name"], project)
    await _seed_runtime_session(state_manager, project["root"])

    originals = {
        "state_manager": server_module.state_manager,
        "storage_backend": server_module.storage_backend,
    }
    orig_exec_ctx = getattr(server_module, "get_execution_context", None)
    from scribe_mcp.tools import manage_docs as manage_docs_module

    orig_prepare_context = manage_docs_module._MANAGE_DOCS_HELPER.prepare_context
    server_module.state_manager = state_manager
    server_module.storage_backend = None
    server_module.get_execution_context = lambda: SimpleNamespace(
        mode="project",
        session_id="fallback-write-session",
        stable_session_id="fallback-write-session",
    )

    try:
        async def _prepare_context_stub(**kwargs):
            state = await state_manager.load()
            return LoggingContext(
                tool_name=str(kwargs.get("tool_name") or "manage_docs"),
                project=state.get_project(project["name"]),
                recent_projects=list(getattr(state, "recent_projects", []) or []),
                state_snapshot=kwargs.get("state_snapshot") or {},
                reminders=[],
                resolution_source="agent_context",
            )

        manage_docs_module._MANAGE_DOCS_HELPER.prepare_context = _prepare_context_stub
        result = await manage_docs(
            action="create",
            doc="fallback_blocked_note",
            metadata={
                "doc_type": "custom",
                "doc_name": "fallback_blocked_note",
                "body": "# Note\nShould fail closed.\n",
            },
            dry_run=False,
        )
    finally:
        server_module.state_manager = originals["state_manager"]
        server_module.storage_backend = originals["storage_backend"]
        if orig_exec_ctx is not None:
            server_module.get_execution_context = orig_exec_ctx
        manage_docs_module._MANAGE_DOCS_HELPER.prepare_context = orig_prepare_context

    assert result["ok"] is False
    assert result.get("reason_code") == "manage_docs_write_requires_session_binding"
    assert "fell back to non-session context" in (result.get("error") or "")
    assert result.get("project_resolution", {}).get("resolution_source") == "agent_context"


@pytest.mark.asyncio
async def test_manage_docs_invalid_action_response_includes_supported_actions_manifest(tmp_path: Path) -> None:
    project = await _setup_project(tmp_path)
    state_manager = StateManager(path=tmp_path / "state.json")
    await state_manager.set_current_project(project["name"], project)
    await _seed_runtime_session(state_manager, project["root"])

    with _isolated_server(state_manager, project_root=Path(project["root"])):
        result = await manage_docs(action="definitely_not_real", dry_run=True)

    assert result["ok"] is False
    manifest = result.get("supported_actions")
    assert isinstance(manifest, dict)
    assert manifest.get("cleanup_actions") == ["project_health", "rehome_doc"]
