"""Agent identification and session management utilities."""

from __future__ import annotations

import asyncio
import logging
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from scribe_mcp.utils.time import utcnow

logger = logging.getLogger(__name__)


class AgentIdentity:
    """
    Manages agent identification and session state for multi-agent environments.

    Features:
    - Automatic agent ID generation from context
    - Persistent agent identity across sessions
    - Project resumption capability
    - Activity tracking and state updates
    """

    def __init__(self, state_manager):
        self.state_manager = state_manager
        self._cached_agent_id: Optional[str] = None
        self._last_persisted_agent_id: Optional[str] = None
        self._last_persisted_at: float = 0.0
        self._persist_interval_seconds = max(
            5.0,
            float(os.getenv("SCRIBE_AGENT_ID_PERSIST_INTERVAL_SECONDS", "300")),
        )
        self._activity_lock = asyncio.Lock()
        self._pending_activities: list[Dict[str, Any]] = []
        self._last_activity_persist_at: float = 0.0
        self._activity_persist_interval_seconds = max(
            5.0,
            float(os.getenv("SCRIBE_AGENT_ACTIVITY_PERSIST_INTERVAL_SECONDS", "60")),
        )
        self._activity_buffer_limit = max(
            20,
            int(os.getenv("SCRIBE_AGENT_ACTIVITY_BUFFER_LIMIT", "100")),
        )

    async def get_or_create_agent_id(self, context: Optional[Dict[str, Any]] = None) -> str:
        """
        Get existing agent ID or create a new one based on context.

        Args:
            context: Optional context information (MCP request, environment, etc.)

        Returns:
            Agent ID string
        """
        # Resolve identity with fast paths first (context/env/cache), then state fallback.
        agent_id = self._get_agent_id_from_mcp_context(context) or self._get_agent_id_from_environment()
        if not agent_id:
            agent_id = self._cached_agent_id
        if not agent_id:
            agent_id = await self._get_agent_id_from_persistent_state()
        if not agent_id:
            agent_id = self._create_new_agent_id()

        self._cached_agent_id = agent_id

        # Persist only when identity changes or at a coarse heartbeat interval.
        if self._should_persist(agent_id):
            await self._store_agent_id(agent_id)

        return agent_id

    def _should_persist(self, agent_id: str) -> bool:
        now = time.monotonic()
        if self._last_persisted_agent_id != agent_id:
            return True
        if (now - self._last_persisted_at) >= self._persist_interval_seconds:
            return True
        return False

    def _get_agent_id_from_mcp_context(self, context: Optional[Dict[str, Any]]) -> Optional[str]:
        """Extract agent ID from MCP request context."""
        if not context:
            return None

        # Try various MCP context fields
        mcp_context_keys = [
            "client_id", "session_id", "request_id", "user_id",
            "agent_id", "client_name", "tool_call_id"
        ]

        for key in mcp_context_keys:
            if key in context:
                return f"mcp-{context[key]}"

        # Try to extract from request metadata
        if "request" in context:
            request = context["request"]
            if isinstance(request, dict):
                if "method" in request:
                    method = request["method"]
                    if "params" in request:
                        params = request["params"]
                        if isinstance(params, dict) and "session_id" in params:
                            return f"mcp-session-{params['session_id']}"

        return None

    def _get_agent_id_from_environment(self) -> Optional[str]:
        """Extract agent ID from environment variables."""
        env_keys = [
            "MCP_AGENT_ID", "SCRIBE_AGENT_ID", "CLIENT_ID",
            "SESSION_ID", "USER_AGENT", "HOSTNAME", "USERNAME"
        ]

        for key in env_keys:
            value = os.getenv(key)
            if value:
                # Sanitize and normalize
                safe_value = value.replace(" ", "-").lower()[:50]
                return f"env-{safe_value}"

        return None

    async def _get_agent_id_from_persistent_state(self) -> Optional[str]:
        """Get agent ID from persistent state storage."""
        try:
            state = await self.state_manager.load()
            agent_state = getattr(state, "agent_state", {})
            if "last_agent_id" in agent_state:
                return agent_state["last_agent_id"]
        except Exception:
            pass
        return None

    def _create_new_agent_id(self) -> str:
        """Create a new unique agent ID."""
        # Generate unique ID with timestamp and random component
        timestamp = utcnow().strftime("%Y%m%d-%H%M%S")
        random_part = str(uuid.uuid4())[:8]
        return f"agent-{timestamp}-{random_part}"

    async def _store_agent_id(self, agent_id: str) -> None:
        """Store agent ID in persistent state for future use."""
        try:
            state = await self.state_manager.load()
            if not hasattr(state, "agent_state"):
                state.agent_state = {}

            state.agent_state.update({
                "last_agent_id": agent_id,
                "last_seen": utcnow().isoformat(),
                "agent_metadata": {
                    "created_at": utcnow().isoformat(),
                    "id_type": "auto-generated"
                }
            })

            await self.state_manager.persist(state)
            self._last_persisted_agent_id = agent_id
            self._last_persisted_at = time.monotonic()
        except Exception:
            # Don't fail if we can't store the agent ID
            self._last_persisted_agent_id = agent_id
            self._last_persisted_at = time.monotonic()

    async def resume_agent_session(
        self,
        agent_id: str,
        agent_context_manager,
        stable_session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """
        Resume an agent's previous session and project context.

        Args:
            agent_id: Agent identifier
            agent_context_manager: AgentContextManager instance
            stable_session_id: Optional stable session ID from ExecutionContext
            metadata: Optional session metadata

        Returns:
            Session ID if resumption successful, None otherwise
        """
        try:
            # Check if agent has an existing project
            agent_project = await agent_context_manager.get_current_project(agent_id)
            project_name = (
                str(agent_project.get("project_name"))
                if agent_project and agent_project.get("project_name")
                else None
            )
            scoped_reuse_key = self._derive_scoped_reuse_key(
                repo_root=self._derive_repo_root(agent_project),
                project_name=project_name,
            )
            if agent_project and agent_project.get("project_name"):
                # Create new session for the agent with stable session if provided
                session_metadata = {
                    "resumed": True,
                    "resumed_at": utcnow().isoformat(),
                    "previous_project": agent_project["project_name"],
                    "session_reuse_status": "reused" if stable_session_id else "allocated",
                    "session_reuse_scope": scoped_reuse_key,
                }
                if metadata:
                    session_metadata.update(metadata)
                session_id = await agent_context_manager.start_session(
                    agent_id,
                    session_id=stable_session_id,  # Pass through stable session
                    metadata=session_metadata
                )

                logger.debug("Resumed agent '%s' session (previous project: %s, session: %s)",
                             agent_id, agent_project['project_name'], session_id)

                return session_id
            else:
                # No previous project, create fresh session
                session_metadata = {
                    "fresh_session": True,
                    "created_at": utcnow().isoformat(),
                    "session_reuse_status": "allocated",
                    "session_reuse_scope": scoped_reuse_key,
                }
                if metadata:
                    session_metadata.update(metadata)
                session_id = await agent_context_manager.start_session(
                    agent_id,
                    session_id=stable_session_id,  # Pass through stable session
                    metadata=session_metadata
                )

                logger.debug("Created fresh session for agent '%s' (session: %s)", agent_id, session_id)

                return session_id

        except Exception as e:
            logger.warning("Failed to resume session for agent '%s': %s", agent_id, e)
            return None

    @staticmethod
    def _derive_repo_root(agent_project: Optional[Dict[str, Any]]) -> str:
        if not agent_project:
            return ""
        repo_root = agent_project.get("repo_root")
        return str(repo_root) if repo_root else ""

    @staticmethod
    def _derive_scoped_reuse_key(repo_root: str, project_name: Optional[str]) -> str:
        normalized_repo_root = repo_root.strip() if repo_root else ""
        normalized_project = (project_name or "").strip() or "__prebinding__"
        return f"{normalized_repo_root}:{normalized_project}"

    async def update_agent_activity(self, agent_id: str, activity_type: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Update agent activity tracking.

        Args:
            agent_id: Agent identifier
            activity_type: Type of activity (tool_call, project_switch, etc.)
            metadata: Additional activity metadata
        """
        try:
            activity = {
                "agent_id": agent_id,
                "activity_type": activity_type,
                "timestamp": utcnow().isoformat(),
                "metadata": metadata or {},
            }

            async with self._activity_lock:
                self._pending_activities.append(activity)
                if len(self._pending_activities) > self._activity_buffer_limit:
                    self._pending_activities = self._pending_activities[-self._activity_buffer_limit :]

                now = time.monotonic()
                if (now - self._last_activity_persist_at) < self._activity_persist_interval_seconds:
                    return

                pending = list(self._pending_activities)
                self._pending_activities.clear()
                self._last_activity_persist_at = now

            state = await self.state_manager.load()
            if not hasattr(state, "agent_state"):
                state.agent_state = {}

            existing = state.agent_state.get("activity_log") or []
            if not isinstance(existing, list):
                existing = []
            existing.extend(pending)
            if len(existing) > 100:
                existing = existing[-100:]

            latest = pending[-1] if pending else activity
            state.agent_state["activity_log"] = existing
            state.agent_state.update({
                "last_agent_id": latest["agent_id"],
                "last_seen": latest["timestamp"],
                "last_activity": latest["activity_type"],
            })

            await self.state_manager.persist(state)
        except Exception:
            # Don't fail if we can't update activity
            pass


# Global instance for server integration
_agent_identity: Optional[AgentIdentity] = None


def get_agent_identity() -> AgentIdentity:
    """Get the global agent identity instance."""
    global _agent_identity
    if _agent_identity is None:
        raise RuntimeError("AgentIdentity not initialized. Call init_agent_identity first.")
    return _agent_identity


def init_agent_identity(state_manager) -> AgentIdentity:
    """Initialize the global agent identity instance."""
    global _agent_identity
    _agent_identity = AgentIdentity(state_manager)
    return _agent_identity
