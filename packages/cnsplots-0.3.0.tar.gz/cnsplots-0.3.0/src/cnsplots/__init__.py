"""CNSPlots Module."""

import logging
import warnings

import cnsplots._methods as methods
import cnsplots._utils as utils
import cnsplots._validation as validation
from cnsplots._methods import CoxModel, LogisticModel, prerank
from cnsplots._multipanels import multipanel
from cnsplots._settings import settings
from cnsplots._setup import setup_ax, setup_ggplot, setup_matplotlib, setup_scanpy
from cnsplots._utils import (
    BLUE,
    BROWN,
    CHOCOLATE,
    GRAY,
    GREEN,
    ORANGE,
    PINK,
    PURPLE,
    RED,
    VIOLET,
    YELLOW,
    add_panel_label,
    apply_unicode_font,
    figure,
    get_hexcolors_from_apalette,
    get_showcase_data,
    palettes,
    savefig,
    take_legend_out,
)
from cnsplots.plots import (
    barplot,
    boxplot,
    confusionplot,
    cumulativeincidenceplot,
    distplot,
    donutplot,
    dotplot,
    forestplot,
    gseaplot,
    heatmapplot,
    histplot,
    kdeplot,
    lineplot,
    lollipopplot,
    phyloplot,
    placeholderplot,
    pieplot,
    qqplot,
    regplot,
    ridgeplot,
    rocplot,
    sankeyplot,
    scatterplot,
    slopeplot,
    stackplot,
    stripplot,
    survivalplot,
    upsetplot,
    vennplot,
    violinplot,
    volcanoplot,
)

__version__ = "0.3.0"
save = savefig
__all__ = (
    "utils",
    "settings",
    "validation",
    "BLUE",
    "BROWN",
    "CHOCOLATE",
    "GRAY",
    "GREEN",
    "ORANGE",
    "PINK",
    "PURPLE",
    "RED",
    "VIOLET",
    "YELLOW",
    "methods",
    "CoxModel",
    "LogisticModel",
    "prerank",
    "setup_ax",
    "setup_ggplot",
    "setup_matplotlib",
    "setup_scanpy",
    "add_panel_label",
    "apply_unicode_font",
    "figure",
    "multipanel",
    "save",
    "savefig",
    "palettes",
    "take_legend_out",
    "get_hexcolors_from_apalette",
    "get_showcase_data",
    "barplot",
    "boxplot",
    "confusionplot",
    "cumulativeincidenceplot",
    "distplot",
    "donutplot",
    "dotplot",
    "forestplot",
    "gseaplot",
    "heatmapplot",
    "histplot",
    "kdeplot",
    "lineplot",
    "lollipopplot",
    "phyloplot",
    "placeholderplot",
    "pieplot",
    "qqplot",
    "regplot",
    "ridgeplot",
    "rocplot",
    "sankeyplot",
    "scatterplot",
    "slopeplot",
    "stackplot",
    "stripplot",
    "survivalplot",
    "upsetplot",
    "vennplot",
    "violinplot",
    "volcanoplot",
)

warnings.filterwarnings("ignore", message="findfont: Font family 'Helvetica' not found")

mpl_logger = logging.getLogger("matplotlib")
mpl_logger.setLevel(logging.ERROR)

logging.getLogger("fontTools").setLevel(logging.ERROR)
