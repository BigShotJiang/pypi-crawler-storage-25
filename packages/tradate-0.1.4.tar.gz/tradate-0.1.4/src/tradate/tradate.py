import itertools
import logging
import threading
from datetime import datetime, timedelta

from .consts import DATA_DIR

logger = logging.getLogger(__name__)

_fetch_lock = threading.Lock()


def _load_dates() -> tuple[list[str], set[str], dict[str, str], dict[str, str]]:
    """加载交易日期数据并返回优化后的数据结构"""
    dates_list = []
    for csv_file in sorted(DATA_DIR.glob("*.csv")):
        dates_list.extend(
            line.strip()
            for line in csv_file.read_text(encoding="utf-8").splitlines()
            if line.strip()
        )

    dates_set = set(dates_list)

    date_prevdate = {
        next_date: current_date
        for current_date, next_date in itertools.pairwise(dates_list)
    }
    date_nextdate = {
        current_date: next_date
        for current_date, next_date in itertools.pairwise(dates_list)
    }

    return dates_list, dates_set, date_prevdate, date_nextdate


# 模块级别加载，避免重复加载
_DATES_LIST, _DATES_SET, _DATE_PREVDATE, _DATE_NEXTDATE = _load_dates()


def _reload_dates():
    """重新加载交易日期数据（更新模块级变量）"""
    global _DATES_LIST, _DATES_SET, _DATE_PREVDATE, _DATE_NEXTDATE
    _DATES_LIST, _DATES_SET, _DATE_PREVDATE, _DATE_NEXTDATE = _load_dates()


def _try_fetch_new_data(date: str) -> bool:
    """
    尝试从新浪财经获取新的交易日期数据。

    当查询的日期晚于本地缓存的最后交易日时，调用 fetcher 的 tool 函数
    获取最新交易日期列表。如果获取到的数据包含查询日期所在的年，
    则将该年的交易日期保存到本地 CSV 文件并重新加载数据。

    Args:
        date: 查询的日期字符串，格式为 'YYYY-MM-DD'

    Returns:
        bool: 如果成功获取并加载了新数据返回 True，否则返回 False
    """
    if not _DATES_LIST or date < _DATES_LIST[-1]:
        return False

    with _fetch_lock:
        # 获取锁后再次检查，避免重复获取
        if date < _DATES_LIST[-1]:
            return False

        try:
            from .fetcher import tool_trade_date_hist_sina
        except ImportError:
            logger.warning("无法导入 fetcher 模块，跳过在线获取交易日期")
            return False

        try:
            dates = tool_trade_date_hist_sina()
            year = date[:4]
            year_dates = [d for d in dates if d.startswith(year)]

            if not year_dates:
                return False

            # 保存到本地 CSV
            csv_path = DATA_DIR / f"{year}.csv"
            try:
                content = "\n".join(year_dates) + "\n"
                csv_path.write_text(content, encoding="utf-8")
            except OSError:
                logger.warning(
                    "无法写入 %s，数据仅在当前进程中生效", csv_path
                )

            _reload_dates()
            return True
        except Exception:
            logger.exception("在线获取交易日期失败")
            return False


def is_tradate(date: str) -> bool:
    """
    检查给定日期是否为交易日

    Args:
        date: 日期字符串，格式为'YYYY-MM-DD'，例如'2025-10-24'

    Returns:
        bool: 如果是交易日返回True，否则返回False
    """
    return date in _DATES_SET


def today_is_tradate() -> bool:
    """
    检查今天是否为交易日

    Returns:
        bool: 如果今天是交易日返回True，否则返回False
    """

    return is_tradate(datetime.now().strftime("%Y-%m-%d"))


def get_prev_date(date: str, fmt: str | None = None) -> str | None:
    """
    获取指定日期的前一个交易日

    Args:
        date: 日期字符串，格式为'YYYY-MM-DD'
        fmt: 可选的输出日期格式

    Returns:
        str: 前一个交易日，如果不存在则返回None
    """
    ret = _DATE_PREVDATE.get(date, None)
    if ret is not None:
        return datetime.strptime(ret, "%Y-%m-%d").strftime(fmt) if fmt else ret

    # 日期超出缓存范围时尝试在线获取新数据
    _try_fetch_new_data(date)
    ret = _DATE_PREVDATE.get(date, None)
    if fmt is None or ret is None:
        return ret
    return datetime.strptime(ret, "%Y-%m-%d").strftime(fmt)


def get_next_date(date: str, fmt: str | None = None) -> str | None:
    """
    获取指定日期的后一个交易日

    Args:
        date: 日期字符串，格式为'YYYY-MM-DD'
        fmt: 可选的输出日期格式

    Returns:
        str: 后一个交易日，如果不存在则返回None
    """
    ret = _DATE_NEXTDATE.get(date, None)
    if ret is not None:
        return datetime.strptime(ret, "%Y-%m-%d").strftime(fmt) if fmt else ret

    # 日期超出缓存范围时尝试在线获取新数据
    _try_fetch_new_data(date)
    ret = _DATE_NEXTDATE.get(date, None)
    if fmt is None or ret is None:
        return ret
    return datetime.strptime(ret, "%Y-%m-%d").strftime(fmt)


def get_all_dates() -> list[str]:
    """
    获取所有交易日期列表（按顺序）

    Returns:
        List[str]: 按顺序排列的交易日期列表
    """
    return _DATES_LIST.copy()  # 返回副本以防止外部修改


def get_traday(fmt: str | None = None) -> str | None:
    """
    获取距今最近的交易日（包括今天，如果今天是交易日的话）

    Returns:
        str: 最近的交易日，格式为'YYYY-MM-DD'，如果没有找到返回None
    """

    now = datetime.now()
    today: str = now.strftime("%Y-%m-%d")

    if is_tradate(today):
        return now.strftime(fmt) if fmt is not None else today

    # 否则向前查找最近的交易日
    delta = timedelta(days=1)
    # 最多向前查找365天，防止无限循环
    for _ in range(365):
        now -= delta
        if is_tradate(now.strftime("%Y-%m-%d")):
            return now.strftime(fmt if fmt is not None else "%Y-%m-%d")

    return None


def get_yestraday(fmt: str | None = None) -> str | None:
    """
    获取距今最近交易日的前一个交易日

    Returns:
        str: 最近交易日的前一个交易日，格式为'YYYY-MM-DD'，如果没有找到返回None
    """
    troday = get_traday()
    if troday is None:
        return None

    return get_prev_date(troday, fmt)
