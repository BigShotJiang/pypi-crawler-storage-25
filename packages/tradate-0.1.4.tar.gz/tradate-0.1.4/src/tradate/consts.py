#!/usr/bin/env python3

from pathlib import Path

PARENT: Path = Path(__file__).parent.absolute()

DATA_DIR: Path = PARENT / "data"

DESKTOP_PATH: Path = Path.home().absolute() / "Desktop"
