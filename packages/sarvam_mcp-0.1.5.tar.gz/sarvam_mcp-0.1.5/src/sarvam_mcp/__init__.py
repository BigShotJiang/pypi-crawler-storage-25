"""Sarvam AI MCP server — first-class MCP tools for the full public Sarvam API surface."""

__version__ = "0.1.0"
