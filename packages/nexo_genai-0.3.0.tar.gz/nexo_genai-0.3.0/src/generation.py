from abc import ABC, abstractmethod
from .prompt import PromptManager


class ConfigManager[T: PromptManager](ABC):
    """
    A manager responsible for configuring the generation settings (e.g., temperature,
    response schemas, and system instructions) for the LLM models.

    This class centralizes the `GenerateContentConfig` objects so they can be reused
    efficiently across the application without needing to be re-instantiated for every request.
    """

    def __init__(self, prompt_manager: T):
        self._prompt_manager = prompt_manager

    @abstractmethod
    def load(self) -> None:
        """
        Initializes the generation configurations by attaching the required system
        prompts and JSON schemas.

        ⚠️ IMPORTANT:
        This method MUST be called during the application's startup phase ("before start" lifespan).
        Furthermore, it strictly requires that the `PromptManager.load()` method has already
        been executed, as it relies on the system prompts loaded by the PromptManager.

        Args:
            prompt_manager (PromptManager): The initialized PromptManager instance containing
                                            the loaded system prompts.
        """
