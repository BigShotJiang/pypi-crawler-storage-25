from copy import deepcopy
from datetime import datetime, timezone
from google import genai
from google.genai.types import GenerateContentConfig, GenerateContentResponse
from google.oauth2.service_account import Credentials
from pydantic import BaseModel, Field
from typing import Annotated
from uuid import uuid4
from nexo.logging.config import LogConfig
from nexo.logging.logger import Client
from nexo.schemas.application import ApplicationContext, OptApplicationContext
from nexo.schemas.bus import ListOfAnyPublishers
from nexo.schemas.connection import OptConnectionContext
from nexo.schemas.error.enums import ErrorCode
from nexo.schemas.exception.factory import MaleoExceptionFactory
from nexo.schemas.operation.context import DefaultOperationContext
from nexo.schemas.operation.enums import OperationType
from nexo.schemas.operation.mixins import Timestamp
from nexo.schemas.operation.resource import (
    CreateResourceOperationAction,
    CreateSingleResourceOperation,
)
from nexo.schemas.resource import ResourceIdentifier, AggregateField
from nexo.schemas.response import SingleDataResponse
from nexo.schemas.security.authentication import OptAnyAuthentication
from nexo.schemas.security.authorization import OptAnyAuthorization
from nexo.schemas.security.impersonation import OptImpersonation
from nexo.types.misc import OptPathOrStr
from nexo.types.uuid import OptUUID
from nexo.utils.loaders.google import load, validate
from .constants import GENAI_RESOURCE
from .schemas import Text


GOOGLE_GENAI_RESOURCE = deepcopy(GENAI_RESOURCE)
GOOGLE_GENAI_RESOURCE.identifiers.append(
    ResourceIdentifier(key="google", name="Google", slug="google")
)


class GoogleGenAIConfig(BaseModel):
    location: Annotated[str, Field(..., description="Model's Location")]
    model: Annotated[str, Field(..., description="Model's Name")]


OptGoogleGenAIConfig = GoogleGenAIConfig | None


class GoogleGenAIConfigMixin[T: OptGoogleGenAIConfig](BaseModel):
    google: Annotated[T, Field(..., description="Google's GenAI Config")]


class GoogleGenAI:
    def __init__(
        self,
        config: GoogleGenAIConfig,
        log_config: LogConfig,
        *,
        application_context: OptApplicationContext = None,
        credentials: Credentials | None = None,
        credentials_path: OptPathOrStr = None,
        publishers: ListOfAnyPublishers,
    ) -> None:
        self.config = config

        self._application_context = (
            application_context
            if application_context is not None
            else ApplicationContext.new()
        )

        self._logger = Client(
            log_config,
            environment=self._application_context.environment,
            service_key=self._application_context.service_key,
            client_key=GOOGLE_GENAI_RESOURCE.aggregate(AggregateField.KEY, sep="_"),
        )

        self._operation_context = DefaultOperationContext.CLIENT_SERVICE_INTERNAL.value

        if (credentials is None and credentials_path is None) or (
            credentials is not None and credentials_path is not None
        ):
            raise ValueError(
                "Only either 'credentials' and 'credentials_path' must be given"
            )

        if credentials is not None:
            self._credentials = credentials
        else:
            self._credentials = load(credentials_path)

        validate(self._credentials)

        self.client = genai.Client(
            vertexai=True,
            project=self.project_id,
            location=self.config.location,
        )

        self._publishers = publishers

    @property
    def project_id(self) -> str:
        project_id = self._credentials.project_id
        if not isinstance(project_id, str):
            raise ValueError("Project ID did not exist")
        return project_id

    def generate_text(
        self,
        *,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        config: GenerateContentConfig,
        contents: str,
    ) -> SingleDataResponse[Text, None]:
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = CreateResourceOperationAction()

        resource = deepcopy(GENAI_RESOURCE)
        resource.details = {"type": "text"}

        executed_at = datetime.now(tz=timezone.utc)

        content_generation_response = self.client.models.generate_content(
            model=self.config.model, contents=contents, config=config
        )

        operation_response = SingleDataResponse[GenerateContentResponse, None].new(
            data=content_generation_response
        )
        summary = f"Successfully generated text using model '{self.config.model}' in location '{self.config.location}'."
        operation = CreateSingleResourceOperation[GenerateContentResponse, None](
            application_context=self._application_context,
            id=operation_id,
            is_ai=True,
            context=self._operation_context,
            action=operation_action,
            resource=resource,
            timestamp=Timestamp.completed_now(executed_at),
            summary=summary,
            connection_context=connection_context,
            authentication=authentication,
            authorization=authorization,
            impersonation=impersonation,
            response=operation_response,
        )
        operation.log_and_publish(self._logger, self._publishers)

        if content_generation_response.text is None:
            summary = "Content generation response did not contains any text."
            exc = MaleoExceptionFactory.from_code(
                ErrorCode.INTERNAL_SERVER_ERROR,
                details=summary,
                operation_type=OperationType.RESOURCE,
                operation_id=operation_id,
                is_ai_operation=True,
                operation_context=self._operation_context,
                operation_action=operation_action,
                resource=GENAI_RESOURCE,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary=summary,
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            raise exc

        data = Text(text=content_generation_response.text)
        response = SingleDataResponse[Text, None].new(data=data)

        return response
