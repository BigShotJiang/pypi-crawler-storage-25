from typing import Annotated

from pydantic import BaseModel, Field

from .google import OptGoogleGenAIConfig
from .prompt import PromptConfig


class GenAIConfig[P: PromptConfig, G: OptGoogleGenAIConfig](BaseModel):
    prompt: Annotated[P, Field(..., description="Prompt's config")]
    google: Annotated[G, Field(..., description="Google's GenAI config")]


OptGenAIConfig = GenAIConfig | None


class GenAIConfigMixin[T: OptGenAIConfig](BaseModel):
    genai: Annotated[T, Field(..., description="GenAI's config")]
