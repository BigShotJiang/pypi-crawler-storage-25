from typing import Annotated, Self

from abc import ABC, abstractmethod
from nexo.types.string import OptStr
from pathlib import Path
from pydantic import BaseModel, Field, model_validator
from uuid import UUID


class PromptConfig(BaseModel):
    use_local_prompt: Annotated[
        bool, Field(..., description="Whether to use local prompt")
    ]
    prompt_dir: Annotated[OptStr, Field(..., description="Prompt directory")]

    @model_validator(mode="after")
    def validate_prompt_dir(self) -> Self:
        if self.use_local_prompt:
            if self.prompt_dir is None:
                raise ValueError("Prompt directory can't be None")
            else:
                prompt_dir = Path(self.prompt_dir)
                if not prompt_dir.exists() or not prompt_dir.is_dir():
                    raise ValueError(
                        f"Prompt directory '{self.prompt_dir}' "
                        "either did not exist or is not a directory"
                    )
        return self


class PromptManager(ABC):
    """
    A unified manager for handling the lifecycle, storage, and generation of LLM prompts.

    This class serves two primary responsibilities:
    1. **Initialization (Manager)**: Downloading and caching raw system prompts and user
       prompt templates from an external source (e.g., Google Secret Manager) via `load()`.
    2. **Formatting (Generator)**: Providing methods to inject dynamic runtime data
       into the loaded templates to produce final prompt strings.

    ⚠️ IMPORTANT USAGE NOTE:
    The `generate_*_prompt` methods rely on templates that are populated by the `load()` method.
    Therefore, `load()` MUST be executed during the application's startup phase (specifically
    in the "before start" lifespan step). Calling any generation method before `load()`
    is called will result in missing or uninitialized template errors.
    """

    @abstractmethod
    def __init__(self):
        """
        Initialize the prompt manager
        """

    @abstractmethod
    def load(self, operation_id: UUID):
        """
        Downloads and initializes the system and user prompts from Google Secret Manager.

        ⚠️ IMPORTANT:
        This method MUST be called to initialize the prompts before any other operations occur.
        It is strictly required to be executed during the application's startup phase,
        specifically in the "before start" step of the application's lifespan.

        Args:
            operation_id (UUID): The unique ID for tracing the startup operation.
            google_secret_manager (GoogleSecretManager): The client used to read the secrets.
        """
