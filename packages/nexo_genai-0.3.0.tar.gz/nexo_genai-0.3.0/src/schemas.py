from typing import Annotated

from pydantic import BaseModel, Field


class Text(BaseModel):
    text: Annotated[str, Field(..., description="Response Text")]
