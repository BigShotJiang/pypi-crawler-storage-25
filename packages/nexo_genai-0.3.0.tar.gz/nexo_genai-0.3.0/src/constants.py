from nexo.schemas.resource import Resource, ResourceIdentifier

GENAI_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="genai",
            name="GenAI",
            slug="genai",
        )
    ],
    details=None,
)
