# Custom Rules Guide

AgentLint lets you create project-specific rules using the same interface as built-in rules. Custom rules are Python files placed in a directory of your choice.

## Setup

1. Create a rules directory in your project:

```bash
mkdir -p .agentlint/rules
```

2. Enable it in `agentlint.yml` and add your pack name to `packs:`:

```yaml
packs:
  - universal
  - myproject          # activates rules with pack = "myproject"

custom_rules_dir: .agentlint/rules/
```

Rules whose `pack` is not in `packs:` are loaded but silently skipped. Use `agentlint doctor` to detect this.

## Creating a rule

Create a `.py` file in your custom rules directory. Each file can contain one or more `Rule` subclasses.

```python
# .agentlint/rules/no_raw_sql.py
from agentlint.models import Rule, RuleContext, Violation, Severity, HookEvent


class NoRawSQL(Rule):
    id = "no-raw-sql"
    description = "Blocks raw SQL queries — use the ORM instead"
    severity = Severity.WARNING
    events = [HookEvent.PRE_TOOL_USE]
    pack = "myproject"

    def evaluate(self, context: RuleContext) -> list[Violation]:
        content = context.file_content or ""
        if not content:
            return []

        # Check for raw SQL patterns
        sql_keywords = ["execute(", "raw_sql(", "cursor.execute("]
        for keyword in sql_keywords:
            if keyword in content:
                return [Violation(
                    rule_id=self.id,
                    message=f"Raw SQL detected ({keyword}). Use the ORM.",
                    severity=self.severity,
                    file_path=context.file_path,
                    suggestion="Use Model.objects or the query builder instead.",
                )]
        return []
```

## Rule anatomy

Every rule needs these class attributes:

| Attribute | Type | Description |
|-----------|------|-------------|
| `id` | `str` | Unique identifier. Prefix with `custom/` for clarity. |
| `description` | `str` | One-line description. |
| `severity` | `Severity` | `ERROR` (blocks), `WARNING` (advises), or `INFO` (reports). |
| `events` | `list[HookEvent]` | When this rule runs. |
| `pack` | `str` | Pack name — any string. Must be listed in `packs:` to activate. |

And one method:

```python
def evaluate(self, context: RuleContext) -> list[Violation]:
    """Return a list of violations (empty list = pass)."""
```

## RuleContext fields

Your `evaluate` method receives a `RuleContext` with:

| Field | Type | Description |
|-------|------|-------------|
| `event` | `HookEvent` | Current lifecycle event |
| `tool_name` | `str` | Tool being used (Write, Edit, Bash, etc.) |
| `tool_input` | `dict` | Raw tool input from Claude Code |
| `project_dir` | `str` | Absolute path to project root |
| `file_content` | `str \| None` | File content (for Write/Edit operations) |
| `file_content_before` | `str \| None` | File content before edit (for diff-based rules, PostToolUse only) |
| `file_path` | `str \| None` | Target file path (from `tool_input`) |
| `command` | `str \| None` | Bash command (from `tool_input`) |
| `config` | `dict` | Per-rule config from `agentlint.yml` |
| `session_state` | `dict` | Mutable shared state across the session |
| `prompt` | `str \| None` | User prompt text (UserPromptSubmit only) |
| `subagent_output` | `str \| None` | Subagent's last assistant message (SubagentStop only) |
| `agent_transcript_path` | `str \| None` | Path to subagent's JSONL transcript (SubagentStop only) |
| `agent_type` | `str \| None` | Subagent type, e.g. "general-purpose" (SubagentStart/Stop) |
| `agent_id` | `str \| None` | Unique subagent identifier (SubagentStart/Stop) |
| `notification_type` | `str \| None` | Notification type (Notification only) |
| `compact_source` | `str \| None` | Context that was compacted (PreCompact only) |

## Hook events

AgentLint supports all 17 Claude Code hook events. Choose which events your rule responds to:

**Registered by `agentlint setup`** (7 events):

| Event | When | Can block? |
|-------|------|-----------|
| `HookEvent.PRE_TOOL_USE` | Before a tool call | Yes (ERROR = deny protocol) |
| `HookEvent.POST_TOOL_USE` | After a tool call | No (advise only) |
| `HookEvent.USER_PROMPT_SUBMIT` | When user sends a prompt | No (advise only) |
| `HookEvent.SUB_AGENT_START` | When a subagent spawns | No (injects `additionalContext`) |
| `HookEvent.SUB_AGENT_STOP` | When a subagent completes | No (advise only) |
| `HookEvent.NOTIFICATION` | On system notifications | No (advise only) |
| `HookEvent.STOP` | End of session | No (report only) |

**Available for custom rules** (10 additional events):

| Event | When |
|-------|------|
| `HookEvent.SESSION_START` | Session begins |
| `HookEvent.SESSION_END` | Session ends |
| `HookEvent.PRE_COMPACT` | Before context compaction |
| `HookEvent.POST_TOOL_USE_FAILURE` | After a tool call fails |
| `HookEvent.PERMISSION_REQUEST` | User asked to approve an action |
| `HookEvent.CONFIG_CHANGE` | Settings changed mid-session |
| `HookEvent.WORKTREE_CREATE` | Git worktree created |
| `HookEvent.WORKTREE_REMOVE` | Git worktree removed |
| `HookEvent.TEAMMATE_IDLE` | Teammate goes idle |
| `HookEvent.TASK_COMPLETED` | Background task completes |

Custom rules targeting these events work out of the box — the CLI routes any event string to the engine. You only need to add the corresponding hook entry to `.claude/settings.json` if it's not already registered.

## Using session state

Rules can share state across invocations using `context.session_state`. This is a mutable dict persisted between hook calls:

```python
def evaluate(self, context: RuleContext) -> list[Violation]:
    state = context.session_state
    state["my_counter"] = state.get("my_counter", 0) + 1
    # State persists to the next invocation
    ...
```

## Testing your rule

```python
# tests/test_my_rule.py
from agentlint.models import HookEvent, RuleContext
from your_rules.no_raw_sql import NoRawSQL


def test_detects_raw_sql():
    rule = NoRawSQL()
    context = RuleContext(
        event=HookEvent.PRE_TOOL_USE,
        tool_name="Write",
        tool_input={"file_path": "app/views.py"},
        project_dir="/tmp",
        file_content="cursor.execute('SELECT * FROM users')",
    )
    violations = rule.evaluate(context)
    assert len(violations) == 1
    assert "Raw SQL" in violations[0].message


def test_passes_orm_code():
    rule = NoRawSQL()
    context = RuleContext(
        event=HookEvent.PRE_TOOL_USE,
        tool_name="Write",
        tool_input={"file_path": "app/views.py"},
        project_dir="/tmp",
        file_content="users = User.objects.filter(active=True)",
    )
    assert rule.evaluate(context) == []
```

## Rule discovery

AgentLint auto-loads custom rules by scanning the configured directory:

- **File naming**: Any `.py` file in the directory is loaded (non-recursive)
- **Skipped files**: Files starting with `_` (e.g., `_helpers.py`, `__init__.py`) are ignored — use these for shared utilities
- **Class detection**: Each file is scanned for subclasses of `Rule` — you can have multiple rule classes per file
- **Pack attribute**: Set `pack` to any name (e.g., `"fintech"`, `"myproject"`). The pack name must appear in your `packs:` list to activate — use `agentlint doctor` to detect orphaned packs

### Debugging tips

If your custom rule isn't loading:

1. **Check the path**: Verify `custom_rules_dir` in `agentlint.yml` is relative to your project root
2. **Check the filename**: Ensure it doesn't start with `_`
3. **Check the class**: It must subclass `Rule` from `agentlint.models` and have all required attributes (`id`, `description`, `severity`, `events`, `pack`)
4. **Enable debug logging**: Run with `AGENTLINT_LOG_LEVEL=DEBUG agentlint check --event PreToolUse` to see rule loading output
5. **Test in isolation**: Import your rule file directly in a Python script to check for syntax errors
