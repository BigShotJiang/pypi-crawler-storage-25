#!/usr/bin/env python3
"""Print per-class image counts for each split in a WebDataset folder."""

import argparse
import json
import sys
import tarfile
from collections import Counter
from pathlib import Path


def decode_cls(raw: bytes, classes: list[str]) -> str:
    s = raw.decode().strip()
    if s.lstrip("-").isdigit():
        idx = int(s)
        return classes[idx] if 0 <= idx < len(classes) else s
    return s


def count_split(wds_dir: Path, split: str, num_shards: int, classes: list[str]) -> Counter:
    counts: Counter = Counter()
    split_dir = wds_dir / split
    for i in range(num_shards):
        shard = split_dir / f"shard-{i:06d}.tar"
        if not shard.exists():
            print(f"  Warning: {shard} not found, skipping", file=sys.stderr)
            continue
        with tarfile.open(shard) as tf:
            for member in tf.getmembers():
                if member.name.endswith(".cls"):
                    cls_name = decode_cls(tf.extractfile(member).read(), classes)
                    counts[cls_name] += 1
    return counts


def print_table(split: str, counts: Counter, classes: list[str]) -> None:
    total = sum(counts.values())
    print(f"\n{split}  ({total:,} total)")
    print(f"  {'class':<30} {'count':>8}  {'%':>6}")
    print(f"  {'-'*30} {'-'*8}  {'-'*6}")
    for cls in classes:
        n = counts.get(cls, 0)
        pct = 100 * n / total if total else 0.0
        print(f"  {cls:<30} {n:>8,}  {pct:>5.1f}%")
    # show any unexpected classes not listed in dataset_info.json
    for cls in sorted(counts):
        if cls not in classes:
            n = counts[cls]
            pct = 100 * n / total if total else 0.0
            print(f"  {cls:<30} {n:>8,}  {pct:>5.1f}%  [unexpected]")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", help="Path to dataset root (must contain wds/dataset_info.json)")
    parser.add_argument(
        "--splits", nargs="+", default=None,
        help="Splits to count (default: all splits in dataset_info.json)",
    )
    args = parser.parse_args()

    root = Path(args.data)
    info_path = root / "wds" / "dataset_info.json"
    if not info_path.exists():
        sys.exit(f"Error: {info_path} not found")

    with open(info_path) as f:
        meta = json.load(f)

    classes: list[str] = meta.get("classes", [])
    splits_meta: dict = meta.get("splits", {})
    splits_to_run = args.splits if args.splits else list(splits_meta.keys())

    wds_dir = root / "wds"
    split_totals = {}
    for split in splits_to_run:
        if split not in splits_meta:
            print(f"Warning: split '{split}' not in dataset_info.json, skipping", file=sys.stderr)
            continue
        num_shards = splits_meta[split]["num_shards"]
        print(f"Counting {split} ({num_shards} shards)…", end="", flush=True)
        counts = count_split(wds_dir, split, num_shards, classes)
        print("\r", end="")
        split_totals[split] = sum(counts.values())
        print_table(split, counts, classes)

    # Print split distribution summary
    if split_totals:
        grand_total = sum(split_totals.values())
        print(f"\nSplit distribution ({grand_total:,} total images)")
        print(f"  {'split':<20} {'count':>8}  {'%':>6}")
        print(f"  {'-'*20} {'-'*8}  {'-'*6}")
        for split in splits_to_run:
            if split in split_totals:
                count = split_totals[split]
                pct = 100 * count / grand_total
                print(f"  {split:<20} {count:>8,}  {pct:>5.1f}%")


if __name__ == "__main__":
    main()
