# Артефакты doubled-graph

Формат — **XML** (совместимость с `doubled-graph.lint()` валидацией). Шесть файлов в `docs/`, один в корне. Создаются агентом по сценарию из `prompts/new-project/` или `prompts/migrate-existing-project/` (через `Write`), эволюционируют через skills семейства `doubled-graph-*` (через `Edit`).

**Источник истины для XML-схем** — templates в upstream grace-marketplace:
[`skills/grace/grace-init/assets/docs/*.xml.template`](https://github.com/osovv/grace-marketplace/tree/main/skills/grace/grace-init/assets/docs). Мы **не форкаем** их; описываем роль и связи между ними. Минимальные inline-шаблоны для bootstrap'а — в `prompts/new-project/` промптах.

---

## Карта артефактов

```
docs/
├── requirements.xml           ← что делает продукт (бизнес-цели, AAG)
├── technology.xml             ← стек, версии, constraints
├── development-plan.xml       ← модули, контракты, фазы, flows
├── knowledge-graph.xml        ← declared graph: модули, экспорты, CrossLinks
├── verification-plan.xml      ← тесты, сценарии, markers, gates
└── operational-packets.xml    ← canonical ExecutionPacket/GraphDelta/FailurePacket shapes

AGENTS.md                      ← протокол агента + phase-блок (см. drift-and-priority.md)
```

Плюс код с якорями разметки (ниже § «Разметка кода»).

---

## 1. `docs/requirements.xml`

**Что содержит:** use-cases в нотации Actor–Action–Goal (AAG). Каждый use case — атомарен.

```xml
<Requirements>
  <UseCase id="UC-001">
    <Actor>Buyer</Actor>
    <Action>place_order</Action>
    <Goal>получить подтверждение в течение 3 секунд</Goal>
    <NonFunctional>
      <Latency>p95 &lt; 3s</Latency>
      <Security>JWT-auth required</Security>
    </NonFunctional>
  </UseCase>
  ...
</Requirements>
```

**Кто меняет:** человек — напрямую или через ИИ с явной формулировкой. Изменение требования = новая версия, старая помечается `deprecated`.

**Связи:** каждый `UC-xxx` реализуется одним или несколькими `M-xxx` в `development-plan.xml`; эта связь отражается в `knowledge-graph.xml` через элемент `Implements`.

---

## 2. `docs/technology.xml`

**Что содержит:** стек и constraints.

```xml
<Technology>
  <Runtime name="<язык>" minimum="<floor от зависимостей>" preferred="current-stable" />
  <Libraries>
    <Lib name="<framework>" version=">=X.Y" />
    <Lib name="<orm>" version="^X" />
  </Libraries>
  <Testing>
    <Framework>&lt;из language-adapter&gt;</Framework>
    <Coverage target="<80%|настраиваемо>" />
  </Testing>
  <Deployment>&lt;Docker | k8s | serverless | bare-metal&gt;</Deployment>
</Technology>
```

**Правила версий:**
- `minimum` — обоснованный floor (напр., `3.12` для Python если нужен FalkorDB Lite). Не завышай.
- `preferred` — обычно `current-stable` или `LTS`. Конкретный `X.Y.Z` **не указывай** — устаревает.
- В `<Lib version>` используй диапазоны (`>=X.Y`, `^X`, `~X.Y`), не exact pins. Exact pins — lockfile'у.

**Approval-gate:** утверждение стека происходит до того, как `development-plan.xml` начнёт ссылаться на конкретные библиотеки. На момент approval актуальные версии сверяются через WebFetch/WebSearch — не берутся из памяти ИИ.

---

## 3. `docs/development-plan.xml`

**Что содержит:** модули, контракты модулей, фазы, data-flows.

```xml
<DevelopmentPlan>
  <M-AUTH-VALIDATE NAME="AuthValidate" TYPE="CORE_LOGIC" LAYER="1" STATUS="planned" CRITICALITY="critical">
    <contract>
      <purpose>Validate incoming JWT and resolve User. JWT header must be present; returns User | null (never throws); clock-skew tolerance = 60s.</purpose>
      <inputs><param name="req" type="Request"/></inputs>
      <outputs><param name="user" type="User | null"/></outputs>
    </contract>
    <target>
      <source>src/auth/validate.ts</source>
      <tests>tests/auth/validate.test.ts</tests>
    </target>
    <interface>
      <export-validateUser PURPOSE="validate JWT, resolve user"/>
    </interface>
    <depends>M-AUTH-TOKENS</depends>
  </M-AUTH-VALIDATE>

  <Phase-1 name="Foundation" status="pending">
    <goal>Set up authentication core</goal>
    <step-1 module="M-AUTH-TOKENS" status="pending" verification="V-M-AUTH-TOKENS">provision token utilities</step-1>
    <step-2 module="M-AUTH-VALIDATE" status="pending" verification="V-M-AUTH-VALIDATE">JWT validation logic</step-2>
  </Phase-1>

  <DF-LOGIN NAME="LoginFlow" TRIGGER="user-login">
    <step-1>M-ROUTES-LOGIN receives login request</step-1>
    <step-2>M-AUTH-VALIDATE validates JWT</step-2>
    <step-3>M-SESSION-CREATE creates session</step-3>
    <evidence>VALIDATE_SUCCESS marker in logs</evidence>
  </DF-LOGIN>
</DevelopmentPlan>
```

**Приоритет полей:**
- `CRITICALITY` ∈ {critical, standard, helper} — вход для risk-level в `doubled-graph.impact()`.
- `<target><source>` — множество файлов, принадлежащих модулю. `doubled-graph.detect_changes()` по этому полю определяет `code_without_module`.
- `<DF-*>` — используется для визуализации процессов и для `critical-path` классификации в `impact`.

---

## 4. `docs/knowledge-graph.xml` — declared graph

**Что содержит:** модули, экспорты, CrossLinks (ссылки между модулями), аннотации.

```xml
<KnowledgeGraph>
  <M-AUTH-VALIDATE NAME="AuthValidate" TYPE="CORE_LOGIC" STATUS="planned">
    <purpose>Validate incoming JWT and resolve User</purpose>
    <path>src/auth/validate.ts</path>
    <depends>M-AUTH-TOKENS</depends>
    <annotations>
      <fn-validateUser PURPOSE="validate JWT, resolve user"/>
      <fn-validateToken PURPOSE="validate raw token string"/>
      <security>PII-touching</security>
    </annotations>
  </M-AUTH-VALIDATE>

  <CrossLink from="M-AUTH-VALIDATE" to="M-AUTH-TOKENS" relation="uses"/>
</KnowledgeGraph>
```

**Отличие от computed graph:** этот файл пишется ИИ по замыслу, а не извлекается из AST. Оба графа пересекаются в `doubled-graph.detect_changes()` — ядро ценности методологии, см. `tools.md`.

---

## 5. `docs/verification-plan.xml`

**Что содержит:** тесты, их команды, сценарии, markers (имена логов), gates.

```xml
<VerificationPlan>
  <V-M-AUTH-VALIDATE MODULE="M-AUTH-VALIDATE" PRIORITY="high">
    <test-files><file>tests/auth/validate.test.ts</file></test-files>
    <module-checks>
      <check-1>pnpm test auth/validate</check-1>
    </module-checks>
    <scenarios>
      <scenario-1 kind="success">valid JWT returns User</scenario-1>
      <scenario-2 kind="failure">expired JWT returns null</scenario-2>
    </scenarios>
    <required-log-markers>
      <marker-1>[AuthValidate][validateUser][BLOCK_DECODE_JWT] VALIDATE_SUCCESS</marker-1>
      <marker-2>[AuthValidate][validateUser][BLOCK_CHECK_CLOCK_SKEW] VALIDATE_FAIL</marker-2>
    </required-log-markers>
  </V-M-AUTH-VALIDATE>

  <Gate id="G-pre-merge" kind="required">
    <Check>doubled-graph lint</Check>
    <Check>doubled-graph detect-changes --scope compare --base-ref main</Check>
    <Check>pnpm test</Check>
  </Gate>
</VerificationPlan>
```

**Связь с кодом:** каждый `<marker-N>` в `<required-log-markers>` — имя, которое должно появиться в structured log, когда код проходит соответствующую точку. `doubled-graph.detect_changes()` `missing_verification` проверяет, что для каждого критического `M-*` есть хотя бы один `V-M-*`.

---

## 6. `docs/operational-packets.xml`

**Что содержит:** canonical форматы пакетов, которыми агент обменивается между фазами / sub-agent'ами.

- **ExecutionPacket** — что parent agent передаёт worker'у при параллельной кодогенерации.
- **GraphDelta** — что worker возвращает (новые модули, изменённые экспорты).
- **VerificationDelta** — то же для verification.
- **FailurePacket** — handoff между debug-итерациями.

Это — инфраструктурный артефакт; в маленьких проектах может быть пустым (только шаблоны без содержимого). Пользователю видеть редко.

---

## 7. `AGENTS.md`

Создаётся при bootstrap проекта (см. `prompts/new-project/02-requirements.md`). Содержит:

- Keywords и Annotation проекта.
- Копию 10 принципов doubled-graph.
- Справочник якорей (см. § «Разметка кода» ниже).
- Конвенцию логов и verification.
- **phase-блок** (см. `drift-and-priority.md`):

```markdown
<!-- doubled-graph:phase:start -->
## doubled-graph phase
phase: post_migration
updated: 2026-04-18
<!-- doubled-graph:phase:end -->
```

ИИ-ассистент читает `AGENTS.md` первым при входе в репозиторий.

---

## Разметка кода (якоря)

Синтаксис комментариев адаптируется под язык (см. `language-adapters/*.md`). Ниже — в TypeScript-варианте.

```ts
// START_MODULE_CONTRACT
// Module: M-AUTH-VALIDATE
// Purpose: validate JWT and resolve User
// Scope: single file src/auth/validate.ts
// Dependencies: M-AUTH-TOKENS
// Criticality: critical
// LINKS: UC-001, V-M-AUTH-VALIDATE-01
// END_MODULE_CONTRACT

// START_MODULE_MAP
// exports:
//   - validateUser (function)
//   - validateToken (function)
// END_MODULE_MAP

// START_CONTRACT: validateUser
// PURPOSE: validate JWT, resolve user
// INPUTS: req: Request (with Authorization: Bearer header)
// OUTPUTS: User | null (null if invalid, never throws)
// SIDE_EFFECTS: none
// LINKS: UC-001, M-AUTH-VALIDATE, V-M-AUTH-VALIDATE-01
// END_CONTRACT: validateUser
export function validateUser(req: Request): User | null {
  // START_BLOCK_DECODE_JWT
  const token = extractToken(req);
  const payload = decodeJwt(token);
  // END_BLOCK_DECODE_JWT

  // START_BLOCK_CHECK_CLOCK_SKEW
  if (Math.abs(Date.now() - payload.iat * 1000) > 60_000) return null;
  // END_BLOCK_CHECK_CLOCK_SKEW

  return payload.user;
}

// START_CHANGE_SUMMARY
// 2026-04-12: tightened JWT clock-skew tolerance to 60s (DG-Authored: ai)
// 2026-04-18: --
// END_CHANGE_SUMMARY
```

**Правила:**

- **Модуль-контракт** — на уровне файла (первый раз), не дублируется внутри файла.
- **Function-контракт** — перед определением функции (для TS/Java/Go); в Python — в docstring под `def` (см. `language-adapters/python.md`).
- **Блок** — ≤ 500 токенов, имена уникальны **в файле**, но могут совпадать между файлами.
- **CHANGE_SUMMARY** — в конце файла, хронологический порядок, последняя строка — дата-пустая-запись (для будущих правок).

`doubled-graph.lint()` проверяет парность открывающих/закрывающих, уникальность в файле, соответствие имени функции в `START_CONTRACT:`/`END_CONTRACT:`, наличие `M-*` в модуль-контракте, существующие `UC-*`/`V-M-*` в LINKS.

---

## Structured logs

Каждое лог-событие имеет минимум полей (см. § 13 методологии draft):

```json
{
  "ts": "2026-04-18T10:22:04.123Z",
  "level": "info",
  "anchor": "validateUser:BLOCK_DECODE_JWT",
  "module": "M-AUTH-VALIDATE",
  "requirement": "UC-001",
  "correlation_id": "req_abc123",
  "event": "jwt_decoded",
  "belief": "payload trusted, skew=0"
}
```

`anchor` имеет формат `<function>:<block>` (или просто `<function>` для function-level события) и **должен** совпадать с именем якоря в коде. `doubled-graph lint` проверяет, что каждый `anchor` ссылается на существующий якорь.

**Privacy-правила** — `drift-and-priority.md § Logs privacy` + `runtime-adapters/*.md`.

**OpenTelemetry GenAI — НЕ обязателен.** Команды могут использовать свой observability-стек; маркирование лог-полей выше — достаточный baseline. См. `memory/project_otel_dropped.md`.

---

## Жизненный цикл артефактов

| Файл | bootstrap (intent-интервью + `Write` шаблона) | architecture-gate (`Edit` модулей) | execute-фаза (после кодогенерации) | поддержка |
|---|---|---|---|---|
| requirements.xml | шаблон + ответы пользователя | + детальные UC | обычно не меняется | `Edit` UC при новой фиче |
| technology.xml | шаблон | стек утверждён | не меняется | `Edit` при апгрейде стека |
| development-plan.xml | шаблон | модули + фазы | контракты сверены с реальным кодом | `Edit` через skill `doubled-graph-after-edit` шаг 2 |
| knowledge-graph.xml | шаблон | модули + экспорты + CrossLinks | exports/CrossLinks под факт | `Edit` через skill `doubled-graph-after-edit` шаг 2 |
| verification-plan.xml | шаблон | V-M-* черновики | заполнено после прогонов | `Edit` через skill `doubled-graph-verify` |
| operational-packets.xml | шаблон | обычно не трогаем | inflight-метаданные параллельной кодогенерации | редко меняется |
| AGENTS.md | копия шаблона + phase-блок | не меняется | не меняется | `doubled-graph phase set` при переключении режима |
