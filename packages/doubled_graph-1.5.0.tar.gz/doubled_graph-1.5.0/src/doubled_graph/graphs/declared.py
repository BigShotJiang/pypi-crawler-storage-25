"""Parser for the declared graph (docs/*.xml produced by grace-marketplace).

Schema source of truth: upstream `osovv/grace-marketplace` templates at
`skills/grace/grace-init/assets/docs/*.xml.template`. The grace XML format
encodes IDs in tag names (not attributes) — `<M-CONFIG NAME=… STATUS=…>`,
`<V-M-AUTH MODULE=…>`, `<DF-001>` etc. Atom-attributes are uppercase
(`NAME`, `TYPE`, `MODULE`); child tags are lowercase or kebab.

We tolerate missing fields (half-initialised repos mid-migration must stay
queryable) — `_safe_parse` returns None on malformed XML and the caller
records the file in `loaded_from` with a `!` prefix.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable


_MODULE_TAG = re.compile(r"^M-[A-Za-z0-9_-]+$")
_VERIF_TAG = re.compile(r"^V-M-[A-Za-z0-9_-]+$")
_EXPORT_PREFIXES = ("export-", "fn-", "type-")


@dataclass
class DeclaredModule:
    id: str
    purpose: str = ""
    paths: list[str] = field(default_factory=list)
    exports: list[str] = field(default_factory=list)
    crosslinks: list[str] = field(default_factory=list)


@dataclass
class DeclaredVerification:
    id: str
    module_id: str
    kind: str = ""


@dataclass
class DeclaredGraph:
    modules: dict[str, DeclaredModule] = field(default_factory=dict)
    verification: dict[str, DeclaredVerification] = field(default_factory=dict)
    loaded_from: list[str] = field(default_factory=list)


def _safe_parse(path: Path) -> ET.Element | None:
    if not path.exists():
        return None
    try:
        return ET.parse(path).getroot()
    except ET.ParseError:
        return None


def _iter_module_tags(root: ET.Element) -> Iterable[ET.Element]:
    for el in root.iter():
        if _MODULE_TAG.match(el.tag or ""):
            yield el


def _iter_verification_tags(root: ET.Element) -> Iterable[ET.Element]:
    for el in root.iter():
        if _VERIF_TAG.match(el.tag or ""):
            yield el


def _append_unique(target: list[str], value: str) -> None:
    if value and value not in target:
        target.append(value)


def _export_name(tag: str) -> str | None:
    for prefix in _EXPORT_PREFIXES:
        if tag.startswith(prefix):
            return tag[len(prefix):]
    return None


def _merge_dev_plan_module(graph: DeclaredGraph, mod: ET.Element) -> None:
    mid = mod.tag
    existing = graph.modules.get(mid) or DeclaredModule(id=mid)

    purpose = (mod.findtext("contract/purpose") or "").strip()
    if purpose and not existing.purpose:
        existing.purpose = purpose

    for src in mod.findall("target/source"):
        if src.text:
            _append_unique(existing.paths, src.text.strip())
    for tst in mod.findall("target/tests"):
        if tst.text:
            _append_unique(existing.paths, tst.text.strip())

    for el in mod.findall("interface/*"):
        name = _export_name(el.tag or "")
        if name:
            _append_unique(existing.exports, name)

    graph.modules[mid] = existing


def _merge_kg_module(graph: DeclaredGraph, mod: ET.Element) -> None:
    mid = mod.tag
    existing = graph.modules.get(mid) or DeclaredModule(id=mid)

    purpose = (mod.findtext("purpose") or "").strip()
    if purpose and not existing.purpose:
        existing.purpose = purpose

    for el in mod.findall("path"):
        if el.text:
            _append_unique(existing.paths, el.text.strip())

    for el in mod.findall("annotations/*"):
        name = _export_name(el.tag or "")
        if name:
            _append_unique(existing.exports, name)

    graph.modules[mid] = existing


def load_declared_graph(repo_path: Path) -> DeclaredGraph:
    """Load declared graph from the conventional docs/ location.

    Why we need an in-process parser (vs always shelling to `grace`):
      `detect_changes` cross-references the declared graph with the
      CGC-computed graph on every call. Forking the grace CLI per cross-ref
      would add noticeable latency on large repos. We parse once, cache
      in-process, and hand CGC-comparable structures to `crossref.py`.

    Tolerant to missing / malformed files — returns whatever it can parse.
    Malformed files are recorded in `loaded_from` with a `!` prefix so the
    caller can surface it as a methodology warning instead of a hard error.
    """
    graph = DeclaredGraph()
    docs = repo_path / "docs"

    dev_plan = docs / "development-plan.xml"
    root = _safe_parse(dev_plan)
    if root is not None:
        graph.loaded_from.append(str(dev_plan))
        for mod in _iter_module_tags(root):
            _merge_dev_plan_module(graph, mod)
    elif dev_plan.exists():
        graph.loaded_from.append(f"!{dev_plan}")

    kg = docs / "knowledge-graph.xml"
    root = _safe_parse(kg)
    if root is not None:
        graph.loaded_from.append(str(kg))
        for mod in _iter_module_tags(root):
            _merge_kg_module(graph, mod)
        for cl in root.iter("CrossLink"):
            src_id = cl.get("from") or ""
            tgt_id = cl.get("to") or ""
            if not src_id or not tgt_id:
                continue
            mod = graph.modules.get(src_id)
            if mod is None:
                continue
            _append_unique(mod.crosslinks, tgt_id)
    elif kg.exists():
        graph.loaded_from.append(f"!{kg}")

    vp = docs / "verification-plan.xml"
    root = _safe_parse(vp)
    if root is not None:
        graph.loaded_from.append(str(vp))
        for v in _iter_verification_tags(root):
            vid = v.tag
            mid = v.get("MODULE") or v.get("module") or ""
            graph.verification[vid] = DeclaredVerification(
                id=vid,
                module_id=mid,
                kind=v.get("PRIORITY") or v.get("kind") or "",
            )
    elif vp.exists():
        graph.loaded_from.append(f"!{vp}")

    return graph
