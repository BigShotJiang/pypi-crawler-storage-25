import argparse
import sys
import os
from dcg_sci_tool.merge_xyz import merge_xyz
from dcg_sci_tool.applications.manual_name_xyz_png_at_nebdir import manual_name_xyz_png_at_nebdir
from dcg_sci_tool.reaction.neb_post_process import neb_post_process
from dcg_sci_tool.collect_pattern_files import collect_pattern_files
from dcg_sci_tool.get_detailed_MD_traj import get_detailed_MD_traj
from dcg_sci_tool.applications.get_traj_focusing_reaction_site_batches import get_traj_focusing_reaction_site_batches
from dcg_sci_tool.applications.get_reactants_ad_config_batches import get_reactants_ad_config_batches
from dcg_sci_tool.applications.get_reaction_site_infos_batches import get_reaction_site_infos_batches
from dcg_sci_tool.applications.label_barrier_batches import label_barrier_batches

# 第一步：为每个子命令定义其对应的处理函数
def merge_xyz_command(args):
    """
    处理 merge_xyz 子命令的实际逻辑。
    """
    print(f"正在处理输入文件列表: {args.input}")
    # 这里调用实际的合并函数
    merge_xyz(args.input)
    return 0

def manual_name_xyz_png_at_nebdir_command(args):
    """
    处理 manual_name_xyz_png_at_nebdir 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    manual_name_xyz_png_at_nebdir()
    return 0

def neb_post_process_command(args):
    """
    处理 neb_post_process 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    neb_post_process()
    return 0

def collect_pattern_files_command(args):
    """
    处理 collect_pattern_files 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    collect_pattern_files(args.pattern, args.directory)
    return 0

def get_detailed_MD_traj_command(args):
    """
    处理 get_detailed_MD_traj 子命令的实际逻辑。
    """
    # 将逗号分隔的字符串转换为整数列表
    if isinstance(args.atom_indexes, str):
        atom_index_list = [int(idx.strip()) for idx in args.atom_indexes.split(',')]
    elif hasattr(args.atom_indexes, '__iter__'):
        # 如果已经是可迭代对象，转换为整数列表
        atom_index_list = [int(idx) for idx in args.atom_indexes]
    else:
        # 单个值的情况
        atom_index_list = [int(args.atom_indexes)]
    
    get_detailed_MD_traj(int(args.index), atom_index_list)
    return 0


def get_traj_focusing_reaction_site_batches_command(args):
    """
    处理 get_traj_focusing_reaction_site_batches 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    get_traj_focusing_reaction_site_batches()
    return 0


def get_traj_focusing_reaction_site_batches_command(args):
    """
    处理 get_traj_focusing_reaction_site_batches 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    get_traj_focusing_reaction_site_batches(args.cutoff)
    return 0

def get_reactants_ad_config_batches_command(args):
    """
    处理 get_reactants_ad_config_batches 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    get_reactants_ad_config_batches()
    return 0

def get_reaction_site_infos_batches_command(args):
    """
    处理 get_reaction_site_infos_batches 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    get_reaction_site_infos_batches()
    return 0

def label_barrier_batches_command(args):
    """
    处理 label_barrier_batches 子命令的实际逻辑。
    """
    # 如果需要参数，可以从args中获取
    label_barrier_batches()
    return 0

def show_banner():
    """显示banner的函数"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    banner_path = os.path.join(script_dir, 'banner.txt')
    try:
        with open(banner_path, 'r', encoding='utf-8') as f:
            content = f.read()
        print(content)
    except FileNotFoundError:
        print("欢迎使用dcg-sci-tool！这是一个用于科学计算的工具包。")

def main():
    """主 CLI 入口函数"""
    
    # 1. 创建顶层解析器
    parser = argparse.ArgumentParser(
        description="dcg-sci-tool: 一个用于科学计算的工具包。",
        epilog="使用 'dcg-sci-tool <命令> -h' 查看具体命令帮助。",
        add_help=False  # 禁用默认的-h/--help处理
    )
    
    # 添加自定义的-h/--help参数
    parser.add_argument('-h', '--help', action='store_true', help='显示帮助信息')

    # 2. 创建子命令解析器
    subparsers = parser.add_subparsers(
        dest='command',
        title='可用命令',
        help='选择要执行的操作'
    )
    # 注意：这里不设置required=True，因为我们要处理无子命令的情况

    # 3. 定义 'merge_xyz' 子命令
    parser_merge_xyz = subparsers.add_parser(
        'merge_xyz',
        help='合并多个xyz文件'
    )
    
    parser_merge_xyz.add_argument(
        'input',
        nargs='+',
        help='要合并的xyz文件路径'
    )
    
    parser_merge_xyz.add_argument(
        '-o', '--output',
        default='merged.xyz',
        help='输出文件的路径 (默认: merged.xyz)'
    )
    
    # 4. 定义 'manual_name_xyz_png_at_nebdir' 子命令
    parser_manual_name_xyz_png_at_nebdir = subparsers.add_parser(
        'manual_name_xyz_png_at_nebdir',
        help='手动命名xyz文件和png文件'
    )
    
    parser_manual_name_xyz_png_at_nebdir.add_argument(
        '-d', '--directory',
        default='.',
        help='目标目录 (默认: 当前目录)'
    )
    
    # 5. 定义 'neb_post_process' 子命令
    parser_neb_post_process = subparsers.add_parser(
        'neb_post_process',
        help='对neb轨迹文件进行后处理'
    )
    
    parser_neb_post_process.add_argument(
        '-d', '--directory',
        default='.',
        help='目标目录 (默认: 当前目录)'
    )
    
    # 6. 定义 'collect_pattern_files' 子命令
    parser_collect_pattern_files = subparsers.add_parser(
        'collect_pattern_files',
        help='收集指定目录下的所有特定模式的文件'
    )
    
    parser_collect_pattern_files.add_argument(
        '-d', '--directory',
        # default='.',
        help='目标目录 (默认: 当前目录)'
    )
    parser_collect_pattern_files.add_argument(
        '-p', '--pattern',
        default='*.xyz',
        help='文件模式 (默认: *.xyz)'
    )
    
    # 7. 定义 'get_detailed_MD_traj' 子命令
    parser_get_detailed_MD_traj = subparsers.add_parser(
        'get_detailed_MD_traj',
        help='从MD轨迹文件中提取详细信息'
    )
    
    parser_get_detailed_MD_traj.add_argument(
        '-i', '--index',
        type=int,
        help='在合并的dump_locate.xyz轨迹中的帧索引，在0-39999之间'
    )
    parser_get_detailed_MD_traj.add_argument(
        '-a', '--atom_indexes',
        nargs='+',
        help='要上色的原子索引列表 (默认: 0)'
    )
    
    # 8. 定义 'get_traj_focusing_reaction_site_batches' 子命令
    parser_get_traj_focusing_reaction_site_batches = subparsers.add_parser(
        'get_traj_focusing_reaction_site_batches',
        help='从MD轨迹文件中提取聚焦反应局部结构'
    )
    
    parser_get_traj_focusing_reaction_site_batches.add_argument(
        '-c', '--cutoff',
        type=float,
        default=8.0,
        help='截止距离，单位为Å (默认: 8.0)'
    )
    
    # 9. 定义 'get_reactants_ad_config_batches' 子命令
    parser_get_reactants_ad_config_batches = subparsers.add_parser(
        'get_reactants_ad_config_batches',
        help='从MD轨迹文件中提取聚焦反应局部结构'
    )
    
    # 10. 定义 'get_reaction_site_infos_batches' 子命令
    parser_get_reaction_site_infos_batches = subparsers.add_parser(
        'get_reaction_site_infos_batches',
        help='批量获取neb轨迹初始帧的反应位点的结构信息'
    )

    # 11. 定义 'label_barrier_batches' 子命令
    parser_label_barrier_batches = subparsers.add_parser(
        'label_barrier_batches',
        help='批量给neb轨迹文件添加能垒注释'
    )
    
    parser_label_barrier_batches.set_defaults(func=label_barrier_batches_command)
    
    # 5. 将子命令绑定到处理函数
    parser_merge_xyz.set_defaults(func=merge_xyz_command)
    parser_manual_name_xyz_png_at_nebdir.set_defaults(func=manual_name_xyz_png_at_nebdir_command)
    parser_neb_post_process.set_defaults(func=neb_post_process_command)
    parser_collect_pattern_files.set_defaults(func=collect_pattern_files_command)
    parser_get_detailed_MD_traj.set_defaults(func=get_detailed_MD_traj_command)
    parser_get_traj_focusing_reaction_site_batches.set_defaults(func=get_traj_focusing_reaction_site_batches_command)
    parser_get_reactants_ad_config_batches.set_defaults(func=get_reactants_ad_config_batches_command)
    parser_get_reaction_site_infos_batches.set_defaults(func=get_reaction_site_infos_batches_command)
    parser_label_barrier_batches.set_defaults(func=label_barrier_batches_command)
    
    # 6. 解析参数
    try:
        args = parser.parse_args()
    except SystemExit:
        # 当parse_args()遇到错误（如无效参数）时会调用sys.exit()
        # 我们需要在这里捕获并显示帮助信息
        parser.print_help()
        sys.exit(2)
    
    # 7. 根据参数决定是否显示banner
    if not hasattr(args, 'func'):
        # 如果没有子命令，显示banner和帮助
        show_banner()
        print("\n" + "="*50 + "\n")
        parser.print_help()
        return 0
    
    # 8. 有子命令时，不显示banner，直接执行对应函数
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())