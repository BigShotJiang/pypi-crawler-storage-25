# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.1.x   | :white_check_mark: |
| 0.10.x  | :white_check_mark: |
| 0.9.x   | :white_check_mark: |
| 0.8.x   | :white_check_mark: |
| 0.7.x   | :white_check_mark: |
| < 0.7   | :x:                |

Current release line: **v1.1.0**.

## Reporting a Vulnerability

If you discover a security vulnerability in drift, **please do not open a public issue.**

Instead, report it privately:

1. **Email:** Send a detailed description to the maintainer via the contact listed on the [GitHub profile](https://github.com/sauremilk).
2. **GitHub Security Advisory:** Use the [private vulnerability reporting](https://github.com/sauremilk/drift/security/advisories/new) feature.

Please include:

- A description of the vulnerability and its potential impact.
- Steps to reproduce or a proof-of-concept.
- The drift version affected.

You will receive an acknowledgment within **72 hours** and a resolution timeline within **7 days**.

## Scope

drift is a static analysis tool that:

- **Parses Python and TypeScript source code** using AST modules and tree-sitter.
- **Invokes `git log`** via `subprocess` to read commit history.
- **Reads file system contents** of the target repository.

### Security Boundary Controls

The following controls are implemented in runtime code and treated as part of
the security baseline:

- **Path normalization:** repository roots are resolved to absolute paths before
	file traversal.
- **Symlink policy:** symlink files are skipped during file discovery.
- **File size guardrail:** files larger than 5 MB are skipped.
- **Git subprocess hardening:** git commands are invoked with argument lists
	(no shell interpolation) and fixed command templates.
- **Git timeout guardrail:** git history parsing uses a 60 second subprocess
	timeout.
- **Safe config parsing:** configuration is loaded via `yaml.safe_load` and
	validated via strict Pydantic schemas (`extra="forbid"`).
- **Non-executing parsing:** source files are parsed via `ast.parse` or
	tree-sitter; no analyzed source is executed.

### Known Attack Surface

| Vector | Description | Mitigation |
| --- | --- | --- |
| Git history parsing | drift calls `git log` via `subprocess` on the target repo. A crafted `.git` directory could theoretically influence output. | drift passes only hardcoded `git log` format strings — no user-controlled arguments are interpolated into shell commands. |
| Arbitrary file read | drift reads all `.py` and `.ts` files in the target directory tree. | No file contents are executed. Parsing is done via Python `ast.parse()` which does not execute code. |
| CI environment | When run in CI (e.g., GitHub Actions), drift has access to the runner's environment. | drift does not read environment variables, secrets, or network resources beyond the local repository. |

### Residual Risks and Operational Guidance

Even with the controls above, drift may still consume significant resources on
very large or adversarial repositories (for example, huge numbers of small
files or expensive parser workloads).

Recommended operational posture:

1. Run drift in isolated CI runners for untrusted repositories.
2. Use report-only mode first (`fail-on: none`) before enforcing hard gates.
3. Keep clone depth and analysis scope aligned with your risk and runtime
	 budget.
4. Treat optional dependency sets as an expanded supply-chain surface and pin
	 versions in controlled environments.

### Security Regression Evidence

Security-relevant behavior is covered by dedicated tests, including:

- `tests/test_git_history_safety.py` (subprocess argument safety and path
	handling)
- `tests/test_file_discovery.py` (symlink skipping, exclude handling, oversize
	file handling)
- `tests/test_cache_resilience.py` (corrupted cache and concurrent access
	resilience)

## Disclosure Policy

We follow [coordinated disclosure](https://en.wikipedia.org/wiki/Coordinated_vulnerability_disclosure). Vulnerabilities will be patched before public disclosure. Credit will be given to reporters unless they prefer anonymity.
