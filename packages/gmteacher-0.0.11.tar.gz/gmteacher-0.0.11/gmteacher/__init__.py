'''
GM Teacher Module
 - download_file
'''
import importlib.metadata

try:
    __version__ = importlib.metadata.version("gmteacher")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"

from .main import download_file
