import os
import requests

urls = {
    'PDF': ['온디바이스 AI 기술동향 및 발전방향.pdf', 'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/온디바이스%20AI%20기술동향%20및%20발전방향.pdf'],
    'PDF2': ['온디바이스 AI(On-Device AI) 산업현황 보고서.pdf', 'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/온디바이스%20AI(On-Device%20AI)%20산업현황%20보고서.pdf'],
    'IMAGE': ['seoul_night.jpg', 'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/seoul_night.jpg'],
    'AUDIO': ['sample_audio.mp3', 'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/sample_audio.mp3'],
    'HTML': ['page.html',  'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/page.html'],
    'IDBM_HTML':  ['imdb.html',  'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/imdb.html'],
    'ALL': ['data.zip',  'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/data.zip'],
    'SDI: ['sdi.zip', 'https://raw.githubusercontent.com/matiasteacher12/datarepo/main/sdi.zip']
}

def download_file(tag, path='./data/'):
    '''
     - tag: file tag -> {"PDF", "PDF2", "IMAGE", "AUDIO", "HTML", "IDBM_HTML", "ALL", "SDI"}
     - path: downlod directory (default: "./data/")
    '''
    url = urls.get(tag)

    if url:
        response = requests.get(url[1])

        if response.status_code == 200:
            data = response.content
            filepath = f'{path}{url[0]}'

            if not os.path.exists(filepath):
                os.makedirs(path, exist_ok=True)

                with open(filepath, 'wb') as f:
                    f.write(data)
                print(f'Download Completed: {filepath}')
            else:
                print('File Already Exists')
        else:
            print(f'Download Failed: {response.status_code}')
    else:
        print('ERROR: Tag Not Found')
