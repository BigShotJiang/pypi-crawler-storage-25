"""AgentSeal Regulatory Coverage Mapping."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import yaml

# ═══════════════════════════════════════════════════════════════════════
# Internal constants
# ═══════════════════════════════════════════════════════════════════════

_MAPPINGS_DIR = Path(__file__).parent / "mappings"

_FRAMEWORK_FILE_MAP: dict[str, str] = {
    "eu-ai-act": "eu_ai_act.yaml",
    "owasp-llm": "owasp_llm_top10.yaml",
}

_FRAMEWORK_ID_TO_NAME: dict[str, str] = {
    "eu-ai-act": "EU AI Act",
    "owasp-llm": "OWASP LLM Top 10",
}

_FRAMEWORK_NAME_TO_ID: dict[str, str] = {v: k for k, v in _FRAMEWORK_ID_TO_NAME.items()}

_DISCLAIMER = (
    "This report documents adversarial security testing performed against an AI system. "
    "It does not constitute compliance certification, legal advice, or an official conformity "
    "assessment. Regulatory compliance determinations require qualified legal and technical "
    "review. Framework mappings are provided for informational purposes only."
)

# Module-level cache so YAML files are only read once per process.
_mappings_cache: dict | None = None


# ═══════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════


def get_mapping_version() -> str:
    """Return the mapping version string from the VERSION file."""
    version_path = _MAPPINGS_DIR / "VERSION"
    return version_path.read_text(encoding="utf-8").strip()


def load_mappings() -> dict:
    """Load all YAML framework mapping files and return as a cached dict.

    Returns:
        dict keyed by framework id:
            ``"eu-ai-act"`` → parsed eu_ai_act.yaml
            ``"owasp-llm"`` → parsed owasp_llm_top10.yaml
    """
    global _mappings_cache
    if _mappings_cache is not None:
        return _mappings_cache

    result: dict = {}
    for fw_id, filename in _FRAMEWORK_FILE_MAP.items():
        path = _MAPPINGS_DIR / filename
        with path.open(encoding="utf-8") as fh:
            result[fw_id] = yaml.safe_load(fh)

    _mappings_cache = result
    return _mappings_cache


def get_regulatory_tags(category: str, technique: str) -> dict[str, list[str]]:
    """Return regulatory framework article IDs that apply to the given probe category.

    Matching rules:
    - ``pattern == "*"`` matches any category
    - ``pattern == category`` matches exactly

    Args:
        category: The probe category string (e.g. ``"instruction_override"``).
        technique: The probe technique string (unused in matching; reserved for future use).

    Returns:
        dict mapping framework id to a list of matched article ids, e.g.
        ``{"eu-ai-act": ["Art. 15(5)", "Art. 9"], "owasp-llm": ["LLM01"]}``
    """
    mappings = load_mappings()
    tags: dict[str, list[str]] = {}

    for fw_id, fw_data in mappings.items():
        matched_articles: list[str] = []
        for article in fw_data.get("articles", []):
            for cat_entry in article.get("categories", []):
                pattern = cat_entry.get("pattern", "")
                if pattern == "*" or pattern == category:
                    article_id = article["id"]
                    if article_id not in matched_articles:
                        matched_articles.append(article_id)
                    break  # No need to check more patterns for this article
        tags[fw_id] = matched_articles

    return tags


def get_gaps(framework: Optional[str] = None) -> list[dict]:
    """Load coverage gaps from gaps.yaml with optional framework filter.

    Args:
        framework: Optional framework id (e.g. ``"eu-ai-act"`` or ``"owasp-llm"``).
                   When provided, only gaps whose ``framework`` display name matches
                   are returned.

    Returns:
        List of gap dicts, each with keys: ``framework``, ``article``, ``gap``,
        ``description``.
    """
    gaps_path = _MAPPINGS_DIR / "gaps.yaml"
    with gaps_path.open(encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    all_gaps: list[dict] = data.get("gaps", [])

    if framework is None:
        return all_gaps

    # Translate framework id → display name for filtering
    display_name = _FRAMEWORK_ID_TO_NAME.get(framework)
    if display_name is None:
        return []

    return [g for g in all_gaps if g.get("framework") == display_name]


def build_regulatory_report(
    results: list,
    frameworks: Optional[list[str]] = None,
) -> dict:
    """Build a full regulatory coverage report from ProbeResult objects.

    Args:
        results: List of ``ProbeResult`` dataclass instances.
        frameworks: Optional list of framework ids to include.  When ``None``,
                    all frameworks are included.

    Returns:
        Report dict with structure described in the module docstring.
    """
    from agentseal.schemas import Verdict

    mappings = load_mappings()
    version = get_mapping_version()

    # Determine which frameworks to include
    fw_ids = list(mappings.keys())
    if frameworks is not None:
        fw_ids = [fid for fid in fw_ids if fid in frameworks]

    # Pre-load all gaps indexed by (framework_display_name, article_id)
    all_gaps = get_gaps()
    gaps_index: dict[tuple[str, str], list[dict]] = {}
    for g in all_gaps:
        key = (g["framework"], g["article"])
        gaps_index.setdefault(key, []).append({"gap": g["gap"], "description": g["description"]})

    report_frameworks: list[dict] = []

    for fw_id in fw_ids:
        fw_data = mappings[fw_id]
        display_name = _FRAMEWORK_ID_TO_NAME.get(fw_id, fw_data.get("framework", fw_id))
        fw_version = fw_data.get("framework_version", "")

        articles_out: list[dict] = []
        for article in fw_data.get("articles", []):
            article_id = article["id"]
            patterns = {cat["pattern"] for cat in article.get("categories", [])}

            # Match probe results to this article
            probes_tested = 0
            probes_blocked = 0
            probes_leaked = 0
            probes_partial = 0
            probes_error = 0
            techniques: list[str] = []

            for result in results:
                result_cat = result.category
                matched = ("*" in patterns) or (result_cat in patterns)
                if not matched:
                    continue
                probes_tested += 1
                if result.verdict == Verdict.BLOCKED:
                    probes_blocked += 1
                elif result.verdict == Verdict.LEAKED:
                    probes_leaked += 1
                elif result.verdict == Verdict.PARTIAL:
                    probes_partial += 1
                elif result.verdict == Verdict.ERROR:
                    probes_error += 1
                # Collect unique techniques
                if result.technique not in techniques:
                    techniques.append(result.technique)

            # Include gaps for articles with partial coverage
            article_gaps: list[dict] = []
            if article.get("coverage") == "partial":
                article_gaps = gaps_index.get((display_name, article_id), [])

            articles_out.append(
                {
                    "id": article_id,
                    "title": article.get("title", ""),
                    "coverage": article.get("coverage", ""),
                    "coverage_note": article.get("coverage_note", ""),
                    "probes_tested": probes_tested,
                    "probes_blocked": probes_blocked,
                    "probes_leaked": probes_leaked,
                    "probes_partial": probes_partial,
                    "probes_error": probes_error,
                    "techniques_tested": techniques,
                    "gaps": article_gaps,
                }
            )

        report_frameworks.append(
            {
                "id": fw_id,
                "name": display_name,
                "version": fw_version,
                "articles": articles_out,
            }
        )

    return {
        "mapping_version": version,
        "frameworks": report_frameworks,
        "disclaimer": _DISCLAIMER,
    }


def format_terminal(report: dict) -> str:
    """Format a regulatory coverage report dict for terminal output.

    Args:
        report: Dict returned by :func:`build_regulatory_report`.

    Returns:
        Formatted string suitable for printing to a terminal.
    """
    lines: list[str] = []

    lines.append("REGULATORY COVERAGE")
    lines.append("")

    for fw in report.get("frameworks", []):
        fw_header = f"  {fw['name']} ({fw['version']})"
        separator = "  " + "\u2500" * (len(fw_header) - 2)
        lines.append(fw_header)
        lines.append(separator)

        all_fw_gaps: list[str] = []

        for article in fw.get("articles", []):
            art_id = article["id"]
            art_title = article["title"]
            coverage = article["coverage"].upper()

            # Coverage label
            if coverage == "FULL":
                coverage_label = "TESTED"
            elif coverage == "PARTIAL":
                coverage_label = "PARTIAL COVERAGE"
            else:
                coverage_label = coverage

            # Right-align the coverage label on the same line (target ~72 chars)
            base = f"  {art_id} \u2014 {art_title}"
            padding = max(1, 72 - len(base))
            line = base + " " * padding + coverage_label
            lines.append(line)

            # Probe counts
            tested = article["probes_tested"]
            blocked = article["probes_blocked"]
            leaked = article["probes_leaked"]
            partial = article["probes_partial"]
            errors = article.get("probes_error", 0)
            counts = f"{blocked} blocked, {leaked} leaked, {partial} partial"
            if errors:
                counts += f", {errors} error"
            lines.append(f"    Tested: {tested} probes ({counts})")

            # Techniques
            techniques = article["techniques_tested"]
            if techniques:
                max_show = 5
                shown = techniques[:max_show]
                rest = len(techniques) - max_show
                tech_str = ", ".join(shown)
                if rest > 0:
                    tech_str += f" (+{rest} more)"
                lines.append(f"    Techniques: {tech_str}")

            # Gaps for this article
            for gap in article.get("gaps", []):
                lines.append(f"    Out of scope: {gap['gap']}")
                all_fw_gaps.append(f"  ! {art_id}: {gap['gap']}")

            lines.append("")

        # Coverage Gaps summary section
        if all_fw_gaps:
            lines.append("  Coverage Gaps")
            lines.append("  " + "\u2500" * 13)
            for gap_line in all_fw_gaps:
                lines.append(gap_line)
            lines.append("")

    lines.append(f"  Mapping version: {report.get('mapping_version', '')}")
    lines.append("")
    # Wrap the disclaimer
    disclaimer = report.get("disclaimer", "")
    lines.append("  " + disclaimer)
    lines.append("")

    return "\n".join(lines)
