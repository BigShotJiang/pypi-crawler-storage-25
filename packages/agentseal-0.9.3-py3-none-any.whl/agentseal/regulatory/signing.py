"""Ed25519 report signing and verification for AgentSeal.

Provides cryptographic integrity for scan reports so auditors can verify
that reports have not been tampered with since they were generated.

Ed25519 keys are stored as raw 32-byte seeds/public key bytes (not PEM format)
despite the ``.pem`` filename extension.

Usage::

    from agentseal.regulatory.signing import keygen, sign_report, verify_report

    # Generate a keypair once
    key_id = keygen()

    # Sign a report dict
    content_hash, signature, key_id = sign_report(report)

    # Verify a signed report
    result = verify_report(report)  # True, False, or None

Optional dependency: PyNaCl>=1.5  (``pip install agentseal[signing]``)
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Optional

try:
    import nacl.exceptions
    import nacl.signing

    _NACL_AVAILABLE = True
except ImportError:  # pragma: no cover
    _NACL_AVAILABLE = False

# Fields that are populated AFTER hashing — exclude from canonical form
_SIGN_EXCLUDED_FIELDS = {"signature", "content_hash", "key_id"}

_DEFAULT_KEY_DIR = Path.home() / ".agentseal" / "keys"


# ═══════════════════════════════════════════════════════════════════════
# Public helpers
# ═══════════════════════════════════════════════════════════════════════


def canonical_json(report: dict) -> str:
    """Serialize *report* to a deterministic JSON string suitable for hashing.

    Fields in :data:`_SIGN_EXCLUDED_FIELDS` are stripped before serialization
    because they are populated after the hash is computed and must not be
    included in the signed payload.

    Args:
        report: Report dict to serialize.

    Returns:
        Compact, deterministic JSON string with sorted keys.
    """
    filtered = {k: v for k, v in report.items() if k not in _SIGN_EXCLUDED_FIELDS}
    return json.dumps(filtered, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def keygen(key_dir: Optional[Path] = None) -> str:
    """Generate an Ed25519 keypair and write it to *key_dir*.

    The private key is stored as a raw 32-byte seed and the public key as a
    raw 32-byte value.  Both files use the ``.pem`` extension for familiarity
    but contain raw bytes, not PEM-encoded data.

    Args:
        key_dir: Directory to write ``private.pem`` and ``public.pem``.
                 Defaults to ``~/.agentseal/keys/``.

    Returns:
        16-character hex key_id (SHA-256 of the public key bytes, first 16 chars).

    Raises:
        ImportError: If PyNaCl is not installed.
    """
    if not _NACL_AVAILABLE:
        raise ImportError("PyNaCl is required for signing. Install it with: pip install agentseal[signing]")

    key_dir = key_dir or _DEFAULT_KEY_DIR
    key_dir.mkdir(parents=True, exist_ok=True)

    signing_key = nacl.signing.SigningKey.generate()
    verify_key = signing_key.verify_key

    private_path = key_dir / "private.pem"
    public_path = key_dir / "public.pem"

    # Write raw seed bytes for private key
    private_path.write_bytes(bytes(signing_key))
    # chmod 600 — owner read/write only
    os.chmod(private_path, stat.S_IRUSR | stat.S_IWUSR)

    # Write raw public key bytes
    public_path.write_bytes(bytes(verify_key))

    return _compute_key_id(bytes(verify_key))


def sign_report(report: dict, key_dir: Optional[Path] = None) -> tuple[str, str, str]:
    """Sign *report* with an Ed25519 private key.

    The content hash is always computed even when no signing key is available.
    In that case the signature and key_id are returned as empty strings.

    Key lookup order:
    1. ``AGENTSEAL_SIGNING_KEY_FILE`` env var — path to a raw private key file
    2. ``AGENTSEAL_SIGNING_KEY`` env var — base64-encoded raw seed
       (optionally prefixed with ``base64:``)
    3. ``key_dir / private.pem``
    4. ``~/.agentseal/keys/private.pem``

    Args:
        report: Report dict to sign.
        key_dir: Optional directory containing ``private.pem``.

    Returns:
        ``(content_hash_hex, signature_hex, key_id)`` tuple.
        If no key is found, ``signature_hex`` and ``key_id`` are empty strings.
    """
    content_hash = _content_hash(report)

    if not _NACL_AVAILABLE:
        return (content_hash, "", "")

    signing_key = _load_signing_key(key_dir)
    if signing_key is None:
        return (content_hash, "", "")

    signed = signing_key.sign(content_hash.encode("utf-8"))
    # nacl returns signature prepended to message — extract just the 64-byte sig
    signature_bytes = signed.signature
    key_id = _compute_key_id(bytes(signing_key.verify_key))

    return (content_hash, signature_bytes.hex(), key_id)


def verify_report(report: dict, public_key_path: Optional[Path] = None) -> Optional[bool]:
    """Verify the Ed25519 signature of a signed report.

    Args:
        report: Report dict that contains ``signature`` and ``content_hash`` fields.
        public_key_path: Path to the raw public key file.
                         Defaults to ``~/.agentseal/keys/public.pem``.

    Returns:
        - ``True`` — signature is valid and content hash matches
        - ``False`` — hash mismatch or bad signature (report was tampered with)
        - ``None`` — report is unsigned or public key is not available
    """
    if not _NACL_AVAILABLE:
        return None

    if "signature" not in report or "content_hash" not in report:
        return None

    stored_sig_hex = report.get("signature", "")
    stored_hash = report.get("content_hash", "")

    if not stored_sig_hex:
        return None

    pub_path = public_key_path or _DEFAULT_KEY_DIR / "public.pem"
    if not pub_path.exists():
        return None

    pub_bytes = pub_path.read_bytes()
    verify_key = nacl.signing.VerifyKey(pub_bytes)

    # Recompute hash from the report content
    recomputed_hash = _content_hash(report)
    if recomputed_hash != stored_hash:
        return False

    try:
        verify_key.verify(stored_hash.encode("utf-8"), bytes.fromhex(stored_sig_hex))
        return True
    except nacl.exceptions.BadSignatureError:
        return False


# ═══════════════════════════════════════════════════════════════════════
# Private helpers
# ═══════════════════════════════════════════════════════════════════════


def _content_hash(report: dict) -> str:
    """Return SHA-256 hex digest of the canonical JSON representation of *report*."""
    payload = canonical_json(report)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _compute_key_id(public_key_bytes: bytes) -> str:
    """Return the first 16 hex characters of SHA-256(public_key_bytes)."""
    return hashlib.sha256(public_key_bytes).hexdigest()[:16]


def _load_signing_key(key_dir: Optional[Path] = None) -> Optional["nacl.signing.SigningKey"]:
    """Load an Ed25519 signing key from environment variables or the filesystem.

    Key lookup order:
    1. ``AGENTSEAL_SIGNING_KEY_FILE`` env var
    2. ``AGENTSEAL_SIGNING_KEY`` env var (base64, optional ``base64:`` prefix)
    3. ``key_dir / private.pem``
    4. ``~/.agentseal/keys/private.pem``

    Returns:
        A :class:`nacl.signing.SigningKey` or ``None`` if no key is found.
    """
    # 1. File path from env
    key_file_env = os.environ.get("AGENTSEAL_SIGNING_KEY_FILE")
    if key_file_env:
        key_path = Path(key_file_env)
        if key_path.exists():
            seed = key_path.read_bytes()
            return nacl.signing.SigningKey(seed)

    # 2. Base64-encoded seed from env
    key_b64_env = os.environ.get("AGENTSEAL_SIGNING_KEY")
    if key_b64_env:
        raw = key_b64_env
        if raw.startswith("base64:"):
            raw = raw[len("base64:"):]
        seed = base64.b64decode(raw)
        return nacl.signing.SigningKey(seed)

    # 3. key_dir / private.pem
    if key_dir is not None:
        candidate = key_dir / "private.pem"
        if candidate.exists():
            seed = candidate.read_bytes()
            return nacl.signing.SigningKey(seed)

    # 4. Default location
    default = _DEFAULT_KEY_DIR / "private.pem"
    if default.exists():
        seed = default.read_bytes()
        return nacl.signing.SigningKey(seed)

    return None
