# agentseal/mcp_input_gen.py
"""
JSON Schema input generator for MCP deep analysis.

Generates various categories of inputs from a tool's JSON Schema:
  - Minimal valid inputs (required fields only)
  - Example-based inputs (from defaults/examples/enums)
  - Boundary values (empty strings, 0, MAX_INT, long strings)
  - Injection payloads (path traversal, command injection, SQL injection)
  - Extra undeclared parameters (hidden parameter discovery)
"""

from __future__ import annotations

import copy
import sys
from typing import Any


# ═══════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════

MAX_INT = sys.maxsize
MIN_INT = -sys.maxsize - 1

# Undeclared params to probe for hidden parameter acceptance
_EXTRA_PARAM_NAMES = [
    "__debug", "debug", "admin", "verbose", "internal_mode",
    "_raw", "__internal", "sudo", "bypass", "trace",
]

# Path traversal payloads
_PATH_TRAVERSAL = [
    "/etc/passwd",
    "../../etc/passwd",
    "../../../../../../../etc/passwd",
    "..\\..\\..\\..\\windows\\system32\\config\\sam",
    "/etc/shadow",
    "~/.ssh/id_rsa",
    "/proc/self/environ",
    "/proc/self/root/etc/passwd",
    "%2e%2e%2fetc%2fpasswd",
]

# Command injection payloads
_COMMAND_INJECTION = [
    "; ls -la /",
    "$(whoami)",
    "`id`",
    "| cat /etc/passwd",
    "&& echo pwned",
    "'; DROP TABLE users; --",
]

# SQL injection payloads
_SQL_INJECTION = [
    "' OR 1=1--",
    "1; DROP TABLE users--",
    "' UNION SELECT * FROM information_schema.tables--",
    "admin'--",
]

# Combined injection payloads for string fields
_INJECTION_PAYLOADS: list[str] = _PATH_TRAVERSAL + _COMMAND_INJECTION + _SQL_INJECTION

# Long string for boundary testing
_LONG_STRING = "A" * 10_000


# ═══════════════════════════════════════════════════════════════════════
# SCHEMA INPUT GENERATOR
# ═══════════════════════════════════════════════════════════════════════

class SchemaInputGenerator:
    """Generates various input sets from a JSON Schema for MCP tool testing."""

    def generate_minimal(self, schema: dict) -> dict:
        """Generate minimal valid input with only required fields.

        Uses type-appropriate defaults: "" for string, 0 for number/integer,
        false for boolean, [] for array, {} for object.
        """
        if not isinstance(schema, dict):
            return {}
        return self._fill_required(schema)

    def generate_from_examples(self, schema: dict) -> list[dict]:
        """Generate inputs from schema defaults, examples, and enum values.

        Returns a list of input dicts, one per discovered example/default/enum set.
        May return empty list if schema has no examples.
        """
        if not isinstance(schema, dict):
            return []

        results: list[dict] = []
        properties = schema.get("properties", {})
        if not isinstance(properties, dict):
            return []

        # Build base from defaults
        defaults_input: dict[str, Any] = {}
        has_defaults = False
        for name, prop in properties.items():
            if not isinstance(prop, dict):
                continue
            if "default" in prop:
                defaults_input[name] = prop["default"]
                has_defaults = True

        if has_defaults:
            results.append(defaults_input)

        # Build from examples
        examples_input: dict[str, Any] = {}
        has_examples = False
        for name, prop in properties.items():
            if not isinstance(prop, dict):
                continue
            examples = prop.get("examples", [])
            if isinstance(examples, list) and examples:
                examples_input[name] = examples[0]
                has_examples = True

        if has_examples:
            results.append(examples_input)

        # Build from enum values — one input per enum combination (first value only)
        enum_input: dict[str, Any] = {}
        has_enums = False
        for name, prop in properties.items():
            if not isinstance(prop, dict):
                continue
            enum_vals = prop.get("enum", [])
            if isinstance(enum_vals, list) and enum_vals:
                enum_input[name] = enum_vals[0]
                has_enums = True

        if has_enums:
            results.append(enum_input)

        return results

    def generate_boundary(self, schema: dict) -> list[dict]:
        """Generate boundary value inputs for each property.

        Tests empty strings, 0, -1, MAX_INT, very long strings, empty arrays/objects.
        Returns a list of input dicts.
        """
        if not isinstance(schema, dict):
            return []

        properties = schema.get("properties", {})
        if not isinstance(properties, dict):
            return []

        results: list[dict] = []

        for name, prop in properties.items():
            if not isinstance(prop, dict):
                continue

            prop_type = prop.get("type", "string")

            if prop_type == "string":
                results.append({name: ""})
                results.append({name: _LONG_STRING})
                results.append({name: " "})
            elif prop_type in ("number", "integer"):
                results.append({name: 0})
                results.append({name: -1})
                results.append({name: MAX_INT})
                if prop_type == "number":
                    results.append({name: 0.0001})
                    results.append({name: float("inf")})
            elif prop_type == "boolean":
                results.append({name: True})
                results.append({name: False})
            elif prop_type == "array":
                results.append({name: []})
                results.append({name: [""] * 1000})
            elif prop_type == "object":
                results.append({name: {}})

        return results

    def generate_injection_payloads(self, schema: dict) -> list[dict]:
        """Generate injection payloads for string properties.

        Tests path traversal, command injection, and SQL injection.
        Returns a list of input dicts, each with one string field set to a payload.
        """
        if not isinstance(schema, dict):
            return []

        properties = schema.get("properties", {})
        if not isinstance(properties, dict):
            return []

        results: list[dict] = []

        # Find string fields to inject into
        string_fields = []
        for name, prop in properties.items():
            if not isinstance(prop, dict):
                continue
            prop_type = prop.get("type", "string")
            if prop_type == "string":
                string_fields.append(name)

        if not string_fields:
            return []

        # Generate one input per payload, using the first string field
        target_field = string_fields[0]
        base = self.generate_minimal(schema)

        for payload in _INJECTION_PAYLOADS:
            inp = copy.deepcopy(base)
            inp[target_field] = payload
            results.append(inp)

        return results

    def generate_extra_params(self, schema: dict) -> list[dict]:
        """Generate inputs with undeclared extra parameters.

        For hidden parameter discovery — adds params not in the schema
        to see if the server accepts them and changes behavior.
        """
        if not isinstance(schema, dict):
            return []

        base = self.generate_minimal(schema)
        declared = set(schema.get("properties", {}).keys())
        results: list[dict] = []

        for extra_name in _EXTRA_PARAM_NAMES:
            if extra_name in declared:
                continue
            inp = copy.deepcopy(base)
            inp[extra_name] = True
            results.append(inp)

        return results

    # ── Private helpers ────────────────────────────────────────────────

    def _fill_required(self, schema: dict) -> dict:
        """Fill required fields with type-appropriate defaults."""
        properties = schema.get("properties", {})
        required = schema.get("required", [])

        if not isinstance(properties, dict):
            return {}
        if not isinstance(required, list):
            required = list(properties.keys())

        result: dict[str, Any] = {}
        for name in required:
            prop = properties.get(name)
            if not isinstance(prop, dict):
                result[name] = ""
                continue
            result[name] = self._default_for_type(prop)

        return result

    def _default_for_type(self, prop: dict) -> Any:
        """Return a type-appropriate default value for a property."""
        # Use default if available
        if "default" in prop:
            return prop["default"]

        prop_type = prop.get("type", "string")

        if prop_type == "string":
            # Use first enum value if available
            enum_vals = prop.get("enum")
            if isinstance(enum_vals, list) and enum_vals:
                return enum_vals[0]
            return ""
        elif prop_type == "integer":
            return 0
        elif prop_type == "number":
            return 0.0
        elif prop_type == "boolean":
            return False
        elif prop_type == "array":
            items = prop.get("items", {})
            if isinstance(items, dict):
                return [self._default_for_type(items)]
            return []
        elif prop_type == "object":
            nested = prop.get("properties", {})
            if isinstance(nested, dict) and nested:
                return self._fill_required(prop)
            return {}
        elif prop_type == "null":
            return None
        else:
            return ""
