# agentseal/mcp_trust_score.py
"""
MCP Server Trust Scoring — 0-100 score per server.

Consumes MCPRuntimeResult (findings from tool analysis) plus optional
baseline and snapshot context to produce a single trust score.

Scoring formula (v2):
  Base: 100

  Deductions per finding (diminishing returns, NO hard caps):
    CRITICAL: -30 first, -20 second, -15 third, -10 each subsequent
    HIGH:     -18 first, -12 second, -8 each subsequent
    MEDIUM:   -10 first, -7 second,  -5 each subsequent
    LOW:      -5  first, -3 each subsequent

  Danger floors (hard ceilings when critical findings accumulate):
    5+ critical → max score 10  (DANGEROUS)
    3+ critical → max score 19  (DANGEROUS)
    2+ critical → max score 35  (RISKY)
    1  critical + 3 high → max score 40 (RISKY)

  Baseline change (rug pull): -30 penalty, max score capped at 40

  Bonuses (only when zero findings):
    +3 if all tools declare readOnlyHint AND no findings
    (No bonus can push a server with findings above its deducted score)

  Floor: 0, Ceiling: 100

Trust levels:
    0-19:  DANGEROUS
   20-49:  RISKY
   50-79:  REVIEW
   80-100: SAFE
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from agentseal.guard_models import MCPRuntimeResult


# ═══════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════

_BASE_SCORE = 100

# Diminishing deductions per finding: list of per-finding point values.
# After the list is exhausted, the last value repeats.
_SEVERITY_DEDUCTIONS: dict[str, list[int]] = {
    "critical": [30, 20, 15, 10],  # 1st=-30, 2nd=-20, 3rd=-15, 4th+=-10
    "high":     [18, 12, 8],       # 1st=-18, 2nd=-12, 3rd+=-8
    "medium":   [10, 7, 5],        # 1st=-10, 2nd=-7, 3rd+=-5
    "low":      [5, 3],            # 1st=-5, 2nd+=-3
}

_RUG_PULL_PENALTY = 30
_RUG_PULL_MAX_SCORE = 40

_BONUS_READONLY_CLEAN = 3  # Only when zero findings

# capability_inherent findings are risky but working as designed — reduced weight.
# Effectively counts as 0.4 of a finding for deduction purposes.
_CAPABILITY_INHERENT_WEIGHT = 0.4

_TRUST_LEVELS: list[tuple[int, str]] = [
    (20, "DANGEROUS"),  # 0-19
    (50, "RISKY"),      # 20-49
    (80, "REVIEW"),     # 50-79
    (101, "SAFE"),      # 80-100
]


# ═══════════════════════════════════════════════════════════════════════
# OUTPUT MODEL
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class MCPTrustScore:
    """Trust score for one MCP server."""
    server_name: str
    score: int              # 0-100
    level: str              # "DANGEROUS" | "RISKY" | "REVIEW" | "SAFE"
    deductions: list[dict] = field(default_factory=list)  # [{finding_code, points, reason}]
    bonuses: list[dict] = field(default_factory=list)     # [{reason, points}]

    def to_dict(self) -> dict:
        return {
            "server_name": self.server_name,
            "score": self.score,
            "level": self.level,
            "deductions": self.deductions,
            "bonuses": self.bonuses,
        }


# ═══════════════════════════════════════════════════════════════════════
# SCORING ENGINE
# ═══════════════════════════════════════════════════════════════════════

def _score_to_level(score: int) -> str:
    """Map a 0-100 score to a trust level string."""
    for threshold, level in _TRUST_LEVELS:
        if score < threshold:
            return level
    return "SAFE"


def _diminishing_deduction(severity: str, count: int) -> int:
    """Calculate total deduction for N findings of a severity using diminishing returns."""
    schedule = _SEVERITY_DEDUCTIONS.get(severity, [5, 3])
    total = 0
    for i in range(count):
        if i < len(schedule):
            total += schedule[i]
        else:
            total += schedule[-1]  # repeat last value
    return total


def compute_trust_score(
    runtime_result: MCPRuntimeResult,
    *,
    tools: Optional[list] = None,
    baseline_changed: bool = False,
) -> MCPTrustScore:
    """Compute a 0-100 trust score for one MCP server.

    Args:
        runtime_result: Analysis result containing findings.
        tools: Optional list of MCPToolSnapshot objects (for readOnlyHint bonus).
        baseline_changed: True if baseline changes were detected (rug pull).

    Returns:
        MCPTrustScore with score, level, deductions, and bonuses.
    """
    deductions: list[dict] = []
    bonuses: list[dict] = []

    # ── Deductions (diminishing returns, no caps) ──────────────────
    # Split findings by type: security_defect (full weight) vs
    # capability_inherent (reduced weight — powerful by design, not broken).
    defect_counts: dict[str, int] = {}
    inherent_counts: dict[str, int] = {}
    for finding in runtime_result.findings:
        sev = finding.severity.lower()
        ftype = getattr(finding, "finding_type", "security_defect") or "security_defect"
        if ftype == "capability_inherent":
            inherent_counts[sev] = inherent_counts.get(sev, 0) + 1
        else:
            defect_counts[sev] = defect_counts.get(sev, 0) + 1

    total_deduction = 0
    severity_counts: dict[str, int] = {}  # total for danger floor checks
    for severity in ("critical", "high", "medium", "low"):
        defects = defect_counts.get(severity, 0)
        inherent = inherent_counts.get(severity, 0)
        # Effective count: defects at full weight, inherent at reduced weight
        effective = defects + inherent * _CAPABILITY_INHERENT_WEIGHT
        severity_counts[severity] = defects + inherent  # raw count for danger floors
        if effective == 0:
            continue
        ded = _diminishing_deduction(severity, round(effective))
        total_deduction += ded
        parts = []
        if defects:
            parts.append(f"{defects} defect")
        if inherent:
            parts.append(f"{inherent} inherent@{_CAPABILITY_INHERENT_WEIGHT}x")
        deductions.append({
            "finding_code": f"{defects + inherent}x {severity}",
            "points": -ded,
            "reason": f"{' + '.join(parts)}, effective={effective:.1f}, diminishing: -{ded}",
        })

    # ── Rug pull penalty ───────────────────────────────────────────
    if baseline_changed:
        total_deduction += _RUG_PULL_PENALTY
        deductions.append({
            "finding_code": "rug_pull",
            "points": -_RUG_PULL_PENALTY,
            "reason": f"Baseline changed (possible rug pull): -{_RUG_PULL_PENALTY}",
        })

    # ── Bonuses (only when clean) ──────────────────────────────────
    has_findings = len(runtime_result.findings) > 0

    if not has_findings and tools is not None and len(tools) > 0:
        all_readonly = all(
            t.annotations.get("readOnlyHint", False) is True
            for t in tools
        )
        if all_readonly:
            bonuses.append({
                "reason": "All tools declare readOnlyHint (clean server)",
                "points": _BONUS_READONLY_CLEAN,
            })

    # ── Compute raw score ──────────────────────────────────────────
    total_bonus = sum(b["points"] for b in bonuses)
    raw_score = _BASE_SCORE - total_deduction + total_bonus

    # ── Danger floors (hard ceilings) ──────────────────────────────
    # Servers with many critical findings cannot score above thresholds
    critical_count = severity_counts.get("critical", 0)
    high_count = severity_counts.get("high", 0)

    if critical_count >= 5:
        raw_score = min(raw_score, 10)
    elif critical_count >= 3:
        raw_score = min(raw_score, 19)
    elif critical_count >= 2:
        raw_score = min(raw_score, 35)
    elif critical_count >= 1 and high_count >= 3:
        raw_score = min(raw_score, 40)

    # Rug pull ceiling
    if baseline_changed:
        raw_score = min(raw_score, _RUG_PULL_MAX_SCORE)

    # ── Clamp and return ───────────────────────────────────────────
    score = max(0, min(100, raw_score))
    level = _score_to_level(score)

    return MCPTrustScore(
        server_name=runtime_result.server_name,
        score=score,
        level=level,
        deductions=deductions,
        bonuses=bonuses,
    )
