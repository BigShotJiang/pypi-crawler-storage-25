from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


SEVERITY_ORDER: dict[str, int] = {"critical": 0, "high": 1, "medium": 2, "low": 3}


@dataclass
class MCPServerConfig:
    name: str
    command: str
    args: list[str]
    env: dict[str, str] = field(default_factory=dict)
    source_file: Path | None = None
    transport: str = "stdio"
    url: str | None = None
    package_id: str | None = None
    agents: list[str] = field(default_factory=list)

    @property
    def dedup_key(self) -> tuple[str, tuple[str, ...]]:
        return (self.command, tuple(self.args))


@dataclass
class SkillPath:
    path: Path
    platform: str
    format: str


@dataclass
class CollectedAgent:
    name: str
    agent_type: str
    config_path: Path
    mcp_servers: list[MCPServerConfig]
    skills: list[SkillPath]
    status: str


@dataclass
class Finding:
    code: str
    title: str
    description: str
    severity: str
    source: str | None
    server_name: str
    agent_names: list[str]
    evidence: str
    remediation: str
    confidence: float = 1.0

    def to_dict(self) -> dict:
        d = {
            "code": self.code,
            "title": self.title,
            "description": self.description,
            "severity": self.severity,
            "source": self.source,
            "server_name": self.server_name,
            "agent_names": self.agent_names,
            "evidence": self.evidence,
            "remediation": self.remediation,
        }
        if self.confidence < 1.0:
            d["confidence"] = round(self.confidence, 2)
        return d


@dataclass
class RegistryData:
    trust_score: float
    findings: list[Finding]
    capability_labels: set[str]
    analyzed_version: str | None
    analyzed_at: str | None
    tools: list[str]


@dataclass
class MatchResult:
    server: MCPServerConfig
    registry_hit: RegistryData | None
    needs_runtime: bool
    version_gap: str | None
    analysis_method: str = "static"  # registry, static, runtime, llm


@dataclass
class GuardScanResult:
    agents: list[CollectedAgent]
    match_results: list[MatchResult]
    findings: list[Finding]
    machine_score: float
    servers_scanned: int
    from_registry: int
    failed: int
    scan_duration_seconds: float
    deep_analysis: dict | None = None

    @property
    def severity_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for f in self.findings:
            if f.severity in counts:
                counts[f.severity] += 1
        return counts

    @property
    def has_critical(self) -> bool:
        return any(f.severity == "critical" for f in self.findings)

    @property
    def sorted_findings(self) -> list[Finding]:
        return sorted(self.findings, key=lambda f: SEVERITY_ORDER.get(f.severity, 99))

    def to_dict(self) -> dict:
        d = {
            "agents": [
                {
                    "name": a.name,
                    "agent_type": a.agent_type,
                    "config_path": str(a.config_path),
                    "status": a.status,
                }
                for a in self.agents
            ],
            "match_results": [
                {
                    "server_name": mr.server.name,
                    "needs_runtime": mr.needs_runtime,
                    "version_gap": mr.version_gap,
                    "registry_hit": mr.registry_hit is not None,
                    "analysis_method": mr.analysis_method,
                }
                for mr in self.match_results
            ],
            "findings": [f.to_dict() for f in self.findings],
            "machine_score": self.machine_score,
            "servers_scanned": self.servers_scanned,
            "from_registry": self.from_registry,
            "failed": self.failed,
            "scan_duration_seconds": self.scan_duration_seconds,
            "severity_counts": self.severity_counts,
        }
        if self.deep_analysis:
            d["deep_analysis"] = self.deep_analysis
        return d

    def to_report_data(self) -> dict:
        """Transform into the format the dashboard backend expects.

        Maps our flat findings list into the nested structure that
        guard_parser.py and _extract_counts() read:
        mcp_results, skill_results, agents_found, toxic_flows, baseline_changes.
        """
        mcp_results: dict[str, dict] = {}
        skill_results: dict[str, dict] = {}
        toxic_flows: list[dict] = []
        baseline_changes: list[dict] = []
        method_by_server = {mr.server.name: mr.analysis_method for mr in self.match_results}

        for f in self.findings:
            fd = {"severity": f.severity, "title": f.title, "description": f.description,
                  "code": f.code, "evidence": f.evidence, "remediation": f.remediation}

            if f.code.startswith(("FLOW-", "XFLOW-")):
                servers = f.server_name.split(", ") if f.server_name else []
                toxic_flows.append({
                    "risk_level": "high" if f.severity in ("critical", "high") else "medium",
                    "risk_type": f.code,
                    "title": f.title,
                    "description": f.description,
                    "servers_involved": servers,
                    "remediation": f.remediation,
                })
            elif f.code.startswith("BASE-"):
                baseline_changes.append({
                    "server_name": f.server_name or "",
                    "change_type": {
                        "BASE-001": "tools_changed",
                        "BASE-002": "tools_added",
                        "BASE-003": "tools_removed",
                        "BASE-004": "config_changed",
                    }.get(f.code, "config_changed"),
                    "detail": f.description,
                    "description": f.description,
                })
            elif f.code.startswith("SKILL-"):
                sname = f.server_name or "unknown"
                if sname not in skill_results:
                    skill_results[sname] = {"name": sname, "findings": []}
                skill_results[sname]["findings"].append(fd)
            elif f.code.startswith(("CONF-", "MCPR-")):
                sname = f.server_name or "unknown"
                if sname not in mcp_results:
                    mcp_results[sname] = {
                        "server_name": sname, "name": sname,
                        "findings": [], "tools": [],
                        "analysis_method": method_by_server.get(sname, "static"),
                    }
                mcp_results[sname]["findings"].append(fd)

        # Add ALL discovered skills as inventory items (even clean ones)
        for agent in self.agents:
            for skill in agent.skills:
                sname = skill.path.name
                if sname not in skill_results:
                    skill_results[sname] = {
                        "name": sname,
                        "skill_name": sname,
                        "path": str(skill.path),
                        "platform": skill.platform,
                        "format": skill.format,
                        "findings": [],
                    }

        agents_found = [
            {
                "name": a.name,
                "agent_name": a.name,
                "agent_type": a.agent_type,
                "config_path": str(a.config_path),
                "mcp_servers": len(a.mcp_servers),
                "mcp_server_names": [s.name for s in a.mcp_servers],
                "skills_count": len(a.skills),
                "status": a.status,
            }
            for a in self.agents
        ]

        report = {
            "duration_seconds": self.scan_duration_seconds,
            "machine_score": self.machine_score,
            "agents_found": agents_found,
            "mcp_results": list(mcp_results.values()),
            "skill_results": list(skill_results.values()),
            "mcp_runtime_results": [],
            "toxic_flows": toxic_flows,
            "baseline_changes": baseline_changes,
            "summary": self.severity_counts,
        }
        deep_findings = [f.to_dict() for f in self.findings if f.code.startswith("DEEP-")]
        if self.deep_analysis or deep_findings:
            report["deep_analysis"] = {
                **(self.deep_analysis or {}),
                "findings": deep_findings,
            }
        return report
