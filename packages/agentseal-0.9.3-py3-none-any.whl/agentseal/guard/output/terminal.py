from __future__ import annotations

from agentseal.guard.models import GuardScanResult

_RED = "\033[91m"
_YELLOW = "\033[93m"
_GREEN = "\033[92m"
_CYAN = "\033[96m"
_DIM = "\033[90m"
_BOLD = "\033[1m"
_RESET = "\033[0m"

_SEV_COLOR = {
    "critical": _RED,
    "high": _RED,
    "medium": _YELLOW,
    "low": _DIM,
}


def _score_color(score: float) -> str:
    if score >= 80:
        return _GREEN
    if score >= 50:
        return _YELLOW
    return _RED


def format_terminal(result: GuardScanResult) -> str:
    lines: list[str] = []

    lines.append(f"\n{_BOLD}{_CYAN}AgentSeal Guard{_RESET}")
    lines.append(f"{_DIM}{'─' * 50}{_RESET}\n")

    lines.append(f"{_BOLD}Agents detected:{_RESET}")
    for agent in result.agents:
        srv_count = len(agent.mcp_servers)
        skill_count = len(agent.skills)
        lines.append(
            f"  {_CYAN}{agent.name}{_RESET} "
            f"{_DIM}({srv_count} server{'s' if srv_count != 1 else ''}, "
            f"{skill_count} skill{'s' if skill_count != 1 else ''}){_RESET}"
        )
    if not result.agents:
        lines.append(f"  {_DIM}none{_RESET}")
    lines.append("")

    _METHOD_LABEL = {
        "registry": f"{_GREEN}REGISTRY{_RESET}",
        "static": f"{_YELLOW}STATIC{_RESET}",
        "runtime": f"{_CYAN}RUNTIME{_RESET}",
        "llm": f"{_CYAN}LLM{_RESET}",
    }

    lines.append(f"{_BOLD}MCP Servers ({result.servers_scanned}):{_RESET}")
    for mr in result.match_results:
        label = _METHOD_LABEL.get(mr.analysis_method, _DIM + "UNKNOWN" + _RESET)
        score = ""
        if mr.registry_hit:
            sc = mr.registry_hit.trust_score
            score = f" {_score_color(sc)}{int(sc)}/100{_RESET}"
        agents_str = ", ".join(mr.server.agents) if mr.server.agents else ""
        lines.append(
            f"  {label:>20}  {_BOLD}{mr.server.name}{_RESET}{score}"
            f"  {_DIM}{agents_str}{_RESET}"
        )
    if not result.match_results:
        lines.append(f"  {_DIM}none{_RESET}")
    lines.append(f"  {_DIM}From registry: {result.from_registry} · Failed: {result.failed}{_RESET}")
    lines.append("")

    regular = [f for f in result.sorted_findings if not f.code.startswith("DEEP-")]
    deep = [f for f in result.sorted_findings if f.code.startswith("DEEP-")]

    lines.append(f"{_BOLD}Findings ({len(regular)}):{_RESET}")
    if regular:
        for f in regular:
            color = _SEV_COLOR.get(f.severity, _RESET)
            lines.append(
                f"  {color}{f.severity.upper():8}{_RESET}  "
                f"{_BOLD}{f.code}{_RESET}  {f.title}"
            )
    else:
        lines.append(f"  {_GREEN}No findings{_RESET}")
    lines.append("")

    score = result.machine_score
    color = _score_color(score)
    lines.append(f"{_BOLD}Trust Score:{_RESET} {color}{_BOLD}{int(score)}/100{_RESET}")
    lines.append("")

    remediations = [f.remediation for f in regular if f.remediation][:5]
    if remediations:
        lines.append(f"{_BOLD}Top remediations:{_RESET}")
        for i, r in enumerate(remediations, 1):
            lines.append(f"  {i}. {r}")
        lines.append("")

    dur = result.scan_duration_seconds
    lines.append(f"{_DIM}Scan completed in {dur:.2f}s{_RESET}\n")

    if deep:
        model_name = ""
        if result.deep_analysis and result.deep_analysis.get("model_used"):
            model_name = result.deep_analysis["model_used"]

        header = f"{_BOLD}{_CYAN}Deep Analysis{_RESET}"
        if model_name:
            header += f"  {_DIM}({model_name}){_RESET}"
        lines.append(header)
        lines.append(f"{_DIM}{'─' * 50}{_RESET}\n")

        for f in deep:
            color = _SEV_COLOR.get(f.severity, _RESET)
            lines.append(
                f"  {color}{f.severity.upper():8}{_RESET}  "
                f"{_BOLD}{f.code}{_RESET}  {f.title}"
            )
            if f.description:
                for desc_line in f.description.splitlines():
                    lines.append(f"    {_DIM}{desc_line}{_RESET}")
        lines.append("")

    return "\n".join(lines)
