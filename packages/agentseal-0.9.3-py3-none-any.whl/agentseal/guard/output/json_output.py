from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.models import GuardScanResult


class _PathEncoder(json.JSONEncoder):
    def default(self, o: object) -> object:
        if isinstance(o, Path):
            return str(o)
        return super().default(o)


def format_json(result: GuardScanResult) -> str:
    return json.dumps(result.to_dict(), indent=2, cls=_PathEncoder)
