from __future__ import annotations

from agentseal.guard.models import Finding, GuardScanResult

_SARIF_SCHEMA = (
    "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json"
)

_LEVEL_MAP: dict[str, str] = {
    "critical": "error",
    "high": "error",
    "medium": "warning",
    "low": "note",
}


def format_sarif(result: GuardScanResult) -> dict:
    rule_ids: list[str] = []
    rule_index_map: dict[str, int] = {}
    for f in result.findings:
        if f.code not in rule_index_map:
            rule_index_map[f.code] = len(rule_ids)
            rule_ids.append(f.code)

    rules = [
        {
            "id": code,
            "name": code.replace("-", ""),
            "shortDescription": {"text": code},
        }
        for code in rule_ids
    ]

    sarif_results = []
    for f in result.findings:
        entry: dict = {
            "ruleId": f.code,
            "ruleIndex": rule_index_map[f.code],
            "level": _LEVEL_MAP.get(f.severity, "note"),
            "message": {"text": f"{f.title}: {f.description}"},
            "fingerprints": {"evidence/v1": f.evidence},
        }
        sarif_results.append(entry)

    return {
        "$schema": _SARIF_SCHEMA,
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "AgentSeal Guard",
                        "informationUri": "https://agentseal.org",
                        "rules": rules,
                    }
                },
                "results": sarif_results,
            }
        ],
    }
