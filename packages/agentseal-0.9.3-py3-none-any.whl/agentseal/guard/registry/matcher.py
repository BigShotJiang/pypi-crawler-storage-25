from __future__ import annotations

from agentseal.guard.models import MCPServerConfig


def extract_package_id(server: MCPServerConfig) -> str | None:
    cmd = server.command
    args = server.args

    for arg in args:
        if "github.com" in arg or arg.startswith("github:"):
            return f"github:{arg}"

    if cmd in ("npx", "npx.cmd"):
        return _npx_package(args)
    if cmd == "uvx":
        return _first_non_flag(args, prefix="pypi")
    if cmd == "pipx":
        return _pipx_package(args)
    if cmd in ("python", "python3"):
        return _python_m_package(args)
    if cmd == "docker":
        return _docker_package(args)

    return None


def _npx_package(args: list[str]) -> str | None:
    for arg in args:
        if arg.startswith("-"):
            continue
        return f"npm:{arg}"
    return None


def _first_non_flag(args: list[str], prefix: str) -> str | None:
    skip_next = False
    for arg in args:
        if skip_next:
            skip_next = False
            continue
        if arg.startswith("-"):
            if "=" not in arg:
                skip_next = True
            continue
        return f"{prefix}:{arg}"
    return None


def _pipx_package(args: list[str]) -> str | None:
    skip_run = True
    for arg in args:
        if arg.startswith("-"):
            continue
        if skip_run and arg == "run":
            skip_run = False
            continue
        return f"pypi:{arg}"
    return None


def _python_m_package(args: list[str]) -> str | None:
    try:
        idx = args.index("-m")
        if idx + 1 < len(args):
            return f"pypi:{args[idx + 1]}"
    except ValueError:
        pass
    return None


def _docker_package(args: list[str]) -> str | None:
    try:
        run_idx = args.index("run")
    except ValueError:
        return None
    for arg in args[run_idx + 1:]:
        if arg.startswith("-"):
            continue
        return f"docker:{arg}"
    return None
