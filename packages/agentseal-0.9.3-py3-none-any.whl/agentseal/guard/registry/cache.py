from __future__ import annotations

import json
import logging
import time
from pathlib import Path

import httpx

from agentseal.guard.models import RegistryData

logger = logging.getLogger(__name__)

_STALE_SECONDS = 86400
_CACHE_URL = "https://agentseal.org/api/v1/mcp/guard-cache"


def _dedupe_entries(matches: dict[str, dict]) -> list[dict]:
    """Deduplicate registry entries that are the same server (npm + git mirrors).

    Groups by trust_score (within tolerance of 5 points) — entries with similar
    scores are considered the same server published to multiple registries.
    Returns one per group, preferring npm entries.
    """
    if not matches:
        return []
    groups: list[list[tuple[str, dict]]] = []
    for key, entry in matches.items():
        score = entry.get("trust_score", -1)
        placed = False
        for group in groups:
            ref_score = group[0][1].get("trust_score", -1)
            if abs(score - ref_score) <= 5:
                group.append((key, entry))
                placed = True
                break
        if not placed:
            groups.append([(key, entry)])
    result: list[dict] = []
    for group in groups:
        npm = next((e for k, e in group if k.startswith("npm:")), None)
        result.append(npm or group[0][1])
    return result


class RegistryCache:
    def __init__(self, path: Path | None = None, base_url: str | None = None) -> None:
        self.path = path or Path.home() / ".agentseal" / "registry_cache.json"
        self._cache_url = (base_url.rstrip("/") + "/api/v1/mcp/guard-cache") if base_url else _CACHE_URL
        self._data: dict | None = None

    def _load(self) -> dict:
        if self._data is not None:
            return self._data
        if not self.path.exists():
            return {}
        try:
            self._data = json.loads(self.path.read_text())
        except (json.JSONDecodeError, OSError):
            self._data = {}
        return self._data

    def is_stale(self) -> bool:
        data = self._load()
        if not data or "fetched_at" not in data:
            return True
        return (time.time() - data["fetched_at"]) > _STALE_SECONDS

    def server_count(self) -> int:
        data = self._load()
        return len(data.get("servers", {}))

    def fetch_remote(self) -> int:
        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.get(self._cache_url)
                resp.raise_for_status()
                servers = resp.json()
            self.update(servers)
            return len(servers)
        except Exception as e:
            logger.warning("Failed to fetch registry cache: %s", e)
            return 0

    def ensure_fresh(self) -> None:
        if self.is_stale():
            count = self.fetch_remote()
            if count:
                logger.info("Registry cache updated: %d servers", count)

    def lookup(self, package_id: str | None) -> RegistryData | None:
        if not package_id:
            return None
        data = self._load()
        servers = data.get("servers", {})
        entry = servers.get(package_id)
        if entry is None:
            entry = self._fuzzy_lookup(package_id, servers)
        if entry is None:
            return None
        return RegistryData(
            trust_score=entry["trust_score"],
            findings=entry.get("findings", []),
            capability_labels=set(entry.get("capability_labels", [])),
            analyzed_version=entry.get("analyzed_version"),
            analyzed_at=entry.get("analyzed_at"),
            tools=entry.get("tools", []),
        )

    @staticmethod
    def _fuzzy_lookup(package_id: str, servers: dict) -> dict | None:
        prefix, _, name = package_id.partition(":")
        if not name:
            return None
        short = name.rsplit("/", 1)[-1]
        core = short
        for strip in ("mcp-server-", "server-", "mcp-"):
            if core.startswith(strip):
                core = core[len(strip):]
                break
        candidates = {short, core, f"server-{core}", f"mcp-{core}", f"mcp-server-{core}"}

        # Collect all matches — only return if exactly one unique server
        matches: dict[str, dict] = {}
        for suffix in candidates:
            for key, entry in servers.items():
                key_tail = key.rsplit("/", 1)[-1].split(":")[-1]
                if key_tail == suffix:
                    matches[key] = entry

        unique = _dedupe_entries(matches)
        if len(unique) == 1:
            return unique[0]

        # Prefix match: "agentseal" matches "agentseal-mcp-intel"
        if len(core) >= 5:
            prefix_matches: dict[str, dict] = {}
            for key, entry in servers.items():
                key_tail = key.rsplit("/", 1)[-1].split(":")[-1]
                if key_tail.startswith(f"{core}-") or key_tail.startswith(f"{core}_"):
                    prefix_matches[key] = entry
            unique = _dedupe_entries(prefix_matches)
            if len(unique) == 1:
                return unique[0]

        return None

    def update(self, data: dict) -> None:
        payload = {
            "fetched_at": time.time(),
            "servers": data,
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(payload))
        self._data = payload
