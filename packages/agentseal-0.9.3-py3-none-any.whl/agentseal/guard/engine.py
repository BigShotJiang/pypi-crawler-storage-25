from __future__ import annotations

import hashlib
import logging
import time
from pathlib import Path

from agentseal.guard.models import (
    CollectedAgent,
    Finding,
    GuardScanResult,
    MCPServerConfig,
    MatchResult,
    SEVERITY_ORDER,
)
from agentseal.guard.collectors.base import collect_all
from agentseal.guard.registry.matcher import extract_package_id
from agentseal.guard.registry.cache import RegistryCache
from agentseal.guard.analyzers.pattern import PatternAnalyzer
from agentseal.guard.analyzers.toxic_flow import ToxicFlowAnalyzer
from agentseal.guard.analyzers.baseline import BaselineAnalyzer
from agentseal.guard.analyzers.skill_code import SkillCodeAnalyzer
from agentseal.guard.analyzers.skill_content import SkillContentAnalyzer
from agentseal.guard.analyzers.skill_semantic import SkillSemanticAnalyzer
from agentseal.guard.analyzers.xflow import CrossArtifactFlowAnalyzer
from agentseal.guard.scoring import compute_machine_score

logger = logging.getLogger(__name__)

try:
    from agentseal.mcp_tool_analyzer import MCPToolAnalyzer
    from agentseal.mcp_runtime import MCPToolSnapshot
    _HAS_RUNTIME_ANALYZER = True
except ImportError:
    _HAS_RUNTIME_ANALYZER = False


class GuardEngine:
    def __init__(
        self,
        *,
        skip_runtime: bool = False,
        deep: bool = False,
        deep_all: bool = False,
        deep_timeout: float = 60.0,
        model: str | None = None,
        api_key: str | None = None,
        baseline_path: Path | None = None,
        cache_path: Path | None = None,
        project_path: Path | None = None,
        no_process_scan: bool = False,
        interactive: bool = False,
    ) -> None:
        self._skip_runtime = skip_runtime
        self._deep = deep
        self._deep_all = deep_all
        self._deep_timeout = deep_timeout
        self._model = model
        self._api_key = api_key
        self._baseline_path = baseline_path
        self._cache_path = cache_path
        self._project_path = project_path
        self._no_process_scan = no_process_scan
        self._interactive = interactive

    async def run(self) -> GuardScanResult:
        started = time.monotonic()

        agents = collect_all()

        if self._project_path:
            from agentseal.guard.collectors.project import ProjectMCPCollector
            agents.extend(ProjectMCPCollector(self._project_path).collect())

        if not self._no_process_scan:
            from agentseal.guard.collectors.process import ProcessMCPCollector
            known = {(s.command, tuple(s.args)) for a in agents for s in a.mcp_servers}
            proc_collector = ProcessMCPCollector()
            proc_collector.known_commands = known
            agents.extend(proc_collector.collect())

        servers = self._deduplicate_servers(agents)
        all_skills = [skill for agent in agents for skill in agent.skills]

        registry = RegistryCache(self._cache_path)
        registry.ensure_fresh()
        match_results: list[MatchResult] = []
        for server in servers:
            package_id = extract_package_id(server)
            registry_hit = registry.lookup(package_id) if package_id else None
            if registry_hit is None and server.name:
                registry_hit = registry.lookup(f"npm:{server.name}")
            needs_runtime = registry_hit is None
            match_results.append(MatchResult(
                server=server,
                registry_hit=registry_hit,
                needs_runtime=needs_runtime,
                version_gap=None,
                analysis_method="registry" if registry_hit else "static",
            ))

        findings: list[Finding] = []
        findings.extend(PatternAnalyzer().analyze(agents=agents))

        if all_skills:
            findings.extend(SkillCodeAnalyzer().analyze(skills=all_skills))
            findings.extend(SkillContentAnalyzer().analyze(skills=all_skills))
            findings.extend(SkillSemanticAnalyzer().analyze(skills=all_skills))

            from agentseal.guard.skill_parser import compute_skill_confidence, parse_skill_file
            source_contents = {str(s.path): parse_skill_file(s) or "" for s in all_skills}
            findings = compute_skill_confidence(findings, "", source_contents=source_contents)

        findings.extend(ToxicFlowAnalyzer().analyze(agents=agents, match_results=match_results))
        findings.extend(CrossArtifactFlowAnalyzer().analyze(
            agents=agents, match_results=match_results, findings=findings,
        ))

        servers_failed = 0
        tool_hashes: dict[str, dict[str, tuple[str, str]]] = {}

        if not self._skip_runtime:
            _analyzer = MCPToolAnalyzer() if _HAS_RUNTIME_ANALYZER else None

            for mr in match_results:
                if not mr.needs_runtime:
                    continue
                raw = await self._scan_server(mr.server)
                if raw is None:
                    servers_failed += 1
                    logger.info("Connection failed for server %s", mr.server.name)
                    continue
                mr.analysis_method = "runtime"
                server_tools: dict[str, tuple[str, str]] = {}
                raw_tools = raw.get("tools", [])
                all_tool_names: set[str] = {t.get("name", "") for t in raw_tools}
                for tool in raw_tools:
                    name = tool.get("name", "")
                    desc = tool.get("description", "")
                    schema = str(tool.get("input_schema", {}))
                    desc_hash = hashlib.sha512(desc.encode()).hexdigest()
                    schema_hash = hashlib.sha512(schema.encode()).hexdigest()
                    server_tools[name] = (desc_hash, schema_hash)
                if server_tools:
                    tool_hashes[mr.server.name] = server_tools

                if _analyzer is not None:
                    for tool_dict in raw_tools:
                        tool_snap = MCPToolSnapshot(
                            name=tool_dict.get("name", ""),
                            description=tool_dict.get("description", ""),
                            input_schema=tool_dict.get("input_schema", {}),
                            annotations=tool_dict.get("annotations", {}),
                            signature_hash=tool_dict.get("signature_hash", ""),
                        )
                        for mf in _analyzer.analyze_tool(tool_snap, mr.server.name, all_tool_names):
                            findings.append(Finding(
                                code=mf.code,
                                title=mf.title,
                                description=mf.description,
                                severity=mf.severity,
                                source="runtime",
                                server_name=mf.server_name,
                                agent_names=list(mr.server.agents),
                                evidence=mf.evidence[:200],
                                remediation=mf.remediation,
                            ))

            for mr in match_results:
                if mr.registry_hit is None:
                    continue
                server_tools = {}
                for tool in mr.registry_hit.tools:
                    if isinstance(tool, dict):
                        name = tool.get("name", "")
                        desc = tool.get("description", "")
                        schema = str(tool.get("input_schema", {}))
                        desc_hash = hashlib.sha512(desc.encode()).hexdigest()
                        schema_hash = hashlib.sha512(schema.encode()).hexdigest()
                        server_tools[name] = (desc_hash, schema_hash)
                    elif isinstance(tool, str):
                        server_tools[tool] = ("", "")
                if server_tools:
                    tool_hashes.setdefault(mr.server.name, server_tools)

            if tool_hashes:
                findings.extend(
                    BaselineAnalyzer(self._baseline_path).analyze(tool_hashes=tool_hashes)
                )

        unmatched_count = sum(1 for mr in match_results if mr.analysis_method == "static")
        if unmatched_count > 0 and not self._deep:
            if self._interactive and self._model:
                import sys
                unmatched_names = [mr.server.name for mr in match_results if mr.analysis_method == "static"]
                print(
                    f"\n\033[93m{unmatched_count} server{'s' if unmatched_count != 1 else ''} "
                    f"not in registry: {', '.join(unmatched_names)}\033[0m",
                    file=sys.stderr,
                )
                try:
                    answer = input(f"\033[93mRun LLM deep analysis with {self._model}? [y/N] \033[0m").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    answer = "n"
                if answer in ("y", "yes"):
                    self._deep = True
            elif not self._skip_runtime:
                import sys
                print(
                    f"\033[93m{unmatched_count} server{'s' if unmatched_count != 1 else ''} "
                    f"not in registry. Run with --deep --model <model> for LLM analysis.\033[0m",
                    file=sys.stderr,
                )

        deep_meta: dict | None = None
        if self._deep:
            import sys

            drift_servers: set[str] = set()
            for f in findings:
                if f.code.startswith("BASE-"):
                    drift_servers.add(f.server_name)

            from agentseal.guard.analyzers.active_probe import ActiveProbeRunner, should_probe
            probe_runner = ActiveProbeRunner(timeout=self._deep_timeout)
            probed = 0
            for mr in match_results:
                if not should_probe(mr, drift_servers=drift_servers, deep_all=self._deep_all):
                    continue
                print(f"\033[90m  Probing {mr.server.name}...\033[0m", file=sys.stderr)
                probe_findings = await probe_runner.probe_server(mr.server)
                findings.extend(probe_findings)
                mr.analysis_method = "llm"
                probed += 1

            model_name = self._model
            if not model_name:
                from agentseal.guard.llm_client import detect_ollama_model
                model_name = await detect_ollama_model()
                if model_name:
                    model_name = f"ollama:{model_name}"

            if model_name:
                from agentseal.guard.llm_client import resolve_client
                from agentseal.guard.analyzers.deep_reasoning import DeepReasoningAnalyzer

                print(f"\033[90m  Running LLM analysis ({model_name})...\033[0m", file=sys.stderr)

                temp_result = GuardScanResult(
                    agents=agents, match_results=match_results,
                    findings=[f for f in findings if not f.code.startswith("DEEP-")],
                    machine_score=0, servers_scanned=len(servers),
                    from_registry=sum(1 for mr in match_results if mr.registry_hit is not None),
                    failed=servers_failed, scan_duration_seconds=0,
                )

                try:
                    llm_client = resolve_client(model_name, api_key=self._api_key)
                    analyzer = DeepReasoningAnalyzer(llm_client, model_name)
                    deep_findings = await analyzer.analyze(temp_result)
                    findings.extend(deep_findings)
                    deep_meta = {"model_used": model_name, "probed_servers": probed}

                    skill_findings = [f for f in findings if f.code.startswith("SKILL-")]
                    if skill_findings and all_skills:
                        from agentseal.guard.analyzers.skill_llm import SkillLLMAnalyzer
                        print(f"\033[90m  Reviewing {len(skill_findings)} skill findings with LLM...\033[0m", file=sys.stderr)
                        findings = await SkillLLMAnalyzer(llm_client, model_name).review_findings(
                            all_skills, findings,
                        )
                except ValueError as e:
                    print(f"\033[93m⚠ LLM setup failed: {e}\033[0m", file=sys.stderr)
            else:
                print("\033[93m⚠ --deep: no --model specified and Ollama not detected. Skipping LLM analysis.\033[0m", file=sys.stderr)

        machine_score = compute_machine_score(
            match_results=match_results,
            findings=findings,
        )

        return GuardScanResult(
            agents=agents,
            match_results=match_results,
            findings=findings,
            machine_score=machine_score,
            servers_scanned=len(servers),
            from_registry=sum(1 for mr in match_results if mr.registry_hit is not None),
            failed=servers_failed,
            scan_duration_seconds=time.monotonic() - started,
            deep_analysis=deep_meta,
        )

    def _deduplicate_servers(self, agents: list[CollectedAgent]) -> list[MCPServerConfig]:
        seen: dict[tuple, MCPServerConfig] = {}
        for agent in agents:
            for server in agent.mcp_servers:
                key = server.dedup_key
                if key in seen:
                    if agent.agent_type not in seen[key].agents:
                        seen[key].agents.append(agent.agent_type)
                else:
                    seen[key] = server
        return list(seen.values())

    async def _scan_server(self, server: MCPServerConfig) -> dict | None:
        try:
            from agentseal.mcp_runtime import scan_server, MCPConnectionError  # type: ignore[import]
            config: dict = {
                "name": server.name,
                "command": server.command,
                "args": server.args,
                "env": server.env,
            }
            if server.url:
                config["url"] = server.url
            result = await scan_server(config, timeout=30.0)
            if isinstance(result, MCPConnectionError):
                return None
            return result.to_dict()
        except Exception:
            return None

    @staticmethod
    def ci_exit_code(result: GuardScanResult, fail_on: str = "high") -> int:
        threshold = SEVERITY_ORDER.get(fail_on, 99)
        for finding in result.findings:
            if SEVERITY_ORDER.get(finding.severity, 99) <= threshold:
                return 1
        return 0
