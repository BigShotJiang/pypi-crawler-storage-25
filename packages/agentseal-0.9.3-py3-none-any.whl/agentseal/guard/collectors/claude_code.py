from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent, SkillPath


class ClaudeCodeCollector(AgentCollector):
    name = "claude-code"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        for directory in [
            Path("~/.claude/commands").expanduser(),
            Path(".claude/commands"),
        ]:
            if directory.exists():
                for f in directory.glob("*.md"):
                    skills.append(SkillPath(path=f, platform=self.name, format="markdown"))
        return skills

    def config_paths(self) -> list[Path]:
        home = Path.home()
        return [
            home / ".claude.json",
            Path(".mcp.json"),
            home / ".claude" / "settings.json",
        ]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        mcp_servers = []
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            try:
                config = json.loads(path.read_text())
                if "mcpServers" in config:
                    agent = _parse_mcp_object(config, path, "Claude Code", self.name)
                    mcp_servers = agent.mcp_servers
                    break
            except Exception:
                pass

        # Report agent if config exists OR skills exist
        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Claude Code",
            agent_type=self.name,
            config_path=config_path or Path("~/.claude").expanduser(),
            mcp_servers=mcp_servers,
            skills=skills,
            status="found",
        )]
