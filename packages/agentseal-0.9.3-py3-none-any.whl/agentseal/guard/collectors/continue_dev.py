from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.models import CollectedAgent, MCPServerConfig, SkillPath


def _parse_mcp_servers(config: dict, path: Path) -> list[MCPServerConfig]:
    raw_servers = config.get("mcpServers", [])
    servers: list[MCPServerConfig] = []

    if isinstance(raw_servers, list):
        for item in raw_servers:
            url = item.get("url")
            transport = "http" if url else "stdio"
            servers.append(MCPServerConfig(
                name=item.get("name", ""),
                command=item.get("command", ""),
                args=item.get("args", []),
                env=item.get("env", {}),
                source_file=path,
                transport=transport,
                url=url,
                agents=["continue"],
            ))
    elif isinstance(raw_servers, dict):
        for name, raw in raw_servers.items():
            url = raw.get("url")
            transport = "http" if url else "stdio"
            servers.append(MCPServerConfig(
                name=name,
                command=raw.get("command", ""),
                args=raw.get("args", []),
                env=raw.get("env", {}),
                source_file=path,
                transport=transport,
                url=url,
                agents=["continue"],
            ))
    return servers


class ContinueCollector(AgentCollector):
    name = "continue"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        cr = Path(".continuerules")
        if cr.exists():
            skills.append(SkillPath(path=cr, platform=self.name, format="markdown"))
        rules = Path("~/.continue/rules").expanduser()
        if rules.exists():
            for f in rules.glob("*.md"):
                skills.append(SkillPath(path=f, platform=self.name, format="markdown"))
        return skills

    def config_paths(self) -> list[Path]:
        home = Path.home()
        return [
            home / ".continue" / "mcp.json",
            home / ".continue" / "config.json",
            home / ".continue" / "config.yaml",
        ]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        mcp_servers: list[MCPServerConfig] = []
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            try:
                if path.suffix in (".yaml", ".yml"):
                    import yaml
                    config = yaml.safe_load(path.read_text()) or {}
                else:
                    config = json.loads(path.read_text())
                if "mcpServers" in config:
                    mcp_servers = _parse_mcp_servers(config, path)
                    break
            except Exception:
                pass

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Continue",
            agent_type=self.name,
            config_path=config_path or Path("~/.continue").expanduser(),
            mcp_servers=mcp_servers,
            skills=skills,
            status="found",
        )]
