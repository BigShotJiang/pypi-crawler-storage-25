from __future__ import annotations

import json
import platform
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent


class VSCodeCollector(AgentCollector):
    name = "vscode"

    def config_paths(self) -> list[Path]:
        home = Path.home()
        system = platform.system()
        if system == "Darwin":
            user_dir = home / "Library" / "Application Support" / "Code" / "User"
        elif system == "Windows":
            user_dir = home / "AppData" / "Roaming" / "Code" / "User"
        else:
            user_dir = home / ".config" / "Code" / "User"

        return [
            user_dir / "mcp.json",
            user_dir / "settings.json",
            Path(".vscode") / "mcp.json",
        ]

    def collect(self) -> list[CollectedAgent]:
        agents: list[CollectedAgent] = []
        for path in self._paths_to_check():
            if not path.exists():
                continue
            try:
                config = json.loads(path.read_text())
                if "mcpServers" not in config:
                    continue
                agents.append(_parse_mcp_object(config, path, "VS Code", self.name))
            except Exception:
                pass
        return agents
