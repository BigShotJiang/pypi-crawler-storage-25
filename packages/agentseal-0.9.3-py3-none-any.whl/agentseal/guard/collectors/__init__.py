from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path

_pkg_path = str(Path(__file__).parent)
_pkg_name = __name__

for _mod_info in pkgutil.iter_modules([_pkg_path]):
    if _mod_info.name != "base":
        importlib.import_module(f"{_pkg_name}.{_mod_info.name}")
