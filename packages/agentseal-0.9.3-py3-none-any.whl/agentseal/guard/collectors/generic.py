from __future__ import annotations

import json
import platform
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent, MCPServerConfig

_SKIP_DIRS = {
    "claude", "code", "cursor", "cline", "continue", "windsurf",
    "codeium", "zed", "codex", ".claude", "gemini",
    "saoudrizwan.claude-dev",
}

_MCP_FILENAMES = {"mcp.json", "mcp_config.json", "mcp_settings.json"}
_GENERIC_FILENAMES = {"config.json", "settings.json"}


class GenericMCPCollector(AgentCollector):
    name = "generic"

    def _get_config_dirs(self) -> list[Path]:
        override = getattr(self, "_override_config_dirs", None)
        if override is not None:
            return override

        home = Path.home()
        dirs = [home / ".config"]
        if platform.system() == "Darwin":
            dirs.append(home / "Library" / "Application Support")
        return dirs

    def config_paths(self) -> list[Path]:
        return []

    def collect(self) -> list[CollectedAgent]:
        agents: list[CollectedAgent] = []

        for config_dir in self._get_config_dirs():
            if not config_dir.is_dir():
                continue
            for app_dir in sorted(config_dir.iterdir()):
                if not app_dir.is_dir():
                    continue
                if app_dir.name.lower() in _SKIP_DIRS:
                    continue

                for filename in _MCP_FILENAMES | _GENERIC_FILENAMES:
                    cfg_path = app_dir / filename
                    if not cfg_path.exists():
                        continue
                    try:
                        config = json.loads(cfg_path.read_text())
                    except Exception:
                        continue

                    if "mcpServers" in config:
                        agent = _parse_mcp_object(
                            config, cfg_path, app_dir.name, "generic",
                        )
                        agents.append(agent)
                        break
                    elif "context_servers" in config:
                        servers = self._parse_context_servers(config, cfg_path)
                        agents.append(CollectedAgent(
                            name=app_dir.name,
                            agent_type="generic",
                            config_path=cfg_path,
                            mcp_servers=servers,
                            skills=[],
                            status="found",
                        ))
                        break

        return agents

    @staticmethod
    def _parse_context_servers(
        config: dict, cfg_path: Path,
    ) -> list[MCPServerConfig]:
        servers: list[MCPServerConfig] = []
        for name, raw in config.get("context_servers", {}).items():
            cmd_block = raw.get("command", {})
            url = raw.get("url")
            transport = "http" if url else "stdio"
            servers.append(MCPServerConfig(
                name=name,
                command=cmd_block.get("path", ""),
                args=cmd_block.get("args", []),
                env=cmd_block.get("env", {}),
                source_file=cfg_path,
                transport=transport,
                url=url,
                agents=["generic"],
            ))
        return servers
