from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.models import CollectedAgent, SkillPath


class PiCodeCollector(AgentCollector):
    name = "pi-code"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        extensions = Path("~/.pi/agent/extensions").expanduser()
        if extensions.exists():
            for f in extensions.iterdir():
                if f.suffix in (".ts", ".js", ".py"):
                    skills.append(SkillPath(path=f, platform=self.name, format=f.suffix.lstrip(".")))
        guides = Path("~/.pi/agent/guides").expanduser()
        if guides.exists():
            for f in guides.glob("*.md"):
                skills.append(SkillPath(path=f, platform=self.name, format="markdown"))
        return skills

    def config_paths(self) -> list[Path]:
        return [Path("~/.pi/agent/settings.json").expanduser()]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            break

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Pi Code",
            agent_type=self.name,
            config_path=config_path or Path("~/.pi/agent").expanduser(),
            mcp_servers=[],
            skills=skills,
            status="found",
        )]
