from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent, SkillPath


class CursorCollector(AgentCollector):
    name = "cursor"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        for path in [
            Path("~/.cursor/.cursorrules").expanduser(),
            Path(".cursorrules"),
        ]:
            if path.exists():
                skills.append(SkillPath(path=path, platform=self.name, format="mdc"))
        rules_dir = Path(".cursor/rules")
        if rules_dir.exists():
            for f in rules_dir.glob("*.mdc"):
                skills.append(SkillPath(path=f, platform=self.name, format="mdc"))
        return skills

    def config_paths(self) -> list[Path]:
        home = Path.home()
        return [
            home / ".cursor" / "mcp.json",
            Path(".cursor") / "mcp.json",
        ]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        mcp_servers = []
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            try:
                config = json.loads(path.read_text())
                if "mcpServers" in config:
                    agent = _parse_mcp_object(config, path, "Cursor", self.name)
                    mcp_servers = agent.mcp_servers
                    break
            except Exception:
                pass

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Cursor",
            agent_type=self.name,
            config_path=config_path or Path("~/.cursor").expanduser(),
            mcp_servers=mcp_servers,
            skills=skills,
            status="found",
        )]
