from __future__ import annotations

import json
import platform
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.models import CollectedAgent, MCPServerConfig, SkillPath


class ZedCollector(AgentCollector):
    name = "zed"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        rules = Path(".zed/rules")
        if rules.exists():
            for f in rules.glob("*.md"):
                skills.append(SkillPath(path=f, platform=self.name, format="markdown"))
        return skills

    def config_paths(self) -> list[Path]:
        if platform.system() == "Windows":
            return []
        return [Path.home() / ".config" / "zed" / "settings.json"]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        mcp_servers: list[MCPServerConfig] = []
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            try:
                config = json.loads(path.read_text())
                context_servers = config.get("context_servers", {})
                if context_servers:
                    for name, raw in context_servers.items():
                        cmd_block = raw.get("command", {})
                        url = raw.get("url")
                        transport = "http" if url else "stdio"
                        mcp_servers.append(MCPServerConfig(
                            name=name,
                            command=cmd_block.get("path", ""),
                            args=cmd_block.get("args", []),
                            env=cmd_block.get("env", {}),
                            source_file=path,
                            transport=transport,
                            url=url,
                            agents=["zed"],
                        ))
                    break
            except Exception:
                pass

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Zed",
            agent_type=self.name,
            config_path=config_path or Path("~/.config/zed").expanduser(),
            mcp_servers=mcp_servers,
            skills=skills,
            status="found",
        )]
