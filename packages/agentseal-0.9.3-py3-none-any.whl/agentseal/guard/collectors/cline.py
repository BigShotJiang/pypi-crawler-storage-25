from __future__ import annotations

import json
import platform
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent, SkillPath

_CLINE_REL = Path("globalStorage") / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json"


class ClineCollector(AgentCollector):
    name = "cline"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        for p in [Path(".clinerules"), Path(".cline/rules")]:
            if p.is_file():
                skills.append(SkillPath(path=p, platform=self.name, format="markdown"))
            elif p.is_dir():
                for f in p.glob("*.md"):
                    skills.append(SkillPath(path=f, platform=self.name, format="markdown"))
        return skills

    def config_paths(self) -> list[Path]:
        home = Path.home()
        system = platform.system()
        if system == "Darwin":
            user_dir = home / "Library" / "Application Support" / "Code" / "User"
        elif system == "Windows":
            user_dir = home / "AppData" / "Roaming" / "Code" / "User"
        else:
            user_dir = home / ".config" / "Code" / "User"
        return [user_dir / _CLINE_REL]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        mcp_servers = []
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            try:
                config = json.loads(path.read_text())
                if "mcpServers" in config:
                    agent = _parse_mcp_object(config, path, "Cline", self.name)
                    mcp_servers = agent.mcp_servers
                    break
            except Exception:
                pass

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Cline",
            agent_type=self.name,
            config_path=config_path or Path("."),
            mcp_servers=mcp_servers,
            skills=skills,
            status="found",
        )]
