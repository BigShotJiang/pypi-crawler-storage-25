from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent, SkillPath


class GeminiCollector(AgentCollector):
    name = "gemini-cli"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        gemini_md = Path("GEMINI.md")
        if gemini_md.exists():
            skills.append(SkillPath(path=gemini_md, platform=self.name, format="markdown"))
        return skills

    def config_paths(self) -> list[Path]:
        return [Path("~/.gemini/settings.json").expanduser()]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        mcp_servers = []
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            try:
                config = json.loads(path.read_text())
                if "mcpServers" in config:
                    agent = _parse_mcp_object(config, path, "Gemini CLI", self.name)
                    mcp_servers = agent.mcp_servers
                    break
            except Exception:
                pass

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Gemini CLI",
            agent_type=self.name,
            config_path=config_path or Path("~/.gemini").expanduser(),
            mcp_servers=mcp_servers,
            skills=skills,
            status="found",
        )]
