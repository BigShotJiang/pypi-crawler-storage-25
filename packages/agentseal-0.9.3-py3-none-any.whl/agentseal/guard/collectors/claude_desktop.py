from __future__ import annotations

import json
import platform
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.models import CollectedAgent, MCPServerConfig


def _parse_mcp_object(
    config: dict,
    config_path: Path,
    agent_name: str,
    agent_type: str,
) -> CollectedAgent:
    servers: list[MCPServerConfig] = []
    for name, raw in config.get("mcpServers", {}).items():
        url = raw.get("url")
        transport = "http" if url else "stdio"
        servers.append(MCPServerConfig(
            name=name,
            command=raw.get("command", ""),
            args=raw.get("args", []),
            env=raw.get("env", {}),
            source_file=config_path,
            transport=transport,
            url=url,
            agents=[agent_type],
        ))
    return CollectedAgent(
        name=agent_name,
        agent_type=agent_type,
        config_path=config_path,
        mcp_servers=servers,
        skills=[],
        status="found",
    )


class ClaudeDesktopCollector(AgentCollector):
    name = "claude-desktop"

    def config_paths(self) -> list[Path]:
        system = platform.system()
        if system == "Darwin":
            return [Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"]
        if system == "Windows":
            return [Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json"]
        return [Path.home() / ".config" / "claude" / "claude_desktop_config.json"]

    def collect(self) -> list[CollectedAgent]:
        agents: list[CollectedAgent] = []
        for path in self._paths_to_check():
            if not path.exists():
                continue
            try:
                config = json.loads(path.read_text())
                agents.append(_parse_mcp_object(config, path, "Claude Desktop", self.name))
            except Exception:
                pass
        return agents
