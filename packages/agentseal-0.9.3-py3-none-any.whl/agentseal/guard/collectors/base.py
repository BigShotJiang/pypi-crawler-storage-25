from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path

from agentseal.guard.models import CollectedAgent

logger = logging.getLogger(__name__)

COLLECTORS: list[type[AgentCollector]] = []


class AgentCollector(ABC):
    name: str

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if hasattr(cls, "name"):
            COLLECTORS.append(cls)

    @abstractmethod
    def config_paths(self) -> list[Path]:
        ...

    @abstractmethod
    def collect(self) -> list[CollectedAgent]:
        ...

    def _paths_to_check(self) -> list[Path]:
        override = getattr(self, "_override_paths", None)
        if override is not None:
            return override
        return self.config_paths()


def collect_all() -> list[CollectedAgent]:
    import agentseal.guard.collectors  # noqa: F401 — triggers auto-import

    agents: list[CollectedAgent] = []
    for cls in COLLECTORS:
        try:
            agents.extend(cls().collect())
        except Exception:
            logger.exception("Collector %s failed", cls.name)
    return agents
