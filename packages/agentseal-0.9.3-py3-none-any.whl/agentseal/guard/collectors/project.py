from __future__ import annotations

import json
import logging
from pathlib import Path

from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent

logger = logging.getLogger(__name__)

_SKIP_DIRS = frozenset({
    "node_modules", ".git", "dist", "build", "__pycache__",
    ".venv", "venv", ".tox", ".next", "target",
})

_MCP_FILENAMES = frozenset({".mcp.json", "mcp.json"})

_MAX_DEPTH = 5


class ProjectMCPCollector:
    def __init__(self, project_path: Path) -> None:
        self._root = project_path

    def collect(self) -> list[CollectedAgent]:
        if not self._root.is_dir():
            return []

        agents: list[CollectedAgent] = []
        for mcp_path in self._walk(self._root, depth=0):
            try:
                config = json.loads(mcp_path.read_text())
            except Exception:
                logger.debug("Failed to parse %s", mcp_path)
                continue
            dir_name = mcp_path.parent.name
            agent = _parse_mcp_object(
                config, mcp_path, f"project ({dir_name})", "project",
            )
            agents.append(agent)
        return agents

    def _walk(self, directory: Path, depth: int) -> list[Path]:
        if depth >= _MAX_DEPTH:
            return []

        found: list[Path] = []
        try:
            entries = sorted(directory.iterdir())
        except PermissionError:
            return found

        for entry in entries:
            if entry.is_file() and entry.name in _MCP_FILENAMES:
                found.append(entry)
            elif entry.is_dir() and entry.name not in _SKIP_DIRS:
                found.extend(self._walk(entry, depth + 1))
        return found
