from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent, SkillPath


class WindsurfCollector(AgentCollector):
    name = "windsurf"

    def discover_skills(self) -> list[SkillPath]:
        wr = Path(".windsurfrules")
        if wr.exists():
            return [SkillPath(path=wr, platform=self.name, format="markdown")]
        return []

    def config_paths(self) -> list[Path]:
        return [Path.home() / ".codeium" / "windsurf" / "mcp_config.json"]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        mcp_servers = []
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            try:
                config = json.loads(path.read_text())
                if "mcpServers" in config:
                    agent = _parse_mcp_object(config, path, "Windsurf", self.name)
                    mcp_servers = agent.mcp_servers
                    break
            except Exception:
                pass

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Windsurf",
            agent_type=self.name,
            config_path=config_path or Path("."),
            mcp_servers=mcp_servers,
            skills=skills,
            status="found",
        )]
