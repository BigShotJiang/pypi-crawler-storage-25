from __future__ import annotations

import logging
import platform
import re
import subprocess
from pathlib import Path

from agentseal.guard.models import CollectedAgent, MCPServerConfig

logger = logging.getLogger(__name__)

_MCP_PATTERNS = [
    re.compile(r"mcp[_-]server", re.I),
    re.compile(r"@modelcontextprotocol/", re.I),
    re.compile(r"@anthropic/mcp-", re.I),
    re.compile(r"--stdio.*mcp|mcp.*--stdio", re.I),
]

_PARENT_MAP: dict[str, str] = {
    "claude": "Claude Desktop",
    "claude_desktop": "Claude Desktop",
    "cursor": "Cursor",
    "code": "VS Code",
}

_LAUNCHERS = frozenset({"npm", "npx", "pnpm", "yarn", "bun", "bunx"})

_LAUNCHER_SUBCOMMANDS = frozenset({"exec", "dlx", "x", "run"})

_NODE_MODULES_SCOPED_RE = re.compile(r"node_modules/(@[^/]+/[^/]+)")
_NODE_MODULES_UNSCOPED_RE = re.compile(r"node_modules/([^/.@][^/]*)")


def _extract_package_name(command: str, args: list[str]) -> str | None:
    if command in _LAUNCHERS:
        for arg in args:
            if arg.startswith("-"):
                continue
            if arg in _LAUNCHER_SUBCOMMANDS:
                continue
            if arg.startswith("@") or arg[0:1].isalpha():
                return arg
        return None

    if command == "node" and args:
        path = args[0]
        m = _NODE_MODULES_SCOPED_RE.search(path)
        if m:
            return m.group(1)
        m = _NODE_MODULES_UNSCOPED_RE.search(path)
        if m:
            return m.group(1)

    return None


def _parse_ps_line(line: str) -> tuple[int, int, str, str] | None:
    parts = line.split(None, 2)
    if len(parts) < 3:
        return None
    try:
        pid = int(parts[0])
        ppid = int(parts[1])
    except ValueError:
        return None
    rest = parts[2]
    tokens = rest.split(None, 1)
    command = tokens[0].rsplit("/", 1)[-1]
    args = tokens[1] if len(tokens) > 1 else ""
    return pid, ppid, command, args


def _identify_parent(parent_name: str) -> str:
    if not parent_name:
        return "running process (unknown)"
    key = parent_name.lower()
    if key in _PARENT_MAP:
        return _PARENT_MAP[key]
    return f"running process ({parent_name})"


class ProcessMCPCollector:
    known_commands: set[tuple[str, tuple[str, ...]]] | None = None

    def collect(self) -> list[CollectedAgent]:
        output = self._run_ps()
        if not output:
            return []

        candidates: list[tuple[int, int, str, list[str], str]] = []
        for line in output.splitlines():
            parsed = _parse_ps_line(line)
            if parsed is None:
                continue

            pid, ppid, command, args_str = parsed
            full_cmd = f"{command} {args_str}"

            if not any(p.search(full_cmd) for p in _MCP_PATTERNS):
                continue

            arg_list = args_str.split() if args_str else []
            dedup_key = (command, tuple(arg_list))
            if self.known_commands is not None and dedup_key in self.known_commands:
                continue

            parent_name = self._get_process_name(ppid)
            agent_name = _identify_parent(parent_name)
            candidates.append((pid, ppid, command, arg_list, agent_name))

        collected_pids = {c[0] for c in candidates}
        parents_to_discard: set[int] = set()
        child_inheritance: dict[int, str | None] = {}

        for pid, ppid, command, args, _ in candidates:
            if ppid in collected_pids and command not in _LAUNCHERS:
                parent = next((c for c in candidates if c[0] == ppid), None)
                if parent and parent[2] in _LAUNCHERS:
                    parents_to_discard.add(ppid)
                    pkg = _extract_package_name(parent[2], parent[3])
                    if pkg:
                        child_inheritance[pid] = pkg

        agents: list[CollectedAgent] = []
        for pid, ppid, command, arg_list, agent_name in candidates:
            if pid in parents_to_discard:
                continue

            config_path = Path(f"/proc/{pid}") if Path("/proc").exists() else Path("/dev/null")

            pkg = child_inheritance.get(pid) or _extract_package_name(command, arg_list)
            name = pkg if pkg else command

            server = MCPServerConfig(
                name=name,
                command=command,
                args=arg_list,
                source_file=config_path,
                agents=["process"],
                package_id=pkg,
            )
            agents.append(CollectedAgent(
                name=agent_name,
                agent_type="process",
                config_path=config_path,
                mcp_servers=[server],
                skills=[],
                status="running",
            ))

        return agents

    def _run_ps(self) -> str:
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["powershell", "-Command",
                     "Get-Process | Select-Object Id, @{N='ParentId';E={(Get-CimInstance Win32_Process -Filter \"ProcessId=$($_.Id)\").ParentProcessId}}, CommandLine | Format-Table -AutoSize"],
                    capture_output=True, text=True, timeout=10,
                )
            else:
                result = subprocess.run(
                    ["ps", "-eo", "pid,ppid,command", "-ww"],
                    capture_output=True, text=True, timeout=10,
                )
            return result.stdout if result.returncode == 0 else ""
        except Exception:
            logger.exception("Failed to run ps")
            return ""

    def _get_process_name(self, pid: int) -> str:
        try:
            result = subprocess.run(
                ["ps", "-p", str(pid), "-o", "comm="],
                capture_output=True, text=True, timeout=5,
            )
            name = result.stdout.strip()
            return name.rsplit("/", 1)[-1] if name else ""
        except Exception:
            return ""
