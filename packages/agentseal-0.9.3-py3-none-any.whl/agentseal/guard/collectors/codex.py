from __future__ import annotations

import json
from pathlib import Path

from agentseal.guard.collectors.base import AgentCollector
from agentseal.guard.collectors.claude_desktop import _parse_mcp_object
from agentseal.guard.models import CollectedAgent, MCPServerConfig, SkillPath


class CodexCollector(AgentCollector):
    name = "codex"

    def discover_skills(self) -> list[SkillPath]:
        skills: list[SkillPath] = []
        for directory in [
            Path("~/.codex/skills").expanduser(),
            Path(".codex/skills"),
        ]:
            if directory.exists():
                for f in directory.iterdir():
                    if f.suffix in (".md", ".py", ".js", ".ts"):
                        skills.append(SkillPath(path=f, platform=self.name, format=f.suffix.lstrip(".")))
        agents_md = Path("AGENTS.md")
        if agents_md.exists():
            skills.append(SkillPath(path=agents_md, platform=self.name, format="markdown"))
        return skills

    def config_paths(self) -> list[Path]:
        return [
            Path("~/.codex/config.json").expanduser(),
            Path("~/.codex/auth.json").expanduser(),
        ]

    def collect(self) -> list[CollectedAgent]:
        skills = self.discover_skills()
        config_path = None

        for path in self._paths_to_check():
            if not path.exists():
                continue
            config_path = path
            break

        if config_path is None and not skills:
            return []

        return [CollectedAgent(
            name="Codex CLI",
            agent_type=self.name,
            config_path=config_path or Path("~/.codex").expanduser(),
            mcp_servers=[],
            skills=skills,
            status="found",
        )]
