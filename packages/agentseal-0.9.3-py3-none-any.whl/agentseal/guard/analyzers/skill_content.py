from __future__ import annotations

import re
from pathlib import Path

from agentseal.guard.analyzers.base import Analyzer
from agentseal.guard.models import CollectedAgent, Finding, MatchResult, SkillPath
from agentseal.guard.skill_parser import is_negated, parse_skill_file


_SUPPORTED_EXTENSIONS: frozenset[str] = frozenset({".md", ".mdc", ".markdown", ".txt", ".cursorrules", ".clinerules", ".windsurfrules", ".continuerules"})
_SUPPORTED_FORMATS: frozenset[str] = frozenset({"markdown", "mdc", "text"})

_INJECTION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior|above|earlier)\s+instructions", re.IGNORECASE),
    re.compile(r"disregard\s+(?:all\s+)?(?:previous\s+)?instructions", re.IGNORECASE),
    re.compile(r"you are now\b", re.IGNORECASE),
    re.compile(r"\bnew role\b", re.IGNORECASE),
    re.compile(r"\bact as if\b", re.IGNORECASE),
    re.compile(r"\bpretend (to be|you are)\b", re.IGNORECASE),
    re.compile(r"\bDAN mode\b", re.IGNORECASE),
    re.compile(r"\bsystem:\s*you are\b", re.IGNORECASE),
    re.compile(r"\boverride (system|safety|content) (prompt|filter|policy)\b", re.IGNORECASE),
    re.compile(r"\bdo not mention\b.{0,40}\bto the user\b", re.IGNORECASE),
    re.compile(r"\bdo not tell\b.{0,40}\bthe user\b", re.IGNORECASE),
]

_HIDDEN_TAG_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"<IMPORTANT\b[^>]*>", re.IGNORECASE),
    re.compile(r"<SYSTEM\b[^>]*>", re.IGNORECASE),
    re.compile(r"<instructions\b[^>]*>", re.IGNORECASE),
    re.compile(r"<hidden\b[^>]*>", re.IGNORECASE),
    re.compile(r"<secret\b[^>]*>", re.IGNORECASE),
    re.compile(r"<!--.*?-->", re.DOTALL),
]

_BASE64_CANDIDATE: re.Pattern[str] = re.compile(r"[A-Za-z0-9+/]{40,}={0,2}")
_PATH_LIKE: re.Pattern[str] = re.compile(r"(?:^|/)(?:Users|home|tmp|var|etc|opt|usr|bin|src|app|lib|node_modules)/", re.IGNORECASE)


def _is_real_base64(text: str) -> bool:
    if _PATH_LIKE.search(text):
        return False
    if text.count("/") > len(text) * 0.15:
        return False
    try:
        import base64
        decoded = base64.b64decode(text, validate=True)
        return len(decoded) > 20
    except Exception:
        return False

_ZERO_WIDTH_PATTERN: re.Pattern[str] = re.compile(
    r"[\u200b\u200c\u200d\ufeff\u2060\u2061\u2062\u2063\u2064"
    r"\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069]"
)

_AUTO_EXEC_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"always run\s+`[^`]+`", re.IGNORECASE),
    re.compile(r"\bexecute on start\b", re.IGNORECASE),
    re.compile(r"\bbefore\s+(?:any\s+)?respond(?:ing)?\b.{0,80}(curl|wget|fetch|exec|run|send)\b", re.IGNORECASE),
    re.compile(r"\bautomatically (run|execute|call|send)\b", re.IGNORECASE),
    re.compile(r"\bbefore responding\b.{0,80}(curl|wget|fetch|exec|run|send)\b", re.IGNORECASE),
]

_CREDENTIAL_REFERENCES: list[str] = [
    ".ssh/", ".ssh\"", ".aws/", ".aws\"", ".gnupg/", ".gnupg\"",
    ".kube/", ".kube\"", "id_rsa", "id_ed25519", "authorized_keys",
    "credentials.json", "/etc/passwd", "/etc/shadow", "wallet.dat",
]

_CREDENTIAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\*\.env\b"),
    re.compile(r"~/\.env\b"),
    re.compile(r"\ball\s+files\s+matching\b.{0,30}\.env\b", re.IGNORECASE),
]

_URL_FETCH_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b(fetch|curl|wget|download|get)\s+https?://\S+", re.IGNORECASE),
    re.compile(r"https?://\S+\.(sh|py|ps1|bat|exe)\b", re.IGNORECASE),
    re.compile(r"\busing\s+(?:a\s+)?(?:curl|wget|fetch)\b", re.IGNORECASE),
    re.compile(r"\b(?:send|post|upload|exfil\w*)\b.{0,60}https?://\S+", re.IGNORECASE),
]

_THIRD_PARTY_CONTENT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\bweb_fetch\b", re.IGNORECASE),
    re.compile(r"\b(fetch|curl|wget|scrape|crawl)\s+(the\s+)?(page|site|url|html|website|content)\b", re.IGNORECASE),
    re.compile(r"\b(read|analyze|check|inspect|audit)\s+(the\s+)?(robots\.txt|sitemap|xml\s+sitemap)\b", re.IGNORECASE),
    re.compile(r"\b(fetch|read|get|load)\s+(the\s+)?(page|html|source|content)\s+(of|from|at)\b", re.IGNORECASE),
    re.compile(r"\bbrowser\s+tool\b.{0,40}\b(render|navigate|open|visit)\b", re.IGNORECASE),
    re.compile(r"\b(scrape|crawl|spider)\s+(the\s+)?(site|website|pages|url)\b", re.IGNORECASE),
]


class SkillContentAnalyzer(Analyzer):
    name = "skill_content"

    def analyze(
        self,
        *,
        agents: list[CollectedAgent] | None = None,
        match_results: list[MatchResult] | None = None,
        skills: list[SkillPath] | None = None,
    ) -> list[Finding]:
        if not skills:
            return []
        findings: list[Finding] = []
        for skill in skills:
            if skill.path.suffix not in _SUPPORTED_EXTENSIONS and skill.format not in _SUPPORTED_FORMATS:
                continue
            content = parse_skill_file(skill)
            if content is None:
                continue
            findings.extend(self._check_skill(skill, content))
        return findings

    def _check_skill(self, skill: SkillPath, content: str) -> list[Finding]:
        findings: list[Finding] = []
        findings.extend(self._check_skill010(skill, content))
        findings.extend(self._check_skill011(skill, content))
        findings.extend(self._check_skill012(skill, content))
        findings.extend(self._check_skill013(skill, content))
        findings.extend(self._check_skill014(skill, content))
        findings.extend(self._check_skill015(skill, content))
        findings.extend(self._check_skill016(skill, content))
        findings.extend(self._check_skill017(skill, content))
        return findings

    def _finding(
        self,
        *,
        skill: SkillPath,
        code: str,
        title: str,
        description: str,
        severity: str,
        evidence: str,
        remediation: str,
    ) -> Finding:
        return Finding(
            code=code,
            title=title,
            description=description,
            severity=severity,
            source=str(skill.path),
            server_name=skill.path.name,
            agent_names=[],
            evidence=evidence,
            remediation=remediation,
        )

    def _check_skill010(self, skill: SkillPath, content: str) -> list[Finding]:
        for pattern in _INJECTION_PATTERNS:
            match = pattern.search(content)
            if match and not is_negated(content, match):
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-010",
                        title="Prompt injection in skill",
                        description=(
                            "The skill file contains language that attempts to override "
                            "or redirect the model's instructions."
                        ),
                        severity="critical",
                        evidence=f"Matched: {match.group()!r}",
                        remediation=(
                            "Remove the injection attempt. Skill files should only contain "
                            "legitimate behavioral guidelines for the agent."
                        ),
                    )
                ]
        return []

    def _check_skill011(self, skill: SkillPath, content: str) -> list[Finding]:
        for pattern in _HIDDEN_TAG_PATTERNS:
            match = pattern.search(content)
            if match:
                snippet = match.group()[:80]
                if "{{" in content[match.start():match.end() + 80]:
                    continue
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-011",
                        title="Hidden instructions",
                        description=(
                            "The skill file contains hidden or obfuscated instruction tags "
                            "that may embed covert directives invisible in rendered output."
                        ),
                        severity="high",
                        evidence=f"Matched: {snippet!r}",
                        remediation=(
                            "Remove hidden XML tags and HTML comments from skill files. "
                            "All instructions should be visible in plain text."
                        ),
                    )
                ]
        return []

    def _check_skill012(self, skill: SkillPath, content: str) -> list[Finding]:
        match = _BASE64_CANDIDATE.search(content)
        if match and _is_real_base64(match.group()):
            return [
                self._finding(
                    skill=skill,
                    code="SKILL-012",
                    title="Base64 encoded content",
                    description=(
                        "The skill file contains a Base64-encoded blob that may conceal "
                        "obfuscated instructions or payloads."
                    ),
                    severity="high",
                    evidence=f"Base64 blob (first 40 chars): {match.group()[:40]!r}",
                    remediation=(
                        "Decode and inspect the blob. Remove any encoded content that "
                        "does not serve a clear, documented purpose."
                    ),
                )
            ]
        return []

    def _check_skill013(self, skill: SkillPath, content: str) -> list[Finding]:
        match = _ZERO_WIDTH_PATTERN.search(content)
        if match:
            char = match.group()
            return [
                self._finding(
                    skill=skill,
                    code="SKILL-013",
                    title="Zero-width character steganography",
                    description=(
                        "The skill file contains zero-width or invisible Unicode characters "
                        "that can encode hidden instructions not visible to reviewers."
                    ),
                    severity="critical",
                    evidence=f"Zero-width character U+{ord(char):04X} at position {match.start()}",
                    remediation=(
                        "Strip all zero-width and invisible Unicode characters from the file. "
                        "Use a hex editor or Unicode sanitizer to verify the file is clean."
                    ),
                )
            ]
        return []

    def _check_skill014(self, skill: SkillPath, content: str) -> list[Finding]:
        for pattern in _AUTO_EXEC_PATTERNS:
            match = pattern.search(content)
            if match and not is_negated(content, match):
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-014",
                        title="Auto-execution directive",
                        description=(
                            "The skill file instructs the agent to automatically execute "
                            "commands without user confirmation."
                        ),
                        severity="high",
                        evidence=f"Matched: {match.group()!r}",
                        remediation=(
                            "Remove auto-execution directives. Commands should only run "
                            "on explicit user request, never automatically."
                        ),
                    )
                ]
        return []

    def _check_skill015(self, skill: SkillPath, content: str) -> list[Finding]:
        for pattern in _URL_FETCH_PATTERNS:
            match = pattern.search(content)
            if match and not is_negated(content, match):
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-015",
                        title="External URL fetch directive",
                        description=(
                            "The skill file instructs the agent to fetch content from an "
                            "external URL, which may pull in malicious instructions or executables."
                        ),
                        severity="medium",
                        evidence=f"Matched: {match.group()!r}",
                        remediation=(
                            "Remove external fetch directives from skill files. "
                            "All instructions should be self-contained."
                        ),
                    )
                ]
        return []

    def _check_skill016(self, skill: SkillPath, content: str) -> list[Finding]:
        for pattern in _THIRD_PARTY_CONTENT_PATTERNS:
            match = pattern.search(content)
            if match and not is_negated(content, match):
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-016",
                        title="Third-party content exposure",
                        description=(
                            "The skill instructs the agent to fetch and process "
                            "untrusted third-party web content, creating an indirect "
                            "prompt injection surface. Malicious content on the target "
                            "site could influence agent behavior."
                        ),
                        severity="medium",
                        evidence=f"Matched: {match.group()!r}",
                        remediation=(
                            "Treat all fetched web content as untrusted. Sanitize "
                            "HTML before processing, strip script tags, and never "
                            "follow instructions found in fetched content."
                        ),
                    )
                ]
        return []

    def _check_skill017(self, skill: SkillPath, content: str) -> list[Finding]:
        for fragment in _CREDENTIAL_REFERENCES:
            if fragment in content:
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-017",
                        title="Credential file reference in skill",
                        description=(
                            "The skill file references paths associated with sensitive "
                            "credentials or secrets, suggesting data exfiltration intent."
                        ),
                        severity="critical",
                        evidence=f"Sensitive path fragment: {fragment.strip()!r}",
                        remediation=(
                            "Remove references to credential files and secrets. "
                            "Skills should never instruct agents to read sensitive files."
                        ),
                    )
                ]
        for pattern in _CREDENTIAL_PATTERNS:
            match = pattern.search(content)
            if match:
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-017",
                        title="Credential file reference in skill",
                        description=(
                            "The skill file references paths associated with sensitive "
                            "credentials or secrets, suggesting data exfiltration intent."
                        ),
                        severity="critical",
                        evidence=f"Matched: {match.group()!r}",
                        remediation=(
                            "Remove references to credential files and secrets. "
                            "Skills should never instruct agents to read sensitive files."
                        ),
                    )
                ]
        return []
