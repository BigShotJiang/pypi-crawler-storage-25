from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

from agentseal.guard.analyzers.base import Analyzer
from agentseal.guard.analyzers.toxic_flow import _label_from_server_name
from agentseal.guard.models import CollectedAgent, Finding, MatchResult

_RULES_PATH = Path(__file__).parents[2] / "guard" / "rules" / "xflow_rules.yaml"


@dataclass
class XFlowRule:
    id: str = ""
    type: str = ""
    title: str = ""
    severity: str = "high"
    description: str = ""
    remediation: str = ""
    skill_codes: list[str] = field(default_factory=list)
    mcp_caps: list[str] = field(default_factory=list)
    skill_codes_a: list[str] = field(default_factory=list)
    skill_codes_b: list[str] = field(default_factory=list)


def _load_xflow_rules() -> list[XFlowRule]:
    if not _RULES_PATH.exists():
        return []
    data = yaml.safe_load(_RULES_PATH.read_text())
    rules: list[XFlowRule] = []
    for entry in data:
        rules.append(XFlowRule(
            id=entry.get("id", ""),
            type=entry.get("type", ""),
            title=entry.get("title", ""),
            severity=entry.get("severity", "high"),
            description=entry.get("description", ""),
            remediation=entry.get("remediation", ""),
            skill_codes=entry.get("skill_codes", []),
            mcp_caps=entry.get("mcp_caps", []),
            skill_codes_a=entry.get("skill_codes_a", []),
            skill_codes_b=entry.get("skill_codes_b", []),
        ))
    return rules


class CrossArtifactFlowAnalyzer(Analyzer):
    name = "xflow"

    def __init__(self) -> None:
        self._rules = _load_xflow_rules()

    def analyze(
        self,
        *,
        agents: list[CollectedAgent],
        match_results: list[MatchResult] | None = None,
        findings: list[Finding] | None = None,
        **_kwargs,
    ) -> list[Finding]:
        if not findings or not self._rules:
            return []

        skill_codes = {f.code for f in findings if f.code.startswith("SKILL-")}
        if not skill_codes:
            return []

        mcp_caps: set[str] = set()
        if match_results:
            for mr in match_results:
                if mr.registry_hit and mr.registry_hit.capability_labels:
                    mcp_caps.update(mr.registry_hit.capability_labels)
                else:
                    mcp_caps.update(_label_from_server_name(
                        mr.server.name, mr.server.package_id or "",
                    ))

        skill_sources = {}
        for f in findings:
            if f.code.startswith("SKILL-"):
                skill_sources.setdefault(f.code, []).append(f.source or "unknown")

        xflow_findings: list[Finding] = []
        seen: set[str] = set()

        for rule in self._rules:
            if rule.id in seen:
                continue

            if rule.type == "skill_mcp":
                if not self._check_skill_mcp(rule, skill_codes, mcp_caps):
                    continue
            elif rule.type == "skill_skill":
                if not self._check_skill_skill(rule, skill_codes):
                    continue
            else:
                continue

            seen.add(rule.id)

            involved = self._involved_sources(rule, skill_sources)
            xflow_findings.append(Finding(
                code=rule.id,
                title=rule.title,
                description=rule.description,
                severity=rule.severity,
                source="xflow",
                server_name=", ".join(involved) if involved else "multiple",
                agent_names=[],
                evidence=self._build_evidence(rule, skill_codes, mcp_caps),
                remediation=rule.remediation,
            ))

        return xflow_findings

    def _check_skill_mcp(
        self, rule: XFlowRule, skill_codes: set[str], mcp_caps: set[str],
    ) -> bool:
        has_skill = any(sc in skill_codes for sc in rule.skill_codes)
        has_mcp = any(mc in mcp_caps for mc in rule.mcp_caps)
        return has_skill and has_mcp

    def _check_skill_skill(
        self, rule: XFlowRule, skill_codes: set[str],
    ) -> bool:
        has_a = any(sc in skill_codes for sc in rule.skill_codes_a)
        has_b = any(sc in skill_codes for sc in rule.skill_codes_b)
        return has_a and has_b

    def _involved_sources(
        self, rule: XFlowRule, skill_sources: dict[str, list[str]],
    ) -> list[str]:
        sources: set[str] = set()
        codes = rule.skill_codes or (rule.skill_codes_a + rule.skill_codes_b)
        for code in codes:
            for src in skill_sources.get(code, []):
                sources.add(src)
        return sorted(sources)

    def _build_evidence(
        self, rule: XFlowRule, skill_codes: set[str], mcp_caps: set[str],
    ) -> str:
        parts: list[str] = []
        if rule.type == "skill_mcp":
            matched_skills = [sc for sc in rule.skill_codes if sc in skill_codes]
            matched_mcps = [mc for mc in rule.mcp_caps if mc in mcp_caps]
            parts.append(f"Skill findings: {', '.join(matched_skills)}")
            parts.append(f"MCP capabilities: {', '.join(matched_mcps)}")
        elif rule.type == "skill_skill":
            matched_a = [sc for sc in rule.skill_codes_a if sc in skill_codes]
            matched_b = [sc for sc in rule.skill_codes_b if sc in skill_codes]
            parts.append(f"Skill group A: {', '.join(matched_a)}")
            parts.append(f"Skill group B: {', '.join(matched_b)}")
        return " | ".join(parts)
