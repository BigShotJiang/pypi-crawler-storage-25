from __future__ import annotations

from abc import ABC, abstractmethod

from agentseal.guard.models import CollectedAgent, Finding, MatchResult


class Analyzer(ABC):
    name: str
    requires_runtime: bool = False
    requires_llm: bool = False

    @abstractmethod
    def analyze(self, *, agents: list[CollectedAgent], match_results: list[MatchResult] | None = None) -> list[Finding]: ...
