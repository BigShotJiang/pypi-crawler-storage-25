from __future__ import annotations

import math
import re
from collections import Counter

from agentseal.guard.analyzers.base import Analyzer
from agentseal.guard.models import CollectedAgent, Finding, MCPServerConfig

# ═══════════════════════════════════════════════════════════════════════
# CONF-001: Known secret prefixes (stable provider-defined formats)
# ═══════════════════════════════════════════════════════════════════════

_API_KEY_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"sk-ant-[A-Za-z0-9\-_]{20,}"),
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"AKIA[A-Z0-9]{16}"),
    re.compile(r"ghp_[A-Za-z0-9]{36}"),
    re.compile(r"gho_[A-Za-z0-9]{36}"),
    re.compile(r"github_pat_[A-Za-z0-9_]{59}"),
    re.compile(r"glpat-[A-Za-z0-9\-_]{20,}"),
    re.compile(r"xoxb-[A-Za-z0-9\-]{40,}"),
    re.compile(r"sk_live_[A-Za-z0-9]{20,}"),
    re.compile(r"AIza[A-Za-z0-9\-_]{35}"),
    re.compile(r"SG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}"),
]

# ═══════════════════════════════════════════════════════════════════════
# CONF-003: Sensitive paths — known high-value targets + dotfile dirs
# ═══════════════════════════════════════════════════════════════════════

_KNOWN_SENSITIVE_PATHS: list[str] = [
    "/etc/passwd",
    "/etc/shadow",
    "wallet.dat",
    "id_rsa",
    "id_ed25519",
    "authorized_keys",
    "credentials.json",
]

_SENSITIVE_DOTFILE_RE = re.compile(
    r"/\.(?:ssh|aws|gnupg|kube|docker|azure|gcloud|config/gcloud"
    r"|vault-token|npmrc|pypirc|netrc|env)\b"
)

# ═══════════════════════════════════════════════════════════════════════
# CONF-007: Intelligent secret env var detection
# ═══════════════════════════════════════════════════════════════════════

_SECRET_NAME_PATTERNS = re.compile(
    r"_(?:API_KEY|ACCESS_KEY|SECRET|TOKEN|PASSWORD|PRIVATE_KEY|CREDENTIAL|AUTH_TOKEN)$"
    r"|^(?:DATABASE_URL|MONGO_URI|REDIS_URL)$"
    r"|_(?:SECRET_KEY|SIGNING_KEY|ENCRYPTION_KEY|SECRET_ACCESS_KEY)$"
    r"|(?:SECRET|PRIVATE|CREDENTIAL)",
    re.IGNORECASE,
)

_SAFE_ENV_KEYS = frozenset({
    "PATH", "HOME", "SHELL", "TERM", "LANG", "LC_ALL", "USER", "LOGNAME",
    "TMPDIR", "TMP", "TEMP", "DISPLAY", "EDITOR", "VISUAL", "PAGER",
    "NODE_ENV", "PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "VIRTUAL_ENV",
    "NPM_CONFIG_PREFIX", "XDG_RUNTIME_DIR", "XDG_CONFIG_HOME",
    "XDG_DATA_HOME", "XDG_CACHE_HOME", "COLORTERM", "TERM_PROGRAM",
    "HOMEBREW_PREFIX", "HOSTNAME", "PWD", "OLDPWD", "SHLVL",
    "AGENTSEAL_DEBUG",
})


def _is_secret_env_name(key: str) -> bool:
    if key.upper() in _SAFE_ENV_KEYS:
        return False
    return bool(_SECRET_NAME_PATTERNS.search(key))


def _shannon_entropy(text: str) -> float:
    if len(text) < 8:
        return 0.0
    counts = Counter(text)
    length = len(text)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def _looks_like_secret_value(value: str) -> bool:
    if len(value) < 16:
        return False
    if value.startswith("/") or value.startswith("~"):
        return False
    if " " in value:
        return False
    return _shannon_entropy(value) > 3.5


class PatternAnalyzer(Analyzer):
    name = "pattern"

    def analyze(self, *, agents: list[CollectedAgent]) -> list[Finding]:
        findings: list[Finding] = []
        for agent in agents:
            for server in agent.mcp_servers:
                findings.extend(self._check_server(server, agent.name))
        return findings

    def _check_server(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        findings: list[Finding] = []
        findings.extend(self._check_conf001(server, agent_name))
        findings.extend(self._check_conf002(server, agent_name))
        findings.extend(self._check_conf003(server, agent_name))
        findings.extend(self._check_conf004(server, agent_name))
        findings.extend(self._check_conf005(server, agent_name))
        findings.extend(self._check_conf006(server, agent_name))
        findings.extend(self._check_conf007(server, agent_name))
        findings.extend(self._check_conf008(server, agent_name))
        return findings

    def _finding(
        self,
        *,
        server: MCPServerConfig,
        agent_name: str,
        code: str,
        title: str,
        description: str,
        severity: str,
        evidence: str,
        remediation: str,
    ) -> Finding:
        source = str(server.source_file) if server.source_file else None
        return Finding(
            code=code,
            title=title,
            description=description,
            severity=severity,
            source=source,
            server_name=server.name,
            agent_names=[agent_name],
            evidence=evidence,
            remediation=remediation,
        )

    # ── CONF-001: Hardcoded secrets (known prefixes + entropy) ────────

    def _check_conf001(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        results: list[Finding] = []
        for key, value in server.env.items():
            if not isinstance(value, str) or key.upper() in _SAFE_ENV_KEYS:
                continue
            # Check known API key prefixes
            for pattern in _API_KEY_PATTERNS:
                match = pattern.search(value)
                if match:
                    redacted = value[: match.start()] + match.group()[:8] + "…"
                    results.append(self._finding(
                        server=server, agent_name=agent_name,
                        code="CONF-001",
                        title="Hardcoded API key in MCP server config",
                        description="A credential matching a known API key pattern is hardcoded in the server environment.",
                        severity="critical",
                        evidence=f"Matched pattern in {key}: {redacted}",
                        remediation="Remove the hardcoded key. Use a secrets manager or runtime injection.",
                    ))
                    break
            else:
                # No known prefix matched — check entropy for unknown secret formats
                if _is_secret_env_name(key) and _looks_like_secret_value(value):
                    masked = value[:4] + "…" + value[-4:] if len(value) >= 12 else "********"
                    results.append(self._finding(
                        server=server, agent_name=agent_name,
                        code="CONF-001",
                        title="Probable secret in MCP server config",
                        description=f"Env var '{key}' has a name suggesting a secret and a high-entropy value.",
                        severity="high",
                        evidence=f"{key}={masked} (entropy: {_shannon_entropy(value):.1f} bits/char)",
                        remediation="Remove the hardcoded secret. Use a secrets manager or runtime injection.",
                    ))
            if results:
                break
        return results

    # ── CONF-002: npx -y auto-install ─────────────────────────────────

    def _check_conf002(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        if server.command != "npx":
            return []
        if "-y" in server.args or "--yes" in server.args:
            return [self._finding(
                server=server, agent_name=agent_name,
                code="CONF-002",
                title="npx -y auto-install (supply chain risk)",
                description="The -y flag causes npx to install packages without prompting, enabling silent supply chain attacks.",
                severity="high",
                evidence=f"Command: npx {' '.join(server.args)}",
                remediation="Remove the -y flag. Pin the package to an exact version.",
            )]
        return []

    # ── CONF-003: Sensitive paths (known + any dotfile directory) ──────

    def _check_conf003(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        results: list[Finding] = []
        for arg in server.args:
            # Known sensitive paths
            for fragment in _KNOWN_SENSITIVE_PATHS:
                if fragment in arg:
                    results.append(self._finding(
                        server=server, agent_name=agent_name,
                        code="CONF-003",
                        title="Sensitive path in MCP server arguments",
                        description=f"Server has access to sensitive path containing '{fragment}'.",
                        severity="high",
                        evidence=f"Path: {arg}",
                        remediation="Remove sensitive file paths. Provide only the minimum required access.",
                    ))
                    return results

            # Any dotfile directory (e.g. ~/.ssh, ~/.aws, ~/.config/gcloud, ~/.azure)
            if _SENSITIVE_DOTFILE_RE.search(arg):
                match = _SENSITIVE_DOTFILE_RE.search(arg)
                results.append(self._finding(
                    server=server, agent_name=agent_name,
                    code="CONF-003",
                    title="Sensitive dotfile directory in MCP server arguments",
                    description=f"Server has access to credential/config directory '{match.group()}'.",
                    severity="high",
                    evidence=f"Path: {arg}",
                    remediation="Remove dotfile directory access. These directories typically contain credentials.",
                ))
                return results
        return results

    # ── CONF-004: Wildcard root access ────────────────────────────────

    def _check_conf004(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        for arg in server.args:
            if arg in ("/", "~"):
                return [self._finding(
                    server=server, agent_name=agent_name,
                    code="CONF-004",
                    title="Wildcard filesystem access",
                    description="The server is granted root filesystem or full home directory access.",
                    severity="medium",
                    evidence=f"Root path argument: {arg!r}",
                    remediation="Replace with a specific directory the server needs.",
                )]
        return []

    # ── CONF-005: Bind 0.0.0.0 ────────────────────────────────────────

    def _check_conf005(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        combined = list(server.env.values()) + server.args
        for value in combined:
            if "0.0.0.0" in value:
                return [self._finding(
                    server=server, agent_name=agent_name,
                    code="CONF-005",
                    title="MCP server binds 0.0.0.0",
                    description="Server listens on all interfaces, exposing it to the network.",
                    severity="medium",
                    evidence=f"0.0.0.0 found in: {value!r}",
                    remediation="Bind to 127.0.0.1 to restrict to localhost.",
                )]
        return []

    # ── CONF-006: No version pin on npm package ───────────────────────

    def _check_conf006(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        if server.command != "npx":
            return []
        package = None
        for arg in server.args:
            if arg.startswith("-"):
                continue
            if arg.startswith("@") or (not arg.startswith("/") and not arg.startswith("~") and not arg.startswith(".")):
                package = arg
                break
        if not package:
            return []
        last_segment = package.rsplit("/", 1)[-1]
        if "@" not in last_segment[1:]:
            return [self._finding(
                server=server, agent_name=agent_name,
                code="CONF-006",
                title="No version pin on npm package",
                description="Unpinned package allows silent updates that may introduce malicious code.",
                severity="medium",
                evidence=f"Package without version pin: {package!r}",
                remediation=f"Pin to an exact version: {package}@<version>",
            )]
        return []

    # ── CONF-007: Secret env vars (pattern-based, not hardcoded list) ─

    def _check_conf007(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        results: list[Finding] = []
        for key in server.env:
            if _is_secret_env_name(key):
                results.append(self._finding(
                    server=server, agent_name=agent_name,
                    code="CONF-007",
                    title="Secret environment variable passed to MCP server",
                    description=f"Env var '{key}' appears to contain a secret based on its name pattern.",
                    severity="high",
                    evidence=f"Secret env var: {key}",
                    remediation=f"Remove '{key}' from server config. Use a secrets manager.",
                ))
        return results

    # ── CONF-008: Plaintext credentials in connection URLs ────────────

    def _check_conf008(self, server: MCPServerConfig, agent_name: str) -> list[Finding]:
        url_pattern = re.compile(r"[a-z+]+://[^:]+:[^@]+@")
        for arg in server.args:
            if url_pattern.search(arg):
                masked = re.sub(r"(://[^:]+:)[^@]+(@)", r"\1****\2", arg)
                return [self._finding(
                    server=server, agent_name=agent_name,
                    code="CONF-008",
                    title="Plaintext credentials in connection URL",
                    description="Connection string with embedded username and password found in server arguments.",
                    severity="critical",
                    evidence=f"URL with credentials: {masked}",
                    remediation="Move credentials to env vars or a secrets manager.",
                )]
        for value in server.env.values():
            if isinstance(value, str) and url_pattern.search(value):
                masked = re.sub(r"(://[^:]+:)[^@]+(@)", r"\1****\2", value)
                return [self._finding(
                    server=server, agent_name=agent_name,
                    code="CONF-008",
                    title="Plaintext credentials in connection URL",
                    description="Connection string with embedded username and password found in an env var.",
                    severity="critical",
                    evidence=f"URL with credentials: {masked}",
                    remediation="Move credentials to a secrets manager.",
                )]
        return []
