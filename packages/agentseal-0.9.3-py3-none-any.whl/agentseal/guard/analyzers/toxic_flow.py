from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from agentseal.guard.analyzers.base import Analyzer
from agentseal.guard.models import CollectedAgent, Finding, MatchResult

_RULES_PATH = Path(__file__).parents[2] / "guard" / "rules" / "default_flows.yaml"

# ---------------------------------------------------------------------------
# Capability labeling tables
# ---------------------------------------------------------------------------

_NAME_TO_CAPS: dict[str, set[str]] = {
    "read_file": {"read_file"},
    "readfile": {"read_file"},
    "read_files": {"read_file"},
    "get_file": {"read_file"},
    "cat_file": {"read_file"},
    "read_dir": {"read_dir"},
    "readdir": {"read_dir"},
    "list_dir": {"read_dir", "search_files"},
    "list_directory": {"read_dir"},
    "ls": {"read_dir"},
    "search_files": {"search_files"},
    "find_files": {"search_files"},
    "glob_files": {"search_files"},
    "write_file": {"write_file"},
    "writefile": {"write_file"},
    "create_file": {"write_file"},
    "save_file": {"write_file"},
    "append_file": {"write_file"},
    "execute_command": {"exec_command"},
    "exec_command": {"exec_command"},
    "run_command": {"exec_command"},
    "run_shell": {"exec_command"},
    "bash": {"exec_command"},
    "shell": {"exec_command"},
    "run_script": {"exec_command"},
    "http_request": {"http_request"},
    "http_get": {"http_request"},
    "http_post": {"http_request"},
    "make_request": {"http_request"},
    "call_api": {"http_request"},
    "fetch": {"fetch_url"},
    "fetch_url": {"fetch_url"},
    "download": {"download_file"},
    "download_file": {"download_file"},
    "send_message": {"send_message"},
    "send_slack": {"send_message"},
    "post_message": {"send_message"},
    "send_email": {"send_message"},
    "send_mail": {"send_message"},
    "read_env": {"read_env"},
    "get_env": {"read_env"},
    "read_environment": {"read_env"},
    "read_secrets": {"read_secrets"},
    "get_secret": {"read_secrets"},
    "get_secrets": {"read_secrets"},
    "read_ssh": {"read_ssh"},
    "get_ssh_key": {"read_ssh"},
    "database_read": {"database_read"},
    "db_query": {"database_read"},
    "sql_query": {"database_read"},
    "query_db": {"database_read"},
    "restart_service": {"restart_service"},
    "reload_config": {"restart_service"},
    "restart": {"restart_service"},
    "eval_code": {"eval_code"},
    "eval": {"eval_code"},
    "execute_code": {"eval_code"},
    "run_code": {"eval_code"},
    "template_render": {"template_render"},
    "render_template": {"template_render"},
    "read_browser": {"read_browser"},
    "get_browser": {"read_browser"},
    "read_cookies": {"read_browser"},
    "get_cookies": {"read_browser"},
    "webhook": {"webhook"},
    "send_webhook": {"webhook"},
    "trigger_webhook": {"webhook"},
    "read_aws": {"read_env"},
    "read_gcp": {"read_env"},
    "read_azure": {"read_env"},
    "read_credentials": {"read_secrets"},
}

# Semantic category → capabilities. Categories are extracted from server/package
# names, not matched as substrings of arbitrary text.
_CATEGORY_CAPS: dict[str, set[str]] = {
    "filesystem": {"read_file", "write_file", "read_dir", "search_files"},
    "file": {"read_file", "write_file"},
    "fs": {"read_file", "write_file", "read_dir"},
    "slack": {"send_message", "http_request"},
    "discord": {"send_message", "http_request"},
    "email": {"send_message"},
    "smtp": {"send_message"},
    "postgres": {"database_read", "sql_query"},
    "postgresql": {"database_read", "sql_query"},
    "sqlite": {"database_read", "sql_query"},
    "mysql": {"database_read", "sql_query"},
    "mongo": {"database_read"},
    "redis": {"database_read"},
    "search": {"http_request", "fetch_url"},
    "brave": {"http_request", "fetch_url"},
    "fetch": {"http_request", "fetch_url", "download_file"},
    "puppeteer": {"http_request", "fetch_url"},
    "playwright": {"http_request", "fetch_url"},
    "browser": {"http_request", "fetch_url"},
    "docker": {"exec_command"},
    "shell": {"exec_command"},
    "terminal": {"exec_command"},
    "bash": {"exec_command"},
    "kubernetes": {"exec_command"},
    "k8s": {"exec_command"},
    "github": {"http_request"},
    "gitlab": {"http_request"},
    "jira": {"http_request"},
    "notion": {"http_request"},
    "linear": {"http_request"},
    "git": {"read_file"},
    "memory": set(),
    "everything": set(),
    "time": set(),
    "clock": set(),
    "weather": set(),
}


def _extract_category(name: str, package_id: str) -> str | None:
    """Extract a semantic category from server name or package ID.

    Parses structured names like:
      @modelcontextprotocol/server-filesystem → filesystem
      @anthropic/mcp-slack → slack
      mcp-server-postgres → postgres
      server-brave-search → brave-search → brave
    Falls back to the server name itself.
    """
    sources = [name]
    if package_id:
        # npm:@scope/server-name → server-name
        pkg = package_id.split(":")[-1]  # strip npm:/pypi: prefix
        pkg = pkg.rsplit("/", 1)[-1]     # strip @scope/
        sources.insert(0, pkg)

    for src in sources:
        lower = src.lower()
        # Strip common prefixes: mcp-server-, server-, mcp-
        for prefix in ("mcp-server-", "server-", "mcp-"):
            if lower.startswith(prefix):
                lower = lower[len(prefix):]
                break
        # Exact category match
        if lower in _CATEGORY_CAPS:
            return lower
        # Try first segment of hyphenated name: brave-search → brave
        first = lower.split("-")[0]
        if first in _CATEGORY_CAPS:
            return first

    # Final fallback: try the server name directly
    if name.lower() in _CATEGORY_CAPS:
        return name.lower()
    return None


def _label_from_server_name(name: str, package_id: str) -> set[str]:
    category = _extract_category(name, package_id)
    if category is None:
        return set()
    return set(_CATEGORY_CAPS.get(category, set()))


_DESC_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\bread[s]?\s+(a\s+)?file\b", re.I), "read_file"),
    (re.compile(r"\bopen[s]?\s+(a\s+)?file\b", re.I), "read_file"),
    (re.compile(r"\blist[s]?\s+(files|directory|dir)\b", re.I), "read_dir"),
    (re.compile(r"\bwrite[s]?\s+(a\s+)?file\b", re.I), "write_file"),
    (re.compile(r"\bcreate[s]?\s+(a\s+)?file\b", re.I), "write_file"),
    (re.compile(r"\bsave[s]?\s+(a\s+)?file\b", re.I), "write_file"),
    (re.compile(r"\b(run[s]?|execute[s]?|exec)\s+(a\s+)?(shell|bash|command)\b", re.I), "exec_command"),
    (re.compile(r"\bsend[s]?\s+(an?\s+)?http\s+request\b", re.I), "http_request"),
    (re.compile(r"\bmake[s]?\s+(an?\s+)?http\s+(get|post|request)\b", re.I), "http_request"),
    (re.compile(r"\bsend[s]?\s+(a\s+)?message\b", re.I), "send_message"),
    (re.compile(r"\bsend[s]?\s+(an?\s+)?email\b", re.I), "send_message"),
    (re.compile(r"\bpost[s]?\s+(a\s+)?message\b", re.I), "send_message"),
    (re.compile(r"\bdownload[s]?\s+(a\s+)?file\b", re.I), "download_file"),
    (re.compile(r"\bfetch[s]?\s+(a\s+)?url\b", re.I), "fetch_url"),
    (re.compile(r"\bread[s]?\s+(environment|env)\s+variable\b", re.I), "read_env"),
    (re.compile(r"\bread[s]?\s+(a\s+)?secret\b", re.I), "read_secrets"),
    (re.compile(r"\bquery\s+(the\s+)?(database|db)\b", re.I), "database_read"),
    (re.compile(r"\brun[s]?\s+(a\s+)?sql\b", re.I), "database_read"),
    (re.compile(r"\brestart[s]?\s+(a\s+)?service\b", re.I), "restart_service"),
    (re.compile(r"\beval(uate)?[s]?\s+(code|script)\b", re.I), "eval_code"),
    (re.compile(r"\brender[s]?\s+(a\s+)?template\b", re.I), "template_render"),
    (re.compile(r"\bread[s]?\s+browser\b", re.I), "read_browser"),
    (re.compile(r"\bread[s]?\s+cook(ie)?s\b", re.I), "read_browser"),
    (re.compile(r"\bsend[s]?\s+(a\s+)?webhook\b", re.I), "webhook"),
    (re.compile(r"\bsearch[es]?\s+files?\b", re.I), "search_files"),
]

_PARAM_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"^(file_?path|filepath|filename|file)$", re.I), "read_file"),
    (re.compile(r"^(dir_?path|directory|folder)$", re.I), "read_dir"),
    (re.compile(r"^(content|data|body)$", re.I), "write_file"),
    (re.compile(r"^(command|cmd|shell_command|shell_cmd)$", re.I), "exec_command"),
    (re.compile(r"^(url|endpoint|uri)$", re.I), "http_request"),
    (re.compile(r"^(channel|recipient|to|message)$", re.I), "send_message"),
    (re.compile(r"^(env_?var|env_?key|environment_variable)$", re.I), "read_env"),
    (re.compile(r"^(secret_?name|secret_?key|secret_?id)$", re.I), "read_secrets"),
    (re.compile(r"^(query|sql|sql_query)$", re.I), "database_read"),
    (re.compile(r"^(code|script|expression)$", re.I), "eval_code"),
    (re.compile(r"^(template|template_?string)$", re.I), "template_render"),
    (re.compile(r"^(webhook_?url|hook_?url)$", re.I), "webhook"),
    (re.compile(r"^(pattern|glob|search_?pattern)$", re.I), "search_files"),
]


def label_tool(name: str, description: str, input_schema: dict) -> set[str]:
    labels: set[str] = set()

    normalized_name = name.lower()
    if normalized_name in _NAME_TO_CAPS:
        labels.update(_NAME_TO_CAPS[normalized_name])

    if not labels:
        for pattern, cap in _DESC_PATTERNS:
            if pattern.search(description):
                labels.add(cap)

    if not labels:
        props = input_schema.get("properties", {}) if isinstance(input_schema, dict) else {}
        for param_name in props:
            for pattern, cap in _PARAM_PATTERNS:
                if pattern.match(param_name.lower()):
                    labels.add(cap)

    return labels


# ---------------------------------------------------------------------------
# FlowRule + DSL parser
# ---------------------------------------------------------------------------

@dataclass
class FlowRule:
    id: str = ""
    title: str = ""
    severity: str = "high"
    remediation: str = ""
    steps: list[set[str]] = field(default_factory=list)


def parse_flow_rule(pattern: str) -> FlowRule:
    rule = FlowRule()
    parts = pattern.split("->")
    for part in parts:
        part = part.strip().strip("()")
        caps = {c.strip() for c in part.split("|") if c.strip()}
        rule.steps.append(caps)
    return rule


def _load_default_rules() -> list[FlowRule]:
    data = yaml.safe_load(_RULES_PATH.read_text())
    rules: list[FlowRule] = []
    for entry in data:
        rule = parse_flow_rule(entry["pattern"])
        rule.id = entry.get("id", "")
        rule.title = entry.get("title", "")
        rule.severity = entry.get("severity", "high")
        rule.remediation = entry.get("remediation", "")
        rules.append(rule)
    return rules


# ---------------------------------------------------------------------------
# ToxicFlowAnalyzer
# ---------------------------------------------------------------------------

class ToxicFlowAnalyzer(Analyzer):
    name = "toxic_flow"

    def __init__(self) -> None:
        self._rules = _load_default_rules()

    def analyze(
        self,
        *,
        agents: list[CollectedAgent],
        match_results: list[MatchResult] | None = None,
    ) -> list[Finding]:
        if not match_results:
            return []

        server_caps: dict[str, set[str]] = {}
        verified_servers: set[str] = set()
        for mr in match_results:
            if mr.registry_hit is not None and mr.registry_hit.capability_labels:
                server_caps[mr.server.name] = mr.registry_hit.capability_labels
                verified_servers.add(mr.server.name)
            else:
                labels = _label_from_server_name(mr.server.name, mr.server.package_id or "")
                if labels:
                    server_caps[mr.server.name] = labels

        findings: list[Finding] = []
        for agent in agents:
            agent_server_names = {s.name for s in agent.mcp_servers}
            reachable: set[str] = set()
            for sname in agent_server_names:
                reachable.update(server_caps.get(sname, set()))

            if not reachable:
                continue

            # Are all contributing servers verified (registry) or heuristic?
            contributing = {s for s in agent_server_names if server_caps.get(s)}
            all_verified = contributing <= verified_servers

            for rule in self._rules:
                if self._rule_matches(rule, reachable):
                    involved = sorted(contributing)
                    findings.append(self._make_finding(
                        rule, agent, involved, verified=all_verified,
                    ))

        return findings

    def _rule_matches(self, rule: FlowRule, caps: set[str]) -> bool:
        for step in rule.steps:
            if not (step & caps):
                return False
        return True

    def _make_finding(
        self,
        rule: FlowRule,
        agent: CollectedAgent,
        involved_servers: list[str],
        *,
        verified: bool,
    ) -> Finding:
        servers_str = ", ".join(involved_servers) if involved_servers else "unknown"
        if verified:
            severity = rule.severity
            desc = (
                f"Toxic capability flow detected: {rule.title}. "
                f"The agent '{agent.name}' has access to servers that together enable this flow."
            )
        else:
            # Downgrade: unverified heuristic labels → cap at "high"
            severity = "high" if rule.severity == "critical" else rule.severity
            desc = (
                f"Potential toxic flow: {rule.title}. "
                f"Based on server names (not verified via runtime scan or registry). "
                f"Run without --skip-runtime to confirm."
            )
        return Finding(
            code=rule.id,
            title=rule.title,
            description=desc,
            severity=severity,
            source=str(agent.config_path),
            server_name=servers_str,
            agent_names=[agent.name],
            evidence=f"Involved servers: {servers_str}",
            remediation=rule.remediation,
        )
