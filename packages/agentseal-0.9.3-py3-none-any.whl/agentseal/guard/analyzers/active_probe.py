from __future__ import annotations

import asyncio
import logging

from agentseal.guard.models import Finding, MCPServerConfig, MatchResult
from agentseal.guard_models import MCPRuntimeFinding

logger = logging.getLogger(__name__)


def convert_runtime_finding(rf: MCPRuntimeFinding, *, agent_names: list[str]) -> Finding:
    return Finding(
        code=rf.code,
        title=rf.title,
        description=rf.description,
        severity=rf.severity,
        source="deep_probe",
        server_name=rf.server_name,
        agent_names=agent_names,
        evidence=rf.evidence[:500],
        remediation=rf.remediation,
    )


def should_probe(
    mr: MatchResult,
    *,
    drift_servers: set[str],
    deep_all: bool,
) -> bool:
    if deep_all:
        return True
    if mr.needs_runtime:
        return True
    if mr.server.name in drift_servers:
        return True
    return False


class ActiveProbeRunner:
    def __init__(self, *, timeout: float = 60.0) -> None:
        self._timeout = timeout

    async def probe_server(self, server: MCPServerConfig) -> list[Finding]:
        try:
            from agentseal.mcp_session import MCPSession
            from agentseal.mcp_deep_analyzer import MCPDeepAnalyzer
        except ImportError:
            logger.warning("MCPSession/MCPDeepAnalyzer not available, skipping active probe for %s", server.name)
            return []

        findings: list[Finding] = []
        try:
            if server.url:
                session = await asyncio.wait_for(
                    MCPSession.connect_http(server.url, server_name=server.name),
                    timeout=30.0,
                )
            else:
                session = await asyncio.wait_for(
                    MCPSession.connect_stdio(
                        server.command, server.args,
                        env=server.env or None,
                        server_name=server.name,
                    ),
                    timeout=30.0,
                )

            async with session:
                if session.snapshot is None:
                    logger.info("No snapshot for %s, skipping deep probe", server.name)
                    return []

                analyzer = MCPDeepAnalyzer()
                runtime_findings = await asyncio.wait_for(
                    analyzer.analyze(session.snapshot, session),
                    timeout=self._timeout,
                )

                for rf in runtime_findings:
                    findings.append(convert_runtime_finding(
                        rf, agent_names=list(server.agents),
                    ))

        except asyncio.TimeoutError:
            logger.warning("Deep probe timed out for %s (%.0fs)", server.name, self._timeout)
        except Exception as e:
            logger.warning("Deep probe failed for %s: %s", server.name, e)

        return findings
