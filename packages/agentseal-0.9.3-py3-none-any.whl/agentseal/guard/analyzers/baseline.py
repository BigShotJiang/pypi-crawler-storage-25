from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agentseal.guard.models import Finding
from agentseal.guard.analyzers.base import Analyzer


class BaselineStore:
    _VERSION = 1

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or Path.home() / ".agentseal" / "baseline.json"
        self._data: dict[str, Any] = {}
        self._created_at: str | None = None
        if self._path.exists():
            self.load()

    def load(self) -> None:
        raw = json.loads(self._path.read_text())
        self._data = raw.get("servers", {})
        self._created_at = raw.get("created_at")

    def save(self) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": self._VERSION,
            "created_at": self._created_at or now,
            "updated_at": now,
            "servers": self._data,
        }
        self._path.write_text(json.dumps(payload, indent=2))

    @property
    def is_empty(self) -> bool:
        return not self._data

    def set_server_hash(
        self, server_id: str, tool_name: str, desc_hash: str, schema_hash: str
    ) -> None:
        self._data.setdefault(server_id, {"tools": {}})
        self._data[server_id]["tools"][tool_name] = {
            "desc_hash": desc_hash,
            "schema_hash": schema_hash,
        }

    def get_tool_hashes(
        self, server_id: str, tool_name: str
    ) -> tuple[str | None, str | None]:
        entry = self._data.get(server_id, {}).get("tools", {}).get(tool_name)
        if entry is None:
            return None, None
        return entry.get("desc_hash"), entry.get("schema_hash")

    def get_server_tools(self, server_id: str) -> set[str]:
        return set(self._data.get(server_id, {}).get("tools", {}).keys())

    def known_servers(self) -> set[str]:
        return set(self._data.keys())


class BaselineAnalyzer(Analyzer):
    name = "baseline"

    def __init__(self, baseline_path: Path | None = None) -> None:
        self._store = BaselineStore(baseline_path)

    def analyze(  # type: ignore[override]
        self,
        *,
        tool_hashes: dict[str, dict[str, tuple[str, str]]],
    ) -> list[Finding]:
        if self._store.is_empty:
            for server_id, tools in tool_hashes.items():
                for tool_name, (desc_hash, schema_hash) in tools.items():
                    self._store.set_server_hash(server_id, tool_name, desc_hash, schema_hash)
            self._store.save()
            return []

        findings: list[Finding] = []

        for server_id, tools in tool_hashes.items():
            baseline_tools = self._store.get_server_tools(server_id)
            current_tools = set(tools.keys())

            for tool_name, (desc_hash, schema_hash) in tools.items():
                stored_desc, stored_schema = self._store.get_tool_hashes(server_id, tool_name)

                if stored_desc is None:
                    findings.append(Finding(
                        code="BASE-002",
                        title="New tool added to server",
                        description=f"Tool '{tool_name}' was not present in the baseline.",
                        severity="high",
                        source="baseline",
                        server_name=server_id,
                        agent_names=[],
                        evidence=f"tool={tool_name}",
                        remediation="Review the new tool and update the baseline if expected.",
                    ))
                else:
                    if desc_hash != stored_desc:
                        findings.append(Finding(
                            code="BASE-001",
                            title="Tool description changed",
                            description=(
                                f"Tool '{tool_name}' description hash changed — possible rug pull."
                            ),
                            severity="critical",
                            source="baseline",
                            server_name=server_id,
                            agent_names=[],
                            evidence=f"tool={tool_name} old={stored_desc} new={desc_hash}",
                            remediation=(
                                "Inspect the tool description change before trusting this server."
                            ),
                        ))
                    if schema_hash != stored_schema:
                        findings.append(Finding(
                            code="BASE-004",
                            title="Tool schema changed",
                            description=f"Tool '{tool_name}' input schema hash changed.",
                            severity="high",
                            source="baseline",
                            server_name=server_id,
                            agent_names=[],
                            evidence=f"tool={tool_name} old={stored_schema} new={schema_hash}",
                            remediation="Review the schema change and update the baseline if expected.",
                        ))

            for tool_name in baseline_tools - current_tools:
                findings.append(Finding(
                    code="BASE-003",
                    title="Tool removed from server",
                    description=f"Tool '{tool_name}' was present in the baseline but is now gone.",
                    severity="medium",
                    source="baseline",
                    server_name=server_id,
                    agent_names=[],
                    evidence=f"tool={tool_name}",
                    remediation="Verify the tool was intentionally removed.",
                ))

        for server_id, tools in tool_hashes.items():
            for tool_name, (desc_hash, schema_hash) in tools.items():
                self._store.set_server_hash(server_id, tool_name, desc_hash, schema_hash)
        self._store.save()

        return findings
