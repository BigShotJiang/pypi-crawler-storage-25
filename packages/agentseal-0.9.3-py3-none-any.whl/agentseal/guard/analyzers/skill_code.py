from __future__ import annotations

import ast
import math
import re
from pathlib import Path

from agentseal.guard.analyzers.base import Analyzer
from agentseal.guard.models import Finding, SkillPath
from agentseal.guard.skill_parser import parse_skill_file

_CRED_FRAGMENTS: list[str] = [
    ".ssh/",
    ".ssh\"",
    ".aws/",
    ".aws\"",
    ".gnupg/",
    ".gnupg\"",
    ".kube/",
    ".kube\"",
    "id_rsa",
    "id_ed25519",
    "authorized_keys",
    "credentials.json",
    "/etc/passwd",
    "/etc/shadow",
    "wallet.dat",
]

_NETWORK_IMPORTS: frozenset[str] = frozenset(
    ["requests", "urllib", "httpx", "aiohttp"]
)

_SUBPROCESS_CALLS: frozenset[str] = frozenset(
    ["run", "call", "Popen"]
)

_ZERO_WIDTH: re.Pattern[str] = re.compile(
    r"[\u200b\u200c\u200d\u200e\u200f\ufeff\u2028\u2029]"
)

_BASE64_BLOB: re.Pattern[str] = re.compile(r"[A-Za-z0-9+/=]{80,}")

_JS_EVAL: re.Pattern[str] = re.compile(r"\beval\s*\(")
_JS_NEW_FUNCTION: re.Pattern[str] = re.compile(r"\bnew\s+Function\s*\(")
_JS_EVAL_LITERAL: re.Pattern[str] = re.compile(r"""\beval\s*\(\s*['"][^'"]*['"]\s*\)""")
_JS_NEW_FUNCTION_LITERAL: re.Pattern[str] = re.compile(
    r"""\bnew\s+Function\s*\(\s*['"][^'"]*['"]\s*\)"""
)


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    length = len(s)
    return -sum((c / length) * math.log2(c / length) for c in freq.values())


class SkillCodeAnalyzer(Analyzer):
    name = "skill_code"

    def analyze(self, *, skills: list[SkillPath], **_kwargs) -> list[Finding]:  # type: ignore[override]
        findings: list[Finding] = []
        for skill in skills:
            source = parse_skill_file(skill)
            if source is None:
                continue
            findings.extend(self._check_obfuscation(source, skill))
            ext = skill.path.suffix.lower()
            if ext == ".py":
                findings.extend(self._analyze_python(source, skill))
            elif ext in {".js", ".ts", ".mjs"}:
                findings.extend(self._analyze_js(source, skill))
        return findings

    def _finding(
        self,
        *,
        skill: SkillPath,
        code: str,
        title: str,
        description: str,
        severity: str,
        evidence: str,
        remediation: str,
    ) -> Finding:
        return Finding(
            code=code,
            title=title,
            description=description,
            severity=severity,
            source=str(skill.path),
            server_name=skill.path.name,
            agent_names=[],
            evidence=evidence,
            remediation=remediation,
        )

    def _check_obfuscation(self, source: str, skill: SkillPath) -> list[Finding]:
        findings: list[Finding] = []

        if _ZERO_WIDTH.search(source):
            findings.append(
                self._finding(
                    skill=skill,
                    code="SKILL-005",
                    title="Obfuscated code",
                    description=(
                        "The skill file contains zero-width or invisible Unicode characters, "
                        "a common obfuscation technique to hide malicious logic."
                    ),
                    severity="high",
                    evidence="Zero-width Unicode character detected in source",
                    remediation=(
                        "Remove all invisible Unicode characters. Review the code for hidden logic."
                    ),
                )
            )
            return findings

        for line in source.splitlines():
            stripped = line.strip()
            if len(stripped) > 50 and _shannon_entropy(stripped) > 5.5:
                findings.append(
                    self._finding(
                        skill=skill,
                        code="SKILL-005",
                        title="Obfuscated code",
                        description=(
                            "A line in the skill file has unusually high Shannon entropy, "
                            "suggesting obfuscated or encoded content."
                        ),
                        severity="high",
                        evidence=f"High-entropy line (entropy>{5.5}): {stripped[:60]}…",
                        remediation=(
                            "Review high-entropy strings. Replace encoded payloads with "
                            "readable code or verified constants."
                        ),
                    )
                )
                return findings

            m = _BASE64_BLOB.search(line)
            if m:
                findings.append(
                    self._finding(
                        skill=skill,
                        code="SKILL-005",
                        title="Obfuscated code",
                        description=(
                            "The skill file contains a long base64-like string (>80 chars), "
                            "which may encode a hidden payload."
                        ),
                        severity="high",
                        evidence=f"Base64 blob detected: {m.group()[:40]}…",
                        remediation=(
                            "Decode and review the base64 string. Remove encoded payloads."
                        ),
                    )
                )
                return findings

        return findings

    def _analyze_python(self, source: str, skill: SkillPath) -> list[Finding]:
        findings: list[Finding] = []
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return findings

        findings.extend(self._check_skill001_py(source, skill))
        findings.extend(self._check_skill002_py(source, tree, skill))
        findings.extend(self._check_skill003_py(tree, skill))
        findings.extend(self._check_skill004_py(source, tree, skill))
        findings.extend(self._check_skill006_py(tree, skill))
        return findings

    def _check_skill001_py(self, source: str, skill: SkillPath) -> list[Finding]:
        for fragment in _CRED_FRAGMENTS:
            if fragment in source:
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-001",
                        title="Credential file access",
                        description=(
                            "The skill references a path associated with sensitive credentials "
                            "or system authentication files."
                        ),
                        severity="critical",
                        evidence=f"Sensitive path fragment detected: {fragment!r}",
                        remediation=(
                            "Remove access to credential files. Use a secrets manager or "
                            "dedicated auth library instead of reading raw credential files."
                        ),
                    )
                ]
        return []

    def _has_network_import(self, tree: ast.AST) -> bool:
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    if root in _NETWORK_IMPORTS:
                        return True
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root = node.module.split(".")[0]
                    if root in _NETWORK_IMPORTS:
                        return True
        return False

    def _has_env_access(self, source: str) -> bool:
        return "os.environ" in source or "os.getenv" in source

    def _check_skill002_py(
        self, source: str, tree: ast.AST, skill: SkillPath
    ) -> list[Finding]:
        if not (self._has_env_access(source) and self._has_network_import(tree)):
            return []
        return [
            self._finding(
                skill=skill,
                code="SKILL-002",
                title="Environment variable exfiltration",
                description=(
                    "The skill reads environment variables and has network import capability, "
                    "creating a path for credential exfiltration."
                ),
                severity="critical",
                evidence="os.environ/os.getenv access combined with network import detected",
                remediation=(
                    "Separate environment variable access from network calls. "
                    "Never transmit environment variables to external endpoints."
                ),
            )
        ]

    def _is_dynamic_arg(self, node: ast.expr) -> bool:
        if isinstance(node, ast.Constant):
            return False
        if isinstance(node, ast.List):
            return any(not isinstance(elt, ast.Constant) for elt in node.elts)
        if isinstance(node, ast.JoinedStr):
            return True
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Attribute) and func.attr == "format":
                return True
        return True

    def _check_skill003_py(self, tree: ast.AST, skill: SkillPath) -> list[Finding]:
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            is_subprocess_method = (
                isinstance(func, ast.Attribute)
                and func.attr in _SUBPROCESS_CALLS
                and isinstance(func.value, ast.Name)
                and func.value.id == "subprocess"
            )
            is_os_system = (
                isinstance(func, ast.Attribute)
                and func.attr == "system"
                and isinstance(func.value, ast.Name)
                and func.value.id == "os"
            )
            if not (is_subprocess_method or is_os_system):
                continue
            if not node.args:
                continue
            first_arg = node.args[0]
            if self._is_dynamic_arg(first_arg):
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-003",
                        title="Command injection sink",
                        description=(
                            "A shell command is constructed using a dynamic value (f-string or "
                            "format()), creating a command injection vulnerability."
                        ),
                        severity="high",
                        evidence=(
                            f"subprocess/os.system called with dynamic argument at line "
                            f"{node.lineno}"
                        ),
                        remediation=(
                            "Use list-form subprocess arguments to avoid shell interpretation. "
                            "Never interpolate user input into shell command strings."
                        ),
                    )
                ]
        return []

    def _check_skill004_py(
        self, source: str, tree: ast.AST, skill: SkillPath
    ) -> list[Finding]:
        if self._has_env_access(source):
            return []
        if not self._has_network_import(tree):
            return []
        return [
            self._finding(
                skill=skill,
                code="SKILL-004",
                title="Network exfiltration capability",
                description=(
                    "The skill imports a network library, giving it the capability to "
                    "exfiltrate data to external endpoints."
                ),
                severity="high",
                evidence="Network library import detected without environment variable access",
                remediation=(
                    "Verify the network call is necessary and targets a trusted endpoint. "
                    "Restrict outbound network access via allowlists where possible."
                ),
            )
        ]

    def _check_skill006_py(self, tree: ast.AST, skill: SkillPath) -> list[Finding]:
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if not (isinstance(func, ast.Name) and func.id in {"eval", "exec", "compile"}):
                continue
            if not node.args:
                continue
            if not isinstance(node.args[0], ast.Constant):
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-006",
                        title="Eval with variable input",
                        description=(
                            "The skill calls eval(), exec(), or compile() with a non-constant "
                            "argument, enabling arbitrary code execution."
                        ),
                        severity="high",
                        evidence=f"{func.id}() called with dynamic argument at line {node.lineno}",
                        remediation=(
                            "Remove eval/exec/compile calls. If dynamic execution is required, "
                            "use a sandboxed interpreter or restrict input to a safe allowlist."
                        ),
                    )
                ]
        return []

    def _analyze_js(self, source: str, skill: SkillPath) -> list[Finding]:
        findings: list[Finding] = []
        findings.extend(self._check_skill001_js(source, skill))
        findings.extend(self._check_skill006_js(source, skill))
        return findings

    def _check_skill001_js(self, source: str, skill: SkillPath) -> list[Finding]:
        for fragment in _CRED_FRAGMENTS:
            if fragment in source:
                return [
                    self._finding(
                        skill=skill,
                        code="SKILL-001",
                        title="Credential file access",
                        description=(
                            "The skill references a path associated with sensitive credentials "
                            "or system authentication files."
                        ),
                        severity="critical",
                        evidence=f"Sensitive path fragment detected: {fragment!r}",
                        remediation=(
                            "Remove access to credential files. Use a secrets manager or "
                            "dedicated auth library instead of reading raw credential files."
                        ),
                    )
                ]
        return []

    def _check_skill006_js(self, source: str, skill: SkillPath) -> list[Finding]:
        has_eval = bool(_JS_EVAL.search(source))
        has_new_func = bool(_JS_NEW_FUNCTION.search(source))

        if has_eval and not _JS_EVAL_LITERAL.search(source):
            return [
                self._finding(
                    skill=skill,
                    code="SKILL-006",
                    title="Eval with variable input",
                    description=(
                        "The skill calls eval() or new Function() with a non-literal argument, "
                        "enabling arbitrary code execution."
                    ),
                    severity="high",
                    evidence="eval() with dynamic argument detected",
                    remediation=(
                        "Remove eval() calls. If dynamic execution is required, use a sandboxed "
                        "environment or restrict input to a safe allowlist."
                    ),
                )
            ]

        if has_new_func and not _JS_NEW_FUNCTION_LITERAL.search(source):
            return [
                self._finding(
                    skill=skill,
                    code="SKILL-006",
                    title="Eval with variable input",
                    description=(
                        "The skill calls new Function() with a non-literal argument, "
                        "enabling arbitrary code execution."
                    ),
                    severity="high",
                    evidence="new Function() with dynamic argument detected",
                    remediation=(
                        "Remove new Function() calls. Prefer named, declared functions."
                    ),
                )
            ]

        return []
