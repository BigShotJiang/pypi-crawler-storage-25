from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path

_package_path = Path(__file__).parent
for _module_info in pkgutil.iter_modules([str(_package_path)]):
    if _module_info.name != "base":
        importlib.import_module(f"{__name__}.{_module_info.name}")
