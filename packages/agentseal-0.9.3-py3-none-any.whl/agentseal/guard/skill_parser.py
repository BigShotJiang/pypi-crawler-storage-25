from __future__ import annotations

import re
from pathlib import Path

from agentseal.guard.models import SkillPath

_FRONTMATTER_END = re.compile(r"^---\s*$", re.MULTILINE)

_MDC_DESCRIPTION = re.compile(r"^description:\s*(.+)$", re.MULTILINE)

_MDC_METADATA_KEYS = frozenset({"globs", "alwaysApply", "tags", "priority", "version"})


def parse_skill_file(skill: SkillPath) -> str | None:
    try:
        raw = skill.path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None

    if skill.path.suffix == ".mdc" or skill.format == "mdc":
        return _parse_mdc(raw)
    return raw


def _parse_mdc(content: str) -> str:
    if not content.startswith("---"):
        return content

    lines = content.split("\n")
    fm_values: list[str] = []
    end_idx = -1

    for i, line in enumerate(lines[1:], 1):
        if line.strip() == "---":
            end_idx = i
            break
        if ":" in line:
            key, _, val = line.partition(":")
            key = key.strip()
            val = val.strip().strip("\"'")
            if key.lower() in _MDC_METADATA_KEYS or not val:
                continue
            if val.lower() in ("true", "false") or val.startswith("["):
                continue
            fm_values.append(val)

    if end_idx < 0:
        return content

    body = "\n".join(lines[end_idx + 1 :]).lstrip("\n")
    if fm_values:
        return "\n".join(fm_values) + "\n\n" + body
    return body


_NEGATION_RE = re.compile(
    r"\b(?:never|don'?t|do not|must not|should not|shouldn'?t|avoid|"
    r"protect against|guard against|forbid|prohibit|disallow)\b",
    re.IGNORECASE,
)

_NEGATION_WINDOW = 80


def is_negated(content: str, match: re.Match[str]) -> bool:
    start = max(0, match.start() - _NEGATION_WINDOW)
    window = content[start : match.start()]
    if "\n" in window:
        window = window[window.rfind("\n") + 1 :]
    return bool(_NEGATION_RE.search(window))


_DEFENSIVE_CONTEXT_RE = re.compile(
    r"\b(?:security|protect|defense|safeguard|hardening|"
    r"checklist|audit|compliance|policy|guideline|best.practice|"
    r"vulnerability|threat.model|attack.surface|risk.mitigation|"
    r"secure.by.default|zero.trust|least.privilege)\b",
    re.IGNORECASE,
)

_DEFENSIVE_THRESHOLD = 3

CONFIDENCE_BASE = 0.6
CONFIDENCE_DEFENSIVE = -0.3
CONFIDENCE_MULTI_PATTERN = 0.2
CONFIDENCE_OBFUSCATION = 0.3
CONFIDENCE_THRESHOLD = 0.5


def has_defensive_context(content: str) -> bool:
    matches = _DEFENSIVE_CONTEXT_RE.findall(content)
    return len(matches) >= _DEFENSIVE_THRESHOLD


_OBFUSCATION_CODES = frozenset({"SKILL-005", "SKILL-012", "SKILL-013"})
_STRUCTURAL_RISK_CODES = frozenset({"SKILL-016"})


def compute_skill_confidence(
    findings: list,
    content: str,
    *,
    source_contents: dict[str, str] | None = None,
) -> list:
    from agentseal.guard.models import Finding

    if not findings:
        return findings

    skill_findings: list[Finding] = [f for f in findings if f.code.startswith("SKILL-")]
    other_findings: list[Finding] = [f for f in findings if not f.code.startswith("SKILL-")]

    if not skill_findings:
        return findings

    by_source: dict[str | None, list[Finding]] = {}
    for f in skill_findings:
        by_source.setdefault(f.source, []).append(f)

    has_obfuscation = any(f.code in _OBFUSCATION_CODES for f in skill_findings)

    for source, group in by_source.items():
        src_content = (source_contents or {}).get(source or "", content)
        defensive = has_defensive_context(src_content)
        multi = len({f.code for f in group}) > 1
        for f in group:
            if f.code in _OBFUSCATION_CODES or f.code in _STRUCTURAL_RISK_CODES:
                f.confidence = 1.0
                continue

            conf = CONFIDENCE_BASE
            if defensive:
                conf += CONFIDENCE_DEFENSIVE
            if multi:
                conf += CONFIDENCE_MULTI_PATTERN
            if has_obfuscation:
                conf += CONFIDENCE_OBFUSCATION
            f.confidence = min(max(conf, 0.0), 1.0)

    kept = [
        f for f in skill_findings
        if f.confidence >= CONFIDENCE_THRESHOLD or f.severity in ("critical", "high")
    ]
    return other_findings + kept


def skill_name_from_file(skill: SkillPath) -> str:
    raw = None
    try:
        raw = skill.path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        pass

    if raw and raw.startswith("---"):
        for line in raw.split("\n")[1:]:
            if line.strip() == "---":
                break
            if line.startswith("name:"):
                name = line.split(":", 1)[1].strip().strip("\"'")
                if name:
                    return name

    if skill.path.stem.lower() in {"skill", "index", "readme"}:
        return skill.path.parent.name

    return skill.path.stem
