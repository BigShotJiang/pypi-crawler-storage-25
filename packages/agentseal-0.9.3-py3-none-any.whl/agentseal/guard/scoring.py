from __future__ import annotations

from agentseal.guard.models import Finding, MatchResult

SEVERITY_DEDUCTIONS: dict[str, int] = {"critical": 20, "high": 10, "medium": 5, "low": 2}
FLOW_EXTRA_PENALTY: dict[str, int] = {"critical": 15, "high": 8, "medium": 3}


def compute_machine_score(*, match_results: list[MatchResult], findings: list[Finding]) -> int:
    if not match_results:
        base = 100.0
    else:
        scores = [
            mr.registry_hit.trust_score if mr.registry_hit is not None else 50.0
            for mr in match_results
        ]
        base = sum(scores) / len(scores)

    scored_findings = [f for f in findings if not f.code.startswith("DEEP-")]

    total = base
    for f in scored_findings:
        total -= SEVERITY_DEDUCTIONS.get(f.severity, 0)
        if f.code.startswith("FLOW-"):
            total -= FLOW_EXTRA_PENALTY.get(f.severity, 0)

    critical_count = sum(1 for f in scored_findings if f.severity == "critical")
    if critical_count >= 5:
        total = min(total, 10)
    elif critical_count >= 3:
        total = min(total, 19)
    elif critical_count >= 1:
        total = min(total, 49)

    return max(0, min(100, int(total)))
