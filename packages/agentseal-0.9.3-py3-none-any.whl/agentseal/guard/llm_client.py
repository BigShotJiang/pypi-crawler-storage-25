from __future__ import annotations

import asyncio
import os
import shutil
from abc import ABC, abstractmethod

import httpx


class LLMClient(ABC):
    @abstractmethod
    async def complete(self, system: str, user: str) -> str: ...


class OllamaClient(LLMClient):
    def __init__(self, model: str, base_url: str = "http://localhost:11434") -> None:
        self._model = model
        self._base_url = base_url

    async def complete(self, system: str, user: str) -> str:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.post(
                f"{self._base_url}/api/chat",
                json={
                    "model": self._model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    "stream": False,
                },
            )
            resp.raise_for_status()
            return resp.json()["message"]["content"]


class AnthropicClient(LLMClient):
    def __init__(self, model: str, api_key: str) -> None:
        self._model = model
        self._api_key = api_key

    async def complete(self, system: str, user: str) -> str:
        import anthropic
        client = anthropic.AsyncAnthropic(api_key=self._api_key)
        message = await client.messages.create(
            model=self._model,
            max_tokens=4096,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return message.content[0].text


class ClaudeCLIClient(LLMClient):
    async def complete(self, system: str, user: str) -> str:
        prompt = f"{system}\n\n{user}"
        proc = await asyncio.create_subprocess_exec(
            "claude", "-p",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(prompt.encode()), timeout=300.0,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"claude -p failed (exit {proc.returncode}): {stderr.decode()[:500]}")
        return stdout.decode()


class OpenAICompatClient(LLMClient):
    def __init__(self, model: str, api_key: str, base_url: str = "https://api.openai.com/v1") -> None:
        self._model = model
        self._api_key = api_key
        self._base_url = base_url

    async def complete(self, system: str, user: str) -> str:
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.post(
                f"{self._base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self._api_key}"},
                json={
                    "model": self._model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    "max_tokens": 4096,
                },
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]


async def detect_ollama_model() -> str | None:
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get("http://localhost:11434/api/tags")
            if resp.status_code == 200:
                models = resp.json().get("models", [])
                if models:
                    return models[0]["name"]
    except Exception:
        pass
    return None


def resolve_client(model: str, *, api_key: str | None) -> LLMClient:
    if model.startswith("ollama:"):
        return OllamaClient(model[len("ollama:"):])

    if model == "claude-cli":
        if not shutil.which("claude"):
            raise ValueError("claude-cli requires the Claude Code CLI to be installed and on PATH")
        return ClaudeCLIClient()

    if model.startswith("claude"):
        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise ValueError("Claude models require --api-key or ANTHROPIC_API_KEY env var")
        return AnthropicClient(model, key)

    if not api_key:
        raise ValueError(f"Model '{model}' requires --api-key")
    return OpenAICompatClient(model, api_key)
