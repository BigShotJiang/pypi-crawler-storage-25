# agentseal/mcp_session.py
"""
Persistent MCP session for active tool probing.

Unlike mcp_runtime.py (connect → introspect → disconnect), this keeps the
connection alive so we can send tools/call requests for deep analysis.

Supports both stdio and HTTP transports. Reuses JSON-RPC helpers from mcp_runtime.
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import httpx

from agentseal.mcp_runtime import (
    CLIENT_NAME,
    CLIENT_VERSION,
    DEFAULT_TIMEOUT,
    MAX_LINE_BYTES,
    PROCESS_KILL_TIMEOUT,
    PROCESS_SHUTDOWN_TIMEOUT,
    PROTOCOL_VERSION,
    MCPProtocolError,
    MCPServerSnapshot,
    _cleanup_process,
    _extract_result,
    _make_notification,
    _make_request,
    _parse_jsonrpc,
    _parse_sse_stream,
    _read_response_line,
    _stdio_notify,
    _stdio_request,
    sanitize_env,
)


# ═══════════════════════════════════════════════════════════════════════
# RESULT MODEL
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class ToolCallResult:
    """Result of a single tools/call invocation."""
    content: list[dict]        # MCP content blocks
    is_error: bool
    latency_ms: float
    raw_response: dict         # Full JSON-RPC result for evidence


# ═══════════════════════════════════════════════════════════════════════
# PERSISTENT MCP SESSION
# ═══════════════════════════════════════════════════════════════════════

class MCPSession:
    """Async context manager for a persistent MCP server connection.

    Usage:
        async with MCPSession.connect_stdio("node", ["server.js"]) as session:
            result = await session.call_tool("my_tool", {"arg": "value"})

        async with MCPSession.connect_http("http://localhost:3000/mcp") as session:
            result = await session.call_tool("my_tool", {"arg": "value"})
    """

    def __init__(self) -> None:
        self._id_counter: int = 100  # Start high to avoid collisions with init sequence
        self._transport: str = ""    # "stdio" or "http"
        self._timeout: float = DEFAULT_TIMEOUT

        # stdio transport state
        self._proc: asyncio.subprocess.Process | None = None

        # HTTP transport state
        self._http_client: httpx.AsyncClient | None = None
        self._http_url: str = ""
        self._http_headers: dict[str, str] = {}
        self._session_id: str | None = None

        # TCP transport state (sandbox bridge)
        self._tcp_reader: asyncio.StreamReader | None = None
        self._tcp_writer: asyncio.StreamWriter | None = None

        # Snapshot from initial connection
        self.snapshot: MCPServerSnapshot | None = None

    async def __aenter__(self) -> MCPSession:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Cleanly shut down the session."""
        if self._proc is not None:
            await _cleanup_process(self._proc)
            self._proc = None
        if self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None
        if self._tcp_writer is not None:
            self._tcp_writer.close()
            try:
                await self._tcp_writer.wait_closed()
            except Exception:
                pass
            self._tcp_writer = None
            self._tcp_reader = None

    @classmethod
    async def connect_stdio(
        cls,
        command: str,
        args: list[str],
        env: dict[str, str] | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        server_name: str = "",
    ) -> MCPSession:
        """Connect to an MCP server via stdio and keep it alive.

        Performs the full MCP handshake (initialize + notifications/initialized),
        then returns a session ready for tools/call.
        """
        session = cls()
        session._transport = "stdio"
        session._timeout = timeout
        name = server_name or command

        safe_env = sanitize_env(env)

        proc = await asyncio.create_subprocess_exec(
            command, *args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=safe_env,
            limit=MAX_LINE_BYTES,
        )
        session._proc = proc

        assert proc.stdin is not None
        assert proc.stdout is not None

        try:
            # Initialize handshake
            init_params = {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": CLIENT_NAME, "version": CLIENT_VERSION},
            }
            init_result = await _stdio_request(
                proc.stdin, proc.stdout, "initialize", init_params, 1, timeout,
            )
            await _stdio_notify(proc.stdin, "notifications/initialized")

            # Extract basic server info for the snapshot
            capabilities = init_result.get("capabilities", {})
            server_info = init_result.get("serverInfo", {})
            instructions = str(init_result.get("instructions", ""))

            session.snapshot = MCPServerSnapshot(
                server_name=name,
                server_version=str(server_info.get("version", "")),
                protocol_version=str(init_result.get("protocolVersion", "")),
                instructions=instructions,
                capabilities=capabilities,
                tools=[],
                prompts=[],
                resources=[],
                connected_at=datetime.now(timezone.utc).isoformat(),
                connection_duration_ms=0.0,
            )

            session._id_counter = 100
            return session

        except Exception:
            await _cleanup_process(proc)
            session._proc = None
            raise

    @classmethod
    async def connect_http(
        cls,
        url: str,
        headers: dict[str, str] | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        server_name: str = "",
    ) -> MCPSession:
        """Connect to an MCP server via HTTP and keep the client alive."""
        session = cls()
        session._transport = "http"
        session._timeout = timeout
        session._http_url = url
        name = server_name or url

        req_headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if headers:
            req_headers.update(headers)
        session._http_headers = req_headers

        client = httpx.AsyncClient(timeout=httpx.Timeout(timeout))
        session._http_client = client

        try:
            # Initialize handshake
            init_params = {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": CLIENT_NAME, "version": CLIENT_VERSION},
            }
            init_result = await session._http_request("initialize", init_params, 1)
            await session._http_notify("notifications/initialized")

            capabilities = init_result.get("capabilities", {})
            server_info = init_result.get("serverInfo", {})
            instructions = str(init_result.get("instructions", ""))

            session.snapshot = MCPServerSnapshot(
                server_name=name,
                server_version=str(server_info.get("version", "")),
                protocol_version=str(init_result.get("protocolVersion", "")),
                instructions=instructions,
                capabilities=capabilities,
                tools=[],
                prompts=[],
                resources=[],
                connected_at=datetime.now(timezone.utc).isoformat(),
                connection_duration_ms=0.0,
            )

            session._id_counter = 100
            return session

        except Exception:
            await client.aclose()
            session._http_client = None
            raise

    @classmethod
    async def connect_tcp(
        cls,
        host: str,
        port: int,
        timeout: float = DEFAULT_TIMEOUT,
        server_name: str = "",
    ) -> MCPSession:
        """Connect to an MCP server via TCP socket (for sandbox bridge).

        The bridge script inside the Docker container relays JSON-RPC
        over a TCP socket to the MCP server's stdin/stdout.
        """
        session = cls()
        session._transport = "tcp"
        session._timeout = timeout
        name = server_name or f"tcp://{host}:{port}"

        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        session._tcp_reader = reader
        session._tcp_writer = writer

        try:
            # Initialize handshake
            init_params = {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": CLIENT_NAME, "version": CLIENT_VERSION},
            }
            init_result = await session._tcp_request("initialize", init_params, 1, timeout)
            await session._tcp_notify("notifications/initialized")

            capabilities = init_result.get("capabilities", {})
            server_info = init_result.get("serverInfo", {})
            instructions = str(init_result.get("instructions", ""))

            session.snapshot = MCPServerSnapshot(
                server_name=name,
                server_version=str(server_info.get("version", "")),
                protocol_version=str(init_result.get("protocolVersion", "")),
                instructions=instructions,
                capabilities=capabilities,
                tools=[],
                prompts=[],
                resources=[],
                connected_at=datetime.now(timezone.utc).isoformat(),
                connection_duration_ms=0.0,
            )

            session._id_counter = 100
            return session

        except Exception:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            raise

    async def call_tool(
        self,
        tool_name: str,
        arguments: dict,
        timeout: float | None = None,
    ) -> ToolCallResult:
        """Call an MCP tool and return the result with timing.

        Args:
            tool_name: Name of the tool to call.
            arguments: Arguments dict to pass.
            timeout: Per-call timeout (defaults to session timeout).

        Returns:
            ToolCallResult with content blocks, error status, and latency.

        Raises:
            MCPProtocolError: On protocol-level errors.
            ConnectionError: If the session is closed or broken.
            asyncio.TimeoutError: If the call times out.
        """
        t = timeout or self._timeout
        req_id = self._next_id()
        params = {"name": tool_name, "arguments": arguments}

        start = time.monotonic()

        if self._transport == "stdio":
            result = await self._stdio_call(params, req_id, t)
        elif self._transport == "http":
            result = await self._http_request("tools/call", params, req_id, t)
        elif self._transport == "tcp":
            result = await self._tcp_request("tools/call", params, req_id, t)
        else:
            raise ConnectionError(f"Unknown transport: {self._transport}")

        latency = (time.monotonic() - start) * 1000

        content = result.get("content", [])
        if not isinstance(content, list):
            content = []
        is_error = bool(result.get("isError", False))

        return ToolCallResult(
            content=content,
            is_error=is_error,
            latency_ms=round(latency, 1),
            raw_response=result,
        )

    def _next_id(self) -> int:
        self._id_counter += 1
        return self._id_counter

    async def _stdio_call(self, params: dict, req_id: int, timeout: float) -> dict:
        """Send a tools/call request over stdio."""
        if self._proc is None or self._proc.stdin is None or self._proc.stdout is None:
            raise ConnectionError("Stdio session is not connected")
        if self._proc.returncode is not None:
            raise ConnectionError("Server process has exited")
        return await _stdio_request(
            self._proc.stdin, self._proc.stdout,
            "tools/call", params, req_id, timeout,
        )

    async def _http_request(
        self,
        method: str,
        params: dict | None,
        req_id: int,
        timeout: float | None = None,
    ) -> dict:
        """Send a JSON-RPC request over HTTP."""
        if self._http_client is None:
            raise ConnectionError("HTTP session is not connected")

        body = _make_request(method, params, req_id)
        hdrs = dict(self._http_headers)
        if self._session_id:
            hdrs["Mcp-Session-Id"] = self._session_id

        resp = await self._http_client.post(
            self._http_url, content=body, headers=hdrs,
        )

        # Capture session ID
        if "mcp-session-id" in resp.headers:
            self._session_id = resp.headers["mcp-session-id"]

        if resp.status_code >= 400:
            raise MCPProtocolError(
                f"HTTP error: {resp.status_code}", code=resp.status_code,
            )

        content_type = resp.headers.get("content-type", "")

        if "text/event-stream" in content_type:
            events = _parse_sse_stream(resp.text)
            for event in events:
                try:
                    msg = _parse_jsonrpc(event.data)
                    if msg.get("id") == req_id:
                        return _extract_result(msg, req_id)
                except (MCPProtocolError, json.JSONDecodeError):
                    continue
            raise MCPProtocolError("No matching response in SSE stream")

        msg = _parse_jsonrpc(resp.text)
        return _extract_result(msg, req_id)

    async def _http_notify(self, method: str, params: dict | None = None) -> None:
        """Send a JSON-RPC notification over HTTP."""
        if self._http_client is None:
            raise ConnectionError("HTTP session is not connected")

        body = _make_notification(method, params)
        hdrs = dict(self._http_headers)
        if self._session_id:
            hdrs["Mcp-Session-Id"] = self._session_id

        await self._http_client.post(self._http_url, content=body, headers=hdrs)

    async def _tcp_request(
        self,
        method: str,
        params: dict | None,
        req_id: int,
        timeout: float | None = None,
    ) -> dict:
        """Send a JSON-RPC request over TCP (sandbox bridge).

        Loops to skip stale responses and server-initiated notifications
        left over from a previous client session (reconnection scenario).
        """
        if self._tcp_writer is None or self._tcp_reader is None:
            raise ConnectionError("TCP session is not connected")

        body = _make_request(method, params, req_id)
        self._tcp_writer.write(body)
        await self._tcp_writer.drain()

        t = timeout or self._timeout
        deadline = asyncio.get_event_loop().time() + t
        while True:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise TimeoutError(f"TCP request {method} timed out after {t}s")
            raw = await asyncio.wait_for(
                self._tcp_reader.readline(), timeout=remaining,
            )
            if not raw:
                raise ConnectionError("TCP connection closed by bridge")
            try:
                msg = _parse_jsonrpc(raw.decode())
            except (json.JSONDecodeError, MCPProtocolError):
                continue
            if "id" not in msg:
                continue
            if msg.get("id") == req_id:
                return _extract_result(msg, req_id)

    async def _tcp_notify(self, method: str, params: dict | None = None) -> None:
        """Send a JSON-RPC notification over TCP (sandbox bridge)."""
        if self._tcp_writer is None:
            raise ConnectionError("TCP session is not connected")

        body = _make_notification(method, params)
        self._tcp_writer.write(body)
        await self._tcp_writer.drain()
