"""Permission builder — shape + no-op correctness."""

from investify_data import Permission


def test_empty_builder_returns_empty_dict():
    assert Permission().build() == {}


def test_allow_all_tables_and_collections():
    perm = Permission().allow_all_tables().allow_all_collections().build()
    assert perm == {
        "allow": {
            "tables": {"*": {}},
            "collections": {"*": {}},
        }
    }


def test_allow_table_with_where_and_hide():
    perm = (
        Permission()
        .allow_table(
            "stock_price_history",
            where={"symbol": "VNM", "date": {"gte": "-5y"}},
            hide_columns=["created_by"],
        )
        .build()
    )
    assert perm["allow"]["tables"]["stock_price_history"] == {
        "where": {"symbol": "VNM", "date": {"gte": "-5y"}},
        "hide_columns": ["created_by"],
    }


def test_wildcard_plus_specific_override():
    perm = Permission().allow_table("*", where={"date": {"gte": "-1y"}}).allow_table("financial_ratio", hide_columns=["altman_z_score"]).build()
    assert "*" in perm["allow"]["tables"]
    assert "financial_ratio" in perm["allow"]["tables"]
    # Specific entry DOESN'T auto-copy wildcard rules — this is the server's
    # replace-semantic; admin explicitly chose what to keep.
    assert "where" not in perm["allow"]["tables"]["financial_ratio"]


def test_deny_table():
    perm = (
        Permission()
        .allow_all_tables()
        .deny_table("internal_admin")
        .deny_table("internal_admin")  # deduped
        .build()
    )
    assert perm["deny"]["tables"] == ["internal_admin"]


def test_collection_grant():
    perm = Permission().allow_collection("market_news", where={"topic": {"in": ["macro", "retail"]}}).deny_collection("sensitive").build()
    assert perm["allow"]["collections"]["market_news"] == {"where": {"topic": {"in": ["macro", "retail"]}}}
    assert perm["deny"]["collections"] == ["sensitive"]


def test_build_returns_independent_copies():
    """Mutating one build() result must not affect later builds or other callers."""
    builder = Permission().allow_table("T", where={"x": 1})
    first = builder.build()
    first["allow"]["tables"]["T"]["where"]["x"] = 999
    second = builder.build()
    assert second["allow"]["tables"]["T"]["where"]["x"] == 1


def test_empty_sections_omitted():
    """A builder that adds only a deny shouldn't emit an empty allow section."""
    perm = Permission().deny_table("x").build()
    assert "allow" not in perm
    assert perm == {"deny": {"tables": ["x"]}}
