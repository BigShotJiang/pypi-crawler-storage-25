import json

import pytest

from investify_data._base import (
    build_headers,
    build_query_params,
    redact_key,
    serialize_filters,
    validate_api_key,
)


def test_redact_key_masks_suffix() -> None:
    assert redact_key("ifyu_abcdefghijklmnopqrstuvwxyz012345") == "ifyu_***"
    assert redact_key("") == "<none>"


def test_validate_api_key_accepts_all_three_prefixes() -> None:
    validate_api_key("ifyu_abcdefghijklmnopqrstuvwxyz012345")
    validate_api_key("ifys_abcdefghijklmnopqrstuvwxyz012345")
    validate_api_key("ifym_abcdefghijklmnopqrstuvwxyz012345")


def test_validate_api_key_rejects_malformed() -> None:
    with pytest.raises(ValueError):
        validate_api_key("not-a-key")
    with pytest.raises(ValueError):
        validate_api_key("ifyu_short")


def test_build_headers_sets_bearer_and_agent() -> None:
    headers = build_headers("ifyu_abcdefghijklmnopqrstuvwxyz012345", None, "ua/1.0")
    assert headers["Authorization"].startswith("Bearer ifyu_")
    assert headers["User-Agent"] == "ua/1.0"
    assert headers["Accept"] == "application/json"
    assert "X-User-Id" not in headers


def test_build_headers_includes_user_id() -> None:
    headers = build_headers("ifys_abcdefghijklmnopqrstuvwxyz012345", "uid-1", "ua/1.0")
    assert headers["X-User-Id"] == "uid-1"


def test_build_headers_includes_tenant_id() -> None:
    headers = build_headers("ifym_abcdefghijklmnopqrstuvwxyz012345", None, "ua/1.0", tenant_id="tid-1")
    assert headers["X-Tenant-Id"] == "tid-1"
    assert "X-User-Id" not in headers


def test_build_headers_tenant_and_user_id() -> None:
    headers = build_headers("ifym_abcdefghijklmnopqrstuvwxyz012345", "uid-1", "ua/1.0", tenant_id="tid-1")
    assert headers["X-Tenant-Id"] == "tid-1"
    assert headers["X-User-Id"] == "uid-1"


def test_serialize_filters_scalar_list_dict() -> None:
    out = dict(
        serialize_filters(
            {
                "symbol": "VNM",
                "exchange": ["HOSE", "HNX"],
                "date": {"gte": "-30d", "lte": "2025-12-31"},
                "is_active": True,
            }
        )
    )
    assert out["symbol"] == "VNM"
    assert json.loads(out["exchange"]) == ["HOSE", "HNX"]
    assert json.loads(out["date"]) == {"gte": "-30d", "lte": "2025-12-31"}
    assert out["is_active"] == "true"


def test_build_query_params_columns_limit_sort() -> None:
    params = dict(
        build_query_params(
            columns=["symbol", "date"],
            sort="date.desc",
            limit=10,
            offset=5,
            filters={"symbol": "VNM"},
        )
    )
    assert params["columns"] == "symbol,date"
    assert params["sort"] == "date.desc"
    assert params["limit"] == "10"
    assert params["offset"] == "5"
    assert params["symbol"] == "VNM"


def test_build_query_params_drops_none_extras() -> None:
    params = dict(build_query_params(extra={"q": "hi", "mode": None, "include_matches": False}))
    assert params["q"] == "hi"
    assert "mode" not in params
    assert params["include_matches"] == "false"
