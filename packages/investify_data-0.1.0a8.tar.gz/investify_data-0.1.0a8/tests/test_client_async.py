import httpx
import pytest
import respx

from investify_data import AsyncDataClient, NotFound


@respx.mock
async def test_async_catalog_list_table_categories(api_key, base_url):
    route = respx.get(f"{base_url}/v1/catalog/table-categories").mock(return_value=httpx.Response(200, json={"categories": []}))
    async with AsyncDataClient(api_key=api_key, base_url=base_url) as client:
        result = await client.catalog.list_table_categories()
    assert result == {"categories": []}
    assert route.calls.call_count == 1


@respx.mock
async def test_async_tables_query_headers_and_filters(api_key, base_url):
    route = respx.get(f"{base_url}/v1/tables/stock_price_history").mock(return_value=httpx.Response(200, json={"rows": []}))
    async with AsyncDataClient(api_key=api_key, base_url=base_url, user_id="550e8400-e29b-41d4-a716-446655440000") as client:
        await client.tables.query(
            "stock_price_history",
            filters={"symbol": "VNM"},
            limit=3,
        )

    sent = route.calls[-1].request
    assert sent.headers["x-user-id"] == "550e8400-e29b-41d4-a716-446655440000"
    assert sent.url.params.get("symbol") == "VNM"
    assert sent.url.params.get("limit") == "3"


@respx.mock
async def test_async_on_behalf_of_reuses_transport_and_sets_default_user_context(api_key, base_url):
    route = respx.get(f"{base_url}/v1/tables/stock_price_history").mock(return_value=httpx.Response(200, json={"rows": []}))
    async with AsyncDataClient(api_key="ifys_abcdefghijklmnopqrstuvwxyz012345", base_url=base_url) as root:
        client = root.on_behalf_of(user_id="user-1", tenant_id="tenant-1")
        await client.tables.query("stock_price_history")
        await client.close()
        await root.tables.query("stock_price_history")

    first = route.calls[0].request
    second = route.calls[1].request
    assert first.headers["x-user-id"] == "user-1"
    assert first.headers["x-tenant-id"] == "tenant-1"
    assert "x-user-id" not in second.headers
    assert "x-tenant-id" not in second.headers


async def test_async_on_behalf_of_rejects_user_key(base_url):
    async with AsyncDataClient(api_key="ifyu_abcdefghijklmnopqrstuvwxyz012345", base_url=base_url) as client:
        with pytest.raises(ValueError, match="tenant or master key"):
            client.on_behalf_of(user_id="user-1")


async def test_async_on_behalf_of_master_key_requires_tenant_id(base_url):
    async with AsyncDataClient(api_key="ifym_abcdefghijklmnopqrstuvwxyz012345", base_url=base_url) as client:
        with pytest.raises(ValueError, match="master key requires tenant_id"):
            client.on_behalf_of(user_id="user-1")


@respx.mock
async def test_async_search_and_get_document(api_key, base_url):
    respx.get(f"{base_url}/v1/collections/market_news").mock(return_value=httpx.Response(200, json={"hits": [{"id": "d1", "score": 0.9}]}))
    respx.get(f"{base_url}/v1/collections/market_news/d1").mock(return_value=httpx.Response(200, json={"id": "d1", "text": "…", "metadata": {}}))
    async with AsyncDataClient(api_key=api_key, base_url=base_url) as client:
        hits = await client.collections.search("market_news", q="lãi suất")
        doc = await client.collections.get("market_news", "d1")

    assert hits["hits"][0]["id"] == "d1"
    assert doc["id"] == "d1"


@respx.mock
async def test_async_error_maps_to_not_found(api_key, base_url):
    respx.get(f"{base_url}/v1/tables/missing").mock(return_value=httpx.Response(404, json={"detail": {"code": "RESOURCE_NOT_FOUND", "message": "gone"}}))
    async with AsyncDataClient(api_key=api_key, base_url=base_url) as client:
        with pytest.raises(NotFound):
            await client.tables.query("missing")
