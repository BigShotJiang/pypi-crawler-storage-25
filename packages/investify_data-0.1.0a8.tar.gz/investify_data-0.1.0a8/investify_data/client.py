"""Sync client for the Investify Data API."""

from __future__ import annotations

from typing import Any

import httpx

from investify_data._base import (
    DEFAULT_BASE_URL,
    USER_AGENT,
    build_headers,
    redact_key,
    safe_json,
    validate_api_key,
    warn_if_insecure,
)
from investify_data._resources_sync import CatalogResource, CollectionsResource, TablesResource
from investify_data.exceptions import TransportError, raise_for_response


class DataClient:
    """Synchronous client for the Investify Data API.

    Minimal usage:
        client = DataClient(api_key="ifyu_...")
        rows = client.tables.query("stock_price_history", filters={"symbol": "VNM"}, limit=5)
        client.close()

    As a context manager (preferred — closes the underlying pool):
        with DataClient(api_key="ifyu_...") as client:
            ...

    Args:
        api_key: `ifyu_*` (user key), `ifys_*` (tenant key), or `ifym_*` (master key).
        base_url: API base URL. Defaults to production. Override for dev/LAN.
        tenant_id: Default tenant UUID (sent as `X-Tenant-Id`). Only meaningful
            with `ifym_*` (master) keys — lets the admin key act within a specific
            tenant's scope. May be overridden per-call.
        user_id: Default user UUID (sent as `X-User-Id`). Only valid with
            `ifys_*` or `ifym_*` keys; rejected with `ifyu_*`. May be overridden
            per-call on any resource method.
        timeout: Per-request timeout in seconds.
        user_agent: Override User-Agent header (useful for observability).
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        tenant_id: str | None = None,
        user_id: str | None = None,
        timeout: float = 30.0,
        user_agent: str = USER_AGENT,
        _http: httpx.Client | None = None,
        _owns_http: bool = True,
    ) -> None:
        validate_api_key(api_key)
        warn_if_insecure(base_url, api_key)

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._tenant_id = tenant_id
        self._user_id = user_id
        self._user_agent = user_agent
        self._owns_http = _owns_http

        self._http = _http or httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers=build_headers(api_key, user_id, user_agent, tenant_id=tenant_id),
        )

        self.catalog = CatalogResource(self)
        self.tables = TablesResource(self)
        self.collections = CollectionsResource(self)

    def __repr__(self) -> str:
        return f"DataClient(base_url={self._base_url!r}, api_key={redact_key(self._api_key)!r})"

    def __enter__(self) -> DataClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def on_behalf_of(
        self,
        *,
        user_id: str,
        tenant_id: str | None = None,
    ) -> DataClient:
        """Return a lightweight client that sends user context by default.

        The returned client reuses this client's HTTP transport; closing it is
        a no-op. Close the root client that created the transport.
        """
        effective_tenant_id = tenant_id if tenant_id is not None else self._tenant_id
        if self._api_key.startswith("ifyu_"):
            raise ValueError("on_behalf_of() requires a tenant or master key, not a user key.")
        if self._api_key.startswith("ifym_") and not effective_tenant_id:
            raise ValueError("on_behalf_of() with a master key requires tenant_id.")
        return DataClient(
            api_key=self._api_key,
            base_url=self._base_url,
            tenant_id=effective_tenant_id,
            user_id=user_id,
            user_agent=self._user_agent,
            _http=self._http,
            _owns_http=False,
        )

    # ─── Internal ────────────────────────────────────────────────────────────

    def _get_json(
        self,
        path: str,
        *,
        params: list[tuple[str, str]] | None = None,
    ) -> Any:
        extra: dict[str, str] = {}
        if self._tenant_id is not None:
            extra["X-Tenant-Id"] = self._tenant_id
        if self._user_id is not None:
            extra["X-User-Id"] = self._user_id
        headers = extra if extra else None
        try:
            response = self._http.get(path, params=params, headers=headers)
        except httpx.HTTPError as exc:
            raise TransportError(f"network error calling {path}: {type(exc).__name__}") from exc

        body = safe_json(response)
        raise_for_response(response.status_code, body)
        return body
