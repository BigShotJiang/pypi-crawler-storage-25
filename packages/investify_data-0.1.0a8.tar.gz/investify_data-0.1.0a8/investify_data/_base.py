"""Shared utilities for sync + async clients.

Keeps network IO out of this module — only URL building, parameter
serialization, and header assembly. The concrete sync/async clients
pass the results to httpx.
"""

from __future__ import annotations

import json
import re
import warnings
from collections.abc import Mapping
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://data.investify.vn"
USER_AGENT = "investify-data-python"

# Loose sanity check — full validation lives on the server.
_KEY_PATTERN = re.compile(r"^ify[msu]_[A-Za-z0-9]{32}$")


def redact_key(key: str) -> str:
    """Mask all but the 5-char prefix so keys never leak through logs/exceptions."""
    if not key:
        return "<none>"
    return f"{key[:5]}***"


def validate_api_key(key: str) -> None:
    if not _KEY_PATTERN.match(key):
        raise ValueError(f"api_key does not match expected format ify[msu]_<32-chars>: {redact_key(key)}")


def build_headers(
    api_key: str,
    user_id: str | None,
    user_agent: str,
    extra: Mapping[str, str] | None = None,
    *,
    tenant_id: str | None = None,
) -> dict[str, str]:
    headers: dict[str, str] = {
        "Authorization": f"Bearer {api_key}",
        "User-Agent": user_agent,
        "Accept": "application/json",
    }
    if tenant_id:
        headers["X-Tenant-Id"] = tenant_id
    if user_id:
        headers["X-User-Id"] = user_id
    if extra:
        headers.update(extra)
    return headers


def serialize_filters(filters: Mapping[str, Any] | None) -> list[tuple[str, str]]:
    """Serialize {col: spec} into (key, value) query params.

    Spec types:
        str | int | float | bool       -> str(value)
        list | tuple                   -> repeated param
        dict (operator form)           -> JSON-encoded
    """
    if not filters:
        return []

    out: list[tuple[str, str]] = []
    for col, value in filters.items():
        if isinstance(value, dict):
            out.append((col, json.dumps(value, separators=(",", ":"))))
        elif isinstance(value, list | tuple):
            out.append((col, json.dumps(list(value), separators=(",", ":"))))
        elif isinstance(value, bool):
            out.append((col, str(value).lower()))
        elif value is None:
            out.append((col, "null"))
        else:
            out.append((col, str(value)))
    return out


def build_query_params(
    *,
    columns: list[str] | None = None,
    sort: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
    filters: Mapping[str, Any] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> list[tuple[str, str]]:
    """Assemble a sequence of (key, value) params ready for httpx."""
    params: list[tuple[str, str]] = []
    if columns:
        params.append(("columns", ",".join(columns)))
    if sort:
        params.append(("sort", sort))
    if limit is not None:
        params.append(("limit", str(limit)))
    if offset is not None:
        params.append(("offset", str(offset)))
    if extra:
        for k, v in extra.items():
            if v is None:
                continue
            if isinstance(v, bool):
                params.append((k, str(v).lower()))
            else:
                params.append((k, str(v)))
    params.extend(serialize_filters(filters))
    return params


def safe_json(response: httpx.Response) -> Any:
    """Decode a response body as JSON, tolerating empty/invalid bodies.

    Lives in `_base.py` so both sync and async clients share exactly one
    parser — keeps error shapes identical and avoids cross-client imports.
    """
    if not response.content:
        return None
    try:
        return response.json()
    except ValueError:
        return {"detail": response.text[:500]}


_LOCAL_HOSTS = ("localhost", "127.0.0.1", "investify.k8s")


def warn_if_insecure(base_url: str, api_key: str) -> None:
    """Warn when a non-local plaintext URL is paired with a real-looking key."""
    if base_url.startswith("https://"):
        return
    if not base_url.startswith("http://"):
        return
    if any(host in base_url for host in _LOCAL_HOSTS):
        return
    warnings.warn(
        f"Using plaintext http:// base_url={base_url!r} with a live API key ({redact_key(api_key)}). Credentials will be sent in clear text — prefer https://.",
        stacklevel=3,
    )
