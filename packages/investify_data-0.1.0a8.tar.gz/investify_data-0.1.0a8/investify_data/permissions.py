"""Builder helper for constructing Investify Data API permission JSON.

The server's permission shape is:

    {
      "allow": {
        "tables":      {"*": {"where": {...}, "hide_columns": [...]}, "T": {...}},
        "collections": {"*": {"where": {...}}}
      },
      "deny": {"tables": [...], "collections": [...]}
    }

Hand-authoring this is error-prone for admin scripts that template per-tier
permissions. This module exposes a chainable builder that produces the dict
ready to PUT to `/v1/tenants/{tid}/users/{uid}/permission`.

Full reference for the underlying model:
    wos-docs/data-api/features/permissions.md

Examples:

    # Free tier — 1y time depth, limited collections
    perm = (
        Permission()
        .allow_table("*", where={"date": {"gte": "-1y"}})
        .allow_collection("*", where={"topic": {"in": ["public"]}})
        .build()
    )

    # Full internal access
    perm = Permission().allow_all_tables().allow_all_collections().build()

    # Customer-scoped (symbol VCB everywhere with that column)
    perm = Permission().allow_table("*", where={"symbol": "VCB"}).build()

    # Allow all tables except one
    perm = (
        Permission()
        .allow_all_tables()
        .deny_table("internal_admin_table")
        .build()
    )
"""

from __future__ import annotations

import copy
from collections.abc import Mapping
from typing import Any


class Permission:
    """Fluent builder for a data-api permission JSON document.

    All methods return `self` so they can be chained. Call `.build()` at the
    end to produce the dict.
    """

    def __init__(self) -> None:
        self._allow_tables: dict[str, dict[str, Any]] = {}
        self._allow_collections: dict[str, dict[str, Any]] = {}
        self._deny_tables: list[str] = []
        self._deny_collections: list[str] = []

    # ─── Tables ──────────────────────────────────────────────────────────

    def allow_table(
        self,
        table_id: str,
        *,
        where: Mapping[str, Any] | None = None,
        hide_columns: list[str] | None = None,
    ) -> Permission:
        """Grant access to `table_id`, optionally narrowed by `where` or with
        `hide_columns` excluded from responses. Pass `"*"` as wildcard.
        """
        grant: dict[str, Any] = {}
        if where:
            grant["where"] = dict(where)
        if hide_columns:
            grant["hide_columns"] = list(hide_columns)
        self._allow_tables[table_id] = grant
        return self

    def allow_all_tables(self) -> Permission:
        """Shortcut for `allow_table("*")`."""
        return self.allow_table("*")

    def deny_table(self, table_id: str) -> Permission:
        """Add to the deny list — always wins over allow, even wildcard."""
        if table_id not in self._deny_tables:
            self._deny_tables.append(table_id)
        return self

    # ─── Collections ─────────────────────────────────────────────────────

    def allow_collection(
        self,
        collection_id: str,
        *,
        where: Mapping[str, Any] | None = None,
    ) -> Permission:
        grant: dict[str, Any] = {}
        if where:
            grant["where"] = dict(where)
        self._allow_collections[collection_id] = grant
        return self

    def allow_all_collections(self) -> Permission:
        return self.allow_collection("*")

    def deny_collection(self, collection_id: str) -> Permission:
        if collection_id not in self._deny_collections:
            self._deny_collections.append(collection_id)
        return self

    # ─── Build ───────────────────────────────────────────────────────────

    def build(self) -> dict[str, Any]:
        """Produce the full permission dict. Safe to mutate afterward — a deep
        copy of the builder's internal state is returned each time.
        """
        out: dict[str, Any] = {}
        allow: dict[str, Any] = {}
        if self._allow_tables:
            allow["tables"] = copy.deepcopy(self._allow_tables)
        if self._allow_collections:
            allow["collections"] = copy.deepcopy(self._allow_collections)
        if allow:
            out["allow"] = allow

        deny: dict[str, Any] = {}
        if self._deny_tables:
            deny["tables"] = list(self._deny_tables)
        if self._deny_collections:
            deny["collections"] = list(self._deny_collections)
        if deny:
            out["deny"] = deny

        return out


__all__ = ["Permission"]
