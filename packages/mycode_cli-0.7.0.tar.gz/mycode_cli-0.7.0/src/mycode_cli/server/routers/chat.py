"""Chat and run streaming API."""

from __future__ import annotations

import asyncio
import html
import json
import os
from base64 import b64encode
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse

from mycode.messages import (
    build_message,
    document_block,
    image_block,
    text_block,
)
from mycode.models import resolve_model_metadata
from mycode.providers import get_provider_adapter, provider_default_models
from mycode.tools import detect_document_mime_type, detect_image_mime_type, resolve_path
from mycode_cli.config import (
    REASONING_EFFORT_OPTIONS,
    get_settings,
    normalize_reasoning_effort,
    resolve_provider,
    resolve_provider_choices,
)
from mycode_cli.permissions import ToolReviewDecision, ToolReviewRequest
from mycode_cli.runtime import build_agent, model_config_for
from mycode_cli.server.deps import RunManagerDep, StoreDep
from mycode_cli.server.run_manager import ActiveRunError, RunManager, RunState
from mycode_cli.server.schemas import ChatRequest, DecideRequest, StreamEvent

router = APIRouter()


def _format_sse(event: StreamEvent) -> str:
    return f"data: {json.dumps(event.model_dump(exclude_none=True), ensure_ascii=False)}\n\n"


async def _stream_run(req: Request, state: RunState, after: int) -> AsyncIterator[str]:
    last_seq = max(0, after)

    while True:
        if await req.is_disconnected():
            return

        async with state.condition:
            pending = [event for event in state.events if int(event.get("seq") or 0) > last_seq]
            finished = state.status != "running"

            if not pending and not finished:
                try:
                    await asyncio.wait_for(state.condition.wait(), timeout=0.5)
                except TimeoutError:
                    continue
                continue

        for payload in pending:
            if await req.is_disconnected():
                return
            yield _format_sse(StreamEvent(**payload))
            last_seq = int(payload.get("seq") or last_seq)

        if finished:
            break

    yield "data: [DONE]\n\n"


@router.post("/chat")
async def chat(chat: ChatRequest, store: StoreDep, runs: RunManagerDep):
    cwd = os.path.abspath(chat.cwd or os.getcwd())
    settings = get_settings(cwd)
    resolved = resolve_provider(
        settings,
        provider_name=chat.provider,
        model=chat.model,
        api_key=chat.api_key,
        api_base=chat.api_base,
    )
    try:
        request_effort = normalize_reasoning_effort(chat.reasoning_effort)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    reasoning_effort = request_effort if request_effort is not None else resolved.reasoning_effort
    session_id = chat.session_id or "default"

    if chat.message and chat.input:
        raise HTTPException(status_code=400, detail="message and input are mutually exclusive")

    if chat.input:
        blocks: list[dict[str, Any]] = []
        for block in chat.input:
            if block.type == "text":
                text = block.text or ""
                if block.is_attachment:
                    name = str(block.name or "attached-file")
                    blocks.append(
                        text_block(
                            f'<file name="{html.escape(name, quote=True)}">\n{text}\n</file>',
                            meta={"attachment": True, "path": name},
                        )
                    )
                elif text:
                    blocks.append(text_block(text))
                continue

            if block.type == "document":
                if block.data:
                    mime_type = block.mime_type or "application/pdf"
                    if mime_type != "application/pdf":
                        raise HTTPException(status_code=400, detail="unsupported document mime_type")
                    blocks.append(document_block(block.data, mime_type=mime_type, name=block.name or "document.pdf"))
                    continue

                if not block.path:
                    raise HTTPException(status_code=400, detail="document input requires path or data")
                document_path = Path(resolve_path(block.path, cwd=cwd))
                if not document_path.is_file():
                    raise HTTPException(status_code=400, detail=f"document file not found: {block.path}")
                mime_type = block.mime_type or detect_document_mime_type(document_path)
                if mime_type != "application/pdf":
                    raise HTTPException(status_code=400, detail=f"unsupported document file: {block.path}")
                document_data = b64encode(document_path.read_bytes()).decode("utf-8")
                blocks.append(
                    document_block(
                        document_data,
                        mime_type=mime_type,
                        name=block.name or document_path.name,
                    )
                )
                continue

            if block.data:
                if not block.mime_type:
                    raise HTTPException(status_code=400, detail="image data requires mime_type")
                blocks.append(image_block(block.data, mime_type=block.mime_type, name=block.name or "image"))
                continue

            if not block.path:
                raise HTTPException(status_code=400, detail="image input requires path or data")
            image_path = Path(resolve_path(block.path, cwd=cwd))
            if not image_path.is_file():
                raise HTTPException(status_code=400, detail=f"image file not found: {block.path}")
            mime_type = block.mime_type or detect_image_mime_type(image_path)
            if not mime_type:
                raise HTTPException(status_code=400, detail=f"unsupported image file: {block.path}")
            image_data = b64encode(image_path.read_bytes()).decode("utf-8")
            blocks.append(image_block(image_data, mime_type=mime_type, name=block.name or image_path.name))

        if not blocks:
            raise HTTPException(status_code=400, detail="input must include at least one non-empty block")
        user_message = build_message("user", blocks)
    else:
        message_text = str(chat.message or "").strip()
        if not message_text:
            raise HTTPException(status_code=400, detail="message or input is required")
        user_message = build_message("user", [text_block(message_text)])

    data = await store.load_session(session_id)
    session = (data or {}).get("session")
    existing_messages = (data or {}).get("messages") or []

    if not session and chat.rewind_to is not None:
        raise HTTPException(status_code=400, detail="rewind_to requires an existing session")

    if chat.rewind_to is not None:
        if not (0 <= chat.rewind_to < len(existing_messages)):
            raise HTTPException(
                status_code=400,
                detail=f"rewind_to must reference a visible message index between 0 and {len(existing_messages) - 1}",
            )

        target = existing_messages[chat.rewind_to]
        raw_blocks = target.get("content")
        blocks = raw_blocks if isinstance(raw_blocks, list) else []
        has_user_content = any(
            (block.get("type") == "text" and block.get("text")) or block.get("type") in {"image", "document"}
            for block in blocks
        )

        # Rewind only makes sense for real user prompts. Synthetic compact
        # summaries, assistant messages, and tool-result-only user messages are
        # not valid targets.
        if target.get("role") != "user" or (target.get("meta") or {}).get("synthetic") or not has_user_content:
            raise HTTPException(
                status_code=400,
                detail="rewind_to must reference a real user message",
            )

    # Capability check before any disk mutation — a failed check must not
    # leave an empty session on disk or land a premature rewind marker.
    model_config = model_config_for(settings, resolved)
    caps = resolve_model_metadata(
        provider=resolved.provider,
        model=resolved.model,
        supports_image_input=model_config.supports_image_input if model_config else None,
        supports_pdf_input=model_config.supports_pdf_input if model_config else None,
    )
    content_types = {b.get("type") for b in (user_message.get("content") or []) if isinstance(b, dict)}
    if "image" in content_types and not caps.supports_image_input:
        raise HTTPException(status_code=400, detail="current model does not support image input")
    if "document" in content_types and not caps.supports_pdf_input:
        raise HTTPException(status_code=400, detail="current model does not support PDF input")

    # All validation passed. Land the rewind marker (if any) and create the
    # session so the response payload has a meta dict and the agent's
    # auto-resume sees the correct on-disk state.
    if chat.rewind_to is not None:
        await store.append_rewind(session_id, chat.rewind_to)
    if not session:
        created = await store.create_session(session_id, cwd=cwd)
        session = created["session"]

    agent = build_agent(
        store=store,
        cwd=cwd,
        settings=settings,
        resolved_provider=resolved,
        session_id=session_id,
        reasoning_effort=reasoning_effort,
        review=_make_review(runs, session_id),
    )

    try:
        run = await runs.start_run(
            session_id=session_id,
            user_message=user_message,
            base_messages=agent.messages,
            agent=agent,
        )
    except ActiveRunError as exc:
        existing = await runs.get_run(exc.run_id)
        detail: dict[str, Any] = {"message": "session already has a running task"}
        if existing:
            detail["run"] = existing.info()
        raise HTTPException(status_code=409, detail=detail) from exc

    return {"run": run, "session": session}


@router.get("/runs/{run_id}/stream")
async def stream_run(run_id: str, req: Request, runs: RunManagerDep, after: int = 0):
    state = await runs.get_run(run_id)
    if not state:
        raise HTTPException(status_code=404, detail="run not found")

    return StreamingResponse(
        _stream_run(req, state, after),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/runs/{run_id}/cancel")
async def cancel_run(run_id: str, runs: RunManagerDep):
    run = await runs.cancel_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="run not found")
    return {"status": "ok", "run": run}


@router.post("/runs/{run_id}/decide")
async def decide_run(run_id: str, body: DecideRequest, runs: RunManagerDep):
    resolved = await runs.resolve_decision(run_id, body.request_id, body.decision)
    if not resolved:
        raise HTTPException(status_code=404, detail="permission request not found")
    return {"status": "ok"}


def _make_review(runs: RunManager, session_id: str):
    """Bridge before_tool review waits to SSE events on the active run."""

    async def review(request: ToolReviewRequest) -> ToolReviewDecision:
        return await runs.request_decision(
            session_id=session_id,
            tool_call_id=request.tool_call_id,
            tool_name=request.tool_name,
            preview=request.preview,
        )

    return review


@router.get("/config")
async def get_config(cwd: str | None = None):
    resolved_cwd = os.path.abspath(cwd or os.getcwd())
    settings = get_settings(resolved_cwd)
    try:
        resolved = resolve_provider(settings)
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    providers_info: dict[str, Any] = {}
    for provider in resolve_provider_choices(settings):
        provider_config = settings.providers.get(provider.provider_name or "")
        models = (
            list(provider_config.models)
            if provider_config and provider_config.models
            else list(provider_default_models(provider.provider))
        )
        if not models:
            models = [provider.model]

        info: dict[str, Any] = {
            "name": provider.provider_name,
            "provider": provider.provider,
            "type": provider.provider,
            "models": models,
            "base_url": provider.api_base or "",
            "has_api_key": True,
        }

        image_models: list[str] = []
        pdf_models: list[str] = []
        reasoning_models: list[str] = []
        adapter = get_provider_adapter(provider.provider)
        for model in models:
            model_config = provider_config.models.get(model) if provider_config else None
            caps = resolve_model_metadata(
                provider=provider.provider,
                model=model,
                supports_reasoning=model_config.supports_reasoning if model_config else None,
                supports_image_input=model_config.supports_image_input if model_config else None,
                supports_pdf_input=model_config.supports_pdf_input if model_config else None,
            )
            if caps.supports_reasoning is True:
                reasoning_models.append(model)
            if caps.supports_image_input:
                image_models.append(model)
            if caps.supports_pdf_input:
                pdf_models.append(model)

        if adapter.supports_reasoning_effort:
            info["supports_reasoning_effort"] = True
            info["reasoning_models"] = reasoning_models
            info["reasoning_effort"] = provider.reasoning_effort

        info["supports_image_input"] = bool(image_models)
        info["image_input_models"] = image_models
        info["supports_pdf_input"] = bool(pdf_models)
        info["pdf_input_models"] = pdf_models

        providers_info[provider.provider_name or provider.provider] = info

    return {
        "providers": providers_info,
        "default": {
            "provider": resolved.provider_name,
            "model": resolved.model,
        },
        "default_reasoning_effort": settings.default_reasoning_effort,
        "reasoning_effort_options": REASONING_EFFORT_OPTIONS,
        "cwd": resolved_cwd,
        "workspace_root": settings.workspace_root,
        "config_paths": settings.config_paths,
    }
