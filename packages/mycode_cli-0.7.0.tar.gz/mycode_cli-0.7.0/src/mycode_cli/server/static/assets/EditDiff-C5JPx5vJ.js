import{j as N,r as $,b as Je,a as zn,n as Fn,c as $n,d as _n,_ as qe,e as Wn,t as ce,u as Gn}from"./index-Dp879Ucn.js";const jn={position:"absolute",top:0,bottom:0,textAlign:"center"},Bn={display:"contents"};function Ze(){return null}const we="diffs-container",qn=/(?=^From [a-f0-9]+ .+$)/m,ye=/(?=^diff --git)/gm,Qe=/(?=^---\s+\S)/gm,Vn=/(?=^@@ )/gm,Kn=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: (.*))?/m,Te=new RegExp("(?<=\\n)"),Xn=/^(---|\+\+\+)\s+([^\t\r\n]+)/,Yn=/^(---|\+\+\+)\s+[ab]\/([^\t\r\n]+)/,Jn=/^diff --git (?:"a\/(.+?)"|a\/(.+?)) (?:"b\/(.+?)"|b\/(.+?))$/,Zn=/^index ([0-9a-f]+)\.\.([0-9a-f]+)(?: (\d+))?$/i,Ve="header-prefix",Ke="header-metadata",Xe="header-custom",q={dark:"pierre-dark",light:"pierre-light"},Tn="data-theme-css",An="data-unsafe-css",se=1,Qn={hunkLineCount:50,lineHeight:20,diffHeaderHeight:44,hunkSeparatorHeight:32,fileGap:8},et=Object.freeze({fromStart:0,fromEnd:0}),en={startingLine:0,totalLines:1/0,bufferBefore:0,bufferAfter:0},nt={startingLine:0,totalLines:0,bufferBefore:0,bufferAfter:0};function ue(e){return`annotation-${"side"in e?`${e.side}-`:""}${e.lineNumber}`}function tt(e,n){return typeof window>"u"&&n!=null?N.jsxs(N.Fragment,{children:[N.jsx("template",{shadowrootmode:"open",dangerouslySetInnerHTML:{__html:n}}),e]}):N.jsx(N.Fragment,{children:e})}const it=$.createContext(void 0);function rt(){return $.useContext(it)}const ee=new Map,Ae=new Map,$e=new Map,_e=new Set;function nn(e,n){e=Array.isArray(e)?e:[e];for(let t of e){let i;if(typeof t=="string"){if(i=ee.get(t),i==null)throw new Error(`loadResolvedThemes: ${t} is not resolved, you must resolve it before calling loadResolvedThemes`)}else i=t,t=t.name,ee.has(t)||ee.set(t,i);_e.has(t)||(_e.add(t),n.loadThemeSync(i))}}const he=new Map,Ie=new Map,ot=new Map,We=new Set;function tn(e,n){e=Array.isArray(e)?e:[e];for(const t of e){if(We.has(t.name))continue;let i=he.get(t.name);i==null&&(i=t,he.set(t.name,i)),We.add(i.name),n.loadLanguageSync(i.data)}}function In(){return typeof WorkerGlobalScope<"u"&&typeof self<"u"&&self instanceof WorkerGlobalScope}async function st(e){if(In())throw new Error(`resolveLanguage("${e}") cannot be called from a worker context. Languages must be pre-resolved on the main thread and passed to the worker via the resolvedLanguages parameter.`);const n=Ie.get(e);if(n!=null)return n;try{let t=ot.get(e);if(t==null&&Object.prototype.hasOwnProperty.call(Je,e)&&(t=Je[e]),t==null)throw new Error(`resolveLanguage: "${e}" not found in bundled or custom languages`);const i=t().then(({default:r})=>{const o={name:e,data:r};return he.has(e)||he.set(e,o),o});return Ie.set(e,i),await i}finally{Ie.delete(e)}}function at(e){return he.get(e)??st(e)}async function lt(e){if(In())throw new Error(`resolveTheme("${e}") cannot be called from a worker context. Themes must be pre-resolved on the main thread and passed to the worker via the resolvedLanguages parameter.`);const n=Ae.get(e);if(n!=null)return n;try{const t=$e.get(e)??zn[e];if(t==null)throw new Error(`resolveTheme: No valid loader for ${e}`);const i=t().then(o=>dt(e,"default"in o?o.default:o));Ae.set(e,i);const r=await i;if(r.name!==e)throw new Error(`resolvedTheme: themeName: ${e} does not match theme.name: ${r.name}`);return ee.set(r.name,r),r}finally{Ae.delete(e)}}function dt(e,n){const t=ee.get(e);return t??(n=Fn(n),ee.set(e,n),n)}function ft(e){return ee.get(e)??lt(e)}function Rn(e,n){if($e.has(e)){console.error("SharedHighlight.registerCustomTheme: theme name already registered",e);return}$e.set(e,n)}let B;async function ct({themes:e,langs:n,preferredHighlighter:t="shiki-js"}){B??=$n({themes:[],langs:["text"],engine:t==="shiki-wasm"?_n(qe(()=>import("./wasm-CG6Dc4jp.js"),[])):Wn()});const i=ht(B)?await B:B;B=i;const r=[];for(const a of n){if(a==="text"||a==="ansi")continue;const l=at(a);"then"in l?r.push(l):tn(l,i)}const o=[];for(const a of e){const l=ft(a);"then"in l?o.push(l):nn(l,B)}return(r.length>0||o.length>0)&&await Promise.all([Promise.all(r).then(a=>{tn(a,i)}),Promise.all(o).then(a=>{nn(a,i)})]),i}function ut(){if(B!=null&&!("then"in B))return B}function ht(e=B){return e!=null&&"then"in e}Rn("pierre-dark",async()=>{const{default:e}=await qe(async()=>{const{default:n}=await import("./pierre-dark-DF2SEV7i.js");return{default:n}},[]);return{...e,name:"pierre-dark"}});Rn("pierre-light",async()=>{const{default:e}=await qe(async()=>{const{default:n}=await import("./pierre-light-DOlZxES8.js");return{default:n}},[]);return{...e,name:"pierre-light"}});function Mn(e=q){const n=[];return typeof e=="string"?n.push(e):(n.push(e.dark),n.push(e.light)),n}function Hn(e,n){return e==null||n==null||typeof e=="string"||typeof n=="string"?e===n:e.dark===n.dark&&e.light===n.light}const re=new Map,fe={"1c":"1c",abap:"abap",as:"actionscript-3",ada:"ada",adb:"ada",ads:"ada",adoc:"asciidoc",asciidoc:"asciidoc","component.html":"angular-html","component.ts":"angular-ts",conf:"nginx",htaccess:"apache",cls:"tex",trigger:"apex",apl:"apl",applescript:"applescript",scpt:"applescript",ara:"ara",asm:"asm",s:"riscv",astro:"astro",awk:"awk",bal:"ballerina",sh:"zsh",bash:"zsh",bat:"cmd",cmd:"cmd",be:"berry",beancount:"beancount",bib:"bibtex",bicep:"bicep","blade.php":"blade",bsl:"bsl",c:"c",h:"objective-cpp",cs:"csharp",cpp:"cpp",hpp:"cpp",cc:"cpp",cxx:"cpp",hh:"cpp",cdc:"cdc",cairo:"cairo",clar:"clarity",clj:"clojure",cljs:"clojure",cljc:"clojure",soy:"soy",cmake:"cmake","CMakeLists.txt":"cmake",cob:"cobol",cbl:"cobol",cobol:"cobol",CODEOWNERS:"codeowners",ql:"ql",coffee:"coffeescript",lisp:"lisp",cl:"lisp",lsp:"lisp",log:"log",v:"verilog",cql:"cql",cr:"crystal",css:"css",csv:"csv",cue:"cue",cypher:"cypher",cyp:"cypher",d:"d",dart:"dart",dax:"dax",desktop:"desktop",diff:"diff",patch:"diff",Dockerfile:"dockerfile",dockerfile:"dockerfile",env:"dotenv",dm:"dream-maker",edge:"edge",el:"emacs-lisp",ex:"elixir",exs:"elixir",elm:"elm",erb:"erb",erl:"erlang",hrl:"erlang",f:"fortran-fixed-form",for:"fortran-fixed-form",fs:"fsharp",fsi:"fsharp",fsx:"fsharp",f03:"f03",f08:"f08",f18:"f18",f77:"f77",f90:"fortran-free-form",f95:"fortran-free-form",fnl:"fennel",fish:"fish",ftl:"ftl",tres:"gdresource",res:"gdresource",gd:"gdscript",gdshader:"gdshader",gs:"genie",feature:"gherkin",COMMIT_EDITMSG:"git-commit","git-rebase-todo":"git-rebase",gjs:"glimmer-js",gleam:"gleam",gts:"glimmer-ts",glsl:"glsl",vert:"glsl",frag:"glsl",shader:"shaderlab",gp:"gnuplot",plt:"gnuplot",gnuplot:"gnuplot",go:"go",graphql:"graphql",gql:"graphql",groovy:"groovy",gvy:"groovy",hack:"hack",haml:"haml",hbs:"handlebars",handlebars:"handlebars",hs:"haskell",lhs:"haskell",hx:"haxe",hcl:"hcl",hjson:"hjson",hlsl:"hlsl",fx:"hlsl",html:"html",htm:"html",http:"http",rest:"http",hxml:"hxml",hy:"hy",imba:"imba",ini:"ini",cfg:"ini",jade:"pug",pug:"pug",java:"java",js:"javascript",mjs:"javascript",cjs:"javascript",jinja:"jinja",jinja2:"jinja",j2:"jinja",jison:"jison",jl:"julia",json:"json",json5:"json5",jsonc:"jsonc",jsonl:"jsonl",jsonnet:"jsonnet",libsonnet:"jsonnet",jssm:"jssm",jsx:"jsx",kt:"kotlin",kts:"kts",kql:"kusto",tex:"tex",ltx:"tex",lean:"lean4",less:"less",liquid:"liquid",lit:"lit",ll:"llvm",logo:"logo",lua:"lua",luau:"luau",Makefile:"makefile",mk:"makefile",makefile:"makefile",md:"markdown",markdown:"markdown",marko:"marko",m:"wolfram",mat:"matlab",mdc:"mdc",mdx:"mdx",wiki:"wikitext",mediawiki:"wikitext",mmd:"mermaid",mermaid:"mermaid",mips:"mipsasm",mojo:"mojo","🔥":"mojo",move:"move",nar:"narrat",nf:"nextflow",nim:"nim",nims:"nim",nimble:"nim",nix:"nix",nu:"nushell",mm:"objective-cpp",ml:"ocaml",mli:"ocaml",mll:"ocaml",mly:"ocaml",pas:"pascal",p:"pascal",pl:"prolog",pm:"perl",t:"perl",raku:"raku",p6:"raku",pl6:"raku",php:"php",phtml:"php",pls:"plsql",sql:"sql",po:"po",polar:"polar",pcss:"postcss",pot:"pot",potx:"potx",pq:"powerquery",pqm:"powerquery",ps1:"powershell",psm1:"powershell",psd1:"powershell",prisma:"prisma",pro:"prolog",P:"prolog",properties:"properties",proto:"protobuf",pp:"puppet",purs:"purescript",py:"python",pyw:"python",pyi:"python",qml:"qml",qmldir:"qmldir",qss:"qss",r:"r",R:"r",rkt:"racket",rktl:"racket",razor:"razor",cshtml:"razor",rb:"ruby",rbw:"ruby",reg:"reg",regex:"regexp",rel:"rel",rs:"rust",rst:"rst",rake:"ruby",gemspec:"ruby",sas:"sas",sass:"sass",scala:"scala",sc:"scala",scm:"scheme",ss:"scheme",sld:"scheme",scss:"scss",sdbl:"sdbl",shadergraph:"shader",st:"smalltalk",sol:"solidity",sparql:"sparql",rq:"sparql",spl:"splunk",config:"ssh-config",do:"stata",ado:"stata",dta:"stata",styl:"stylus",stylus:"stylus",svelte:"svelte",swift:"swift",sv:"system-verilog",svh:"system-verilog",service:"systemd",socket:"systemd",device:"systemd",timer:"systemd",talon:"talonscript",tasl:"tasl",tcl:"tcl",templ:"templ",tf:"tf",tfvars:"tfvars",toml:"toml",ts:"typescript",tsp:"typespec",tsv:"tsv",tsx:"tsx",ttl:"turtle",twig:"twig",typ:"typst",vv:"v",vala:"vala",vapi:"vala",vb:"vb",vbs:"vb",bas:"vb",vh:"verilog",vhd:"vhdl",vhdl:"vhdl",vim:"vimscript",vue:"vue","vine.ts":"vue-vine",vy:"vyper",wasm:"wasm",wat:"wasm",wy:"文言",wgsl:"wgsl",wit:"wit",wl:"wolfram",nb:"wolfram",xml:"xml",xsl:"xsl",xslt:"xsl",yaml:"yaml",yml:"yml",zs:"zenscript",zig:"zig",zsh:"zsh",sty:"tex"};function ne(e){if(re.has(e))return re.get(e)??"text";if(fe[e]!=null)return fe[e];const n=e.match(/\.([^/\\]+\.[^/\\]+)$/);if(n!=null){if(re.has(n[1]))return re.get(n[1])??"text";if(fe[n[1]]!=null)return fe[n[1]]??"text"}const t=e.match(/\.([^.]+)$/)?.[1]??"";return re.has(t)?re.get(t)??"text":fe[t]??"text"}function ae(e){return e.replace(/\n$|\r\n$/,"")}function V(e){return{type:"text",value:e}}function T({tagName:e,children:n=[],properties:t={}}){return{type:"element",tagName:e,properties:t,children:n}}function Le({name:e,width:n=16,height:t=16,properties:i}){return T({tagName:"svg",properties:{width:n,height:t,viewBox:"0 0 16 16",...i},children:[T({tagName:"use",properties:{href:`#${e.replace(/^#/,"")}`}})]})}function pt(e){let n=e.children[0];for(;n!=null;){if(n.type==="element"&&n.tagName==="code")return n;"children"in n?n=n.children[0]:n=null}}function me(e){return T({tagName:"div",properties:{"data-gutter":""},children:e})}function mt(e,n,t,i={}){return T({tagName:"div",properties:{"data-line-type":e,"data-column-number":n,"data-line-index":t,...i},children:n!=null?[T({tagName:"span",properties:{"data-line-number-content":""},children:[V(`${n}`)]})]:void 0})}function W(e,n,t){return T({tagName:"div",properties:{"data-gutter-buffer":n,"data-buffer-size":t,"data-line-type":n==="annotation"?void 0:e,style:n==="annotation"?`grid-row: span ${t};`:`grid-row: span ${t};min-height:calc(${t} * 1lh);`}})}function gt(e,n,t){const i=typeof t.lineInfo=="function"?t.lineInfo(n):t.lineInfo[n-1];if(i==null){const r=`processLine: line ${n}, contains no state.lineInfo`;throw console.error(r,{node:e,line:n,state:t}),new Error(r)}return e.tagName="div",e.properties["data-line"]=i.lineNumber,e.properties["data-alt-line"]=i.altLineNumber,e.properties["data-line-type"]=i.type,e.properties["data-line-index"]=i.lineIndex,e.children.length===0&&e.children.push(V(`
`)),e}const ge=Symbol("no-token"),Re=Symbol("multiple-tokens");function Pn(e){const n=bt(e);if(n!=null)return n;let t=ge;const i=[];let r=[],o;const a=()=>{if(r.length===0||o==null){r=[],o=void 0;return}if(r.length===1){const s=r[0];if(s?.type==="element"){vt(s,o);for(const d of s.children)Se(d)}else Se(s);i.push(s),r=[],o=void 0;return}for(const s of r)Se(s);i.push(T({tagName:"span",properties:{"data-char":o},children:r})),r=[],o=void 0},l=s=>{if(s!==ge){if(s===Re){t=Re;return}if(t===ge){t=s;return}t!==s&&(t=Re)}};for(const s of e.children){const d=s.type==="element"?Pn(s):ge;if(l(d),typeof d!="number"){a(),i.push(s);continue}o!=null&&o!==d&&a(),o??=d,r.push(s)}return a(),e.children=i,t}function bt(e){const n=e.properties["data-char"];if(typeof n=="number")return n}function Se(e){if(e.type==="element"){e.properties["data-char"]=void 0;for(const n of e.children)Se(n)}}function vt(e,n){e.properties["data-char"]=n}function kt(e={}){const{classPrefix:n="__shiki_",classSuffix:t="",classReplacer:i=l=>l}=e,r=new Map;function o(l){return Object.entries(l).map(([s,d])=>`${s}:${d}`).join(";")}function a(l){const s=typeof l=="string"?l:o(l);let d=n+xt(s)+t;return d=i(d),r.has(d)||r.set(d,typeof l=="string"?l:{...l}),d}return{name:"@shikijs/transformers:style-to-class",pre(l){if(!l.properties.style)return;const s=a(l.properties.style);delete l.properties.style,this.addClassToHast(l,s)},tokens(l){for(const s of l)for(const d of s){if(!d.htmlStyle)continue;const f=a(d.htmlStyle);d.htmlStyle={},d.htmlAttrs||={},d.htmlAttrs.class?d.htmlAttrs.class+=` ${f}`:d.htmlAttrs.class=f}},getClassRegistry(){return r},getCSS(){let l="";for(const[s,d]of r.entries())l+=`.${s}{${typeof d=="string"?d:o(d)}}`;return l},clearRegistry(){r.clear()}}}function xt(e,n=0){let t=3735928559^n,i=1103547991^n;for(let r=0,o;r<e.length;r++)o=e.charCodeAt(r),t=Math.imul(t^o,2654435761),i=Math.imul(i^o,1597334677);return t=Math.imul(t^t>>>16,2246822507),t^=Math.imul(i^i>>>13,3266489909),i=Math.imul(i^i>>>16,2246822507),i^=Math.imul(t^t>>>13,3266489909),(4294967296*(2097151&i)+(t>>>0)).toString(36).slice(0,6)}function yt(e=!1,n=!1){const t={lineInfo:[]},i=[{line(r){return delete r.properties.class,r},pre(r){const o=pt(r),a=[];if(o!=null){let l=1;for(const s of o.children)s.type==="element"&&(e&&Pn(s),a.push(gt(s,l,t)),l++);o.children=a}return r},...e?{tokens(r){for(const o of r){let a=0;for(const l of o){const s=l;s.__lineChar??=a,a+=l.content.length}}},preprocess(r,o){o.mergeWhitespaces="never"},span(r,o,a,l,s){if(s?.offset!=null&&s.content!=null){const d=s.__lineChar;return d!=null&&(r.properties["data-char"]=d),r}return r}}:null}];return n&&i.push(St,rn),{state:t,transformers:i,toClass:rn}}const rn=kt({classPrefix:"hl-"}),St={name:"token-style-normalizer",tokens(e){for(const n of e)for(const t of n){if(t.htmlStyle!=null)continue;const i={};t.color!=null&&(i.color=t.color),t.bgColor!=null&&(i["background-color"]=t.bgColor),t.fontStyle!=null&&t.fontStyle!==0&&((t.fontStyle&1)!==0&&(i["font-style"]="italic"),(t.fontStyle&2)!==0&&(i["font-weight"]="bold"),(t.fontStyle&4)!==0&&(i["text-decoration"]="underline")),Object.keys(i).length>0&&(t.htmlStyle=i)}}};function G(e){return`--${e==="token"?"diffs-token":"diffs"}-`}function Ct({theme:e=q,highlighter:n,prefix:t}){let i="";if(typeof e=="string"){const r=n.getTheme(e);i+=`color:${r.fg};`,i+=`background-color:${r.bg};`,i+=`${G("global")}fg:${r.fg};`,i+=`${G("global")}bg:${r.bg};`,i+=Me(r,t)}else{let r=n.getTheme(e.dark);i+=`${G("global")}dark:${r.fg};`,i+=`${G("global")}dark-bg:${r.bg};`,i+=Me(r,"dark"),r=n.getTheme(e.light),i+=`${G("global")}light:${r.fg};`,i+=`${G("global")}light-bg:${r.bg};`,i+=Me(r,"light")}return i}function Me(e,n){n=n!=null?`${n}-`:"";let t="";const i=e.colors?.["gitDecoration.addedResourceForeground"]??e.colors?.["terminal.ansiGreen"];i!=null&&(t+=`${G("global")}${n}addition-color:${i};`);const r=e.colors?.["gitDecoration.deletedResourceForeground"]??e.colors?.["terminal.ansiRed"];r!=null&&(t+=`${G("global")}${n}deletion-color:${r};`);const o=e.colors?.["gitDecoration.modifiedResourceForeground"]??e.colors?.["terminal.ansiBlue"];return o!=null&&(t+=`${G("global")}${n}modified-color:${o};`),t}function on(e){let n=e.children[0];for(;n!=null;){if(n.type==="element"&&n.tagName==="code")return n.children;"children"in n?n=n.children[0]:n=null}throw console.error(e),new Error("getLineNodes: Unable to find children")}function sn(e,n){return e?.cacheKey===n?.cacheKey&&e?.contents===n?.contents&&e?.name===n?.name&&e?.lang===n?.lang}function He(e,n){return Hn(e.theme,n.theme)&&e.useTokenTransformer===n.useTokenTransformer&&e.tokenizeMaxLineLength===n.tokenizeMaxLineLength&&e.lineDiffType===n.lineDiffType&&e.maxLineDiffLength===n.maxLineDiffLength}function wt(e){const n=e.lang??ne(e.name),t=e.lang??(e.prevName!=null?ne(e.prevName):"text");return n==="text"&&t==="text"}function Ee({diff:e,diffStyle:n,startingLine:t=0,totalLines:i=1/0,expandedHunks:r,collapsedContextThreshold:o=se,callback:a}){const l={finalHunk:e.hunks.at(-1),viewportStart:t,viewportEnd:t+i,isWindowedHighlight:t>0||i<1/0,splitCount:0,unifiedCount:0,shouldBreak(){if(!l.isWindowedHighlight)return!1;const s=l.unifiedCount>=t+i,d=l.splitCount>=t+i;return n==="unified"?s:(n==="split"||s)&&d},shouldSkip(s,d){if(!l.isWindowedHighlight)return!1;const f=l.unifiedCount+s<t,c=l.splitCount+d<t;return n==="unified"?f:(n==="split"||f)&&c},incrementCounts(s,d){(n==="unified"||n==="both")&&(l.unifiedCount+=s),(n==="split"||n==="both")&&(l.splitCount+=d)},isInWindow(s,d){if(!l.isWindowedHighlight)return!0;const f=l.isInUnifiedWindow(s),c=l.isInSplitWindow(d);return n==="unified"?f:n==="split"?c:f||c},isInUnifiedWindow(s){return!l.isWindowedHighlight||l.unifiedCount>=t-s&&l.unifiedCount<t+i},isInSplitWindow(s){return!l.isWindowedHighlight||l.splitCount>=t-s&&l.splitCount<t+i},emit(s,d=!1){return d||(n==="unified"?l.incrementCounts(1,0):n==="split"?l.incrementCounts(0,1):l.incrementCounts(1,1)),a(s)??!1}};e:for(const[s,d]of e.hunks.entries()){let u=function(g,k){return c==null||c.collapsedLines<=0||c.fromStart+c.fromEnd>0?0:n==="unified"?g===d.unifiedLineStart+d.unifiedLineCount-1?c.collapsedLines:0:k===d.splitLineStart+d.splitLineCount-1?c.collapsedLines:0},m=function(){if(f.collapsedLines===0)return 0;const g=f.collapsedLines;return f.collapsedLines=0,g};if(l.shouldBreak())break;const f=an(e.isPartial,d.collapsedBefore,r,s,o),c=(()=>{if(d!==l.finalHunk||!Lt(e))return;const g=e.additionLines.length-(d.additionLineIndex+d.additionCount),k=e.deletionLines.length-(d.deletionLineIndex+d.deletionCount);if(g!==k)throw new Error(`iterateOverDiff: trailing context mismatch (additions=${g}, deletions=${k}) for ${e.name}`);const w=Math.min(g,k);return an(e.isPartial,w,r,e.hunks.length,o)})(),h=f.fromStart+f.fromEnd;if(l.shouldSkip(h,h))l.incrementCounts(h,h),m();else{let g=d.unifiedLineStart-f.rangeSize,k=d.splitLineStart-f.rangeSize,w=d.deletionLineIndex-f.rangeSize,L=d.additionLineIndex-f.rangeSize,E=d.deletionStart-f.rangeSize,A=d.additionStart-f.rangeSize,I=0;for(;I<f.fromStart;){if(l.isInWindow(0,0)){if(l.emit({hunkIndex:s,hunk:d,collapsedBefore:0,collapsedAfter:0,type:"context-expanded",deletionLine:{lineNumber:E+I,lineIndex:w+I,noEOFCR:!1,unifiedLineIndex:g+I,splitLineIndex:k+I},additionLine:{unifiedLineIndex:g+I,splitLineIndex:k+I,lineIndex:L+I,lineNumber:A+I,noEOFCR:!1}}))break e}else l.incrementCounts(1,1);I++}for(g=d.unifiedLineStart-f.fromEnd,k=d.splitLineStart-f.fromEnd,w=d.deletionLineIndex-f.fromEnd,L=d.additionLineIndex-f.fromEnd,E=d.deletionStart-f.fromEnd,A=d.additionStart-f.fromEnd,I=0;I<f.fromEnd;){if(l.isInWindow(0,0)){if(l.emit({hunkIndex:s,hunk:d,collapsedBefore:m(),collapsedAfter:0,type:"context-expanded",deletionLine:{lineNumber:E+I,lineIndex:w+I,noEOFCR:!1,unifiedLineIndex:g+I,splitLineIndex:k+I},additionLine:{unifiedLineIndex:g+I,splitLineIndex:k+I,lineIndex:L+I,lineNumber:A+I,noEOFCR:!1}}))break e}else l.incrementCounts(1,1);I++}}let x=d.unifiedLineStart,y=d.splitLineStart,C=d.deletionLineIndex,p=d.additionLineIndex,b=d.deletionStart,v=d.additionStart;const S=d.hunkContent.at(-1);for(const g of d.hunkContent){if(l.shouldBreak())break e;const k=g===S;if(g.type==="context"){if(l.shouldSkip(g.lines,g.lines))l.incrementCounts(g.lines,g.lines),m();else{let w=0;for(;w<g.lines;){if(l.isInWindow(0,0)){const L=k&&w===g.lines-1,E=x+w,A=y+w;if(l.emit({hunkIndex:s,hunk:d,collapsedBefore:m(),collapsedAfter:u(E,A),type:"context",deletionLine:{lineNumber:b+w,lineIndex:C+w,noEOFCR:L&&d.noEOFCRDeletions,unifiedLineIndex:E,splitLineIndex:A},additionLine:{unifiedLineIndex:E,splitLineIndex:A,lineIndex:p+w,lineNumber:v+w,noEOFCR:L&&d.noEOFCRAdditions}}))break e}else l.incrementCounts(1,1);w++}}x+=g.lines,y+=g.lines,C+=g.lines,p+=g.lines,b+=g.lines,v+=g.lines}else{const w=Math.max(g.deletions,g.additions),L=g.deletions+g.additions;if(!l.shouldSkip(L,w)){const E=Et(l,g,n);for(const[A,I]of E)for(let R=A;R<I;R++){const U=u(x+R,n==="unified"?y+(R<g.deletions?R:R-g.deletions):y+R);if(l.emit(Tt({hunkIndex:s,hunk:d,collapsedBefore:m(),collapsedAfter:U,diffStyle:n,index:R,unifiedLineIndex:x,splitLineIndex:y,additionLineIndex:p,deletionLineIndex:C,additionLineNumber:v,deletionLineNumber:b,content:g,isLastContent:k,unifiedCount:L,splitCount:w}),!0))break e}}m(),l.incrementCounts(L,w),x+=L,y+=w,C+=g.deletions,p+=g.additions,b+=g.deletions,v+=g.additions}}if(c!=null){const{collapsedLines:g,fromStart:k,fromEnd:w}=c,L=k+w;let E=0;for(;E<L;){if(l.shouldBreak())break e;if(l.isInWindow(0,0)){const A=E===L-1;if(l.emit({hunkIndex:e.hunks.length,hunk:void 0,collapsedBefore:0,collapsedAfter:A?g:0,type:"context-expanded",deletionLine:{lineNumber:b+E,lineIndex:C+E,noEOFCR:!1,unifiedLineIndex:x+E,splitLineIndex:y+E},additionLine:{unifiedLineIndex:x+E,splitLineIndex:y+E,lineIndex:p+E,lineNumber:v+E,noEOFCR:!1}}))break e}else l.incrementCounts(1,1);E++}}}}function an(e,n,t,i,r){if(n=Math.max(n,0),n===0||e)return{fromStart:0,fromEnd:0,rangeSize:n,collapsedLines:Math.max(n,0)};if(t===!0||n<=r)return{fromStart:n,fromEnd:0,rangeSize:n,collapsedLines:0};const o=t?.get(i),a=Math.min(Math.max(o?.fromStart??0,0),n),l=Math.min(Math.max(o?.fromEnd??0,0),n),s=a+l,d=s>=n;return{fromStart:d?n:a,fromEnd:d?0:l,rangeSize:n,collapsedLines:Math.max(n-s,0)}}function Lt(e){const n=e.hunks.at(-1);return n==null||e.isPartial||e.additionLines.length===0||e.deletionLines.length===0?!1:n.additionLineIndex+n.additionCount<e.additionLines.length||n.deletionLineIndex+n.deletionCount<e.deletionLines.length}function Et(e,n,t){if(!e.isWindowedHighlight)return[[0,t==="unified"?n.deletions+n.additions:Math.max(n.deletions,n.additions)]];const i=t!=="split",r=t!=="unified",o=t==="unified"?"unified":"split",a=[];function l(c,h){if(c+h<=e.viewportStart||c>=e.viewportEnd)return;const u=Math.max(0,e.viewportStart-c),m=Math.min(h,e.viewportEnd-c);return m>u?[u,m]:void 0}function s(c,h){return o==="split"?c:h==="additions"?[c[0]+n.deletions,c[1]+n.deletions]:c}function d(c,h){if(c==null)return;const[u,m]=s(c,h);m>u&&a.push([u,m])}if(i&&(d(l(e.unifiedCount,n.deletions),"deletions"),d(l(e.unifiedCount+n.deletions,n.additions),"additions")),r&&(d(l(e.splitCount,n.deletions),"deletions"),d(l(e.splitCount,n.additions),"additions")),a.length===0)return a;a.sort((c,h)=>c[0]-h[0]);const f=[a[0]];for(const[c,h]of a.slice(1)){const u=f[f.length-1];c<=u[1]?u[1]=Math.max(u[1],h):f.push([c,h])}return f}function Tt({hunkIndex:e,hunk:n,collapsedAfter:t,collapsedBefore:i,diffStyle:r,index:o,unifiedLineIndex:a,splitLineIndex:l,additionLineIndex:s,deletionLineIndex:d,additionLineNumber:f,deletionLineNumber:c,content:h,isLastContent:u,unifiedCount:m,splitCount:x}){const y=o<h.deletions?a+o:void 0,C=r==="unified"?o>=h.deletions?a+o:void 0:o<h.additions?a+h.deletions+o:void 0,p=r==="unified"?l+(o<h.deletions?o:o-h.deletions):l+o,b=o<h.deletions?d+o:void 0,v=o<h.deletions?c+o:void 0,S=r==="unified"?o>=h.deletions?s+(o-h.deletions):void 0:o<h.additions?s+o:void 0,g=r==="unified"?o>=h.deletions?f+(o-h.deletions):void 0:o<h.additions?f+o:void 0,k=r==="unified"?u&&o===h.deletions-1&&n.noEOFCRDeletions:u&&o===x-1&&n.noEOFCRDeletions,w=r==="unified"?u&&o===m-1&&n.noEOFCRAdditions:u&&o===x-1&&n.noEOFCRAdditions,L=b!=null&&v!=null&&y!=null?{lineNumber:v,lineIndex:b,noEOFCR:k,unifiedLineIndex:y,splitLineIndex:p}:void 0,E=S!=null&&g!=null&&C!=null?{unifiedLineIndex:C,splitLineIndex:p,lineIndex:S,lineNumber:g,noEOFCR:w}:void 0;if(L==null&&E!=null)return{type:"change",hunkIndex:e,hunk:n,collapsedAfter:t,collapsedBefore:i,deletionLine:void 0,additionLine:E};if(L!=null&&E==null)return{type:"change",hunkIndex:e,hunk:n,collapsedAfter:t,collapsedBefore:i,deletionLine:L,additionLine:void 0};if(L==null||E==null)throw new Error("iterateOverDiff: missing change line data");return{type:"change",hunkIndex:e,hunk:n,collapsedAfter:t,collapsedBefore:i,deletionLine:L,additionLine:E}}class Ye{diff(n,t,i={}){let r;typeof i=="function"?(r=i,i={}):"callback"in i&&(r=i.callback);const o=this.castInput(n,i),a=this.castInput(t,i),l=this.removeEmpty(this.tokenize(o,i)),s=this.removeEmpty(this.tokenize(a,i));return this.diffWithOptionsObj(l,s,i,r)}diffWithOptionsObj(n,t,i,r){var o;const a=p=>{if(p=this.postProcess(p,i),r){setTimeout(function(){r(p)},0);return}else return p},l=t.length,s=n.length;let d=1,f=l+s;i.maxEditLength!=null&&(f=Math.min(f,i.maxEditLength));const c=(o=i.timeout)!==null&&o!==void 0?o:1/0,h=Date.now()+c,u=[{oldPos:-1,lastComponent:void 0}];let m=this.extractCommon(u[0],t,n,0,i);if(u[0].oldPos+1>=s&&m+1>=l)return a(this.buildValues(u[0].lastComponent,t,n));let x=-1/0,y=1/0;const C=()=>{for(let p=Math.max(x,-d);p<=Math.min(y,d);p+=2){let b;const v=u[p-1],S=u[p+1];v&&(u[p-1]=void 0);let g=!1;if(S){const w=S.oldPos-p;g=S&&0<=w&&w<l}const k=v&&v.oldPos+1<s;if(!g&&!k){u[p]=void 0;continue}if(!k||g&&v.oldPos<S.oldPos?b=this.addToPath(S,!0,!1,0,i):b=this.addToPath(v,!1,!0,1,i),m=this.extractCommon(b,t,n,p,i),b.oldPos+1>=s&&m+1>=l)return a(this.buildValues(b.lastComponent,t,n))||!0;u[p]=b,b.oldPos+1>=s&&(y=Math.min(y,p-1)),m+1>=l&&(x=Math.max(x,p+1))}d++};if(r)(function p(){setTimeout(function(){if(d>f||Date.now()>h)return r(void 0);C()||p()},0)})();else for(;d<=f&&Date.now()<=h;){const p=C();if(p)return p}}addToPath(n,t,i,r,o){const a=n.lastComponent;return a&&!o.oneChangePerToken&&a.added===t&&a.removed===i?{oldPos:n.oldPos+r,lastComponent:{count:a.count+1,added:t,removed:i,previousComponent:a.previousComponent}}:{oldPos:n.oldPos+r,lastComponent:{count:1,added:t,removed:i,previousComponent:a}}}extractCommon(n,t,i,r,o){const a=t.length,l=i.length;let s=n.oldPos,d=s-r,f=0;for(;d+1<a&&s+1<l&&this.equals(i[s+1],t[d+1],o);)d++,s++,f++,o.oneChangePerToken&&(n.lastComponent={count:1,previousComponent:n.lastComponent,added:!1,removed:!1});return f&&!o.oneChangePerToken&&(n.lastComponent={count:f,previousComponent:n.lastComponent,added:!1,removed:!1}),n.oldPos=s,d}equals(n,t,i){return i.comparator?i.comparator(n,t):n===t||!!i.ignoreCase&&n.toLowerCase()===t.toLowerCase()}removeEmpty(n){const t=[];for(let i=0;i<n.length;i++)n[i]&&t.push(n[i]);return t}castInput(n,t){return n}tokenize(n,t){return Array.from(n)}join(n){return n.join("")}postProcess(n,t){return n}get useLongestToken(){return!1}buildValues(n,t,i){const r=[];let o;for(;n;)r.push(n),o=n.previousComponent,delete n.previousComponent,n=o;r.reverse();const a=r.length;let l=0,s=0,d=0;for(;l<a;l++){const f=r[l];if(f.removed)f.value=this.join(i.slice(d,d+f.count)),d+=f.count;else{if(!f.added&&this.useLongestToken){let c=t.slice(s,s+f.count);c=c.map(function(h,u){const m=i[d+u];return m.length>h.length?m:h}),f.value=this.join(c)}else f.value=this.join(t.slice(s,s+f.count));s+=f.count,f.added||(d+=f.count)}}return r}}class At extends Ye{}const It=new At;function Rt(e,n,t){return It.diff(e,n,t)}const ln="a-zA-Z0-9_\\u{AD}\\u{C0}-\\u{D6}\\u{D8}-\\u{F6}\\u{F8}-\\u{2C6}\\u{2C8}-\\u{2D7}\\u{2DE}-\\u{2FF}\\u{1E00}-\\u{1EFF}";class Mt extends Ye{tokenize(n){const t=new RegExp(`(\\r?\\n)|[${ln}]+|[^\\S\\n\\r]+|[^${ln}]`,"ug");return n.match(t)||[]}}const Ht=new Mt;function Pt(e,n,t){return Ht.diff(e,n,t)}class Dt extends Ye{constructor(){super(...arguments),this.tokenize=Ut}equals(n,t,i){return i.ignoreWhitespace?((!i.newlineIsToken||!n.includes(`
`))&&(n=n.trim()),(!i.newlineIsToken||!t.includes(`
`))&&(t=t.trim())):i.ignoreNewlineAtEof&&!i.newlineIsToken&&(n.endsWith(`
`)&&(n=n.slice(0,-1)),t.endsWith(`
`)&&(t=t.slice(0,-1))),super.equals(n,t,i)}}const Nt=new Dt;function dn(e,n,t){return Nt.diff(e,n,t)}function Ut(e,n){n.stripTrailingCr&&(e=e.replace(/\r\n/g,`
`));const t=[],i=e.split(/(\n|\r\n)/);i[i.length-1]||i.pop();for(let r=0;r<i.length;r++){const o=i[r];r%2&&!n.newlineIsToken?t[t.length-1]+=o:t.push(o)}return t}const Ot={includeIndex:!0,includeUnderline:!0,includeFileHeaders:!0};function fn(e,n,t,i,r,o,a){let l;a?typeof a=="function"?l={callback:a}:l=a:l={},typeof l.context>"u"&&(l.context=4);const s=l.context;if(l.newlineIsToken)throw new Error("newlineIsToken may not be used with patch-generation functions, only with diffing functions");if(l.callback){const{callback:f}=l;dn(t,i,Object.assign(Object.assign({},l),{callback:c=>{const h=d(c);f(h)}}))}else return d(dn(t,i,l));function d(f){if(!f)return;f.push({value:"",lines:[]});function c(p){return p.map(function(b){return" "+b})}const h=[];let u=0,m=0,x=[],y=1,C=1;for(let p=0;p<f.length;p++){const b=f[p],v=b.lines||Ft(b.value);if(b.lines=v,b.added||b.removed){if(!u){const S=f[p-1];u=y,m=C,S&&(x=s>0?c(S.lines.slice(-s)):[],u-=x.length,m-=x.length)}for(const S of v)x.push((b.added?"+":"-")+S);b.added?C+=v.length:y+=v.length}else{if(u)if(v.length<=s*2&&p<f.length-2)for(const S of c(v))x.push(S);else{const S=Math.min(v.length,s);for(const k of c(v.slice(0,S)))x.push(k);const g={oldStart:u,oldLines:y-u+S,newStart:m,newLines:C-m+S,lines:x};h.push(g),u=0,m=0,x=[]}y+=v.length,C+=v.length}}for(const p of h)for(let b=0;b<p.lines.length;b++)p.lines[b].endsWith(`
`)?p.lines[b]=p.lines[b].slice(0,-1):(p.lines.splice(b+1,0,"\\ No newline at end of file"),b++);return{oldFileName:e,newFileName:n,oldHeader:r,newHeader:o,hunks:h}}}function Ge(e,n){if(n||(n=Ot),Array.isArray(e)){if(e.length>1&&!n.includeFileHeaders)throw new Error("Cannot omit file headers on a multi-file patch. (The result would be unparseable; how would a tool trying to apply the patch know which changes are to which file?)");return e.map(i=>Ge(i,n)).join(`
`)}const t=[];n.includeIndex&&e.oldFileName==e.newFileName&&t.push("Index: "+e.oldFileName),n.includeUnderline&&t.push("==================================================================="),n.includeFileHeaders&&(t.push("--- "+e.oldFileName+(typeof e.oldHeader>"u"?"":"	"+e.oldHeader)),t.push("+++ "+e.newFileName+(typeof e.newHeader>"u"?"":"	"+e.newHeader)));for(let i=0;i<e.hunks.length;i++){const r=e.hunks[i];r.oldLines===0&&(r.oldStart-=1),r.newLines===0&&(r.newStart-=1),t.push("@@ -"+r.oldStart+","+r.oldLines+" +"+r.newStart+","+r.newLines+" @@");for(const o of r.lines)t.push(o)}return t.join(`
`)+`
`}function zt(e,n,t,i,r,o,a){if(typeof a=="function"&&(a={callback:a}),a?.callback){const{callback:l}=a;fn(e,n,t,i,r,o,Object.assign(Object.assign({},a),{callback:s=>{l(s?Ge(s,a.headerOptions):void 0)}}))}else{const l=fn(e,n,t,i,r,o,a);return l?Ge(l,a?.headerOptions):void 0}}function Ft(e){const n=e.endsWith(`
`),t=e.split(`
`).map(i=>i+`
`);return n?t.pop():t.push(t.pop().slice(0,-1)),t}function cn({line:e,spanStart:n,spanLength:t}){return{start:{line:e,character:n},end:{line:e,character:n+t},properties:{"data-diff-span":""},alwaysWrap:!0}}function be({item:e,arr:n,enableJoin:t,isNeutral:i=!1,isLastItem:r=!1}){const o=n[n.length-1];if(o==null||r||!t){n.push([i?0:1,e.value]);return}const a=o[0]===0;if(i===a||i&&e.value.length===1&&!a){o[1]+=e.value;return}n.push([i?0:1,e.value])}const $t={forcePlainText:!1};function _t(e,n,t,{forcePlainText:i,startingLine:r,totalLines:o,expandedHunks:a,collapsedContextThreshold:l=se}=$t){i?(r??=0,o??=1/0):(r=0,o=1/0);const s=r>0||o<1/0,d=typeof t.theme=="string"?n.getTheme(t.theme).type:void 0,f=Ct({theme:t.theme,highlighter:n}),c=i&&!s&&(e.unifiedLineCount>1e3||e.splitLineCount>1e3)?"none":t.lineDiffType,h={deletionLines:[],additionLines:[]},{maxLineDiffLength:u}=t,m=!i&&!e.isPartial,x=i?a:void 0,y=new Map;function C(b){const v=m?0:b,S=y.get(v)??Gt();return y.set(v,S),S}function p(b,v,S,g){if(s){let k=S.at(-1);(k==null||k.targetIndex+k.count!==v)&&(k={targetIndex:v,originalOffset:g.length,count:0},S.push(k)),k.count++}g.push(b)}Ee({diff:e,diffStyle:"both",startingLine:r,totalLines:o,expandedHunks:s?x:!0,collapsedContextThreshold:l,callback:({hunkIndex:b,additionLine:v,deletionLine:S,type:g})=>{const k=C(b),w=v!=null?v.splitLineIndex:S.splitLineIndex;g==="change"&&v!=null&&S!=null&&Wt({additionLine:e.additionLines[v.lineIndex],deletionLine:e.deletionLines[S.lineIndex],deletionLineIndex:k.deletionContent.length,additionLineIndex:k.additionContent.length,deletionDecorations:k.deletionDecorations,additionDecorations:k.additionDecorations,lineDiffType:c,maxLineDiffLength:u}),S!=null&&(p(e.deletionLines[S.lineIndex],S.lineIndex,k.deletionSegments,k.deletionContent),k.deletionInfo.push({type:g==="change"?"change-deletion":g,lineNumber:S.lineNumber,altLineNumber:g==="change"?void 0:v.lineNumber??void 0,lineIndex:`${S.unifiedLineIndex},${w}`})),v!=null&&(p(e.additionLines[v.lineIndex],v.lineIndex,k.additionSegments,k.additionContent),k.additionInfo.push({type:g==="change"?"change-addition":g,lineNumber:v.lineNumber,altLineNumber:g==="change"?void 0:S.lineNumber??void 0,lineIndex:`${v.unifiedLineIndex},${w}`}))}});for(const b of y.values()){if(b.deletionContent.length===0&&b.additionContent.length===0)continue;const v={name:e.prevName??e.name,contents:b.deletionContent.value},S={name:e.name,contents:b.additionContent.value},{deletionLines:g,additionLines:k}=jt({deletionFile:v,deletionInfo:b.deletionInfo,deletionDecorations:b.deletionDecorations,additionFile:S,additionInfo:b.additionInfo,additionDecorations:b.additionDecorations,highlighter:n,options:t,languageOverride:i?"text":e.lang});if(m){h.deletionLines=g,h.additionLines=k;continue}if(b.deletionSegments.length>0)for(const w of b.deletionSegments)for(let L=0;L<w.count;L++)h.deletionLines[w.targetIndex+L]=g[w.originalOffset+L];else h.deletionLines.push(...g);if(b.additionSegments.length>0)for(const w of b.additionSegments)for(let L=0;L<w.count;L++)h.additionLines[w.targetIndex+L]=k[w.originalOffset+L];else h.additionLines.push(...k)}return{code:h,themeStyles:f,baseThemeType:d}}function Wt({deletionLine:e,additionLine:n,deletionLineIndex:t,additionLineIndex:i,deletionDecorations:r,additionDecorations:o,lineDiffType:a,maxLineDiffLength:l}){if(e==null||n==null||a==="none"||(e=ae(e),n=ae(n),e.length>l||n.length>l))return;const s=a==="char"?Rt(e,n):Pt(e,n),d=[],f=[],c=a==="word-alt",h=s.at(-1);for(const m of s){const x=m===h;!m.added&&!m.removed?(be({item:m,arr:d,enableJoin:c,isNeutral:!0,isLastItem:x}),be({item:m,arr:f,enableJoin:c,isNeutral:!0,isLastItem:x})):m.removed?be({item:m,arr:d,enableJoin:c,isLastItem:x}):be({item:m,arr:f,enableJoin:c,isLastItem:x})}let u=0;for(const m of d)m[0]===1&&r.push(cn({line:t,spanStart:u,spanLength:m[1].length})),u+=m[1].length;u=0;for(const m of f)m[0]===1&&o.push(cn({line:i,spanStart:u,spanLength:m[1].length})),u+=m[1].length}function Gt(){return{deletionContent:{push(e){this.value+=e,this.length++},value:"",length:0},additionContent:{push(e){this.value+=e,this.length++},value:"",length:0},deletionInfo:[],additionInfo:[],deletionDecorations:[],additionDecorations:[],deletionSegments:[],additionSegments:[]}}function jt({deletionFile:e,additionFile:n,deletionInfo:t,additionInfo:i,highlighter:r,deletionDecorations:o,additionDecorations:a,languageOverride:l,options:{theme:s=q,...d}}){const f=l??ne(e.name),c=l??ne(n.name),{state:h,transformers:u}=yt(d.useTokenTransformer),m=typeof s=="string"?{...d,lang:"text",theme:s,transformers:u,decorations:void 0,defaultColor:!1,cssVariablePrefix:G("token")}:{...d,lang:"text",themes:s,transformers:u,decorations:void 0,defaultColor:!1,cssVariablePrefix:G("token")};return{deletionLines:e.contents===""?[]:(m.lang=f,h.lineInfo=t,m.decorations=o,on(r.codeToHast(ae(e.contents),m))),additionLines:n.contents===""?[]:(m.lang=c,m.decorations=a,h.lineInfo=i,on(r.codeToHast(ae(n.contents),m)))}}const Bt=$.createContext(void 0);function qt(e){const n=$.useRef(e);return $.useInsertionEffect(()=>{n.current=e}),$.useCallback((...t)=>n.current(...t),[])}function Vt(e,n){return e.lineNumber===n.lineNumber&&e.side===n.side}function un(e,n){return e?.start===n?.start&&e?.end===n?.end&&e?.side===n?.side&&e?.endSide===n?.endSide}function Kt(){return T({tagName:"button",properties:{"data-utility-button":"",type:"button"},children:[Le({name:"diffs-icon-plus",properties:{"data-icon":""}})]})}var Xt=class{hoveredLine;hoveredToken;pre;gutterUtilityContainer;gutterUtilityButton;gutterUtilitySlot;interactiveLinesAttr=!1;interactiveLineNumbersAttr=!1;hasPointerListeners=!1;hasDocumentPointerListeners=!1;selectedRange=null;renderedSelectionRange;selectionAnchor;queuedSelectionRender;pointerSession={mode:"idle"};constructor(e,n){this.mode=e,this.options=n}setOptions(e){this.options=e}cleanUp(){this.pre?.removeEventListener("click",this.handlePointerClick),this.pre?.removeEventListener("pointerdown",this.handlePointerDown),this.pre?.removeEventListener("pointermove",this.handlePointerMove),this.pre?.removeEventListener("pointerleave",this.handlePointerLeave),this.pre?.removeAttribute("data-interactive-lines"),this.pre?.removeAttribute("data-interactive-line-numbers"),this.pre=void 0,this.gutterUtilityContainer?.remove(),this.gutterUtilityContainer=void 0,this.gutterUtilityButton=void 0,this.gutterUtilitySlot=void 0,this.clearHoveredLine(),this.clearHoveredToken(),this.detachDocumentPointerListeners(),this.clearPointerSession(),this.queuedSelectionRender!=null&&(cancelAnimationFrame(this.queuedSelectionRender),this.queuedSelectionRender=void 0),this.interactiveLinesAttr=!1,this.interactiveLineNumbersAttr=!1,this.hasPointerListeners=!1}setup(e){this.setSelectionDirty();const{usesCustomGutterUtility:n=!1,enableGutterUtility:t=!1}=this.options;this.pre!==e&&(this.cleanUp(),this.pre=e),t?this.ensureGutterUtilityNode(n):this.gutterUtilityContainer!=null&&(this.gutterUtilityContainer.remove(),this.gutterUtilityContainer=void 0,this.gutterUtilityButton=void 0,this.gutterUtilitySlot=void 0,this.pointerSession.mode==="gutterSelecting"&&(this.clearPointerSession(),this.detachDocumentPointerListeners())),this.syncPointerListeners(e),this.updateInteractiveLineAttributes(),this.renderSelection()}setSelectionDirty(){this.renderedSelectionRange=void 0}isSelectionDirty(){return this.renderedSelectionRange===null}setSelection(e){const n=!(e===this.selectedRange||un(e??void 0,this.selectedRange??void 0));!this.isSelectionDirty()&&!n||(this.selectedRange=e,this.renderSelection(),n&&this.notifySelectionCommitted())}getSelection(){return this.selectedRange}getHoveredLine=()=>{if(this.hoveredLine!=null){if(this.mode==="diff"&&this.hoveredLine.type==="diff-line")return{lineNumber:this.hoveredLine.lineNumber,side:this.hoveredLine.annotationSide};if(this.mode==="file"&&this.hoveredLine.type==="line")return{lineNumber:this.hoveredLine.lineNumber}}};handlePointerClick=e=>{const{onHunkExpand:n,onLineClick:t,onLineNumberClick:i,onTokenClick:r,onMergeConflictActionClick:o}=this.options;n==null&&t==null&&i==null&&o==null&&r==null||this.options.onGutterUtilityClick!=null&&bn(e.composedPath())||(Y(this.options.__debugPointerEvents,"click","FileDiff.DEBUG.handlePointerClick:",e),this.handlePointerEvent({eventType:"click",event:e}))};handlePointerMove=e=>{const{lineHoverHighlight:n="disabled",onLineEnter:t,onLineLeave:i,onTokenEnter:r,onTokenLeave:o,enableGutterUtility:a=!1}=this.options;n==="disabled"&&!a&&t==null&&i==null&&r==null&&o==null||(Y(this.options.__debugPointerEvents,"move","FileDiff.DEBUG.handlePointerMove:",e),this.handlePointerEvent({eventType:"move",event:e}))};handlePointerLeave=e=>{const{__debugPointerEvents:n}=this.options;if(Y(n,"move","FileDiff.DEBUG.handlePointerLeave: no event"),this.hoveredLine==null&&this.hoveredToken==null){Y(n,"move","FileDiff.DEBUG.handlePointerLeave: returned early, no hovered line or token");return}this.gutterUtilityContainer?.remove(),this.hoveredToken!=null&&(this.options.onTokenLeave?.(this.hoveredToken,e),this.clearHoveredToken()),this.hoveredLine!=null&&(this.options.onLineLeave?.({...this.hoveredLine,event:e}),this.clearHoveredLine())};handlePointerEvent({eventType:e,event:n}){const{__debugPointerEvents:t}=this.options,i=n.composedPath();Y(t,e,"FileDiff.DEBUG.handlePointerEvent:",{eventType:e,composedPath:i});const r=this.resolvePointerTarget(i);Y(t,e,"FileDiff.DEBUG.handlePointerEvent: resolvePointerTarget result:",r);const{onLineClick:o,onLineNumberClick:a,onLineEnter:l,onLineLeave:s,onTokenClick:d,onTokenEnter:f,onTokenLeave:c,onHunkExpand:h,onMergeConflictActionClick:u}=this.options;switch(e){case"move":{const m=Pe(r)&&this.hoveredLine?.lineElement===r.lineElement;Ce(r)&&this.hoveredToken?.tokenElement===r.tokenElement||(this.hoveredToken!=null&&(c?.(this.hoveredToken,n),this.clearHoveredToken()),Ce(r)&&(this.setHoveredToken(this.toTokenEventBaseProps(r)),f?.(this.hoveredToken,n))),m||(this.hoveredLine!=null&&(this.gutterUtilityContainer?.remove(),s?.({...this.hoveredLine,event:n}),this.clearHoveredLine()),Pe(r)&&(this.setHoveredLine(this.toEventBaseProps(r)),this.gutterUtilityContainer!=null&&r.numberElement.appendChild(this.gutterUtilityContainer),l?.({...this.hoveredLine,event:n})));break}case"click":{if(r==null)break;if(Zt(r)&&u!=null){u(r);break}if(Jt(r)&&h!=null){h(r.hunkIndex,r.all||n.shiftKey?"both":r.direction,r.all||n.shiftKey?Number.POSITIVE_INFINITY:void 0);break}if(!Pe(r))break;Ce(r)&&d!=null&&d(this.toTokenEventBaseProps(r),n);const m=this.toEventBaseProps(r);a!=null&&r.numberColumn?a({...m,event:n}):o?.({...m,event:n});break}}}syncPointerListeners(e){const{__debugPointerEvents:n,lineHoverHighlight:t="disabled",onLineClick:i,onLineNumberClick:r,onLineEnter:o,onLineLeave:a,onTokenClick:l,onTokenEnter:s,onTokenLeave:d,onHunkExpand:f,onMergeConflictActionClick:c,enableGutterUtility:h=!1,enableLineSelection:u=!1,onGutterUtilityClick:m}=this.options,x=m!=null,y=t!=="disabled"||i!=null||r!=null||o!=null||a!=null||l!=null||s!=null||d!=null||f!=null||c!=null||h||u||x;y&&!this.hasPointerListeners?(e.addEventListener("click",this.handlePointerClick),e.addEventListener("pointerdown",this.handlePointerDown),e.addEventListener("pointermove",this.handlePointerMove),e.addEventListener("pointerleave",this.handlePointerLeave),this.hasPointerListeners=!0,Y(n,"click","FileDiff.DEBUG.attachEventListeners: Attaching click events for:",(()=>{const b=[];return(n==="both"||n==="click")&&(i!=null&&b.push("onLineClick"),r!=null&&b.push("onLineNumberClick"),f!=null&&b.push("expandable hunk separators"),c!=null&&b.push("merge conflict actions")),b})()),Y(n,"move","FileDiff.DEBUG.attachEventListeners: Attaching pointer move event"),Y(n,"move","FileDiff.DEBUG.attachEventListeners: Attaching pointer leave event")):!y&&this.hasPointerListeners&&(e.removeEventListener("click",this.handlePointerClick),e.removeEventListener("pointerdown",this.handlePointerDown),e.removeEventListener("pointermove",this.handlePointerMove),e.removeEventListener("pointerleave",this.handlePointerLeave),this.hasPointerListeners=!1);const C=this.pointerSession.mode==="selecting"||this.pointerSession.mode==="pendingSingleLineUnselect",p=this.pointerSession.mode==="gutterSelecting";(!u&&C||!x&&p)&&(this.clearPointerSession(),this.detachDocumentPointerListeners(),this.selectionAnchor=void 0,this.clearPendingSingleLineState())}updateInteractiveLineAttributes(){if(this.pre==null)return;const{onLineClick:e,onLineNumberClick:n,enableLineSelection:t=!1}=this.options,i=e!=null,r=n!=null||t;i&&!this.interactiveLinesAttr?(this.pre.setAttribute("data-interactive-lines",""),this.interactiveLinesAttr=!0):!i&&this.interactiveLinesAttr&&(this.pre.removeAttribute("data-interactive-lines"),this.interactiveLinesAttr=!1),r&&!this.interactiveLineNumbersAttr?(this.pre.setAttribute("data-interactive-line-numbers",""),this.interactiveLineNumbersAttr=!0):!r&&this.interactiveLineNumbersAttr&&(this.pre.removeAttribute("data-interactive-line-numbers"),this.interactiveLineNumbersAttr=!1)}handlePointerDown=e=>{if(e.pointerType==="mouse"&&e.button!==0||this.pre==null||this.pointerSession.mode!=="idle")return;const n=e.composedPath();bn(n)&&this.options.onGutterUtilityClick!=null?this.startGutterSelectionFromPointerDown(e,n):this.startLineSelectionFromPointerDown(e,n)};startLineSelectionFromPointerDown(e,n){const{enableLineSelection:t=!1}=this.options;if(!t)return;const i=this.getSelectionPointerInfo(n,!0);if(i==null)return;const{pre:r}=this;if(r==null)return;e.preventDefault();const{lineNumber:o,eventSide:a,lineIndex:l}=i;if(e.shiftKey&&this.selectedRange!=null){const s=this.getIndexesFromSelection(this.selectedRange,r.getAttribute("data-diff-type")==="split");if(s==null)return;const d=s.start<=s.end?l>=s.start:l<=s.end;this.selectionAnchor={lineNumber:d?this.selectedRange.start:this.selectedRange.end,side:d?this.selectedRange.side:this.selectedRange.endSide??this.selectedRange.side},this.updateSelection(o,a,!1),this.notifySelectionStart(this.selectedRange),this.pointerSession={mode:"selecting",pointerId:e.pointerId},this.attachDocumentPointerListeners();return}if(this.selectedRange?.start===o&&this.selectedRange?.end===o){const s={lineNumber:o,side:a};this.selectionAnchor=s,this.pointerSession={mode:"pendingSingleLineUnselect",pointerId:e.pointerId,anchor:s,pending:s},this.attachDocumentPointerListeners();return}this.selectedRange=null,this.selectionAnchor={lineNumber:o,side:a},this.updateSelection(o,a,!1),this.notifySelectionStart(this.selectedRange),this.pointerSession={mode:"selecting",pointerId:e.pointerId},this.attachDocumentPointerListeners()}startGutterSelectionFromPointerDown(e,n){const{enableLineSelection:t=!1,onGutterUtilityClick:i}=this.options;if(i==null)return;const r=this.getSelectionPointFromPath(n);r!=null&&(e.preventDefault(),e.stopPropagation(),this.pointerSession={mode:"gutterSelecting",pointerId:e.pointerId,anchor:r,current:r},t&&(this.selectionAnchor={lineNumber:r.lineNumber,side:r.side},this.updateSelection(r.lineNumber,r.side,!1),this.notifySelectionStart(this.selectedRange)),this.attachDocumentPointerListeners())}handleDocumentPointerMove=e=>{const{enableLineSelection:n=!1}=this.options;switch(this.pointerSession.mode){case"idle":return;case"gutterSelecting":{if(e.pointerId!==this.pointerSession.pointerId)return;const t=this.getSelectionPointFromPath(e.composedPath());if(t==null)return;this.pointerSession.current=t,n===!0&&this.updateSelection(t.lineNumber,t.side);return}case"selecting":{if(e.pointerId!==this.pointerSession.pointerId)return;const t=this.getSelectionPointerInfo(e.composedPath(),!1);if(t==null||this.selectionAnchor==null)return;this.updateSelection(t.lineNumber,t.eventSide);return}case"pendingSingleLineUnselect":{if(e.pointerId!==this.pointerSession.pointerId)return;const t=this.getSelectionPointerInfo(e.composedPath(),!1);if(t==null||this.selectionAnchor==null)return;const i={lineNumber:t.lineNumber,side:t.eventSide};if(Vt(this.pointerSession.pending,i))return;this.updateSelection(t.lineNumber,t.eventSide,!1),this.notifySelectionStart(this.selectedRange),this.notifySelectionChangeDelta(),this.pointerSession={mode:"selecting",pointerId:e.pointerId};return}}};handleDocumentPointerUp=e=>{const{enableLineSelection:n=!1,onGutterUtilityClick:t}=this.options;switch(this.pointerSession.mode){case"idle":return;case"gutterSelecting":{if(e.pointerId!==this.pointerSession.pointerId)return;const i=this.getSelectionPointFromPath(e.composedPath());i!=null&&(this.pointerSession.current=i,n&&this.updateSelection(i.lineNumber,i.side)),t?.(this.buildSelectedLineRange(this.pointerSession.anchor,this.pointerSession.current)),this.selectionAnchor=void 0,n&&(this.notifySelectionEnd(this.selectedRange),this.notifySelectionCommitted()),this.clearPointerSession(),this.detachDocumentPointerListeners();return}case"pendingSingleLineUnselect":if(e.pointerId!==this.pointerSession.pointerId)return;this.updateSelection(null,void 0,!1),this.selectionAnchor=void 0,this.clearPendingSingleLineState(),this.detachDocumentPointerListeners(),this.notifySelectionEnd(this.selectedRange),this.notifySelectionCommitted();return;case"selecting":if(e.pointerId!==this.pointerSession.pointerId)return;this.selectionAnchor=void 0,this.detachDocumentPointerListeners(),this.clearPointerSession(),this.notifySelectionEnd(this.selectedRange),this.notifySelectionCommitted()}};handleDocumentPointerCancel=e=>{switch(this.pointerSession.mode){case"idle":return;case"gutterSelecting":case"selecting":case"pendingSingleLineUnselect":if("pointerId"in this.pointerSession&&e.pointerId!==this.pointerSession.pointerId)return;this.selectionAnchor=void 0,this.clearPendingSingleLineState(),this.clearPointerSession(),this.detachDocumentPointerListeners()}};clearHoveredLine(){this.hoveredLine!=null&&(this.hoveredLine.lineElement.removeAttribute("data-hovered"),this.hoveredLine.numberElement.removeAttribute("data-hovered"),this.hoveredLine=void 0)}setHoveredLine(e){const{lineHoverHighlight:n="disabled"}=this.options;this.hoveredLine!=null&&this.clearHoveredLine(),this.hoveredLine=e,n!=="disabled"&&((n==="both"||n==="line")&&this.hoveredLine.lineElement.setAttribute("data-hovered",""),(n==="both"||n==="number")&&this.hoveredLine.numberElement.setAttribute("data-hovered",""))}clearHoveredToken(){this.hoveredToken!=null&&(this.hoveredToken=void 0)}setHoveredToken(e){this.hoveredToken!=null&&this.clearHoveredToken(),this.hoveredToken=e}ensureGutterUtilityNode(e){if(this.gutterUtilityContainer==null&&(this.gutterUtilityContainer=document.createElement("div"),this.gutterUtilityContainer.setAttribute("data-gutter-utility-slot","")),e)this.gutterUtilityButton!=null&&(this.gutterUtilityButton.remove(),this.gutterUtilityButton=void 0),this.gutterUtilitySlot==null&&(this.gutterUtilitySlot=document.createElement("slot"),this.gutterUtilitySlot.name="gutter-utility-slot"),this.gutterUtilitySlot.parentNode!==this.gutterUtilityContainer&&this.gutterUtilityContainer.replaceChildren(this.gutterUtilitySlot);else{if(this.gutterUtilitySlot?.remove(),this.gutterUtilitySlot=void 0,this.gutterUtilityButton==null){const n=document.createElement("div");n.innerHTML=ce(Kt());const t=n.firstElementChild;if(!(t instanceof HTMLButtonElement))throw new Error("InteractionManager.ensureGutterUtilityNode: Node element should be a button");t.remove(),this.gutterUtilityButton=t}this.gutterUtilityButton.parentNode!==this.gutterUtilityContainer&&this.gutterUtilityContainer.replaceChildren(this.gutterUtilityButton)}}attachDocumentPointerListeners(){this.hasDocumentPointerListeners||(document.addEventListener("pointermove",this.handleDocumentPointerMove),document.addEventListener("pointerup",this.handleDocumentPointerUp),document.addEventListener("pointercancel",this.handleDocumentPointerCancel),this.hasDocumentPointerListeners=!0)}detachDocumentPointerListeners(){this.hasDocumentPointerListeners&&(document.removeEventListener("pointermove",this.handleDocumentPointerMove),document.removeEventListener("pointerup",this.handleDocumentPointerUp),document.removeEventListener("pointercancel",this.handleDocumentPointerCancel),this.hasDocumentPointerListeners=!1)}clearPointerSession(){this.pointerSession={mode:"idle"}}clearPendingSingleLineState(){this.pointerSession.mode==="pendingSingleLineUnselect"&&(this.pointerSession={mode:"idle"})}getSelectionPointerInfo(e,n){const t=this.resolvePointerTarget(e);if(je(t)&&!(n&&!t.numberColumn)&&t.splitLineIndex!=null)return{lineIndex:t.splitLineIndex,lineNumber:t.lineNumber,eventSide:this.mode==="diff"?t.side:void 0}}getSelectionPointFromPath(e){const n=this.resolvePointerTarget(e);if(je(n))return{lineNumber:n.lineNumber,side:this.mode==="diff"?n.side:void 0}}getLineIndex(e,n){const{getLineIndex:t}=this.options;return t!=null?t(e,n):[e-1,e-1]}updateSelection(e,n,t=!0){const{selectedRange:i}=this;let r;if(e==null)r=null;else{const o=this.selectionAnchor?.side??n,a=this.selectionAnchor?.lineNumber??e;r=this.buildSelectionRange(a,e,o,n)}un(i??void 0,r??void 0)||(this.selectedRange=r,t&&this.notifySelectionChangeDelta(),this.queuedSelectionRender??=requestAnimationFrame(this.renderSelection))}getIndexesFromSelection(e,n){if(this.pre==null)return;const t=this.getLineIndex(e.start,e.side),i=this.getLineIndex(e.end,e.endSide??e.side);return t!=null&&i!=null?{start:n?t[1]:t[0],end:n?i[1]:i[0]}:void 0}renderSelection=()=>{if(this.queuedSelectionRender!=null&&(cancelAnimationFrame(this.queuedSelectionRender),this.queuedSelectionRender=void 0),this.pre==null||this.renderedSelectionRange===this.selectedRange)return;const e=this.pre.querySelectorAll("[data-selected-line]");for(const l of e)l.removeAttribute("data-selected-line");if(this.renderedSelectionRange=this.selectedRange,this.selectedRange==null)return;const{children:n}=this.pre;if(n.length===0)return;if(n.length>2)throw console.error(n),new Error("InteractionManager.renderSelection: Somehow there are more than 2 code elements...");const t=this.pre.getAttribute("data-diff-type")==="split",i=this.getIndexesFromSelection(this.selectedRange,t);if(i==null)throw console.error({rowRange:i,selectedRange:this.selectedRange}),new Error("InteractionManager.renderSelection: No valid rowRange");const r=i.start===i.end,o=Math.min(i.start,i.end),a=Math.max(i.start,i.end);for(const l of n){const[s,d]=l.children,f=d.children.length;if(f!==s.children.length)throw new Error("InteractionManager.renderSelection: gutter and content children dont match, something is wrong");for(let c=0;c<f;c++){const h=d.children[c],u=s.children[c];if(!(h instanceof HTMLElement)||!(u instanceof HTMLElement))continue;const m=this.parseLineIndex(h,t);if((m??0)>a)break;if(m==null||m<o)continue;let x=r?"single":m===o?"first":m===a?"last":"";h.setAttribute("data-selected-line",x),u.setAttribute("data-selected-line",x),u.nextSibling instanceof HTMLElement&&h.nextSibling instanceof HTMLElement&&(h.nextSibling.hasAttribute("data-line-annotation")||h.nextSibling.hasAttribute("data-merge-conflict-actions"))&&(r?(x="last",h.setAttribute("data-selected-line","first")):m===o?x="":m===a&&h.setAttribute("data-selected-line",""),h.nextSibling.setAttribute("data-selected-line",x),u.nextSibling.setAttribute("data-selected-line",x))}}};notifySelectionCommitted(){this.options.onLineSelected?.(this.selectedRange??null)}notifySelectionChangeDelta(){this.options.onLineSelectionChange?.(this.selectedRange??null)}notifySelectionStart(e){this.options.onLineSelectionStart?.(e)}notifySelectionEnd(e){this.options.onLineSelectionEnd?.(e)}toEventBaseProps(e){return this.mode==="file"?{type:"line",lineElement:e.lineElement,lineNumber:e.lineNumber,numberColumn:e.numberColumn,numberElement:e.numberElement}:{type:"diff-line",annotationSide:e.side,lineType:e.lineType,lineElement:e.lineElement,numberElement:e.numberElement,lineNumber:e.lineNumber,numberColumn:e.numberColumn}}toTokenEventBaseProps({lineCharEnd:e,lineCharStart:n,lineNumber:t,side:i,tokenElement:r,tokenText:o}){return this.mode==="file"?{type:"token",lineCharEnd:e,lineCharStart:n,lineNumber:t,tokenElement:r,tokenText:o}:{type:"token",lineCharEnd:e,lineCharStart:n,lineNumber:t,side:i,tokenElement:r,tokenText:o}}buildSelectedLineRange(e,n){return this.buildSelectionRange(e.lineNumber,n.lineNumber,e.side,n.side)}buildSelectionRange(e,n,t,i){return{start:e,end:n,...t!=null?{side:t}:{},...t!==i&&i!=null?{endSide:i}:{}}}resolvePointerTarget(e){let n=!1,t,i,r,o,a,l,s,d,f,c;for(const u of e){if(!(u instanceof HTMLElement))continue;if(c==null&&u.hasAttribute("data-merge-conflict-action")){const C=u.getAttribute("data-merge-conflict-action")??void 0,p=u.getAttribute("data-merge-conflict-conflict-index")??void 0,b=p!=null?Number.parseInt(p,10):NaN;Qt(C)&&Number.isFinite(b)&&(c={kind:"merge-conflict-action",resolution:C,conflictIndex:b})}if(l==null&&u.hasAttribute("data-char")){l=u;const C=u.getAttribute("data-char");if(C!=null){const p=Number.parseInt(C,10);if(!Number.isNaN(p)){const b=u.textContent??"",v=p+b.length;(b.trim()!==""||this.options.enableTokenInteractionsOnWhitespace===!0)&&(s={tokenElement:l,lineCharStart:p,lineCharEnd:v,tokenText:b});continue}}}const m=a==null?u.getAttribute("data-column-number")??void 0:void 0;if(m!=null){a=u,f=Number.parseInt(m,10),n=!0,t=gn(u),o=u.getAttribute("data-line-index")??void 0;continue}const x=r==null?u.getAttribute("data-line")??void 0:void 0;if(x!=null){r=u,f=Number.parseInt(x,10),t=gn(u),o=u.getAttribute("data-line-index")??void 0;continue}if(d==null&&(u.hasAttribute("data-expand-button")||u.hasAttribute("data-unmodified-lines"))){d={hunkIndex:void 0,direction:u.hasAttribute("data-expand-up")?"up":u.hasAttribute("data-expand-down")?"down":"both",all:u.hasAttribute("data-expand-all-button")};continue}const y=d!=null?u.getAttribute("data-expand-index")??void 0:void 0;if(d!=null&&y!=null){const C=Number.parseInt(y,10);Number.isNaN(C)||(d.hunkIndex=C);continue}if(i==null&&u.hasAttribute("data-code")){i=u;break}}if(c!=null)return c;if(d?.hunkIndex!=null)return{type:"line-info",hunkIndex:d.hunkIndex,direction:d.direction,all:d.all};if(r??=o!=null?pn(i,`[data-line][data-line-index="${o}"]`):void 0,a??=o!=null?pn(i,`[data-column-number][data-line-index="${o}"]`):void 0,i==null||r==null||a==null||t==null||f==null||Number.isNaN(f))return;const h=this.parseLineIndex(r,this.isSplitDiff());return s!=null?this.mode==="file"?{kind:"token",lineType:t,lineElement:r,lineNumber:f,numberColumn:n,numberElement:a,side:void 0,splitLineIndex:h,...s}:{kind:"token",lineType:t,lineElement:r,lineNumber:f,numberColumn:n,numberElement:a,side:mn(t,i),splitLineIndex:h,...s}:this.mode==="file"?{kind:"line",lineType:t,lineElement:r,lineNumber:f,numberColumn:n,numberElement:a,side:void 0,splitLineIndex:h}:{kind:"line",lineType:t,lineElement:r,lineNumber:f,numberColumn:n,numberElement:a,side:mn(t,i),splitLineIndex:h}}isSplitDiff(){return this.pre?.getAttribute("data-diff-type")==="split"}parseLineIndex(e,n){const t=(e.getAttribute("data-line-index")??"").split(",").map(i=>Number.parseInt(i,10)).filter(i=>!Number.isNaN(i));if(n&&t.length===2)return t[1];if(!n)return t[0]}};function hn({enableTokenInteractionsOnWhitespace:e,enableGutterUtility:n,enableHoverUtility:t,lineHoverHighlight:i,onGutterUtilityClick:r,onLineClick:o,onLineEnter:a,onLineLeave:l,onLineNumberClick:s,onTokenClick:d,onTokenEnter:f,onTokenLeave:c,renderGutterUtility:h,renderHoverUtility:u,__debugPointerEvents:m,enableLineSelection:x,onLineSelected:y,onLineSelectionStart:C,onLineSelectionChange:p,onLineSelectionEnd:b},v,S,g){return{enableTokenInteractionsOnWhitespace:e,enableGutterUtility:Yt({enableGutterUtility:n,enableHoverUtility:t,renderGutterUtility:h,renderHoverUtility:u,onGutterUtilityClick:r}),usesCustomGutterUtility:h!=null||u!=null,lineHoverHighlight:i,onGutterUtilityClick:r,onHunkExpand:v,onMergeConflictActionClick:g,onLineClick:o,onLineEnter:a,onLineLeave:l,onLineNumberClick:s,onTokenClick:d,onTokenEnter:f,onTokenLeave:c,__debugPointerEvents:m,enableLineSelection:x,onLineSelected:y,onLineSelectionStart:C,onLineSelectionChange:p,onLineSelectionEnd:b,getLineIndex:S}}function Yt({enableGutterUtility:e,enableHoverUtility:n,renderGutterUtility:t,renderHoverUtility:i,onGutterUtilityClick:r}){if(e!==void 0&&n!==void 0)throw new Error("Cannot use both 'enableGutterUtility' and deprecated 'enableHoverUtility'. Use only 'enableGutterUtility'.");if(t!=null&&i!=null)throw new Error("Cannot use both 'renderGutterUtility' and deprecated 'renderHoverUtility'. Use only 'renderGutterUtility'.");if(r!=null&&(t!=null||i!=null))throw new Error("Cannot use both 'onGutterUtilityClick' and render utility callbacks ('renderGutterUtility'/'renderHoverUtility'). Use only one gutter utility API.");return e??n??!1}function je(e){return e!=null&&"kind"in e&&e.kind==="line"}function Ce(e){return e!=null&&"kind"in e&&e.kind==="token"}function Pe(e){return je(e)||Ce(e)}function Jt(e){return"type"in e&&e.type==="line-info"}function Zt(e){return"kind"in e&&e.kind==="merge-conflict-action"}function Qt(e){return e==="current"||e==="incoming"||e==="both"}function pn(e,n){const t=e?.querySelector(n);return t instanceof HTMLElement?t:void 0}function mn(e,n){switch(e){case"change-deletion":return"deletions";case"change-addition":return"additions";default:return n.hasAttribute("data-deletions")?"deletions":"additions"}}function gn(e){const n=e.getAttribute("data-line-type");if(n!=null)switch(n){case"change-deletion":case"change-addition":case"context":case"context-expanded":return n;default:return}}function bn(e){for(const n of e)if(n instanceof HTMLElement&&n.hasAttribute("data-utility-button"))return!0;return!1}function Y(e="none",n,...t){switch(e){case"none":return;case"both":break;case"click":if(n!=="click")return;break;case"move":if(n!=="move")return;break}console.log(...t)}var ei=class{observedNodes=new Map;queuedUpdates=new Map;cleanUp(){this.resizeObserver?.disconnect(),this.observedNodes.clear(),this.queuedUpdates.clear()}resizeObserver;setup(e,n){this.resizeObserver??=new ResizeObserver(this.handleResizeObserver);const t=e.querySelectorAll("code"),i=new Map(this.observedNodes);this.observedNodes.clear();for(const r of t){let o=i.get(r);if(o!=null&&o.type!=="code")throw new Error("ResizeManager.setup: somehow a code node is being used for an annotation, should be impossible");let a=r.firstElementChild;a instanceof HTMLElement||(a=null),o!=null?(this.observedNodes.set(r,o),i.delete(r),o.numberElement!==a?(o.numberElement!=null&&this.resizeObserver.unobserve(o.numberElement),a!=null&&(this.resizeObserver.observe(a),i.delete(a),this.observedNodes.set(a,o)),o.numberElement=a):o.numberElement!=null&&(i.delete(o.numberElement),this.observedNodes.set(o.numberElement,o))):(o={type:"code",codeElement:r,numberElement:a,codeWidth:"auto",numberWidth:0},this.observedNodes.set(r,o),this.resizeObserver.observe(r),a!=null&&(this.observedNodes.set(a,o),this.resizeObserver.observe(a)))}if(t.length>1&&!n){const r=e.querySelectorAll('[data-line-annotation*=","]'),o=new Map;for(const a of r){if(!(a instanceof HTMLElement))continue;const{lineAnnotation:l=""}=a.dataset;if(!/^\d+,\d+$/.test(l)){console.error("DiffFileRenderer.setupResizeObserver: Invalid element or annotation",{lineAnnotation:l,element:a});continue}let s=o.get(l);s==null&&(s=[],o.set(l,s)),s.push(a)}for(const[a,l]of o){if(l.length!==2){console.error("DiffFileRenderer.setupResizeObserver: Bad Pair",a,l);continue}const[s,d]=l,f=s.firstElementChild,c=d.firstElementChild;if(!(s instanceof HTMLElement)||!(d instanceof HTMLElement)||!(f instanceof HTMLElement)||!(c instanceof HTMLElement))continue;let h=i.get(f);if(h!=null){this.observedNodes.set(f,h),this.observedNodes.set(c,h),i.delete(f),i.delete(c);continue}h={type:"annotations",column1:{container:s,child:f,childHeight:f.getBoundingClientRect().height},column2:{container:d,child:c,childHeight:c.getBoundingClientRect().height},currentHeight:"auto"};const u=Math.max(h.column1.childHeight,h.column2.childHeight);this.applyNewHeight(h,u),this.observedNodes.set(f,h),this.observedNodes.set(c,h),this.resizeObserver.observe(f),this.resizeObserver.observe(c)}}for(const r of i.keys())r.isConnected&&(r.style.removeProperty("--diffs-column-content-width"),r.style.removeProperty("--diffs-column-number-width"),r.style.removeProperty("--diffs-column-width"),r.parentElement instanceof HTMLElement&&r.parentElement.style.removeProperty("--diffs-annotation-min-height")),this.resizeObserver.unobserve(r);i.clear()}handleResizeObserver=e=>{for(const n of e){const{target:t,borderBoxSize:i,contentBoxSize:r}=n;if(!(t instanceof HTMLElement)){console.error("FileDiff.handleResizeObserver: Invalid element for ResizeObserver",n);continue}const o=this.observedNodes.get(t);if(o==null){console.error("FileDiff.handleResizeObserver: Not a valid observed node",n);continue}if(o.type==="annotations"){const a=(()=>{if(t===o.column1.child)return o.column1;if(t===o.column2.child)return o.column2})();if(a==null){console.error("FileDiff.handleResizeObserver: Couldn't find a column for",{item:o,target:t});continue}a.childHeight=i[0].blockSize;const l=Math.max(o.column1.childHeight,o.column2.childHeight);this.applyNewHeight(o,l)}else if(o.type==="code"){const a=[t,r[0].inlineSize],l=this.queuedUpdates.get(o)??[];l.push(a),this.queuedUpdates.set(o,l)}}this.handleColumnChange()};handleColumnChange=()=>{for(const[e,n]of this.queuedUpdates)for(const[t,i]of n)if(t===e.codeElement){const r=Math.max(Math.floor(i),0);if(r!==e.codeWidth){const o=Math.max(r-e.numberWidth,0);e.codeWidth=r===0?"auto":r,e.codeElement.style.setProperty("--diffs-column-content-width",`${o>0?`${o}px`:"auto"}`),e.codeElement.style.setProperty("--diffs-column-width",`${typeof e.codeWidth=="number"?`${e.codeWidth}px`:"auto"}`)}e.numberElement!=null&&typeof e.codeWidth=="number"&&e.numberWidth===0&&n.push([e.numberElement,e.numberElement.getBoundingClientRect().width])}else if(t===e.numberElement){const r=Math.max(Math.ceil(i),0);if(r!==e.numberWidth&&(e.numberWidth=r,e.codeElement.style.setProperty("--diffs-column-number-width",`${e.numberWidth===0?"auto":`${e.numberWidth}px`}`),e.codeWidth!=="auto")){const o=Math.max(e.codeWidth-e.numberWidth,0);e.codeElement.style.setProperty("--diffs-column-content-width",`${o===0?"auto":`${o}px`}`)}}this.queuedUpdates.clear()};applyNewHeight(e,n){n!==e.currentHeight&&(e.currentHeight=Math.max(n,0),e.column1.container.style.setProperty("--diffs-annotation-min-height",`${e.currentHeight}px`),e.column2.container.style.setProperty("--diffs-annotation-min-height",`${e.currentHeight}px`))}};function Dn(e,n){return e==null||n==null?e===n:e.startingLine===n.startingLine&&e.totalLines===n.totalLines&&e.bufferBefore===n.bufferBefore&&e.bufferAfter===n.bufferAfter}function vn(e){for(const n of Array.isArray(e)?e:[e])if(!(n==="text"||n==="ansi")&&!We.has(n))return!1;return!0}function De(e){for(const n of Mn(e))if(!_e.has(n))return!1;return!0}function ni(e){return T({tagName:"div",children:[T({tagName:"div",children:e.annotations?.map(n=>T({tagName:"slot",properties:{name:n}})),properties:{"data-annotation-content":""}})],properties:{"data-line-annotation":`${e.hunkIndex},${e.lineIndex}`}})}function ti(e,n){return T({tagName:"div",children:e,properties:{"data-content":"",style:`grid-row: span ${n}`}})}function ii(e){switch(e){case"file":return"diffs-icon-file-code";case"change":return"diffs-icon-symbol-modified";case"new":return"diffs-icon-symbol-added";case"deleted":return"diffs-icon-symbol-deleted";case"rename-pure":case"rename-changed":return"diffs-icon-symbol-moved"}}function ri({fileOrDiff:e,mode:n}){const t="type"in e?e:void 0,i={"data-diffs-header":n,"data-change-type":t?.type};return T({tagName:"div",children:[n==="custom"?T({tagName:"slot",properties:{name:Xe}}):oi({name:e.name,prevName:"prevName"in e?e.prevName:void 0,iconType:t?.type??"file"}),...n==="custom"?[]:[si(t)]],properties:i})}function oi({name:e,prevName:n,iconType:t}){const i=[T({tagName:"slot",properties:{name:Ve}}),Le({name:ii(t),properties:{"data-change-icon":t}})];return n!=null&&(i.push(T({tagName:"div",children:[T({tagName:"bdi",children:[V(n)]})],properties:{"data-prev-name":""}})),i.push(Le({name:"diffs-icon-arrow-right-short",properties:{"data-rename-icon":""}}))),i.push(T({tagName:"div",children:[T({tagName:"bdi",children:[V(e)]})],properties:{"data-title":""}})),T({tagName:"div",children:i,properties:{"data-header-content":""}})}function si(e){const n=[];if(e!=null){let t=0,i=0;for(const r of e.hunks)t+=r.additionLines,i+=r.deletionLines;(i>0||t===0)&&n.push(T({tagName:"span",children:[V(`-${i}`)],properties:{"data-deletions-count":""}})),(t>0||i===0)&&n.push(T({tagName:"span",children:[V(`+${t}`)],properties:{"data-additions-count":""}}))}return n.push(T({tagName:"slot",properties:{name:Ke}})),T({tagName:"div",children:n,properties:{"data-metadata":""}})}function ai(e){return T({tagName:"pre",properties:li(e)})}function li({diffIndicators:e,disableBackground:n,disableLineNumbers:t,overflow:i,split:r,totalLines:o,type:a,customProperties:l}){return{...l,"data-diff":a==="diff"?"":void 0,"data-file":a==="file"?"":void 0,"data-diff-type":a==="diff"?r?"split":"single":void 0,"data-overflow":i,"data-disable-line-numbers":t?"":void 0,"data-background":n?void 0:"","data-indicators":e==="bars"||e==="classic"?e:void 0,tabIndex:0,style:`--diffs-min-number-column-width-default:${`${o}`.length}ch;`}}function di(e,{theme:n,preferredHighlighter:t="shiki-js"}){return{langs:[e??"text"],themes:Mn(n),preferredHighlighter:t}}function fi(e){return e.useTokenTransformer===!0||e.onTokenClick!=null||e.onTokenEnter!=null||e.onTokenLeave!=null}const ci=`<svg data-icon-sprite aria-hidden="true" width="0" height="0">
  <symbol id="diffs-icon-arrow-right-short" viewBox="0 0 16 16">
    <path d="M8.47 4.22a.75.75 0 0 0 0 1.06l1.97 1.97H3.75a.75.75 0 0 0 0 1.5h6.69l-1.97 1.97a.75.75 0 1 0 1.06 1.06l3.25-3.25a.75.75 0 0 0 0-1.06L9.53 4.22a.75.75 0 0 0-1.06 0"/>
  </symbol>
  <symbol id="diffs-icon-brand-github" viewBox="0 0 16 16">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.01 8.01 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27s-1.36.09-2 .27c-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8"/>
  </symbol>
  <symbol id="diffs-icon-chevron" viewBox="0 0 16 16">
    <path d="M1.47 4.47a.75.75 0 0 1 1.06 0L8 9.94l5.47-5.47a.75.75 0 1 1 1.06 1.06l-6 6a.75.75 0 0 1-1.06 0l-6-6a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-chevrons-narrow" viewBox="0 0 10 16">
    <path d="M4.47 2.22a.75.75 0 0 1 1.06 0l3.25 3.25a.75.75 0 0 1-1.06 1.06L5 3.81 2.28 6.53a.75.75 0 0 1-1.06-1.06zM1.22 9.47a.75.75 0 0 1 1.06 0L5 12.19l2.72-2.72a.75.75 0 0 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0l-3.25-3.25a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-diff-split" viewBox="0 0 16 16">
    <path d="M14 0H8.5v16H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2m-1.5 6.5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0"/><path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5.5V0zm.5 7.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1 0-1" opacity=".3"/>
  </symbol>
  <symbol id="diffs-icon-diff-unified" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8.5h16zm-8-4a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 0 0 1 0v-1h1a.5.5 0 0 0 0-1h-1v-1A.5.5 0 0 0 8 10" clip-rule="evenodd"/><path fill-rule="evenodd" d="M14 0a2 2 0 0 1 2 2v5.5H0V2a2 2 0 0 1 2-2zM6.5 3.5a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1z" clip-rule="evenodd" opacity=".4"/>
  </symbol>
  <symbol id="diffs-icon-expand" viewBox="0 0 16 16">
    <path d="M3.47 5.47a.75.75 0 0 1 1.06 0L8 8.94l3.47-3.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-expand-all" viewBox="0 0 16 16">
    <path d="M11.47 9.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 1 1 1.06-1.06L8 12.94zM7.526 1.418a.75.75 0 0 1 1.004.052l4 4a.75.75 0 1 1-1.06 1.06L8 3.06 4.53 6.53a.75.75 0 1 1-1.06-1.06l4-4z"/>
  </symbol>
  <symbol id="diffs-icon-file-code" viewBox="0 0 16 16">
    <path d="M10.75 0c.199 0 .39.08.53.22l3.5 3.5c.14.14.22.331.22.53v9A2.75 2.75 0 0 1 12.25 16h-8.5A2.75 2.75 0 0 1 1 13.25V2.75A2.75 2.75 0 0 1 3.75 0zm-7 1.5c-.69 0-1.25.56-1.25 1.25v10.5c0 .69.56 1.25 1.25 1.25h8.5c.69 0 1.25-.56 1.25-1.25V5h-1.25A2.25 2.25 0 0 1 10 2.75V1.5z"/><path d="M7.248 6.19a.75.75 0 0 1 .063 1.058L5.753 9l1.558 1.752a.75.75 0 0 1-1.122.996l-2-2.25a.75.75 0 0 1 0-.996l2-2.25a.75.75 0 0 1 1.06-.063M8.69 7.248a.75.75 0 1 1 1.12-.996l2 2.25a.75.75 0 0 1 0 .996l-2 2.25a.75.75 0 1 1-1.12-.996L10.245 9z"/>
  </symbol>
  <symbol id="diffs-icon-plus" viewBox="0 0 16 16">
    <path d="M8 3a.75.75 0 0 1 .75.75v3.5h3.5a.75.75 0 0 1 0 1.5h-3.5v3.5a.75.75 0 0 1-1.5 0v-3.5h-3.5a.75.75 0 0 1 0-1.5h3.5v-3.5A.75.75 0 0 1 8 3"/>
  </symbol>
  <symbol id="diffs-icon-symbol-added" viewBox="0 0 16 16">
    <path d="M8 4a.75.75 0 0 1 .75.75v2.5h2.5a.75.75 0 0 1 0 1.5h-2.5v2.5a.75.75 0 0 1-1.5 0v-2.5h-2.5a.75.75 0 0 1 0-1.5h2.5v-2.5A.75.75 0 0 1 8 4"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-deleted" viewBox="0 0 16 16">
    <path d="M4 8a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 0 1.5h-6.5A.75.75 0 0 1 4 8"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-diffstat" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.75 4.296a.75.75 0 0 0-1.5 0V6.25h-2a.75.75 0 0 0 0 1.5h2v1.5h1.5v-1.5h2a.75.75 0 0 0 0-1.5h-2zM5.25 10a.75.75 0 0 0 0 1.5h5.5a.75.75 0 0 0 0-1.5z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ignored" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m11.53-2.47a.75.75 0 0 0-1.06-1.06l-6 6a.75.75 0 1 0 1.06 1.06z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-modified" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m8 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
  </symbol>
  <symbol id="diffs-icon-symbol-moved" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.495 4.695a.75.75 0 0 0-.05 1.06L10.486 8l-2.041 2.246a.75.75 0 0 0 1.11 1.008l2.5-2.75a.75.75 0 0 0 0-1.008l-2.5-2.75a.75.75 0 0 0-1.06-.051m-4 0a.75.75 0 0 0-.05 1.06l2.044 2.248-1.796 1.995a.75.75 0 0 0 1.114 1.004l2.25-2.5a.75.75 0 0 0-.002-1.007l-2.5-2.75a.75.75 0 0 0-1.06-.05"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ref" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706.286.286.71.54 1.41.73V1.86c-.7.19-1.124.444-1.41.73-.324.325-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8m4 6.397c.697.07 1.522.103 2.5.103 1.613 0 2.806-.088 3.704-.288.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5c-.978 0-1.803.033-2.5.103zM0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m7-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1z"/>
  </symbol>
</svg>`;function ui(e,n){return e==null||n==null?e===n:hi(e.customProperties,n.customProperties)&&e.type===n.type&&e.diffIndicators===n.diffIndicators&&e.disableBackground===n.disableBackground&&e.disableLineNumbers===n.disableLineNumbers&&e.overflow===n.overflow&&e.split===n.split&&e.totalLines===n.totalLines}const kn={};function hi(e=kn,n=kn){if(e===n)return!0;const t=Object.keys(e),i=Object.keys(n);if(t.length!==i.length)return!1;for(const r of t)if(e[r]!==n[r])return!1;return!0}function pi(e){const n=document.createElement("div");return n.dataset.annotationSlot="",n.slot=e,n.style.whiteSpace="normal",n}function mi(){const e=document.createElement("div");return e.slot="gutter-utility-slot",e.style.position="absolute",e.style.top="0",e.style.bottom="0",e.style.textAlign="center",e.style.whiteSpace="normal",e}function gi(){const e=document.createElement("style");return e.setAttribute(An,""),e}var bi=`@layer base, theme, rendered, unsafe;

@layer base {
  :host {
    --diffs-font-fallback:
      'SF Mono', Monaco, Consolas, 'Ubuntu Mono', 'Liberation Mono',
      'Courier New', monospace;
    --diffs-header-font-fallback:
      system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue',
      'Noto Sans', 'Liberation Sans', Arial, sans-serif;

    --diffs-mixer: light-dark(black, white);
    --diffs-gap-fallback: 8px;

    --diffs-added-light: #0dbe4e;
    --diffs-added-dark: #5ecc71;
    --diffs-modified-light: #009fff;
    --diffs-modified-dark: #69b1ff;
    --diffs-deleted-light: #ff2e3f;
    --diffs-deleted-dark: #ff6762;

    /*
    // Available CSS Color Overrides
    --diffs-bg-buffer-override
    --diffs-bg-hover-override
    --diffs-bg-context-override
    --diffs-bg-separator-override

    --diffs-fg-number-override
    --diffs-fg-number-addition-override
    --diffs-fg-number-deletion-override
    --diffs-fg-conflict-marker-override

    --diffs-deletion-color-override
    --diffs-addition-color-override
    --diffs-modified-color-override

    --diffs-bg-deletion-override
    --diffs-bg-deletion-number-override
    --diffs-bg-deletion-hover-override
    --diffs-bg-deletion-emphasis-override

    --diffs-bg-addition-override
    --diffs-bg-addition-number-override
    --diffs-bg-addition-hover-override
    --diffs-bg-addition-emphasis-override

    // Line Selection Color Overrides (for enableLineSelection)
    --diffs-selection-color-override
    --diffs-bg-selection-override
    --diffs-bg-selection-number-override
    --diffs-bg-selection-background-override
    --diffs-bg-selection-number-background-override

    // Available CSS Layout Overrides
    --diffs-gap-inline
    --diffs-gap-block
    --diffs-gap-style
    --diffs-tab-size
  */

    color-scheme: light dark;
    display: block;
    font-family: var(
      --diffs-header-font-family,
      var(--diffs-header-font-fallback)
    );
    font-size: var(--diffs-font-size, 13px);
    line-height: var(--diffs-line-height, 20px);
    font-feature-settings: var(--diffs-font-features);

    /* NOTE(amadeus): we cannot use 'in oklch' because current versions of cursor
     * and vscode use an older build of chrome that appears to have a bug with
     * color-mix and 'in oklch', so use 'in lab' instead */
    --diffs-bg: light-dark(
      var(--diffs-light-bg, #fff),
      var(--diffs-dark-bg, #000)
    );
    --diffs-bg-buffer: var(
      --diffs-bg-buffer-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer))
      )
    );
    --diffs-bg-hover: var(
      --diffs-bg-hover-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 97%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-mixer))
      )
    );

    --diffs-bg-context: var(
      --diffs-bg-context-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 98.5%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 92.5%, var(--diffs-mixer))
      )
    );
    --diffs-bg-context-number: var(
      --diffs-bg-context-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg-context) 80%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-bg-context) 60%, var(--diffs-bg))
      )
    );
    --diffs-bg-conflict-marker: var(
      --diffs-bg-conflict-marker-override,
      light-dark(
        color-mix(
          in lab,
          var(--diffs-bg-context) 88%,
          var(--diffs-modified-base)
        ),
        color-mix(
          in lab,
          var(--diffs-bg-context) 80%,
          var(--diffs-modified-base)
        )
      )
    );
    --diffs-bg-conflict-current: var(
      --diffs-bg-conflict-current-override,
      light-dark(#e5f8ea, #274432)
    );
    --diffs-bg-conflict-base: var(
      --diffs-bg-conflict-base-override,
      light-dark(
        color-mix(
          in lab,
          var(--diffs-bg-context) 90%,
          var(--diffs-modified-base)
        ),
        color-mix(
          in lab,
          var(--diffs-bg-context) 82%,
          var(--diffs-modified-base)
        )
      )
    );
    --diffs-bg-conflict-incoming: var(
      --diffs-bg-conflict-incoming-override,
      light-dark(#e6f1ff, #253b5a)
    );
    --diffs-bg-conflict-marker-number: var(
      --diffs-bg-conflict-marker-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg-conflict-marker) 72%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-bg-conflict-marker) 54%, var(--diffs-bg))
      )
    );
    --diffs-bg-conflict-current-number: var(
      --diffs-bg-conflict-current-number-override,
      light-dark(#d7f1de, #30533d)
    );
    --diffs-bg-conflict-base-number: var(
      --diffs-bg-conflict-base-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg-conflict-base) 72%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-bg-conflict-base) 54%, var(--diffs-bg))
      )
    );
    --diffs-bg-conflict-incoming-number: var(
      --diffs-bg-conflict-incoming-number-override,
      light-dark(#d8e8ff, #2f4b73)
    );
    --conflict-bg-current: var(
      --conflict-bg-current-override,
      var(--diffs-bg-addition)
    );
    --conflict-bg-incoming: var(
      --conflict-bg-incoming-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-modified-base))
      )
    );
    --conflict-bg-current-number: var(
      --conflict-bg-current-number-override,
      var(--diffs-bg-addition-number)
    );
    --conflict-bg-incoming-number: var(
      --conflict-bg-incoming-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-modified-base))
      )
    );
    --conflict-bg-current-header: var(
      --conflict-bg-current-header-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 78%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 68%, var(--diffs-addition-base))
      )
    );
    --conflict-bg-incoming-header: var(
      --conflict-bg-incoming-header-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 78%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 68%, var(--diffs-modified-base))
      )
    );
    --conflict-bg-current-header-number: var(
      --conflict-bg-current-header-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 72%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 62%, var(--diffs-addition-base))
      )
    );
    --conflict-bg-incoming-header-number: var(
      --conflict-bg-incoming-header-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 72%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 62%, var(--diffs-modified-base))
      )
    );

    --diffs-bg-separator: var(
      --diffs-bg-separator-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 96%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-mixer))
      )
    );

    --diffs-fg: light-dark(var(--diffs-light, #000), var(--diffs-dark, #fff));
    --diffs-fg-number: var(
      --diffs-fg-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg))
      )
    );
    --diffs-fg-conflict-marker: var(
      --diffs-fg-conflict-marker-override,
      var(--diffs-fg-number)
    );

    --diffs-deletion-base: var(
      --diffs-deletion-color-override,
      light-dark(
        var(
          --diffs-light-deletion-color,
          var(--diffs-deletion-color, var(--diffs-deleted-light))
        ),
        var(
          --diffs-dark-deletion-color,
          var(--diffs-deletion-color, var(--diffs-deleted-dark))
        )
      )
    );
    --diffs-addition-base: var(
      --diffs-addition-color-override,
      light-dark(
        var(
          --diffs-light-addition-color,
          var(--diffs-addition-color, var(--diffs-added-light))
        ),
        var(
          --diffs-dark-addition-color,
          var(--diffs-addition-color, var(--diffs-added-dark))
        )
      )
    );
    --diffs-modified-base: var(
      --diffs-modified-color-override,
      light-dark(
        var(
          --diffs-light-modified-color,
          var(--diffs-modified-color, var(--diffs-modified-light))
        ),
        var(
          --diffs-dark-modified-color,
          var(--diffs-modified-color, var(--diffs-modified-dark))
        )
      )
    );

    /* NOTE(amadeus): we cannot use 'in oklch' because current versions of cursor
   * and vscode use an older build of chrome that appears to have a bug with
   * color-mix and 'in oklch', so use 'in lab' instead */
    --diffs-bg-deletion: var(
      --diffs-bg-deletion-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-deletion-base)),
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-deletion-base))
      )
    );
    --diffs-bg-deletion-number: var(
      --diffs-bg-deletion-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-deletion-base)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-deletion-base))
      )
    );
    --diffs-bg-deletion-hover: var(
      --diffs-bg-deletion-hover-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-deletion-base)),
        color-mix(in lab, var(--diffs-bg) 75%, var(--diffs-deletion-base))
      )
    );
    --diffs-bg-deletion-emphasis: var(
      --diffs-bg-deletion-emphasis-override,
      light-dark(
        rgb(from var(--diffs-deletion-base) r g b / 0.15),
        rgb(from var(--diffs-deletion-base) r g b / 0.2)
      )
    );

    --diffs-bg-addition: var(
      --diffs-bg-addition-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-addition-base))
      )
    );
    --diffs-bg-addition-number: var(
      --diffs-bg-addition-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-addition-base))
      )
    );
    --diffs-bg-addition-hover: var(
      --diffs-bg-addition-hover-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 70%, var(--diffs-addition-base))
      )
    );
    --diffs-bg-addition-emphasis: var(
      --diffs-bg-addition-emphasis-override,
      light-dark(
        rgb(from var(--diffs-addition-base) r g b / 0.15),
        rgb(from var(--diffs-addition-base) r g b / 0.2)
      )
    );

    --diffs-selection-base: var(--diffs-modified-base);
    --diffs-selection-number-fg: light-dark(
      color-mix(in lab, var(--diffs-selection-base) 65%, var(--diffs-mixer)),
      color-mix(in lab, var(--diffs-selection-base) 75%, var(--diffs-mixer))
    );
    --diffs-bg-selection: var(
      --diffs-bg-selection-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 82%, var(--diffs-selection-base)),
        color-mix(in lab, var(--diffs-bg) 75%, var(--diffs-selection-base))
      )
    );
    --diffs-bg-selection-number: var(
      --diffs-bg-selection-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 75%, var(--diffs-selection-base)),
        color-mix(in lab, var(--diffs-bg) 60%, var(--diffs-selection-base))
      )
    );

    background-color: var(--diffs-bg);
    color: var(--diffs-fg);
  }

  /* NOTE(mdo): Some semantic HTML elements (e.g. \`pre\`, \`code\`) have default
 * user-agent styles. These must be overridden to use our custom styles. */
  pre,
  code,
  [data-error-wrapper] {
    isolation: isolate;
    margin: 0;
    padding: 0;
    display: block;
    outline: none;
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
  }

  pre,
  code {
    background-color: var(--diffs-bg);
  }

  code {
    contain: content;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  [data-icon-sprite] {
    display: none;
  }

  /* NOTE(mdo): Headers and separators are within pre/code, so we need to reset
   * their font-family explicitly. */
  [data-diffs-header],
  [data-separator] {
    font-family: var(
      --diffs-header-font-family,
      var(--diffs-header-font-fallback)
    );
  }

  [data-file-info] {
    padding: 10px;
    font-weight: 700;
    color: var(--fg);
    /* NOTE(amadeus): we cannot use 'in oklch' because current versions of cursor
   * and vscode use an older build of chrome that appears to have a bug with
   * color-mix and 'in oklch', so use 'in lab' instead */
    background-color: color-mix(in lab, var(--bg) 98%, var(--fg));
    border-block: 1px solid color-mix(in lab, var(--bg) 95%, var(--fg));
  }

  [data-diff],
  [data-file] {
    /* This feels a bit crazy to me... so I need to think about it a bit more... */
    --diffs-grid-number-column-width: minmax(min-content, max-content);
    --diffs-code-grid: var(--diffs-grid-number-column-width) 1fr;

    &[data-dehydrated] {
      --diffs-code-grid: var(--diffs-grid-number-column-width) minmax(0, 1fr);
    }

    &:hover [data-code]::-webkit-scrollbar-thumb {
      background-color: var(--diffs-bg-context);
    }
  }

  [data-line] span {
    color: light-dark(
      var(--diffs-token-light, var(--diffs-light)),
      var(--diffs-token-dark, var(--diffs-dark))
    );
    background-color: light-dark(
      var(--diffs-token-light-bg, inherit),
      var(--diffs-token-dark-bg, inherit)
    );
    font-weight: light-dark(
      var(--diffs-token-light-font-weight, inherit),
      var(--diffs-token-dark-font-weight, inherit)
    );
    font-style: light-dark(
      var(--diffs-token-light-font-style, inherit),
      var(--diffs-token-dark-font-style, inherit)
    );
    -webkit-text-decoration: light-dark(
      var(--diffs-token-light-text-decoration, inherit),
      var(--diffs-token-dark-text-decoration, inherit)
    );
            text-decoration: light-dark(
      var(--diffs-token-light-text-decoration, inherit),
      var(--diffs-token-dark-text-decoration, inherit)
    );
  }

  [data-line],
  [data-gutter-buffer],
  [data-line-annotation],
  [data-no-newline] {
    color: var(--diffs-fg);
    background-color: var(--diffs-line-bg, var(--diffs-bg));
  }

  [data-no-newline] {
    -webkit-user-select: none;
            user-select: none;

    span {
      opacity: 0.6;
    }
  }

  [data-diff-type='split'][data-overflow='scroll'] {
    display: grid;
    grid-template-columns: 1fr 1fr;

    [data-additions] {
      border-left: 1px solid var(--diffs-bg);
    }

    [data-deletions] {
      border-right: 1px solid var(--diffs-bg);
    }
  }

  [data-code] {
    display: grid;
    grid-auto-flow: dense;
    grid-template-columns: var(--diffs-code-grid);
    overflow: scroll clip;
    overscroll-behavior-x: none;
    tab-size: var(--diffs-tab-size, 2);
    align-self: flex-start;
    padding-top: var(--diffs-gap-block, var(--diffs-gap-fallback));
    padding-bottom: max(
      0px,
      calc(var(--diffs-gap-block, var(--diffs-gap-fallback)) - 6px)
    );
  }

  [data-container-size] {
    container-type: inline-size;
  }

  [data-code]::-webkit-scrollbar {
    width: 0;
    height: 6px;
  }

  [data-code]::-webkit-scrollbar-track {
    background: transparent;
  }

  [data-code]::-webkit-scrollbar-thumb {
    background-color: transparent;
    border: 1px solid transparent;
    background-clip: content-box;
    border-radius: 3px;
  }

  [data-code]::-webkit-scrollbar-corner {
    background-color: transparent;
  }

  /*
   * If we apply these rules globally it will mean that webkit will opt into the
   * standards compliant version of custom css scrollbars, which we do not want
   * because the custom stuff will look better
  */
  @supports (-moz-appearance: none) {
    [data-code] {
      scrollbar-width: thin;
      scrollbar-color: var(--diffs-bg-context) transparent;
      padding-bottom: var(--diffs-gap-block, var(--diffs-gap-fallback));
    }
  }

  [data-diffs-header] ~ [data-diff],
  [data-diffs-header] ~ [data-file] {
    [data-code],
    &[data-overflow='wrap'] {
      padding-top: 0;
    }
  }

  [data-gutter] {
    display: grid;
    grid-template-rows: subgrid;
    grid-template-columns: subgrid;
    grid-column: 1;
    z-index: 3;
    position: relative;
    background-color: var(--diffs-bg);

    [data-gutter-buffer],
    [data-column-number] {
      border-right: var(--diffs-gap-style, 2px solid var(--diffs-bg));
    }
  }

  [data-content] {
    display: grid;
    grid-template-rows: subgrid;
    grid-template-columns: subgrid;
    grid-column: 2;
    min-width: 0;
  }

  [data-diff-type='split'][data-overflow='wrap'] {
    display: grid;
    grid-auto-flow: dense;
    grid-template-columns: repeat(2, var(--diffs-code-grid));
    padding-block: var(--diffs-gap-block, var(--diffs-gap-fallback));

    [data-deletions] {
      display: contents;

      [data-gutter] {
        grid-column: 1;
      }

      [data-content] {
        grid-column: 2;
        border-right: 1px solid var(--diffs-bg);
      }
    }

    [data-additions] {
      display: contents;

      [data-gutter] {
        grid-column: 3;
        border-left: 1px solid var(--diffs-bg);
      }

      [data-content] {
        grid-column: 4;
      }
    }
  }

  [data-overflow='scroll'] [data-gutter] {
    position: sticky;
    left: 0;
  }

  [data-line-annotation][data-selected-line] {
    background-color: unset;

    &::before {
      content: '';
      /* FIXME(amadeus): This needs to be audited ... */
      position: sticky;
      top: 0;
      left: 0;
      display: block;
      border-right: var(--diffs-gap-style, 1px solid var(--diffs-bg));
      background-color: var(--diffs-bg-selection-number);
    }

    [data-annotation-content] {
      background-color: var(--diffs-bg-selection);
    }
  }

  [data-interactive-lines] [data-line] {
    cursor: pointer;
  }

  [data-content-buffer],
  [data-gutter-buffer] {
    position: relative;
    -webkit-user-select: none;
            user-select: none;
    min-height: 1lh;
  }

  [data-gutter-buffer='annotation'] {
    min-height: 0;
  }

  [data-gutter-buffer='buffer'] {
    background-size: 8px 8px;
    background-position: 0 0;
    background-origin: border-box;
    background-color: var(--diffs-bg);
    /* This is incredibley expensive... */
    background-image: repeating-linear-gradient(
      -45deg,
      transparent,
      transparent calc(3px * 1.414),
      rgb(from var(--diffs-bg-buffer) r g b / 0.8) calc(3px * 1.414),
      rgb(from var(--diffs-bg-buffer) r g b / 0.8) calc(4px * 1.414)
    );
  }

  [data-content-buffer] {
    grid-column: 1;
    /* We multiply by 1.414 (√2) to better approximate the diagonal repeat distance */
    background-size: 8px 8px;
    background-position: 5px 0;
    background-origin: border-box;
    background-color: var(--diffs-bg);
    /* This is incredibley expensive... */
    background-image: repeating-linear-gradient(
      -45deg,
      transparent,
      transparent calc(3px * 1.414),
      var(--diffs-bg-buffer) calc(3px * 1.414),
      var(--diffs-bg-buffer) calc(4px * 1.414)
    );
  }

  [data-separator] {
    box-sizing: content-box;
    background-color: var(--diffs-bg);
  }

  [data-separator='simple'] {
    min-height: 4px;
  }

  [data-separator='line-info'],
  [data-separator='line-info-basic'],
  [data-separator='metadata'],
  [data-separator='simple'] {
    background-color: var(--diffs-bg-separator);
  }

  [data-separator='line-info'],
  [data-separator='line-info-basic'],
  [data-separator='metadata'] {
    height: 32px;
    position: relative;
  }

  [data-separator-wrapper] {
    -webkit-user-select: none;
            user-select: none;
    fill: currentColor;
    position: absolute;
    inset-inline: 0;
    display: flex;
    align-items: center;
    background-color: var(--diffs-bg);
    height: 100%;
  }

  [data-content] [data-separator-wrapper] {
    display: none;
  }

  [data-separator='metadata'] [data-separator-wrapper] {
    inset-inline: 100% auto;
    padding-inline: 1ch;
    height: 100%;
    background-color: var(--diffs-bg-separator);
    color: var(--diffs-fg-number);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    min-width: min-content;
  }

  [data-separator='line-info'] {
    margin-block: var(--diffs-gap-block, var(--diffs-gap-fallback));
  }

  [data-separator='line-info-basic'],
  [data-separator='metadata'] {
    margin-block: 0;
  }

  [data-separator='line-info'][data-separator-first] {
    margin-top: 0;
  }

  [data-separator='line-info'][data-separator-last] {
    margin-bottom: 0;
  }

  [data-expand-index] [data-separator-wrapper] {
    display: grid;
    grid-template-columns: 32px auto;
  }

  [data-expand-index] [data-separator-wrapper][data-separator-multi-button] {
    grid-template-columns: 32px 32px auto;
  }

  [data-expand-button],
  [data-separator-content] {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    background-color: var(--diffs-bg-separator);
  }

  [data-expand-index] [data-separator-content]:hover {
    text-decoration: underline;
    cursor: pointer;
  }

  [data-expand-button] {
    justify-content: center;
    flex-shrink: 0;
    cursor: pointer;
    min-width: 32px;
    align-self: stretch;
    color: var(--diffs-fg-number);
    border-right: 2px solid var(--diffs-bg);

    &:hover {
      color: var(--diffs-fg);
    }

    &[data-expand-all-button] {
      display: none;
    }
  }

  [data-expand-down] [data-icon] {
    transform: scaleY(-1);
  }

  [data-separator-content] {
    flex: 1 1 auto;
    padding: 0 1ch;
    height: 100%;
    color: var(--diffs-fg-number);

    overflow: hidden;
    justify-content: flex-start;
  }

  [data-separator='line-info'],
  [data-separator='line-info-basic'] {
    [data-separator-content] {
      height: 100%;
      -webkit-user-select: none;
              user-select: none;
      overflow: clip;
    }
  }

  @supports (width: 1cqi) {
    [data-unified] {
      [data-separator='line-info'] [data-separator-wrapper] {
        padding-inline: var(--diffs-gap-inline, var(--diffs-gap-fallback));
        width: 100cqi;

        [data-separator-content] {
          border-radius: 6px;
        }
      }

      [data-separator='line-info'][data-expand-index]
        [data-separator-wrapper]
        [data-separator-content] {
        border-top-left-radius: unset;
        border-bottom-left-radius: unset;
      }
    }

    [data-gutter] {
      [data-separator='line-info'] [data-separator-wrapper] {
        padding-left: var(--diffs-gap-inline, var(--diffs-gap-fallback));
      }

      [data-separator='line-info'] [data-separator-content] {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px;
      }

      [data-separator='line-info'][data-expand-index] [data-separator-content] {
        border-top-left-radius: unset;
        border-bottom-left-radius: unset;
      }
    }

    [data-additions] {
      [data-content] [data-separator='line-info'] {
        background-color: var(--diffs-bg);

        [data-separator-wrapper] {
          display: none;
        }
      }

      [data-gutter] [data-separator='line-info'] [data-separator-wrapper] {
        display: block;
        height: 100%;
        background-color: var(--diffs-bg-separator);
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px;

        [data-separator-content],
        [data-expand-button] {
          display: none;
        }
      }
    }

    [data-overflow='scroll']
      [data-additions]
      [data-gutter]
      [data-separator='line-info']
      [data-separator-wrapper] {
      width: calc(100cqi - var(--diffs-gap-inline, var(--diffs-gap-fallback)));
    }

    [data-overflow='wrap']
      [data-additions]
      [data-content]
      [data-separator='line-info']
      [data-separator-wrapper] {
      background-color: var(--diffs-bg-separator);
      display: block;
      height: 100%;
      margin-right: var(--diffs-gap-inline, var(--diffs-gap-fallback));
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px;

      [data-separator-content],
      [data-expand-button] {
        display: none;
      }
    }

    [data-separator='line-info'] [data-separator-wrapper] {
      [data-expand-both],
      [data-expand-down],
      [data-expand-up] {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px;
      }
    }

    @media (pointer: fine) {
      [data-separator='line-info'] [data-separator-wrapper] {
        &[data-separator-multi-button] {
          [data-expand-up] {
            border-top-left-radius: 6px;
            border-bottom-left-radius: unset;
          }

          [data-expand-down] {
            border-bottom-left-radius: 6px;
            border-top-left-radius: unset;
          }
        }
      }
    }
  }

  @media (pointer: coarse) {
    [data-separator='line-info-basic']
      [data-separator-wrapper][data-separator-multi-button] {
      grid-template-columns: 34px 34px auto;

      [data-separator-content] {
        grid-column: unset;
        grid-row: unset;
      }
    }

    @supports (width: 1cqi) {
      [data-separator='line-info'] [data-separator-wrapper] {
        [data-expand-both],
        [data-expand-down],
        [data-expand-up] {
          border-top-left-radius: 6px;
          border-bottom-left-radius: 6px;
        }

        &[data-separator-multi-button] {
          [data-expand-up] {
            border-top-left-radius: 6px;
            border-bottom-left-radius: 6px;
          }

          [data-expand-down] {
            border-bottom-left-radius: unset;
            border-top-left-radius: unset;
          }
        }
      }
    }
  }

  @media (pointer: fine) {
    [data-separator-wrapper][data-separator-multi-button] {
      display: grid;
      grid-template-rows: 50% 50%;

      [data-separator-content] {
        grid-column: 2;
        grid-row: 1 / -1;
        min-width: min-content;
      }

      [data-expand-button] {
        grid-column: 1;
      }
    }

    [data-separator='line-info'] [data-separator-wrapper],
    [data-separator='line-info']
      [data-separator-wrapper][data-separator-multi-button] {
      grid-template-columns: 34px auto;
    }

    [data-separator='line-info-basic'][data-expand-index]
      [data-separator-wrapper] {
      grid-template-columns: 100% auto;
    }

    [data-separator='line-info'],
    [data-separator='line-info-basic'] {
      [data-separator-multi-button] {
        [data-expand-up] {
          border-bottom: 1px solid var(--diffs-bg);
          border-right: 2px solid var(--diffs-bg);
        }
        [data-expand-down] {
          border-top: 1px solid var(--diffs-bg);
          border-right: 2px solid var(--diffs-bg);
        }
      }
    }
  }

  [data-additions] [data-gutter] [data-separator-wrapper],
  [data-additions] [data-separator='line-info-basic'] [data-separator-wrapper],
  [data-content] [data-separator-wrapper] {
    display: none;
  }

  [data-line-annotation],
  [data-gutter-buffer='annotation'] {
    --diffs-line-bg: var(--diffs-bg-context);
  }

  [data-merge-conflict-actions],
  [data-gutter-buffer='merge-conflict-action'] {
    --diffs-line-bg: var(--diffs-bg-context);
  }

  [data-has-merge-conflict] [data-line-annotation],
  [data-has-merge-conflict] [data-gutter-buffer='annotation'] {
    --diffs-line-bg: var(--diffs-bg);
  }

  [data-has-merge-conflict] [data-gutter-buffer='merge-conflict-action'] {
    --diffs-line-bg: var(--diffs-bg);
  }

  [data-line-annotation] {
    min-height: var(--diffs-annotation-min-height, 0);
    z-index: 2;
  }

  [data-merge-conflict-actions] {
    z-index: 2;
  }

  [data-separator='custom'] {
    display: grid;
    grid-template-columns: subgrid;
  }

  [data-line],
  [data-column-number],
  [data-no-newline] {
    position: relative;
    padding-inline: 1ch;
  }

  [data-indicators='classic'] [data-line] {
    padding-inline-start: 2ch;
  }

  [data-indicators='classic'] {
    [data-line-type='change-addition'],
    [data-line-type='change-deletion'] {
      &[data-no-newline],
      &[data-line] {
        &::before {
          display: inline-block;
          width: 1ch;
          height: 1lh;
          position: absolute;
          top: 0;
          left: 0;
          -webkit-user-select: none;
                  user-select: none;
        }
      }
    }

    [data-line-type='change-addition'] {
      &[data-line],
      &[data-no-newline] {
        &::before {
          content: '+';
          color: var(--diffs-addition-base);
        }
      }
    }

    [data-line-type='change-deletion'] {
      &[data-line],
      &[data-no-newline] {
        &::before {
          content: '-';
          color: var(--diffs-deletion-base);
        }
      }
    }
  }

  [data-indicators='bars'] {
    [data-line-type='change-deletion'],
    [data-line-type='change-addition'] {
      &[data-column-number] {
        &::before {
          content: '';
          display: block;
          width: 4px;
          height: 100%;
          position: absolute;
          top: 0;
          left: 0;
          -webkit-user-select: none;
                  user-select: none;
          contain: strict;
        }
      }
    }

    [data-line-type='change-deletion'] {
      &[data-column-number] {
        &::before {
          background-image: linear-gradient(
            0deg,
            var(--diffs-bg-deletion) 50%,
            var(--diffs-deletion-base) 50%
          );
          background-repeat: repeat;
          background-size: 2px 2px;
          background-size: calc(1lh / round(1lh / 2px))
            calc(1lh / round(1lh / 2px));
        }
      }
    }

    [data-line-type='change-addition'] {
      &[data-column-number] {
        &::before {
          background-color: var(--diffs-addition-base);
        }
      }
    }
  }

  [data-overflow='wrap'] {
    [data-line],
    [data-annotation-content] {
      white-space: pre-wrap;
      word-break: break-word;
    }
  }

  [data-overflow='scroll'] [data-line] {
    white-space: pre;
    min-height: 1lh;
  }

  [data-column-number] {
    box-sizing: content-box;
    text-align: right;
    -webkit-user-select: none;
            user-select: none;
    background-color: var(--diffs-bg);
    color: var(--diffs-fg-number);
    padding-left: 2ch;
  }

  [data-line-number-content] {
    display: inline-block;
    min-width: var(
      --diffs-min-number-column-width,
      var(--diffs-min-number-column-width-default, 3ch)
    );
  }

  [data-disable-line-numbers] {
    [data-column-number] {
      min-width: 4px;
      padding: 0;
    }

    [data-line-number-content] {
      display: none;
    }

    [data-gutter-utility-slot] {
      right: unset;
      left: 0;
      justify-content: flex-start;
    }

    &[data-indicators='bars'] [data-gutter-utility-slot] {
      /* Using 5px here because theres a 1px separator after the bar */
      left: 5px;
    }
  }

  [data-file][data-disable-line-numbers] {
    [data-gutter-buffer],
    [data-column-number] {
      min-width: 0;
      border-right: 0;
    }
  }

  [data-interactive-line-numbers] [data-column-number] {
    cursor: pointer;
  }

  [data-diff-span] {
    border-radius: 3px;
    -webkit-box-decoration-break: clone;
            box-decoration-break: clone;
  }

  [data-line-type='change-addition'] {
    &[data-column-number] {
      color: var(
        --diffs-fg-number-addition-override,
        var(--diffs-addition-base)
      );
    }

    [data-diff-span] {
      background-color: var(--diffs-bg-addition-emphasis);
    }
  }

  [data-line-type='change-deletion'] {
    &[data-column-number] {
      color: var(
        --diffs-fg-number-deletion-override,
        var(--diffs-deletion-base)
      );
    }

    [data-diff-span] {
      background-color: var(--diffs-bg-deletion-emphasis);
    }
  }

  [data-background] [data-line-type='change-addition'] {
    --diffs-line-bg: var(--diffs-bg-addition);

    &[data-column-number] {
      background-color: var(--diffs-bg-addition-number);
    }
  }

  [data-background] [data-line-type='change-deletion'] {
    --diffs-line-bg: var(--diffs-bg-deletion);

    &[data-column-number] {
      background-color: var(--diffs-bg-deletion-number);
    }
  }

  [data-merge-conflict='marker-start'],
  [data-merge-conflict='marker-base'],
  [data-merge-conflict='marker-separator'],
  [data-merge-conflict='marker-end'] {
    padding-left: 1ch;
    color: var(--diffs-fg);
  }

  [data-merge-conflict='marker-start'],
  [data-merge-conflict='marker-end'] {
    display: flex;
    align-items: center;

    &::after {
      color: var(--diffs-fg-conflict-marker);
      font-style: normal;
      font-size: 0.75rem;
      line-height: 1.25rem;
      padding-left: 1ch;
      font-family: var(
        --diffs-header-font-family,
        var(--diffs-header-font-fallback)
      );
    }
  }

  [data-merge-conflict='marker-start']::after {
    content: '(Current Change)';
  }

  [data-merge-conflict='marker-end']::after {
    content: '(Incoming Change)';
  }

  [data-merge-conflict='marker-base'],
  [data-merge-conflict='marker-end'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--diffs-bg-conflict-marker);
    }

    &[data-column-number] {
      background-color: var(--diffs-bg-conflict-marker-number);
      color: var(--diffs-fg-conflict-marker);

      [data-line-number-content] {
        color: var(--diffs-fg-conflict-marker);
      }
    }
  }

  [data-merge-conflict='current'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--conflict-bg-current);
    }

    &[data-column-number] {
      background-color: var(--conflict-bg-current-number);
      color: var(--diffs-addition-base);
    }
  }

  [data-gutter-buffer='merge-conflict-marker-start'],
  [data-merge-conflict='marker-start'] {
    background-color: var(--conflict-bg-current-header);
  }

  [data-gutter-buffer='merge-conflict-marker-end'],
  [data-merge-conflict='marker-end'] {
    background-color: var(--conflict-bg-incoming-header);
  }

  [data-merge-conflict='marker-separator'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--diffs-bg);
    }

    &[data-column-number] {
      background-color: var(--diffs-bg);
    }
  }

  [data-merge-conflict='base'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--diffs-bg-conflict-base);
    }

    &[data-column-number] {
      background-color: var(--diffs-bg-conflict-base-number);
      color: var(--diffs-modified-base);
    }
  }

  [data-merge-conflict='incoming'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--conflict-bg-incoming);
    }

    &[data-column-number] {
      background-color: var(--conflict-bg-incoming-number);
      color: var(--diffs-modified-base);
    }
  }

  @media (pointer: fine) {
    [data-column-number],
    [data-line] {
      &[data-hovered] {
        background-color: var(--diffs-bg-hover);
      }
    }

    [data-background] {
      [data-column-number],
      [data-line] {
        &[data-hovered] {
          &[data-line-type='change-deletion'] {
            background-color: var(--diffs-bg-deletion-hover);
          }

          &[data-line-type='change-addition'] {
            background-color: var(--diffs-bg-addition-hover);
          }
        }
      }
    }
  }

  [data-diffs-header='default'] {
    position: relative;
    background-color: var(--diffs-bg);
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));
    min-height: calc(
      1lh + (var(--diffs-gap-block, var(--diffs-gap-fallback)) * 3)
    );
    padding-inline: 16px;
    top: 0;
    z-index: 2;
  }

  [data-header-content] {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));
    min-width: 0;
    white-space: nowrap;
  }

  [data-header-content] [data-prev-name],
  [data-header-content] [data-title] {
    direction: rtl;
    overflow: hidden;
    text-overflow: ellipsis;
    min-width: 0;
    white-space: nowrap;
  }

  [data-prev-name] {
    opacity: 0.7;
  }

  [data-rename-icon] {
    fill: currentColor;
    flex-shrink: 0;
    flex-grow: 0;
  }

  [data-diffs-header='default'] [data-metadata] {
    display: flex;
    align-items: center;
    gap: 1ch;
    white-space: nowrap;
  }

  [data-diffs-header='default'] [data-additions-count] {
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
    color: var(--diffs-addition-base);
  }

  [data-diffs-header='default'] [data-deletions-count] {
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
    color: var(--diffs-deletion-base);
  }

  [data-annotation-content] {
    position: relative;
    display: flow-root;
    align-self: flex-start;
    z-index: 2;
    min-width: 0;
    isolation: isolate;
  }

  [data-merge-conflict-actions-content] {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    padding-inline: 0.5rem;
    min-height: 1.75rem;
    font-family: var(
      --diffs-header-font-family,
      var(--diffs-header-font-fallback)
    );
    font-size: 0.75rem;
    line-height: 1.2;
    color: var(--diffs-fg);
  }

  [data-merge-conflict-action] {
    appearance: none;
    border: 0;
    background: transparent;
    color: var(--diffs-fg-number);
    font: inherit;
    font-style: normal;
    cursor: pointer;
    padding: 0;
  }

  [data-merge-conflict-action]:hover {
    color: var(--diffs-fg);
  }

  [data-merge-conflict-action='current']:hover {
    color: var(--diffs-addition-base);
  }

  [data-merge-conflict-action='incoming']:hover {
    color: var(--diffs-modified-base);
  }

  [data-merge-conflict-action-separator] {
    color: var(--diffs-fg-number);
    opacity: 0.6;
    -webkit-user-select: none;
            user-select: none;
  }

  /* Sticky positioning has a composite costs, so we should _only_ pay it if we
   * need to */
  [data-overflow='scroll'] [data-annotation-content] {
    position: sticky;
    width: var(--diffs-column-content-width, auto);
    left: var(--diffs-column-number-width, 0);
  }

  [data-overflow='scroll'] [data-merge-conflict-actions-content] {
    position: sticky;
    width: var(--diffs-column-content-width, auto);
    left: var(--diffs-column-number-width, 0);
  }

  /* Undo some of the stuff that the 'pre' tag does */
  [data-annotation-slot] {
    text-wrap-mode: wrap;
    word-break: normal;
    white-space-collapse: collapse;
  }

  [data-change-icon] {
    fill: currentColor;
    flex-shrink: 0;
  }

  [data-change-icon='change'],
  [data-change-icon='rename-pure'],
  [data-change-icon='rename-changed'] {
    color: var(--diffs-modified-base);
  }

  [data-change-icon='new'] {
    color: var(--diffs-addition-base);
  }

  [data-change-icon='deleted'] {
    color: var(--diffs-deletion-base);
  }

  [data-change-icon='file'] {
    opacity: 0.6;
  }

  /* Line selection highlighting */
  [data-selected-line] {
    &[data-gutter-buffer='annotation'],
    &[data-column-number] {
      color: var(--diffs-selection-number-fg);
      background-color: var(--diffs-bg-selection-number);
    }

    &[data-line] {
      background-color: var(--diffs-bg-selection);
    }
  }

  [data-line-type='change-addition'],
  [data-line-type='change-deletion'] {
    &[data-selected-line] {
      &[data-line],
      &[data-line][data-hovered] {
        background-color: light-dark(
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 82%,
            var(--diffs-selection-base)
          ),
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 75%,
            var(--diffs-selection-base)
          )
        );
      }

      &[data-column-number],
      &[data-column-number][data-hovered] {
        color: var(--diffs-selection-number-fg);
        background-color: light-dark(
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 75%,
            var(--diffs-selection-base)
          ),
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 60%,
            var(--diffs-selection-base)
          )
        );
      }
    }
  }

  [data-gutter-utility-slot] {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    display: flex;
    justify-content: flex-end;
  }

  [data-unmodified-lines] {
    display: block;
    overflow: hidden;
    min-width: 0;
    text-overflow: ellipsis;
    white-space: nowrap;
    flex: 0 1 auto;
  }

  [data-error-wrapper] {
    overflow: auto;
    padding: var(--diffs-gap-block, var(--diffs-gap-fallback))
      var(--diffs-gap-inline, var(--diffs-gap-fallback));
    max-height: 400px;
    scrollbar-width: none;

    [data-error-message] {
      font-weight: bold;
      font-size: 18px;
      color: var(--diffs-deletion-base);
    }

    [data-error-stack] {
      color: var(--diffs-fg-number);
    }
  }

  [data-placeholder] {
    contain: strict;
  }

  [data-utility-button] {
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    appearance: none;
    width: 1lh;
    height: 1lh;
    margin-right: calc((1lh - 1ch) * -1);
    padding: 0;
    cursor: pointer;
    font-size: var(--diffs-font-size, 13px);
    line-height: var(--diffs-line-height, 20px);
    border-radius: 4px;
    background-color: var(--diffs-modified-base);
    color: var(--diffs-bg);
    fill: currentColor;
    position: relative;
    z-index: 4;
  }
}
`;const Nn="@layer base, theme, rendered, unsafe;";function vi(e){return`${Nn}
@layer unsafe {
  ${e}
}`}function ki(e,n="system"){return`${Nn}
@layer rendered {
  :host {${n==="system"?"":`
  color-scheme: ${n};`}
  ${e}
  }
}`}function Ne({code:e,pre:n,columnType:t,rowSpan:i,containerSize:r=!1}={}){return e==null&&(e=document.createElement("code"),e.setAttribute("data-code",""),t!=null&&e.setAttribute(`data-${t}`,""),n?.appendChild(e)),i!=null?e.style.setProperty("grid-row",`span ${i}`):e.style.removeProperty("grid-row"),r?e.setAttribute("data-container-size",""):e.removeAttribute("data-container-size"),e}function xi({shadowRoot:e,currentNode:n,themeCSS:t}){if(t.trim()===""){n?.remove();return}return n??=yi(),n.textContent=t,n.parentNode!==e&&e.appendChild(n),n}function yi(){const e=document.createElement("style");return e.setAttribute(Tn,""),e}function Si(e,n){if(n==null)return;const t=e.shadowRoot??e.attachShadow({mode:"open"});t.innerHTML===""&&(t.innerHTML=n)}function Ci(e,{type:n,diffIndicators:t,disableBackground:i,disableLineNumbers:r,overflow:o,split:a,totalLines:l,customProperties:s}){if(s!=null)for(const d in s){const f=s[d];f!=null&&e.setAttribute(d,`${f}`)}switch(n==="diff"?(e.setAttribute("data-diff",""),e.removeAttribute("data-file")):(e.setAttribute("data-file",""),e.removeAttribute("data-diff")),t){case"bars":case"classic":e.setAttribute("data-indicators",t);break;case"none":e.removeAttribute("data-indicators");break}return r?e.setAttribute("data-disable-line-numbers",""):e.removeAttribute("data-disable-line-numbers"),i?e.removeAttribute("data-background"):e.setAttribute("data-background",""),n==="diff"?e.setAttribute("data-diff-type",a?"split":"single"):e.removeAttribute("data-diff-type"),e.setAttribute("data-overflow",o),e.tabIndex=0,e.style.setProperty("--diffs-min-number-column-width-default",`${`${l}`.length}ch`),e}if(typeof HTMLElement<"u"&&customElements.get(we)==null){let e;class n extends HTMLElement{constructor(){if(super(),this.shadowRoot!=null)return;const i=this.attachShadow({mode:"open"});e==null&&(e=new CSSStyleSheet,e.replaceSync(bi)),i.adoptedStyleSheets=[e]}}customElements.define(we,n)}const wi=!0;function xn(e,n,t){if(e===n||e==null||n==null)return e===n;const i=new Set(t),r=Object.keys(e),o=new Set(Object.keys(n));for(const a of r)if(o.delete(a),!i.has(a)&&(!(a in n)||e[a]!==n[a]))return!1;for(const a of Array.from(o))if(!i.has(a))return!1;return!0}function Li(e,n){const t=e?.theme??q,i=n?.theme??q,r=yn(e),o=yn(n);return Hn(t,i)&&xn(e,n,["theme","parseDiffOptions"])&&xn(r,o)}function yn(e){if(e!=null&&"parseDiffOptions"in e)return e.parseDiffOptions}function Ei({hunkIndex:e,lineIndex:n,conflictIndex:t}){return`merge-conflict-action-${e}-${n}-${t}`}function Ti(e,n){const t=n.hunks[e.hunkIndex];if(t!=null)return{hunkIndex:e.hunkIndex,lineIndex:Ai(t,e.startContentIndex)}}function Ai(e,n){let t=e.unifiedLineStart;for(let i=0;i<n;i++){const r=e.hunkContent[i];t+=r.type==="context"?r.lines:r.deletions+r.additions}return t}function Ii({fileDiff:e,actions:n,renderCustomHeader:t,renderHeaderPrefix:i,renderHeaderMetadata:r,renderAnnotation:o,renderGutterUtility:a,renderHoverUtility:l,renderMergeConflictUtility:s,lineAnnotations:d,getHoveredLine:f,getInstance:c}){const h=a??l,u=t?.(e),m=i?.(e),x=r?.(e);return N.jsxs(N.Fragment,{children:[u!=null?N.jsx("div",{slot:Xe,children:u}):N.jsxs(N.Fragment,{children:[m!=null&&N.jsx("div",{slot:Ve,children:m}),x!=null&&N.jsx("div",{slot:Ke,children:x})]}),o!=null&&d?.map((y,C)=>N.jsx("div",{slot:ue(y),children:o(y)},C)),n!=null&&s!=null&&c!=null&&n.map(y=>{if(y==null)return;const C=Ri(y,e);return N.jsx("div",{slot:C,style:Bn,children:s(y,c)},C)}),h!=null&&N.jsx("div",{slot:"gutter-utility-slot",style:jn,children:h(f)})]})}function Ri(e,n){const t=Ti(e,n);return t!=null?Ei({hunkIndex:t.hunkIndex,lineIndex:t.lineIndex,conflictIndex:e.conflictIndex}):void 0}var Mi=class{isDeletionsScrolling=!1;isAdditionsScrolling=!1;timeoutId=-1;codeDeletions;codeAdditions;enabled=!1;cleanUp(){this.enabled&&(this.codeDeletions?.removeEventListener("scroll",this.handleDeletionsScroll),this.codeAdditions?.removeEventListener("scroll",this.handleAdditionsScroll),clearTimeout(this.timeoutId),this.codeDeletions=void 0,this.codeAdditions=void 0,this.enabled=!1)}setup(e,n,t){if(n==null||t==null)for(const i of e.children??[])i instanceof HTMLElement&&("deletions"in i.dataset?n=i:"additions"in i.dataset&&(t=i));if(t==null||n==null){this.cleanUp();return}this.codeDeletions!==n&&(this.codeDeletions?.removeEventListener("scroll",this.handleDeletionsScroll),this.codeDeletions=n,n.addEventListener("scroll",this.handleDeletionsScroll,{passive:!0})),this.codeAdditions!==t&&(this.codeAdditions?.removeEventListener("scroll",this.handleAdditionsScroll),this.codeAdditions=t,t.addEventListener("scroll",this.handleAdditionsScroll,{passive:!0})),this.enabled=!0}handleDeletionsScroll=()=>{this.isAdditionsScrolling||(this.isDeletionsScrolling=!0,clearTimeout(this.timeoutId),this.timeoutId=setTimeout(()=>{this.isDeletionsScrolling=!1},300),this.codeAdditions?.scrollTo({left:this.codeDeletions?.scrollLeft}))};handleAdditionsScroll=()=>{this.isDeletionsScrolling||(this.isAdditionsScrolling=!0,clearTimeout(this.timeoutId),this.timeoutId=setTimeout(()=>{this.isAdditionsScrolling=!1},300),this.codeDeletions?.scrollTo({left:this.codeAdditions?.scrollLeft}))}};function ve(e){return T({tagName:"div",properties:{"data-content-buffer":"","data-buffer-size":e,style:`grid-row: span ${e};min-height:calc(${e} * 1lh)`}})}function ke(e){return T({tagName:"div",children:[T({tagName:"span",children:[V("No newline at end of file")]})],properties:{"data-no-newline":"","data-line-type":e,"data-column-content":""}})}function Ue(e){return T({tagName:"div",children:[Le({name:e==="both"?"diffs-icon-expand-all":"diffs-icon-expand",properties:{"data-icon":""}})],properties:{role:"button","data-expand-button":"","data-expand-both":e==="both"?"":void 0,"data-expand-up":e==="up"?"":void 0,"data-expand-down":e==="down"?"":void 0}})}function oe({type:e,content:n,expandIndex:t,chunked:i=!1,slotName:r,isFirstHunk:o,isLastHunk:a}){let l=0;const s=[];if(e==="metadata"&&n!=null&&s.push(T({tagName:"div",children:[V(n)],properties:{"data-separator-wrapper":""}})),(e==="line-info"||e==="line-info-basic")&&n!=null){const d=[];t!=null&&(i?(o||(d.push(Ue("up")),l++),a||(d.push(Ue("down")),l++)):(d.push(Ue(!o&&!a?"both":o?"down":"up")),l++)),d.push(T({tagName:"div",children:[T({tagName:"span",children:[V(n)],properties:{"data-unmodified-lines":""}})],properties:{"data-separator-content":""}})),i&&t!=null&&d.push(T({tagName:"div",children:[V("Expand all")],properties:{role:"button","data-expand-button":"","data-expand-all-button":""}})),s.push(T({tagName:"div",children:d,properties:{"data-separator-wrapper":"","data-separator-multi-button":l>1?"":void 0}}))}return e==="custom"&&r!=null&&s.push(T({tagName:"slot",properties:{name:r}})),T({tagName:"div",children:s,properties:{"data-separator":s.length===0?"simple":e,"data-expand-index":t,"data-separator-first":o?"":void 0,"data-separator-last":a?"":void 0}})}function Hi(e,n){return`hunk-separator-${e}-${n}`}function Pi(e){const n=e.at(-1);return n==null?0:Math.max(n.additionStart+n.additionCount,n.deletionStart+n.deletionCount)}function Di(e){return e.startingLine===0&&e.totalLines===1/0&&e.bufferBefore===0&&e.bufferAfter===0}let Ni=-1;var Ui=class{__id=`diff-hunks-renderer:${++Ni}`;highlighter;diff;expandedHunks=new Map;deletionAnnotations={};additionAnnotations={};computedLang="text";renderCache;constructor(e={theme:q},n,t){this.options=e,this.onRenderUpdate=n,this.workerManager=t,t?.isWorkingPool()!==!0&&(this.highlighter=De(e.theme??q)?ut():void 0)}cleanUp(){this.highlighter=void 0,this.diff=void 0,this.renderCache=void 0,this.workerManager?.cleanUpPendingTasks(this),this.workerManager=void 0,this.onRenderUpdate=void 0}recycle(){this.highlighter=void 0,this.diff=void 0,this.renderCache=void 0,this.workerManager?.cleanUpPendingTasks(this)}setOptions(e){this.options=e}mergeOptions(e){this.options={...this.options,...e}}expandHunk(e,n,t=this.getOptionsWithDefaults().expansionLineCount){const i={...this.expandedHunks.get(e)??{fromStart:0,fromEnd:0}};(n==="up"||n==="both")&&(i.fromStart+=t),(n==="down"||n==="both")&&(i.fromEnd+=t),this.renderCache?.highlighted!==!0&&(this.renderCache=void 0),this.expandedHunks.set(e,i)}getExpandedHunk(e){return this.expandedHunks.get(e)??et}getExpandedHunksMap(){return this.expandedHunks}setLineAnnotations(e){this.additionAnnotations={},this.deletionAnnotations={};for(const n of e){const t=(()=>{switch(n.side){case"deletions":return this.deletionAnnotations;case"additions":return this.additionAnnotations}})(),i=t[n.lineNumber]??[];t[n.lineNumber]=i,i.push(n)}}getUnifiedLineDecoration({lineType:e}){return{gutterLineType:e}}getSplitLineDecoration({side:e,type:n}){return n!=="change"?{gutterLineType:n}:{gutterLineType:e==="deletions"?"change-deletion":"change-addition"}}createAnnotationElement(e){return ni(e)}getOptionsWithDefaults(){const{diffIndicators:e="bars",diffStyle:n="split",disableBackground:t=!1,disableFileHeader:i=!1,disableLineNumbers:r=!1,disableVirtualizationBuffers:o=!1,collapsed:a=!1,expandUnchanged:l=!1,collapsedContextThreshold:s=se,expansionLineCount:d=100,hunkSeparators:f="line-info",lineDiffType:c="word-alt",maxLineDiffLength:h=1e3,overflow:u="scroll",theme:m=q,headerRenderMode:x="default",tokenizeMaxLineLength:y=1e3,useTokenTransformer:C=!1,useCSSClasses:p=!1}=this.options;return{diffIndicators:e,diffStyle:n,disableBackground:t,disableFileHeader:i,disableLineNumbers:r,disableVirtualizationBuffers:o,collapsed:a,expandUnchanged:l,collapsedContextThreshold:s,expansionLineCount:d,hunkSeparators:f,lineDiffType:c,maxLineDiffLength:h,overflow:u,theme:this.workerManager?.getDiffRenderOptions().theme??m,headerRenderMode:x,tokenizeMaxLineLength:y,useTokenTransformer:C,useCSSClasses:p}}async initializeHighlighter(){return this.highlighter=await ct(di(this.computedLang,this.options)),this.highlighter}hydrate(e){if(e==null)return;this.diff=e;const{options:n}=this.getRenderOptions(e);let t=this.workerManager?.getDiffResultCache(e);t!=null&&!He(n,t.options)&&(t=void 0),this.renderCache??={diff:e,highlighted:!wt(e),options:n,result:t?.result,renderRange:void 0},this.workerManager?.isWorkingPool()===!0?this.renderCache.result==null&&this.workerManager.highlightDiffAST(this,this.diff):this.highlighter==null&&(this.computedLang=e.lang??ne(e.name),this.initializeHighlighter())}getRenderOptions(e){const n=(()=>{if(this.workerManager?.isWorkingPool()===!0)return this.workerManager.getDiffRenderOptions();const{theme:i,tokenizeMaxLineLength:r,lineDiffType:o,maxLineDiffLength:a}=this.getOptionsWithDefaults();return{theme:i,useTokenTransformer:fi(this.options),tokenizeMaxLineLength:r,lineDiffType:o,maxLineDiffLength:a}})();this.getOptionsWithDefaults();const{renderCache:t}=this;return t?.result==null?{options:n,forceRender:!0}:e!==t.diff||!He(n,t.options)?{options:n,forceRender:!0}:{options:n,forceRender:!1}}renderDiff(e=this.renderCache?.diff,n=en){if(e==null)return;const{expandUnchanged:t=!1,collapsedContextThreshold:i}=this.getOptionsWithDefaults(),r=this.workerManager?.getDiffResultCache(e);r!=null&&this.renderCache==null&&(this.renderCache={diff:e,highlighted:!0,renderRange:void 0,...r});const{options:o,forceRender:a}=this.getRenderOptions(e);if(this.renderCache??={diff:e,highlighted:!1,options:o,result:void 0,renderRange:void 0},this.workerManager?.isWorkingPool()===!0)(this.renderCache.result==null||!this.renderCache.highlighted&&(e!==this.renderCache.diff||!Dn(this.renderCache.renderRange,n)))&&(this.renderCache.diff=e,this.renderCache.result=this.workerManager.getPlainDiffAST(e,n.startingLine,n.totalLines,Di(n)||t?!0:this.expandedHunks,i),this.renderCache.renderRange=n),n.totalLines>0&&(!this.renderCache.highlighted||a)&&this.workerManager.highlightDiffAST(this,e);else{this.computedLang=e.lang??ne(e.name);const l=this.highlighter!=null&&De(o.theme),s=this.highlighter!=null&&vn(this.computedLang);if(this.highlighter!=null&&l&&(a||!this.renderCache.highlighted&&s||this.renderCache.result==null)){const{result:d,options:f}=this.renderDiffWithHighlighter(e,this.highlighter,!s);this.renderCache={diff:e,options:f,highlighted:s,result:d,renderRange:void 0}}(!l||!s)&&this.asyncHighlight(e).then(({result:d,options:f})=>{this.renderCache!=null&&(this.renderCache.highlighted=!1),this.onHighlightSuccess(e,d,f)})}return this.renderCache.result!=null?this.processDiffResult(this.renderCache.diff,n,this.renderCache.result):void 0}async asyncRender(e,n=en){const{result:t}=await this.asyncHighlight(e);return this.processDiffResult(e,n,t)}createPreElement(e,n,t){const{diffIndicators:i,disableBackground:r,disableLineNumbers:o,overflow:a}=this.getOptionsWithDefaults();return ai({type:"diff",diffIndicators:i,disableBackground:r,disableLineNumbers:o,overflow:a,split:e,totalLines:n,customProperties:t})}async asyncHighlight(e){this.computedLang=e.lang??ne(e.name);const n=this.highlighter!=null&&De(this.options.theme??q),t=this.highlighter!=null&&vn(this.computedLang);return(this.highlighter==null||!n||!t)&&(this.highlighter=await this.initializeHighlighter()),this.renderDiffWithHighlighter(e,this.highlighter)}renderDiffWithHighlighter(e,n,t=!1){const{options:i}=this.getRenderOptions(e),{collapsedContextThreshold:r}=this.getOptionsWithDefaults();return{result:_t(e,n,i,{forcePlainText:t,expandedHunks:t?!0:void 0,collapsedContextThreshold:r}),options:i}}onHighlightSuccess(e,n,t){if(this.renderCache==null)return;const i=!this.renderCache.highlighted||!He(this.renderCache.options,t)||this.renderCache.diff!==e;this.renderCache={diff:e,options:t,highlighted:!0,result:n,renderRange:void 0},i&&this.onRenderUpdate?.()}onHighlightError(e){console.error(e)}processDiffResult(e,n,{code:t,themeStyles:i,baseThemeType:r}){const{diffStyle:o,disableFileHeader:a,expandUnchanged:l,expansionLineCount:s,collapsedContextThreshold:d,hunkSeparators:f}=this.getOptionsWithDefaults();this.diff=e;const c=o==="unified";let h=[],u=[],m=[];const x=[],{additionLines:y,deletionLines:C}=t,p={rowCount:0,hunkSeparators:f,additionsContentAST:h,deletionsContentAST:u,unifiedContentAST:m,unifiedGutterAST:me(),deletionsGutterAST:me(),additionsGutterAST:me(),expansionLineCount:s,hunkData:x,incrementRowCount(R=1){p.rowCount+=R},pushToGutter(R,U){switch(R){case"unified":p.unifiedGutterAST.children.push(U);break;case"deletions":p.deletionsGutterAST.children.push(U);break;case"additions":p.additionsGutterAST.children.push(U);break}}},b=Oi(e),v={size:0,side:void 0,increment(){this.size+=1},flush(){if(o!=="unified"){if(this.size<=0||this.side==null){this.side=void 0,this.size=0;return}this.side==="additions"?(p.pushToGutter("additions",W(void 0,"buffer",this.size)),h?.push(ve(this.size))):(p.pushToGutter("deletions",W(void 0,"buffer",this.size)),u?.push(ve(this.size))),this.size=0,this.side=void 0}}},S=(R,U,te,J,M)=>{p.pushToGutter(R,mt(U,te,J,M))};function g(R){v.flush(),o==="unified"?Oe("unified",R,p):(Oe("deletions",R,p),Oe("additions",R,p))}Ee({diff:e,diffStyle:o,startingLine:n.startingLine,totalLines:n.totalLines,expandedHunks:l?!0:this.expandedHunks,collapsedContextThreshold:d,callback:({hunkIndex:R,hunk:U,collapsedBefore:te,collapsedAfter:J,additionLine:M,deletionLine:P,type:D})=>{const Z=P!=null?P.splitLineIndex:M.splitLineIndex,ie=M!=null?M.unifiedLineIndex:P.unifiedLineIndex;o==="split"&&D!=="change"&&v.flush(),te>0&&g({hunkIndex:R,collapsedLines:te,rangeSize:Math.max(U?.collapsedBefore??0,0),hunkSpecs:U?.hunkSpecs,isFirstHunk:R===0,isLastHunk:!1,isExpandable:!e.isPartial});const le=o==="unified"?ie:Z,pe={type:D,hunkIndex:R,lineIndex:le,unifiedLineIndex:ie,splitLineIndex:Z,deletionLine:P,additionLine:M};if(o==="unified"){const H=this.getUnifiedInjectedRowsForLine?.(pe);H?.before!=null&&Cn(H.before,p);let O=P!=null?C[P.lineIndex]:void 0,z=M!=null?y[M.lineIndex]:void 0;if(O==null&&z==null){const F="DiffHunksRenderer.processDiffResult: deletionLine and additionLine are null, something is wrong";throw console.error(F,{file:e.name}),new Error(F)}const X=D==="change"?M!=null?"change-addition":"change-deletion":D,_=this.getUnifiedLineDecoration({type:D,lineType:X,additionLineIndex:M?.lineIndex,deletionLineIndex:P?.lineIndex});S("unified",_.gutterLineType,M!=null?M.lineNumber:P.lineNumber,`${ie},${Z}`,_.gutterProperties),z!=null?z=xe(z,_.contentProperties):O!=null&&(O=xe(O,_.contentProperties)),Ln({diffStyle:"unified",type:D,deletionLine:O,additionLine:z,unifiedSpan:this.getAnnotations("unified",P?.lineNumber,M?.lineNumber,R,le),createAnnotationElement:F=>this.createAnnotationElement(F),context:p}),H?.after!=null&&Cn(H.after,p)}else{const H=this.getSplitInjectedRowsForLine?.(pe);H?.before!=null&&wn(H.before,p,v);let O=P!=null?C[P.lineIndex]:void 0,z=M!=null?y[M.lineIndex]:void 0;const X=this.getSplitLineDecoration({side:"deletions",type:D,lineIndex:P?.lineIndex}),_=this.getSplitLineDecoration({side:"additions",type:D,lineIndex:M?.lineIndex});if(O==null&&z==null){const j="DiffHunksRenderer.processDiffResult: deletionLine and additionLine are null, something is wrong";throw console.error(j,{file:e.name}),new Error(j)}const F=(()=>{if(D==="change"){if(z==null)return"additions";if(O==null)return"deletions"}})();if(F!=null){if(v.side!=null&&v.side!==F)throw new Error("DiffHunksRenderer.processDiffResult: iterateOverDiff, invalid pending splits");v.side=F,v.increment()}const de=this.getAnnotations("split",P?.lineNumber,M?.lineNumber,R,le);if(de!=null&&v.size>0&&v.flush(),P!=null){const j=xe(O,X.contentProperties);S("deletions",X.gutterLineType,P.lineNumber,`${P.unifiedLineIndex},${Z}`,X.gutterProperties),j!=null&&(O=j)}if(M!=null){const j=xe(z,_.contentProperties);S("additions",_.gutterLineType,M.lineNumber,`${M.unifiedLineIndex},${Z}`,_.gutterProperties),j!=null&&(z=j)}Ln({diffStyle:"split",type:D,additionLine:z,deletionLine:O,...de,createAnnotationElement:j=>this.createAnnotationElement(j),context:p}),H?.after!=null&&wn(H.after,p,v)}const Q=P?.noEOFCR??!1,K=M?.noEOFCR??!1;if(K||Q){if(Q){const H=D==="context"||D==="context-expanded"?D:"change-deletion";o==="unified"?(p.unifiedContentAST.push(ke(H)),p.pushToGutter("unified",W(H,"metadata",1))):(p.deletionsContentAST.push(ke(H)),p.pushToGutter("deletions",W(H,"metadata",1)),K||(p.pushToGutter("additions",W(void 0,"buffer",1)),p.additionsContentAST.push(ve(1))))}if(K){const H=D==="context"||D==="context-expanded"?D:"change-addition";o==="unified"?(p.unifiedContentAST.push(ke(H)),p.pushToGutter("unified",W(H,"metadata",1))):(p.additionsContentAST.push(ke(H)),p.pushToGutter("additions",W(H,"metadata",1)),Q||(p.pushToGutter("deletions",W(void 0,"buffer",1)),p.deletionsContentAST.push(ve(1))))}p.incrementRowCount(1)}J>0&&f!=="simple"&&g({hunkIndex:D==="context-expanded"?R:R+1,collapsedLines:J,rangeSize:b,hunkSpecs:void 0,isFirstHunk:!1,isLastHunk:!0,isExpandable:!e.isPartial}),p.incrementRowCount(1)}}),o==="split"&&v.flush();const k=Math.max(Pi(e.hunks),e.additionLines.length??0,e.deletionLines.length??0),w=n.bufferBefore>0||n.bufferAfter>0,L=!c&&e.type!=="deleted",E=!c&&e.type!=="new",A=p.rowCount>0||w;h=L&&A?h:void 0,u=E&&A?u:void 0,m=c&&A?m:void 0;const I=this.createPreElement(u!=null&&h!=null,k);return{unifiedGutterAST:c&&A?p.unifiedGutterAST.children:void 0,unifiedContentAST:m,deletionsGutterAST:E&&A?p.deletionsGutterAST.children:void 0,deletionsContentAST:u,additionsGutterAST:L&&A?p.additionsGutterAST.children:void 0,additionsContentAST:h,hunkData:x,preNode:I,themeStyles:i,baseThemeType:r,headerElement:a?void 0:this.renderHeader(this.diff),totalLines:k,rowCount:p.rowCount,bufferBefore:n.bufferBefore,bufferAfter:n.bufferAfter,css:""}}renderCodeAST(e,n){const t=e==="unified"?n.unifiedGutterAST:e==="deletions"?n.deletionsGutterAST:n.additionsGutterAST,i=e==="unified"?n.unifiedContentAST:e==="deletions"?n.deletionsContentAST:n.additionsContentAST;if(t==null||i==null)return;const r=me(t);return r.properties.style=`grid-row: span ${n.rowCount}`,[r,ti(i,n.rowCount)]}renderFullAST(e,n=[]){const t=this.getOptionsWithDefaults().hunkSeparators==="line-info",i=this.renderCodeAST("unified",e);if(i!=null)return n.push(T({tagName:"code",children:i,properties:{"data-code":"","data-container-size":t?"":void 0,"data-unified":""}})),{...e.preNode,children:n};const r=this.renderCodeAST("deletions",e);r!=null&&n.push(T({tagName:"code",children:r,properties:{"data-code":"","data-container-size":t?"":void 0,"data-deletions":""}}));const o=this.renderCodeAST("additions",e);return o!=null&&n.push(T({tagName:"code",children:o,properties:{"data-code":"","data-container-size":t?"":void 0,"data-additions":""}})),{...e.preNode,children:n}}renderFullHTML(e,n=[]){return ce(this.renderFullAST(e,n))}renderPartialHTML(e,n){return n==null?ce(e):ce(T({tagName:"code",children:e,properties:{"data-code":"","data-container-size":this.getOptionsWithDefaults().hunkSeparators==="line-info"?"":void 0,[`data-${n}`]:""}}))}getAnnotations(e,n,t,i,r){const o={type:"annotation",hunkIndex:i,lineIndex:r,annotations:[]};if(n!=null)for(const l of this.deletionAnnotations[n]??[])o.annotations.push(ue(l));const a={type:"annotation",hunkIndex:i,lineIndex:r,annotations:[]};if(t!=null)for(const l of this.additionAnnotations[t]??[])(e==="unified"?o:a).annotations.push(ue(l));if(e==="unified")return o.annotations.length>0?o:void 0;if(!(a.annotations.length===0&&o.annotations.length===0))return{deletionSpan:o,additionSpan:a}}renderHeader(e){const{headerRenderMode:n}=this.getOptionsWithDefaults();return ri({fileOrDiff:e,mode:n})}};function Sn(e){return`${e} unmodified line${e>1?"s":""}`}function Cn(e,n){for(const t of e)n.unifiedContentAST.push(t.content),n.pushToGutter("unified",t.gutter),n.incrementRowCount(1)}function wn(e,n,t){for(const{deletion:i,addition:r}of e){if(i==null&&r==null)continue;const o=i!=null&&r!=null?void 0:i==null?"deletions":"additions";(o==null||t.side!==o)&&t.flush(),i!=null&&(n.deletionsContentAST.push(i.content),n.pushToGutter("deletions",i.gutter)),r!=null&&(n.additionsContentAST.push(r.content),n.pushToGutter("additions",r.gutter)),o!=null&&(t.side=o,t.increment()),n.incrementRowCount(1)}}function Ln({diffStyle:e,type:n,deletionLine:t,additionLine:i,unifiedSpan:r,deletionSpan:o,additionSpan:a,createAnnotationElement:l,context:s}){let d=!1;if(e==="unified"){if(i!=null?s.unifiedContentAST.push(i):t!=null&&s.unifiedContentAST.push(t),r!=null){const f=n==="change"?t!=null?"change-deletion":"change-addition":n;s.unifiedContentAST.push(l(r)),s.pushToGutter("unified",W(f,"annotation",1)),d=!0}}else if(e==="split"){if(t!=null&&s.deletionsContentAST.push(t),i!=null&&s.additionsContentAST.push(i),o!=null){const f=n==="change"?t!=null?"change-deletion":"context":n;s.deletionsContentAST.push(l(o)),s.pushToGutter("deletions",W(f,"annotation",1)),d=!0}if(a!=null){const f=n==="change"?i!=null?"change-addition":"context":n;s.additionsContentAST.push(l(a)),s.pushToGutter("additions",W(f,"annotation",1)),d=!0}}d&&s.incrementRowCount(1)}function Oe(e,{hunkIndex:n,collapsedLines:t,rangeSize:i,hunkSpecs:r,isFirstHunk:o,isLastHunk:a,isExpandable:l},s){if(t<=0)return;const d=e==="unified"?s.unifiedContentAST:e==="deletions"?s.deletionsContentAST:s.additionsContentAST;if(s.hunkSeparators==="metadata"){r!=null&&(s.pushToGutter(e,oe({type:"metadata",content:r,isFirstHunk:o,isLastHunk:a})),d.push(oe({type:"metadata",content:r,isFirstHunk:o,isLastHunk:a})),e!=="additions"&&s.incrementRowCount(1));return}if(s.hunkSeparators==="simple"){n>0&&(s.pushToGutter(e,oe({type:"simple",isFirstHunk:o,isLastHunk:!1})),d.push(oe({type:"simple",isFirstHunk:o,isLastHunk:!1})),e!=="additions"&&s.incrementRowCount(1));return}const f=Hi(e,n),c=i>s.expansionLineCount,h=l?n:void 0;s.pushToGutter(e,oe({type:s.hunkSeparators,content:Sn(t),expandIndex:h,chunked:c,slotName:f,isFirstHunk:o,isLastHunk:a})),d.push(oe({type:s.hunkSeparators,content:Sn(t),expandIndex:h,chunked:c,slotName:f,isFirstHunk:o,isLastHunk:a})),e!=="additions"&&s.incrementRowCount(1),s.hunkData.push({slotName:f,hunkIndex:n,lines:t,type:e,expandable:l?{up:!o,down:!a,chunked:c}:void 0})}function xe(e,n){return e==null||e.type!=="element"||n==null?e:{...e,properties:{...e.properties,...n}}}function Oi(e){const n=e.hunks.at(-1);if(n==null||e.isPartial||e.additionLines.length===0||e.deletionLines.length===0)return 0;const t=e.additionLines.length-(n.additionLineIndex+n.additionCount),i=e.deletionLines.length-(n.deletionLineIndex+n.deletionCount);if(t!==i)throw new Error(`DiffHunksRenderer.processDiffResult: trailing context mismatch (additions=${t}, deletions=${i}) for ${e.name}`);return Math.min(t,i)}function zi(e,n){return e.lineNumber===n.lineNumber&&e.side===n.side&&e.metadata===n.metadata}function Fi(e,n){return e.slotName===n.slotName&&e.hunkIndex===n.hunkIndex&&e.lines===n.lines&&e.type===n.type&&e.expandable?.chunked===n.expandable?.chunked&&e.expandable?.up===n.expandable?.up&&e.expandable?.down===n.expandable?.down}function $i(e){const n=e[0];if(n!=="+"&&n!=="-"&&n!==" "&&n!=="\\"){console.error(`parseLineType: Invalid firstChar: "${n}", full line: "${e}"`);return}const t=e.substring(1);return{line:t===""?`
`:t,type:n===" "?"context":n==="\\"?"metadata":n==="+"?"addition":"deletion"}}function _i(e,n,t=!1){const i=ye.test(e),r=e.split(i?ye:Qe);let o;const a=[];for(const l of r){if(i&&!ye.test(l)){if(o==null)o=l;else{if(t)throw Error("parsePatchContent: unknown file blob");console.error("parsePatchContent: unknown file blob:",l)}continue}else if(!i&&!Qe.test(l)){if(o==null)o=l;else{if(t)throw Error("parsePatchContent: unknown file blob");console.error("parsePatchContent: unknown file blob:",l)}continue}const s=Un(l,{cacheKey:void 0,isGitDiff:i,throwOnError:t});s!=null&&a.push(s)}return{patchMetadata:o,files:a}}function Un(e,{cacheKey:n,isGitDiff:t=ye.test(e),oldFile:i,newFile:r,throwOnError:o=!1}={}){let a=0;const l=e.split(Vn);let s;const d=i==null||r==null;let f=0,c=0;for(const h of l){const u=h.split(Te),m=u.shift();if(m==null){if(o)throw Error("parsePatchContent: invalid hunk");console.error("parsePatchContent: invalid hunk",h);continue}const x=m.match(Kn);let y=0,C=0;if(x==null||s==null){if(s!=null){if(o)throw Error("parsePatchContent: Invalid hunk");console.error("parsePatchContent: Invalid hunk",h);continue}s={name:"",type:"change",hunks:[],splitLineCount:0,unifiedLineCount:0,isPartial:d,additionLines:!d&&i!=null&&r!=null?r.contents.split(Te):[],deletionLines:!d&&i!=null&&r!=null?i.contents.split(Te):[],cacheKey:n},s.additionLines.length===1&&r?.contents===""&&(s.additionLines.length=0),s.deletionLines.length===1&&i?.contents===""&&(s.deletionLines.length=0),u.unshift(m);for(const k of u){const w=k.match(t?Yn:Xn);if(k.startsWith("diff --git")){const[,,L,,E]=k.trim().match(Jn)??[];s.name=E.trim(),L!==E&&(s.prevName=L.trim())}else if(w!=null){const[,L,E]=w;L==="---"&&E!=="/dev/null"?(s.prevName=E.trim(),s.name=E.trim()):L==="+++"&&E!=="/dev/null"&&(s.name=E.trim())}else if(t){if(k.startsWith("new mode ")&&(s.mode=k.replace("new mode","").trim()),k.startsWith("old mode ")&&(s.prevMode=k.replace("old mode","").trim()),k.startsWith("new file mode")&&(s.type="new",s.mode=k.replace("new file mode","").trim()),k.startsWith("deleted file mode")&&(s.type="deleted",s.mode=k.replace("deleted file mode","").trim()),k.startsWith("similarity index")&&(k.startsWith("similarity index 100%")?s.type="rename-pure":s.type="rename-changed"),k.startsWith("index ")){const[,L,E,A]=k.trim().match(Zn)??[];L!=null&&(s.prevObjectId=L),E!=null&&(s.newObjectId=E),A!=null&&(s.mode=A)}k.startsWith("rename from ")&&(s.prevName=k.replace("rename from ","").trim()),k.startsWith("rename to ")&&(s.name=k.replace("rename to ","").trim())}}continue}let p,b;for(;u.length>0&&(u[u.length-1]===`
`||u[u.length-1]==="\r"||u[u.length-1]===`\r
`||u[u.length-1]==="");)u.pop();const v=parseInt(x[3]),S=parseInt(x[1]);f=d?f:S-1,c=d?c:v-1;const g={collapsedBefore:0,splitLineCount:0,splitLineStart:0,unifiedLineCount:0,unifiedLineStart:0,additionCount:parseInt(x[4]??"1"),additionStart:v,additionLines:y,deletionCount:parseInt(x[2]??"1"),deletionStart:S,deletionLines:C,deletionLineIndex:f,additionLineIndex:c,hunkContent:[],hunkContext:x[5],hunkSpecs:m,noEOFCRAdditions:!1,noEOFCRDeletions:!1};if(isNaN(g.additionCount)||isNaN(g.deletionCount)||isNaN(g.additionStart)||isNaN(g.deletionStart)){if(o)throw Error("parsePatchContent: invalid hunk metadata");console.error("parsePatchContent: invalid hunk metadata",g);continue}for(const k of u){const w=$i(k);if(w==null){console.error("processFile: invalid rawLine:",k);continue}const{type:L,line:E}=w;if(L==="addition")(p==null||p.type!=="change")&&(p=ze("change",f,c),g.hunkContent.push(p)),c++,d&&s.additionLines.push(E),p.additions++,y++,b="addition";else if(L==="deletion")(p==null||p.type!=="change")&&(p=ze("change",f,c),g.hunkContent.push(p)),f++,d&&s.deletionLines.push(E),p.deletions++,C++,b="deletion";else if(L==="context")(p==null||p.type!=="context")&&(p=ze("context",f,c),g.hunkContent.push(p)),c++,f++,d&&(s.deletionLines.push(E),s.additionLines.push(E)),p.lines++,b="context";else if(L==="metadata"&&p!=null){if(p.type==="context"?(g.noEOFCRAdditions=!0,g.noEOFCRDeletions=!0):b==="deletion"?g.noEOFCRDeletions=!0:b==="addition"&&(g.noEOFCRAdditions=!0),d&&(b==="addition"||b==="context")){const A=s.additionLines.length-1;A>=0&&(s.additionLines[A]=ae(s.additionLines[A]))}if(d&&(b==="deletion"||b==="context")){const A=s.deletionLines.length-1;A>=0&&(s.deletionLines[A]=ae(s.deletionLines[A]))}}}g.additionLines=y,g.deletionLines=C,g.collapsedBefore=Math.max(g.additionStart-1-a,0),s.hunks.push(g),a=g.additionStart+g.additionCount-1;for(const k of g.hunkContent)k.type==="context"?(g.splitLineCount+=k.lines,g.unifiedLineCount+=k.lines):(g.splitLineCount+=Math.max(k.additions,k.deletions),g.unifiedLineCount+=k.deletions+k.additions);g.splitLineStart=s.splitLineCount+g.collapsedBefore,g.unifiedLineStart=s.unifiedLineCount+g.collapsedBefore,s.splitLineCount+=g.collapsedBefore+g.splitLineCount,s.unifiedLineCount+=g.collapsedBefore+g.unifiedLineCount}if(s!=null){if(s.hunks.length>0&&!d&&s.additionLines.length>0&&s.deletionLines.length>0){const h=s.hunks[s.hunks.length-1],u=h.additionStart+h.additionCount-1,m=s.additionLines.length,x=Math.max(m-u,0);s.splitLineCount+=x,s.unifiedLineCount+=x}return t||(s.prevName!=null&&s.name!==s.prevName?s.hunks.length>0?s.type="rename-changed":s.type="rename-pure":r!=null&&r.contents===""?s.type="deleted":i!=null&&i.contents===""&&(s.type="new")),s.type!=="rename-pure"&&s.type!=="rename-changed"&&(s.prevName=void 0),s}}function Wi(e,n,t=!1){const i=[];for(const r of e.split(qn))try{i.push(_i(r,n!=null?`${n}-${i.length}`:void 0,t))}catch(o){if(t)throw o;console.error(o)}return i}function ze(e,n,t){return e==="change"?{type:"change",additions:0,deletions:0,additionLineIndex:t,deletionLineIndex:n}:{type:"context",lines:0,additionLineIndex:t,deletionLineIndex:n}}function Be(e,n,t,i=!1){const r=Un(zt(e.name,n.name,e.contents,n.contents,e.header,n.header,t),{cacheKey:(()=>{if(e.cacheKey!=null&&n.cacheKey!=null)return`${e.cacheKey}:${n.cacheKey}`})(),oldFile:e,newFile:n,throwOnError:i});if(r==null)throw new Error("parseDiffFrom: FileInvalid diff -- probably need to fix something -- if the files are the same maybe?");return n.lang!=null&&(r.lang=n.lang),r}let Gi=-1;var On=class{static LoadedCustomComponent=wi;__id=`file-diff:${++Gi}`;fileContainer;spriteSVG;pre;codeUnified;codeDeletions;codeAdditions;bufferBefore;bufferAfter;themeCSSStyle;appliedThemeCSS;unsafeCSSStyle;appliedUnsafeCSS;gutterUtilityContent;headerElement;headerPrefix;headerMetadata;headerCustom;separatorCache=new Map;errorWrapper;placeHolder;hunksRenderer;resizeManager;scrollSyncManager;interactionManager;annotationCache=new Map;lineAnnotations=[];deletionFile;additionFile;fileDiff;renderRange;appliedPreAttributes;lastRenderedHeaderHTML;lastRowCount;enabled=!0;constructor(e={theme:q},n,t=!1){this.options=e,this.workerManager=n,this.isContainerManaged=t,this.hunksRenderer=this.createHunksRenderer(e),this.resizeManager=new ei,this.scrollSyncManager=new Mi,this.interactionManager=new Xt("diff",hn(e,typeof e.hunkSeparators=="function"||(e.hunkSeparators??"line-info")==="line-info"||e.hunkSeparators==="line-info-basic"?this.handleExpandHunk:void 0,this.getLineIndex)),this.workerManager?.subscribeToThemeChanges(this),this.enabled=!0}handleHighlightRender=()=>{this.rerender()};getHunksRendererOptions(e){return{...e,headerRenderMode:e.renderCustomHeader!=null?"custom":"default",hunkSeparators:typeof e.hunkSeparators=="function"?"custom":e.hunkSeparators}}createHunksRenderer(e){return new Ui(this.getHunksRendererOptions(e),this.handleHighlightRender,this.workerManager)}getLineIndex=(e,n="additions")=>{if(this.fileDiff==null)return;const t=this.fileDiff.hunks.at(-1);let i,r;e:for(const o of this.fileDiff.hunks){let a=n==="deletions"?o.deletionStart:o.additionStart;const l=n==="deletions"?o.deletionCount:o.additionCount;let s=o.splitLineStart,d=o.unifiedLineStart;if(e<a){const f=a-e;i=Math.max(d-f,0),r=Math.max(s-f,0);break e}if(e>=a+l){if(o===t){const f=e-(a+l);i=d+o.unifiedLineCount+f,r=s+o.splitLineCount+f;break e}continue}for(const f of o.hunkContent)if(f.type==="context")if(e<a+f.lines){const c=e-a;r=s+c,i=d+c;break e}else a+=f.lines,s+=f.lines,d+=f.lines;else{const c=n==="deletions"?f.deletions:f.additions;if(e<a+c){const h=e-a;i=d+(n==="additions"?f.deletions:0)+h,r=s+h;break e}else a+=c,s+=Math.max(f.deletions,f.additions),d+=f.deletions+f.additions}break e}if(!(i==null||r==null))return[i,r]};setOptions(e){e!=null&&(this.options=e,this.hunksRenderer.setOptions(this.getHunksRendererOptions(e)),this.interactionManager.setOptions(hn(e,typeof e.hunkSeparators=="function"||(e.hunkSeparators??"line-info")==="line-info"||e.hunkSeparators==="line-info-basic"?this.handleExpandHunk:void 0,this.getLineIndex)))}mergeOptions(e){this.options={...this.options,...e}}setThemeType(e){(this.options.themeType??"system")!==e&&(this.mergeOptions({themeType:e}),!(typeof this.options.theme=="string"||this.fileContainer==null||this.appliedThemeCSS==null)&&this.applyThemeState(this.fileContainer,this.appliedThemeCSS.themeStyles,e,this.appliedThemeCSS.baseThemeType))}getHoveredLine=()=>this.interactionManager.getHoveredLine();setLineAnnotations(e){this.lineAnnotations=e}canPartiallyRender(e,n,t){return!(e||n||t||typeof this.options.hunkSeparators=="function")}setSelectedLines(e){this.interactionManager.setSelection(e)}cleanUp(e=!1){this.resizeManager.cleanUp(),this.interactionManager.cleanUp(),this.scrollSyncManager.cleanUp(),this.workerManager?.unsubscribeToThemeChanges(this),this.renderRange=void 0,this.isContainerManaged||this.fileContainer?.remove(),this.fileContainer?.shadowRoot!=null&&(this.fileContainer.shadowRoot.innerHTML=""),this.fileContainer=void 0,this.pre!=null&&(this.pre.innerHTML="",this.pre=void 0),this.codeUnified=void 0,this.codeDeletions=void 0,this.codeAdditions=void 0,this.bufferBefore=void 0,this.bufferAfter=void 0,this.appliedPreAttributes=void 0,this.headerElement=void 0,this.headerPrefix=void 0,this.headerMetadata=void 0,this.headerCustom=void 0,this.lastRenderedHeaderHTML=void 0,this.errorWrapper=void 0,this.spriteSVG=void 0,this.lastRowCount=void 0,this.themeCSSStyle=void 0,this.appliedThemeCSS=void 0,this.unsafeCSSStyle=void 0,this.appliedUnsafeCSS=void 0,e?this.hunksRenderer.recycle():(this.hunksRenderer.cleanUp(),this.workerManager=void 0,this.fileDiff=void 0,this.deletionFile=void 0,this.additionFile=void 0),this.enabled=!1}virtualizedSetup(){this.enabled=!0,this.workerManager?.subscribeToThemeChanges(this)}hydrate(e){const{fileContainer:n,prerenderedHTML:t,preventEmit:i=!1,lineAnnotations:r,oldFile:o,newFile:a,fileDiff:l}=e;this.hydrateElements(n,t),this.pre==null&&this.headerElement==null?this.render({...e,preventEmit:!0}):this.hydrationSetup({fileDiff:l,oldFile:o,newFile:a,lineAnnotations:r}),i||this.emitPostRender()}hydrateElements(e,n){Si(e,n);for(const t of e.shadowRoot?.children??[]){if(t instanceof SVGElement){this.spriteSVG=t;continue}if(t instanceof HTMLElement){if(t instanceof HTMLPreElement){this.pre=t;for(const i of t.children)!(i instanceof HTMLElement)||i.tagName.toLowerCase()!=="code"||("deletions"in i.dataset&&(this.codeDeletions=i),"additions"in i.dataset&&(this.codeAdditions=i),"unified"in i.dataset&&(this.codeUnified=i));continue}if("diffsHeader"in t.dataset){this.headerElement=t;continue}if(t instanceof HTMLStyleElement&&t.hasAttribute(Tn)){this.themeCSSStyle=t;continue}if(t instanceof HTMLStyleElement&&t.hasAttribute(An)){this.unsafeCSSStyle=t,this.appliedUnsafeCSS=t.textContent;continue}}}this.pre!=null&&(this.syncCodeNodesFromPre(this.pre),this.pre.removeAttribute("data-dehydrated")),(this.pre!=null||this.headerElement!=null)&&(this.fileContainer=e)}hydrationSetup({fileDiff:e,oldFile:n,newFile:t,lineAnnotations:i}){const{diffStyle:r="split",overflow:o="scroll"}=this.options;this.lineAnnotations=i??this.lineAnnotations,this.additionFile=t,this.deletionFile=n,this.fileDiff=e??(n!=null&&t!=null?Be(n,t,this.options.parseDiffOptions):void 0),this.pre!=null&&(this.hunksRenderer.hydrate(this.fileDiff),this.renderAnnotations(),this.renderGutterUtility(),this.injectUnsafeCSS(),this.interactionManager.setup(this.pre),this.resizeManager.setup(this.pre,o==="wrap"),o==="scroll"&&r==="split"&&this.scrollSyncManager.setup(this.pre,this.codeDeletions,this.codeAdditions))}rerender(){!this.enabled||this.fileDiff==null&&this.additionFile==null&&this.deletionFile==null||this.render({forceRender:!0,renderRange:this.renderRange})}handleExpandHunk=(e,n,t)=>{this.expandHunk(e,n,t)};expandHunk=(e,n,t)=>{this.hunksRenderer.expandHunk(e,n,t),this.rerender()};render({oldFile:e,newFile:n,fileDiff:t,forceRender:i=!1,preventEmit:r=!1,lineAnnotations:o,fileContainer:a,containerWrapper:l,renderRange:s}){if(!this.enabled)throw new Error("FileDiff.render: attempting to call render after cleaned up");const{collapsed:d=!1}=this.options,f=d?void 0:s,c=e!=null&&n!=null&&(!sn(e,this.deletionFile)||!sn(n,this.additionFile));let h=t!=null&&t!==this.fileDiff;const u=o!=null&&(o.length>0||this.lineAnnotations.length>0)?o!==this.lineAnnotations:!1;if(!d&&Dn(f,this.renderRange)&&!i&&!u&&(t!=null&&t===this.fileDiff||t==null&&!c))return!1;const{renderRange:m}=this;if(this.renderRange=f,this.deletionFile=e,this.additionFile=n,t!=null?this.fileDiff=t:e!=null&&n!=null&&c&&(h=!0,this.fileDiff=Be(e,n,this.options.parseDiffOptions)),o!=null&&this.setLineAnnotations(o),this.fileDiff==null)return!1;this.hunksRenderer.setOptions(this.getHunksRendererOptions(this.options)),this.hunksRenderer.setLineAnnotations(this.lineAnnotations);const{diffStyle:x="split",disableErrorHandling:y=!1,disableFileHeader:C=!1,overflow:p="scroll",themeType:b="system"}=this.options;if(C&&(this.headerElement!=null&&(this.headerElement.remove(),this.headerElement=void 0,this.lastRenderedHeaderHTML=void 0),this.clearHeaderSlots()),a=this.getOrCreateFileContainer(a,l),d){this.removeRenderedCode(),this.clearAuxiliaryNodes();try{const v=this.hunksRenderer.renderDiff(this.fileDiff,nt);v!=null&&this.applyThemeState(a,v.themeStyles,b,v.baseThemeType),v?.headerElement!=null&&this.applyHeaderToDOM(v.headerElement,a),this.renderSeparators([]),this.injectUnsafeCSS()}catch(v){if(y)throw v;console.error(v),v instanceof Error&&this.applyErrorToDOM(v,a)}return r||this.emitPostRender(),!0}try{const v=this.getOrCreatePreNode(a);if(!(this.canPartiallyRender(i,u,c||h)&&this.applyPartialRender({previousRenderRange:m,renderRange:f}))){const S=this.hunksRenderer.renderDiff(this.fileDiff,f);if(S==null)return this.workerManager?.isInitialized()===!1&&this.workerManager.initialize().then(()=>this.rerender()),!1;this.applyThemeState(a,S.themeStyles,b,S.baseThemeType),S.headerElement!=null&&this.applyHeaderToDOM(S.headerElement,a),S.additionsContentAST!=null||S.deletionsContentAST!=null||S.unifiedContentAST!=null?this.applyHunksToDOM(v,S):this.pre!=null&&(this.pre.remove(),this.pre=void 0),this.renderSeparators(S.hunkData)}this.applyBuffers(v,f),this.injectUnsafeCSS(),this.renderAnnotations(),this.renderGutterUtility(),this.interactionManager.setup(v),this.resizeManager.setup(v,p==="wrap"),p==="scroll"&&x==="split"?this.scrollSyncManager.setup(v,this.codeDeletions,this.codeAdditions):this.scrollSyncManager.cleanUp()}catch(v){if(y)throw v;console.error(v),v instanceof Error&&this.applyErrorToDOM(v,a)}return r||this.emitPostRender(),!0}emitPostRender(){this.fileContainer!=null&&this.options.onPostRender?.(this.fileContainer,this)}removeRenderedCode(){this.resizeManager.cleanUp(),this.scrollSyncManager.cleanUp(),this.interactionManager.cleanUp(),this.bufferBefore?.remove(),this.bufferBefore=void 0,this.bufferAfter?.remove(),this.bufferAfter=void 0,this.codeUnified?.remove(),this.codeUnified=void 0,this.codeDeletions?.remove(),this.codeDeletions=void 0,this.codeAdditions?.remove(),this.codeAdditions=void 0,this.pre?.remove(),this.pre=void 0,this.appliedPreAttributes=void 0,this.lastRowCount=void 0}clearAuxiliaryNodes(){for(const{element:e}of this.separatorCache.values())e.remove();this.separatorCache.clear();for(const{element:e}of this.annotationCache.values())e.remove();this.annotationCache.clear(),this.gutterUtilityContent?.remove(),this.gutterUtilityContent=void 0}renderPlaceholder(e){if(this.fileContainer==null)return!1;if(this.cleanChildNodes(),this.placeHolder==null){const n=this.fileContainer.shadowRoot??this.fileContainer.attachShadow({mode:"open"});this.placeHolder=document.createElement("div"),this.placeHolder.dataset.placeholder="",n.appendChild(this.placeHolder)}return this.placeHolder.style.setProperty("height",`${e}px`),!0}cleanChildNodes(){this.resizeManager.cleanUp(),this.scrollSyncManager.cleanUp(),this.interactionManager.cleanUp(),this.bufferAfter?.remove(),this.bufferBefore?.remove(),this.codeAdditions?.remove(),this.codeDeletions?.remove(),this.codeUnified?.remove(),this.errorWrapper?.remove(),this.headerElement?.remove(),this.gutterUtilityContent?.remove(),this.headerPrefix?.remove(),this.headerMetadata?.remove(),this.headerCustom?.remove(),this.pre?.remove(),this.spriteSVG?.remove(),this.themeCSSStyle?.remove(),this.unsafeCSSStyle?.remove(),this.bufferAfter=void 0,this.bufferBefore=void 0,this.codeAdditions=void 0,this.codeDeletions=void 0,this.codeUnified=void 0,this.errorWrapper=void 0,this.headerElement=void 0,this.gutterUtilityContent=void 0,this.headerPrefix=void 0,this.headerMetadata=void 0,this.headerCustom=void 0,this.pre=void 0,this.spriteSVG=void 0,this.themeCSSStyle=void 0,this.appliedThemeCSS=void 0,this.unsafeCSSStyle=void 0,this.appliedUnsafeCSS=void 0,this.lastRenderedHeaderHTML=void 0,this.lastRowCount=void 0}renderSeparators(e){const{hunkSeparators:n}=this.options;if(this.isContainerManaged||this.fileContainer==null||typeof n!="function"){for(const{element:i}of this.separatorCache.values())i.remove();this.separatorCache.clear();return}const t=new Map(this.separatorCache);for(const i of e){const r=i.slotName;let o=this.separatorCache.get(r);if(o==null||!Fi(i,o.hunkData)){o?.element.remove();const a=document.createElement("div");a.style.display="contents",a.slot=i.slotName;const l=n(i,this);l!=null&&a.appendChild(l),this.fileContainer.appendChild(a),o={element:a,hunkData:i},this.separatorCache.set(r,o)}t.delete(r)}for(const[i,{element:r}]of t.entries())this.separatorCache.delete(i),r.remove()}renderAnnotations(){if(this.isContainerManaged||this.fileContainer==null){for(const{element:t}of this.annotationCache.values())t.remove();this.annotationCache.clear();return}const e=new Map(this.annotationCache),{renderAnnotation:n}=this.options;if(n!=null&&this.lineAnnotations.length>0)for(const[t,i]of this.lineAnnotations.entries()){const r=`${t}-${ue(i)}`;let o=this.annotationCache.get(r);if(o==null||!zi(i,o.annotation)){o?.element.remove();const a=n(i);if(a==null)continue;o={element:pi(ue(i)),annotation:i},o.element.appendChild(a),this.fileContainer.appendChild(o.element),this.annotationCache.set(r,o)}e.delete(r)}for(const[t,{element:i}]of e.entries())this.annotationCache.delete(t),i.remove()}renderGutterUtility(){const e=this.options.renderGutterUtility??this.options.renderHoverUtility;if(this.fileContainer==null||e==null){this.gutterUtilityContent?.remove(),this.gutterUtilityContent=void 0;return}const n=e(this.interactionManager.getHoveredLine);if(n!=null&&this.gutterUtilityContent!=null)return;if(n==null){this.gutterUtilityContent?.remove(),this.gutterUtilityContent=void 0;return}const t=mi();t.appendChild(n),this.fileContainer.appendChild(t),this.gutterUtilityContent=t}getOrCreateFileContainer(e,n){const t=this.fileContainer;if(this.fileContainer=e??this.fileContainer??document.createElement(we),t!=null&&t!==this.fileContainer&&(this.lastRenderedHeaderHTML=void 0,this.headerElement=void 0),n!=null&&this.fileContainer.parentNode!==n&&n.appendChild(this.fileContainer),this.spriteSVG==null){const i=document.createElement("div");i.innerHTML=ci;const r=i.firstChild;r instanceof SVGElement&&(this.spriteSVG=r,this.fileContainer.shadowRoot?.appendChild(this.spriteSVG))}return this.fileContainer}getFileContainer(){return this.fileContainer}getOrCreatePreNode(e){const n=e.shadowRoot??e.attachShadow({mode:"open"});return this.pre==null?(this.pre=document.createElement("pre"),this.appliedPreAttributes=void 0,this.codeUnified=void 0,this.codeDeletions=void 0,this.codeAdditions=void 0,n.appendChild(this.pre)):this.pre.parentNode!==n&&(n.appendChild(this.pre),this.appliedPreAttributes=void 0),this.placeHolder?.remove(),this.placeHolder=void 0,this.pre}syncCodeNodesFromPre(e){this.codeUnified=void 0,this.codeDeletions=void 0,this.codeAdditions=void 0;for(const n of Array.from(e.children))n instanceof HTMLElement&&(n.hasAttribute("data-unified")?this.codeUnified=n:n.hasAttribute("data-deletions")?this.codeDeletions=n:n.hasAttribute("data-additions")&&(this.codeAdditions=n))}applyHeaderToDOM(e,n){this.cleanupErrorWrapper(),this.placeHolder?.remove(),this.placeHolder=void 0;const{fileDiff:t}=this,i=ce(e);if(i!==this.lastRenderedHeaderHTML){const d=document.createElement("div");d.innerHTML=i;const f=d.firstElementChild;if(!(f instanceof HTMLElement))return;this.headerElement!=null?n.shadowRoot?.replaceChild(f,this.headerElement):n.shadowRoot?.prepend(f),this.headerElement=f,this.lastRenderedHeaderHTML=i}if(this.isContainerManaged||t==null)return;const{renderCustomHeader:r,renderHeaderPrefix:o,renderHeaderMetadata:a}=this.options;if(r!=null){const d=r(t)??void 0;this.headerCustom=this.upsertHeaderSlotElement(n,this.headerCustom,Xe,d),this.headerPrefix?.remove(),this.headerMetadata?.remove(),this.headerPrefix=void 0,this.headerMetadata=void 0;return}const l=o?.(t)??void 0,s=a?.(t)??void 0;this.headerPrefix=this.upsertHeaderSlotElement(n,this.headerPrefix,Ve,l),this.headerMetadata=this.upsertHeaderSlotElement(n,this.headerMetadata,Ke,s),this.headerCustom?.remove(),this.headerCustom=void 0}clearHeaderSlots(){this.headerPrefix?.remove(),this.headerMetadata?.remove(),this.headerCustom?.remove(),this.headerPrefix=void 0,this.headerMetadata=void 0,this.headerCustom=void 0}upsertHeaderSlotElement(e,n,t,i){if(i==null){n?.remove();return}const r=n??this.createHeaderSlotElement(t);return n==null&&e.appendChild(r),this.replaceHeaderSlotContent(r,i),r}replaceHeaderSlotContent(e,n){e.replaceChildren(),n instanceof Element?e.appendChild(n):e.innerText=`${n}`}createHeaderSlotElement(e){const n=document.createElement("div");return n.slot=e,n}injectUnsafeCSS(){const{unsafeCSS:e}=this.options,n=this.fileContainer?.shadowRoot;if(n!=null){if(e==null||e===""){this.unsafeCSSStyle!=null&&(this.unsafeCSSStyle.remove(),this.unsafeCSSStyle=void 0),this.appliedUnsafeCSS=void 0;return}this.unsafeCSSStyle?.parentNode===n&&this.appliedUnsafeCSS===e||(this.unsafeCSSStyle??=gi(),this.unsafeCSSStyle.parentNode!==n&&n.appendChild(this.unsafeCSSStyle),this.unsafeCSSStyle.textContent=vi(e),this.appliedUnsafeCSS=e)}}applyThemeState(e,n,t,i){const r=e.shadowRoot??e.attachShadow({mode:"open"}),o=i??t;this.themeCSSStyle?.parentNode===r&&this.appliedThemeCSS?.themeStyles===n&&this.appliedThemeCSS.themeType===o||(this.themeCSSStyle=xi({shadowRoot:r,currentNode:this.themeCSSStyle,themeCSS:ki(n,o)}),this.appliedThemeCSS=this.themeCSSStyle!=null?{themeStyles:n,themeType:o,baseThemeType:i}:void 0)}applyHunksToDOM(e,n){const{overflow:t="scroll"}=this.options,i=(this.options.hunkSeparators??"line-info")==="line-info",r=t==="wrap"?n.rowCount:void 0;this.cleanupErrorWrapper(),this.applyPreNodeAttributes(e,n);let o=!1;const a=[],l=this.hunksRenderer.renderCodeAST("unified",n),s=this.hunksRenderer.renderCodeAST("deletions",n),d=this.hunksRenderer.renderCodeAST("additions",n);l!=null?(o=this.codeUnified==null||this.codeAdditions!=null||this.codeDeletions!=null,this.codeDeletions?.remove(),this.codeDeletions=void 0,this.codeAdditions?.remove(),this.codeAdditions=void 0,this.codeUnified=Ne({code:this.codeUnified,columnType:"unified",rowSpan:r,containerSize:i}),this.codeUnified.innerHTML=this.hunksRenderer.renderPartialHTML(l),a.push(this.codeUnified)):s!=null||d!=null?(s!=null?(o=this.codeDeletions==null||this.codeUnified!=null,this.codeUnified?.remove(),this.codeUnified=void 0,this.codeDeletions=Ne({code:this.codeDeletions,columnType:"deletions",rowSpan:r,containerSize:i}),this.codeDeletions.innerHTML=this.hunksRenderer.renderPartialHTML(s),a.push(this.codeDeletions)):(this.codeDeletions?.remove(),this.codeDeletions=void 0),d!=null?(o=o||this.codeAdditions==null||this.codeUnified!=null,this.codeUnified?.remove(),this.codeUnified=void 0,this.codeAdditions=Ne({code:this.codeAdditions,columnType:"additions",rowSpan:r,containerSize:i}),this.codeAdditions.innerHTML=this.hunksRenderer.renderPartialHTML(d),a.push(this.codeAdditions)):(this.codeAdditions?.remove(),this.codeAdditions=void 0)):(this.codeUnified?.remove(),this.codeUnified=void 0,this.codeDeletions?.remove(),this.codeDeletions=void 0,this.codeAdditions?.remove(),this.codeAdditions=void 0),a.length===0?e.textContent="":o&&e.replaceChildren(...a),this.lastRowCount=n.rowCount}applyPartialRender({previousRenderRange:e,renderRange:n}){const{pre:t,codeUnified:i,codeAdditions:r,codeDeletions:o,options:{diffStyle:a="split"}}=this;if(t==null||e==null||n==null||!Number.isFinite(e.totalLines)||!Number.isFinite(n.totalLines)||this.lastRowCount==null)return!1;const l=this.getCodeColumns(a,i,o,r);if(l==null)return!1;const s=e.startingLine,d=n.startingLine,f=s+e.totalLines,c=d+n.totalLines,h=Math.max(s,d),u=Math.min(f,c);if(u<=h)return!1;const m=Math.max(0,h-s),x=Math.max(0,f-u),y=this.trimColumns({columns:l,trimStart:m,trimEnd:x,previousStart:s,overlapStart:h,overlapEnd:u,diffStyle:a});if(y<0)throw new Error("applyPartialRender: failed to trim to overlap");if(this.lastRowCount<y)throw new Error("applyPartialRender: trimmed beyond DOM row count");let C=this.lastRowCount-y;const p=(g,k)=>{if(!(k<=0||this.fileDiff==null))return this.hunksRenderer.renderDiff(this.fileDiff,{startingLine:g,totalLines:k,bufferBefore:0,bufferAfter:0})},b=p(d,Math.max(h-d,0));if(b==null&&d<h)return!1;const v=p(u,Math.max(c-u,0));if(v==null&&c>u)return!1;const S=(g,k)=>{if(g!=null){if(a==="unified"&&!Array.isArray(l))this.insertPartialHTML(a,l,g,k);else if(a==="split"&&Array.isArray(l))this.insertPartialHTML(a,l,g,k);else throw new Error("FileDiff.applyPartialRender.applyChunk: invalid chunk application");C+=g.rowCount}};return this.cleanupErrorWrapper(),S(b,"afterbegin"),S(v,"beforeend"),this.lastRowCount!==C&&(this.applyRowSpan(a,l,C),this.lastRowCount=C),!0}insertPartialHTML(e,n,t,i){if(e==="unified"&&!Array.isArray(n)){const r=this.hunksRenderer.renderCodeAST("unified",t);this.renderPartialColumn(n,r,i)}else if(e==="split"&&Array.isArray(n)){const r=this.hunksRenderer.renderCodeAST("deletions",t),o=this.hunksRenderer.renderCodeAST("additions",t);this.renderPartialColumn(n[0],r,i),this.renderPartialColumn(n[1],o,i)}else throw new Error("FileDiff.insertPartialHTML: Invalid argument composition")}renderPartialColumn(e,n,t){if(e==null||n==null)return;const i=En(n[0]),r=En(n[1]);if(i==null||r==null)throw new Error("FileDiff.insertPartialHTML: Unexpected AST structure");const o=r.at(0);t==="beforeend"&&o?.type==="element"&&typeof o.properties["data-buffer-size"]=="number"&&this.mergeBuffersIfNecessary(o.properties["data-buffer-size"],e.content.children[e.content.children.length-1],e.gutter.children[e.gutter.children.length-1],i,r,!0);const a=r.at(-1);t==="afterbegin"&&a?.type==="element"&&typeof a.properties["data-buffer-size"]=="number"&&this.mergeBuffersIfNecessary(a.properties["data-buffer-size"],e.content.children[0],e.gutter.children[0],i,r,!1),e.gutter.insertAdjacentHTML(t,this.hunksRenderer.renderPartialHTML(i)),e.content.insertAdjacentHTML(t,this.hunksRenderer.renderPartialHTML(r))}mergeBuffersIfNecessary(e,n,t,i,r,o){if(!(n instanceof HTMLElement)||!(t instanceof HTMLElement))return;const a=this.getBufferSize(n.dataset);a!=null&&(o?(i.shift(),r.shift()):(i.pop(),r.pop()),this.updateBufferSize(n,a+e),this.updateBufferSize(t,a+e))}applyRowSpan(e,n,t){const i=r=>{r!=null&&(r.gutter.style.setProperty("grid-row",`span ${t}`),r.content.style.setProperty("grid-row",`span ${t}`))};if(e==="unified"&&!Array.isArray(n))i(n);else if(e==="split"&&Array.isArray(n))i(n[0]),i(n[1]);else throw new Error("dun fuuuuked up")}trimColumnRows(e,n,t){let i=0,r=0,o=0,a=!1;const l=t>=0;if(e==null)return 0;const s=Array.from(e.content.children),d=Array.from(e.gutter.children);if(s.length!==d.length)throw new Error("FileDiff.trimColumnRows: columns do not match");for(;o<s.length&&!(n<=0&&!l&&!a);){const f=d[o],c=s[o];if(o++,!(f instanceof HTMLElement)||!(c instanceof HTMLElement))throw console.error({gutterElement:f,contentElement:c}),new Error("FileDiff.trimColumnRows: invalid row elements");if(a&&(a=!1,f.dataset.gutterBuffer==="annotation"&&"lineAnnotation"in c.dataset||f.dataset.gutterBuffer==="metadata"&&"noNewline"in c.dataset)){f.remove(),c.remove(),r++;continue}if("lineIndex"in f.dataset&&"lineIndex"in c.dataset){(n>0||l&&i>=t)&&(f.remove(),c.remove(),n>0&&(n--,n===0&&(a=!0)),r++),i++;continue}if("separator"in f.dataset&&"separator"in c.dataset){(n>0||l&&i>=t)&&(f.remove(),c.remove(),r++);continue}if(f.dataset.gutterBuffer==="annotation"&&"lineAnnotation"in c.dataset){(n>0||l&&i>=t)&&(f.remove(),c.remove(),r++);continue}if(f.dataset.gutterBuffer==="metadata"&&"noNewline"in c.dataset){(n>0||l&&i>=t)&&(f.remove(),c.remove(),r++);continue}if(f.dataset.gutterBuffer==="buffer"&&"contentBuffer"in c.dataset){const h=this.getBufferSize(c.dataset);if(h==null)throw new Error("FileDiff.trimColumnRows: invalid element");if(n>0){const u=Math.min(n,h),m=h-u;m>0?(this.updateBufferSize(f,m),this.updateBufferSize(c,m),r+=u):(f.remove(),c.remove(),r+=h),n-=u}else if(l){const u=i,m=i+h-1;if(t<=u)f.remove(),c.remove(),r+=h;else if(t<=m){const x=m-t+1,y=h-x;this.updateBufferSize(f,y),this.updateBufferSize(c,y),r+=x}}i+=h;continue}throw console.error({gutterElement:f,contentElement:c}),new Error("FileDiff.trimColumnRows: unknown row elements")}return r}trimColumns({columns:e,diffStyle:n,overlapEnd:t,overlapStart:i,previousStart:r,trimEnd:o,trimStart:a}){const l=Math.max(0,i-r),s=t-r;if(s<0)throw new Error("FileDiff.trimColumns: overlap ends before previous");const d=a>0,f=o>0;if(!d&&!f)return 0;const c=d?l:0,h=f?s:-1;if(n==="unified"&&!Array.isArray(e))return this.trimColumnRows(e,c,h);if(n==="split"&&Array.isArray(e)){const u=this.trimColumnRows(e[0],c,h),m=this.trimColumnRows(e[1],c,h);if(e[0]!=null&&e[1]!=null&&u!==m)throw new Error("FileDiff.trimColumns: split columns out of sync");return e[0]!=null?u:m}else throw console.error({diffStyle:n,columns:e}),new Error("FileDiff.trimColumns: Invalid columns for diffType")}getBufferSize(e){const n=Number.parseInt(e?.bufferSize??"",10);return Number.isNaN(n)?void 0:n}updateBufferSize(e,n){e.dataset.bufferSize=`${n}`,e.style.setProperty("grid-row",`span ${n}`),e.style.setProperty("min-height",`calc(${n} * 1lh)`)}getCodeColumns(e,n,t,i){function r(o){if(o==null)return;const a=o.children[0],l=o.children[1];if(!(!(a instanceof HTMLElement)||!(l instanceof HTMLElement)||a.dataset.gutter==null||l.dataset.content==null))return{gutter:a,content:l}}if(e==="unified")return r(n);{const o=r(t),a=r(i);return o!=null||a!=null?[o,a]:void 0}}applyBuffers(e,n){const{disableVirtualizationBuffers:t=!1}=this.options;if(t||n==null){this.bufferBefore!=null&&(this.bufferBefore.remove(),this.bufferBefore=void 0),this.bufferAfter!=null&&(this.bufferAfter.remove(),this.bufferAfter=void 0);return}n.bufferBefore>0?(this.bufferBefore==null&&(this.bufferBefore=document.createElement("div"),this.bufferBefore.dataset.virtualizerBuffer="before",e.before(this.bufferBefore)),this.bufferBefore.style.setProperty("height",`${n.bufferBefore}px`),this.bufferBefore.style.setProperty("contain","strict")):this.bufferBefore!=null&&(this.bufferBefore.remove(),this.bufferBefore=void 0),n.bufferAfter>0?(this.bufferAfter==null&&(this.bufferAfter=document.createElement("div"),this.bufferAfter.dataset.virtualizerBuffer="after",e.after(this.bufferAfter)),this.bufferAfter.style.setProperty("height",`${n.bufferAfter}px`),this.bufferAfter.style.setProperty("contain","strict")):this.bufferAfter!=null&&(this.bufferAfter.remove(),this.bufferAfter=void 0)}applyPreNodeAttributes(e,{additionsContentAST:n,deletionsContentAST:t,totalLines:i},r){const{diffIndicators:o="bars",disableBackground:a=!1,disableLineNumbers:l=!1,overflow:s="scroll",diffStyle:d="split"}=this.options,f={type:"diff",diffIndicators:o,disableBackground:a,disableLineNumbers:l,overflow:s,split:d==="unified"?!1:n!=null&&t!=null,totalLines:i,customProperties:r};ui(f,this.appliedPreAttributes)||(Ci(e,f),this.appliedPreAttributes=f)}applyErrorToDOM(e,n){this.cleanupErrorWrapper();const t=this.getOrCreatePreNode(n);t.innerHTML="",t.remove(),this.pre=void 0,this.appliedPreAttributes=void 0;const i=n.shadowRoot??n.attachShadow({mode:"open"});this.errorWrapper??=document.createElement("div"),this.errorWrapper.dataset.errorWrapper="",this.errorWrapper.innerHTML="",i.appendChild(this.errorWrapper);const r=document.createElement("div");r.dataset.errorMessage="",r.innerText=e.message,this.errorWrapper.appendChild(r);const o=document.createElement("pre");o.dataset.errorStack="",o.innerText=e.stack??"No Error Stack",this.errorWrapper.appendChild(o)}cleanupErrorWrapper(){this.errorWrapper?.remove(),this.errorWrapper=void 0}};function En(e){if(!(e==null||e.type!=="element"))return e.children??[]}function ji(e,n){const t={...Qn,...n};return t.hunkSeparatorHeight=Bi(e,n?.hunkSeparatorHeight),t}function Bi(e,n){if(n!=null)return n;switch(e){case"simple":return 4;case"metadata":case"line-info":case"line-info-basic":case"custom":return 32}}let qi=-1;var Vi=class extends On{__id=`little-virtualized-file-diff:${++qi}`;top;height=0;metrics;heightCache=new Map;isVisible=!1;virtualizer;constructor(e,n,t,i,r=!1){super(e,i,r);const{hunkSeparators:o="line-info"}=this.options;this.virtualizer=n,this.metrics=ji(typeof o=="function"?"custom":o,t)}getLineHeight(e,n=!1){const t=this.heightCache.get(e);if(t!=null)return t;const i=n?2:1;return this.metrics.lineHeight*i}setOptions(e){if(e==null)return;const n=this.options.diffStyle,t=this.options.overflow,i=this.options.collapsed;super.setOptions(e),(n!==this.options.diffStyle||t!==this.options.overflow||i!==this.options.collapsed)&&(this.heightCache.clear(),this.computeApproximateSize(),this.renderRange=void 0),this.virtualizer.instanceChanged(this)}reconcileHeights(){const{overflow:e="scroll"}=this.options;if(this.fileContainer!=null&&(this.top=this.virtualizer.getOffsetInScrollContainer(this.fileContainer)),this.fileContainer==null||this.fileDiff==null){this.height=0;return}if(e==="scroll"&&this.lineAnnotations.length===0&&!this.virtualizer.config.resizeDebugging)return;const n=this.getDiffStyle();let t=!1;const i=n==="split"?[this.codeDeletions,this.codeAdditions]:[this.codeUnified];for(const r of i){if(r==null)continue;const o=r.children[1];if(o instanceof HTMLElement)for(const a of o.children){if(!(a instanceof HTMLElement))continue;const l=a.dataset.lineIndex;if(l==null)continue;const s=Xi(l,n);let d=a.getBoundingClientRect().height,f=!1;a.nextElementSibling instanceof HTMLElement&&("lineAnnotation"in a.nextElementSibling.dataset||"noNewline"in a.nextElementSibling.dataset)&&("noNewline"in a.nextElementSibling.dataset&&(f=!0),d+=a.nextElementSibling.getBoundingClientRect().height);const c=this.getLineHeight(s,f);d!==c&&(t=!0,d===this.metrics.lineHeight*(f?2:1)?this.heightCache.delete(s):this.heightCache.set(s,d))}}(t||this.virtualizer.config.resizeDebugging)&&this.computeApproximateSize()}onRender=e=>this.fileContainer==null?!1:(e&&(this.top=this.virtualizer.getOffsetInScrollContainer(this.fileContainer)),this.render());cleanUp(){this.fileContainer!=null&&this.virtualizer.disconnect(this.fileContainer),super.cleanUp()}expandHunk=(e,n,t)=>{this.hunksRenderer.expandHunk(e,n,t),this.computeApproximateSize(),this.renderRange=void 0,this.virtualizer.instanceChanged(this)};setVisibility(e){this.fileContainer!=null&&(this.renderRange=void 0,e&&!this.isVisible?(this.top=this.virtualizer.getOffsetInScrollContainer(this.fileContainer),this.isVisible=!0):!e&&this.isVisible&&(this.isVisible=!1,this.rerender()))}computeApproximateSize(){const e=this.height===0;if(this.height=0,this.fileDiff==null)return;const{disableFileHeader:n=!1,expandUnchanged:t=!1,collapsed:i=!1,collapsedContextThreshold:r=se,hunkSeparators:o="line-info"}=this.options,{diffHeaderHeight:a,fileGap:l,hunkSeparatorHeight:s}=this.metrics,d=this.getDiffStyle(),f=o!=="simple"&&o!=="metadata"&&o!=="line-info-basic"?l:0;if(n?o!=="simple"&&o!=="metadata"&&(this.height+=l):this.height+=a,!i&&(Ee({diff:this.fileDiff,diffStyle:d,expandedHunks:t?!0:this.hunksRenderer.getExpandedHunksMap(),collapsedContextThreshold:r,callback:({hunkIndex:c,collapsedBefore:h,collapsedAfter:u,deletionLine:m,additionLine:x})=>{const y=x!=null?x.splitLineIndex:m.splitLineIndex,C=x!=null?x.unifiedLineIndex:m.unifiedLineIndex,p=(x?.noEOFCR??!1)||(m?.noEOFCR??!1);h>0&&(c>0&&(this.height+=f),this.height+=s+f),this.height+=this.getLineHeight(d==="split"?y:C,p),u>0&&o!=="simple"&&(this.height+=f+s)}}),this.fileDiff.hunks.length>0&&(this.height+=l),this.fileContainer!=null&&this.virtualizer.config.resizeDebugging&&!e)){const c=this.fileContainer.getBoundingClientRect();c.height!==this.height?console.log("VirtualizedFileDiff.computeApproximateSize: computed height doesnt match",{name:this.fileDiff.name,elementHeight:c.height,computedHeight:this.height}):console.log("VirtualizedFileDiff.computeApproximateSize: computed height IS CORRECT")}}render({fileContainer:e,oldFile:n,newFile:t,fileDiff:i,...r}={}){const o=this.fileContainer==null;if(this.fileDiff??=i??(n!=null&&t!=null?Be(n,t,this.options.parseDiffOptions):void 0),e=this.getOrCreateFileContainer(e),this.fileDiff==null)return console.error("VirtualizedFileDiff.render: attempting to virtually render when we dont have the correct data"),!1;if(o?(this.computeApproximateSize(),this.virtualizer.connect(e,this),this.top??=this.virtualizer.getOffsetInScrollContainer(e),this.isVisible=this.virtualizer.isInstanceVisible(this.top,this.height)):this.top??=this.virtualizer.getOffsetInScrollContainer(e),!this.isVisible)return this.renderPlaceholder(this.height);const a=this.virtualizer.getWindowSpecs(),l=this.computeRenderRangeFromWindow(this.fileDiff,this.top,a);return super.render({fileDiff:this.fileDiff,fileContainer:e,renderRange:l,oldFile:n,newFile:t,...r})}getDiffStyle(){return this.options.diffStyle??"split"}getExpandedRegion(e,n,t){if(t<=0||e)return{fromStart:0,fromEnd:0,collapsedLines:Math.max(t,0),renderAll:!1};const{expandUnchanged:i=!1,collapsedContextThreshold:r=se}=this.options;if(i||t<=r)return{fromStart:t,fromEnd:0,collapsedLines:0,renderAll:!0};const o=this.hunksRenderer.getExpandedHunk(n),a=Math.min(Math.max(o.fromStart,0),t),l=Math.min(Math.max(o.fromEnd,0),t),s=a+l,d=s>=t;return{fromStart:a,fromEnd:l,collapsedLines:Math.max(t-s,0),renderAll:d}}getExpandedLineCount(e,n){let t=0;if(e.isPartial){for(const r of e.hunks)t+=n==="split"?r.splitLineCount:r.unifiedLineCount;return t}for(const[r,o]of e.hunks.entries()){const a=n==="split"?o.splitLineCount:o.unifiedLineCount;t+=a;const l=Math.max(o.collapsedBefore,0),{fromStart:s,fromEnd:d,renderAll:f}=this.getExpandedRegion(e.isPartial,r,l);l>0&&(t+=f?l:s+d)}const i=e.hunks.at(-1);if(i!=null&&Ki(e)){const r=e.additionLines.length-(i.additionLineIndex+i.additionCount),o=e.deletionLines.length-(i.deletionLineIndex+i.deletionCount);if(i!=null&&r!==o)throw new Error(`VirtualizedFileDiff: trailing context mismatch (additions=${r}, deletions=${o}) for ${e.name}`);const a=Math.min(r,o);if(i!=null&&a>0){const{fromStart:l,renderAll:s}=this.getExpandedRegion(e.isPartial,e.hunks.length,a);t+=s?a:l}}return t}computeRenderRangeFromWindow(e,n,{top:t,bottom:i}){const{disableFileHeader:r=!1,expandUnchanged:o=!1,collapsedContextThreshold:a=se,hunkSeparators:l="line-info"}=this.options,{diffHeaderHeight:s,fileGap:d,hunkLineCount:f,hunkSeparatorHeight:c,lineHeight:h}=this.metrics,u=this.getDiffStyle(),m=this.height,x=this.getExpandedLineCount(e,u),y=r?d:s;if(n<t-m||n>i)return{startingLine:0,totalLines:0,bufferBefore:0,bufferAfter:m-y-d};if(x<=f||e.hunks.length===0)return{startingLine:0,totalLines:f,bufferBefore:0,bufferAfter:0};const C=Math.ceil(Math.max(i-t,0)/h),p=Math.ceil(C/f)*f+f,b=p/f,v=b,S=[],g=(t+i)/2,k=l==="simple"||l==="metadata"||l==="line-info-basic"?0:d;let w=n+y,L=0,E,A,I;if(Ee({diff:e,diffStyle:u,expandedHunks:o?!0:this.hunksRenderer.getExpandedHunksMap(),collapsedContextThreshold:a,callback:({hunkIndex:ie,collapsedBefore:le,collapsedAfter:pe,deletionLine:Q,additionLine:K})=>{const H=K!=null?K.splitLineIndex:Q.splitLineIndex,O=K!=null?K.unifiedLineIndex:Q.unifiedLineIndex,z=(K?.noEOFCR??!1)||(Q?.noEOFCR??!1);let X=le>0?c+k+(ie>0?k:0):0;ie===0&&l==="simple"&&(X=0),w+=X;const _=L%f===0;if(_&&(S.push(w-(n+y+X)),I!=null)){if(I<=0)return!0;I--}const F=this.getLineHeight(u==="split"?H:O,z),de=Math.floor(L/f);return w>t-F&&w<i&&(E??=de),A==null&&w+F>g&&(A=de),I==null&&w>=i&&_&&(I=v),L++,w+=F,pe>0&&l!=="simple"&&(w+=c+k),!1}}),E==null)return{startingLine:0,totalLines:0,bufferBefore:0,bufferAfter:m-y-d};const R=S.length;A??=E;const U=Math.round(A-b/2),te=Math.max(0,R-b),J=Math.max(0,Math.min(U,te)),M=J*f,P=U<0?p+U*f:p,D=S[J]??0,Z=J+P/f;return{startingLine:M,totalLines:P,bufferBefore:D,bufferAfter:Z<S.length?m-y-S[Z]-d:m-(w-n)-d}}};function Ki(e){const n=e.hunks.at(-1);return n==null||e.isPartial||e.additionLines.length===0||e.deletionLines.length===0?!1:n.additionLineIndex+n.additionCount<e.additionLines.length||n.deletionLineIndex+n.deletionCount<e.deletionLines.length}function Xi(e,n){const[t,i]=e.split(",").map(Number);return n==="split"?i:t}const Yi=typeof window>"u"?$.useEffect:$.useLayoutEffect;function Ji({fileDiff:e,options:n,lineAnnotations:t,selectedLines:i,prerenderedHTML:r,metrics:o,hasGutterRenderUtility:a,hasCustomHeader:l,disableWorkerPool:s}){const d=rt(),f=$.useContext(Bt),c=$.useRef(null),h=qt(u=>{if(u!=null){if(c.current!=null)throw new Error("useFileDiffInstance: An instance should not already exist when a node is created");d!=null?c.current=new Vi(Fe({hasCustomHeader:l,hasGutterRenderUtility:a,options:n}),d,o,s?void 0:f,!0):c.current=new On(Fe({hasCustomHeader:l,hasGutterRenderUtility:a,options:n}),s?void 0:f,!0),c.current.hydrate({fileDiff:e,fileContainer:u,lineAnnotations:t,prerenderedHTML:r})}else{if(c.current==null)throw new Error("useFileDiffInstance: A FileDiff instance should exist when unmounting");c.current.cleanUp(),c.current=null}});return Yi(()=>{const{current:u}=c;if(u==null)return;const m=Fe({hasCustomHeader:l,hasGutterRenderUtility:a,options:n}),x=!Li(u.options,m);u.setOptions(m),u.render({forceRender:x,fileDiff:e,lineAnnotations:t}),i!==void 0&&u.setSelectedLines(i)}),{ref:h,getHoveredLine:$.useCallback(()=>c.current?.getHoveredLine(),[])}}function Fe({options:e,hasCustomHeader:n,hasGutterRenderUtility:t}){return t||n?{...e,renderCustomHeader:n?Ze:void 0,renderGutterUtility:t?Ze:void 0}:e}function Zi(e){const n=Wi(e);if(n.length!==1)throw console.error(n),new Error("PatchDiff: Provided patch must include only 1 patch, with 1 diff");const{files:t}=n[0];if(t.length!==1)throw console.error(t),new Error("FileDiff: Provided patch must contain exactly 1 file diff");return t[0]}function Qi({patch:e,options:n,metrics:t,lineAnnotations:i,selectedLines:r,className:o,style:a,prerenderedHTML:l,renderAnnotation:s,renderCustomHeader:d,renderHeaderPrefix:f,renderHeaderMetadata:c,renderGutterUtility:h,renderHoverUtility:u,disableWorkerPool:m=!1}){const x=er(e),{ref:y,getHoveredLine:C}=Ji({fileDiff:x,options:n,metrics:t,lineAnnotations:i,selectedLines:r,prerenderedHTML:l,hasGutterRenderUtility:h!=null||u!=null,hasCustomHeader:d!=null,disableWorkerPool:m});return N.jsx(we,{ref:y,className:o,style:a,children:tt(Ii({fileDiff:x,renderCustomHeader:d,renderHeaderPrefix:f,renderHeaderMetadata:c,renderAnnotation:s,lineAnnotations:i,renderGutterUtility:h,renderHoverUtility:u,getHoveredLine:C}),l)})}function er(e){return $.useMemo(()=>Zi(e),[e])}const nr={dark:"dark-plus",light:"light-plus"},tr={"--diffs-font-family":'"Geist Mono", ui-monospace, monospace',"--diffs-header-font-family":'"Geist Mono", ui-monospace, monospace',"--diffs-font-size":"13px","--diffs-line-height":"1.5","--diffs-light-bg":"hsl(var(--code-background))","--diffs-dark-bg":"hsl(var(--code-background))"},ir=`
[data-code] {
  overflow-x: auto;
}

[data-line] {
  min-width: max-content;
}

[data-diff] {
  margin: 0;
}

[data-separator='simple'] {
  min-height: 6px;
  background:
    linear-gradient(
      to bottom,
      transparent,
      transparent calc(50% - 1px),
      color-mix(in srgb, currentColor 12%, transparent) calc(50% - 1px),
      color-mix(in srgb, currentColor 12%, transparent) calc(50% + 1px),
      transparent calc(50% + 1px),
      transparent
    ),
    var(--diffs-bg);
}
`;function or({patch:e}){const{resolvedTheme:n}=Gn();return N.jsx("div",{className:"rounded-md bg-code overflow-hidden",children:N.jsx(Qi,{patch:e,style:{...tr,colorScheme:n},disableWorkerPool:!0,options:{theme:nr,themeType:n,diffStyle:"unified",diffIndicators:"classic",disableFileHeader:!0,hunkSeparators:"simple",overflow:"scroll",unsafeCSS:ir}})})}export{or as default};
