from __future__ import annotations

import argparse
from dataclasses import dataclass
import os
import random
import re
import sys
from collections.abc import Iterable
from pathlib import Path

from packages.profile import DEFAULT_CLONE_TEXT, render_clone_charter

from .runtime import CliRuntime
from .shell import (
    Align,
    BRAND_ACCENT,
    BRAND_ACCENT_STRONG,
    BRAND_LIGHT,
    BRAND_MUTED,
    Console,
    Group,
    Panel,
    ProductizedShell,
    RICH_AVAILABLE,
    Table,
    Text,
    _resolve_aegis_version,
    render_guardian_mark,
)

try:
    from prompt_toolkit.application.current import get_app
    from prompt_toolkit.filters import has_focus
    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings as PromptKeyBindings
    from prompt_toolkit.key_binding.bindings.focus import focus_next, focus_previous
    from prompt_toolkit.layout.containers import HSplit
    from prompt_toolkit.layout.layout import Layout
    from prompt_toolkit.shortcuts import input_dialog
    from prompt_toolkit.styles import Style as PromptStyle
    from prompt_toolkit.widgets import Button, Dialog, Label, RadioList

    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = True
except ModuleNotFoundError:  # pragma: no cover - optional wizard polish
    get_app = None
    has_focus = None
    Application = None
    PromptKeyBindings = None
    focus_next = None
    focus_previous = None
    HSplit = None
    Layout = None
    input_dialog = None
    PromptStyle = None
    Button = None
    Dialog = None
    Label = None
    RadioList = None
    PROMPT_TOOLKIT_DIALOGS_AVAILABLE = False

DEFAULT_PROVIDER_ID = "openai-compatible"
DEFAULT_SECRET_ENV_VAR = "AEGIS_OPENROUTER_API_KEY"
DEFAULT_PROVIDER_SECRET_ENV_VARS = {
    "openai": "AEGIS_OPENAI_API_KEY",
    "anthropic": "AEGIS_ANTHROPIC_API_KEY",
    "openrouter": "AEGIS_OPENROUTER_API_KEY",
    "openai-compatible": "AEGIS_LIVE_PROVIDER_API_KEY",
    "google": "AEGIS_GOOGLE_API_KEY",
    "groq": "AEGIS_GROQ_API_KEY",
    "deepseek": "AEGIS_DEEPSEEK_API_KEY",
    "xai": "AEGIS_XAI_API_KEY",
    "mistral": "AEGIS_MISTRAL_API_KEY",
    "together": "AEGIS_TOGETHER_API_KEY",
    "fireworks": "AEGIS_FIREWORKS_API_KEY",
    "moonshot": "AEGIS_MOONSHOT_API_KEY",
    "minimax": "AEGIS_MINIMAX_API_KEY",
}
PERSONALITY_PRESET_EMOJIS = {
    "core": "🪨",
    "companion": "🤝",
    "operator": "🛠️",
}
INITIATIVE_EMOJIS = {
    "gentle": "🌿",
    "proactive": "⚡",
}
PROVIDER_EMOJIS = {
    "openai": "🤖",
    "anthropic": "🧭",
    "openrouter": "🌐",
    "openai-compatible": "🔌",
    "google": "🔎",
    "groq": "⚡",
    "deepseek": "🔍",
    "xai": "🚀",
    "mistral": "🌬️",
    "together": "🤝",
    "fireworks": "🎆",
    "moonshot": "🌙",
    "minimax": "🎭",
    "ollama": "🦙",
    "vllm": "🧠",
}
WIZARD_MAX_VISIBLE_CHOICES = 9
DEFAULT_CLONE_NAME_SUGGESTIONS = (
    "Ada",
    "Asher",
    "Avery",
    "Caleb",
    "Chloe",
    "Eden",
    "Eli",
    "Eliza",
    "Felix",
    "Hazel",
    "Iris",
    "Jasper",
    "Julian",
    "Leah",
    "Lena",
    "Leo",
    "Maya",
    "Miles",
    "Milo",
    "Nina",
    "Nora",
    "Owen",
    "Ruby",
    "Rowan",
    "Simon",
    "Silas",
    "Theo",
    "Vera",
    "Zoe",
)


@dataclass(frozen=True, slots=True)
class WizardChoice:
    value: str
    label: str
    detail: str
    emoji: str = ""


@dataclass(frozen=True, slots=True)
class CliCardSection:
    title: str
    lines: tuple[str, ...] = ()


class _WizardBackSignal:
    __slots__ = ()


WIZARD_BACK = _WizardBackSignal()


class _WizardCancelledError(Exception):
    __slots__ = ("surface",)

    def __init__(self, surface: str) -> None:
        super().__init__(surface)
        self.surface = surface


@dataclass(slots=True)
class BirthWizardState:
    display_name: str
    initial_goal: str
    personality_preset: str
    initiative: str
    provider_id: str
    base_url: str
    default_model: str
    secret_env_var: str | None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aegis",
        description="Aegis CLI with explicit born, clone, clones, health, and grow entrypoints.",
    )
    parser.add_argument("--state-dir", required=True, type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--profile-dir", required=True, type=Path, help=argparse.SUPPRESS)

    subparsers = parser.add_subparsers(dest="command")

    born = subparsers.add_parser(
        "born",
        help="Run the first-time onboard and persist identity, CLONE charter, and provider readiness.",
    )
    born.add_argument("--provider-id", default=DEFAULT_PROVIDER_ID)
    born.add_argument("--display-name", default=None)
    born.add_argument("--personality-preset", default=None)
    born.add_argument("--initiative", default=None)
    born.add_argument("--clone-text", default=None)
    born.add_argument("--soul-text", default=None, help=argparse.SUPPRESS)
    born.add_argument("--clone-name", default=None)
    born.add_argument("--initial-goal", default=None)
    born.add_argument("--base-url", default=None)
    born.add_argument("--default-model", default=None)
    born.add_argument("--secret-env-var", default=None)
    born.add_argument("--non-interactive", action="store_true")

    subparsers.add_parser(
        "health",
        help="Review provider, voice, and security readiness before opening the grow surface.",
    )

    clone = subparsers.add_parser(
        "clone",
        help="Clone a fresh Aegis individual and optionally enter it immediately.",
    )
    clone.add_argument("clone_name", nargs="?", help="Name the new Aegis clone.")
    clone.add_argument("--profile-id", default=None)
    clone.add_argument("--display-name", default=None)
    clone.add_argument("--initial-goal", default=None, help="Seed the clone with its first durable goal.")
    clone.add_argument("--debug", action="store_true", help="Show runtime diagnostics inside the grow surface.")
    clone.add_argument("--message", default=None, help="Create the clone, run one turn, and exit.")

    clones = subparsers.add_parser(
        "clones",
        help="Inspect or retire existing Aegis clones.",
    )
    clones_subparsers = clones.add_subparsers(dest="clones_command")
    bye = clones_subparsers.add_parser(
        "bye",
        help="Retire one named clone or clear every clone.",
    )
    bye.add_argument("clone_id", nargs="?", help="Name the Aegis clone to retire.")
    bye.add_argument("--all", action="store_true", dest="delete_all", help="Retire every clone.")

    grow = subparsers.add_parser(
        "grow",
        help="Enter an existing Aegis clone through the branded TUI or run one provider-backed turn.",
    )
    grow.add_argument("--session-id", default=None, help="Open a known session directly.")
    grow.add_argument("--clone-id", default=None, help="Open the latest session for a known clone.")
    grow.add_argument("--debug", action="store_true", help="Show runtime diagnostics inside the grow surface.")
    grow.add_argument("--message", default=None, help="Run one grow turn and exit.")
    grow.add_argument(
        "--voice-input-file",
        default=None,
        type=Path,
        help="Run one provider-backed voice turn from an audio file and exit.",
    )
    grow.add_argument(
        "--voice-output-file",
        default=None,
        type=Path,
        help="Write one synthesized voice reply when voice output is enabled.",
    )
    grow.add_argument("--voice-input-model", default="gpt-4o-mini-transcribe")
    grow.add_argument("--voice-output-model", default="gpt-4o-mini-tts")
    grow.add_argument("--voice-name", default="alloy")

    return parser


def _print_heading(title: str, detail: str | None = None) -> None:
    print(title)
    if detail:
        print(f"  {detail}")


def _print_field(label: str, value: object) -> None:
    rendered = ""
    if value is not None:
        rendered = str(value)
    print(f"  {label}: {rendered}")


def _print_bullet(text: str) -> None:
    print(f"  - {text}")


def _print_command_hints(*commands: str) -> None:
    if not commands:
        return
    print("  next_commands:")
    for command in commands:
        _print_bullet(command)


def _print_cli_card(
    title: str,
    detail: str | None = None,
    *,
    sections: tuple[CliCardSection, ...] = (),
    next_commands: tuple[str, ...] = (),
) -> None:
    if RICH_AVAILABLE and Panel is not None and Group is not None:
        console = Console(highlight=False, soft_wrap=True)
        blocks: list[Text] = []
        header = Text()
        if detail:
            header.append(f"{detail}", style=BRAND_MUTED)
            blocks.append(header)
        for section in sections:
            if blocks:
                blocks.append(Text(" "))
            section_text = Text()
            section_text.append(f"{section.title}\n", style=f"bold {BRAND_ACCENT}")
            for line in section.lines:
                section_text.append(f"• {line}\n", style=BRAND_LIGHT)
            blocks.append(section_text)
        if next_commands:
            if blocks:
                blocks.append(Text(" "))
            command_text = Text()
            command_text.append("Next\n", style=f"bold {BRAND_ACCENT}")
            for command in next_commands:
                command_text.append(f"• {command}\n", style=BRAND_LIGHT)
            blocks.append(command_text)
        console.print(
            Panel(
                Group(*blocks) if blocks else Text(""),
                title=f"[bold {BRAND_ACCENT}] {title} [/bold {BRAND_ACCENT}]",
                subtitle=f"[bold {BRAND_LIGHT}]Your own persistent AI agent, growing with you.[/bold {BRAND_LIGHT}]",
                border_style=BRAND_ACCENT,
                padding=(1, 2),
            )
        )
        return

    _print_heading(title, detail)
    for section in sections:
        if section.title:
            print(f"  {section.title}:")
        for line in section.lines:
            _print_bullet(line)
    _print_command_hints(*next_commands)


def _interactive_shell_supported() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _wizard_dialogs_supported() -> bool:
    return (
        _interactive_shell_supported()
        and PROMPT_TOOLKIT_DIALOGS_AVAILABLE
        and os.environ.get("AEGIS_NO_WIZARD_DIALOGS") != "1"
    )


def _wizard_style():
    if PromptStyle is None:
        return None
    return PromptStyle.from_dict(
        {
            "dialog": f"bg:#141922 {BRAND_LIGHT}",
            "dialog frame.label": f"bg:#141922 {BRAND_ACCENT} bold",
            "dialog.body": f"bg:#141922 {BRAND_LIGHT}",
            "dialog.body text-area": f"bg:#1a202b {BRAND_LIGHT}",
            "dialog.body radio": f"{BRAND_LIGHT}",
            "dialog.body radio-selected": f"{BRAND_ACCENT_STRONG} bold",
            "dialog.body button": f"bg:#1a202b {BRAND_LIGHT}",
            "dialog.body button.focused": f"bg:{BRAND_ACCENT_STRONG} #141922 bold",
            "dialog shadow": "bg:#0f1218",
            "title": f"{BRAND_ACCENT} bold",
            "prompt": f"{BRAND_LIGHT}",
            "item": f"{BRAND_LIGHT}",
            "selected": f"{BRAND_ACCENT_STRONG} bold",
            "detail": f"{BRAND_MUTED}",
            "selected-detail": f"{BRAND_LIGHT}",
            "hint": f"{BRAND_MUTED}",
        }
    )


def _wizard_choice_menu(
    title: str,
    prompt: str,
    choices: tuple[WizardChoice, ...],
    *,
    default: str,
    allow_back: bool = False,
) -> str | _WizardBackSignal:
    if not (
        PROMPT_TOOLKIT_DIALOGS_AVAILABLE
        and Application is not None
        and PromptKeyBindings is not None
        and get_app is not None
        and has_focus is not None
        and focus_next is not None
        and focus_previous is not None
        and HSplit is not None
        and Layout is not None
        and Button is not None
        and Dialog is not None
        and Label is not None
        and RadioList is not None
    ):
        return default
    default_value = next((choice.value for choice in choices if choice.value == default), choices[0].value)
    values = tuple(
        (
            choice.value,
            [
                ("class:item", f"{_wizard_choice_label(choice)}\n"),
                ("class:detail", f"  {choice.detail}"),
            ],
        )
        for choice in choices
    )
    radio_list = RadioList(
        values=values,
        default=default_value,
        select_on_focus=True,
        show_scrollbar=len(choices) > WIZARD_MAX_VISIBLE_CHOICES,
    )
    hint = "Enter continues · Esc goes back · ↑/↓ or j/k moves" if allow_back else "Enter continues · ↑/↓ or j/k moves"

    def _accept() -> None:
        get_app().exit(result=radio_list.current_value)

    def _cancel() -> None:
        get_app().exit(result=WIZARD_BACK)

    continue_button = Button(text="Continue", handler=_accept)
    cancel_button = Button(text="Back", handler=_cancel)
    dialog = Dialog(
        title=title,
        body=HSplit(
            [
                Label(text=prompt, dont_extend_height=True),
                radio_list,
                Label(text=hint, dont_extend_height=True),
            ],
            padding=1,
        ),
        buttons=[continue_button, cancel_button],
        with_background=True,
    )
    bindings = PromptKeyBindings()
    @bindings.add("tab")
    def _focus_next_binding(event) -> None:
        focus_next(event)

    @bindings.add("s-tab")
    def _focus_previous_binding(event) -> None:
        focus_previous(event)

    @bindings.add("enter", filter=has_focus(radio_list), eager=True)
    def _accept_binding(_event) -> None:
        _accept()

    @bindings.add("escape")
    def _cancel_binding(_event) -> None:
        _cancel()

    application = Application(
        layout=Layout(dialog, focused_element=radio_list),
        key_bindings=bindings,
        style=_wizard_style(),
        full_screen=True,
        mouse_support=True,
    )
    answer = application.run()
    if answer is WIZARD_BACK:
        return WIZARD_BACK
    return str(answer or radio_list.current_value or default_value)


def _wizard_choice_window(total: int, selected: int, *, max_visible: int = WIZARD_MAX_VISIBLE_CHOICES) -> tuple[int, int]:
    if total <= max_visible:
        return 0, total
    if selected < 0:
        selected = 0
    if selected >= total:
        selected = total - 1
    half = max_visible // 2
    start = max(0, selected - half)
    end = start + max_visible
    if end > total:
        end = total
        start = end - max_visible
    return start, end


def _wizard_choice_fragments(
    title: str,
    prompt: str,
    choices: tuple[WizardChoice, ...],
    *,
    selected: int,
    max_visible: int = WIZARD_MAX_VISIBLE_CHOICES,
    allow_back: bool = False,
) -> list[tuple[str, str]]:
    fragments: list[tuple[str, str]] = [
        ("class:title", f"{title}\n"),
        ("class:prompt", f"{prompt}\n\n"),
    ]
    start, end = _wizard_choice_window(len(choices), selected, max_visible=max_visible)
    if start > 0:
        fragments.append(("class:hint", f"↑ {start} more above\n"))
    for index in range(start, end):
        choice = choices[index]
        active = index == selected
        marker = "›" if active else " "
        label_style = "class:selected" if active else "class:item"
        detail_style = "class:selected-detail" if active else "class:detail"
        fragments.append((label_style, f"{marker} {_wizard_choice_label(choice)}\n"))
        fragments.append((detail_style, f"  {choice.detail}\n"))
    if end < len(choices):
        fragments.append(("class:hint", f"↓ {len(choices) - end} more below\n"))
    if allow_back:
        fragments.append(("class:hint", "\nEnter confirms · Esc goes back · ↑/↓ or j/k moves"))
    else:
        fragments.append(("class:hint", "\nEnter confirms · ↑/↓ or j/k moves"))
    return fragments


def _wizard_choice_label(choice: WizardChoice) -> str:
    if not choice.emoji:
        return choice.label
    return f"{choice.emoji} {choice.label}"


def _slugify_clone_name(value: str) -> str:
    collapsed = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return collapsed or "aegis"


def _display_name_from_clone_name(value: str) -> str:
    collapsed = re.sub(r"[^a-zA-Z0-9]+", " ", value.strip()).strip()
    return collapsed.title() or "Aegis"


def _suggest_clone_name(runtime: CliRuntime | None = None) -> str:
    candidates = DEFAULT_CLONE_NAME_SUGGESTIONS
    if runtime is None:
        return random.choice(candidates)
    available = tuple(
        name
        for name in candidates
        if runtime.latest_session_for_clone(_slugify_clone_name(name)) is None
    )
    return random.choice(available or candidates)


def _unique_clone_name(runtime: CliRuntime, desired_name: str) -> str:
    base = _slugify_clone_name(desired_name)
    candidate = base
    index = 2
    while runtime.latest_session_for_clone(candidate) is not None:
        candidate = f"{base}-{index}"
        index += 1
    return candidate


def _provider_choices(runtime: CliRuntime) -> tuple[WizardChoice, ...]:
    choices: list[WizardChoice] = []
    for record in runtime.provider_catalog():
        choices.append(
            WizardChoice(
                value=record.provider_id,
                label=record.display_name,
                detail=record.catalog_summary,
                emoji=PROVIDER_EMOJIS.get(record.provider_id, "🧠"),
            )
        )
    return tuple(choices)


def _personality_choices(runtime: CliRuntime) -> tuple[WizardChoice, ...]:
    return tuple(
        WizardChoice(
            value=preset.preset_id,
            label=preset.label,
            detail=preset.summary,
            emoji=PERSONALITY_PRESET_EMOJIS.get(preset.preset_id, "✨"),
        )
        for preset in runtime.personality_presets()
        if preset.preset_id != "custom"
    )


def _initiative_choices() -> tuple[WizardChoice, ...]:
    return (
        WizardChoice(
            value="gentle",
            label="Gentle Presence",
            detail="Waits for you first and keeps the thread calm, warm, and steady.",
            emoji=INITIATIVE_EMOJIS["gentle"],
        ),
        WizardChoice(
            value="proactive",
            label="Proactive Presence",
            detail="Surfaces the next durable step before the thread drifts too far.",
            emoji=INITIATIVE_EMOJIS["proactive"],
        ),
    )


def _prompt_value(label: str, *, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    answer = input(f"{label}{suffix}: ").strip()
    return answer or (default or "")


def _wizard_text_prompt(
    title: str,
    prompt: str,
    *,
    default: str | None = None,
    allow_back: bool = False,
) -> str | _WizardBackSignal:
    if _wizard_dialogs_supported() and input_dialog is not None:
        answer = input_dialog(
            title=title,
            text=prompt,
            default=default or "",
            style=_wizard_style(),
            ok_text="Continue",
            cancel_text="Back",
        ).run()
        if answer is None:
            return WIZARD_BACK
        resolved = str(answer or "").strip()
        return resolved or (default or "")
    return _prompt_value(prompt, default=default)


def _wizard_choice_prompt(
    title: str,
    prompt: str,
    choices: tuple[WizardChoice, ...],
    *,
    default: str | None = None,
    allow_back: bool = False,
) -> str | _WizardBackSignal:
    if not choices:
        return default or ""
    default_value = default or choices[0].value
    if _wizard_dialogs_supported():
        return _wizard_choice_menu(title, prompt, choices, default=default_value, allow_back=allow_back)
    print(prompt)
    for index, choice in enumerate(choices, start=1):
        marker = "*" if choice.value == default_value else " "
        print(f"  {marker} {index}. {_wizard_choice_label(choice)} :: {choice.detail}")
    while True:
        answer = input(f"choice [{default_value}]: ").strip()
        if not answer:
            return default_value
        if answer.isdigit():
            index = int(answer)
            if 1 <= index <= len(choices):
                return choices[index - 1].value
        normalized = answer.casefold()
        for choice in choices:
            if normalized in {choice.value.casefold(), choice.label.casefold()}:
                return choice.value
        print("  choose a listed number, provider id, or label.")


def _prompt_initial_goal(
    display_name: str,
    *,
    existing: str | None = None,
    allow_back: bool = False,
) -> str | _WizardBackSignal:
    return _wizard_text_prompt(
        "Seed Its First Goal",
        f"What first goal should {display_name} carry when grow opens? Leave it blank to decide inside the conversation.",
        default=existing,
        allow_back=allow_back,
    )


def _default_secret_env_var(provider_id: str) -> str:
    explicit = DEFAULT_PROVIDER_SECRET_ENV_VARS.get(provider_id)
    if explicit is not None:
        return explicit
    normalized = re.sub(r"[^A-Za-z0-9]+", "_", provider_id).strip("_").upper() or "LIVE_PROVIDER"
    return f"AEGIS_{normalized}_API_KEY"


def _provider_setup_defaults(runtime: CliRuntime, provider_id: str) -> tuple[str, str, str | None]:
    guide = runtime.provider_setup_guide(provider_id)
    summary = dict(runtime.provider_summary())
    support_bundle = runtime.security_support_bundle()
    secret_env_vars = tuple(support_bundle["provider"]["secret_env_vars"])
    base_url = str(summary["base_url"] or guide.suggested_base_url or "").strip()
    model_id = str(summary["default_model"] or guide.suggested_model_id or "").strip()
    if guide.required_secret_keys:
        default_secret_env_var = _default_secret_env_var(provider_id)
        secret_env_var = (secret_env_vars[0] if secret_env_vars else default_secret_env_var).strip()
    else:
        secret_env_var = None
    return base_url, model_id, secret_env_var


def _default_personality_preset(runtime: CliRuntime, *, mode: str, current: str | None = None) -> str | None:
    if mode != "her":
        return None
    if current:
        return current
    for preset in runtime.personality_presets():
        if preset.preset_id == "companion":
            return preset.preset_id
    return runtime.personality_presets()[0].preset_id


def _print_birth_wizard_intro() -> None:
    if not RICH_AVAILABLE or Table is None or Panel is None or Group is None:
        _print_heading("Aegis born", "Let's bring your first Aegis to life.")
        _print_bullet("name the Aegis that will stay with your thread")
        _print_bullet("choose how it should naturally show up for you")
        _print_bullet("bind the first model path it will think through")
        _print_bullet("step straight into aegis grow")
        return
    console = Console(highlight=False, soft_wrap=True)
    brand = Table.grid(expand=True)
    brand.add_column(no_wrap=True)
    hero = Text(justify="center")
    hero.append("Let's bring your first Aegis to life.\n", style=f"bold {BRAND_LIGHT}")
    hero.append("Name it, shape its vibe, bind its first mind, then step into grow.", style=BRAND_MUTED)
    flow = Text()
    flow.append("Birth flow\n", style=f"bold {BRAND_ACCENT}")
    flow.append("1 · Name your first Aegis\n", style=BRAND_LIGHT)
    flow.append("2 · Choose its presence\n", style=BRAND_LIGHT)
    flow.append("3 · Bind its first model path\n", style=BRAND_LIGHT)
    flow.append("4 · Hand off to aegis grow", style=BRAND_LIGHT)
    brand.add_row(_center_brand_block(hero))
    brand.add_row(Text(" "))
    brand.add_row(_center_brand_block(render_guardian_mark()))
    brand.add_row(Text(" "))
    layout = Table.grid(expand=True)
    console_width = getattr(console.size, "width", 0)
    if console_width and console_width < 132:
        layout.add_column(ratio=1, min_width=48)
        layout.add_row(brand)
        layout.add_row(Text(" "))
        layout.add_row(flow)
    else:
        layout.add_column(ratio=11, min_width=44)
        layout.add_column(ratio=13, min_width=48)
        layout.add_row(brand, flow)
    console.print(
        Panel(
            layout,
            title=f"[bold {BRAND_ACCENT}] Aegis Born v{_resolve_aegis_version()} [/bold {BRAND_ACCENT}]",
            subtitle=f"[bold {BRAND_LIGHT}]Your own persistent AI agent, growing with you.[/bold {BRAND_LIGHT}]",
            border_style=BRAND_ACCENT,
            padding=(1, 2),
        )
    )


def _prompt_first_clone_name(default_name: str, *, allow_back: bool = False) -> str | _WizardBackSignal:
    return _wizard_text_prompt(
        "Name Your First Aegis",
        "This first Aegis is yours. What name feels right?",
        default=default_name,
        allow_back=allow_back,
    )


def _run_interactive_clone_wizard(
    runtime: CliRuntime,
    *,
    initial_goal: str,
    prompt_goal: bool,
) -> tuple[str, str] | None:
    clone_name = _suggest_clone_name(runtime)
    while True:
        answer = _wizard_text_prompt(
            "Name Another Aegis",
            "What should this new Aegis be called?",
            default=clone_name,
            allow_back=True,
        )
        if answer is WIZARD_BACK:
            return None
        clone_name = str(answer).strip()
        if not prompt_goal:
            return clone_name, initial_goal
        answered_goal = _prompt_initial_goal(
            _display_name_from_clone_name(clone_name),
            existing=initial_goal,
            allow_back=True,
        )
        if answered_goal is WIZARD_BACK:
            continue
        return clone_name, str(answered_goal).strip()


def _run_interactive_birth_wizard(
    runtime: CliRuntime,
    *,
    display_name: str,
    initial_goal: str,
    personality_preset: str,
    initiative: str,
    provider_id: str,
    base_url: str,
    default_model: str,
    secret_env_var: str | None,
) -> BirthWizardState | None:
    state = BirthWizardState(
        display_name=display_name,
        initial_goal=initial_goal,
        personality_preset=personality_preset,
        initiative=initiative,
        provider_id=provider_id,
        base_url=base_url,
        default_model=default_model,
        secret_env_var=secret_env_var,
    )
    steps = (
        "display_name",
        "initial_goal",
        "personality_preset",
        "initiative",
        "provider_id",
        "base_url",
        "default_model",
        "secret_env_var",
    )
    step_index = 0
    while step_index < len(steps):
        step = steps[step_index]
        if step == "display_name":
            answer = _prompt_first_clone_name(state.display_name, allow_back=True)
            if answer is WIZARD_BACK:
                return None
            state.display_name = str(answer).strip() or state.display_name
            step_index += 1
            continue
        if step == "initial_goal":
            answer = _prompt_initial_goal(state.display_name, existing=state.initial_goal, allow_back=True)
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.initial_goal = str(answer).strip()
            step_index += 1
            continue
        if step == "personality_preset":
            answer = _wizard_choice_prompt(
                "Choose Its Presence",
                f"When {state.display_name} first speaks, how should it naturally feel?",
                _personality_choices(runtime),
                default=state.personality_preset,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.personality_preset = str(answer)
            step_index += 1
            continue
        if step == "initiative":
            answer = _wizard_choice_prompt(
                "Choose Its Initiative",
                f"When the thread goes quiet, how should {state.display_name} stay with you?",
                _initiative_choices(),
                default=state.initiative,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.initiative = str(answer)
            step_index += 1
            continue
        if step == "provider_id":
            answer = _wizard_choice_prompt(
                "Choose Its First Mind",
                f"Where should {state.display_name} think from first?",
                _provider_choices(runtime),
                default=state.provider_id,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            selected_provider_id = str(answer)
            if selected_provider_id != state.provider_id:
                base_url_default, model_default, secret_env_var_default = _provider_setup_defaults(runtime, selected_provider_id)
                state.base_url = base_url_default
                state.default_model = model_default
                state.secret_env_var = secret_env_var_default
            state.provider_id = selected_provider_id
            step_index += 1
            continue
        guide = runtime.provider_setup_guide(state.provider_id)
        if step == "base_url":
            if "base_url" not in guide.required_config_keys:
                step_index += 1
                continue
            answer = _wizard_text_prompt(
                "Set Its Endpoint",
                f"What endpoint should {state.display_name} call first?",
                default=state.base_url,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.base_url = str(answer).strip()
            step_index += 1
            continue
        if step == "default_model":
            answer = _wizard_text_prompt(
                "Choose Its First Model",
                f"What model should {state.display_name} speak through first?",
                default=state.default_model,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.default_model = str(answer).strip()
            step_index += 1
            continue
        if step == "secret_env_var":
            if not guide.required_secret_keys:
                step_index += 1
                continue
            answer = _wizard_text_prompt(
                "Bind Its Secret",
                f"Which environment variable should carry {state.display_name}'s provider key?",
                default=state.secret_env_var or DEFAULT_SECRET_ENV_VAR,
                allow_back=True,
            )
            if answer is WIZARD_BACK:
                step_index -= 1
                continue
            state.secret_env_var = str(answer).strip() or None
            step_index += 1
            continue
    return state


def _print_birth_paused() -> None:
    _print_cli_card(
        "Aegis birth paused",
        "No new identity or provider changes were written.",
        next_commands=("aegis born", "aegis health"),
    )


def _print_overview(runtime: CliRuntime) -> None:
    provider = dict(runtime.provider_summary())
    doctor = runtime.provider_doctor()
    clones = runtime.list_clones(limit=5)
    if RICH_AVAILABLE and Table is not None and Panel is not None and Group is not None:
        console = Console(highlight=False, soft_wrap=True)
        brand = Table.grid(expand=True)
        brand.add_column(no_wrap=True)
        headline = Text(no_wrap=True)
        headline.append("Welcome back !\n", style=f"bold {BRAND_LIGHT}")
        headline.append("Your own persistent AI agent, growing with you.", style=BRAND_MUTED)
        capability = Text("persistent memory · long-horizon decisions · long context", style=BRAND_MUTED)
        action_lines = Text()
        action_lines.append("Start here\n", style=f"bold {BRAND_ACCENT}")
        action_lines.append("aegis born  · name your first Aegis, shape its clone charter, and hatch it\n", style=BRAND_LIGHT)
        action_lines.append("aegis grow · re-enter the live Aegis clone that already knows the thread\n", style=BRAND_LIGHT)
        action_lines.append("aegis clone <name> · create another Aegis individual when you need one\n", style=BRAND_LIGHT)
        action_lines.append("aegis clones · inspect or retire named clones\n", style=BRAND_LIGHT)
        action_lines.append("aegis health · inspect provider, voice, and security readiness\n", style=BRAND_LIGHT)
        action_lines.append("\nCurrent posture\n", style=f"bold {BRAND_ACCENT}")
        action_lines.append(f"health · {doctor['status']}\n", style=BRAND_MUTED if doctor["status"] != "ready" else BRAND_LIGHT)
        action_lines.append(f"provider · {provider['provider_id']}\n", style=BRAND_MUTED)
        if clones:
            action_lines.append("clones · " + ", ".join(clone.clone_id for clone in clones), style=BRAND_MUTED)
        else:
            action_lines.append("clones · none yet", style=BRAND_MUTED)
        brand.add_row(_center_brand_block(headline))
        brand.add_row(Text(" "))
        brand.add_row(_center_brand_block(render_guardian_mark()))
        brand.add_row(Text(" "))
        brand.add_row(_center_brand_block(capability))
        layout = Table.grid(expand=True)
        layout.add_column(ratio=11, min_width=46)
        layout.add_column(ratio=11, min_width=44)
        layout.add_row(brand, action_lines)
        console.print(
            Panel(
                layout,
                title=f"[bold {BRAND_ACCENT}] Aegis v{_resolve_aegis_version()} [/bold {BRAND_ACCENT}]",
                subtitle=f"[bold {BRAND_LIGHT}]Your own persistent AI agent, growing with you.[/bold {BRAND_LIGHT}]",
                border_style=BRAND_ACCENT,
                padding=(1, 2),
            )
        )
        return

    _print_heading("Welcome back !", "Your own persistent AI agent, growing with you.")
    _print_bullet("persistent memory · long-horizon decisions · long context")
    _print_bullet("aegis born  - name your first Aegis, shape its clone charter, and hatch it")
    _print_bullet("aegis grow - enter the live Aegis clone that already holds the thread")
    _print_bullet("aegis clone <name> - create another Aegis individual when you need one")
    _print_bullet("aegis clones - inspect or retire clones")
    _print_bullet("aegis health - inspect provider, voice, and security readiness")
    _print_field("health", doctor["status"])
    _print_field("provider", provider["provider_id"])
    _print_field("clones", ", ".join(clone.clone_id for clone in clones) if clones else "none yet")


def _center_brand_block(renderable):
    if Align is None:
        return renderable
    return Align.center(renderable)


def _print_setup_intro(runtime: CliRuntime, *, provider_id: str) -> None:
    guide = runtime.provider_setup_guide(provider_id)
    loaded = runtime.current_profile()
    _print_cli_card(
        "Aegis born",
        "Bring your first Aegis to life and hand it off to grow.",
        sections=(
            CliCardSection(
                "Current shape",
                (
                    f"name · {loaded.state.display_name}",
                    f"provider · {guide.display_name}",
                    f"transport · {guide.transport_display_name}",
                ),
            ),
            CliCardSection(
                "Birth flow",
                (
                    "Give it a name and presence that feel like its own",
                    "Bind its first model path",
                    "Finish in aegis grow",
                ),
            ),
        ),
    )


def _default_born_args() -> argparse.Namespace:
    return argparse.Namespace(
        provider_id=DEFAULT_PROVIDER_ID,
        display_name=None,
        personality_preset=None,
        initiative=None,
        clone_text=None,
        soul_text=None,
        clone_name=None,
        initial_goal=None,
        base_url=None,
        default_model=None,
        secret_env_var=None,
        non_interactive=False,
    )


def _default_grow_args() -> argparse.Namespace:
    return argparse.Namespace(
        session_id=None,
        clone_id=None,
        debug=False,
        message=None,
        voice_input_file=None,
        voice_output_file=None,
        voice_input_model="gpt-4o-mini-transcribe",
        voice_output_model="gpt-4o-mini-tts",
        voice_name="alloy",
    )


def _ensure_clone_ready(
    runtime: CliRuntime,
    *,
    clone_name: str,
    display_name: str,
    profile_id: str,
    initial_goal: str | None = None,
) -> tuple[object, str]:
    existing = runtime.latest_session_for_clone(clone_name)
    if existing is not None:
        runtime.seed_initial_goal(existing.session_id, initial_goal or "")
        return existing, "existing"
    session = runtime.create_clone(
        clone_id=clone_name,
        profile_id=profile_id,
        display_name=display_name,
        mode="her",
        initial_goal=initial_goal,
    )
    return session, "created"


def _run_setup(runtime: CliRuntime, args: argparse.Namespace) -> int:
    provider_id = args.provider_id
    loaded = runtime.current_profile()
    base_url_default, model_default, secret_env_var_default = _provider_setup_defaults(runtime, provider_id)
    initial_clone_name = args.clone_name
    initial_goal = (args.initial_goal or "").strip()
    if args.display_name is not None:
        display_name = args.display_name
    elif initial_clone_name:
        display_name = _display_name_from_clone_name(initial_clone_name)
    else:
        display_name = _suggest_clone_name(runtime)
    mode = "her"
    personality_preset = _default_personality_preset(
        runtime,
        mode=mode,
        current=args.personality_preset or (loaded.her_mode.personality_preset if loaded.her_mode is not None else None),
    )
    initiative = args.initiative or (loaded.her_mode.initiative if loaded.her_mode is not None else "gentle")
    requested_clone_text = args.clone_text if args.clone_text is not None else args.soul_text
    base_url = args.base_url or base_url_default
    default_model = args.default_model or model_default
    secret_env_var = args.secret_env_var or secret_env_var_default

    interactive_birth = _interactive_shell_supported() and not args.non_interactive
    if interactive_birth:
        _print_birth_wizard_intro()
        wizard_state = _run_interactive_birth_wizard(
            runtime,
            display_name=display_name,
            initial_goal=initial_goal,
            personality_preset=_default_personality_preset(runtime, mode=mode, current=personality_preset) or "companion",
            initiative=initiative,
            provider_id=provider_id,
            base_url=base_url,
            default_model=default_model,
            secret_env_var=secret_env_var,
        )
        if wizard_state is None:
            _print_birth_paused()
            return 0
        display_name = wizard_state.display_name
        initial_goal = wizard_state.initial_goal
        personality_preset = wizard_state.personality_preset
        initiative = wizard_state.initiative
        provider_id = wizard_state.provider_id
        base_url = wizard_state.base_url
        default_model = wizard_state.default_model
        secret_env_var = wizard_state.secret_env_var
    else:
        _print_setup_intro(runtime, provider_id=provider_id)

    if not base_url or not default_model:
        raise SystemExit("born requires a provider base URL and default model")

    updated_identity = runtime.update_identity(
        display_name=display_name,
        mode=mode,
    )
    updated_identity = runtime.update_her_mode(
        profile_id=updated_identity.state.profile_id,
        initiative=initiative,
        personality_preset=personality_preset,
    )
    clone_text = (
        requested_clone_text.strip()
        if requested_clone_text is not None and requested_clone_text.strip()
        else render_clone_charter(
            display_name=updated_identity.state.display_name,
            personality_preset=personality_preset,
            initiative=initiative,
            mode=updated_identity.state.mode,
        )
    )
    updated_identity = runtime.update_clone_text(
        profile_id=updated_identity.state.profile_id,
        clone_text=(clone_text or DEFAULT_CLONE_TEXT).strip(),
    )

    configured = runtime.set_default_provider(
        provider_id=provider_id,
        profile_id=updated_identity.state.profile_id,
        display_name=updated_identity.state.display_name,
        mode=updated_identity.state.mode,
        base_url=base_url,
        default_model=default_model,
        secret_env_var=secret_env_var,
    )

    report = runtime.provider_doctor()
    provider = report["provider"]
    clone_name = _unique_clone_name(runtime, initial_clone_name or display_name)
    first_clone, first_clone_status = _ensure_clone_ready(
        runtime,
        clone_name=clone_name,
        display_name=display_name,
        profile_id=configured.state.profile_id,
        initial_goal=initial_goal,
    )
    readiness_lines = [
        f"clone · {runtime.clone_id_for_session(first_clone)}",
        f"status · {first_clone_status}",
        f"provider · {provider['display_name'] if 'display_name' in provider else provider['provider_id']}",
        f"model · {provider['default_model'] or '<unset>'}",
        f"health · {report['status']}",
    ]
    if configured.her_mode is not None:
        readiness_lines.extend(
            [
                f"presence · {configured.her_mode.personality_preset}",
                f"initiative · {configured.her_mode.initiative}",
            ]
        )
    if initial_goal:
        readiness_lines.append(f"initial_goal · {initial_goal}")
    if interactive_birth and report["status"] == "ready":
        runtime.prepare_session_surface(first_clone.session_id)
        return ProductizedShell(runtime, session_id=first_clone.session_id, opened="Born new").run()
    _print_cli_card(
        "Aegis is born",
        f"{display_name} is ready.",
        sections=(
            CliCardSection("Ready now", tuple(readiness_lines)),
        ),
        next_commands=("aegis grow", "aegis clone <name>", "aegis clones")
        if report["status"] == "ready"
        else ("aegis health", "aegis born"),
    )
    return 0


def _print_doctor(runtime: CliRuntime) -> None:
    provider = runtime.provider_doctor()
    voice = runtime.voice_doctor()
    security = runtime.security_doctor()
    clones = runtime.list_clones(limit=5)
    active = provider["provider"]
    status_lines = (
        f"provider_status · {provider['status']}",
        f"voice_status · {voice['status']}",
        f"security_status · {security['status']}",
        f"active_provider_id · {active['provider_id']}",
        f"active_provider_source · {active['source']}",
        f"active_provider_model_id · {active['default_model'] or '<unset>'}",
    )
    provider_checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in provider["checks"]
    )
    voice_checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in voice["checks"]
    )
    security_checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in security["checks"]
    )
    voice_identity_lines = tuple(
        line
        for line in (
            f"voice_supported_path · {voice['supported_path']}" if voice.get("supported_path") else "",
            f"voice_identity_binding · {voice['identity_binding']}" if voice.get("identity_binding") else "",
            f"voice_identity_summary · {voice['voice_identity_summary']}" if voice.get("voice_identity_summary") else "",
        )
        if line
    )
    extra_lines = (
        (f"probe_summary · {provider['probe_summary']}",) if provider["probe_summary"] else ()
    )
    sections = [CliCardSection("Readiness", status_lines)]
    if provider_checks:
        sections.append(CliCardSection("Provider checks", provider_checks))
    if voice_checks:
        sections.append(CliCardSection("Voice checks", voice_checks))
    if voice_identity_lines:
        sections.append(CliCardSection("Voice identity", voice_identity_lines))
    if security_checks:
        sections.append(CliCardSection("Security checks", security_checks))
    if extra_lines:
        sections.append(CliCardSection("Probe", extra_lines))
    _print_cli_card(
        "Aegis health",
        "Readiness before the grow surface opens.",
        sections=tuple(sections),
        next_commands=("aegis grow", "aegis clone <name>", "aegis clones")
        if provider["status"] == "ready" and clones
        else ("aegis clone <name>", "aegis grow", "aegis clones")
        if provider["status"] == "ready"
        else ("aegis born",),
    )


def _print_clone_created(runtime: CliRuntime, session_id: str) -> None:
    session = runtime.inspect_session(session_id)
    clone_id = runtime.clone_id_for_session(session)
    goals = runtime.inspect_goals(session_id)
    ready_lines = [
        f"clone_id · {clone_id}",
        f"session_id · {session.session_id}",
        f"profile_id · {session.profile_id}",
        f"status · {session.status}",
    ]
    if goals:
        ready_lines.append(f"active_goal · {goals[0].title}")
    _print_cli_card(
        "Aegis clone",
        "A new Aegis individual is ready.",
        sections=(
            CliCardSection(
                "Ready now",
                tuple(ready_lines),
            ),
        ),
        next_commands=("aegis grow", f"aegis grow --clone-id {clone_id}", "aegis clones"),
    )


def _print_clone_paused() -> None:
    _print_cli_card(
        "Aegis clone paused",
        "No new clone was created.",
        next_commands=("aegis clone <name>", "aegis grow", "aegis clones"),
    )


def _print_clones(runtime: CliRuntime) -> None:
    clones = runtime.list_clones(limit=24)
    if not clones:
        _print_cli_card(
            "Aegis clones",
            "Named Aegis individuals with their own continuity lines.",
            sections=(CliCardSection("Current state", ("No clones yet.",)),),
            next_commands=("aegis clone <name>",),
        )
        return
    clone_lines = tuple(
        f"{clone.clone_id} · latest {clone.latest_session_id[:8]} · {clone.session_count} session{'s' if clone.session_count != 1 else ''} · {clone.latest_status}"
        for clone in clones
    )
    _print_cli_card(
        "Aegis clones",
        "Named Aegis individuals with their own continuity lines.",
        sections=(CliCardSection("Available clones", clone_lines),),
        next_commands=("aegis grow", "aegis clone <name>", "aegis clones bye <name>", "aegis clones bye --all"),
    )


def _print_clone_retired(clone_id: str, deleted_sessions: int) -> None:
    _print_cli_card(
        "Clone retired",
        "A named Aegis continuity line has been cleared.",
        sections=(
            CliCardSection(
                "Retired now",
                (
                    f"clone_id · {clone_id}",
                    f"deleted_sessions · {deleted_sessions}",
                ),
            ),
        ),
        next_commands=("aegis clones", "aegis clone <name>", "aegis grow"),
    )


def _print_clone_retire_paused() -> None:
    _print_cli_card(
        "Clone retire paused",
        "No clone was cleared.",
        next_commands=("aegis clones", "aegis grow", "aegis clone <name>"),
    )


def _print_all_clones_retired(deleted_clones: int, deleted_sessions: int) -> None:
    _print_cli_card(
        "All clones retired",
        "Every named Aegis clone has been cleared.",
        sections=(
            CliCardSection(
                "Retired now",
                (
                    f"deleted_clones · {deleted_clones}",
                    f"deleted_sessions · {deleted_sessions}",
                ),
            ),
        ),
        next_commands=("aegis clone <name>", "aegis born", "aegis health"),
    )


def _prompt_clone_choice(runtime: CliRuntime, clones, *, intent: str = "enter") -> object:
    prompt = (
        "Multiple Aegis clones are available. Pick one before entering grow."
        if intent == "enter"
        else "Multiple Aegis clones are available. Pick one before clearing it."
    )
    if _wizard_dialogs_supported():
        default_clone = clones[0].clone_id
        choices = tuple(
            WizardChoice(
                value=clone.clone_id,
                label=f"{clone.clone_id} · {clone.session_count} session{'s' if clone.session_count != 1 else ''}",
                detail=f"latest continuity {clone.latest_session_id[:8]} · {clone.latest_status}",
            )
            for clone in clones
        )
        selected_id = _wizard_choice_prompt(
            "Choose clone",
            prompt,
            choices,
            default=default_clone,
            allow_back=True,
        )
        if selected_id is WIZARD_BACK:
            return WIZARD_BACK
        for clone in clones:
            if clone.clone_id == selected_id:
                return clone
    _print_cli_card(
        "Choose clone",
        prompt,
        sections=(
            CliCardSection(
                "Available clones",
                tuple(
                    f"{index}. {clone.clone_id} · latest {clone.latest_session_id[:8]} · {clone.session_count} session{'s' if clone.session_count != 1 else ''} · {clone.latest_status}"
                    for index, clone in enumerate(clones, start=1)
                ),
            ),
        ),
    )
    while True:
        answer = input("clone: ").strip()
        if answer.isdigit():
            index = int(answer)
            if 1 <= index <= len(clones):
                return clones[index - 1]
        for clone in clones:
            if clone.clone_id == answer:
                return clone
        print("  enter a clone number or clone id from the list above")


def _resolve_growth_session(
    runtime: CliRuntime,
    *,
    session_id: str | None = None,
    clone_id: str | None = None,
) -> tuple[str, str]:
    if session_id is not None:
        return runtime.inspect_session(session_id).session_id, "Opened existing"
    if clone_id is not None:
        selected = runtime.latest_session_for_clone(clone_id)
        if selected is None:
            raise ValueError(f"unknown clone: {clone_id}")
        return selected.session_id, f"Opened clone {clone_id}"
    clones = runtime.list_clones(limit=16)
    if not clones:
        raise LookupError("no-clones")
    if len(clones) == 1:
        return clones[0].latest_session_id, f"Opened clone {clones[0].clone_id}"
    if _interactive_shell_supported():
        selected = _prompt_clone_choice(runtime, clones)
        if selected is WIZARD_BACK:
            raise _WizardCancelledError("grow")
        return selected.latest_session_id, f"Opened clone {selected.clone_id}"
    raise ValueError("multiple clones are available; pass --clone-id or enter grow from an interactive TTY")


def _print_clone_blocked(runtime: CliRuntime) -> None:
    report = runtime.provider_doctor()
    provider = report["provider"]
    checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in report["checks"]
    )
    sections = [
        CliCardSection(
            "Current readiness",
            (
                f"provider_status · {report['status']}",
                f"active_provider_id · {provider['provider_id']}",
                f"active_provider_source · {provider['source']}",
            ),
        )
    ]
    if checks:
        sections.append(CliCardSection("Provider checks", checks))
    _print_cli_card(
        "Clone blocked",
        "Finish birth before hatching another Aegis.",
        sections=tuple(sections),
        next_commands=("aegis born", "aegis health"),
    )


def _print_grow_blocked(runtime: CliRuntime) -> None:
    report = runtime.provider_doctor()
    provider = report["provider"]
    checks = tuple(
        f"{check['check']} · {check['status']}{f' · {check['summary']}' if check.get('summary') else ''}"
        for check in report["checks"]
    )
    sections = [
        CliCardSection(
            "Current readiness",
            (
                f"provider_status · {report['status']}",
                f"active_provider_id · {provider['provider_id']}",
                f"active_provider_source · {provider['source']}",
            ),
        )
    ]
    if checks:
        sections.append(CliCardSection("Provider checks", checks))
    _print_cli_card(
        "Grow blocked",
        "Finish birth and health checks before entering the grow surface.",
        sections=tuple(sections),
        next_commands=("aegis born", "aegis health"),
    )


def _print_no_clones() -> None:
    _print_cli_card(
        "No clones yet",
        "Create an Aegis clone before entering the grow surface.",
        next_commands=("aegis clone <name>", "aegis health"),
    )


def _run_clone(runtime: CliRuntime, args: argparse.Namespace) -> int:
    if runtime.provider_doctor()["status"] != "ready":
        _print_clone_blocked(runtime)
        return 1
    raw_clone_name = args.clone_name
    initial_goal = (args.initial_goal or "").strip()
    if raw_clone_name is None:
        if not _interactive_shell_supported():
            _print_heading("Name needed", "Run aegis clone <name>, or rerun in a TTY and Aegis will ask you.")
            _print_command_hints("aegis clone <name>", "aegis grow", "aegis clones")
            return 1
        _print_heading("Aegis clone", "Let's bring another Aegis individual online.")
        wizard_state = _run_interactive_clone_wizard(
            runtime,
            initial_goal=initial_goal,
            prompt_goal=args.message is None,
        )
        if wizard_state is None:
            _print_clone_paused()
            return 0
        raw_clone_name, initial_goal = wizard_state
    clone_id = _unique_clone_name(runtime, raw_clone_name)
    display_name = args.display_name or _display_name_from_clone_name(raw_clone_name)
    session = runtime.create_clone(
        clone_id=clone_id,
        profile_id=args.profile_id,
        display_name=display_name,
        mode="her",
        initial_goal=initial_goal,
    )
    runtime.prepare_session_surface(session.session_id)
    if args.message is not None:
        outcome = runtime.explain_next_step(session_id=session.session_id, prompt=args.message)
        _print_clone_created(runtime, session.session_id)
        _print_assistant_turn(runtime, outcome)
        return 0
    if _interactive_shell_supported():
        return ProductizedShell(runtime, session_id=session.session_id, opened="Cloned new", debug=args.debug).run()
    _print_clone_created(runtime, session.session_id)
    return 0


def _run_clones(runtime: CliRuntime, args: argparse.Namespace) -> int:
    if args.clones_command is None:
        _print_clones(runtime)
        return 0
    if args.clones_command != "bye":
        raise ValueError(f"unknown clones command: {args.clones_command}")
    if args.delete_all:
        if args.clone_id is not None:
            raise ValueError("aegis clones bye accepts either a clone name or --all")
        deleted_clones, deleted_sessions = runtime.delete_all_clones()
        _print_all_clones_retired(deleted_clones, deleted_sessions)
        return 0
    if args.clone_id is None:
        clones = runtime.list_clones(limit=16)
        if not clones:
            _print_no_clones()
            return 1
        if _interactive_shell_supported():
            selected = _prompt_clone_choice(runtime, clones, intent="retire")
            if selected is WIZARD_BACK:
                _print_clone_retire_paused()
                return 0
            clone_id = selected.clone_id
        else:
            raise ValueError("aegis clones bye requires <name> or --all")
    else:
        clone_id = args.clone_id
    deleted_sessions = runtime.delete_clone(clone_id)
    if deleted_sessions == 0:
        raise ValueError(f"unknown clone: {clone_id}")
    _print_clone_retired(clone_id, deleted_sessions)
    return 0


def _print_assistant_turn(runtime: CliRuntime, outcome, *, title: str = "Aegis turn") -> None:
    provider = dict(runtime.provider_summary())
    lines = [
        f"session_id · {outcome.session.session_id}",
        f"profile_id · {outcome.profile.profile_id}",
        f"provider_id · {provider['provider_id']}",
        f"provider_model_id · {provider['default_model'] or '<unset>'}",
        f"execution · {outcome.execution.summary}",
        f"goals_in_play · {len(outcome.goals)}",
        f"memory_hits · {len(outcome.memories)}",
    ]
    if outcome.plan is not None:
        lines.append(f"plan_rationale · {outcome.plan.rationale}")
    _print_cli_card(
        title,
        "One grow turn completed.",
        sections=(CliCardSection("Turn summary", tuple(lines)),),
    )


def _print_voice_turn(result, *, output_path: Path | None = None) -> None:
    lines = [
        f"voice_input_outcome · {result.input_resolution.outcome}",
        f"voice_input_summary · {result.input_resolution.summary}",
        f"voice_policy_decision · {result.voice_turn.policy_result.decision.value}",
    ]
    if result.voice_turn.output is not None:
        lines.append(f"voice_output_mode · {result.voice_turn.output.delivery_mode}")
        lines.append(f"voice_output_enabled · {result.voice_turn.output.voice_enabled}")
        if result.voice_turn.output.metadata.get("voice_identity_summary"):
            lines.append(
                f"voice_identity_summary · {result.voice_turn.output.metadata['voice_identity_summary']}"
            )
    if output_path is not None:
        lines.append(f"voice_output_file · {output_path}")
    _print_cli_card(
        "Voice turn",
        "Aegis completed one voice-first turn.",
        sections=(CliCardSection("Voice summary", tuple(lines)),),
    )


def _run_grow(runtime: CliRuntime, args: argparse.Namespace) -> int:
    if args.message is not None and args.voice_input_file is not None:
        raise ValueError("--message and --voice-input-file cannot be used together")
    if args.voice_output_file is not None and args.voice_input_file is None:
        raise ValueError("--voice-output-file requires --voice-input-file")
    if runtime.provider_doctor()["status"] != "ready":
        _print_grow_blocked(runtime)
        return 1

    try:
        session_id, opened = _resolve_growth_session(
            runtime,
            session_id=args.session_id,
            clone_id=args.clone_id,
        )
    except _WizardCancelledError:
        _print_cli_card(
            "Grow paused",
            "No clone was selected.",
            next_commands=("aegis grow", "aegis clones", "aegis clone <name>"),
        )
        return 0
    except LookupError:
        _print_no_clones()
        return 1
    runtime.prepare_session_surface(session_id)

    if args.voice_input_file is not None:
        audio_bytes = args.voice_input_file.read_bytes()
        result = runtime.run_voice_turn(
            session_id=session_id,
            audio_bytes=audio_bytes,
            audio_name=args.voice_input_file.name,
            audio_format=args.voice_input_file.suffix.lstrip(".") or None,
            voice_output_enabled=args.voice_output_file is not None,
            input_model_id=args.voice_input_model,
            output_model_id=args.voice_output_model,
            voice_name=args.voice_name,
            output_audio_format=(args.voice_output_file.suffix.lstrip(".") or "mp3")
            if args.voice_output_file is not None
            else "mp3",
        )
        if args.voice_output_file is not None and result.voice_turn.output is not None and result.voice_turn.output.audio_bytes is not None:
            args.voice_output_file.parent.mkdir(parents=True, exist_ok=True)
            args.voice_output_file.write_bytes(result.voice_turn.output.audio_bytes)
        _print_voice_turn(result, output_path=args.voice_output_file)
        if result.kernel_outcome is not None:
            _print_assistant_turn(runtime, result.kernel_outcome)
            return 0
        return 1

    if args.message is not None:
        outcome = runtime.explain_next_step(session_id=session_id, prompt=args.message)
        _print_assistant_turn(runtime, outcome)
        return 0

    if _interactive_shell_supported():
        return ProductizedShell(runtime, session_id=session_id, opened=opened, debug=args.debug).run()
    return _run_stream_grow_loop(runtime, session_id, sys.stdin)


def _run_stream_grow_loop(runtime: CliRuntime, session_id: str, stream: Iterable[str]) -> int:
    for line in stream:
        prompt = line.rstrip("\n").strip()
        if not prompt:
            continue
        outcome = runtime.explain_next_step(session_id=session_id, prompt=prompt)
        _print_assistant_turn(runtime, outcome)
    return 0


def _run_default_entry(runtime: CliRuntime) -> int:
    if not _interactive_shell_supported():
        _print_overview(runtime)
        return 0
    if runtime.list_clones(limit=16):
        return _run_grow(runtime, _default_grow_args())
    return _run_setup(runtime, _default_born_args())


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    runtime = CliRuntime.create(state_dir=args.state_dir, profile_dir=args.profile_dir)

    if args.command is None:
        return _run_default_entry(runtime)
    if args.command == "born":
        return _run_setup(runtime, args)
    if args.command == "health":
        _print_doctor(runtime)
        return 0
    if args.command == "clone":
        try:
            return _run_clone(runtime, args)
        except ValueError as error:
            parser.error(str(error))
    if args.command == "clones":
        try:
            return _run_clones(runtime, args)
        except ValueError as error:
            parser.error(str(error))
    if args.command == "grow":
        try:
            return _run_grow(runtime, args)
        except ValueError as error:
            parser.error(str(error))
    parser.error(f"unknown command: {args.command}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
