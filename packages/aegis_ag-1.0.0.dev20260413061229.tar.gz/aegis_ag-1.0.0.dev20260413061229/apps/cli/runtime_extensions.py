"""Extension bootstrap helpers for the CLI runtime."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
import json
from pathlib import Path
from typing import Any

from packages.mcp import McpRuntime, McpServerDefinition, mcp_server_from_payload
from packages.profile import ProfileLoader
from packages.security import SecurityPolicy
from packages.skills import SkillActivationContext, SkillRuntime, builtin_skill_definitions
from packages.storage import RuntimeStorageRepository
from packages.tools import (
    BuiltinToolDependencies,
    SecurityApprovalGateway,
    ToolRuntime,
    register_builtin_tools,
)


@dataclass(frozen=True, slots=True)
class CliExtensionManifest:
    tool_overrides: Mapping[str, bool]
    tool_manifest_paths: tuple[Path, ...]
    skill_overrides: Mapping[str, bool]
    skill_manifest_paths: tuple[Path, ...]
    skill_package_paths: tuple[Path, ...]
    mcp_definitions: tuple[McpServerDefinition, ...]
    mcp_overrides: Mapping[str, bool]


@dataclass(frozen=True, slots=True)
class _PreviewTelemetrySink:
    snapshot_path: Path
    descriptor: Any = None

    def emit(self, event: Mapping[str, Any]) -> None:
        existing = {}
        if self.snapshot_path.exists():
            existing = json.loads(self.snapshot_path.read_text(encoding="utf-8"))
        telemetry = list(existing.get("telemetry", ()))
        telemetry.append(dict(event))
        existing["telemetry"] = telemetry
        self.snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        self.snapshot_path.write_text(json.dumps(existing, indent=2, sort_keys=True), encoding="utf-8")


def load_json_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_extension_manifest(manifest: Mapping[str, Any], *, profile_dir: Path) -> CliExtensionManifest:
    return CliExtensionManifest(
        tool_overrides=_load_enabled_overrides(manifest, "tool_overrides"),
        tool_manifest_paths=_load_manifest_paths(manifest, "tool_manifests", profile_dir=profile_dir),
        skill_overrides=_load_enabled_overrides(manifest, "skill_overrides"),
        skill_manifest_paths=_load_manifest_paths(manifest, "skill_manifests", profile_dir=profile_dir),
        skill_package_paths=_load_manifest_paths(manifest, "skill_packages", profile_dir=profile_dir),
        mcp_definitions=_load_mcp_servers(manifest),
        mcp_overrides=_load_enabled_overrides(manifest, "mcp_overrides"),
    )


def serialize_manifest_path(path: Path, *, profile_dir: Path) -> str:
    try:
        return str(path.relative_to(profile_dir))
    except ValueError:
        return str(path)


def build_tool_runtime(
    manifest: CliExtensionManifest,
    *,
    dependencies: BuiltinToolDependencies,
    snapshot_path: Path,
    security_policy: SecurityPolicy,
) -> ToolRuntime:
    runtime = ToolRuntime(
        approval_gateway=SecurityApprovalGateway(
            policy=security_policy,
            telemetry=_PreviewTelemetrySink(snapshot_path),
            source="cli.tool.runtime",
            auto_approve_deferred=True,
        )
    )
    register_builtin_tools(
        runtime,
        enabled_overrides=manifest.tool_overrides,
        dependencies=dependencies,
    )
    for path in manifest.tool_manifest_paths:
        runtime.load_manifest(path)
    return runtime


def build_skill_runtime(
    manifest: CliExtensionManifest,
    *,
    repository: RuntimeStorageRepository,
    profile_loader: ProfileLoader,
) -> SkillRuntime:
    runtime = SkillRuntime(
        context_resolver=lambda session_id: _resolve_skill_activation_context(repository, profile_loader, session_id)
    )
    for definition in builtin_skill_definitions(manifest.skill_overrides):
        runtime.register_skill(definition)
    for path in manifest.skill_manifest_paths:
        runtime.load_manifest(path)
    for path in manifest.skill_package_paths:
        runtime.load_package(path)
    return runtime


def build_mcp_runtime(manifest: CliExtensionManifest) -> McpRuntime:
    runtime = McpRuntime()
    for definition in manifest.mcp_definitions:
        runtime.register_server(
            replace(
                definition,
                enabled=manifest.mcp_overrides.get(definition.server_id, definition.enabled),
            )
        )
    return runtime


def _load_enabled_overrides(manifest: Mapping[str, Any], section: str) -> dict[str, bool]:
    payload = manifest.get(section, {})
    if not isinstance(payload, Mapping):
        return {}
    overrides: dict[str, bool] = {}
    for item_id, record in payload.items():
        if isinstance(record, Mapping) and "enabled" in record:
            overrides[str(item_id)] = bool(record["enabled"])
    return overrides


def _load_manifest_paths(manifest: Mapping[str, Any], section: str, *, profile_dir: Path) -> tuple[Path, ...]:
    payload = manifest.get(section, ())
    if not isinstance(payload, list):
        return ()
    paths: list[Path] = []
    for item in payload:
        raw = str(item).strip()
        if not raw:
            continue
        path = Path(raw)
        if not path.is_absolute():
            path = profile_dir / path
        paths.append(path)
    return tuple(paths)


def _load_mcp_servers(manifest: Mapping[str, Any]) -> tuple[McpServerDefinition, ...]:
    payload = manifest.get("mcp_servers", ())
    if not isinstance(payload, list):
        return ()
    definitions: list[McpServerDefinition] = []
    for item in payload:
        if not isinstance(item, Mapping):
            continue
        definitions.append(mcp_server_from_payload(item))
    return tuple(definitions)


def _resolve_skill_activation_context(
    repository: RuntimeStorageRepository,
    profile_loader: ProfileLoader,
    session_id: str,
) -> SkillActivationContext:
    session = repository.load_session(session_id)
    if session is None:
        raise KeyError(session_id)
    loaded = profile_loader.load(profile_id=session.profile_id)
    return SkillActivationContext(
        profile_id=loaded.state.profile_id,
        workspace_id=session.workspace_id,
        mode=loaded.state.mode,
    )
