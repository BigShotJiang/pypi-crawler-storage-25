"""Governable companion identity and onboarding surfaces."""

from __future__ import annotations

import random
import re
from dataclasses import dataclass
from typing import Callable, Sequence

from .loader import LoadedProfile, load_packaged_aegis_text
from .policy import HerModeSettings, resolve_personality_preset

DEFAULT_AEGIS_TEXT = "\n".join(
    (
        "You are Aegis, a persistent AI built to protect continuity, context, and trust across time.",
        "Every named clone is still Aegis: the core charter is stable even when the clone's voice evolves.",
        "Stay grounded, calm, direct, and exact.",
        "Never fake memory, certainty, capability, intimacy, or identity.",
        "Let AEGIS.md define the immutable core, let CLONE.md define this clone's voice, and let FRIEND.md define durable facts about the user.",
    )
)
DEFAULT_CLONE_TEXT = "\n".join(
    (
        "You are a named Aegis clone for this friend.",
        "Protect the thread, carry context forward, and make your voice legible over time.",
        "Stay warm when invited, exact when it matters, and trustworthy always.",
    )
)
DEFAULT_SOUL_TEXT = DEFAULT_CLONE_TEXT


@dataclass(frozen=True, slots=True)
class OnboardingCheckpoint:
    checkpoint_id: str
    label: str
    status: str
    summary: str


@dataclass(frozen=True, slots=True)
class CompanionOnboardingState:
    status: str
    ready: bool
    missing_fields: tuple[str, ...]
    next_step: str
    summary: str
    checkpoints: tuple[OnboardingCheckpoint, ...]


@dataclass(frozen=True, slots=True)
class CompanionIdentityState:
    display_name: str
    mode: str
    soul_text: str
    aegis_text: str
    clone_text: str
    friend_text: str
    personality_preset: str
    personality_label: str
    personality_traits: tuple[str, ...]
    personality_summary: str
    relational_stance: str
    initiative: str
    continuity_notes: tuple[str, ...]
    governance_summary: str
    proactive_summary: str
    voice_identity_summary: str


@dataclass(frozen=True, slots=True)
class CompanionGovernanceState:
    identity: CompanionIdentityState
    onboarding: CompanionOnboardingState


@dataclass(frozen=True, slots=True)
class FriendProfileQuestion:
    field_id: str
    canonical_label: str
    bucket: str
    prompt_title: str
    prompt_body: str
    emoji: str
    aliases: tuple[str, ...] = ()


FRIEND_PROFILE_QUESTIONS = (
    FriendProfileQuestion(
        field_id="preferred_name",
        canonical_label="Preferred name",
        bucket="required",
        prompt_title="What Should I Call You?",
        prompt_body="The name, nickname, or way of addressing you that feels right and natural.",
        emoji="💬",
        aliases=("name", "nickname", "call me"),
    ),
    FriendProfileQuestion(
        field_id="current_work",
        canonical_label="Current work",
        bucket="required",
        prompt_title="What Work Are You In Right Now?",
        prompt_body="The work, role, or long-running focus I should optimize around across sessions.",
        emoji="🌿",
        aliases=("work", "current role", "work focus"),
    ),
    FriendProfileQuestion(
        field_id="school",
        canonical_label="School",
        bucket="good-to-have",
        prompt_title="Where Did You Go To School?",
        prompt_body="Only if it still shapes how you see yourself, your path, or your context.",
        emoji="🎓",
    ),
    FriendProfileQuestion(
        field_id="current_city",
        canonical_label="Current city",
        bucket="good-to-have",
        prompt_title="What City Are You Living In?",
        prompt_body="Only if place materially affects your routines, timing, or day-to-day context.",
        emoji="🌆",
        aliases=("city", "home city"),
    ),
    FriendProfileQuestion(
        field_id="mbti",
        canonical_label="MBTI",
        bucket="good-to-have",
        prompt_title="Do You Know Your MBTI?",
        prompt_body="Only if it is a framing you actually use for yourself.",
        emoji="🧠",
    ),
    FriendProfileQuestion(
        field_id="dream",
        canonical_label="Dream",
        bucket="good-to-have",
        prompt_title="What Dream Or Long Pull Matters To You?",
        prompt_body="A long-range aspiration, pull, or direction that keeps showing up in your life.",
        emoji="✨",
    ),
    FriendProfileQuestion(
        field_id="creative_hobby",
        canonical_label="Creative hobby",
        bucket="good-to-have",
        prompt_title="What Creative Hobby Do You Actually Enjoy?",
        prompt_body="Anything hands-on or expressive you come back to because it feels like you.",
        emoji="🎨",
        aliases=("hobby creative",),
    ),
    FriendProfileQuestion(
        field_id="media_hobby",
        canonical_label="Media hobby",
        bucket="good-to-have",
        prompt_title="What Media Hobby Do You Keep Coming Back To?",
        prompt_body="Reading, film, games, music, or another media habit that reliably feels like home.",
        emoji="📚",
        aliases=("hobby media",),
    ),
    FriendProfileQuestion(
        field_id="movement_hobby",
        canonical_label="Movement hobby",
        bucket="good-to-have",
        prompt_title="What Movement Or Outdoors Hobby Do You Enjoy?",
        prompt_body="Anything physical or outdoors that is actually part of your life when it can be.",
        emoji="🏃",
        aliases=("hobby movement",),
    ),
    FriendProfileQuestion(
        field_id="boundaries",
        canonical_label="Boundaries",
        bucket="good-to-have",
        prompt_title="Any Durable Boundaries Or Sensitivities I Should Respect?",
        prompt_body="Only the stable ones that would help me avoid overstepping across time.",
        emoji="🧱",
        aliases=("sensitivities", "boundaries and sensitivities"),
    ),
)

_FRIEND_PROFILE_QUESTION_BY_ID = {question.field_id: question for question in FRIEND_PROFILE_QUESTIONS}


def _normalize_friend_field_label(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.strip().lower()).strip()


_FRIEND_PROFILE_FIELD_LOOKUP = {
    _normalize_friend_field_label(label): question.field_id
    for question in FRIEND_PROFILE_QUESTIONS
    for label in (question.canonical_label, *question.aliases)
}


def _clean_friend_field_value(value: str) -> str:
    cleaned = value.strip().strip("*").strip()
    cleaned = cleaned.strip("\"' ")
    return cleaned


def parse_friend_profile(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        line = re.sub(r"^[-*]\s+", "", line)
        if ":" not in line:
            continue
        label, raw_value = line.split(":", 1)
        field_id = _FRIEND_PROFILE_FIELD_LOOKUP.get(_normalize_friend_field_label(label))
        value = _clean_friend_field_value(raw_value)
        if field_id is None or not value:
            continue
        if value.lower() in {"unknown", "n/a", "none", "<unknown>", "<unset>"}:
            continue
        values[field_id] = value
    if "preferred_name" not in values:
        name_match = re.search(
            r"(?i)\b(?:call me|i go by|my name is|i'm called|i am called)\s+([^\n,.;:]+)",
            text,
        )
        if name_match is not None:
            inferred = _clean_friend_field_value(name_match.group(1))
            if inferred:
                values["preferred_name"] = inferred
    if "current_work" not in values:
        work_match = re.search(
            (
                r"(?i)\b(?:i work on|i'm working on|i am working on|user works on|i build|i'm building|"
                r"i am building|user builds|i research|i'm researching|i am researching|user researches|"
                r"i study|i'm studying|i am studying|user studies|current work is|my work is)\s+([^\n.!?]+)"
            ),
            text,
        )
        if work_match is not None:
            inferred = _clean_friend_field_value(work_match.group(1))
            if inferred:
                values["current_work"] = inferred
    return values


def friend_profile_fields(profile: LoadedProfile) -> dict[str, str]:
    return parse_friend_profile(friend_text(profile))


def render_friend_profile(**field_values: str | None) -> str:
    lines: list[str] = []
    for question in FRIEND_PROFILE_QUESTIONS:
        value = _clean_friend_field_value(str(field_values.get(question.field_id) or ""))
        if value:
            lines.append(f"{question.canonical_label}: {value}")
    return "\n".join(lines)


def missing_friend_required_questions(profile: LoadedProfile) -> tuple[FriendProfileQuestion, ...]:
    values = friend_profile_fields(profile)
    return tuple(
        question
        for question in FRIEND_PROFILE_QUESTIONS
        if question.bucket == "required" and not values.get(question.field_id)
    )


def missing_friend_good_to_have_questions(profile: LoadedProfile) -> tuple[FriendProfileQuestion, ...]:
    values = friend_profile_fields(profile)
    return tuple(
        question
        for question in FRIEND_PROFILE_QUESTIONS
        if question.bucket == "good-to-have" and not values.get(question.field_id)
    )


def select_friend_onboarding_questions(
    profile: LoadedProfile,
    *,
    good_to_have_limit: int = 2,
    chooser: Callable[[Sequence[FriendProfileQuestion], int], Sequence[FriendProfileQuestion]] | None = None,
) -> tuple[FriendProfileQuestion, ...]:
    required = missing_friend_required_questions(profile)
    good_to_have = missing_friend_good_to_have_questions(profile)
    if good_to_have_limit <= 0 or not good_to_have:
        sampled_good_to_have: tuple[FriendProfileQuestion, ...] = ()
    elif len(good_to_have) <= good_to_have_limit:
        sampled_good_to_have = good_to_have
    else:
        sampled_good_to_have = tuple((chooser or random.sample)(good_to_have, good_to_have_limit))
    return required + sampled_good_to_have


def resolved_her_mode(profile: LoadedProfile) -> HerModeSettings:
    if profile.her_mode is not None:
        return profile.her_mode
    preset = resolve_personality_preset(None, mode=profile.state.mode)
    return HerModeSettings(
        personality_preset=preset.preset_id,
        personality=preset.traits,
    )


def aegis_text(profile: LoadedProfile) -> str:
    try:
        return load_packaged_aegis_text().strip()
    except OSError:
        return DEFAULT_AEGIS_TEXT


def render_clone_charter(
    *,
    display_name: str,
    personality_preset: str | None,
    initiative: str,
    mode: str = "default",
) -> str:
    preset = resolve_personality_preset(personality_preset, mode=mode)
    traits = ", ".join(preset.traits) or "grounded, direct, trustworthy"
    return "\n".join(
        (
            f"You are {display_name}, a named Aegis clone for this friend.",
            f"Default posture: {preset.summary}",
            f"Traits to preserve: {traits}.",
            f"Initiative style: {initiative}.",
            "Carry continuity carefully, protect trust, and let the friend refine this clone over time.",
        )
    )


def clone_text(profile: LoadedProfile) -> str:
    her_mode = resolved_her_mode(profile)
    return (
        profile.clone_text
        or profile.soul_text
        or render_clone_charter(
            display_name=profile.state.display_name,
            personality_preset=her_mode.personality_preset,
            initiative=her_mode.initiative,
            mode=profile.state.mode,
        )
        or DEFAULT_CLONE_TEXT
    ).strip()


def soul_text(profile: LoadedProfile) -> str:
    return clone_text(profile)


def friend_text(profile: LoadedProfile) -> str:
    return (profile.friend_text or "").strip()


def build_companion_identity_state(profile: LoadedProfile) -> CompanionIdentityState:
    her_mode = resolved_her_mode(profile)
    preset = resolve_personality_preset(her_mode.personality_preset, mode=profile.state.mode)
    traits = her_mode.personality or preset.traits
    clone_charter = clone_text(profile)
    friend_profile = friend_text(profile)
    return CompanionIdentityState(
        display_name=profile.state.display_name,
        mode=profile.state.mode,
        soul_text=clone_charter,
        aegis_text=aegis_text(profile),
        clone_text=clone_charter,
        friend_text=friend_profile,
        personality_preset=preset.preset_id,
        personality_label=preset.label,
        personality_traits=traits,
        personality_summary=preset.summary,
        relational_stance=preset.relational_stance,
        initiative=her_mode.initiative,
        continuity_notes=her_mode.notes,
        governance_summary=her_mode.governance_summary(),
        proactive_summary=her_mode.proactive_summary(),
        voice_identity_summary=her_mode.voice_identity_summary(),
    )


def build_companion_onboarding_state(profile: LoadedProfile) -> CompanionOnboardingState:
    manifest = dict(profile.manifest)
    her_mode_payload = manifest.get("her_mode") if isinstance(manifest.get("her_mode"), dict) else {}
    assert isinstance(her_mode_payload, dict)
    identity = build_companion_identity_state(profile)
    missing_required_friend_questions = missing_friend_required_questions(profile)
    missing_good_to_have_friend_questions = missing_friend_good_to_have_questions(profile)

    has_explicit_display_name = "display_name" in manifest
    has_custom_clone = profile.clone_text is not None and profile.clone_text.strip() != ""
    has_explicit_personality = any(key in her_mode_payload for key in ("personality_preset", "personality"))
    has_explicit_initiative = "initiative" in her_mode_payload
    has_required_friend_profile = not missing_required_friend_questions

    checkpoints = (
        OnboardingCheckpoint(
            checkpoint_id="display-name",
            label="Display name",
            status="ready" if has_explicit_display_name else "needs-confirmation",
            summary=(
                f"identity anchored as {identity.display_name}"
                if has_explicit_display_name
                else f"using derived display name {identity.display_name}"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="clone",
            label="Clone charter",
            status="ready" if has_custom_clone else "needs-confirmation",
            summary=(
                "durable CLONE.md is present"
                if has_custom_clone
                else "still running on the default clone charter"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="personality",
            label="Personality preset",
            status="ready" if has_explicit_personality else "needs-confirmation",
            summary=(
                f"preset {identity.personality_label} is explicitly pinned"
                if has_explicit_personality
                else f"preset {identity.personality_label} is inferred from defaults"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="initiative",
            label="Initiative posture",
            status="ready" if has_explicit_initiative else "needs-confirmation",
            summary=(
                f"initiative is set to {identity.initiative}"
                if has_explicit_initiative
                else f"initiative is falling back to {identity.initiative}"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="friend",
            label="Friend profile",
            status="ready" if has_required_friend_profile else "needs-confirmation",
            summary=(
                (
                    "FRIEND.md has the required stable user fields set"
                    + (
                        f"; {len(missing_good_to_have_friend_questions)} optional profile fields remain open"
                        if missing_good_to_have_friend_questions
                        else ""
                    )
                )
                if has_required_friend_profile
                else (
                    "FRIEND.md still needs the required stable user fields: "
                    + ", ".join(question.canonical_label for question in missing_required_friend_questions)
                )
            ),
        ),
    )
    missing_fields = tuple(
        checkpoint.checkpoint_id for checkpoint in checkpoints if checkpoint.status != "ready"
    )
    ready = not missing_fields
    if ready:
        status = "ready"
        next_step = "identity-governance-ready"
        summary = (
            "AEGIS, clone, and friend state are explicitly grounded for one "
            "long-lived companion path."
        )
    else:
        status = "needs-onboarding"
        next_step = "confirm the clone charter and gather FRIEND.md before treating the profile as fully onboarded"
        summary = (
            "Companion identity exists, but onboarding is still relying on defaults "
            "for: " + ", ".join(missing_fields)
        )
    return CompanionOnboardingState(
        status=status,
        ready=ready,
        missing_fields=missing_fields,
        next_step=next_step,
        summary=summary,
        checkpoints=checkpoints,
    )


def build_companion_governance_state(profile: LoadedProfile) -> CompanionGovernanceState:
    return CompanionGovernanceState(
        identity=build_companion_identity_state(profile),
        onboarding=build_companion_onboarding_state(profile),
    )
