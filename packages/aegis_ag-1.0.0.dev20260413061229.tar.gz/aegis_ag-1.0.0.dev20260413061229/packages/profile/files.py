"""Filesystem helpers for durable profile text surfaces."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

PROFILE_MANIFEST_FILENAME = "profile.json"
AEGIS_FILENAME = "AEGIS.md"
CLONE_FILENAME = "CLONE.md"
FRIEND_FILENAME = "FRIEND.md"
LEGACY_SOUL_FILENAME = "SOUL.md"
SOUL_FILENAME = CLONE_FILENAME
PROFILE_BUNDLES_DIRNAME = "profiles"


def profile_manifest_path(profile_dir: Path) -> Path:
    return profile_dir / PROFILE_MANIFEST_FILENAME


def clone_text_path(profile_dir: Path) -> Path:
    return profile_dir / CLONE_FILENAME


def friend_text_path(profile_dir: Path) -> Path:
    return profile_dir / FRIEND_FILENAME


def legacy_soul_path(profile_dir: Path) -> Path:
    return profile_dir / LEGACY_SOUL_FILENAME


def profile_bundle_has_content(bundle_dir: Path) -> bool:
    return any(
        path.exists()
        for path in (
            profile_manifest_path(bundle_dir),
            clone_text_path(bundle_dir),
            legacy_soul_path(bundle_dir),
            friend_text_path(bundle_dir),
        )
    )


def load_clone_text_file(profile_dir: Path, *, migrate_legacy: bool = True) -> str | None:
    clone_path = clone_text_path(profile_dir)
    legacy_path = legacy_soul_path(profile_dir)
    if clone_path.exists():
        if migrate_legacy and legacy_path.exists():
            legacy_path.unlink()
        return clone_path.read_text(encoding="utf-8")
    if not legacy_path.exists():
        return None
    clone_text = legacy_path.read_text(encoding="utf-8")
    if migrate_legacy:
        clone_path.parent.mkdir(parents=True, exist_ok=True)
        clone_path.write_text(clone_text, encoding="utf-8")
        legacy_path.unlink()
    return clone_text


def write_clone_text_file(profile_dir: Path, clone_text: str | None) -> Path:
    clone_path = clone_text_path(profile_dir)
    legacy_path = legacy_soul_path(profile_dir)
    clone_path.parent.mkdir(parents=True, exist_ok=True)
    if clone_text is None:
        if clone_path.exists():
            clone_path.unlink()
        if legacy_path.exists():
            legacy_path.unlink()
        return clone_path
    clone_path.write_text(clone_text, encoding="utf-8")
    if legacy_path.exists():
        legacy_path.unlink()
    return clone_path


def write_friend_text_file(profile_dir: Path, friend_text: str | None) -> Path:
    path = friend_text_path(profile_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    if friend_text is None:
        if path.exists():
            path.unlink()
        return path
    path.write_text(friend_text, encoding="utf-8")
    return path


def write_profile_manifest_file(profile_dir: Path, manifest: Mapping[str, Any]) -> Path:
    path = profile_manifest_path(profile_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dict(manifest), indent=2, sort_keys=True), encoding="utf-8")
    return path
