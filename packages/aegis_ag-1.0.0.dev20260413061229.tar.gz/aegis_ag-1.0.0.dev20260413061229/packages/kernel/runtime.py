"""Canonical event-to-outcome lifecycle orchestration.

The kernel is intentionally thin: it coordinates the turn lifecycle across the
shared contracts and capability ports without embedding provider, SQL, or
delivery specifics.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta, timezone
from html import unescape as html_unescape
import json
import re
from typing import Any, Protocol, runtime_checkable
from uuid import uuid4

from packages.agent_runs import AgentRunService
from packages.capabilities.runtime import (
    ContextCapability,
    DeliveryAdapterCapability,
    MemoryCapability,
    ModelProviderCapability,
    PlanningCapability,
    TelemetrySinkCapability,
    ToolCapability,
)
from packages.contracts.runtime import (
    AgentRunState,
    AgentRunStep,
    ContextBundle,
    EventEnvelope,
    ExecutionResult,
    GoalNode,
    MemoryRecord,
    PlanDraft,
    ProfileState,
    SessionContinuityState,
    SessionState,
)
from packages.planning.runtime import (
    GoalGraph,
    PlanningDecision,
    build_goal_graph,
    build_plan_draft_from_decision,
)
from packages.session import SessionLineageService


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


@runtime_checkable
class KernelStoragePort(Protocol):
    """Typed storage port used by the kernel lifecycle."""

    def load_profile(self, profile_id: str) -> ProfileState | None:
        """Load a durable profile record."""

    def load_session(self, session_id: str) -> SessionState | None:
        """Load a durable session record."""

    def load_goal_graph(self, session_id: str) -> GoalGraph | None:
        """Load the durable goal graph for a session."""

    def upsert_profile(
        self,
        profile: ProfileState,
        *,
        updated_at: datetime | None = None,
    ) -> None:
        """Persist a profile record."""

    def upsert_session(
        self,
        session: SessionState,
        *,
        resume_count_delta: int = 0,
    ) -> None:
        """Persist a session record."""

    def upsert_goal_graph(self, graph: GoalGraph) -> None:
        """Persist a durable goal graph."""


@dataclass(frozen=True, slots=True)
class KernelDependencies:
    storage: KernelStoragePort
    context: ContextCapability
    planning: PlanningCapability
    memory: MemoryCapability
    model_provider: ModelProviderCapability
    telemetry: TelemetrySinkCapability
    tools: ToolCapability | None = None
    delivery: DeliveryAdapterCapability | None = None


@dataclass(frozen=True, slots=True)
class KernelTurnRequest:
    event: EventEnvelope
    prompt: str
    goal_query: str | None = None
    tool_name: str | None = None
    tool_arguments: Mapping[str, Any] = field(default_factory=dict)
    delivery_payload: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class KernelStageRecord:
    stage: str
    detail: str
    recorded_at: datetime


@dataclass(frozen=True, slots=True)
class KernelOutcome:
    event: EventEnvelope
    profile: ProfileState
    session: SessionState
    continuity: SessionContinuityState
    goals: tuple[GoalNode, ...]
    goal_graph: GoalGraph
    memories: tuple[MemoryRecord, ...]
    context: ContextBundle
    decision: PlanningDecision | None
    plan: PlanDraft | None
    run: AgentRunState | None
    execution: ExecutionResult
    delivery: ExecutionResult | None
    stages: tuple[KernelStageRecord, ...]


@dataclass(frozen=True, slots=True)
class _TextToolCall:
    tool_name: str
    arguments: Mapping[str, str]


@dataclass(frozen=True, slots=True)
class _ParsedToolCalls:
    cleaned_text: str
    calls: tuple[_TextToolCall, ...]


@dataclass(frozen=True, slots=True)
class KernelService:
    dependencies: KernelDependencies

    def run(self, request: KernelTurnRequest) -> KernelOutcome:
        stages: list[KernelStageRecord] = []
        event = request.event
        current = _utc_now()

        def stage(name: str, detail: str) -> None:
            stages.append(KernelStageRecord(stage=name, detail=detail, recorded_at=_utc_now()))

        stage("ingest", f"event={event.event_id}")
        session = self.dependencies.storage.load_session(event.session_id)
        if session is None:
            raise KeyError(f"unknown session: {event.session_id}")

        profile = self.dependencies.storage.load_profile(session.profile_id)
        if profile is None:
            raise KeyError(f"unknown profile: {session.profile_id}")

        stage("resolve", f"profile={profile.profile_id} session={session.session_id}")

        goal_graph = self._recover_goal_graph(session)
        goal_graph = self._maintain_goal_graph(session, goal_graph, request, current)
        stage(
            "goals-maintain",
            f"goals={len(goal_graph.nodes)} active_goal={goal_graph.active_goal_id or '<none>'}",
        )
        continuity_session, continuity = self._recover_continuity(session, goal_graph)
        memories = self._recover_memories(continuity_session, goal_graph, request)
        goals = tuple(node.to_contract_goal() for node in goal_graph.nodes)
        stage(
            "recover",
            " ".join(
                (
                    f"goals={len(goals)}",
                    f"memories={len(memories)}",
                    f"active_goal={goal_graph.active_goal_id or '<none>'}",
                    f"continuity={continuity.mode}",
                    f"origin={continuity.origin_session_id}",
                )
            ),
        )

        context = self.dependencies.context.assemble(continuity_session, goals, memories)
        stage("context", f"bundle={context.bundle_id} budget={context.token_budget}")

        decision, plan = self._choose_plan(goal_graph, memories, continuity_session)
        stage(
            "select",
            " ".join(
                (
                    f"decision={decision.decision_id}",
                    f"goal={decision.selected_move.goal_id or 'none'}",
                    f"kind={decision.selected_move.kind}",
                    f"progression={decision.rationale.progression_action}",
                    f"planned_active_goal={decision.rationale.planned_active_goal_id or '<none>'}",
                )
            ),
        )
        execution_goals = tuple(node.to_contract_goal() for node in goal_graph.nodes)
        context = self._context_for_generation(
            request=request,
            session=continuity_session,
            goals=execution_goals,
            memories=memories,
            context=context,
            decision=decision,
            plan=plan,
            continuity=continuity,
        )
        prepared_run, prompt_for_execution = self._prepare_agent_run(request, continuity_session)
        execution, run = self._execute(
            request,
            profile,
            continuity_session,
            context,
            prompt_for_execution=prompt_for_execution,
            agent_run=prepared_run,
        )
        stage("execute", f"execution={execution.execution_id} outcome={execution.outcome}")

        goal_graph = self._refresh_goal_graph(event.session_id, fallback=goal_graph)
        goal_graph = self._reconcile_goal_graph(
            continuity_session,
            goal_graph,
            request,
            execution,
            decision=decision,
            current=_utc_now(),
        )
        execution_goals = tuple(node.to_contract_goal() for node in goal_graph.nodes)
        stage(
            "goals-reconcile",
            f"goals={len(goal_graph.nodes)} active_goal={goal_graph.active_goal_id or '<none>'}",
        )

        persisted_at = _utc_now()
        refreshed_session = self._persist(
            profile,
            continuity_session,
            persisted_at,
            goal_graph,
            continuity,
            run=run,
        )
        stage("persist", f"session={session.session_id}")

        delivery = self._deliver(request, profile, refreshed_session, execution, plan)
        stage("emit", "telemetry and delivery hooks dispatched")

        outcome = KernelOutcome(
            event=event,
            profile=profile,
            session=refreshed_session,
            continuity=continuity,
            goals=execution_goals,
            goal_graph=goal_graph,
            memories=memories,
            context=context,
            decision=decision,
            plan=plan,
            run=run,
            execution=execution,
            delivery=delivery,
            stages=tuple(stages),
        )
        self._emit_telemetry(outcome)
        return outcome

    def _recover_goal_graph(self, session: SessionState) -> GoalGraph:
        load_goal_graph = getattr(self.dependencies.storage, "load_goal_graph", None)
        if callable(load_goal_graph):
            graph = load_goal_graph(session.session_id)
            if graph is not None:
                return graph
        return build_goal_graph(session_id=session.session_id, goals=())

    def _refresh_goal_graph(self, session_id: str, *, fallback: GoalGraph) -> GoalGraph:
        load_goal_graph = getattr(self.dependencies.storage, "load_goal_graph", None)
        if callable(load_goal_graph):
            graph = load_goal_graph(session_id)
            if graph is not None:
                return graph
        return fallback

    def _recover_memories(
        self,
        session: SessionState,
        goal_graph: GoalGraph,
        request: KernelTurnRequest,
    ) -> tuple[MemoryRecord, ...]:
        query = request.goal_query or request.prompt or request.event.payload.get("message", "")
        if not query.strip() and goal_graph.nodes:
            query = " ".join(node.title for node in goal_graph.nodes[:3])
        if not query.strip():
            return ()
        return self.dependencies.memory.search(session.session_id, query)

    def _recover_continuity(
        self,
        session: SessionState,
        goal_graph: GoalGraph,
    ) -> tuple[SessionState, SessionContinuityState]:
        service = SessionLineageService(repository=self.dependencies.storage)
        load_lineage = getattr(self.dependencies.storage, "lineage", None)
        lineage = load_lineage(session.session_id) if callable(load_lineage) else (session,)
        continuity = service.continuity_state(
            session,
            lineage=lineage,
            active_goal_id=goal_graph.active_goal_id,
        )
        return service.apply_continuity_state(session, continuity), continuity

    def _choose_plan(
        self,
        goal_graph: GoalGraph,
        memories: tuple[MemoryRecord, ...],
        session: SessionState,
    ) -> tuple[PlanningDecision, PlanDraft]:
        decision = self.dependencies.planning.choose_next_step(
            session=session,
            graph=goal_graph,
            memories=memories,
        )
        return decision, build_plan_draft_from_decision(decision)

    def _maintain_goal_graph(
        self,
        session: SessionState,
        goal_graph: GoalGraph,
        request: KernelTurnRequest,
        current: datetime,
    ) -> GoalGraph:
        maintain = getattr(self.dependencies.planning, "maintain_goal_graph", None)
        if not callable(maintain):
            return goal_graph
        result = maintain(
            session=session,
            graph=goal_graph,
            prompt=request.prompt,
            goal_query=request.goal_query,
            event=request.event,
            now=current,
        )
        return result.graph if hasattr(result, "graph") else goal_graph

    def _reconcile_goal_graph(
        self,
        session: SessionState,
        goal_graph: GoalGraph,
        request: KernelTurnRequest,
        execution: ExecutionResult,
        *,
        decision: PlanningDecision | None,
        current: datetime,
    ) -> GoalGraph:
        reconcile = getattr(self.dependencies.planning, "reconcile_goal_graph", None)
        if not callable(reconcile):
            return goal_graph
        result = reconcile(
            session=session,
            graph=goal_graph,
            prompt=request.prompt,
            execution=execution,
            decision=decision,
            event=request.event,
            now=current,
        )
        return result.graph if hasattr(result, "graph") else goal_graph

    def _context_for_generation(
        self,
        *,
        request: KernelTurnRequest,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        context: ContextBundle,
        decision: PlanningDecision | None,
        plan: PlanDraft | None,
        continuity: SessionContinuityState,
    ) -> ContextBundle:
        if request.tool_name is not None:
            return context
        augment = getattr(self.dependencies.context, "augment_for_generation", None)
        if not callable(augment):
            return context
        enriched = augment(
            session=session,
            goals=goals,
            memories=memories,
            context=context,
            decision=decision,
            plan=plan,
            continuity=continuity,
        )
        return enriched if isinstance(enriched, ContextBundle) else context

    def _prepare_agent_run(
        self,
        request: KernelTurnRequest,
        session: SessionState,
    ) -> tuple[AgentRunState | None, str]:
        if request.tool_name is not None or self.dependencies.tools is None:
            return None, request.prompt
        load_active_run = getattr(self.dependencies.storage, "load_latest_open_agent_run", None)
        upsert_run = getattr(self.dependencies.storage, "upsert_agent_run", None)
        if not callable(load_active_run):
            return None, request.prompt
        active_run = load_active_run(session.session_id)
        service = AgentRunService()
        if active_run is None or not service.should_resume(request.prompt):
            return None, request.prompt
        resumed = service.resume_run(active_run)
        if callable(upsert_run):
            upsert_run(resumed)
        return resumed, service.resume_prompt_for_request(resumed, request.prompt)

    def _execute(
        self,
        request: KernelTurnRequest,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        *,
        prompt_for_execution: str,
        agent_run: AgentRunState | None,
    ) -> tuple[ExecutionResult, AgentRunState | None]:
        if request.tool_name is not None:
            if self.dependencies.tools is None:
                raise RuntimeError("tool execution requested but no tool capability was configured")
            return (
                self.dependencies.tools.invoke(
                    request.tool_name,
                    dict(request.tool_arguments),
                    session_id=session.session_id,
                ),
                None,
            )
        response = self.dependencies.model_provider.generate(
            profile=profile,
            session=session,
            context=context,
            prompt=prompt_for_execution,
        )
        if self.dependencies.tools is None:
            return _clean_execution_summary(response), None
        return self._execute_model_tool_loop(
            request=request,
            profile=profile,
            session=session,
            context=context,
            initial=response,
            prompt_for_execution=prompt_for_execution,
            agent_run=agent_run,
        )

    def _execute_model_tool_loop(
        self,
        *,
        request: KernelTurnRequest,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        initial: ExecutionResult,
        prompt_for_execution: str,
        agent_run: AgentRunState | None,
    ) -> tuple[ExecutionResult, AgentRunState | None]:
        response = initial
        prompt_tokens_total = response.prompt_tokens
        completion_tokens_total = response.completion_tokens
        total_tokens_total = response.total_tokens
        loop_context = context
        loop_traces: list[str] = []
        run_service = AgentRunService()
        budget = run_service.budget
        current_run = agent_run
        starting_model_turn_count = current_run.model_turn_count if current_run is not None else 0
        deadline = _utc_now() + timedelta(
            seconds=(current_run.max_wall_time_seconds if current_run is not None else budget.max_wall_time_seconds)
        )
        last_tool_batch_signature: tuple[str, ...] | None = None
        repeated_tool_batch_count = 0
        while True:
            parsed = _parse_text_tool_calls(response.summary)
            if current_run is None and parsed.calls:
                current_run = run_service.start_run(
                    session_id=session.session_id,
                    source_event_id=request.event.event_id,
                    prompt=request.prompt,
                )
                self._persist_agent_run(current_run)
            if current_run is not None:
                cleaned_summary = parsed.cleaned_text or response.summary
                current_run, model_step = run_service.record_model_turn(
                    current_run,
                    summary=cleaned_summary,
                )
                self._persist_agent_run(current_run, step=model_step)
            if not parsed.calls:
                cleaned = _with_execution_usage(
                    _clean_execution_summary(response),
                    prompt_tokens=prompt_tokens_total,
                    completion_tokens=completion_tokens_total,
                    total_tokens=total_tokens_total,
                )
                if not loop_traces:
                    if current_run is not None:
                        current_run = run_service.complete(current_run, summary=cleaned.summary)
                        self._persist_agent_run(current_run)
                    return cleaned, current_run
                finalized = replace(
                    cleaned,
                    side_effects=tuple(dict.fromkeys((*cleaned.side_effects, *loop_traces))),
                )
                if current_run is not None:
                    current_run = run_service.complete(current_run, summary=finalized.summary)
                    self._persist_agent_run(current_run)
                return finalized, current_run

            observations: list[str] = []
            tool_batch_signature: list[str] = []
            for call in parsed.calls:
                try:
                    result = self.dependencies.tools.invoke(
                        call.tool_name,
                        dict(call.arguments),
                        session_id=session.session_id,
                    )
                except Exception as error:
                    result = ExecutionResult(
                        execution_id=f"tool:{session.session_id}:{uuid4().hex[:8]}",
                        session_id=session.session_id,
                        outcome="failed",
                        summary=str(error),
                        side_effects=(call.tool_name,),
                    )
                loop_traces.append(call.tool_name)
                tool_batch_signature.append(_tool_call_signature(call))
                if current_run is not None:
                    current_run, tool_step = run_service.record_tool_step(
                        current_run,
                        tool_name=call.tool_name,
                        arguments=call.arguments,
                        result=result,
                    )
                    self._persist_agent_run(current_run, step=tool_step)
                observations.append(
                    "\n".join(
                        [
                            f"tool: {call.tool_name}",
                            f"arguments: {_format_tool_arguments(call.arguments)}",
                            f"outcome: {result.outcome}",
                            f"summary: {_tool_result_preview(result.summary, preview_chars=budget.tool_result_preview_chars)}",
                        ]
                    )
                )

            observations = _enforce_observation_budget(
                observations,
                turn_budget_chars=budget.tool_result_turn_budget_chars,
            )
            batch_signature_tuple = tuple(tool_batch_signature)
            if batch_signature_tuple and batch_signature_tuple == last_tool_batch_signature:
                repeated_tool_batch_count += 1
            else:
                repeated_tool_batch_count = 1 if batch_signature_tuple else 0
            last_tool_batch_signature = batch_signature_tuple or None

            if current_run is not None and repeated_tool_batch_count >= budget.max_repeated_tool_batches:
                recent_steps = self._list_recent_agent_run_steps(current_run.run_id, limit=6)
                continuation_prompt = run_service.build_continuation_prompt(
                    current_run,
                    recent_steps=recent_steps,
                    observations=tuple(observations),
                )
                parked = run_service.park(
                    current_run,
                    continuation_prompt=continuation_prompt,
                    waiting_reason="no-progress-repeat-tool-batch",
                    last_summary=(
                        "The model repeated the same tool batch without enough visible progress. "
                        "Resume the run after adjusting the request or the available tools."
                    ),
                )
                self._persist_agent_run(parked)
                return (
                    ExecutionResult(
                        execution_id=f"run:{parked.run_id}:stalled",
                        session_id=session.session_id,
                        outcome="paused",
                        summary=(
                            "I parked this run because the model kept asking for the same tool batch "
                            "without making enough forward progress. Ask me to continue with a sharper nudge "
                            "and I will resume from the checkpoint."
                        ),
                        prompt_tokens=prompt_tokens_total,
                        completion_tokens=completion_tokens_total,
                        total_tokens=total_tokens_total,
                        side_effects=tuple(dict.fromkeys(loop_traces)),
                    ),
                    parked,
                )

            if current_run is not None and (
                (current_run.model_turn_count - starting_model_turn_count) >= current_run.max_model_turns
                or _utc_now() >= deadline
            ):
                reason = (
                    "model-turn-budget"
                    if (current_run.model_turn_count - starting_model_turn_count) >= current_run.max_model_turns
                    else "wall-time-budget"
                )
                recent_steps = self._list_recent_agent_run_steps(current_run.run_id, limit=6)
                continuation_prompt = run_service.build_continuation_prompt(
                    current_run,
                    recent_steps=recent_steps,
                    observations=tuple(observations),
                )
                parked = run_service.park(
                    current_run,
                    continuation_prompt=continuation_prompt,
                    waiting_reason=reason,
                    last_summary=parsed.cleaned_text or response.summary,
                )
                self._persist_agent_run(parked)
                message = (
                    "I kept working through this request and parked it at a durable checkpoint "
                    f"after {parked.model_turn_count} model rounds and {parked.tool_call_count} tool calls. "
                    "Ask me to continue and I will resume from the saved run."
                )
                return (
                    ExecutionResult(
                        execution_id=f"run:{parked.run_id}:pending",
                        session_id=session.session_id,
                        outcome="paused",
                        summary=message,
                        prompt_tokens=prompt_tokens_total,
                        completion_tokens=completion_tokens_total,
                        total_tokens=total_tokens_total,
                        side_effects=tuple(dict.fromkeys(loop_traces)),
                    ),
                    parked,
                )

            loop_context = _augment_context_with_tool_results(loop_context, observations)
            response = self.dependencies.model_provider.generate(
                profile=profile,
                session=session,
                context=loop_context,
                prompt=_tool_followup_prompt(
                    current_run.prompt if current_run is not None else request.prompt,
                    observations=tuple(observations),
                ),
            )
            prompt_tokens_total += response.prompt_tokens
            completion_tokens_total += response.completion_tokens
            total_tokens_total += response.total_tokens

    def _deliver(
        self,
        request: KernelTurnRequest,
        profile: ProfileState,
        session: SessionState,
        execution: ExecutionResult,
        plan: PlanDraft | None,
    ) -> ExecutionResult | None:
        if self.dependencies.delivery is None:
            return None
        payload = {
            "event_id": request.event.event_id,
            "profile_id": profile.profile_id,
            "session_id": session.session_id,
            "outcome": execution.outcome,
            "summary": execution.summary,
            "plan_id": plan.plan_id if plan is not None else None,
        }
        payload.update(dict(request.delivery_payload))
        return self.dependencies.delivery.deliver(session.session_id, payload)

    def _persist(
        self,
        profile: ProfileState,
        session: SessionState,
        updated_at: datetime,
        goal_graph: GoalGraph,
        continuity: SessionContinuityState,
        *,
        run: AgentRunState | None,
    ) -> SessionState:
        interruption_state = session.interruption_state
        if run is not None:
            run_interruption = AgentRunService().interruption_state(run)
            if run_interruption is not None:
                interruption_state = run_interruption
            elif interruption_state is not None and interruption_state.startswith("agent-run:"):
                interruption_state = None
        refreshed_session = replace(session, updated_at=updated_at, interruption_state=interruption_state)
        self.dependencies.storage.upsert_profile(profile, updated_at=updated_at)
        self.dependencies.storage.upsert_session(
            refreshed_session,
            resume_count_delta=1 if continuity.requires_recovery else 0,
        )
        upsert_goal_graph = getattr(self.dependencies.storage, "upsert_goal_graph", None)
        if callable(upsert_goal_graph):
            upsert_goal_graph(goal_graph)
        return refreshed_session

    def _persist_agent_run(
        self,
        run: AgentRunState,
        *,
        step: AgentRunStep | None = None,
    ) -> None:
        upsert_run = getattr(self.dependencies.storage, "upsert_agent_run", None)
        if callable(upsert_run):
            upsert_run(run)
        append_step = getattr(self.dependencies.storage, "append_agent_run_step", None)
        if step is not None and callable(append_step):
            append_step(step)

    def _list_recent_agent_run_steps(self, run_id: str, *, limit: int) -> tuple[AgentRunStep, ...]:
        list_steps = getattr(self.dependencies.storage, "list_agent_run_steps", None)
        if not callable(list_steps):
            return ()
        return tuple(list_steps(run_id, limit=limit))

    def _emit_telemetry(self, outcome: KernelOutcome) -> None:
        for stage in outcome.stages:
            self.dependencies.telemetry.emit(
                {
                    "event_id": f"telemetry:{outcome.session.session_id}:{stage.stage}:{stage.recorded_at.isoformat()}",
                    "event_type": "kernel.stage",
                    "session_id": outcome.session.session_id,
                    "source": "kernel",
                    "payload": {
                        "stage": stage.stage,
                        "detail": stage.detail,
                        "recorded_at": stage.recorded_at.isoformat(),
                        "event_id": outcome.event.event_id,
                    },
                }
            )
        self.dependencies.telemetry.emit(
            {
                "event_id": f"telemetry:{outcome.session.session_id}:outcome:{uuid4().hex}",
                "event_type": "kernel.outcome",
                "session_id": outcome.session.session_id,
                "source": "kernel",
                "payload": {
                    "event_id": outcome.event.event_id,
                    "profile_id": outcome.profile.profile_id,
                    "context_bundle_id": outcome.context.bundle_id,
                    "execution_id": outcome.execution.execution_id,
                    "execution_outcome": outcome.execution.outcome,
                    "delivery_execution_id": outcome.delivery.execution_id if outcome.delivery is not None else "",
                    "continuity_mode": outcome.continuity.mode,
                    "continuity_origin_session_id": outcome.continuity.origin_session_id,
                    "continuity_requires_recovery": str(outcome.continuity.requires_recovery).lower(),
                    "selected_goal_id": outcome.decision.selected_move.goal_id if outcome.decision is not None else "",
                    "selected_kind": outcome.decision.selected_move.kind if outcome.decision is not None else "",
                    "progression_action": outcome.decision.rationale.progression_action if outcome.decision is not None else "",
                    "planned_active_goal_id": outcome.decision.rationale.planned_active_goal_id if outcome.decision is not None else "",
                    "goal_graph_revision": outcome.goal_graph.revision_id or "",
                    "agent_run_id": outcome.run.run_id if outcome.run is not None else "",
                    "agent_run_status": outcome.run.status if outcome.run is not None else "",
                    "agent_run_step_count": outcome.run.step_count if outcome.run is not None else 0,
                },
            }
        )


_TOOL_CALL_WRAPPER_PATTERN = re.compile(r"</?(?:[\w.-]+:)?tool_call[^>]*>", re.IGNORECASE)
_INVOKE_PATTERN = re.compile(
    r"<(?:[\w.-]+:)?invoke\s+name=(?P<quote>[\"'])(?P<name>.+?)(?P=quote)\s*>(?P<body>.*?)</(?:[\w.-]+:)?invoke>",
    re.IGNORECASE | re.DOTALL,
)
_PARAMETER_PATTERN = re.compile(
    r"<(?:[\w.-]+:)?parameter\s+name=(?P<quote>[\"'])(?P<name>.+?)(?P=quote)\s*>(?P<value>.*?)</(?:[\w.-]+:)?parameter>",
    re.IGNORECASE | re.DOTALL,
)


def _parse_text_tool_calls(raw: str) -> _ParsedToolCalls:
    calls: list[_TextToolCall] = []
    for match in _INVOKE_PATTERN.finditer(raw):
        tool_name = match.group("name").strip()
        if not tool_name:
            continue
        arguments: dict[str, str] = {}
        for parameter in _PARAMETER_PATTERN.finditer(match.group("body")):
            name = parameter.group("name").strip()
            if not name:
                continue
            arguments[name] = html_unescape(parameter.group("value").strip())
        calls.append(_TextToolCall(tool_name=tool_name, arguments=arguments))
    cleaned = _strip_tool_markup(raw)
    return _ParsedToolCalls(cleaned_text=cleaned, calls=tuple(calls))


def _strip_tool_markup(raw: str) -> str:
    cleaned = _INVOKE_PATTERN.sub("", raw)
    cleaned = _TOOL_CALL_WRAPPER_PATTERN.sub("", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def _clean_execution_summary(result: ExecutionResult) -> ExecutionResult:
    cleaned = _strip_tool_markup(result.summary)
    if not cleaned or cleaned == result.summary:
        return result
    return replace(result, summary=cleaned)


def _with_execution_usage(
    result: ExecutionResult,
    *,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
) -> ExecutionResult:
    return replace(
        result,
        prompt_tokens=max(0, prompt_tokens),
        completion_tokens=max(0, completion_tokens),
        total_tokens=max(0, total_tokens),
    )


def _augment_context_with_tool_results(
    context: ContextBundle,
    observations: list[str],
) -> ContextBundle:
    rendered_sections = [context.rendered_prompt or ""]
    rendered_sections.append("## runtime tool results")
    rendered_sections.extend(observations)
    artifact_ids = tuple((*context.artifact_ids, *(f"tool-result-{index + 1}" for index in range(len(observations)))))
    return replace(
        context,
        artifact_ids=artifact_ids,
        rendered_prompt="\n\n".join(section for section in rendered_sections if section.strip()),
    )


def _tool_followup_prompt(original_prompt: str, *, observations: tuple[str, ...]) -> str:
    result_block = "\n\n".join(observations)
    return (
        "Continue the same Aegis turn.\n"
        f"Original user request:\n{original_prompt}\n\n"
        "The requested tool work has already been executed. Use the tool results below to answer directly as Aegis.\n"
        "If more tool work is still necessary, you may emit another <tool_call> block with <invoke> and <parameter> tags.\n"
        "Do not repeat raw tool-call markup in the final user-facing answer.\n\n"
        f"{result_block}"
    )


def _format_tool_arguments(arguments: Mapping[str, str]) -> str:
    if not arguments:
        return "<none>"
    return ", ".join(f"{key}={value}" for key, value in sorted(arguments.items()))


def _tool_call_signature(call: _TextToolCall) -> str:
    payload = json.dumps(dict(sorted(call.arguments.items())), separators=(",", ":"), sort_keys=True)
    return f"{call.tool_name}:{payload}"


def _tool_result_preview(summary: str, *, preview_chars: int) -> str:
    compact = " ".join(summary.split())
    if len(compact) <= preview_chars:
        return compact
    return f"{compact[: preview_chars - 15].rstrip()} ... [truncated]"


def _enforce_observation_budget(
    observations: list[str],
    *,
    turn_budget_chars: int,
) -> list[str]:
    if turn_budget_chars <= 0:
        return observations
    total = sum(len(item) for item in observations)
    if total <= turn_budget_chars:
        return observations
    trimmed = list(observations)
    for index, observation in sorted(
        enumerate(trimmed),
        key=lambda item: len(item[1]),
        reverse=True,
    ):
        if total <= turn_budget_chars:
            break
        if "[truncated]" in observation:
            shortened = observation
        else:
            shortened = _tool_result_preview(observation, preview_chars=max(160, turn_budget_chars // max(len(trimmed), 1)))
        total -= len(trimmed[index])
        trimmed[index] = shortened
        total += len(shortened)
    return trimmed
