"""Built-in tool definitions and handlers.

Keeping built-ins here keeps the executable tool surface package-owned while
allowing thin app surfaces to bind only the dependencies they actually provide.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
import json
import shutil
import subprocess
from typing import Any, Protocol
from urllib.parse import parse_qs, quote_plus, urljoin, urlparse
from urllib.request import Request, urlopen

from packages.contracts.runtime import ExecutionResult, GoalNode
from packages.cron import CronRuntime
from packages.mcp import McpServerDefinition
from packages.profile import LoadedProfile
from packages.skills import SkillDefinition, SkillHubEntry, SkillManifestLoadRecord

from .runtime import ToolDefinition, ToolInvocation, ToolRuntime, ToolSideEffectMetadata


class SkillManagementSurface(Protocol):
    def skill_catalog(self, *, session_id: str | None = None) -> tuple[SkillDefinition, ...]:
        """List installed skills."""

    def search_skill_hub(self, query: str, *, limit: int = 12) -> tuple[SkillHubEntry, ...]:
        """Search the shared skill hub."""

    def inspect_skill(self, skill_id: str, *, session_id: str | None = None) -> SkillDefinition:
        """Inspect one installed skill."""

    def install_skill_source(
        self,
        reference: str | Path,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillManifestLoadRecord:
        """Install a skill package or manifest."""

    def set_skill_enabled(
        self,
        skill_id: str,
        enabled: bool,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillDefinition:
        """Toggle skill availability."""

    def create_experience_skill(
        self,
        *,
        skill_id: str,
        display_name: str,
        summary: str,
        instruction_text: str,
        category: str | None = None,
        install: bool = True,
        overwrite: bool = False,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> SkillManifestLoadRecord:
        """Write an Aegis-authored experience skill into the shared shelf."""


class McpManagementSurface(Protocol):
    def mcp_catalog(self, *, session_id: str | None = None) -> tuple[McpServerDefinition, ...]:
        """List configured MCP servers."""

    def search_mcp_registry(self, query: str, *, limit: int = 12) -> tuple[McpServerDefinition, ...]:
        """Search installable MCP servers."""

    def inspect_mcp_server(self, server_id: str, *, session_id: str | None = None) -> McpServerDefinition:
        """Inspect one configured MCP server."""

    def inspect_mcp_registry_entry(self, reference: str) -> McpServerDefinition:
        """Inspect one installable MCP registry entry."""

    def install_mcp_server(
        self,
        reference: str,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> McpServerDefinition:
        """Install an MCP server into the active profile."""

    def set_mcp_enabled(
        self,
        server_id: str,
        enabled: bool,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> McpServerDefinition:
        """Toggle MCP availability."""


class GoalManagementSurface(Protocol):
    def inspect_goals(self, session_id: str) -> tuple[GoalNode, ...]:
        """List durable goals for a session."""

    def inspect_goal(self, session_id: str, goal_id: str) -> GoalNode:
        """Inspect one durable goal."""

    def create_goal(
        self,
        session_id: str,
        *,
        title: str,
        status: str = "active",
        priority: str = "medium",
        owner: str = "shared",
        parent_goal_id: str | None = None,
        dependency_refs: Any = None,
        evidence_refs: Any = None,
        related_memory_ids: Any = None,
        review_checkpoint: str | None = None,
        deadline: Any = None,
        time_sensitivity: str | None = None,
        reason: str | None = None,
        activate: bool | None = None,
    ) -> GoalNode:
        """Create a durable goal."""

    def update_goal(
        self,
        session_id: str,
        goal_id: str,
        *,
        title: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        reason: str | None = None,
    ) -> tuple[GoalNode, GoalNode, str]:
        """Update a durable goal."""

    def delete_goal(self, session_id: str, goal_id: str, *, reason: str) -> tuple[GoalNode, GoalNode]:
        """Delete a durable goal."""


class CompanionManagementSurface(Protocol):
    def inspect_companion(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> LoadedProfile:
        """Inspect the active companion state."""

    def update_clone_text(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        clone_text: str | None,
    ) -> LoadedProfile:
        """Persist CLONE.md for the active profile."""

    def update_friend_text(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        friend_text: str | None,
    ) -> LoadedProfile:
        """Persist FRIEND.md for the active profile."""


@dataclass(frozen=True, slots=True)
class BuiltinToolDependencies:
    cwd: Path
    cron_runtime: CronRuntime | None = None
    companion_management: CompanionManagementSurface | None = None
    skill_management: SkillManagementSurface | None = None
    mcp_management: McpManagementSurface | None = None
    goal_management: GoalManagementSurface | None = None
    web_user_agent: str = "Aegis/1.0 (+https://github.com/agentic-in/aegis)"


def register_builtin_tools(
    runtime: ToolRuntime,
    *,
    enabled_overrides: Mapping[str, bool],
    dependencies: BuiltinToolDependencies,
) -> None:
    for definition in builtin_tool_definitions(enabled_overrides):
        runtime.register_tool(definition, handler=_handler_for_tool(definition, dependencies=dependencies))


def builtin_tool_definitions(enabled_overrides: Mapping[str, bool]) -> tuple[ToolDefinition, ...]:
    definitions = (
        ToolDefinition(
            tool_id="tool.shell.command",
            display_name="Shell Command",
            version="1.0.0",
            description="Run a local shell command inside the current workspace when the operator explicitly asks for it.",
            schema={
                "type": "object",
                "required": ["command"],
                "properties": {"command": {"type": "string"}},
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("shell", "workspace"),
                notes="Reserved for explicit operator-directed shell execution.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.workspace.search",
            display_name="Workspace Search",
            version="1.0.0",
            description="Search the current workspace quickly for files or lines that match a query.",
            schema={
                "type": "object",
                "required": ["query"],
                "properties": {"query": {"type": "string"}},
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="low",
                approval_class="standard",
                reads_state=True,
                categories=("search", "workspace"),
                notes="Uses fast local search to surface nearby code and notes.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.web.search",
            display_name="Web Search",
            version="1.0.0",
            description="Search the public web for a query and summarize the top useful results.",
            schema={
                "type": "object",
                "required": ["query"],
                "properties": {
                    "query": {"type": "string"},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 8},
                },
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                categories=("search", "web"),
                notes="Uses a lightweight public search endpoint for fast discovery with direct-result fallback.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.web.fetch",
            display_name="Web Fetch",
            version="1.0.0",
            description="Fetch a specific URL and extract the readable text from that page.",
            schema={
                "type": "object",
                "required": ["url"],
                "properties": {"url": {"type": "string"}},
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                categories=("fetch", "web"),
                notes="Reads a specific public URL and returns a text-first extraction.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.companion.manage",
            display_name="Companion Manager",
            version="1.0.0",
            description=(
                "Inspect or persist the active clone's CLONE.md and FRIEND.md state. "
                "AEGIS.md remains immutable and is only exposed for inspection. "
                "Canonical call shape: action=inspect|set|append|clear with target=clone|friend."
            ),
            schema={
                "type": "object",
                "required": ["action"],
                "properties": {
                    "action": {"type": "string", "enum": ["inspect", "set", "append", "clear"]},
                    "target": {"type": "string", "enum": ["clone", "friend"]},
                    "text": {"type": "string"},
                    "profile_id": {"type": "string"},
                },
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("companion", "identity"),
                notes="Use this to keep clone charter and friend profile durable across turns.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.skill.manage",
            display_name="Skill Manager",
            version="1.0.0",
            description=(
                "Search the shared skill shelf, inspect installed skills, install or toggle skills for this clone, "
                "and materialize experience-promoted skill packages."
            ),
            schema={
                "type": "object",
                "required": ["action"],
                "properties": {
                    "action": {"type": "string"},
                    "query": {"type": "string"},
                    "reference": {"type": "string"},
                    "skill_id": {"type": "string"},
                    "limit": {"type": "integer"},
                    "display_name": {"type": "string"},
                    "summary": {"type": "string"},
                    "instruction_text": {"type": "string"},
                    "category": {"type": "string"},
                    "install": {"type": "boolean"},
                    "overwrite": {"type": "boolean"},
                },
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("skill", "experience"),
                notes="Capability search, install, and shared skill authoring for the active Aegis surface.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.mcp.manage",
            display_name="MCP Manager",
            version="1.0.0",
            description=(
                "Search the MCP registry, inspect configured or installable servers, "
                "install MCP servers for this clone, and toggle configured servers."
            ),
            schema={
                "type": "object",
                "required": ["action"],
                "properties": {
                    "action": {"type": "string"},
                    "query": {"type": "string"},
                    "reference": {"type": "string"},
                    "server_id": {"type": "string"},
                    "limit": {"type": "integer"},
                },
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("mcp", "capability"),
                notes="Registry search, install, inspect, and toggle flow for configured MCP bridges.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.cron.manage",
            display_name="Cron Jobs",
            version="1.0.0",
            description="Create, list, inspect, pause, resume, remove, and run built-in scheduled jobs.",
            schema={
                "type": "object",
                "required": ["action"],
                "properties": {
                    "action": {"type": "string"},
                    "job_id": {"type": "string"},
                    "name": {"type": "string"},
                    "schedule": {"type": "string"},
                    "job_kind": {"type": "string"},
                    "message": {"type": "string"},
                    "query": {"type": "string"},
                    "prompt": {"type": "string"},
                    "profile_id": {"type": "string"},
                    "clone_id": {"type": "string"},
                },
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("cron", "automation"),
                notes="Built-in recurring job management for the active Aegis surface.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.provider.test",
            display_name="Provider Test Probe",
            version="1.0.0",
            description="Run an operator-facing provider probe through the shared runtime.",
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                touches_secrets=True,
                categories=("provider", "network"),
                notes="Used by health and born validation flows.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
            execution={
                "kind": "structured_result",
                "summary_template": "Provider Test Probe remains governed by the shared runtime.",
            },
        ),
        ToolDefinition(
            tool_id="tool.goal.update",
            display_name="Goal Update",
            version="1.0.0",
            description="Inspect, create, focus, update, or delete durable goals and sub-goals inside the current goal graph; use parent_goal_id to attach a child goal.",
            schema={
                "type": "object",
                "properties": {
                    "action": {"type": "string"},
                    "goal_id": {"type": "string"},
                    "title": {"type": "string"},
                    "status": {"type": "string"},
                    "priority": {"type": "string"},
                    "owner": {"type": "string"},
                    "parent_goal_id": {"type": "string"},
                    "dependency_refs": {"type": ["string", "array"]},
                    "evidence_refs": {"type": ["string", "array"]},
                    "related_memory_ids": {"type": ["string", "array"]},
                    "review_checkpoint": {"type": "string"},
                    "deadline": {"type": "string"},
                    "time_sensitivity": {"type": "string"},
                    "reason": {"type": "string"},
                    "activate": {"type": ["boolean", "string"]},
                },
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("goal", "state"),
                notes="Used for inspectable goal edits from the operator path.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
        ),
        ToolDefinition(
            tool_id="tool.memory.correct",
            display_name="Memory Correction",
            version="1.0.0",
            description="Correct an existing durable memory record with lineage preserved.",
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("memory", "correction"),
                notes="Keeps durable corrections explicit and auditable.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
            execution={
                "kind": "structured_result",
                "summary_template": "Memory Correction remains governed by the shared runtime.",
            },
        ),
        ToolDefinition(
            tool_id="tool.memory.delete",
            display_name="Memory Deletion",
            version="1.0.0",
            description="Delete a durable memory record through governed operator flow.",
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("memory", "deletion"),
                notes="Deletion requires explicit operator intent.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
            execution={
                "kind": "structured_result",
                "summary_template": "Memory Deletion remains governed by the shared runtime.",
            },
        ),
    )
    return tuple(
        replace(definition, enabled=enabled_overrides.get(definition.tool_id, definition.enabled))
        for definition in definitions
    )


def _handler_for_tool(definition: ToolDefinition, *, dependencies: BuiltinToolDependencies):
    if definition.tool_id == "tool.shell.command":
        return lambda invocation: _run_shell_command(invocation, cwd=dependencies.cwd)
    if definition.tool_id == "tool.workspace.search":
        return lambda invocation: _run_workspace_search(invocation, cwd=dependencies.cwd)
    if definition.tool_id == "tool.web.search":
        return lambda invocation: _run_web_search(invocation, user_agent=dependencies.web_user_agent)
    if definition.tool_id == "tool.web.fetch":
        return lambda invocation: _run_web_fetch(invocation, user_agent=dependencies.web_user_agent)
    if definition.tool_id == "tool.companion.manage":
        return lambda invocation: _run_companion_action(invocation, surface=dependencies.companion_management)
    if definition.tool_id == "tool.skill.manage":
        return lambda invocation: _run_skill_action(invocation, surface=dependencies.skill_management)
    if definition.tool_id == "tool.mcp.manage":
        return lambda invocation: _run_mcp_action(invocation, surface=dependencies.mcp_management)
    if definition.tool_id == "tool.goal.update":
        return lambda invocation: _run_goal_action(invocation, surface=dependencies.goal_management)
    if definition.tool_id == "tool.cron.manage":
        return lambda invocation: _run_cron_action(invocation, runtime=dependencies.cron_runtime)
    return None


def _run_shell_command(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    command = str(invocation.arguments.get("command") or "").strip()
    if not command:
        raise ValueError("tool.shell.command requires a 'command' argument")
    completed = subprocess.run(
        command,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=20,
    )
    body = "\n".join(part for part in (completed.stdout.strip(), completed.stderr.strip()) if part).strip()
    summary = _truncate(body) or f"command exited with status {completed.returncode}"
    if completed.returncode != 0:
        raise RuntimeError(summary)
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": ("shell", "workspace"),
    }


def _run_workspace_search(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    query = str(invocation.arguments.get("query") or "").strip()
    if not query:
        raise ValueError("tool.workspace.search requires a 'query' argument")
    rg_path = shutil.which("rg")
    if rg_path is None:
        raise RuntimeError("workspace search requires rg to be installed")
    completed = subprocess.run(
        [rg_path, "-n", "--no-heading", "--smart-case", "--max-count", "12", query, str(cwd)],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=20,
    )
    body = completed.stdout.strip() or completed.stderr.strip()
    if completed.returncode not in {0, 1}:
        raise RuntimeError(body or f"workspace search failed with status {completed.returncode}")
    summary = _truncate(body) or f"no workspace matches for query: {query}"
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": ("search", "workspace"),
    }


def _coerce_optional_bool(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    if normalized in {"true", "1", "yes", "on"}:
        return True
    if normalized in {"false", "0", "no", "off"}:
        return False
    return None


def _goal_line(goal: GoalNode) -> str:
    return f"{goal.goal_id} | {goal.status} | {goal.priority} | {goal.title}"


def _goal_exists(surface: GoalManagementSurface, session_id: str, goal_id: str) -> bool:
    try:
        surface.inspect_goal(session_id, goal_id)
    except KeyError:
        return False
    return True


def _run_goal_action(invocation: ToolInvocation, *, surface: GoalManagementSurface | None) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("goal management is not configured for this runtime")
    session_id = invocation.session_id
    requested_action = str(invocation.arguments.get("action") or "").strip().lower()
    title = str(invocation.arguments.get("title") or "").strip()
    goal_id = str(invocation.arguments.get("goal_id") or "").strip()
    parent_goal_id = (
        str(invocation.arguments.get("parent_goal_id"))
        if invocation.arguments.get("parent_goal_id") is not None
        else None
    )
    if requested_action:
        action = requested_action
    elif title and parent_goal_id:
        action = "create"
    elif title and not goal_id:
        action = "create"
    else:
        action = "update"
    if action in {"list", "ls"}:
        goals = surface.inspect_goals(session_id)
        summary = "\n".join(_goal_line(goal) for goal in goals[:12]) or "No durable goals are tracked for this session."
        return {
            "execution_id": invocation.invocation_id,
            "summary": summary,
            "outcome": "success",
            "side_effects": ("goal", "state"),
        }
    if action == "inspect":
        if not goal_id:
            raise ValueError("tool.goal.update inspect requires a 'goal_id' argument")
        goal = surface.inspect_goal(session_id, goal_id)
        return {
            "execution_id": invocation.invocation_id,
            "summary": _goal_line(goal),
            "outcome": "success",
            "side_effects": ("goal", "state"),
        }
    if action == "create":
        if not title:
            raise ValueError("tool.goal.update create requires a 'title' argument")
        resolved_parent_goal_id = parent_goal_id
        if resolved_parent_goal_id is None and goal_id and _goal_exists(surface, session_id, goal_id):
            # Model-generated calls often use goal_id as the parent reference when
            # asking to decompose a goal. Accept that form instead of failing.
            resolved_parent_goal_id = goal_id
        goal = surface.create_goal(
            session_id,
            title=title,
            status=str(invocation.arguments.get("status") or "active"),
            priority=str(invocation.arguments.get("priority") or "medium"),
            owner=str(invocation.arguments.get("owner") or "shared"),
            parent_goal_id=resolved_parent_goal_id,
            dependency_refs=invocation.arguments.get("dependency_refs"),
            evidence_refs=invocation.arguments.get("evidence_refs"),
            related_memory_ids=invocation.arguments.get("related_memory_ids"),
            review_checkpoint=str(invocation.arguments.get("review_checkpoint")) if invocation.arguments.get("review_checkpoint") is not None else None,
            deadline=invocation.arguments.get("deadline"),
            time_sensitivity=str(invocation.arguments.get("time_sensitivity")) if invocation.arguments.get("time_sensitivity") is not None else None,
            reason=str(invocation.arguments.get("reason")) if invocation.arguments.get("reason") is not None else None,
            activate=_coerce_optional_bool(invocation.arguments.get("activate")),
        )
        return {
            "execution_id": invocation.invocation_id,
            "summary": f"Created durable goal: {_goal_line(goal)}",
            "outcome": "success",
            "side_effects": ("goal", "state"),
        }
    if not goal_id:
        raise ValueError("tool.goal.update requires a 'goal_id' argument unless action=create|list")
    if action == "delete":
        before, after = surface.delete_goal(
            session_id,
            goal_id,
            reason=str(invocation.arguments.get("reason") or "tool deleted goal"),
        )
        return {
            "execution_id": invocation.invocation_id,
            "summary": f"Deleted durable goal: {_goal_line(before)} -> {_goal_line(after)}",
            "outcome": "success",
            "side_effects": ("goal", "state"),
        }
    forced_status = {
        "focus": "active",
        "complete": "completed",
        "block": "blocked",
        "defer": "deferred",
    }.get(action)
    before, after, reason = surface.update_goal(
        session_id,
        goal_id,
        title=str(invocation.arguments.get("title")) if invocation.arguments.get("title") is not None else None,
        status=forced_status if forced_status is not None else (str(invocation.arguments.get("status")) if invocation.arguments.get("status") is not None else None),
        priority=str(invocation.arguments.get("priority")) if invocation.arguments.get("priority") is not None else None,
        reason=str(invocation.arguments.get("reason")) if invocation.arguments.get("reason") is not None else None,
    )
    return {
        "execution_id": invocation.invocation_id,
        "summary": f"{reason}: {_goal_line(before)} -> {_goal_line(after)}",
        "outcome": "success",
        "side_effects": ("goal", "state"),
    }


def _run_web_search(invocation: ToolInvocation, *, user_agent: str) -> Mapping[str, Any]:
    query = str(invocation.arguments.get("query") or "").strip()
    if not query:
        raise ValueError("tool.web.search requires a 'query' argument")
    limit = max(1, min(_coerce_int(invocation.arguments.get("limit"), default=5), 8))
    search_error: Exception | None = None
    try:
        results = _run_duckduckgo_html_search(query, user_agent=user_agent, limit=limit)
    except Exception as error:  # pragma: no cover - exercised through fallback behavior
        search_error = error
        results = ()
    if results:
        return _tool_summary(
            invocation,
            _format_web_search_summary(query=query, results=results),
            side_effects=("search", "web"),
        )
    try:
        fallback_lines = _run_duckduckgo_instant_answer(query, user_agent=user_agent, limit=limit)
    except Exception as error:
        if search_error is not None:
            raise RuntimeError(f"web search failed after HTML and fallback attempts: {search_error}; {error}") from error
        raise
    if search_error is not None and not fallback_lines:
        raise RuntimeError(f"web search failed: {search_error}") from search_error
    summary_lines = [f"search: {query}", *fallback_lines] if fallback_lines else [f"no web results for query: {query}"]
    return _tool_summary(
        invocation,
        _truncate("\n".join(summary_lines), limit=1600),
        side_effects=("search", "web"),
    )


def _run_web_fetch(invocation: ToolInvocation, *, user_agent: str) -> Mapping[str, Any]:
    raw_url = str(invocation.arguments.get("url") or "").strip()
    url = _normalized_url(raw_url)
    if url is None:
        raise ValueError("tool.web.fetch requires a valid 'url' argument")
    request = Request(
        url,
        headers={
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml,text/plain,application/json;q=0.9,*/*;q=0.8",
        },
    )
    with urlopen(request, timeout=20) as response:  # noqa: S310
        payload = response.read(350_000)
        content_type = response.headers.get_content_type()
        charset = response.headers.get_content_charset() or "utf-8"
        resolved_url = response.geturl()
    title, excerpt = _extract_web_text(payload, content_type=content_type, charset=charset)
    lines: list[str] = []
    if title:
        lines.append(title)
    if excerpt:
        lines.append(excerpt)
    lines.append(f"source: {resolved_url}")
    summary = _truncate("\n".join(lines), limit=1600)
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": ("fetch", "web"),
    }


@dataclass(frozen=True, slots=True)
class _WebSearchResult:
    title: str
    url: str
    snippet: str = ""


def _run_duckduckgo_html_search(
    query: str,
    *,
    user_agent: str,
    limit: int,
) -> tuple[_WebSearchResult, ...]:
    request = Request(
        f"https://html.duckduckgo.com/html/?q={quote_plus(query)}",
        headers={
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml",
        },
    )
    with urlopen(request, timeout=20) as response:  # noqa: S310
        payload = response.read().decode("utf-8", errors="replace")
    parser = _DuckDuckGoSearchResultsParser(limit=limit)
    parser.feed(payload)
    parser.close()
    return parser.results


def _run_duckduckgo_instant_answer(
    query: str,
    *,
    user_agent: str,
    limit: int,
) -> tuple[str, ...]:
    request = Request(
        f"https://api.duckduckgo.com/?q={quote_plus(query)}&format=json&no_html=1&skip_disambig=1",
        headers={"User-Agent": user_agent},
    )
    with urlopen(request, timeout=20) as response:  # noqa: S310
        payload = json.loads(response.read().decode("utf-8"))
    lines: list[str] = []
    abstract = str(payload.get("AbstractText") or "").strip()
    abstract_url = str(payload.get("AbstractURL") or "").strip()
    if abstract:
        lines.append(abstract if not abstract_url else f"{abstract} ({abstract_url})")
    answer = str(payload.get("Answer") or "").strip()
    if answer and answer not in lines:
        lines.append(answer)
    related = payload.get("RelatedTopics")
    if isinstance(related, list):
        for item in _iter_duckduckgo_related_topics(related):
            text = str(item.get("Text") or "").strip()
            url = str(item.get("FirstURL") or "").strip()
            if text:
                lines.append(text if not url else f"{text} ({url})")
            if len(lines) >= max(3, limit):
                break
    return tuple(lines)


def _iter_duckduckgo_related_topics(topics: list[Any]) -> tuple[Mapping[str, Any], ...]:
    flattened: list[Mapping[str, Any]] = []
    for item in topics:
        if not isinstance(item, Mapping):
            continue
        nested = item.get("Topics")
        if isinstance(nested, list):
            flattened.extend(_iter_duckduckgo_related_topics(nested))
            continue
        flattened.append(item)
    return tuple(flattened)


def _format_web_search_summary(
    *,
    query: str,
    results: tuple[_WebSearchResult, ...],
) -> str:
    lines = [f"search: {query}"]
    for index, result in enumerate(results, start=1):
        lines.append(f"{index}. {result.title}")
        lines.append(f"   {result.url}")
        if result.snippet:
            lines.append(f"   {result.snippet}")
    return _truncate("\n".join(lines), limit=1600)


def _unwrap_duckduckgo_result_url(raw_url: str | None) -> str | None:
    candidate = _optional_string(raw_url)
    if candidate is None:
        return None
    if candidate.startswith("//"):
        candidate = f"https:{candidate}"
    elif candidate.startswith("/"):
        candidate = urljoin("https://duckduckgo.com", candidate)
    parsed = urlparse(candidate)
    if parsed.netloc.endswith("duckduckgo.com") and parsed.path.startswith("/l/"):
        redirect = parse_qs(parsed.query).get("uddg", ())
        if redirect:
            return _normalized_url(redirect[0])
    return _normalized_url(candidate)


def _run_companion_action(
    invocation: ToolInvocation,
    *,
    surface: CompanionManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("tool.companion.manage is not wired on this Aegis surface")
    action, target = normalize_companion_request(
        action=invocation.arguments.get("action"),
        target=invocation.arguments.get("target"),
    )
    profile_id = _optional_string(invocation.arguments.get("profile_id"))
    if action in {"inspect", "show"}:
        if target in {"clone", "friend"}:
            return _tool_summary(
                invocation,
                _inspect_companion_target(
                    surface,
                    session_id=invocation.session_id,
                    profile_id=profile_id,
                    target=target,
                ),
                side_effects=("companion", target),
            )
        profile = surface.inspect_companion(session_id=invocation.session_id, profile_id=profile_id)
        clone_text = profile.clone_text or profile.soul_text or "<empty>"
        friend_text = profile.friend_text or "<empty>"
        return _tool_summary(
            invocation,
            "\n".join(
                [
                    f"profile_id: {profile.state.profile_id}",
                    f"display_name: {profile.state.display_name}",
                    f"aegis_path: {profile.aegis_path or '<packaged>'}",
                    "aegis_editable: false",
                    f"clone_path: {profile.state.soul_path or '<none>'}",
                    f"clone_text: {clone_text}",
                    f"friend_path: {profile.friend_path or '<none>'}",
                    f"friend_text: {friend_text}",
                ]
            ),
            side_effects=("companion",),
        )

    if target not in {"clone", "friend"}:
        raise ValueError(
            "tool.companion.manage requires target=clone or target=friend; "
            "canonical call shape is action=inspect|set|append|clear with target=clone|friend"
        )
    if action in {"set", "write"}:
        text = _optional_string(invocation.arguments.get("text"))
        if text is None:
            return _tool_summary(
                invocation,
                _inspect_companion_target(
                    surface,
                    session_id=invocation.session_id,
                    profile_id=profile_id,
                    target=target,
                ),
                side_effects=("companion", target),
            )
        return _tool_summary(
            invocation,
            _write_companion_target(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                target=target,
                text=text,
            ),
            side_effects=("companion", target),
        )
    if action == "append":
        text = _optional_string(invocation.arguments.get("text"))
        if text is None:
            return _tool_summary(
                invocation,
                _inspect_companion_target(
                    surface,
                    session_id=invocation.session_id,
                    profile_id=profile_id,
                    target=target,
                ),
                side_effects=("companion", target),
            )
        profile = surface.inspect_companion(session_id=invocation.session_id, profile_id=profile_id)
        existing = (
            profile.clone_text or profile.soul_text
            if target == "clone"
            else profile.friend_text
        )
        merged = text if not _optional_string(existing) else f"{str(existing).rstrip()}\n\n{text}"
        return _tool_summary(
            invocation,
            _write_companion_target(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                target=target,
                text=merged,
            ),
            side_effects=("companion", target),
        )
    if action == "clear":
        return _tool_summary(
            invocation,
            _write_companion_target(
                surface,
                session_id=invocation.session_id,
                profile_id=profile_id,
                target=target,
                text=None,
            ),
            side_effects=("companion", target),
        )
    raise ValueError(
        f"tool.companion.manage does not support action={action!r}; "
        "canonical actions are inspect|set|append|clear"
    )


def normalize_companion_request(*, action: Any, target: Any) -> tuple[str, str]:
    normalized_action = str(action or "").strip().lower() or "inspect"
    normalized_target = _normalize_companion_target(target)

    alias_map = {
        "inspect_friend": ("inspect", "friend"),
        "show_friend": ("inspect", "friend"),
        "read_friend": ("inspect", "friend"),
        "get_friend": ("inspect", "friend"),
        "update_friend": ("set", "friend"),
        "set_friend": ("set", "friend"),
        "write_friend": ("set", "friend"),
        "append_friend": ("append", "friend"),
        "add_friend": ("append", "friend"),
        "clear_friend": ("clear", "friend"),
        "reset_friend": ("clear", "friend"),
        "inspect_clone": ("inspect", "clone"),
        "show_clone": ("inspect", "clone"),
        "read_clone": ("inspect", "clone"),
        "get_clone": ("inspect", "clone"),
        "update_clone": ("set", "clone"),
        "set_clone": ("set", "clone"),
        "write_clone": ("set", "clone"),
        "append_clone": ("append", "clone"),
        "add_clone": ("append", "clone"),
        "clear_clone": ("clear", "clone"),
        "reset_clone": ("clear", "clone"),
    }
    if normalized_action in alias_map:
        canonical_action, inferred_target = alias_map[normalized_action]
        return canonical_action, normalized_target or inferred_target

    if normalized_action in {"show", "read", "get"}:
        normalized_action = "inspect"
    elif normalized_action in {"write", "update"}:
        normalized_action = "set"
    elif normalized_action in {"add"}:
        normalized_action = "append"
    elif normalized_action in {"delete", "drop", "reset"}:
        normalized_action = "clear"
    return normalized_action, normalized_target


def _normalize_companion_target(value: Any) -> str:
    normalized = str(value or "").strip().lower()
    if normalized in {"friend", "friend.md", "friend_profile", "friend-profile", "friend profile"}:
        return "friend"
    if normalized in {"clone", "clone.md", "clone_charter", "clone-charter", "clone charter", "soul"}:
        return "clone"
    return normalized


def _write_companion_target(
    surface: CompanionManagementSurface,
    *,
    session_id: str | None,
    profile_id: str | None,
    target: str,
    text: str | None,
) -> str:
    if target == "clone":
        updated = surface.update_clone_text(
            session_id=session_id,
            profile_id=profile_id,
            clone_text=text,
        )
        return "\n".join(
            [
                f"profile_id: {updated.state.profile_id}",
                f"target: {target}",
                f"clone_text: {updated.clone_text or updated.soul_text or '<empty>'}",
            ]
        )
    updated = surface.update_friend_text(
        session_id=session_id,
        profile_id=profile_id,
        friend_text=text,
    )
    return "\n".join(
        [
            f"profile_id: {updated.state.profile_id}",
            f"target: {target}",
            f"friend_text: {updated.friend_text or '<empty>'}",
        ]
    )


def _inspect_companion_target(
    surface: CompanionManagementSurface,
    *,
    session_id: str | None,
    profile_id: str | None,
    target: str,
) -> str:
    profile = surface.inspect_companion(session_id=session_id, profile_id=profile_id)
    if target == "clone":
        return "\n".join(
            [
                f"profile_id: {profile.state.profile_id}",
                f"target: {target}",
                f"clone_text: {profile.clone_text or profile.soul_text or '<empty>'}",
            ]
        )
    return "\n".join(
        [
            f"profile_id: {profile.state.profile_id}",
            f"target: {target}",
            f"friend_text: {profile.friend_text or '<empty>'}",
        ]
    )


def _run_skill_action(
    invocation: ToolInvocation,
    *,
    surface: SkillManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("tool.skill.manage is not wired on this Aegis surface")
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.skill.manage requires an 'action' argument")
    if action in {"list", "ls"}:
        skills = surface.skill_catalog(session_id=invocation.session_id)
        lines = [
            f"{skill.skill_id} | enabled={skill.enabled} | {skill.display_name} | {skill.summary}"
            for skill in skills
        ] or ["<empty>"]
        return _tool_summary(invocation, "\n".join(lines))
    if action == "search":
        query = str(invocation.arguments.get("query") or "").strip()
        if not query:
            raise ValueError("tool.skill.manage search requires a 'query' argument")
        limit = _coerce_int(invocation.arguments.get("limit"), default=12)
        matches = surface.search_skill_hub(query, limit=limit)
        lines = [
            f"{entry.reference} | {entry.display_name} | {entry.summary} | source={entry.source_label}"
            for entry in matches
        ] or ["<empty>"]
        return _tool_summary(invocation, "\n".join(lines))
    if action == "inspect":
        skill_id = str(invocation.arguments.get("skill_id") or invocation.arguments.get("reference") or "").strip()
        if not skill_id:
            raise ValueError("tool.skill.manage inspect requires 'skill_id'")
        skill = surface.inspect_skill(skill_id, session_id=invocation.session_id)
        return _tool_summary(
            invocation,
            "\n".join(
                [
                    f"skill_id: {skill.skill_id}",
                    f"display_name: {skill.display_name}",
                    f"enabled: {skill.enabled}",
                    f"version: {skill.version}",
                    f"summary: {skill.summary}",
                    f"provenance: {skill.provenance or 'built-in'}",
                ]
            ),
        )
    if action == "install":
        reference = str(invocation.arguments.get("reference") or invocation.arguments.get("skill_id") or "").strip()
        if not reference:
            raise ValueError("tool.skill.manage install requires 'reference'")
        record = surface.install_skill_source(reference, session_id=invocation.session_id)
        return _tool_summary(
            invocation,
            "\n".join(
                [
                    f"source_path: {record.source_path}",
                    f"skill_ids: {', '.join(record.skill_ids) or '<empty>'}",
                ]
            ),
            side_effects=("skill", "install"),
        )
    if action in {"enable", "disable"}:
        skill_id = str(invocation.arguments.get("skill_id") or "").strip()
        if not skill_id:
            raise ValueError(f"tool.skill.manage {action} requires 'skill_id'")
        updated = surface.set_skill_enabled(skill_id, action == "enable", session_id=invocation.session_id)
        return _tool_summary(
            invocation,
            f"{updated.skill_id}\nenabled: {updated.enabled}",
            side_effects=("skill", "toggle"),
        )
    if action == "create":
        skill_id = str(invocation.arguments.get("skill_id") or "").strip()
        display_name = str(invocation.arguments.get("display_name") or "").strip()
        summary = str(invocation.arguments.get("summary") or "").strip()
        instruction_text = str(invocation.arguments.get("instruction_text") or "").strip()
        if not skill_id or not display_name or not summary or not instruction_text:
            raise ValueError(
                "tool.skill.manage create requires 'skill_id', 'display_name', 'summary', and 'instruction_text'"
            )
        record = surface.create_experience_skill(
            skill_id=skill_id,
            display_name=display_name,
            summary=summary,
            instruction_text=instruction_text,
            category=str(invocation.arguments.get("category") or "").strip() or None,
            install=_coerce_bool(invocation.arguments.get("install"), default=True),
            overwrite=_coerce_bool(invocation.arguments.get("overwrite"), default=False),
            session_id=invocation.session_id,
        )
        return _tool_summary(
            invocation,
            "\n".join(
                [
                    f"source_path: {record.source_path}",
                    f"skill_ids: {', '.join(record.skill_ids) or '<empty>'}",
                ]
            ),
            side_effects=("skill", "experience"),
        )
    raise ValueError(f"tool.skill.manage does not support action={action!r}")


def _run_mcp_action(
    invocation: ToolInvocation,
    *,
    surface: McpManagementSurface | None,
) -> Mapping[str, Any]:
    if surface is None:
        raise RuntimeError("tool.mcp.manage is not wired on this Aegis surface")
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.mcp.manage requires an 'action' argument")
    if action in {"list", "ls"}:
        servers = surface.mcp_catalog(session_id=invocation.session_id)
        lines = [
            (
                f"{server.server_id} | enabled={server.enabled} | {server.display_name} | "
                f"{server.summary} | source={_mcp_source_label(server)}"
            )
            for server in servers
        ] or ["<empty>"]
        return _tool_summary(invocation, "\n".join(lines), side_effects=("mcp",))
    if action == "search":
        query = str(invocation.arguments.get("query") or "").strip()
        if not query:
            raise ValueError("tool.mcp.manage search requires a 'query' argument")
        limit = _coerce_int(invocation.arguments.get("limit"), default=12)
        matches = surface.search_mcp_registry(query, limit=limit)
        lines = [
            f"{server.server_id} | {server.display_name} | {server.summary} | source={_mcp_source_label(server)}"
            for server in matches
        ] or ["<empty>"]
        return _tool_summary(invocation, "\n".join(lines), side_effects=("mcp",))
    if action == "inspect":
        reference = str(invocation.arguments.get("server_id") or invocation.arguments.get("reference") or "").strip()
        if not reference:
            raise ValueError("tool.mcp.manage inspect requires 'server_id'")
        try:
            server = surface.inspect_mcp_server(reference, session_id=invocation.session_id)
        except KeyError:
            server = surface.inspect_mcp_registry_entry(reference)
        return _tool_summary(
            invocation,
            "\n".join(
                [
                    f"server_id: {server.server_id}",
                    f"display_name: {server.display_name}",
                    f"enabled: {server.enabled}",
                    f"transport: {server.transport}",
                    f"command: {server.command or '<none>'}",
                    f"args: {' '.join(server.args) or '<none>'}",
                    f"url: {server.url or '<none>'}",
                    f"provenance: {server.provenance or '<none>'}",
                    f"source: {_mcp_source_label(server)}",
                ]
            ),
            side_effects=("mcp",),
        )
    if action == "install":
        reference = str(invocation.arguments.get("reference") or invocation.arguments.get("server_id") or "").strip()
        if not reference:
            raise ValueError("tool.mcp.manage install requires 'reference'")
        server = surface.install_mcp_server(reference, session_id=invocation.session_id)
        return _tool_summary(
            invocation,
            "\n".join(
                [
                    f"server_id: {server.server_id}",
                    f"display_name: {server.display_name}",
                    f"transport: {server.transport}",
                    f"enabled: {server.enabled}",
                    f"source: {_mcp_source_label(server)}",
                ]
            ),
            side_effects=("mcp", "install"),
        )
    if action in {"enable", "disable"}:
        server_id = str(invocation.arguments.get("server_id") or invocation.arguments.get("reference") or "").strip()
        if not server_id:
            raise ValueError(f"tool.mcp.manage {action} requires 'server_id'")
        updated = surface.set_mcp_enabled(server_id, action == "enable", session_id=invocation.session_id)
        return _tool_summary(
            invocation,
            f"{updated.server_id}\nenabled: {updated.enabled}",
            side_effects=("mcp", "toggle"),
        )
    raise ValueError(f"tool.mcp.manage does not support action={action!r}")


def _run_cron_action(invocation: ToolInvocation, *, runtime: CronRuntime | None) -> ExecutionResult:
    if runtime is None:
        raise RuntimeError("cron runtime is not configured")
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.cron.manage requires an 'action' argument")
    if action == "list":
        jobs = runtime.list_jobs(
            profile_id=_optional_string(invocation.arguments.get("profile_id")),
            clone_id=_optional_string(invocation.arguments.get("clone_id")),
        )
        summary = "\n".join(
            f"{job.job_id} | {job.status} | {job.name} | {job.schedule_text} | {job.action_kind}"
            for job in jobs
        ) or "<empty>"
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=summary,
            side_effects=("cron", "automation"),
        )
    if action == "create":
        name = _optional_string(invocation.arguments.get("name")) or "Aegis job"
        schedule = _optional_string(invocation.arguments.get("schedule"))
        job_kind = _optional_string(invocation.arguments.get("job_kind"))
        if not schedule or not job_kind:
            raise ValueError("cron create requires 'schedule' and 'job_kind'")
        payload = {
            key: value
            for key, value in (
                ("message", _optional_string(invocation.arguments.get("message"))),
                ("query", _optional_string(invocation.arguments.get("query"))),
                ("prompt", _optional_string(invocation.arguments.get("prompt"))),
            )
            if value is not None
        }
        job = runtime.create_job(
            name=name,
            schedule_text=schedule,
            action_kind=job_kind,
            payload=payload,
            profile_id=_optional_string(invocation.arguments.get("profile_id")),
            clone_id=_optional_string(invocation.arguments.get("clone_id")),
        )
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=(
                f"created {job.job_id}\n"
                f"name: {job.name}\n"
                f"schedule: {job.schedule_text}\n"
                f"job_kind: {job.action_kind}\n"
                f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}"
            ),
            side_effects=("cron", "automation"),
        )
    job_id = _optional_string(invocation.arguments.get("job_id"))
    if not job_id:
        raise ValueError(f"cron action '{action}' requires 'job_id'")
    if action == "inspect":
        job = runtime.inspect_job(job_id)
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=(
                f"{job.job_id}\n"
                f"name: {job.name}\n"
                f"status: {job.status}\n"
                f"schedule: {job.schedule_text}\n"
                f"job_kind: {job.action_kind}\n"
                f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}\n"
                f"last_summary: {job.last_summary or '<none>'}"
            ),
            side_effects=("cron", "automation"),
        )
    if action == "pause":
        job = runtime.pause_job(job_id)
        summary = f"{job.job_id}\nstatus: {job.status}"
    elif action == "resume":
        job = runtime.resume_job(job_id)
        summary = f"{job.job_id}\nstatus: {job.status}\nnext_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}"
    elif action == "remove":
        job = runtime.remove_job(job_id)
        summary = f"{job.job_id}\nstatus: removed"
    else:
        raise ValueError(f"unsupported cron action: {action}")
    return ExecutionResult(
        execution_id=invocation.invocation_id,
        session_id=invocation.session_id,
        outcome="success",
        summary=summary,
        side_effects=("cron", "automation"),
    )


def _tool_summary(
    invocation: ToolInvocation,
    summary: str,
    *,
    side_effects: tuple[str, ...] = ("skill",),
) -> Mapping[str, Any]:
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": side_effects,
    }


def _coerce_bool(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _coerce_int(value: Any, *, default: int) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _mcp_source_label(definition: McpServerDefinition) -> str:
    metadata = definition.metadata if isinstance(definition.metadata, Mapping) else {}
    source_label = metadata.get("source_label")
    if source_label:
        return str(source_label)
    if definition.provenance:
        return definition.provenance
    return "builtin-registry"


def _optional_string(value: Any) -> str | None:
    if value is None:
        return None
    resolved = str(value).strip()
    return resolved or None


def _truncate(value: str, *, limit: int = 1200) -> str:
    compact = value.strip()
    if len(compact) <= limit:
        return compact
    return compact[: max(0, limit - 1)].rstrip() + "…"


def _normalized_url(value: str) -> str | None:
    candidate = value.strip().strip("\"'")
    if not candidate:
        return None
    parsed = urlparse(candidate)
    if not parsed.scheme:
        candidate = f"https://{candidate}"
        parsed = urlparse(candidate)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    return candidate


def _extract_web_text(payload: bytes, *, content_type: str, charset: str) -> tuple[str, str]:
    decoded = payload.decode(charset, errors="replace")
    if content_type in {"text/html", "application/xhtml+xml"} or content_type.endswith("+html"):
        parser = _HTMLTextExtractor()
        parser.feed(decoded)
        parser.close()
        return parser.title, _truncate(parser.text, limit=1400)
    return "", _truncate(_compact_text(decoded), limit=1400)


def _compact_text(value: str) -> str:
    return " ".join(unescape(value).split())


class _DuckDuckGoSearchResultsParser(HTMLParser):
    def __init__(self, *, limit: int) -> None:
        super().__init__()
        self._limit = limit
        self._results: list[_WebSearchResult] = []
        self._current_url: str | None = None
        self._current_title_parts: list[str] = []
        self._current_snippet_parts: list[str] = []
        self._capture_title = False
        self._capture_snippet = False
        self._snippet_depth = 0

    @property
    def results(self) -> tuple[_WebSearchResult, ...]:
        return tuple(self._results[: self._limit])

    def close(self) -> None:
        self._flush_current()
        super().close()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if len(self._results) >= self._limit:
            return
        attr_map = {key: value or "" for key, value in attrs}
        classes = {part for part in attr_map.get("class", "").split() if part}
        if tag == "a" and {"result__a", "result-link"} & classes:
            self._flush_current()
            resolved_url = _unwrap_duckduckgo_result_url(attr_map.get("href"))
            if resolved_url is None:
                return
            self._current_url = resolved_url
            self._current_title_parts = []
            self._current_snippet_parts = []
            self._capture_title = True
            self._capture_snippet = False
            self._snippet_depth = 0
            return
        if self._capture_snippet:
            self._snippet_depth += 1
            return
        if self._current_url is not None and {"result__snippet", "result-snippet"} & classes:
            self._capture_snippet = True
            self._snippet_depth = 1

    def handle_endtag(self, tag: str) -> None:
        if self._capture_title and tag == "a":
            self._capture_title = False
            return
        if self._capture_snippet:
            self._snippet_depth -= 1
            if self._snippet_depth <= 0:
                self._capture_snippet = False
                self._snippet_depth = 0

    def handle_data(self, data: str) -> None:
        text = _compact_text(data)
        if not text or self._current_url is None:
            return
        if self._capture_title:
            self._current_title_parts.append(text)
        elif self._capture_snippet:
            self._current_snippet_parts.append(text)

    def _flush_current(self) -> None:
        if self._current_url is None:
            return
        title = " ".join(self._current_title_parts).strip()
        snippet = " ".join(self._current_snippet_parts).strip()
        if title and all(existing.url != self._current_url for existing in self._results):
            self._results.append(_WebSearchResult(title=title, url=self._current_url, snippet=snippet))
        self._current_url = None
        self._current_title_parts = []
        self._current_snippet_parts = []
        self._capture_title = False
        self._capture_snippet = False
        self._snippet_depth = 0


class _HTMLTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._blocked_depth = 0
        self._in_title = False
        self._title_parts: list[str] = []
        self._text_parts: list[str] = []

    @property
    def title(self) -> str:
        return " ".join(self._title_parts).strip()

    @property
    def text(self) -> str:
        return " ".join(self._text_parts).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript"}:
            self._blocked_depth += 1
            return
        if tag == "title":
            self._in_title = True

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript"} and self._blocked_depth > 0:
            self._blocked_depth -= 1
            return
        if tag == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._blocked_depth > 0:
            return
        text = _compact_text(data)
        if not text:
            return
        if self._in_title:
            self._title_parts.append(text)
        else:
            self._text_parts.append(text)
