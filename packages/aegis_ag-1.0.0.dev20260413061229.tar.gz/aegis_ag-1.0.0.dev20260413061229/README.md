<p align="center">
  <img src="apps/site/static/assets/brand/evolution-stage-1.svg" alt="Aegis growth stage 1" width="54" />
  <img src="apps/site/static/assets/brand/evolution-stage-2.svg" alt="Aegis growth stage 2" width="72" />
  <img src="apps/site/static/assets/brand/evolution-stage-3.svg" alt="Aegis growth stage 3" width="90" />
  <img src="apps/site/static/assets/brand/aegis-logo.png" alt="Aegis growth stage 4" width="108" />
</p>

<h1 align="center">Aegis</h1>

<p align="center">
  <strong>Your own persistent AI.</strong><br />
  An agent that remembers, reasons, and endures across time.
</p>

Aegis is building toward a personal AI agent that does not lose the thread when
a single chat ends. The goal is not just tool calling or session orchestration,
but continuity: an agent that becomes more useful as it accumulates the right
history, goals, and context.

## Positioning

Aegis is for long-running work that should survive interruption.

- It should remember what matters.
- It should reason across longer horizons than the current turn.
- It should recover the right context instead of collapsing when the window fills.

In product terms, Aegis is aiming at a persistent personal AI, not a disposable
chat session.

## Why Aegis Exists

Most current agents fail in three predictable ways:

- **Amnesia:** decisions, preferences, and project state disappear when the session ends.
- **Myopia:** current-turn optimization wins over next-week usefulness.
- **Overflow:** context windows fill up, and naive truncation replaces structured memory and retrieval.

The product thesis behind Aegis is that a useful agent should behave more like a
persistent collaborator: it should remember, plan, and recover the right
context when work resumes.

## Thesis

- **Long-term memory:** durable episodic, semantic, and procedural memory instead of session-only state.
- **Long-horizon decision making:** persistent goals, task decomposition, and deadline-aware planning.
- **Long-context understanding:** layered context management, compression, and retrieval instead of naive truncation.

## Quickstart

Aegis is used from the terminal. The path is simple: install it, run `aegis`,
let it hatch your first named clone, and continue directly into grow. Use
`aegis clone <name>` only when you want another Aegis individual.

### Install from remote

```bash
curl -fsSL https://aegis.agentic-in.ai/install.sh | bash
```

This installs the public `aegis` launcher into `~/.local/bin` and prepares the
default durable runtime under `~/.local/share/aegis`. The public installer now
tracks the latest published development package by default. If you want the
latest stable package instead:

```bash
curl -fsSL https://aegis.agentic-in.ai/install.sh | bash -s -- --channel stable
```

### Install from source

```bash
git clone https://github.com/agentic-in/aegis.git
cd aegis
bash scripts/install.sh
```

This creates a local launcher and the default durable layout:

- `AEGIS_HOME`
- `AEGIS_STATE_DIR`
- `AEGIS_PROFILE_DIR`

If `~/.local/bin` is not already on `PATH`, use the launcher path printed by the
install script directly.

### CLI overview

```bash
aegis
aegis born
aegis grow
aegis clone nova
aegis clones
aegis health
aegis grow --message "Who are you?"
```

The CLI surface stays intentionally small:

- `aegis` is the default entry: on the first run it starts birth, and later it re-enters grow directly or asks which clone to open.
- `aegis born` brings the first Aegis to life, persists identity and `CLONE.md`, binds the provider path, asks for the first durable goal, hatches the first clone, and in interactive use hands off straight into grow.
- `aegis grow` is the normal way back in and enters the current live clone directly when one exists.
- `aegis grow --message "..."` runs a single turn without staying in the TUI.
- `aegis health` checks whether the current companion is ready to grow.
- `aegis clone <name>` creates another named Aegis individual only when you want a second continuity line, and can seed its first durable goal with `--initial-goal`.
- `aegis clones` lists known clones.
- `aegis clones bye <name>` retires one clone.
- `aegis clones bye --all` clears every clone.
- `aegis grow --clone-id <name>` opens one clone directly.

Inside `grow`, the conversation stays primary. Slash commands such as `/status`,
`/memory`, `/goals`, `/identity`, and `/help` are there when you need to inspect
or steer continuity without leaving the session.

## Shipped Capability Overview

Aegis already ships these core runtime surfaces on `main`:

- Durable memory, planning, and context recovery backing the normal `grow` path.
- Persistent clones with isolated continuity, personality, and `CLONE.md`.
- Provider onboarding and a pluggable catalog covering `openai-compatible`, `openai`, `openrouter`, `anthropic`, `google`, `groq`, `deepseek`, `xai`, `mistral`, `together`, `fireworks`, `moonshot`, `minimax`, `ollama`, and `vllm`.
- Built-in tools for shell execution, workspace search, web search, direct web fetch, and cron management.
- Built-in skills for shell, workspace search, web search/read, continuity, cron scheduling, and voice reply guidance.
- Local skill-hub search/install plus MCP discovery/install for servers such as Fetch, Filesystem, GitHub, Playwright, and Brave Search.
- Durable agent-run checkpoints for resumable multi-step tool loops and long-horizon follow-up.

The public docs now cover the supported operator path plus the currently shipped
provider, capability, automation, and extension surfaces. Internal design docs
under `docs/system-design/` still describe the broader target architecture.
