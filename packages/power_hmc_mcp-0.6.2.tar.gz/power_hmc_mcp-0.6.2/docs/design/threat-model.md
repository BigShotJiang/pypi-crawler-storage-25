# Threat model and RBAC matrix (Phase C prerequisite)

Status: **Draft** — must be reviewed before the first real `POST` lands in
Phase C. Formal external review remains a Phase H deliverable.
Last updated: 2026-05-18.

This document was reprioritized from Phase H to a Phase C prerequisite because
**you cannot responsibly ship real write execution against production Power
Systems infrastructure without a documented threat model**. Phase H scope is
narrowed to external review and supply-chain hardening
([`TODO.md` Phase H](../../TODO.md#phase-h--security--compliance)).

Scope mirrors [`SECURITY.md`](../../SECURITY.md): we cover the server, its
transport, and its handling of HMC sessions and capability tokens. IBM HMC
firmware vulnerabilities, physical access, and DR/replication are out of scope.

## Trust boundaries

```mermaid
flowchart LR
    Agent[Agent / LLM client] -->|stdio or streamable HTTP| Server[power-hmc-mcp server]
    Server -->|HTTPS + X-API-Session token| HMC[IBM HMC REST]
    Server -->|JSON / structured logs| Sink[Log sink / SIEM]
    Env[(.env / secret store)] -->|HMC_USERNAME, HMC_PASSWORD| Server
    Fixtures[(demo_fixtures/)] -->|HMC_DEMO_MODE=true| Server
```

Boundaries, in order of trust gradient:

| Boundary | Trust direction | Today's enforcement |
|----------|-----------------|---------------------|
| Agent ↔ Server (stdio) | Server treats agent input as **untrusted** | Tool schemas validate types; `WriteAuthorization` token gates mutations |
| Agent ↔ Server (streamable HTTP) | Same as stdio, plus network exposure | Reverse-proxy + mTLS recommended in [`docs/transports.md`](../transports.md); session affinity unresolved (see [`TODO.md` Phase D](../../TODO.md#phase-d--transport--deployment)) |
| Server ↔ HMC | HMC is **authoritative** for partition state | TLS verification on by default (`HMC_VERIFY_TLS=true`); managed-system allowlist (`HMC_ALLOWED_MANAGED_SYSTEMS`); session token redacted in logs |
| Server ↔ Log sink | One-way; logs treated as eventually-public | `RedactingFilter` removes passwords and `X-API-Session` tokens before emission |
| Filesystem ↔ Server (`.env`) | Filesystem is trusted at startup | `.env` documented as 600 / vault-backed in [`docs/operations.md`](../operations.md); no runtime re-read |

See [`docs/architecture.md` write-safety-model](../architecture.md#write-safety-model)
for the request-flow diagrams that show where each boundary is crossed.

## Attacker personas

| # | Persona | Capability | Primary risk |
|---|---------|------------|--------------|
| 1 | Malicious agent (prompt-injected LLM) | Can call any registered MCP tool with arbitrary parameters | Triggering destructive writes via persuasive natural-language instructions |
| 2 | Over-eager LLM (no malice) | Same surface as #1, but no intent | Calling write tools because the prompt sounded urgent; idempotency races |
| 3 | Lateral attacker on the same host | Can read process memory, files, and env vars | Exfiltrating `HMC_PASSWORD`, in-memory session token, or `.env` |
| 4 | Insider operator | Has legitimate HMC credentials | Escalating beyond their HMC role (running `stop_lpar` on systems they should only read) |
| 5 | Compromised log sink | Read-only access to structured logs | Reconstructing session tokens or passwords from log replay |
| 6 | Network-on-path (HTTP transport only) | TCP between agent and server | Tool-call injection, response tampering |

## Asset matrix

| Asset | Location | Sensitivity | Existing protection |
|-------|----------|-------------|---------------------|
| HMC username | `Settings.hmc_username` | Medium | Not redacted (not a secret) but `extra="ignore"` on `Settings` blocks env-var sprawl |
| HMC password | `Settings.hmc_password` (`SecretStr`) | High | `SecretStr` prevents accidental `repr`; `RedactingFilter` substring-redacts in all log records |
| HMC session token | `HmcSession._session_token` (in-memory) | High | Never serialized; redacted via `X-API-Session` regex; cleared on `close()` |
| `WriteAuthorization` capability token | Issued in `run_write_tool`, consumed in same call stack | Medium-high | Module-private sentinel; direct construction raises; `isinstance` check re-validates in `HmcClient` write methods ([`tools/write.py:109-120`](../../src/power_hmc_mcp/tools/write.py)) |
| Structured logs | stdout / log file / SIEM | Medium | `RedactingFilter`; `hmc_request_end` event redacts URL params |
| PCM metric JSON | Response body (transient) | Low-medium | Size-guarded (`HMC_MAX_METRICS_BYTES`); not persisted |
| `.env` file | Filesystem | High | Documented as 600; never logged; sample shipped without secrets |

## Mitigations already in place (Phase A + B)

This list is the baseline. Anything in the next section ("Open mitigations")
must close **before** Phase C feature PRs merge.

- **Structural write boundary.** `WriteAuthorization` requires a module-private
  sentinel; direct construction raises; `HmcClient` write methods re-validate
  via `isinstance`. Forgetting `@mark_write_tool` is a **server-startup
  failure**, not a runtime mutation risk
  ([`tools/write.py`](../../src/power_hmc_mcp/tools/write.py)).
- **Single write-audit issuer.** `run_write_tool` is the only path that
  produces a `WriteAuthorization` and the only path that emits `write_audit`
  on every code path (denied / dry_run / authorized — never silent).
- **Defaults that fail closed.**
  - `HMC_ENABLE_WRITE_TOOLS=false` by default — write tools are not even
    registered with FastMCP.
  - `HMC_REQUIRE_EXECUTE_FLAG` available to force dry-run unless the agent
    explicitly opts in.
  - `HMC_VERIFY_TLS=true` by default.
  - `HMC_DEMO_MODE` prints a prominent `WARNING` on startup so it cannot be
    mistaken for a real deployment.
- **Logging hygiene.** `RedactingFilter` strips passwords, `X-API-Session`
  tokens, and `Authorization: Bearer` headers from log records before they
  leave the process.
- **Managed-system allowlist.** `HMC_ALLOWED_MANAGED_SYSTEMS` restricts which
  systems any tool — read or write — can touch.
- **Correlation ID propagation.** Every HMC request carries a request-scoped
  correlation ID; every `mcp_tool_call`, `hmc_request_end`, `session_*`, and
  `write_audit` event carries it. SIEM joins are first-class.

## Open mitigations (gating Phase C)

The four items below must land before any real `POST` ships. They map 1:1 to
the attacker personas above.

### 1. RBAC matrix vs. HMC roles

A table that maps the four IBM HMC built-in roles to the MCP tool surface.
**Rows** are HMC roles; **columns** are MCP tools; **cells** are one of:

- `R` — tool requires only HMC read scope; safe to expose to this role.
- `W` — tool requires HMC write scope; expose only with dual-control.
- `-` — tool not callable by this role even if registered (HMC will reject).

Shape (populated as Phase C firmware captures land):

| HMC role | `list_managed_systems` | `list_lpars` | `get_lpar_status` | `get_lpar` | `get_managed_system` | `list_partition_profiles` | `get_capacity` | `health_check` | `start_lpar` | `stop_lpar` | `create_lpar_from_profile` |
|----------|------------------------|--------------|-------------------|------------|----------------------|---------------------------|----------------|----------------|--------------|-------------|----------------------------|
| `hmcsuperadmin` | R | R | R | R | R | R | R | R | W | W | W |
| `hmcoperator` | R | R | R | R | R | R | R | R | W | W | W |
| `hmcviewer` | R | R | R | R | R | R | R | R | - | - | - |
| `hmcservicerep` | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD |

Rows are best-effort initial values from IBM documentation and will be
**confirmed by lab capture** during Phase C — that is why each row is marked
`TBD` for `hmcservicerep` (the role with the most firmware-dependent
behaviour) and why this matrix lives in a doc rather than enforced in code.
Once captured, the matrix becomes a section in [`docs/operations.md`](../operations.md)
that operators can hand to security review.

**Enforcement model:** the MCP server does **not** enforce HMC roles directly
— the HMC does, via the configured service account. Our role is to (a)
document which account each deployment should use, (b) refuse to register
write tools when `HMC_ENABLE_WRITE_TOOLS=false`, and (c) emit `write_audit`
on every code path so denied writes are reviewable.

### 2. Dual-control approval workflow

Required for `create_lpar_from_profile` and any production-bound `stop_lpar`.
The hook is already planned in [`TODO.md` Phase C](../../TODO.md#phase-c--write-path-execution)
("Approval workflow hooks (external ticket ID, dual-control) [PLACEHOLDER]").
Threat-model requirements for that hook:

- The approval token (external ticket ID) is passed as a tool parameter,
  recorded in `write_audit`, and validated against an external policy
  endpoint before `WriteAuthorization` is issued.
- The external policy endpoint is the **authority**; the MCP server does not
  cache approvals. Replay of an already-consumed approval token must be
  rejected by the external system.
- This mitigates **persona #1 (malicious agent)** and **persona #2
  (over-eager LLM)**: even with the right tool parameters, no `POST` lands
  without an out-of-band human sign-off recorded against an external ticket.

### 3. Persistent audit sink (interim story)

Phase E will ship `write_audit` via OpenTelemetry log exporters. **Before
that**, the threat model needs to state explicitly that the in-process JSON
log is the auditable source of truth. Required Phase C posture:

- Operators are responsible for shipping the structured log to a SIEM (Fluent
  Bit / Vector recipes are Phase E deliverables; for Phase C, document a
  manual `journald` / file-tail pattern in `docs/operations.md`).
- `write_audit` schema is **frozen** for Phase C: any field addition must be
  backwards-compatible (additive only).

### 4. Secrets handling

`.env` is acceptable for pilot deployments but **must** be replaced by a vault
sidecar for production. Phase H tracks the vault wiring
([`TODO.md` Phase H](../../TODO.md#phase-h--security--compliance) "Secrets
via vault sidecars instead of env-only"). For Phase C entry the threat-model
requirement is documentation only:

- A runbook entry in `docs/operations.md` describing the recommended deployment
  posture: `.env` permissions, no `.env` in container images, no `.env` in
  process listings.
- An explicit denial in [`SECURITY.md`](../../SECURITY.md) that running with
  `HMC_VERIFY_TLS=false` against production is an accepted-risk
  configuration error, not a defended posture. (This is already documented;
  the threat model just notes it.)

## What this draft does NOT do

- Does not enforce RBAC inside the MCP server (HMC is authoritative).
- Does not populate the `hmcservicerep` row of the RBAC matrix; that needs a
  lab capture during Phase C.
- Does not specify the dual-control endpoint protocol; that is a Phase C
  implementation question once the approval-workflow hook lands.
- Does not cover the streamable-HTTP session affinity question — that is a
  Phase D issue ([`TODO.md` Phase D](../../TODO.md#phase-d--transport--deployment))
  and revisits this document when async lands.

## Cross-references

- [`SECURITY.md`](../../SECURITY.md) — reporting policy + in-scope vs.
  out-of-scope definitions.
- [`docs/architecture.md` write-safety-model](../architecture.md#write-safety-model)
  — the structural boundary this threat model relies on.
- [`docs/design/write-idempotency.md`](write-idempotency.md) — companion
  Phase C prerequisite; covers the GET-before-POST pattern that pairs with
  the dual-control workflow.
- [`docs/operations.md`](../operations.md) — configuration reference;
  populated `denied`/`denied_idempotent` runbook entries land alongside this
  doc.
- [`TODO.md` Phase H](../../TODO.md#phase-h--security--compliance) — formal
  external review of this draft is the Phase H deliverable.
