# Operations

Reference doc for operators running `power-hmc-mcp` in shared or controlled environments. For first-run setup see the [README](../README.md). For protocol-level architecture see [architecture](architecture.md). For agent-side guidance see the [agent guide](agent-guide.md). Terminology is defined once in the [glossary](glossary.md).

---

## Configuration reference

Every variable below is read from environment variables or a `.env` file via Pydantic settings (`src/power_hmc_mcp/config.py`). Required vars have no default.

### Demo mode

| Variable | Default | Description |
|----------|---------|-------------|
| `HMC_DEMO_MODE` | `false` | When `true`, all read tools return bundled fixture responses and no HMC connection is made. Write tools return `{"executed": false, "demo": true}`. Startup emits a prominent `WARNING`. Enables demos, CI smoke tests, and contributor onboarding without HMC access. **Do not enable in production.** |

### Connection (required unless `HMC_DEMO_MODE=true`)

| Variable | Default | Description |
|----------|---------|-------------|
| `HMC_HOST` | _required_ | HMC hostname or IP. **No protocol or path** (`hmc.example.com`, not `https://hmc.example.com/`). |
| `HMC_PORT` | `443` | HMC REST API port. IBM docs for 7063-CR2 on V10/V11 list 443; legacy V8/V9 appliances may require `12443`. |
| `HMC_USERNAME` | _required_ | HMC user with the minimum permissions for the exposed tools. |
| `HMC_PASSWORD` | _required_ | Password (or token, depending on HMC setup). Redacted from logs by `RedactingFilter`. |
| `HMC_VERIFY_TLS` | `true` | Verify the HMC's TLS certificate. Set `false` only for self-signed labs. |
| `HMC_CA_BUNDLE` | _unset_ | Path to a PEM CA bundle for corporate-PKI HMCs (preferred over `HMC_VERIFY_TLS=false`). |
| `HMC_TIMEOUT_SECONDS` | `30` | Per-request HTTP timeout (1–300). |

### Write-tool gating

| Variable | Default | Description |
|----------|---------|-------------|
| `HMC_ENABLE_WRITE_TOOLS` | `false` | Register `start_lpar` / `stop_lpar` / `create_lpar_from_profile` MCP tools. Off by default. |
| `HMC_WRITES_ENABLED` | `false` | Master switch for live HMC write mutations. Requires `HMC_ENABLE_WRITE_TOOLS=true` as well. Never enable in demo or development. |
| `HMC_REQUIRE_EXECUTE_FLAG` | `true` | Require `execute=true` on a write-tool call to leave the dry-run path. Keep on unless you have an external approval gate. |

### Scope and posture

| Variable | Default | Description |
|----------|---------|-------------|
| `HMC_ALLOWED_MANAGED_SYSTEMS` | _unset_ | Comma-separated managed-system UUID allowlist. When set, read tools only return / accept these systems; write tools refuse out-of-list IDs. Blast-radius tool, not RBAC. |
| `HMC_DEPLOYMENT_MODE` | `development` | One of `development` / `controlled` / `production`. Documents intent today; see [Deployment modes](#deployment-modes-hmc_deployment_mode) for the recommended toggle matrix. |

### Transport

| Variable | Default | Description |
|----------|---------|-------------|
| `HMC_MCP_TRANSPORT` | `stdio` | `stdio` (default, local agents) or `streamable-http` (remote / containerized). See [transports](transports.md). |
| `HMC_MCP_HTTP_HOST` | `127.0.0.1` | Bind host for streamable HTTP transport. **Bind to loopback** unless TLS termination + auth live in front. |
| `HMC_MCP_HTTP_PORT` | `8000` | Bind port for streamable HTTP transport. |
| `HMC_MCP_HTTP_PATH` | `/mcp` | Path component for streamable HTTP. |
| `HMC_MCP_HTTP_PROBES_PATH` | (empty — disabled) | Mount path for HTTP `/healthz` and `/readyz` (D3). `/` mounts at listener root; any other value is a prefix (e.g. `/admin` → `/admin/healthz`, `/admin/readyz`). HTTP-only — never registered when `HMC_MCP_TRANSPORT=stdio`. Must not collide with `HMC_MCP_HTTP_PATH`. |
| `HMC_DEFAULT_ALIAS` | `default` | Alias attached to the implicit endpoint built from `HMC_HOST` / `HMC_USERNAME` / `HMC_PASSWORD` (Phase D, D5). Lowercased; characters limited to `[a-z0-9_-]`. Cannot collide with any alias declared in `HMC_REGISTRY`. |
| `HMC_REGISTRY` | (unset) | Optional JSON list of additional HMC endpoints exposed via the `hmc_alias` tool parameter (Phase D, D5). Each entry must carry `alias` / `host` / `username` / `password`; optional per-entry overrides are `port` / `verify_tls` / `timeout_seconds`. All other HMC settings (allowlists, retries, write guardrails, transport, observability) are process-wide and apply uniformly to every alias. |

### Container / Helm deployment (D4)

A multi-stage [`Dockerfile`](../Dockerfile) builds the runtime image as a non-root (UID 10001) container with `tini` as PID 1. Default env wires the streamable-HTTP transport on port 8000. Pair with [`examples/deploy/`](../examples/deploy/) for reverse-proxy templates and [`examples/deploy/helm/power-hmc-mcp/`](../examples/deploy/helm/power-hmc-mcp/) for the Kubernetes chart. The chart wires `livenessProbe` / `readinessProbe` to the D3 probes when `mcp.http.probesPath` is non-empty and falls back to TCP-socket health checks otherwise.

### Observability

| Variable | Default | Description |
|----------|---------|-------------|
| `HMC_LOG_JSON` | `false` | Emit single-line JSON log records (preferred for shippers). Otherwise human key=value tail. |
| `HMC_PROPAGATE_CORRELATION_HEADER` | `true` | Inject the configured outbound correlation header (see `HMC_OUTBOUND_CORRELATION_HEADER`) into every outbound HMC request so MCP-side and HMC-side logs are joinable. Set `false` only if older firmware rejects unknown request headers. |
| `HMC_CORRELATION_ECHO_HEADER` | `X-Transaction-ID` | Primary response header to read for the HMC's echo of the outbound correlation ID. The IBM HMC REST API spec guarantees `X-Transaction-ID` is echoed verbatim. Override only if your firmware echoes under a different name. |
| `HMC_CORRELATION_ECHO_FALLBACK_HEADERS` | `X-Client-Correlator` | Comma-separated fallback header names walked in order after the primary if it is absent. `X-Client-Correlator` is the IBM-defined optional alternative (V8+). Empty string disables fallback. |
| `HMC_OUTBOUND_CORRELATION_HEADER` | `X-Transaction-ID` | Header sent outbound on each HMC request. IBM-spec default. Override to `X-Correlation-ID` for backwards compat with existing log pipelines. |
| `HMC_API_VERSION_HINT` | _unset_ | Operator-supplied hint about the target HMC API / firmware version (e.g. `V11R1`, `V10R2M1040`). **Logging hint only** — included in `session_logon_end` / `session_logoff_end` payloads and the startup log line when set. Does NOT flip firmware-gated behavior; the compatibility tables in [`hmc-compatibility.md`](hmc-compatibility.md) remain the source of truth for what is validated. Empty string is treated as unset. |

### Retry / throttle

| Variable | Default | Valid range | Description |
|----------|---------|-------------|-------------|
| `HMC_READ_MAX_RETRIES` | `2` | `0`–`10` | Additional attempts after retryable transport / HTTP failures on read calls. |
| `HMC_WRITE_MAX_RETRIES` | `0` | `0`–`10` | Additional attempts on writes. **Default zero** because POSTs are non-idempotent without IBM-confirmed idempotency tokens. |
| `HMC_RETRY_BASE_SECONDS` | `0.5` | `0`–`120` s | Base backoff before the first retry. |
| `HMC_RETRY_MAX_SECONDS` | `8.0` | `0`–`120` s | Cap on backoff with jitter. |
| `HMC_MIN_REQUEST_INTERVAL_SECONDS` | `0.0` | `0`–`60` s | Minimum spacing between outbound HMC calls (client-side throttle placeholder; raise if your HMC throws 429 under load). |
| `HMC_MAX_REAUTH_ATTEMPTS` | `1` | `0`–`3` | Number of re-authentication attempts when the HMC returns `401` mid-request. `0` disables automatic re-auth (any `401` surfaces as `HmcAuthError` immediately). Higher than `3` is rejected at config load. Each re-auth emits a `session_reauth` event. |

**Tuning rationale:** defaults are conservative estimates pending real HMC trace collection. After lab traces are available, update defaults in `config.py` with a structured comment of the form `# Tuned from HMC V<version> traces (<YYYY-MM-DD>): <one-line rationale>` above each adjusted field, and re-confirm the table above matches. Per-firmware observed behaviour belongs in [`docs/hmc-compatibility.md`](hmc-compatibility.md); this table tracks the operator-facing defaults.

### Read-path tuning

| Variable | Default | Description |
|----------|---------|-------------|
| `HMC_LPAR_STATUS_SOURCE` | `uom` | `uom` (single canonical GET; default) or `quick` (multi quick-property fan-out for older firmware). |
| `HMC_PREFER_QUICK_PROPERTIES` | `false` | **[PLACEHOLDER]** Feature flag for the composite single-GET quick-property endpoint. **Do not enable until validated against firmware** — see [`hmc-compatibility.md`](hmc-compatibility.md) 'LPAR Composite Quick Endpoint'. |
| `HMC_MAX_METRICS_BYTES` | `10000000` | Maximum PCM metric JSON response body size in bytes. `get_capacity_full` raises `HmcResponseTooLargeError` before parsing if exceeded. Default 10 MB; raise if HMC emits unusually large payloads. |

---

## Logging

Two modes:

- **Human (default)**: `event_type` followed by a key=value tail. Easy to read in a tail.
- **JSON (`HMC_LOG_JSON=true`)**: single-line JSON per record. Pipe straight into Loki / Splunk / OpenSearch.

Secret redaction (`logging_utils.RedactingFilter`) masks:

- `password=<value>` patterns (case-insensitive)
- `<Password>...</Password>` XML elements (HMC logon body)
- `X-API-Session=<token>` headers (HMC session token)
- `Authorization: Bearer <token>` headers
- The literal `HMC_PASSWORD` value, if set in env when the process started

Add additional literals by extending `_collect_secrets` in `logging_utils.py` if you store other secrets (e.g. proxy passwords) in the process environment.

### Standard event types

| Event type | When | Notable fields |
|------------|------|----------------|
| `mcp_tool_start` | Tool invocation begins | `tool_name`, `correlation_id` |
| `mcp_tool_end` | Tool invocation returns or raises | `tool_name`, `outcome` (`success` / `error`), `duration_ms`, `error_type` |
| `hmc_request_start` | About to call HMC | `hmc_method`, `hmc_path` |
| `hmc_request_end` | HMC call returned | `hmc_status`, `duration_ms`, `outcome` (`success` / `auth_retry` / `auth_error` / `http_error` / `transport_error`), optional `hmc_echo_correlation_id` |
| `session_logon_end` | HMC session established successfully in `login()` | `hmc_host`, `outcome` (`success` / `demo`) |
| `session_logoff_end` | HMC session tear-down completed or attempted in `close()` | `hmc_host`, `outcome` (`success` / `error` / `demo`) |
| `session_reauth` | HMC returned `401` mid-request and re-authentication was attempted | `hmc_host`, `outcome` (`success` / `failure`), `trigger` (currently always `401_mid_request`) |
| `write_audit` | Write tool decided / authorized / denied | See [`write_audit` schema](#write_audit-schema) |
| `telemetry_stub` | Reserved for future OTEL / metrics exporters (no-op DEBUG today) | `telemetry_event` (event name), arbitrary attrs |

Every record carries `event_type`, `component=power_hmc_mcp`, and `correlation_id`.

### `write_audit` schema

Emitted by `power_hmc_mcp.observability.log_write_audit` from inside the structural write boundary on every outcome. Fields are stable; SIEM rules can pin on them.

| Field | Type | Description |
|-------|------|-------------|
| `event_type` | string | Always `write_audit`. |
| `component` | string | Always `power_hmc_mcp`. |
| `correlation_id` | string | Bound to the MCP tool invocation. |
| `tool_name` | string | The MCP tool name (e.g. `start_lpar`). |
| `operation` | string | Logical operation name (today equal to `tool_name`). |
| `outcome` | enum | `denied`, `dry_run`, or `authorized` (`WRITE_AUDIT_OUTCOMES`). |
| `reason` | string | Guardrail decision reason (human-readable). |
| `execute_requested` | bool | Whether the caller passed `execute=true`. |

`denied` is the highest-signal record for security review: it indicates a caller attempted a write that the guardrail refused. It is emitted **before** the denial envelope is returned, so it cannot be skipped by a tool author.

---

## Correlation IDs

- One UUID per MCP tool invocation, bound by `mcp_tool_call` unless the caller already set one.
- Propagated to the HMC on the outbound request via `HMC_OUTBOUND_CORRELATION_HEADER` (default `X-Transaction-ID` — the IBM HMC REST API spec header). Override to `X-Correlation-ID` for backwards compatibility with existing log pipelines.
- According to the IBM HMC REST API spec, `X-Transaction-ID` is the spec-defined correlation header for HMC requests. `X-Correlation-ID` and `X-Request-ID` are **not** defined in the IBM HMC spec; do not rely on them being echoed.
- The outbound header (`HMC_OUTBOUND_CORRELATION_HEADER`, default `X-Transaction-ID`) and the echo-read header (`HMC_CORRELATION_ECHO_HEADER`, default `X-Transaction-ID`) are **symmetric** — both default to the IBM-specified header so the client expects whatever it sends to come back under the same name. When the HMC firmware echoes the header as the spec describes, `hmc_echo_correlation_id` is populated on the `hmc_request_end` log event so both sides of the wire are joinable in one log query. The exact per-firmware echo behaviour is `[ASSUMED]` until rows land in [`docs/hmc-compatibility.md`](hmc-compatibility.md) 'Correlation Header Echo — Per-firmware observations'; until then, treat missing echoes as expected on uncaptured firmware.

**Fallback resolution order:** the server checks the header named by `HMC_CORRELATION_ECHO_HEADER` first (default `X-Transaction-ID`), then each header in `HMC_CORRELATION_ECHO_FALLBACK_HEADERS` in order (default `X-Client-Correlator` — IBM-defined optional V8+ alternative). If none are present in the HMC response, `hmc_echo_correlation_id` is omitted from the log payload entirely — it is never emitted as `None` or an empty string.

---

## Errors and exceptions

The HMC client raises a small typed hierarchy. Tool wrappers let these bubble up; FastMCP serializes them into MCP error responses. Operators reading logs and agent authors catching errors should know:

| Exception | Raised when | Typical operator action |
|-----------|-------------|-------------------------|
| `HmcAuthError` | Logon failed (bad credentials, locked account), or session expired and re-authentication failed. | Verify `HMC_USERNAME` / `HMC_PASSWORD`, check the user's HMC role, look for HMC-side lockout. |
| `HmcHttpError` | HMC returned a non-`401` ≥ `400` status, or a transport error after retries. Carries `status_code` and a sanitized `url`. | Inspect HMC logs at the same `correlation_id`. `429` → raise `HMC_MIN_REQUEST_INTERVAL_SECONDS`. `5xx` → check HMC health. |
| `HmcParseError` | An HMC response body did not match the expected XML / Atom shape. | Likely firmware variance. File an issue with the redacted feed and HMC firmware version. |
| `HmcValidationError` | Input failed validation **before** any HMC call (e.g. malformed UUID, system not in allowlist). | Check the agent's input. Allowlist mismatches surface here. |
| `HmcError` | Base class. Catch this to handle any HMC failure uniformly. | — |

Definitions live in `src/power_hmc_mcp/exceptions.py`.

### Retryable signals

Reads:

- Transport: timeouts, connect errors (limited cases).
- HTTP: `429`, `502`, `503`, `504` on safe / idempotent methods.

Writes:

- HTTP-status retries apply only when the method is classified idempotent. POSTs rely on transport-level retries **only if** `HMC_WRITE_MAX_RETRIES` is raised deliberately. Default `0` keeps blast radius minimal.

### Synchronous and asynchronous sleeps

`http_policy.retry_sleep` and `http_policy.throttle_before_request` use `time.sleep` intentionally because the HMC client is built on `httpx.Client` (synchronous). The `# SYNC-ONLY` comments at those call sites are paired with `retry_sleep_async` and `throttle_before_request_async`, marked `# ASYNC`, which use `asyncio.sleep` and are consumed by `HmcAsyncSession` (`session_async.py`) on top of `httpx.AsyncClient`. The sync path is the supported public MCP surface today; the async path is opt-in for Phase D internals (Multi-HMC pools, OpenTelemetry instrumentation). Do not delete either marker — they document the invariant pair.

---

## Audit trail for writes

Two complementary signals exist for every write-tool invocation:

1. **`write_audit` log event** (durable signal): emitted by the structural decorator on every outcome (`denied` / `dry_run` / `authorized`). See the [schema](#write_audit-schema) above. **This is the canonical write-audit record** — log parsers and SIEM rules should pin on this event.
2. **Inline `audit` block** in the placeholder response body: `correlation_id`, `record_status=placeholder`, `hmc_request_preview`. Convenience for inspecting a single response without joining log lines.

Future: ship the log event to an immutable store / SIEM via `telemetry_hook` or OpenTelemetry exporters without rewriting tools (Phase E).

### Why the structural boundary matters

A reviewer asked whether the write gating was structural (enforced by the type system + module boundaries) or conventional (each tool body remembered to call the right helpers). It is now **structural**:

- The single helper that issues a `WriteAuthorization` token is module-private and only called from `tools/write.py::run_write_tool`.
- `HmcClient.start_lpar` / `stop_lpar` / `create_lpar_from_profile` require a `WriteAuthorization` parameter and re-validate it with `isinstance` to defeat `cast()` abuse.
- Every registered write tool must wear `@mark_write_tool`; the registration validator refuses to start the server if any expected write tool lacks the marker.
- Every code path inside `run_write_tool` emits a `write_audit` log event before returning, so a denied write is never silent.

See [architecture: write safety model](architecture.md#write-safety-model) for the full property list.

---

## Deployment modes (`HMC_DEPLOYMENT_MODE`)

| Mode | Intent | Recommended toggles |
|------|--------|---------------------|
| `development` | Fast iteration; verbose logs acceptable; experiments encouraged. | Defaults are fine. `HMC_VERIFY_TLS=false` for self-signed labs. |
| `controlled` | Integration labs; allowlist + write flags tightly managed. | `HMC_ALLOWED_MANAGED_SYSTEMS=...`, `HMC_LOG_JSON=true`, `HMC_ENABLE_WRITE_TOOLS=true` only after a lab dry-run review. |
| `production` | Hardened posture; prefer allowlists, structured logs, minimal write surface. | `HMC_VERIFY_TLS=true` (or `HMC_CA_BUNDLE`), `HMC_LOG_JSON=true`, `HMC_ALLOWED_MANAGED_SYSTEMS=...`, `HMC_REQUIRE_EXECUTE_FLAG=true`. Keep `HMC_ENABLE_WRITE_TOOLS=false` until Phase C. |

**Today**: the flag documents intent; automation tightening (e.g., refusing write registration in `production`) is roadmap work — see [`TODO.md`](../TODO.md).

---

## Allowlist

`HMC_ALLOWED_MANAGED_SYSTEMS` is a focused **blast-radius** tool, not the sole definition of security. Combine with:

- HMC RBAC (the user behind `HMC_USERNAME` should have only what the exposed tools need).
- Network ACLs (the MCP server should reach the HMC over a controlled path).
- Transport protection (TLS verification on, mTLS or SSO gateway in front of HTTP transport).

When the allowlist is unset, all systems the HMC user can see are exposed. When set, read tools filter to those UUIDs and `_check_allowlist` rejects any other ID before any HMC call (raises `HmcValidationError`).

---

## Rollout checklist

1. Verify TLS posture (`HMC_VERIFY_TLS`, optional `HMC_CA_BUNDLE`).
2. Set `HMC_ALLOWED_MANAGED_SYSTEMS` for non-prod pilots.
3. Keep `HMC_ENABLE_WRITE_TOOLS=false` until lab validation completes (Phase C).
4. Enable structured logging in shared environments (`HMC_LOG_JSON=true`).
5. Choose transport (`stdio` vs `streamable-http`) per hosting model — see [transports](transports.md).
6. Pipe `write_audit` events to your audit store as soon as writes are enabled.
7. Wire HMC-side and MCP-side logs into one query path on `correlation_id`.

---

## Common runbook entries

### Symptom: `HmcAuthError: HMC logon failed with status 401`

- Verify the credentials work against the HMC's web UI / direct REST.
- Check whether HMC has locked the account after repeated failures.
- If you rotated the password, restart the server so it picks up the new value (Pydantic `Settings` is resolved at startup).

### Symptom: `HmcHttpError` with `status_code=429`

- HMC rate-limit hit. Raise `HMC_MIN_REQUEST_INTERVAL_SECONDS` (e.g. to `0.25`).
- Inspect what's calling at high frequency — fan-out from a long agent loop?

### Symptom: tool returns dry-run envelope when caller wanted execute

- Check `HMC_ENABLE_WRITE_TOOLS=true` is actually set in the process environment (not just `.env` for a different shell).
- Check the `write_audit` record — `outcome=denied` with `reason` tells you which check refused.

### Symptom: agent chain receives `HmcAuthError` after running for several minutes

Indicates the HMC session expired mid-workflow and re-authentication failed. Look for `session_reauth` events with `outcome=failure` and `trigger=401_mid_request` in logs.

Check:

- HMC credentials were not rotated mid-session (a password change invalidates the existing session).
- The HMC session lifetime is not shorter than your agent workflow duration. HMC defaults vary by firmware — check the HMC GUI "Users and Security → User Properties" page.
- `HMC_MAX_REAUTH_ATTEMPTS` is not `0` (which disables automatic recovery entirely).

As a temporary mitigation while investigating the root cause, raise `HMC_MAX_REAUTH_ATTEMPTS` to `2`. Do not exceed `3` — repeated failures usually point at credential or RBAC drift rather than transient network issues.

### Symptom: `hmc_echo_correlation_id` never appears in logs

- According to the IBM HMC REST API spec, `X-Transaction-ID` is the spec-defined correlation header — but actual per-firmware echo behaviour is not guaranteed and is tracked in [`docs/hmc-compatibility.md`](hmc-compatibility.md) 'Correlation Header Echo'. Treat the absence of an echo as expected on uncaptured firmware until a row confirms otherwise.
- Verify with `curl -k -i -H 'X-Transaction-ID: probe-1' https://<hmc>:443/rest/api/uom/ManagedSystem` directly against the HMC and inspect the response headers (legacy appliances may use port `12443`).
- If a particular firmware build echoes under a different header, set `HMC_CORRELATION_ECHO_HEADER` (primary) and/or `HMC_CORRELATION_ECHO_FALLBACK_HEADERS` (comma-separated fallbacks).
- Record whatever you observe in [`docs/hmc-compatibility.md`](hmc-compatibility.md) 'Correlation Header Echo — Per-firmware observations' so the project gradually moves rows from `[ASSUMED]` to `[VALIDATED vN]`.

### Symptom: server fails to start with `Write tools missing the @mark_write_tool decorator`

- Someone added a write tool without applying `@mark_write_tool` — the boot-time guardrail check caught it. Add the decorator (see the [architecture recipe](architecture.md#adding-a-new-write-tool)) before re-running.

---

## Log shipping

When `HMC_LOG_JSON=true`, each log line is a single JSON object suitable for tail-and-forward pipelines. Starter templates (adjust paths and sink endpoints for your environment):

- Fluent Bit: [`integrations/fluent-bit/hmc-mcp.conf`](../integrations/fluent-bit/hmc-mcp.conf)
- Vector: [`integrations/vector/hmc-mcp.yaml`](../integrations/vector/hmc-mcp.yaml)

Pin SIEM rules on stable fields such as `event_type`, `correlation_id`, and `write_audit` outcomes documented in [architecture](architecture.md).

---

## Maintainer setup (GitHub & releases)

One-time repository configuration (topics, milestones, project board triage, Codecov, PyPI OIDC) is documented in [`release-engineering.md`](release-engineering.md).

Quick commands after `gh auth login`:

```bash
gh secret set CODECOV_TOKEN --repo TylrDn/power-hmc-mcp-server   # paste token from codecov.io
export GH_PROJECT_NUMBER=1   # your Projects board number, if used
./scripts/github-bootstrap.sh
```

Configure PyPI **Trusted Publishing** before pushing a `v*.*.*` tag — see [PyPI OIDC](release-engineering.md#pypi-trusted-publishing-oidc).
