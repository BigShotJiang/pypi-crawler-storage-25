"""MCP tool registration."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.pool import ClientResolver, HmcClientPool, single_client_resolver
from power_hmc_mcp.tools import (
    create_lpar_from_profile,
    get_capacity,
    get_lpar,
    get_lpar_status,
    get_managed_system,
    health_check,
    list_lpars,
    list_managed_systems,
    list_partition_profiles,
    start_lpar,
    stop_lpar,
)
from power_hmc_mcp.tools.write import is_write_tool

READONLY_TOOL_NAMES = frozenset(
    {
        "list_managed_systems",
        "list_lpars",
        "get_lpar_status",
        "get_managed_system",
        "get_lpar",
        "list_partition_profiles",
        "get_capacity",
        "health_check",
    }
)

WRITE_TOOL_NAMES = frozenset(
    {
        "create_lpar_from_profile",
        "start_lpar",
        "stop_lpar",
    }
)


def _register_read_tools(mcp: FastMCP, resolver: ClientResolver) -> None:
    list_managed_systems.register(mcp, resolver)
    list_lpars.register(mcp, resolver)
    get_lpar_status.register(mcp, resolver)
    get_managed_system.register(mcp, resolver)
    get_lpar.register(mcp, resolver)
    list_partition_profiles.register(mcp, resolver)
    get_capacity.register(mcp, resolver)
    health_check.register(mcp, resolver)


def _validate_tool_registration(mcp: FastMCP, *, writes_enabled: bool) -> None:
    registered_tools = mcp._tool_manager._tools
    registered = frozenset(registered_tools.keys())
    allowed_names = READONLY_TOOL_NAMES | WRITE_TOOL_NAMES
    if not registered <= allowed_names:
        unexpected = registered - allowed_names
        raise RuntimeError(f"Unexpected MCP tools registered: {sorted(unexpected)}")
    if writes_enabled:
        missing = WRITE_TOOL_NAMES - registered
        if missing:
            raise RuntimeError(
                f"HMC_ENABLE_WRITE_TOOLS is true but missing registrations: {sorted(missing)}",
            )
        unmarked = sorted(
            name
            for name in WRITE_TOOL_NAMES & registered
            if not is_write_tool(registered_tools[name].fn)
        )
        if unmarked:
            raise RuntimeError(
                "Write tools missing the @mark_write_tool decorator (guardrail bypass risk): "
                f"{unmarked}. Apply mark_write_tool from power_hmc_mcp.tools.write.",
            )
    elif registered & WRITE_TOOL_NAMES:
        raise RuntimeError("Write MCP tools must not be registered when write tools are disabled")


def _coerce_to_resolver(client_or_pool: HmcClient | HmcClientPool) -> tuple[ClientResolver, bool]:
    """Return (resolver, writes_enabled) for the given client or pool input.

    Single-HmcClient deployments wrap with :func:`single_client_resolver` so
    every tool sees the same shape; pool deployments delegate to
    :meth:`HmcClientPool.sync_resolver`. The boolean falls out of whichever
    settings instance ultimately drives the write-enable check.
    """
    if isinstance(client_or_pool, HmcClient):
        writes_enabled = client_or_pool.settings.hmc_enable_write_tools
        return single_client_resolver(client_or_pool), writes_enabled
    base_settings = client_or_pool.registry.base_settings
    return client_or_pool.sync_resolver(), base_settings.hmc_enable_write_tools


def register_readonly_tools(mcp: FastMCP, client_or_pool: HmcClient | HmcClientPool) -> None:
    """Register read-only MCP tools (strict; ignores write-tool enable flag)."""
    resolver, _writes_enabled = _coerce_to_resolver(client_or_pool)
    _register_read_tools(mcp, resolver)
    _validate_tool_registration(mcp, writes_enabled=False)


def register_tools(mcp: FastMCP, client_or_pool: HmcClient | HmcClientPool) -> None:
    """Register MCP tools according to settings (read tools + optional writes).

    Accepts either a single :class:`HmcClient` (single-HMC ergonomic;
    pre-D5 callers) or an :class:`HmcClientPool` (multi-HMC, D5+).
    """
    resolver, writes_enabled = _coerce_to_resolver(client_or_pool)
    _register_read_tools(mcp, resolver)
    if writes_enabled:
        create_lpar_from_profile.register(mcp, resolver)
        start_lpar.register(mcp, resolver)
        stop_lpar.register(mcp, resolver)
    _validate_tool_registration(mcp, writes_enabled=writes_enabled)
