"""IBM Power HMC REST API client."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, cast

import httpx

from power_hmc_mcp import observability, routes
from power_hmc_mcp.config import CapacityOutputMode, Settings, load_settings
from power_hmc_mcp.exceptions import (
    HmcHttpError,
    HmcNotImplementedError,
    HmcResponseTooLargeError,
    HmcValidationError,
)
from power_hmc_mcp.guardrails import WriteAuthorization
from power_hmc_mcp.hmc_xml import (
    parse_feed_entries,
    parse_pcm_metrics_feed,
    parse_quick_properties,
    parse_resource_properties,
)
from power_hmc_mcp.http_policy import (
    retry_sleep as retry_sleep,  # noqa: F401 — explicit re-export so session.py late-import (hmc_client.retry_sleep) survives no_implicit_reexport and unittest.mock.patch keeps its hook
)
from power_hmc_mcp.normalize import (
    normalize_lpar_state,
    normalize_pcm_samples_for_agent,
    normalize_resource,
    pcm_summary,
)
from power_hmc_mcp.serialize import drop_none, ensure_json_serializable
from power_hmc_mcp.session import (
    ACCEPT_ATOM,  # noqa: F401 — re-export for backwards compatibility
    ACCEPT_UOM_XML,
    HmcSession,
)
from power_hmc_mcp.validation import validate_resource_id

# Re-export for tests and backwards compatibility
LOGON_PATH = routes.LOGON_PATH
MANAGED_SYSTEMS_PATH = routes.MANAGED_SYSTEMS_PATH
LPAR_PROFILES_PATH = routes.LPAR_PROFILES_PATH
PCM_PROCESSED_METRICS_PATH = routes.PCM_PROCESSED_METRICS_PATH
SESSION_HEADER = routes.SESSION_HEADER

# [VALIDATED — IBM Docs Power9/10/11] LPAR Quick properties (Table 1 of the
# Power11 Logical Partition resource doc:
# https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition).
# The URL shape and these property names are IBM-doc-aligned.  The
# enumerated **values** returned for PartitionState / RMCState remain
# firmware-dependent — see docs/hmc-compatibility.md 'LPAR State Strings'.
LPAR_QUICK_PROPERTIES = (
    "PartitionState",
    "PartitionName",
    "PartitionID",
    "RMCState",
)


def _parse_version(version_str: str) -> tuple[int, ...]:
    """Parse a dotted version string into a comparable tuple.

    Returns ``(0,)`` on any parse failure so callers degrade gracefully.
    """
    try:
        return tuple(int(p) for p in version_str.split("."))
    except (ValueError, AttributeError):
        return (0,)


def _pcm_cpu_aggregates(
    system_util: dict[str, Any],
) -> dict[str, float | None]:
    """Compute CPU utilisation aggregates from a parsed PCM ``systemUtil`` object.

    Handles the IBM PCM JSON schema (Power9 / Power10 / Power11 — identical
    schema; single implementation path).  Field name and nesting path are
    validated against official IBM Power Systems documentation:

    Path: ``systemUtil.utilSamples[n].serverUtil.processor.utilizedProcUnits``

    Every numeric field is an *array* whose length and index order are declared
    by ``systemUtil.utilInfo.metricArrayOrder``:

    - ``Processed`` (30-second samples): ``["Avg"]`` → index 0 only.
    - ``Aggregated`` (5-min / 2-hr / 1-day): ``["Avg", "Min", "Max"]``
      → indices 0 / 1 / 2.

    For ``Processed`` samples this function extracts the single ``Avg`` element
    from each sample and returns ``min_cpu_pct``, ``max_cpu_pct``, and
    ``avg_cpu_pct`` across the full sample window.  For ``Aggregated`` samples
    the pre-computed ``Min`` / ``Max`` / ``Avg`` are read directly from the
    first (and typically only) aggregated entry.

    ``utilizedProcUnitsDeductIdle`` is present only when
    ``utilInfo.version >= "1.1.0"`` (PHYP ≥ 7.8.0, HMC V10R2M1040+).  This
    function reads ``utilInfo.version`` **from the actual PCM response
    payload** before accessing the field, and falls back to
    ``utilizedProcUnits`` for older firmware — no separate code path per
    power generation is required.  This selection is **not** driven by the
    operator-supplied ``HMC_API_VERSION_HINT`` (which is logging-only);
    the in-band ``utilInfo.version`` is the authoritative source per IBM
    docs.

    Returns a dict with keys ``min_cpu_pct``, ``max_cpu_pct``, ``avg_cpu_pct``
    (all ``float | None``).  All three are ``None`` when no valid samples are
    present or the payload is empty.

    [VALIDATED — IBM Docs Power9, Power10, Power11]
    """
    util_info: dict[str, Any] = system_util.get("utilInfo", {})
    samples: list[dict[str, Any]] = system_util.get("utilSamples", [])
    metric_type: str = util_info.get("metricType", "Processed")
    array_order: list[str] = util_info.get("metricArrayOrder", ["Avg"])
    schema_version: str = util_info.get("version", "1.0.0")

    # Prefer deductIdle field when the firmware schema supports it (v1.1.0+).
    use_deduct_idle = _parse_version(schema_version) >= (1, 1, 0)

    try:
        avg_idx = array_order.index("Avg")
    except ValueError:
        return {"min_cpu_pct": None, "max_cpu_pct": None, "avg_cpu_pct": None}
    min_idx = array_order.index("Min") if "Min" in array_order else None
    max_idx = array_order.index("Max") if "Max" in array_order else None

    field = "utilizedProcUnitsDeductIdle" if use_deduct_idle else "utilizedProcUnits"

    avgs: list[float] = []
    mins: list[float] = []
    maxs: list[float] = []

    for sample in samples:
        proc = sample.get("serverUtil", {}).get("processor", {})
        arr = proc.get(field) or proc.get("utilizedProcUnits")
        if not isinstance(arr, list) or not arr:
            continue
        try:
            avgs.append(float(arr[avg_idx]))
            if min_idx is not None and len(arr) > min_idx:
                mins.append(float(arr[min_idx]))
            if max_idx is not None and len(arr) > max_idx:
                maxs.append(float(arr[max_idx]))
        except (TypeError, ValueError, IndexError):
            continue

    if not avgs:
        return {"min_cpu_pct": None, "max_cpu_pct": None, "avg_cpu_pct": None}

    # For Aggregated metricType, the array already contains pre-computed
    # Min/Max/Avg — use them directly from the first entry.
    if metric_type == "Aggregated" and mins and maxs:
        return {
            "min_cpu_pct": mins[0],
            "max_cpu_pct": maxs[0],
            "avg_cpu_pct": avgs[0],
        }

    # For Processed metricType, aggregate the per-sample Avg values ourselves.
    return {
        "min_cpu_pct": min(avgs),
        "max_cpu_pct": max(avgs),
        "avg_cpu_pct": sum(avgs) / len(avgs),
    }


class HmcClient:
    """Client for IBM Power HMC REST operations."""

    def __init__(
        self,
        settings: Settings | None = None,
        *,
        session: HmcSession | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        if session is not None:
            self._session = session
            self._settings = session.settings
        else:
            self._settings = settings or load_settings()
            self._session = HmcSession(self._settings, http_client=http_client)

    @property
    def settings(self) -> Settings:
        return self._settings

    def login(self) -> None:
        """Establish an HMC REST API session (no-op in demo mode)."""
        hint = self._settings.hmc_api_version_hint
        if self._settings.hmc_demo_mode:
            observability.log_logon_end(
                self._settings.hmc_host,
                outcome="demo",
                api_version_hint=hint,
            )
            return
        self._session.login()
        observability.log_logon_end(
            self._settings.hmc_host,
            outcome="success",
            api_version_hint=hint,
        )

    def close(self) -> None:
        """Log off and close the HTTP client (no-op for session in demo mode).

        Swallows logoff failures — the process should not crash on teardown —
        but emits ``session_logoff_end`` with ``outcome="error"`` so the event
        is visible in logs and SIEM rules can distinguish clean from failed
        teardowns.
        """
        hint = self._settings.hmc_api_version_hint
        if self._settings.hmc_demo_mode:
            observability.log_logoff_end(
                self._settings.hmc_host,
                outcome="demo",
                api_version_hint=hint,
            )
            return
        try:
            self._session.close()
        except HmcHttpError:
            observability.log_logoff_end(
                self._settings.hmc_host,
                outcome="error",
                api_version_hint=hint,
            )
            return
        observability.log_logoff_end(
            self._settings.hmc_host,
            outcome="success",
            api_version_hint=hint,
        )

    _DEMO_FIXTURES_DIR: Path = Path(__file__).parent / "demo_fixtures"

    def _demo_fixture(self, name: str) -> Any:
        """Load a bundled demo fixture by tool name and return its parsed JSON."""
        path = self._DEMO_FIXTURES_DIR / f"{name}.json"
        return json.loads(path.read_text(encoding="utf-8"))

    def __enter__(self) -> HmcClient:
        self.login()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def _check_metrics_response_size(self, body: bytes) -> None:
        """Raise HmcResponseTooLargeError if body exceeds the configured size limit.

        Called by :meth:`get_capacity_full` before parsing PCM metric JSON so the
        process never tries to deserialise a multi-hundred-MB firmware dump.
        The limit is ``HMC_MAX_METRICS_BYTES`` (default 10 MB).
        """
        if len(body) > self._settings.hmc_max_metrics_bytes:
            raise HmcResponseTooLargeError(
                f"PCM metrics response exceeds limit: "
                f"{len(body)} > {self._settings.hmc_max_metrics_bytes} bytes",
                max_bytes=self._settings.hmc_max_metrics_bytes,
                actual_bytes=len(body),
            )

    def _check_allowlist(self, managed_system_id: str) -> str:
        system_id = validate_resource_id(managed_system_id, field="managed_system_id")
        if not self._settings.is_managed_system_allowed(system_id):
            raise HmcValidationError(
                f"Managed system {system_id} is not in HMC_ALLOWED_MANAGED_SYSTEMS",
            )
        return system_id

    def _filter_allowed_systems(
        self,
        systems: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        allowlist = self._settings.allowed_managed_system_ids()
        if allowlist is None:
            return systems
        return [system for system in systems if system.get("id") in allowlist]

    def list_managed_systems(self) -> list[dict[str, Any]]:
        """Return managed systems visible to this client."""
        if self._settings.hmc_demo_mode:
            return cast(list[dict[str, Any]], self._demo_fixture("list_managed_systems"))
        response = self._session.request("GET", MANAGED_SYSTEMS_PATH)
        result = self._filter_allowed_systems(parse_feed_entries(response.text))
        return ensure_json_serializable(result)

    def get_managed_system(self, managed_system_id: str) -> dict[str, Any]:
        """Return details for a single managed system."""
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_managed_system"))
        system_id = self._check_allowlist(managed_system_id)
        path = routes.managed_system_path(system_id)
        response = self._session.request("GET", path, accept=ACCEPT_UOM_XML)
        properties = parse_resource_properties(response.text)
        result = normalize_resource(system_id, properties, uri=path)
        return ensure_json_serializable(result)

    def list_lpars(self, managed_system_id: str) -> list[dict[str, Any]]:
        """Return LPARs for the given managed system UUID."""
        if self._settings.hmc_demo_mode:
            return cast(list[dict[str, Any]], self._demo_fixture("list_lpars"))
        system_id = self._check_allowlist(managed_system_id)
        path = routes.logical_partition_collection_path(system_id)
        response = self._session.request("GET", path)
        result = parse_feed_entries(response.text)
        return ensure_json_serializable(result)

    def get_lpar_status(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        """Return normalized status for a single LPAR."""
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_lpar_status"))
        system_id = self._check_allowlist(managed_system_id)
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")

        if self._settings.hmc_lpar_status_source == "quick":
            raw_quick: dict[str, str] = {}
            for prop in LPAR_QUICK_PROPERTIES:
                qpath = routes.logical_partition_quick_property_path(lpar_uuid, prop)
                qresp = self._session.request("GET", qpath, accept=ACCEPT_UOM_XML)
                raw_quick.update(parse_quick_properties(qresp.text))
            quick_state = raw_quick.get("PartitionState")
            result = drop_none(
                {
                    "managed_system_id": system_id,
                    "lpar_id": lpar_uuid,
                    "source": "quick",
                    "name": raw_quick.get("PartitionName"),
                    "state": quick_state,
                    "canonical_state": normalize_lpar_state(quick_state),
                    "partition_id": raw_quick.get("PartitionID"),
                    "rmc_state": raw_quick.get("RMCState"),
                    "raw_quick": raw_quick,
                },
            )
            return ensure_json_serializable(result)

        path = routes.logical_partition_path(system_id, lpar_uuid)
        response = self._session.request("GET", path, accept=ACCEPT_UOM_XML)
        properties = parse_resource_properties(response.text)
        uom_state = properties.get("PartitionState") or properties.get("State")
        result = drop_none(
            {
                "managed_system_id": system_id,
                "lpar_id": lpar_uuid,
                "source": "uom",
                "name": properties.get("PartitionName"),
                "state": uom_state,
                "canonical_state": normalize_lpar_state(uom_state),
                "partition_id": properties.get("PartitionID"),
                "rmc_state": properties.get("RMCState"),
                "properties": properties,
            },
        )
        return ensure_json_serializable(result)

    def get_lpar(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        """Return detailed information for a single LPAR."""
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_lpar"))
        system_id = self._check_allowlist(managed_system_id)
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")
        path = routes.logical_partition_path(system_id, lpar_uuid)
        response = self._session.request("GET", path, accept=ACCEPT_UOM_XML)
        properties = parse_resource_properties(response.text)
        result = normalize_resource(lpar_uuid, properties, uri=path)
        result["managed_system_id"] = system_id
        return ensure_json_serializable(result)

    def get_lpar_quick(self, lpar_id: str) -> dict[str, Any]:
        """[PLACEHOLDER] Fetch LPAR properties via the composite quick endpoint.

        The composite endpoint (``GET .../LogicalPartition/{uuid}/quick``)
        returns multiple quick properties in a single round trip and is
        materially faster than the current per-property fan-out path
        (``HMC_LPAR_STATUS_SOURCE=quick`` makes 4 GETs today).

        .. note::
            [RISK] The composite quick-property endpoint shape varies by
            firmware version (JSON vs ``application/xml;type=PartitionQuickProperties``)
            and is not supported on all HMC versions.  Wiring this method
            requires latency measurements confirming the quick endpoint is
            faster than the full UOM GET, documented in
            ``docs/hmc-compatibility.md`` 'LPAR Composite Quick Endpoint'.

        The :data:`Settings.hmc_prefer_quick_properties` feature flag
        (``HMC_PREFER_QUICK_PROPERTIES`` env, default ``False``) must be ``True``
        to activate this method once it is wired.  Until B2 firmware
        validation is complete, this returns a placeholder shape so callers
        can reason about the contract.
        """
        validated = validate_resource_id(lpar_id, field="lpar_id")
        return ensure_json_serializable(
            {
                "lpar_id": validated,
                "placeholder": True,
                "message": (
                    "[PLACEHOLDER] Composite quick-property endpoint not yet "
                    "wired. Pending firmware-version latency validation. "
                    "See docs/hmc-compatibility.md 'LPAR Composite Quick Endpoint'."
                ),
            },
        )

    def list_partition_profiles(self, lpar_id: str) -> list[dict[str, Any]]:
        """Return partition profiles for an LPAR."""
        if self._settings.hmc_demo_mode:
            return cast(list[dict[str, Any]], self._demo_fixture("list_partition_profiles"))
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")
        path = routes.logical_partition_profiles_path(lpar_uuid)
        response = self._session.request("GET", path)
        result = parse_feed_entries(response.text)
        return ensure_json_serializable(result)

    def get_capacity(
        self,
        managed_system_id: str,
        *,
        mode: CapacityOutputMode = "metadata",
    ) -> dict[str, Any]:
        """Return PCM processed metrics information for a managed system."""
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_capacity"))
        system_id = self._check_allowlist(managed_system_id)
        start_ts = (datetime.now(UTC) - timedelta(minutes=10)).strftime("%Y-%m-%dT%H:%M:%SZ")
        path = routes.pcm_processed_metrics_path(system_id)
        response = self._session.request(
            "GET",
            path,
            params={"StartTS": start_ts, "NoOfSamples": 1},
        )
        raw_samples = parse_pcm_metrics_feed(response.text)
        normalized = normalize_pcm_samples_for_agent(raw_samples)

        base: dict[str, Any] = {
            "managed_system_id": system_id,
            "mode": mode,
            "window_start_ts": start_ts,
            "pcm_enabled": bool(raw_samples),
        }

        if mode == "metadata":
            base["samples"] = normalized
        elif mode == "summary":
            base["summary"] = pcm_summary(raw_samples)
        elif mode == "full":
            raise HmcValidationError(
                "mode='full' is not implemented in Phase A. Use mode='metadata' or "
                "mode='summary'. Full PCM metric JSON retrieval is planned for Phase B.",
            )
        return ensure_json_serializable(drop_none(base))

    def get_capacity_full(
        self,
        managed_system_id: str,
        metrics_href: str,
    ) -> dict[str, Any]:
        """Fetch and parse PCM metric JSON from a ``metrics_href`` URL.

        Applies a size guard before parsing: if the response body exceeds
        ``HMC_MAX_METRICS_BYTES`` (default 10 MB), raises
        :class:`HmcResponseTooLargeError` immediately so the process never
        tries to deserialise a multi-hundred-MB firmware dump.

        After parsing, delegates to :func:`_pcm_cpu_aggregates` to produce
        CPU utilisation aggregates (``min_cpu_pct``, ``max_cpu_pct``,
        ``avg_cpu_pct``) from the ``systemUtil`` object in the response.

        .. note::
            [PLACEHOLDER] The actual HTTP fetch is not yet implemented.
            Phase B2-7b will replace the stub body with the real
            ``self._session.request("GET", metrics_href)`` call.  The PCM
            field name (``utilizedProcUnits``) and JSON shape are confirmed
            against IBM Docs (Power9/10/11) — see ``docs/hmc-compatibility.md``
            'PCM Metric JSON Field Names'.
        """
        system_id = self._check_allowlist(managed_system_id)
        if not metrics_href or not metrics_href.strip():
            raise HmcValidationError("metrics_href must be a non-empty URL string")

        # [PLACEHOLDER] Phase B2-7b: replace this block with a real
        # _session.request() call.  The fetch must:
        #   1. GET metrics_href (relative path against base_url).
        #   2. Check len(response.content) against self._settings.hmc_max_metrics_bytes
        #      BEFORE calling response.json() — see size guard helper below.
        #   3. Parse the JSON and pass response.json().get("systemUtil", {})
        #      to _pcm_cpu_aggregates().
        # For now, return a stub so the interface and size-guard path are testable.

        # [PLACEHOLDER] Phase B2-7b: call self._check_metrics_response_size(response.content)
        # before json.loads() once the real fetch is wired.

        aggregates = _pcm_cpu_aggregates({})  # placeholder — no real samples yet
        # CPU aggregate keys are always present (None until Phase B2 fetches real data);
        # do not drop them — their presence in the response documents the API shape.
        return ensure_json_serializable(
            {
                "managed_system_id": system_id,
                "metrics_href": metrics_href,
                "placeholder": True,
                "message": (
                    "[PLACEHOLDER] PCM full metric fetch not yet implemented; "
                    "Phase B2-7b will wire the real HTTP call. "
                    "PCM field shape (utilizedProcUnits / "
                    "utilizedProcUnitsDeductIdle) is confirmed against IBM "
                    "Docs Power9/10/11."
                ),
                **aggregates,
            }
        )

    def is_authenticated(self) -> bool:
        """Return True when an HMC session token is currently held.

        Used by D3 readiness probes; does not trigger HMC traffic. Demo
        mode never holds a real session, so the predicate is always False
        in demo mode (probe handlers special-case demo separately).
        """
        if self._settings.hmc_demo_mode:
            return False
        return self._session._session_token is not None

    def health_check(self) -> dict[str, Any]:
        """Verify HMC connectivity and active session without returning partition data."""
        if self._settings.hmc_demo_mode:
            return ensure_json_serializable(
                drop_none(
                    {
                        "status": "ok",
                        "hmc_host": self._settings.hmc_host,
                        "session_active": False,
                        "managed_system_count": 1,
                    }
                )
            )
        self._session._ensure_session()
        response = self._session.request("GET", MANAGED_SYSTEMS_PATH)
        systems = self._filter_allowed_systems(parse_feed_entries(response.text))
        result = drop_none(
            {
                "status": "ok",
                "hmc_host": self._settings.hmc_host,
                "session_active": self._session._session_token is not None,
                "managed_system_count": len(systems),
            },
        )
        return ensure_json_serializable(result)

    def _require_authorization(
        self,
        authorization: object,
        *,
        operation: str,
    ) -> WriteAuthorization:
        """Refuse to mutate without a real :class:`WriteAuthorization`.

        Defense in depth alongside the type signature: catches ``cast()``
        abuse and any caller that bypasses the write-tool decorator. The only
        legitimate source of a :class:`WriteAuthorization` is
        :mod:`power_hmc_mcp.tools.write`.
        """
        if not isinstance(authorization, WriteAuthorization):
            raise TypeError(
                f"{operation} requires a WriteAuthorization issued via the write-tool "
                "decorator (power_hmc_mcp.tools.write.run_write_tool); refusing to mutate.",
            )
        if authorization.operation != operation:
            raise ValueError(
                f"WriteAuthorization is for operation={authorization.operation!r}, "
                f"not {operation!r}; refusing to mutate.",
            )
        return authorization

    def execute_job(
        self,
        managed_system_id: str,
        lpar_id: str,
        operation_name: str,
        job_parameters_xml: str,
        *,
        authorization: WriteAuthorization,
    ) -> str:
        """[PLACEHOLDER] Submit a JobRequest and return the job ID from the Location header.

        Phase C IBM job grammar (URL shape [VALIDATED — IBM Docs Power10/11]):

        1. ``GET .../do/{OP}`` — fetch JobRequest XSD template
        2. ``PUT .../jobs`` — submit populated JobRequest XML body
        3. Parse job ID from ``Location`` response header

        The ``{OP}`` name and XML namespace remain ``[ASSUMPTION]`` until B2
        firmware capture lands in ``docs/hmc-compatibility.md``.

        [ASSUMPTION] Location header carries ``/rest/api/uom/.../jobs/{jobId}``.
        """
        self._require_authorization(authorization, operation=authorization.operation)
        self._check_allowlist(managed_system_id)
        raise HmcNotImplementedError(
            "execute_job is not wired yet — Phase C blocked on B2 firmware capture",
        )

    def poll_job_status(
        self,
        managed_system_id: str,
        lpar_id: str,
        job_id: str,
        *,
        poll_interval_seconds: float = 2.0,
        max_polls: int = 30,
    ) -> dict[str, Any]:
        """[PLACEHOLDER] Poll job status until terminal state or timeout.

        Polls ``GET logical_partition_job_status_path(...)`` until Status is
        terminal. Terminal states ``Completed`` and ``Failed`` are
        ``[ASSUMPTION]`` pending B2 capture.
        """
        self._check_allowlist(managed_system_id)
        raise HmcNotImplementedError(
            "poll_job_status is not wired yet — Phase C blocked on B2 firmware capture",
        )

    def create_lpar_from_profile(
        self,
        managed_system_id: str,
        profile_name: str,
        new_lpar_name: str,
        overrides: dict[str, Any] | None = None,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return self._demo_write_response("create_lpar_from_profile")
        from power_hmc_mcp.guardrails import placeholder_execute_response

        auth = self._require_authorization(authorization, operation="create_lpar_from_profile")
        system_id = self._check_allowlist(managed_system_id)
        preview_path = routes.logical_partition_create_from_profile_path(system_id)
        params = {
            "managed_system_id": system_id,
            "profile_name": profile_name,
            "new_lpar_name": new_lpar_name,
            "overrides": overrides or {},
        }
        return placeholder_execute_response(
            "create_lpar_from_profile",
            params,
            preview_method="POST",
            preview_path=preview_path,
            authorization=auth,
        )

    @staticmethod
    def _demo_write_response(operation: str) -> dict[str, Any]:
        """Stable write-tool response shape returned when demo mode is active."""
        return {
            "executed": False,
            "demo": True,
            "operation": operation,
            "message": "Demo mode active — no HMC calls made",
            "suggested_next_step": (
                "Demo mode is active — no HMC calls are made. "
                "Set HMC_DEMO_MODE=false to execute against a real HMC."
            ),
        }

    def start_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return self._demo_write_response("start_lpar")
        from power_hmc_mcp.guardrails import placeholder_execute_response

        auth = self._require_authorization(authorization, operation="start_lpar")
        system_id = self._check_allowlist(managed_system_id)
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")
        preview_path = routes.logical_partition_start_job_path(system_id, lpar_uuid)
        params = {"managed_system_id": system_id, "lpar_id": lpar_uuid}
        return placeholder_execute_response(
            "start_lpar",
            params,
            preview_method="POST",
            preview_path=preview_path,
            authorization=auth,
        )

    def stop_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        mode: str = "normal",
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return self._demo_write_response("stop_lpar")
        from power_hmc_mcp.guardrails import placeholder_execute_response

        auth = self._require_authorization(authorization, operation="stop_lpar")
        system_id = self._check_allowlist(managed_system_id)
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")
        preview_path = routes.logical_partition_stop_job_path(system_id, lpar_uuid)
        params = {"managed_system_id": system_id, "lpar_id": lpar_uuid, "mode": mode}
        return placeholder_execute_response(
            "stop_lpar",
            params,
            preview_method="POST",
            preview_path=preview_path,
            authorization=auth,
        )
