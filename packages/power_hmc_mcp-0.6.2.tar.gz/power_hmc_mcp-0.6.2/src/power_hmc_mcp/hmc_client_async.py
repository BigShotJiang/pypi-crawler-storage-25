"""Async pair of :mod:`power_hmc_mcp.hmc_client` (read-method surface).

Phase D introduced this module behind a Phase-D-internal seam: ``HmcAsyncClient``
exposes the same read-method surface as :class:`~power_hmc_mcp.hmc_client.HmcClient`
on top of :class:`~power_hmc_mcp.session_async.HmcAsyncSession`. Demo mode
behaves identically (no HMC traffic, fixture-backed responses).

Write methods are deferred — the existing sync client is the supported path
for writes (stdio / streamable-HTTP single-HMC). The async pool is
introduced primarily for D5 multi-HMC under streamable-HTTP and for the
upcoming OpenTelemetry-aware retry paths.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, cast

import httpx

from power_hmc_mcp import observability, routes
from power_hmc_mcp.config import CapacityOutputMode, Settings, load_settings
from power_hmc_mcp.exceptions import HmcHttpError, HmcResponseTooLargeError, HmcValidationError
from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates  # shared, pure helper
from power_hmc_mcp.hmc_xml import (
    parse_feed_entries,
    parse_pcm_metrics_feed,
    parse_quick_properties,
    parse_resource_properties,
)
from power_hmc_mcp.http_policy import (
    retry_sleep_async as retry_sleep_async,  # noqa: F401 — explicit re-export so session_async.py late-import (hmc_client_async.retry_sleep_async) survives no_implicit_reexport and unittest.mock.patch keeps its hook
)
from power_hmc_mcp.normalize import (
    normalize_lpar_state,
    normalize_pcm_samples_for_agent,
    normalize_resource,
    pcm_summary,
)
from power_hmc_mcp.serialize import drop_none, ensure_json_serializable
from power_hmc_mcp.session_async import (
    ACCEPT_ATOM,  # noqa: F401 — re-export for symmetry with hmc_client
    ACCEPT_UOM_XML,
    HmcAsyncSession,
)
from power_hmc_mcp.validation import validate_resource_id

# Re-export for tests and symmetry with the sync client.
LOGON_PATH = routes.LOGON_PATH
MANAGED_SYSTEMS_PATH = routes.MANAGED_SYSTEMS_PATH
LPAR_PROFILES_PATH = routes.LPAR_PROFILES_PATH
PCM_PROCESSED_METRICS_PATH = routes.PCM_PROCESSED_METRICS_PATH
SESSION_HEADER = routes.SESSION_HEADER

# Same property tuple used by the sync client (firmware-doc-aligned).
LPAR_QUICK_PROPERTIES = (
    "PartitionState",
    "PartitionName",
    "PartitionID",
    "RMCState",
)


class HmcAsyncClient:
    """Async client for IBM Power HMC REST read operations."""

    def __init__(
        self,
        settings: Settings | None = None,
        *,
        session: HmcAsyncSession | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        if session is not None:
            self._session = session
            self._settings = session.settings
        else:
            self._settings = settings or load_settings()
            self._session = HmcAsyncSession(self._settings, http_client=http_client)

    @property
    def settings(self) -> Settings:
        return self._settings

    async def login(self) -> None:
        hint = self._settings.hmc_api_version_hint
        if self._settings.hmc_demo_mode:
            observability.log_logon_end(
                self._settings.hmc_host,
                outcome="demo",
                api_version_hint=hint,
            )
            return
        await self._session.login()
        observability.log_logon_end(
            self._settings.hmc_host,
            outcome="success",
            api_version_hint=hint,
        )

    async def close(self) -> None:
        hint = self._settings.hmc_api_version_hint
        if self._settings.hmc_demo_mode:
            observability.log_logoff_end(
                self._settings.hmc_host,
                outcome="demo",
                api_version_hint=hint,
            )
            return
        try:
            await self._session.close()
        except HmcHttpError:
            observability.log_logoff_end(
                self._settings.hmc_host,
                outcome="error",
                api_version_hint=hint,
            )
            return
        observability.log_logoff_end(
            self._settings.hmc_host,
            outcome="success",
            api_version_hint=hint,
        )

    _DEMO_FIXTURES_DIR: Path = Path(__file__).parent / "demo_fixtures"

    def _demo_fixture(self, name: str) -> Any:
        path = self._DEMO_FIXTURES_DIR / f"{name}.json"
        return json.loads(path.read_text(encoding="utf-8"))

    async def __aenter__(self) -> HmcAsyncClient:
        await self.login()
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    def _check_metrics_response_size(self, body: bytes) -> None:
        if len(body) > self._settings.hmc_max_metrics_bytes:
            raise HmcResponseTooLargeError(
                f"PCM metrics response exceeds limit: "
                f"{len(body)} > {self._settings.hmc_max_metrics_bytes} bytes",
                max_bytes=self._settings.hmc_max_metrics_bytes,
                actual_bytes=len(body),
            )

    def _check_allowlist(self, managed_system_id: str) -> str:
        system_id = validate_resource_id(managed_system_id, field="managed_system_id")
        if not self._settings.is_managed_system_allowed(system_id):
            raise HmcValidationError(
                f"Managed system {system_id} is not in HMC_ALLOWED_MANAGED_SYSTEMS",
            )
        return system_id

    def _filter_allowed_systems(
        self,
        systems: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        allowlist = self._settings.allowed_managed_system_ids()
        if allowlist is None:
            return systems
        return [system for system in systems if system.get("id") in allowlist]

    async def list_managed_systems(self) -> list[dict[str, Any]]:
        if self._settings.hmc_demo_mode:
            return cast(list[dict[str, Any]], self._demo_fixture("list_managed_systems"))
        response = await self._session.request("GET", MANAGED_SYSTEMS_PATH)
        result = self._filter_allowed_systems(parse_feed_entries(response.text))
        return ensure_json_serializable(result)

    async def get_managed_system(self, managed_system_id: str) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_managed_system"))
        system_id = self._check_allowlist(managed_system_id)
        path = routes.managed_system_path(system_id)
        response = await self._session.request("GET", path, accept=ACCEPT_UOM_XML)
        properties = parse_resource_properties(response.text)
        result = normalize_resource(system_id, properties, uri=path)
        return ensure_json_serializable(result)

    async def list_lpars(self, managed_system_id: str) -> list[dict[str, Any]]:
        if self._settings.hmc_demo_mode:
            return cast(list[dict[str, Any]], self._demo_fixture("list_lpars"))
        system_id = self._check_allowlist(managed_system_id)
        path = routes.logical_partition_collection_path(system_id)
        response = await self._session.request("GET", path)
        result = parse_feed_entries(response.text)
        return ensure_json_serializable(result)

    async def get_lpar_status(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_lpar_status"))
        system_id = self._check_allowlist(managed_system_id)
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")

        if self._settings.hmc_lpar_status_source == "quick":
            raw_quick: dict[str, str] = {}
            for prop in LPAR_QUICK_PROPERTIES:
                qpath = routes.logical_partition_quick_property_path(lpar_uuid, prop)
                qresp = await self._session.request("GET", qpath, accept=ACCEPT_UOM_XML)
                raw_quick.update(parse_quick_properties(qresp.text))
            quick_state = raw_quick.get("PartitionState")
            result = drop_none(
                {
                    "managed_system_id": system_id,
                    "lpar_id": lpar_uuid,
                    "source": "quick",
                    "name": raw_quick.get("PartitionName"),
                    "state": quick_state,
                    "canonical_state": normalize_lpar_state(quick_state),
                    "partition_id": raw_quick.get("PartitionID"),
                    "rmc_state": raw_quick.get("RMCState"),
                    "raw_quick": raw_quick,
                },
            )
            return ensure_json_serializable(result)

        path = routes.logical_partition_path(system_id, lpar_uuid)
        response = await self._session.request("GET", path, accept=ACCEPT_UOM_XML)
        properties = parse_resource_properties(response.text)
        uom_state = properties.get("PartitionState") or properties.get("State")
        result = drop_none(
            {
                "managed_system_id": system_id,
                "lpar_id": lpar_uuid,
                "source": "uom",
                "name": properties.get("PartitionName"),
                "state": uom_state,
                "canonical_state": normalize_lpar_state(uom_state),
                "partition_id": properties.get("PartitionID"),
                "rmc_state": properties.get("RMCState"),
                "properties": properties,
            },
        )
        return ensure_json_serializable(result)

    async def get_lpar(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_lpar"))
        system_id = self._check_allowlist(managed_system_id)
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")
        path = routes.logical_partition_path(system_id, lpar_uuid)
        response = await self._session.request("GET", path, accept=ACCEPT_UOM_XML)
        properties = parse_resource_properties(response.text)
        result = normalize_resource(lpar_uuid, properties, uri=path)
        result["managed_system_id"] = system_id
        return ensure_json_serializable(result)

    async def list_partition_profiles(self, lpar_id: str) -> list[dict[str, Any]]:
        if self._settings.hmc_demo_mode:
            return cast(list[dict[str, Any]], self._demo_fixture("list_partition_profiles"))
        lpar_uuid = validate_resource_id(lpar_id, field="lpar_id")
        path = routes.logical_partition_profiles_path(lpar_uuid)
        response = await self._session.request("GET", path)
        result = parse_feed_entries(response.text)
        return ensure_json_serializable(result)

    async def get_capacity(
        self,
        managed_system_id: str,
        *,
        mode: CapacityOutputMode = "metadata",
    ) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return cast(dict[str, Any], self._demo_fixture("get_capacity"))
        system_id = self._check_allowlist(managed_system_id)
        start_ts = (datetime.now(UTC) - timedelta(minutes=10)).strftime("%Y-%m-%dT%H:%M:%SZ")
        path = routes.pcm_processed_metrics_path(system_id)
        response = await self._session.request(
            "GET",
            path,
            params={"StartTS": start_ts, "NoOfSamples": 1},
        )
        raw_samples = parse_pcm_metrics_feed(response.text)
        normalized = normalize_pcm_samples_for_agent(raw_samples)

        base: dict[str, Any] = {
            "managed_system_id": system_id,
            "mode": mode,
            "window_start_ts": start_ts,
            "pcm_enabled": bool(raw_samples),
        }

        if mode == "metadata":
            base["samples"] = normalized
        elif mode == "summary":
            base["summary"] = pcm_summary(raw_samples)
        elif mode == "full":
            raise HmcValidationError(
                "mode='full' is not implemented in Phase A. Use mode='metadata' or "
                "mode='summary'. Full PCM metric JSON retrieval is planned for Phase B.",
            )
        return ensure_json_serializable(drop_none(base))

    async def get_capacity_full(
        self,
        managed_system_id: str,
        metrics_href: str,
    ) -> dict[str, Any]:
        """[PLACEHOLDER] async mirror of :meth:`HmcClient.get_capacity_full`."""
        system_id = self._check_allowlist(managed_system_id)
        if not metrics_href or not metrics_href.strip():
            raise HmcValidationError("metrics_href must be a non-empty URL string")
        aggregates = _pcm_cpu_aggregates({})
        return ensure_json_serializable(
            {
                "managed_system_id": system_id,
                "metrics_href": metrics_href,
                "placeholder": True,
                "message": (
                    "[PLACEHOLDER] Async PCM full metric fetch not yet implemented; "
                    "Phase B2-7b will wire the real HTTP call. PCM field shape "
                    "(utilizedProcUnits / utilizedProcUnitsDeductIdle) is confirmed "
                    "against IBM Docs Power9/10/11."
                ),
                **aggregates,
            }
        )

    async def health_check(self) -> dict[str, Any]:
        if self._settings.hmc_demo_mode:
            return ensure_json_serializable(
                drop_none(
                    {
                        "status": "ok",
                        "hmc_host": self._settings.hmc_host,
                        "session_active": False,
                        "managed_system_count": 1,
                    }
                )
            )
        await self._session._ensure_session()
        response = await self._session.request("GET", MANAGED_SYSTEMS_PATH)
        systems = self._filter_allowed_systems(parse_feed_entries(response.text))
        result = drop_none(
            {
                "status": "ok",
                "hmc_host": self._settings.hmc_host,
                "session_active": self._session._session_token is not None,
                "managed_system_count": len(systems),
            },
        )
        return ensure_json_serializable(result)

    def is_authenticated(self) -> bool:
        """Return True when an HMC session token is held.

        Used by D3 readiness probes; does not trigger HMC traffic.
        """
        if self._settings.hmc_demo_mode:
            return False
        return self._session._session_token is not None
