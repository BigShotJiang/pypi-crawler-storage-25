"""MCP server entrypoint for power-hmc-mcp."""

from __future__ import annotations

import atexit
import logging

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from power_hmc_mcp.config import load_settings
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.logging_utils import configure_logging
from power_hmc_mcp.pool import HmcClientPool
from power_hmc_mcp.probes import register_probes
from power_hmc_mcp.registry import build_registry
from power_hmc_mcp.tools import register_tools

logger = logging.getLogger(__name__)

mcp = FastMCP("power-hmc-mcp", json_response=True)
_pool: HmcClientPool | None = None


def _shutdown_client() -> None:
    global _pool
    if _pool is not None:
        _pool.close_all()
        _pool = None


def main() -> None:
    global _pool
    load_dotenv()
    settings = load_settings()
    configure_logging(settings=settings)
    registry = build_registry(settings)
    _pool = HmcClientPool(registry)
    atexit.register(_shutdown_client)
    if settings.hmc_demo_mode:
        logger.warning(
            "DEMO MODE ACTIVE — all HMC calls are mocked; "
            "no real HMC connection will be made (HMC_DEMO_MODE=true)"
        )
    if settings.hmc_api_version_hint:
        logger.info(
            "HMC_API_VERSION_HINT=%s (logging hint only — does not flip "
            "firmware-gated behavior; see docs/hmc-compatibility.md)",
            settings.hmc_api_version_hint,
        )
    aliases = registry.aliases()
    if len(aliases) > 1:
        logger.info(
            "HMC registry: %d aliases (default=%s, others=%s)",
            len(aliases),
            registry.default_alias,
            ", ".join(a for a in aliases if a != registry.default_alias),
        )
    default_client: HmcClient = _pool.get_default_sync()
    default_client.login()
    register_tools(mcp, _pool)
    logger.info(
        "Starting power-hmc-mcp MCP server host=%s transport=%s",
        settings.hmc_host,
        settings.hmc_mcp_transport,
    )
    try:
        transport = settings.hmc_mcp_transport
        if transport == "streamable-http":
            mcp.settings.host = settings.hmc_mcp_http_host
            mcp.settings.port = settings.hmc_mcp_http_port
            mcp.settings.streamable_http_path = settings.hmc_mcp_http_path
            # D3: probes are HTTP-only — never registered for stdio.
            # register_probes() is a no-op when HMC_MCP_HTTP_PROBES_PATH is unset.
            register_probes(mcp, default_client, settings)
        mcp.run(transport=transport)
    finally:
        _shutdown_client()


if __name__ == "__main__":
    main()
