"""MCP server exposing IBM Power HMC operations as typed tools."""

__version__ = "0.6.0"
