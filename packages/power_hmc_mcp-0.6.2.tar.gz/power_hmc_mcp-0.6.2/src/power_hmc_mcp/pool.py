"""HMC client pool keyed by ``(alias, mode)`` (Phase D, D5).

Pools :class:`~power_hmc_mcp.hmc_client.HmcClient` and
:class:`~power_hmc_mcp.hmc_client_async.HmcAsyncClient` instances by
``(alias, mode)`` so a single process can address multiple HMCs over
either transport without spinning up a fresh login per call.

Key invariants:

* The keying tuple is ``(alias, mode)`` where ``mode`` is ``"sync"`` or
  ``"async"`` — a sync and async client for the same alias have
  independent HMC sessions and **must not** share a token. Mixing the
  two on a single token would race ``# SYNC-ONLY`` and ``# ASYNC``
  retry/throttle helpers (see ``http_policy.py`` markers).
* Lazy construction: clients are built on first access. The default
  alias is eager-built only when :meth:`get_default_sync` is called,
  preserving the v0.x boot sequence semantics (login at startup).
* Process-wide settings (allowlists, retries, write guardrails, log
  config) apply uniformly via the registry's
  :meth:`~power_hmc_mcp.registry.HmcRegistry.settings_for` overlay.

This module is the single point of truth for "which HmcClient should
this tool call use right now" given an optional ``hmc_alias`` argument.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Literal

from power_hmc_mcp.exceptions import HmcValidationError
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.hmc_client_async import HmcAsyncClient
from power_hmc_mcp.registry import HmcRegistry

__all__ = [
    "ClientResolver",
    "HmcClientPool",
    "single_client_resolver",
]

logger = logging.getLogger(__name__)

ClientMode = Literal["sync", "async"]
ClientResolver = Callable[[str | None], HmcClient]


class HmcClientPool:
    """Lazy ``(alias, mode)``-keyed client pool.

    Constructs ``HmcClient`` / ``HmcAsyncClient`` on first access and
    caches them. ``close_all()`` closes every cached client; safe to
    call from atexit or shutdown handlers.
    """

    def __init__(self, registry: HmcRegistry) -> None:
        self._registry = registry
        self._sync: dict[str, HmcClient] = {}
        self._async: dict[str, HmcAsyncClient] = {}

    @property
    def registry(self) -> HmcRegistry:
        return self._registry

    @property
    def default_alias(self) -> str:
        return self._registry.default_alias

    def aliases(self) -> tuple[str, ...]:
        return self._registry.aliases()

    def _resolve_alias(self, alias: str | None) -> str:
        if alias is None or alias == "":
            return self.default_alias
        normalised = alias.strip().lower()
        if normalised not in self._registry:
            raise HmcValidationError(
                f"Unknown HMC alias {alias!r}; known aliases: "
                f"{', '.join(self._registry.aliases())}",
            )
        return normalised

    def get_sync(self, alias: str | None) -> HmcClient:
        resolved = self._resolve_alias(alias)
        client = self._sync.get(resolved)
        if client is None:
            settings = self._registry.settings_for(resolved)
            client = HmcClient(settings)
            self._sync[resolved] = client
            logger.debug("HmcClientPool: built sync client for alias=%s", resolved)
        return client

    def get_async(self, alias: str | None) -> HmcAsyncClient:
        resolved = self._resolve_alias(alias)
        client = self._async.get(resolved)
        if client is None:
            settings = self._registry.settings_for(resolved)
            client = HmcAsyncClient(settings)
            self._async[resolved] = client
            logger.debug("HmcClientPool: built async client for alias=%s", resolved)
        return client

    def get_default_sync(self) -> HmcClient:
        """Return (eagerly construct if needed) the default-alias sync client."""
        return self.get_sync(self.default_alias)

    def close_all(self) -> None:
        """Close every cached client. Async clients can only be closed inside an event loop."""
        for alias, client in list(self._sync.items()):
            try:
                client.close()
            except Exception:
                logger.exception("HmcClientPool.close_all: sync alias=%s close failed", alias)
            self._sync.pop(alias, None)
        if self._async:
            logger.debug(
                "HmcClientPool.close_all: %d async clients still cached "
                "(close them from within their owning event loop)",
                len(self._async),
            )

    # --- ergonomics -------------------------------------------------------

    def sync_resolver(self) -> ClientResolver:
        """Return a callable suitable for tool-time alias resolution."""
        return self.get_sync


def single_client_resolver(client: HmcClient) -> ClientResolver:
    """Wrap a single :class:`HmcClient` as a :data:`ClientResolver`.

    Used by tests / single-HMC code paths that pre-date D5. The resolver
    rejects any alias that does not match the client's default alias —
    mirroring :meth:`HmcClientPool._resolve_alias` semantics.
    """
    expected = client.settings.hmc_default_alias

    def resolver(alias: str | None) -> HmcClient:
        if alias is None or alias == "" or alias.strip().lower() == expected:
            return client
        raise HmcValidationError(
            f"Unknown HMC alias {alias!r}; only the default alias {expected!r} "
            "is configured (set HMC_REGISTRY to expose more)",
        )

    return resolver
