"""Tests for the HMC REST client."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any
from unittest.mock import patch

import httpx
import pytest
import respx

from power_hmc_mcp import observability
from power_hmc_mcp.config import Settings
from power_hmc_mcp.exceptions import (
    HmcAuthError,
    HmcHttpError,
    HmcParseError,
    HmcValidationError,
)
from power_hmc_mcp.hmc_client import LOGON_PATH, MANAGED_SYSTEMS_PATH, SESSION_HEADER, HmcClient
from tests.conftest import apply_hmc_env

TEST_SESSION = "test-session-token-abc123"
SYSTEM_ID = "38f2a140-b30f-8544-7a1b-2c3d4e5f1234"
LPAR_ID = "11111111-1111-2222-3333-444455556666"


def test_login_sets_session_header(hmc_client: HmcClient, hmc_routes: respx.MockRouter) -> None:
    hmc_client.login()
    route = hmc_routes.calls[-1]
    assert route.request.method == "PUT"
    assert route.request.url.path.endswith(LOGON_PATH)

    hmc_client.list_managed_systems()
    get_call = hmc_routes.calls[-1]
    assert get_call.request.headers[SESSION_HEADER] == TEST_SESSION


def test_list_managed_systems_parses_feed(hmc_client: HmcClient) -> None:
    systems = hmc_client.list_managed_systems()
    assert len(systems) == 2
    assert systems[0]["id"] == SYSTEM_ID
    assert systems[0]["name"] == "p9-SiteA"
    assert systems[0]["state"] == "operating"


def test_list_lpars_uses_system_uuid_in_path(
    hmc_client: HmcClient,
    hmc_routes: respx.MockRouter,
) -> None:
    lpars = hmc_client.list_lpars(SYSTEM_ID)
    assert len(lpars) == 2
    assert lpars[0]["name"] == "AIX01"
    assert lpars[0]["partition_id"] == "2"
    last = hmc_routes.calls[-1]
    assert SYSTEM_ID in str(last.request.url)


def test_get_lpar_status_uom_document(hmc_client: HmcClient, hmc_routes: respx.MockRouter) -> None:
    status = hmc_client.get_lpar_status(SYSTEM_ID, LPAR_ID)
    assert status["lpar_id"] == LPAR_ID
    assert status["managed_system_id"] == SYSTEM_ID
    assert status["source"] == "uom"
    assert status["name"] == "AIX01"
    assert status["state"] == "running"
    assert status["canonical_state"] == "running"
    assert status["partition_id"] == "2"
    assert status["rmc_state"] == "active"
    assert status["properties"]["PartitionState"] == "running"
    lpar_calls = [
        c
        for c in hmc_routes.calls
        if f"/LogicalPartition/{LPAR_ID}" in str(c.request.url)
        and "/quick/" not in str(c.request.url)
    ]
    assert len(lpar_calls) >= 1


def test_get_lpar_status_quick_source(
    monkeypatch: pytest.MonkeyPatch,
    hmc_routes: respx.MockRouter,
) -> None:
    """HMC_LPAR_STATUS_SOURCE=quick fans out per-property GETs and populates canonical_state.

    Covers the second branch of get_lpar_status (which B2-1 added a
    canonical_state field to) so the quick-source path is exercised in unit
    tests alongside the default uom path.
    """
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_LPAR_STATUS_SOURCE", "quick")
    settings = Settings()
    assert settings.hmc_lpar_status_source == "quick"
    client = HmcClient(settings)
    status = client.get_lpar_status(SYSTEM_ID, LPAR_ID)
    assert status["source"] == "quick"
    assert status["lpar_id"] == LPAR_ID
    assert status["state"] == "running"
    assert status["canonical_state"] == "running"
    assert status["name"] == "AIX01"
    assert status["partition_id"] == "2"
    assert status["rmc_state"] == "active"
    assert "raw_quick" in status

    quick_calls = [c for c in hmc_routes.calls if "/quick/" in str(c.request.url)]
    assert len(quick_calls) == 4, "expected one GET per quick property"


def test_http_401_after_reauth_raises_auth_error(
    hmc_settings,
    hmc_routes: respx.MockRouter,
) -> None:
    base = hmc_settings.base_url
    hmc_routes.get(f"{base}{MANAGED_SYSTEMS_PATH}").respond(status_code=401)
    client = HmcClient(hmc_settings)
    with pytest.raises(HmcAuthError, match="re-authentication failed"):
        client.list_managed_systems()
    assert "super-secret" not in str(client._settings.hmc_password)


def test_http_401_retries_login_once(hmc_settings, respx_mock: respx.MockRouter) -> None:
    base = hmc_settings.base_url
    systems_route = respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}")
    systems_route.side_effect = [
        httpx.Response(401, request=httpx.Request("GET", f"{base}{MANAGED_SYSTEMS_PATH}")),
        httpx.Response(
            200,
            text=(Path(__file__).parent / "fixtures" / "managed_systems_feed.xml").read_text(
                encoding="utf-8",
            ),
            request=httpx.Request("GET", f"{base}{MANAGED_SYSTEMS_PATH}"),
        ),
    ]
    respx_mock.put(f"{base}{LOGON_PATH}").respond(
        status_code=200,
        headers={SESSION_HEADER: TEST_SESSION},
    )
    client = HmcClient(hmc_settings)
    systems = client.list_managed_systems()
    assert len(systems) == 2
    assert systems_route.call_count == 2
    logon_calls = [c for c in respx_mock.calls if c.request.method == "PUT"]
    assert len(logon_calls) >= 1


def test_logon_failure_raises_auth_error(hmc_settings, respx_mock: respx.MockRouter) -> None:
    base = hmc_settings.base_url
    respx_mock.put(f"{base}{LOGON_PATH}").respond(status_code=401, text="denied")
    client = HmcClient(hmc_settings)
    with pytest.raises(HmcAuthError):
        client.login()


def test_logon_missing_session_header_raises_auth_error(
    hmc_settings,
    respx_mock: respx.MockRouter,
) -> None:
    base = hmc_settings.base_url
    respx_mock.put(f"{base}{LOGON_PATH}").respond(status_code=200, text="ok")
    client = HmcClient(hmc_settings)
    with pytest.raises(HmcAuthError):
        client.login()


def test_close_sends_logoff(hmc_client: HmcClient, hmc_routes: respx.MockRouter) -> None:
    hmc_client.login()
    hmc_client.close()
    delete_calls = [c for c in hmc_routes.calls if c.request.method == "DELETE"]
    assert delete_calls
    assert delete_calls[-1].request.headers[SESSION_HEADER] == TEST_SESSION


def test_is_authenticated_tracks_session_token(
    hmc_client: HmcClient,
    hmc_routes: respx.MockRouter,
) -> None:
    """``is_authenticated()`` mirrors session-token presence (D3 readiness probe input)."""
    assert hmc_client.is_authenticated() is False
    hmc_client.login()
    assert hmc_client.is_authenticated() is True
    hmc_client.close()
    assert hmc_client.is_authenticated() is False


def test_is_authenticated_false_in_demo_mode(demo_hmc_client: HmcClient) -> None:
    """Demo mode never holds a real session — predicate is always False."""
    demo_hmc_client.login()
    assert demo_hmc_client.is_authenticated() is False


def test_write_client_method_returns_placeholder_when_authorized(
    hmc_client: HmcClient,
) -> None:
    from power_hmc_mcp.guardrails import _issue_authorization

    auth = _issue_authorization(operation="start_lpar", correlation_id="cid-test")
    out = hmc_client.start_lpar(SYSTEM_ID, LPAR_ID, authorization=auth)
    assert out["placeholder"] is True
    assert out["executed"] is False
    assert out["audit"]["record_status"] == "placeholder"
    assert out["audit"]["correlation_id"] == "cid-test"


def test_write_client_method_refuses_without_authorization(
    hmc_client: HmcClient,
) -> None:
    """`cast()` abuse and bare TypeError calls hit the runtime isinstance check."""
    from typing import cast

    from power_hmc_mcp.guardrails import WriteAuthorization

    with pytest.raises(TypeError, match="WriteAuthorization"):
        hmc_client.start_lpar(
            SYSTEM_ID,
            LPAR_ID,
            authorization=cast(WriteAuthorization, "not a real authorization"),
        )


def test_write_client_method_refuses_mismatched_operation(hmc_client: HmcClient) -> None:
    from power_hmc_mcp.guardrails import _issue_authorization

    wrong_auth = _issue_authorization(operation="stop_lpar", correlation_id="cid-x")
    with pytest.raises(ValueError, match="operation="):
        hmc_client.start_lpar(SYSTEM_ID, LPAR_ID, authorization=wrong_auth)


def test_malformed_xml_raises_hmc_parse_error(
    hmc_settings,
    respx_mock: respx.MockRouter,
) -> None:
    base = hmc_settings.base_url
    respx_mock.put(f"{base}{LOGON_PATH}").respond(
        status_code=200,
        headers={SESSION_HEADER: TEST_SESSION},
    )
    respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}").respond(text="<<<invalid")
    client = HmcClient(hmc_settings)
    with pytest.raises(HmcParseError):
        client.list_managed_systems()


def test_invalid_resource_id_rejected(hmc_client: HmcClient) -> None:
    with pytest.raises(HmcValidationError):
        hmc_client.list_lpars("../evil")


def test_tool_outputs_json_serializable(hmc_client: HmcClient) -> None:
    systems = hmc_client.list_managed_systems()
    json.dumps(systems)
    status = hmc_client.get_lpar_status(SYSTEM_ID, LPAR_ID)
    json.dumps(status)
    assert "name" in status


def test_login_timeout_raises_hmc_http_error(
    hmc_settings,
    respx_mock: respx.MockRouter,
) -> None:
    base = hmc_settings.base_url
    request = httpx.Request("PUT", f"{base}{LOGON_PATH}")
    respx_mock.put(f"{base}{LOGON_PATH}").mock(
        side_effect=httpx.TimeoutException("timed out", request=request),
    )
    client = HmcClient(hmc_settings)
    with pytest.raises(HmcHttpError, match="timed out"):
        client.login()


def test_get_managed_system(hmc_client: HmcClient) -> None:
    system = hmc_client.get_managed_system(SYSTEM_ID)
    assert system["id"] == SYSTEM_ID
    assert system["name"] == "p9-SiteA"
    assert system["state"] == "operating"
    assert system["properties"]["IPAddress"] == "10.0.0.10"


def test_get_lpar(hmc_client: HmcClient) -> None:
    lpar = hmc_client.get_lpar(SYSTEM_ID, LPAR_ID)
    assert lpar["id"] == LPAR_ID
    assert lpar["managed_system_id"] == SYSTEM_ID
    assert lpar["name"] == "AIX01"
    assert lpar["state"] == "running"


def test_list_partition_profiles(hmc_client: HmcClient) -> None:
    profiles = hmc_client.list_partition_profiles(LPAR_ID)
    assert len(profiles) == 2
    assert profiles[0]["name"] == "default"


def test_get_capacity_metadata_mode(hmc_client: HmcClient) -> None:
    capacity = hmc_client.get_capacity(SYSTEM_ID, mode="metadata")
    assert capacity["managed_system_id"] == SYSTEM_ID
    assert capacity["mode"] == "metadata"
    assert capacity["pcm_enabled"] is True
    assert len(capacity["samples"]) == 1
    assert capacity["samples"][0]["category"] == "phyp"
    assert (
        capacity["samples"][0]["metrics_href"] == "/rest/api/pcm/ProcessedMetrics/sample-phyp.json"
    )


def test_get_capacity_summary_mode(hmc_client: HmcClient) -> None:
    capacity = hmc_client.get_capacity(SYSTEM_ID, mode="summary")
    assert capacity["mode"] == "summary"
    assert capacity["summary"]["sample_count"] == 1
    assert capacity["summary"]["categories"]["phyp"] == 1
    assert "samples" not in capacity


def test_get_capacity_full_mode_raises_validation_error(hmc_client: HmcClient) -> None:
    with pytest.raises(HmcValidationError, match="Phase [AB]"):
        hmc_client.get_capacity(SYSTEM_ID, mode="full")


class TestDemoMode:
    """Demo mode: read tools return fixtures, write tools return demo envelope, no HTTP."""

    def test_list_managed_systems_returns_fixture(self, demo_hmc_client: HmcClient) -> None:
        result = demo_hmc_client.list_managed_systems()
        assert isinstance(result, list)
        assert len(result) > 0
        assert "id" in result[0]
        assert "name" in result[0]

    def test_get_managed_system_returns_fixture(self, demo_hmc_client: HmcClient) -> None:
        result = demo_hmc_client.get_managed_system(SYSTEM_ID)
        assert isinstance(result, dict)
        assert "id" in result
        assert "properties" in result

    def test_list_lpars_returns_fixture(self, demo_hmc_client: HmcClient) -> None:
        result = demo_hmc_client.list_lpars(SYSTEM_ID)
        assert isinstance(result, list)
        assert len(result) > 0

    def test_get_lpar_status_returns_fixture(self, demo_hmc_client: HmcClient) -> None:
        result = demo_hmc_client.get_lpar_status(SYSTEM_ID, LPAR_ID)
        assert isinstance(result, dict)
        assert result["source"] == "uom"

    def test_get_capacity_returns_fixture(self, demo_hmc_client: HmcClient) -> None:
        result = demo_hmc_client.get_capacity(SYSTEM_ID)
        assert isinstance(result, dict)
        assert "samples" in result or "summary" in result or "placeholder" in result

    def test_health_check_returns_synthetic(self, demo_hmc_client: HmcClient) -> None:
        result = demo_hmc_client.health_check()
        assert result["status"] == "ok"
        assert result["session_active"] is False
        assert result["hmc_host"] == "demo-hmc.test"

    def test_login_is_noop_no_http(self, demo_hmc_client: HmcClient) -> None:
        """login() in demo mode must not invoke HmcSession.login() (no HTTP calls)."""
        from unittest.mock import patch

        with patch.object(
            demo_hmc_client._session,
            "login",
            side_effect=AssertionError("HmcSession.login() must not be called in demo mode"),
        ):
            demo_hmc_client.login()  # must not raise

    def test_close_is_noop_no_http(self, demo_hmc_client: HmcClient) -> None:
        demo_hmc_client.login()
        demo_hmc_client.close()  # should not raise

    def test_write_tool_returns_demo_envelope(self, demo_hmc_client: HmcClient) -> None:
        """start_lpar() in demo mode returns the demo envelope via the public API."""
        from power_hmc_mcp.guardrails import _issue_authorization

        auth = _issue_authorization(operation="start_lpar", correlation_id="test-cid-demo")
        result = demo_hmc_client.start_lpar(SYSTEM_ID, LPAR_ID, authorization=auth)
        assert result["executed"] is False
        assert result["demo"] is True
        assert result["operation"] == "start_lpar"
        assert "suggested_next_step" in result
        assert result["suggested_next_step"]

    def test_login_emits_demo_logon_event(
        self, demo_hmc_client: HmcClient, caplog: pytest.LogCaptureFixture
    ) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            demo_hmc_client.login()
        assert any("session_logon_end" in r.getMessage() for r in caplog.records)
        assert any("demo" in r.getMessage() for r in caplog.records)


class TestGetCapacityFull:
    """Tests for the get_capacity_full stub and size-guard infrastructure."""

    def test_returns_placeholder(self, hmc_client: HmcClient) -> None:
        result = hmc_client.get_capacity_full(
            SYSTEM_ID, "/rest/api/pcm/ProcessedMetrics/sample.json"
        )
        assert result["placeholder"] is True
        assert result["managed_system_id"] == SYSTEM_ID

    def test_includes_metrics_href(self, hmc_client: HmcClient) -> None:
        href = "/rest/api/pcm/ProcessedMetrics/sample.json"
        result = hmc_client.get_capacity_full(SYSTEM_ID, href)
        assert result["metrics_href"] == href

    def test_includes_cpu_aggregate_keys(self, hmc_client: HmcClient) -> None:
        result = hmc_client.get_capacity_full(
            SYSTEM_ID, "/rest/api/pcm/ProcessedMetrics/sample.json"
        )
        for key in ("min_cpu_pct", "max_cpu_pct", "avg_cpu_pct"):
            assert key in result

    def test_rejects_empty_metrics_href(self, hmc_client: HmcClient) -> None:
        from power_hmc_mcp.exceptions import HmcValidationError

        with pytest.raises(HmcValidationError, match="metrics_href"):
            hmc_client.get_capacity_full(SYSTEM_ID, "")

    def test_result_is_json_serializable(self, hmc_client: HmcClient) -> None:
        import json

        result = hmc_client.get_capacity_full(
            SYSTEM_ID, "/rest/api/pcm/ProcessedMetrics/sample.json"
        )
        json.dumps(result)


class TestGetLparQuick:
    """B2-5: composite quick-property endpoint stub returns a placeholder shape.

    Validates the contract surface (no HTTP made) until the endpoint is
    validated against real firmware and `HMC_PREFER_QUICK_PROPERTIES` is
    enabled by the operator.
    """

    def test_returns_placeholder(self, hmc_client: HmcClient) -> None:
        result = hmc_client.get_lpar_quick(LPAR_ID)
        assert result["placeholder"] is True
        assert result["lpar_id"] == LPAR_ID
        assert "[PLACEHOLDER]" in result["message"]
        json.dumps(result)

    def test_rejects_invalid_lpar_id(self, hmc_client: HmcClient) -> None:
        with pytest.raises(HmcValidationError):
            hmc_client.get_lpar_quick("../evil")


class TestHmcResponseTooLargeError:
    def test_has_max_and_actual_bytes(self) -> None:
        from power_hmc_mcp.exceptions import HmcResponseTooLargeError

        err = HmcResponseTooLargeError("too big", max_bytes=10_000_000, actual_bytes=15_000_000)
        assert err.max_bytes == 10_000_000
        assert err.actual_bytes == 15_000_000
        assert "too big" in str(err)

    def test_is_hmc_error_subclass(self) -> None:
        from power_hmc_mcp.exceptions import HmcError, HmcResponseTooLargeError

        err = HmcResponseTooLargeError("x", max_bytes=1, actual_bytes=2)
        assert isinstance(err, HmcError)


def _sample(
    utilized: list[float] | str | None,
    deduct_idle: list[float] | None = None,
) -> dict[str, Any]:
    """Build a single PCM utilSamples entry against the IBM Power9/10/11 schema."""
    processor: dict[str, Any] = {"utilizedProcUnits": utilized}
    if deduct_idle is not None:
        processor["utilizedProcUnitsDeductIdle"] = deduct_idle
    return {"serverUtil": {"processor": processor}}


def _system_util(
    samples: list[dict[str, Any]],
    *,
    version: str = "1.0.0",
    metric_type: str = "Processed",
    metric_array_order: list[str] | None = None,
) -> dict[str, Any]:
    """Build a ``systemUtil`` object with the IBM PCM JSON shape."""
    return {
        "utilInfo": {
            "version": version,
            "metricType": metric_type,
            "metricArrayOrder": metric_array_order or ["Avg"],
        },
        "utilSamples": samples,
    }


class TestPcmCpuAggregates:
    """Unit tests for the _pcm_cpu_aggregates helper.

    Schema reference: ``systemUtil.utilSamples[n].serverUtil.processor.utilizedProcUnits``
    (IBM Docs Power9/10/11).  Every numeric field is an array; index order
    is declared by ``utilInfo.metricArrayOrder``.
    """

    @pytest.mark.parametrize(
        ("description", "samples", "exp_min", "exp_max", "exp_avg"),
        [
            ("empty samples", [], None, None, None),
            ("single Processed sample", [_sample([42.5])], 42.5, 42.5, 42.5),
            (
                "multiple Processed samples (min/max/avg over window)",
                [_sample([10.0]), _sample([20.0]), _sample([30.0])],
                10.0,
                30.0,
                20.0,
            ),
            (
                "non-list utilizedProcUnits skipped",
                [_sample("not-a-list"), _sample([80.0])],
                80.0,
                80.0,
                80.0,
            ),
            (
                "empty utilizedProcUnits arrays skipped",
                [_sample([]), _sample([5.0])],
                5.0,
                5.0,
                5.0,
            ),
            (
                "all invalid samples returns None",
                [_sample("bad"), _sample([])],
                None,
                None,
                None,
            ),
            ("integer values coerced to float", [_sample([75])], 75.0, 75.0, 75.0),
        ],
    )
    def test_aggregates_processed_metric_type(
        self,
        description: str,
        samples: list[dict[str, Any]],
        exp_min: float | None,
        exp_max: float | None,
        exp_avg: float | None,
    ) -> None:
        from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates

        result = _pcm_cpu_aggregates(_system_util(samples))
        if exp_min is None:
            assert result == {
                "min_cpu_pct": None,
                "max_cpu_pct": None,
                "avg_cpu_pct": None,
            }, description
        else:
            assert result["min_cpu_pct"] == pytest.approx(exp_min), description
            assert result["max_cpu_pct"] == pytest.approx(exp_max), description
            assert result["avg_cpu_pct"] == pytest.approx(exp_avg), description

    @pytest.mark.parametrize(
        ("fixture_file", "expected_field"),
        [
            ("metrics_href_response.json", "utilizedProcUnitsDeductIdle"),
            ("metrics_href_response_v9.json", "utilizedProcUnits"),
        ],
    )
    def test_pcm_cpu_aggregates_uses_correct_field_per_schema_version(
        self,
        fixture_file: str,
        expected_field: str,
        fixtures_dir: Path,
    ) -> None:
        """v1.1.0+ uses deductIdle; v1.0.0 falls back to utilizedProcUnits."""
        from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates

        data = json.loads((fixtures_dir / fixture_file).read_text())
        result = _pcm_cpu_aggregates(data["systemUtil"])
        # expected_field is asserted by reading the fixture path the
        # implementation will consume — drift in either side surfaces here.
        assert result["avg_cpu_pct"] is not None
        assert isinstance(result["avg_cpu_pct"], float)
        assert result["min_cpu_pct"] <= result["avg_cpu_pct"] <= result["max_cpu_pct"]

        # Cross-check: the values must come from `expected_field` when present
        # (else fall back to utilizedProcUnits).  Compute the expected average
        # from the fixture using the same field-selection rule.
        samples = data["systemUtil"]["utilSamples"]
        raw_values = [
            float(s["serverUtil"]["processor"].get(expected_field, [None])[0])
            for s in samples
            if s["serverUtil"]["processor"].get(expected_field) is not None
        ] or [float(s["serverUtil"]["processor"]["utilizedProcUnits"][0]) for s in samples]
        assert result["avg_cpu_pct"] == pytest.approx(sum(raw_values) / len(raw_values))

    def test_pcm_cpu_aggregates_empty_system_util_returns_none_aggregates(self) -> None:
        from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates

        result = _pcm_cpu_aggregates({})
        assert result == {"min_cpu_pct": None, "max_cpu_pct": None, "avg_cpu_pct": None}

    def test_pcm_cpu_aggregates_malformed_array_skipped_gracefully(self) -> None:
        """Non-list or wrong-length arrays must not raise."""
        from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates

        system_util = _system_util(
            [
                _sample("not-a-list"),
                _sample([]),
                _sample([5.0]),
            ],
        )
        result = _pcm_cpu_aggregates(system_util)
        assert result["avg_cpu_pct"] == 5.0

    def test_pcm_cpu_aggregates_aggregated_metric_type_reads_precomputed_values(
        self,
    ) -> None:
        """Aggregated metricType: read pre-computed Avg/Min/Max from index 0."""
        from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates

        system_util = _system_util(
            [_sample([6.0, 4.0, 9.0])],
            metric_type="Aggregated",
            metric_array_order=["Avg", "Min", "Max"],
        )
        result = _pcm_cpu_aggregates(system_util)
        assert result == {"avg_cpu_pct": 6.0, "min_cpu_pct": 4.0, "max_cpu_pct": 9.0}

    def test_pcm_cpu_aggregates_falls_back_to_utilized_when_deduct_idle_absent_on_v110(
        self,
    ) -> None:
        """v1.1.0 schema but firmware omits deductIdle → fall back to utilizedProcUnits."""
        from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates

        system_util = _system_util(
            [_sample([6.8]), _sample([7.4])],
            version="1.1.0",
        )
        result = _pcm_cpu_aggregates(system_util)
        assert result["avg_cpu_pct"] == pytest.approx(7.1)
        assert result["min_cpu_pct"] == pytest.approx(6.8)
        assert result["max_cpu_pct"] == pytest.approx(7.4)


def test_allowlist_filters_list_managed_systems(hmc_client_allowlist: HmcClient) -> None:
    systems = hmc_client_allowlist.list_managed_systems()
    assert len(systems) == 1
    assert systems[0]["id"] == SYSTEM_ID


def test_allowlist_denies_get_managed_system(hmc_client_allowlist: HmcClient) -> None:
    with pytest.raises(HmcValidationError):
        hmc_client_allowlist.get_managed_system("48f2a140-b30f-8544-7a1b-2c3d4e5a5678")


def test_new_read_outputs_json_serializable(hmc_client: HmcClient) -> None:
    json.dumps(hmc_client.get_managed_system(SYSTEM_ID))
    json.dumps(hmc_client.get_lpar(SYSTEM_ID, LPAR_ID))
    json.dumps(hmc_client.list_partition_profiles(LPAR_ID))
    json.dumps(hmc_client.get_capacity(SYSTEM_ID, mode="metadata"))
    json.dumps(hmc_client.get_capacity(SYSTEM_ID, mode="summary"))


def test_health_check(hmc_client: HmcClient) -> None:
    result = hmc_client.health_check()
    assert result["status"] == "ok"
    assert result["hmc_host"] == "hmc.test"
    assert result["session_active"] is True
    assert result["managed_system_count"] == 2
    json.dumps(result)


def test_health_check_json_serializable(hmc_client_allowlist: HmcClient) -> None:
    result = hmc_client_allowlist.health_check()
    assert result["managed_system_count"] == 1
    json.dumps(result)


def test_hmc_http_error_url_has_no_credentials(hmc_settings, hmc_routes: respx.MockRouter) -> None:
    base = hmc_settings.base_url
    hmc_routes.get(f"{base}{MANAGED_SYSTEMS_PATH}").respond(status_code=500, text="error")
    client = HmcClient(hmc_settings)
    with pytest.raises(HmcHttpError) as exc_info:
        client.list_managed_systems()
    assert "super-secret" not in str(exc_info.value)
    assert exc_info.value.url is not None
    assert "super-secret" not in exc_info.value.url


@patch("power_hmc_mcp.hmc_client.retry_sleep", lambda *_a, **_kw: None)
def test_list_managed_systems_retries_on_503(
    hmc_settings: Settings,
    respx_mock: respx.MockRouter,
) -> None:
    base = hmc_settings.base_url
    respx_mock.put(f"{base}{LOGON_PATH}").respond(
        status_code=200,
        headers={SESSION_HEADER: TEST_SESSION},
    )
    sys_route = respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}")
    body_text = (Path(__file__).parent / "fixtures" / "managed_systems_feed.xml").read_text(
        encoding="utf-8",
    )
    ok_req = httpx.Request("GET", f"{base}{MANAGED_SYSTEMS_PATH}")
    sys_route.side_effect = [
        httpx.Response(503, request=ok_req),
        httpx.Response(200, text=body_text, request=ok_req),
    ]
    client = HmcClient(hmc_settings)
    systems = client.list_managed_systems()
    assert len(systems) == 2
    assert sys_route.call_count == 2


def _managed_systems_capture(
    captured: dict[str, str | None],
    *,
    response_headers: dict[str, str] | None = None,
    outbound_header: str = "X-Transaction-ID",
):
    """Capture the outbound correlation header (default per IBM HMC spec)."""

    def _capture(request: httpx.Request) -> httpx.Response:
        captured["hdr"] = request.headers.get(outbound_header)
        body_text = (Path(__file__).parent / "fixtures" / "managed_systems_feed.xml").read_text(
            encoding="utf-8",
        )
        return httpx.Response(
            200,
            text=body_text,
            headers=response_headers or {},
            request=request,
        )

    return _capture


def test_correlation_header_propagation_default_on(
    monkeypatch: pytest.MonkeyPatch,
    respx_mock: respx.MockRouter,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.delenv("HMC_PROPAGATE_CORRELATION_HEADER", raising=False)
    settings = Settings()
    assert settings.hmc_propagate_correlation_header is True
    base = settings.base_url
    respx_mock.put(f"{base}{LOGON_PATH}").respond(
        status_code=200,
        headers={SESSION_HEADER: TEST_SESSION},
    )

    captured: dict[str, str | None] = {}
    respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}").mock(
        side_effect=_managed_systems_capture(captured),
    )
    client = HmcClient(settings)
    with observability.correlation_scope("corr-default-on"):
        client.list_managed_systems()
    assert captured["hdr"] == "corr-default-on"


def test_correlation_header_propagation_disabled(
    monkeypatch: pytest.MonkeyPatch,
    respx_mock: respx.MockRouter,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_PROPAGATE_CORRELATION_HEADER", "false")
    settings = Settings()
    assert settings.hmc_propagate_correlation_header is False
    base = settings.base_url
    respx_mock.put(f"{base}{LOGON_PATH}").respond(
        status_code=200,
        headers={SESSION_HEADER: TEST_SESSION},
    )

    captured: dict[str, str | None] = {}
    respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}").mock(
        side_effect=_managed_systems_capture(captured),
    )
    client = HmcClient(settings)
    with observability.correlation_scope("corr-disabled"):
        client.list_managed_systems()
    assert captured["hdr"] is None


def test_correlation_header_echo_captured_in_log(
    monkeypatch: pytest.MonkeyPatch,
    respx_mock: respx.MockRouter,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """HMC echo via X-Transaction-ID (IBM spec default) is captured into hmc_request_end."""
    apply_hmc_env(monkeypatch)
    settings = Settings()
    base = settings.base_url
    respx_mock.put(f"{base}{LOGON_PATH}").respond(
        status_code=200,
        headers={SESSION_HEADER: TEST_SESSION},
    )

    captured: dict[str, str | None] = {}
    respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}").mock(
        side_effect=_managed_systems_capture(
            captured,
            response_headers={"X-Transaction-ID": "server-tid"},
        ),
    )
    client = HmcClient(settings)
    with caplog.at_level("INFO", logger="power_hmc_mcp.observability"):
        with observability.correlation_scope("corr-echo"):
            client.list_managed_systems()
    end_records = [r for r in caplog.records if "hmc_request_end" in r.getMessage()]
    assert end_records, "expected at least one hmc_request_end log record"
    assert any("server-tid" in r.getMessage() for r in end_records)


def test_login_emits_session_logon_end(
    hmc_settings: Settings,
    hmc_routes: respx.MockRouter,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """login() emits a structured session_logon_end lifecycle event on success."""
    client = HmcClient(hmc_settings)
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        client.login()
    assert any("session_logon_end" in r.getMessage() for r in caplog.records)
    assert any("success" in r.getMessage() for r in caplog.records)


def test_close_emits_session_logoff_end(
    hmc_settings: Settings,
    hmc_routes: respx.MockRouter,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """close() emits a structured session_logoff_end lifecycle event on success."""
    client = HmcClient(hmc_settings)
    client.login()
    caplog.clear()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        client.close()
    assert any("session_logoff_end" in r.getMessage() for r in caplog.records)


def test_close_emits_logoff_error_outcome_when_session_fails(
    hmc_settings: Settings,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """close() emits session_logoff_end with outcome=error when HmcSession.close() raises."""
    from unittest.mock import patch

    from power_hmc_mcp.exceptions import HmcHttpError

    client = HmcClient(hmc_settings)
    with patch.object(
        client._session,
        "close",
        side_effect=HmcHttpError("logoff failed", status_code=0, url="/rest/api/web/Logon"),
    ):
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            client.close()  # must not raise

    records = [r for r in caplog.records if "session_logoff_end" in r.getMessage()]
    assert records, "expected a session_logoff_end log record"
    assert any("error" in r.getMessage() for r in records)
