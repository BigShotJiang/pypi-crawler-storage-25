"""Shared pytest fixtures."""

from __future__ import annotations

import re
from pathlib import Path

import pytest
import respx

from power_hmc_mcp.config import Settings
from power_hmc_mcp.hmc_client import (
    LOGON_PATH,
    LPAR_PROFILES_PATH,
    MANAGED_SYSTEMS_PATH,
    SESSION_HEADER,
    HmcClient,
)

FIXTURES = Path(__file__).parent / "fixtures"
TEST_SESSION = "test-session-token-abc123"
SYSTEM_ID = "38f2a140-b30f-8544-7a1b-2c3d4e5f1234"
LPAR_ID = "11111111-1111-2222-3333-444455556666"


def apply_hmc_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Set standard HMC_* env vars for tests."""
    monkeypatch.setenv("HMC_HOST", "hmc.test")
    monkeypatch.setenv("HMC_PORT", "443")
    monkeypatch.setenv("HMC_USERNAME", "api-user")
    monkeypatch.setenv("HMC_PASSWORD", "super-secret")
    monkeypatch.setenv("HMC_VERIFY_TLS", "false")


def _fixture(name: str) -> str:
    return (FIXTURES / name).read_text(encoding="utf-8")


@pytest.fixture
def fixtures_dir() -> Path:
    """Path to the shared tests/fixtures directory (read-only for tests)."""
    return FIXTURES


@pytest.fixture
def respx_mock():
    with respx.mock(assert_all_called=False) as router:
        yield router


@pytest.fixture
def hmc_settings(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    return Settings()


@pytest.fixture
def hmc_settings_allowlist(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ALLOWED_MANAGED_SYSTEMS", SYSTEM_ID)
    return Settings()


@pytest.fixture
def hmc_routes(respx_mock, hmc_settings: Settings):  # noqa: ANN001
    """Mock HMC logon, managed systems, LPAR list, and quick property endpoints."""
    base = hmc_settings.base_url

    respx_mock.put(f"{base}{LOGON_PATH}").respond(
        status_code=200,
        headers={SESSION_HEADER: TEST_SESSION},
        text="<LogonResponse/>",
    )
    respx_mock.delete(f"{base}{LOGON_PATH}").respond(status_code=200)

    respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}").respond(
        text=_fixture("managed_systems_feed.xml"),
    )
    respx_mock.get(
        f"{base}{MANAGED_SYSTEMS_PATH}/{SYSTEM_ID}/LogicalPartition",
    ).respond(text=_fixture("logical_partitions_feed.xml"))

    quick_base = f"{base}/rest/api/uom/LogicalPartition/{LPAR_ID}/quick"
    respx_mock.get(f"{quick_base}/PartitionState").respond(
        text=_fixture("lpar_quick_partition_state.xml"),
    )
    respx_mock.get(f"{quick_base}/PartitionName").respond(
        text=_fixture("lpar_quick_partition_name.xml"),
    )
    respx_mock.get(f"{quick_base}/PartitionID").respond(
        text=_fixture("lpar_quick_partition_id.xml"),
    )
    respx_mock.get(f"{quick_base}/RMCState").respond(
        text=_fixture("lpar_quick_rmc_state.xml"),
    )

    respx_mock.get(f"{base}{MANAGED_SYSTEMS_PATH}/{SYSTEM_ID}").respond(
        text=_fixture("managed_system_detail.xml"),
    )
    respx_mock.get(
        f"{base}{MANAGED_SYSTEMS_PATH}/{SYSTEM_ID}/LogicalPartition/{LPAR_ID}",
    ).respond(text=_fixture("logical_partition_detail.xml"))
    respx_mock.get(
        f"{base}{LPAR_PROFILES_PATH.format(lpar_id=LPAR_ID)}",
    ).respond(text=_fixture("partition_profiles_feed.xml"))
    respx_mock.get(
        url=re.compile(
            rf"^{re.escape(base)}/rest/api/pcm/ManagedSystem/{re.escape(SYSTEM_ID)}/ProcessedMetrics",
        ),
    ).respond(text=_fixture("pcm_processed_metrics_feed.xml"))

    return respx_mock


@pytest.fixture
def hmc_client(hmc_settings: Settings, hmc_routes) -> HmcClient:  # noqa: ANN001
    return HmcClient(hmc_settings)


@pytest.fixture
def hmc_client_allowlist(hmc_settings_allowlist: Settings, hmc_routes) -> HmcClient:  # noqa: ANN001
    return HmcClient(hmc_settings_allowlist)


@pytest.fixture
def demo_hmc_settings(monkeypatch: pytest.MonkeyPatch) -> Settings:
    """Settings with HMC_DEMO_MODE=true.  No real HMC env vars required."""
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    return Settings()


@pytest.fixture
def demo_hmc_client(demo_hmc_settings: Settings) -> HmcClient:
    """HmcClient in demo mode — makes no HTTP calls."""
    return HmcClient(demo_hmc_settings)
