"""Tests for HmcSession transport and session lifecycle."""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest

from power_hmc_mcp import observability
from power_hmc_mcp.config import Settings
from power_hmc_mcp.exceptions import HmcAuthError
from power_hmc_mcp.http_policy import RequestClassification
from power_hmc_mcp.routes import LOGON_PATH, MANAGED_SYSTEMS_PATH, SESSION_HEADER
from power_hmc_mcp.session import HmcSession
from tests.conftest import LPAR_ID, SYSTEM_ID, apply_hmc_env

FIXTURES = Path(__file__).parent / "fixtures"
MANAGED_SYSTEMS_XML = (FIXTURES / "managed_systems_feed.xml").read_text(encoding="utf-8")


def _logon_then_managed_systems_handler(
    *,
    response_headers: dict[str, str] | None = None,
) -> Callable[[httpx.Request], httpx.Response]:
    """Build a MockTransport handler that logs in and returns managed systems XML.

    Used by the correlation-echo tests so each test can vary only the response
    headers on the GET while keeping the logon path stable.
    """

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "test-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and request.url.path.endswith(MANAGED_SYSTEMS_PATH):
            return httpx.Response(
                200,
                text=MANAGED_SYSTEMS_XML,
                headers=response_headers or {},
            )
        return httpx.Response(404)

    return handler


def _session_with_transport(settings: Settings, handler) -> HmcSession:
    transport = httpx.MockTransport(handler)
    http = httpx.Client(
        base_url=settings.base_url,
        transport=transport,
        verify=settings.httpx_verify(),
        timeout=settings.hmc_timeout_seconds,
    )
    return HmcSession(settings, http_client=http)


def test_login_sets_session_token(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "test-token-abc"},
                text="<LogonResponse/>",
            )
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    assert session._session_token == "test-token-abc"


def test_login_raises_on_400(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(400)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    with pytest.raises(HmcAuthError):
        session.login()


def test_login_raises_when_no_token_header(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(200, text="<LogonResponse/>")
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    with pytest.raises(HmcAuthError):
        session.login()


def test_close_clears_session_token(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "DELETE" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(200)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    session.close()
    assert session._session_token is None


@patch("power_hmc_mcp.hmc_client.retry_sleep", lambda *_a, **_kw: None)
def test_request_retries_on_503(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    managed_system_get_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal managed_system_get_count
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "test-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            managed_system_get_count += 1
            if managed_system_get_count == 1:
                return httpx.Response(503)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    response = session.request(
        "GET",
        MANAGED_SYSTEMS_PATH,
        classification=RequestClassification.READ,
    )
    assert response.status_code == 200


@dataclass
class _ReauthState:
    logon_count: int = 0
    managed_system_get_count: int = 0


@patch("power_hmc_mcp.hmc_client.retry_sleep", lambda *_a, **_kw: None)
def test_request_reauth_on_401(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    state = _ReauthState()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            state.logon_count += 1
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "re-authed-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            state.managed_system_get_count += 1
            if state.managed_system_get_count == 1:
                return httpx.Response(401)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    response = session.request(
        "GET",
        MANAGED_SYSTEMS_PATH,
        classification=RequestClassification.READ,
    )
    assert response.status_code == 200
    assert state.logon_count >= 2


# --- B2-3: correlation header echo capture --------------------------------


def _hmc_request_end_records(caplog: pytest.LogCaptureFixture) -> list[logging.LogRecord]:
    return [r for r in caplog.records if "hmc_request_end" in r.getMessage()]


def test_correlation_echo_primary_header_used(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Primary header (default X-Transaction-ID per IBM HMC spec) is captured into the log."""
    apply_hmc_env(monkeypatch)
    settings = Settings()
    handler = _logon_then_managed_systems_handler(
        response_headers={"X-Transaction-ID": "tid-primary"},
    )
    session = _session_with_transport(settings, handler)
    session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        session.request("GET", MANAGED_SYSTEMS_PATH)
    end_records = _hmc_request_end_records(caplog)
    assert end_records, "expected hmc_request_end log record"
    assert any("tid-primary" in r.getMessage() for r in end_records)
    assert any("hmc_echo_correlation_id" in r.getMessage() for r in end_records)


def test_correlation_echo_fallback_x_client_correlator(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Falls back to X-Client-Correlator (IBM V8+ optional) when X-Transaction-ID absent."""
    apply_hmc_env(monkeypatch)
    settings = Settings()
    handler = _logon_then_managed_systems_handler(
        response_headers={"X-Client-Correlator": "ccr-fallback"},
    )
    session = _session_with_transport(settings, handler)
    session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        session.request("GET", MANAGED_SYSTEMS_PATH)
    end_records = _hmc_request_end_records(caplog)
    assert end_records
    assert any("ccr-fallback" in r.getMessage() for r in end_records)


def test_correlation_echo_neither_header_present(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Echo key is omitted entirely when no configured header is present in the response."""
    apply_hmc_env(monkeypatch)
    settings = Settings()
    handler = _logon_then_managed_systems_handler(response_headers={})
    session = _session_with_transport(settings, handler)
    session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        session.request("GET", MANAGED_SYSTEMS_PATH)
    end_records = _hmc_request_end_records(caplog)
    assert end_records
    # Key must be absent — not None / empty string. The `_emit_log` tail
    # contains the dict repr; "hmc_echo_correlation_id" must not appear.
    for record in end_records:
        assert "hmc_echo_correlation_id" not in record.getMessage(), (
            "echo key must be omitted when neither configured header is present, "
            f"saw: {record.getMessage()}"
        )


def test_correlation_echo_custom_env_header(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Operator-configured custom primary header is honoured."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_CORRELATION_ECHO_HEADER", "X-IBM-Trace-ID")
    monkeypatch.setenv("HMC_CORRELATION_ECHO_FALLBACK_HEADERS", "")
    settings = Settings()
    assert settings.hmc_correlation_echo_header == "X-IBM-Trace-ID"
    assert settings.hmc_correlation_echo_fallback_headers == ()
    handler = _logon_then_managed_systems_handler(
        response_headers={"X-IBM-Trace-ID": "trace-42"},
    )
    session = _session_with_transport(settings, handler)
    session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        session.request("GET", MANAGED_SYSTEMS_PATH)
    end_records = _hmc_request_end_records(caplog)
    assert end_records
    assert any("trace-42" in r.getMessage() for r in end_records)


# --- B2-3: outbound correlation header (HMC_OUTBOUND_CORRELATION_HEADER) --


def _capture_outbound_handler(
    captured: dict[str, str | None],
    headers_to_capture: tuple[str, ...],
) -> Callable[[httpx.Request], httpx.Response]:
    """Handler that captures the value of each header in headers_to_capture."""

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "test-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and request.url.path.endswith(MANAGED_SYSTEMS_PATH):
            for name in headers_to_capture:
                captured[name] = request.headers.get(name)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    return handler


def test_outbound_header_default_is_x_transaction_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default outbound header is X-Transaction-ID (IBM HMC REST API spec)."""
    apply_hmc_env(monkeypatch)
    monkeypatch.delenv("HMC_OUTBOUND_CORRELATION_HEADER", raising=False)
    monkeypatch.delenv("HMC_PROPAGATE_CORRELATION_HEADER", raising=False)
    settings = Settings()
    assert settings.hmc_outbound_correlation_header == "X-Transaction-ID"
    assert settings.hmc_propagate_correlation_header is True

    captured: dict[str, str | None] = {}
    handler = _capture_outbound_handler(
        captured,
        headers_to_capture=("X-Transaction-ID", "X-Correlation-ID"),
    )
    session = _session_with_transport(settings, handler)
    session.login()
    with observability.correlation_scope("cid-outbound-1"):
        session.request("GET", MANAGED_SYSTEMS_PATH)

    assert captured["X-Transaction-ID"] == "cid-outbound-1"
    assert captured["X-Correlation-ID"] is None


def test_outbound_header_custom_env_override(monkeypatch: pytest.MonkeyPatch) -> None:
    """HMC_OUTBOUND_CORRELATION_HEADER=X-Correlation-ID restores legacy behaviour."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_OUTBOUND_CORRELATION_HEADER", "X-Correlation-ID")
    settings = Settings()
    assert settings.hmc_outbound_correlation_header == "X-Correlation-ID"

    captured: dict[str, str | None] = {}
    handler = _capture_outbound_handler(
        captured,
        headers_to_capture=("X-Transaction-ID", "X-Correlation-ID"),
    )
    session = _session_with_transport(settings, handler)
    session.login()
    with observability.correlation_scope("cid-legacy"):
        session.request("GET", MANAGED_SYSTEMS_PATH)

    assert captured["X-Correlation-ID"] == "cid-legacy"
    assert captured["X-Transaction-ID"] is None


def test_outbound_header_not_sent_when_propagation_disabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """HMC_PROPAGATE_CORRELATION_HEADER=false suppresses every outbound header name."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_PROPAGATE_CORRELATION_HEADER", "false")
    settings = Settings()
    assert settings.hmc_propagate_correlation_header is False

    captured: dict[str, str | None] = {}
    handler = _capture_outbound_handler(
        captured,
        headers_to_capture=("X-Transaction-ID", "X-Correlation-ID"),
    )
    session = _session_with_transport(settings, handler)
    session.login()
    with observability.correlation_scope("cid-no-send"):
        session.request("GET", MANAGED_SYSTEMS_PATH)

    assert captured["X-Transaction-ID"] is None
    assert captured["X-Correlation-ID"] is None


def test_outbound_traceparent_injected_when_span_active(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    captured: dict[str, str | None] = {}
    handler = _capture_outbound_handler(
        captured,
        headers_to_capture=("traceparent", "X-Transaction-ID"),
    )
    session = _session_with_transport(settings, handler)
    session.login()

    def _inject_test_traceparent(headers: dict[str, str]) -> None:
        headers["traceparent"] = "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01"

    monkeypatch.setattr(observability, "inject_outbound_trace_headers", _inject_test_traceparent)
    with observability.correlation_scope("cid-trace-1"):
        session.request("GET", MANAGED_SYSTEMS_PATH)

    assert captured["X-Transaction-ID"] == "cid-trace-1"
    assert captured["traceparent"] == "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01"


def test_x_audit_memento_on_put_only(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    captured: dict[str, str | None] = {}
    job_path = f"/rest/api/uom/ManagedSystem/{SYSTEM_ID}/LogicalPartition/{LPAR_ID}/jobs"

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "test-token"},
                text="<LogonResponse/>",
            )
        if request.method == "PUT" and request.url.path.endswith("/jobs"):
            captured["put_audit"] = request.headers.get("X-Audit-Memento")
            return httpx.Response(202, headers={"Location": f"{job_path}/job-1"})
        if request.method == "GET" and request.url.path.endswith(MANAGED_SYSTEMS_PATH):
            captured["get_audit"] = request.headers.get("X-Audit-Memento")
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    with observability.correlation_scope("audit-cid-1"):
        session.request("PUT", job_path, content=b"<JobRequest/>")
        session.request("GET", MANAGED_SYSTEMS_PATH)

    assert captured["put_audit"] == "audit-cid-1"
    assert captured["get_audit"] is None


# --- B2-4: session_reauth event + HMC_MAX_REAUTH_ATTEMPTS -----------------


def _session_reauth_records(caplog: pytest.LogCaptureFixture) -> list[logging.LogRecord]:
    return [r for r in caplog.records if "session_reauth" in r.getMessage()]


@patch("power_hmc_mcp.hmc_client.retry_sleep", lambda *_a, **_kw: None)
def test_401_reauth_success_emits_session_reauth_event(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """A successful 401 -> re-login -> retry path emits session_reauth outcome=success."""
    apply_hmc_env(monkeypatch)
    settings = Settings()
    state = _ReauthState()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            state.logon_count += 1
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "re-authed-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            state.managed_system_get_count += 1
            if state.managed_system_get_count == 1:
                return httpx.Response(401)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        response = session.request(
            "GET",
            MANAGED_SYSTEMS_PATH,
            classification=RequestClassification.READ,
        )
    assert response.status_code == 200

    reauth_records = _session_reauth_records(caplog)
    success_records = [r for r in reauth_records if "success" in r.getMessage()]
    seen = [r.getMessage() for r in reauth_records]
    assert len(success_records) == 1, (
        f"expected exactly one session_reauth outcome=success, got: {seen}"
    )
    assert any("401_mid_request" in r.getMessage() for r in success_records)
    assert any("hmc.test" in r.getMessage() for r in success_records)


@patch("power_hmc_mcp.hmc_client.retry_sleep", lambda *_a, **_kw: None)
def test_401_reauth_failure_raises_and_emits_failure_event(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """A 401 that persists after re-login raises HmcAuthError + emits failure event."""
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "re-authed-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            return httpx.Response(401)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        with pytest.raises(HmcAuthError, match="re-authentication failed"):
            session.request(
                "GET",
                MANAGED_SYSTEMS_PATH,
                classification=RequestClassification.READ,
            )

    reauth_records = _session_reauth_records(caplog)
    failure_records = [r for r in reauth_records if "failure" in r.getMessage()]
    seen = [r.getMessage() for r in reauth_records]
    assert len(failure_records) == 1, (
        f"expected exactly one session_reauth outcome=failure, got: {seen}"
    )
    assert any("401_mid_request" in r.getMessage() for r in failure_records)


@patch("power_hmc_mcp.hmc_client.retry_sleep", lambda *_a, **_kw: None)
def test_max_reauth_attempts_zero_raises_immediately(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """HMC_MAX_REAUTH_ATTEMPTS=0 makes any 401 surface as HmcAuthError without re-login."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_REAUTH_ATTEMPTS", "0")
    settings = Settings()
    assert settings.hmc_max_reauth_attempts == 0
    state = _ReauthState()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            state.logon_count += 1
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "test-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            return httpx.Response(401)
        return httpx.Response(404)

    session = _session_with_transport(settings, handler)
    session.login()
    logon_count_after_initial = state.logon_count
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        with pytest.raises(HmcAuthError):
            session.request("GET", MANAGED_SYSTEMS_PATH)

    # No additional logon was attempted (we still sit at the initial logon count).
    assert state.logon_count == logon_count_after_initial, (
        "HMC_MAX_REAUTH_ATTEMPTS=0 must not invoke any additional login()"
    )
    failure_records = [r for r in _session_reauth_records(caplog) if "failure" in r.getMessage()]
    assert len(failure_records) == 1


def test_reauth_demo_mode_emits_no_event_no_http(
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Demo mode short-circuits at HmcClient — no HmcSession, no session_reauth.

    Guards against accidental coupling: B2-4 must not cause demo mode tools
    to emit session-recovery events (demo mode never reaches HmcSession at all).
    """
    from power_hmc_mcp.hmc_client import HmcClient

    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    client = HmcClient(Settings())

    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        client.login()
        client.list_managed_systems()
        client.get_lpar_status(
            "38f2a140-b30f-8544-7a1b-2c3d4e5f1234",
            "11111111-1111-2222-3333-444455556666",
        )
        client.close()

    assert _session_reauth_records(caplog) == [], "demo mode must not emit session_reauth events"
