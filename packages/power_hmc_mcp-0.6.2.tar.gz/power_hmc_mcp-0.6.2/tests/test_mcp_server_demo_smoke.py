"""Demo-mode smoke test for :func:`power_hmc_mcp.mcp_server.main`.

The FastMCP entrypoint (``mcp_server.main``) is otherwise uncovered by the unit
suite because :py:meth:`FastMCP.run` is blocking. This test runs ``main()`` in
``HMC_DEMO_MODE=true`` with ``mcp.run`` patched to a no-op, exercising:

* env loading + ``Settings`` construction;
* ``HmcClient`` instantiation in demo mode;
* ``atexit`` registration of ``_shutdown_client``;
* the demo-mode ``WARNING`` log;
* ``register_tools(mcp, client)`` — every read-tool ``register()`` lambda runs.

This is the single test referenced in ``pyproject.toml`` justifying the 88%
coverage floor (vs. 90%). Once the floor is raised, this test is the
gating coverage contributor for ``mcp_server.py`` and the registration shims.
"""

from __future__ import annotations

import atexit
import logging

import pytest

from power_hmc_mcp import mcp_server


class _RecordCollector(logging.Handler):
    """Capture log records on the ``mcp_server`` logger directly.

    ``configure_logging`` clears root handlers, so pytest's ``caplog`` fixture
    (which attaches at root) misses anything emitted afterwards. Attaching this
    handler to ``power_hmc_mcp.mcp_server`` is independent of root and survives
    ``configure_logging``.
    """

    def __init__(self) -> None:
        super().__init__()
        self.records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)


def test_main_demo_mode_smoke(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    monkeypatch.setenv("HMC_MCP_TRANSPORT", "stdio")

    monkeypatch.setattr(mcp_server.mcp, "run", lambda *args, **kwargs: None)

    registered: list[object] = []
    real_register = atexit.register

    def spy_register(func, *args, **kwargs):  # type: ignore[no-untyped-def]
        registered.append(func)
        return real_register(func, *args, **kwargs)

    monkeypatch.setattr(mcp_server.atexit, "register", spy_register)

    collector = _RecordCollector()
    collector.setLevel(logging.WARNING)
    server_logger = logging.getLogger("power_hmc_mcp.mcp_server")
    server_logger.addHandler(collector)
    try:
        mcp_server.main()
    finally:
        server_logger.removeHandler(collector)

    assert mcp_server._shutdown_client in registered, (
        "main() must register _shutdown_client via atexit so the HMC client is "
        "closed on process exit"
    )

    demo_warnings = [
        record
        for record in collector.records
        if record.levelno == logging.WARNING and "DEMO MODE ACTIVE" in record.getMessage()
    ]
    assert demo_warnings, (
        "main() must emit the demo-mode WARNING when HMC_DEMO_MODE=true; "
        "operators rely on this to confirm no real HMC traffic will be sent"
    )

    registered_tool_names = set(mcp_server.mcp._tool_manager._tools.keys())
    expected_read_tools = {
        "list_managed_systems",
        "list_lpars",
        "get_lpar_status",
        "get_managed_system",
        "get_lpar",
        "list_partition_profiles",
        "get_capacity",
        "health_check",
    }
    assert expected_read_tools <= registered_tool_names, (
        f"register_tools(mcp, client) must register every read tool; "
        f"missing: {sorted(expected_read_tools - registered_tool_names)}"
    )

    assert mcp_server._pool is None, (
        "the finally clause in main() must call _shutdown_client() so "
        "module-level _pool (D5) is cleared on return"
    )
