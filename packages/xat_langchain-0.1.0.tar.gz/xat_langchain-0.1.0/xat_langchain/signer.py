"""XAT Signer -- builds canonical request, signs with ECDSA P-256, produces Agent-Signature header.

The private key never enters this module if using a KMS provider.
"""

import hashlib
import time
import base64
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils
from cryptography.hazmat.primitives.asymmetric.ec import ECDSA


class XATSigner:
    """Signs HTTP requests per the x-agent-trust extension.

    Args:
        private_key_pem: PEM-encoded ECDSA P-256 private key (dev only).
        key_file: Path to PEM key file (dev only).
        agent_id: Identifier for this agent (used as keyid in the header).
        kms_sign: Optional async callable(data: bytes) -> bytes for KMS signing.
                  When provided, private_key_pem is not needed.
    """

    def __init__(self, private_key_pem=None, key_file=None, agent_id="default", kms_sign=None):
        self.agent_id = agent_id
        self._kms_sign = kms_sign

        if kms_sign:
            self._private_key = None
        elif key_file:
            with open(key_file, "rb") as f:
                self._private_key = serialization.load_pem_private_key(f.read(), password=None)
        elif private_key_pem:
            if isinstance(private_key_pem, str):
                private_key_pem = private_key_pem.encode()
            self._private_key = serialization.load_pem_private_key(private_key_pem, password=None)
        else:
            raise ValueError("XATSigner requires private_key_pem, key_file, or kms_sign")

    def _build_canonical(self, method: str, path: str, ts: str, body: str) -> str:
        body_hash = hashlib.sha256(body.encode() if isinstance(body, str) else body).hexdigest()
        return f"{method.upper()} {path}\n{ts}\n{body_hash}"

    def sign(self, method: str, path: str, body: str = "") -> dict:
        """Sign a request. Returns dict with 'header' (the Agent-Signature value) and metadata."""
        ts = str(int(time.time()))
        canonical = self._build_canonical(method, path, ts, body)

        if self._kms_sign:
            # KMS path -- key never enters this process
            import asyncio
            sig_bytes = asyncio.get_event_loop().run_until_complete(
                self._kms_sign(canonical.encode())
            )
            sig_b64 = base64.b64encode(sig_bytes).decode()
        else:
            sig_bytes = self._private_key.sign(
                canonical.encode(),
                ECDSA(hashes.SHA256())
            )
            sig_b64 = base64.b64encode(sig_bytes).decode()

        header = f'keyid="{self.agent_id}",alg="ES256",ts="{ts}",sig="{sig_b64}"'

        return {
            "header": header,
            "header_name": "Agent-Signature",
            "canonical": canonical,
            "ts": ts,
            "keyid": self.agent_id,
        }

    def patch_session(self, session):
        """Patch a requests.Session to automatically sign all requests."""
        original_request = session.request
        signer = self

        def signed_request(method, url, **kwargs):
            from urllib.parse import urlparse
            parsed = urlparse(url)
            path = parsed.path + ("?" + parsed.query if parsed.query else "")
            body = kwargs.get("data", "") or kwargs.get("json", "")
            if isinstance(body, dict):
                import json
                body = json.dumps(body)
            elif not isinstance(body, str):
                body = str(body) if body else ""

            result = signer.sign(method, path, body)
            headers = kwargs.get("headers", {}) or {}
            headers["Agent-Signature"] = result["header"]
            kwargs["headers"] = headers
            return original_request(method, url, **kwargs)

        session.request = signed_request
        return session
