"""XAT-LangChain -- x-agent-trust signing for LangChain tool calls.

Wraps LangChain tools so every HTTP request carries a signed Agent-Signature header.
Based on the x-agent-trust extension registered in the OpenAPI Extensions Registry.

https://spec.openapis.org/registry/extension/x-agent-trust.html

Raza Sharif, CyberSecAI Ltd. Apache-2.0.
"""

from xat_langchain.signer import XATSigner
from xat_langchain.toolkit import XATToolkit, xat_tool
from xat_langchain.callback import XATCallbackHandler

__version__ = "0.1.0"
__all__ = ["XATSigner", "XATToolkit", "xat_tool", "XATCallbackHandler"]
