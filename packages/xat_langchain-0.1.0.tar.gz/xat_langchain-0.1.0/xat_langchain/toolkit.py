"""XAT Toolkit -- wraps LangChain tools with automatic Agent-Signature signing.

Usage:
    from xat_langchain import XATToolkit, xat_tool

    # Wrap existing tools
    toolkit = XATToolkit(key_file="agent.pem", agent_id="my-agent")
    signed_tools = toolkit.wrap(existing_tools)

    # Or use the decorator
    @xat_tool(key_file="agent.pem", agent_id="my-agent")
    def my_tool(query: str) -> str:
        return requests.get(f"https://api.example.com/search?q={query}").text
"""

import functools
import requests as _requests
from xat_langchain.signer import XATSigner


class XATToolkit:
    """Wraps a list of LangChain tools so their HTTP calls carry Agent-Signature."""

    def __init__(self, private_key_pem=None, key_file=None, agent_id="default", kms_sign=None):
        self.signer = XATSigner(
            private_key_pem=private_key_pem,
            key_file=key_file,
            agent_id=agent_id,
            kms_sign=kms_sign,
        )

    def _create_signed_session(self):
        """Create a requests.Session with automatic signing."""
        session = _requests.Session()
        return self.signer.patch_session(session)

    def wrap(self, tools):
        """Wrap a list of LangChain tools. Returns new tool instances with signed HTTP calls.

        This works by monkey-patching the global requests module during tool execution
        so any HTTP call the tool makes gets signed automatically.
        """
        import requests
        wrapped = []
        signer = self.signer

        for tool in tools:
            original_run = tool._run if hasattr(tool, '_run') else None
            original_arun = tool._arun if hasattr(tool, '_arun') else None

            if original_run:
                original_func = original_run

                @functools.wraps(original_func)
                def signed_run(*args, _orig=original_func, _signer=signer, **kwargs):
                    # Patch requests.get/post/etc for the duration of this tool call
                    orig_get = requests.get
                    orig_post = requests.post
                    orig_put = requests.put
                    orig_delete = requests.delete
                    orig_patch = requests.patch

                    session = _requests.Session()
                    _signer.patch_session(session)

                    requests.get = session.get
                    requests.post = session.post
                    requests.put = session.put
                    requests.delete = session.delete
                    requests.patch = session.patch

                    try:
                        return _orig(*args, **kwargs)
                    finally:
                        requests.get = orig_get
                        requests.post = orig_post
                        requests.put = orig_put
                        requests.delete = orig_delete
                        requests.patch = orig_patch

                tool._run = signed_run

            wrapped.append(tool)

        return wrapped


def xat_tool(private_key_pem=None, key_file=None, agent_id="default", kms_sign=None):
    """Decorator that wraps a function's HTTP calls with Agent-Signature signing.

    Usage:
        @xat_tool(key_file="agent.pem", agent_id="my-agent")
        def search(query: str) -> str:
            return requests.get(f"https://api.example.com?q={query}").text
    """
    signer = XATSigner(
        private_key_pem=private_key_pem,
        key_file=key_file,
        agent_id=agent_id,
        kms_sign=kms_sign,
    )

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            import requests
            session = _requests.Session()
            signer.patch_session(session)

            orig_get = requests.get
            orig_post = requests.post

            requests.get = session.get
            requests.post = session.post

            try:
                return func(*args, **kwargs)
            finally:
                requests.get = orig_get
                requests.post = orig_post

        return wrapper
    return decorator
