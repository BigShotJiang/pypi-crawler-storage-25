"""XAT Callback Handler -- LangChain callback that logs all signed tool calls.

Provides an audit trail of which agent signed which tool call and when.
"""

from langchain_core.callbacks import BaseCallbackHandler


class XATCallbackHandler(BaseCallbackHandler):
    """Logs XAT signing events during LangChain tool execution.

    Usage:
        from xat_langchain import XATCallbackHandler
        handler = XATCallbackHandler()
        agent.invoke({"input": "..."}, config={"callbacks": [handler]})
        print(handler.signed_calls)
    """

    def __init__(self):
        self.signed_calls = []

    def on_tool_start(self, serialized, input_str, **kwargs):
        self.signed_calls.append({
            "tool": serialized.get("name", "unknown"),
            "input": input_str[:200] if isinstance(input_str, str) else str(input_str)[:200],
            "event": "tool_start",
        })

    def on_tool_end(self, output, **kwargs):
        if self.signed_calls:
            self.signed_calls[-1]["event"] = "tool_end"
            self.signed_calls[-1]["output_length"] = len(str(output))

    def on_tool_error(self, error, **kwargs):
        if self.signed_calls:
            self.signed_calls[-1]["event"] = "tool_error"
            self.signed_calls[-1]["error"] = str(error)[:200]
