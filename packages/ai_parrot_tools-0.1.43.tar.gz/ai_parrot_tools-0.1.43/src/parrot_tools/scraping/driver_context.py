"""
Driver Context Manager — manages browser driver lifecycle.

Provides a plugin-style ``DriverRegistry`` for registering driver factories
and an async context manager ``driver_context()`` that handles session-based
(persistent) and per-operation (fresh) driver modes.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Callable, Dict, Optional

from .drivers.abstract import AbstractDriver
from .toolkit_models import DriverConfig

logger = logging.getLogger(__name__)


class DriverRegistry:
    """Plugin-style registry for browser driver factories.

    Driver factories are callables that accept a ``DriverConfig`` and return
    a setup object with an ``async def get_driver()`` method.

    Usage::

        DriverRegistry.register("selenium", my_selenium_factory)
        factory = DriverRegistry.get("selenium")
    """

    _factories: Dict[str, Callable[[DriverConfig], Any]] = {}

    @classmethod
    def register(cls, driver_type: str, factory: Callable[[DriverConfig], Any]) -> None:
        """Register a driver factory for a given driver type.

        Args:
            driver_type: Identifier for the driver (e.g. ``"selenium"``, ``"playwright"``).
            factory: Callable that accepts a ``DriverConfig`` and returns a
                setup object with ``async def get_driver()``.
        """
        cls._factories[driver_type] = factory
        logger.debug("Registered driver factory: %s", driver_type)

    @classmethod
    def unregister(cls, driver_type: str) -> None:
        """Remove a registered driver factory.

        Args:
            driver_type: Identifier to remove.
        """
        cls._factories.pop(driver_type, None)

    @classmethod
    def get(cls, driver_type: str) -> Callable[[DriverConfig], Any]:
        """Get a registered driver factory.

        Args:
            driver_type: Identifier of the driver factory.

        Returns:
            The registered factory callable.

        Raises:
            ValueError: If the driver type is not registered.
        """
        if driver_type not in cls._factories:
            raise ValueError(
                f"Unknown driver type: {driver_type!r}. "
                f"Registered: {list(cls._factories.keys())}"
            )
        return cls._factories[driver_type]

    @classmethod
    def list_registered(cls) -> list[str]:
        """Return list of registered driver type names.

        Returns:
            List of driver type identifiers.
        """
        return list(cls._factories.keys())


class _SeleniumSetupAdapter:
    """Setup-style wrapper that adapts ``SeleniumDriver`` to the registry.

    The registry contract requires an object with ``async def get_driver()``
    that returns a ready-to-use driver. Selenium's lifecycle is
    ``SeleniumSetup.__init__`` → ``await get_driver()`` (returns raw WebDriver);
    this adapter instead builds a ``SeleniumDriver`` (an ``AbstractDriver``)
    and starts it, so the registry always yields an ``AbstractDriver`` —
    never a raw ``selenium.webdriver.WebDriver``.

    Args:
        config: Browser configuration from ``DriverConfig``.
    """

    def __init__(self, config: DriverConfig) -> None:
        self._config = config

    async def get_driver(self) -> AbstractDriver:
        """Instantiate and start a ``SeleniumDriver``.

        Returns:
            A started ``SeleniumDriver`` instance (an ``AbstractDriver``).
        """
        from .drivers.selenium_driver import SeleniumDriver

        options: Dict[str, Any] = {
            "timeout": self._config.default_timeout,
            "disable_images": self._config.disable_images,
        }
        if self._config.custom_user_agent:
            options["custom_user_agent"] = self._config.custom_user_agent
        if self._config.mobile_device:
            options["mobile_device"] = self._config.mobile_device

        driver = SeleniumDriver(
            browser=self._config.browser,
            headless=self._config.headless,
            auto_install=self._config.auto_install,
            mobile=self._config.mobile,
            options=options,
        )
        await driver.start()
        return driver


def _create_selenium_setup(config: DriverConfig) -> Any:
    """Create a Selenium adapter from a DriverConfig.

    Returns a ``_SeleniumSetupAdapter`` whose ``get_driver()`` yields a
    started ``SeleniumDriver`` (an ``AbstractDriver``), replacing the
    previous pattern that returned a raw ``SeleniumSetup`` whose
    ``get_driver()`` yielded a raw ``selenium.webdriver.WebDriver``.

    Args:
        config: Browser configuration.

    Returns:
        A ``_SeleniumSetupAdapter`` instance.
    """
    return _SeleniumSetupAdapter(config)


# Generic browser-name → Playwright browser-type mapping.
# Mirrors ``DriverFactory._BROWSER_TO_PLAYWRIGHT`` so callers can keep using
# ``DriverConfig.browser="chrome"`` regardless of the backend.
_BROWSER_TO_PLAYWRIGHT: Dict[str, str] = {
    "chrome": "chromium",
    "chromium": "chromium",
    "firefox": "firefox",
    "safari": "webkit",
    "webkit": "webkit",
    "edge": "chromium",
}


class _PlaywrightSetup:
    """Setup-style wrapper that adapts ``PlaywrightDriver`` to the registry.

    The registry contract requires an object with ``async def get_driver()``
    that returns a ready-to-use driver. Playwright's lifecycle is
    ``__init__`` → ``await start()``; this wrapper bridges the two so a
    started ``PlaywrightDriver`` (an ``AbstractDriver``) is returned.
    """

    def __init__(self, config: DriverConfig) -> None:
        self._config = config

    async def get_driver(self) -> AbstractDriver:
        """Instantiate and start a ``PlaywrightDriver``.

        Returns:
            A started ``PlaywrightDriver`` instance (an ``AbstractDriver``).
        """
        from .drivers.playwright_config import PlaywrightConfig
        from .drivers.playwright_driver import PlaywrightDriver

        browser = (self._config.browser or "chromium").lower()
        pw_browser = _BROWSER_TO_PLAYWRIGHT.get(browser, browser)
        pw_config = PlaywrightConfig(
            browser_type=pw_browser,
            headless=self._config.headless,
            timeout=self._config.default_timeout,
            mobile=self._config.mobile,
            device_name=self._config.mobile_device,
            extra_http_headers=(
                {"User-Agent": self._config.custom_user_agent}
                if self._config.custom_user_agent
                else None
            ),
        )
        driver = PlaywrightDriver(pw_config)
        await driver.start()
        return driver


def _create_playwright_setup(config: DriverConfig) -> Any:
    """Create a Playwright setup wrapper from a DriverConfig.

    Args:
        config: Browser configuration.

    Returns:
        A ``_PlaywrightSetup`` instance whose ``get_driver()`` returns a
        started ``PlaywrightDriver``.
    """
    return _PlaywrightSetup(config)


# Register the built-in driver factories.
DriverRegistry.register("selenium", _create_selenium_setup)
DriverRegistry.register("playwright", _create_playwright_setup)


async def _quit_driver(driver: Any) -> None:
    """Quit a driver, handling both sync and async ``quit()`` methods.

    All drivers registered after FEAT-104 implement ``AbstractDriver`` and
    expose an ``async def quit()``; the sync fallback is retained for
    third-party or legacy drivers that may still be registered externally.

    Args:
        driver: Browser driver instance.
    """
    if hasattr(driver, "quit"):
        result = driver.quit()
        if asyncio.iscoroutine(result):
            await result


@asynccontextmanager
async def driver_context(
    config: DriverConfig,
    session_driver: Optional[Any] = None,
) -> AsyncIterator[Any]:
    """Async context manager that yields a browser driver.

    In session mode (``session_driver`` provided), the existing driver is
    yielded without lifecycle management. In fresh mode, a new driver is
    created from the registry, yielded, and quit on exit.

    Args:
        config: Driver configuration.
        session_driver: Existing driver to reuse (session mode). If ``None``,
            a fresh driver is created and destroyed.

    Yields:
        A browser driver instance.
    """
    if session_driver is not None:
        logger.debug("Using session driver (reuse mode)")
        yield session_driver
    else:
        factory = DriverRegistry.get(config.driver_type)
        setup = factory(config)
        logger.debug("Creating fresh %s driver", config.driver_type)
        driver = await setup.get_driver()
        try:
            yield driver
        finally:
            logger.debug("Quitting fresh %s driver", config.driver_type)
            await _quit_driver(driver)
