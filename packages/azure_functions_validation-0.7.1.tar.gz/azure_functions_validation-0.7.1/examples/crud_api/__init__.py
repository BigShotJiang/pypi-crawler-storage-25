"""CRUD API example package."""
