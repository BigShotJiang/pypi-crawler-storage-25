# perfact-api-app-model

SQLAlchemy models for the `app` namespace — the authentication and authorization tables used by `perfact-api-main`. Part of the `perfact.api.app.model` namespace.

## Models

| Class | Table | Purpose |
|---|---|---|
| `AppUser` | `appuser` | User accounts |
| `AppUserKey` | `appuserkey` | API keys belonging to a user |
| `AppUserLogin` | `appuserlogin` | Active login sessions (cookie tracking) |
| `AppGroup` | `appgroup` | Groups, each carrying a Zope role name |
| `AppPerm` | `appperm` | Named permissions |
| `AppStc` | `appstc` | Organisational scope tree (hierarchical) |
| `AppUserXPerm` | `appuserxperm` | User ↔ permission assignments |
| `AppUserXStc` | `appuserxstc` | User ↔ scope assignments |
| `AppPermXGroup` | `apppermxgroup` | Permission ↔ group assignments |
| `AppPermXStc` | `apppermxstc` | Permission ↔ scope assignments |
| `AppStc_Paths` | `appstc_paths` (view) | Materialised ancestor paths for the scope tree |

## How the permission model works

A user is granted access to a scope (`AppStc`) via `AppUserXStc`. Within that scope, a user has permissions (`AppPerm`) via `AppUserXPerm`. Each permission can be linked to one or more groups (`AppGroup`), and each group carries a Zope role name. The effective roles for a user in a given scope are resolved by walking the `AppStc_Paths` view upward through the scope hierarchy.

## Dependencies

- `perfact-api-base-model`
- `sqlalchemy`
- `psycopg[c]`
- `pydantic-settings`

## Maintainers

- Viktor Dick <viktor.dick@perfact.de>
- Alexander Rolfes <alexander.rolfes@perfact.de>
