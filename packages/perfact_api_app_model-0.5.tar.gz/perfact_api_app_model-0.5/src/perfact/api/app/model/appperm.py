from perfact.api.base.model import Base, Mapped


class AppPerm(Base):
    name: Mapped[str]
