from perfact.api.base.model import Base, Mapped


class AppGroup(Base):
    zoperole: Mapped[str]
