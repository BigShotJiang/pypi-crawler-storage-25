from perfact.api.base.model import Base, Mapped


class AppUser(Base):
    name: Mapped[str]
    password: Mapped[str | None]
