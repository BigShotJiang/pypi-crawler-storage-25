from perfact.api.base.model import Base, ForeignKey, Mapped, mapped_column, relationship

from .appuser import AppUser


class AppUserKey(Base):
    appuser_id: Mapped[int] = mapped_column(ForeignKey(AppUser.id))
    key: Mapped[str]
    appuser: Mapped[AppUser] = relationship()
