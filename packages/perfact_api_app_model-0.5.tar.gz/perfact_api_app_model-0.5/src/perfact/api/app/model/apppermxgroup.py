from perfact.api.base.model import Base, ForeignKey, Mapped, mapped_column, relationship

from .appgroup import AppGroup
from .appperm import AppPerm


class AppPermXGroup(Base):
    appgroup_id: Mapped[int] = mapped_column(ForeignKey(AppGroup.id))
    appperm_id: Mapped[int] = mapped_column(ForeignKey(AppPerm.id))
    perm: Mapped[AppPerm] = relationship()
    group: Mapped[AppGroup] = relationship()
