from perfact.api.base.model import Base, ForeignKey, Mapped, mapped_column, relationship

from .appperm import AppPerm
from .appuser import AppUser


class AppUserXPerm(Base):
    appuser_id: Mapped[int] = mapped_column(ForeignKey(AppUser.id))
    appperm_id: Mapped[int] = mapped_column(ForeignKey(AppPerm.id))
    needsgrant: Mapped[bool] = mapped_column(server_default="false")
    user: Mapped[AppUser] = relationship()
    perm: Mapped[AppPerm] = relationship()
