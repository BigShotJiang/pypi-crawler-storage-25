import time
from dataclasses import dataclass
from typing import Optional

from perfact.api.base.model import Base
from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    MetaData,
    Table,
    delete,
    select,
    text,
)
from sqlalchemy.orm import Mapped, Session

metadata_obj = MetaData()


class AppTblCleanup(Base):
    tablename: Mapped[str]
    range: Mapped[Optional[str]]
    filter: Mapped[Optional[str]]

    @dataclass
    class RunResult:
        count: int  # number of deleted records
        elapsed: float  # time in seconds it took
        limit_reached: bool  # if the limit was reached

    def run(self, session: Session) -> RunResult:
        """
        Execute cleanup for the selected table.
        """
        start = time.monotonic()
        LIMIT = 100_000
        table = Table(
            self.tablename,
            metadata_obj,
            Column(f"{self.tablename}_id", Integer, primary_key=True, key="id"),
            Column(f"{self.tablename}_modtime", DateTime(timezone=True), key="modtime"),
            extend_existing=True,
        )
        ids_select = (
            select(table.c.id)
            .where(table.c.modtime < text("now() - (:ival)::interval"))
            .where(text(self.filter or "true"))
            .params(ival=self.range)
            .order_by(table.c.id)
            .limit(LIMIT)
        )
        # Use connection().execute() (Core layer) instead of session.execute()
        # (ORM layer): return type is CursorResult, which exposes rowcount.
        # Also skips autoflush — intentional, this worker runs in its own
        # session with no pending state.
        result = session.connection().execute(
            delete(table).where(table.c.id.in_(ids_select))
        )
        count = result.rowcount
        elapsed = time.monotonic() - start
        return AppTblCleanup.RunResult(
            count=count,
            limit_reached=(count == LIMIT),
            elapsed=elapsed,
        )

    @staticmethod
    def run_cleanup_batches(session: Session):
        """
        Clean up data according to given rules in apptblcleanup.
        Commits after each processed batch. Returns a mapping from table name to
        number of entries deleted.
        """

        result = session.execute(select(AppTblCleanup))
        rows = list(result.scalars().all())
        stats = {
            row.tablename: AppTblCleanup.RunResult(
                count=0,
                elapsed=0.0,
                limit_reached=False,
            )
            for row in rows
        }
        while rows:
            new_rows = []
            for row in rows:
                res = row.run(session)
                tgt = stats[row.tablename]
                tgt.count += res.count
                tgt.elapsed += res.elapsed
                tgt.limit_reached = tgt.limit_reached or res.limit_reached
                if res.limit_reached:
                    new_rows.append(row)

                yield stats

            rows = new_rows
