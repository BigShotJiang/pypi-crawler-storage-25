from typing import List, Optional, Sequence, Type

from perfact.api.base.model import Base
from sqlalchemy import (
    ARRAY,
    BigInteger,
    ColumnElement,
    ScalarSelect,
    Select,
    and_,
    cast,
    func,
    join,
    literal,
    or_,
    select,
)
from sqlalchemy.dialects.postgresql import array

from .appstc import AppStc_Paths
from .authinfo import AuthInfo


class Selfilterable:
    """
    selfilters is a mechanism which creates visibility rules for a table.
    The rule is defined by a SQL WHERE statement.
    This statement should be added to all queries to the database.
    The selfilter can be retrived by calling the classmethod `get_selfilter`.
    """

    @classmethod
    def get_selfilter(cls, auth: Optional[AuthInfo]) -> ColumnElement[bool]:
        """
        returns the selfilter as a ColumnElement which can be used in
        a WHERE/filter statement.

        usage:
            select(MtArt).filter(
                MtArt.get_selfilter(...)
            )
        """
        raise NotImplementedError(f"No selfilter defined for {cls.__name__}")

    @staticmethod
    def generate_selfilter_stc_query(
        entity: Type[Base],
        stcrefcol: Optional[str] = None,
        stcmxntable: Optional[Type[Base]] = None,
        mxnflags: Sequence[str] = [],
        appstc_ids=None,
        inherit=False,
    ) -> Select:
        """
        this implements
        PerFact.WebApp.db_selfilter_sql_d.methods.appstc_query_iq
        the sqlalchemy way.

        The stcrefcol-column (e.g. <entity>_appstc_id) is used via AppStc_Paths to
        find object ids linked to the given appstc.
        If `stcmxntable` is set, the mxn-table is used to find
        the object ids linked to the given appstc.

        mxnflags:
            Optional list of flags that must exist as additional boolean
            columns of the MxN table. If set, only entries with this flag are
            considered.

        returns:
        filter statement returning all object ids that are
        mapped to the given appstc and allowed to present to the user.

        usage:
            conditions = [
                MtArt.generate_selfilter_stc_query(appstc_ids=[stc.id]),
            ]

        """
        if (stcmxntable is None) == (stcrefcol is None):
            raise RuntimeError("Either mxn or refcol need to be supplied")

        main_table = entity
        tbl = main_table.__tablename__

        # build up where statement
        conditions: List[ColumnElement[bool]] = [
            AppStc_Paths.id_path.bool_op("&&")(
                cast(array(appstc_ids), ARRAY(BigInteger))
            ),
        ]

        if inherit:
            subquery: ScalarSelect[bool] = (
                select(
                    func.bool_or(
                        AppStc_Paths.id_path.op("&&")(func.array(AppStc_Paths.id))
                    )
                )
                .filter(AppStc_Paths.id.in_(appstc_ids))
                .scalar_subquery()
            )

            conditions.append(subquery)

        if stcmxntable:
            mxn_table = entity.metadata.tables[stcmxntable.__tablename__]

            column_names = mxn_table.c[f"{tbl}_id"]

            join_on = [or_(AppStc_Paths.id == mxn_table.c["appstc_id"])]

            for flag in mxnflags:
                join_on.append(mxn_table.c[flag])

            j = join(
                mxn_table,
                AppStc_Paths,
                and_(*join_on),
            )
        elif stcrefcol:
            column_names = getattr(main_table, "id")
            j = join(
                tbl,
                AppStc_Paths,
                AppStc_Paths.id == getattr(main_table, stcrefcol),
            )

        query = select(column_names).select_from(j).where(or_(*conditions))
        return query

    @staticmethod
    def generate_selfilter_open():
        """
        this implements a open selfilter (everything is accessible)
        the sqlalchemy way.
        """
        return literal(True)
