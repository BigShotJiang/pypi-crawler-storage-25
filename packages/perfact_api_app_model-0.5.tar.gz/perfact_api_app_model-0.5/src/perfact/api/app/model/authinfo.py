from dataclasses import dataclass
from typing import Optional


@dataclass
class AuthInfo:
    """
    Authentication information for the current user
    """

    name: str
    roles: list[str]
    appstc: Optional[int]
