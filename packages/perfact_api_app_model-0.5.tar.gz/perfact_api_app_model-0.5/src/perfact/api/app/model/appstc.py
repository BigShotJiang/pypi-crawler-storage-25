from perfact.api.base.model import Base, ForeignKey, Mapped, View, mapped_column
from sqlalchemy.types import ARRAY, Integer


class AppStc(Base):
    name: Mapped[str]
    parent_appstc_id: Mapped[int | None] = mapped_column(ForeignKey("appstc.id"))


class AppStc_Paths(View):
    __tablename__ = "appstc_paths"
    id: Mapped[int] = mapped_column("id", primary_key=True)
    id_path: Mapped[list[int]] = mapped_column(
        "id_path", ARRAY(Integer, as_tuple=True, zero_indexes=True)
    )
    depth: Mapped[int] = mapped_column("depth")
