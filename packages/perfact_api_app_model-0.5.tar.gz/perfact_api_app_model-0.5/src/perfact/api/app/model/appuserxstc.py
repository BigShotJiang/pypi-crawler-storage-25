from perfact.api.base.model import Base, ForeignKey, Mapped, mapped_column, relationship

from .appstc import AppStc
from .appuser import AppUser


class AppUserXStc(Base):
    appuser_id: Mapped[int] = mapped_column(ForeignKey(AppUser.id))
    appstc_id: Mapped[int] = mapped_column(ForeignKey(AppStc.id))

    user: Mapped[AppUser] = relationship()
    stc: Mapped[AppStc] = relationship()
