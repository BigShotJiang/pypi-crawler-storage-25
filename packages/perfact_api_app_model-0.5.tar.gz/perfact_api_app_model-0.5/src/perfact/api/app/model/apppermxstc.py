from perfact.api.base.model import Base, ForeignKey, Mapped, mapped_column, relationship

from .appperm import AppPerm
from .appstc import AppStc


class AppPermXStc(Base):
    appperm_id: Mapped[int] = mapped_column(ForeignKey(AppPerm.id))
    appstc_id: Mapped[int] = mapped_column(ForeignKey(AppStc.id))

    perm: Mapped[AppPerm] = relationship()
    stc: Mapped[AppStc] = relationship()
