from perfact.api.base.model import Base, ForeignKey, Mapped, mapped_column, relationship

from .appuser import AppUser


class AppUserLogin(Base):
    appuser_id: Mapped[int] = mapped_column(ForeignKey(AppUser.id))
    cookie: Mapped[str | None]
    nextcookie: Mapped[str | None]
    done: Mapped[bool] = mapped_column(default=False)
    user: Mapped[AppUser] = relationship()
