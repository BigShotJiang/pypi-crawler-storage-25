# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
tox                     # Format check + lint + security + type check
ruff format src         # Auto-format
ruff check src          # Lint
mypy src                # Type check
bandit --configfile bandit.yml -r src  # Security check
```

No unit tests currently exist (commented out in `tox.ini`).

Version is derived from git tags via `setuptools-scm`. PyPI publish triggers on tags matching `[0-9]*`.

## Architecture

SQLAlchemy 2.x ORM models for the `perfact.api.app.model` namespace — the auth/authz data layer used by `perfact-api-main`. All models inherit from `perfact.api.base.model.Base` (external private package), which provides the `id` primary key.

### Data Model

Ten tables + one view implementing user/permission/scope management:

| Class | Table | Role |
|---|---|---|
| `AppUser` | `appuser` | User accounts |
| `AppUserKey` | `appuserkey` | API keys per user |
| `AppUserLogin` | `appuserlogin` | Active login sessions |
| `AppGroup` | `appgroup` | Groups carrying Zope role names |
| `AppPerm` | `appperm` | Named permission definitions |
| `AppStc` | `appstc` | Hierarchical org scope tree (self-referential) |
| `AppUserXPerm` | `appuserxperm` | User ↔ permission (has `needsgrant` flag) |
| `AppUserXStc` | `appuserxstc` | User ↔ scope |
| `AppPermXGroup` | `apppermxgroup` | Permission ↔ group |
| `AppPermXStc` | `apppermxstc` | Permission ↔ scope |
| `AppStc_Paths` | `appstc_paths` | **View**: materialized ancestor paths (ARRAY) |

`AppStc_Paths` extends `View` (not `Base`) — read-only; SQL defined in `schema/tables/appstc/`.

`AppTblCleanup` (`apptblcleanup.py`) is a non-model utility: batched deletion of old records (100k rows/batch) from any table, used by background workers.

### Permission Flow

User exercises a permission within a scope. Permissions map to groups (= Zope role names). `AppStc_Paths` walks the scope hierarchy to resolve inherited roles.

### Conventions

- SQLAlchemy 2.0 mapped annotations: `Mapped[type]`, `mapped_column()`, `relationship()`
- Nullable columns: `Mapped[str | None]`
- Server-side defaults: `mapped_column(server_default="false")`
- Every FK has a companion `relationship()`
- `__init__.py` re-exports all models — import from package root
- `py.typed` present; keep all models fully typed
