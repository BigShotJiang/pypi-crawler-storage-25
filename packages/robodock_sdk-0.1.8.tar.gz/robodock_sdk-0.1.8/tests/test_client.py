"""测试RoboDockClient类."""

import pytest
from unittest.mock import Mock, patch
from robodock_sdk import RoboDockClient


@pytest.fixture
def client():
    """创建RoboDockClient实例用于测试."""
    with patch('boto3.client'):
        return RoboDockClient(
            s3_endpoint="http://test:9000",
            api_url="http://test:8080"
        )


def test_client_init(client):
    """测试客户端初始化."""
    assert client.actions is not None
    assert client.actions.server_url == "http://test:8080"


def test_client_init_rejects_empty_string():
    """传入空字符串应抛出异常."""
    with patch("boto3.client"):
        with pytest.raises(ValueError):
            RoboDockClient(s3_endpoint=" ")


def test_get_dataset(client):
    """测试获取数据集."""
    with patch.object(client.actions, 'get_dataset_info') as mock_get:
        mock_get.return_value = {"data": {"uuid": "test"}}
        
        result = client.get_dataset("test-uuid")
        
        assert result == {"data": {"uuid": "test"}}
        mock_get.assert_called_once_with("test-uuid")


def test_update_run_status(client):
    """测试更新运行状态."""
    with patch.object(client.actions, 'update_run') as mock_update:
        mock_update.return_value = 200
        
        result = client.update_run_status(
            unique_name="test-run",
            status="success",
            finish_time=123456
        )
        
        assert result == 200
        mock_update.assert_called_once()
        call_args = mock_update.call_args
        assert call_args[0][0] == "test-run"
        assert call_args[0][1]["status"] == "success"
        assert call_args[0][1]["finish_time"] == 123456
