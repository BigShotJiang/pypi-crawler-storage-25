"""测试工具函数."""

import pytest
import os
from unittest.mock import patch
from robodock_sdk.utils import (
    get_env_config,
    is_resume_enabled,
    get_unique_name
)


def test_get_env_config_default():
    """测试默认配置."""
    with patch.dict(os.environ, {}, clear=True):
        config = get_env_config()
        
        assert config['PROJECT_NAME'] == 'default_project'
        assert config['RUN_NAME'] == 'default_run'
        assert config['BATCH_SIZE'] == '32'


def test_get_env_config_custom():
    """测试自定义配置."""
    env_vars = {
        'PROJECT_NAME': 'my_project',
        'RUN_NAME': 'run_001',
        'BATCH_SIZE': '64'
    }
    
    with patch.dict(os.environ, env_vars, clear=True):
        config = get_env_config()
        
        assert config['PROJECT_NAME'] == 'my_project'
        assert config['RUN_NAME'] == 'run_001'
        assert config['BATCH_SIZE'] == '64'


def test_is_resume_enabled_true():
    """测试恢复训练启用."""
    with patch.dict(os.environ, {'RESUME': 'true'}, clear=True):
        assert is_resume_enabled() is True
    
    with patch.dict(os.environ, {'RESUME': 'True'}, clear=True):
        assert is_resume_enabled() is True


def test_is_resume_enabled_false():
    """测试恢复训练禁用."""
    with patch.dict(os.environ, {'RESUME': 'false'}, clear=True):
        assert is_resume_enabled() is False
    
    with patch.dict(os.environ, {}, clear=True):
        assert is_resume_enabled() is False


def test_get_unique_name():
    """测试生成唯一名称."""
    # 使用参数
    name = get_unique_name('project1', 'run1')
    assert name == 'project1-run1'
    
    # 使用环境变量
    with patch.dict(os.environ, {'PROJECT_NAME': 'proj', 'RUN_NAME': 'run'}, clear=True):
        name = get_unique_name()
        assert name == 'proj-run'
