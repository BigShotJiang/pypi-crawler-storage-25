"""RoboDock SDK - Python SDK for RoboDock Platform."""

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.0.0+unknown"

from .client import RoboDockClient
from .actions import RoboDockActions

__all__ = ["RoboDockClient", "RoboDockActions", "__version__"]
