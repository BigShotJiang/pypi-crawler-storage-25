"""RoboDock SDK utilities."""

import os
from typing import Dict, Optional


def get_env_config() -> Dict[str, str]:
    """从环境变量获取配置信息。
    
    Returns:
        配置字典
    """
    return {
        'PROJECT_NAME': os.getenv('PROJECT_NAME', 'default_project'),
        'RUN_NAME': os.getenv('RUN_NAME', 'default_run'),
        'SAVE_INTERVAL': os.getenv('SAVE_INTERVAL', '5000'),
        'DATASET_DIR': os.getenv('DATASET_DIR', ''),
        'BATCH_SIZE': os.getenv('BATCH_SIZE', '32'),
        'NUM_TRAIN_STEPS': os.getenv('NUM_TRAIN_STEPS', '20000'),
        'LOG_INTERVAL': os.getenv('LOG_INTERVAL', '10'),
        'WANDB_ENABLED': os.getenv('WANDB_ENABLED', 'false'),
        'WANDB_API_KEY': os.getenv('WANDB_API_KEY', ''),
        'PRETRAIN_MODEL': os.getenv('PRETRAIN_MODEL', ''),
        'RESUME': os.getenv('RESUME', 'false'),
        'RESUME_FROM': os.getenv('RESUME_FROM', ''),
        'OUTPUT_DIR': os.getenv('OUTPUT_DIR', '/workspace/checkpoints'),
        'DATASET_UUID': os.getenv('DATASET_UUID', ''),
    }


def is_resume_enabled() -> bool:
    """检查是否启用恢复训练。
    
    Returns:
        是否启用恢复
    """
    return os.getenv('RESUME', 'false').lower() == 'true'


def get_unique_name(project_name: Optional[str] = None, run_name: Optional[str] = None) -> str:
    """生成唯一的运行名称。
    
    Args:
        project_name: 项目名称
        run_name: 运行名称
        
    Returns:
        唯一名称
    """
    project = project_name or os.getenv('PROJECT_NAME', 'default_project')
    run = run_name or os.getenv('RUN_NAME', 'default_run')
    return f"{project}-{run}"
