"""底层Actions API使用示例."""

import logging
from robodock_sdk.actions import RoboDockActions

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    """使用底层Actions API进行更细粒度的控制。"""
    
    # 创建Actions实例
    actions = RoboDockActions(
        s3_endpoint="http://192.168.1.6:9000",
        s3_access_key="robodock",
        s3_secret_key="robodock",
        api_url="http://192.168.1.2:31080",
        bucket_name="robodock-data"
    )
    
    # 1. 获取数据集信息
    logger.info("获取数据集信息...")
    dataset_uuid = "your-dataset-uuid"
    try:
        dataset_info = actions.get_dataset_info(dataset_uuid)
        logger.info(f"数据集信息: {dataset_info}")
    except Exception as e:
        logger.error(f"失败: {e}")
    
    # 2. 获取单条数据信息
    logger.info("获取单条数据信息...")
    data_uuid = "your-data-uuid"
    try:
        data_info = actions.get_singledata_info(data_uuid)
        logger.info(f"数据信息: {data_info}")
    except Exception as e:
        logger.error(f"失败: {e}")
    
    # 3. 下载数据
    logger.info("下载数据...")
    try:
        local_path = actions.download_data(
            data_name="data.zip",
            uuid=data_uuid,
            dirname="singledata"
        )
        logger.info(f"数据已下载到: {local_path}")
    except Exception as e:
        logger.error(f"失败: {e}")
    
    # 4. 更新单条数据
    logger.info("更新数据检查结果...")
    try:
        status = actions.update_singledata(
            uuid=data_uuid,
            checker_result="pass",
            checker_info="数据验证通过"
        )
        logger.info(f"更新成功，状态码: {status}")
    except Exception as e:
        logger.error(f"失败: {e}")
    
    # 5. 获取运行信息
    logger.info("获取运行信息...")
    run_uuid = "your-run-uuid"
    try:
        run_info = actions.get_run_info(run_uuid, unique_type="uuid")
        logger.info(f"运行信息: {run_info}")
    except Exception as e:
        logger.error(f"失败: {e}")
    
    # 6. 更新运行状态
    logger.info("更新运行状态...")
    import time
    try:
        status = actions.update_run(
            unique_name=run_uuid,
            body={
                "status": "processing",
                "start_time": int(time.time() * 1000),
                "progress": 0.5
            },
            unique_type="uuid"
        )
        logger.info(f"更新成功，状态码: {status}")
    except Exception as e:
        logger.error(f"失败: {e}")
    
    # 7. 下载检查点
    logger.info("下载检查点...")
    try:
        checkpoint_path = actions.download_checkpoint(
            online_path="checkpoints/model.tar",
            local_path="/local/checkpoints"
        )
        logger.info(f"检查点已下载到: {checkpoint_path}")
    except Exception as e:
        logger.error(f"失败: {e}")
    
    # 8. 上传数据
    logger.info("上传数据...")
    try:
        s3_key = actions.upload_data(
            outdir_path="/local/model/output",
            upload_path="models/project/run"
        )
        logger.info(f"数据已上传: {s3_key}")
    except Exception as e:
        logger.error(f"失败: {e}")


if __name__ == "__main__":
    main()
