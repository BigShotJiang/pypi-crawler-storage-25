"""已合并示例。

异步上传checkpoint示例已合并到 basic_usage.py。
请运行 `python examples/basic_usage.py` 查看异步上传演示。
"""
