# RoboDock SDK 示例

本目录包含RoboDock SDK的使用示例。

## 示例列表

### 1. basic_usage.py
基础SDK使用示例，展示核心功能：
- 创建客户端
- 获取数据集/数据信息
- 下载数据
- 更新任务状态
- 上传模型

运行方式：
```bash
python examples/basic_usage.py
```

### 2. training_workflow.py
完整的训练工作流示例，展示：
- 使用环境变量配置
- 完整的训练流程
- 错误处理
- 任务状态管理
- 模型上传与清理

运行方式：
```bash
# 设置环境变量
export PROJECT_NAME=my_project
export RUN_NAME=run_001
export DATASET_UUID=your-dataset-uuid
export OUTPUT_DIR=/workspace/checkpoints

# 运行示例
python examples/training_workflow.py
```

### 3. actions_api.py
底层Actions API使用示例，展示：
- 直接使用RoboDockActions类
- 更细粒度的API控制
- 各种操作的具体用法

运行方式：
```bash
python examples/actions_api.py
```


## 环境变量

训练工作流示例支持以下环境变量：

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| PROJECT_NAME | 项目名称 | default_project |
| RUN_NAME | 运行名称 | default_run |
| DATASET_UUID | 数据集UUID | (必填) |
| OUTPUT_DIR | 输出目录 | /workspace/checkpoints |
| RESUME | 是否恢复训练 | false |
| RESUME_FROM | 恢复的运行UUID | - |
| SAVE_INTERVAL | 保存间隔 | 5000 |
| BATCH_SIZE | 批次大小 | 32 |
| NUM_TRAIN_STEPS | 训练步数 | 20000 |

## 注意事项

1. 运行示例前请确保已安装SDK：
   ```bash
   pip install -e .
   ```

2. 示例中的UUID和路径需要替换为实际值

3. 确保网络可以访问配置的S3和API端点
