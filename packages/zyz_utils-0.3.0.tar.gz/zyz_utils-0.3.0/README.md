# zyz_utils

This is a simple utility package containing basic functionality.

## Installation

```bash
pip install zyz_utils
```

## Usage

```python
from zyz_utils import getAllFiles

# Example usage:
files = getAllFiles('.')
print(files)
```
