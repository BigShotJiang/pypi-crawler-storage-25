import numpy as np
import os
import matplotlib.pyplot as plt
import time
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
import open3d as o3d
import laspy
try:
    import cupy as cp
except ImportError:
    cp = None

'''-------------------------------
@func	: getAllFiles
@Time	: 2023/07/11 08:48:43
@Author : Yuzhu Zhou
@explain : Obtain all files in the current directory
@input : targetDir：Path directory
@output : listFiles： File list
-------------------------------'''
def getAllFiles(targetDir):
    listFiles = os.listdir(targetDir)
    return listFiles


'''-------------------------------
@func	: plot_3d_normal
@Time	: 2025/04/17 16:27:54
@Author : Yuzhu Zhou
@explain : 绘制三维点云和法向量
@from   : chatgpt
-------------------------------'''
def plot_3d_normal(points, colors=[], normals=[]):
    # 创建3D图像
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    # 绘制点
    ax.scatter(points[:, 0], points[:, 1], points[:, 2], 
            c='r', s=50, label='Points', depthshade=True)

    # 绘制法向量（箭头）
    ax.quiver(points[:, 0], points[:, 1], points[:, 2],
            normals[:, 0], normals[:, 1], normals[:, 2],
            length=1.0, color='b', alpha=0.6, arrow_length_ratio=0.1, label='Normals')

    # 设置坐标轴标签和图例
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('3D Points with Normals')
    ax.legend()

    plt.tight_layout()
    plt.show()


    '''-------------------------------
@func	: pca_compute
@Time	: 2024/04/15 16:44:24
@Author : Yuzhu Zhou
@explain : 
@from : 点云侠
-------------------------------'''
def pca_compute(data, sort=True):
    """
     SVD分解计算点云的特征值与特征向量
    :param data: 输入数据
    :param sort: 是否将特征值特征向量进行排序
    :return: 特征值与特征向量
    """
    average_data = np.mean(data, axis=0)  # 求均值
    decentration_matrix = data - average_data  # 去中心化
    H = np.dot(decentration_matrix.T, decentration_matrix)  # 求解协方差矩阵 H
    eigenvectors, eigenvalues, eigenvectors_T = np.linalg.svd(H)  # SVD求解特征值、特征向量

    if sort:
        sort = eigenvalues.argsort()[::-1]  # 降序排列
        eigenvalues = eigenvalues[sort]  # 索引
        eigenvectors = eigenvectors[sort]

    return eigenvalues, eigenvectors


'''-------------------------------
@func	: fit_plane_sklearn
@Time	: 2025/04/09 15:48:46
@Author : Yuzhu Zhou
@explain : pca拟合平面方程
-------------------------------'''
def fit_plane_sklearn(points):
    """
    使用Scikit-learn的PCA拟合平面
    :param points: Nx3的numpy数组
    :return: 平面系数A, B, C, D (Ax + By + Cz + D = 0)
    """
    pca = PCA(n_components=3)
    pca.fit(points)
    
    # 最小方差方向就是平面的法向量
    normal = pca.components_[2]
    centroid = np.mean(points, axis=0)
    
    A, B, C = normal
    D = -np.dot(normal, centroid)
    
    # 归一化平面方程
    norm_factor = np.sqrt(A**2 + B**2 + C**2)
    A, B, C, D = A/norm_factor, B/norm_factor, C/norm_factor, D/norm_factor
    
    return round(A,3), round(B,3), round(C,3), round(D,3)

'''-------------------------------
@func	: 
@Time	: 2025/04/30 11:05:10
@Author : Yuzhu Zhou
@explain : 倾向倾角计算
@from   : 葛老师
-------------------------------'''
def Occurrence_calculation(A,B,C):
    dip = np.degrees(np.arccos(abs(C) / np.sqrt(pow(A,2) + pow(B,2) + pow(C,2))))
    dip_angle = 0
    if A >= 0 and B >= 0 and C >= 0:
        dip_angle = np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))
    elif A < 0 and B > 0 and C >= 0:
        dip_angle =360 - np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))
    elif A < 0 and B < 0 and C >= 0:
        dip_angle = 180 + np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))
    elif A > 0 and B < 0 and C >= 0:
        dip_angle = 180 - np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))
    elif A >= 0 and B >= 0 and C < 0:
        dip_angle = 180 + np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))
    elif A < 0 and B > 0 and C < 0:
        dip_angle = 180 - np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))
    elif A < 0 and B < 0 and C < 0:
        dip_angle = np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))
    elif A > 0 and B < 0  and C < 0:
        dip_angle = 360 - np.degrees(np.arcsin(np.fabs(A) / np.sqrt(pow(A,2) + pow(B,2))))

    return round(dip,2), round(dip_angle,2)


'''-------------------------------
@func	: softmax
@Time	: 2024/04/17 11:10:08
@Author : Yuzhu Zhou
@explain : 归一化
-------------------------------'''
def softmax(logits, enhance = True):
    exp_logits = np.exp(logits - np.max(logits))  # 减去最大值以提高数值稳定性
    k = 1
    if enhance:
        k = len(logits)

    return exp_logits *k / np.sum(exp_logits, axis=-1, keepdims=True)


'''-------------------------------
@func	: compute_angles
@Time	: 2025/03/14 15:00:09
@Author : Yuzhu Zhou
@explain : 计算两组向量两两之间的角度
-------------------------------'''
def compute_angles(a, b):
    """
    通过邻域一致性统一法向量朝向。

    参数:
        a (np.array n*3): 第一组向量
        b (np.array n*3): 第二组向量
    返回:
        angles (np.array): 一一对应的法向量的夹角 弧度制。
    """
    # 计算点积
    dot_products = np.sum(a * b, axis=1)
    
    # 计算向量的模
    norm_a = np.linalg.norm(a, axis=1)
    norm_b = np.linalg.norm(b, axis=1)
    
    # 计算夹角的余弦值
    cos_theta = dot_products / (norm_a * norm_b)
    
    # 避免数值误差导致cos_theta超出[-1, 1]范围
    cos_theta = np.clip(cos_theta, -1.0, 1.0)
    
    # 计算夹角（弧度）
    angles = np.arccos(cos_theta)
    
    return angles


'''-------------------------------
@func	: 
@Time	: 2025/03/27 10:53:52
@Author : Yuzhu Zhou
@explain : 
@from: chatgpt  Robust normal vector estimation in 3D point clouds through iterative principal component analysis
-------------------------------'''
def is_on_edge(points, normals, n_neighbors):
    """
    判断每个点是否位于边缘

    参数：
    - points: 一个 (n_points, 3) 的 cupy 数组，表示所有三维点
    - normals: 一个 (n_points, 3) 的 cupy 数组，表示每个点的法向量
    - thresh_proj: 一个浮动阈值，表示投影误差的最大容忍值
    - n_neighbors: 邻域点的数量，用于最近邻搜索

    返回：
    - results: 一个布尔数组，表示每个点是否在边缘
    """
    # 使用 NearestNeighbors 来找到每个点的邻域
    nbrs = NearestNeighbors(n_neighbors=n_neighbors)
    nbrs.fit(points)  # 转换为 numpy 数组进行最近邻搜索
    distances, indices = nbrs.kneighbors(points)

    indeces_gpu = indices
    points_gpu = cp.asarray(points)
    normals_gpu = cp.asarray(normals)
    # 计算邻域的均值中心 pt_moy
    neighborhood_gpu = points_gpu[indeces_gpu]  # 获取每个点的邻域
    pt_moy = cp.mean(neighborhood_gpu, axis=1)  # 每个点邻域的均值

    # 计算投影误差的平方和 proj_moy
    diff = neighborhood_gpu - cp.expand_dims(pt_moy, axis=1)  # 计算邻域点与均值中心的偏移
    
    proj = cp.sum(diff * cp.expand_dims(normals_gpu, axis=1), axis=2)  # 计算偏移在法向量方向上的投影
    proj_moy = cp.mean(proj**2, axis=1)  # 计算每个点的投影误差的平方和
    proj_moy = cp.sqrt(proj_moy)  # 计算均方根投影误差
    cp.get_default_memory_pool().free_all_blocks()
    return proj_moy


'''-------------------------------
@func	: load_point_cloud_file
@Time	: 2024/10/17 11:06:36
@Author : Yuzhu Zhou
@explain : 加载点云数据
-------------------------------'''
def load_point_cloud_file(file_path, format, time_record = True):
    if format == 'pts':
        point_cloud= o3d.io.read_point_cloud(file_path)
    if format == 'txt':
        start_time = time.time() # 记录开始时间
        data = np.loadtxt(file_path)

        point_cloud = o3d.geometry.PointCloud()
        point_cloud.points = o3d.utility.Vector3dVector(data[:,:3])
        try:
            point_cloud.colors = o3d.utility.Vector3dVector(data[:,-3:])
        except:
            pass
        scalar = data[:,3]
        print("scalar shape", scalar.shape)
        end_time = time.time()   # 记录结束时间
        execution_time = end_time - start_time # 计算执行时间
        if time_record:
            print("数据读取时间为：", execution_time)
        return point_cloud, scalar

    if format == 'las':
        start_time = time.time() # 记录开始时间

        point_cloud = o3d.geometry.PointCloud()
        
        raw_data = laspy.file.File(file_path)
        file_name = (file_path.split('\\')[-1].split('.')[0])

        points = raw_data.points
        header = raw_data.header
        offset = header.offset
        scale = header.scale
        X = raw_data.X * scale[0]
        Y = raw_data.Y * scale[1]
        Z = raw_data.Z * scale[2]
        if raw_data.red.any():
            R = raw_data.red / 256 / 256
            G = raw_data.green / 256 / 256
            B = raw_data.blue / 256 / 256
            colors = np.column_stack((R,G,B))
            point_cloud.colors = o3d.utility.Vector3dVector(colors)


        intensity_raw = raw_data.intensity
        if np.mean(raw_data.intensity) > 256:
            intensity = np.array(list(map(int, raw_data.intensity // 257)))
            # self.intensity = np.array(list(map(int, raw_data.intensity & 0x00ff)))
        else:
            intensity = np.array(list(map(int, raw_data.intensity)))
        points = np.column_stack((X,Y,Z))
        point_cloud.points = o3d.utility.Vector3dVector(points)

        intensity_dev = [-1] * len(points)
        raw_data.close()
        end_time = time.time()   # 记录结束时间
        execution_time = end_time - start_time # 计算执行时间
        print("las数据读取运行时间为：", execution_time)

    return point_cloud

'''-------------------------------
@func	: write_out_point
@Time	: 2024/03/10 09:40:41
@Author : Yuzhu Zhou
@explain : 导出点云数据
-------------------------------'''
def write_out_point(out_path, points, colors=[], intensity=[], normals = [], format='pts'):
    if format == 'txt':
        if len(colors) and len(intensity) and len(normals):
            fmt_list = ['%f'] * 4 + ['%d'] * 3 + ['%f'] * 3  # 前4列浮点，后3列整数
            fmt_str = ' '.join(fmt_list)
            result =  np.column_stack((points, np.array(intensity)))
            result =  np.column_stack((result, np.array(colors)))
            result =  np.column_stack((result, np.array(normals)))
            np.savetxt(out_path, result, fmt=fmt_str)
        elif len(colors) and len(normals):
            fmt_list = ['%f'] * 3 + ['%d'] * 3 + ['%f'] * 3  # 前4列浮点，后3列整数
            fmt_str = ' '.join(fmt_list)
            result =  np.column_stack((points, np.array(colors)))
            result =  np.column_stack((result, np.array(normals)))
            np.savetxt(out_path, result, fmt=fmt_str)
        elif len(colors) and len(intensity):
            fmt_list = ['%f'] * 4 + ['%d'] * 3  # 前4列浮点，后3列整数
            fmt_str = ' '.join(fmt_list)
            result =  np.column_stack((points, np.array(intensity)))
            result =  np.column_stack((result, np.array(colors)))
            np.savetxt(out_path, result, fmt=fmt_str)
        elif len(normals) and len(intensity):
            result =  np.column_stack((points, np.array(intensity)))
            result =  np.column_stack((result, np.array(normals)))
            np.savetxt(out_path, result, fmt='%f')
        elif len(colors):
            fmt_list = ['%f'] * 3 + ['%d'] * 3  # 前4列浮点，后3列整数
            fmt_str = ' '.join(fmt_list)
            result =  np.column_stack((points, np.array(colors)))
            np.savetxt(out_path, result, fmt=fmt_str)
        elif len(normals):
            result =  np.column_stack((points, np.array(normals)))
            np.savetxt(out_path, result, fmt='%f')
        elif len(intensity):
            result =  np.column_stack((points, np.array(intensity)))
            np.savetxt(out_path, result, fmt='%f')
        else:
            np.savetxt(out_path, points, fmt='%f')
    else:
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(np.array(points))
        if normals:
            print('有法向量')
            pcd.normals = o3d.utility.Vector3dVector(np.array(normals))
        if colors:
            pcd.colors = o3d.utility.Vector3dVector(np.array(colors))
        o3d.io.write_point_cloud(out_path, pcd,  write_ascii=True)



'''-------------------------------
@func	: calculate_density_gpu
@Time	: 2025/03/14 16:04:28
@Author : Yuzhu Zhou
@explain : 使用sklearn进行最近邻搜索，计算点最小平均距离
-------------------------------'''
def calculate_density_sklearn(pcd, show_time = False):
    """
    计算点云密度（ 加速版本，使用 sklearn 进行最近邻搜索）

    参数:
        pcd: Open3D 点云对象
        k: 最近邻点的数量（取最近的第 2 个点，因为第 1 个点是自身）
    """
    # 将点云数据转换为 numpy 数组
    start_time = time.time()
    points = np.asarray(pcd.points, dtype=np.float32)
    point_size = points.shape[0]

    # K 近邻搜索（用 sklearn 生成最邻近点矩阵）
    nbrs = NearestNeighbors(n_neighbors=2, algorithm='kd_tree').fit(points)
    distances, _ = nbrs.kneighbors(points)
    density = np.mean(distances, axis=0)[1]
    # 计算点云的中心
    x_center = np.mean(points[:, 0])
    y_center = np.mean(points[:, 1])

    end_time = time.time()
    if show_time:
        print('sklearn 密度计算耗时：{}s'.format(end_time - start_time))
    return density, x_center, y_center, point_size


'''-------------------------------
@func	: rotate_points
@Time	: 2023/07/11 09:29:32
@Author : Yuzhu Zhou
@explain : Rotate the point at an Angle to the center point
-------------------------------'''
def rotate_points(points, center, angle):
    '''-------------------------------
    inputs : 
        points : data, Rotating point (array)
        center : data, Center of rotation (array)
        angle : The Angle you need to rotate
    outputs : 
        final_points : The point after rotation (array)
    -------------------------------'''
    # 将角度转换为弧度
    angle_rad = np.deg2rad(angle)

    # 计算相对于中心点的坐标
    translated_points = points - center

    # 应用旋转矩阵
    rotation_matrix = np.array([[np.cos(angle_rad), -np.sin(angle_rad)],
                                [np.sin(angle_rad), np.cos(angle_rad)]])
    rotated_points = np.dot(translated_points, rotation_matrix.T)

    # 将相对坐标转换回绝对坐标
    final_points = rotated_points + center

    return final_points