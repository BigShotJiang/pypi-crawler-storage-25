//! Shared metric selection primitives used by `diff` and `top-offenders`.
//!
//! A *selector* is a known metric name (e.g. `loc.lloc`) bundled with the
//! extraction closure that pulls the value out of a [`FuncSpace`], a display
//! label, and a [`Polarity`] (whether higher or lower values are "better").

use crate::spaces::FuncSpace;

/// Whether a metric is "better" when higher or lower.
///
/// Used by callers to interpret deltas/rankings (e.g. `Cyclomatic` is
/// [`Polarity::LowerIsBetter`], while `Mi` is [`Polarity::HigherIsBetter`]).
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
#[serde(rename_all = "kebab-case")]
pub(crate) enum Polarity {
    LowerIsBetter,
    HigherIsBetter,
}

/// A selector for a single metric column: name, display label, polarity,
/// and a function that extracts the value from a [`FuncSpace`].
#[derive(Debug, Clone)]
pub(crate) struct MetricSelector {
    pub(crate) name: &'static str,
    pub(crate) label: &'static str,
    pub(crate) polarity: Polarity,
    pub(crate) extract: fn(&FuncSpace) -> f64,
}

type MetricDef = (&'static str, &'static str, Polarity, fn(&FuncSpace) -> f64);

/// Catalogue of metrics that can be referenced by name from the CLI.
pub(crate) const KNOWN_METRICS: &[MetricDef] = &[
    ("cyclomatic", "Cyclomatic", Polarity::LowerIsBetter, |s| {
        s.metrics.cyclomatic.cyclomatic_sum()
    }),
    ("cognitive", "Cognitive", Polarity::LowerIsBetter, |s| {
        s.metrics.cognitive.cognitive_sum()
    }),
    ("nom.functions", "Functions", Polarity::LowerIsBetter, |s| {
        s.metrics.nom.functions_sum()
    }),
    ("loc.lloc", "LLOC", Polarity::LowerIsBetter, |s| {
        s.metrics.loc.lloc()
    }),
    (
        "mi.original",
        "MI (Original)",
        Polarity::HigherIsBetter,
        |s| s.metrics.mi.mi_original(),
    ),
    ("mi.sei", "MI (SEI)", Polarity::HigherIsBetter, |s| {
        s.metrics.mi.mi_sei()
    }),
    ("mi.visual_studio", "MI", Polarity::HigherIsBetter, |s| {
        s.metrics.mi.mi_visual_studio()
    }),
    (
        "halstead.volume",
        "Halstead Vol",
        Polarity::LowerIsBetter,
        |s| s.metrics.halstead.volume(),
    ),
    ("abc", "ABC", Polarity::LowerIsBetter, |s| {
        s.metrics.abc.magnitude_sum()
    }),
];

/// Default metric set for `diff` (kept here so both diff and top-offenders
/// can surface the same fallback from a single source of truth).
pub(crate) const DEFAULT_METRICS: &[&str] = &[
    "cyclomatic",
    "cognitive",
    "nom.functions",
    "loc.lloc",
    "mi.visual_studio",
];

/// Parse a list of metric specs into resolved [`MetricSelector`]s.
///
/// A spec is a bare metric name (`cognitive`) or a polarity-prefixed name
/// (`+nom.functions`, `-mi.visual_studio`). Unknown names emit a warning and
/// are skipped.
///
/// When `specs` is empty, [`DEFAULT_METRICS`] is used as a fallback. This is
/// the contract `diff` expects. Callers that want "no fallback" (e.g.
/// `top-offenders`, where `--metric` is required) should enforce that at the
/// CLI layer before calling this function.
pub(crate) fn parse_metric_selectors(specs: &[String]) -> Vec<MetricSelector> {
    let specs: Vec<&str> = if specs.is_empty() {
        DEFAULT_METRICS.to_vec()
    } else {
        specs.iter().map(|s| s.as_str()).collect()
    };

    let mut selectors = Vec::new();
    for spec in specs {
        let (polarity_override, name) = if let Some(rest) = spec.strip_prefix('+') {
            (Some(Polarity::HigherIsBetter), rest)
        } else if let Some(rest) = spec.strip_prefix('-') {
            (Some(Polarity::LowerIsBetter), rest)
        } else {
            (None, spec)
        };

        if let Some(&(n, label, default_polarity, extract)) =
            KNOWN_METRICS.iter().find(|(n, ..)| *n == name)
        {
            selectors.push(MetricSelector {
                name: n,
                label,
                polarity: polarity_override.unwrap_or(default_polarity),
                extract,
            });
        } else {
            log::warn!("Unknown metric '{name}', skipping.");
        }
    }

    selectors
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_apply_when_specs_empty() {
        let selectors = parse_metric_selectors(&[]);
        assert_eq!(selectors.len(), DEFAULT_METRICS.len());
        for (sel, expected) in selectors.iter().zip(DEFAULT_METRICS.iter()) {
            assert_eq!(sel.name, *expected);
        }
    }

    #[test]
    fn polarity_prefix_overrides_default() {
        let specs = vec!["+loc.lloc".to_string(), "-mi.visual_studio".to_string()];
        let selectors = parse_metric_selectors(&specs);
        assert_eq!(selectors.len(), 2);
        assert_eq!(selectors[0].name, "loc.lloc");
        assert_eq!(selectors[0].polarity, Polarity::HigherIsBetter);
        assert_eq!(selectors[1].name, "mi.visual_studio");
        assert_eq!(selectors[1].polarity, Polarity::LowerIsBetter);
    }

    #[test]
    fn unknown_metric_is_skipped() {
        let specs = vec!["nonexistent".to_string()];
        let selectors = parse_metric_selectors(&specs);
        assert!(selectors.is_empty());
    }

    #[test]
    fn bare_mi_is_unknown() {
        // `mi` by itself isn't a leaf — you must pick a variant.
        let specs = vec!["mi".to_string()];
        let selectors = parse_metric_selectors(&specs);
        assert!(selectors.is_empty());
    }
}
