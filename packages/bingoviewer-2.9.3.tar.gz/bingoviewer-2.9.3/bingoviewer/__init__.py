"""BiNgo Genome Viewer — a lightweight browser-based genomics viewer."""

__version__ = "2.9.3"
