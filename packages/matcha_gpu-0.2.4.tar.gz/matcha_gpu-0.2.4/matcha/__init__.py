"""
matcha — GPU energy metering for AI training workloads.

Copyright (c) 2025 Keeya Labs. All rights reserved.

    import matcha
    m = matcha.init()
    m.step_start()
    ...
    m.step_end(step)
    m.finish()
"""

from .api import init, watch, Meter
from ._engine import StepResult, SessionResult

__version__ = "0.2.3"
__all__ = ["init", "watch", "Meter", "StepResult", "SessionResult"]
