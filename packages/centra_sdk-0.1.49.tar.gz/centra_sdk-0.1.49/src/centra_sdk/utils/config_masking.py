"""Utility for masking secret values in configurations before logging."""

from typing import List, Optional

from centra_sdk.models.connector.v1.operations.config import ConfigOpts, InternalConfig


def mask_config_secrets(
    config: InternalConfig,
    schema: Optional[List[ConfigOpts]],
    mask_unknown: bool = True
) -> List[dict]:
    """Mask secret values in configuration for safe logging.

    Args:
        config: The InternalConfig object containing configurations to mask
        schema: The configuration schema containing metadata about which fields are secrets
        mask_unknown: If True (default), mask fields not found in schema for security.
                     If False, preserve unknown field values.

    Returns:
        List of dictionaries with secret values replaced by "***"

    Example:
        >>> schema = [
        ...     ConfigOpts(name="api_url", opt_type=OptType.OPT_STRING,
        ...                default_value="", description="API URL", secret=False),
        ...     ConfigOpts(name="api_key", opt_type=OptType.OPT_STRING,
        ...                default_value="", description="API Key", secret=True)
        ... ]
        >>> config = InternalConfig(configs=[
        ...     Configuration(name="api_url", value="https://example.com"),
        ...     Configuration(name="api_key", value="super-secret-123")
        ... ])
        >>> mask_config_secrets(config, schema)
        [
            {"name": "api_url", "value": "https://example.com"},
            {"name": "api_key", "value": "***"}
        ]
    """
    if not schema:
        # No schema = can't determine what's safe, mask everything
        return [{"name": c.name, "value": "***"} for c in config.configs]

    # Build sets of secret and known field names
    secret_names = {opt.name for opt in schema if opt.secret}
    known_names = {opt.name for opt in schema}

    # Mask secrets and optionally unknown fields
    masked_configs = []
    for conf in config.configs:
        is_secret = conf.name in secret_names
        is_unknown = conf.name not in known_names

        should_mask = is_secret or (is_unknown and mask_unknown)

        masked_configs.append({
            "name": conf.name,
            "value": "***" if should_mask else conf.value
        })

    return masked_configs
