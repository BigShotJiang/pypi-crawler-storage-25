import json
from typing import Any

import requests
from dapla_auth_client import AuthClient
from requests import Response


class CollectorClient:
    """Client for interacting with the SSB Collector service.

    This class provides methods to start, stop, and monitor collector tasks.

    Args:
        collector_url: The base URL of the collector service

    Example:
        >>> client = CollectorClient("https://collector.example.com")
        >>> client.collector_url
        'https://collector.example.com'
    """

    def __init__(self, collector_url: str, skip_keycloak_token: bool = False) -> None:
        """Initialize the CollectorClient.

        Args:
            collector_url: The base URL of the collector service
            skip_keycloak_token: If True, the client will not fetch a Keycloak token for authentication. Default is False.
                Used for service-to-service communication where authentication is handled through NAIS service discovery.
        """
        self.collector_url = collector_url
        self.skip_keycloak_token = skip_keycloak_token

    def start(self, specification: dict[str, Any]) -> Response:
        """Start a new collector task.

        Args:
            specification: The JSON object of the collector specification

        Returns:
            Response: The "requests.Response" object from the API call
        """
        if self.skip_keycloak_token:
            auth_header = {}
            keycloak_token = None
        else:
            keycloak_token = AuthClient.fetch_personal_token()
            auth_header = {"Authorization": f"Bearer {keycloak_token}"}

        collector_response = requests.put(
            self.collector_url,
            headers={
                "Content-type": "application/json",
                **auth_header,
            },
            data=json.dumps(specification),
        )
        collector_response.raise_for_status()
        print(
            "Task initiated successfully! Check running tasks with the running_tasks() function."
        )
        return collector_response

    def running_tasks(self) -> Response:
        """Get all running collector tasks.

        Returns:
            Response: The "requests.Response" object from the API call
        """
        if self.skip_keycloak_token:
            auth_header = {}
            keycloak_token = None
        else:
            keycloak_token = AuthClient.fetch_personal_token()
            auth_header = {"Authorization": f"Bearer {keycloak_token}"}

        collector_response = requests.get(self.collector_url, headers=auth_header)
        collector_response.raise_for_status()
        return collector_response

    def stop(self, task_id: int) -> Response:
        """Stop a running collector task.

        Args:
            task_id: The id of the task to stop.

        Returns:
            Response: The "requests.Response" object from the API call
        """
        if self.skip_keycloak_token:
            auth_header = {}
            keycloak_token = None
        else:
            keycloak_token = AuthClient.fetch_personal_token()
            auth_header = {"Authorization": f"Bearer {keycloak_token}"}

        collector_response = requests.delete(
            f"{self.collector_url}/{task_id}",
            headers=auth_header,
        )
        if collector_response.status_code == 400:
            print(
                "Collector task with id: "
                + str(task_id)
                + " cannot be stopped! Maybe it was already stopped or completed"
            )
        else:
            print("Collector task with id: " + str(task_id) + " stopped successfully")

        return collector_response


def start(
    collector_url: str, specification: dict[str, Any], skip_keycloak_token: bool = False
) -> Response:
    """Start a new collector task.

    Args:
        collector_url: The URL of the collector service
        specification: The JSON object of the collector specification
        skip_keycloak_token: If True, the client will not fetch a Keycloak token for authentication. Default is False.
            Used for service-to-service communication where authentication is handled through NAIS service discovery.

    Returns:
        Response: The "requests.Response" object from the API call
    """
    if skip_keycloak_token:
        auth_header = {}
        keycloak_token = None
    else:
        keycloak_token = AuthClient.fetch_personal_token()
        auth_header = {"Authorization": f"Bearer {keycloak_token}"}

    collector_response = requests.put(
        collector_url,
        headers={
            "Content-type": "application/json",
            **auth_header,
        },
        data=json.dumps(specification),
    )
    collector_response.raise_for_status()
    print(
        "Task initiated successfully! Check running tasks with the running_tasks() function."
    )
    return collector_response


def running_tasks(collector_url: str, skip_keycloak_token: bool = False) -> Response:
    """Get all running collector tasks.

    Args:
        collector_url: The URL of the collector service
        skip_keycloak_token: If True, the client will not fetch a Keycloak token for authentication. Default is False.
            Used for service-to-service communication where authentication is handled through NAIS service discovery.

    Returns:
        Response: The "requests.Response" object from the API call
    """
    if skip_keycloak_token:
        auth_header = {}
        keycloak_token = None
    else:
        keycloak_token = AuthClient.fetch_personal_token()
        auth_header = {"Authorization": f"Bearer {keycloak_token}"}

    collector_response = requests.get(collector_url, headers=auth_header)
    collector_response.raise_for_status()
    return collector_response


def stop(
    collector_url: str, task_id: int, skip_keycloak_token: bool = False
) -> Response:
    """Stop a running collector task.

    Args:
        collector_url: The URL of the collector service
        task_id: The id of the task to stop.
        skip_keycloak_token: If True, the client will not fetch a Keycloak token for authentication. Default is False.
            Used for service-to-service communication where authentication is handled through NAIS service discovery.

    Returns:
        Response: The "requests.Response" object from the API call
    """
    if skip_keycloak_token:
        auth_header = {}
        keycloak_token = None
    else:
        keycloak_token = AuthClient.fetch_personal_token()
        auth_header = {"Authorization": f"Bearer {keycloak_token}"}

    collector_response = requests.delete(
        f"{collector_url}/{task_id}",
        headers=auth_header,
    )
    if collector_response.status_code == 400:
        print(
            "Collector task with id: "
            + str(task_id)
            + " cannot be stopped! Maybe it was already stopped or completed"
        )
    else:
        print("Collector task with id: " + str(task_id) + " stopped successfully")

    return collector_response
