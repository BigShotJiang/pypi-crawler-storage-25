"""Command-line interface."""

import click


@click.command()
@click.version_option()
def main() -> None:
    """SSB Collector Client."""


if __name__ == "__main__":
    main(prog_name="ssb_collector_client")  # pragma: no cover
