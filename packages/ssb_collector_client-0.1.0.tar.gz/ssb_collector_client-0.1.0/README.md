# SSB Collector Client

[![PyPI](https://img.shields.io/pypi/v/ssb-collector-client.svg)][pypi status]
[![Status](https://img.shields.io/pypi/status/ssb-collector-client.svg)][pypi status]
[![Python Version](https://img.shields.io/pypi/pyversions/ssb-collector-client)][pypi status]
[![License](https://img.shields.io/pypi/l/ssb-collector-client)][license]

[![Documentation](https://github.com/statisticsnorway/ssb-collector-client/actions/workflows/docs.yml/badge.svg)][documentation]
[![Tests](https://github.com/statisticsnorway/ssb-collector-client/actions/workflows/tests.yml/badge.svg)][tests]
[![Coverage](https://sonarcloud.io/api/project_badges/measure?project=statisticsnorway_ssb-collector-client&metric=coverage)][sonarcov]
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=statisticsnorway_ssb-collector-client&metric=alert_status)][sonarquality]

[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)][pre-commit]
[![Black](https://img.shields.io/badge/code%20style-black-000000.svg)][black]
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json)][poetry]

[pypi status]: https://pypi.org/project/ssb-collector-client/
[documentation]: https://statisticsnorway.github.io/ssb-collector-client
[tests]: https://github.com/statisticsnorway/ssb-collector-client/actions?workflow=Tests
[sonarcov]: https://sonarcloud.io/summary/overall?id=statisticsnorway_ssb-collector-client
[sonarquality]: https://sonarcloud.io/summary/overall?id=statisticsnorway_ssb-collector-client
[pre-commit]: https://github.com/pre-commit/pre-commit
[black]: https://github.com/psf/black
[poetry]: https://python-poetry.org/

## Features

- Start new data collector tasks with custom specifications
- List all running collector tasks
- Stop running collector tasks by ID
- Built-in authentication using Dapla Auth Client
- Object-oriented API with `CollectorClient` class

## Requirements

- Python 3.10 or higher
- Access to a Data Collector service
- Dapla authentication credentials

## Installation

You can install _SSB Collector Client_ via [pip] from [PyPI]:

```console
pip install ssb-collector-client
```

## Usage

The SSB Collector Client provides an object-oriented interface using the `CollectorClient` class:

### Quick Start

```python
from ssb_collector_client import CollectorClient

# Initialize the client with your collector service URL
client = CollectorClient("https://your-collector-service.no/tasks")

# Define your collector specification
specification = {
    "type": "your-collector-type",
    # ... other specification parameters
}

# Start a new task
response = client.start(specification)

# Get all running tasks
tasks = client.running_tasks()
print(f"Running tasks: {tasks.json()}")

# Stop a specific task by ID
client.stop(task_id=1234)
```

### Complete Example

Here's a complete example using the `CollectorClient` class:

```python
from ssb_collector_client import CollectorClient

# Initialize the client
collector_url = "https://your-collector-service.no/tasks"
client = CollectorClient(collector_url)

# Define your collector specification
specification = {
    "type": "example-type",
    "name": "my-collection-task",
    # ... other specification parameters
}

# Start a new task
print("Starting collector task...")
start_response = client.start(specification)
print(f"Task started: {start_response.status_code}")

# Check running tasks
print("\nChecking running tasks...")
tasks_response = client.running_tasks()
tasks = tasks_response.json()
print(f"Running tasks: {tasks}")

# Stop a specific task if needed
if tasks:
    task_id = 1234  # Replace with actual task ID
    print(f"\nStopping task {task_id}...")
    client.stop(task_id)
```

Please see the [Reference Guide] for details.

## Contributing

Contributions are very welcome.
To learn more, see the [Contributor Guide].

## License

Distributed under the terms of the [MIT license][license],
_SSB Collector Client_ is free and open source software.

## Issues

If you encounter any problems,
please [file an issue] along with a detailed description.

## Credits

This project was generated from [Statistics Norway]'s [SSB PyPI Template].

[statistics norway]: https://www.ssb.no/en
[pypi]: https://pypi.org/
[ssb pypi template]: https://github.com/statisticsnorway/ssb-pypitemplate
[file an issue]: https://github.com/statisticsnorway/ssb-collector-client/issues
[pip]: https://pip.pypa.io/

<!-- github-only -->

[license]: https://github.com/statisticsnorway/ssb-collector-client/blob/main/LICENSE
[contributor guide]: https://github.com/statisticsnorway/ssb-collector-client/blob/main/CONTRIBUTING.md
[reference guide]: https://statisticsnorway.github.io/ssb-collector-client/reference.html
