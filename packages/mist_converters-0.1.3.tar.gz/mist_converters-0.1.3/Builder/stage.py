"""
builder.py
Core components for building Agentic AI Flow Graphs
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
from Converter.tokenizer_utils import count_prompt_tokens, count_tokens, preprocess_tokens
import numpy as np
import json as _json


def token_count(content) -> int:
    """Return token count for any content type (str, list, dict, None)."""
    if not content:
        return 0
    text = content if isinstance(content, str) else _json.dumps(content, ensure_ascii=False)
    return count_tokens(text)


class StageType(Enum):
    """Enumeration of all available stage types"""
    LLM_CALL = "llm_call"
    RAG = "rag"
    MEMORY_RETRIEVAL = "memory_retrieval"
    TOOL_CALL = "tool_call"
    PREPROCESSING = "preprocessing"
    POSTPROCESSING = "postprocessing"
    INPUT = "input"
    OUTPUT = "output"
    UNDEFINED = "undefined"
    AGENT = "agent"


@dataclass
class Stage(ABC):
    """Base class for all agentic AI stages"""
    id: str
    name: str
    stage_type: StageType = field(init=False)
    description: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    inputs: List[str] = field(default_factory=list)  # IDs of previous stages
    outputs: List[str] = field(default_factory=list)  # IDs of next stages
    input_len: int = 0
    output_len: int = 0
    latency: float = None
    @abstractmethod
    def get_display_info(self) -> Dict[str, Any]:
        """Returns information for visualization"""
        rec_uuid = self.metadata.get("uuid", "")
        return {
            "id": self.id,
            "name": self.name,
            "type": self.stage_type.value,
            "description": self.description,
            "input_len": self.input_len,
            "output_len": self.output_len,
            "output_tokens": self.metadata.get("output_tokens"),
            "latency": self.latency,
            "uuid": rec_uuid,
        }
    
    def get_short_label(self) -> str:
        """Returns a short label for display in the node"""
        return self.name
    
    def add_input(self, stage_id: str):
        """Add an input connection"""
        if stage_id not in self.inputs:
            self.inputs.append(stage_id)
    
    def add_output(self, stage_id: str):
        """Add an output connection"""
        if stage_id not in self.outputs:
            self.outputs.append(stage_id)


@dataclass
class LLMCallStage(Stage):
    """Stage for LLM API calls"""
    # model: str = "gpt-4"
    # temperature: float = 0.7
    # max_tokens: int = 1000
    # system_prompt: str = ""
     
    def __init__(self,
        call_type: str = "",
        system_prompt: str = "",
        user_prompt: str = "",
        input_len: int = 0,
        output_len: int = 0,
        past_KV_context: int = 0,
        output_text: str = "",
        model: str = "gpt-4",
        temperature: float = 0.7,
        max_tokens: int = 1000,
        latency: float = None,
        **kwargs):
        super().__init__(**kwargs)

        self.call_type = call_type
        self.stage_type = StageType.LLM_CALL
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        # If input_len not provided, calculate it as sum of system_prompt and user_prompt lengths
        self.system_prompt_len = count_tokens(system_prompt)
        self.user_prompt_len = count_tokens(user_prompt)
        self.input_len = count_prompt_tokens(system_prompt, user_prompt) if input_len == 0 else input_len
        self.output = output_text
        self.past_KV_context = past_KV_context
        # Prefer explicit output_len; fall back to counting output_text if provided
        self.output_len = output_len if output_len != 0 else (count_tokens(preprocess_tokens(output_text)) if output_text else 0)
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.latency = latency
        

    
    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        # Prefer model name from metadata (set by parser from JSONL) over the default
        model = self.metadata.get("model") or self.model
        info.update({
            "model": model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "call_type": self.call_type,
            "system_prompt": self.system_prompt,
            "user_prompt": self.user_prompt,
            "input_len": self.input_len,
            "past_KV_context": self.past_KV_context,
            "output": self.output,
            "output_len": self.output_len,
            "system_prompt_len": self.system_prompt_len,
            "user_prompt_len": self.user_prompt_len,
            # Surface Claude Code-specific fields from metadata as top-level entries
            "input_tokens": self.metadata.get("input_tokens"),
            "output_tokens": self.metadata.get("output_tokens"),
            "thinking": self.metadata.get("thinking"),
            "thinking_len": self.metadata.get("thinking_len"),
            "session": self.metadata.get("session"),
            "timestamp": self.metadata.get("timestamp"),
            "metadata": self.metadata,
        })
        return info
    
    def get_short_label(self) -> str:
        return f"{self.name}"


@dataclass
class RAGStage(Stage):
    """Stage for Retrieval-Augmented Generation"""
    vector_store: str = "pinecone"
    top_k: int = 5
    similarity_threshold: float = 0.7
    embedding_model: str = "text-embedding-ada-002"
    
    def __post_init__(self):
        self.stage_type = StageType.RAG
    
    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        info.update({
            "vector_store": self.vector_store,
            "top_k": self.top_k,
            "threshold": self.similarity_threshold
        })
        return info
    
    def get_short_label(self) -> str:
        return f"{self.name}\n{self.vector_store}\ntop_k={self.top_k}"


@dataclass
class MemoryRetrievalStage(Stage):
    """Stage for retrieving conversation memory"""
    memory_type: str = "short_term"  # short_term, long_term, episodic
    retrieval_strategy: str = "recent"  # recent, relevant, summary
    max_items: int = 10
    
    def __post_init__(self):
        self.stage_type = StageType.MEMORY_RETRIEVAL
    
    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        info.update({
            "memory_type": self.memory_type,
            "strategy": self.retrieval_strategy,
            "max_items": self.max_items
        })
        return info
    
    def get_short_label(self) -> str:
        return f"{self.name}\n{self.memory_type}\n{self.retrieval_strategy}"


@dataclass
class ToolCallStage(Stage):
    """Stage for external tool invocation"""
    # tool_name: str = ""
    # parameters: Dict[str, Any] = field(default_factory=dict)
    # timeout: int = 30
    
    def __init__(self,
    input_cmd: str = "",
    action: str = "",
    data_download: float = None,
    tool_name: str = "",
    stage_type: StageType = StageType.TOOL_CALL,
    parameters: Dict[str, Any] = None,
    timeout: int = 30,
    max_latency: float = 10.0,
    min_latency: float = 0.1,
    avg_latency: float = 1.0,
    actions_count: int = 0,
    **kwargs):
        self.tool_name = tool_name
        self.parameters = parameters if parameters is not None else {}
        self.timeout = timeout
        self.max_latency = max_latency
        self.min_latency = min_latency
        self.avg_latency = avg_latency
        super().__init__(**kwargs)
        self.input_cmd = input_cmd
        self.action = action
        self.actions_count = actions_count
        self.stage_type = stage_type

    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        tool_name = self.metadata.get("tool_name") or self.tool_name
        info.update({
            "tool": tool_name,
            "timeout": f"{self.timeout}s",
            "input_cmd": self.input_cmd,
            "action": self.action,
            "max_latency": self.max_latency,
            "min_latency": self.min_latency,
            "latency": self.avg_latency,
            "actions_count": self.actions_count,
            "tool_use_id": self.metadata.get("tool_use_id"),
            "input_preview": self.metadata.get("input_preview"),
            "spawns_subagent": self.metadata.get("spawns_subagent"),
            "subagent_id": self.metadata.get("subagent_id"),
            "timestamp": self.metadata.get("timestamp"),
            "metadata": self.metadata,
        })
        return info
    
    def get_short_label(self) -> str:
        return f"{self.name}\n{self.actions_count} actions"




@dataclass
class PreprocessingStage(Stage):
    """Stage for input preprocessing"""
    operations: List[str] = field(default_factory=list)
    stage_type: StageType = StageType.PREPROCESSING


    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        info.update({
            "operations": ", ".join(self.operations),
            "metadata": self.metadata,
        })
        return info
    
    def get_short_label(self) -> str:
        ops = ", ".join(self.operations[:2])
        if len(self.operations) > 2:
            ops += "..."
        return f"{self.name}\n{ops}"


@dataclass
class PostprocessingStage(Stage):
    """Stage for output postprocessing"""
    operations: List[str] = field(default_factory=list)
    stage_type: StageType = StageType.POSTPROCESSING

    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        info.update({
            "operations": ", ".join(self.operations),
            # Surface Claude Code-specific fields from metadata as top-level entries
            "tool_use_id": self.metadata.get("tool_use_id"),
            "timestamp": self.metadata.get("timestamp"),
            "metadata": self.metadata,
        })
        return info
    
    def get_short_label(self) -> str:
        ops = ", ".join(self.operations[:2])
        if len(self.operations) > 2:
            ops += "..."
        return f"{self.name}\n{ops}"


@dataclass
class InputStage(Stage):
    """Stage representing user or external input"""
    stage_type: StageType = StageType.INPUT

    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        info.update({"metadata": self.metadata})
        return info

    def get_short_label(self) -> str:
        return self.name


@dataclass
class OutputStage(Stage):
    """Stage representing final or intermediate output"""
    stage_type: StageType = StageType.OUTPUT

    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        info.update({"metadata": self.metadata})
        return info

    def get_short_label(self) -> str:
        return self.name


@dataclass
class AgentStage(Stage):
    """Stage representing an Agent tool invocation (spawn + result envelope)."""
    stage_type: StageType = StageType.AGENT

    def get_display_info(self) -> Dict[str, Any]:
        info = super().get_display_info()
        info.update({
            "agent_id": self.metadata.get("agent_id"),
            "tool_names": self.metadata.get("tool_names"),
            "tool_use_id": self.metadata.get("tool_use_id"),
            "timestamp": self.metadata.get("timestamp"),
            "metadata": self.metadata,
        })
        return info

    def get_short_label(self) -> str:
        return self.name


class AgenticGraph:
    """Container for agentic AI workflow graph"""
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self.stages: Dict[str, Stage] = {}
        self.edges: List[tuple] = []
    
    def add_stage(self, stage: Stage):
        """Add a stage to the graph"""
        self.stages[stage.id] = stage
    
    def connect(self, from_id: str, to_id: str):
        """Connect two stages"""
        if from_id not in self.stages or to_id not in self.stages:
            raise ValueError("Both stages must exist in the graph")
        
        self.stages[from_id].add_output(to_id)
        self.stages[to_id].add_input(from_id)
        self.edges.append((from_id, to_id))
    
    def get_stage(self, stage_id: str) -> Optional[Stage]:
        """Get a stage by ID"""
        return self.stages.get(stage_id)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert graph to dictionary"""
        return {
            "name": self.name,
            "description": self.description,
            "stages": {sid: stage.get_display_info() for sid, stage in self.stages.items()},
            "edges": self.edges
        }

