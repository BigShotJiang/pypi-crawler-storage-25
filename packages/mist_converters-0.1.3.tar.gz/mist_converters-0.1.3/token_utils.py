import tiktoken

# cl100k_base is used by GPT-4 / GPT-3.5-turbo — the de-facto standard
# encoding for general-purpose token counting.
_enc = tiktoken.get_encoding("cl100k_base")


def count_tokens(text: str) -> int:
    """Return the number of tokens in text."""
    return len(_enc.encode(text, disallowed_special=()))


def count_prompt_tokens(system_prompt: str, user_prompt: str) -> int:
    """Return total token count across system and user prompts."""
    return count_tokens(system_prompt) + count_tokens(user_prompt)
