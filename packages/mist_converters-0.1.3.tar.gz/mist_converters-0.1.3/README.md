# mist-converters — Claude Code Converter

Converts Claude Code session logs (`.jsonl` files) into **AgenticGraph JSON** files that capture every LLM call, tool use, thinking step, and subagent invocation as a structured graph.

---

## Requirements

- Python 3.9+
- pip

---

## Installation

```bash
pip install mist-converters
```

This installs the `mist-convert` CLI command directly — no cloning needed.

---

## Running

Convert all projects under `~/.claude/projects` (default):

```bash
mist-convert
```

### Custom projects directory

Pass the path to your `.claude/projects` directory:

```bash
mist-convert /path/to/your/.claude/projects
```

### Single project directory

```bash
mist-convert --dir /path/to/single/project
```

---

## Output

All JSON files are written to `claude_code/output/` inside **the directory from which you run the script**. For example, if you run the script from `/home/user/mist-converters`, the output will be at `/home/user/mist-converters/claude_code/output/`. Please send us this full path once the conversion is complete.

```
claude_code/
└── output/
    └── <project-name>/
        └── <session-id>.json
```

Each JSON file is an AgenticGraph for one session:

```json
{
  "name": "...",
  "description": "...",
  "stages": [ ... ],
  "edges": [ { "from": "...", "to": "..." }, ... ]
}
```

---

## Project structure

```
mist-converters/
├── Converter/
│   ├── run_all_projects.sh       ← entry point
│   ├── dir_claude_code_parser.py ← main parser
│   └── tokenizer_utils.py
├── Builder/
│   └── stage.py                  ← AgenticGraph data model
├── token_utils.py                ← tiktoken-based token counter
└── requirements.txt
```
