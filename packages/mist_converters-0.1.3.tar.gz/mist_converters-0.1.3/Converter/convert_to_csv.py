#!/usr/bin/env python3

import json
import csv
import sys
from typing import Dict, List
def parse_latency(raw_latency) -> float:
    """Convert latency values (e.g., '7.064s', '120ms') to seconds."""
    if raw_latency is None:
        return 0.0
    if isinstance(raw_latency, (int, float)):
        return float(raw_latency)

    if isinstance(raw_latency, str):
        text = raw_latency.strip().lower()
        multiplier = 1.0
        if text.endswith("ms"):
            multiplier = 0.001
            text = text[:-2]
        elif text.endswith("s"):
            text = text[:-1]

        try:
            return float(text.strip()) * multiplier
        except ValueError:
            return 0.0

    return 0.0

def load_json_data(file_path: str) -> Dict:
    """Load the JSON trace file."""
    with open(file_path, 'r') as f:
        return json.load(f)

def map_stage_type(stage_type: str, description: str = "") -> str:
    """Map stage type to the required format."""
    if stage_type == "llm_call":
        return "[PREFILL, DECODE]"
    elif stage_type in ("preprocessing", "input"):
        return "[PREPROCESSING]"
    elif stage_type in ("postprocessing", "output"):
        return "[POSTPROCESSING]"
    elif stage_type == "tool_call":
        return "[TOOL_CALL]"
    elif stage_type == "undefined" and "file-history-snapshot" in (description or ""):
        return "[PREPROCESSING]"
    elif stage_type == "undefined" and "last-prompt" in (description or ""):
        return "[POSTPROCESSING]"
    else:
        return f"[{stage_type.upper()}]"

def get_model_name(stage: Dict, node_id: int) -> str:
    """Extract or generate model name."""
    if "model" in stage:
        return stage["model"]
    else:
        # Generate generic model names for non-LLM stages
        stage_type = stage.get("type", "unknown")
        if stage_type in ("preprocessing", "input"):
            return f"Preprocessor_{node_id}"
        elif stage_type in ("postprocessing", "output"):
            return f"Postprocessor_{node_id}"
        elif stage_type == "tool_call":
            return f"Tool_{node_id}"
        else:
            return f"Stage_{node_id}"

def build_dependency_map(dependencies: List[Dict]) -> Dict[str, List[str]]:
    """Build a map of stage dependencies."""
    dep_map = {}
    for dep in dependencies:
        from_stage = dep["from"]
        to_stage = dep["to"]
        
        if to_stage not in dep_map:
            dep_map[to_stage] = []
        dep_map[to_stage].append(from_stage)
    
    return dep_map

def get_dependencies(stage_id: str, dep_map: Dict[str, List[str]], stage_id_to_node: Dict[str, int]) -> str:
    """Get dependencies for a stage as a formatted string."""
    if stage_id not in dep_map:
        return ""
    
    deps = dep_map[stage_id]
    node_deps = []
    
    for dep in deps:
        if dep in stage_id_to_node:
            node_deps.append(str(stage_id_to_node[dep]))
    
    if node_deps:
        return f"[{','.join(node_deps)}]"
    else:
        return ""

def convert_to_csv(json_data: Dict, output_file: str):
    """Convert JSON trace data to CSV format."""
    try:
        stages = json_data.get("stages", [])
        edges = json_data.get("edges", [])

        # Build dependency map
        dep_map = build_dependency_map(edges)

        # Create mapping from stage ID to node number
        stage_id_to_node = {}
        csv_rows = []

        # Process each stage
        for i, stage in enumerate(stages):
            node_id = i + 1
            stage_id = stage.get("id", f"stage_{node_id}")
            stage_id_to_node[stage_id] = node_id

            # Extract stage information
            stage_type_raw = stage.get("type", "unknown")
            description = stage.get("description", "")
            stage_formatted = map_stage_type(stage_type_raw, description)

            model_name = get_model_name(stage, node_id)
            input_length = stage.get("input_len", 0)
            output_length = stage.get("output_len", 0)

            # For now, assign all to graph_1, but this could be made more sophisticated
            graph_id = "graph_1"

            # Dependencies will be filled in second pass
            csv_rows.append({
                'node_id': node_id,
                'stage': stage_formatted,
                'model_name': model_name,
                'input_length': input_length,
                'output_length': output_length,
                'graph_id': graph_id,
                'stage_id': stage_id,
                'latency': parse_latency(stage.get("latency")),
                'dependencies': ""
            })

        # Second pass: fill in dependencies
        for row in csv_rows:
            stage_id = row['stage_id']
            deps = get_dependencies(stage_id, dep_map, stage_id_to_node)
            row['dependencies'] = deps
            del row['stage_id']  # Remove temporary field

        # Write to CSV
        with open(output_file, 'w', newline='') as csvfile:
            fieldnames = ['node_id', 'stage', 'model_name', 'input_length', 'output_length', 'graph_id', 'dependencies','latency']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            writer.writeheader()
            for row in csv_rows:
                writer.writerow(row)

        from collections import Counter
        json_counts = Counter(s.get("type", "unknown") for s in stages)
        csv_counts  = Counter(row['stage'] for row in csv_rows)
        print(f"Converted {len(csv_rows)} stages to CSV format in {output_file}")
        print("JSON stage types (input):")
        for stage_type, count in sorted(json_counts.items()):
            print(f"  {stage_type}: {count}")
        print("CSV stage types (output):")
        for stage_type, count in sorted(csv_counts.items()):
            print(f"  {stage_type}: {count}")
    except Exception as exc:
        import traceback
        traceback.print_exc()
        raise RuntimeError(f"Failed to convert JSON to CSV: {exc}") from exc

def main():
    if len(sys.argv) != 3:
        print("Usage: python convert_to_csv.py <input_json_file> <output_csv_file>")
        sys.exit(1)
    print(len(sys.argv))
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    print(f"Converting {input_file} to {output_file}...")
    
    try:
        json_data = load_json_data(input_file)
        convert_to_csv(json_data, output_file)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()