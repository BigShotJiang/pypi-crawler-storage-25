import re
import json
import sys
from pathlib import Path

# Add parent directory to path to import Builder module
sys.path.insert(0, "/home/ivohra6/mist-converters")

from bs4 import BeautifulSoup
from Builder.stage import (
    AgenticGraph, PostprocessingStage, PreprocessingStage, 
   ToolCallStage, LLMCallStage
)
from Visualizer.visualizer import AgenticGraphVisualizer
from Converter.prompt_extractor import PromptExtractor
from Converter.tokenizer_utils import count_prompt_tokens, count_tokens, convert_json_to_csv
from Converter.base import AgenticGraphConverter

# Initiali# ze prompt extractor globally
prompt_extractor = PromptExtractor()

def parse_webtactix_trace(html_content: str, filename: str = "task.html") -> AgenticGraph:
    """
    Parse WebTactix HTML trace into an AgenticGraph.
    
    Structure:
    1. Task Input (first node)
    2. Constraint Agent (LLM call)
    3. Round 000: Preprocessing only (snapshot + accessibility tree)
    4. Rounds 001+: Planner Outputs -> Decision -> Execute (with optional data_extraction)
    5. Terminal/Finish + Summary
    """
    soup = BeautifulSoup(html_content, 'html.parser')
    graph = AgenticGraph(
        name=f"WebTactix Trace - {Path(filename).stem}",
        description="Agentic workflow trace with task, planning, and execution"
    )

    # --- 1. Task Input Node ---
    task_text = "Task not found"
    task_section = soup.find('div', class_='card-title', string='Task')
    if task_section:
        task_body = task_section.find_next_sibling('div', class_='card-body')
        if task_body:
            kv_table = task_body.find('table', class_='kv')
            if kv_table:
                intent_row = kv_table.find('td', class_='k', string='intent')
                if intent_row:
                    intent_value = intent_row.find_next_sibling('td', class_='v')
                    if intent_value:
                        task_text = intent_value.text.strip()
    
    task_id = "task_input"
    task_stage = PreprocessingStage(
        id=task_id,
        name="Task Input",
        description=task_text[:100] + ("..." if len(task_text) > 100 else ""),
        operations=["intent"],
        metadata={"full_task": task_text}
    )
    graph.add_stage(task_stage)

    # --- 2. Constraint Agent (LLM Call) ---
    constraints_list = []
    constraints_text = []
    constraints_section = soup.find('div', class_='card-title', string='Constraints')
    if constraints_section:
        constraints_body = constraints_section.find_next_sibling('div', class_='card-body')
        if constraints_body:
            tbl = constraints_body.find('table', class_='tbl')
            if tbl:
                tbody = tbl.find('tbody')
                if tbody:
                    rows = tbody.find_all('tr')
                    for row in rows:
                        cols = row.find_all('td')
                        if len(cols) >= 2:
                            kind = cols[0].text.strip()
                            text = cols[1].text.strip()
                            constraints_list.append({"kind": kind, "text": text})
                            constraints_text.append(f"{kind}: {text}")
    
    constraint_desc = "; ".join(constraints_text) if constraints_text else "Process task constraints"
    
    # Create output as JSON string
    constraint_output = json.dumps(constraints_list, indent=2) if constraints_list else "{}"
    
    constraint_id = "constraint_agent"
    system_prompt, user_prompt = prompt_extractor.get_constraint_prompts(task_text)
    input_tokens = count_prompt_tokens(system_prompt, user_prompt)
    input_tokens += count_tokens(task_text)
    constraint_stage = LLMCallStage(
        id=constraint_id,
        name="Constraint Agent",
        description=constraint_desc[:100] + ("..." if len(constraint_desc) > 100 else ""),
        call_type="constraint_processing",
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        input_len=input_tokens,
        output_text=constraint_output,
        model="deepseek",
        metadata={"constraints": constraints_text}
    )
    graph.add_stage(constraint_stage)
    graph.connect(task_id, constraint_id)

    prev_stage_id = constraint_id
    rounds = soup.find_all('details')

    for i, round_elem in enumerate(rounds):
        summary = round_elem.find('summary')
        if not (summary and 'round' in summary.text.lower()):
            continue

        r_match = re.search(r'round (\d+)', summary.text)
        if not r_match:
            continue
            
        r_num = r_match.group(1)
        r_prefix = f"r{r_num}"

        # --- Handle Round 000 (Preprocessing Only) ---
        if r_num == "000":
            prep_id = f"{r_prefix}_preprocessing"
            prep_stage = PreprocessingStage(
                id=prep_id,
                name="Round 000: Initial State",
                description="Capture snapshot and accessibility tree",
                operations=["snapshot_capture", "accessibility_tree_extraction"]
            )
            graph.add_stage(prep_stage)
            graph.connect(prev_stage_id, prep_id)
            prev_stage_id = prep_id
            continue

        # --- Rounds 001+ : Planner -> Decision -> Execute Flow ---
        
        # Extract frontier from round.json
        frontier_val = "[]"
        try:
            frontier_table = round_elem.find('div', class_='subttl', string='round.json')
            if frontier_table:
                table = frontier_table.find_next('table')
                if table:
                    frontier_row = table.find('td', string='frontier')
                    if frontier_row:
                        frontier_val = frontier_row.find_next_sibling('td').text
        except:
            pass

        # 1. Round Start (Preprocessing)
        prep_id = f"{r_prefix}_prep"
        prep_stage = PreprocessingStage(
            id=prep_id,
            name=f"Round {r_num}: State",
            description=f"Frontier: {frontier_val[:60]}...",
            operations=["current state and parent extraction", "last 10 actions tried (history)"],
            metadata={"frontier": frontier_val}
        )
        graph.add_stage(prep_stage)
        graph.connect(prev_stage_id, prep_id)

        # 2. Parallel Planning Stages
        planner_section = round_elem.find('div', class_='card-title', string='planner outputs')
        plan_nodes_ids = []
        
        if planner_section:
            planner_body = planner_section.find_next_sibling('div', class_='card-body')
            plan_cards = planner_body.find_all('section', class_='card') if planner_body else []
            
            for plan_card in plan_cards:
                title_div = plan_card.find('div', class_='card-title')
                if not title_div:
                    continue
                
                plan_name = title_div.text.strip()
                v_match = re.search(r'plan_(v\d+)\.json', plan_name)
                v_id = v_match.group(1) if v_match else "unknown"
                
                # Extract goal
                goal = "No goal found"
                tbl = plan_card.find('table', class_='tbl')
                if tbl:
                    tbody = tbl.find('tbody')
                    if tbody:
                        first_row = tbody.find('tr')
                        if first_row:
                            cols = first_row.find_all('td')
                            if len(cols) > 2:
                                goal = cols[2].text.strip()

                # Extract planner outputs (page_summary, progress_analysis, plans)
                planner_output = {
                    "page_summary": "",
                    "progress_analysis": "",
                    "plans": []
                }

                summary_label = plan_card.find('div', class_='subttl', string='page_summary')
                if summary_label:
                    summary_pre = summary_label.find_next('pre', class_='snippet')
                    if summary_pre:
                        planner_output["page_summary"] = summary_pre.get_text().strip()

                progress_label = plan_card.find('div', class_='subttl', string='progress_analysis')
                if progress_label:
                    progress_pre = progress_label.find_next('pre', class_='snippet')
                    if progress_pre:
                        planner_output["progress_analysis"] = progress_pre.get_text().strip()

                plans_label = plan_card.find('div', class_='subttl', string='plans')
                if plans_label:
                    plans_table = plans_label.find_next('table', class_='tbl')
                    if plans_table:
                        plans_tbody = plans_table.find('tbody')
                        if plans_tbody:
                            for row in plans_tbody.find_all('tr'):
                                cols = [c.get_text().strip() for c in row.find_all('td')]
                                if len(cols) >= 4:
                                    planner_output["plans"].append({
                                        "index": cols[0],
                                        "name": cols[1],
                                        "goal": cols[2],
                                        "steps": cols[3]
                                    })

                plan_stage_id = f"{r_prefix}_plan_{v_id}"
                # TODO - We should have this as an LLM call too. 
                system_prompt, user_prompt_template = prompt_extractor.get_planner_prompts(task_text)
                
                # Add constraints to user prompt
                constraints_str = ""
                if constraints_list:
                    constraints_str = "Constraints:\n" + "\n".join(f"- [{c['kind']}] {c['text']}" for c in constraints_list) + "\n\n"
                
                user_prompt = user_prompt_template + "\n" + constraints_str + f"Goal: {goal}"
                input_tokens = count_prompt_tokens(system_prompt, user_prompt)
                
                # Extract duration from planner card
                planner_duration = ""
                meta_divs = plan_card.find_all('div', class_='meta')
                for meta in meta_divs:
                    meta_text = meta.get_text()
                    if 'duration' in meta_text:
                        dur_match = re.search(r'duration\s+([\d.]+s)', meta_text)
                        if dur_match:
                            planner_duration = dur_match.group(1)
                            break
                
                plan_stage = LLMCallStage(
                    id=plan_stage_id,
                    name=f"Plan {v_id}",
                    description=f"{goal[:80]}{'...' if len(goal) > 80 else ''}",
                    #planning_method="tree_search",
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    input_len=input_tokens,
                    output_text=json.dumps(planner_output, ensure_ascii=True),
                    latency=planner_duration,
                    metadata={"v_id": v_id, "full_goal": goal},
                    model='deepseek'
                )
                graph.add_stage(plan_stage)
                graph.connect(prep_id, plan_stage_id)
                plan_nodes_ids.append(plan_stage_id)

        # Single postprocessing node for all plans
        if plan_nodes_ids:
            postprocess_id = f"{r_prefix}_postprocess"
            postprocess_plan = PostprocessingStage(
                id=postprocess_id,
                name=f"Postprocess Plans",
                operations=["plan_parsing", "action_filter_and_translate", "creates_page_summary"],
            )
            graph.add_stage(postprocess_plan)
            for pid in plan_nodes_ids:
                graph.connect(pid, postprocess_id)

        # 3. Decision Agent (broken into 3 stages: preprocess → LLM call → postprocess)
        decision_section = round_elem.find('div', class_='card-title', string='decision')
        selected_node = "None"
        decision_reason = ""
        decision_type = "unknown"
        decision_duration = ""
        
        if decision_section:
            dec_body = decision_section.find_next_sibling('div', class_='card-body')
            if dec_body:
                # Find the inner decision.json card
                inner_card = dec_body.find('div', class_='card-title', string='decision.json')
                inner_body = inner_card.find_next_sibling('div', class_='card-body') if inner_card else dec_body
                
                # Extract decision type from badge (select_and_execute, reflect_and_replan, or finish)
                badge = inner_body.find('span', class_='badge')
                if badge:
                    decision_type = badge.text.strip()
                
                # Extract duration from meta div
                meta_divs = inner_body.find_all('div', class_='meta')
                for meta in meta_divs:
                    meta_text = meta.get_text()
                    if 'duration' in meta_text:
                        dur_match = re.search(r'duration\s+([\d.]+s)', meta_text)
                        if dur_match:
                            decision_duration = dur_match.group(1)
                    if 'selected:' in meta_text:
                        sel_b = meta.find('b')
                        if sel_b:
                            selected_node = sel_b.text.strip()
                
                # Extract reason from snippet
                reason_pre = inner_body.find('pre', class_='snippet')
                if reason_pre:
                    decision_reason = reason_pre.text.strip()

        # 3a. Decision Preprocessing - operations vary by decision type
        dec_prep_id = f"{r_prefix}_decision_prep"
        
        # Set preprocess operations based on decision type
        if decision_type == "select_and_execute":
            prep_ops = ["validates plans", "early exit if only one valid path"]
            prep_desc = "Prepare plans and context for decision agent"
        elif decision_type == "reflect_and_replan":
            prep_ops = ["summary of failed candidates", "progress analysis"]
            prep_desc = "Analyze failed attempts and prepare for replanning"
        else:
            prep_ops = ["gather_context"]
            prep_desc = "Prepare context for decision"
        
        dec_prep_stage = PreprocessingStage(
            id=dec_prep_id,
            name="Decision: Preprocess",
            description=prep_desc,
            operations=prep_ops
        )
        graph.add_stage(dec_prep_stage)
        
        # Connect postprocess to decision prep
        if plan_nodes_ids:
            graph.connect(postprocess_id, dec_prep_id)
        else:
            graph.connect(prep_id, dec_prep_id)
        
        # 3b. Decision LLM Call
        dec_llm_id = f"{r_prefix}_decision_llm"
        system_prompt, user_prompt_template = prompt_extractor.get_decision_prompts(decision_type)
        user_prompt = user_prompt_template + (f"\nReason: {decision_reason}" if decision_reason else "")
        input_tokens = count_prompt_tokens(system_prompt, user_prompt)
        
        # Create decision output with all extracted information
        decision_output = {
            "decision_type": decision_type,
            "selected": selected_node,
            "reason": decision_reason,
            "duration": decision_duration
        }
        
        dec_llm_stage = LLMCallStage(
            id=dec_llm_id,
            name=f"Decision: {decision_type}",
            description=f"Selected: {selected_node} | {decision_reason[:60]}{'...' if len(decision_reason) > 60 else ''}",
            call_type=decision_type,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            input_len=input_tokens,
            output_text=json.dumps(decision_output, indent=2),
            latency=decision_duration,
            model="deepseek",
            metadata={
                "decision_type": decision_type,
                "selected": selected_node,
                "reason": decision_reason,
                "duration": decision_duration
            }
        )
        graph.add_stage(dec_llm_stage)
        graph.connect(dec_prep_id, dec_llm_id)
        
        # 3c. Decision Postprocessing - operations vary by decision type
        dec_post_id = f"{r_prefix}_decision_post"
        
        # Set postprocess operations based on decision type
        if decision_type == "select_and_execute":
            post_ops = ["pushes other nodes to queue", "calls executor for selected action"]
            post_desc = f"Extract selected node: {selected_node}"
        elif decision_type == "reflect_and_replan":
            post_ops = ["check priority queue", "call executor"]
            post_desc = "Process priority queue and execute"
        else:
            post_ops = ["process_output"]
            post_desc = "Process decision output"
        
        dec_post_stage = PostprocessingStage(
            id=dec_post_id,
            name="Decision: Postprocess",
            description=post_desc,
            operations=post_ops
        )
        graph.add_stage(dec_post_stage)
        graph.connect(dec_llm_id, dec_post_id)

        # 4. Execute Stage (Actions)
        actions_section = round_elem.find('div', class_='card-title', string='actions.json')
        action_executed = False
        
        if actions_section:
            act_body = actions_section.find_next_sibling('div', class_='card-body')
            if act_body:
                tbl = act_body.find('table', class_='tbl')
                
                if tbl:
                    tbody = tbl.find('tbody')
                    if tbody:
                        rows = tbody.find_all('tr')
                        
                        for row in rows:
                            cols = row.find_all('td')
                            if len(cols) < 4:
                                continue
                            
                            act_type = cols[0].text.strip()
                            
                            # Check for execution action
                            if 'exec_ok' in act_type or 'ok' in act_type:
                                src = cols[1].text.strip()
                                dst = cols[2].text.strip()
                                sig = cols[3].text.strip()
                                
                                # Extract derived exec durations from actions section
                                derived_exec_durations = ""
                                
                                # Search for "derived exec durations" text in the actions body
                                all_text = act_body.get_text()
                                derived_match = re.search(r'derived exec durations:\s*count\s+(\d+)\s*\|\s*avg\s+([\d.]+)s\s*\|\s*min\s+([\d.]+)s\s*\|\s*max\s+([\d.]+)s', all_text)
                                if derived_match:
                                    count = derived_match.group(1)
                                    avg = derived_match.group(2)
                                    min_val = derived_match.group(3)
                                    max_val = derived_match.group(4)
                                    derived_exec_durations = f"derived exec durations: count {count} | avg {avg}s | min {min_val}s | max {max_val}s"
                                
                                tool_id = f"{r_prefix}_execute"
                                action_stage = ToolCallStage(
                                    id=tool_id,
                                    name=f"Execute: {src}→{dst}",
                                    description=sig[:100],
                                    tool_name="browser_automation",
                                    action=act_type,
                                    metadata={"src": src, "dst": dst, "signature": sig, "derived_exec_durations": derived_exec_durations},
                                    avg_latency=float(avg) if derived_exec_durations else 0.0,
                                    min_latency=float(min_val) if derived_exec_durations else 0.0,
                                    max_latency=float(max_val) if derived_exec_durations else 0.0,
                                    actions_count=int(count) if derived_exec_durations else 0
                                )
                                graph.add_stage(action_stage)
                                graph.connect(dec_post_id, tool_id)
                                prev_stage_id = tool_id
                                action_executed = True
                                
                                # Check for data_extraction (LLM call)
                                if 'data_extraction' in act_type.lower() or any('extract' in col.text.lower() for col in cols):
                                    extract_id = f"{r_prefix}_data_extraction"
                                    system_prompt, user_prompt_template = prompt_extractor.get_data_extraction_prompts()
                                    extract_stage = LLMCallStage(
                                        id=extract_id,
                                        name="Data Extraction",
                                        description="Extract and structure information from page",
                                        call_type="data_extraction",
                                        system_prompt=system_prompt,
                                        user_prompt=user_prompt,
                                        input_len=input_tokens,
                                        model="deepseek"
                                    )
                                    graph.add_stage(extract_stage)
                                    graph.connect(tool_id, extract_id)
                                    prev_stage_id = extract_id
                                break

        if not action_executed:
            prev_stage_id = dec_post_id

    # --- 5. Check for Terminal/Finish and Summary ---
    # Look for Final & Summary section
    final_section = soup.find('div', class_='card-title', string='Final & Summary')
    
    if final_section:
        final_body = final_section.find_next_sibling('div', class_='card-body')
        if final_body:
            kv_table = final_body.find('table', class_='kv')
            
            status = "unknown"
            answer = "N/A"
            reason = ""
            eval_result = ""
            total_rounds = ""
            t_end = ""
            
            if kv_table:
                # Extract all fields from kv table
                for row in kv_table.find_all('tr'):
                    k_cell = row.find('td', class_='k')
                    v_cell = row.find('td', class_='v')
                    
                    if k_cell and v_cell:
                        key = k_cell.text.strip()
                        value = v_cell.text.strip()
                        
                        if key == 'status':
                            status = value
                        elif key == 'answer':
                            answer = value
                        elif key == 'reason':
                            reason = value
                        elif key == 'eval':
                            eval_result = value
                        elif key == 'total_rounds':
                            total_rounds = value
                        elif key == 't_end':
                            t_end = value
            
            # Add Finish node
            # finish_id = "finish"
            # finish_stage = ReasoningStage(
            #     id=finish_id,
            #     name=f"Terminal: {status}",
            #     description=f"Status: {status}, Reason: {reason}",
            #     reasoning_type="termination",
            #     metadata={"status": status, "reason": reason}
            # )
            # graph.add_stage(finish_stage)
            # graph.connect(prev_stage_id, finish_id)
            
            # Add Summary node with answer
            summary_id = "summary"
            summary_stage = PostprocessingStage(
                id=summary_id,
                name="output",
                description=f"Answer: {answer} | Eval: {eval_result} | Rounds: {total_rounds}",
                operations=["result_aggregation", "summary_generation"],
                metadata={
                    "status": status,
                    "answer": answer,
                    "reason": reason,
                    "eval": eval_result,
                    "total_rounds": total_rounds,
                    "t_end": t_end
                }
            )
            graph.add_stage(summary_stage)
            graph.connect(prev_stage_id, summary_id)

    return graph

def load_single_graph(base_directory: str, task_name: str) -> AgenticGraph:
    """
    Load and parse a single HTML file by task name.
    
    Args:
        base_directory: Directory containing the HTML trace files
        task_name: Name of the task (e.g., 'task_0')
    
    Returns:
        AgenticGraph object or None if not found
    """
    # Construct the file path
    base_path = Path(base_directory)
    file_path = base_path / f"task_{task_name}.html"
    
    if not file_path.exists():
        print(f"✗ File not found: {file_path}")
        return None
    
    if not file_path.is_file():
        print(f"✗ Not a file: {file_path}")
        return None
    
    print(f"Loading: {file_path.name}")
    
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            html_content = f.read()
        
        graph = parse_webtactix_trace(html_content, file_path.name)
        
        # Convert graph to JSON
        json_filename = base_path / f"{task_name}_dump.json"
        json_data = AgenticGraphConverter.to_json(graph)
        with open(json_filename, 'w', encoding='utf-8') as json_file:
            json.dump(json_data, json_file, indent=2)
        print(f"✓ Created JSON: {json_filename}")
        
        # Convert JSON to CSV
        # csv_filename = base_path / f"{task_name}_dump.csv"
        # convert_json_to_csv(str(json_filename), str(csv_filename))
        
        print(f"✓ Successfully loaded {file_path.name}")
        return graph
    
    except Exception as e:
        print(f"✗ Error loading {file_path.name}: {str(e)}")
        return None


# # --- Usage ---
# if __name__ == "__main__":
    
#     # Default base directory for trace files
#     DEFAULT_DIR = "/home/ivohra6/benchmarks/webarena/deepseek/"
    
#     if len(sys.argv) > 1:
#         base_dir = sys.argv[1]
#     else:
#         base_dir = DEFAULT_DIR
    
#     # Verify directory exists
#     if not Path(base_dir).is_dir():
#         print(f"Error: Directory not found: {base_dir}")
#         sys.exit(1)
    
#     print(f"Base directory: {base_dir}")
#     print(f"Starting visualizer — type a task name (e.g. task_0) on the frontend to load.\n")
    
#     # Launch visualizer with the loader function
#     viz = AgenticGraphVisualizer(
#         base_directory=base_dir,
#         loader_fn=load_single_graph
#     )
#     viz.run()