"""
converter.py
Convert between JSON and AgenticGraph formats
"""

from typing import Dict, Any
from Builder.stage import (
    AgenticGraph, StageType, Stage,
    LLMCallStage, RAGStage, MemoryRetrievalStage, 
    ToolCallStage,
    PreprocessingStage, PostprocessingStage
)


class AgenticGraphConverter:
    """Convert between different formats and AgenticGraph"""
    
    @staticmethod
    def from_json(json_data: Dict[str, Any]) -> AgenticGraph:
        """Convert JSON to AgenticGraph"""
        graph = AgenticGraph(
            name=json_data.get('name', 'Untitled'),
            description=json_data.get('description', '')
        )
        
        # Create stage instances based on type
        for stage_data in json_data.get('stages', []):
            stage_type = StageType(stage_data['type'])
            stage_class = AgenticGraphConverter._get_stage_class(stage_type)
            
            # Extract common fields
            common_fields = {
                'id': stage_data['id'],
                'name': stage_data['name'],
                'description': stage_data.get('description', ''),
                'metadata': stage_data.get('metadata', {})
            }
            
            # Extract type-specific fields
            type_fields = {k: v for k, v in stage_data.items() 
                          if k not in ['id', 'name', 'type', 'description', 'metadata', 'inputs', 'outputs']}
            
            stage = stage_class(**common_fields, **type_fields)
            graph.add_stage(stage)
        
        # Add connections
        for edge in json_data.get('edges', []):
            graph.connect(edge['from'], edge['to'])
        
        return graph
    
    @staticmethod
    def to_json(graph: AgenticGraph) -> Dict[str, Any]:
        """Convert AgenticGraph to JSON"""
        stages = []
        for stage_id, stage in graph.stages.items():
            stage_dict = stage.get_display_info()
            stage_dict['input_len'] = stage.input_len
            stage_dict['output_len'] = stage.output_len
            stage_dict['latency'] = stage.latency
            stage_dict['type'] = stage.stage_type.value
            stage_dict['id'] = stage.id
            stages.append(stage_dict)
        
        return {
            'name': graph.name,
            'description': graph.description,
            'stages': stages,
            'edges': [{'from': e[0], 'to': e[1]} for e in graph.edges]
        }
    
    @staticmethod
    def _get_stage_class(stage_type: StageType):
        """Get the appropriate stage class for a stage type"""
        mapping = {
            StageType.LLM_CALL: LLMCallStage,
            StageType.RAG: RAGStage,
            StageType.MEMORY_RETRIEVAL: MemoryRetrievalStage,
            StageType.PLANNING: PlanningStage,
            StageType.AGENT_CALL: AgentCallStage,
            StageType.TOOL_CALL: ToolCallStage,
            StageType.REASONING: ReasoningStage,
            StageType.OUTPUT_VALIDATION: ValidationStage,
            StageType.PREPROCESSING: PreprocessingStage,
            StageType.POSTPROCESSING: PostprocessingStage,
            StageType.CONDITIONAL: ConditionalStage
        }
        return mapping.get(stage_type, Stage)
    
    @staticmethod
    def example_customer_support() -> Dict[str, Any]:
        """Returns an example customer support workflow JSON"""
        return {
            "name": "Customer Support Agent",
            "description": "Multi-stage customer support workflow with RAG and validation",
            "stages": [
                {
                    "id": "input_1",
                    "name": "User Input",
                    "type": "preprocessing",
                    "description": "Process user query",
                    "operations": ["normalize", "tokenize", "intent_extract"]
                },
                {
                    "id": "rag_1",
                    "name": "Knowledge Retrieval",
                    "type": "rag",
                    "description": "Retrieve relevant documentation",
                    "vector_store": "pinecone",
                    "top_k": 5,
                    "similarity_threshold": 0.8,
                    "embedding_model": "text-embedding-ada-002"
                },
                {
                    "id": "llm_1",
                    "name": "Response Generation",
                    "type": "llm_call",
                    "description": "Generate response using GPT-4",
                    "model": "gpt-4",
                    "temperature": 0.7,
                    "max_tokens": 500,
                    "system_prompt": "You are a helpful customer support assistant"
                },
                {
                    "id": "validation_1",
                    "name": "Output Validation",
                    "type": "output_validation",
                    "description": "Validate response quality",
                    "validation_rules": ["completeness", "accuracy", "tone"],
                    "strict_mode": True
                }
            ],
            "edges": [
                {"from": "input_1", "to": "rag_1"},
                {"from": "rag_1", "to": "llm_1"},
                {"from": "llm_1", "to": "validation_1"}
            ]
        }
    
    @staticmethod
    def example_research_agent() -> Dict[str, Any]:
        """Returns an example research agent workflow JSON"""
        return {
            "name": "Research Agent",
            "description": "Advanced research workflow with planning and multi-stage reasoning",
            "stages": [
                {
                    "id": "prep_1",
                    "name": "Input Processing",
                    "type": "preprocessing",
                    "description": "Clean and normalize research query",
                    "operations": ["normalize", "extract_keywords"]
                },
                {
                    "id": "plan_1",
                    "name": "Research Planning",
                    "type": "planning",
                    "description": "Decompose research query into sub-tasks",
                    "planning_method": "hierarchical",
                    "max_depth": 3
                },
                {
                    "id": "rag_1",
                    "name": "Document Retrieval",
                    "type": "rag",
                    "description": "Retrieve relevant research documents",
                    "vector_store": "weaviate",
                    "top_k": 10,
                    "similarity_threshold": 0.75,
                    "embedding_model": "text-embedding-ada-002"
                },
                {
                    "id": "reason_1",
                    "name": "Analysis",
                    "type": "reasoning",
                    "description": "Analyze retrieved information",
                    "reasoning_type": "chain_of_thought",
                    "steps": 5
                },
                {
                    "id": "llm_1",
                    "name": "Synthesis",
                    "type": "llm_call",
                    "description": "Synthesize findings into report",
                    "model": "gpt-4",
                    "temperature": 0.5,
                    "max_tokens": 2000,
                    "system_prompt": "You are a research assistant"
                },
                {
                    "id": "valid_1",
                    "name": "Quality Check",
                    "type": "output_validation",
                    "description": "Validate research quality",
                    "validation_rules": ["factuality", "completeness", "citations"],
                    "strict_mode": True
                },
                {
                    "id": "post_1",
                    "name": "Format Output",
                    "type": "postprocessing",
                    "description": "Format final research report",
                    "operations": ["format_markdown", "add_citations", "add_toc"]
                }
            ],
            "edges": [
                {"from": "prep_1", "to": "plan_1"},
                {"from": "plan_1", "to": "rag_1"},
                {"from": "rag_1", "to": "reason_1"},
                {"from": "reason_1", "to": "llm_1"},
                {"from": "llm_1", "to": "valid_1"},
                {"from": "valid_1", "to": "post_1"}
            ]
        }
    
    @staticmethod
    def example_multi_agent() -> Dict[str, Any]:
        """Returns an example multi-agent coordination workflow JSON"""
        return {
            "name": "Multi-Agent System",
            "description": "Coordinated multi-agent workflow with specialized agents and tool calls",
            "stages": [
                {
                    "id": "input_1",
                    "name": "Task Input",
                    "type": "preprocessing",
                    "description": "Process incoming task",
                    "operations": ["parse", "validate"]
                },
                {
                    "id": "plan_1",
                    "name": "Task Planner",
                    "type": "planning",
                    "description": "Break down task for multiple agents",
                    "planning_method": "parallel",
                    "max_depth": 2
                },
                {
                    "id": "agent_1",
                    "name": "Data Agent",
                    "type": "agent_call",
                    "description": "Specialized data analysis agent",
                    "agent_type": "data_analyst",
                    "capabilities": ["data_processing", "visualization", "statistics"]
                },
                {
                    "id": "tool_1",
                    "name": "Database Query",
                    "type": "tool_call",
                    "description": "Query company database",
                    "tool_name": "sql_executor",
                    "timeout": 30
                },
                {
                    "id": "agent_2",
                    "name": "Reporting Agent",
                    "type": "agent_call",
                    "description": "Report generation specialist",
                    "agent_type": "reporter",
                    "capabilities": ["writing", "formatting", "visualization"]
                },
                {
                    "id": "llm_1",
                    "name": "Final Synthesis",
                    "type": "llm_call",
                    "description": "Combine all agent outputs",
                    "model": "gpt-4",
                    "temperature": 0.6,
                    "max_tokens": 1500
                }
            ],
            "edges": [
                {"from": "input_1", "to": "plan_1"},
                {"from": "plan_1", "to": "agent_1"},
                {"from": "plan_1", "to": "tool_1"},
                {"from": "agent_1", "to": "agent_2"},
                {"from": "tool_1", "to": "agent_2"},
                {"from": "agent_2", "to": "llm_1"}
            ]
        }