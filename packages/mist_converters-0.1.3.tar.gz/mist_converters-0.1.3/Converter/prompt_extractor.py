"""
prompt_extractor.py
Extracts system and user prompts from agent source files
"""

import re
import sys
from pathlib import Path
from typing import Dict, Tuple, Optional

# Add the webtactix path to sys.path for imports
sys.path.insert(0, '/home/ivohra6/benchmarks/webtactix')
from webtactix.agents.planner_agent import TIPS


class PromptExtractor:
    """Extract prompts from agent source files by parsing the actual code"""
    
    def __init__(self, agents_dir: str = "/home/ivohra6/benchmarks/webtactix/webtactix/agents"):
        self.agents_dir = Path(agents_dir)
        self.prompts = {}
        self._load_prompts()
    
    def _extract_parenthesized_string(self, content: str, var_name: str, start_pos: int = 0) -> Optional[str]:
        """Extract a multi-line string literal in parentheses: var_name = ( "string" "continuation" ) or return (...)"""
        # Try variable assignment first: var_name = (
        pattern = rf'{var_name}\s*=\s*\('
        match = re.search(pattern, content[start_pos:], re.DOTALL)
        
        if not match:
            # Try return statement: return (
            pattern = rf'{var_name}\s*\('
            match = re.search(pattern, content[start_pos:], re.DOTALL)
        
        if not match:
            return None
        
        # Find the position of opening parenthesis
        start = start_pos + match.end() - 1
        paren_count = 1
        end = start + 1
        in_string = False
        escape_next = False
        
        # Find matching closing parenthesis, accounting for strings
        while end < len(content) and paren_count > 0:
            char = content[end]
            
            if escape_next:
                escape_next = False
            elif char == '\\':
                escape_next = True
            elif char == '"' and not in_string:
                in_string = True
            elif char == '"' and in_string:
                in_string = False
            elif not in_string:
                if char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
            end += 1
        
        if paren_count == 0:
            inner_content = content[start+1:end-1]
            # Extract all strings (regular and f-strings) and concatenate
            # Match both regular strings and f-strings
            string_parts = []
            for match in re.finditer(r'[f]?"([^"\\]*(?:\\.[^"\\]*)*)"', inner_content):
                string_parts.append(match.group(1))
            result = ''.join(string_parts)
            return result
        return None
    
    def _extract_join_string(self, content: str, var_name: str, start_pos: int = 0) -> Optional[str]:
        """Extract strings from pattern: var_name = "".join([...]) or "\\n".join([...])"""
        # Pattern to match: var_name = "separator".join([...])
        pattern = rf'{var_name}\s*=\s*"([^"]*)"\s*\.join\s*\(\s*\['
        match = re.search(pattern, content[start_pos:], re.DOTALL)
        
        if not match:
            return None
        
        separator = match.group(1)
        # Find the opening bracket position
        bracket_start = start_pos + match.end() - 1
        bracket_count = 1
        bracket_end = bracket_start + 1
        
        # Find matching closing bracket
        while bracket_end < len(content) and bracket_count > 0:
            if content[bracket_end] == '[':
                bracket_count += 1
            elif content[bracket_end] == ']':
                bracket_count -= 1
            bracket_end += 1
        
        if bracket_count == 0:
            list_content = content[bracket_start+1:bracket_end-1]
            # Extract all quoted strings from the list
            string_parts = re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"', list_content)
            result = separator.join(string_parts)
            return result
        return None
    
    def _extract_method_body(self, content: str, method_signature: str) -> Optional[str]:
        """Extract the body of a method"""
        pattern = rf'{method_signature}.*?(?=\n    def |\n    async def |\nclass |\Z)'
        match = re.search(pattern, content, re.DOTALL)
        return match.group(0) if match else None
    
    def _load_constraint_agent(self):
        """Load prompts from constraint_agent.py"""
        file_path = self.agents_dir / "constraint_agent.py"
        if not file_path.exists():
            return
        
        content = file_path.read_text()
        
        # Extract from run method
        run_method = self._extract_method_body(content, r'async def run\(self\)')
        if run_method:
            system = self._extract_parenthesized_string(run_method, 'system')
            user = self._extract_parenthesized_string(run_method, 'user')
            
            self.prompts['constraint_agent'] = {
                'system': system,
                'user': user
            }
    
    def _load_planner_agent(self):
        """Load prompts from planner_agent.py"""
        file_path = self.agents_dir / "planner_agent.py"
        if not file_path.exists():
            return
        
        content = file_path.read_text()
        
        # Extract from the run method
        run_method = self._extract_method_body(content, r'async def run\(self, node_id: NodeId, _round: int\)')
        if run_method:
            system = self._extract_parenthesized_string(run_method, 'system')
            # User prompt might use "".join([...]) pattern
            user = self._extract_join_string(run_method, 'user')
            if not user:
                user = self._extract_parenthesized_string(run_method, 'user')
            
            self.prompts['planner_agent'] = {
                'system': system,
                'user': user
            }
    
    def _load_decision_agent(self):
        """Load prompts from decision_agent.py"""
        file_path = self.agents_dir / "decision_agent.py"
        if not file_path.exists():
            return
        
        content = file_path.read_text()
        
        # Extract reflect_or_reselect prompts
        reflect_method = self._extract_method_body(content, r'async def reflect_or_reselect')
        reflect_system = None
        reflect_user = None
        if reflect_method:
            reflect_system = self._extract_parenthesized_string(reflect_method, 'system')
            # User prompt uses "".join([...]) pattern
            reflect_user = self._extract_join_string(reflect_method, 'user')
            if not reflect_user:
                reflect_user = self._extract_parenthesized_string(reflect_method, 'user')
        
        # Extract select_and_execute prompts
        select_method = self._extract_method_body(content, r'async def select_and_execute')
        select_system = None
        select_user = None
        if select_method:
            select_system = self._extract_parenthesized_string(select_method, 'system')
            # User prompt uses "".join([...]) pattern
            select_user = self._extract_join_string(select_method, 'user')
            if not select_user:
                select_user = self._extract_parenthesized_string(select_method, 'user')
        
        self.prompts['decision_agent'] = {
            'reflect_and_replan': {
                'system': reflect_system,
                'user': reflect_user
            },
            'select_and_execute': {
                'system': select_system,
                'user': select_user
            }
        }
    
    def _load_data_agent(self):
        """Load prompts from data_agent.py"""
        file_path = self.agents_dir / "data_agent.py"
        if not file_path.exists():
            return
        
        content = file_path.read_text()
        
        # Extract _system_prompt static method
        system_method = self._extract_method_body(content, r'def _system_prompt\(\)')
        system = None
        if system_method:
            system = self._extract_parenthesized_string(system_method, 'return')
        
        # Extract _user_prompt method
        user_method = self._extract_method_body(content, r'def _user_prompt\(self,')
        user = None
        if user_method:
            user = self._extract_parenthesized_string(user_method, 'return')
        
        self.prompts['data_agent'] = {
            'system': system,
            'user': user
        }
    
    def _load_prompts(self):
        """Load all agent prompts"""
        self._load_constraint_agent()
        self._load_planner_agent()
        self._load_decision_agent()
        self._load_data_agent()
    
    def get_constraint_prompts(self, task_desc: str) -> Tuple[str, str]:
        """Get constraint agent prompts"""
        p = self.prompts.get('constraint_agent', {})
        system = p.get('system', '')
        user = p.get('user', '')
        # User prompt has f-string with task.intent, replace with actual task
        if user and '{self.task.intent}' in user:
            user = user.replace('{self.task.intent}', task_desc)
        return system, user
    
    def get_planner_prompts(self, goal: str = "") -> Tuple[str, str]:
        """Get planner agent prompts"""
        p = self.prompts.get('planner_agent', {})
        system = p.get('system', '')
        user = p.get('user', '')
        
        # Replace {TIPS} with actual TIPS value
        if user and '{TIPS}' in user:
            user = user.replace('{TIPS}', TIPS)
        
        # Replace {self.q} with placeholder for later substitution
        if user and '{self.q}' in user:
            user = user.replace('{self.q}', goal)
        
        return system, user
    
    def get_decision_prompts(self, decision_type: str = "select_and_execute") -> Tuple[str, str]:
        """Get decision agent prompts"""
        decision_prompts = self.prompts.get('decision_agent', {})
        
        # Get prompts based on decision type
        if decision_type == "reflect_and_replan":
            p = decision_prompts.get('reflect_and_replan', {})
        else:
            p = decision_prompts.get('select_and_execute', {})
        
        system = p.get('system', '')
        user = p.get('user', '')
        return system, user
    
    def get_data_extraction_prompts(self, goal: str = "") -> Tuple[str, str]:
        """Get data extraction agent prompts"""
        p = self.prompts.get('data_agent', {})
        system = p.get('system', '')
        user = p.get('user', '')
        return system, user
