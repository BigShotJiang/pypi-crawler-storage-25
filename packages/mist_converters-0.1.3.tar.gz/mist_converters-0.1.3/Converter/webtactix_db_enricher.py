"""
webtactix_db_enricher.py  —  Attach profiling DB data to an AgenticGraph.

Two classes:

  AgentDBEnricher (abstract base)
  ─────────────────────────────
  Generic machinery for mapping graph stage IDs → SQLite profiling events and
  writing measured_* fields back onto each stage.
  Subclasses override only `stage_id_to_step_pattern()` to handle agent-specific
  naming conventions.

  WebtactixDBEnricher(AgentDBEnricher)
  ────────────────────────────────────
  Concrete implementation for the Webtactix / WebTactix agent.
  Maps stage IDs produced by webtactic_injestor.py to the step_name patterns
  stored in the profiling DB by the Webtactix agent's IPC emitter.

Usage
─────
    from Converter.webtactic_injestor import load_single_graph
    from Converter.webtactix_db_enricher import WebtactixDBEnricher

    graph   = load_single_graph("./traces", "task_0")
    enricher = WebtactixDBEnricher(db_path="task_0_profile.db")
    enriched = enricher.enrich(graph)

    enricher.to_enriched_json(enriched, "task_0_enriched.json")
    enricher.to_enriched_csv(enriched,  "task_0_enriched.csv")

Enriched fields added to each stage (via stage.metadata):
─────────────────────────────────────────────────────────
  measured_latency_ms     float   — wall-clock latency from DB
  measured_input_tokens   int     — input tokens from llm_call_events
  measured_output_tokens  int     — output tokens from llm_call_events
  measured_cpu_p50        float   — p50 CPU% during stage window
  measured_cpu_p99        float   — p99 CPU% during stage window
  measured_mem_max_mb     float   — peak RSS MB during stage window
  measured_net_tx_bytes   int     — TX bytes during stage window
  measured_net_rx_bytes   int     — RX bytes during stage window

When an LLM match is found, stage.latency and stage.input_len / output_len
are also updated to reflect actual measured values (superseding static estimates).
"""

from __future__ import annotations

import csv
import json
import os
import re
import sqlite3
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

# ─────────────────────────────────────────────────────────────────────────────
# Stats helper (mirrors analysis.py's _stats without the extra import)
# ─────────────────────────────────────────────────────────────────────────────

def _stats_simple(values: List[float]) -> Dict[str, Optional[float]]:
    """Return basic percentile stats for a list of numeric values."""
    arr = [v for v in values if v is not None]
    if not arr:
        return {"mean": None, "p50": None, "p90": None, "p99": None,
                "min": None, "max": None, "count": 0}
    a = np.array(arr, dtype=float)
    a = a[~np.isnan(a)]
    if len(a) == 0:
        return {"mean": None, "p50": None, "p90": None, "p99": None,
                "min": None, "max": None, "count": 0}
    return {
        "mean": float(np.mean(a)),
        "p50":  float(np.percentile(a, 50)),
        "p90":  float(np.percentile(a, 90)),
        "p99":  float(np.percentile(a, 99)),
        "min":  float(np.min(a)),
        "max":  float(np.max(a)),
        "count": int(len(a)),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Abstract base
# ─────────────────────────────────────────────────────────────────────────────

class AgentDBEnricher(ABC):
    """
    Opens a profiling SQLite DB (read-only) and enriches every stage in an
    AgenticGraph with measured performance data from matching DB events.

    Subclasses must implement `stage_id_to_step_pattern()`.
    """

    def __init__(self, db_path: str, run_id: Optional[str] = None):
        self.db_path = db_path
        self.run_id  = run_id

        db_uri = f"file:{db_path}?immutable=1"
        self._conn = sqlite3.connect(db_uri, uri=True)
        self._conn.row_factory = sqlite3.Row
        self._run_filter: Tuple = (run_id,) if run_id else ()

    def close(self):
        self._conn.close()

    # ── public API ────────────────────────────────────────────────────────── #

    @abstractmethod
    def stage_id_to_step_pattern(self, stage_id: str) -> Optional[str]:
        """
        Map a graph stage_id to a DB step_name LIKE pattern.
        Return None to skip enrichment for this stage.
        Return "__exec__" as a sentinel to use exec_events lookup instead.
        """

    def enrich(self, graph) -> "any":
        """
        Attach measured_* fields to every stage in graph.
        Returns the same graph object (mutated in-place) for chaining.
        """
        for stage_id, stage in graph.stages.items():
            pattern = self.stage_id_to_step_pattern(stage_id)
            if pattern is None:
                continue

            if pattern == "__exec__":
                metrics = self._exec_metrics_for_stage(stage_id, graph)
            else:
                metrics = self._llm_metrics_for_pattern(pattern)

            if not metrics:
                continue

            stage.metadata.update(metrics)

            # Also write back to the canonical Stage fields if the data is there
            if metrics.get("measured_latency_ms") is not None:
                stage.latency = metrics["measured_latency_ms"] / 1000.0
            if metrics.get("measured_input_tokens") is not None:
                stage.input_len = int(metrics["measured_input_tokens"])
            if metrics.get("measured_output_tokens") is not None:
                stage.output_len = int(metrics["measured_output_tokens"])
            if metrics.get("measured_system_tokens") is not None and hasattr(stage, "system_prompt_len"):
                stage.system_prompt_len = int(metrics["measured_system_tokens"])
            if metrics.get("measured_user_tokens") is not None and hasattr(stage, "user_prompt_len"):
                stage.user_prompt_len = int(metrics["measured_user_tokens"])

        return graph

    def to_enriched_json(self, graph, output_path: Optional[str] = None) -> Dict:
        """
        Convert the graph to a dict including measured_* metadata.
        If output_path is given, also writes to that file.
        """
        edge_list = [
            {"from": src, "to": dst}
            for src, dst in graph.edges
        ]
        data = {
            "name": graph.name,
            "description": graph.description,
            "edges": edge_list,
            "stages": [],
        }
        for sid, stage in graph.stages.items():
            info = stage.get_display_info()
            # Merge measured_* from metadata into top-level for easy reading
            for k, v in stage.metadata.items():
                if k.startswith("measured_"):
                    info[k] = v
            data["stages"].append(info)

        if output_path:
            out_dir = os.path.dirname(output_path)
            if out_dir:
                os.makedirs(out_dir, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, default=str)

        return data

    def to_enriched_csv(self, graph, output_path: str) -> str:
        """
        Write a CSV where each row is one stage with both static and measured
        fields.  Compatible with MIST downstream consumers.
        """
        MEASURED_COLS = [
            "measured_latency_ms",
            "measured_input_tokens",
            "measured_output_tokens",
            "measured_system_tokens",
            "measured_user_tokens",
            "measured_cpu_p50",
            "measured_cpu_p99",
            "measured_mem_max_mb",
            "measured_net_tx_bytes",
            "measured_net_rx_bytes",
        ]

        fieldnames = [
            "stage_id", "stage_name", "stage_type",
            "description", "input_len", "output_len", "latency",
        ] + MEASURED_COLS

        rows = []
        for sid, stage in graph.stages.items():
            info = stage.get_display_info()
            row = {
                "stage_id":   sid,
                "stage_name": info.get("name", ""),
                "stage_type": info.get("type", ""),
                "description": info.get("description", ""),
                "input_len":  info.get("input_len", 0),
                "output_len": info.get("output_len", 0),
                "latency":    info.get("latency", ""),
            }
            for col in MEASURED_COLS:
                row[col] = stage.metadata.get(col, "")
            rows.append(row)

        out_dir = os.path.dirname(output_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
            
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        return output_path

    # ── internal helpers ──────────────────────────────────────────────────── #

    def _run_where(self, extra: str = "") -> Tuple[str, tuple]:
        """Return (WHERE clause, params) scoped to self.run_id if set."""
        if self.run_id:
            base = "WHERE run_id = ?"
            params: tuple = (self.run_id,)
        else:
            base = "WHERE 1=1"
            params = ()
        if extra:
            base += f" AND ({extra})"
        return base, params

    def _llm_metrics_for_pattern(self, pattern: str) -> Optional[Dict]:
        """
        Find llm_call_events whose step_name matches the LIKE pattern.
        Returns measured_* dict, or None if no rows found.
        """
        where, params = self._run_where("step_name LIKE ?")
        params = params + (pattern,)
        try:
            rows = self._conn.execute(
                f"SELECT latency_ms, input_tokens, output_tokens, "
                f"       system_tokens, user_tokens, "
                f"       sent_at, received_at "
                f"FROM   llm_call_events {where} ORDER BY sent_at",
                params,
            ).fetchall()
        except Exception:
            return None

        if not rows:
            return None

        lat_vals  = [r["latency_ms"]    for r in rows if r["latency_ms"]    is not None]
        in_vals   = [r["input_tokens"]  for r in rows if r["input_tokens"]  is not None]
        out_vals  = [r["output_tokens"] for r in rows if r["output_tokens"] is not None]
        sys_vals  = [r["system_tokens"] for r in rows if r["system_tokens"] is not None]
        user_vals = [r["user_tokens"]   for r in rows if r["user_tokens"]   is not None]

        # Use the first match's timing for window-based CPU/net lookup
        first = rows[0]
        t_start = first["sent_at"]
        t_end   = rows[-1]["received_at"] or rows[-1]["sent_at"]

        result: Dict[str, Any] = {}

        if lat_vals:
            result["measured_latency_ms"]     = float(np.mean(lat_vals))
        if in_vals:
            result["measured_input_tokens"]   = int(np.mean(in_vals))
        if out_vals:
            result["measured_output_tokens"]  = int(np.mean(out_vals))
        if sys_vals:
            result["measured_system_tokens"]  = int(np.mean(sys_vals))
        if user_vals:
            result["measured_user_tokens"]    = int(np.mean(user_vals))

        # CPU / memory for the LLM window
        cpu_mem = self._window_cpu_mem(t_start, t_end)
        result.update(cpu_mem)

        # Network for the LLM window
        net = self._window_network(t_start, t_end)
        result.update(net)

        return result or None

    def _exec_metrics_for_stage(self, stage_id: str, graph) -> Optional[Dict]:
        """
        Look up exec_events and get timing/CPU/net data.
        Falls back to a broad exec_type = 'web_op' query if stage-specific
        lookup yields nothing.
        """
        # Try to look up by exec_id matching stage_id pattern first
        where, params = self._run_where("(exec_id LIKE ? OR step_name LIKE ?)")
        pattern = f"%{stage_id}%"
        params = params + (pattern, pattern)

        try:
            rows = self._conn.execute(
                f"SELECT started_at, ended_at, duration_ms "
                f"FROM   exec_events {where} ORDER BY started_at",
                params,
            ).fetchall()
        except Exception:
            rows = []

        if not rows:
            return None

        dur_vals = [r["duration_ms"] for r in rows if r["duration_ms"] is not None]
        t_start  = rows[0]["started_at"]
        t_end    = rows[-1]["ended_at"] or rows[-1]["started_at"]

        result: Dict[str, Any] = {}
        if dur_vals:
            result["measured_latency_ms"] = float(np.mean(dur_vals))

        cpu_mem = self._window_cpu_mem(t_start, t_end)
        result.update(cpu_mem)
        net = self._window_network(t_start, t_end)
        result.update(net)

        return result or None

    def _window_cpu_mem(self, t_start: float, t_end: float) -> Dict:
        """Return CPU p50/p99 and RSS max for a time window."""
        if t_start is None or t_end is None:
            return {}
        where, params = self._run_where("ts BETWEEN ? AND ?")
        params = params + (t_start, t_end)
        try:
            ticks = self._conn.execute(
                f"SELECT cpu_pct, rss_mb FROM cpu_mem_ticks {where}",
                params,
            ).fetchall()
        except Exception:
            return {}

        cpu_vals = [t["cpu_pct"] for t in ticks if t["cpu_pct"] is not None]
        rss_vals = [t["rss_mb"]  for t in ticks if t["rss_mb"]  is not None]

        result = {}
        if cpu_vals:
            result["measured_cpu_p50"] = float(np.percentile(cpu_vals, 50))
            result["measured_cpu_p99"] = float(np.percentile(cpu_vals, 99))
        if rss_vals:
            result["measured_mem_max_mb"] = float(np.max(rss_vals))

        return result

    def _window_network(self, t_start: float, t_end: float) -> Dict:
        """Return TX/RX byte totals for a time window."""
        if t_start is None or t_end is None:
            return {}
        where, params = self._run_where("ts BETWEEN ? AND ?")
        params = params + (t_start, t_end)
        try:
            pkts = self._conn.execute(
                f"SELECT direction, size_bytes "
                f"FROM   network_packets {where}",
                params,
            ).fetchall()
        except Exception:
            return {}

        tx = sum(p["size_bytes"] for p in pkts
                 if p["direction"] == "tx" and p["size_bytes"] is not None)
        rx = sum(p["size_bytes"] for p in pkts
                 if p["direction"] == "rx" and p["size_bytes"] is not None)

        return {
            "measured_net_tx_bytes": tx,
            "measured_net_rx_bytes": rx,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Webtactix concrete implementation
# ─────────────────────────────────────────────────────────────────────────────

class WebtactixDBEnricher(AgentDBEnricher):
    """
    Maps Webtactix graph stage IDs (from webtactic_injestor.py) to DB
    step_name LIKE patterns used by the Webtactix agent's IPC emitter.

    Stage ID → DB step_name pattern mapping:
    ─────────────────────────────────────────
    task_input               → None  (skip)
    constraint_agent         → "constraint%"
    r000_preprocessing       → None  (no meaningful LLM/exec data for round 0)
    r{N}_prep                → None  (preprocessing — no LLM call)
    r{N}_plan_{v_id}         → "planner|round={n}|node={v_id}%"
    r{N}_postprocess         → None  (no LLM call)
    r{N}_decision_prep       → None  (no LLM call)
    r{N}_decision_llm        → "decision%|round={n}%"  or  "decision%"
    r{N}_decision_post       → None  (no LLM call)
    r{N}_execute             → "__exec__"  (uses exec_events)
    r{N}_data_extraction     → "data%|round={n}%"  or  "data%"
    summary                  → None  (skip)

    N in the stage ID is zero-padded 3 digits (e.g. r001 → round 1).
    """

    def stage_id_to_step_pattern(self, stage_id: str) -> Optional[str]:
        """Translate a graph stage ID to a DB step_name SQL LIKE pattern."""

        # ── skip non-LLM / non-exec stages ──────────────────────────────────
        SKIP_EXACT = {
            "task_input", "summary",
        }
        if stage_id in SKIP_EXACT:
            return None

        SKIP_SUFFIXES = ("_prep", "_postprocess", "_decision_prep", "_decision_post")
        for sfx in SKIP_SUFFIXES:
            if stage_id.endswith(sfx):
                return None

        # ── round 000 preprocessing ──────────────────────────────────────────
        if stage_id == "r000_preprocessing":
            return None

        # ── constraint agent ─────────────────────────────────────────────────
        if stage_id == "constraint_agent":
            return "constraint%"

        # ── round-prefixed stages ─────────────────────────────────────────────
        # stage_id format: r{NNN}_<type>[_<extra>]
        m = re.fullmatch(r"r(\d+)_(.*)", stage_id)
        if not m:
            return None

        round_num = int(m.group(1))          # e.g. 1
        rest      = m.group(2)               # e.g. "plan_v2", "decision_llm", "execute"

        # ── planner call  r{N}_plan_{v_id} ──────────────────────────────────
        pm = re.fullmatch(r"plan_(v\d+)", rest)
        if pm:
            v_id = pm.group(1)               # e.g. "v2"
            # step_name in DB: "planner|round=1|node=v2" or "planner|round=01|node=v2"
            # Use a LIKE pattern tolerant of both zero-padded and unpadded rounds
            return f"planner%round={round_num}%node={v_id}%"

        # ── decision LLM call  r{N}_decision_llm ────────────────────────────
        if rest == "decision_llm":
            # step_name in DB: "decision:select_and_execute|round=1|..."
            # or "decision|round=1|..." — match any decision call for this round
            return f"decision%round={round_num}%"

        # ── execute / web_op  r{N}_execute ──────────────────────────────────
        if rest == "execute":
            return "__exec__"

        # ── data extraction  r{N}_data_extraction ───────────────────────────
        if rest == "data_extraction":
            return f"data%round={round_num}%"

        # Anything else (e.g. future stage types) — skip
        return None
