#!/usr/bin/env python3
"""
parse_agentic_graph.py

Parses a Claude Code project directory (containing primary .jsonl session files
and optional subagents/ folders) into an AgenticGraph JSON, then generates a
self-contained HTML visualizer.

Usage:
    python parse_agentic_graph.py <directory> [--output graph.html]
"""

import json
import sys
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional
import re
from datetime import datetime
from Builder.stage import StageType, AgenticGraph, LLMCallStage, ToolCallStage, PreprocessingStage, PostprocessingStage, OutputStage
from token_utils import count_tokens

def token_count(content) -> int:
    """Return token count for any content type (str, list, dict, None) using tiktoken."""
    import json as _json
    if not content:
        return 0
    text = content if isinstance(content, str) else _json.dumps(content, ensure_ascii=False)
    return count_tokens(text)


def _extract_string_content(value) -> str:
    """
    Recursively extract the meaningful string from a content value.
    - str          → returned as-is
    - list         → first item that yields a non-empty string
    - dict/text    → value of 'text' or 'thinking' field
    - dict/tool_use → json.dumps({"name": ..., "input": ...})
    - dict/other   → recurse into nested dicts/lists via 'content' key first
    Returns "" if no string content is found.
    """
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        for item in value:
            result = _extract_string_content(item)
            if result:
                return result
        return ""
    if isinstance(value, dict):
        if "content" in value:
            result = _extract_string_content(value["content"])
            if result:
                return result
        for field in ("text", "thinking"):
            if field in value and isinstance(value[field], str):
                return value[field]
        if value.get("type") == "tool_use" and "input" in value:
            return json.dumps({"name": value.get("name"), "input": value["input"]})
        for v in value.values():
            if isinstance(v, (dict, list)):
                result = _extract_string_content(v)
                if result:
                    return result
        return ""
    return ""


def output_length(content) -> int:
    """Return character length of the meaningful extracted string content."""
    return len(_extract_string_content(content))


# ─── JSONL Parsing ────────────────────────────────────────────────────────────

# Tools whose tool_result is treated as an LLM-generated artifact (not real CPU↔GPU I/O)
WRITE_TOOLS = {
    "write", "edit", "todowrite", "task", "exitplanmode", "askuserquestion",
}


def parse_timestamp(ts: Any) -> Optional[float]:
    if ts is None:
        return None
    if isinstance(ts, (int, float)):
        # epoch ms or epoch s
        if ts > 1e10:
            return ts / 1000.0
        return float(ts)
    if isinstance(ts, str):
        # ISO 8601
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            return dt.timestamp()
        except Exception:
            pass
    return None



def read_jsonl(path: Path) -> List[dict]:
    lines = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        lines.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    except Exception as e:
        print(f"  Warning: could not read {path}: {e}", file=sys.stderr)
    return lines



# ─── Shared stage-factory helpers ────────────────────────────────────────────
_AGENT_TOOLS = {"agent"}


def _make_assistant_stage(
    sid: str,
    label: str,
    rec_uuid: str,
    ts: Optional[float],
    content: list,
    block_type: str,
    model_name: str,
    input_tokens: int,
    kv_cache_len: int,
    extra_meta: dict = None,
):
    """
    Build the correct stage for an assistant record.

      tool_use  → LLMCallStage  (latency = tool_use.ts - parent thinking/text.ts)
      thinking  → LLMCallStage  (output_len = tokens in thinking field)
      text      → LLMCallStage  (output_len = tokens in text field)
      other     → PreprocessingStage / UNDEFINED
    """
    base_meta = {"uuid": rec_uuid, "model": model_name, "input_tokens": input_tokens,
                 "kv_cache_length": kv_cache_len, "timestamp": ts, "session": label}
    if extra_meta:
        base_meta.update(extra_meta)

    if block_type == "tool_use":
        tool_names = [b.get("name", "unknown") for b in content
                      if isinstance(b, dict) and b.get("type") == "tool_use"]
        extracted = _extract_string_content(content)
        meta = {**base_meta, "block_type": "tool_use", "tool_names": tool_names,
                "output_tokens": token_count(extracted)}
        name = f"[{label}] Agent Call" if any(n.lower() in _AGENT_TOOLS for n in tool_names) else f"[{label}] Tool Use"
        return LLMCallStage(id=sid, name=name,
                            description=", ".join(tool_names),
                            past_KV_context=kv_cache_len, metadata=meta,
                            input_len=input_tokens, output_len=len(extracted))

    if block_type == "thinking":
        thinking_text = next((b.get("thinking", "") for b in content if isinstance(b, dict)), "")
        extracted = _extract_string_content(content)
        meta = {**base_meta, "block_type": "thinking", "thinking": True,
                "output_tokens": token_count(extracted)}
        return LLMCallStage(id=sid, name=f"[{label}] Thinking",
                            description=thinking_text,
                            past_KV_context=kv_cache_len, metadata=meta,
                            input_len=input_tokens, output_len=len(extracted))

    if block_type == "text":
        text = next((b.get("text", "") for b in content if isinstance(b, dict)), "")
        extracted = _extract_string_content(content)
        meta = {**base_meta, "block_type": "text", "output_tokens": token_count(extracted)}
        return LLMCallStage(id=sid, name=f"[{label}] Assistant Output",
                            description=text,
                            past_KV_context=kv_cache_len, metadata=meta,
                            input_len=input_tokens, output_len=len(extracted))

    # Unknown block type
    meta = {**base_meta, "block_type": block_type, "undefined": True}
    stage = PreprocessingStage(id=sid, name=f"[{label}] Undefined",
                               description=f"undefined block type: {block_type!r}",
                               metadata=meta)
    stage.stage_type = StageType.UNDEFINED
    return stage


def _make_tool_result_stage(
    sid: str,
    label: str,
    rec_uuid: str,
    ts: Optional[float],
    result_block: dict,
    model_name: str,
    write_edit_ids: set,
    extra_meta: dict = None,
    agent_tool_ids: set = None,
):
    """
    Build the correct stage for a user tool_result block.

      Write/Edit/TodoWrite parent → LLMCallStage
        input_len  = token_count(full result content)
        output_len = len(str(result content))
        model      = inherited from parent tool_use stage

      All other tools → ToolCallStage
        input_len  = token_count(full result content)
        output_len = len(str(result content))
    """
    result_content = result_block.get("content", "")
    tool_use_id    = result_block.get("tool_use_id", "")
    extracted      = _extract_string_content(result_content)
    base_meta = {"uuid": rec_uuid, "tool_use_id": tool_use_id,
                 "timestamp": ts, "block_type": "tool_result",
                 "output_tokens": token_count(extracted)}
    if extra_meta:
        base_meta.update(extra_meta)

    if tool_use_id in write_edit_ids:
        meta = {**base_meta, "model": model_name}
        return LLMCallStage(id=sid, name=f"[{label}] Tool Result",
                            description=extracted, metadata=meta,
                            input_len=token_count(result_content),
                            output_len=len(extracted))

    if agent_tool_ids and tool_use_id in agent_tool_ids:
        return ToolCallStage(id=sid, name=f"[{label}] Agent Result",
                             stage_type=StageType.TOOL_CALL,
                             description=extracted, metadata=base_meta,
                             input_len=token_count(result_content),
                             output_len=len(extracted))

    return ToolCallStage(id=sid, name=f"[{label}] Tool Result",
                         stage_type=StageType.TOOL_CALL,
                         description=extracted, metadata=base_meta,
                         input_len=token_count(result_content),
                         output_len=len(extracted))


def _make_user_input_stage(
    sid: str,
    label: str,
    rec_uuid: str,
    ts: Optional[float],
    content: list,
    block_type: str,
):
    """Build a PreprocessingStage for non-tool_result user content."""
    text = next(
        (b.get("text", "") or b.get("source", {}).get("url", "") or b.get("type", "")
         for b in content if isinstance(b, dict)),
        "",
    )
    meta = {"uuid": rec_uuid, "timestamp": ts,
            "block_type": "user_input", "content_block_type": block_type}
    return PreprocessingStage(id=sid, name=f"[{label}] User Context",
                              description=str(text), metadata=meta,
                              input_len=token_count(content), output_len=0)


# ─── Session → Stages ─────────────────────────────────────────────────────────

def parse_session(
    session_file: Path,
    session_label: str,
    graph: AgenticGraph,
    id_prefix: str,
    visited_files: Optional[set] = None,
):
    """
    Parse a single JSONL session file and add stages to graph.

    Each JSONL record becomes one node. Node type is derived from the
    content block type (each record has exactly one block type):

      assistant / tool_use    → OUTPUT    (structured tool dispatch, output of the LLM run)
      assistant / thinking    → LLM_CALL  (model reasoning)
      assistant / text        → OUTPUT    (model response)
      user      / tool_result → TOOL_CALL (external execution result)
      user      / text|document|* → INPUT  (human message or document input)
      queue-operation            → INPUT  (session lifecycle / init input)
      system                  → PREPROCESSING
      result                  → OUTPUT
      progress / hook_progress   → PREPROCESSING (hook lifecycle event)
      progress / agent_progress  → mirrors the embedded subagent message type;
                                   stages are chained per-agent and connected from
                                   the parent Agent tool_use stage
      anything else           → UNDEFINED

    Edges reflect semantic causation, not the linear parentUuid chain:
      - tool_use  ← last LLM stage (all parallel tool calls share the same LLM parent)
      - tool_result ← its matching tool_use (by tool_use_id field)
      - thinking/text ← all pending tool_results (fan-in), or last stage if none
      - agent_progress first stage ← parent Agent tool_use
      - agent_progress subsequent stages ← previous stage in same agent thread

    visited_files: shared set of resolved Paths already fully processed; this file
    is added to it on entry so callers can skip it in orphan scanning.
    """
    records = read_jsonl(session_file)
    if not records:
        return []

    # Mark this file as fully processed so the orphan scanner won't re-parse it.
    if visited_files is not None:
        visited_files.add(session_file.resolve())

    # Subagent JSONL files live beside the session JSONL in a <stem>/subagents/ dir
    _subagents_dir: Path = session_file.parent / session_file.stem / "subagents"

    stage_ids: List[str] = []
    counter = [0]

    def new_id(suffix: str = "") -> str:
        counter[0] += 1
        return f"{id_prefix}_{counter[0]:04d}{('_' + suffix) if suffix else ''}"

    last_sid: Optional[str] = None          # last stage of any type
    last_llm_sid: Optional[str] = None      # last thinking or text output (the "LLM decision" anchor)
    pending_tool_uses: Dict[str, str] = {}  # tool_use_id → stage_id, awaiting their tool_result
    write_edit_tool_ids: set = set()        # tool_use_ids for Write/Edit/TodoWrite tools → result treated as LLM call
    agent_tool_ids: set = set()             # tool_use_ids for Agent tool calls → inlined from subagent dir
    recent_tool_results: List[str] = []     # tool_result sids not yet consumed by a subsequent LLM stage
    buffered_inputs: List[dict] = []        # initial user records before first real stage
    pending_enqueue: Optional[dict] = None  # buffered enqueue record, waiting for matching dequeue

    def _flush_buffered_inputs():
        """Merge all buffered pre-session user records into one PreprocessingStage.
        Connects from the previous last_sid to preserve temporal order."""
        nonlocal last_sid
        if not buffered_inputs:
            return
        prev_sid = last_sid
        first_ts = next((r.get("_ts") for r in buffered_inputs if r.get("_ts")), None)
        desc_parts = [r.get("_desc") for r in buffered_inputs if r.get("_desc")]
        total_len = sum(r.get("_len", 0) for r in buffered_inputs)
        sid = new_id("user_input")
        stage = PreprocessingStage(
            id=sid,
            name=f"[{session_label}] User Context",
            description="; ".join(desc_parts) if desc_parts else session_label,
            metadata={"timestamp": first_ts, "block_type": "user_input", "merged_count": len(buffered_inputs),
                      "parent_sid": prev_sid},
            input_len=total_len,
        )
        graph.add_stage(stage)
        stage_ids.append(sid)
        if prev_sid:
            graph.connect(prev_sid, sid)
        last_sid = sid
        buffered_inputs.clear()

    for rec in records:
        rtype = rec.get("type", "")
        ts = parse_timestamp(rec.get("timestamp") or rec.get("ts"))
        msg = rec.get("message", {}) or {}
        rec_uuid = rec.get("uuid", "")

        content = msg.get("content", [])
        if not isinstance(content, list):
            content = [{"type": "text", "text": str(content)}]

        # Block type of the first non-empty block (all blocks in a record share one type)
        block_type = next(
            (b.get("type", "") for b in content if isinstance(b, dict) and b.get("type")),
            "",
        )

        stage = None

        # ── progress: hook lifecycle or inline subagent message ───────────────
        if rtype == "progress":
            data = rec.get("data", {}) or {}
            progress_type = data.get("type", "")

            if progress_type == "hook_progress":
                if buffered_inputs:
                    _flush_buffered_inputs()
                hook_name  = data.get("hookName", "")
                hook_event = data.get("hookEvent", "")
                # PreToolUse gates/validates before the tool runs → Preprocessing
                # PostToolUse/Stop fire after execution → Postprocessing
                _hook_meta = {
                    "uuid": rec_uuid,
                    "timestamp": ts,
                    "block_type": "hook_progress",
                    "hook_event": hook_event,
                    "hook_name": hook_name,
                    "command": data.get("command", ""),
                }
                sid = new_id("hook")
                if hook_event in ("PostToolUse", "Stop"):
                    stage = PostprocessingStage(
                        id=sid,
                        name=f"[{session_label}] Hook: {hook_name or hook_event}",
                        description=f"{hook_event} → {hook_name}",
                        metadata=_hook_meta,
                    )
                else:
                    # PreToolUse and any unknown hook events
                    stage = PreprocessingStage(
                        id=sid,
                        name=f"[{session_label}] Hook: {hook_name or hook_event}",
                        description=f"{hook_event} → {hook_name}",
                        metadata=_hook_meta,
                    )
                graph.add_stage(stage)
                stage_ids.append(sid)
                if last_sid:
                    stage.metadata["parent_sid"] = last_sid
                    graph.connect(last_sid, sid)
                last_sid = sid
                continue

            elif progress_type == "agent_progress":
                # Subagent turns are streamed inline here, but the subagent JSONL
                # (subagents/agent-{id}.jsonl) is the authoritative source.
                # We inline from the JSONL file at the tool_result stage instead,
                # so skip these progress records entirely.
                continue

            else:
                # Unknown progress subtype — skip.
                pass

        # ── queue-operation: buffer enqueue, create node on dequeue ──────────
        # enqueue + dequeue → one PreprocessingStage "Waiting in Queue"
        #   latency = dequeue_ts - enqueue_ts  (time spent waiting)
        #   input_len = tokens in text blocks of enqueue content (user's typed message)
        # dequeue-only (no buffered enqueue) → same node but latency = 0
        if rtype == "queue-operation":
            operation = rec.get("operation")
            if operation == "enqueue":
                # Buffer the enqueue; emit node when dequeue arrives
                text_blocks = [b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"]
                pending_enqueue = {
                    "ts": ts,
                    "uuid": rec_uuid,
                    "user_text": " ".join(t for t in text_blocks if t),
                    "input_len": token_count(" ".join(t for t in text_blocks if t)),
                    "has_attachments": any(b.get("type") != "text" for b in content if isinstance(b, dict)),
                    "session_id": rec.get("sessionId", ""),
                }
                continue
            elif operation == "dequeue":
                if buffered_inputs:
                    _flush_buffered_inputs()
                enq = pending_enqueue or {}
                enqueue_ts = enq.get("ts")
                if enqueue_ts is not None and ts is not None:
                    queue_latency = max(0.0, round(ts - enqueue_ts, 3))
                else:
                    queue_latency = 0.0
                sid = new_id("queue")
                stage = PreprocessingStage(
                    id=sid,
                    name=f"[{session_label}] Waiting in Queue",
                    description=enq.get("user_text", "") if enq.get("user_text") else "dequeue only",
                    metadata={
                        "uuid": enq.get("uuid", rec_uuid),
                        "timestamp": enqueue_ts or ts,
                        "block_type": "waiting_in_queue",
                        "enqueue_ts": enqueue_ts,
                        "dequeue_ts": ts,
                        "has_attachments": enq.get("has_attachments", False),
                        "session_id": enq.get("session_id", rec.get("sessionId", "")),
                        "start_timestamp": enqueue_ts if enqueue_ts is not None else ts,
                        "end_timestamp": ts,
                    },
                    input_len=enq.get("input_len", 0),
                )
                stage.latency = queue_latency
                graph.add_stage(stage)
                stage_ids.append(sid)
                if last_sid:
                    stage.metadata["parent_sid"] = last_sid
                    graph.connect(last_sid, sid)
                last_sid = sid
                pending_enqueue = None
                continue
            else:
                continue

        # ── Buffer initial user records before the first real stage ───────────
        is_initial_input = (
            rtype == "user" and block_type not in ("tool_result", "text") and not last_sid
        )
        if is_initial_input:
            text_desc = next(
                (b.get("text", "") or b.get("type", "") for b in content if isinstance(b, dict)), ""
            )
            buffered_inputs.append({
                "_ts": ts,
                "_desc": text_desc or rec.get("subtype", rtype),
                "_len": token_count(content),
            })
            continue

        # Flush buffered inputs before the first real stage
        if buffered_inputs:
            _flush_buffered_inputs()

        # ── System / init ──────────────────────────────────────
        if rtype == "system":
            sid = new_id("init")
            stage = PreprocessingStage(
                id=sid,
                name=f"[{session_label}] Session Init",
                description=rec.get("description", ""),
                metadata={
                    "uuid": rec_uuid,
                    "session_label": session_label,
                    "cwd": rec.get("cwd", ""),
                    "model": rec.get("model", ""),
                    "timestamp": ts,
                    "block_type": "system",
                },
                input_len=token_count(rec.get("content", "")),
            )

        # ── Assistant message ──────────────────────────────────
        elif rtype == "assistant":
            usage        = msg.get("usage", {})
            model_name   = msg.get("model", rec.get("model", ""))
            input_tokens = usage.get("input_tokens", 0) + usage.get("cache_creation_input_tokens", 0)
            kv_cache_len = usage.get("cache_read_input_tokens", 0)
            sid          = new_id("tool_use" if block_type == "tool_use" else
                                  "thinking"  if block_type == "thinking"  else
                                  "output"    if block_type == "text"      else "undefined")
            stage = _make_assistant_stage(
                sid, session_label, rec_uuid, ts, content, block_type,
                model_name, input_tokens, kv_cache_len,
                extra_meta={"full_usage": usage, "raw_message": msg,
                            "raw_timestamp": rec.get("timestamp")},
            )

        # ── User message ───────────────────────────────────────
        elif rtype == "user":
            if block_type == "tool_result":
                result_block = next(b for b in content if isinstance(b, dict))
                tool_use_id  = result_block.get("tool_use_id", "")
                _parent_sid  = pending_tool_uses.get(tool_use_id, "")
                model_name   = (
                    graph.stages[_parent_sid].metadata.get("model", "")
                    if _parent_sid and _parent_sid in graph.stages
                    else msg.get("model", rec.get("model", ""))
                )
                sid   = new_id("tool_result")
                stage = _make_tool_result_stage(
                    sid, session_label, rec_uuid, ts,
                    result_block, model_name, write_edit_tool_ids,
                    agent_tool_ids=agent_tool_ids,
                )
                if tool_use_id in agent_tool_ids:
                    tur = rec.get("toolUseResult")
                    tur = tur if isinstance(tur, dict) else {}
                    agent_id_here = tur.get("agentId", "")
                    # Always inline from the subagent JSONL — single unified path for
                    # both async and sync agents regardless of agent_progress records.
                    sub_jsonl = _subagents_dir / f"agent-{agent_id_here}.jsonl" if agent_id_here else None
                    if sub_jsonl and sub_jsonl.exists():
                        sub_label  = f"{session_label}/sub-{agent_id_here[:8]}"
                        sub_prefix = f"{id_prefix}_sub{agent_id_here[:8]}"
                        sub_ids = parse_session(sub_jsonl, sub_label, graph, sub_prefix, visited_files=visited_files)
                        if sub_ids and _parent_sid:
                            # parent tool_use → first subagent stage
                            graph.connect(_parent_sid, sub_ids[0])
                            graph.stages[sub_ids[0]].metadata["parent_sid"] = _parent_sid
                            # redirect wiring below: last subagent stage → this tool_result
                            pending_tool_uses[tool_use_id] = sub_ids[-1]
                        # This tool_result is just the return envelope — no generation here.
                        # Reclassify as OutputStage with zero duration; real work is in
                        # the inlined subagent stages.
                        preserved_meta = dict(stage.metadata)
                        preserved_meta["start_timestamp"] = ts
                        preserved_meta["end_timestamp"] = ts
                        preserved_meta["reclassified_from"] = "agent_tool_result"
                        preserved_meta["agent_id"] = agent_id_here
                        result_content = result_block.get("content", "")
                        extracted_rc   = _extract_string_content(result_content)
                        preserved_meta["output_tokens"] = token_count(extracted_rc)
                        stage = OutputStage(
                            id=sid,
                            name=f"[{session_label}] Agent Result",
                            description=extracted_rc,
                            metadata=preserved_meta,
                            input_len=token_count(result_content),
                            output_len=len(extracted_rc),
                        )
            else:
                sid   = new_id("user_input")
                stage = _make_user_input_stage(
                    sid, session_label, rec_uuid, ts, content, block_type,
                )

        # ── Result ─────────────────────────────────────────────
        elif rtype == "result":
            duration_ms = rec.get("duration_ms", rec.get("durationMs"))
            latency = round(duration_ms / 1000.0, 3) if duration_ms else None
            sid = new_id("result")
            stage = OutputStage(
                id=sid,
                name=f"[{session_label}] Session Result",
                description=f"cost=${rec.get('total_cost_usd', 0):.4f}",
                metadata={
                    "uuid": rec_uuid,
                    "subtype": rec.get("subtype", ""),
                    "total_cost_usd": rec.get("total_cost_usd", 0),
                    "num_turns": rec.get("num_turns", 0),
                    "duration_ms": duration_ms,
                    "timestamp": ts,
                    "block_type": "result",
                },
                latency=latency,
            )

        else:
            sid = new_id("undefined")
            stage = PreprocessingStage(
                id=sid,
                name=f"[{session_label}] Undefined",
                description=f"unknown record type: {rtype!r}",
                metadata={"uuid": rec_uuid, "timestamp": ts, "record_type": rtype, "undefined": True},
            )
            stage.stage_type = StageType.UNDEFINED

        if stage is None:
            continue

        # ── Attach raw fields from the JSONL record ───────────────
        # raw_timestamp: ISO string exactly as it appears in the JSONL
        # raw_message:   full message object (assistant + user records)
        # full_usage:    full usage dict (assistant records only)
        raw_ts = rec.get("timestamp")
        if raw_ts:
            stage.metadata["raw_timestamp"] = raw_ts
        if msg:
            stage.metadata["raw_message"] = msg
        if rtype == "assistant":
            stage.metadata["full_usage"] = msg.get("usage", {})

        graph.add_stage(stage)
        stage_ids.append(sid)

        # ── Semantic wiring ────────────────────────────────────
        #
        # tool_use  → from last_llm_sid  (all tool_uses dispatched from the same
        #             LLM decision are siblings, not chained through each other)
        #
        # tool_result → from its matching tool_use via tool_use_id
        #               (parentUuid would give the previous record, which is wrong
        #               when results come back out of dispatch order)
        #
        # thinking/text → fan-in from all recent_tool_results if any,
        #                 else sequential from last_sid

        if block_type == "tool_use":
            # Register each tool_use_id in this record for result matching
            for b in content:
                if isinstance(b, dict) and b.get("type") == "tool_use":
                    tid = b.get("id", "")
                    if tid:
                        pending_tool_uses[tid] = sid
                        if b.get("name", "").lower() in WRITE_TOOLS:
                            write_edit_tool_ids.add(tid)
                        if b.get("name", "").lower() in _AGENT_TOOLS:
                            agent_tool_ids.add(tid)
            parent_sid = last_llm_sid or last_sid
            if parent_sid:
                stage.metadata["parent_sid"] = parent_sid
                graph.connect(parent_sid, sid)

        elif block_type == "tool_result":
            result_block = next(
                (b for b in content if isinstance(b, dict) and b.get("type") == "tool_result"), None
            )
            tool_use_id = result_block.get("tool_use_id", "") if result_block else ""
            parent_sid = pending_tool_uses.pop(tool_use_id, None) or last_sid
            if parent_sid:
                stage.metadata["parent_sid"] = parent_sid
                graph.connect(parent_sid, sid)
            recent_tool_results.append(sid)

        elif block_type in ("thinking", "text"):
            if recent_tool_results:
                # Fan-in: this LLM stage consumes all pending tool results
                for tr_sid in recent_tool_results:
                    graph.connect(tr_sid, sid)
                # Use the last tool_result as primary parent for latency computation
                stage.metadata["parent_sid"] = recent_tool_results[-1]
                recent_tool_results = []
            elif last_sid:
                stage.metadata["parent_sid"] = last_sid
                graph.connect(last_sid, sid)
            last_llm_sid = sid

        else:
            # system, user_input, result, undefined — sequential
            if last_sid:
                stage.metadata["parent_sid"] = last_sid
                graph.connect(last_sid, sid)

        last_sid = sid


    _compute_latencies(stage_ids, graph)
    return stage_ids


def _compute_latencies(stage_ids: List[str], graph: AgenticGraph):
    """
    Second pass: fill latency on each stage from timestamps.

    Rules:
      thinking   → max(immediate children timestamps) - this.ts
      tool_result→ this.ts - parent_tool_use.ts  (execution time)
      tool_use   → None  (OUTPUT stage, no meaningful latency)
      text       → None  (OUTPUT stage, no meaningful latency for now)
      others     → skipped
    """
    # Build parent → [children] map using parent_sid stored in metadata
    parent_to_children: Dict[str, List[str]] = {}
    for sid in stage_ids:
        stage = graph.stages.get(sid)
        if not stage:
            continue
        psid = stage.metadata.get("parent_sid")
        if psid:
            parent_to_children.setdefault(psid, []).append(sid)

    for i, sid in enumerate(stage_ids):
        stage = graph.stages.get(sid)
        if not stage:
            continue
        ts = stage.metadata.get("timestamp")
        if ts is None:
            continue
        block_type = stage.metadata.get("block_type", "")
        parent_sid = stage.metadata.get("parent_sid")
        parent_ts = (
            graph.stages[parent_sid].metadata.get("timestamp")
            if parent_sid and parent_sid in graph.stages
            else None
        )

        def _lat(a: float, b: float, label: str) -> float:
            """Latency = a - b, clamped to 0. Warns on negative (clock skew / out-of-order records)."""
            diff = round(a - b, 3)
            if diff < 0:
                print(
                    f"  Warning: negative latency ({diff}s) for stage {sid} [{label}] "
                    f"— likely clock skew or out-of-order records, clamping to 0.",
                    file=sys.stderr,
                )
                return 0.0
            return diff

        # ── hook_progress: zero latency (sub-ms clock jitter makes next_ts unreliable)
        if block_type == "hook_progress":
            stage.latency = 0
            stage.metadata["start_timestamp"] = ts
            stage.metadata["end_timestamp"] = ts

        elif block_type == "thinking":
            # max(immediate children timestamps) - this.ts
            children = parent_to_children.get(sid, [])
            child_timestamps = [
                graph.stages[c].metadata.get("timestamp")
                for c in children
                if graph.stages.get(c) and graph.stages[c].metadata.get("timestamp") is not None
            ]
            if child_timestamps:
                stage.latency = _lat(max(child_timestamps), ts, "thinking→next")
            stage.metadata["start_timestamp"] = ts
            stage.metadata["end_timestamp"] = ts + (stage.latency or 0)

        elif block_type == "tool_use":
            # LLM stage: latency = time from parent stage to this tool_use emission
            if parent_ts is not None:
                lat = _lat(ts, parent_ts, "tool_use−parent")
                stage.latency = lat
            else:
                stage.latency = 0
            stage.metadata["start_timestamp"] = parent_ts if parent_ts is not None else ts
            stage.metadata["end_timestamp"] = ts

        elif block_type == "tool_result":
            if stage.metadata.get("reclassified_from") == "agent_tool_result":
                # Inlined agent return envelope: start/end already set to ts
                # during parsing (zero duration); nothing to recompute.
                stage.latency = 0
            else:
                # Execution time = result timestamp - parent tool_use timestamp
                if parent_ts is not None:
                    lat = _lat(ts, parent_ts, "tool_result−tool_use")
                    # Cap bash tool latency at 1 second
                    parent_stage = graph.stages.get(parent_sid)
                    if parent_stage:
                        tool_names = parent_stage.metadata.get("tool_names", [])
                        if any("bash" in n.lower() for n in tool_names):
                            lat = min(lat, 1.0)
                    stage.latency = lat
                    if hasattr(stage, "avg_latency"):
                        stage.avg_latency = lat
                stage.metadata["end_timestamp"] = ts
                stage.metadata["start_timestamp"] = ts - (stage.latency or 0)

        elif block_type == "waiting_in_queue":
            # latency already computed during parsing (dequeue_ts - enqueue_ts)
            # For dequeue-only stages enqueue_ts is None; fall back to dequeue_ts so
            # start_timestamp is never null (matches the patch applied to existing outputs).
            dequeue_ts = stage.metadata.get("dequeue_ts") or ts
            stage.metadata["start_timestamp"] = stage.metadata.get("enqueue_ts") or dequeue_ts
            stage.metadata["end_timestamp"] = dequeue_ts

        elif block_type == "user_input":
            stage.latency = 0
            stage.metadata["start_timestamp"] = ts
            stage.metadata["end_timestamp"] = ts

        elif block_type == "text":
            # Use only tool_use children (same LLM response batch) to compute latency.
            # Sequential next-stage children can be from the next user turn (large idle gap)
            # and must not be counted.
            children = parent_to_children.get(sid, [])
            tool_use_timestamps = [
                graph.stages[c].metadata.get("timestamp")
                for c in children
                if graph.stages.get(c)
                and graph.stages[c].metadata.get("block_type") == "tool_use"
                and graph.stages[c].metadata.get("timestamp") is not None
            ]
            if tool_use_timestamps:
                stage.latency = _lat(max(tool_use_timestamps), ts, "text→tool_use")
            stage.metadata["start_timestamp"] = ts
            stage.metadata["end_timestamp"] = ts + (stage.latency or 0)

        elif stage.metadata.get("undefined", False):
            # latency = next stage's timestamp − this timestamp
            next_ts = None
            for next_sid in stage_ids[i + 1:]:
                ns = graph.stages.get(next_sid)
                if ns and ns.metadata.get("timestamp") is not None:
                    next_ts = ns.metadata["timestamp"]
                    break
            lat = _lat(next_ts, ts, "undefined→next") if next_ts is not None else 0.0
            stage.latency = lat
            stage.metadata["timestamp"] = ts
            stage.metadata["start_timestamp"] = ts
            stage.metadata["end_timestamp"] = next_ts if next_ts is not None else ts

        elif block_type in ("system", "result", "undefined"):
            stage.latency = 0
            stage.metadata["start_timestamp"] = ts
            stage.metadata["end_timestamp"] = ts



# ─── Directory Scanner ────────────────────────────────────────────────────────

# Patterns for Claude Code session file naming (mirrors claude-replay's resolve-session.mjs)
_uuid_re = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


# ─── Session Clustering ───────────────────────────────────────────────────────

def _read_file_uuid_sets(path: Path):
    """
    Quick scan of a JSONL file.
    Returns (all_record_uuids, all_parent_uuids) as frozensets.

    Used to detect cross-file parentUuid references that indicate a session
    continuation, versus files with no shared references (independent sessions).
    """
    all_uuids:    set = set()
    parent_uuids: set = set()
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    u = rec.get("uuid", "")
                    if u:
                        all_uuids.add(u)
                    pu = rec.get("parentUuid", "")
                    if pu:
                        parent_uuids.add(pu)
                except json.JSONDecodeError:
                    pass
    except Exception:
        pass
    return frozenset(all_uuids), frozenset(parent_uuids)


def _cluster_uuid_files(uuid_files: List[Path]) -> List[List[Path]]:
    """
    Group UUID session files into clusters of related (continuation) sessions.

    Two files end up in the same cluster when one file's parentUuid values
    overlap with the other file's record UUIDs — i.e., file B is a continuation
    of file A because B's records reference A's records via parentUuid.

    Files with zero cross-references form independent singleton clusters —
    they represent completely separate sessions that happen to share a directory.

    Returns a list of clusters sorted descending by total file size (largest first).
    """
    if not uuid_files:
        return []
    if len(uuid_files) == 1:
        return [uuid_files]

    # Read UUID / parentUuid sets once per file
    uuid_sets:   Dict[str, frozenset] = {}
    parent_sets: Dict[str, frozenset] = {}
    for f in uuid_files:
        u, p = _read_file_uuid_sets(f)
        uuid_sets[f.stem]   = u
        parent_sets[f.stem] = p

    stems = [f.stem for f in uuid_files]

    # Union-Find (path-compressed)
    _uf: Dict[str, str] = {s: s for s in stems}

    def _find(x: str) -> str:
        while _uf[x] != x:
            _uf[x] = _uf[_uf[x]]
            x = _uf[x]
        return x

    def _union(x: str, y: str) -> None:
        rx, ry = _find(x), _find(y)
        if rx != ry:
            _uf[rx] = ry

    # Link files that reference each other via parentUuid
    for stem_b in stems:
        if not parent_sets[stem_b]:
            continue
        for stem_a in stems:
            if stem_a == stem_b:
                continue
            # If any parentUuid in B is a record UUID in A → B continues A
            if parent_sets[stem_b] & uuid_sets[stem_a]:
                _union(stem_a, stem_b)

    # Group by cluster root
    stem_to_file = {f.stem: f for f in uuid_files}
    raw_clusters: Dict[str, List[Path]] = {}
    for stem in stems:
        root = _find(stem)
        raw_clusters.setdefault(root, []).append(stem_to_file[stem])

    # Sort clusters: largest total byte size first
    return sorted(
        raw_clusters.values(),
        key=lambda c: sum(p.stat().st_size for p in c),
        reverse=True,
    )



def _parse_cluster(
    cluster: List[Path],
    graph_name: str,
    graph_description: str,
    visited_files: Optional[set] = None,
) -> AgenticGraph:
    """
    Build one AgenticGraph for a single session cluster.

    The file with the latest mtime is PRIMARY; the rest are chained after it.
    """
    graph = AgenticGraph(name=graph_name, description=graph_description)

    if len(cluster) == 1:
        primary_file   = cluster[0]
        other_files: List[Path] = []
    else:
        ranked = sorted(cluster, key=lambda p: p.stat().st_mtime, reverse=True)
        primary_file = ranked[0]
        other_files  = ranked[1:]

    primary_label = primary_file.stem[:8]

    print(
        f"  Primary: {primary_file.name} | "
        f"Other UUID files in cluster: {len(other_files)}"
    )
    print(f"  Parsing primary session [{primary_label}]: {primary_file.name}")

    primary_ids = parse_session(primary_file, primary_label, graph, f"s0_{primary_label}", visited_files=visited_files)
    last_sid: Optional[str] = primary_ids[-1] if primary_ids else None

    for i, ufile in enumerate(other_files, start=1):
        label = ufile.stem[:8]
        print(f"  Parsing additional session [{label}]: {ufile.name}")
        ids = parse_session(ufile, label, graph, f"s{i}_{label}", visited_files=visited_files)
        if ids and last_sid and last_sid in graph.stages:
            graph.connect(last_sid, ids[0])
        if ids:
            last_sid = ids[-1]

    print(f"  → {len(graph.stages)} stages, {len(graph.edges)} edges")
    return graph


def build_graphs_from_directory(
    directory: Path, name: str = None, visited_files: Optional[set] = None
) -> List[AgenticGraph]:
    """
    Parse a Claude Code project directory and return one AgenticGraph per
    independent session cluster.

    Detection logic
    ---------------
    Each record in a Claude Code JSONL file carries a ``parentUuid`` field that
    chains it to its predecessor.  When a session *continues* in a new file, the
    new file's first records will have ``parentUuid`` values that point to record
    UUIDs in the previous file — that cross-file reference places both files in
    the same cluster.

    Files that share no ``parentUuid`` cross-references are independent sessions
    (different tasks started at different times) and produce separate graphs /
    separate output JSON files.

    """
    directory = directory.resolve()
    base_name = name or directory.name

    # ── Collect UUID session files ────────────────────────────────────────────
    uuid_files: List[Path] = []

    for f in sorted(directory.glob("*.jsonl")):
        if f.stat().st_size == 0:
            continue
        if _uuid_re.match(f.stem):
            uuid_files.append(f)

    if not uuid_files:
        print("  No parent session JSONL files found — will scan for orphaned agent files.")
        return []

    # ── Cluster independent sessions ─────────────────────────────────────────
    clusters = _cluster_uuid_files(uuid_files)

    if len(clusters) > 1:
        print(f"Detected {len(clusters)} independent session clusters in {directory.name}:")
        for i, c in enumerate(clusters, 1):
            stems = ", ".join(f.stem[:8] for f in c)
            print(f"  Cluster {i}: [{stems}]  ({len(c)} file(s))")
    else:
        c = clusters[0] if clusters else []
        print(f"Single session cluster: {len(c)} UUID file(s)")

    # ── Build one graph per cluster ───────────────────────────────────────────
    graphs: List[AgenticGraph] = []
    for i, cluster in enumerate(clusters):
        label = cluster[0].stem[:8]
        if len(clusters) > 1:
            graph_name = f"{base_name} [{label}]"
            graph_desc = f"Parsed from {directory} — session {label}"
            print(f"\nBuilding graph for cluster {i+1}/{len(clusters)} [{label}]:")
        else:
            graph_name = base_name
            graph_desc = f"Parsed from {directory}"

        graph = _parse_cluster(cluster, graph_name, graph_desc, visited_files=visited_files)
        graphs.append(graph)

    return graphs



# ─── Stage serialisation helper ──────────────────────────────────────────────

def _stage_dict(stage) -> dict:
    """Serialize a stage to JSON-ready dict, surfacing raw timestamp/message/usage."""
    d = stage.get_display_info()
    meta = stage.metadata
    d["timestamp"] = meta.get("raw_timestamp")
    d["usage"]     = meta.get("full_usage")
    return d


def _write_graph_json(graph: AgenticGraph, out_path: Path) -> None:
    out_data = {
        "name":        graph.name,
        "description": graph.description,
        "stages":      [_stage_dict(s) for s in graph.stages.values()],
        "edges":       [{"from": f, "to": t} for f, t in graph.edges],
    }
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(out_data, fh, indent=2)


# ─── Orphan agent scanner ─────────────────────────────────────────────────────

def _process_orphan_agents(directory: Path, out_dir: Path, visited_files: set) -> int:
    """
    Find all agent-*.jsonl files under *directory* that were not already inlined
    into a parent graph, parse each as a standalone graph, and write JSON output.

    Two layouts are handled:
      NEW  …/{session-uuid}/subagents/agent-{id}.jsonl
           Output: {session_uuid[:8]}-{agent_stem}.json
      OLD  …/agent-{shortid}.jsonl  (directly in the project dir, no subagents/)
           Output: {agent_stem}.json

    __MACOSX/ directories (macOS zip metadata) are always excluded.
    Empty files are skipped.
    """
    # Collect every agent-*.jsonl anywhere under the project directory
    all_agent_files = [
        f for f in directory.rglob("agent-*.jsonl")
        if "__MACOSX" not in f.parts
        and f.stat().st_size > 0
    ]

    orphans = [f for f in all_agent_files if f.resolve() not in visited_files]

    if not orphans:
        return 0

    print(f"\n  Orphaned agent files: {len(orphans)}")

    parsed_count = 0
    for agent_file in sorted(orphans):
        # Determine output stem from the file's location in the directory tree
        if agent_file.parent.name == "subagents":
            # NEW layout: …/{session-uuid}/subagents/agent-xxx.jsonl
            session_uuid_dir = agent_file.parent.parent.name
            out_stem = f"{session_uuid_dir[:8]}-{agent_file.stem}"
        else:
            # OLD layout: agent-xxx.jsonl directly in the project dir (or a non-subagents dir)
            out_stem = agent_file.stem

        out_path = out_dir / f"{out_stem}.json"

        rel = agent_file.relative_to(directory)
        print(f"    {rel}  →  {out_path.name}")

        label  = out_stem
        prefix = f"orp_{out_stem[:12].replace('-', '_')}"
        graph  = AgenticGraph(
            name=out_stem,
            description=f"Orphaned agent session: {agent_file}",
        )

        ids = parse_session(agent_file, label, graph, prefix, visited_files=visited_files)
        if not ids:
            print(f"      (skipped — no parseable records)")
            continue

        _write_graph_json(graph, out_path)
        print(f"      → {len(graph.stages)} stages, {len(graph.edges)} edges")
        parsed_count += 1

    return parsed_count


# ─── CLI ──────────────────────────────────────────────────────────────────────

# Fixed base output root — all JSON files land under claude_code/output/
_OUTPUT_ROOT = Path("claude_code/output")


def main():
    ap = argparse.ArgumentParser(
        description="Parse Claude Code JSONL directory → AgenticGraph JSON"
    )
    ap.add_argument("--dir", required=True,
                    help="Path to project directory containing .jsonl files")
    ap.add_argument("--name", default=None, help="Graph name override")
    args = ap.parse_args()

    directory = Path(args.dir).resolve()
    if not directory.exists():
        print(f"Error: {directory} does not exist", file=sys.stderr)
        sys.exit(1)

    out_dir = _OUTPUT_ROOT / directory.name
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Parsing directory : {directory}")
    print(f"Output directory  : {out_dir}/")

    visited_files: set = set()
    graphs = build_graphs_from_directory(directory, name=args.name, visited_files=visited_files)

    session_graphs_written = 0
    for graph in graphs:
        # Session tag: 8-char prefix of the primary session UUID
        # Embedded in graph name as "GraphName [d81021af]" when multi-session,
        # or we fall back to the directory name for single-session directories.
        if "[" in graph.name:
            session_tag = graph.name.split("[")[-1].rstrip("]").strip()
        else:
            session_tag = directory.name

        out_path = out_dir / f"{session_tag}.json"
        _write_graph_json(graph, out_path)
        print(f"JSON saved → {out_path}  ({len(graph.stages)} stages, {len(graph.edges)} edges)")
        session_graphs_written += 1

    orphan_count = _process_orphan_agents(directory, out_dir, visited_files)

    if session_graphs_written == 0 and orphan_count == 0:
        print("No graphs produced.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()