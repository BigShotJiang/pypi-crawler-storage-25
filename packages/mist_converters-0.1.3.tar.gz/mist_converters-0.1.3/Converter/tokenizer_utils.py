import os

# Set before transformers is imported so library-level warnings never reach the terminal.
# TRANSFORMERS_VERBOSITY silences the "PyTorch not found" notice emitted at import time.
# TOKENIZERS_PARALLELISM prevents a fork-safety warning from the Rust tokenizer backend.
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_HUB_VERBOSITY", "error")  # silences unauthenticated-request notice

_tokenizer = None

def _get_tokenizer():
    global _tokenizer
    if _tokenizer is None:
        from transformers import AutoTokenizer, logging as _hf_logging
        _hf_logging.set_verbosity_error()
        _tokenizer = AutoTokenizer.from_pretrained("deepseek-ai/DeepSeek-R1")
    return _tokenizer

def count_prompt_tokens(system_prompt: str, user_prompt: str) -> int:
    """Count total tokens in system and user prompts."""
    tok = _get_tokenizer()
    return len(tok.encode(system_prompt)) + len(tok.encode(user_prompt))

def count_tokens(prompt: str) -> int:
    """Count tokens in a single prompt."""
    return len(_get_tokenizer().encode(prompt))

def preprocess_tokens(prompt: str) -> str:
    return prompt.replace('\n', '')


import re
import json
import sys
import csv
from pathlib import Path

# Add parent directory to path to import Builder module
sys.path.insert(0, str(Path(__file__).parent.parent))




def convert_json_to_csv(json_filename: str, csv_filename: str):
    """
    Phase 2: Read the JSON dump and convert to the specific CSV format.
    CSV Columns: node_id, stage, model_name, input_length, output_length, graph_id, dependencies
    """
    with open(json_filename, 'r', encoding='utf-8') as f:
        data = json.load(f)

    graph_id = Path(json_filename).stem.replace("_dump", "") # e.g. task_0
    
    # Build Dependency Map (Reverse Adjacency: Target -> [Sources])
    parent_map = {}
    for edge in data["edges"]:
        src = edge["source"]
        tgt = edge["target"]
        if tgt not in parent_map:
            parent_map[tgt] = []
        parent_map[tgt].append(src)

    rows = []
    
    for node in data["nodes"]:
        n_id = node["id"]
        n_type = node["type"]
        
        # 1. Determine Stage Label
        if n_type == "LLMCallStage":
            stage_label = "[PREFILL, DECODE]"
        elif "Tool" in n_type:
            stage_label = "[TOOL]"
        elif "Preprocessing" in n_type or "Postprocessing" in n_type:
            stage_label = "[CPU]"
        else:
            stage_label = "[CPU]"

        # 2. Model Name
        model_name = node.get("model", "N/A")
        if model_name == "N/A" and stage_label == "[CPU]":
            model_name = "Host_Machine"

        # 3. Input Length
        input_len = node.get("input_len", 0)

        # 4. Output Length (Calculate tokens from output text if LLM)
        output_len = 0
        if "output_text" in node and node["output_text"]:
            output_len = count_tokens(node["output_text"])
        
        # 5. Dependencies string "[id1, id2]"
        parents = parent_map.get(n_id, [])
        # Format explicitly as string representation of list like "[src1, src2]"
        if not parents:
            deps_str = "" # Leave empty if no dependencies, or "[]" based on pref
        else:
            # Enforce the string format "[a,b]"
            deps_str = "[" + ",".join(str(p) for p in parents) + "]"

        rows.append({
            "node_id": n_id,
            "stage": stage_label,
            "model_name": model_name,
            "input_length": input_len,
            "output_length": output_len,
            "graph_id": graph_id,
            "dependencies": deps_str
        })

    # Write CSV
    headers = ["node_id", "stage", "model_name", "input_length", "output_length", "graph_id", "dependencies"]
    
    with open(csv_filename, 'w', newline='', encoding='utf-8') as f:
        # Use quoting=csv.QUOTE_MINIMAL or QUOTE_NONNUMERIC to handle the brackets in dependencies
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
            
    print(f"-> Converted to CSV: {csv_filename}")