"""
convert_jsonl_to_graph.py

Ingest a Claude Code session JSONL and emit an AgenticGraph JSON file
(same schema as task_0_dump.json / AgenticGraphConverter.from_json).

Graph mapping
─────────────
  initial user message    → preprocessing  ("User Input")
  LLM call (message.id)  → llm_call        [PREFILL, DECODE]
  tool_use block          → tool_call
  tool-result user msg   → preprocessing  ("Tool Results")

Token counts come directly from message.usage; no tokenizer needed.

  input_len        = input_tokens + cache_creation_input_tokens + cache_read_input_tokens
  output_len       = output_tokens
  past_KV_context  = cache_read_input_tokens  (cached context from prior turns)
  system_prompt_len ≈ cache_read of first LLM call (pre-cached system prompt)
  user_prompt_len  = input_tokens (fresh uncached tokens in this turn)

Latency
  LLM call  : last_chunk_timestamp − first_chunk_timestamp
  tool_call : tool_result_timestamp − tool_use_chunk_timestamp
  preprocessing : 0.0

Usage
  python convert_jsonl_to_graph.py [input.jsonl [output.json]]
"""

import json
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


# ─── helpers ──────────────────────────────────────────────────────────────────

def _ts(iso: str) -> datetime | None:
    try:
        return datetime.fromisoformat(iso.replace("Z", "+00:00"))
    except Exception:
        return None


def _latency(t_start: str | None, t_end: str | None) -> float | None:
    if not t_start or not t_end:
        return None
    s, e = _ts(t_start), _ts(t_end)
    if s and e:
        return round((e - s).total_seconds(), 4)
    return None


def _group_key(rec: dict) -> str | None:
    """Stable key that groups streaming chunks of the same LLM call together."""
    # Prefer message.id (present in both old and new Claude Code JSONL)
    mid = rec.get("message", {}).get("id")
    if mid:
        return mid
    # Fall back to requestId (older format)
    return rec.get("requestId")


def _read_usage(rec: dict) -> dict:
    usage = rec.get("message", {}).get("usage", {})
    cc = usage.get("cache_creation_input_tokens", 0)
    if isinstance(usage.get("cache_creation"), dict):
        cobj = usage["cache_creation"]
        cc = cobj.get("ephemeral_1h_input_tokens", 0) + cobj.get("ephemeral_5m_input_tokens", 0)
    return {
        "input_tokens":          usage.get("input_tokens", 0),
        "cache_creation":        cc,
        "cache_read":            usage.get("cache_read_input_tokens", 0),
        "output_tokens":         usage.get("output_tokens", 0),
    }


def _text_blocks(content) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = [b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"]
        return " ".join(p for p in parts if p).strip()
    return ""


def _tool_uses_in(content) -> list[dict]:
    if not isinstance(content, list):
        return []
    return [b for b in content if isinstance(b, dict) and b.get("type") == "tool_use"]


def _tool_results_in(content) -> list[dict]:
    if not isinstance(content, list):
        return []
    return [b for b in content if isinstance(b, dict) and b.get("type") == "tool_result"]


def _subagent_end_ts(subagents_dir: Path, agent_id: str) -> str | None:
    """Return the timestamp of the last entry in the subagent JSONL file.

    For async Agent tool calls the tool_result timestamp is only the launch
    confirmation; the true end of the agent's work is the last line of its own
    JSONL file kept in  <session_dir>/subagents/agent-<agentId>.jsonl.
    """
    jsonl_path = subagents_dir / f"agent-{agent_id}.jsonl"
    if not jsonl_path.exists():
        return None
    last_ts: str | None = None
    with open(jsonl_path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                ts = entry.get("timestamp")
                if ts:
                    last_ts = ts
            except json.JSONDecodeError:
                pass
    return last_ts


# ─── JSONL loading ─────────────────────────────────────────────────────────────

def load_jsonl(path: str) -> list[dict]:
    records: list[dict] = []
    with open(path, encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as exc:
                print(f"Warning: bad JSON on line {lineno}: {exc}", file=sys.stderr)
    return records


# ─── Parsing ──────────────────────────────────────────────────────────────────

class LLMCallInfo:
    __slots__ = (
        "group_key", "chunks", "first_uuid", "last_uuid",
        "first_ts", "last_ts", "usage", "model",
        "tool_uses",      # list[{id, name, input, ts, uuid}]
        "output_text",
    )

    def __init__(self, group_key: str):
        self.group_key = group_key
        self.chunks: list[dict] = []
        self.first_uuid = self.last_uuid = None
        self.first_ts = self.last_ts = None
        self.usage: dict = {}
        self.model = "unknown"
        self.tool_uses: list[dict] = []
        self.output_text = ""

    def add_chunk(self, rec: dict):
        self.chunks.append(rec)
        uid = rec.get("uuid")
        ts  = rec.get("timestamp")
        if self.first_uuid is None:
            self.first_uuid = uid
            self.first_ts   = ts
        self.last_uuid = uid
        self.last_ts   = ts

        msg   = rec.get("message", {})
        u     = _read_usage(rec)
        # Keep usage from the chunk with the most output_tokens (the "final" chunk)
        if u["output_tokens"] >= self.usage.get("output_tokens", 0):
            self.usage = u
        if not self.model or self.model == "unknown":
            self.model = msg.get("model", "unknown")

        content = msg.get("content", [])
        for tu in _tool_uses_in(content):
            tuid = tu.get("id", "")
            if not any(x["id"] == tuid for x in self.tool_uses):
                self.tool_uses.append({
                    "id":    tuid,
                    "name":  tu.get("name", ""),
                    "input": tu.get("input", {}),
                    "ts":    ts,
                    "uuid":  uid,
                })
        if not self.output_text:
            txt = _text_blocks(content)
            if txt:
                self.output_text = txt


class UserMsgInfo:
    __slots__ = ("uuid", "parent_uuid", "ts", "has_tool_results",
                 "tool_results",   # list[{tool_use_id, content}]
                 "text",
                 "source_assistant_uuid",
                 "tool_use_result",  # toolUseResult top-level field (Agent async metadata)
                 )

    def __init__(self, rec: dict):
        self.uuid                = rec.get("uuid")
        self.parent_uuid         = rec.get("parentUuid")
        self.ts                  = rec.get("timestamp")
        self.source_assistant_uuid = rec.get("sourceToolAssistantUUID")
        content                  = rec.get("message", {}).get("content", [])
        self.tool_results        = _tool_results_in(content)
        self.has_tool_results    = bool(self.tool_results)
        self.text                = _text_blocks(content)
        self.tool_use_result     = rec.get("toolUseResult")  # present on Agent tool-result records


def parse_session(records: list[dict]):
    """
    Returns:
        llm_calls  : OrderedDict[group_key -> LLMCallInfo]  (insertion = first-chunk order)
        user_msgs  : dict[uuid -> UserMsgInfo]
        uuid_to_gk : dict[uuid -> group_key]  (for assistant chunks)
        session_id : str
    """
    llm_calls:  dict[str, LLMCallInfo] = {}
    user_msgs:  dict[str, UserMsgInfo] = {}
    uuid_to_gk: dict[str, str]         = {}
    session_id: str | None = None

    for rec in records:
        if rec.get("type") == "queue-operation":
            continue

        if session_id is None:
            session_id = rec.get("sessionId")

        rtype = rec.get("type")

        if rtype == "assistant":
            gk = _group_key(rec)
            if not gk:
                continue
            if gk not in llm_calls:
                llm_calls[gk] = LLMCallInfo(gk)
            llm_calls[gk].add_chunk(rec)
            uid = rec.get("uuid")
            if uid:
                uuid_to_gk[uid] = gk

        elif rtype == "user":
            uid = rec.get("uuid")
            if uid:
                user_msgs[uid] = UserMsgInfo(rec)

    return llm_calls, user_msgs, uuid_to_gk, (session_id or "unknown")


# ─── Graph flow traversal ──────────────────────────────────────────────────────

def build_ordered_chain(llm_calls, user_msgs, uuid_to_gk):
    """
    Walk the parentUuid chain and return an ordered list of
        ("user", UserMsgInfo) | ("llm", LLMCallInfo)

    The chain is:
      root_user → LLM_A → [tool_results_user] → LLM_B → …
    """
    # parent_uuid → LLM call (whose first chunk has that parent)
    parent_to_llm: dict[str, LLMCallInfo] = {
        lc.chunks[0].get("parentUuid"): lc
        for lc in llm_calls.values()
        if lc.chunks
    }

    # parent_uuid → user message
    parent_to_user: dict[str, UserMsgInfo] = {
        um.parent_uuid: um
        for um in user_msgs.values()
        if um.parent_uuid
    }

    # Find root user message (parentUuid is None)
    root = next((um for um in user_msgs.values() if um.parent_uuid is None), None)
    if root is None:
        # Fall back: earliest user message
        root = min(user_msgs.values(), key=lambda u: u.ts or "", default=None)
    if root is None:
        return []

    chain: list[tuple] = []
    visited_uuids: set[str] = set()
    visited_gks:   set[str] = set()

    cur_user: UserMsgInfo | None = root

    while cur_user and cur_user.uuid not in visited_uuids:
        visited_uuids.add(cur_user.uuid)
        chain.append(("user", cur_user))

        # Find the LLM call whose first chunk's parent == cur_user.uuid
        lc = parent_to_llm.get(cur_user.uuid)
        if lc is None:
            break
        if lc.group_key in visited_gks:
            break
        visited_gks.add(lc.group_key)
        chain.append(("llm", lc))

        # Find next user message: parent == last_uuid of this LLM call
        next_user = parent_to_user.get(lc.last_uuid)
        if next_user is None:
            break
        cur_user = next_user

    return chain


# ─── AgenticGraph JSON builder ─────────────────────────────────────────────────

def build_graph_json(chain, session_id: str, subagents_dir: Path | None = None) -> dict:
    """
    Emit a task_0_dump.json-compatible AgenticGraph dict.

    Stage types:
      preprocessing  – user input / tool results
      llm_call       – LLM inference
      tool_call      – tool execution (one per tool_use block)

    Fields populated:
      input_len, output_len, latency
      model, past_KV_context, system_prompt_len, user_prompt_len
      tool_name, input_cmd, current_KV_context, actions_count
    """
    # Build lookup: tool_use_id -> UserMsgInfo (for latency)
    tool_use_id_to_result: dict[str, UserMsgInfo] = {}
    for _, obj in chain:
        if _ == "user":
            um: UserMsgInfo = obj
            for tr in um.tool_results:
                tuid = tr.get("tool_use_id")
                if tuid:
                    tool_use_id_to_result[tuid] = um

    stages: list[dict] = []
    edges:  list[dict] = []

    # Counters for human-readable IDs
    prep_n = llm_n = tool_n = 0
    prev_stage_ids: list[str] = []

    # Remember first call's cache_read as system prompt length baseline
    first_llm_seen = False
    system_prompt_baseline = 0

    for kind, obj in chain:

        # ── Preprocessing (user message) ───────────────────────────────────
        if kind == "user":
            um: UserMsgInfo = obj
            prep_n += 1
            sid   = f"prep_{prep_n}"
            name  = "Tool Results" if um.has_tool_results else "User Input"
            ops   = "tool_result_processing" if um.has_tool_results else "user_request"

            stages.append({
                "id":          sid,
                "name":        name,
                "type":        "preprocessing",
                "description": um.text[:200] if um.text else name,
                "input_len":   0,
                "output_len":  0,
                "latency":     None,
                "operations":  ops,
            })
            for pid in prev_stage_ids:
                edges.append({"from": pid, "to": sid})
            prev_stage_ids = [sid]

        # ── LLM call ──────────────────────────────────────────────────────
        elif kind == "llm":
            lc: LLMCallInfo = obj
            llm_n += 1
            sid = f"llm_{llm_n}"

            u = lc.usage
            inp_tok    = u.get("input_tokens", 0)
            cache_cc   = u.get("cache_creation", 0)
            cache_read = u.get("cache_read", 0)
            out_tok    = u.get("output_tokens", 0)

            input_len  = inp_tok + cache_cc + cache_read
            output_len = out_tok
            llm_lat    = _latency(lc.first_ts, lc.last_ts)

            if not first_llm_seen:
                system_prompt_baseline = cache_read
                first_llm_seen = True

            stages.append({
                "id":               sid,
                "name":             f"LLM Call {llm_n}",
                "type":             "llm_call",
                "description":      lc.output_text[:200] if lc.output_text else "",
                "input_len":        input_len,
                "output_len":       output_len,
                "latency":          f"{llm_lat}s" if llm_lat is not None else None,
                # LLM-specific
                "model":            lc.model,
                "temperature":      0.7,
                "max_tokens":       8192,
                "call_type":        "",
                "system_prompt":    "",
                "system_prompt_len": system_prompt_baseline,
                "user_prompt":      "",
                "user_prompt_len":  inp_tok,
                "past_KV_context":  cache_read,
                "output":           lc.output_text[:500] if lc.output_text else "",
            })
            for pid in prev_stage_ids:
                edges.append({"from": pid, "to": sid})

            if lc.tool_uses:
                # One TOOL_CALL stage per tool_use block
                tool_stage_ids: list[str] = []
                for tu in lc.tool_uses:
                    tool_n += 1
                    tsid = f"tool_{tool_n}"
                    tool_stage_ids.append(tsid)

                    # Latency: tool_result_timestamp - tool_use_chunk_timestamp
                    # For async Agent calls the tool_result timestamp is only
                    # the launch confirmation; use the subagent JSONL last entry
                    # as the true end timestamp instead.
                    result_msg = tool_use_id_to_result.get(tu["id"])
                    tur = getattr(result_msg, "tool_use_result", None) if result_msg else None
                    is_async_agent = (
                        tu["name"] == "Agent"
                        and tur is not None
                        and tur.get("isAsync") is True
                    )
                    if is_async_agent and subagents_dir is not None:
                        agent_id = tur.get("agentId", "")
                        result_ts = _subagent_end_ts(subagents_dir, agent_id)
                    else:
                        result_ts = result_msg.ts if result_msg else None
                    tool_lat = _latency(tu["ts"], result_ts)

                    stages.append({
                        "id":                  tsid,
                        "name":                tu["name"] or f"Tool {tool_n}",
                        "type":                "tool_call",
                        "description":         f"Tool: {tu['name']}",
                        "input_len":           0,
                        "output_len":          0,
                        "latency":             f"{tool_lat}s" if tool_lat is not None else None,
                        # ToolCall-specific
                        "tool_name":           tu["name"],
                        "input_cmd":           json.dumps(tu["input"])[:300] if tu["input"] else "",
                        "parameters":          tu["input"],
                        "timeout":             120,
                        "current_KV_context":  cache_read,
                        "new_KV_context":      0,
                        "action":              tu["name"],
                        "actions_count":       1,
                    })
                    edges.append({"from": sid, "to": tsid})

                prev_stage_ids = tool_stage_ids

            else:
                prev_stage_ids = [sid]

    return {
        "name":        f"Claude Session — {session_id}",
        "description": "Claude Code session converted to AgenticGraph",
        "stages":      stages,
        "edges":       edges,
    }


# ─── Entry point ───────────────────────────────────────────────────────────────

def convert(input_path: str, output_path: str) -> dict:
    print(f"Loading {input_path} …")
    records = load_jsonl(input_path)

    llm_calls, user_msgs, uuid_to_gk, session_id = parse_session(records)
    print(f"  {len(user_msgs)} user messages, {len(llm_calls)} LLM calls")

    chain = build_ordered_chain(llm_calls, user_msgs, uuid_to_gk)

    kinds = [k for k, _ in chain]
    llm_count  = kinds.count("llm")
    user_count = kinds.count("user")
    print(f"  Chain: {len(chain)} nodes — {user_count} user msgs, {llm_count} LLM calls")

    # Subagent JSONL files live at <session_dir>/subagents/ next to the main JSONL
    p = Path(input_path)
    subagents_dir = p.parent / p.stem / "subagents"
    if not subagents_dir.exists():
        subagents_dir = None

    graph = build_graph_json(chain, session_id, subagents_dir=subagents_dir)

    # Count tool_call stages
    tool_count = sum(1 for s in graph["stages"] if s["type"] == "tool_call")
    print(f"  Stages: {len(graph['stages'])} total  "
          f"({sum(1 for s in graph['stages'] if s['type']=='preprocessing')} preprocessing, "
          f"{llm_count} llm_call, {tool_count} tool_call)")

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2)
    print(f"Wrote AgenticGraph JSON → {output_path}")

    return graph


if __name__ == "__main__":
    default_input  = (
        "/home/ivohra6/GenA-LLM/projects/"
        "-Users-aayushi-Documents-Research-code-policeRL-POLICEd-RL/"
        "3ac0a1ce-1ad0-4c47-9120-185cecf6cb4f.jsonl"
    )
    default_output = "/home/ivohra6/mist-converters/claude_graph_data.json"

    inp = sys.argv[1] if len(sys.argv) > 1 else default_input
    out = sys.argv[2] if len(sys.argv) > 2 else default_output

    convert(inp, out)
