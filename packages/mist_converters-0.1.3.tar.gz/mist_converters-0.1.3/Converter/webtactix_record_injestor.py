"""
webtactix_record_injestor.py

JSON-native injector for WebTactix record/webarena task directories.

Instead of parsing the HTML produced by build_record_site.py, this injector
reads the raw JSON files directly (meta.json, task.json, final.json,
round_*/round.json, round_*/plan_*.json, round_*/decision.json,
round_*/actions.json, round_*/data_extraction/) and constructs the same
AgenticGraph that the HTML injector (webtactic_injestor.py) produces.

Optionally generates a task_<id>.html alongside the JSON dump for
side-by-side verification against the HTML injector output.

Usage:
    python webtactix_record_injestor.py [base_dir] [--model MODEL] [--task TASK_NAME]
    python webtactix_record_injestor.py /home/ivohra6/benchmarks/webtactix/record/webarena \
        --model vllm_sudo --task task_410

Stage graph structure (identical to HTML injector):
    task_input
      └─ constraint_agent
           └─ r000_preprocessing
                └─ r001_prep
                     ├─ r001_plan_v1   ──┐
                     ├─ r001_plan_v2   ──┤
                     ...                 ▼
                                  r001_postprocess
                                      └─ r001_decision_prep
                                           └─ r001_decision_llm
                                                └─ r001_decision_post
                                                     └─ r001_execute
                                                          └─ r001_data_extraction  (optional)
                                                               └─ r002_prep  ...
    summary
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── path setup ───────────────────────────────────────────────────────────────
_HERE = Path(__file__).parent
sys.path.insert(0, str(_HERE.parent))

# Import the JSON parsing helper from build_record_site.py
_BUILD_SITE = Path("/home/ivohra6/benchmarks/webtactix/webtactix/tools/build_record_site.py")
if _BUILD_SITE.exists():
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location("build_record_site", _BUILD_SITE)
    _brs = _ilu.load_from_spec(_spec)       # type: ignore[arg-type]
    _spec.loader.exec_module(_brs)          # type: ignore[union-attr]
    _parse_task    = _brs.parse_task
    _render_task   = _brs.render_task
    _summarize_for_index = _brs.summarize_for_index
    _render_index  = _brs.render_index
    _HAS_BRS = True
else:
    _HAS_BRS = False
    _parse_task = None
    _render_task = None

from Builder.stage import (
    AgenticGraph,
    LLMCallStage,
    PostprocessingStage,
    PreprocessingStage,
    ToolCallStage,
)
from Visualizer.visualizer import AgenticGraphVisualizer
from base import AgenticGraphConverter
from prompt_extractor import PromptExtractor
from tokenizer_utils import count_prompt_tokens, count_tokens, convert_json_to_csv

# ── globals ───────────────────────────────────────────────────────────────────
prompt_extractor = PromptExtractor()

DEFAULT_BASE = "/home/ivohra6/benchmarks/webtactix/record/webarena"


# ── helpers ───────────────────────────────────────────────────────────────────

def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _fmt_duration(seconds: Any) -> str:
    """Return duration as a string like '15.890s', empty if unavailable."""
    try:
        return f"{float(seconds):.3f}s"
    except (TypeError, ValueError):
        return ""


def _v_id_from_file(filename: str) -> str:
    """Extract 'v1' from 'plan_v1.json'."""
    m = re.search(r"plan_(v\d+)\.json", filename)
    return m.group(1) if m else "unknown"


def _exec_stats(exec_durations: List[Dict[str, Any]]):
    """Return (count, avg, min, max) for the completed exec actions."""
    dvals = [
        _safe_float(d["duration_s"])
        for d in exec_durations
        if d.get("duration_s") is not None
    ]
    if not dvals:
        return 0, 0.0, 0.0, 0.0
    return len(dvals), sum(dvals) / len(dvals), min(dvals), max(dvals)


# ── core parser ───────────────────────────────────────────────────────────────

def parse_webtactix_record(task_dir: Path) -> AgenticGraph:
    """
    Parse a WebTactix record task directory into an AgenticGraph.

    Args:
        task_dir: Path to task_XXX/ directory containing meta.json,
                  task.json, final.json, round_*/ subdirectories.

    Returns:
        AgenticGraph with the same stage structure as the HTML injector.
    """
    if not _HAS_BRS:
        raise RuntimeError(
            f"build_record_site.py not found at {_BUILD_SITE}. "
            "Cannot parse task directory without it."
        )

    task_run = _parse_task(task_dir)

    task_json  = task_run.get("task",  {}) or {}
    final_json = task_run.get("final", {}) or {}
    rounds     = task_run.get("rounds", []) or []

    # task_spec is either {"task": {TaskSpec}, "constraints": [...]}
    # or directly a flat TaskSpec dict
    task_spec   = task_json.get("task", {}) if isinstance(task_json.get("task"), dict) else task_json
    constraints = task_json.get("constraints", []) if isinstance(task_json.get("constraints"), list) else []

    task_id_val = str(task_spec.get("task_id", "") or task_dir.name)
    intent      = str(task_spec.get("intent", "") or "")

    graph = AgenticGraph(
        name=f"WebTactix Record - {task_dir.name}",
        description="Agentic workflow trace from record JSON files",
    )

    # ── 1. Task Input ─────────────────────────────────────────────────────────
    task_stage = PreprocessingStage(
        id="task_input",
        name="Task Input",
        description=intent[:100] + ("..." if len(intent) > 100 else ""),
        operations=["intent"],
        metadata={"full_task": intent, "task_id": task_id_val},
    )
    graph.add_stage(task_stage)

    # ── 2. Constraint Agent ───────────────────────────────────────────────────
    constraints_list  = []
    constraints_texts = []
    for c in constraints:
        if not isinstance(c, dict):
            continue
        kind = str(c.get("kind", "") or "")
        text = str(c.get("text", "") or "")
        constraints_list.append({"kind": kind, "text": text})
        constraints_texts.append(f"{kind}: {text}")

    constraint_desc   = "; ".join(constraints_texts) if constraints_texts else "Process task constraints"
    constraint_output = json.dumps(constraints_list, indent=2) if constraints_list else "{}"

    sys_p_c, usr_p_c = prompt_extractor.get_constraint_prompts(intent)
    in_len_c = count_prompt_tokens(sys_p_c, usr_p_c) + count_tokens(intent)

    constraint_stage = LLMCallStage(
        id="constraint_agent",
        name="Constraint Agent",
        description=constraint_desc[:100] + ("..." if len(constraint_desc) > 100 else ""),
        call_type="constraint_processing",
        system_prompt=sys_p_c,
        user_prompt=usr_p_c,
        input_len=in_len_c,
        output_text=constraint_output,
        model="deepseek",
        metadata={"constraints": constraints_texts},
    )
    graph.add_stage(constraint_stage)
    graph.connect("task_input", "constraint_agent")

    prev_id = "constraint_agent"

    # ── 3. Rounds ─────────────────────────────────────────────────────────────
    for r in rounds:
        rj      = r.get("round_json", {}) or {}
        r_num   = int(rj.get("round", 0) or 0)
        r_str   = f"{r_num:03d}"
        r_pfx   = f"r{r_str}"
        rt      = str(r.get("round_type", "plan_only") or "plan_only")

        frontier_raw = rj.get("frontier", [])
        frontier_val = json.dumps(frontier_raw) if isinstance(frontier_raw, list) else str(frontier_raw)

        # ── Round 000: initial snapshot only ─────────────────────────────────
        if r_num == 0:
            prep_id = f"{r_pfx}_preprocessing"
            graph.add_stage(PreprocessingStage(
                id=prep_id,
                name="Round 000: Initial State",
                description="Capture snapshot and accessibility tree",
                operations=["snapshot_capture", "accessibility_tree_extraction"],
            ))
            graph.connect(prev_id, prep_id)
            prev_id = prep_id
            continue

        # ── Round N (≥1): full Planner → Decision → Execute flow ─────────────

        # 3a. Round prep (state extraction)
        prep_id = f"{r_pfx}_prep"
        graph.add_stage(PreprocessingStage(
            id=prep_id,
            name=f"Round {r_str}: State",
            description=f"Frontier: {frontier_val[:60]}...",
            operations=["current state and parent extraction", "last 10 actions tried (history)"],
            metadata={"frontier": frontier_val},
        ))
        graph.connect(prev_id, prep_id)

        # 3b. Parallel planning stages
        plans        = r.get("plans", []) or []
        plan_node_ids: List[str] = []

        for pl in plans:
            if not isinstance(pl, dict):
                continue

            v_id   = _v_id_from_file(str(pl.get("_file", "") or ""))
            usage  = pl.get("usage", {}) or {}
            result = pl.get("result", {}) or {}
            dur    = _fmt_duration(pl.get("duration"))
            model  = str(usage.get("model", "deepseek") or "deepseek")

            plans_list = result.get("plans", []) if isinstance(result.get("plans"), list) else []
            goal       = str(plans_list[0].get("goal", "") if plans_list else "")
            planner_output = {
                "page_summary":      str(result.get("page_summary",      "") or ""),
                "progress_analysis": str(result.get("progress_analysis", "") or ""),
                "plans":             plans_list,
            }

            # constraints string for user prompt (mirrors HTML injector)
            constraints_str = ""
            if constraints_list:
                constraints_str = (
                    "Constraints:\n"
                    + "\n".join(f"- [{c['kind']}] {c['text']}" for c in constraints_list)
                    + "\n\n"
                )

            sys_p_pl, usr_p_pl_tmpl = prompt_extractor.get_planner_prompts(intent)
            usr_p_pl = usr_p_pl_tmpl + "\n" + constraints_str + f"Goal: {goal}"
            in_len_pl = count_prompt_tokens(sys_p_pl, usr_p_pl)

            plan_stage_id = f"{r_pfx}_plan_{v_id}"
            graph.add_stage(LLMCallStage(
                id=plan_stage_id,
                name=f"Plan {v_id}",
                description=f"{goal[:80]}{'...' if len(goal) > 80 else ''}",
                system_prompt=sys_p_pl,
                user_prompt=usr_p_pl,
                input_len=in_len_pl,
                output_text=json.dumps(planner_output, ensure_ascii=True),
                latency=dur,
                metadata={"v_id": v_id, "full_goal": goal},
                model=model,
            ))
            graph.connect(prep_id, plan_stage_id)
            plan_node_ids.append(plan_stage_id)

        # 3c. Postprocess (synthesise all plans)
        postprocess_id: Optional[str] = None
        if plan_node_ids:
            postprocess_id = f"{r_pfx}_postprocess"
            graph.add_stage(PostprocessingStage(
                id=postprocess_id,
                name="Postprocess Plans",
                operations=["plan_parsing", "action_filter_and_translate", "creates_page_summary"],
            ))
            for pid in plan_node_ids:
                graph.connect(pid, postprocess_id)

        # 3d. Decision (prep → LLM → post)
        decision     = r.get("decision") or {}
        dec_result   = decision.get("result", {}) or {} if isinstance(decision.get("result"), dict) else {}
        dec_kind     = str(dec_result.get("kind",     "") or "unknown")
        dec_selected = str(dec_result.get("selected", "") or "None")
        dec_reason   = str(dec_result.get("reason",   "") or "")
        dec_dur      = _fmt_duration(decision.get("duration"))

        # 3d-i. Decision prep
        dec_prep_id = f"{r_pfx}_decision_prep"
        if dec_kind == "select_and_execute":
            prep_ops  = ["validates plans", "early exit if only one valid path"]
            prep_desc = "Prepare plans and context for decision agent"
        elif dec_kind == "reflect_and_replan":
            prep_ops  = ["summary of failed candidates", "progress analysis"]
            prep_desc = "Analyze failed attempts and prepare for replanning"
        else:
            prep_ops  = ["gather_context"]
            prep_desc = "Prepare context for decision"

        graph.add_stage(PreprocessingStage(
            id=dec_prep_id,
            name="Decision: Preprocess",
            description=prep_desc,
            operations=prep_ops,
        ))
        graph.connect(postprocess_id if postprocess_id else prep_id, dec_prep_id)

        # 3d-ii. Decision LLM
        dec_llm_id = f"{r_pfx}_decision_llm"
        sys_p_d, usr_p_d_tmpl = prompt_extractor.get_decision_prompts(dec_kind)
        usr_p_d = usr_p_d_tmpl + (f"\nReason: {dec_reason}" if dec_reason else "")
        in_len_d = count_prompt_tokens(sys_p_d, usr_p_d)

        dec_output = {
            "decision_type": dec_kind,
            "selected":      dec_selected,
            "reason":        dec_reason,
            "duration":      dec_dur,
        }
        graph.add_stage(LLMCallStage(
            id=dec_llm_id,
            name=f"Decision: {dec_kind}",
            description=(
                f"Selected: {dec_selected} | "
                f"{dec_reason[:60]}{'...' if len(dec_reason) > 60 else ''}"
            ),
            call_type=dec_kind,
            system_prompt=sys_p_d,
            user_prompt=usr_p_d,
            input_len=in_len_d,
            output_text=json.dumps(dec_output, indent=2),
            latency=dec_dur,
            model="deepseek",
            metadata={
                "decision_type": dec_kind,
                "selected":      dec_selected,
                "reason":        dec_reason,
            },
        ))
        graph.connect(dec_prep_id, dec_llm_id)

        # 3d-iii. Decision post
        dec_post_id = f"{r_pfx}_decision_post"
        if dec_kind == "select_and_execute":
            post_ops  = ["pushes other nodes to queue", "calls executor for selected action"]
            post_desc = f"Extract selected node: {dec_selected}"
        elif dec_kind == "reflect_and_replan":
            post_ops  = ["check priority queue", "call executor"]
            post_desc = "Process priority queue and execute"
        else:
            post_ops  = ["process_output"]
            post_desc = "Process decision output"

        graph.add_stage(PostprocessingStage(
            id=dec_post_id,
            name="Decision: Postprocess",
            description=post_desc,
            operations=post_ops,
        ))
        graph.connect(dec_llm_id, dec_post_id)

        # 3e. Execute / Data-extraction
        exec_durations = r.get("exec_durations", []) or []
        data_runs      = r.get("data_extraction", []) or []

        action_executed = False

        if rt == "web_operation" and exec_durations:
            # Take first completed action for name / description
            first = exec_durations[0]
            src   = str(first.get("src",        "") or "")
            dst   = str(first.get("dst",        "") or "")
            sig   = str(first.get("action_sig", "") or "")

            cnt, avg, mn, mx = _exec_stats(exec_durations)
            dur_str = (
                f"derived exec durations: count {cnt} | "
                f"avg {avg:.3f}s | min {mn:.3f}s | max {mx:.3f}s"
            ) if cnt else ""

            tool_id = f"{r_pfx}_execute"
            graph.add_stage(ToolCallStage(
                id=tool_id,
                name=f"Execute: {src}→{dst}",
                description=sig[:100],
                tool_name="browser_automation",
                action="exec_ok",
                metadata={
                    "src": src, "dst": dst,
                    "signature": sig,
                    "derived_exec_durations": dur_str,
                },
                avg_latency=avg,
                min_latency=mn,
                max_latency=mx,
                actions_count=cnt,
            ))
            graph.connect(dec_post_id, tool_id)
            prev_id = tool_id
            action_executed = True

        elif rt == "data_extraction" and data_runs:
            # data_extraction_ok exec action (browser navigation)
            if exec_durations:
                first = exec_durations[0]
                src   = str(first.get("src",        "") or "")
                dst   = str(first.get("dst",        "") or "")
                sig   = str(first.get("action_sig", "") or "data_extraction")
            else:
                first_node = data_runs[0]
                begin_j    = first_node.get("begin", {}) or {}
                src        = str(begin_j.get("round",   r_str))
                dst        = str(begin_j.get("node_id", ""))
                sig        = "data_extraction_ok"

            cnt, avg, mn, mx = _exec_stats(exec_durations)

            exec_tool_id = f"{r_pfx}_execute"
            graph.add_stage(ToolCallStage(
                id=exec_tool_id,
                name=f"Execute: {src}→{dst}",
                description=sig[:100],
                tool_name="browser_automation",
                action="data_extraction_ok",
                metadata={"src": src, "dst": dst, "signature": sig},
                avg_latency=avg,
                min_latency=mn,
                max_latency=mx,
                actions_count=max(cnt, len(data_runs)),
            ))
            graph.connect(dec_post_id, exec_tool_id)

            # Data extraction LLM (turns inside node_XXX/turns.jsonl)
            all_turns: List[Dict[str, Any]] = []
            for dn in data_runs:
                turns = dn.get("turns", []) or []
                all_turns.extend([t for t in turns if isinstance(t, dict)])

            sys_p_de, usr_p_de = prompt_extractor.get_data_extraction_prompts()
            in_len_de = count_prompt_tokens(sys_p_de, usr_p_de)

            extract_id = f"{r_pfx}_data_extraction"
            graph.add_stage(LLMCallStage(
                id=extract_id,
                name="Data Extraction",
                description="Extract and structure information from page",
                call_type="data_extraction",
                system_prompt=sys_p_de,
                user_prompt=usr_p_de,
                input_len=in_len_de,
                model="deepseek",
                metadata={"num_nodes": len(data_runs), "num_turns": len(all_turns)},
            ))
            graph.connect(exec_tool_id, extract_id)
            prev_id = extract_id
            action_executed = True

        if not action_executed:
            prev_id = dec_post_id

    # ── 4. Summary ────────────────────────────────────────────────────────────
    status       = str(final_json.get("status",  "") or "")
    answer       = str(final_json.get("answer",  "") or "N/A")
    reason       = str(final_json.get("reason",  "") or "")
    eval_result  = final_json.get("eval_result", {})
    eval_ok      = eval_result.get("ok",    None)  if isinstance(eval_result, dict) else eval_result
    eval_score   = eval_result.get("score", None)  if isinstance(eval_result, dict) else None
    summary_j    = final_json.get("summary", {}) or {}
    total_rounds = summary_j.get("total_rounds", len(rounds))
    t_end        = final_json.get("t_end", None)

    graph.add_stage(PostprocessingStage(
        id="summary",
        name="output",
        description=f"Answer: {answer} | Eval: {eval_ok} | Rounds: {total_rounds}",
        operations=["result_aggregation", "summary_generation"],
        metadata={
            "status":       status,
            "answer":       answer,
            "reason":       reason,
            "eval":         str(eval_ok),
            "eval_score":   eval_score,
            "total_rounds": total_rounds,
            "t_end":        t_end,
        },
    ))
    graph.connect(prev_id, "summary")

    return graph


# ── load helper ───────────────────────────────────────────────────────────────

def load_single_graph_from_record(
    base_directory: str,
    task_name: str,
    *,
    model: str = "",
    emit_html: bool = True,
    dataset: str = "",
) -> Optional[AgenticGraph]:
    """
    Load and parse a single record task directory by name.

    Args:
        base_directory: Base record directory (e.g. /…/record/webarena or /…/record/webarena/<model>)
        task_name:      Directory name, e.g. 'task_410'
        model:          Optional model sub-folder name (e.g. 'vllm_sudo').
                        If provided, resolves to <base_directory>/<model>/<task_name>.
                        If empty, resolves to <base_directory>/<task_name>.
        emit_html:      If True, write task_<id>.html alongside _dump.json for verification.
        dataset:        Dataset label used when rendering HTML (default: inferred from path).

    Returns:
        AgenticGraph or None on failure.
    """
    base_path = Path(base_directory)
    task_dir  = (base_path / model / task_name) if model else (base_path / task_name)

    if not task_dir.exists() or not task_dir.is_dir():
        print(f"[FAIL] Task directory not found: {task_dir}")
        return None

    print(f"[load] {task_dir}")

    try:
        graph = parse_webtactix_record(task_dir)
    except Exception as exc:
        print(f"[FAIL] parse error: {exc}")
        return None

    # ── write _dump.json ──────────────────────────────────────────────────────
    json_path = task_dir / f"{task_name}_dump.json"
    json_data = AgenticGraphConverter.to_json(graph)
    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump(json_data, fh, indent=2)
    print(f"[OK]   wrote JSON dump  → {json_path}")

    # ── optionally emit HTML (parallel verification) ──────────────────────────
    if emit_html and _HAS_BRS and _render_task is not None:
        try:
            task_run  = _parse_task(task_dir)
            task_json = task_run.get("task", {}) or {}
            task_spec = task_json.get("task", {}) if isinstance(task_json.get("task"), dict) else task_json
            tid       = task_spec.get("task_id", None) or task_dir.name.replace("task_", "")

            _ds    = dataset or (base_path.parent.name if model else base_path.name)
            _model = model or base_path.name

            html_text = _render_task(task_run, dataset=_ds, model=_model, out_dir=task_dir)
            html_path = task_dir / f"task_{tid}.html"
            html_path.write_text(html_text, encoding="utf-8")
            print(f"[OK]   wrote HTML verify → {html_path}")
        except Exception as exc:
            print(f"[WARN] HTML generation failed: {exc}")

    print(f"[OK]   loaded {task_name}")
    return graph


# ── CLI / visualiser entry point ──────────────────────────────────────────────

def main() -> None:
    import argparse

    ap = argparse.ArgumentParser(
        description="JSON-based WebTactix record injector"
    )
    ap.add_argument(
        "base_dir",
        nargs="?",
        default=DEFAULT_BASE,
        help=f"Base record directory (default: {DEFAULT_BASE})",
    )
    ap.add_argument(
        "--model",
        default="",
        help="Model sub-directory under base_dir (e.g. vllm_sudo)",
    )
    ap.add_argument(
        "--task",
        default="",
        help="If set, parse only this task and dump JSON+HTML without launching the visualiser",
    )
    ap.add_argument(
        "--no-html",
        action="store_true",
        help="Skip parallel HTML generation",
    )
    args = ap.parse_args()

    base_dir     = args.base_dir
    model        = args.model
    emit_html    = not args.no_html

    # ── one-shot: dump a single task and exit ─────────────────────────────────
    if args.task:
        load_single_graph_from_record(
            base_dir,
            args.task,
            model=model,
            emit_html=emit_html,
        )
        return

    # ── interactive visualiser ────────────────────────────────────────────────
    active_base = str(Path(base_dir) / model) if model else base_dir

    if not Path(active_base).is_dir():
        print(f"[ERROR] Directory not found: {active_base}")
        sys.exit(1)

    print(f"[record injector] base  : {active_base}")
    print(f"[record injector] model : {model or '(none)'}")
    print(f"[record injector] type a task name (e.g. task_410) in the visualiser to load.\n")

    def _loader(base: str, name: str) -> Optional[AgenticGraph]:
        return load_single_graph_from_record(base, name, model="", emit_html=emit_html)

    viz = AgenticGraphVisualizer(
        base_directory=active_base,
        loader_fn=_loader,
    )
    viz.run()


if __name__ == "__main__":
    main()
