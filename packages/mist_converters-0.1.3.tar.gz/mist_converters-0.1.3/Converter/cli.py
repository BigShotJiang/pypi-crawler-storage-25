#!/usr/bin/env python3
import argparse
import json
import sys
from pathlib import Path

from Converter.dir_claude_code_parser import build_graphs_from_directory

_OUTPUT_ROOT = Path("claude_code/output")


def _process_project(directory: Path) -> None:
    out_dir = _OUTPUT_ROOT / directory.name
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"\nProcessing: {directory}")
    graphs = build_graphs_from_directory(directory)
    if not graphs:
        print(f"  No graphs produced for {directory.name}", file=sys.stderr)
        return

    for graph in graphs:
        session_tag = (
            graph.name.split("[")[-1].rstrip("]").strip()
            if "[" in graph.name
            else directory.name
        )
        out_path = out_dir / f"{session_tag}.json"
        out_data = {
            "name": graph.name,
            "description": graph.description,
            "stages": [stage.get_display_info() for stage in graph.stages.values()],
            "edges": [{"from": f, "to": t} for f, t in graph.edges],
        }
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(out_data, fh, indent=2)
        print(f"  Saved → {out_path}  ({len(graph.stages)} stages, {len(graph.edges)} edges)")


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Convert Claude Code session logs to AgenticGraph JSON.\n\n"
                    "Processes every project subdirectory under a .claude/projects path, "
                    "or a single project directory when --dir is given.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument(
        "projects_dir",
        nargs="?",
        default=None,
        help="Path to .claude/projects directory (default: ~/.claude/projects). "
             "Each subdirectory is treated as one project.",
    )
    ap.add_argument(
        "--dir",
        default=None,
        metavar="PROJECT_DIR",
        help="Process a single project directory instead of all projects.",
    )
    args = ap.parse_args()

    if args.dir:
        single = Path(args.dir).expanduser().resolve()
        if not single.exists():
            print(f"Error: directory does not exist: {single}", file=sys.stderr)
            sys.exit(1)
        _process_project(single)
    else:
        projects_dir = (
            Path(args.projects_dir).expanduser().resolve()
            if args.projects_dir
            else Path.home() / ".claude" / "projects"
        )
        if not projects_dir.exists():
            print(f"Error: directory does not exist: {projects_dir}", file=sys.stderr)
            sys.exit(1)
        subdirs = sorted(d for d in projects_dir.iterdir() if d.is_dir())
        if not subdirs:
            print(f"No project subdirectories found in {projects_dir}", file=sys.stderr)
            sys.exit(1)
        for d in subdirs:
            _process_project(d)

    output_path = Path.cwd() / "claude_code" / "output"
    print(f"\nDone. Output written to: {output_path}")
    print(f"Please send us this path: {output_path}")


if __name__ == "__main__":
    main()
