import json
from unittest.mock import patch, MagicMock
from django.test import TestCase
from django_email_builder.client import MailCraftClient


def _mock_response(status=200, data=None):
    """Create a mock urllib response."""
    resp = MagicMock()
    resp.status = status
    resp.read.return_value = json.dumps(data or {}).encode()
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


class ClientRenderTests(TestCase):
    @patch('django_email_builder.client.urlopen')
    def test_render_returns_html(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(200, {
            'html': '<table>Hello John</table>',
            'warnings': [],
            'variables_used': ['first_name'],
        })
        client = MailCraftClient('mc_test_key', 'https://example.com')
        html = client.render({'version': 1}, {'first_name': 'John'})
        self.assertEqual(html, '<table>Hello John</table>')

        call_args = mock_urlopen.call_args
        request = call_args[0][0]
        body = json.loads(request.data)
        self.assertEqual(body['variables'], {'first_name': 'John'})
        self.assertIn('json_data', body)
