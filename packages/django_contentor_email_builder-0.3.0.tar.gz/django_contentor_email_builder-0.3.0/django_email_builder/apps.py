from django.apps import AppConfig


class DjangoEmailBuilderConfig(AppConfig):
    name = 'django_email_builder'
    default_auto_field = 'django.db.models.BigAutoField'
    verbose_name = 'Email Builder'
