import json
from urllib.request import Request, urlopen


class MailCraftClient:
    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')

    def _request(self, method: str, path: str, data: dict | None = None) -> dict:
        url = f'{self.base_url}/api/v1{path}'
        body = json.dumps(data).encode() if data else None
        req = Request(url, data=body, method=method)
        req.add_header('X-API-Key', self.api_key)
        req.add_header('Content-Type', 'application/json')

        with urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())

    def render(self, template_json: dict, variables: dict) -> str:
        """POST /api/v1/render — returns rendered HTML string."""
        result = self._request('POST', '/render', {
            'json_data': template_json,
            'variables': variables,
        })
        return result['html']
