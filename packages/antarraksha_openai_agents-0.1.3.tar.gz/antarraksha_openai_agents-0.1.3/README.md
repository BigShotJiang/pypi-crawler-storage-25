# antarraksha-openai-agents

Antarraksha AI Agent Enforcement SDK for the OpenAI Agents SDK.

## Installation

```bash
pip install antarraksha-openai-agents
```

## Quick Start

Attach Antarraksha as input and output guardrails on your Agent. Registration happens automatically on first use — no login, no API key, no signup required.

```python
from agents import Agent
from antarraksha_openai_agents import (
    AntarrakshaInputGuardrail,
    AntarrakshaOutputGuardrail,
)

input_guard = AntarrakshaInputGuardrail(agent_id="my-openai-agent")
output_guard = AntarrakshaOutputGuardrail(agent_id="my-openai-agent")

agent = Agent(
    name="my-openai-agent",
    instructions="You are a helpful assistant.",
    input_guardrails=[input_guard],
    output_guardrails=[output_guard],
)
```

Run your agent normally — every input and output is now enforced against Antarraksha policy.

## Parameters

| Parameter | Default | Description |
|---|---|---|
| `agent_id` | `None` | Unique identifier for your agent. Triggers auto-registration on first use. |
| `base_url` | `"https://antarraksha.ai"` | Antarraksha endpoint. Override for self-hosted / dev. |
| `passport_id` | `None` | Optional pre-issued passport ID (e.g. `ANTK-PASS-xxx`). |
| `sdk_key` | `None` | Optional pre-issued SDK key. If omitted and `agent_id` is set, the SDK auto-registers and obtains one. |
| `fail_closed` | `True` | If `True`, deny on enforcement-server unreachable. Set `False` for fail-open during early integration. |

## Enforcement Behavior

- **Input guardrail** fires before the LLM receives the user prompt. Antarraksha can DENY (raises `PermissionError`) or ALLOW.
- **Output guardrail** fires after the LLM produces output. Antarraksha can DENY (raises `PermissionError`) or ALLOW.
- Every call is logged in your Antarraksha registry and visible at `https://antarraksha.ai/registry`.

## Corporate Network Note

If you're behind a corporate TLS-inspection proxy and see `SSLCertVerificationError`, install:

```bash
pip install pip-system-certs
```

This makes Python trust your Windows / macOS system certificate store.
