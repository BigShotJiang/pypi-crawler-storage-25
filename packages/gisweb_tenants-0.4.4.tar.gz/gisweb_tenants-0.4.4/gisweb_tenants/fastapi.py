# fastapi.py
import logging
from typing import Literal

from fastapi import HTTPException
from fastapi.requests import Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import DBAPIError, OperationalError, ProgrammingError, StatementError
from starlette.middleware.base import BaseHTTPMiddleware

from .internal_token import (
    InternalTokenClaims,
    InvalidInternalTokenError,
    MissingInternalTokenError,
    decode_internal_token,
)

log = logging.getLogger(__name__)


# =========================================================
# Helpers
# =========================================================

def _extract_token(raw: str | None) -> str | None:
    """
    Estrae il token dall'header in modo flessibile:
    - "Bearer <token>"  → restituisce <token>
    - "<token>"         → restituisce <token> direttamente
    - None / ""         → restituisce None
    """
    if not raw or not raw.strip():
        return None
    parts = raw.strip().split(" ", 1)
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1].strip() or None
    return parts[0].strip() or None


# =========================================================
# Database error middleware
# =========================================================

async def database_error_middleware(request: Request, call_next):
    try:
        return await call_next(request)

    except OperationalError:
        log.exception("DB OperationalError on %s %s", request.method, request.url)
        return JSONResponse(
            status_code=503,
            content={"detail": "Database non disponibile"},
        )

    except ProgrammingError:
        log.exception("DB ProgrammingError on %s %s", request.method, request.url)
        return JSONResponse(
            status_code=500,
            content={"detail": "Errore interno del server"},
        )

    except DBAPIError:
        log.exception("DB DBAPIError on %s %s", request.method, request.url)
        return JSONResponse(
            status_code=503,
            content={"detail": "Errore database"},
        )

    except StatementError:
        log.exception("DB StatementError on %s %s", request.method, request.url)
        return JSONResponse(
            status_code=500,
            content={"detail": "Errore interno del server"},
        )


# =========================================================
# Internal audit middleware
# =========================================================

class InternalAuditMiddleware(BaseHTTPMiddleware):
    """
    Middleware di audit per i microservizi interni.
    Legge il token interno dall'header configurato, lo decodifica
    per estrarre le info utente e le logga su ogni request.
    Non blocca mai la richiesta — la protezione delle route
    è delegata a make_internal_auth_dependency.

    Uso in main.py del microservizio:

        from gisweb_tenants import InternalAuditMiddleware

        app.add_middleware(
            InternalAuditMiddleware,
            audience=settings.db_app_name_prefix,
            secret=settings.internal_token_secret.get_secret_value(),
            header_name=settings.internal_service_token_header,
        )
    """

    def __init__(
        self,
        app,
        *,
        audience: str,
        secret: str,
        header_name: str = "Authorization",
        issuer: str = "fastapi-bff",
        algorithm: Literal["HS256", "HS384", "HS512"] = "HS256",
        leeway_seconds: int = 5,
    ):
        super().__init__(app)
        self.audience = audience
        self.secret = secret
        self.header_name = header_name
        self.issuer = issuer
        self.algorithm = algorithm
        self.leeway_seconds = leeway_seconds

    async def dispatch(self, request: Request, call_next):
        correlation_id = request.headers.get("x-correlation-id")
        user: InternalTokenClaims | None = None

        try:
            raw = request.headers.get(self.header_name)
            token = _extract_token(raw)
            if token:
                user = decode_internal_token(
                    token,
                    secret=self.secret,
                    expected_audience=self.audience,
                    expected_issuer=self.issuer,
                    algorithm=self.algorithm,
                    leeway_seconds=self.leeway_seconds,
                )
        except Exception:
            pass  # non blocca — lascia decidere agli endpoint

        log.info(
            "service_request",
            extra={
                "correlation_id": correlation_id,
                "path": request.url.path,
                "method": request.method,
                "tenant": user.tenant if user else None,
                "sub": user.sub if user else None,
                "username": user.username if user else None,
                "groups": user.groups if user else None,
                "jti": user.jti if user else None,
            },
        )

        return await call_next(request)


# =========================================================
# Internal auth dependency factory
# =========================================================

def make_internal_auth_dependency(
    *,
    secret: str,
    audience: str,
    header_name: str = "Authorization",
    issuer: str = "fastapi-bff",
    algorithm: Literal["HS256", "HS384", "HS512"] = "HS256",
    leeway_seconds: int = 5,
    require_groups: list[str] | None = None,
    require_roles: list[str] | None = None,
):
    """
    Factory che restituisce una dependency FastAPI per verificare
    il token interno emesso dal BFF.

    Uso tipico nel microservizio:

        get_current_user = make_internal_auth_dependency(
            secret=settings.internal_token_secret,
            audience="nome-microservizio",
            header_name=settings.internal_service_token_header,
        )

        get_admin_user = make_internal_auth_dependency(
            secret=settings.internal_token_secret,
            audience="nome-microservizio",
            header_name=settings.internal_service_token_header,
            require_roles=["superuser"],
        )

        @router.get("/risorsa")
        async def risorsa(user: InternalTokenClaims = Depends(get_current_user)):
            ...

        @router.get("/admin")
        async def admin(user: InternalTokenClaims = Depends(get_admin_user)):
            ...
    """

    async def _dependency(request: Request) -> InternalTokenClaims:
        raw = request.headers.get(header_name)
        token = _extract_token(raw)

        try:
            if not token:
                raise MissingInternalTokenError("missing_token")

            claims = decode_internal_token(
                token,
                secret=secret,
                expected_audience=audience,
                expected_issuer=issuer,
                algorithm=algorithm,
                leeway_seconds=leeway_seconds,
            )
        except MissingInternalTokenError:
            raise HTTPException(status_code=401, detail="missing_token")
        except InvalidInternalTokenError as exc:
            raise HTTPException(status_code=401, detail=str(exc))

        if require_groups:
            if not any(g in claims.groups for g in require_groups):
                raise HTTPException(status_code=403, detail="insufficient_permissions")

        if require_roles:
            if not any(r in claims.roles for r in require_roles):
                raise HTTPException(status_code=403, detail="insufficient_permissions")

        return claims

    return _dependency
