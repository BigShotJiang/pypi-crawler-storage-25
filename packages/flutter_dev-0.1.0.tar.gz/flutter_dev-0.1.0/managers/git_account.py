#!/usr/bin/env python3
"""
Git Account Manager
Manage multiple GitHub accounts via `gh` CLI + git config.

Subcommands:
    fdev git                  Interactive menu
    fdev git status           Show current account + git config
    fdev git list             List all logged-in GitHub accounts
    fdev git switch [user]    Switch active GitHub account
    fdev git add              Login a new GitHub account (gh auth login)
    fdev git remove [user]    Logout a GitHub account
    fdev git config           Update git config user.name / user.email
"""

import re
import shutil
import subprocess
import sys

from common_utils import RED, GREEN, YELLOW, BLUE, MAGENTA, NC, CHECKMARK, CROSS


# ---------------------------------------------------------------------------
# gh CLI helpers
# ---------------------------------------------------------------------------

def _gh_installed():
    """Return True if `gh` CLI is available in PATH."""
    return shutil.which("gh") is not None


def _run_gh(args, capture=True, timeout=15):
    """
    Run a `gh` command and return CompletedProcess (or None on failure).
    When capture=False, stdout/stderr stream to the terminal (for interactive auth).
    """
    try:
        if capture:
            return subprocess.run(
                ["gh"] + args,
                capture_output=True,
                text=True,
                timeout=timeout,
                encoding="utf-8",
                errors="replace",
            )
        return subprocess.run(["gh"] + args, timeout=timeout)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def _parse_auth_status():
    """
    Parse `gh auth status` output and return a list of dicts:
        [{"user": "devsmaxcode", "active": True, "host": "github.com"}, ...]

    Returns empty list if `gh` not installed or no accounts logged in.
    """
    if not _gh_installed():
        return []

    result = _run_gh(["auth", "status"])
    if result is None or result.returncode != 0:
        return []

    text = result.stdout + "\n" + result.stderr
    accounts = []

    # Pattern: "Logged in to <host> account <user> (...)"
    # followed (within the same block) by "Active account: true/false"
    blocks = re.split(r"\n(?=\s*[✓\-]\s*Logged in to)", text)
    for block in blocks:
        match = re.search(
            r"Logged in to\s+(\S+)\s+account\s+(\S+)", block
        )
        if not match:
            continue
        host = match.group(1)
        user = match.group(2)
        active = bool(re.search(r"Active account:\s*true", block))
        accounts.append({"user": user, "host": host, "active": active})

    return accounts


def _active_account(accounts=None):
    """Return active account username or None."""
    accounts = accounts if accounts is not None else _parse_auth_status()
    for acc in accounts:
        if acc["active"]:
            return acc["user"]
    return None


# ---------------------------------------------------------------------------
# git config helpers
# ---------------------------------------------------------------------------

def _git_config_get(key, scope="global"):
    """Read a git config value. scope: 'global' | 'local' | None (auto)."""
    cmd = ["git", "config"]
    if scope == "global":
        cmd.append("--global")
    elif scope == "local":
        cmd.append("--local")
    cmd.append("--get")
    cmd.append(key)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return ""


def _git_config_set(key, value, scope="global"):
    """Set a git config value. Returns True on success."""
    cmd = ["git", "config"]
    if scope == "global":
        cmd.append("--global")
    elif scope == "local":
        cmd.append("--local")
    cmd.extend([key, value])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False


def _in_git_repo():
    """Check if current directory is inside a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=3,
        )
        return result.returncode == 0 and result.stdout.strip() == "true"
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def _print_header():
    print(f"\n{BLUE}🔐 GitHub Account Manager{NC}\n")


def _print_status_block(accounts):
    active = _active_account(accounts)
    name_global = _git_config_get("user.name", "global")
    email_global = _git_config_get("user.email", "global")

    print(f"  {BLUE}Active GH account:{NC} "
          f"{GREEN if active else RED}{active or 'none'}{NC}")
    print(f"  {BLUE}Git config (global):{NC} "
          f"{GREEN}{name_global or '(unset)'}{NC} "
          f"{YELLOW}<{email_global or '(unset)'}>{NC}")

    if _in_git_repo():
        name_local = _git_config_get("user.name", "local")
        email_local = _git_config_get("user.email", "local")
        if name_local or email_local:
            print(f"  {BLUE}Git config (local): {NC} "
                  f"{GREEN}{name_local or '(unset)'}{NC} "
                  f"{YELLOW}<{email_local or '(unset)'}>{NC}")
    print()


def _print_accounts(accounts):
    if not accounts:
        print(f"  {YELLOW}No GitHub accounts logged in.{NC}")
        print(f"  {BLUE}Run:{NC} {GREEN}fdev git add{NC} to login.\n")
        return
    print(f"  {YELLOW}Available accounts:{NC}")
    for i, acc in enumerate(accounts, 1):
        if acc["active"]:
            print(f"    {GREEN}{i}. {acc['user']} (active) {CHECKMARK}{NC}")
        else:
            print(f"    {BLUE}{i}. {acc['user']}{NC}")
    print()


# ---------------------------------------------------------------------------
# Pre-flight check
# ---------------------------------------------------------------------------

def _check_gh_or_exit():
    if not _gh_installed():
        print(f"\n{RED}{CROSS} `gh` CLI is not installed.{NC}")
        print(f"{YELLOW}Install with:{NC}")
        print(f"  macOS:   {GREEN}brew install gh{NC}")
        print(f"  Linux:   {GREEN}sudo apt install gh{NC}  "
              f"(or see https://cli.github.com){NC}")
        print(f"  Windows: {GREEN}scoop install gh{NC} or "
              f"{GREEN}winget install --id GitHub.cli{NC}\n")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Subcommand: status
# ---------------------------------------------------------------------------

def cmd_status():
    _check_gh_or_exit()
    _print_header()
    accounts = _parse_auth_status()
    _print_status_block(accounts)
    _print_accounts(accounts)


# ---------------------------------------------------------------------------
# Subcommand: list
# ---------------------------------------------------------------------------

def cmd_list():
    _check_gh_or_exit()
    accounts = _parse_auth_status()
    if not accounts:
        print(f"\n{YELLOW}  No GitHub accounts logged in.{NC}\n")
        return
    print(f"\n{BLUE}  Logged-in GitHub accounts:{NC}")
    for acc in accounts:
        marker = f"{GREEN}(active){NC}" if acc["active"] else ""
        print(f"    {acc['user']:<20} {acc['host']}  {marker}")
    print()


# ---------------------------------------------------------------------------
# Subcommand: switch
# ---------------------------------------------------------------------------

def cmd_switch(target=None):
    """Switch active GitHub account. Does NOT auto-update git config."""
    _check_gh_or_exit()
    accounts = _parse_auth_status()

    if not accounts:
        print(f"\n{YELLOW}  No accounts to switch. Run `fdev git add` first.{NC}\n")
        return

    if target is None:
        _print_header()
        _print_status_block(accounts)
        _print_accounts(accounts)
        try:
            choice = input(f"{MAGENTA}  Select account [1-{len(accounts)}]: {NC}").strip()
            if not choice:
                return
            idx = int(choice) - 1
            if not (0 <= idx < len(accounts)):
                print(f"\n{RED}  Invalid choice{NC}\n")
                return
            target = accounts[idx]["user"]
        except ValueError:
            print(f"\n{RED}  Invalid input{NC}\n")
            return
        except KeyboardInterrupt:
            print()
            return

    # Validate target
    if not any(acc["user"] == target for acc in accounts):
        print(f"\n{RED}  Account '{target}' is not logged in.{NC}")
        print(f"  {BLUE}Run:{NC} {GREEN}fdev git add{NC} to login first.\n")
        return

    current = _active_account(accounts)
    if current == target:
        print(f"\n{YELLOW}  Already on account: {GREEN}{target}{NC}\n")
        return

    print(f"\n  {BLUE}→ Switching to {GREEN}{target}{NC}...{NC}")
    result = _run_gh(["auth", "switch", "--user", target])
    if result is None or result.returncode != 0:
        err = (result.stderr.strip() if result else "unknown error")
        print(f"  {CROSS} gh auth switch failed: {RED}{err}{NC}\n")
        return
    print(f"  {CHECKMARK} gh auth switch --user {target}")

    setup = _run_gh(["auth", "setup-git"])
    if setup is not None and setup.returncode == 0:
        print(f"  {CHECKMARK} gh auth setup-git")
    else:
        print(f"  {YELLOW}!  gh auth setup-git skipped/failed{NC}")

    # Show current git config but DO NOT auto-update.
    name = _git_config_get("user.name", "global")
    email = _git_config_get("user.email", "global")
    print(f"\n  {BLUE}Current git config (global):{NC} "
          f"{GREEN}{name or '(unset)'}{NC} {YELLOW}<{email or '(unset)'}>{NC}")
    print(f"  {YELLOW}Note: Git config was NOT changed.{NC}")
    print(f"  {BLUE}Run:{NC} {GREEN}fdev git config{NC} "
          f"if you want to update name/email.\n")


# ---------------------------------------------------------------------------
# Subcommand: add (gh auth login)
# ---------------------------------------------------------------------------

def cmd_add():
    _check_gh_or_exit()
    print(f"\n{BLUE}  Launching `gh auth login` (interactive)...{NC}")
    print(f"  {YELLOW}Follow the prompts to add a new GitHub account.{NC}\n")
    result = _run_gh(["auth", "login"], capture=False, timeout=600)
    if result is not None and result.returncode == 0:
        print(f"\n  {CHECKMARK} {GREEN}Account added successfully{NC}\n")
    else:
        print(f"\n  {CROSS} {RED}gh auth login failed or cancelled{NC}\n")


# ---------------------------------------------------------------------------
# Subcommand: remove
# ---------------------------------------------------------------------------

def cmd_remove(target=None):
    _check_gh_or_exit()
    accounts = _parse_auth_status()

    if not accounts:
        print(f"\n{YELLOW}  No accounts to remove.{NC}\n")
        return

    if target is None:
        _print_header()
        _print_accounts(accounts)
        try:
            choice = input(f"{MAGENTA}  Select account to remove "
                           f"[1-{len(accounts)}]: {NC}").strip()
            if not choice:
                return
            idx = int(choice) - 1
            if not (0 <= idx < len(accounts)):
                print(f"\n{RED}  Invalid choice{NC}\n")
                return
            target = accounts[idx]["user"]
        except ValueError:
            print(f"\n{RED}  Invalid input{NC}\n")
            return
        except KeyboardInterrupt:
            print()
            return

    if not any(acc["user"] == target for acc in accounts):
        print(f"\n{RED}  Account '{target}' is not logged in.{NC}\n")
        return

    try:
        confirm = input(f"\n  {YELLOW}Logout {RED}{target}{YELLOW}? "
                        f"(y/N): {NC}").strip().lower()
    except KeyboardInterrupt:
        print()
        return

    if confirm != "y":
        print(f"  {BLUE}Cancelled.{NC}\n")
        return

    result = _run_gh(["auth", "logout", "--user", target, "--hostname", "github.com"])
    if result is not None and result.returncode == 0:
        print(f"  {CHECKMARK} {GREEN}Logged out: {target}{NC}\n")
    else:
        err = (result.stderr.strip() if result else "unknown error")
        print(f"  {CROSS} {RED}Logout failed: {err}{NC}\n")


# ---------------------------------------------------------------------------
# Subcommand: config (update git config user.name / user.email)
# ---------------------------------------------------------------------------

def cmd_config():
    print(f"\n{BLUE}  Update git config{NC}\n")

    # Pick scope
    has_local = _in_git_repo()
    default_scope = "g"
    scope_prompt = f"  {MAGENTA}Scope: [g]lobal"
    if has_local:
        scope_prompt += " / [l]ocal (current repo)"
    scope_prompt += f" [{default_scope}]: {NC}"

    try:
        scope_in = input(scope_prompt).strip().lower() or default_scope
    except KeyboardInterrupt:
        print()
        return

    if scope_in.startswith("l"):
        if not has_local:
            print(f"  {RED}Not inside a git repo — cannot set local config.{NC}\n")
            return
        scope = "local"
    else:
        scope = "global"

    cur_name = _git_config_get("user.name", scope)
    cur_email = _git_config_get("user.email", scope)

    print(f"\n  {BLUE}Current ({scope}):{NC}")
    print(f"    Name:  {GREEN}{cur_name or '(unset)'}{NC}")
    print(f"    Email: {GREEN}{cur_email or '(unset)'}{NC}\n")

    try:
        new_name = input(f"  {MAGENTA}New name  "
                         f"(empty = keep): {NC}").strip()
        new_email = input(f"  {MAGENTA}New email "
                          f"(empty = keep): {NC}").strip()
    except KeyboardInterrupt:
        print()
        return

    if not new_name and not new_email:
        print(f"\n  {YELLOW}Nothing changed.{NC}\n")
        return

    print()
    if new_name:
        if _git_config_set("user.name", new_name, scope):
            print(f"  {CHECKMARK} git config --{scope} user.name "
                  f"\"{new_name}\"")
        else:
            print(f"  {CROSS} {RED}Failed to set user.name{NC}")
    if new_email:
        if _git_config_set("user.email", new_email, scope):
            print(f"  {CHECKMARK} git config --{scope} user.email "
                  f"\"{new_email}\"")
        else:
            print(f"  {CROSS} {RED}Failed to set user.email{NC}")
    print()


# ---------------------------------------------------------------------------
# Subcommand: help
# ---------------------------------------------------------------------------

def cmd_help():
    print(f"\n{BLUE}fdev git — GitHub Account Manager{NC}\n")
    print(f"{YELLOW}Usage:{NC}")
    print(f"  {GREEN}fdev git{NC}                  Interactive menu")
    print(f"  {GREEN}fdev git status{NC}           Show active account + git config")
    print(f"  {GREEN}fdev git list{NC}             List logged-in accounts")
    print(f"  {GREEN}fdev git switch [user]{NC}    Switch active GitHub account")
    print(f"  {GREEN}fdev git add{NC}              Login a new account (gh auth login)")
    print(f"  {GREEN}fdev git remove [user]{NC}    Logout an account")
    print(f"  {GREEN}fdev git config{NC}           Update git user.name / user.email")
    print(f"\n{BLUE}Notes:{NC}")
    print(f"  {YELLOW}• Switching account does NOT change git user.name/email automatically.{NC}")
    print(f"  {YELLOW}• Use `fdev git config` to update name/email when you want.{NC}\n")


# ---------------------------------------------------------------------------
# Interactive menu (no subcommand)
# ---------------------------------------------------------------------------

def _interactive_menu():
    _check_gh_or_exit()
    while True:
        accounts = _parse_auth_status()
        _print_header()
        _print_status_block(accounts)
        _print_accounts(accounts)

        print(f"  {YELLOW}Actions:{NC}")
        if accounts:
            print(f"    {BLUE}[1-{len(accounts)}]{NC}  Switch to account")
        print(f"    {BLUE}[a]{NC}    Add new account (gh auth login)")
        if accounts:
            print(f"    {BLUE}[r]{NC}    Remove account")
        print(f"    {BLUE}[c]{NC}    Update git config (name/email)")
        print(f"    {BLUE}[s]{NC}    Refresh status")
        print(f"    {BLUE}[q]{NC}    Quit\n")

        try:
            choice = input(f"{MAGENTA}  Choice: {NC}").strip().lower()
        except (KeyboardInterrupt, EOFError):
            print()
            return

        if not choice or choice == "q":
            return
        if choice == "a":
            cmd_add()
            continue
        if choice == "r":
            cmd_remove()
            continue
        if choice == "c":
            cmd_config()
            continue
        if choice == "s":
            continue
        # Numeric choice → switch
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(accounts):
                cmd_switch(accounts[idx]["user"])
            else:
                print(f"\n  {RED}Invalid choice{NC}\n")
        except ValueError:
            print(f"\n  {RED}Invalid input{NC}\n")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def git_account_manager(args=None):
    """
    Main dispatcher for `fdev git ...`.
    `args` is the list of args after `git` (i.e. sys.argv[2:]).
    """
    args = args or []

    if not args:
        _interactive_menu()
        return

    sub = args[0].lower()
    rest = args[1:]

    if sub in ("status", "st"):
        cmd_status()
    elif sub in ("list", "ls"):
        cmd_list()
    elif sub == "switch":
        cmd_switch(rest[0] if rest else None)
    elif sub in ("add", "login"):
        cmd_add()
    elif sub in ("remove", "rm", "logout"):
        cmd_remove(rest[0] if rest else None)
    elif sub == "config":
        cmd_config()
    elif sub in ("help", "-h", "--help"):
        cmd_help()
    else:
        print(f"\n{RED}Unknown subcommand: {sub}{NC}")
        cmd_help()
        sys.exit(1)
