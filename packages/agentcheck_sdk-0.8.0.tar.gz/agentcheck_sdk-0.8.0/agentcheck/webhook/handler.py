from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from datetime import datetime

from ..exceptions import AgentCheckError


@dataclass
class WebhookEvent:
    id: str
    type: str
    created_at: str
    data: dict


class WebhookHandler:
    """Verify and parse incoming webhook events."""

    def __init__(self, secret: str):
        self._secret = secret

    def verify_and_parse(self, body: str | bytes, signature: str) -> WebhookEvent:
        """Verify HMAC signature and parse webhook payload.

        Args:
            body: Raw request body (str or bytes).
            signature: Value from X-AgentCheck-Signature header.

        Returns:
            Parsed WebhookEvent.

        Raises:
            AgentCheckError: If signature is invalid.
        """
        if isinstance(body, str):
            body_bytes = body.encode("utf-8")
        else:
            body_bytes = body

        expected = hmac.new(
            self._secret.encode("utf-8"),
            body_bytes,
            hashlib.sha256,
        ).hexdigest()

        if not hmac.compare_digest(expected, signature):
            raise AgentCheckError("Invalid webhook signature", code="invalid_signature")

        payload = json.loads(body_bytes)
        return WebhookEvent(
            id=payload["id"],
            type=payload["type"],
            created_at=payload["created_at"],
            data=payload.get("data", {}),
        )
