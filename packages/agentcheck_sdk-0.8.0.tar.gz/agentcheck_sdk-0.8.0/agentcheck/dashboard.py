"""DelegationDashboard - Embeddable HTML widget for agent delegation status."""

from __future__ import annotations

from .client import Client

DASHBOARD_CSS = """
.ac-dashboard{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;max-width:960px;margin:0 auto;padding:24px;}
.ac-title{font-size:20px;font-weight:700;margin:0 0 20px;color:#1e293b;}
.ac-cards{display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;}
.ac-card{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:16px 20px;min-width:100px;text-align:center;}
.ac-card-num{font-size:28px;font-weight:800;color:#1e293b;}
.ac-card-label{font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin-top:4px;}
.ac-table{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;border:1px solid #e5e7eb;}
.ac-table th{padding:10px 14px;text-align:left;font-size:12px;font-weight:700;color:#475569;background:#f8fafc;border-bottom:2px solid #e5e7eb;}
.ac-table td{padding:10px 14px;font-size:13px;color:#555;border-bottom:1px solid #f0f0f0;}
.ac-table a{color:#2563eb;font-size:12px;}
.ac-badge{display:inline-block;padding:2px 10px;border-radius:9999px;font-size:11px;font-weight:700;color:#fff;}
.ac-approved{background:#16a34a;}.ac-pending{background:#ca8a04;}.ac-revoked{background:#dc2626;}.ac-expired{background:#6b7280;}
.ac-footer{text-align:center;color:#94a3b8;font-size:12px;margin-top:16px;}
"""


class DelegationDashboard:
    """Embeddable HTML widget for agent delegation status.

    Generates self-contained HTML showing:
    - Active delegations with status badges
    - Quick verify links
    - Auto-refresh support

    Usage (FastAPI):
        @app.get("/admin/delegations")
        def delegations():
            return HTMLResponse(dashboard.render())

    Usage (embed):
        html = dashboard.render_widget()
        # Insert into your page template
    """

    def __init__(
        self,
        client: Client,
        title: str = "Agent Delegations",
        refresh_interval: int = 30,
        limit: int = 20,
    ):
        self._client = client
        self._title = title
        self._refresh = refresh_interval
        self._limit = limit

    def render(self) -> str:
        """Render full HTML page."""
        widget = self.render_widget()
        refresh = (
            f'<meta http-equiv="refresh" content="{self._refresh}">'
            if self._refresh > 0
            else ""
        )
        return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
{refresh}
<title>{self._title}</title>
</head><body>{widget}</body></html>"""

    def render_widget(self) -> str:
        """Render widget HTML for embedding."""
        records = self._client.list(limit=self._limit).records

        counts: dict[str, int] = {}
        for r in records:
            counts[r.status] = counts.get(r.status, 0) + 1

        cards = "\n".join(
            f'<div class="ac-card"><div class="ac-card-num">{c}</div>'
            f'<div class="ac-card-label">{s}</div></div>'
            for s, c in counts.items()
        )

        rows = "\n".join(
            f"""<tr>
            <td><span class="ac-badge ac-{r.status}">{r.status}</span></td>
            <td>{r.agent}</td>
            <td title="{r.scope}">{r.scope[:60]}{'...' if len(r.scope) > 60 else ''}</td>
            <td>{r.authorized_by}</td>
            <td>{r.created_at.strftime('%Y-%m-%d')}</td>
            <td><a href="{r.verify_url}" target="_blank">Verify</a></td>
            </tr>"""
            for r in records
        )

        refresh_text = (
            f"Auto-refresh: {self._refresh}s" if self._refresh > 0 else "Manual refresh"
        )

        return f"""<div class="ac-dashboard">
<h2 class="ac-title">{self._title}</h2>
<div class="ac-cards">{cards}</div>
<table class="ac-table">
<thead><tr><th>Status</th><th>Agent</th><th>Scope</th><th>Authorized by</th><th>Created</th><th>Verify</th></tr></thead>
<tbody>{rows}</tbody>
</table>
<div class="ac-footer">{len(records)} delegation(s) | {refresh_text}</div>
</div>
<style>{DASHBOARD_CSS}</style>"""
