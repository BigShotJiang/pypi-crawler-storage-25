"""Scope Engine - Structured scope verification.

Provides automatic action verification when scope is in structured JSON format.
If scope is free-text, customers verify themselves.
If scope is structured JSON, this engine verifies automatically.

Structured scope format:
{
    "allowed": ["action1", "action2"],       # Allowed actions (whitelist)
    "denied": ["action3"],                    # Denied actions (blacklist, overrides allowed)
    "limits": {                               # Per-action limits
        "action1": {
            "max_amount": 10000,
            "currency": "USD",
            "max_count_per_day": 50
        }
    },
    "schedule": {                             # Time-based restrictions
        "timezone": "UTC",
        "allowed_hours": [9, 17],             # 9am-5pm only
        "allowed_days": [1, 2, 3, 4, 5]      # Monday-Friday only
    },
    "require_approval_above": {               # Escalation thresholds
        "amount": 5000
    }
}
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass
class VerificationResult:
    allowed: bool
    reason: str
    details: dict[str, Any] | None = None


class ScopeEngine:
    """Verify actions against structured scope definitions.

    Usage:
        engine = ScopeEngine()

        # Parse scope (auto-detects structured vs free-text)
        scope = engine.parse('{"allowed":["read","write"],"denied":["delete"]}')

        # Verify action
        result = engine.verify(scope, "read")
        # VerificationResult(allowed=True, reason="Action in allowed list")

        result = engine.verify(scope, "delete")
        # VerificationResult(allowed=False, reason="Action in denied list")

        result = engine.verify(scope, "read", amount=15000)
        # VerificationResult(allowed=False, reason="Amount 15000 exceeds limit 10000")
    """

    def parse(self, scope_str: str) -> dict | str:
        """Parse scope string. Returns dict if structured, str if free-text."""
        try:
            parsed = json.loads(scope_str)
            if isinstance(parsed, dict) and ("allowed" in parsed or "denied" in parsed):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        return scope_str

    def verify(
        self,
        scope: dict | str,
        action: str,
        amount: float | None = None,
        timestamp: datetime | None = None,
        **kwargs: Any,
    ) -> VerificationResult:
        """Verify if an action is allowed by the scope.

        Args:
            scope: Parsed scope (dict for structured, str for free-text)
            action: Action to verify (e.g. "order_parts", "deploy")
            amount: Optional amount for limit checks
            timestamp: Optional time for schedule checks
        """
        # Free-text scope: can't auto-verify
        if isinstance(scope, str):
            return VerificationResult(
                allowed=True,
                reason="Free-text scope: automatic verification not available. Verify manually.",
                details={"scope_type": "free-text"},
            )

        # Denied list (highest priority)
        denied = scope.get("denied", [])
        if action in denied:
            return VerificationResult(
                allowed=False,
                reason=f"Action '{action}' is in denied list",
            )

        # Allowed list
        allowed = scope.get("allowed", [])
        if allowed and action not in allowed:
            return VerificationResult(
                allowed=False,
                reason=f"Action '{action}' not in allowed list: {allowed}",
            )

        # Amount limits
        limits = scope.get("limits", {})
        if action in limits and amount is not None:
            action_limits = limits[action]
            max_amount = action_limits.get("max_amount")
            if max_amount is not None and amount > max_amount:
                currency = action_limits.get("currency", "")
                return VerificationResult(
                    allowed=False,
                    reason=f"Amount {amount} exceeds limit {max_amount} {currency}",
                    details={"limit": max_amount, "actual": amount},
                )

        # Escalation threshold
        escalation = scope.get("require_approval_above", {})
        if amount is not None and "amount" in escalation:
            if amount > escalation["amount"]:
                return VerificationResult(
                    allowed=False,
                    reason=f"Amount {amount} requires additional approval (threshold: {escalation['amount']})",
                    details={"threshold": escalation["amount"], "actual": amount},
                )

        # Schedule check
        schedule = scope.get("schedule")
        if schedule and timestamp:
            allowed_hours = schedule.get("allowed_hours")
            if allowed_hours and len(allowed_hours) == 2:
                hour = timestamp.hour
                if not (allowed_hours[0] <= hour < allowed_hours[1]):
                    return VerificationResult(
                        allowed=False,
                        reason=f"Action not allowed at hour {hour} (allowed: {allowed_hours[0]}-{allowed_hours[1]})",
                    )

            allowed_days = schedule.get("allowed_days")
            if allowed_days:
                day = timestamp.isoweekday()
                if day not in allowed_days:
                    return VerificationResult(
                        allowed=False,
                        reason=f"Action not allowed on day {day} (allowed: {allowed_days})",
                    )

        return VerificationResult(
            allowed=True,
            reason="Action verified: within scope",
        )


def build_scope(
    allowed: list[str] | None = None,
    denied: list[str] | None = None,
    limits: dict[str, dict] | None = None,
    schedule: dict | None = None,
    require_approval_above: dict | None = None,
) -> str:
    """Build a structured scope JSON string.

    Usage:
        scope = build_scope(
            allowed=["read_data", "order_parts", "send_reports"],
            denied=["delete_data", "modify_schema"],
            limits={
                "order_parts": {"max_amount": 10000, "currency": "USD"},
            },
            schedule={
                "allowed_hours": [9, 17],
                "allowed_days": [1, 2, 3, 4, 5],
            },
        )
        agentcheck.record(agent="bot", scope=scope, ...)
    """
    scope: dict[str, Any] = {}
    if allowed:
        scope["allowed"] = allowed
    if denied:
        scope["denied"] = denied
    if limits:
        scope["limits"] = limits
    if schedule:
        scope["schedule"] = schedule
    if require_approval_above:
        scope["require_approval_above"] = require_approval_above
    return json.dumps(scope)
