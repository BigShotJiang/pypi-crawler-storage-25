from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class Agreement(BaseModel):
    id: str
    status: str
    agent: str
    agent_provider: str | None = None
    scope: str
    authorized_by: str
    created_at: datetime
    approved_at: datetime | None = None
    expires_at: datetime | None = None
    verify_url: str
    signature: str | None = None
    sig_algorithm: str = "HMAC-SHA256"


class AgreementList(BaseModel):
    records: list[Agreement]
    limit: int
    offset: int
