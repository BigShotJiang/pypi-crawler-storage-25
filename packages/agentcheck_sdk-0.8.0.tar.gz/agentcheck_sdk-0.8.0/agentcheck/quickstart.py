"""QuickStart - Setup everything in one call."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Callable

from .client import Client
from .dashboard import DelegationDashboard
from .langchain import AgentToolChecker
from .provider import DelegationProvider


@dataclass
class AgentCheckBundle:
    """All AgentCheck tools in one object."""

    client: Client
    provider: DelegationProvider
    dashboard: DelegationDashboard

    def checker(self, agent_name: str) -> AgentToolChecker:
        """Get a tool checker for a specific agent."""
        return AgentToolChecker(self.provider, agent_name)


def quick_start(
    api_key: str | None = None,
    base_url: str | None = None,
    verify_scope: Callable[[str, str], bool] | None = None,
) -> AgentCheckBundle:
    """Setup everything in one call.

    Usage:
        ac = agentcheck.quick_start()  # reads from env
        # or
        ac = agentcheck.quick_start(api_key="ak_live_...")

        # Now use everything:
        ac.provider.can_act("bot", "action")
        ac.client.record(...)
        ac.dashboard.render()
        checker = ac.checker("my-bot")
        safe_fn = checker.wrap("tool", original_fn)
    """
    key = api_key or os.environ.get("AGENTCHECK_API_KEY", "")
    url = base_url or os.environ.get(
        "AGENTCHECK_BASE_URL", "https://agentcheck.spaceplanning.work"
    )

    if not key:
        raise RuntimeError(
            "Provide api_key or set AGENTCHECK_API_KEY environment variable"
        )

    client = Client(api_key=key, base_url=url)
    provider = DelegationProvider(client, verify_scope=verify_scope)
    dashboard = DelegationDashboard(client)

    return AgentCheckBundle(
        client=client,
        provider=provider,
        dashboard=dashboard,
    )
