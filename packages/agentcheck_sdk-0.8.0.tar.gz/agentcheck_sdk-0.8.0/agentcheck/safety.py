"""Safety Layers - Multi-layered action verification beyond simple rule matching.

Layer 1: ScopeEngine       - "What is it doing?" (rule matching)
Layer 2: BudgetTracker     - "How much total?" (cumulative tracking)
Layer 3: PatternMonitor    - "Is this normal?" (anomaly detection)
Layer 4: HumanEscalation   - "Should a human decide?" (approval request)

Each layer can be used independently or combined via SafetyStack.
"""

from __future__ import annotations

import json
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable

from .scope_engine import ScopeEngine, VerificationResult


# ── Layer 2: Budget Tracker ──────────────────────────────────


class BudgetTracker:
    """Track cumulative usage and enforce daily/monthly budgets.

    Catches: "$9K x 10 times = $90K" when single-action limit is $10K.

    Usage:
        tracker = BudgetTracker(
            daily_limit=50000,
            monthly_limit=500000,
        )
        result = tracker.check("order_parts", amount=9000)
        # After 6th call: allowed=False, "Daily budget exceeded"
    """

    def __init__(
        self,
        daily_limit: float | None = None,
        monthly_limit: float | None = None,
        daily_count_limit: int | None = None,
        per_action_limits: dict[str, dict] | None = None,
    ):
        self._daily_limit = daily_limit
        self._monthly_limit = monthly_limit
        self._daily_count_limit = daily_count_limit
        self._per_action_limits = per_action_limits or {}
        self._daily_totals: dict[str, float] = defaultdict(float)  # date_str -> total
        self._daily_counts: dict[str, int] = defaultdict(int)
        self._monthly_totals: dict[str, float] = defaultdict(float)
        self._action_daily: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))

    def check(
        self, action: str, amount: float = 0, timestamp: datetime | None = None
    ) -> VerificationResult:
        ts = timestamp or datetime.now()
        day_key = ts.strftime("%Y-%m-%d")
        month_key = ts.strftime("%Y-%m")

        # Daily count limit
        if self._daily_count_limit:
            if self._daily_counts[day_key] >= self._daily_count_limit:
                return VerificationResult(
                    allowed=False,
                    reason=f"Daily action count limit reached ({self._daily_count_limit})",
                    details={"count": self._daily_counts[day_key], "limit": self._daily_count_limit},
                )

        # Daily amount limit
        if self._daily_limit and amount > 0:
            projected = self._daily_totals[day_key] + amount
            if projected > self._daily_limit:
                return VerificationResult(
                    allowed=False,
                    reason=f"Daily budget exceeded: {projected:.0f} > {self._daily_limit:.0f}",
                    details={"projected": projected, "limit": self._daily_limit},
                )

        # Monthly amount limit
        if self._monthly_limit and amount > 0:
            projected = self._monthly_totals[month_key] + amount
            if projected > self._monthly_limit:
                return VerificationResult(
                    allowed=False,
                    reason=f"Monthly budget exceeded: {projected:.0f} > {self._monthly_limit:.0f}",
                    details={"projected": projected, "limit": self._monthly_limit},
                )

        # Per-action daily limit
        if action in self._per_action_limits:
            limit = self._per_action_limits[action].get("daily_limit", 0)
            if limit and amount > 0:
                projected = self._action_daily[action][day_key] + amount
                if projected > limit:
                    return VerificationResult(
                        allowed=False,
                        reason=f"Daily limit for '{action}' exceeded: {projected:.0f} > {limit:.0f}",
                    )

        return VerificationResult(allowed=True, reason="Within budget")

    def record_usage(self, action: str, amount: float = 0, timestamp: datetime | None = None):
        """Record actual usage after action completes."""
        ts = timestamp or datetime.now()
        day_key = ts.strftime("%Y-%m-%d")
        month_key = ts.strftime("%Y-%m")
        self._daily_totals[day_key] += amount
        self._daily_counts[day_key] += 1
        self._monthly_totals[month_key] += amount
        self._action_daily[action][day_key] += amount


# ── Layer 3: Pattern Monitor ──────────────────────────────────


@dataclass
class PatternAlert:
    level: str  # "warning" or "critical"
    message: str
    details: dict[str, Any] = field(default_factory=dict)


class PatternMonitor:
    """Detect anomalous behavior patterns.

    Catches: "normally 3 actions/day, suddenly 50/day"

    Usage:
        monitor = PatternMonitor(window_days=7)
        monitor.record("order_parts")  # call after each action
        ...
        alerts = monitor.check("order_parts")
        # [PatternAlert(level="warning", message="3x normal frequency")]
    """

    def __init__(self, window_days: int = 7, frequency_threshold: float = 3.0):
        self._window_days = window_days
        self._frequency_threshold = frequency_threshold
        self._history: list[dict] = []

    def record(self, action: str, amount: float = 0, timestamp: datetime | None = None):
        """Record an action occurrence."""
        self._history.append({
            "action": action,
            "amount": amount,
            "timestamp": (timestamp or datetime.now()).isoformat(),
        })

    def check(self, action: str, amount: float = 0) -> list[PatternAlert]:
        """Check for anomalies."""
        alerts = []
        now = datetime.now()
        window_start = now - timedelta(days=self._window_days)

        # Filter history for this action within window
        recent = [
            h for h in self._history
            if h["action"] == action and datetime.fromisoformat(h["timestamp"]) > window_start
        ]

        if len(recent) < 3:
            return alerts  # Not enough data

        # Frequency check: compare today vs average
        today_count = sum(
            1 for h in recent
            if datetime.fromisoformat(h["timestamp"]).date() == now.date()
        )
        days_with_data = len(set(
            datetime.fromisoformat(h["timestamp"]).date() for h in recent
        ))
        avg_daily = len(recent) / max(days_with_data, 1)

        if avg_daily > 0 and today_count > avg_daily * self._frequency_threshold:
            alerts.append(PatternAlert(
                level="warning",
                message=f"Unusual frequency: {today_count} today vs {avg_daily:.1f} avg/day ({today_count/avg_daily:.1f}x normal)",
                details={"today": today_count, "avg": avg_daily},
            ))

        # Amount check: is this amount unusually large?
        if amount > 0:
            amounts = [h["amount"] for h in recent if h["amount"] > 0]
            if amounts:
                avg_amount = sum(amounts) / len(amounts)
                if amount > avg_amount * self._frequency_threshold:
                    alerts.append(PatternAlert(
                        level="warning",
                        message=f"Unusual amount: {amount:.0f} vs {avg_amount:.0f} avg ({amount/avg_amount:.1f}x normal)",
                        details={"amount": amount, "avg": avg_amount},
                    ))

        return alerts


# ── Layer 4: Human Escalation ──────────────────────────────────


class HumanEscalation:
    """Request human approval for high-risk actions.

    Usage:
        escalation = HumanEscalation(
            threshold_amount=5000,
            on_escalate=lambda action, amount: send_approval_email(...)
        )
        result = escalation.check("order_parts", amount=8000)
        # VerificationResult(allowed=False, reason="Requires human approval")
    """

    def __init__(
        self,
        threshold_amount: float | None = None,
        high_risk_actions: list[str] | None = None,
        on_escalate: Callable[[str, float], None] | None = None,
    ):
        self._threshold = threshold_amount
        self._high_risk = high_risk_actions or []
        self._on_escalate = on_escalate

    def check(self, action: str, amount: float = 0) -> VerificationResult:
        needs_approval = False
        reason = ""

        if action in self._high_risk:
            needs_approval = True
            reason = f"Action '{action}' is classified as high-risk"

        if self._threshold and amount > self._threshold:
            needs_approval = True
            reason = f"Amount {amount:.0f} exceeds escalation threshold {self._threshold:.0f}"

        if needs_approval:
            if self._on_escalate:
                self._on_escalate(action, amount)
            return VerificationResult(
                allowed=False,
                reason=f"Requires human approval: {reason}",
                details={"needs_human_approval": True},
            )

        return VerificationResult(allowed=True, reason="No escalation needed")


# ── SafetyStack: All layers combined ──────────────────────────


@dataclass
class SafetyResult:
    allowed: bool
    passed_layers: list[str]
    failed_layer: str | None = None
    reason: str = ""
    alerts: list[PatternAlert] = field(default_factory=list)


class SafetyStack:
    """Combine all safety layers into a single check.

    Usage:
        stack = SafetyStack(
            scope_engine=ScopeEngine(),
            budget=BudgetTracker(daily_limit=50000),
            pattern=PatternMonitor(),
            escalation=HumanEscalation(threshold_amount=5000),
        )

        result = stack.check(scope, "order_parts", amount=8000)
        if not result.allowed:
            print(f"Blocked at {result.failed_layer}: {result.reason}")
    """

    def __init__(
        self,
        scope_engine: ScopeEngine | None = None,
        budget: BudgetTracker | None = None,
        pattern: PatternMonitor | None = None,
        escalation: HumanEscalation | None = None,
    ):
        self.scope_engine = scope_engine or ScopeEngine()
        self.budget = budget
        self.pattern = pattern
        self.escalation = escalation

    def check(
        self,
        scope: dict | str,
        action: str,
        amount: float = 0,
        timestamp: datetime | None = None,
    ) -> SafetyResult:
        passed = []
        alerts = []

        # Layer 1: Scope rules
        r1 = self.scope_engine.verify(scope, action, amount=amount, timestamp=timestamp)
        if not r1.allowed:
            return SafetyResult(
                allowed=False, passed_layers=passed,
                failed_layer="scope_engine", reason=r1.reason,
            )
        passed.append("scope_engine")

        # Layer 2: Budget
        if self.budget:
            r2 = self.budget.check(action, amount, timestamp)
            if not r2.allowed:
                return SafetyResult(
                    allowed=False, passed_layers=passed,
                    failed_layer="budget_tracker", reason=r2.reason,
                )
            passed.append("budget_tracker")

        # Layer 3: Pattern
        if self.pattern:
            pattern_alerts = self.pattern.check(action, amount)
            alerts.extend(pattern_alerts)
            critical = [a for a in pattern_alerts if a.level == "critical"]
            if critical:
                return SafetyResult(
                    allowed=False, passed_layers=passed,
                    failed_layer="pattern_monitor", reason=critical[0].message,
                    alerts=alerts,
                )
            passed.append("pattern_monitor")

        # Layer 4: Human escalation
        if self.escalation:
            r4 = self.escalation.check(action, amount)
            if not r4.allowed:
                return SafetyResult(
                    allowed=False, passed_layers=passed,
                    failed_layer="human_escalation", reason=r4.reason,
                    alerts=alerts,
                )
            passed.append("human_escalation")

        return SafetyResult(
            allowed=True, passed_layers=passed,
            reason="All safety layers passed", alerts=alerts,
        )

    def record_execution(self, action: str, amount: float = 0, timestamp: datetime | None = None):
        """Record execution for budget tracking and pattern monitoring."""
        if self.budget:
            self.budget.record_usage(action, amount, timestamp)
        if self.pattern:
            self.pattern.record(action, amount, timestamp)
