"""DelegationGuard - FastAPI/Flask middleware for automatic delegation checks."""

from __future__ import annotations

from typing import Callable

from .provider import DelegationProvider


def fastapi_guard(
    provider: DelegationProvider,
    get_agent: Callable,
    get_action: Callable,
):
    """FastAPI middleware that checks delegation before each request.

    Usage:
        from agentcheck.guard import fastapi_guard

        @app.middleware("http")
        async def delegation_check(request, call_next):
            return await fastapi_guard(
                provider,
                get_agent=lambda req: req.headers.get("x-agent-id"),
                get_action=lambda req: f"{req.method} {req.url.path}",
            )(request, call_next)
    """

    async def middleware(request, call_next):
        agent = get_agent(request)
        if not agent:
            from starlette.responses import JSONResponse

            return JSONResponse(
                {"error": "No agent identified in request"}, status_code=403
            )

        action = get_action(request)
        check = provider.can_act(agent, action)

        if not check["allowed"]:
            from starlette.responses import JSONResponse

            return JSONResponse(
                {
                    "error": "Delegation check failed",
                    "reason": check["reason"],
                    "agent": agent,
                    "action": action,
                },
                status_code=403,
            )

        response = await call_next(request)

        agreement = check.get("agreement")
        provider.log_execution(
            agent, action, agreement.id if agreement else None, "success"
        )

        return response

    return middleware
