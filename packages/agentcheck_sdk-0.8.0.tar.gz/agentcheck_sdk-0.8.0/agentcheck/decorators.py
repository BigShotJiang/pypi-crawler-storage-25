"""Decorators - Reduce delegation checks to 1 line."""

from __future__ import annotations

import functools
import os
from typing import Callable

from .client import Client
from .provider import DelegationProvider

_auto_provider: DelegationProvider | None = None


def _get_auto_provider() -> DelegationProvider:
    """Auto-create provider from environment variables."""
    global _auto_provider
    if _auto_provider is None:
        api_key = os.environ.get("AGENTCHECK_API_KEY")
        base_url = os.environ.get(
            "AGENTCHECK_BASE_URL", "https://agentcheck.spaceplanning.work"
        )
        if not api_key:
            raise RuntimeError("AGENTCHECK_API_KEY environment variable not set")
        client = Client(api_key=api_key, base_url=base_url)
        _auto_provider = DelegationProvider(client)
    return _auto_provider


def delegation_required(agent: str, action: str | None = None):
    """Decorator: function only runs if agent has valid delegation.

    Usage:
        @delegation_required("order-bot")
        def create_order(item, quantity):
            ...

        @delegation_required("deploy-bot", action="deploy-staging")
        def deploy_to_staging():
            ...
    """

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            act = action or fn.__name__
            provider = _get_auto_provider()
            return provider.execute_with_guard(agent, act, lambda: fn(*args, **kwargs))

        return wrapper

    return decorator


def scope_check(agent: str, action: str) -> bool:
    """One-liner: check if agent can perform action.

    Usage:
        if agentcheck.scope_check("my-bot", "send-email"):
            send_email()
    """
    provider = _get_auto_provider()
    result = provider.can_act(agent, action)
    return result["allowed"]
