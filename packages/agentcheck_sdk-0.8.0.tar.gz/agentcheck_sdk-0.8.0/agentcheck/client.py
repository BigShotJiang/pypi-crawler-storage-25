from __future__ import annotations

import httpx

from .exceptions import (
    AgentCheckError,
    AuthenticationError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from .models import Agreement, AgreementList

_DEFAULT_BASE_URL = "https://api.agentcheck.io"


class Client:
    """AgentCheck API client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )

    def _handle_response(self, resp: httpx.Response) -> dict:
        if resp.status_code == 401:
            raise AuthenticationError("Invalid API key", code="unauthorized")
        if resp.status_code == 404:
            raise NotFoundError("Resource not found", code="not_found")
        if resp.status_code == 400:
            data = resp.json()
            msg = data.get("error", {}).get("message", "Bad request")
            raise ValidationError(msg, code="bad_request")
        if resp.status_code >= 500:
            raise ServerError("Server error", code="server_error")
        if not resp.is_success:
            raise AgentCheckError(f"HTTP {resp.status_code}")
        return resp.json()

    def record(
        self,
        agent: str,
        scope: str,
        authorized_by: str,
        agent_provider: str | None = None,
        expires_in_days: int | None = None,
        metadata: dict | None = None,
    ) -> Agreement:
        """Create a new agreement and send approval email."""
        body: dict = {
            "agent": agent,
            "scope": scope,
            "authorized_by": authorized_by,
        }
        if agent_provider is not None:
            body["agent_provider"] = agent_provider
        if expires_in_days is not None:
            body["expires_in_days"] = expires_in_days
        if metadata is not None:
            body["metadata"] = metadata

        resp = self._http.post("/api/v1/record", json=body)
        data = self._handle_response(resp)
        return Agreement.model_validate(data["data"])

    def get(self, agreement_id: str) -> Agreement:
        """Get agreement details by ID."""
        resp = self._http.get(f"/api/v1/record/{agreement_id}")
        data = self._handle_response(resp)
        return Agreement.model_validate(data["data"])

    def list(
        self,
        status: str | None = None,
        agent: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> AgreementList:
        """List agreements with optional filters."""
        params: dict = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        if agent is not None:
            params["agent"] = agent

        resp = self._http.get("/api/v1/records", params=params)
        data = self._handle_response(resp)
        return AgreementList.model_validate(data["data"])

    def amend(
        self,
        agreement_id: str,
        new_scope: str,
        reason: str | None = None,
        require_reauth: bool = True,
    ) -> Agreement:
        """Amend an agreement's scope. Creates a new version."""
        body: dict = {
            "new_scope": new_scope,
            "require_reauth": require_reauth,
        }
        if reason is not None:
            body["reason"] = reason

        resp = self._http.post(f"/api/v1/record/{agreement_id}/amend", json=body)
        data = self._handle_response(resp)
        return Agreement.model_validate(data["data"])

    def revoke(
        self,
        agreement_id: str,
        reason: str,
    ) -> Agreement:
        """Revoke an agreement immediately."""
        resp = self._http.post(
            f"/api/v1/record/{agreement_id}/revoke",
            json={"reason": reason},
        )
        data = self._handle_response(resp)
        return Agreement.model_validate(data["data"])

    def register_webhook(
        self,
        url: str,
        events: list[str],
    ) -> dict:
        """Register a webhook endpoint."""
        resp = self._http.post(
            "/api/v1/webhooks",
            json={"url": url, "events": events},
        )
        data = self._handle_response(resp)
        return data["data"]

    def get_audit_trail(self, agreement_id: str) -> dict:
        """Get audit trail (hash chain) for an agreement."""
        resp = self._http.get(f"/api/v1/audit/{agreement_id}")
        data = self._handle_response(resp)
        return data

    def verify_audit_chain(self, agreement_id: str) -> dict:
        """Verify hash chain integrity for an agreement."""
        resp = self._http.get(f"/api/v1/audit/{agreement_id}/verify")
        data = self._handle_response(resp)
        return data

    @staticmethod
    def signup(
        email: str,
        company_name: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
    ) -> dict:
        """Self-service signup. Returns API key (shown once)."""
        body: dict = {"email": email}
        if company_name is not None:
            body["company_name"] = company_name
        resp = httpx.post(f"{base_url}/api/v1/signup", json=body)
        if resp.status_code == 429:
            raise AgentCheckError("Rate limited", code="rate_limited")
        if not resp.is_success:
            data = resp.json()
            msg = data.get("error", {}).get("message", "Signup failed")
            raise AgentCheckError(msg)
        return resp.json()["data"]

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
