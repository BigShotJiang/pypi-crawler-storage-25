"""AgentCheck - Record what your AI agent is allowed to do."""

from __future__ import annotations

from .client import Client
from .exceptions import (
    AgentCheckError,
    AuthenticationError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from .models import Agreement, AgreementList
from .provider import DelegationProvider
from .langchain import AgentToolChecker
from .dashboard import DelegationDashboard
from .decorators import delegation_required, scope_check
from .quickstart import quick_start
from . import templates
from .scope_engine import ScopeEngine, build_scope
from .safety import SafetyStack, BudgetTracker, PatternMonitor, HumanEscalation

__version__ = "0.8.0"
__all__ = [
    "Client",
    "Agreement",
    "AgreementList",
    "AgentCheckError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "init",
    "record",
    "get",
    "list",
    "amend",
]

# -- Module-level convenience API --
# Enables: agentcheck.record(agent, scope, authorized_by)

_client: Client | None = None


def init(api_key: str, base_url: str = "https://api.agentcheck.io"):
    """Initialize the global client."""
    global _client
    _client = Client(api_key=api_key, base_url=base_url)


def _get_client() -> Client:
    if _client is None:
        raise AgentCheckError(
            "Call agentcheck.init(api_key='...') first",
            code="not_initialized",
        )
    return _client


def record(
    agent: str,
    scope: str,
    authorized_by: str,
    **kwargs,
) -> Agreement:
    """Create a new agreement. One line is all you need."""
    return _get_client().record(
        agent=agent,
        scope=scope,
        authorized_by=authorized_by,
        **kwargs,
    )


def get(agreement_id: str) -> Agreement:
    """Get agreement details."""
    return _get_client().get(agreement_id)


def list(
    status: str | None = None,
    agent: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> AgreementList:
    """List agreements."""
    return _get_client().list(status=status, agent=agent, limit=limit, offset=offset)


def amend(
    agreement_id: str,
    new_scope: str,
    reason: str | None = None,
    require_reauth: bool = True,
) -> Agreement:
    """Amend an agreement's scope."""
    return _get_client().amend(
        agreement_id=agreement_id,
        new_scope=new_scope,
        reason=reason,
        require_reauth=require_reauth,
    )
