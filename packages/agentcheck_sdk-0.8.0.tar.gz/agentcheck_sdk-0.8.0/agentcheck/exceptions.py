class AgentCheckError(Exception):
    """Base exception for AgentCheck SDK."""

    def __init__(self, message: str, code: str | None = None):
        self.message = message
        self.code = code
        super().__init__(message)


class AuthenticationError(AgentCheckError):
    """Invalid or missing API key."""


class NotFoundError(AgentCheckError):
    """Resource not found."""


class ValidationError(AgentCheckError):
    """Invalid request parameters."""


class ServerError(AgentCheckError):
    """Server-side error."""
