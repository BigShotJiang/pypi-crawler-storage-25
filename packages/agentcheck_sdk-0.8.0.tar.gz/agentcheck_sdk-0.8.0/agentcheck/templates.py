"""Scope Templates - Pre-built scope definitions for common use cases."""

from __future__ import annotations


def manufacturing(max_order_amount: int = 10000, currency: str = "USD") -> str:
    """Manufacturing agent scope template.

    Usage:
        agentcheck.record(
            agent="maintenance-bot",
            scope=templates.manufacturing(max_order_amount=10000),
            authorized_by="factory-manager@company.com"
        )
    """
    return (
        f"Monitor equipment 24/7. "
        f"Order replacement parts up to {currency} {max_order_amount:,}. "
        f"Generate maintenance reports. "
        f"Alert on anomalies."
    )


def customer_support(max_refund: int = 500, currency: str = "USD") -> str:
    """Customer support agent scope template."""
    return (
        f"Access customer profiles (read-only). "
        f"Issue refunds up to {currency} {max_refund:,}. "
        f"Create support tickets. "
        f"Escalate to human agent for amounts over {currency} {max_refund:,}."
    )


def devops(environments: list[str] | None = None) -> str:
    """DevOps agent scope template."""
    envs = environments or ["staging"]
    env_str = ", ".join(envs)
    return (
        f"Deploy to {env_str}. "
        f"Rollback on failure. "
        f"Monitor server health. "
        f"Restart services on crash. "
        f"Cannot modify production database directly."
    )


def finance(
    max_transaction: int = 10000,
    currency: str = "USD",
    asset_classes: list[str] | None = None,
) -> str:
    """Finance/trading agent scope template."""
    assets = asset_classes or ["stocks", "bonds"]
    asset_str = ", ".join(assets)
    return (
        f"Execute trades up to {currency} {max_transaction:,} per transaction. "
        f"Asset classes: {asset_str}. "
        f"Generate daily P&L reports. "
        f"Cannot withdraw funds."
    )


def data_pipeline(databases: list[str] | None = None) -> str:
    """Data pipeline agent scope template."""
    dbs = databases or ["analytics"]
    db_str = ", ".join(dbs)
    return (
        f"Read from production database. "
        f"Write to {db_str} database(s). "
        f"Run ETL jobs on schedule. "
        f"Cannot modify production schema. "
        f"Cannot delete records."
    )


def general(actions: list[str]) -> str:
    """General purpose scope from a list of allowed actions.

    Usage:
        scope = templates.general(["read-files", "send-notifications", "generate-reports"])
    """
    return "Allowed actions: " + ", ".join(actions) + "."
