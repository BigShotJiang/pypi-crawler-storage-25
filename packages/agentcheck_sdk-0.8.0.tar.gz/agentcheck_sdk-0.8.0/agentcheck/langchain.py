"""AgentToolChecker - LangChain/CrewAI tool execution guard."""

from __future__ import annotations

from typing import Callable, TypeVar

from .provider import DelegationProvider

T = TypeVar("T")


class AgentToolChecker:
    """Wrap LangChain/CrewAI tools with delegation checks.

    Usage:
        checker = AgentToolChecker(provider, "my-bot")

        # Wrap any tool function
        safe_send = checker.wrap("send-email", original_send_email)
        safe_send(to="user@example.com", body="Hello")

        # Or check manually
        if checker.can_use_tool("send-email"):
            send_email(...)
    """

    def __init__(self, provider: DelegationProvider, agent_name: str):
        self._provider = provider
        self._agent_name = agent_name

    def can_use_tool(self, tool_name: str) -> bool:
        """Check if agent can use a specific tool."""
        check = self._provider.can_act(self._agent_name, tool_name)
        return check["allowed"]

    def wrap(self, tool_name: str, tool_fn: Callable[..., T]) -> Callable[..., T]:
        """Wrap a tool function with delegation check + execution log."""

        def wrapped(*args, **kwargs):
            return self._provider.execute_with_guard(
                self._agent_name,
                tool_name,
                lambda: tool_fn(*args, **kwargs),
            )

        wrapped.__name__ = f"guarded_{tool_fn.__name__}"
        wrapped.__doc__ = tool_fn.__doc__
        return wrapped
