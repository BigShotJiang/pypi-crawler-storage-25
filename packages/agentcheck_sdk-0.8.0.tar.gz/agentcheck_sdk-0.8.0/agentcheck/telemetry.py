"""Telemetry Plugin - Opt-in usage tracking.

NOT enabled by default. You must explicitly enable it.

What it tracks:
- Which SDK features are used (record, list, revoke, etc.)
- SDK language and version
- Agent names (for your own analytics)

What it does NOT track:
- Scope content
- Email addresses
- API keys
- Request/response payloads
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import Any

import httpx


class TelemetryPlugin:
    """Opt-in telemetry. Batches events and sends every 60 seconds.

    Usage:
        from agentcheck.telemetry import TelemetryPlugin

        # Enable telemetry (opt-in)
        telemetry = TelemetryPlugin(api_key="ak_live_...", base_url="https://...")
        telemetry.enable()

        # Now all SDK calls are automatically tracked
        # To disable:
        telemetry.disable()

    Or with quick_start:
        ac = agentcheck.quick_start()
        ac.telemetry.enable()  # opt-in
    """

    _instance: TelemetryPlugin | None = None

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://agentcheck.spaceplanning.work",
        flush_interval: int = 60,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._flush_interval = flush_interval
        self._buffer: deque[dict[str, Any]] = deque(maxlen=500)
        self._enabled = False
        self._thread: threading.Thread | None = None

    def enable(self):
        """Start collecting telemetry."""
        self._enabled = True
        TelemetryPlugin._instance = self
        self._thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._thread.start()

    def disable(self):
        """Stop collecting telemetry."""
        self._enabled = False
        TelemetryPlugin._instance = None
        self._flush()

    @staticmethod
    def track(event: str, feature: str | None = None, agent_name: str | None = None, **kwargs):
        """Record a telemetry event (no-op if not enabled)."""
        instance = TelemetryPlugin._instance
        if instance is None or not instance._enabled:
            return

        instance._buffer.append({
            "event": event,
            "sdk_language": "python",
            "sdk_version": "0.4.0",
            "feature": feature,
            "agent_name": agent_name,
            "metadata": kwargs if kwargs else None,
        })

    def _flush_loop(self):
        while self._enabled:
            time.sleep(self._flush_interval)
            self._flush()

    def _flush(self):
        if not self._buffer:
            return

        events = []
        while self._buffer:
            events.append(self._buffer.popleft())

        try:
            httpx.post(
                f"{self._base_url}/api/v1/telemetry",
                headers={"X-API-Key": self._api_key},
                json={"events": events},
                timeout=10,
            )
        except Exception:
            pass  # Telemetry should never break the app
