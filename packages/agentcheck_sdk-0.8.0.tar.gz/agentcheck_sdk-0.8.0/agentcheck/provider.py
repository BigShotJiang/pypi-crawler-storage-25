"""DelegationProvider - Universal set menu for AI agent delegation."""

from __future__ import annotations

from typing import Any, Callable

import httpx

from .client import Client
from .models import Agreement
from .scope_engine import ScopeEngine


class DelegationProvider:
    """High-level wrapper for common delegation operations.

    Combines individual SDK methods into ready-to-use flows:
    - can_act(): "Can this agent do this action right now?"
    - has_active_delegation(): "Does this agent have any valid delegation?"
    - log_execution(): "Record what the agent actually did"
    - execute_with_guard(): Check + execute + log in one call

    When verify_scope is not provided and scope is structured JSON,
    ScopeEngine verifies automatically.

    Usage:
        # Auto-verify with structured scope:
        provider = DelegationProvider(client)

        # Custom verify with free-text scope:
        provider = DelegationProvider(client,
            verify_scope=lambda scope, action: action in scope)
    """

    def __init__(
        self,
        client: Client,
        verify_scope: Callable[[str, str], bool] | None = None,
    ):
        self._client = client
        self._scope_engine = ScopeEngine()
        if verify_scope:
            self._verify_scope = verify_scope
        else:
            self._verify_scope = self._auto_verify

    def _auto_verify(self, scope_str: str, action: str) -> bool:
        """Auto-verify using ScopeEngine for structured scopes."""
        scope = self._scope_engine.parse(scope_str)
        result = self._scope_engine.verify(scope, action)
        return result.allowed

    def can_act(
        self,
        agent_name: str,
        action: str,
        params: dict | None = None,
    ) -> dict:
        """Check if agent has valid delegation AND action is in scope."""
        records = self._client.list(agent=agent_name, status="approved")

        if not records.records:
            return {"allowed": False, "reason": "No active delegation"}

        agreement = records.records[0]

        if not self._verify_scope(agreement.scope, action):
            return {"allowed": False, "reason": "Action not in scope", "agreement": agreement}

        return {"allowed": True, "agreement": agreement}

    def has_active_delegation(self, agent_name: str) -> bool:
        """Check if agent has any active (approved) delegation."""
        records = self._client.list(agent=agent_name, status="approved")
        return len(records.records) > 0

    def log_execution(
        self,
        agent_name: str,
        action: str,
        agreement_id: str | None = None,
        result: str | None = None,
        metadata: dict | None = None,
    ) -> None:
        """Log what an agent actually did (audit trail)."""
        body: dict[str, Any] = {"agent": agent_name, "action": action}
        if agreement_id:
            body["agreement_id"] = agreement_id
        if result:
            body["result"] = result
        if metadata:
            body["metadata"] = metadata
        self._client._http.post("/api/v1/executions", json=body)

    def execute_with_guard(
        self,
        agent_name: str,
        action: str,
        execute_fn: Callable[[], Any],
        params: dict | None = None,
    ) -> Any:
        """Full flow: check permission, execute, log."""
        check = self.can_act(agent_name, action, params)
        if not check["allowed"]:
            raise PermissionError(
                f'Agent "{agent_name}" cannot "{action}": {check["reason"]}'
            )

        result = execute_fn()

        agreement = check.get("agreement")
        self.log_execution(
            agent_name,
            action,
            agreement.id if agreement else None,
            "success",
            params,
        )

        return result
