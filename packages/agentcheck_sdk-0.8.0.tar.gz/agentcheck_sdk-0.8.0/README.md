# agentcheck

Record what your AI agent is allowed to do.

## Install

```bash
pip install agentcheck
```

## Quickstart

```python
import agentcheck

agentcheck.init(api_key="ak_live_...", base_url="https://agentcheck.fly.dev")

proof = agentcheck.record(
    agent="factory-bot",
    scope="order parts under $10K, monitor equipment 24/7",
    authorized_by="kim@factory.com"
)

# Kim gets an email, clicks "Approve"
# Anyone can verify: /api/v1/verify/{proof.id}

record = agentcheck.get(proof.id)
print(record.status)  # "approved"
```

## API

| Function | Description |
|----------|-------------|
| `agentcheck.init(api_key, base_url)` | Initialize with your API key |
| `agentcheck.record(agent, scope, authorized_by)` | Create agreement |
| `agentcheck.get(id)` | Get agreement details |
| `agentcheck.list(status, agent)` | List agreements |
| `agentcheck.amend(id, new_scope)` | Amend agreement scope |

## Sign Up

```python
from agentcheck import Client

result = Client.signup(
    email="dev@company.com",
    company_name="My Company",
    base_url="https://agentcheck.fly.dev"
)
print(result["api_key"])  # Save this - shown once only
```

## License

MIT
