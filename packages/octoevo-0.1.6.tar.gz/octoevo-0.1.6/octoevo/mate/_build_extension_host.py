"""
Generated during release build. Do not edit manually.
"""

DEFAULT_EXTENSION_WEBAPP_HOST = "https://weclaw.ai"
