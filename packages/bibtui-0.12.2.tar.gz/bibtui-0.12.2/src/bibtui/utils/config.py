import tomllib
from dataclasses import dataclass, field
from pathlib import Path

CONFIG_PATH = Path.home() / ".config" / "bibtui" / "config.toml"


@dataclass
class Config:
    pdf_base_dir: str = ""
    unpaywall_email: str = ""
    openalex_api_key: str = ""
    pdf_download_dir: str = ""
    auto_fetch_pdf: bool = True
    update_last_check_utc: str = ""
    update_last_notified_utc: str = ""
    update_latest_version: str = ""
    check_for_updates: bool = True
    recent_files: list[str] = field(default_factory=list)
    theme: str = ""  # empty means auto-detect from OS/Omarchy


def is_first_run() -> bool:
    """Return True if no config file exists yet (new installation)."""
    return not CONFIG_PATH.exists()


def _git_email() -> str:
    """Read user.email from global git config, or return empty string."""
    import subprocess

    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        return result.stdout.strip()
    except Exception:
        return ""


def default_config() -> Config:
    """Return a Config pre-filled with sensible platform defaults."""
    home = Path.home()
    return Config(
        pdf_base_dir=str(home / "Documents" / "papers"),
        unpaywall_email=_git_email(),
        pdf_download_dir=str(home / "Downloads"),
    )


def load_config() -> Config:
    if not CONFIG_PATH.exists():
        return default_config()
    try:
        with open(CONFIG_PATH, "rb") as f:
            data = tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):
        return default_config()
    pdf = data.get("pdf", {})
    api_keys = data.get("api_keys", {})
    updates = data.get("updates", {})
    files_section = data.get("files", {})
    ui_section = data.get("ui", {})
    recent_raw = files_section.get("recent", [])
    recent_files = [str(r) for r in recent_raw if isinstance(r, str)]
    return Config(
        pdf_base_dir=pdf.get("base_dir", ""),
        unpaywall_email=pdf.get("unpaywall_email", ""),
        openalex_api_key=api_keys.get("openalex_api_key", ""),
        pdf_download_dir=pdf.get("download_dir", ""),
        auto_fetch_pdf=pdf.get("auto_fetch_pdf", True),
        update_last_check_utc=updates.get("last_check_utc", ""),
        update_last_notified_utc=updates.get("last_notified_utc", ""),
        update_latest_version=updates.get("latest_version", ""),
        check_for_updates=updates.get("check_for_updates", True),
        recent_files=recent_files,
        theme=ui_section.get("theme", ""),
    )


def _toml_escape(value: str) -> str:
    """Escape a string value for embedding in a TOML double-quoted string."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _toml_str_list(items: list[str]) -> str:
    escaped = ", ".join(f'"{_toml_escape(item)}"' for item in items)
    return f"[{escaped}]"


def save_config(config: Config) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "[pdf]",
        f'base_dir = "{_toml_escape(config.pdf_base_dir)}"',
        f'unpaywall_email = "{_toml_escape(config.unpaywall_email)}"',
        f'download_dir = "{_toml_escape(config.pdf_download_dir)}"',
        f"auto_fetch_pdf = {'true' if config.auto_fetch_pdf else 'false'}",
        "",
        "[api_keys]",
        f'openalex_api_key = "{_toml_escape(config.openalex_api_key)}"',
        "",
        "[updates]",
        f'last_check_utc = "{_toml_escape(config.update_last_check_utc)}"',
        f'last_notified_utc = "{_toml_escape(config.update_last_notified_utc)}"',
        f'latest_version = "{_toml_escape(config.update_latest_version)}"',
        f"check_for_updates = {'true' if config.check_for_updates else 'false'}",
        "",
        "[files]",
        f"recent = {_toml_str_list(config.recent_files[:8])}",
        "",
        "[ui]",
        f'theme = "{_toml_escape(config.theme)}"',
        "",
    ]
    CONFIG_PATH.write_text("\n".join(lines), encoding="utf-8")
