"""
Nuke Persistent Server Manager (File-Based IPC)

Manages the lifecycle of a headless Nuke instance (nuke -t) kept alive for
the duration of the agent. Speeds up Nuke operations by ~30-50x by amortising
the ~5-10 second Nuke startup over the agent's lifetime.

Architecture:
    base_dir/command.json   — agent writes command here
    base_dir/response.json  — Nuke writes result here
    base_dir/ready.json     — Nuke writes this on startup to signal it's alive

Based on: houdini_server_manager_filebased.py
"""

import json
import logging
import os
import re
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class NukeServerManagerFileBased:
    """Start / stop / dispatch to a single persistent Nuke -t process."""

    def __init__(self, base_dir: Optional[Path] = None):
        self.nuke_process: Optional[subprocess.Popen] = None
        self.is_ready = False
        self.server_startup_time = 0.0

        if base_dir is None:
            base_dir = Path(tempfile.gettempdir()) / "plumber_nuke_persistent"

        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

        self.command_file = self.base_dir / "command.json"
        self.response_file = self.base_dir / "response.json"
        self.ready_file = self.base_dir / "ready.json"

        self.nuke_path = self._find_nuke_executable()

    # ──────────────────────────────────────────────────
    # Discovery
    # ──────────────────────────────────────────────────

    def _find_nuke_executable(self) -> str:
        """
        Locate the newest installed Nuke executable.

        Returns the NEWEST version found by scanning standard install dirs
        on Windows, macOS and Linux. Falls back to a best-guess path.
        """
        import platform

        system = platform.system()

        # Check PATH first (covers linux packages and dev setups).
        try:
            which_cmd = "where" if system == "Windows" else "which"
            # Nuke versioned binaries are named Nuke{version}, try a generic match too.
            for name in ("Nuke", "nuke"):
                result = subprocess.run([which_cmd, name], capture_output=True, text=True)
                if result.returncode == 0 and result.stdout.strip():
                    path = result.stdout.strip().split("\n")[0]
                    logger.info(f"✓ Found Nuke in PATH: {path}")
                    return path
        except Exception:
            pass

        found = []  # list of (version_tuple, path, version_str)

        if system == "Windows":
            # Program Files\Nuke{version}\Nuke{version}.exe
            for base in (r"C:\Program Files", r"C:\Program Files (x86)"):
                base_path = Path(base)
                if not base_path.exists():
                    continue
                for folder in base_path.iterdir():
                    if not folder.is_dir() or not folder.name.startswith("Nuke"):
                        continue
                    version_match = re.match(r"Nuke(\d+(?:\.\d+)*)", folder.name)
                    if not version_match:
                        continue
                    version_str = version_match.group(1)
                    # Executable is usually Nuke{version}.exe inside the folder.
                    for exe_name in (
                        f"Nuke{version_str}.exe",
                        # Very old layouts occasionally varied; be forgiving:
                        *(f.name for f in folder.iterdir() if f.is_file() and f.name.startswith("Nuke") and f.name.endswith(".exe")),
                    ):
                        exe_path = folder / exe_name
                        if exe_path.exists():
                            try:
                                version_parts = tuple(int(x) for x in version_str.split("."))
                                found.append((version_parts, str(exe_path), version_str))
                                logger.debug(f"Found Nuke {version_str}: {exe_path}")
                                break
                            except ValueError:
                                pass

        elif system == "Darwin":
            apps = Path("/Applications")
            if apps.exists():
                for folder in apps.iterdir():
                    m = re.match(r"Nuke(\d+(?:\.\d+)*)", folder.name)
                    if not m:
                        continue
                    version_str = m.group(1)
                    # /Applications/Nuke14.0/Nuke14.0.app/Contents/MacOS/Nuke14.0
                    exe_path = folder / f"Nuke{version_str}.app" / "Contents" / "MacOS" / f"Nuke{version_str}"
                    if exe_path.exists():
                        try:
                            version_parts = tuple(int(x) for x in version_str.split("."))
                            found.append((version_parts, str(exe_path), version_str))
                        except ValueError:
                            pass

        else:  # Linux
            import glob
            for pattern in ("/usr/local/Nuke*", "/opt/Nuke*"):
                for match_dir in glob.glob(pattern):
                    folder = Path(match_dir)
                    m = re.match(r"Nuke(\d+(?:\.\d+)*)", folder.name)
                    if not m:
                        continue
                    version_str = m.group(1)
                    exe_path = folder / f"Nuke{version_str}"
                    if exe_path.exists():
                        try:
                            version_parts = tuple(int(x) for x in version_str.split("."))
                            found.append((version_parts, str(exe_path), version_str))
                        except ValueError:
                            pass

        if found:
            found.sort(reverse=True, key=lambda x: x[0])
            version_parts, path, version_str = found[0]
            logger.info(f"✓ Found Nuke v{version_str} (newest): {path}")
            return path

        logger.warning("⚠️ Nuke executable not found via dynamic discovery")
        if system == "Windows":
            return r"C:\Program Files\Nuke14.0\Nuke14.0.exe"
        elif system == "Darwin":
            return "/Applications/Nuke14.0/Nuke14.0.app/Contents/MacOS/Nuke14.0"
        return "nuke"

    # ──────────────────────────────────────────────────
    # Lifecycle
    # ──────────────────────────────────────────────────

    def start_server(self, timeout: int = 60) -> bool:
        """Launch `nuke -t <server_script>`; wait for ready.json."""
        logger.info("🚀 Starting Nuke persistent server (file-based IPC)...")

        start_time = time.time()

        server_script = Path(__file__).parent / "nuke_persistent_server_filebased.py"
        if not server_script.exists():
            logger.error(f"❌ Server script not found: {server_script}")
            return False

        logger.info(f"📄 Server script: {server_script}")
        logger.info(f"🎨 Nuke path: {self.nuke_path}")
        logger.info(f"📁 IPC directory: {self.base_dir}")

        # Clean stale IPC files from a previous run.
        for f in (self.command_file, self.response_file, self.ready_file):
            if f.exists():
                try:
                    f.unlink()
                except Exception:
                    pass

        try:
            CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0

            self.nuke_process = subprocess.Popen(
                [
                    self.nuke_path,
                    "-t",
                    str(server_script),
                    "--command-file", str(self.command_file),
                    "--response-file", str(self.response_file),
                    "--ready-file", str(self.ready_file),
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0,
            )

            logger.info(f"📝 Nuke server process started (PID: {self.nuke_process.pid})")
            logger.info("⏳ Waiting for Nuke to initialize...")

            for _ in range(timeout * 10):  # 0.1s ticks
                if self.nuke_process.poll() is not None:
                    logger.error(f"❌ Nuke server died (exit code: {self.nuke_process.returncode})")
                    return False

                if self.ready_file.exists():
                    try:
                        with open(self.ready_file, "r") as f:
                            ready_data = json.load(f)

                        self.server_startup_time = time.time() - start_time
                        self.is_ready = True

                        logger.info("✅ Nuke persistent server ready!")
                        logger.info(f"   Startup time: {self.server_startup_time:.2f}s")
                        logger.info(f"   Nuke version: {ready_data.get('nuke_version')}")
                        logger.info(f"   PID: {ready_data.get('pid')}")
                        return True
                    except (json.JSONDecodeError, IOError):
                        # File still being written — keep waiting.
                        pass

                time.sleep(0.1)

            elapsed = time.time() - start_time
            logger.error(f"❌ Nuke server did not become ready within {timeout}s (waited {elapsed:.1f}s)")
            self._cleanup_process()
            return False

        except Exception as e:
            logger.error(f"❌ Failed to start Nuke server: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            self._cleanup_process()
            return False

    def execute_command(
        self,
        command: str,
        operation_type: str = "generic",
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Write a command file, poll for response.json, return parsed result."""
        if not self.is_ready:
            raise RuntimeError("Nuke server not ready — call start_server() first")

        # operation_id correlates command with response — see
        # blender_server_manager_filebased.py for full rationale.
        operation_id = uuid.uuid4().hex
        logger.debug(f"📝 Executing Nuke command: {operation_type} (op={operation_id[:8]})")
        request_start = time.time()

        if self.response_file.exists():
            try:
                self.response_file.unlink()
            except Exception:
                pass

        command_data = {
            "operation_id": operation_id,
            "command": command,
            "operation_type": operation_type,
        }

        try:
            with open(self.command_file, "w") as f:
                json.dump(command_data, f, indent=2)
        except Exception as e:
            raise RuntimeError(f"Failed to write command file: {e}")

        for _ in range(timeout * 10):
            if self.nuke_process and self.nuke_process.poll() is not None:
                raise RuntimeError(
                    f"Nuke server process died (exit code: {self.nuke_process.returncode})"
                )

            if self.response_file.exists():
                try:
                    with open(self.response_file, "r") as f:
                        result = json.load(f)

                    response_op_id = result.get("operation_id")
                    if response_op_id and response_op_id != operation_id:
                        logger.debug(f"Discarding stale response op={response_op_id[:8]}")
                        try:
                            self.response_file.unlink()
                        except OSError:
                            pass
                        time.sleep(0.1)
                        continue

                    result["total_time"] = time.time() - request_start
                    logger.debug(
                        f"✓ {operation_type} completed in {result['total_time']*1000:.0f}ms"
                    )
                    return result
                except (json.JSONDecodeError, IOError):
                    pass

            time.sleep(0.1)

        elapsed = time.time() - request_start
        raise TimeoutError(f"Nuke command '{operation_type}' timed out after {elapsed:.1f}s")

    # ──────────────────────────────────────────────────
    # Teardown / health
    # ──────────────────────────────────────────────────

    def _cleanup_process(self):
        if self.nuke_process:
            try:
                self.nuke_process.terminate()
                try:
                    self.nuke_process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.nuke_process.kill()
                    self.nuke_process.wait()
            except Exception:
                pass
            self.nuke_process = None

    def shutdown(self):
        logger.info("🛑 Shutting down Nuke persistent server...")
        self._cleanup_process()

        for f in (self.command_file, self.response_file, self.ready_file):
            if f.exists():
                try:
                    f.unlink()
                except Exception:
                    pass

        self.is_ready = False
        logger.info("✓ Nuke server shutdown complete")

    def is_alive(self) -> bool:
        if not self.is_ready:
            return False
        if not self.nuke_process:
            return False
        if self.nuke_process.poll() is not None:
            logger.warning("⚠️ Nuke server process died unexpectedly")
            self.is_ready = False
            return False
        return True

    def get_status(self) -> Dict[str, Any]:
        return {
            "is_ready": self.is_ready,
            "is_alive": self.is_alive(),
            "pid": self.nuke_process.pid if self.nuke_process else None,
            "startup_time": self.server_startup_time,
            "nuke_path": self.nuke_path,
            "ipc_directory": str(self.base_dir),
        }
