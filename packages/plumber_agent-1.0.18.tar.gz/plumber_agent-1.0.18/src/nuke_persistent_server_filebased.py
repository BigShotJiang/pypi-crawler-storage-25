"""
File-Based Nuke Persistent Server

Keeps Nuke running in terminal mode (nuke -t) to avoid the 5-10 second cold
start per operation. Communication is via file-based IPC — same pattern as
Maya / Blender / Houdini persistent servers.

Performance: ~30-50x faster than spawning Nuke per operation.
Architecture: Command queue (JSON) → Nuke executes → Response queue (JSON)

Launched by: local-dcc-agent/src/nuke_server_manager_filebased.py
Based on:    houdini_persistent_server_filebased.py
"""

import os
import sys
import time
import json
from pathlib import Path
from datetime import datetime

# Log file for diagnostics — written even before Nuke is ready.
log_file = Path(__file__).parent / "nuke_server_filebased.log"


def _serialize_result(value):
    """Preserve structured data if JSON-serializable, fallback to str()."""
    if value is None:
        return 'OK'
    try:
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        return str(value)


def log(message):
    """Write to log file with timestamp."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    try:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {message}\n")
            f.flush()
    except Exception:
        # Logging must never crash the server
        pass


log("=" * 80)
log("FILE-BASED NUKE PERSISTENT SERVER STARTING")

log("Initializing Nuke...")
start_init = time.time()

try:
    import nuke  # Available inside `nuke -t` interpreter

    # Nuke version — prefer NUKE_VERSION_STRING, fall back to env dict.
    try:
        nuke_version = nuke.NUKE_VERSION_STRING
    except AttributeError:
        try:
            nuke_version = nuke.env.get("NukeVersionString", "unknown")
        except Exception:
            nuke_version = "unknown"

    init_time = time.time() - start_init
    log(f"Nuke {nuke_version} initialized in {init_time:.2f}s")

    # Start from an empty comp for a clean state.
    nuke.scriptClear()
    log("Default comp cleared")

except Exception as e:
    log(f"ERROR during Nuke initialization: {e}")
    import traceback
    log(f"Traceback:\n{traceback.format_exc()}")
    sys.exit(1)


def process_command(command_data):
    """
    Execute a Nuke Python snippet and return the result.

    Expected command_data:
        {
            "command": "<python code>",
            "operation_type": "<label for logging>"
        }

    The executed snippet can set a top-level `result` variable; if it's
    JSON-serializable it's returned verbatim, otherwise str()'d.
    """
    command = command_data.get('command', '')
    operation_type = command_data.get('operation_type', 'generic')
    operation_id = command_data.get('operation_id')  # Echoed back for stale-response rejection

    log(f"Executing: {operation_type} (op={operation_id[:8] if operation_id else 'none'})")
    log(f"Command preview: {command[:200] if len(command) > 200 else command}")

    exec_start = time.time()
    exec_globals = {
        'nuke': nuke,
        'result': None,
    }

    try:
        # Capture print output so nodes can surface logs if they want.
        import io
        stdout_capture = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = stdout_capture

        try:
            exec(command, exec_globals)
        finally:
            sys.stdout = old_stdout

        captured_output = stdout_capture.getvalue()
        exec_time = time.time() - exec_start

        result = {
            'operation_id': operation_id,
            'success': True,
            'result': _serialize_result(exec_globals.get('result', 'OK')),
            'execution_time': exec_time,
        }

        if captured_output:
            result['output'] = captured_output
            log(f"Command output: {captured_output[:200]}")

        log(f"Success in {exec_time*1000:.1f}ms")
        return result

    except Exception as e:
        exec_time = time.time() - exec_start
        error_msg = str(e)
        log(f"ERROR: {error_msg}")

        import traceback
        log(f"Traceback:\n{traceback.format_exc()}")

        return {
            'operation_id': operation_id,
            'success': False,
            'result': None,
            'error': error_msg,
            'execution_time': exec_time,
        }


def run_server(command_file: Path, response_file: Path, ready_file: Path):
    """
    Main server loop — poll command file, execute, write response.
    """
    log("=" * 80)
    log("NUKE SERVER READY — Monitoring command queue")
    log(f"Command file: {command_file}")
    log(f"Response file: {response_file}")
    log(f"Ready file: {ready_file}")

    try:
        nuke_version = nuke.NUKE_VERSION_STRING
    except AttributeError:
        nuke_version = nuke.env.get("NukeVersionString", "unknown") if hasattr(nuke, "env") else "unknown"

    ready_data = {
        'status': 'ready',
        'nuke_version': nuke_version,
        'pid': os.getpid(),
        'started_at': datetime.now().isoformat(),
    }

    with open(ready_file, 'w') as f:
        json.dump(ready_data, f, indent=2)

    log(f"Ready file written — Server PID: {os.getpid()}")

    last_command_time = None

    while True:
        try:
            if command_file.exists():
                current_mtime = command_file.stat().st_mtime

                if last_command_time is None or current_mtime != last_command_time:
                    last_command_time = current_mtime
                    log("Command file detected")

                    try:
                        with open(command_file, 'r') as f:
                            command_data = json.load(f)

                        log(f"Command received: {command_data.get('operation_type', 'unknown')}")

                        result = process_command(command_data)

                        with open(response_file, 'w') as f:
                            json.dump(result, f, indent=2)

                        log("Response written")

                        try:
                            command_file.unlink()
                            log("Command file deleted (execution complete)")
                        except Exception as e:
                            log(f"Warning: could not delete command file: {e}")

                    except (json.JSONDecodeError, IOError) as e:
                        log(f"Error reading command file: {e}")
                        error_result = {
                            'success': False,
                            'error': f'Failed to read command: {e}',
                            'execution_time': 0.0,
                        }
                        with open(response_file, 'w') as f:
                            json.dump(error_result, f, indent=2)

            time.sleep(0.05)  # 50ms poll

        except KeyboardInterrupt:
            log("Server shutdown requested (Ctrl+C)")
            break

        except Exception as e:
            log(f"ERROR in main loop: {e}")
            import traceback
            log(f"Traceback:\n{traceback.format_exc()}")
            time.sleep(1)

    log("=" * 80)
    log("NUKE SERVER SHUTDOWN")


if __name__ == "__main__":
    # Manual argument parsing — nuke -t passes args through sys.argv but the
    # exact layout depends on the version. Parse defensively.
    log(f"sys.argv: {sys.argv}")

    command_file_path = None
    response_file_path = None
    ready_file_path = None

    i = 0
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg == "--command-file" and i + 1 < len(sys.argv):
            command_file_path = sys.argv[i + 1]
            i += 2
        elif arg == "--response-file" and i + 1 < len(sys.argv):
            response_file_path = sys.argv[i + 1]
            i += 2
        elif arg == "--ready-file" and i + 1 < len(sys.argv):
            ready_file_path = sys.argv[i + 1]
            i += 2
        else:
            i += 1

    if not all([command_file_path, response_file_path, ready_file_path]):
        log("ERROR: Missing required arguments")
        log(f"  command-file:  {command_file_path}")
        log(f"  response-file: {response_file_path}")
        log(f"  ready-file:    {ready_file_path}")
        sys.exit(1)

    run_server(Path(command_file_path), Path(response_file_path), Path(ready_file_path))
