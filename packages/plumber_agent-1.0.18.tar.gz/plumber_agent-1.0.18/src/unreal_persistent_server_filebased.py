"""
File-Based Unreal Engine Persistent Server

Uses file-based IPC (command/response queues) for communication.
This script runs INSIDE UnrealEditor-Cmd.exe via -ExecutePythonScript.

Architecture: Agent writes command.json -> UE executes -> writes response.json

Note: The 'unreal' module is available because this runs inside the Editor process.
"""

import os
import sys
import time
import json
from pathlib import Path
from datetime import datetime

# Log file for diagnostics
log_file = Path(__file__).parent / "unreal_server_filebased.log"


def _serialize_result(value):
    """Preserve structured data if JSON-serializable, fallback to str()."""
    if value is None:
        return 'OK'
    try:
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        return str(value)


def log(message):
    """Write to log file with timestamp."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")
        f.flush()


log("=" * 80)
log("FILE-BASED UNREAL ENGINE PERSISTENT SERVER STARTING")

# Try to import unreal module (available inside Editor)
try:
    import unreal
    engine_version = str(unreal.SystemLibrary.get_engine_version())
    log(f"Unreal Engine {engine_version} available")
except ImportError:
    engine_version = "unknown"
    unreal = None
    log("WARNING: 'unreal' module not available - running outside Editor context")


def process_command(command_data):
    """
    Execute a Python command and return the result.

    Args:
        command_data: Dict with 'command' and 'operation_type'

    Returns:
        Dict with execution result
    """
    command = command_data.get('command', '')
    operation_type = command_data.get('operation_type', 'generic')
    operation_id = command_data.get('operation_id')  # Echoed back for stale-response rejection

    log(f"Executing: {operation_type} (op={operation_id[:8] if operation_id else 'none'})")
    log(f"Command preview: {command[:200] if len(command) > 200 else command}")

    exec_start = time.time()
    exec_globals = {
        'unreal': unreal,
        'result': None
    }

    try:
        # Capture print output
        import io
        stdout_capture = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = stdout_capture

        exec(command, exec_globals)

        sys.stdout = old_stdout
        captured_output = stdout_capture.getvalue()

        exec_time = time.time() - exec_start

        result = {
            'operation_id': operation_id,
            'success': True,
            'result': _serialize_result(exec_globals.get('result', 'OK')),
            'execution_time': exec_time
        }

        log(f"Success in {exec_time*1000:.1f}ms")
        if captured_output:
            log(f"Output: {captured_output.strip()}")
        log(f"Result: {result['result']}")
        return result

    except Exception as e:
        sys.stdout = old_stdout if 'old_stdout' in locals() else sys.stdout

        exec_time = time.time() - exec_start
        result = {
            'operation_id': operation_id,
            'success': False,
            'error': str(e),
            'execution_time': exec_time
        }
        log(f"Error: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")
        return result


def run_server(command_file, response_file, ready_file):
    """
    Run the file-based Unreal server.

    Args:
        command_file: Path to command queue file
        response_file: Path to response queue file
        ready_file: Path to ready indicator file
    """
    log(f"Command queue: {command_file}")
    log(f"Response queue: {response_file}")
    log(f"Ready indicator: {ready_file}")

    # Create ready file to signal we're initialized
    try:
        with open(ready_file, 'w') as f:
            ready_data = {
                'status': 'ready',
                'unreal_version': engine_version,
                'pid': os.getpid(),
                'started_at': datetime.now().isoformat()
            }
            json.dump(ready_data, f)
        log(f"Ready file created: {ready_file}")
    except Exception as e:
        log(f"ERROR creating ready file: {e}")
        sys.exit(1)

    log("=" * 80)
    log("UNREAL SERVER READY - Monitoring command queue")
    log("=" * 80)

    # Main loop: monitor command file
    last_command_mtime = 0

    while True:
        try:
            if os.path.exists(command_file):
                current_mtime = os.path.getmtime(command_file)

                if current_mtime > last_command_mtime:
                    last_command_mtime = current_mtime

                    try:
                        with open(command_file, 'r') as f:
                            command_data = json.load(f)

                        log(f"Command received: {command_data.get('operation_type', 'unknown')}")

                        result = process_command(command_data)

                        with open(response_file, 'w') as f:
                            json.dump(result, f)

                        log(f"Response written to {response_file}")

                        try:
                            os.remove(command_file)
                            log("Command file removed")
                        except:
                            pass

                    except json.JSONDecodeError as e:
                        log(f"ERROR parsing command JSON: {e}")
                    except Exception as e:
                        log(f"ERROR processing command: {e}")
                        error_result = {
                            'success': False,
                            'error': str(e),
                            'execution_time': 0
                        }
                        try:
                            with open(response_file, 'w') as f:
                                json.dump(error_result, f)
                        except:
                            pass

            time.sleep(0.1)

        except KeyboardInterrupt:
            log("Received shutdown signal")
            break
        except Exception as e:
            log(f"ERROR in main loop: {e}")
            time.sleep(1)

    log("=" * 80)
    log("UNREAL SERVER SHUTTING DOWN")
    log("=" * 80)


if __name__ == "__main__":
    # Parse args manually (Unreal's -ExecutePythonScript doesn't pass args through argparse cleanly)
    command_file = None
    response_file = None
    ready_file = None

    args = sys.argv[1:]
    i = 0
    while i < len(args):
        if args[i] == "--command-file" and i + 1 < len(args):
            command_file = args[i + 1]
            i += 2
        elif args[i] == "--response-file" and i + 1 < len(args):
            response_file = args[i + 1]
            i += 2
        elif args[i] == "--ready-file" and i + 1 < len(args):
            ready_file = args[i + 1]
            i += 2
        else:
            i += 1

    if not all([command_file, response_file, ready_file]):
        log("ERROR: Missing required arguments (--command-file, --response-file, --ready-file)")
        print("Usage: --command-file <path> --response-file <path> --ready-file <path>")
        sys.exit(1)

    log(f"Args: command={command_file}, response={response_file}, ready={ready_file}")
    run_server(command_file, response_file, ready_file)
