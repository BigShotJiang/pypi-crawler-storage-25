"""Public package interface for the Modus SDK."""

__version__ = "0.0.1"


def init(api_key: str) -> None:
    """Initialize the Modus SDK.

    Args:
        api_key: API key used to authenticate with Modus.
    """
    pass
