# Guide complet — Système de Notifications SSE

## Table des matières

1. [Vue d'ensemble](#vue-densemble)
2. [Architecture](#architecture)
3. [Backend — Composants Python](#backend--composants-python)
4. [Endpoint SSE — API REST](#endpoint-sse--api-rest)
5. [Types d'événements SSE](#types-dévénements-sse)
6. [Frontend — Intégration client](#frontend--intégration-client)
7. [Gestion des sessions et changement de session](#gestion-des-sessions-et-changement-de-session)
8. [Diagrammes de séquence](#diagrammes-de-séquence)
9. [Guide d'intégration Frontend (pour les devs front)](#guide-dintégration-frontend-pour-les-devs-front)
10. [Tests existants](#tests-existants)
11. [Erreurs connues et corrections passées](#erreurs-connues-et-corrections-passées)

---

## Vue d'ensemble

Le système de notifications SSE (Server-Sent Events) permet au frontend de recevoir des événements temps réel depuis le backend sans polling. Il est utilisé pour :

- Notifier la fin d'un stream de réponse agent (`stream_complete`)
- Notifier le spawn et la complétion de sous-agents (`subagent_spawn`, `subagent_result`)
- Notifier les erreurs de sous-agents (`error`)

Ce système est **distinct** du streaming de réponse agent (endpoint `/stream`). Le streaming SSE de réponse utilise `POST /stream` et envoie les chunks de texte/activités en temps réel. Les notifications SSE utilisent `GET /notifications` et envoient des événements de lifecycle (spawn, result, error, stream_complete).

### Deux flux SSE distincts

| Flux | Endpoint | Méthode | Rôle |
|------|----------|---------|------|
| Streaming réponse | `/sessions/{session_id}/stream` | POST | Chunks de texte, activités, routing |
| Notifications | `/notifications?session_id=...` | GET | Événements de lifecycle (spawn, result, error, stream_complete) |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         BACKEND (Python)                         │
│                                                                  │
│  ┌──────────────────┐     ┌──────────────────┐                  │
│  │ SubagentExecutor  │────▶│  NotificationHub  │                  │
│  │                    │     │  (pub/sub mémoire)│                  │
│  │ • subagent_spawn   │     │                    │                  │
│  │ • subagent_result  │     │  subscribe(sid)    │                  │
│  │ • error            │     │  unsubscribe(sid,q)│                  │
│  └──────────────────┘     │  publish(sid, evt)  │                  │
│                            └────────┬───────────┘                  │
│  ┌──────────────────┐              │                              │
│  │ handle_stream_   │              │                              │
│  │ endpoint()       │──────────────┘                              │
│  │ • stream_complete │                                            │
│  └──────────────────┘              │                              │
│                                     ▼                              │
│  ┌──────────────────────────────────────────────┐                │
│  │ GET /notifications?session_id=X&user_id=Y     │                │
│  │ handle_notifications_endpoint()                │                │
│  │                                                │                │
│  │ 1. hub.subscribe(session_id) → Queue           │                │
│  │ 2. Boucle: queue.get(timeout=15s)              │                │
│  │    - événement → yield "event: {type}\n..."    │                │
│  │    - timeout   → yield ": keepalive\n\n"       │                │
│  │ 3. finally: hub.unsubscribe(session_id, queue) │                │
│  └──────────────────────────────────────────────┘                │
└──────────────────────────────────────────────────────────────────┘
                              │ SSE
                              ▼
┌──────────────────────────────────────────────────────────────────┐
│                       FRONTEND (JavaScript)                       │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐     │
│  │ connectNotifications(sessionId, userId)                   │     │
│  │                                                           │     │
│  │ EventSource → GET /notifications?session_id=X&user_id=Y   │     │
│  │                                                           │     │
│  │ Handlers:                                                 │     │
│  │  • stream_complete  → loadMessages()                      │     │
│  │  • subagent_result  → remove indicator + loadMessages()   │     │
│  │  • subagent_spawn   → afficher indicateur progression     │     │
│  │  • error            → afficher notification erreur        │     │
│  │  • onerror          → reconnexion backoff exponentiel     │     │
│  └─────────────────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────────────────┘
```

---

## Backend — Composants Python

### NotificationHub (`agent_framework/notifications/hub.py`)

Composant central de pub/sub en mémoire. Gère les abonnements par session via des `asyncio.Queue`.

```python
class NotificationHub:
    """Per-session event pub/sub pour notifications SSE."""

    def __init__(self) -> None:
        self._subscriptions: dict[str, set[asyncio.Queue[dict[str, Any]]]] = {}
        self._lock = asyncio.Lock()

    async def subscribe(self, session_id: str) -> asyncio.Queue:
        """Crée une queue bornée (100 items) pour un subscriber."""

    async def unsubscribe(self, session_id: str, queue: asyncio.Queue) -> None:
        """Retire une queue. Supprime la session si plus de subscribers."""

    async def publish(self, session_id: str, event: dict[str, Any]) -> None:
        """Distribue un événement à tous les subscribers d'une session.
        Non-bloquant, best-effort. Si une queue est pleine, l'événement
        est droppé pour ce subscriber uniquement (log warning)."""
```

Caractéristiques clés :
- Queue bornée à **100 items** par subscriber (évite les fuites mémoire)
- `publish()` utilise `put_nowait()` — jamais bloquant
- Protégé par `asyncio.Lock` pour la thread-safety
- Si un subscriber est lent, ses événements sont droppés silencieusement (log warning)
- Nettoyage automatique : quand le dernier subscriber d'une session se désinscrit, l'entrée session est supprimée

### Initialisation au démarrage (`agent_framework/web/server.py`)

Le `NotificationHub` est créé au démarrage de l'application FastAPI et stocké dans `app.state` :

```python
# Dans le lifespan de l'app FastAPI
notification_hub = NotificationHub()
app.state.notification_hub = notification_hub

# Injecté dans le SubagentExecutor
subagent_executor = SubagentExecutor(
    storage=session_storage,
    message_injector=message_injector,
    default_agent_class=agent_class,
    notification_hub=notification_hub,
    retrigger=retrigger,
)
```

### Points de publication des événements

| Événement | Source | Fichier | Méthode |
|-----------|--------|---------|---------|
| `subagent_spawn` | SubagentExecutor | `subagents/executor.py` | `execute()` |
| `subagent_result` | SubagentExecutor | `subagents/executor.py` | `_run_child_agent()` |
| `error` | SubagentExecutor | `subagents/executor.py` | `_handle_failure()` |
| `stream_complete` | Stream endpoint | `web/server.py` | `handle_stream_endpoint()` → `stream_generator()` |
| `stream_complete` | InternalRetrigger | `subagents/retrigger.py` | `retrigger_parent()` |

Toutes les publications sont **best-effort** : wrappées dans `try/except Exception` avec un `logger.warning` en cas d'échec. Aucune publication ne bloque jamais le flux principal.

---

## Endpoint SSE — API REST

### `GET /notifications`

Endpoint SSE pour les notifications temps réel d'une session.

#### Paramètres

| Paramètre | Type | Requis | Description |
|-----------|------|--------|-------------|
| `session_id` | string (query) | Oui | ID de la session à écouter |
| `user_id` | string (query) | Non | ID utilisateur (défaut: `default_user`) |

#### Headers de réponse

```
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive
X-Accel-Buffering: no
```

Le header `X-Accel-Buffering: no` est important pour désactiver le buffering nginx/reverse proxy.

#### Format SSE

Chaque événement suit le format standard SSE :

```
event: {type}\ndata: {json}\n\n
```

Exemple concret :

```
event: subagent_spawn
data: {"type":"subagent_spawn","session_id":"abc-123","child_session_id":"def-456","task":"Analyser les données","timestamp":"2026-04-07T10:30:00Z"}

```

#### Keepalive

Toutes les **15 secondes** sans événement, le serveur envoie un commentaire SSE :

```
: keepalive

```

Les commentaires SSE (lignes commençant par `:`) sont ignorés par l'API `EventSource` du navigateur. Ils servent à maintenir la connexion ouverte et éviter les timeouts des proxies (CloudFront, ALB, nginx).

#### Cycle de vie de la connexion

1. Le client ouvre `GET /notifications?session_id=X`
2. Le serveur appelle `hub.subscribe(session_id)` → obtient une `Queue`
3. Boucle infinie :
   - `queue.get(timeout=15s)` → événement → `yield "event: ...\ndata: ...\n\n"`
   - Timeout → `yield ": keepalive\n\n"`
   - Client déconnecté (`request.is_disconnected()`) → sortie de boucle
4. `finally` : `hub.unsubscribe(session_id, queue)` — nettoyage garanti

#### Codes d'erreur

| Code | Condition |
|------|-----------|
| 503 | `NotificationHub` non initialisé (`notification_hub is None`) |
| 422 | `session_id` manquant |

---

## Types d'événements SSE

### 1. `subagent_spawn`

Émis quand un sous-agent est lancé. Publié dans `SubagentExecutor.execute()` après la création de la tâche asyncio.

```json
{
    "type": "subagent_spawn",
    "session_id": "parent-session-id",
    "child_session_id": "child-session-uuid",
    "task": "Description de la tâche du sous-agent",
    "timestamp": "2026-04-07T10:30:00.000000+00:00"
}
```

| Champ | Type | Description |
|-------|------|-------------|
| `type` | string | Toujours `"subagent_spawn"` |
| `session_id` | string | ID de la session parente (celle du client) |
| `child_session_id` | string | UUID de la session du sous-agent |
| `task` | string | Description de la tâche assignée au sous-agent |
| `timestamp` | string (ISO 8601) | Horodatage UTC |

### 2. `subagent_result`

Émis quand un sous-agent termine avec succès. Publié dans `SubagentExecutor._run_child_agent()` après l'injection du résultat dans la session parente et le retrigger.

```json
{
    "type": "subagent_result",
    "session_id": "parent-session-id",
    "child_session_id": "child-session-uuid",
    "interaction_id": "interaction-uuid-or-null",
    "timestamp": "2026-04-07T10:31:00.000000+00:00",
    "status": "success",
    "response_summary": "Résumé de la réponse (tronqué à 500 caractères)",
    "has_activity_part": true,
    "retrigger_skipped": false
}
```

| Champ | Type | Description |
|-------|------|-------------|
| `type` | string | Toujours `"subagent_result"` |
| `session_id` | string | ID de la session parente |
| `child_session_id` | string | UUID de la session du sous-agent |
| `interaction_id` | string \| null | ID d'interaction du retrigger (`null` si retrigger skipped ou échoué) |
| `timestamp` | string (ISO 8601) | Horodatage UTC |
| `status` | string | `"success"` pour une complétion réussie |
| `response_summary` | string | Résumé de la réponse du sous-agent, tronqué à 500 caractères |
| `has_activity_part` | boolean | `true` — indique qu'un `ActivityOutputPart` `subagent_response` a été émis |
| `retrigger_skipped` | boolean | `false` si le retrigger a été effectué, `true` si `should_retrigger` a retourné `False` |

### 3. `error`

Émis quand un sous-agent échoue. Publié dans `SubagentExecutor._handle_failure()`.

```json
{
    "type": "error",
    "session_id": "parent-session-id",
    "child_session_id": "child-session-uuid",
    "message": "Description de l'erreur",
    "timestamp": "2026-04-07T10:31:30.000000+00:00"
}
```

| Champ | Type | Description |
|-------|------|-------------|
| `type` | string | Toujours `"error"` |
| `session_id` | string | ID de la session parente |
| `child_session_id` | string | UUID du sous-agent en erreur |
| `message` | string | Message d'erreur lisible |
| `timestamp` | string (ISO 8601) | Horodatage UTC |

### 4. `stream_complete`

Émis quand le streaming de réponse agent est terminé et la réponse persistée. Publié dans `handle_stream_endpoint()` → `stream_generator()` après la persistance, et également par `InternalRetrigger.retrigger_parent()` après la persistance de la réponse retriggée.

```json
{
    "type": "stream_complete",
    "session_id": "session-id",
    "interaction_id": "interaction-uuid",
    "timestamp": "2026-04-07T10:32:00.000000+00:00"
}
```

| Champ | Type | Description |
|-------|------|-------------|
| `type` | string | Toujours `"stream_complete"` |
| `session_id` | string | ID de la session |
| `interaction_id` | string | UUID de l'interaction (échange user→agent) |
| `timestamp` | string (ISO 8601) | Horodatage UTC |
| `source` | string (optionnel) | `"retrigger"` quand émis par le retrigger, absent sinon |

Ce événement est crucial : il signale au frontend que la réponse complète est disponible en base et qu'un `loadMessages()` ramènera le message finalisé.

---

## Frontend — Intégration client

### Connexion SSE (`connectNotifications`)

Le frontend utilise l'API native `EventSource` du navigateur :

```javascript
connectNotifications(sessionId, userId) {
    // Ferme toute connexion précédente
    this.disconnectNotifications();

    const url = `${BASE_PATH}/notifications?session_id=${encodeURIComponent(sessionId)}&user_id=${encodeURIComponent(userId)}`;
    const es = new EventSource(url);
    this._notificationEventSource = es;
    this._notificationReconnectDelay = 1000;

    // Handlers pour chaque type d'événement
    es.addEventListener('subagent_result', async (e) => { ... });
    es.addEventListener('stream_complete', async (e) => { ... });
    es.addEventListener('subagent_spawn', (e) => { ... });
    es.addEventListener('error', (e) => { ... });

    // Reconnexion automatique
    es.onerror = () => {
        es.close();
        this._notificationEventSource = null;
        const delay = this._notificationReconnectDelay;
        this._notificationReconnectDelay = Math.min(delay * 2, 30000);
        setTimeout(() => {
            if (this.selectedSessionId === sessionId) {
                this.connectNotifications(sessionId, userId);
            }
        }, delay);
    };

    es.onopen = () => {
        this._notificationReconnectDelay = 1000; // Reset du backoff
    };
}
```

### Handlers d'événements

#### `stream_complete`

```javascript
es.addEventListener('stream_complete', async (e) => {
    const data = JSON.parse(e.data);
    // Guard : ignorer si l'événement n'est pas pour la session active
    if (data.session_id && data.session_id !== this.selectedSessionId) return;
    await this.loadMessages(); // Recharge les messages depuis le backend
});
```

#### `subagent_result`

```javascript
es.addEventListener('subagent_result', async (e) => {
    const data = JSON.parse(e.data);
    if (data.session_id && data.session_id !== this.selectedSessionId) return;
    // Retirer l'indicateur de progression du sous-agent
    const el = document.querySelector(`[data-child-session-id="${data.child_session_id}"]`);
    if (el) el.remove();
    await this.loadMessages();
});
```

#### `subagent_spawn`

```javascript
es.addEventListener('subagent_spawn', (e) => {
    const data = JSON.parse(e.data);
    if (data.session_id && data.session_id !== this.selectedSessionId) return;

    const childId = data.child_session_id;
    const task = data.task || 'Sous-agent en cours...';

    // Éviter les doublons
    if (document.querySelector(`[data-child-session-id="${childId}"]`)) return;

    // Créer l'indicateur de progression
    const indicator = document.createElement('div');
    indicator.className = 'subagent-progress-indicator';
    indicator.setAttribute('data-child-session-id', childId);
    indicator.innerHTML = `
        <div class="flex items-center gap-2">
            <div class="loading-spinner"></div>
            <span class="text-sm text-indigo-700">
                🤖 Sous-agent en cours : ${DOMPurify.sanitize(task.substring(0, 150))}
            </span>
        </div>
    `;

    const messagesContainer = document.getElementById('messages');
    if (messagesContainer) {
        messagesContainer.appendChild(indicator);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
});
```

#### `error`

```javascript
es.addEventListener('error', (e) => {
    if (!e.data) return; // Erreur de connexion (pas un événement serveur)

    const data = JSON.parse(e.data);
    if (data.session_id && data.session_id !== this.selectedSessionId) return;

    const message = data.message || 'Erreur inconnue';
    const childId = data.child_session_id;

    // Retirer l'indicateur de progression si présent
    if (childId) {
        const indicator = document.querySelector(`[data-child-session-id="${childId}"]`);
        if (indicator) indicator.remove();
    }

    // Afficher la notification d'erreur
    const notification = document.createElement('div');
    notification.className = 'sse-error-notification';
    notification.innerHTML = `
        <div class="flex items-center gap-2">
            <span>⚠️</span>
            <span class="text-sm">${DOMPurify.sanitize(message.substring(0, 300))}</span>
        </div>
    `;

    const messagesContainer = document.getElementById('messages');
    if (messagesContainer) {
        messagesContainer.appendChild(notification);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
});
```

### Reconnexion automatique

Le mécanisme de reconnexion utilise un backoff exponentiel :

| Tentative | Délai |
|-----------|-------|
| 1 | 1s |
| 2 | 2s |
| 3 | 4s |
| 4 | 8s |
| 5 | 16s |
| 6+ | 30s (max) |

La reconnexion ne se fait que si la session est toujours la session active (`this.selectedSessionId === sessionId`). Si l'utilisateur a changé de session entre-temps, la reconnexion est abandonnée.

Le délai est reset à 1s dès que la connexion est rétablie (`es.onopen`).

### Déconnexion

```javascript
disconnectNotifications() {
    if (this._notificationEventSource) {
        this._notificationEventSource.close();
        this._notificationEventSource = null;
    }
}
```

---

## Gestion des sessions et changement de session

Le changement de session est le cas le plus complexe du système SSE. Quand l'utilisateur change de session pendant qu'un stream est en cours, il faut :

1. Préserver l'état de streaming de l'ancienne session
2. Maintenir la connexion SSE en arrière-plan pour recevoir `stream_complete`
3. Restaurer l'état quand l'utilisateur revient

### Structures de données par session

```javascript
// Dans appState() — Alpine.js
_sessionStreamingStates: new Map(),    // Map<session_id, StreamingState>
_backgroundEventSources: new Map(),    // Map<session_id, EventSource>
_sessionsNeedingReload: new Set(),     // Set<session_id>
```

| Structure | Rôle |
|-----------|------|
| `_sessionStreamingStates` | Sauvegarde des 13 champs de streaming par session |
| `_backgroundEventSources` | Connexions SSE maintenues en arrière-plan |
| `_sessionsNeedingReload` | Sessions dont le stream s'est terminé pendant qu'on était ailleurs |

### Les 13 champs de streaming sauvegardés

```javascript
{
    isStreaming,
    currentStreamingMessage,
    streamingActivities,
    inlineActivities,
    streamingParts,
    streamingText,
    underTheHoodExpanded,
    streamingContainer,
    streamingStartTime,
    streamingMessageId,
    streamingCompleteText,
    streamingBuffer,
    hasFinalResponse,
    currentStreamingParts,
}
```

### Flux de changement de session (`selectSession`)

```
selectSession(newSessionId)
│
├── SI ancienne session a un stream en cours (isStreaming === true)
│   ├── saveStreamingState(oldSessionId)     → sauvegarde les 13 champs dans _sessionStreamingStates
│   └── moveConnectionToBackground(oldSessionId) → déplace EventSource dans _backgroundEventSources
│
├── SINON
│   └── disconnectNotifications()            → ferme la connexion SSE
│
├── resetStreamingState()                    → remet les 13 champs à zéro (UI propre)
│
├── SI _sessionsNeedingReload.has(newSessionId)
│   ├── _sessionsNeedingReload.delete(newSessionId)
│   └── loadMessages()                       → le stream s'est terminé pendant qu'on était ailleurs
│
├── SINON SI _sessionStreamingStates.has(newSessionId)
│   ├── restoreStreamingState(newSessionId)  → restaure les 13 champs
│   └── promoteBackgroundConnection(newSessionId) → ferme la bg connection, ouvre une nouvelle
│
├── SINON
│   └── loadMessages()                       → flux normal, pas d'état sauvegardé
│
└── SI _notificationEventSource === null
    └── connectNotifications(newSessionId, userId) → établit la connexion SSE
```

### Connexion en arrière-plan

Quand on quitte une session avec un stream en cours :

```javascript
moveConnectionToBackground(sessionId) {
    const es = this._notificationEventSource;
    this._notificationEventSource = null;
    this._backgroundEventSources.set(sessionId, es);

    // Écouter stream_complete en arrière-plan
    es.addEventListener('stream_complete', () => {
        this._sessionsNeedingReload.add(sessionId);
        this._sessionStreamingStates.delete(sessionId);
        es.close();
        this._backgroundEventSources.delete(sessionId);
    });
}
```

Quand on revient sur une session avec un stream en cours :

```javascript
promoteBackgroundConnection(sessionId) {
    const es = this._backgroundEventSources.get(sessionId);
    if (!es) return;
    this._backgroundEventSources.delete(sessionId);
    es.close(); // Ferme la connexion simplifiée
    this.connectNotifications(sessionId, this.currentUserId); // Ouvre une connexion complète
}
```

### Guard de session dans les handlers

Chaque handler SSE vérifie que l'événement concerne la session active :

```javascript
if (data.session_id && data.session_id !== this.selectedSessionId) return;
```

Cela empêche les événements d'une ancienne session de polluer l'UI de la session courante.

---

## Diagrammes de séquence

### Flux normal — Message agent avec sous-agent

```
Client                    Backend                  NotificationHub
  │                          │                          │
  │── POST /stream ─────────▶│                          │
  │◀── SSE chunks ──────────│                          │
  │                          │                          │
  │                          │── execute() ────────────▶│
  │                          │   (subagent_spawn)       │
  │                          │                          │
  │◀── GET /notifications ──│                          │
  │    (EventSource)         │                          │
  │                          │                          │
  │◀── event: subagent_spawn │◀─── publish() ──────────│
  │    (affiche indicateur)  │                          │
  │                          │                          │
  │                          │── _run_child_agent() ───▶│
  │                          │   (sous-agent termine)   │
  │                          │                          │
  │◀── event: subagent_result│◀─── publish() ──────────│
  │    (retire indicateur,   │                          │
  │     loadMessages())      │                          │
  │                          │                          │
  │◀── SSE: data: {done} ───│                          │
  │                          │                          │
  │                          │── stream_generator() ───▶│
  │                          │   (stream_complete)      │
  │                          │                          │
  │◀── event: stream_complete│◀─── publish() ──────────│
  │    (loadMessages())      │                          │
```

### Flux — Changement de session pendant un stream

```
Client                    Backend                  NotificationHub
  │                          │                          │
  │ [Session A — stream en cours]                       │
  │◀── SSE chunks ──────────│                          │
  │◀── event: subagent_spawn│                          │
  │                          │                          │
  │── selectSession(B) ─────│                          │
  │   saveStreamingState(A)  │                          │
  │   moveConnectionToBackground(A)                     │
  │   resetStreamingState()  │                          │
  │                          │                          │
  │── GET /notifications?session_id=B ────────────────▶│
  │                          │                          │
  │ [Session A termine en arrière-plan]                 │
  │                          │── stream_complete(A) ───▶│
  │   _sessionsNeedingReload.add(A)                     │
  │   bg EventSource(A).close()                         │
  │                          │                          │
  │── selectSession(A) ─────│                          │
  │   _sessionsNeedingReload.has(A) → true              │
  │   loadMessages()         │                          │
  │   (affiche le message finalisé)                     │
  │── GET /notifications?session_id=A ────────────────▶│
```

---

## Guide d'intégration Frontend  

### Connexion minimale

Pour intégrer les notifications SSE dans un frontend custom :

```javascript
const sessionId = 'votre-session-id';
const userId = 'votre-user-id';
const baseUrl = 'http://localhost:8000'; // URL de l'API

const es = new EventSource(
    `${baseUrl}/notifications?session_id=${encodeURIComponent(sessionId)}&user_id=${encodeURIComponent(userId)}`
);

// Événement : stream terminé → recharger les messages
es.addEventListener('stream_complete', async (e) => {
    const data = JSON.parse(e.data);
    console.log('Stream terminé, interaction:', data.interaction_id);
    // → Appeler GET /sessions/{session_id}/messages pour récupérer le message final
});

// Événement : sous-agent lancé → afficher un indicateur
es.addEventListener('subagent_spawn', (e) => {
    const data = JSON.parse(e.data);
    console.log('Sous-agent lancé:', data.child_session_id, 'tâche:', data.task);
    // → Afficher un spinner/indicateur de progression
});

// Événement : sous-agent terminé → retirer l'indicateur
es.addEventListener('subagent_result', async (e) => {
    const data = JSON.parse(e.data);
    console.log('Sous-agent terminé:', data.child_session_id);
    // → Retirer l'indicateur de progression
    // → Recharger les messages
});

// Événement : erreur sous-agent → afficher l'erreur
es.addEventListener('error', (e) => {
    if (!e.data) {
        // Erreur de connexion (pas un événement serveur)
        console.warn('Connexion SSE perdue');
        return;
    }
    const data = JSON.parse(e.data);
    console.error('Erreur:', data.message);
    // → Afficher une notification d'erreur
    // → Retirer l'indicateur de progression si data.child_session_id est présent
});

// Reconnexion automatique sur erreur de connexion
es.onerror = () => {
    console.warn('Connexion SSE interrompue, reconnexion...');
    // L'EventSource natif reconnecte automatiquement,
    // mais pour un contrôle fin, fermer et recréer manuellement
};

// Fermeture propre
function disconnect() {
    es.close();
}
```

### Points d'attention pour l'intégration

1. **Distinguer erreur de connexion et événement erreur** : Le handler `error` de `EventSource` est appelé à la fois pour les erreurs de connexion (pas de `e.data`) et pour les événements SSE de type `error` (avec `e.data`). Vérifier `e.data` avant de parser.

2. **Guard de session** : Toujours vérifier `data.session_id === currentSessionId` avant d'agir. Les événements peuvent arriver avec un léger décalage après un changement de session.

3. **Sanitisation** : Toujours sanitiser les données avant insertion dans le DOM (XSS). Le framework utilise `DOMPurify.sanitize()`.

4. **Troncature** : Les descriptions de tâches peuvent être longues. Tronquer à 150 caractères pour `subagent_spawn`, 300 pour les messages d'erreur.

5. **Idempotence** : Vérifier les doublons avant d'insérer des indicateurs (utiliser `data-child-session-id` comme clé unique).

6. **Keepalive** : Les commentaires SSE (`: keepalive`) sont gérés automatiquement par `EventSource`. Aucune action côté client.

7. **Reconnexion** : Implémenter un backoff exponentiel (1s → 30s max). Ne reconnecter que si la session est toujours active.

8. **`stream_complete` est le signal clé** : C'est l'événement qui indique que la réponse agent est persistée et disponible via `GET /sessions/{session_id}/messages`. Sans cet événement, le dernier message peut ne pas être visible dans l'historique.

### Endpoints complémentaires

| Endpoint | Méthode | Description |
|----------|---------|-------------|
| `/sessions/{session_id}/messages` | GET | Récupérer l'historique des messages |
| `/sessions/{session_id}/stream` | POST | Envoyer un message et recevoir la réponse en streaming |
| `/notifications` | GET (SSE) | Notifications temps réel |

---

## Tests existants

### Tests unitaires SSE (`tests/test_web/test_sse_notifications_unit.py`)

- `test_notifications_returns_event_stream_content_type` — Vérifie le content-type `text/event-stream`
- `test_notifications_without_session_id_returns_422` — Vérifie le rejet sans `session_id`
- `test_sse_event_format` — Vérifie le format `event: {type}\ndata: {json}\n\n`

### Tests erreur SSE (`tests/test_web/test_sse_error_notification.py`)

- Analyse statique du HTML : présence du handler, CSS, DOMPurify, troncature, fallback
- Delivery end-to-end : événements error avec/sans message, avec child_session_id

### Tests property-based subagent spawn (`tests/test_subagents/test_subagent_spawn_notification_pbt.py`)

- `test_spawn_notification_has_correct_fields` — Vérifie les champs de l'événement `subagent_spawn` (Hypothesis)
- `test_publish_failure_does_not_block_execute` — Vérifie que l'échec de publish ne bloque pas `execute()`

### Tests property-based circuits (`tests/test_subagents/test_executor_circuits_pbt.py`)

- `test_retrigger_failure_does_not_prevent_notification` — Retrigger échoue → notification quand même
- `test_notification_failure_does_not_prevent_retrigger` — Notification échoue → retrigger quand même
- `test_retrigger_completes_before_notify` — Ordre garanti : retrigger avant notification

---

## Erreurs connues et corrections passées

### Bug 1 : Fuite de session SSE (`sse-stream-session-leak`)

**Problème** : Quand l'utilisateur changeait de session, les événements SSE de l'ancienne session pouvaient déclencher des actions dans la nouvelle session (rechargement de messages parasites, indicateurs de progression fantômes).

**Cause** : 
- `disconnectNotifications()` n'était appelé qu'à l'intérieur de `connectNotifications()`, qui était la dernière étape de `selectSession()`
- Les handlers SSE ne vérifiaient pas le `session_id` de l'événement

**Fix** :
- Ajout de guards `session_id` dans tous les handlers SSE
- Appel de `disconnectNotifications()` et `resetStreamingState()` au début de `selectSession()`

### Bug 2 : Régression du fix session leak (`sse-session-switch-regression`)

**Problème** : Le fix précédent fermait immédiatement la connexion SSE et effaçait l'état de streaming au début de `selectSession()`. Résultat : le `stream_complete` n'arrivait jamais, le message final n'apparaissait pas, l'indicateur "agent thinking" restait bloqué.

**Cause** : Destruction de l'état de streaming et fermeture de la connexion SSE avant que le stream ne soit terminé côté serveur.

**Fix** :
- Gestion de l'état de streaming par session (`_sessionStreamingStates`)
- Connexions SSE en arrière-plan (`_backgroundEventSources`)
- Tracking des sessions nécessitant un reload (`_sessionsNeedingReload`)
- `saveStreamingState()` / `restoreStreamingState()` pour préserver/restaurer l'état
- `moveConnectionToBackground()` / `promoteBackgroundConnection()` pour gérer les connexions

### Bug 3 : Événement `subagent_spawn` non publié (`validate-session-notifications-sse`)

**Problème** : L'événement `subagent_spawn` n'était pas publié via le `NotificationHub`, seulement émis via `activity_callback`.

**Fix** : Ajout de la publication `subagent_spawn` dans `SubagentExecutor.execute()` avec le même pattern best-effort que les autres événements.
