# AgentFramework

**Framework-agnostic foundation for building AI agents with multi-provider LLM support**

[![PyPI version](https://badge.fury.io/py/agent-framework-lib.svg)](https://pypi.org/project/agent-framework-lib/)
[![Tests](https://github.com/Cinco-AI/AgentFramework/workflows/Tests%20%26%20Coverage/badge.svg)](https://github.com/Cinco-AI/AgentFramework/actions)
[![Coverage](https://codecov.io/gh/Cinco-AI/AgentFramework/branch/main/graph/badge.svg)](https://codecov.io/gh/Cinco-AI/AgentFramework)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## Overview

AgentFramework provides a **framework-agnostic foundation** for building production-ready AI agents that work seamlessly across different LLM frameworks (LlamaIndex, Microsoft Agent Framework, etc.).

### Key Features

🎯 **Framework Agnostic**
- Abstract base class (`BaseAgent`) compatible with any LLM framework
- Implementations for LlamaIndex and Microsoft Agent Framework included
- Easy to extend to other frameworks (LangChain, CrewAI, AutoGen, etc.)

🤖 **Multi-Provider LLM Support**
- OpenAI (GPT-5, GPT-4.5, GPT-4o)
- Anthropic (Claude Opus/Sonnet/Haiku 4.x)
- Google (Gemini 2.5 Pro/Flash)
- Automatic routing based on query complexity

🧠 **Memory Providers**
- **Memori**: SQL-based memory (SQLite, PostgreSQL, MySQL)
- **Graphiti**: Graph-based memory (FalkorDB, Neo4j)
- Hybrid mode for best of both worlds

🛠️ **21 Built-in Skills**
- **Visualization**: Charts, Mermaid diagrams, DrawIO
- **Documents**: PDF, PowerPoint, Word, Excel
- **Data**: CSV, tables, data formatting
- **Code**: Code formatting, templating
- **UI**: Forms, options blocks, images
- **Web**: Search integration
- **Meta**: Skill creator for custom capabilities

🏢 **Workspace Integration**
- Multi-user collaboration via NestJS backend
- Auto-subscribe to workspaces
- Shared artefacts and context
- User preferences via Graphiti

📦 **File Storage**
- Local filesystem
- AWS S3
- MinIO
- Google Cloud Storage
- Metadata indexing via Elasticsearch

📊 **Observability**
- OpenTelemetry integration
- Elasticsearch logging
- Kibana dashboards
- LLM metrics (tokens, latency, costs)

---

## Quick Start

### Installation

```bash
# Install base package
pip install agent-framework-lib

# Or with optional dependencies
pip install agent-framework-lib[s3,elasticsearch,memory,workspace]
```

### Create Your First Agent

```python
from agent_framework import LlamaIndexAgent

class MyAgent(LlamaIndexAgent):
    def get_agent_prompt(self) -> str:
        return "You are a helpful AI assistant."

    def get_agent_tools(self) -> list:
        return []  # Skills will auto-load on demand

# Run the agent
if __name__ == "__main__":
    from agent_framework import create_basic_agent_server
    create_basic_agent_server(MyAgent, port=8000)
```

Start the server:
```bash
python my_agent.py
```

Your agent is now running at `http://localhost:8000` with:
- Streaming API at `/api/message/stream`
- Web UI at `/`
- 21 built-in skills available on-demand

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      FastAPI Server                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │   Chat   │  │  Files   │  │ Skills   │  │Workspace │    │
│  │    API   │  │   API    │  │   API    │  │   API    │    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘    │
└─────────────────────────────────────────────────────────────┘
                             │
                    ┌────────┴────────┐
                    │  AgentManager   │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │                             │
    ┌─────────▼──────────┐       ┌─────────▼──────────┐
    │   LlamaIndexAgent  │       │  MicrosoftAgent    │
    │   (implementation) │       │  (implementation)  │
    └─────────┬──────────┘       └─────────┬──────────┘
              │                             │
              └──────────────┬──────────────┘
                             │
                    ┌────────▼────────┐
                    │   BaseAgent     │  ← Framework-agnostic core
                    │  (Skills Mixin) │
                    └────────┬────────┘
                             │
            ┌────────────────┼────────────────┐
            │                │                │
    ┌───────▼───────┐ ┌─────▼─────┐ ┌───────▼────────┐
    │  SkillRegistry│ │  Memory   │ │ StateManager   │
    │  (21 skills)  │ │  Manager  │ │  (Sessions)    │
    └───────────────┘ └───────────┘ └────────────────┘
```

---

## Documentation

- **[Getting Started](GETTING_STARTED.md)** - Installation and setup
- **[Creating Agents](CREATING_AGENTS.md)** - Build your first agent
- **[Custom Skills](CUSTOM_SKILLS_GUIDE.md)** - Extend with custom capabilities
- **[Tools & MCP](TOOLS_AND_MCP_GUIDE.md)** - Integrate external tools
- **[Workspace Integration](WORKSPACE_INTEGRATION.md)** - Multi-user collaboration
- **[Architecture](ARCHITECTURE.md)** - Deep dive into the design
- **[API Reference](api/core/base_agent.md)** - Full API documentation

---

## Use Cases

✅ **Customer Support Agents**
- Multi-provider LLM routing (cost optimization)
- File attachments (PDF analysis)
- Memory for customer history
- Workspace for team collaboration

✅ **Data Analysis Agents**
- Excel/CSV skills for data processing
- Chart generation for visualization
- PDF reports with unified_pdf skill
- S3 storage for large datasets

✅ **Content Creation Agents**
- PowerPoint/Word generation
- Mermaid diagrams for documentation
- Image generation (DALL-E integration)
- Code formatting skills

✅ **Multi-Agent Systems**
- Agent-to-Agent (A2A) protocol
- Subagent spawning (max depth configurable)
- Workspace-based collaboration
- Shared memory via Graphiti

---

## Contributing

We welcome contributions! Please see our [Contributing Guide](https://github.com/Cinco-AI/AgentFramework/blob/main/CONTRIBUTING.md).

### Development Setup

```bash
# Clone the repository
git clone https://github.com/Cinco-AI/AgentFramework.git
cd AgentFramework

# Install with uv (recommended)
uv sync --all-extras

# Install pre-commit hooks
pre-commit install

# Run tests
uv run pytest

# Run with coverage
uv run pytest --cov=agent_framework
```

---

## License

MIT License - see [LICENSE](https://github.com/Cinco-AI/AgentFramework/blob/main/LICENSE) for details.

---

## Support

- **Issues**: [GitHub Issues](https://github.com/Cinco-AI/AgentFramework/issues)
- **Discussions**: [GitHub Discussions](https://github.com/Cinco-AI/AgentFramework/discussions)
- **Email**: support@cinco.ai
