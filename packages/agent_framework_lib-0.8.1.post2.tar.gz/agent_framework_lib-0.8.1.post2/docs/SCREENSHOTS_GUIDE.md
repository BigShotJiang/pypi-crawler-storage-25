# Guide de Screenshots — AgentFramework

## Table des matières

1. [Introduction](#1-introduction)
2. [Convention de nommage](#2-convention-de-nommage)
3. [Répertoire de stockage et résolution](#3-répertoire-de-stockage-et-résolution)
4. [Liste des screenshots requis](#4-liste-des-screenshots-requis)
5. [Instructions de capture](#5-instructions-de-capture)
6. [Conseils pour des screenshots cohérents](#6-conseils-pour-des-screenshots-cohérents)

---

## 1. Introduction

Ce guide définit les conventions et les procédures pour la capture des screenshots de l'interface web d'AgentFramework. L'objectif est de maintenir une documentation visuelle cohérente, à jour et facilement maintenable.

Chaque screenshot illustre un aspect précis de la gestion des skills dans l'interface web. Ce guide sert de référence pour :

- Savoir quels screenshots sont requis pour la documentation
- Respecter une convention de nommage uniforme
- Produire des captures avec une résolution et un format constants
- Reproduire chaque capture de manière identique grâce à des instructions pas-à-pas

---

## 2. Convention de nommage

Tous les fichiers de screenshots suivent le format :

```
{section}_{description}_{resolution}.png
```

| Segment | Description | Exemples |
|---------|-------------|----------|
| `section` | Zone fonctionnelle de l'interface | `skills`, `settings`, `agents` |
| `description` | Description courte en snake_case | `tab_overview`, `creation_form`, `content_display` |
| `resolution` | Dimensions en pixels (largeur×hauteur) | `1280x720` |

**Exemples de noms de fichiers :**

| Fichier | Description |
|---------|-------------|
| `skills_tab_overview_1280x720.png` | Vue d'ensemble de l'onglet Skills |
| `skills_creation_form_1280x720.png` | Formulaire de création d'un skill |
| `skills_modification_form_1280x720.png` | Formulaire de modification d'un skill |
| `skills_content_display_1280x720.png` | Affichage du contenu d'un skill |

**Règles :**

- Utiliser uniquement des lettres minuscules, des chiffres et des underscores (`_`)
- Pas d'espaces ni de caractères spéciaux dans les noms de fichiers
- Toujours inclure la résolution dans le nom du fichier
- Format obligatoire : **PNG**

---

## 3. Répertoire de stockage et résolution

### Répertoire

Tous les screenshots sont stockés dans :

```
docs/screenshots/
```

Ce dossier doit être créé à la racine du répertoire `docs/` s'il n'existe pas encore.

### Résolution et format

| Paramètre | Valeur |
|-----------|--------|
| Largeur | 1280 pixels |
| Hauteur | 720 pixels |
| Format | PNG |
| Résolution cible | **1280×720** |

La résolution 1280×720 offre un bon compromis entre lisibilité et taille de fichier. Elle correspond à un affichage HD standard et s'intègre bien dans la documentation Markdown.

---

## 4. Liste des screenshots requis

Le tableau ci-dessous liste les screenshots nécessaires pour documenter la gestion des skills dans l'interface web.

| # | Nom du fichier | Description | Section documentée |
|---|---------------|-------------|-------------------|
| 1 | `skills_tab_overview_1280x720.png` | Vue d'ensemble de l'onglet Skills avec la liste des skills disponibles | Onglet Skills |
| 2 | `skills_creation_form_1280x720.png` | Formulaire de création d'un nouveau custom skill | Création de skill |
| 3 | `skills_modification_form_1280x720.png` | Formulaire de modification d'un custom skill existant | Modification de skill |
| 4 | `skills_content_display_1280x720.png` | Affichage du contenu et des instructions d'un skill | Contenu d'un skill |

---

## 5. Instructions de capture

### 5.1 Onglet Skills — Vue d'ensemble

**Fichier :** `skills_tab_overview_1280x720.png`

**Objectif :** Montrer la page principale de l'onglet Skills avec la liste des skills disponibles (builtin et custom).

**Étapes :**

1. Lancer l'application AgentFramework localement (`uv run python -m agent_framework`)
2. Ouvrir le navigateur à l'adresse de l'interface web (par défaut `http://localhost:8000`)
3. Redimensionner la fenêtre du navigateur à **1280×720 pixels**
4. Naviguer vers l'onglet **Skills** dans le menu principal
5. S'assurer que la liste affiche au moins quelques skills (builtin et/ou custom) pour illustrer le contenu
6. Vérifier que la page est entièrement chargée (pas de spinner ni de contenu en cours de chargement)
7. Capturer la fenêtre du navigateur

---

### 5.2 Formulaire de création de skill

**Fichier :** `skills_creation_form_1280x720.png`

**Objectif :** Montrer le formulaire vierge de création d'un nouveau custom skill.

**Étapes :**

1. Depuis l'onglet Skills, cliquer sur le bouton de création d'un nouveau skill
2. Attendre que le formulaire de création s'affiche complètement
3. Laisser le formulaire **vide** (ne pas remplir les champs) pour montrer la structure du formulaire avec les labels et les placeholders
4. S'assurer que tous les champs du formulaire sont visibles à l'écran (scroller si nécessaire pour montrer l'ensemble)
5. Capturer la fenêtre du navigateur

---

### 5.3 Formulaire de modification de skill

**Fichier :** `skills_modification_form_1280x720.png`

**Objectif :** Montrer le formulaire de modification d'un custom skill existant, pré-rempli avec des données.

**Étapes :**

1. S'assurer qu'au moins un custom skill existe dans l'application (en créer un au préalable si nécessaire)
2. Depuis l'onglet Skills, sélectionner un custom skill existant
3. Cliquer sur le bouton de modification (édition) du skill
4. Attendre que le formulaire s'affiche avec les données pré-remplies du skill
5. Vérifier que les champs contiennent bien les valeurs actuelles du skill (nom, description, instructions, etc.)
6. Capturer la fenêtre du navigateur

---

### 5.4 Affichage du contenu d'un skill

**Fichier :** `skills_content_display_1280x720.png`

**Objectif :** Montrer l'affichage détaillé du contenu d'un skill, incluant ses instructions et ses métadonnées.

**Étapes :**

1. Depuis l'onglet Skills, sélectionner un skill (builtin ou custom) qui possède des instructions détaillées
2. Cliquer sur le skill pour afficher son contenu détaillé
3. Vérifier que les éléments suivants sont visibles :
   - Le nom et la description du skill
   - Les instructions (corps Markdown)
   - Les métadonnées (trigger patterns, dépendances, etc.) si affichées
4. Si le contenu est long, positionner le scroll pour montrer la partie la plus représentative
5. Capturer la fenêtre du navigateur

---

## 6. Conseils pour des screenshots cohérents

### Paramètres du navigateur

- Utiliser **Google Chrome** ou **Chromium** pour la cohérence entre les captures
- Désactiver les extensions de navigateur qui modifient l'apparence des pages (ad blockers avec indicateurs visuels, thèmes, etc.)
- Utiliser le **thème par défaut** du navigateur (pas de thème sombre sauf si c'est le thème par défaut de l'application)
- Désactiver la barre de favoris pour maximiser l'espace utile

### Dimensions de la fenêtre

Pour obtenir une capture exacte de 1280×720 pixels :

1. Ouvrir les **DevTools** du navigateur (F12)
2. Activer le mode **Device Toolbar** (Ctrl+Shift+M / Cmd+Shift+M)
3. Définir les dimensions à **1280×720**
4. Utiliser la fonction de capture d'écran intégrée aux DevTools :
   - Ouvrir le menu des DevTools (trois points) → **Capture screenshot**
   - Ou via la palette de commandes (Ctrl+Shift+P / Cmd+Shift+P) → taper « Capture screenshot »

### Contenu de la page

- S'assurer que la page est **entièrement chargée** avant la capture (pas de spinners, pas de contenu partiel)
- Utiliser des **données réalistes** mais non sensibles dans les formulaires pré-remplis
- Éviter les données personnelles (noms, emails, etc.) dans les captures
- Privilégier un skill d'exemple avec un nom descriptif (ex : `mon-skill-exemple`)

### Qualité de l'image

- Format **PNG** obligatoire (pas de JPEG, pas de WebP)
- Ne pas compresser les images après la capture
- Ne pas ajouter d'annotations, de flèches ou de cadres directement sur les screenshots (utiliser le Markdown dans la documentation pour les légendes)
- Vérifier que le texte est lisible et net sur le screenshot final
