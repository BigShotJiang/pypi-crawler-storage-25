"""Injects system messages into existing sessions."""

from __future__ import annotations

import logging
import uuid

from agent_framework.session.session_storage import MessageData, SessionStorageInterface
from agent_framework.tools.activity_callback import ActivityCallback, make_activity_part

from .message_queue import SessionMessageQueue

logger = logging.getLogger(__name__)


class MessageInjector:
    """Injects system messages into existing sessions.

    Persists the message via ``SessionStorageInterface``, enqueues it in a
    ``SessionMessageQueue`` for consumption by the parent agent, and
    optionally emits an activity event.
    """

    def __init__(
        self,
        storage: SessionStorageInterface,
        activity_callback: ActivityCallback | None = None,
    ) -> None:
        self._storage = storage
        self._activity_callback = activity_callback
        self._queue = SessionMessageQueue()

    async def inject_message(
        self,
        session_id: str,
        content: str,
        source: str,
        user_id: str = "system",
    ) -> bool:
        """Push a system message into the identified session.

        Persists the message, enqueues it for the parent agent, and emits
        an activity event.  Never raises — returns ``False`` when the
        session does not exist or persistence fails.

        Args:
            session_id: Target session identifier.
            content: Message body to inject.
            source: Identifier of the originating component (e.g. child session id).
            user_id: Owner of the target session. Defaults to ``"system"``.

        Returns:
            ``True`` if the message was successfully injected, ``False`` otherwise.
        """
        try:
            # Check session existence first
            session = await self._storage.load_session(user_id, session_id)
            if session is None:
                logger.warning(
                    "inject_message: session %s not found for user %s",
                    session_id,
                    user_id,
                )
                return False

            # Persist the message
            message_data = MessageData(
                message_id=str(uuid.uuid4()),
                session_id=session_id,
                user_id=user_id,
                interaction_id=str(uuid.uuid4()),
                sequence_number=0,
                message_type="subagent_result",
                role="system",
                text_content=content,
            )

            persisted = await self._storage.add_message(message_data)
            if not persisted:
                logger.error(
                    "inject_message: failed to persist message for session %s",
                    session_id,
                )
                return False

            # Enqueue for the parent agent to consume on next turn
            await self._queue.enqueue(session_id, content)

            # Emit activity event (best-effort)
            if self._activity_callback is not None:
                try:
                    part = make_activity_part(
                        activity_type="message_injection",
                        source=source,
                        content=f"Message injected into session {session_id}",
                        display_info={
                            "target_session_id": session_id,
                            "source": source,
                        },
                    )
                    self._activity_callback(part)
                except Exception:
                    logger.warning(
                        "inject_message: failed to emit activity for session %s",
                        session_id,
                        exc_info=True,
                    )

            return True

        except Exception:
            logger.error(
                "inject_message: unexpected error for session %s",
                session_id,
                exc_info=True,
            )
            return False

    def get_queue(self) -> SessionMessageQueue:
        """Return the internal ``SessionMessageQueue``."""
        return self._queue
