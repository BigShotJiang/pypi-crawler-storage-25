"""InternalRetrigger — re-triggers the parent agent after subagent completion."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from agent_framework.core.agent_interface import StructuredAgentInput

if TYPE_CHECKING:
    from agent_framework.core.agent_interface import AgentInterface
    from agent_framework.core.agent_provider import AgentManager
    from agent_framework.notifications.hub import NotificationHub
    from agent_framework.session.session_storage import SessionStorageInterface

logger = logging.getLogger(__name__)


class InternalRetrigger:
    """Re-triggers the parent agent with a subagent result via direct in-process call."""

    def __init__(
        self,
        storage: SessionStorageInterface,
        agent_manager: AgentManager,
        default_agent_class: type[AgentInterface],
        notification_hub: NotificationHub | None = None,
    ) -> None:
        self._storage = storage
        self._agent_manager = agent_manager
        self._default_agent_class = default_agent_class
        self._notification_hub = notification_hub

    async def retrigger_parent(
        self,
        parent_session_id: str,
        parent_user_id: str,
        result_text: str,
        child_session_id: str,
    ) -> str | None:
        """Re-trigger the parent agent with the subagent result.

        Instantiates the parent agent, feeds it the subagent result as a new
        message, persists the response, and returns the interaction_id.

        Args:
            parent_session_id: Session ID of the parent agent.
            parent_user_id: User ID that owns the parent session.
            result_text: Text result from the child subagent.
            child_session_id: Session ID of the completed child subagent.

        Returns:
            The interaction_id of the persisted response, or None on failure.
        """
        interaction_id = str(uuid.uuid4())

        try:
            # Load parent session to get configuration
            parent_session = await self._storage.load_session(
                parent_user_id, parent_session_id
            )
            if parent_session is None:
                logger.error(
                    "InternalRetrigger: parent session not found — "
                    "session_id=%s, user_id=%s",
                    parent_session_id,
                    parent_user_id,
                )
                return None

            # Instantiate agent: try no-arg first, fallback to kwargs
            agent_class = self._default_agent_class
            try:
                agent = agent_class()
            except TypeError:
                agent = agent_class(
                    agent_id=parent_session_id,
                    name=f"retrigger-{parent_session_id[:8]}",
                    description="Retrigger parent agent",
                )

            # Inject session storage if supported
            if hasattr(agent, "set_session_storage"):
                agent.set_session_storage(self._storage)

            # Configure session with parent's stored configuration
            config = parent_session.session_configuration or {}
            config["user_id"] = parent_user_id
            config["session_id"] = parent_session_id
            if hasattr(agent, "configure_session"):
                await agent.configure_session(config)

            # Load parent conversation history to restore context
            history = await self._storage.get_conversation_history(parent_session_id)

            # Build context-rich query with history + subagent result
            subagent_block = (
                "[SYSTÈME — Résultat du sous-agent]\n"
                "Ce message provient d'un sous-agent que TU as lancé, PAS de l'utilisateur.\n"
                "L'utilisateur attend que tu lui présentes de la meilleure façon (résumé ou non) le résultat du subagent.\n"
                "Tu DOIS inclure tout contenu visuel que l'utilisateur demandais dans ta réponse "
                "(diagrammes, code, tableaux, etc.) sans le résumer ni le tronquer.\n"
                "---\n"
                f"{result_text}"
            )
            if history:
                history_lines = []
                for msg in history:
                    role = msg.role or "unknown"
                    text = msg.text_content or ""
                    history_lines.append(f"[{role}]: {text}")
                combined_query = "\n".join(history_lines) + "\n\n" + subagent_block
            else:
                combined_query = subagent_block

            agent_input = StructuredAgentInput(query=combined_query)
            response = await agent.handle_message(parent_session_id, agent_input)

            # Persist the response (lazy import to avoid circular imports)
            from agent_framework.web.server import _persist_agent_response_to_storage

            processing_time_ms = 0.0
            model_used = None
            if hasattr(agent, "get_current_model"):
                try:
                    model_used = await agent.get_current_model(parent_session_id)
                except Exception:
                    pass

            agent_id = getattr(agent, "agent_id", None)
            agent_type = getattr(agent, "agent_type", None)

            persisted = await _persist_agent_response_to_storage(
                user_id=parent_user_id,
                session_id=parent_session_id,
                interaction_id=interaction_id,
                agent_response_obj=response,
                processing_time_ms=processing_time_ms,
                model_used=model_used,
                selection_mode=None,
                agent_id=agent_id,
                agent_type=agent_type,
            )

            if not persisted:
                logger.warning(
                    "InternalRetrigger: persistence returned False — "
                    "interaction_id=%s, session_id=%s",
                    interaction_id,
                    parent_session_id,
                )

            # Best-effort: notify frontend that a new message is available
            if persisted and self._notification_hub is not None:
                try:
                    await self._notification_hub.publish(parent_session_id, {
                        "type": "stream_complete",
                        "session_id": parent_session_id,
                        "interaction_id": interaction_id,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "source": "retrigger",
                    })
                except Exception:
                    logger.warning(
                        "InternalRetrigger: failed to publish stream_complete — "
                        "session_id=%s, interaction_id=%s",
                        parent_session_id,
                        interaction_id,
                        exc_info=True,
                    )

            return interaction_id

        except Exception:
            logger.error(
                "InternalRetrigger: failed to retrigger parent — "
                "session_id=%s, child_session_id=%s",
                parent_session_id,
                child_session_id,
                exc_info=True,
            )
            return None


__all__ = ["InternalRetrigger"]
