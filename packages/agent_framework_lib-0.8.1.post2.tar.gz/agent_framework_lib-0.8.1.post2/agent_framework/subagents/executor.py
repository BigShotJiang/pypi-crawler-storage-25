"""SubagentExecutor — orchestrates async subagent execution."""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Literal

from agent_framework.core.agent_interface import (
    ActivityOutputPart,
    StructuredAgentInput,
    TechnicalDetails,
)
from agent_framework.session.session_storage import (
    AgentLifecycleData,
    SessionData,
    SessionStorageInterface,
)
from agent_framework.tools.activity_callback import ActivityCallback, make_activity_part

from .message_injector import MessageInjector
from .spawn_tool import build_subagent_system_prompt

if TYPE_CHECKING:
    from agent_framework.capabilities.resolver import CapabilitySet
    from agent_framework.core.agent_interface import AgentInterface
    from agent_framework.notifications.hub import NotificationHub
    from agent_framework.subagents.retrigger import InternalRetrigger

logger = logging.getLogger(__name__)

_SOURCE = "SubagentExecutor"
_ICON = "🤖"

ShouldRetriggerFn = Callable[[str, str, str, Literal["success", "error"]], bool]


def _default_should_retrigger(
    parent_session_id: str,
    child_session_id: str,
    response_text: str,
    status: Literal["success", "error"],
) -> bool:
    """Default retrigger decision: always retrigger."""
    return True


class SubagentConcurrencyError(Exception):
    """Raised when the per-session concurrency limit is exceeded."""


@dataclass
class SubagentTaskInfo:
    """Metadata for a running subagent task."""

    child_session_id: str
    parent_session_id: str
    task: str
    depth: int
    asyncio_task: asyncio.Task[None]
    started_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class SubagentExecutor:
    """Orchestrates async subagent instantiation and execution."""

    def __init__(
        self,
        storage: SessionStorageInterface,
        message_injector: MessageInjector,
        default_agent_class: type[AgentInterface] | None = None,
        default_timeout: float = 300.0,
        max_concurrent_per_session: int = 5,
        notification_hub: NotificationHub | None = None,
        retrigger: InternalRetrigger | None = None,
        should_retrigger: ShouldRetriggerFn | None = None,
    ) -> None:
        self._storage = storage
        self._message_injector = message_injector
        self._default_agent_class = default_agent_class
        self._default_timeout = default_timeout
        self._max_concurrent = max_concurrent_per_session
        self._notification_hub = notification_hub
        self._retrigger = retrigger
        self._should_retrigger = should_retrigger or _default_should_retrigger

        self._active_tasks: dict[str, SubagentTaskInfo] = {}
        self._session_task_count: dict[str, int] = {}

    async def execute(
        self,
        task: str,
        parent_session_id: str,
        parent_user_id: str,
        capability_set: CapabilitySet,
        current_depth: int,
        agent_class: type[AgentInterface] | None = None,
        activity_callback: ActivityCallback | None = None,
    ) -> str:
        """Launch async subagent execution.

        Returns the child session ID immediately. The agent runs in a
        separate ``asyncio.Task``.

        Raises:
            SubagentConcurrencyError: If the concurrency limit is reached.
        """
        current_count = self._session_task_count.get(parent_session_id, 0)
        if current_count >= self._max_concurrent:
            raise SubagentConcurrencyError(
                f"Maximum concurrent subagents ({self._max_concurrent}) reached "
                f"for session {parent_session_id}"
            )

        child_session_id = str(uuid.uuid4())

        # Create child session with parent reference
        child_session_data = SessionData(
            session_id=child_session_id,
            user_id=parent_user_id,
            agent_instance_config={},
            parent_session_id=parent_session_id,
            session_configuration={
                "file_storage_session_id": parent_session_id,
            },
        )
        await self._storage.save_session(parent_user_id, child_session_id, child_session_data)

        effective_agent_class = agent_class or self._default_agent_class

        # Create the background task
        bg_task = asyncio.create_task(
            self._run_child_agent(
                child_session_id=child_session_id,
                task=task,
                parent_session_id=parent_session_id,
                parent_user_id=parent_user_id,
                capability_set=capability_set,
                current_depth=current_depth,
                agent_class=effective_agent_class,
                activity_callback=activity_callback,
            )
        )

        task_info = SubagentTaskInfo(
            child_session_id=child_session_id,
            parent_session_id=parent_session_id,
            task=task,
            depth=current_depth + 1,
            asyncio_task=bg_task,
        )
        self._active_tasks[child_session_id] = task_info
        self._session_task_count[parent_session_id] = current_count + 1

        # Emit spawn activity
        if activity_callback is not None:
            try:
                activity_callback(
                    make_activity_part(
                        activity_type="subagent_spawn",
                        source=_SOURCE,
                        content=f"Spawning subagent for: {task[:100]}",
                        display_info={
                            "icon": _ICON,
                            "session_id": child_session_id,
                            "task": task,
                            "depth": current_depth + 1,
                        },
                    )
                )
            except Exception:
                logger.warning("Failed to emit subagent_spawn activity", exc_info=True)

        # Register lifecycle event
        try:
            await self._storage.add_agent_lifecycle_event(
                AgentLifecycleData(
                    lifecycle_id=str(uuid.uuid4()),
                    agent_id=child_session_id,
                    agent_type="subagent",
                    event_type="subagent_started",
                    session_id=child_session_id,
                    user_id=parent_user_id,
                    metadata={
                        "parent_session_id": parent_session_id,
                        "task": task,
                        "depth": current_depth + 1,
                    },
                )
            )
        except Exception:
            logger.warning("Failed to register subagent_started lifecycle event", exc_info=True)

        # Publish spawn notification (best-effort, never blocks)
        if self._notification_hub is not None:
            try:
                await self._notification_hub.publish(parent_session_id, {
                    "type": "subagent_spawn",
                    "session_id": parent_session_id,
                    "child_session_id": child_session_id,
                    "task": task,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
            except Exception:
                logger.warning("Failed to publish subagent_spawn notification", exc_info=True)

        return child_session_id

    async def _run_child_agent(
        self,
        child_session_id: str,
        task: str,
        parent_session_id: str,
        parent_user_id: str,
        capability_set: CapabilitySet,
        current_depth: int,
        agent_class: type[AgentInterface] | None,
        activity_callback: ActivityCallback | None,
    ) -> None:
        """Internal execution inside the asyncio.Task."""
        # Isolate OTel context for this child task to prevent
        # "Failed to detach context" errors when the asyncio.Task
        # runs in a different context than where it was created.
        try:
            from opentelemetry import context as otel_context
            otel_token = otel_context.attach(otel_context.get_current())
        except Exception:
            otel_token = None
            otel_context = None  # type: ignore[assignment]

        start = time.monotonic()
        try:
            if agent_class is None:
                raise RuntimeError("No agent class provided and no default configured")

            # Try no-arg instantiation first (production agents hardcode their identity),
            # fall back to keyword args for agents that accept them (e.g. test stubs).
            try:
                agent = agent_class()
            except TypeError:
                agent = agent_class(
                    agent_id=child_session_id,
                    name=f"subagent-{child_session_id[:8]}",
                    description="Subagent",
                )

            system_prompt = build_subagent_system_prompt(
                task=task,
                depth=current_depth + 1,
                max_depth=capability_set.max_subagent_depth,
            )

            agent_input = StructuredAgentInput(query=task, parts=[])

            # Inject session storage for memory/persistence support
            if hasattr(agent, "set_session_storage"):
                agent.set_session_storage(self._storage)

            # Configure session with subagent system prompt
            # Use model routing to select the best model for the task
            session_config: dict[str, Any] = {
                "system_prompt": system_prompt,
                "user_id": parent_user_id,
                "session_id": child_session_id,
                "file_storage_session_id": parent_session_id,
            }
            try:
                from ..core.model_router import model_router
                routing_result = await model_router.route(
                    query=task, context="", model_preference=model_router.default_mode
                )
                session_config["model_name"] = routing_result.model
                logger.info(
                    "Subagent model routing: %s (tier=%s)",
                    routing_result.model, routing_result.tier.value,
                )
            except Exception:
                logger.debug("Model routing unavailable for subagent, using default")

            await agent.configure_session(session_config)

            # Execute with streaming for full monitoring support
            # handle_message_stream yields StructuredAgentOutput chunks;
            # the last one contains the final response_text
            final_output = None
            async def _stream_to_completion():
                nonlocal final_output
                async for output in agent.handle_message_stream(child_session_id, agent_input):
                    final_output = output
                return final_output

            await asyncio.wait_for(
                _stream_to_completion(),
                timeout=self._default_timeout,
            )

            elapsed_ms = int((time.monotonic() - start) * 1000)
            response_text = (
                getattr(final_output, "response_text", None) or str(final_output)
                if final_output else "[no response]"
            )

            # Inject result into parent session
            await self._message_injector.inject_message(
                session_id=parent_session_id,
                content=response_text,
                source=child_session_id,
                user_id=parent_user_id,
            )

            # Emit full response activity (best-effort)
            if activity_callback is not None:
                try:
                    activity_callback(
                        make_activity_part(
                            activity_type="subagent_response",
                            source=_SOURCE,
                            content=response_text,
                            display_info={
                                "icon": _ICON,
                                "friendly_name": "Réponse du sous-agent",
                                "session_id": child_session_id,
                                "task": task,
                            },
                            technical_details=TechnicalDetails(
                                function_name="_run_child_agent",
                                arguments={"task": task},
                                raw_result=response_text[:500],
                                execution_time_ms=elapsed_ms,
                                timestamp=datetime.now(timezone.utc).isoformat(),
                                status="success",
                            ),
                        )
                    )
                except Exception:
                    logger.warning("Failed to emit subagent_response activity", exc_info=True)

            # Emit completion activity
            if activity_callback is not None:
                try:
                    summary = f"Subagent {child_session_id[:8]} completed: {response_text[:100]}"
                    activity_callback(
                        make_activity_part(
                            activity_type="subagent_completion",
                            source=_SOURCE,
                            content=summary,
                            display_info={
                                "icon": _ICON,
                                "session_id": child_session_id,
                                "summary": summary,
                                "execution_time_ms": elapsed_ms,
                            },
                            technical_details=TechnicalDetails(
                                function_name="_run_child_agent",
                                arguments={"task": task},
                                raw_result=response_text[:200],
                                execution_time_ms=elapsed_ms,
                                timestamp=datetime.now(timezone.utc).isoformat(),
                                status="success",
                            ),
                        )
                    )
                except Exception:
                    logger.warning("Failed to emit subagent_completion activity", exc_info=True)

            # Register lifecycle event
            try:
                await self._storage.add_agent_lifecycle_event(
                    AgentLifecycleData(
                        lifecycle_id=str(uuid.uuid4()),
                        agent_id=child_session_id,
                        agent_type="subagent",
                        event_type="subagent_completed",
                        session_id=child_session_id,
                        user_id=parent_user_id,
                        metadata={
                            "execution_time_ms": elapsed_ms,
                            "summary": response_text[:200],
                        },
                    )
                )
            except Exception:
                logger.warning("Failed to register subagent_completed lifecycle event", exc_info=True)

            # Aggregate LLM stats from child to parent
            await self._aggregate_llm_stats(child_session_id, parent_session_id, parent_user_id)

            interaction_id = None
            retrigger_skipped = False
            try:
                do_retrigger = self._should_retrigger(
                    parent_session_id, child_session_id, response_text, "success"
                )
            except Exception:
                logger.warning(
                    "should_retrigger raised an exception, falling back to True",
                    exc_info=True,
                )
                do_retrigger = True

            if do_retrigger and self._retrigger is not None:
                try:
                    interaction_id = await self._retrigger.retrigger_parent(
                        parent_session_id=parent_session_id,
                        parent_user_id=parent_user_id,
                        result_text=response_text,
                        child_session_id=child_session_id,
                    )
                except Exception:
                    logger.warning(
                        "Retrigger failed for subagent %s",
                        child_session_id[:8],
                        exc_info=True,
                    )
            elif not do_retrigger:
                retrigger_skipped = True

            # Publish notification (best-effort, never blocks)
            if self._notification_hub is not None:
                try:
                    await self._notification_hub.publish(parent_session_id, {
                        "type": "subagent_result",
                        "session_id": parent_session_id,
                        "child_session_id": child_session_id,
                        "interaction_id": interaction_id,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "status": "success",
                        "response_summary": response_text[:500],
                        "has_activity_part": True,
                        "retrigger_skipped": retrigger_skipped,
                    })
                except Exception:
                    logger.warning("Failed to publish subagent_result notification", exc_info=True)

        except asyncio.TimeoutError:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            error_msg = (
                f"Subagent {child_session_id[:8]} timed out after "
                f"{self._default_timeout}s while executing: {task[:100]}"
            )
            await self._handle_failure(
                child_session_id=child_session_id,
                parent_session_id=parent_session_id,
                parent_user_id=parent_user_id,
                error_type="TimeoutError",
                error_message=error_msg,
                elapsed_ms=elapsed_ms,
                task=task,
                activity_callback=activity_callback,
            )

        except Exception as exc:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            error_msg = (
                f"Subagent {child_session_id[:8]} failed: "
                f"{type(exc).__name__}: {exc}"
            )
            await self._handle_failure(
                child_session_id=child_session_id,
                parent_session_id=parent_session_id,
                parent_user_id=parent_user_id,
                error_type=type(exc).__name__,
                error_message=error_msg,
                elapsed_ms=elapsed_ms,
                task=task,
                activity_callback=activity_callback,
            )

        finally:
            # Detach the OTel context token (safe even if context shifted)
            if otel_token is not None and otel_context is not None:
                try:
                    otel_context.detach(otel_token)
                except ValueError:
                    pass

            # Clean up tracking state
            self._active_tasks.pop(child_session_id, None)
            count = self._session_task_count.get(parent_session_id, 1)
            if count <= 1:
                self._session_task_count.pop(parent_session_id, None)
            else:
                self._session_task_count[parent_session_id] = count - 1

    async def _handle_failure(
        self,
        child_session_id: str,
        parent_session_id: str,
        parent_user_id: str,
        error_type: str,
        error_message: str,
        elapsed_ms: int,
        task: str,
        activity_callback: ActivityCallback | None,
    ) -> None:
        """Inject error message and emit failure events."""
        logger.error("Subagent %s failed: %s", child_session_id[:8], error_message)

        await self._message_injector.inject_message(
            session_id=parent_session_id,
            content=error_message,
            source=child_session_id,
            user_id=parent_user_id,
        )

        if activity_callback is not None:
            try:
                activity_callback(
                    make_activity_part(
                        activity_type="subagent_failed",
                        source=_SOURCE,
                        content=error_message,
                        display_info={
                            "icon": _ICON,
                            "session_id": child_session_id,
                            "error_type": error_type,
                            "error_message": error_message,
                        },
                        technical_details=TechnicalDetails(
                            function_name="_run_child_agent",
                            arguments={"task": task},
                            raw_result=error_message,
                            execution_time_ms=elapsed_ms,
                            timestamp=datetime.now(timezone.utc).isoformat(),
                            status="error",
                        ),
                    )
                )
            except Exception:
                logger.warning("Failed to emit subagent_failed activity", exc_info=True)

        try:
            await self._storage.add_agent_lifecycle_event(
                AgentLifecycleData(
                    lifecycle_id=str(uuid.uuid4()),
                    agent_id=child_session_id,
                    agent_type="subagent",
                    event_type="subagent_failed",
                    session_id=child_session_id,
                    user_id=parent_user_id,
                    metadata={
                        "error_type": error_type,
                        "error_message": error_message,
                    },
                )
            )
        except Exception:
            logger.warning("Failed to register subagent_failed lifecycle event", exc_info=True)

        # Re-trigger parent agent with the error message
        interaction_id = None
        if self._retrigger is not None:
            try:
                interaction_id = await self._retrigger.retrigger_parent(
                    parent_session_id=parent_session_id,
                    parent_user_id=parent_user_id,
                    result_text=error_message,
                    child_session_id=child_session_id,
                )
            except Exception:
                logger.warning("Retrigger failed for failed subagent %s", child_session_id[:8], exc_info=True)

        # Publish error notification (best-effort)
        if self._notification_hub is not None:
            try:
                await self._notification_hub.publish(parent_session_id, {
                    "type": "error",
                    "session_id": parent_session_id,
                    "child_session_id": child_session_id,
                    "message": error_message,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
            except Exception:
                logger.warning("Failed to publish error notification", exc_info=True)

    async def _aggregate_llm_stats(
        self,
        child_session_id: str,
        parent_session_id: str,
        parent_user_id: str,
    ) -> None:
        """Merge child session LLM stats into the parent session."""
        try:
            child_session = await self._storage.load_session(parent_user_id, child_session_id)
            if child_session is None or child_session.llm_stats is None:
                return

            parent_session = await self._storage.load_session(parent_user_id, parent_session_id)
            if parent_session is None:
                return

            child_stats = child_session.llm_stats
            if parent_session.llm_stats is None:
                parent_session.llm_stats = {
                    "total_input_tokens": 0,
                    "total_thinking_tokens": 0,
                    "total_output_tokens": 0,
                    "total_llm_calls": 0,
                    "total_duration_ms": 0.0,
                }

            for key in (
                "total_input_tokens",
                "total_thinking_tokens",
                "total_output_tokens",
                "total_llm_calls",
            ):
                parent_session.llm_stats[key] = (
                    parent_session.llm_stats.get(key, 0) + child_stats.get(key, 0)
                )
            parent_session.llm_stats["total_duration_ms"] = (
                parent_session.llm_stats.get("total_duration_ms", 0.0)
                + child_stats.get("total_duration_ms", 0.0)
            )

            await self._storage.save_session(parent_user_id, parent_session_id, parent_session)
        except Exception:
            logger.warning("Failed to aggregate LLM stats", exc_info=True)

    def get_active_tasks(self, parent_session_id: str) -> list[str]:
        """Return child session IDs of active tasks for a parent session."""
        return [
            info.child_session_id
            for info in self._active_tasks.values()
            if info.parent_session_id == parent_session_id
        ]

    async def cancel_task(self, child_session_id: str) -> bool:
        """Cancel an active subagent task.

        Returns:
            ``True`` if the task was found and cancelled, ``False`` otherwise.
        """
        task_info = self._active_tasks.get(child_session_id)
        if task_info is None:
            return False

        task_info.asyncio_task.cancel()
        return True


__all__ = [
    "ShouldRetriggerFn",
    "SubagentConcurrencyError",
    "SubagentExecutor",
    "SubagentTaskInfo",
    "_default_should_retrigger",
]
