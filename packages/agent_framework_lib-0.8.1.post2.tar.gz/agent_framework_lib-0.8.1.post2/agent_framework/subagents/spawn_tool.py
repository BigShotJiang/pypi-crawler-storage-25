"""
SubagentSpawnTool — spawns isolated agent sessions for task delegation.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from agent_framework.core.agent_interface import TechnicalDetails
from agent_framework.tools.activity_callback import ActivityCallback, make_activity_part
from agent_framework.tools.base import AgentTool


if TYPE_CHECKING:
    from agent_framework.capabilities.resolver import CapabilitySet
    from agent_framework.skills.base import SkillRegistry
    from agent_framework.subagents.executor import SubagentExecutor

_SOURCE = "SubagentSpawnTool"
_ICON = "🤖"


@dataclass
class SubagentSession:
    """Isolated agent session spawned by a parent agent."""

    session_id: str
    task: str
    depth: int
    registry: "SkillRegistry | None" = field(default=None)


def build_subagent_system_prompt(task: str, depth: int, max_depth: int) -> str:
    """Generate a minimal system prompt for a subagent.

    Args:
        task: The task assigned to the subagent.
        depth: Current spawn depth.
        max_depth: Maximum allowed spawn depth.

    Returns:
        System prompt string.
    """
    return (
        f"You are a subagent at depth {depth}/{max_depth}.\n"
        f"Your task: {task}\n"
        "Focus exclusively on this task. Do not perform actions outside its scope.\n"
        f"{'You may not spawn further subagents.' if depth >= max_depth else f'You may spawn subagents up to depth {max_depth}.'}"
    )


class SubagentSpawnTool(AgentTool):
    """Spawns isolated subagent sessions to delegate tasks."""

    def __init__(
        self,
        capability_set: "CapabilitySet",
        current_depth: int = 0,
        activity_callback: ActivityCallback | None = None,
        executor: "SubagentExecutor | None" = None,
        parent_session_id: str | None = None,
        parent_user_id: str | None = None,
        agent_class: type | None = None,
    ) -> None:
        """Initialize SubagentSpawnTool.

        Args:
            capability_set: CapabilitySet of the current session.
            current_depth: Current spawn depth (0 = top-level agent).
            activity_callback: Optional callback to emit ActivityOutputPart events.
            executor: Optional SubagentExecutor for real execution.
            parent_session_id: Session ID of the parent agent.
            parent_user_id: User ID of the parent agent.
            agent_class: Concrete agent class to use for child sessions.
        """
        super().__init__()
        self._capability_set = capability_set
        self._current_depth = current_depth
        self._activity_callback = activity_callback
        self._executor = executor
        self._parent_session_id = parent_session_id
        self._parent_user_id = parent_user_id
        self._agent_class = agent_class

    def get_tool_function(self) -> Callable[..., Any]:
        """Return the spawn_subagent callable."""

        async def spawn_subagent(
            task: str,
            skill_ids: list[str] | None = None,
            max_depth: int | None = None,
        ) -> str:
            """Spawn an isolated subagent session to execute a task.

            Args:
                task: Description of the task to delegate.
                skill_ids: Skills to activate in the subagent (optional).
                max_depth: Maximum spawn depth override (optional).

            Returns:
                Subagent session ID or error message string.
            """
            if "subagent:spawn" not in self._capability_set.native_tools:
                return "[error] Capability 'subagent:spawn' is not authorized for this session"

            effective_max_depth = (
                max_depth
                if max_depth is not None
                else self._capability_set.max_subagent_depth
            )

            if self._current_depth >= effective_max_depth:
                return (
                    f"[error] Maximum subagent depth ({effective_max_depth}) reached. "
                    "Cannot spawn further subagents."
                )

            if self._executor is not None:
                return await self._spawn_with_executor(
                    task=task,
                    skill_ids=skill_ids,
                    effective_max_depth=effective_max_depth,
                )

            return self._spawn_stub(
                task=task,
                skill_ids=skill_ids,
                effective_max_depth=effective_max_depth,
            )

        return spawn_subagent

    async def _spawn_with_executor(
        self,
        task: str,
        skill_ids: list[str] | None,
        effective_max_depth: int,
    ) -> str:
        """Delegate execution to the SubagentExecutor.

        The executor handles emitting the subagent_spawn activity
        and subagent_completion events.
        """
        from agent_framework.subagents.executor import SubagentConcurrencyError

        try:
            session_id = await self._executor.execute(  # type: ignore[union-attr]
                task=task,
                parent_session_id=self._parent_session_id or "",
                parent_user_id=self._parent_user_id or "",
                capability_set=self._capability_set,
                current_depth=self._current_depth,
                agent_class=self._agent_class,
                activity_callback=self._activity_callback,
            )
        except SubagentConcurrencyError as exc:
            return f"[error] {exc}"
        except Exception as exc:
            return f"[error] Failed to create subagent: {exc}"

        return session_id

    def _spawn_stub(
        self,
        task: str,
        skill_ids: list[str] | None,
        effective_max_depth: int,
    ) -> str:
        """Stub behavior when no executor is provided (backward compatibility)."""
        session_id = str(uuid.uuid4())

        self._emit_spawn_activity(task, skill_ids, effective_max_depth, session_id=session_id)

        _system_prompt = build_subagent_system_prompt(
            task=task,
            depth=self._current_depth + 1,
            max_depth=effective_max_depth,
        )

        result_summary = f"Subagent {session_id} completed task: {task[:80]}"

        if self._activity_callback:
            self._activity_callback(
                make_activity_part(
                    activity_type="subagent_completion",
                    source=_SOURCE,
                    content=result_summary,
                    display_info={
                        "icon": _ICON,
                        "subagent_session_id": session_id,
                        "summary": result_summary,
                    },
                    technical_details=TechnicalDetails(
                        function_name="spawn_subagent",
                        arguments={"task": task},
                        raw_result=result_summary,
                        execution_time_ms=0,
                        timestamp=make_activity_part(
                            "subagent_completion", _SOURCE
                        ).timestamp,
                        status="success",
                    ),
                )
            )

        return session_id

    def _emit_spawn_activity(
        self,
        task: str,
        skill_ids: list[str] | None,
        effective_max_depth: int,
        session_id: str | None,
    ) -> None:
        """Emit the subagent_spawn ActivityOutputPart."""
        if not self._activity_callback:
            return

        display_session_id = session_id or "pending"
        ts = make_activity_part("subagent_spawn", _SOURCE).timestamp

        self._activity_callback(
            make_activity_part(
                activity_type="subagent_spawn",
                source=_SOURCE,
                content=f"Spawning subagent for: {task[:100]}",
                display_info={
                    "icon": _ICON,
                    "subagent_session_id": display_session_id,
                    "task": task,
                    "depth": self._current_depth + 1,
                },
                technical_details=TechnicalDetails(
                    function_name="spawn_subagent",
                    arguments={
                        "task": task,
                        "skill_ids": skill_ids,
                        "max_depth": effective_max_depth,
                    },
                    raw_result=display_session_id,
                    execution_time_ms=0,
                    timestamp=ts,
                    status="success",
                ),
            )
        )

    def get_tool_info(self) -> dict[str, Any]:
        return {
            "name": self.__class__.__name__,
            "description": "Spawn an isolated subagent session to delegate a task",
            "requires_file_storage": False,
            "requires_user_context": False,
        }


__all__ = [
    "SubagentSession",
    "SubagentSpawnTool",
    "build_subagent_system_prompt",
]
