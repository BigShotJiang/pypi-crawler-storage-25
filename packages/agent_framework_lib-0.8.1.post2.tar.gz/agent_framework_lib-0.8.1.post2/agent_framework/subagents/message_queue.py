"""Per-session async message queue for pending message injection."""

from __future__ import annotations

import asyncio


class SessionMessageQueue:
    """Thread-safe per-session message queue.

    Each session gets its own ``asyncio.Queue`` created lazily on first
    enqueue.  All public mutating methods are guarded by an ``asyncio.Lock``
    to ensure safe concurrent access from multiple coroutines.
    """

    def __init__(self) -> None:
        self._queues: dict[str, asyncio.Queue[str]] = {}
        self._lock: asyncio.Lock = asyncio.Lock()

    async def enqueue(self, session_id: str, content: str) -> None:
        """Add a message to the session's queue.

        Creates the queue lazily if it does not exist yet.

        Args:
            session_id: Target session identifier.
            content: Message content to enqueue.
        """
        async with self._lock:
            if session_id not in self._queues:
                self._queues[session_id] = asyncio.Queue()
            self._queues[session_id].put_nowait(content)

    async def drain(self, session_id: str) -> list[str]:
        """Retrieve and remove all pending messages for a session.

        Non-blocking: uses ``get_nowait()`` to collect every available
        message.  Returns an empty list when no messages are pending or
        the session has no queue.

        Args:
            session_id: Target session identifier.

        Returns:
            List of pending message strings (may be empty).
        """
        async with self._lock:
            queue = self._queues.get(session_id)
            if queue is None or queue.empty():
                return []

            messages: list[str] = []
            while not queue.empty():
                try:
                    messages.append(queue.get_nowait())
                except asyncio.QueueEmpty:
                    break
            return messages

    def has_pending(self, session_id: str) -> bool:
        """Check whether the session has pending messages.

        This is a synchronous, non-blocking check.

        Args:
            session_id: Target session identifier.

        Returns:
            ``True`` if at least one message is waiting, ``False`` otherwise.
        """
        queue = self._queues.get(session_id)
        if queue is None:
            return False
        return not queue.empty()
