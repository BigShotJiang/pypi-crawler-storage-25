"""In-memory pub/sub component for per-session SSE notifications."""

import asyncio
import logging
from typing import Any

logger = logging.getLogger(__name__)


class NotificationHub:
    """Per-session event pub/sub for SSE notifications.

    Manages subscriber queues per session and distributes events
    to all active subscribers using non-blocking put operations.
    """

    def __init__(self) -> None:
        self._subscriptions: dict[str, set[asyncio.Queue[dict[str, Any]]]] = {}
        self._lock = asyncio.Lock()

    async def subscribe(self, session_id: str) -> asyncio.Queue[dict[str, Any]]:
        """Register a new subscriber for a session.

        Args:
            session_id: The session to subscribe to.

        Returns:
            A queue to await events from. Bounded to 100 items.
        """
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=100)
        async with self._lock:
            if session_id not in self._subscriptions:
                self._subscriptions[session_id] = set()
            self._subscriptions[session_id].add(queue)
        return queue

    async def unsubscribe(self, session_id: str, queue: asyncio.Queue[dict[str, Any]]) -> None:
        """Remove a subscriber's queue from a session.

        No-op if the queue was already removed or the session has no subscribers.

        Args:
            session_id: The session to unsubscribe from.
            queue: The subscriber queue to remove.
        """
        async with self._lock:
            subscribers = self._subscriptions.get(session_id)
            if subscribers is None:
                return
            subscribers.discard(queue)
            if not subscribers:
                del self._subscriptions[session_id]

    async def publish(self, session_id: str, event: dict[str, Any]) -> None:
        """Distribute an event to all active subscribers for a session.

        Non-blocking, best-effort delivery. If a subscriber's queue is full,
        the event is dropped for that subscriber only.

        Args:
            session_id: The target session.
            event: The event dict to distribute.
        """
        async with self._lock:
            subscribers = self._subscriptions.get(session_id)
            if subscribers is None:
                return
            # Snapshot to avoid mutation during iteration
            queues = list(subscribers)

        for queue in queues:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning(
                    "Dropping notification event for session %s: subscriber queue full",
                    session_id,
                )
