"""Polling-based message fetcher for local development.

Replaces webhooks when the agent is not publicly accessible.
Periodically polls the workspace API for new messages and feeds
them into the same processing pipeline as webhooks.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Awaitable

from .client import WorkspaceClient
from .cursor import CursorStore
from .models import WorkspaceMessage
from .subscription import SubscriptionRecord

logger = logging.getLogger(__name__)


class WorkspacePoller:
    """Polls workspace messages and dispatches them for processing.

    Args:
        interval: Seconds between polls.
        process_fn: Async callable (payload, workspace_id) -> None.
    """

    def __init__(
        self,
        interval: float = 5.0,
        process_fn: Callable[[dict, str], Awaitable[None]] | None = None,
    ) -> None:
        self._interval = interval
        self._process_fn = process_fn
        self._tasks: dict[str, asyncio.Task] = {}
        self._stop_events: dict[str, asyncio.Event] = {}

    def start(
        self,
        workspace_id: str,
        record: SubscriptionRecord,
        cursor_store: CursorStore,
        agent_id: str,
    ) -> None:
        """Start polling a workspace for new messages."""
        if workspace_id in self._tasks:
            logger.info("Poller already running for workspace %s", workspace_id)
            return

        stop_event = asyncio.Event()
        self._stop_events[workspace_id] = stop_event
        self._tasks[workspace_id] = asyncio.create_task(
            self._poll_loop(workspace_id, record, cursor_store, agent_id, stop_event)
        )
        logger.info("Poller started for workspace %s (interval=%.1fs)", workspace_id, self._interval)

    def stop(self, workspace_id: str) -> None:
        """Stop polling a workspace."""
        if workspace_id in self._stop_events:
            self._stop_events[workspace_id].set()
        task = self._tasks.pop(workspace_id, None)
        self._stop_events.pop(workspace_id, None)
        if task and not task.done():
            task.cancel()
        logger.info("Poller stopped for workspace %s", workspace_id)

    def stop_all(self) -> None:
        """Stop all active pollers."""
        for ws_id in list(self._tasks.keys()):
            self.stop(ws_id)

    @property
    def active_workspaces(self) -> list[str]:
        return list(self._tasks.keys())

    async def _poll_loop(
        self,
        workspace_id: str,
        record: SubscriptionRecord,
        cursor_store: CursorStore,
        agent_id: str,
        stop_event: asyncio.Event,
    ) -> None:
        """Main polling loop for a single workspace."""
        logger.info("Poll loop started for workspace %s", workspace_id)

        while not stop_event.is_set():
            try:
                await self._poll_once(workspace_id, record, cursor_store, agent_id)
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("Poll error for workspace %s", workspace_id)

            try:
                await asyncio.wait_for(stop_event.wait(), timeout=self._interval)
                break
            except asyncio.TimeoutError:
                pass

        logger.info("Poll loop ended for workspace %s", workspace_id)

    async def _poll_once(
        self,
        workspace_id: str,
        record: SubscriptionRecord,
        cursor_store: CursorStore,
        agent_id: str,
    ) -> None:
        """Single poll iteration: fetch new messages and process them."""
        client = WorkspaceClient(record.workspace_url, record.workspace_api_key, agent_id=agent_id)
        try:
            cursor = await cursor_store.load(agent_id, workspace_id)

            if cursor is None:
                messages = await client.get_messages(
                    workspace_id, after_id=None, limit=1, sort="desc",
                )
                if not messages:
                    return
                # On ne traite pas les anciens messages, on positionne juste le curseur
                # pour ne traiter que les futurs messages
                last = messages[0]
                await cursor_store.save(agent_id, workspace_id, last.id)
                logger.info(
                    "Poller initialized cursor for workspace %s at message %s",
                    workspace_id, last.id,
                )
                return

            messages = await client.get_messages(
                workspace_id, after_id=cursor, limit=50, sort="asc",
            )

            if not messages:
                return

            # Filtrer les messages agent (on ne traite que les messages utilisateur)
            user_messages = [m for m in messages if m.sender_type != "agent"]

            if not user_messages:
                # Mettre à jour le curseur même si que des messages agent
                last = messages[-1]
                await cursor_store.save(agent_id, workspace_id, last.id)
                return

            # Traiter le dernier message utilisateur (les précédents font partie du contexte)
            last_user_msg = user_messages[-1]
            logger.info(
                "Poller found %d new message(s) in workspace %s, processing last from %s",
                len(user_messages), workspace_id, last_user_msg.sender_name,
            )

            # Construire un payload webhook simulé
            payload = {
                "event": "message.created",
                "workspaceId": workspace_id,
                "message": {
                    "id": last_user_msg.id,
                    "senderId": last_user_msg.sender_id,
                    "senderName": last_user_msg.sender_name,
                    "senderType": last_user_msg.sender_type,
                    "content": last_user_msg.content,
                    "createdAt": last_user_msg.created_at,
                    "metadata": last_user_msg.metadata,
                },
            }

            if self._process_fn:
                await self._process_fn(payload, workspace_id)

        finally:
            await client.close()
