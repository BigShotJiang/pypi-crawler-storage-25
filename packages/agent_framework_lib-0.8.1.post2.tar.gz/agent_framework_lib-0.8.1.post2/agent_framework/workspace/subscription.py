"""Workspace subscription persistence via SessionStorageInterface."""

import logging
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from agent_framework.session.session_storage import SessionData, SessionStorageInterface

logger = logging.getLogger(__name__)

# Fixed user_id used to namespace all subscription records in the session store.
_SUBSCRIPTIONS_USER_ID = "__ws_subscriptions__"


@dataclass
class SubscriptionRecord:
    """Persisted workspace subscription metadata."""

    workspace_id: str
    workspace_url: str
    workspace_api_key: str
    workspace_name: str
    webhook_id: str
    subscribed_at: str
    status: str = "active"


class SubscriptionStore:
    """CRUD for workspace subscriptions backed by SessionStorageInterface.

    Uses a fixed user_id prefix and workspace_id as session_id so that
    records are stored alongside regular sessions without collisions.
    """

    def __init__(self, storage: SessionStorageInterface) -> None:
        self._storage = storage

    async def save(self, record: SubscriptionRecord) -> bool:
        """Persist a subscription record."""
        now = datetime.now(timezone.utc).isoformat()
        session_data = SessionData(
            session_id=record.workspace_id,
            user_id=_SUBSCRIPTIONS_USER_ID,
            agent_instance_config={},
            created_at=now,
            updated_at=now,
            metadata=asdict(record),
        )
        return await self._storage.save_session(
            _SUBSCRIPTIONS_USER_ID, record.workspace_id, session_data
        )

    async def load(self, workspace_id: str) -> SubscriptionRecord | None:
        """Load a subscription by workspace_id, or None if absent."""
        session = await self._storage.load_session(_SUBSCRIPTIONS_USER_ID, workspace_id)
        if session is None or session.metadata is None:
            return None
        return _record_from_metadata(session.metadata)

    async def delete(self, workspace_id: str) -> bool:
        """Delete a subscription by workspace_id."""
        return await self._storage.delete_session(_SUBSCRIPTIONS_USER_ID, workspace_id)

    async def list_all(self) -> list[SubscriptionRecord]:
        """Return all active subscription records."""
        session_ids = await self._storage.list_user_sessions(_SUBSCRIPTIONS_USER_ID)
        records: list[SubscriptionRecord] = []
        for sid in session_ids:
            record = await self.load(sid)
            if record is not None:
                records.append(record)
        return records


def _record_from_metadata(metadata: dict) -> SubscriptionRecord:
    """Reconstruct a SubscriptionRecord from a metadata dict."""
    return SubscriptionRecord(
        workspace_id=metadata["workspace_id"],
        workspace_url=metadata["workspace_url"],
        workspace_api_key=metadata["workspace_api_key"],
        workspace_name=metadata["workspace_name"],
        webhook_id=metadata["webhook_id"],
        subscribed_at=metadata["subscribed_at"],
        status=metadata.get("status", "active"),
    )
