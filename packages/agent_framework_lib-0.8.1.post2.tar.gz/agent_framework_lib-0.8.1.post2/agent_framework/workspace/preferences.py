"""Workspace user preferences provider with caching."""

import logging
import time

from ..memory.manager import MemoryManager
from .client import WorkspaceClient
from .config import WorkspaceConfig

logger = logging.getLogger(__name__)


class WorkspaceUserPreferencesProvider:
    """Loads and caches preferences for all members of a workspace via Graphiti recall.

    Fetches workspace members, recalls each human member's preferences from
    Graphiti, and formats them into a structured text block for prompt injection.

    Args:
        client: HTTP client for the Workspace Server API.
        memory_manager: Memory manager for Graphiti recall.
        config: Workspace configuration (TTL, max facts per user).
    """

    def __init__(
        self,
        client: WorkspaceClient,
        memory_manager: MemoryManager,
        config: WorkspaceConfig,
    ) -> None:
        self._client = client
        self._memory_manager = memory_manager
        self._config = config
        # Cache: {workspace_id: (timestamp, result_string)}
        self._cache: dict[str, tuple[float, str]] = {}

    async def get_all_preferences(self, workspace_id: str, agent_id: str) -> str:
        """Return a formatted block of preferences for all workspace members.

        Checks the cache first (TTL-based). On cache miss, fetches members,
        recalls preferences from Graphiti for each human member, and formats
        the result.

        Args:
            workspace_id: Target workspace.
            agent_id: Agent identifier for Graphiti recall.

        Returns:
            Structured text block with per-user preferences.
        """
        cached = self._cache.get(workspace_id)
        if cached is not None:
            ts, result = cached
            if (time.monotonic() - ts) < self._config.prefs_cache_ttl:
                return result

        members = await self._client.get_members(workspace_id)
        human_members = [m for m in members if m.member_type == "user"]

        sections: list[str] = []
        for member in human_members:
            try:
                ctx = await self._memory_manager.recall(
                    user_id=member.member_id,
                    agent_id=agent_id,
                    query="user preferences",
                    limit=self._config.prefs_max_facts_per_user,
                )
                facts = ctx.facts
            except Exception:
                logger.warning(
                    "Failed to recall preferences for member %s in workspace %s",
                    member.member_id,
                    workspace_id,
                    exc_info=True,
                )
                facts = []

            header = f"## {member.member_name} ({member.member_id}, role: {member.role})"
            if facts:
                lines = "\n".join(f"- {fact.content}" for fact in facts)
            else:
                lines = "- No preferences detected"
            sections.append(f"{header}\n{lines}")

        result = "[Workspace User Preferences]\n\n" + "\n\n".join(sections)
        self._cache[workspace_id] = (time.monotonic(), result)
        return result

    def invalidate_cache(self, workspace_id: str) -> None:
        """Remove cached preferences for a workspace.

        Args:
            workspace_id: Workspace whose cache entry should be removed.
        """
        self._cache.pop(workspace_id, None)
