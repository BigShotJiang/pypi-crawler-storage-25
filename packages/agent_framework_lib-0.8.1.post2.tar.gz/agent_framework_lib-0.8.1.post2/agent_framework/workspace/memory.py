"""Workspace memory adapter with per-member fan-out."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from .models import WorkspaceMember, WorkspaceMessage

if TYPE_CHECKING:
    from agent_framework.memory.manager import MemoryManager

logger = logging.getLogger(__name__)


class WorkspaceMemoryAdapter:
    """Stores workspace interactions in Graphiti for every human member.

    Each human member of the workspace receives a copy of the interaction
    in their own Graphiti graph, isolated by a composed group_id.

    Args:
        memory_manager: The framework's memory manager instance.
        workspace_id: Target workspace identifier.
        agent_id: The agent's member ID in the workspace.
    """

    def __init__(
        self,
        memory_manager: MemoryManager,
        workspace_id: str,
        agent_id: str,
    ) -> None:
        self._memory_manager = memory_manager
        self._workspace_id = workspace_id
        self._agent_id = agent_id

    async def store_batch(
        self,
        messages: list[WorkspaceMessage],
        agent_response: str,
        trigger_sender_id: str,
        members: list[WorkspaceMember],
    ) -> None:
        """Store the workspace interaction for every human member.

        Fan-out: for each member where member_type == "user", calls
        store_interaction() so the exchange appears in their Graphiti graph.
        Agent members are excluded. Individual failures are logged but
        non-blocking.

        Args:
            messages: The batch of workspace messages (context + trigger).
            agent_response: The agent's response text.
            trigger_sender_id: member_id of the user who triggered the agent.
            members: All workspace members (used for fan-out targeting).
        """
        human_members = [m for m in members if m.member_type == "user"]
        if not human_members:
            logger.debug("No human members to fan-out memory for workspace=%s", self._workspace_id)
            return

        # Find the trigger message content
        user_message = self._extract_trigger_message(messages, trigger_sender_id)

        # Build participant names for source_description
        trigger_sender_name = self._find_member_name(members, trigger_sender_id)
        participant_names = [m.member_name for m in human_members]
        source_description = self._build_source_description(trigger_sender_name, participant_names)

        session_id = f"ws-{self._workspace_id}"

        tasks = [
            self._store_for_member(
                member=member,
                session_id=session_id,
                user_message=user_message,
                agent_response=agent_response,
                source_description=source_description,
                trigger_sender_name=trigger_sender_name,
            )
            for member in human_members
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for member, result in zip(human_members, results):
            if isinstance(result, Exception):
                logger.error(
                    "Failed to store memory for member=%s workspace=%s: %s",
                    member.member_id,
                    self._workspace_id,
                    result,
                )

    async def _store_for_member(
        self,
        member: WorkspaceMember,
        session_id: str,
        user_message: str,
        agent_response: str,
        source_description: str,
        trigger_sender_name: str,
    ) -> bool:
        """Store a single interaction for one member."""
        group_id = f"{member.member_id}:workspace:{self._workspace_id}"

        metadata = {
            "source": "workspace",
            "workspace_id": self._workspace_id,
            "sender_name": trigger_sender_name,
            "source_description": source_description,
        }

        return await self._memory_manager.store_interaction(
            user_id=group_id,
            session_id=session_id,
            agent_id=self._agent_id,
            user_message=user_message,
            agent_response=agent_response,
            metadata=metadata,
        )

    def _build_source_description(
        self,
        trigger_sender_name: str,
        participant_names: list[str],
    ) -> str:
        """Build a descriptive source string for the Graphiti episode.

        Args:
            trigger_sender_name: Name of the user who triggered the exchange.
            participant_names: Names of all human members observing the exchange.

        Returns:
            A human-readable description of the interaction context.
        """
        observers = ", ".join(participant_names) if participant_names else "aucun"
        return (
            f"Team interaction in workspace ws-{self._workspace_id}. "
            f"Exchange between {trigger_sender_name} and the agent, "
            f"observed by members: {observers}."
        )

    @staticmethod
    def _extract_trigger_message(
        messages: list[WorkspaceMessage],
        trigger_sender_id: str,
    ) -> str:
        """Extract the trigger user's message content from the batch.

        Looks for the last message from the trigger sender. Falls back
        to the last message overall if the sender is not found.
        """
        for msg in reversed(messages):
            if msg.sender_id == trigger_sender_id:
                return msg.content

        # Fallback: use the last message content
        return messages[-1].content if messages else ""

    @staticmethod
    def _find_member_name(
        members: list[WorkspaceMember],
        member_id: str,
    ) -> str:
        """Resolve a member_id to a display name."""
        for m in members:
            if m.member_id == member_id:
                return m.member_name
        return member_id
