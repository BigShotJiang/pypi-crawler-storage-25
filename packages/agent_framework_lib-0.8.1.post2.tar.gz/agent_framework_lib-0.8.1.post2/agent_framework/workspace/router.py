"""FastAPI router for workspace subscription and webhook endpoints."""

from __future__ import annotations

import logging
import os
import secrets
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request, Response

from .artefacts import create_artefact_tools
from .client import WorkspaceClient
from .config import WorkspaceConfig
from .cursor import CursorStore
from .memory import WorkspaceMemoryAdapter
from .models import SubscribeRequest, SubscribeResponse, SubscriptionInfo
from .poller import WorkspacePoller
from .preferences import WorkspaceUserPreferencesProvider
from .session import WorkspaceSession
from .subscription import SubscriptionRecord, SubscriptionStore

from agent_framework.core.agent_interface import StructuredAgentInput
from agent_framework.session.session_storage import SessionStorageInterface
from .context import ChatMessage

logger = logging.getLogger(__name__)


def _format_chat_history(chat_history: list) -> str:
    """Format chat history messages into a text block for the agent."""
    if not chat_history:
        return ""
    lines = []
    for msg in chat_history:
        role_label = "User" if msg.role == "user" else "Assistant"
        lines.append(f"{role_label}: {msg.content}")
    return "\n".join(lines)


_WORKSPACE_ARTEFACT_PROMPT = """

[Workspace File Management]
You are operating inside a shared workspace. To manage files in this workspace, use ONLY these tools:
- list_workspace_artefacts(type?) — List files shared in the workspace. Optional filter: NOTE, EXPORT, DECISION, FILE.
- download_workspace_artefact(artefact_id) — Download and read a workspace file by its artefact ID.
- upload_workspace_artefact(file_path, type?, message_id?) — Upload a local file to the workspace. Write the file to /tmp/ first, then upload it.
Do NOT use internal file skills or shell commands to share files. Always use upload_workspace_artefact so files appear in the workspace for all members."""

_WORKSPACE_MEMBERS_PLACEHOLDER = "{{workspace_members}}"
_WORKSPACE_PREFERENCES_PLACEHOLDER = "{{workspace_user_preferences}}"


def _augment_workspace_prompt(agent: Any, members_str: str = "", preferences_str: str = "") -> None:
    """Inject workspace context into the agent's system prompt.

    Handles three injections:
    - ``{{workspace_members}}`` placeholder → replaced with comma-separated member names
    - ``{{workspace_user_preferences}}`` placeholder → replaced with per-user preferences block
    - Artefact tool instructions appended at the end

    If placeholders are absent, the values are prepended automatically.
    """
    instance = getattr(agent, "_agent_instance", None)
    if instance is None:
        return
    prompt = getattr(instance, "system_prompt", None) or ""

    # 1. Inject workspace members
    if members_str:
        if _WORKSPACE_MEMBERS_PLACEHOLDER in prompt:
            prompt = prompt.replace(_WORKSPACE_MEMBERS_PLACEHOLDER, members_str)
        else:
            prompt = f"[Workspace Members]\n{members_str}\n\n{prompt}"
        logger.info("Injected workspace_members into agent system prompt")

    # 2. Inject workspace user preferences
    if preferences_str:
        if _WORKSPACE_PREFERENCES_PLACEHOLDER in prompt:
            prompt = prompt.replace(_WORKSPACE_PREFERENCES_PLACEHOLDER, preferences_str)
        else:
            prompt = f"{preferences_str}\n\n{prompt}"
        logger.info("Injected workspace_user_preferences into agent system prompt")

    # 3. Append artefact tool instructions (once)
    if "upload_workspace_artefact" not in prompt:
        prompt = prompt + _WORKSPACE_ARTEFACT_PROMPT
        logger.info("Augmented agent system prompt with workspace artefact instructions")

    instance.system_prompt = prompt


def create_workspace_router(
    config: WorkspaceConfig,
    session_storage: SessionStorageInterface,
    agent_class: type,
    agent_manager: Any,
) -> APIRouter:
    """Create the workspace APIRouter with all endpoints wired.

    Args:
        config: Workspace configuration loaded from env.
        session_storage: Shared session storage backend.
        agent_class: Agent class for instantiation.
        agent_manager: Agent manager for session handling.

    Returns:
        Configured APIRouter with workspace endpoints.
    """
    router = APIRouter(prefix="/workspace", tags=["workspace"])
    store = SubscriptionStore(session_storage)

    @router.post("/subscribe", status_code=201)
    async def subscribe_to_workspace(
        request: SubscribeRequest,
    ) -> SubscribeResponse:
        """Subscribe the agent to a workspace.

        Executes: register_agent → join_workspace → subscribe_webhook → save.
        Rolls back on failure.
        """
        # Pour les opérations admin (ajout membre, webhook), utiliser l'owner_id si fourni
        admin_id = request.owner_id or config.agent_id
        admin_client = WorkspaceClient(request.workspace_url, request.workspace_api_key, agent_id=admin_id)
        agent_client = WorkspaceClient(request.workspace_url, request.workspace_api_key, agent_id=config.agent_id)
        joined = False
        try:
            await admin_client.register_agent(config.agent_id, config.agent_id)

            try:
                await admin_client.join_workspace(
                    request.workspace_id, config.agent_id, config.agent_id,
                )
                joined = True
            except Exception as join_err:
                # 403 = pas owner mais l'agent est peut-être déjà membre
                if "403" in str(join_err):
                    logger.info("Agent already added to workspace %s (403 on join)", request.workspace_id)
                    joined = True
                else:
                    raise

            webhook_url = (
                f"{config.agent_public_url.rstrip('/')}/workspace/webhook"
            )
            secret_value = secrets.token_urlsafe(32)
            wh_resp = await admin_client.subscribe_webhook(
                workspace_id=request.workspace_id,
                agent_id=config.agent_id,
                target_url=webhook_url,
                secret_key="x-webhook-secret",
                secret_value=secret_value,
            )
            webhook_id = wh_resp.get("_id", wh_resp.get("id", wh_resp.get("webhookId", "")))

            members = await agent_client.get_members(request.workspace_id)

            record = SubscriptionRecord(
                workspace_id=request.workspace_id,
                workspace_url=request.workspace_url,
                workspace_api_key=request.workspace_api_key,
                workspace_name=wh_resp.get("workspaceName", request.workspace_id),
                webhook_id=webhook_id,
                subscribed_at=datetime.now(timezone.utc).isoformat(),
            )
            await store.save(record)

            return SubscribeResponse(
                workspace_id=request.workspace_id,
                workspace_name=record.workspace_name,
                webhook_id=webhook_id,
                members_count=len(members),
            )
        except Exception:
            if joined and not request.owner_id:
                try:
                    await admin_client.leave_workspace(
                        request.workspace_id, config.agent_id,
                    )
                except Exception:
                    logger.warning(
                        "Rollback leave_workspace failed for %s",
                        request.workspace_id,
                    )
            raise
        finally:
            await admin_client.close()
            await agent_client.close()

    @router.get("/subscriptions")
    async def list_subscriptions() -> list[SubscriptionInfo]:
        """Return all active workspace subscriptions."""
        records = await store.list_all()
        return [
            SubscriptionInfo(
                workspace_id=r.workspace_id,
                workspace_url=r.workspace_url,
                workspace_name=r.workspace_name,
                subscribed_at=r.subscribed_at,
                webhook_id=r.webhook_id,
                status=r.status,
            )
            for r in records
        ]

    @router.delete("/subscriptions/{workspace_id}", status_code=204, response_class=Response)
    async def unsubscribe_from_workspace(workspace_id: str) -> Response:
        """Unsubscribe the agent from a workspace."""
        record = await store.load(workspace_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Subscription not found")

        client = WorkspaceClient(record.workspace_url, record.workspace_api_key, agent_id=config.agent_id)
        try:
            await client.unsubscribe_webhook(record.webhook_id)
            await client.leave_workspace(workspace_id, config.agent_id)
            await store.delete(workspace_id)
        finally:
            await client.close()

        return Response(status_code=204)

    @router.post("/webhook")
    async def handle_webhook(
        request: Request,
        background_tasks: BackgroundTasks,
    ) -> dict:
        """Receive a webhook from the Workspace Server.

        Returns 202 for valid payloads, delegates processing to a background task.
        """
        payload: dict = await request.json()

        # Le webhook envoie "type" (ex: "workspace.message.created")
        event = payload.get("type", payload.get("event", ""))
        if event not in (
            "message.created",
            "workspace.message.created",
            "workspace.member.agent.mentioned",
        ):
            return {"status": "ignored"}

        # Le message est dans data.message ou directement dans message
        data = payload.get("data", {})
        message = data.get("message", payload.get("message", data))
        if message.get("senderType") == "agent":
            return {"status": "ignored", "reason": "agent_message"}

        workspace_id = data.get("workspaceId", payload.get("workspaceId", message.get("workspaceId", "")))
        if workspace_id == "":
            return {"status": "ignored"}

        record = await store.load(workspace_id)
        if record is None:
            if not config.default_workspace_url or not config.default_workspace_api_key:
                logger.warning("Auto-subscribe impossible pour workspace %s : configuration manquante", workspace_id)
                raise HTTPException(status_code=404, detail=f"Unknown workspace: {workspace_id}")

            record = SubscriptionRecord(
                workspace_id=workspace_id,
                workspace_url=config.default_workspace_url,
                workspace_api_key=config.default_workspace_api_key,
                workspace_name=workspace_id,
                webhook_id="",
                subscribed_at=datetime.now(timezone.utc).isoformat(),
                status="active",
            )
            await store.save(record)
            logger.info("Auto-subscribed workspace %s", workspace_id)

        # Normaliser le payload pour le traitement en background
        normalized = {
            "event": "message.created",
            "workspaceId": workspace_id,
            "message": {
                "id": str(message.get("_id", message.get("id", ""))),
                "senderId": message.get("senderId", ""),
                "senderName": message.get("senderName", ""),
                "senderType": message.get("senderType", "user"),
                "content": message.get("content", ""),
                "createdAt": message.get("createdAt", ""),
                "metadata": message.get("metadata", {}),
            },
        }

        background_tasks.add_task(_process_webhook, normalized, workspace_id)
        return {"status": "accepted"}

    async def _process_webhook(payload: dict, workspace_id: str) -> None:
        """Process a webhook by wiring a WorkspaceSession to the agent."""
        record = await store.load(workspace_id)
        if record is None:
            logger.warning("Subscription not found for workspace %s during processing", workspace_id)
            return

        client = WorkspaceClient(record.workspace_url, record.workspace_api_key, agent_id=config.agent_id)
        cursor_store = CursorStore(session_storage)

        memory_adapter = None
        prefs_provider = None
        if hasattr(agent_manager, 'memory_manager') and agent_manager.memory_manager is not None:
            memory_adapter = WorkspaceMemoryAdapter(
                memory_manager=agent_manager.memory_manager,
                workspace_id=workspace_id,
                agent_id=config.agent_id,
            )
            prefs_provider = WorkspaceUserPreferencesProvider(
                client=client,
                memory_manager=agent_manager.memory_manager,
                config=config,
            )

        artefact_tools: list = []
        try:
            artefact_tools = create_artefact_tools(client, workspace_id)
        except Exception:
            logger.error("Failed to create artefact tools for workspace %s", workspace_id)

        async def agent_handler(query: str, chat_history: list) -> tuple[str, str | None]:
            """Delegate to the agent framework via AgentManager."""
            session_id = f"ws-{workspace_id}"
            user_id = f"ws-{workspace_id}"
            try:
                agent = await agent_manager.get_agent(
                    session_id=session_id,
                    agent_class=agent_class,
                    user_id=user_id,
                )

                history_text = _format_chat_history(chat_history)
                if history_text:
                    full_query = f"[Conversation context]\n{history_text}\n\n[Current message]\n{query}"
                else:
                    full_query = query

                # Injecter les artefact tools dans l'agent LlamaIndex
                if artefact_tools and hasattr(agent, '_agent_instance') and agent._agent_instance is not None:
                    try:
                        from llama_index.core.tools import FunctionTool
                        existing_names = {t.metadata.name for t in agent._agent_instance.tools}
                        for tool_def in artefact_tools:
                            if tool_def["name"] not in existing_names:
                                ft = FunctionTool.from_defaults(
                                    async_fn=tool_def["fn"],
                                    name=tool_def["name"],
                                    description=tool_def["description"],
                                )
                                agent._agent_instance.tools.append(ft)
                                logger.info("Injected workspace tool '%s' into agent", tool_def["name"])
                    except Exception:
                        logger.warning("Could not inject artefact tools into agent for workspace %s", workspace_id)

                # Construire la liste des membres pour injection dans le prompt
                members_str = ""
                preferences_str = ""
                try:
                    members = await client.get_members(workspace_id)
                    human_names = [m.member_name for m in members if m.member_type == "user"]
                    if human_names:
                        members_str = ", ".join(human_names)
                except Exception:
                    logger.warning("Could not fetch members for workspace %s", workspace_id)

                if prefs_provider is not None:
                    try:
                        preferences_str = await prefs_provider.get_all_preferences(
                            workspace_id, config.agent_id,
                        )
                    except Exception:
                        logger.warning("Could not fetch preferences for workspace %s", workspace_id)

                # Augmenter le system prompt (membres, préférences, artefact tools)
                if hasattr(agent, '_agent_instance') and agent._agent_instance is not None:
                    _augment_workspace_prompt(agent, members_str=members_str, preferences_str=preferences_str)

                agent_input = StructuredAgentInput(query=full_query)
                result = await agent.handle_message(session_id, agent_input)

                model_name = None
                try:
                    model_name = await agent.get_current_model(session_id)
                except Exception:
                    logger.debug("Could not retrieve model name for workspace %s", workspace_id)

                return (result.response_text or "", model_name)
            except Exception as e:
                logger.error("Agent handler failed for workspace %s: %s", workspace_id, e)
                return (f"I encountered an error processing your request: {e}", None)

        session = WorkspaceSession(
            client=client,
            workspace_id=workspace_id,
            agent_member_id=config.agent_id,
            config=config,
            cursor_store=cursor_store,
            agent_handler=agent_handler,
            memory_adapter=memory_adapter,
            prefs_provider=prefs_provider,
        )

        try:
            await session.handle_webhook(payload)
        except Exception:
            logger.exception("Webhook processing failed for workspace %s", workspace_id)
        finally:
            await client.close()

    # ------------------------------------------------------------------
    # Polling mode (for local dev without public URL)
    # ------------------------------------------------------------------

    poll_interval = float(os.getenv("WORKSPACE_POLL_INTERVAL", "30"))
    poller = WorkspacePoller(interval=poll_interval, process_fn=_process_webhook)

    @router.post("/poll/start/{workspace_id}")
    async def start_polling(workspace_id: str) -> dict:
        """Start polling a workspace for new messages (dev mode)."""
        record = await store.load(workspace_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Subscription not found")

        cursor_store = CursorStore(session_storage)
        poller.start(workspace_id, record, cursor_store, config.agent_id)
        return {"status": "polling", "workspace_id": workspace_id, "interval": poll_interval}

    @router.post("/poll/stop/{workspace_id}")
    async def stop_polling(workspace_id: str) -> dict:
        """Stop polling a workspace."""
        poller.stop(workspace_id)
        return {"status": "stopped", "workspace_id": workspace_id}

    @router.get("/poll/status")
    async def poll_status() -> dict:
        """Get active pollers status."""
        return {"active": poller.active_workspaces}

    return router
