"""Workspace data models."""

from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel


@dataclass
class WorkspaceMessage:
    """A message from a workspace conversation."""

    id: str
    content: str
    sender_id: str
    sender_type: str  # "user" | "agent"
    sender_name: str
    created_at: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkspaceMember:
    """A member of a workspace."""

    member_id: str
    member_name: str
    member_type: str  # "user" | "agent"
    role: str  # "owner" | "participant" | "viewer"


@dataclass
class WorkspaceArtefact:
    """A file or document attached to a workspace."""

    id: str
    type: str  # "NOTE" | "EXPORT" | "DECISION" | "FILE"
    file_id: str
    file_name: str
    created_at: str
    created_by: str


class SubscribeRequest(BaseModel):
    """Request body for POST /workspace/subscribe."""

    workspace_url: str
    workspace_api_key: str
    workspace_id: str
    owner_id: str | None = None


class SubscribeResponse(BaseModel):
    """Response body for POST /workspace/subscribe."""

    status: str = "subscribed"
    workspace_id: str
    workspace_name: str
    webhook_id: str
    members_count: int


class SubscriptionInfo(BaseModel):
    """Info about an active workspace subscription."""

    workspace_id: str
    workspace_url: str
    workspace_name: str
    subscribed_at: str
    webhook_id: str
    status: str
