"""Workspace artefact tools for agents.

Provides factory function to create artefact tool definitions
(list, download, upload) scoped to a specific workspace.
"""

import logging
from typing import Any

import httpx

from .client import WorkspaceClient
from .models import WorkspaceArtefact

logger = logging.getLogger(__name__)

_DEFAULT_MAX_DOWNLOAD_SIZE = 50 * 1024 * 1024  # 50 MB


def create_artefact_tools(
    client: WorkspaceClient,
    workspace_id: str,
    max_download_size: int = _DEFAULT_MAX_DOWNLOAD_SIZE,
) -> list[dict[str, Any]]:
    """Create workspace artefact tool definitions.

    Returns a list of dicts with 'name', 'description', and 'fn' keys.
    Each 'fn' is an async closure capturing *client* and *workspace_id*.

    Args:
        client: Authenticated workspace HTTP client.
        workspace_id: Target workspace identifier.
        max_download_size: Max file size in bytes for downloads (default 50 MB).
    """

    async def list_workspace_artefacts(type: str | None = None) -> list[dict[str, Any]]:
        """List artefacts in the workspace.

        Args:
            type: Optional filter by artefact type (NOTE, EXPORT, DECISION, FILE).

        Returns:
            List of artefact info dicts.
        """
        artefacts: list[WorkspaceArtefact] = await client.list_artefacts(
            workspace_id, type=type,
        )
        return [
            {
                "id": a.id,
                "type": a.type,
                "file_name": a.file_name,
                "created_at": a.created_at,
                "created_by": a.created_by,
            }
            for a in artefacts
        ]

    async def download_workspace_artefact(artefact_id: str) -> str:
        """Download an artefact by ID.

        Looks up the artefact to get its file_id, fetches a signed URL,
        then downloads the content. Returns text content for text files
        or a description for binary files.

        Args:
            artefact_id: The artefact identifier.

        Returns:
            File content as text.

        Raises:
            ValueError: If artefact not found or file exceeds size limit.
        """
        # Find the artefact to get its file_id
        artefacts = await client.list_artefacts(workspace_id)
        target: WorkspaceArtefact | None = None
        for a in artefacts:
            if a.id == artefact_id:
                target = a
                break

        if target is None:
            raise ValueError(f"Artefact '{artefact_id}' not found in workspace '{workspace_id}'")

        signed_url = await client.get_signed_url(target.file_id)

        # Download via a separate httpx call
        async with httpx.AsyncClient(timeout=httpx.Timeout(60.0)) as http:
            response = await http.get(signed_url)
            response.raise_for_status()

            content_length = response.headers.get("content-length")
            if content_length is not None and int(content_length) > max_download_size:
                raise ValueError(
                    f"File '{target.file_name}' exceeds size limit "
                    f"({int(content_length)} bytes > {max_download_size} bytes)"
                )

            data = response.content
            if len(data) > max_download_size:
                raise ValueError(
                    f"File '{target.file_name}' exceeds size limit "
                    f"({len(data)} bytes > {max_download_size} bytes)"
                )

        # Attempt to decode as text
        try:
            return data.decode("utf-8")
        except UnicodeDecodeError:
            return (
                f"[Binary file: {target.file_name}, "
                f"{len(data)} bytes, type: {target.type}]"
            )

    async def upload_workspace_artefact(
        file_path: str,
        type: str = "FILE",
        message_id: str | None = None,
    ) -> dict[str, Any]:
        """Upload a local file as a workspace artefact.

        Args:
            file_path: Path to the local file to upload.
            type: Artefact type (NOTE, EXPORT, DECISION, FILE).
            message_id: Optional related message ID.

        Returns:
            Dict with the created artefact info.
        """
        artefact: WorkspaceArtefact = await client.upload_artefact(
            workspace_id, file_path, type=type, message_id=message_id,
        )
        return {
            "id": artefact.id,
            "type": artefact.type,
            "file_id": artefact.file_id,
            "file_name": artefact.file_name,
            "created_at": artefact.created_at,
            "created_by": artefact.created_by,
        }

    return [
        {
            "name": "list_workspace_artefacts",
            "description": (
                "List artefacts in the current workspace. "
                "Optionally filter by type (NOTE, EXPORT, DECISION, FILE)."
            ),
            "fn": list_workspace_artefacts,
        },
        {
            "name": "download_workspace_artefact",
            "description": (
                "Download a workspace artefact by its ID. "
                "Returns the file content as text, or a description for binary files."
            ),
            "fn": download_workspace_artefact,
        },
        {
            "name": "upload_workspace_artefact",
            "description": (
                "Upload a local file as a workspace artefact. "
                "Specify the file path, type (default FILE), and optional message ID."
            ),
            "fn": upload_workspace_artefact,
        },
    ]
