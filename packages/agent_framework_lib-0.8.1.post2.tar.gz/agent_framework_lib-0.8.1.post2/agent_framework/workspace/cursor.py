"""Workspace cursor persistence via SessionStorageInterface."""

import logging
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from agent_framework.session.session_storage import SessionData, SessionStorageInterface

logger = logging.getLogger(__name__)

# Fixed user_id used to namespace all cursor records in the session store.
_CURSORS_USER_ID = "__ws_cursors__"


@dataclass
class CursorRecord:
    """Persisted workspace message cursor."""

    agent_id: str
    workspace_id: str
    last_message_id: str
    updated_at: str


class CursorStore:
    """Load/save workspace message cursors backed by SessionStorageInterface.

    Uses a fixed user_id prefix and `{agent_id}:{workspace_id}` as session_id
    so that records are stored alongside regular sessions without collisions.
    """

    def __init__(self, storage: SessionStorageInterface) -> None:
        self._storage = storage

    async def load(self, agent_id: str, workspace_id: str) -> str | None:
        """Load the last_message_id for a given agent/workspace pair, or None."""
        session_id = f"{agent_id}:{workspace_id}"
        session = await self._storage.load_session(_CURSORS_USER_ID, session_id)
        if session is None or session.metadata is None:
            return None
        return session.metadata.get("last_message_id")

    async def load_full(self, agent_id: str, workspace_id: str) -> CursorRecord | None:
        """Load the full cursor record for a given agent/workspace pair.

        Args:
            agent_id: Agent identifier.
            workspace_id: Workspace identifier.

        Returns:
            The full CursorRecord, or None if no record exists.
        """
        session_id = f"{agent_id}:{workspace_id}"
        session = await self._storage.load_session(_CURSORS_USER_ID, session_id)
        if session is None or session.metadata is None:
            return None
        return CursorRecord(
            agent_id=session.metadata.get("agent_id", agent_id),
            workspace_id=session.metadata.get("workspace_id", workspace_id),
            last_message_id=session.metadata.get("last_message_id", ""),
            updated_at=session.metadata.get("updated_at", ""),
        )

    async def save(
        self,
        agent_id: str,
        workspace_id: str,
        message_id: str,
        expected_updated_at: str | None = None,
    ) -> bool:
        """Persist the cursor with the current timestamp.

        Args:
            agent_id: Agent identifier.
            workspace_id: Workspace identifier.
            message_id: New last_message_id to persist.
            expected_updated_at: If provided, performs optimistic locking by
                comparing with the existing record's updated_at before writing.

        Returns:
            True if saved successfully, False if a conflict was detected.
        """
        if expected_updated_at is not None:
            existing = await self.load_full(agent_id, workspace_id)
            if existing and existing.updated_at != expected_updated_at:
                logger.warning(
                    "Cursor conflict: workspace=%s expected=%s actual=%s",
                    workspace_id, expected_updated_at, existing.updated_at,
                )
                return False

        session_id = f"{agent_id}:{workspace_id}"
        now = datetime.now(timezone.utc).isoformat()
        record = CursorRecord(
            agent_id=agent_id,
            workspace_id=workspace_id,
            last_message_id=message_id,
            updated_at=now,
        )
        session_data = SessionData(
            session_id=session_id,
            user_id=_CURSORS_USER_ID,
            agent_instance_config={},
            created_at=now,
            updated_at=now,
            metadata=asdict(record),
        )
        return await self._storage.save_session(
            _CURSORS_USER_ID, session_id, session_data
        )
