"""Workspace configuration loaded from environment variables."""

import os
from dataclasses import dataclass


@dataclass
class WorkspaceConfig:
    """Configuration for workspace integration.

    Args:
        enabled: Whether workspace integration is active.
        agent_id: Unique identifier for the agent in the workspace server.
        agent_public_url: Public URL where the agent receives webhooks.
        max_context_messages: Max messages to include in context window.
        max_gap_messages: Max gap before truncation with warning.
        prefs_cache_ttl: TTL in seconds for the preferences cache.
        prefs_max_facts_per_user: Max Graphiti facts per user for preferences.
        default_workspace_url: Default Workspace Server URL for auto-subscribe.
        default_workspace_api_key: Default API key for auto-subscribe.
    """

    enabled: bool
    agent_id: str
    agent_public_url: str
    max_context_messages: int = 50
    max_gap_messages: int = 200
    prefs_cache_ttl: float = 300.0
    prefs_max_facts_per_user: int = 10
    default_workspace_url: str = ""
    default_workspace_api_key: str = ""

    @classmethod
    def from_env(cls) -> "WorkspaceConfig":
        """Create a WorkspaceConfig from environment variables.

        Reads:
            WORKSPACE_ENABLED, WORKSPACE_AGENT_ID, WORKSPACE_AGENT_PUBLIC_URL,
            WORKSPACE_MAX_CONTEXT_MESSAGES, WORKSPACE_MAX_GAP_MESSAGES,
            WORKSPACE_PREFS_CACHE_TTL, WORKSPACE_PREFS_MAX_FACTS_PER_USER,
            WORKSPACE_URL, API_KEY_WORKSPACE
        """
        return cls(
            enabled=os.getenv("WORKSPACE_ENABLED", "false").lower() == "true",
            agent_id=os.getenv("WORKSPACE_AGENT_ID", ""),
            agent_public_url=os.getenv("WORKSPACE_AGENT_PUBLIC_URL", ""),
            max_context_messages=int(os.getenv("WORKSPACE_MAX_CONTEXT_MESSAGES", "500")),
            max_gap_messages=int(os.getenv("WORKSPACE_MAX_GAP_MESSAGES", "200")),
            prefs_cache_ttl=float(os.getenv("WORKSPACE_PREFS_CACHE_TTL", "300.0")),
            prefs_max_facts_per_user=int(os.getenv("WORKSPACE_PREFS_MAX_FACTS_PER_USER", "10")),
            default_workspace_url=os.getenv("WORKSPACE_URL", ""),
            default_workspace_api_key=os.getenv("API_KEY_WORKSPACE", ""),
        )
