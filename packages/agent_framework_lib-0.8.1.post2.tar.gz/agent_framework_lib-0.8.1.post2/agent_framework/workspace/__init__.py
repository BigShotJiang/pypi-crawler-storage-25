"""
Workspace Integration Module.

Provides workspace participation capabilities for agents:
- Subscribe to workspaces and receive messages via webhooks
- Build multi-user conversational context
- Store interactions in Graphiti with per-member fan-out
- Manage workspace artefacts (files)
- Load and cache user preferences across workspace members
"""

from .client import WorkspaceClient
from .config import WorkspaceConfig
from .context import ChatMessage, ContextBuilder
from .models import (
    WorkspaceMessage,
    WorkspaceMember,
    WorkspaceArtefact,
    SubscribeRequest,
    SubscribeResponse,
    SubscriptionInfo,
)
from .subscription import SubscriptionRecord, SubscriptionStore
from .cursor import CursorRecord, CursorStore
from .artefacts import create_artefact_tools
from .memory import WorkspaceMemoryAdapter
from .preferences import WorkspaceUserPreferencesProvider
from .session import WorkspaceSession
from .router import create_workspace_router

__all__ = [
    "ChatMessage",
    "ContextBuilder",
    "WorkspaceClient",
    "WorkspaceConfig",
    "create_artefact_tools",
    "WorkspaceMessage",
    "WorkspaceMember",
    "WorkspaceArtefact",
    "SubscribeRequest",
    "SubscribeResponse",
    "SubscriptionInfo",
    "SubscriptionRecord",
    "SubscriptionStore",
    "CursorRecord",
    "CursorStore",
    "WorkspaceMemoryAdapter",
    "WorkspaceUserPreferencesProvider",
    "WorkspaceSession",
    "create_workspace_router",
]

__version__ = "0.1.0"
