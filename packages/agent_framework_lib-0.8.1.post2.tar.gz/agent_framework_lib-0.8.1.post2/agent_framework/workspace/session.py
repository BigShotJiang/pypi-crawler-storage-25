"""Workspace session orchestrator."""

from __future__ import annotations

import logging
import time
from collections.abc import Awaitable, Callable
from typing import Any

from .client import WorkspaceClient
from .config import WorkspaceConfig
from .context import ChatMessage, ContextBuilder, truncate_messages
from .cursor import CursorStore
from .models import WorkspaceMessage
from .preferences import WorkspaceUserPreferencesProvider

logger = logging.getLogger(__name__)


class WorkspaceSession:
    """Orchestrates the lifecycle of an agent within a workspace.

    Handles incoming webhooks by fetching context messages, building
    chat history, invoking the agent, posting the response, and
    updating the cursor.

    Args:
        client: HTTP client for the Workspace Server API.
        workspace_id: Target workspace identifier.
        agent_member_id: Agent's member ID in the workspace.
        config: Workspace configuration.
        cursor_store: Persistent cursor storage.
        agent_handler: Async callable (query, chat_history) -> (response_text, model_name).
        memory_adapter: Optional memory adapter (wired later).
        prefs_provider: Optional preferences provider for workspace members.
    """

    def __init__(
        self,
        client: WorkspaceClient,
        workspace_id: str,
        agent_member_id: str,
        config: WorkspaceConfig,
        cursor_store: CursorStore,
        agent_handler: Callable[[str, list[ChatMessage]], Awaitable[tuple[str, str | None]]],
        memory_adapter: Any | None = None,
        prefs_provider: WorkspaceUserPreferencesProvider | None = None,
    ) -> None:
        self._client = client
        self._workspace_id = workspace_id
        self._agent_member_id = agent_member_id
        self._config = config
        self._cursor_store = cursor_store
        self._agent_handler = agent_handler
        self._memory_adapter = memory_adapter
        self._prefs_provider = prefs_provider

    async def handle_webhook(self, payload: dict) -> None:
        """Process an incoming webhook payload.

        Sequence:
        1. Extract message from payload
        2. Fetch context messages using cursor
        3. Build chat history via ContextBuilder
        4. Inject workspace member preferences into the query
        5. Call the agent handler → receives (response_text, model_name)
        6. Post the response to the workspace (with model_name metadata)
        7. Store to memory (placeholder)
        8. Update the cursor
        """
        message = payload.get("message", payload.get("data", {}))
        trigger_message_id = message.get("id", "")
        trigger_sender_id = message.get("senderId", message.get("sender_id", ""))

        cursor_record = await self._cursor_store.load_full(
            self._agent_member_id, self._workspace_id
        )
        cursor_updated_at = cursor_record.updated_at if cursor_record else None

        logger.info(
            "Processing webhook for workspace=%s trigger_message=%s",
            self._workspace_id,
            trigger_message_id,
        )

        # 1. Fetch context messages
        messages = await self._fetch_context_messages()
        if not messages:
            logger.warning(
                "No messages fetched for workspace=%s", self._workspace_id
            )
            return

        # 2. Truncate if gap is too large
        messages, warning = truncate_messages(
            messages,
            max_gap_messages=self._config.max_gap_messages,
            max_context_messages=self._config.max_context_messages,
        )
        if warning:
            logger.info("Gap truncation: %s", warning)

        # 3. Build chat history
        builder = ContextBuilder(self._agent_member_id)
        try:
            chat_history, user_query = builder.build(messages)
        except ValueError:
            logger.warning(
                "No actionable messages after filtering for workspace=%s",
                self._workspace_id,
            )
            return

        # Prepend truncation warning to the first history entry if needed
        if warning and chat_history:
            chat_history.insert(
                0, ChatMessage(role="user", content=warning)
            )

        # 4. Inject workspace member preferences
        preferences = await self._inject_preferences()
        if preferences is not None:
            user_query = f"{preferences}\n\n{user_query}"

        # 5. Call the agent
        start_ms = time.monotonic()
        response_text, model_name = await self._agent_handler(user_query, chat_history)
        elapsed_ms = int((time.monotonic() - start_ms) * 1000)

        # 6. Post response
        await self._post_response(response_text, elapsed_ms, model_name=model_name)

        # 7. Store to memory
        await self._store_to_memory(messages, response_text, trigger_sender_id)

        # 8. Update cursor
        if trigger_message_id:
            await self._update_cursor(trigger_message_id, expected_updated_at=cursor_updated_at)

    async def _fetch_context_messages(self) -> list[WorkspaceMessage]:
        """Fetch messages from the workspace using the stored cursor."""
        cursor = await self._cursor_store.load(
            self._agent_member_id, self._workspace_id
        )

        if cursor is None:
            # First message: get last N messages in descending order, then reverse
            messages = await self._client.get_messages(
                self._workspace_id,
                after_id=None,
                limit=self._config.max_context_messages,
                sort="desc",
            )
            messages.reverse()
        else:
            # Subsequent messages: get messages after cursor
            messages = await self._client.get_messages(
                self._workspace_id,
                after_id=cursor,
                limit=self._config.max_gap_messages + 1,
                sort="asc",
            )

        return messages

    async def _post_response(self, text: str, processing_time_ms: int, model_name: str | None = None) -> None:
        """Publish the agent's response to the workspace."""
        metadata: dict[str, Any] = {
            "processing_time_ms": processing_time_ms,
        }
        if model_name:
            metadata["model"] = model_name
        await self._client.post_message(
            self._workspace_id,
            text,
            self._agent_member_id,
            metadata=metadata,
        )
        logger.info(
            "Posted response to workspace=%s (%dms)",
            self._workspace_id,
            processing_time_ms,
        )

    async def _inject_preferences(self) -> str | None:
        """Load workspace member preferences from the provider.

        Returns:
            Formatted preferences block, or None if unavailable.
        """
        if self._prefs_provider is None:
            return None
        try:
            return await self._prefs_provider.get_all_preferences(
                self._workspace_id, self._agent_member_id
            )
        except Exception:
            logger.warning("Failed to load preferences for workspace=%s", self._workspace_id)
            return None

    async def _store_to_memory(
        self,
        messages: list[WorkspaceMessage],
        agent_response: str,
        trigger_sender_id: str,
    ) -> None:
        """Store the interaction in long-term memory via the memory adapter.

        Args:
            messages: Context messages from the workspace.
            agent_response: The agent's response text.
            trigger_sender_id: Member ID of the user who triggered the agent.
        """
        if self._memory_adapter is None:
            return
        try:
            members = await self._client.get_members(self._workspace_id)
            await self._memory_adapter.store_batch(
                messages=messages,
                agent_response=agent_response,
                trigger_sender_id=trigger_sender_id,
                members=members,
            )
        except Exception:
            logger.warning(
                "Memory storage failed for workspace=%s",
                self._workspace_id,
                exc_info=True,
            )

    async def _update_cursor(self, message_id: str, expected_updated_at: str | None = None) -> None:
        """Persist the new cursor position with optimistic locking."""
        saved = await self._cursor_store.save(
            self._agent_member_id, self._workspace_id, message_id,
            expected_updated_at=expected_updated_at,
        )
        if not saved:
            logger.info(
                "Cursor conflict detected for workspace=%s, will retry on next webhook",
                self._workspace_id,
            )
            return
        logger.debug(
            "Cursor updated: workspace=%s message_id=%s",
            self._workspace_id,
            message_id,
        )
