"""Async HTTP client for the Workspace Server API."""

import asyncio
import logging
from typing import Any

import httpx

from .models import WorkspaceArtefact, WorkspaceMember, WorkspaceMessage


logger = logging.getLogger(__name__)

_MAX_RETRIES = 3
_BACKOFF_DELAYS = (1.0, 2.0, 4.0)


def _normalize_message(raw: dict[str, Any]) -> dict[str, Any]:
    """Map MongoDB ``_id`` to ``id`` and flatten sender populate."""
    out = dict(raw)
    if "_id" in out and "id" not in out:
        out["id"] = str(out.pop("_id"))
    if "sender_id" not in out and "senderId" in out:
        out["sender_id"] = out.pop("senderId")
    if "sender_type" not in out and "senderType" in out:
        out["sender_type"] = out.pop("senderType")
    if "sender_name" not in out and "senderName" in out:
        out["sender_name"] = out.pop("senderName")
    if "created_at" not in out and "createdAt" in out:
        out["created_at"] = out.pop("createdAt")
    # Supprimer les champs non attendus par le dataclass
    for key in ("workspace", "sender", "mentionedUsers", "mentionedAgents",
                "createdBy", "__v", "updatedAt"):
        out.pop(key, None)
    return out


def _normalize_member(raw: dict[str, Any]) -> dict[str, Any]:
    """Map MongoDB fields to WorkspaceMember dataclass fields."""
    out = dict(raw)
    if "_id" in out and "id" not in out:
        out["id"] = str(out.pop("_id"))
    if "member_id" not in out and "memberId" in out:
        out["member_id"] = out.pop("memberId")
    if "member_name" not in out and "memberName" in out:
        out["member_name"] = out.pop("memberName")
    if "member_type" not in out and "memberType" in out:
        out["member_type"] = out.pop("memberType")
    for key in ("workspace", "createdBy", "updatedBy", "createdAt",
                "updatedAt", "__v", "id", "_id"):
        out.pop(key, None)
    return out


def _normalize_artefact(raw: dict[str, Any]) -> dict[str, Any]:
    """Map MongoDB fields to WorkspaceArtefact dataclass fields."""
    out = dict(raw)
    if "_id" in out and "id" not in out:
        out["id"] = str(out.pop("_id"))
    # Le champ file peut être un ObjectId string ou un objet populé
    file_val = out.pop("file", None)
    if file_val is not None:
        if isinstance(file_val, dict):
            out["file_id"] = str(file_val.get("_id", ""))
            out["file_name"] = file_val.get("originalName", file_val.get("filename", ""))
        else:
            out["file_id"] = str(file_val)
            out.setdefault("file_name", "")
    if "file_id" not in out:
        out["file_id"] = out.pop("fileId", "")
    if "file_name" not in out and "fileName" in out:
        out["file_name"] = out.pop("fileName")
    if "created_at" not in out and "createdAt" in out:
        out["created_at"] = out.pop("createdAt")
    if "created_by" not in out and "createdBy" in out:
        out["created_by"] = out.pop("createdBy")
    for key in ("workspace", "message", "updatedBy", "updatedAt", "__v"):
        out.pop(key, None)
    return out


class WorkspaceClient:
    """HTTP client wrapping all calls to the Workspace Server REST API.

    Args:
        base_url: Root URL of the Workspace Server (e.g. ``https://ws.example.com``).
        api_key: API key used for authentication via ``x-api-key`` header.
    """

    def __init__(self, base_url: str, api_key: str, agent_id: str = "agent") -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            headers={
                "x-api-key": api_key,
                "x-auth-mode": "api-key",
                "x-user-id": agent_id,
                "x-user-name": agent_id,
            },
            timeout=httpx.Timeout(30.0),
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        files: Any | None = None,
        data: dict[str, Any] | None = None,
        ignore_conflict: bool = False,
    ) -> httpx.Response:
        """Send an HTTP request with retry and error handling.

        Retries on network errors and HTTP 5xx up to 3 times with
        exponential backoff (1s, 2s, 4s). HTTP 409 is silently
        swallowed when *ignore_conflict* is True.
        """
        last_exc: Exception | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                response = await self._client.request(
                    method,
                    path,
                    json=json,
                    params=params,
                    files=files,
                    data=data,
                )
            except httpx.HTTPError as exc:
                last_exc = exc
                delay = _BACKOFF_DELAYS[attempt]
                logger.warning(
                    "Network error on %s %s (attempt %d/%d): %s — retrying in %.1fs",
                    method, path, attempt + 1, _MAX_RETRIES, exc, delay,
                )
                await asyncio.sleep(delay)
                continue

            if response.status_code >= 500:
                last_exc = httpx.HTTPStatusError(
                    f"Server error {response.status_code}",
                    request=response.request,
                    response=response,
                )
                delay = _BACKOFF_DELAYS[attempt]
                logger.warning(
                    "HTTP %d on %s %s (attempt %d/%d) — retrying in %.1fs",
                    response.status_code, method, path, attempt + 1, _MAX_RETRIES, delay,
                )
                await asyncio.sleep(delay)
                continue

            if response.status_code == 409 and ignore_conflict:
                logger.debug("HTTP 409 on %s %s — ignored (idempotent)", method, path)
                return response

            if response.status_code in (401, 403):
                logger.error(
                    "Auth error HTTP %d on %s %s", response.status_code, method, path,
                )
                response.raise_for_status()

            response.raise_for_status()
            return response

        # All retries exhausted
        assert last_exc is not None
        logger.error(
            "All %d retries exhausted for %s %s", _MAX_RETRIES, method, path,
        )
        raise last_exc

    # ------------------------------------------------------------------
    # Runtime methods
    # ------------------------------------------------------------------

    async def get_messages(
        self,
        workspace_id: str,
        after_id: str | None = None,
        limit: int = 50,
        sort: str = "asc",
    ) -> list[WorkspaceMessage]:
        """Fetch messages from a workspace.

        Args:
            workspace_id: Target workspace.
            after_id: Return messages after this ID (cursor).
            limit: Max number of messages to return.
            sort: Sort order (``asc`` or ``desc``).
        """
        params: dict[str, Any] = {"limit": limit, "sort": sort}
        if after_id is not None:
            params["afterId"] = after_id

        resp = await self._request("GET", f"/workspaces/{workspace_id}/messages", params=params)
        payload = resp.json()
        # Le serveur retourne soit une liste, soit { data: [...], total, ... }
        items = payload if isinstance(payload, list) else payload.get("data", [])
        return [WorkspaceMessage(**_normalize_message(item)) for item in items]

    async def post_message(
        self,
        workspace_id: str,
        content: str,
        agent_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> WorkspaceMessage:
        """Publish a message in a workspace.

        Args:
            workspace_id: Target workspace.
            content: Message text.
            agent_id: Sender agent identifier (used in x-user-id header).
            metadata: Optional metadata dict (model, processing time, etc.).
        """
        body: dict[str, Any] = {
            "content": content,
            "senderType": "agent",
        }
        if metadata:
            body["metadata"] = metadata

        resp = await self._request("POST", f"/workspaces/{workspace_id}/messages", json=body)
        return WorkspaceMessage(**_normalize_message(resp.json()))

    async def get_members(self, workspace_id: str) -> list[WorkspaceMember]:
        """List all members of a workspace."""
        resp = await self._request("GET", f"/workspaces/{workspace_id}/members")
        items = resp.json()
        if isinstance(items, dict) and "data" in items:
            items = items["data"]
        return [WorkspaceMember(**_normalize_member(item)) for item in items]

    async def list_artefacts(
        self, workspace_id: str, type: str | None = None,
    ) -> list[WorkspaceArtefact]:
        """List artefacts in a workspace.

        Args:
            workspace_id: Target workspace.
            type: Optional filter (NOTE, EXPORT, DECISION, FILE).
        """
        params: dict[str, Any] = {}
        if type is not None:
            params["type"] = type

        resp = await self._request(
            "GET", f"/workspaces/{workspace_id}/artefacts", params=params,
        )
        items = resp.json()
        if isinstance(items, dict) and "data" in items:
            items = items["data"]
        return [WorkspaceArtefact(**_normalize_artefact(item)) for item in items]

    async def upload_artefact(
        self,
        workspace_id: str,
        file_path: str,
        type: str = "FILE",
        message_id: str | None = None,
    ) -> WorkspaceArtefact:
        """Upload a file as a workspace artefact (multipart/form-data).

        Args:
            workspace_id: Target workspace.
            file_path: Local path to the file to upload.
            type: Artefact type (NOTE, EXPORT, DECISION, FILE).
            message_id: Optional related message ID.
        """
        data: dict[str, Any] = {"type": type}
        if message_id is not None:
            data["messageId"] = message_id

        with open(file_path, "rb") as f:
            files = {"files": (file_path.split("/")[-1], f)}
            resp = await self._request(
                "POST",
                f"/workspaces/{workspace_id}/artefacts",
                files=files,
                data=data,
            )
        raw = resp.json()
        # Le serveur retourne { success, count, results: [...] }
        if isinstance(raw, dict) and "results" in raw:
            items = raw["results"]
            if items:
                return WorkspaceArtefact(**_normalize_artefact(items[0]))
        return WorkspaceArtefact(**_normalize_artefact(raw))

    async def get_signed_url(self, file_id: str) -> str:
        """Get a signed download URL for a file.

        Args:
            file_id: The file identifier.
        """
        resp = await self._request("GET", f"/files/{file_id}/signed-url")
        return resp.json()["url"]

    # ------------------------------------------------------------------
    # Subscription lifecycle
    # ------------------------------------------------------------------

    async def register_agent(self, agent_id: str, agent_name: str) -> dict[str, Any]:
        """Register the agent identity on the Workspace Server.

        HTTP 409 is silently ignored (agent already registered).
        """
        resp = await self._request(
            "POST",
            "/workspace-agents",
            json={"agentId": agent_id, "agentName": agent_name},
            ignore_conflict=True,
        )
        return resp.json()

    async def join_workspace(
        self, workspace_id: str, agent_id: str, agent_name: str,
    ) -> dict[str, Any]:
        """Add the agent as a member of a workspace.

        HTTP 409 is silently ignored (already a member).
        """
        resp = await self._request(
            "POST",
            f"/workspaces/{workspace_id}/members",
            json={
                "memberId": agent_id,
                "memberName": agent_name,
                "memberType": "agent",
                "role": "participant",
            },
            ignore_conflict=True,
        )
        return resp.json()

    async def subscribe_webhook(
        self,
        workspace_id: str,
        agent_id: str,
        target_url: str,
        secret_key: str,
        secret_value: str,
    ) -> dict[str, Any]:
        """Create a webhook subscription for workspace events.

        Args:
            workspace_id: Target workspace.
            agent_id: Agent identifier.
            target_url: URL that will receive webhook POSTs.
            secret_key: Header name for webhook signature.
            secret_value: Secret used to sign webhook payloads.
        """
        resp = await self._request(
            "POST",
            "/webhook-subscriptions",
            json={
                "name": f"agent-{agent_id}-{workspace_id}",
                "targetUrl": target_url,
                "secretKey": secret_key,
                "secretValue": secret_value,
                "eventTypes": ["*"],
                "isAgent": True,
                "agentId": agent_id,
                "active": True,
                "metadata": {"workspaceId": workspace_id, "agentId": agent_id},
            },
            ignore_conflict=True,
        )
        return resp.json()

    async def unsubscribe_webhook(self, webhook_id: str) -> None:
        """Delete a webhook subscription."""
        await self._request("DELETE", f"/webhook-subscriptions/{webhook_id}")

    async def leave_workspace(self, workspace_id: str, member_id: str) -> None:
        """Remove a member from a workspace."""
        await self._request("DELETE", f"/workspaces/{workspace_id}/members/{member_id}")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()
