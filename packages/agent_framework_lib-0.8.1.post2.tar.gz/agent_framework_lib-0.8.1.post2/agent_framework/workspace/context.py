"""Context builder for workspace conversations."""

from __future__ import annotations

from dataclasses import dataclass

from .models import WorkspaceMessage


def truncate_messages(
    messages: list[WorkspaceMessage],
    max_gap_messages: int,
    max_context_messages: int,
) -> tuple[list[WorkspaceMessage], str | None]:
    """Truncate messages if the gap exceeds the threshold.

    When the number of messages between the cursor and the trigger message
    exceeds max_gap_messages, keep only the last max_context_messages and
    produce a warning indicating how many were omitted.

    Args:
        messages: Full list of messages from the gap.
        max_gap_messages: Threshold above which truncation kicks in.
        max_context_messages: Maximum messages to keep after truncation.

    Returns:
        Tuple of (possibly truncated messages, warning text or None).
    """
    if len(messages) <= max_gap_messages:
        return messages, None

    omitted = len(messages) - max_context_messages
    truncated = messages[-max_context_messages:]
    warning = f"⚠️ {omitted} messages omitted (gap exceeded {max_gap_messages} messages)"
    return truncated, warning


@dataclass
class ChatMessage:
    """A chat message with role and content."""

    role: str  # "user" | "assistant"
    content: str


class ContextBuilder:
    """Transforms workspace messages into a chat history and user query.

    Applies role mapping and filtering:
    - User messages get role "user" with a [SenderName] prefix.
    - Agent messages from other agents get role "assistant", no prefix.
    - Messages from the agent itself are excluded entirely.
    - The last non-excluded message is separated as the user_query string.
    """

    def __init__(self, agent_member_id: str) -> None:
        self._agent_member_id = agent_member_id

    def build(
        self, messages: list[WorkspaceMessage]
    ) -> tuple[list[ChatMessage], str]:
        """Build chat history and extract the user query.

        Args:
            messages: Ordered list of workspace messages (oldest first).

        Returns:
            Tuple of (chat_history, user_query) where chat_history contains
            all non-excluded messages except the last, and user_query is the
            content string of the last non-excluded message.

        Raises:
            ValueError: If no non-excluded messages remain after filtering.
        """
        converted: list[ChatMessage] = []

        for msg in messages:
            if msg.sender_id == self._agent_member_id:
                continue

            if msg.sender_type == "user":
                content = f"[{msg.sender_name}] {msg.content}"
                converted.append(ChatMessage(role="user", content=content))
            else:
                converted.append(
                    ChatMessage(role="assistant", content=msg.content)
                )

        if not converted:
            raise ValueError(
                "No messages remaining after filtering self-messages"
            )

        user_query = converted[-1].content
        chat_history = converted[:-1]

        return chat_history, user_query
