"""
Agent Framework Skills System

A modular system for organizing agent capabilities into on-demand packages called "Skills".
Each skill bundles together metadata, detailed instructions, and associated tools.
Built-in skills are loaded exclusively from SKILL.md files.

Key Components:
    - Skill: Complete skill definition with metadata, instructions, and tools
    - SkillMetadata: Lightweight metadata for skill discovery (~50 tokens per skill)
    - SkillRegistry: Central registry for skill management
    - LoadedSkillContext: Runtime context for a loaded skill
    - SkillsMixin: Mixin class for integrating skills into agents

Example:
    from agent_framework.skills import Skill, SkillMetadata, SkillRegistry

    registry = SkillRegistry()

    from agent_framework.skills import get_all_builtin_skills
    for skill in get_all_builtin_skills():
        registry.register(skill)
"""

from .agent_mixin import SkillsMixin
from .base import (
    LoadedSkillContext,
    Skill,
    SkillCategory,
    SkillMetadata,
    SkillRegistry,
)
from .builtin import (
    get_all_builtin_skills,
)
from .discovery_prompt import (
    SKILLS_DISCOVERY_PROMPT,
    get_skills_discovery_prompt,
)
from .tools import (
    create_skill_tools,
    list_skills,
    load_skill,
    unload_skill,
)


__all__ = [
    "Skill",
    "SkillMetadata",
    "SkillRegistry",
    "LoadedSkillContext",
    "SkillCategory",
    "SkillsMixin",
    "SKILLS_DISCOVERY_PROMPT",
    "get_skills_discovery_prompt",
    "create_skill_tools",
    "list_skills",
    "load_skill",
    "unload_skill",
    "get_all_builtin_skills",
]
