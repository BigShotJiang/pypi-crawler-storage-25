"""
CustomSkillManager — manages the lifecycle of user-created custom skills.

Handles CRUD operations on the filesystem, registration/unregistration in the
SkillRegistry, ``{{SKILL_DIR}}`` placeholder resolution, and native tool attachment.
"""

from __future__ import annotations

import logging
import mimetypes
import re
import shutil
from pathlib import Path

from agent_framework.skills.base import Skill, SkillRegistry
from agent_framework.skills.markdown_loader import (
    MarkdownSkillLoader,
    SkillConfig,
    SkillFrontmatter,
    SkillFrontmatterMeta,
)
from agent_framework.tools.shell_tool import ShellTool
from agent_framework.tools.web_fetch_tool import WebFetchTool


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------

class CustomSkillError(Exception):
    """Base exception for custom-skill operations."""


class SkillNotFoundError(CustomSkillError):
    """Raised when a skill cannot be found in the registry or filesystem."""


class BuiltinSkillError(CustomSkillError):
    """Raised when an operation targets a builtin skill."""


class SkillConflictError(CustomSkillError):
    """Raised when a skill name conflicts with an existing skill."""


class InvalidSkillNameError(CustomSkillError):
    """Raised when a skill name does not match the required format."""


class PathTraversalError(CustomSkillError):
    """Raised when a directory-traversal attempt is detected."""


# ---------------------------------------------------------------------------
# Manager
# ---------------------------------------------------------------------------

_NAME_RE = re.compile(r"^[a-z0-9_-]+$")


class CustomSkillManager:
    """Manages the full lifecycle of user-created custom skills."""

    def __init__(self, registry: SkillRegistry, custom_skills_dir: Path) -> None:
        """Initialise the manager.

        Args:
            registry: The central skill registry.
            custom_skills_dir: Root directory for custom skill storage.
        """
        self._registry = registry
        self._custom_skills_dir = custom_skills_dir
        self._loader = MarkdownSkillLoader()
        self._builtin_names: set[str] = set()

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Create the custom-skills directory if absent and load existing skills.

        Each immediate subdirectory that contains a ``SKILL.md`` file is loaded,
        has native tools attached, and is registered with ``source="custom"``.
        Failures are logged as warnings without blocking the remaining skills.
        """
        self._custom_skills_dir.mkdir(parents=True, exist_ok=True)

        for child in sorted(self._custom_skills_dir.iterdir()):
            if not child.is_dir():
                continue
            skill_md = child / "SKILL.md"
            if not skill_md.exists():
                continue
            try:
                skill = self._loader.load_from_file(skill_md)
                self._warn_missing_bins(skill)
                self._attach_native_tools(skill)
                self._register_with_source(skill)
            except Exception as exc:
                logger.warning(
                    "Failed to load custom skill from %s: %s", child, exc,
                )

    # ------------------------------------------------------------------
    # Builtin / custom helpers
    # ------------------------------------------------------------------

    def set_builtin_names(self, names: set[str]) -> None:
        """Store the set of builtin skill names for protection checks.

        Args:
            names: Names of all builtin skills.
        """
        self._builtin_names = set(names)

    def is_builtin(self, name: str) -> bool:
        """Return ``True`` if *name* belongs to a builtin skill."""
        return name in self._builtin_names

    def is_custom(self, name: str) -> bool:
        """Return ``True`` if *name* is registered with ``source="custom"``."""
        return self._registry.get_source(name) == "custom"

    # ------------------------------------------------------------------
    # Placeholder resolution
    # ------------------------------------------------------------------

    def resolve_skill_dir_placeholder(self, text: str, skill_dir: Path) -> str:
        """Replace every ``{{SKILL_DIR}}`` occurrence with the canonical path.

        Args:
            text: Text that may contain the placeholder.
            skill_dir: Directory whose resolved path replaces the placeholder.

        Returns:
            The text with all placeholders substituted.
        """
        return text.replace("{{SKILL_DIR}}", str(skill_dir.resolve()))

    # ------------------------------------------------------------------
    # SKILL.md builder
    # ------------------------------------------------------------------

    def _build_skill_md(self, frontmatter: SkillFrontmatter, instructions: str) -> str:
        """Build the full content of a SKILL.md file.

        Args:
            frontmatter: Parsed frontmatter dataclass.
            instructions: Markdown body (instructions text).

        Returns:
            A string ready to be written as SKILL.md.
        """
        return f"---\n{frontmatter.to_yaml()}---\n\n{instructions}"

    # ------------------------------------------------------------------
    # Native-tool attachment
    # ------------------------------------------------------------------

    def _attach_native_tools(self, skill: Skill) -> None:
        """Attach ``ShellTool`` and ``WebFetchTool`` if not already present.

        Args:
            skill: The skill to augment.
        """
        existing_types = {type(t) for t in skill.tools}
        if ShellTool not in existing_types:
            skill.tools.append(ShellTool(default_timeout=60))
        if WebFetchTool not in existing_types:
            skill.tools.append(WebFetchTool())

    # ------------------------------------------------------------------
    # Registry helper
    # ------------------------------------------------------------------

    def _register_with_source(self, skill: Skill) -> None:
        """Register *skill* in the registry with ``source="custom"``.

        Args:
            skill: The skill to register.
        """
        self._registry.register(skill, source="custom")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _warn_missing_bins(self, skill: Skill) -> None:
        """Log a warning for each required binary that is not on PATH."""
        for binary in skill.metadata.requires_bins:
            if shutil.which(binary) is None:
                logger.warning(
                    "Custom skill '%s' requires binary '%s' which was not found in PATH",
                    skill.metadata.name,
                    binary,
                )

    # ------------------------------------------------------------------
    # Filename validation
    # ------------------------------------------------------------------

    def _validate_filename(self, filename: str) -> None:
        """Raise ``PathTraversalError`` if *filename* is unsafe.

        A filename is considered unsafe when it contains ``..``, starts with
        ``/``, or its resolved path escapes the skill directory.

        Args:
            filename: The filename to validate.

        Raises:
            PathTraversalError: If the filename is unsafe.
        """
        if ".." in filename:
            raise PathTraversalError(f"Directory traversal detected in filename: {filename}")
        if filename.startswith("/"):
            raise PathTraversalError(f"Absolute path not allowed: {filename}")

    @staticmethod
    def _references_file_path(entrypoint: str) -> bool:
        """Check if the entrypoint references a file path (not just a URL)."""
        import re

        # Strip URL-like tokens (e.g. http://..., https://...) before checking
        stripped = re.sub(r"[a-zA-Z][a-zA-Z0-9+.-]*://\S*", "", entrypoint)
        if "/" in stripped or "\\" in stripped:
            return True
        # Detect bare filenames with common script extensions (e.g. "helloworld.py")
        if re.search(r"\b\w+\.(py|sh|bash|js|ts|rb|pl|php|jar|exe|bat|cmd)\b", stripped):
            return True
        return False

    def _validate_entrypoint(self, entrypoint: str) -> None:
        """Reject entrypoints that reference file paths without ``{{SKILL_DIR}}``.

        Args:
            entrypoint: The entrypoint command string to validate.

        Raises:
            CustomSkillError: If the entrypoint contains a file path (``/`` or
                ``\\``) but does not use the ``{{SKILL_DIR}}`` placeholder.
        """
        if self._references_file_path(entrypoint) and "{{SKILL_DIR}}" not in entrypoint:
            raise CustomSkillError(
                f"Entrypoint references a file path without using the "
                f"{{{{SKILL_DIR}}}} placeholder: {entrypoint}"
            )

    # ------------------------------------------------------------------
    # CRUD operations
    # ------------------------------------------------------------------

    def create_skill(
        self,
        name: str,
        description: str,
        instructions: str,
        display_name: str | None = None,
        emoji: str | None = None,
        trigger_patterns: list[str] | None = None,
        entrypoint: str | None = None,
        runtime: str | None = None,
        requires_bins: list[str] | None = None,
        requires_env: list[str] | None = None,
        files: list[tuple[str, bytes]] | None = None,
    ) -> Skill:
        """Create a new custom skill on disk and register it.

        Args:
            name: Unique skill identifier (must match ``[a-z0-9_-]+``).
            description: Short description of the skill.
            instructions: Markdown body for the SKILL.md.
            display_name: Optional human-friendly display name.
            emoji: Optional emoji icon.
            trigger_patterns: Optional keyword patterns for discovery.
            entrypoint: Optional execution command.
            runtime: Optional runtime identifier.
            requires_bins: Optional list of required system binaries.
            requires_env: Optional list of required environment variables.
            files: Optional list of ``(filename, content_bytes)`` tuples.

        Returns:
            The newly created and registered Skill.

        Raises:
            InvalidSkillNameError: If *name* does not match the required format.
            SkillConflictError: If *name* conflicts with a builtin or existing skill.
        """
        if not _NAME_RE.match(name):
            raise InvalidSkillNameError(
                f"Skill name '{name}' does not match required format [a-z0-9_-]+"
            )

        if self.is_builtin(name) or self._registry.get(name) is not None:
            raise SkillConflictError(f"A skill named '{name}' already exists")

        skill_dir = self._custom_skills_dir / name
        skill_dir.mkdir(parents=True, exist_ok=True)

        if entrypoint is not None:
            self._validate_entrypoint(entrypoint)

        cfg = SkillConfig(
            emoji=emoji,
            trigger_patterns=list(trigger_patterns or []),
            entrypoint=entrypoint,
            runtime=runtime,
            requires_bins=list(requires_bins or []),
            requires_env=list(requires_env or []),
        )
        meta = SkillFrontmatterMeta(config=cfg)
        frontmatter = SkillFrontmatter(
            name=name,
            description=description,
            display_name=display_name,
            metadata=meta,
        )

        skill_md_content = self._build_skill_md(frontmatter, instructions)
        skill_md_path = skill_dir / "SKILL.md"
        skill_md_path.write_text(skill_md_content, encoding="utf-8")

        if files:
            for filename, content in files:
                (skill_dir / filename).write_bytes(content)

        skill = self._loader.load_from_file(skill_md_path)
        self._warn_missing_bins(skill)
        self._attach_native_tools(skill)
        self._register_with_source(skill)
        return skill

    def update_skill(
        self,
        name: str,
        description: str | None = None,
        instructions: str | None = None,
        display_name: str | None = None,
        emoji: str | None = None,
        trigger_patterns: list[str] | None = None,
        entrypoint: str | None = None,
        runtime: str | None = None,
        requires_bins: list[str] | None = None,
        requires_env: list[str] | None = None,
    ) -> Skill:
        """Update an existing custom skill's metadata and/or instructions.

        Only the fields that are explicitly provided (not ``None``) are updated;
        the rest keep their current values.

        Args:
            name: Name of the skill to update.
            description: New description (optional).
            instructions: New instructions body (optional).
            display_name: New display name (optional).
            emoji: New emoji (optional).
            trigger_patterns: New trigger patterns (optional).
            entrypoint: New entrypoint command (optional).
            runtime: New runtime identifier (optional).
            requires_bins: New required binaries (optional).
            requires_env: New required env vars (optional).

        Returns:
            The updated Skill.

        Raises:
            BuiltinSkillError: If *name* is a builtin skill.
            SkillNotFoundError: If the skill does not exist.
        """
        if self.is_builtin(name):
            raise BuiltinSkillError(f"Cannot modify builtin skill '{name}'")

        skill_dir = self._custom_skills_dir / name
        skill_md_path = skill_dir / "SKILL.md"
        if not skill_md_path.exists():
            raise SkillNotFoundError(f"Skill '{name}' not found")

        content = skill_md_path.read_text(encoding="utf-8")
        fm_dict, body = self._loader._parse_frontmatter(content)
        frontmatter = SkillFrontmatter.from_dict(fm_dict)

        if description is not None:
            frontmatter.description = description
        if display_name is not None:
            frontmatter.display_name = display_name
        if emoji is not None:
            frontmatter.metadata.config.emoji = emoji
        if trigger_patterns is not None:
            frontmatter.metadata.config.trigger_patterns = list(trigger_patterns)
        if entrypoint is not None:
            self._validate_entrypoint(entrypoint)
            frontmatter.metadata.config.entrypoint = entrypoint
        if runtime is not None:
            frontmatter.metadata.config.runtime = runtime
        if requires_bins is not None:
            frontmatter.metadata.config.requires_bins = list(requires_bins)
        if requires_env is not None:
            frontmatter.metadata.config.requires_env = list(requires_env)

        new_body = instructions if instructions is not None else body
        skill_md_content = self._build_skill_md(frontmatter, new_body)
        skill_md_path.write_text(skill_md_content, encoding="utf-8")

        was_loaded = self._registry.is_loaded(name)
        if was_loaded:
            self._registry.unload(name)

        self._registry.unregister(name)

        skill = self._loader.load_from_file(skill_md_path)
        self._warn_missing_bins(skill)
        self._attach_native_tools(skill)
        self._register_with_source(skill)

        if was_loaded:
            self._registry.load(name)

        return skill

    def delete_skill(self, name: str) -> None:
        """Delete a custom skill from disk and the registry.

        Args:
            name: Name of the skill to delete.

        Raises:
            BuiltinSkillError: If *name* is a builtin skill.
            SkillNotFoundError: If the skill does not exist.
        """
        if self.is_builtin(name):
            raise BuiltinSkillError(f"Cannot delete builtin skill '{name}'")

        skill_dir = self._custom_skills_dir / name
        if not skill_dir.exists():
            raise SkillNotFoundError(f"Skill '{name}' not found")

        if self._registry.is_loaded(name):
            self._registry.unload(name)

        self._registry.unregister(name)
        shutil.rmtree(skill_dir)

    # ------------------------------------------------------------------
    # Directory / file helpers
    # ------------------------------------------------------------------

    def get_skill_dir(self, name: str) -> Path:
        """Return the directory path for a custom skill.

        Args:
            name: Skill identifier.

        Returns:
            Path to the skill's subdirectory inside ``CUSTOM_SKILLS_DIR``.
        """
        return self._custom_skills_dir / name

    def list_skill_files(self, name: str) -> list[str]:
        """List files in a skill directory, excluding SKILL.md.

        Args:
            name: Skill identifier.

        Returns:
            Sorted list of filenames.

        Raises:
            SkillNotFoundError: If the skill directory does not exist.
        """
        skill_dir = self._custom_skills_dir / name
        if not skill_dir.exists():
            raise SkillNotFoundError(f"Skill '{name}' not found")

        return sorted(
            f.name for f in skill_dir.iterdir() if f.is_file() and f.name != "SKILL.md"
        )

    def get_file(self, name: str, filename: str) -> tuple[bytes, str]:
        """Read a file from a skill directory.

        Args:
            name: Skill identifier.
            filename: Name of the file to read.

        Returns:
            Tuple of ``(content_bytes, mime_type)``.

        Raises:
            PathTraversalError: If *filename* is unsafe.
            SkillNotFoundError: If the skill or file does not exist.
        """
        self._validate_filename(filename)

        skill_dir = self._custom_skills_dir / name
        if not skill_dir.exists():
            raise SkillNotFoundError(f"Skill '{name}' not found")

        file_path = skill_dir / filename
        if not file_path.exists():
            raise SkillNotFoundError(f"File '{filename}' not found in skill '{name}'")

        content = file_path.read_bytes()
        mime_type, _ = mimetypes.guess_type(filename)
        return content, mime_type or "application/octet-stream"

    def add_file(self, name: str, filename: str, content: bytes) -> None:
        """Write a file into a skill directory.

        Args:
            name: Skill identifier.
            filename: Name of the file to write.
            content: Raw bytes to write.

        Raises:
            PathTraversalError: If *filename* is unsafe.
            SkillNotFoundError: If the skill directory does not exist.
        """
        self._validate_filename(filename)

        skill_dir = self._custom_skills_dir / name
        if not skill_dir.exists():
            raise SkillNotFoundError(f"Skill '{name}' not found")

        (skill_dir / filename).write_bytes(content)

    def delete_file(self, name: str, filename: str) -> None:
        """Delete a file from a skill directory.

        Args:
            name: Skill identifier.
            filename: Name of the file to delete.

        Raises:
            PathTraversalError: If *filename* is unsafe.
            SkillNotFoundError: If the skill or file does not exist.
        """
        self._validate_filename(filename)

        skill_dir = self._custom_skills_dir / name
        if not skill_dir.exists():
            raise SkillNotFoundError(f"Skill '{name}' not found")

        file_path = skill_dir / filename
        if not file_path.exists():
            raise SkillNotFoundError(f"File '{filename}' not found in skill '{name}'")

        file_path.unlink()


__all__ = [
    "CustomSkillError",
    "SkillNotFoundError",
    "BuiltinSkillError",
    "SkillConflictError",
    "InvalidSkillNameError",
    "PathTraversalError",
    "CustomSkillManager",
]
