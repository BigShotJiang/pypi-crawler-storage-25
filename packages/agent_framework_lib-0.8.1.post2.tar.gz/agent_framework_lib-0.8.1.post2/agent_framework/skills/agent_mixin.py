"""
Skills Mixin for BaseAgent.

Provides skills capabilities to agents via mixin pattern.
This allows clean integration without modifying the core BaseAgent class.

Usage:
    ```python
    from agent_framework.core.base_agent import BaseAgent
    from agent_framework.skills.agent_mixin import SkillsMixin

    class MyAgent(SkillsMixin, BaseAgent):
        pass

    # Skills are automatically available
    agent = MyAgent(agent_id="my-agent", name="My Agent", description="...")
    agent.register_builtin_skills()
    context = agent.load_skill("chart")
    ```

The mixin provides:
- Skill registry management
- Skill registration, loading, and unloading
- Access to skill tools for agent use
- Combined instructions from loaded skills
- Combined tools from loaded skills
"""

import logging
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from .base import LoadedSkillContext, Skill, SkillRegistry


logger = logging.getLogger(__name__)


class SkillsMixin:
    """
    Mixin that adds skills capabilities to agents.

    Agents that inherit this mixin gain:
    - A skill registry for managing skills
    - Methods to register, load, and unload skills
    - Access to skill management tools
    - Combined instructions and tools from loaded skills

    Attributes:
        _skill_registry: SkillRegistry instance for managing skills
        _skill_tools: Cached skill management tools
    """

    # These will be set by the agent class
    agent_id: str

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize skills mixin."""
        # Import here to avoid circular imports
        from .base import SkillRegistry

        # Initialize skills attributes before super().__init__
        self._skill_registry: SkillRegistry = SkillRegistry()
        self._skill_tools: list[Callable[..., str]] = []

        # Call parent __init__
        super().__init__(*args, **kwargs)

    @property
    def skill_registry(self) -> "SkillRegistry":
        """
        Access the skill registry.

        Returns:
            The SkillRegistry instance for this agent
        """
        return self._skill_registry

    def register_skill(self, skill: "Skill") -> None:
        """
        Register a skill with this agent.

        Args:
            skill: The Skill instance to register

        Raises:
            ValueError: If the skill is invalid
        """
        self._skill_registry.register(skill)
        logger.debug(f"Registered skill '{skill.metadata.name}' with agent")

    def load_skill(self, name: str) -> "LoadedSkillContext":
        """
        Load a skill by name.

        Loading a skill resolves its instructions and activates its tools.
        Dependencies are automatically loaded first.

        Args:
            name: Name of the skill to load

        Returns:
            LoadedSkillContext with resolved instructions and tools

        Raises:
            ValueError: If skill not found or circular dependency detected
        """
        context = self._skill_registry.load(name)
        logger.info(f"Loaded skill '{name}' for agent '{getattr(self, 'agent_id', 'unknown')}'")
        return context

    def unload_skill(self, name: str) -> None:
        """
        Unload a skill by name.

        Unloading a skill deactivates its tools and removes it from
        the loaded set.

        Args:
            name: Name of the skill to unload
        """
        self._skill_registry.unload(name)
        logger.info(f"Unloaded skill '{name}' for agent '{getattr(self, 'agent_id', 'unknown')}'")

    def register_builtin_skills(self) -> None:
        """Register all built-in skills with this agent.

        After registering builtins, also loads any custom skills found in
        the ``CUSTOM_SKILLS_DIR`` environment variable (default ``./custom_skills``).
        Skills already registered are skipped.
        """
        from .builtin import get_all_builtin_skills

        builtin_skills = get_all_builtin_skills()
        registered_count = 0

        for skill in builtin_skills:
            if self._skill_registry.get(skill.metadata.name) is not None:
                continue
            self.register_skill(skill)
            registered_count += 1

        if registered_count > 0:
            logger.info(
                f"Registered {registered_count} built-in skills "
                f"for agent '{getattr(self, 'agent_id', 'unknown')}'"
            )
        elif builtin_skills:
            logger.debug(
                f"All {len(builtin_skills)} built-in skills already registered "
                f"for agent '{getattr(self, 'agent_id', 'unknown')}'"
            )

        self._register_custom_skills()

    def _register_custom_skills(self) -> None:
        """Load custom skills from CUSTOM_SKILLS_DIR into this agent's registry.

        Each subdirectory containing a SKILL.md is loaded, has native tools
        attached, and is registered with ``source="custom"``.  Failures are
        logged as warnings without blocking the remaining skills.
        """
        import os
        import shutil

        from .markdown_loader import MarkdownSkillLoader
        from ..tools.shell_tool import ShellTool
        from ..tools.web_fetch_tool import WebFetchTool

        custom_dir = Path(os.getenv("CUSTOM_SKILLS_DIR", "./custom_skills"))
        if not custom_dir.is_dir():
            return

        loader = MarkdownSkillLoader()
        count = 0

        for child in sorted(custom_dir.iterdir()):
            if not child.is_dir():
                continue
            skill_md = child / "SKILL.md"
            if not skill_md.exists():
                continue
            try:
                skill = loader.load_from_file(skill_md)
                if self._skill_registry.get(skill.metadata.name) is not None:
                    continue
                existing_types = {type(t) for t in skill.tools}
                if ShellTool not in existing_types:
                    skill.tools.append(ShellTool(default_timeout=60))
                if WebFetchTool not in existing_types:
                    skill.tools.append(WebFetchTool())
                for binary in skill.metadata.requires_bins:
                    if shutil.which(binary) is None:
                        logger.warning(
                            "Custom skill '%s' requires binary '%s' not found in PATH",
                            skill.metadata.name,
                            binary,
                        )
                self._skill_registry.register(skill, source="custom")
                count += 1
            except Exception as exc:
                logger.warning("Failed to load custom skill from %s: %s", child, exc)

        if count > 0:
            logger.info(
                f"Registered {count} custom skill(s) "
                f"for agent '{getattr(self, 'agent_id', 'unknown')}'"
            )

    def get_skill_tools(self) -> list[Callable[..., str]]:
        """
        Get skill management tools for the agent.

        Returns tools that allow the agent to discover, load, and unload
        skills at runtime. These tools are bound to this agent's registry.

        Returns:
            List of callable tools: [list_skills, load_skill, unload_skill]
        """
        if not self._skill_tools:
            from .tools import create_skill_tools

            self._skill_tools = create_skill_tools(self._skill_registry)
        return self._skill_tools

    def get_loaded_skill_instructions(self) -> str:
        """
        Get combined instructions from all loaded skills.

        Returns a formatted string containing the instructions from
        all currently loaded skills, suitable for injection into
        the agent's context.

        Returns:
            Combined instructions string, or empty string if no skills loaded
        """
        instructions: list[str] = []
        for name in self._skill_registry.list_loaded():
            context = self._skill_registry.get_loaded_context(name)
            if context:
                instructions.append(f"## {name} Skill\n{context.instructions}")

        return "\n\n".join(instructions)

    def get_loaded_skill_tools(self) -> list[Any]:
        """
        Get all tools from loaded skills.

        Returns a list of all tool instances from all currently
        loaded skills.

        Returns:
            List of tool instances from loaded skills
        """
        tools: list[Any] = []
        for name in self._skill_registry.list_loaded():
            context = self._skill_registry.get_loaded_context(name)
            if context:
                tools.extend(context.tools)
        return tools

    def get_skills_summary(self) -> dict[str, Any]:
        """
        Get a summary of skills status for metadata.

        Returns:
            Dictionary with total_skills and loaded_skills counts
        """
        all_skills = self._skill_registry.list_all()
        loaded_skills = self._skill_registry.list_loaded()
        return {
            "total_skills": len(all_skills),
            "loaded_skills": len(loaded_skills),
            "loaded_skill_names": loaded_skills,
        }

    def register_skills_from_dir(self, skills_dir: Path) -> None:
        """Load all SKILL.md files from a directory and register them.

        Native tools (ShellTool, WebFetchTool) are attached to each loaded skill
        if not already present.

        Args:
            skills_dir: Directory containing SKILL.md files.

        Raises:
            ValueError: If the directory does not exist.
        """
        from agent_framework.skills.markdown_loader import MarkdownSkillLoader
        from agent_framework.tools.shell_tool import ShellTool
        from agent_framework.tools.web_fetch_tool import WebFetchTool

        skills_dir = Path(skills_dir)
        if not skills_dir.exists() or not skills_dir.is_dir():
            raise ValueError(f"Skills directory not found: {skills_dir}")

        loader = MarkdownSkillLoader()
        skills = loader.load_from_dir(skills_dir)

        for skill in skills:
            existing_types = {type(t) for t in skill.tools}
            if ShellTool not in existing_types:
                skill.tools.append(ShellTool())
            if WebFetchTool not in existing_types:
                skill.tools.append(WebFetchTool())
            try:
                self._skill_registry.register(skill)
                logger.debug("Registered SKILL.md skill '%s'", skill.metadata.name)
            except Exception as exc:
                logger.warning(
                    "Could not register skill '%s': %s", skill.metadata.name, exc
                )

    def apply_capability_set(self, capability_set: "Any") -> None:
        """Filter the SkillRegistry to only keep skills in capability_set.skill_ids.

        This method is idempotent: applying the same CapabilitySet twice produces
        the same registry state.

        Args:
            capability_set: A CapabilitySet instance with a skill_ids attribute.
        """
        allowed = set(capability_set.skill_ids)
        all_names = [m.name for m in self._skill_registry.list_all()]
        for name in all_names:
            if name not in allowed:
                self._skill_registry.unregister(name)


__all__ = [
    "SkillsMixin",
]
