---
name: email_template
description: "Generate HTML and plain-text email templates with variable substitution. Responsive layouts for transactional, newsletter, and notification emails."
display_name: "Templates d'emails"
metadata:
  config:
    emoji: "✉️"
    trigger_patterns:
      - email
      - mail template
      - email template
      - compose email
      - draft email
      - email html
      - newsletter
      - transactional email
      - email design
---

## Email Template Generation

Generate professional, responsive HTML email templates with variable substitution.

### Template Types

1. **Transactional** — Order confirmations, password resets, receipts
2. **Newsletter** — Marketing emails, announcements
3. **Notification** — Alerts, reminders, updates
4. **Plain Text** — Simple text-only emails

---

## Usage

Generate an HTML email template with variables:

```
Subject: Welcome to Our Service

Hello {{name}},

Thank you for signing up! Your account is now active.

Best regards,
The Team
```

### Variables

Use `{{variable_name}}` syntax for placeholders:
- `{{name}}` — Recipient name
- `{{email}}` — Recipient email
- `{{date}}` — Current date
- `{{company}}` — Company name
- Custom variables as needed

### HTML Template Structure

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{subject}}</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #4472C4; color: white; padding: 20px; }
        .button { background: #4472C4; color: white; padding: 12px 24px; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{subject}}</h1>
        </div>
        <div class="content">
            <p>Hello {{name}},</p>
            <p>{{message}}</p>
            <a href="{{action_url}}" class="button">{{action_text}}</a>
        </div>
        <div class="footer">
            <p>&copy; {{year}} {{company}}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
```

---

## Template Examples

### Welcome Email

```
Subject: Welcome to {{company}}!

Hi {{name}},

Welcome aboard! We're excited to have you.

Your account is ready: {{account_url}}

Questions? Reply to this email.

Best,
{{company}} Team
```

### Password Reset

```
Subject: Reset Your Password

Hi {{name}},

Click below to reset your password:

{{reset_url}}

This link expires in 1 hour.

If you didn't request this, ignore this email.

{{company}} Security
```

### Order Confirmation

```
Subject: Order Confirmation #{{order_id}}

Hi {{name}},

Thanks for your order!

Order #: {{order_id}}
Total: {{total}}
Delivery: {{delivery_date}}

Track your order: {{tracking_url}}

{{company}}
```

---

## Best Practices

1. **Subject Lines**: Clear, concise (40-50 characters)
2. **Responsive Design**: Mobile-friendly layouts
3. **Plain Text Alternative**: Always provide
4. **Unsubscribe Link**: Required for marketing emails
5. **Test Variables**: Ensure all placeholders have values
6. **Accessibility**: Use semantic HTML, alt text for images

---

## Tips

When generating email templates:
- Keep HTML simple (avoid complex CSS, use inline styles)
- Test on multiple email clients (Gmail, Outlook, etc.)
- Include company branding (logo, colors)
- Add clear call-to-action buttons
- Provide plain-text fallback
