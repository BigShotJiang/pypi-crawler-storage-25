#!/usr/bin/env python3
"""Format Python code using black."""
import json
import sys
import subprocess

def main():
    try:
        code = sys.stdin.read()
        # Run black in pipe mode
        result = subprocess.run(
            ["black", "-", "--quiet"],
            input=code,
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode == 0:
            print(result.stdout)
        else:
            raise ValueError(result.stderr)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
