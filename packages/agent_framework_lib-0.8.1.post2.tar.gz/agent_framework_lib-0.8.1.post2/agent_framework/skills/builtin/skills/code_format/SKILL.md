---
name: code_format
description: "Format and lint code (Python, JavaScript, JSON, YAML) using black, ruff, prettier."
display_name: "Formatage de code"
metadata:
  config:
    emoji: "💻"
    trigger_patterns:
      - format code
      - lint
      - black
      - prettier
      - code style
      - fix syntax
      - beautify code
      - code formatting
    requires:
      bins:
        - uv
---

## Code Formatting and Linting

Format code using industry-standard formatters:

- **Python**: black (formatting) + ruff (linting)
- **JavaScript/TypeScript**: prettier
- **JSON/YAML**: pretty-print formatting

### Format Python Code

```bash
echo 'def foo(x,y):return x+y' | uv run python agent_framework/skills/builtin/skills/code_format/format_python.py
```

Output:
```python
def foo(x, y):
    return x + y
```

### Format JavaScript

```bash
echo 'function foo(x,y){return x+y;}' | uv run python agent_framework/skills/builtin/skills/code_format/format_js.py
```

### Lint Python

```bash
echo 'import os\nx=1' | uv run python agent_framework/skills/builtin/skills/code_format/lint_python.py
```

Returns linting issues and suggestions.
