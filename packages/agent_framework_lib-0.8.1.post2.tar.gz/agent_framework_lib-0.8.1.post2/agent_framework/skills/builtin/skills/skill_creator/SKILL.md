---
name: skill_creator
description: "Guide for creating custom skills via API, UI, or code. Includes SKILL.md structure, YAML frontmatter reference, and validation workflow."
display_name: "Création de skills"
metadata:
  config:
    emoji: "🏗️"
    trigger_patterns:
      - create skill
      - new skill
      - skill generator
      - make skill
      - build skill
      - custom skill
      - skill development
      - define skill
      - skill template
---

## Skill Creation Guide

You can help users create custom skills for the AgentFramework in three ways:
1. **Via API** — POST `/api/skills` (immediate registration)
2. **Via Code** — Create `custom_skills/skill-name/SKILL.md` (requires restart)
3. **Via UI** — Skills tab in web interface (uses API internally)

---

## Quick Decision Guide

```
User wants to create a skill?
├── "Create a skill that..." → Use API method (immediate)
├── "Build a skill for..." → Use API method (immediate)
├── "I need a custom skill..." → Use API method (immediate)
└── Advanced developer? → Suggest code method (more control)
```

**DEFAULT**: Always use the API method unless the user specifically requests code-based creation.

---

## Method 1: API Creation (RECOMMENDED)

### Step 1: Design the Skill

Work with the user to define:
- **Name**: Lowercase, alphanumeric + dashes/underscores only (e.g., `my-custom-skill`)
- **Description**: One-line summary of what the skill does
- **Instructions**: Detailed Markdown instructions for the agent
- **Type**: Skill_Markdown (instructions only) or Skill_Script (with executable scripts)
- **Trigger patterns**: Keywords for auto-discovery (optional but recommended)

### Step 2: Build the JSON Payload

For a **Skill_Markdown** (instructions only):
```json
{
  "name": "my-skill",
  "description": "Short description of the skill",
  "instructions": "## Instructions\n\nDetailed Markdown instructions here...",
  "display_name": "My Custom Skill",
  "emoji": "🔧",
  "trigger_patterns": ["keyword1", "keyword2"]
}
```

For a **Skill_Script** (with executable Python script):
```json
{
  "name": "my-script-skill",
  "description": "Skill with Python execution",
  "instructions": "## Instructions\n\nHow to use this skill...\n\n### Execution\n\nRun via:\n```bash\necho '{\"data\": \"value\"}' | uv run python {{SKILL_DIR}}/my_script.py\n```",
  "display_name": "My Script Skill",
  "emoji": "⚙️",
  "trigger_patterns": ["script", "execute"],
  "entrypoint": "uv run python {{SKILL_DIR}}/my_script.py",
  "runtime": "python",
  "requires_bins": ["uv"]
}
```

### Step 3: Validate (Optional but Recommended)

Before creating, validate the skill using `POST /api/skills/validate`:

```bash
curl -X POST http://localhost:8000/api/skills/validate \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-skill",
    "description": "Description here",
    "instructions": "## Instructions\n\nDetailed content..."
  }'
```

Response:
```json
{
  "score": 85,
  "suggestions": ["Add more examples"],
  "warnings": []
}
```

**Target score**: ≥ 85 for high-quality skills.

### Step 4: Create the Skill

Send POST request to `/api/skills`:

```bash
curl -X POST http://localhost:8000/api/skills \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-skill",
    "description": "Short description",
    "instructions": "## Instructions\n\nFull content...",
    "display_name": "My Skill",
    "emoji": "🔧",
    "trigger_patterns": ["keyword1", "keyword2"]
  }'
```

Success response (201 Created):
```json
{
  "name": "my-skill",
  "description": "Short description",
  "display_name": "My Skill",
  "emoji": "🔧",
  "source": "custom",
  "trigger_patterns": ["keyword1", "keyword2"]
}
```

**The skill is now immediately available to the agent!**

### Step 5: Upload Scripts (For Skill_Script only)

If the skill includes Python scripts, upload them via `POST /api/skills/{name}/files`:

```bash
curl -X POST http://localhost:8000/api/skills/my-script-skill/files \
  -F "file=@my_script.py"
```

Response:
```json
{
  "status": "uploaded",
  "filename": "my_script.py"
}
```

---

## Method 2: Code-Based Creation

For advanced users who want version control and manual editing.

### Step 1: Create Directory

```bash
mkdir -p custom_skills/my-skill
```

### Step 2: Create SKILL.md

Create `custom_skills/my-skill/SKILL.md` with this structure:

```markdown
---
name: my-skill
description: "Short description of the skill"
display_name: "My Custom Skill"
metadata:
  config:
    emoji: "🔧"
    trigger_patterns:
      - keyword1
      - keyword2
    requires:
      bins:
        - uv
---

## Instructions

Detailed Markdown instructions for the agent.

### Usage

Explain how the agent should use this skill.

### Examples

Provide concrete examples.
```

### Step 3: Add Scripts (For Skill_Script)

Place Python scripts in the same directory:
```
custom_skills/my-skill/
  SKILL.md
  my_script.py
  utils.py
```

### Step 4: Restart Agent

The skill will be auto-discovered on next agent startup.

---

## SKILL.md Structure Reference

### Frontmatter (YAML)

The frontmatter block contains metadata:

```yaml
---
name: skill-name              # REQUIRED: Unique identifier (a-z0-9_-)
description: "One-line desc"  # REQUIRED: Short description
display_name: "Display Name"  # OPTIONAL: UI-friendly name
homepage: "https://..."       # OPTIONAL: Documentation URL
metadata:
  config:
    emoji: "🔧"               # OPTIONAL: Icon for UI
    primaryEnv: API_KEY       # OPTIONAL: Main env variable
    trigger_patterns:         # OPTIONAL: Keywords for discovery
      - keyword1
      - keyword2
    entrypoint: "uv run ..."  # OPTIONAL: Execution command (Skill_Script)
    runtime: python           # OPTIONAL: Runtime identifier
    requires:
      bins:                   # OPTIONAL: Required system binaries
        - uv
        - curl
      env:                    # OPTIONAL: Required environment variables
        - API_KEY
    install:                  # OPTIONAL: Installation instructions
      - command: "uv pip install pandas"
        description: "Install pandas"
---
```

### Instructions (Markdown)

After the frontmatter, provide detailed instructions in Markdown:

```markdown
## Skill Title

Brief introduction to the skill.

### When to Use

Explain use cases and scenarios.

### Usage

For Skill_Markdown: Explain how to format responses.
For Skill_Script: Provide command examples.

### Examples

Provide concrete examples with input/output.

### Best Practices

Tips for optimal use of the skill.
```

---

## Skill Types

### Skill_Markdown

**Use when**: The skill provides instructions for formatting agent responses (forms, display, templates).

**Characteristics**:
- No Python scripts
- Instructions only (Markdown)
- Agent uses instructions to format output
- Examples: `form`, `image_display`, `multimodal`

**Example SKILL.md**:
```markdown
---
name: my-formatter
description: "Format data in a specific way"
metadata:
  config:
    emoji: "📝"
    trigger_patterns: [format, display]
---

## Instructions

When the user asks to format data, generate a JSON object like this:
\```json
{"formatted": true, "data": "..."}
\```
```

### Skill_Script

**Use when**: The skill executes code (file generation, API calls, data processing).

**Characteristics**:
- One or more Python scripts
- Scripts executed via `ShellTool` (shell_exec)
- Scripts receive JSON on stdin, produce JSON on stdout
- Must include `entrypoint` in frontmatter
- Examples: `chart`, `excel`, `unified_pdf`

**Example SKILL.md**:
```markdown
---
name: my-processor
description: "Process data via Python script"
metadata:
  config:
    emoji: "⚙️"
    trigger_patterns: [process, compute]
    entrypoint: "uv run python {{SKILL_DIR}}/process.py"
    runtime: python
    requires:
      bins: [uv]
---

## Instructions

Process data by piping JSON to the script:

\```bash
echo '{"input": "data"}' | uv run python {{SKILL_DIR}}/process.py --output result.json
\```

### Script Output Format

The script must print JSON to stdout:
\```json
{"status": "success", "result": "...", "file_id": "..."}
\```
```

---

## Script Output Standard (Skill_Script)

All Skill_Script scripts must follow this output format:

### Success Output (stdout)

```json
{
  "status": "success",
  "file_id": "uuid",
  "download_url": "/files/uuid/download",
  "filename": "output.png",
  "size_bytes": 1234,
  "mime_type": "image/png"
}
```

### Error Output (stderr)

```json
{
  "status": "error",
  "message": "Description of what went wrong"
}
```

Scripts should:
- Exit with code 0 on success
- Exit with code 1 (or non-zero) on error
- Print JSON to stdout on success
- Print JSON to stderr on error

---

## Common Patterns

### Pattern 1: Simple Formatter (Skill_Markdown)

Used for generating structured output (JSON, forms, options).

```yaml
name: json-formatter
description: "Format data as JSON"
metadata:
  config:
    trigger_patterns: [json, format json]
```

### Pattern 2: File Generator (Skill_Script)

Used for creating downloadable files (images, documents, spreadsheets).

```yaml
name: file-gen
description: "Generate files"
metadata:
  config:
    entrypoint: "uv run python {{SKILL_DIR}}/generate.py"
    requires:
      bins: [uv]
```

### Pattern 3: API Wrapper (Skill_Script)

Used for calling external APIs (web search, AI services, databases).

```yaml
name: api-caller
description: "Call external API"
metadata:
  config:
    entrypoint: "uv run python {{SKILL_DIR}}/call_api.py"
    requires:
      env: [API_KEY]
```

### Pattern 4: Data Transformer (Skill_Script)

Used for processing and transforming data (CSV, JSON, XML).

```yaml
name: data-transform
description: "Transform data formats"
metadata:
  config:
    entrypoint: "uv run python {{SKILL_DIR}}/transform.py"
```

---

## Validation Rules

When validating a skill, the system checks:

1. **Name format**: Must match `^[a-z0-9_-]+$`
2. **Required fields**: `name`, `description`, `instructions` must be present
3. **Instructions length**: Should be ≥ 50 characters for meaningful content
4. **Sections**: Well-structured Markdown with headers (`##`)
5. **Examples**: At least one code example is recommended
6. **Trigger patterns**: At least 2-3 keywords recommended
7. **Dependencies**: `requires.bins` should list all system binaries used

**Validation score breakdown**:
- Base: 50 points
- Good length: +15 points
- Has sections: +10 points
- Has examples: +10 points
- Has trigger patterns: +10 points
- Complete frontmatter: +5 points

**Target**: ≥ 85 points for production-ready skills.

---

## Error Handling

### Common Errors

| Error Code | Meaning | Solution |
|------------|---------|----------|
| 400 | Invalid name pattern | Use only lowercase, numbers, dashes, underscores |
| 409 | Skill already exists | Choose a different name or update existing skill |
| 422 | Invalid data | Check JSON structure and required fields |

### Example Error Response

```json
{
  "detail": "Invalid skill name 'My Skill!'. Must match pattern ^[a-z0-9_-]+$"
}
```

---

## Best Practices

1. **Clear naming**: Use descriptive, hyphenated names (e.g., `email-generator`, `csv-processor`)
2. **Rich instructions**: Provide detailed Markdown with examples, use cases, and edge cases
3. **Trigger patterns**: Include synonyms and related terms (5-10 patterns recommended)
4. **Validation first**: Always validate before creating to catch issues early
5. **Test locally**: For Skill_Script, test scripts independently before uploading
6. **Document dependencies**: List all required binaries and environment variables
7. **Error messages**: Scripts should provide helpful error messages in JSON format
8. **Versioning**: Consider adding version numbers to skill names for major updates

---

## Quick Examples

### Example 1: Simple Text Formatter (Skill_Markdown)

```json
{
  "name": "uppercase-formatter",
  "description": "Convert text to uppercase format",
  "instructions": "## Uppercase Formatter\n\nWhen asked to uppercase text, return:\n```\nTEXT IN UPPERCASE\n```",
  "emoji": "🔠",
  "trigger_patterns": ["uppercase", "caps", "all caps"]
}
```

### Example 2: CSV Generator (Skill_Script)

```json
{
  "name": "csv-generator",
  "description": "Generate CSV files from JSON data",
  "instructions": "## CSV Generator\n\nConvert JSON to CSV:\n```bash\necho '[{\"name\":\"John\",\"age\":30}]' | uv run python {{SKILL_DIR}}/to_csv.py --filename data.csv\n```",
  "emoji": "📊",
  "trigger_patterns": ["csv", "export csv", "create csv"],
  "entrypoint": "uv run python {{SKILL_DIR}}/to_csv.py",
  "runtime": "python",
  "requires_bins": ["uv"]
}
```

---

## Workflow Summary

```
1. User requests skill creation
   ↓
2. Design skill (name, description, type)
   ↓
3. Write instructions (Markdown)
   ↓
4. Validate via POST /api/skills/validate
   ↓
5. Adjust if score < 85
   ↓
6. Create via POST /api/skills
   ↓
7. Upload scripts if Skill_Script
   ↓
8. Skill is immediately available!
```

---

## Additional Resources

- **API Documentation**: See `/api/skills` endpoints documentation
- **Builtin Skills**: Reference existing builtin skills as templates:
  - `chart` — Skill_Script with image generation
  - `excel` — Skill_Script with file creation
  - `form` — Skill_Markdown with JSON output
  - `unified_pdf` — Skill_Script with HTML processing
- **Skill Registry**: All skills are registered in `SkillRegistry`
- **Custom Skills Directory**: `custom_skills/` for code-based skills

---

## Tips for Agent Responses

When helping users create skills:

1. **Ask questions** to clarify requirements (name, type, purpose, inputs/outputs)
2. **Suggest trigger patterns** based on the skill's purpose
3. **Validate first** before creating to avoid errors
4. **Provide the API curl command** ready to execute
5. **Explain next steps** (how to use the skill, how to test it)
6. **Offer to create the script** if it's a Skill_Script
7. **Iterate** if validation score is low

Remember: Creating a high-quality skill involves thoughtful design, clear instructions, and thorough testing!
