---
name: data_format
description: "Convert between JSON and YAML formats, validate JSON schemas, and format data structures."
display_name: "Conversion de formats de données"
metadata:
  config:
    emoji: "🔄"
    trigger_patterns:
      - json
      - yaml
      - convert format
      - validate json
      - format data
      - json to yaml
      - yaml to json
      - json schema
      - pretty print
    requires:
      bins:
        - uv
---

## Data Format Conversion and Validation

Convert between JSON and YAML formats and validate JSON against schemas.

### Operations

1. **JSON to YAML** — Convert JSON to YAML format
2. **YAML to JSON** — Convert YAML to JSON format
3. **Format/Pretty Print** — Format JSON or YAML with indentation
4. **Validate JSON Schema** — Validate JSON against a JSON Schema

---

## Convert JSON to YAML

```bash
echo '{"name": "Alice", "age": 30}' | uv run python agent_framework/skills/builtin/skills/data_format/json_to_yaml.py
```

Output:
```yaml
name: Alice
age: 30
```

---

## Convert YAML to JSON

```bash
echo 'name: Alice\nage: 30' | uv run python agent_framework/skills/builtin/skills/data_format/yaml_to_json.py
```

Output:
```json
{
  "name": "Alice",
  "age": 30
}
```

---

## Validate JSON Schema

```bash
echo '{"data": {...}, "schema": {...}}' | uv run python agent_framework/skills/builtin/skills/data_format/validate_schema.py
```
