#!/usr/bin/env python3
"""Convert JSON to YAML."""
import json
import sys
import yaml

def main():
    try:
        data = json.load(sys.stdin)
        yaml.dump(data, sys.stdout, default_flow_style=False, allow_unicode=True)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
