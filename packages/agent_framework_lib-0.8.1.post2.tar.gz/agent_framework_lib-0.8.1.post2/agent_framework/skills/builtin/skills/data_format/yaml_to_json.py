#!/usr/bin/env python3
"""Convert YAML to JSON."""
import json
import sys
import yaml

def main():
    try:
        data = yaml.safe_load(sys.stdin)
        json.dump(data, sys.stdout, indent=2, ensure_ascii=False)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
