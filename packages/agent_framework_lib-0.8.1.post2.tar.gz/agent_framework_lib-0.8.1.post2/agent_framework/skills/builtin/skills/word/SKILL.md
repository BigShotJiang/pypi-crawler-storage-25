---
name: word
description: "Generate Word (.docx) documents with formatted text, headings, lists, tables, and images."
display_name: "Génération de documents Word"
metadata:
  config:
    emoji: "📝"
    trigger_patterns:
      - word
      - docx
      - document
      - create document
      - text document
      - generate docx
      - word document
      - report document
      - document file
    requires:
      bins:
        - uv
---

## Word Document Generation

Generate professional Word documents (.docx) by running the `create_word.py` script via `shell_exec`.

The script creates documents with formatted text, headings, bullet/numbered lists, tables, and embedded images.

---

## Usage

Pipe a JSON document definition to stdin and specify the target filename:

```bash
echo '{"title": "My Document", "sections": [...]}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill word --filename "document.docx" --output-dir "/path/to/output"
```

---

## Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename, e.g. `"report.docx"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

---

## Stdin (JSON)

Provide a JSON object on stdin with the following structure:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `title` | string | No | Document title (appears as first heading) |
| `author` | string | No | Document author name (metadata) |
| `subject` | string | No | Document subject (metadata) |
| `sections` | array | Yes | Array of content sections (see Section Structure below) |
| `page_size` | string | No | Page size: `"A4"` (default), `"Letter"`, `"Legal"` |
| `orientation` | string | No | Page orientation: `"portrait"` (default), `"landscape"` |
| `margins` | object | No | Page margins in inches: `{"top": 1, "bottom": 1, "left": 1, "right": 1}` (default: 1 inch all sides) |

---

## Section Structure

Each section in the `sections` array is an object with:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | Yes | Section type: `"heading"`, `"paragraph"`, `"list"`, `"table"`, `"image"`, `"page_break"` |
| `level` | integer | No | Heading level (1-9) — for `"heading"` type only |
| `text` | string | No | Text content — for `"heading"` and `"paragraph"` types |
| `style` | object | No | Text style (see Style Object below) |
| `items` | array[string] | No | List items — for `"list"` type |
| `ordered` | boolean | No | If `true`, numbered list; if `false`, bulleted list (default: `false`) |
| `table` | object | No | Table definition — for `"table"` type (see Table Structure below) |
| `image` | string | No | Image path or data URI — for `"image"` type |
| `image_width` | number | No | Image width in inches (default: 6) |
| `caption` | string | No | Image caption |

---

## Section Types

### 1. Heading (`"heading"`)

Creates a heading with specified level (1 = largest, 9 = smallest).

```json
{
  "type": "heading",
  "level": 1,
  "text": "Executive Summary"
}
```

### 2. Paragraph (`"paragraph"`)

Creates a paragraph of text with optional formatting.

```json
{
  "type": "paragraph",
  "text": "This is a paragraph with regular text.",
  "style": {
    "bold": false,
    "italic": false,
    "font_size": 11,
    "align": "left"
  }
}
```

### 3. List (`"list"`)

Creates bulleted or numbered list.

```json
{
  "type": "list",
  "ordered": false,
  "items": [
    "First bullet point",
    "Second bullet point",
    "Third bullet point"
  ]
}
```

For numbered list:
```json
{
  "type": "list",
  "ordered": true,
  "items": [
    "Step 1: Prepare data",
    "Step 2: Analyze results",
    "Step 3: Create report"
  ]
}
```

### 4. Table (`"table"`)

Creates a table with headers and data rows.

```json
{
  "type": "table",
  "table": {
    "headers": ["Name", "Role", "Department"],
    "rows": [
      ["Alice Johnson", "Manager", "Sales"],
      ["Bob Smith", "Developer", "Engineering"],
      ["Carol White", "Analyst", "Finance"]
    ],
    "style": "medium"
  }
}
```

### 5. Image (`"image"`)

Embeds an image in the document.

```json
{
  "type": "image",
  "image": "/path/to/chart.png",
  "image_width": 5,
  "caption": "Figure 1: Sales by region"
}
```

Images can be:
- **File path**: Absolute or relative path
- **Data URI**: `data:image/png;base64,iVBORw0KGgoAAAANS...`

### 6. Page Break (`"page_break"`)

Inserts a page break.

```json
{
  "type": "page_break"
}
```

---

## Style Object

Optional style object for paragraphs and headings:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `bold` | boolean | `false` | Bold text |
| `italic` | boolean | `false` | Italic text |
| `underline` | boolean | `false` | Underlined text |
| `font_size` | integer | 11 | Font size in points |
| `font_name` | string | "Calibri" | Font family name |
| `color` | string | "000000" | Text color (hex format, e.g., `"FF0000"` for red) |
| `align` | string | "left" | Text alignment: `"left"`, `"center"`, `"right"`, `"justify"` |

Example:
```json
{
  "style": {
    "bold": true,
    "font_size": 14,
    "color": "0000FF",
    "align": "center"
  }
}
```

---

## Table Structure

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `headers` | array[string] | Yes | Column headers |
| `rows` | array[array] | Yes | Data rows (each row is an array of cell values) |
| `style` | string | No | Table style: `"light"`, `"medium"` (default), `"dark"` |

Table styles:
- **light**: Light gray header, no borders
- **medium**: Blue header, grid borders (default)
- **dark**: Dark blue header, white text, grid borders

---

## Complete Example

Create a multi-section business report:

```bash
echo '{
  "title": "Q4 2024 Business Report",
  "author": "Jane Smith",
  "subject": "Quarterly Performance Analysis",
  "page_size": "A4",
  "orientation": "portrait",
  "sections": [
    {
      "type": "heading",
      "level": 1,
      "text": "Executive Summary"
    },
    {
      "type": "paragraph",
      "text": "This report presents the key findings from Q4 2024 business operations. Revenue increased significantly while maintaining operational efficiency.",
      "style": {"font_size": 11, "align": "justify"}
    },
    {
      "type": "heading",
      "level": 2,
      "text": "Key Highlights"
    },
    {
      "type": "list",
      "ordered": false,
      "items": [
        "Revenue: $12.5M (+28% YoY)",
        "New customers: 450 (+35%)",
        "Customer satisfaction: 94%",
        "Market share: 18% (+3%)"
      ]
    },
    {
      "type": "page_break"
    },
    {
      "type": "heading",
      "level": 2,
      "text": "Financial Performance"
    },
    {
      "type": "table",
      "table": {
        "headers": ["Metric", "Q3 2024", "Q4 2024", "Change"],
        "rows": [
          ["Revenue", "$9.8M", "$12.5M", "+28%"],
          ["Profit", "$2.1M", "$3.0M", "+43%"],
          ["Expenses", "$7.7M", "$9.5M", "+23%"],
          ["Net Margin", "21%", "24%", "+3pp"]
        ],
        "style": "medium"
      }
    },
    {
      "type": "heading",
      "level": 2,
      "text": "Revenue Trend"
    },
    {
      "type": "image",
      "image": "/path/to/revenue_chart.png",
      "image_width": 6,
      "caption": "Figure 1: Quarterly revenue growth over 12 months"
    },
    {
      "type": "heading",
      "level": 2,
      "text": "Strategic Priorities for 2025"
    },
    {
      "type": "list",
      "ordered": true,
      "items": [
        "Scale operations to support 2x growth target",
        "Expand into European market (Q2 2025)",
        "Build enterprise sales team (15 new hires)",
        "Launch AI-powered features in Q3 2025"
      ]
    },
    {
      "type": "heading",
      "level": 2,
      "text": "Conclusion"
    },
    {
      "type": "paragraph",
      "text": "Q4 2024 demonstrated strong performance across all key metrics. With continued focus on customer success and operational excellence, we are well-positioned for sustained growth in 2025.",
      "style": {"font_size": 11, "align": "justify"}
    }
  ]
}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill word --filename "Q4_2024_Report.docx"
```

---

## Output Format (stdout)

On success, the script prints a JSON object with download information:

```json
{
  "status": "success",
  "file_id": "uuid",
  "download_url": "/files/uuid/download",
  "filename": "Q4_2024_Report.docx",
  "size_bytes": 78456,
  "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "local_cleaned": true,
  "metadata": {
    "section_count": 10,
    "page_count": 3
  }
}
```

Use the `download_url` to provide a download link:
```
[Download document](/files/uuid/download)
```

---

## Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with non-zero code:

```json
{
  "status": "error",
  "message": "Description of the error"
}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | No JSON on stdin | `"No JSON data provided on stdin"` |
| 1 | Invalid JSON | `"Invalid JSON on stdin: ..."` |
| 1 | Missing `sections` field | `"Document must include 'sections' array"` |
| 1 | Invalid section type | `"Invalid section type 'invalid'. Must be one of: heading, paragraph, list, table, image, page_break"` |
| 1 | Missing filename | `"Filename cannot be empty"` |
| 1 | Missing dependency | `"python-docx is not installed. Install with: uv add python-docx"` |

---

## Best Practices

### Document Structure
1. **Start with title**: Use level 1 heading for document title
2. **Use heading hierarchy**: Level 1 for main sections, level 2 for subsections, etc.
3. **Page breaks**: Insert before major new sections
4. **Tables**: Keep tables to 5-7 columns for readability
5. **Images**: Use appropriate width (4-6 inches for most documents)

### Content Guidelines
1. **Paragraphs**: Use justified alignment for formal documents
2. **Lists**: Use bulleted lists for unordered items, numbered for steps/sequences
3. **Headings**: Keep headings concise and descriptive
4. **Tables**: Include headers for all tables
5. **Images**: Always add captions to images and charts

### Formatting
1. **Font size**: 11-12pt for body text, 14-16pt for headings
2. **Font family**: Calibri (default), Arial, or Times New Roman for formal documents
3. **Colors**: Use sparingly; black for text, blue/gray for headings
4. **Alignment**: Left for informal, justified for formal reports
5. **Margins**: 1 inch all sides (default) for standard documents

---

## Common Use Cases

### 1. Business Report
```json
{
  "sections": [
    {"type": "heading", "level": 1, "text": "Report Title"},
    {"type": "paragraph", "text": "Executive summary..."},
    {"type": "heading", "level": 2, "text": "Analysis"},
    {"type": "table", "table": {...}},
    {"type": "image", "image": "chart.png"}
  ]
}
```

### 2. Meeting Minutes
```json
{
  "sections": [
    {"type": "heading", "level": 1, "text": "Meeting Minutes - 2024-12-15"},
    {"type": "heading", "level": 2, "text": "Attendees"},
    {"type": "list", "items": ["John Doe", "Jane Smith", "Bob Johnson"]},
    {"type": "heading", "level": 2, "text": "Action Items"},
    {"type": "list", "ordered": true, "items": ["Task 1", "Task 2", "Task 3"]}
  ]
}
```

### 3. Technical Documentation
```json
{
  "sections": [
    {"type": "heading", "level": 1, "text": "API Documentation"},
    {"type": "heading", "level": 2, "text": "Endpoints"},
    {"type": "paragraph", "text": "This section describes available API endpoints."},
    {"type": "table", "table": {"headers": ["Endpoint", "Method", "Description"], "rows": [...]}}
  ]
}
```

### 4. Invoice
```json
{
  "sections": [
    {"type": "heading", "level": 1, "text": "INVOICE", "style": {"align": "center"}},
    {"type": "paragraph", "text": "Invoice #12345\\nDate: 2024-12-15", "style": {"align": "right"}},
    {"type": "heading", "level": 2, "text": "Items"},
    {"type": "table", "table": {"headers": ["Item", "Quantity", "Unit Price", "Total"], "rows": [...]}}
  ]
}
```

---

## Tips for Agents

When helping users create Word documents:

1. **Ask about structure**: Main sections, subsections, content types
2. **Suggest formatting**: Appropriate heading levels, text alignment, styles
3. **Organize content**: Logical flow with clear section breaks
4. **Use page breaks**: For major sections in longer documents
5. **Add visuals**: Tables for data, images for charts/diagrams
6. **Include metadata**: Set title, author, subject for professional documents
7. **Validate content**: Ensure headings are hierarchical, tables are properly formatted

Remember: Well-structured documents with clear headings and consistent formatting are easier to read and more professional!
