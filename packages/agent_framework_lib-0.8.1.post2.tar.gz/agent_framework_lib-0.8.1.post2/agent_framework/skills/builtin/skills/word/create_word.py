#!/usr/bin/env python3
"""
Word document generation script for the word skill.

Reads JSON document definition from stdin and creates a .docx file.
"""
import base64
import json
import sys
from io import BytesIO
from pathlib import Path
from typing import Any

try:
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
except ImportError:
    print(
        json.dumps({
            "status": "error",
            "message": "python-docx is not installed. Install with: uv add python-docx"
        }),
        file=sys.stderr
    )
    sys.exit(1)


# Alignment mapping
ALIGN_MAP = {
    "left": WD_ALIGN_PARAGRAPH.LEFT,
    "center": WD_ALIGN_PARAGRAPH.CENTER,
    "right": WD_ALIGN_PARAGRAPH.RIGHT,
    "justify": WD_ALIGN_PARAGRAPH.JUSTIFY
}


def hex_to_rgb(hex_color: str) -> RGBColor:
    """Convert hex color string to RGBColor."""
    hex_color = hex_color.lstrip('#')
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    return RGBColor(r, g, b)


def load_image(image_source: str) -> BytesIO:
    """Load image from file path or data URI."""
    if image_source.startswith("data:image"):
        # Data URI format
        try:
            header, encoded = image_source.split(",", 1)
            image_data = base64.b64decode(encoded)
            return BytesIO(image_data)
        except Exception as e:
            raise ValueError(f"Invalid data URI: {e}")
    else:
        # File path
        image_path = Path(image_source)
        if not image_path.exists():
            raise FileNotFoundError(f"Image file not found: {image_source}")
        return BytesIO(image_path.read_bytes())


def apply_style(run: Any, style: dict[str, Any]) -> None:
    """Apply text style to a run."""
    if style.get("bold"):
        run.bold = True
    if style.get("italic"):
        run.italic = True
    if style.get("underline"):
        run.underline = True
    if "font_size" in style:
        run.font.size = Pt(style["font_size"])
    if "font_name" in style:
        run.font.name = style["font_name"]
    if "color" in style:
        run.font.color.rgb = hex_to_rgb(style["color"])


def add_heading_section(doc: Document, section: dict[str, Any]) -> None:
    """Add heading section to document."""
    level = section.get("level", 1)
    text = section.get("text", "")

    heading = doc.add_heading(text, level=level)

    # Apply custom style if provided
    if "style" in section:
        style = section["style"]
        para = heading
        if "align" in style:
            para.alignment = ALIGN_MAP.get(style["align"], WD_ALIGN_PARAGRAPH.LEFT)

        # Apply style to runs
        for run in para.runs:
            apply_style(run, style)


def add_paragraph_section(doc: Document, section: dict[str, Any]) -> None:
    """Add paragraph section to document."""
    text = section.get("text", "")
    paragraph = doc.add_paragraph(text)

    # Apply style
    if "style" in section:
        style = section["style"]
        if "align" in style:
            paragraph.alignment = ALIGN_MAP.get(style["align"], WD_ALIGN_PARAGRAPH.LEFT)

        # Apply style to runs
        for run in paragraph.runs:
            apply_style(run, style)


def add_list_section(doc: Document, section: dict[str, Any]) -> None:
    """Add list section (bulleted or numbered) to document."""
    items = section.get("items", [])
    ordered = section.get("ordered", False)

    # Note: python-docx doesn't have built-in numbered list support
    # We'll use bullet points and prefix with numbers if ordered
    for i, item in enumerate(items):
        if ordered:
            text = f"{i + 1}. {item}"
        else:
            text = item

        para = doc.add_paragraph(text, style='List Bullet' if not ordered else 'List Number')


def add_table_section(doc: Document, section: dict[str, Any]) -> None:
    """Add table section to document."""
    table_data = section.get("table", {})
    headers = table_data.get("headers", [])
    rows = table_data.get("rows", [])
    style_name = table_data.get("style", "medium")

    if not headers or not rows:
        return

    # Create table
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Apply table style
    if style_name == "light":
        table.style = 'Light Grid'
    elif style_name == "dark":
        table.style = 'Dark List'
    else:  # medium
        table.style = 'Medium Grid 1'

    # Fill header row
    header_cells = table.rows[0].cells
    for i, header in enumerate(headers):
        header_cells[i].text = str(header)
        # Bold header text
        for paragraph in header_cells[i].paragraphs:
            for run in paragraph.runs:
                run.font.bold = True

    # Fill data rows
    for row_idx, row_data in enumerate(rows):
        row_cells = table.rows[row_idx + 1].cells
        for col_idx, value in enumerate(row_data):
            row_cells[col_idx].text = str(value)


def add_image_section(doc: Document, section: dict[str, Any]) -> None:
    """Add image section to document."""
    image_source = section.get("image")
    if not image_source:
        return

    try:
        image_stream = load_image(image_source)
        width = section.get("image_width", 6)  # Default 6 inches
        doc.add_picture(image_stream, width=Inches(width))

        # Add caption if provided
        if "caption" in section:
            caption_para = doc.add_paragraph(section["caption"])
            caption_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in caption_para.runs:
                run.italic = True
                run.font.size = Pt(10)

    except Exception as e:
        # Add error text if image fails to load
        error_para = doc.add_paragraph(f"[Image failed to load: {str(e)}]")
        for run in error_para.runs:
            run.font.color.rgb = RGBColor(255, 0, 0)


def add_page_break(doc: Document) -> None:
    """Add page break to document."""
    doc.add_page_break()


def set_page_layout(doc: Document, data: dict[str, Any]) -> None:
    """Set page layout properties (size, orientation, margins)."""
    section = doc.sections[0]

    # Set page size
    page_size = data.get("page_size", "A4")
    if page_size == "Letter":
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
    elif page_size == "Legal":
        section.page_width = Inches(8.5)
        section.page_height = Inches(14)
    else:  # A4 (default)
        section.page_width = Inches(8.27)
        section.page_height = Inches(11.69)

    # Set orientation
    orientation = data.get("orientation", "portrait")
    if orientation == "landscape":
        # Swap width and height
        section.page_width, section.page_height = section.page_height, section.page_width

    # Set margins
    margins = data.get("margins", {})
    section.top_margin = Inches(margins.get("top", 1))
    section.bottom_margin = Inches(margins.get("bottom", 1))
    section.left_margin = Inches(margins.get("left", 1))
    section.right_margin = Inches(margins.get("right", 1))


def create_document(data: dict[str, Any], output_path: Path) -> dict[str, Any]:
    """Create Word document from JSON data."""
    doc = Document()

    # Set page layout
    set_page_layout(doc, data)

    # Set document properties
    core_props = doc.core_properties
    if "title" in data:
        core_props.title = data["title"]
    if "author" in data:
        core_props.author = data["author"]
    if "subject" in data:
        core_props.subject = data["subject"]

    # Add title if provided
    if "title" in data:
        title = doc.add_heading(data["title"], level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Process sections
    sections = data.get("sections", [])
    if not sections:
        raise ValueError("Document must include 'sections' array")

    section_handlers = {
        "heading": add_heading_section,
        "paragraph": add_paragraph_section,
        "list": add_list_section,
        "table": add_table_section,
        "image": add_image_section,
        "page_break": lambda d, s: add_page_break(d)
    }

    for section in sections:
        section_type = section.get("type")
        if section_type not in section_handlers:
            raise ValueError(
                f"Invalid section type '{section_type}'. "
                f"Must be one of: {', '.join(section_handlers.keys())}"
            )

        handler = section_handlers[section_type]
        handler(doc, section)

    # Save document
    doc.save(str(output_path))

    # Estimate page count (rough approximation)
    # Each section contributes ~0.1 pages on average
    page_count = max(1, len(sections) // 10)

    return {
        "section_count": len(sections),
        "page_count": page_count
    }


def main() -> None:
    """Main entry point."""
    # This script is called via create_and_register.py
    # The actual implementation will be handled by that wrapper
    pass


if __name__ == "__main__":
    main()
