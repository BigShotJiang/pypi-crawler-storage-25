---
name: image_gen
description: "Generate images using AI image generation APIs (DALL-E 3, DALL-E 2). Create custom illustrations, diagrams, and visual content from text descriptions."
display_name: "Génération d'images par IA"
metadata:
  config:
    emoji: "🎨"
    trigger_patterns:
      - generate image
      - create image
      - draw
      - illustration
      - ai image
      - dall-e
      - dalle
      - image generation
      - create picture
      - generate illustration
      - ai art
      - picture generation
    requires:
      bins:
        - uv
      env:
        - OPENAI_API_KEY
---

## AI Image Generation

Generate images using OpenAI's DALL-E models by running the `generate_image.py` script via `shell_exec`.

The script supports DALL-E 3 (latest, highest quality) and DALL-E 2 (faster, more affordable) with customizable parameters for size, quality, and style.

---

## Usage

Pipe a JSON generation request to stdin and specify the target filename:

```bash
echo '{"prompt": "A futuristic cityscape at sunset", "model": "dall-e-3", "size": "1024x1024"}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill image_gen --filename "cityscape.png" --output-dir "/path/to/output"
```

---

## Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename for the generated image, e.g. `"illustration.png"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

---

## Stdin (JSON)

Provide a JSON object on stdin with the following structure:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `prompt` | string | Yes | Text description of the image to generate (max 4000 characters for DALL-E 3, 1000 for DALL-E 2) |
| `model` | string | No | AI model: `"dall-e-3"` (default), `"dall-e-2"` |
| `size` | string | No | Image size (see Size Options below) |
| `quality` | string | No | Image quality: `"standard"` (default), `"hd"` (DALL-E 3 only) |
| `style` | string | No | Image style: `"vivid"` (default), `"natural"` (DALL-E 3 only) |
| `n` | integer | No | Number of images to generate (1-10 for DALL-E 2, always 1 for DALL-E 3) |

---

## Model Comparison

### DALL-E 3 (Recommended)

**Best for**: High-quality, detailed images with better prompt following

| Feature | Value |
|---------|-------|
| Quality | Highest (especially with `"hd"` quality) |
| Prompt adherence | Excellent — understands complex descriptions |
| Available sizes | `1024x1024`, `1024x1792` (portrait), `1792x1024` (landscape) |
| Style options | `vivid` (vibrant, hyper-real), `natural` (more subdued, natural) |
| Cost | Higher |
| Speed | Slower (~10-30 seconds) |

**Use DALL-E 3 when**:
- You need high-quality, detailed images
- Prompt contains complex or specific requirements
- Image will be used professionally (presentations, marketing)
- You want HDproperty quality output

### DALL-E 2

**Best for**: Faster generation, multiple variations, lower cost

| Feature | Value |
|---------|-------|
| Quality | Good |
| Prompt adherence | Good — simpler prompts work best |
| Available sizes | `256x256`, `512x512`, `1024x1024` |
| Multiple images | Yes (1-10 images per request via `n` parameter) |
| Cost | Lower |
| Speed | Faster (~5-15 seconds) |

**Use DALL-E 2 when**:
- You need quick iterations or multiple variations
- Budget is a concern
- Prompt is simple and straightforward
- Lower resolution is acceptable

---

## Size Options

### DALL-E 3 Sizes
- `1024x1024` — Square (default) — General purpose
- `1024x1792` — Portrait (9:16 aspect ratio) — Mobile screens, posters
- `1792x1024` — Landscape (16:9 aspect ratio) — Presentations, web banners

### DALL-E 2 Sizes
- `256x256` — Small square — Quick tests, thumbnails
- `512x512` — Medium square — Web graphics, icons
- `1024x1024` — Large square — High-res graphics, prints

---

## Quality & Style (DALL-E 3 Only)

### Quality

- `"standard"` (default) — Good quality, faster, lower cost
- `"hd"` — Highest quality, more detail, slower, higher cost

**Use HD quality for**:
- Professional presentations and marketing materials
- Large format prints or displays
- Images requiring fine details (textures, faces, text)

### Style

- `"vivid"` (default) — Vibrant, hyper-real, dramatic — Good for eye-catching visuals
- `"natural"` — More subdued, realistic, natural tones — Good for professional/corporate content

---

## Complete Example

Generate a high-quality landscape illustration for a presentation:

```bash
echo '{
  "prompt": "A serene mountain landscape with a crystal-clear lake reflecting snow-capped peaks, surrounded by pine forests, during golden hour. Photorealistic style with soft lighting and vibrant colors.",
  "model": "dall-e-3",
  "size": "1792x1024",
  "quality": "hd",
  "style": "natural"
}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill image_gen --filename "mountain_landscape.png"
```

---

## Output Format (stdout)

On success, the script prints a JSON object with download information:

```json
{
  "status": "success",
  "file_id": "uuid",
  "download_url": "/files/uuid/download",
  "filename": "mountain_landscape.png",
  "size_bytes": 234567,
  "mime_type": "image/png",
  "local_cleaned": true,
  "metadata": {
    "model": "dall-e-3",
    "size": "1792x1024",
    "quality": "hd",
    "revised_prompt": "A tranquil mountain vista featuring..."
  }
}
```

**Note**: The `revised_prompt` field (DALL-E 3 only) shows how OpenAI interpreted and enhanced your original prompt.

Use the `download_url` to provide a download link:
```
[Download image](/files/uuid/download)
```

---

## Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with non-zero code:

```json
{
  "status": "error",
  "message": "Description of the error"
}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | No JSON on stdin | `"No JSON data provided on stdin"` |
| 1 | Invalid JSON | `"Invalid JSON on stdin: ..."` |
| 1 | Missing prompt | `"prompt field is required"` |
| 1 | Prompt too long | `"Prompt exceeds maximum length (4000 characters for DALL-E 3)"` |
| 1 | Invalid size | `"Invalid size '2048x2048' for dall-e-3. Must be one of: 1024x1024, 1024x1792, 1792x1024"` |
| 1 | Missing API key | `"OPENAI_API_KEY environment variable is not set"` |
| 1 | API error | `"OpenAI API error: Rate limit exceeded"` |
| 1 | Content policy violation | `"Image generation failed: Content policy violation"` |

---

## Prompt Engineering Best Practices

### 1. Be Specific and Descriptive

**❌ Poor**:
```
"A cat"
```

**✅ Good**:
```
"A fluffy orange tabby cat sitting on a windowsill, looking outside at a rainy day. Soft natural lighting, cozy atmosphere, photorealistic style."
```

### 2. Include Style, Mood, and Lighting

- **Style**: photorealistic, oil painting, watercolor, digital art, minimalist, cartoon, etc.
- **Mood**: serene, energetic, mysterious, cheerful, dramatic, etc.
- **Lighting**: golden hour, soft natural light, dramatic shadows, backlit, studio lighting, etc.

**Example**:
```
"A modern office interior with large windows, minimalist furniture, and green plants. Bright natural lighting, clean professional aesthetic, architectural photography style."
```

### 3. Specify Composition and Perspective

- **Perspective**: aerial view, close-up, wide shot, eye-level, bird's eye, etc.
- **Composition**: centered, rule of thirds, symmetrical, etc.

**Example**:
```
"Aerial view of a winding river through a dense forest, shot from above. Symmetrical composition, vibrant greens, late afternoon lighting."
```

### 4. Use Artistic References (When Appropriate)

Reference well-known art styles or artists for specific aesthetics:
```
"A cyberpunk street scene in the style of Blade Runner, with neon signs, rain-slicked streets, and towering buildings. Cinematic, moody, blue and pink color palette."
```

### 5. Avoid Ambiguity

Be precise about what you want:

**❌ Ambiguous**:
```
"A nice logo"
```

**✅ Clear**:
```
"A minimalist logo featuring a stylized mountain peak inside a circular frame. Navy blue and white color scheme, clean lines, modern professional design."
```

---

## Common Use Cases

### 1. Presentation Illustrations

```json
{
  "prompt": "A professional illustration showing a team collaborating around a digital interface displaying data charts and graphs. Modern office setting, diverse team members, clean vector art style with blue and green color scheme.",
  "model": "dall-e-3",
  "size": "1792x1024",
  "quality": "hd",
  "style": "natural"
}
```

### 2. Product Mockups

```json
{
  "prompt": "A sleek smartphone on a wooden desk with a cup of coffee and a notebook. Minimalist workspace, soft natural lighting from a window, product photography style, shallow depth of field.",
  "model": "dall-e-3",
  "size": "1024x1024",
  "quality": "hd",
  "style": "natural"
}
```

### 3. Concept Art

```json
{
  "prompt": "A futuristic city with flying vehicles, towering glass skyscrapers, and green vertical gardens. Sunset lighting with warm orange and pink tones, digital art style, detailed and atmospheric.",
  "model": "dall-e-3",
  "size": "1792x1024",
  "quality": "hd",
  "style": "vivid"
}
```

### 4. Diagrams and Infographics

```json
{
  "prompt": "A simple flowchart diagram showing a user onboarding process with 5 steps, using icons and arrows. Clean, professional infographic style with blue and gray colors, minimalist design.",
  "model": "dall-e-3",
  "size": "1024x1792",
  "quality": "standard",
  "style": "natural"
}
```

### 5. Social Media Graphics

```json
{
  "prompt": "An inspiring quote card with the text 'Believe in yourself' on a gradient background of purple and pink. Modern typography, motivational poster style, clean and eye-catching.",
  "model": "dall-e-2",
  "size": "1024x1024"
}
```

---

## Limitations and Content Policy

### Content Policy

OpenAI's content policy prohibits:
- Hateful, harassing, or violent content
- Adult or sexual content
- Political or religious content that could be harmful
- Illegal activities
- Personal information or impersonation
- Copyrighted characters or logos

If your prompt violates the content policy, the API will return an error.

### Technical Limitations

- **Text in images**: DALL-E can struggle with generating readable text. For images with specific text, consider using image editing tools after generation.
- **Specific people**: Cannot generate images of real, identifiable people
- **Brands and logos**: Cannot generate copyrighted brand logos or trademarked content
- **Anatomical accuracy**: May struggle with complex poses or specific anatomical details

---

## Cost Optimization Tips

1. **Use DALL-E 2 for iterations**: Start with DALL-E 2 to test prompts, then use DALL-E 3 for final version
2. **Standard quality first**: Try standard quality before using HD
3. **Smaller sizes for testing**: Use smaller sizes (1024x1024) for initial tests
4. **Refine prompts**: Spend time crafting good prompts to avoid multiple generations
5. **Batch requests**: If generating multiple variations, use DALL-E 2's `n` parameter

---

## Tips for Agents

When helping users generate images:

1. **Clarify requirements**: Ask about purpose, style, dimensions, quality needs
2. **Suggest model**: DALL-E 3 for quality, DALL-E 2 for speed/cost
3. **Recommend size**: Based on use case (presentation → landscape, social media → square, poster → portrait)
4. **Craft detailed prompts**: Include style, mood, lighting, composition
5. **Set expectations**: Mention generation time (~10-30s for DALL-E 3)
6. **Offer refinement**: If result isn't perfect, suggest prompt improvements
7. **Explain revised prompt**: For DALL-E 3, share how OpenAI interpreted the prompt

Remember: Great images come from great prompts — spend time crafting detailed, specific descriptions!
