#!/usr/bin/env python3
"""
AI image generation script for the image_gen skill.

Reads JSON generation request from stdin and creates an image using OpenAI's DALL-E API.
"""
import json
import os
import sys
from pathlib import Path
from typing import Any

try:
    from openai import OpenAI
except ImportError:
    print(
        json.dumps({
            "status": "error",
            "message": "openai is not installed. Install with: uv add openai"
        }),
        file=sys.stderr
    )
    sys.exit(1)


# Model configurations
MODEL_CONFIGS = {
    "dall-e-3": {
        "sizes": ["1024x1024", "1024x1792", "1792x1024"],
        "qualities": ["standard", "hd"],
        "styles": ["vivid", "natural"],
        "max_prompt_length": 4000,
        "n_images": 1  # DALL-E 3 always generates 1 image
    },
    "dall-e-2": {
        "sizes": ["256x256", "512x512", "1024x1024"],
        "max_prompt_length": 1000,
        "n_images_max": 10
    }
}


def validate_request(data: dict[str, Any]) -> tuple[bool, str]:
    """Validate the generation request."""
    # Check required fields
    if "prompt" not in data:
        return False, "prompt field is required"

    prompt = data["prompt"]
    model = data.get("model", "dall-e-3")

    # Validate model
    if model not in MODEL_CONFIGS:
        return False, f"Invalid model '{model}'. Must be one of: {', '.join(MODEL_CONFIGS.keys())}"

    config = MODEL_CONFIGS[model]

    # Validate prompt length
    if len(prompt) > config["max_prompt_length"]:
        return False, f"Prompt exceeds maximum length ({config['max_prompt_length']} characters for {model})"

    # Validate size
    if "size" in data:
        size = data["size"]
        if size not in config["sizes"]:
            return False, f"Invalid size '{size}' for {model}. Must be one of: {', '.join(config['sizes'])}"

    # Validate quality (DALL-E 3 only)
    if model == "dall-e-3" and "quality" in data:
        quality = data["quality"]
        if quality not in config["qualities"]:
            return False, f"Invalid quality '{quality}'. Must be one of: {', '.join(config['qualities'])}"

    # Validate style (DALL-E 3 only)
    if model == "dall-e-3" and "style" in data:
        style = data["style"]
        if style not in config["styles"]:
            return False, f"Invalid style '{style}'. Must be one of: {', '.join(config['styles'])}"

    # Validate n (DALL-E 2 only)
    if "n" in data:
        n = data["n"]
        if model == "dall-e-3" and n != 1:
            return False, "DALL-E 3 can only generate 1 image at a time (n=1)"
        if model == "dall-e-2":
            if not isinstance(n, int) or n < 1 or n > config["n_images_max"]:
                return False, f"n must be between 1 and {config['n_images_max']} for DALL-E 2"

    return True, ""


def generate_image(data: dict[str, Any]) -> dict[str, Any]:
    """Generate image using OpenAI API."""
    # Check for API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY environment variable is not set")

    # Create client
    client = OpenAI(api_key=api_key)

    # Extract parameters
    prompt = data["prompt"]
    model = data.get("model", "dall-e-3")
    size = data.get("size")
    quality = data.get("quality")
    style = data.get("style")
    n = data.get("n", 1)

    # Set defaults based on model
    if model == "dall-e-3":
        if not size:
            size = "1024x1024"
        if not quality:
            quality = "standard"
        if not style:
            style = "vivid"
        n = 1  # Always 1 for DALL-E 3
    else:  # dall-e-2
        if not size:
            size = "1024x1024"

    # Build API request parameters
    api_params = {
        "model": model,
        "prompt": prompt,
        "n": n,
        "size": size,
        "response_format": "url"  # Get URL instead of base64
    }

    # Add DALL-E 3 specific parameters
    if model == "dall-e-3":
        api_params["quality"] = quality
        api_params["style"] = style

    # Make API call
    try:
        response = client.images.generate(**api_params)
    except Exception as e:
        error_message = str(e)
        # Provide more specific error messages
        if "content_policy_violation" in error_message.lower():
            raise ValueError("Image generation failed: Content policy violation. Please modify your prompt.")
        elif "rate_limit" in error_message.lower():
            raise ValueError("OpenAI API error: Rate limit exceeded. Please try again later.")
        elif "insufficient_quota" in error_message.lower():
            raise ValueError("OpenAI API error: Insufficient quota. Please check your API credits.")
        else:
            raise ValueError(f"OpenAI API error: {error_message}")

    # Extract response data
    image_data = response.data[0]
    image_url = image_data.url
    revised_prompt = getattr(image_data, 'revised_prompt', None)

    return {
        "url": image_url,
        "revised_prompt": revised_prompt,
        "model": model,
        "size": size,
        "quality": quality if model == "dall-e-3" else None,
        "style": style if model == "dall-e-3" else None
    }


def download_image(url: str, output_path: Path) -> int:
    """Download image from URL to file."""
    import urllib.request

    try:
        with urllib.request.urlopen(url) as response:
            image_data = response.read()
            output_path.write_bytes(image_data)
            return len(image_data)
    except Exception as e:
        raise ValueError(f"Failed to download image: {e}")


def main() -> None:
    """Main entry point."""
    # This script is called via create_and_register.py
    # The actual implementation will be handled by that wrapper
    pass


if __name__ == "__main__":
    main()
