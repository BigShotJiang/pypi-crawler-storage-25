---
name: powerpoint
description: "Generate PowerPoint (.pptx) presentations with slides, text, images, tables, and custom layouts."
display_name: "Génération de présentations PowerPoint"
metadata:
  config:
    emoji: "📊"
    trigger_patterns:
      - powerpoint
      - pptx
      - presentation
      - slides
      - slideshow
      - create presentation
      - generate slides
      - deck
      - slide deck
    requires:
      bins:
        - uv
---

## PowerPoint Presentation Generation

Generate professional PowerPoint presentations (.pptx) by running the `create_powerpoint.py` script via `shell_exec`.

The script creates presentations with multiple slides, supports various layouts (title, content, two-column, picture), and handles text, images, tables, and lists.

---

## Usage

Pipe a JSON presentation definition to stdin and specify the target filename:

```bash
echo '{"title": "My Presentation", "slides": [...]}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill powerpoint --filename "presentation.pptx" --output-dir "/path/to/output"
```

---

## Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename, e.g. `"quarterly_report.pptx"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

---

## Stdin (JSON)

Provide a JSON object on stdin with the following structure:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `title` | string | No | Presentation title (used in metadata and optional title slide) |
| `subtitle` | string | No | Presentation subtitle (for title slide) |
| `author` | string | No | Presentation author name |
| `slides` | array | Yes | Array of slide definitions (see Slide Structure below) |
| `theme` | string | No | Color theme: `"default"`, `"blue"`, `"green"`, `"red"`, `"corporate"` (default: `"default"`) |

---

## Slide Structure

Each slide in the `slides` array is an object with:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `layout` | string | Yes | Slide layout: `"title"`, `"content"`, `"two_column"`, `"picture"`, `"blank"` |
| `title` | string | No | Slide title (appears at top of slide) |
| `content` | string or array | No | Slide content (text, list items, or paragraphs) |
| `image` | string | No | Image path (file path or data URI) — for `"picture"` layout |
| `image_caption` | string | No | Caption for the image |
| `table` | object | No | Table definition (see Table Structure below) |
| `notes` | string | No | Speaker notes for the slide |
| `left_content` | string or array | No | Left column content (for `"two_column"` layout) |
| `right_content` | string or array | No | Right column content (for `"two_column"` layout) |

---

## Layouts

### 1. Title Slide (`"title"`)

Used for cover slides with a main title and subtitle.

```json
{
  "layout": "title",
  "title": "Quarterly Business Review",
  "content": "Q4 2024 Results"
}
```

### 2. Content Slide (`"content"`)

Standard slide with title and bulleted content.

```json
{
  "layout": "content",
  "title": "Key Highlights",
  "content": [
    "Revenue increased 25% YoY",
    "Expanded to 3 new markets",
    "Customer satisfaction: 94%"
  ]
}
```

Content can be:
- **String**: Single paragraph
- **Array of strings**: Bulleted list

### 3. Two-Column Slide (`"two_column"`)

Side-by-side content layout.

```json
{
  "layout": "two_column",
  "title": "Comparison",
  "left_content": [
    "Advantages:",
    "• Fast deployment",
    "• Cost effective"
  ],
  "right_content": [
    "Challenges:",
    "• Training required",
    "• Integration complexity"
  ]
}
```

### 4. Picture Slide (`"picture"`)

Full-size image with optional caption.

```json
{
  "layout": "picture",
  "title": "Market Analysis",
  "image": "/path/to/chart.png",
  "image_caption": "Figure 1: Revenue Growth by Region"
}
```

Images can be:
- **File path**: Absolute or relative path to an image file
- **Data URI**: `data:image/png;base64,iVBORw0KGgoAAAANS...`

### 5. Blank Slide (`"blank"`)

Empty slide for custom content.

```json
{
  "layout": "blank",
  "title": "Custom Slide"
}
```

---

## Table Structure

To include a table on any slide, add a `table` field:

```json
{
  "layout": "content",
  "title": "Sales by Region",
  "table": {
    "headers": ["Region", "Q3", "Q4", "Growth"],
    "rows": [
      ["North America", "$2.5M", "$3.1M", "+24%"],
      ["Europe", "$1.8M", "$2.2M", "+22%"],
      ["Asia", "$1.2M", "$1.6M", "+33%"]
    ],
    "style": "medium"
  }
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `headers` | array[string] | Yes | Column headers |
| `rows` | array[array] | Yes | Data rows (each row is an array of cell values) |
| `style` | string | No | Table style: `"light"`, `"medium"`, `"dark"` (default: `"medium"`) |

---

## Complete Example

Create a multi-slide presentation with various layouts:

```bash
echo '{
  "title": "Q4 2024 Business Review",
  "subtitle": "Results and Strategy",
  "author": "Jane Smith",
  "theme": "corporate",
  "slides": [
    {
      "layout": "title",
      "title": "Q4 2024 Business Review",
      "content": "Results and Strategy for 2025"
    },
    {
      "layout": "content",
      "title": "Executive Summary",
      "content": [
        "Revenue: $12.5M (+28% YoY)",
        "New customers: 450 (+35%)",
        "Market share: 18% (+3%)",
        "Team growth: 85 employees"
      ],
      "notes": "Emphasize the strong growth across all metrics"
    },
    {
      "layout": "content",
      "title": "Financial Performance",
      "table": {
        "headers": ["Metric", "Q3", "Q4", "Change"],
        "rows": [
          ["Revenue", "$9.8M", "$12.5M", "+28%"],
          ["Profit", "$2.1M", "$3.0M", "+43%"],
          ["Expenses", "$7.7M", "$9.5M", "+23%"]
        ],
        "style": "medium"
      }
    },
    {
      "layout": "two_column",
      "title": "Strengths & Opportunities",
      "left_content": [
        "Strengths:",
        "• Strong product-market fit",
        "• Experienced leadership team",
        "• Robust technology platform"
      ],
      "right_content": [
        "Opportunities:",
        "• International expansion",
        "• Enterprise market entry",
        "• Strategic partnerships"
      ]
    },
    {
      "layout": "picture",
      "title": "Revenue Growth Trend",
      "image": "/path/to/revenue_chart.png",
      "image_caption": "Figure 1: Quarterly revenue growth over 12 months"
    },
    {
      "layout": "content",
      "title": "2025 Priorities",
      "content": [
        "1. Scale operations to support 2x growth",
        "2. Launch in European market",
        "3. Build enterprise sales team",
        "4. Enhance product features based on feedback"
      ]
    }
  ]
}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill powerpoint --filename "Q4_review.pptx"
```

---

## Output Format (stdout)

On success, the script prints a JSON object with download information:

```json
{
  "status": "success",
  "file_id": "uuid",
  "download_url": "/files/uuid/download",
  "filename": "Q4_review.pptx",
  "size_bytes": 45678,
  "mime_type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "local_cleaned": true,
  "metadata": {
    "slide_count": 6,
    "theme": "corporate"
  }
}
```

Use the `download_url` to provide a download link:
```
[Download presentation](/files/uuid/download)
```

---

## Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with non-zero code:

```json
{
  "status": "error",
  "message": "Description of the error"
}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | No JSON on stdin | `"No JSON data provided on stdin"` |
| 1 | Invalid JSON | `"Invalid JSON on stdin: Expecting value: line 1 column 1 (char 0)"` |
| 1 | Missing `slides` field | `"Presentation must include 'slides' array"` |
| 1 | Invalid layout | `"Invalid layout 'invalid'. Must be one of: title, content, two_column, picture, blank"` |
| 1 | Missing filename | `"Filename cannot be empty"` |
| 1 | Missing dependency | `"python-pptx is not installed. Install with: uv add python-pptx"` |

---

## Themes

Built-in color themes for professional presentations:

| Theme | Primary Color | Use Case |
|-------|---------------|----------|
| `default` | Blue (#4472C4) | General purpose |
| `blue` | Navy (#003366) | Corporate, finance |
| `green` | Forest Green (#2E8B57) | Environment, health |
| `red` | Crimson (#DC143C) | Energy, urgency |
| `corporate` | Charcoal (#36454F) | Business, consulting |

Themes affect:
- Title slide background
- Heading colors
- Table header colors
- Accent elements

---

## Best Practices

### Content Guidelines
1. **Slide count**: Aim for 8-15 slides for most presentations
2. **Text per slide**: Keep to 3-5 bullet points maximum
3. **Titles**: Make slide titles descriptive and action-oriented
4. **Images**: Use high-resolution images (PNG or JPEG)
5. **Tables**: Keep tables to 5-7 rows for readability

### Layout Selection
- **Title**: First slide only
- **Content**: Main content slides (most common)
- **Two-column**: Comparisons, pros/cons, before/after
- **Picture**: Charts, diagrams, photos that need emphasis
- **Blank**: Custom content or section dividers

### Image Best Practices
- For data URIs: Images are embedded directly in the .pptx
- For file paths: Images must be accessible at the specified path
- Supported formats: PNG, JPEG, GIF
- Recommended size: 1920x1080 (16:9 aspect ratio)

### Speaker Notes
- Add `notes` field to slides for presenter guidance
- Include key talking points and statistics
- Not visible to audience, only to presenter

---

## Common Use Cases

### 1. Business Report
```json
{
  "theme": "corporate",
  "slides": [
    {"layout": "title", "title": "Quarterly Report"},
    {"layout": "content", "title": "Summary", "content": ["..."]},
    {"layout": "content", "title": "Metrics", "table": {...}},
    {"layout": "picture", "title": "Trends", "image": "chart.png"}
  ]
}
```

### 2. Product Pitch
```json
{
  "theme": "blue",
  "slides": [
    {"layout": "title", "title": "Product Name", "content": "Tagline"},
    {"layout": "content", "title": "Problem", "content": ["..."]},
    {"layout": "content", "title": "Solution", "content": ["..."]},
    {"layout": "two_column", "title": "Benefits", "left_content": [...], "right_content": [...]}
  ]
}
```

### 3. Training Deck
```json
{
  "theme": "green",
  "slides": [
    {"layout": "title", "title": "Training Session"},
    {"layout": "content", "title": "Objectives", "content": ["..."]},
    {"layout": "picture", "title": "Process Flow", "image": "diagram.png"},
    {"layout": "content", "title": "Key Takeaways", "content": ["..."]}
  ]
}
```

---

## Tips for Agents

When helping users create PowerPoint presentations:

1. **Ask about structure**: Number of slides, key sections, flow
2. **Suggest layouts**: Match content type to appropriate layout
3. **Offer themes**: Recommend theme based on presentation purpose
4. **Include images**: If data is visualized, generate charts first, then embed
5. **Add speaker notes**: Include notes for important slides
6. **Validate content**: Ensure slides aren't text-heavy
7. **Provide preview**: Describe what each slide will look like

Remember: Good presentations tell a story — ensure logical flow and clear messaging!
