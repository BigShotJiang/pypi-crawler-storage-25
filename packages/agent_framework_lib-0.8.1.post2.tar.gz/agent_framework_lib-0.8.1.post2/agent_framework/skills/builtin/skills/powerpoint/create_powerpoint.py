#!/usr/bin/env python3
"""
PowerPoint generation script for the powerpoint skill.

Reads JSON presentation definition from stdin and creates a .pptx file.
"""
import base64
import json
import sys
from io import BytesIO
from pathlib import Path
from typing import Any

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor
except ImportError:
    print(
        json.dumps({
            "status": "error",
            "message": "python-pptx is not installed. Install with: uv add python-pptx"
        }),
        file=sys.stderr
    )
    sys.exit(1)


# Theme color definitions
THEMES = {
    "default": {
        "primary": RGBColor(68, 114, 196),  # Blue
        "secondary": RGBColor(112, 173, 71),  # Green
        "text": RGBColor(0, 0, 0)  # Black
    },
    "blue": {
        "primary": RGBColor(0, 51, 102),  # Navy
        "secondary": RGBColor(0, 102, 204),  # Light Blue
        "text": RGBColor(0, 0, 0)
    },
    "green": {
        "primary": RGBColor(46, 139, 87),  # Forest Green
        "secondary": RGBColor(60, 179, 113),  # Medium Green
        "text": RGBColor(0, 0, 0)
    },
    "red": {
        "primary": RGBColor(220, 20, 60),  # Crimson
        "secondary": RGBColor(178, 34, 34),  # Fire Brick
        "text": RGBColor(0, 0, 0)
    },
    "corporate": {
        "primary": RGBColor(54, 69, 79),  # Charcoal
        "secondary": RGBColor(100, 116, 126),  # Gray
        "text": RGBColor(0, 0, 0)
    }
}


def load_image(image_source: str) -> BytesIO:
    """Load image from file path or data URI."""
    if image_source.startswith("data:image"):
        # Data URI format: data:image/png;base64,iVBORw0KG...
        try:
            header, encoded = image_source.split(",", 1)
            image_data = base64.b64decode(encoded)
            return BytesIO(image_data)
        except Exception as e:
            raise ValueError(f"Invalid data URI: {e}")
    else:
        # File path
        image_path = Path(image_source)
        if not image_path.exists():
            raise FileNotFoundError(f"Image file not found: {image_source}")
        return BytesIO(image_path.read_bytes())


def add_title_slide(prs: Presentation, slide_data: dict[str, Any], theme: dict) -> None:
    """Add a title slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout

    # Add background color
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = theme["primary"]

    # Add title
    if "title" in slide_data:
        title_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(2.5), Inches(9), Inches(1.5)
        )
        title_frame = title_box.text_frame
        title_frame.text = slide_data["title"]
        title_frame.paragraphs[0].font.size = Pt(44)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)
        title_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

    # Add subtitle/content
    if "content" in slide_data:
        subtitle_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(4.2), Inches(9), Inches(1)
        )
        subtitle_frame = subtitle_box.text_frame
        subtitle_frame.text = slide_data["content"]
        subtitle_frame.paragraphs[0].font.size = Pt(28)
        subtitle_frame.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)
        subtitle_frame.paragraphs[0].alignment = PP_ALIGN.CENTER


def add_content_slide(prs: Presentation, slide_data: dict[str, Any], theme: dict) -> None:
    """Add a content slide with title and bullet points."""
    slide = prs.slides.add_slide(prs.slide_layouts[1])  # Title and Content layout

    # Set title
    if "title" in slide_data:
        title = slide.shapes.title
        title.text = slide_data["title"]
        title.text_frame.paragraphs[0].font.color.rgb = theme["primary"]

    # Add content
    if "content" in slide_data:
        body = slide.placeholders[1]
        tf = body.text_frame
        tf.clear()

        content = slide_data["content"]
        if isinstance(content, str):
            # Single paragraph
            p = tf.paragraphs[0]
            p.text = content
            p.level = 0
        elif isinstance(content, list):
            # Bulleted list
            for i, item in enumerate(content):
                if i == 0:
                    p = tf.paragraphs[0]
                else:
                    p = tf.add_paragraph()
                p.text = item
                p.level = 0

    # Add table if present
    if "table" in slide_data:
        add_table_to_slide(slide, slide_data["table"], theme)

    # Add notes
    if "notes" in slide_data:
        notes_slide = slide.notes_slide
        notes_slide.notes_text_frame.text = slide_data["notes"]


def add_two_column_slide(prs: Presentation, slide_data: dict[str, Any], theme: dict) -> None:
    """Add a two-column content slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout

    # Add title
    if "title" in slide_data:
        title_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(0.5), Inches(9), Inches(0.8)
        )
        title_frame = title_box.text_frame
        title_frame.text = slide_data["title"]
        title_frame.paragraphs[0].font.size = Pt(32)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = theme["primary"]

    # Add left column
    if "left_content" in slide_data:
        left_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(1.5), Inches(4.5), Inches(4.5)
        )
        left_frame = left_box.text_frame
        add_text_content(left_frame, slide_data["left_content"])

    # Add right column
    if "right_content" in slide_data:
        right_box = slide.shapes.add_textbox(
            Inches(5.25), Inches(1.5), Inches(4.5), Inches(4.5)
        )
        right_frame = right_box.text_frame
        add_text_content(right_frame, slide_data["right_content"])


def add_picture_slide(prs: Presentation, slide_data: dict[str, Any], theme: dict) -> None:
    """Add a picture slide with full-size image."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout

    # Add title
    if "title" in slide_data:
        title_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(0.5), Inches(9), Inches(0.8)
        )
        title_frame = title_box.text_frame
        title_frame.text = slide_data["title"]
        title_frame.paragraphs[0].font.size = Pt(32)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = theme["primary"]

    # Add image
    if "image" in slide_data:
        try:
            image_stream = load_image(slide_data["image"])
            # Center the image
            slide.shapes.add_picture(
                image_stream,
                Inches(1.5), Inches(1.8),
                width=Inches(7)
            )
        except Exception as e:
            # Add error text if image fails to load
            error_box = slide.shapes.add_textbox(
                Inches(2), Inches(3.5), Inches(6), Inches(1)
            )
            error_frame = error_box.text_frame
            error_frame.text = f"[Image failed to load: {str(e)}]"
            error_frame.paragraphs[0].font.color.rgb = RGBColor(255, 0, 0)
            error_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

    # Add caption
    if "image_caption" in slide_data:
        caption_box = slide.shapes.add_textbox(
            Inches(1), Inches(6), Inches(8), Inches(0.5)
        )
        caption_frame = caption_box.text_frame
        caption_frame.text = slide_data["image_caption"]
        caption_frame.paragraphs[0].font.size = Pt(14)
        caption_frame.paragraphs[0].font.italic = True
        caption_frame.paragraphs[0].alignment = PP_ALIGN.CENTER


def add_blank_slide(prs: Presentation, slide_data: dict[str, Any], theme: dict) -> None:
    """Add a blank slide with optional title."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank layout

    if "title" in slide_data:
        title_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(0.5), Inches(9), Inches(0.8)
        )
        title_frame = title_box.text_frame
        title_frame.text = slide_data["title"]
        title_frame.paragraphs[0].font.size = Pt(32)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = theme["primary"]


def add_text_content(text_frame: Any, content: Any) -> None:
    """Add text content to a text frame (string or list)."""
    if isinstance(content, str):
        text_frame.text = content
    elif isinstance(content, list):
        for i, item in enumerate(content):
            if i == 0:
                p = text_frame.paragraphs[0]
            else:
                p = text_frame.add_paragraph()
            p.text = item
            p.level = 0


def add_table_to_slide(slide: Any, table_data: dict[str, Any], theme: dict) -> None:
    """Add a table to a slide."""
    headers = table_data.get("headers", [])
    rows = table_data.get("rows", [])
    style = table_data.get("style", "medium")

    if not headers or not rows:
        return

    # Calculate dimensions
    num_rows = len(rows) + 1  # +1 for header
    num_cols = len(headers)

    # Add table shape
    table_shape = slide.shapes.add_table(
        num_rows, num_cols,
        Inches(1), Inches(2.5),
        Inches(8), Inches(3)
    )
    table = table_shape.table

    # Set column widths
    col_width = Inches(8) / num_cols
    for col in table.columns:
        col.width = int(col_width)

    # Style colors based on style
    if style == "light":
        header_color = RGBColor(220, 220, 220)
        text_color = RGBColor(0, 0, 0)
    elif style == "dark":
        header_color = theme["primary"]
        text_color = RGBColor(255, 255, 255)
    else:  # medium
        header_color = theme["secondary"]
        text_color = RGBColor(0, 0, 0)

    # Fill header row
    for col_idx, header in enumerate(headers):
        cell = table.cell(0, col_idx)
        cell.text = str(header)
        cell.fill.solid()
        cell.fill.fore_color.rgb = header_color
        cell.text_frame.paragraphs[0].font.bold = True
        cell.text_frame.paragraphs[0].font.size = Pt(12)
        if style == "dark":
            cell.text_frame.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)

    # Fill data rows
    for row_idx, row in enumerate(rows):
        for col_idx, value in enumerate(row):
            cell = table.cell(row_idx + 1, col_idx)
            cell.text = str(value)
            cell.text_frame.paragraphs[0].font.size = Pt(11)


def create_presentation(data: dict[str, Any], output_path: Path) -> dict[str, Any]:
    """Create PowerPoint presentation from JSON data."""
    # Create presentation
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)

    # Get theme
    theme_name = data.get("theme", "default")
    theme = THEMES.get(theme_name, THEMES["default"])

    # Set metadata
    if "title" in data:
        prs.core_properties.title = data["title"]
    if "author" in data:
        prs.core_properties.author = data["author"]

    # Process slides
    slides_data = data.get("slides", [])
    if not slides_data:
        raise ValueError("Presentation must include 'slides' array")

    layout_handlers = {
        "title": add_title_slide,
        "content": add_content_slide,
        "two_column": add_two_column_slide,
        "picture": add_picture_slide,
        "blank": add_blank_slide
    }

    for slide_data in slides_data:
        layout = slide_data.get("layout", "content")

        if layout not in layout_handlers:
            raise ValueError(
                f"Invalid layout '{layout}'. Must be one of: {', '.join(layout_handlers.keys())}"
            )

        handler = layout_handlers[layout]
        handler(prs, slide_data, theme)

    # Save presentation
    prs.save(str(output_path))

    return {
        "slide_count": len(slides_data),
        "theme": theme_name
    }


def main() -> None:
    """Main entry point."""
    # This script is called via create_and_register.py
    # The actual implementation will be handled by that wrapper
    pass


if __name__ == "__main__":
    main()
