#!/usr/bin/env python3
"""
CSV creation script for the csv skill.

Reads JSON array from stdin and creates a CSV file.
"""
import csv
import json
import sys
from pathlib import Path
from typing import Any


def create_csv(data: list[dict[str, Any]], output_path: Path, **kwargs: Any) -> dict[str, Any]:
    """Create CSV file from JSON array."""
    if not data:
        raise ValueError("Cannot create CSV from empty array")

    # Extract options
    delimiter = kwargs.get("delimiter", ",")
    encoding = kwargs.get("encoding", "utf-8")
    include_index = kwargs.get("include_index", False)

    # Validate delimiter
    if len(delimiter) != 1:
        raise ValueError("Delimiter must be a single character")

    # Get headers from first object
    first_row = data[0]
    headers = list(first_row.keys())

    if include_index:
        headers = ["index"] + headers

    # Write CSV
    with open(output_path, "w", newline="", encoding=encoding) as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=headers, delimiter=delimiter)
        writer.writeheader()

        for i, row in enumerate(data):
            if include_index:
                row = {"index": i, **row}
            writer.writerow(row)

    # Get file size
    file_size = output_path.stat().st_size

    return {
        "rows": len(data),
        "columns": len(headers),
        "encoding": encoding
    }


def main() -> None:
    """Main entry point."""
    # This script is called via create_and_register.py
    # The actual implementation will be handled by that wrapper
    pass


if __name__ == "__main__":
    main()
