---
name: csv
description: "Create, read, and manipulate CSV files. Convert JSON to CSV, CSV to JSON, filter, sort, and transform tabular data."
display_name: "Manipulation de fichiers CSV"
metadata:
  config:
    emoji: "📋"
    trigger_patterns:
      - csv
      - comma separated
      - data export
      - spreadsheet data
      - tabular data
      - csv file
      - export to csv
      - read csv
      - parse csv
      - csv format
    requires:
      bins:
        - uv
---

## CSV File Manipulation

Work with CSV (Comma-Separated Values) files through three operations:

1. **Create CSV** — Convert JSON data to CSV file
2. **Read CSV** — Parse CSV file to JSON
3. **Transform CSV** — Filter, sort, and manipulate CSV data

All operations are performed via the `create_csv.py`, `read_csv.py`, and `transform_csv.py` scripts executed through `shell_exec`.

---

## Operation 1: Create CSV from JSON

Convert JSON array data to a CSV file.

### Usage

Pipe JSON array to stdin and specify the target filename:

```bash
echo '[{"name": "Alice", "age": 30, "city": "Paris"}, {"name": "Bob", "age": 25, "city": "London"}]' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill csv --filename "data.csv" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target CSV filename, e.g. `"export.csv"` |
| `--output-dir` | No | Output directory (default: current directory) |
| `--delimiter` | No | Column delimiter character (default: `,`). Use `\t` for TSV |
| `--encoding` | No | File encoding (default: `utf-8`). Options: `utf-8`, `iso-8859-1`, `windows-1252` |
| `--include-index` | No | Include row index as first column (default: `false`) |

### Stdin (JSON)

Provide a JSON array of objects. Each object represents one row:

```json
[
  {"name": "Alice", "age": 30, "department": "Engineering"},
  {"name": "Bob", "age": 25, "department": "Sales"},
  {"name": "Carol", "age": 35, "department": "Marketing"}
]
```

**Requirements**:
- Must be a JSON array
- Each object should have the same keys (headers)
- Values can be strings, numbers, booleans, or null

### Example

```bash
echo '[
  {"product": "Widget A", "price": 19.99, "stock": 150},
  {"product": "Widget B", "price": 29.99, "stock": 75},
  {"product": "Widget C", "price": 39.99, "stock": 200}
]' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill csv --filename "products.csv"
```

**Output CSV** (`products.csv`):
```csv
product,price,stock
Widget A,19.99,150
Widget B,29.99,75
Widget C,39.99,200
```

### Output Format (stdout)

```json
{
  "status": "success",
  "file_id": "uuid",
  "download_url": "/files/uuid/download",
  "filename": "products.csv",
  "size_bytes": 124,
  "mime_type": "text/csv",
  "metadata": {
    "rows": 3,
    "columns": 3,
    "encoding": "utf-8"
  }
}
```

---

## Operation 2: Read CSV to JSON

Parse a CSV file and convert it to JSON format.

### Usage

```bash
uv run python agent_framework/skills/builtin/skills/csv/read_csv.py \
  --file "data.csv" \
  --encoding "utf-8" \
  --delimiter ","
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--file` | Yes | Path to the CSV file to read |
| `--delimiter` | No | Column delimiter character (default: `,`) |
| `--encoding` | No | File encoding (default: `utf-8`) |
| `--skip-rows` | No | Number of rows to skip at the beginning (default: 0) |
| `--max-rows` | No | Maximum number of rows to read (default: all) |

### Output Format (stdout)

```json
{
  "status": "success",
  "data": [
    {"name": "Alice", "age": "30", "city": "Paris"},
    {"name": "Bob", "age": "25", "city": "London"}
  ],
  "metadata": {
    "rows": 2,
    "columns": 3,
    "headers": ["name", "age", "city"]
  }
}
```

**Note**: All values are returned as strings. Convert types as needed.

### Example

Given `employees.csv`:
```csv
name,role,salary
Alice Johnson,Manager,75000
Bob Smith,Developer,65000
Carol White,Designer,60000
```

```bash
uv run python agent_framework/skills/builtin/skills/csv/read_csv.py --file "employees.csv"
```

Output:
```json
{
  "status": "success",
  "data": [
    {"name": "Alice Johnson", "role": "Manager", "salary": "75000"},
    {"name": "Bob Smith", "role": "Developer", "salary": "65000"},
    {"name": "Carol White", "role": "Designer", "salary": "60000"}
  ],
  "metadata": {
    "rows": 3,
    "columns": 3,
    "headers": ["name", "role", "salary"]
  }
}
```

---

## Operation 3: Transform CSV

Filter, sort, and transform CSV data.

### Usage

```bash
uv run python agent_framework/skills/builtin/skills/csv/transform_csv.py \
  --input "data.csv" \
  --output "filtered.csv" \
  --filter '{"column": "age", "operator": ">", "value": 25}' \
  --sort "name" \
  --sort-order "asc"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--input` | Yes | Input CSV file path |
| `--output` | Yes | Output CSV file path |
| `--filter` | No | Filter condition as JSON (see Filter Syntax below) |
| `--sort` | No | Column name to sort by |
| `--sort-order` | No | Sort order: `"asc"` (default) or `"desc"` |
| `--select` | No | Comma-separated list of columns to include (default: all) |
| `--limit` | No | Maximum number of rows in output (default: all) |

### Filter Syntax

Filter is a JSON object:

```json
{
  "column": "column_name",
  "operator": "==|!=|>|<|>=|<=|contains|startswith|endswith",
  "value": "comparison_value"
}
```

**Operators**:
- `==` — Equal to
- `!=` — Not equal to
- `>`, `<`, `>=`, `<=` — Numeric comparisons
- `contains` — String contains substring
- `startswith` — String starts with
- `endswith` — String ends with

### Examples

#### Filter rows
```bash
# Get employees with salary > 60000
uv run python agent_framework/skills/builtin/skills/csv/transform_csv.py \
  --input "employees.csv" \
  --output "high_earners.csv" \
  --filter '{"column": "salary", "operator": ">", "value": "60000"}'
```

#### Sort data
```bash
# Sort employees by name alphabetically
uv run python agent_framework/skills/builtin/skills/csv/transform_csv.py \
  --input "employees.csv" \
  --output "sorted.csv" \
  --sort "name" \
  --sort-order "asc"
```

#### Select columns
```bash
# Extract only name and salary columns
uv run python agent_framework/skills/builtin/skills/csv/transform_csv.py \
  --input "employees.csv" \
  --output "names_salaries.csv" \
  --select "name,salary"
```

#### Combine operations
```bash
# Filter, sort, and limit
uv run python agent_framework/skills/builtin/skills/csv/transform_csv.py \
  --input "sales.csv" \
  --output "top_sales.csv" \
  --filter '{"column": "region", "operator": "==", "value": "North"}' \
  --sort "revenue" \
  --sort-order "desc" \
  --limit 10
```

### Output Format (stdout)

```json
{
  "status": "success",
  "file_id": "uuid",
  "download_url": "/files/uuid/download",
  "filename": "filtered.csv",
  "metadata": {
    "input_rows": 100,
    "output_rows": 25,
    "columns": 5
  }
}
```

---

## Error Handling (stderr)

On failure, scripts print JSON error to stderr:

```json
{
  "status": "error",
  "message": "Description of the error"
}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | No JSON on stdin (create) | `"No JSON data provided on stdin"` |
| 1 | Invalid JSON | `"Invalid JSON on stdin: ..."` |
| 1 | Not a JSON array | `"Stdin must be a JSON array of objects"` |
| 1 | Empty array | `"Cannot create CSV from empty array"` |
| 1 | File not found (read/transform) | `"File not found: data.csv"` |
| 1 | Invalid delimiter | `"Delimiter must be a single character"` |
| 1 | Invalid filter | `"Invalid filter JSON: ..."` |
| 1 | Missing column | `"Column 'age' not found in CSV"` |

---

## Encoding Support

The skill supports multiple text encodings for international data:

| Encoding | Use Case |
|----------|----------|
| `utf-8` (default) | Modern standard, supports all languages |
| `iso-8859-1` (Latin-1) | Western European languages |
| `windows-1252` | Windows legacy files |
| `utf-16` | Unicode with BOM (Byte Order Mark) |

**Example**:
```bash
# Read French CSV with ISO-8859-1 encoding
uv run python agent_framework/skills/builtin/skills/csv/read_csv.py \
  --file "données.csv" \
  --encoding "iso-8859-1"
```

---

## Common Use Cases

### 1. Export Database Query to CSV

```json
[
  {"user_id": 1001, "name": "Alice", "email": "alice@example.com", "signup_date": "2024-01-15"},
  {"user_id": 1002, "name": "Bob", "email": "bob@example.com", "signup_date": "2024-02-20"},
  {"user_id": 1003, "name": "Carol", "email": "carol@example.com", "signup_date": "2024-03-10"}
]
```

Pipe to create_csv.py → `users.csv`

### 2. Import CSV for Processing

Read CSV → Convert to JSON → Process in code → Export back to CSV

```bash
# Read
uv run python .../read_csv.py --file "input.csv" > data.json

# Process (in your code)
# ...

# Write
cat processed.json | uv run python ...create_csv.py --filename "output.csv"
```

### 3. Filter Sales Data

```bash
# Get sales from Q4 2024 in North America region
uv run python .../transform_csv.py \
  --input "sales_2024.csv" \
  --output "q4_north_america.csv" \
  --filter '{"column": "quarter", "operator": "==", "value": "Q4"}' \
  --filter '{"column": "region", "operator": "==", "value": "North America"}'
```

### 4. Create TSV (Tab-Separated Values)

```bash
echo '[...]' | uv run python ...create_csv.py \
  --filename "data.tsv" \
  --delimiter $'\t'
```

### 5. Extract Summary Report

```bash
# Top 20 customers by revenue
uv run python .../transform_csv.py \
  --input "customer_revenue.csv" \
  --output "top_20.csv" \
  --sort "total_revenue" \
  --sort-order "desc" \
  --limit 20 \
  --select "customer_name,total_revenue,country"
```

---

## Best Practices

### Data Quality

1. **Consistent headers**: Ensure all objects in JSON array have the same keys
2. **Handle null values**: Null values are exported as empty strings in CSV
3. **Escape special characters**: Commas, quotes, and newlines in values are properly escaped
4. **Validate data types**: CSV stores everything as text — validate types after reading

### Performance

1. **Large files**: For files > 100MB, use `--max-rows` to process in batches
2. **Filter early**: Apply filters before sorting to reduce data size
3. **Select columns**: Use `--select` to reduce memory usage with wide tables
4. **Encoding**: Use UTF-8 unless you have a specific reason for another encoding

### File Naming

1. Use `.csv` extension for comma-delimited files
2. Use `.tsv` extension for tab-delimited files
3. Include date or version in filename: `sales_2024-12-15.csv`
4. Use lowercase and underscores: `customer_data.csv` not `Customer Data.csv`

---

## Tips for Agents

When helping users work with CSV files:

1. **Identify operation**: Create, read, or transform?
2. **Check encoding**: Ask about international characters if unsure
3. **Suggest filters**: For large datasets, recommend filtering before downloading
4. **Validate structure**: Ensure JSON data has consistent structure for creation
5. **Provide examples**: Show sample output format
6. **Handle errors**: CSV parsing can fail — explain common issues (mismatched quotes, wrong encoding)
7. **Alternative formats**: Suggest Excel skill for files with multiple sheets or complex formatting

Remember: CSV is simple but powerful — ideal for data exchange, database imports/exports, and data analysis!
