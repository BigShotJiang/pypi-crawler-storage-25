#!/usr/bin/env python3
"""
CSV reading script for the csv skill.

Reads a CSV file and outputs JSON.
"""
import argparse
import csv
import json
import sys
from pathlib import Path


def read_csv_file(
    file_path: Path,
    delimiter: str = ",",
    encoding: str = "utf-8",
    skip_rows: int = 0,
    max_rows: int | None = None
) -> dict:
    """Read CSV file and return JSON."""
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    if len(delimiter) != 1:
        raise ValueError("Delimiter must be a single character")

    data = []
    with open(file_path, "r", newline="", encoding=encoding) as csvfile:
        reader = csv.DictReader(csvfile, delimiter=delimiter)

        # Skip rows if requested
        for _ in range(skip_rows):
            try:
                next(reader)
            except StopIteration:
                break

        # Read rows
        for i, row in enumerate(reader):
            if max_rows and i >= max_rows:
                break
            data.append(dict(row))

        headers = reader.fieldnames or []

    return {
        "status": "success",
        "data": data,
        "metadata": {
            "rows": len(data),
            "columns": len(headers),
            "headers": list(headers)
        }
    }


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Read CSV file and output JSON")
    parser.add_argument("--file", required=True, help="Path to CSV file")
    parser.add_argument("--delimiter", default=",", help="Column delimiter (default: ,)")
    parser.add_argument("--encoding", default="utf-8", help="File encoding (default: utf-8)")
    parser.add_argument("--skip-rows", type=int, default=0, help="Number of rows to skip")
    parser.add_argument("--max-rows", type=int, help="Maximum rows to read")

    args = parser.parse_args()

    try:
        result = read_csv_file(
            Path(args.file),
            delimiter=args.delimiter,
            encoding=args.encoding,
            skip_rows=args.skip_rows,
            max_rows=args.max_rows
        )
        print(json.dumps(result, indent=2))
    except Exception as e:
        error = {"status": "error", "message": str(e)}
        print(json.dumps(error), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
