#!/usr/bin/env python3
"""
CSV transformation script for the csv skill.

Filters, sorts, and selects columns from CSV files.
"""
import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any


def apply_filter(rows: list[dict], filter_spec: dict) -> list[dict]:
    """Apply filter to rows."""
    column = filter_spec["column"]
    operator = filter_spec["operator"]
    value = str(filter_spec["value"])

    filtered = []
    for row in rows:
        if column not in row:
            continue

        cell_value = str(row[column])

        # Apply operator
        if operator == "==":
            if cell_value == value:
                filtered.append(row)
        elif operator == "!=":
            if cell_value != value:
                filtered.append(row)
        elif operator == ">":
            try:
                if float(cell_value) > float(value):
                    filtered.append(row)
            except ValueError:
                continue
        elif operator == "<":
            try:
                if float(cell_value) < float(value):
                    filtered.append(row)
            except ValueError:
                continue
        elif operator == ">=":
            try:
                if float(cell_value) >= float(value):
                    filtered.append(row)
            except ValueError:
                continue
        elif operator == "<=":
            try:
                if float(cell_value) <= float(value):
                    filtered.append(row)
            except ValueError:
                continue
        elif operator == "contains":
            if value.lower() in cell_value.lower():
                filtered.append(row)
        elif operator == "startswith":
            if cell_value.lower().startswith(value.lower()):
                filtered.append(row)
        elif operator == "endswith":
            if cell_value.lower().endswith(value.lower()):
                filtered.append(row)

    return filtered


def sort_rows(rows: list[dict], sort_column: str, sort_order: str) -> list[dict]:
    """Sort rows by column."""
    def get_sort_key(row: dict) -> Any:
        value = row.get(sort_column, "")
        # Try numeric sort first
        try:
            return float(value)
        except (ValueError, TypeError):
            return str(value).lower()

    reverse = (sort_order.lower() == "desc")
    return sorted(rows, key=get_sort_key, reverse=reverse)


def select_columns(rows: list[dict], columns: list[str]) -> list[dict]:
    """Select specific columns from rows."""
    return [
        {col: row.get(col, "") for col in columns}
        for row in rows
    ]


def transform_csv(
    input_path: Path,
    output_path: Path,
    filter_spec: dict | None = None,
    sort_column: str | None = None,
    sort_order: str = "asc",
    select_cols: list[str] | None = None,
    limit: int | None = None
) -> dict:
    """Transform CSV file."""
    if not input_path.exists():
        raise FileNotFoundError(f"File not found: {input_path}")

    # Read input CSV
    with open(input_path, "r", newline="", encoding="utf-8") as csvfile:
        reader = csv.DictReader(csvfile)
        rows = list(reader)
        headers = reader.fieldnames or []

    input_row_count = len(rows)

    # Apply filter
    if filter_spec:
        rows = apply_filter(rows, filter_spec)

    # Apply sort
    if sort_column:
        if sort_column not in (headers if not select_cols else select_cols):
            raise ValueError(f"Column '{sort_column}' not found in CSV")
        rows = sort_rows(rows, sort_column, sort_order)

    # Select columns
    if select_cols:
        # Validate columns exist
        for col in select_cols:
            if col not in headers:
                raise ValueError(f"Column '{col}' not found in CSV")
        rows = select_columns(rows, select_cols)
        headers = select_cols

    # Apply limit
    if limit:
        rows = rows[:limit]

    # Write output CSV
    with open(output_path, "w", newline="", encoding="utf-8") as csvfile:
        if rows:
            writer = csv.DictWriter(csvfile, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

    return {
        "input_rows": input_row_count,
        "output_rows": len(rows),
        "columns": len(headers)
    }


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Transform CSV file")
    parser.add_argument("--input", required=True, help="Input CSV file")
    parser.add_argument("--output", required=True, help="Output CSV file")
    parser.add_argument("--filter", help="Filter as JSON")
    parser.add_argument("--sort", help="Column to sort by")
    parser.add_argument("--sort-order", default="asc", choices=["asc", "desc"], help="Sort order")
    parser.add_argument("--select", help="Comma-separated columns to select")
    parser.add_argument("--limit", type=int, help="Max rows in output")

    args = parser.parse_args()

    try:
        # Parse filter
        filter_spec = None
        if args.filter:
            filter_spec = json.loads(args.filter)

        # Parse select columns
        select_cols = None
        if args.select:
            select_cols = [col.strip() for col in args.select.split(",")]

        # Transform
        metadata = transform_csv(
            Path(args.input),
            Path(args.output),
            filter_spec=filter_spec,
            sort_column=args.sort,
            sort_order=args.sort_order,
            select_cols=select_cols,
            limit=args.limit
        )

        # Output result
        result = {
            "status": "success",
            "filename": args.output,
            "metadata": metadata
        }
        print(json.dumps(result, indent=2))

    except Exception as e:
        error = {"status": "error", "message": str(e)}
        print(json.dumps(error), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
