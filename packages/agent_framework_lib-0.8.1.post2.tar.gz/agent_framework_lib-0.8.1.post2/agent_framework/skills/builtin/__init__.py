"""Built-in Skills for Agent Framework — Markdown-based skills only."""

from pathlib import Path
from ..base import Skill

_SKILLS_MD_DIR = Path(__file__).parent / "skills"


def _get_builtin_skills_from_markdown() -> list[Skill]:
    """Load built-in skills from SKILL.md files with ShellTool and WebFetchTool attached."""
    from ..markdown_loader import MarkdownSkillLoader
    from ...tools.shell_tool import ShellTool
    from ...tools.web_fetch_tool import WebFetchTool

    skills = MarkdownSkillLoader().load_from_dir(_SKILLS_MD_DIR)
    for skill in skills:
        existing_types = {type(t) for t in skill.tools}
        if ShellTool not in existing_types:
            skill.tools.append(ShellTool(default_timeout=60))
        if WebFetchTool not in existing_types:
            skill.tools.append(WebFetchTool())
    return skills


def get_all_builtin_skills() -> list[Skill]:
    """Get all built-in skills from SKILL.md files.

    Returns:
        List of Skill instances for all built-in skills.
    """
    return _get_builtin_skills_from_markdown()


__all__ = [
    "get_all_builtin_skills",
]
