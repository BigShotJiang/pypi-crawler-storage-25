"""Agent Framework Tools — Shell, web fetch, and adaptive sizing utilities."""

from .base import AgentTool, ToolDependencyError
from .shell_tool import ShellTool
from .web_fetch_tool import WebFetchTool
from .sizing_config import ImageSizingConfig, ImageDimensionCalculator
from .pdf_image_scaler import PDFImageScaler
from .adaptive_pdf_css import AdaptivePDFCSS, PDFImageConfig
from . import multimodal_tools

__all__ = [
    "AgentTool",
    "ToolDependencyError",
    "ShellTool",
    "WebFetchTool",
    "ImageSizingConfig",
    "ImageDimensionCalculator",
    "PDFImageScaler",
    "AdaptivePDFCSS",
    "PDFImageConfig",
    "multimodal_tools",
]
