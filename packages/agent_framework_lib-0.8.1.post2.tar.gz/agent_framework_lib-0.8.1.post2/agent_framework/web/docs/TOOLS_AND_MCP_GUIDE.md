# Tools and MCP Integration Guide

This guide explains how to add tools and MCP (Model Context Protocol) servers to your agents, including the skills architecture and the scripts-based tool system.

**Related Documentation:**
- [Creating Agents Guide](CREATING_AGENTS.md) - Complete guide to creating agents
- [Skills Integration](CREATING_AGENTS.md#skills-integration) - Skills system in agents
- [Custom Skills Guide](CUSTOM_SKILLS_GUIDE.md) - Creating custom skills

## Table of Contents

1. [Skills and Tools Architecture](#skills-and-tools-architecture)
2. [Scripts-Based Skill Architecture](#scripts-based-skill-architecture)
3. [Available Scripts](#available-scripts)
4. [Creating a New Script Skill](#creating-a-new-script-skill)
5. [Adding Tools to LlamaIndex Agents](#adding-tools-to-llamaindex-agents)
6. [Adding Tools to BaseAgent (Custom Framework)](#adding-tools-to-baseagent-custom-framework)
7. [Adding MCP Servers to LlamaIndex Agents](#adding-mcp-servers-to-llamaindex-agents)
8. [Adding MCP Servers to BaseAgent](#adding-mcp-servers-to-baseagent)
9. [Dependency Management](#dependency-management)
10. [Troubleshooting](#troubleshooting)
11. [Tool Best Practices](#tool-best-practices)

---

## Skills and Tools Architecture

The Agent Framework uses a **markdown-based skills architecture** where each skill is defined by a `SKILL.md` file and uses `ShellTool` to execute standalone CLI scripts.

### Overview

Skills are the primary way to provide capabilities to agents. Each skill consists of:

- **SKILL.md** — a markdown file with frontmatter metadata and detailed instructions for the LLM
- **ShellTool** — executes CLI commands (shell scripts, Python scripts) and returns stdout/stderr
- **WebFetchTool** — retrieves web content (URLs, APIs) for skills that need web access

When a skill is loaded, the framework automatically attaches `ShellTool` and `WebFetchTool` to it. The agent reads the SKILL.md instructions and uses `ShellTool` to run the appropriate CLI script.

### How It Works

```
Agent LLM
  │
  ├── load_skill("excel")
  │     └── Returns: SKILL.md instructions + ShellTool + WebFetchTool
  │
  └── shell_exec("uv run python scripts/skills/create_excel.py ...")
        └── Script runs autonomously
              ├── stdout: {"status": "success", "file": "/path/to/report.xlsx"}
              └── stderr + exit 1 on error
```

### Key Components

| Component | Location | Role |
|-----------|----------|------|
| `ShellTool` | `agent_framework/tools/shell_tool.py` | Executes CLI commands with timeout support |
| `WebFetchTool` | `agent_framework/tools/web_fetch_tool.py` | Fetches web content for skills needing web access |
| `AgentTool` | `agent_framework/tools/base.py` | Abstract base class for ShellTool and WebFetchTool |
| `MarkdownSkillLoader` | `agent_framework/skills/markdown_loader.py` | Loads skills from SKILL.md files |
| `multimodal_tools` | `agent_framework/tools/multimodal_tools.py` | Multimodal content processing utilities |
| Sizing utilities | `agent_framework/tools/sizing_config.py` etc. | Image dimension calculation and PDF scaling |

### Loading Skills

Skills are loaded automatically via `get_all_builtin_skills()`:

```python
from agent_framework.skills.builtin import get_all_builtin_skills

skills = get_all_builtin_skills()
for skill in skills:
    print(skill.metadata.name, [type(t).__name__ for t in skill.tools])
    # e.g. "excel ['ShellTool', 'WebFetchTool']"
```

`BaseAgent` (and therefore `LlamaIndexAgent`) inherits from `SkillsMixin`, so built-in skills and their tools are auto-loaded at initialization.


---

## Scripts-Based Skill Architecture

Each skill uses standalone CLI scripts executed via `ShellTool`. This is the architecture for all built-in skills.

### Agent Workflow

1. The agent loads a skill via `SkillRegistry` or `register_builtin_skills()`
2. The skill's `SKILL.md` instructions are injected into the agent's context
3. The agent reads the instructions and builds the appropriate shell command
4. The agent calls `shell_exec(...)` to run the script
5. The script writes output to stdout as JSON
6. The agent reads the result and communicates it to the user

### Script Output Format

All scripts use a uniform JSON output format:

```json
// Success (file created)
{"status": "success", "file": "/absolute/path/to/output.xlsx"}

// Success (data returned)
{"status": "success", "results": [...]}

// Error (on stderr, exit code 1)
{"status": "error", "message": "Description of the error"}
```

---

## Available Scripts

All scripts live in `scripts/skills/` and are executed with `uv run python`:

| Script | Description | Key Arguments |
|--------|-------------|---------------|
| `create_excel.py` | Generate .xlsx files | `--filename`, JSON sheets on stdin |
| `chart_to_image.py` | Chart.js → PNG | `--filename`, `--output-dir`, JSON config on stdin |
| `mermaid_to_image.py` | Mermaid → PNG | `--filename`, `--output-dir`, `--theme`, code on stdin |
| `table_to_image.py` | HTML table → PNG | `--filename`, `--output-dir`, JSON data on stdin |
| `create_file.py` | Create text files | `--filename`, `--content` or stdin |
| `list_files.py` | List directory contents | `--directory` |
| `read_file.py` | Read file content | `--path` |
| `get_file_path.py` | Resolve file paths | `--filename`, `--directory` |
| `create_pdf.py` | HTML → PDF | `--filename`, `--output-dir`, HTML on stdin |
| `web_search.py` | Web search (DuckDuckGo) | `--query`, `--max-results` |
| `web_news_search.py` | News search (DuckDuckGo) | `--query`, `--max-results` |
| `create_drawio.py` | Create .drawio files | `--filename`, `--xml` or XML on stdin |

### Built-in Skills Reference

| Skill | Script | Category |
|-------|--------|----------|
| `chart` | `scripts/skills/chart_to_image.py` | visualization |
| `mermaid` | `scripts/skills/mermaid_to_image.py` | visualization |
| `table` | `scripts/skills/table_to_image.py` | visualization |
| `file` | `create_file.py`, `list_files.py`, `read_file.py` | document |
| `unified_pdf` | `scripts/skills/create_pdf.py` | document |
| `file_access` | `scripts/skills/get_file_path.py` | document |
| `excel` | `scripts/skills/create_excel.py` | document |
| `web_search` | `web_search.py`, `web_news_search.py` | web |
| `drawio` | `scripts/skills/create_drawio.py` | document |
| `multimodal` | (requires API access) | multimodal |
| `form` | (instructions only) | ui |
| `optionsblock` | (instructions only) | ui |
| `image_display` | (instructions only) | ui |

---

## Creating a New Script Skill

To add a new skill to the framework, you create two things: a standalone script and a SKILL.md file.

### Step 1: Create the Script

Create a new Python file in `scripts/skills/`. Follow this pattern:

```python
#!/usr/bin/env python3
"""Short description of what this script does."""
import argparse
import json
import sys


def main():
    parser = argparse.ArgumentParser(description="What this script does")
    parser.add_argument("--filename", required=True, help="Output filename")
    parser.add_argument("--output-dir", default=".", help="Output directory")
    args = parser.parse_args()

    try:
        # Read input from stdin if needed
        input_data = sys.stdin.read().strip()
        if not input_data:
            raise ValueError("No input data provided on stdin")

        data = json.loads(input_data)

        # Do the actual work
        output_path = do_work(args.filename, args.output_dir, data)

        # Print success JSON to stdout
        print(json.dumps({"status": "success", "file": str(output_path)}))

    except json.JSONDecodeError as e:
        print(json.dumps({"status": "error", "message": f"Invalid JSON: {e}"}), file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
```

**Conventions:**

- Use `argparse` for all CLI arguments
- Read large/structured input from stdin as JSON
- Print success result as JSON to stdout with `"status": "success"`
- Print errors as JSON to stderr with `"status": "error"` and exit code 1
- Write output files to `--output-dir` (default: current directory)
- Use absolute paths in the output JSON so the agent can reference the file
- The script must be runnable with `uv run python scripts/skills/your_script.py`

### Step 2: Create the SKILL.md

Create a directory under `agent_framework/skills/builtin/skills/your_skill/` with a `SKILL.md` file:

```markdown
---
name: your_skill
description: "Short description for the agent to understand when to use this skill."
display_name: "Human-Readable Skill Name"
metadata:
  config:
    emoji: "🔧"
    trigger_patterns:
      - keyword1
      - keyword2
    requires:
      bins:
        - uv
---

## Your Skill Name

Description of what this skill does and when to use it.

### Usage

```bash
echo '{"key": "value"}' | uv run python scripts/skills/your_script.py --filename "output.txt" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Output filename |
| `--output-dir` | No | Output directory (default: current directory) |

### Stdin (JSON)

Describe the expected JSON input format.

### Output Format (stdout)

```json
{"status": "success", "file": "/absolute/path/to/output.txt"}
```

### Error Handling (stderr)

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause |
|-----------|-------|
| 1 | Invalid input or runtime error |
| 2 | Missing required arguments |
```

### Step 3: Verify

Run the script with `--help` to confirm it works:

```bash
uv run python scripts/skills/your_script.py --help
```

Test with valid input:

```bash
echo '{"key": "value"}' | uv run python scripts/skills/your_script.py --filename "test.txt"
```

The skill will be automatically discovered by `MarkdownSkillLoader` and will have `ShellTool` + `WebFetchTool` attached when loaded via `get_all_builtin_skills()`.


---

## Adding Tools to LlamaIndex Agents

For a complete guide on creating LlamaIndex agents, see [CREATING_AGENTS.md](CREATING_AGENTS.md).

### Automatic FunctionTool Conversion

LlamaIndexAgent automatically converts Python functions to LlamaIndex `FunctionTool` instances:
- Function name → tool name
- Docstring → tool description
- Type hints → parameter schema

```python
from agent_framework.implementations import LlamaIndexAgent

class MyAgent(LlamaIndexAgent):
    def get_agent_tools(self) -> list[callable]:
        def add(a: int, b: int) -> int:
            """Add two numbers together."""
            return a + b
        
        def get_weather(city: str) -> str:
            """Get the current weather for a city."""
            return f"Weather in {city}: Sunny, 72°F"
        
        return [add, get_weather]
```

> **Note:** You can still use `FunctionTool.from_defaults()` for more control, but it's no longer required.

### Async Tools

LlamaIndex supports async tools natively:

```python
def get_agent_tools(self) -> list[callable]:
    async def fetch_data(url: str) -> str:
        """Fetch data from a URL."""
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                return await response.text()
    
    return [fetch_data]
```

### Tools with Session Context

```python
class MyAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__()
        self.current_user_id = "default_user"
    
    async def configure_session(self, session_configuration):
        self.current_user_id = session_configuration.get('user_id', 'default_user')
        self.current_session_id = session_configuration.get('session_id')
        await super().configure_session(session_configuration)
    
    def get_agent_tools(self) -> list[callable]:
        def get_user_info() -> str:
            """Get information about the current user."""
            return f"User: {self.current_user_id}, Session: {self.current_session_id}"
        
        return [get_user_info]
```

---

## Adding Tools to BaseAgent (Custom Framework)

For a complete guide on creating BaseAgent implementations, see [CREATING_AGENTS.md](CREATING_AGENTS.md).

### Basic Tool Integration

```python
from agent_framework.core.base_agent import BaseAgent

class MyCustomAgent(BaseAgent):
    def get_agent_tools(self) -> list[callable]:
        def calculate(expression: str) -> float:
            """Evaluate a mathematical expression."""
            return eval(expression)
        
        return [calculate]
    
    async def run_agent(self, query: str, ctx, stream: bool = False):
        """You handle tool calling in your framework."""
        pass
```

### Tool Execution Pattern

```python
async def run_agent(self, query: str, ctx, stream: bool = False):
    messages = [
        {"role": "system", "content": self._system_prompt},
        {"role": "user", "content": query}
    ]
    
    max_iterations = 5
    for iteration in range(max_iterations):
        response = await self._llm_client.create(
            messages=messages,
            tools=self._get_tool_schemas()
        )
        
        message = response.choices[0].message
        
        if hasattr(message, 'tool_calls') and message.tool_calls:
            for tool_call in message.tool_calls:
                tool_name = tool_call.function.name
                tool_args = json.loads(tool_call.function.arguments)
                
                if tool_name in self._tools:
                    result = self._tools[tool_name](**tool_args)
                    
                    messages.append({
                        "role": "assistant",
                        "tool_calls": [tool_call]
                    })
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": str(result)
                    })
            continue
        
        return message.content
    
    return "Max iterations reached"
```

---

## Adding MCP Servers to LlamaIndex Agents

### What is MCP?

MCP (Model Context Protocol) allows agents to connect to external tool servers, enabling file system operations, database access, API integrations, and custom tool servers.

### Important: Memory Tools Are Added Automatically

When you define `get_memory_config()` in your agent, the framework automatically adds memory tools (`recall_memory`, `store_memory`, `forget_memory`). These are combined with your tools in `_get_all_tools()`.

**⚠️ If you override `initialize_agent()`**, use the `tools` parameter (which already contains memory tools) instead of calling `get_agent_tools()` directly:

```python
# ❌ WRONG - loses memory tools
async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
    all_tools = self.get_agent_tools()
    await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)

# ✅ CORRECT - preserves memory tools
async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
    all_tools = list(tools) + self.mcp_tools
    await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)
```

### Basic MCP Integration

```python
from agent_framework.implementations import LlamaIndexAgent

class MyMCPAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__()
        self.mcp_tools = []
        self._mcp_initialized = False
    
    async def _initialize_mcp_tools(self):
        if self._mcp_initialized:
            return
        
        try:
            from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
        except ImportError:
            print("Install: uv add llama-index-tools-mcp")
            return
        
        client = BasicMCPClient(
            command="uvx",
            args=["@modelcontextprotocol/server-filesystem", "/path/to/workspace"],
            env={}
        )
        
        mcp_tool_spec = McpToolSpec(client=client)
        function_tools = await mcp_tool_spec.to_tool_list_async()
        self.mcp_tools.extend(function_tools)
        self._mcp_initialized = True
    
    def get_agent_tools(self) -> list[callable]:
        def greet(name: str) -> str:
            """Greet a user."""
            return f"Hello, {name}!"
        
        return [greet]
    
    async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
        await self._initialize_mcp_tools()
        all_tools = list(tools) + self.mcp_tools
        await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)
```

### Multiple MCP Servers

```python
async def _initialize_mcp_tools(self):
    from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
    
    fs_client = BasicMCPClient(
        command="uvx",
        args=["@modelcontextprotocol/server-filesystem", "/workspace"]
    )
    fs_tools = await McpToolSpec(client=fs_client).to_tool_list_async()
    self.mcp_tools.extend(fs_tools)
    
    gh_client = BasicMCPClient(
        command="uvx",
        args=["@modelcontextprotocol/server-github"],
        env={"GITHUB_TOKEN": os.getenv("GITHUB_TOKEN")}
    )
    gh_tools = await McpToolSpec(client=gh_client).to_tool_list_async()
    self.mcp_tools.extend(gh_tools)
    
    db_client = BasicMCPClient(
        command="uvx",
        args=["@modelcontextprotocol/server-postgres"],
        env={"DATABASE_URL": os.getenv("DATABASE_URL")}
    )
    db_tools = await McpToolSpec(client=db_client).to_tool_list_async()
    self.mcp_tools.extend(db_tools)
```

### MCP Server Configuration

Common MCP servers and their configurations:

```python
# Filesystem access
{"command": "uvx", "args": ["@modelcontextprotocol/server-filesystem", "/path/to/workspace"]}

# GitHub integration
{"command": "uvx", "args": ["@modelcontextprotocol/server-github"], "env": {"GITHUB_TOKEN": "your-token"}}

# PostgreSQL database
{"command": "uvx", "args": ["@modelcontextprotocol/server-postgres"], "env": {"DATABASE_URL": "postgresql://..."}}

# Web fetch/scraping
{"command": "uvx", "args": ["@modelcontextprotocol/server-fetch"]}

# Custom Python MCP server
{"command": "uv", "args": ["run", "python", "-m", "my_mcp_server"], "env": {"API_KEY": "your-key"}}
```

---

## Adding MCP Servers to BaseAgent

For BaseAgent, you handle MCP tool loading and execution manually:

```python
from agent_framework.core.base_agent import BaseAgent

class MyCustomMCPAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.mcp_tools = []
        self._mcp_clients = {}
    
    async def _initialize_mcp_tools(self):
        try:
            from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
        except ImportError:
            print("Install: uv add llama-index-tools-mcp")
            return
        
        client = BasicMCPClient(
            command="uvx",
            args=["@modelcontextprotocol/server-filesystem", "/workspace"]
        )
        self._mcp_clients["filesystem"] = client
        
        mcp_tool_spec = McpToolSpec(client=client)
        function_tools = await mcp_tool_spec.to_tool_list_async()
        self.mcp_tools.extend(function_tools)
    
    def get_agent_tools(self) -> list[callable]:
        built_in_tools = [...]
        return built_in_tools + self.mcp_tools
    
    async def initialize_agent(self, model_name, system_prompt, tools, **kwargs):
        await self._initialize_mcp_tools()
        all_tools = self.get_agent_tools()
        # Initialize your framework with all tools
```

---

## Dependency Management

### Core Dependencies

```bash
# Install base framework
uv add agent-framework-lib

# With LlamaIndex support
uv add agent-framework-lib[llamaindex]
```

**Core dependencies** (always installed): `aiofiles`, `pydantic`

### Chart Generation Dependencies

Chart generation scripts require Playwright for browser automation.

```bash
# Install Playwright
uv add playwright

# Install browser binaries (Chromium) — one-time setup (~100MB)
playwright install chromium
```

### PDF Generation Dependencies

PDF generation scripts require additional Python packages and system libraries.

**Python Packages:**
```bash
uv add weasyprint>=60.0 markdown>=3.5
```

**System Dependencies (WeasyPrint):**

macOS:
```bash
brew install pango gdk-pixbuf libffi
export DYLD_LIBRARY_PATH="/opt/homebrew/lib:$DYLD_LIBRARY_PATH"
```

Ubuntu/Debian:
```bash
sudo apt-get install libpango-1.0-0 libpangoft2-1.0-0 libgdk-pixbuf2.0-0 libffi-dev
```

Fedora/RHEL:
```bash
sudo dnf install pango gdk-pixbuf2 libffi-devel
```

### Web Search Dependencies

```bash
uv add ddgs
# or
uv add agent-framework-lib[websearch]
```

### MCP Dependencies

```bash
uv add llama-index-tools-mcp
```

### Optional Dependencies

```bash
uv add agent-framework-lib[mongodb]       # MongoDB session storage
uv add agent-framework-lib[s3]            # AWS S3 file storage
uv add agent-framework-lib[minio]         # MinIO file storage
uv add agent-framework-lib[gcp]           # GCP file storage
uv add agent-framework-lib[multimodal]    # Multimodal processing
uv add agent-framework-lib[observability] # Observability stack
uv add agent-framework-lib[websearch]     # Web search (DuckDuckGo)
uv add agent-framework-lib[all]           # All optional dependencies
```


---

## Troubleshooting

### PDF Scripts Not Working

**Symptom:** `create_pdf.py` fails with missing library errors

**Solution:**
1. Install system dependencies for your platform (see [Dependency Management](#dependency-management))
2. On macOS, ensure `DYLD_LIBRARY_PATH` is set:
   ```bash
   export DYLD_LIBRARY_PATH="/opt/homebrew/lib:$DYLD_LIBRARY_PATH"
   ```
3. Restart your Python environment after installing dependencies

### Tools Not Being Called

1. Check docstrings are clear and descriptive
2. Verify type hints are correct
3. Ensure tools are returned from `get_agent_tools()`
4. Check LLM model supports function calling

### MCP Tools Not Loading

1. Install MCP package: `uv add llama-index-tools-mcp`
2. Verify MCP server is installed: `uvx install @modelcontextprotocol/server-filesystem`
3. Check server command and args are correct
4. Ensure `_initialize_mcp_tools()` is called before agent initialization

### Script Execution Errors

1. Verify the script runs manually: `uv run python scripts/skills/your_script.py --help`
2. Check stdin input is valid JSON when required
3. Look at stderr output for error details
4. Ensure `ShellTool` timeout is sufficient for the operation (default: 60s)

---

## Tool Best Practices

### 1. Clear Docstrings

```python
def search_database(query: str, limit: int = 10) -> list[dict]:
    """
    Search the database for records matching the query.
    
    Args:
        query: The search query string
        limit: Maximum number of results to return (default: 10)
    
    Returns:
        List of matching records as dictionaries
    """
```

### 2. Type Hints

```python
def calculate_discount(price: float, discount_percent: int) -> float:
    """Calculate discounted price."""
    return price * (1 - discount_percent / 100)
```

### 3. Error Handling

```python
def divide(a: float, b: float) -> float | str:
    """Divide two numbers."""
    try:
        if b == 0:
            return "Error: Cannot divide by zero"
        return a / b
    except Exception as e:
        return f"Error: {str(e)}"
```

### 4. Async for I/O

```python
async def fetch_api_data(endpoint: str) -> dict:
    """Fetch data from API endpoint."""
    import aiohttp
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://api.example.com/{endpoint}") as response:
            return await response.json()
```

### 5. Tool Organization

```python
# tools/database.py
def search_users(query: str) -> list[dict]:
    """Search users in database."""
    pass

# tools/api.py
async def fetch_weather(city: str) -> dict:
    """Fetch weather data."""
    pass

# agent.py
from tools import database, api

class MyAgent(LlamaIndexAgent):
    def get_agent_tools(self) -> list[callable]:
        return [database.search_users, api.fetch_weather]
```

### 6. Tool Testing

```python
import pytest
from agent import MyAgent

def test_add_tool():
    agent = MyAgent()
    tools = agent.get_agent_tools()
    add_tool = next(t for t in tools if t.__name__ == "add")
    assert add_tool(2, 3) == 5

@pytest.mark.asyncio
async def test_async_tool():
    agent = MyAgent()
    tools = agent.get_agent_tools()
    fetch_tool = next(t for t in tools if t.__name__ == "fetch_data")
    result = await fetch_tool("https://api.example.com/data")
    assert isinstance(result, dict)
```

---

## Additional Resources

- [LlamaIndex Tools Documentation](https://docs.llamaindex.ai/en/stable/module_guides/deploying/agents/tools/)
- [Model Context Protocol](https://modelcontextprotocol.io/)
- [MCP Server List](https://github.com/modelcontextprotocol/servers)
- [Agent Framework Examples](../examples/)
- [WeasyPrint Documentation](https://doc.courtbouillon.org/weasyprint/)
