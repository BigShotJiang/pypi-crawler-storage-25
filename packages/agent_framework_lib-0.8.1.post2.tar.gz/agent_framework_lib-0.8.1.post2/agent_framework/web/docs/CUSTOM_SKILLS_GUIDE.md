# Guide des Custom Skills — AgentFramework

## Table des matières

1. [Introduction](#1-introduction)
2. [Glossaire](#2-glossaire)
3. [Types de Skills](#3-types-de-skills)
4. [Structure d'un fichier SKILL.md](#4-structure-dun-fichier-skillmd)
5. [Référence du Frontmatter YAML](#5-référence-du-frontmatter-yaml)
6. [Méthodes de création et modification](#6-méthodes-de-création-et-modification)
7. [Cycle de vie des skills](#7-cycle-de-vie-des-skills)
8. [Skills builtin](#8-skills-builtin)
9. [Suppression du système legacy](#9-suppression-du-système-legacy)
10. [API REST](#10-api-rest)

---

## 1. Introduction

Ce guide est la référence principale pour la création et la gestion des **skills** dans AgentFramework. Un skill est un module de capacité chargeable à la demande par un agent, défini par un fichier `SKILL.md`.

AgentFramework utilise exclusivement le système basé sur des fichiers **Markdown + Scripts** pour définir les skills. Chaque skill est décrit par un fichier `SKILL.md` contenant un bloc de métadonnées YAML (frontmatter) suivi d'instructions en Markdown.

Il existe deux types de skills :

- **Skill_Markdown** — Instructions pures en Markdown, sans script associé.
- **Skill_Script** — Instructions Markdown combinées avec un ou plusieurs scripts Python autonomes exécutés via `ShellTool`.

Ce guide couvre la structure des fichiers, les métadonnées disponibles, les méthodes de création, le cycle de vie complet, et la référence des skills builtin du framework.

---

## 2. Glossaire

| Terme | Définition |
|-------|------------|
| **Skill** | Module de capacité chargeable à la demande par un agent, défini par un fichier `SKILL.md` |
| **Skill_Markdown** | Skill dont les instructions sont écrites en Markdown pur, sans script associé. Le fichier `SKILL.md` contient uniquement des instructions textuelles pour l'agent (ex : `form`, `image_display`, `multimodal`) |
| **Skill_Script** | Skill combinant un fichier `SKILL.md` (instructions) avec un ou plusieurs scripts Python autonomes exécutés via `ShellTool` (ex : `chart`, `excel`, `mermaid`) |
| **SKILL.md** | Fichier définissant un skill, composé d'un frontmatter YAML (métadonnées) et d'un corps Markdown (instructions pour l'agent) |
| **Frontmatter** | Bloc YAML en tête du fichier `SKILL.md`, délimité par `---`, contenant les métadonnées du skill (name, description, trigger_patterns, etc.) |
| **SkillRegistry** | Registre central qui gère l'enregistrement, le chargement et le déchargement des skills |
| **CustomSkillManager** | Gestionnaire des skills personnalisées créées par les utilisateurs via l'API, l'UI ou le code |
| **MarkdownSkillLoader** | Composant qui parse les fichiers `SKILL.md` et crée des objets `Skill` |
| **ShellTool** | Outil natif permettant l'exécution de commandes shell avec un timeout configurable (60s par défaut) |
| **trigger_patterns** | Liste de mots-clés permettant la découverte automatique d'un skill par l'agent |

---

## 3. Types de Skills

AgentFramework distingue deux types de skills, selon qu'ils contiennent ou non des scripts exécutables.

### 3.1 Skill_Markdown

Un **Skill_Markdown** est un skill dont le fichier `SKILL.md` contient uniquement des instructions textuelles en Markdown. Il n'a pas de script Python associé. L'agent utilise directement les instructions pour formater ses réponses ou interagir avec l'utilisateur.

**Cas d'usage typiques :**
- Génération de formulaires interactifs (`form`)
- Affichage d'images (`image_display`)
- Analyse multimodale (`multimodal`)
- Blocs d'options (`optionsblock`)

**Structure du dossier :**

```
skills/
  mon_skill_markdown/
    SKILL.md          # Frontmatter YAML + instructions Markdown
```

### 3.2 Skill_Script

Un **Skill_Script** combine un fichier `SKILL.md` (instructions) avec un ou plusieurs scripts Python autonomes. L'agent lit les instructions du `SKILL.md`, construit une commande shell, et l'exécute via `ShellTool`. Le script produit un résultat JSON sur stdout.

**Cas d'usage typiques :**
- Génération de graphiques (`chart`)
- Création de fichiers Excel (`excel`)
- Génération de diagrammes Mermaid (`mermaid`)
- Recherche web (`web_search`)
- Création de PDF (`unified_pdf`)

**Structure du dossier :**

```
skills/
  mon_skill_script/
    SKILL.md          # Frontmatter YAML + instructions Markdown
    mon_script.py     # Script Python exécuté via ShellTool
    utils.py          # (optionnel) Modules utilitaires
```

### 3.3 Comparaison

| Caractéristique | Skill_Markdown | Skill_Script |
|----------------|----------------|--------------|
| Fichier `SKILL.md` | ✅ Obligatoire | ✅ Obligatoire |
| Scripts Python | ❌ Aucun | ✅ Un ou plusieurs |
| Exécution via ShellTool | ❌ Non | ✅ Oui |
| Sortie JSON sur stdout | ❌ Non applicable | ✅ Oui |
| Dépendances système (bins) | Rarement | Souvent (ex : `uv`) |
| Complexité | Simple | Moyenne à élevée |

---

## 4. Structure d'un fichier SKILL.md

Chaque skill est défini par un fichier `SKILL.md` composé de deux parties :

1. **Frontmatter YAML** — Bloc de métadonnées délimité par `---`
2. **Corps Markdown** — Instructions pour l'agent

### 4.1 Format général

```markdown
---
name: nom-du-skill
description: "Description courte du skill"
display_name: "Nom affiché dans l'UI"
metadata:
  config:
    emoji: "🔧"
    trigger_patterns:
      - mot-clé1
      - mot-clé2
---

## Instructions

Contenu Markdown décrivant comment l'agent doit utiliser ce skill.
Les instructions peuvent inclure des exemples, des tableaux, des blocs de code, etc.
```

Le frontmatter est parsé par `MarkdownSkillLoader` qui extrait les métadonnées et crée un objet `Skill`. Le corps Markdown est injecté comme instructions dans le contexte de l'agent lorsque le skill est chargé.

### 4.2 Exemple complet — Skill_Markdown

Voici un exemple complet d'un Skill_Markdown pour la génération de formulaires interactifs :

```markdown
---
name: form
description: "Generate interactive forms for collecting structured user input"
display_name: "Création de formulaires"
metadata:
  config:
    emoji: "📝"
    trigger_patterns:
      - form
      - input
      - survey
      - questionnaire
      - collect information
---

## Instructions de génération de formulaires

Tu peux présenter des formulaires interactifs aux utilisateurs pour collecter
des informations structurées. Les formulaires sont définis via une structure
JSON avec une clé `formDefinition`.

### Quand utiliser les formulaires

- Collecter plusieurs informations en une seule fois
- Recueillir des données structurées (emails, nombres, sélections)
- Créer des sondages ou questionnaires

### Structure JSON du formulaire

Pour présenter un formulaire, génère un objet JSON avec cette structure :

\```json
{
  "formDefinition": {
    "title": "Titre du formulaire",
    "description": "Description optionnelle",
    "fields": [
      {
        "name": "email",
        "label": "Votre email :",
        "fieldType": "email",
        "required": true
      }
    ],
    "submitButton": {"text": "Envoyer"}
  }
}
\```

### Types de champs supportés

| Type | Description |
|------|-------------|
| `text` | Champ texte simple |
| `number` | Champ numérique |
| `email` | Champ email |
| `select` | Liste déroulante |
| `checkbox` | Case à cocher |
| `radio` | Boutons radio |
| `textarea` | Zone de texte multiligne |
| `date` | Sélecteur de date |
```

Ce skill ne contient aucun script Python. L'agent utilise directement les instructions Markdown pour générer le JSON du formulaire dans sa réponse.

### 4.3 Exemple complet — Skill_Script

Voici un exemple complet d'un Skill_Script pour la génération de graphiques :

```markdown
---
name: chart
description: "Display interactive Chart.js charts in chat OR save as PNG images."
display_name: "Génération des graphiques"
metadata:
  config:
    emoji: "📊"
    trigger_patterns:
      - chart
      - graph
      - plot
      - visualization
    requires:
      bins:
        - uv
---

## Instructions de génération de graphiques

Tu as DEUX façons de créer des graphiques :
1. **Affichage interactif** (par défaut) — Afficher dans le chat via un bloc ```chart
2. **Sauvegarde en image** — Créer un fichier PNG via le script `chart_to_image.py`

### Affichage interactif (par défaut)

Utilise un bloc de code avec l'identifiant `chart` :

\```chart
{
  "type": "chartjs",
  "chartConfig": {
    "type": "bar",
    "data": {
      "labels": ["Jan", "Fév", "Mar"],
      "datasets": [{
        "label": "Ventes",
        "data": [65, 59, 80]
      }]
    }
  }
}
\```

### Sauvegarde en image PNG

Pour sauvegarder un graphique en fichier PNG, exécute le script via shell :

\```bash
echo '{"type": "bar", "data": {...}}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill chart --filename "graphique.png"
\```

### Format de sortie (stdout JSON)

\```json
{
  "status": "success",
  "file_id": "uuid",
  "download_url": "/files/uuid/download",
  "filename": "graphique.png",
  "size_bytes": 1234,
  "mime_type": "image/png"
}
\```
```

Ce skill combine des instructions Markdown avec un script Python (`chart_to_image.py`). Le champ `requires.bins` indique que le binaire `uv` doit être disponible dans le PATH. L'agent construit la commande shell à partir des instructions, l'exécute via `ShellTool`, et parse le JSON retourné sur stdout.

---

## 5. Référence du Frontmatter YAML

Le frontmatter YAML est le bloc de métadonnées situé en tête de chaque fichier `SKILL.md`, délimité par `---`. Il est parsé par `MarkdownSkillLoader` et converti en objets `SkillFrontmatter` et `SkillConfig`.

### 5.1 Champs de premier niveau

Ces champs sont définis directement à la racine du frontmatter (dataclass `SkillFrontmatter`).

| Champ | Type | Obligatoire | Défaut | Description |
|-------|------|-------------|--------|-------------|
| `name` | `str` | ✅ Oui | — | Identifiant unique du skill. Doit respecter le pattern `[a-z0-9_-]+`. Utilisé comme clé dans le `SkillRegistry`. |
| `description` | `str` | ✅ Oui | — | Description courte du skill, affichée dans la liste des skills et dans l'API. |
| `display_name` | `str` | ❌ Non | `null` | Nom affiché dans l'interface utilisateur. Si absent, le champ `name` est utilisé. |
| `homepage` | `str` | ❌ Non | `null` | URL de la page d'accueil ou de la documentation externe du skill. |

**Exemple :**

```yaml
---
name: mon-skill
description: "Génère des rapports PDF à partir de données structurées"
display_name: "Générateur de rapports"
homepage: "https://example.com/mon-skill"
---
```

### 5.2 Champs de configuration (`metadata.config`)

Ces champs sont imbriqués sous `metadata.config` dans le YAML (dataclass `SkillConfig`).

| Champ | Type | Obligatoire | Défaut | Description |
|-------|------|-------------|--------|-------------|
| `emoji` | `str` | ❌ Non | `null` | Icône emoji affichée à côté du nom du skill dans l'interface. |
| `primaryEnv` | `str` | ❌ Non | `null` | Variable d'environnement principale requise par le skill. Sérialisé en `primaryEnv` dans le YAML (attribut Python : `primary_env`). |
| `trigger_patterns` | `list[str]` | ❌ Non | `[]` | Liste de mots-clés permettant la découverte automatique du skill par l'agent. L'agent utilise ces patterns pour suggérer le chargement du skill. |
| `entrypoint` | `str` | ❌ Non | `null` | Commande d'exécution du script pour les Skill_Script. Typiquement un appel `uv run python ...`. Non utilisé pour les Skill_Markdown. |
| `runtime` | `str` | ❌ Non | `null` | Identifiant du runtime d'exécution (ex : `python`). Permet au framework de déterminer l'environnement d'exécution. |

**Exemple :**

```yaml
metadata:
  config:
    emoji: "📊"
    primaryEnv: MY_API_KEY
    trigger_patterns:
      - graphique
      - chart
      - visualisation
    entrypoint: "uv run python {{SKILL_DIR}}/generate.py"
    runtime: python
```

### 5.3 Dépendances (`metadata.config.requires`)

Les dépendances sont déclarées sous `metadata.config.requires` et permettent au framework de vérifier la disponibilité des prérequis au chargement du skill.

| Champ | Type | Obligatoire | Défaut | Description |
|-------|------|-------------|--------|-------------|
| `requires.bins` | `list[str]` | ❌ Non | `[]` | Liste des binaires système requis dans le `PATH` (ex : `uv`, `curl`, `node`). Le framework émet un avertissement si un binaire est absent. |
| `requires.env` | `list[str]` | ❌ Non | `[]` | Liste des variables d'environnement requises (ex : `API_KEY`, `DATABASE_URL`). |

**Exemple :**

```yaml
metadata:
  config:
    requires:
      bins:
        - uv
        - curl
      env:
        - MY_API_KEY
        - MY_SECRET
```

### 5.4 Installation (`metadata.config.install`)

Le champ `install` permet de déclarer des instructions d'installation pour les dépendances du skill.

| Champ | Type | Obligatoire | Défaut | Description |
|-------|------|-------------|--------|-------------|
| `install` | `list[dict]` | ❌ Non | `[]` | Liste de dictionnaires décrivant les étapes d'installation nécessaires pour le skill. Chaque entrée peut contenir des commandes ou des instructions spécifiques à une plateforme. |

**Exemple :**

```yaml
metadata:
  config:
    install:
      - command: "uv pip install pandas"
        description: "Installer la bibliothèque pandas"
      - command: "uv pip install openpyxl"
        description: "Installer le support Excel"
```

### 5.5 Exemple complet du frontmatter

Voici un frontmatter complet utilisant tous les champs disponibles :

```yaml
---
name: data-export
description: "Exporte des données en CSV, Excel ou PDF"
display_name: "Export de données"
homepage: "https://example.com/data-export"
metadata:
  config:
    emoji: "📤"
    primaryEnv: EXPORT_API_KEY
    trigger_patterns:
      - export
      - csv
      - excel
      - données
    entrypoint: "uv run python {{SKILL_DIR}}/export.py"
    runtime: python
    requires:
      bins:
        - uv
      env:
        - EXPORT_API_KEY
    install:
      - command: "uv pip install pandas openpyxl"
        description: "Installer les dépendances d'export"
---
```

---

## 6. Méthodes de création et modification

Il existe trois façons de créer et modifier des skills dans AgentFramework : via le code source, via l'interface web, et via l'API REST.

### 6.1 Via le code (dossier `custom_skills/`)

#### Création

Pour créer un skill manuellement, ajoutez un dossier dans le répertoire `custom_skills/` à la racine de votre projet :

1. Créez un dossier portant le nom du skill. Le nom doit respecter le pattern `[a-z0-9_-]+` (lettres minuscules, chiffres, tirets et underscores uniquement).

```
custom_skills/
  mon-skill/
    SKILL.md
```

2. Créez un fichier `SKILL.md` dans ce dossier avec le frontmatter YAML et les instructions Markdown :

```markdown
---
name: mon-skill
description: "Description courte du skill"
display_name: "Mon Skill"
metadata:
  config:
    emoji: "🔧"
    trigger_patterns:
      - mot-clé1
      - mot-clé2
---

## Instructions

Contenu Markdown décrivant le comportement du skill.
```

3. Pour un **Skill_Script**, ajoutez vos scripts Python dans le même dossier et déclarez le champ `entrypoint` dans le frontmatter :

```
custom_skills/
  mon-skill/
    SKILL.md
    mon_script.py
```

Les skills placés dans `custom_skills/` sont **auto-découverts** au démarrage de l'agent par `MarkdownSkillLoader`. Aucune configuration supplémentaire n'est nécessaire.

#### Modification

Pour modifier un skill existant créé via le code :

1. Éditez directement le fichier `SKILL.md` dans le dossier du skill (frontmatter et/ou instructions).
2. Redémarrez l'agent pour que les modifications soient prises en compte. Le `MarkdownSkillLoader` re-parse les fichiers au démarrage.

### 6.2 Via l'interface web (onglet Skills)

#### Création

L'interface web d'AgentFramework propose un onglet dédié à la gestion des skills :

1. Naviguez vers l'onglet **Skills** dans l'interface web.
2. Cliquez sur le bouton **« Create Skill »**.
3. Remplissez le formulaire avec les informations du skill :
   - **name** — Identifiant unique du skill (pattern `[a-z0-9_-]+`)
   - **description** — Description courte
   - **instructions** — Instructions Markdown pour l'agent
   - **emoji** — Icône emoji (optionnel)
   - **trigger_patterns** — Mots-clés de découverte automatique (optionnel)
4. Validez le formulaire pour créer le skill.

L'interface web appelle l'API REST (`POST /api/skills`) en arrière-plan. Le skill est immédiatement enregistré dans le `SkillRegistry` et disponible pour l'agent.

#### Modification

1. Dans l'onglet **Skills**, cliquez sur le skill à modifier.
2. Éditez les champs souhaités (description, instructions, emoji, trigger patterns, etc.).
3. Sauvegardez les modifications.

L'interface appelle `PUT /api/skills/{name}` en arrière-plan. Seuls les champs modifiés sont mis à jour.

> **Note :** Les skills builtin (source `builtin`) ne peuvent pas être modifiés via l'interface web. Seuls les skills custom sont éditables.

### 6.3 Via l'API REST

#### Création

Envoyez une requête `POST /api/skills` avec un corps JSON conforme au modèle `SkillCreateRequest` :

```bash
curl -X POST http://localhost:8000/api/skills \
  -H "Content-Type: application/json" \
  -d '{
    "name": "mon-skill",
    "description": "Description du skill",
    "instructions": "## Instructions\nContenu Markdown...",
    "display_name": "Mon Skill",
    "emoji": "🔧",
    "trigger_patterns": ["mot-clé1", "mot-clé2"]
  }'
```

Les champs obligatoires sont `name`, `description` et `instructions`. Les autres champs sont optionnels. Consultez la [section 10 — API REST](#10-api-rest) pour la documentation complète des endpoints, des modèles de requête/réponse et des codes d'erreur.

#### Modification

Envoyez une requête `PUT /api/skills/{name}` avec un corps JSON conforme au modèle `SkillUpdateRequest`. Seuls les champs fournis sont mis à jour :

```bash
curl -X PUT http://localhost:8000/api/skills/mon-skill \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Nouvelle description",
    "emoji": "🚀"
  }'
```

> **Note :** Les skills builtin ne peuvent pas être modifiés via l'API REST (erreur `403`). Consultez la [section 10 — API REST](#10-api-rest) pour les détails complets.

### 6.4 Récapitulatif des méthodes

| Méthode | Création | Modification | Rechargement |
|---------|----------|--------------|--------------|
| Code (`custom_skills/`) | Créer un dossier + `SKILL.md` | Éditer le fichier `SKILL.md` | Redémarrage de l'agent requis |
| Interface web (onglet Skills) | Formulaire « Create Skill » | Cliquer, éditer, sauvegarder | Immédiat |
| API REST | `POST /api/skills` | `PUT /api/skills/{name}` | Immédiat |

---

## 7. Cycle de vie des skills

Le cycle de vie d'un skill dans AgentFramework se décompose en trois phases : la **découverte** au démarrage de l'agent, le **chargement à la demande** lors d'une requête utilisateur, et l'**exécution** du skill (pour les Skill_Script).

```
Démarrage agent          Requête utilisateur         Exécution
───────────────          ───────────────────         ─────────
Scan des dossiers        list_skills()               Lecture instructions
       ↓                        ↓                          ↓
Parse SKILL.md           load_skill(name)            Construction commande
       ↓                        ↓                          ↓
Création objets Skill    Résolution dépendances      ShellTool (shell_exec)
       ↓                        ↓                          ↓
Injection outils         LoadedSkillContext           Parse JSON stdout
       ↓
SkillRegistry.register
```

### 7.1 Phase de découverte

La découverte des skills se produit au démarrage de l'agent, lors de l'appel à `register_builtin_skills()` dans le mixin `SkillsMixin`. Cette méthode déclenche deux scans successifs :

#### Skills builtin

1. `register_builtin_skills()` appelle `get_all_builtin_skills(source="markdown")` qui scanne le dossier `agent_framework/skills/builtin/skills/`.
2. `MarkdownSkillLoader.load_from_dir()` utilise `rglob("SKILL.md")` pour trouver tous les fichiers `SKILL.md` dans l'arborescence.
3. Pour chaque fichier trouvé, `load_from_file()` est appelé :
   - Le frontmatter YAML est extrait et parsé en un objet `SkillFrontmatter`.
   - Le corps Markdown est conservé comme instructions.
   - Un objet `Skill` est créé avec un `SkillMetadata` (name, description, trigger_patterns, requires_bins, requires_env).
4. Chaque skill est enregistré dans le `SkillRegistry` avec `source="builtin"`.

#### Skills custom

Immédiatement après les builtin, `_register_custom_skills()` est appelé :

1. Le dossier `custom_skills/` est scanné (configurable via la variable d'environnement `CUSTOM_SKILLS_DIR`).
2. Pour chaque sous-dossier contenant un fichier `SKILL.md`, `MarkdownSkillLoader.load_from_file()` parse le fichier.
3. Les outils natifs sont attachés au skill :
   - `ShellTool` (timeout par défaut : 60 secondes) — permet l'exécution de commandes shell.
   - `WebFetchTool` — permet la récupération de contenu web.
4. Les dépendances système déclarées dans `requires.bins` sont vérifiées via `shutil.which()`. Un avertissement est émis si un binaire est absent du `PATH`.
5. Le skill est enregistré dans le `SkillRegistry` avec `source="custom"`.

#### Résultat de la découverte

À la fin de cette phase, le `SkillRegistry` contient tous les skills disponibles (builtin + custom). Chaque skill possède :
- Ses métadonnées (`SkillMetadata`) pour la recherche et la découverte.
- Ses instructions (texte Markdown ou chemin vers le fichier).
- Ses outils (`ShellTool`, `WebFetchTool`).
- Sa configuration (entrypoint, runtime, skill_dir).

### 7.2 Phase de chargement à la demande

Le chargement d'un skill se produit à la demande, lorsque l'agent a besoin d'une capacité spécifique pour répondre à une requête utilisateur.

#### Flux de chargement

1. **Découverte par l'agent** — L'agent appelle `list_skills()` qui retourne la liste des `SkillMetadata` via `SkillRegistry.list_all()`. Chaque entrée contient le nom, la description et les trigger patterns du skill (~50 tokens par skill).

2. **Sélection et chargement** — L'agent appelle `load_skill(name)` qui déclenche `SkillRegistry.load()` :
   - **Détection de circularité** — Le registre maintient une chaîne de chargement (`loading_chain`) pour détecter les dépendances circulaires. Si un cycle est détecté, une erreur `ValueError` est levée.
   - **Résolution des dépendances** — Les skills déclarés dans le champ `dependencies` sont chargés récursivement avant le skill principal.
   - **Chargement des instructions** — Si les instructions sont un chemin (`Path`), le contenu du fichier est lu et mis en cache. Si c'est une chaîne, elle est utilisée directement.
   - **Injection de l'entrypoint** — Si le skill définit un `entrypoint` dans sa configuration, une section `## Execution` est automatiquement ajoutée aux instructions avec la commande complète à exécuter. Le placeholder `{{SKILL_DIR}}` est résolu vers le chemin absolu du dossier du skill.

3. **Retour du contexte** — Un objet `LoadedSkillContext` est retourné, contenant :
   - `instructions` — Les instructions complètes (avec l'entrypoint injecté si applicable).
   - `tools` — La liste des outils disponibles (`ShellTool`, `WebFetchTool`).
   - `dependencies_loaded` — La liste des dépendances chargées.
   - `loaded_at` — L'horodatage du chargement.

#### Déchargement

L'agent peut décharger un skill via `unload_skill(name)`, qui retire le skill de l'ensemble des skills chargés et supprime son `LoadedSkillContext` du cache.

### 7.3 Phase d'exécution (Skill_Script)

Pour les Skill_Script, l'exécution suit un flux précis après le chargement :

```
1. Agent lit les instructions du LoadedSkillContext
   ↓
2. Agent construit la commande shell selon les instructions
   (ex : echo '{"type":"bar","data":{...}}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill chart)
   ↓
3. Agent exécute la commande via ShellTool (shell_exec)
   - Timeout configurable (60s par défaut)
   - Le script s'exécute dans le répertoire du skill (skill_dir)
   ↓
4. Le script produit un résultat JSON sur stdout :
   {"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", ...}
   ↓
5. Agent parse le JSON et présente le résultat à l'utilisateur
   - En cas de succès : lien de téléchargement, aperçu, etc.
   - En cas d'erreur : message d'erreur depuis stderr + code de sortie non-zéro
```

#### Format de sortie standard

Les scripts des Skill_Script suivent un format de sortie uniforme :

**Succès :**

```json
{
  "status": "success",
  "file_id": "uuid-du-fichier",
  "download_url": "/files/uuid/download",
  "filename": "output.png",
  "size_bytes": 12345,
  "mime_type": "image/png"
}
```

**Erreur :**

```json
{
  "status": "error",
  "message": "Description de l'erreur"
}
```

Les scripts qui créent des fichiers (graphiques, PDF, Excel, etc.) gèrent automatiquement l'enregistrement dans le système de stockage. Le champ `download_url` dans la sortie JSON fournit un lien de téléchargement direct.

#### Différence avec les Skill_Markdown

Les Skill_Markdown n'ont pas de phase d'exécution via `ShellTool`. L'agent utilise directement les instructions Markdown pour formater sa réponse (formulaires JSON, blocs d'options, affichage d'images, etc.). Il n'y a pas de script à exécuter ni de sortie JSON à parser.

### 7.4 Mécanisme `_view` (fonctionnalité prévue)

> **Note :** Ce mécanisme est prévu pour une version future du framework. Il n'est pas encore implémenté dans le code source actuel.

Le mécanisme `_view` est un concept de convention de nommage pour les skills orientés consultation de données. Le principe est le suivant :

- Un skill dont le nom se termine par `_view` (ex : `sales_view`, `inventory_view`) serait automatiquement enrichi d'un **query tool** injecté par le framework.
- Ce query tool permettrait à l'agent d'interroger une source de données associée au skill sans que le développeur ait besoin de l'implémenter manuellement.
- L'injection serait transparente : le développeur crée un skill `mon_domaine_view` et le framework détecte le suffixe `_view` pour ajouter automatiquement l'outil de requête.

Ce mécanisme vise à simplifier la création de skills de consultation en éliminant le code boilerplate lié à l'interrogation de données.

---

## 8. Skills builtin

AgentFramework inclut **13 skills builtin** prêts à l'emploi, répartis en cinq catégories. Ces skills sont enregistrés automatiquement au démarrage de l'agent depuis le dossier `agent_framework/skills/builtin/skills/`.

### 8.1 Tableau récapitulatif

| Nom | Catégorie | Type | Description | Dépendances | Trigger Patterns |
|-----|-----------|------|-------------|-------------|------------------|
| `chart` | Visualization | Skill_Script | Affiche des graphiques Chart.js interactifs ou les sauvegarde en PNG | `uv` | chart, graph, plot, visualization, bar chart, line chart, pie chart, doughnut, scatter, radar |
| `mermaid` | Visualization | Skill_Script | Affiche des diagrammes Mermaid interactifs ou les sauvegarde en PNG | `uv` | mermaid, diagram, flowchart, sequence, sequence diagram, class diagram, state diagram, er diagram, gantt, architecture |
| `table` | Visualization | Skill_Script | Affiche des tableaux interactifs ou les sauvegarde en PNG | `uv` | table, tabledata, grid, data table, spreadsheet, tabular, rows and columns |
| `excel` | Document | Skill_Script | Génère des fichiers Excel `.xlsx` avec feuilles multiples et formatage | `uv` | excel, spreadsheet, xlsx, tableau |
| `drawio` | Document | Skill_Script | Génère des fichiers `.drawio` pour diagrammes et flowcharts | `uv` | drawio, diagram, flowchart, architecture diagram, draw.io |
| `file` | Document | Skill_Script | Crée, liste et lit des fichiers depuis le stockage | `uv` | file, create file, list files, read file, save file, write file, text file, store file |
| `file_access` | Document | Skill_Script | Résout les chemins absolus de fichiers pour l'intégration dans des documents | `uv` | file path, file access, embed file, file url, embed image, image path, file reference |
| `unified_pdf` | Document | Skill_Script | Crée des documents PDF à partir de contenu HTML avec intégration automatique d'images | `uv` | pdf, document, report, create pdf, generate pdf, html to pdf, export pdf |
| `web_search` | Web | Skill_Script | Recherche sur le web et les actualités via DuckDuckGo (sans clé API) | `uv` | search, web search, news, lookup, find online, google, current events, recent news |
| `multimodal` | Multimodal | Skill_Markdown | Analyse d'images par IA (description, OCR, questions-réponses) | — | image, analyze image, describe image, ocr, text extraction, vision, picture, photo, screenshot |
| `form` | UI | Skill_Markdown | Génère des formulaires interactifs pour collecter des données structurées | — | form, input, survey, questionnaire, collect information, gather data, user input |
| `optionsblock` | UI | Skill_Markdown | Génère des boutons d'options cliquables pour l'interaction utilisateur | — | options, choices, select, buttons, yes or no, choose, pick one, confirmation |
| `image_display` | UI | Skill_Markdown | Affiche des images depuis des URLs avec téléchargement et vue plein écran | — | display image, show image, image url, render image, embed image, picture, photo |

### 8.2 Détail des Skill_Script

Chaque Skill_Script s'exécute via `ShellTool` et produit un résultat JSON sur stdout. Le format de sortie standard est décrit dans la [section 7.3 — Phase d'exécution](#73-phase-dexécution-skill_script).

#### `chart` — Génération de graphiques

Deux modes d'utilisation : affichage interactif via un bloc ` ```chart ` (par défaut) ou sauvegarde en PNG.

**Commande de sauvegarde :**

```bash
echo '{"type": "bar", "data": {"labels": [...], "datasets": [...]}, "options": {...}}' \
  | uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
    --skill chart --filename "graphique.png"
```

**Arguments :** `--filename` (obligatoire), `--output-dir` (optionnel).
**Stdin :** Objet JSON Chart.js avec les champs `type` (obligatoire) et `data` (obligatoire).

#### `mermaid` — Génération de diagrammes

Deux modes : affichage interactif via un bloc ` ```mermaid ` (par défaut) ou sauvegarde en PNG.

**Commande de sauvegarde :**

```bash
echo 'graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[OK]' \
  | uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
    --skill mermaid --filename "diagramme.png"
```

**Arguments :** `--filename` (obligatoire), `--output-dir` (optionnel), `--theme` (optionnel : `default`, `dark`, `forest`, `neutral`).
**Stdin :** Code Mermaid brut (les clôtures ` ```mermaid ` sont automatiquement retirées).

#### `table` — Génération de tableaux

Deux modes : affichage interactif via un bloc ` ```tabledata ` (par défaut) ou sauvegarde en PNG.

**Commande de sauvegarde :**

```bash
echo '{"headers": ["Nom", "Valeur"], "rows": [["A", "1"], ["B", "2"]]}' \
  | uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
    --skill table --filename "tableau.png"
```

**Arguments :** `--filename` (obligatoire), `--output-dir` (optionnel), `--theme` (optionnel : `default`, `dark`, `blue`, `green`, `minimal`), `--font-size` (optionnel).
**Stdin :** Objet JSON avec `headers` (obligatoire) et `rows` (obligatoire).

#### `excel` — Génération de fichiers Excel

**Commande :**

```bash
echo '[{"name": "Feuille1", "headers": ["Col1", "Col2"], "rows": [["a", "b"]], "bold_header": true}]' \
  | uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
    --skill excel --filename "rapport.xlsx"
```

**Arguments :** `--filename` (obligatoire), `--output-dir` (optionnel).
**Stdin :** Tableau JSON de définitions de feuilles, chacune avec `name`, `headers`, `rows`, `bold_header` (tous optionnels sauf au moins une feuille).

#### `drawio` — Génération de diagrammes Draw.io

**Commande :**

```bash
uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
  --skill drawio --filename "architecture.drawio" --xml "<mxfile>...</mxfile>"
```

Ou via stdin :

```bash
echo '<mxfile>...</mxfile>' \
  | uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
    --skill drawio --filename "architecture.drawio"
```

**Arguments :** `--filename` (obligatoire), `--xml` (optionnel, sinon lu depuis stdin), `--output-dir` (optionnel).

#### `file` — Gestion de fichiers

Ce skill expose trois scripts distincts :

**Créer un fichier :**

```bash
uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
  --skill file --filename "rapport.txt" --content "Contenu du fichier"
```

**Lister les fichiers d'un répertoire :**

```bash
uv run python -m agent_framework.skills.builtin.skills.file.list_files \
  --directory "/chemin/vers/dossier"
```

**Lire un fichier :**

```bash
uv run python -m agent_framework.skills.builtin.skills.file.read_file \
  --path "/chemin/vers/fichier.txt"
```

#### `file_access` — Accès aux fichiers

Résout le chemin absolu d'un fichier existant.

**Commande :**

```bash
uv run python -m agent_framework.skills.builtin.skills.file_access.get_file_path \
  --filename "chart.png" --directory "/tmp/output"
```

**Arguments :** `--filename` (obligatoire), `--directory` (optionnel).
**Sortie :** `{"status": "success", "file": "/chemin/absolu/chart.png"}`

#### `unified_pdf` — Génération de PDF

Crée un PDF A4 à partir de contenu HTML via Playwright + Chromium.

**Commande :**

```bash
echo '<h1>Titre</h1><p>Contenu HTML...</p>' \
  | uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
    --skill unified_pdf --filename "document.pdf"
```

**Arguments :** `--filename` (obligatoire), `--output-dir` (optionnel).
**Stdin :** Contenu HTML (fragment ou document complet).

#### `web_search` — Recherche web et actualités

Ce skill expose deux scripts :

**Recherche web :**

```bash
uv run python -m agent_framework.skills.builtin.skills.web_search.web_search \
  --query "Python async best practices" --max-results 5
```

**Recherche actualités :**

```bash
uv run python -m agent_framework.skills.builtin.skills.web_search.web_news_search \
  --query "intelligence artificielle" --max-results 5
```

**Arguments communs :** `--query` (obligatoire), `--max-results` (optionnel, défaut 5, max 10).

### 8.3 Skills Skill_Markdown

Les skills de type Skill_Markdown (`multimodal`, `form`, `optionsblock`, `image_display`) n'ont pas de script associé. L'agent utilise directement les instructions du fichier `SKILL.md` pour formater ses réponses (JSON de formulaire, blocs d'options, affichage d'images, etc.). Il n'y a pas de commande shell à exécuter ni de sortie JSON à parser — voir la [section 7.3](#73-phase-dexécution-skill_script) pour la distinction avec les Skill_Script.

---

## 9. Suppression du système legacy

> 🗑️ **SUPPRIMÉ (v0.8.1)** — Le système de skills basé sur `source="python"`, les sous-classes `AgentTool` et les fonctions factory `create_*_skill()` a été **entièrement supprimé** du framework. Les skills fonctionnent désormais exclusivement via les fichiers `SKILL.md` (Skill_Markdown ou Skill_Script).

### 9.1 Qu'est-ce qui a été supprimé ?

L'ancien système de skills Python, déprécié en v0.7.0, a été complètement retiré en v0.8.1. Les éléments suivants n'existent plus dans le framework :

- **Fichiers Python skill** — Les 15 fichiers `*_skill.py` dans `agent_framework/skills/builtin/` (chart_skill.py, excel_skill.py, file_skill.py, mermaid_skill.py, table_skill.py, unified_pdf_skill.py, pdf_skill.py, pdf_with_images_skill.py, drawio_skill.py, web_search_skill.py, file_access_skill.py, form_skill.py, optionsblock_skill.py, image_display_skill.py, multimodal_skill.py) et leurs fonctions factory `create_*_skill()` ont été supprimés.

- **Classes AgentTool wrapper** — Les 11 fichiers de classes wrapper dans `agent_framework/tools/` (chart_tools.py, excel_tools.py, file_tools.py, mermaid_tools.py, tabledata_tools.py, unified_pdf_tool.py, pdf_tools.py, pdf_with_images_tool.py, drawio_tools.py, web_search_tools.py, file_access_tools.py) et leurs classes (ChartToImageTool, CreateExcelTool, CreateFileTool, ListFilesTool, ReadFileTool, MermaidToImageTool, TableToImageTool, CreateUnifiedPDFTool, CreatePDFFromMarkdownTool, CreatePDFFromHTMLTool, CreatePDFWithImagesTool, CreateDrawioTool, GetFilePathTool, WebSearchTool, WebNewsSearchTool) ont été supprimés.

- **Paramètre `source`** — Le paramètre `source` a été retiré de `get_all_builtin_skills()` et `register_builtin_skills()`. Ces fonctions chargent désormais uniquement les skills markdown, sans option de sélection de source.

- **Méthodes SkillsMixin** — Les méthodes `get_all_registered_skill_tools()` et `configure_skill_tools_context()` ont été supprimées de `SkillsMixin`, ainsi que l'attribut `_skill_tool_instances`. Ces méthodes servaient à collecter et configurer les instances `AgentTool` pour LlamaIndex.

### 9.2 Pourquoi cette suppression ?

Le système Markdown + Script, introduit en v0.7.0, a entièrement remplacé le système legacy :

- **Simplicité** — Un fichier `SKILL.md` avec du YAML et du Markdown suffit à définir un skill complet, sans écrire de classe Python.
- **Découplage** — Les scripts des Skill_Script sont des programmes Python autonomes, exécutés via `ShellTool`, sans dépendance directe au framework.
- **Uniformité** — Tous les skills (builtin et custom) utilisent le même format `SKILL.md`, facilitant la maintenance et la compréhension.
- **Accessibilité** — Les développeurs peuvent créer des skills sans connaître l'architecture interne du framework.

### 9.3 Impact sur le code existant

Si votre code utilisait l'ancien système, voici les changements nécessaires :

| Ancien code (supprimé) | Remplacement |
|------------------------|--------------|
| `get_all_builtin_skills(source="python")` | `get_all_builtin_skills()` (markdown uniquement) |
| `register_builtin_skills(source="python")` | `register_builtin_skills()` (markdown uniquement) |
| `get_all_registered_skill_tools()` | Supprimé — les skills markdown n'utilisent pas d'instances `AgentTool` |
| `configure_skill_tools_context(...)` | Supprimé — les scripts autonomes gèrent leur propre contexte |
| `from agent_framework.tools import ChartToImageTool, ...` | Supprimé — utiliser les skills markdown correspondants |
| `from agent_framework.skills.builtin.chart_skill import create_chart_skill` | Supprimé — le skill `chart` est chargé automatiquement depuis `SKILL.md` |

### 9.4 Migration

Si vous utilisiez déjà `source="markdown"` (défaut depuis v0.7.0), aucune action n'est requise.

Si vous utilisiez `source="python"` ou les classes `AgentTool` directement, migrez vers le système Markdown + Script :

- **Skill_Markdown** — Pour les skills qui fournissent uniquement des instructions textuelles à l'agent (formulaires, affichage, analyse). Créez un fichier `SKILL.md` avec un frontmatter YAML et des instructions Markdown. Voir la [section 3.1](#31-skill_markdown) et l'[exemple complet en section 4.2](#42-exemple-complet--skill_markdown).

- **Skill_Script** — Pour les skills qui exécutent du code (génération de fichiers, appels API, traitement de données). Créez un fichier `SKILL.md` avec un frontmatter YAML (incluant `entrypoint`) et placez vos scripts Python autonomes dans le même dossier. Voir la [section 3.2](#32-skill_script) et l'[exemple complet en section 4.3](#43-exemple-complet--skill_script).

---

## 10. API REST

AgentFramework expose une API REST complète pour la gestion des skills via le routeur FastAPI défini dans `agent_framework/web/skills_router.py`. Tous les endpoints sont préfixés par `/api/skills`.

### 10.1 Vue d'ensemble des endpoints

| Méthode | Endpoint | Description | Code succès |
|---------|----------|-------------|-------------|
| `GET` | `/api/skills` | Liste tous les skills (builtin + custom) | 200 |
| `GET` | `/api/skills/{name}` | Détail d'un skill (instructions, fichiers) | 200 |
| `POST` | `/api/skills` | Crée un nouveau custom skill | 201 |
| `POST` | `/api/skills/validate` | Valide le contenu d'un skill | 200 |
| `PUT` | `/api/skills/{name}` | Met à jour un custom skill | 200 |
| `DELETE` | `/api/skills/{name}` | Supprime un custom skill | 200 |
| `GET` | `/api/skills/{name}/files/{filename}` | Télécharge un fichier du dossier du skill | 200 |
| `POST` | `/api/skills/{name}/files` | Upload un fichier dans le dossier du skill | 201 |
| `DELETE` | `/api/skills/{name}/files/{filename}` | Supprime un fichier du dossier du skill | 200 |

### 10.2 Modèles de requête

#### SkillCreateRequest (POST /api/skills)

| Champ | Type | Obligatoire | Description |
|-------|------|-------------|-------------|
| `name` | `string` | ✅ Oui | Identifiant unique. Pattern : `^[a-z0-9_-]+$` |
| `description` | `string` | ✅ Oui | Description courte du skill |
| `instructions` | `string` | ✅ Oui | Instructions Markdown pour l'agent |
| `display_name` | `string` | ❌ Non | Nom affiché dans l'interface |
| `emoji` | `string` | ❌ Non | Icône emoji |
| `trigger_patterns` | `list[string]` | ❌ Non | Mots-clés de découverte automatique (défaut : `[]`) |
| `entrypoint` | `string` | ❌ Non | Commande d'exécution pour les Skill_Script |
| `runtime` | `string` | ❌ Non | Identifiant du runtime (ex : `python`) |
| `requires_bins` | `list[string]` | ❌ Non | Binaires système requis (défaut : `[]`) |
| `requires_env` | `list[string]` | ❌ Non | Variables d'environnement requises (défaut : `[]`) |

#### SkillUpdateRequest (PUT /api/skills/{name})

Tous les champs sont optionnels. Seuls les champs fournis sont mis à jour.

| Champ | Type | Description |
|-------|------|-------------|
| `description` | `string` | Nouvelle description |
| `instructions` | `string` | Nouvelles instructions Markdown |
| `display_name` | `string` | Nouveau nom affiché |
| `emoji` | `string` | Nouvel emoji |
| `trigger_patterns` | `list[string]` | Nouveaux mots-clés |
| `entrypoint` | `string` | Nouvelle commande d'exécution |
| `runtime` | `string` | Nouveau runtime |
| `requires_bins` | `list[string]` | Nouveaux binaires requis |
| `requires_env` | `list[string]` | Nouvelles variables d'environnement |

#### SkillValidateRequest (POST /api/skills/validate)

| Champ | Type | Obligatoire | Description |
|-------|------|-------------|-------------|
| `name` | `string` | ✅ Oui | Nom du skill à valider |
| `description` | `string` | ✅ Oui | Description à valider |
| `instructions` | `string` | ✅ Oui | Instructions à valider |

### 10.3 Modèles de réponse

#### SkillResponse

Modèle retourné pour un skill individuel (GET détail, POST création, PUT modification).

```json
{
  "name": "mon-skill",
  "description": "Description du skill",
  "display_name": "Mon Skill",
  "emoji": "🔧",
  "source": "custom",
  "trigger_patterns": ["mot-clé1", "mot-clé2"],
  "entrypoint": "uv run python /path/to/script.py",
  "runtime": "python",
  "requires_bins": ["uv"],
  "requires_env": ["API_KEY"],
  "instructions": "## Instructions\nContenu Markdown...",
  "files": ["script.py", "config.json"]
}
```

Les champs `instructions` et `files` sont inclus uniquement dans la réponse de `GET /api/skills/{name}`. Le champ `source` vaut `"builtin"` ou `"custom"`.

#### SkillListResponse

Modèle retourné par `GET /api/skills`.

```json
{
  "skills": [
    {
      "name": "chart",
      "description": "Display interactive Chart.js charts...",
      "display_name": "Génération des graphiques",
      "emoji": "📊",
      "source": "builtin",
      "trigger_patterns": ["chart", "graph", "plot"],
      "entrypoint": null,
      "runtime": null,
      "requires_bins": ["uv"],
      "requires_env": []
    }
  ]
}
```

#### SkillValidationReport

Modèle retourné par `POST /api/skills/validate`.

```json
{
  "score": 85,
  "suggestions": [
    "Consider adding sections (##), steps, examples, or usage instructions."
  ],
  "warnings": []
}
```

Le champ `score` est un entier entre 0 et 100. Les champs `suggestions` et `warnings` sont des listes de chaînes décrivant les améliorations possibles et les problèmes détectés.

### 10.4 Codes d'erreur

| Code HTTP | Exception source | Signification |
|-----------|-----------------|---------------|
| 400 | `PathTraversalError` | Nom de fichier invalide (tentative de traversée de répertoire) ou tentative d'accès direct au fichier `SKILL.md` via les endpoints fichiers |
| 403 | `BuiltinSkillError` | Tentative de modification ou suppression d'un skill builtin. Seuls les skills custom peuvent être modifiés ou supprimés |
| 404 | `SkillNotFoundError` | Le skill ou le fichier demandé n'existe pas |
| 409 | `SkillConflictError` | Un skill avec ce nom existe déjà (lors de la création) |
| 422 | `InvalidSkillNameError` / `CustomSkillError` | Le nom du skill ne respecte pas le pattern `^[a-z0-9_-]+$` ou les données du skill sont invalides |

Format de réponse d'erreur :

```json
{
  "detail": "Skill 'mon-skill' not found"
}
```

### 10.5 Endpoints — Détail et exemples

#### GET /api/skills — Lister tous les skills

Retourne la liste de tous les skills enregistrés (builtin et custom) avec leurs métadonnées.

```bash
curl -X GET http://localhost:8000/api/skills
```

Réponse `200 OK` :

```json
{
  "skills": [
    {
      "name": "chart",
      "description": "Display interactive Chart.js charts in chat OR save as PNG images.",
      "display_name": "Génération des graphiques",
      "emoji": "📊",
      "source": "builtin",
      "trigger_patterns": ["chart", "graph", "plot", "visualization"],
      "entrypoint": null,
      "runtime": null,
      "requires_bins": ["uv"],
      "requires_env": []
    },
    {
      "name": "mon-skill",
      "description": "Mon skill personnalisé",
      "display_name": "Mon Skill",
      "emoji": "🔧",
      "source": "custom",
      "trigger_patterns": ["mot-clé1"],
      "entrypoint": null,
      "runtime": null,
      "requires_bins": [],
      "requires_env": []
    }
  ]
}
```

#### GET /api/skills/{name} — Détail d'un skill

Retourne les informations complètes d'un skill, incluant ses instructions et la liste de ses fichiers.

```bash
curl -X GET http://localhost:8000/api/skills/mon-skill
```

Réponse `200 OK` :

```json
{
  "name": "mon-skill",
  "description": "Mon skill personnalisé",
  "display_name": "Mon Skill",
  "emoji": "🔧",
  "source": "custom",
  "trigger_patterns": ["mot-clé1"],
  "entrypoint": null,
  "runtime": null,
  "requires_bins": [],
  "requires_env": [],
  "instructions": "## Instructions\nContenu Markdown du skill...",
  "files": ["script.py"]
}
```

Réponse `404 Not Found` (skill inexistant) :

```json
{
  "detail": "Skill 'inexistant' not found"
}
```

#### POST /api/skills — Créer un skill

Crée un nouveau custom skill. Les champs `name`, `description` et `instructions` sont obligatoires.

```bash
curl -X POST http://localhost:8000/api/skills \
  -H "Content-Type: application/json" \
  -d '{
    "name": "mon-skill",
    "description": "Description du skill",
    "instructions": "## Instructions\nContenu Markdown...",
    "display_name": "Mon Skill",
    "emoji": "🔧",
    "trigger_patterns": ["mot-clé1", "mot-clé2"]
  }'
```

Réponse `201 Created` :

```json
{
  "name": "mon-skill",
  "description": "Description du skill",
  "display_name": "Mon Skill",
  "emoji": "🔧",
  "source": "custom",
  "trigger_patterns": ["mot-clé1", "mot-clé2"],
  "entrypoint": null,
  "runtime": null,
  "requires_bins": [],
  "requires_env": []
}
```

Réponse `409 Conflict` (nom déjà existant) :

```json
{
  "detail": "Skill 'mon-skill' already exists"
}
```

Réponse `422 Unprocessable Entity` (nom invalide) :

```json
{
  "detail": "Invalid skill name 'Mon Skill!'. Must match pattern ^[a-z0-9_-]+$"
}
```

#### POST /api/skills/validate — Valider un skill

Valide le contenu d'un skill et retourne un rapport de qualité avec un score, des suggestions et des avertissements.

```bash
curl -X POST http://localhost:8000/api/skills/validate \
  -H "Content-Type: application/json" \
  -d '{
    "name": "mon-skill",
    "description": "Description du skill",
    "instructions": "## Instructions\n\nÉtape 1 : Faire ceci.\n\n### Exemple\n\nVoici un exemple d usage."
  }'
```

Réponse `200 OK` :

```json
{
  "score": 100,
  "suggestions": [],
  "warnings": []
}
```

Exemple avec un contenu trop court :

```bash
curl -X POST http://localhost:8000/api/skills/validate \
  -H "Content-Type: application/json" \
  -d '{
    "name": "test",
    "description": "Test",
    "instructions": "Courtes instructions."
  }'
```

Réponse `200 OK` :

```json
{
  "score": 65,
  "suggestions": [
    "Instructions are very short — consider adding more detail.",
    "Consider adding sections (##), steps, examples, or usage instructions."
  ],
  "warnings": []
}
```

#### PUT /api/skills/{name} — Modifier un skill

Met à jour un custom skill existant. Seuls les champs fournis dans le corps de la requête sont modifiés.

```bash
curl -X PUT http://localhost:8000/api/skills/mon-skill \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Nouvelle description",
    "emoji": "🚀"
  }'
```

Réponse `200 OK` :

```json
{
  "name": "mon-skill",
  "description": "Nouvelle description",
  "display_name": "Mon Skill",
  "emoji": "🚀",
  "source": "custom",
  "trigger_patterns": ["mot-clé1", "mot-clé2"],
  "entrypoint": null,
  "runtime": null,
  "requires_bins": [],
  "requires_env": []
}
```

Réponse `403 Forbidden` (skill builtin) :

```json
{
  "detail": "Cannot modify builtin skill 'chart'"
}
```

Réponse `404 Not Found` (skill inexistant) :

```json
{
  "detail": "Skill 'inexistant' not found"
}
```

#### DELETE /api/skills/{name} — Supprimer un skill

Supprime un custom skill et son dossier sur le disque.

```bash
curl -X DELETE http://localhost:8000/api/skills/mon-skill
```

Réponse `200 OK` :

```json
{
  "status": "deleted",
  "name": "mon-skill"
}
```

Réponse `403 Forbidden` (skill builtin) :

```json
{
  "detail": "Cannot delete builtin skill 'chart'"
}
```

Réponse `404 Not Found` (skill inexistant) :

```json
{
  "detail": "Skill 'inexistant' not found"
}
```

#### GET /api/skills/{name}/files/{filename} — Télécharger un fichier

Télécharge un fichier depuis le dossier d'un skill. Le fichier `SKILL.md` n'est pas accessible via cet endpoint (utiliser `GET /api/skills/{name}` pour obtenir les instructions).

```bash
curl -X GET http://localhost:8000/api/skills/mon-skill/files/script.py \
  --output script.py
```

Réponse `200 OK` : le contenu binaire du fichier avec le `Content-Type` approprié.

Réponse `400 Bad Request` (fichier SKILL.md ou traversée de répertoire) :

```json
{
  "detail": "SKILL.md is managed via the skill metadata endpoints."
}
```

Réponse `403 Forbidden` (skill builtin) :

```json
{
  "detail": "Cannot access files of builtin skill 'chart'"
}
```

Réponse `404 Not Found` (skill ou fichier inexistant) :

```json
{
  "detail": "File 'script.py' not found in skill 'mon-skill'"
}
```

#### POST /api/skills/{name}/files — Uploader un fichier

Upload un fichier dans le dossier d'un custom skill. Le fichier est envoyé en `multipart/form-data`. Le fichier `SKILL.md` ne peut pas être uploadé via cet endpoint.

```bash
curl -X POST http://localhost:8000/api/skills/mon-skill/files \
  -F "file=@script.py"
```

Réponse `201 Created` :

```json
{
  "status": "uploaded",
  "filename": "script.py"
}
```

Réponse `400 Bad Request` (fichier SKILL.md ou traversée de répertoire) :

```json
{
  "detail": "SKILL.md is managed via the skill metadata endpoints."
}
```

Réponse `403 Forbidden` (skill builtin) :

```json
{
  "detail": "Cannot modify files of builtin skill 'chart'."
}
```

Réponse `404 Not Found` (skill inexistant) :

```json
{
  "detail": "Skill 'mon-skill' not found"
}
```

#### DELETE /api/skills/{name}/files/{filename} — Supprimer un fichier

Supprime un fichier du dossier d'un custom skill. Le fichier `SKILL.md` ne peut pas être supprimé via cet endpoint.

```bash
curl -X DELETE http://localhost:8000/api/skills/mon-skill/files/script.py
```

Réponse `200 OK` :

```json
{
  "status": "deleted",
  "filename": "script.py"
}
```

Réponse `400 Bad Request` (fichier SKILL.md ou traversée de répertoire) :

```json
{
  "detail": "SKILL.md is managed via the skill metadata endpoints."
}
```

Réponse `403 Forbidden` (skill builtin) :

```json
{
  "detail": "Cannot modify files of builtin skill 'chart'."
}
```

Réponse `404 Not Found` (skill ou fichier inexistant) :

```json
{
  "detail": "Skill 'mon-skill' not found"
}
```
