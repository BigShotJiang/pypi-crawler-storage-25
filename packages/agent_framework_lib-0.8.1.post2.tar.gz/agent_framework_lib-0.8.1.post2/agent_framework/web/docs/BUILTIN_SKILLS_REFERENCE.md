# Skills Builtin — Référence Complète

Ce document présente les **21 skills natives** de l'AgentFramework, organisées par catégorie fonctionnelle.

---

## Vue d'ensemble

Le système de skills permet de charger des capacités à la demande, réduisant la consommation de tokens de ~80% par rapport à un chargement global de toutes les instructions.

**Total de skills builtin** : **21 skills**
- **Skill_Markdown** : 10 skills (instructions pures, pas d'exécution)
- **Skill_Script** : 11 skills (exécution de scripts Python)

**Répartition par catégorie** :
- Visualization : 3 skills
- Document : 7 skills
- Web : 1 skill
- Multimodal : 2 skills
- UI : 5 skills
- Data : 2 skills
- Code : 1 skill

---

## Table récapitulative

| Skill | Type | Catégorie | Description | Nouveauté v0.9.0 |
|-------|------|-----------|-------------|------------------|
| **chart** | Script | Visualization | Génération de graphiques Chart.js (bar, line, pie, etc.) ou export PNG | |
| **mermaid** | Script | Visualization | Diagrammes Mermaid (flowchart, sequence, etc.) ou export PNG | |
| **table** | Script | Visualization | Tables formatées ou export PNG | |
| **file** | Script | Document | Création, lecture, liste de fichiers | |
| **unified_pdf** | Script | Document | Génération de PDF depuis HTML avec images embarquées | |
| **file_access** | Script | Document | Accès aux fichiers stockés (download URL) | |
| **excel** | Script | Document | Génération de fichiers Excel (.xlsx) multi-feuilles | |
| **drawio** | Script | Document | Génération de diagrammes Draw.io (.drawio) | |
| **powerpoint** | Script | Document | Génération de présentations PowerPoint (.pptx) | ✅ |
| **word** | Script | Document | Génération de documents Word (.docx) | ✅ |
| **web_search** | Script | Web | Recherche web (DuckDuckGo) et actualités | |
| **multimodal** | Markdown | Multimodal | Instructions pour traitement multimodal (images, audio) | |
| **image_gen** | Script | Multimodal | Génération d'images IA (DALL-E 3 et DALL-E 2) | ✅ |
| **form** | Markdown | UI | Génération de formulaires interactifs (formDefinition JSON) | |
| **optionsblock** | Markdown | UI | Boutons d'options cliquables | |
| **image_display** | Markdown | UI | Affichage d'images dans le chat | |
| **email_template** | Markdown | UI | Templates d'emails HTML responsive | ✅ |
| **skill_creator** | Markdown | UI | Guide de création de skills custom | ✅ |
| **csv** | Script | Data | Manipulation CSV (create, read, transform) | ✅ |
| **data_format** | Script | Data | Conversion JSON ↔ YAML, validation schemas | ✅ |
| **code_format** | Script | Code | Formatage de code (Python, JS, JSON, YAML) | ✅ |

---

## Catégorie : Visualization (3 skills)

### chart — Graphiques Chart.js

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `chart_to_image.py`
**Trigger patterns** : chart, graph, plot, visualization, bar chart, line chart, pie chart

**Description** : Génération de graphiques interactifs Chart.js affichés directement dans le chat, ou export en PNG pour intégration dans des documents.

**Formats supportés** :
- Bar charts (vertical/horizontal)
- Line charts
- Pie charts / Doughnut charts
- Radar charts
- Scatter plots
- Bubble charts

**Modes d'utilisation** :
1. **Affichage interactif** (défaut) : Code block ` ```chart ` avec JSON Chart.js
2. **Export PNG** : Script via `chart_to_image.py` pour génération de fichier image

**Use cases** : Visualisation de données analytiques, rapports de performance, dashboards, présentations

---

### mermaid — Diagrammes Mermaid

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `mermaid_to_image.py`
**Trigger patterns** : mermaid, diagram, flowchart, sequence diagram, class diagram

**Description** : Génération de diagrammes techniques (flowcharts, sequence diagrams, class diagrams, etc.) via syntaxe Mermaid 10.x.

**Types de diagrammes** :
- Flowcharts (flux de processus)
- Sequence diagrams (interactions entre composants)
- Class diagrams (architecture UML)
- State diagrams (machines à états)
- Entity Relationship diagrams (modèles de données)
- Gantt charts (planification de projet)
- Pie charts, User Journey, etc.

**Modes d'utilisation** :
1. **Affichage interactif** : Code block ` ```mermaid ` avec syntaxe Mermaid
2. **Export PNG** : Script via `mermaid_to_image.py`

**Use cases** : Documentation technique, architecture software, processus métier, workflows

---

### table — Tables formatées

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `table_to_image.py`
**Trigger patterns** : table, data table, tabular data

**Description** : Affichage de tables de données formatées dans le chat ou export PNG.

**Fonctionnalités** :
- Headers personnalisables
- Formatage des colonnes (alignment, width)
- Support de grandes tables avec scroll
- Export PNG pour intégration dans documents

**Use cases** : Rapports de données, comparaisons, listes structurées

---

## Catégorie : Document (7 skills)

### file — Gestion de fichiers

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `create_file.py`, `read_file.py`, `list_files.py`
**Trigger patterns** : file, create file, read file, list files

**Description** : Opérations CRUD sur fichiers (création, lecture, listage).

**Opérations** :
- `create_file.py` : Créer un fichier texte
- `read_file.py` : Lire le contenu d'un fichier
- `list_files.py` : Lister les fichiers disponibles

**Use cases** : Manipulation de fichiers de configuration, logs, exports de données

---

### unified_pdf — Génération de PDF

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `create_pdf.py`
**Trigger patterns** : pdf, document, report, create pdf, generate pdf

**Description** : Génération de PDF depuis HTML avec support complet des images (data URIs et URLs).

**Fonctionnalités** :
- Rendering via Playwright (Chromium headless)
- Support HTML complet (tags, styles, images)
- Images embarquées automatiquement
- Format A4 par défaut
- CSS personnalisable

**Use cases** : Rapports, factures, documents officiels, exports de contenu web

---

### file_access — Accès aux fichiers

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `get_file_path.py`
**Trigger patterns** : file access, download, get file

**Description** : Récupération de l'URL de téléchargement pour fichiers stockés.

**Use cases** : Partage de fichiers générés, download de documents

---

### excel — Fichiers Excel

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `create_excel.py`
**Dépendance** : `openpyxl>=3.1.5`
**Trigger patterns** : excel, spreadsheet, xlsx, tableau

**Description** : Génération de fichiers Excel (.xlsx) avec multiple feuilles, formatage, et formules.

**Fonctionnalités** :
- Multiple sheets avec noms personnalisés
- Headers en gras
- Formatage de cellules
- Formules Excel

**Use cases** : Exports de données, rapports financiers, budgets, inventaires

---

### drawio — Diagrammes Draw.io

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `create_drawio.py`
**Dépendance** : `drawpyo>=0.2.5`
**Trigger patterns** : drawio, diagram, architecture diagram

**Description** : Génération de diagrammes Draw.io (.drawio) pour architectures techniques.

**Use cases** : Diagrammes d'infrastructure, architectures cloud, network diagrams

---

### powerpoint — Présentations PowerPoint ✨ v0.9.0

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `create_powerpoint.py`
**Dépendance** : `python-pptx>=1.0.0`
**Trigger patterns** : powerpoint, pptx, presentation, slides, slideshow

**Description** : Génération de présentations PowerPoint (.pptx) professionnelles avec 5 layouts, images, tables, et thèmes de couleur.

**Layouts disponibles** :
- `title` : Slide de couverture
- `content` : Titre + contenu (listes, texte)
- `two_column` : Deux colonnes côte à côte
- `picture` : Image pleine page avec légende
- `blank` : Slide vierge

**Thèmes** : default, blue, green, red, corporate

**Use cases** : Présentations d'affaires, pitchs, formations, webinaires

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

### word — Documents Word ✨ v0.9.0

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `create_word.py`
**Dépendance** : `python-docx>=1.1.0`
**Trigger patterns** : word, docx, document, create document

**Description** : Génération de documents Word (.docx) avec formatage complet, images, tableaux, et mise en page.

**Section types** :
- `heading` : 9 niveaux (H1-H9)
- `paragraph` : Texte avec formatage (bold, italic, underline, couleur, police)
- `list` : Listes numérotées ou à puces
- `table` : Tableaux avec styles
- `image` : Images embarquées avec légendes
- `page_break` : Séparateurs de pages

**Mise en page** : Marges, orientation (portrait/landscape), taille de page (A4, Letter, Legal)

**Use cases** : Rapports, contrats, factures, documentation technique, meeting minutes

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

## Catégorie : Web (1 skill)

### web_search — Recherche web

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `web_search.py`, `web_news_search.py`
**Dépendance** : `ddgs>=9.9.3`
**Trigger patterns** : web search, search, google, duckduckgo, news search

**Description** : Recherche web via DuckDuckGo (gratuit, sans API key) pour obtenir des informations à jour.

**Fonctionnalités** :
- Recherche générale : `web_search.py`
- Recherche d'actualités : `web_news_search.py`
- Aucune clé API requise
- Résultats en temps réel

**Use cases** : Recherche d'informations actuelles, actualités, veille technologique

---

## Catégorie : Multimodal (2 skills)

### multimodal — Traitement multimodal

**Type** : Skill_Markdown
**Fichiers** : `SKILL.md`
**Trigger patterns** : image, audio, video, multimodal, image analysis

**Description** : Instructions pour l'agent sur le traitement de contenus multimodaux (images, audio, vidéo).

**Capacités** :
- Analyse d'images (description, OCR, détection d'objets)
- Traitement d'audio (transcription, analyse)
- Instructions pour génération de contenu multimodal

**Use cases** : Analyse d'images, transcription audio, description de contenus visuels

---

### image_gen — Génération d'images IA ✨ v0.9.0

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `generate_image.py`
**Dépendance** : `openai` (déjà présent)
**Variable d'environnement** : `OPENAI_API_KEY`
**Trigger patterns** : generate image, create image, draw, illustration, ai image, dall-e

**Description** : Génération d'images via DALL-E 3 (qualité maximale) et DALL-E 2 (rapide et économique).

**DALL-E 3** (recommandé) :
- Tailles : 1024x1024, 1024x1792 (portrait), 1792x1024 (landscape)
- Qualité : standard ou hd
- Style : vivid (vibrant) ou natural (sobre)
- Prompts jusqu'à 4000 caractères

**DALL-E 2** (alternatif) :
- Tailles : 256x256, 512x512, 1024x1024
- Génération multiple (1-10 images)
- Prompts jusqu'à 1000 caractères

**Use cases** : Illustrations, mockups, concept art, contenu social media, bannières web

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

## Catégorie : UI (5 skills)

### form — Formulaires interactifs

**Type** : Skill_Markdown
**Fichiers** : `SKILL.md`
**Trigger patterns** : form, input, formulaire, survey

**Description** : Instructions pour générer des formulaires interactifs dans le chat (formDefinition JSON).

**Types de champs** :
- Text input, textarea, email, number
- Select dropdown, radio buttons, checkboxes
- Date picker, file upload

**Use cases** : Collecte de données, enquêtes, configuration, onboarding

---

### optionsblock — Boutons d'options

**Type** : Skill_Markdown
**Fichiers** : `SKILL.md`
**Trigger patterns** : options, buttons, choice, menu

**Description** : Génération de boutons cliquables pour choix multiples.

**Use cases** : Navigation, menus, quiz, sélection rapide

---

### image_display — Affichage d'images

**Type** : Skill_Markdown
**Fichiers** : `SKILL.md`
**Trigger patterns** : display image, show image, image

**Description** : Instructions pour afficher des images dans le chat.

**Use cases** : Affichage de graphiques générés, photos, diagrammes

---

### email_template — Templates d'emails ✨ v0.9.0

**Type** : Skill_Markdown
**Fichiers** : `SKILL.md`
**Trigger patterns** : email, mail template, email template, compose email

**Description** : Guide pour générer des templates d'emails HTML responsive avec substitution de variables.

**Types de templates** :
- Transactional (confirmations, reset password)
- Newsletter (marketing, annonces)
- Notification (alertes, reminders)
- Plain-text (emails simples)

**Fonctionnalités** :
- Variables `{{name}}`, `{{email}}`, `{{date}}`, etc.
- Layouts responsive (desktop/mobile)
- Styles inline (compatibilité clients email)

**Use cases** : Emails transactionnels, newsletters, notifications, onboarding

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

### skill_creator — Création de skills ✨ v0.9.0

**Type** : Skill_Markdown
**Fichiers** : `SKILL.md` (~500 lignes)
**Trigger patterns** : create skill, new skill, skill generator, make skill

**Description** : Guide complet pour créer des custom skills via API, UI, ou code manuel.

**Workflows couverts** :
1. **Via API** : `POST /api/skills/validate` → `POST /api/skills`
2. **Via UI** : Interface web Skills tab
3. **Via code** : Création manuelle dans `custom_skills/{skill-name}/SKILL.md`

**Contenu** :
- Référence complète du frontmatter YAML
- Patterns Skill_Markdown vs Skill_Script
- Format de sortie standardisé (stdout/stderr JSON)
- Exemples concrets

**Use cases** : Auto-amélioration du framework, documentation développeurs, création rapide de skills custom

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

## Catégorie : Data (2 skills)

### csv — Manipulation CSV ✨ v0.9.0

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `create_csv.py`, `read_csv.py`, `transform_csv.py`
**Trigger patterns** : csv, comma separated, data export, spreadsheet data

**Description** : Manipulation complète de fichiers CSV avec 3 opérations.

**Opérations** :
1. **Create** : JSON → CSV (délimiteurs, encodages personnalisés)
2. **Read** : CSV → JSON (skip rows, max rows)
3. **Transform** : Filtrer, trier, sélectionner colonnes, limiter résultats

**Filtres disponibles** : `==`, `!=`, `>`, `<`, `>=`, `<=`, `contains`, `startswith`, `endswith`

**Use cases** : Exports de bases de données, filtrage de datasets, rapports tabulaires

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

### data_format — Conversion de formats ✨ v0.9.0

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `json_to_yaml.py`, `yaml_to_json.py`
**Dépendance** : `pyyaml` (déjà présent), `jsonschema>=4.20.0`
**Trigger patterns** : json, yaml, convert format, validate json

**Description** : Conversion bidirectionnelle JSON ↔ YAML avec validation schemas.

**Opérations** :
- JSON → YAML (pretty-print, Unicode)
- YAML → JSON (parsing strict)
- Validation JSON Schema

**Use cases** : Configuration (Docker Compose, Kubernetes), conversion API, validation de données

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

## Catégorie : Code (1 skill)

### code_format — Formatage de code ✨ v0.9.0

**Type** : Skill_Script
**Fichiers** : `SKILL.md`, `format_python.py`
**Dépendances** : `black`, `ruff` (déjà présents)
**Trigger patterns** : format code, lint, black, prettier, code style

**Description** : Formatage automatique de code Python, JavaScript, JSON, YAML selon les standards de l'industrie.

**Langages supportés** :
- **Python** : `black` (formatage PEP 8) + `ruff` (linting)
- **JavaScript/TypeScript** : `prettier`
- **JSON/YAML** : Pretty-print

**Use cases** : Code reviews, standardisation, CI/CD, préparation de commits

[**Détails complets dans CHANGELOG.md v0.9.0**]

---

## Guide de sélection d'une skill

### Pour la génération de documents

| Besoin | Skill recommandée | Raison |
|--------|-------------------|--------|
| Présentation avec slides | `powerpoint` | Layouts variés, thèmes, interactivité |
| Rapport textuel | `word` | Formatage riche, mise en page professionnelle |
| Document simple | `unified_pdf` | HTML → PDF, rapide |
| Fichier de données | `excel` ou `csv` | Excel pour multi-feuilles, CSV pour simplicité |
| Facture/contrat | `word` ou `unified_pdf` | Word pour édition future, PDF pour immuabilité |

### Pour la visualisation de données

| Besoin | Skill recommandée | Raison |
|--------|-------------------|--------|
| Graphiques quantitatifs | `chart` | Bar, line, pie charts interactifs |
| Diagrammes techniques | `mermaid` | Flowcharts, sequence diagrams, UML |
| Diagrammes d'infra | `drawio` | Architecture cloud, network diagrams |
| Tables de données | `table` | Affichage structuré de données tabulaires |

### Pour le contenu multimédia

| Besoin | Skill recommandée | Raison |
|--------|-------------------|--------|
| Générer une image | `image_gen` | DALL-E 3 pour qualité, DALL-E 2 pour rapidité |
| Analyser une image | `multimodal` | Description, OCR, détection d'objets |
| Afficher une image | `image_display` | Affichage simple dans le chat |

### Pour les données

| Besoin | Skill recommandée | Raison |
|--------|-------------------|--------|
| Export CSV | `csv` (create) | JSON → CSV avec options |
| Import CSV | `csv` (read) | CSV → JSON pour traitement |
| Filtrer CSV | `csv` (transform) | Filtres, tri, sélection de colonnes |
| Convertir JSON/YAML | `data_format` | Conversion bidirectionnelle |
| Fichier Excel | `excel` | Multiple feuilles, formatage |

### Pour le développement

| Besoin | Skill recommandée | Raison |
|--------|-------------------|--------|
| Formater du code | `code_format` | Python (black), JS (prettier) |
| Créer une skill | `skill_creator` | Guide complet, workflows API/UI/code |
| Recherche web | `web_search` | Informations à jour, gratuit |

---

## Utilisation des skills

### Lister les skills disponibles

```python
from agent_framework.skills.builtin import get_all_builtin_skills

skills = get_all_builtin_skills()
for skill in skills:
    print(f"{skill.metadata.name}: {skill.metadata.description}")
```

### Charger une skill à la demande

```python
from agent_framework.skills import SkillRegistry

registry = SkillRegistry()

# Charger une skill
loaded_skill = registry.load_skill("powerpoint")

# Obtenir les instructions
instructions = loaded_skill.get_instructions()

# Décharger quand terminé
registry.unload_skill("powerpoint")
```

### Via l'agent

Les agents utilisant `SkillsMixin` ont accès aux tools automatiques :
- `list_skills()` : Lister les skills disponibles
- `load_skill(name)` : Charger une skill et obtenir ses instructions
- `unload_skill(name)` : Décharger une skill

---

## Références

- **Guide de création de skills custom** : [docs/CUSTOM_SKILLS_GUIDE.md](CUSTOM_SKILLS_GUIDE.md)
- **Guide de création d'agents** : [docs/CREATING_AGENTS.md](CREATING_AGENTS.md)
- **Exemples** : [examples/skills_demo_agent.py](../examples/skills_demo_agent.py)
- **CHANGELOG v0.9.0** : Détails complets des 8 nouvelles skills

---

## Notes

- Les skills marquées ✨ sont nouvelles dans la v0.9.0
- Toutes les skills sont testées (79 tests unitaires passent à 100%)
- Les Skill_Script nécessitent les dépendances listées dans leurs sections
- Les Skill_Markdown n'ont pas de dépendances externes
