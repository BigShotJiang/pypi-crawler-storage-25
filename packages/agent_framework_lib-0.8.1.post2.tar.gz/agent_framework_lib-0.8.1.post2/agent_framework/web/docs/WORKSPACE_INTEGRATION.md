# Workspace Integration Guide

Connect your agent to the Workspace Platform as a collaborative participant in multi-user workspaces. The agent can subscribe to workspaces, receive messages, respond in conversations, and manage shared files.

## Quick Start

### 1. Environment Variables

```bash
WORKSPACE_ENABLED=true
WORKSPACE_AGENT_ID=my-agent              # Unique ID (lowercase, hyphens only)
WORKSPACE_AGENT_PUBLIC_URL=https://my-agent.example.com  # Public URL for webhooks
```

### 2. Subscribe to a Workspace

```bash
curl -X POST https://my-agent.example.com/workspace/subscribe \
  -H "Content-Type: application/json" \
  -d '{
    "workspace_url": "https://workspace-server.example.com",
    "workspace_api_key": "your-api-key",
    "workspace_id": "64f1a2b3c4d5e6f7...",
    "owner_id": "owner-user-id"
  }'
```

The agent will automatically register itself, join the workspace, and create a webhook subscription.

### 3. Start Receiving Messages

Once subscribed, the workspace server sends webhooks to `POST /workspace/webhook` on every new message. The agent processes them in the background and posts its response back.

## Architecture

```
Workspace Server (NestJS)          Agent Framework (FastAPI)
┌──────────────────────┐           ┌──────────────────────────┐
│                      │  webhook  │  POST /workspace/webhook  │
│  User sends message  │──────────►│                          │
│                      │           │  1. Fetch context msgs    │
│                      │           │  2. Build chat history    │
│                      │           │  3. Inject preferences    │
│                      │           │  4. Call LLM              │
│  Message appears     │◄──────────│  5. Post response         │
│  in workspace        │   POST    │  6. Update cursor         │
└──────────────────────┘           └──────────────────────────┘
```

## Endpoints

### Subscription Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/workspace/subscribe` | Subscribe agent to a workspace |
| GET | `/workspace/subscriptions` | List active subscriptions |
| DELETE | `/workspace/subscriptions/{workspace_id}` | Unsubscribe from a workspace |

### Webhook

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/workspace/webhook` | Receive events from workspace server |

### Polling (Local Development)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/workspace/poll/start/{workspace_id}` | Start polling for new messages |
| POST | `/workspace/poll/stop/{workspace_id}` | Stop polling |
| GET | `/workspace/poll/status` | List active pollers |

## Subscribe Request

```json
{
  "workspace_url": "https://workspace-server.example.com",
  "workspace_api_key": "api-key",
  "workspace_id": "mongodb-object-id",
  "owner_id": "owner-user-id"
}
```

| Field | Required | Description |
|-------|----------|-------------|
| `workspace_url` | Yes | Root URL of the workspace server (no `/api` suffix) |
| `workspace_api_key` | Yes | API key for `x-api-key` authentication |
| `workspace_id` | Yes | MongoDB ObjectId of the target workspace |
| `owner_id` | No | User ID of a workspace owner. Required when the agent cannot add itself as a member (only owners can add members). |

### What happens internally

1. `POST /workspace-agents` — Registers the agent identity (409 ignored)
2. `POST /workspaces/{id}/members` — Adds the agent as a member (409 ignored, 403 tolerated if already added)
3. `POST /webhook-subscriptions` — Creates a webhook pointing to `{AGENT_PUBLIC_URL}/workspace/webhook`
4. Persists the subscription locally (Elasticsearch or memory)

## Polling Mode

When the agent is not publicly accessible (e.g., running on localhost), use polling instead of webhooks:

```bash
# Start polling (checks every 5 seconds by default)
curl -X POST http://localhost:8110/workspace/poll/start/64f1a2b3...

# Check status
curl http://localhost:8110/workspace/poll/status

# Stop polling
curl -X POST http://localhost:8110/workspace/poll/stop/64f1a2b3...
```

Configure the interval with `WORKSPACE_POLL_INTERVAL` (seconds).

The poller initializes its cursor to the latest message on first run, then only processes new user messages. It reuses the same processing pipeline as webhooks.

## Workspace Artefacts (File Management)

When running in workspace context, the agent automatically receives three tools for managing shared files:

### Available Tools

- **`list_workspace_artefacts(type?)`** — List files in the workspace. Optional filter: `NOTE`, `EXPORT`, `DECISION`, `FILE`
- **`download_workspace_artefact(artefact_id)`** — Download a file by artefact ID. Uses presigned S3 URLs (24h). Returns text content or binary description
- **`upload_workspace_artefact(file_path, type?, message_id?)`** — Upload a local file to the workspace as a shared artefact

### How It Works

These tools are injected automatically into the agent's LlamaIndex instance at each message processing. No code changes needed in your agent. The system prompt is also augmented with instructions telling the agent to use these tools instead of internal file skills.

### Workspace Server Endpoints Used

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/workspaces/{id}/artefacts` | List artefacts (with populated file info) |
| POST | `/workspaces/{id}/artefacts` | Upload file (multipart, field name: `files`) |
| GET | `/files/{id}/signed-url` | Get presigned S3 download URL (24h) |

## Prompt Augmentation

The workspace module automatically enriches the agent's system prompt with workspace context. Two placeholders are available:

### `{{workspace_members}}`

Replaced with a comma-separated list of human member display names (e.g., `Elliott Girard, Alice Martin, Bob Dupont`).

If the placeholder is not present in the prompt, the members list is prepended automatically with a `[Workspace Members]` header.

### `{{workspace_user_preferences}}`

Replaced with a structured block of per-user preferences recalled from Graphiti memory. Requires Graphiti to be configured.

Example output:
```
[Workspace User Preferences]

## Elliott Girard (elliott@example.com, role: owner)
- Prefers responses in French
- Works on the Owliance project

## Alice Martin (alice@example.com, role: participant)
- No preferences detected
```

If the placeholder is not present, preferences are prepended automatically.

### Example Agent Prompt

```python
def get_agent_prompt(self) -> str:
    return """You are a collaborative assistant in a team workspace.

Members: {{workspace_members}}

{{workspace_user_preferences}}

Rules:
- Address participants by name when relevant
- Be concise and helpful"""
```

## Authentication

The agent authenticates to the workspace server using API key mode. Every request includes:

```
x-api-key: {workspace_api_key}
x-auth-mode: api-key
x-user-id: {agent_id}
x-user-name: {agent_id}
```

## Context Building

When a message arrives, the agent:

1. Reads the cursor (last processed message ID) from persistent storage
2. Fetches messages after the cursor from the workspace API
3. Truncates if the gap exceeds `WORKSPACE_MAX_GAP_MESSAGES` (default 200)
4. Builds a LlamaIndex chat history with `[SenderName]` prefixes for user messages
5. Separates the triggering message as the user query
6. Injects workspace member preferences (if Graphiti is available)
7. Calls the LLM with the full context
8. Posts the response to the workspace
9. Updates the cursor

## Configuration Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `WORKSPACE_ENABLED` | `false` | Enable workspace module |
| `WORKSPACE_AGENT_ID` | — | Agent identifier (lowercase, hyphens) |
| `WORKSPACE_AGENT_PUBLIC_URL` | — | Public URL for webhook reception |
| `WORKSPACE_MAX_CONTEXT_MESSAGES` | `50` | Max messages in context window |
| `WORKSPACE_MAX_GAP_MESSAGES` | `200` | Max gap before truncation |
| `WORKSPACE_POLL_INTERVAL` | `5` | Polling interval in seconds |
| `WORKSPACE_PREFS_CACHE_TTL` | `300` | Preferences cache TTL (seconds) |
| `WORKSPACE_PREFS_MAX_FACTS_PER_USER` | `10` | Max Graphiti facts per user |

## Example: Minimal Workspace Agent

```python
from agent_framework.implementations import LlamaIndexAgent
from agent_framework import create_basic_agent_server
import os

class MyWorkspaceAgent(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="my-workspace-agent",
            name="My Workspace Agent",
            description="A collaborative assistant",
        )
        self.register_builtin_skills()

    def get_agent_prompt(self) -> str:
        return """You are a helpful assistant in a team workspace.

Members: {{workspace_members}}

Be concise and address people by name."""

    def get_agent_tools(self) -> list[callable]:
        return self.get_skill_tools()

if __name__ == "__main__":
    os.environ["WORKSPACE_ENABLED"] = "true"
    os.environ["WORKSPACE_AGENT_ID"] = "my-workspace-agent"
    os.environ["WORKSPACE_AGENT_PUBLIC_URL"] = "https://my-agent.example.com"
    create_basic_agent_server(MyWorkspaceAgent, port=8110)
```
