"""
Skills API Router

Provides FastAPI endpoints for managing custom skills: listing, creating,
updating, deleting, and retrieving skill details.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request, UploadFile, File
from fastapi.responses import Response
from pydantic import BaseModel, Field

from agent_framework.skills.custom_skill_manager import (
    BuiltinSkillError,
    CustomSkillError,
    CustomSkillManager,
    InvalidSkillNameError,
    PathTraversalError,
    SkillConflictError,
    SkillNotFoundError,
)


logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class SkillCreateRequest(BaseModel):
    """JSON body for POST /api/skills."""

    name: str = Field(..., pattern=r"^[a-z0-9_-]+$")
    description: str
    instructions: str
    display_name: str | None = None
    emoji: str | None = None
    trigger_patterns: list[str] = Field(default_factory=list)
    entrypoint: str | None = None
    runtime: str | None = None
    requires_bins: list[str] = Field(default_factory=list)
    requires_env: list[str] = Field(default_factory=list)


class SkillUpdateRequest(BaseModel):
    """JSON body for PUT /api/skills/{name}."""

    description: str | None = None
    instructions: str | None = None
    display_name: str | None = None
    emoji: str | None = None
    trigger_patterns: list[str] | None = None
    entrypoint: str | None = None
    runtime: str | None = None
    requires_bins: list[str] | None = None
    requires_env: list[str] | None = None


class SkillResponse(BaseModel):
    """Response model for a single skill."""

    name: str
    description: str
    display_name: str | None = None
    emoji: str | None = None
    source: str
    trigger_patterns: list[str] = Field(default_factory=list)
    entrypoint: str | None = None
    runtime: str | None = None
    requires_bins: list[str] = Field(default_factory=list)
    requires_env: list[str] = Field(default_factory=list)
    instructions: str | None = None
    files: list[str] | None = None


class SkillListResponse(BaseModel):
    """Response model for GET /api/skills."""

    skills: list[SkillResponse]


class SkillValidateRequest(BaseModel):
    """JSON body for POST /api/skills/validate."""

    name: str
    description: str
    instructions: str


class SkillValidationReport(BaseModel):
    """AI validation report."""

    score: int = Field(..., ge=0, le=100)
    suggestions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

skills_router = APIRouter(prefix="/api/skills", tags=["skills"])


def _get_manager(request: Request) -> CustomSkillManager:
    """Retrieve the CustomSkillManager from application state."""
    return request.app.state.custom_skill_manager


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@skills_router.get("", response_model=SkillListResponse)
async def list_skills(request: Request) -> SkillListResponse:
    """List all registered skills with their source."""
    manager = _get_manager(request)
    registry = manager._registry

    items: list[SkillResponse] = []
    for meta in registry.list_all():
        skill_obj = registry.get(meta.name)
        source = registry.get_source(meta.name) or "builtin"
        items.append(
            SkillResponse(
                name=meta.name,
                description=meta.description,
                display_name=skill_obj.display_name if skill_obj else None,
                emoji=skill_obj.display_icon if skill_obj else None,
                source=source,
                trigger_patterns=list(meta.trigger_patterns),
                entrypoint=skill_obj.config.get("entrypoint") if skill_obj else None,
                runtime=skill_obj.config.get("runtime") if skill_obj else None,
                requires_bins=list(meta.requires_bins),
                requires_env=list(meta.requires_env),
            )
        )

    return SkillListResponse(skills=items)


@skills_router.post("", response_model=SkillResponse, status_code=201)
async def create_skill(body: SkillCreateRequest, request: Request) -> SkillResponse:
    """Create a new custom skill."""
    manager = _get_manager(request)

    try:
        skill = manager.create_skill(
            name=body.name,
            description=body.description,
            instructions=body.instructions,
            display_name=body.display_name,
            emoji=body.emoji,
            trigger_patterns=body.trigger_patterns,
            entrypoint=body.entrypoint,
            runtime=body.runtime,
            requires_bins=body.requires_bins,
            requires_env=body.requires_env,
        )
    except InvalidSkillNameError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except SkillConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except CustomSkillError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return SkillResponse(
        name=skill.metadata.name,
        description=skill.metadata.description,
        display_name=skill.display_name,
        emoji=skill.display_icon,
        source="custom",
        trigger_patterns=list(skill.metadata.trigger_patterns),
        entrypoint=skill.config.get("entrypoint"),
        runtime=skill.config.get("runtime"),
        requires_bins=list(skill.metadata.requires_bins),
        requires_env=list(skill.metadata.requires_env),
    )


@skills_router.post("/validate", response_model=SkillValidationReport)
async def validate_skill(body: SkillValidateRequest) -> SkillValidationReport:
    """Run a basic validation on skill content and return a quality report."""
    suggestions: list[str] = []
    warnings: list[str] = []
    score = 100

    if len(body.instructions) < 50:
        suggestions.append("Instructions are very short — consider adding more detail.")
        score -= 20

    if len(body.instructions) > 10000:
        warnings.append("Instructions exceed 10 000 characters — consider splitting into sections.")
        score -= 10

    if not body.description.strip():
        warnings.append("Description is empty.")
        score -= 15

    lower = body.instructions.lower()
    key_sections = ["##", "step", "example", "usage"]
    found = sum(1 for kw in key_sections if kw in lower)
    if found == 0:
        suggestions.append(
            "Consider adding sections (##), steps, examples, or usage instructions."
        )
        score -= 15

    if not body.name.strip():
        warnings.append("Skill name is empty.")
        score -= 10

    score = max(0, min(100, score))

    return SkillValidationReport(score=score, suggestions=suggestions, warnings=warnings)


@skills_router.get("/{name}", response_model=SkillResponse)
async def get_skill(name: str, request: Request) -> SkillResponse:
    """Get detailed information for a single skill, including instructions and files."""
    manager = _get_manager(request)
    registry = manager._registry

    skill = registry.get(name)
    if skill is None:
        raise HTTPException(status_code=404, detail=f"Skill '{name}' not found")

    source = registry.get_source(name) or "builtin"

    instructions: str | None = None
    try:
        instructions = skill.get_instructions()
    except Exception:
        logger.warning("Could not load instructions for skill '%s'", name)

    files: list[str] | None = None
    try:
        files = manager.list_skill_files(name)
    except SkillNotFoundError:
        files = None

    return SkillResponse(
        name=skill.metadata.name,
        description=skill.metadata.description,
        display_name=skill.display_name,
        emoji=skill.display_icon,
        source=source,
        trigger_patterns=list(skill.metadata.trigger_patterns),
        entrypoint=skill.config.get("entrypoint"),
        runtime=skill.config.get("runtime"),
        requires_bins=list(skill.metadata.requires_bins),
        requires_env=list(skill.metadata.requires_env),
        instructions=instructions,
        files=files,
    )


@skills_router.put("/{name}", response_model=SkillResponse)
async def update_skill(name: str, body: SkillUpdateRequest, request: Request) -> SkillResponse:
    """Update an existing custom skill."""
    manager = _get_manager(request)

    try:
        skill = manager.update_skill(
            name=name,
            description=body.description,
            instructions=body.instructions,
            display_name=body.display_name,
            emoji=body.emoji,
            trigger_patterns=body.trigger_patterns,
            entrypoint=body.entrypoint,
            runtime=body.runtime,
            requires_bins=body.requires_bins,
            requires_env=body.requires_env,
        )
    except BuiltinSkillError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except SkillNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except CustomSkillError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    return SkillResponse(
        name=skill.metadata.name,
        description=skill.metadata.description,
        display_name=skill.display_name,
        emoji=skill.display_icon,
        source="custom",
        trigger_patterns=list(skill.metadata.trigger_patterns),
        entrypoint=skill.config.get("entrypoint"),
        runtime=skill.config.get("runtime"),
        requires_bins=list(skill.metadata.requires_bins),
        requires_env=list(skill.metadata.requires_env),
    )


@skills_router.delete("/{name}", status_code=200)
async def delete_skill(name: str, request: Request) -> dict[str, str]:
    """Delete a custom skill."""
    manager = _get_manager(request)

    try:
        manager.delete_skill(name)
    except BuiltinSkillError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except SkillNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return {"status": "deleted", "name": name}


@skills_router.get("/{name}/files/{filename}")
async def download_file(name: str, filename: str, request: Request) -> Response:
    """Download a file from a skill directory."""
    if filename == "SKILL.md":
        raise HTTPException(
            status_code=400,
            detail="SKILL.md is managed via the skill metadata endpoints.",
        )

    manager = _get_manager(request)

    try:
        data, mime_type = manager.get_file(name, filename)
    except PathTraversalError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except SkillNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except BuiltinSkillError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc

    return Response(content=data, media_type=mime_type)


@skills_router.post("/{name}/files", status_code=201)
async def upload_file(
    name: str, request: Request, file: UploadFile = File(...)
) -> dict[str, str]:
    """Upload a file into a skill directory."""
    if file.filename == "SKILL.md":
        raise HTTPException(
            status_code=400,
            detail="SKILL.md is managed via the skill metadata endpoints.",
        )

    manager = _get_manager(request)

    if manager.is_builtin(name):
        raise HTTPException(
            status_code=403,
            detail=f"Cannot modify files of builtin skill '{name}'.",
        )

    try:
        content = await file.read()
        manager.add_file(name, file.filename, content)
    except PathTraversalError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except SkillNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return {"status": "uploaded", "filename": file.filename}


@skills_router.delete("/{name}/files/{filename}", status_code=200)
async def delete_file(name: str, filename: str, request: Request) -> dict[str, str]:
    """Delete a file from a skill directory."""
    if filename == "SKILL.md":
        raise HTTPException(
            status_code=400,
            detail="SKILL.md is managed via the skill metadata endpoints.",
        )

    manager = _get_manager(request)

    if manager.is_builtin(name):
        raise HTTPException(
            status_code=403,
            detail=f"Cannot modify files of builtin skill '{name}'.",
        )

    try:
        manager.delete_file(name, filename)
    except PathTraversalError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except SkillNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return {"status": "deleted", "filename": filename}
