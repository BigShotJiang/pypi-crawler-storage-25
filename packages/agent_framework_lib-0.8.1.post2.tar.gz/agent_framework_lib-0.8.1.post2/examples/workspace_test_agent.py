"""
Workspace Integration Test Agent

Agent de test pour valider l'intégration avec le Workspace Platform.
Se connecte au backend workspace, s'abonne à un workspace via le module
workspace/ du framework, et répond aux messages des utilisateurs.

Usage:
    uv run python examples/workspace_test_agent.py

L'agent démarre sur http://localhost:8110
Le front workspace est sur http://localhost:3001/agents
Le backend workspace est sur https://workspace-back-dev.owliance.work

Pour abonner l'agent à un workspace :
    curl -X POST http://localhost:8110/workspace/subscribe \\
      -H "Content-Type: application/json" \\
      -d '{
        "workspace_url": "https://workspace-back-dev.owliance.work/api",
        "workspace_api_key": "abcdefgh",
        "workspace_id": "<WORKSPACE_ID>"
      }'
"""

import os
from typing import Any

from agent_framework.implementations import LlamaIndexAgent


class WorkspaceTestAgent(LlamaIndexAgent):
    """Agent de test pour l'intégration workspace.

    Fournit des outils basiques et un prompt orienté collaboration
    pour valider le flux complet : webhook → context → agent → réponse.
    """

    def __init__(self) -> None:
        super().__init__(
            agent_id="workspace-test-agent",
            name="Workspace Test Agent",
            description="Agent de test pour valider l'intégration avec le Workspace Platform.",
            image_url="https://api.dicebear.com/7.x/bottts/svg?seed=workspace",
        )
        self.register_builtin_skills()

    async def configure_session(self, session_configuration: dict[str, Any]) -> None:
        """Capture le contexte de session."""
        await super().configure_session(session_configuration)

    def get_agent_prompt(self) -> str:
        return """Tu es un assistant collaboratif intégré dans un workspace d'équipe.

Tu participes à des conversations multi-utilisateurs dans un espace de travail partagé.
Quand tu reçois un message, le contexte de la conversation précédente est inclus
avec les noms des participants entre crochets (ex: [Alice]: ...).

Règles :
- Réponds de manière concise et utile
- Adresse-toi aux participants par leur nom quand c'est pertinent
- Tu peux utiliser tes skills (charts, tableaux, etc.) si on te le demande
- Si on te demande un résumé de la conversation, synthétise le contexte fourni

Tu as aussi accès aux artefacts du workspace (fichiers partagés) via des outils dédiés
quand ils sont disponibles."""

    def get_agent_tools(self) -> list[callable]:
        """Outils de base + skills management."""

        def ping() -> str:
            """Vérifie que l'agent est opérationnel. Retourne 'pong'."""
            return "pong"

        def echo(message: str) -> str:
            """Répète le message reçu. Utile pour tester le flux."""
            return f"Echo: {message}"

        tools = [ping, echo]
        tools.extend(self.get_skill_tools())
        return tools


def main() -> None:
    """Démarre le serveur agent avec le module workspace activé."""
    if not os.getenv("OPENAI_API_KEY"):
        print("Erreur: OPENAI_API_KEY non définie")
        return

    # Activer le module workspace
    os.environ.setdefault("WORKSPACE_ENABLED", "true")
    os.environ.setdefault("WORKSPACE_AGENT_ID", "workspace-test-agent")
    os.environ.setdefault("WORKSPACE_AGENT_PUBLIC_URL", "http://localhost:8110")

    from agent_framework import create_basic_agent_server

    port = int(os.getenv("AGENT_PORT", "8110"))

    print("=" * 60)
    print("🏢 Workspace Test Agent")
    print("=" * 60)
    print(f"📊 Model: {os.getenv('DEFAULT_MODEL', 'gpt-5-mini')}")
    print(f"🌐 Agent: http://localhost:{port}")
    print(f"🔗 Workspace endpoints:")
    print(f"   POST /workspace/subscribe")
    print(f"   GET  /workspace/subscriptions")
    print(f"   POST /workspace/webhook")
    print(f"   POST /workspace/poll/start/{{workspace_id}}")
    print(f"   POST /workspace/poll/stop/{{workspace_id}}")
    print(f"🎯 Front: http://localhost:3001/agents")
    print(f"🔧 Backend: https://workspace-back-dev.owliance.work")
    print("=" * 60)
    print()
    print("Pour abonner l'agent puis démarrer le polling :")
    print(f'  curl -X POST http://localhost:{port}/workspace/subscribe \\')
    print('    -H "Content-Type: application/json" \\')
    print("    -d '{")
    print('      "workspace_url": "https://workspace-back-dev.owliance.work",')
    print('      "workspace_api_key": "abcdefgh",')
    print('      "workspace_id": "<WORKSPACE_ID>",')
    print('      "owner_id": "<OWNER_USER_ID>"')
    print("    }'")
    print()
    print(f"  curl -X POST http://localhost:{port}/workspace/poll/start/<WORKSPACE_ID>")
    print()

    create_basic_agent_server(
        agent_class=WorkspaceTestAgent,
        host="0.0.0.0",
        port=port,
        reload=False,
    )


if __name__ == "__main__":
    main()
