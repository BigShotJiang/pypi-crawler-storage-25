"""Production-grade end-to-end tests.

These tests simulate real end-client usage patterns:
- Full room lifecycle (create → join → commit → switch active → leave → delete)
- Mirror proxy with a real upstream HTTP server
- Dashboard rendering with live data
- WebSocket real-time event delivery
- Rate limiting behavior
- Security enforcement at every boundary
- Edge cases: duplicate commits, reconnect, TTL expiration
"""

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest.mock import AsyncMock

import pytest

httpx = pytest.importorskip("httpx")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _create_room(client, room_id: str, developer_id: str, upstream_url: str) -> dict:
    resp = client.post(
        "/rooms",
        json={
            "room_id": room_id,
            "developer_id": developer_id,
            "upstream_url": upstream_url,
        },
    )
    assert resp.status_code == 200, f"create_room failed: {resp.text}"
    return resp.json()


def _join_room(client, room_id: str, developer_id: str, upstream_url: str, join_secret: str) -> dict:
    resp = client.post(
        f"/rooms/{room_id}/join",
        json={
            "developer_id": developer_id,
            "upstream_url": upstream_url,
            "join_secret": join_secret,
        },
    )
    assert resp.status_code == 200, f"join_room failed: {resp.text}"
    return resp.json()


def _report_commit(client, room_id: str, dev_id: str, token: str,
                   commit_hash: str, branch: str = "main", message: str = "commit") -> dict:
    resp = client.post(
        f"/rooms/{room_id}/commits",
        json={
            "developer_id": dev_id,
            "commit_hash": commit_hash,
            "branch": branch,
            "message": message,
        },
        headers=_auth(token),
    )
    assert resp.status_code == 200, f"report_commit failed: {resp.text}"
    return resp.json()


def _heartbeat(client, room_id: str, dev_id: str, token: str,
               upstream_url: str | None = None) -> dict:
    payload: dict = {"developer_id": dev_id}
    if upstream_url is not None:
        payload["upstream_url"] = upstream_url
    resp = client.post(
        f"/rooms/{room_id}/presence/heartbeat",
        json=payload,
        headers=_auth(token),
    )
    assert resp.status_code == 200, f"heartbeat failed: {resp.text}"
    return resp.json()


def _disconnect(client, room_id: str, dev_id: str, token: str) -> dict:
    resp = client.post(
        f"/rooms/{room_id}/presence/disconnect",
        json={"developer_id": dev_id},
        headers=_auth(token),
    )
    assert resp.status_code == 200, f"disconnect failed: {resp.text}"
    return resp.json()


def _get_status(client, room_id: str) -> dict:
    resp = client.get(f"/rooms/{room_id}/status")
    assert resp.status_code == 200, f"get_status failed: {resp.text}"
    return resp.json()


# ---------------------------------------------------------------------------
# 1. Full room lifecycle
# ---------------------------------------------------------------------------

class TestFullRoomLifecycle:
    """Simulates the complete lifecycle as end clients would experience it."""

    def test_create_returns_all_tokens_and_room_id(self, client):
        data = _create_room(client, "lifecycle", "alice", "http://localhost:3000")
        assert data["room_id"] == "lifecycle"
        assert len(data["join_secret"]) >= 40
        assert len(data["admin_token"]) >= 40
        assert len(data["member_token"]) >= 40
        assert data["join_secret"] != data["admin_token"] != data["member_token"]

    def test_duplicate_room_creation_rejected(self, client):
        _create_room(client, "dup-room", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms",
            json={"room_id": "dup-room", "developer_id": "bob", "upstream_url": "http://localhost:3001"},
        )
        assert resp.status_code == 409

    def test_join_requires_correct_secret(self, client):
        data = _create_room(client, "secret-test", "alice", "http://localhost:3000")

        resp = client.post(
            "/rooms/secret-test/join",
            json={"developer_id": "eve", "upstream_url": "http://evil.com", "join_secret": "wrong"},
        )
        assert resp.status_code == 403

        join_data = _join_room(client, "secret-test", "bob", "http://localhost:3001", data["join_secret"])
        assert "member_token" in join_data

    def test_join_nonexistent_room_rejected(self, client):
        resp = client.post(
            "/rooms/nonexistent/join",
            json={"developer_id": "bob", "upstream_url": "http://localhost:3001", "join_secret": "x"},
        )
        # Returns 403 (not 404) to avoid leaking whether a room exists
        assert resp.status_code == 403

    def test_status_shows_all_participants_after_join(self, client):
        data = _create_room(client, "multi-dev", "alice", "http://localhost:3000")
        _join_room(client, "multi-dev", "bob", "http://localhost:3001", data["join_secret"])

        status = _get_status(client, "multi-dev")
        assert len(status["participants"]) == 2
        dev_ids = {p["developer_id"] for p in status["participants"]}
        assert dev_ids == {"alice", "bob"}

    def test_room_deletion_cascades_and_returns_404(self, client):
        data = _create_room(client, "del-room", "alice", "http://localhost:3000")
        _report_commit(client, "del-room", "alice", data["member_token"], "a1b2c3d")

        resp = client.delete("/rooms/del-room", headers=_auth(data["admin_token"]))
        assert resp.status_code == 200

        status_resp = client.get("/rooms/del-room/status")
        assert status_resp.status_code == 404

    def test_delete_requires_admin_token(self, client):
        data = _create_room(client, "admin-del", "alice", "http://localhost:3000")

        resp = client.delete("/rooms/admin-del", headers=_auth(data["member_token"]))
        assert resp.status_code == 403

        resp = client.delete("/rooms/admin-del", headers=_auth(data["admin_token"]))
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# 2. Active developer switching (the core product mechanism)
# ---------------------------------------------------------------------------

class TestActiveDeveloperSwitching:
    """The fundamental product behavior: commits determine who is active."""

    def test_creator_is_active_by_default(self, client):
        _create_room(client, "active-default", "alice", "http://alice:3000")
        status = _get_status(client, "active-default")
        assert status["active_upstream"] == "http://alice:3000"

    def test_commit_switches_active_developer(self, client):
        data = _create_room(client, "switch-test", "alice", "http://alice:3000")
        bob_data = _join_room(client, "switch-test", "bob", "http://bob:3001", data["join_secret"])

        _report_commit(client, "switch-test", "alice", data["member_token"], "aaa1111")
        status1 = _get_status(client, "switch-test")
        assert status1["active_upstream"] == "http://alice:3000"

        _report_commit(client, "switch-test", "bob", bob_data["member_token"], "bbb2222")
        status2 = _get_status(client, "switch-test")
        assert status2["active_upstream"] == "http://bob:3001"

        _report_commit(client, "switch-test", "alice", data["member_token"], "aaa3333")
        status3 = _get_status(client, "switch-test")
        assert status3["active_upstream"] == "http://alice:3000"

    def test_disconnect_falls_back_to_previous_committer(self, client):
        data = _create_room(client, "fallback-test", "alice", "http://alice:3000")
        bob_data = _join_room(client, "fallback-test", "bob", "http://bob:3001", data["join_secret"])

        _report_commit(client, "fallback-test", "alice", data["member_token"], "aaa1111")
        _report_commit(client, "fallback-test", "bob", bob_data["member_token"], "bbb2222")

        status_before = _get_status(client, "fallback-test")
        assert status_before["active_upstream"] == "http://bob:3001"

        _disconnect(client, "fallback-test", "bob", bob_data["member_token"])

        status_after = _get_status(client, "fallback-test")
        assert status_after["active_upstream"] == "http://alice:3000"

    def test_all_disconnected_returns_none(self, client):
        data = _create_room(client, "all-off", "alice", "http://alice:3000")
        _disconnect(client, "all-off", "alice", data["member_token"])

        status = _get_status(client, "all-off")
        assert status["active_upstream"] is None

    def test_reconnect_restores_active(self, client):
        data = _create_room(client, "reconnect", "alice", "http://alice:3000")
        _report_commit(client, "reconnect", "alice", data["member_token"], "aaa1111")
        _disconnect(client, "reconnect", "alice", data["member_token"])

        status_off = _get_status(client, "reconnect")
        assert status_off["active_upstream"] is None

        _heartbeat(client, "reconnect", "alice", data["member_token"])

        status_on = _get_status(client, "reconnect")
        assert status_on["active_upstream"] == "http://alice:3000"


# ---------------------------------------------------------------------------
# 3. Commit idempotency and ordering
# ---------------------------------------------------------------------------

class TestCommitBehavior:

    def test_duplicate_commit_is_idempotent(self, client):
        data = _create_room(client, "idem-room", "alice", "http://localhost:3000")
        r1 = _report_commit(client, "idem-room", "alice", data["member_token"], "aaa1111")
        assert r1["inserted"] is True

        r2 = _report_commit(client, "idem-room", "alice", data["member_token"], "aaa1111")
        assert r2["inserted"] is False

        status = _get_status(client, "idem-room")
        assert len(status["commits"]) == 1

    def test_commit_by_non_member_rejected(self, client):
        _create_room(client, "non-member", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms/non-member/commits",
            json={
                "developer_id": "eve",
                "commit_hash": "eee1111",
                "branch": "main",
                "message": "intruder",
            },
            headers=_auth("fake-token"),
        )
        assert resp.status_code == 403

    def test_commit_ordering_by_server_time(self, client):
        data = _create_room(client, "order-test", "alice", "http://localhost:3000")
        bob_data = _join_room(client, "order-test", "bob", "http://localhost:3001", data["join_secret"])

        _report_commit(client, "order-test", "alice", data["member_token"], "aaa1111", message="first")
        _report_commit(client, "order-test", "bob", bob_data["member_token"], "bbb2222", message="second")
        _report_commit(client, "order-test", "alice", data["member_token"], "ccc3333", message="third")

        status = _get_status(client, "order-test")
        messages = [c["message"] for c in status["commits"]]
        assert messages == ["third", "second", "first"]

    def test_commit_validates_hash_format(self, client):
        data = _create_room(client, "validate-hash", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms/validate-hash/commits",
            json={
                "developer_id": "alice",
                "commit_hash": "INVALID",
                "branch": "main",
                "message": "bad hash",
            },
            headers=_auth(data["member_token"]),
        )
        assert resp.status_code == 400

    def test_commit_to_nonexistent_room(self, client):
        resp = client.post(
            "/rooms/ghost-room/commits",
            json={
                "developer_id": "alice",
                "commit_hash": "aaa1111",
                "branch": "main",
                "message": "nowhere",
            },
            headers=_auth("some-token"),
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# 4. Presence (heartbeat / disconnect / TTL)
# ---------------------------------------------------------------------------

class TestPresence:

    def test_heartbeat_updates_upstream_url(self, client):
        data = _create_room(client, "hb-update", "alice", "http://old-url:3000")
        _heartbeat(client, "hb-update", "alice", data["member_token"],
                   upstream_url="http://new-url:4000")

        status = _get_status(client, "hb-update")
        assert status["active_upstream"] == "http://new-url:4000"
        assert status["participants"][0]["upstream_url"] == "http://new-url:4000"

    def test_heartbeat_without_auth_rejected(self, client):
        _create_room(client, "hb-noauth", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms/hb-noauth/presence/heartbeat",
            json={"developer_id": "alice"},
        )
        assert resp.status_code == 401

    def test_heartbeat_with_wrong_token_rejected(self, client):
        _create_room(client, "hb-wrongauth", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms/hb-wrongauth/presence/heartbeat",
            json={"developer_id": "alice"},
            headers=_auth("wrong-token"),
        )
        assert resp.status_code == 403

    def test_disconnect_and_reconnect_cycle(self, client):
        data = _create_room(client, "cycle-room", "alice", "http://localhost:3000")

        _disconnect(client, "cycle-room", "alice", data["member_token"])
        s1 = _get_status(client, "cycle-room")
        assert s1["participants"][0]["connected"] is False
        assert s1["active_upstream"] is None

        _heartbeat(client, "cycle-room", "alice", data["member_token"])
        s2 = _get_status(client, "cycle-room")
        assert s2["participants"][0]["connected"] is True
        assert s2["active_upstream"] == "http://localhost:3000"


# ---------------------------------------------------------------------------
# 5. Mirror proxy with real ephemeral upstream
# ---------------------------------------------------------------------------

class TestMirrorProxy:

    def test_mirror_proxies_get_with_path_and_query(self, client, monkeypatch):
        from mact.server.main import fastapi_app

        data = _create_room(client, "mirror-e2e", "alice", "http://localhost:9999")
        _report_commit(client, "mirror-e2e", "alice", data["member_token"], "aaa1111")

        captured = {}

        async def fake_request(method, url, content=None, headers=None, follow_redirects=False, **kw):
            captured["method"] = method
            captured["url"] = str(url)
            return httpx.Response(200, content=b"OK", headers={"content-type": "text/plain"})

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.request = AsyncMock(side_effect=fake_request)
        monkeypatch.setattr(fastapi_app.state, "mirror_client", mock_client)

        resp = client.get("/r/mirror-e2e/api/data?page=1&limit=10")
        assert resp.status_code == 200
        assert resp.text == "OK"
        assert captured["url"] == "http://localhost:9999/api/data?page=1&limit=10"
        assert captured["method"] == "GET"

    def test_mirror_post_forwards_body(self, client, monkeypatch):
        from mact.server.main import fastapi_app

        data = _create_room(client, "mirror-post", "alice", "http://localhost:9999")
        _report_commit(client, "mirror-post", "alice", data["member_token"], "aaa1111")

        captured = {}

        async def fake_request(method, url, content=None, headers=None, follow_redirects=False, **kw):
            captured["method"] = method
            captured["content"] = content
            return httpx.Response(201, content=b'{"id":1}', headers={"content-type": "application/json"})

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.request = AsyncMock(side_effect=fake_request)
        monkeypatch.setattr(fastapi_app.state, "mirror_client", mock_client)

        resp = client.post("/r/mirror-post/api/submit", json={"name": "test"})
        assert resp.status_code == 201
        assert captured["method"] == "POST"
        assert captured["content"] is not None

    def test_mirror_offline_page_when_no_upstream(self, client):
        data = _create_room(client, "offline-e2e", "alice", "http://localhost:3000")
        _disconnect(client, "offline-e2e", "alice", data["member_token"])

        resp = client.get("/r/offline-e2e")
        assert resp.status_code == 503
        assert "No developer is currently live" in resp.text
        assert "offline-e2e" in resp.text

    def test_mirror_injects_live_reload_into_html_responses(self, client, monkeypatch):
        from mact.server.main import fastapi_app

        data = _create_room(client, "inject-test", "alice", "http://localhost:9999")
        _report_commit(client, "inject-test", "alice", data["member_token"], "aaa1111")

        html_body = b"<html><head><title>My App</title></head><body><h1>Hello World</h1></body></html>"

        async def fake_request(**kw):
            return httpx.Response(200, content=html_body, headers={"content-type": "text/html; charset=utf-8"})

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.request = AsyncMock(side_effect=fake_request)
        monkeypatch.setattr(fastapi_app.state, "mirror_client", mock_client)

        resp = client.get("/r/inject-test/")
        assert resp.status_code == 200
        text = resp.text

        assert "<h1>Hello World</h1>" in text
        assert "MACT live-reload" in text
        assert "WebSocket" in text
        assert "location.reload()" in text

        assert resp.headers.get("cache-control") == "no-store"
        assert "x-mact-upstream" in resp.headers

    def test_mirror_does_not_inject_script_into_json(self, client, monkeypatch):
        from mact.server.main import fastapi_app

        data = _create_room(client, "json-test", "alice", "http://localhost:9999")
        _report_commit(client, "json-test", "alice", data["member_token"], "aaa1111")

        async def fake_request(**kw):
            return httpx.Response(200, content=b'{"key":"value"}',
                                  headers={"content-type": "application/json"})

        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.request = AsyncMock(side_effect=fake_request)
        monkeypatch.setattr(fastapi_app.state, "mirror_client", mock_client)

        resp = client.get("/r/json-test/api/data")
        assert resp.status_code == 200
        assert resp.json() == {"key": "value"}
        assert "MACT live-reload" not in resp.text


# ---------------------------------------------------------------------------
# 6. Admin comments
# ---------------------------------------------------------------------------

class TestAdminComments:

    def test_full_comment_lifecycle(self, client):
        data = _create_room(client, "comment-lifecycle", "alice", "http://localhost:3000")
        _report_commit(client, "comment-lifecycle", "alice", data["member_token"],
                       "aaa1111", message="Initial work")

        # Set comment
        resp = client.patch(
            "/rooms/comment-lifecycle/commits/aaa1111/comment",
            json={"comment": "Looks good, ship it!"},
            headers=_auth(data["admin_token"]),
        )
        assert resp.status_code == 200

        status = _get_status(client, "comment-lifecycle")
        assert status["latest_commit"]["admin_comment"] == "Looks good, ship it!"

        # Update comment
        client.patch(
            "/rooms/comment-lifecycle/commits/aaa1111/comment",
            json={"comment": "Updated: needs one more fix"},
            headers=_auth(data["admin_token"]),
        )
        status2 = _get_status(client, "comment-lifecycle")
        assert status2["latest_commit"]["admin_comment"] == "Updated: needs one more fix"

        # Clear comment
        client.patch(
            "/rooms/comment-lifecycle/commits/aaa1111/comment",
            json={"comment": None},
            headers=_auth(data["admin_token"]),
        )
        status3 = _get_status(client, "comment-lifecycle")
        assert status3["latest_commit"]["admin_comment"] is None

    def test_member_cannot_comment(self, client):
        data = _create_room(client, "no-member-comment", "alice", "http://localhost:3000")
        _report_commit(client, "no-member-comment", "alice", data["member_token"], "aaa1111")

        resp = client.patch(
            "/rooms/no-member-comment/commits/aaa1111/comment",
            json={"comment": "Unauthorized"},
            headers=_auth(data["member_token"]),
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# 7. Dashboard rendering
# ---------------------------------------------------------------------------

class TestDashboard:

    def test_subdomain_dashboard_renders_room_data(self, client):
        data = _create_room(client, "dash-e2e", "alice", "http://localhost:3000")
        bob_data = _join_room(client, "dash-e2e", "bob", "http://localhost:3001", data["join_secret"])
        _report_commit(client, "dash-e2e", "alice", data["member_token"],
                       "aaa1111", message="Feature A")
        _report_commit(client, "dash-e2e", "bob", bob_data["member_token"],
                       "bbb2222", message="Fix bug B")

        from mact.server.main import fastapi_app
        from sqlalchemy.orm import Session

        db = fastapi_app.state.SessionLocal()
        try:
            from mact.server.main import _room_dashboard_response
            from starlette.testclient import TestClient
            from starlette.requests import Request

            # Use the path-based dashboard with env var
            import os
            os.environ["MACT_DEV_DASHBOARD"] = "true"
            try:
                resp = client.get("/rooms/dash-e2e/dashboard")
                assert resp.status_code == 200
                html = resp.text

                assert "dash-e2e" in html
                assert "alice" in html
                assert "bob" in html
                assert "aaa1111" in html or "aaa1111"[:7] in html
                assert "Feature A" in html
                assert "Fix bug B" in html
                assert "LIVE" in html or "badge-live" in html
            finally:
                os.environ.pop("MACT_DEV_DASHBOARD", None)
        finally:
            db.close()


# ---------------------------------------------------------------------------
# 8. WebSocket real-time events
# ---------------------------------------------------------------------------

class TestWebSocketEvents:

    def test_websocket_initial_snapshot_has_full_room_data(self, client):
        data = _create_room(client, "ws-snapshot", "alice", "http://localhost:3000")
        _report_commit(client, "ws-snapshot", "alice", data["member_token"],
                       "aaa1111", message="test")

        with client.websocket_connect("/rooms/ws-snapshot/events") as ws:
            msg = ws.receive_json()
            assert msg["type"] == "room_status"
            payload = msg["payload"]
            assert payload["room_id"] == "ws-snapshot"
            assert payload["active_upstream"] == "http://localhost:3000"
            assert len(payload["participants"]) == 1
            assert payload["latest_commit"]["commit_hash"] == "aaa1111"

    def test_websocket_rejects_nonexistent_room(self, client):
        from starlette.websockets import WebSocketDisconnect

        with pytest.raises(WebSocketDisconnect):
            with client.websocket_connect("/rooms/ghost-ws/events"):
                pass

    def test_mirror_live_page_contains_iframe_and_websocket(self, client):
        data = _create_room(client, "live-page", "alice", "http://localhost:3000")
        resp = client.get("/r/live-page/live")
        assert resp.status_code == 200
        html = resp.text
        assert "mact-mirror-frame" in html
        assert "iframe" in html.lower()
        assert "WebSocket" in html


# ---------------------------------------------------------------------------
# 9. Input validation (boundary testing)
# ---------------------------------------------------------------------------

class TestInputValidation:

    def test_room_id_rejects_uppercase(self, client):
        resp = client.post(
            "/rooms",
            json={"room_id": "UPPER", "developer_id": "alice", "upstream_url": "http://localhost:3000"},
        )
        assert resp.status_code == 400

    def test_room_id_rejects_leading_hyphen(self, client):
        resp = client.post(
            "/rooms",
            json={"room_id": "-bad", "developer_id": "alice", "upstream_url": "http://localhost:3000"},
        )
        assert resp.status_code == 400

    def test_room_id_rejects_trailing_hyphen(self, client):
        resp = client.post(
            "/rooms",
            json={"room_id": "bad-", "developer_id": "alice", "upstream_url": "http://localhost:3000"},
        )
        assert resp.status_code == 400

    def test_room_id_rejects_too_long(self, client):
        resp = client.post(
            "/rooms",
            json={"room_id": "x" * 51, "developer_id": "alice", "upstream_url": "http://localhost:3000"},
        )
        assert resp.status_code in (400, 422)

    def test_developer_id_rejects_special_chars(self, client):
        resp = client.post(
            "/rooms",
            json={"room_id": "valid-room", "developer_id": "al@ce!", "upstream_url": "http://localhost:3000"},
        )
        assert resp.status_code == 400

    def test_commit_hash_rejects_short(self, client):
        data = _create_room(client, "val-hash", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms/val-hash/commits",
            json={"developer_id": "alice", "commit_hash": "abc", "branch": "main", "message": "x"},
            headers=_auth(data["member_token"]),
        )
        assert resp.status_code in (400, 422)

    def test_commit_hash_rejects_uppercase(self, client):
        data = _create_room(client, "val-hash2", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms/val-hash2/commits",
            json={"developer_id": "alice", "commit_hash": "ABCDEF0", "branch": "main", "message": "x"},
            headers=_auth(data["member_token"]),
        )
        assert resp.status_code == 400

    def test_empty_message_rejected(self, client):
        data = _create_room(client, "val-msg", "alice", "http://localhost:3000")
        resp = client.post(
            "/rooms/val-msg/commits",
            json={"developer_id": "alice", "commit_hash": "aaa1111", "branch": "main", "message": ""},
            headers=_auth(data["member_token"]),
        )
        assert resp.status_code == 422

    def test_missing_required_fields_rejected(self, client):
        resp = client.post("/rooms", json={"room_id": "x"})
        assert resp.status_code == 422


# ---------------------------------------------------------------------------
# 10. Room listing (admin view)
# ---------------------------------------------------------------------------

class TestRoomListing:

    def test_list_rooms_returns_summaries(self, client):
        _create_room(client, "list-a", "alice", "http://localhost:3000")
        _create_room(client, "list-b", "bob", "http://localhost:3001")

        resp = client.get("/rooms")
        assert resp.status_code == 200
        rooms = resp.json()
        room_ids = {r["room_id"] for r in rooms}
        assert "list-a" in room_ids
        assert "list-b" in room_ids

        for r in rooms:
            assert "created_at" in r
            assert "creator" in r
            assert "member_count" in r
            assert "live_count" in r
            assert "commit_count" in r


# ---------------------------------------------------------------------------
# 11. Cache-control and response headers
# ---------------------------------------------------------------------------

class TestResponseHeaders:

    def test_status_response_has_no_cache_headers(self, client):
        _create_room(client, "cache-test", "alice", "http://localhost:3000")
        resp = client.get("/rooms/cache-test/status")
        assert resp.status_code == 200
        assert resp.headers.get("cache-control") == "no-store, max-age=0"
        assert resp.headers.get("pragma") == "no-cache"


# ---------------------------------------------------------------------------
# 12. Health and readiness
# ---------------------------------------------------------------------------

class TestHealthReadiness:

    def test_health_always_200(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}

    def test_ready_200_when_db_connected(self, client):
        resp = client.get("/ready")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ready"}

    def test_landing_page_returns_html(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
        assert "MACT" in resp.text
        assert "Mirrored Active Collaborative Tunnel" in resp.text
        assert "https://github.com/int33k/M-ACT" in resp.text
        assert "pip install mact-cli" in resp.text


# ---------------------------------------------------------------------------
# 13. Rejoin (developer re-joining updates their upstream_url and token)
# ---------------------------------------------------------------------------

class TestRejoin:

    def test_rejoin_updates_upstream_and_token(self, client):
        data = _create_room(client, "rejoin-room", "alice", "http://localhost:3000")
        bob_data = _join_room(client, "rejoin-room", "bob", "http://bob-old:3001", data["join_secret"])
        old_token = bob_data["member_token"]

        bob_data2 = _join_room(client, "rejoin-room", "bob", "http://bob-new:4001", data["join_secret"])
        new_token = bob_data2["member_token"]

        assert old_token != new_token

        status = _get_status(client, "rejoin-room")
        assert len(status["participants"]) == 2
        bob_p = next(p for p in status["participants"] if p["developer_id"] == "bob")
        assert bob_p["upstream_url"] == "http://bob-new:4001"

        _report_commit(client, "rejoin-room", "bob", new_token, "bbb1111")
        status2 = _get_status(client, "rejoin-room")
        assert status2["active_upstream"] == "http://bob-new:4001"

        resp = client.post(
            "/rooms/rejoin-room/commits",
            json={"developer_id": "bob", "commit_hash": "bbb2222", "branch": "main", "message": "x"},
            headers=_auth(old_token),
        )
        assert resp.status_code == 403
