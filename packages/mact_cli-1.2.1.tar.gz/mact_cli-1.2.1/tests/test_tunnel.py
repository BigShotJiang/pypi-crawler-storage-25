"""Tests for tunnel config generation and lifecycle (mocked subprocess)."""

from unittest.mock import MagicMock, patch

import pytest

from mact.tunnel.frpc import FrpcTunnel


def test_public_url_format():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="tunnel.m-act.live",
    )
    assert t.public_url == "http://alice-demo.tunnel.m-act.live"


def test_public_url_with_custom_port():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="localhost",
        vhost_http_port=18180,
    )
    assert t.public_url == "http://alice-demo.localhost:18180"


def test_proxy_name():
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="bob")
    assert t.proxy_name == "mact-bob-demo"


def test_generate_config_contains_essentials():
    t = FrpcTunnel(
        local_port=4000,
        room_id="proj",
        developer_id="carol",
        server_addr="frp.example.com",
        server_port=7777,
        auth_token="secret123",
        vhost_domain="tunnel.example.com",
    )
    cfg = t.generate_config()
    assert 'serverAddr = "frp.example.com"' in cfg
    assert "serverPort = 7777" in cfg
    assert 'auth.token = "secret123"' in cfg
    assert "localPort = 4000" in cfg
    assert "carol-proj.tunnel.example.com" in cfg


def test_generate_config_no_auth_token():
    t = FrpcTunnel(
        local_port=3000, room_id="demo", developer_id="alice", auth_token=""
    )
    cfg = t.generate_config()
    assert "auth.token" not in cfg


def test_is_running_initially_false():
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    assert t.is_running() is False


@patch(
    "mact.tunnel.frpc.ensure_frpc_executable",
    side_effect=OSError("simulated frpc unavailable"),
)
def test_start_raises_when_frpc_unavailable(mock_ensure):
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    with pytest.raises(OSError, match="simulated frpc unavailable"):
        t.start()


@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("subprocess.Popen")
def test_start_spawns_frpc(mock_popen, mock_ensure, tmp_path):
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_popen.return_value = mock_proc

    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    t.start()

    assert mock_popen.called
    call_args = mock_popen.call_args
    assert "/usr/bin/frpc" in call_args[0][0][0]
    assert t.is_running() is True

    t.stop()
    mock_proc.send_signal.assert_called()
