from mact.server.subdomain import parse_room_from_host, should_rewrite_subdomain_path


def test_parse_room_subdomain():
    assert parse_room_from_host("al-shifa.m-act.live", "m-act.live") == "al-shifa"
    assert parse_room_from_host("al_shifa.m-act.live", "m-act.live") == "al_shifa"
    assert parse_room_from_host("m-act.live", "m-act.live") is None
    assert parse_room_from_host("www.m-act.live", "m-act.live") is None
    assert parse_room_from_host("api.m-act.live", "m-act.live") is None


def test_parse_room_localhost_domain():
    assert parse_room_from_host("e2e_test.localhost", "localhost") == "e2e_test"
    assert parse_room_from_host("myroom.localhost", "localhost") == "myroom"
    assert parse_room_from_host("localhost", "localhost") is None
    assert parse_room_from_host("www.localhost", "localhost") is None


def test_parse_room_strips_port_from_host():
    """parse_room_from_host receives hostname only (no port); middleware strips port."""
    assert parse_room_from_host("myroom.m-act.live", "m-act.live") == "myroom"


def test_should_rewrite_skips_dashboard_and_health():
    assert should_rewrite_subdomain_path("/dashboard") is False
    assert should_rewrite_subdomain_path("/dashboard/extra") is False
    assert should_rewrite_subdomain_path("/health") is False
    assert should_rewrite_subdomain_path("/ready") is False
    assert should_rewrite_subdomain_path("/internal/foo") is False
    assert should_rewrite_subdomain_path("/rooms/foo/status") is False
    assert should_rewrite_subdomain_path("/rooms/foo/events") is False
    assert should_rewrite_subdomain_path("/live") is False
    assert should_rewrite_subdomain_path("/") is True
    assert should_rewrite_subdomain_path("/foo") is True
