from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from mact.db.models import CommitRow, Room, RoomMember
from mact.security import verify_token


# ---------------------------------------------------------------------------
# Room CRUD
# ---------------------------------------------------------------------------

def create_room(
    db: Session,
    room_id: str,
    developer_id: str,
    upstream_url: str,
    *,
    join_secret_hash: str,
    admin_token_hash: str,
    member_token_hash: str,
) -> None:
    existing = db.scalar(select(Room).where(Room.room_id == room_id))
    if existing is not None:
        raise ValueError("room already exists")
    now = datetime.now(timezone.utc)
    room = Room(
        room_id=room_id,
        created_at=now,
        join_secret_hash=join_secret_hash,
        admin_token_hash=admin_token_hash,
        creator_developer_id=developer_id,
    )
    db.add(room)
    db.add(
        RoomMember(
            room_id=room_id,
            developer_id=developer_id,
            upstream_url=upstream_url,
            connected=True,
            last_seen_at=now,
            member_token_hash=member_token_hash,
        )
    )
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise ValueError("room already exists")


def join_room(
    db: Session,
    room_id: str,
    developer_id: str,
    upstream_url: str,
    *,
    member_token_hash: str,
) -> None:
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None:
        raise KeyError("room not found")
    now = datetime.now(timezone.utc)
    member = db.scalar(
        select(RoomMember).where(
            RoomMember.room_id == room_id,
            RoomMember.developer_id == developer_id,
        )
    )
    if member is None:
        db.add(
            RoomMember(
                room_id=room_id,
                developer_id=developer_id,
                upstream_url=upstream_url,
                connected=True,
                last_seen_at=now,
                member_token_hash=member_token_hash,
            )
        )
    else:
        member.upstream_url = upstream_url
        member.connected = True
        member.last_seen_at = now
        member.member_token_hash = member_token_hash
    db.commit()


# ---------------------------------------------------------------------------
# Commits
# ---------------------------------------------------------------------------

def add_commit(
    db: Session,
    room_id: str,
    commit_hash: str,
    branch: str,
    message: str,
    developer_id: str,
) -> bool:
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None:
        raise KeyError("room not found")
    member = db.scalar(
        select(RoomMember).where(
            RoomMember.room_id == room_id,
            RoomMember.developer_id == developer_id,
        )
    )
    if member is None:
        raise ValueError("developer is not a member")
    now = datetime.now(timezone.utc)
    row = CommitRow(
        room_id=room_id,
        commit_hash=commit_hash,
        branch=branch,
        message=message,
        developer_id=developer_id,
        server_received_at=now,
    )
    db.add(row)
    try:
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        return False


def update_commit_comment(
    db: Session, room_id: str, commit_hash: str, comment: str | None
) -> bool:
    row = db.scalar(
        select(CommitRow).where(
            CommitRow.room_id == room_id,
            CommitRow.commit_hash == commit_hash,
        )
    )
    if row is None:
        return False
    row.admin_comment = comment
    row.comment_updated_at = datetime.now(timezone.utc)
    db.commit()
    return True


# ---------------------------------------------------------------------------
# Presence
# ---------------------------------------------------------------------------

def heartbeat_member(
    db: Session,
    room_id: str,
    developer_id: str,
    upstream_url: str | None = None,
) -> None:
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None:
        raise KeyError("room not found")
    member = db.scalar(
        select(RoomMember).where(
            RoomMember.room_id == room_id,
            RoomMember.developer_id == developer_id,
        )
    )
    if member is None:
        raise KeyError("member not found")
    member.connected = True
    member.last_seen_at = datetime.now(timezone.utc)
    if upstream_url is not None:
        member.upstream_url = upstream_url
    db.commit()


def disconnect_member(db: Session, room_id: str, developer_id: str) -> None:
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None:
        raise KeyError("room not found")
    member = db.scalar(
        select(RoomMember).where(
            RoomMember.room_id == room_id,
            RoomMember.developer_id == developer_id,
        )
    )
    if member is None:
        raise KeyError("member not found")
    member.connected = False
    db.commit()


# ---------------------------------------------------------------------------
# Security verification
# ---------------------------------------------------------------------------

def verify_join_secret(db: Session, room_id: str, token: str) -> bool:
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None or not room.join_secret_hash:
        return False
    return verify_token(token, room.join_secret_hash)


def verify_member_token(
    db: Session, room_id: str, developer_id: str, token: str
) -> bool:
    member = db.scalar(
        select(RoomMember).where(
            RoomMember.room_id == room_id,
            RoomMember.developer_id == developer_id,
        )
    )
    if member is None or not member.member_token_hash:
        return False
    return verify_token(token, member.member_token_hash)


def verify_admin_token(db: Session, room_id: str, token: str) -> bool:
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None or not room.admin_token_hash:
        return False
    return verify_token(token, room.admin_token_hash)


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------

def _as_utc_aware(dt: datetime) -> datetime:
    """SQLite returns naive datetimes; Postgres returns aware — normalize for compares."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _is_member_live(member: RoomMember, now: datetime, ttl_seconds: int) -> bool:
    if not member.connected:
        return False
    seen = _as_utc_aware(member.last_seen_at)
    return seen >= (now - timedelta(seconds=ttl_seconds))


def _resolve_active_from_loaded(
    commits: list[CommitRow],
    members_by_dev: dict[str, RoomMember],
    now: datetime,
    ttl_seconds: int,
) -> str | None:
    """Resolve active upstream using already-loaded commits and members."""
    for c in commits:
        m = members_by_dev.get(c.developer_id)
        if m and _is_member_live(m, now, ttl_seconds):
            return m.upstream_url
    for m in members_by_dev.values():
        if _is_member_live(m, now, ttl_seconds):
            return m.upstream_url
    return None


def get_room_status(
    db: Session, room_id: str, presence_ttl_seconds: int = 60
) -> dict | None:
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None:
        return None
    members = db.scalars(
        select(RoomMember).where(RoomMember.room_id == room_id)
    ).all()
    all_commits = db.scalars(
        select(CommitRow)
        .where(CommitRow.room_id == room_id)
        .order_by(CommitRow.server_received_at.desc())
    ).all()
    latest = all_commits[0] if all_commits else None
    now = datetime.now(timezone.utc)
    members_by_dev = {m.developer_id: m for m in members}
    active = _resolve_active_from_loaded(
        all_commits, members_by_dev, now, presence_ttl_seconds
    )
    return {
        "room_id": room.room_id,
        "participants": [
            {
                "developer_id": m.developer_id,
                "upstream_url": m.upstream_url,
                "connected": _is_member_live(m, now, presence_ttl_seconds),
                "last_seen_at": m.last_seen_at.isoformat(),
            }
            for m in members
        ],
        "latest_commit": (
            {
                "commit_hash": latest.commit_hash,
                "branch": latest.branch,
                "message": latest.message,
                "developer_id": latest.developer_id,
                "server_received_at": latest.server_received_at.isoformat(),
                "admin_comment": latest.admin_comment,
            }
            if latest
            else None
        ),
        "commits": [
            {
                "commit_hash": c.commit_hash,
                "branch": c.branch,
                "message": c.message,
                "developer_id": c.developer_id,
                "server_received_at": c.server_received_at.isoformat(),
                "admin_comment": c.admin_comment,
            }
            for c in all_commits
        ],
        "active_upstream": active,
    }


def resolve_active_upstream(
    db: Session,
    room_id: str,
    presence_ttl_seconds: int = 60,
    now: datetime | None = None,
) -> str | None:
    now = now or datetime.now(timezone.utc)
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None:
        return None
    commits = db.scalars(
        select(CommitRow)
        .where(CommitRow.room_id == room_id)
        .order_by(CommitRow.server_received_at.desc())
    ).all()
    members_by_dev: dict[str, RoomMember] = {
        m.developer_id: m
        for m in db.scalars(
            select(RoomMember).where(RoomMember.room_id == room_id)
        ).all()
    }
    return _resolve_active_from_loaded(commits, members_by_dev, now, presence_ttl_seconds)


def list_rooms(db: Session, presence_ttl_seconds: int = 60) -> list[dict]:
    """Return a summary of all rooms (for admin listing)."""
    rooms = db.scalars(select(Room).order_by(Room.created_at.desc())).all()
    now = datetime.now(timezone.utc)
    result = []
    for room in rooms:
        member_count = db.scalar(
            select(func.count()).where(RoomMember.room_id == room.room_id)
        )
        members = db.scalars(
            select(RoomMember).where(RoomMember.room_id == room.room_id)
        ).all()
        live_count = sum(
            1 for m in members if _is_member_live(m, now, presence_ttl_seconds)
        )
        commit_count = db.scalar(
            select(func.count()).where(CommitRow.room_id == room.room_id)
        )
        result.append({
            "room_id": room.room_id,
            "created_at": room.created_at.isoformat(),
            "creator": room.creator_developer_id,
            "member_count": member_count or 0,
            "live_count": live_count,
            "commit_count": commit_count or 0,
        })
    return result


def delete_room(db: Session, room_id: str) -> bool:
    """Delete a room; members and commits are removed by ON DELETE CASCADE."""
    room = db.scalar(select(Room).where(Room.room_id == room_id))
    if room is None:
        return False
    db.delete(room)
    db.commit()
    return True


def ping_db(db: Session) -> None:
    db.execute(text("SELECT 1"))
