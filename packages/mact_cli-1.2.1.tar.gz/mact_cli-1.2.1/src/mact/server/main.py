from __future__ import annotations

import asyncio
import html
import json
import logging
import os
from contextlib import asynccontextmanager
from urllib.parse import urlparse, urlunparse

import httpx
import websockets
import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from mact.db import repository as repo
from mact.db.models import Base
from mact.security import generate_token, hash_token
from mact.server.asgi_subdomain import SubdomainRewriteMiddleware
from mact.server.ratelimit import RATE_LIMITS, RateLimiter, rate_limit_key
from mact.server.realtime import RoomEventBroker, schedule_room_broadcast
from mact.server.settings import load_settings
from mact.validation import BRANCH_RE, DEV_RE, HASH_RE, ROOM_RE

HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
    "host",
}
STRIP_UPSTREAM_HEADERS = HOP_BY_HOP_HEADERS | {"server", "date"}
MIRROR_TIMEOUT = httpx.Timeout(connect=2.0, read=5.0, write=5.0, pool=5.0)
LOGGER = logging.getLogger(__name__)

# Landing page & docs — canonical public source (see README / project-tracking)
MACT_SOURCE_REPO_URL = "https://github.com/int33k/M-ACT"
MACT_FULL_NAME = "Mirrored Active Collaborative Tunnel"


# ---------------------------------------------------------------------------
# Pydantic request models
# ---------------------------------------------------------------------------

class RoomCreateRequest(BaseModel):
    room_id: str = Field(min_length=1, max_length=50)
    developer_id: str = Field(min_length=1, max_length=30)
    upstream_url: str = Field(min_length=1, max_length=2000)


class RoomJoinRequest(BaseModel):
    developer_id: str = Field(min_length=1, max_length=30)
    upstream_url: str = Field(min_length=1, max_length=2000)
    join_secret: str = Field(min_length=1)


class CommitReportRequest(BaseModel):
    developer_id: str = Field(min_length=1, max_length=30)
    commit_hash: str = Field(min_length=7, max_length=40)
    branch: str = Field(min_length=1, max_length=80)
    message: str = Field(min_length=1, max_length=250)


class MemberPresenceRequest(BaseModel):
    developer_id: str = Field(min_length=1, max_length=30)
    upstream_url: str | None = None


class CommitCommentRequest(BaseModel):
    comment: str | None = Field(default=None, max_length=2000)


# ---------------------------------------------------------------------------
# Validators
# ---------------------------------------------------------------------------

def _validate_room_id(room_id: str) -> None:
    if not ROOM_RE.fullmatch(room_id):
        raise HTTPException(status_code=400, detail="invalid room_id")


def _validate_developer_id(developer_id: str) -> None:
    if not DEV_RE.fullmatch(developer_id):
        raise HTTPException(status_code=400, detail="invalid developer_id")


def _validate_commit(commit_hash: str, branch: str) -> None:
    if not HASH_RE.fullmatch(commit_hash):
        raise HTTPException(status_code=400, detail="invalid commit_hash")
    if not BRANCH_RE.fullmatch(branch):
        raise HTTPException(status_code=400, detail="invalid branch")


def _require_bearer(request: Request) -> str:
    auth = request.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="missing authorization")
    return auth[7:]


def _rate_check(request: Request, bucket: str) -> None:
    cfg = RATE_LIMITS.get(bucket)
    if cfg:
        request.app.state.rate_limiter.check(rate_limit_key(request, bucket), cfg)


# ---------------------------------------------------------------------------
# App lifecycle
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = load_settings()
    connect_args: dict = {}
    if settings.database_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
    use_static_pool = (
        settings.database_url.startswith("sqlite") and ":memory:" in settings.database_url
    )
    engine_kw: dict = {"connect_args": connect_args, "pool_pre_ping": True}
    if use_static_pool:
        engine_kw["poolclass"] = StaticPool
        engine_kw["pool_pre_ping"] = False
    engine = create_engine(settings.database_url, **engine_kw)
    if settings.database_url.startswith("sqlite"):

        @event.listens_for(engine, "connect")
        def _sqlite_pragma(dbapi_conn, _connection_record) -> None:
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    if settings.auto_create_tables:
        Base.metadata.create_all(bind=engine)
    app.state.settings = settings
    app.state.SessionLocal = sessionmaker(
        autocommit=False, autoflush=False, bind=engine
    )
    app.state.main_loop = asyncio.get_running_loop()
    app.state.room_broker = RoomEventBroker()
    app.state.mirror_client = httpx.AsyncClient(timeout=MIRROR_TIMEOUT)
    rate_limiter = RateLimiter()
    app.state.rate_limiter = rate_limiter

    async def _periodic_rate_limit_cleanup() -> None:
        while True:
            await asyncio.sleep(300)
            rate_limiter.cleanup(max_age=300.0)

    cleanup_task = asyncio.create_task(_periodic_rate_limit_cleanup())
    yield
    cleanup_task.cancel()
    await app.state.mirror_client.aclose()
    engine.dispose()


def get_db(request: Request):
    SessionLocal = request.app.state.SessionLocal
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


fastapi_app = FastAPI(title="MACT API", version="1.1.0", lifespan=lifespan)


# ---------------------------------------------------------------------------
# Landing page
# ---------------------------------------------------------------------------


def _landing_css() -> str:
    return """<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#070b14;--surface:#111827;--surface2:#1e293b;--surface3:#0f172a;
--border:#1e293b;--text:#e2e8f0;--muted:#94a3b8;--accent:#38bdf8;--accent2:#818cf8;
--green:#34d399;--amber:#f59e0b;--gradient:linear-gradient(135deg,#38bdf8,#818cf8);
--glow:rgba(56,189,248,.12)}
html{scroll-behavior:smooth}
body{font-family:system-ui,-apple-system,'Segoe UI',sans-serif;background:var(--bg);
color:var(--text);min-height:100vh;overflow-x:hidden}
a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}
code{font-family:'SF Mono',Consolas,'Liberation Mono',monospace}

.landing-nav{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:1rem;
padding:1rem 1.5rem;max-width:1100px;margin:0 auto;border-bottom:1px solid rgba(30,41,59,.8);
background:rgba(7,11,20,.85);backdrop-filter:blur(12px)}
.landing-nav .brand{font-weight:800;font-size:1.15rem;letter-spacing:-.03em;
background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
background-clip:text}
.landing-nav .fullname{font-size:clamp(.62rem,2vw,.75rem);color:var(--muted);line-height:1.35;
display:block;flex:1;min-width:0}
.landing-nav .spacer{flex:1}
.landing-nav a.nav-cta{font-size:.85rem;font-weight:600;color:var(--accent);
padding:.4rem .85rem;border:1px solid rgba(56,189,248,.35);border-radius:9999px}
.landing-nav a.nav-cta:hover{text-decoration:none;background:rgba(56,189,248,.1)}

.hero{text-align:center;padding:4rem 1.5rem 3.5rem;position:relative;overflow:hidden}
.hero::before{content:'';position:absolute;inset:0;
background:
radial-gradient(ellipse 80% 50% at 50% -20%,var(--glow),transparent 55%),
radial-gradient(ellipse 60% 40% at 100% 50%,rgba(129,140,248,.08),transparent 50%),
radial-gradient(ellipse 50% 30% at 0% 80%,rgba(56,189,248,.06),transparent 45%);
pointer-events:none}
.hero-inner{position:relative;max-width:720px;margin:0 auto}
.badge{display:inline-flex;align-items:center;gap:.4rem;padding:.35rem .85rem;margin-bottom:1.25rem;
font-size:.75rem;font-weight:600;letter-spacing:.04em;text-transform:uppercase;
color:#a5b4fc;background:rgba(99,102,241,.12);border:1px solid rgba(99,102,241,.25);
border-radius:9999px}
.hero h1{font-size:clamp(2.75rem,8vw,4.25rem);font-weight:800;line-height:1.05;
background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
background-clip:text;margin-bottom:.6rem;letter-spacing:-.04em}
.hero h2.fullname-line{font-size:clamp(1rem,2.4vw,1.25rem);font-weight:600;color:#cbd5e1;
line-height:1.45;margin:0 auto 1rem;max-width:36rem;letter-spacing:.01em}
.hero .subtitle{font-size:clamp(1rem,2.4vw,1.2rem);color:var(--muted);max-width:34rem;
margin:0 auto 1.75rem;line-height:1.65}
.hero-actions{display:flex;gap:.85rem;justify-content:center;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;gap:.5rem;padding:.8rem 1.6rem;border-radius:.6rem;
font-weight:600;font-size:.95rem;transition:transform .15s ease,box-shadow .15s ease,opacity .15s}
.btn-primary{background:var(--gradient);color:#050a12;box-shadow:0 4px 24px rgba(56,189,248,.25)}
.btn-primary:hover{opacity:.95;text-decoration:none;transform:translateY(-2px);
box-shadow:0 8px 32px rgba(56,189,248,.35)}
.btn-secondary{border:1px solid var(--border);color:var(--text);background:var(--surface)}
.btn-secondary:hover{border-color:var(--accent);text-decoration:none;transform:translateY(-1px)}

.stats{margin:1.3rem auto 0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:.8rem}
.stat{background:rgba(15,23,42,.7);border:1px solid rgba(51,65,85,.65);border-radius:.7rem;padding:.8rem}
.stat strong{display:block;font-size:1.02rem;color:#f8fafc}
.stat span{display:block;font-size:.8rem;color:var(--muted);margin-top:.2rem}

.install-bar{margin:2.25rem auto 0;max-width:460px;background:var(--surface);
border:1px solid var(--border);border-radius:.65rem;padding:.85rem 1.1rem;
font-family:'SF Mono',Consolas,'Liberation Mono',monospace;font-size:.88rem;
color:var(--green);display:flex;align-items:center;justify-content:space-between;gap:.5rem}
.install-bar code{flex:1;text-align:left}
.install-bar button{background:none;border:1px solid var(--border);color:var(--muted);
border-radius:.3rem;padding:.3rem .55rem;cursor:pointer;font-size:.72rem;transition:all .15s}
.install-bar button:hover{color:var(--text);border-color:var(--accent)}
.install-bar button.copied{color:var(--green);border-color:var(--green)}

section{max-width:960px;margin:0 auto;padding:3rem 1.5rem}
.section-title{font-size:clamp(1.35rem,3vw,1.65rem);font-weight:700;margin-bottom:.35rem}
.section-desc{color:var(--muted);margin-bottom:2rem;font-size:1.02rem;line-height:1.55}

.features{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1.15rem}
.feature{background:linear-gradient(145deg,rgba(17,24,39,.9),rgba(15,23,42,.6));
border:1px solid var(--border);border-radius:.85rem;padding:1.5rem 1.35rem;
transition:border-color .2s,transform .2s,box-shadow .2s}
.feature:hover{border-color:rgba(56,189,248,.35);transform:translateY(-2px);
box-shadow:0 12px 40px rgba(0,0,0,.25)}
.feature-icon{font-size:1.45rem;margin-bottom:.65rem;display:block;filter:grayscale(.15)}
.feature h3{font-size:1.02rem;font-weight:600;margin-bottom:.45rem;color:#f1f5f9}
.feature p{color:var(--muted);font-size:.875rem;line-height:1.55}

.how-it-works{counter-reset:step;background:rgba(15,23,42,.35);border-radius:1rem;
padding:1.5rem 1.25rem;border:1px solid rgba(30,41,59,.6)}
.step{display:flex;gap:1.15rem;padding:1.1rem 0;border-bottom:1px solid rgba(51,65,85,.5)}
.step:last-child{border-bottom:none}
.step::before{counter-increment:step;content:counter(step);
flex-shrink:0;width:2rem;height:2rem;border-radius:50%;
background:var(--gradient);color:#050a12;display:flex;align-items:center;
justify-content:center;font-weight:800;font-size:.8rem}
.step-content h3{font-size:.95rem;font-weight:600;margin-bottom:.25rem;color:#e2e8f0}
.step-content p{color:var(--muted);font-size:.875rem;line-height:1.55}
.step-content code{background:var(--surface2);padding:.15rem .4rem;border-radius:.25rem;
font-size:.8rem;color:var(--green)}

.split{display:grid;grid-template-columns:1.2fr .8fr;gap:1.2rem}
.panel{background:var(--surface3);border:1px solid rgba(51,65,85,.65);border-radius:.9rem;padding:1.2rem}
.panel h3{font-size:1rem;margin-bottom:.55rem}
.panel p,.panel li{color:var(--muted);font-size:.9rem;line-height:1.55}
.panel ul{list-style:none;display:grid;gap:.55rem}
.panel li code{background:var(--surface2);padding:.12rem .35rem;border-radius:.25rem;color:var(--green)}

.use-cases{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:.85rem}
.use-case{background:rgba(17,24,39,.7);border:1px solid rgba(51,65,85,.6);border-radius:.8rem;padding:1rem}
.use-case h4{font-size:.95rem;margin-bottom:.35rem}
.use-case p{font-size:.85rem;color:var(--muted);line-height:1.55}

.faq{display:grid;gap:.7rem}
.faq details{background:rgba(15,23,42,.45);border:1px solid rgba(51,65,85,.55);border-radius:.7rem;padding:.85rem 1rem}
.faq summary{cursor:pointer;font-weight:600;color:#dbeafe}
.faq p{margin-top:.55rem;color:var(--muted);font-size:.88rem;line-height:1.6}

.final-cta{background:linear-gradient(145deg,rgba(56,189,248,.14),rgba(129,140,248,.12));
border:1px solid rgba(129,140,248,.35);border-radius:1rem;padding:1.5rem;text-align:center}
.final-cta p{color:#dbeafe;max-width:42rem;margin:.7rem auto 1.1rem;line-height:1.6}

footer{text-align:center;padding:2.75rem 1.5rem 3rem;color:var(--muted);font-size:.78rem;
border-top:1px solid var(--border);margin-top:1rem;line-height:1.7}
footer .footer-title{font-weight:600;color:#cbd5e1;margin-bottom:.35rem;font-size:.85rem}
footer a{color:var(--accent)}
.github-link{word-break:break-all}

@media(max-width:780px){
  .stats{grid-template-columns:1fr}
  .split{grid-template-columns:1fr}
}
</style>"""


def _landing_html() -> str:
    from mact import __version__

    gh = MACT_SOURCE_REPO_URL
    full = MACT_FULL_NAME
    return (
        "<!doctype html>"
        '<html lang="en"><head><meta charset="utf-8"/>'
        '<meta name="viewport" content="width=device-width,initial-scale=1"/>'
        f"<title>MACT — {full}</title>"
        f'<meta name="description" content="MACT ({full}): '
        'share live localhost previews with your team. One command, public URL, real-time sync."/>'
        f"{_landing_css()}"
        "</head><body>"
        '<header class="landing-nav" role="navigation">'
        '<span class="brand">MACT</span>'
        f'<span class="fullname">{full}</span>'
        '<span class="spacer"></span>'
        f'<a class="nav-cta" href="{gh}" rel="noopener noreferrer" target="_blank">Source</a>'
        "</header>"
        '<div class="hero">'
        '<div class="hero-inner">'
        "<h1>M - A C T</h1>"
        f'<h2 class="fullname-line">{full}</h2>'
        '<p class="subtitle">MACT gives your team a stable public preview URL that always points to '
        "the most recently active developer, so reviews happen on real work-in-progress.</p>"
        '<div class="hero-actions">'
        '<a class="btn btn-primary" href="https://pypi.org/project/mact-cli/" rel="noopener noreferrer" target="_blank">'
        "Install from PyPI</a>"
        f'<a class="btn btn-secondary" href="{gh}" rel="noopener noreferrer" target="_blank">'
        "View on GitHub</a>"
        "</div>"
        '<div class="stats">'
        '<div class="stat"><strong>Stable Room URLs</strong><span>Share <code>room.m-act.live</code> with stakeholders instantly.</span></div>'
        '<div class="stat"><strong>Git-Driven Routing</strong><span>Latest commit activity decides who is live.</span></div>'
        '<div class="stat"><strong>Secure Access</strong><span>Join secrets + tokens with SHA-256 hashing.</span></div>'
        "</div>"
        '<div class="install-bar">'
        "<code>pip install mact-cli</code>"
        '<button type="button" onclick="navigator.clipboard.writeText(\'pip install mact-cli\');'
        "this.textContent='Copied!';this.classList.add('copied');"
        "setTimeout(function(){this.textContent='Copy';this.classList.remove('copied');}.bind(this),2000)"
        '">Copy</button>'
        "</div>"
        "</div>"
        "</div>"
        "<section>"
        '<h2 class="section-title">Why Teams Choose MACT</h2>'
        '<p class="section-desc">Built for fast feedback loops, QA sign-off, and async reviews without '
        "waiting for a staging deploy.</p>"
        '<div class="features">'
        '<div class="feature">'
        '<span class="feature-icon">&#127760;</span>'
        "<h3>Stable Public Room URL</h3>"
        "<p>Your localhost gets a live URL like <code>room.m-act.live</code>. "
        "Share it with anyone &mdash; they see exactly what you see.</p>"
        "</div>"
        '<div class="feature">'
        '<span class="feature-icon">&#128260;</span>'
        "<h3>Auto-Switching Mirror</h3>"
        "<p>When the active developer changes, the mirror switches automatically. "
        "Viewers always see the latest build-ready branch without refreshing.</p>"
        "</div>"
        '<div class="feature">'
        '<span class="feature-icon">&#128274;</span>'
        "<h3>Security by Default</h3>"
        "<p>Rooms are protected with join secrets and bearer tokens. "
        "SHA-256 hashed, constant-time verified. No tokens stored in plaintext on the server.</p>"
        "</div>"
        '<div class="feature">'
        '<span class="feature-icon">&#128221;</span>'
        "<h3>Commit Timeline & Comments</h3>"
        "<p>Automatic commit reporting via git hooks. Supervisors can comment on commits "
        "through the dashboard or API.</p>"
        "</div>"
        '<div class="feature">'
        '<span class="feature-icon">&#9889;</span>'
        "<h3>Real-Time Dashboard</h3>"
        "<p>Live status bar, participant list, and commit history &mdash; "
        "all updating in real-time via WebSocket.</p>"
        "</div>"
        '<div class="feature">'
        '<span class="feature-icon">&#128295;</span>'
        "<h3>Zero-Hassle Tunneling</h3>"
        "<p>Built-in frpc integration. MACT downloads and manages the tunnel binary "
        "automatically on first use.</p>"
        "</div>"
        "</div>"
        "</section>"
        "<section>"
        '<h2 class="section-title">How It Works</h2>'
        '<p class="section-desc">A practical flow from local app to shareable preview in minutes.</p>'
        '<div class="how-it-works">'
        '<div class="step"><div class="step-content">'
        "<h3>Set your identity</h3>"
        "<p>Run <code>mact init --developer yourname</code> once to configure who you are.</p>"
        "</div></div>"
        '<div class="step"><div class="step-content">'
        "<h3>Create a room &amp; go live</h3>"
        "<p>From your git project, run <code>mact create --room myproject --port 3000</code>. "
        "This registers the room and starts the tunnel and heartbeat. "
        "Share the join secret with collaborators.</p>"
        "</div></div>"
        '<div class="step"><div class="step-content">'
        "<h3>Collaborators join</h3>"
        "<p>Others run <code>mact join --room myproject --port 3001 --secret &lt;join-secret&gt;</code> "
        "from their repo; that starts their tunnel and heartbeat too. The mirror auto-switches to the "
        "most recently active developer.</p>"
        "</div></div>"
        "</div>"
        "</section>"
        "<section>"
        '<h2 class="section-title">Quickstart Cheatsheet</h2>'
        '<p class="section-desc">Copy-paste commands for the most common first session.</p>'
        '<div class="split">'
        '<div class="panel">'
        "<h3>Host a room</h3>"
        "<ul>"
        "<li><code>mact init --developer alice</code></li>"
        "<li><code>mact configure-frp --server-addr m-act.live --server-port 7000 --token &lt;frp-token&gt;</code></li>"
        "<li><code>mact create --room myproject --port 3000</code></li>"
        "</ul>"
        "</div>"
        '<div class="panel">'
        "<h3>Join a room</h3>"
        "<ul>"
        "<li><code>mact init --developer bob</code></li>"
        "<li><code>mact join --room myproject --port 3001 --secret &lt;join-secret&gt;</code></li>"
        "<li><code>mact status --room myproject</code></li>"
        "</ul>"
        "</div>"
        "</div>"
        "</section>"
        "<section>"
        '<h2 class="section-title">Best For</h2>'
        '<p class="section-desc">MACT is designed for teams that need rapid visibility into in-progress work.</p>'
        '<div class="use-cases">'
        '<div class="use-case"><h4>Product Reviews</h4><p>Share one stable room URL with PM/Design while developers rotate ownership behind the scenes.</p></div>'
        '<div class="use-case"><h4>QA and UAT</h4><p>Validate fixes instantly on real localhost environments without rebuild-and-deploy cycles.</p></div>'
        '<div class="use-case"><h4>Pair/Mob Sessions</h4><p>Seamlessly hand off who is live by committing and running <code>mact create</code> or <code>mact join</code> from the next developer&rsquo;s machine.</p></div>'
        '<div class="use-case"><h4>Distributed Teams</h4><p>Use commit history and comments to keep cross-time-zone collaboration aligned.</p></div>'
        "</div>"
        "</section>"
        "<section>"
        '<h2 class="section-title">FAQ</h2>'
        '<div class="faq">'
        '<details><summary>Do I need to deploy my app first?</summary><p>No. MACT mirrors directly from localhost through a controlled tunnel.</p></details>'
        '<details><summary>What happens if the active developer goes offline?</summary><p>MACT resolves active upstream by liveness and recent commit activity, then falls back safely when needed.</p></details>'
        '<details><summary>Is MACT only for frontend apps?</summary><p>No. Anything reachable on a local HTTP port can be shared, including APIs, admin panels, and prototypes.</p></details>'
        '<details><summary>Can I self-host?</summary><p>Yes. MACT ships with server extras and deployment docs for Nginx, systemd, FRP, and PostgreSQL setups.</p></details>'
        "</div>"
        "</section>"
        "<section>"
        '<div class="final-cta">'
        "<h2>Start sharing real work, not screenshots</h2>"
        "<p>Install MACT, create a room, and give your team a live review URL within minutes.</p>"
        '<div class="hero-actions">'
        '<a class="btn btn-primary" href="https://pypi.org/project/mact-cli/" rel="noopener noreferrer" target="_blank">Get mact-cli</a>'
        f'<a class="btn btn-secondary" href="{gh}" rel="noopener noreferrer" target="_blank">Read the source</a>'
        "</div>"
        "</div>"
        "</section>"
        "<footer>"
        f'<p class="footer-title">MACT &mdash; {full}</p>'
        f'<p>v{__version__} &middot; '
        '<a href="https://pypi.org/project/mact-cli/" rel="noopener noreferrer" target="_blank">PyPI</a> &middot; '
        f'<a class="github-link" href="{gh}" rel="noopener noreferrer" target="_blank">{gh}</a> &middot; '
        "MIT License</p>"
        "</footer>"
        "</body></html>"
    )


@fastapi_app.get("/", response_class=HTMLResponse)
def landing_page() -> HTMLResponse:
    # No-store so browsers/CDNs do not keep stale HTML after a server deploy.
    return HTMLResponse(
        content=_landing_html(),
        headers={
            "Cache-Control": "no-store, max-age=0, must-revalidate",
            "Pragma": "no-cache",
        },
    )


# ---------------------------------------------------------------------------
# Health / readiness
# ---------------------------------------------------------------------------

@fastapi_app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@fastapi_app.get("/ready")
def ready(request: Request) -> dict[str, str]:
    SessionLocal = request.app.state.SessionLocal
    db = SessionLocal()
    try:
        repo.ping_db(db)
    except Exception as exc:
        raise HTTPException(
            status_code=503, detail="database not ready"
        ) from exc
    finally:
        db.close()
    return {"status": "ready"}


# ---------------------------------------------------------------------------
# Room management
# ---------------------------------------------------------------------------

@fastapi_app.get("/rooms")
def list_rooms(request: Request, db: Session = Depends(get_db)) -> list[dict]:
    return repo.list_rooms(
        db,
        presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
    )


@fastapi_app.post("/rooms")
def create_room(
    payload: RoomCreateRequest, request: Request, db: Session = Depends(get_db)
) -> dict:
    _rate_check(request, "/rooms")
    _validate_room_id(payload.room_id)
    _validate_developer_id(payload.developer_id)

    join_secret = generate_token()
    admin_token = generate_token()
    member_token = generate_token()

    try:
        repo.create_room(
            db,
            payload.room_id,
            payload.developer_id,
            payload.upstream_url,
            join_secret_hash=hash_token(join_secret),
            admin_token_hash=hash_token(admin_token),
            member_token_hash=hash_token(member_token),
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    schedule_room_broadcast(fastapi_app, payload.room_id)
    return {
        "room_id": payload.room_id,
        "join_secret": join_secret,
        "admin_token": admin_token,
        "member_token": member_token,
    }


@fastapi_app.post("/rooms/{room_id}/join")
def join_room(
    room_id: str,
    payload: RoomJoinRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict:
    _rate_check(request, "join")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)

    if not repo.verify_join_secret(db, room_id, payload.join_secret):
        raise HTTPException(status_code=403, detail="invalid join secret")

    member_token = generate_token()
    try:
        repo.join_room(
            db,
            room_id,
            payload.developer_id,
            payload.upstream_url,
            member_token_hash=hash_token(member_token),
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "joined", "member_token": member_token}


@fastapi_app.delete("/rooms/{room_id}")
def delete_room(
    room_id: str,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, str]:
    _validate_room_id(room_id)

    token = _require_bearer(request)
    if not repo.verify_admin_token(db, room_id, token):
        raise HTTPException(status_code=403, detail="invalid admin token")

    if not repo.delete_room(db, room_id):
        raise HTTPException(status_code=404, detail="room not found")
    return {"status": "deleted"}


# ---------------------------------------------------------------------------
# Commits
# ---------------------------------------------------------------------------

@fastapi_app.post("/rooms/{room_id}/commits")
def report_commit(
    room_id: str,
    payload: CommitReportRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, bool]:
    _rate_check(request, "commits")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)
    _validate_commit(payload.commit_hash, payload.branch)

    token = _require_bearer(request)
    if not repo.verify_member_token(db, room_id, payload.developer_id, token):
        raise HTTPException(status_code=403, detail="invalid member token")

    try:
        inserted = repo.add_commit(
            db,
            room_id=room_id,
            commit_hash=payload.commit_hash,
            branch=payload.branch,
            message=payload.message,
            developer_id=payload.developer_id,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    schedule_room_broadcast(fastapi_app, room_id)
    return {"inserted": inserted}


@fastapi_app.patch("/rooms/{room_id}/commits/{commit_hash}/comment")
def update_comment(
    room_id: str,
    commit_hash: str,
    payload: CommitCommentRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, str]:
    _rate_check(request, "comment")
    _validate_room_id(room_id)

    token = _require_bearer(request)
    if not repo.verify_admin_token(db, room_id, token):
        raise HTTPException(status_code=403, detail="invalid admin token")

    if not repo.update_commit_comment(db, room_id, commit_hash, payload.comment):
        raise HTTPException(status_code=404, detail="commit not found")
    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "updated"}


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

@fastapi_app.get("/rooms/{room_id}/status")
def room_status(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> dict:
    _validate_room_id(room_id)
    payload = repo.get_room_status(
        db,
        room_id,
        presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
    )
    if payload is None:
        raise HTTPException(status_code=404, detail="room not found")
    return JSONResponse(
        content=payload,
        headers={
            "Cache-Control": "no-store, max-age=0",
            "Pragma": "no-cache",
        },
    )


@fastapi_app.get("/internal/rooms/{room_id}/active-upstream")
def active_upstream(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> dict[str, str | None]:
    _validate_room_id(room_id)
    return {
        "active_upstream": repo.resolve_active_upstream(
            db,
            room_id,
            presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
        )
    }


# ---------------------------------------------------------------------------
# Presence
# ---------------------------------------------------------------------------

@fastapi_app.post("/rooms/{room_id}/presence/heartbeat")
def heartbeat(
    room_id: str,
    payload: MemberPresenceRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, str]:
    _rate_check(request, "heartbeat")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)

    token = _require_bearer(request)
    if not repo.verify_member_token(db, room_id, payload.developer_id, token):
        raise HTTPException(status_code=403, detail="invalid member token")

    try:
        repo.heartbeat_member(
            db, room_id, payload.developer_id, upstream_url=payload.upstream_url
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "ok"}


@fastapi_app.post("/rooms/{room_id}/presence/disconnect")
def disconnect(
    room_id: str,
    payload: MemberPresenceRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, str]:
    _rate_check(request, "disconnect")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)

    token = _require_bearer(request)
    if not repo.verify_member_token(db, room_id, payload.developer_id, token):
        raise HTTPException(status_code=403, detail="invalid member token")

    try:
        repo.disconnect_member(db, room_id, payload.developer_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Realtime (WebSocket)
# ---------------------------------------------------------------------------


@fastapi_app.websocket("/rooms/{room_id}/events")
async def room_events_ws(websocket: WebSocket, room_id: str) -> None:
    _validate_room_id(room_id)
    app = websocket.app
    SessionLocal = app.state.SessionLocal
    db = SessionLocal()
    try:
        payload = repo.get_room_status(
            db,
            room_id,
            presence_ttl_seconds=app.state.settings.presence_ttl_seconds,
        )
    finally:
        db.close()
    if payload is None:
        await websocket.close(code=1008)
        return

    await websocket.accept()
    broker: RoomEventBroker = app.state.room_broker
    await broker.connect(room_id, websocket)
    await websocket.send_json({"type": "room_status", "payload": payload})
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await broker.disconnect(room_id, websocket)


# ---------------------------------------------------------------------------
# Mirror proxy
# ---------------------------------------------------------------------------

def _build_target_url(active_upstream: str, path: str, query: str) -> str:
    base = active_upstream.rstrip("/")
    suffix = f"/{path}" if path else ""
    if query:
        return f"{base}{suffix}?{query}"
    return f"{base}{suffix}"


def _http_url_to_ws(url: str) -> str:
    p = urlparse(url)
    scheme = "wss" if p.scheme == "https" else "ws"
    return urlunparse((scheme, p.netloc, p.path, "", p.query, ""))


async def _mirror_websocket_proxy(
    websocket: WebSocket, room_id: str, path: str
) -> None:
    _validate_room_id(room_id)
    SessionLocal = websocket.app.state.SessionLocal
    db = SessionLocal()
    try:
        active = repo.resolve_active_upstream(
            db,
            room_id,
            presence_ttl_seconds=websocket.app.state.settings.presence_ttl_seconds,
        )
    finally:
        db.close()

    if not active:
        await websocket.close(code=1008)
        return

    raw_q = websocket.scope.get("query_string", b"")
    q = raw_q.decode("latin-1") if raw_q else ""
    target_http = _build_target_url(active, path, q)
    ws_url = _http_url_to_ws(target_http)

    extra_headers: list[tuple[str, str]] = []
    for name in ("cookie", "authorization", "sec-websocket-protocol"):
        v = websocket.headers.get(name)
        if v:
            extra_headers.append((name, v))

    try:
        async with websockets.connect(
            ws_url,
            open_timeout=2.0,
            max_size=2**30,
            extra_headers=extra_headers or None,
        ) as upstream:
            await websocket.accept()

            async def client_to_upstream() -> None:
                try:
                    while True:
                        msg = await websocket.receive()
                        mtype = msg.get("type")
                        if mtype == "websocket.disconnect":
                            break
                        if mtype != "websocket.receive":
                            continue
                        if "text" in msg:
                            await upstream.send(msg["text"])
                        elif "bytes" in msg:
                            await upstream.send(msg["bytes"])
                except WebSocketDisconnect:
                    pass

            async def upstream_to_client() -> None:
                try:
                    async for message in upstream:
                        if isinstance(message, str):
                            await websocket.send_text(message)
                        else:
                            await websocket.send_bytes(message)
                except Exception:
                    LOGGER.warning(
                        "Upstream websocket relay failed for room_id=%s path=%s",
                        room_id,
                        path,
                        exc_info=True,
                    )

            _done, pending = await asyncio.wait(
                [
                    asyncio.create_task(client_to_upstream()),
                    asyncio.create_task(upstream_to_client()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
    except Exception:
        LOGGER.warning(
            "Mirror websocket proxy failed for room_id=%s path=%s",
            room_id,
            path,
            exc_info=True,
        )
        try:
            await websocket.close(code=1011)
        except Exception:
            pass


@fastapi_app.websocket("/r/{room_id}")
async def mirror_room_websocket_root(websocket: WebSocket, room_id: str) -> None:
    await _mirror_websocket_proxy(websocket, room_id, "")


@fastapi_app.websocket("/r/{room_id}/{path:path}")
async def mirror_room_websocket_path(
    websocket: WebSocket, room_id: str, path: str
) -> None:
    await _mirror_websocket_proxy(websocket, room_id, path)


def _offline_page(room_id: str) -> str:
    safe = html.escape(room_id, quote=True)
    return (
        "<!doctype html>"
        '<html lang="en"><head><meta charset="utf-8"/>'
        '<meta name="viewport" content="width=device-width,initial-scale=1"/>'
        "<title>MACT — Waiting for developer</title>"
        "<style>"
        "*{margin:0;padding:0;box-sizing:border-box}"
        "body{font-family:system-ui,-apple-system,sans-serif;"
        "background:#0a0e1a;color:#e2e8f0;min-height:100vh;"
        "display:flex;align-items:center;justify-content:center;text-align:center}"
        ".wrap{max-width:480px;padding:2rem}"
        ".icon{font-size:3rem;margin-bottom:1.5rem;opacity:.7}"
        "h1{font-size:1.5rem;font-weight:700;margin-bottom:.75rem;"
        "background:linear-gradient(135deg,#38bdf8,#818cf8);"
        "-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
        "background-clip:text}"
        "p{color:#94a3b8;line-height:1.6;margin-bottom:1rem}"
        "code{background:#1e293b;padding:.2rem .5rem;border-radius:.25rem;"
        "font-size:.9rem;color:#38bdf8}"
        ".pulse{animation:pulse 2s ease-in-out infinite}"
        "@keyframes pulse{0%,100%{opacity:.4}50%{opacity:1}}"
        ".hint{font-size:.8rem;color:#64748b;margin-top:1.5rem}"
        "a{color:#38bdf8;text-decoration:none}a:hover{text-decoration:underline}"
        "</style>"
        "</head><body>"
        '<div class="wrap">'
        '<div class="icon">&#9898;</div>'
        f"<h1>Room <code>{safe}</code></h1>"
        '<p>No developer is currently live in this room.</p>'
        '<p class="pulse" style="color:#fbbf24;font-size:.85rem">'
        "Waiting for a developer to connect&hellip;</p>"
        '<p class="hint">Developers: from a git project, run <code>mact create --room '
        f'{safe} --port &lt;port&gt;</code> or <code>mact join --room {safe} ...</code> to go live.</p>'
        '<p class="hint"><a href="/">Back to m-act.live</a></p>'
        "</div>"
        "<script>"
        "setInterval(function(){location.reload()},5000);"
        "</script>"
        "</body></html>"
    )


def _dashboard_css() -> str:
    return """<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0f172a;--surface:#1e293b;--border:#334155;--text:#e2e8f0;
--muted:#94a3b8;--accent:#38bdf8;--green:#34d399;--red:#f87171;--yellow:#fbbf24}
body{font-family:system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);
min-height:100vh;padding:2rem}
.container{max-width:960px;margin:0 auto}
h1{font-size:1.75rem;font-weight:700;margin-bottom:.25rem}
h2{font-size:1.1rem;font-weight:600;color:var(--muted);margin:1.5rem 0 .75rem;
text-transform:uppercase;letter-spacing:.05em;font-size:.85rem}
.room-title{color:var(--accent)}
.status-bar{display:flex;gap:1.5rem;flex-wrap:wrap;margin:1rem 0;padding:1rem;
background:var(--surface);border-radius:.5rem;border:1px solid var(--border)}
.status-item{display:flex;flex-direction:column;gap:.25rem}
.status-label{font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
.status-value{font-size:.95rem;font-weight:500}
.badge{display:inline-block;padding:.15rem .5rem;border-radius:9999px;font-size:.75rem;font-weight:600}
.badge-live{background:rgba(52,211,153,.15);color:var(--green)}
.badge-offline{background:rgba(248,113,113,.15);color:var(--red)}
table{width:100%;border-collapse:collapse;background:var(--surface);border-radius:.5rem;
overflow:hidden;border:1px solid var(--border)}
th{background:rgba(255,255,255,.03);text-align:left;padding:.6rem .75rem;
font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;font-weight:600}
td{padding:.6rem .75rem;border-top:1px solid var(--border);font-size:.875rem}
tr:hover td{background:rgba(255,255,255,.02)}
.hash{font-family:'SF Mono',Consolas,monospace;color:var(--accent);font-size:.8rem}
.comment{color:var(--yellow);font-style:italic;font-size:.8rem}
.time{color:var(--muted);font-size:.8rem}
.empty{color:var(--muted);font-style:italic;padding:1rem}
</style>"""


def _dashboard_client_script(room_id: str) -> str:
    rj = json.dumps(room_id)
    return (
        "<script>\n"
        "(function(){\n"
        f"var ROOM_ID={rj};\n"
        "var statusUrl='/rooms/'+encodeURIComponent(ROOM_ID)+'/status';\n"
        "var wsProto=location.protocol==='https:'?'wss:':'ws:';\n"
        "var wsUrl=wsProto+'//'+location.host+'/rooms/'+encodeURIComponent(ROOM_ID)+'/events';\n"
        "function esc(s){var d=document.createElement('div');d.appendChild(document.createTextNode(s));return d.innerHTML;}\n"
        "function badge(live){return live"
        "?'<span class=\"badge badge-live\">LIVE</span>'"
        ":'<span class=\"badge badge-offline\">OFFLINE</span>';}\n"
        "function timeAgo(iso){\n"
        "  var d=new Date(iso),s=Math.floor((Date.now()-d)/1000);\n"
        "  if(s<60)return s+'s ago';if(s<3600)return Math.floor(s/60)+'m ago';\n"
        "  return Math.floor(s/3600)+'h ago';}\n"
        "function applyPayload(p){\n"
        "  if(!p)return;\n"
        "  var au=document.getElementById('mact-active-upstream');\n"
        "  if(au)au.textContent=p.active_upstream||'(none)';\n"
        "  var liveCount=(p.participants||[]).filter(function(x){return x.connected}).length;\n"
        "  var lc=document.getElementById('mact-live-count');\n"
        "  if(lc)lc.textContent=liveCount+'/'+p.participants.length;\n"
        "  var cc=document.getElementById('mact-commit-count');\n"
        "  if(cc)cc.textContent=(p.commits||[]).length;\n"
        "  var tb=document.getElementById('mact-participants-tbody');\n"
        "  if(tb){\n"
        "    tb.innerHTML='';\n"
        "    (p.participants||[]).forEach(function(m){\n"
        "      var tr=document.createElement('tr');\n"
        "      tr.innerHTML='<td>'+esc(m.developer_id)+'</td><td class=\"hash\">'+esc(m.upstream_url)"
        "+'</td><td>'+badge(m.connected)+'</td><td class=\"time\">'+esc(timeAgo(m.last_seen_at))+'</td>';\n"
        "      tb.appendChild(tr);\n"
        "    });\n"
        "  }\n"
        "  var cb=document.getElementById('mact-commits-tbody');\n"
        "  if(cb){\n"
        "    cb.innerHTML='';\n"
        "    (p.commits||[]).forEach(function(c){\n"
        "      var tr=document.createElement('tr');\n"
        "      var cmt=c.admin_comment?'<span class=\"comment\">'+esc(c.admin_comment)+'</span>':'';\n"
        "      tr.innerHTML='<td class=\"hash\">'+esc(c.commit_hash.substring(0,7))+'</td><td>'"
        "+esc(c.developer_id)+'</td><td>'+esc(c.branch)+'</td><td>'+esc(c.message)+'</td>'"
        "+'<td>'+cmt+'</td><td class=\"time\">'+esc(timeAgo(c.server_received_at))+'</td>';\n"
        "      cb.appendChild(tr);\n"
        "    });\n"
        "    if(!p.commits||!p.commits.length){\n"
        "      var tr=document.createElement('tr');\n"
        "      tr.innerHTML='<td colspan=\"6\" class=\"empty\">(no commits yet)</td>';\n"
        "      cb.appendChild(tr);\n"
        "    }\n"
        "  }\n"
        "}\n"
        "function poll(){\n"
        "  fetch(statusUrl,{cache:'no-store',headers:{'Cache-Control':'no-cache'}})\n"
        "    .then(function(r){if(!r.ok)return null;return r.json();})\n"
        "    .then(function(d){if(d)applyPayload(d);})\n"
        "    .catch(function(){});\n"
        "}\n"
        "poll();setInterval(poll,2000);\n"
        "function connectWs(){\n"
        "  try{\n"
        "    var ws=new WebSocket(wsUrl);\n"
        "    ws.onmessage=function(ev){\n"
        "      try{var msg=JSON.parse(ev.data);\n"
        "      if(msg.type==='room_status')applyPayload(msg.payload);\n"
        "      }catch(e){}\n"
        "    };\n"
        "    ws.onclose=function(){setTimeout(connectWs,3000);};\n"
        "  }catch(e){setTimeout(connectWs,3000);}\n"
        "}\n"
        "connectWs();\n"
        "})();\n"
        "</script>"
    )


def _dashboard_html(room_id: str, payload: dict) -> str:
    esc = html.escape
    active = payload.get("active_upstream")
    active_str = esc(active) if active else "(none)"
    live_count = sum(1 for p in payload["participants"] if p["connected"])
    total = len(payload["participants"])
    commits = payload.get("commits", [])

    participant_rows = ""
    for p in payload["participants"]:
        badge = ('<span class="badge badge-live">LIVE</span>' if p["connected"]
                 else '<span class="badge badge-offline">OFFLINE</span>')
        participant_rows += (
            f"<tr><td>{esc(p['developer_id'])}</td>"
            f'<td class="hash">{esc(p["upstream_url"])}</td>'
            f"<td>{badge}</td>"
            f'<td class="time">{esc(p["last_seen_at"])}</td></tr>'
        )

    commit_rows = ""
    for c in commits:
        cmt = f'<span class="comment">{esc(c["admin_comment"])}</span>' if c.get("admin_comment") else ""
        commit_rows += (
            f'<tr><td class="hash">{esc(c["commit_hash"][:7])}</td>'
            f"<td>{esc(c['developer_id'])}</td>"
            f"<td>{esc(c['branch'])}</td>"
            f"<td>{esc(c['message'])}</td>"
            f"<td>{cmt}</td>"
            f'<td class="time">{esc(c["server_received_at"])}</td></tr>'
        )
    if not commit_rows:
        commit_rows = '<tr><td colspan="6" class="empty">(no commits yet)</td></tr>'

    return (
        "<!doctype html>"
        '<html lang="en"><head><meta charset="utf-8"/>'
        '<meta name="viewport" content="width=device-width,initial-scale=1"/>'
        f"<title>MACT — {esc(room_id)}</title>"
        f"{_dashboard_css()}"
        "</head><body>"
        '<nav class="topbar">'
        '<span class="brand">MACT</span>'
        '<a href="/">Home</a>'
        f'<a href="/r/{esc(room_id)}/">Mirror</a>'
        '<span class="spacer"></span>'
        f'<span style="color:#94a3b8;font-size:.8rem">{esc(room_id)}.m-act.live</span>'
        "</nav>"
        '<div class="container">'
        f'<h1>Room <span class="room-title">{esc(room_id)}</span></h1>'
        '<div class="status-bar">'
        '<div class="status-item"><span class="status-label">Active Upstream</span>'
        f'<span class="status-value" id="mact-active-upstream">{active_str}</span></div>'
        '<div class="status-item"><span class="status-label">Members</span>'
        f'<span class="status-value" id="mact-live-count">{live_count}/{total}</span></div>'
        '<div class="status-item"><span class="status-label">Commits</span>'
        f'<span class="status-value" id="mact-commit-count">{len(commits)}</span></div>'
        "</div>"
        "<h2>Participants</h2>"
        "<table><thead><tr><th>Developer</th><th>Upstream</th><th>Status</th>"
        "<th>Last Seen</th></tr></thead>"
        f'<tbody id="mact-participants-tbody">{participant_rows}</tbody></table>'
        "<h2>Commit History</h2>"
        "<table><thead><tr><th>Hash</th><th>Author</th><th>Branch</th>"
        "<th>Message</th><th>Comment</th><th>Time</th></tr></thead>"
        f'<tbody id="mact-commits-tbody">{commit_rows}</tbody></table>'
        "</div>"
        f"{_dashboard_client_script(room_id)}"
        "</body></html>"
    )


def _mirror_live_html(room_id: str, iframe_src: str) -> str:
    esc = html.escape
    room_js = json.dumps(room_id)
    safe_src = esc(iframe_src, quote=True)
    return (
        "<!doctype html>"
        '<html lang="en"><head><meta charset="utf-8"/>'
        f"<title>MACT live — {esc(room_id)}</title>"
        "<style>html,body{height:100%;margin:0}"
        "#mact-mirror-frame{width:100%;height:100%;border:0}</style>"
        "</head><body>"
        f'<iframe id="mact-mirror-frame" src="{safe_src}" title="mirrored app"></iframe>'
        "<script>\n"
        "(function(){\n"
        f"var roomId = {room_js};\n"
        "var statusUrl = '/rooms/' + encodeURIComponent(roomId) + '/status';\n"
        "var iframe = document.getElementById('mact-mirror-frame');\n"
        "var lastUpstream = null;\n"
        "var wsProto = location.protocol === 'https:' ? 'wss:' : 'ws:';\n"
        "var wsUrl = wsProto + '//' + location.host + '/rooms/' + encodeURIComponent(roomId) + '/events';\n"
        "function reloadFrame() {\n"
        "  var base = iframe.src.split('?')[0];\n"
        "  iframe.src = base + '?mact_ts=' + Date.now();\n"
        "}\n"
        "function onStatus(p) {\n"
        "  if (!p) return;\n"
        "  var au = p.active_upstream;\n"
        "  if (au !== lastUpstream) {\n"
        "    if (lastUpstream !== null) reloadFrame();\n"
        "    lastUpstream = au;\n"
        "  }\n"
        "}\n"
        "function poll() {\n"
        "  fetch(statusUrl, { cache: 'no-store', headers: { 'Cache-Control': 'no-cache' } })\n"
        "    .then(function(r) { if (!r.ok) return null; return r.json(); })\n"
        "    .then(onStatus)\n"
        "    .catch(function() {});\n"
        "}\n"
        "poll();\n"
        "setInterval(poll, 2000);\n"
        "function connectWs() {\n"
        "  try {\n"
        "    var ws = new WebSocket(wsUrl);\n"
        "    ws.onmessage = function(ev) {\n"
        "      try {\n"
        "        var msg = JSON.parse(ev.data);\n"
        "        if (msg.type === 'room_status') onStatus(msg.payload);\n"
        "      } catch (e) {}\n"
        "    };\n"
        "    ws.onclose = function() { setTimeout(connectWs, 3000); };\n"
        "  } catch (e) { setTimeout(connectWs, 3000); }\n"
        "}\n"
        "connectWs();\n"
        "})();\n"
        "</script>"
        "</body></html>"
    )


def _room_dashboard_response(
    request: Request, db: Session, room_id: str
) -> HTMLResponse:
    _validate_room_id(room_id)
    payload = repo.get_room_status(
        db,
        room_id,
        presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
    )
    if payload is None:
        return HTMLResponse(content=_offline_page(room_id), status_code=503)
    return HTMLResponse(content=_dashboard_html(room_id, payload))


@fastapi_app.get("/dashboard", response_class=HTMLResponse)
def room_dashboard(
    request: Request, db: Session = Depends(get_db)
) -> HTMLResponse:
    room_id = getattr(request.state, "mact_room_from_host", None)
    if not room_id:
        raise HTTPException(status_code=404, detail="Not found")
    return _room_dashboard_response(request, db, room_id)


def _path_dashboard_allowed() -> bool:
    return os.getenv("MACT_DEV_DASHBOARD", "").lower() in ("1", "true", "yes")


@fastapi_app.get("/rooms/{room_id}/dashboard", response_class=HTMLResponse)
def room_dashboard_by_path(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> HTMLResponse:
    """Browser-friendly dashboard when not using subdomains (local simulation).

    Same HTML as ``GET /dashboard`` on ``{room}.domain``. Requires
    ``MACT_DEV_DASHBOARD=true`` so it is off in production by default.
    """
    if not _path_dashboard_allowed():
        raise HTTPException(status_code=404, detail="Not found")
    return _room_dashboard_response(request, db, room_id)


@fastapi_app.get("/dev/dashboard/{room_id}", response_class=HTMLResponse)
def dev_dashboard_alias(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> HTMLResponse:
    """Alias for ``/rooms/{room_id}/dashboard`` during local development."""
    if not _path_dashboard_allowed():
        raise HTTPException(status_code=404, detail="Not found")
    return _room_dashboard_response(request, db, room_id)


@fastapi_app.get("/live", response_class=HTMLResponse)
def mirror_live_subdomain(request: Request) -> HTMLResponse:
    """Auto-updating mirror shell (iframe + WebSocket). Use on ``{room}.domain/live``."""
    room_id = getattr(request.state, "mact_room_from_host", None)
    if not room_id:
        raise HTTPException(status_code=404, detail="Not found")
    return HTMLResponse(content=_mirror_live_html(room_id, "/"))


@fastapi_app.get("/r/{room_id}/live", response_class=HTMLResponse)
def mirror_live_under_r(room_id: str) -> HTMLResponse:
    """Iframe + WebSocket: reloads mirrored content when the active upstream changes."""
    _validate_room_id(room_id)
    return HTMLResponse(content=_mirror_live_html(room_id, f"/r/{room_id}/"))


def _inject_mirror_reload_script(content: bytes, room_id: str) -> bytes:
    """Append a script to mirrored HTML that reloads the page when the active upstream changes."""
    rj = json.dumps(room_id)
    script = (
        "\n<!-- MACT live-reload -->\n"
        "<script>\n"
        "(function(){\n"
        f"var ROOM_ID={rj};\n"
        "var statusUrl='/rooms/'+encodeURIComponent(ROOM_ID)+'/status';\n"
        "var lastUpstream=null;\n"
        "function check(){\n"
        "  fetch(statusUrl,{cache:'no-store',headers:{'Cache-Control':'no-cache'}})\n"
        "    .then(function(r){if(!r.ok)return null;return r.json();})\n"
        "    .then(function(d){\n"
        "      if(!d)return;\n"
        "      var au=d.active_upstream;\n"
        "      if(lastUpstream===null){lastUpstream=au;return;}\n"
        "      if(au!==lastUpstream){location.reload();}\n"
        "    }).catch(function(){});\n"
        "}\n"
        "check();\n"
        "setInterval(check,2000);\n"
        "var wsProto=location.protocol==='https:'?'wss:':'ws:';\n"
        "var wsUrl=wsProto+'//'+location.host+'/rooms/'+encodeURIComponent(ROOM_ID)+'/events';\n"
        "function connectWs(){\n"
        "  try{\n"
        "    var ws=new WebSocket(wsUrl);\n"
        "    ws.onmessage=function(ev){\n"
        "      try{\n"
        "        var msg=JSON.parse(ev.data);\n"
        "        if(msg.type==='room_status'&&msg.payload){\n"
        "          var au=msg.payload.active_upstream;\n"
        "          if(lastUpstream===null){lastUpstream=au;return;}\n"
        "          if(au!==lastUpstream){location.reload();}\n"
        "        }\n"
        "      }catch(e){}\n"
        "    };\n"
        "    ws.onclose=function(){setTimeout(connectWs,3000);};\n"
        "  }catch(e){setTimeout(connectWs,3000);}\n"
        "}\n"
        "connectWs();\n"
        "})();\n"
        "</script>\n"
    ).encode()

    html_lower = content.lower()
    close_body = html_lower.rfind(b"</body>")
    if close_body != -1:
        return content[:close_body] + script + content[close_body:]
    close_html = html_lower.rfind(b"</html>")
    if close_html != -1:
        return content[:close_html] + script + content[close_html:]
    return content + script


_MIRROR_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"]


async def _mirror_proxy(
    room_id: str,
    request: Request,
    path: str,
    db: Session,
) -> Response:
    _validate_room_id(room_id)
    active = repo.resolve_active_upstream(
        db,
        room_id,
        presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
    )
    if not active:
        LOGGER.info("mirror room_id=%s resolved=offline", room_id)
        return HTMLResponse(content=_offline_page(room_id), status_code=503)

    LOGGER.debug("mirror room_id=%s resolved_upstream=%s path=%s", room_id, active, path)
    target_url = _build_target_url(active, path, request.url.query)
    outbound_headers = {
        key: value
        for key, value in request.headers.items()
        if key.lower() not in HOP_BY_HOP_HEADERS
    }
    body = await request.body()

    try:
        mirror_client: httpx.AsyncClient = request.app.state.mirror_client
        upstream = await mirror_client.request(
            method=request.method,
            url=target_url,
            content=body if body else None,
            headers=outbound_headers,
            follow_redirects=True,
        )
    except httpx.RequestError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"upstream request failed: {exc.__class__.__name__}",
        ) from exc

    response_headers = {
        key: value
        for key, value in upstream.headers.items()
        if key.lower() not in STRIP_UPSTREAM_HEADERS
    }
    response_headers["cache-control"] = "no-store"
    response_headers["x-mact-upstream"] = active

    content = upstream.content
    content_type = (upstream.headers.get("content-type") or "").lower()
    if "text/html" in content_type and upstream.status_code < 400:
        content = _inject_mirror_reload_script(content, room_id)
        response_headers.pop("content-length", None)

    return Response(
        content=content,
        status_code=upstream.status_code,
        headers=response_headers,
    )


@fastapi_app.api_route("/r/{room_id}", methods=_MIRROR_METHODS, include_in_schema=False)
async def mirror_room_root(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> Response:
    return await _mirror_proxy(room_id, request, "", db)


@fastapi_app.api_route("/r/{room_id}/{path:path}", methods=_MIRROR_METHODS)
async def mirror_room(
    room_id: str, request: Request, path: str = "", db: Session = Depends(get_db)
) -> Response:
    return await _mirror_proxy(room_id, request, path, db)


app = SubdomainRewriteMiddleware(fastapi_app)


def run() -> None:
    uvicorn.run("mact.server.main:app", host="0.0.0.0", port=8000, reload=False)
