from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    """Loaded once per process from environment (see `load_settings`)."""

    database_url: str
    auto_create_tables: bool
    presence_ttl_seconds: int
    #: e.g. ``m-act.live`` for ``{room}.m-act.live``. Empty string disables subdomain routing.
    public_base_domain: str | None


def load_settings() -> Settings:
    domain_raw = os.getenv("MACT_PUBLIC_BASE_DOMAIN", "m-act.live").strip()
    return Settings(
        database_url=os.getenv("DATABASE_URL", "sqlite:///./mact.db"),
        auto_create_tables=os.getenv("MACT_AUTO_CREATE_TABLES", "true").lower()
        in ("1", "true", "yes"),
        presence_ttl_seconds=int(os.getenv("MACT_PRESENCE_TTL_SECONDS", "60")),
        public_base_domain=domain_raw or None,
    )
