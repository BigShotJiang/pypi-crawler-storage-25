"""Suite runner.

Iterates the probe list, materializes each into a ``(Probe, Spec)`` via
the registry, executes it with a :class:`~dlm_sway.probes.base.RunContext`,
and assembles a :class:`~dlm_sway.core.result.SuiteResult`.

Runtime contract:

- Probes are executed in declaration order (not sorted, not parallelized).
  The null-adapter baseline has to run before any probe that needs z-scores,
  so authoring order is load-bearing.
- A probe that raises is recorded as
  :attr:`~dlm_sway.core.result.Verdict.ERROR` and the suite continues —
  one broken probe doesn't torch the whole report.
- The backend is the caller's responsibility: the runner does not build
  or close it, so callers can reuse a backend across multiple suites.
"""

from __future__ import annotations

import time
from pathlib import Path
from types import MappingProxyType

from dlm_sway import __version__
from dlm_sway.core.determinism import seed_everything
from dlm_sway.core.errors import ProbeError
from dlm_sway.core.result import DeterminismReport, ProbeResult, SuiteResult, Verdict, utcnow
from dlm_sway.core.scoring import DifferentialBackend, PreflightCheckable
from dlm_sway.core.sections import Section
from dlm_sway.probes.base import RunContext, build_probe
from dlm_sway.probes.null_adapter import NullAdapterSpec, get_null_stats
from dlm_sway.suite.spec import SwaySpec


def run(
    spec: SwaySpec,
    backend: DifferentialBackend,
    *,
    spec_path: str = "<memory>",
    doc_text: str | None = None,
    sections: tuple[Section, ...] | None = None,
    skip_preflight: bool = False,
    trace_path: Path | None = None,
) -> SuiteResult:
    """Execute every probe in ``spec`` against ``backend``.

    Before any probe runs, the runner asks the backend to preflight-check
    itself if it implements :class:`PreflightCheckable`. On failure
    (e.g., a NaN-weighted adapter), the runner aborts the suite with a
    single synthetic ERROR probe and skips every configured probe — so
    a broken model never produces a false PASS verdict (the +11639σ
    class of bug from Audit 01).

    Set ``skip_preflight=True`` to disable the gate (e.g., for sub-second
    test suites where the cost matters); the default is to run it.
    """
    started = utcnow()

    # Sprint 07: ``concurrent_probes`` is scaffolding. The HF and MLX
    # backends declare ``safe_for_concurrent_views = False`` so the
    # runner stays sequential below. The spec field is still validated
    # + accepted (so a future pool can light up without a schema bump)
    # but does nothing until the pool lands; see
    # ``.docs/design/backend-concurrency.md``.
    #
    # DC4 (Audit 02) — the previous stderr warning fired every run
    # with ``concurrent_probes>1`` even though execution was
    # unchanged, which was noise for no benefit. The warning is
    # reinstated by the sprint that wires the pool.

    # Seed every RNG sway's probes touch before any backend work runs.
    # ``strict=True`` asks torch for deterministic algorithms and sets
    # CUBLAS_WORKSPACE_CONFIG; this is a no-op when torch is absent, so
    # callers without the ``hf`` extra still get a seeded python/numpy
    # state and a ``best_effort`` classification in the report.
    det_summary = seed_everything(spec.defaults.seed, strict=True)
    determinism = DeterminismReport(
        class_=det_summary.class_,
        seed=det_summary.seed,
        notes=det_summary.notes,
    )

    # Sprint 07: attach a trace writer to the backend's
    # instrumentation if the caller asked for one. Silent no-op for
    # backends without ``_inst`` (custom backends) and for the default
    # ``trace_path=None`` case.
    _install_trace_writer(backend, trace_path)

    ctx = RunContext(
        backend=backend,
        seed=spec.defaults.seed,
        top_k=spec.defaults.top_k,
        sections=sections,
        doc_text=doc_text,
    )

    results: list[ProbeResult] = []
    null_stats: dict[str, dict[str, float]] = {}
    null_stats_by_rank: dict[str, dict[str, dict[str, float]]] = {}

    # Preflight gate: if the backend can self-check, do so before any
    # probe runs. A failing preflight aborts the suite.
    if not skip_preflight and isinstance(backend, PreflightCheckable):
        t0 = time.perf_counter()
        ok, reason = backend.preflight_finite_check()
        duration = time.perf_counter() - t0
        if not ok:
            results.append(
                ProbeResult(
                    name="__preflight__",
                    kind="preflight",
                    verdict=Verdict.ERROR,
                    score=None,
                    message=(
                        f"backend preflight failed — suite aborted before any probe ran. {reason}"
                    ),
                    duration_s=duration,
                    evidence={"preflight_reason": reason},
                )
            )
            finished = utcnow()
            return SuiteResult(
                spec_path=spec_path,
                started_at=started,
                finished_at=finished,
                base_model_id=spec.models.base.base,
                adapter_id=str(spec.models.ft.adapter) if spec.models.ft.adapter else "",
                sway_version=__version__,
                probes=tuple(results),
                null_stats={},
                determinism=determinism,
                backend_stats=_snapshot_backend_stats(backend),
            )

    # Pre-extract suite kinds so each probe sees only what's *after* it.
    suite_kinds: list[str] = [str(entry.get("kind", "")) for entry in spec.suite]

    for idx, raw in enumerate(spec.suite):
        probe, probe_spec = build_probe(raw)
        if not probe_spec.enabled:
            results.append(
                ProbeResult(
                    name=probe_spec.name,
                    kind=probe_spec.kind,
                    verdict=Verdict.SKIP,
                    score=None,
                    message="disabled in spec",
                )
            )
            continue

        # Refresh ctx.downstream_kinds for this probe. The current
        # null_adapter probe wants to know which probe kinds it's
        # calibrating *for* — that's the kinds in the suite after itself.
        downstream_kinds = tuple(k for k in suite_kinds[idx + 1 :] if k)
        ctx = RunContext(
            backend=ctx.backend,
            seed=ctx.seed,
            top_k=ctx.top_k,
            sections=ctx.sections,
            doc_text=ctx.doc_text,
            null_stats=ctx.null_stats,
            null_stats_by_rank=ctx.null_stats_by_rank,
            downstream_kinds=downstream_kinds,
        )

        # Label trace events with the currently-running probe so the
        # JSONL is filterable by probe name.
        _set_backend_probe_label(backend, probe_spec.name)

        t0 = time.perf_counter()
        try:
            result = probe.run(probe_spec, ctx)
        except ProbeError as exc:
            result = ProbeResult(
                name=probe_spec.name,
                kind=probe_spec.kind,
                verdict=Verdict.ERROR,
                score=None,
                message=str(exc),
            )
        except Exception as exc:  # noqa: BLE001 — probe impls may raise anything
            result = ProbeResult(
                name=probe_spec.name,
                kind=probe_spec.kind,
                verdict=Verdict.ERROR,
                score=None,
                message=f"{type(exc).__name__}: {exc}",
            )
        duration = time.perf_counter() - t0
        # Re-stamp duration (probes don't know their own wall time).
        result = _with_duration(result, duration)
        results.append(result)

        # Null-adapter result seeds ctx.null_stats for subsequent probes.
        if isinstance(probe_spec, NullAdapterSpec) and result.evidence.get("null_stats"):
            null_stats.update(result.evidence["null_stats"])
            null_stats_by_rank.update(result.evidence.get("null_stats_by_rank") or {})
            # The dataclass is frozen, but the dict was previously
            # passed by reference — a probe could have mutated stats
            # other probes consume. Wrap in MappingProxyType so the
            # contract matches the docstring (B21).
            ctx = RunContext(
                backend=ctx.backend,
                seed=ctx.seed,
                top_k=ctx.top_k,
                sections=ctx.sections,
                doc_text=ctx.doc_text,
                null_stats=MappingProxyType(null_stats),
                null_stats_by_rank=MappingProxyType(null_stats_by_rank),
            )

    _set_backend_probe_label(backend, None)
    finished = utcnow()
    return SuiteResult(
        spec_path=spec_path,
        started_at=started,
        finished_at=finished,
        base_model_id=spec.models.base.base,
        adapter_id=str(spec.models.ft.adapter) if spec.models.ft.adapter else "",
        sway_version=__version__,
        probes=tuple(results),
        null_stats=null_stats,
        determinism=determinism,
        backend_stats=_snapshot_backend_stats(backend),
    )


def _install_trace_writer(backend: DifferentialBackend, trace_path: Path | None) -> None:
    """Attach a :class:`TraceWriter` to the backend's instrumentation.

    Silent no-op when the backend doesn't expose ``_inst`` (custom
    backends). When ``trace_path`` is ``None``, the existing no-op
    tracer stays in place.
    """
    if trace_path is None:
        return
    inst = getattr(backend, "_inst", None)
    if inst is None:
        return
    from dlm_sway.backends._instrumentation import TraceWriter

    inst.trace = TraceWriter(trace_path)


def _set_backend_probe_label(backend: DifferentialBackend, name: str | None) -> None:
    inst = getattr(backend, "_inst", None)
    if inst is None:
        return
    inst.set_current_probe(name)


def _snapshot_backend_stats(backend: DifferentialBackend) -> dict[str, float | int]:
    """Copy the backend's counters into a plain dict for ``SuiteResult``."""
    inst = getattr(backend, "_inst", None)
    if inst is None:
        return {}
    return dict(inst.stats.to_dict())


def _with_duration(result: ProbeResult, duration: float) -> ProbeResult:
    """Return a copy of ``result`` with :attr:`ProbeResult.duration_s` set.

    Every ``ProbeResult`` field must be forwarded explicitly — a dropped
    field here silently returns ``None`` for the whole runner path, which
    is how F01 (bootstrap ``ci_95`` stripped from every probe) landed
    before the audit caught it.
    """
    return ProbeResult(
        name=result.name,
        kind=result.kind,
        verdict=result.verdict,
        score=result.score,
        raw=result.raw,
        z_score=result.z_score,
        base_value=result.base_value,
        ft_value=result.ft_value,
        evidence=result.evidence,
        message=result.message,
        duration_s=duration,
        ci_95=result.ci_95,
    )


__all__ = ["get_null_stats", "run"]
