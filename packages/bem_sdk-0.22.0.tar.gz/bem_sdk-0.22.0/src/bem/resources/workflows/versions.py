# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncWorkflowVersionsPage, AsyncWorkflowVersionsPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.workflow import Workflow
from ...types.workflows import version_list_params
from ...types.workflows.version_retrieve_response import VersionRetrieveResponse

__all__ = ["VersionsResource", "AsyncVersionsResource"]


class VersionsResource(SyncAPIResource):
    """
    Workflows orchestrate one or more functions into a directed acyclic graph (DAG) for document processing.

    Use these endpoints to create, update, list, and manage workflows, and to invoke them
    with file input via `POST /v3/workflows/{workflowName}/call`.

    The call endpoint accepts files as either multipart form data or JSON with base64-encoded
    content. In the Bem CLI, use `@path/to/file` inside JSON values to automatically read and
    encode files:

    ```
    bem workflows call --workflow-name my-workflow \\
      --input.single-file '{"inputContent": "@file.pdf", "inputType": "pdf"}' \\
      --wait
    ```
    """

    @cached_property
    def with_raw_response(self) -> VersionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/bem-team/bem-python-sdk#accessing-raw-response-data-eg-headers
        """
        return VersionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> VersionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/bem-team/bem-python-sdk#with_streaming_response
        """
        return VersionsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        version_num: int,
        *,
        workflow_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VersionRetrieveResponse:
        """
        **Retrieve a specific historical version of a workflow.**

        Versions are immutable. Use this endpoint to see what a workflow looked like at
        the moment a particular call was made — every call record carries the workflow
        `versionNum` it ran against.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workflow_name:
            raise ValueError(f"Expected a non-empty value for `workflow_name` but received {workflow_name!r}")
        return self._get(
            path_template(
                "/v3/workflows/{workflow_name}/versions/{version_num}",
                workflow_name=workflow_name,
                version_num=version_num,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VersionRetrieveResponse,
        )

    def list(
        self,
        workflow_name: str,
        *,
        ending_before: int | Omit = omit,
        limit: int | Omit = omit,
        sort_order: Literal["asc", "desc"] | Omit = omit,
        starting_after: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncWorkflowVersionsPage[Workflow]:
        """**List every version of a workflow.**

        Versions are immutable.

        Each row captures what the workflow looked like between
        updates: graph topology, metadata, and timestamps. Returns newest-first by
        default. Cursor pagination via `startingAfter` / `endingBefore` over
        `versionNum`.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workflow_name:
            raise ValueError(f"Expected a non-empty value for `workflow_name` but received {workflow_name!r}")
        return self._get_api_list(
            path_template("/v3/workflows/{workflow_name}/versions", workflow_name=workflow_name),
            page=SyncWorkflowVersionsPage[Workflow],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "ending_before": ending_before,
                        "limit": limit,
                        "sort_order": sort_order,
                        "starting_after": starting_after,
                    },
                    version_list_params.VersionListParams,
                ),
            ),
            model=Workflow,
        )


class AsyncVersionsResource(AsyncAPIResource):
    """
    Workflows orchestrate one or more functions into a directed acyclic graph (DAG) for document processing.

    Use these endpoints to create, update, list, and manage workflows, and to invoke them
    with file input via `POST /v3/workflows/{workflowName}/call`.

    The call endpoint accepts files as either multipart form data or JSON with base64-encoded
    content. In the Bem CLI, use `@path/to/file` inside JSON values to automatically read and
    encode files:

    ```
    bem workflows call --workflow-name my-workflow \\
      --input.single-file '{"inputContent": "@file.pdf", "inputType": "pdf"}' \\
      --wait
    ```
    """

    @cached_property
    def with_raw_response(self) -> AsyncVersionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/bem-team/bem-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncVersionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncVersionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/bem-team/bem-python-sdk#with_streaming_response
        """
        return AsyncVersionsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        version_num: int,
        *,
        workflow_name: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VersionRetrieveResponse:
        """
        **Retrieve a specific historical version of a workflow.**

        Versions are immutable. Use this endpoint to see what a workflow looked like at
        the moment a particular call was made — every call record carries the workflow
        `versionNum` it ran against.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workflow_name:
            raise ValueError(f"Expected a non-empty value for `workflow_name` but received {workflow_name!r}")
        return await self._get(
            path_template(
                "/v3/workflows/{workflow_name}/versions/{version_num}",
                workflow_name=workflow_name,
                version_num=version_num,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VersionRetrieveResponse,
        )

    def list(
        self,
        workflow_name: str,
        *,
        ending_before: int | Omit = omit,
        limit: int | Omit = omit,
        sort_order: Literal["asc", "desc"] | Omit = omit,
        starting_after: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Workflow, AsyncWorkflowVersionsPage[Workflow]]:
        """**List every version of a workflow.**

        Versions are immutable.

        Each row captures what the workflow looked like between
        updates: graph topology, metadata, and timestamps. Returns newest-first by
        default. Cursor pagination via `startingAfter` / `endingBefore` over
        `versionNum`.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workflow_name:
            raise ValueError(f"Expected a non-empty value for `workflow_name` but received {workflow_name!r}")
        return self._get_api_list(
            path_template("/v3/workflows/{workflow_name}/versions", workflow_name=workflow_name),
            page=AsyncWorkflowVersionsPage[Workflow],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "ending_before": ending_before,
                        "limit": limit,
                        "sort_order": sort_order,
                        "starting_after": starting_after,
                    },
                    version_list_params.VersionListParams,
                ),
            ),
            model=Workflow,
        )


class VersionsResourceWithRawResponse:
    def __init__(self, versions: VersionsResource) -> None:
        self._versions = versions

        self.retrieve = to_raw_response_wrapper(
            versions.retrieve,
        )
        self.list = to_raw_response_wrapper(
            versions.list,
        )


class AsyncVersionsResourceWithRawResponse:
    def __init__(self, versions: AsyncVersionsResource) -> None:
        self._versions = versions

        self.retrieve = async_to_raw_response_wrapper(
            versions.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            versions.list,
        )


class VersionsResourceWithStreamingResponse:
    def __init__(self, versions: VersionsResource) -> None:
        self._versions = versions

        self.retrieve = to_streamed_response_wrapper(
            versions.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            versions.list,
        )


class AsyncVersionsResourceWithStreamingResponse:
    def __init__(self, versions: AsyncVersionsResource) -> None:
        self._versions = versions

        self.retrieve = async_to_streamed_response_wrapper(
            versions.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            versions.list,
        )
