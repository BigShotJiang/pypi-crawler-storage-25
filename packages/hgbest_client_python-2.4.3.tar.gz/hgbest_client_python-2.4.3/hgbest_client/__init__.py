# sdk/hgbest_client.py
import hashlib
import hmac
import time
import json
import requests
import sys

class HgBestClientPython:
    """
    Python SDK for the HgBest Analytics API.
    All requests are HMAC-SHA256 signed.
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = 'https://hgbest-backend.onrender.com',
    ):
        if not api_key or not api_secret:
            raise ValueError('HgBestClient requires both api_key and api_secret.')

        self.api_key    = api_key
        self.api_secret = api_secret.encode('utf-8')
        self.base_url   = base_url

        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept':       'application/json',
        })

    # ─── Signing helpers ──────────────────────────────────────────────────────

    def _generate_sha256_hash(self, data: str) -> str:
        return hashlib.sha256(data.encode('utf-8')).hexdigest()

    def _generate_signature(self, method: str, path: str, timestamp: str, request_body: str) -> str:
        body_hash      = self._generate_sha256_hash(request_body)
        string_to_sign = f"{method}\n{path}\n{timestamp}\n{body_hash}"
        return hmac.new(self.api_secret, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()

    # ─── Core request method ──────────────────────────────────────────────────

    def _send_signed_request(self, method: str, endpoint: str, data: dict = None, timeout: int = 30):
        timestamp = str(int(time.time() * 1000))

        request_body_str = ''
        if data and method in ('POST', 'PUT'):
            request_body_str = json.dumps(data, separators=(',', ':'))

        signature = self._generate_signature(method, endpoint, timestamp, request_body_str)

        headers = {
            'X-API-KEY':       self.api_key,
            'X-API-TIMESTAMP': timestamp,
            'X-API-SIGNATURE': signature,
        }
        self.session.headers.update(headers)

        url = f"{self.base_url}{endpoint}"

        try:
            if method == 'GET':
                response = self.session.get(url, timeout=timeout)
            elif method == 'POST':
                response = self.session.post(url, json=data, timeout=timeout)
            elif method == 'PUT':
                response = self.session.put(url, json=data, timeout=timeout)
            elif method == 'DELETE':
                response = self.session.delete(url, timeout=timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            return response.json()

        except requests.exceptions.HTTPError as e:
            print(f"API Error [{method} {endpoint}]: {e.response.status_code} — {e.response.text}", file=sys.stderr)
            raise
        except requests.exceptions.RequestException as e:
            print(f"Request Error [{method} {endpoint}]: {e}", file=sys.stderr)
            raise

    # ─── Domain accessors ─────────────────────────────────────────────────────

    @property
    def risk(self):
        return _RiskAPI(self)

    @property
    def finance(self):
        return _FinanceAPI(self)

    @property
    def market(self):
        return _MarketAPI(self)

    @property
    def aml_kyc(self):
        return _AmlKycAPI(self)


# ─── Domain classes ───────────────────────────────────────────────────────────

class _RiskAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def global_supply_chain_alert(self, payload: dict):
        """POST /risk/global-supply-chain-alert"""
        return self._client._send_signed_request('POST', '/risk/global-supply-chain-alert', payload)


class _FinanceAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def macro_sentiment_score(self, payload: dict):
        """POST /finance/macro-sentiment-score"""
        return self._client._send_signed_request('POST', '/finance/macro-sentiment-score', payload)


class _MarketAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

    def algorithmic_divergence_signal(self, payload: dict):
        """POST /market/algorithmic-divergence-signal"""
        return self._client._send_signed_request('POST', '/market/algorithmic-divergence-signal', payload)


class _AmlKycAPI:
    def __init__(self, client: 'HgBestClientPython'):
        self._client = client

   def verify(self, payload: dict):
        """
        Submit a KYC/AML verification request.

        payload keys:
          id_image_base64 (str)  : Data URI — "data:image/jpeg;base64,<data>"
          selfie_base64   (str)  : Data URI — "data:image/jpeg;base64,<data>"
          webhook_url     (str)  : URL to receive the final result (optional).
          metadata        (dict) : Arbitrary key/value pairs echoed in result (optional).

        Returns immediately:
          { request_id, status: "PROCESSING", submitted_at }

        Final webhook / poll result includes:
          status        : "APPROVED" | "REJECTED" | "ERROR"
          reason_codes  : list of strings — e.g. ["LIVENESS_FAILED", "FACE_MISMATCH"]
          kyc           : { document_type, full_name, date_of_birth, expiry_date,
                            is_expired, doc_confidence }
          face_match    : { score, passed, faces_detected, confidence, notes }
          liveness      : { appears_live, liveness_confidence, passed, notes }
          aml           : { sanctions_checked, sanctions_hit, sanctions_details }
          metadata      : echoed back from request
          processing_ms : int
        """
        
        return self._client._send_signed_request('POST', '/aml-kyc/verify', payload, timeout=60)

    def get_request(self, request_id: str):
        """
        Poll for the outcome of a previously submitted verification.
        GET /aml-kyc/requests/<request_id>
        """
        return self._client._send_signed_request('GET', f'/aml-kyc/requests/{request_id}')


