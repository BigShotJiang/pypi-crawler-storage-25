# quill-sort

**Adaptive Ultra-Sort** — the fastest general-purpose sorting library for Python.

```python
from quill import quill_sort, quill_sorted

quill_sort([3, 1, 4, 1, 5, 9])               # → [1, 1, 3, 4, 5, 9]
quill_sort(records, key=lambda r: r['age'])   # sort objects
quill_sort(big_data, parallel=True)           # use all CPU cores
result = quill_sorted(iterable, reverse=True) # mirrors built-in sorted()
```

## Installation

```bash
pip install quill-sort              # core (no dependencies)
pip install quill-sort[fast]        # + numpy for max speed
pip install quill-sort[all]         # + numpy + pandas support
```

## How it works

Quill profiles your data at intake and picks the optimal path automatically:

| Data type | Strategy | Complexity |
|-----------|----------|------------|
| Dense integer range | Counting sort | O(n + k) |
| Integers (numpy) | Narrowest-dtype radix | O(n) |
| Integers (no numpy) | Base-256 radix, precomputed histograms | O(n) |
| Floats | NumPy optimised introsort | O(n log n) |
| Strings / bytes | Python Timsort | O(n log n) |
| Objects with key | Rank-encode → numpy argsort | O(n log n) |
| Pre-sorted | Early exit after O(sample) probe | O(sample) |
| Reverse-sorted | Single `.reverse()` call | O(n/2) |

**Dtype-width optimisation** — Quill selects the narrowest safe numpy integer
type for each dataset. `uint16` uses 4× less memory bandwidth than `int64`,
making it ~6× faster on large arrays. This is the same technique used by
`ska_sort` and `spread_sort`.

**Single-pass histogram precomputation** — the pure-Python fallback scans the
array exactly once to build all digit histograms simultaneously, then skips any
radix pass where all values share the same digit.

## Supported types

- `int`, `float`, `str`, `bytes` — native fast paths
- Negative integers — automatically shifted to non-negative before sorting
- `None` values — filtered out, sorted data returned, Nones reinserted at end
- `pandas.Series` — sorted and returned as a new Series
- `pandas.DataFrame` — sorted by column(s) via `key='column_name'`
- `numpy.ndarray` — sorted in-place via numpy directly
- Any generator or iterator — materialised to list, sorted, returned

## Plugin system

Add support for any custom type:

```python
from quill import register_plugin
from quill._plugins import QuillPlugin

class MyPlugin(QuillPlugin):
    handles = (MyCustomClass,)
    name    = "my_custom_class"

    @staticmethod
    def prepare(data, key, reverse):
        items = [x.value for x in data]
        postprocess = lambda sorted_list: [MyCustomClass(v) for v in sorted_list]
        return items, key, postprocess

register_plugin(MyPlugin)

# Now quill_sort works on your type automatically:
quill_sort(list_of_my_objects)
```

## CLI / Demo

```bash
python -m quill       # run the benchmark demo
quill                 # same, if installed via pip
```

## Performance

Approximate timings on modern hardware (Apple M2, numpy installed):

| n | Time |
|---|------|
| 1,000 | 0.00008s |
| 100,000 | 0.002s |
| 1,000,000 | 0.015s |
| 10,000,000 | 0.15s |
| 100,000,000 | 1.5s |

## Requirements

- Python 3.8+
- `numpy` optional (strongly recommended — `pip install numpy`)
- `pandas` optional (for DataFrame support)

## License

MIT — by Invariant Games
