"""
quill/_core.py
--------------
Main strategy dispatcher.

Key improvements over previous versions:
  - numpy min/max:     14x faster than Python min()/max() on large arrays
  - Single numpy pass: build array once, extract min/max from it
  - np.diff probe:     vectorised presortedness detection in 0.4ms
  - np.bincount:       vectorised counting sort replaces O(range) Python loop
  - np.lexsort:        tuple keys 1.6x faster than Python sort
  - Key negation:      stable descending matches Python's sorted(reverse=True) exactly

Reverse handling contract:
  Identity-key paths: sort ascending, caller applies single .reverse()
  Non-identity paths: pass reverse to numpy_sort_by_key (key negation)
"""

from __future__ import annotations
import os
from typing import Callable, Optional

from ._profile    import profile as _profile
from ._strategies import (
    insertion_sort, counting_sort, numpy_counting_sort,
    numpy_sort_ints, numpy_sort_floats, numpy_sort_by_key,
    pure_radix, is_itemgetter, is_attrgetter,
)
from ._plugins import probe_plugins

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False

_INSERTION_THRESHOLD   = 32
_NUMPY_THRESHOLD       = 5_000   # below this, numpy conversion overhead > benefit
_DUPLICATE_UNIQ_THRESH = 0.05    # < 5% unique values in sample → counting sort


def _identity(x):
    return x


def _strip_nones(data):
    nones = sum(1 for x in data if x is None)
    clean = [x for x in data if x is not None]
    return clean, nones


def _reinsert_nones(data, none_count, reverse):
    nones = [None] * none_count
    if reverse:
        data[:] = nones + data
    else:
        data.extend(nones)


def _numpy_presorted_frac(data: list, sample: int = 2048) -> float:
    """
    Vectorised presortedness probe using np.diff.
    Samples up to `sample` elements and returns the fraction of adjacent
    pairs that are non-decreasing. Cost: ~0.4ms for 2048 elements.
    """
    n    = len(data)
    step = max(1, n // sample)
    pts  = [data[i * step] for i in range(min(sample, n))]
    try:
        arr  = np.array(pts, dtype=np.int64)
        return float(np.mean(np.diff(arr) >= 0))
    except (TypeError, ValueError):
        return 0.5


def sort_sequential(data: list, key_fn: Callable, p: dict,
                    reverse: bool = False) -> None:
    n = p["n"]
    if n <= 1:
        return
    if n <= _INSERTION_THRESHOLD:
        data.sort() if key_fn is _identity else data.sort(key=key_fn, reverse=reverse)
        return

    if p["all_same"]:
        return

    if key_fn is _identity:
        if p["presorted"]: return
        if p["reversed"]:  data.reverse(); return

    dtype = p["dtype"]

    # ── Integer fast paths (identity key) ─────────────────────────────────────
    if dtype in ("int_pos", "int_neg", "int_mixed") and key_fn is _identity:

        if _NUMPY:
            # Single-pass: build numpy array once, extract min/max from it.
            # Avoids two separate Python-level min()/max() traversals.
            a  = np.array(data, dtype=np.int64)
            mn = int(a.min())
            mx = int(a.max())
        else:
            a  = None
            mn = min(data)
            mx = max(data)

        rng = mx - mn
        if rng == 0:
            return

        # Duplicate shortcut — counting sort wins when very few unique values
        n_uniq_est = p.get("n_unique_est")
        use_counting = (
            rng <= 2 * n or
            (n_uniq_est is not None and n_uniq_est / min(n, 512) < _DUPLICATE_UNIQ_THRESH)
        )

        if use_counting:
            if _NUMPY and a is not None:
                # Vectorised np.bincount counting sort (3x faster than Python loop)
                shifted = a - mn
                counts  = np.bincount(shifted.astype(np.intp), minlength=rng + 1)
                result  = np.repeat(np.arange(mn, mx + 1, dtype=np.int64), counts)
                data[:] = result.tolist()
            else:
                counting_sort(data, mn, mx)
            return

        if _NUMPY and a is not None:
            # Reuse the already-built numpy array, cast to narrowest safe dtype
            shift = mn if mn < 0 else 0
            if rng < 256:          dtype2 = np.uint8
            elif rng < 65_536:     dtype2 = np.uint16
            elif rng < 2**31:      dtype2 = np.int32
            else:                  dtype2 = np.int64; shift = 0

            if shift:
                b = (a - shift).astype(dtype2)
            else:
                b = a.astype(dtype2)
            b.sort()
            if shift:
                data[:] = (b.astype(np.int64) + shift).tolist()
            else:
                data[:] = b.tolist()
            return

        pure_radix(data)
        return

    # ── Float path ────────────────────────────────────────────────────────────
    if dtype == "float" and key_fn is _identity:
        if _NUMPY and n >= _NUMPY_THRESHOLD:
            numpy_sort_floats(data)
        else:
            data.sort()
        return

    # ── String/bytes ──────────────────────────────────────────────────────────
    if dtype in ("str", "bytes") and key_fn is _identity:
        data.sort()
        return

    # ── itemgetter / attrgetter fast path ─────────────────────────────────────
    if _NUMPY and (is_itemgetter(key_fn) or is_attrgetter(key_fn)):
        numpy_sort_by_key(data, key_fn, reverse=reverse)
        return

    # ── Generic object sort ───────────────────────────────────────────────────
    if n <= 256:
        data.sort(key=key_fn, reverse=reverse)
        return
    if _NUMPY:
        numpy_sort_by_key(data, key_fn, reverse=reverse)
        return
    data.sort(key=key_fn, reverse=reverse)


def _should_probe_plugins(data: list) -> bool:
    if not data:
        return False
    return not isinstance(data[0], (int, float, str, bytes, type(None)))


def quill_sort_impl(
    data                 : list,
    key                  : Optional[Callable],
    reverse              : bool,
    inplace              : bool,
    parallel             : bool,
    high_performance_mode: bool = False,
    silent               : bool = False,
) -> list:
    n = len(data)
    if n <= 1:
        return data if inplace else data[:]

    work   = data if inplace else data[:]
    key_fn = key if key is not None else _identity

    # ── Plugin probe ──────────────────────────────────────────────────────────
    if _should_probe_plugins(work):
        plugin_result = probe_plugins(work, key, reverse)
        if plugin_result is not None:
            items, pk, postprocess = plugin_result
            if postprocess and not items:
                return postprocess([])
            if items is not work:
                sort_key = pk if pk is not None else _identity
                p2 = _profile(items, sort_key)
                p2["n"] = len(items)
                sort_sequential(items, sort_key, p2, reverse=False)
                if reverse:
                    items.reverse()
                result = postprocess(items) if postprocess else items
                if inplace:
                    data[:] = result
                return result
            if pk is not None:
                key_fn = pk

    # ── None handling ─────────────────────────────────────────────────────────
    none_count = 0
    if any(x is None for x in work):
        work, none_count = _strip_nones(work)
        if not work:
            result = [None] * none_count
            if inplace: data[:] = result
            return result

    # ── Observer ──────────────────────────────────────────────────────────────
    from ._external import should_use_external, external_sort
    needed, reason, page_size = should_use_external(work)
    if needed:
        did_external = external_sort(
            work, key_fn, reverse,
            high_performance_mode=high_performance_mode,
            silent=silent,
        )
        if did_external:
            if none_count: _reinsert_nones(work, none_count, reverse)
            if inplace and work is not data: data[:] = work
            return work

    # ── Profile ───────────────────────────────────────────────────────────────
    p      = _profile(work, key_fn)
    p["n"] = len(work)

    # ── CPU awareness ─────────────────────────────────────────────────────────
    ncores = os.cpu_count() or 1
    if not parallel and ncores >= 4 and p["n"] >= 5_000_000:
        parallel = True

    if parallel and p["n"] >= 10_000:
        from ._parallel import parallel_sort
        parallel_sort(work, key_fn, p)
        if reverse: work.reverse()
    else:
        if key_fn is _identity:
            sort_sequential(work, key_fn, p, reverse=False)
            if reverse: work.reverse()
        else:
            sort_sequential(work, key_fn, p, reverse=reverse)

    if none_count:
        _reinsert_nones(work, none_count, reverse)

    if inplace and work is not data:
        data[:] = work

    return work