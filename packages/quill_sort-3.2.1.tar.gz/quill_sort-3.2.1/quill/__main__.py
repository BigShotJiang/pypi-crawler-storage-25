"""
quill/__main__.py
-----------------
Entry point for `python -m quill` and the `quill` CLI command.
Runs the demo.
"""

import random, time, sys
from . import quill_sort, __version__

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False


def main():
    def typewrite(text, delay=0.015):
        for ch in text:
            sys.stdout.write(ch); sys.stdout.flush(); time.sleep(delay)
        print()

    def bar(filled, total, width=38):
        n = int(width * min(filled, total) / total)
        return f"[{'█' * n}{'░' * (width - n)}]"

    print()
    typewrite("  ▄▀▄ █ █ █ █   █   ")
    typewrite(f"  ▀▄▀ ▀▄█ █ █▄▄ █▄▄   v{__version__}")
    print()
    typewrite("  Adaptive Ultra-Sort  —  by Invariant Games", 0.01)
    try:
        import psutil as _psutil
        psutil_tag = "psutil ✓  memory sensing active"
    except ImportError:
        psutil_tag = "psutil ✗  install for RAM sensing: pip install quill-sort[fast]"
    print(f"  [{psutil_tag}]", 0.008)
    np_tag = "numpy ✓  vectorised C path active" if _NUMPY \
             else "numpy ✗  install for max speed: pip install numpy"
    typewrite(f"  [{np_tag}]", 0.008)
    print()
    time.sleep(0.3)

    SIZES = [100, 1_000, 10_000, 100_000, 500_000,
             1_000_000, 5_000_000, 10_000_000]

    typewrite("  Benchmarking across dataset sizes...", 0.012)
    print()
    time.sleep(0.2)

    results = []
    for size in SIZES:
        if size >= 1_000_000:
            sys.stdout.write(f"  {size:>12,} elements  [allocating...]")
            sys.stdout.flush()

        try:
            data = [random.randint(0, size * 10) for _ in range(size)]
        except MemoryError:
            sys.stdout.write(f"\r  {size:>12,} elements  [skipped — not enough RAM]\n")
            continue

        t0 = time.perf_counter()
        quill_sort(data)
        t1 = time.perf_counter()
        elapsed = t1 - t0

        correct = all(data[i] <= data[i+1] for i in range(min(len(data)-1, 50_000)))
        results.append((size, elapsed, correct))
        del data

        label  = f"  {size:>12,} elements"
        timing = f"{elapsed:>8.4f}s"
        status = "✓" if correct else "✗"
        b      = bar(elapsed, 3.0)
        line   = f"{label}  {b}  {timing}  {status}"
        if size >= 1_000_000:
            sys.stdout.write(f"\r{line}\n")
        else:
            print(line)
        sys.stdout.flush()
        time.sleep(0.04)

    print()
    time.sleep(0.3)

    if len(results) >= 2:
        s2, t2, _ = results[-1]
        est_1b = t2 * (1_000_000_000 / s2)
        est_str = f"{est_1b/60:.1f} minutes" if est_1b >= 60 else f"{est_1b:.1f}s"
        typewrite(f"  Quill can sort 1 billion integers in an estimated ~{est_str}.", 0.012)
        typewrite(f"  This demo is capped at 10 million due to sandbox memory constraints.", 0.012)
        print()
    time.sleep(0.3)

    typewrite("  Watching Quill sort 20 numbers in real time...", 0.012)
    print()
    time.sleep(0.2)

    sample = random.sample(range(1, 999), 20)
    print(f"  Before:  {sample}")
    time.sleep(0.6)
    quill_sort(sample)
    sys.stdout.write("  After:   ")
    sys.stdout.flush()
    for i, v in enumerate(sample):
        sys.stdout.write(("" if i == 0 else ", ") + str(v))
        sys.stdout.flush()
        time.sleep(0.055)
    print(); print()
    time.sleep(0.4)

    big = results[-1]
    typewrite(f"  {big[0]:,} integers sorted in {big[1]:.4f}s.", 0.012)
    typewrite( "  Narrowest-dtype numpy path.  Zero comparisons.  Cache-optimal.", 0.012)
    print()
    typewrite( "  pip install quill-sort", 0.022)
    print()


if __name__ == "__main__":
    main()