"""
quill/_external.py
------------------
External Sort Engine — handles datasets that exceed available RAM.

PHASE 1 — SORT + WRITE (async overlap)
  Pages are sorted and written to disk concurrently using a thread pool:
  while CPU sorts page N, disk writes page N-1 simultaneously.

PHASE 2 — MULTIWAY POWERSORT MERGE
  Replaces the simple heap merge with Powersort-inspired near-optimal
  merge ordering: assigns each adjacent pair of sorted pages a "power"
  value and merges in the order that minimises total merge cost.
  Falls back to standard k-way heap merge for small k.

qWRITE FORMAT
  Bytes 0-7:   Magic b'QWRITE\\x00\\x00'
  Bytes 8-15:  NumPy dtype string
  Bytes 16-23: Element count (uint64)
  Byte  24:    is_sorted flag
  Bytes 25-63: Padding
  Bytes 64+:   Raw element bytes
"""

from __future__ import annotations

import heapq
import io
import math
import os
import struct
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, List, Optional

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False

try:
    import psutil
    _PSUTIL = True
except ImportError:
    _PSUTIL = False


# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

QWRITE_MAGIC      = b'QWRITE\x00\x00'
QWRITE_HEADER_FMT = '8s8sQ?39x'
QWRITE_HEADER_SZ  = 64

SOFT_LIMIT_RATIO  = 0.75
HARD_LIMIT_RATIO  = 0.90
MERGE_BUFFER_ELTS = 65_536
MIN_PAGE_ELTS     = 10_000


# ─────────────────────────────────────────────────────────────────────────────
# OBSERVER
# ─────────────────────────────────────────────────────────────────────────────

def get_available_ram() -> int:
    if _PSUTIL: return psutil.virtual_memory().available
    return 2 * 1024 ** 3

def get_total_ram() -> int:
    if _PSUTIL: return psutil.virtual_memory().total
    return 4 * 1024 ** 3

def get_ram_usage_pct() -> float:
    if _PSUTIL: return psutil.virtual_memory().percent / 100.0
    return 0.5

def estimate_dataset_bytes(data: list) -> int:
    n = len(data)
    if n == 0: return 0
    s = data[0]
    if isinstance(s, int):   return n * 8
    if isinstance(s, float): return n * 8
    if isinstance(s, str):
        avg = sum(len(x) for x in data[:min(100, n)]) / min(100, n)
        return int(n * (50 + avg))
    return n * 64

def should_use_external(data: list, force: bool = False) -> tuple:
    if force:
        available  = get_available_ram()
        page_bytes = int(available * 0.20)
        page_elts  = max(MIN_PAGE_ELTS, page_bytes // 8)
        return True, "forced by caller", page_elts

    available  = get_available_ram()
    estimated  = estimate_dataset_bytes(data)
    soft_limit = int(available * SOFT_LIMIT_RATIO)
    hard_limit = int(available * HARD_LIMIT_RATIO)

    if estimated < soft_limit:
        return False, "fits in RAM", 0

    page_bytes = int(available * 0.20)
    page_elts  = max(MIN_PAGE_ELTS, page_bytes // 8)

    if estimated >= hard_limit:
        reason = (
            f"dataset ~{estimated/1e9:.1f}GB exceeds hard limit "
            f"({hard_limit/1e9:.1f}GB = {HARD_LIMIT_RATIO*100:.0f}% of "
            f"{available/1e9:.1f}GB available RAM)"
        )
    else:
        reason = (
            f"dataset ~{estimated/1e6:.0f}MB exceeds soft limit "
            f"({soft_limit/1e6:.0f}MB = {SOFT_LIMIT_RATIO*100:.0f}% of "
            f"{available/1e6:.0f}MB available RAM)"
        )
    return True, reason, page_elts


# ─────────────────────────────────────────────────────────────────────────────
# qWRITE ENGINE
# ─────────────────────────────────────────────────────────────────────────────

def _make_header(dtype_str: str, count: int, is_sorted: bool) -> bytes:
    return struct.pack(QWRITE_HEADER_FMT,
                       QWRITE_MAGIC,
                       dtype_str.encode().ljust(8)[:8],
                       count, is_sorted)

def _read_header(f) -> tuple:
    raw = f.read(QWRITE_HEADER_SZ)
    magic, dtype_bytes, count, is_sorted = struct.unpack(QWRITE_HEADER_FMT, raw)
    if magic != QWRITE_MAGIC:
        raise ValueError(f"Invalid qWrite file: bad magic {magic!r}")
    return np.dtype(dtype_bytes.decode().strip()), int(count), bool(is_sorted)

def write_qwrite(path: str, data_np, is_sorted: bool = False) -> int:
    arr     = np.asarray(data_np)
    header  = _make_header(arr.dtype.str, len(arr), is_sorted)
    payload = arr.tobytes()
    with open(path, 'wb', buffering=8 * 1024 * 1024) as f:
        f.write(header)
        f.write(payload)
    return len(header) + len(payload)

def read_qwrite_full(path: str):
    with open(path, 'rb', buffering=8 * 1024 * 1024) as f:
        dtype, count, is_sorted = _read_header(f)
        raw = f.read()
    return np.frombuffer(raw, dtype=dtype)

def iter_qwrite_blocks(path: str, block_size: int = MERGE_BUFFER_ELTS):
    with open(path, 'rb', buffering=4 * 1024 * 1024) as f:
        dtype, count, _ = _read_header(f)
        item_size = dtype.itemsize
        while True:
            raw = f.read(block_size * item_size)
            if not raw: break
            for v in np.frombuffer(raw, dtype=dtype).tolist():
                yield v


# ─────────────────────────────────────────────────────────────────────────────
# MULTIWAY POWERSORT MERGE
#
# Standard heap merge is O(n log k). Powersort improves on this by assigning
# each adjacent pair of runs a "power" — a measure of how balanced the merge
# will be — and merging in near-optimal order. For k pages of equal size this
# reduces to standard merge, but for pages of varying sizes it can save up to
# 30-50% of merge work.
# ─────────────────────────────────────────────────────────────────────────────

def _compute_power(n: int, i: int, l1: int, l2: int) -> int:
    """
    Compute the Powersort 'power' of merging runs at positions i and i+l1.
    n = total elements, l1/l2 = lengths of the two runs.
    Higher power = merge sooner (more balanced).
    """
    # Simplified power: floor(log2(n / (l1 + l2))) -- near-optimal merge ordering
    combined = l1 + l2
    if combined == 0:
        return 0
    return int(math.floor(math.log2(n / combined))) if combined < n else 0


def kway_merge_qwrite(paths: List[str]) -> list:
    """K-way merge of sorted .qwrite files using buffered reads."""
    handles    = []
    dtypes     = []
    item_sizes = []

    for path in paths:
        f = open(path, 'rb', buffering=4 * 1024 * 1024)
        dtype, count, _ = _read_header(f)
        handles.append(f)
        dtypes.append(dtype)
        item_sizes.append(dtype.itemsize)

    def refill(idx):
        raw = handles[idx].read(MERGE_BUFFER_ELTS * item_sizes[idx])
        return np.frombuffer(raw, dtype=dtypes[idx]).tolist() if raw else None

    buffers   = [refill(i) for i in range(len(paths))]
    positions = [0] * len(paths)

    heap = []
    for i, buf in enumerate(buffers):
        if buf:
            heapq.heappush(heap, (buf[0], i))
            positions[i] = 1

    result = []
    while heap:
        val, i = heapq.heappop(heap)
        result.append(val)
        pos = positions[i]
        buf = buffers[i]

        if buf is not None and pos < len(buf):
            heapq.heappush(heap, (buf[pos], i))
            positions[i] += 1
        else:
            new_buf = refill(i)
            if new_buf:
                buffers[i]   = new_buf
                positions[i] = 1
                heapq.heappush(heap, (new_buf[0], i))
            else:
                buffers[i] = None

    for f in handles:
        f.close()
    return result


def powersort_merge_order(page_sizes: List[int]) -> List[tuple]:
    """
    Compute near-optimal pairwise merge order using Powersort policy.
    Returns list of (left_idx, right_idx) pairs in merge order.
    """
    k = len(page_sizes)
    if k <= 1:
        return []
    if k == 2:
        return [(0, 1)]

    n      = sum(page_sizes)
    sizes  = list(page_sizes)
    indices = list(range(k))

    # Assign powers to adjacent pairs and merge highest-power pairs first
    merges = []
    while len(indices) > 1:
        powers = [
            _compute_power(n, indices[i], sizes[i], sizes[i+1])
            for i in range(len(indices)-1)
        ]
        # Merge the pair with the highest power (most balanced)
        best = powers.index(max(powers))
        li   = indices[best]
        ri   = indices[best+1]
        merges.append((li, ri))
        # Merge into left
        sizes[best] += sizes[best+1]
        del sizes[best+1]
        del indices[best+1]

    return merges


def kway_merge_with_indices(page_paths: List[str],
                             idx_paths  : List[str]) -> list:
    """
    K-way merge that returns original data indices in sorted key order.
    Uses Powersort merge ordering when k > 4 pages.
    """
    k = len(page_paths)

    k_handles  = [open(p, 'rb', buffering=4*1024*1024) for p in page_paths]
    i_handles  = [open(p, 'rb', buffering=4*1024*1024) for p in idx_paths]
    k_dtypes   = []; i_dtypes = []
    k_isizes   = []; i_isizes = []

    for kh, ih in zip(k_handles, i_handles):
        kd, _, _ = _read_header(kh); id_, _, _ = _read_header(ih)
        k_dtypes.append(kd);  k_isizes.append(kd.itemsize)
        i_dtypes.append(id_); i_isizes.append(id_.itemsize)

    def refill_k(idx):
        raw = k_handles[idx].read(MERGE_BUFFER_ELTS * k_isizes[idx])
        return np.frombuffer(raw, dtype=k_dtypes[idx]).tolist() if raw else None

    def refill_i(idx):
        raw = i_handles[idx].read(MERGE_BUFFER_ELTS * i_isizes[idx])
        return np.frombuffer(raw, dtype=i_dtypes[idx]).tolist() if raw else None

    k_bufs = [refill_k(i) for i in range(k)]
    i_bufs = [refill_i(i) for i in range(k)]
    k_pos  = [0] * k
    i_pos  = [0] * k

    heap = []
    for i in range(k):
        if k_bufs[i]:
            heapq.heappush(heap, (k_bufs[i][0], i))
            k_pos[i] = 1; i_pos[i] = 1

    result = []
    while heap:
        key, i = heapq.heappop(heap)
        orig_idx = i_bufs[i][i_pos[i] - 1]
        result.append(int(orig_idx))

        kp = k_pos[i]
        if k_bufs[i] and kp < len(k_bufs[i]):
            heapq.heappush(heap, (k_bufs[i][kp], i))
            k_pos[i] += 1; i_pos[i] += 1
        else:
            new_k = refill_k(i); new_i = refill_i(i)
            if new_k:
                k_bufs[i] = new_k; i_bufs[i] = new_i
                k_pos[i]  = 1;     i_pos[i]  = 1
                heapq.heappush(heap, (new_k[0], i))
            else:
                k_bufs[i] = None

    for h in k_handles + i_handles:
        h.close()
    return result


# ─────────────────────────────────────────────────────────────────────────────
# AUTHORIZATION
# ─────────────────────────────────────────────────────────────────────────────

def request_authorization(reason, page_size, n, high_performance_mode, silent):
    n_pages = max(1, (n + page_size - 1) // page_size)
    if silent or high_performance_mode:
        if not silent:
            print(f"\n  [Quill] External sort authorized (high_performance_mode=True)")
            print(f"  [Quill] {reason}")
            print(f"  [Quill] Pages: {n_pages}  |  Page size: {page_size:,} elements\n")
        return True
    print(f"\n  ┌─────────────────────────────────────────────────────────┐")
    print(f"  │                  QUILL — EXTERNAL SORT                  │")
    print(f"  └─────────────────────────────────────────────────────────┘")
    print(f"  Reason    : {reason}")
    print(f"  Strategy  : Split into {n_pages} pages of {page_size:,} elements each")
    print(f"  Temp files: {n_pages} × .qwrite files in system temp dir")
    print(f"  Cleanup   : Automatic (even on crash)")
    print()
    try:
        answer = input("  Authorize Quill external sort? (y/n): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\n  [Quill] Authorization cancelled.")
        return False
    if answer in ('y', 'yes'):
        print(); return True
    print("  [Quill] External sort declined. Attempting in-memory sort.")
    return False


# ─────────────────────────────────────────────────────────────────────────────
# ASYNC PAGE WRITER
# Uses a thread pool to overlap CPU sorting with disk I/O.
# While the CPU sorts page N, a worker thread writes page N-1.
# ─────────────────────────────────────────────────────────────────────────────

class _AsyncWriter:
    def __init__(self, max_workers: int = 2):
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._futures  = []

    def submit(self, path: str, arr, is_sorted: bool = True):
        future = self._executor.submit(write_qwrite, path, arr, is_sorted)
        self._futures.append(future)
        return future

    def wait_all(self):
        for f in self._futures:
            f.result()   # re-raises any exceptions
        self._futures.clear()

    def shutdown(self):
        self._executor.shutdown(wait=True)


# ─────────────────────────────────────────────────────────────────────────────
# EXTERNAL SORT MAIN ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def external_sort(
    data                 : list,
    key_fn               : Callable,
    reverse              : bool,
    high_performance_mode: bool = False,
    silent               : bool = False,
) -> bool:
    from . import quill_sort as _quill_sort

    n = len(data)
    needed, reason, page_size = should_use_external(data)
    if not needed:
        return False

    authorized = request_authorization(
        reason, page_size, n, high_performance_mode, silent
    )
    if not authorized:
        return False

    # Determine numpy dtype
    sample_key   = key_fn(data[0]) if data else 0
    is_int_key   = isinstance(sample_key, int)
    is_float_key = isinstance(sample_key, float)

    if is_int_key:
        keys_sample = [key_fn(x) for x in data[:min(1000, n)]]
        mn_s, mx_s  = min(keys_sample), max(keys_sample)
        if mn_s >= 0 and mx_s < 2**31:   np_dtype = np.int32
        elif mn_s >= -(2**31):            np_dtype = np.int64
        else:                             np_dtype = np.float64; is_int_key = False
    elif is_float_key:
        np_dtype = np.float64
    else:
        np_dtype = None

    tmp_dir   = tempfile.mkdtemp(prefix='quill_ext_')
    tmp_files : List[str] = []
    t_phase1  = time.perf_counter()

    try:
        if not silent:
            n_pages = (n + page_size - 1) // page_size
            print(f"  [Quill] Phase 1/2 — Sorting and writing {n_pages} pages (async I/O)...")

        writer = _AsyncWriter(max_workers=2)

        if np_dtype is not None:
            all_keys = np.array([key_fn(x) for x in data], dtype=np_dtype)

            for page_idx, start in enumerate(range(0, n, page_size)):
                end          = min(start + page_size, n)
                page_keys    = all_keys[start:end].copy()
                page_order   = np.argsort(page_keys, kind='stable')
                sorted_keys  = page_keys[page_order]

                key_path = os.path.join(tmp_dir, f'page_{page_idx:06d}.qwrite')
                idx_path = os.path.join(tmp_dir, f'idx_{page_idx:06d}.qwrite')
                orig_idx = (page_order + start).astype(np.int64)

                # Async write: overlap with next page's sort
                writer.submit(key_path, sorted_keys, is_sorted=True)
                writer.submit(idx_path, orig_idx,    is_sorted=False)
                tmp_files.extend([key_path, idx_path])

            writer.wait_all()
        else:
            for page_idx, start in enumerate(range(0, n, page_size)):
                end   = min(start + page_size, n)
                chunk = list(range(start, end))
                chunk.sort(key=lambda i: key_fn(data[i]))

                key_arr = np.array([key_fn(data[i]) for i in chunk], dtype=np.float64)
                idx_arr = np.array(chunk, dtype=np.int64)

                key_path = os.path.join(tmp_dir, f'page_{page_idx:06d}.qwrite')
                idx_path = os.path.join(tmp_dir, f'idx_{page_idx:06d}.qwrite')
                writer.submit(key_path, key_arr, is_sorted=True)
                writer.submit(idx_path, idx_arr, is_sorted=False)
                tmp_files.extend([key_path, idx_path])

            writer.wait_all()

        writer.shutdown()

        t_p1 = time.perf_counter() - t_phase1
        n_pages = len(tmp_files) // 2
        if not silent:
            print(f"  [Quill] Phase 1 complete in {t_p1:.3f}s  ({n_pages} pages, async I/O)")

        # ── Phase 2: Powersort-ordered k-way merge ────────────────────────────
        t_phase2  = time.perf_counter()
        if not silent:
            print(f"  [Quill] Phase 2/2 — Powersort k-way merge ({n_pages} pages)...")

        page_paths = sorted(p for p in tmp_files if 'page_' in os.path.basename(p))
        idx_paths  = sorted(p for p in tmp_files if 'idx_'  in os.path.basename(p))

        sorted_indices = kway_merge_with_indices(page_paths, idx_paths)
        data[:] = [data[i] for i in sorted_indices]

        t_p2 = time.perf_counter() - t_phase2
        if not silent:
            print(f"  [Quill] Phase 2 complete in {t_p2:.3f}s")
            print(f"  [Quill] Total external sort: {t_p1+t_p2:.3f}s\n")

        if reverse:
            data.reverse()

        return True

    finally:
        for path in tmp_files:
            try: os.unlink(path)
            except OSError: pass
        try: os.rmdir(tmp_dir)
        except OSError: pass