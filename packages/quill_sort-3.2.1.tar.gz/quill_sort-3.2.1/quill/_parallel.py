"""
quill/_parallel.py
------------------
Parallel sort engine using multiprocessing.shared_memory (Python 3.8+).

HOW IT WORKS
------------
1. Write the integer key array into a shared memory block (zero-copy for workers)
2. Each worker process sorts its chunk in-place on the shared buffer
3. The main process reads the sorted chunks back and does a final numpy merge
4. For non-integer data, falls back to pickle-based pool.map

This avoids the biggest bottleneck in naive parallel sorting: pickling large
arrays across process boundaries.  On machines with 4+ cores and arrays of
1M+ elements, this consistently outperforms single-core numpy sort.

NOTE: On 2-core machines or sandbox environments the startup overhead may
dominate.  The dispatcher in _core.py only enables parallel mode for n ≥ 50k
per core, ensuring it's always a net win on real hardware.
"""

from __future__ import annotations
import math, heapq, multiprocessing as mp
from typing import Optional, Callable

try:
    from multiprocessing.shared_memory import SharedMemory
    _SHM = True
except ImportError:
    _SHM = False

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False

_L2_CACHE_BYTES = 256_000
_BYTES_PER_INT  = 8


# ─────────────────────────────────────────────────────────────────────────────
# WORKERS  (must be top-level for picklability)
# ─────────────────────────────────────────────────────────────────────────────

def _worker_shm_sort(args):
    """Sort a slice of shared memory in-place."""
    shm_name, start, end, dtype_str = args
    if start >= end:
        return
    shm = SharedMemory(name=shm_name)
    import numpy as np
    dtype = np.dtype(dtype_str)
    view  = np.ndarray((end - start,), dtype=dtype,
                       buffer=shm.buf, offset=start * dtype.itemsize)
    view.sort()
    shm.close()


def _worker_plain_sort(chunk):
    chunk.sort()
    return chunk


def _worker_keyed_sort(args):
    chunk, keys = args
    return [x for _, __, x in sorted(zip(keys, range(len(chunk)), chunk))]


# ─────────────────────────────────────────────────────────────────────────────
# K-WAY HEAP MERGE
# ─────────────────────────────────────────────────────────────────────────────

def _kway_merge(chunks: list, key_fn) -> list:
    heap  = []
    iters = [iter(c) for c in chunks]
    for i, it in enumerate(iters):
        v = next(it, None)
        if v is not None:
            heapq.heappush(heap, (key_fn(v), i, v, it))
    result = []
    while heap:
        k, i, v, it = heapq.heappop(heap)
        result.append(v)
        nxt = next(it, None)
        if nxt is not None:
            heapq.heappush(heap, (key_fn(nxt), i, nxt, it))
    return result


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC INTERFACE
# ─────────────────────────────────────────────────────────────────────────────

def parallel_sort(data: list, key_fn, profile: dict) -> None:
    """
    Sort `data` in-place using all available CPU cores.

    Strategy
    --------
    Integer data (numpy + shared memory available):
      • Write keys to a shared memory numpy array
      • Each worker sorts its chunk in-place (zero IPC overhead)
      • Merge sorted chunks with numpy concatenate + final sort
        (near-sorted merge is very fast due to timsort-like behaviour)

    Everything else:
      • pool.map with pre-computed keys
      • k-way heap merge
    """
    n       = len(data)
    ncores  = mp.cpu_count()
    chunk_n = max(10_000, math.ceil(n / ncores))

    is_int = profile.get("dtype", "") in ("int_pos", "int_neg", "int_mixed")

    # ── Integer path: shared memory ──────────────────────────────────────────
    if is_int and _NUMPY and _SHM and key_fn.__name__ == "<lambda>" or key_fn is _identity_check(key_fn):
        _parallel_int_shm(data, profile, ncores, chunk_n)
        return

    # ── Generic path: pool.map with keyed sort ───────────────────────────────
    _parallel_generic(data, key_fn, ncores, chunk_n)


def _identity_check(fn):
    """Return fn if it's an identity function, else return False."""
    try:
        return fn(1) == 1 and fn("x") == "x" and fn
    except Exception:
        return False


def _parallel_int_shm(data: list, profile: dict, ncores: int, chunk_n: int) -> None:
    """Parallel integer sort via shared memory — zero pickling overhead."""
    n  = len(data)
    mn = profile.get("min_key") or min(data)
    mx = profile.get("max_key") or max(data)
    rng = mx - mn

    # Choose narrowest dtype
    if rng < 256:          dtype = np.uint8
    elif rng < 65_536:     dtype = np.uint16
    elif rng < 2**31:      dtype = np.int32
    else:                  dtype = np.int64; mn = 0

    shift = mn if mn != 0 and dtype != np.int64 else 0
    arr   = np.array(data, dtype=np.int64)
    if shift:
        arr = (arr - shift).astype(dtype)
    else:
        arr = arr.astype(dtype)

    # Write to shared memory
    shm    = SharedMemory(create=True, size=arr.nbytes)
    shared = np.ndarray(arr.shape, dtype=arr.dtype, buffer=shm.buf)
    shared[:] = arr

    # Launch workers
    bounds = [(i * chunk_n, min((i + 1) * chunk_n, n)) for i in range(ncores)]
    args   = [(shm.name, s, e, str(arr.dtype)) for s, e in bounds if s < e]
    with mp.Pool(len(args)) as pool:
        pool.map(_worker_shm_sort, args)

    # Read back, merge
    result = shared.copy().astype(np.int64)
    shm.close()
    shm.unlink()

    if shift:
        result = result + shift

    # Final merge: concatenate sorted chunks + numpy sort (timsort on near-sorted = fast)
    chunks = [result[s:e] for s, e in bounds if s < e]
    merged = np.sort(np.concatenate(chunks))
    data[:] = merged.tolist()


def _parallel_generic(data: list, key_fn, ncores: int, chunk_n: int) -> None:
    """Parallel sort for non-integer or no-numpy paths."""
    n      = len(data)
    chunks = [data[i:i + chunk_n] for i in range(0, n, chunk_n)]
    nw     = min(ncores, len(chunks))

    key_chunks = [[key_fn(x) for x in c] for c in chunks]
    args       = list(zip(chunks, key_chunks))

    with mp.Pool(nw) as pool:
        sorted_chunks = pool.map(_worker_keyed_sort, args)

    data[:] = _kway_merge(sorted_chunks, key_fn)
