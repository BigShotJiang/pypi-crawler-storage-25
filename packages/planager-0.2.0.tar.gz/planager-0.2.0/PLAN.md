# planager — Feature Plans for LLM-Assisted Development

## Overview

planager is a lightweight tool that gives LLM coding agents (Claude Code,
Codex, etc.) the ability to automatically create, follow, and maintain
feature plans across sessions. The runtime behavior is pure markdown and
CLAUDE.md conventions — no database, no server. The Python package exists
only as a distribution mechanism: `uvx planager init` copies template files
into your project, then the package is no longer involved.

### What gets installed into your project

```
your-project/
  .plans/                    # feature plan markdown files (create as needed)
  .claude/
    skills/
      plan/SKILL.md          # /plan — create or resume a feature plan
      plan-status/SKILL.md   # /plan-status — summarize all plans
  CLAUDE.md                  # planager snippet appended (or created)
```

### What the agent does automatically (via CLAUDE.md instructions)

1. **Session start**: checks `.plans/` for `in-progress` plans and offers
   to resume.
2. **New feature work**: creates a plan (explore codebase, propose phases,
   get user approval) before writing code.
3. **During work**: checks off steps, adds notes, updates the plan file.
4. **On completion**: marks the plan `done` with a summary.

No MCP tools, no special runtime. The agent reads and writes markdown files.

---

## User experience

```bash
# One-time install (works from any machine with uv)
cd my-project
uvx planager init

# That's it. From now on, Claude Code automatically uses plans.
# Or use the slash commands:
#   /plan          — create a new plan or resume an existing one
#   /plan-status   — see progress across all plans
```

---

## Plan format

```markdown
---
feature: short-slug
title: Human-Readable Title
status: planning | in-progress | blocked | done
created: 2026-04-18
updated: 2026-04-18
---

## Context

What the feature is, why it matters, constraints, links to issues or docs.
Everything an agent needs to start or resume work without asking questions.

## Phase 1: <title>

Brief description of this phase's goal.

- [x] Completed step
- [ ] Pending step

## Phase 2: <title>

- [ ] Step
- [ ] Step

## Notes

Running log — decisions, blockers, things tried, links to commits/PRs.
```

Key properties:
- **Self-contained**: the plan has all context needed to resume work.
- **Round-trip safe**: agents read and rewrite plans without losing content.
- **Human-readable**: it's just markdown. Open it, read it, edit it by hand.
- **Git-friendly**: diffs show exactly what changed between sessions.

---

## CLAUDE.md snippet

The core integration. When present in a project's CLAUDE.md, it makes Claude
Code automatically aware of plans without any user prompting.

The snippet instructs the agent to:

1. **On session start**: check `.plans/` for any `in-progress` or `blocked`
   plans. If one exists and the user's request relates to it, read it and
   resume from the first unchecked step.
2. **When starting a new feature**: create a plan in `.plans/<slug>.md`
   before writing code. Explore the codebase, design phases, and get user
   approval on the plan before implementing.
3. **While working**: check off steps as they're completed. Add notes about
   decisions or blockers. Update the `updated` date and `status` field.
4. **On completion**: set status to `done`, write a final note summarizing
   what was built.

---

## Slash-command skills

### `/plan` — Create or resume a plan

Behavior:
- If there are `in-progress` plans, list them and ask which to resume (or
  offer to create a new one).
- If creating new: ask for a brief description, explore the codebase to
  understand what's involved, then draft a phased plan and present it for
  approval before saving to `.plans/`.
- If resuming: read the plan, summarize where things stand, and begin work
  from the first unchecked step.

### `/plan-status` — Show status of all plans

Reads all `.md` files in `.plans/`, parses frontmatter and checkboxes, and
prints a summary table:

```
Feature          Status       Progress
───────────────  ───────────  ─────────
auth             in-progress  Phase 2: 3/7
dark-mode        planning     Phase 1: 0/4
api-v2           done         5/5
```

---

## Architecture

```
planager/
  src/planager/
    __init__.py
    cli.py               # entry point: `planager init`
    templates/            # bundled template files
      CLAUDE.md.snippet
      plan/SKILL.md
      plan-status/SKILL.md
  pyproject.toml          # uv/hatchling config, [project.scripts]
  README.md
  PLAN.md                 # this file
```

The package is a thin wrapper around file-copy logic. The `init` command:
1. Creates `.plans/` directory.
2. Copies skill files into `.claude/skills/`.
3. Appends the CLAUDE.md snippet (or creates CLAUDE.md if absent).
4. Is idempotent — safe to run again without duplicating content.

Only dependency: Python stdlib. No runtime dependencies.

### Tooling

- **uv** — packaging, virtual environments, `uvx` for one-shot execution.
- **hatchling** — build backend.
- **ruff** — linting and formatting.
- **pytest** — tests.

---

## Phases of implementation

### Phase 1: Core content

The CLAUDE.md snippet and skill definitions are the product. Everything
else is packaging around them.

- [ ] Write the CLAUDE.md snippet with automatic plan behavior
  - Session-start: detect and offer to resume in-progress plans
  - New feature: explore, propose phased plan, get approval, save
  - During work: check steps, add notes, update frontmatter
  - Completion: set done, write summary
- [ ] Write `plan/SKILL.md` — the `/plan` skill
  - Create flow: gather description, explore, propose phases
  - Resume flow: read plan, summarize, begin from first unchecked step
- [ ] Write `plan-status/SKILL.md` — the `/plan-status` skill
  - Glob `.plans/*.md`, parse frontmatter + checkboxes, print table
- [ ] Test: add the snippet and skills to this repo, start a fresh session,
  verify the agent follows the plan workflow automatically

### Phase 2: Package and `init` command

- [ ] Set up project skeleton (pyproject.toml, src layout, uv sync)
- [ ] Bundle template files in `src/planager/templates/`
- [ ] Write `cli.py` with `planager init` command
  - Create `.plans/`
  - Copy skills into `.claude/skills/`
  - Append snippet to CLAUDE.md (skip if already present)
  - Idempotent
- [ ] Wire up `[project.scripts]` so `uvx planager init` works
- [ ] Write tests for the init command (verify files created, idempotency)
- [ ] Ensure `ruff check` and `ruff format --check` pass

### Phase 3: Distribution and docs

- [ ] Fill out pyproject.toml metadata (description, author, license, urls)
- [ ] Write README.md
  - One-liner install: `uvx planager init`
  - What it does, how it works, plan format reference
  - Examples of plan workflow in practice
- [ ] Test: `uvx` install from source into a clean project, verify workflow
- [ ] Publish to PyPI (`uv build && uv publish`)

### Phase 4: Polish

- [ ] Refine CLAUDE.md wording based on real usage
- [ ] Consider: Codex/AGENTS.md equivalent of the CLAUDE.md snippet
- [ ] Consider: `/plan-archive` skill to move done plans out of the way
- [ ] Consider: plan templates for different work types (feature vs bugfix)

---

## Non-goals

- Runtime dependencies or background processes
- Database or registry
- MCP server
- Web UI
- Issue tracker integration
