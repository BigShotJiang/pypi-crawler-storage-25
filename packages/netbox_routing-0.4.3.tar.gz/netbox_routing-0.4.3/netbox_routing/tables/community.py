import django_tables2 as tables
from django.utils.translation import gettext_lazy as _

from netbox.tables import NetBoxTable
from netbox_routing.models.community import *

__all__ = (
    'CommunityTable',
    'CommunityListTable',
    'CommunityListEntryTable',
)

from tenancy.tables import TenancyColumnsMixin


class CommunityTable(TenancyColumnsMixin, NetBoxTable):
    name = tables.Column(verbose_name=_('Name'), linkify=True)
    community = tables.Column(verbose_name=_('Community'), linkify=True)
    role = tables.Column(verbose_name=_('Role'), linkify=True)

    class Meta(NetBoxTable.Meta):
        model = Community
        fields = (
            'pk',
            'id',
            'name',
            'community',
            'role',
            'status',
            'description',
            'tenant_group',
            'tenant',
        )
        default_columns = (
            'pk',
            'id',
            'name',
            'community',
            'status',
            'description',
        )


class CommunityListTable(TenancyColumnsMixin, NetBoxTable):
    name = tables.Column(verbose_name=_('Name'), linkify=True)

    class Meta(NetBoxTable.Meta):
        model = CommunityList
        fields = (
            'pk',
            'id',
            'name',
            'description',
            'tenant_group',
            'tenant',
        )
        default_columns = (
            'pk',
            'id',
            'name',
            'description',
        )


class CommunityListEntryTable(NetBoxTable):
    community_list = tables.Column(verbose_name=_('Community List'), linkify=True)
    community = tables.Column(verbose_name=_('Community'), linkify=True)

    class Meta(NetBoxTable.Meta):
        model = CommunityListEntry
        fields = (
            'pk',
            'id',
            'community_list',
            'action',
            'community',
            'description',
        )
        default_columns = (
            'pk',
            'id',
            'community_list',
            'action',
            'community',
            'description',
        )
