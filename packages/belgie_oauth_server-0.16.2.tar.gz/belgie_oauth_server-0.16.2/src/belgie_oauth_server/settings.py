from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable, Mapping, Sequence
from datetime import datetime  # noqa: TC003
from functools import cached_property
from typing import TYPE_CHECKING, Literal, Self
from urllib.parse import urlparse, urlunparse

from belgie_proto.oauth_server import (
    OAuthServerAccessTokenProtocol,
    OAuthServerAdapterProtocol,
    OAuthServerAuthorizationCodeProtocol,
    OAuthServerAuthorizationStateProtocol,
    OAuthServerClientProtocol,
    OAuthServerConsentProtocol,
    OAuthServerRefreshTokenProtocol,
)
from pydantic import AnyHttpUrl, AnyUrl, BaseModel, Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from belgie_oauth_server.models import OAuthServerClientInformationFull, OAuthServerClientMetadata
from belgie_oauth_server.signing import OAuthServerSigning

if TYPE_CHECKING:
    from belgie_core.core.settings import BelgieSettings

    from belgie_oauth_server.plugin import OAuthServerPlugin

type RequestURIParams = Mapping[str, str]
type RequestURIResolver = Callable[[str, str], RequestURIParams | Awaitable[RequestURIParams | None] | None]
type SelectAccountResolver = Callable[[str, str, str, list[str]], bool | Awaitable[bool]]
type PostLoginResolver = Callable[[str, str, str, list[str]], bool | Awaitable[bool]]
type OAuthServerGrantType = Literal["authorization_code", "client_credentials", "refresh_token"]
type ConsentReferenceResolver = Callable[[str, str, str, list[str]], str | Awaitable[str | None] | None]
type ClientReferenceResolver = Callable[[str, str], str | Awaitable[str | None] | None]
type ClientPrivilegesResolver = Callable[
    [Literal["create", "read", "update", "delete", "list", "rotate"], str, str, str | None],
    bool | Awaitable[bool] | None,
]
type ScopeExpirations = dict[str, int]
type AccessTokenClaimsResolver = Callable[[dict[str, object]], dict[str, object] | Awaitable[dict[str, object]]]
type IdTokenClaimsResolver = Callable[[dict[str, object]], dict[str, object] | Awaitable[dict[str, object]]]
type UserInfoClaimsResolver = Callable[[dict[str, object]], dict[str, object] | Awaitable[dict[str, object]]]
type TokenResponseFieldsResolver = Callable[[dict[str, object]], dict[str, object] | Awaitable[dict[str, object]]]
type TokenGenerator = Callable[[], str | Awaitable[str]]
type RefreshTokenEncoder = Callable[[str, str | None], str | Awaitable[str]]
type RefreshTokenDecoder = Callable[[str], tuple[str | None, str] | Awaitable[tuple[str | None, str]]]
type TrustedClient = OAuthServerClientMetadata | OAuthServerClientInformationFull
type TrustedClientResolver = Callable[[TrustedClient], bool | Awaitable[bool] | None]

PAIRWISE_SECRET_MIN_LENGTH = 32


class OAuthServerTokenPrefixSettings(BaseModel):
    access_token: str | None = None
    refresh_token: str | None = None
    client_secret: str | None = None


class OAuthServerAdvertisedMetadata(BaseModel):
    scopes_supported: list[str] | None = None
    claims_supported: list[str] | None = None
    protected_resource_scopes_supported: list[str] | None = None


class OAuthServerRateLimitRule(BaseModel):
    window: int = 60
    max: int = 20


class OAuthServerRateLimitSettings(BaseModel):
    model_config = {"populate_by_name": True}

    token: OAuthServerRateLimitRule | None = Field(default_factory=OAuthServerRateLimitRule)
    authorize: OAuthServerRateLimitRule | None = Field(default_factory=lambda: OAuthServerRateLimitRule(max=30))
    introspect: OAuthServerRateLimitRule | None = Field(default_factory=lambda: OAuthServerRateLimitRule(max=100))
    revoke: OAuthServerRateLimitRule | None = Field(default_factory=lambda: OAuthServerRateLimitRule(max=30))
    registration: OAuthServerRateLimitRule | None = Field(
        default_factory=lambda: OAuthServerRateLimitRule(max=5),
        alias="register",
        serialization_alias="register",
    )
    userinfo: OAuthServerRateLimitRule | None = Field(default_factory=lambda: OAuthServerRateLimitRule(max=60))


class OAuthServerResource(BaseModel):
    prefix: str
    scopes: list[str] | None = None

    @field_validator("prefix")
    @classmethod
    def validate_prefix(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            msg = "prefix must be a non-empty path"
            raise ValueError(msg)
        if not normalized.startswith("/"):
            msg = "prefix must start with '/'"
            raise ValueError(msg)
        return normalized

    def resolve_url(self, base_url: str | AnyHttpUrl) -> AnyHttpUrl:
        parsed = urlparse(str(base_url))
        base_path = parsed.path.rstrip("/")
        full_path = f"{base_path}{self.prefix}" if base_path else self.prefix
        return AnyHttpUrl(urlunparse(parsed._replace(path=full_path, query="", fragment="")))


class OAuthServer(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="BELGIE_OAUTH_",
        env_file=".env",
        extra="ignore",
        arbitrary_types_allowed=True,
    )

    adapter: OAuthServerAdapterProtocol[
        OAuthServerClientProtocol,
        OAuthServerAuthorizationStateProtocol,
        OAuthServerAuthorizationCodeProtocol,
        OAuthServerAccessTokenProtocol,
        OAuthServerRefreshTokenProtocol,
        OAuthServerConsentProtocol,
    ] = Field(exclude=True)

    base_url: AnyHttpUrl | None = None
    prefix: str = "/oauth"
    login_url: str | None = None
    signup_url: str | None = None
    consent_url: str | None = None
    select_account_url: str | None = None

    client_id: str = "belgie_client"
    client_secret: SecretStr | None = None
    redirect_uris: list[AnyUrl] = Field(min_length=1)
    grant_types: list[OAuthServerGrantType] = Field(
        default_factory=lambda: ["authorization_code", "client_credentials", "refresh_token"],
    )
    default_scopes: Sequence[str] = Field(default_factory=tuple)
    static_client_require_pkce: bool = True
    pairwise_secret: SecretStr | None = None
    signing: OAuthServerSigning = Field(default_factory=OAuthServerSigning)

    authorization_code_ttl_seconds: int = 300
    access_token_ttl_seconds: int = 3600
    refresh_token_ttl_seconds: int = 2592000
    id_token_ttl_seconds: int = 36000
    state_ttl_seconds: int = 600
    code_challenge_method: Literal["S256"] = "S256"
    scope_expirations: ScopeExpirations | None = None
    enable_end_session: bool = False
    allow_dynamic_client_registration: bool = False
    allow_unauthenticated_client_registration: bool = False
    allow_public_client_prelogin: bool = False
    client_registration_default_scopes: list[str] | None = None
    client_registration_allowed_scopes: list[str] | None = None
    client_registration_client_secret_expires_at: int | datetime | None = 0
    client_credentials_default_scopes: list[str] | None = None
    resources: list[OAuthServerResource] | None = Field(default=None, min_length=1, max_length=1)
    include_root_resource_metadata_fallback: bool = True
    include_root_oauth_metadata_fallback: bool = True
    include_root_openid_metadata_fallback: bool = True
    request_uri_resolver: RequestURIResolver | None = None
    select_account_resolver: SelectAccountResolver | None = None
    post_login_url: str | None = None
    post_login_resolver: PostLoginResolver | None = None
    consent_reference_resolver: ConsentReferenceResolver | None = None
    client_reference_resolver: ClientReferenceResolver | None = None
    client_privileges: ClientPrivilegesResolver | None = None
    trusted_client_resolver: TrustedClientResolver | None = None
    custom_access_token_claims: AccessTokenClaimsResolver | None = None
    custom_id_token_claims: IdTokenClaimsResolver | None = None
    custom_userinfo_claims: UserInfoClaimsResolver | None = None
    custom_token_response_fields: TokenResponseFieldsResolver | None = None
    generate_client_id: TokenGenerator | None = None
    generate_client_secret: TokenGenerator | None = None
    generate_access_token: TokenGenerator | None = None
    generate_refresh_token: TokenGenerator | None = None
    refresh_token_encoder: RefreshTokenEncoder | None = None
    refresh_token_decoder: RefreshTokenDecoder | None = None
    token_prefixes: OAuthServerTokenPrefixSettings = Field(default_factory=OAuthServerTokenPrefixSettings)
    advertised_metadata: OAuthServerAdvertisedMetadata | None = None
    rate_limit: OAuthServerRateLimitSettings = Field(default_factory=OAuthServerRateLimitSettings)

    @model_validator(mode="before")
    @classmethod
    def reject_legacy_settings(cls, values: object) -> object:
        if isinstance(values, dict):
            if "route_prefix" in values:
                msg = "`route_prefix` has been removed; use `prefix` instead"
                raise ValueError(msg)
            if "resource_server_url" in values:
                msg = "`resource_server_url` has been removed; use `resources=[OAuthServerResource(...)]` instead"
                raise ValueError(msg)
            if "resource_scopes" in values:
                msg = "`resource_scopes` has been removed; use `resources=[OAuthServerResource(scopes=[...])]` instead"
                raise ValueError(msg)
        return values

    @field_validator("adapter")
    @classmethod
    def validate_adapter(
        cls,
        value: OAuthServerAdapterProtocol[
            OAuthServerClientProtocol,
            OAuthServerAuthorizationStateProtocol,
            OAuthServerAuthorizationCodeProtocol,
            OAuthServerAccessTokenProtocol,
            OAuthServerRefreshTokenProtocol,
            OAuthServerConsentProtocol,
        ],
    ) -> OAuthServerAdapterProtocol[
        OAuthServerClientProtocol,
        OAuthServerAuthorizationStateProtocol,
        OAuthServerAuthorizationCodeProtocol,
        OAuthServerAccessTokenProtocol,
        OAuthServerRefreshTokenProtocol,
        OAuthServerConsentProtocol,
    ]:
        if not isinstance(value, OAuthServerAdapterProtocol):
            msg = "adapter must implement OAuthServerAdapterProtocol"
            raise TypeError(msg)
        return value

    @model_validator(mode="after")
    def validate_refresh_token_hooks(self) -> Self:
        if self.refresh_token_encoder is not None and self.refresh_token_decoder is None:
            msg = "refresh_token_decoder is required when refresh_token_encoder is configured"
            raise ValueError(msg)
        if "refresh_token" in self.grant_types and "authorization_code" not in self.grant_types:
            msg = "refresh_token grant requires authorization_code grant"
            raise ValueError(msg)
        if "authorization_code" in self.grant_types:
            if self.login_url is None:
                msg = "login_url is required when authorization_code grant is enabled"
                raise ValueError(msg)
            if self.consent_url is None:
                msg = "consent_url is required when authorization_code grant is enabled"
                raise ValueError(msg)
        if self.pairwise_secret is not None:
            pairwise_secret_value = self.pairwise_secret.get_secret_value()
            if len(pairwise_secret_value) < PAIRWISE_SECRET_MIN_LENGTH:
                msg = "pairwise_secret must be at least 32 characters"
                raise ValueError(msg)
        return self

    @field_validator("grant_types")
    @classmethod
    def validate_grant_types(cls, value: list[OAuthServerGrantType]) -> list[OAuthServerGrantType]:
        deduped: list[OAuthServerGrantType] = []
        for grant_type in value:
            if grant_type not in deduped:
                deduped.append(grant_type)
        return deduped

    @cached_property
    def issuer_url(self) -> AnyHttpUrl | None:
        if self.base_url is None:
            return None

        parsed = urlparse(str(self.base_url))
        base_path = parsed.path.rstrip("/")
        prefix = self.prefix.strip("/")
        auth_path = "auth"
        full_path = f"{base_path}/{auth_path}/{prefix}" if prefix else f"{base_path}/{auth_path}"
        return AnyHttpUrl(urlunparse(parsed._replace(path=full_path, query="", fragment="")))

    def resolve_resource(
        self,
        fallback_base_url: str | AnyHttpUrl | None = None,
    ) -> tuple[AnyHttpUrl, list[str] | None] | None:
        if self.resources is None:
            return None

        base_url = self.base_url if self.base_url is not None else fallback_base_url
        if base_url is None:
            msg = "base_url is required to resolve OAuth resources"
            raise ValueError(msg)

        resource = self.resources[0]
        return resource.resolve_url(base_url), resource.scopes

    def supported_scopes(self) -> list[str]:
        scopes = [*self.default_scopes, "openid", "profile", "email", "offline_access"]
        if self.resources is not None:
            scopes.extend(self.resources[0].scopes or [])
        if self.client_registration_allowed_scopes is not None:
            scopes.extend(self.client_registration_allowed_scopes)
        supported: list[str] = []
        for scope in scopes:
            normalized = scope.strip()
            if normalized and normalized not in supported:
                supported.append(normalized)
        return supported

    def supports_grant_type(self, grant_type: str) -> bool:
        return grant_type in self.grant_types

    def supports_authorization_code(self) -> bool:
        return self.supports_grant_type("authorization_code")

    async def is_trusted_client(self, oauth_client: TrustedClient) -> bool:
        if oauth_client.skip_consent:
            return True
        if self.trusted_client_resolver is None:
            return False

        trusted = self.trusted_client_resolver(oauth_client)
        if inspect.isawaitable(trusted):
            trusted = await trusted
        return bool(trusted)

    def __call__(self, belgie_settings: BelgieSettings) -> OAuthServerPlugin:
        plugin_class = __import__("belgie_oauth_server.plugin", fromlist=["OAuthServerPlugin"]).OAuthServerPlugin
        return plugin_class(belgie_settings, self)
