from setuptools import setup, find_packages

setup(
    name="cacmath",
    version="1.0.0",
    packages=find_packages(),
    description="YAA caculator",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
)
