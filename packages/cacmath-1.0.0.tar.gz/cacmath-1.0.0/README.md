YAA caculator

addition only

ex. caculator(1 + 1)
