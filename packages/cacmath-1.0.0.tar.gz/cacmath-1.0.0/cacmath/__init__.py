def caculate(expr):
    parts = expr.split("+")
    one = int(parts[0].strip())
    two = int(parts[1].strip())
    result = one + two
    print(result)
    return result
