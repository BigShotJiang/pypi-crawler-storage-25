# alibaba_production_Business

## 项目简介
本项目用于串联两类能力：
- Alibaba OpenAPI（ICBU）：获取商品详情、获取/渲染商品发布 Schema（XML）、在 Schema 上做字段级读写、并将修改后的 XML 发布为“商品草稿”。
- AlphaShop AI：根据商品信息生成多语言卖点（Selling Points），并回填到商品 Schema 的“商品卖点”字段。

核心思想：以 Alibaba 返回的 **Schema XML** 作为“真源数据结构”，通过 `SchemaNode` 对 XML 做结构化读写，然后再回传到发布草稿接口。

## 目录结构
- alibaba_production_business/
  - api/
    - alibaba_client.py：Alibaba OpenAPI 调用封装（sync 接口 + 手动签名、token 获取、schema render、发布草稿等）
    - alpha_shop.py：AlphaShop “多语言卖点生成”接口封装（JWT 鉴权 + POST 请求）
  - business/
    - core.py：SchemaNode（核心领域对象），提供对 Schema XML 的读写能力
    - common.py：将 schema XML 字符串解析为 SchemaNode
  - tools/
    - generate_jwt_token.py：生成 HS256 JWT（用于 AlphaShop Bearer 鉴权）
    - sha256_signature.py：签名/Token 相关工具（备用）
- example/
  - getProductSchema.xml：Schema 示例（用于字段结构参考，如商品属性、阶梯价等）
- test/
  - 获取主图.py：最小可运行示例（商品详情 → schema render → 解析 → 提取主图）

## 主要业务流程
### 1) 获取线上商品 + 获取可编辑 Schema(XML)
- 调用 `alibaba_production_business.api.alibaba_client.get_product_detail(product_id)` 获取商品详情，得到 `category_id`
- 调用 `alibaba_production_business.api.alibaba_client.get_product_schema_render(cat_id, product_id)` 获取 schema render，其中 `body["data"]` 为 XML 字符串
- 调用 `alibaba_production_business.business.common.get_alibaba_schema(schema_xml, category_id)` 将 XML 解析为 `SchemaNode`

### 2) 在 Schema 上读取/修改字段
`SchemaNode`（business/core.py）提供常用字段的读写：
- 标题：`set_product_title(new_title)`
- 主图：`get_production_sc_images()` / `set_production_sc_images(images)`
- 商品卖点：`get_product_selling_points()` / `set_product_selling_points(text)`
- 类目商品属性：`get_product_attributes()`
- 阶梯价：`get_ladder_price()` / `set_ladder_price(ladder_prices)`

其中阶梯价写入需要满足平台校验：**数量越大，单价必须递减（或不递增）**，否则发布草稿会报错（例如 `Tiered prices must be in descending order`）。

### 3) 生成多语言卖点（AlphaShop）
- 调用 `alibaba_production_business.api.alpha_shop.call_selling_point(...)`
  - 从项目根目录 `env.json` 读取 `ALPHASHOP_ACCESS_KEY` 与 `ALPHASHOP_SECRET_KEY`
  - 生成 Bearer JWT 并发起 POST 请求到：
    - `https://api.alphashop.cn/ai.text.generateMultiLanguageSellingPoint/1.0`
  - 成功时返回卖点文本（取 `result.result[0]`）

### 4) 发布草稿（把修改后的 XML 提交到 Alibaba）
- 调用 `alibaba_production_business.api.alibaba_client.add_product_schema_draft(xml, cat_id, ...)`
  - 目标接口：`https://open-api.alibaba.com/sync`
  - method：`alibaba.icbu.product.schema.add.draft`
  - 传参：`param_product_top_publish_request`（紧凑 JSON）
  - 签名：按参数名排序拼接 `key+value`，用 `ALIBABA_API_SECRET` 做 HMAC-SHA256，hex 大写
  - 成功时返回 `product_id`（草稿商品明文 id）

## 配置说明（env.json）
项目使用根目录 `env.json` 存放运行所需配置（不要在 README 中写入真实密钥）：
- Alibaba：`ALIBABA_API_KEY`、`ALIBABA_API_SECRET`、`ALIBABA_ACCESS_TOKEN`、`ALIBABA_REFRESH_TOKEN` 等
- AlphaShop：`ALPHASHOP_ACCESS_KEY`、`ALPHASHOP_SECRET_KEY`

## 运行示例
最小流程示例在 `test/获取主图.py`：
- 读取商品详情 → 获取 schema render → 解析 XML → 提取主图字段

## 作为依赖被其它项目引用（方案 A）
本仓库已提供可安装包 `alibaba_production_business`（对应 pip 包名 `alibaba-production-business`）。

### 安装方式
- 本地开发（推荐）：
  - `pip install -e /path/to/alibaba_production_Business`
- 或在其它项目中使用本地路径安装：
  - `pip install /path/to/alibaba_production_Business`

### 其它项目中导入
- Alibaba OpenAPI：
  - `from alibaba_production_business.api.alibaba_client import get_product_detail, get_product_schema_render, add_product_schema_draft`
- AlphaShop 卖点：
  - `from alibaba_production_business.api.alpha_shop import call_selling_point`
- Schema 读写：
  - `from alibaba_production_business.business.common import get_alibaba_schema`

### env.json 定位规则
默认优先读取调用方当前工作目录下的 `env.json`；也可通过环境变量 `ALIBABA_PRODUCTION_ENV_JSON` 指定 `env.json` 的绝对路径。

## 发布到 PyPI（公共）
发布前准备：
- 不要把 `env.json` 发布到 PyPI；建议用 `env.example.json` 做模板，并在调用方项目中自行提供真实 `env.json`
- 本项目已通过 `MANIFEST.in` 排除 `env.json`，并在 `.gitignore` 忽略 `env.json`

构建并检查包：
- `python -m pip install -U build twine`
- `python -m build`
- `python -m twine check dist/*`

上传到 PyPI：
- 先在 PyPI 站点创建账号，并生成 API Token
- 建议设置环境变量（两种其一）：
  - `export TWINE_USERNAME=__token__`
  - `export TWINE_PASSWORD=pypi-...`
- 上传：
  - `python -m twine upload dist/*`

## 注意事项
- `SchemaNode.tree` 会尝试写入 `data/tree_output.json`，运行前请确保 `data/` 目录存在。
- 若出现 PyJWT 的 `InsecureKeyLengthWarning`，通常是对 HMAC key 长度的安全提醒，不一定影响功能；若密钥可控建议使用更长的随机密钥。

## 测试代码
测试代码写在 test文件夹中
