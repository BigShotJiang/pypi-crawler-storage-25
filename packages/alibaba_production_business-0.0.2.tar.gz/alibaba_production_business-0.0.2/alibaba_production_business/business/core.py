import json
import xml.etree.ElementTree as ET
from collections import defaultdict


def schema_to_tree(elem: ET.Element):
    obj = {}

    if elem.attrib:
        obj["@attrs"] = dict(elem.attrib)
    text = (elem.text or "").strip()
    if text:
        obj["#text"] = text

    children = list(elem)
    if children:
        groups = defaultdict(list)
        for c in children:
            groups[c.tag].append(schema_to_tree(c))
        for tag, items in groups.items():
            obj[tag] = items
    return obj


class SchemaNode:
    def __init__(self, root: ET.Element, category_id: str):
        self.element = root
        self.category_id = category_id

    @property
    def tree(self):
        ret = schema_to_tree(self.element)
        with open("data/tree_output.json", "w", encoding="utf-8") as f:
            json.dump(ret, f, ensure_ascii=False, indent=2)
        return ret

    @property
    def xml(self):
        xml_str = ET.tostring(self.element, encoding="unicode")
        return xml_str

    def set_product_title(self, new_product_name: str) -> ET.Element | None:
        field = self.element.find(".//field[@id='productTitle']")
        if field is None:
            return None

        value_node = field.find("value")
        if value_node is None:
            value_node = ET.SubElement(field, "value")
        value_node.text = new_product_name
        return field

    def get_production_sc_images(self) -> dict:
        ret = {}
        for id in [f"scImages_{i}" for i in range(5)]:
            field = self.element.find(f".//field[@id='{id}'][@type='input']")
            if field is None:
                continue
            value_node = field.find("value")
            if value_node is None:
                continue
            ret[id] = value_node.text
        return ret

    def get_product_selling_points(self) -> str:
        field = self.element.find(".//field[@id='textDesc']")
        if field is None:
            field = self.element.find(".//field[@name='商品卖点']")
        if field is None:
            return ""
        value_node = field.find("value")
        if value_node is None or value_node.text is None:
            return ""
        text = value_node.text.strip()
        if not text:
            return ""
        return text

    def set_product_selling_points(self, selling_points: str) -> ET.Element | None:
        field = self.element.find(".//field[@id='textDesc']")
        if field is None:
            field = self.element.find(".//field[@name='商品卖点']")

        if field is None:
            item_schema = self.element
            if item_schema.tag != "itemSchema":
                item_schema = self.element.find(".//itemSchema")
            if item_schema is None:
                item_schema = self.element

            field = ET.SubElement(item_schema, "field", {"id": "textDesc", "name": "商品卖点", "type": "input"})

        value_node = field.find("value")
        if value_node is None:
            value_node = ET.SubElement(field, "value")

        value_node.text = selling_points
        return field

    def set_production_sc_images(
        self,
        images: {
            "scImages_0": str | None,
            "scImages_1": str | None,
            "scImages_2": str | None,
            "scImages_3": str | None,
            "scImages_4": str | None,
            "scImages_5": str | None,
        },
    ) -> ET.Element | None:
        print("设置主图", images.items())
        nodes = []
        for id, value in images.items():
            if value is None:
                continue
            field = self.element.find(f".//field[@id='{id}'][@type='input']")
            print(f"找到id为{id}的节点:", field)
            if field is None:
                print(f"未找到id为{id}的节点")
                continue
            value_node = field.find("value")
            if value_node is None:
                value_node = ET.SubElement(field, "value")
            value_node.text = value
            nodes.append(field)
        return nodes

    def get_product_attributes(self) -> dict:
        ret = {}
        icbu_node = self.element.find(".//field[@id='icbuCatProp']")
        if icbu_node is None:
            return ret

        complex_value = icbu_node.find("complex-value")
        if complex_value is None:
            return ret

        for field in complex_value.findall("field"):
            attr_name = field.get("name")
            if not attr_name:
                continue

            attr_type = field.get("type")

            if attr_type in ("singleCheck", "input", "singleCheckInput"):
                value_node = field.find("value")
                if value_node is not None:
                    val = value_node.get("inputValue") or value_node.text
                    if val:
                        ret[attr_name] = val
            elif attr_type in ("multiCheck", "multiCheckInput"):
                values_node = field.find("values")
                if values_node is not None:
                    vals = []
                    for v_node in values_node.findall("value"):
                        val = v_node.get("inputValue") or v_node.text
                        if val:
                            vals.append(val)
                    if vals:
                        ret[attr_name] = vals
        return ret

    def get_ladder_price(self) -> list[dict]:
        field = self.element.find(".//field[@id='ladderPrice']")
        if field is None:
            field = self.element.find(".//field[@name='阶梯价']")
        if field is None:
            return []

        complex_value = field.find("complex-value")
        if complex_value is None:
            return []

        ret: list[dict] = []
        for ladder_field in complex_value.findall("field"):
            ladder_cv = ladder_field.find("complex-value")
            if ladder_cv is None:
                continue

            q_node = ladder_cv.find("field[@id='quantity']/value")
            p_node = ladder_cv.find("field[@id='price']/value")
            if q_node is None or p_node is None or q_node.text is None or p_node.text is None:
                continue

            q_text = q_node.text.strip()
            p_text = p_node.text.strip()
            if not q_text or not p_text:
                continue

            try:
                quantity = int(float(q_text))
                price = float(p_text)
            except ValueError:
                continue

            ret.append({"quantity": quantity, "price": price})

        ret.sort(key=lambda x: x["quantity"])
        return ret

    def set_ladder_price(self, ladder_prices: list[dict]) -> ET.Element | None:
        if not ladder_prices:
            return None

        normalized: list[dict] = []
        for item in ladder_prices:
            if not isinstance(item, dict):
                continue
            if "quantity" not in item or "price" not in item:
                continue
            try:
                quantity = int(float(str(item["quantity"]).strip()))
                price = float(str(item["price"]).strip())
            except ValueError:
                continue
            if quantity <= 0 or price <= 0:
                continue
            normalized.append({"quantity": quantity, "price": price})

        if not normalized:
            return None

        normalized.sort(key=lambda x: x["quantity"])
        normalized = normalized[:4]
        for i in range(1, len(normalized)):
            if normalized[i]["price"] > normalized[i - 1]["price"]:
                return None

        field = self.element.find(".//field[@id='ladderPrice']")
        if field is None:
            field = self.element.find(".//field[@name='阶梯价']")

        if field is None:
            item_schema = self.element
            if item_schema.tag != "itemSchema":
                item_schema = self.element.find(".//itemSchema")
            if item_schema is None:
                item_schema = self.element
            field = ET.SubElement(item_schema, "field", {"id": "ladderPrice", "name": "阶梯价", "type": "complex"})

        complex_value = field.find("complex-value")
        if complex_value is None:
            complex_value = ET.SubElement(field, "complex-value")
        else:
            for child in list(complex_value):
                complex_value.remove(child)

        for idx, item in enumerate(normalized):
            ladder_field = ET.SubElement(complex_value, "field", {"id": f"ladderPrice_{idx}", "type": "complex"})
            ladder_cv = ET.SubElement(ladder_field, "complex-value")

            q_field = ET.SubElement(ladder_cv, "field", {"id": "quantity", "type": "input"})
            q_value = ET.SubElement(q_field, "value")
            q_value.text = str(item["quantity"])

            p_field = ET.SubElement(ladder_cv, "field", {"id": "price", "type": "input"})
            p_value = ET.SubElement(p_field, "value")
            p_value.text = str(item["price"])

        return field
