import xml.etree.ElementTree as ET

from alibaba_production_business.business.core import SchemaNode


def get_alibaba_schema(schema: str, category_id: str) -> SchemaNode | None:
    if not schema:
        return None

    try:
        root = ET.fromstring(schema)
    except ET.ParseError:
        return None
    return SchemaNode(root, category_id)

