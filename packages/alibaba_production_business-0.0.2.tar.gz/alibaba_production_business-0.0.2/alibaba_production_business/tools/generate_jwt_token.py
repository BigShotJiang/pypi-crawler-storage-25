import time

import jwt


def generate_jwt_token(access_key, secret_key):
    try:
        current_time = int(time.time())
        expired_at = current_time + 1800
        not_before = current_time - 5

        headers = {"alg": "HS256", "typ": "JWT"}
        payload = {"iss": access_key, "exp": expired_at, "nbf": not_before}

        token = jwt.encode(payload, secret_key, algorithm="HS256", headers=headers)
        return token
    except Exception as e:
        print(f"生成JWT token失败: {str(e)}")
        return None

