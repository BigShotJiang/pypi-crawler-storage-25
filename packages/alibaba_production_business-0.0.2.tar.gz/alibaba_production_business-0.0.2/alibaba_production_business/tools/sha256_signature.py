import base64
import hashlib
import hmac
import json
import time


def sha256_signature(
    access_key: str,
    secret_key: str,
    expires_in_seconds: int = 1800,
    not_before_skew_seconds: int = 5,
) -> str | None:
    try:
        now = int(time.time())
        header = {"alg": "HS256", "typ": "JWT"}
        payload = {
            "iss": access_key,
            "exp": now + int(expires_in_seconds),
            "nbf": now - int(not_before_skew_seconds),
        }

        def b64url(data: bytes) -> str:
            return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")

        header_b64 = b64url(json.dumps(header, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
        payload_b64 = b64url(json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
        signing_input = f"{header_b64}.{payload_b64}".encode("utf-8")
        signature = hmac.new(secret_key.encode("utf-8"), signing_input, hashlib.sha256).digest()
        sig_b64 = b64url(signature)
        return f"{header_b64}.{payload_b64}.{sig_b64}"
    except Exception:
        return None

