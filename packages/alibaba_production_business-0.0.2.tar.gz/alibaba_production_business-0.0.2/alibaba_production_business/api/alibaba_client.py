import hashlib
import hmac
import json
import time

import requests

from alibaba_production_business.config import load_env, save_env

import iop


GATEWAY = "https://open-api.alibaba.com/rest"
SYNC_URL = "https://open-api.alibaba.com/sync"


def _sha256_sign(params: dict, app_secret: str) -> str:
    sorted_keys = sorted(params.keys())
    query_string = ""
    for key in sorted_keys:
        query_string += str(key) + str(params[key])
    return hmac.new(app_secret.encode("utf-8"), query_string.encode("utf-8"), hashlib.sha256).hexdigest().upper()


def create_access_token(code: str, uuid: str | None = None) -> dict:
    env_data = load_env()
    client = iop.IopClient(GATEWAY, env_data.get("ALIBABA_API_KEY", ""), env_data.get("ALIBABA_API_SECRET", ""))
    request = iop.IopRequest("/auth/token/create")
    request.add_api_param("code", code)
    if uuid:
        request.add_api_param("uuid", uuid)

    response = client.execute(request)
    if response.body and isinstance(response.body, dict):
        access_token = response.body.get("access_token")
        refresh_token = response.body.get("refresh_token")
        if access_token and refresh_token:
            env_data["ALIBABA_ACCESS_TOKEN"] = access_token
            env_data["ALIBABA_REFRESH_TOKEN"] = refresh_token
            save_env(env_data)
    return {"type": response.type, "body": response.body}


def get_product_detail(product_id: str, access_token: str | None = None) -> dict:
    try:
        env_data = load_env()
        app_key = env_data.get("ALIBABA_API_KEY", "")
        app_secret = env_data.get("ALIBABA_API_SECRET", "")
        token = access_token or env_data.get("ALIBABA_ACCESS_TOKEN", "")

        timestamp = str(int(round(time.time() * 1000)))
        params = {
            "product_id": str(product_id),
            "language": "en_US",
            "version": "trade.1.1",
            "method": "alibaba.icbu.product.get",
            "app_key": app_key,
            "sign_method": "sha256",
            "session": token,
            "timestamp": timestamp,
            "format": "json",
            "v": "2.0",
            "simplify": "true",
        }

        params = {k: v for k, v in params.items() if v is not None}
        params["sign"] = _sha256_sign(params, app_secret)

        response = requests.get(SYNC_URL, params=params, timeout=30)
        try:
            body = response.json()
        except Exception:
            body = response.text
        return {"type": "manual_sync", "body": body}
    except requests.exceptions.RequestException as e:
        return {"type": "manual_sync", "body": {"error_response": {"msg": f"Request failed: {str(e)}"}}}
    except Exception as e:
        return {"type": "manual_sync", "body": {"error_response": {"msg": f"Unexpected error: {str(e)}"}}}


def get_product_schema_render(cat_id: str | None = None, product_id: str | None = None) -> dict:
    env_data = load_env()
    app_key = env_data.get("ALIBABA_API_KEY", "")
    app_secret = env_data.get("ALIBABA_API_SECRET", "")
    token = env_data.get("ALIBABA_ACCESS_TOKEN", "")

    payload: dict = {"publish_type": "default", "language": "zh", "version": "trade.1.1"}
    if product_id is not None:
        payload["product_id"] = str(product_id)
    if cat_id is not None:
        payload["cat_id"] = str(cat_id)

    param_json = json.dumps(payload, separators=(",", ":"))
    timestamp = str(int(round(time.time() * 1000)))

    params = {
        "param_product_top_publish_request": param_json,
        "method": "alibaba.icbu.product.schema.render",
        "app_key": app_key,
        "sign_method": "sha256",
        "session": token,
        "timestamp": timestamp,
        "format": "json",
        "v": "2.0",
        "simplify": "true",
    }

    params = {k: v for k, v in params.items() if v is not None}
    params["sign"] = _sha256_sign(params, app_secret)

    try:
        response = requests.post(SYNC_URL, data=params, timeout=30)
        try:
            body = response.json()
        except Exception:
            body = response.text
        return {"type": "manual_sync", "body": body}
    except requests.exceptions.RequestException as e:
        return {"type": "manual_sync", "body": {"error_response": {"msg": f"Request failed: {str(e)}"}}}


def get_product_schema(cat_id: str) -> dict:
    env_data = load_env()
    app_key = env_data.get("ALIBABA_API_KEY", "")
    app_secret = env_data.get("ALIBABA_API_SECRET", "")
    access_token = env_data.get("ALIBABA_ACCESS_TOKEN", "")

    param_json = json.dumps({"cat_id": str(cat_id), "language": "en_US", "version": "trade.1.1"}, separators=(",", ":"))
    timestamp = str(int(round(time.time() * 1000)))

    params = {
        "param_product_top_publish_request": param_json,
        "method": "alibaba.icbu.product.schema.get",
        "app_key": app_key,
        "sign_method": "sha256",
        "session": access_token,
        "timestamp": timestamp,
        "format": "json",
        "v": "2.0",
        "simplify": "true",
    }

    params = {k: v for k, v in params.items() if v is not None}
    params["sign"] = _sha256_sign(params, app_secret)

    try:
        response = requests.get(SYNC_URL, params=params, timeout=30)
        try:
            body = response.json()
        except Exception:
            body = response.text
        return {"type": "manual_sync", "body": body}
    except Exception as e:
        return {"type": "manual_sync", "body": {"error_response": {"msg": f"Unexpected error: {str(e)}"}}}


def get_product_publish_schema(
    cat_id: str,
    publish_type: str = "default",
    product_id: str | None = None,
    language: str = "en_US",
    version: str = "trade.1.1",
    access_token: str | None = None,
) -> dict:
    payload: dict = {"publish_type": publish_type, "cat_id": str(cat_id), "language": language, "version": version}
    if product_id is not None:
        payload["productId"] = str(product_id)

    env_data = load_env()
    token = access_token or env_data.get("ALIBABA_ACCESS_TOKEN", "")
    client = iop.IopClient(GATEWAY, env_data.get("ALIBABA_API_KEY", ""), env_data.get("ALIBABA_API_SECRET", ""))
    request = iop.IopRequest("alibaba.icbu.product.schema.get")
    request.add_api_param("param_product_top_publish_request", json.dumps(payload, ensure_ascii=False, separators=(",", ":")))

    response = client.execute(request, token)
    return {"type": response.type, "body": response.body}


def add_product_schema_draft(
    xml: str,
    cat_id: str | None = None,
    publish_type: str = "default",
    language: str = "en_US",
    version: str = "trade.1.1",
    access_token: str | None = None,
) -> dict:
    env_data = load_env()
    app_key = env_data.get("ALIBABA_API_KEY", "")
    app_secret = env_data.get("ALIBABA_API_SECRET", "")
    token = access_token or env_data.get("ALIBABA_ACCESS_TOKEN", "")

    payload: dict = {"publish_type": publish_type, "language": language, "version": version, "xml": xml}
    if cat_id is not None:
        payload["cat_id"] = str(cat_id)

    param_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    timestamp = str(int(round(time.time() * 1000)))

    params = {
        "param_product_top_publish_request": param_json,
        "method": "alibaba.icbu.product.schema.add.draft",
        "app_key": app_key,
        "sign_method": "sha256",
        "session": token,
        "timestamp": timestamp,
        "format": "json",
        "v": "2.0",
        "simplify": "true",
    }

    params = {k: v for k, v in params.items() if v is not None}
    params["sign"] = _sha256_sign(params, app_secret)

    try:
        response = requests.post(SYNC_URL, data=params, timeout=30)
        try:
            body = response.json()
        except Exception:
            body = response.text
        return {"type": "manual_sync", "body": body}
    except requests.exceptions.RequestException as e:
        return {"type": "manual_sync", "body": {"error_response": {"msg": f"Request failed: {str(e)}"}}}

