from typing import Any

import requests

from alibaba_production_business.config import load_env
from alibaba_production_business.tools.generate_jwt_token import generate_jwt_token


def call_selling_point(
    product_name: str,
    product_category: str,
    target_language: str,
    product_keyword: list[str] | None = None,
    item_spec: str | dict[str, Any] | None = None,
    product_description: str | None = None,
) -> str | None:
    full_url = "https://api.alphashop.cn/ai.text.generateMultiLanguageSellingPoint/1.0"

    try:
        env_data = load_env()
        access_key = env_data.get("ALPHASHOP_ACCESS_KEY")
        secret_key = env_data.get("ALPHASHOP_SECRET_KEY")
        if not access_key or not secret_key:
            raise ValueError("Missing ALPHASHOP_ACCESS_KEY or ALPHASHOP_SECRET_KEY in env.json")

        token = generate_jwt_token(access_key, secret_key)
        if not token:
            raise ValueError("Failed to generate JWT token")

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

        payload: dict[str, Any] = {
            "productName": product_name,
            "productCategory": product_category,
            "targetLanguage": target_language,
        }

        if product_keyword is not None:
            payload["productKeyword"] = product_keyword

        if item_spec is not None:
            if isinstance(item_spec, dict):
                payload["itemSpec"] = ", ".join(f"{k}: {v}" for k, v in item_spec.items())
            else:
                payload["itemSpec"] = item_spec

        if product_description is not None:
            payload["productDescription"] = product_description

        response = requests.post(full_url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()

        if data.get("resultCode") == "SUCCESS":
            result_data = data.get("result")
            if isinstance(result_data, dict) and result_data.get("success"):
                result_list = result_data.get("result")
                if isinstance(result_list, list) and result_list:
                    return result_list[0]
        return None
    except requests.RequestException as e:
        print(f"Error calling selling point API: {e}")
        return None
    except Exception as e:
        print(f"Error preparing selling point request: {e}")
        return None
