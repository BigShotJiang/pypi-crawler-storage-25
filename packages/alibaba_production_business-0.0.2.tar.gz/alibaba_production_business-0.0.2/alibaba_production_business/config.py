import json
import os
from pathlib import Path


def get_env_path() -> Path:
    env_override = os.environ.get("ALIBABA_PRODUCTION_ENV_JSON")
    if env_override:
        return Path(env_override).expanduser()

    cwd_env = Path.cwd() / "env.json"
    if cwd_env.exists():
        return cwd_env

    repo_env = Path(__file__).resolve().parents[1] / "env.json"
    return repo_env


def load_env() -> dict:
    env_path = get_env_path()
    if env_path.exists():
        with env_path.open("r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_env(data: dict) -> None:
    env_path = get_env_path()
    env_path.parent.mkdir(parents=True, exist_ok=True)
    with env_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

