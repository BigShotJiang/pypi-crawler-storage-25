"""
dvara/config.py

Central config — API endpoint, paths, version.
"""

import os

VERSION = "0.1.0"

# API base URL — override with dvara_API_URL environment variable
API_BASE_URL = os.getenv("dvara_API_URL", "http://localhost:8000")

# Local filter cache path — override with dvara_FILTER_PATH
DEFAULT_FILTER_PATH = os.getenv(
    "dvara_FILTER_PATH",
    os.path.join(os.path.expanduser("~"), ".dvara", "filter.bin"),
)
