from .memory import remember
from .errors import solve_error
from .model import generate_response

CACHE = {}

def compress_prompt(text: str) -> str:
    lines = text.split('\n')
    compressed = []
    for line in lines:
        if 'plt.' in line or 'test_' in line or 'assert ' in line:
            continue
        compressed.append(line)
    result = '\n'.join(compressed)
    # limit to roughly 400 tokens (approx 1600 chars)
    return result[:1600]

def ask(question: str, traceback: str = None, max_tokens: int = 80):
    """
    Main Ask Workflow:
    Pure GenAI coding assistant without retrieval.
    Handles tracebacks if provided.
    """
    if question in CACHE:
        return CACHE[question]

    print(f"Analyzing: {question[:80]}...")

    error_context = ""
    is_debug = False
    
    if traceback:
        is_debug = True
        error_info = solve_error(traceback)
        if error_info:
            error_context = f"\n\nContext from traceback:\n{error_info}"

    compressed_q = compress_prompt(question)
    final_q = error_context + "\nQuestion:\n" + compressed_q

    # Detect task type
    q_lower = question.lower()
    
    if is_debug or any(k.lower() in q_lower for k in ['traceback', 'error', 'modulenotfounderror', 'typeerror', 'importerror', 'exception']):
        system_prompt = "You are a debugging assistant. Find root cause and provide corrected code."
    elif any(k.lower() in q_lower for k in ['pass', 'todo', 'complete code', 'fill missing code', 'missing function', 'return full code']):
        system_prompt = "You are a Python coding assistant. Complete missing code and return only final code."
    else:
        system_prompt = "You are a concise GenAI and Python coding assistant."

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": final_q}
    ]

    import time
    start_time = time.time()
    try:
        answer = generate_response(messages, max_tokens=max_tokens)
        elapsed = time.time() - start_time
        print(f"\n[Time taken: {elapsed:.2f}s]")
    except Exception as e:
        answer = f"Error during generation: {e}"
        print(answer)
        return

    # Memory
    remember(question, answer)
    CACHE[question] = answer

    print("\n" + answer)
    return answer

