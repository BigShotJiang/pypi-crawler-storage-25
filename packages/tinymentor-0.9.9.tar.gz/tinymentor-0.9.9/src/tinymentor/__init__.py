from .ask import ask
from .learning import approve
from .diagnostics import system_report
import threading
from .model import preload_model

# Single background preload — the ONLY thread that touches model loading
threading.Thread(target=preload_model, daemon=True).start()

__all__ = ["ask", "approve", "system_report"]
