import os
import threading
from llama_cpp import Llama
from .progress import ProgressTracker, make_assembly_bar

# ── Globals ──────────────────────────────────────────────────────
MODEL = None
_model_lock = threading.Lock()
_ASSEMBLY_BUFFER = 8 * 1024 * 1024  # 8MB streaming buffer


def get_model_path(tracker=None):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(base_dir, "models", "qwen.gguf")

    if os.path.exists(model_path):
        return model_path

    if tracker:
        tracker.update(10)

    os.makedirs(os.path.dirname(model_path), exist_ok=True)

    try:
        import pandas_sns_2_part1
        parts = [pandas_sns_2_part1.get_part_path()]

        i = 2
        while True:
            try:
                mod = __import__(f"pandas_sns_2_part{i}")
                parts.append(mod.get_part_path())
                i += 1
            except ImportError:
                break

        if tracker:
            tracker.update(25)

        # FIX 3: Stream with fixed buffer instead of reading entire part into RAM
        total_size = sum(os.path.getsize(p) for p in parts)
        assembly_bar = make_assembly_bar(total_size)

        with open(model_path, "wb") as outfile:
            for part in parts:
                with open(part, "rb") as infile:
                    while True:
                        buf = infile.read(_ASSEMBLY_BUFFER)
                        if not buf:
                            break
                        outfile.write(buf)
                        if assembly_bar:
                            assembly_bar.update(len(buf))

        if assembly_bar:
            assembly_bar.close()

    except Exception as e:
        print(f"Error assembling model: {e}")

    return model_path


def preload_model():
    """Background thread function to preload the model into RAM."""
    get_model(_show_progress=False)


import sys

def get_model(_show_progress=True):
    global MODEL
    if MODEL is not None:
        return MODEL

    with _model_lock:
        if MODEL is not None:
            return MODEL

        tracker = ProgressTracker() if _show_progress else None

        model_path = get_model_path(tracker)
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model not found at {model_path}")

        if tracker:
            tracker.update(40)

        # FIX 7: Auto-detect CPU count instead of hardcoded 8
        cpu_count = os.cpu_count() or 4
        n_threads = max(2, min(cpu_count - 2, 8))

        # Completely disable llama_cpp's broken stdout suppression in Jupyter
        import llama_cpp._utils
        import llama_cpp.llama
        class DummySuppress:
            def __init__(self, disable=False):
                pass
            def __enter__(self):
                pass
            def __exit__(self, exc_type, exc_val, exc_tb):
                pass
        llama_cpp._utils.suppress_stdout_stderr = DummySuppress
        if hasattr(llama_cpp.llama, 'suppress_stdout_stderr'):
            llama_cpp.llama.suppress_stdout_stderr = DummySuppress

        MODEL = Llama(
            model_path=model_path,
            n_ctx=2048,
            n_threads=n_threads,
            n_batch=128,
            verbose=False,
            use_mmap=True,
            use_mlock=False
        )

        if tracker:
            tracker.update(55)

        # Warm up
        MODEL.create_chat_completion([{"role": "user", "content": "hi"}], max_tokens=5)

        if tracker:
            tracker.close()

        return MODEL


def generate_response(messages: list, max_tokens: int = 50, temperature: float = 0.2):
    model = get_model()

    output = model.create_chat_completion(
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature
    )

    return output['choices'][0]['message']['content'].strip()


# FIX 1: NO background thread here — only __init__.py spawns one
