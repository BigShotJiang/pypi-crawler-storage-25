"""
Diagnostic report for tinymentor.
Call system_report() to print RAM, CPU, model status, cache size, and thread info.
"""
import os
import sys
import threading
import importlib


def system_report():
    """Print a diagnostic snapshot of tinymentor's runtime state."""
    # Import the MODULE directly, not the function re-exported by __init__
    _model_mod = importlib.import_module("tinymentor.model")
    _ask_mod = importlib.import_module("tinymentor.ask")

    print("=" * 50)
    print("  tinymentor system_report()")
    print("=" * 50)

    # ── RAM ──
    try:
        import resource
        usage_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # macOS reports bytes, Linux reports KB
        if sys.platform == "darwin":
            ram_mb = usage_kb / (1024 * 1024)
        else:
            ram_mb = usage_kb / 1024
        print(f"  RAM usage (peak):    {ram_mb:.1f} MB")
    except Exception:
        print("  RAM usage:           unavailable")

    # ── CPU ──
    cpu_count = os.cpu_count() or "unknown"
    print(f"  CPU cores:           {cpu_count}")

    # ── Model status ──
    if _model_mod.MODEL is not None:
        print(f"  Model loaded:        YES")
        model_path = _model_mod.get_model_path()
        if os.path.exists(model_path):
            size_mb = os.path.getsize(model_path) / (1024 * 1024)
            print(f"  Model file size:     {size_mb:.1f} MB")
        n_ctx = getattr(_model_mod.MODEL, 'n_ctx', 'unknown')
        print(f"  Context window:      {n_ctx}")
    else:
        print(f"  Model loaded:        NO")

    # ── Cache ──
    cache_size = len(_ask_mod.CACHE)
    print(f"  Response cache:      {cache_size} entries")

    # ── Memory file ──
    from .memory import MEMORY_FILE
    if os.path.exists(MEMORY_FILE):
        mem_size = os.path.getsize(MEMORY_FILE)
        print(f"  Memory file:         {mem_size} bytes")
    else:
        print(f"  Memory file:         not created yet")

    # ── Threads ──
    active = threading.active_count()
    thread_names = [t.name for t in threading.enumerate()]
    print(f"  Active threads:      {active}")
    print(f"  Thread names:        {thread_names}")

    print("=" * 50)
