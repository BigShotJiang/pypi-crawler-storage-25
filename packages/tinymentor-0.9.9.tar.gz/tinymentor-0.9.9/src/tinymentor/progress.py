"""
Progress tracking for tinymentor notebook UX.
Shows live status updates so the notebook doesn't appear frozen.
"""
import sys

try:
    from tqdm.auto import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False


class ProgressTracker:
    """
    Displays staged progress bars in notebooks.
    Falls back to plain print() if tqdm is not available.
    """

    STAGES = {
        10: "Loading model parts...",
        25: "Assembling model...",
        40: "Initializing model...",
        55: "Warming model...",
        70: "Understanding question...",
        85: "Generating response...",
        100: "Done",
    }

    def __init__(self):
        self._bar = None
        if HAS_TQDM:
            self._bar = tqdm(
                total=100,
                desc="tinymentor",
                bar_format="[{n:3.0f}%] {desc} {bar}",
                ncols=50,
            )

    def update(self, pct: int):
        """Advance to a specific percentage and display the matching stage label."""
        label = self.STAGES.get(pct, "")
        if self._bar is not None:
            self._bar.n = pct
            self._bar.set_description(label)
            self._bar.refresh()
        else:
            block = int(pct / 5)
            bar = "█" * block + "-" * (20 - block)
            print(f"[{pct:3d}%] {label}\n{bar}", flush=True)

    def close(self):
        if self._bar is not None:
            self._bar.close()


def make_assembly_bar(total_bytes: int):
    """Return a tqdm bar for byte-level model assembly progress."""
    if HAS_TQDM:
        return tqdm(
            total=total_bytes,
            desc="Assembling model",
            unit="B",
            unit_scale=True,
            ncols=60,
        )
    return None

