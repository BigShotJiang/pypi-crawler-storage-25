<p align="center">
  <img src="https://onyxchat-ai.vercel.app/logo/Group%2071.png" alt="ONYX AI Logo" width="200">
</p>

# 💎 ONYX AI Gemma 4 Engine (E2B Edition)

A high-performance, professional FastAPI wrapper for **Gemma Multimodal models** with built-in 4-bit quantization and streaming support. Developed by **ONYX** (RUI Company).

## 🚀 Features
* **Zero Config Integration:** Deploy a multimodal AI server in seconds.
* **Optimized Performance:** Native 4-bit quantization using `bitsandbytes` for low VRAM/RAM usage.
* **Real-time Streaming:** Built-in SSE (Server-Sent Events) for smooth, token-by-token generation.
* **Hardware Friendly:** Optimized for both GPU and high-performance CPU inference.

## 📦 Installation

### Option 1: Via pip
You can install the engine directly from PyPI:
```bash
pip install onyx-AI-Gemma4
Option 2: Via requirements.txt
For production environments or Hugging Face Spaces, use the following dependencies:

Plaintext
fastapi
uvicorn
transformers>=4.48.0
torch
accelerate
bitsandbytes
Pillow
torchvision
onyx-AI-Gemma4
💻 Python Usage Guide
To use the library, import the engine using the specific module name ONYXAI_Gemma4E2B. The engine handles model loading, quantization, and server routing automatically.

Standard Script Usage
Python
from ONYXAI_Gemma4E2B import OnyxEngine

# 1. Initialize the Engine 
engine = OnyxEngine(model_id="google/gemma-4-E2B-it")

# 2. Run the server
if __name__ == "__main__":
    engine.run(host="0.0.0.0", port=7860)
Production/Space Usage (main.py)
Ideal for Hugging Face Spaces or deployments using an external runner:

Python
from ONYXAI_Gemma4E2B import OnyxEngine
import uvicorn
import os

# Initialize the Engine
engine = OnyxEngine(model_id="google/gemma-4-E2B-it")

# Access the underlying FastAPI app instance
app = engine.app

@app.get("/")
def home():
    return {"message": "ONYX Engine is running on Hugging Face Spaces!"}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 7860))
    uvicorn.run(app, host="0.0.0.0", port=port)
🛠 API Interaction
The endpoint /predict is built into the library and supports full streaming.

Endpoint: POST /predict

Example Request (JSON):

JSON
{
  "messages": [
    {
      "role": "user", 
      "content": "Explain the importance of AI in modern software engineering."
    }
  ],
  "temperature": 0.7,
  "max_tokens": 1024
}
🔗 Project Links
Organization: ONYX / RUI Company

Portfolio: Eng. Rawan Jassim

LinkedIn: Professional Profile [cite: 2025-08-11]

© 2026 ONYX. All rights reserved.