# استدعاء الكلاس من ملف engine.py للمستوى الأعلى بالمكتبة
from .engine import OnyxEngine

# تعريف العناصر المتاحة للاستخدام الخارجي (اختياري بس احترافي)
__all__ = ["OnyxEngine"]