from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse
import uvicorn
import asyncio
import torch
from transformers import AutoModelForMultimodalLM, AutoProcessor, TextIteratorStreamer, BitsAndBytesConfig
from threading import Thread

class OnyxEngine:
    def __init__(self, model_id="google/gemma-4-E2B-it"):
        self.app = FastAPI(title="ONYX Engine")
        self.model_id = model_id
        
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4"
        )

        self.processor = AutoProcessor.from_pretrained(self.model_id)
        self.model = AutoModelForMultimodalLM.from_pretrained(
            self.model_id,
            quantization_config=bnb_config,
            device_map="auto", # تم التعديل لـ auto لاستغلال الـ GPU إن وجد
            low_cpu_mem_usage=True,
            trust_remote_code=True
        ).eval()

        self.setup_routes()

    def setup_routes(self):
        @self.app.post("/predict")
        async def generate(request: Request):
            data = await request.json()
            messages = data.get("messages", [])
            temp = data.get("temperature", 0.7)
            max_tokens = data.get("max_tokens", 1024)

            async def generate_chunks():
                try:
                    input_text = self.processor.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
                    streamer = TextIteratorStreamer(self.processor.tokenizer, skip_prompt=True, skip_special_tokens=True)
                    inputs = self.processor(text=input_text, return_tensors="pt").to(self.model.device)

                    generation_kwargs = dict(**inputs, streamer=streamer, max_new_tokens=max_tokens, do_sample=True, temperature=max(temp, 0.1), use_cache=True)
                    Thread(target=self.model.generate, kwargs=generation_kwargs).start()

                    for new_text in streamer:
                        if new_text:
                            yield new_text
                            await asyncio.sleep(0)
                except Exception as e:
                    yield f" [Error: {str(e)}]"

            return StreamingResponse(generate_chunks(), media_type="text/event-stream")

    def run(self, host="0.0.0.0", port=7860):
        uvicorn.run(self.app, host=host, port=port)