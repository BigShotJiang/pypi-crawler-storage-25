.. perfact documentation master file, created by
   sphinx-quickstart on Fri Jan  9 12:50:21 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

perfact documentation
=====================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 4
   :caption: Contents:

   api/modules 
