# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Run all checks (lint, security, tests, types, docs)
tox

# Individual checks
ruff check perfact              # Lint
ruff format --check perfact     # Format check
ruff format perfact             # Auto-format
mypy perfact                    # Type check
bandit --configfile bandit.yaml -r perfact  # Security scan

# Tests (requires a running PostgreSQL instance)
pytest --doctest-modules --cov-branch --cov=perfact --cov-fail-under=100 --cov-report=term-missing

# Run a single test file
pytest perfact/dbutils/tests/test_crud.py

# Run a single test by name
pytest -k "test_create"
```

**100% code coverage is enforced** — adding code without tests will fail the test run.

## Architecture

The library (`perfact/dbutils/`) provides PostgreSQL database utilities usable from both plain Python and Zope environments.

### Module Overview

- **`api.py`** — Core type definitions and context objects. `Context` is the central object passed through the library: it bundles a database connection (`conn`), a `User`, an `LCC` config, and optional hooks. `User` carries role/permission info. Protocol types (`CodedHook`, `MayHook`, `CodedHooksResolver`, `SelfilterGenerator`) define the hook interfaces used by `lcc.py`.

- **`conn.py`** — Database connection wrappers. `Connection` wraps a psycopg2 connection; `ZRDBConnectionWrapper` wraps Zope ZRDB connections. Both implement the `Executor` protocol exposing a unified `execute()` method. Query results are returned as `Results` dataclass instances with `.dicts()` and `.rows()` helpers.

- **`crud.py`** — CRUD operations (`create`, `read`, `update`, `delete`) built on parameterized SQL via psycopg2's `sql` module. `update()` has an optional audit mode that writes `author`/`modtime` fields. All query construction is internal; callers pass table names, column dicts, and filter conditions.

- **`lcc.py`** — Lifecycle/state transition management. `perform_transition()` runs a state change with pre/post hooks resolved via `collect_hooks()`. Side effects are loaded from the database. Transitions are logged to `*lch` tables. `transition_with_hooks()` is the main entry point for callers.

- **`schemainfo.py`** — Schema introspection. `get_columns()` queries `information_schema` to list columns for a given table.

- **`conn.py` (`wrap_zrdbconn_sqasession`)** — Also exposes a SQLAlchemy `Session` wrapper. SQLAlchemy is an optional dependency; importing the module succeeds without it, but calling `wrap_zrdbconn_sqasession()` raises `ImportError` if SQLAlchemy is not installed.

### Key Dependency Flow

```
Callers → Context (api.py)
            ├── conn.py   (Executor / Connection / ZRDBConnectionWrapper)
            ├── crud.py   (uses conn.execute internally)
            └── lcc.py    (uses crud + conn, resolves hooks from api.py protocols)
```

### Testing

Tests live in `perfact/dbutils/tests/`. Integration tests use `pytest-postgresql` to spin up a real PostgreSQL instance via fixtures in `conftest.py`. There are no mocked database tests — all DB tests run against a real Postgres connection.
