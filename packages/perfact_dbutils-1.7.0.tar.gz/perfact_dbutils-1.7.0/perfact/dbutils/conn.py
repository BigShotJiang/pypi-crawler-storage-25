from __future__ import annotations

from abc import abstractmethod
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional, Protocol, TypeAlias, Union

from psycopg2 import sql

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

Query: TypeAlias = Union[sql.SQL, sql.Composed, str, Callable]


class Namespace:
    """
    Convert a dict to a namespace, allowing access via a.b instead of a['b']
    """

    def __init__(self, data=None, **kw):
        self.__dict__.update(kw)


@dataclass
class Results:
    """
    Object representing the result of a query in a compact way with helper
    functions that yield results in a more usable way.
    """

    names: tuple[str, ...]
    tuples: list[tuple]

    def dicts(self):
        "Generate dicts from result"
        for row in self.tuples:
            yield {key: value for key, value in zip(self.names, row)}

    def rows(self):
        "Generate namespaces from result"
        for row in self.dicts():
            yield Namespace(**row)


class Executor(Protocol):
    @abstractmethod
    def execute(
        self, query: Query, **args: Optional[Mapping[str, Any]]
    ) -> Results:  # pragma: no cover
        raise NotImplementedError


class Connection:
    """
    Wrapper exposing a nice execute method.
    Is initialized with something that has an execute method like a Connection
    from psycopg.
    """

    def __init__(self, conn):
        self.conn = conn

    def execute(self, query: Query, **args: Optional[Mapping[str, Any]]) -> Results:
        """
        Execute given query. Returns a namespace with "names" and "tuples". If
        parameters are to be used, they should be included in the form of
        %(name)s in the query. The result also contains methods dicts() and
        rows() that provide generators for getting the results as dictionaries
        or namespaces.
        """
        with self.conn.cursor() as cur:
            cur.execute(query, args)
            if not cur.description:
                return Results(names=(), tuples=[])
            return Results(
                names=tuple(col.name for col in cur.description),
                tuples=cur.fetchall(),
            )


class ZRDBConnectionWrapper:
    """
    Wrap a ZRDB.Connection into something with a matching execute method
    """

    def __init__(self, conn):
        self.conn = conn._v_database_connection

    def execute(self, query: Query, **args: Optional[Mapping[str, Any]]) -> Results:
        """
        Execute within a Zope transaction
        """
        if callable(query):
            # We assume this is a ZSQLMethod
            query = query(src__=1)

        if isinstance(query, sql.Composed):
            query = query.as_string(self.conn.getcursor())

        res = self.conn.query(query, query_data=args)
        # Now we have a tuple with the first element containing a list of
        # column descriptions and the second containing the list of results
        if not res[0]:
            return Results(names=(), tuples=[])
        return Results(
            names=tuple(col["name"] for col in res[0]),
            tuples=res[1],
        )


def wrap_zrdbconn(dbconn):
    return ZRDBConnectionWrapper(dbconn)


def wrap_zrdbconn_sqasession(dbconn) -> Session:
    try:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import Session as _Session
    except ImportError as err:
        raise ImportError(
            "sqlalchemy is required for wrap_zrdbconn_sqasession"
        ) from err
    # just a valid parsable to make sqlalchemy happy, not used
    conn_url = "postgresql+psycopg2://postgres:postgres@hostname:5432/database"
    engine = create_engine(conn_url, creator=dbconn.getconn)
    return _Session(engine)
