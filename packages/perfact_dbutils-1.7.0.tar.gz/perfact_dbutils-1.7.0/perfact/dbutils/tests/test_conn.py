import sys

import pytest
from psycopg2 import sql
from sqlalchemy import BigInteger, Sequence, String, select
from sqlalchemy.orm import DeclarativeBase, Mapped, MappedAsDataclass, mapped_column

from ..conn import Connection, wrap_zrdbconn, wrap_zrdbconn_sqasession


@pytest.fixture(scope="function")
def conn(postgresql):
    with postgresql.cursor() as cur:
        cur.execute(
            "CREATE TABLE appuser "
            "(appuser_id serial PRIMARY KEY, "
            "appuser_author varchar, "
            "appuser_modtime timestamp default current_timestamp, "
            "appuser_name varchar, "
            "appuser_fullname varchar);"
        )
        cur.execute(
            "create or replace function db_username() "
            "returns text as $$ "
            "begin "
            "   return 'test_user'; "
            "end; "
            "$$ language plpgsql;"
        )
    postgresql.commit()
    yield postgresql


class Base(DeclarativeBase, MappedAsDataclass):
    pass


class User(Base):
    __tablename__ = "appuser"
    id: Mapped[int] = mapped_column(
        "appuser_id",
        BigInteger,
        Sequence("appuser_appuser_id_seq"),
        init=False,
        primary_key=True,
        comment="Benutzer",
    )
    name: Mapped[str] = mapped_column("appuser_name", String)


def test_psycopg(postgresql):
    """
    Test basic usage with a psycopg test connection.
    """
    conn = Connection(postgresql)
    res = conn.execute("""
      select now() as ts
    """)
    assert res.names == ("ts",)
    assert len(res.tuples) == 1
    assert len(list(res.rows())) == 1
    assert len(list(res.dicts())) == 1
    # Query not returning anything
    res = conn.execute("create table test (test_id bigint)")
    assert len(res.tuples) == 0


class MockZRDBConnection:
    def __init__(self, conn):
        self._v_database_connection = self
        self.conn = conn

    def query(self, query, query_data=None):
        with self.conn.cursor() as cur:
            cur.execute(query, query_data)
            if not cur.description:
                return (), []
            return (
                [{"name": col.name} for col in cur.description],
                cur.fetchall(),
            )

    def getcursor(self):
        return self.conn

    def getconn(self):
        return self.conn


def generate_query(src__):
    assert src__
    return "select 5*6 as bla"


def test_wrapper(postgresql):
    """
    Test the wrapper for ZRDBConnection objects - although we mock them here.
    """
    mock = MockZRDBConnection(postgresql)
    conn = wrap_zrdbconn(mock)
    # Regular query
    res = conn.execute("select now() as ts")
    assert res.names == ("ts",)
    # Test wrapper with composed sql
    query = sql.SQL("select now() as ts").format()
    res = conn.execute(query)
    assert res.names == ("ts",)
    # Query generator, mocking ZSQLMethod
    res = conn.execute(generate_query)
    assert res.names == ("bla",)
    # Query not returning anything
    res = conn.execute("create table test (test_id bigint)")
    assert len(res.tuples) == 0


def test_sqlawrapper(conn):
    mock = MockZRDBConnection(conn)
    session = wrap_zrdbconn_sqasession(mock)
    user1 = User(name="Carlos")
    session.add(user1)
    user2 = session.execute(select(User).where(User.name == "Carlos")).first()[0]
    user3 = User(name="test")
    session.add(user3)
    assert user2.name == "Carlos"


def test_sqlawrapper_no_sqla(monkeypatch):
    monkeypatch.setitem(sys.modules, "sqlalchemy", None)
    with pytest.raises(ImportError):
        wrap_zrdbconn_sqasession(None)
