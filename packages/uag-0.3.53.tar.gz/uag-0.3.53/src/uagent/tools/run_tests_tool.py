"""run_tests_tool

Wrapper tool for running tests.

Purpose:
- Standardize test execution and return structured results.
- Auto-detect pytest / unittest / npm when framework=auto.

Safety:
- Tests are generally non-hazardous.
- Extra arguments are rejected if they contain shell metacharacters.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple

from .safe_file_ops_extras import ensure_within_workdir, is_path_dangerous
from .i18n_helper import make_tool_translator

BUSY_LABEL = True
STATUS_LABEL = "tool:run_tests"


_ = make_tool_translator(__file__)


TOOL_SPEC: Dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "run_tests",
        "description": _(
            "tool.description",
            default="Run tests (auto-detect pytest/unittest/npm). Reject shell metacharacters in extra_args.",
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "framework": {
                    "type": "string",
                    "enum": ["auto", "pytest", "unittest", "npm"],
                    "default": "auto",
                    "description": _(
                        "param.framework.description", default="Test framework type."
                    ),
                },
                "target": {
                    "type": ["string", "null"],
                    "default": None,
                    "description": _(
                        "param.target.description",
                        default="Target (pytest path, unittest start directory, npm script, etc.). If null, defaults are used.",
                    ),
                },
                "extra_args": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": [],
                    "description": _(
                        "param.extra_args.description",
                        default="Additional arguments (array). Rejected if shell metacharacters are present.",
                    ),
                },
                "cwd": {
                    "type": ["string", "null"],
                    "default": None,
                    "description": _(
                        "param.cwd.description",
                        default="Working directory to run in (must be within workdir). If null, current directory.",
                    ),
                },
                "pythonpath": {
                    "type": ["string", "null"],
                    "default": None,
                    "description": _(
                        "param.pythonpath.description",
                        default="Additional PYTHONPATH (e.g. 'src'). If provided, it is prefixed for the test command.",
                    ),
                },
                "report": {
                    "type": "string",
                    "enum": ["text", "json"],
                    "default": "json",
                    "description": _(
                        "param.report.description", default="Output format."
                    ),
                },
            },
        },
    },
}


_META_RE = re.compile(r"(&&|\|\||\||>>|>|<)")


def _reject_if_meta(s: str) -> Optional[str]:
    if _META_RE.search(s or ""):
        return _(
            "error.shell_metacharacters_not_allowed",
            default="shell metacharacters are not allowed in arguments: {arg}",
        ).format(arg=repr(s))
    return None


def _exists_any(names: List[str]) -> bool:
    return any(os.path.exists(n) for n in names)


def _detect_framework() -> str:
    if _exists_any(["pytest.ini", "conftest.py"]):
        return "pytest"
    if os.path.exists("package.json"):
        return "npm"
    if os.path.isdir("tests"):
        return "unittest"
    return "auto"


def _truncate(label: str, text: str) -> str:
    from .context import get_callbacks

    cb = get_callbacks()
    trunc = getattr(cb, "truncate_output", None) if cb is not None else None
    if callable(trunc):
        try:
            return trunc(label, text, 400_000)
        except Exception:
            return text
    return text


def _cmd_exec_json(
    command: str, cwd: Optional[str]
) -> Tuple[str, str, int, Optional[str]]:
    try:
        from .cmd_exec_json_tool import run_tool as cmd_exec_json

        out = cmd_exec_json({"command": command, "cwd": cwd})
        obj = json.loads(out)
        if obj.get("blocked"):
            return "", "", 1, str(obj.get("reason") or "blocked")
        if obj.get("timeout"):
            return "", "", 124, str(obj.get("message") or "timeout")
        stdout = str(obj.get("stdout") or "")
        stderr = str(obj.get("stderr") or "")
        code = int(obj.get("returncode") or 0)
        return stdout, stderr, code, None
    except Exception as e:
        return (
            "",
            f"cmd_exec_json unavailable: {type(e).__name__}: {e}",
            1,
            "unavailable",
        )


def _apply_pythonpath_prefix(cmd_str: str, pythonpath: Optional[str]) -> str:
    if not pythonpath:
        return cmd_str

    pp = str(pythonpath)
    err = _reject_if_meta(pp)
    if err:
        raise ValueError(err)

    if os.name == "nt":
        return f"set PYTHONPATH={pp};%PYTHONPATH% && {cmd_str}"

    return f"PYTHONPATH={pp}:$PYTHONPATH {cmd_str}"


def run_tool(args: Dict[str, Any]) -> str:
    framework = str(args.get("framework") or "auto")
    target = args.get("target", None)
    extra_args = args.get("extra_args", []) or []
    cwd = args.get("cwd", None)
    pythonpath = args.get("pythonpath", None)
    report = str(args.get("report") or "json")

    if framework not in ("auto", "pytest", "unittest", "npm"):
        return json.dumps(
            {
                "ok": False,
                "error": _(
                    "error.invalid_framework", default="invalid framework: {framework}"
                ).format(framework=framework),
            },
            ensure_ascii=False,
        )

    if report not in ("text", "json"):
        return json.dumps(
            {
                "ok": False,
                "error": _(
                    "error.invalid_report", default="invalid report: {report}"
                ).format(report=report),
            },
            ensure_ascii=False,
        )

    sanitized_args: List[str] = []
    for a in extra_args:
        a = str(a)
        err = _reject_if_meta(a)
        if err:
            return json.dumps({"ok": False, "error": err}, ensure_ascii=False)
        sanitized_args.append(a)

    run_cwd: Optional[str] = None
    if cwd is not None:
        if is_path_dangerous(str(cwd)):
            return json.dumps(
                {
                    "ok": False,
                    "error": _(
                        "error.dangerous_cwd_rejected",
                        default="dangerous cwd rejected: {cwd}",
                    ).format(cwd=cwd),
                },
                ensure_ascii=False,
            )
        try:
            run_cwd = ensure_within_workdir(str(cwd))
        except Exception as e:
            return json.dumps(
                {
                    "ok": False,
                    "error": _(
                        "error.cwd_not_allowed", default="cwd not allowed: {error}"
                    ).format(error=e),
                },
                ensure_ascii=False,
            )

    detected = None
    if framework == "auto":
        detected = _detect_framework()
        if detected == "auto":
            return json.dumps(
                {
                    "ok": False,
                    "error": _(
                        "error.framework_auto_detect_failed",
                        default="framework auto-detect failed",
                    ),
                },
                ensure_ascii=False,
            )
        framework = detected

    cmd_parts: List[str] = []
    if framework == "pytest":
        cmd_parts = ["python", "-m", "pytest", "-q"]
        if target:
            cmd_parts.append(str(target))
        cmd_parts.extend(sanitized_args)
    elif framework == "unittest":
        cmd_parts = ["python", "-m", "unittest", "discover"]
        if target:
            cmd_parts.extend(["-s", str(target)])
        else:
            cmd_parts.extend(["-s", "tests"])
        cmd_parts.extend(sanitized_args)
    elif framework == "npm":
        cmd_parts = ["npm", "test"]
        if target:
            cmd_parts.append(str(target))
        cmd_parts.extend(sanitized_args)
    else:
        return json.dumps(
            {
                "ok": False,
                "error": _(
                    "error.unsupported_framework",
                    default="unsupported framework: {framework}",
                ).format(framework=framework),
            },
            ensure_ascii=False,
        )

    def q(x: str) -> str:
        x = str(x)
        if not x:
            return '""'
        if " " in x or "\t" in x or '"' in x:
            x = x.replace('"', '\\"')
            return f'"{x}"'
        return x

    cmd_str = " ".join(q(p) for p in cmd_parts)

    try:
        cmd_str = _apply_pythonpath_prefix(cmd_str, pythonpath)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False)

    stdout, stderr, code, err_tag = _cmd_exec_json(cmd_str, cwd=run_cwd)

    stdout_t = _truncate("run_tests stdout", stdout)
    stderr_t = _truncate("run_tests stderr", stderr)

    result: Dict[str, Any] = {
        "ok": code == 0,
        "framework": framework,
        "detected": detected,
        "command": cmd_str,
        "cwd": run_cwd,
        "returncode": code,
        "stdout": stdout_t,
        "stderr": stderr_t,
    }
    if err_tag:
        result["error_tag"] = err_tag

    if report == "text":
        return (
            f"framework={framework}\n"
            f"cwd={run_cwd}\n"
            f"command={cmd_str}\n"
            f"returncode={code}\n\n"
            f"[stdout]\n{stdout_t}\n\n"
            f"[stderr]\n{stderr_t}\n"
        )

    return json.dumps(result, ensure_ascii=False)
