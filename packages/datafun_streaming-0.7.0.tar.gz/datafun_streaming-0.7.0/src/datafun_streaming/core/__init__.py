"""Shared primitives."""
