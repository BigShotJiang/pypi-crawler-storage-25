"""Per-resource SDK clients."""

from mailwire_sdk.resources.api_keys import ApiKeysResource
from mailwire_sdk.resources.domains import DomainsResource
from mailwire_sdk.resources.inboxes import InboxesResource
from mailwire_sdk.resources.messages import MessagesResource
from mailwire_sdk.resources.tenants import TenantsResource
from mailwire_sdk.resources.threads import ThreadsResource
from mailwire_sdk.resources.webhooks import WebhooksResource

__all__ = [
    "ApiKeysResource",
    "DomainsResource",
    "InboxesResource",
    "MessagesResource",
    "TenantsResource",
    "ThreadsResource",
    "WebhooksResource",
]
