"""Inbox + address management."""

from __future__ import annotations

from typing import Any

from mailwire_sdk._transport import Transport


class InboxesResource:
    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def create(
        self,
        *,
        client_id: str,
        display_name: str,
        domain_id: str,
        shareable_local_part: str | None = None,
        private_address_count: int = 0,
        workspace_id: str | None = None,
        project_id: str | None = None,
        signature_text: str | None = None,
        signature_html: str | None = None,
        timezone: str = "UTC",
        language: str = "en",
        avatar_url: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "client_id": client_id,
            "display_name": display_name,
            "domain_id": domain_id,
            "private_address_count": private_address_count,
            "timezone": timezone,
            "language": language,
            "metadata": metadata or {},
        }
        if shareable_local_part is not None:
            body["shareable_address"] = {"local_part": shareable_local_part}
        for k, v in (
            ("workspace_id", workspace_id),
            ("project_id", project_id),
            ("signature_text", signature_text),
            ("signature_html", signature_html),
            ("avatar_url", avatar_url),
        ):
            if v is not None:
                body[k] = v
        return self._t.request("POST", "/v1/inboxes", json=body)

    def list(
        self,
        *,
        workspace_id: str | None = None,
        project_id: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if workspace_id is not None:
            params["workspace_id"] = workspace_id
        if project_id is not None:
            params["project_id"] = project_id
        return self._t.request("GET", "/v1/inboxes", params=params)["data"]  # type: ignore[no-any-return]

    def get(self, inbox_id: str) -> dict[str, Any]:
        return self._t.request("GET", f"/v1/inboxes/{inbox_id}")

    def update(
        self,
        inbox_id: str,
        **fields: Any,
    ) -> dict[str, Any]:
        return self._t.request("PATCH", f"/v1/inboxes/{inbox_id}", json=fields)

    def archive(self, inbox_id: str) -> None:
        self._t.request("DELETE", f"/v1/inboxes/{inbox_id}")

    def add_address(self, inbox_id: str) -> dict[str, Any]:
        return self._t.request("POST", f"/v1/inboxes/{inbox_id}/addresses")
