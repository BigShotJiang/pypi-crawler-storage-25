"""Tenant CRUD — admin-scoped."""

from __future__ import annotations

from typing import Any

from mailwire_sdk._transport import Transport


class TenantsResource:
    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def create(
        self,
        *,
        name: str,
        slug: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "metadata": metadata or {}}
        if slug is not None:
            body["slug"] = slug
        return self._t.request("POST", "/v1/tenants", json=body)

    def list(self, *, limit: int = 50) -> list[dict[str, Any]]:
        return self._t.request("GET", "/v1/tenants", params={"limit": limit})["data"]  # type: ignore[no-any-return]

    def get(self, tenant_id: str) -> dict[str, Any]:
        return self._t.request("GET", f"/v1/tenants/{tenant_id}")

    def update(
        self,
        tenant_id: str,
        *,
        name: str | None = None,
        status: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = {
            k: v
            for k, v in (("name", name), ("status", status), ("metadata", metadata))
            if v is not None
        }
        return self._t.request("PATCH", f"/v1/tenants/{tenant_id}", json=body)

    def delete(self, tenant_id: str) -> None:
        self._t.request("DELETE", f"/v1/tenants/{tenant_id}")
