"""Webhook subscriber CRUD — `/v1/webhooks`.

The `secret` field is returned EXACTLY ONCE on `create` and `rotate_secret`.
Listings + reads expose only `secret_prefix`.
"""

from __future__ import annotations

from typing import Any

from mailwire_sdk._transport import Transport


class WebhooksResource:
    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def create(
        self,
        *,
        name: str,
        url: str,
        events_subscribed: list[str],
        environment: str = "live",
        workspace_id: str | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "name": name,
            "url": url,
            "events_subscribed": events_subscribed,
            "environment": environment,
            "metadata": metadata or {},
        }
        if workspace_id is not None:
            body["workspace_id"] = workspace_id
        if description is not None:
            body["description"] = description
        return self._t.request("POST", "/v1/webhooks", json=body)

    def get(self, endpoint_id: str) -> dict[str, Any]:
        return self._t.request("GET", f"/v1/webhooks/{endpoint_id}")

    def update(
        self,
        endpoint_id: str,
        *,
        url: str | None = None,
        events_subscribed: list[str] | None = None,
        enabled: bool | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if events_subscribed is not None:
            body["events_subscribed"] = events_subscribed
        if enabled is not None:
            body["enabled"] = enabled
        if description is not None:
            body["description"] = description
        return self._t.request("PATCH", f"/v1/webhooks/{endpoint_id}", json=body)

    def revoke(self, endpoint_id: str) -> None:
        self._t.request("DELETE", f"/v1/webhooks/{endpoint_id}")

    def rotate_secret(self, endpoint_id: str) -> dict[str, Any]:
        return self._t.request("POST", f"/v1/webhooks/{endpoint_id}/rotate_secret")

    def deliveries(
        self, endpoint_id: str, *, limit: int = 50
    ) -> list[dict[str, Any]]:
        data = self._t.request(
            "GET",
            f"/v1/webhooks/{endpoint_id}/deliveries",
            params={"limit": limit},
        ).get("data", [])
        return list(data)

    # `list` is defined LAST so other methods' `list[...]` annotations bind
    # to the builtin (Python class scope is built top-down).
    def list(self) -> list[dict[str, Any]]:
        data = self._t.request("GET", "/v1/webhooks").get("data", [])
        return list(data)
