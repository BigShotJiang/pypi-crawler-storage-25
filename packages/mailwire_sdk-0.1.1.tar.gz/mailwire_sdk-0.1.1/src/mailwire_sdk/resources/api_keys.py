"""API-key CRUD under `/v1/tenants/{t}/api_keys` — admin-scoped.

The mint response includes a `token` field exactly once. Surface it to the user
immediately; the server keeps only an Argon2id hash.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from mailwire_sdk._transport import Transport


class ApiKeysResource:
    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def create(
        self,
        tenant_id: str,
        *,
        name: str,
        scopes: list[str],
        environment: str = "live",
        workspace_id: str | None = None,
        project_id: str | None = None,
        inbox_id: str | None = None,
        expires_at: datetime | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "name": name,
            "scopes": scopes,
            "environment": environment,
            "metadata": metadata or {},
        }
        if workspace_id is not None:
            body["workspace_id"] = workspace_id
        if project_id is not None:
            body["project_id"] = project_id
        if inbox_id is not None:
            body["inbox_id"] = inbox_id
        if expires_at is not None:
            body["expires_at"] = expires_at.isoformat()
        return self._t.request("POST", f"/v1/tenants/{tenant_id}/api_keys", json=body)

    def list(self, tenant_id: str) -> list[dict[str, Any]]:
        return self._t.request("GET", f"/v1/tenants/{tenant_id}/api_keys")["data"]  # type: ignore[no-any-return]

    def get(self, tenant_id: str, key_id: str) -> dict[str, Any]:
        return self._t.request("GET", f"/v1/tenants/{tenant_id}/api_keys/{key_id}")

    def revoke(self, tenant_id: str, key_id: str) -> None:
        self._t.request("DELETE", f"/v1/tenants/{tenant_id}/api_keys/{key_id}")
