"""Thread list / detail — `/v1/threads`. Gmail-style inbox view."""

from __future__ import annotations

from typing import Any

from mailwire_sdk._transport import Transport


class ThreadsResource:
    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def get(
        self, thread_id: str, *, include_last_message: bool = True
    ) -> dict[str, Any]:
        params = {"include_last_message": "true" if include_last_message else "false"}
        return self._t.request("GET", f"/v1/threads/{thread_id}", params=params)

    # `list` defined LAST so other annotations bind to the builtin
    # (Python class scope is built top-down).
    def list(
        self,
        *,
        inbox_id: str,
        limit: int = 50,
        include_last_message: bool = True,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "inbox_id": inbox_id,
            "limit": limit,
            "include_last_message": "true" if include_last_message else "false",
        }
        data = self._t.request("GET", "/v1/threads", params=params).get("data", [])
        return list(data)
