"""Outbound + read endpoints for messages."""

from __future__ import annotations

from typing import Any

from mailwire_sdk._transport import Transport


class MessagesResource:
    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def send(
        self,
        *,
        inbox_id: str,
        from_address: str,
        to: list[str],
        subject: str = "",
        text: str | None = None,
        html: str | None = None,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        sending_domain_id: str | None = None,
        in_reply_to_message_id: str | None = None,
        headers: dict[str, str] | None = None,
        attachments: list[dict[str, Any]] | None = None,
        tags: list[str] | None = None,
        tracking_opens: bool = False,
        tracking_clicks: bool = False,
        metadata: dict[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "inbox_id": inbox_id,
            "from_address": from_address,
            "to": to,
            "cc": cc or [],
            "bcc": bcc or [],
            "subject": subject,
            "headers": headers or {},
            "attachments": attachments or [],
            "tags": tags or [],
            "tracking": {"opens": tracking_opens, "clicks": tracking_clicks},
            "metadata": metadata or {},
        }
        if sending_domain_id is not None:
            body["sending_domain_id"] = sending_domain_id
        if in_reply_to_message_id is not None:
            body["in_reply_to_message_id"] = in_reply_to_message_id
        if text is not None:
            body["text"] = text
        if html is not None:
            body["html"] = html
        request_headers = (
            {"Idempotency-Key": idempotency_key} if idempotency_key is not None else None
        )
        return self._t.request(
            "POST", "/v1/messages", json=body, headers=request_headers
        )

    def list(
        self,
        *,
        inbox_id: str | None = None,
        thread_id: str | None = None,
        direction: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        for k, v in (("inbox_id", inbox_id), ("thread_id", thread_id), ("direction", direction)):
            if v is not None:
                params[k] = v
        return self._t.request("GET", "/v1/messages", params=params)["data"]  # type: ignore[no-any-return]

    def get(self, message_id: str) -> dict[str, Any]:
        return self._t.request("GET", f"/v1/messages/{message_id}")
