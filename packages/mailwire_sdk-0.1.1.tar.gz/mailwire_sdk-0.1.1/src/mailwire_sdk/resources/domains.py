"""Domain registration + verification."""

from __future__ import annotations

from typing import Any

from mailwire_sdk._transport import Transport


class DomainsResource:
    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def register(
        self,
        tenant_id: str,
        *,
        domain_name: str,
        purpose: str,
        region: str = "us",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = {
            "domain_name": domain_name,
            "purpose": purpose,
            "region": region,
            "metadata": metadata or {},
        }
        return self._t.request("POST", f"/v1/tenants/{tenant_id}/domains", json=body)

    def list_for_tenant(self, tenant_id: str) -> list[dict[str, Any]]:
        return self._t.request("GET", f"/v1/tenants/{tenant_id}/domains")["data"]  # type: ignore[no-any-return]

    def get(self, domain_id: str) -> dict[str, Any]:
        return self._t.request("GET", f"/v1/domains/{domain_id}")

    def get_dns_records(self, domain_id: str) -> dict[str, Any]:
        return self._t.request("GET", f"/v1/domains/{domain_id}/dns_records")

    def verify(self, domain_id: str) -> dict[str, Any]:
        return self._t.request("POST", f"/v1/domains/{domain_id}/verify")

    def delete(self, domain_id: str) -> None:
        self._t.request("DELETE", f"/v1/domains/{domain_id}")
