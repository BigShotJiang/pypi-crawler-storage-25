"""Top-level mailwire SDK client.

The synchronous `Client` is the v0 surface — async support and generated typed
models land in Sprint 5. Usage:

    from mailwire_sdk import Client
    with Client(token="mw_live_...", base_url="https://api.example.com") as mw:
        inbox = mw.inboxes.create(
            client_id="lena.taiwo",
            display_name="Lena",
            domain_id="dom_...",
            shareable_local_part="lena",
            private_address_count=2,
        )
        mw.messages.send(
            inbox_id=inbox["id"],
            from_address="Lena <lena@someonehq.com>",
            to=["recipient@example.com"],
            subject="Catching up",
            text="...",
        )
"""

from __future__ import annotations

from typing import Any

from mailwire_sdk._transport import Transport
from mailwire_sdk.resources import (
    ApiKeysResource,
    DomainsResource,
    InboxesResource,
    MessagesResource,
    TenantsResource,
    ThreadsResource,
    WebhooksResource,
)


class Client:
    """Synchronous mailwire client.

    Use as a context manager (recommended) or call `.close()` when done. Each
    `Client` owns a pooled `httpx.Client` under the hood.
    """

    def __init__(
        self,
        *,
        token: str,
        base_url: str = "http://localhost:8083",
        timeout: float = 30.0,
    ) -> None:
        self._transport = Transport(token=token, base_url=base_url, timeout=timeout)
        self.tenants = TenantsResource(self._transport)
        self.api_keys = ApiKeysResource(self._transport)
        self.domains = DomainsResource(self._transport)
        self.inboxes = InboxesResource(self._transport)
        self.messages = MessagesResource(self._transport)
        self.threads = ThreadsResource(self._transport)
        self.webhooks = WebhooksResource(self._transport)

    def healthz(self) -> dict[str, Any]:
        """Service health probe — no auth required server-side, but the SDK
        still sends the bearer header. Returns `{"status": "ok", "version": ...}`.
        """
        return self._transport.request("GET", "/healthz")

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
