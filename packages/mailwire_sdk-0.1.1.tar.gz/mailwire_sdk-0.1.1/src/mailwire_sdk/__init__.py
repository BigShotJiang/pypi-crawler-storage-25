"""Python SDK for mailwire-x1.

Public surface:
    - `Client` — synchronous client (use as context manager).
    - `MailwireError` and subclasses for catching API errors.
"""

from mailwire_sdk.client import Client
from mailwire_sdk.errors import (
    AuthError,
    ConflictError,
    MailwireError,
    NotFoundError,
    PermissionError,
    ProviderError,
    ServerError,
    ValidationError,
)

__version__ = "0.1.0"

__all__ = [
    "AuthError",
    "Client",
    "ConflictError",
    "MailwireError",
    "NotFoundError",
    "PermissionError",
    "ProviderError",
    "ServerError",
    "ValidationError",
    "__version__",
]
