"""HTTP transport — wraps httpx.Client with auth + error envelope decoding."""

from __future__ import annotations

from typing import Any

import httpx

from mailwire_sdk.errors import MailwireError, from_envelope


class Transport:
    def __init__(
        self,
        *,
        token: str,
        base_url: str,
        timeout: float = 30.0,
        user_agent: str = "mailwire-sdk-python/0.1.0",
    ) -> None:
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {token}",
                "User-Agent": user_agent,
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        try:
            response = self._client.request(
                method, path, params=params, json=json, headers=headers
            )
        except httpx.RequestError as exc:
            raise MailwireError(f"network error: {exc}") from exc

        if response.status_code == 204 or not response.content:
            return {}

        try:
            payload = response.json()
        except ValueError as exc:
            raise MailwireError(
                f"non-JSON response (HTTP {response.status_code}): {response.text[:200]!r}"
            ) from exc

        if response.status_code >= 400:
            raise from_envelope(payload, status_code=response.status_code)

        return payload  # type: ignore[no-any-return]

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Transport:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
