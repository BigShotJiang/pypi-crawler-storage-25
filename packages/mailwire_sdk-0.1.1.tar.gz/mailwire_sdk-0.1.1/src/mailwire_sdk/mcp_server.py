"""mailwire MCP server (stdio transport).

Exposes the inbox + message read/write surface as MCP tools so an AI agent host
(Claude Desktop, IDE extensions, etc.) can drive mailwire on a user's behalf.

Run via the `mailwire-mcp` console script:

    MAILWIRE_BASE_URL=https://api.example.com \\
    MAILWIRE_TOKEN=mw_live_... \\
    mailwire-mcp

Or wire it into an MCP host config:

    {
      "mcpServers": {
        "mailwire": {
          "command": "mailwire-mcp",
          "env": {
            "MAILWIRE_BASE_URL": "https://api.example.com",
            "MAILWIRE_TOKEN": "mw_live_..."
          }
        }
      }
    }

The server is intentionally thin — every tool is a direct passthrough to the
SDK with the response JSON-encoded back to the caller. No business logic lives
here.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import sys
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from mailwire_sdk import Client, MailwireError

_TOOLS: list[dict[str, Any]] = [
    {
        "name": "mailwire_list_inboxes",
        "description": (
            "List inboxes for the authenticated tenant. Optionally filter by "
            "workspace_id or project_id. Returns a JSON array of inbox objects "
            "with their addresses inlined."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {"type": "string"},
                "project_id": {"type": "string"},
                "limit": {"type": "integer", "default": 50, "maximum": 200},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "mailwire_get_inbox",
        "description": "Fetch a single inbox by its public ID (inb_*).",
        "inputSchema": {
            "type": "object",
            "properties": {"inbox_id": {"type": "string"}},
            "required": ["inbox_id"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mailwire_send_message",
        "description": (
            "Send an outbound email. `from_address` may be bare "
            "(`name@domain`) or display-name form (`Name <name@domain>`). "
            "Provide `text` or `html` (or both). Pass `idempotency_key` if "
            "you want safe retries."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "inbox_id": {"type": "string"},
                "from_address": {"type": "string"},
                "to": {"type": "array", "items": {"type": "string"}, "minItems": 1},
                "cc": {"type": "array", "items": {"type": "string"}},
                "bcc": {"type": "array", "items": {"type": "string"}},
                "subject": {"type": "string"},
                "text": {"type": "string"},
                "html": {"type": "string"},
                "sending_domain_id": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "metadata": {"type": "object", "additionalProperties": {"type": "string"}},
                "idempotency_key": {"type": "string"},
            },
            "required": ["inbox_id", "from_address", "to"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mailwire_list_messages",
        "description": (
            "List recent messages for the tenant. Filter by inbox_id, "
            "thread_id, or direction (`outbound` / `inbound`)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "inbox_id": {"type": "string"},
                "thread_id": {"type": "string"},
                "direction": {"type": "string", "enum": ["inbound", "outbound"]},
                "limit": {"type": "integer", "default": 50, "maximum": 200},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "mailwire_get_message",
        "description": "Fetch a single message by its public ID (msg_*).",
        "inputSchema": {
            "type": "object",
            "properties": {"message_id": {"type": "string"}},
            "required": ["message_id"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mailwire_list_webhooks",
        "description": (
            "List active webhook subscribers for the tenant. Each entry "
            "carries the URL, events_subscribed, secret_prefix, and "
            "last delivery status."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    },
    {
        "name": "mailwire_register_webhook",
        "description": (
            "Register a new webhook subscriber. Returns the plaintext signing "
            "secret EXACTLY ONCE — record it on the subscriber side."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "url": {"type": "string"},
                "events_subscribed": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                },
                "environment": {"type": "string", "enum": ["live", "test"]},
                "description": {"type": "string"},
            },
            "required": ["name", "url", "events_subscribed"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mailwire_get_webhook_deliveries",
        "description": (
            "Fetch the most recent delivery attempts for a webhook subscriber "
            "(useful for debugging why an event didn't arrive)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {"endpoint_id": {"type": "string"}},
            "required": ["endpoint_id"],
            "additionalProperties": False,
        },
    },
]


def _dispatch(client: Client, name: str, args: dict[str, Any]) -> Any:  # noqa: PLR0911 — pure dispatch table
    """Call the right SDK method for `name` and return the raw response."""
    if name == "mailwire_list_inboxes":
        return client.inboxes.list(
            workspace_id=args.get("workspace_id"),
            project_id=args.get("project_id"),
            limit=args.get("limit", 50),
        )
    if name == "mailwire_get_inbox":
        return client.inboxes.get(args["inbox_id"])
    if name == "mailwire_send_message":
        return client.messages.send(
            inbox_id=args["inbox_id"],
            from_address=args["from_address"],
            to=args["to"],
            cc=args.get("cc"),
            bcc=args.get("bcc"),
            subject=args.get("subject", ""),
            text=args.get("text"),
            html=args.get("html"),
            sending_domain_id=args.get("sending_domain_id"),
            tags=args.get("tags"),
            metadata=args.get("metadata"),
            idempotency_key=args.get("idempotency_key"),
        )
    if name == "mailwire_list_messages":
        return client.messages.list(
            inbox_id=args.get("inbox_id"),
            thread_id=args.get("thread_id"),
            direction=args.get("direction"),
            limit=args.get("limit", 50),
        )
    if name == "mailwire_get_message":
        return client.messages.get(args["message_id"])
    if name == "mailwire_list_webhooks":
        return client.webhooks.list()
    if name == "mailwire_register_webhook":
        return client.webhooks.create(
            name=args["name"],
            url=args["url"],
            events_subscribed=args["events_subscribed"],
            environment=args.get("environment", "live"),
            description=args.get("description"),
        )
    if name == "mailwire_get_webhook_deliveries":
        return client.webhooks.deliveries(args["endpoint_id"])
    raise ValueError(f"unknown tool: {name}")


async def _run() -> None:
    base_url = os.environ.get("MAILWIRE_BASE_URL", "http://localhost:8083")
    token = os.environ.get("MAILWIRE_TOKEN")
    if not token:
        print(
            "MAILWIRE_TOKEN env var is required to run the mailwire MCP server",
            file=sys.stderr,
        )
        raise SystemExit(2)

    client = Client(token=token, base_url=base_url)
    server: Server = Server("mailwire")

    @server.list_tools()  # type: ignore[no-untyped-call,untyped-decorator]
    async def _list() -> list[Tool]:
        return [Tool(**spec) for spec in _TOOLS]

    @server.call_tool()  # type: ignore[untyped-decorator]
    async def _call(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        try:
            result = await asyncio.to_thread(_dispatch, client, name, arguments or {})
        except MailwireError as exc:
            payload = {
                "ok": False,
                "error": {
                    "type": exc.type,
                    "code": exc.code,
                    "message": str(exc),
                    "details": exc.details,
                    "request_id": exc.request_id,
                },
            }
            return [TextContent(type="text", text=json.dumps(payload, indent=2))]
        return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())

    client.close()


def main() -> None:
    """Console entry point — `mailwire-mcp`."""
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(_run())


if __name__ == "__main__":
    main()
