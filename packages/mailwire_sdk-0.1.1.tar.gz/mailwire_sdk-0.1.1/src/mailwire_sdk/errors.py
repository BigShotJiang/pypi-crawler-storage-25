"""SDK error hierarchy mirrors the API error envelope.

Server response:

    { "error": { "type": "validation_error", "code": "...", "message": "...",
                 "request_id": "...", "details": {...} } }

is parsed and raised as a typed subclass of `MailwireError`. Callers can either
catch the broad `MailwireError` or be specific (`AuthError`, `NotFoundError`,
`ConflictError`, etc.).
"""

from __future__ import annotations

from typing import Any


class MailwireError(Exception):
    """Base class for every error raised by the SDK."""

    def __init__(
        self,
        message: str,
        *,
        type: str | None = None,
        code: str | None = None,
        status_code: int | None = None,
        details: dict[str, Any] | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.type = type
        self.code = code
        self.status_code = status_code
        self.details: dict[str, Any] = details or {}
        self.request_id = request_id


class AuthError(MailwireError):
    """401 — missing or invalid bearer token."""


class PermissionError(MailwireError):
    """403 — token lacks required scope."""


class NotFoundError(MailwireError):
    """404 — resource missing or owned by another tenant."""


class ConflictError(MailwireError):
    """409 — uniqueness conflict or idempotency-key reuse with a different body."""


class ValidationError(MailwireError):
    """422 / 400 — request body failed validation."""


class ProviderError(MailwireError):
    """502/503-ish — upstream provider failed."""


class ServerError(MailwireError):
    """5xx — internal error."""


_BY_TYPE: dict[str, type[MailwireError]] = {
    "auth_error": AuthError,
    "permission_error": PermissionError,
    "not_found": NotFoundError,
    "conflict": ConflictError,
    "validation_error": ValidationError,
    "request_error": ValidationError,
    "provider_error": ProviderError,
    "server_error": ServerError,
}


def from_envelope(envelope: dict[str, Any], *, status_code: int) -> MailwireError:
    """Construct the right subclass from an `{"error": {...}}` payload."""
    err = envelope.get("error", envelope)
    cls = _BY_TYPE.get(err.get("type", ""), MailwireError)
    return cls(
        err.get("message", "request failed"),
        type=err.get("type"),
        code=err.get("code"),
        status_code=status_code,
        details=err.get("details"),
        request_id=err.get("request_id"),
    )
