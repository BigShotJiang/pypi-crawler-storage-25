"""Cross-project memory for AI coding agents."""

__version__ = "0.3.0"
