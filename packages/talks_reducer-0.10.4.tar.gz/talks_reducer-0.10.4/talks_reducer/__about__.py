"""Package metadata for talks_reducer."""

__all__ = ["__version__"]

__version__ = "0.10.4"
