from __future__ import annotations

from .._types import _ensure_connected
from ..redis import RedisTransport, StandaloneConfig
from ..serializers import JSONSerializer
from ..serializers.base import Serializer
from .base import Result, ResultBackend


class RedisResults(ResultBackend):
	def __init__(
		self,
		url: str = "redis://localhost:6379/0",
		prefix: str = "qq:r:",
		*,
		transport: RedisTransport | None = None,
		serializer: Serializer = JSONSerializer(),
		marshal_types: bool = True,
		ttl: float | None = 86400,
		replay: bool = True,
		store_errors: bool = True,
	):
		"""
		Redis-backed result store.

		- `url`: Redis connection URL (convenience alias for ``StandaloneConfig``).
		- `prefix`: key prefix for every stored result.
		- `transport`: pre-configured :class:`~kuu.redis.RedisTransport`.
		  When given, ``url`` is ignored.
		- `serializer`: payload serializer.
		- `marshal_types`: persist type info alongside the payload.
		- `ttl`: default expiry in seconds; ``None`` means no expiry.
		- `replay`: short-circuit task execution when a cached result is present.
		- `store_errors`: persist terminal failures so callers can observe them.
		"""
		super().__init__(
			serializer=serializer,
			marshal_types=marshal_types,
			ttl=ttl,
			replay=replay,
			store_errors=store_errors,
		)
		self.prefix = prefix
		self._redis = transport or RedisTransport(StandaloneConfig(url=url))

	@property
	def r(self):
		assert self._redis.r is not None
		return self._redis.r

	def _k(self, key: str) -> str:
		return self._redis.result_key(self.prefix, key)

	async def connect(self) -> None:
		if self._redis.r is not None:
			return
		await self._redis.connect()

	async def close(self) -> None:
		await self._redis.close()

	@_ensure_connected
	async def get(self, key: str) -> Result | None:
		data = await self.r.get(self._k(key))
		return self.serializer.unmarshal(data, into=Result) if data else None

	@_ensure_connected
	async def set(self, key: str, result: Result, ttl: float | None = None) -> None:
		await self.r.set(
			self._k(key), self.serializer.marshal(result), ex=int(ttl) if ttl else None
		)

	@_ensure_connected
	async def setnx(self, key: str, result: Result, ttl: float | None = None) -> bool:
		return bool(
			await self.r.set(
				self._k(key), self.serializer.marshal(result), ex=int(ttl) if ttl else None, nx=True
			)
		)
