"""
Agent lock file utilities.

The agent.lock file stores the agent ID and function ID for a voicerun project,
allowing the CLI to track which remote agent corresponds to the local project.
"""

import json
from pathlib import Path
from typing import Optional

import typer

from ..entities.agent import AgentRepository
from ..utils.config import ERROR_STYLE
from ..utils.utils import console

AGENT_LOCK_FILE = "agent.lock"


def load_agent_lock(voicerun_dir: Path) -> Optional[dict]:
    """Load the agent lock file if it exists.

    Args:
        voicerun_dir: Path to the .voicerun directory

    Returns:
        Dictionary with lock data (id, functionId) or None if not found/invalid
    """
    lock_path = voicerun_dir / AGENT_LOCK_FILE
    if lock_path.exists():
        try:
            with open(lock_path, "r") as f:
                return json.load(f)
        except Exception:
            return None
    return None


def save_agent_lock(voicerun_dir: Path, lock_data: dict) -> bool:
    """Save the agent lock file.

    Args:
        voicerun_dir: Path to the .voicerun directory
        lock_data: Dictionary with lock data (id, functionId)

    Returns:
        True if saved successfully, False otherwise
    """
    lock_path = voicerun_dir / AGENT_LOCK_FILE
    try:
        with open(lock_path, "w") as f:
            json.dump(lock_data, f, indent=2)
        return True
    except Exception:
        return False


def resolve_agent(agent: Optional[str] = None):
    """Resolve agent from an argument or from agent.lock.

    Args:
        agent: Optional agent name or ID. If None, falls back to agent.lock
               in the current working directory.

    Returns:
        The resolved Agent entity.

    Raises:
        typer.Exit: If the agent cannot be resolved.
    """
    agent_repo = AgentRepository()

    if agent:
        agent_entity = agent_repo.get_by_name_or_id(agent)
        if not agent_entity:
            console.print(f"[{ERROR_STYLE}]Agent not found: {agent}[/{ERROR_STYLE}]")
            raise typer.Exit(1)
        return agent_entity

    voicerun_dir = Path.cwd() / ".voicerun"
    if voicerun_dir.exists():
        lock_data = load_agent_lock(voicerun_dir)
        if lock_data and "id" in lock_data:
            agent_entity = agent_repo.get_by_id(lock_data["id"])
            if agent_entity:
                return agent_entity

    console.print(f"[{ERROR_STYLE}]No agent specified. Provide an agent name/ID or run from within a voicerun project directory.[/{ERROR_STYLE}]")
    raise typer.Exit(1)
