from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np
from PIL import Image

from .detection import ComicTextDetection, ComicTextDetector
from .detection import ctd as _ctd_mod
from .inpainting.aot import AotInpainter
from .renderer import RenderConfig, render_blocks
from .renderer import bubble as _bubble_mod
from .renderer.bubble import attach_render_bboxes
from .renderer.fonts import FontStack
from .translation import OpenRouterError, VisionBlockResult, VisionLlmClient
from .translation.openrouter import VisionPageResult
from .types import BBox, TextBlock

# YOLO bbox 밖으로 튀어나온 획 끝단까지 포함시키기 위한 여유 픽셀
DROP_BBOX_PAD = 6


@dataclass
class PipelineResult:
    detection: ComicTextDetection
    vision_results: list[VisionBlockResult]
    mask_restricted: np.ndarray
    mask_final: np.ndarray
    inpainted: Image.Image
    # vision_results가 비어있으면 inpainted와 동일
    final: Image.Image
    # LLM 호출이 실제로 실패했을 때만 설정. skip/cached/비어있음은 None.
    vision_error: str | None = None


MIN_COMPONENT_AREA = 500
# 기존 YOLO bbox와 이 비율 이상 겹치면 복구 생략
OVERLAP_THRESHOLD = 0.3


def _iter_clipped_nonempty_bboxes(
    blocks: list[TextBlock], image_w: int, image_h: int, pad: int
):
    for block in blocks:
        x0, y0, x1, y1 = block.bbox.clip_to_image(image_w, image_h, pad)
        if x1 > x0 and y1 > y0:
            yield x0, y0, x1, y1


def _bbox_coverage_mask(
    blocks: list[TextBlock], image_h: int, image_w: int, pad: int
) -> np.ndarray:
    out = np.zeros((image_h, image_w), dtype=bool)
    for x0, y0, x1, y1 in _iter_clipped_nonempty_bboxes(blocks, image_w, image_h, pad):
        out[y0:y1, x0:x1] = True
    return out


def recover_missed_blocks(
    mask: np.ndarray,
    blocks: list[TextBlock],
    pad: int = DROP_BBOX_PAD,
    min_area: int = MIN_COMPONENT_AREA,
    overlap_threshold: float = OVERLAP_THRESHOLD,
) -> list[TextBlock]:
    if mask.max() == 0:
        return []

    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)

    H, W = mask.shape[:2]
    covered = _bbox_coverage_mask(blocks, H, W, pad)

    new_blocks: list[TextBlock] = []
    # label 0은 cv2 connected-component 규약상 배경
    for i in range(1, n_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < min_area:
            continue

        component_mask = labels == i
        overlap_ratio = np.sum(component_mask & covered) / area
        if overlap_ratio > overlap_threshold:
            continue

        cx = float(stats[i, cv2.CC_STAT_LEFT])
        cy = float(stats[i, cv2.CC_STAT_TOP])
        cw = float(stats[i, cv2.CC_STAT_WIDTH])
        ch = float(stats[i, cv2.CC_STAT_HEIGHT])
        new_blocks.append(TextBlock(bbox=BBox(x=cx, y=cy, width=cw, height=ch)))

    return new_blocks


def restrict_mask_to_bboxes(
    mask: np.ndarray,
    blocks: list[TextBlock],
    pad: int = DROP_BBOX_PAD,
) -> np.ndarray:
    if not blocks:
        return np.zeros_like(mask)
    H, W = mask.shape[:2]
    allowed = _bbox_coverage_mask(blocks, H, W, pad)
    out = mask.copy()
    out[~allowed] = 0
    return out


def drop_sfx_blocks(
    mask: np.ndarray,
    blocks: list[TextBlock],
    vision_results: list[VisionBlockResult],
    pad: int = DROP_BBOX_PAD,
) -> np.ndarray:
    drop_indices = {r.block_index for r in vision_results if r.is_sfx}
    if not drop_indices:
        return mask
    sfx_blocks = [b for i, b in enumerate(blocks) if i in drop_indices]
    out = mask.copy()
    H, W = out.shape[:2]
    for x0, y0, x1, y1 in _iter_clipped_nonempty_bboxes(sfx_blocks, W, H, pad):
        out[y0:y1, x0:x1] = 0
    return out


def run_pipeline(
    image: Image.Image,
    ctd: ComicTextDetector,
    aot: AotInpainter,
    client: VisionLlmClient | None,
    stack: FontStack,
    *,
    skip_llm: bool = False,
    expand_bubbles: bool = True,
    cached_vision: list[VisionBlockResult] | None = None,
    recorder=None,
) -> PipelineResult:
    if recorder is not None:
        recorder.record_params({
            "image_size": list(image.size),
            "ctd": {
                "input_size": ctd.input_size[0],
                "confidence_threshold": _ctd_mod.CONFIDENCE_THRESHOLD,
                "nms_threshold": _ctd_mod.NMS_THRESHOLD,
                "mask_prob_threshold": _ctd_mod.MASK_PROB_THRESHOLD,
                "dilation_radius": _ctd_mod.DILATION_RADIUS,
                "hole_close_radius": _ctd_mod.HOLE_CLOSE_RADIUS,
                "bbox_dilation": _ctd_mod.BBOX_DILATION,
            },
            "pipeline": {
                "drop_bbox_pad": DROP_BBOX_PAD,
                "min_component_area": MIN_COMPONENT_AREA,
                "overlap_threshold": OVERLAP_THRESHOLD,
                "skip_llm": skip_llm,
                "expand_bubbles": expand_bubbles,
            },
            "bubble": {
                "flood_tolerance": list(_bubble_mod.FLOOD_TOLERANCE),
                "max_area_ratio": _bubble_mod.DEFAULT_MAX_AREA_RATIO,
                "max_expansion_ratio": _bubble_mod.DEFAULT_MAX_EXPANSION_RATIO,
                "overlap_threshold": _bubble_mod.DEFAULT_OVERLAP_THRESHOLD,
            },
            "vision": {
                "model": client.model if client else None,
                "max_long_edge": client.annotator.max_long_edge if client else None,
            },
        })
        recorder.record_input(image)

    image_np = np.asarray(image.convert("RGB"), dtype=np.uint8)
    detection = ctd.infer(image_np)
    print(f"[pipeline] CTD: {len(detection.text_blocks)} blocks (YOLO)")

    missed = recover_missed_blocks(detection.mask, detection.text_blocks)
    if missed:
        print(f"[pipeline] recovered {len(missed)} block(s) from UNet mask")
        detection.text_blocks.extend(missed)
        detection.text_blocks.sort(key=lambda b: b.bbox.y + b.bbox.height * 0.5)

    mask_restricted = restrict_mask_to_bboxes(detection.mask, detection.text_blocks)
    if recorder is not None:
        recorder.record_detection(image, detection, mask_restricted)

    if not detection.text_blocks:
        print("[pipeline] no text blocks detected — skipping LLM/inpaint/render")
        empty_mask = np.zeros_like(detection.mask)
        if recorder is not None:
            recorder.record_final(image)
        return PipelineResult(
            detection=detection,
            vision_results=[],
            mask_restricted=mask_restricted,
            mask_final=empty_mask,
            inpainted=image,
            final=image,
        )

    vision_results, vision_error = _run_vision(
        image, detection.text_blocks, client, skip_llm, cached_vision, recorder
    )

    mask_final = drop_sfx_blocks(mask_restricted, detection.text_blocks, vision_results)
    if mask_final is not mask_restricted:
        dropped = sorted({r.block_index for r in vision_results if r.is_sfx})
        print(f"[pipeline] dropping {len(dropped)} SFX block(s) from mask: {dropped}")
    if recorder is not None:
        recorder.record_vision(image, vision_results, mask_final)

    inpainted = aot.infer(image, Image.fromarray(mask_final, mode="L"))
    if recorder is not None:
        recorder.record_inpaint(inpainted)

    final = _render(
        inpainted, detection.text_blocks, vision_results, stack, recorder,
        expand_bubbles=expand_bubbles,
    )
    if recorder is not None:
        recorder.record_final(final)

    return PipelineResult(
        detection=detection,
        vision_results=vision_results,
        mask_restricted=mask_restricted,
        mask_final=mask_final,
        inpainted=inpainted,
        final=final,
        vision_error=vision_error,
    )


def _run_vision(
    image: Image.Image,
    blocks: list[TextBlock],
    client: VisionLlmClient | None,
    skip_llm: bool,
    cached_vision: list[VisionBlockResult] | None,
    recorder=None,
) -> tuple[list[VisionBlockResult], str | None]:
    if cached_vision is not None:
        print(f"[pipeline] vision: reused {len(cached_vision)} results from cache")
        return cached_vision, None
    if skip_llm or not blocks:
        return [], None
    if client is None:
        print("[pipeline] LLM skipped: OPENROUTER_API_KEY/MODEL not set")
        return [], None

    try:
        page_result: VisionPageResult = client.run_page(image, blocks)
    except OpenRouterError as e:
        msg = str(e)
        print(f"[pipeline] !! vision LLM FAILED: {msg}")
        return [], msg

    if recorder is not None:
        if page_result.annotated is not None:
            recorder.record_annotated(page_result.annotated)
        if page_result.usage:
            recorder.record_cost(client.model, page_result.attempts, page_result.usage)

    results = page_result.blocks
    print(
        f"[pipeline] vision: {len(results)} decisions "
        f"({client.model}, attempts={page_result.attempts})"
    )
    for r in results:
        tag = "SFX" if r.is_sfx else "대사"
        print(f"  [{r.block_index}] {tag} -> {r.ko_translation!r}")
    return results, None


def _render(
    inpainted: Image.Image,
    blocks: list[TextBlock],
    vision_results: list[VisionBlockResult],
    stack: FontStack,
    recorder,
    *,
    expand_bubbles: bool = True,
) -> Image.Image:
    if not vision_results:
        print("[pipeline] no vision results — skipping render")
        return inpainted

    for r in vision_results:
        if 0 <= r.block_index < len(blocks):
            blocks[r.block_index].translation = r.ko_translation

    if expand_bubbles:
        inpainted_np = np.asarray(inpainted.convert("RGB"), dtype=np.uint8)
        attach_render_bboxes(inpainted_np, blocks)
    if recorder is not None:
        recorder.record_render(inpainted, blocks)

    return render_blocks(inpainted, blocks, stack=stack)
