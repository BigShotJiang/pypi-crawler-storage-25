"""공백이 있으면 단어 단위, 없으면 글자 단위 줄바꿈.

한국어 말풍선은 공백을 포함하는 경우가 많아 단어 단위를 먼저 시도하고,
공백 없는 덩어리(예: '우와아아아아')나 CJK 본문은 글자 단위로 폴백.
"""

from __future__ import annotations

from .fonts import FontStack


def wrap_text(text: str, stack: FontStack, max_width: float, size: int) -> list[str]:
    if not text:
        return [""]

    lines: list[str] = []
    for paragraph in text.split("\n"):
        if paragraph == "":
            lines.append("")
            continue
        lines.extend(_wrap_paragraph(paragraph, stack, max_width, size))
    return lines


def _wrap_paragraph(text: str, stack: FontStack, max_width: float, size: int) -> list[str]:
    if " " in text:
        return _wrap_by_word(text.split(" "), stack, max_width, size)
    return _wrap_by_char(text, stack, max_width, size)


def _wrap_by_word(words: list[str], stack: FontStack, max_width: float, size: int) -> list[str]:
    lines: list[str] = []
    current = ""
    current_w = 0.0
    space_w = stack.char_width(" ", size)

    for word in words:
        word_w = stack.measure(word, size)

        if word_w > max_width:
            if current:
                lines.append(current)
                current = ""
                current_w = 0.0
            lines.extend(_wrap_by_char(word, stack, max_width, size))
            continue

        if not current:
            current = word
            current_w = word_w
            continue

        tentative = current_w + space_w + word_w
        if tentative <= max_width:
            current = current + " " + word
            current_w = tentative
        else:
            lines.append(current)
            current = word
            current_w = word_w

    if current:
        lines.append(current)
    return lines or [""]


def _wrap_by_char(text: str, stack: FontStack, max_width: float, size: int) -> list[str]:
    lines: list[str] = []
    current = ""
    current_w = 0.0

    for ch in text:
        ch_w = stack.char_width(ch, size)
        if current and current_w + ch_w > max_width:
            lines.append(current)
            current = ch
            current_w = ch_w
        else:
            current += ch
            current_w += ch_w

    if current:
        lines.append(current)
    return lines or [""]
