from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PIL import Image

from ..types import TextBlock
from .draw import draw_centered
from .fit import fit_font_size
from .fonts import FontStack

_PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PRIMARY_FONT = _PACKAGE_ROOT / "assets" / "fonts" / "Jua-Regular.ttf"
DEFAULT_FALLBACK_FONT = _PACKAGE_ROOT / "assets" / "fonts" / "PretendardJP-Regular.otf"


def default_font_stack() -> FontStack:
    return FontStack(
        primary_path=DEFAULT_PRIMARY_FONT,
        fallback_path=DEFAULT_FALLBACK_FONT,
    )


@dataclass
class RenderConfig:
    padding_ratio: float = 0.08

    fill_color: tuple[int, int, int] = (0, 0, 0)
    stroke_color: tuple[int, int, int] | None = (255, 255, 255)

    stroke_ratio: float = 0.08

    min_font_size: int = 10
    max_font_size: int = 72


def render_blocks(
    image: Image.Image,
    blocks: list[TextBlock],
    config: RenderConfig | None = None,
    stack: FontStack | None = None,
) -> Image.Image:
    config = config or RenderConfig()
    stack = stack or default_font_stack()

    out = image.copy()
    if out.mode != "RGB":
        out = out.convert("RGB")

    for block in blocks:
        text = (block.translation or "").strip()
        if not text:
            continue

        bbox = block.render_bbox or block.bbox
        pad_x = bbox.width * config.padding_ratio
        pad_y = bbox.height * config.padding_ratio
        max_w = max(1.0, bbox.width - 2 * pad_x)
        max_h = max(1.0, bbox.height - 2 * pad_y)

        size, lines = fit_font_size(
            text,
            stack,
            max_w,
            max_h,
            min_size=config.min_font_size,
            max_size=config.max_font_size,
        )

        stroke_w = (
            max(0, int(round(size * config.stroke_ratio)))
            if config.stroke_color is not None
            else 0
        )

        draw_centered(
            image=out,
            box_x=bbox.x + pad_x,
            box_y=bbox.y + pad_y,
            box_w=max_w,
            box_h=max_h,
            lines=lines,
            stack=stack,
            size=size,
            fill=config.fill_color,
            stroke_fill=config.stroke_color if stroke_w > 0 else None,
            stroke_width=stroke_w,
        )

    return out


__all__ = [
    "RenderConfig",
    "render_blocks",
    "default_font_stack",
    "DEFAULT_PRIMARY_FONT",
    "DEFAULT_FALLBACK_FONT",
]
