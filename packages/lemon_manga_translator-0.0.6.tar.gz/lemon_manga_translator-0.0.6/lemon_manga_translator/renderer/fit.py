"""박스에 맞는 최대 폰트 사이즈 이진탐색. 매 iteration 마다 wrap을 다시
돌리지만 박스당 ~log2(80-8)≈6회라 비용은 무시 가능.
"""

from __future__ import annotations

from .fonts import FontStack
from .wrap import wrap_text


def fit_font_size(
    text: str,
    stack: FontStack,
    max_width: float,
    max_height: float,
    min_size: int,
    max_size: int,
) -> tuple[int, list[str]]:
    low, high = min_size, max_size
    best_size = min_size
    best_lines: list[str] = []

    while low <= high:
        mid = (low + high) // 2
        lines = wrap_text(text, stack, max_width, mid)

        total_h = len(lines) * stack.line_height(mid)
        widest = max((stack.measure(line, mid) for line in lines), default=0.0)

        if widest <= max_width and total_h <= max_height:
            best_size = mid
            best_lines = lines
            low = mid + 1
        else:
            high = mid - 1

    if not best_lines:
        best_lines = wrap_text(text, stack, max_width, min_size)
        best_size = min_size

    return best_size, best_lines
