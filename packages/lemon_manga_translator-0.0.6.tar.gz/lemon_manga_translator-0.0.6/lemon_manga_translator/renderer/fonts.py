"""primary가 글자를 렌더하는지 판단은 getmask(ch) 결과를 notdef(U+FFFD)
마스크와 비교해서 확인한다. PIL이 커버리지 API를 안 주기 때문.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from PIL import ImageFont
from PIL.ImageFont import FreeTypeFont

_NOTDEF_PROBE = "\uFFFD"
LINE_SPACING_RATIO = 1.2


@dataclass
class _SizedFonts:
    primary: FreeTypeFont
    fallback: FreeTypeFont
    tofu: bytes  # size별 notdef 마스크 바이트


@dataclass
class FontStack:
    primary_path: Path
    fallback_path: Path
    _fonts: dict[int, _SizedFonts] = field(init=False, repr=False, default_factory=dict)
    _coverage: dict[str, bool] = field(init=False, repr=False, default_factory=dict)

    def _ensure(self, size: int) -> _SizedFonts:
        cached = self._fonts.get(size)
        if cached is not None:
            return cached
        primary = ImageFont.truetype(str(self.primary_path), size)
        fallback = ImageFont.truetype(str(self.fallback_path), size)
        tofu = bytes(primary.getmask(_NOTDEF_PROBE))
        sized = _SizedFonts(primary=primary, fallback=fallback, tofu=tofu)
        self._fonts[size] = sized
        return sized

    def _primary_has(self, ch: str, size: int) -> bool:
        if not ch:
            return True
        cached = self._coverage.get(ch)
        if cached is not None:
            return cached
        sized = self._ensure(size)
        result = bytes(sized.primary.getmask(ch)) != sized.tofu
        self._coverage[ch] = result
        return result

    def pick(self, ch: str, size: int) -> FreeTypeFont:
        sized = self._ensure(size)
        return sized.primary if self._primary_has(ch, size) else sized.fallback

    def char_width(self, ch: str, size: int) -> float:
        return self.pick(ch, size).getlength(ch)

    def measure(self, text: str, size: int) -> float:
        return sum(self.char_width(ch, size) for ch in text)

    def glyph_height(self, size: int) -> float:
        ascent, descent = self._ensure(size).primary.getmetrics()
        return ascent + descent

    def line_height(self, size: int) -> float:
        return self.glyph_height(size) * LINE_SPACING_RATIO
