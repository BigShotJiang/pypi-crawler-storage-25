import{j as U,r as B,_ as w,u as Kt}from"./index-D1i09K0m.js";import{c as Xt,b as Ke,n as Jt,a as Yt,t as me}from"./langs-Cmgo0-eD.js";const Zt={position:"absolute",top:0,bottom:0,textAlign:"center"},Qt={display:"contents"};function at(){return null}const _e="diffs-container",en=/(?=^From [a-f0-9]+ .+$)/m,Ee=/(?=^diff --git)/gm,st=/(?=^---\s+\S)/gm,tn=/(?=^@@ )/gm,nn=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: (.*))?/m,Me=new RegExp("(?<=\\n)"),rn=/^(---|\+\+\+)\s+([^\t\r\n]+)/,on=/^(---|\+\+\+)\s+[ab]\/([^\t\r\n]+)/,an=/^diff --git (?:"a\/(.+?)"|a\/(.+?)) (?:"b\/(.+?)"|b\/(.+?))$/,sn=/^index ([0-9a-f]+)\.\.([0-9a-f]+)(?: (\d+))?$/i,tt="header-prefix",nt="header-metadata",it="header-custom",J={dark:"pierre-dark",light:"pierre-light"},Mt="data-theme-css",Nt="data-unsafe-css",fe=1,ln={hunkLineCount:50,lineHeight:20,diffHeaderHeight:44,hunkSeparatorHeight:32,fileGap:8},dn=Object.freeze({fromStart:0,fromEnd:0}),lt={startingLine:0,totalLines:1/0,bufferBefore:0,bufferAfter:0},fn={startingLine:0,totalLines:0,bufferBefore:0,bufferAfter:0};function ge(e){return`annotation-${"side"in e?`${e.side}-`:""}${e.lineNumber}`}function cn(e,t){return typeof window>"u"&&t!=null?U.jsxs(U.Fragment,{children:[U.jsx("template",{shadowrootmode:"open",dangerouslySetInnerHTML:{__html:t}}),e]}):U.jsx(U.Fragment,{children:e})}const un=B.createContext(void 0);function hn(){return B.useContext(un)}const re=new Map,Ne=new Map,Xe=new Map,Je=new Set;function dt(e,t){e=Array.isArray(e)?e:[e];for(let n of e){let i;if(typeof n=="string"){if(i=re.get(n),i==null)throw new Error(`loadResolvedThemes: ${n} is not resolved, you must resolve it before calling loadResolvedThemes`)}else i=n,n=n.name,re.has(n)||re.set(n,i);Je.has(n)||(Je.add(n),t.loadThemeSync(i))}}const be=new Map,He=new Map,pn=new Map,Ye=new Set;function ft(e,t){e=Array.isArray(e)?e:[e];for(const n of e){if(Ye.has(n.name))continue;let i=be.get(n.name);i==null&&(i=n,be.set(n.name,i)),Ye.add(i.name),t.loadLanguageSync(i.data)}}function Ht(){return typeof WorkerGlobalScope<"u"&&typeof self<"u"&&self instanceof WorkerGlobalScope}const mn=[{id:"andromeeda",displayName:"Andromeeda",type:"dark",import:(()=>w(()=>import("./andromeeda-C4gqWexZ.js"),[]))},{id:"aurora-x",displayName:"Aurora X",type:"dark",import:(()=>w(()=>import("./aurora-x-D-2ljcwZ.js"),[]))},{id:"ayu-dark",displayName:"Ayu Dark",type:"dark",import:(()=>w(()=>import("./ayu-dark-DYE7WIF3.js"),[]))},{id:"ayu-light",displayName:"Ayu Light",type:"light",import:(()=>w(()=>import("./ayu-light-BA47KaF1.js"),[]))},{id:"ayu-mirage",displayName:"Ayu Mirage",type:"dark",import:(()=>w(()=>import("./ayu-mirage-32ctXXKs.js"),[]))},{id:"catppuccin-frappe",displayName:"Catppuccin Frappé",type:"dark",import:(()=>w(()=>import("./catppuccin-frappe-DFWUc33u.js"),[]))},{id:"catppuccin-latte",displayName:"Catppuccin Latte",type:"light",import:(()=>w(()=>import("./catppuccin-latte-C9dUb6Cb.js"),[]))},{id:"catppuccin-macchiato",displayName:"Catppuccin Macchiato",type:"dark",import:(()=>w(()=>import("./catppuccin-macchiato-DQyhUUbL.js"),[]))},{id:"catppuccin-mocha",displayName:"Catppuccin Mocha",type:"dark",import:(()=>w(()=>import("./catppuccin-mocha-D87Tk5Gz.js"),[]))},{id:"dark-plus",displayName:"Dark Plus",type:"dark",import:(()=>w(()=>import("./dark-plus-C3mMm8J8.js"),[]))},{id:"dracula",displayName:"Dracula Theme",type:"dark",import:(()=>w(()=>import("./dracula-BzJJZx-M.js"),[]))},{id:"dracula-soft",displayName:"Dracula Theme Soft",type:"dark",import:(()=>w(()=>import("./dracula-soft-BXkSAIEj.js"),[]))},{id:"everforest-dark",displayName:"Everforest Dark",type:"dark",import:(()=>w(()=>import("./everforest-dark-BgDCqdQA.js"),[]))},{id:"everforest-light",displayName:"Everforest Light",type:"light",import:(()=>w(()=>import("./everforest-light-C8M2exoo.js"),[]))},{id:"github-dark",displayName:"GitHub Dark",type:"dark",import:(()=>w(()=>import("./github-dark-DHJKELXO.js"),[]))},{id:"github-dark-default",displayName:"GitHub Dark Default",type:"dark",import:(()=>w(()=>import("./github-dark-default-Cuk6v7N8.js"),[]))},{id:"github-dark-dimmed",displayName:"GitHub Dark Dimmed",type:"dark",import:(()=>w(()=>import("./github-dark-dimmed-DH5Ifo-i.js"),[]))},{id:"github-dark-high-contrast",displayName:"GitHub Dark High Contrast",type:"dark",import:(()=>w(()=>import("./github-dark-high-contrast-E3gJ1_iC.js"),[]))},{id:"github-light",displayName:"GitHub Light",type:"light",import:(()=>w(()=>import("./github-light-DAi9KRSo.js"),[]))},{id:"github-light-default",displayName:"GitHub Light Default",type:"light",import:(()=>w(()=>import("./github-light-default-D7oLnXFd.js"),[]))},{id:"github-light-high-contrast",displayName:"GitHub Light High Contrast",type:"light",import:(()=>w(()=>import("./github-light-high-contrast-BfjtVDDH.js"),[]))},{id:"gruvbox-dark-hard",displayName:"Gruvbox Dark Hard",type:"dark",import:(()=>w(()=>import("./gruvbox-dark-hard-CFHQjOhq.js"),[]))},{id:"gruvbox-dark-medium",displayName:"Gruvbox Dark Medium",type:"dark",import:(()=>w(()=>import("./gruvbox-dark-medium-GsRaNv29.js"),[]))},{id:"gruvbox-dark-soft",displayName:"Gruvbox Dark Soft",type:"dark",import:(()=>w(()=>import("./gruvbox-dark-soft-CVdnzihN.js"),[]))},{id:"gruvbox-light-hard",displayName:"Gruvbox Light Hard",type:"light",import:(()=>w(()=>import("./gruvbox-light-hard-CH1njM8p.js"),[]))},{id:"gruvbox-light-medium",displayName:"Gruvbox Light Medium",type:"light",import:(()=>w(()=>import("./gruvbox-light-medium-DRw_LuNl.js"),[]))},{id:"gruvbox-light-soft",displayName:"Gruvbox Light Soft",type:"light",import:(()=>w(()=>import("./gruvbox-light-soft-hJgmCMqR.js"),[]))},{id:"horizon",displayName:"Horizon",type:"dark",import:(()=>w(()=>import("./horizon-BUw7H-hv.js"),[]))},{id:"horizon-bright",displayName:"Horizon Bright",type:"dark",import:(()=>w(()=>import("./horizon-bright-Cn-bp-IR.js"),[]))},{id:"houston",displayName:"Houston",type:"dark",import:(()=>w(()=>import("./houston-DnULxvSX.js"),[]))},{id:"kanagawa-dragon",displayName:"Kanagawa Dragon",type:"dark",import:(()=>w(()=>import("./kanagawa-dragon-CkXjmgJE.js"),[]))},{id:"kanagawa-lotus",displayName:"Kanagawa Lotus",type:"light",import:(()=>w(()=>import("./kanagawa-lotus-CfQXZHmo.js"),[]))},{id:"kanagawa-wave",displayName:"Kanagawa Wave",type:"dark",import:(()=>w(()=>import("./kanagawa-wave-DWedfzmr.js"),[]))},{id:"laserwave",displayName:"LaserWave",type:"dark",import:(()=>w(()=>import("./laserwave-DUszq2jm.js"),[]))},{id:"light-plus",displayName:"Light Plus",type:"light",import:(()=>w(()=>import("./light-plus-B7mTdjB0.js"),[]))},{id:"material-theme",displayName:"Material Theme",type:"dark",import:(()=>w(()=>import("./material-theme-D5KoaKCx.js"),[]))},{id:"material-theme-darker",displayName:"Material Theme Darker",type:"dark",import:(()=>w(()=>import("./material-theme-darker-BfHTSMKl.js"),[]))},{id:"material-theme-lighter",displayName:"Material Theme Lighter",type:"light",import:(()=>w(()=>import("./material-theme-lighter-B0m2ddpp.js"),[]))},{id:"material-theme-ocean",displayName:"Material Theme Ocean",type:"dark",import:(()=>w(()=>import("./material-theme-ocean-CyktbL80.js"),[]))},{id:"material-theme-palenight",displayName:"Material Theme Palenight",type:"dark",import:(()=>w(()=>import("./material-theme-palenight-Csfq5Kiy.js"),[]))},{id:"min-dark",displayName:"Min Dark",type:"dark",import:(()=>w(()=>import("./min-dark-CafNBF8u.js"),[]))},{id:"min-light",displayName:"Min Light",type:"light",import:(()=>w(()=>import("./min-light-CTRr51gU.js"),[]))},{id:"monokai",displayName:"Monokai",type:"dark",import:(()=>w(()=>import("./monokai-D4h5O-jR.js"),[]))},{id:"night-owl",displayName:"Night Owl",type:"dark",import:(()=>w(()=>import("./night-owl-C39BiMTA.js"),[]))},{id:"night-owl-light",displayName:"Night Owl Light",type:"light",import:(()=>w(()=>import("./night-owl-light-CMTm3GFP.js"),[]))},{id:"nord",displayName:"Nord",type:"dark",import:(()=>w(()=>import("./nord-Ddv68eIx.js"),[]))},{id:"one-dark-pro",displayName:"One Dark Pro",type:"dark",import:(()=>w(()=>import("./one-dark-pro-DVMEJ2y_.js"),[]))},{id:"one-light",displayName:"One Light",type:"light",import:(()=>w(()=>import("./one-light-C3Wv6jpd.js"),[]))},{id:"plastic",displayName:"Plastic",type:"dark",import:(()=>w(()=>import("./plastic-3e1v2bzS.js"),[]))},{id:"poimandres",displayName:"Poimandres",type:"dark",import:(()=>w(()=>import("./poimandres-CS3Unz2-.js"),[]))},{id:"red",displayName:"Red",type:"dark",import:(()=>w(()=>import("./red-bN70gL4F.js"),[]))},{id:"rose-pine",displayName:"Rosé Pine",type:"dark",import:(()=>w(()=>import("./rose-pine-qdsjHGoJ.js"),[]))},{id:"rose-pine-dawn",displayName:"Rosé Pine Dawn",type:"light",import:(()=>w(()=>import("./rose-pine-dawn-DHQR4-dF.js"),[]))},{id:"rose-pine-moon",displayName:"Rosé Pine Moon",type:"dark",import:(()=>w(()=>import("./rose-pine-moon-D4_iv3hh.js"),[]))},{id:"slack-dark",displayName:"Slack Dark",type:"dark",import:(()=>w(()=>import("./slack-dark-BthQWCQV.js"),[]))},{id:"slack-ochin",displayName:"Slack Ochin",type:"light",import:(()=>w(()=>import("./slack-ochin-DqwNpetd.js"),[]))},{id:"snazzy-light",displayName:"Snazzy Light",type:"light",import:(()=>w(()=>import("./snazzy-light-Bw305WKR.js"),[]))},{id:"solarized-dark",displayName:"Solarized Dark",type:"dark",import:(()=>w(()=>import("./solarized-dark-DXbdFlpD.js"),[]))},{id:"solarized-light",displayName:"Solarized Light",type:"light",import:(()=>w(()=>import("./solarized-light-L9t79GZl.js"),[]))},{id:"synthwave-84",displayName:"Synthwave '84",type:"dark",import:(()=>w(()=>import("./synthwave-84-CbfX1IO0.js"),[]))},{id:"tokyo-night",displayName:"Tokyo Night",type:"dark",import:(()=>w(()=>import("./tokyo-night-hegEt444.js"),[]))},{id:"vesper",displayName:"Vesper",type:"dark",import:(()=>w(()=>import("./vesper-DU1UobuO.js"),[]))},{id:"vitesse-black",displayName:"Vitesse Black",type:"dark",import:(()=>w(()=>import("./vitesse-black-Bkuqu6BP.js"),[]))},{id:"vitesse-dark",displayName:"Vitesse Dark",type:"dark",import:(()=>w(()=>import("./vitesse-dark-D0r3Knsf.js"),[]))},{id:"vitesse-light",displayName:"Vitesse Light",type:"light",import:(()=>w(()=>import("./vitesse-light-CVO1_9PV.js"),[]))}],Ot=Object.fromEntries(mn.map(e=>[e.id,e.import]));class rt extends Error{constructor(t){super(t),this.name="ShikiError"}}function gn(){return 2147483648}function bn(){return typeof performance<"u"?performance.now():Date.now()}const vn=(e,t)=>e+(t-e%t)%t;async function yn(e){let t,n;const i={};function r(u){n=u,i.HEAPU8=new Uint8Array(u),i.HEAPU32=new Uint32Array(u)}function o(u,p,y){i.HEAPU8.copyWithin(u,p,p+y)}function s(u){try{return t.grow(u-n.byteLength+65535>>>16),r(t.buffer),1}catch{}}function l(u){const p=i.HEAPU8.length;u=u>>>0;const y=gn();if(u>y)return!1;for(let x=1;x<=4;x*=2){let C=p*(1+.2/x);C=Math.min(C,u+100663296);const m=Math.min(y,vn(Math.max(u,C),65536));if(s(m))return!0}return!1}const a=typeof TextDecoder<"u"?new TextDecoder("utf8"):void 0;function d(u,p,y=1024){const x=p+y;let C=p;for(;u[C]&&!(C>=x);)++C;if(C-p>16&&u.buffer&&a)return a.decode(u.subarray(p,C));let m="";for(;p<C;){let b=u[p++];if(!(b&128)){m+=String.fromCharCode(b);continue}const v=u[p++]&63;if((b&224)===192){m+=String.fromCharCode((b&31)<<6|v);continue}const S=u[p++]&63;if((b&240)===224?b=(b&15)<<12|v<<6|S:b=(b&7)<<18|v<<12|S<<6|u[p++]&63,b<65536)m+=String.fromCharCode(b);else{const g=b-65536;m+=String.fromCharCode(55296|g>>10,56320|g&1023)}}return m}function f(u,p){return u?d(i.HEAPU8,u,p):""}const c={emscripten_get_now:bn,emscripten_memcpy_big:o,emscripten_resize_heap:l,fd_write:()=>0};async function h(){const p=await e({env:c,wasi_snapshot_preview1:c});t=p.memory,r(t.buffer),Object.assign(i,p),i.UTF8ToString=f}return await h(),i}var kn=Object.defineProperty,xn=(e,t,n)=>t in e?kn(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,H=(e,t,n)=>xn(e,typeof t!="symbol"?t+"":t,n);let O=null;function Sn(e){throw new rt(e.UTF8ToString(e.getLastOnigError()))}class Pe{constructor(t){H(this,"utf16Length"),H(this,"utf8Length"),H(this,"utf16Value"),H(this,"utf8Value"),H(this,"utf16OffsetToUtf8"),H(this,"utf8OffsetToUtf16");const n=t.length,i=Pe._utf8ByteLength(t),r=i!==n,o=r?new Uint32Array(n+1):null;r&&(o[n]=i);const s=r?new Uint32Array(i+1):null;r&&(s[i]=n);const l=new Uint8Array(i);let a=0;for(let d=0;d<n;d++){const f=t.charCodeAt(d);let c=f,h=!1;if(f>=55296&&f<=56319&&d+1<n){const u=t.charCodeAt(d+1);u>=56320&&u<=57343&&(c=(f-55296<<10)+65536|u-56320,h=!0)}r&&(o[d]=a,h&&(o[d+1]=a),c<=127?s[a+0]=d:c<=2047?(s[a+0]=d,s[a+1]=d):c<=65535?(s[a+0]=d,s[a+1]=d,s[a+2]=d):(s[a+0]=d,s[a+1]=d,s[a+2]=d,s[a+3]=d)),c<=127?l[a++]=c:c<=2047?(l[a++]=192|(c&1984)>>>6,l[a++]=128|(c&63)>>>0):c<=65535?(l[a++]=224|(c&61440)>>>12,l[a++]=128|(c&4032)>>>6,l[a++]=128|(c&63)>>>0):(l[a++]=240|(c&1835008)>>>18,l[a++]=128|(c&258048)>>>12,l[a++]=128|(c&4032)>>>6,l[a++]=128|(c&63)>>>0),h&&d++}this.utf16Length=n,this.utf8Length=i,this.utf16Value=t,this.utf8Value=l,this.utf16OffsetToUtf8=o,this.utf8OffsetToUtf16=s}static _utf8ByteLength(t){let n=0;for(let i=0,r=t.length;i<r;i++){const o=t.charCodeAt(i);let s=o,l=!1;if(o>=55296&&o<=56319&&i+1<r){const a=t.charCodeAt(i+1);a>=56320&&a<=57343&&(s=(o-55296<<10)+65536|a-56320,l=!0)}s<=127?n+=1:s<=2047?n+=2:s<=65535?n+=3:n+=4,l&&i++}return n}createString(t){const n=t.omalloc(this.utf8Length);return t.HEAPU8.set(this.utf8Value,n),n}}const De=class K{constructor(t){if(H(this,"id",++K.LAST_ID),H(this,"_onigBinding"),H(this,"content"),H(this,"utf16Length"),H(this,"utf8Length"),H(this,"utf16OffsetToUtf8"),H(this,"utf8OffsetToUtf16"),H(this,"ptr"),!O)throw new rt("Must invoke loadWasm first.");this._onigBinding=O,this.content=t;const n=new Pe(t);this.utf16Length=n.utf16Length,this.utf8Length=n.utf8Length,this.utf16OffsetToUtf8=n.utf16OffsetToUtf8,this.utf8OffsetToUtf16=n.utf8OffsetToUtf16,this.utf8Length<1e4&&!K._sharedPtrInUse?(K._sharedPtr||(K._sharedPtr=O.omalloc(1e4)),K._sharedPtrInUse=!0,O.HEAPU8.set(n.utf8Value,K._sharedPtr),this.ptr=K._sharedPtr):this.ptr=n.createString(O)}convertUtf8OffsetToUtf16(t){return this.utf8OffsetToUtf16?t<0?0:t>this.utf8Length?this.utf16Length:this.utf8OffsetToUtf16[t]:t}convertUtf16OffsetToUtf8(t){return this.utf16OffsetToUtf8?t<0?0:t>this.utf16Length?this.utf8Length:this.utf16OffsetToUtf8[t]:t}dispose(){this.ptr===K._sharedPtr?K._sharedPtrInUse=!1:this._onigBinding.ofree(this.ptr)}};H(De,"LAST_ID",0);H(De,"_sharedPtr",0);H(De,"_sharedPtrInUse",!1);let Ut=De;class Cn{constructor(t){if(H(this,"_onigBinding"),H(this,"_ptr"),!O)throw new rt("Must invoke loadWasm first.");const n=[],i=[];for(let l=0,a=t.length;l<a;l++){const d=new Pe(t[l]);n[l]=d.createString(O),i[l]=d.utf8Length}const r=O.omalloc(4*t.length);O.HEAPU32.set(n,r/4);const o=O.omalloc(4*t.length);O.HEAPU32.set(i,o/4);const s=O.createOnigScanner(r,o,t.length);for(let l=0,a=t.length;l<a;l++)O.ofree(n[l]);O.ofree(o),O.ofree(r),s===0&&Sn(O),this._onigBinding=O,this._ptr=s}dispose(){this._onigBinding.freeOnigScanner(this._ptr)}findNextMatchSync(t,n,i){let r=0;if(typeof i=="number"&&(r=i),typeof t=="string"){t=new Ut(t);const o=this._findNextMatchSync(t,n,!1,r);return t.dispose(),o}return this._findNextMatchSync(t,n,!1,r)}_findNextMatchSync(t,n,i,r){const o=this._onigBinding,s=o.findNextOnigScannerMatch(this._ptr,t.id,t.ptr,t.utf8Length,t.convertUtf16OffsetToUtf8(n),r);if(s===0)return null;const l=o.HEAPU32;let a=s/4;const d=l[a++],f=l[a++],c=[];for(let h=0;h<f;h++){const u=t.convertUtf8OffsetToUtf16(l[a++]),p=t.convertUtf8OffsetToUtf16(l[a++]);c[h]={start:u,end:p,length:p-u}}return{index:d,captureIndices:c}}}function wn(e){return typeof e.instantiator=="function"}function Ln(e){return typeof e.default=="function"}function En(e){return typeof e.data<"u"}function Tn(e){return typeof Response<"u"&&e instanceof Response}function An(e){return typeof ArrayBuffer<"u"&&(e instanceof ArrayBuffer||ArrayBuffer.isView(e))||typeof Buffer<"u"&&Buffer.isBuffer?.(e)||typeof SharedArrayBuffer<"u"&&e instanceof SharedArrayBuffer||typeof Uint32Array<"u"&&e instanceof Uint32Array}let ye;function _n(e){if(ye)return ye;async function t(){O=await yn(async n=>{let i=e;return i=await i,typeof i=="function"&&(i=await i(n)),typeof i=="function"&&(i=await i(n)),wn(i)?i=await i.instantiator(n):Ln(i)?i=await i.default(n):(En(i)&&(i=i.data),Tn(i)?typeof WebAssembly.instantiateStreaming=="function"?i=await In(i)(n):i=await Rn(i)(n):An(i)?i=await Oe(i)(n):i instanceof WebAssembly.Module?i=await Oe(i)(n):"default"in i&&i.default instanceof WebAssembly.Module&&(i=await Oe(i.default)(n))),"instance"in i&&(i=i.instance),"exports"in i&&(i=i.exports),i})}return ye=t(),ye}function Oe(e){return t=>WebAssembly.instantiate(e,t)}function In(e){return t=>WebAssembly.instantiateStreaming(e,t)}function Rn(e){return async t=>{const n=await e.arrayBuffer();return WebAssembly.instantiate(n,t)}}async function zt(e){return e&&await _n(e),{createScanner(t){return new Cn(t.map(n=>typeof n=="string"?n:n.source))},createString(t){return new Ut(t)}}}const Pn=Xt({langs:Ke,themes:Ot,engine:()=>zt(w(()=>import("./wasm-CG6Dc4jp.js"),[]))});async function Dn(e){if(Ht())throw new Error(`resolveLanguage("${e}") cannot be called from a worker context. Languages must be pre-resolved on the main thread and passed to the worker via the resolvedLanguages parameter.`);const t=He.get(e);if(t!=null)return t;try{let n=pn.get(e);if(n==null&&Object.prototype.hasOwnProperty.call(Ke,e)&&(n=Ke[e]),n==null)throw new Error(`resolveLanguage: "${e}" not found in bundled or custom languages`);const i=n().then(({default:r})=>{const o={name:e,data:r};return be.has(e)||be.set(e,o),o});return He.set(e,i),await i}finally{He.delete(e)}}function Mn(e){return be.get(e)??Dn(e)}async function Nn(e){if(Ht())throw new Error(`resolveTheme("${e}") cannot be called from a worker context. Themes must be pre-resolved on the main thread and passed to the worker via the resolvedLanguages parameter.`);const t=Ne.get(e);if(t!=null)return t;try{const n=Xe.get(e)??Ot[e];if(n==null)throw new Error(`resolveTheme: No valid loader for ${e}`);const i=n().then(o=>Hn(e,"default"in o?o.default:o));Ne.set(e,i);const r=await i;if(r.name!==e)throw new Error(`resolvedTheme: themeName: ${e} does not match theme.name: ${r.name}`);return re.set(r.name,r),r}finally{Ne.delete(e)}}function Hn(e,t){const n=re.get(e);return n??(t=Jt(t),re.set(e,t),t)}function On(e){return re.get(e)??Nn(e)}function Ft(e,t){if(Xe.has(e)){console.error("SharedHighlight.registerCustomTheme: theme name already registered",e);return}Xe.set(e,t)}let X;async function Un({themes:e,langs:t,preferredHighlighter:n="shiki-js"}){X??=Pn({themes:[],langs:["text"],engine:n==="shiki-wasm"?zt(w(()=>import("./wasm-CG6Dc4jp.js"),[])):Yt()});const i=Fn(X)?await X:X;X=i;const r=[];for(const s of t){if(s==="text"||s==="ansi")continue;const l=Mn(s);"then"in l?r.push(l):ft(l,i)}const o=[];for(const s of e){const l=On(s);"then"in l?o.push(l):dt(l,X)}return(r.length>0||o.length>0)&&await Promise.all([Promise.all(r).then(s=>{ft(s,i)}),Promise.all(o).then(s=>{dt(s,i)})]),i}function zn(){if(X!=null&&!("then"in X))return X}function Fn(e=X){return e!=null&&"then"in e}Ft("pierre-dark",async()=>{const{default:e}=await w(async()=>{const{default:t}=await import("./pierre-dark-DF2SEV7i.js");return{default:t}},[]);return{...e,name:"pierre-dark"}});Ft("pierre-light",async()=>{const{default:e}=await w(async()=>{const{default:t}=await import("./pierre-light-DOlZxES8.js");return{default:t}},[]);return{...e,name:"pierre-light"}});function $t(e=J){const t=[];return typeof e=="string"?t.push(e):(t.push(e.dark),t.push(e.light)),t}function Vt(e,t){return e==null||t==null||typeof e=="string"||typeof t=="string"?e===t:e.dark===t.dark&&e.light===t.light}const le=new Map,pe={"1c":"1c",abap:"abap",as:"actionscript-3",ada:"ada",adb:"ada",ads:"ada",adoc:"asciidoc",asciidoc:"asciidoc","component.html":"angular-html","component.ts":"angular-ts",conf:"nginx",htaccess:"apache",cls:"tex",trigger:"apex",apl:"apl",applescript:"applescript",scpt:"applescript",ara:"ara",asm:"asm",s:"riscv",astro:"astro",awk:"awk",bal:"ballerina",sh:"zsh",bash:"zsh",bat:"cmd",cmd:"cmd",be:"berry",beancount:"beancount",bib:"bibtex",bicep:"bicep","blade.php":"blade",bsl:"bsl",c:"c",h:"objective-cpp",cs:"csharp",cpp:"cpp",hpp:"cpp",cc:"cpp",cxx:"cpp",hh:"cpp",cdc:"cdc",cairo:"cairo",clar:"clarity",clj:"clojure",cljs:"clojure",cljc:"clojure",soy:"soy",cmake:"cmake","CMakeLists.txt":"cmake",cob:"cobol",cbl:"cobol",cobol:"cobol",CODEOWNERS:"codeowners",ql:"ql",coffee:"coffeescript",lisp:"lisp",cl:"lisp",lsp:"lisp",log:"log",v:"verilog",cql:"cql",cr:"crystal",css:"css",csv:"csv",cue:"cue",cypher:"cypher",cyp:"cypher",d:"d",dart:"dart",dax:"dax",desktop:"desktop",diff:"diff",patch:"diff",Dockerfile:"dockerfile",dockerfile:"dockerfile",env:"dotenv",dm:"dream-maker",edge:"edge",el:"emacs-lisp",ex:"elixir",exs:"elixir",elm:"elm",erb:"erb",erl:"erlang",hrl:"erlang",f:"fortran-fixed-form",for:"fortran-fixed-form",fs:"fsharp",fsi:"fsharp",fsx:"fsharp",f03:"f03",f08:"f08",f18:"f18",f77:"f77",f90:"fortran-free-form",f95:"fortran-free-form",fnl:"fennel",fish:"fish",ftl:"ftl",tres:"gdresource",res:"gdresource",gd:"gdscript",gdshader:"gdshader",gs:"genie",feature:"gherkin",COMMIT_EDITMSG:"git-commit","git-rebase-todo":"git-rebase",gjs:"glimmer-js",gleam:"gleam",gts:"glimmer-ts",glsl:"glsl",vert:"glsl",frag:"glsl",shader:"shaderlab",gp:"gnuplot",plt:"gnuplot",gnuplot:"gnuplot",go:"go",graphql:"graphql",gql:"graphql",groovy:"groovy",gvy:"groovy",hack:"hack",haml:"haml",hbs:"handlebars",handlebars:"handlebars",hs:"haskell",lhs:"haskell",hx:"haxe",hcl:"hcl",hjson:"hjson",hlsl:"hlsl",fx:"hlsl",html:"html",htm:"html",http:"http",rest:"http",hxml:"hxml",hy:"hy",imba:"imba",ini:"ini",cfg:"ini",jade:"pug",pug:"pug",java:"java",js:"javascript",mjs:"javascript",cjs:"javascript",jinja:"jinja",jinja2:"jinja",j2:"jinja",jison:"jison",jl:"julia",json:"json",json5:"json5",jsonc:"jsonc",jsonl:"jsonl",jsonnet:"jsonnet",libsonnet:"jsonnet",jssm:"jssm",jsx:"jsx",kt:"kotlin",kts:"kts",kql:"kusto",tex:"tex",ltx:"tex",lean:"lean4",less:"less",liquid:"liquid",lit:"lit",ll:"llvm",logo:"logo",lua:"lua",luau:"luau",Makefile:"makefile",mk:"makefile",makefile:"makefile",md:"markdown",markdown:"markdown",marko:"marko",m:"wolfram",mat:"matlab",mdc:"mdc",mdx:"mdx",wiki:"wikitext",mediawiki:"wikitext",mmd:"mermaid",mermaid:"mermaid",mips:"mipsasm",mojo:"mojo","🔥":"mojo",move:"move",nar:"narrat",nf:"nextflow",nim:"nim",nims:"nim",nimble:"nim",nix:"nix",nu:"nushell",mm:"objective-cpp",ml:"ocaml",mli:"ocaml",mll:"ocaml",mly:"ocaml",pas:"pascal",p:"pascal",pl:"prolog",pm:"perl",t:"perl",raku:"raku",p6:"raku",pl6:"raku",php:"php",phtml:"php",pls:"plsql",sql:"sql",po:"po",polar:"polar",pcss:"postcss",pot:"pot",potx:"potx",pq:"powerquery",pqm:"powerquery",ps1:"powershell",psm1:"powershell",psd1:"powershell",prisma:"prisma",pro:"prolog",P:"prolog",properties:"properties",proto:"protobuf",pp:"puppet",purs:"purescript",py:"python",pyw:"python",pyi:"python",qml:"qml",qmldir:"qmldir",qss:"qss",r:"r",R:"r",rkt:"racket",rktl:"racket",razor:"razor",cshtml:"razor",rb:"ruby",rbw:"ruby",reg:"reg",regex:"regexp",rel:"rel",rs:"rust",rst:"rst",rake:"ruby",gemspec:"ruby",sas:"sas",sass:"sass",scala:"scala",sc:"scala",scm:"scheme",ss:"scheme",sld:"scheme",scss:"scss",sdbl:"sdbl",shadergraph:"shader",st:"smalltalk",sol:"solidity",sparql:"sparql",rq:"sparql",spl:"splunk",config:"ssh-config",do:"stata",ado:"stata",dta:"stata",styl:"stylus",stylus:"stylus",svelte:"svelte",swift:"swift",sv:"system-verilog",svh:"system-verilog",service:"systemd",socket:"systemd",device:"systemd",timer:"systemd",talon:"talonscript",tasl:"tasl",tcl:"tcl",templ:"templ",tf:"tf",tfvars:"tfvars",toml:"toml",ts:"typescript",tsp:"typespec",tsv:"tsv",tsx:"tsx",ttl:"turtle",twig:"twig",typ:"typst",vv:"v",vala:"vala",vapi:"vala",vb:"vb",vbs:"vb",bas:"vb",vh:"verilog",vhd:"vhdl",vhdl:"vhdl",vim:"vimscript",vue:"vue","vine.ts":"vue-vine",vy:"vyper",wasm:"wasm",wat:"wasm",wy:"文言",wgsl:"wgsl",wit:"wit",wl:"wolfram",nb:"wolfram",xml:"xml",xsl:"xsl",xslt:"xsl",yaml:"yaml",yml:"yml",zs:"zenscript",zig:"zig",zsh:"zsh",sty:"tex"};function oe(e){if(le.has(e))return le.get(e)??"text";if(pe[e]!=null)return pe[e];const t=e.match(/\.([^/\\]+\.[^/\\]+)$/);if(t!=null){if(le.has(t[1]))return le.get(t[1])??"text";if(pe[t[1]]!=null)return pe[t[1]]??"text"}const n=e.match(/\.([^.]+)$/)?.[1]??"";return le.has(n)?le.get(n)??"text":pe[n]??"text"}function ce(e){return e.replace(/\n$|\r\n$/,"")}function Y(e){return{type:"text",value:e}}function A({tagName:e,children:t=[],properties:n={}}){return{type:"element",tagName:e,properties:n,children:t}}function Ie({name:e,width:t=16,height:n=16,properties:i}){return A({tagName:"svg",properties:{width:t,height:n,viewBox:"0 0 16 16",...i},children:[A({tagName:"use",properties:{href:`#${e.replace(/^#/,"")}`}})]})}function $n(e){let t=e.children[0];for(;t!=null;){if(t.type==="element"&&t.tagName==="code")return t;"children"in t?t=t.children[0]:t=null}}function ke(e){return A({tagName:"div",properties:{"data-gutter":""},children:e})}function Vn(e,t,n,i={}){return A({tagName:"div",properties:{"data-line-type":e,"data-column-number":t,"data-line-index":n,...i},children:t!=null?[A({tagName:"span",properties:{"data-line-number-content":""},children:[Y(`${t}`)]})]:void 0})}function G(e,t,n){return A({tagName:"div",properties:{"data-gutter-buffer":t,"data-buffer-size":n,"data-line-type":t==="annotation"?void 0:e,style:t==="annotation"?`grid-row: span ${n};`:`grid-row: span ${n};min-height:calc(${n} * 1lh);`}})}function Bn(e,t,n){const i=typeof n.lineInfo=="function"?n.lineInfo(t):n.lineInfo[t-1];if(i==null){const r=`processLine: line ${t}, contains no state.lineInfo`;throw console.error(r,{node:e,line:t,state:n}),new Error(r)}return e.tagName="div",e.properties["data-line"]=i.lineNumber,e.properties["data-alt-line"]=i.altLineNumber,e.properties["data-line-type"]=i.type,e.properties["data-line-index"]=i.lineIndex,e.children.length===0&&e.children.push(Y(`
`)),e}const xe=Symbol("no-token"),Ue=Symbol("multiple-tokens");function Bt(e){const t=Wn(e);if(t!=null)return t;let n=xe;const i=[];let r=[],o;const s=()=>{if(r.length===0||o==null){r=[],o=void 0;return}if(r.length===1){const a=r[0];if(a?.type==="element"){Gn(a,o);for(const d of a.children)Te(d)}else Te(a);i.push(a),r=[],o=void 0;return}for(const a of r)Te(a);i.push(A({tagName:"span",properties:{"data-char":o},children:r})),r=[],o=void 0},l=a=>{if(a!==xe){if(a===Ue){n=Ue;return}if(n===xe){n=a;return}n!==a&&(n=Ue)}};for(const a of e.children){const d=a.type==="element"?Bt(a):xe;if(l(d),typeof d!="number"){s(),i.push(a);continue}o!=null&&o!==d&&s(),o??=d,r.push(a)}return s(),e.children=i,n}function Wn(e){const t=e.properties["data-char"];if(typeof t=="number")return t}function Te(e){if(e.type==="element"){e.properties["data-char"]=void 0;for(const t of e.children)Te(t)}}function Gn(e,t){e.properties["data-char"]=t}function jn(e={}){const{classPrefix:t="__shiki_",classSuffix:n="",classReplacer:i=l=>l}=e,r=new Map;function o(l){return Object.entries(l).map(([a,d])=>`${a}:${d}`).join(";")}function s(l){const a=typeof l=="string"?l:o(l);let d=t+qn(a)+n;return d=i(d),r.has(d)||r.set(d,typeof l=="string"?l:{...l}),d}return{name:"@shikijs/transformers:style-to-class",pre(l){if(!l.properties.style)return;const a=s(l.properties.style);delete l.properties.style,this.addClassToHast(l,a)},tokens(l){for(const a of l)for(const d of a){if(!d.htmlStyle)continue;const f=s(d.htmlStyle);d.htmlStyle={},d.htmlAttrs||={},d.htmlAttrs.class?d.htmlAttrs.class+=` ${f}`:d.htmlAttrs.class=f}},getClassRegistry(){return r},getCSS(){let l="";for(const[a,d]of r.entries())l+=`.${a}{${typeof d=="string"?d:o(d)}}`;return l},clearRegistry(){r.clear()}}}function qn(e,t=0){let n=3735928559^t,i=1103547991^t;for(let r=0,o;r<e.length;r++)o=e.charCodeAt(r),n=Math.imul(n^o,2654435761),i=Math.imul(i^o,1597334677);return n=Math.imul(n^n>>>16,2246822507),n^=Math.imul(i^i>>>13,3266489909),i=Math.imul(i^i>>>16,2246822507),i^=Math.imul(n^n>>>13,3266489909),(4294967296*(2097151&i)+(n>>>0)).toString(36).slice(0,6)}function Kn(e=!1,t=!1){const n={lineInfo:[]},i=[{line(r){return delete r.properties.class,r},pre(r){const o=$n(r),s=[];if(o!=null){let l=1;for(const a of o.children)a.type==="element"&&(e&&Bt(a),s.push(Bn(a,l,n)),l++);o.children=s}return r},...e?{tokens(r){for(const o of r){let s=0;for(const l of o){const a=l;a.__lineChar??=s,s+=l.content.length}}},preprocess(r,o){o.mergeWhitespaces="never"},span(r,o,s,l,a){if(a?.offset!=null&&a.content!=null){const d=a.__lineChar;return d!=null&&(r.properties["data-char"]=d),r}return r}}:null}];return t&&i.push(Xn,ct),{state:n,transformers:i,toClass:ct}}const ct=jn({classPrefix:"hl-"}),Xn={name:"token-style-normalizer",tokens(e){for(const t of e)for(const n of t){if(n.htmlStyle!=null)continue;const i={};n.color!=null&&(i.color=n.color),n.bgColor!=null&&(i["background-color"]=n.bgColor),n.fontStyle!=null&&n.fontStyle!==0&&((n.fontStyle&1)!==0&&(i["font-style"]="italic"),(n.fontStyle&2)!==0&&(i["font-weight"]="bold"),(n.fontStyle&4)!==0&&(i["text-decoration"]="underline")),Object.keys(i).length>0&&(n.htmlStyle=i)}}};function j(e){return`--${e==="token"?"diffs-token":"diffs"}-`}function Jn({theme:e=J,highlighter:t,prefix:n}){let i="";if(typeof e=="string"){const r=t.getTheme(e);i+=`color:${r.fg};`,i+=`background-color:${r.bg};`,i+=`${j("global")}fg:${r.fg};`,i+=`${j("global")}bg:${r.bg};`,i+=ze(r,n)}else{let r=t.getTheme(e.dark);i+=`${j("global")}dark:${r.fg};`,i+=`${j("global")}dark-bg:${r.bg};`,i+=ze(r,"dark"),r=t.getTheme(e.light),i+=`${j("global")}light:${r.fg};`,i+=`${j("global")}light-bg:${r.bg};`,i+=ze(r,"light")}return i}function ze(e,t){t=t!=null?`${t}-`:"";let n="";const i=e.colors?.["gitDecoration.addedResourceForeground"]??e.colors?.["terminal.ansiGreen"];i!=null&&(n+=`${j("global")}${t}addition-color:${i};`);const r=e.colors?.["gitDecoration.deletedResourceForeground"]??e.colors?.["terminal.ansiRed"];r!=null&&(n+=`${j("global")}${t}deletion-color:${r};`);const o=e.colors?.["gitDecoration.modifiedResourceForeground"]??e.colors?.["terminal.ansiBlue"];return o!=null&&(n+=`${j("global")}${t}modified-color:${o};`),n}function ut(e){let t=e.children[0];for(;t!=null;){if(t.type==="element"&&t.tagName==="code")return t.children;"children"in t?t=t.children[0]:t=null}throw console.error(e),new Error("getLineNodes: Unable to find children")}function ht(e,t){return e?.cacheKey===t?.cacheKey&&e?.contents===t?.contents&&e?.name===t?.name&&e?.lang===t?.lang}function Fe(e,t){return Vt(e.theme,t.theme)&&e.useTokenTransformer===t.useTokenTransformer&&e.tokenizeMaxLineLength===t.tokenizeMaxLineLength&&e.lineDiffType===t.lineDiffType&&e.maxLineDiffLength===t.maxLineDiffLength}function Yn(e){const t=e.lang??oe(e.name),n=e.lang??(e.prevName!=null?oe(e.prevName):"text");return t==="text"&&n==="text"}function Re({diff:e,diffStyle:t,startingLine:n=0,totalLines:i=1/0,expandedHunks:r,collapsedContextThreshold:o=fe,callback:s}){const l={finalHunk:e.hunks.at(-1),viewportStart:n,viewportEnd:n+i,isWindowedHighlight:n>0||i<1/0,splitCount:0,unifiedCount:0,shouldBreak(){if(!l.isWindowedHighlight)return!1;const a=l.unifiedCount>=n+i,d=l.splitCount>=n+i;return t==="unified"?a:(t==="split"||a)&&d},shouldSkip(a,d){if(!l.isWindowedHighlight)return!1;const f=l.unifiedCount+a<n,c=l.splitCount+d<n;return t==="unified"?f:(t==="split"||f)&&c},incrementCounts(a,d){(t==="unified"||t==="both")&&(l.unifiedCount+=a),(t==="split"||t==="both")&&(l.splitCount+=d)},isInWindow(a,d){if(!l.isWindowedHighlight)return!0;const f=l.isInUnifiedWindow(a),c=l.isInSplitWindow(d);return t==="unified"?f:t==="split"?c:f||c},isInUnifiedWindow(a){return!l.isWindowedHighlight||l.unifiedCount>=n-a&&l.unifiedCount<n+i},isInSplitWindow(a){return!l.isWindowedHighlight||l.splitCount>=n-a&&l.splitCount<n+i},emit(a,d=!1){return d||(t==="unified"?l.incrementCounts(1,0):t==="split"?l.incrementCounts(0,1):l.incrementCounts(1,1)),s(a)??!1}};e:for(const[a,d]of e.hunks.entries()){let u=function(g,k){return c==null||c.collapsedLines<=0||c.fromStart+c.fromEnd>0?0:t==="unified"?g===d.unifiedLineStart+d.unifiedLineCount-1?c.collapsedLines:0:k===d.splitLineStart+d.splitLineCount-1?c.collapsedLines:0},p=function(){if(f.collapsedLines===0)return 0;const g=f.collapsedLines;return f.collapsedLines=0,g};if(l.shouldBreak())break;const f=pt(e.isPartial,d.collapsedBefore,r,a,o),c=(()=>{if(d!==l.finalHunk||!Zn(e))return;const g=e.additionLines.length-(d.additionLineIndex+d.additionCount),k=e.deletionLines.length-(d.deletionLineIndex+d.deletionCount);if(g!==k)throw new Error(`iterateOverDiff: trailing context mismatch (additions=${g}, deletions=${k}) for ${e.name}`);const L=Math.min(g,k);return pt(e.isPartial,L,r,e.hunks.length,o)})(),h=f.fromStart+f.fromEnd;if(l.shouldSkip(h,h))l.incrementCounts(h,h),p();else{let g=d.unifiedLineStart-f.rangeSize,k=d.splitLineStart-f.rangeSize,L=d.deletionLineIndex-f.rangeSize,E=d.additionLineIndex-f.rangeSize,T=d.deletionStart-f.rangeSize,_=d.additionStart-f.rangeSize,I=0;for(;I<f.fromStart;){if(l.isInWindow(0,0)){if(l.emit({hunkIndex:a,hunk:d,collapsedBefore:0,collapsedAfter:0,type:"context-expanded",deletionLine:{lineNumber:T+I,lineIndex:L+I,noEOFCR:!1,unifiedLineIndex:g+I,splitLineIndex:k+I},additionLine:{unifiedLineIndex:g+I,splitLineIndex:k+I,lineIndex:E+I,lineNumber:_+I,noEOFCR:!1}}))break e}else l.incrementCounts(1,1);I++}for(g=d.unifiedLineStart-f.fromEnd,k=d.splitLineStart-f.fromEnd,L=d.deletionLineIndex-f.fromEnd,E=d.additionLineIndex-f.fromEnd,T=d.deletionStart-f.fromEnd,_=d.additionStart-f.fromEnd,I=0;I<f.fromEnd;){if(l.isInWindow(0,0)){if(l.emit({hunkIndex:a,hunk:d,collapsedBefore:p(),collapsedAfter:0,type:"context-expanded",deletionLine:{lineNumber:T+I,lineIndex:L+I,noEOFCR:!1,unifiedLineIndex:g+I,splitLineIndex:k+I},additionLine:{unifiedLineIndex:g+I,splitLineIndex:k+I,lineIndex:E+I,lineNumber:_+I,noEOFCR:!1}}))break e}else l.incrementCounts(1,1);I++}}let y=d.unifiedLineStart,x=d.splitLineStart,C=d.deletionLineIndex,m=d.additionLineIndex,b=d.deletionStart,v=d.additionStart;const S=d.hunkContent.at(-1);for(const g of d.hunkContent){if(l.shouldBreak())break e;const k=g===S;if(g.type==="context"){if(l.shouldSkip(g.lines,g.lines))l.incrementCounts(g.lines,g.lines),p();else{let L=0;for(;L<g.lines;){if(l.isInWindow(0,0)){const E=k&&L===g.lines-1,T=y+L,_=x+L;if(l.emit({hunkIndex:a,hunk:d,collapsedBefore:p(),collapsedAfter:u(T,_),type:"context",deletionLine:{lineNumber:b+L,lineIndex:C+L,noEOFCR:E&&d.noEOFCRDeletions,unifiedLineIndex:T,splitLineIndex:_},additionLine:{unifiedLineIndex:T,splitLineIndex:_,lineIndex:m+L,lineNumber:v+L,noEOFCR:E&&d.noEOFCRAdditions}}))break e}else l.incrementCounts(1,1);L++}}y+=g.lines,x+=g.lines,C+=g.lines,m+=g.lines,b+=g.lines,v+=g.lines}else{const L=Math.max(g.deletions,g.additions),E=g.deletions+g.additions;if(!l.shouldSkip(E,L)){const T=Qn(l,g,t);for(const[_,I]of T)for(let R=_;R<I;R++){const z=u(y+R,t==="unified"?x+(R<g.deletions?R:R-g.deletions):x+R);if(l.emit(ei({hunkIndex:a,hunk:d,collapsedBefore:p(),collapsedAfter:z,diffStyle:t,index:R,unifiedLineIndex:y,splitLineIndex:x,additionLineIndex:m,deletionLineIndex:C,additionLineNumber:v,deletionLineNumber:b,content:g,isLastContent:k,unifiedCount:E,splitCount:L}),!0))break e}}p(),l.incrementCounts(E,L),y+=E,x+=L,C+=g.deletions,m+=g.additions,b+=g.deletions,v+=g.additions}}if(c!=null){const{collapsedLines:g,fromStart:k,fromEnd:L}=c,E=k+L;let T=0;for(;T<E;){if(l.shouldBreak())break e;if(l.isInWindow(0,0)){const _=T===E-1;if(l.emit({hunkIndex:e.hunks.length,hunk:void 0,collapsedBefore:0,collapsedAfter:_?g:0,type:"context-expanded",deletionLine:{lineNumber:b+T,lineIndex:C+T,noEOFCR:!1,unifiedLineIndex:y+T,splitLineIndex:x+T},additionLine:{unifiedLineIndex:y+T,splitLineIndex:x+T,lineIndex:m+T,lineNumber:v+T,noEOFCR:!1}}))break e}else l.incrementCounts(1,1);T++}}}}function pt(e,t,n,i,r){if(t=Math.max(t,0),t===0||e)return{fromStart:0,fromEnd:0,rangeSize:t,collapsedLines:Math.max(t,0)};if(n===!0||t<=r)return{fromStart:t,fromEnd:0,rangeSize:t,collapsedLines:0};const o=n?.get(i),s=Math.min(Math.max(o?.fromStart??0,0),t),l=Math.min(Math.max(o?.fromEnd??0,0),t),a=s+l,d=a>=t;return{fromStart:d?t:s,fromEnd:d?0:l,rangeSize:t,collapsedLines:Math.max(t-a,0)}}function Zn(e){const t=e.hunks.at(-1);return t==null||e.isPartial||e.additionLines.length===0||e.deletionLines.length===0?!1:t.additionLineIndex+t.additionCount<e.additionLines.length||t.deletionLineIndex+t.deletionCount<e.deletionLines.length}function Qn(e,t,n){if(!e.isWindowedHighlight)return[[0,n==="unified"?t.deletions+t.additions:Math.max(t.deletions,t.additions)]];const i=n!=="split",r=n!=="unified",o=n==="unified"?"unified":"split",s=[];function l(c,h){if(c+h<=e.viewportStart||c>=e.viewportEnd)return;const u=Math.max(0,e.viewportStart-c),p=Math.min(h,e.viewportEnd-c);return p>u?[u,p]:void 0}function a(c,h){return o==="split"?c:h==="additions"?[c[0]+t.deletions,c[1]+t.deletions]:c}function d(c,h){if(c==null)return;const[u,p]=a(c,h);p>u&&s.push([u,p])}if(i&&(d(l(e.unifiedCount,t.deletions),"deletions"),d(l(e.unifiedCount+t.deletions,t.additions),"additions")),r&&(d(l(e.splitCount,t.deletions),"deletions"),d(l(e.splitCount,t.additions),"additions")),s.length===0)return s;s.sort((c,h)=>c[0]-h[0]);const f=[s[0]];for(const[c,h]of s.slice(1)){const u=f[f.length-1];c<=u[1]?u[1]=Math.max(u[1],h):f.push([c,h])}return f}function ei({hunkIndex:e,hunk:t,collapsedAfter:n,collapsedBefore:i,diffStyle:r,index:o,unifiedLineIndex:s,splitLineIndex:l,additionLineIndex:a,deletionLineIndex:d,additionLineNumber:f,deletionLineNumber:c,content:h,isLastContent:u,unifiedCount:p,splitCount:y}){const x=o<h.deletions?s+o:void 0,C=r==="unified"?o>=h.deletions?s+o:void 0:o<h.additions?s+h.deletions+o:void 0,m=r==="unified"?l+(o<h.deletions?o:o-h.deletions):l+o,b=o<h.deletions?d+o:void 0,v=o<h.deletions?c+o:void 0,S=r==="unified"?o>=h.deletions?a+(o-h.deletions):void 0:o<h.additions?a+o:void 0,g=r==="unified"?o>=h.deletions?f+(o-h.deletions):void 0:o<h.additions?f+o:void 0,k=r==="unified"?u&&o===h.deletions-1&&t.noEOFCRDeletions:u&&o===y-1&&t.noEOFCRDeletions,L=r==="unified"?u&&o===p-1&&t.noEOFCRAdditions:u&&o===y-1&&t.noEOFCRAdditions,E=b!=null&&v!=null&&x!=null?{lineNumber:v,lineIndex:b,noEOFCR:k,unifiedLineIndex:x,splitLineIndex:m}:void 0,T=S!=null&&g!=null&&C!=null?{unifiedLineIndex:C,splitLineIndex:m,lineIndex:S,lineNumber:g,noEOFCR:L}:void 0;if(E==null&&T!=null)return{type:"change",hunkIndex:e,hunk:t,collapsedAfter:n,collapsedBefore:i,deletionLine:void 0,additionLine:T};if(E!=null&&T==null)return{type:"change",hunkIndex:e,hunk:t,collapsedAfter:n,collapsedBefore:i,deletionLine:E,additionLine:void 0};if(E==null||T==null)throw new Error("iterateOverDiff: missing change line data");return{type:"change",hunkIndex:e,hunk:t,collapsedAfter:n,collapsedBefore:i,deletionLine:E,additionLine:T}}class ot{diff(t,n,i={}){let r;typeof i=="function"?(r=i,i={}):"callback"in i&&(r=i.callback);const o=this.castInput(t,i),s=this.castInput(n,i),l=this.removeEmpty(this.tokenize(o,i)),a=this.removeEmpty(this.tokenize(s,i));return this.diffWithOptionsObj(l,a,i,r)}diffWithOptionsObj(t,n,i,r){var o;const s=m=>{if(m=this.postProcess(m,i),r){setTimeout(function(){r(m)},0);return}else return m},l=n.length,a=t.length;let d=1,f=l+a;i.maxEditLength!=null&&(f=Math.min(f,i.maxEditLength));const c=(o=i.timeout)!==null&&o!==void 0?o:1/0,h=Date.now()+c,u=[{oldPos:-1,lastComponent:void 0}];let p=this.extractCommon(u[0],n,t,0,i);if(u[0].oldPos+1>=a&&p+1>=l)return s(this.buildValues(u[0].lastComponent,n,t));let y=-1/0,x=1/0;const C=()=>{for(let m=Math.max(y,-d);m<=Math.min(x,d);m+=2){let b;const v=u[m-1],S=u[m+1];v&&(u[m-1]=void 0);let g=!1;if(S){const L=S.oldPos-m;g=S&&0<=L&&L<l}const k=v&&v.oldPos+1<a;if(!g&&!k){u[m]=void 0;continue}if(!k||g&&v.oldPos<S.oldPos?b=this.addToPath(S,!0,!1,0,i):b=this.addToPath(v,!1,!0,1,i),p=this.extractCommon(b,n,t,m,i),b.oldPos+1>=a&&p+1>=l)return s(this.buildValues(b.lastComponent,n,t))||!0;u[m]=b,b.oldPos+1>=a&&(x=Math.min(x,m-1)),p+1>=l&&(y=Math.max(y,m+1))}d++};if(r)(function m(){setTimeout(function(){if(d>f||Date.now()>h)return r(void 0);C()||m()},0)})();else for(;d<=f&&Date.now()<=h;){const m=C();if(m)return m}}addToPath(t,n,i,r,o){const s=t.lastComponent;return s&&!o.oneChangePerToken&&s.added===n&&s.removed===i?{oldPos:t.oldPos+r,lastComponent:{count:s.count+1,added:n,removed:i,previousComponent:s.previousComponent}}:{oldPos:t.oldPos+r,lastComponent:{count:1,added:n,removed:i,previousComponent:s}}}extractCommon(t,n,i,r,o){const s=n.length,l=i.length;let a=t.oldPos,d=a-r,f=0;for(;d+1<s&&a+1<l&&this.equals(i[a+1],n[d+1],o);)d++,a++,f++,o.oneChangePerToken&&(t.lastComponent={count:1,previousComponent:t.lastComponent,added:!1,removed:!1});return f&&!o.oneChangePerToken&&(t.lastComponent={count:f,previousComponent:t.lastComponent,added:!1,removed:!1}),t.oldPos=a,d}equals(t,n,i){return i.comparator?i.comparator(t,n):t===n||!!i.ignoreCase&&t.toLowerCase()===n.toLowerCase()}removeEmpty(t){const n=[];for(let i=0;i<t.length;i++)t[i]&&n.push(t[i]);return n}castInput(t,n){return t}tokenize(t,n){return Array.from(t)}join(t){return t.join("")}postProcess(t,n){return t}get useLongestToken(){return!1}buildValues(t,n,i){const r=[];let o;for(;t;)r.push(t),o=t.previousComponent,delete t.previousComponent,t=o;r.reverse();const s=r.length;let l=0,a=0,d=0;for(;l<s;l++){const f=r[l];if(f.removed)f.value=this.join(i.slice(d,d+f.count)),d+=f.count;else{if(!f.added&&this.useLongestToken){let c=n.slice(a,a+f.count);c=c.map(function(h,u){const p=i[d+u];return p.length>h.length?p:h}),f.value=this.join(c)}else f.value=this.join(n.slice(a,a+f.count));a+=f.count,f.added||(d+=f.count)}}return r}}class ti extends ot{}const ni=new ti;function ii(e,t,n){return ni.diff(e,t,n)}const mt="a-zA-Z0-9_\\u{AD}\\u{C0}-\\u{D6}\\u{D8}-\\u{F6}\\u{F8}-\\u{2C6}\\u{2C8}-\\u{2D7}\\u{2DE}-\\u{2FF}\\u{1E00}-\\u{1EFF}";class ri extends ot{tokenize(t){const n=new RegExp(`(\\r?\\n)|[${mt}]+|[^\\S\\n\\r]+|[^${mt}]`,"ug");return t.match(n)||[]}}const oi=new ri;function ai(e,t,n){return oi.diff(e,t,n)}class si extends ot{constructor(){super(...arguments),this.tokenize=di}equals(t,n,i){return i.ignoreWhitespace?((!i.newlineIsToken||!t.includes(`
`))&&(t=t.trim()),(!i.newlineIsToken||!n.includes(`
`))&&(n=n.trim())):i.ignoreNewlineAtEof&&!i.newlineIsToken&&(t.endsWith(`
`)&&(t=t.slice(0,-1)),n.endsWith(`
`)&&(n=n.slice(0,-1))),super.equals(t,n,i)}}const li=new si;function gt(e,t,n){return li.diff(e,t,n)}function di(e,t){t.stripTrailingCr&&(e=e.replace(/\r\n/g,`
`));const n=[],i=e.split(/(\n|\r\n)/);i[i.length-1]||i.pop();for(let r=0;r<i.length;r++){const o=i[r];r%2&&!t.newlineIsToken?n[n.length-1]+=o:n.push(o)}return n}const fi={includeIndex:!0,includeUnderline:!0,includeFileHeaders:!0};function bt(e,t,n,i,r,o,s){let l;s?typeof s=="function"?l={callback:s}:l=s:l={},typeof l.context>"u"&&(l.context=4);const a=l.context;if(l.newlineIsToken)throw new Error("newlineIsToken may not be used with patch-generation functions, only with diffing functions");if(l.callback){const{callback:f}=l;gt(n,i,Object.assign(Object.assign({},l),{callback:c=>{const h=d(c);f(h)}}))}else return d(gt(n,i,l));function d(f){if(!f)return;f.push({value:"",lines:[]});function c(m){return m.map(function(b){return" "+b})}const h=[];let u=0,p=0,y=[],x=1,C=1;for(let m=0;m<f.length;m++){const b=f[m],v=b.lines||ui(b.value);if(b.lines=v,b.added||b.removed){if(!u){const S=f[m-1];u=x,p=C,S&&(y=a>0?c(S.lines.slice(-a)):[],u-=y.length,p-=y.length)}for(const S of v)y.push((b.added?"+":"-")+S);b.added?C+=v.length:x+=v.length}else{if(u)if(v.length<=a*2&&m<f.length-2)for(const S of c(v))y.push(S);else{const S=Math.min(v.length,a);for(const k of c(v.slice(0,S)))y.push(k);const g={oldStart:u,oldLines:x-u+S,newStart:p,newLines:C-p+S,lines:y};h.push(g),u=0,p=0,y=[]}x+=v.length,C+=v.length}}for(const m of h)for(let b=0;b<m.lines.length;b++)m.lines[b].endsWith(`
`)?m.lines[b]=m.lines[b].slice(0,-1):(m.lines.splice(b+1,0,"\\ No newline at end of file"),b++);return{oldFileName:e,newFileName:t,oldHeader:r,newHeader:o,hunks:h}}}function Ze(e,t){if(t||(t=fi),Array.isArray(e)){if(e.length>1&&!t.includeFileHeaders)throw new Error("Cannot omit file headers on a multi-file patch. (The result would be unparseable; how would a tool trying to apply the patch know which changes are to which file?)");return e.map(i=>Ze(i,t)).join(`
`)}const n=[];t.includeIndex&&e.oldFileName==e.newFileName&&n.push("Index: "+e.oldFileName),t.includeUnderline&&n.push("==================================================================="),t.includeFileHeaders&&(n.push("--- "+e.oldFileName+(typeof e.oldHeader>"u"?"":"	"+e.oldHeader)),n.push("+++ "+e.newFileName+(typeof e.newHeader>"u"?"":"	"+e.newHeader)));for(let i=0;i<e.hunks.length;i++){const r=e.hunks[i];r.oldLines===0&&(r.oldStart-=1),r.newLines===0&&(r.newStart-=1),n.push("@@ -"+r.oldStart+","+r.oldLines+" +"+r.newStart+","+r.newLines+" @@");for(const o of r.lines)n.push(o)}return n.join(`
`)+`
`}function ci(e,t,n,i,r,o,s){if(typeof s=="function"&&(s={callback:s}),s?.callback){const{callback:l}=s;bt(e,t,n,i,r,o,Object.assign(Object.assign({},s),{callback:a=>{l(a?Ze(a,s.headerOptions):void 0)}}))}else{const l=bt(e,t,n,i,r,o,s);return l?Ze(l,s?.headerOptions):void 0}}function ui(e){const t=e.endsWith(`
`),n=e.split(`
`).map(i=>i+`
`);return t?n.pop():n.push(n.pop().slice(0,-1)),n}function vt({line:e,spanStart:t,spanLength:n}){return{start:{line:e,character:t},end:{line:e,character:t+n},properties:{"data-diff-span":""},alwaysWrap:!0}}function Se({item:e,arr:t,enableJoin:n,isNeutral:i=!1,isLastItem:r=!1}){const o=t[t.length-1];if(o==null||r||!n){t.push([i?0:1,e.value]);return}const s=o[0]===0;if(i===s||i&&e.value.length===1&&!s){o[1]+=e.value;return}t.push([i?0:1,e.value])}const hi={forcePlainText:!1};function pi(e,t,n,{forcePlainText:i,startingLine:r,totalLines:o,expandedHunks:s,collapsedContextThreshold:l=fe}=hi){i?(r??=0,o??=1/0):(r=0,o=1/0);const a=r>0||o<1/0,d=typeof n.theme=="string"?t.getTheme(n.theme).type:void 0,f=Jn({theme:n.theme,highlighter:t}),c=i&&!a&&(e.unifiedLineCount>1e3||e.splitLineCount>1e3)?"none":n.lineDiffType,h={deletionLines:[],additionLines:[]},{maxLineDiffLength:u}=n,p=!i&&!e.isPartial,y=i?s:void 0,x=new Map;function C(b){const v=p?0:b,S=x.get(v)??gi();return x.set(v,S),S}function m(b,v,S,g){if(a){let k=S.at(-1);(k==null||k.targetIndex+k.count!==v)&&(k={targetIndex:v,originalOffset:g.length,count:0},S.push(k)),k.count++}g.push(b)}Re({diff:e,diffStyle:"both",startingLine:r,totalLines:o,expandedHunks:a?y:!0,collapsedContextThreshold:l,callback:({hunkIndex:b,additionLine:v,deletionLine:S,type:g})=>{const k=C(b),L=v!=null?v.splitLineIndex:S.splitLineIndex;g==="change"&&v!=null&&S!=null&&mi({additionLine:e.additionLines[v.lineIndex],deletionLine:e.deletionLines[S.lineIndex],deletionLineIndex:k.deletionContent.length,additionLineIndex:k.additionContent.length,deletionDecorations:k.deletionDecorations,additionDecorations:k.additionDecorations,lineDiffType:c,maxLineDiffLength:u}),S!=null&&(m(e.deletionLines[S.lineIndex],S.lineIndex,k.deletionSegments,k.deletionContent),k.deletionInfo.push({type:g==="change"?"change-deletion":g,lineNumber:S.lineNumber,altLineNumber:g==="change"?void 0:v.lineNumber??void 0,lineIndex:`${S.unifiedLineIndex},${L}`})),v!=null&&(m(e.additionLines[v.lineIndex],v.lineIndex,k.additionSegments,k.additionContent),k.additionInfo.push({type:g==="change"?"change-addition":g,lineNumber:v.lineNumber,altLineNumber:g==="change"?void 0:S.lineNumber??void 0,lineIndex:`${v.unifiedLineIndex},${L}`}))}});for(const b of x.values()){if(b.deletionContent.length===0&&b.additionContent.length===0)continue;const v={name:e.prevName??e.name,contents:b.deletionContent.value},S={name:e.name,contents:b.additionContent.value},{deletionLines:g,additionLines:k}=bi({deletionFile:v,deletionInfo:b.deletionInfo,deletionDecorations:b.deletionDecorations,additionFile:S,additionInfo:b.additionInfo,additionDecorations:b.additionDecorations,highlighter:t,options:n,languageOverride:i?"text":e.lang});if(p){h.deletionLines=g,h.additionLines=k;continue}if(b.deletionSegments.length>0)for(const L of b.deletionSegments)for(let E=0;E<L.count;E++)h.deletionLines[L.targetIndex+E]=g[L.originalOffset+E];else h.deletionLines.push(...g);if(b.additionSegments.length>0)for(const L of b.additionSegments)for(let E=0;E<L.count;E++)h.additionLines[L.targetIndex+E]=k[L.originalOffset+E];else h.additionLines.push(...k)}return{code:h,themeStyles:f,baseThemeType:d}}function mi({deletionLine:e,additionLine:t,deletionLineIndex:n,additionLineIndex:i,deletionDecorations:r,additionDecorations:o,lineDiffType:s,maxLineDiffLength:l}){if(e==null||t==null||s==="none"||(e=ce(e),t=ce(t),e.length>l||t.length>l))return;const a=s==="char"?ii(e,t):ai(e,t),d=[],f=[],c=s==="word-alt",h=a.at(-1);for(const p of a){const y=p===h;!p.added&&!p.removed?(Se({item:p,arr:d,enableJoin:c,isNeutral:!0,isLastItem:y}),Se({item:p,arr:f,enableJoin:c,isNeutral:!0,isLastItem:y})):p.removed?Se({item:p,arr:d,enableJoin:c,isLastItem:y}):Se({item:p,arr:f,enableJoin:c,isLastItem:y})}let u=0;for(const p of d)p[0]===1&&r.push(vt({line:n,spanStart:u,spanLength:p[1].length})),u+=p[1].length;u=0;for(const p of f)p[0]===1&&o.push(vt({line:i,spanStart:u,spanLength:p[1].length})),u+=p[1].length}function gi(){return{deletionContent:{push(e){this.value+=e,this.length++},value:"",length:0},additionContent:{push(e){this.value+=e,this.length++},value:"",length:0},deletionInfo:[],additionInfo:[],deletionDecorations:[],additionDecorations:[],deletionSegments:[],additionSegments:[]}}function bi({deletionFile:e,additionFile:t,deletionInfo:n,additionInfo:i,highlighter:r,deletionDecorations:o,additionDecorations:s,languageOverride:l,options:{theme:a=J,...d}}){const f=l??oe(e.name),c=l??oe(t.name),{state:h,transformers:u}=Kn(d.useTokenTransformer),p=typeof a=="string"?{...d,lang:"text",theme:a,transformers:u,decorations:void 0,defaultColor:!1,cssVariablePrefix:j("token")}:{...d,lang:"text",themes:a,transformers:u,decorations:void 0,defaultColor:!1,cssVariablePrefix:j("token")};return{deletionLines:e.contents===""?[]:(p.lang=f,h.lineInfo=n,p.decorations=o,ut(r.codeToHast(ce(e.contents),p))),additionLines:t.contents===""?[]:(p.lang=c,p.decorations=s,h.lineInfo=i,ut(r.codeToHast(ce(t.contents),p)))}}const vi=B.createContext(void 0);function yi(e){const t=B.useRef(e);return B.useInsertionEffect(()=>{t.current=e}),B.useCallback((...n)=>t.current(...n),[])}function ki(e,t){return e.lineNumber===t.lineNumber&&e.side===t.side}function yt(e,t){return e?.start===t?.start&&e?.end===t?.end&&e?.side===t?.side&&e?.endSide===t?.endSide}function xi(){return A({tagName:"button",properties:{"data-utility-button":"",type:"button"},children:[Ie({name:"diffs-icon-plus",properties:{"data-icon":""}})]})}var Si=class{hoveredLine;hoveredToken;pre;gutterUtilityContainer;gutterUtilityButton;gutterUtilitySlot;interactiveLinesAttr=!1;interactiveLineNumbersAttr=!1;hasPointerListeners=!1;hasDocumentPointerListeners=!1;selectedRange=null;renderedSelectionRange;selectionAnchor;queuedSelectionRender;pointerSession={mode:"idle"};constructor(e,t){this.mode=e,this.options=t}setOptions(e){this.options=e}cleanUp(){this.pre?.removeEventListener("click",this.handlePointerClick),this.pre?.removeEventListener("pointerdown",this.handlePointerDown),this.pre?.removeEventListener("pointermove",this.handlePointerMove),this.pre?.removeEventListener("pointerleave",this.handlePointerLeave),this.pre?.removeAttribute("data-interactive-lines"),this.pre?.removeAttribute("data-interactive-line-numbers"),this.pre=void 0,this.gutterUtilityContainer?.remove(),this.gutterUtilityContainer=void 0,this.gutterUtilityButton=void 0,this.gutterUtilitySlot=void 0,this.clearHoveredLine(),this.clearHoveredToken(),this.detachDocumentPointerListeners(),this.clearPointerSession(),this.queuedSelectionRender!=null&&(cancelAnimationFrame(this.queuedSelectionRender),this.queuedSelectionRender=void 0),this.interactiveLinesAttr=!1,this.interactiveLineNumbersAttr=!1,this.hasPointerListeners=!1}setup(e){this.setSelectionDirty();const{usesCustomGutterUtility:t=!1,enableGutterUtility:n=!1}=this.options;this.pre!==e&&(this.cleanUp(),this.pre=e),n?this.ensureGutterUtilityNode(t):this.gutterUtilityContainer!=null&&(this.gutterUtilityContainer.remove(),this.gutterUtilityContainer=void 0,this.gutterUtilityButton=void 0,this.gutterUtilitySlot=void 0,this.pointerSession.mode==="gutterSelecting"&&(this.clearPointerSession(),this.detachDocumentPointerListeners())),this.syncPointerListeners(e),this.updateInteractiveLineAttributes(),this.renderSelection()}setSelectionDirty(){this.renderedSelectionRange=void 0}isSelectionDirty(){return this.renderedSelectionRange===null}setSelection(e){const t=!(e===this.selectedRange||yt(e??void 0,this.selectedRange??void 0));!this.isSelectionDirty()&&!t||(this.selectedRange=e,this.renderSelection(),t&&this.notifySelectionCommitted())}getSelection(){return this.selectedRange}getHoveredLine=()=>{if(this.hoveredLine!=null){if(this.mode==="diff"&&this.hoveredLine.type==="diff-line")return{lineNumber:this.hoveredLine.lineNumber,side:this.hoveredLine.annotationSide};if(this.mode==="file"&&this.hoveredLine.type==="line")return{lineNumber:this.hoveredLine.lineNumber}}};handlePointerClick=e=>{const{onHunkExpand:t,onLineClick:n,onLineNumberClick:i,onTokenClick:r,onMergeConflictActionClick:o}=this.options;t==null&&n==null&&i==null&&o==null&&r==null||this.options.onGutterUtilityClick!=null&&wt(e.composedPath())||(ee(this.options.__debugPointerEvents,"click","FileDiff.DEBUG.handlePointerClick:",e),this.handlePointerEvent({eventType:"click",event:e}))};handlePointerMove=e=>{const{lineHoverHighlight:t="disabled",onLineEnter:n,onLineLeave:i,onTokenEnter:r,onTokenLeave:o,enableGutterUtility:s=!1}=this.options;t==="disabled"&&!s&&n==null&&i==null&&r==null&&o==null||(ee(this.options.__debugPointerEvents,"move","FileDiff.DEBUG.handlePointerMove:",e),this.handlePointerEvent({eventType:"move",event:e}))};handlePointerLeave=e=>{const{__debugPointerEvents:t}=this.options;if(ee(t,"move","FileDiff.DEBUG.handlePointerLeave: no event"),this.hoveredLine==null&&this.hoveredToken==null){ee(t,"move","FileDiff.DEBUG.handlePointerLeave: returned early, no hovered line or token");return}this.gutterUtilityContainer?.remove(),this.hoveredToken!=null&&(this.options.onTokenLeave?.(this.hoveredToken,e),this.clearHoveredToken()),this.hoveredLine!=null&&(this.options.onLineLeave?.({...this.hoveredLine,event:e}),this.clearHoveredLine())};handlePointerEvent({eventType:e,event:t}){const{__debugPointerEvents:n}=this.options,i=t.composedPath();ee(n,e,"FileDiff.DEBUG.handlePointerEvent:",{eventType:e,composedPath:i});const r=this.resolvePointerTarget(i);ee(n,e,"FileDiff.DEBUG.handlePointerEvent: resolvePointerTarget result:",r);const{onLineClick:o,onLineNumberClick:s,onLineEnter:l,onLineLeave:a,onTokenClick:d,onTokenEnter:f,onTokenLeave:c,onHunkExpand:h,onMergeConflictActionClick:u}=this.options;switch(e){case"move":{const p=$e(r)&&this.hoveredLine?.lineElement===r.lineElement;Ae(r)&&this.hoveredToken?.tokenElement===r.tokenElement||(this.hoveredToken!=null&&(c?.(this.hoveredToken,t),this.clearHoveredToken()),Ae(r)&&(this.setHoveredToken(this.toTokenEventBaseProps(r)),f?.(this.hoveredToken,t))),p||(this.hoveredLine!=null&&(this.gutterUtilityContainer?.remove(),a?.({...this.hoveredLine,event:t}),this.clearHoveredLine()),$e(r)&&(this.setHoveredLine(this.toEventBaseProps(r)),this.gutterUtilityContainer!=null&&r.numberElement.appendChild(this.gutterUtilityContainer),l?.({...this.hoveredLine,event:t})));break}case"click":{if(r==null)break;if(Li(r)&&u!=null){u(r);break}if(wi(r)&&h!=null){h(r.hunkIndex,r.all||t.shiftKey?"both":r.direction,r.all||t.shiftKey?Number.POSITIVE_INFINITY:void 0);break}if(!$e(r))break;Ae(r)&&d!=null&&d(this.toTokenEventBaseProps(r),t);const p=this.toEventBaseProps(r);s!=null&&r.numberColumn?s({...p,event:t}):o?.({...p,event:t});break}}}syncPointerListeners(e){const{__debugPointerEvents:t,lineHoverHighlight:n="disabled",onLineClick:i,onLineNumberClick:r,onLineEnter:o,onLineLeave:s,onTokenClick:l,onTokenEnter:a,onTokenLeave:d,onHunkExpand:f,onMergeConflictActionClick:c,enableGutterUtility:h=!1,enableLineSelection:u=!1,onGutterUtilityClick:p}=this.options,y=p!=null,x=n!=="disabled"||i!=null||r!=null||o!=null||s!=null||l!=null||a!=null||d!=null||f!=null||c!=null||h||u||y;x&&!this.hasPointerListeners?(e.addEventListener("click",this.handlePointerClick),e.addEventListener("pointerdown",this.handlePointerDown),e.addEventListener("pointermove",this.handlePointerMove),e.addEventListener("pointerleave",this.handlePointerLeave),this.hasPointerListeners=!0,ee(t,"click","FileDiff.DEBUG.attachEventListeners: Attaching click events for:",(()=>{const b=[];return(t==="both"||t==="click")&&(i!=null&&b.push("onLineClick"),r!=null&&b.push("onLineNumberClick"),f!=null&&b.push("expandable hunk separators"),c!=null&&b.push("merge conflict actions")),b})()),ee(t,"move","FileDiff.DEBUG.attachEventListeners: Attaching pointer move event"),ee(t,"move","FileDiff.DEBUG.attachEventListeners: Attaching pointer leave event")):!x&&this.hasPointerListeners&&(e.removeEventListener("click",this.handlePointerClick),e.removeEventListener("pointerdown",this.handlePointerDown),e.removeEventListener("pointermove",this.handlePointerMove),e.removeEventListener("pointerleave",this.handlePointerLeave),this.hasPointerListeners=!1);const C=this.pointerSession.mode==="selecting"||this.pointerSession.mode==="pendingSingleLineUnselect",m=this.pointerSession.mode==="gutterSelecting";(!u&&C||!y&&m)&&(this.clearPointerSession(),this.detachDocumentPointerListeners(),this.selectionAnchor=void 0,this.clearPendingSingleLineState())}updateInteractiveLineAttributes(){if(this.pre==null)return;const{onLineClick:e,onLineNumberClick:t,enableLineSelection:n=!1}=this.options,i=e!=null,r=t!=null||n;i&&!this.interactiveLinesAttr?(this.pre.setAttribute("data-interactive-lines",""),this.interactiveLinesAttr=!0):!i&&this.interactiveLinesAttr&&(this.pre.removeAttribute("data-interactive-lines"),this.interactiveLinesAttr=!1),r&&!this.interactiveLineNumbersAttr?(this.pre.setAttribute("data-interactive-line-numbers",""),this.interactiveLineNumbersAttr=!0):!r&&this.interactiveLineNumbersAttr&&(this.pre.removeAttribute("data-interactive-line-numbers"),this.interactiveLineNumbersAttr=!1)}handlePointerDown=e=>{if(e.pointerType==="mouse"&&e.button!==0||this.pre==null||this.pointerSession.mode!=="idle")return;const t=e.composedPath();wt(t)&&this.options.onGutterUtilityClick!=null?this.startGutterSelectionFromPointerDown(e,t):this.startLineSelectionFromPointerDown(e,t)};startLineSelectionFromPointerDown(e,t){const{enableLineSelection:n=!1}=this.options;if(!n)return;const i=this.getSelectionPointerInfo(t,!0);if(i==null)return;const{pre:r}=this;if(r==null)return;e.preventDefault();const{lineNumber:o,eventSide:s,lineIndex:l}=i;if(e.shiftKey&&this.selectedRange!=null){const a=this.getIndexesFromSelection(this.selectedRange,r.getAttribute("data-diff-type")==="split");if(a==null)return;const d=a.start<=a.end?l>=a.start:l<=a.end;this.selectionAnchor={lineNumber:d?this.selectedRange.start:this.selectedRange.end,side:d?this.selectedRange.side:this.selectedRange.endSide??this.selectedRange.side},this.updateSelection(o,s,!1),this.notifySelectionStart(this.selectedRange),this.pointerSession={mode:"selecting",pointerId:e.pointerId},this.attachDocumentPointerListeners();return}if(this.selectedRange?.start===o&&this.selectedRange?.end===o){const a={lineNumber:o,side:s};this.selectionAnchor=a,this.pointerSession={mode:"pendingSingleLineUnselect",pointerId:e.pointerId,anchor:a,pending:a},this.attachDocumentPointerListeners();return}this.selectedRange=null,this.selectionAnchor={lineNumber:o,side:s},this.updateSelection(o,s,!1),this.notifySelectionStart(this.selectedRange),this.pointerSession={mode:"selecting",pointerId:e.pointerId},this.attachDocumentPointerListeners()}startGutterSelectionFromPointerDown(e,t){const{enableLineSelection:n=!1,onGutterUtilityClick:i}=this.options;if(i==null)return;const r=this.getSelectionPointFromPath(t);r!=null&&(e.preventDefault(),e.stopPropagation(),this.pointerSession={mode:"gutterSelecting",pointerId:e.pointerId,anchor:r,current:r},n&&(this.selectionAnchor={lineNumber:r.lineNumber,side:r.side},this.updateSelection(r.lineNumber,r.side,!1),this.notifySelectionStart(this.selectedRange)),this.attachDocumentPointerListeners())}handleDocumentPointerMove=e=>{const{enableLineSelection:t=!1}=this.options;switch(this.pointerSession.mode){case"idle":return;case"gutterSelecting":{if(e.pointerId!==this.pointerSession.pointerId)return;const n=this.getSelectionPointFromPath(e.composedPath());if(n==null)return;this.pointerSession.current=n,t===!0&&this.updateSelection(n.lineNumber,n.side);return}case"selecting":{if(e.pointerId!==this.pointerSession.pointerId)return;const n=this.getSelectionPointerInfo(e.composedPath(),!1);if(n==null||this.selectionAnchor==null)return;this.updateSelection(n.lineNumber,n.eventSide);return}case"pendingSingleLineUnselect":{if(e.pointerId!==this.pointerSession.pointerId)return;const n=this.getSelectionPointerInfo(e.composedPath(),!1);if(n==null||this.selectionAnchor==null)return;const i={lineNumber:n.lineNumber,side:n.eventSide};if(ki(this.pointerSession.pending,i))return;this.updateSelection(n.lineNumber,n.eventSide,!1),this.notifySelectionStart(this.selectedRange),this.notifySelectionChangeDelta(),this.pointerSession={mode:"selecting",pointerId:e.pointerId};return}}};handleDocumentPointerUp=e=>{const{enableLineSelection:t=!1,onGutterUtilityClick:n}=this.options;switch(this.pointerSession.mode){case"idle":return;case"gutterSelecting":{if(e.pointerId!==this.pointerSession.pointerId)return;const i=this.getSelectionPointFromPath(e.composedPath());i!=null&&(this.pointerSession.current=i,t&&this.updateSelection(i.lineNumber,i.side)),n?.(this.buildSelectedLineRange(this.pointerSession.anchor,this.pointerSession.current)),this.selectionAnchor=void 0,t&&(this.notifySelectionEnd(this.selectedRange),this.notifySelectionCommitted()),this.clearPointerSession(),this.detachDocumentPointerListeners();return}case"pendingSingleLineUnselect":if(e.pointerId!==this.pointerSession.pointerId)return;this.updateSelection(null,void 0,!1),this.selectionAnchor=void 0,this.clearPendingSingleLineState(),this.detachDocumentPointerListeners(),this.notifySelectionEnd(this.selectedRange),this.notifySelectionCommitted();return;case"selecting":if(e.pointerId!==this.pointerSession.pointerId)return;this.selectionAnchor=void 0,this.detachDocumentPointerListeners(),this.clearPointerSession(),this.notifySelectionEnd(this.selectedRange),this.notifySelectionCommitted()}};handleDocumentPointerCancel=e=>{switch(this.pointerSession.mode){case"idle":return;case"gutterSelecting":case"selecting":case"pendingSingleLineUnselect":if("pointerId"in this.pointerSession&&e.pointerId!==this.pointerSession.pointerId)return;this.selectionAnchor=void 0,this.clearPendingSingleLineState(),this.clearPointerSession(),this.detachDocumentPointerListeners()}};clearHoveredLine(){this.hoveredLine!=null&&(this.hoveredLine.lineElement.removeAttribute("data-hovered"),this.hoveredLine.numberElement.removeAttribute("data-hovered"),this.hoveredLine=void 0)}setHoveredLine(e){const{lineHoverHighlight:t="disabled"}=this.options;this.hoveredLine!=null&&this.clearHoveredLine(),this.hoveredLine=e,t!=="disabled"&&((t==="both"||t==="line")&&this.hoveredLine.lineElement.setAttribute("data-hovered",""),(t==="both"||t==="number")&&this.hoveredLine.numberElement.setAttribute("data-hovered",""))}clearHoveredToken(){this.hoveredToken!=null&&(this.hoveredToken=void 0)}setHoveredToken(e){this.hoveredToken!=null&&this.clearHoveredToken(),this.hoveredToken=e}ensureGutterUtilityNode(e){if(this.gutterUtilityContainer==null&&(this.gutterUtilityContainer=document.createElement("div"),this.gutterUtilityContainer.setAttribute("data-gutter-utility-slot","")),e)this.gutterUtilityButton!=null&&(this.gutterUtilityButton.remove(),this.gutterUtilityButton=void 0),this.gutterUtilitySlot==null&&(this.gutterUtilitySlot=document.createElement("slot"),this.gutterUtilitySlot.name="gutter-utility-slot"),this.gutterUtilitySlot.parentNode!==this.gutterUtilityContainer&&this.gutterUtilityContainer.replaceChildren(this.gutterUtilitySlot);else{if(this.gutterUtilitySlot?.remove(),this.gutterUtilitySlot=void 0,this.gutterUtilityButton==null){const t=document.createElement("div");t.innerHTML=me(xi());const n=t.firstElementChild;if(!(n instanceof HTMLButtonElement))throw new Error("InteractionManager.ensureGutterUtilityNode: Node element should be a button");n.remove(),this.gutterUtilityButton=n}this.gutterUtilityButton.parentNode!==this.gutterUtilityContainer&&this.gutterUtilityContainer.replaceChildren(this.gutterUtilityButton)}}attachDocumentPointerListeners(){this.hasDocumentPointerListeners||(document.addEventListener("pointermove",this.handleDocumentPointerMove),document.addEventListener("pointerup",this.handleDocumentPointerUp),document.addEventListener("pointercancel",this.handleDocumentPointerCancel),this.hasDocumentPointerListeners=!0)}detachDocumentPointerListeners(){this.hasDocumentPointerListeners&&(document.removeEventListener("pointermove",this.handleDocumentPointerMove),document.removeEventListener("pointerup",this.handleDocumentPointerUp),document.removeEventListener("pointercancel",this.handleDocumentPointerCancel),this.hasDocumentPointerListeners=!1)}clearPointerSession(){this.pointerSession={mode:"idle"}}clearPendingSingleLineState(){this.pointerSession.mode==="pendingSingleLineUnselect"&&(this.pointerSession={mode:"idle"})}getSelectionPointerInfo(e,t){const n=this.resolvePointerTarget(e);if(Qe(n)&&!(t&&!n.numberColumn)&&n.splitLineIndex!=null)return{lineIndex:n.splitLineIndex,lineNumber:n.lineNumber,eventSide:this.mode==="diff"?n.side:void 0}}getSelectionPointFromPath(e){const t=this.resolvePointerTarget(e);if(Qe(t))return{lineNumber:t.lineNumber,side:this.mode==="diff"?t.side:void 0}}getLineIndex(e,t){const{getLineIndex:n}=this.options;return n!=null?n(e,t):[e-1,e-1]}updateSelection(e,t,n=!0){const{selectedRange:i}=this;let r;if(e==null)r=null;else{const o=this.selectionAnchor?.side??t,s=this.selectionAnchor?.lineNumber??e;r=this.buildSelectionRange(s,e,o,t)}yt(i??void 0,r??void 0)||(this.selectedRange=r,n&&this.notifySelectionChangeDelta(),this.queuedSelectionRender??=requestAnimationFrame(this.renderSelection))}getIndexesFromSelection(e,t){if(this.pre==null)return;const n=this.getLineIndex(e.start,e.side),i=this.getLineIndex(e.end,e.endSide??e.side);return n!=null&&i!=null?{start:t?n[1]:n[0],end:t?i[1]:i[0]}:void 0}renderSelection=()=>{if(this.queuedSelectionRender!=null&&(cancelAnimationFrame(this.queuedSelectionRender),this.queuedSelectionRender=void 0),this.pre==null||this.renderedSelectionRange===this.selectedRange)return;const e=this.pre.querySelectorAll("[data-selected-line]");for(const l of e)l.removeAttribute("data-selected-line");if(this.renderedSelectionRange=this.selectedRange,this.selectedRange==null)return;const{children:t}=this.pre;if(t.length===0)return;if(t.length>2)throw console.error(t),new Error("InteractionManager.renderSelection: Somehow there are more than 2 code elements...");const n=this.pre.getAttribute("data-diff-type")==="split",i=this.getIndexesFromSelection(this.selectedRange,n);if(i==null)throw console.error({rowRange:i,selectedRange:this.selectedRange}),new Error("InteractionManager.renderSelection: No valid rowRange");const r=i.start===i.end,o=Math.min(i.start,i.end),s=Math.max(i.start,i.end);for(const l of t){const[a,d]=l.children,f=d.children.length;if(f!==a.children.length)throw new Error("InteractionManager.renderSelection: gutter and content children dont match, something is wrong");for(let c=0;c<f;c++){const h=d.children[c],u=a.children[c];if(!(h instanceof HTMLElement)||!(u instanceof HTMLElement))continue;const p=this.parseLineIndex(h,n);if((p??0)>s)break;if(p==null||p<o)continue;let y=r?"single":p===o?"first":p===s?"last":"";h.setAttribute("data-selected-line",y),u.setAttribute("data-selected-line",y),u.nextSibling instanceof HTMLElement&&h.nextSibling instanceof HTMLElement&&(h.nextSibling.hasAttribute("data-line-annotation")||h.nextSibling.hasAttribute("data-merge-conflict-actions"))&&(r?(y="last",h.setAttribute("data-selected-line","first")):p===o?y="":p===s&&h.setAttribute("data-selected-line",""),h.nextSibling.setAttribute("data-selected-line",y),u.nextSibling.setAttribute("data-selected-line",y))}}};notifySelectionCommitted(){this.options.onLineSelected?.(this.selectedRange??null)}notifySelectionChangeDelta(){this.options.onLineSelectionChange?.(this.selectedRange??null)}notifySelectionStart(e){this.options.onLineSelectionStart?.(e)}notifySelectionEnd(e){this.options.onLineSelectionEnd?.(e)}toEventBaseProps(e){return this.mode==="file"?{type:"line",lineElement:e.lineElement,lineNumber:e.lineNumber,numberColumn:e.numberColumn,numberElement:e.numberElement}:{type:"diff-line",annotationSide:e.side,lineType:e.lineType,lineElement:e.lineElement,numberElement:e.numberElement,lineNumber:e.lineNumber,numberColumn:e.numberColumn}}toTokenEventBaseProps({lineCharEnd:e,lineCharStart:t,lineNumber:n,side:i,tokenElement:r,tokenText:o}){return this.mode==="file"?{type:"token",lineCharEnd:e,lineCharStart:t,lineNumber:n,tokenElement:r,tokenText:o}:{type:"token",lineCharEnd:e,lineCharStart:t,lineNumber:n,side:i,tokenElement:r,tokenText:o}}buildSelectedLineRange(e,t){return this.buildSelectionRange(e.lineNumber,t.lineNumber,e.side,t.side)}buildSelectionRange(e,t,n,i){return{start:e,end:t,...n!=null?{side:n}:{},...n!==i&&i!=null?{endSide:i}:{}}}resolvePointerTarget(e){let t=!1,n,i,r,o,s,l,a,d,f,c;for(const u of e){if(!(u instanceof HTMLElement))continue;if(c==null&&u.hasAttribute("data-merge-conflict-action")){const C=u.getAttribute("data-merge-conflict-action")??void 0,m=u.getAttribute("data-merge-conflict-conflict-index")??void 0,b=m!=null?Number.parseInt(m,10):NaN;Ei(C)&&Number.isFinite(b)&&(c={kind:"merge-conflict-action",resolution:C,conflictIndex:b})}if(l==null&&u.hasAttribute("data-char")){l=u;const C=u.getAttribute("data-char");if(C!=null){const m=Number.parseInt(C,10);if(!Number.isNaN(m)){const b=u.textContent??"",v=m+b.length;(b.trim()!==""||this.options.enableTokenInteractionsOnWhitespace===!0)&&(a={tokenElement:l,lineCharStart:m,lineCharEnd:v,tokenText:b});continue}}}const p=s==null?u.getAttribute("data-column-number")??void 0:void 0;if(p!=null){s=u,f=Number.parseInt(p,10),t=!0,n=Ct(u),o=u.getAttribute("data-line-index")??void 0;continue}const y=r==null?u.getAttribute("data-line")??void 0:void 0;if(y!=null){r=u,f=Number.parseInt(y,10),n=Ct(u),o=u.getAttribute("data-line-index")??void 0;continue}if(d==null&&(u.hasAttribute("data-expand-button")||u.hasAttribute("data-unmodified-lines"))){d={hunkIndex:void 0,direction:u.hasAttribute("data-expand-up")?"up":u.hasAttribute("data-expand-down")?"down":"both",all:u.hasAttribute("data-expand-all-button")};continue}const x=d!=null?u.getAttribute("data-expand-index")??void 0:void 0;if(d!=null&&x!=null){const C=Number.parseInt(x,10);Number.isNaN(C)||(d.hunkIndex=C);continue}if(i==null&&u.hasAttribute("data-code")){i=u;break}}if(c!=null)return c;if(d?.hunkIndex!=null)return{type:"line-info",hunkIndex:d.hunkIndex,direction:d.direction,all:d.all};if(r??=o!=null?xt(i,`[data-line][data-line-index="${o}"]`):void 0,s??=o!=null?xt(i,`[data-column-number][data-line-index="${o}"]`):void 0,i==null||r==null||s==null||n==null||f==null||Number.isNaN(f))return;const h=this.parseLineIndex(r,this.isSplitDiff());return a!=null?this.mode==="file"?{kind:"token",lineType:n,lineElement:r,lineNumber:f,numberColumn:t,numberElement:s,side:void 0,splitLineIndex:h,...a}:{kind:"token",lineType:n,lineElement:r,lineNumber:f,numberColumn:t,numberElement:s,side:St(n,i),splitLineIndex:h,...a}:this.mode==="file"?{kind:"line",lineType:n,lineElement:r,lineNumber:f,numberColumn:t,numberElement:s,side:void 0,splitLineIndex:h}:{kind:"line",lineType:n,lineElement:r,lineNumber:f,numberColumn:t,numberElement:s,side:St(n,i),splitLineIndex:h}}isSplitDiff(){return this.pre?.getAttribute("data-diff-type")==="split"}parseLineIndex(e,t){const n=(e.getAttribute("data-line-index")??"").split(",").map(i=>Number.parseInt(i,10)).filter(i=>!Number.isNaN(i));if(t&&n.length===2)return n[1];if(!t)return n[0]}};function kt({enableTokenInteractionsOnWhitespace:e,enableGutterUtility:t,enableHoverUtility:n,lineHoverHighlight:i,onGutterUtilityClick:r,onLineClick:o,onLineEnter:s,onLineLeave:l,onLineNumberClick:a,onTokenClick:d,onTokenEnter:f,onTokenLeave:c,renderGutterUtility:h,renderHoverUtility:u,__debugPointerEvents:p,enableLineSelection:y,onLineSelected:x,onLineSelectionStart:C,onLineSelectionChange:m,onLineSelectionEnd:b},v,S,g){return{enableTokenInteractionsOnWhitespace:e,enableGutterUtility:Ci({enableGutterUtility:t,enableHoverUtility:n,renderGutterUtility:h,renderHoverUtility:u,onGutterUtilityClick:r}),usesCustomGutterUtility:h!=null||u!=null,lineHoverHighlight:i,onGutterUtilityClick:r,onHunkExpand:v,onMergeConflictActionClick:g,onLineClick:o,onLineEnter:s,onLineLeave:l,onLineNumberClick:a,onTokenClick:d,onTokenEnter:f,onTokenLeave:c,__debugPointerEvents:p,enableLineSelection:y,onLineSelected:x,onLineSelectionStart:C,onLineSelectionChange:m,onLineSelectionEnd:b,getLineIndex:S}}function Ci({enableGutterUtility:e,enableHoverUtility:t,renderGutterUtility:n,renderHoverUtility:i,onGutterUtilityClick:r}){if(e!==void 0&&t!==void 0)throw new Error("Cannot use both 'enableGutterUtility' and deprecated 'enableHoverUtility'. Use only 'enableGutterUtility'.");if(n!=null&&i!=null)throw new Error("Cannot use both 'renderGutterUtility' and deprecated 'renderHoverUtility'. Use only 'renderGutterUtility'.");if(r!=null&&(n!=null||i!=null))throw new Error("Cannot use both 'onGutterUtilityClick' and render utility callbacks ('renderGutterUtility'/'renderHoverUtility'). Use only one gutter utility API.");return e??t??!1}function Qe(e){return e!=null&&"kind"in e&&e.kind==="line"}function Ae(e){return e!=null&&"kind"in e&&e.kind==="token"}function $e(e){return Qe(e)||Ae(e)}function wi(e){return"type"in e&&e.type==="line-info"}function Li(e){return"kind"in e&&e.kind==="merge-conflict-action"}function Ei(e){return e==="current"||e==="incoming"||e==="both"}function xt(e,t){const n=e?.querySelector(t);return n instanceof HTMLElement?n:void 0}function St(e,t){switch(e){case"change-deletion":return"deletions";case"change-addition":return"additions";default:return t.hasAttribute("data-deletions")?"deletions":"additions"}}function Ct(e){const t=e.getAttribute("data-line-type");if(t!=null)switch(t){case"change-deletion":case"change-addition":case"context":case"context-expanded":return t;default:return}}function wt(e){for(const t of e)if(t instanceof HTMLElement&&t.hasAttribute("data-utility-button"))return!0;return!1}function ee(e="none",t,...n){switch(e){case"none":return;case"both":break;case"click":if(t!=="click")return;break;case"move":if(t!=="move")return;break}console.log(...n)}var Ti=class{observedNodes=new Map;queuedUpdates=new Map;cleanUp(){this.resizeObserver?.disconnect(),this.observedNodes.clear(),this.queuedUpdates.clear()}resizeObserver;setup(e,t){this.resizeObserver??=new ResizeObserver(this.handleResizeObserver);const n=e.querySelectorAll("code"),i=new Map(this.observedNodes);this.observedNodes.clear();for(const r of n){let o=i.get(r);if(o!=null&&o.type!=="code")throw new Error("ResizeManager.setup: somehow a code node is being used for an annotation, should be impossible");let s=r.firstElementChild;s instanceof HTMLElement||(s=null),o!=null?(this.observedNodes.set(r,o),i.delete(r),o.numberElement!==s?(o.numberElement!=null&&this.resizeObserver.unobserve(o.numberElement),s!=null&&(this.resizeObserver.observe(s),i.delete(s),this.observedNodes.set(s,o)),o.numberElement=s):o.numberElement!=null&&(i.delete(o.numberElement),this.observedNodes.set(o.numberElement,o))):(o={type:"code",codeElement:r,numberElement:s,codeWidth:"auto",numberWidth:0},this.observedNodes.set(r,o),this.resizeObserver.observe(r),s!=null&&(this.observedNodes.set(s,o),this.resizeObserver.observe(s)))}if(n.length>1&&!t){const r=e.querySelectorAll('[data-line-annotation*=","]'),o=new Map;for(const s of r){if(!(s instanceof HTMLElement))continue;const{lineAnnotation:l=""}=s.dataset;if(!/^\d+,\d+$/.test(l)){console.error("DiffFileRenderer.setupResizeObserver: Invalid element or annotation",{lineAnnotation:l,element:s});continue}let a=o.get(l);a==null&&(a=[],o.set(l,a)),a.push(s)}for(const[s,l]of o){if(l.length!==2){console.error("DiffFileRenderer.setupResizeObserver: Bad Pair",s,l);continue}const[a,d]=l,f=a.firstElementChild,c=d.firstElementChild;if(!(a instanceof HTMLElement)||!(d instanceof HTMLElement)||!(f instanceof HTMLElement)||!(c instanceof HTMLElement))continue;let h=i.get(f);if(h!=null){this.observedNodes.set(f,h),this.observedNodes.set(c,h),i.delete(f),i.delete(c);continue}h={type:"annotations",column1:{container:a,child:f,childHeight:f.getBoundingClientRect().height},column2:{container:d,child:c,childHeight:c.getBoundingClientRect().height},currentHeight:"auto"};const u=Math.max(h.column1.childHeight,h.column2.childHeight);this.applyNewHeight(h,u),this.observedNodes.set(f,h),this.observedNodes.set(c,h),this.resizeObserver.observe(f),this.resizeObserver.observe(c)}}for(const r of i.keys())r.isConnected&&(r.style.removeProperty("--diffs-column-content-width"),r.style.removeProperty("--diffs-column-number-width"),r.style.removeProperty("--diffs-column-width"),r.parentElement instanceof HTMLElement&&r.parentElement.style.removeProperty("--diffs-annotation-min-height")),this.resizeObserver.unobserve(r);i.clear()}handleResizeObserver=e=>{for(const t of e){const{target:n,borderBoxSize:i,contentBoxSize:r}=t;if(!(n instanceof HTMLElement)){console.error("FileDiff.handleResizeObserver: Invalid element for ResizeObserver",t);continue}const o=this.observedNodes.get(n);if(o==null){console.error("FileDiff.handleResizeObserver: Not a valid observed node",t);continue}if(o.type==="annotations"){const s=(()=>{if(n===o.column1.child)return o.column1;if(n===o.column2.child)return o.column2})();if(s==null){console.error("FileDiff.handleResizeObserver: Couldn't find a column for",{item:o,target:n});continue}s.childHeight=i[0].blockSize;const l=Math.max(o.column1.childHeight,o.column2.childHeight);this.applyNewHeight(o,l)}else if(o.type==="code"){const s=[n,r[0].inlineSize],l=this.queuedUpdates.get(o)??[];l.push(s),this.queuedUpdates.set(o,l)}}this.handleColumnChange()};handleColumnChange=()=>{for(const[e,t]of this.queuedUpdates)for(const[n,i]of t)if(n===e.codeElement){const r=Math.max(Math.floor(i),0);if(r!==e.codeWidth){const o=Math.max(r-e.numberWidth,0);e.codeWidth=r===0?"auto":r,e.codeElement.style.setProperty("--diffs-column-content-width",`${o>0?`${o}px`:"auto"}`),e.codeElement.style.setProperty("--diffs-column-width",`${typeof e.codeWidth=="number"?`${e.codeWidth}px`:"auto"}`)}e.numberElement!=null&&typeof e.codeWidth=="number"&&e.numberWidth===0&&t.push([e.numberElement,e.numberElement.getBoundingClientRect().width])}else if(n===e.numberElement){const r=Math.max(Math.ceil(i),0);if(r!==e.numberWidth&&(e.numberWidth=r,e.codeElement.style.setProperty("--diffs-column-number-width",`${e.numberWidth===0?"auto":`${e.numberWidth}px`}`),e.codeWidth!=="auto")){const o=Math.max(e.codeWidth-e.numberWidth,0);e.codeElement.style.setProperty("--diffs-column-content-width",`${o===0?"auto":`${o}px`}`)}}this.queuedUpdates.clear()};applyNewHeight(e,t){t!==e.currentHeight&&(e.currentHeight=Math.max(t,0),e.column1.container.style.setProperty("--diffs-annotation-min-height",`${e.currentHeight}px`),e.column2.container.style.setProperty("--diffs-annotation-min-height",`${e.currentHeight}px`))}};function Wt(e,t){return e==null||t==null?e===t:e.startingLine===t.startingLine&&e.totalLines===t.totalLines&&e.bufferBefore===t.bufferBefore&&e.bufferAfter===t.bufferAfter}function Lt(e){for(const t of Array.isArray(e)?e:[e])if(!(t==="text"||t==="ansi")&&!Ye.has(t))return!1;return!0}function Ve(e){for(const t of $t(e))if(!Je.has(t))return!1;return!0}function Ai(e){return A({tagName:"div",children:[A({tagName:"div",children:e.annotations?.map(t=>A({tagName:"slot",properties:{name:t}})),properties:{"data-annotation-content":""}})],properties:{"data-line-annotation":`${e.hunkIndex},${e.lineIndex}`}})}function _i(e,t){return A({tagName:"div",children:e,properties:{"data-content":"",style:`grid-row: span ${t}`}})}function Ii(e){switch(e){case"file":return"diffs-icon-file-code";case"change":return"diffs-icon-symbol-modified";case"new":return"diffs-icon-symbol-added";case"deleted":return"diffs-icon-symbol-deleted";case"rename-pure":case"rename-changed":return"diffs-icon-symbol-moved"}}function Ri({fileOrDiff:e,mode:t}){const n="type"in e?e:void 0,i={"data-diffs-header":t,"data-change-type":n?.type};return A({tagName:"div",children:[t==="custom"?A({tagName:"slot",properties:{name:it}}):Pi({name:e.name,prevName:"prevName"in e?e.prevName:void 0,iconType:n?.type??"file"}),...t==="custom"?[]:[Di(n)]],properties:i})}function Pi({name:e,prevName:t,iconType:n}){const i=[A({tagName:"slot",properties:{name:tt}}),Ie({name:Ii(n),properties:{"data-change-icon":n}})];return t!=null&&(i.push(A({tagName:"div",children:[A({tagName:"bdi",children:[Y(t)]})],properties:{"data-prev-name":""}})),i.push(Ie({name:"diffs-icon-arrow-right-short",properties:{"data-rename-icon":""}}))),i.push(A({tagName:"div",children:[A({tagName:"bdi",children:[Y(e)]})],properties:{"data-title":""}})),A({tagName:"div",children:i,properties:{"data-header-content":""}})}function Di(e){const t=[];if(e!=null){let n=0,i=0;for(const r of e.hunks)n+=r.additionLines,i+=r.deletionLines;(i>0||n===0)&&t.push(A({tagName:"span",children:[Y(`-${i}`)],properties:{"data-deletions-count":""}})),(n>0||i===0)&&t.push(A({tagName:"span",children:[Y(`+${n}`)],properties:{"data-additions-count":""}}))}return t.push(A({tagName:"slot",properties:{name:nt}})),A({tagName:"div",children:t,properties:{"data-metadata":""}})}function Mi(e){return A({tagName:"pre",properties:Ni(e)})}function Ni({diffIndicators:e,disableBackground:t,disableLineNumbers:n,overflow:i,split:r,totalLines:o,type:s,customProperties:l}){return{...l,"data-diff":s==="diff"?"":void 0,"data-file":s==="file"?"":void 0,"data-diff-type":s==="diff"?r?"split":"single":void 0,"data-overflow":i,"data-disable-line-numbers":n?"":void 0,"data-background":t?void 0:"","data-indicators":e==="bars"||e==="classic"?e:void 0,tabIndex:0,style:`--diffs-min-number-column-width-default:${`${o}`.length}ch;`}}function Hi(e,{theme:t,preferredHighlighter:n="shiki-js"}){return{langs:[e??"text"],themes:$t(t),preferredHighlighter:n}}function Oi(e){return e.useTokenTransformer===!0||e.onTokenClick!=null||e.onTokenEnter!=null||e.onTokenLeave!=null}const Ui=`<svg data-icon-sprite aria-hidden="true" width="0" height="0">
  <symbol id="diffs-icon-arrow-right-short" viewBox="0 0 16 16">
    <path d="M8.47 4.22a.75.75 0 0 0 0 1.06l1.97 1.97H3.75a.75.75 0 0 0 0 1.5h6.69l-1.97 1.97a.75.75 0 1 0 1.06 1.06l3.25-3.25a.75.75 0 0 0 0-1.06L9.53 4.22a.75.75 0 0 0-1.06 0"/>
  </symbol>
  <symbol id="diffs-icon-brand-github" viewBox="0 0 16 16">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.01 8.01 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27s-1.36.09-2 .27c-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8"/>
  </symbol>
  <symbol id="diffs-icon-chevron" viewBox="0 0 16 16">
    <path d="M1.47 4.47a.75.75 0 0 1 1.06 0L8 9.94l5.47-5.47a.75.75 0 1 1 1.06 1.06l-6 6a.75.75 0 0 1-1.06 0l-6-6a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-chevrons-narrow" viewBox="0 0 10 16">
    <path d="M4.47 2.22a.75.75 0 0 1 1.06 0l3.25 3.25a.75.75 0 0 1-1.06 1.06L5 3.81 2.28 6.53a.75.75 0 0 1-1.06-1.06zM1.22 9.47a.75.75 0 0 1 1.06 0L5 12.19l2.72-2.72a.75.75 0 0 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0l-3.25-3.25a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-diff-split" viewBox="0 0 16 16">
    <path d="M14 0H8.5v16H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2m-1.5 6.5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0"/><path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5.5V0zm.5 7.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1 0-1" opacity=".3"/>
  </symbol>
  <symbol id="diffs-icon-diff-unified" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8.5h16zm-8-4a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 0 0 1 0v-1h1a.5.5 0 0 0 0-1h-1v-1A.5.5 0 0 0 8 10" clip-rule="evenodd"/><path fill-rule="evenodd" d="M14 0a2 2 0 0 1 2 2v5.5H0V2a2 2 0 0 1 2-2zM6.5 3.5a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1z" clip-rule="evenodd" opacity=".4"/>
  </symbol>
  <symbol id="diffs-icon-expand" viewBox="0 0 16 16">
    <path d="M3.47 5.47a.75.75 0 0 1 1.06 0L8 8.94l3.47-3.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-expand-all" viewBox="0 0 16 16">
    <path d="M11.47 9.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 1 1 1.06-1.06L8 12.94zM7.526 1.418a.75.75 0 0 1 1.004.052l4 4a.75.75 0 1 1-1.06 1.06L8 3.06 4.53 6.53a.75.75 0 1 1-1.06-1.06l4-4z"/>
  </symbol>
  <symbol id="diffs-icon-file-code" viewBox="0 0 16 16">
    <path d="M10.75 0c.199 0 .39.08.53.22l3.5 3.5c.14.14.22.331.22.53v9A2.75 2.75 0 0 1 12.25 16h-8.5A2.75 2.75 0 0 1 1 13.25V2.75A2.75 2.75 0 0 1 3.75 0zm-7 1.5c-.69 0-1.25.56-1.25 1.25v10.5c0 .69.56 1.25 1.25 1.25h8.5c.69 0 1.25-.56 1.25-1.25V5h-1.25A2.25 2.25 0 0 1 10 2.75V1.5z"/><path d="M7.248 6.19a.75.75 0 0 1 .063 1.058L5.753 9l1.558 1.752a.75.75 0 0 1-1.122.996l-2-2.25a.75.75 0 0 1 0-.996l2-2.25a.75.75 0 0 1 1.06-.063M8.69 7.248a.75.75 0 1 1 1.12-.996l2 2.25a.75.75 0 0 1 0 .996l-2 2.25a.75.75 0 1 1-1.12-.996L10.245 9z"/>
  </symbol>
  <symbol id="diffs-icon-plus" viewBox="0 0 16 16">
    <path d="M8 3a.75.75 0 0 1 .75.75v3.5h3.5a.75.75 0 0 1 0 1.5h-3.5v3.5a.75.75 0 0 1-1.5 0v-3.5h-3.5a.75.75 0 0 1 0-1.5h3.5v-3.5A.75.75 0 0 1 8 3"/>
  </symbol>
  <symbol id="diffs-icon-symbol-added" viewBox="0 0 16 16">
    <path d="M8 4a.75.75 0 0 1 .75.75v2.5h2.5a.75.75 0 0 1 0 1.5h-2.5v2.5a.75.75 0 0 1-1.5 0v-2.5h-2.5a.75.75 0 0 1 0-1.5h2.5v-2.5A.75.75 0 0 1 8 4"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-deleted" viewBox="0 0 16 16">
    <path d="M4 8a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 0 1.5h-6.5A.75.75 0 0 1 4 8"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-diffstat" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.75 4.296a.75.75 0 0 0-1.5 0V6.25h-2a.75.75 0 0 0 0 1.5h2v1.5h1.5v-1.5h2a.75.75 0 0 0 0-1.5h-2zM5.25 10a.75.75 0 0 0 0 1.5h5.5a.75.75 0 0 0 0-1.5z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ignored" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m11.53-2.47a.75.75 0 0 0-1.06-1.06l-6 6a.75.75 0 1 0 1.06 1.06z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-modified" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m8 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
  </symbol>
  <symbol id="diffs-icon-symbol-moved" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.495 4.695a.75.75 0 0 0-.05 1.06L10.486 8l-2.041 2.246a.75.75 0 0 0 1.11 1.008l2.5-2.75a.75.75 0 0 0 0-1.008l-2.5-2.75a.75.75 0 0 0-1.06-.051m-4 0a.75.75 0 0 0-.05 1.06l2.044 2.248-1.796 1.995a.75.75 0 0 0 1.114 1.004l2.25-2.5a.75.75 0 0 0-.002-1.007l-2.5-2.75a.75.75 0 0 0-1.06-.05"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ref" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706.286.286.71.54 1.41.73V1.86c-.7.19-1.124.444-1.41.73-.324.325-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8m4 6.397c.697.07 1.522.103 2.5.103 1.613 0 2.806-.088 3.704-.288.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5c-.978 0-1.803.033-2.5.103zM0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m7-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1z"/>
  </symbol>
</svg>`;function zi(e,t){return e==null||t==null?e===t:Fi(e.customProperties,t.customProperties)&&e.type===t.type&&e.diffIndicators===t.diffIndicators&&e.disableBackground===t.disableBackground&&e.disableLineNumbers===t.disableLineNumbers&&e.overflow===t.overflow&&e.split===t.split&&e.totalLines===t.totalLines}const Et={};function Fi(e=Et,t=Et){if(e===t)return!0;const n=Object.keys(e),i=Object.keys(t);if(n.length!==i.length)return!1;for(const r of n)if(e[r]!==t[r])return!1;return!0}function $i(e){const t=document.createElement("div");return t.dataset.annotationSlot="",t.slot=e,t.style.whiteSpace="normal",t}function Vi(){const e=document.createElement("div");return e.slot="gutter-utility-slot",e.style.position="absolute",e.style.top="0",e.style.bottom="0",e.style.textAlign="center",e.style.whiteSpace="normal",e}function Bi(){const e=document.createElement("style");return e.setAttribute(Nt,""),e}var Wi=`@layer base, theme, rendered, unsafe;

@layer base {
  :host {
    --diffs-font-fallback:
      'SF Mono', Monaco, Consolas, 'Ubuntu Mono', 'Liberation Mono',
      'Courier New', monospace;
    --diffs-header-font-fallback:
      system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue',
      'Noto Sans', 'Liberation Sans', Arial, sans-serif;

    --diffs-mixer: light-dark(black, white);
    --diffs-gap-fallback: 8px;

    --diffs-added-light: #0dbe4e;
    --diffs-added-dark: #5ecc71;
    --diffs-modified-light: #009fff;
    --diffs-modified-dark: #69b1ff;
    --diffs-deleted-light: #ff2e3f;
    --diffs-deleted-dark: #ff6762;

    /*
    // Available CSS Color Overrides
    --diffs-bg-buffer-override
    --diffs-bg-hover-override
    --diffs-bg-context-override
    --diffs-bg-separator-override

    --diffs-fg-number-override
    --diffs-fg-number-addition-override
    --diffs-fg-number-deletion-override
    --diffs-fg-conflict-marker-override

    --diffs-deletion-color-override
    --diffs-addition-color-override
    --diffs-modified-color-override

    --diffs-bg-deletion-override
    --diffs-bg-deletion-number-override
    --diffs-bg-deletion-hover-override
    --diffs-bg-deletion-emphasis-override

    --diffs-bg-addition-override
    --diffs-bg-addition-number-override
    --diffs-bg-addition-hover-override
    --diffs-bg-addition-emphasis-override

    // Line Selection Color Overrides (for enableLineSelection)
    --diffs-selection-color-override
    --diffs-bg-selection-override
    --diffs-bg-selection-number-override
    --diffs-bg-selection-background-override
    --diffs-bg-selection-number-background-override

    // Available CSS Layout Overrides
    --diffs-gap-inline
    --diffs-gap-block
    --diffs-gap-style
    --diffs-tab-size
  */

    color-scheme: light dark;
    display: block;
    font-family: var(
      --diffs-header-font-family,
      var(--diffs-header-font-fallback)
    );
    font-size: var(--diffs-font-size, 13px);
    line-height: var(--diffs-line-height, 20px);
    font-feature-settings: var(--diffs-font-features);

    /* NOTE(amadeus): we cannot use 'in oklch' because current versions of cursor
     * and vscode use an older build of chrome that appears to have a bug with
     * color-mix and 'in oklch', so use 'in lab' instead */
    --diffs-bg: light-dark(
      var(--diffs-light-bg, #fff),
      var(--diffs-dark-bg, #000)
    );
    --diffs-bg-buffer: var(
      --diffs-bg-buffer-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer))
      )
    );
    --diffs-bg-hover: var(
      --diffs-bg-hover-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 97%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-mixer))
      )
    );

    --diffs-bg-context: var(
      --diffs-bg-context-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 98.5%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 92.5%, var(--diffs-mixer))
      )
    );
    --diffs-bg-context-number: var(
      --diffs-bg-context-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg-context) 80%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-bg-context) 60%, var(--diffs-bg))
      )
    );
    --diffs-bg-conflict-marker: var(
      --diffs-bg-conflict-marker-override,
      light-dark(
        color-mix(
          in lab,
          var(--diffs-bg-context) 88%,
          var(--diffs-modified-base)
        ),
        color-mix(
          in lab,
          var(--diffs-bg-context) 80%,
          var(--diffs-modified-base)
        )
      )
    );
    --diffs-bg-conflict-current: var(
      --diffs-bg-conflict-current-override,
      light-dark(#e5f8ea, #274432)
    );
    --diffs-bg-conflict-base: var(
      --diffs-bg-conflict-base-override,
      light-dark(
        color-mix(
          in lab,
          var(--diffs-bg-context) 90%,
          var(--diffs-modified-base)
        ),
        color-mix(
          in lab,
          var(--diffs-bg-context) 82%,
          var(--diffs-modified-base)
        )
      )
    );
    --diffs-bg-conflict-incoming: var(
      --diffs-bg-conflict-incoming-override,
      light-dark(#e6f1ff, #253b5a)
    );
    --diffs-bg-conflict-marker-number: var(
      --diffs-bg-conflict-marker-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg-conflict-marker) 72%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-bg-conflict-marker) 54%, var(--diffs-bg))
      )
    );
    --diffs-bg-conflict-current-number: var(
      --diffs-bg-conflict-current-number-override,
      light-dark(#d7f1de, #30533d)
    );
    --diffs-bg-conflict-base-number: var(
      --diffs-bg-conflict-base-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg-conflict-base) 72%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-bg-conflict-base) 54%, var(--diffs-bg))
      )
    );
    --diffs-bg-conflict-incoming-number: var(
      --diffs-bg-conflict-incoming-number-override,
      light-dark(#d8e8ff, #2f4b73)
    );
    --conflict-bg-current: var(
      --conflict-bg-current-override,
      var(--diffs-bg-addition)
    );
    --conflict-bg-incoming: var(
      --conflict-bg-incoming-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-modified-base))
      )
    );
    --conflict-bg-current-number: var(
      --conflict-bg-current-number-override,
      var(--diffs-bg-addition-number)
    );
    --conflict-bg-incoming-number: var(
      --conflict-bg-incoming-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-modified-base))
      )
    );
    --conflict-bg-current-header: var(
      --conflict-bg-current-header-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 78%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 68%, var(--diffs-addition-base))
      )
    );
    --conflict-bg-incoming-header: var(
      --conflict-bg-incoming-header-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 78%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 68%, var(--diffs-modified-base))
      )
    );
    --conflict-bg-current-header-number: var(
      --conflict-bg-current-header-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 72%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 62%, var(--diffs-addition-base))
      )
    );
    --conflict-bg-incoming-header-number: var(
      --conflict-bg-incoming-header-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 72%, var(--diffs-modified-base)),
        color-mix(in lab, var(--diffs-bg) 62%, var(--diffs-modified-base))
      )
    );

    --diffs-bg-separator: var(
      --diffs-bg-separator-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 96%, var(--diffs-mixer)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-mixer))
      )
    );

    --diffs-fg: light-dark(var(--diffs-light, #000), var(--diffs-dark, #fff));
    --diffs-fg-number: var(
      --diffs-fg-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg)),
        color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg))
      )
    );
    --diffs-fg-conflict-marker: var(
      --diffs-fg-conflict-marker-override,
      var(--diffs-fg-number)
    );

    --diffs-deletion-base: var(
      --diffs-deletion-color-override,
      light-dark(
        var(
          --diffs-light-deletion-color,
          var(--diffs-deletion-color, var(--diffs-deleted-light))
        ),
        var(
          --diffs-dark-deletion-color,
          var(--diffs-deletion-color, var(--diffs-deleted-dark))
        )
      )
    );
    --diffs-addition-base: var(
      --diffs-addition-color-override,
      light-dark(
        var(
          --diffs-light-addition-color,
          var(--diffs-addition-color, var(--diffs-added-light))
        ),
        var(
          --diffs-dark-addition-color,
          var(--diffs-addition-color, var(--diffs-added-dark))
        )
      )
    );
    --diffs-modified-base: var(
      --diffs-modified-color-override,
      light-dark(
        var(
          --diffs-light-modified-color,
          var(--diffs-modified-color, var(--diffs-modified-light))
        ),
        var(
          --diffs-dark-modified-color,
          var(--diffs-modified-color, var(--diffs-modified-dark))
        )
      )
    );

    /* NOTE(amadeus): we cannot use 'in oklch' because current versions of cursor
   * and vscode use an older build of chrome that appears to have a bug with
   * color-mix and 'in oklch', so use 'in lab' instead */
    --diffs-bg-deletion: var(
      --diffs-bg-deletion-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-deletion-base)),
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-deletion-base))
      )
    );
    --diffs-bg-deletion-number: var(
      --diffs-bg-deletion-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-deletion-base)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-deletion-base))
      )
    );
    --diffs-bg-deletion-hover: var(
      --diffs-bg-deletion-hover-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-deletion-base)),
        color-mix(in lab, var(--diffs-bg) 75%, var(--diffs-deletion-base))
      )
    );
    --diffs-bg-deletion-emphasis: var(
      --diffs-bg-deletion-emphasis-override,
      light-dark(
        rgb(from var(--diffs-deletion-base) r g b / 0.15),
        rgb(from var(--diffs-deletion-base) r g b / 0.2)
      )
    );

    --diffs-bg-addition: var(
      --diffs-bg-addition-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-addition-base))
      )
    );
    --diffs-bg-addition-number: var(
      --diffs-bg-addition-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 91%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-addition-base))
      )
    );
    --diffs-bg-addition-hover: var(
      --diffs-bg-addition-hover-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-addition-base)),
        color-mix(in lab, var(--diffs-bg) 70%, var(--diffs-addition-base))
      )
    );
    --diffs-bg-addition-emphasis: var(
      --diffs-bg-addition-emphasis-override,
      light-dark(
        rgb(from var(--diffs-addition-base) r g b / 0.15),
        rgb(from var(--diffs-addition-base) r g b / 0.2)
      )
    );

    --diffs-selection-base: var(--diffs-modified-base);
    --diffs-selection-number-fg: light-dark(
      color-mix(in lab, var(--diffs-selection-base) 65%, var(--diffs-mixer)),
      color-mix(in lab, var(--diffs-selection-base) 75%, var(--diffs-mixer))
    );
    --diffs-bg-selection: var(
      --diffs-bg-selection-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 82%, var(--diffs-selection-base)),
        color-mix(in lab, var(--diffs-bg) 75%, var(--diffs-selection-base))
      )
    );
    --diffs-bg-selection-number: var(
      --diffs-bg-selection-number-override,
      light-dark(
        color-mix(in lab, var(--diffs-bg) 75%, var(--diffs-selection-base)),
        color-mix(in lab, var(--diffs-bg) 60%, var(--diffs-selection-base))
      )
    );

    background-color: var(--diffs-bg);
    color: var(--diffs-fg);
  }

  /* NOTE(mdo): Some semantic HTML elements (e.g. \`pre\`, \`code\`) have default
 * user-agent styles. These must be overridden to use our custom styles. */
  pre,
  code,
  [data-error-wrapper] {
    isolation: isolate;
    margin: 0;
    padding: 0;
    display: block;
    outline: none;
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
  }

  pre,
  code {
    background-color: var(--diffs-bg);
  }

  code {
    contain: content;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  [data-icon-sprite] {
    display: none;
  }

  /* NOTE(mdo): Headers and separators are within pre/code, so we need to reset
   * their font-family explicitly. */
  [data-diffs-header],
  [data-separator] {
    font-family: var(
      --diffs-header-font-family,
      var(--diffs-header-font-fallback)
    );
  }

  [data-file-info] {
    padding: 10px;
    font-weight: 700;
    color: var(--fg);
    /* NOTE(amadeus): we cannot use 'in oklch' because current versions of cursor
   * and vscode use an older build of chrome that appears to have a bug with
   * color-mix and 'in oklch', so use 'in lab' instead */
    background-color: color-mix(in lab, var(--bg) 98%, var(--fg));
    border-block: 1px solid color-mix(in lab, var(--bg) 95%, var(--fg));
  }

  [data-diff],
  [data-file] {
    /* This feels a bit crazy to me... so I need to think about it a bit more... */
    --diffs-grid-number-column-width: minmax(min-content, max-content);
    --diffs-code-grid: var(--diffs-grid-number-column-width) 1fr;

    &[data-dehydrated] {
      --diffs-code-grid: var(--diffs-grid-number-column-width) minmax(0, 1fr);
    }

    &:hover [data-code]::-webkit-scrollbar-thumb {
      background-color: var(--diffs-bg-context);
    }
  }

  [data-line] span {
    color: light-dark(
      var(--diffs-token-light, var(--diffs-light)),
      var(--diffs-token-dark, var(--diffs-dark))
    );
    background-color: light-dark(
      var(--diffs-token-light-bg, inherit),
      var(--diffs-token-dark-bg, inherit)
    );
    font-weight: light-dark(
      var(--diffs-token-light-font-weight, inherit),
      var(--diffs-token-dark-font-weight, inherit)
    );
    font-style: light-dark(
      var(--diffs-token-light-font-style, inherit),
      var(--diffs-token-dark-font-style, inherit)
    );
    -webkit-text-decoration: light-dark(
      var(--diffs-token-light-text-decoration, inherit),
      var(--diffs-token-dark-text-decoration, inherit)
    );
            text-decoration: light-dark(
      var(--diffs-token-light-text-decoration, inherit),
      var(--diffs-token-dark-text-decoration, inherit)
    );
  }

  [data-line],
  [data-gutter-buffer],
  [data-line-annotation],
  [data-no-newline] {
    color: var(--diffs-fg);
    background-color: var(--diffs-line-bg, var(--diffs-bg));
  }

  [data-no-newline] {
    -webkit-user-select: none;
            user-select: none;

    span {
      opacity: 0.6;
    }
  }

  [data-diff-type='split'][data-overflow='scroll'] {
    display: grid;
    grid-template-columns: 1fr 1fr;

    [data-additions] {
      border-left: 1px solid var(--diffs-bg);
    }

    [data-deletions] {
      border-right: 1px solid var(--diffs-bg);
    }
  }

  [data-code] {
    display: grid;
    grid-auto-flow: dense;
    grid-template-columns: var(--diffs-code-grid);
    overflow: scroll clip;
    overscroll-behavior-x: none;
    tab-size: var(--diffs-tab-size, 2);
    align-self: flex-start;
    padding-top: var(--diffs-gap-block, var(--diffs-gap-fallback));
    padding-bottom: max(
      0px,
      calc(var(--diffs-gap-block, var(--diffs-gap-fallback)) - 6px)
    );
  }

  [data-container-size] {
    container-type: inline-size;
  }

  [data-code]::-webkit-scrollbar {
    width: 0;
    height: 6px;
  }

  [data-code]::-webkit-scrollbar-track {
    background: transparent;
  }

  [data-code]::-webkit-scrollbar-thumb {
    background-color: transparent;
    border: 1px solid transparent;
    background-clip: content-box;
    border-radius: 3px;
  }

  [data-code]::-webkit-scrollbar-corner {
    background-color: transparent;
  }

  /*
   * If we apply these rules globally it will mean that webkit will opt into the
   * standards compliant version of custom css scrollbars, which we do not want
   * because the custom stuff will look better
  */
  @supports (-moz-appearance: none) {
    [data-code] {
      scrollbar-width: thin;
      scrollbar-color: var(--diffs-bg-context) transparent;
      padding-bottom: var(--diffs-gap-block, var(--diffs-gap-fallback));
    }
  }

  [data-diffs-header] ~ [data-diff],
  [data-diffs-header] ~ [data-file] {
    [data-code],
    &[data-overflow='wrap'] {
      padding-top: 0;
    }
  }

  [data-gutter] {
    display: grid;
    grid-template-rows: subgrid;
    grid-template-columns: subgrid;
    grid-column: 1;
    z-index: 3;
    position: relative;
    background-color: var(--diffs-bg);

    [data-gutter-buffer],
    [data-column-number] {
      border-right: var(--diffs-gap-style, 2px solid var(--diffs-bg));
    }
  }

  [data-content] {
    display: grid;
    grid-template-rows: subgrid;
    grid-template-columns: subgrid;
    grid-column: 2;
    min-width: 0;
  }

  [data-diff-type='split'][data-overflow='wrap'] {
    display: grid;
    grid-auto-flow: dense;
    grid-template-columns: repeat(2, var(--diffs-code-grid));
    padding-block: var(--diffs-gap-block, var(--diffs-gap-fallback));

    [data-deletions] {
      display: contents;

      [data-gutter] {
        grid-column: 1;
      }

      [data-content] {
        grid-column: 2;
        border-right: 1px solid var(--diffs-bg);
      }
    }

    [data-additions] {
      display: contents;

      [data-gutter] {
        grid-column: 3;
        border-left: 1px solid var(--diffs-bg);
      }

      [data-content] {
        grid-column: 4;
      }
    }
  }

  [data-overflow='scroll'] [data-gutter] {
    position: sticky;
    left: 0;
  }

  [data-line-annotation][data-selected-line] {
    background-color: unset;

    &::before {
      content: '';
      /* FIXME(amadeus): This needs to be audited ... */
      position: sticky;
      top: 0;
      left: 0;
      display: block;
      border-right: var(--diffs-gap-style, 1px solid var(--diffs-bg));
      background-color: var(--diffs-bg-selection-number);
    }

    [data-annotation-content] {
      background-color: var(--diffs-bg-selection);
    }
  }

  [data-interactive-lines] [data-line] {
    cursor: pointer;
  }

  [data-content-buffer],
  [data-gutter-buffer] {
    position: relative;
    -webkit-user-select: none;
            user-select: none;
    min-height: 1lh;
  }

  [data-gutter-buffer='annotation'] {
    min-height: 0;
  }

  [data-gutter-buffer='buffer'] {
    background-size: 8px 8px;
    background-position: 0 0;
    background-origin: border-box;
    background-color: var(--diffs-bg);
    /* This is incredibley expensive... */
    background-image: repeating-linear-gradient(
      -45deg,
      transparent,
      transparent calc(3px * 1.414),
      rgb(from var(--diffs-bg-buffer) r g b / 0.8) calc(3px * 1.414),
      rgb(from var(--diffs-bg-buffer) r g b / 0.8) calc(4px * 1.414)
    );
  }

  [data-content-buffer] {
    grid-column: 1;
    /* We multiply by 1.414 (√2) to better approximate the diagonal repeat distance */
    background-size: 8px 8px;
    background-position: 5px 0;
    background-origin: border-box;
    background-color: var(--diffs-bg);
    /* This is incredibley expensive... */
    background-image: repeating-linear-gradient(
      -45deg,
      transparent,
      transparent calc(3px * 1.414),
      var(--diffs-bg-buffer) calc(3px * 1.414),
      var(--diffs-bg-buffer) calc(4px * 1.414)
    );
  }

  [data-separator] {
    box-sizing: content-box;
    background-color: var(--diffs-bg);
  }

  [data-separator='simple'] {
    min-height: 4px;
  }

  [data-separator='line-info'],
  [data-separator='line-info-basic'],
  [data-separator='metadata'],
  [data-separator='simple'] {
    background-color: var(--diffs-bg-separator);
  }

  [data-separator='line-info'],
  [data-separator='line-info-basic'],
  [data-separator='metadata'] {
    height: 32px;
    position: relative;
  }

  [data-separator-wrapper] {
    -webkit-user-select: none;
            user-select: none;
    fill: currentColor;
    position: absolute;
    inset-inline: 0;
    display: flex;
    align-items: center;
    background-color: var(--diffs-bg);
    height: 100%;
  }

  [data-content] [data-separator-wrapper] {
    display: none;
  }

  [data-separator='metadata'] [data-separator-wrapper] {
    inset-inline: 100% auto;
    padding-inline: 1ch;
    height: 100%;
    background-color: var(--diffs-bg-separator);
    color: var(--diffs-fg-number);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    min-width: min-content;
  }

  [data-separator='line-info'] {
    margin-block: var(--diffs-gap-block, var(--diffs-gap-fallback));
  }

  [data-separator='line-info-basic'],
  [data-separator='metadata'] {
    margin-block: 0;
  }

  [data-separator='line-info'][data-separator-first] {
    margin-top: 0;
  }

  [data-separator='line-info'][data-separator-last] {
    margin-bottom: 0;
  }

  [data-expand-index] [data-separator-wrapper] {
    display: grid;
    grid-template-columns: 32px auto;
  }

  [data-expand-index] [data-separator-wrapper][data-separator-multi-button] {
    grid-template-columns: 32px 32px auto;
  }

  [data-expand-button],
  [data-separator-content] {
    display: flex;
    flex: 0 0 auto;
    align-items: center;
    background-color: var(--diffs-bg-separator);
  }

  [data-expand-index] [data-separator-content]:hover {
    text-decoration: underline;
    cursor: pointer;
  }

  [data-expand-button] {
    justify-content: center;
    flex-shrink: 0;
    cursor: pointer;
    min-width: 32px;
    align-self: stretch;
    color: var(--diffs-fg-number);
    border-right: 2px solid var(--diffs-bg);

    &:hover {
      color: var(--diffs-fg);
    }

    &[data-expand-all-button] {
      display: none;
    }
  }

  [data-expand-down] [data-icon] {
    transform: scaleY(-1);
  }

  [data-separator-content] {
    flex: 1 1 auto;
    padding: 0 1ch;
    height: 100%;
    color: var(--diffs-fg-number);

    overflow: hidden;
    justify-content: flex-start;
  }

  [data-separator='line-info'],
  [data-separator='line-info-basic'] {
    [data-separator-content] {
      height: 100%;
      -webkit-user-select: none;
              user-select: none;
      overflow: clip;
    }
  }

  @supports (width: 1cqi) {
    [data-unified] {
      [data-separator='line-info'] [data-separator-wrapper] {
        padding-inline: var(--diffs-gap-inline, var(--diffs-gap-fallback));
        width: 100cqi;

        [data-separator-content] {
          border-radius: 6px;
        }
      }

      [data-separator='line-info'][data-expand-index]
        [data-separator-wrapper]
        [data-separator-content] {
        border-top-left-radius: unset;
        border-bottom-left-radius: unset;
      }
    }

    [data-gutter] {
      [data-separator='line-info'] [data-separator-wrapper] {
        padding-left: var(--diffs-gap-inline, var(--diffs-gap-fallback));
      }

      [data-separator='line-info'] [data-separator-content] {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px;
      }

      [data-separator='line-info'][data-expand-index] [data-separator-content] {
        border-top-left-radius: unset;
        border-bottom-left-radius: unset;
      }
    }

    [data-additions] {
      [data-content] [data-separator='line-info'] {
        background-color: var(--diffs-bg);

        [data-separator-wrapper] {
          display: none;
        }
      }

      [data-gutter] [data-separator='line-info'] [data-separator-wrapper] {
        display: block;
        height: 100%;
        background-color: var(--diffs-bg-separator);
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px;

        [data-separator-content],
        [data-expand-button] {
          display: none;
        }
      }
    }

    [data-overflow='scroll']
      [data-additions]
      [data-gutter]
      [data-separator='line-info']
      [data-separator-wrapper] {
      width: calc(100cqi - var(--diffs-gap-inline, var(--diffs-gap-fallback)));
    }

    [data-overflow='wrap']
      [data-additions]
      [data-content]
      [data-separator='line-info']
      [data-separator-wrapper] {
      background-color: var(--diffs-bg-separator);
      display: block;
      height: 100%;
      margin-right: var(--diffs-gap-inline, var(--diffs-gap-fallback));
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px;

      [data-separator-content],
      [data-expand-button] {
        display: none;
      }
    }

    [data-separator='line-info'] [data-separator-wrapper] {
      [data-expand-both],
      [data-expand-down],
      [data-expand-up] {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px;
      }
    }

    @media (pointer: fine) {
      [data-separator='line-info'] [data-separator-wrapper] {
        &[data-separator-multi-button] {
          [data-expand-up] {
            border-top-left-radius: 6px;
            border-bottom-left-radius: unset;
          }

          [data-expand-down] {
            border-bottom-left-radius: 6px;
            border-top-left-radius: unset;
          }
        }
      }
    }
  }

  @media (pointer: coarse) {
    [data-separator='line-info-basic']
      [data-separator-wrapper][data-separator-multi-button] {
      grid-template-columns: 34px 34px auto;

      [data-separator-content] {
        grid-column: unset;
        grid-row: unset;
      }
    }

    @supports (width: 1cqi) {
      [data-separator='line-info'] [data-separator-wrapper] {
        [data-expand-both],
        [data-expand-down],
        [data-expand-up] {
          border-top-left-radius: 6px;
          border-bottom-left-radius: 6px;
        }

        &[data-separator-multi-button] {
          [data-expand-up] {
            border-top-left-radius: 6px;
            border-bottom-left-radius: 6px;
          }

          [data-expand-down] {
            border-bottom-left-radius: unset;
            border-top-left-radius: unset;
          }
        }
      }
    }
  }

  @media (pointer: fine) {
    [data-separator-wrapper][data-separator-multi-button] {
      display: grid;
      grid-template-rows: 50% 50%;

      [data-separator-content] {
        grid-column: 2;
        grid-row: 1 / -1;
        min-width: min-content;
      }

      [data-expand-button] {
        grid-column: 1;
      }
    }

    [data-separator='line-info'] [data-separator-wrapper],
    [data-separator='line-info']
      [data-separator-wrapper][data-separator-multi-button] {
      grid-template-columns: 34px auto;
    }

    [data-separator='line-info-basic'][data-expand-index]
      [data-separator-wrapper] {
      grid-template-columns: 100% auto;
    }

    [data-separator='line-info'],
    [data-separator='line-info-basic'] {
      [data-separator-multi-button] {
        [data-expand-up] {
          border-bottom: 1px solid var(--diffs-bg);
          border-right: 2px solid var(--diffs-bg);
        }
        [data-expand-down] {
          border-top: 1px solid var(--diffs-bg);
          border-right: 2px solid var(--diffs-bg);
        }
      }
    }
  }

  [data-additions] [data-gutter] [data-separator-wrapper],
  [data-additions] [data-separator='line-info-basic'] [data-separator-wrapper],
  [data-content] [data-separator-wrapper] {
    display: none;
  }

  [data-line-annotation],
  [data-gutter-buffer='annotation'] {
    --diffs-line-bg: var(--diffs-bg-context);
  }

  [data-merge-conflict-actions],
  [data-gutter-buffer='merge-conflict-action'] {
    --diffs-line-bg: var(--diffs-bg-context);
  }

  [data-has-merge-conflict] [data-line-annotation],
  [data-has-merge-conflict] [data-gutter-buffer='annotation'] {
    --diffs-line-bg: var(--diffs-bg);
  }

  [data-has-merge-conflict] [data-gutter-buffer='merge-conflict-action'] {
    --diffs-line-bg: var(--diffs-bg);
  }

  [data-line-annotation] {
    min-height: var(--diffs-annotation-min-height, 0);
    z-index: 2;
  }

  [data-merge-conflict-actions] {
    z-index: 2;
  }

  [data-separator='custom'] {
    display: grid;
    grid-template-columns: subgrid;
  }

  [data-line],
  [data-column-number],
  [data-no-newline] {
    position: relative;
    padding-inline: 1ch;
  }

  [data-indicators='classic'] [data-line] {
    padding-inline-start: 2ch;
  }

  [data-indicators='classic'] {
    [data-line-type='change-addition'],
    [data-line-type='change-deletion'] {
      &[data-no-newline],
      &[data-line] {
        &::before {
          display: inline-block;
          width: 1ch;
          height: 1lh;
          position: absolute;
          top: 0;
          left: 0;
          -webkit-user-select: none;
                  user-select: none;
        }
      }
    }

    [data-line-type='change-addition'] {
      &[data-line],
      &[data-no-newline] {
        &::before {
          content: '+';
          color: var(--diffs-addition-base);
        }
      }
    }

    [data-line-type='change-deletion'] {
      &[data-line],
      &[data-no-newline] {
        &::before {
          content: '-';
          color: var(--diffs-deletion-base);
        }
      }
    }
  }

  [data-indicators='bars'] {
    [data-line-type='change-deletion'],
    [data-line-type='change-addition'] {
      &[data-column-number] {
        &::before {
          content: '';
          display: block;
          width: 4px;
          height: 100%;
          position: absolute;
          top: 0;
          left: 0;
          -webkit-user-select: none;
                  user-select: none;
          contain: strict;
        }
      }
    }

    [data-line-type='change-deletion'] {
      &[data-column-number] {
        &::before {
          background-image: linear-gradient(
            0deg,
            var(--diffs-bg-deletion) 50%,
            var(--diffs-deletion-base) 50%
          );
          background-repeat: repeat;
          background-size: 2px 2px;
          background-size: calc(1lh / round(1lh / 2px))
            calc(1lh / round(1lh / 2px));
        }
      }
    }

    [data-line-type='change-addition'] {
      &[data-column-number] {
        &::before {
          background-color: var(--diffs-addition-base);
        }
      }
    }
  }

  [data-overflow='wrap'] {
    [data-line],
    [data-annotation-content] {
      white-space: pre-wrap;
      word-break: break-word;
    }
  }

  [data-overflow='scroll'] [data-line] {
    white-space: pre;
    min-height: 1lh;
  }

  [data-column-number] {
    box-sizing: content-box;
    text-align: right;
    -webkit-user-select: none;
            user-select: none;
    background-color: var(--diffs-bg);
    color: var(--diffs-fg-number);
    padding-left: 2ch;
  }

  [data-line-number-content] {
    display: inline-block;
    min-width: var(
      --diffs-min-number-column-width,
      var(--diffs-min-number-column-width-default, 3ch)
    );
  }

  [data-disable-line-numbers] {
    [data-column-number] {
      min-width: 4px;
      padding: 0;
    }

    [data-line-number-content] {
      display: none;
    }

    [data-gutter-utility-slot] {
      right: unset;
      left: 0;
      justify-content: flex-start;
    }

    &[data-indicators='bars'] [data-gutter-utility-slot] {
      /* Using 5px here because theres a 1px separator after the bar */
      left: 5px;
    }
  }

  [data-file][data-disable-line-numbers] {
    [data-gutter-buffer],
    [data-column-number] {
      min-width: 0;
      border-right: 0;
    }
  }

  [data-interactive-line-numbers] [data-column-number] {
    cursor: pointer;
  }

  [data-diff-span] {
    border-radius: 3px;
    -webkit-box-decoration-break: clone;
            box-decoration-break: clone;
  }

  [data-line-type='change-addition'] {
    &[data-column-number] {
      color: var(
        --diffs-fg-number-addition-override,
        var(--diffs-addition-base)
      );
    }

    [data-diff-span] {
      background-color: var(--diffs-bg-addition-emphasis);
    }
  }

  [data-line-type='change-deletion'] {
    &[data-column-number] {
      color: var(
        --diffs-fg-number-deletion-override,
        var(--diffs-deletion-base)
      );
    }

    [data-diff-span] {
      background-color: var(--diffs-bg-deletion-emphasis);
    }
  }

  [data-background] [data-line-type='change-addition'] {
    --diffs-line-bg: var(--diffs-bg-addition);

    &[data-column-number] {
      background-color: var(--diffs-bg-addition-number);
    }
  }

  [data-background] [data-line-type='change-deletion'] {
    --diffs-line-bg: var(--diffs-bg-deletion);

    &[data-column-number] {
      background-color: var(--diffs-bg-deletion-number);
    }
  }

  [data-merge-conflict='marker-start'],
  [data-merge-conflict='marker-base'],
  [data-merge-conflict='marker-separator'],
  [data-merge-conflict='marker-end'] {
    padding-left: 1ch;
    color: var(--diffs-fg);
  }

  [data-merge-conflict='marker-start'],
  [data-merge-conflict='marker-end'] {
    display: flex;
    align-items: center;

    &::after {
      color: var(--diffs-fg-conflict-marker);
      font-style: normal;
      font-size: 0.75rem;
      line-height: 1.25rem;
      padding-left: 1ch;
      font-family: var(
        --diffs-header-font-family,
        var(--diffs-header-font-fallback)
      );
    }
  }

  [data-merge-conflict='marker-start']::after {
    content: '(Current Change)';
  }

  [data-merge-conflict='marker-end']::after {
    content: '(Incoming Change)';
  }

  [data-merge-conflict='marker-base'],
  [data-merge-conflict='marker-end'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--diffs-bg-conflict-marker);
    }

    &[data-column-number] {
      background-color: var(--diffs-bg-conflict-marker-number);
      color: var(--diffs-fg-conflict-marker);

      [data-line-number-content] {
        color: var(--diffs-fg-conflict-marker);
      }
    }
  }

  [data-merge-conflict='current'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--conflict-bg-current);
    }

    &[data-column-number] {
      background-color: var(--conflict-bg-current-number);
      color: var(--diffs-addition-base);
    }
  }

  [data-gutter-buffer='merge-conflict-marker-start'],
  [data-merge-conflict='marker-start'] {
    background-color: var(--conflict-bg-current-header);
  }

  [data-gutter-buffer='merge-conflict-marker-end'],
  [data-merge-conflict='marker-end'] {
    background-color: var(--conflict-bg-incoming-header);
  }

  [data-merge-conflict='marker-separator'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--diffs-bg);
    }

    &[data-column-number] {
      background-color: var(--diffs-bg);
    }
  }

  [data-merge-conflict='base'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--diffs-bg-conflict-base);
    }

    &[data-column-number] {
      background-color: var(--diffs-bg-conflict-base-number);
      color: var(--diffs-modified-base);
    }
  }

  [data-merge-conflict='incoming'] {
    &[data-line],
    &[data-no-newline] {
      background-color: var(--conflict-bg-incoming);
    }

    &[data-column-number] {
      background-color: var(--conflict-bg-incoming-number);
      color: var(--diffs-modified-base);
    }
  }

  @media (pointer: fine) {
    [data-column-number],
    [data-line] {
      &[data-hovered] {
        background-color: var(--diffs-bg-hover);
      }
    }

    [data-background] {
      [data-column-number],
      [data-line] {
        &[data-hovered] {
          &[data-line-type='change-deletion'] {
            background-color: var(--diffs-bg-deletion-hover);
          }

          &[data-line-type='change-addition'] {
            background-color: var(--diffs-bg-addition-hover);
          }
        }
      }
    }
  }

  [data-diffs-header='default'] {
    position: relative;
    background-color: var(--diffs-bg);
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));
    min-height: calc(
      1lh + (var(--diffs-gap-block, var(--diffs-gap-fallback)) * 3)
    );
    padding-inline: 16px;
    top: 0;
    z-index: 2;
  }

  [data-header-content] {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));
    min-width: 0;
    white-space: nowrap;
  }

  [data-header-content] [data-prev-name],
  [data-header-content] [data-title] {
    direction: rtl;
    overflow: hidden;
    text-overflow: ellipsis;
    min-width: 0;
    white-space: nowrap;
  }

  [data-prev-name] {
    opacity: 0.7;
  }

  [data-rename-icon] {
    fill: currentColor;
    flex-shrink: 0;
    flex-grow: 0;
  }

  [data-diffs-header='default'] [data-metadata] {
    display: flex;
    align-items: center;
    gap: 1ch;
    white-space: nowrap;
  }

  [data-diffs-header='default'] [data-additions-count] {
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
    color: var(--diffs-addition-base);
  }

  [data-diffs-header='default'] [data-deletions-count] {
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
    color: var(--diffs-deletion-base);
  }

  [data-annotation-content] {
    position: relative;
    display: flow-root;
    align-self: flex-start;
    z-index: 2;
    min-width: 0;
    isolation: isolate;
  }

  [data-merge-conflict-actions-content] {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    padding-inline: 0.5rem;
    min-height: 1.75rem;
    font-family: var(
      --diffs-header-font-family,
      var(--diffs-header-font-fallback)
    );
    font-size: 0.75rem;
    line-height: 1.2;
    color: var(--diffs-fg);
  }

  [data-merge-conflict-action] {
    appearance: none;
    border: 0;
    background: transparent;
    color: var(--diffs-fg-number);
    font: inherit;
    font-style: normal;
    cursor: pointer;
    padding: 0;
  }

  [data-merge-conflict-action]:hover {
    color: var(--diffs-fg);
  }

  [data-merge-conflict-action='current']:hover {
    color: var(--diffs-addition-base);
  }

  [data-merge-conflict-action='incoming']:hover {
    color: var(--diffs-modified-base);
  }

  [data-merge-conflict-action-separator] {
    color: var(--diffs-fg-number);
    opacity: 0.6;
    -webkit-user-select: none;
            user-select: none;
  }

  /* Sticky positioning has a composite costs, so we should _only_ pay it if we
   * need to */
  [data-overflow='scroll'] [data-annotation-content] {
    position: sticky;
    width: var(--diffs-column-content-width, auto);
    left: var(--diffs-column-number-width, 0);
  }

  [data-overflow='scroll'] [data-merge-conflict-actions-content] {
    position: sticky;
    width: var(--diffs-column-content-width, auto);
    left: var(--diffs-column-number-width, 0);
  }

  /* Undo some of the stuff that the 'pre' tag does */
  [data-annotation-slot] {
    text-wrap-mode: wrap;
    word-break: normal;
    white-space-collapse: collapse;
  }

  [data-change-icon] {
    fill: currentColor;
    flex-shrink: 0;
  }

  [data-change-icon='change'],
  [data-change-icon='rename-pure'],
  [data-change-icon='rename-changed'] {
    color: var(--diffs-modified-base);
  }

  [data-change-icon='new'] {
    color: var(--diffs-addition-base);
  }

  [data-change-icon='deleted'] {
    color: var(--diffs-deletion-base);
  }

  [data-change-icon='file'] {
    opacity: 0.6;
  }

  /* Line selection highlighting */
  [data-selected-line] {
    &[data-gutter-buffer='annotation'],
    &[data-column-number] {
      color: var(--diffs-selection-number-fg);
      background-color: var(--diffs-bg-selection-number);
    }

    &[data-line] {
      background-color: var(--diffs-bg-selection);
    }
  }

  [data-line-type='change-addition'],
  [data-line-type='change-deletion'] {
    &[data-selected-line] {
      &[data-line],
      &[data-line][data-hovered] {
        background-color: light-dark(
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 82%,
            var(--diffs-selection-base)
          ),
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 75%,
            var(--diffs-selection-base)
          )
        );
      }

      &[data-column-number],
      &[data-column-number][data-hovered] {
        color: var(--diffs-selection-number-fg);
        background-color: light-dark(
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 75%,
            var(--diffs-selection-base)
          ),
          color-mix(
            in lab,
            var(--diffs-line-bg, var(--diffs-bg)) 60%,
            var(--diffs-selection-base)
          )
        );
      }
    }
  }

  [data-gutter-utility-slot] {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    display: flex;
    justify-content: flex-end;
  }

  [data-unmodified-lines] {
    display: block;
    overflow: hidden;
    min-width: 0;
    text-overflow: ellipsis;
    white-space: nowrap;
    flex: 0 1 auto;
  }

  [data-error-wrapper] {
    overflow: auto;
    padding: var(--diffs-gap-block, var(--diffs-gap-fallback))
      var(--diffs-gap-inline, var(--diffs-gap-fallback));
    max-height: 400px;
    scrollbar-width: none;

    [data-error-message] {
      font-weight: bold;
      font-size: 18px;
      color: var(--diffs-deletion-base);
    }

    [data-error-stack] {
      color: var(--diffs-fg-number);
    }
  }

  [data-placeholder] {
    contain: strict;
  }

  [data-utility-button] {
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    appearance: none;
    width: 1lh;
    height: 1lh;
    margin-right: calc((1lh - 1ch) * -1);
    padding: 0;
    cursor: pointer;
    font-size: var(--diffs-font-size, 13px);
    line-height: var(--diffs-line-height, 20px);
    border-radius: 4px;
    background-color: var(--diffs-modified-base);
    color: var(--diffs-bg);
    fill: currentColor;
    position: relative;
    z-index: 4;
  }
}
`;const Gt="@layer base, theme, rendered, unsafe;";function Gi(e){return`${Gt}
@layer unsafe {
  ${e}
}`}function ji(e,t="system"){return`${Gt}
@layer rendered {
  :host {${t==="system"?"":`
  color-scheme: ${t};`}
  ${e}
  }
}`}function Be({code:e,pre:t,columnType:n,rowSpan:i,containerSize:r=!1}={}){return e==null&&(e=document.createElement("code"),e.setAttribute("data-code",""),n!=null&&e.setAttribute(`data-${n}`,""),t?.appendChild(e)),i!=null?e.style.setProperty("grid-row",`span ${i}`):e.style.removeProperty("grid-row"),r?e.setAttribute("data-container-size",""):e.removeAttribute("data-container-size"),e}function qi({shadowRoot:e,currentNode:t,themeCSS:n}){if(n.trim()===""){t?.remove();return}return t??=Ki(),t.textContent=n,t.parentNode!==e&&e.appendChild(t),t}function Ki(){const e=document.createElement("style");return e.setAttribute(Mt,""),e}function Xi(e,t){if(t==null)return;const n=e.shadowRoot??e.attachShadow({mode:"open"});n.innerHTML===""&&(n.innerHTML=t)}function Ji(e,{type:t,diffIndicators:n,disableBackground:i,disableLineNumbers:r,overflow:o,split:s,totalLines:l,customProperties:a}){if(a!=null)for(const d in a){const f=a[d];f!=null&&e.setAttribute(d,`${f}`)}switch(t==="diff"?(e.setAttribute("data-diff",""),e.removeAttribute("data-file")):(e.setAttribute("data-file",""),e.removeAttribute("data-diff")),n){case"bars":case"classic":e.setAttribute("data-indicators",n);break;case"none":e.removeAttribute("data-indicators");break}return r?e.setAttribute("data-disable-line-numbers",""):e.removeAttribute("data-disable-line-numbers"),i?e.removeAttribute("data-background"):e.setAttribute("data-background",""),t==="diff"?e.setAttribute("data-diff-type",s?"split":"single"):e.removeAttribute("data-diff-type"),e.setAttribute("data-overflow",o),e.tabIndex=0,e.style.setProperty("--diffs-min-number-column-width-default",`${`${l}`.length}ch`),e}if(typeof HTMLElement<"u"&&customElements.get(_e)==null){let e;class t extends HTMLElement{constructor(){if(super(),this.shadowRoot!=null)return;const i=this.attachShadow({mode:"open"});e==null&&(e=new CSSStyleSheet,e.replaceSync(Wi)),i.adoptedStyleSheets=[e]}}customElements.define(_e,t)}const Yi=!0;function Tt(e,t,n){if(e===t||e==null||t==null)return e===t;const i=new Set(n),r=Object.keys(e),o=new Set(Object.keys(t));for(const s of r)if(o.delete(s),!i.has(s)&&(!(s in t)||e[s]!==t[s]))return!1;for(const s of Array.from(o))if(!i.has(s))return!1;return!0}function Zi(e,t){const n=e?.theme??J,i=t?.theme??J,r=At(e),o=At(t);return Vt(n,i)&&Tt(e,t,["theme","parseDiffOptions"])&&Tt(r,o)}function At(e){if(e!=null&&"parseDiffOptions"in e)return e.parseDiffOptions}function Qi({hunkIndex:e,lineIndex:t,conflictIndex:n}){return`merge-conflict-action-${e}-${t}-${n}`}function er(e,t){const n=t.hunks[e.hunkIndex];if(n!=null)return{hunkIndex:e.hunkIndex,lineIndex:tr(n,e.startContentIndex)}}function tr(e,t){let n=e.unifiedLineStart;for(let i=0;i<t;i++){const r=e.hunkContent[i];n+=r.type==="context"?r.lines:r.deletions+r.additions}return n}function nr({fileDiff:e,actions:t,renderCustomHeader:n,renderHeaderPrefix:i,renderHeaderMetadata:r,renderAnnotation:o,renderGutterUtility:s,renderHoverUtility:l,renderMergeConflictUtility:a,lineAnnotations:d,getHoveredLine:f,getInstance:c}){const h=s??l,u=n?.(e),p=i?.(e),y=r?.(e);return U.jsxs(U.Fragment,{children:[u!=null?U.jsx("div",{slot:it,children:u}):U.jsxs(U.Fragment,{children:[p!=null&&U.jsx("div",{slot:tt,children:p}),y!=null&&U.jsx("div",{slot:nt,children:y})]}),o!=null&&d?.map((x,C)=>U.jsx("div",{slot:ge(x),children:o(x)},C)),t!=null&&a!=null&&c!=null&&t.map(x=>{if(x==null)return;const C=ir(x,e);return U.jsx("div",{slot:C,style:Qt,children:a(x,c)},C)}),h!=null&&U.jsx("div",{slot:"gutter-utility-slot",style:Zt,children:h(f)})]})}function ir(e,t){const n=er(e,t);return n!=null?Qi({hunkIndex:n.hunkIndex,lineIndex:n.lineIndex,conflictIndex:e.conflictIndex}):void 0}var rr=class{isDeletionsScrolling=!1;isAdditionsScrolling=!1;timeoutId=-1;codeDeletions;codeAdditions;enabled=!1;cleanUp(){this.enabled&&(this.codeDeletions?.removeEventListener("scroll",this.handleDeletionsScroll),this.codeAdditions?.removeEventListener("scroll",this.handleAdditionsScroll),clearTimeout(this.timeoutId),this.codeDeletions=void 0,this.codeAdditions=void 0,this.enabled=!1)}setup(e,t,n){if(t==null||n==null)for(const i of e.children??[])i instanceof HTMLElement&&("deletions"in i.dataset?t=i:"additions"in i.dataset&&(n=i));if(n==null||t==null){this.cleanUp();return}this.codeDeletions!==t&&(this.codeDeletions?.removeEventListener("scroll",this.handleDeletionsScroll),this.codeDeletions=t,t.addEventListener("scroll",this.handleDeletionsScroll,{passive:!0})),this.codeAdditions!==n&&(this.codeAdditions?.removeEventListener("scroll",this.handleAdditionsScroll),this.codeAdditions=n,n.addEventListener("scroll",this.handleAdditionsScroll,{passive:!0})),this.enabled=!0}handleDeletionsScroll=()=>{this.isAdditionsScrolling||(this.isDeletionsScrolling=!0,clearTimeout(this.timeoutId),this.timeoutId=setTimeout(()=>{this.isDeletionsScrolling=!1},300),this.codeAdditions?.scrollTo({left:this.codeDeletions?.scrollLeft}))};handleAdditionsScroll=()=>{this.isDeletionsScrolling||(this.isAdditionsScrolling=!0,clearTimeout(this.timeoutId),this.timeoutId=setTimeout(()=>{this.isAdditionsScrolling=!1},300),this.codeDeletions?.scrollTo({left:this.codeAdditions?.scrollLeft}))}};function Ce(e){return A({tagName:"div",properties:{"data-content-buffer":"","data-buffer-size":e,style:`grid-row: span ${e};min-height:calc(${e} * 1lh)`}})}function we(e){return A({tagName:"div",children:[A({tagName:"span",children:[Y("No newline at end of file")]})],properties:{"data-no-newline":"","data-line-type":e,"data-column-content":""}})}function We(e){return A({tagName:"div",children:[Ie({name:e==="both"?"diffs-icon-expand-all":"diffs-icon-expand",properties:{"data-icon":""}})],properties:{role:"button","data-expand-button":"","data-expand-both":e==="both"?"":void 0,"data-expand-up":e==="up"?"":void 0,"data-expand-down":e==="down"?"":void 0}})}function de({type:e,content:t,expandIndex:n,chunked:i=!1,slotName:r,isFirstHunk:o,isLastHunk:s}){let l=0;const a=[];if(e==="metadata"&&t!=null&&a.push(A({tagName:"div",children:[Y(t)],properties:{"data-separator-wrapper":""}})),(e==="line-info"||e==="line-info-basic")&&t!=null){const d=[];n!=null&&(i?(o||(d.push(We("up")),l++),s||(d.push(We("down")),l++)):(d.push(We(!o&&!s?"both":o?"down":"up")),l++)),d.push(A({tagName:"div",children:[A({tagName:"span",children:[Y(t)],properties:{"data-unmodified-lines":""}})],properties:{"data-separator-content":""}})),i&&n!=null&&d.push(A({tagName:"div",children:[Y("Expand all")],properties:{role:"button","data-expand-button":"","data-expand-all-button":""}})),a.push(A({tagName:"div",children:d,properties:{"data-separator-wrapper":"","data-separator-multi-button":l>1?"":void 0}}))}return e==="custom"&&r!=null&&a.push(A({tagName:"slot",properties:{name:r}})),A({tagName:"div",children:a,properties:{"data-separator":a.length===0?"simple":e,"data-expand-index":n,"data-separator-first":o?"":void 0,"data-separator-last":s?"":void 0}})}function or(e,t){return`hunk-separator-${e}-${t}`}function ar(e){const t=e.at(-1);return t==null?0:Math.max(t.additionStart+t.additionCount,t.deletionStart+t.deletionCount)}function sr(e){return e.startingLine===0&&e.totalLines===1/0&&e.bufferBefore===0&&e.bufferAfter===0}let lr=-1;var dr=class{__id=`diff-hunks-renderer:${++lr}`;highlighter;diff;expandedHunks=new Map;deletionAnnotations={};additionAnnotations={};computedLang="text";renderCache;constructor(e={theme:J},t,n){this.options=e,this.onRenderUpdate=t,this.workerManager=n,n?.isWorkingPool()!==!0&&(this.highlighter=Ve(e.theme??J)?zn():void 0)}cleanUp(){this.highlighter=void 0,this.diff=void 0,this.renderCache=void 0,this.workerManager?.cleanUpPendingTasks(this),this.workerManager=void 0,this.onRenderUpdate=void 0}recycle(){this.highlighter=void 0,this.diff=void 0,this.renderCache=void 0,this.workerManager?.cleanUpPendingTasks(this)}setOptions(e){this.options=e}mergeOptions(e){this.options={...this.options,...e}}expandHunk(e,t,n=this.getOptionsWithDefaults().expansionLineCount){const i={...this.expandedHunks.get(e)??{fromStart:0,fromEnd:0}};(t==="up"||t==="both")&&(i.fromStart+=n),(t==="down"||t==="both")&&(i.fromEnd+=n),this.renderCache?.highlighted!==!0&&(this.renderCache=void 0),this.expandedHunks.set(e,i)}getExpandedHunk(e){return this.expandedHunks.get(e)??dn}getExpandedHunksMap(){return this.expandedHunks}setLineAnnotations(e){this.additionAnnotations={},this.deletionAnnotations={};for(const t of e){const n=(()=>{switch(t.side){case"deletions":return this.deletionAnnotations;case"additions":return this.additionAnnotations}})(),i=n[t.lineNumber]??[];n[t.lineNumber]=i,i.push(t)}}getUnifiedLineDecoration({lineType:e}){return{gutterLineType:e}}getSplitLineDecoration({side:e,type:t}){return t!=="change"?{gutterLineType:t}:{gutterLineType:e==="deletions"?"change-deletion":"change-addition"}}createAnnotationElement(e){return Ai(e)}getOptionsWithDefaults(){const{diffIndicators:e="bars",diffStyle:t="split",disableBackground:n=!1,disableFileHeader:i=!1,disableLineNumbers:r=!1,disableVirtualizationBuffers:o=!1,collapsed:s=!1,expandUnchanged:l=!1,collapsedContextThreshold:a=fe,expansionLineCount:d=100,hunkSeparators:f="line-info",lineDiffType:c="word-alt",maxLineDiffLength:h=1e3,overflow:u="scroll",theme:p=J,headerRenderMode:y="default",tokenizeMaxLineLength:x=1e3,useTokenTransformer:C=!1,useCSSClasses:m=!1}=this.options;return{diffIndicators:e,diffStyle:t,disableBackground:n,disableFileHeader:i,disableLineNumbers:r,disableVirtualizationBuffers:o,collapsed:s,expandUnchanged:l,collapsedContextThreshold:a,expansionLineCount:d,hunkSeparators:f,lineDiffType:c,maxLineDiffLength:h,overflow:u,theme:this.workerManager?.getDiffRenderOptions().theme??p,headerRenderMode:y,tokenizeMaxLineLength:x,useTokenTransformer:C,useCSSClasses:m}}async initializeHighlighter(){return this.highlighter=await Un(Hi(this.computedLang,this.options)),this.highlighter}hydrate(e){if(e==null)return;this.diff=e;const{options:t}=this.getRenderOptions(e);let n=this.workerManager?.getDiffResultCache(e);n!=null&&!Fe(t,n.options)&&(n=void 0),this.renderCache??={diff:e,highlighted:!Yn(e),options:t,result:n?.result,renderRange:void 0},this.workerManager?.isWorkingPool()===!0?this.renderCache.result==null&&this.workerManager.highlightDiffAST(this,this.diff):this.highlighter==null&&(this.computedLang=e.lang??oe(e.name),this.initializeHighlighter())}getRenderOptions(e){const t=(()=>{if(this.workerManager?.isWorkingPool()===!0)return this.workerManager.getDiffRenderOptions();const{theme:i,tokenizeMaxLineLength:r,lineDiffType:o,maxLineDiffLength:s}=this.getOptionsWithDefaults();return{theme:i,useTokenTransformer:Oi(this.options),tokenizeMaxLineLength:r,lineDiffType:o,maxLineDiffLength:s}})();this.getOptionsWithDefaults();const{renderCache:n}=this;return n?.result==null?{options:t,forceRender:!0}:e!==n.diff||!Fe(t,n.options)?{options:t,forceRender:!0}:{options:t,forceRender:!1}}renderDiff(e=this.renderCache?.diff,t=lt){if(e==null)return;const{expandUnchanged:n=!1,collapsedContextThreshold:i}=this.getOptionsWithDefaults(),r=this.workerManager?.getDiffResultCache(e);r!=null&&this.renderCache==null&&(this.renderCache={diff:e,highlighted:!0,renderRange:void 0,...r});const{options:o,forceRender:s}=this.getRenderOptions(e);if(this.renderCache??={diff:e,highlighted:!1,options:o,result:void 0,renderRange:void 0},this.workerManager?.isWorkingPool()===!0)(this.renderCache.result==null||!this.renderCache.highlighted&&(e!==this.renderCache.diff||!Wt(this.renderCache.renderRange,t)))&&(this.renderCache.diff=e,this.renderCache.result=this.workerManager.getPlainDiffAST(e,t.startingLine,t.totalLines,sr(t)||n?!0:this.expandedHunks,i),this.renderCache.renderRange=t),t.totalLines>0&&(!this.renderCache.highlighted||s)&&this.workerManager.highlightDiffAST(this,e);else{this.computedLang=e.lang??oe(e.name);const l=this.highlighter!=null&&Ve(o.theme),a=this.highlighter!=null&&Lt(this.computedLang);if(this.highlighter!=null&&l&&(s||!this.renderCache.highlighted&&a||this.renderCache.result==null)){const{result:d,options:f}=this.renderDiffWithHighlighter(e,this.highlighter,!a);this.renderCache={diff:e,options:f,highlighted:a,result:d,renderRange:void 0}}(!l||!a)&&this.asyncHighlight(e).then(({result:d,options:f})=>{this.renderCache!=null&&(this.renderCache.highlighted=!1),this.onHighlightSuccess(e,d,f)})}return this.renderCache.result!=null?this.processDiffResult(this.renderCache.diff,t,this.renderCache.result):void 0}async asyncRender(e,t=lt){const{result:n}=await this.asyncHighlight(e);return this.processDiffResult(e,t,n)}createPreElement(e,t,n){const{diffIndicators:i,disableBackground:r,disableLineNumbers:o,overflow:s}=this.getOptionsWithDefaults();return Mi({type:"diff",diffIndicators:i,disableBackground:r,disableLineNumbers:o,overflow:s,split:e,totalLines:t,customProperties:n})}async asyncHighlight(e){this.computedLang=e.lang??oe(e.name);const t=this.highlighter!=null&&Ve(this.options.theme??J),n=this.highlighter!=null&&Lt(this.computedLang);return(this.highlighter==null||!t||!n)&&(this.highlighter=await this.initializeHighlighter()),this.renderDiffWithHighlighter(e,this.highlighter)}renderDiffWithHighlighter(e,t,n=!1){const{options:i}=this.getRenderOptions(e),{collapsedContextThreshold:r}=this.getOptionsWithDefaults();return{result:pi(e,t,i,{forcePlainText:n,expandedHunks:n?!0:void 0,collapsedContextThreshold:r}),options:i}}onHighlightSuccess(e,t,n){if(this.renderCache==null)return;const i=!this.renderCache.highlighted||!Fe(this.renderCache.options,n)||this.renderCache.diff!==e;this.renderCache={diff:e,options:n,highlighted:!0,result:t,renderRange:void 0},i&&this.onRenderUpdate?.()}onHighlightError(e){console.error(e)}processDiffResult(e,t,{code:n,themeStyles:i,baseThemeType:r}){const{diffStyle:o,disableFileHeader:s,expandUnchanged:l,expansionLineCount:a,collapsedContextThreshold:d,hunkSeparators:f}=this.getOptionsWithDefaults();this.diff=e;const c=o==="unified";let h=[],u=[],p=[];const y=[],{additionLines:x,deletionLines:C}=n,m={rowCount:0,hunkSeparators:f,additionsContentAST:h,deletionsContentAST:u,unifiedContentAST:p,unifiedGutterAST:ke(),deletionsGutterAST:ke(),additionsGutterAST:ke(),expansionLineCount:a,hunkData:y,incrementRowCount(R=1){m.rowCount+=R},pushToGutter(R,z){switch(R){case"unified":m.unifiedGutterAST.children.push(z);break;case"deletions":m.deletionsGutterAST.children.push(z);break;case"additions":m.additionsGutterAST.children.push(z);break}}},b=fr(e),v={size:0,side:void 0,increment(){this.size+=1},flush(){if(o!=="unified"){if(this.size<=0||this.side==null){this.side=void 0,this.size=0;return}this.side==="additions"?(m.pushToGutter("additions",G(void 0,"buffer",this.size)),h?.push(Ce(this.size))):(m.pushToGutter("deletions",G(void 0,"buffer",this.size)),u?.push(Ce(this.size))),this.size=0,this.side=void 0}}},S=(R,z,ae,te,P)=>{m.pushToGutter(R,Vn(z,ae,te,P))};function g(R){v.flush(),o==="unified"?Ge("unified",R,m):(Ge("deletions",R,m),Ge("additions",R,m))}Re({diff:e,diffStyle:o,startingLine:t.startingLine,totalLines:t.totalLines,expandedHunks:l?!0:this.expandedHunks,collapsedContextThreshold:d,callback:({hunkIndex:R,hunk:z,collapsedBefore:ae,collapsedAfter:te,additionLine:P,deletionLine:M,type:N})=>{const ne=M!=null?M.splitLineIndex:P.splitLineIndex,se=P!=null?P.unifiedLineIndex:M.unifiedLineIndex;o==="split"&&N!=="change"&&v.flush(),ae>0&&g({hunkIndex:R,collapsedLines:ae,rangeSize:Math.max(z?.collapsedBefore??0,0),hunkSpecs:z?.hunkSpecs,isFirstHunk:R===0,isLastHunk:!1,isExpandable:!e.isPartial});const ue=o==="unified"?se:ne,ve={type:N,hunkIndex:R,lineIndex:ue,unifiedLineIndex:se,splitLineIndex:ne,deletionLine:M,additionLine:P};if(o==="unified"){const D=this.getUnifiedInjectedRowsForLine?.(ve);D?.before!=null&&It(D.before,m);let F=M!=null?C[M.lineIndex]:void 0,$=P!=null?x[P.lineIndex]:void 0;if(F==null&&$==null){const V="DiffHunksRenderer.processDiffResult: deletionLine and additionLine are null, something is wrong";throw console.error(V,{file:e.name}),new Error(V)}const Q=N==="change"?P!=null?"change-addition":"change-deletion":N,W=this.getUnifiedLineDecoration({type:N,lineType:Q,additionLineIndex:P?.lineIndex,deletionLineIndex:M?.lineIndex});S("unified",W.gutterLineType,P!=null?P.lineNumber:M.lineNumber,`${se},${ne}`,W.gutterProperties),$!=null?$=Le($,W.contentProperties):F!=null&&(F=Le(F,W.contentProperties)),Pt({diffStyle:"unified",type:N,deletionLine:F,additionLine:$,unifiedSpan:this.getAnnotations("unified",M?.lineNumber,P?.lineNumber,R,ue),createAnnotationElement:V=>this.createAnnotationElement(V),context:m}),D?.after!=null&&It(D.after,m)}else{const D=this.getSplitInjectedRowsForLine?.(ve);D?.before!=null&&Rt(D.before,m,v);let F=M!=null?C[M.lineIndex]:void 0,$=P!=null?x[P.lineIndex]:void 0;const Q=this.getSplitLineDecoration({side:"deletions",type:N,lineIndex:M?.lineIndex}),W=this.getSplitLineDecoration({side:"additions",type:N,lineIndex:P?.lineIndex});if(F==null&&$==null){const q="DiffHunksRenderer.processDiffResult: deletionLine and additionLine are null, something is wrong";throw console.error(q,{file:e.name}),new Error(q)}const V=(()=>{if(N==="change"){if($==null)return"additions";if(F==null)return"deletions"}})();if(V!=null){if(v.side!=null&&v.side!==V)throw new Error("DiffHunksRenderer.processDiffResult: iterateOverDiff, invalid pending splits");v.side=V,v.increment()}const he=this.getAnnotations("split",M?.lineNumber,P?.lineNumber,R,ue);if(he!=null&&v.size>0&&v.flush(),M!=null){const q=Le(F,Q.contentProperties);S("deletions",Q.gutterLineType,M.lineNumber,`${M.unifiedLineIndex},${ne}`,Q.gutterProperties),q!=null&&(F=q)}if(P!=null){const q=Le($,W.contentProperties);S("additions",W.gutterLineType,P.lineNumber,`${P.unifiedLineIndex},${ne}`,W.gutterProperties),q!=null&&($=q)}Pt({diffStyle:"split",type:N,additionLine:$,deletionLine:F,...he,createAnnotationElement:q=>this.createAnnotationElement(q),context:m}),D?.after!=null&&Rt(D.after,m,v)}const ie=M?.noEOFCR??!1,Z=P?.noEOFCR??!1;if(Z||ie){if(ie){const D=N==="context"||N==="context-expanded"?N:"change-deletion";o==="unified"?(m.unifiedContentAST.push(we(D)),m.pushToGutter("unified",G(D,"metadata",1))):(m.deletionsContentAST.push(we(D)),m.pushToGutter("deletions",G(D,"metadata",1)),Z||(m.pushToGutter("additions",G(void 0,"buffer",1)),m.additionsContentAST.push(Ce(1))))}if(Z){const D=N==="context"||N==="context-expanded"?N:"change-addition";o==="unified"?(m.unifiedContentAST.push(we(D)),m.pushToGutter("unified",G(D,"metadata",1))):(m.additionsContentAST.push(we(D)),m.pushToGutter("additions",G(D,"metadata",1)),ie||(m.pushToGutter("deletions",G(void 0,"buffer",1)),m.deletionsContentAST.push(Ce(1))))}m.incrementRowCount(1)}te>0&&f!=="simple"&&g({hunkIndex:N==="context-expanded"?R:R+1,collapsedLines:te,rangeSize:b,hunkSpecs:void 0,isFirstHunk:!1,isLastHunk:!0,isExpandable:!e.isPartial}),m.incrementRowCount(1)}}),o==="split"&&v.flush();const k=Math.max(ar(e.hunks),e.additionLines.length??0,e.deletionLines.length??0),L=t.bufferBefore>0||t.bufferAfter>0,E=!c&&e.type!=="deleted",T=!c&&e.type!=="new",_=m.rowCount>0||L;h=E&&_?h:void 0,u=T&&_?u:void 0,p=c&&_?p:void 0;const I=this.createPreElement(u!=null&&h!=null,k);return{unifiedGutterAST:c&&_?m.unifiedGutterAST.children:void 0,unifiedContentAST:p,deletionsGutterAST:T&&_?m.deletionsGutterAST.children:void 0,deletionsContentAST:u,additionsGutterAST:E&&_?m.additionsGutterAST.children:void 0,additionsContentAST:h,hunkData:y,preNode:I,themeStyles:i,baseThemeType:r,headerElement:s?void 0:this.renderHeader(this.diff),totalLines:k,rowCount:m.rowCount,bufferBefore:t.bufferBefore,bufferAfter:t.bufferAfter,css:""}}renderCodeAST(e,t){const n=e==="unified"?t.unifiedGutterAST:e==="deletions"?t.deletionsGutterAST:t.additionsGutterAST,i=e==="unified"?t.unifiedContentAST:e==="deletions"?t.deletionsContentAST:t.additionsContentAST;if(n==null||i==null)return;const r=ke(n);return r.properties.style=`grid-row: span ${t.rowCount}`,[r,_i(i,t.rowCount)]}renderFullAST(e,t=[]){const n=this.getOptionsWithDefaults().hunkSeparators==="line-info",i=this.renderCodeAST("unified",e);if(i!=null)return t.push(A({tagName:"code",children:i,properties:{"data-code":"","data-container-size":n?"":void 0,"data-unified":""}})),{...e.preNode,children:t};const r=this.renderCodeAST("deletions",e);r!=null&&t.push(A({tagName:"code",children:r,properties:{"data-code":"","data-container-size":n?"":void 0,"data-deletions":""}}));const o=this.renderCodeAST("additions",e);return o!=null&&t.push(A({tagName:"code",children:o,properties:{"data-code":"","data-container-size":n?"":void 0,"data-additions":""}})),{...e.preNode,children:t}}renderFullHTML(e,t=[]){return me(this.renderFullAST(e,t))}renderPartialHTML(e,t){return t==null?me(e):me(A({tagName:"code",children:e,properties:{"data-code":"","data-container-size":this.getOptionsWithDefaults().hunkSeparators==="line-info"?"":void 0,[`data-${t}`]:""}}))}getAnnotations(e,t,n,i,r){const o={type:"annotation",hunkIndex:i,lineIndex:r,annotations:[]};if(t!=null)for(const l of this.deletionAnnotations[t]??[])o.annotations.push(ge(l));const s={type:"annotation",hunkIndex:i,lineIndex:r,annotations:[]};if(n!=null)for(const l of this.additionAnnotations[n]??[])(e==="unified"?o:s).annotations.push(ge(l));if(e==="unified")return o.annotations.length>0?o:void 0;if(!(s.annotations.length===0&&o.annotations.length===0))return{deletionSpan:o,additionSpan:s}}renderHeader(e){const{headerRenderMode:t}=this.getOptionsWithDefaults();return Ri({fileOrDiff:e,mode:t})}};function _t(e){return`${e} unmodified line${e>1?"s":""}`}function It(e,t){for(const n of e)t.unifiedContentAST.push(n.content),t.pushToGutter("unified",n.gutter),t.incrementRowCount(1)}function Rt(e,t,n){for(const{deletion:i,addition:r}of e){if(i==null&&r==null)continue;const o=i!=null&&r!=null?void 0:i==null?"deletions":"additions";(o==null||n.side!==o)&&n.flush(),i!=null&&(t.deletionsContentAST.push(i.content),t.pushToGutter("deletions",i.gutter)),r!=null&&(t.additionsContentAST.push(r.content),t.pushToGutter("additions",r.gutter)),o!=null&&(n.side=o,n.increment()),t.incrementRowCount(1)}}function Pt({diffStyle:e,type:t,deletionLine:n,additionLine:i,unifiedSpan:r,deletionSpan:o,additionSpan:s,createAnnotationElement:l,context:a}){let d=!1;if(e==="unified"){if(i!=null?a.unifiedContentAST.push(i):n!=null&&a.unifiedContentAST.push(n),r!=null){const f=t==="change"?n!=null?"change-deletion":"change-addition":t;a.unifiedContentAST.push(l(r)),a.pushToGutter("unified",G(f,"annotation",1)),d=!0}}else if(e==="split"){if(n!=null&&a.deletionsContentAST.push(n),i!=null&&a.additionsContentAST.push(i),o!=null){const f=t==="change"?n!=null?"change-deletion":"context":t;a.deletionsContentAST.push(l(o)),a.pushToGutter("deletions",G(f,"annotation",1)),d=!0}if(s!=null){const f=t==="change"?i!=null?"change-addition":"context":t;a.additionsContentAST.push(l(s)),a.pushToGutter("additions",G(f,"annotation",1)),d=!0}}d&&a.incrementRowCount(1)}function Ge(e,{hunkIndex:t,collapsedLines:n,rangeSize:i,hunkSpecs:r,isFirstHunk:o,isLastHunk:s,isExpandable:l},a){if(n<=0)return;const d=e==="unified"?a.unifiedContentAST:e==="deletions"?a.deletionsContentAST:a.additionsContentAST;if(a.hunkSeparators==="metadata"){r!=null&&(a.pushToGutter(e,de({type:"metadata",content:r,isFirstHunk:o,isLastHunk:s})),d.push(de({type:"metadata",content:r,isFirstHunk:o,isLastHunk:s})),e!=="additions"&&a.incrementRowCount(1));return}if(a.hunkSeparators==="simple"){t>0&&(a.pushToGutter(e,de({type:"simple",isFirstHunk:o,isLastHunk:!1})),d.push(de({type:"simple",isFirstHunk:o,isLastHunk:!1})),e!=="additions"&&a.incrementRowCount(1));return}const f=or(e,t),c=i>a.expansionLineCount,h=l?t:void 0;a.pushToGutter(e,de({type:a.hunkSeparators,content:_t(n),expandIndex:h,chunked:c,slotName:f,isFirstHunk:o,isLastHunk:s})),d.push(de({type:a.hunkSeparators,content:_t(n),expandIndex:h,chunked:c,slotName:f,isFirstHunk:o,isLastHunk:s})),e!=="additions"&&a.incrementRowCount(1),a.hunkData.push({slotName:f,hunkIndex:t,lines:n,type:e,expandable:l?{up:!o,down:!s,chunked:c}:void 0})}function Le(e,t){return e==null||e.type!=="element"||t==null?e:{...e,properties:{...e.properties,...t}}}function fr(e){const t=e.hunks.at(-1);if(t==null||e.isPartial||e.additionLines.length===0||e.deletionLines.length===0)return 0;const n=e.additionLines.length-(t.additionLineIndex+t.additionCount),i=e.deletionLines.length-(t.deletionLineIndex+t.deletionCount);if(n!==i)throw new Error(`DiffHunksRenderer.processDiffResult: trailing context mismatch (additions=${n}, deletions=${i}) for ${e.name}`);return Math.min(n,i)}function cr(e,t){return e.lineNumber===t.lineNumber&&e.side===t.side&&e.metadata===t.metadata}function ur(e,t){return e.slotName===t.slotName&&e.hunkIndex===t.hunkIndex&&e.lines===t.lines&&e.type===t.type&&e.expandable?.chunked===t.expandable?.chunked&&e.expandable?.up===t.expandable?.up&&e.expandable?.down===t.expandable?.down}function hr(e){const t=e[0];if(t!=="+"&&t!=="-"&&t!==" "&&t!=="\\"){console.error(`parseLineType: Invalid firstChar: "${t}", full line: "${e}"`);return}const n=e.substring(1);return{line:n===""?`
`:n,type:t===" "?"context":t==="\\"?"metadata":t==="+"?"addition":"deletion"}}function pr(e,t,n=!1){const i=Ee.test(e),r=e.split(i?Ee:st);let o;const s=[];for(const l of r){if(i&&!Ee.test(l)){if(o==null)o=l;else{if(n)throw Error("parsePatchContent: unknown file blob");console.error("parsePatchContent: unknown file blob:",l)}continue}else if(!i&&!st.test(l)){if(o==null)o=l;else{if(n)throw Error("parsePatchContent: unknown file blob");console.error("parsePatchContent: unknown file blob:",l)}continue}const a=jt(l,{cacheKey:void 0,isGitDiff:i,throwOnError:n});a!=null&&s.push(a)}return{patchMetadata:o,files:s}}function jt(e,{cacheKey:t,isGitDiff:n=Ee.test(e),oldFile:i,newFile:r,throwOnError:o=!1}={}){let s=0;const l=e.split(tn);let a;const d=i==null||r==null;let f=0,c=0;for(const h of l){const u=h.split(Me),p=u.shift();if(p==null){if(o)throw Error("parsePatchContent: invalid hunk");console.error("parsePatchContent: invalid hunk",h);continue}const y=p.match(nn);let x=0,C=0;if(y==null||a==null){if(a!=null){if(o)throw Error("parsePatchContent: Invalid hunk");console.error("parsePatchContent: Invalid hunk",h);continue}a={name:"",type:"change",hunks:[],splitLineCount:0,unifiedLineCount:0,isPartial:d,additionLines:!d&&i!=null&&r!=null?r.contents.split(Me):[],deletionLines:!d&&i!=null&&r!=null?i.contents.split(Me):[],cacheKey:t},a.additionLines.length===1&&r?.contents===""&&(a.additionLines.length=0),a.deletionLines.length===1&&i?.contents===""&&(a.deletionLines.length=0),u.unshift(p);for(const k of u){const L=k.match(n?on:rn);if(k.startsWith("diff --git")){const[,,E,,T]=k.trim().match(an)??[];a.name=T.trim(),E!==T&&(a.prevName=E.trim())}else if(L!=null){const[,E,T]=L;E==="---"&&T!=="/dev/null"?(a.prevName=T.trim(),a.name=T.trim()):E==="+++"&&T!=="/dev/null"&&(a.name=T.trim())}else if(n){if(k.startsWith("new mode ")&&(a.mode=k.replace("new mode","").trim()),k.startsWith("old mode ")&&(a.prevMode=k.replace("old mode","").trim()),k.startsWith("new file mode")&&(a.type="new",a.mode=k.replace("new file mode","").trim()),k.startsWith("deleted file mode")&&(a.type="deleted",a.mode=k.replace("deleted file mode","").trim()),k.startsWith("similarity index")&&(k.startsWith("similarity index 100%")?a.type="rename-pure":a.type="rename-changed"),k.startsWith("index ")){const[,E,T,_]=k.trim().match(sn)??[];E!=null&&(a.prevObjectId=E),T!=null&&(a.newObjectId=T),_!=null&&(a.mode=_)}k.startsWith("rename from ")&&(a.prevName=k.replace("rename from ","").trim()),k.startsWith("rename to ")&&(a.name=k.replace("rename to ","").trim())}}continue}let m,b;for(;u.length>0&&(u[u.length-1]===`
`||u[u.length-1]==="\r"||u[u.length-1]===`\r
`||u[u.length-1]==="");)u.pop();const v=parseInt(y[3]),S=parseInt(y[1]);f=d?f:S-1,c=d?c:v-1;const g={collapsedBefore:0,splitLineCount:0,splitLineStart:0,unifiedLineCount:0,unifiedLineStart:0,additionCount:parseInt(y[4]??"1"),additionStart:v,additionLines:x,deletionCount:parseInt(y[2]??"1"),deletionStart:S,deletionLines:C,deletionLineIndex:f,additionLineIndex:c,hunkContent:[],hunkContext:y[5],hunkSpecs:p,noEOFCRAdditions:!1,noEOFCRDeletions:!1};if(isNaN(g.additionCount)||isNaN(g.deletionCount)||isNaN(g.additionStart)||isNaN(g.deletionStart)){if(o)throw Error("parsePatchContent: invalid hunk metadata");console.error("parsePatchContent: invalid hunk metadata",g);continue}for(const k of u){const L=hr(k);if(L==null){console.error("processFile: invalid rawLine:",k);continue}const{type:E,line:T}=L;if(E==="addition")(m==null||m.type!=="change")&&(m=je("change",f,c),g.hunkContent.push(m)),c++,d&&a.additionLines.push(T),m.additions++,x++,b="addition";else if(E==="deletion")(m==null||m.type!=="change")&&(m=je("change",f,c),g.hunkContent.push(m)),f++,d&&a.deletionLines.push(T),m.deletions++,C++,b="deletion";else if(E==="context")(m==null||m.type!=="context")&&(m=je("context",f,c),g.hunkContent.push(m)),c++,f++,d&&(a.deletionLines.push(T),a.additionLines.push(T)),m.lines++,b="context";else if(E==="metadata"&&m!=null){if(m.type==="context"?(g.noEOFCRAdditions=!0,g.noEOFCRDeletions=!0):b==="deletion"?g.noEOFCRDeletions=!0:b==="addition"&&(g.noEOFCRAdditions=!0),d&&(b==="addition"||b==="context")){const _=a.additionLines.length-1;_>=0&&(a.additionLines[_]=ce(a.additionLines[_]))}if(d&&(b==="deletion"||b==="context")){const _=a.deletionLines.length-1;_>=0&&(a.deletionLines[_]=ce(a.deletionLines[_]))}}}g.additionLines=x,g.deletionLines=C,g.collapsedBefore=Math.max(g.additionStart-1-s,0),a.hunks.push(g),s=g.additionStart+g.additionCount-1;for(const k of g.hunkContent)k.type==="context"?(g.splitLineCount+=k.lines,g.unifiedLineCount+=k.lines):(g.splitLineCount+=Math.max(k.additions,k.deletions),g.unifiedLineCount+=k.deletions+k.additions);g.splitLineStart=a.splitLineCount+g.collapsedBefore,g.unifiedLineStart=a.unifiedLineCount+g.collapsedBefore,a.splitLineCount+=g.collapsedBefore+g.splitLineCount,a.unifiedLineCount+=g.collapsedBefore+g.unifiedLineCount}if(a!=null){if(a.hunks.length>0&&!d&&a.additionLines.length>0&&a.deletionLines.length>0){const h=a.hunks[a.hunks.length-1],u=h.additionStart+h.additionCount-1,p=a.additionLines.length,y=Math.max(p-u,0);a.splitLineCount+=y,a.unifiedLineCount+=y}return n||(a.prevName!=null&&a.name!==a.prevName?a.hunks.length>0?a.type="rename-changed":a.type="rename-pure":r!=null&&r.contents===""?a.type="deleted":i!=null&&i.contents===""&&(a.type="new")),a.type!=="rename-pure"&&a.type!=="rename-changed"&&(a.prevName=void 0),a}}function mr(e,t,n=!1){const i=[];for(const r of e.split(en))try{i.push(pr(r,t!=null?`${t}-${i.length}`:void 0,n))}catch(o){if(n)throw o;console.error(o)}return i}function je(e,t,n){return e==="change"?{type:"change",additions:0,deletions:0,additionLineIndex:n,deletionLineIndex:t}:{type:"context",lines:0,additionLineIndex:n,deletionLineIndex:t}}function et(e,t,n,i=!1){const r=jt(ci(e.name,t.name,e.contents,t.contents,e.header,t.header,n),{cacheKey:(()=>{if(e.cacheKey!=null&&t.cacheKey!=null)return`${e.cacheKey}:${t.cacheKey}`})(),oldFile:e,newFile:t,throwOnError:i});if(r==null)throw new Error("parseDiffFrom: FileInvalid diff -- probably need to fix something -- if the files are the same maybe?");return t.lang!=null&&(r.lang=t.lang),r}let gr=-1;var qt=class{static LoadedCustomComponent=Yi;__id=`file-diff:${++gr}`;fileContainer;spriteSVG;pre;codeUnified;codeDeletions;codeAdditions;bufferBefore;bufferAfter;themeCSSStyle;appliedThemeCSS;unsafeCSSStyle;appliedUnsafeCSS;gutterUtilityContent;headerElement;headerPrefix;headerMetadata;headerCustom;separatorCache=new Map;errorWrapper;placeHolder;hunksRenderer;resizeManager;scrollSyncManager;interactionManager;annotationCache=new Map;lineAnnotations=[];deletionFile;additionFile;fileDiff;renderRange;appliedPreAttributes;lastRenderedHeaderHTML;lastRowCount;enabled=!0;constructor(e={theme:J},t,n=!1){this.options=e,this.workerManager=t,this.isContainerManaged=n,this.hunksRenderer=this.createHunksRenderer(e),this.resizeManager=new Ti,this.scrollSyncManager=new rr,this.interactionManager=new Si("diff",kt(e,typeof e.hunkSeparators=="function"||(e.hunkSeparators??"line-info")==="line-info"||e.hunkSeparators==="line-info-basic"?this.handleExpandHunk:void 0,this.getLineIndex)),this.workerManager?.subscribeToThemeChanges(this),this.enabled=!0}handleHighlightRender=()=>{this.rerender()};getHunksRendererOptions(e){return{...e,headerRenderMode:e.renderCustomHeader!=null?"custom":"default",hunkSeparators:typeof e.hunkSeparators=="function"?"custom":e.hunkSeparators}}createHunksRenderer(e){return new dr(this.getHunksRendererOptions(e),this.handleHighlightRender,this.workerManager)}getLineIndex=(e,t="additions")=>{if(this.fileDiff==null)return;const n=this.fileDiff.hunks.at(-1);let i,r;e:for(const o of this.fileDiff.hunks){let s=t==="deletions"?o.deletionStart:o.additionStart;const l=t==="deletions"?o.deletionCount:o.additionCount;let a=o.splitLineStart,d=o.unifiedLineStart;if(e<s){const f=s-e;i=Math.max(d-f,0),r=Math.max(a-f,0);break e}if(e>=s+l){if(o===n){const f=e-(s+l);i=d+o.unifiedLineCount+f,r=a+o.splitLineCount+f;break e}continue}for(const f of o.hunkContent)if(f.type==="context")if(e<s+f.lines){const c=e-s;r=a+c,i=d+c;break e}else s+=f.lines,a+=f.lines,d+=f.lines;else{const c=t==="deletions"?f.deletions:f.additions;if(e<s+c){const h=e-s;i=d+(t==="additions"?f.deletions:0)+h,r=a+h;break e}else s+=c,a+=Math.max(f.deletions,f.additions),d+=f.deletions+f.additions}break e}if(!(i==null||r==null))return[i,r]};setOptions(e){e!=null&&(this.options=e,this.hunksRenderer.setOptions(this.getHunksRendererOptions(e)),this.interactionManager.setOptions(kt(e,typeof e.hunkSeparators=="function"||(e.hunkSeparators??"line-info")==="line-info"||e.hunkSeparators==="line-info-basic"?this.handleExpandHunk:void 0,this.getLineIndex)))}mergeOptions(e){this.options={...this.options,...e}}setThemeType(e){(this.options.themeType??"system")!==e&&(this.mergeOptions({themeType:e}),!(typeof this.options.theme=="string"||this.fileContainer==null||this.appliedThemeCSS==null)&&this.applyThemeState(this.fileContainer,this.appliedThemeCSS.themeStyles,e,this.appliedThemeCSS.baseThemeType))}getHoveredLine=()=>this.interactionManager.getHoveredLine();setLineAnnotations(e){this.lineAnnotations=e}canPartiallyRender(e,t,n){return!(e||t||n||typeof this.options.hunkSeparators=="function")}setSelectedLines(e){this.interactionManager.setSelection(e)}cleanUp(e=!1){this.resizeManager.cleanUp(),this.interactionManager.cleanUp(),this.scrollSyncManager.cleanUp(),this.workerManager?.unsubscribeToThemeChanges(this),this.renderRange=void 0,this.isContainerManaged||this.fileContainer?.remove(),this.fileContainer?.shadowRoot!=null&&(this.fileContainer.shadowRoot.innerHTML=""),this.fileContainer=void 0,this.pre!=null&&(this.pre.innerHTML="",this.pre=void 0),this.codeUnified=void 0,this.codeDeletions=void 0,this.codeAdditions=void 0,this.bufferBefore=void 0,this.bufferAfter=void 0,this.appliedPreAttributes=void 0,this.headerElement=void 0,this.headerPrefix=void 0,this.headerMetadata=void 0,this.headerCustom=void 0,this.lastRenderedHeaderHTML=void 0,this.errorWrapper=void 0,this.spriteSVG=void 0,this.lastRowCount=void 0,this.themeCSSStyle=void 0,this.appliedThemeCSS=void 0,this.unsafeCSSStyle=void 0,this.appliedUnsafeCSS=void 0,e?this.hunksRenderer.recycle():(this.hunksRenderer.cleanUp(),this.workerManager=void 0,this.fileDiff=void 0,this.deletionFile=void 0,this.additionFile=void 0),this.enabled=!1}virtualizedSetup(){this.enabled=!0,this.workerManager?.subscribeToThemeChanges(this)}hydrate(e){const{fileContainer:t,prerenderedHTML:n,preventEmit:i=!1,lineAnnotations:r,oldFile:o,newFile:s,fileDiff:l}=e;this.hydrateElements(t,n),this.pre==null&&this.headerElement==null?this.render({...e,preventEmit:!0}):this.hydrationSetup({fileDiff:l,oldFile:o,newFile:s,lineAnnotations:r}),i||this.emitPostRender()}hydrateElements(e,t){Xi(e,t);for(const n of e.shadowRoot?.children??[]){if(n instanceof SVGElement){this.spriteSVG=n;continue}if(n instanceof HTMLElement){if(n instanceof HTMLPreElement){this.pre=n;for(const i of n.children)!(i instanceof HTMLElement)||i.tagName.toLowerCase()!=="code"||("deletions"in i.dataset&&(this.codeDeletions=i),"additions"in i.dataset&&(this.codeAdditions=i),"unified"in i.dataset&&(this.codeUnified=i));continue}if("diffsHeader"in n.dataset){this.headerElement=n;continue}if(n instanceof HTMLStyleElement&&n.hasAttribute(Mt)){this.themeCSSStyle=n;continue}if(n instanceof HTMLStyleElement&&n.hasAttribute(Nt)){this.unsafeCSSStyle=n,this.appliedUnsafeCSS=n.textContent;continue}}}this.pre!=null&&(this.syncCodeNodesFromPre(this.pre),this.pre.removeAttribute("data-dehydrated")),(this.pre!=null||this.headerElement!=null)&&(this.fileContainer=e)}hydrationSetup({fileDiff:e,oldFile:t,newFile:n,lineAnnotations:i}){const{diffStyle:r="split",overflow:o="scroll"}=this.options;this.lineAnnotations=i??this.lineAnnotations,this.additionFile=n,this.deletionFile=t,this.fileDiff=e??(t!=null&&n!=null?et(t,n,this.options.parseDiffOptions):void 0),this.pre!=null&&(this.hunksRenderer.hydrate(this.fileDiff),this.renderAnnotations(),this.renderGutterUtility(),this.injectUnsafeCSS(),this.interactionManager.setup(this.pre),this.resizeManager.setup(this.pre,o==="wrap"),o==="scroll"&&r==="split"&&this.scrollSyncManager.setup(this.pre,this.codeDeletions,this.codeAdditions))}rerender(){!this.enabled||this.fileDiff==null&&this.additionFile==null&&this.deletionFile==null||this.render({forceRender:!0,renderRange:this.renderRange})}handleExpandHunk=(e,t,n)=>{this.expandHunk(e,t,n)};expandHunk=(e,t,n)=>{this.hunksRenderer.expandHunk(e,t,n),this.rerender()};render({oldFile:e,newFile:t,fileDiff:n,forceRender:i=!1,preventEmit:r=!1,lineAnnotations:o,fileContainer:s,containerWrapper:l,renderRange:a}){if(!this.enabled)throw new Error("FileDiff.render: attempting to call render after cleaned up");const{collapsed:d=!1}=this.options,f=d?void 0:a,c=e!=null&&t!=null&&(!ht(e,this.deletionFile)||!ht(t,this.additionFile));let h=n!=null&&n!==this.fileDiff;const u=o!=null&&(o.length>0||this.lineAnnotations.length>0)?o!==this.lineAnnotations:!1;if(!d&&Wt(f,this.renderRange)&&!i&&!u&&(n!=null&&n===this.fileDiff||n==null&&!c))return!1;const{renderRange:p}=this;if(this.renderRange=f,this.deletionFile=e,this.additionFile=t,n!=null?this.fileDiff=n:e!=null&&t!=null&&c&&(h=!0,this.fileDiff=et(e,t,this.options.parseDiffOptions)),o!=null&&this.setLineAnnotations(o),this.fileDiff==null)return!1;this.hunksRenderer.setOptions(this.getHunksRendererOptions(this.options)),this.hunksRenderer.setLineAnnotations(this.lineAnnotations);const{diffStyle:y="split",disableErrorHandling:x=!1,disableFileHeader:C=!1,overflow:m="scroll",themeType:b="system"}=this.options;if(C&&(this.headerElement!=null&&(this.headerElement.remove(),this.headerElement=void 0,this.lastRenderedHeaderHTML=void 0),this.clearHeaderSlots()),s=this.getOrCreateFileContainer(s,l),d){this.removeRenderedCode(),this.clearAuxiliaryNodes();try{const v=this.hunksRenderer.renderDiff(this.fileDiff,fn);v!=null&&this.applyThemeState(s,v.themeStyles,b,v.baseThemeType),v?.headerElement!=null&&this.applyHeaderToDOM(v.headerElement,s),this.renderSeparators([]),this.injectUnsafeCSS()}catch(v){if(x)throw v;console.error(v),v instanceof Error&&this.applyErrorToDOM(v,s)}return r||this.emitPostRender(),!0}try{const v=this.getOrCreatePreNode(s);if(!(this.canPartiallyRender(i,u,c||h)&&this.applyPartialRender({previousRenderRange:p,renderRange:f}))){const S=this.hunksRenderer.renderDiff(this.fileDiff,f);if(S==null)return this.workerManager?.isInitialized()===!1&&this.workerManager.initialize().then(()=>this.rerender()),!1;this.applyThemeState(s,S.themeStyles,b,S.baseThemeType),S.headerElement!=null&&this.applyHeaderToDOM(S.headerElement,s),S.additionsContentAST!=null||S.deletionsContentAST!=null||S.unifiedContentAST!=null?this.applyHunksToDOM(v,S):this.pre!=null&&(this.pre.remove(),this.pre=void 0),this.renderSeparators(S.hunkData)}this.applyBuffers(v,f),this.injectUnsafeCSS(),this.renderAnnotations(),this.renderGutterUtility(),this.interactionManager.setup(v),this.resizeManager.setup(v,m==="wrap"),m==="scroll"&&y==="split"?this.scrollSyncManager.setup(v,this.codeDeletions,this.codeAdditions):this.scrollSyncManager.cleanUp()}catch(v){if(x)throw v;console.error(v),v instanceof Error&&this.applyErrorToDOM(v,s)}return r||this.emitPostRender(),!0}emitPostRender(){this.fileContainer!=null&&this.options.onPostRender?.(this.fileContainer,this)}removeRenderedCode(){this.resizeManager.cleanUp(),this.scrollSyncManager.cleanUp(),this.interactionManager.cleanUp(),this.bufferBefore?.remove(),this.bufferBefore=void 0,this.bufferAfter?.remove(),this.bufferAfter=void 0,this.codeUnified?.remove(),this.codeUnified=void 0,this.codeDeletions?.remove(),this.codeDeletions=void 0,this.codeAdditions?.remove(),this.codeAdditions=void 0,this.pre?.remove(),this.pre=void 0,this.appliedPreAttributes=void 0,this.lastRowCount=void 0}clearAuxiliaryNodes(){for(const{element:e}of this.separatorCache.values())e.remove();this.separatorCache.clear();for(const{element:e}of this.annotationCache.values())e.remove();this.annotationCache.clear(),this.gutterUtilityContent?.remove(),this.gutterUtilityContent=void 0}renderPlaceholder(e){if(this.fileContainer==null)return!1;if(this.cleanChildNodes(),this.placeHolder==null){const t=this.fileContainer.shadowRoot??this.fileContainer.attachShadow({mode:"open"});this.placeHolder=document.createElement("div"),this.placeHolder.dataset.placeholder="",t.appendChild(this.placeHolder)}return this.placeHolder.style.setProperty("height",`${e}px`),!0}cleanChildNodes(){this.resizeManager.cleanUp(),this.scrollSyncManager.cleanUp(),this.interactionManager.cleanUp(),this.bufferAfter?.remove(),this.bufferBefore?.remove(),this.codeAdditions?.remove(),this.codeDeletions?.remove(),this.codeUnified?.remove(),this.errorWrapper?.remove(),this.headerElement?.remove(),this.gutterUtilityContent?.remove(),this.headerPrefix?.remove(),this.headerMetadata?.remove(),this.headerCustom?.remove(),this.pre?.remove(),this.spriteSVG?.remove(),this.themeCSSStyle?.remove(),this.unsafeCSSStyle?.remove(),this.bufferAfter=void 0,this.bufferBefore=void 0,this.codeAdditions=void 0,this.codeDeletions=void 0,this.codeUnified=void 0,this.errorWrapper=void 0,this.headerElement=void 0,this.gutterUtilityContent=void 0,this.headerPrefix=void 0,this.headerMetadata=void 0,this.headerCustom=void 0,this.pre=void 0,this.spriteSVG=void 0,this.themeCSSStyle=void 0,this.appliedThemeCSS=void 0,this.unsafeCSSStyle=void 0,this.appliedUnsafeCSS=void 0,this.lastRenderedHeaderHTML=void 0,this.lastRowCount=void 0}renderSeparators(e){const{hunkSeparators:t}=this.options;if(this.isContainerManaged||this.fileContainer==null||typeof t!="function"){for(const{element:i}of this.separatorCache.values())i.remove();this.separatorCache.clear();return}const n=new Map(this.separatorCache);for(const i of e){const r=i.slotName;let o=this.separatorCache.get(r);if(o==null||!ur(i,o.hunkData)){o?.element.remove();const s=document.createElement("div");s.style.display="contents",s.slot=i.slotName;const l=t(i,this);l!=null&&s.appendChild(l),this.fileContainer.appendChild(s),o={element:s,hunkData:i},this.separatorCache.set(r,o)}n.delete(r)}for(const[i,{element:r}]of n.entries())this.separatorCache.delete(i),r.remove()}renderAnnotations(){if(this.isContainerManaged||this.fileContainer==null){for(const{element:n}of this.annotationCache.values())n.remove();this.annotationCache.clear();return}const e=new Map(this.annotationCache),{renderAnnotation:t}=this.options;if(t!=null&&this.lineAnnotations.length>0)for(const[n,i]of this.lineAnnotations.entries()){const r=`${n}-${ge(i)}`;let o=this.annotationCache.get(r);if(o==null||!cr(i,o.annotation)){o?.element.remove();const s=t(i);if(s==null)continue;o={element:$i(ge(i)),annotation:i},o.element.appendChild(s),this.fileContainer.appendChild(o.element),this.annotationCache.set(r,o)}e.delete(r)}for(const[n,{element:i}]of e.entries())this.annotationCache.delete(n),i.remove()}renderGutterUtility(){const e=this.options.renderGutterUtility??this.options.renderHoverUtility;if(this.fileContainer==null||e==null){this.gutterUtilityContent?.remove(),this.gutterUtilityContent=void 0;return}const t=e(this.interactionManager.getHoveredLine);if(t!=null&&this.gutterUtilityContent!=null)return;if(t==null){this.gutterUtilityContent?.remove(),this.gutterUtilityContent=void 0;return}const n=Vi();n.appendChild(t),this.fileContainer.appendChild(n),this.gutterUtilityContent=n}getOrCreateFileContainer(e,t){const n=this.fileContainer;if(this.fileContainer=e??this.fileContainer??document.createElement(_e),n!=null&&n!==this.fileContainer&&(this.lastRenderedHeaderHTML=void 0,this.headerElement=void 0),t!=null&&this.fileContainer.parentNode!==t&&t.appendChild(this.fileContainer),this.spriteSVG==null){const i=document.createElement("div");i.innerHTML=Ui;const r=i.firstChild;r instanceof SVGElement&&(this.spriteSVG=r,this.fileContainer.shadowRoot?.appendChild(this.spriteSVG))}return this.fileContainer}getFileContainer(){return this.fileContainer}getOrCreatePreNode(e){const t=e.shadowRoot??e.attachShadow({mode:"open"});return this.pre==null?(this.pre=document.createElement("pre"),this.appliedPreAttributes=void 0,this.codeUnified=void 0,this.codeDeletions=void 0,this.codeAdditions=void 0,t.appendChild(this.pre)):this.pre.parentNode!==t&&(t.appendChild(this.pre),this.appliedPreAttributes=void 0),this.placeHolder?.remove(),this.placeHolder=void 0,this.pre}syncCodeNodesFromPre(e){this.codeUnified=void 0,this.codeDeletions=void 0,this.codeAdditions=void 0;for(const t of Array.from(e.children))t instanceof HTMLElement&&(t.hasAttribute("data-unified")?this.codeUnified=t:t.hasAttribute("data-deletions")?this.codeDeletions=t:t.hasAttribute("data-additions")&&(this.codeAdditions=t))}applyHeaderToDOM(e,t){this.cleanupErrorWrapper(),this.placeHolder?.remove(),this.placeHolder=void 0;const{fileDiff:n}=this,i=me(e);if(i!==this.lastRenderedHeaderHTML){const d=document.createElement("div");d.innerHTML=i;const f=d.firstElementChild;if(!(f instanceof HTMLElement))return;this.headerElement!=null?t.shadowRoot?.replaceChild(f,this.headerElement):t.shadowRoot?.prepend(f),this.headerElement=f,this.lastRenderedHeaderHTML=i}if(this.isContainerManaged||n==null)return;const{renderCustomHeader:r,renderHeaderPrefix:o,renderHeaderMetadata:s}=this.options;if(r!=null){const d=r(n)??void 0;this.headerCustom=this.upsertHeaderSlotElement(t,this.headerCustom,it,d),this.headerPrefix?.remove(),this.headerMetadata?.remove(),this.headerPrefix=void 0,this.headerMetadata=void 0;return}const l=o?.(n)??void 0,a=s?.(n)??void 0;this.headerPrefix=this.upsertHeaderSlotElement(t,this.headerPrefix,tt,l),this.headerMetadata=this.upsertHeaderSlotElement(t,this.headerMetadata,nt,a),this.headerCustom?.remove(),this.headerCustom=void 0}clearHeaderSlots(){this.headerPrefix?.remove(),this.headerMetadata?.remove(),this.headerCustom?.remove(),this.headerPrefix=void 0,this.headerMetadata=void 0,this.headerCustom=void 0}upsertHeaderSlotElement(e,t,n,i){if(i==null){t?.remove();return}const r=t??this.createHeaderSlotElement(n);return t==null&&e.appendChild(r),this.replaceHeaderSlotContent(r,i),r}replaceHeaderSlotContent(e,t){e.replaceChildren(),t instanceof Element?e.appendChild(t):e.innerText=`${t}`}createHeaderSlotElement(e){const t=document.createElement("div");return t.slot=e,t}injectUnsafeCSS(){const{unsafeCSS:e}=this.options,t=this.fileContainer?.shadowRoot;if(t!=null){if(e==null||e===""){this.unsafeCSSStyle!=null&&(this.unsafeCSSStyle.remove(),this.unsafeCSSStyle=void 0),this.appliedUnsafeCSS=void 0;return}this.unsafeCSSStyle?.parentNode===t&&this.appliedUnsafeCSS===e||(this.unsafeCSSStyle??=Bi(),this.unsafeCSSStyle.parentNode!==t&&t.appendChild(this.unsafeCSSStyle),this.unsafeCSSStyle.textContent=Gi(e),this.appliedUnsafeCSS=e)}}applyThemeState(e,t,n,i){const r=e.shadowRoot??e.attachShadow({mode:"open"}),o=i??n;this.themeCSSStyle?.parentNode===r&&this.appliedThemeCSS?.themeStyles===t&&this.appliedThemeCSS.themeType===o||(this.themeCSSStyle=qi({shadowRoot:r,currentNode:this.themeCSSStyle,themeCSS:ji(t,o)}),this.appliedThemeCSS=this.themeCSSStyle!=null?{themeStyles:t,themeType:o,baseThemeType:i}:void 0)}applyHunksToDOM(e,t){const{overflow:n="scroll"}=this.options,i=(this.options.hunkSeparators??"line-info")==="line-info",r=n==="wrap"?t.rowCount:void 0;this.cleanupErrorWrapper(),this.applyPreNodeAttributes(e,t);let o=!1;const s=[],l=this.hunksRenderer.renderCodeAST("unified",t),a=this.hunksRenderer.renderCodeAST("deletions",t),d=this.hunksRenderer.renderCodeAST("additions",t);l!=null?(o=this.codeUnified==null||this.codeAdditions!=null||this.codeDeletions!=null,this.codeDeletions?.remove(),this.codeDeletions=void 0,this.codeAdditions?.remove(),this.codeAdditions=void 0,this.codeUnified=Be({code:this.codeUnified,columnType:"unified",rowSpan:r,containerSize:i}),this.codeUnified.innerHTML=this.hunksRenderer.renderPartialHTML(l),s.push(this.codeUnified)):a!=null||d!=null?(a!=null?(o=this.codeDeletions==null||this.codeUnified!=null,this.codeUnified?.remove(),this.codeUnified=void 0,this.codeDeletions=Be({code:this.codeDeletions,columnType:"deletions",rowSpan:r,containerSize:i}),this.codeDeletions.innerHTML=this.hunksRenderer.renderPartialHTML(a),s.push(this.codeDeletions)):(this.codeDeletions?.remove(),this.codeDeletions=void 0),d!=null?(o=o||this.codeAdditions==null||this.codeUnified!=null,this.codeUnified?.remove(),this.codeUnified=void 0,this.codeAdditions=Be({code:this.codeAdditions,columnType:"additions",rowSpan:r,containerSize:i}),this.codeAdditions.innerHTML=this.hunksRenderer.renderPartialHTML(d),s.push(this.codeAdditions)):(this.codeAdditions?.remove(),this.codeAdditions=void 0)):(this.codeUnified?.remove(),this.codeUnified=void 0,this.codeDeletions?.remove(),this.codeDeletions=void 0,this.codeAdditions?.remove(),this.codeAdditions=void 0),s.length===0?e.textContent="":o&&e.replaceChildren(...s),this.lastRowCount=t.rowCount}applyPartialRender({previousRenderRange:e,renderRange:t}){const{pre:n,codeUnified:i,codeAdditions:r,codeDeletions:o,options:{diffStyle:s="split"}}=this;if(n==null||e==null||t==null||!Number.isFinite(e.totalLines)||!Number.isFinite(t.totalLines)||this.lastRowCount==null)return!1;const l=this.getCodeColumns(s,i,o,r);if(l==null)return!1;const a=e.startingLine,d=t.startingLine,f=a+e.totalLines,c=d+t.totalLines,h=Math.max(a,d),u=Math.min(f,c);if(u<=h)return!1;const p=Math.max(0,h-a),y=Math.max(0,f-u),x=this.trimColumns({columns:l,trimStart:p,trimEnd:y,previousStart:a,overlapStart:h,overlapEnd:u,diffStyle:s});if(x<0)throw new Error("applyPartialRender: failed to trim to overlap");if(this.lastRowCount<x)throw new Error("applyPartialRender: trimmed beyond DOM row count");let C=this.lastRowCount-x;const m=(g,k)=>{if(!(k<=0||this.fileDiff==null))return this.hunksRenderer.renderDiff(this.fileDiff,{startingLine:g,totalLines:k,bufferBefore:0,bufferAfter:0})},b=m(d,Math.max(h-d,0));if(b==null&&d<h)return!1;const v=m(u,Math.max(c-u,0));if(v==null&&c>u)return!1;const S=(g,k)=>{if(g!=null){if(s==="unified"&&!Array.isArray(l))this.insertPartialHTML(s,l,g,k);else if(s==="split"&&Array.isArray(l))this.insertPartialHTML(s,l,g,k);else throw new Error("FileDiff.applyPartialRender.applyChunk: invalid chunk application");C+=g.rowCount}};return this.cleanupErrorWrapper(),S(b,"afterbegin"),S(v,"beforeend"),this.lastRowCount!==C&&(this.applyRowSpan(s,l,C),this.lastRowCount=C),!0}insertPartialHTML(e,t,n,i){if(e==="unified"&&!Array.isArray(t)){const r=this.hunksRenderer.renderCodeAST("unified",n);this.renderPartialColumn(t,r,i)}else if(e==="split"&&Array.isArray(t)){const r=this.hunksRenderer.renderCodeAST("deletions",n),o=this.hunksRenderer.renderCodeAST("additions",n);this.renderPartialColumn(t[0],r,i),this.renderPartialColumn(t[1],o,i)}else throw new Error("FileDiff.insertPartialHTML: Invalid argument composition")}renderPartialColumn(e,t,n){if(e==null||t==null)return;const i=Dt(t[0]),r=Dt(t[1]);if(i==null||r==null)throw new Error("FileDiff.insertPartialHTML: Unexpected AST structure");const o=r.at(0);n==="beforeend"&&o?.type==="element"&&typeof o.properties["data-buffer-size"]=="number"&&this.mergeBuffersIfNecessary(o.properties["data-buffer-size"],e.content.children[e.content.children.length-1],e.gutter.children[e.gutter.children.length-1],i,r,!0);const s=r.at(-1);n==="afterbegin"&&s?.type==="element"&&typeof s.properties["data-buffer-size"]=="number"&&this.mergeBuffersIfNecessary(s.properties["data-buffer-size"],e.content.children[0],e.gutter.children[0],i,r,!1),e.gutter.insertAdjacentHTML(n,this.hunksRenderer.renderPartialHTML(i)),e.content.insertAdjacentHTML(n,this.hunksRenderer.renderPartialHTML(r))}mergeBuffersIfNecessary(e,t,n,i,r,o){if(!(t instanceof HTMLElement)||!(n instanceof HTMLElement))return;const s=this.getBufferSize(t.dataset);s!=null&&(o?(i.shift(),r.shift()):(i.pop(),r.pop()),this.updateBufferSize(t,s+e),this.updateBufferSize(n,s+e))}applyRowSpan(e,t,n){const i=r=>{r!=null&&(r.gutter.style.setProperty("grid-row",`span ${n}`),r.content.style.setProperty("grid-row",`span ${n}`))};if(e==="unified"&&!Array.isArray(t))i(t);else if(e==="split"&&Array.isArray(t))i(t[0]),i(t[1]);else throw new Error("dun fuuuuked up")}trimColumnRows(e,t,n){let i=0,r=0,o=0,s=!1;const l=n>=0;if(e==null)return 0;const a=Array.from(e.content.children),d=Array.from(e.gutter.children);if(a.length!==d.length)throw new Error("FileDiff.trimColumnRows: columns do not match");for(;o<a.length&&!(t<=0&&!l&&!s);){const f=d[o],c=a[o];if(o++,!(f instanceof HTMLElement)||!(c instanceof HTMLElement))throw console.error({gutterElement:f,contentElement:c}),new Error("FileDiff.trimColumnRows: invalid row elements");if(s&&(s=!1,f.dataset.gutterBuffer==="annotation"&&"lineAnnotation"in c.dataset||f.dataset.gutterBuffer==="metadata"&&"noNewline"in c.dataset)){f.remove(),c.remove(),r++;continue}if("lineIndex"in f.dataset&&"lineIndex"in c.dataset){(t>0||l&&i>=n)&&(f.remove(),c.remove(),t>0&&(t--,t===0&&(s=!0)),r++),i++;continue}if("separator"in f.dataset&&"separator"in c.dataset){(t>0||l&&i>=n)&&(f.remove(),c.remove(),r++);continue}if(f.dataset.gutterBuffer==="annotation"&&"lineAnnotation"in c.dataset){(t>0||l&&i>=n)&&(f.remove(),c.remove(),r++);continue}if(f.dataset.gutterBuffer==="metadata"&&"noNewline"in c.dataset){(t>0||l&&i>=n)&&(f.remove(),c.remove(),r++);continue}if(f.dataset.gutterBuffer==="buffer"&&"contentBuffer"in c.dataset){const h=this.getBufferSize(c.dataset);if(h==null)throw new Error("FileDiff.trimColumnRows: invalid element");if(t>0){const u=Math.min(t,h),p=h-u;p>0?(this.updateBufferSize(f,p),this.updateBufferSize(c,p),r+=u):(f.remove(),c.remove(),r+=h),t-=u}else if(l){const u=i,p=i+h-1;if(n<=u)f.remove(),c.remove(),r+=h;else if(n<=p){const y=p-n+1,x=h-y;this.updateBufferSize(f,x),this.updateBufferSize(c,x),r+=y}}i+=h;continue}throw console.error({gutterElement:f,contentElement:c}),new Error("FileDiff.trimColumnRows: unknown row elements")}return r}trimColumns({columns:e,diffStyle:t,overlapEnd:n,overlapStart:i,previousStart:r,trimEnd:o,trimStart:s}){const l=Math.max(0,i-r),a=n-r;if(a<0)throw new Error("FileDiff.trimColumns: overlap ends before previous");const d=s>0,f=o>0;if(!d&&!f)return 0;const c=d?l:0,h=f?a:-1;if(t==="unified"&&!Array.isArray(e))return this.trimColumnRows(e,c,h);if(t==="split"&&Array.isArray(e)){const u=this.trimColumnRows(e[0],c,h),p=this.trimColumnRows(e[1],c,h);if(e[0]!=null&&e[1]!=null&&u!==p)throw new Error("FileDiff.trimColumns: split columns out of sync");return e[0]!=null?u:p}else throw console.error({diffStyle:t,columns:e}),new Error("FileDiff.trimColumns: Invalid columns for diffType")}getBufferSize(e){const t=Number.parseInt(e?.bufferSize??"",10);return Number.isNaN(t)?void 0:t}updateBufferSize(e,t){e.dataset.bufferSize=`${t}`,e.style.setProperty("grid-row",`span ${t}`),e.style.setProperty("min-height",`calc(${t} * 1lh)`)}getCodeColumns(e,t,n,i){function r(o){if(o==null)return;const s=o.children[0],l=o.children[1];if(!(!(s instanceof HTMLElement)||!(l instanceof HTMLElement)||s.dataset.gutter==null||l.dataset.content==null))return{gutter:s,content:l}}if(e==="unified")return r(t);{const o=r(n),s=r(i);return o!=null||s!=null?[o,s]:void 0}}applyBuffers(e,t){const{disableVirtualizationBuffers:n=!1}=this.options;if(n||t==null){this.bufferBefore!=null&&(this.bufferBefore.remove(),this.bufferBefore=void 0),this.bufferAfter!=null&&(this.bufferAfter.remove(),this.bufferAfter=void 0);return}t.bufferBefore>0?(this.bufferBefore==null&&(this.bufferBefore=document.createElement("div"),this.bufferBefore.dataset.virtualizerBuffer="before",e.before(this.bufferBefore)),this.bufferBefore.style.setProperty("height",`${t.bufferBefore}px`),this.bufferBefore.style.setProperty("contain","strict")):this.bufferBefore!=null&&(this.bufferBefore.remove(),this.bufferBefore=void 0),t.bufferAfter>0?(this.bufferAfter==null&&(this.bufferAfter=document.createElement("div"),this.bufferAfter.dataset.virtualizerBuffer="after",e.after(this.bufferAfter)),this.bufferAfter.style.setProperty("height",`${t.bufferAfter}px`),this.bufferAfter.style.setProperty("contain","strict")):this.bufferAfter!=null&&(this.bufferAfter.remove(),this.bufferAfter=void 0)}applyPreNodeAttributes(e,{additionsContentAST:t,deletionsContentAST:n,totalLines:i},r){const{diffIndicators:o="bars",disableBackground:s=!1,disableLineNumbers:l=!1,overflow:a="scroll",diffStyle:d="split"}=this.options,f={type:"diff",diffIndicators:o,disableBackground:s,disableLineNumbers:l,overflow:a,split:d==="unified"?!1:t!=null&&n!=null,totalLines:i,customProperties:r};zi(f,this.appliedPreAttributes)||(Ji(e,f),this.appliedPreAttributes=f)}applyErrorToDOM(e,t){this.cleanupErrorWrapper();const n=this.getOrCreatePreNode(t);n.innerHTML="",n.remove(),this.pre=void 0,this.appliedPreAttributes=void 0;const i=t.shadowRoot??t.attachShadow({mode:"open"});this.errorWrapper??=document.createElement("div"),this.errorWrapper.dataset.errorWrapper="",this.errorWrapper.innerHTML="",i.appendChild(this.errorWrapper);const r=document.createElement("div");r.dataset.errorMessage="",r.innerText=e.message,this.errorWrapper.appendChild(r);const o=document.createElement("pre");o.dataset.errorStack="",o.innerText=e.stack??"No Error Stack",this.errorWrapper.appendChild(o)}cleanupErrorWrapper(){this.errorWrapper?.remove(),this.errorWrapper=void 0}};function Dt(e){if(!(e==null||e.type!=="element"))return e.children??[]}function br(e,t){const n={...ln,...t};return n.hunkSeparatorHeight=vr(e,t?.hunkSeparatorHeight),n}function vr(e,t){if(t!=null)return t;switch(e){case"simple":return 4;case"metadata":case"line-info":case"line-info-basic":case"custom":return 32}}let yr=-1;var kr=class extends qt{__id=`little-virtualized-file-diff:${++yr}`;top;height=0;metrics;heightCache=new Map;isVisible=!1;virtualizer;constructor(e,t,n,i,r=!1){super(e,i,r);const{hunkSeparators:o="line-info"}=this.options;this.virtualizer=t,this.metrics=br(typeof o=="function"?"custom":o,n)}getLineHeight(e,t=!1){const n=this.heightCache.get(e);if(n!=null)return n;const i=t?2:1;return this.metrics.lineHeight*i}setOptions(e){if(e==null)return;const t=this.options.diffStyle,n=this.options.overflow,i=this.options.collapsed;super.setOptions(e),(t!==this.options.diffStyle||n!==this.options.overflow||i!==this.options.collapsed)&&(this.heightCache.clear(),this.computeApproximateSize(),this.renderRange=void 0),this.virtualizer.instanceChanged(this)}reconcileHeights(){const{overflow:e="scroll"}=this.options;if(this.fileContainer!=null&&(this.top=this.virtualizer.getOffsetInScrollContainer(this.fileContainer)),this.fileContainer==null||this.fileDiff==null){this.height=0;return}if(e==="scroll"&&this.lineAnnotations.length===0&&!this.virtualizer.config.resizeDebugging)return;const t=this.getDiffStyle();let n=!1;const i=t==="split"?[this.codeDeletions,this.codeAdditions]:[this.codeUnified];for(const r of i){if(r==null)continue;const o=r.children[1];if(o instanceof HTMLElement)for(const s of o.children){if(!(s instanceof HTMLElement))continue;const l=s.dataset.lineIndex;if(l==null)continue;const a=Sr(l,t);let d=s.getBoundingClientRect().height,f=!1;s.nextElementSibling instanceof HTMLElement&&("lineAnnotation"in s.nextElementSibling.dataset||"noNewline"in s.nextElementSibling.dataset)&&("noNewline"in s.nextElementSibling.dataset&&(f=!0),d+=s.nextElementSibling.getBoundingClientRect().height);const c=this.getLineHeight(a,f);d!==c&&(n=!0,d===this.metrics.lineHeight*(f?2:1)?this.heightCache.delete(a):this.heightCache.set(a,d))}}(n||this.virtualizer.config.resizeDebugging)&&this.computeApproximateSize()}onRender=e=>this.fileContainer==null?!1:(e&&(this.top=this.virtualizer.getOffsetInScrollContainer(this.fileContainer)),this.render());cleanUp(){this.fileContainer!=null&&this.virtualizer.disconnect(this.fileContainer),super.cleanUp()}expandHunk=(e,t,n)=>{this.hunksRenderer.expandHunk(e,t,n),this.computeApproximateSize(),this.renderRange=void 0,this.virtualizer.instanceChanged(this)};setVisibility(e){this.fileContainer!=null&&(this.renderRange=void 0,e&&!this.isVisible?(this.top=this.virtualizer.getOffsetInScrollContainer(this.fileContainer),this.isVisible=!0):!e&&this.isVisible&&(this.isVisible=!1,this.rerender()))}computeApproximateSize(){const e=this.height===0;if(this.height=0,this.fileDiff==null)return;const{disableFileHeader:t=!1,expandUnchanged:n=!1,collapsed:i=!1,collapsedContextThreshold:r=fe,hunkSeparators:o="line-info"}=this.options,{diffHeaderHeight:s,fileGap:l,hunkSeparatorHeight:a}=this.metrics,d=this.getDiffStyle(),f=o!=="simple"&&o!=="metadata"&&o!=="line-info-basic"?l:0;if(t?o!=="simple"&&o!=="metadata"&&(this.height+=l):this.height+=s,!i&&(Re({diff:this.fileDiff,diffStyle:d,expandedHunks:n?!0:this.hunksRenderer.getExpandedHunksMap(),collapsedContextThreshold:r,callback:({hunkIndex:c,collapsedBefore:h,collapsedAfter:u,deletionLine:p,additionLine:y})=>{const x=y!=null?y.splitLineIndex:p.splitLineIndex,C=y!=null?y.unifiedLineIndex:p.unifiedLineIndex,m=(y?.noEOFCR??!1)||(p?.noEOFCR??!1);h>0&&(c>0&&(this.height+=f),this.height+=a+f),this.height+=this.getLineHeight(d==="split"?x:C,m),u>0&&o!=="simple"&&(this.height+=f+a)}}),this.fileDiff.hunks.length>0&&(this.height+=l),this.fileContainer!=null&&this.virtualizer.config.resizeDebugging&&!e)){const c=this.fileContainer.getBoundingClientRect();c.height!==this.height?console.log("VirtualizedFileDiff.computeApproximateSize: computed height doesnt match",{name:this.fileDiff.name,elementHeight:c.height,computedHeight:this.height}):console.log("VirtualizedFileDiff.computeApproximateSize: computed height IS CORRECT")}}render({fileContainer:e,oldFile:t,newFile:n,fileDiff:i,...r}={}){const o=this.fileContainer==null;if(this.fileDiff??=i??(t!=null&&n!=null?et(t,n,this.options.parseDiffOptions):void 0),e=this.getOrCreateFileContainer(e),this.fileDiff==null)return console.error("VirtualizedFileDiff.render: attempting to virtually render when we dont have the correct data"),!1;if(o?(this.computeApproximateSize(),this.virtualizer.connect(e,this),this.top??=this.virtualizer.getOffsetInScrollContainer(e),this.isVisible=this.virtualizer.isInstanceVisible(this.top,this.height)):this.top??=this.virtualizer.getOffsetInScrollContainer(e),!this.isVisible)return this.renderPlaceholder(this.height);const s=this.virtualizer.getWindowSpecs(),l=this.computeRenderRangeFromWindow(this.fileDiff,this.top,s);return super.render({fileDiff:this.fileDiff,fileContainer:e,renderRange:l,oldFile:t,newFile:n,...r})}getDiffStyle(){return this.options.diffStyle??"split"}getExpandedRegion(e,t,n){if(n<=0||e)return{fromStart:0,fromEnd:0,collapsedLines:Math.max(n,0),renderAll:!1};const{expandUnchanged:i=!1,collapsedContextThreshold:r=fe}=this.options;if(i||n<=r)return{fromStart:n,fromEnd:0,collapsedLines:0,renderAll:!0};const o=this.hunksRenderer.getExpandedHunk(t),s=Math.min(Math.max(o.fromStart,0),n),l=Math.min(Math.max(o.fromEnd,0),n),a=s+l,d=a>=n;return{fromStart:s,fromEnd:l,collapsedLines:Math.max(n-a,0),renderAll:d}}getExpandedLineCount(e,t){let n=0;if(e.isPartial){for(const r of e.hunks)n+=t==="split"?r.splitLineCount:r.unifiedLineCount;return n}for(const[r,o]of e.hunks.entries()){const s=t==="split"?o.splitLineCount:o.unifiedLineCount;n+=s;const l=Math.max(o.collapsedBefore,0),{fromStart:a,fromEnd:d,renderAll:f}=this.getExpandedRegion(e.isPartial,r,l);l>0&&(n+=f?l:a+d)}const i=e.hunks.at(-1);if(i!=null&&xr(e)){const r=e.additionLines.length-(i.additionLineIndex+i.additionCount),o=e.deletionLines.length-(i.deletionLineIndex+i.deletionCount);if(i!=null&&r!==o)throw new Error(`VirtualizedFileDiff: trailing context mismatch (additions=${r}, deletions=${o}) for ${e.name}`);const s=Math.min(r,o);if(i!=null&&s>0){const{fromStart:l,renderAll:a}=this.getExpandedRegion(e.isPartial,e.hunks.length,s);n+=a?s:l}}return n}computeRenderRangeFromWindow(e,t,{top:n,bottom:i}){const{disableFileHeader:r=!1,expandUnchanged:o=!1,collapsedContextThreshold:s=fe,hunkSeparators:l="line-info"}=this.options,{diffHeaderHeight:a,fileGap:d,hunkLineCount:f,hunkSeparatorHeight:c,lineHeight:h}=this.metrics,u=this.getDiffStyle(),p=this.height,y=this.getExpandedLineCount(e,u),x=r?d:a;if(t<n-p||t>i)return{startingLine:0,totalLines:0,bufferBefore:0,bufferAfter:p-x-d};if(y<=f||e.hunks.length===0)return{startingLine:0,totalLines:f,bufferBefore:0,bufferAfter:0};const C=Math.ceil(Math.max(i-n,0)/h),m=Math.ceil(C/f)*f+f,b=m/f,v=b,S=[],g=(n+i)/2,k=l==="simple"||l==="metadata"||l==="line-info-basic"?0:d;let L=t+x,E=0,T,_,I;if(Re({diff:e,diffStyle:u,expandedHunks:o?!0:this.hunksRenderer.getExpandedHunksMap(),collapsedContextThreshold:s,callback:({hunkIndex:se,collapsedBefore:ue,collapsedAfter:ve,deletionLine:ie,additionLine:Z})=>{const D=Z!=null?Z.splitLineIndex:ie.splitLineIndex,F=Z!=null?Z.unifiedLineIndex:ie.unifiedLineIndex,$=(Z?.noEOFCR??!1)||(ie?.noEOFCR??!1);let Q=ue>0?c+k+(se>0?k:0):0;se===0&&l==="simple"&&(Q=0),L+=Q;const W=E%f===0;if(W&&(S.push(L-(t+x+Q)),I!=null)){if(I<=0)return!0;I--}const V=this.getLineHeight(u==="split"?D:F,$),he=Math.floor(E/f);return L>n-V&&L<i&&(T??=he),_==null&&L+V>g&&(_=he),I==null&&L>=i&&W&&(I=v),E++,L+=V,ve>0&&l!=="simple"&&(L+=c+k),!1}}),T==null)return{startingLine:0,totalLines:0,bufferBefore:0,bufferAfter:p-x-d};const R=S.length;_??=T;const z=Math.round(_-b/2),ae=Math.max(0,R-b),te=Math.max(0,Math.min(z,ae)),P=te*f,M=z<0?m+z*f:m,N=S[te]??0,ne=te+M/f;return{startingLine:P,totalLines:M,bufferBefore:N,bufferAfter:ne<S.length?p-x-S[ne]-d:p-(L-t)-d}}};function xr(e){const t=e.hunks.at(-1);return t==null||e.isPartial||e.additionLines.length===0||e.deletionLines.length===0?!1:t.additionLineIndex+t.additionCount<e.additionLines.length||t.deletionLineIndex+t.deletionCount<e.deletionLines.length}function Sr(e,t){const[n,i]=e.split(",").map(Number);return t==="split"?i:n}const Cr=typeof window>"u"?B.useEffect:B.useLayoutEffect;function wr({fileDiff:e,options:t,lineAnnotations:n,selectedLines:i,prerenderedHTML:r,metrics:o,hasGutterRenderUtility:s,hasCustomHeader:l,disableWorkerPool:a}){const d=hn(),f=B.useContext(vi),c=B.useRef(null),h=yi(u=>{if(u!=null){if(c.current!=null)throw new Error("useFileDiffInstance: An instance should not already exist when a node is created");d!=null?c.current=new kr(qe({hasCustomHeader:l,hasGutterRenderUtility:s,options:t}),d,o,a?void 0:f,!0):c.current=new qt(qe({hasCustomHeader:l,hasGutterRenderUtility:s,options:t}),a?void 0:f,!0),c.current.hydrate({fileDiff:e,fileContainer:u,lineAnnotations:n,prerenderedHTML:r})}else{if(c.current==null)throw new Error("useFileDiffInstance: A FileDiff instance should exist when unmounting");c.current.cleanUp(),c.current=null}});return Cr(()=>{const{current:u}=c;if(u==null)return;const p=qe({hasCustomHeader:l,hasGutterRenderUtility:s,options:t}),y=!Zi(u.options,p);u.setOptions(p),u.render({forceRender:y,fileDiff:e,lineAnnotations:n}),i!==void 0&&u.setSelectedLines(i)}),{ref:h,getHoveredLine:B.useCallback(()=>c.current?.getHoveredLine(),[])}}function qe({options:e,hasCustomHeader:t,hasGutterRenderUtility:n}){return n||t?{...e,renderCustomHeader:t?at:void 0,renderGutterUtility:n?at:void 0}:e}function Lr(e){const t=mr(e);if(t.length!==1)throw console.error(t),new Error("PatchDiff: Provided patch must include only 1 patch, with 1 diff");const{files:n}=t[0];if(n.length!==1)throw console.error(n),new Error("FileDiff: Provided patch must contain exactly 1 file diff");return n[0]}function Er({patch:e,options:t,metrics:n,lineAnnotations:i,selectedLines:r,className:o,style:s,prerenderedHTML:l,renderAnnotation:a,renderCustomHeader:d,renderHeaderPrefix:f,renderHeaderMetadata:c,renderGutterUtility:h,renderHoverUtility:u,disableWorkerPool:p=!1}){const y=Tr(e),{ref:x,getHoveredLine:C}=wr({fileDiff:y,options:t,metrics:n,lineAnnotations:i,selectedLines:r,prerenderedHTML:l,hasGutterRenderUtility:h!=null||u!=null,hasCustomHeader:d!=null,disableWorkerPool:p});return U.jsx(_e,{ref:x,className:o,style:s,children:cn(nr({fileDiff:y,renderCustomHeader:d,renderHeaderPrefix:f,renderHeaderMetadata:c,renderAnnotation:a,lineAnnotations:i,renderGutterUtility:h,renderHoverUtility:u,getHoveredLine:C}),l)})}function Tr(e){return B.useMemo(()=>Lr(e),[e])}const Ar={dark:"dark-plus",light:"light-plus"},_r={"--diffs-font-family":'"JetBrains Mono", ui-monospace, monospace',"--diffs-header-font-family":'"JetBrains Mono", ui-monospace, monospace',"--diffs-font-size":"13px","--diffs-line-height":"1.5","--diffs-light-bg":"hsl(var(--code-background))","--diffs-dark-bg":"hsl(var(--code-background))"},Ir=`
[data-code] {
  overflow-x: auto;
}

[data-line] {
  min-width: max-content;
}

[data-diff] {
  margin: 0;
}

[data-separator='simple'] {
  min-height: 6px;
  background:
    linear-gradient(
      to bottom,
      transparent,
      transparent calc(50% - 1px),
      color-mix(in srgb, currentColor 12%, transparent) calc(50% - 1px),
      color-mix(in srgb, currentColor 12%, transparent) calc(50% + 1px),
      transparent calc(50% + 1px),
      transparent
    ),
    var(--diffs-bg);
}
`;function Dr({patch:e}){const{resolvedTheme:t}=Kt();return U.jsx("div",{className:"rounded-md bg-code overflow-hidden",children:U.jsx(Er,{patch:e,style:{..._r,colorScheme:t},disableWorkerPool:!0,options:{theme:Ar,themeType:t,diffStyle:"unified",diffIndicators:"classic",disableFileHeader:!0,hunkSeparators:"simple",overflow:"scroll",unsafeCSS:Ir}})})}export{Dr as default};
