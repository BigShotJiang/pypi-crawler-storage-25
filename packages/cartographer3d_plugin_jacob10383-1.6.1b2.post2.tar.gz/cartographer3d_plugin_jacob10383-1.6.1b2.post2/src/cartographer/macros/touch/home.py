from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from numbers import Real
from random import random
from typing import TYPE_CHECKING, final

from typing_extensions import override

from cartographer.interfaces.configuration import TouchConfig
from cartographer.interfaces.printer import Macro, MacroParams
from cartographer.macros.fields import config_ref, param, parse
from cartographer.macros.utils import force_home_z

if TYPE_CHECKING:
    from cartographer.interfaces.printer import Toolhead
    from cartographer.probe.touch_mode import TouchMode


logger = logging.getLogger(__name__)

Z_HOP = 2
DISPLAY_DECIMALS = 4


@dataclass(frozen=True)
class TouchHomeParams:
    """Parameters for CARTOGRAPHER_TOUCH_HOME."""

    random_radius: float = param(
        "Random homing radius",
        default=config_ref(TouchConfig, "home_random_radius"),
        min=0,
        key="EXPERIMENTAL_RANDOM_RADIUS",
    )
    print_temp: float | None = param(
        "Optional print nozzle temperature (°C) used to compute touch-home thermal correction.",
        default=None,
        key="PRINT_TEMP",
        min=0,
        max=400,
    )


@final
class TouchHomeMacro(Macro):
    description = "Touch the bed to home Z axis"

    def __init__(
        self,
        probe: TouchMode,
        toolhead: Toolhead,
        *,
        home_position: tuple[float, float],
        lift_speed: float,
        travel_speed: float,
        random_radius: float,
        thermal_expansion_coefficient: float | None = None,
    ) -> None:
        self._probe = probe
        self._toolhead = toolhead
        self._home_position = home_position
        self._lift_speed = lift_speed
        self._travel_speed = travel_speed
        self._random_radius = random_radius
        self._thermal_expansion_coefficient = thermal_expansion_coefficient

    @override
    def run(self, params: MacroParams) -> None:
        p = parse(TouchHomeParams, params, random_radius=self._random_radius)
        if not self._toolhead.is_homed("x") or not self._toolhead.is_homed("y"):
            msg = "Must home x and y before touch homing"
            raise RuntimeError(msg)

        # Check if Z is already homed before we start
        z_was_homed = self._toolhead.is_homed("z")
        model = self._probe.get_model()
        z_offset = model.z_offset if isinstance(model.z_offset, Real) else 0.0

        with force_home_z(self._toolhead):
            pos = self._toolhead.get_position()
            self._toolhead.move(
                z=pos.z + Z_HOP,
                speed=self._lift_speed,
            )
            home_x, home_y = self._get_homing_position(p.random_radius)
            self._toolhead.move(
                x=home_x,
                y=home_y,
                speed=self._travel_speed,
            )
            self._toolhead.wait_moves()

            measured_touch_temp = self._toolhead.get_extruder_temperature().current
            thermal_offset_term = self._compute_thermal_offset_term(
                p.print_temp,
                measured_touch_temp,
            )

            probe_trigger = self._probe.perform_probe()
            raw_trigger = probe_trigger + z_offset
            effective_z_offset = z_offset - (thermal_offset_term if thermal_offset_term is not None else 0.0)
            trigger_pos = raw_trigger - effective_z_offset

        self._toolhead.z_home_end(self._probe)
        pos = self._toolhead.get_position()
        self._toolhead.set_z_position(pos.z - trigger_pos)

        if z_was_homed:
            logger.info(
                "Touch home at (%.3f, %.3f) adjusted z by %.3f mm.",
                pos.x,
                pos.y,
                -trigger_pos,
            )
        else:
            logger.info(
                "Touch home at (%.3f, %.3f) set z to %.3f mm.",
                pos.x,
                pos.y,
                pos.z - trigger_pos,
            )

    def _compute_thermal_offset_term(
        self,
        print_temp: float | None,
        measured_touch_temp: float,
    ) -> float | None:
        if print_temp is None:
            return None

        coeff = self._thermal_expansion_coefficient
        if coeff is None:
            logger.warning(
                "PRINT_TEMP provided but [cartographer touch] thermal_expansion_coefficient is unset; "
                "ignoring override.",
            )
            return None

        temp_delta = print_temp - measured_touch_temp
        offset_term = coeff * temp_delta
        logger.info(
            "Thermal offset term: %s mm (coeff=%s, delta_t=%s°C, touch=%s°C, print=%s°C)",
            self._format_signed(offset_term),
            self._format_trimmed(coeff, 8),
            self._format_signed(temp_delta, 1),
            self._format_trimmed(measured_touch_temp, 1),
            self._format_trimmed(print_temp, 1),
        )
        return offset_term

    @staticmethod
    def _format_trimmed(value: float, decimals: int = DISPLAY_DECIMALS) -> str:
        rounded = round(value, decimals)
        if abs(rounded) < 0.5 * (10**-decimals):
            rounded = 0.0
        result = f"{rounded:.{decimals}f}".rstrip("0").rstrip(".")
        return "0" if result in {"", "-0"} else result

    def _format_signed(self, value: float, decimals: int = DISPLAY_DECIMALS) -> str:
        sign = "+" if value >= 0 else "-"
        return f"{sign}{self._format_trimmed(abs(value), decimals)}"

    def _get_homing_position(self, random_radius: float) -> tuple[float, float]:
        center_x, center_y = self._home_position
        u1 = random()  # [0, 1)
        u2 = random()  # [0, 1)

        # Polar coordinates with square root for uniform area distribution
        radius = random_radius * math.sqrt(u1)
        angle = 2 * math.pi * u2

        # Convert to Cartesian coordinates
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)

        return (x, y)
