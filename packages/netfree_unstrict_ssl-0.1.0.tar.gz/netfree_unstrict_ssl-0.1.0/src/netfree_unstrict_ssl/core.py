import ssl as _ssl


def unstrict_ssl() -> bool:
    """
    Disable VERIFY_X509_STRICT in Python 3.13+ SSL default context.

    Returns:
        True if patch was applied.
        False if VERIFY_X509_STRICT does not exist.
    """
    if not hasattr(_ssl, "VERIFY_X509_STRICT"):
        return False

    if getattr(_ssl, "_netfree_ssl_fix_applied", False):
        return True

    _orig = _ssl.create_default_context

    def _patched(*args, **kwargs):
        ctx = _orig(*args, **kwargs)
        ctx.verify_flags &= ~_ssl.VERIFY_X509_STRICT
        return ctx

    _ssl.create_default_context = _patched
    _ssl._netfree_ssl_fix_applied = True

    return True