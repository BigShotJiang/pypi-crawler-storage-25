from .core import unstrict_ssl

__all__ = ["unstrict_ssl"]