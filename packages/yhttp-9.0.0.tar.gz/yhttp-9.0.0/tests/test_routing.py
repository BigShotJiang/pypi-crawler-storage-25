import re
from urllib.parse import quote

import pytest
from bddrest import status, response, when, given

from yhttp.core import notfound


def test_routing_basic(app, httpreq):

    @app.route()
    @app.route('/index')
    def get(req):
        return 'get index'

    @app.route()
    def post(req):
        return 'post index'

    @app.route(verb=['delete', 'remove'])
    def delete_remove(req):
        return 'delete remove'

    with httpreq():
        assert status == 200
        assert response == 'get index'

        when('/index')
        assert status == 200
        assert response == 'get index'

        when(verb='post')
        assert status == 200
        assert response == 'post index'

        when(verb='invalid')
        assert status == 405

        when('/invalid')
        assert status == 404

        when(verb='delete')
        assert status == 200
        assert response == 'delete remove'

        when(verb='remove')
        assert status == 200
        assert response == 'delete remove'


def test_routing_order(app, httpreq):

    @app.route(r'/([a-z0-9]+)')
    def get(req, arg1):
        return f'index {arg1}'

    @app.route(r'/([a-z0-9]+)/bar/([a-z0-9]+)')
    def get(req, arg1, arg2):
        return f'foo {arg1} {arg2}'

    with httpreq('/1'):
        assert status == 200
        assert response == 'index 1'

        when('/foo/bar/baz')
        assert status == 200
        assert response == 'foo foo baz'


def test_routing_argument(app, httpreq):

    @app.route(r'/(\d+)')
    def get(req, id_):
        return id_

    with httpreq('/12'):
        assert status == 200
        assert response == '12'

        when('/')
        assert status == 404

        when('/foo')
        assert status == 404

        when('/1/2')
        assert status == 404

    @app.route(r'/(\d+)/?(\w+)?')
    def post(req, id_, title='Empty'):
        return f'{id_} {title}'

    @app.route(r'/(\d+)(?:/(\w+))?')
    def put(req, id_, title='Empty'):
        return f'{id_} {title}'

    with httpreq('/12/foo', 'post'):
        assert status == 200
        assert response == '12 foo'

        when('/12')
        assert status == 200
        assert response == '12 Empty'

        when(verb='put', path='/12/foo')
        assert status == 200
        assert response == '12 foo'


def test_routing_insert(app, httpreq):

    @app.route(r'/(.*)')
    def get(req, id_):
        raise notfound

    @app.route(r'/foo', insert=0)
    def get(req):  # noqa: W0404
        return b'foo'

    with httpreq('/foo'):
        assert status == 200
        assert response == 'foo'


def test_routing_allverbs(app, httpreq):

    @app.route(verb='*')
    def all(req):
        return 'all'

    with httpreq():
        assert status == 200
        assert response == 'all'

        when(verb='post')
        assert status == 200
        assert response == 'all'

        when(verb='put')
        assert status == 200
        assert response == 'all'


def test_routing_encodedurl(app, httpreq):

    @app.route(r'/(.+)')
    def get(req, id_):
        return id_

    with httpreq('/12'):
        assert status == 200
        assert response == '12'

        when(quote('/الف'))
        assert status == 200
        assert response == 'الف'

        when('/foo bar')
        assert status == 200
        assert response == 'foo bar'

        when('/foo%20bar')
        assert status == 200
        assert response == 'foo bar'


def test_routing_encodedurl_route(app, httpreq):

    @app.route(r'/([ a-z]+)', re.I)
    def get(req, id_):
        return id_

    with httpreq('/id: foo%20bar'):
        assert status == 200
        assert response == 'foo bar'

        when(path_parameters=given | dict(id='foo Bar'))
        assert status == 200
        assert response == 'foo Bar'


def test_routing_twice(app, httpreq):
    def get(req):
        pass

    app.route(r'/')(get)
    with pytest.raises(ValueError):
        app.route(r'/')(get)

    with httpreq('/'):
        assert status == 200


def test_routing_delete(app, httpreq):
    def get(req):
        pass

    app.route(r'/')(get)
    with pytest.raises(ValueError):
        app.route(r'/')(get)

    app.delete_route(r'/', 'get')

    with httpreq('/'):
        assert status == 405

    app.route(r'/')(get)
    with httpreq('/'):
        assert status == 200

    with pytest.raises(ValueError):
        app.delete_route('/notexists', 'get')


def test_routing_replace(app, httpreq):
    def get(req):
        return 'foo'

    app.route(r'/')(get)
    with httpreq('/'):
        assert status == 200
        assert response.text == 'foo'

    def get(req):
        return 'bar'

    with pytest.raises(ValueError):
        app.route(r'/')(get)

    with pytest.raises(ValueError):
        app.route(r'/', exists='invalidvalue')(get)

    app.route(r'/', exists='remove')(get)
    with httpreq('/'):
        assert status == 200
        assert response.text == 'bar'


def test_routing_trailingslash(app, httpreq):
    with pytest.raises(ValueError):
        app.route(trailingslash='invalid')

    @app.route()
    def get(req):
        return req.path

    @app.route(trailingslash='remove')
    def remove(req):
        return req.path

    @app.route(trailingslash='redirect')
    def redirect(req):
        return req.path

    @app.route('/foo/?', )
    def get(req):
        return req.path

    @app.route('/foo/?', trailingslash='remove')
    def remove(req):
        return req.path

    @app.route('/foo/?', trailingslash='redirect')
    def redirect(req):
        return req.path

    with httpreq():
        assert status == 200
        assert response == '/'

        when(verb='REMOVE')
        assert status == 200
        assert response == ''

        when(verb='REDIRECT')
        assert status == 302
        assert response.headers['location'] == ''

    with httpreq('/foo/'):
        assert status == 200
        assert response == '/foo/'

        when(verb='REMOVE')
        assert status == 200
        assert response == '/foo'

        when(verb='REDIRECT')
        assert status == 302
        assert response.headers['location'] == '/foo'
