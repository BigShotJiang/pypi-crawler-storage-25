from bddrest import status, given, when, response

from yhttp.core import statuses, guard as g, json


def test_queryguard_strict(app, httpreq):
    @app.route()
    @app.queryguard(strict=True)
    def get(req):
        pass

    @app.route()
    @app.queryguard(strict=True, fields=(
        g.String('foo', optional=True),
        g.Integer('bar', optional=True),
    ))
    def post(req):
        pass

    with httpreq():
        assert status == 200

        when(query=dict(foo='bar'))
        assert status == '400 Bad Request'
        assert response.text.startswith('400 Bad Request\r\n')

    with httpreq(verb='post', query=dict(foo='bar')):
        assert status == 200

        when(query=given - 'foo')
        assert status == 200

        when(query=given | dict(baz='baz'))
        assert status == '400 Bad Request'
        assert response.text.startswith('400 Invalid field(s): baz\r\n')

        when(query=given | dict(bar='bar'))
        assert status == '400 Bad Request'
        assert response.text.startswith('400 bar: Integer Required\r\n')


def test_queryguard_string(app, httpreq):
    @app.route()
    @app.queryguard((
        g.String('foo', optional=True, length=(1, 3), pattern=r'^[a-z]+$'),
    ))
    @json
    def post(req):
        return req.query.dict

    with httpreq(verb='post', query=dict(foo='abc', bar='2')):
        assert status == 200
        assert response.json == dict(foo=['abc'], bar=['2'])

        when(query=given - 'foo')
        assert status == 200

        when(query=dict(foo=''))
        assert status == '400 Bad Request'
        assert response.text.startswith(
            '400 foo: Length must be between 1 and 3 characters\r\n'
        )

        when(query=dict(foo='12'))
        assert status == '400 Bad Request'
        assert response.text.startswith('400 foo: Invalid Format\r\n')


def test_queryguard_integer(app, httpreq):
    def nozero(req, field, values):
        if values[field.name] == 0:
            raise statuses.HTTPStatus(400, f'{field.name}: Zero Not Allowed')

        return 0

    @app.route()
    @app.queryguard(fields=(
        g.Integer('bar', range=(-2, 5), callback=nozero),
    ))
    @json
    def post(req):
        return req.query.dict

    with httpreq(verb='post', query=dict(foo='abc', bar='2')):
        assert status == 200
        assert response.json == dict(foo=['abc'], bar=[2])

        when(query=dict(bar='-2'))
        assert status == 200
        assert response.json == dict(bar=[-2])

        when(query=dict(bar='-3'))
        assert status == '400 Bad Request'
        assert response.text.startswith(
            '400 bar: Value must be between -2 and 5\r\n'
        )

        when(query=given - 'bar')
        assert status == '400 Bad Request'
        assert response.text.startswith('400 bar: Required\r\n')

        when(query=dict(bar='bar'))
        assert status == '400 Bad Request'
        assert response.text.startswith('400 bar: Integer Required\r\n')

        when(query=given | dict(bar=0))
        assert status == '400 bar: Zero Not Allowed'


def test_queryguard_boolean_kwargs(app, httpreq):
    @app.route()
    @app.queryguard(fields=(
        g.Boolean('bar'),
    ))
    @json
    def post(req, *, bar=None):
        return bar

    with httpreq(verb='post', path='/?bar=yes'):
        assert status == 200
        assert response.json is True

    with httpreq(verb='post', path='/?bar=false'):
        assert status == 200
        assert response.json is False
