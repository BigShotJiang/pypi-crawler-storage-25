from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import aiosqlite

from aicd.db.registry_seed import seed_agent_work_mode_registry
from aicd.db.schema import RESET_DROP_SCRIPT, SCHEMA, SCHEMA_USER_VERSION


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class ChatMessageRow:
    id: int
    session_id: str
    role: str
    content: str
    tool_calls_json: str | None
    created_at: str
    tool_call_id: str | None
    tool_name: str | None


@dataclass
class ChatSummaryRow:
    id: int
    session_id: str
    content: str
    covers_up_to_message_id: int | None
    created_at: str


@dataclass
class TaskRow:
    id: str
    type: str
    status: str
    parent_id: str | None
    thread_root_id: str | None
    agent_workflow: str | None
    agent_kind: str | None
    work_mode: str | None
    created_at: str
    updated_at: str
    payload: dict[str, Any]
    result_summary: str | None
    error: str | None


@dataclass
class TaskMessageRow:
    id: int
    thread_root_id: str | None
    to_task_id: str
    from_task_id: str
    kind: str
    body: dict[str, Any]
    created_at: str
    read_at: str | None


class TaskStore:
    _TASK_SELECT_COLS = (
        "id, type, status, parent_id, thread_root_id, agent_workflow, "
        "agent_kind, work_mode, "
        "created_at, updated_at, payload_json, result_summary, error"
    )

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        #: 最近一次 ``connect()`` 是否因 ``user_version`` 不一致而整库重建（任务与聊天已清空）
        self.last_open_rebuilt_db: bool = False

    async def connect(self) -> aiosqlite.Connection:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = await aiosqlite.connect(self._db_path)
        # 多进程并发读写时尽量避免 "database is locked"。
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute("PRAGMA busy_timeout=5000")
        cur = await conn.execute("PRAGMA user_version")
        row = await cur.fetchone()
        ver = int(row[0]) if row is not None and row[0] is not None else 0
        rebuilt = ver != SCHEMA_USER_VERSION
        self.last_open_rebuilt_db = rebuilt
        if rebuilt:
            await conn.executescript(RESET_DROP_SCRIPT)
            await conn.executescript(SCHEMA)
            await conn.execute(f"PRAGMA user_version = {SCHEMA_USER_VERSION}")
        else:
            await conn.executescript(SCHEMA)
        await conn.commit()
        await seed_agent_work_mode_registry(conn)
        return conn

    async def insert_task(
        self,
        conn: aiosqlite.Connection,
        *,
        task_type: str,
        status: str,
        parent_id: str | None,
        payload: dict[str, Any],
        task_id: str | None = None,
        thread_root_id: str | None = None,
        agent_workflow: str | None = None,
        agent_kind: str | None = None,
        work_mode: str | None = None,
    ) -> str:
        tid = task_id or str(uuid.uuid4())
        now = _utc_now()
        tr = (
            thread_root_id.strip()
            if isinstance(thread_root_id, str) and thread_root_id.strip()
            else None
        )
        aw = (
            agent_workflow.strip()
            if isinstance(agent_workflow, str) and agent_workflow.strip()
            else None
        )
        ak = (
            agent_kind.strip()
            if isinstance(agent_kind, str) and agent_kind.strip()
            else None
        )
        wm = (
            work_mode.strip()
            if isinstance(work_mode, str) and work_mode.strip()
            else None
        )
        await conn.execute(
            """
            INSERT INTO tasks (id, type, status, parent_id, thread_root_id, agent_workflow,
                agent_kind, work_mode,
                created_at, updated_at, payload_json, result_summary, error)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL)
            """,
            (
                tid,
                task_type,
                status,
                parent_id,
                tr,
                aw,
                ak,
                wm,
                now,
                now,
                json.dumps(payload, ensure_ascii=False),
            ),
        )
        await conn.commit()
        return tid

    async def update_task(
        self,
        conn: aiosqlite.Connection,
        task_id: str,
        *,
        status: str | None = None,
        result_summary: str | None = None,
        error: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> None:
        row = await self.get_task(conn, task_id)
        if not row:
            return
        now = _utc_now()
        st = status or row.status
        rs = result_summary if result_summary is not None else row.result_summary
        err = error if error is not None else row.error
        pl = json.dumps(payload, ensure_ascii=False) if payload is not None else json.dumps(
            row.payload, ensure_ascii=False
        )
        await conn.execute(
            """
            UPDATE tasks SET status=?, updated_at=?, result_summary=?, error=?,
                payload_json=?, thread_root_id=?, agent_workflow=?,
                agent_kind=?, work_mode=? WHERE id=?
            """,
            (
                st,
                now,
                rs,
                err,
                pl,
                row.thread_root_id,
                row.agent_workflow,
                row.agent_kind,
                row.work_mode,
                task_id,
            ),
        )
        await conn.commit()

    def _row_to_task(self, row: tuple[Any, ...]) -> TaskRow:
        (
            tid,
            ttype,
            status,
            parent_id,
            thread_root_id,
            agent_workflow,
            agent_kind,
            work_mode,
            created_at,
            updated_at,
            payload_json,
            result_summary,
            error,
        ) = row
        try:
            payload = json.loads(payload_json or "{}")
        except json.JSONDecodeError:
            payload = {}
        tr = str(thread_root_id).strip() if thread_root_id else None
        aw = str(agent_workflow).strip() if agent_workflow else None
        ak = str(agent_kind).strip() if agent_kind else None
        wm = str(work_mode).strip() if work_mode else None
        return TaskRow(
            id=tid,
            type=ttype,
            status=status,
            parent_id=parent_id,
            thread_root_id=tr,
            agent_workflow=aw,
            agent_kind=ak,
            work_mode=wm,
            created_at=created_at,
            updated_at=updated_at,
            payload=payload,
            result_summary=result_summary,
            error=error,
        )

    async def get_task(
        self, conn: aiosqlite.Connection, task_id: str
    ) -> TaskRow | None:
        cur = await conn.execute(
            f"SELECT {self._TASK_SELECT_COLS} FROM tasks WHERE id=?",
            (task_id,),
        )
        row = await cur.fetchone()
        if not row:
            return None
        return self._row_to_task(row)

    async def list_tasks(
        self, conn: aiosqlite.Connection, limit: int = 100
    ) -> list[TaskRow]:
        cur = await conn.execute(
            f"SELECT {self._TASK_SELECT_COLS} FROM tasks "
            "ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        )
        rows = await cur.fetchall()
        return [self._row_to_task(r) for r in rows]

    async def list_tasks_for_thread(
        self, conn: aiosqlite.Connection, thread_root_id: str, *, limit: int = 100
    ) -> list[TaskRow]:
        sid = (thread_root_id or "").strip()
        if not sid:
            return []
        cur = await conn.execute(
            f"SELECT {self._TASK_SELECT_COLS} FROM tasks "
            "WHERE thread_root_id = ? ORDER BY updated_at DESC LIMIT ?",
            (sid, limit),
        )
        rows = await cur.fetchall()
        return [self._row_to_task(r) for r in rows]

    async def tasks_any_active(self, conn: aiosqlite.Connection) -> bool:
        """是否存在 ``running`` / ``pending`` 任务（不限 list 条数截断）。"""
        cur = await conn.execute(
            """
            SELECT 1 FROM tasks
            WHERE lower(status) IN ('running', 'pending')
            LIMIT 1
            """
        )
        row = await cur.fetchone()
        return row is not None

    async def tasks_any_active_for_thread(
        self, conn: aiosqlite.Connection, thread_root_id: str
    ) -> bool:
        sid = (thread_root_id or "").strip()
        if not sid:
            return False
        cur = await conn.execute(
            """
            SELECT 1 FROM tasks
            WHERE thread_root_id = ?
              AND lower(status) IN ('running', 'pending')
            LIMIT 1
            """,
            (sid,),
        )
        row = await cur.fetchone()
        return row is not None

    async def list_tasks_by_parent(
        self, conn: aiosqlite.Connection, parent_id: str, *, limit: int = 200
    ) -> list[TaskRow]:
        cur = await conn.execute(
            f"SELECT {self._TASK_SELECT_COLS} FROM tasks "
            "WHERE parent_id = ? ORDER BY updated_at DESC LIMIT ?",
            (parent_id, limit),
        )
        rows = await cur.fetchall()
        return [self._row_to_task(r) for r in rows]

    async def list_top_level_tasks_for_session_thread(
        self,
        conn: aiosqlite.Connection,
        session_thread_id: str,
        *,
        limit: int = 80,
        since_updated_at: str | None = None,
    ) -> list[TaskRow]:
        """顶层任务且 ``tasks.thread_root_id`` 等于主会话 id（由主对话发起的后台任务）。"""
        sid = (session_thread_id or "").strip()
        if not sid:
            return []
        if since_updated_at and since_updated_at.strip():
            cur = await conn.execute(
                f"""
                SELECT {self._TASK_SELECT_COLS} FROM tasks
                WHERE parent_id IS NULL
                  AND thread_root_id = ?
                  AND updated_at > ?
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (sid, since_updated_at.strip(), limit),
            )
        else:
            cur = await conn.execute(
                f"""
                SELECT {self._TASK_SELECT_COLS} FROM tasks
                WHERE parent_id IS NULL
                  AND thread_root_id = ?
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (sid, limit),
            )
        rows = await cur.fetchall()
        return [self._row_to_task(r) for r in rows]

    async def clear_task_history(self, conn: aiosqlite.Connection) -> dict[str, int]:
        """删除全部 task_messages 与 tasks 行（不删 chat_* 表）。"""
        cur = await conn.execute("SELECT COUNT(*) FROM task_messages")
        row_m = await cur.fetchone()
        n_msg = int(row_m[0]) if row_m else 0
        cur = await conn.execute("SELECT COUNT(*) FROM tasks")
        row_t = await cur.fetchone()
        n_tasks = int(row_t[0]) if row_t else 0
        await conn.execute("DELETE FROM task_messages")
        await conn.execute("DELETE FROM tasks")
        await conn.commit()
        return {"task_messages_deleted": n_msg, "tasks_deleted": n_tasks}

    async def clear_task_history_for_thread(
        self, conn: aiosqlite.Connection, thread_root_id: str
    ) -> dict[str, int]:
        """仅删除指定会话线程下的 tasks 与关联 task_messages。"""
        from aicd.tasks.main_inbox import main_inbox_id

        sid = (thread_root_id or "").strip()
        if not sid:
            return {"task_messages_deleted": 0, "tasks_deleted": 0}

        cur = await conn.execute(
            "SELECT id FROM tasks WHERE thread_root_id = ?",
            (sid,),
        )
        task_ids = [str(r[0]) for r in (await cur.fetchall()) if r and r[0]]
        inbox_id = main_inbox_id(sid)

        clauses = ["thread_root_id = ?", "to_task_id = ?"]
        params: list[Any] = [sid, inbox_id]
        if task_ids:
            qmarks = ",".join("?" for _ in task_ids)
            clauses.extend(
                [
                    f"to_task_id IN ({qmarks})",
                    f"from_task_id IN ({qmarks})",
                ]
            )
            params.extend(task_ids)
            params.extend(task_ids)
        where = " OR ".join(f"({c})" for c in clauses)

        cur = await conn.execute(
            f"SELECT COUNT(*) FROM task_messages WHERE {where}",
            tuple(params),
        )
        row_m = await cur.fetchone()
        n_msg = int(row_m[0]) if row_m else 0

        cur = await conn.execute(
            "SELECT COUNT(*) FROM tasks WHERE thread_root_id = ?",
            (sid,),
        )
        row_t = await cur.fetchone()
        n_tasks = int(row_t[0]) if row_t else 0

        await conn.execute(
            f"DELETE FROM task_messages WHERE {where}",
            tuple(params),
        )
        await conn.execute("DELETE FROM tasks WHERE thread_root_id = ?", (sid,))
        await conn.commit()
        return {"task_messages_deleted": n_msg, "tasks_deleted": n_tasks}

    async def append_chat_message(
        self,
        conn: aiosqlite.Connection,
        *,
        session_id: str,
        role: str,
        content: str | None,
        tool_calls: list[dict[str, Any]] | None = None,
        tool_call_id: str | None = None,
        tool_name: str | None = None,
    ) -> int:
        now = _utc_now()
        tc = json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None
        cur = await conn.execute(
            """
            INSERT INTO chat_messages (
                session_id, role, content, tool_calls_json, created_at,
                tool_call_id, tool_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session_id,
                role,
                content or "",
                tc,
                now,
                tool_call_id,
                tool_name,
            ),
        )
        await conn.commit()
        return int(cur.lastrowid)

    def _row_to_chat_message(self, row: tuple[Any, ...]) -> ChatMessageRow:
        return ChatMessageRow(
            id=int(row[0]),
            session_id=str(row[1]),
            role=str(row[2]),
            content=str(row[3] or ""),
            tool_calls_json=row[4] if row[4] else None,
            created_at=str(row[5]),
            tool_call_id=str(row[6]) if row[6] is not None else None,
            tool_name=str(row[7]) if row[7] is not None else None,
        )

    async def list_chat_messages(
        self,
        conn: aiosqlite.Connection,
        session_id: str,
        *,
        limit: int = 500,
        offset: int = 0,
    ) -> list[ChatMessageRow]:
        cur = await conn.execute(
            """
            SELECT id, session_id, role, content, tool_calls_json, created_at,
                   tool_call_id, tool_name
            FROM chat_messages
            WHERE session_id = ?
            ORDER BY id ASC
            LIMIT ? OFFSET ?
            """,
            (session_id, limit, offset),
        )
        rows = await cur.fetchall()
        return [self._row_to_chat_message(r) for r in rows]

    async def count_chat_messages(
        self, conn: aiosqlite.Connection, session_id: str
    ) -> int:
        cur = await conn.execute(
            "SELECT COUNT(*) FROM chat_messages WHERE session_id=?",
            (session_id,),
        )
        r = await cur.fetchone()
        return int(r[0]) if r else 0

    async def list_chat_messages_tail(
        self,
        conn: aiosqlite.Connection,
        session_id: str,
        *,
        limit: int,
    ) -> list[ChatMessageRow]:
        cur = await conn.execute(
            """
            SELECT id, session_id, role, content, tool_calls_json, created_at,
                   tool_call_id, tool_name
            FROM chat_messages
            WHERE session_id = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (session_id, limit),
        )
        rows = await cur.fetchall()
        rev = list(reversed(rows))
        return [self._row_to_chat_message(r) for r in rev]

    async def search_chat_messages(
        self,
        conn: aiosqlite.Connection,
        session_id: str,
        *,
        query: str,
        use_regex: bool = False,
        limit: int = 30,
        scan_limit: int = 2000,
    ) -> list[ChatMessageRow]:
        """按子串（LIKE）或正则在本会话内检索消息行；正则模式仅扫描最近 ``scan_limit`` 条（从新到旧）。"""
        q = (query or "").strip()
        if not q:
            return []
        lim = max(1, min(100, int(limit)))
        scan = max(50, min(8000, int(scan_limit)))
        if use_regex:
            try:
                rx = re.compile(q)
            except re.error:
                return []
            cur = await conn.execute(
                """
                SELECT id, session_id, role, content, tool_calls_json, created_at,
                       tool_call_id, tool_name
                FROM chat_messages
                WHERE session_id = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (session_id, scan),
            )
            raw = await cur.fetchall()
            out: list[ChatMessageRow] = []
            for t in raw:
                r = self._row_to_chat_message(t)
                blob = "\n".join(
                    p
                    for p in (
                        r.content or "",
                        r.tool_name or "",
                        r.tool_calls_json or "",
                    )
                    if p
                )
                if rx.search(blob):
                    out.append(r)
                if len(out) >= lim:
                    break
            out.reverse()
            return out
        esc = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        pat = f"%{esc}%"
        cur = await conn.execute(
            """
            SELECT id, session_id, role, content, tool_calls_json, created_at,
                   tool_call_id, tool_name
            FROM chat_messages
            WHERE session_id = ?
              AND (
                content LIKE ? ESCAPE '\\'
                OR IFNULL(tool_name, '') LIKE ? ESCAPE '\\'
                OR IFNULL(tool_calls_json, '') LIKE ? ESCAPE '\\'
              )
            ORDER BY id DESC
            LIMIT ?
            """,
            (session_id, pat, pat, pat, lim),
        )
        raw = await cur.fetchall()
        return [self._row_to_chat_message(t) for t in reversed(raw)]

    async def get_chat_message(
        self, conn: aiosqlite.Connection, message_id: int
    ) -> ChatMessageRow | None:
        cur = await conn.execute(
            """
            SELECT id, session_id, role, content, tool_calls_json, created_at,
                   tool_call_id, tool_name
            FROM chat_messages WHERE id=?
            """,
            (message_id,),
        )
        row = await cur.fetchone()
        if not row:
            return None
        return self._row_to_chat_message(row)

    async def append_chat_summary(
        self,
        conn: aiosqlite.Connection,
        *,
        session_id: str,
        content: str,
        covers_up_to_message_id: int | None = None,
    ) -> int:
        now = _utc_now()
        cur = await conn.execute(
            """
            INSERT INTO chat_summaries (session_id, content, covers_up_to_message_id, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (session_id, content, covers_up_to_message_id, now),
        )
        await conn.commit()
        return int(cur.lastrowid)

    async def count_chat_summaries(
        self, conn: aiosqlite.Connection, session_id: str
    ) -> int:
        cur = await conn.execute(
            "SELECT COUNT(*) FROM chat_summaries WHERE session_id=?",
            (session_id,),
        )
        r = await cur.fetchone()
        return int(r[0]) if r else 0

    async def list_chat_summaries(
        self, conn: aiosqlite.Connection, session_id: str, limit: int = 20
    ) -> list[ChatSummaryRow]:
        cur = await conn.execute(
            """
            SELECT id, session_id, content, covers_up_to_message_id, created_at
            FROM chat_summaries
            WHERE session_id = ?
            ORDER BY id ASC
            LIMIT ?
            """,
            (session_id, limit),
        )
        rows = await cur.fetchall()
        out: list[ChatSummaryRow] = []
        for r in rows:
            out.append(
                ChatSummaryRow(
                    id=int(r[0]),
                    session_id=str(r[1]),
                    content=str(r[2]),
                    covers_up_to_message_id=int(r[3]) if r[3] is not None else None,
                    created_at=str(r[4]),
                )
            )
        return out

    def _row_to_task_message(self, row: tuple[Any, ...]) -> TaskMessageRow:
        (
            mid,
            thread_root_id,
            to_task_id,
            from_task_id,
            kind,
            body_json,
            created_at,
            read_at,
        ) = row
        try:
            body = json.loads(body_json or "{}")
        except json.JSONDecodeError:
            body = {}
        if not isinstance(body, dict):
            body = {"value": body}
        return TaskMessageRow(
            id=int(mid),
            thread_root_id=str(thread_root_id) if thread_root_id else None,
            to_task_id=str(to_task_id),
            from_task_id=str(from_task_id),
            kind=str(kind),
            body=body,
            created_at=str(created_at),
            read_at=str(read_at) if read_at else None,
        )

    async def insert_task_message(
        self,
        conn: aiosqlite.Connection,
        *,
        to_task_id: str,
        from_task_id: str,
        kind: str,
        body: dict[str, Any],
        thread_root_id: str | None = None,
    ) -> int:
        now = _utc_now()
        cur = await conn.execute(
            """
            INSERT INTO task_messages (
                thread_root_id, to_task_id, from_task_id, kind, body_json, created_at, read_at)
            VALUES (?, ?, ?, ?, ?, ?, NULL)
            """,
            (
                thread_root_id,
                to_task_id,
                from_task_id,
                kind,
                json.dumps(body, ensure_ascii=False),
                now,
            ),
        )
        await conn.commit()
        return int(cur.lastrowid)

    async def list_task_messages(
        self,
        conn: aiosqlite.Connection,
        *,
        to_task_id: str,
        since_id: int = 0,
        limit: int = 50,
    ) -> list[TaskMessageRow]:
        cur = await conn.execute(
            """
            SELECT id, thread_root_id, to_task_id, from_task_id, kind, body_json, created_at, read_at
            FROM task_messages
            WHERE to_task_id = ? AND id > ?
            ORDER BY id ASC
            LIMIT ?
            """,
            (to_task_id, since_id, limit),
        )
        rows = await cur.fetchall()
        return [self._row_to_task_message(r) for r in rows]

    async def list_task_messages_unread(
        self,
        conn: aiosqlite.Connection,
        *,
        to_task_id: str,
        limit: int = 50,
    ) -> list[TaskMessageRow]:
        cur = await conn.execute(
            """
            SELECT id, thread_root_id, to_task_id, from_task_id, kind, body_json, created_at, read_at
            FROM task_messages
            WHERE to_task_id = ? AND read_at IS NULL
            ORDER BY id ASC
            LIMIT ?
            """,
            (to_task_id, limit),
        )
        rows = await cur.fetchall()
        return [self._row_to_task_message(r) for r in rows]

    async def mark_task_messages_read(
        self, conn: aiosqlite.Connection, message_ids: list[int]
    ) -> None:
        if not message_ids:
            return
        now = _utc_now()
        qmarks = ",".join("?" * len(message_ids))
        await conn.execute(
            f"UPDATE task_messages SET read_at=? WHERE id IN ({qmarks})",
            [now, *message_ids],
        )
        await conn.commit()

    async def fetch_prompt_block_content(
        self, conn: aiosqlite.Connection, block_id: str | None
    ) -> str | None:
        bid = (block_id or "").strip()
        if not bid:
            return None
        cur = await conn.execute(
            "SELECT content FROM prompt_blocks WHERE id=?",
            (bid,),
        )
        row = await cur.fetchone()
        if not row:
            return None
        return str(row[0] or "").strip() or None

    async def get_agent_kind_def_row(
        self, conn: aiosqlite.Connection, key: str
    ) -> dict[str, Any] | None:
        k = (key or "").strip().lower()
        if not k:
            return None
        cur = await conn.execute(
            """
            SELECT key, display_name, category, parent_key, llm_profile_name,
                   prompt_block_id, builtin, enabled, meta_json
            FROM agent_kind_defs WHERE key=? AND enabled=1
            """,
            (k,),
        )
        row = await cur.fetchone()
        if not row:
            return None
        meta: dict[str, Any] = {}
        if row[8]:
            try:
                meta = json.loads(row[8])
            except json.JSONDecodeError:
                meta = {}
        return {
            "key": row[0],
            "display_name": row[1],
            "category": row[2],
            "parent_key": row[3],
            "llm_profile_name": row[4],
            "prompt_block_id": row[5],
            "builtin": bool(row[6]),
            "enabled": bool(row[7]),
            "meta": meta,
        }

    async def get_work_mode_def_row(
        self, conn: aiosqlite.Connection, key: str
    ) -> dict[str, Any] | None:
        k = (key or "").strip().lower()
        if not k:
            return None
        cur = await conn.execute(
            """
            SELECT key, display_name, llm_profile_name, prompt_block_id,
                   tmp_policy_json, policies_json, builtin, enabled, meta_json
            FROM work_mode_defs WHERE key=? AND enabled=1
            """,
            (k,),
        )
        row = await cur.fetchone()
        if not row:
            return None
        meta: dict[str, Any] = {}
        if row[8]:
            try:
                meta = json.loads(row[8])
            except json.JSONDecodeError:
                meta = {}
        pol: dict[str, Any] | None = None
        if row[5]:
            try:
                pol = json.loads(row[5])
            except json.JSONDecodeError:
                pol = None
        return {
            "key": row[0],
            "display_name": row[1],
            "llm_profile_name": row[2],
            "prompt_block_id": row[3],
            "tmp_policy_json": row[4],
            "policies": pol,
            "builtin": bool(row[6]),
            "enabled": bool(row[7]),
            "meta": meta,
        }

    async def list_agent_kind_defs(
        self,
        conn: aiosqlite.Connection,
        *,
        include_disabled: bool = True,
    ) -> list[dict[str, Any]]:
        where = "" if include_disabled else " WHERE enabled = 1 "
        cur = await conn.execute(
            f"""
            SELECT key, display_name, category, parent_key, llm_profile_name,
                   prompt_block_id, builtin, enabled, meta_json
            FROM agent_kind_defs{where} ORDER BY key ASC
            """
        )
        rows = await cur.fetchall()
        out: list[dict[str, Any]] = []
        for row in rows:
            meta: dict[str, Any] = {}
            if row[8]:
                try:
                    meta = json.loads(row[8])
                except json.JSONDecodeError:
                    meta = {}
            pb = row[5]
            ptxt = await self.fetch_prompt_block_content(conn, pb) if pb else None
            out.append(
                {
                    "key": row[0],
                    "display_name": row[1],
                    "category": row[2],
                    "parent_key": row[3],
                    "llm_profile_name": row[4],
                    "prompt_block_id": pb,
                    "prompt_block_excerpt": (ptxt[:200] + "…")
                    if ptxt and len(ptxt) > 200
                    else ptxt,
                    "builtin": bool(row[6]),
                    "enabled": bool(row[7]),
                    "meta": meta,
                }
            )
        return out

    async def list_work_mode_defs(
        self,
        conn: aiosqlite.Connection,
        *,
        include_disabled: bool = True,
    ) -> list[dict[str, Any]]:
        where = "" if include_disabled else " WHERE enabled = 1 "
        cur = await conn.execute(
            f"""
            SELECT key, display_name, llm_profile_name, prompt_block_id,
                   tmp_policy_json, policies_json, builtin, enabled, meta_json
            FROM work_mode_defs{where} ORDER BY key ASC
            """
        )
        rows = await cur.fetchall()
        out: list[dict[str, Any]] = []
        for row in rows:
            meta: dict[str, Any] = {}
            if row[8]:
                try:
                    meta = json.loads(row[8])
                except json.JSONDecodeError:
                    meta = {}
            pb = row[3]
            ptxt = await self.fetch_prompt_block_content(conn, pb) if pb else None
            pol: dict[str, Any] | None = None
            if row[5]:
                try:
                    pol = json.loads(row[5])
                except json.JSONDecodeError:
                    pol = None
            out.append(
                {
                    "key": row[0],
                    "display_name": row[1],
                    "llm_profile_name": row[2],
                    "prompt_block_id": pb,
                    "prompt_block_excerpt": (ptxt[:200] + "…")
                    if ptxt and len(ptxt) > 200
                    else ptxt,
                    "tmp_policy_json": row[4],
                    "policies": pol,
                    "builtin": bool(row[6]),
                    "enabled": bool(row[7]),
                    "meta": meta,
                }
            )
        return out

    async def upsert_prompt_block(
        self,
        conn: aiosqlite.Connection,
        *,
        block_id: str,
        name: str,
        content: str,
        version: int = 1,
    ) -> None:
        now = _utc_now()
        await conn.execute(
            """
            INSERT INTO prompt_blocks (id, name, content, version, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                name=excluded.name,
                content=excluded.content,
                version=excluded.version,
                updated_at=excluded.updated_at
            """,
            (block_id, name, content, int(version), now),
        )
        await conn.commit()

    async def upsert_agent_kind_def(
        self,
        conn: aiosqlite.Connection,
        *,
        key: str,
        display_name: str,
        category: str,
        parent_key: str | None = None,
        llm_profile_name: str | None = None,
        prompt_block_id: str | None = None,
        enabled: bool = True,
        meta_json: str | None = None,
        builtin: int = 0,
    ) -> None:
        k = (key or "").strip().lower()
        if not k:
            raise ValueError("agent_kind key required")
        await conn.execute(
            """
            INSERT INTO agent_kind_defs (
                key, display_name, category, parent_key, llm_profile_name,
                prompt_block_id, builtin, enabled, meta_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET
                display_name=excluded.display_name,
                category=excluded.category,
                parent_key=excluded.parent_key,
                llm_profile_name=excluded.llm_profile_name,
                prompt_block_id=excluded.prompt_block_id,
                enabled=excluded.enabled,
                meta_json=excluded.meta_json
            """,
            (
                k,
                display_name.strip(),
                category.strip(),
                parent_key.strip() if isinstance(parent_key, str) and parent_key.strip() else None,
                llm_profile_name.strip()
                if isinstance(llm_profile_name, str) and llm_profile_name.strip()
                else None,
                prompt_block_id.strip()
                if isinstance(prompt_block_id, str) and prompt_block_id.strip()
                else None,
                builtin,
                1 if enabled else 0,
                meta_json if meta_json else None,
            ),
        )
        await conn.commit()

    async def delete_agent_kind_def(
        self,
        conn: aiosqlite.Connection,
        key: str,
        *,
        hard: bool = False,
    ) -> tuple[bool, str]:
        k = (key or "").strip().lower()
        if not k:
            return False, "empty key"
        cur = await conn.execute(
            "SELECT builtin, enabled FROM agent_kind_defs WHERE key=?",
            (k,),
        )
        row = await cur.fetchone()
        if not row:
            return False, "not found"
        if int(row[0]) == 1:
            return False, "cannot delete builtin row"
        if hard:
            await conn.execute("DELETE FROM agent_kind_defs WHERE key=?", (k,))
            await conn.commit()
            return True, "deleted"
        if int(row[1]) == 0:
            return True, "already_disabled"
        await conn.execute(
            "UPDATE agent_kind_defs SET enabled=0 WHERE key=?",
            (k,),
        )
        await conn.commit()
        return True, "disabled"

    async def upsert_work_mode_def(
        self,
        conn: aiosqlite.Connection,
        *,
        key: str,
        display_name: str,
        llm_profile_name: str | None = None,
        prompt_block_id: str | None = None,
        tmp_policy_json: str | None = None,
        policies_json: str | None = None,
        enabled: bool = True,
        meta_json: str | None = None,
        builtin: int = 0,
    ) -> None:
        k = (key or "").strip().lower()
        if not k:
            raise ValueError("work_mode key required")
        await conn.execute(
            """
            INSERT INTO work_mode_defs (
                key, display_name, llm_profile_name, prompt_block_id,
                tmp_policy_json, policies_json, builtin, enabled, meta_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET
                display_name=excluded.display_name,
                llm_profile_name=excluded.llm_profile_name,
                prompt_block_id=excluded.prompt_block_id,
                tmp_policy_json=excluded.tmp_policy_json,
                policies_json=excluded.policies_json,
                enabled=excluded.enabled,
                meta_json=excluded.meta_json
            """,
            (
                k,
                display_name.strip(),
                llm_profile_name.strip()
                if isinstance(llm_profile_name, str) and llm_profile_name.strip()
                else None,
                prompt_block_id.strip()
                if isinstance(prompt_block_id, str) and prompt_block_id.strip()
                else None,
                tmp_policy_json if tmp_policy_json else None,
                policies_json if policies_json else None,
                builtin,
                1 if enabled else 0,
                meta_json if meta_json else None,
            ),
        )
        await conn.commit()

    async def delete_work_mode_def(
        self,
        conn: aiosqlite.Connection,
        key: str,
        *,
        hard: bool = False,
    ) -> tuple[bool, str]:
        k = (key or "").strip().lower()
        if not k:
            return False, "empty key"
        cur = await conn.execute(
            "SELECT builtin, enabled FROM work_mode_defs WHERE key=?",
            (k,),
        )
        row = await cur.fetchone()
        if not row:
            return False, "not found"
        if int(row[0]) == 1:
            return False, "cannot delete builtin row"
        if hard:
            await conn.execute("DELETE FROM work_mode_defs WHERE key=?", (k,))
            await conn.commit()
            return True, "deleted"
        if int(row[1]) == 0:
            return True, "already_disabled"
        await conn.execute(
            "UPDATE work_mode_defs SET enabled=0 WHERE key=?",
            (k,),
        )
        await conn.commit()
        return True, "disabled"

    async def delete_prompt_block(
        self, conn: aiosqlite.Connection, block_id: str
    ) -> tuple[bool, str]:
        bid = (block_id or "").strip()
        if not bid:
            return False, "empty id"
        cur = await conn.execute(
            """
            SELECT 1 FROM agent_kind_defs WHERE prompt_block_id=? LIMIT 1
            """,
            (bid,),
        )
        if await cur.fetchone():
            return False, "prompt_block still referenced by agent_kind_defs"
        cur = await conn.execute(
            """
            SELECT 1 FROM work_mode_defs WHERE prompt_block_id=? LIMIT 1
            """,
            (bid,),
        )
        if await cur.fetchone():
            return False, "prompt_block still referenced by work_mode_defs"
        await conn.execute("DELETE FROM prompt_blocks WHERE id=?", (bid,))
        await conn.commit()
        return True, "ok"
