# Trustcafe API Wrapper

## Prerequisites

You will need:
1. API Client and Secret
2. Python 3.11 or something sensible or above
3. A method for environment variables like [python-dotenv](https://pypi.org/project/python-dotenv/)

### API client key and secret from the site

1. https://www.trustcafe.io/en/myaccount/apiaccess for production and https://alpha.wts2.net/en/myaccount/apiaccess for alpha (this will change in the future)
2. Click "Create new client credentials key pair"
3. Choose all of the scopes or select which you would like to restrict the key to
4. Scroll down and press Save
5. Copy the client key and secret to your environment, the secret cannot be retrieved without making a new one

## Installation

pip install trustcafeapiwrapper

OR

uv add trustcafeapiwrapper

## Usage



```python
import trustcafeapiwrapper, os


API = trustcafeapiwrapper.APIClient(
    client_id=os.getenv("client_id"),
    client_secret=os.getenv("client_secret")
)

profile = API.run_job('userprofile.get', "simon-little")


from trustcafeapiwrapper.wrappers.post.create_post import create_post

API.wrapped(create_post(
    "This is a test post created via the create_post wrapper function.",
))
```
## More
- [Development "Things to think about do"](https://gitlab.com/trustcafe/trustcafe-api-wrapper/-/blob/main/development.md)
- [Documentation](https://gitlab.com/trustcafe/trustcafe-api-wrapper/-/blob/main/documentation.md)
