def get_parent_pksk_from_path(parent_path):
    if parent_path == '/':
        return 'maintrunk#maintrunk'
    
    entity, slug = parent_path.strip('/').split('/')
    
    if entity == 'branch':
        entity = 'subwiki'
    elif entity == 'user':
        entity = 'userprofile'

    if entity not in ['userprofile', 'subwiki']:
        raise ValueError(f"Invalid parent entity: {entity}. Must be 'userprofile' or 'subwiki'.")
    
    return f"{entity}#{slug}"