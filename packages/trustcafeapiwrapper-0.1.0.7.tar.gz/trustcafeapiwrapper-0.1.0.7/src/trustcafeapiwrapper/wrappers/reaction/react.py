
from trustcafeapiwrapper.utils import get_child_spksk_from_paths
def react(reaction_type: str, parent_path: str, item_path: str):
    """
    React to something.  ie a post or a comment.
    This is one endpoint for creating, updating and deleting reactions.  
    The logic is handled in the backend.

    Args:
        
    Returns:
        dict: A dictionary containing the job name and payload for creating the post 
        that will be processed by the API client wrapper function.
    """
    parent = get_child_spksk_from_paths(parent_path, item_path)
    return {
            "job_function": "reaction.reacttosomething",            
            "payload": {
                "reaction": reaction_type,                
                "parent": parent
            }
        }
