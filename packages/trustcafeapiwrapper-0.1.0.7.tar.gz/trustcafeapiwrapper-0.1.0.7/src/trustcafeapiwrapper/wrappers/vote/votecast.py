from trustcafeapiwrapper.utils import get_child_spksk_from_paths

def votecast(vote: str, parent_path: str, item_path: str):
    """
    Creates a new vote in the API.

    Args:
        
    Returns:
        dict: A dictionary containing the job name and payload for creating the post 
        that will be processed by the API client wrapper function.
    """
    parent = get_child_spksk_from_paths(parent_path, item_path)
    
    return {
            "job_function": "vote.votecast",            
            "payload": {
                "vote": vote,                
                "parent": parent
            }
        }
