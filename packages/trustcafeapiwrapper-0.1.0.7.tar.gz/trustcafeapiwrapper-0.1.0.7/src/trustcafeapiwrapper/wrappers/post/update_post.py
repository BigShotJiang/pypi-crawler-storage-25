from trustcafeapiwrapper.utils import get_post_pksk, get_parent_pksk_from_path

def update_post(parent_path, post_path, post_text, blur_label=None, card_url=None, collaborative=False):
    """
    Updates an existing post.
    
    Args:
        post_slug (str): The slug of the post to update.
        post_text (str): The new text for the post.
        parent_path (str, optional): The parent path for the post. Defaults to '/'.
        blur_label (str, optional): The blur label for the post. Defaults to None.
        card_url (str, optional): The card URL for the post. Defaults to None.
        collaborative (bool, optional): Whether the post is collaborative. Defaults to False.

        Returns:
            dict: The updated post data.
    """
    parent_pksk = get_parent_pksk_from_path(parent_path)
    post_pksk = get_post_pksk(parent_pksk, post_path)

    payload = {
        "key": {
            "pk": post_pksk.get('pk', None),
            "sk": post_pksk.get('sk', None)
        },
        "postSlug": post_path.strip('/post/'),
        "blurLabel": blur_label,
        "cardUrl": card_url,
        "postText": post_text,
        "collaborative": collaborative,
        
    }

    return {
            "job_function": "post.update",            
            "payload": payload
        }