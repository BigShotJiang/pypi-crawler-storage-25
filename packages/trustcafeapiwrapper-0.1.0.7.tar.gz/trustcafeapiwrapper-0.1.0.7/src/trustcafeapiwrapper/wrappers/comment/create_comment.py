
from trustcafeapiwrapper.utils.get_parent_pksk_from_path import get_parent_pksk_from_path
from trustcafeapiwrapper.utils.get_post_pksk import get_post_pksk
def create_comment(comment_text, post_slug, parent_path, blur_label=None, version=3):
    """
    Creates a new comment.

    Args:
        comment_text (str): The text content of the comment.
        parent_path (str): The parent path for the comment, in the format 'userprofile/slug' or 'subwiki/slug'.
        blur_label (str, optional): An optional label for blurring the comment content.
        version (int, optional): The version of the comment structure to use, default is 3.

    Returns:
        dict: A dictionary containing the job name and payload for creating the comment 
        that will be processed by the API client wrapper function.
    """

    parent_pksk = get_parent_pksk_from_path(parent_path)
    post_pksk = get_post_pksk(parent_pksk, post_slug)
    return {
            "job_function": "comment.create",            
            "payload": {
                "blurLabel": blur_label,
                "commentText": comment_text,
                "parent": {
                    "pk": post_pksk['pk'],
                    "sk": post_pksk['sk'],
                    "slug": parent_path.split('/')[-1]
                },
                "topLevel": {
                    "pk": post_pksk['pk'],
                    "sk": post_pksk['sk']
                },
                "version": version
            }
        }