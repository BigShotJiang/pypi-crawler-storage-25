# ABAP Accelerator MCP Server

<!-- mcp-name: io.github.openkash/abap-accelerator -->

SAP ADT API [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) server for ABAP development. Works with any MCP-compatible client including Claude Code, Amazon Q Developer, Kiro, Cursor, Windsurf, and more.

> **Fork notice:** This is a fork of [AWS ABAP Accelerator for Amazon Q Developer](https://github.com/aws-solutions-library-samples/guidance-for-deploying-sap-abap-accelerator-for-amazon-q-developer), repackaged for PyPI and optimized for local stdio runs. The original project targets Docker/ECS enterprise deployments; this fork focuses on the simplest path: `pip install` and go.

## Quick Start

```bash
pip install abap-accelerator
```

Create a `.env` file or set environment variables:

```bash
SAP_HOST=your-sap-host.example.com   # or host:port (e.g., 10.0.0.1:44300)
SAP_INSTANCE_NUMBER=00                # used to calculate port when SAP_HOST has no port
SAP_CLIENT=100
SAP_USERNAME=your_username
SAP_PASSWORD=your_password
```

Run:

```bash
abap-accelerator
```

That's it. The server starts in stdio mode and is ready for your MCP client.

## MCP Client Configuration

Add to your client's MCP config file:

**Claude Code** (`.mcp.json` in project root):
```json
{
  "mcpServers": {
    "abap-accelerator": {
      "command": "abap-accelerator",
      "env": {
        "SAP_HOST": "your-sap-host.example.com",
        "SAP_INSTANCE_NUMBER": "00",
        "SAP_CLIENT": "100",
        "SAP_USERNAME": "your_username",
        "SAP_PASSWORD": "your_password"
      }
    }
  }
}
```

**Amazon Q Developer** (`~/.aws/amazonq/mcp.json` or workspace `.amazonq/mcp.json`):
```json
{
  "mcpServers": {
    "abap-accelerator": {
      "command": "abap-accelerator",
      "env": {
        "SAP_HOST": "your-sap-host.example.com",
        "SAP_INSTANCE_NUMBER": "00",
        "SAP_CLIENT": "100",
        "SAP_USERNAME": "your_username",
        "SAP_PASSWORD": "your_password"
      }
    }
  }
}
```

**Kiro** (`.kiro/settings/mcp.json`):
```json
{
  "mcpServers": {
    "abap-accelerator": {
      "command": "abap-accelerator",
      "env": {
        "SAP_HOST": "your-sap-host.example.com",
        "SAP_INSTANCE_NUMBER": "00",
        "SAP_CLIENT": "100",
        "SAP_USERNAME": "your_username",
        "SAP_PASSWORD": "your_password"
      }
    }
  }
}
```

> **Tip:** If you run `abap-accelerator` from a directory with a `.env` file, you can omit the `env` block — the server loads `.env` automatically.

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `SAP_HOST` | Yes | - | SAP hostname or host:port |
| `SAP_INSTANCE_NUMBER` | Yes | - | Instance number (00-99), used to calculate port |
| `SAP_CLIENT` | Yes | - | SAP client number (e.g., 100) |
| `SAP_USERNAME` | Yes | - | SAP username |
| `SAP_PASSWORD` | Yes | - | SAP password |
| `SAP_LANGUAGE` | No | `EN` | SAP language |
| `SAP_SECURE` | No | `true` | Use HTTPS |
| `SSL_VERIFY` | No | `true` | Verify SSL certificates (set `false` for self-signed) |
| `CUSTOM_CA_CERT_PATH` | No | - | Path to custom CA certificate |
| `LOG_LEVEL` | No | `INFO` | Logging level (DEBUG, INFO, WARNING, ERROR) |

## SAP Port Calculation

The server calculates the SAP port from the instance number:

| Instance Number | HTTPS Port | HTTP Port |
|-----------------|------------|-----------|
| 00 | 44300 | 8000 |
| 01 | 44301 | 8001 |
| 02 | 44302 | 8002 |

Formula: HTTPS = `44300 + instance_number`, HTTP = `8000 + instance_number`

If `SAP_HOST` includes a port (e.g., `10.0.0.1:44300`), the instance number is ignored.

## Available Tools

| Tool | Description |
|------|-------------|
| `aws_abap_cb_connection_status` | Check SAP connection status |
| `aws_abap_cb_get_objects` | List ABAP objects in a package |
| `aws_abap_cb_get_source` | Get source code of an object |
| `aws_abap_cb_search_object` | Search for ABAP objects |
| `aws_abap_cb_create_object` | Create new ABAP object |
| `aws_abap_cb_update_source` | Update source code |
| `aws_abap_cb_check_syntax` | Check syntax of source code |
| `aws_abap_cb_activate_object` | Activate ABAP object |
| `aws_abap_cb_activate_objects_batch` | Batch activate objects |
| `aws_abap_cb_run_atc_check` | Run ATC quality checks |
| `aws_abap_cb_run_unit_tests` | Execute unit tests |
| `aws_abap_cb_get_test_classes` | Get test classes for an object |
| `aws_abap_cb_create_or_update_test_class` | Create/update test class |
| `aws_abap_cb_get_migration_analysis` | Get migration analysis |
| `aws_abap_cb_get_transport_requests` | Get transport requests |

## Environment Guidance

This tool provides direct access to ABAP development objects. Use it in non-production environments:

| Intended | Not Recommended |
|----------|----------------|
| Development (DEV) | Production (PRD) |
| Sandbox (SBX) | Pre-production |
| Quality Assurance (QAS) | |
| Test / Training / Demo | |

## Troubleshooting

**SSL Certificate Errors** (`SSL: CERTIFICATE_VERIFY_FAILED`):
- Set `CUSTOM_CA_CERT_PATH` to your corporate CA cert
- For testing only: set `SSL_VERIFY=false`

**Connection Timeout**:
- Verify SAP system is reachable from your network
- Check firewall allows port 44300 (or your SAP port)
- Verify SAP ADT services are enabled (transaction SICF)

**Debug Logging**:
- Set `LOG_LEVEL=DEBUG` for verbose output

## License

MIT No Attribution (MIT-0) — see [LICENSE](./LICENSE)

Original work Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
