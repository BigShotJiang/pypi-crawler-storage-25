# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.2.0] - 2026-03-20

### Added

- **Metabase v58 support**: Full support for Metabase v0.58.x
  - New `V58` enum value and `V58Adapter` implementation
  - Handles nullable card fields introduced in v58: `dashboard_tab_id`, `entity_id`, `parameter_mappings`
  - Same MBQL 5 (stages) query format as v57
  - New `docker-compose.test.v58.yml` for integration testing
  - Run with `MB_METABASE_VERSION=v58` or `--metabase-version v58`
- **Permissions Migration**: Export and import permission groups and access control settings
  - Export permission groups with `--include-permissions` flag
  - Import and apply permissions with `--apply-permissions` flag
  - Automatic remapping of group IDs, database IDs, and collection IDs
  - Solves "403 Forbidden" errors after migration
  - Comprehensive documentation in `doc/PERMISSIONS_MIGRATION.md`
- **Improved Permissions Logging**: Reduced log spam with batch reporting
  - Unmapped collections reported once at INFO level
  - Unmapped databases reported once at WARNING level
  - Summary report after permissions import
- Preparing for initial PyPI release
- Comprehensive test suite
- CI/CD pipeline with GitHub Actions
- Code quality tools (black, ruff, mypy)
- Community guidelines and contribution documentation

### Changed

- **Collection rename strategy behavior**: `--conflict rename` now reuses the existing
  target collection and applies renaming at the card/dashboard level only. Previously,
  a new collection with a unique name (e.g., "My Collection (1)") was created alongside
  the existing one.

### Fixed

- **Permissions Import 409 Conflict**: Fixed revision number conflict when applying permissions
  - Now fetches current revision from target instance before applying
  - Prevents "someone else edited the permissions" errors
- **v57 pMBQL `source-card` dependency extraction**: Metabase v57 changed query format from
  `"source-table": "card__123"` (string) to `"source-card": 123` (integer). The topological
  sort only looked for the string format, causing cards with v57 references to be imported in
  wrong order.
- **v57 pMBQL metric card references in export**: The export service did not discover
  `source-card` integer dependencies during dependency traversal, and the query remapper did
  not remap metric card IDs in the pMBQL `["metric", N, {...}]` tuple format.
- **Metric/question card conflict resolution**: Metric cards (`type: "metric"`) and question
  cards (`type: "question"`) can share the same name. During import with `--conflict overwrite`,
  the toolkit matched by name only, so importing a metric card would overwrite a same-named
  question card. Fixed by adding `card_type` parameter to `find_existing_card()` and filtering
  by Metabase model type.
- **Metric cards excluded from collection listing during export**: The export collection listing
  only requested `model: "card"` and `model: "dashboard"`, missing `model: "metric"`. Metric
  cards were silently dropped from exports.

## [1.0.0] - 2025-10-07

### Added

- Initial release of Metabase Migration Toolkit
- Export Metabase collections, cards (questions), and dashboards
- Import with intelligent database remapping
- Recursive dependency resolution for cards
- Conflict resolution strategies (skip, overwrite, rename)
- Dry-run mode for safe preview of import actions
- Comprehensive structured logging with configurable levels
- Retry logic with exponential backoff for API requests
- Multiple authentication methods (username/password, session token, personal token)
- Environment variable support via .env files
- Progress bars for long-running operations
- Manifest file generation for export tracking
- Collection hierarchy preservation
- Support for archived items (optional inclusion)
- Selective export by root collection IDs

### Security

- Credentials handled securely via environment variables
- Passwords and tokens masked in logs and export files
- No sensitive data exposed in error messages

[Unreleased]: https://github.com/yourusername/metabase-migration-toolkit/compare/v1.2.0...HEAD
[1.2.0]: https://github.com/yourusername/metabase-migration-toolkit/compare/v1.0.0...v1.2.0
[1.0.0]: https://github.com/yourusername/metabase-migration-toolkit/releases/tag/v1.0.0
