# Copyright (c) 2019 The Boule Developers.
# Distributed under the terms of the BSD 3-Clause License.
# SPDX-License-Identifier: BSD-3-Clause
#
# This code is part of the Fatiando a Terra project (https://www.fatiando.org)
#
"""
These are the functions and classes that make up the Boule API.
"""

from ._ellipsoid import Ellipsoid
from ._realizations import (
    EGM96,
    GRS80,
    WGS84,
    Callisto2024,
    Ceres2018,
    Charon2024,
    Enceladus2024,
    Europa2024,
    Ganymede2024,
    Io2024,
    Mars2009,
    Mercury2015,
    Mercury2024,
    Moon2015,
    Pluto2024,
    Titan2024,
    Venus2015,
    Vesta2017,
    VestaTriaxial2017,
)
from ._sphere import Sphere
from ._triaxialellipsoid import TriaxialEllipsoid
from ._version import __version__

# Append a leading "v" to the generated version by setuptools_scm
__version__ = f"v{__version__}"
