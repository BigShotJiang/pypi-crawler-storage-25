from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from ._expression import evaluate_condition
from .component import Component, build_default_params, default_view_status, iter_arg_definitions
from .connection import Connection, default_edge_attrs
from .exceptions import ValidationError
from .types import EdgeData, EdgeType, GraphData, ModelPublicity, NodeData

if TYPE_CHECKING:
    from .client import DxPipeClient


def _unwrap(payload: Any) -> Any:
    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


class Model:
    def __init__(
        self,
        *,
        client: "DxPipeClient",
        model_id: str | None,
        name: str,
        workspace_type: str,
        description: str = "",
        publicity: ModelPublicity = "private",
        snapshot: dict[str, Any] | None = None,
        raw: dict[str, Any] | None = None,
    ) -> None:
        self.client = client
        self.id = model_id
        self.name = name
        self.workspace_type = workspace_type
        self.description = description
        self.publicity = publicity
        self.raw = raw or {}
        self.global_params: dict[str, Any] = {}
        self._components: dict[str, Component] = {}
        self._connections: dict[str, Connection] = {}
        self._component_counters: Counter[str] = Counter()
        self._edge_counter = 0
        self._load_snapshot(snapshot or {"global": {}, "nodes": [], "edges": []})

    @classmethod
    def list(cls, client: "DxPipeClient", **params: Any) -> list["Model"]:
        payload = _unwrap(client.http.get("/api/models/", params=params or None))
        if isinstance(payload, dict) and "results" in payload:
            items = payload["results"]
        else:
            items = payload if isinstance(payload, list) else []
        return [cls.from_payload(client, item) for item in items if isinstance(item, dict)]

    @classmethod
    def get(cls, client: "DxPipeClient", model_id: str) -> "Model":
        payload = _unwrap(client.http.get(f"/api/models/{model_id}/"))
        if not isinstance(payload, dict):
            raise TypeError("Model payload must be a JSON object.")
        return cls.from_payload(client, payload)

    @classmethod
    def create(
        cls,
        client: "DxPipeClient",
        *,
        name: str,
        workspace_type: str,
        description: str = "",
        publicity: ModelPublicity = "private",
        global_params: dict[str, Any] | None = None,
    ) -> "Model":
        initial_global = client.meta.get_default_global_params(workspace_type)
        if global_params:
            initial_global.update(global_params)
        model = cls(
            client=client,
            model_id=None,
            name=name,
            workspace_type=workspace_type,
            description=description,
            publicity=publicity,
            snapshot={"global": initial_global, "nodes": [], "edges": []},
        )
        payload = _unwrap(
            client.http.post(
                "/api/models/",
                json={
                    "name": name,
                    "description": description,
                    "publicity": publicity,
                    "type": workspace_type,
                    "snapshot_data": model.to_snapshot_data(),
                },
            )
        )
        if not isinstance(payload, dict):
            raise TypeError("Model create response must be a JSON object.")
        return cls.from_payload(client, payload)

    @classmethod
    def from_payload(cls, client: "DxPipeClient", payload: dict[str, Any]) -> "Model":
        snapshot = payload.get("current_snapshot") or payload.get("snapshot_data") or {"global": {}, "nodes": [], "edges": []}
        return cls(
            client=client,
            model_id=str(payload.get("id")) if payload.get("id") is not None else None,
            name=str(payload.get("name", "")),
            workspace_type=str(payload.get("type", "")),
            description=str(payload.get("description", "")),
            publicity=payload.get("publicity", "private"),
            snapshot=snapshot,
            raw=payload,
        )

    @property
    def components(self) -> list[Component]:
        return list(self._components.values())

    @property
    def connections(self) -> list[Connection]:
        return list(self._connections.values())

    def get_component(self, component_id: str) -> Component:
        return self._components[component_id]

    def list_components(self) -> list[Component]:
        return self.components

    def list_connections(self) -> list[Connection]:
        return self.connections

    def set_global(self, key: str, value: Any) -> "Model":
        self.global_params[key] = value
        return self

    def get_global(self, key: str, default: Any = None) -> Any:
        return self.global_params.get(key, default)

    def add_component(
        self,
        class_id: str,
        *,
        label: str | None = None,
        params: dict[str, Any] | None = None,
        position: tuple[float, float] | None = None,
        view_status: dict[str, Any] | None = None,
    ) -> Component:
        definition = self.client.meta.get_component_definition(self.workspace_type, class_id)
        component_id = self._next_component_id(class_id)
        default_params = build_default_params(definition)
        merged_params = {**default_params, **(params or {})}
        pins_label = {
            str(port.get("key")): ""
            for port in definition.get("portsDefinition", []) or []
            if isinstance(port, dict) and "key" in port
        }
        component = Component(
            model=self,
            component_id=component_id,
            class_id=class_id,
            label=label or str(definition.get("label", component_id)),
            params=merged_params,
            pins_label=pins_label,
            view_status=(view_status or default_view_status(position)),
        )
        self._components[component.id] = component
        return component

    def remove_component(self, component_id: str) -> None:
        if component_id not in self._components:
            return
        del self._components[component_id]
        for edge_id in [
            edge.id
            for edge in self._connections.values()
            if edge.source_component == component_id or edge.target_component == component_id
        ]:
            self._connections.pop(edge_id, None)

    def connect(
        self,
        source_component: str | Component,
        source_port: str,
        target_component: str | Component,
        target_port: str,
        *,
        router: dict[str, Any] | None = None,
        vertices: list[dict[str, float]] | None = None,
        attrs: dict[str, Any] | None = None,
    ) -> Connection:
        source = self._resolve_component(source_component)
        target = self._resolve_component(target_component)
        source_ref = source.port(source_port)
        target_ref = target.port(target_port)
        if not source_ref.is_active:
            raise ValidationError(f"Source port {source.id}.{source_port} is not active.")
        if not target_ref.is_active:
            raise ValidationError(f"Target port {target.id}.{target_port} is not active.")
        if source_ref.type != target_ref.type:
            raise ValidationError(
                f"Port type mismatch: {source.id}.{source_port} is {source_ref.type}, "
                f"but {target.id}.{target_port} is {target_ref.type}."
            )
        edge_type: EdgeType = "fluid-edge" if source_ref.type == "FLUID" else "control-edge"
        connection = Connection(
            id=self._next_edge_id(),
            source_component=source.id,
            source_port=source_port,
            target_component=target.id,
            target_port=target_port,
            type=edge_type,
            attrs=deepcopy(attrs) if attrs else default_edge_attrs(edge_type),
            router=deepcopy(router) if router else {"name": "orth"},
            vertices=deepcopy(vertices) if vertices else [],
        )
        self._connections[connection.id] = connection
        return connection

    def disconnect(self, connection_id: str) -> None:
        self._connections.pop(connection_id, None)

    def validate(self) -> list[str]:
        issues: list[str] = []
        signal_map: defaultdict[str, list[str]] = defaultdict(list)
        for component in self.components:
            for port_key, label in component.pins_label.items():
                text = str(label).strip()
                if not text:
                    continue
                port = component.port(port_key)
                if port.is_active:
                    signal_map[text].append(f"{component.id}:{port_key}")
            for signal_key, label in component.signal_values().items():
                signal_map[label].append(f"{component.id}:{signal_key}")

        for component in self.components:
            issues.extend(f"component {component.label}: {item}" for item in component.validate())
            for port in component.active_ports:
                edge_connected = self._count_port_connections(component.id, port.key) >= 1
                label = component.get_pin_label(port.key).strip()
                signal_connected = bool(label and len(signal_map.get(label, [])) >= 2)
                if not edge_connected and not signal_connected:
                    issues.append(f"component {component.label}: port {port.name} is not connected")
            for arg_def in iter_arg_definitions(component.definition.get("argsGroup", [])):
                if arg_def.get("type") != "signal":
                    continue
                key = arg_def.get("key")
                if not key:
                    continue
                if not evaluate_condition(arg_def.get("condition", "true"), {**component.params, "context": {}}):
                    continue
                value = str(component.params.get(key, "")).strip()
                if value and len(signal_map.get(value, [])) < 2:
                    issues.append(
                        f"component {component.label}: signal {arg_def.get('label', key)} is not connected"
                    )
        return issues

    def to_snapshot_data(self) -> GraphData:
        return {
            "global": deepcopy(self.global_params),
            "nodes": [component.to_node_data() for component in self.components],
            "edges": [connection.to_edge_data() for connection in self.connections],
        }

    def save(self, *, validate: bool = False) -> "Model":
        if not self.id:
            raise ValidationError("Cannot save a model without a server-side id. Use save_as or create first.")
        if validate:
            issues = self.validate()
            if issues:
                raise ValidationError("; ".join(issues))
        payload = _unwrap(
            self.client.http.put(
                f"/api/models/{self.id}/",
                json={
                    "name": self.name,
                    "description": self.description,
                    "publicity": self.publicity,
                    "snapshot_data": self.to_snapshot_data(),
                },
            )
        )
        if isinstance(payload, dict):
            refreshed = Model.from_payload(self.client, payload)
            self.__dict__.update(refreshed.__dict__)
        return self

    def save_as(
        self,
        *,
        name: str,
        description: str | None = None,
        publicity: ModelPublicity | None = None,
    ) -> "Model":
        payload = _unwrap(
            self.client.http.post(
                "/api/models/",
                json={
                    "name": name,
                    "description": self.description if description is None else description,
                    "publicity": self.publicity if publicity is None else publicity,
                    "type": self.workspace_type,
                    "snapshot_data": self.to_snapshot_data(),
                },
            )
        )
        if not isinstance(payload, dict):
            raise TypeError("Model save_as response must be a JSON object.")
        return Model.from_payload(self.client, payload)

    def delete(self) -> None:
        if not self.id:
            return
        self.client.http.delete(f"/api/models/{self.id}/")

    def run(self, *, timeout: int | None = None, image: str | None = None) -> "Job":
        graph = self.to_snapshot_data()
        graph["global"] = deepcopy(graph["global"])
        graph["global"].setdefault("taskID", str(uuid4()))
        if timeout is not None:
            graph["global"]["timeout"] = timeout
        if image is not None:
            graph["global"]["image"] = image
        workspace_definition = self.client.meta.get_workspace_definition(self.workspace_type)
        payload = _unwrap(
            self.client.http.post(
                "/api/jobs/",
                json={
                    "workspace_type": self.workspace_type,
                    "model_id": self.id,
                    "data": {
                        "graph": graph,
                        "definition": workspace_definition.get("components", {}),
                    }
                },
            )
        )
        if not isinstance(payload, dict):
            raise TypeError("Job create response must be a JSON object.")
        from .job import Job

        return Job.from_payload(self.client, payload)

    def _load_snapshot(self, snapshot: dict[str, Any]) -> None:
        self.global_params = deepcopy(snapshot.get("global", {})) if isinstance(snapshot, dict) else {}
        self._components = {}
        for node in snapshot.get("nodes", []) if isinstance(snapshot, dict) else []:
            if not isinstance(node, dict):
                continue
            component = Component(
                model=self,
                component_id=str(node.get("id", "")),
                class_id=str(node.get("nodeClassID", "")),
                label=str(node.get("label", node.get("id", ""))),
                params=deepcopy(node.get("data", {})),
                pins_label=deepcopy(node.get("pinsLabel", {})),
                view_status=deepcopy(node.get("viewStatus", default_view_status())),
            )
            self._components[component.id] = component
        self._connections = {}
        for edge in snapshot.get("edges", []) if isinstance(snapshot, dict) else []:
            if not isinstance(edge, dict):
                continue
            source = edge.get("source", {})
            target = edge.get("target", {})
            connection = Connection(
                id=str(edge.get("id", "")),
                source_component=str(source.get("cell", "")),
                source_port=str(source.get("port", "")),
                target_component=str(target.get("cell", "")),
                target_port=str(target.get("port", "")),
                type=edge.get("type", "fluid-edge"),
                attrs=deepcopy(edge.get("attrs", {})),
                router=deepcopy(edge.get("router", {"name": "orth"})),
                vertices=deepcopy(edge.get("vertices", [])),
            )
            self._connections[connection.id] = connection
        self._rebuild_counters()

    def _rebuild_counters(self) -> None:
        self._component_counters.clear()
        for component_id in self._components:
            if "_" not in component_id:
                continue
            class_id, suffix = component_id.rsplit("_", 1)
            if suffix.isdigit():
                self._component_counters[class_id] = max(self._component_counters[class_id], int(suffix) + 1)
        max_edge = 0
        for edge_id in self._connections:
            if edge_id.startswith("edge_") and edge_id[5:].isdigit():
                max_edge = max(max_edge, int(edge_id[5:]) + 1)
        self._edge_counter = max_edge

    def _resolve_component(self, value: str | Component) -> Component:
        if isinstance(value, Component):
            return value
        return self._components[value]

    def _next_component_id(self, class_id: str) -> str:
        current = self._component_counters[class_id]
        self._component_counters[class_id] += 1
        return f"{class_id}_{current}"

    def _next_edge_id(self) -> str:
        edge_id = f"edge_{self._edge_counter}"
        self._edge_counter += 1
        return edge_id

    def _count_port_connections(self, component_id: str, port_key: str) -> int:
        return sum(
            1
            for edge in self._connections.values()
            if (edge.source_component == component_id and edge.source_port == port_key)
            or (edge.target_component == component_id and edge.target_port == port_key)
        )
