from __future__ import annotations

from typing import Any, Literal, TypedDict


JobStatus = Literal[
    "pending",
    "running",
    "pausing",
    "paused",
    "stopping",
    "stopped",
    "success",
    "fault",
]
ModelPublicity = Literal["private", "depart_public", "public"]
PortType = Literal["FLUID", "CONTROL"]
EdgeType = Literal["fluid-edge", "control-edge"]
MessageType = Literal["log", "plot", "inspect", "table", "container"]
Verb = Literal["append", "update", "delete"]


class PointData(TypedDict):
    x: float
    y: float


class SizeData(TypedDict):
    width: float
    height: float


class NodeViewStatus(TypedDict):
    flip: bool
    angle: float
    size: SizeData
    position: PointData
    zIndex: int


class NodeEndpoint(TypedDict):
    cell: str
    port: str


class RouterData(TypedDict, total=False):
    name: str


class EdgeAttrs(TypedDict, total=False):
    line: dict[str, Any]


class NodeData(TypedDict):
    id: str
    label: str
    nodeClassID: str
    viewStatus: NodeViewStatus
    data: dict[str, Any]
    pinsLabel: dict[str, str]


class EdgeData(TypedDict):
    id: str
    source: NodeEndpoint
    target: NodeEndpoint
    attrs: dict[str, Any]
    type: EdgeType
    router: RouterData
    vertices: list[PointData]


GraphData = TypedDict(
    "GraphData",
    {
        "global": dict[str, Any],
        "nodes": list[NodeData],
        "edges": list[EdgeData],
    },
)


TaskData = TypedDict(
    "TaskData",
    {
        "graph": GraphData,
        "definition": dict[str, Any],
    },
)


class JobMessagePayload(TypedDict, total=False):
    id: int
    key: str
    verb: Verb
    type: MessageType
    data: Any
