from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .types import EdgeData, EdgeType


def default_edge_attrs(edge_type: EdgeType) -> dict[str, Any]:
    stroke = "#4d4d4d" if edge_type == "fluid-edge" else "#2f73ff"
    return {
        "line": {
            "targetMarker": None,
            "stroke": stroke,
            "strokeWidth": 2,
            "strokeDasharray": "0 0",
        }
    }


@dataclass(slots=True)
class Connection:
    id: str
    source_component: str
    source_port: str
    target_component: str
    target_port: str
    type: EdgeType
    attrs: dict[str, Any] = field(default_factory=dict)
    router: dict[str, Any] = field(default_factory=lambda: {"name": "orth"})
    vertices: list[dict[str, float]] = field(default_factory=list)

    def to_edge_data(self) -> EdgeData:
        return {
            "id": self.id,
            "source": {"cell": self.source_component, "port": self.source_port},
            "target": {"cell": self.target_component, "port": self.target_port},
            "attrs": self.attrs or default_edge_attrs(self.type),
            "type": self.type,
            "router": self.router,
            "vertices": self.vertices,
        }
