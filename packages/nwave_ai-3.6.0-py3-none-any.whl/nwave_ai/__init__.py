"""nwave-ai: CLI installer for the nWave methodology framework."""

__version__ = "3.6.0"
