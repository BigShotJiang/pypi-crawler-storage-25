import os
import sys
import tempfile
import json
import re
from bs4 import BeautifulSoup

def _extract_chunks_with_bs4(html: str) -> str:
    soup = BeautifulSoup(html, 'html.parser')
    for doc_struct in soup(["script", "style", "noscript", "meta", "header", "footer", "nav", "aside"]):
        doc_struct.decompose()
    return soup.get_text(separator=' ', strip=True)

def scrape_and_extract_web_data(url: str, output_format: str = "markdown", use_stealth: bool = True) -> str:
    """
    Navigates to URL using Playwright, bypasses WAF using stealth (optionally),
    waits for network idle, extracts HTML, and formats it using MarkItDown and LLM.
    """
    from playwright.sync_api import sync_playwright
    
    html_content = ""
    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(headless=True)
        except Exception as e:
            if "Executable doesn't exist at" in str(e) or "Please run" in str(e):
                import subprocess
                print("[*] Chromium binary not found. Auto-installing Playwright dependencies...", file=sys.stderr)
                subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)
                browser = p.chromium.launch(headless=True)
            else:
                raise
                
        context = browser.new_context()
        
        if use_stealth:
            try:
                from playwright_stealth import stealth_sync
                page = context.new_page()
                stealth_sync(page)
            except ImportError:
                page = context.new_page()
        else:
            page = context.new_page()
            
        try:
            page.goto(url, wait_until="networkidle", timeout=20000)
        except Exception:
            pass # Timeout but page might be partially loaded
        
        html_content = page.content()
        browser.close()
        
    try:
        from markitdown import MarkItDown
        md = MarkItDown()
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w", encoding="utf-8") as temp_file:
            temp_file.write(html_content)
            temp_path = temp_file.name
            
        result = md.convert(temp_path)
        os.remove(temp_path)
        extracted_text = result.text_content
    except Exception:
        extracted_text = _extract_chunks_with_bs4(html_content)
        
    # Formatting Pipeline using NixAgent Core
    if output_format.lower() == "raw":
        return extracted_text

    from nixagent import Agent
    formatter_agent = Agent(
        name="DocumentationRefiner",
        system_prompt="You are a Documentation Formatter processing partial structural strings sequentially.",
        use_builtin_tools=False
    )
    
    lines = extracted_text.splitlines()
    chunk_size = 200
    final_output = []
    json_master_array = []
    
    for i in range(0, len(lines), chunk_size):
        chunk = "\n".join(lines[i:i+chunk_size])
        if not chunk.strip():
            continue
            
        if output_format.lower() == "json":
            prompt = f"Extract the primary data items from the following web text chunk into a strict JSON array of objects. Output EXACTLY a serialized JSON array (`[]`) and absolutely no other text, preambles, or markdown formatting.\n\n[CHUNK]\n{chunk}"
            chunk_response = formatter_agent.run(user_prompt=prompt, stream=False)
            try:
                match = re.search(r'\[\s*(.*)\s*\]', chunk_response, re.DOTALL)
                if match:
                    json_str = match.group(0)
                    parsed_json = json.loads(json_str)
                    if isinstance(parsed_json, list):
                        json_master_array.extend(parsed_json)
                    else:
                        json_master_array.append(parsed_json)
            except Exception:
                pass
        else:
            prompt = f"Format and clean the following chunk of web extracted text into professional {output_format}:\n\n{chunk}"
            chunk_response = formatter_agent.run(user_prompt=prompt, stream=False)
            final_output.append(chunk_response)

    if output_format.lower() == "json":
        return json.dumps(json_master_array, indent=4)
    return "\n\n".join(final_output)
