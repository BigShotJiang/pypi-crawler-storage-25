import argparse
import sys
from nixagent import Agent
from nixagent.logger import logger
from nixagent.profiles import AgentFactory
from dotenv import load_dotenv

load_dotenv()

def main():
    parser = argparse.ArgumentParser(
        description="NixAgent - Enterprise Multi-Agent AI System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  nixagent 'Analyze the project structure'\n"
            "  nixagent --interactive\n"
            "  nixagent --verbose 'Task with debug output'\n"
            "  nixagent --team CodeGenerator,Analyzer 'Build a REST API'\n"
        ),
    )
    parser.add_argument("task", nargs="?", help="Task description to execute")
    parser.add_argument("--interactive", "-i", action="store_true", help="Run in interactive mode")
    parser.add_argument("--verbose", "-v", action="store_true", help="Show detailed agent output")
    parser.add_argument("--team", "-t", type=str, default="", help="Comma-separated agent profiles for team execution")
    parser.add_argument("--no-stream", action="store_true", help="Disable streaming output")

    args = parser.parse_args()

    if args.verbose:
        import logging
        logger.setLevel(logging.DEBUG)
        
    if args.interactive:
        run_interactive(args)
        
    elif args.task:
        run_task(args)
        
    else:
        parser.print_help()
        sys.exit(1)

def run_task(args):
    team_profiles = [p.strip() for p in args.team.split(",")] if args.team else []
    
    if team_profiles:
        coordinator = Agent("Coordinator", system_prompt="You are coordinating a team to accomplish the user task.")
        for profile in team_profiles:
            sub_agent = AgentFactory.create_agent(profile)
            if sub_agent:
                coordinator.register_collaborator(sub_agent)
            else:
                print(f"Warning: Unknown profile {profile}")
        
        reply = coordinator.run(args.task, stream=not args.no_stream)
    else:
        agent = Agent("Primary", system_prompt="You are a highly capable general assistant.")
        reply = agent.run(args.task, stream=not args.no_stream)
        
    if args.no_stream:
        print(reply)
    else:
        for chunk in reply:
            sys.stdout.write(chunk)
            sys.stdout.flush()
        print()

def run_interactive(args):
    print("NixAgent - Enterprise Multi-Agent AI System")
    print("=" * 40)
    print("Type your task and press Enter. Type 'quit' to exit.\n")
    
    team_profiles = [p.strip() for p in args.team.split(",")] if args.team else []
    if team_profiles:
        agent = Agent("Coordinator", system_prompt="You are coordinating a team to accomplish the user task.")
        for profile in team_profiles:
            sub = AgentFactory.create_agent(profile)
            if sub: agent.register_collaborator(sub)
    else:
        agent = Agent("Primary", system_prompt="You are a highly capable general assistant.")

    try:
        while True:
            try:
                task = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nShutting down...")
                break

            if not task:
                continue
            if task.lower() in ("quit", "exit", "q"):
                print("Shutting down...")
                break

            reply = agent.run(task, stream=not args.no_stream)
            if args.no_stream:
                print(f"\n{reply}\n")
            else:
                for chunk in reply:
                    sys.stdout.write(chunk)
                    sys.stdout.flush()
                print("\n")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
