"""
EnergyScope MCP Server
======================
MCP server for AI agents to discover, query, and analyse energy market data.
17 tools: 6 data + 11 analytics.

An analyst can ask their AI assistant questions like:
  "What's the latest WTI crude oil price?"
  "Forecast WTI using crude stocks and production as predictors"
  "Are there any regime changes in WTI since 2020?"
  "Is WTI stationary? Run unit root tests."
  "What's the correlation between WTI, Brent, and jet fuel?"
  "Run a Prophet forecast on US crude stocks with US holidays"

The agent uses these tools to search, browse, fetch, and analyse the data.

Register:
    claude mcp add --scope user --transport stdio energyscope -- python "<path>/energyscope_mcp.py"

Requires:
    pip install mcp pyarrow

Env vars:
    ENERGYSCOPE_SERVER  - Flight server address (default: grpc://localhost:8815)
    ENERGYSCOPE_API_KEY - API key for authentication (optional)
"""

import os
import sys
import json
import time
from typing import Optional

import pyarrow as pa
import pyarrow.flight as flight
from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SERVER_ADDRESS = os.environ.get("ENERGYSCOPE_SERVER", "grpc://localhost:8815")
API_KEY = os.environ.get("ENERGYSCOPE_API_KEY", "")

mcp = FastMCP(
    "energyscope",
    instructions="EIA energy market data — petroleum, natural gas, electricity. "
                 "Search 170,000+ time series, browse by category, fetch historical data.",
)

# ---------------------------------------------------------------------------
# Flight client (singleton)
# ---------------------------------------------------------------------------

_client = None


def _call_options():
    """Build FlightCallOptions with API key auth header if configured."""
    if API_KEY:
        import base64
        token = base64.b64encode(f"{API_KEY}:".encode()).decode()
        return flight.FlightCallOptions(headers=[(b"authorization", f"Basic {token}".encode())])
    return None


def get_client() -> flight.FlightClient:
    global _client
    if _client is None:
        _client = flight.connect(SERVER_ADDRESS)
    return _client


def do_action(action_type: str, body: str = "") -> dict:
    """Call a Flight action and return parsed JSON response."""
    client = get_client()
    action = flight.Action(action_type, body.encode() if body else b"")
    results = []
    for result in client.do_action(action, options=_call_options()):
        results.append(json.loads(result.body.to_pybytes()))
    return results[0] if len(results) == 1 else results


def do_get(series: list, start: str = None, end: str = None) -> pa.Table:
    """Fetch data via Flight do_get."""
    client = get_client()
    ticket_dict = {"series": series}
    if start:
        ticket_dict["start"] = start
    if end:
        ticket_dict["end"] = end
    ticket = flight.Ticket(json.dumps(ticket_dict).encode())
    reader = client.do_get(ticket, options=_call_options())
    return reader.read_all()


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def search(query: str, limit: int = 20) -> str:
    """Search for energy data series by keyword.

    Use this to find series IDs for topics like "crude oil", "gasoline prices",
    "natural gas storage", "diesel imports", "jet fuel", etc.

    Returns series_id, name, frequency (D/W/M/A), and units.

    Examples:
      search("WTI crude oil")
      search("gasoline retail price")
      search("natural gas storage")
      search("distillate imports PADD 1")
    """
    result = do_action("search", query)
    if isinstance(result, list) and len(result) == 0:
        return "No series found. Try broader keywords."

    # Truncate to limit
    if isinstance(result, list):
        result = result[:limit]

    lines = []
    for r in result:
        freq = r.get("f", "?")
        units = r.get("units", "")
        lines.append(f"  {r['series_id']:40s}  {freq}  {units:20s}  {r.get('name', '')}")

    header = f"Found {len(result)} series:\n"
    header += f"  {'Series ID':40s}  F  {'Units':20s}  Name\n"
    header += f"  {'-'*40}  -  {'-'*20}  {'-'*40}\n"
    return header + "\n".join(lines)


@mcp.tool()
def get_data(
    series_ids: list[str],
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Fetch time series data for one or more series.

    Args:
        series_ids: List of series IDs (e.g. ["PET.RWTC.D", "PET.RBRTE.D"])
        start: Start date YYYY-MM-DD (optional, defaults to all history)
        end: End date YYYY-MM-DD (optional, defaults to latest)

    Returns data as a table with columns: series_id, period, value.

    Examples:
      get_data(["PET.RWTC.D"], "2024-01-01", "2024-12-31")
      get_data(["PET.RWTC.D", "PET.RBRTE.D"], "2020-01-01")
    """
    table = do_get(series_ids, start, end)

    if table.num_rows == 0:
        return "No data found for the given series and date range."

    # Format as readable table
    lines = [f"{'Series ID':40s}  {'Period':12s}  {'Value':>12s}"]
    lines.append(f"{'-'*40}  {'-'*12}  {'-'*12}")

    sid_col = table.column("series_id")
    period_col = table.column("period")
    value_col = table.column("value")

    for i in range(min(table.num_rows, 500)):  # cap at 500 rows
        sid = sid_col[i].as_py()
        period = period_col[i].as_py()
        value = value_col[i].as_py()
        val_str = f"{value:>12.4f}" if value is not None else f"{'N/A':>12s}"
        lines.append(f"{sid:40s}  {period:12s}  {val_str}")

    result = f"{table.num_rows} rows returned.\n\n" + "\n".join(lines)
    if table.num_rows > 500:
        result += f"\n\n... (showing first 500 of {table.num_rows} rows)"
    return result


@mcp.tool()
def latest(series_ids: list[str]) -> str:
    """Get the latest (most recent) value for one or more series.

    Faster than get_data — returns just the last known data point per series,
    plus the series name and units.

    Args:
        series_ids: List of series IDs

    Examples:
      latest(["PET.RWTC.D"])  # Latest WTI crude oil price
      latest(["PET.RWTC.D", "PET.RBRTE.D"])  # Latest WTI and Brent
    """
    result = do_action("latest", json.dumps({"series": series_ids}))

    lines = []
    for r in result:
        if "error" in r:
            lines.append(f"  {r['series_id']}: {r['error']}")
        else:
            val = r.get("value")
            val_str = f"{val:.4f}" if val is not None else "N/A"
            lines.append(
                f"  {r['series_id']:40s}  {r.get('period', '?'):12s}  "
                f"{val_str:>12s}  {r.get('units', ''):20s}  {r.get('name', '')}"
            )

    header = f"  {'Series ID':40s}  {'Period':12s}  {'Value':>12s}  {'Units':20s}  Name\n"
    header += f"  {'-'*40}  {'-'*12}  {'-'*12}  {'-'*20}  {'-'*30}\n"
    return header + "\n".join(lines)


@mcp.tool()
def browse(category_id: Optional[int] = None) -> str:
    """Browse the EIA data category tree.

    Call with no arguments to see top-level categories.
    Call with a category_id to see its children and series.

    Use this to explore what data is available when you don't know
    the exact series ID.

    Examples:
      browse()             # Top-level categories (Petroleum, Natural Gas, etc.)
      browse(714755)       # Children of a specific category
    """
    body = json.dumps({"id": category_id}) if category_id else "{}"
    result = do_action("browse", body)

    if isinstance(result, list):
        # Top-level categories
        lines = ["Top-level categories:\n"]
        for cat in result:
            children = cat.get("children", 0)
            series = cat.get("series", 0)
            lines.append(f"  [{cat['id']}] {cat['name']}  ({children} subcategories, {series} series)")
        return "\n".join(lines)
    else:
        # Category detail
        lines = [f"Category: {result['name']} (id={result['id']})\n"]

        children = result.get("children", [])
        if children:
            lines.append(f"Subcategories ({len(children)}):")
            for cat in children:
                c = cat.get("children", 0)
                s = cat.get("series", 0)
                lines.append(f"  [{cat['id']}] {cat['name']}  ({c} subcategories, {s} series)")

        series = result.get("series", [])
        if series:
            lines.append(f"\nSeries ({len(series)}):")
            for s in series[:50]:  # cap display
                lines.append(f"  {s['series_id']:40s}  {s.get('f', '?')}  {s.get('units', ''):20s}  {s.get('name', '')}")
            if len(series) > 50:
                lines.append(f"  ... and {len(series) - 50} more")

        return "\n".join(lines)


@mcp.tool()
def datasets() -> str:
    """List available datasets and their status (loaded, rows, series count).

    Shows what data is currently available on the server.
    """
    result = do_action("list_datasets")

    lines = [f"{'Name':10s}  {'Status':10s}  {'Rows':>12s}  {'Series':>10s}"]
    lines.append(f"{'-'*10}  {'-'*10}  {'-'*12}  {'-'*10}")

    for ds in result:
        status = "loaded" if ds.get("loaded") else "available"
        rows = f"{ds.get('rows', 0):>12,}" if ds.get("loaded") else f"{'—':>12s}"
        series = f"{ds.get('series', 0):>10,}" if ds.get("loaded") else f"{'—':>10s}"
        lines.append(f"{ds['name']:10s}  {status:10s}  {rows}  {series}")

    return "\n".join(lines)


@mcp.tool()
def health() -> str:
    """Check server health and connection status."""
    try:
        result = do_action("healthcheck")
        return (
            f"Status: {result.get('status', '?')}\n"
            f"Series: {result.get('series_count', 0):,}\n"
            f"Rows: {result.get('data_rows', 0):,}\n"
            f"Server: {SERVER_ADDRESS}"
        )
    except Exception as e:
        return f"Connection failed: {e}\nServer: {SERVER_ADDRESS}"


# ---------------------------------------------------------------------------
# Analytics Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def forecast(
    series_ids: list[str],
    target: str,
    horizon: int = 12,
    method: str = "xgboost",
    engine: str = "both",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Multi-factor forecast using XGBoost/ElasticNet/Ridge/OLS regression.
    Auto-forecasts predictor series with ARIMA and/or Prophet.

    Args:
        series_ids: All series (target + predictors), e.g. ["PET.RWTC.D", "PET.WCESTUS1.W"]
        target: The series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        method: xgboost (default), elasticnet, ridge, ols
        engine: Predictor engine — both (default), arima, prophet
        start: Start date for training (YYYY-MM-DD)
        end: End date for training
    """
    req = {"series": series_ids, "target": target, "horizon": horizon,
           "method": method, "predictor_engine": engine}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("forecast", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"ES.Forecast: {target} (R²={result.get('r_squared', 0):.3f}, method={method}, engine={engine})"]
    lines.append(f"Observations: {result.get('observations', 0)}")
    lines.append("")
    for c in result.get("coefficients", []):
        sel = " *" if c.get("selected") else ""
        lines.append(f"  {c['series']}: {c['coefficient']:.4f}{sel}")
    lines.append("")
    lines.append("Forecast:")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")

    if "forecast_comparison" in result:
        lines.append("")
        lines.append("Comparison (ARIMA vs Prophet predictor engines):")
        for eng, fcs in result["forecast_comparison"].items():
            vals = ", ".join([f"${f['forecast']:.2f}" for f in fcs[:3]])
            lines.append(f"  {eng}: {vals}...")

    return "\n".join(lines)


@mcp.tool()
def arima(
    series_id: str,
    horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Univariate auto-ARIMA forecast with confidence intervals.

    Args:
        series_id: Series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("arima", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"ARIMA{tuple(result.get('order', []))} (AIC={result.get('aic', 0):.1f})"]
    lines.append("")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def prophet(
    series_id: str,
    horizon: int = 12,
    holidays: Optional[str] = None,
    seasonality: str = "additive",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Facebook Prophet forecast with holidays and seasonality.

    Args:
        series_id: Series to forecast, e.g. "PET.WCESTUS1.W"
        horizon: Periods ahead (default 12)
        holidays: Country code for holidays (US, UK, DE, FR)
        seasonality: additive (default) or multiplicative
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon, "seasonality_mode": seasonality}
    if holidays: req["country_holidays"] = holidays
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("prophet", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Prophet forecast ({result.get('frequency', '?')})"]
    if result.get("changepoints"):
        lines.append(f"Changepoints: {', '.join(result['changepoints'][-5:])}")
    lines.append("")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def theta(
    series_id: str,
    horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Theta method forecast — M3 competition winner. Fast, robust benchmark.

    Args:
        series_id: Series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("theta", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Theta forecast ({result.get('observations', 0)} obs)"]
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def breakpoints(
    series_id: str,
    min_shift: float = 0,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Detect structural breaks / regime changes in a series.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        min_shift: Minimum shift magnitude to include (e.g. 5 for $5+)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id}
    if min_shift > 0: req["min_shift"] = min_shift
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("breakpoints", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"{result.get('n_breakpoints', 0)} breakpoints detected:"]
    for bp in result.get("breakpoints", []):
        shift = bp.get("shift", 0)
        lines.append(f"  {bp['period']}: {'+' if shift > 0 else ''}{shift:.1f}  (before: {bp.get('mean_before', 0):.1f} → after: {bp.get('mean_after', 0):.1f})")
    return "\n".join(lines)


@mcp.tool()
def stats(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Descriptive statistics for a series.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("stats", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Stats for {series_id}:"]
    for key in ["count", "mean", "median", "std", "min", "max", "skewness", "kurtosis",
                "p5", "p25", "p75", "p95", "first_date", "last_date", "pct_change"]:
        val = result.get(key)
        if val is not None:
            lines.append(f"  {key}: {val}")
    return "\n".join(lines)


@mcp.tool()
def volatility(
    series_id: str,
    window: int = 20,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Rolling + GARCH(1,1) conditional volatility, annualised.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        window: Rolling window (default 20)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("volatility", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    current = result.get("current", {})
    lines = [f"Volatility for {series_id}:"]
    lines.append(f"  Rolling vol ({window}): {current.get('rolling_vol', 0):.4f}")
    if "garch_vol" in current:
        lines.append(f"  GARCH vol: {current.get('garch_vol', 0):.4f}")
    lines.append(f"  Frequency: {current.get('frequency', '?')}")
    lines.append(f"  Annualised factor: {current.get('annualised_factor', 0)}")
    return "\n".join(lines)


@mcp.tool()
def correlation(
    series_ids: list[str],
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Pairwise correlation matrix for multiple series.

    Args:
        series_ids: List of series IDs (at least 2)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_ids}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("correlation", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    labels = result.get("labels", [])
    matrix = result.get("matrix", [])
    lines = [f"Correlation ({result.get('observations', 0)} observations):"]
    header = "".ljust(25) + "  ".join([l[:10].rjust(10) for l in labels])
    lines.append(header)
    for i, label in enumerate(labels):
        row = label[:25].ljust(25) + "  ".join([f"{matrix[i][j]:.4f}".rjust(10) for j in range(len(labels))])
        lines.append(row)
    return "\n".join(lines)


@mcp.tool()
def unit_root(
    series_id: str,
    test: str = "all",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Unit root tests — is this series stationary? (ADF, KPSS, Phillips-Perron)

    Args:
        series_id: Series to test, e.g. "PET.RWTC.D"
        test: adf, kpss, pp, or all (default)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "test": test}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("unit_root", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Unit root tests for {series_id}:"]
    lines.append(f"Consensus: {result.get('consensus', '?')}")
    for name, t in result.get("tests", {}).items():
        lines.append(f"  {name.upper()}: stat={t.get('statistic', 0):.4f}, p={t.get('p_value', 0):.4f}, stationary={t.get('stationary', '?')}")
    return "\n".join(lines)


@mcp.tool()
def cointegration(
    series_ids: list[str],
    method: str = "johansen",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Cointegration test — do these series move together long-term?

    Args:
        series_ids: List of series IDs (at least 2)
        method: johansen (default) or engle-granger
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_ids, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("cointegration", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Cointegration ({method}): {'COINTEGRATED' if result.get('cointegrated') else 'Not cointegrated'}"]
    lines.append(f"Observations: {result.get('observations', 0)}")
    if "trace_tests" in result:
        for t in result["trace_tests"]:
            lines.append(f"  {t['hypothesis']}: stat={t['trace_stat']:.2f}, cv95={t['cv_95']:.2f}, reject={t.get('reject_95', '?')}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="stdio")
