"ffprobe.py - ffprobe info wrapper for python"

import json
import subprocess
from datetime import timedelta
from os import PathLike
from pathlib import Path
from typing import Any

import ffmpeg


class ffprobe_info(object):
    """
    ffprobe_info

    ffprobe info wrapper for python

    Args:
        d (dict): ffprobe output dictionary

    Returns:
        ffprobe_info object

    Raises:
        FileNotFoundError: If ffprobe executable is not found

    Example:
        >>> from ffprobe import ffprobe_info
        >>> info = ffprobe_info(d)
        >>> info.dur
        datetime.timedelta(seconds=6, microseconds=700000)
        >>> info.file
        Path('video.mp4')
        >>> info.size
        1048576
        >>> info.vc
        'h264'
    """

    def __init__(self, d: dict[str, Any]):
        self.raw_info: dict[str, Any] = d
        self.file: Path = Path(d["format"].get("filename"))
        self.dur: timedelta = timedelta(seconds=float(d["format"]["duration"]))
        self.size: int = int(d["format"]["size"])
        video_streams, audio_streams, subtitle_streams = self.set_streams(d)
        self.video_streams: list | list[dict] = video_streams
        self.audio_streams: list | list[dict] = audio_streams
        self.subtitle_streams: list | list[dict] = subtitle_streams
        self.width: int = (
            self.video_streams[0].get("width", 0) if self.video_streams else 0
        )
        self.height: int = (
            self.video_streams[0].get("height", 0) if self.video_streams else 0
        )
        self.vc: str | None = (
            (
                self.video_streams[0].get("codec_name", None)
                if self.video_streams
                else None
            )
            if self.audio_streams
            else None
        )
        self.ac: str | None = (
            (
                self.audio_streams[0].get("codec_name", None)
                if self.audio_streams
                else None
            )
            if self.audio_streams
            else None
        )
        self.sc: str | None = (
            (
                self.subtitle_streams[0].get("codec_name", None)
                if self.subtitle_streams
                else None
            )
            if self.subtitle_streams
            else None
        )

        self.br: int = int(d["format"].get("bit_rate", 0))
        self.vbr: int = (
            int(self.video_streams[0].get("bit_rate", 0)) if self.video_streams else 0
        )
        self.abr: int = (
            int(self.audio_streams[0].get("bit_rate", 0)) if self.audio_streams else 0
        )

    def set_streams(
        self, d: dict[str, Any]
    ) -> tuple[list | list[dict], list | list[dict], list | list[dict]]:
        """
        Set video and audio streams

        Parameters
        ----------
        d : dict
            ffprobe output dictionary

        Returns
        -------
        tuple
            video_streams, audio_streams, subtitle_streams
        """
        video_streams: list | list[dict] = []
        audio_streams: list | list[dict] = []
        subtitle_streams: list | list[dict] = []
        for stream in d["streams"]:
            codec_type: str = stream["codec_type"]
            if codec_type == "video":
                video_streams.append(stream)
            elif codec_type == "audio":
                audio_streams.append(stream)
            elif codec_type == "subtitle":
                subtitle_streams.append(stream)
        return video_streams, audio_streams, subtitle_streams

    @property
    def has_video(self) -> bool:
        """Check if video streams are available"""
        return bool(self.video_streams)

    @property
    def has_audio(self) -> bool:
        """Check if audio streams are available"""
        return bool(self.audio_streams)

    @property
    def has_subtitle(self) -> bool:
        """Check if subtitle streams are available"""
        return bool(self.subtitle_streams)


def get_video_info(
    file: str | PathLike[str] | Path, ffprobe: str = "ffprobe"
) -> ffprobe_info | None:
    """
    Get video info using ffprobe

    Parameters
    ----------
    file : str
        Path to video file
    ffprobe : str
        Path to ffprobe executable

    Returns
    -------
    ffprobe_info
        ffprobe_info object

    Raises
    ------
    FileNotFoundError
        If ffprobe executable is not found
    """

    file_obj: Path = Path(file)
    sp: subprocess.CompletedProcess = subprocess.run(
        f"{ffprobe} -v quiet -print_format json -show_format -show_streams "
        + f'"{file_obj.resolve()}"',
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if sp.returncode == 1:
        print("ffprobe error occured.")
        print(sp.stderr)
    else:
        d = json.loads(sp.stdout)
        info = ffprobe_info(d)
        return info
    return None


def get_info(file: str | PathLike[str] | Path) -> ffprobe_info | None:
    """
    Get video info using ffprobe, via the typed-ffmpeg library

    Parameters
    ----------
    file : str
        Path to video file

    Returns
    -------
    ffprobe_info
        ffprobe_info object
    """

    probe: dict[str, Any] = ffmpeg.probe(filename=file)
    info: ffprobe_info = ffprobe_info(probe)
    return info
