"""
PDF Compliance Report Generator for PQC Scanner
"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.colors import HexColor, black, white
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_CENTER
from datetime import datetime

DARK_BLUE  = HexColor("#1F4E79")
MID_BLUE   = HexColor("#2E75B6")
LIGHT_GREY = HexColor("#F2F2F2")
MID_GREY   = HexColor("#CCCCCC")
CRITICAL   = HexColor("#C00000")
PASS_GREEN = HexColor("#375623")

def verdict_color(verdict):
    if "CRITICAL" in str(verdict) or "LEAK" in str(verdict): return CRITICAL
    if "PASS" in str(verdict): return PASS_GREEN
    return MID_GREY

def generate_pdf(results: dict, output_path: str, target: str = "liboqs 0.15.0"):
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("T1", fontSize=22, textColor=DARK_BLUE,
        alignment=TA_CENTER, fontName="Helvetica-Bold", spaceAfter=4)
    sub_style = ParagraphStyle("T2", fontSize=11, textColor=MID_BLUE,
        alignment=TA_CENTER, fontName="Helvetica", spaceAfter=4)
    conf_style = ParagraphStyle("C", fontSize=10, textColor=CRITICAL,
        alignment=TA_CENTER, fontName="Helvetica-Bold", spaceAfter=16)
    head_style = ParagraphStyle("H", fontSize=12, textColor=DARK_BLUE,
        fontName="Helvetica-Bold", spaceBefore=14, spaceAfter=6)
    body_style = ParagraphStyle("B", fontSize=10, fontName="Helvetica",
        spaceAfter=6, leading=14)
    foot_style = ParagraphStyle("F", fontSize=8, textColor=MID_GREY,
        alignment=TA_CENTER, fontName="Helvetica")

    doc = SimpleDocTemplate(output_path, pagesize=A4,
        rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm)

    now = datetime.now().strftime("%B %d, %Y %H:%M")
    story = []

    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph("PQC TIMING SIDE-CHANNEL", title_style))
    story.append(Paragraph("COMPLIANCE ASSESSMENT REPORT", title_style))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(f"Target: {target}  |  Generated: {now}", sub_style))
    story.append(Paragraph("CONFIDENTIAL — FOR INTERNAL USE ONLY", conf_style))
    story.append(HRFlowable(width="100%", thickness=2, color=DARK_BLUE))
    story.append(Spacer(1, 0.4*cm))

    # Count findings
    findings = [(alg, op, d) for alg, ops in results.items()
                for op, d in ops.items() if "CRITICAL" in str(d.get("verdict","")) or "LEAK" in str(d.get("verdict",""))]
    total = sum(len(ops) for ops in results.values())

    # Summary box
    summary_text = "CRITICAL FINDINGS DETECTED" if findings else "ALL TESTS PASSED"
    summary_color = CRITICAL if findings else PASS_GREEN
    summary_table = Table([[Paragraph(
        f"{summary_text} — {len(findings)} critical out of {total} operations tested",
        ParagraphStyle("s", fontSize=12, textColor=white,
            fontName="Helvetica-Bold", alignment=TA_CENTER)
    )]], colWidths=[16.5*cm], style=TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), summary_color),
        ("TOPPADDING", (0,0), (-1,-1), 10),
        ("BOTTOMPADDING", (0,0), (-1,-1), 10),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 0.4*cm))

    story.append(Paragraph("1. Executive Summary", head_style))
    story.append(Paragraph(
        "This report presents automated timing side-channel analysis results using "
        "Test Vector Leakage Assessment (TVLA, ISO/IEC 17825) with 100,000 measurements "
        "per operation via CLOCK_MONOTONIC_RAW. Operations with |t| > 4.5 are CRITICAL.",
        body_style))

    story.append(Paragraph("2. Methodology", head_style))
    story.append(Paragraph(
        "Fixed-input timing measurements are compared against random-input measurements "
        "using Welch's t-test. Results confirmed on bare metal Ubuntu (GitHub Actions "
        "ubuntu-latest). Noise floor established via AES-128 control experiment (~11.7ns).",
        body_style))

    story.append(Paragraph("3. Results", head_style))

    # Results table
    rows = [["Algorithm", "Operation", "t-statistic", "Delta (ns)", "Verdict"]]
    for alg, ops in results.items():
        for op, d in ops.items():
            rows.append([alg, op, str(d.get("t","N/A")),
                        str(d.get("delta_ns","N/A")), d.get("verdict","N/A")])

    ts = TableStyle([
        ("BACKGROUND", (0,0), (-1,0), DARK_BLUE),
        ("TEXTCOLOR",  (0,0), (-1,0), white),
        ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",   (0,0), (-1,-1), 9),
        ("ALIGN",      (0,0), (-1,-1), "CENTER"),
        ("VALIGN",     (0,0), (-1,-1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [white, LIGHT_GREY]),
        ("FONTNAME",   (0,1), (-1,-1), "Helvetica"),
        ("GRID",       (0,0), (-1,-1), 0.5, MID_GREY),
        ("TOPPADDING", (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
    ])
    for i, row in enumerate(rows[1:], 1):
        ts.add("TEXTCOLOR", (4,i), (4,i), verdict_color(row[4]))
        ts.add("FONTNAME",  (4,i), (4,i), "Helvetica-Bold")

    story.append(Table(rows, colWidths=[4.5*cm,3*cm,3*cm,3*cm,3*cm], style=ts, repeatRows=1))
    story.append(Spacer(1, 0.4*cm))

    if findings:
        story.append(Paragraph("4. Critical Findings", head_style))
        for alg, op, d in findings:
            story.append(Paragraph(
                f"<b>{alg} — {op}</b>: t={d['t']}, delta={d['delta_ns']}ns. "
                f"Statistically significant timing signal detected.",
                body_style))

    story.append(Paragraph("5. Remediation", head_style))
    story.append(Paragraph(
        "<b>ML-KEM Encapsulation:</b> Use OQS_KEM_encaps_derand() with a pre-seeded DRBG "
        "to bypass OQS_randombytes(). The cryptographic core is clean — timing signal is RNG-induced.",
        body_style))
    story.append(Paragraph(
        "<b>FALCON Verification:</b> Timing leak originates in Golomb-Rice decompression "
        "(comp_decode() in codec.c). A constant-time unary decoding implementation is required. "
        "Padded variants do not fix this issue.",
        body_style))

    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="100%", thickness=1, color=MID_GREY))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        f"Generated by PQC Scanner v1.3.0 — https://pypi.org/project/pqc-scanner/ | "
        f"Collective Qubits | {now}", foot_style))

    doc.build(story)
    print(f"PDF report saved to {output_path}")

if __name__ == "__main__":
    sample = {
        "ML-KEM-512":  {"encaps": {"t": -8.37,   "delta_ns": -87.2,   "verdict": "CRITICAL"}, "decaps": {"t": 1.15, "delta_ns": 8.4, "verdict": "PASS"}},
        "ML-KEM-768":  {"encaps": {"t": -13.68,  "delta_ns": -298.4,  "verdict": "CRITICAL"}, "decaps": {"t": -0.09,"delta_ns":-0.8, "verdict": "PASS"}},
        "FALCON-512":  {"sign":   {"t": 1.55,    "delta_ns": 284.1,   "verdict": "PASS"},     "verify": {"t": -227.72,"delta_ns":-2760.0,"verdict": "CRITICAL"}},
        "FALCON-1024": {"sign":   {"t": 1.03,    "delta_ns": 112.3,   "verdict": "PASS"},     "verify": {"t": -303.05,"delta_ns":-6454.2,"verdict": "CRITICAL"}},
    }
    generate_pdf(sample, "/tmp/pqc_report_test.pdf")
