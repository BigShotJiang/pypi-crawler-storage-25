"""EU AI Act conformity automation.

Implements helpers for Article 51 (general-purpose AI model providers)
technical documentation. The output is a JSON evidence packet whose
shape mirrors Annex XI / XII of the Regulation, suitable for handing
to legal / external auditors verbatim.
"""
from .article_51 import build_evidence_packet

__all__ = ["build_evidence_packet"]
