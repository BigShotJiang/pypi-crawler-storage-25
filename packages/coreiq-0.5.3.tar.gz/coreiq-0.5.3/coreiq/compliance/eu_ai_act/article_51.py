"""EU AI Act Article 51 conformity evidence packet.

Article 51 requires GPAI model providers (and downstream deployers
above the systemic-risk threshold) to publish technical documentation
covering: (a) general description and purpose, (b) training data and
process, (c) tasks and modalities, (d) architecture, (e) energy use,
(f) test/eval results, (g) cybersecurity measures, (h) DPIA pointers.

CoreIQ doesn't train models — it observes and governs them. This module
auto-fills the deployer-side fields from configuration + audit data, and
leaves model-provider fields as ``"<from-provider>"`` placeholders that
must be sourced from the upstream model card.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_evidence_packet(
    *,
    deployment_id: str,
    tenant_id: str,
    models_in_use: list[str],
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return a JSON-serialisable Article 51 evidence packet.

    Auditor-facing fields:
    - generated_at: timestamp of this packet
    - deployer: { tenant, deployment, environment }
    - models: list of model identifiers in use during this window
    - governance:
        - policy_bundle_sha: identifier of the active signed policy
        - audit_chain: HMAC mode + sink count
        - residency: region pinning
    - placeholders: keys the deployer must source from the upstream
      provider's model card.
    """
    from coreiq.config import get_residency_config

    extra = extra or {}
    residency = get_residency_config()

    packet: dict[str, Any] = {
        "generated_at": _now_iso(),
        "regulation": "EU AI Act",
        "article": "Article 51 (GPAI model providers)",
        "deployer": {
            "tenant_id": tenant_id,
            "deployment_id": deployment_id,
            "environment": os.environ.get("COREIQ_ENVIRONMENT", "production"),
        },
        "models": list(models_in_use),
        "governance": {
            "policy_bundle_sha": os.environ.get("COREIQ_POLICY_BUNDLE_SHA", ""),
            "audit_chain": {
                "hmac_enabled": bool(os.environ.get("COREIQ_AUDIT_HMAC_KEY")),
                "fail_open": os.environ.get("COREIQ_AUDIT_FAIL_OPEN", "false") == "true",
            },
            "residency": {
                "default_region": residency["default_region"],
                "allowed_regions": residency["allowed_regions"],
                "block_cross_region": residency["block_cross_region_writes"],
            },
        },
        "placeholders_to_source_from_provider": [
            "training_data_summary",
            "model_architecture",
            "energy_consumption",
            "evaluation_metrics",
            "known_limitations",
            "intended_purpose",
        ],
    }
    packet.update(extra)
    return packet


def render_evidence_packet(packet: dict[str, Any], indent: int = 2) -> str:
    return json.dumps(packet, indent=indent, sort_keys=True)
