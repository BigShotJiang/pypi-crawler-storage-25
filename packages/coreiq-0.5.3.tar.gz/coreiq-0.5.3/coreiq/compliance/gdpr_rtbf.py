"""GDPR Article 17 — right to erasure (right to be forgotten).

Purges every persisted record tied to a ``tenant_id`` across all active
storage backends (audit chain, traces, cost, policy decisions, virtual
keys). Each purge appends an audit-chain entry recording WHO requested
the deletion and WHAT scope was erased — the audit entry itself is
non-erasable by design (regulators need proof the deletion happened).

Tables / collections covered:
- ``traces``, ``audit_log``, ``policy_decisions``, ``cost_records``
- ``security_events``, ``canary_deployments`` (only rows for this tenant)
- ``virtual_keys`` (revoked, not deleted, so historical audit links remain)

Usage::

    from coreiq.compliance.gdpr_rtbf import erase_tenant
    summary = erase_tenant("tenant-acme", requested_by="dpo@acme.com")
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger("coreiq.compliance.gdpr")


# Tables that hold tenant-scoped rows we should erase on RTBF.
_ERASE_TABLES = (
    "traces",
    "audit_log_pii",  # audit chain has a separate non-pii table (see note below)
    "policy_decisions",
    "cost_records",
    "security_events",
    "canary_deployments",
)


def erase_tenant(tenant_id: str, *, requested_by: str, dry_run: bool = False) -> dict[str, Any]:
    """Delete tenant-scoped rows across all backends.

    Returns a summary dict::

        {
            "tenant_id": "...",
            "requested_by": "...",
            "erased_at": ISO-8601,
            "tables": {"traces": 12345, ...},
            "audit_entry_id": "...",
            "dry_run": false,
        }
    """
    from coreiq.store.db import get_shared_connection

    erased_at = datetime.now(timezone.utc).isoformat()
    summary: dict[str, Any] = {
        "tenant_id": tenant_id,
        "requested_by": requested_by,
        "erased_at": erased_at,
        "tables": {},
        "dry_run": dry_run,
    }

    conn = get_shared_connection()

    for table in _ERASE_TABLES:
        try:
            count_row = conn.fetchone(f"SELECT COUNT(*) AS c FROM {table} WHERE tenant_id = ?", (tenant_id,))
            count = int(count_row[0] if count_row and not isinstance(count_row, dict) else (count_row.get("c") if count_row else 0))
        except Exception as exc:
            logger.debug("rtbf: count failed on %s: %s", table, exc)
            count = 0
        summary["tables"][table] = count

        if dry_run or count == 0:
            continue
        try:
            conn.execute(f"DELETE FROM {table} WHERE tenant_id = ?", (tenant_id,))
            conn.commit()
        except Exception as exc:
            logger.warning("rtbf: delete failed on %s for %s: %s", table, tenant_id, exc)

    # Revoke (not delete) virtual keys so the chain link survives.
    if not dry_run:
        try:
            conn.execute(
                "UPDATE virtual_keys SET active = 0, revoked_at = ? WHERE tenant_id = ?",
                (erased_at, tenant_id),
            )
            conn.commit()
        except Exception as exc:
            logger.debug("rtbf: virtual_keys revoke skipped: %s", exc)

    audit_id = _append_audit_entry(tenant_id, requested_by, summary)
    summary["audit_entry_id"] = audit_id
    return summary


def _append_audit_entry(tenant_id: str, requested_by: str, summary: dict[str, Any]) -> str:
    """Append a non-erasable audit-chain entry recording the deletion."""
    try:
        from coreiq.governance.chained_audit import append_event
    except Exception as exc:
        logger.debug("rtbf: audit append unavailable: %s", exc)
        return ""
    try:
        entry_id = append_event(
            event_type="gdpr.rtbf",
            actor=requested_by,
            tenant_id=tenant_id,
            payload={
                "tables": summary["tables"],
                "erased_at": summary["erased_at"],
                "dry_run": summary.get("dry_run", False),
            },
        )
        return str(entry_id) if entry_id else ""
    except Exception as exc:
        logger.warning("rtbf: audit append failed: %s", exc)
        return ""
