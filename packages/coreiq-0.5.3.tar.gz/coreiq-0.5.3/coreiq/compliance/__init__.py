"""Compliance automation modules.

Each submodule generates evidence artefacts that map directly to
specific regulatory clauses (EU AI Act, GDPR, etc.). Outputs are JSON
documents — visualization is deliberately delegated to OTel consumers.
"""
