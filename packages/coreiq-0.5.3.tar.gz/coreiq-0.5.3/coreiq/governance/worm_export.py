"""WORM (Write Once Read Many) audit export for compliance archival.

Database-only audit package storage - tracks audit chain evidence with full
queryability and integrity verification.

Usage::

    from coreiq.governance.worm_export import export_audit_package
    package = export_audit_package(
        from_ts="2026-01-01", to_ts="2026-03-31",
        include_metadata=["eu_ai_act_article_12", "soc2_cc7"],
    )
    print(package.package_id)  # use ID to query/download via API
"""
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class AuditPackage:
    package_id: str
    path: Optional[str]  # None for database-only storage
    manifest: Dict[str, Any]
    manifest_hash: str
    entry_count: int
    from_ts: Optional[str]
    to_ts: Optional[str]
    created_at: str = field(default_factory=_now)
    storage_type: str = "database"
    s3_bucket: Optional[str] = None
    s3_key: Optional[str] = None


class WORMExporter:
    """Exports audit chain + events into a signed evidence package."""

    def export(
        self,
        output_path: str = "./audit-exports/",  # kept for API compatibility but not used
        from_ts: Optional[str] = None,
        to_ts: Optional[str] = None,
        include_metadata: Optional[List[str]] = None,
        compress: bool = True,  # kept for API compatibility but not used
    ) -> AuditPackage:
        """Export audit evidence to a local directory.

        Args:
            output_path: Directory to write the package.
            from_ts: ISO timestamp lower bound.
            to_ts:   ISO timestamp upper bound.
            include_metadata: Compliance framework tags to embed in manifest.
            compress: Whether to gzip the JSONL files (default True).

        Returns:
            AuditPackage with path, manifest, and manifest_hash.
        """
        from ..store.db import get_shared_connection
        conn = get_shared_connection()

        package_id = str(uuid.uuid4())

        # Build WHERE clause
        where_clauses: list = []
        params: list = []
        if from_ts:
            where_clauses.append("ts >= ?")
            params.append(from_ts)
        if to_ts:
            where_clauses.append("ts <= ?")
            params.append(to_ts)

        # Build audit_chain WHERE clause
        chain_where_clauses: list = []
        chain_params: list = []
        if from_ts:
            chain_where_clauses.append("ts >= ?")
            chain_params.append(from_ts)
        if to_ts:
            chain_where_clauses.append("ts <= ?")
            chain_params.append(to_ts)
        chain_where = ("WHERE " + " AND ".join(chain_where_clauses)) if chain_where_clauses else ""

        chain_rows = conn.execute(
            f"SELECT entry_id, event_id, prev_hash, entry_hash, ts FROM audit_chain {chain_where} ORDER BY ts ASC",
            tuple(chain_params),
        ).fetchall()

        # Create a simple manifest hash from package metadata
        import hashlib as _hashlib
        manifest_data = f"{package_id}:{from_ts}:{to_ts}:{len(chain_rows)}:{include_metadata or []}:{_now()}"
        manifest_hash = _hashlib.sha256(manifest_data.encode()).hexdigest()

        # Persist package metadata to database (database-only storage)
        import json as _json
        conn.execute(
            """INSERT INTO audit_packages
               (id, tenant_id, from_ts, to_ts, entry_count, manifest_hash,
                compliance_frameworks, storage_type, s3_bucket, s3_key, output_path, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                package_id,
                "default",  # tenant_id - future: accept from request
                from_ts,
                to_ts,
                len(chain_rows),
                manifest_hash,
                _json.dumps(include_metadata or []),
                "database",  # storage_type - database only
                None,  # s3_bucket
                None,  # s3_key
                None,  # output_path - no files
                _now(),  # created_at
            ),
        )
        conn.commit()

        # Build manifest for response
        manifest: Dict[str, Any] = {
            "package_id": package_id,
            "created_at": _now(),
            "from_ts": from_ts,
            "to_ts": to_ts,
            "entry_count": len(chain_rows),
            "compliance_frameworks": include_metadata or [],
            "storage_type": "database",
            "generator": "coreiq.governance.worm_export",
        }

        return AuditPackage(
            package_id=package_id,
            path=None,  # no file path
            manifest=manifest,
            manifest_hash=manifest_hash,
            entry_count=len(chain_rows),
            from_ts=from_ts,
            to_ts=to_ts,
            storage_type="database",
            s3_bucket=None,
            s3_key=None,
        )


def export_audit_package(
    output_path: str = "./audit-exports/",
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    include_metadata: Optional[List[str]] = None,
    destination: Optional[str] = None,  # future: S3/GCS URI
    sign: bool = False,                 # future: GPG signing
) -> AuditPackage:
    """Export a WORM compliance evidence package.

    Args:
        output_path: Local output directory.
        from_ts: ISO start timestamp.
        to_ts: ISO end timestamp.
        include_metadata: Compliance framework tags (e.g. ["eu_ai_act_article_12"]).
        destination: Future: S3/GCS URI for off-site archival.
        sign: Future: GPG-sign the manifest.
    """
    return WORMExporter().export(
        output_path=output_path,
        from_ts=from_ts,
        to_ts=to_ts,
        include_metadata=include_metadata,
    )
