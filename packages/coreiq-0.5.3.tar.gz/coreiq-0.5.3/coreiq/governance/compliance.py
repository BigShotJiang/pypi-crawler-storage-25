"""Compliance checks — data retention, PII handling, consent verification,
and structured evidence package export for SOC 2 / EU AI Act / GDPR."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..exceptions import CoreIQError

logger = logging.getLogger("coreiq.governance.compliance")


class ComplianceFramework(str, Enum):
    """Supported compliance frameworks for evidence package generation."""
    SOC2_TYPE2 = "soc2_type2"
    EU_AI_ACT_ART12 = "eu_ai_act_art12"
    GDPR_ART30 = "gdpr_art30"


@dataclass
class ControlCoverage:
    """Coverage result for a single control."""
    control_id: str
    control_name: str
    framework: str
    status: str          # "satisfied" | "partial" | "gap" | "requires_review"
    items: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class CompliancePackage:
    """Result of export_compliance_package()."""
    package_id: str        # UUID hex — stable reference for DB / download
    output_path: str       # Local filesystem path (may be empty if S3-only)
    period_start: str
    period_end: str
    frameworks: List[str]
    controls: List[ControlCoverage]
    manifest_hash: str     # SHA-256 of the exported evidence JSON
    generated_at: str
    tenant_id: str = "default"
    s3_bucket: Optional[str] = None   # Set when stored on S3 WORM
    s3_key: Optional[str] = None      # Set when stored on S3 WORM
    storage_type: str = "filesystem"  # "filesystem" | "s3_worm"

    @property
    def coverage_report(self) -> Dict[str, str]:
        """Return {control_id: status} for quick review."""
        return {c.control_id: c.status for c in self.controls}

    @property
    def gap_count(self) -> int:
        return sum(1 for c in self.controls if c.status in ("gap", "requires_review"))


_FRAMEWORK_TEMPLATES = {
    ComplianceFramework.SOC2_TYPE2: [
        "coreiq.governance.evidence_templates.soc2_cc6",
        "coreiq.governance.evidence_templates.soc2_cc7",
    ],
    ComplianceFramework.EU_AI_ACT_ART12: [
        "coreiq.governance.evidence_templates.eu_ai_act_art12",
    ],
    ComplianceFramework.GDPR_ART30: [
        "coreiq.governance.evidence_templates.gdpr_art30",
    ],
}


def _upload_to_s3_worm(
    evidence_json: str,
    package_id: str,
    bucket: str,
    key_prefix: str = "compliance-packages/",
    retention_days: int = 2555,
    retention_mode: str = "COMPLIANCE",
    region: Optional[str] = None,
) -> Tuple[str, str]:
    """Upload evidence JSON to an S3 Object Lock bucket. Returns (bucket, key).

    Raises RuntimeError if boto3 is unavailable; raises any boto3 client error
    on upload failure so the caller can decide whether to fall back.
    """
    try:
        import boto3
    except ImportError as exc:
        raise RuntimeError(f"boto3 is required for S3 WORM storage (pip install boto3): {exc}") from exc

    now = datetime.now(timezone.utc)
    date_path = now.strftime("%Y/%m/%d")
    key = f"{key_prefix}{date_path}/{package_id}.json"
    retain_until = now + timedelta(days=retention_days)

    client_kwargs: Dict[str, Any] = {}
    if region:
        client_kwargs["region_name"] = region

    client = boto3.client("s3", **client_kwargs)
    client.put_object(
        Bucket=bucket,
        Key=key,
        Body=evidence_json.encode("utf-8"),
        ContentType="application/json",
        ObjectLockMode=retention_mode,
        ObjectLockRetainUntilDate=retain_until,
    )
    return bucket, key


def generate_s3_presigned_url(
    bucket: str,
    key: str,
    expires_in: int = 3600,
    region: Optional[str] = None,
) -> str:
    """Return a presigned GET URL for a compliance package stored in S3."""
    try:
        import boto3
    except ImportError as exc:
        raise RuntimeError(f"boto3 is required: {exc}") from exc

    client_kwargs: Dict[str, Any] = {}
    if region:
        client_kwargs["region_name"] = region

    client = boto3.client("s3", **client_kwargs)
    return client.generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=expires_in,
    )


def export_compliance_package(
    frameworks: List[ComplianceFramework],
    period_start: str,
    period_end: str,
    output_path: str = "./compliance-packages/",
    sign: bool = True,
    tenant_id: str = "default",
) -> CompliancePackage:
    """Export a structured compliance evidence package.

    Collects evidence from all registered templates for the requested frameworks,
    writes a signed JSON evidence file to the local filesystem, and — when
    ``COREIQ_COMPLIANCE_S3_BUCKET`` is set — also uploads it to S3 Object Lock
    (WORM) for tamper-evident, legally-defensible archival.

    Package metadata (id, frameworks, period, hash, storage location) is always
    persisted to the ``compliance_packages`` DB table regardless of storage backend.

    Environment variables (all optional):
        COREIQ_COMPLIANCE_S3_BUCKET       S3 bucket with Object Lock enabled
        COREIQ_COMPLIANCE_S3_KEY_PREFIX   Key prefix (default: "compliance-packages/")
        COREIQ_COMPLIANCE_S3_RETENTION_DAYS  Object Lock retention (default: 2555 ≈ 7 yr)
        COREIQ_COMPLIANCE_S3_RETENTION_MODE  COMPLIANCE or GOVERNANCE (default: COMPLIANCE)
        COREIQ_COMPLIANCE_S3_REGION       AWS region (falls back to AWS_REGION)

    Args:
        frameworks: List of ComplianceFramework values to collect evidence for.
        period_start: ISO-8601 start of the evidence period.
        period_end: ISO-8601 end of the evidence period.
        output_path: Directory to write the local evidence file to.
        sign: If True, include a SHA-256 manifest hash of the evidence file.
        tenant_id: Tenant context for the DB record.

    Returns:
        CompliancePackage with coverage report, storage location, and package_id.
    """
    import importlib
    from ..store.db import get_shared_connection

    conn = get_shared_connection()
    package_id = uuid.uuid4().hex

    # Validate output_path — must stay inside the compliance-packages directory
    _safe_base = Path(
        os.environ.get("COREIQ_COMPLIANCE_DIR", "./compliance-packages")
    ).resolve()
    out_dir = (_safe_base / Path(output_path).name) if output_path != str(_safe_base) + "/" else _safe_base
    try:
        out_dir.resolve().relative_to(_safe_base)
    except ValueError:
        raise ValueError(f"output_path must be inside the compliance-packages directory, got: {output_path!r}")
    out_dir.mkdir(parents=True, exist_ok=True)

    controls: List[ControlCoverage] = []
    all_evidence: Dict[str, Any] = {
        "package_id": package_id,
        "tenant_id": tenant_id,
        "period_start": period_start,
        "period_end": period_end,
        "frameworks": [f.value for f in frameworks],
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "controls": [],
    }

    # Embed the active policy bundle id + content hash so evidence is
    # tamper-evident against the exact policy version that was in force.
    try:
        from ..policy import get_policy_engine
        _bundle = get_policy_engine().get_bundle()
        if _bundle is not None:
            all_evidence["policy_bundle"] = {
                "bundle_id": _bundle.bundle_id,
                "bundle_sha256": _bundle.canonical_hash(),
                "tenant_id": _bundle.tenant_id,
                "version": _bundle.version,
                "mode": _bundle.mode,
                "residency": _bundle.residency,
            }
    except Exception as _exc:
        logger.debug("compliance: policy bundle metadata embed skipped: %s", _exc)

    for fw in frameworks:
        templates = _FRAMEWORK_TEMPLATES.get(fw, [])
        for mod_path in templates:
            try:
                mod = importlib.import_module(mod_path)
                evidence = mod.collect(conn, period_start, period_end)

                # Determine overall status from items
                statuses = [item.get("status", "unknown") for item in evidence.get("items", [])]
                if all(s == "satisfied" for s in statuses):
                    overall = "satisfied"
                elif any(s == "gap" for s in statuses):
                    overall = "gap"
                elif any(s in ("requires_review", "requires_configuration") for s in statuses):
                    overall = "requires_review"
                else:
                    overall = "partial"

                coverage = ControlCoverage(
                    control_id=evidence.get("control_id", mod_path),
                    control_name=evidence.get("control_name", ""),
                    framework=fw.value,
                    status=overall,
                    items=evidence.get("items", []),
                )
                controls.append(coverage)
                all_evidence["controls"].append(evidence)
            except Exception as exc:
                logger.warning("Failed to collect evidence from %s: %s", mod_path, exc)
                controls.append(ControlCoverage(
                    control_id=mod_path,
                    control_name=mod_path,
                    framework=fw.value,
                    status="gap",
                    items=[{"error": str(exc)}],
                ))

    # Serialize evidence
    ts_slug = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    fw_slug = "_".join(f.value for f in frameworks)
    filename = f"compliance_{fw_slug}_{ts_slug}_{package_id[:8]}.json"
    evidence_path = out_dir / filename

    evidence_json = json.dumps(all_evidence, indent=2, default=str)

    manifest_hash = hashlib.sha256(evidence_json.encode()).hexdigest() if sign else ""

    # ── Local filesystem write ────────────────────────────────────────────────
    evidence_path.write_text(evidence_json, encoding="utf-8")
    if sign:
        evidence_path.with_suffix(".sha256").write_text(
            f"{manifest_hash}  {filename}\n", encoding="utf-8"
        )

    # ── S3 WORM upload (when bucket is configured) ────────────────────────────
    s3_bucket: Optional[str] = os.environ.get("COREIQ_COMPLIANCE_S3_BUCKET") or None
    s3_key: Optional[str] = None
    storage_type = "filesystem"

    if s3_bucket:
        key_prefix = os.environ.get("COREIQ_COMPLIANCE_S3_KEY_PREFIX", "compliance-packages/")
        retention_days = int(os.environ.get("COREIQ_COMPLIANCE_S3_RETENTION_DAYS", "2555"))
        retention_mode = os.environ.get("COREIQ_COMPLIANCE_S3_RETENTION_MODE", "COMPLIANCE")
        region = os.environ.get("COREIQ_COMPLIANCE_S3_REGION") or os.environ.get("AWS_REGION")
        try:
            _, s3_key = _upload_to_s3_worm(
                evidence_json, package_id, s3_bucket,
                key_prefix=key_prefix,
                retention_days=retention_days,
                retention_mode=retention_mode,
                region=region,
            )
            storage_type = "s3_worm"
            logger.info(
                "Compliance package uploaded to S3 WORM: s3://%s/%s", s3_bucket, s3_key
            )
        except Exception as exc:
            logger.error(
                "S3 WORM upload failed for package %s, keeping filesystem copy: %s",
                package_id, exc,
            )
            s3_bucket = None  # don't record stale bucket reference in DB

    gap_count = sum(1 for c in controls if c.status in ("gap", "requires_review"))

    # ── Persist metadata to DB ────────────────────────────────────────────────
    try:
        conn.execute(
            """INSERT INTO compliance_packages
               (id, tenant_id, frameworks, period_start, period_end, manifest_hash,
                storage_type, s3_bucket, s3_key, output_path, gap_count, control_count, generated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                package_id, tenant_id,
                json.dumps([f.value for f in frameworks]),
                period_start, period_end, manifest_hash,
                storage_type, s3_bucket, s3_key,
                str(evidence_path),
                gap_count, len(controls),
                all_evidence["generated_at"],
            ),
        )
        conn.commit()
    except Exception as exc:
        logger.warning("Failed to persist compliance package metadata to DB: %s", exc)

    logger.info(
        "Compliance package generated: %s (%d controls, %d gaps, storage=%s)",
        evidence_path, len(controls), gap_count, storage_type,
    )

    return CompliancePackage(
        package_id=package_id,
        output_path=str(evidence_path),
        period_start=period_start,
        period_end=period_end,
        frameworks=[f.value for f in frameworks],
        controls=controls,
        manifest_hash=manifest_hash,
        generated_at=all_evidence["generated_at"],
        tenant_id=tenant_id,
        s3_bucket=s3_bucket,
        s3_key=s3_key,
        storage_type=storage_type,
    )


@dataclass
class RetentionPolicy:
    """Define how long different data types are kept."""
    traces_days: int = 90
    feedback_days: int = 365
    events_days: int = 30
    cache_events_days: int = 30


@dataclass
class ComplianceViolation(CoreIQError):
    check: str
    detail: str

    def __str__(self) -> str:
        return f"Compliance violation [{self.check}]: {self.detail}"


def check_retention(ts: str, max_age_days: int) -> bool:
    """Return True if record is within retention window."""
    try:
        record_time = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
        return record_time >= cutoff
    except (ValueError, AttributeError):
        return True  # Can't parse — assume compliant


def purge_expired_records(conn, retention: Optional[RetentionPolicy] = None) -> dict:
    """Delete records outside their retention window. Returns counts per table."""
    policy = retention or RetentionPolicy()
    now = datetime.now(timezone.utc)
    counts: dict[str, int] = {}

    table_map = {
        "traces":        policy.traces_days,
        "feedback":      policy.feedback_days,
        "events":        policy.events_days,
        "cache_events":  policy.cache_events_days,
    }
    for table, days in table_map.items():
        cutoff = (now - timedelta(days=days)).isoformat()
        cur = conn.execute(f"DELETE FROM {table} WHERE ts < ?", (cutoff,))
        counts[table] = cur.rowcount

    conn.commit()
    return counts


@dataclass
class ConsentRecord:
    subject_id: str
    purpose: str
    granted: bool
    granted_at: Optional[str] = None
    expires_at: Optional[str] = None

    def is_valid(self) -> bool:
        if not self.granted:
            return False
        if self.expires_at:
            try:
                exp = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
                return datetime.now(timezone.utc) < exp
            except ValueError:
                return False
        return True
