"""Data Residency & Cross-Border Transfer Controls.

Enforces per-tenant region constraints — blocks writes destined for
regions outside the tenant's allowed set, and audits all transfers.

Usage::

    from coreiq.governance import ResidencyPolicy, DataResidencyAuditor

    policy = ResidencyPolicy(
        tenant_id="acme",
        home_region="eu-west-1",
        allowed_regions=["eu-west-1", "eu-central-1"],
        block_cross_region_writes=True,
    )

    # Raises CrossRegionWriteBlocked if region not in allowed set
    policy.check_write(region="us-east-1")

    # Configure globally from config
    from coreiq.governance.data_residency import configure_residency
    configure_residency()  # reads from TOML / env
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger("coreiq.governance.data_residency")


class CrossRegionWriteBlocked(Exception):
    """Raised when a write would violate data residency policy."""

    def __init__(self, tenant_id: str, target_region: str, allowed: List[str]):
        self.tenant_id = tenant_id
        self.target_region = target_region
        self.allowed = allowed
        super().__init__(
            f"Cross-region write blocked for tenant '{tenant_id}': "
            f"target region '{target_region}' not in allowed set {allowed}"
        )


@dataclass
class ResidencyPolicy:
    """Residency policy for a single tenant.

    Args:
        tenant_id: Tenant this policy applies to.
        home_region: The tenant's primary data-at-rest region.
        allowed_regions: Regions where writes are permitted (includes home_region).
        block_cross_region_writes: If True, writes to non-allowed regions raise an exception.
    """

    tenant_id: str
    home_region: str = "default"
    allowed_regions: List[str] = field(default_factory=list)
    block_cross_region_writes: bool = False

    def __post_init__(self):
        # Ensure home_region is always in the allowed set
        if self.home_region and self.home_region not in self.allowed_regions:
            self.allowed_regions = [self.home_region] + list(self.allowed_regions)

    def check_write(self, region: Optional[str] = None) -> None:
        """Check whether a write to the given region is permitted.

        Args:
            region: Target write region. If None, defaults to home_region (always allowed).

        Raises:
            CrossRegionWriteBlocked: If the write would violate this policy.
        """
        if not region or region == self.home_region:
            return  # home-region writes always allowed
        if not self.block_cross_region_writes:
            return  # enforcement disabled
        if self.allowed_regions and region not in self.allowed_regions:
            raise CrossRegionWriteBlocked(
                tenant_id=self.tenant_id,
                target_region=region,
                allowed=self.allowed_regions,
            )

    def is_allowed(self, region: str) -> bool:
        """Return True if the given region is permitted for this tenant."""
        if not self.allowed_regions:
            return True  # no restrictions
        return region in self.allowed_regions


class DataResidencyAuditor:
    """Audits and enforces data residency across all tenant writes.

    Maintains a registry of per-tenant ``ResidencyPolicy`` objects and
    provides a single ``check_write()`` entrypoint used by the storage layer.

    Thread-safe.
    """

    def __init__(self, default_policy: Optional[ResidencyPolicy] = None):
        self._policies: Dict[str, ResidencyPolicy] = {}
        self._default_policy = default_policy
        self._lock = threading.Lock()

    def register_policy(self, policy: ResidencyPolicy) -> None:
        """Register or update a policy for a tenant."""
        with self._lock:
            self._policies[policy.tenant_id] = policy
            logger.debug("Registered residency policy for tenant %s: home=%s, allowed=%s",
                         policy.tenant_id, policy.home_region, policy.allowed_regions)

    def get_policy(self, tenant_id: str) -> Optional[ResidencyPolicy]:
        """Return the residency policy for a tenant, or the default policy."""
        with self._lock:
            return self._policies.get(tenant_id) or self._default_policy

    def check_write(self, tenant_id: str, region: Optional[str] = None) -> None:
        """Enforce residency policy for a tenant write.

        Args:
            tenant_id: The tenant performing the write.
            region: Target region. If None, enforcement is skipped.

        Raises:
            CrossRegionWriteBlocked: If the write violates the tenant's policy.
        """
        if not region or not tenant_id:
            return
        policy = self.get_policy(tenant_id)
        if policy is None:
            return
        policy.check_write(region)

    def audit_transfer(
        self,
        tenant_id: str,
        source_region: str,
        target_region: str,
        data_type: str = "trace",
        outcome: str = "allowed",
    ) -> None:
        """Record a cross-border data transfer event to the audit log."""
        try:
            from ..store.writer import get_writer
            get_writer().insert_event(
                message=f"Data transfer: {source_region} → {target_region}",
                level="info" if outcome == "allowed" else "warning",
                source="data_residency",
                metadata={
                    "tenant_id": tenant_id,
                    "source_region": source_region,
                    "target_region": target_region,
                    "data_type": data_type,
                    "outcome": outcome,
                },
            )
        except Exception as exc:
            logger.debug("Failed to audit transfer: %s", exc)


# ---------------------------------------------------------------------------
# Module-level singleton — configured at startup via configure_residency()
# ---------------------------------------------------------------------------

_auditor: Optional[DataResidencyAuditor] = None
_auditor_lock = threading.Lock()


def get_auditor() -> DataResidencyAuditor:
    """Return the module-level DataResidencyAuditor (created on first call)."""
    global _auditor
    if _auditor is None:
        with _auditor_lock:
            if _auditor is None:
                _auditor = DataResidencyAuditor()
    return _auditor


def configure_residency() -> DataResidencyAuditor:
    """Configure the global auditor from TOML / env config.

    Call this once at application startup. Reads from::

        [residency]
        enabled = true
        default_region = "eu-west-1"
        allowed_regions = ["eu-west-1", "eu-central-1"]
        block_cross_region_writes = true

    Returns the configured auditor.
    """
    from ..config import get_residency_config
    cfg = get_residency_config()
    if not cfg.get("enabled", False):
        return get_auditor()

    default_region = cfg.get("default_region", "default")
    allowed = cfg.get("allowed_regions", [default_region])
    block = cfg.get("block_cross_region_writes", False)

    default_policy = ResidencyPolicy(
        tenant_id="default",
        home_region=default_region,
        allowed_regions=allowed,
        block_cross_region_writes=block,
    )
    auditor = get_auditor()
    auditor._default_policy = default_policy
    logger.info(
        "Data residency configured: home=%s, allowed=%s, block_cross_region=%s",
        default_region, allowed, block,
    )
    return auditor
