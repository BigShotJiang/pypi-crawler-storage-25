"""Bias & Fairness Monitor — detect bias in model outputs across demographics.

Analyzes outputs for differential treatment based on demographic indicators
and generates fairness reports.
"""
from __future__ import annotations
import re
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List
logger = logging.getLogger(__name__)

DEMOGRAPHIC_INDICATORS = {
    "gender": [
        (r"\b(?:he|him|his|man|male|boy|father|husband|sir|mr)\b", "male"),
        (r"\b(?:she|her|hers|woman|female|girl|mother|wife|madam|mrs|ms)\b", "female"),
    ],
    "age": [
        (r"\b(?:young|youth|millennial|gen[- ]?z|teenager|junior)\b", "young"),
        (r"\b(?:old|elderly|senior|retired|aging|boomer)\b", "old"),
    ],
}

@dataclass
class BiasIndicator:
    dimension: str
    group: str
    count: int
    sentiment_score: float  # -1 to 1
    context_snippets: List[str] = field(default_factory=list)
    def to_dict(self) -> Dict[str, Any]:
        return {"dimension": self.dimension, "group": self.group, "count": self.count,
                "sentiment_score": round(self.sentiment_score, 3), "context_snippets": self.context_snippets[:3]}

POSITIVE_WORDS = {"good", "great", "excellent", "qualified", "skilled", "capable", "strong", "ideal", "perfect", "best", "recommended"}
NEGATIVE_WORDS = {"bad", "poor", "unqualified", "weak", "incapable", "unsuitable", "risky", "problem", "concern", "avoid", "unlikely"}

@dataclass
class BiasReport:
    total_outputs_analyzed: int
    bias_detected: bool
    indicators: List[BiasIndicator] = field(default_factory=list)
    fairness_score: float = 1.0  # 1.0 = perfectly fair
    recommendations: List[str] = field(default_factory=list)
    def to_dict(self) -> Dict[str, Any]:
        return {"total_outputs_analyzed": self.total_outputs_analyzed, "bias_detected": self.bias_detected,
                "indicators": [i.to_dict() for i in self.indicators],
                "fairness_score": round(self.fairness_score, 3), "recommendations": self.recommendations}

class BiasMonitor:
    def __init__(self):
        self._compiled = {}
        for dim, patterns in DEMOGRAPHIC_INDICATORS.items():
            self._compiled[dim] = [(re.compile(p, re.IGNORECASE), group) for p, group in patterns]

    def _sentiment_around(self, text: str, match_start: int, window: int = 50) -> float:
        start = max(0, match_start - window)
        end = min(len(text), match_start + window)
        context = text[start:end].lower()
        words = set(context.split())
        pos = len(words & POSITIVE_WORDS)
        neg = len(words & NEGATIVE_WORDS)
        total = pos + neg
        if total == 0:
            return 0.0
        return (pos - neg) / total

    def analyze(self, texts: List[str]) -> BiasReport:
        group_data: Dict[str, Dict[str, Dict]] = {}
        for text in texts:
            for dim, patterns in self._compiled.items():
                for compiled, group in patterns:
                    for m in compiled.finditer(text):
                        key = f"{dim}:{group}"
                        if key not in group_data:
                            group_data[key] = {"dim": dim, "group": group, "count": 0, "sentiments": [], "snippets": []}
                        group_data[key]["count"] += 1
                        sent = self._sentiment_around(text, m.start())
                        group_data[key]["sentiments"].append(sent)
                        snippet = text[max(0, m.start()-20):m.end()+20].strip()
                        if len(group_data[key]["snippets"]) < 3:
                            group_data[key]["snippets"].append(snippet)

        indicators = []
        for data in group_data.values():
            sents = data["sentiments"]
            avg_sent = sum(sents) / len(sents) if sents else 0
            indicators.append(BiasIndicator(dimension=data["dim"], group=data["group"],
                count=data["count"], sentiment_score=avg_sent, context_snippets=data["snippets"]))

        bias_detected = False
        fairness = 1.0
        recommendations = []
        # Check for differential sentiment within a dimension
        dims = {}
        for ind in indicators:
            dims.setdefault(ind.dimension, []).append(ind)
        for dim, inds in dims.items():
            if len(inds) >= 2:
                sents = [i.sentiment_score for i in inds]
                spread = max(sents) - min(sents)
                if spread > 0.3:
                    bias_detected = True
                    fairness = min(fairness, 1.0 - spread)
                    groups = [f"{i.group}({i.sentiment_score:+.2f})" for i in inds]
                    recommendations.append(f"Potential {dim} bias detected: {', '.join(groups)}")

        return BiasReport(total_outputs_analyzed=len(texts), bias_detected=bias_detected,
            indicators=indicators, fairness_score=max(0, fairness), recommendations=recommendations)
