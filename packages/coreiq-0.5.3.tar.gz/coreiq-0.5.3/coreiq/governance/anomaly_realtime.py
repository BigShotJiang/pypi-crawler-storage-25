"""Per-key runtime anomaly detector for the proxy pipeline.

Tracks the last N requests per virtual key (token volume, cost,
finish_reason distribution) and flags any new request whose value is
3+ sigmas off the rolling baseline. Designed to be called from the
proxy pipeline's stage 7 (observe) so a flag fires within ~60s of an
anomaly starting.

Storage is in-process — for multi-replica HA the per-key baselines
should ideally live in Redis (deferred to a follow-up). For
single-replica deployments the in-process state is sufficient and
adds zero latency.
"""
from __future__ import annotations

import logging
import threading
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

from .stats import rolling_zscore

logger = logging.getLogger("coreiq.governance.anomaly_realtime")


@dataclass
class _KeyState:
    """Rolling per-key history of recent request metrics."""

    token_history: deque = field(default_factory=lambda: deque(maxlen=200))
    cost_history: deque = field(default_factory=lambda: deque(maxlen=200))


@dataclass
class AnomalyEvent:
    """Returned when an anomaly is detected for a request."""

    key_id: str
    metric: str
    value: float
    z_score: float
    severity: str  # "warning" | "critical"


class RuntimeAnomalyDetector:
    """Per-key rolling-window anomaly detector.

    Thread-safe. The detector keeps a deque of recent observations per
    virtual key id (default window = 200 requests, max ~200 keys
    actively tracked at any time — older keys are pruned on first
    overflow).

    Usage from the proxy pipeline::

        detector = RuntimeAnomalyDetector()

        # In stage 7 (observe), after the request finishes:
        events = detector.observe(
            key_id=ctx.virtual_key_id,
            input_tokens=usage["prompt_tokens"],
            output_tokens=usage["completion_tokens"],
            cost_usd=cost.total_cost,
        )
        for event in events:
            logger.warning("Anomaly: %s", event)
            # ... emit audit + webhook ...
    """

    def __init__(
        self,
        *,
        warning_threshold_sigma: float = 3.0,
        critical_threshold_sigma: float = 5.0,
        max_keys_tracked: int = 5000,
    ) -> None:
        self._warning = warning_threshold_sigma
        self._critical = critical_threshold_sigma
        self._max_keys = max_keys_tracked
        self._states: dict[str, _KeyState] = {}
        self._lock = threading.Lock()

    def observe(
        self,
        *,
        key_id: Optional[str],
        input_tokens: int = 0,
        output_tokens: int = 0,
        cost_usd: float = 0.0,
    ) -> list[AnomalyEvent]:
        """Record one request and return any anomalies it triggered.

        Returns a list (possibly empty) of :class:`AnomalyEvent`. The
        list is empty in the steady state — anomalies are rare events.
        """
        if not key_id:
            return []

        total_tokens = float(input_tokens + output_tokens)
        with self._lock:
            state = self._states.get(key_id)
            if state is None:
                # Bounded LRU: drop oldest key when at capacity.
                if len(self._states) >= self._max_keys:
                    self._states.pop(next(iter(self._states)))
                state = _KeyState()
                self._states[key_id] = state

            # Append latest BEFORE measuring so the deque
            # already includes this observation; rolling_zscore
            # uses the previous window only.
            state.token_history.append(total_tokens)
            state.cost_history.append(float(cost_usd))

            events: list[AnomalyEvent] = []

            # Need at least a few samples before we can claim
            # a baseline.
            if len(state.token_history) < 30:
                return events

            token_z = rolling_zscore(list(state.token_history), window=100)
            if abs(token_z) >= self._critical:
                events.append(
                    AnomalyEvent(
                        key_id=key_id,
                        metric="total_tokens",
                        value=total_tokens,
                        z_score=token_z,
                        severity="critical",
                    )
                )
            elif abs(token_z) >= self._warning:
                events.append(
                    AnomalyEvent(
                        key_id=key_id,
                        metric="total_tokens",
                        value=total_tokens,
                        z_score=token_z,
                        severity="warning",
                    )
                )

            cost_z = rolling_zscore(list(state.cost_history), window=100)
            if abs(cost_z) >= self._critical:
                events.append(
                    AnomalyEvent(
                        key_id=key_id,
                        metric="cost_usd",
                        value=float(cost_usd),
                        z_score=cost_z,
                        severity="critical",
                    )
                )
            elif abs(cost_z) >= self._warning:
                events.append(
                    AnomalyEvent(
                        key_id=key_id,
                        metric="cost_usd",
                        value=float(cost_usd),
                        z_score=cost_z,
                        severity="warning",
                    )
                )

            return events

    def reset(self, key_id: Optional[str] = None) -> None:
        """Drop the rolling state for one key (or all if key_id is None)."""
        with self._lock:
            if key_id is None:
                self._states.clear()
            else:
                self._states.pop(key_id, None)


# Module-level singleton — most callers use this rather than constructing
# their own. The proxy pipeline imports `_detector` and calls observe().
_detector: Optional[RuntimeAnomalyDetector] = None
_detector_lock = threading.Lock()


def get_anomaly_detector() -> RuntimeAnomalyDetector:
    global _detector
    if _detector is None:
        with _detector_lock:
            if _detector is None:
                _detector = RuntimeAnomalyDetector()
    return _detector
