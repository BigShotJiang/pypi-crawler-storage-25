"""Cryptographically immutable audit trail with SHA-256 HMAC hash-chaining.

Each entry in the audit_chain table contains:
- entry_id: UUID
- event_id: reference to the events table entry
- prev_hash: SHA-256 HMAC of the previous entry (genesis entry uses zeros)
- entry_hash: SHA-256 HMAC of (entry_id + event_id + prev_hash + ts)
- ts: ISO timestamp

This makes retrospective tampering cryptographically detectable.

Failure semantics
-----------------

Audit writes are SYNCHRONOUS and FAIL-LOUD by default. Setting
``COREIQ_AUDIT_FAIL_OPEN=true`` reverts to the legacy fail-silent
behaviour where a sink failure logs a warning and the request
continues. The default (fail-loud) is correct for any deployment that
treats audit as a regulatory requirement (SOC 2, ISO 27001, HIPAA,
17a-4).

The HMAC signing key MUST be set via ``COREIQ_AUDIT_HMAC_KEY`` —
there is no longer a hardcoded default. ChainedAuditLogger raises
``RuntimeError`` at construction time when the key is missing, so
a misconfigured deployment fails at startup rather than silently
producing audit entries signed with a publicly-known key.
"""
import hashlib
import hmac
import logging
import os
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from ..exceptions import ConfigError

try:
    # Wave 2B P1: per-tenant HKDF subkey derivation. ``cryptography`` is
    # already a top-level dependency (pyproject.toml).
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    _HKDF_AVAILABLE = True
except Exception:  # pragma: no cover — should never happen in shipped builds
    _HKDF_AVAILABLE = False

logger = logging.getLogger("coreiq.governance.chained_audit")

# Wave 2B P1: HKDF salt — versioned so a future v2 derivation scheme can
# coexist with v1 entries during a rotation. Public-knowledge by design;
# salts in HKDF do not need to be secret.
_AUDIT_HKDF_SALT = b"coreiq-audit-v1"


_GENESIS_HASH = "0" * 64  # sentinel for the first entry


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _get_hmac_key() -> bytes:
    """Return the HMAC signing key from env.

    Resolution order:
      1. ``COREIQ_AUDIT_HMAC_KEY`` set → use it verbatim.
      2. ``COREIQ_AUDIT_FAIL_OPEN=true`` → use a per-process marker
         key, log a loud warning. Deprecated alias for dev mode.
      3. ``COREIQ_ENV`` is unset or ``development`` → use a per-process
         marker key so ``pip install coreiq && coreiq`` works out of
         the box. This is a dev-mode fallback ONLY — every audit entry
         still carries a consistent HMAC within the process, so the
         chain is internally verifiable, but the key is thrown away on
         restart. A loud warning is logged on first use.
      4. ``COREIQ_ENV=production`` → raise ``RuntimeError``. The
         previous hardcoded fallback (``b"coreiq-audit-chain-v1"``) was
         a publicly-disclosed key that gave zero real cryptographic
         protection. Refusing to start forces production deployments
         to configure a real secret.
    """
    raw = os.environ.get("COREIQ_AUDIT_HMAC_KEY", "")
    if raw:
        return raw.encode()

    fail_open_explicit = (
        os.environ.get("COREIQ_AUDIT_FAIL_OPEN", "").lower() in ("1", "true", "yes")
    )
    env = os.environ.get("COREIQ_ENV", "development").lower()
    is_dev = env != "production"

    if fail_open_explicit or is_dev:
        logger.warning(
            "COREIQ_AUDIT_HMAC_KEY is unset — using an ephemeral dev key. "
            "Audit chain entries are internally verifiable within this "
            "process but not persisted across restarts. "
            "Set COREIQ_AUDIT_HMAC_KEY=... and COREIQ_ENV=production for "
            "tamper-evident audit in production."
        )
        return f"coreiq-audit-dev-{uuid.uuid4()}".encode()

    raise ConfigError(
        "COREIQ_AUDIT_HMAC_KEY is required",
        hint="Generate with: python -c \"import secrets; print(secrets.token_hex(32))\". "
             "In dev, set COREIQ_AUDIT_FAIL_OPEN=true to skip this requirement."
    )


def _is_dev_ephemeral_key() -> bool:
    """Return True when ``_get_hmac_key()`` would mint a fresh ephemeral key.

    Used by ``verify_audit_chain()`` to short-circuit verification with a
    clear ``dev_mode=True`` signal instead of comparing rows against a
    brand-new random key (which always returns ``valid=False`` and emits
    a confusing "possible tampering" diagnostic). Wave 3A fix.
    """
    if os.environ.get("COREIQ_AUDIT_HMAC_KEY", ""):
        return False
    fail_open_explicit = (
        os.environ.get("COREIQ_AUDIT_FAIL_OPEN", "").lower() in ("1", "true", "yes")
    )
    env = os.environ.get("COREIQ_ENV", "development").lower()
    is_dev = env != "production"
    return fail_open_explicit or is_dev


def _compute_hmac(data: str, key: bytes) -> str:
    """Compute SHA-256 HMAC of data. Returns hex digest."""
    return hmac.new(key, data.encode(), hashlib.sha256).hexdigest()


def _derive_tenant_key(master_key: bytes, tenant_id: str) -> bytes:
    """Derive a 32-byte per-tenant HMAC subkey from the master key.

    Uses ``HKDF-SHA256`` with a versioned static salt and the tenant_id
    as the ``info`` parameter — the standard recipe for domain-separated
    subkey derivation (RFC 5869). Result: every tenant gets a
    cryptographically distinct signing key, so a row forged with tenant
    A's master derivation cannot be replayed against tenant B and vice
    versa, even though both derive from the same master HMAC key.

    Tenant-less rows (legacy / cross-tenant ops) keep using the master
    key directly; this function is only invoked when a tenant_id is
    present on the row.
    """
    if not _HKDF_AVAILABLE:
        # Fail-loud: cryptography is a required dep. If somehow missing,
        # fall back to a labeled HMAC so we still get domain separation
        # rather than silently mixing tenants on the same key.
        return hmac.new(
            master_key,
            _AUDIT_HKDF_SALT + b"|" + tenant_id.encode("utf-8"),
            hashlib.sha256,
        ).digest()
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=_AUDIT_HKDF_SALT,
        info=tenant_id.encode("utf-8"),
    )
    return hkdf.derive(master_key)


def _key_fingerprint(key: bytes) -> str:
    """Short, non-reversible identifier for an HMAC key.

    Used to tag audit_chain rows so verification can pick the right key
    when keys have been rotated (Wave 1A P0). Eight hex chars of a
    SHA-256 digest is enough to disambiguate any practical number of
    historical keys without leaking material.
    """
    return hashlib.sha256(key).hexdigest()[:8]


def _compute_entry_hash(entry_id: str, event_id: str, prev_hash: str, ts: str, key: bytes) -> str:
    payload = f"{entry_id}:{event_id}:{prev_hash}:{ts}"
    return _compute_hmac(payload, key)


@dataclass
class ChainVerifyResult:
    valid: bool
    entry_count: int
    broken_at: Optional[str] = None  # entry_id where chain breaks
    error: Optional[str] = None
    # Wave 1A P0: surface anchor diagnostics for windowed verifications.
    anchored: bool = True
    anchor_note: Optional[str] = None
    # Wave 3A: explicit dev-mode signal. When True the verification was
    # short-circuited because no persistent HMAC key is configured —
    # comparing entries against a freshly-minted ephemeral key would
    # otherwise return ``valid=False`` with a confusing "tamper" message.
    dev_mode: bool = False
    note: Optional[str] = None


class ChainedAuditLogger:
    """Wraps AuditLogger to add SHA-256 HMAC hash-chaining.

    Usage::

        logger = ChainedAuditLogger()
        logger.log("user.login", principal="alice@example.com")

    All existing AuditLogger.log() kwargs are supported unchanged.

    A configured :class:`coreiq.governance.sinks.AuditSinkRouter` can
    be passed to mirror every audit event to one or more SIEM
    destinations. Sink failures are propagated as
    :class:`coreiq.governance.sinks.SinkFailure` (caller can decide to
    return a 503), unless the router was configured with
    ``block_on_failure=False`` per sink.

    Constructor raises ``RuntimeError`` when ``COREIQ_AUDIT_HMAC_KEY``
    is unset and fail-open mode is not enabled — there is no longer
    a hardcoded default key.
    """

    def __init__(self, source: str = "audit", *, sink_router: Any = None) -> None:
        from .audit import AuditLogger
        self._inner = AuditLogger(source=source)
        self._lock = threading.Lock()
        self._key = _get_hmac_key()
        # Default to the env-configured process-wide router so audit events
        # actually fan out to SIEMs without manual wiring.
        if sink_router is None:
            try:
                from .sinks.base import get_sink_router
                sink_router = get_sink_router()
            except Exception as exc:
                logger.warning("Audit sink router unavailable: %s", exc)
                sink_router = None
        self._sink_router = sink_router
        # Fail-open is opt-in for the chain too — same env knob as the key.
        self._fail_open = (
            os.environ.get("COREIQ_AUDIT_FAIL_OPEN", "").lower() in ("1", "true", "yes")
        )

    def _get_conn(self) -> Any:
        from ..store.db import get_shared_connection
        return get_shared_connection()

    def _get_last_hash(self, conn: Any) -> str:
        row = conn.execute(
            "SELECT entry_hash FROM audit_chain ORDER BY ts DESC LIMIT 1"
        ).fetchone()
        return row["entry_hash"] if row else _GENESIS_HASH

    def log(
        self,
        action: str,
        *,
        principal: Optional[str] = None,
        resource: Optional[str] = None,
        outcome: str = "success",
        metadata: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
    ) -> str:
        # Write to events table first (existing behaviour — unchanged)
        event_id = self._inner.log(
            action,
            principal=principal,
            resource=resource,
            outcome=outcome,
            metadata=metadata,
            trace_id=trace_id,
        )
        # Wave 2B P1: resolve tenant_id from explicit kwarg or metadata.
        # If a tenant_id is present, derive a per-tenant subkey via HKDF
        # so cross-tenant forgery is cryptographically infeasible.
        if tenant_id is None and metadata:
            tid = metadata.get("tenant_id")
            if isinstance(tid, str) and tid:
                tenant_id = tid
        if tenant_id:
            signing_key = _derive_tenant_key(self._key, tenant_id)
        else:
            signing_key = self._key
        # Append to hash chain — fail-loud by default. Setting
        # COREIQ_AUDIT_FAIL_OPEN=true reverts to the legacy
        # log-and-continue behavior for non-production environments.
        try:
            conn = self._get_conn()
            with self._lock:
                prev_hash = self._get_last_hash(conn)
                entry_id = str(uuid.uuid4())
                ts = _now()
                entry_hash = _compute_entry_hash(entry_id, event_id, prev_hash, ts, signing_key)
                # Wave 2B P1: fingerprint identifies the *derived* key so
                # verify can rebuild it without an extra lookup. Tenant-less
                # rows keep using the master fingerprint.
                fingerprint = _key_fingerprint(signing_key)
                # Wave 2A P1: GDPR Art.17 — store a salted hash of the
                # principal so the chain stays linkable when ``principal``
                # is later nulled to honour an erasure request.
                principal_hash: Optional[str] = None
                if principal:
                    principal_hash = hashlib.sha256(
                        f"{principal}|{tenant_id or ''}".encode("utf-8")
                    ).hexdigest()[:16]
                # Wave 1A P0: persist the fingerprint of the signing key so
                # verify_audit_chain() can pick the matching key per row,
                # which makes HMAC key rotation non-destructive.
                try:
                    conn.execute(
                        "INSERT INTO audit_chain"
                        "(entry_id, event_id, prev_hash, entry_hash, ts,"
                        " key_fingerprint, tenant_id, principal_hash)"
                        " VALUES (?,?,?,?,?,?,?,?)",
                        (entry_id, event_id, prev_hash, entry_hash, ts,
                         fingerprint, tenant_id, principal_hash),
                    )
                except Exception as col_exc:
                    # Backward-compat: backends that haven't picked up the
                    # ALTER TABLEs yet still receive the row. Both columns
                    # (key_fingerprint, tenant_id) are added idempotently in
                    # db.py — fall back to the legacy 5-column INSERT.
                    err = str(col_exc).lower()
                    if (
                        "key_fingerprint" not in err
                        and "tenant_id" not in err
                        and "principal_hash" not in err
                    ):
                        raise
                    try:
                        conn.execute(
                            "INSERT INTO audit_chain"
                            "(entry_id, event_id, prev_hash, entry_hash, ts, key_fingerprint)"
                            " VALUES (?,?,?,?,?,?)",
                            (entry_id, event_id, prev_hash, entry_hash, ts, fingerprint),
                        )
                    except Exception as col_exc2:
                        err2 = str(col_exc2).lower()
                        if "key_fingerprint" not in err2:
                            raise
                        conn.execute(
                            "INSERT INTO audit_chain"
                            "(entry_id, event_id, prev_hash, entry_hash, ts)"
                            " VALUES (?,?,?,?,?)",
                            (entry_id, event_id, prev_hash, entry_hash, ts),
                        )
                conn.commit()
        except Exception as exc:
            if not self._fail_open:
                logger.error(
                    "Audit chain write failed (fail-loud): %s", exc, exc_info=True
                )
                raise
            logger.warning("Audit chain write failed (fail-open): %s", exc)

        # Mirror to configured SIEM sinks. Sink failures propagate
        # SinkFailure (which the caller treats as a 503) unless the
        # router was configured with block_on_failure=False per sink.
        if self._sink_router is not None and len(self._sink_router) > 0:
            event_payload = {
                "entry_id": entry_id if "entry_id" in locals() else None,
                "event_id": event_id,
                "action": action,
                "principal": principal,
                "resource": resource,
                "outcome": outcome,
                "metadata": metadata or {},
                "trace_id": trace_id,
                "ts": ts if "ts" in locals() else _now(),
            }
            try:
                self._sink_router.write(event_payload)
            except Exception as exc:
                if not self._fail_open:
                    raise
                logger.warning("SIEM sink router failed (fail-open): %s", exc)
        return event_id


def _row_get(row: Any, col: str, default: Any = None) -> Any:
    """Best-effort column lookup that tolerates missing columns."""
    try:
        v = row[col]
        return v if v is not None else default
    except Exception:
        return default


def verify_audit_chain(
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    *,
    keys: Optional[Dict[str, bytes]] = None,
) -> ChainVerifyResult:
    """Verify the integrity of the audit chain.

    Checks that each entry's entry_hash matches the recomputed HMAC and
    that prev_hash links correctly to the previous entry.

    Args:
        from_ts: ISO timestamp lower bound (inclusive). None = beginning.
        to_ts:   ISO timestamp upper bound (inclusive). None = now.
        keys:    Optional ``{key_fingerprint: hmac_key_bytes}`` mapping.
                 When omitted, only the currently-configured HMAC key is
                 used. Pass historical keys here to verify rows that were
                 signed before a rotation. Wave 1A P0 fix.

    Returns:
        ChainVerifyResult with valid=True if chain is intact.
    """
    from ..store.db import get_shared_connection
    conn = get_shared_connection()

    # Wave 3A: when no persistent HMAC key is configured (dev mode),
    # short-circuit with a clear ``dev_mode=True`` result instead of
    # generating a fresh ephemeral key — every entry would mismatch and
    # the result would falsely report tampering. Callers supplying an
    # explicit ``keys`` map opt out of the short-circuit (they're driving
    # verification with their own key inventory).
    if not keys and _is_dev_ephemeral_key():
        try:
            count_row = conn.execute("SELECT COUNT(*) AS c FROM audit_chain").fetchone()
            count = int(count_row["c"]) if count_row else 0
        except Exception:
            count = 0
        return ChainVerifyResult(
            valid=True,
            entry_count=count,
            dev_mode=True,
            note=(
                "HMAC key not configured — chain integrity skipped. "
                "Set COREIQ_AUDIT_HMAC_KEY and COREIQ_ENV=production to enable "
                "tamper-evident verification."
            ),
        )

    current_key = _get_hmac_key()
    key_map: Dict[str, bytes] = dict(keys or {})
    # Always include the current key so callers don't have to.
    key_map.setdefault(_key_fingerprint(current_key), current_key)

    where_clauses: list = []
    params: list = []
    if from_ts:
        where_clauses.append("ts >= ?")
        params.append(from_ts)
    if to_ts:
        where_clauses.append("ts <= ?")
        params.append(to_ts)
    where = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

    # Try to select key_fingerprint and tenant_id; fall back if either
    # column is absent on older deployments.
    params_t = tuple(params)
    try:
        rows = conn.execute(
            f"SELECT entry_id, event_id, prev_hash, entry_hash, ts, key_fingerprint, tenant_id "
            f"FROM audit_chain {where} ORDER BY ts ASC",
            params_t,
        ).fetchall()
    except Exception:
        try:
            rows = conn.execute(
                f"SELECT entry_id, event_id, prev_hash, entry_hash, ts, key_fingerprint "
                f"FROM audit_chain {where} ORDER BY ts ASC",
                params_t,
            ).fetchall()
        except Exception:
            rows = conn.execute(
                f"SELECT entry_id, event_id, prev_hash, entry_hash, ts FROM audit_chain {where} ORDER BY ts ASC",
                params_t,
            ).fetchall()

    if not rows:
        return ChainVerifyResult(valid=True, entry_count=0, anchored=True)

    # Wave 1A P0 fix: when from_ts is set we may be verifying a window
    # that starts mid-chain. Fetch the entry immediately before the
    # window and check that the first in-window row's prev_hash matches
    # that anchor's entry_hash. If no such anchor exists, state so
    # explicitly in the result rather than silently skipping the check.
    anchor_hash: str = _GENESIS_HASH
    anchored = True
    anchor_note: Optional[str] = None
    if from_ts:
        anchor_row = conn.execute(
            "SELECT entry_id, entry_hash, ts FROM audit_chain WHERE ts < ? ORDER BY ts DESC LIMIT 1",
            (from_ts,),
        ).fetchone()
        if anchor_row is not None:
            anchor_hash = anchor_row["entry_hash"]
        else:
            anchored = False
            anchor_note = (
                "no audit_chain entry exists before from_ts; "
                "first-row prev_hash anchored to genesis"
            )

    expected_prev = anchor_hash
    for i, row in enumerate(rows):
        entry_id = row["entry_id"]
        event_id = row["event_id"]
        prev_hash = row["prev_hash"]
        stored_hash = row["entry_hash"]
        ts = row["ts"]
        fp = _row_get(row, "key_fingerprint")
        row_tenant = _row_get(row, "tenant_id")

        # Check prev_hash linkage. We now anchor the first row too —
        # either to the entry_hash of the row immediately preceding the
        # window, or (when no such row exists) to the genesis sentinel.
        if prev_hash != expected_prev:
            return ChainVerifyResult(
                valid=False,
                entry_count=i,
                broken_at=entry_id,
                error=f"prev_hash mismatch at entry {entry_id}",
                anchored=anchored,
                anchor_note=anchor_note,
            )

        # Pick the right key.
        # Wave 2B P1: when the row carries a ``tenant_id``, derive the
        # per-tenant subkey via HKDF from each available master key and
        # match by fingerprint. This means a row written for tenant A
        # cannot be re-verified using a key derived for tenant B — even
        # though both share the same master HMAC key.
        signing_key: Optional[bytes] = None
        if row_tenant:
            # Try every master key we know about, derive each, and pick
            # the one whose derived fingerprint matches the row's tag.
            for master in key_map.values():
                derived = _derive_tenant_key(master, row_tenant)
                if fp and _key_fingerprint(derived) == fp:
                    signing_key = derived
                    break
            # Back-compat: pre-HKDF tenant rows were signed directly with
            # the master key (their fingerprint matches a raw master,
            # not an HKDF-derived subkey). When no derived fingerprint
            # matches, try a direct master-key fingerprint match before
            # falling through to deriving from the current master.
            if signing_key is None and fp:
                direct_master = key_map.get(fp)
                if direct_master is not None:
                    signing_key = direct_master
            if signing_key is None:
                # No fingerprint match — fall back to deriving from the
                # current master key; verification will fail loudly if
                # the row was actually signed for a different tenant.
                signing_key = _derive_tenant_key(current_key, row_tenant)
        else:
            # Legacy / cross-tenant row — pick by fingerprint as before.
            signing_key = key_map.get(fp) if fp else None
            if signing_key is None:
                signing_key = current_key

        expected_hash = _compute_entry_hash(entry_id, event_id, prev_hash, ts, signing_key)
        if not hmac.compare_digest(stored_hash, expected_hash):
            return ChainVerifyResult(
                valid=False,
                entry_count=i,
                broken_at=entry_id,
                error=(
                    f"entry_hash mismatch at entry {entry_id} — "
                    f"possible tampering or unknown key (fingerprint={fp or 'n/a'})"
                ),
                anchored=anchored,
                anchor_note=anchor_note,
            )

        expected_prev = stored_hash

    return ChainVerifyResult(
        valid=True,
        entry_count=len(rows),
        anchored=anchored,
        anchor_note=anchor_note,
    )
