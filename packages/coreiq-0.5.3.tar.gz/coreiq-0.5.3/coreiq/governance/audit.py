"""Audit log — records all significant operations to the events store."""
from datetime import datetime, timezone
from typing import Any, Dict, Optional


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class AuditLogger:
    """Writes audit entries using the CoreIQ event writer."""

    def __init__(self, source: str = "audit"):
        self._source = source
        self._writer = None  # lazy init to avoid circular imports

    def _get_writer(self):
        if self._writer is None:
            from ..store.writer import get_writer
            self._writer = get_writer()
        return self._writer

    def log(
        self,
        action: str,
        *,
        principal: Optional[str] = None,
        resource: Optional[str] = None,
        outcome: str = "success",
        metadata: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
    ) -> str:
        meta: Dict[str, Any] = {
            "action": action,
            "outcome": outcome,
        }
        if principal:
            meta["principal"] = principal
        if resource:
            meta["resource"] = resource
        if metadata:
            meta.update(metadata)

        level = "info" if outcome == "success" else "warning"
        return self._get_writer().insert_event(
            message=f"[audit] {action}",
            level=level,
            metadata=meta,
            source=self._source,
            trace_id=trace_id,
        )


# Module-level default audit logger
_audit = AuditLogger()


def audit_log(
    action: str,
    *,
    principal: Optional[str] = None,
    resource: Optional[str] = None,
    outcome: str = "success",
    metadata: Optional[Dict[str, Any]] = None,
    trace_id: Optional[str] = None,
) -> str:
    return _audit.log(
        action,
        principal=principal,
        resource=resource,
        outcome=outcome,
        metadata=metadata,
        trace_id=trace_id,
    )
