"""Population Stability Index (PSI) and CUSUM drift detection.

Designed to be invoked from a scheduled job (Kubernetes CronJob, cron,
etc.) — NOT in the request hot path. The scheduler queries the
``inferences`` table for the past N hours of cost / latency / token
metrics, computes PSI against a 7-day baseline window, and emits a
``drift_event`` audit entry whenever a metric exceeds the configured
PSI threshold.

Usage from the new ``coreiq drift`` CLI::

    coreiq drift run --window-hours 24 --baseline-days 7

Or programmatically::

    from coreiq.governance.drift import run_drift_check
    detected = run_drift_check(window_hours=24, baseline_days=7)
    for d in detected:
        print(f"{d.metric}: PSI={d.psi:.3f}")
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from .stats import psi

logger = logging.getLogger("coreiq.governance.drift")

# Default PSI thresholds — industry rule of thumb.
PSI_MODERATE = 0.10
PSI_SIGNIFICANT = 0.25


@dataclass
class DriftDetection:
    """One drift event surfaced by run_drift_check."""

    metric: str
    psi: float
    severity: str  # "moderate" | "significant"
    baseline_window_start: str
    baseline_window_end: str
    current_window_start: str
    current_window_end: str
    sample_count_baseline: int
    sample_count_current: int


def run_drift_check(
    *,
    window_hours: int = 24,
    baseline_days: int = 7,
    metrics: Optional[list[str]] = None,
    conn: Any = None,
) -> list[DriftDetection]:
    """Run a single drift check pass against the inferences table.

    Compares the most recent ``window_hours`` of inference data against
    a baseline window of ``baseline_days`` ending where the current
    window starts. Returns a list of detections (possibly empty).

    Parameters
    ----------
    window_hours:
        Length of the current observation window in hours.
    baseline_days:
        Length of the baseline window in days.
    metrics:
        List of metric names to check. Defaults to
        ``["cost_usd", "latency_ms", "input_tokens", "output_tokens"]``.
    conn:
        Optional StorageBackend. Defaults to ``get_shared_connection()``.

    Returns
    -------
    list[DriftDetection]
        Empty when no metric exceeds the moderate threshold.
    """
    if metrics is None:
        metrics = ["cost_usd", "latency_ms", "input_tokens", "output_tokens"]

    if conn is None:
        from ..store.db import get_shared_connection
        conn = get_shared_connection()

    now = datetime.now(timezone.utc)
    current_end = now
    current_start = now - timedelta(hours=window_hours)
    baseline_end = current_start
    baseline_start = baseline_end - timedelta(days=baseline_days)

    detections: list[DriftDetection] = []

    for metric in metrics:
        # Pull baseline + current samples for this metric. Use the
        # portable SQL — the dialect translator handles backend-specific
        # placeholder rewrites.
        try:
            baseline_rows = conn.fetchall(
                f"SELECT {metric} FROM inferences WHERE ts >= ? AND ts < ?",
                (baseline_start.isoformat(), baseline_end.isoformat()),
            )
            current_rows = conn.fetchall(
                f"SELECT {metric} FROM inferences WHERE ts >= ? AND ts < ?",
                (current_start.isoformat(), current_end.isoformat()),
            )
        except Exception as exc:
            logger.warning("drift: failed to read %s: %s", metric, exc)
            continue

        baseline_values = _extract_numeric(baseline_rows, metric)
        current_values = _extract_numeric(current_rows, metric)

        if len(baseline_values) < 30 or len(current_values) < 10:
            logger.debug(
                "drift: insufficient samples for %s (baseline=%d, current=%d)",
                metric, len(baseline_values), len(current_values),
            )
            continue

        score = psi(baseline_values, current_values)
        if score < PSI_MODERATE:
            continue

        severity = "significant" if score >= PSI_SIGNIFICANT else "moderate"
        detections.append(
            DriftDetection(
                metric=metric,
                psi=score,
                severity=severity,
                baseline_window_start=baseline_start.isoformat(),
                baseline_window_end=baseline_end.isoformat(),
                current_window_start=current_start.isoformat(),
                current_window_end=current_end.isoformat(),
                sample_count_baseline=len(baseline_values),
                sample_count_current=len(current_values),
            )
        )

    return detections


def _extract_numeric(rows: list, column: str) -> list[float]:
    """Pull a numeric column out of fetchall results, skipping nulls."""
    out: list[float] = []
    for row in rows:
        if row is None:
            continue
        # Backend rows can be sqlite3.Row, dict, RealDictRow, MongoRow…
        # All support __getitem__ by column name.
        try:
            value = row[column]
        except (KeyError, IndexError, TypeError):
            continue
        if value is None:
            continue
        try:
            out.append(float(value))
        except (TypeError, ValueError):
            continue
    return out
