"""Enterprise Group Guardrail Enforcement.

Provides runtime evaluation of guardrails derived from OIDC/AD group policies.
Called at pipeline Stage 1 (after auth) and Stage 2/6 (content scanning).

Design goals:
- Zero latency impact when disabled (short-circuit on empty group list)
- Additive to existing key-level checks (group rules are additional constraints)
- Thread-safe; cached per-request to avoid repeated DB queries

Usage (from pipeline)::

    from coreiq.governance.guardrails import GroupGuardrailEngine

    engine = GroupGuardrailEngine()
    engine.check_request(groups=["engineering", "ml-team"], model="gpt-4o",
                         provider="openai", input_tokens=1200)
    engine.check_output(groups=["engineering"], output_text="...", raise_on_violation=True)

Usage (admin config)::

    POST /api/group-policies
    {
      "group_name": "ml-team",
      "allowed_models": ["gpt-4o", "gpt-4o-mini"],
      "denied_models": ["o1-preview"],
      "allowed_providers": ["openai"],
      "max_input_tokens": 8192,
      "max_output_tokens": 4096,
      "max_budget_usd": 100.0,
      "tpm_limit": 100000,
      "rpm_limit": 60,
      "rbac_role": "operator"
    }

    POST /api/group-guardrules
    {
      "group_name": "finance-team",
      "rule_name": "no_financial_data",
      "pattern": "(?:account.number|routing.number|IBAN|swift.code)",
      "description": "Block financial account numbers in output",
      "action": "block"
    }
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("coreiq.governance.guardrails")

# Default TTL for cached policy/rule lookups (seconds).
# Set to 0 to disable caching and always read fresh from the DB.
_CACHE_TTL_SECONDS = 5.0

# Maximum allowed regex pattern length (characters).
_MAX_PATTERN_LEN = 256

# Subprocess smoke-test timeout (seconds).
_REDOS_TEST_TIMEOUT_S = 0.1


def validate_guardrule_pattern(pattern: str) -> None:
    """Validate a guardrule regex pattern for safety.

    Raises ``ValueError`` if the pattern:
    - exceeds ``_MAX_PATTERN_LEN`` characters
    - contains an obvious nested-quantifier construct (ReDoS risk)
    - takes longer than ``_REDOS_TEST_TIMEOUT_S`` on a 1 KB test string
      (tested in a subprocess to isolate the worker from a runaway regex)

    Also raises ``ValueError`` if the pattern is not valid regex.
    """
    # 1. Length check
    if len(pattern) > _MAX_PATTERN_LEN:
        raise ValueError(
            f"Pattern too long ({len(pattern)} chars); maximum is {_MAX_PATTERN_LEN}."
        )

    # 2. Reject obvious nested-quantifier shapes (ReDoS)
    if re.search(r'\([^)]*[+*][^)]*\)\s*[+*]', pattern):
        raise ValueError(
            "Pattern contains a nested quantifier (e.g. `(a+)+`) that can cause "
            "catastrophic backtracking. Rewrite without nested quantifiers."
        )

    # 3. Basic syntax check — must compile before the subprocess test
    try:
        re.compile(pattern, re.IGNORECASE)
    except re.error as exc:
        raise ValueError(f"Invalid regex pattern: {exc}") from exc

    # 4. Subprocess smoke-test on a 1 KB string
    test_code = (
        "import re, sys; "
        f"p = re.compile({pattern!r}, re.IGNORECASE); "
        "p.search('a' * 1024); "
        "sys.exit(0)"
    )
    try:
        subprocess.run(
            [sys.executable, "-c", test_code],
            timeout=_REDOS_TEST_TIMEOUT_S,
            capture_output=True,
        )
    except subprocess.TimeoutExpired:
        raise ValueError(
            "Pattern timed out on a test input — it likely causes catastrophic "
            "backtracking and has been rejected."
        )


class GuardrailViolation(Exception):
    """Raised when a request or response violates a group guardrail."""

    def __init__(self, rule: str, detail: str, group_name: str = ""):
        self.rule = rule
        self.detail = detail
        self.group_name = group_name
        super().__init__(f"Guardrail violation [{rule}] (group={group_name!r}): {detail}")


@dataclass
class GroupRule:
    """A single content guardrule attached to an IdP group."""
    id: str
    group_name: str
    tenant_id: str
    rule_name: str
    pattern: str
    description: str = ""
    action: str = "block"    # "block" | "warn" | "redact"
    _compiled: Any = field(default=None, repr=False, compare=False)

    def compile(self) -> None:
        if self._compiled is None:
            try:
                validate_guardrule_pattern(self.pattern)
                self._compiled = re.compile(self.pattern, re.IGNORECASE)
            except (re.error, ValueError) as exc:
                logger.warning("Invalid or unsafe guardrule pattern %r: %s", self.pattern, exc)
                self._compiled = None

    def matches(self, text: str) -> bool:
        if self._compiled is None:
            self.compile()
        return bool(self._compiled and self._compiled.search(text))


class GroupGuardrailEngine:
    """Runtime guardrail enforcement engine.

    Resolves group policies + content rules from the DB and evaluates them
    against each request. Uses a short TTL cache (default 5s) to avoid
    hitting the DB on every request while still picking up policy changes
    promptly. Set ``_CACHE_TTL_SECONDS = 0`` to disable caching.

    Thread-safe.
    """

    def __init__(self, cache_ttl: float = _CACHE_TTL_SECONDS):
        self._lock = threading.Lock()
        self._cache_ttl = cache_ttl
        # Cache: (groups_key, tenant_id) → (timestamp, result)
        self._policy_cache: Dict[Tuple[str, str], Tuple[float, List[Any]]] = {}
        self._rules_cache: Dict[Tuple[str, str], Tuple[float, List[GroupRule]]] = {}

    # ------------------------------------------------------------------
    # Public API — called from the pipeline
    # ------------------------------------------------------------------

    def check_request(
        self,
        *,
        groups: List[str],
        tenant_id: str = "default",
        model: str = "",
        provider: str = "",
        input_tokens: int = 0,
    ) -> None:
        """Check whether the request is allowed under the groups' policies.

        Enforces: model denylist, model allowlist, provider allowlist,
        max_input_tokens. Called in pipeline Stage 1 (after key auth).

        Args:
            groups: IdP group names for this request (from virtual key metadata).
            tenant_id: Tenant scope.
            model: The requested model.
            provider: The resolved provider.
            input_tokens: Estimated input token count.

        Raises:
            GuardrailViolation: If any policy blocks the request.
        """
        if not groups:
            return

        policies = self._load_policies(groups, tenant_id)
        if not policies:
            return

        for policy in policies:
            # Denylist check (applied before allowlist)
            if policy.denied_models and model in policy.denied_models:
                raise GuardrailViolation(
                    "denied_model",
                    f"Model {model!r} is on the denylist for group {policy.group_name!r}",
                    group_name=policy.group_name,
                )

            # Allowlist check
            if policy.allowed_models and model not in policy.allowed_models:
                raise GuardrailViolation(
                    "model_not_allowed",
                    f"Model {model!r} is not in the allowlist for group {policy.group_name!r}. "
                    f"Allowed: {policy.allowed_models}",
                    group_name=policy.group_name,
                )

            # Provider check
            if policy.allowed_providers and provider and provider not in policy.allowed_providers:
                raise GuardrailViolation(
                    "provider_not_allowed",
                    f"Provider {provider!r} is not allowed for group {policy.group_name!r}. "
                    f"Allowed: {policy.allowed_providers}",
                    group_name=policy.group_name,
                )

            # Input token limit
            if policy.max_input_tokens and input_tokens > policy.max_input_tokens:
                raise GuardrailViolation(
                    "input_token_limit",
                    f"Input tokens ({input_tokens}) exceed limit ({policy.max_input_tokens}) "
                    f"for group {policy.group_name!r}",
                    group_name=policy.group_name,
                )

    def check_output(
        self,
        *,
        groups: List[str],
        tenant_id: str = "default",
        output_text: str,
        output_tokens: int = 0,
        raise_on_violation: bool = True,
    ) -> List[str]:
        """Check LLM output against per-group content guardrules.

        Applies group-specific regex patterns + output token limits.
        Called in pipeline Stage 6 (post-scan).

        Args:
            groups: IdP group names for this request.
            tenant_id: Tenant scope.
            output_text: The LLM response text.
            output_tokens: Token count of the response.
            raise_on_violation: If True, raise GuardrailViolation on first match.

        Returns:
            List of violated rule names (only when raise_on_violation=False).

        Raises:
            GuardrailViolation: If raise_on_violation=True and a rule matches.
        """
        if not groups or not output_text:
            return []

        violations: List[str] = []

        # Output token limit check
        policies = self._load_policies(groups, tenant_id)
        for policy in policies:
            if policy.max_output_tokens and output_tokens > policy.max_output_tokens:
                violation_name = f"output_token_limit:{policy.group_name}"
                if raise_on_violation:
                    raise GuardrailViolation(
                        "output_token_limit",
                        f"Output tokens ({output_tokens}) exceed limit ({policy.max_output_tokens}) "
                        f"for group {policy.group_name!r}",
                        group_name=policy.group_name,
                    )
                violations.append(violation_name)

        # Content rules
        rules = self._load_rules(groups, tenant_id)
        for rule in rules:
            if rule.matches(output_text):
                violation_name = f"{rule.rule_name}:{rule.group_name}"
                logger.warning(
                    "Content guardrule %r matched output for group %r (action=%s)",
                    rule.rule_name, rule.group_name, rule.action,
                )
                if rule.action == "block" and raise_on_violation:
                    raise GuardrailViolation(
                        rule.rule_name,
                        f"Output blocked by guardrule {rule.rule_name!r} "
                        f"(group={rule.group_name!r}): {rule.description}",
                        group_name=rule.group_name,
                    )
                violations.append(violation_name)

        return violations

    def get_role(self, groups: List[str], tenant_id: str = "default") -> str:
        """Return the most permissive RBAC role across all groups.

        Used to assign a dashboard/API role to an IdP-provisioned user.
        Order: admin > operator > viewer.
        """
        if not groups:
            return "viewer"
        policies = self._load_policies(groups, tenant_id)
        if not policies:
            return "viewer"
        role_rank = {"viewer": 0, "operator": 1, "admin": 2}
        best = max(
            ((p.rbac_role or "operator") for p in policies),
            key=lambda r: role_rank.get(r, 1),
        )
        return best

    # ------------------------------------------------------------------
    # DB loaders — cached with short TTL (default 5s) for performance.
    # Policy updates take effect within _CACHE_TTL_SECONDS.
    # ------------------------------------------------------------------

    @staticmethod
    def _cache_key(groups: List[str], tenant_id: str) -> Tuple[str, str]:
        """Build a hashable cache key from groups + tenant."""
        return (",".join(sorted(groups)), tenant_id)

    def _load_policies(self, groups: List[str], tenant_id: str) -> List[Any]:
        """Load GroupPolicy records for the given groups from the DB.

        Results are cached for ``self._cache_ttl`` seconds to avoid a DB
        round-trip on every request.
        """
        ck = self._cache_key(groups, tenant_id)
        now = time.monotonic()

        with self._lock:
            cached = self._policy_cache.get(ck)
            if cached and self._cache_ttl > 0 and (now - cached[0]) < self._cache_ttl:
                return cached[1]

        from ..identity.models import GroupPolicy
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            placeholders = ",".join("?" * len(groups))
            rows = conn.execute(
                f"""
                SELECT * FROM group_policies
                WHERE group_name IN ({placeholders})
                  AND (tenant_id = ? OR tenant_id IS NULL OR tenant_id = '')
                """,
                (*groups, tenant_id),
            ).fetchall()
        except Exception as exc:
            logger.debug("Could not load group policies: %s", exc)
            return []

        def _parse_json_list(v):
            if not v:
                return None
            try:
                return json.loads(v)
            except (json.JSONDecodeError, TypeError):
                return None

        policies = []
        for row in rows:
            policies.append(GroupPolicy(
                id=row["id"],
                group_name=row["group_name"],
                tenant_id=row["tenant_id"] or "default",
                allowed_models=_parse_json_list(row["allowed_models_json"]),
                denied_models=_parse_json_list(
                    row["denied_models_json"] if "denied_models_json" in row.keys() else None
                ),
                allowed_providers=_parse_json_list(
                    row["allowed_providers_json"] if "allowed_providers_json" in row.keys() else None
                ),
                max_budget_usd=row["max_budget_usd"],
                tpm_limit=row["tpm_limit"],
                rpm_limit=row["rpm_limit"],
                max_input_tokens=row["max_input_tokens"] if "max_input_tokens" in row.keys() else None,
                max_output_tokens=row["max_output_tokens"] if "max_output_tokens" in row.keys() else None,
                rbac_role=row["rbac_role"] if "rbac_role" in row.keys() else "operator",
                data_region=row["data_region"] if "data_region" in row.keys() else "",
                created_at=row["created_at"] or "",
            ))

        with self._lock:
            self._policy_cache[ck] = (now, policies)

        return policies

    def _load_rules(self, groups: List[str], tenant_id: str) -> List[GroupRule]:
        """Load GroupRule records for the given groups from the DB.

        Results are cached for ``self._cache_ttl`` seconds.
        """
        ck = self._cache_key(groups, tenant_id)
        now = time.monotonic()

        with self._lock:
            cached = self._rules_cache.get(ck)
            if cached and self._cache_ttl > 0 and (now - cached[0]) < self._cache_ttl:
                return cached[1]

        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            placeholders = ",".join("?" * len(groups))
            rows = conn.execute(
                f"""
                SELECT * FROM group_guardrules
                WHERE group_name IN ({placeholders})
                  AND (tenant_id = ? OR tenant_id IS NULL OR tenant_id = '')
                """,
                (*groups, tenant_id),
            ).fetchall()
        except Exception as exc:
            logger.debug("Could not load group guardrules: %s", exc)
            return []

        rules = []
        for row in rows:
            rule = GroupRule(
                id=row["id"],
                group_name=row["group_name"],
                tenant_id=row["tenant_id"] or "default",
                rule_name=row["rule_name"],
                pattern=row["pattern"],
                description=row["description"] or "",
                action=row["action"] or "block",
            )
            rule.compile()
            rules.append(rule)

        with self._lock:
            self._rules_cache[ck] = (now, rules)

        return rules


# Module-level singleton
_engine: Optional[GroupGuardrailEngine] = None
_engine_lock = threading.Lock()


def get_guardrail_engine() -> GroupGuardrailEngine:
    global _engine
    if _engine is None:
        with _engine_lock:
            if _engine is None:
                _engine = GroupGuardrailEngine()
    return _engine
