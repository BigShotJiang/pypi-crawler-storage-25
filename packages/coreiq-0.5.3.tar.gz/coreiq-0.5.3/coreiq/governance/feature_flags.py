"""Feature flag evaluation service.

Ported from sdk-go's FlagService pattern. Supports per-tenant and per-user
flag overrides with a simple evaluate/toggle API.
"""
from __future__ import annotations
import json
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from ..store.db import get_shared_connection

logger = logging.getLogger("coreiq.governance.feature_flags")

@dataclass
class FlagDecision:
    enabled: bool
    key: str
    reason: str = "default"  # "default", "tenant_override", "user_override", "rule"

@dataclass
class FeatureFlag:
    id: str
    key: str
    description: str
    enabled_by_default: bool
    tenant_overrides: dict  # {tenant_id: bool}
    user_overrides: dict    # {user_id: bool}
    created_at: str
    updated_at: str

class FlagService:
    """Evaluate and manage feature flags."""

    def evaluate(self, key: str, *, tenant_id: str = "", user_id: str = "") -> FlagDecision:
        """Evaluate a feature flag. Check order: user override > tenant override > default."""
        conn = get_shared_connection()
        row = conn.execute("SELECT * FROM feature_flags WHERE key = ?", (key,)).fetchone()
        if not row:
            return FlagDecision(enabled=False, key=key, reason="not_found")

        row = dict(row)
        # User override (highest priority)
        user_overrides = json.loads(row.get("user_overrides") or "{}")
        if user_id and user_id in user_overrides:
            return FlagDecision(enabled=user_overrides[user_id], key=key, reason="user_override")

        # Tenant override
        tenant_overrides = json.loads(row.get("tenant_overrides") or "{}")
        if tenant_id and tenant_id in tenant_overrides:
            return FlagDecision(enabled=tenant_overrides[tenant_id], key=key, reason="tenant_override")

        # Default
        return FlagDecision(enabled=bool(row.get("enabled_by_default", False)), key=key, reason="default")

    def is_enabled(self, key: str, *, tenant_id: str = "", user_id: str = "") -> bool:
        """Shorthand — returns just the boolean."""
        return self.evaluate(key, tenant_id=tenant_id, user_id=user_id).enabled

    def create_flag(self, key: str, description: str = "", enabled_by_default: bool = False) -> FeatureFlag:
        """Create a new feature flag."""
        conn = get_shared_connection()
        flag_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        conn.execute(
            "INSERT OR REPLACE INTO feature_flags (id, key, description, enabled_by_default, tenant_overrides, user_overrides, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)",
            (flag_id, key, description, int(enabled_by_default), "{}", "{}", now, now)
        )
        conn.commit()
        return FeatureFlag(id=flag_id, key=key, description=description, enabled_by_default=enabled_by_default, tenant_overrides={}, user_overrides={}, created_at=now, updated_at=now)

    def set_override(self, key: str, *, tenant_id: str = "", user_id: str = "", enabled: bool = True) -> None:
        """Set a tenant or user override for a flag."""
        conn = get_shared_connection()
        row = conn.execute("SELECT * FROM feature_flags WHERE key = ?", (key,)).fetchone()
        if not row:
            raise ValueError(f"Flag '{key}' not found")
        row = dict(row)
        now = datetime.now(timezone.utc).isoformat()
        if user_id:
            overrides = json.loads(row.get("user_overrides") or "{}")
            overrides[user_id] = enabled
            conn.execute("UPDATE feature_flags SET user_overrides = ?, updated_at = ? WHERE key = ?", (json.dumps(overrides), now, key))
        elif tenant_id:
            overrides = json.loads(row.get("tenant_overrides") or "{}")
            overrides[tenant_id] = enabled
            conn.execute("UPDATE feature_flags SET tenant_overrides = ?, updated_at = ? WHERE key = ?", (json.dumps(overrides), now, key))
        conn.commit()

    def list_flags(self) -> list:
        """List all feature flags."""
        conn = get_shared_connection()
        rows = conn.execute("SELECT * FROM feature_flags ORDER BY key").fetchall()
        return [dict(r) for r in rows]

    def delete_flag(self, key: str) -> bool:
        """Delete a feature flag."""
        conn = get_shared_connection()
        cursor = conn.execute("DELETE FROM feature_flags WHERE key = ?", (key,))
        conn.commit()
        return cursor.rowcount > 0
