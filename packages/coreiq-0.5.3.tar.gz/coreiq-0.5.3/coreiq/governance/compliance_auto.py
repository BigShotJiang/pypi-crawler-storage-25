"""Compliance Auto-Evidence Generator — legacy shim over the plugin registry.

The real implementation now lives in
:mod:`coreiq.governance.frameworks`. This module keeps the
``ComplianceAutoGenerator``/``EvidenceItem``/``CompliancePackage`` surface
stable so v0.3.0 callers (pytest suites, tier3_features router,
docs examples) continue to work unchanged.

Key behaviors:

- :meth:`ComplianceAutoGenerator.generate` routes to
  :data:`coreiq.governance.frameworks.REGISTRY` and maps the four-valued
  plugin status (``pass|warn|fail|not_applicable``) down to the legacy
  three-valued output (``met|partial|not_met``).
- ``EvidenceItem.to_dict()`` and ``CompliancePackage.to_dict()`` emit
  exactly the same keys as v0.3.0.
- :meth:`ComplianceAutoGenerator.update_state` now emits a
  ``DeprecationWarning`` on first call — the new architecture reads real
  tenant data instead of in-memory state dicts — but continues to accept
  writes without raising.
- Framework ids ``soc2``, ``eu_ai_act``, and ``gdpr`` still work and
  return real plugin-driven results.
"""
from __future__ import annotations

import logging
import uuid
import warnings
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Four-value -> three-value status mapping.
_STATUS_MAP = {
    "pass": "met",
    "warn": "partial",
    "fail": "not_met",
    "not_applicable": "partial",
}


@dataclass
class EvidenceItem:
    control_id: str
    title: str
    description: str
    status: str  # "met", "partial", "not_met"
    evidence_data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "control_id": self.control_id,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "evidence_data": self.evidence_data,
        }


@dataclass
class CompliancePackage:
    package_id: str
    framework: str
    generated_at: str
    items: List[EvidenceItem] = field(default_factory=list)
    summary: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "package_id": self.package_id,
            "framework": self.framework,
            "generated_at": self.generated_at,
            "items": [i.to_dict() for i in self.items],
            "summary": self.summary,
            "total_controls": len(self.items),
        }


class ComplianceAutoGenerator:
    """Backward-compat wrapper over the new framework plugin registry."""

    def __init__(self) -> None:
        # Kept for API compatibility — the new architecture ignores this
        # dict and reads real tenant data instead.
        self._system_state: Dict[str, Any] = {}
        self._deprecated_warned = False

    def update_state(self, key: str, value: Any) -> None:
        """Deprecated. The plugin architecture queries live tenant data."""
        if not self._deprecated_warned:
            warnings.warn(
                "ComplianceAutoGenerator.update_state is deprecated; the "
                "plugin framework queries real tenant data via "
                "coreiq.governance.frameworks.compute_all().",
                DeprecationWarning,
                stacklevel=2,
            )
            self._deprecated_warned = True
        self._system_state[key] = value

    def generate(
        self,
        framework: str = "soc2",
        tenant_id: str = "default",
    ) -> CompliancePackage:
        """Run all registered controls for the requested framework and
        return a :class:`CompliancePackage`."""
        from .frameworks import REGISTRY
        from .frameworks.base import ControlContext

        fw = REGISTRY.get(framework)
        items: List[EvidenceItem] = []
        if fw is None:
            # Unknown id: return an empty package (legacy behavior
            # silently substituted SOC 2 — we now return empty so callers
            # can detect typos rather than silently getting the wrong data).
            return CompliancePackage(
                package_id=str(uuid.uuid4())[:8],
                framework=framework,
                generated_at=datetime.now(timezone.utc).isoformat(),
                items=items,
                summary={"met": 0, "partial": 0, "not_met": 0},
            )

        ctx = ControlContext(tenant_id=tenant_id)
        for control in fw.controls:
            try:
                result = control.check_fn(ctx)
            except Exception as exc:
                logger.exception("check_fn failed for %s", control.id)
                items.append(EvidenceItem(
                    control_id=control.id,
                    title=control.name,
                    description=control.description,
                    status="not_met",
                    evidence_data={"error": str(exc)},
                ))
                continue
            items.append(EvidenceItem(
                control_id=control.id,
                title=control.name,
                description=control.description,
                status=_STATUS_MAP.get(result.status, "partial"),
                evidence_data=dict(result.evidence or {}),
            ))

        summary = {
            "met": sum(1 for i in items if i.status == "met"),
            "partial": sum(1 for i in items if i.status == "partial"),
            "not_met": sum(1 for i in items if i.status == "not_met"),
        }
        return CompliancePackage(
            package_id=str(uuid.uuid4())[:8],
            framework=framework,
            generated_at=datetime.now(timezone.utc).isoformat(),
            items=items,
            summary=summary,
        )
