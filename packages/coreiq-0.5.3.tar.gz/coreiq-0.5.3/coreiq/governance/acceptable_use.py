from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class AcceptableUsePolicy:
    id: str
    tenant_id: str
    content_markdown: str
    version: int
    active: int
    created_at: str


@dataclass
class UserAcknowledgment:
    id: str
    policy_id: str
    user_id: str
    acknowledged_at: str
    ip_address: str


class AUPManager:
    def create_policy(self, tenant_id: str, content: str) -> AcceptableUsePolicy:
        conn = get_shared_connection()
        row = conn.execute(
            "SELECT MAX(version) as v FROM aup_policies WHERE tenant_id=?", (tenant_id,)
        ).fetchone()
        try:
            version = (row.get("v") or 0) + 1 if row else 1
        except AttributeError:
            version = (row["v"] or 0) + 1 if (row and row["v"]) else 1
        conn.execute("UPDATE aup_policies SET active=0 WHERE tenant_id=?", (tenant_id,))
        p = AcceptableUsePolicy(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            content_markdown=content,
            version=version,
            active=1,
            created_at=_now(),
        )
        conn.execute(
            "INSERT INTO aup_policies(id,tenant_id,content_markdown,version,active,created_at) VALUES(?,?,?,?,?,?)",
            (p.id, p.tenant_id, p.content_markdown, p.version, p.active, p.created_at),
        )
        conn.commit()
        return p

    def get_active(self, tenant_id: str) -> Optional[AcceptableUsePolicy]:
        row = get_shared_connection().execute(
            "SELECT * FROM aup_policies WHERE tenant_id=? AND active=1 ORDER BY version DESC LIMIT 1", (tenant_id,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        return AcceptableUsePolicy(
            id=d.get("id", ""),
            tenant_id=d.get("tenant_id", tenant_id),
            content_markdown=d.get("content_markdown", ""),
            version=d.get("version", 1),
            active=d.get("active", 1),
            created_at=d.get("created_at", ""),
        )

    def acknowledge(self, policy_id: str, user_id: str, ip_address: str = "") -> UserAcknowledgment:
        conn = get_shared_connection()
        a = UserAcknowledgment(
            id=str(uuid.uuid4()),
            policy_id=policy_id,
            user_id=user_id,
            acknowledged_at=_now(),
            ip_address=ip_address,
        )
        conn.execute(
            "INSERT OR REPLACE INTO aup_acknowledgments(id,policy_id,user_id,acknowledged_at,ip_address) VALUES(?,?,?,?,?)",
            (a.id, a.policy_id, a.user_id, a.acknowledged_at, a.ip_address),
        )
        conn.commit()
        return a

    def acknowledgment_status(self, tenant_id: str) -> dict:
        conn = get_shared_connection()
        policy = self.get_active(tenant_id)
        if not policy:
            return {"policy_id": None, "total_users": 0, "acknowledged": 0, "pending": []}
        ack_rows = conn.execute(
            "SELECT user_id FROM aup_acknowledgments WHERE policy_id=?", (policy.id,)
        ).fetchall()
        acked = {r["user_id"] for r in ack_rows}
        user_rows = conn.execute(
            "SELECT id, email FROM users WHERE tenant_id=? AND status='active'", (tenant_id,)
        ).fetchall()
        # Deduplicate by email — repeated testkit/API runs can create multiple
        # rows for the same address; count each distinct email once.
        seen_emails: set = set()
        unique_users: list = []
        for r in user_rows:
            email = r["email"]
            if email not in seen_emails:
                seen_emails.add(email)
                unique_users.append(r)
        pending = [r["email"] for r in unique_users if r["id"] not in acked]
        return {
            "policy_id": policy.id,
            "version": policy.version,
            "total_users": len(unique_users),
            "acknowledged": len(acked),
            "pending": pending,
        }
