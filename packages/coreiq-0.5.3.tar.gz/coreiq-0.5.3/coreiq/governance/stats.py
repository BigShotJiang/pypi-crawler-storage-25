"""Statistical helpers for drift and anomaly detection.

Pure stdlib (math) — no NumPy required so this module is importable
without any optional extras. The implementations are deliberately
simple: PSI for distribution drift, CUSUM for time-series shift, and
rolling-window z-score for anomaly detection.

Reference reading:
- PSI: https://www.listendata.com/2015/05/population-stability-index.html
- CUSUM: https://en.wikipedia.org/wiki/CUSUM
"""
from __future__ import annotations

import math
from typing import Sequence


def histogram(values: Sequence[float], buckets: int = 10) -> tuple[list[float], list[int]]:
    """Build a histogram with `buckets` equally-sized bins.

    Returns ``(bin_edges, counts)`` where ``len(bin_edges) == buckets+1``.
    """
    if not values:
        return ([0.0] * (buckets + 1), [0] * buckets)
    lo = min(values)
    hi = max(values)
    if lo == hi:
        # Single-value distribution — make a degenerate range so PSI
        # math doesn't divide by zero.
        hi = lo + 1.0
    width = (hi - lo) / buckets
    edges = [lo + i * width for i in range(buckets + 1)]
    counts = [0] * buckets
    for v in values:
        idx = int((v - lo) / width)
        if idx >= buckets:
            idx = buckets - 1
        counts[idx] += 1
    return edges, counts


def psi(baseline: Sequence[float], current: Sequence[float], buckets: int = 10) -> float:
    """Population Stability Index between two distributions.

    Returns a non-negative float. Industry rules of thumb:
        PSI < 0.1   → no significant change
        0.1 ≤ PSI < 0.25 → moderate drift
        PSI ≥ 0.25  → significant drift
    """
    if not baseline or not current:
        return 0.0
    lo = min(min(baseline), min(current))
    hi = max(max(baseline), max(current))
    if lo == hi:
        return 0.0
    width = (hi - lo) / buckets

    base_counts = [0] * buckets
    cur_counts = [0] * buckets
    for v in baseline:
        idx = int((v - lo) / width)
        if idx >= buckets:
            idx = buckets - 1
        base_counts[idx] += 1
    for v in current:
        idx = int((v - lo) / width)
        if idx >= buckets:
            idx = buckets - 1
        cur_counts[idx] += 1

    n_base = len(baseline)
    n_cur = len(current)

    score = 0.0
    for b, c in zip(base_counts, cur_counts):
        # Smoothing — PSI is undefined when a bin is empty in either
        # population, so add 0.0001 to both counts.
        b_pct = (b + 0.0001) / n_base
        c_pct = (c + 0.0001) / n_cur
        score += (c_pct - b_pct) * math.log(c_pct / b_pct)
    return score


def cusum(values: Sequence[float], target: float, threshold: float, k: float = 0.5) -> tuple[bool, float]:
    """Cumulative-sum control chart for detecting shifts in a series.

    Returns ``(alarm, max_excursion)`` where ``alarm`` is True if the
    one-sided cumulative sum exceeded ``threshold`` at any point.
    ``k`` is the slack parameter (typically half the smallest shift
    you want to detect).

    This is intentionally one-sided (positive shift only) because the
    typical anomaly we care about — cost spike, latency spike, token
    surge — all show as upward excursions.
    """
    if not values:
        return (False, 0.0)
    s = 0.0
    max_s = 0.0
    for v in values:
        s = max(0.0, s + (v - target - k))
        if s > max_s:
            max_s = s
    return (max_s > threshold, max_s)


def rolling_zscore(values: Sequence[float], window: int = 50) -> float:
    """Z-score of the latest value against a rolling baseline window.

    Uses the previous ``window`` values (excluding the latest) as the
    baseline. Returns 0 when the baseline has fewer than 2 samples or
    its standard deviation is zero — both cases mean "no opinion".
    """
    if len(values) < 2:
        return 0.0
    latest = values[-1]
    baseline = list(values[-window - 1 : -1])
    if len(baseline) < 2:
        return 0.0
    mean = sum(baseline) / len(baseline)
    variance = sum((x - mean) ** 2 for x in baseline) / len(baseline)
    std = math.sqrt(variance)
    if std == 0:
        return 0.0
    return (latest - mean) / std


def is_anomalous(values: Sequence[float], window: int = 50, threshold: float = 3.0) -> bool:
    """True if the latest value is at least ``threshold`` sigmas from
    the rolling baseline (default: 3-sigma)."""
    return abs(rolling_zscore(values, window=window)) >= threshold
