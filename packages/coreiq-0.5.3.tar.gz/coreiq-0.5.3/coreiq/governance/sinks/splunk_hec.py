"""Splunk HTTP Event Collector (HEC) audit sink."""
from __future__ import annotations

import json
from typing import Optional

from .base import AuditSink, SinkFailure


class SplunkHECSink(AuditSink):
    """Posts audit events to a Splunk HTTP Event Collector endpoint.

    Parameters
    ----------
    url:
        Full HEC URL, e.g. ``https://splunk.example.com:8088/services/collector/event``.
    token:
        HEC token (created in Splunk under Settings → Data inputs → HEC).
    source:
        Splunk ``source`` field. Defaults to ``coreiq``.
    sourcetype:
        Splunk ``sourcetype`` field. Defaults to ``coreiq:audit``.
    index:
        Optional Splunk index to write to. Defaults to the HEC token's
        configured default.
    timeout_s:
        HTTP timeout in seconds. A timeout counts as a sink failure.
    verify_ssl:
        Set False for self-signed Splunk deployments.
    """

    def __init__(
        self,
        *,
        url: str,
        token: str,
        source: str = "coreiq",
        sourcetype: str = "coreiq:audit",
        index: Optional[str] = None,
        timeout_s: float = 5.0,
        verify_ssl: bool = True,
    ) -> None:
        if not url:
            raise ValueError("SplunkHECSink requires a non-empty url")
        if not token:
            raise ValueError("SplunkHECSink requires a non-empty token")
        self._url = url
        self._token = token
        self._source = source
        self._sourcetype = sourcetype
        self._index = index
        self._timeout = timeout_s
        self._verify = verify_ssl

    @property
    def name(self) -> str:
        return "splunk_hec"

    def write(self, event: dict) -> None:
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise SinkFailure(self.name, f"httpx not installed: {exc}") from exc

        payload: dict = {
            "event": event,
            "source": self._source,
            "sourcetype": self._sourcetype,
        }
        if self._index:
            payload["index"] = self._index

        headers = {
            "Authorization": f"Splunk {self._token}",
            "Content-Type": "application/json",
        }

        try:
            with httpx.Client(timeout=self._timeout, verify=self._verify) as client:
                resp = client.post(self._url, headers=headers, content=json.dumps(payload))
        except httpx.HTTPError as exc:
            raise SinkFailure(self.name, f"transport error: {exc}") from exc

        if resp.status_code >= 300:
            raise SinkFailure(
                self.name,
                f"HTTP {resp.status_code}: {resp.text[:200]}",
            )
