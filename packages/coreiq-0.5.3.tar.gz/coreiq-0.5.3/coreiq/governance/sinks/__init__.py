"""Audit sink implementations.

Each sink implements :class:`AuditSink` from :mod:`base` and writes a
structured audit event to its respective destination (Splunk HEC,
Microsoft Sentinel, Google Chronicle, Datadog Logs, Elasticsearch, S3
WORM bucket).

The :class:`AuditSinkRouter` (also in :mod:`base`) fans out a single
audit event to N sinks with per-sink failure policy (block-on-fail vs
log-and-continue).
"""
from .base import AuditSink, AuditSinkRouter, SinkFailure
from .chronicle import ChronicleSink
from .datadog_siem import DatadogSIEMSink
from .elastic import ElasticSink
from .s3_worm import S3WORMSink
from .sentinel import SentinelSink
from .splunk_hec import SplunkHECSink

__all__ = [
    "AuditSink",
    "AuditSinkRouter",
    "SinkFailure",
    "SplunkHECSink",
    "SentinelSink",
    "ChronicleSink",
    "DatadogSIEMSink",
    "ElasticSink",
    "S3WORMSink",
]
