"""Microsoft Sentinel Log Analytics audit sink.

Uses the modern Data Collection Rule (DCR) ingestion API rather than
the legacy HTTP Data Collector. Requires
``coreiq[siem-sentinel]`` which adds ``azure-monitor-ingestion`` and
``azure-identity``.
"""
from __future__ import annotations

from typing import Optional

from .base import AuditSink, SinkFailure


class SentinelSink(AuditSink):
    """Posts audit events to a Microsoft Sentinel custom table via DCR.

    Parameters
    ----------
    endpoint:
        DCR endpoint URL, e.g.
        ``https://my-dcr-abcd.eastus-1.ingest.monitor.azure.com``.
    rule_id:
        DCR immutable ID (``dcr-...``).
    stream_name:
        Custom stream name configured in the DCR
        (e.g. ``Custom-CoreIQAudit_CL``).
    credential:
        Optional ``TokenCredential`` instance. If None, uses
        ``DefaultAzureCredential()`` from ``coreiq[siem-sentinel]``.
    """

    def __init__(
        self,
        *,
        endpoint: str,
        rule_id: str,
        stream_name: str,
        credential: Optional[object] = None,
    ) -> None:
        if not endpoint:
            raise ValueError("SentinelSink requires a non-empty endpoint")
        if not rule_id:
            raise ValueError("SentinelSink requires a non-empty rule_id")
        if not stream_name:
            raise ValueError("SentinelSink requires a non-empty stream_name")
        self._endpoint = endpoint
        self._rule_id = rule_id
        self._stream_name = stream_name
        self._credential = credential
        self._client = None  # lazy

    @property
    def name(self) -> str:
        return "sentinel"

    def _get_client(self):
        if self._client is not None:
            return self._client
        try:
            from azure.identity import DefaultAzureCredential
            from azure.monitor.ingestion import LogsIngestionClient
        except ImportError as exc:
            raise SinkFailure(
                self.name,
                f"requires coreiq[siem-sentinel]: {exc}",
            ) from exc

        credential = self._credential or DefaultAzureCredential()
        self._client = LogsIngestionClient(endpoint=self._endpoint, credential=credential)
        return self._client

    def write(self, event: dict) -> None:
        client = self._get_client()
        try:
            client.upload(rule_id=self._rule_id, stream_name=self._stream_name, logs=[event])
        except Exception as exc:  # azure SDK exceptions
            raise SinkFailure(self.name, f"upload failed: {exc}") from exc
