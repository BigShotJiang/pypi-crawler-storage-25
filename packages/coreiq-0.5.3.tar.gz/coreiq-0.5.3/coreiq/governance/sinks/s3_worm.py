"""S3 Object Lock (WORM) audit sink for tamper-evident archival."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from .base import AuditSink, SinkFailure


class S3WORMSink(AuditSink):
    """Writes audit events to an S3 bucket with Object Lock enabled.

    Object Lock in COMPLIANCE mode prevents the object from being
    deleted or overwritten by ANY user — including the bucket owner —
    until the retention period elapses. This makes the bucket a
    legally-defensible immutable archive for SOC 2 / 17a-4 / HIPAA
    audit retention requirements.

    Each audit event is written as a separate JSON object with a
    timestamped key (``YYYY/MM/DD/HH/<uuid>.json``) so the bucket can
    be efficiently scanned by date range later.

    Parameters
    ----------
    bucket:
        S3 bucket name. The bucket MUST have Object Lock enabled at
        creation time — Object Lock cannot be enabled retroactively.
    region:
        AWS region. Defaults to env var ``AWS_REGION`` or
        ``us-east-1``.
    retention_days:
        Number of days to lock each object for. Defaults to 2555
        (~7 years, the SEC 17a-4 retention floor).
    retention_mode:
        ``COMPLIANCE`` (default — strictly immutable) or
        ``GOVERNANCE`` (admin override possible).
    key_prefix:
        Optional prefix for every object key, e.g. ``coreiq-prod/``.
    """

    def __init__(
        self,
        *,
        bucket: str,
        region: Optional[str] = None,
        retention_days: int = 2555,
        retention_mode: str = "COMPLIANCE",
        key_prefix: str = "",
    ) -> None:
        if not bucket:
            raise ValueError("S3WORMSink requires bucket")
        if retention_mode not in ("COMPLIANCE", "GOVERNANCE"):
            raise ValueError("retention_mode must be COMPLIANCE or GOVERNANCE")
        self._bucket = bucket
        self._region = region
        self._retention_days = retention_days
        self._retention_mode = retention_mode
        self._key_prefix = key_prefix
        self._client = None

    @property
    def name(self) -> str:
        return "s3_worm"

    def _get_client(self):
        if self._client is not None:
            return self._client
        try:
            import boto3
        except ImportError as exc:
            raise SinkFailure(self.name, f"requires coreiq[siem-s3]: {exc}") from exc
        kwargs: dict = {}
        if self._region:
            kwargs["region_name"] = self._region
        self._client = boto3.client("s3", **kwargs)
        return self._client

    def _build_key(self) -> str:
        now = datetime.now(timezone.utc)
        ts_path = now.strftime("%Y/%m/%d/%H")
        return f"{self._key_prefix}{ts_path}/{uuid.uuid4().hex}.json"

    def write(self, event: dict) -> None:
        client = self._get_client()
        key = self._build_key()
        retain_until = datetime.now(timezone.utc) + timedelta(days=self._retention_days)

        try:
            client.put_object(
                Bucket=self._bucket,
                Key=key,
                Body=json.dumps(event).encode("utf-8"),
                ContentType="application/json",
                ObjectLockMode=self._retention_mode,
                ObjectLockRetainUntilDate=retain_until,
            )
        except Exception as exc:
            raise SinkFailure(self.name, f"put_object failed: {exc}") from exc
