"""Datadog Cloud SIEM audit sink (via Logs API)."""
from __future__ import annotations

import json
from typing import Optional

from .base import AuditSink, SinkFailure

_DEFAULT_INTAKE_HOST = "http-intake.logs.datadoghq.com"


class DatadogSIEMSink(AuditSink):
    """Posts audit events to Datadog Logs (which feeds Datadog Cloud SIEM).

    Parameters
    ----------
    api_key:
        Datadog API key (NOT the application key).
    site:
        Datadog site, e.g. ``datadoghq.com`` (default), ``datadoghq.eu``,
        ``us3.datadoghq.com``. Used to construct the intake host
        when ``intake_host`` is not provided.
    intake_host:
        Override the intake hostname directly. Useful for unusual
        deployments.
    service:
        Datadog ``service`` tag attached to every event. Defaults to ``coreiq``.
    source:
        Datadog ``source`` tag. Defaults to ``coreiq``.
    timeout_s:
        HTTP timeout in seconds.
    """

    def __init__(
        self,
        *,
        api_key: str,
        site: str = "datadoghq.com",
        intake_host: Optional[str] = None,
        service: str = "coreiq",
        source: str = "coreiq",
        timeout_s: float = 5.0,
    ) -> None:
        if not api_key:
            raise ValueError("DatadogSIEMSink requires api_key")
        self._api_key = api_key
        if intake_host:
            host = intake_host
        elif site == "datadoghq.com":
            host = _DEFAULT_INTAKE_HOST
        else:
            host = f"http-intake.logs.{site}"
        self._url = f"https://{host}/api/v2/logs"
        self._service = service
        self._source = source
        self._timeout = timeout_s

    @property
    def name(self) -> str:
        return "datadog_siem"

    def write(self, event: dict) -> None:
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise SinkFailure(self.name, f"httpx not installed: {exc}") from exc

        # Datadog Logs API expects either a single object or an array.
        payload = {
            "ddsource": self._source,
            "service": self._service,
            "message": json.dumps(event),
            **{f"audit.{k}": v for k, v in event.items() if isinstance(v, (str, int, float, bool))},
        }
        headers = {
            "Content-Type": "application/json",
            "DD-API-KEY": self._api_key,
        }

        try:
            with httpx.Client(timeout=self._timeout) as client:
                resp = client.post(self._url, headers=headers, content=json.dumps(payload))
        except httpx.HTTPError as exc:
            raise SinkFailure(self.name, f"transport error: {exc}") from exc

        if resp.status_code >= 300:
            raise SinkFailure(
                self.name,
                f"HTTP {resp.status_code}: {resp.text[:200]}",
            )
