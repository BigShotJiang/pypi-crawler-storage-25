"""Google Chronicle Unified Data Model (UDM) audit sink.

Posts audit events to Google Chronicle's ingestion API. Requires
``coreiq[siem-chronicle]`` which adds ``google-auth``.
"""
from __future__ import annotations

import json
from typing import Optional

from .base import AuditSink, SinkFailure

_DEFAULT_ENDPOINT = "https://malachiteingestion-pa.googleapis.com/v2/unstructuredlogentries:batchCreate"


class ChronicleSink(AuditSink):
    """Posts audit events to Google Chronicle as unstructured log entries.

    Parameters
    ----------
    customer_id:
        Chronicle customer ID (UUID).
    log_type:
        Chronicle log type identifier, e.g. ``COREIQ_AUDIT``. Must be
        registered with Chronicle support before first use.
    service_account_json_path:
        Path to a Google Cloud service account JSON key file with
        Chronicle ingestion permissions. The credential is loaded
        lazily on first write.
    endpoint:
        Override the default ingestion endpoint (e.g. for region-specific
        deployments).
    timeout_s:
        HTTP timeout in seconds.
    """

    def __init__(
        self,
        *,
        customer_id: str,
        log_type: str,
        service_account_json_path: str,
        endpoint: Optional[str] = None,
        timeout_s: float = 5.0,
    ) -> None:
        if not customer_id:
            raise ValueError("ChronicleSink requires customer_id")
        if not log_type:
            raise ValueError("ChronicleSink requires log_type")
        if not service_account_json_path:
            raise ValueError("ChronicleSink requires service_account_json_path")
        self._customer_id = customer_id
        self._log_type = log_type
        self._sa_path = service_account_json_path
        self._endpoint = endpoint or _DEFAULT_ENDPOINT
        self._timeout = timeout_s
        self._credentials = None  # lazy

    @property
    def name(self) -> str:
        return "chronicle"

    def _get_credentials(self):
        if self._credentials is not None:
            return self._credentials
        try:
            from google.auth.transport.requests import Request
            from google.oauth2 import service_account
        except ImportError as exc:
            raise SinkFailure(
                self.name,
                f"requires coreiq[siem-chronicle]: {exc}",
            ) from exc
        creds = service_account.Credentials.from_service_account_file(
            self._sa_path,
            scopes=["https://www.googleapis.com/auth/malachite-ingestion"],
        )
        creds.refresh(Request())
        self._credentials = creds
        return creds

    def write(self, event: dict) -> None:
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise SinkFailure(self.name, f"httpx not installed: {exc}") from exc

        creds = self._get_credentials()
        if creds.expired:
            from google.auth.transport.requests import Request
            creds.refresh(Request())

        body = {
            "customerId": self._customer_id,
            "logType": self._log_type,
            "entries": [{"logText": json.dumps(event)}],
        }
        headers = {
            "Authorization": f"Bearer {creds.token}",
            "Content-Type": "application/json",
        }

        try:
            with httpx.Client(timeout=self._timeout) as client:
                resp = client.post(self._endpoint, headers=headers, content=json.dumps(body))
        except httpx.HTTPError as exc:
            raise SinkFailure(self.name, f"transport error: {exc}") from exc

        if resp.status_code >= 300:
            raise SinkFailure(
                self.name,
                f"HTTP {resp.status_code}: {resp.text[:200]}",
            )
