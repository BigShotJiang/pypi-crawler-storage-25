"""Elasticsearch / OpenSearch _bulk audit sink."""
from __future__ import annotations

import json
from typing import Optional

from .base import AuditSink, SinkFailure


class ElasticSink(AuditSink):
    """Posts audit events to an Elasticsearch (or OpenSearch) cluster.

    Uses the ``_bulk`` endpoint with a single ``index`` action per
    write — even though we're writing one event at a time, ``_bulk``
    is the canonical Elasticsearch ingestion API and works against
    every supported version (8.x, 7.x, OpenSearch 2.x).

    Parameters
    ----------
    url:
        Cluster base URL, e.g. ``https://elastic.example.com:9200``.
    index:
        Index name to write to (e.g. ``coreiq-audit``).
    api_key:
        Elasticsearch API key (preferred). Mutually exclusive with
        ``username``/``password``.
    username, password:
        HTTP basic auth credentials. Used when ``api_key`` is None.
    timeout_s:
        HTTP timeout in seconds.
    verify_ssl:
        Set False for self-signed clusters.
    """

    def __init__(
        self,
        *,
        url: str,
        index: str,
        api_key: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        timeout_s: float = 5.0,
        verify_ssl: bool = True,
    ) -> None:
        if not url:
            raise ValueError("ElasticSink requires url")
        if not index:
            raise ValueError("ElasticSink requires index")
        if not (api_key or (username and password)):
            raise ValueError(
                "ElasticSink requires either api_key or username+password"
            )
        self._url = url.rstrip("/") + "/_bulk"
        self._index = index
        self._api_key = api_key
        self._username = username
        self._password = password
        self._timeout = timeout_s
        self._verify = verify_ssl

    @property
    def name(self) -> str:
        return "elastic"

    def write(self, event: dict) -> None:
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise SinkFailure(self.name, f"httpx not installed: {exc}") from exc

        # _bulk format: NDJSON pairs of (action, document) lines.
        action = json.dumps({"index": {"_index": self._index}})
        document = json.dumps(event)
        body = f"{action}\n{document}\n"

        headers = {"Content-Type": "application/x-ndjson"}
        auth = None
        if self._api_key:
            headers["Authorization"] = f"ApiKey {self._api_key}"
        else:
            auth = (self._username or "", self._password or "")

        try:
            with httpx.Client(timeout=self._timeout, verify=self._verify) as client:
                resp = client.post(
                    self._url,
                    headers=headers,
                    content=body,
                    auth=auth,
                )
        except httpx.HTTPError as exc:
            raise SinkFailure(self.name, f"transport error: {exc}") from exc

        if resp.status_code >= 300:
            raise SinkFailure(
                self.name,
                f"HTTP {resp.status_code}: {resp.text[:200]}",
            )

        # _bulk returns 200 even when individual items fail; check
        # the response body for per-item errors.
        try:
            body_json = resp.json()
            if body_json.get("errors"):
                raise SinkFailure(
                    self.name,
                    f"bulk had item errors: {json.dumps(body_json)[:200]}",
                )
        except SinkFailure:
            raise
        except Exception:
            # JSON decode failure — treat as opaque success since the
            # HTTP code was good.
            pass
