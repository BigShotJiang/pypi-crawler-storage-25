"""Audit sink ABC, fan-out router, and env-driven sink factory.

The :class:`AuditSink` interface is the contract every concrete sink
implementation honors. The :class:`AuditSinkRouter` lets one audit
event be written to N sinks with per-sink failure policy: a sink can
either block the request (fail-closed) or log a warning and continue
(fail-open).

Design rules
------------

1. Every sink's :meth:`AuditSink.write` is **synchronous and
   fail-loud** by default. Buffering audit was the original sin —
   audit events that ride on a buffered writer get dropped on crashes,
   which is the exact failure mode that breaks the marketed
   "cryptographically immutable audit" claim.
2. The router decides on a per-sink basis whether a write failure
   propagates a :class:`SinkFailure` (block-on-fail) or only logs a
   warning (log-and-continue). The decision is made when the sink is
   added, not at write time.
3. Sinks should validate their config in `__init__` and raise on
   missing credentials, so a misconfigured sink fails at startup
   rather than on the first audit write.
"""
from __future__ import annotations

import logging
import os
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional

logger = logging.getLogger("coreiq.governance.sinks")


class SinkFailure(Exception):
    """Raised by an audit sink when a write fails irrecoverably.

    The router catches this and either re-raises (when the sink is
    configured `block_on_failure=True`) or logs a warning and continues
    to the next sink.
    """

    def __init__(self, sink_name: str, message: str) -> None:
        super().__init__(f"audit sink {sink_name}: {message}")
        self.sink_name = sink_name
        self.detail = message


class AuditSink(ABC):
    """Abstract base class for an audit destination.

    Concrete sinks (Splunk, Sentinel, Chronicle, Datadog, Elastic, S3
    WORM) inherit and implement :meth:`write`. The method takes a
    plain dict (the audit event payload) and either returns cleanly or
    raises :class:`SinkFailure` with a clear reason.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Short identifier used in logs and error messages."""

    @abstractmethod
    def write(self, event: dict) -> None:
        """Synchronously write a single audit event to the sink.

        Must raise :class:`SinkFailure` on any failure (network error,
        auth rejection, schema validation failure). The router catches
        the exception and applies the configured failure policy.
        """


@dataclass
class _RegisteredSink:
    sink: AuditSink
    block_on_failure: bool


class AuditSinkRouter:
    """Fan-out audit writes to N sinks with per-sink failure policy.

    Usage::

        router = AuditSinkRouter()
        router.add(SplunkHECSink(url=..., token=...), block_on_failure=True)
        router.add(S3WORMSink(bucket=...), block_on_failure=True)
        router.add(DatadogSIEMSink(api_key=...), block_on_failure=False)
        router.write(event)

    Sinks are written in registration order. If a `block_on_failure`
    sink fails, the router immediately raises :class:`SinkFailure` and
    does NOT call later sinks — the audit write is treated as failed
    and the caller (typically the proxy pipeline) returns a 503 to the
    HTTP client.

    `block_on_failure=False` sinks log the failure and continue.
    """

    def __init__(self) -> None:
        self._sinks: List[_RegisteredSink] = []

    def add(self, sink: AuditSink, *, block_on_failure: bool = False) -> None:
        self._sinks.append(_RegisteredSink(sink=sink, block_on_failure=block_on_failure))

    def __len__(self) -> int:
        return len(self._sinks)

    def names(self) -> List[str]:
        return [s.sink.name for s in self._sinks]

    def write(self, event: dict) -> None:
        """Write *event* to every registered sink in order.

        Raises :class:`SinkFailure` on the first `block_on_failure`
        sink that errors. `block_on_failure=False` sinks log a warning
        and the iteration continues.
        """
        for entry in self._sinks:
            try:
                entry.sink.write(event)
            except SinkFailure as exc:
                if entry.block_on_failure:
                    logger.error(
                        "Audit sink %s failed (block_on_failure=true), refusing request: %s",
                        entry.sink.name,
                        exc.detail,
                    )
                    raise
                logger.warning(
                    "Audit sink %s failed (log-and-continue): %s",
                    entry.sink.name,
                    exc.detail,
                )
            except Exception as exc:  # pragma: no cover — defensive
                # A sink that raises something other than SinkFailure is
                # a programming error in the sink implementation. Wrap
                # and apply the same policy.
                wrapped = SinkFailure(entry.sink.name, f"unexpected: {exc}")
                if entry.block_on_failure:
                    raise wrapped from exc
                logger.warning(
                    "Audit sink %s raised unexpected exception (log-and-continue): %s",
                    entry.sink.name,
                    exc,
                )


# ── Env-driven sink factory ───────────────────────────────────────────────────

_router: Optional["AuditSinkRouter"] = None
_router_lock = threading.Lock()


def get_sink_router() -> "AuditSinkRouter":
    """Return the process-wide AuditSinkRouter, building it on first call.

    On first construction, sinks are auto-registered from environment variables
    (see :func:`_auto_populate_sinks_from_env`). Misconfigured sinks are
    skipped with a warning so a single bad sink can never block startup —
    audit-chain integrity itself is enforced by ``COREIQ_AUDIT_HMAC_KEY``.
    """
    global _router
    if _router is None:
        with _router_lock:
            if _router is None:
                _router = AuditSinkRouter()
                _auto_populate_sinks_from_env(_router)
    return _router


def _block(name: str) -> bool:
    """Return True iff COREIQ_SINK_<NAME>_BLOCK is set truthy."""
    val = os.environ.get(f"COREIQ_SINK_{name}_BLOCK", "").lower()
    return val in ("1", "true", "yes", "on")


def _auto_populate_sinks_from_env(router: "AuditSinkRouter") -> None:
    """Register concrete audit sinks from ``COREIQ_SINK_*`` env vars.

    Recognised variables (per sink, all optional — set to enable):

    Splunk HEC
        ``COREIQ_SINK_SPLUNK_URL``, ``COREIQ_SINK_SPLUNK_TOKEN``,
        optional ``COREIQ_SINK_SPLUNK_INDEX``,
        ``COREIQ_SINK_SPLUNK_BLOCK`` (default off).

    Microsoft Sentinel
        ``COREIQ_SINK_SENTINEL_ENDPOINT``, ``COREIQ_SINK_SENTINEL_RULE_ID``,
        ``COREIQ_SINK_SENTINEL_STREAM``,
        ``COREIQ_SINK_SENTINEL_BLOCK``.

    Google Chronicle
        ``COREIQ_SINK_CHRONICLE_CUSTOMER_ID``,
        ``COREIQ_SINK_CHRONICLE_LOG_TYPE``,
        ``COREIQ_SINK_CHRONICLE_SA_JSON`` (path to service-account JSON),
        ``COREIQ_SINK_CHRONICLE_BLOCK``.

    Datadog SIEM
        ``COREIQ_SINK_DATADOG_API_KEY``,
        optional ``COREIQ_SINK_DATADOG_SITE`` (default ``datadoghq.com``),
        ``COREIQ_SINK_DATADOG_BLOCK``.

    Elastic
        ``COREIQ_SINK_ELASTIC_URL``, ``COREIQ_SINK_ELASTIC_INDEX``,
        optional ``COREIQ_SINK_ELASTIC_API_KEY``,
        ``COREIQ_SINK_ELASTIC_BLOCK``.

    S3 WORM
        ``COREIQ_SINK_S3_BUCKET``, optional ``COREIQ_SINK_S3_REGION``,
        ``COREIQ_SINK_S3_PREFIX``,
        ``COREIQ_SINK_S3_BLOCK``.
    """
    env = os.environ.get
    registered: List[str] = []

    def _try(name: str, builder):
        try:
            sink = builder()
        except Exception as exc:
            logger.warning("Audit sink %s skipped — config invalid: %s", name, exc)
            return
        router.add(sink, block_on_failure=_block(name))
        registered.append(name)

    if env("COREIQ_SINK_SPLUNK_URL") and env("COREIQ_SINK_SPLUNK_TOKEN"):
        from .splunk_hec import SplunkHECSink
        _try("SPLUNK", lambda: SplunkHECSink(
            url=env("COREIQ_SINK_SPLUNK_URL"),
            token=env("COREIQ_SINK_SPLUNK_TOKEN"),
            index=env("COREIQ_SINK_SPLUNK_INDEX"),
        ))

    if (env("COREIQ_SINK_SENTINEL_ENDPOINT") and
            env("COREIQ_SINK_SENTINEL_RULE_ID") and
            env("COREIQ_SINK_SENTINEL_STREAM")):
        from .sentinel import SentinelSink
        _try("SENTINEL", lambda: SentinelSink(
            endpoint=env("COREIQ_SINK_SENTINEL_ENDPOINT"),
            rule_id=env("COREIQ_SINK_SENTINEL_RULE_ID"),
            stream_name=env("COREIQ_SINK_SENTINEL_STREAM"),
        ))

    if (env("COREIQ_SINK_CHRONICLE_CUSTOMER_ID") and
            env("COREIQ_SINK_CHRONICLE_LOG_TYPE") and
            env("COREIQ_SINK_CHRONICLE_SA_JSON")):
        from .chronicle import ChronicleSink
        _try("CHRONICLE", lambda: ChronicleSink(
            customer_id=env("COREIQ_SINK_CHRONICLE_CUSTOMER_ID"),
            log_type=env("COREIQ_SINK_CHRONICLE_LOG_TYPE"),
            service_account_json_path=env("COREIQ_SINK_CHRONICLE_SA_JSON"),
        ))

    if env("COREIQ_SINK_DATADOG_API_KEY"):
        from .datadog_siem import DatadogSIEMSink
        _try("DATADOG", lambda: DatadogSIEMSink(
            api_key=env("COREIQ_SINK_DATADOG_API_KEY"),
            site=env("COREIQ_SINK_DATADOG_SITE", "datadoghq.com"),
        ))

    if env("COREIQ_SINK_ELASTIC_URL") and env("COREIQ_SINK_ELASTIC_INDEX"):
        from .elastic import ElasticSink
        _try("ELASTIC", lambda: ElasticSink(
            url=env("COREIQ_SINK_ELASTIC_URL"),
            index=env("COREIQ_SINK_ELASTIC_INDEX"),
            api_key=env("COREIQ_SINK_ELASTIC_API_KEY"),
        ))

    if env("COREIQ_SINK_S3_BUCKET"):
        from .s3_worm import S3WORMSink
        _try("S3", lambda: S3WORMSink(
            bucket=env("COREIQ_SINK_S3_BUCKET"),
            region=env("COREIQ_SINK_S3_REGION"),
            key_prefix=env("COREIQ_SINK_S3_PREFIX", ""),
        ))

    if registered:
        logger.info("Audit sinks registered from env: %s", ", ".join(registered))
