"""Model Risk Register — EU AI Act risk tier classification and sign-off tracking.

Provides a `ModelRiskRegister` for cataloguing AI models with risk tier
assignments (per EU AI Act Annex III / Article 6), sign-off tracking,
and a human-readable risk summary.

Usage::

    from coreiq.governance import ModelRiskRegister, RiskTier

    register = ModelRiskRegister()
    register.add_model(
        model_id="gpt-4o",
        provider="openai",
        risk_tier=RiskTier.LIMITED,
        use_case="customer support chatbot",
        approved_by="compliance_officer@acme.com",
    )
    entry = register.get("gpt-4o")
    summary = register.risk_summary()
"""
from __future__ import annotations

import json
import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger("coreiq.governance.model_risk")


class RiskTier(str, Enum):
    """EU AI Act risk classification tiers.

    PROHIBITED — Unacceptable risk (Art. 5 prohibited practices).
    HIGH — High-risk AI systems (Annex III categories).
    LIMITED — Limited risk with transparency obligations.
    MINIMAL — Minimal or no risk — most AI applications.
    UNCLASSIFIED — Not yet assessed.
    """
    PROHIBITED = "prohibited"
    HIGH = "high"
    LIMITED = "limited"
    MINIMAL = "minimal"
    UNCLASSIFIED = "unclassified"


# EU AI Act Annex III high-risk categories (simplified)
HIGH_RISK_USE_CASES = {
    "biometric identification",
    "critical infrastructure",
    "education assessment",
    "employment selection",
    "essential services",
    "law enforcement",
    "migration border control",
    "administration of justice",
}


@dataclass
class ModelRiskEntry:
    """A single model entry in the risk register."""
    model_id: str
    provider: str
    risk_tier: RiskTier
    use_case: str
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    notes: str = ""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_approved(self) -> bool:
        return self.approved_by is not None

    def requires_hitl(self) -> bool:
        """High-risk models should have HITL review enabled."""
        return self.risk_tier in (RiskTier.HIGH, RiskTier.PROHIBITED)


class ModelRiskRegister:
    """In-memory + DB-backed registry of model risk assessments.

    Thread-safe. Persists entries to the `model_risk_register` table
    in the CoreIQ database.
    """

    def __init__(self):
        self._entries: Dict[str, ModelRiskEntry] = {}
        self._lock = threading.Lock()
        self._load_from_db()

    def _load_from_db(self) -> None:
        """Load existing entries from the DB on startup."""
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            rows = conn.execute("SELECT * FROM model_risk_register").fetchall()
            with self._lock:
                for row in rows:
                    meta = json.loads(row["metadata_json"]) if row["metadata_json"] else {}
                    entry = ModelRiskEntry(
                        id=row["id"],
                        model_id=row["model_id"],
                        provider=row["provider"],
                        risk_tier=RiskTier(row["risk_tier"]),
                        use_case=row["use_case"],
                        approved_by=row["approved_by"],
                        approved_at=row["approved_at"],
                        notes=row["notes"] or "",
                        created_at=row["created_at"],
                        metadata=meta,
                    )
                    self._entries[entry.model_id] = entry
        except Exception as exc:
            logger.debug("Could not load model risk register from DB: %s", exc)

    def _persist(self, entry: ModelRiskEntry) -> None:
        """Persist a single entry to the DB. Caller should NOT hold the lock."""
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            conn.execute(
                """INSERT OR REPLACE INTO model_risk_register
                   (id, model_id, provider, risk_tier, use_case,
                    approved_by, approved_at, notes, metadata_json, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    entry.id, entry.model_id, entry.provider, entry.risk_tier.value,
                    entry.use_case, entry.approved_by, entry.approved_at,
                    entry.notes, json.dumps(entry.metadata) if entry.metadata else None,
                    entry.created_at,
                ),
            )
            conn.commit()
        except Exception as exc:
            logger.debug("Could not persist model risk entry: %s", exc)

    def add_model(
        self,
        model_id: str,
        provider: str,
        risk_tier: RiskTier | str = RiskTier.UNCLASSIFIED,
        use_case: str = "",
        approved_by: Optional[str] = None,
        notes: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ModelRiskEntry:
        """Add or update a model in the risk register.

        Args:
            model_id: The model identifier (e.g. "gpt-4o", "claude-3-5-sonnet").
            provider: Provider name (e.g. "openai", "anthropic").
            risk_tier: EU AI Act risk tier.
            use_case: Description of intended use.
            approved_by: Email / ID of approving compliance officer.
            notes: Free-form notes.
            metadata: Additional metadata dict.

        Returns:
            The created or updated ModelRiskEntry.
        """
        if isinstance(risk_tier, str):
            risk_tier = RiskTier(risk_tier)

        with self._lock:
            existing = self._entries.get(model_id)
            now = datetime.now(timezone.utc).isoformat()
            entry = ModelRiskEntry(
                id=existing.id if existing else str(uuid.uuid4()),
                model_id=model_id,
                provider=provider,
                risk_tier=risk_tier,
                use_case=use_case,
                approved_by=approved_by,
                approved_at=now if approved_by else None,
                notes=notes,
                created_at=existing.created_at if existing else now,
                metadata=metadata or {},
            )
            self._entries[model_id] = entry

        self._persist(entry)

        if risk_tier == RiskTier.HIGH:
            logger.warning(
                "HIGH-RISK model registered: %s (%s) — use case: %s. "
                "Ensure HITL and compliance review are configured.",
                model_id, provider, use_case,
            )
        return entry

    def get(self, model_id: str) -> Optional[ModelRiskEntry]:
        """Return the risk entry for a model, or None."""
        with self._lock:
            return self._entries.get(model_id)

    def classify(self, model_id: str, use_case: str) -> RiskTier:
        """Auto-classify a model based on use case keywords.

        Heuristic only — compliance officer approval is still required for HIGH.
        """
        use_case_lower = use_case.lower()
        for keyword in HIGH_RISK_USE_CASES:
            if keyword in use_case_lower:
                return RiskTier.HIGH
        return RiskTier.LIMITED

    def list_entries(self, risk_tier: Optional[RiskTier] = None) -> List[ModelRiskEntry]:
        """Return all entries, optionally filtered by tier."""
        with self._lock:
            entries = list(self._entries.values())
        if risk_tier is not None:
            entries = [e for e in entries if e.risk_tier == risk_tier]
        return entries

    def approve(self, model_id: str, approved_by: str) -> Optional[ModelRiskEntry]:
        """Record compliance sign-off for a model."""
        with self._lock:
            entry = self._entries.get(model_id)
            if entry is None:
                return None
            entry.approved_by = approved_by
            entry.approved_at = datetime.now(timezone.utc).isoformat()

        self._persist(entry)
        logger.info("Model %s approved by %s", model_id, approved_by)
        return entry

    def risk_summary(self) -> Dict[str, Any]:
        """Return a summary of the risk register."""
        with self._lock:
            entries = list(self._entries.values())
        by_tier: Dict[str, int] = {}
        for e in entries:
            by_tier[e.risk_tier.value] = by_tier.get(e.risk_tier.value, 0) + 1
        unapproved_high = [
            e.model_id for e in entries
            if e.risk_tier == RiskTier.HIGH and not e.is_approved()
        ]
        return {
            "total_models": len(entries),
            "by_tier": by_tier,
            "unapproved_high_risk": unapproved_high,
            "requires_attention": len(unapproved_high) > 0,
        }


# Module-level singleton
_register: Optional[ModelRiskRegister] = None
_register_lock = threading.Lock()


def get_model_risk_register() -> ModelRiskRegister:
    """Return the module-level ModelRiskRegister."""
    global _register
    if _register is None:
        with _register_lock:
            if _register is None:
                _register = ModelRiskRegister()
    return _register
