"""Human-in-the-Loop (HITL) Workflow Engine.

Provides a `@hitl_gate` decorator that intercepts high-stakes LLM calls
when a risk score exceeds a configurable threshold. Intercepted calls are
paused and queued for human review. Execution resumes on approval or falls
back to a default value on timeout.

Usage::

    import coreiq

    @coreiq.hitl_gate(risk_threshold=0.8, timeout_s=300, fallback="I cannot assist with that.")
    async def sensitive_llm_call(prompt: str) -> str:
        return await llm.complete(prompt)

    # With a custom risk scorer
    @coreiq.hitl_gate(
        risk_threshold=0.7,
        risk_scorer=my_risk_fn,  # (prompt, *args, **kwargs) -> float
        timeout_s=120,
        fallback="Request requires human review.",
    )
    async def high_stakes_call(prompt: str) -> str: ...
"""
from __future__ import annotations

import asyncio
import functools
import json
import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("coreiq.governance.hitl")


@dataclass
class HITLQueueItem:
    """An item waiting for human review."""
    id: str
    trace_id: Optional[str]
    function_name: str
    risk_score: float
    payload: Dict[str, Any]     # serialised call args
    status: str                 # "pending" | "approved" | "rejected" | "timed_out"
    reviewer_id: Optional[str] = None
    decision: Optional[str] = None
    decision_at: Optional[str] = None
    fallback_used: bool = False
    timeout_s: int = 300
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Internal: asyncio.Event signalling that a decision has been made
    _decision_event: Optional[asyncio.Event] = field(default=None, repr=False, compare=False)


class HITLWorkflow:
    """In-memory + DB-backed HITL review queue.

    Thread-safe and async-safe. Pending items block the calling coroutine
    until a reviewer approves / rejects them, or the timeout elapses.
    """

    def __init__(self):
        self._queue: Dict[str, HITLQueueItem] = {}
        self._lock = threading.Lock()

    def enqueue(
        self,
        *,
        function_name: str,
        risk_score: float,
        payload: Dict[str, Any],
        timeout_s: int = 300,
        trace_id: Optional[str] = None,
        decision_event: Optional[asyncio.Event] = None,
    ) -> HITLQueueItem:
        """Add a call to the review queue and persist it to the DB."""
        item = HITLQueueItem(
            id=str(uuid.uuid4()),
            trace_id=trace_id,
            function_name=function_name,
            risk_score=risk_score,
            payload=payload,
            status="pending",
            timeout_s=timeout_s,
        )
        with self._lock:
            # Attach the event under the lock so decide() never sees a None
            # _decision_event on a queued item.
            item._decision_event = decision_event
            self._queue[item.id] = item
        self._persist(item)
        logger.warning(
            "HITL: '%s' intercepted (risk=%.2f). Item %s queued for human review.",
            function_name, risk_score, item.id,
        )
        return item

    def decide(
        self,
        item_id: str,
        decision: str,
        reviewer_id: Optional[str] = None,
    ) -> Optional[HITLQueueItem]:
        """Record a human decision (approved/rejected) and unblock the waiting coroutine.

        Args:
            item_id: The HITL queue item ID.
            decision: "approved" or "rejected".
            reviewer_id: Optional reviewer identifier for audit.

        Returns:
            Updated HITLQueueItem, or None if not found.
        """
        with self._lock:
            item = self._queue.get(item_id)
            if item is None:
                return None
            item.decision = decision
            item.reviewer_id = reviewer_id
            item.decision_at = datetime.now(timezone.utc).isoformat()
            item.status = decision  # "approved" or "rejected"
            event = item._decision_event
        # Persist outside the lock (I/O should not block other lock holders)
        self._persist(item)
        # Signal the waiting coroutine; read event ref captured under the lock
        if event is not None:
            event.set()
        return item

    def list_pending(self) -> List[HITLQueueItem]:
        """Return all items currently in pending status."""
        with self._lock:
            return [i for i in self._queue.values() if i.status == "pending"]

    def get(self, item_id: str) -> Optional[HITLQueueItem]:
        with self._lock:
            # Try in-memory first, then DB
            item = self._queue.get(item_id)
        if item is None:
            item = self._load_from_db(item_id)
        return item

    def _load_from_db(self, item_id: str) -> Optional[HITLQueueItem]:
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            row = conn.execute(
                "SELECT * FROM hitl_queue WHERE id = ?", (item_id,)
            ).fetchone()
            if row is None:
                return None
            return HITLQueueItem(
                id=row["id"],
                trace_id=row["trace_id"],
                function_name=row["function_name"],
                risk_score=row["risk_score"],
                payload=json.loads(row["payload_json"]) if row["payload_json"] else {},
                status=row["status"],
                reviewer_id=row["reviewer_id"],
                decision=row["decision"],
                decision_at=row["decision_at"],
                fallback_used=bool(row["fallback_used"]),
                timeout_s=row["timeout_s"] or 300,
                created_at=row["created_at"],
            )
        except Exception as exc:
            logger.debug("Could not load HITL item from DB: %s", exc)
            return None

    def _persist(self, item: HITLQueueItem) -> None:
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            conn.execute(
                """INSERT OR REPLACE INTO hitl_queue
                   (id, trace_id, function_name, risk_score, payload_json,
                    status, reviewer_id, decision, decision_at,
                    fallback_used, timeout_s, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    item.id, item.trace_id, item.function_name, item.risk_score,
                    json.dumps(item.payload, default=str),
                    item.status, item.reviewer_id, item.decision, item.decision_at,
                    int(item.fallback_used), item.timeout_s, item.created_at,
                ),
            )
            conn.commit()
        except Exception as exc:
            logger.debug("Could not persist HITL item: %s", exc)


# ---------------------------------------------------------------------------
# Module-level workflow singleton
# ---------------------------------------------------------------------------

_workflow: Optional[HITLWorkflow] = None
_workflow_lock = threading.Lock()


def get_hitl_workflow() -> HITLWorkflow:
    global _workflow
    if _workflow is None:
        with _workflow_lock:
            if _workflow is None:
                _workflow = HITLWorkflow()
    return _workflow


# ---------------------------------------------------------------------------
# Default risk scorer (can be replaced via hitl_gate risk_scorer=)
# ---------------------------------------------------------------------------

def _default_risk_scorer(prompt: str, *args, **kwargs) -> float:
    """Heuristic risk scorer based on prompt length and keywords.

    This is intentionally simple — replace with a real classifier in production.
    """
    HIGH_RISK_KEYWORDS = {
        "delete", "remove", "destroy", "override", "bypass", "admin",
        "root", "sudo", "payment", "ssn", "password", "credential",
    }
    text = str(prompt).lower()
    score = 0.0
    # Keyword hits increase risk
    hits = sum(1 for kw in HIGH_RISK_KEYWORDS if kw in text)
    score += min(hits * 0.15, 0.6)
    # Very long prompts slightly increase risk
    if len(text) > 2000:
        score += 0.1
    return min(score, 1.0)


# ---------------------------------------------------------------------------
# @hitl_gate decorator
# ---------------------------------------------------------------------------

def hitl_gate(
    risk_threshold: float = 0.8,
    timeout_s: int = 300,
    fallback: Any = None,
    risk_scorer: Optional[Callable] = None,
):
    """Decorator that intercepts high-risk LLM calls for human review.

    When the risk score for a call exceeds `risk_threshold`, the call is
    queued in the HITL review queue. The coroutine waits up to `timeout_s`
    seconds for a human decision:
    - Approved → original function executes and result is returned
    - Rejected or timeout → `fallback` value is returned immediately

    Args:
        risk_threshold: Risk score above which the call is intercepted (0.0–1.0).
        timeout_s: Seconds to wait for a human decision before using fallback.
        fallback: Value returned when the call is rejected or times out.
        risk_scorer: Callable(prompt, *args, **kwargs) → float. If None, uses
            the built-in heuristic scorer.

    Example::

        @coreiq.hitl_gate(risk_threshold=0.8, timeout_s=300, fallback="Unavailable")
        async def process(prompt: str) -> str:
            return await llm.complete(prompt)
    """
    scorer = risk_scorer or _default_risk_scorer

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Score risk using first positional arg as prompt if available
            prompt = args[0] if args else str(kwargs)
            try:
                risk_score = float(scorer(prompt, *args[1:], **kwargs))
            except Exception:
                risk_score = 0.0

            if risk_score < risk_threshold:
                return await func(*args, **kwargs)

            # Intercept — queue for human review
            from ..tracing import get_current_trace_id
            trace_id = get_current_trace_id()

            workflow = get_hitl_workflow()
            # Create the event BEFORE enqueue so it is already attached when
            # the item becomes visible in the queue.  This eliminates the race
            # where decide() could fire between enqueue() returning and the
            # old code assigning item._decision_event.
            decision_event = asyncio.Event()
            item = workflow.enqueue(
                function_name=func.__qualname__,
                risk_score=risk_score,
                payload={"args": [str(a) for a in args], "kwargs": {k: str(v) for k, v in kwargs.items()}},
                timeout_s=timeout_s,
                trace_id=trace_id,
                decision_event=decision_event,
            )

            try:
                # Wait for human decision or timeout
                await asyncio.wait_for(decision_event.wait(), timeout=timeout_s)
            except asyncio.TimeoutError:
                item.status = "timed_out"
                item.fallback_used = True
                workflow._persist(item)
                logger.warning(
                    "HITL timeout for item %s (%s) — using fallback",
                    item.id, func.__qualname__,
                )
                return fallback

            if item.decision == "approved":
                logger.info("HITL item %s approved by %s — executing", item.id, item.reviewer_id)
                return await func(*args, **kwargs)
            else:
                item.fallback_used = True
                workflow._persist(item)
                logger.info("HITL item %s rejected — using fallback", item.id)
                return fallback

        return wrapper
    return decorator
