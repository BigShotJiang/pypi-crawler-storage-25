"""Multimodal payload validation policy.

Multimodal requests (image / audio / video) bypass the text-only
prompt-injection / PII detectors used elsewhere in the pipeline. This
module enforces hard limits on:

- MIME types (allow-list per modality)
- Per-attachment size (decoded byte length)
- Aggregate request size (sum of all attachments)
- Count of attachments per request

Configure via env::

    COREIQ_MULTIMODAL_MAX_ATTACHMENTS=10
    COREIQ_MULTIMODAL_MAX_BYTES=20971520           # 20 MiB total
    COREIQ_MULTIMODAL_MAX_PER_ATTACHMENT=5242880   # 5 MiB each
    COREIQ_MULTIMODAL_ALLOWED_MIME=image/png,image/jpeg,audio/wav,audio/mp3

Returns a :class:`MultimodalDecision` — never raises. Callers turn a
``denied=True`` decision into a 4xx response.
"""
from __future__ import annotations

import base64
import os
from dataclasses import dataclass, field
from typing import Any, Iterable

_DEFAULT_ALLOWED = {
    "image/png", "image/jpeg", "image/webp", "image/gif",
    "audio/wav", "audio/mp3", "audio/mpeg", "audio/ogg",
    "video/mp4", "video/webm",
}


def _allowed_mimes() -> set[str]:
    raw = os.environ.get("COREIQ_MULTIMODAL_ALLOWED_MIME", "").strip()
    if not raw:
        return set(_DEFAULT_ALLOWED)
    return {m.strip().lower() for m in raw.split(",") if m.strip()}


def _max_attachments() -> int:
    return int(os.environ.get("COREIQ_MULTIMODAL_MAX_ATTACHMENTS", "10"))


def _max_total_bytes() -> int:
    return int(os.environ.get("COREIQ_MULTIMODAL_MAX_BYTES", str(20 * 1024 * 1024)))


def _max_per_attachment() -> int:
    return int(os.environ.get("COREIQ_MULTIMODAL_MAX_PER_ATTACHMENT", str(5 * 1024 * 1024)))


@dataclass
class Attachment:
    mime: str
    decoded_bytes: int


@dataclass
class MultimodalDecision:
    denied: bool = False
    reason: str | None = None
    attachments: list[Attachment] = field(default_factory=list)
    total_bytes: int = 0


def _decode_size(data_url_or_b64: str) -> int:
    """Return the decoded byte length of a base64 / data: URL value."""
    if data_url_or_b64.startswith("data:"):
        _, _, payload = data_url_or_b64.partition(",")
    else:
        payload = data_url_or_b64
    try:
        return len(base64.b64decode(payload, validate=False))
    except Exception:
        # Not base64 — assume raw and use string length as a coarse proxy.
        return len(payload)


def _extract_mime(item: dict[str, Any]) -> str:
    """Best-effort MIME extraction from a multimodal content part."""
    mt = (item.get("mime_type") or item.get("media_type") or "").lower()
    if mt:
        return mt
    url = item.get("image_url") or item.get("audio_url") or item.get("video_url") or ""
    if isinstance(url, dict):
        url = url.get("url", "")
    if isinstance(url, str) and url.startswith("data:"):
        head, _, _ = url[5:].partition(";")
        return head.lower()
    return ""


def evaluate(content_parts: Iterable[dict[str, Any]]) -> MultimodalDecision:
    """Validate a list of multimodal content parts.

    ``content_parts`` are OpenAI-format chat content items, e.g.::

        [
            {"type": "text", "text": "..."},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64,..."}},
        ]
    """
    decision = MultimodalDecision()
    allowed = _allowed_mimes()
    max_count = _max_attachments()
    max_total = _max_total_bytes()
    max_per = _max_per_attachment()

    count = 0
    for part in content_parts:
        ptype = (part.get("type") or "").lower()
        if ptype not in ("image_url", "audio_url", "video_url", "input_image", "input_audio"):
            continue
        count += 1
        if count > max_count:
            decision.denied = True
            decision.reason = f"too many attachments (max {max_count})"
            return decision
        mime = _extract_mime(part)
        if not mime:
            decision.denied = True
            decision.reason = "missing or unrecognised MIME type"
            return decision
        if mime not in allowed:
            decision.denied = True
            decision.reason = f"MIME type {mime!r} not in allow-list"
            return decision
        url = part.get("image_url") or part.get("audio_url") or part.get("video_url") or ""
        if isinstance(url, dict):
            url = url.get("url", "")
        size = _decode_size(url) if isinstance(url, str) else 0
        if size > max_per:
            decision.denied = True
            decision.reason = f"attachment {size} bytes exceeds per-attachment cap {max_per}"
            return decision
        decision.attachments.append(Attachment(mime=mime, decoded_bytes=size))
        decision.total_bytes += size
        if decision.total_bytes > max_total:
            decision.denied = True
            decision.reason = f"aggregate size {decision.total_bytes} exceeds cap {max_total}"
            return decision

    return decision
