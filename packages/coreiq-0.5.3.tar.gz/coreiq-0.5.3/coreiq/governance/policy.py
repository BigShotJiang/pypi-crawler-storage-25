"""Policy enforcement — allowlists, denylists, cost limits, and versioning."""
from __future__ import annotations

import json
import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ..exceptions import CoreIQError

logger = logging.getLogger("coreiq.governance.policy")


@dataclass
class PolicyViolation(CoreIQError):
    rule: str
    detail: str

    def __str__(self) -> str:
        return f"Policy violation [{self.rule}]: {self.detail}"


@dataclass
class Policy:
    name: str
    allowed_models: list[str] = field(default_factory=list)
    denied_models: list[str] = field(default_factory=list)
    max_input_tokens: Optional[int] = None
    max_output_tokens: Optional[int] = None
    max_cost_usd: Optional[float] = None
    allowed_providers: list[str] = field(default_factory=list)

    def check_model(self, model: str) -> None:
        """Raise PolicyViolation if model is not permitted."""
        if self.denied_models and model in self.denied_models:
            raise PolicyViolation("denied_model", f"Model '{model}' is on the denylist")
        if self.allowed_models and model not in self.allowed_models:
            raise PolicyViolation("allowed_model", f"Model '{model}' is not on the allowlist")

    def check_tokens(self, input_tok: int, output_tok: int) -> None:
        """Raise PolicyViolation if token counts exceed limits."""
        if self.max_input_tokens and input_tok > self.max_input_tokens:
            raise PolicyViolation(
                "max_input_tokens",
                f"Input {input_tok} exceeds limit {self.max_input_tokens}",
            )
        if self.max_output_tokens and output_tok > self.max_output_tokens:
            raise PolicyViolation(
                "max_output_tokens",
                f"Output {output_tok} exceeds limit {self.max_output_tokens}",
            )

    def check_provider(self, provider: str) -> None:
        """Raise PolicyViolation if provider is not permitted."""
        if self.allowed_providers and provider not in self.allowed_providers:
            raise PolicyViolation(
                "allowed_provider",
                f"Provider '{provider}' is not on the allowlist",
            )


# Module-level default policy (permissive — override via set_default_policy)
_default_policy: Optional[Policy] = None


def get_default_policy() -> Optional[Policy]:
    return _default_policy


def set_default_policy(policy: Optional[Policy]) -> None:
    global _default_policy
    _default_policy = policy


# ---------------------------------------------------------------------------
# Policy Versioning — diff tracking and approval workflow
# ---------------------------------------------------------------------------


@dataclass
class PolicyVersion:
    """A versioned snapshot of a Policy with approval tracking."""
    id: str
    policy_name: str
    version: int
    config: Dict[str, Any]          # Policy fields as dict
    diff: Optional[Dict[str, Any]]  # Changed fields vs previous version
    status: str                     # "draft" | "approved" | "rejected" | "active"
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    created_by: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_policy(self) -> Policy:
        """Reconstruct a Policy object from this version's config."""
        cfg = self.config
        return Policy(
            name=cfg.get("name", self.policy_name),
            allowed_models=cfg.get("allowed_models", []),
            denied_models=cfg.get("denied_models", []),
            max_input_tokens=cfg.get("max_input_tokens"),
            max_output_tokens=cfg.get("max_output_tokens"),
            max_cost_usd=cfg.get("max_cost_usd"),
            allowed_providers=cfg.get("allowed_providers", []),
        )


class PolicyVersionManager:
    """Manages versioned policy documents with diff + approval workflow.

    Thread-safe. Persists to the ``policy_versions`` DB table.
    """

    def __init__(self) -> None:
        self._versions: Dict[str, List[PolicyVersion]] = {}  # policy_name → versions
        self._lock = threading.Lock()
        self._load_from_db()

    def _load_from_db(self) -> None:
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            rows = conn.execute(
                "SELECT * FROM policy_versions ORDER BY policy_name, version ASC"
            ).fetchall()
            with self._lock:
                for row in rows:
                    pv = PolicyVersion(
                        id=row["id"],
                        policy_name=row["policy_name"],
                        version=row["version"],
                        config=json.loads(row["config_json"]) if row["config_json"] else {},
                        diff=json.loads(row["diff_json"]) if row["diff_json"] else None,
                        status=row["status"] or "draft",
                        approved_by=row["approved_by"],
                        approved_at=row["approved_at"],
                        created_by=row["created_by"],
                        created_at=row["created_at"],
                    )
                    self._versions.setdefault(pv.policy_name, []).append(pv)
        except Exception as exc:
            logger.debug("Could not load policy versions from DB: %s", exc)

    def _persist(self, pv: PolicyVersion) -> None:
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            conn.execute(
                """INSERT OR REPLACE INTO policy_versions
                   (id, policy_name, version, config_json, diff_json,
                    status, approved_by, approved_at, created_by, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    pv.id, pv.policy_name, pv.version,
                    json.dumps(pv.config), json.dumps(pv.diff) if pv.diff else None,
                    pv.status, pv.approved_by, pv.approved_at, pv.created_by, pv.created_at,
                ),
            )
            conn.commit()
        except Exception as exc:
            logger.debug("Could not persist policy version: %s", exc)

    def create_version(
        self,
        policy: Policy,
        created_by: Optional[str] = None,
    ) -> PolicyVersion:
        """Create a new version of a policy, computing a diff vs the previous version."""
        policy_name = policy.name
        with self._lock:
            versions = self._versions.get(policy_name, [])
            version_number = len(versions) + 1
            prev = versions[-1] if versions else None

        config = {
            "name": policy.name,
            "allowed_models": policy.allowed_models,
            "denied_models": policy.denied_models,
            "max_input_tokens": policy.max_input_tokens,
            "max_output_tokens": policy.max_output_tokens,
            "max_cost_usd": policy.max_cost_usd,
            "allowed_providers": policy.allowed_providers,
        }

        # Compute diff vs previous version
        diff = None
        if prev is not None:
            diff = {}
            for k, v in config.items():
                if prev.config.get(k) != v:
                    diff[k] = {"from": prev.config.get(k), "to": v}

        pv = PolicyVersion(
            id=str(uuid.uuid4()),
            policy_name=policy_name,
            version=version_number,
            config=config,
            diff=diff,
            status="draft",
            created_by=created_by,
        )
        with self._lock:
            self._versions.setdefault(policy_name, []).append(pv)

        self._persist(pv)
        return pv

    def approve(self, policy_name: str, version: int, approved_by: str) -> Optional[PolicyVersion]:
        """Approve a policy version, promoting it to active."""
        with self._lock:
            versions = self._versions.get(policy_name, [])
            pv = next((v for v in versions if v.version == version), None)
            if pv is None:
                return None
            pv.status = "approved"
            pv.approved_by = approved_by
            pv.approved_at = datetime.now(timezone.utc).isoformat()
            # Mark previous active as superseded
            for v in versions:
                if v.version != version and v.status == "active":
                    v.status = "superseded"
                    self._persist(v)
            pv.status = "active"

        self._persist(pv)
        logger.info("Policy %s v%d approved by %s", policy_name, version, approved_by)
        return pv

    def get_active(self, policy_name: str) -> Optional[PolicyVersion]:
        """Return the currently active version for a policy."""
        with self._lock:
            versions = self._versions.get(policy_name, [])
            return next((v for v in reversed(versions) if v.status == "active"), None)

    def get_history(self, policy_name: str) -> List[PolicyVersion]:
        """Return all versions for a policy, newest first."""
        with self._lock:
            return list(reversed(self._versions.get(policy_name, [])))


# Module-level singleton
_version_manager: Optional[PolicyVersionManager] = None
_vm_lock = threading.Lock()


def get_policy_version_manager() -> PolicyVersionManager:
    global _version_manager
    if _version_manager is None:
        with _vm_lock:
            if _version_manager is None:
                _version_manager = PolicyVersionManager()
    return _version_manager
