from __future__ import annotations
from dataclasses import dataclass


@dataclass
class MemoryAuditResult:
    total_entries: int
    pii_detected: int
    pii_entries: list[dict]  # [{"index": i, "types": [...], "redacted": str}]
    policy_violations: int
    entries_to_purge: list[str]


class MemoryGovernanceEngine:
    """PII detection and governance for memory/knowledge stores.

    Scans memory entries (RAG chunks, conversation history, agent memory)
    for PII and policy violations. Uses coreiq's existing security modules.
    """

    def scan_memory_store(self, entries: list[dict], text_field: str = "content") -> MemoryAuditResult:
        """Scan a list of memory entries for PII.

        entries: list of dicts, each with at least a text_field key
        """
        from ..security.pii import detect_pii

        pii_entries = []
        for i, entry in enumerate(entries):
            text = entry.get(text_field, "")
            if not text:
                continue
            try:
                detected = detect_pii(text)
                if detected:
                    pii_entries.append({
                        "index": i,
                        "id": entry.get("id", str(i)),
                        "types": detected,
                        "text_snippet": text[:100],
                    })
            except Exception:
                pass

        return MemoryAuditResult(
            total_entries=len(entries),
            pii_detected=len(pii_entries),
            pii_entries=pii_entries,
            policy_violations=len(pii_entries),  # PII = policy violation
            entries_to_purge=[e["id"] for e in pii_entries],
        )

    def redact_memory_entry(self, entry: dict, text_field: str = "content") -> dict:
        """Redact PII from a single memory entry."""
        from ..security.pii import redact_pii
        text = entry.get(text_field, "")
        if not text:
            return entry
        try:
            redacted = redact_pii(text)
            return {**entry, text_field: redacted, "_pii_redacted": True}
        except Exception:
            return entry

    def retention_check(self, entries: list[dict], max_age_days: int = 90,
                        ts_field: str = "created_at") -> list[str]:
        """Return IDs of entries older than max_age_days."""
        from datetime import datetime, timezone, timedelta
        cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
        to_purge = []
        for entry in entries:
            ts_str = entry.get(ts_field)
            if not ts_str:
                continue
            try:
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                if ts < cutoff:
                    to_purge.append(entry.get("id", ""))
            except Exception:
                pass
        return [x for x in to_purge if x]
