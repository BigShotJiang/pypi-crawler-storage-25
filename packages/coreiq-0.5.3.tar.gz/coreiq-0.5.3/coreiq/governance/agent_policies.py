"""Agent Governance Framework — tool policies, budgets, delegation, loop detection.

Provides runtime governance for autonomous AI agents:

- **Tool call policies**: Max calls per session, approval requirements, blocked tools
- **Agent budgets**: Per-agent cost/session limits with alerts
- **Delegation policies**: Allowed delegation targets, max depth, approval gates
- **Loop detection**: Circuit breaker for runaway agent loops
- **Reasoning trace**: Require chain-of-thought logging for audit

Usage::

    policy = AgentPolicyEngine()
    policy.set_tool_policy("support-bot",
        max_calls_per_session=20,
        require_approval_for=["send_email", "database_write"],
        blocked_tools=["shell_exec"])

    policy.set_agent_budget("support-bot",
        max_cost_per_session=2.00,
        max_cost_per_day=100.00,
        alert_at=0.8)

    policy.set_delegation_policy("support-bot",
        can_delegate_to=["knowledge-bot"],
        max_delegation_depth=3)

    policy.set_loop_policy("support-bot",
        max_iterations=50,
        cost_circuit_breaker=5.00)
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ═══════════════════════════════════════════════════════════════════════════════
# Data Models
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ToolPolicy:
    """Policy governing which tools an agent can call."""
    agent_id: str
    max_calls_per_session: int = 100
    require_approval_for: List[str] = field(default_factory=list)
    blocked_tools: List[str] = field(default_factory=list)
    allowed_tools: Optional[List[str]] = None  # None = all allowed (except blocked)
    rate_limit_per_minute: int = 60

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "max_calls_per_session": self.max_calls_per_session,
            "require_approval_for": self.require_approval_for,
            "blocked_tools": self.blocked_tools,
            "allowed_tools": self.allowed_tools,
            "rate_limit_per_minute": self.rate_limit_per_minute,
        }


@dataclass
class AgentBudget:
    """Budget constraints for an agent."""
    agent_id: str
    max_cost_per_session: float = 5.00
    max_cost_per_day: float = 100.00
    max_tokens_per_session: int = 500000
    alert_at: float = 0.8  # Alert when spending hits this fraction

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "max_cost_per_session": self.max_cost_per_session,
            "max_cost_per_day": self.max_cost_per_day,
            "max_tokens_per_session": self.max_tokens_per_session,
            "alert_at": self.alert_at,
        }


@dataclass
class DelegationPolicy:
    """Policy governing agent-to-agent delegation."""
    agent_id: str
    can_delegate_to: List[str] = field(default_factory=list)
    max_delegation_depth: int = 5
    require_human_approval_after_depth: int = 3

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "can_delegate_to": self.can_delegate_to,
            "max_delegation_depth": self.max_delegation_depth,
            "require_human_approval_after_depth": self.require_human_approval_after_depth,
        }


@dataclass
class LoopPolicy:
    """Policy for detecting and stopping runaway agent loops."""
    agent_id: str
    max_iterations: int = 50
    cost_circuit_breaker: float = 5.00
    time_circuit_breaker_seconds: int = 300  # 5 min max
    similarity_threshold: float = 0.9  # Detect repeated actions

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "max_iterations": self.max_iterations,
            "cost_circuit_breaker": self.cost_circuit_breaker,
            "time_circuit_breaker_seconds": self.time_circuit_breaker_seconds,
            "similarity_threshold": self.similarity_threshold,
        }


@dataclass
class HITLItem:
    """A pending human-in-the-loop approval request."""
    item_id: str
    session_id: str
    agent_id: str
    tool_name: str
    context: Dict[str, Any]
    status: str = "pending"   # pending | approved | rejected
    created_at: str = field(default_factory=_now)
    resolved_at: Optional[str] = None
    reviewer: Optional[str] = None
    resolution_note: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "item_id": self.item_id,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "tool_name": self.tool_name,
            "context": self.context,
            "status": self.status,
            "created_at": self.created_at,
            "resolved_at": self.resolved_at,
            "reviewer": self.reviewer,
            "resolution_note": self.resolution_note,
        }


@dataclass
class AgentSession:
    """Runtime tracking for an active agent session."""
    session_id: str
    agent_id: str
    tool_calls: int = 0
    tool_call_log: List[Dict[str, Any]] = field(default_factory=list)
    total_cost: float = 0.0
    total_tokens: int = 0
    iterations: int = 0
    delegation_depth: int = 0
    start_time: float = field(default_factory=time.time)
    recent_actions: List[str] = field(default_factory=list)
    reasoning_trace: List[Dict[str, Any]] = field(default_factory=list)
    require_reasoning_trace: bool = False
    alerts: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "tool_calls": self.tool_calls,
            "total_cost": round(self.total_cost, 4),
            "total_tokens": self.total_tokens,
            "iterations": self.iterations,
            "delegation_depth": self.delegation_depth,
            "elapsed_seconds": round(time.time() - self.start_time, 1),
            "alerts": self.alerts,
            "reasoning_trace_entries": len(self.reasoning_trace),
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Policy Violations
# ═══════════════════════════════════════════════════════════════════════════════

class AgentPolicyViolation(Exception):
    """Raised when an agent violates a governance policy."""
    def __init__(self, agent_id: str, policy_type: str, message: str):
        self.agent_id = agent_id
        self.policy_type = policy_type
        super().__init__(f"[{agent_id}] {policy_type}: {message}")


# ═══════════════════════════════════════════════════════════════════════════════
# Agent Policy Engine
# ═══════════════════════════════════════════════════════════════════════════════

class AgentPolicyEngine:
    """Central engine for agent governance policies.

    Manages tool policies, budgets, delegation rules, and loop detection
    for autonomous AI agents. Thread-safe.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._tool_policies: Dict[str, ToolPolicy] = {}
        self._budgets: Dict[str, AgentBudget] = {}
        self._delegation_policies: Dict[str, DelegationPolicy] = {}
        self._loop_policies: Dict[str, LoopPolicy] = {}
        self._sessions: Dict[str, AgentSession] = {}
        self._reasoning_required: set[str] = set()
        self._daily_costs: Dict[str, float] = {}  # agent_id -> today's spend
        self._daily_reset_date: str = ""
        self._hitl_queue: Dict[str, HITLItem] = {}  # item_id -> HITLItem

    # ------------------------------------------------------------------
    # Policy Configuration
    # ------------------------------------------------------------------

    def set_tool_policy(
        self, agent_id: str, *,
        max_calls_per_session: int = 100,
        require_approval_for: Optional[List[str]] = None,
        blocked_tools: Optional[List[str]] = None,
        allowed_tools: Optional[List[str]] = None,
        rate_limit_per_minute: int = 60,
    ) -> ToolPolicy:
        """Set tool call policy for an agent."""
        policy = ToolPolicy(
            agent_id=agent_id,
            max_calls_per_session=max_calls_per_session,
            require_approval_for=require_approval_for or [],
            blocked_tools=blocked_tools or [],
            allowed_tools=allowed_tools,
            rate_limit_per_minute=rate_limit_per_minute,
        )
        with self._lock:
            self._tool_policies[agent_id] = policy
        logger.info("Tool policy set for agent '%s'", agent_id)
        return policy

    def set_agent_budget(
        self, agent_id: str, *,
        max_cost_per_session: float = 5.00,
        max_cost_per_day: float = 100.00,
        max_tokens_per_session: int = 500000,
        alert_at: float = 0.8,
    ) -> AgentBudget:
        """Set budget constraints for an agent."""
        budget = AgentBudget(
            agent_id=agent_id,
            max_cost_per_session=max_cost_per_session,
            max_cost_per_day=max_cost_per_day,
            max_tokens_per_session=max_tokens_per_session,
            alert_at=alert_at,
        )
        with self._lock:
            self._budgets[agent_id] = budget
        logger.info("Budget set for agent '%s': $%.2f/session, $%.2f/day",
                     agent_id, max_cost_per_session, max_cost_per_day)
        return budget

    def set_delegation_policy(
        self, agent_id: str, *,
        can_delegate_to: Optional[List[str]] = None,
        max_delegation_depth: int = 5,
        require_human_approval_after_depth: int = 3,
    ) -> DelegationPolicy:
        """Set delegation policy for an agent."""
        policy = DelegationPolicy(
            agent_id=agent_id,
            can_delegate_to=can_delegate_to or [],
            max_delegation_depth=max_delegation_depth,
            require_human_approval_after_depth=require_human_approval_after_depth,
        )
        with self._lock:
            self._delegation_policies[agent_id] = policy
        return policy

    def set_loop_policy(
        self, agent_id: str, *,
        max_iterations: int = 50,
        cost_circuit_breaker: float = 5.00,
        time_circuit_breaker_seconds: int = 300,
    ) -> LoopPolicy:
        """Set loop detection policy for an agent."""
        policy = LoopPolicy(
            agent_id=agent_id,
            max_iterations=max_iterations,
            cost_circuit_breaker=cost_circuit_breaker,
            time_circuit_breaker_seconds=time_circuit_breaker_seconds,
        )
        with self._lock:
            self._loop_policies[agent_id] = policy
        return policy

    def require_reasoning_trace(self, agent_id: str) -> None:
        """Require chain-of-thought logging for an agent."""
        with self._lock:
            self._reasoning_required.add(agent_id)

    # ------------------------------------------------------------------
    # Session Management
    # ------------------------------------------------------------------

    def start_session(self, agent_id: str, delegation_depth: int = 0) -> AgentSession:
        """Start a new governance-tracked agent session."""
        session_id = str(uuid.uuid4())
        session = AgentSession(
            session_id=session_id,
            agent_id=agent_id,
            delegation_depth=delegation_depth,
            require_reasoning_trace=agent_id in self._reasoning_required,
        )
        with self._lock:
            self._sessions[session_id] = session
        return session

    def get_session(self, session_id: str) -> Optional[AgentSession]:
        return self._sessions.get(session_id)

    def end_session(self, session_id: str) -> Optional[AgentSession]:
        """End a session and return its final state."""
        with self._lock:
            return self._sessions.pop(session_id, None)

    # ------------------------------------------------------------------
    # Runtime Checks
    # ------------------------------------------------------------------

    def check_tool_call(
        self, session_id: str, tool_name: str,
    ) -> Dict[str, Any]:
        """Check if a tool call is allowed under the agent's policy.

        Returns a dict with:
        - allowed: bool
        - requires_approval: bool
        - reason: str (if blocked)

        Raises AgentPolicyViolation if hard-blocked.
        """
        session = self._sessions.get(session_id)
        if session is None:
            return {"allowed": True, "requires_approval": False, "reason": ""}

        policy = self._tool_policies.get(session.agent_id)
        if policy is None:
            session.tool_calls += 1
            session.tool_call_log.append({"tool": tool_name, "ts": _now(), "allowed": True})
            return {"allowed": True, "requires_approval": False, "reason": ""}

        # Check blocked tools
        if tool_name in policy.blocked_tools:
            session.tool_call_log.append({"tool": tool_name, "ts": _now(), "allowed": False, "reason": "blocked"})
            raise AgentPolicyViolation(
                session.agent_id, "tool_policy",
                f"Tool '{tool_name}' is blocked for this agent",
            )

        # Check allowed tools (allowlist)
        if policy.allowed_tools is not None and tool_name not in policy.allowed_tools:
            session.tool_call_log.append({"tool": tool_name, "ts": _now(), "allowed": False, "reason": "not_in_allowlist"})
            raise AgentPolicyViolation(
                session.agent_id, "tool_policy",
                f"Tool '{tool_name}' is not in the allowed list",
            )

        # Check max calls
        if session.tool_calls >= policy.max_calls_per_session:
            raise AgentPolicyViolation(
                session.agent_id, "tool_policy",
                f"Max tool calls ({policy.max_calls_per_session}) exceeded",
            )

        session.tool_calls += 1
        requires_approval = tool_name in policy.require_approval_for
        session.tool_call_log.append({
            "tool": tool_name, "ts": _now(), "allowed": True,
            "requires_approval": requires_approval,
        })

        return {
            "allowed": True,
            "requires_approval": requires_approval,
            "reason": f"Tool '{tool_name}' requires human approval" if requires_approval else "",
        }

    def check_budget(
        self, session_id: str, cost_delta: float = 0.0, tokens_delta: int = 0,
    ) -> Dict[str, Any]:
        """Check and update budget for an agent session.

        Raises AgentPolicyViolation if budget exceeded.
        """
        session = self._sessions.get(session_id)
        if session is None:
            return {"within_budget": True, "alerts": []}

        budget = self._budgets.get(session.agent_id)
        if budget is None:
            session.total_cost += cost_delta
            session.total_tokens += tokens_delta
            return {"within_budget": True, "alerts": []}

        session.total_cost += cost_delta
        session.total_tokens += tokens_delta
        alerts = []

        # Check session cost
        if session.total_cost > budget.max_cost_per_session:
            raise AgentPolicyViolation(
                session.agent_id, "budget",
                f"Session cost ${session.total_cost:.2f} exceeds limit ${budget.max_cost_per_session:.2f}",
            )

        # Check session tokens
        if session.total_tokens > budget.max_tokens_per_session:
            raise AgentPolicyViolation(
                session.agent_id, "budget",
                f"Session tokens {session.total_tokens} exceeds limit {budget.max_tokens_per_session}",
            )

        # Check daily cost
        self._ensure_daily_reset()
        daily = self._daily_costs.get(session.agent_id, 0.0) + cost_delta
        self._daily_costs[session.agent_id] = daily
        if daily > budget.max_cost_per_day:
            raise AgentPolicyViolation(
                session.agent_id, "budget",
                f"Daily cost ${daily:.2f} exceeds limit ${budget.max_cost_per_day:.2f}",
            )

        # Alert check
        session_ratio = session.total_cost / budget.max_cost_per_session if budget.max_cost_per_session > 0 else 0
        if session_ratio >= budget.alert_at:
            alert = f"Agent '{session.agent_id}' at {session_ratio:.0%} of session budget"
            alerts.append(alert)
            if alert not in session.alerts:
                session.alerts.append(alert)
                logger.warning(alert)

        return {"within_budget": True, "alerts": alerts}

    def check_delegation(
        self, session_id: str, target_agent: str,
    ) -> Dict[str, Any]:
        """Check if delegation to a target agent is allowed.

        Returns dict with allowed, requires_approval, reason.
        Raises AgentPolicyViolation if blocked.
        """
        session = self._sessions.get(session_id)
        if session is None:
            return {"allowed": True, "requires_approval": False, "reason": ""}

        policy = self._delegation_policies.get(session.agent_id)
        if policy is None:
            return {"allowed": True, "requires_approval": False, "reason": ""}

        # Check depth limit
        if session.delegation_depth >= policy.max_delegation_depth:
            raise AgentPolicyViolation(
                session.agent_id, "delegation",
                f"Max delegation depth ({policy.max_delegation_depth}) exceeded",
            )

        # Check allowed targets
        if policy.can_delegate_to and target_agent not in policy.can_delegate_to:
            raise AgentPolicyViolation(
                session.agent_id, "delegation",
                f"Agent '{session.agent_id}' is not allowed to delegate to '{target_agent}'",
            )

        requires_approval = session.delegation_depth >= policy.require_human_approval_after_depth
        return {
            "allowed": True,
            "requires_approval": requires_approval,
            "reason": f"Depth {session.delegation_depth + 1} requires human approval" if requires_approval else "",
        }

    def check_loop(self, session_id: str) -> Dict[str, Any]:
        """Check for loop/runaway conditions.

        Raises AgentPolicyViolation if circuit breaker triggered.
        """
        session = self._sessions.get(session_id)
        if session is None:
            return {"safe": True, "reason": ""}

        session.iterations += 1
        policy = self._loop_policies.get(session.agent_id)
        if policy is None:
            return {"safe": True, "reason": ""}

        # Check iteration limit
        if session.iterations > policy.max_iterations:
            raise AgentPolicyViolation(
                session.agent_id, "loop_detection",
                f"Max iterations ({policy.max_iterations}) exceeded — possible infinite loop",
            )

        # Check cost circuit breaker
        if session.total_cost > policy.cost_circuit_breaker:
            raise AgentPolicyViolation(
                session.agent_id, "loop_detection",
                f"Cost circuit breaker ${policy.cost_circuit_breaker:.2f} exceeded "
                f"(current: ${session.total_cost:.2f})",
            )

        # Check time circuit breaker
        elapsed = time.time() - session.start_time
        if elapsed > policy.time_circuit_breaker_seconds:
            raise AgentPolicyViolation(
                session.agent_id, "loop_detection",
                f"Time circuit breaker ({policy.time_circuit_breaker_seconds}s) exceeded "
                f"(elapsed: {elapsed:.0f}s)",
            )

        return {"safe": True, "iterations": session.iterations, "reason": ""}

    def log_reasoning(self, session_id: str, step: str, reasoning: str) -> None:
        """Log a reasoning trace entry for audit."""
        session = self._sessions.get(session_id)
        if session is None:
            return
        session.reasoning_trace.append({
            "step": step,
            "reasoning": reasoning,
            "ts": _now(),
        })

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_policies(self, agent_id: str) -> Dict[str, Any]:
        """Get all policies for an agent."""
        return {
            "agent_id": agent_id,
            "tool_policy": self._tool_policies.get(agent_id, ToolPolicy(agent_id=agent_id)).to_dict(),
            "budget": self._budgets.get(agent_id, AgentBudget(agent_id=agent_id)).to_dict(),
            "delegation_policy": self._delegation_policies.get(agent_id, DelegationPolicy(agent_id=agent_id)).to_dict(),
            "loop_policy": self._loop_policies.get(agent_id, LoopPolicy(agent_id=agent_id)).to_dict(),
            "reasoning_trace_required": agent_id in self._reasoning_required,
        }

    def list_sessions(self) -> List[Dict[str, Any]]:
        return [s.to_dict() for s in self._sessions.values()]

    # ------------------------------------------------------------------
    # Human-in-the-Loop (HITL) Queue
    # ------------------------------------------------------------------

    def enqueue_hitl(
        self,
        session_id: str,
        tool_name: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> HITLItem:
        """Enqueue a tool call for human approval.

        Called when check_tool_call returns requires_approval=True and the
        agent wants to surface the request for a human reviewer.
        """
        session = self._sessions.get(session_id)
        agent_id = session.agent_id if session else "unknown"
        item = HITLItem(
            item_id=str(uuid.uuid4()),
            session_id=session_id,
            agent_id=agent_id,
            tool_name=tool_name,
            context=context or {},
        )
        with self._lock:
            self._hitl_queue[item.item_id] = item
        logger.info("HITL item %s enqueued: agent=%s tool=%s", item.item_id, agent_id, tool_name)
        return item

    def list_hitl_queue(self, status: Optional[str] = None) -> List[HITLItem]:
        """Return all HITL items, optionally filtered by status."""
        items = list(self._hitl_queue.values())
        if status:
            items = [i for i in items if i.status == status]
        return sorted(items, key=lambda i: i.created_at, reverse=True)

    def resolve_hitl(
        self,
        item_id: str,
        approved: bool,
        reviewer: str = "human",
        note: str = "",
    ) -> Optional[HITLItem]:
        """Approve or reject a pending HITL item."""
        with self._lock:
            item = self._hitl_queue.get(item_id)
            if item is None:
                return None
            item.status = "approved" if approved else "rejected"
            item.resolved_at = _now()
            item.reviewer = reviewer
            item.resolution_note = note
        logger.info(
            "HITL item %s resolved: %s by %s",
            item_id, item.status, reviewer,
        )
        return item

    def _ensure_daily_reset(self):
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if today != self._daily_reset_date:
            self._daily_costs.clear()
            self._daily_reset_date = today
