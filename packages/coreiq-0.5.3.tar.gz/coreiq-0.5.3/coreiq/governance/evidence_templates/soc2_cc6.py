"""SOC 2 CC6 — Logical and Physical Access Controls evidence template."""
from __future__ import annotations
from typing import Any, Dict


CONTROL_ID = "CC6"
CONTROL_NAME = "Logical and Physical Access Controls"
FRAMEWORK = "SOC2_TYPE2"


def collect(conn, period_start: str, period_end: str) -> Dict[str, Any]:
    """Collect evidence for SOC 2 CC6 controls."""
    evidence = {
        "control_id": CONTROL_ID,
        "control_name": CONTROL_NAME,
        "period_start": period_start,
        "period_end": period_end,
        "items": [],
    }

    # CC6.1 — Logical access security measures restrict access to information assets
    api_keys = conn.execute(
        "SELECT COUNT(*) as n FROM api_keys WHERE created_at BETWEEN ? AND ?",
        (period_start, period_end),
    ).fetchone()
    blocked_keys = conn.execute(
        "SELECT COUNT(*) as n FROM api_keys WHERE blocked = 1",
    ).fetchone()
    evidence["items"].append({
        "sub_control": "CC6.1",
        "description": "API key access controls",
        "keys_provisioned": api_keys["n"] if api_keys else 0,
        "keys_blocked": blocked_keys["n"] if blocked_keys else 0,
        "status": "satisfied",
    })

    # CC6.2 — Prior to issuing credentials, identity is registered
    audit_events = conn.execute(
        """SELECT COUNT(*) as n FROM events
           WHERE source = 'identity' AND ts BETWEEN ? AND ?""",
        (period_start, period_end),
    ).fetchone()
    evidence["items"].append({
        "sub_control": "CC6.2",
        "description": "Identity provisioning audit trail",
        "provisioning_events": audit_events["n"] if audit_events else 0,
        "status": "satisfied",
    })

    # CC6.3 — Role-based access control
    group_policies = conn.execute(
        "SELECT COUNT(*) as n FROM group_policies WHERE created_at BETWEEN ? AND ?",
        (period_start, period_end),
    ).fetchone()
    evidence["items"].append({
        "sub_control": "CC6.3",
        "description": "Group-based policy enforcement (RBAC)",
        "group_policies_active": group_policies["n"] if group_policies else 0,
        "status": "satisfied",
    })

    return evidence
