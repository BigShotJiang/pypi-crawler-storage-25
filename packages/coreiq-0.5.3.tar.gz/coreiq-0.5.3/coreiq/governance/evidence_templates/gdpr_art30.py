"""GDPR Article 30 — Records of Processing Activities evidence template."""
from __future__ import annotations
from typing import Any, Dict


CONTROL_ID = "GDPR_ART30"
CONTROL_NAME = "Records of Processing Activities (Article 30)"
FRAMEWORK = "GDPR"


def collect(conn, period_start: str, period_end: str) -> Dict[str, Any]:
    """Collect evidence for GDPR Article 30 compliance."""
    evidence = {
        "control_id": CONTROL_ID,
        "control_name": CONTROL_NAME,
        "period_start": period_start,
        "period_end": period_end,
        "items": [],
    }

    # Art 30(1)(a) — Name and contact details of the controller
    evidence["items"].append({
        "article": "Art 30(1)(a)",
        "description": "Controller identification",
        "system": "CoreIQ AI Observability Platform",
        "status": "requires_configuration",
        "note": "Set controller_name and contact in coreiq.toml [compliance.gdpr]",
    })

    # Art 30(1)(b) — Purposes of processing
    tenant_count = conn.execute(
        "SELECT COUNT(DISTINCT tenant_id) as n FROM traces WHERE ts BETWEEN ? AND ?",
        (period_start, period_end),
    ).fetchone()
    evidence["items"].append({
        "article": "Art 30(1)(b)",
        "description": "Purposes of processing",
        "purposes": ["AI inference logging", "observability", "quality evaluation"],
        "tenants_processed": tenant_count["n"] if tenant_count else 0,
        "status": "satisfied",
    })

    # Art 30(1)(c) — Categories of data subjects
    evidence["items"].append({
        "article": "Art 30(1)(c)",
        "description": "Categories of data subjects",
        "categories": ["API users", "end-users of integrated AI applications"],
        "status": "satisfied",
    })

    # Art 30(1)(d) — Categories of personal data
    evidence["items"].append({
        "article": "Art 30(1)(d)",
        "description": "Categories of personal data",
        "categories": ["user_id (pseudonymous)", "session_id", "tenant_id"],
        "pseudonymisation": True,
        "status": "satisfied",
    })

    # Art 30(1)(e) — Recipients of personal data
    evidence["items"].append({
        "article": "Art 30(1)(e)",
        "description": "Recipients / processors",
        "recipients": ["LLM providers (OpenAI, Anthropic, etc.) for inference"],
        "status": "requires_review",
        "note": "Review providers list for sub-processor agreements",
    })

    # Art 30(1)(f) — Transfers to third countries
    try:
        transfer_events = conn.execute(
            """SELECT COUNT(*) as n FROM events
               WHERE source = 'data_residency' AND ts BETWEEN ? AND ?""",
            (period_start, period_end),
        ).fetchone()
        transfer_count = transfer_events["n"] if transfer_events else 0
    except Exception:
        transfer_count = 0
    evidence["items"].append({
        "article": "Art 30(1)(f)",
        "description": "Third country transfer records",
        "transfer_events_logged": transfer_count,
        "status": "satisfied",
    })

    # Art 30(1)(g) — Retention periods
    evidence["items"].append({
        "article": "Art 30(1)(g)",
        "description": "Data retention schedule",
        "retention_policy": {
            "traces": "90 days",
            "feedback": "365 days",
            "events": "30 days",
            "audit_chain": "indefinite (legal requirement)",
        },
        "status": "satisfied",
    })

    return evidence
