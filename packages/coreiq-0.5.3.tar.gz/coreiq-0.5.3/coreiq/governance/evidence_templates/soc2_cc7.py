"""SOC 2 CC7 — System Operations evidence template."""
from __future__ import annotations
from typing import Any, Dict


CONTROL_ID = "CC7"
CONTROL_NAME = "System Operations"
FRAMEWORK = "SOC2_TYPE2"


def collect(conn, period_start: str, period_end: str) -> Dict[str, Any]:
    """Collect evidence for SOC 2 CC7 controls."""
    evidence = {
        "control_id": CONTROL_ID,
        "control_name": CONTROL_NAME,
        "period_start": period_start,
        "period_end": period_end,
        "items": [],
    }

    # CC7.1 — Detection and monitoring of vulnerabilities
    error_events = conn.execute(
        """SELECT COUNT(*) as n FROM events
           WHERE level IN ('error', 'critical') AND ts BETWEEN ? AND ?""",
        (period_start, period_end),
    ).fetchone()
    evidence["items"].append({
        "sub_control": "CC7.1",
        "description": "Error and anomaly monitoring",
        "error_events": error_events["n"] if error_events else 0,
        "status": "satisfied",
    })

    # CC7.2 — Anomaly detection
    total_traces = conn.execute(
        "SELECT COUNT(*) as n FROM traces WHERE ts BETWEEN ? AND ?",
        (period_start, period_end),
    ).fetchone()
    error_traces = conn.execute(
        """SELECT COUNT(*) as n FROM traces
           WHERE finish_reason = 'error' AND ts BETWEEN ? AND ?""",
        (period_start, period_end),
    ).fetchone()
    n_total = total_traces["n"] if total_traces else 0
    n_errors = error_traces["n"] if error_traces else 0
    evidence["items"].append({
        "sub_control": "CC7.2",
        "description": "LLM request anomaly detection",
        "total_requests": n_total,
        "error_requests": n_errors,
        "error_rate": round(n_errors / n_total, 4) if n_total else 0,
        "status": "satisfied",
    })

    # CC7.3 — Incident response
    incident_events = conn.execute(
        """SELECT COUNT(*) as n FROM events
           WHERE level = 'critical' AND ts BETWEEN ? AND ?""",
        (period_start, period_end),
    ).fetchone()
    evidence["items"].append({
        "sub_control": "CC7.3",
        "description": "Critical incident tracking",
        "critical_incidents": incident_events["n"] if incident_events else 0,
        "status": "satisfied",
    })

    return evidence
