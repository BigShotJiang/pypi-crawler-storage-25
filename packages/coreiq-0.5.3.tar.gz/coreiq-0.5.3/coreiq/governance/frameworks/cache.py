"""Per-tenant cache for compliance control results.

- Adds the ``compliance_check_results`` table to
  :data:`coreiq.store.dialect.TABLES` so every storage backend treats it
  as a mutable / "current value" row (last write wins).
- :func:`compute_all` runs every registered control for a tenant, honoring
  :mod:`.overrides` and a simple TTL cache. ``force=True`` skips the cache.
- The DDL lives here (and is appended to by ``store.db.init_schema``) so
  the cache is self-contained; adding a new table is one edit.

Scheduled / background computation is intentionally NOT implemented —
MVP is on-demand only, triggered by the REST layer.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from ...store.dialect import TABLES, _replacing
from .base import Control, ControlContext, ControlResult
from .registry import REGISTRY

logger = logging.getLogger(__name__)

# Register the cache table with the dialect translator so every backend
# gets the correct engine + sort key. Match how routing_rules / group_budgets
# were registered by the parallel agent.
TABLES["compliance_check_results"] = {
    "pk": ["tenant_id", "control_id"],
    **_replacing(["tenant_id", "control_id"], "checked_at"),
}

# DDL appended by ``store.db.init_schema`` via :func:`_ddl_statements`.
_CACHE_DDL = [
    """CREATE TABLE IF NOT EXISTS compliance_check_results (
        tenant_id       TEXT NOT NULL,
        control_id      TEXT NOT NULL,
        status          TEXT NOT NULL,
        evidence_json   TEXT DEFAULT '{}',
        notes           TEXT DEFAULT '',
        computed_in_ms  INTEGER DEFAULT 0,
        checked_at      TEXT NOT NULL,
        PRIMARY KEY (tenant_id, control_id)
    )""",
    "CREATE INDEX IF NOT EXISTS idx_compliance_cache_tenant ON compliance_check_results(tenant_id)",
    "CREATE INDEX IF NOT EXISTS idx_compliance_cache_status ON compliance_check_results(status)",
]


def _ddl_statements() -> list:
    """Return the DDL statements for this module.

    ``store.db.init_schema`` calls this (via the sibling :mod:`.overrides`
    module) so we don't have to touch ``db.py`` each time we add a new
    compliance table.
    """
    return list(_CACHE_DDL)


# Default TTL for cached results (1 hour). Configurable per-call via
# ``compute_all(..., ttl_seconds=...)``.
DEFAULT_TTL_SECONDS = 3600


def _conn():
    from ...store.db import get_shared_connection
    return get_shared_connection()


def _parse_iso(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        # Handle trailing Z
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s)
    except Exception:
        return None


def _row_to_result(row) -> Optional[ControlResult]:
    if row is None:
        return None
    try:
        if isinstance(row, dict):
            status = row.get("status")
            evidence_json = row.get("evidence_json") or "{}"
            notes = row.get("notes") or ""
            computed_in_ms = row.get("computed_in_ms") or 0
            checked_at = row.get("checked_at") or ""
        else:
            try:
                seq = list(row)
            except Exception:
                return None
            if len(seq) < 7:
                return None
            _tid, _cid, status, evidence_json, notes, computed_in_ms, checked_at = seq[:7]
        try:
            evidence = json.loads(evidence_json) if evidence_json else {}
        except Exception:
            evidence = {}
        return ControlResult(
            status=str(status or "fail"),
            evidence=evidence if isinstance(evidence, dict) else {},
            checked_at=str(checked_at or ""),
            notes=str(notes or ""),
            computed_in_ms=int(computed_in_ms or 0),
        )
    except Exception:
        return None


def get_cached(tenant_id: str, control_id: str) -> Optional[ControlResult]:
    """Return the most recent cached result for a (tenant, control), or
    ``None`` if nothing is stored."""
    try:
        row = _conn().execute(
            "SELECT tenant_id, control_id, status, evidence_json, notes, "
            "computed_in_ms, checked_at FROM compliance_check_results "
            "WHERE tenant_id = ? AND control_id = ?",
            (tenant_id, control_id),
        ).fetchone()
        return _row_to_result(row)
    except Exception:
        return None


def _store_result(tenant_id: str, control_id: str, result: ControlResult) -> None:
    try:
        conn = _conn()
        conn.execute(
            "INSERT OR REPLACE INTO compliance_check_results"
            "(tenant_id, control_id, status, evidence_json, notes,"
            " computed_in_ms, checked_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                tenant_id,
                control_id,
                result.status,
                json.dumps(result.evidence, default=str),
                result.notes,
                int(result.computed_in_ms),
                result.checked_at or datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
    except Exception:
        logger.debug("failed to cache compliance result", exc_info=True)


def _is_fresh(result: ControlResult, ttl_seconds: int, now: datetime) -> bool:
    ts = _parse_iso(result.checked_at)
    if ts is None:
        return False
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return (now - ts) < timedelta(seconds=ttl_seconds)


def _run_single(
    ctx: ControlContext,
    control: Control,
) -> ControlResult:
    start = ctx.time_ms()
    try:
        result = control.check_fn(ctx)
    except Exception as exc:
        logger.exception("check_fn failed for control %s", control.id)
        return ControlResult(
            status="fail",
            evidence={"error": str(exc)},
            checked_at=ctx.now_iso(),
            notes="check_fn raised an exception",
            computed_in_ms=ctx.time_ms() - start,
        )
    # Ensure checked_at and computed_in_ms are populated.
    checked_at = result.checked_at or ctx.now_iso()
    computed_in_ms = result.computed_in_ms or (ctx.time_ms() - start)
    if result.checked_at and result.computed_in_ms:
        return result
    return ControlResult(
        status=result.status,
        evidence=result.evidence,
        checked_at=checked_at,
        notes=result.notes,
        computed_in_ms=computed_in_ms,
    )


def compute_all(
    tenant_id: str,
    force: bool = False,
    window_days: int = 14,
    ttl_seconds: int = DEFAULT_TTL_SECONDS,
) -> dict:
    """Run every registered control for ``tenant_id``.

    Returns a dict keyed by ``control_id``.

    - If an override exists for ``(tenant_id, control_id)`` (see
      :mod:`.overrides`), the override is used instead of running the check.
    - Otherwise: if a fresh cache entry exists and ``force`` is false,
      reuse it; else run ``control.check_fn``, cache the result, return it.
    """
    # Late import to avoid cycles — overrides depends on registry too.
    from .overrides import get_override

    ctx = ControlContext(tenant_id=tenant_id, window_days=window_days)
    now = ctx.now

    out: dict = {}
    for control in REGISTRY.all_controls():
        override = get_override(tenant_id, control.id)
        if override is not None:
            out[control.id] = override
            continue

        if not force:
            cached = get_cached(tenant_id, control.id)
            if cached is not None and _is_fresh(cached, ttl_seconds, now):
                out[control.id] = cached
                continue

        result = _run_single(ctx, control)
        _store_result(tenant_id, control.id, result)
        out[control.id] = result
    return out
