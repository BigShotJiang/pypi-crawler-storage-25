"""Per-tenant override store for compliance control results.

Some controls can't be derived from runtime data (physical security,
penetration-test attestations, vendor SOC 2 reports, etc.). Operators can
attest to those controls by storing an override, which
:func:`.cache.compute_all` consumes instead of running ``check_fn``.

Schema: ``tenant_compliance_overrides``
- Keyed on ``(tenant_id, control_id)``.
- ``status`` is one of the standard four: pass | warn | fail | not_applicable.
- ``expires_at`` lets overrides expire automatically (common for annual
  attestations).
- Registered in :data:`coreiq.store.dialect.TABLES` so every backend
  handles it correctly.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Optional

from ...store.dialect import TABLES, _replacing
from .base import ControlResult

logger = logging.getLogger(__name__)


TABLES["tenant_compliance_overrides"] = {
    "pk": ["tenant_id", "control_id"],
    **_replacing(["tenant_id", "control_id"], "updated_at"),
}


_OVERRIDES_DDL = [
    """CREATE TABLE IF NOT EXISTS tenant_compliance_overrides (
        tenant_id       TEXT NOT NULL,
        control_id      TEXT NOT NULL,
        status          TEXT NOT NULL,
        notes           TEXT DEFAULT '',
        evidence_json   TEXT DEFAULT '{}',
        set_by          TEXT DEFAULT '',
        expires_at      TEXT,
        created_at      TEXT,
        updated_at      TEXT,
        PRIMARY KEY (tenant_id, control_id)
    )""",
    "CREATE INDEX IF NOT EXISTS idx_compliance_overrides_tenant ON tenant_compliance_overrides(tenant_id)",
]


def _ddl_statements() -> list:
    return list(_OVERRIDES_DDL)


def _conn():
    from ...store.db import get_shared_connection
    return get_shared_connection()


def _parse_iso(s) -> Optional[datetime]:
    if not s:
        return None
    try:
        if isinstance(s, datetime):
            return s
        s = str(s)
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s)
    except Exception:
        return None


def _row_to_result(row) -> Optional[ControlResult]:
    if row is None:
        return None
    if isinstance(row, dict):
        status = row.get("status")
        notes = row.get("notes") or ""
        evidence_json = row.get("evidence_json") or "{}"
        expires_at = row.get("expires_at")
        updated_at = row.get("updated_at")
    else:
        # sqlite3.Row / list / tuple — all support positional indexing.
        try:
            seq = list(row)
        except Exception:
            return None
        if len(seq) < 9:
            return None
        _tid, _cid, status, notes, evidence_json, _set_by, expires_at, _created_at, updated_at = seq[:9]

    # Expiry check
    exp = _parse_iso(expires_at)
    if exp is not None:
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) >= exp:
            return None

    try:
        evidence = json.loads(evidence_json) if evidence_json else {}
    except Exception:
        evidence = {}
    if not isinstance(evidence, dict):
        evidence = {}
    evidence.setdefault("override", True)
    return ControlResult(
        status=str(status or "not_applicable"),
        evidence=evidence,
        checked_at=str(updated_at or ""),
        notes=f"[override] {notes}" if notes else "[override]",
        computed_in_ms=0,
    )


def get_override(tenant_id: str, control_id: str) -> Optional[ControlResult]:
    """Return the active override for a (tenant, control), or None."""
    try:
        row = _conn().fetchone(
            "SELECT tenant_id, control_id, status, notes, evidence_json, set_by,"
            " expires_at, created_at, updated_at FROM tenant_compliance_overrides"
            " WHERE tenant_id = ? AND control_id = ?",
            (tenant_id, control_id),
        )
        return _row_to_result(row)
    except Exception:
        return None


def set_override(
    tenant_id: str,
    control_id: str,
    status: str,
    notes: str = "",
    evidence: Optional[dict] = None,
    set_by: str = "",
    expires_at: Optional[str] = None,
) -> None:
    """Create or update an override. ``status`` must be one of
    ``pass|warn|fail|not_applicable``."""
    if status not in ("pass", "warn", "fail", "not_applicable"):
        raise ValueError(f"invalid status: {status!r}")
    now = datetime.now(timezone.utc).isoformat()
    try:
        conn = _conn()
        # Check if row already exists to preserve created_at
        existing = conn.fetchone(
            "SELECT created_at FROM tenant_compliance_overrides WHERE tenant_id = ? AND control_id = ?",
            (tenant_id, control_id),
        )
        created_at = now
        if existing is not None:
            if isinstance(existing, dict):
                created_at = existing.get("created_at") or now
            else:
                try:
                    created_at = list(existing)[0] or now
                except Exception:
                    created_at = now
        conn.execute(
            "INSERT OR REPLACE INTO tenant_compliance_overrides"
            "(tenant_id, control_id, status, notes, evidence_json, set_by, expires_at, created_at, updated_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                tenant_id,
                control_id,
                status,
                notes,
                json.dumps(evidence or {}, default=str),
                set_by,
                expires_at,
                created_at,
                now,
            ),
        )
        conn.commit()
    except Exception:
        logger.exception("failed to set compliance override")
        raise


def clear_override(tenant_id: str, control_id: str) -> None:
    try:
        conn = _conn()
        conn.execute(
            "DELETE FROM tenant_compliance_overrides WHERE tenant_id = ? AND control_id = ?",
            (tenant_id, control_id),
        )
        conn.commit()
    except Exception:
        logger.debug("failed to clear compliance override", exc_info=True)


def list_overrides(tenant_id: str) -> list:
    """Return all non-expired overrides for a tenant, as dicts."""
    out: list = []
    try:
        rows = _conn().fetchall(
            "SELECT tenant_id, control_id, status, notes, evidence_json, set_by,"
            " expires_at, created_at, updated_at FROM tenant_compliance_overrides"
            " WHERE tenant_id = ?",
            (tenant_id,),
        ) or []
    except Exception:
        return out
    for row in rows:
        if isinstance(row, dict):
            tid = row.get("tenant_id")
            cid = row.get("control_id")
            status = row.get("status")
            notes = row.get("notes") or ""
            evidence_json = row.get("evidence_json") or "{}"
            set_by = row.get("set_by") or ""
            expires_at = row.get("expires_at")
            created_at = row.get("created_at")
            updated_at = row.get("updated_at")
        else:
            try:
                seq = list(row)
            except Exception:
                continue
            if len(seq) < 9:
                continue
            tid, cid, status, notes, evidence_json, set_by, expires_at, created_at, updated_at = seq[:9]
        # Filter expired
        exp = _parse_iso(expires_at)
        if exp is not None:
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) >= exp:
                continue
        try:
            evidence = json.loads(evidence_json) if evidence_json else {}
        except Exception:
            evidence = {}
        out.append({
            "tenant_id": tid,
            "control_id": cid,
            "status": status,
            "notes": notes,
            "evidence": evidence if isinstance(evidence, dict) else {},
            "set_by": set_by,
            "expires_at": expires_at,
            "created_at": created_at,
            "updated_at": updated_at,
        })
    return out
