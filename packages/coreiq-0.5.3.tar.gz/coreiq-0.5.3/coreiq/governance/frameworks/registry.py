"""Registry and auto-discovery for compliance framework plugins.

Auto-discovery runs on first access via :meth:`FrameworkRegistry.discover_all`:

1. Walks ``coreiq.governance.frameworks.builtin.*`` and imports each module.
   Every builtin module registers its :class:`Framework` at import time.
2. Reads entry points in the ``coreiq.compliance_frameworks`` group (stdlib
   only — :mod:`importlib.metadata`) so third-party packages can ship their
   own frameworks without modifying CoreIQ.

Re-registration of a framework id is idempotent (no-op + debug log).
"""
from __future__ import annotations

import importlib
import logging
import pkgutil
import threading
from typing import Optional

from .base import Control, Framework

logger = logging.getLogger(__name__)


class FrameworkRegistry:
    """Process-wide registry of :class:`Framework` plugins."""

    def __init__(self) -> None:
        self._frameworks: dict = {}
        self._controls: dict = {}  # control_id -> Control (first wins)
        self._lock = threading.RLock()
        self._discovered = False

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, framework: Framework) -> None:
        with self._lock:
            existing = self._frameworks.get(framework.id)
            if existing is not None:
                logger.debug("framework %r already registered; ignoring", framework.id)
                return
            self._frameworks[framework.id] = framework
            for ctrl in framework.controls:
                # First control wins when the same id appears in multiple
                # frameworks via cross-mapping — all subsequent references
                # to the id pick up this canonical control definition.
                self._controls.setdefault(ctrl.id, ctrl)

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def all(self) -> list:
        with self._lock:
            return list(self._frameworks.values())

    def get(self, framework_id: str) -> Optional[Framework]:
        with self._lock:
            return self._frameworks.get(framework_id)

    def control(self, control_id: str) -> Optional[Control]:
        with self._lock:
            return self._controls.get(control_id)

    def all_controls(self) -> list:
        """All unique controls (dedup by id) across all frameworks."""
        with self._lock:
            return list(self._controls.values())

    def controls_for(self, framework_id: str) -> list:
        fw = self.get(framework_id)
        if fw is None:
            return []
        return list(fw.controls)

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def discover_builtin(self) -> None:
        """Import every module under ``coreiq.governance.frameworks.builtin``.

        Each module calls ``REGISTRY.register(...)`` at import time.
        """
        try:
            from . import builtin as builtin_pkg
        except Exception as exc:
            logger.debug("could not import builtin frameworks package: %s", exc)
            return
        for modinfo in pkgutil.iter_modules(builtin_pkg.__path__):
            if modinfo.name.startswith("_"):
                continue
            full = f"{builtin_pkg.__name__}.{modinfo.name}"
            try:
                importlib.import_module(full)
            except Exception:
                logger.exception("failed to import builtin framework %r", full)

    def discover_entry_points(self) -> None:
        """Load frameworks from the ``coreiq.compliance_frameworks`` entry
        point group (third-party pip packages)."""
        try:
            from importlib.metadata import entry_points
        except Exception:
            return
        try:
            eps = entry_points()
            group: list = []
            # Python 3.10+: entry_points() returns an EntryPoints object
            select = getattr(eps, "select", None)
            if callable(select):
                group = list(select(group="coreiq.compliance_frameworks"))
            else:
                group = list(eps.get("coreiq.compliance_frameworks", []))  # type: ignore[attr-defined]
        except Exception:
            group = []

        for ep in group:
            try:
                loaded = ep.load()
            except Exception:
                logger.exception("failed to load entry point %r", ep)
                continue
            # Entry point may point at a Framework instance or a callable
            # returning one.
            fw = loaded() if callable(loaded) and not isinstance(loaded, Framework) else loaded
            if isinstance(fw, Framework):
                self.register(fw)

    def discover_all(self, force: bool = False) -> None:
        """Run all discovery passes. Idempotent unless ``force=True``."""
        with self._lock:
            if self._discovered and not force:
                return
            self._discovered = True
        self.discover_builtin()
        self.discover_entry_points()


# Module-level singleton.
REGISTRY = FrameworkRegistry()
