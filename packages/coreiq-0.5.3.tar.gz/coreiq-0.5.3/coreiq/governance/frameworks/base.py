"""Core dataclasses for the compliance framework plugin system.

This module defines the primitive types every framework plugin speaks:

- :class:`Control` — a single audit control (id, importance, category,
  ``check_fn`` callable, cross-framework mappings, regulatory references).
- :class:`ControlContext` — the "world" a ``check_fn`` sees. Exposes safe
  helpers (``query_table``, ``count_table``, ``get_tenant_meta``,
  ``get_tenant_setting``) that funnel every read through
  :func:`coreiq.store.db.get_shared_connection` and the central
  :data:`coreiq.store.dialect.TABLES` registry — so the same checks run
  unchanged across SQLite / Postgres / MongoDB / ClickHouse.
- :class:`ControlResult` — the output of a ``check_fn``. Status is one of
  ``pass|warn|fail|not_applicable``. The legacy ``compliance_auto`` shim
  maps these to ``met|partial|not_met`` for backward compat.
- :class:`Framework` — the top-level plugin: name, version, regulator, and
  a tuple of :class:`Control` instances.

All dataclasses here are frozen so plugins are immutable after registration.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional


# --------------------------------------------------------------------------
# Dataclasses
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class ControlResult:
    """Output of a single ``Control.check_fn`` invocation."""
    status: str  # "pass" | "warn" | "fail" | "not_applicable"
    evidence: dict = field(default_factory=dict)
    checked_at: str = ""
    notes: str = ""
    computed_in_ms: int = 0

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "evidence": dict(self.evidence),
            "checked_at": self.checked_at,
            "notes": self.notes,
            "computed_in_ms": self.computed_in_ms,
        }


@dataclass(frozen=True)
class Control:
    """A single audit control within one or more compliance frameworks."""
    id: str
    name: str
    framework_ids: tuple
    category: str
    importance: str  # "critical" | "high" | "medium" | "low"
    description: str
    remediation_text: str
    check_fn: Callable[["ControlContext"], ControlResult]
    references: tuple = ()

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "framework_ids": list(self.framework_ids),
            "category": self.category,
            "importance": self.importance,
            "description": self.description,
            "remediation_text": self.remediation_text,
            "references": list(self.references),
        }


@dataclass(frozen=True)
class Framework:
    """A compliance framework plugin: metadata + a tuple of controls."""
    id: str
    name: str
    version: str
    regulator: str
    url: str
    controls: tuple

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "version": self.version,
            "regulator": self.regulator,
            "url": self.url,
            "control_count": len(self.controls),
            "controls": [c.to_dict() for c in self.controls],
        }


# --------------------------------------------------------------------------
# ControlContext — the safe data window handed to each check_fn
# --------------------------------------------------------------------------


class ControlContext:
    """Read-only view of a tenant's data for a single control evaluation.

    Every helper funnels through :func:`get_shared_connection` and only
    accepts table names listed in :data:`coreiq.store.dialect.TABLES` —
    arbitrary SQL is never permitted. This lets the same ``check_fn``
    run against any storage backend.
    """

    def __init__(
        self,
        tenant_id: str,
        window_days: int = 14,
        now: Optional[datetime] = None,
    ) -> None:
        self.tenant_id = tenant_id
        self.window_days = window_days
        self.now = now or datetime.now(timezone.utc)
        self._tenant_meta_cache: Optional[dict] = None

    # --------------- internal helpers ---------------

    @staticmethod
    def _allowed_tables() -> set:
        # Late import to avoid a circular dependency at module load time.
        from ...store.dialect import TABLES
        return set(TABLES.keys())

    @staticmethod
    def _safe_ident(name: str) -> bool:
        if not name:
            return False
        for ch in name:
            if not (ch.isalnum() or ch == "_"):
                return False
        return True

    def _conn(self):
        from ...store.db import get_shared_connection
        return get_shared_connection()

    def _build_where(
        self,
        filters: Optional[dict],
    ) -> tuple:
        """Return (where_sql, params). Only safe identifier keys allowed."""
        if not filters:
            return "", ()
        parts = []
        params: list = []
        for key, value in filters.items():
            if not self._safe_ident(key):
                raise ValueError(f"unsafe column name: {key!r}")
            parts.append(f"{key} = ?")
            params.append(value)
        return "WHERE " + " AND ".join(parts), tuple(params)

    # --------------- public API ---------------

    def query_table(
        self,
        table: str,
        filters: Optional[dict] = None,
        limit: int = 100,
        columns: str = "*",
    ) -> list:
        """Return rows from a whitelisted table. Raises ``ValueError`` for
        any table not listed in :data:`coreiq.store.dialect.TABLES`."""
        if table not in self._allowed_tables():
            raise ValueError(f"table {table!r} is not in the TABLES registry")
        if columns != "*":
            for col in [c.strip() for c in columns.split(",")]:
                if not self._safe_ident(col):
                    raise ValueError(f"unsafe column name: {col!r}")
        try:
            limit_i = max(1, int(limit))
        except (TypeError, ValueError):
            limit_i = 100
        where, params = self._build_where(filters)
        sql = f"SELECT {columns} FROM {table} {where} LIMIT {limit_i}"
        try:
            conn = self._conn()
            rows = conn.fetchall(sql, params)
            return list(rows or [])
        except Exception:
            return []

    def count_table(
        self,
        table: str,
        filters: Optional[dict] = None,
    ) -> int:
        """Return ``COUNT(*)`` for a whitelisted table."""
        if table not in self._allowed_tables():
            raise ValueError(f"table {table!r} is not in the TABLES registry")
        where, params = self._build_where(filters)
        sql = f"SELECT COUNT(*) FROM {table} {where}"
        try:
            conn = self._conn()
            row = conn.fetchone(sql, params)
            if row is None:
                return 0
            if isinstance(row, dict):
                # Postgres DictRow / Mongo etc.
                for v in row.values():
                    return int(v or 0)
                return 0
            # sqlite3.Row / list / tuple — all index positionally.
            try:
                return int(row[0] or 0)
            except Exception:
                try:
                    return int(list(row)[0] or 0)
                except Exception:
                    return 0
        except Exception:
            return 0

    def get_tenant_meta(self) -> dict:
        """Fetch the ``tenants`` row for ``self.tenant_id`` as a dict."""
        if self._tenant_meta_cache is not None:
            return self._tenant_meta_cache
        default = {"id": self.tenant_id, "name": "", "plan": "free", "settings": {}}
        try:
            conn = self._conn()
            row = conn.fetchone(
                "SELECT id, name, slug, plan, settings_json FROM tenants WHERE id = ?",
                (self.tenant_id,),
            )
            if row is None:
                self._tenant_meta_cache = default
                return default
            if isinstance(row, dict):
                meta = {
                    "id": row.get("id"),
                    "name": row.get("name"),
                    "slug": row.get("slug"),
                    "plan": row.get("plan") or "free",
                    "settings": _safe_json(row.get("settings_json")),
                }
            else:
                try:
                    seq = list(row)
                except Exception:
                    seq = []
                if len(seq) >= 5:
                    meta = {
                        "id": seq[0],
                        "name": seq[1],
                        "slug": seq[2],
                        "plan": seq[3] or "free",
                        "settings": _safe_json(seq[4]),
                    }
                else:
                    meta = default
            self._tenant_meta_cache = meta
            return meta
        except Exception:
            self._tenant_meta_cache = default
            return default

    def get_tenant_setting(self, key: str, default: Any = None) -> Any:
        """Read a single key from the tenant's ``settings_json`` column."""
        meta = self.get_tenant_meta()
        settings = meta.get("settings") or {}
        return settings.get(key, default)

    def time_ms(self) -> int:
        """Monotonic millisecond clock — used for ``computed_in_ms``."""
        return int(time.monotonic() * 1000)

    def now_iso(self) -> str:
        return self.now.isoformat()


def _safe_json(raw: Any) -> dict:
    if raw is None or raw == "":
        return {}
    if isinstance(raw, dict):
        return raw
    try:
        out = json.loads(raw)
        return out if isinstance(out, dict) else {}
    except Exception:
        return {}
