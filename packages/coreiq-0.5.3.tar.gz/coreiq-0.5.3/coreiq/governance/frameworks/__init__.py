"""Plugin-architecture compliance framework system.

This package exposes the primitive types plus the singleton
:data:`REGISTRY`. Auto-discovery of all 12 builtin frameworks
(and any third-party plugins registered via the
``coreiq.compliance_frameworks`` entry point group) runs on first
import and is idempotent.
"""
from __future__ import annotations

from .base import Control, ControlContext, ControlResult, Framework
from .registry import REGISTRY, FrameworkRegistry

# Kick off auto-discovery at import time (idempotent).
REGISTRY.discover_all()

__all__ = [
    "Control",
    "ControlContext",
    "ControlResult",
    "Framework",
    "FrameworkRegistry",
    "REGISTRY",
]
