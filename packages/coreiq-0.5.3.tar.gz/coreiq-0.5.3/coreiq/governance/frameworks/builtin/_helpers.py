"""Shared helpers used by builtin framework check functions.

Every helper takes a :class:`ControlContext` and queries real tenant data
via ``ctx.query_table`` / ``ctx.count_table`` / ``ctx.get_tenant_meta``.
Nothing in this module returns a hardcoded status.
"""
from __future__ import annotations

from ..base import ControlContext, ControlResult


def _tenant_filter(ctx: ControlContext, col: str = "tenant_id") -> dict:
    return {col: ctx.tenant_id}


def manual_control(notes: str = "requires manual verification") -> ControlResult:
    """Return a ``not_applicable`` result for controls that cannot be
    derived from runtime data. Operators should attest to these via the
    ``tenant_compliance_overrides`` table."""
    return ControlResult(
        status="not_applicable",
        evidence={"manual": True},
        notes=notes,
    )


def check_has_rows(
    ctx: ControlContext,
    table: str,
    min_rows: int = 1,
    scoped: bool = True,
    extra_filters: dict | None = None,
    pass_notes: str = "",
    fail_notes: str = "",
) -> ControlResult:
    """Pass if the table has at least ``min_rows`` tenant-scoped rows."""
    filters: dict = {}
    if scoped:
        filters.update(_tenant_filter(ctx))
    if extra_filters:
        filters.update(extra_filters)
    try:
        count = ctx.count_table(table, filters=filters)
    except ValueError:
        return manual_control(f"table {table!r} not provisioned in this backend")
    status = "pass" if count >= min_rows else ("warn" if count > 0 else "fail")
    return ControlResult(
        status=status,
        evidence={"table": table, "count": count, "threshold": min_rows, "filters": filters},
        notes=pass_notes if status == "pass" else fail_notes,
    )


def check_setting_true(
    ctx: ControlContext,
    key: str,
    pass_notes: str = "",
    fail_notes: str = "",
) -> ControlResult:
    """Pass if the tenant's ``settings_json[key]`` is truthy."""
    value = ctx.get_tenant_setting(key)
    status = "pass" if bool(value) else "warn"
    return ControlResult(
        status=status,
        evidence={"setting": key, "value": value, "tenant_id": ctx.tenant_id},
        notes=pass_notes if status == "pass" else fail_notes,
    )


def check_no_recent_critical(
    ctx: ControlContext,
    table: str = "security_violations",
    severity_field: str = "severity",
    severity: str = "critical",
) -> ControlResult:
    """Pass if the tenant has no rows in *table* matching ``severity``."""
    try:
        count = ctx.count_table(
            table,
            filters={"tenant_id": ctx.tenant_id, severity_field: severity},
        )
    except ValueError:
        return manual_control()
    status = "pass" if count == 0 else ("warn" if count < 5 else "fail")
    return ControlResult(
        status=status,
        evidence={"table": table, "severity": severity, "count": count},
        notes="no critical incidents" if status == "pass" else f"{count} critical events",
    )
