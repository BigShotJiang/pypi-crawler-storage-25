"""SOC 2 Type II — AICPA Trust Services Criteria 2017."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import (
    check_has_rows,
    check_no_recent_critical,
)


def _check_logical_access(ctx: ControlContext) -> ControlResult:
    # CC6.1 — logical access control.
    count = ctx.count_table("api_keys")
    has_rbac = ctx.count_table("users") > 0
    status = "pass" if (count > 0 and has_rbac) else ("warn" if count > 0 else "fail")
    return ControlResult(
        status=status,
        evidence={"api_keys": count, "users_defined": has_rbac},
        notes="Logical access is enforced via API keys + RBAC users",
    )


def _check_access_review(ctx: ControlContext) -> ControlResult:
    # CC6.2 — periodic access review.
    return check_has_rows(
        ctx,
        "users",
        min_rows=1,
        scoped=False,
        pass_notes="User registry populated for periodic review",
        fail_notes="No users in registry — access review cannot be performed",
    )


def _check_user_provisioning(ctx: ControlContext) -> ControlResult:
    # CC6.3 — provisioning/deprovisioning.
    active = ctx.count_table("api_keys")
    revoked = ctx.count_table("revoked_tokens", filters=None)
    status = "pass" if active > 0 else "warn"
    return ControlResult(
        status=status,
        evidence={"active_api_keys": active, "revoked_tokens": revoked},
        notes="Provisioning tracked via api_keys and revoked_tokens tables",
    )


def _check_encryption(ctx: ControlContext) -> ControlResult:
    # CC6.6/CC6.7 — encryption at rest + in transit.
    tls = ctx.get_tenant_setting("tls_enforced", True)
    status = "pass" if tls else "warn"
    return ControlResult(
        status=status,
        evidence={"tls_enforced": bool(tls), "at_rest": "AES-256 (storage backend native)"},
        notes="Encryption posture based on tenant settings",
    )


def _check_audit_logging(ctx: ControlContext) -> ControlResult:
    # CC7.1 — system monitoring.
    events = ctx.count_table("events")
    audit = ctx.count_table("audit_chain")
    status = "pass" if (events + audit) > 0 else "fail"
    return ControlResult(
        status=status,
        evidence={"events": events, "audit_chain_entries": audit},
        notes="Audit trail present" if status == "pass" else "No audit events recorded",
    )


def _check_incident_response(ctx: ControlContext) -> ControlResult:
    # CC7.2/CC7.3 — incident detection + response.
    return check_has_rows(
        ctx,
        "incidents",
        min_rows=0,
        extra_filters=None,
        pass_notes="Incident tracking is configured",
        fail_notes="",
    )


def _check_monitoring_anomalies(ctx: ControlContext) -> ControlResult:
    return check_no_recent_critical(ctx)


def _check_change_management(ctx: ControlContext) -> ControlResult:
    # CC8.1 — change management via prompt registry + deploy history.
    versions = ctx.count_table("prompt_versions")
    deploys = ctx.count_table("deploy_history")
    status = "pass" if (versions > 0 or deploys > 0) else "warn"
    return ControlResult(
        status=status,
        evidence={"prompt_versions": versions, "deploy_history": deploys},
        notes="Change management via prompt_versions + deploy_history",
    )


def _check_policy_governance(ctx: ControlContext) -> ControlResult:
    return check_has_rows(
        ctx,
        "policy_versions",
        scoped=False,
        pass_notes="Policy version history present",
        fail_notes="No versioned policies defined",
    )


def _check_vendor_risk(ctx: ControlContext) -> ControlResult:
    # CC9.2 — vendor risk — tracked via model_risk_register (model vendors).
    return check_has_rows(
        ctx,
        "model_risk_register",
        scoped=False,
        pass_notes="Model vendor risk register populated",
        fail_notes="Model risk register empty",
    )


def _check_risk_assessment(ctx: ControlContext) -> ControlResult:
    return check_has_rows(
        ctx,
        "model_risk_register",
        scoped=False,
        pass_notes="Risk assessments on file for deployed models",
        fail_notes="No risk assessments on file",
    )


def _check_data_classification(ctx: ControlContext) -> ControlResult:
    meta = ctx.get_tenant_meta()
    classified = bool((meta.get("settings") or {}).get("data_classification"))
    status = "pass" if classified else "warn"
    return ControlResult(
        status=status,
        evidence={"data_classification": classified, "tenant_plan": meta.get("plan")},
        notes="Tenant-level data classification setting",
    )


SOC2 = Framework(
    id="soc2",
    name="SOC 2 Type II",
    version="TSC 2017",
    regulator="AICPA",
    url="https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2",
    controls=(
        Control(
            id="CC6.1",
            name="Logical Access",
            framework_ids=("soc2", "iso_27001"),
            category="Access Control",
            importance="critical",
            description="Logical access security software, infrastructure, and architectures are implemented to protect against threats.",
            remediation_text="Configure authenticated API keys and define RBAC users for every tenant. Rotate credentials regularly.",
            check_fn=_check_logical_access,
            references=("AICPA TSC CC6.1",),
        ),
        Control(
            id="CC6.2",
            name="User Access Review",
            framework_ids=("soc2",),
            category="Access Control",
            importance="high",
            description="Prior to issuing system credentials, the entity registers and authorizes new users.",
            remediation_text="Populate the users table and review active accounts at least quarterly.",
            check_fn=_check_access_review,
            references=("AICPA TSC CC6.2",),
        ),
        Control(
            id="CC6.3",
            name="User Provisioning",
            framework_ids=("soc2", "iso_27001"),
            category="Access Control",
            importance="high",
            description="The entity authorizes, modifies, or removes access to data based on roles or responsibilities.",
            remediation_text="Track provisioning events and revoke tokens on termination via revoked_tokens.",
            check_fn=_check_user_provisioning,
            references=("AICPA TSC CC6.3",),
        ),
        Control(
            id="CC6.6",
            name="Encryption",
            framework_ids=("soc2", "hipaa", "pci_dss"),
            category="Data Protection",
            importance="critical",
            description="The entity implements logical access security measures to protect against threats from outside its system.",
            remediation_text="Enforce TLS on all external endpoints; enable disk encryption on the storage backend.",
            check_fn=_check_encryption,
            references=("AICPA TSC CC6.6",),
        ),
        Control(
            id="CC7.1",
            name="System Monitoring",
            framework_ids=("soc2",),
            category="Audit Monitoring",
            importance="critical",
            description="The entity uses detection and monitoring procedures to identify (1) changes to configurations and (2) security events.",
            remediation_text="Enable the audit_chain and events tables; verify writes flow for all critical actions.",
            check_fn=_check_audit_logging,
            references=("AICPA TSC CC7.1",),
        ),
        Control(
            id="CC7.2",
            name="Incident Detection",
            framework_ids=("soc2", "iso_27001"),
            category="Incident Response",
            importance="high",
            description="The entity monitors system components and the operation of those components for anomalies.",
            remediation_text="Populate the incidents table through automated alerting; review open incidents weekly.",
            check_fn=_check_incident_response,
            references=("AICPA TSC CC7.2",),
        ),
        Control(
            id="CC7.3",
            name="Security Event Response",
            framework_ids=("soc2",),
            category="Incident Response",
            importance="high",
            description="The entity evaluates security events to determine whether they could or have resulted in a failure of the entity to meet its objectives.",
            remediation_text="Review critical security_violations rows daily; drive them to zero via guardrail tuning.",
            check_fn=_check_monitoring_anomalies,
            references=("AICPA TSC CC7.3",),
        ),
        Control(
            id="CC8.1",
            name="Change Management",
            framework_ids=("soc2", "iso_27001"),
            category="Configuration Management",
            importance="high",
            description="The entity authorizes, designs, develops, tests, approves, and implements changes to infrastructure.",
            remediation_text="Use the prompt registry + deploy_history to require version control and approvals.",
            check_fn=_check_change_management,
            references=("AICPA TSC CC8.1",),
        ),
        Control(
            id="CC9.1",
            name="Risk Mitigation",
            framework_ids=("soc2",),
            category="Risk Management",
            importance="high",
            description="The entity identifies, selects, and develops risk mitigation activities for risks arising from potential business disruptions.",
            remediation_text="Create versioned policies covering model allow/deny lists and approvals.",
            check_fn=_check_policy_governance,
            references=("AICPA TSC CC9.1",),
        ),
        Control(
            id="CC9.2",
            name="Vendor Management",
            framework_ids=("soc2", "iso_27001"),
            category="Vendor Management",
            importance="medium",
            description="The entity assesses and manages risks associated with vendors and business partners.",
            remediation_text="Register every AI model vendor in model_risk_register with a risk tier and approvals.",
            check_fn=_check_vendor_risk,
            references=("AICPA TSC CC9.2",),
        ),
        Control(
            id="CC3.2",
            name="Risk Assessment",
            framework_ids=("soc2", "nist_ai_rmf"),
            category="Risk Management",
            importance="high",
            description="The entity identifies risks to the achievement of its objectives and analyzes risks as a basis for determining how risks should be managed.",
            remediation_text="Run model risk assessments quarterly and log outcomes in model_risk_register.",
            check_fn=_check_risk_assessment,
            references=("AICPA TSC CC3.2",),
        ),
        Control(
            id="C1.1",
            name="Confidentiality",
            framework_ids=("soc2", "gdpr"),
            category="Data Protection",
            importance="critical",
            description="The entity identifies and maintains confidential information to meet the entity's objectives related to confidentiality.",
            remediation_text="Classify tenant data via settings_json.data_classification and enforce redaction in traces.",
            check_fn=_check_data_classification,
            references=("AICPA TSC C1.1",),
        ),
    ),
)

REGISTRY.register(SOC2)
