"""NIST AI Risk Management Framework 1.0."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows


def _setting(ctx: ControlContext, key: str) -> ControlResult:
    val = ctx.get_tenant_setting(key)
    return ControlResult(
        status="pass" if val else "warn",
        evidence={key: val},
        notes=f"Tenant setting {key}",
    )


def _check_govern_policy(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "policy_versions", scoped=False,
                          pass_notes="Governance policies defined")


def _check_govern_accountability(ctx: ControlContext) -> ControlResult:
    return _setting(ctx, "ai_accountability_owner")


def _check_map_context(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "model_risk_register", scoped=False,
                          pass_notes="Context mapped via model risk register")


def _check_map_risk(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "model_risk_register", scoped=False)


def _check_measure_metrics(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "eval_scores", scoped=False,
                          pass_notes="Metrics measured via eval_scores")


def _check_measure_test(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "eval_datasets", scoped=False)


def _check_manage_risks(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "hitl_queue", min_rows=0)


def _check_manage_recovery(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "escalation_policies", scoped=False)


NIST_AI_RMF = Framework(
    id="nist_ai_rmf",
    name="NIST AI Risk Management Framework",
    version="1.0",
    regulator="National Institute of Standards and Technology",
    url="https://www.nist.gov/itl/ai-risk-management-framework",
    controls=(
        Control("GOVERN-1.1", "AI Governance Policy", ("nist_ai_rmf", "iso_42001"),
                "Risk Management", "high",
                "Legal and regulatory requirements involving AI are understood, managed, and documented.",
                "Publish a versioned AI governance policy.",
                _check_govern_policy, ("NIST AI RMF 1.0 GOVERN 1.1",)),
        Control("GOVERN-2.1", "Accountability", ("nist_ai_rmf",),
                "Vendor Management", "medium",
                "Roles, responsibilities, and lines of communication related to AI are documented and clear.",
                "Set settings_json.ai_accountability_owner to the named owner.",
                _check_govern_accountability, ("NIST AI RMF 1.0 GOVERN 2.1",)),
        Control("MAP-1.1", "Context Mapping", ("nist_ai_rmf",),
                "Risk Management", "high",
                "Intended purpose, potentially beneficial uses, context-specific laws, etc., are understood.",
                "Register every model with its use case.",
                _check_map_context, ("NIST AI RMF 1.0 MAP 1.1",)),
        Control("MAP-2.3", "Risk Identification", ("nist_ai_rmf", "eu_ai_act"),
                "Risk Management", "high",
                "Potential AI risks are identified and mapped.",
                "Maintain the model risk register.",
                _check_map_risk, ("NIST AI RMF 1.0 MAP 2.3",)),
        Control("MEASURE-2.1", "Metrics", ("nist_ai_rmf",),
                "Audit Monitoring", "high",
                "Test sets, metrics, and details about the tools used are documented.",
                "Populate eval_scores continuously.",
                _check_measure_metrics, ("NIST AI RMF 1.0 MEASURE 2.1",)),
        Control("MEASURE-2.3", "Test & Evaluation", ("nist_ai_rmf",),
                "Audit Monitoring", "medium",
                "AI system performance or assurance criteria are measured qualitatively or quantitatively.",
                "Curate eval_datasets.",
                _check_measure_test, ("NIST AI RMF 1.0 MEASURE 2.3",)),
        Control("MANAGE-2.1", "Risk Response", ("nist_ai_rmf",),
                "Incident Response", "high",
                "Resources required to manage AI risks are taken into account.",
                "Route risky outputs to HITL queue.",
                _check_manage_risks, ("NIST AI RMF 1.0 MANAGE 2.1",)),
        Control("MANAGE-4.3", "Recovery", ("nist_ai_rmf", "iso_27001"),
                "Business Continuity", "medium",
                "AI incidents and errors are communicated to relevant AI actors, including affected communities.",
                "Define escalation_policies.",
                _check_manage_recovery, ("NIST AI RMF 1.0 MANAGE 4.3",)),
    ),
)

REGISTRY.register(NIST_AI_RMF)
