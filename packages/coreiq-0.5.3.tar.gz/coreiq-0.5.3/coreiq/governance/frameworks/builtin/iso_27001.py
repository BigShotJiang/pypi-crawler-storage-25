"""ISO/IEC 27001:2022 Annex A (AI-relevant subset)."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows


def _setting(ctx: ControlContext, key: str, notes: str = "") -> ControlResult:
    val = ctx.get_tenant_setting(key)
    return ControlResult(
        status="pass" if val else "warn",
        evidence={key: val},
        notes=notes or key,
    )


def _has(ctx: ControlContext, table: str, scoped: bool = False) -> ControlResult:
    return check_has_rows(ctx, table, scoped=scoped)


ISO_27001 = Framework(
    id="iso_27001",
    name="ISO/IEC 27001:2022",
    version="2022",
    regulator="International Organization for Standardization",
    url="https://www.iso.org/standard/27001",
    controls=(
        Control("A.5.1", "Information Security Policies", ("iso_27001", "soc2"),
                "Risk Management", "high",
                "Policies for information security shall be defined, approved and communicated.",
                "Publish AUP policies per tenant.",
                lambda ctx: check_has_rows(ctx, "aup_policies", scoped=True),
                ("ISO/IEC 27001:2022 A.5.1",)),
        Control("A.5.7", "Threat Intelligence", ("iso_27001",),
                "Risk Management", "medium",
                "Information relating to information security threats shall be collected and analysed.",
                "Record threats via incidents table.",
                lambda ctx: _has(ctx, "incidents"),
                ("ISO/IEC 27001:2022 A.5.7",)),
        Control("A.5.15", "Access Control", ("iso_27001",),
                "Access Control", "critical",
                "Rules to control physical and logical access to information and other associated assets shall be established.",
                "Define group_policies with RBAC roles.",
                lambda ctx: _has(ctx, "group_policies"),
                ("ISO/IEC 27001:2022 A.5.15",)),
        Control("A.5.23", "Cloud Services", ("iso_27001",),
                "Vendor Management", "high",
                "Processes for the acquisition, use, management and exit from cloud services shall be established.",
                "Register cloud AI vendors in model_risk_register.",
                lambda ctx: _has(ctx, "model_risk_register"),
                ("ISO/IEC 27001:2022 A.5.23",)),
        Control("A.5.30", "ICT Readiness for Business Continuity", ("iso_27001",),
                "Business Continuity", "high",
                "ICT readiness shall be planned, implemented, maintained and tested.",
                "Enable backup_enabled=true and run DR drills.",
                lambda ctx: _setting(ctx, "backup_enabled", "Backups enabled"),
                ("ISO/IEC 27001:2022 A.5.30",)),
        Control("A.8.2", "Privileged Access Rights", ("iso_27001",),
                "Access Control", "high",
                "The allocation and use of privileged access rights shall be restricted and managed.",
                "Define admin vs user roles via group_policies.",
                lambda ctx: _has(ctx, "group_policies"),
                ("ISO/IEC 27001:2022 A.8.2",)),
        Control("A.8.15", "Logging", ("iso_27001", "hipaa"),
                "Audit Monitoring", "critical",
                "Logs that record activities, exceptions, faults and other relevant events shall be produced.",
                "Enable audit_chain writes.",
                lambda ctx: _has(ctx, "audit_chain"),
                ("ISO/IEC 27001:2022 A.8.15",)),
        Control("A.8.16", "Monitoring Activities", ("iso_27001",),
                "Audit Monitoring", "high",
                "Networks, systems and applications shall be monitored for anomalous behaviour.",
                "Enable traces and events collection.",
                lambda ctx: _has(ctx, "events"),
                ("ISO/IEC 27001:2022 A.8.16",)),
        Control("A.8.24", "Use of Cryptography", ("iso_27001", "pci_dss"),
                "Data Protection", "critical",
                "Rules for the effective use of cryptography shall be defined and implemented.",
                "Enforce TLS on all endpoints.",
                lambda ctx: _setting(ctx, "tls_enforced", "TLS enforced"),
                ("ISO/IEC 27001:2022 A.8.24",)),
        Control("A.8.28", "Secure Coding", ("iso_27001",),
                "Configuration Management", "medium",
                "Secure coding principles shall be applied to software development.",
                "Use prompt_versions for every prompt change review.",
                lambda ctx: _has(ctx, "prompt_versions"),
                ("ISO/IEC 27001:2022 A.8.28",)),
        Control("A.8.32", "Change Management", ("iso_27001", "soc2"),
                "Configuration Management", "high",
                "Changes to information processing facilities and systems shall be subject to change management.",
                "Require deploy_history entries for every rollout.",
                lambda ctx: _has(ctx, "deploy_history"),
                ("ISO/IEC 27001:2022 A.8.32",)),
        Control("A.5.34", "Privacy and PII Protection", ("iso_27001", "gdpr"),
                "Data Protection", "high",
                "The organization shall identify and meet the requirements regarding the preservation of privacy and protection of PII.",
                "Enable pii_redaction in tenant settings.",
                lambda ctx: _setting(ctx, "pii_redaction", "PII redaction enabled"),
                ("ISO/IEC 27001:2022 A.5.34",)),
    ),
)

REGISTRY.register(ISO_27001)
