"""DORA — Digital Operational Resilience Act (Regulation (EU) 2022/2554)."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows


def _setting(ctx: ControlContext, key: str) -> ControlResult:
    val = ctx.get_tenant_setting(key)
    return ControlResult(
        status="pass" if val else "warn",
        evidence={key: val},
        notes=key,
    )


DORA = Framework(
    id="dora",
    name="Digital Operational Resilience Act",
    version="Regulation (EU) 2022/2554",
    regulator="European Supervisory Authorities",
    url="https://www.eiopa.europa.eu/browse/regulation-and-policy/digital-operational-resilience-act-dora_en",
    controls=(
        Control("DORA-5", "ICT Risk Management Framework", ("dora", "iso_27001"),
                "Risk Management", "critical",
                "Financial entities shall have a sound, comprehensive and well-documented ICT risk management framework (Article 5).",
                "Publish policy_versions for the ICT risk management framework.",
                lambda ctx: check_has_rows(ctx, "policy_versions"),
                ("DORA Art. 5",)),
        Control("DORA-8", "Identification", ("dora",),
                "Risk Management", "high",
                "Financial entities shall identify, classify and adequately document all ICT-supported business functions (Article 8).",
                "Inventory models in model_risk_register.",
                lambda ctx: check_has_rows(ctx, "model_risk_register"),
                ("DORA Art. 8",)),
        Control("DORA-9", "Protection and Prevention", ("dora",),
                "Data Protection", "critical",
                "Financial entities shall continuously monitor and control the security and functioning of ICT systems (Article 9).",
                "Enforce TLS and monitor security violations.",
                lambda ctx: _setting(ctx, "tls_enforced"),
                ("DORA Art. 9",)),
        Control("DORA-10", "Detection", ("dora", "soc2"),
                "Audit Monitoring", "high",
                "Financial entities shall have in place mechanisms to promptly detect anomalous activities (Article 10).",
                "Monitor security_violations and incidents.",
                lambda ctx: check_has_rows(ctx, "security_violations", min_rows=0),
                ("DORA Art. 10",)),
        Control("DORA-11", "Response and Recovery", ("dora",),
                "Business Continuity", "critical",
                "Financial entities shall put in place a comprehensive ICT business continuity policy (Article 11).",
                "Enable backup_enabled and define escalation_policies.",
                lambda ctx: _setting(ctx, "backup_enabled"),
                ("DORA Art. 11",)),
        Control("DORA-17", "ICT-related Incident Management", ("dora",),
                "Incident Response", "critical",
                "Financial entities shall define, establish and implement an ICT-related incident management process (Article 17).",
                "Use incidents + escalation_policies.",
                lambda ctx: check_has_rows(ctx, "escalation_policies"),
                ("DORA Art. 17",)),
        Control("DORA-24", "Digital Operational Resilience Testing", ("dora",),
                "Audit Monitoring", "high",
                "Financial entities shall establish a sound and comprehensive digital operational resilience testing programme (Article 24).",
                "Run evals and record eval_scores.",
                lambda ctx: check_has_rows(ctx, "eval_scores"),
                ("DORA Art. 24",)),
        Control("DORA-28", "ICT Third-party Risk", ("dora", "iso_27001"),
                "Vendor Management", "critical",
                "Financial entities shall manage ICT third-party risk as an integral component of ICT risk (Article 28).",
                "Maintain model_risk_register with vendor contacts.",
                lambda ctx: check_has_rows(ctx, "model_risk_register"),
                ("DORA Art. 28",)),
    ),
)

REGISTRY.register(DORA)
