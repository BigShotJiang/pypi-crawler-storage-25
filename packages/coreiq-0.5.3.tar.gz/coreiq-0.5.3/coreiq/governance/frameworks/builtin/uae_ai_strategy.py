"""UAE National AI Strategy 2031 + CBUAE AI/ML Guidelines."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows


def _setting(ctx: ControlContext, key: str) -> ControlResult:
    val = ctx.get_tenant_setting(key)
    return ControlResult(
        status="pass" if val else "warn",
        evidence={key: val},
        notes=key,
    )


UAE = Framework(
    id="uae_ai_strategy",
    name="UAE National AI Strategy 2031",
    version="2031",
    regulator="UAE Council for Artificial Intelligence / CBUAE",
    url="https://ai.gov.ae/strategy/",
    controls=(
        Control("UAE-1", "Ethics & Governance", ("uae_ai_strategy", "iso_42001"),
                "Risk Management", "high",
                "Adoption of the UAE AI ethics framework across all AI deployments.",
                "Publish a versioned AI policy.",
                lambda ctx: check_has_rows(ctx, "policy_versions", scoped=False),
                ("UAE AI Strategy 2031 — Ethics Pillar",)),
        Control("UAE-2", "Data Sovereignty", ("uae_ai_strategy",),
                "Data Protection", "critical",
                "Data must be stored in UAE-approved jurisdictions when handling sensitive categories.",
                "Declare data_region='uae' in tenant settings.",
                lambda ctx: _setting(ctx, "data_region"),
                ("UAE PDPL; CBUAE Data Localization",)),
        Control("UAE-3", "Model Risk Management (CBUAE)", ("uae_ai_strategy",),
                "Risk Management", "critical",
                "CBUAE requires model risk management for AI/ML in financial services.",
                "Register AI models in model_risk_register with tier and approvals.",
                lambda ctx: check_has_rows(ctx, "model_risk_register", scoped=False),
                ("CBUAE AI/ML Model Risk Guidelines 2023",)),
        Control("UAE-4", "Explainability", ("uae_ai_strategy", "eu_ai_act"),
                "Audit Monitoring", "high",
                "AI decisions affecting customers must be explainable.",
                "Attest explainability_enabled=true.",
                lambda ctx: _setting(ctx, "explainability_enabled"),
                ("CBUAE AI/ML 3.2",)),
        Control("UAE-5", "Bias Mitigation", ("uae_ai_strategy",),
                "Data Protection", "high",
                "AI systems shall implement bias detection and mitigation.",
                "Run bias_monitor and record findings.",
                lambda ctx: _setting(ctx, "bias_monitoring_enabled"),
                ("UAE AI Strategy 2031",)),
        Control("UAE-6", "Human Oversight", ("uae_ai_strategy", "eu_ai_act"),
                "Risk Management", "critical",
                "High-impact AI decisions require human oversight.",
                "Route high-risk calls into hitl_queue.",
                lambda ctx: check_has_rows(ctx, "hitl_queue", min_rows=0),
                ("CBUAE AI/ML 4.1",)),
        Control("UAE-7", "Audit Trail", ("uae_ai_strategy", "soc2"),
                "Audit Monitoring", "critical",
                "All AI decisions affecting regulated activities must be logged.",
                "Enable audit_chain writes.",
                lambda ctx: check_has_rows(ctx, "audit_chain", scoped=False),
                ("CBUAE AI/ML 5.1",)),
        Control("UAE-8", "Vendor Oversight", ("uae_ai_strategy",),
                "Vendor Management", "medium",
                "Third-party AI vendors must be assessed per CBUAE outsourcing guidance.",
                "Track vendors in model_risk_register.",
                lambda ctx: check_has_rows(ctx, "model_risk_register", scoped=False),
                ("CBUAE Outsourcing 2021",)),
        Control("UAE-9", "Incident Reporting", ("uae_ai_strategy",),
                "Incident Response", "high",
                "AI incidents affecting customers must be reported to the regulator within required SLAs.",
                "Track incidents in the incidents table.",
                lambda ctx: check_has_rows(ctx, "incidents", min_rows=0),
                ("CBUAE AI/ML 6.1",)),
        Control("UAE-10", "Consumer Protection", ("uae_ai_strategy", "gdpr"),
                "Data Protection", "high",
                "AI systems must protect customer personal data per PDPL.",
                "Enforce pii_redaction in settings.",
                lambda ctx: _setting(ctx, "pii_redaction"),
                ("UAE PDPL Federal Decree-Law No. 45/2021",)),
    ),
)

REGISTRY.register(UAE)
