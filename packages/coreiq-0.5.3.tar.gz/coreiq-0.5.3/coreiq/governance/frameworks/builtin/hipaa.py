"""HIPAA Security, Privacy and Breach Notification Rules."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows, manual_control


def _generic_setting(ctx: ControlContext, key: str, default: bool = False) -> ControlResult:
    val = ctx.get_tenant_setting(key, default)
    return ControlResult(
        status="pass" if val else "warn",
        evidence={"setting": key, "value": val},
        notes=f"Tenant setting {key}",
    )


def _check_access_control(ctx: ControlContext) -> ControlResult:
    keys = ctx.count_table("api_keys")
    return ControlResult(
        status="pass" if keys > 0 else "fail",
        evidence={"api_keys": keys},
        notes="Unique user identification per 164.312(a)(1)",
    )


def _check_audit_controls(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "audit_chain", scoped=False,
                           pass_notes="Audit chain active",
                           fail_notes="No audit records")


def _check_integrity(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "audit_chain", scoped=False,
                           pass_notes="Hash-chained audit log provides integrity")


def _check_transmission_security(ctx: ControlContext) -> ControlResult:
    return _generic_setting(ctx, "tls_enforced", True)


def _check_assigned_security(ctx: ControlContext) -> ControlResult:
    return _generic_setting(ctx, "security_officer")


def _check_workforce_training(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "aup_acknowledgments", scoped=False,
                           pass_notes="Workforce has acknowledged AUP")


def _check_access_authorization(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "group_policies", scoped=False)


def _check_contingency_plan(ctx: ControlContext) -> ControlResult:
    return _generic_setting(ctx, "backup_enabled", True)


def _check_incident_procedures(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "escalation_policies", scoped=False)


def _check_baa(ctx: ControlContext) -> ControlResult:
    return _generic_setting(ctx, "baa_signed")


def _check_minimum_necessary(ctx: ControlContext) -> ControlResult:
    return _generic_setting(ctx, "pii_redaction", True)


def _check_breach_notification(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "incidents", min_rows=0)


def _check_phi_inventory(ctx: ControlContext) -> ControlResult:
    return _generic_setting(ctx, "phi_inventory")


def _check_sanction_policy(ctx: ControlContext) -> ControlResult:
    return _generic_setting(ctx, "sanction_policy")


HIPAA = Framework(
    id="hipaa",
    name="HIPAA Security, Privacy, Breach Notification",
    version="45 CFR Parts 160 & 164",
    regulator="HHS Office for Civil Rights",
    url="https://www.hhs.gov/hipaa/for-professionals/index.html",
    controls=(
        Control("164.308(a)(2)", "Assigned Security Responsibility", ("hipaa",),
                "Access Control", "high",
                "Identify the security official who is responsible for developing and implementing security policies.",
                "Set settings_json.security_officer to the named official.",
                _check_assigned_security, ("45 CFR 164.308(a)(2)",)),
        Control("164.308(a)(3)", "Workforce Security", ("hipaa",),
                "Access Control", "high",
                "Implement policies and procedures to ensure all members of its workforce have appropriate access.",
                "Track AUP acknowledgments for every workforce member.",
                _check_workforce_training, ("45 CFR 164.308(a)(3)",)),
        Control("164.308(a)(4)", "Information Access Management", ("hipaa",),
                "Access Control", "high",
                "Implement policies for authorizing access to electronic protected health information (ePHI).",
                "Define group_policies scoped to each tenant's ePHI access patterns.",
                _check_access_authorization, ("45 CFR 164.308(a)(4)",)),
        Control("164.308(a)(5)", "Security Awareness Training", ("hipaa",),
                "Access Control", "medium",
                "Implement a security awareness and training program.",
                "Require AUP acknowledgment upon onboarding.",
                _check_workforce_training, ("45 CFR 164.308(a)(5)",)),
        Control("164.308(a)(6)", "Security Incident Procedures", ("hipaa",),
                "Incident Response", "high",
                "Implement policies to address security incidents.",
                "Define escalation_policies for each tenant.",
                _check_incident_procedures, ("45 CFR 164.308(a)(6)",)),
        Control("164.308(a)(7)", "Contingency Plan", ("hipaa",),
                "Business Continuity", "high",
                "Establish policies for responding to an emergency that affects systems containing ePHI.",
                "Enable backups and record backup_enabled=true.",
                _check_contingency_plan, ("45 CFR 164.308(a)(7)",)),
        Control("164.308(b)", "Business Associate Agreements", ("hipaa",),
                "Vendor Management", "critical",
                "A covered entity may permit a business associate to create, receive, maintain PHI only if satisfactory assurances exist.",
                "Record baa_signed=true after executing BAAs with all subprocessors.",
                _check_baa, ("45 CFR 164.308(b)",)),
        Control("164.310", "Physical Safeguards", ("hipaa",),
                "Access Control", "medium",
                "Physical measures, policies and procedures to protect electronic information systems.",
                "Manual attestation required — host provider's audit report (SOC 2 or ISO).",
                lambda ctx: manual_control("physical safeguards require host attestation"),
                ("45 CFR 164.310",)),
        Control("164.312(a)", "Access Control", ("hipaa", "soc2"),
                "Access Control", "critical",
                "Technical policies and procedures for systems that maintain ePHI to allow access only to authorized persons.",
                "Issue unique API keys for each user.",
                _check_access_control, ("45 CFR 164.312(a)",)),
        Control("164.312(b)", "Audit Controls", ("hipaa", "soc2"),
                "Audit Monitoring", "critical",
                "Implement hardware, software, and/or procedural mechanisms that record and examine activity.",
                "Enable audit_chain writes for all PHI access.",
                _check_audit_controls, ("45 CFR 164.312(b)",)),
        Control("164.312(c)", "Integrity", ("hipaa",),
                "Data Protection", "high",
                "Implement policies to protect ePHI from improper alteration or destruction.",
                "Rely on hash-chained audit logs (coreiq chained_audit).",
                _check_integrity, ("45 CFR 164.312(c)",)),
        Control("164.312(e)", "Transmission Security", ("hipaa", "pci_dss"),
                "Data Protection", "critical",
                "Implement technical security measures to guard against unauthorized access to ePHI over networks.",
                "Enforce TLS on every endpoint.",
                _check_transmission_security, ("45 CFR 164.312(e)",)),
        Control("164.514", "Minimum Necessary", ("hipaa",),
                "Data Protection", "high",
                "A covered entity must make reasonable efforts to use, disclose, and request only the minimum necessary PHI.",
                "Enable PII redaction in traces.",
                _check_minimum_necessary, ("45 CFR 164.514",)),
        Control("164.402", "Breach Notification", ("hipaa", "gdpr"),
                "Incident Response", "critical",
                "Notification requirements following a breach of unsecured PHI.",
                "Log incidents and set an SLA of 60 days.",
                _check_breach_notification, ("45 CFR 164.400-414",)),
    ),
)

REGISTRY.register(HIPAA)
