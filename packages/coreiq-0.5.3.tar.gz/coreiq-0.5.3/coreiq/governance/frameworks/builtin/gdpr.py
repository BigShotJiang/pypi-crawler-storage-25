"""GDPR — Regulation (EU) 2016/679."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows


def _check_lawful_basis(ctx: ControlContext) -> ControlResult:
    basis = ctx.get_tenant_setting("gdpr_lawful_basis")
    return ControlResult(
        status="pass" if basis else "warn",
        evidence={"lawful_basis": basis},
        notes="Lawful basis per Article 6",
    )


def _check_consent(ctx: ControlContext) -> ControlResult:
    acks = ctx.count_table("aup_acknowledgments")
    return ControlResult(
        status="pass" if acks > 0 else "warn",
        evidence={"acknowledgments": acks},
        notes="Recorded consent via AUP acknowledgments",
    )


def _check_data_subject_rights(ctx: ControlContext) -> ControlResult:
    handler = ctx.get_tenant_setting("dsar_contact")
    return ControlResult(
        status="pass" if handler else "warn",
        evidence={"dsar_contact": handler},
        notes="DSAR handler configured",
    )


def _check_records_of_processing(ctx: ControlContext) -> ControlResult:
    traces = ctx.count_table("traces")
    return ControlResult(
        status="pass" if traces > 0 else "warn",
        evidence={"traces": traces},
        notes="Article 30 records via traces table",
    )


def _check_security_of_processing(ctx: ControlContext) -> ControlResult:
    tls = bool(ctx.get_tenant_setting("tls_enforced", True))
    redaction = bool(ctx.get_tenant_setting("pii_redaction", True))
    status = "pass" if (tls and redaction) else "warn"
    return ControlResult(
        status=status,
        evidence={"tls_enforced": tls, "pii_redaction": redaction},
        notes="Appropriate technical measures under Article 32",
    )


def _check_breach_notification(ctx: ControlContext) -> ControlResult:
    return check_has_rows(
        ctx, "incidents", min_rows=0, scoped=False,
        pass_notes="Breach notification workflow configured via incidents",
        fail_notes="",
    )


def _check_dpia(ctx: ControlContext) -> ControlResult:
    dpia = ctx.get_tenant_setting("dpia_completed", False)
    return ControlResult(
        status="pass" if dpia else "warn",
        evidence={"dpia_completed": bool(dpia)},
        notes="DPIA required per Article 35",
    )


def _check_dpo(ctx: ControlContext) -> ControlResult:
    dpo = ctx.get_tenant_setting("dpo_contact")
    return ControlResult(
        status="pass" if dpo else "warn",
        evidence={"dpo_contact": dpo},
        notes="Data Protection Officer contact per Article 37",
    )


GDPR = Framework(
    id="gdpr",
    name="General Data Protection Regulation",
    version="Regulation (EU) 2016/679",
    regulator="European Data Protection Board",
    url="https://gdpr-info.eu/",
    controls=(
        Control("GDPR-ART6", "Lawful Basis", ("gdpr",), "Data Protection", "critical",
                "Processing shall be lawful only if and to the extent that at least one legal basis applies.",
                "Declare the lawful basis in settings_json.gdpr_lawful_basis.",
                _check_lawful_basis, ("GDPR Art. 6",)),
        Control("GDPR-ART7", "Consent", ("gdpr",), "Data Protection", "high",
                "Where processing is based on consent, the controller shall be able to demonstrate that the data subject has consented.",
                "Record user consent via AUP acknowledgments.",
                _check_consent, ("GDPR Art. 7",)),
        Control("GDPR-ART12", "Data Subject Rights", ("gdpr",), "Data Protection", "high",
                "The controller shall facilitate the exercise of data subject rights.",
                "Configure settings_json.dsar_contact with an active DPO mailbox.",
                _check_data_subject_rights, ("GDPR Art. 12-22",)),
        Control("GDPR-ART30", "Records of Processing", ("gdpr", "soc2"), "Audit Monitoring", "high",
                "Each controller shall maintain a record of processing activities under its responsibility.",
                "Enable traces for every inference call.",
                _check_records_of_processing, ("GDPR Art. 30",)),
        Control("GDPR-ART32", "Security of Processing", ("gdpr", "hipaa"), "Data Protection", "critical",
                "The controller shall implement appropriate technical and organisational measures.",
                "Enforce TLS and PII redaction via tenant settings.",
                _check_security_of_processing, ("GDPR Art. 32",)),
        Control("GDPR-ART33", "Breach Notification", ("gdpr",), "Incident Response", "critical",
                "In the case of a personal data breach, the controller shall notify the supervisory authority within 72 hours.",
                "Configure incident workflow and escalation_policies.",
                _check_breach_notification, ("GDPR Art. 33-34",)),
        Control("GDPR-ART35", "Data Protection Impact Assessment", ("gdpr", "eu_ai_act"), "Risk Management", "high",
                "Where processing is likely to result in a high risk to the rights and freedoms of natural persons.",
                "Attest dpia_completed=true in tenant settings once completed.",
                _check_dpia, ("GDPR Art. 35",)),
        Control("GDPR-ART37", "Data Protection Officer", ("gdpr",), "Vendor Management", "medium",
                "The controller shall designate a data protection officer in specified cases.",
                "Configure settings_json.dpo_contact with the DPO email.",
                _check_dpo, ("GDPR Art. 37-39",)),
    ),
)

REGISTRY.register(GDPR)
