"""Builtin compliance framework plugins.

Each submodule registers one :class:`coreiq.governance.frameworks.Framework`
at import time via ``REGISTRY.register(...)``. The parent package walks
this subpackage with :mod:`pkgutil` during auto-discovery — adding a new
framework is just dropping in a new file.
"""
