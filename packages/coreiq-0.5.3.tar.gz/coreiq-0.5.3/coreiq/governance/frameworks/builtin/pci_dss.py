"""PCI-DSS v4.0 (AI-relevant subset)."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows


def _setting(ctx: ControlContext, key: str, default: bool = False, notes: str = "") -> ControlResult:
    val = ctx.get_tenant_setting(key, default)
    return ControlResult(
        status="pass" if val else "warn",
        evidence={key: val},
        notes=notes or f"Tenant setting {key}",
    )


def _check_firewall(ctx: ControlContext) -> ControlResult:
    return _setting(ctx, "network_segmentation", notes="Network controls per Req 1")


def _check_default_passwords(ctx: ControlContext) -> ControlResult:
    keys = ctx.count_table("api_keys")
    return ControlResult(
        status="pass" if keys > 0 else "warn",
        evidence={"api_keys": keys},
        notes="API keys replace defaults per Req 2",
    )


def _check_stored_cardholder_data(ctx: ControlContext) -> ControlResult:
    return _setting(ctx, "pii_redaction", True, "Cardholder redaction per Req 3")


def _check_encryption_transmission(ctx: ControlContext) -> ControlResult:
    return _setting(ctx, "tls_enforced", True, "Encryption per Req 4")


def _check_malware(ctx: ControlContext) -> ControlResult:
    violations = ctx.count_table("security_violations", filters={"tenant_id": ctx.tenant_id, "category": "prompt_injection"})
    return ControlResult(
        status="pass" if violations < 10 else "warn",
        evidence={"injection_violations": violations},
        notes="Prompt-injection guardrails per Req 5 equivalent",
    )


def _check_secure_systems(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "prompt_versions", scoped=False,
                          pass_notes="Change control via prompt_versions per Req 6")


def _check_access_restriction(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "group_policies", scoped=False)


def _check_unique_id(ctx: ControlContext) -> ControlResult:
    users = ctx.count_table("users")
    return ControlResult(
        status="pass" if users > 0 else "warn",
        evidence={"users": users},
        notes="Unique IDs per Req 8",
    )


def _check_logging(ctx: ControlContext) -> ControlResult:
    audit = ctx.count_table("audit_chain")
    return ControlResult(
        status="pass" if audit > 0 else "fail",
        evidence={"audit_chain": audit},
        notes="Logging per Req 10",
    )


def _check_security_policy(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "aup_policies", scoped=True,
                          pass_notes="Security policy published per Req 12")


PCI_DSS = Framework(
    id="pci_dss",
    name="PCI-DSS v4.0",
    version="4.0",
    regulator="PCI Security Standards Council",
    url="https://www.pcisecuritystandards.org/",
    controls=(
        Control("REQ-1", "Install and Maintain Network Controls", ("pci_dss",),
                "Access Control", "high",
                "Install and maintain network security controls.",
                "Enable network_segmentation=true in tenant settings.",
                _check_firewall, ("PCI-DSS v4.0 Req 1",)),
        Control("REQ-2", "Apply Secure Configurations", ("pci_dss",),
                "Configuration Management", "high",
                "Apply secure configurations to all system components.",
                "Replace default credentials with per-user API keys.",
                _check_default_passwords, ("PCI-DSS v4.0 Req 2",)),
        Control("REQ-3", "Protect Stored Account Data", ("pci_dss", "gdpr"),
                "Data Protection", "critical",
                "Protect stored account data.",
                "Enable PII redaction in request/response traces.",
                _check_stored_cardholder_data, ("PCI-DSS v4.0 Req 3",)),
        Control("REQ-4", "Protect Cardholder Data with Strong Cryptography", ("pci_dss", "hipaa"),
                "Data Protection", "critical",
                "Protect cardholder data with strong cryptography during transmission.",
                "Enforce TLS 1.2+ on all endpoints.",
                _check_encryption_transmission, ("PCI-DSS v4.0 Req 4",)),
        Control("REQ-5", "Protect Systems from Malicious Software", ("pci_dss",),
                "Data Protection", "high",
                "Protect all systems and networks from malicious software.",
                "Tune prompt-injection guardrails to reduce violations.",
                _check_malware, ("PCI-DSS v4.0 Req 5",)),
        Control("REQ-6", "Develop and Maintain Secure Systems", ("pci_dss", "soc2"),
                "Configuration Management", "high",
                "Develop and maintain secure systems and software.",
                "Use the prompt registry to enforce approval workflow.",
                _check_secure_systems, ("PCI-DSS v4.0 Req 6",)),
        Control("REQ-7", "Restrict Access by Need-to-Know", ("pci_dss",),
                "Access Control", "high",
                "Restrict access to system components and cardholder data by business need to know.",
                "Define group_policies with minimum necessary scope.",
                _check_access_restriction, ("PCI-DSS v4.0 Req 7",)),
        Control("REQ-8", "Identify Users and Authenticate Access", ("pci_dss",),
                "Access Control", "critical",
                "Identify users and authenticate access to system components.",
                "Register unique users in the users table.",
                _check_unique_id, ("PCI-DSS v4.0 Req 8",)),
        Control("REQ-10", "Log and Monitor All Access", ("pci_dss", "hipaa"),
                "Audit Monitoring", "critical",
                "Log and monitor all access to system components and cardholder data.",
                "Enable the hash-chained audit log.",
                _check_logging, ("PCI-DSS v4.0 Req 10",)),
        Control("REQ-12", "Support Information Security with Policies", ("pci_dss",),
                "Risk Management", "medium",
                "Support information security with organizational policies and programs.",
                "Publish an AUP per tenant.",
                _check_security_policy, ("PCI-DSS v4.0 Req 12",)),
    ),
)

REGISTRY.register(PCI_DSS)
