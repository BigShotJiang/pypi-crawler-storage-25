"""EU AI Act (Regulation (EU) 2024/1689)."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows, manual_control


def _check_risk_classification(ctx: ControlContext) -> ControlResult:
    return check_has_rows(
        ctx, "model_risk_register", scoped=False,
        pass_notes="Models are risk-classified per Article 6",
        fail_notes="No model risk classifications recorded",
    )


def _check_data_governance(ctx: ControlContext) -> ControlResult:
    datasets = ctx.count_table("eval_datasets")
    items = ctx.count_table("dataset_items")
    status = "pass" if datasets > 0 and items > 0 else "warn"
    return ControlResult(
        status=status,
        evidence={"datasets": datasets, "dataset_items": items},
        notes="Training/eval datasets registered",
    )


def _check_technical_documentation(ctx: ControlContext) -> ControlResult:
    return check_has_rows(
        ctx, "prompt_versions", scoped=False,
        pass_notes="Technical docs maintained via prompt_versions",
        fail_notes="No technical documentation on file",
    )


def _check_record_keeping(ctx: ControlContext) -> ControlResult:
    traces = ctx.count_table("traces")
    audit = ctx.count_table("audit_chain")
    status = "pass" if traces > 0 and audit > 0 else ("warn" if traces > 0 else "fail")
    return ControlResult(
        status=status,
        evidence={"traces": traces, "audit_chain": audit},
        notes="Automatic logs are retained per Article 12",
    )


def _check_transparency(ctx: ControlContext) -> ControlResult:
    disclosure = ctx.get_tenant_setting("ai_user_disclosure", False)
    return ControlResult(
        status="pass" if disclosure else "warn",
        evidence={"ai_user_disclosure": bool(disclosure)},
        notes="Per Article 13, users must be informed they are interacting with AI",
    )


def _check_human_oversight(ctx: ControlContext) -> ControlResult:
    hitl = ctx.count_table("hitl_queue")
    status = "pass" if hitl > 0 else "warn"
    return ControlResult(
        status=status,
        evidence={"hitl_items": hitl},
        notes="Human-in-the-loop oversight enabled",
    )


def _check_accuracy_robustness(ctx: ControlContext) -> ControlResult:
    evals = ctx.count_table("eval_scores")
    status = "pass" if evals > 0 else "warn"
    return ControlResult(
        status=status,
        evidence={"eval_scores": evals},
        notes="Ongoing accuracy/robustness evaluations",
    )


def _check_cybersecurity(ctx: ControlContext) -> ControlResult:
    violations = ctx.count_table("security_violations", filters={"tenant_id": ctx.tenant_id, "severity": "critical"})
    return ControlResult(
        status="pass" if violations == 0 else "fail",
        evidence={"critical_violations": violations},
        notes="Per Article 15: no critical security violations",
    )


def _check_post_market_monitoring(ctx: ControlContext) -> ControlResult:
    incidents = ctx.count_table("incidents")
    return ControlResult(
        status="pass" if incidents >= 0 else "warn",
        evidence={"incidents_tracked": incidents},
        notes="Post-market monitoring via incident tracking",
    )


def _check_conformity_assessment(ctx: ControlContext) -> ControlResult:
    return manual_control("Conformity assessment is a manual CE-marking step")


EU_AI_ACT = Framework(
    id="eu_ai_act",
    name="EU AI Act",
    version="Regulation (EU) 2024/1689",
    regulator="European Commission",
    url="https://artificialintelligenceact.eu/",
    controls=(
        Control("ART6", "Risk Classification", ("eu_ai_act",), "Risk Management", "critical",
                "Classification rules for high-risk AI systems (Article 6).",
                "Tag every deployed model with a risk tier in model_risk_register.",
                _check_risk_classification, ("EU AI Act Art. 6",)),
        Control("ART10", "Data Governance", ("eu_ai_act", "gdpr"), "Data Protection", "critical",
                "Data and data governance requirements for training, validation and testing (Article 10).",
                "Register datasets and items used for training/eval.",
                _check_data_governance, ("EU AI Act Art. 10",)),
        Control("ART11", "Technical Documentation", ("eu_ai_act",), "Configuration Management", "high",
                "Technical documentation must be drawn up before placing on the market (Article 11).",
                "Use the prompt registry to maintain versioned technical docs.",
                _check_technical_documentation, ("EU AI Act Art. 11",)),
        Control("ART12", "Record Keeping", ("eu_ai_act", "soc2"), "Audit Monitoring", "high",
                "High-risk AI systems shall technically allow for the automatic recording of events (Article 12).",
                "Enable traces and audit_chain writes for all inference calls.",
                _check_record_keeping, ("EU AI Act Art. 12",)),
        Control("ART13", "Transparency", ("eu_ai_act",), "Data Protection", "high",
                "High-risk AI systems shall be designed to ensure sufficient transparency (Article 13).",
                "Set settings_json.ai_user_disclosure=true to record operator has disclosed AI use.",
                _check_transparency, ("EU AI Act Art. 13",)),
        Control("ART14", "Human Oversight", ("eu_ai_act", "nist_ai_rmf"), "Risk Management", "critical",
                "High-risk AI systems shall be designed so they can be effectively overseen by natural persons (Article 14).",
                "Route high-risk calls into the HITL queue and review within SLA.",
                _check_human_oversight, ("EU AI Act Art. 14",)),
        Control("ART15", "Accuracy & Robustness", ("eu_ai_act",), "Risk Management", "high",
                "High-risk AI systems shall achieve appropriate levels of accuracy, robustness and cybersecurity (Article 15).",
                "Schedule evals weekly and record eval_scores.",
                _check_accuracy_robustness, ("EU AI Act Art. 15",)),
        Control("ART15-SEC", "Cybersecurity", ("eu_ai_act", "iso_27001"), "Data Protection", "critical",
                "Cybersecurity obligations under Article 15.",
                "Drive critical security_violations to zero via guardrails.",
                _check_cybersecurity, ("EU AI Act Art. 15(4)",)),
        Control("ART17", "Post-Market Monitoring", ("eu_ai_act",), "Audit Monitoring", "high",
                "Providers of high-risk AI systems shall establish a post-market monitoring system (Article 72).",
                "Create incidents in real time and review weekly.",
                _check_post_market_monitoring, ("EU AI Act Art. 72",)),
        Control("ART43", "Conformity Assessment", ("eu_ai_act",), "Risk Management", "high",
                "Conformity assessment procedure before placing on the market (Article 43).",
                "Attest to completed conformity assessment via the overrides endpoint.",
                _check_conformity_assessment, ("EU AI Act Art. 43",)),
    ),
)

REGISTRY.register(EU_AI_ACT)
