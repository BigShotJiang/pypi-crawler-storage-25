"""ISO/IEC 42001:2023 — AI Management System."""
from __future__ import annotations

from ..base import Control, ControlContext, ControlResult, Framework
from ..registry import REGISTRY
from ._helpers import check_has_rows


def _setting(ctx: ControlContext, key: str, notes: str = "") -> ControlResult:
    val = ctx.get_tenant_setting(key)
    return ControlResult(
        status="pass" if val else "warn",
        evidence={key: val},
        notes=notes or key,
    )


def _check_ai_policy(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "policy_versions", scoped=False,
                          pass_notes="AI policy on file")


def _check_ai_objectives(ctx: ControlContext) -> ControlResult:
    return _setting(ctx, "ai_objectives", "AI management objectives defined")


def _check_risk_assessment(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "model_risk_register", scoped=False)


def _check_ai_impact_assessment(ctx: ControlContext) -> ControlResult:
    return _setting(ctx, "ai_impact_assessment_completed", "AI impact assessment completed")


def _check_resources(ctx: ControlContext) -> ControlResult:
    return _setting(ctx, "ai_resources_allocated")


def _check_competence(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "aup_acknowledgments", scoped=False,
                          pass_notes="Workforce trained (AUP acknowledged)")


def _check_data_management(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "eval_datasets", scoped=False)


def _check_monitoring(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "eval_scores", scoped=False,
                          pass_notes="Ongoing AI monitoring active")


def _check_incident_management(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "incidents", min_rows=0)


def _check_continuous_improvement(ctx: ControlContext) -> ControlResult:
    return check_has_rows(ctx, "prompt_versions", scoped=False,
                          pass_notes="Iterative improvement via prompt registry")


ISO_42001 = Framework(
    id="iso_42001",
    name="ISO/IEC 42001:2023 AI Management System",
    version="2023",
    regulator="International Organization for Standardization",
    url="https://www.iso.org/standard/42001",
    controls=(
        Control("A.2", "AI Policy", ("iso_42001", "nist_ai_rmf"),
                "Risk Management", "high",
                "Top management shall establish an AI policy appropriate to the purpose of the organization.",
                "Publish a policy_versions record for the AI policy.",
                _check_ai_policy, ("ISO/IEC 42001:2023 Clause 5.2",)),
        Control("A.3", "AI Objectives", ("iso_42001",),
                "Risk Management", "medium",
                "The organization shall establish AI objectives at relevant functions and levels.",
                "Declare ai_objectives in tenant settings.",
                _check_ai_objectives, ("ISO/IEC 42001:2023 Clause 6.2",)),
        Control("A.4", "AI Risk Assessment", ("iso_42001", "eu_ai_act"),
                "Risk Management", "critical",
                "The organization shall define and apply an AI risk assessment process.",
                "Register every model in model_risk_register.",
                _check_risk_assessment, ("ISO/IEC 42001:2023 Clause 6.1",)),
        Control("A.5", "AI System Impact Assessment", ("iso_42001", "eu_ai_act"),
                "Risk Management", "high",
                "The organization shall assess the impact of AI systems on individuals, groups and societies.",
                "Attest ai_impact_assessment_completed=true.",
                _check_ai_impact_assessment, ("ISO/IEC 42001:2023 Clause 6.1.4",)),
        Control("A.6", "Resources", ("iso_42001",),
                "Vendor Management", "medium",
                "The organization shall determine and provide the resources needed for the AI management system.",
                "Attest ai_resources_allocated=true.",
                _check_resources, ("ISO/IEC 42001:2023 Clause 7.1",)),
        Control("A.7", "Competence", ("iso_42001", "hipaa"),
                "Access Control", "medium",
                "The organization shall determine the competence needed for persons doing work under its control.",
                "Require AUP acknowledgment on onboarding.",
                _check_competence, ("ISO/IEC 42001:2023 Clause 7.2",)),
        Control("A.8", "Data Management", ("iso_42001", "gdpr"),
                "Data Protection", "high",
                "The organization shall manage data used for AI systems throughout the life cycle.",
                "Register datasets in eval_datasets.",
                _check_data_management, ("ISO/IEC 42001:2023 Annex A.7",)),
        Control("A.9", "Monitoring", ("iso_42001",),
                "Audit Monitoring", "high",
                "The organization shall monitor the performance and effectiveness of the AI management system.",
                "Run evals and populate eval_scores.",
                _check_monitoring, ("ISO/IEC 42001:2023 Clause 9.1",)),
        Control("A.10", "Incident Management", ("iso_42001",),
                "Incident Response", "high",
                "The organization shall establish processes for handling AI incidents.",
                "Track incidents via the incidents table.",
                _check_incident_management, ("ISO/IEC 42001:2023 Annex A.8",)),
        Control("A.11", "Continual Improvement", ("iso_42001",),
                "Configuration Management", "medium",
                "The organization shall continually improve the suitability, adequacy and effectiveness of the AI management system.",
                "Iterate prompts via the prompt registry.",
                _check_continuous_improvement, ("ISO/IEC 42001:2023 Clause 10.1",)),
    ),
)

REGISTRY.register(ISO_42001)
