"""Minimal Model Context Protocol (MCP) server for CoreIQ.

Implements the JSON-RPC 2.0 wire format the MCP spec requires
(https://modelcontextprotocol.io/specification), exposing the existing
:class:`coreiq.tools.registry.ToolRegistry` to MCP-aware clients
(Claude Desktop, Cursor, OpenAI Agents SDK, etc.).

Methods supported
-----------------

- ``initialize`` — handshake. Returns server capabilities (only
  ``tools`` is advertised).
- ``tools/list`` — returns every tool registered in the registry,
  translated into the MCP wire format via :func:`schema_adapter.tool_to_mcp`.
- ``tools/call`` — invokes a tool by name. Delegates to a caller-supplied
  ``tool_invoker`` callable so coreiq's tool execution path stays in
  one place (governance / sandbox / audit) and the MCP server is only
  responsible for protocol framing.
- ``ping`` — keepalive. Returns an empty result.
- (Notifications like ``notifications/initialized`` are accepted and
  silently acknowledged.)

Why we don't depend on the upstream `mcp` PyPI package
-------------------------------------------------------

The `mcp` package is a fast-moving spec implementation. Pinning it
adds dependency churn and the surface we need (5 methods, JSON-RPC
2.0 framing) is small enough that ~250 LOC of stdlib code is simpler
and easier to test than wrapping a third-party client. The wire format
is stable JSON-RPC 2.0 — anything more sophisticated (HTTP+SSE
transport, OAuth) can be added in a follow-up commit.
"""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Optional, Union

from ..tools.registry import ToolRegistry
from .schema_adapter import mcp_call_to_tool_args, tool_to_mcp

logger = logging.getLogger("coreiq.mcp.server")

# JSON-RPC 2.0 error codes
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603

# MCP-specific error code range starts at -32000.
TOOL_NOT_FOUND = -32001
TOOL_EXECUTION_FAILED = -32002


# A tool invoker is a sync or async callable: (tool_name, arguments) -> result
ToolInvoker = Callable[[str, dict], Union[Any, Awaitable[Any]]]


class MCPServer:
    """JSON-RPC 2.0 protocol handler that exposes a ToolRegistry over MCP.

    Instantiate once per app, register the FastAPI route via
    :func:`mount_mcp_router`, and every MCP-aware client that points
    its config at the route discovers the registered tools.

    Parameters
    ----------
    registry:
        The :class:`ToolRegistry` whose tools should be exposed.
    tool_invoker:
        A sync-or-async callable that takes ``(tool_name, arguments)``
        and returns the tool's result. CoreIQ's existing tool execution
        path (with governance, sandbox, audit) lives outside this
        module — the MCP server only handles protocol framing.
    server_name:
        Returned in the ``initialize`` response. Defaults to ``coreiq``.
    server_version:
        Returned in the ``initialize`` response.
    """

    PROTOCOL_VERSION = "2024-11-05"

    def __init__(
        self,
        *,
        registry: ToolRegistry,
        tool_invoker: Optional[ToolInvoker] = None,
        server_name: str = "coreiq",
        server_version: str = "0.3.0",
    ) -> None:
        self._registry = registry
        self._invoker = tool_invoker
        self._server_name = server_name
        self._server_version = server_version

    # ------------------------------------------------------------------
    # Public dispatch entry point
    # ------------------------------------------------------------------

    async def handle(self, request: dict) -> Optional[dict]:
        """Handle a single JSON-RPC request and return the response dict.

        Returns ``None`` for notifications (requests without an ``id``
        field) per the JSON-RPC 2.0 spec — notifications never get a
        response.

        Never raises: every exception path produces a JSON-RPC error
        response so a misbehaving client can't crash the server.
        """
        if not isinstance(request, dict):
            return _error(None, INVALID_REQUEST, "Request must be a JSON object")

        req_id = request.get("id")
        method = request.get("method")
        params = request.get("params") or {}

        if not isinstance(method, str) or not method:
            return _error(req_id, INVALID_REQUEST, "Missing 'method' field")

        # Notifications (no id) get acknowledged silently.
        is_notification = "id" not in request

        try:
            handler = self._method_handlers().get(method)
            if handler is None:
                if is_notification:
                    return None
                return _error(req_id, METHOD_NOT_FOUND, f"Method not found: {method}")

            result = await handler(params)
            if is_notification:
                return None
            return _success(req_id, result)
        except _MCPError as exc:
            if is_notification:
                return None
            return _error(req_id, exc.code, exc.message, data=exc.data)
        except Exception as exc:  # pragma: no cover — defensive
            logger.exception("MCP handler crashed for method=%s", method)
            if is_notification:
                return None
            return _error(req_id, INTERNAL_ERROR, f"Internal error: {exc}")

    # ------------------------------------------------------------------
    # Method handlers
    # ------------------------------------------------------------------

    def _method_handlers(self) -> dict:
        return {
            "initialize": self._handle_initialize,
            "ping": self._handle_ping,
            "tools/list": self._handle_tools_list,
            "tools/call": self._handle_tools_call,
            # Notifications we accept but ignore
            "notifications/initialized": self._handle_noop,
            "notifications/cancelled": self._handle_noop,
        }

    async def _handle_initialize(self, params: dict) -> dict:
        return {
            "protocolVersion": self.PROTOCOL_VERSION,
            "capabilities": {
                "tools": {"listChanged": True},
            },
            "serverInfo": {
                "name": self._server_name,
                "version": self._server_version,
            },
        }

    async def _handle_ping(self, params: dict) -> dict:
        return {}

    async def _handle_tools_list(self, params: dict) -> dict:
        # No pagination — coreiq registries are typically <100 tools.
        # If a registry grows past that we can add nextCursor handling.
        tools = [tool_to_mcp(spec) for spec in self._registry.all()]
        return {"tools": tools}

    async def _handle_tools_call(self, params: dict) -> dict:
        name = params.get("name")
        if not isinstance(name, str) or not name:
            raise _MCPError(INVALID_PARAMS, "tools/call requires 'name' field")

        spec = self._registry.get(name)
        if spec is None:
            raise _MCPError(TOOL_NOT_FOUND, f"Tool not found: {name}")

        if self._invoker is None:
            raise _MCPError(
                TOOL_EXECUTION_FAILED,
                "MCP server has no tool_invoker configured — tool calls are read-only.",
            )

        arguments = mcp_call_to_tool_args(params.get("arguments"))
        try:
            result = self._invoker(name, arguments)
            if hasattr(result, "__await__"):
                result = await result
        except Exception as exc:
            raise _MCPError(
                TOOL_EXECUTION_FAILED,
                f"Tool {name!r} raised: {exc}",
            ) from exc

        # MCP spec says tools/call returns ``{content: [...], isError: false}``.
        # Each content item has a type — we use "text" by default.
        if isinstance(result, dict) and "content" in result:
            return result
        return {
            "content": [
                {"type": "text", "text": str(result)},
            ],
            "isError": False,
        }

    async def _handle_noop(self, params: dict) -> dict:
        return {}


# ---------------------------------------------------------------------------
# JSON-RPC envelope helpers
# ---------------------------------------------------------------------------


def _success(req_id: Any, result: Any) -> dict:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _error(req_id: Any, code: int, message: str, *, data: Any = None) -> dict:
    err: dict = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": "2.0", "id": req_id, "error": err}


class _MCPError(Exception):
    def __init__(self, code: int, message: str, *, data: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.data = data


# ---------------------------------------------------------------------------
# FastAPI integration
# ---------------------------------------------------------------------------


def mount_mcp_router(
    app: Any,
    server: MCPServer,
    *,
    path: str = "/mcp",
) -> None:
    """Mount a FastAPI POST handler at ``path`` that proxies to ``server``.

    Imports FastAPI lazily so this module is importable even when
    ``coreiq.tools`` is used in a non-server context (CLI tool listing,
    test fixtures).

    The handler accepts a raw JSON body via Starlette's
    ``request.body()`` (parsed manually with stdlib ``json``) rather
    than via FastAPI's Pydantic body parsing because:
      1. JSON-RPC 2.0 batch requests are top-level arrays, which
         FastAPI's automatic body validation rejects.
      2. ``__future__`` annotations in this module turn the
         ``Request`` type hint into a string at import time, which
         under some FastAPI versions makes the parameter look like a
         query parameter rather than the special Starlette Request
         object.
    """
    try:
        from starlette.responses import JSONResponse, Response
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "mount_mcp_router requires fastapi/starlette. Install with: pip install fastapi"
        ) from exc

    import json as _json

    async def mcp_endpoint(req):  # no annotation — bound at runtime via add_route
        try:
            body_bytes = await req.body()
            payload = _json.loads(body_bytes)
        except Exception:
            return JSONResponse(
                content=_error(None, PARSE_ERROR, "Failed to parse JSON body"),
                status_code=400,
            )

        # Batch requests (JSON-RPC 2.0 supports an array of requests).
        if isinstance(payload, list):
            responses = []
            for item in payload:
                resp = await server.handle(item)
                if resp is not None:
                    responses.append(resp)
            return JSONResponse(content=responses)

        resp = await server.handle(payload)
        if resp is None:
            # Notifications get a 204 with no body.
            return Response(status_code=204)
        return JSONResponse(content=resp)

    # Use Starlette's add_route directly (bypassing FastAPI's signature
    # introspection) so the handler signature is treated as a raw
    # ASGI-style ``(request) -> response`` callable.
    async def _starlette_handler(request):
        return await mcp_endpoint(request)

    app.router.add_route(
        path,
        _starlette_handler,
        methods=["POST"],
        name="mcp_endpoint",
    )
