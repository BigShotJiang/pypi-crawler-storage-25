"""Model Context Protocol (MCP) support for CoreIQ.

Exposes coreiq's :class:`coreiq.tools.registry.ToolRegistry` over the
Model Context Protocol so MCP-aware clients (Claude Desktop, Cursor,
OpenAI Agents SDK with MCP, Anthropic API with MCP server config) can
discover and call tools registered with coreiq.

This module ships a minimal, dependency-free MCP server implementation
that speaks the JSON-RPC 2.0 wire format the spec requires. We do NOT
depend on the upstream `mcp` package because (a) it's a fast-moving
spec and pinning it adds churn, (b) the surface we need is small enough
that ~250 LOC of stdlib JSON-RPC is simpler than wrapping a third-party
client.

Public API
----------

- :class:`MCPServer` — protocol handler. Stateless; takes a
  :class:`ToolRegistry` and a tool-execution callable, returns
  JSON-RPC responses for incoming JSON-RPC requests.
- :func:`mount_mcp_router` — FastAPI integration. Mounts the protocol
  handler at the configured route (default `/mcp`).
- :func:`tool_to_mcp` — converts a :class:`coreiq.tools.registry.ToolSpec`
  to an MCP `Tool` dict in the wire format.

See https://modelcontextprotocol.io/specification for the protocol spec.
"""
from .schema_adapter import tool_to_mcp
from .server import MCPServer, mount_mcp_router

__all__ = ["MCPServer", "mount_mcp_router", "tool_to_mcp"]
