"""Translation between CoreIQ ToolSpec and MCP Tool wire format.

The good news: ``ToolSpec.parameters`` is already a JSON Schema dict
(coreiq's tool registry has stored schemas in this shape since v0.1),
and the MCP spec defines a Tool's ``inputSchema`` as "a JSON Schema
object that defines the expected parameters for the tool". So the
translation is essentially a field rename plus a couple of safety
checks.

This module is a separate file from server.py so it's trivial to unit
test without standing up a FastAPI app.
"""
from __future__ import annotations

from typing import Any, Mapping

from ..tools.registry import ToolSpec

# Maximum length of a tool name in the MCP wire format. The spec doesn't
# pin a hard limit, but Claude Desktop and Cursor both fail when names
# exceed ~100 characters; coreiq's tool registry already enforces a
# 2000-char limit on descriptions, so we just guard names here.
_MAX_TOOL_NAME_LEN = 128


def tool_to_mcp(spec: ToolSpec) -> dict:
    """Convert a CoreIQ ToolSpec to an MCP ``Tool`` dict.

    The output format follows the
    `MCP spec <https://modelcontextprotocol.io/specification>`_::

        {
            "name": "calculator",
            "description": "Performs arithmetic operations",
            "inputSchema": {
                "type": "object",
                "properties": {...},
                "required": [...]
            }
        }

    The function never raises — invalid specs (empty name, oversized
    name) are normalised on the fly so a registry with one bad tool
    doesn't break ``listTools`` for the whole server.
    """
    name = (spec.name or "").strip()
    if not name:
        name = "unnamed_tool"
    if len(name) > _MAX_TOOL_NAME_LEN:
        name = name[:_MAX_TOOL_NAME_LEN]

    description = spec.description or ""

    # MCP requires inputSchema to be a JSON Schema object. coreiq stores
    # this in `parameters`. If the registered tool has no parameters at
    # all, emit an empty object schema (legal in JSON Schema and the
    # MCP spec — many tools take no input).
    input_schema: dict
    if isinstance(spec.parameters, Mapping) and spec.parameters:
        input_schema = dict(spec.parameters)
    else:
        input_schema = {"type": "object", "properties": {}}

    # The spec requires `type: "object"` at the root of inputSchema.
    # If the registered schema didn't include it, add it.
    if "type" not in input_schema:
        input_schema["type"] = "object"
    if "properties" not in input_schema and input_schema["type"] == "object":
        input_schema["properties"] = {}

    return {
        "name": name,
        "description": description,
        "inputSchema": input_schema,
    }


def mcp_call_to_tool_args(mcp_args: Any) -> dict:
    """Normalize an MCP ``tools/call`` arguments value into a flat dict.

    The MCP spec says ``tools/call`` requests carry an ``arguments``
    field that should be a JSON object. We accept None / non-dict
    values defensively because some clients send the field empty when
    a tool takes no input.
    """
    if mcp_args is None:
        return {}
    if isinstance(mcp_args, dict):
        return dict(mcp_args)
    # Anything else (list, string, number) gets wrapped under a single
    # ``input`` key so the tool handler can decide what to do with it.
    return {"input": mcp_args}
