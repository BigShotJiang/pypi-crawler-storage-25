from __future__ import annotations

import asyncio
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Any, Dict, Literal, Optional

from .store.writer import get_writer

_logger = logging.getLogger("coreiq")
_hook_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="coreiq-hook")

if TYPE_CHECKING:
    from .evolution.feedback import FeedbackRecorder
    from .evolution.sdk import EvolutionSDK
    from .evolution.evaluator import EvalEngine
    from .security.scanner import ScanResult
    from .performance.budget import BudgetTracker
    from .performance.cache import InMemorySemanticCache
    from .performance.router import ModelRouter
    from .security.firewall import AIFirewall
    from .prompts.registry import PromptRegistry
    from .status import StatusReport

Level = Literal["debug", "info", "warning", "error", "critical"]
_VALID_LEVELS = {"debug", "info", "warning", "error", "critical"}
_KNOWN_PROVIDERS = {"openai", "anthropic", "vllm", "sglang", "openai_compat"}


class _ToolsInterface:
    """Unified interface for tool registration, validation, and routing."""

    def __init__(self, registry, validator, router, evolution=None):
        self._registry = registry
        self._validator = validator
        self._router = router
        self._evolution = evolution  # optional EvolutionSDK ref for win-rate tracking

    def register(self, tools, *, defer_loading: bool = False) -> None:
        """Register tool specs.

        Args:
            tools: List of tool dicts with {name, description, parameters}.
            defer_loading: When True, tools go into the deferred catalog and are
                only loaded into context when explicitly searched. Per-tool
                ``"defer_loading"`` key overrides this batch default.
        """
        self._registry.register(tools, defer_loading=defer_loading)

    def validate(self, tool_name: str, args_json: str):
        """Validate a JSON argument string against the named tool's parameter schema."""
        return self._validator.validate(tool_name, args_json)

    def select(self, query: str, top_k: int = 5):
        """Return the top-k most relevant tools for a natural-language query."""
        return self._router.select(query, top_k)

    def search(self, query: str, top_k: int = 5):
        """Search the deferred tool catalog and return a ToolSearchResult.

        Only considers tools registered with ``defer_loading=True``. Uses
        semantic embeddings (sentence-transformers) when available, with
        evolution-blended scoring when usage data exists.

        Args:
            query: Natural language description of what you need.
            top_k: Maximum number of tools to return (default 5).

        Returns:
            ToolSearchResult with tool_refs, similarity_scores, and tokens_saved.
        """
        from .tools.catalog import ToolSearchResult

        hits = self._router.select_deferred(query, top_k)
        specs = [spec for spec, _ in hits]
        return ToolSearchResult(
            tool_refs=[spec.name for spec in specs],
            similarity_scores=[round(score, 4) for _, score in hits],
            query=query,
            top_k=top_k,
            tokens_saved=self._router.token_savings(specs),
        )

    def resolve(self, tool_refs: list) -> list:
        """Load full ToolSpec objects from a list of tool names.

        Silently skips names not in the registry.

        Args:
            tool_refs: List of tool names (e.g. from ToolSearchResult.tool_refs).

        Returns:
            List of ToolSpec objects in the same order as tool_refs.
        """
        return [s for name in tool_refs if (s := self._registry.get(name)) is not None]

    def context_budget(self, selected, tokens_per_tool: int = 200) -> int:
        """Estimate tokens saved by sending selected tools instead of the full catalog."""
        return self._router.token_savings(selected, tokens_per_tool)

    def record_usage(self, tool_name: str, outcome: float) -> None:
        """Record a tool usage outcome to improve future ranking.

        Feeds into Thompson sampling (EvolutionSDK) when available and updates
        the router's evolution-blended score for the tool.

        Args:
            tool_name: Name of the tool that was used.
            outcome: Success score in [0.0, 1.0] — 1.0 is a great result,
                0.0 is a failure.
        """
        if not 0.0 <= outcome <= 1.0:
            raise ValueError(f"outcome must be in [0.0, 1.0], got {outcome}")
        if self._evolution is not None:
            try:
                self._evolution.add_variant(tool_name)
                signal = "thumbs_up" if outcome >= 0.5 else "thumbs_down"
                self._evolution.record_outcome(tool_name, signal)
                arm = self._evolution._get_bandit().get_arm(tool_name)
                if arm is not None:
                    self._router.update_win_rate(tool_name, arm.win_rate)
            except Exception:
                pass  # evolution integration must not break tool usage

    def select_within_budget(self, query: str, token_budget: int) -> list:
        """Select tools by relevance until the token budget is filled.

        Args:
            query: Natural language description of what you need.
            token_budget: Maximum tokens to allocate for tool definitions.

        Returns:
            List of ToolSpec objects fitting within the budget.
        """
        return self._router.select_within_budget(query, token_budget)

    def token_savings(self, selected, tokens_per_tool: int = 200) -> int:
        """Return the estimated token savings from using a subset of tools."""
        return self._router.token_savings(selected, tokens_per_tool)

    def __len__(self) -> int:
        """Return the number of registered tools."""
        return len(self._registry)


class CoreIQClient:
    """Primary client for CoreIQ — event logging, tracing, security, and performance features."""

    def __init__(self, db_path=None, api_key=None, log_level="info", provider="openai_compat", model=None):
        """Initialise a CoreIQ client with optional storage, auth, and provider settings."""
        from .exceptions import ConfigError

        if provider not in _KNOWN_PROVIDERS:
            raise ConfigError(f"provider must be one of {sorted(_KNOWN_PROVIDERS)}, got '{provider}'")
        if log_level not in _VALID_LEVELS:
            raise ConfigError(f"log_level must be one of {sorted(_VALID_LEVELS)}, got '{log_level}'")
        self.db_path = db_path
        self.api_key = api_key
        self.log_level = log_level
        import os

        self.provider = provider
        self.model = model or os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")
        self._feedback: FeedbackRecorder | None = None
        self._evolution: EvolutionSDK | None = None
        self._eval: EvalEngine | None = None
        self._tools_registry = None
        self._tools_validator = None
        self._tools_router = None
        self._cache: InMemorySemanticCache | None = None
        self._budget: BudgetTracker | None = None
        self._router: ModelRouter | None = None
        self._event_hooks: list = []

    def __enter__(self) -> CoreIQClient:
        """Enter sync context manager — returns self."""
        return self

    def __exit__(self, *exc) -> None:
        """Exit sync context manager — flushes and closes the client."""
        self.close()

    async def __aenter__(self) -> "CoreIQClient":
        """Async context-manager entry — returns self.

        Usage::

            async with CoreIQClient() as client:
                await client.alog_event("started")
        """
        return self

    async def __aexit__(self, *args) -> None:
        """Async context-manager exit — flushes and closes the client."""
        self.close()

    def close(self) -> None:
        """Flush pending writes and release resources."""
        try:
            get_writer().flush()
            self._closed = True
        except Exception:
            pass

    def on_event(self, callback) -> None:
        """Register a callback invoked on every log_event.

        Use this to forward events to SIEM, OTel, webhooks, or any external system::

            def forward_to_siem(event: dict):
                requests.post("https://siem.corp.com/api/events", json=event)

            client.on_event(forward_to_siem)
            client.log_event("user login", user_id="u1")  # → also calls forward_to_siem
        """
        self._event_hooks.append(callback)

    @property
    def feedback(self) -> FeedbackRecorder:
        """Lazy-loaded FeedbackRecorder for capturing thumbs-up/down signals."""
        if self._feedback is None:
            from .evolution.feedback import get_feedback_recorder

            self._feedback = get_feedback_recorder()
        return self._feedback

    @property
    def evolution(self) -> EvolutionSDK:
        """Lazy-loaded EvolutionSDK for prompt A/B testing and bandit optimisation."""
        if self._evolution is None:
            from .evolution.sdk import EvolutionSDK

            self._evolution = EvolutionSDK()
        return self._evolution

    @property
    def tools(self) -> _ToolsInterface:
        """Lazy-loaded tools interface for registration, validation, and semantic routing."""
        if self._tools_registry is None:
            from .tools.registry import ToolRegistry
            from .tools.validator import ToolValidator
            from .tools.router import ToolRouter

            self._tools_registry = ToolRegistry()
            self._tools_validator = ToolValidator(self._tools_registry)
            self._tools_router = ToolRouter(self._tools_registry)
        return _ToolsInterface(
            self._tools_registry,
            self._tools_validator,
            self._tools_router,
            self._evolution,  # None until client.evolution is first accessed
        )

    @property
    def firewall(self) -> "AIFirewall":
        """AI Firewall — multi-layered WAF for LLM inputs.

        Examples::

            verdict = client.firewall.scan("ignore all previous instructions")
            if verdict.blocked:
                print(f"Blocked: {verdict.details}")

            # Canary tokens
            safe_prompt = client.firewall.inject_canary(system_prompt, request_id)
            leak = client.firewall.detect_canary(output, request_id)
        """
        if not hasattr(self, "_firewall") or self._firewall is None:
            from .security.firewall import AIFirewall

            self._firewall = AIFirewall()
        return self._firewall

    @property
    def prompts(self) -> "PromptRegistry":
        """Prompt Registry — git-like version control for prompts.

        Examples::

            client.prompts.register("support-reply", version="1.0",
                template="You are a support agent for {{company}}...")

            client.prompts.deploy("support-reply", version="1.0",
                traffic=0.1)  # 10% canary

            client.prompts.set_rollback_policy("support-reply",
                metric="thumbs_down_rate", threshold=0.15)

            resolved = client.prompts.resolve("support-reply",
                context_key=user_id)
        """
        if not hasattr(self, "_prompts") or self._prompts is None:
            from .prompts.registry import PromptRegistry

            self._prompts = PromptRegistry()
        return self._prompts

    @property
    def eval(self) -> "EvalEngine":
        """Lazy-loaded EvalEngine for running LLM output evaluations."""
        if self._eval is None:
            from .evolution.evaluator import EvalEngine

            self._eval = EvalEngine()
        return self._eval

    @property
    def cache(self) -> "InMemorySemanticCache":
        """Lazy-loaded in-process semantic cache for deduplicating LLM calls."""
        if self._cache is None:
            from .performance.cache import InMemorySemanticCache

            self._cache = InMemorySemanticCache()
        return self._cache

    def scan(self, messages: list[dict], *, output_rules=None) -> ScanResult:
        """Scan messages for injection, PII, and output violations.

        Args:
            messages: Conversation messages to scan.
            output_rules: Optional list of GuardRule for custom output checks.
        """
        from .security.scanner import scan_messages

        return scan_messages(messages, output_rules=output_rules)

    def scan_and_redact(self, messages: list[dict], *, output_rules=None) -> tuple:
        """Scan and return (ScanResult, redacted_messages).

        Combines security scanning with PII redaction in one call::

            result, clean_msgs = client.scan_and_redact(messages)
            if result.clean:
                response = llm.call(messages=clean_msgs)
        """
        from .security.scanner import scan_and_redact

        return scan_and_redact(messages, output_rules=output_rules)

    async def ascan(self, messages: list[dict], *, output_rules=None) -> "ScanResult":
        """Async counterpart of :meth:`scan`.

        Usage::

            result = await client.ascan(messages)
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.scan(messages, output_rules=output_rules),
        )

    async def ascan_and_redact(self, messages: list[dict], *, output_rules=None) -> tuple:
        """Async counterpart of :meth:`scan_and_redact`.

        Usage::

            result, clean_msgs = await client.ascan_and_redact(messages)
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.scan_and_redact(messages, output_rules=output_rules),
        )

    @property
    def budget(self) -> BudgetTracker:
        """Lazy-loaded BudgetTracker for enforcing per-request token/cost limits."""
        if self._budget is None:
            from .performance.budget import BudgetTracker, BudgetConfig

            self._budget = BudgetTracker(BudgetConfig())
        return self._budget

    @property
    def router(self) -> ModelRouter:
        """Lazy-loaded ModelRouter for latency/cost-aware model selection."""
        if self._router is None:
            from .performance.router import ModelRouter

            self._router = ModelRouter(default_model=self.model)
        return self._router

    def log_event(
        self,
        message: str,
        metadata: Optional[Dict[str, Any]] = None,
        *,
        level: Level = "info",
        source: Optional[str] = None,
        trace_id: Optional[str] = None,
        **extra: Any,
    ) -> str:
        """Log a structured event to the CoreIQ store.

        Args:
            message:  Human-readable description of the event.
            metadata: Arbitrary key/value pairs attached to the event.
            level:    Severity — "debug", "info", "warning", "error", "critical".
            source:   Optional origin label (e.g. module name, agent ID).
            trace_id: Optionally link this event to an existing trace.
            **extra:  Extra key/value pairs merged into metadata.

        Returns:
            The generated event ID (UUID string).
        """
        if trace_id is None:
            from .tracing import get_current_trace_id

            trace_id = get_current_trace_id()
        if extra:
            metadata = {**(metadata or {}), **extra}
        _validate_level(level)
        try:
            event_id = get_writer().insert_event(
                message=message,
                metadata=metadata,
                level=level,
                source=source,
                trace_id=trace_id,
            )
            # Invoke event hooks in background threads (non-blocking)
            if self._event_hooks:
                event_data = {
                    "id": event_id,
                    "message": message,
                    "level": level,
                    "metadata": metadata,
                    "source": source,
                    "trace_id": trace_id,
                }
                for hook in self._event_hooks:
                    _hook_executor.submit(hook, event_data)
            return event_id
        except Exception as e:
            _logger.error("Failed to write event: %s", e)
            from .exceptions import DatabaseError

            raise DatabaseError(f"Failed to log event: {e}") from e

    async def alog_event(
        self,
        message: str,
        *,
        level: Level = "info",
        metadata: Optional[Dict[str, Any]] = None,
        source: Optional[str] = None,
        trace_id: Optional[str] = None,
    ) -> str:
        """Async counterpart of :meth:`log_event`.

        Usage::

            event_id = await client.alog_event("user signed up", level="info",
                                                metadata={"plan": "pro"})
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.log_event(
                message,
                level=level,
                metadata=metadata,
                source=source,
                trace_id=trace_id,
            ),
        )

    def query_events(
        self,
        *,
        level: Optional[str] = None,
        source: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict]:
        """Query stored events programmatically.

        Args:
            level:  Filter by level (debug, info, warning, error, critical).
            source: Filter by source label.
            limit:  Max rows to return (default 100).

        Returns:
            List of event dicts with keys: id, level, message, metadata, source, trace_id, ts.
        """
        from .store.db import get_shared_connection

        conn = get_shared_connection()
        where, params = [], []
        if level:
            where.append("level = ?")
            params.append(level)
        if source:
            where.append("source = ?")
            params.append(source)
        clause = ("WHERE " + " AND ".join(where)) if where else ""
        rows = conn.execute(
            f"SELECT * FROM events {clause} ORDER BY ts DESC LIMIT ?",
            (*params, limit),
        ).fetchall()
        return [
            {
                "id": r["id"],
                "level": r["level"],
                "message": r["message"],
                "metadata": json.loads(r["meta_json"]) if r["meta_json"] else None,
                "source": r["source"],
                "trace_id": r["trace_id"],
                "ts": r["ts"],
            }
            for r in rows
        ]

    def status(self) -> "StatusReport":
        """Return a zero-token system health summary (last 7 days).

        Usage::

            status = client.status()
            print(status)             # human-readable
            status.to_dict()          # machine-readable
        """
        from .status import build_status

        return build_status()

    async def astatus(self) -> "StatusReport":
        """Async counterpart of :meth:`status`.

        Usage::

            report = await client.astatus()
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.status)

    def _record_tool_call(
        self,
        trace_id: str,
        tool_name: str,
        args: Dict[str, Any],
        valid: bool = True,
        error: Optional[str] = None,
    ) -> None:
        get_writer().insert_tool_call(
            trace_id=trace_id,
            tool_name=tool_name,
            args_json=json.dumps(args),
            valid=valid,
            error=error,
        )


def _validate_level(level: str) -> str:
    if level not in _VALID_LEVELS:
        from .exceptions import ValidationError

        raise ValidationError(f"level must be one of {sorted(_VALID_LEVELS)}, got '{level}'")
    return level


def log_event(
    message: str,
    metadata: Optional[Dict[str, Any]] = None,
    *,
    level: Level = "info",
    source: Optional[str] = None,
    trace_id: Optional[str] = None,
    **extra: Any,
) -> str:
    """Module-level convenience wrapper for logging a structured event.

    Usage::

        import coreiq
        coreiq.log_event("user signed up", {"plan": "pro", "user_id": "u_123"})
        coreiq.log_event("payment failed", {"amount": 49.99}, level="error")
        coreiq.log_event("signup", plan="pro", user_id="u1")
    """
    if trace_id is None:
        from .tracing import get_current_trace_id

        trace_id = get_current_trace_id()
    if extra:
        metadata = {**(metadata or {}), **extra}
    _validate_level(level)
    try:
        return get_writer().insert_event(
            message=message,
            metadata=metadata,
            level=level,
            source=source,
            trace_id=trace_id,
        )
    except Exception as e:
        _logger.error("Failed to write event: %s", e)
        from .exceptions import DatabaseError

        raise DatabaseError(f"Failed to log event: {e}") from e
