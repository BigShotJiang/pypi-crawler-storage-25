"""Hallucination judge — detects fabricated facts in LLM responses."""
from typing import Optional

from .base import EvalScore, JudgeProvider
from .faithfulness import _call_judge

_PROMPT_TEMPLATE = """\
You are an expert evaluator detecting hallucinations in AI responses.
A hallucination is a claim that is not supported by the context and cannot be verified.
Score the response from 0.0 (heavy hallucination — many fabricated facts) to 1.0 (no hallucination — all claims verifiable).

Context: {context}
Response: {response}

Return ONLY a JSON object: {{"score": <float 0.0-1.0>, "rationale": "<one sentence>"}}
"""


class HallucinationJudge(JudgeProvider):
    """Detects hallucinated facts in LLM responses. Lower score = more hallucination."""

    def __init__(self, model: str = "", provider: str = "openai_compat"):
        import os
        self._model = model or os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")
        self._provider = provider

    @property
    def dimension(self) -> str:
        return "hallucination"

    async def evaluate(
        self,
        prompt: str,
        response: str,
        context: str = "",
        trace_id: Optional[str] = None,
    ) -> EvalScore:
        judge_prompt = _PROMPT_TEMPLATE.format(context=context or prompt, response=response)
        score, rationale = await _call_judge(judge_prompt, self._model, self._provider)
        return EvalScore(
            dimension=self.dimension,
            score=score,
            rationale=rationale,
            model=self._model,
            trace_id=trace_id,
        )
