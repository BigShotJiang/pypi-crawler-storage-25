"""Answer relevance judge — measures how relevant the response is to the question."""
from typing import Optional

from .base import EvalScore, JudgeProvider
from .faithfulness import _call_judge

_PROMPT_TEMPLATE = """\
You are an expert evaluator assessing answer relevance.
Score how relevant and directly responsive the answer is to the question.
1.0 = directly and completely answers the question. 0.0 = completely off-topic.

Question: {prompt}
Answer: {response}

Return ONLY a JSON object: {{"score": <float 0.0-1.0>, "rationale": "<one sentence>"}}
"""


class RelevanceJudge(JudgeProvider):
    """Evaluates whether the LLM response directly answers the question."""

    def __init__(self, model: str = "", provider: str = "openai_compat"):
        import os
        self._model = model or os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")
        self._provider = provider

    @property
    def dimension(self) -> str:
        return "answer_relevance"

    async def evaluate(
        self,
        prompt: str,
        response: str,
        context: str = "",
        trace_id: Optional[str] = None,
    ) -> EvalScore:
        judge_prompt = _PROMPT_TEMPLATE.format(prompt=prompt, response=response)
        score, rationale = await _call_judge(judge_prompt, self._model, self._provider)
        return EvalScore(
            dimension=self.dimension,
            score=score,
            rationale=rationale,
            model=self._model,
            trace_id=trace_id,
        )
