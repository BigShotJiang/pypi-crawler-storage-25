"""Base classes for LLM-as-a-Judge evaluation."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class BuiltinJudge(str, Enum):
    FAITHFULNESS = "faithfulness"
    HALLUCINATION = "hallucination"
    ANSWER_RELEVANCE = "answer_relevance"
    TOXICITY = "toxicity"
    GROUNDEDNESS = "groundedness"


@dataclass
class EvalScore:
    dimension: str
    score: float          # 0.0 – 1.0 (higher = better, except hallucination where lower = better)
    rationale: str = ""
    model: str = ""
    trace_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class JudgeProvider(ABC):
    """Abstract base class for evaluation judges.

    Implement this to add custom evaluation dimensions::

        class MyJudge(JudgeProvider):
            @property
            def dimension(self) -> str:
                return "business_relevance"

            async def evaluate(self, prompt: str, response: str, context: str = "") -> EvalScore:
                ...
    """

    @property
    @abstractmethod
    def dimension(self) -> str:
        """The evaluation dimension name (e.g. 'faithfulness')."""
        ...

    @abstractmethod
    async def evaluate(
        self,
        prompt: str,
        response: str,
        context: str = "",
        trace_id: Optional[str] = None,
    ) -> EvalScore:
        """Evaluate a prompt/response pair. Returns EvalScore."""
        ...
