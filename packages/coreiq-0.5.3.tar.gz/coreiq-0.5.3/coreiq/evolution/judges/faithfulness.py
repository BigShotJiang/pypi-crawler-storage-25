"""Faithfulness judge — measures whether the response is faithful to the context."""
from typing import Optional

from .base import EvalScore, JudgeProvider

_PROMPT_TEMPLATE = """\
You are an expert evaluator assessing faithfulness.
Given the following context and response, score how faithfully the response is grounded in the context.
A score of 1.0 means every claim in the response can be directly traced to the context.
A score of 0.0 means the response contradicts or ignores the context entirely.

Context: {context}
Response: {response}

Return ONLY a JSON object with keys "score" (float 0.0-1.0) and "rationale" (one sentence).
Example: {{"score": 0.85, "rationale": "Most claims are grounded but one fact is unsupported."}}
"""


class FaithfulnessJudge(JudgeProvider):
    """Evaluates whether the LLM response faithfully reflects the provided context."""

    def __init__(self, model: str = "", provider: str = "openai_compat"):
        import os
        self._model = model or os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")
        self._provider = provider

    @property
    def dimension(self) -> str:
        return "faithfulness"

    async def evaluate(
        self,
        prompt: str,
        response: str,
        context: str = "",
        trace_id: Optional[str] = None,
    ) -> EvalScore:
        judge_prompt = _PROMPT_TEMPLATE.format(context=context or prompt, response=response)
        score, rationale = await _call_judge(judge_prompt, self._model, self._provider)
        return EvalScore(
            dimension=self.dimension,
            score=score,
            rationale=rationale,
            model=self._model,
            trace_id=trace_id,
        )


async def _call_judge(prompt: str, model: str, provider: str) -> tuple:
    """Call the judge LLM and parse score + rationale. Returns (score, rationale)."""
    import json
    try:
        if provider == "openai":
            import openai
            client = openai.AsyncOpenAI()
            resp = await client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=150,
            )
            raw = resp.choices[0].message.content or "{}"
        elif provider == "anthropic":
            import anthropic
            client = anthropic.AsyncAnthropic()
            resp = await client.messages.create(
                model=model,
                max_tokens=150,
                messages=[{"role": "user", "content": prompt}],
            )
            raw = resp.content[0].text if resp.content else "{}"
        else:
            return 0.5, "Judge provider not supported — returning neutral score."

        # Parse JSON response
        # Handle code blocks
        if "```" in raw:
            raw = raw.split("```")[1].lstrip("json").strip()
        data = json.loads(raw)
        score = float(data.get("score", 0.5))
        score = max(0.0, min(1.0, score))
        rationale = str(data.get("rationale", ""))
        return score, rationale
    except Exception as e:
        return 0.5, f"Judge evaluation failed: {e}"
