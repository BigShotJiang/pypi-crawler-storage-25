"""Groundedness judge — measures whether claims can be traced to source material."""
from typing import Optional

from .base import EvalScore, JudgeProvider
from .faithfulness import _call_judge

_PROMPT_TEMPLATE = """\
You are an expert evaluator assessing groundedness.
Score how well each claim in the response is supported by the provided source context.
1.0 = all claims are explicitly grounded in the source. 0.0 = no claims are supported.

Source context: {context}
Response: {response}

Return ONLY a JSON object: {{"score": <float 0.0-1.0>, "rationale": "<one sentence>"}}
"""


class GroundednessJudge(JudgeProvider):
    """Evaluates whether each claim is grounded in the source context."""

    def __init__(self, model: str = "", provider: str = "openai_compat"):
        import os
        self._model = model or os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")
        self._provider = provider

    @property
    def dimension(self) -> str:
        return "groundedness"

    async def evaluate(
        self,
        prompt: str,
        response: str,
        context: str = "",
        trace_id: Optional[str] = None,
    ) -> EvalScore:
        judge_prompt = _PROMPT_TEMPLATE.format(context=context or prompt, response=response)
        score, rationale = await _call_judge(judge_prompt, self._model, self._provider)
        return EvalScore(
            dimension=self.dimension,
            score=score,
            rationale=rationale,
            model=self._model,
            trace_id=trace_id,
        )
