"""Production→Dataset Flywheel.

Automatically promotes high-signal production traces to versioned eval datasets.
Human annotation hooks allow manual labeling. Integrates with the CI eval gate.

Usage::

    from coreiq.evolution import DatasetBuilder

    builder = DatasetBuilder(name="production_sample_v1")
    builder.add_from_traces(
        min_score=0.85,
        dimension="faithfulness",
        limit=100,
    )
    dataset = builder.build()
    print(dataset.size)  # → number of items
"""
from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("coreiq.evolution.dataset")


@dataclass
class DatasetItem:
    """A single item in an eval dataset."""
    id: str
    dataset_id: str
    trace_id: Optional[str]
    input_text: str
    output_text: str
    reference_output: Optional[str] = None
    labels: Dict[str, Any] = field(default_factory=dict)
    quality_score: Optional[float] = None
    source: str = "production"      # "production" | "manual" | "synthetic"
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class EvalDataset:
    """A versioned, named collection of eval examples."""
    id: str
    name: str
    version: int
    description: str = ""
    items: List[DatasetItem] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def size(self) -> int:
        return len(self.items)


class DatasetBuilder:
    """Builds eval datasets from production trace scores.

    Args:
        name: Dataset name (e.g. "production_sample_v1").
        description: Human-readable description.
        annotation_hook: Optional callable invoked for each item — use for human annotation.
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        annotation_hook: Optional[Callable[[DatasetItem], DatasetItem]] = None,
    ):
        self._name = name
        self._description = description
        self._annotation_hook = annotation_hook
        self._items: List[DatasetItem] = []

    def add_from_traces(
        self,
        min_score: float = 0.7,
        dimension: str = "faithfulness",
        limit: int = 100,
        include_low_quality: bool = False,
        min_tokens: int = 10,
    ) -> int:
        """Select production traces with high eval scores and add to the dataset.

        Args:
            min_score: Minimum eval score threshold (0.0–1.0).
            dimension: Which eval dimension to filter on.
            limit: Maximum number of traces to add.
            include_low_quality: If True, also include low-score traces (useful for contrast sets).
            min_tokens: Skip traces with fewer tokens than this.

        Returns:
            Number of items added.
        """
        from ..store.db import get_shared_connection
        conn = get_shared_connection()

        score_filter = ">=" if not include_low_quality else "<"
        try:
            rows = conn.execute(
                f"""
                SELECT t.id as trace_id, t.meta_json, t.input_tok, t.output_tok,
                       es.score, es.dimension
                FROM traces t
                JOIN eval_scores es ON es.trace_id = t.id
                WHERE es.dimension = ?
                  AND es.score {score_filter} ?
                  AND (t.input_tok + t.output_tok) >= ?
                ORDER BY es.score DESC
                LIMIT ?
                """,
                (dimension, min_score, min_tokens, limit),
            ).fetchall()
        except Exception as exc:
            logger.warning("Could not query traces for dataset: %s", exc)
            return 0

        added = 0
        for row in rows:
            meta = {}
            try:
                meta = json.loads(row["meta_json"]) if row["meta_json"] else {}
            except Exception:
                pass

            item = DatasetItem(
                id=str(uuid.uuid4()),
                dataset_id="",  # assigned when build() is called
                trace_id=row["trace_id"],
                input_text=meta.get("prompt", ""),
                output_text=meta.get("response", ""),
                quality_score=row["score"],
                labels={"dimension": row["dimension"], "score": row["score"]},
                source="production",
            )
            if self._annotation_hook:
                try:
                    item = self._annotation_hook(item)
                except Exception as ann_exc:
                    logger.debug("Annotation hook failed for %s: %s", item.trace_id, ann_exc)
            self._items.append(item)
            added += 1

        logger.info("Added %d items from traces (min_score=%.2f, dim=%s)", added, min_score, dimension)
        return added

    def add_item(
        self,
        input_text: str,
        output_text: str,
        *,
        trace_id: Optional[str] = None,
        reference_output: Optional[str] = None,
        labels: Optional[Dict[str, Any]] = None,
        quality_score: Optional[float] = None,
        source: str = "manual",
    ) -> DatasetItem:
        """Manually add a single item to the dataset."""
        item = DatasetItem(
            id=str(uuid.uuid4()),
            dataset_id="",
            trace_id=trace_id,
            input_text=input_text,
            output_text=output_text,
            reference_output=reference_output,
            labels=labels or {},
            quality_score=quality_score,
            source=source,
        )
        self._items.append(item)
        return item

    def build(self, version: int = 1) -> EvalDataset:
        """Finalise and persist the dataset.

        Args:
            version: Dataset version number.

        Returns:
            The persisted EvalDataset.
        """
        dataset_id = str(uuid.uuid4())
        # Assign dataset_id to all items
        for item in self._items:
            item.dataset_id = dataset_id

        dataset = EvalDataset(
            id=dataset_id,
            name=self._name,
            version=version,
            description=self._description,
            items=list(self._items),
        )
        self._persist(dataset)
        logger.info("Built dataset %r v%d with %d items", self._name, version, dataset.size)
        return dataset

    def _persist(self, dataset: EvalDataset) -> None:
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            conn.execute(
                """INSERT OR REPLACE INTO eval_datasets
                   (id, name, version, description, size, metadata_json, created_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    dataset.id, dataset.name, dataset.version,
                    dataset.description, dataset.size,
                    json.dumps(dataset.metadata), dataset.created_at,
                ),
            )
            for item in dataset.items:
                conn.execute(
                    """INSERT OR REPLACE INTO dataset_items
                       (id, dataset_id, trace_id, input_text, output_text,
                        reference_output, labels_json, quality_score, source, created_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (
                        item.id, item.dataset_id, item.trace_id,
                        item.input_text, item.output_text,
                        item.reference_output,
                        json.dumps(item.labels), item.quality_score,
                        item.source, item.created_at,
                    ),
                )
            conn.commit()
        except Exception as exc:
            logger.warning("Could not persist dataset: %s", exc)
