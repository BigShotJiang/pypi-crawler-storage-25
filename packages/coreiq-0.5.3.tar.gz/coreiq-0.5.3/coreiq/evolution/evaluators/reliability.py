from __future__ import annotations
from .accuracy import EvalResult


class ReliabilityEvaluator:
    """Checks if tool calls and structured outputs are valid/reliable."""

    name = "reliability"

    def evaluate_tool_calls(self, tool_calls: list[dict], allowed_tools: list[str] | None = None) -> EvalResult:
        if not tool_calls:
            return EvalResult(score=1.0, passed=True, reason="No tool calls", dimension="reliability")

        issues = []
        for tc in tool_calls:
            name = tc.get("function", {}).get("name", "")
            if allowed_tools and name not in allowed_tools:
                issues.append(f"Unauthorized tool: {name}")
            args = tc.get("function", {}).get("arguments", "{}")
            try:
                import json
                json.loads(args)
            except Exception:
                issues.append(f"Invalid JSON args for tool: {name}")

        score = 1.0 - (len(issues) / max(len(tool_calls), 1))
        return EvalResult(score=score, passed=not issues, reason="; ".join(issues) or "OK", dimension="reliability")

    def evaluate_json_output(self, output: str, schema: dict | None = None) -> EvalResult:
        import json
        try:
            json.loads(output)
            return EvalResult(score=1.0, passed=True, reason="Valid JSON", dimension="reliability")
        except Exception as e:
            return EvalResult(score=0.0, passed=False, reason=f"Invalid JSON: {e}", dimension="reliability")
