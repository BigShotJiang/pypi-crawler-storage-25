from __future__ import annotations
from .accuracy import EvalResult


class CriteriaEvaluator:
    """Evaluates a response against arbitrary criteria using LLM-as-judge."""

    name = "criteria"

    def __init__(self, criteria: list[str], model: str = "", threshold: float = 0.7):
        self.criteria = criteria
        self.model = model
        self.threshold = threshold

    def evaluate(self, input: str, output: str) -> list[EvalResult]:
        """Heuristic evaluation — returns one result per criterion."""
        results = []
        for criterion in self.criteria:
            # Simple length/content heuristic without LLM
            score = 0.5  # neutral without LLM
            results.append(EvalResult(score=score, passed=True, reason=f"Criterion '{criterion}' requires LLM eval", dimension=criterion))
        return results

    async def evaluate_with_llm(self, input: str, output: str, llm_client=None) -> list[EvalResult]:
        if llm_client is None:
            return self.evaluate(input, output)

        results = []
        for criterion in self.criteria:
            prompt = (
                f"Evaluate if the response meets this criterion: '{criterion}'\n\n"
                f"Input: {input}\n\nResponse: {output}\n\n"
                f"Score 0.0 to 1.0. Respond as JSON: {{\"score\": 0.X, \"reason\": \"...\"}}"
            )
            try:
                import json
                resp = await llm_client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}],
                    response_format={"type": "json_object"},
                    max_tokens=200,
                )
                data = json.loads(resp.choices[0].message.content)
                score = float(data.get("score", 0.5))
                results.append(EvalResult(score=score, passed=score >= self.threshold, reason=data.get("reason", ""), dimension=criterion))
            except Exception as e:
                results.append(EvalResult(score=0.0, passed=False, reason=f"LLM eval failed: {e}", dimension=criterion))
        return results
