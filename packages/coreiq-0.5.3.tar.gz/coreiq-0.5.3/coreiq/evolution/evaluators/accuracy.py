from __future__ import annotations
from dataclasses import dataclass


@dataclass
class EvalResult:
    score: float  # 0.0 - 1.0
    passed: bool
    reason: str
    dimension: str


class AccuracyEvaluator:
    """Evaluates response accuracy against a reference answer using LLM-as-judge."""

    name = "accuracy"
    threshold: float = 0.7

    def __init__(self, threshold: float = 0.7, model: str = ""):
        self.threshold = threshold
        self.model = model

    def evaluate(self, input: str, output: str, reference: str | None = None) -> EvalResult:
        if not reference:
            return EvalResult(score=0.5, passed=True, reason="No reference provided — skipped", dimension="accuracy")

        # Simple heuristic if no LLM available: keyword overlap
        ref_words = set(reference.lower().split())
        out_words = set(output.lower().split())
        if not ref_words:
            return EvalResult(score=1.0, passed=True, reason="Empty reference", dimension="accuracy")

        overlap = len(ref_words & out_words) / len(ref_words)
        passed = overlap >= self.threshold
        return EvalResult(
            score=round(overlap, 3),
            passed=passed,
            reason=f"Keyword overlap: {overlap:.1%}",
            dimension="accuracy",
        )

    async def evaluate_with_llm(self, input: str, output: str, reference: str, llm_client=None) -> EvalResult:
        """LLM-as-judge evaluation. llm_client should be an OpenAI-compatible client."""
        if llm_client is None:
            return self.evaluate(input, output, reference)

        prompt = (
            f"Rate the accuracy of the following response compared to the reference answer.\n\n"
            f"Input: {input}\n\nResponse: {output}\n\nReference: {reference}\n\n"
            f"Score from 0.0 to 1.0 and explain why. Respond with JSON: {{\"score\": 0.X, \"reason\": \"...\"}}"
        )
        try:
            import json
            resp = await llm_client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
                max_tokens=200,
            )
            data = json.loads(resp.choices[0].message.content)
            score = float(data.get("score", 0.5))
            return EvalResult(score=score, passed=score >= self.threshold, reason=data.get("reason", ""), dimension="accuracy")
        except Exception as e:
            return EvalResult(score=0.0, passed=False, reason=f"LLM eval failed: {e}", dimension="accuracy")
