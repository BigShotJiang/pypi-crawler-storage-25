"""Semantic Regression Testing — replay past inputs and compare outputs.

Detects quality regressions when prompts, models, or configs change.

Usage::

    tester = RegressionTester()
    tester.add_baseline("prompt-v1", input="Hello", output="Hi there!", scores={"tone": 0.9})
    result = tester.run_test(
        old_version="prompt-v1", new_version="prompt-v2",
        eval_fn=lambda inp: llm(inp), metrics=["tone", "relevance"])
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class BaselineSample:
    version: str
    input_text: str
    output_text: str
    scores: Dict[str, float] = field(default_factory=dict)


@dataclass
class RegressionResult:
    old_version: str
    new_version: str
    sample_size: int
    regression_detected: bool
    degraded_dimensions: List[str] = field(default_factory=list)
    improved_dimensions: List[str] = field(default_factory=list)
    dimension_scores: Dict[str, Dict[str, float]] = field(default_factory=dict)
    recommendation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "old_version": self.old_version,
            "new_version": self.new_version,
            "sample_size": self.sample_size,
            "regression_detected": self.regression_detected,
            "degraded_dimensions": self.degraded_dimensions,
            "improved_dimensions": self.improved_dimensions,
            "dimension_scores": self.dimension_scores,
            "recommendation": self.recommendation,
        }


class RegressionTester:
    """Semantic regression testing engine."""

    def __init__(self):
        self._baselines: Dict[str, List[BaselineSample]] = {}

    def add_baseline(
        self, version: str, input_text: str, output_text: str,
        scores: Optional[Dict[str, float]] = None,
    ) -> None:
        self._baselines.setdefault(version, []).append(
            BaselineSample(version=version, input_text=input_text,
                           output_text=output_text, scores=scores or {})
        )

    def get_baselines(self, version: str) -> List[BaselineSample]:
        return self._baselines.get(version, [])

    def compare_versions(
        self, old_version: str, new_version: str,
        new_scores: Optional[Dict[str, List[float]]] = None,
        threshold: float = 0.05,
    ) -> RegressionResult:
        """Compare scores between two versions.

        Args:
            old_version: Baseline version identifier.
            new_version: New version identifier.
            new_scores: Dict of metric_name -> list of scores for new version.
            threshold: Min score drop to count as regression.
        """
        old_samples = self._baselines.get(old_version, [])
        if not old_samples:
            return RegressionResult(
                old_version=old_version, new_version=new_version,
                sample_size=0, regression_detected=False,
                recommendation="No baseline data for old version",
            )

        # Aggregate old scores
        old_scores: Dict[str, List[float]] = {}
        for sample in old_samples:
            for metric, score in sample.scores.items():
                old_scores.setdefault(metric, []).append(score)

        old_avgs = {m: sum(s) / len(s) for m, s in old_scores.items() if s}

        if new_scores is None:
            new_scores = {}
        new_avgs = {m: sum(s) / len(s) for m, s in new_scores.items() if s}

        # Compare
        degraded = []
        improved = []
        dimension_scores: Dict[str, Dict[str, float]] = {}

        for metric in set(old_avgs) | set(new_avgs):
            old_val = old_avgs.get(metric, 0.0)
            new_val = new_avgs.get(metric, 0.0)
            diff = new_val - old_val
            dimension_scores[metric] = {
                "old_score": round(old_val, 4),
                "new_score": round(new_val, 4),
                "change": round(diff, 4),
                "change_pct": round(diff / old_val * 100, 1) if old_val > 0 else 0,
            }
            if diff < -threshold:
                degraded.append(metric)
            elif diff > threshold:
                improved.append(metric)

        regression = len(degraded) > 0
        rec = ""
        if regression:
            rec = f"Block deploy: {', '.join(degraded)} score(s) dropped"
        elif improved:
            rec = f"Safe to deploy: {', '.join(improved)} improved"
        else:
            rec = "No significant changes detected"

        return RegressionResult(
            old_version=old_version, new_version=new_version,
            sample_size=len(old_samples),
            regression_detected=regression,
            degraded_dimensions=degraded,
            improved_dimensions=improved,
            dimension_scores=dimension_scores,
            recommendation=rec,
        )
