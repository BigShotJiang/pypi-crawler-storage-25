from enum import Enum
from typing import Optional

from ..exceptions import ValidationError
from ..store.writer import get_writer


class FeedbackSignal(str, Enum):
    THUMBS_UP = "thumbs_up"
    THUMBS_DOWN = "thumbs_down"
    SCORE = "score"
    CORRECTION = "correction"


class FeedbackRecorder:
    def record(
        self,
        *,
        response_id: str,
        signal: str,
        value: float = 0.0,
        dimension: Optional[str] = None,
        correction: Optional[str] = None,
        user_id: Optional[str] = None,
        task_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> None:
        valid_signals = {e.value for e in FeedbackSignal}
        if signal not in valid_signals:
            raise ValidationError(
                f"Invalid signal '{signal}'. Must be one of: {sorted(valid_signals)}"
            )
        get_writer().insert_feedback(
            response_id=response_id,
            signal=signal,
            value=value,
            dimension=dimension,
            correction=correction,
            user_id=user_id,
            task_id=task_id,
            session_id=session_id,
        )

    def thumbs_up(self, response_id: str, *, dimension: Optional[str] = None,
                  user_id: Optional[str] = None, task_id: Optional[str] = None,
                  session_id: Optional[str] = None) -> None:
        self.record(response_id=response_id, signal="thumbs_up", value=1.0,
                    dimension=dimension, user_id=user_id, task_id=task_id, session_id=session_id)

    def thumbs_down(self, response_id: str, *, dimension: Optional[str] = None,
                    correction: Optional[str] = None,
                    user_id: Optional[str] = None, task_id: Optional[str] = None,
                    session_id: Optional[str] = None) -> None:
        self.record(response_id=response_id, signal="thumbs_down", value=0.0,
                    dimension=dimension, correction=correction,
                    user_id=user_id, task_id=task_id, session_id=session_id)

    def score(self, response_id: str, value: float, *, dimension: Optional[str] = None,
              user_id: Optional[str] = None, task_id: Optional[str] = None,
              session_id: Optional[str] = None) -> None:
        self.record(response_id=response_id, signal="score", value=value,
                    dimension=dimension, user_id=user_id, task_id=task_id, session_id=session_id)


_recorder: Optional[FeedbackRecorder] = None


def get_feedback_recorder() -> FeedbackRecorder:
    global _recorder
    if _recorder is None:
        _recorder = FeedbackRecorder()
    return _recorder
