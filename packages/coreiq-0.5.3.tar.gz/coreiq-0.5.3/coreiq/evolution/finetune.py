"""Fine-tune data management — collect, curate, and export training pairs."""
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class TrainingPair:
    prompt: str
    completion: str
    quality_score: float = 1.0
    source_trace_id: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    tags: list[str] = field(default_factory=list)

    def to_openai_format(self) -> dict:
        """Format as OpenAI fine-tuning JSONL record."""
        return {
            "messages": [
                {"role": "user", "content": self.prompt},
                {"role": "assistant", "content": self.completion},
            ]
        }

    def to_alpaca_format(self) -> dict:
        """Format as Alpaca-style instruction record."""
        return {
            "instruction": self.prompt,
            "input": "",
            "output": self.completion,
        }


class FinetuneDataset:
    """Collect and export fine-tuning pairs with quality filtering."""

    def __init__(self, min_quality_score: float = 0.7):
        self._pairs: list[TrainingPair] = []
        self._min_quality = min_quality_score

    def add(self, pair: TrainingPair) -> None:
        self._pairs.append(pair)

    def add_from_feedback(
        self,
        prompt: str,
        completion: str,
        *,
        signal: str,
        value: float = 0.0,
        correction: Optional[str] = None,
        trace_id: Optional[str] = None,
    ) -> Optional[TrainingPair]:
        """
        Create a training pair from feedback signal.
        - thumbs_up: use completion as-is
        - correction: use correction text as completion
        - thumbs_down / low score: skip
        """
        if signal == "thumbs_up":
            pair = TrainingPair(prompt=prompt, completion=completion,
                                quality_score=1.0, source_trace_id=trace_id,
                                tags=["thumbs_up"])
        elif signal == "correction" and correction:
            pair = TrainingPair(prompt=prompt, completion=correction,
                                quality_score=0.9, source_trace_id=trace_id,
                                tags=["correction"])
        elif signal == "score" and value >= self._min_quality:
            pair = TrainingPair(prompt=prompt, completion=completion,
                                quality_score=value, source_trace_id=trace_id,
                                tags=["scored"])
        else:
            return None
        self._pairs.append(pair)
        return pair

    def export_jsonl(self, path: str, *, fmt: str = "openai", min_score: Optional[float] = None) -> int:
        """Export to JSONL file. Returns number of records written."""
        threshold = min_score if min_score is not None else self._min_quality
        pairs = [p for p in self._pairs if p.quality_score >= threshold]
        with open(path, "w") as f:
            for pair in pairs:
                record = pair.to_openai_format() if fmt == "openai" else pair.to_alpaca_format()
                f.write(json.dumps(record) + "\n")
        return len(pairs)

    def __len__(self) -> int:
        return len(self._pairs)

    @property
    def stats(self) -> dict:
        if not self._pairs:
            return {"total": 0, "avg_quality": 0.0, "ready": 0}
        avg_q = sum(p.quality_score for p in self._pairs) / len(self._pairs)
        ready = sum(1 for p in self._pairs if p.quality_score >= self._min_quality)
        return {
            "total": len(self._pairs),
            "avg_quality": round(avg_q, 3),
            "ready": ready,
        }
