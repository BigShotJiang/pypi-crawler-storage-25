"""CI/CD Eval Gate — pass/fail quality gate for eval datasets.

Runs eval scores against configurable thresholds and exits with:
- 0 = PASS (all gates met)
- 1 = FAIL (one or more gates not met)

CLI usage::

    coreiq-eval-gate --dataset production_sample_v1 --gate "faithfulness>=0.85"
    echo $?   # 0=pass, 1=fail

Programmatic usage::

    from coreiq.evolution import EvalGate

    gate = EvalGate(dataset_name="production_sample_v1")
    gate.add_threshold("faithfulness", min_score=0.85)
    gate.add_threshold("hallucination", max_score=0.10)
    result = gate.run()
    print(result.passed, result.report)
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("coreiq.evolution.ci_gate")


@dataclass
class GateThreshold:
    dimension: str
    min_score: Optional[float] = None   # inclusive lower bound
    max_score: Optional[float] = None   # inclusive upper bound

    def check(self, score: float) -> Tuple[bool, str]:
        """Returns (passed, reason)."""
        if self.min_score is not None and score < self.min_score:
            return False, f"{self.dimension}={score:.3f} < required {self.min_score}"
        if self.max_score is not None and score > self.max_score:
            return False, f"{self.dimension}={score:.3f} > required max {self.max_score}"
        return True, f"{self.dimension}={score:.3f} OK"


@dataclass
class GateResult:
    dataset_name: str
    passed: bool
    thresholds: List[GateThreshold]
    scores: Dict[str, float]
    failures: List[str]
    report: str

    def __str__(self) -> str:
        return self.report


class EvalGate:
    """Configurable eval quality gate for CI/CD pipelines.

    Args:
        dataset_name: Name of the dataset to evaluate.
        dataset_version: Optional specific version (latest if None).
    """

    def __init__(self, dataset_name: str, dataset_version: Optional[int] = None):
        self._dataset_name = dataset_name
        self._dataset_version = dataset_version
        self._thresholds: List[GateThreshold] = []

    def add_threshold(
        self,
        dimension: str,
        min_score: Optional[float] = None,
        max_score: Optional[float] = None,
    ) -> "EvalGate":
        """Add a pass/fail threshold for an eval dimension.

        Args:
            dimension: Eval dimension name (e.g. "faithfulness", "hallucination").
            min_score: Minimum acceptable average score (inclusive).
            max_score: Maximum acceptable average score (inclusive, useful for toxicity).

        Returns:
            self for chaining.
        """
        self._thresholds.append(GateThreshold(dimension, min_score, max_score))
        return self

    def run(self) -> GateResult:
        """Execute the eval gate against the dataset.

        Computes average eval scores per dimension from the dataset items,
        then checks each threshold.

        Returns:
            GateResult with passed status and detailed report.
        """
        from ..store.db import get_shared_connection
        conn = get_shared_connection()

        # Load dataset
        if self._dataset_version is not None:
            ds_row = conn.execute(
                "SELECT * FROM eval_datasets WHERE name = ? AND version = ?",
                (self._dataset_name, self._dataset_version),
            ).fetchone()
        else:
            ds_row = conn.execute(
                "SELECT * FROM eval_datasets WHERE name = ? ORDER BY version DESC LIMIT 1",
                (self._dataset_name,),
            ).fetchone()

        if ds_row is None:
            msg = f"Dataset {self._dataset_name!r} not found"
            return GateResult(
                dataset_name=self._dataset_name,
                passed=False,
                thresholds=self._thresholds,
                scores={},
                failures=[msg],
                report=f"FAIL — {msg}",
            )

        dataset_id = ds_row["id"]
        # Get trace_ids from dataset items
        item_rows = conn.execute(
            "SELECT trace_id FROM dataset_items WHERE dataset_id = ? AND trace_id IS NOT NULL",
            (dataset_id,),
        ).fetchall()
        trace_ids = [r["trace_id"] for r in item_rows if r["trace_id"]]

        if not trace_ids:
            # Fall back to quality_score from dataset items
            score_rows = conn.execute(
                """SELECT labels_json, quality_score FROM dataset_items
                   WHERE dataset_id = ?""",
                (dataset_id,),
            ).fetchall()
            dim_scores: Dict[str, List[float]] = {}
            for row in score_rows:
                if row["quality_score"] is not None:
                    labels = json.loads(row["labels_json"]) if row["labels_json"] else {}
                    dim = labels.get("dimension", "quality")
                    dim_scores.setdefault(dim, []).append(row["quality_score"])
        else:
            # Aggregate eval_scores for these traces
            placeholders = ",".join("?" * len(trace_ids))
            score_rows = conn.execute(
                f"""SELECT dimension, AVG(score) as avg_score
                    FROM eval_scores
                    WHERE trace_id IN ({placeholders})
                    GROUP BY dimension""",
                trace_ids,
            ).fetchall()
            dim_scores = {r["dimension"]: [r["avg_score"]] for r in score_rows}

        avg_scores = {dim: sum(vs) / len(vs) for dim, vs in dim_scores.items() if vs}

        # Check thresholds
        failures = []
        lines = [f"Eval Gate: {self._dataset_name} (id={dataset_id})"]
        lines.append(f"Items: {ds_row['size'] or len(trace_ids)}")
        lines.append("")

        for threshold in self._thresholds:
            score = avg_scores.get(threshold.dimension)
            if score is None:
                msg = f"  ✗ {threshold.dimension}: no scores available"
                failures.append(msg)
                lines.append(msg)
                continue
            passed, reason = threshold.check(score)
            status = "✓" if passed else "✗"
            lines.append(f"  {status} {reason}")
            if not passed:
                failures.append(reason)

        overall = len(failures) == 0
        lines.append("")
        lines.append("PASS" if overall else f"FAIL ({len(failures)} threshold(s) not met)")

        return GateResult(
            dataset_name=self._dataset_name,
            passed=overall,
            thresholds=self._thresholds,
            scores=avg_scores,
            failures=failures,
            report="\n".join(lines),
        )


def _parse_gate_expr(expr: str) -> GateThreshold:
    """Parse a gate expression like 'faithfulness>=0.85' or 'toxicity<=0.05'."""
    for op in (">=", "<=", ">", "<"):
        if op in expr:
            dim, val_str = expr.split(op, 1)
            val = float(val_str.strip())
            dim = dim.strip()
            if op in (">=", ">"):
                return GateThreshold(dimension=dim, min_score=val)
            else:
                return GateThreshold(dimension=dim, max_score=val)
    raise ValueError(
        f"Invalid gate expression {expr!r}. Expected format: 'dimension>=value' or 'dimension<=value'"
    )


def main() -> None:
    """CLI entry point: coreiq-eval-gate"""
    parser = argparse.ArgumentParser(
        prog="coreiq-eval-gate",
        description="CoreIQ CI/CD eval quality gate — exits 0 on PASS, 1 on FAIL",
    )
    parser.add_argument("--dataset", required=True, help="Dataset name to evaluate")
    parser.add_argument("--version", type=int, default=None, help="Dataset version (latest if omitted)")
    parser.add_argument(
        "--gate", action="append", dest="gates", default=[],
        help="Threshold expression, e.g. 'faithfulness>=0.85'. Repeatable.",
    )
    parser.add_argument("--json", action="store_true", help="Output results as JSON")
    args = parser.parse_args()

    gate = EvalGate(dataset_name=args.dataset, dataset_version=args.version)
    for expr in args.gates:
        threshold = _parse_gate_expr(expr)
        gate.add_threshold(threshold.dimension, threshold.min_score, threshold.max_score)

    result = gate.run()

    if args.json:
        import json as _json
        print(_json.dumps({
            "dataset": result.dataset_name,
            "passed": result.passed,
            "scores": result.scores,
            "failures": result.failures,
        }))
    else:
        print(result.report)

    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    main()
