"""LLM-as-a-Judge Evaluation Engine.

Samples production traces and runs them through configurable judge prompts,
storing quality scores alongside trace records.

Usage::

    from coreiq.evolution import EvalEngine, BuiltinJudge

    engine = EvalEngine(
        judges=[BuiltinJudge.FAITHFULNESS, BuiltinJudge.HALLUCINATION],
        sample_rate=0.10,
        judge_model="openai/gpt-oss-120b",  # or set OPENAI_COMPATIBLE_DEFAULT_MODEL
    )

    # Evaluate a specific trace
    result = await engine.evaluate(trace_id="abc-123", prompt="...", response="...")

    # Start background sampling of production traffic
    engine.start_sampling()
"""
import asyncio
import logging
import random
from dataclasses import dataclass
from typing import Dict, List, Optional

logger = logging.getLogger("coreiq.evolution.evaluator")


@dataclass
class EvalResult:
    trace_id: str
    scores: Dict[str, float]
    rationales: Dict[str, str]
    judges_run: List[str]
    error: Optional[str] = None


class EvalEngine:
    """Async evaluation engine that runs LLM-as-a-Judge evaluators on traces.

    Args:
        judges: List of BuiltinJudge enum values or JudgeProvider instances.
        sample_rate: Fraction of production traces to evaluate automatically (0.0–1.0).
        judge_model: Default model for built-in judges.
        judge_provider: Default provider for built-in judges ("openai" | "anthropic").
        async_workers: Number of concurrent evaluation workers.
        store_rationale: Whether to persist judge rationale text (uses more storage).
        min_trace_tokens: Skip traces below this token count.
    """

    def __init__(
        self,
        judges=None,
        sample_rate: float = 0.10,
        judge_model: str = "",
        judge_provider: str = "openai_compat",
        async_workers: int = 4,
        store_rationale: bool = True,
        min_trace_tokens: int = 50,
    ):
        import os
        from .judges.base import BuiltinJudge
        self._sample_rate = sample_rate
        self._judge_model = judge_model or os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")
        self._judge_provider = judge_provider
        self._async_workers = async_workers
        self._store_rationale = store_rationale
        self._min_trace_tokens = min_trace_tokens
        self._sampling_active = False

        # Resolve judge instances
        self._judges: List = []
        for j in (judges or []):
            if isinstance(j, BuiltinJudge):
                self._judges.append(self._make_builtin(j))
            else:
                self._judges.append(j)  # custom JudgeProvider instance

    def _make_builtin(self, judge_enum):
        from .judges.base import BuiltinJudge
        from .judges.faithfulness import FaithfulnessJudge
        from .judges.hallucination import HallucinationJudge
        from .judges.relevance import RelevanceJudge
        from .judges.toxicity import ToxicityJudge
        from .judges.groundedness import GroundednessJudge

        mapping = {
            BuiltinJudge.FAITHFULNESS: FaithfulnessJudge,
            BuiltinJudge.HALLUCINATION: HallucinationJudge,
            BuiltinJudge.ANSWER_RELEVANCE: RelevanceJudge,
            BuiltinJudge.TOXICITY: ToxicityJudge,
            BuiltinJudge.GROUNDEDNESS: GroundednessJudge,
        }
        cls = mapping.get(judge_enum)
        if cls:
            return cls(model=self._judge_model, provider=self._judge_provider)
        raise ValueError(f"Unknown builtin judge: {judge_enum}")

    def register_judge(self, name: str, judge) -> None:
        """Register a custom judge under a given name."""
        self._judges.append(judge)

    async def evaluate(
        self,
        trace_id: str,
        prompt: str = "",
        response: str = "",
        context: str = "",
    ) -> EvalResult:
        """Evaluate a single trace through all configured judges.

        Args:
            trace_id: The trace ID to evaluate (used for storage + lookup).
            prompt: The input prompt (or fetched from DB if empty).
            response: The LLM response (or fetched from DB if empty).
            context: Optional retrieval context for faithfulness/groundedness.

        Returns:
            EvalResult with per-dimension scores and rationales.
        """
        # If prompt/response not provided, try to fetch from trace metadata
        if not prompt and not response:
            prompt, response = await self._fetch_trace_content(trace_id)

        scores: Dict[str, float] = {}
        rationales: Dict[str, str] = {}
        judges_run: List[str] = []

        tasks = [
            judge.evaluate(prompt, response, context=context, trace_id=trace_id)
            for judge in self._judges
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for judge, result in zip(self._judges, results):
            dim = judge.dimension
            if isinstance(result, Exception):
                logger.warning("Judge %s failed for trace %s: %s", dim, trace_id, result)
                scores[dim] = 0.5
                rationales[dim] = f"Evaluation failed: {result}"
            else:
                scores[dim] = result.score
                rationales[dim] = result.rationale
                judges_run.append(dim)

        # Persist scores to DB
        await self._store_scores(trace_id, scores, rationales)

        return EvalResult(
            trace_id=trace_id,
            scores=scores,
            rationales=rationales if self._store_rationale else {},
            judges_run=judges_run,
        )

    async def _fetch_trace_content(self, trace_id: str):
        """Attempt to fetch prompt/response from trace metadata."""
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            row = conn.execute(
                "SELECT meta_json FROM traces WHERE id = ?", (trace_id,)
            ).fetchone()
            if row and row[0]:
                import json
                meta = json.loads(row[0])
                return meta.get("prompt", ""), meta.get("response", "")
        except Exception:
            pass
        return "", ""

    async def _store_scores(
        self,
        trace_id: str,
        scores: Dict[str, float],
        rationales: Dict[str, str],
    ) -> None:
        """Persist eval scores to the eval_scores table."""
        try:
            from ..store.writer import get_writer
            writer = get_writer()
            for dimension, score in scores.items():
                rationale = rationales.get(dimension, "") if self._store_rationale else ""
                writer.insert_eval_score(
                    trace_id=trace_id,
                    judge_id=f"{dimension}:{self._judge_model}",
                    dimension=dimension,
                    score=score,
                    rationale=rationale,
                )
        except Exception as e:
            logger.debug("Failed to store eval scores: %s", e)

    def should_sample(self) -> bool:
        """Return True if this request should be evaluated (based on sample_rate)."""
        return random.random() < self._sample_rate

    def start_sampling(self) -> None:
        """Enable automatic background evaluation of sampled production traces.

        Hooks into the CoreIQ event system to sample incoming traces.
        """
        self._sampling_active = True
        logger.info(
            "EvalEngine sampling started (rate=%.1f%%, judges=%s)",
            self._sample_rate * 100,
            [j.dimension for j in self._judges],
        )

    def stop_sampling(self) -> None:
        """Disable automatic background evaluation."""
        self._sampling_active = False


# Module-level singleton
_default_engine: Optional[EvalEngine] = None


def get_eval_engine() -> EvalEngine:
    global _default_engine
    if _default_engine is None:
        _default_engine = EvalEngine()
    return _default_engine
