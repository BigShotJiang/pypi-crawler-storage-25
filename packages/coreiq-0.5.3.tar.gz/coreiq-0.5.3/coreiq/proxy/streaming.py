"""SSE streaming utilities for the CoreIQ proxy.

Provides:
- **StreamingResponseAccumulator** — accumulates GenericStreamingChunks into
  a final ProviderResponse (for caching and logging after a stream completes).
- **chunks_to_openai_sse** — async generator that converts GenericStreamingChunks
  to the OpenAI-compatible SSE wire format.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import AsyncIterator, Optional

from .providers.base import GenericStreamingChunk, ProviderResponse


def _now() -> float:
    """Monotonic clock source.

    Wrapping ``time.monotonic`` in a module-level function makes it easy
    to monkey-patch in unit tests (``patch("coreiq.proxy.streaming._now")``)
    without having to fight ``dataclass.field(default_factory=...)`` which
    captures the function reference at class definition time.
    """
    return time.monotonic()


@dataclass
class StreamingResponseAccumulator:
    """Accumulates streaming chunks into a complete ProviderResponse.

    Usage::

        acc = StreamingResponseAccumulator(model="gpt-4o", request_id="req-123")
        async for chunk in provider.stream(request):
            acc.add(chunk)
            yield chunk
        response = acc.to_response()
    """

    model: str = ""
    request_id: str = ""
    _text_parts: list[str] = field(default_factory=list)
    _finish_reason: str = "stop"
    _usage: dict = field(default_factory=dict)
    _tool_calls: list[dict] = field(default_factory=list)
    # ``_start_time`` is set in ``__post_init__`` (not via
    # ``default_factory``) so that tests patching the module-level
    # ``_now`` symbol take effect at instance construction. Using
    # ``default_factory=_now`` would capture the original function at
    # class-definition time and make patching impossible.
    _start_time: float = 0.0
    _chunk_count: int = 0
    # Timing for TTFT / time-per-output-token metrics. ``_first_chunk_at``
    # is set the first time ``add()`` sees a chunk with actual text or a
    # tool-call delta — keep-alive / empty chunks don't count because
    # they don't represent user-visible progress.
    _first_chunk_at: Optional[float] = None

    def __post_init__(self) -> None:
        # Resolve the clock at construction time via the module-level
        # ``_now`` helper so monkeypatching works.
        if self._start_time == 0.0:
            self._start_time = _now()

    def add(self, chunk: GenericStreamingChunk) -> None:
        """Accumulate a single streaming chunk."""
        self._chunk_count += 1

        if chunk.text:
            self._text_parts.append(chunk.text)
            if self._first_chunk_at is None:
                self._first_chunk_at = _now()
        elif chunk.tool_calls and self._first_chunk_at is None:
            self._first_chunk_at = _now()

        if chunk.finish_reason:
            self._finish_reason = chunk.finish_reason

        if chunk.usage:
            self._usage.update(chunk.usage)

        if chunk.tool_calls:
            # Merge tool call deltas by index.
            for tc in chunk.tool_calls:
                idx = tc.get("index", len(self._tool_calls))
                while len(self._tool_calls) <= idx:
                    self._tool_calls.append({"id": "", "type": "function", "function": {"name": "", "arguments": ""}})
                existing = self._tool_calls[idx]
                if tc.get("id"):
                    existing["id"] = tc["id"]
                if tc.get("type"):
                    existing["type"] = tc["type"]
                func = tc.get("function", {})
                if func.get("name"):
                    existing["function"]["name"] += func["name"]
                if func.get("arguments"):
                    existing["function"]["arguments"] += func["arguments"]

    @property
    def content(self) -> str:
        """Return the full accumulated text content."""
        return "".join(self._text_parts)

    @property
    def chunk_count(self) -> int:
        return self._chunk_count

    @property
    def ttft_ms(self) -> Optional[int]:
        """Time-to-first-token in milliseconds, or None if no chunk arrived.

        Measured from ``_start_time`` (accumulator construction) to the
        arrival of the first non-empty chunk. A cache hit that skips the
        streaming path entirely never constructs an accumulator, so it
        reports TTFT ≈ 0 via a different code path in the pipeline.

        Uses ``round()`` rather than truncation so that a 49.9999ms delta
        caused by float imprecision reports 50ms, matching wall-clock
        expectations.
        """
        if self._first_chunk_at is None:
            return None
        return round((self._first_chunk_at - self._start_time) * 1000)

    @property
    def time_per_output_token_ms(self) -> Optional[float]:
        """Average time per output token in milliseconds after TTFT.

        Computed as ``(total_latency - ttft) / output_tokens``. Returns
        None when we don't have both a first-chunk timestamp and a
        non-zero output token count.
        """
        if self._first_chunk_at is None:
            return None
        output_tokens = int(self._usage.get("completion_tokens") or 0)
        if output_tokens <= 0:
            return None
        total_ms = (_now() - self._start_time) * 1000
        first_chunk_ms = (self._first_chunk_at - self._start_time) * 1000
        post_first_ms = total_ms - first_chunk_ms
        if post_first_ms <= 0:
            return None
        return post_first_ms / output_tokens

    def to_response(self) -> ProviderResponse:
        """Build a complete ProviderResponse from accumulated chunks."""
        latency_ms = round((_now() - self._start_time) * 1000)
        content = self.content

        # Estimate tokens from usage if provided, otherwise approximate.
        usage = dict(self._usage)
        if "completion_tokens" not in usage:
            # Rough approximation: 1 token ~ 4 chars.
            usage["completion_tokens"] = max(1, len(content) // 4)
        if "prompt_tokens" not in usage:
            usage["prompt_tokens"] = 0
        usage.setdefault(
            "total_tokens",
            usage.get("prompt_tokens", 0) + usage.get("completion_tokens", 0),
        )

        return ProviderResponse(
            id=self.request_id,
            model=self.model,
            content=content,
            finish_reason=self._finish_reason,
            usage=usage,
            tool_calls=self._tool_calls if self._tool_calls else None,
            latency_ms=latency_ms,
        )


async def chunks_to_openai_sse(
    chunks: AsyncIterator[GenericStreamingChunk],
    model: str,
    request_id: str,
    *,
    created: Optional[int] = None,
) -> AsyncIterator[str]:
    """Convert an async stream of GenericStreamingChunks to OpenAI SSE format.

    Yields ``data: {json}\\n\\n`` strings suitable for a StreamingResponse.
    Ends with ``data: [DONE]\\n\\n``.

    Each SSE event is a ``ChatCompletionChunk`` with::

        {
            "id": "chatcmpl-...",
            "object": "chat.completion.chunk",
            "created": 1234567890,
            "model": "gpt-4o",
            "choices": [{
                "index": 0,
                "delta": {"content": "..."},
                "finish_reason": null
            }]
        }
    """
    import time as _time

    ts = created if created is not None else int(_time.time())

    async for chunk in chunks:
        if chunk.is_finished and not chunk.text and not chunk.tool_calls:
            # Final sentinel — emit finish_reason then DONE.
            event = {
                "id": request_id,
                "object": "chat.completion.chunk",
                "created": ts,
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {},
                        "finish_reason": chunk.finish_reason or "stop",
                    }
                ],
            }
            if chunk.usage:
                event["usage"] = chunk.usage
            yield f"data: {json.dumps(event)}\n\n"
            break

        # Build delta object.
        delta: dict = {}
        if chunk.text:
            delta["content"] = chunk.text
        if chunk.tool_calls:
            delta["tool_calls"] = chunk.tool_calls

        # Skip empty deltas (e.g. keep-alive chunks with no content).
        if not delta and not chunk.finish_reason:
            continue

        event = {
            "id": request_id,
            "object": "chat.completion.chunk",
            "created": ts,
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "delta": delta,
                    "finish_reason": chunk.finish_reason if chunk.is_finished else None,
                }
            ],
        }
        if chunk.usage:
            event["usage"] = chunk.usage

        yield f"data: {json.dumps(event)}\n\n"

        if chunk.is_finished:
            break

    yield "data: [DONE]\n\n"
