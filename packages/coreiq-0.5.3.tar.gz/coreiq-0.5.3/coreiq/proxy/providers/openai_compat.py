"""Generic OpenAI-compatible provider for self-hosted and local inference.

Covers vLLM, SGLang, Ollama, LocalAI, and any other server that exposes
an OpenAI-compatible ``/v1/chat/completions`` endpoint.  The provider
delegates most logic to :class:`OpenAIProvider` but with a configurable
``base_url`` and relaxed requirements (no API key needed by default,
conservative parameter set).
"""

from __future__ import annotations

import json
import logging
import uuid

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.openai_compat")

# Conservative parameter set — local servers generally support a smaller
# subset than the full OpenAI API.
_BASE_COMPAT_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "stop",
    "frequency_penalty",
    "presence_penalty",
    "n",
    "tools",
    "tool_choice",
]


class OpenAICompatProvider(ProviderConfig):
    """Provider for any OpenAI-compatible inference server.

    Parameters
    ----------
    base_url:
        Full base URL of the inference server (e.g. ``http://localhost:8000/v1``).
    api_key:
        Optional API key.  Most local servers do not require one.
    supported_params:
        Override the list of supported request parameters.  When ``None``
        a conservative default (no tools, no response_format) is used.
    custom_headers:
        Additional headers to include in every request.
    provider_label:
        Human-readable label used in logs and ``provider_name``.
    """

    provider_name = "openai_compatible"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str | None = None,
        supported_params: list[str] | None = None,
        custom_headers: dict[str, str] | None = None,
        provider_label: str = "openai_compatible",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or ""
        self._supported_params = supported_params or list(_BASE_COMPAT_PARAMS)
        self.custom_headers = custom_headers or {}
        self.provider_name = provider_label

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        """Return the configured parameter list for this server."""
        return list(self._supported_params)

    def get_api_base(self) -> str:
        """Return the configured base URL."""
        return self.base_url

    def validate_environment(self) -> bool:
        """OpenAI-compatible servers generally do not require an API key.

        Only validates that ``base_url`` is set.
        """
        if not self.base_url:
            logger.warning(
                "%s: base_url is not set — provider will not work",
                self.provider_name,
            )
            return False
        return True

    def _requires_api_key(self) -> bool:
        """Return ``False`` — most local servers do not need a key."""
        return False

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Build an OpenAI-compatible request against the configured base_url."""
        url = f"{self.base_url}/chat/completions"
        headers: dict[str, str] = {"Content-Type": "application/json"}

        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        headers.update(self.custom_headers)

        body = request.to_dict()

        # Add stream_options when streaming if the server supports it.
        if request.stream and "stream_options" in self._supported_params:
            body.setdefault("stream_options", {"include_usage": True})

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Map an OpenAI-compatible response (same structure as OpenAI)."""
        choices = raw_response.get("choices", [])
        first_choice = choices[0] if choices else {}
        message = first_choice.get("message", {})

        content = message.get("content") or ""
        finish_reason = first_choice.get("finish_reason") or "stop"
        tool_calls = message.get("tool_calls")

        usage_raw = raw_response.get("usage", {})
        usage = {
            "prompt_tokens": usage_raw.get("prompt_tokens", 0),
            "completion_tokens": usage_raw.get("completion_tokens", 0),
            "total_tokens": usage_raw.get(
                "total_tokens",
                usage_raw.get("prompt_tokens", 0) + usage_raw.get("completion_tokens", 0),
            ),
        }

        return ProviderResponse(
            id=raw_response.get("id", f"chatcmpl-{uuid.uuid4().hex[:12]}"),
            model=raw_response.get("model", ""),
            content=content,
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls,
            raw=raw_response,
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse an OpenAI-compatible SSE ``data:`` payload."""
        data = json.loads(raw_chunk)
        choices = data.get("choices", [])
        first = choices[0] if choices else {}
        delta = first.get("delta", {})

        text = delta.get("content") or ""
        finish_reason = first.get("finish_reason")
        tool_calls = delta.get("tool_calls")

        usage_raw = data.get("usage")
        usage: dict | None = None
        if usage_raw:
            usage = {
                "prompt_tokens": usage_raw.get("prompt_tokens", 0),
                "completion_tokens": usage_raw.get("completion_tokens", 0),
                "total_tokens": usage_raw.get("total_tokens", 0),
            }

        return GenericStreamingChunk(
            text=text,
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls if tool_calls else None,
            is_finished=finish_reason is not None,
        )


# ---------------------------------------------------------------------------
# Factory functions for well-known local servers
# ---------------------------------------------------------------------------


def create_vllm_provider(
    base_url: str = "http://localhost:8000/v1",
    *,
    api_key: str | None = None,
) -> OpenAICompatProvider:
    """Create a provider configured for a vLLM server.

    vLLM supports a broader set of OpenAI parameters including tools and
    response_format on recent versions.
    """
    return OpenAICompatProvider(
        base_url=base_url,
        api_key=api_key,
        supported_params=[
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "stop", "frequency_penalty", "presence_penalty",
            "n", "tools", "tool_choice", "response_format", "seed",
            "logprobs", "top_logprobs",
        ],
        provider_label="vllm",
    )


def create_sglang_provider(
    base_url: str = "http://localhost:30000/v1",
    *,
    api_key: str | None = None,
) -> OpenAICompatProvider:
    """Create a provider configured for an SGLang server.

    SGLang supports most OpenAI parameters including tools on recent
    versions.
    """
    return OpenAICompatProvider(
        base_url=base_url,
        api_key=api_key,
        supported_params=[
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "stop", "frequency_penalty", "presence_penalty",
            "n", "seed",
        ],
        provider_label="sglang",
    )


def create_ollama_provider(
    base_url: str = "http://localhost:11434/v1",
    *,
    api_key: str | None = None,
) -> OpenAICompatProvider:
    """Create a provider configured for an Ollama server.

    Ollama's OpenAI-compatible endpoint supports a limited parameter set.
    Tools and response_format support varies by model.
    """
    return OpenAICompatProvider(
        base_url=base_url,
        api_key=api_key,
        supported_params=[
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "stop", "frequency_penalty", "presence_penalty",
            "seed",
        ],
        provider_label="ollama",
    )


def create_nim_provider(
    base_url: str = "http://localhost:8000/v1",
    *,
    api_key: str | None = None,
) -> OpenAICompatProvider:
    """Create a provider configured for an NVIDIA NIM endpoint.

    NIM exposes an OpenAI-compatible API. When running against the
    NVIDIA-hosted catalog ``https://integrate.api.nvidia.com/v1`` an API
    key is required; for self-hosted NIM containers it usually isn't.
    """
    return OpenAICompatProvider(
        base_url=base_url,
        api_key=api_key,
        supported_params=[
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "stop", "frequency_penalty", "presence_penalty",
            "n", "tools", "tool_choice", "response_format", "seed",
        ],
        provider_label="nim",
    )


def create_fireworks_provider(
    base_url: str = "https://api.fireworks.ai/inference/v1",
    *,
    api_key: str | None = None,
) -> OpenAICompatProvider:
    """Create a provider for Fireworks AI's hosted inference."""
    return OpenAICompatProvider(
        base_url=base_url,
        api_key=api_key,
        supported_params=[
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "stop", "frequency_penalty", "presence_penalty",
            "n", "tools", "tool_choice", "response_format", "seed",
            "top_k",
        ],
        provider_label="fireworks",
    )


def create_perplexity_provider(
    base_url: str = "https://api.perplexity.ai",
    *,
    api_key: str | None = None,
) -> OpenAICompatProvider:
    """Create a provider for Perplexity's `sonar` and chat models.

    Perplexity returns an OpenAI-compatible response augmented with a
    ``citations`` field on the message body. The base provider passes
    that through inside ``raw`` so callers can read it without
    coreiq-side parsing.
    """
    return OpenAICompatProvider(
        base_url=base_url,
        api_key=api_key,
        supported_params=[
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "stop", "frequency_penalty", "presence_penalty",
            "search_domain_filter", "return_citations", "search_recency_filter",
            "top_k",
        ],
        provider_label="perplexity",
    )


def create_xai_provider(
    base_url: str = "https://api.x.ai/v1",
    *,
    api_key: str | None = None,
) -> OpenAICompatProvider:
    """Create a provider for xAI's Grok API (OpenAI-compatible)."""
    return OpenAICompatProvider(
        base_url=base_url,
        api_key=api_key,
        supported_params=[
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "stop", "frequency_penalty", "presence_penalty",
            "n", "tools", "tool_choice", "response_format", "seed",
        ],
        provider_label="xai",
    )
