"""DeepSeek provider for the CoreIQ proxy.

DeepSeek exposes an OpenAI-compatible API for their chat, coder, and
reasoner models.  This provider extends :class:`OpenAICompatProvider`
with DeepSeek-specific defaults.
"""

from __future__ import annotations

import logging
import os

from .openai_compat import OpenAICompatProvider

logger = logging.getLogger("coreiq.proxy.deepseek")

# DeepSeek supports most OpenAI chat-completion parameters.
_DEEPSEEK_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "tools",
    "tool_choice",
    "response_format",
    "stop",
    "frequency_penalty",
    "presence_penalty",
    "seed",
    "user",
    "logprobs",
    "top_logprobs",
    "stream_options",
]


class DeepSeekProvider(OpenAICompatProvider):
    """DeepSeek inference provider (OpenAI-compatible).

    Parameters
    ----------
    api_key:
        DeepSeek API key.  Falls back to ``DEEPSEEK_API_KEY``.
    api_base:
        Base URL override (default ``https://api.deepseek.com/v1``).
    """

    provider_name = "deepseek"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("DEEPSEEK_API_KEY", "")
        resolved_base = (api_base or os.environ.get("DEEPSEEK_API_BASE", "")).rstrip("/")
        super().__init__(
            base_url=resolved_base or "https://api.deepseek.com/v1",
            api_key=resolved_key,
            supported_params=list(_DEEPSEEK_PARAMS),
            provider_label="deepseek",
        )

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("DEEPSEEK_API_KEY is not set — DeepSeek provider will not work")
            return False
        return True
