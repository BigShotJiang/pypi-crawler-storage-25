"""Provider registry — resolves ``provider/model`` strings to ProviderConfig instances.

The registry is the single entry point the proxy uses to look up which
provider should handle a given model string.  Providers register themselves
at startup (or lazily on first use), and the router calls ``resolve()`` to
obtain the correct ``ProviderConfig`` plus the bare model name.

Model string conventions:
    - ``"openai/gpt-4o"``         -> provider="openai",   model="gpt-4o"
    - ``"anthropic/claude-sonnet-4-6"`` -> provider="anthropic", model="claude-sonnet-4-6"
    - ``"gpt-4o"``                -> resolved via prefix lookup (fallback)
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

from .base import ProviderConfig, ProviderError

logger = logging.getLogger("coreiq.proxy.registry")

# Well-known model prefixes used for fallback resolution when no explicit
# ``provider/`` prefix is supplied.
_PREFIX_MAP: dict[str, str] = {
    "gpt-": "openai",
    "o1": "openai",
    "o3": "openai",
    "o4": "openai",
    "chatgpt-": "openai",
    "claude-": "anthropic",
    "gemini-": "google",
    "mistral-": "mistral",
    "command-": "cohere",
    "llama-": "together",
    "mixtral-": "together",
    "deepseek-": "deepseek",
    "anthropic.": "bedrock",
    "meta.": "bedrock",
    "mistral.": "bedrock",
    "amazon.": "bedrock",
    # Self-hosted / OpenAI-compatible endpoints route via the openai_compat
    # provider class. The "vllm-", "ollama-", "nim-", "tgi-" prefixes are
    # documentation-friendly aliases that operators can use to disambiguate
    # which backend is serving a given model.
    "vllm-": "vllm",
    "ollama-": "ollama",
    "nim-": "nim",
    "tgi-": "huggingface_tgi",
    # Hosted alternatives to the major providers
    "fireworks-": "fireworks",
    "perplexity-": "perplexity",
    "sonar-": "perplexity",
    "grok-": "xai",
    "replicate-": "replicate",
}


class ProviderRegistry:
    """Resolves ``provider/model`` strings to ``ProviderConfig`` instances.

    Thread-safe for reads after initial registration.  Registration should
    happen at application startup before requests are served.
    """

    def __init__(self) -> None:
        self._providers: dict[str, ProviderConfig] = {}
        # Optional per-model overrides: model_name -> provider_name.
        self._model_overrides: dict[str, str] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, name: str, provider: ProviderConfig) -> None:
        """Register a provider under *name* (lowercase).

        Raises ``ValueError`` if a provider with the same name is already
        registered — use ``replace()`` for intentional overwrites.
        """
        name = name.lower()
        if name in self._providers:
            raise ValueError(
                f"Provider {name!r} is already registered.  "
                "Use replace() to overwrite."
            )
        self._providers[name] = provider
        logger.info("Registered provider %r (%s)", name, type(provider).__name__)

    def replace(self, name: str, provider: ProviderConfig) -> None:
        """Register or replace a provider under *name*."""
        name = name.lower()
        self._providers[name] = provider
        logger.info("Replaced provider %r (%s)", name, type(provider).__name__)

    def register_model_override(self, model: str, provider_name: str) -> None:
        """Map a specific model name to a provider regardless of prefix.

        Useful for custom deployments, e.g. mapping ``"my-fine-tuned-3.5"``
        to the ``"openai"`` provider.
        """
        self._model_overrides[model] = provider_name.lower()

    # ------------------------------------------------------------------
    # Resolution
    # ------------------------------------------------------------------

    def resolve(self, model_string: str) -> tuple[ProviderConfig, str]:
        """Resolve a model string to ``(ProviderConfig, model_name)``.

        Resolution order:
            1. Explicit prefix: ``"openai/gpt-4o"``
            2. Per-model override registered via ``register_model_override()``
            3. Well-known prefix heuristic (``gpt-`` -> ``openai``, etc.)

        Raises ``ProviderError`` if the provider cannot be determined or is
        not registered.
        """
        provider_name: Optional[str] = None
        model_name: str = model_string

        # 1) Explicit "provider/model" syntax.
        if "/" in model_string:
            parts = model_string.split("/", 1)
            candidate = parts[0].lower()
            if candidate in self._providers:
                return self._providers[candidate], parts[1]
            # Could be a model name with a slash (e.g. org/model on HF).
            # Fall through to other strategies.
            provider_name = candidate
            model_name = parts[1]

        # 2) Per-model override.
        if model_string in self._model_overrides:
            pname = self._model_overrides[model_string]
            if pname in self._providers:
                return self._providers[pname], model_string
            raise ProviderError(
                f"Model override maps {model_string!r} to provider {pname!r}, "
                "but that provider is not registered.",
                provider=pname,
            )

        # 3) Well-known prefix lookup.
        if provider_name is None:
            for prefix, pname in _PREFIX_MAP.items():
                if model_string.lower().startswith(prefix):
                    provider_name = pname
                    break

        if provider_name and provider_name in self._providers:
            return self._providers[provider_name], model_name

        if provider_name:
            raise ProviderError(
                f"Provider {provider_name!r} (from model string {model_string!r}) "
                "is not registered.  Available: "
                + ", ".join(sorted(self._providers)),
                provider=provider_name,
            )

        raise ProviderError(
            f"Cannot determine provider for model {model_string!r}.  "
            "Use the 'provider/model' format or register a model override.  "
            "Available providers: " + ", ".join(sorted(self._providers)),
        )

    def get(self, name: str) -> Optional[ProviderConfig]:
        """Return the provider registered under *name*, or ``None``."""
        return self._providers.get(name.lower())

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def list_providers(self) -> list[str]:
        """Return a sorted list of registered provider names."""
        return sorted(self._providers)

    def list_models(self) -> list[dict]:
        """Return metadata for all registered providers.

        Each entry includes the provider name and whether the environment
        is correctly configured.  This is intended for the ``GET /v1/models``
        endpoint.
        """
        result: list[dict] = []
        for name in sorted(self._providers):
            provider = self._providers[name]
            result.append({
                "provider": name,
                "class": type(provider).__name__,
                "api_base": provider.get_api_base(),
                "environment_valid": provider.validate_environment(),
            })
        return result

    def __contains__(self, name: str) -> bool:
        return name.lower() in self._providers

    def __len__(self) -> int:
        return len(self._providers)

    def __repr__(self) -> str:
        names = ", ".join(sorted(self._providers))
        return f"<ProviderRegistry providers=[{names}]>"


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_singleton: ProviderRegistry | None = None
_singleton_lock = threading.Lock()


def get_provider_registry() -> ProviderRegistry:
    """Return the module-level :class:`ProviderRegistry` singleton.

    The registry is created lazily on first access and reused for the
    lifetime of the process.
    """
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                _singleton = ProviderRegistry()
    return _singleton
