"""Google Gemini provider for the CoreIQ proxy.

Google's Generative Language API differs significantly from the OpenAI
chat-completion format.  This provider handles all translation:

* Messages use ``contents`` array with ``parts`` instead of ``messages``.
* System messages are placed in the top-level ``system_instruction`` field.
* Tool definitions use ``function_declarations`` format.
* Auth supports both API key (query param) and Bearer token.
* Streaming returns JSON chunks via SSE.
"""

from __future__ import annotations

import json
import logging
import os
import uuid

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.google")

# Parameters the Gemini API accepts (mapped from OpenAI conventions).
_GOOGLE_PARAMS = [
    "model",
    "messages",
    "max_tokens",
    "temperature",
    "top_p",
    "top_k",
    "stream",
    "tools",
    "tool_choice",
    "stop",
    "response_format",
]

# Mapping from Gemini finish reason to OpenAI finish_reason.
_FINISH_REASON_MAP = {
    "STOP": "stop",
    "MAX_TOKENS": "length",
    "SAFETY": "content_filter",
    "RECITATION": "content_filter",
    "OTHER": "stop",
}


class GoogleProvider(ProviderConfig):
    """Google Gemini (Generative Language API) provider.

    Parameters
    ----------
    api_key:
        Google API key.  Falls back to ``GOOGLE_API_KEY``.
    api_base:
        Base URL override (default ``https://generativelanguage.googleapis.com/v1beta``).
    auth_mode:
        ``"query"`` to pass the key as ``?key=``, or ``"bearer"`` for
        ``Authorization: Bearer`` header.  Default ``"query"``.
    default_max_tokens:
        Default output token limit when the request does not specify one.
    """

    provider_name = "google"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        auth_mode: str = "query",
        default_max_tokens: int = 4096,
    ) -> None:
        self.api_key = api_key or os.environ.get("GOOGLE_API_KEY", "")
        self.api_base = (api_base or os.environ.get("GOOGLE_API_BASE", "")).rstrip("/")
        self.auth_mode = auth_mode
        self.default_max_tokens = default_max_tokens

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        """Return parameters accepted by the Gemini API."""
        return list(_GOOGLE_PARAMS)

    def get_api_base(self) -> str:
        """Return the effective API base URL."""
        return self.api_base or "https://generativelanguage.googleapis.com/v1beta"

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("GOOGLE_API_KEY is not set — Google provider will not work")
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Translate an OpenAI-style request into the Gemini generateContent format."""
        base = self.get_api_base()
        model = request.model

        if request.stream:
            url = f"{base}/models/{model}:streamGenerateContent?alt=sse"
        else:
            url = f"{base}/models/{model}:generateContent"

        # Auth — query param or bearer header.
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.auth_mode == "bearer":
            headers["Authorization"] = f"Bearer {self.api_key}"
        else:
            sep = "&" if "?" in url else "?"
            url = f"{url}{sep}key={self.api_key}"

        # Convert messages.
        system_text, contents = _convert_messages(request.messages)

        body: dict = {"contents": contents}

        # System instruction.
        if system_text:
            body["system_instruction"] = {"parts": [{"text": system_text}]}

        # Generation config.
        gen_config: dict = {}
        if request.max_tokens is not None:
            gen_config["maxOutputTokens"] = request.max_tokens
        else:
            gen_config["maxOutputTokens"] = self.default_max_tokens
        if request.temperature is not None:
            gen_config["temperature"] = request.temperature
        if request.top_p is not None:
            gen_config["topP"] = request.top_p
        if request.stop is not None:
            gen_config["stopSequences"] = (
                request.stop if isinstance(request.stop, list) else [request.stop]
            )
        if request.response_format and request.response_format.get("type") == "json_object":
            gen_config["responseMimeType"] = "application/json"
        if "top_k" in request.extra:
            gen_config["topK"] = request.extra["top_k"]

        if gen_config:
            body["generationConfig"] = gen_config

        # Tools.
        if request.tools:
            body["tools"] = [{"function_declarations": _translate_tools(request.tools)}]
        if request.tool_choice is not None and request.tools:
            body["tool_config"] = _translate_tool_config(request.tool_choice)

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Translate a Gemini generateContent response to a ProviderResponse."""
        candidates = raw_response.get("candidates", [])
        first = candidates[0] if candidates else {}
        content_obj = first.get("content", {})
        parts = content_obj.get("parts", [])

        text_parts: list[str] = []
        tool_calls: list[dict] = []

        for part in parts:
            if "text" in part:
                text_parts.append(part["text"])
            elif "functionCall" in part:
                fc = part["functionCall"]
                tool_calls.append({
                    "id": f"call_{uuid.uuid4().hex[:12]}",
                    "type": "function",
                    "function": {
                        "name": fc.get("name", ""),
                        "arguments": json.dumps(fc.get("args", {})),
                    },
                })

        finish_reason_raw = first.get("finishReason", "STOP")
        finish_reason = _FINISH_REASON_MAP.get(finish_reason_raw, "stop")

        usage_raw = raw_response.get("usageMetadata", {})
        # Gemini prompt-cache field:
        #   usageMetadata.cachedContentTokenCount — tokens served from a
        #   cachedContent reference, billed at 25% of base input rate.
        # See https://ai.google.dev/gemini-api/docs/caching
        cached_input = int(usage_raw.get("cachedContentTokenCount", 0) or 0)
        usage = {
            "prompt_tokens": usage_raw.get("promptTokenCount", 0),
            "completion_tokens": usage_raw.get("candidatesTokenCount", 0),
            "total_tokens": usage_raw.get("totalTokenCount", 0),
            "cached_input_tokens": cached_input,
        }

        return ProviderResponse(
            id=f"gemini-{uuid.uuid4().hex[:12]}",
            model=raw_response.get("modelVersion", ""),
            content="\n".join(text_parts) if text_parts else "",
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls if tool_calls else None,
            raw=raw_response,
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse a single SSE ``data:`` payload from a Gemini stream.

        Gemini streams JSON objects with the same structure as the
        non-streaming response, one candidate at a time.
        """
        data = json.loads(raw_chunk)
        candidates = data.get("candidates", [])
        first = candidates[0] if candidates else {}
        content_obj = first.get("content", {})
        parts = content_obj.get("parts", [])

        text = ""
        tool_calls_out: list[dict] = []
        for part in parts:
            if "text" in part:
                text += part["text"]
            elif "functionCall" in part:
                fc = part["functionCall"]
                tool_calls_out.append({
                    "id": f"call_{uuid.uuid4().hex[:12]}",
                    "type": "function",
                    "function": {
                        "name": fc.get("name", ""),
                        "arguments": json.dumps(fc.get("args", {})),
                    },
                })

        finish_reason_raw = first.get("finishReason")
        finish_reason = _FINISH_REASON_MAP.get(finish_reason_raw, None) if finish_reason_raw else None

        usage_raw = data.get("usageMetadata")
        usage: dict | None = None
        if usage_raw:
            usage = {
                "prompt_tokens": usage_raw.get("promptTokenCount", 0),
                "completion_tokens": usage_raw.get("candidatesTokenCount", 0),
                "total_tokens": usage_raw.get("totalTokenCount", 0),
            }

        return GenericStreamingChunk(
            text=text,
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls_out if tool_calls_out else None,
            is_finished=finish_reason is not None,
        )


# ---------------------------------------------------------------------------
# Internal translation helpers
# ---------------------------------------------------------------------------


def _convert_messages(messages: list[dict]) -> tuple[str, list[dict]]:
    """Convert OpenAI-style messages to Gemini ``contents`` format.

    Returns ``(system_text, contents)`` where system messages are extracted
    into a single string and the remaining messages are mapped to Gemini's
    ``{role, parts}`` structure.
    """
    system_parts: list[str] = []
    contents: list[dict] = []

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if role == "system":
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        system_parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        system_parts.append(block)
            else:
                system_parts.append(str(content))
            continue

        # Map OpenAI roles to Gemini roles.
        gemini_role = "model" if role == "assistant" else "user"

        if role == "tool":
            # Tool results -> functionResponse part.
            contents.append({
                "role": "user",
                "parts": [{
                    "functionResponse": {
                        "name": msg.get("name", msg.get("tool_call_id", "function")),
                        "response": {"result": str(content)},
                    }
                }],
            })
            continue

        if role == "assistant" and msg.get("tool_calls"):
            # Assistant with tool calls -> functionCall parts.
            parts: list[dict] = []
            text_content = msg.get("content")
            if text_content:
                parts.append({"text": text_content})
            for tc in msg["tool_calls"]:
                func = tc.get("function", {})
                args = func.get("arguments", "{}")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except (json.JSONDecodeError, TypeError):
                        args = {}
                parts.append({
                    "functionCall": {
                        "name": func.get("name", ""),
                        "args": args,
                    }
                })
            contents.append({"role": "model", "parts": parts})
            continue

        # Standard text message.
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict):
                    if block.get("type") == "text":
                        parts.append({"text": block.get("text", "")})
                    elif block.get("type") == "image_url":
                        url = block.get("image_url", {}).get("url", "")
                        if url.startswith("data:"):
                            try:
                                header, b64data = url.split(",", 1)
                                mime = header.split(";")[0].split(":")[1]
                                parts.append({"inline_data": {"mime_type": mime, "data": b64data}})
                            except (ValueError, IndexError):
                                parts.append({"text": f"[Image: {url[:80]}]"})
                        else:
                            # Gemini supports URL-based images via file_data
                            parts.append({"text": f"[Image: {url}]"})
                elif isinstance(block, str):
                    parts.append({"text": block})
            contents.append({"role": gemini_role, "parts": parts})
        else:
            contents.append({"role": gemini_role, "parts": [{"text": str(content)}]})

    return "\n\n".join(system_parts), contents


def _translate_tools(tools: list[dict]) -> list[dict]:
    """Convert OpenAI tool definitions to Gemini ``function_declarations``.

    OpenAI format::

        {"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}

    Gemini format::

        {"name": ..., "description": ..., "parameters": ...}
    """
    declarations: list[dict] = []
    for tool in tools:
        if tool.get("type") == "function":
            func = tool.get("function", {})
            decl: dict = {
                "name": func.get("name", ""),
                "description": func.get("description", ""),
            }
            params = func.get("parameters")
            if params:
                decl["parameters"] = params
            declarations.append(decl)
    return declarations


def _translate_tool_config(tool_choice: str | dict) -> dict:
    """Convert OpenAI ``tool_choice`` to Gemini ``tool_config``.

    OpenAI values:
        - ``"auto"``     -> mode AUTO
        - ``"required"`` -> mode ANY
        - ``"none"``     -> mode NONE
        - ``{"type": "function", "function": {"name": "X"}}``
                         -> mode ANY with allowed function names
    """
    if isinstance(tool_choice, str):
        mapping = {
            "auto": {"function_calling_config": {"mode": "AUTO"}},
            "required": {"function_calling_config": {"mode": "ANY"}},
            "none": {"function_calling_config": {"mode": "NONE"}},
        }
        return mapping.get(tool_choice, {"function_calling_config": {"mode": "AUTO"}})

    if isinstance(tool_choice, dict):
        func = tool_choice.get("function", {})
        name = func.get("name", "")
        if name:
            return {
                "function_calling_config": {
                    "mode": "ANY",
                    "allowed_function_names": [name],
                }
            }
        return {"function_calling_config": {"mode": "AUTO"}}

    return {"function_calling_config": {"mode": "AUTO"}}
