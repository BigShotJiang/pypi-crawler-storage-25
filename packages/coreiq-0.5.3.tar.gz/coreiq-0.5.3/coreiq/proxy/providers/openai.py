"""OpenAI provider for the CoreIQ proxy.

Reference implementation — OpenAI's API is the canonical format that
ProviderRequest/ProviderResponse are modelled after, so most transforms
are near-passthrough.  Also supports Azure OpenAI when ``api_base``
points to an Azure endpoint.
"""

from __future__ import annotations

import json
import logging
import os
import uuid

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.openai")

# Standard OpenAI chat-completion parameters.
_OPENAI_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "tools",
    "tool_choice",
    "response_format",
    "stop",
    "frequency_penalty",
    "presence_penalty",
    "seed",
    "user",
    "n",
    "logprobs",
    "top_logprobs",
    "stream_options",
    "parallel_tool_calls",
    "logit_bias",
]


class OpenAIProvider(ProviderConfig):
    """OpenAI chat-completions provider with optional Azure support.

    Parameters
    ----------
    api_key:
        OpenAI API key.  Falls back to the ``OPENAI_API_KEY`` env var.
    api_base:
        Base URL override.  When the value contains ``"azure"`` the
        provider switches to Azure OpenAI URL conventions.
    api_version:
        Azure API version query parameter (default ``2024-06-01``).
    organization:
        Optional OpenAI organization header.
    """

    provider_name = "openai"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        api_version: str = "2024-06-01",
        organization: str | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.api_base = (api_base or os.environ.get("OPENAI_API_BASE", "")).rstrip("/")
        self.api_version = api_version
        self.organization = organization or os.environ.get("OPENAI_ORG_ID")
        self._is_azure = "azure" in self.api_base.lower() if self.api_base else False

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        """Return all standard OpenAI chat-completion parameters."""
        return list(_OPENAI_PARAMS)

    def get_api_base(self) -> str:
        """Return the effective API base URL."""
        if self.api_base:
            return self.api_base
        return "https://api.openai.com/v1"

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("OPENAI_API_KEY is not set — OpenAI provider will not work")
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Build OpenAI-compatible URL, headers, and body.

        For standard OpenAI the body is essentially ``request.to_dict()``.
        For Azure, the URL includes the deployment name and api-version
        query parameter, and the auth header uses ``api-key`` instead of
        ``Authorization: Bearer``.
        """
        body = request.to_dict()

        # Inject stream_options for usage reporting during streaming.
        if request.stream:
            body.setdefault("stream_options", {"include_usage": True})

        if self._is_azure:
            url = self._azure_url(request.model)
            headers = self._azure_headers()
            # Azure expects the model in the URL, not the body.
            body.pop("model", None)
        else:
            url = f"{self.get_api_base()}/chat/completions"
            headers = self._openai_headers()

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Map an OpenAI JSON response to a ProviderResponse (near 1-to-1)."""
        choices = raw_response.get("choices", [])
        first_choice = choices[0] if choices else {}
        message = first_choice.get("message", {})

        content = message.get("content") or ""
        finish_reason = first_choice.get("finish_reason") or "stop"
        tool_calls = message.get("tool_calls")

        usage_raw = raw_response.get("usage", {})
        # OpenAI prompt-cache field:
        #   usage.prompt_tokens_details.cached_tokens — tokens served
        #   from the prompt cache, billed at 50% of the base input rate.
        # See https://platform.openai.com/docs/guides/prompt-caching
        cached_input = int(
            (usage_raw.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
            or 0
        )
        usage = {
            "prompt_tokens": usage_raw.get("prompt_tokens", 0),
            "completion_tokens": usage_raw.get("completion_tokens", 0),
            "total_tokens": usage_raw.get("total_tokens", 0),
            "cached_input_tokens": cached_input,
        }

        return ProviderResponse(
            id=raw_response.get("id", f"chatcmpl-{uuid.uuid4().hex[:12]}"),
            model=raw_response.get("model", ""),
            content=content,
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls,
            raw=raw_response,
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse a single SSE ``data:`` payload from an OpenAI stream."""
        data = json.loads(raw_chunk)
        choices = data.get("choices", [])
        first = choices[0] if choices else {}
        delta = first.get("delta", {})

        text = delta.get("content") or ""
        finish_reason = first.get("finish_reason")
        tool_calls = delta.get("tool_calls")

        # Usage may appear in a final chunk when stream_options.include_usage is set.
        usage_raw = data.get("usage")
        usage: dict | None = None
        if usage_raw:
            usage = {
                "prompt_tokens": usage_raw.get("prompt_tokens", 0),
                "completion_tokens": usage_raw.get("completion_tokens", 0),
                "total_tokens": usage_raw.get("total_tokens", 0),
            }

        return GenericStreamingChunk(
            text=text,
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls if tool_calls else None,
            is_finished=finish_reason is not None,
        )

    # ------------------------------------------------------------------
    # Embedding support
    # ------------------------------------------------------------------

    def transform_embedding_request(self, body: dict) -> tuple[str, dict, dict]:
        """Build URL, headers, and body for an embedding request.

        For standard OpenAI this is a simple pass-through.  For Azure
        the URL is adjusted to the deployment endpoint.
        """
        if self._is_azure:
            model = body.get("model", "")
            base = self.api_base.rstrip("/")
            url = (
                f"{base}/openai/deployments/{model}/embeddings"
                f"?api-version={self.api_version}"
            )
            headers = self._azure_headers()
            body_out = dict(body)
            body_out.pop("model", None)
        else:
            url = f"{self.get_api_base()}/embeddings"
            headers = self._openai_headers()
            body_out = dict(body)
        return url, headers, body_out

    def transform_embedding_response(self, raw_response: dict) -> dict:
        """Transform an embedding response (pass-through for OpenAI)."""
        return raw_response

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _openai_headers(self) -> dict[str, str]:
        """Standard OpenAI authorization headers."""
        headers: dict[str, str] = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        if self.organization:
            headers["OpenAI-Organization"] = self.organization
        return headers

    def _azure_headers(self) -> dict[str, str]:
        """Azure OpenAI uses ``api-key`` instead of Bearer tokens."""
        return {
            "api-key": self.api_key,
            "Content-Type": "application/json",
        }

    def _azure_url(self, model: str) -> str:
        """Build the Azure deployment URL with API version query string.

        Azure convention:
        ``{api_base}/openai/deployments/{deployment}/chat/completions?api-version={ver}``
        """
        base = self.api_base.rstrip("/")
        return (
            f"{base}/openai/deployments/{model}/chat/completions"
            f"?api-version={self.api_version}"
        )
