"""First-class Ollama provider.

Ollama exposes an OpenAI-compatible API at ``http://<host>:11434/v1``
plus a native ``/api/chat`` endpoint. We use the OpenAI-compat path for
broad coverage (chat, streaming, tools) and surface Ollama-specific
defaults (no API key, common parameter set).

Configuration::

    OLLAMA_BASE_URL=http://localhost:11434/v1   # default
"""
from __future__ import annotations

import os

from .openai_compat import OpenAICompatProvider

_DEFAULT_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "stop",
    "tools",
    "tool_choice",
    "response_format",
]


class OllamaProvider(OpenAICompatProvider):
    """Ollama-specific provider with sane defaults."""

    provider_name = "ollama"

    def __init__(self, base_url: str | None = None, api_key: str | None = None) -> None:
        url = base_url or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
        super().__init__(
            base_url=url,
            api_key=api_key or os.environ.get("OLLAMA_API_KEY", ""),
            supported_params=list(_DEFAULT_PARAMS),
            provider_label="ollama",
        )
