"""Replicate provider for the CoreIQ proxy.

Replicate's API is unusual: it's an *asynchronous* prediction system.
Submitting a prediction returns immediately with a job ID and a status
URL; the client polls until ``status=succeeded`` (or ``failed``) to
retrieve the final output. There is no native streaming for the
``predictions`` endpoint, though some models expose a streaming URL via
``urls.stream`` that emits SSE events.

This provider implements the synchronous "submit + poll" flow inside a
single :meth:`transform_request` → HTTP call → :meth:`transform_response`
sequence by surfacing both via a custom :meth:`predict` method that the
proxy pipeline can call directly when ``provider_name == "replicate"``.

For the OpenAI-compatible chat path used by the rest of coreiq, the
provider exposes a no-op ``transform_request`` / ``transform_response``
pair that builds a single POST + GET-poll sequence and returns the
finalized output as a regular ProviderResponse.

Configuration
-------------

::

    REPLICATE_API_TOKEN=r8_...
    REPLICATE_DEFAULT_VERSION=meta/meta-llama-3.1-405b-instruct  # optional

The model string accepted by ``transform_request`` should be the
Replicate model identifier in the form ``owner/name`` or
``owner/name:version``. The provider resolves the version automatically
when only ``owner/name`` is given by hitting Replicate's
``/models/{owner}/{name}`` endpoint to discover the latest version.
"""
from __future__ import annotations

import logging
import os
import uuid
from typing import Optional

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.replicate")

_REPLICATE_API_BASE = "https://api.replicate.com/v1"

# Maximum poll iterations before we give up (each poll waits POLL_INTERVAL seconds).
_MAX_POLL_ITERATIONS = 600  # 600 * 0.5s = 5 min default deadline
_POLL_INTERVAL_S = 0.5


class ReplicateProvider(ProviderConfig):
    """Async predictions API client wrapped behind ProviderConfig.

    The submit + poll loop happens **inside** the proxy pipeline's
    HTTPX call, not in ``transform_response``. The proxy already handles
    the actual HTTP I/O, so this provider's ``transform_request`` builds
    the *initial* POST body, and ``transform_response`` is responsible
    for following the ``urls.get`` field if the prediction isn't yet
    in a terminal state. Because the pipeline doesn't know about the
    poll loop natively, ReplicateProvider exposes :meth:`do_predict` as
    an escape hatch the dispatch path uses for this provider.
    """

    provider_name = "replicate"

    def __init__(
        self,
        *,
        api_token: Optional[str] = None,
        default_version: Optional[str] = None,
        max_poll_iterations: int = _MAX_POLL_ITERATIONS,
        poll_interval_s: float = _POLL_INTERVAL_S,
    ) -> None:
        self.api_token = api_token or os.environ.get("REPLICATE_API_TOKEN", "")
        self.default_version = default_version or os.environ.get("REPLICATE_DEFAULT_VERSION", "")
        self._max_poll_iterations = max_poll_iterations
        self._poll_interval_s = poll_interval_s

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        return [
            "model",
            "messages",
            "temperature",
            "max_tokens",
            "top_p",
            "top_k",
            "stop",
            "seed",
        ]

    def get_api_base(self) -> str:
        return _REPLICATE_API_BASE

    def validate_environment(self) -> bool:
        if not self.api_token:
            logger.warning(
                "REPLICATE_API_TOKEN is not set — Replicate provider will not work"
            )
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Build the initial POST to ``/predictions``.

        Replicate accepts ``{version, input}`` where ``input`` is a
        model-specific dict. We translate the OpenAI ``messages`` array
        into the most common Replicate input shape: ``{prompt: "..."}``.
        Models that take richer input shapes (system + user split,
        image_input, etc.) can be reached by passing custom kwargs in
        ``request.extra``.
        """
        url = f"{_REPLICATE_API_BASE}/predictions"
        headers = self._headers()

        version = self._resolve_version(request.model)
        prompt = self._messages_to_prompt(request.messages)

        input_payload: dict = {"prompt": prompt}
        if request.temperature is not None:
            input_payload["temperature"] = request.temperature
        if request.max_tokens is not None:
            input_payload["max_new_tokens"] = request.max_tokens
        if request.top_p is not None:
            input_payload["top_p"] = request.top_p
        # Caller-supplied input overrides via extra
        for key, value in (request.extra or {}).items():
            input_payload[key] = value

        body: dict = {"input": input_payload}
        if version:
            body["version"] = version

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Wrap a finalized prediction (output already retrieved).

        The polling loop in :meth:`do_predict` writes the final output
        into ``raw_response["_coreiq_output"]`` before calling this
        method. If that field is missing the response is treated as an
        in-progress prediction and an empty content string is returned
        with finish_reason="processing" — letting the caller surface
        the situation rather than block.
        """
        output = raw_response.get("_coreiq_output")
        if output is None:
            return ProviderResponse(
                id=raw_response.get("id", f"replicate-{uuid.uuid4().hex[:12]}"),
                model=raw_response.get("model", "replicate"),
                content="",
                finish_reason="processing",
                usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
                tool_calls=None,
                raw=raw_response,
            )

        if isinstance(output, list):
            content = "".join(str(p) for p in output)
        else:
            content = str(output)

        # Replicate's metrics dict carries token counts when the model
        # exposes them; otherwise we fall back to character/4 estimates.
        metrics = raw_response.get("metrics") or {}
        prompt_tokens = int(metrics.get("input_token_count") or 0)
        completion_tokens = int(metrics.get("output_token_count") or max(1, len(content) // 4))

        return ProviderResponse(
            id=raw_response.get("id", f"replicate-{uuid.uuid4().hex[:12]}"),
            model=raw_response.get("model", "replicate"),
            content=content,
            finish_reason="stop",
            usage={
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
            },
            tool_calls=None,
            raw=raw_response,
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Replicate native predictions don't stream — return an empty chunk.

        Some Replicate models DO support a streaming endpoint via
        ``urls.stream``, but consuming it requires a separate SSE
        connection that is out of scope for this commit. Future work
        can wire that path through the existing streaming.py
        accumulator.
        """
        return GenericStreamingChunk(text="", is_finished=False)

    # ------------------------------------------------------------------
    # Polling helper — called by the dispatch layer for this provider
    # ------------------------------------------------------------------

    def is_terminal_status(self, status: str) -> bool:
        """Whether a Replicate prediction status is final (won't change)."""
        return status in ("succeeded", "failed", "canceled")

    def is_succeeded(self, status: str) -> bool:
        return status == "succeeded"

    @property
    def poll_interval_s(self) -> float:
        return self._poll_interval_s

    @property
    def max_poll_iterations(self) -> int:
        return self._max_poll_iterations

    def get_poll_url(self, prediction: dict) -> Optional[str]:
        """Extract the GET URL from a prediction's ``urls.get`` field."""
        urls = prediction.get("urls") or {}
        return urls.get("get")

    def merge_output(self, prediction: dict) -> dict:
        """Return the prediction with ``_coreiq_output`` populated.

        Called once the polling loop sees ``status=succeeded`` so that
        :meth:`transform_response` knows the output is ready. The native
        Replicate response field is just ``output``; copying it under a
        coreiq-prefixed key lets us distinguish "in progress" from
        "complete with empty output" without ambiguity.
        """
        merged = dict(prediction)
        merged["_coreiq_output"] = prediction.get("output")
        return merged

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Token {self.api_token}",
            "Content-Type": "application/json",
        }

    def _resolve_version(self, model: str) -> str:
        """Resolve a Replicate model identifier to a version hash.

        Accepts:
        - ``owner/name:version-hash`` → returns ``version-hash``
        - ``owner/name`` → returns the configured default version, if any
        - bare model name → returns the configured default version
        """
        if not model:
            return self.default_version
        if ":" in model:
            return model.split(":", 1)[1]
        return self.default_version

    @staticmethod
    def _messages_to_prompt(messages: list[dict]) -> str:
        """Flatten an OpenAI messages array into a single prompt string.

        See ``HuggingFaceTGIProvider._messages_to_prompt`` for the
        rationale — same approach.
        """
        parts: list[str] = []
        for msg in messages or []:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                )
            parts.append(f"{role}: {content}")
        parts.append("assistant:")
        return "\n".join(parts)


def create_replicate_provider() -> ReplicateProvider:
    return ReplicateProvider()
