"""Hugging Face Text Generation Inference (TGI) provider.

TGI is HF's production inference server for self-hosted LLMs. Its native
endpoints are ``/generate`` (synchronous) and ``/generate_stream`` (SSE),
both of which take a flat ``{inputs, parameters}`` body — fundamentally
different from the OpenAI ``messages`` array.

Why TGI is a dedicated subclass instead of an OpenAICompat factory
------------------------------------------------------------------

Recent TGI versions DO expose an OpenAI-compatible ``/v1/chat/completions``
endpoint via the "messages API" extension. For users running those
versions, the existing :class:`OpenAICompatProvider` works directly with
``base_url=http://tgi:8080/v1``. **This dedicated provider exists for
the much more common case** where the user is talking to a vanilla TGI
deployment that only speaks the native ``/generate`` shape — typical for
self-hosted LLMs on EKS/GKE where the operator just dropped in the
``ghcr.io/huggingface/text-generation-inference`` image.

The conversion is best-effort: messages are flattened into a single
prompt string by joining ``role: content`` pairs, which works well for
chat-tuned models that follow the expected role format and degrades
gracefully for base completion models. Tool calling is not supported in
the native shape.
"""
from __future__ import annotations

import json
import logging
import os
import uuid
from typing import Optional

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.huggingface_tgi")

_TGI_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "stop",
    "seed",
    "top_k",
    "repetition_penalty",
]


class HuggingFaceTGIProvider(ProviderConfig):
    """Provider for Hugging Face Text Generation Inference (native API).

    Parameters
    ----------
    base_url:
        Root URL of the TGI server, e.g. ``http://tgi:8080``. Do NOT
        include ``/generate`` — this provider appends the right path.
    api_key:
        Optional bearer token for TGI servers behind a gateway.
    """

    provider_name = "huggingface_tgi"

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> None:
        self.base_url = (
            base_url
            or os.environ.get("HUGGINGFACE_TGI_URL", "")
            or "http://localhost:8080"
        ).rstrip("/")
        self.api_key = api_key or os.environ.get("HUGGINGFACE_TGI_TOKEN", "")

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        return list(_TGI_PARAMS)

    def get_api_base(self) -> str:
        return self.base_url

    def validate_environment(self) -> bool:
        if not self.base_url:
            logger.warning(
                "HUGGINGFACE_TGI_URL is not set — TGI provider will not work"
            )
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Build a TGI ``/generate`` (or ``/generate_stream``) request.

        The OpenAI-style ``messages`` array is flattened to a single
        prompt string. Token / temperature / top_p / stop parameters are
        translated into the ``parameters`` sub-dict TGI expects.
        """
        path = "/generate_stream" if request.stream else "/generate"
        url = f"{self.base_url}{path}"

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        prompt = self._messages_to_prompt(request.messages)

        parameters: dict = {}
        if request.temperature is not None:
            parameters["temperature"] = request.temperature
        if request.max_tokens is not None:
            parameters["max_new_tokens"] = request.max_tokens
        if request.top_p is not None:
            parameters["top_p"] = request.top_p
        if request.stop:
            parameters["stop"] = list(request.stop) if isinstance(request.stop, (list, tuple)) else [request.stop]
        # Carry through TGI-specific extras from request.extra
        for key in ("top_k", "repetition_penalty", "seed"):
            if key in request.extra:
                parameters[key] = request.extra[key]

        body = {"inputs": prompt, "parameters": parameters}
        if request.stream:
            body["stream"] = True

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Map a TGI ``/generate`` response into a ProviderResponse.

        TGI returns either ``{"generated_text": "..."}`` for a single
        result or a list ``[{"generated_text": "..."}]`` when ``num_return_sequences > 1``.
        """
        if isinstance(raw_response, list):
            first = raw_response[0] if raw_response else {}
        else:
            first = raw_response

        content = first.get("generated_text", "") or ""
        details = first.get("details") or {}
        finish_reason = self._map_finish_reason(details.get("finish_reason"))

        # TGI provides token-level details when ``details=true``; map
        # them to OpenAI-style usage so the rest of the pipeline (cost
        # calc, dashboards) works unchanged.
        prompt_tokens = int(details.get("prefill", 0) and len(details.get("prefill", [])) or 0)
        completion_tokens = int(details.get("generated_tokens") or 0)

        usage = {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        }

        return ProviderResponse(
            id=f"tgi-{uuid.uuid4().hex[:12]}",
            model="tgi",
            content=content,
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=None,
            raw=raw_response if isinstance(raw_response, dict) else {"results": raw_response},
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse a single TGI SSE ``data:`` payload.

        TGI streams ``{token: {text, ...}, generated_text: ..., details: ...}``
        per chunk. The terminal chunk has a non-empty ``generated_text`` and
        ``details.finish_reason`` set.
        """
        try:
            data = json.loads(raw_chunk)
        except json.JSONDecodeError:
            return GenericStreamingChunk(text="", is_finished=False)

        token = data.get("token") or {}
        text = token.get("text", "") or ""

        # Detect end-of-stream by the presence of details + generated_text.
        details = data.get("details") or {}
        finish_reason = self._map_finish_reason(details.get("finish_reason")) if details else None
        is_finished = bool(finish_reason)

        usage = None
        if details:
            completion_tokens = int(details.get("generated_tokens") or 0)
            usage = {
                "prompt_tokens": 0,
                "completion_tokens": completion_tokens,
                "total_tokens": completion_tokens,
            }

        return GenericStreamingChunk(
            text=text,
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=None,
            is_finished=is_finished,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _messages_to_prompt(messages: list[dict]) -> str:
        """Flatten an OpenAI messages array into a single prompt string.

        Uses a simple ``role: content`` format that works for most
        chat-tuned base models. Operators wanting a model-specific
        chat template (e.g. Llama 3 special tokens) should run TGI's
        OpenAI-compatible ``/v1/chat/completions`` endpoint via
        :class:`OpenAICompatProvider` instead.
        """
        parts: list[str] = []
        for msg in messages or []:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, list):
                # Multi-modal content blocks — concatenate text-only parts.
                content = " ".join(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                )
            parts.append(f"{role}: {content}")
        parts.append("assistant:")
        return "\n".join(parts)

    @staticmethod
    def _map_finish_reason(tgi_reason: Optional[str]) -> str:
        """Map TGI's finish_reason vocabulary to OpenAI's."""
        if not tgi_reason:
            return "stop"
        mapping = {
            "length": "length",
            "eos_token": "stop",
            "stop_sequence": "stop",
        }
        return mapping.get(tgi_reason, "stop")


def create_huggingface_tgi_provider() -> HuggingFaceTGIProvider:
    """Factory for env-driven HuggingFaceTGIProvider construction."""
    return HuggingFaceTGIProvider()
