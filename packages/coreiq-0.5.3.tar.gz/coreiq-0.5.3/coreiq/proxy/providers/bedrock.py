"""AWS Bedrock provider for the CoreIQ proxy.

Supports Claude, Llama, Mistral, and Titan models via the Bedrock
Converse API.  Authentication uses AWS SigV4 signing implemented with
stdlib only (hashlib, hmac, urllib.parse).  When *boto3* is available
it is used for credential resolution and signing for simplicity;
otherwise the pure-stdlib path handles everything.

Bedrock Converse API differences from direct Anthropic/OpenAI APIs:
  - Endpoint: ``POST /model/{model_id}/converse`` (or ``converse-stream``)
  - Messages use content blocks: ``[{"text": "..."}]``
  - System prompt is a top-level ``system`` array of text blocks
  - Inference params live under ``inferenceConfig``
  - Tool definitions live under ``toolConfig``
  - Streaming returns a JSON event stream (not SSE)
"""

from __future__ import annotations

import datetime
import hashlib
import hmac
import json
import logging
import os
import uuid
from typing import Any
from urllib.parse import quote, urlparse

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.bedrock")

# ---------------------------------------------------------------------------
# Model ID mapping
# ---------------------------------------------------------------------------

# User-friendly names -> Bedrock model identifiers.
_MODEL_MAP: dict[str, str] = {
    "claude-sonnet-4-6": "anthropic.claude-sonnet-4-6-v1",
    "claude-haiku-4-5": "anthropic.claude-haiku-4-5-20251001-v1:0",
    "claude-3-5-sonnet-latest": "anthropic.claude-3-5-sonnet-20241022-v2:0",
    "claude-3-5-sonnet-20241022": "anthropic.claude-3-5-sonnet-20241022-v2:0",
    "claude-3-5-haiku-latest": "anthropic.claude-3-5-haiku-20241022-v1:0",
    "claude-3-5-haiku-20241022": "anthropic.claude-3-5-haiku-20241022-v1:0",
    "claude-3-opus-20240229": "anthropic.claude-3-opus-20240229-v1:0",
    "claude-3-sonnet-20240229": "anthropic.claude-3-sonnet-20240229-v1:0",
    "claude-3-haiku-20240307": "anthropic.claude-3-haiku-20240307-v1:0",
    "llama3-70b": "meta.llama3-70b-instruct-v1:0",
    "llama3-8b": "meta.llama3-8b-instruct-v1:0",
    "llama3-1-70b": "meta.llama3-1-70b-instruct-v1:0",
    "llama3-1-8b": "meta.llama3-1-8b-instruct-v1:0",
    "mistral-large": "mistral.mistral-large-2407-v1:0",
    "mistral-small": "mistral.mistral-small-2402-v1:0",
    "mixtral-8x7b": "mistral.mixtral-8x7b-instruct-v0:1",
    "titan-premier": "amazon.titan-text-premier-v2:0",
    "titan-express": "amazon.titan-text-express-v1",
    "titan-lite": "amazon.titan-text-lite-v1",
}

# Parameters accepted by the Bedrock Converse API (mapped from OpenAI names).
_BEDROCK_PARAMS = [
    "model",
    "messages",
    "max_tokens",
    "temperature",
    "top_p",
    "stream",
    "tools",
    "tool_choice",
    "stop",
    "system",
]

# Mapping from Bedrock stopReason to OpenAI finish_reason.
_STOP_REASON_MAP = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
    "content_filtered": "content_filter",
}


class BedrockProvider(ProviderConfig):
    """AWS Bedrock Converse API provider.

    Parameters
    ----------
    region:
        AWS region for the Bedrock endpoint.  Falls back to
        ``AWS_REGION``, ``AWS_DEFAULT_REGION``, then ``us-east-1``.
    access_key:
        AWS access key ID.  Falls back to ``AWS_ACCESS_KEY_ID``.
    secret_key:
        AWS secret access key.  Falls back to ``AWS_SECRET_ACCESS_KEY``.
    session_token:
        Optional AWS session token for temporary credentials.
        Falls back to ``AWS_SESSION_TOKEN``.
    default_max_tokens:
        Default ``maxTokens`` when the request doesn't specify one.
    """

    provider_name = "bedrock"

    def __init__(
        self,
        *,
        region: str | None = None,
        access_key: str | None = None,
        secret_key: str | None = None,
        session_token: str | None = None,
        default_max_tokens: int = 4096,
    ) -> None:
        self.region = (
            region
            or os.environ.get("AWS_REGION")
            or os.environ.get("AWS_DEFAULT_REGION")
            or "us-east-1"
        )
        self.default_max_tokens = default_max_tokens

        # Credential resolution: explicit args > env vars > boto3 chain.
        self._access_key = access_key or os.environ.get("AWS_ACCESS_KEY_ID", "")
        self._secret_key = secret_key or os.environ.get("AWS_SECRET_ACCESS_KEY", "")
        self._session_token = session_token or os.environ.get("AWS_SESSION_TOKEN", "")
        self._boto3_session = None

        # If explicit creds aren't available, try boto3 for credential chain.
        if not self._access_key or not self._secret_key:
            try:
                import boto3
                self._boto3_session = boto3.Session(region_name=self.region)
                creds = self._boto3_session.get_credentials()
                if creds is not None:
                    frozen = creds.get_frozen_credentials()
                    self._access_key = frozen.access_key or ""
                    self._secret_key = frozen.secret_key or ""
                    self._session_token = frozen.token or ""
                    logger.info("Bedrock credentials resolved via boto3 credential chain")
            except ImportError:
                logger.debug("boto3 not available — using env var credentials only")
            except Exception as exc:
                logger.debug("boto3 credential resolution failed: %s", exc)

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        """Return parameters accepted by the Bedrock Converse API."""
        return list(_BEDROCK_PARAMS)

    def get_api_base(self) -> str:
        """Return the Bedrock runtime endpoint base URL."""
        return f"https://bedrock-runtime.{self.region}.amazonaws.com"

    def validate_environment(self) -> bool:
        """Check that AWS credentials are available."""
        if not self._access_key or not self._secret_key:
            logger.warning(
                "AWS credentials not found — Bedrock provider will not work. "
                "Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY, or install boto3."
            )
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Translate an OpenAI-style request to the Bedrock Converse API format."""
        model_id = self._resolve_model_id(request.model)

        # Choose endpoint based on streaming.
        action = "converse-stream" if request.stream else "converse"
        url = f"{self.get_api_base()}/model/{_uri_encode(model_id)}/{action}"

        # Build messages in Bedrock Converse format.
        system_blocks, messages = self._extract_system(request.messages)
        converse_messages = self._translate_messages(messages)

        body: dict[str, Any] = {
            "messages": converse_messages,
        }

        # System prompt as top-level array of text blocks.
        if system_blocks:
            body["system"] = system_blocks

        # Inference configuration.
        inference_config: dict[str, Any] = {}
        inference_config["maxTokens"] = request.max_tokens or self.default_max_tokens
        if request.temperature is not None:
            inference_config["temperature"] = request.temperature
        if request.top_p is not None:
            inference_config["topP"] = request.top_p
        if request.stop is not None:
            stop_seqs = request.stop if isinstance(request.stop, list) else [request.stop]
            inference_config["stopSequences"] = stop_seqs
        body["inferenceConfig"] = inference_config

        # Tool configuration.
        if request.tools:
            body["toolConfig"] = self._translate_tool_config(request.tools, request.tool_choice)

        # Sign the request with SigV4.
        payload = json.dumps(body)
        now = datetime.datetime.now(datetime.timezone.utc)
        headers = self._sign_v4(
            method="POST",
            url=url,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            payload=payload,
            timestamp=now,
        )

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Translate a Bedrock Converse response to a ProviderResponse."""
        output = raw_response.get("output", {})
        message = output.get("message", {})
        content_blocks = message.get("content", [])

        text_parts: list[str] = []
        tool_calls: list[dict] = []

        for block in content_blocks:
            if "text" in block:
                text_parts.append(block["text"])
            elif "toolUse" in block:
                tu = block["toolUse"]
                tool_calls.append({
                    "id": tu.get("toolUseId", f"call_{uuid.uuid4().hex[:12]}"),
                    "type": "function",
                    "function": {
                        "name": tu.get("name", ""),
                        "arguments": json.dumps(tu.get("input", {})),
                    },
                })

        stop_reason = raw_response.get("stopReason", "end_turn")
        finish_reason = _STOP_REASON_MAP.get(stop_reason, "stop")

        usage_raw = raw_response.get("usage", {})
        usage = {
            "prompt_tokens": usage_raw.get("inputTokens", 0),
            "completion_tokens": usage_raw.get("outputTokens", 0),
            "total_tokens": (
                usage_raw.get("inputTokens", 0) + usage_raw.get("outputTokens", 0)
            ),
        }

        return ProviderResponse(
            id=raw_response.get("ResponseMetadata", {}).get("RequestId", f"bedrock-{uuid.uuid4().hex[:12]}"),
            model=raw_response.get("model", ""),
            content="\n".join(text_parts) if text_parts else "",
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls if tool_calls else None,
            raw=raw_response,
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse a Bedrock Converse streaming event.

        Bedrock streams JSON events (not SSE).  Each event has a single
        top-level key indicating its type:

        - ``messageStart`` — role of the assistant message
        - ``contentBlockStart`` — signals a new text or toolUse block
        - ``contentBlockDelta`` — incremental text or tool input
        - ``contentBlockStop`` — block finished
        - ``messageStop`` — final stop reason
        - ``metadata`` — usage statistics
        """
        data = json.loads(raw_chunk)

        # messageStart — beginning of response
        if "messageStart" in data:
            return GenericStreamingChunk(
                provider_specific={"event": "messageStart", "role": data["messageStart"].get("role", "")},
            )

        # contentBlockStart — new content block
        if "contentBlockStart" in data:
            block_start = data["contentBlockStart"]
            start_info = block_start.get("start", {})
            if "toolUse" in start_info:
                tu = start_info["toolUse"]
                tool_call = {
                    "index": block_start.get("contentBlockIndex", 0),
                    "id": tu.get("toolUseId", f"call_{uuid.uuid4().hex[:12]}"),
                    "type": "function",
                    "function": {
                        "name": tu.get("name", ""),
                        "arguments": "",
                    },
                }
                return GenericStreamingChunk(tool_calls=[tool_call])
            return GenericStreamingChunk()

        # contentBlockDelta — incremental content
        if "contentBlockDelta" in data:
            block_delta = data["contentBlockDelta"]
            delta = block_delta.get("delta", {})

            if "text" in delta:
                return GenericStreamingChunk(text=delta["text"])

            if "toolUse" in delta:
                partial_input = delta["toolUse"].get("input", "")
                tool_call = {
                    "index": block_delta.get("contentBlockIndex", 0),
                    "function": {"arguments": partial_input},
                }
                return GenericStreamingChunk(tool_calls=[tool_call])

            return GenericStreamingChunk()

        # contentBlockStop
        if "contentBlockStop" in data:
            return GenericStreamingChunk()

        # messageStop — end of message
        if "messageStop" in data:
            stop_reason = data["messageStop"].get("stopReason", "end_turn")
            finish_reason = _STOP_REASON_MAP.get(stop_reason, "stop")
            return GenericStreamingChunk(
                finish_reason=finish_reason,
                is_finished=True,
            )

        # metadata — usage info at end of stream
        if "metadata" in data:
            meta = data["metadata"]
            usage_raw = meta.get("usage", {})
            usage = None
            if usage_raw:
                usage = {
                    "prompt_tokens": usage_raw.get("inputTokens", 0),
                    "completion_tokens": usage_raw.get("outputTokens", 0),
                    "total_tokens": (
                        usage_raw.get("inputTokens", 0) + usage_raw.get("outputTokens", 0)
                    ),
                }
            return GenericStreamingChunk(
                usage=usage,
                is_finished=True,
                provider_specific={"event": "metadata", "metrics": meta.get("metrics", {})},
            )

        # Unknown event — return empty chunk.
        return GenericStreamingChunk()

    # ------------------------------------------------------------------
    # SigV4 signing (stdlib only)
    # ------------------------------------------------------------------

    def _sign_v4(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        payload: str,
        timestamp: datetime.datetime,
    ) -> dict[str, str]:
        """AWS SigV4 signing using stdlib only (hashlib, hmac).

        Returns a complete set of headers including the Authorization header.
        """
        service = "bedrock"
        parsed = urlparse(url)
        host = parsed.hostname or ""
        path = parsed.path or "/"
        query = parsed.query or ""

        # Timestamps.
        amz_date = timestamp.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = timestamp.strftime("%Y%m%d")

        # Headers to sign.
        signed_headers_dict = dict(headers)
        signed_headers_dict["host"] = host
        signed_headers_dict["x-amz-date"] = amz_date
        if self._session_token:
            signed_headers_dict["x-amz-security-token"] = self._session_token

        # Canonical headers (sorted, lowercase).
        canonical_header_names = sorted(k.lower() for k in signed_headers_dict)
        canonical_headers = ""
        for name in canonical_header_names:
            # Find the original key (case-insensitive).
            for k, v in signed_headers_dict.items():
                if k.lower() == name:
                    canonical_headers += f"{name}:{v.strip()}\n"
                    break
        signed_headers_str = ";".join(canonical_header_names)

        # Payload hash.
        payload_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()

        # Canonical request.
        canonical_request = "\n".join([
            method,
            _uri_encode_path(path),
            _canonical_query_string(query),
            canonical_headers,
            signed_headers_str,
            payload_hash,
        ])

        # String to sign.
        credential_scope = f"{date_stamp}/{self.region}/{service}/aws4_request"
        string_to_sign = "\n".join([
            "AWS4-HMAC-SHA256",
            amz_date,
            credential_scope,
            hashlib.sha256(canonical_request.encode("utf-8")).hexdigest(),
        ])

        # Signing key (HMAC chain).
        signing_key = _get_signature_key(self._secret_key, date_stamp, self.region, service)

        # Signature.
        signature = hmac.new(
            signing_key,
            string_to_sign.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        # Authorization header.
        authorization = (
            f"AWS4-HMAC-SHA256 "
            f"Credential={self._access_key}/{credential_scope}, "
            f"SignedHeaders={signed_headers_str}, "
            f"Signature={signature}"
        )

        # Build final headers.
        result = dict(headers)
        result["x-amz-date"] = amz_date
        result["x-amz-content-sha256"] = payload_hash
        result["Authorization"] = authorization
        if self._session_token:
            result["x-amz-security-token"] = self._session_token

        return result

    # ------------------------------------------------------------------
    # Model resolution
    # ------------------------------------------------------------------

    def _resolve_model_id(self, model: str) -> str:
        """Map a user-friendly model name to a Bedrock model ID.

        Accepts:
          - Direct Bedrock IDs (e.g. ``anthropic.claude-sonnet-4-6-v1``)
          - Short names from ``_MODEL_MAP``
          - Names already containing a dot (assumed to be valid Bedrock IDs)
        """
        # Strip the "bedrock/" prefix if it leaked through.
        if model.startswith("bedrock/"):
            model = model[len("bedrock/"):]

        # Exact match in our map.
        if model in _MODEL_MAP:
            return _MODEL_MAP[model]

        # Already looks like a Bedrock model ID (contains a dot).
        if "." in model:
            return model

        # Try prefix matching for versioned names.
        for short_name, bedrock_id in _MODEL_MAP.items():
            if model.startswith(short_name):
                return bedrock_id

        # Return as-is and let Bedrock reject it if invalid.
        logger.warning(
            "Bedrock model %r not found in mapping — passing through as-is", model
        )
        return model

    # ------------------------------------------------------------------
    # Message translation helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_system(messages: list[dict]) -> tuple[list[dict], list[dict]]:
        """Separate system messages into Bedrock system blocks.

        Returns (system_blocks, remaining_messages) where system_blocks
        is a list of ``{"text": "..."}`` dicts.
        """
        system_blocks: list[dict] = []
        remaining: list[dict] = []

        for msg in messages:
            if msg.get("role") == "system":
                content = msg.get("content", "")
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            system_blocks.append({"text": block.get("text", "")})
                        elif isinstance(block, str):
                            system_blocks.append({"text": block})
                else:
                    system_blocks.append({"text": str(content)})
            else:
                remaining.append(msg)

        return system_blocks, remaining

    @staticmethod
    def _translate_messages(messages: list[dict]) -> list[dict]:
        """Translate OpenAI-format messages to Bedrock Converse format.

        Bedrock Converse expects:
          - ``role``: "user" or "assistant"
          - ``content``: list of content blocks (``{"text": "..."}``,
            ``{"toolUse": {...}}``, ``{"toolResult": {...}}``)
        """
        result: list[dict] = []

        for msg in messages:
            role = msg.get("role", "user")

            # Tool result messages (OpenAI role="tool").
            if role == "tool":
                tool_result_block = {
                    "toolResult": {
                        "toolUseId": msg.get("tool_call_id", ""),
                        "content": [{"text": str(msg.get("content", ""))}],
                    }
                }
                # Bedrock requires tool results under role "user".
                # Merge with previous user message if possible, otherwise create new.
                if result and result[-1].get("role") == "user":
                    result[-1]["content"].append(tool_result_block)
                else:
                    result.append({
                        "role": "user",
                        "content": [tool_result_block],
                    })
                continue

            # Assistant messages with tool_calls.
            if role == "assistant" and msg.get("tool_calls"):
                content_blocks: list[dict] = []
                text_content = msg.get("content")
                if text_content:
                    content_blocks.append({"text": text_content})
                for tc in msg["tool_calls"]:
                    func = tc.get("function", {})
                    arguments = func.get("arguments", "{}")
                    if isinstance(arguments, str):
                        try:
                            arguments = json.loads(arguments)
                        except (json.JSONDecodeError, TypeError):
                            arguments = {}
                    content_blocks.append({
                        "toolUse": {
                            "toolUseId": tc.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                            "name": func.get("name", ""),
                            "input": arguments,
                        }
                    })
                result.append({"role": "assistant", "content": content_blocks})
                continue

            # Standard user/assistant messages.
            content = msg.get("content", "")
            if isinstance(content, str):
                content_blocks = [{"text": content}] if content else [{"text": ""}]
            elif isinstance(content, list):
                # Translate OpenAI content block format to Bedrock format.
                content_blocks = []
                for block in content:
                    if isinstance(block, str):
                        content_blocks.append({"text": block})
                    elif isinstance(block, dict):
                        if block.get("type") == "text":
                            content_blocks.append({"text": block.get("text", "")})
                        elif block.get("type") == "image_url":
                            # Bedrock supports images via base64 in content blocks.
                            image_url = block.get("image_url", {}).get("url", "")
                            if image_url.startswith("data:"):
                                # Parse data URI: data:image/png;base64,<data>
                                try:
                                    header, b64data = image_url.split(",", 1)
                                    media_type = header.split(":")[1].split(";")[0]
                                    content_blocks.append({
                                        "image": {
                                            "format": media_type.split("/")[1],
                                            "source": {
                                                "bytes": b64data,
                                            },
                                        }
                                    })
                                except (ValueError, IndexError):
                                    content_blocks.append({"text": f"[Image: {image_url[:100]}]"})
                            else:
                                # URL-based images not directly supported by Bedrock.
                                content_blocks.append({"text": f"[Image URL: {image_url}]"})
                        elif block.get("type") == "tool_result":
                            # Already in Anthropic format — convert to Bedrock.
                            content_blocks.append({
                                "toolResult": {
                                    "toolUseId": block.get("tool_use_id", ""),
                                    "content": [{"text": str(block.get("content", ""))}],
                                }
                            })
                        else:
                            content_blocks.append({"text": json.dumps(block)})
                if not content_blocks:
                    content_blocks = [{"text": ""}]
            else:
                content_blocks = [{"text": str(content)}]

            # Map "assistant" through; everything else defaults.
            bedrock_role = "assistant" if role == "assistant" else "user"
            result.append({"role": bedrock_role, "content": content_blocks})

        # Bedrock requires alternating user/assistant turns.
        # Merge consecutive same-role messages.
        merged: list[dict] = []
        for msg in result:
            if merged and merged[-1].get("role") == msg.get("role"):
                merged[-1]["content"].extend(msg["content"])
            else:
                merged.append(msg)

        return merged

    @staticmethod
    def _translate_tool_config(
        tools: list[dict],
        tool_choice: str | dict | None = None,
    ) -> dict:
        """Convert OpenAI tool definitions to Bedrock toolConfig format.

        Bedrock format::

            {
                "tools": [
                    {
                        "toolSpec": {
                            "name": "...",
                            "description": "...",
                            "inputSchema": {"json": {...}}
                        }
                    }
                ],
                "toolChoice": {"auto": {}} | {"any": {}} | {"tool": {"name": "X"}}
            }
        """
        bedrock_tools: list[dict] = []
        for tool in tools:
            if tool.get("type") == "function":
                func = tool.get("function", {})
                bedrock_tools.append({
                    "toolSpec": {
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                        "inputSchema": {
                            "json": func.get("parameters", {"type": "object", "properties": {}}),
                        },
                    }
                })
            else:
                # Pass through in case of already-Bedrock-formatted tools.
                bedrock_tools.append(tool)

        config: dict[str, Any] = {"tools": bedrock_tools}

        # Tool choice.
        if tool_choice is not None:
            if isinstance(tool_choice, str):
                if tool_choice == "auto":
                    config["toolChoice"] = {"auto": {}}
                elif tool_choice == "required":
                    config["toolChoice"] = {"any": {}}
                elif tool_choice == "none":
                    # Bedrock doesn't have "none" — omit toolChoice to let model decide.
                    pass
                else:
                    config["toolChoice"] = {"auto": {}}
            elif isinstance(tool_choice, dict):
                func = tool_choice.get("function", {})
                name = func.get("name", "")
                if name:
                    config["toolChoice"] = {"tool": {"name": name}}
                else:
                    config["toolChoice"] = {"auto": {}}

        return config


# ---------------------------------------------------------------------------
# SigV4 helper functions (stdlib)
# ---------------------------------------------------------------------------


def _hmac_sha256(key: bytes, msg: str) -> bytes:
    """HMAC-SHA256 with bytes key and string message."""
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def _get_signature_key(secret_key: str, date_stamp: str, region: str, service: str) -> bytes:
    """Derive the SigV4 signing key via HMAC chain.

    signing_key = HMAC(HMAC(HMAC(HMAC("AWS4" + secret, date), region), service), "aws4_request")
    """
    k_date = _hmac_sha256(f"AWS4{secret_key}".encode("utf-8"), date_stamp)
    k_region = hmac.new(k_date, region.encode("utf-8"), hashlib.sha256).digest()
    k_service = hmac.new(k_region, service.encode("utf-8"), hashlib.sha256).digest()
    k_signing = hmac.new(k_service, b"aws4_request", hashlib.sha256).digest()
    return k_signing


def _uri_encode(value: str) -> str:
    """URI-encode a value for use in a URL path segment (for model IDs with colons)."""
    return quote(value, safe="")


def _uri_encode_path(path: str) -> str:
    """URI-encode a full path, preserving forward slashes."""
    return quote(path, safe="/")


def _canonical_query_string(query: str) -> str:
    """Sort query parameters for canonical request (SigV4 requirement)."""
    if not query:
        return ""
    params = []
    for param in query.split("&"):
        if "=" in param:
            key, value = param.split("=", 1)
            params.append((quote(key, safe=""), quote(value, safe="")))
        else:
            params.append((quote(param, safe=""), ""))
    params.sort(key=lambda x: (x[0], x[1]))
    return "&".join(f"{k}={v}" for k, v in params)
