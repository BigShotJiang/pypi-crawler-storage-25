"""Groq provider for the CoreIQ proxy.

Groq exposes an OpenAI-compatible API for fast inference on custom
hardware.  This provider extends :class:`OpenAICompatProvider` with
Groq-specific defaults and the full OpenAI parameter set.
"""

from __future__ import annotations

import logging
import os

from .openai_compat import OpenAICompatProvider

logger = logging.getLogger("coreiq.proxy.groq")

# Groq supports most OpenAI chat-completion parameters.
_GROQ_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "tools",
    "tool_choice",
    "response_format",
    "stop",
    "frequency_penalty",
    "presence_penalty",
    "seed",
    "user",
    "n",
    "stream_options",
    "parallel_tool_calls",
]


class GroqProvider(OpenAICompatProvider):
    """Groq inference provider (OpenAI-compatible).

    Parameters
    ----------
    api_key:
        Groq API key.  Falls back to ``GROQ_API_KEY``.
    api_base:
        Base URL override (default ``https://api.groq.com/openai/v1``).
    """

    provider_name = "groq"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("GROQ_API_KEY", "")
        resolved_base = (api_base or os.environ.get("GROQ_API_BASE", "")).rstrip("/")
        super().__init__(
            base_url=resolved_base or "https://api.groq.com/openai/v1",
            api_key=resolved_key,
            supported_params=list(_GROQ_PARAMS),
            provider_label="groq",
        )

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("GROQ_API_KEY is not set — Groq provider will not work")
            return False
        return True
