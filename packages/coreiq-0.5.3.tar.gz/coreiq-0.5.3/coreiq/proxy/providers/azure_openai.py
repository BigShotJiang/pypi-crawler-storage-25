"""Azure OpenAI provider for the CoreIQ proxy.

Subclasses :class:`OpenAIProvider` to inherit the OpenAI request/response
shape and the existing Azure URL templating, but adds:

- A dedicated provider name (``azure``) so the registry can route
  ``azure/<deployment>`` model strings explicitly without needing the
  legacy "is_azure" heuristic that triggered on the substring ``azure``
  in the api_base.
- AAD / Managed Identity token caching (optional, requires
  ``coreiq[azure]`` which adds ``azure-identity``). When AAD auth is
  configured, the provider mints a short-lived bearer token via
  ``DefaultAzureCredential``, caches it in memory until ~5 minutes
  before expiry, then refreshes.
- Multiple deployment-name → endpoint mappings via a single env var
  ``AZURE_OPENAI_DEPLOYMENTS`` (JSON dict) so a single provider instance
  can route ``azure/gpt-4`` and ``azure/gpt-4o`` to different deployment
  names against the same endpoint.

Configuration
-------------

Static API key (most common):

::

    AZURE_OPENAI_ENDPOINT=https://myresource.openai.azure.com
    AZURE_OPENAI_API_KEY=...
    AZURE_OPENAI_API_VERSION=2024-06-01     # optional, has a default
    AZURE_OPENAI_DEPLOYMENTS='{"gpt-4": "gpt-4-prod", "gpt-4o": "gpt-4o-prod"}'

AAD / Managed Identity:

::

    pip install "coreiq[azure]"
    AZURE_OPENAI_ENDPOINT=https://myresource.openai.azure.com
    AZURE_OPENAI_AUTH=aad     # opt in to AAD; api_key is ignored
    # No further config — DefaultAzureCredential discovers your
    # environment (managed identity, env vars, az cli, etc.).

The pipeline routes ``azure/gpt-4`` → this provider via the registry's
``provider/model`` syntax. If a deployment alias is registered, the
deployment name in the URL is the *value* (``gpt-4-prod``); otherwise
the bare model string passes through unchanged.
"""
from __future__ import annotations

import json
import logging
import os
import time
from typing import Optional

from .openai import OpenAIProvider

logger = logging.getLogger("coreiq.proxy.azure_openai")


class AzureOpenAIProvider(OpenAIProvider):
    """Azure OpenAI provider with deployment-name routing + AAD support.

    Subclasses :class:`OpenAIProvider` so the request/response transforms
    and streaming chunk parser come for free. Overrides only the bits
    that are Azure-specific: provider name, the URL builder (so it picks
    the deployment name from a registered map rather than echoing the
    raw model string), and the auth headers (Bearer token from AAD when
    in AAD mode, otherwise the inherited ``api-key`` flow).
    """

    provider_name = "azure"

    # AAD bearer tokens are minted with ~60 minute expiry. We refresh
    # them eagerly 5 minutes before expiry to avoid races.
    _AAD_REFRESH_BUFFER_S = 5 * 60
    _AAD_SCOPE = "https://cognitiveservices.azure.com/.default"

    def __init__(
        self,
        *,
        endpoint: Optional[str] = None,
        api_key: Optional[str] = None,
        api_version: Optional[str] = None,
        deployments: Optional[dict[str, str]] = None,
        auth_mode: Optional[str] = None,
    ) -> None:
        # Resolve config from explicit args or env.
        endpoint = (
            endpoint
            or os.environ.get("AZURE_OPENAI_ENDPOINT", "")
            or os.environ.get("OPENAI_API_BASE", "")
        )
        api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY", "") or os.environ.get("OPENAI_API_KEY", "")
        api_version = api_version or os.environ.get("AZURE_OPENAI_API_VERSION") or "2024-06-01"
        auth_mode = (auth_mode or os.environ.get("AZURE_OPENAI_AUTH", "key")).lower()

        super().__init__(
            api_key=api_key,
            api_base=endpoint,
            api_version=api_version,
        )

        # Parent sets `_is_azure` based on substring match. Force it on
        # so the inherited `transform_request()` always picks the Azure
        # branch even when the endpoint hostname doesn't contain "azure".
        self._is_azure = True

        # Deployment alias map: model_name -> deployment_name.
        if deployments is None:
            raw = os.environ.get("AZURE_OPENAI_DEPLOYMENTS", "")
            if raw:
                try:
                    deployments = json.loads(raw)
                    if not isinstance(deployments, dict):
                        logger.warning(
                            "AZURE_OPENAI_DEPLOYMENTS must be a JSON object; ignoring"
                        )
                        deployments = None
                except json.JSONDecodeError as exc:
                    logger.warning(
                        "AZURE_OPENAI_DEPLOYMENTS is not valid JSON: %s", exc
                    )
                    deployments = None
        self._deployments: dict[str, str] = dict(deployments) if deployments else {}

        # AAD state — populated lazily on first call when in aad mode.
        self._auth_mode = auth_mode
        self._aad_token: Optional[str] = None
        self._aad_expires_at: float = 0.0
        self._aad_credential = None  # azure.identity.DefaultAzureCredential

        if auth_mode == "aad":
            self._init_aad_credential()

    # ------------------------------------------------------------------
    # AAD plumbing (optional)
    # ------------------------------------------------------------------

    def _init_aad_credential(self) -> None:
        """Construct a DefaultAzureCredential lazily.

        Falls back to a clear log message when ``coreiq[azure]`` isn't
        installed, so the operator can switch to api-key auth without a
        cryptic ImportError trace.
        """
        try:
            from azure.identity import DefaultAzureCredential
        except ImportError:
            logger.warning(
                "AZURE_OPENAI_AUTH=aad requires azure-identity. "
                "Install with: pip install coreiq[azure]"
            )
            return
        self._aad_credential = DefaultAzureCredential()

    def _get_aad_token(self) -> Optional[str]:
        """Return a cached AAD bearer token, refreshing when near expiry."""
        if self._aad_credential is None:
            return None
        now = time.time()
        if self._aad_token and (self._aad_expires_at - now) > self._AAD_REFRESH_BUFFER_S:
            return self._aad_token
        try:
            token = self._aad_credential.get_token(self._AAD_SCOPE)
        except Exception as exc:  # pragma: no cover — depends on env
            logger.error("Failed to acquire AAD token for Azure OpenAI: %s", exc)
            return None
        self._aad_token = token.token
        self._aad_expires_at = float(token.expires_on)
        return self._aad_token

    # ------------------------------------------------------------------
    # Overrides
    # ------------------------------------------------------------------

    def get_api_base(self) -> str:
        """Azure has no implicit default base URL — endpoint must be set."""
        if self.api_base:
            return self.api_base
        # Inherit a clear failure mode rather than fabricating a URL.
        return ""

    def validate_environment(self) -> bool:
        if not self.api_base:
            logger.warning(
                "AZURE_OPENAI_ENDPOINT is not set — Azure OpenAI provider will not work"
            )
            return False
        if self._auth_mode == "aad":
            if self._aad_credential is None:
                return False
            return True
        if not self.api_key:
            logger.warning(
                "AZURE_OPENAI_API_KEY is not set — Azure OpenAI provider will not work"
            )
            return False
        return True

    def _resolve_deployment(self, model: str) -> str:
        """Map a logical model name to the configured deployment name."""
        return self._deployments.get(model, model)

    def _azure_url(self, model: str) -> str:
        """Override parent's URL builder to use the deployment alias."""
        deployment = self._resolve_deployment(model)
        base = self.api_base.rstrip("/")
        return (
            f"{base}/openai/deployments/{deployment}/chat/completions"
            f"?api-version={self.api_version}"
        )

    def _azure_headers(self) -> dict[str, str]:
        """Use AAD bearer token when configured, otherwise the api-key header."""
        if self._auth_mode == "aad":
            token = self._get_aad_token()
            if token:
                return {
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                }
            # Fall through to api-key auth as a degraded mode if AAD failed.
        return {
            "api-key": self.api_key,
            "Content-Type": "application/json",
        }

    def transform_embedding_request(self, body: dict) -> tuple[str, dict, dict]:
        """Override to use the deployment alias for embedding requests too."""
        model = body.get("model", "")
        deployment = self._resolve_deployment(model)
        base = self.api_base.rstrip("/")
        url = (
            f"{base}/openai/deployments/{deployment}/embeddings"
            f"?api-version={self.api_version}"
        )
        headers = self._azure_headers()
        body_out = dict(body)
        body_out.pop("model", None)
        return url, headers, body_out


def create_azure_openai_provider() -> AzureOpenAIProvider:
    """Factory for env-driven Azure OpenAI provider construction."""
    return AzureOpenAIProvider()
