"""Mistral AI provider for the CoreIQ proxy.

Mistral's chat API is largely OpenAI-compatible with minor differences:

* No ``n`` parameter (always generates a single completion).
* No ``logprobs`` support.
* Supports ``safe_prompt`` for guardrail injection.
* Uses Bearer token authentication.

This provider extends :class:`OpenAIProvider` and overrides only
the bits that differ.
"""

from __future__ import annotations

import logging
import os

from .base import (
    ProviderRequest,
)
from .openai import OpenAIProvider

logger = logging.getLogger("coreiq.proxy.mistral")

# Parameters the Mistral API accepts — OpenAI-like but without n/logprobs.
_MISTRAL_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "tools",
    "tool_choice",
    "response_format",
    "stop",
    "seed",
    "safe_prompt",
    "random_seed",
]


class MistralProvider(OpenAIProvider):
    """Mistral AI chat-completions provider.

    Extends OpenAIProvider since Mistral uses the same wire format,
    with a few parameter restrictions and a different base URL.

    Parameters
    ----------
    api_key:
        Mistral API key.  Falls back to ``MISTRAL_API_KEY``.
    api_base:
        Base URL override (default ``https://api.mistral.ai/v1``).
    """

    provider_name = "mistral"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("MISTRAL_API_KEY", "")
        self.api_base = (api_base or os.environ.get("MISTRAL_API_BASE", "")).rstrip("/")
        self.organization = None
        self._is_azure = False

    # ------------------------------------------------------------------
    # Overrides
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        """Return parameters accepted by the Mistral API."""
        return list(_MISTRAL_PARAMS)

    def get_api_base(self) -> str:
        """Return the effective API base URL."""
        return self.api_base or "https://api.mistral.ai/v1"

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("MISTRAL_API_KEY is not set — Mistral provider will not work")
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Build a Mistral-compatible request.

        Delegates to the OpenAI implementation for most of the work,
        then strips unsupported parameters and injects Mistral-specific
        extras.
        """
        url = f"{self.get_api_base()}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        body = request.to_dict()

        # Strip parameters Mistral does not support.
        body.pop("n", None)
        body.pop("logprobs", None)
        body.pop("top_logprobs", None)
        body.pop("frequency_penalty", None)
        body.pop("presence_penalty", None)
        body.pop("user", None)
        body.pop("logit_bias", None)

        # Mistral-specific: safe_prompt option.
        if "safe_prompt" in request.extra:
            body["safe_prompt"] = request.extra["safe_prompt"]

        # Mistral uses random_seed instead of seed.
        if "seed" in body:
            body["random_seed"] = body.pop("seed")

        # Inject stream_options for usage in streaming responses.
        if request.stream:
            body.setdefault("stream_options", {"include_usage": True})

        return url, headers, body
