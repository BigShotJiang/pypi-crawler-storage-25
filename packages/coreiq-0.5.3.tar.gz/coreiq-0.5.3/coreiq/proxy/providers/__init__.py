"""Provider implementations for the CoreIQ proxy."""

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
    ProviderError,
    ProviderTimeoutError,
    ProviderAuthError,
    ProviderRateLimitError,
)
from .registry import ProviderRegistry, get_provider_registry
from .openai import OpenAIProvider
from .anthropic import AnthropicProvider
from .openai_compat import (
    OpenAICompatProvider,
    create_vllm_provider,
    create_sglang_provider,
    create_ollama_provider,
)
from .google import GoogleProvider
from .mistral import MistralProvider
from .cohere import CohereProvider
from .groq import GroqProvider
from .together import TogetherProvider
from .deepseek import DeepSeekProvider
from .bedrock import BedrockProvider

__all__ = [
    # Base types
    "GenericStreamingChunk",
    "ProviderConfig",
    "ProviderRequest",
    "ProviderResponse",
    "ProviderError",
    "ProviderTimeoutError",
    "ProviderAuthError",
    "ProviderRateLimitError",
    # Registry
    "ProviderRegistry",
    "get_provider_registry",
    # Providers
    "OpenAIProvider",
    "AnthropicProvider",
    "OpenAICompatProvider",
    "GoogleProvider",
    "MistralProvider",
    "CohereProvider",
    "GroqProvider",
    "TogetherProvider",
    "DeepSeekProvider",
    "BedrockProvider",
    # Factory functions
    "create_vllm_provider",
    "create_sglang_provider",
    "create_ollama_provider",
]
