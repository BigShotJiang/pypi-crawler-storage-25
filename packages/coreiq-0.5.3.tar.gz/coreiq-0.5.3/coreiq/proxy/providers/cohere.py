"""Cohere provider for the CoreIQ proxy.

Cohere's Chat API v2 differs from the OpenAI format in several ways:

* Uses ``messages`` but roles are uppercased (``SYSTEM``, ``USER``,
  ``CHATBOT`` / ``ASSISTANT``).
* Response structure uses ``message``, ``usage.tokens`` for token counts.
* Tool definitions use a different schema format.
* Streaming uses SSE with typed events.
"""

from __future__ import annotations

import json
import logging
import os
import uuid

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.cohere")

# Parameters the Cohere Chat v2 API accepts.
_COHERE_PARAMS = [
    "model",
    "messages",
    "max_tokens",
    "temperature",
    "top_p",
    "top_k",
    "stream",
    "tools",
    "stop",
    "frequency_penalty",
    "presence_penalty",
    "seed",
]


class CohereProvider(ProviderConfig):
    """Cohere Chat v2 API provider.

    Parameters
    ----------
    api_key:
        Cohere API key.  Falls back to ``COHERE_API_KEY``.
    api_base:
        Base URL override (default ``https://api.cohere.com/v2``).
    default_max_tokens:
        Default output token limit when the request does not specify one.
    """

    provider_name = "cohere"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        default_max_tokens: int = 4096,
    ) -> None:
        self.api_key = api_key or os.environ.get("COHERE_API_KEY", "")
        self.api_base = (api_base or os.environ.get("COHERE_API_BASE", "")).rstrip("/")
        self.default_max_tokens = default_max_tokens

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        """Return parameters accepted by the Cohere Chat v2 API."""
        return list(_COHERE_PARAMS)

    def get_api_base(self) -> str:
        """Return the effective API base URL."""
        return self.api_base or "https://api.cohere.com/v2"

    # ------------------------------------------------------------------
    # Embedding support
    # ------------------------------------------------------------------

    def transform_embedding_request(self, body: dict) -> tuple[str, dict, dict]:
        url = f"{self.get_api_base()}/embed"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        inp = body.get("input", "")
        texts = inp if isinstance(inp, list) else [inp]
        out = {
            "texts": texts,
            "model": body.get("model", "embed-english-v3.0"),
            "input_type": "search_document",
        }
        return url, headers, out

    def transform_embedding_response(self, raw: dict) -> dict:
        embeddings = raw.get("embeddings", {})
        # Cohere v2 returns embeddings under "float" key
        vectors = embeddings.get("float", embeddings) if isinstance(embeddings, dict) else embeddings
        data = [{"object": "embedding", "index": i, "embedding": v} for i, v in enumerate(vectors)]
        meta = raw.get("meta", {}).get("billed_units", {})
        return {
            "object": "list",
            "data": data,
            "model": raw.get("model", ""),
            "usage": {"prompt_tokens": meta.get("input_tokens", 0), "total_tokens": meta.get("input_tokens", 0)},
        }

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("COHERE_API_KEY is not set — Cohere provider will not work")
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Translate an OpenAI-style request into the Cohere Chat v2 format."""
        url = f"{self.get_api_base()}/chat"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        messages = _convert_messages(request.messages)

        body: dict = {
            "model": request.model,
            "messages": messages,
        }

        if request.stream:
            body["stream"] = True

        if request.max_tokens is not None:
            body["max_tokens"] = request.max_tokens
        else:
            body["max_tokens"] = self.default_max_tokens

        if request.temperature is not None:
            body["temperature"] = request.temperature
        if request.top_p is not None:
            body["p"] = request.top_p
        if request.stop is not None:
            body["stop_sequences"] = (
                request.stop if isinstance(request.stop, list) else [request.stop]
            )
        if request.frequency_penalty is not None:
            body["frequency_penalty"] = request.frequency_penalty
        if request.presence_penalty is not None:
            body["presence_penalty"] = request.presence_penalty
        if request.seed is not None:
            body["seed"] = request.seed
        if "top_k" in request.extra:
            body["k"] = request.extra["top_k"]

        # Tools.
        if request.tools:
            body["tools"] = _translate_tools(request.tools)

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Translate a Cohere Chat v2 response to a ProviderResponse."""
        # Cohere v2 returns message with content array.
        message = raw_response.get("message", {})
        content_blocks = message.get("content", [])

        text_parts: list[str] = []
        tool_calls: list[dict] = []

        for block in content_blocks:
            if block.get("type") == "text":
                text_parts.append(block.get("text", ""))

        # Tool calls in Cohere v2.
        tc_blocks = message.get("tool_calls", [])
        for tc in tc_blocks:
            func = tc.get("function", {})
            tool_calls.append({
                "id": tc.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                "type": "function",
                "function": {
                    "name": func.get("name", ""),
                    "arguments": func.get("arguments", "{}"),
                },
            })

        finish_reason_raw = raw_response.get("finish_reason", "COMPLETE")
        finish_reason = _map_finish_reason(finish_reason_raw)

        usage_raw = raw_response.get("usage", {})
        tokens = usage_raw.get("tokens", {})
        usage = {
            "prompt_tokens": tokens.get("input_tokens", 0),
            "completion_tokens": tokens.get("output_tokens", 0),
            "total_tokens": (
                tokens.get("input_tokens", 0) + tokens.get("output_tokens", 0)
            ),
        }

        return ProviderResponse(
            id=raw_response.get("id", f"cohere-{uuid.uuid4().hex[:12]}"),
            model=raw_response.get("model", ""),
            content="\n".join(text_parts) if text_parts else "",
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls if tool_calls else None,
            raw=raw_response,
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse a single SSE ``data:`` payload from a Cohere stream.

        Cohere v2 streaming uses typed events similar to Anthropic.
        """
        data = json.loads(raw_chunk)
        event_type = data.get("type", "")

        if event_type == "content-start":
            return GenericStreamingChunk()

        if event_type == "content-delta":
            delta = data.get("delta", {})
            message = delta.get("message", {})
            content = message.get("content", {})
            text = content.get("text", "")
            return GenericStreamingChunk(text=text)

        if event_type == "content-end":
            return GenericStreamingChunk()

        if event_type == "tool-call-start":
            delta = data.get("delta", {})
            message = delta.get("message", {})
            tc = message.get("tool_calls", {})
            tool_call = {
                "index": data.get("index", 0),
                "id": tc.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                "type": "function",
                "function": {
                    "name": tc.get("function", {}).get("name", ""),
                    "arguments": "",
                },
            }
            return GenericStreamingChunk(tool_calls=[tool_call])

        if event_type == "tool-call-delta":
            delta = data.get("delta", {})
            message = delta.get("message", {})
            tc = message.get("tool_calls", {})
            args = tc.get("function", {}).get("arguments", "")
            tool_call = {
                "index": data.get("index", 0),
                "function": {"arguments": args},
            }
            return GenericStreamingChunk(tool_calls=[tool_call])

        if event_type == "tool-call-end":
            return GenericStreamingChunk()

        if event_type == "message-start":
            return GenericStreamingChunk()

        if event_type == "message-end":
            delta = data.get("delta", {})
            finish_reason_raw = delta.get("finish_reason", "COMPLETE")
            finish_reason = _map_finish_reason(finish_reason_raw)
            usage_raw = delta.get("usage", {})
            tokens = usage_raw.get("tokens", {})
            usage = None
            if tokens:
                usage = {
                    "prompt_tokens": tokens.get("input_tokens", 0),
                    "completion_tokens": tokens.get("output_tokens", 0),
                    "total_tokens": (
                        tokens.get("input_tokens", 0) + tokens.get("output_tokens", 0)
                    ),
                }
            return GenericStreamingChunk(
                finish_reason=finish_reason,
                usage=usage,
                is_finished=True,
            )

        # Unknown event — return empty chunk.
        return GenericStreamingChunk()


# ---------------------------------------------------------------------------
# Internal translation helpers
# ---------------------------------------------------------------------------


def _convert_messages(messages: list[dict]) -> list[dict]:
    """Convert OpenAI-style messages to Cohere v2 format.

    Cohere v2 uses standard role names (system, user, assistant, tool).
    """
    converted: list[dict] = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if role == "system":
            converted.append({"role": "system", "content": str(content)})
        elif role == "user":
            converted.append({"role": "user", "content": str(content)})
        elif role == "assistant":
            entry: dict = {"role": "assistant"}
            if msg.get("tool_calls"):
                entry["tool_calls"] = []
                for tc in msg["tool_calls"]:
                    func = tc.get("function", {})
                    entry["tool_calls"].append({
                        "id": tc.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                        "type": "function",
                        "function": {
                            "name": func.get("name", ""),
                            "arguments": func.get("arguments", "{}"),
                        },
                    })
                if content:
                    entry["content"] = str(content)
            else:
                entry["content"] = str(content)
            converted.append(entry)
        elif role == "tool":
            converted.append({
                "role": "tool",
                "tool_call_id": msg.get("tool_call_id", ""),
                "content": str(content),
            })
        else:
            converted.append({"role": "user", "content": str(content)})

    return converted


def _translate_tools(tools: list[dict]) -> list[dict]:
    """Convert OpenAI tool definitions to Cohere v2 format.

    Cohere v2 uses the same OpenAI-compatible tool format.
    """
    translated: list[dict] = []
    for tool in tools:
        if tool.get("type") == "function":
            translated.append(tool)
        else:
            translated.append(tool)
    return translated


def _map_finish_reason(reason: str) -> str:
    """Map Cohere finish reasons to OpenAI conventions."""
    mapping = {
        "COMPLETE": "stop",
        "MAX_TOKENS": "length",
        "STOP_SEQUENCE": "stop",
        "TOOL_CALL": "tool_calls",
        "ERROR": "stop",
    }
    return mapping.get(reason, "stop")
