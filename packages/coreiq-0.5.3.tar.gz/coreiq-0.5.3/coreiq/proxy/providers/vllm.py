"""First-class vLLM provider.

vLLM exposes an OpenAI-compatible server at ``http://<host>:8000/v1``.
This subclass surfaces vLLM-specific defaults (full parameter set
including ``logprobs``, ``best_of``) and an opt-in API key for clusters
deployed behind ``--api-key``.

Configuration::

    VLLM_BASE_URL=http://localhost:8000/v1
    VLLM_API_KEY=<key-if-server-was-started-with-one>
"""
from __future__ import annotations

import os

from .openai_compat import OpenAICompatProvider

_DEFAULT_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "top_k",
    "min_p",
    "stream",
    "stop",
    "frequency_penalty",
    "presence_penalty",
    "n",
    "best_of",
    "logprobs",
    "logit_bias",
    "tools",
    "tool_choice",
    "response_format",
    "seed",
]


class VLLMProvider(OpenAICompatProvider):
    provider_name = "vllm"

    def __init__(self, base_url: str | None = None, api_key: str | None = None) -> None:
        url = base_url or os.environ.get("VLLM_BASE_URL", "http://localhost:8000/v1")
        super().__init__(
            base_url=url,
            api_key=api_key or os.environ.get("VLLM_API_KEY", ""),
            supported_params=list(_DEFAULT_PARAMS),
            provider_label="vllm",
        )
