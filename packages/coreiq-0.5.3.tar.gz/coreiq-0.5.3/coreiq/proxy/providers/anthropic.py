"""Anthropic provider for the CoreIQ proxy.

Anthropic's Messages API differs significantly from the OpenAI
chat-completion format.  This provider handles all translation:

* System messages are extracted from the messages list and placed into
  the top-level ``system`` parameter.
* Tool definitions are translated from OpenAI's ``{type, function}``
  wrapper to Anthropic's flat ``{name, description, input_schema}``
  format.
* Streaming uses typed event objects (``message_start``,
  ``content_block_delta``, etc.) instead of OpenAI's uniform
  ``choices[].delta`` structure.
"""

from __future__ import annotations

import json
import logging
import os
import uuid

from .base import (
    GenericStreamingChunk,
    ProviderConfig,
    ProviderRequest,
    ProviderResponse,
)

logger = logging.getLogger("coreiq.proxy.anthropic")

_ANTHROPIC_API_VERSION = "2023-06-01"

# Parameters the Anthropic Messages API accepts.
_ANTHROPIC_PARAMS = [
    "model",
    "messages",
    "max_tokens",
    "temperature",
    "top_p",
    "top_k",
    "stream",
    "system",
    "tools",
    "tool_choice",
    "stop_sequences",
    "metadata",
]

# Mapping from Anthropic stop_reason to OpenAI finish_reason.
_STOP_REASON_MAP = {
    "end_turn": "stop",
    "stop_sequence": "stop",
    "max_tokens": "length",
    "tool_use": "tool_calls",
}


class AnthropicProvider(ProviderConfig):
    """Anthropic Messages API provider.

    Parameters
    ----------
    api_key:
        Anthropic API key.  Falls back to ``ANTHROPIC_API_KEY``.
    api_base:
        Base URL override (default ``https://api.anthropic.com``).
    api_version:
        Value for the ``anthropic-version`` header.
    default_max_tokens:
        Anthropic requires ``max_tokens`` on every request.  If the
        incoming ``ProviderRequest`` has no value, this default is used.
    """

    provider_name = "anthropic"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        api_version: str = _ANTHROPIC_API_VERSION,
        default_max_tokens: int = 4096,
    ) -> None:
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.api_base = (api_base or os.environ.get("ANTHROPIC_API_BASE", "")).rstrip("/")
        self.api_version = api_version
        self.default_max_tokens = default_max_tokens

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def get_supported_params(self, model: str) -> list[str]:
        """Return parameters accepted by the Anthropic Messages API."""
        return list(_ANTHROPIC_PARAMS)

    def get_api_base(self) -> str:
        """Return the effective API base URL."""
        return self.api_base or "https://api.anthropic.com"

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("ANTHROPIC_API_KEY is not set — Anthropic provider will not work")
            return False
        return True

    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Translate an OpenAI-style request into the Anthropic Messages format."""
        url = f"{self.get_api_base()}/v1/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": self.api_version,
            "Content-Type": "application/json",
        }

        system_parts, messages = _extract_system_messages(request.messages)
        messages = _merge_consecutive_user_messages(messages)
        messages = _normalise_message_content(messages)

        body: dict = {
            "model": request.model,
            "messages": messages,
            "max_tokens": request.max_tokens or self.default_max_tokens,
        }

        if request.stream:
            body["stream"] = True

        # Optional scalar parameters.
        if request.temperature is not None:
            body["temperature"] = request.temperature
        if request.top_p is not None:
            body["top_p"] = request.top_p
        if request.stop is not None:
            body["stop_sequences"] = (
                request.stop if isinstance(request.stop, list) else [request.stop]
            )

        # System prompt.
        if system_parts:
            body["system"] = system_parts

        # Tools.
        if request.tools:
            body["tools"] = _translate_tools(request.tools)
        if request.tool_choice is not None and request.tools:
            body["tool_choice"] = _translate_tool_choice(request.tool_choice)

        # User metadata.
        if request.user:
            body["metadata"] = {"user_id": request.user}

        # Forward whitelisted extra params.
        if "top_k" in request.extra:
            body["top_k"] = request.extra["top_k"]

        return url, headers, body

    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Translate an Anthropic Messages response to a ProviderResponse."""
        content_blocks = raw_response.get("content", [])
        text_parts: list[str] = []
        tool_calls: list[dict] = []

        for block in content_blocks:
            if block.get("type") == "text":
                text_parts.append(block.get("text", ""))
            elif block.get("type") == "tool_use":
                tool_calls.append({
                    "id": block.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                    "type": "function",
                    "function": {
                        "name": block["name"],
                        "arguments": json.dumps(block.get("input", {})),
                    },
                })

        stop_reason = raw_response.get("stop_reason", "end_turn")
        finish_reason = _STOP_REASON_MAP.get(stop_reason, "stop")

        usage_raw = raw_response.get("usage", {})
        # Anthropic prompt-cache fields:
        #   usage.cache_creation_input_tokens — tokens written to the cache
        #     this turn (priced at base input rate)
        #   usage.cache_read_input_tokens — tokens served from the cache
        #     this turn (priced at 10% of base input rate)
        # See https://docs.anthropic.com/en/docs/build-with-claude/prompt-caching
        cache_read = int(usage_raw.get("cache_read_input_tokens", 0) or 0)
        cache_creation = int(usage_raw.get("cache_creation_input_tokens", 0) or 0)
        # Anthropic's input_tokens does NOT include cached_read tokens
        # (that's why they're a separate field). Add them back so
        # downstream cost-calculation sees the true total input.
        base_input = int(usage_raw.get("input_tokens", 0) or 0)
        total_input = base_input + cache_read + cache_creation
        usage = {
            "prompt_tokens": total_input,
            "completion_tokens": usage_raw.get("output_tokens", 0),
            "total_tokens": (
                total_input + int(usage_raw.get("output_tokens", 0) or 0)
            ),
            # CoreIQ-specific extension surfaced through the usage dict so
            # downstream consumers (writer.py, cost calc, OTel attributes)
            # can read the cached count without having to know
            # provider-specific field names.
            "cached_input_tokens": cache_read,
        }

        return ProviderResponse(
            id=raw_response.get("id", f"msg_{uuid.uuid4().hex[:12]}"),
            model=raw_response.get("model", ""),
            content="\n".join(text_parts) if text_parts else "",
            finish_reason=finish_reason,
            usage=usage,
            tool_calls=tool_calls if tool_calls else None,
            raw=raw_response,
        )

    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse a single Anthropic SSE event payload.

        Anthropic streams typed events rather than a uniform delta structure.
        Each ``data:`` line is a JSON object with a ``type`` field:

        - ``message_start`` — contains the message skeleton and usage.
        - ``content_block_start`` — signals a new text or tool_use block.
        - ``content_block_delta`` — incremental text or tool input JSON.
        - ``message_delta`` — final stop_reason and output token count.
        - ``message_stop`` — logical end of stream.
        - ``ping`` — keep-alive, ignored.
        """
        data = json.loads(raw_chunk)
        event_type = data.get("type", "")

        if event_type == "message_start":
            message = data.get("message", {})
            usage_raw = message.get("usage", {})
            return GenericStreamingChunk(
                usage={
                    "prompt_tokens": usage_raw.get("input_tokens", 0),
                    "completion_tokens": usage_raw.get("output_tokens", 0),
                },
                provider_specific={"event": "message_start", "model": message.get("model", "")},
            )

        if event_type == "content_block_start":
            block = data.get("content_block", {})
            if block.get("type") == "tool_use":
                tool_call = {
                    "index": data.get("index", 0),
                    "id": block.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                    "type": "function",
                    "function": {
                        "name": block.get("name", ""),
                        "arguments": "",
                    },
                }
                return GenericStreamingChunk(tool_calls=[tool_call])
            # Text block start — usually empty, nothing to emit.
            return GenericStreamingChunk()

        if event_type == "content_block_delta":
            delta = data.get("delta", {})
            delta_type = delta.get("type", "")

            if delta_type == "text_delta":
                return GenericStreamingChunk(text=delta.get("text", ""))

            if delta_type == "input_json_delta":
                # Incremental JSON for a tool_use block.
                partial_json = delta.get("partial_json", "")
                tool_call = {
                    "index": data.get("index", 0),
                    "function": {"arguments": partial_json},
                }
                return GenericStreamingChunk(tool_calls=[tool_call])

            return GenericStreamingChunk()

        if event_type == "message_delta":
            delta = data.get("delta", {})
            stop_reason = delta.get("stop_reason")
            finish_reason = _STOP_REASON_MAP.get(stop_reason, "stop") if stop_reason else None
            usage_raw = data.get("usage", {})
            usage = None
            if usage_raw:
                usage = {
                    "completion_tokens": usage_raw.get("output_tokens", 0),
                }
            return GenericStreamingChunk(
                finish_reason=finish_reason,
                usage=usage,
                is_finished=finish_reason is not None,
            )

        if event_type == "message_stop":
            return GenericStreamingChunk(is_finished=True, finish_reason="stop")

        # ping or unknown event — return empty chunk.
        return GenericStreamingChunk()


# ---------------------------------------------------------------------------
# Internal translation helpers
# ---------------------------------------------------------------------------


def _extract_system_messages(messages: list[dict]) -> tuple[str, list[dict]]:
    """Separate system messages from the conversation.

    Returns a tuple of ``(system_text, remaining_messages)`` where
    ``system_text`` is the concatenation of all system-role messages and
    ``remaining_messages`` has those entries removed.
    """
    system_parts: list[str] = []
    filtered: list[dict] = []

    for msg in messages:
        if msg.get("role") == "system":
            content = msg.get("content", "")
            if isinstance(content, list):
                # Handle content-block arrays — extract text parts.
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        system_parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        system_parts.append(block)
            else:
                system_parts.append(str(content))
        else:
            filtered.append(msg)

    return "\n\n".join(system_parts), filtered


def _merge_consecutive_user_messages(messages: list[dict]) -> list[dict]:
    """Merge consecutive user messages into a single message.

    The Anthropic API rejects conversations with consecutive messages of
    the same role.  When multiple user messages appear in a row (common
    when a system message is extracted between them) they are combined.
    """
    if not messages:
        return messages

    merged: list[dict] = [messages[0]]
    for msg in messages[1:]:
        if msg.get("role") == merged[-1].get("role") == "user":
            prev_content = merged[-1].get("content", "")
            curr_content = msg.get("content", "")
            # Merge as strings when both are strings, otherwise use blocks.
            if isinstance(prev_content, str) and isinstance(curr_content, str):
                merged[-1] = {"role": "user", "content": f"{prev_content}\n\n{curr_content}"}
            else:
                merged[-1] = {
                    "role": "user",
                    "content": _to_content_blocks(prev_content) + _to_content_blocks(curr_content),
                }
        else:
            merged.append(msg)

    return merged


def _to_content_blocks(content: str | list) -> list[dict]:
    """Ensure content is a list of Anthropic content blocks.

    Converts OpenAI ``image_url`` blocks to Anthropic ``image`` blocks so
    vision models receive images instead of silently dropping them.
    """
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    if isinstance(content, list):
        out: list[dict] = []
        for block in content:
            if not isinstance(block, dict):
                out.append({"type": "text", "text": str(block)})
                continue
            if block.get("type") == "image_url":
                url = block.get("image_url", {}).get("url", "")
                if url.startswith("data:"):
                    # data:image/png;base64,<data> → Anthropic base64 block
                    try:
                        header, b64data = url.split(",", 1)
                        media_type = header.split(";")[0].split(":")[1]
                        out.append({
                            "type": "image",
                            "source": {"type": "base64", "media_type": media_type, "data": b64data},
                        })
                    except (ValueError, IndexError):
                        out.append({"type": "text", "text": f"[Image: {url[:80]}]"})
                else:
                    # URL-based image → Anthropic url source
                    out.append({
                        "type": "image",
                        "source": {"type": "url", "url": url},
                    })
                continue
            out.append(block)
        return out
    return [{"type": "text", "text": str(content)}]


def _normalise_message_content(messages: list[dict]) -> list[dict]:
    """Ensure every message has content in the format Anthropic expects.

    - Tool-result messages (role=tool) are converted to Anthropic's
      ``tool_result`` content blocks with role ``user``.
    - Assistant messages with ``tool_calls`` are converted to
      ``tool_use`` content blocks.
    """
    normalised: list[dict] = []
    for msg in messages:
        role = msg.get("role", "")

        if role == "tool":
            # OpenAI tool result -> Anthropic tool_result block.
            normalised.append({
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": msg.get("tool_call_id", ""),
                        "content": str(msg.get("content", "")),
                    }
                ],
            })
        elif role == "assistant" and msg.get("tool_calls"):
            # Convert OpenAI-style tool_calls to Anthropic tool_use blocks.
            content_blocks: list[dict] = []
            text_content = msg.get("content")
            if text_content:
                content_blocks.append({"type": "text", "text": text_content})
            for tc in msg["tool_calls"]:
                func = tc.get("function", {})
                arguments = func.get("arguments", "{}")
                if isinstance(arguments, str):
                    try:
                        arguments = json.loads(arguments)
                    except (json.JSONDecodeError, TypeError):
                        arguments = {}
                content_blocks.append({
                    "type": "tool_use",
                    "id": tc.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                    "name": func.get("name", ""),
                    "input": arguments,
                })
            normalised.append({"role": "assistant", "content": content_blocks})
        else:
            normalised.append(msg)

    return normalised


def _translate_tools(tools: list[dict]) -> list[dict]:
    """Convert OpenAI tool definitions to Anthropic format.

    OpenAI format::

        {"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}

    Anthropic format::

        {"name": ..., "description": ..., "input_schema": ...}
    """
    translated: list[dict] = []
    for tool in tools:
        if tool.get("type") == "function":
            func = tool.get("function", {})
            translated.append({
                "name": func.get("name", ""),
                "description": func.get("description", ""),
                "input_schema": func.get("parameters", {"type": "object", "properties": {}}),
            })
        else:
            # Pass through non-function tools (future-proofing).
            translated.append(tool)
    return translated


def _translate_tool_choice(tool_choice: str | dict) -> dict:
    """Convert OpenAI ``tool_choice`` to Anthropic format.

    OpenAI values:
        - ``"auto"``        -> ``{"type": "auto"}``
        - ``"required"``    -> ``{"type": "any"}``
        - ``"none"``        -> ``{"type": "auto"}`` (Anthropic has no "none")
        - ``{"type": "function", "function": {"name": "X"}}``
                            -> ``{"type": "tool", "name": "X"}``
    """
    if isinstance(tool_choice, str):
        mapping = {
            "auto": {"type": "auto"},
            "required": {"type": "any"},
            "none": {"type": "auto"},
        }
        return mapping.get(tool_choice, {"type": "auto"})

    if isinstance(tool_choice, dict):
        func = tool_choice.get("function", {})
        name = func.get("name", "")
        if name:
            return {"type": "tool", "name": name}
        return {"type": "auto"}

    return {"type": "auto"}
