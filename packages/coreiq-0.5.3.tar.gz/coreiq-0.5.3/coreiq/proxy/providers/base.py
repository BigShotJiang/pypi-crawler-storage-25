"""Base provider abstraction for the CoreIQ proxy.

Every LLM provider (OpenAI, Anthropic, Google, etc.) implements the
ProviderConfig interface.  The proxy normalises all requests into
ProviderRequest, dispatches them through the provider's transform layer,
and normalises responses back into ProviderResponse.

Streaming uses the GenericStreamingChunk intermediate type so the
streaming handler can convert any provider's output into OpenAI-compatible
SSE without knowing provider details.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Optional

import httpx

logger = logging.getLogger("coreiq.proxy")


# ---------------------------------------------------------------------------
# Shared httpx.AsyncClient pool
# ---------------------------------------------------------------------------
#
# Constructing a fresh httpx.AsyncClient per request forces a brand-new TCP
# + TLS handshake every time, which adds ~50-200ms of cold-path overhead and
# defeats HTTP/2 connection reuse. We keep one client per provider_name,
# created lazily, and reuse it across the process lifetime. close_all() is
# wired into the FastAPI shutdown hook in server/app.py.

_POOL_LOCK = asyncio.Lock()
_POOL: dict[str, httpx.AsyncClient] = {}


def _pool_limits() -> httpx.Limits:
    """Return the connection-pool limits derived from env (with sane defaults)."""
    return httpx.Limits(
        max_connections=int(os.environ.get("COREIQ_HTTPX_MAX_CONNECTIONS", "100")),
        max_keepalive_connections=int(
            os.environ.get("COREIQ_HTTPX_MAX_KEEPALIVE", "20")
        ),
        keepalive_expiry=float(os.environ.get("COREIQ_HTTPX_KEEPALIVE_EXPIRY", "30")),
    )


async def get_http_client(provider_name: str) -> httpx.AsyncClient:
    """Return the shared AsyncClient for *provider_name*, creating it on first use."""
    client = _POOL.get(provider_name)
    if client is not None and not client.is_closed:
        return client
    async with _POOL_LOCK:
        client = _POOL.get(provider_name)
        if client is not None and not client.is_closed:
            return client
        client = httpx.AsyncClient(
            limits=_pool_limits(),
            http2=os.environ.get("COREIQ_HTTPX_HTTP2", "0") in ("1", "true", "yes"),
            timeout=httpx.Timeout(connect=10.0, read=120.0, write=10.0, pool=10.0),
        )
        _POOL[provider_name] = client
        return client


async def close_http_pool() -> None:
    """Close every pooled client. Safe to call multiple times."""
    async with _POOL_LOCK:
        for client in list(_POOL.values()):
            try:
                await client.aclose()
            except Exception as exc:  # noqa: BLE001 - best-effort shutdown
                logger.warning("error closing httpx client: %s", exc)
        _POOL.clear()

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ProviderError(Exception):
    """Base exception for provider-related errors."""

    def __init__(
        self,
        message: str,
        *,
        provider: str = "",
        status_code: int | None = None,
        raw_response: dict | None = None,
    ) -> None:
        self.provider = provider
        self.status_code = status_code
        self.raw_response = raw_response or {}
        super().__init__(message)


class ProviderTimeoutError(ProviderError):
    """The provider did not respond within the configured timeout."""


class ProviderAuthError(ProviderError):
    """Authentication or authorisation failure against the provider."""


class ProviderRateLimitError(ProviderError):
    """The provider returned a rate-limit (HTTP 429) response."""


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class GenericStreamingChunk:
    """Universal intermediate type for streaming across all providers.

    Every provider's stream parser produces these, and the streaming
    handler converts them to OpenAI-compatible SSE format.  Two-stage
    normalisation isolates provider quirks from the transport layer.
    """

    text: str = ""
    finish_reason: Optional[str] = None
    usage: Optional[dict] = None  # {prompt_tokens, completion_tokens}
    tool_calls: Optional[list[dict]] = None
    is_finished: bool = False
    # Provider-specific metadata that callers may inspect.
    provider_specific: dict = field(default_factory=dict)


@dataclass(slots=True)
class ProviderRequest:
    """Normalised request to send to any provider.

    Follows the OpenAI chat-completion parameter convention so that the
    majority of fields map 1-to-1 for OpenAI-compatible providers.
    Non-OpenAI providers transform this into their native format inside
    ``ProviderConfig.transform_request()``.
    """

    model: str
    messages: list[dict]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stream: bool = False
    tools: Optional[list[dict]] = None
    tool_choice: Optional[str | dict] = None
    response_format: Optional[dict] = None
    stop: Optional[str | list[str]] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    seed: Optional[int] = None
    user: Optional[str] = None
    n: Optional[int] = None
    logprobs: Optional[bool] = None
    top_logprobs: Optional[int] = None
    # Internal metadata — not forwarded to the provider.
    trace_id: Optional[str] = None
    timeout_s: float = 120.0
    extra: dict = field(default_factory=dict)

    def to_dict(self, *, include_none: bool = False) -> dict:
        """Serialise to a dict suitable for an OpenAI-compatible body.

        By default keys whose value is ``None`` are omitted so providers
        that reject unknown parameters are not tripped up.
        """
        _FIELDS = (
            "model", "messages", "temperature", "max_tokens", "top_p",
            "stream", "tools", "tool_choice", "response_format", "stop",
            "frequency_penalty", "presence_penalty", "seed", "user",
            "n", "logprobs", "top_logprobs",
        )
        out: dict[str, Any] = {}
        for key in _FIELDS:
            val = getattr(self, key)
            if val is not None or include_none:
                out[key] = val
        out.update(self.extra)
        return out


@dataclass(slots=True)
class ProviderResponse:
    """Normalised response from any provider.

    ``raw`` preserves the original provider payload for debugging and
    logging, while the rest of the fields provide a uniform interface.
    """

    id: str
    model: str
    content: str
    finish_reason: str
    usage: dict  # {prompt_tokens, completion_tokens, total_tokens}
    tool_calls: Optional[list[dict]] = None
    raw: dict = field(default_factory=dict)
    latency_ms: int = 0

    @property
    def prompt_tokens(self) -> int:
        return self.usage.get("prompt_tokens", 0)

    @property
    def completion_tokens(self) -> int:
        return self.usage.get("completion_tokens", 0)

    @property
    def total_tokens(self) -> int:
        return self.usage.get("total_tokens", self.prompt_tokens + self.completion_tokens)


# ---------------------------------------------------------------------------
# Abstract base class
# ---------------------------------------------------------------------------


class ProviderConfig(ABC):
    """Abstract base class for all LLM providers.

    Subclasses implement the *transform* methods to convert between the
    normalised CoreIQ types and the provider's native wire format.  The
    concrete ``complete()`` and ``stream()`` methods handle HTTP dispatch,
    error mapping, and logging so that individual providers only need to
    worry about serialisation.
    """

    # Subclasses MUST set this to a unique lowercase identifier
    # (e.g. "openai", "anthropic", "google").
    provider_name: str = ""

    # Default connect / read / write timeouts for httpx (seconds).
    _default_timeout: float = 120.0

    # Maximum automatic retries on transient failures (5xx, 429).
    _max_retries: int = 2

    # Seconds between retries (simple linear back-off multiplier).
    _retry_backoff: float = 1.0

    # ------------------------------------------------------------------
    # Abstract interface — every provider MUST implement these
    # ------------------------------------------------------------------

    @abstractmethod
    def get_supported_params(self, model: str) -> list[str]:
        """Return the list of request parameter names this provider supports.

        Used by the proxy to strip unsupported fields before forwarding a
        request, avoiding 400 errors from providers that reject unknown
        parameters (e.g. Anthropic rejects ``logprobs``).
        """

    @abstractmethod
    def transform_request(self, request: ProviderRequest) -> tuple[str, dict, dict]:
        """Convert a normalised request into provider-native HTTP components.

        Returns:
            A 3-tuple of ``(url, headers, body)`` where *url* is the full
            endpoint URL, *headers* is a dict of HTTP headers, and *body*
            is a JSON-serialisable dict.
        """

    @abstractmethod
    def transform_response(self, raw_response: dict) -> ProviderResponse:
        """Convert a provider-native JSON response to a ProviderResponse."""

    @abstractmethod
    def transform_streaming_chunk(self, raw_chunk: str) -> GenericStreamingChunk:
        """Parse a single SSE ``data:`` line from the provider's stream.

        The input is the raw string payload after stripping the ``data: ``
        prefix (but before JSON decoding — the implementation should
        handle its own parsing).

        Return a ``GenericStreamingChunk`` with ``is_finished=True`` when
        the stream is logically complete (e.g. ``data: [DONE]`` for
        OpenAI-compatible providers).
        """

    @abstractmethod
    def validate_environment(self) -> bool:
        """Check that required environment variables and API keys exist.

        Returns ``True`` if the provider is ready to accept requests,
        ``False`` otherwise.  Implementations should log a warning for
        every missing variable.
        """

    @abstractmethod
    def get_api_base(self) -> str:
        """Return the base URL for this provider (no trailing slash)."""

    # ------------------------------------------------------------------
    # Shared concrete methods
    # ------------------------------------------------------------------

    def filter_params(self, request: ProviderRequest, model: str) -> ProviderRequest:
        """Return a copy of *request* with unsupported params set to None.

        This prevents 400 errors when forwarding to providers that reject
        unknown fields.
        """
        supported = set(self.get_supported_params(model))
        # Always keep core fields.
        always_keep = {"model", "messages", "stream"}
        _OPTIONAL_FIELDS = (
            "temperature", "max_tokens", "top_p", "tools", "tool_choice",
            "response_format", "stop", "frequency_penalty", "presence_penalty",
            "seed", "user", "n", "logprobs", "top_logprobs",
        )
        filtered_extra: dict[str, Any] = {}
        for key in _OPTIONAL_FIELDS:
            if key not in supported and key not in always_keep:
                # Zero out unsupported params so to_dict() omits them.
                object.__setattr__(request, key, None)
        for k, v in request.extra.items():
            if k in supported:
                filtered_extra[k] = v
        request.extra = filtered_extra
        return request

    async def complete(self, request: ProviderRequest) -> ProviderResponse:
        """Send a non-streaming completion request and return a normalised response.

        Handles timeout mapping, HTTP error classification, and automatic
        retries on transient failures.
        """
        request = self.filter_params(request, request.model)
        url, headers, body = self.transform_request(request)
        # Inject W3C traceparent / tracestate so the provider call is part of
        # the same distributed trace as the inbound request. No-op when OTel
        # isn't configured.
        try:
            from coreiq.observability.otel_propagator import inject as _inject_trace
            _inject_trace(headers)
        except Exception:
            pass
        body["stream"] = False

        timeout = httpx.Timeout(
            connect=10.0,
            read=request.timeout_s,
            write=10.0,
            pool=10.0,
        )

        last_exc: Exception | None = None
        for attempt in range(1 + self._max_retries):
            if attempt > 0:
                import asyncio
                wait = self._retry_backoff * attempt
                logger.info(
                    "Retrying %s request (attempt %d/%d) after %.1fs",
                    self.provider_name, attempt + 1, 1 + self._max_retries, wait,
                )
                await asyncio.sleep(wait)

            start = time.monotonic()
            try:
                client = await get_http_client(self.provider_name)
                resp = await client.post(url, headers=headers, json=body, timeout=timeout)

                latency_ms = int((time.monotonic() - start) * 1000)

                if resp.status_code == 401 or resp.status_code == 403:
                    raise ProviderAuthError(
                        f"{self.provider_name} auth failure: {resp.text[:300]}",
                        provider=self.provider_name,
                        status_code=resp.status_code,
                        raw_response=_safe_json(resp),
                    )

                if resp.status_code == 429:
                    last_exc = ProviderRateLimitError(
                        f"{self.provider_name} rate limited",
                        provider=self.provider_name,
                        status_code=429,
                        raw_response=_safe_json(resp),
                    )
                    continue  # retry

                if resp.status_code >= 500:
                    last_exc = ProviderError(
                        f"{self.provider_name} server error ({resp.status_code}): {resp.text[:300]}",
                        provider=self.provider_name,
                        status_code=resp.status_code,
                        raw_response=_safe_json(resp),
                    )
                    continue  # retry

                if resp.status_code >= 400:
                    raise ProviderError(
                        f"{self.provider_name} error ({resp.status_code}): {resp.text[:500]}",
                        provider=self.provider_name,
                        status_code=resp.status_code,
                        raw_response=_safe_json(resp),
                    )

                raw_data = resp.json()
                result = self.transform_response(raw_data)
                result.latency_ms = latency_ms
                return result

            except httpx.TimeoutException:
                latency_ms = int((time.monotonic() - start) * 1000)
                last_exc = ProviderTimeoutError(
                    f"{self.provider_name} request timed out after {latency_ms}ms",
                    provider=self.provider_name,
                )
                continue  # retry

            except (ProviderAuthError, ProviderError) as exc:
                # Auth errors and 4xx client errors are not retryable.
                if not isinstance(exc, (ProviderRateLimitError,)) and (
                    getattr(exc, "status_code", None) is not None
                    and getattr(exc, "status_code", 500) < 500
                    and getattr(exc, "status_code", 200) != 429
                ):
                    raise
                last_exc = exc
                continue

            except httpx.ConnectError as exc:
                last_exc = ProviderError(
                    f"{self.provider_name} connection failed: {exc}",
                    provider=self.provider_name,
                )
                continue

        # All retries exhausted.
        assert last_exc is not None
        raise last_exc

    async def stream(self, request: ProviderRequest) -> AsyncIterator[GenericStreamingChunk]:
        """Send a streaming request and yield normalised chunks.

        Connects with httpx and iterates over Server-Sent Events (SSE)
        lines.  Each ``data:`` payload is passed to the provider's
        ``transform_streaming_chunk()`` for normalisation.
        """
        request = self.filter_params(request, request.model)
        url, headers, body = self.transform_request(request)
        try:
            from coreiq.observability.otel_propagator import inject as _inject_trace
            _inject_trace(headers)
        except Exception:
            pass
        body["stream"] = True

        timeout = httpx.Timeout(
            connect=10.0,
            read=request.timeout_s,
            write=10.0,
            pool=10.0,
        )

        start = time.monotonic()
        try:
            client = await get_http_client(self.provider_name)
            async with client.stream("POST", url, headers=headers, json=body, timeout=timeout) as resp:
                if resp.status_code == 401 or resp.status_code == 403:
                    await resp.aread()
                    raise ProviderAuthError(
                        f"{self.provider_name} auth failure: {resp.text[:300]}",
                        provider=self.provider_name,
                        status_code=resp.status_code,
                    )

                if resp.status_code == 429:
                    await resp.aread()
                    raise ProviderRateLimitError(
                        f"{self.provider_name} rate limited",
                        provider=self.provider_name,
                        status_code=429,
                    )

                if resp.status_code >= 400:
                    await resp.aread()
                    raise ProviderError(
                        f"{self.provider_name} error ({resp.status_code}): {resp.text[:500]}",
                        provider=self.provider_name,
                        status_code=resp.status_code,
                    )

                buffer = ""
                async for raw_bytes in resp.aiter_bytes():
                    buffer += raw_bytes.decode("utf-8", errors="replace")
                    # SSE frames are separated by double newlines.
                    while "\n\n" in buffer:
                        frame, buffer = buffer.split("\n\n", 1)
                        for line in frame.split("\n"):
                            line = line.strip()
                            if not line or line.startswith(":"):
                                # Comment or keep-alive — skip.
                                continue
                            if line.startswith("data: "):
                                data_payload = line[6:]
                                if data_payload.strip() == "[DONE]":
                                    yield GenericStreamingChunk(
                                        is_finished=True,
                                        finish_reason="stop",
                                    )
                                    return
                                try:
                                    chunk = self.transform_streaming_chunk(data_payload)
                                    yield chunk
                                    if chunk.is_finished:
                                        return
                                except Exception:
                                    logger.debug(
                                        "Failed to parse streaming chunk from %s: %s",
                                        self.provider_name,
                                        data_payload[:200],
                                        exc_info=True,
                                    )

                # Process any remaining data in the buffer.
                if buffer.strip():
                    for line in buffer.strip().split("\n"):
                        line = line.strip()
                        if line.startswith("data: "):
                            data_payload = line[6:]
                            if data_payload.strip() == "[DONE]":
                                yield GenericStreamingChunk(
                                    is_finished=True,
                                    finish_reason="stop",
                                )
                                return
                            try:
                                chunk = self.transform_streaming_chunk(data_payload)
                                yield chunk
                            except Exception:
                                logger.debug(
                                    "Failed to parse trailing chunk from %s: %s",
                                    self.provider_name,
                                    data_payload[:200],
                                    exc_info=True,
                                )

        except httpx.TimeoutException:
            latency_ms = int((time.monotonic() - start) * 1000)
            raise ProviderTimeoutError(
                f"{self.provider_name} stream timed out after {latency_ms}ms",
                provider=self.provider_name,
            )
        except httpx.ConnectError as exc:
            raise ProviderError(
                f"{self.provider_name} connection failed: {exc}",
                provider=self.provider_name,
            )

    def __repr__(self) -> str:
        return f"<{type(self).__name__} provider={self.provider_name!r}>"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_json(resp: httpx.Response) -> dict:
    """Try to decode a response body as JSON, falling back to an empty dict."""
    try:
        return resp.json()
    except Exception:
        return {"raw_text": resp.text[:1000]}
