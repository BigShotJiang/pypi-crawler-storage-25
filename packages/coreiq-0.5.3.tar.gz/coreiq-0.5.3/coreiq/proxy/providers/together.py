"""Together AI provider for the CoreIQ proxy.

Together AI exposes an OpenAI-compatible API for open-source model
inference.  This provider extends :class:`OpenAICompatProvider` with
Together-specific defaults and parameter support.
"""

from __future__ import annotations

import logging
import os

from .openai_compat import OpenAICompatProvider

logger = logging.getLogger("coreiq.proxy.together")

# Together supports most OpenAI chat-completion parameters.
_TOGETHER_PARAMS = [
    "model",
    "messages",
    "temperature",
    "max_tokens",
    "top_p",
    "stream",
    "tools",
    "tool_choice",
    "response_format",
    "stop",
    "frequency_penalty",
    "presence_penalty",
    "seed",
    "n",
    "logprobs",
    "top_logprobs",
    "stream_options",
]


class TogetherProvider(OpenAICompatProvider):
    """Together AI inference provider (OpenAI-compatible).

    Parameters
    ----------
    api_key:
        Together API key.  Falls back to ``TOGETHER_API_KEY``.
    api_base:
        Base URL override (default ``https://api.together.xyz/v1``).
    """

    provider_name = "together"

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("TOGETHER_API_KEY", "")
        resolved_base = (api_base or os.environ.get("TOGETHER_API_BASE", "")).rstrip("/")
        super().__init__(
            base_url=resolved_base or "https://api.together.xyz/v1",
            api_key=resolved_key,
            supported_params=list(_TOGETHER_PARAMS),
            provider_label="together",
        )

    def validate_environment(self) -> bool:
        """Check that an API key is available."""
        if not self.api_key:
            logger.warning("TOGETHER_API_KEY is not set — Together provider will not work")
            return False
        return True
