"""7-stage request pipeline for the CoreIQ proxy gateway.

Every LLM request flows through:
    1. Auth — validate API key
    2. Security pre-scan — injection detection, PII redaction
    3. Function resolution — (pass-through in Phase 1)
    4. Cache check — semantic cache lookup
    5. Route & dispatch — provider resolution + HTTP call
    6. Security post-scan — output guardrails
    7. Observe — trace recording, cost calculation, audit log
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Optional

from .cost import CostCalculator, CostResult
from .providers.base import (
    ProviderConfig,
    ProviderError,
    ProviderAuthError,
    ProviderRateLimitError,
    ProviderRequest,
    ProviderResponse,
    ProviderTimeoutError,
)
from .keys import BudgetExceededError
from .providers.registry import ProviderRegistry
from .routing.router import Deployment, DeploymentRouter
from .routing.strategies import NoAvailableDeploymentError
from .streaming import StreamingResponseAccumulator

logger = logging.getLogger("coreiq.proxy.pipeline")


# ---------------------------------------------------------------------------
# Pipeline context — mutable state carried through all 7 stages
# ---------------------------------------------------------------------------


@dataclass
class PipelineContext:
    """Mutable context passed through all pipeline stages."""

    request_id: str = field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex[:24]}")
    tenant_id: str = ""
    model: str = ""
    provider_name: str = ""
    messages: list[dict] = field(default_factory=list)
    original_messages: list[dict] = field(default_factory=list)
    stream: bool = False

    # Stage 1: Auth — resolved virtual key (if applicable)
    virtual_key_id: str = ""
    # IdP groups from virtual key metadata — used for runtime guardrail evaluation
    idp_groups: list[str] = field(default_factory=list)

    # Stage 1.5: Sovereign Policy Engine — set when COREIQ_POLICY_ENGINE=v2
    policy_decision: Optional[Any] = None
    policy_decision_id: Optional[str] = None

    # Stage 2: Security scan results
    scan_clean: bool = True
    scan_issues: list[str] = field(default_factory=list)
    pii_redacted: bool = False

    # Stage 3: Function resolution
    function_id: Optional[str] = None
    variant_id: Optional[str] = None
    stored_input_json: Optional[str] = None
    episode_id: Optional[str] = None
    _episode_context: Optional[Any] = None

    # Stage 4: Cache
    cache_hit: bool = False
    cached_response: Optional[Any] = None

    # Stage 5: Provider response
    provider_response: Optional[ProviderResponse] = None

    # Stage 6: Post-scan
    post_scan_clean: bool = True
    post_scan_issues: list[str] = field(default_factory=list)

    # Stage 7: Observability
    cost: Optional[CostResult] = None
    start_time: float = field(default_factory=time.monotonic)
    latency_ms: int = 0
    ttft_ms: int = 0  # time to first token (streaming only; 0 = not measured)

    # Composite variant flag — when True, Stage 3 handled dispatch internally
    # (e.g. best-of-N or mixture-of-N) and Stage 5 should be skipped.
    _skip_dispatch: bool = False

    # Extra parameters forwarded to the provider.
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    tools: Optional[list[dict]] = None
    tool_choice: Optional[Any] = None
    response_format: Optional[dict] = None
    stop: Optional[Any] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    seed: Optional[int] = None
    user: Optional[str] = None
    n: Optional[int] = None
    logprobs: Optional[bool] = None
    top_logprobs: Optional[int] = None


# ---------------------------------------------------------------------------
# Pipeline errors — map to HTTP status codes in the gateway
# ---------------------------------------------------------------------------


class PipelineAuthError(Exception):
    """401 Unauthorized."""


class PipelineSecurityError(Exception):
    """400 Bad Request — security scan failed."""


class PipelineBudgetError(Exception):
    """429 Too Many Requests — budget exceeded."""


class PipelineProviderError(Exception):
    """502 Bad Gateway — provider error."""

    def __init__(self, message: str, *, status_code: int = 502):
        self.status_code = status_code
        super().__init__(message)


class PipelinePolicyError(Exception):
    """403 Forbidden — Sovereign Policy Engine denied the request."""

    def __init__(self, message: str, *, decision: Any = None):
        self.decision = decision
        super().__init__(message)


# ---------------------------------------------------------------------------
# Request pipeline
# ---------------------------------------------------------------------------


class RequestPipeline:
    """Orchestrates the 7-stage request pipeline.

    Args:
        registry: Provider registry for resolving model strings.
        api_key: Expected API key (None = no auth required).
        cache: Optional semantic cache instance.
        cost_calculator: Optional cost calculator (created if not provided).
    """

    def __init__(
        self,
        *,
        registry: ProviderRegistry,
        api_key: Optional[str] = None,
        cache: Optional[Any] = None,
        cost_calculator: Optional[CostCalculator] = None,
        key_manager: Optional[Any] = None,
        deployment_router: Optional[DeploymentRouter] = None,
        function_registry: Optional[Any] = None,
        variant_manager: Optional[Any] = None,
        experiment_manager: Optional[Any] = None,
        template_engine: Optional[Any] = None,
        dicl_store: Optional[Any] = None,
        rate_limiter: Optional[Any] = None,
        episode_manager: Optional[Any] = None,
    ) -> None:
        self._registry = registry
        self._api_key = api_key
        self._cache = cache
        self._cost = cost_calculator or CostCalculator()
        self._key_manager = key_manager
        self._deployment_router = deployment_router
        self._audit = None  # lazy init

        # Optimization singletons — lazy-initialized on first use if not provided.
        self._function_registry = function_registry
        self._variant_manager = variant_manager
        self._experiment_manager = experiment_manager
        self._template_engine = template_engine
        self._dicl_store = dicl_store

        # Episode manager for multi-turn orchestration.
        self._episode_manager = episode_manager

        # Rate limiter for virtual key TPM/RPM enforcement.
        self._rate_limiter = rate_limiter

        # Background observe stage: fire-and-forget tasks so the user-facing
        # response returns before trace/cost/audit writes finish. Bounded set
        # — when full we await inline (back-pressure) so we never silently
        # drop traces.
        self._observe_inflight: set[asyncio.Task[Any]] = set()
        try:
            self._observe_max_inflight = int(
                os.environ.get("COREIQ_OBSERVE_MAX_INFLIGHT", "256")
            )
        except ValueError:
            self._observe_max_inflight = 256
        # Allow operators to force the legacy synchronous path for debugging.
        self._observe_async = os.environ.get(
            "COREIQ_OBSERVE_ASYNC", "1"
        ).strip().lower() in ("1", "true", "yes")

    async def _run_observe(self, ctx: "PipelineContext") -> None:
        """Run _stage_observe off the hot path when capacity allows.

        Fire-and-forget by default (the response can return as soon as the
        provider call resolves). Falls back to inline execution when the
        in-flight set is saturated so observability never silently drops.
        """
        if not self._observe_async:
            await asyncio.to_thread(self._stage_observe, ctx)
            return
        if len(self._observe_inflight) >= self._observe_max_inflight:
            logger.warning(
                "observe queue saturated (%d in flight) — running inline",
                len(self._observe_inflight),
            )
            await asyncio.to_thread(self._stage_observe, ctx)
            return
        task = asyncio.create_task(asyncio.to_thread(self._stage_observe, ctx))
        self._observe_inflight.add(task)
        task.add_done_callback(self._observe_inflight.discard)

    # ------------------------------------------------------------------
    # Top-level entry span (parent of every per-stage span)
    # ------------------------------------------------------------------

    def _open_entry_span(self, ctx: "PipelineContext") -> Any:
        """Start a top-level OTel span and return it (or None if OTel is off).

        We don't use ``start_as_current_span`` because the caller may be
        sync (cache-hit early return) or async (provider dispatch). Instead
        we activate the span via ``use_span`` inside the wrapper helpers,
        so child spans created downstream still parent correctly.
        """
        try:
            from coreiq.observability import otel_exporter
            if not otel_exporter.is_configured() or otel_exporter._otel_tracer is None:
                return None
            from opentelemetry.trace import SpanKind
            span = otel_exporter._otel_tracer.start_span(
                "coreiq.proxy.request",
                kind=SpanKind.SERVER,
                attributes={
                    "coreiq.request.id": ctx.request_id or "",
                    "coreiq.request.model": ctx.model or "",
                    "coreiq.request.stream": bool(ctx.stream),
                },
            )
            return span
        except Exception as exc:  # noqa: BLE001 — observability must never raise
            logger.debug("entry span open failed: %s", exc)
            return None

    def _close_entry_span(
        self,
        span: Any,
        *,
        ctx: Optional["PipelineContext"] = None,
        error: Optional[BaseException] = None,
    ) -> None:
        """Set final attributes + status on the entry span and end it."""
        if span is None:
            return
        try:
            from opentelemetry.trace import StatusCode
            if ctx is not None:
                if ctx.provider_name:
                    span.set_attribute("coreiq.provider", ctx.provider_name)
                if ctx.tenant_id:
                    span.set_attribute("coreiq.tenant_id", ctx.tenant_id)
                if ctx.virtual_key_id:
                    span.set_attribute("coreiq.virtual_key_id", ctx.virtual_key_id)
                if ctx.latency_ms:
                    span.set_attribute("coreiq.latency_ms", int(ctx.latency_ms))
                if ctx.cache_hit:
                    span.set_attribute("coreiq.cache.hit", True)
                if getattr(ctx, "provider_response", None) is not None:
                    pr = ctx.provider_response
                    span.set_attribute("gen_ai.usage.input_tokens", int(pr.prompt_tokens or 0))
                    span.set_attribute("gen_ai.usage.output_tokens", int(pr.completion_tokens or 0))
                    # Emit GenAI metrics — no-op if metrics aren't configured.
                    try:
                        from ..observability import metrics_genai as _mg
                        _mg.record_token_usage(
                            system=getattr(ctx, "provider_name", "unknown"),
                            model=getattr(ctx, "model", "unknown") or "unknown",
                            operation="chat",
                            input_tokens=int(pr.prompt_tokens or 0),
                            output_tokens=int(pr.completion_tokens or 0),
                        )
                        if getattr(ctx, "ttft_ms", None):
                            _mg.record_ttft(
                                system=getattr(ctx, "provider_name", "unknown"),
                                model=getattr(ctx, "model", "unknown") or "unknown",
                                operation="chat",
                                ttft_ms=ctx.ttft_ms,
                            )
                    except Exception:
                        pass  # observability must never break the request path
            if error is not None:
                span.record_exception(error)
                span.set_status(StatusCode.ERROR, str(error))
                span.set_attribute("error.type", type(error).__name__)
            else:
                span.set_status(StatusCode.OK)
        except Exception as exc:  # noqa: BLE001
            logger.debug("entry span finalize failed: %s", exc)
        finally:
            try:
                span.end()
            except Exception:
                pass

    async def _wrap_stream_with_entry_span(
        self,
        gen: AsyncIterator[str],
        span: Any,
        ctx: "PipelineContext",
    ) -> AsyncIterator[str]:
        """Forward SSE chunks and close the entry span when the stream ends."""
        try:
            async for chunk in gen:
                yield chunk
        except Exception as exc:
            self._close_entry_span(span, ctx=ctx, error=exc)
            raise
        else:
            self._close_entry_span(span, ctx=ctx)

    def _get_audit(self):
        if self._audit is None:
            from ..governance.chained_audit import ChainedAuditLogger
            from ..governance.sinks.base import get_sink_router
            self._audit = ChainedAuditLogger(source="proxy", sink_router=get_sink_router())
        return self._audit

    def _get_writer(self):
        from ..store.writer import get_writer
        return get_writer()

    def _get_function_registry(self):
        """Return the shared FunctionRegistry, lazy-initializing if needed."""
        if self._function_registry is None:
            from ..optimization.function import FunctionRegistry
            self._function_registry = FunctionRegistry()
        return self._function_registry

    def _get_variant_manager(self):
        """Return the shared VariantManager, lazy-initializing if needed."""
        if self._variant_manager is None:
            from ..optimization.variant import VariantManager
            self._variant_manager = VariantManager()
        return self._variant_manager

    def _get_experiment_manager(self):
        """Return the shared ExperimentManager, lazy-initializing if needed."""
        if self._experiment_manager is None:
            from ..optimization.experiment import ExperimentManager
            self._experiment_manager = ExperimentManager()
        return self._experiment_manager

    def _get_template_engine(self):
        """Return the shared TemplateEngine, lazy-initializing if needed."""
        if self._template_engine is None:
            from ..optimization.templates import TemplateEngine
            self._template_engine = TemplateEngine()
        return self._template_engine

    def _get_dicl_store(self):
        """Return the shared EmbeddingDICL, lazy-initializing if needed.

        ``db_path`` is a sentinel that enables persistence; the actual
        backend is whatever the store abstraction dispatches to.
        """
        if self._dicl_store is None:
            from ..optimization.dicl import EmbeddingDICL
            self._dicl_store = EmbeddingDICL(db_path="<configured-backend>")
        return self._dicl_store

    def _get_episode_manager(self):
        """Return the shared EpisodeManager, lazy-initializing if needed."""
        if self._episode_manager is None:
            from ..optimization.episode import EpisodeManager
            self._episode_manager = EpisodeManager(
                experiment_manager=self._get_experiment_manager(),
                variant_manager=self._get_variant_manager(),
            )
        return self._episode_manager

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    async def process(
        self,
        *,
        model: str,
        messages: list[dict],
        stream: bool = False,
        api_key: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        tools: Optional[list[dict]] = None,
        tool_choice: Optional[Any] = None,
        response_format: Optional[dict] = None,
        stop: Optional[Any] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        user: Optional[str] = None,
        n: Optional[int] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        episode_id: Optional[str] = None,
    ) -> dict | AsyncIterator[str]:
        """Process a chat completion request through all 7 pipeline stages.

        For non-streaming: returns a dict in OpenAI ChatCompletion format.
        For streaming: returns an async generator yielding SSE strings.

        Raises:
            PipelineAuthError: API key validation failed.
            PipelineSecurityError: Prompt injection or policy violation.
            PipelineBudgetError: Budget or rate limit exceeded.
            PipelineProviderError: Upstream provider error.
        """
        ctx = PipelineContext(
            model=model,
            messages=list(messages),
            original_messages=list(messages),
            stream=stream,
            episode_id=episode_id,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
            tools=tools,
            tool_choice=tool_choice,
            response_format=response_format,
            stop=stop,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            seed=seed,
            user=user,
            n=n,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
        )


        # Open a top-level OTel span that becomes the parent of every
        # downstream span (provider call, observe, policy). The span ends
        # when the coroutine returns; for streaming it ends when the SSE
        # generator is fully consumed (see _wrap_stream_with_entry_span).
        _entry_span = self._open_entry_span(ctx)

        try:
            result = await self._process_inner(
                ctx=ctx,
                stream=stream,
                api_key=api_key,
                tools=tools,
                _entry_span=_entry_span,
            )
        except Exception as exc:
            self._close_entry_span(_entry_span, ctx=ctx, error=exc)
            raise

        # Streaming: hand back a wrapped iterator that closes the span when
        # the SSE stream completes. Non-streaming: close immediately.
        if stream and not isinstance(result, dict):
            return self._wrap_stream_with_entry_span(result, _entry_span, ctx)
        self._close_entry_span(_entry_span, ctx=ctx)
        return result

    async def _process_inner(
        self,
        *,
        ctx: PipelineContext,
        stream: bool,
        api_key: Optional[str],
        tools: Optional[list[dict]],
        _entry_span: Any = None,
    ) -> dict | AsyncIterator[str]:
        # Auto-register tool definitions from the request into the tool catalog.
        if tools:
            try:
                from ..server.routers.tools import _registry as _tool_registry
                _tool_defs = []
                for _t in tools:
                    _fn = _t.get("function", _t) if isinstance(_t, dict) else {}
                    _name = _fn.get("name", "")
                    if _name and not _tool_registry.get(_name):
                        _tool_defs.append({
                            "name": _name,
                            "description": _fn.get("description", ""),
                            "parameters": _fn.get("parameters", {}),
                        })
                if _tool_defs:
                    _tool_registry.register(_tool_defs)
                    logger.debug("Auto-registered %d tool(s) from LLM call", len(_tool_defs))
            except Exception:
                pass

        # --- Stage 1: Auth ---
        self._stage_auth(ctx, api_key)

        # --- Stage 1.5: Sovereign Policy Engine (flag-gated) ---
        self._stage_policy_pre(ctx)

        # --- Stage 2: Security pre-scan ---
        await self._stage_pre_scan(ctx)

        # --- Stage 3: Function resolution (pass-through Phase 1) ---
        await self._stage_function_resolve(ctx)

        # --- Stage 4: Cache check ---
        self._stage_cache_check(ctx)
        if ctx.cache_hit and ctx.cached_response is not None:
            # Record cache hit in observability.
            await self._run_observe(ctx)
            if ctx.stream:
                # Cached response is a non-streaming dict; replay it as SSE.
                return self._cached_response_as_sse(ctx.cached_response)
            # Patch _coreiq fields so the caller sees cache_hit=true and current latency.
            cached = dict(ctx.cached_response)
            if "_coreiq" in cached:
                cached["_coreiq"] = {**cached["_coreiq"], "cache_hit": True, "latency_ms": ctx.latency_ms}
            return cached

        # --- Stage 5: Route & dispatch ---
        # If Stage 3 handled dispatch (composite variants like best-of-N / mixture-of-N),
        # skip provider dispatch and go straight to post-scan + observe.
        if ctx._skip_dispatch and ctx.provider_response is not None:
            # --- Stage 6: Security post-scan ---
            await self._stage_post_scan(ctx)
            # --- Stage 6.5: Policy post-evaluation ---
            self._stage_policy_post(ctx)
            # --- Stage 7: Observe ---
            await self._run_observe(ctx)
            return self._format_response(ctx)

        if self._deployment_router and self._deployment_router.list_deployments():
            # Use the deployment router with fallback chain.
            if stream:
                return await self._routed_stream(ctx)
            else:
                await self._routed_dispatch(ctx)
                # --- Stage 6: Security post-scan ---
                await self._stage_post_scan(ctx)
                # --- Stage 6.5: Policy post-evaluation ---
                self._stage_policy_post(ctx)
                # --- Stage 7: Observe ---
                await self._run_observe(ctx)
                return self._format_response(ctx)
        else:
            # Fallback: direct provider resolution (backward compat).
            provider, bare_model = self._resolve_provider(ctx)
            ctx.provider_name = provider.provider_name

            if stream:
                return await self._stream_with_pipeline(ctx, provider, bare_model)
            else:
                await self._stage_dispatch(ctx, provider, bare_model)
                # --- Stage 6: Security post-scan ---
                await self._stage_post_scan(ctx)
                # --- Stage 6.5: Policy post-evaluation ---
                self._stage_policy_post(ctx)
                # --- Stage 7: Observe ---
                await self._run_observe(ctx)
                return self._format_response(ctx)

    # ------------------------------------------------------------------
    # Stage 1: Auth
    # ------------------------------------------------------------------

    def _stage_auth(self, ctx: PipelineContext, provided_key: Optional[str]) -> None:
        """Validate API key — supports both master key and virtual keys.

        Virtual keys (``sk-coreiq-...``) are validated via the KeyManager.
        When a virtual key is used, additional checks are applied:
        budget limits, model allow-lists, and expiry.

        Raises:
            PipelineAuthError: API key validation failed.
            PipelineBudgetError: Virtual key is over budget.
        """
        if self._api_key is None or self._api_key == "":
            import os
            if os.getenv("COREIQ_AUTH_MODE", "").lower() != "disabled":
                logger.warning(
                    "COREIQ_API_KEY is not set and COREIQ_AUTH_MODE!=disabled — "
                    "all requests are accepted without authentication. "
                    "Set COREIQ_AUTH_MODE=disabled to suppress this warning in dev."
                )
            return  # No auth configured.
        if not provided_key:
            raise PipelineAuthError(
                "Missing API key. Provide via Authorization: Bearer <key> or X-API-Key header."
            )

        # Try master key first (constant-time comparison).
        import hmac as _hmac
        if _hmac.compare_digest(provided_key, self._api_key):
            return  # Master key — full access.

        # Try virtual key if a KeyManager is available.
        if self._key_manager is not None and provided_key.startswith("sk-coreiq-"):
            vk = self._key_manager.validate_key(provided_key)
            if vk is None:
                raise PipelineAuthError(
                    "Invalid, expired, or revoked virtual API key."
                )

            # Budget check — atomic; raises BudgetExceededError if over limit.
            try:
                self._key_manager.check_budget(vk)
            except BudgetExceededError as exc:
                raise PipelineBudgetError(str(exc)) from exc

            # Model allow-list check.
            if not self._key_manager.check_model_allowed(vk, ctx.model):
                raise PipelineAuthError(
                    f"Model {ctx.model!r} is not allowed for this API key."
                )

            # RPM/TPM rate limit check.
            if self._rate_limiter is not None:
                if not self._rate_limiter.check_rate(vk.id, vk.rpm_limit, vk.tpm_limit):
                    raise PipelineBudgetError(
                        f"Rate limit exceeded for virtual key (RPM: {vk.rpm_limit}, TPM: {vk.tpm_limit}). "
                        "Retry-After: 60"
                    )

            ctx.tenant_id = vk.tenant_id
            ctx.virtual_key_id = vk.id

            # Extract IdP groups from key metadata for runtime guardrail evaluation.
            try:
                groups = (vk.metadata or {}).get("groups", [])
                if isinstance(groups, list):
                    ctx.idp_groups = [str(g) for g in groups]
            except Exception:
                pass

            # Runtime group guardrail check (model/provider/token limits).
            # This supplements key-level checks and reflects live policy changes
            # without requiring re-provisioning.
            if ctx.idp_groups:
                try:
                    from ..governance.guardrails import get_guardrail_engine
                    # Estimate input tokens from message content length
                    _input_tok_est = sum(
                        len(m.get("content", "") or "") // 4
                        for m in ctx.messages
                    )
                    get_guardrail_engine().check_request(
                        groups=ctx.idp_groups,
                        tenant_id=ctx.tenant_id or "default",
                        model=ctx.model,
                        provider=ctx.provider_name or "",
                        input_tokens=_input_tok_est,
                    )
                except PipelineAuthError:
                    raise
                except Exception as _grail_exc:
                    from ..governance.guardrails import GuardrailViolation
                    if isinstance(_grail_exc, GuardrailViolation):
                        raise PipelineAuthError(str(_grail_exc)) from _grail_exc
                    logger.debug("Guardrail check error (non-blocking): %s", _grail_exc)

            # Stage 1 additions: Model risk register, data residency, AUP, policy engine, HITL
            try:
                # Model risk check — reject if model is not approved
                from ..governance.model_risk import get_model_risk_register
                _risk_register = get_model_risk_register()
                _risk_entry = _risk_register.get(ctx.model)
                if _risk_entry and not _risk_entry.is_approved():
                    raise PipelineAuthError(
                        f"Model {ctx.model!r} is not approved for use. "
                        f"Risk tier: {_risk_entry.risk_tier.value}. "
                        f"Contact compliance for approval."
                    )

                # HITL check — queue high-risk models for human review
                if _risk_entry and _risk_entry.requires_hitl():
                    try:
                        from ..governance.hitl import get_hitl_workflow
                        _hitl = get_hitl_workflow()
                        # For high-risk models, require human approval
                        # In a real implementation, this would block and wait for approval
                        # For now, we'll just log a warning and allow with tracking
                        logger.warning(
                            "HITL: High-risk model %s requires human review (request %s). "
                            "Auto-approving for now - implement full HITL workflow for production.",
                            ctx.model, ctx.request_id,
                        )
                        # Record HITL requirement in trace metadata for audit
                        # Full implementation would queue the request and block here
                    except Exception as _hitl_exc:
                        logger.debug("HITL check error (non-blocking): %s", _hitl_exc)

                # Data residency check — reject if tenant data must stay in specific region
                try:
                    from ..governance.data_residency import get_auditor
                    _auditor = get_auditor()
                    _auditor.check_write(tenant_id=ctx.tenant_id or "default")
                except Exception as _residency_exc:
                    logger.debug("Data residency check failed: %s", _residency_exc)
                    if "DataResidencyError" in str(type(_residency_exc)):
                        raise PipelineAuthError(
                            f"Request blocked: data residency policy violation. {_residency_exc}"
                        ) from _residency_exc

                # AUP acknowledgment check — block if user hasn't acknowledged active policy
                try:
                    from ..governance.acceptable_use import AUPManager
                    _aup_mgr = AUPManager()
                    _aup_policy = _aup_mgr.get_active(ctx.tenant_id or "default")
                    if _aup_policy:
                        # Check if virtual key user has acknowledged AUP
                        _user_id = (vk.metadata or {}).get("user_id") if vk else None
                        if _user_id:
                            import os
                            _conn = None
                            try:
                                from ..store.db import get_shared_connection
                                _conn = get_shared_connection()
                                _ack_row = _conn.execute(
                                    "SELECT 1 FROM aup_acknowledgments WHERE policy_id=? AND user_id=?",
                                    (_aup_policy.id, _user_id)
                                ).fetchone()
                                if not _ack_row:
                                    raise PipelineAuthError(
                                        f"User has not acknowledged the Acceptable Use Policy (v{_aup_policy.version}). "
                                        f"Please acknowledge before using AI services."
                                    )
                            except PipelineAuthError:
                                raise
                            except Exception as _db_exc:
                                logger.debug("AUP acknowledgment check error: %s", _db_exc)
                except PipelineAuthError:
                    raise
                except Exception as _aup_exc:
                    logger.debug("AUP check error (non-blocking): %s", _aup_exc)

                # Policy engine — deny-list checks (model/provider/token limits)
                try:
                    from ..governance.policy import get_default_policy, PolicyViolation
                    _default_policy = get_default_policy()
                    if _default_policy:
                        _input_tok_est = sum(len(m.get("content", "") or "") // 4 for m in ctx.messages)
                        _default_policy.check_model(ctx.model)
                        _default_policy.check_tokens(_input_tok_est, 0)  # output tokens unknown yet
                        if ctx.provider_name:
                            _default_policy.check_provider(ctx.provider_name)
                except PolicyViolation as _policy_exc:
                    raise PipelineAuthError(
                        f"Request blocked: policy violation. {_policy_exc}"
                    ) from _policy_exc
                except Exception as _policy_exc:
                    logger.debug("Policy check error (non-blocking): %s", _policy_exc)

            except PipelineAuthError:
                raise
            except Exception as _stage1_exc:
                logger.debug("Stage 1 security checks error (non-blocking): %s", _stage1_exc)

            return

        raise PipelineAuthError("Invalid API key.")

    # ------------------------------------------------------------------
    # Stage 1.5: Sovereign Policy Engine (flag-gated)
    # ------------------------------------------------------------------

    def _resolve_target_host(self, ctx: PipelineContext) -> str:
        """Derive the real upstream hostname for sovereignty/egress checks.

        Resolution order:
          1. If a DeploymentRouter is configured, walk its enabled
             deployments matching ``ctx.model`` and ask the
             ProviderConfig for ``get_api_base()``.
          2. Otherwise, ask the ProviderRegistry to resolve ``ctx.model``
             and call ``get_api_base()`` on the returned ProviderConfig.
          3. If both paths fail, fall back to ``ctx.provider_name`` so
             callers still see a value (and tests still see a non-empty
             string), but log at debug.

        The returned string is the hostname (no scheme, no path), which
        is what the egress evaluator's fnmatch comparator expects.
        """
        from urllib.parse import urlparse

        def _hostname(url: str) -> str:
            try:
                parsed = urlparse(url if "://" in url else f"https://{url}")
                return (parsed.hostname or "").lower()
            except Exception:
                return ""

        # 1. DeploymentRouter — pick the first enabled deployment matching the model.
        if self._deployment_router is not None:
            try:
                for dep in self._deployment_router.list_deployments():
                    if not dep.enabled:
                        continue
                    if dep.model and dep.model != ctx.model and not dep.model.endswith(
                        "/" + (ctx.model or "")
                    ):
                        continue
                    base = dep.provider_config.get_api_base()
                    host = _hostname(base)
                    if host:
                        return host
            except Exception as exc:
                logger.debug("target_host: router resolution failed: %s", exc)

        # 2. ProviderRegistry — resolve the model directly.
        try:
            provider, _bare = self._registry.resolve(ctx.model)
            host = _hostname(provider.get_api_base())
            if host:
                return host
        except Exception as exc:
            logger.debug("target_host: registry resolution failed: %s", exc)

        # 3. Fallback — provider name is wrong for fnmatch but at least non-empty.
        return ctx.provider_name or ""

    def _stage_policy_pre(self, ctx: PipelineContext) -> None:
        """Evaluate the active Policy Bundle pre-call.

        No-op unless COREIQ_POLICY_ENGINE=v2 is set. In observe mode,
        denies are downgraded to deny_simulated and the request proceeds —
        the decision is logged either way. In enforce mode, a hard DENY
        raises PipelinePolicyError → 403.
        """
        if os.environ.get("COREIQ_POLICY_ENGINE", "").lower() != "v2":
            return
        try:
            from ..policy import get_policy_engine
            from ..policy.engine import RequestContext as PolicyCtx
            from ..policy.decision import DecisionAction
        except Exception as exc:
            logger.debug("policy engine unavailable (non-fatal): %s", exc)
            return

        engine = get_policy_engine()
        if not engine.has_bundle:
            return  # no bundle loaded → default-allow

        # Build a request context from the pipeline's view of the world.
        #
        # Wave 1A P0 fix: target_host MUST be a real upstream hostname so the
        # egress evaluator's fnmatch against patterns like "api.openai.com"
        # actually fires. The previous implementation passed the provider's
        # short name (e.g. "openai"), which silently bypassed every host-
        # pattern allow/deny rule.
        target_host = self._resolve_target_host(ctx)

        # Best-effort pre-dispatch token estimate (chars/4 — same heuristic
        # used by the runtime guardrails). Lets policy `limits.input` rules
        # fire pre-call without waiting for the provider response, and feeds
        # the replay record so /v1/policy/decisions/replay can reconstruct
        # an identical RequestContext.
        _input_tok_est = sum(
            len(m.get("content", "") or "") // 4
            for m in (ctx.messages or [])
        )
        pctx = PolicyCtx(
            tenant_id=ctx.tenant_id or "default",
            principal=ctx.virtual_key_id,
            groups=list(ctx.idp_groups or []),
            model=ctx.model,
            provider=ctx.provider_name,
            target_host=target_host,
            input_tokens=_input_tok_est or None,
            messages=list(ctx.messages or []),
            metadata={"request_id": ctx.request_id} if ctx.request_id else {},
            trace_id=ctx.request_id,
        )
        decision = engine.evaluate_pre(pctx)
        ctx.policy_decision = decision
        ctx.policy_decision_id = decision.decision_id

        # Persist the decision (fail-soft).
        try:
            from ..policy.decision import get_decision_writer
            get_decision_writer().write(decision)
        except Exception as exc:
            logger.debug("policy decision persist failed (non-fatal): %s", exc)

        # If routing rule chose a deployment, surface it on ctx so Stage 5 can use it.
        if decision.target_deployment:
            try:
                ctx.meta = getattr(ctx, "meta", {}) or {}
            except Exception:
                pass

        if decision.action == DecisionAction.DENY:
            raise PipelinePolicyError(
                f"Policy denied request: {decision.reason}",
                decision=decision,
            )

    # ------------------------------------------------------------------
    # Stage 5.5: Sovereign Policy Engine post-evaluation (flag-gated)
    # ------------------------------------------------------------------

    def _stage_policy_post(self, ctx: PipelineContext) -> None:
        """Evaluate the active Policy Bundle post-call.

        No-op unless COREIQ_POLICY_ENGINE=v2 is set and a pre-decision
        exists on the context. Updates the Decision in place and persists
        the updated record. Raises PipelinePolicyError on DENY.
        """
        if ctx.policy_decision is None:
            return
        if os.environ.get("COREIQ_POLICY_ENGINE", "").lower() != "v2":
            return
        try:
            from ..policy import get_policy_engine
            from ..policy.engine import RequestContext as PolicyCtx
            from ..policy.decision import DecisionAction, get_decision_writer
        except Exception as exc:
            logger.debug("policy engine unavailable for post-eval (non-fatal): %s", exc)
            return

        # Pull post-call signals from the same fields _stage_observe uses.
        output_tokens: Optional[int] = None
        output_text: Optional[str] = None
        cost_usd: Optional[float] = None
        if ctx.provider_response is not None:
            output_tokens = ctx.provider_response.completion_tokens
            output_text = ctx.provider_response.content
        if ctx.cost is not None:
            cost_usd = ctx.cost.total_cost

        pctx = PolicyCtx(
            tenant_id=ctx.tenant_id or "default",
            principal=ctx.virtual_key_id,
            groups=list(ctx.idp_groups or []),
            model=ctx.model,
            provider=ctx.provider_name,
            target_host=self._resolve_target_host(ctx),
            input_tokens=(
                ctx.provider_response.prompt_tokens
                if ctx.provider_response is not None else None
            ),
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            output_text=output_text,
            messages=list(ctx.messages or []),
            metadata={},
            trace_id=ctx.request_id,
        )

        try:
            get_policy_engine().evaluate_post(pctx, ctx.policy_decision)
        except Exception as exc:
            logger.debug("policy post-eval failed (non-fatal): %s", exc)
            return

        # Persist the updated decision (fail-soft).
        try:
            get_decision_writer().write(ctx.policy_decision)
        except Exception as exc:
            logger.debug("policy decision post-persist failed (non-fatal): %s", exc)

        if ctx.policy_decision.action == DecisionAction.DENY:
            raise PipelinePolicyError(
                str(ctx.policy_decision.reason or "policy denied"),
                decision=ctx.policy_decision,
            )

    def _maybe_stream_policy_post(
        self, ctx: "PipelineContext", accumulator: Any,
    ) -> Optional[str]:
        """Mid-stream Stage 5.5: re-evaluate post-rules against partial state.

        Returns the deny reason when a guardrail/limit fires, otherwise None.
        Cheap: bails out before constructing a PolicyCtx when no decision
        exists or the engine flag is off.
        """
        if ctx.policy_decision is None:
            return None
        if os.environ.get("COREIQ_POLICY_ENGINE", "").lower() != "v2":
            return None
        try:
            from ..policy import get_policy_engine
            from ..policy.engine import RequestContext as PolicyCtx
            from ..policy.decision import DecisionAction
        except Exception:
            return None

        partial_text = ""
        try:
            partial_text = accumulator.content or ""
        except Exception:
            pass

        # Best-effort partial cost estimate: per-chunk usage isn't always
        # available, but the test surface estimates from token count.
        partial_tokens = len(partial_text.split()) if partial_text else 0
        partial_cost = (
            ctx.cost.total_cost if (getattr(ctx, "cost", None) is not None) else None
        )

        pctx = PolicyCtx(
            tenant_id=ctx.tenant_id or "default",
            principal=ctx.virtual_key_id,
            groups=list(ctx.idp_groups or []),
            model=ctx.model,
            provider=ctx.provider_name,
            target_host=self._resolve_target_host(ctx),
            output_tokens=partial_tokens or None,
            cost_usd=partial_cost,
            output_text=partial_text or None,
            messages=list(ctx.messages or []),
            metadata={},
            trace_id=ctx.request_id,
        )
        try:
            get_policy_engine().evaluate_post(pctx, ctx.policy_decision)
        except Exception:
            return None
        if ctx.policy_decision.action == DecisionAction.DENY:
            return str(ctx.policy_decision.reason or "policy denied")
        return None

    # ------------------------------------------------------------------
    # Stage 2: Security pre-scan
    # ------------------------------------------------------------------

    async def _stage_pre_scan(self, ctx: PipelineContext) -> None:
        """Run injection detection and PII redaction on input messages.

        IMPORTANT: The scanner is synchronous — we run it in a thread
        to avoid blocking the async event loop.
        """
        from ..security.scanner import scan_and_redact

        try:
            scan_result, redacted_messages = await asyncio.to_thread(
                scan_and_redact, ctx.messages, check_pii=True
            )
        except Exception as exc:
            import os
            if os.getenv("COREIQ_SCAN_FAILURE_MODE", "closed").lower() == "open":
                logger.warning(
                    "Security pre-scan failed (COREIQ_SCAN_FAILURE_MODE=open, proceeding): %s", exc
                )
                return
            logger.error(
                "Security pre-scan hard failure — blocking request %s: %s",
                ctx.request_id, exc, exc_info=True,
            )
            raise PipelineSecurityError(
                "Security scanner unavailable; request blocked for safety. "
                "Set COREIQ_SCAN_FAILURE_MODE=open to allow requests when scanner fails."
            ) from exc

        ctx.scan_clean = scan_result.clean
        ctx.scan_issues = scan_result.issues

        # Persist any input-scan violations to the security_violations table.
        if not scan_result.clean and scan_result.issues:
            try:
                from ..security.violations import get_violation_recorder
                _vr = get_violation_recorder()
                for _issue in scan_result.issues:
                    _vr.record(
                        tenant_id=ctx.tenant_id or "default",
                        category="input_scan",
                        severity="high" if scan_result.injection_flags else "medium",
                        message=str(_issue),
                        trace_id=ctx.request_id,
                        action_taken="blocked" if scan_result.injection_flags else "flagged",
                    )
            except Exception as _vr_exc:
                logger.debug("Failed to record input violation: %s", _vr_exc)

        # Block on injection detection.
        if scan_result.injection_flags:
            logger.warning(
                "Prompt injection detected in request %s: %s",
                ctx.request_id,
                scan_result.injection_flags,
            )
            raise PipelineSecurityError(
                f"Request blocked: prompt injection detected ({len(scan_result.injection_flags)} indicator(s))."
            )

        # Apply PII redaction (replace messages with redacted versions).
        if scan_result.pii_found:
            ctx.messages = redacted_messages
            ctx.pii_redacted = True
            logger.info(
                "PII redacted in request %s: %s",
                ctx.request_id,
                scan_result.pii_found,
            )

        # Stage 2 additions: DLP scanning, multimodal guard
        try:
            # DLP scanning — detect sensitive data patterns (credentials, financial data, etc.)
            from ..security.dlp import DLPEngine
            _dlp_scanner = DLPEngine()
            _dlp_result = _dlp_scanner.scan_messages(ctx.messages)
            if not _dlp_result.clean and _dlp_result.action != "allow":
                logger.warning(
                    "DLP violations detected in request %s: %s",
                    ctx.request_id,
                    _dlp_result.findings,
                )
                # Record DLP violations
                try:
                    from ..security.violations import get_violation_recorder
                    _vr = get_violation_recorder()
                    for _finding in _dlp_result.findings:
                        _vr.record(
                            tenant_id=ctx.tenant_id or "default",
                            category="dlp_scan",
                            severity="high" if _dlp_result.action == "block" else "medium",
                            message=f"DLP finding: {_finding.description}",
                            trace_id=ctx.request_id,
                            action_taken="blocked" if _dlp_result.action == "block" else "flagged",
                        )
                except Exception as _vr_exc:
                    logger.debug("Failed to record DLP violation: %s", _vr_exc)

                # Block if DLP action is block
                if _dlp_result.action == "block":
                    raise PipelineSecurityError(
                        f"Request blocked: DLP violation detected. {_dlp_result.findings[0].description if _dlp_result.findings else 'Sensitive data patterns found.'}"
                    )
        except PipelineSecurityError:
            raise
        except Exception as _dlp_exc:
            logger.debug("DLP scan error (non-blocking): %s", _dlp_exc)

        # Multimodal guard — check image/video content for safety
        try:
            from ..security.multimodal_guard import MultiModalGuard
            _mm_guard = MultiModalGuard()
            _has_images = any(
                msg.get("content") and isinstance(msg.get("content"), list)
                for msg in ctx.messages
            )
            if _has_images:
                _mm_result = _mm_guard.scan_messages(ctx.messages)
                if not _mm_result.clean:
                    logger.warning(
                        "Multimodal guard detected unsafe content in request %s: %s",
                        ctx.request_id,
                        _mm_result.violations,
                    )
                    # Record multimodal violations
                    try:
                        from ..security.violations import get_violation_recorder
                        _vr = get_violation_recorder()
                        for _violation in _mm_result.violations:
                            _vr.record(
                                tenant_id=ctx.tenant_id or "default",
                                category="multimodal_scan",
                                severity="high",
                                message=f"Multimodal violation: {_violation}",
                                trace_id=ctx.request_id,
                                action_taken="blocked",
                            )
                    except Exception as _vr_exc:
                        logger.debug("Failed to record multimodal violation: %s", _vr_exc)

                    raise PipelineSecurityError(
                        f"Request blocked: unsafe image/video content detected. {_mm_result.violations[0] if _mm_result.violations else 'Inappropriate content found.'}"
                    )
        except PipelineSecurityError:
            raise
        except Exception as _mm_exc:
            logger.debug("Multimodal guard error (non-blocking): %s", _mm_exc)

    # ------------------------------------------------------------------
    # Stage 3: Function resolution
    # ------------------------------------------------------------------

    async def _stage_function_resolve(self, ctx: PipelineContext) -> None:
        """Resolve function name to variant/template.

        If ``ctx.model`` matches a registered function name (or ID), the
        function is resolved, a variant is selected (via experiment or
        weight-based sampling), templates are rendered, and the pipeline
        context is updated with the rendered messages and the variant's
        model.

        For composite variants (best-of-N, mixture-of-N), this stage handles
        the full dispatch (multiple LLM calls + judge/fuser) and sets
        ``ctx.provider_response`` directly, flagging Stage 5 to be skipped.

        If no function matches, this is a pass-through — messages are
        forwarded as-is to the provider.

        Uses shared singleton instances (lazy-initialized once) instead of
        creating fresh registries on every request.
        """
        try:
            fn_registry = self._get_function_registry()
            fn_def = fn_registry.resolve(ctx.model)
            if fn_def is None:
                return  # Not a function — pass through to provider

            variant_mgr = self._get_variant_manager()
            experiment_mgr = self._get_experiment_manager()

            # Episode-aware variant selection: if the request carries an
            # X-Episode-ID, load the episode context and use pinned variants
            # to ensure consistency within the conversation.
            episode_mgr = None
            episode_ctx = None
            if ctx.episode_id:
                try:
                    episode_mgr = self._get_episode_manager()
                    episode_ctx = episode_mgr.get(ctx.episode_id)
                    if episode_ctx is not None:
                        ctx._episode_context = episode_ctx
                except Exception as exc:
                    logger.debug("Episode load failed for %s: %s", ctx.episode_id, exc)

            # Select a variant — episode-pinned first, then experiment, then weights
            variant = None
            if episode_ctx is not None and episode_mgr is not None:
                pinned_id = episode_mgr.select_variant_for_episode(
                    ctx.episode_id, fn_def.id,
                )
                if pinned_id is not None:
                    variant = variant_mgr.get_by_id(pinned_id)

            if variant is None:
                variant = variant_mgr.select_variant(
                    fn_def.id,
                    experiment_manager=experiment_mgr,
                )

            if variant is None:
                logger.debug(
                    "Function '%s' resolved but no active variant — passing through",
                    fn_def.name,
                )
                return

            # Pin the selected variant into the episode for future turns
            if episode_ctx is not None:
                episode_ctx.pin_variant(fn_def.id, variant.id)

            # Extract stored input from messages
            # Convention: the last user message content is treated as the input
            stored_input: dict = {}
            for msg in reversed(ctx.messages):
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    if isinstance(content, str):
                        # Try to parse as JSON for structured input
                        try:
                            parsed = json.loads(content)
                            if isinstance(parsed, dict):
                                stored_input = parsed
                            else:
                                stored_input = {"text": content}
                        except (json.JSONDecodeError, ValueError):
                            stored_input = {"text": content}
                    elif isinstance(content, dict):
                        stored_input = content
                    else:
                        stored_input = {"text": str(content)}
                    break

            # Render templates if the variant has them
            if variant.system_template or variant.user_template:
                engine = self._get_template_engine()

                # Retrieve DICL examples if available
                dicl_messages = None
                try:
                    dicl = self._get_dicl_store()
                    examples = dicl.retrieve(fn_def.id, stored_input, k=3)
                    if examples:
                        dicl_messages = dicl.to_messages(examples)
                except Exception as exc:
                    logger.debug("DICL retrieval failed: %s", exc)

                variant_dict = {
                    "system_template": variant.system_template,
                    "user_template": variant.user_template,
                }
                rendered = engine.render_variant(
                    variant_dict, stored_input, dicl_messages=dicl_messages,
                )
                ctx.messages = rendered.messages
                ctx.stored_input_json = json.dumps(rendered.stored_input)
            else:
                # No templates — keep original messages
                ctx.stored_input_json = json.dumps(stored_input)

            # Update context with function/variant metadata
            ctx.function_id = fn_def.id
            ctx.variant_id = variant.id
            if not ctx.episode_id:
                ctx.episode_id = f"ep-{uuid.uuid4().hex[:16]}"

            # Replace model with the variant's model (if specified)
            if variant.model:
                ctx.model = variant.model

            logger.info(
                "Function resolved: %s -> variant=%s model=%s episode=%s",
                fn_def.name, variant.name, ctx.model, ctx.episode_id,
            )

            # --- Composite variant execution (best-of-N / mixture-of-N) ---
            from ..optimization.variant import VariantType as _VT

            if variant.type in (_VT.best_of_n, _VT.mixture_of_n):
                await self._execute_composite_variant(
                    ctx, variant, variant_mgr, fn_def,
                )

        except ImportError:
            # Optimization module not available — pass through
            pass
        except Exception as exc:
            logger.warning("Function resolution failed: %s", exc, exc_info=True)
            # Fail open — continue with original messages

    # ------------------------------------------------------------------
    # Stage 3b: Composite variant execution
    # ------------------------------------------------------------------

    async def _execute_composite_variant(
        self,
        ctx: PipelineContext,
        variant: Any,
        variant_mgr: Any,
        fn_def: Any,
    ) -> None:
        """Execute a composite variant (best-of-N or mixture-of-N).

        Resolves inner variants, runs the appropriate executor, and sets
        ``ctx.provider_response`` directly so that Stage 5 is skipped.
        """
        from ..optimization.composite import BestOfNExecutor, MixtureOfNExecutor
        from ..optimization.variant import VariantType as _VT

        # Resolve inner variants by name
        inner_variants = []
        for vname in variant.inner_variant_names:
            inner = variant_mgr.get(fn_def.id, vname)
            if inner is not None and inner.active:
                inner_variants.append(inner)
            else:
                logger.warning(
                    "Inner variant %r not found or inactive for function %s",
                    vname, fn_def.id,
                )

        n = variant.n
        timeout_s = (variant.config or {}).get("timeout_s", 60.0)

        if variant.type == _VT.best_of_n:
            executor = BestOfNExecutor(self._registry, self._cost)
            result = await executor.execute(
                variant,
                ctx.messages,
                inner_variants,
                n=n,
                judge_model=variant.judge_model,
                judge_criteria=(variant.config or {}).get("judge_criteria"),
                timeout_s=timeout_s,
            )
        elif variant.type == _VT.mixture_of_n:
            executor = MixtureOfNExecutor(self._registry, self._cost)
            result = await executor.execute(
                variant,
                ctx.messages,
                inner_variants,
                n=n,
                fuser_model=variant.fuser_model,
                fuser_instructions=(variant.config or {}).get("fuser_instructions"),
                timeout_s=timeout_s,
            )
        else:
            return  # Not a composite variant — should not happen

        # Build a synthetic ProviderResponse from the composite result
        ctx.provider_response = ProviderResponse(
            id=ctx.request_id,
            model=result.strategy,
            content=result.content,
            finish_reason="stop",
            usage={
                "prompt_tokens": 0,
                "completion_tokens": sum(c.tokens for c in result.candidates),
                "total_tokens": sum(c.tokens for c in result.candidates),
            },
            raw={
                "composite_strategy": result.strategy,
                "candidates": len(result.candidates),
                "selected_index": result.selected_index,
                "judge_reasoning": result.judge_reasoning,
                "total_cost_usd": result.total_cost_usd,
            },
            latency_ms=result.total_latency_ms,
        )
        ctx._skip_dispatch = True

        logger.info(
            "Composite variant %s executed: strategy=%s candidates=%d latency=%dms cost=$%.4f",
            variant.name, result.strategy, len(result.candidates),
            result.total_latency_ms, result.total_cost_usd,
        )

    # ------------------------------------------------------------------
    # Stage 4: Cache check
    # ------------------------------------------------------------------

    async def _cached_response_as_sse(self, cached: dict) -> AsyncIterator[str]:
        """Replay a cached non-streaming response as OpenAI-compatible SSE."""
        choices = cached.get("choices", [])
        content = ""
        finish_reason = "stop"
        if choices:
            msg = choices[0].get("message", {})
            content = msg.get("content", "") or ""
            finish_reason = choices[0].get("finish_reason") or "stop"

        request_id = cached.get("id", f"chatcmpl-{uuid.uuid4().hex[:12]}")
        model = cached.get("model", "")
        created = cached.get("created", int(time.time()))

        if content:
            yield f"data: {json.dumps({'id': request_id, 'object': 'chat.completion.chunk', 'created': created, 'model': model, 'choices': [{'index': 0, 'delta': {'content': content}, 'finish_reason': None}]})}\n\n"

        finish_event: dict = {
            "id": request_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": finish_reason}],
        }
        if "usage" in cached:
            finish_event["usage"] = cached["usage"]
        yield f"data: {json.dumps(finish_event)}\n\n"
        yield "data: [DONE]\n\n"

    def _stage_cache_check(self, ctx: PipelineContext) -> None:
        """Check the semantic cache for a matching response."""
        if self._cache is None:
            return

        try:
            entry = self._cache.get(ctx.messages, trace_id=ctx.request_id)
            if entry is not None:
                ctx.cache_hit = True
                ctx.cached_response = entry.response
                logger.info("Cache HIT for request %s", ctx.request_id)
            else:
                logger.debug("Cache MISS for request %s (store_size=%d)", ctx.request_id, len(self._cache._store))
        except Exception as exc:
            logger.warning("Cache check failed for %s: %s", ctx.request_id, exc, exc_info=True)

    # ------------------------------------------------------------------
    # Stage 5: Route & dispatch
    # ------------------------------------------------------------------

    def _resolve_provider(self, ctx: PipelineContext) -> tuple[ProviderConfig, str]:
        """Resolve the model string to a provider and bare model name."""
        try:
            return self._registry.resolve(ctx.model)
        except ProviderError as exc:
            raise PipelineProviderError(
                f"Cannot resolve model {ctx.model!r}: {exc}",
                status_code=400,
            ) from exc

    def _build_provider_request(self, ctx: PipelineContext, bare_model: str) -> ProviderRequest:
        """Build a ProviderRequest from the pipeline context."""
        return ProviderRequest(
            model=bare_model,
            messages=ctx.messages,
            temperature=ctx.temperature,
            max_tokens=ctx.max_tokens,
            top_p=ctx.top_p,
            stream=ctx.stream,
            tools=ctx.tools,
            tool_choice=ctx.tool_choice,
            response_format=ctx.response_format,
            stop=ctx.stop,
            frequency_penalty=ctx.frequency_penalty,
            presence_penalty=ctx.presence_penalty,
            seed=ctx.seed,
            user=ctx.user,
            n=ctx.n,
            logprobs=ctx.logprobs,
            top_logprobs=ctx.top_logprobs,
            trace_id=ctx.request_id,
        )

    async def _stage_dispatch(
        self,
        ctx: PipelineContext,
        provider: ProviderConfig,
        bare_model: str,
    ) -> None:
        """Send the request to the provider and store the response."""
        request = self._build_provider_request(ctx, bare_model)
        request.stream = False

        # Stage 5 additions: Agent policies check before tool calls
        if request.tools and len(request.tools) > 0:
            try:
                from ..governance.agent_policies import AgentPolicyEngine
                _policy_engine = AgentPolicyEngine()
                # Use model name as agent_id for policy checks
                _agent_id = ctx.model.split("/")[-1] if "/" in ctx.model else ctx.model
                # Start a session for this request (tool calls are session-based)
                _policy_engine.start_session(agent_id=_agent_id, delegation_depth=0)
                # Check tool call policies
                for tool in request.tools:
                    _tool_name = tool.get("name", "unknown")
                    try:
                        _tool_check = _policy_engine.check_tool_call(
                            session_id=ctx.request_id,
                            tool_name=_tool_name,
                        )
                        if not _tool_check.get("allowed", True):
                            raise PipelineSecurityError(
                                f"Tool '{_tool_name}' is not allowed for agent '{_agent_id}'. "
                                f"Reason: {_tool_check.get('reason', 'Policy violation')}"
                            )
                    except Exception as _tool_exc:
                        # Log but don't block if policy check fails (fail-safe)
                        logger.debug("Tool policy check error for '%s': %s", _tool_name, _tool_exc)
                # Check agent budget (will use actual cost after response)
            except PipelineSecurityError:
                raise
            except Exception as _policy_exc:
                logger.debug("Agent policy check error (non-blocking): %s", _policy_exc)

        try:
            response = await provider.complete(request)
        except ProviderAuthError as exc:
            raise PipelineProviderError(
                f"Provider authentication failed: {exc}",
                status_code=502,
            ) from exc
        except ProviderRateLimitError as exc:
            raise PipelineProviderError(
                f"Provider rate limited: {exc}",
                status_code=429,
            ) from exc
        except ProviderTimeoutError as exc:
            raise PipelineProviderError(
                f"Provider timed out: {exc}",
                status_code=504,
            ) from exc
        except ProviderError as exc:
            raise PipelineProviderError(
                f"Provider error: {exc}",
                status_code=exc.status_code or 502,
            ) from exc

        ctx.provider_response = response

    # ------------------------------------------------------------------
    # Stage 5b: Routed dispatch (DeploymentRouter with fallbacks)
    # ------------------------------------------------------------------

    async def _policy_select_deployments(
        self,
        ctx: PipelineContext,
        request: ProviderRequest,
        *,
        max_attempts: int = 3,
    ) -> list[Deployment]:
        """Select deployments honoring the active policy decision.

        - If the policy decision pinned a ``target_deployment``, force its
          selection (when present in the router).
        - Otherwise pass the bundle's residency to the router so the
          fallback chain stays within the declared region.
        """
        assert self._deployment_router is not None

        decision = ctx.policy_decision

        # P1: honor pinned target_deployment from the policy decision.
        if decision is not None:
            target_id = getattr(decision, "target_deployment", None)
            if target_id:
                pinned = self._deployment_router.get_deployment(target_id)
                if pinned is not None and pinned.enabled:
                    logger.debug(
                        "Policy pinned deployment %s for request %s",
                        target_id, ctx.request_id,
                    )
                    return [pinned]
                logger.warning(
                    "Policy pinned deployment %s not found/enabled — "
                    "falling back to router selection", target_id,
                )

        # P2: pass bundle residency to router for the fallback chain.
        residency: Optional[str] = None
        if decision is not None:
            try:
                from ..policy import get_policy_engine
                bundle = get_policy_engine().get_bundle()
                if bundle is not None and bundle.residency and bundle.residency != "any":
                    residency = bundle.residency
            except Exception as exc:
                logger.debug("Bundle residency lookup failed (non-fatal): %s", exc)

        if residency is not None:
            return await self._deployment_router.select_with_fallbacks(
                request, max_attempts=max_attempts, residency=residency,
            )
        return await self._deployment_router.select_with_fallbacks(
            request, max_attempts=max_attempts,
        )

    async def _routed_dispatch(self, ctx: PipelineContext) -> None:
        """Dispatch via the DeploymentRouter with automatic fallbacks.

        Selects an ordered list of deployments and tries each in turn.
        On success, records metrics.  On retryable failure (429, 5xx,
        timeout, connection error), records the failure and tries the
        next deployment.  Non-retryable errors (auth, 4xx) raise
        immediately.
        """
        assert self._deployment_router is not None

        # Build a ProviderRequest for the router's strategy selection.
        dummy_request = self._build_provider_request(ctx, ctx.model)
        dummy_request.stream = False

        try:
            deployments = await self._policy_select_deployments(
                ctx, dummy_request, max_attempts=3,
            )
        except NoAvailableDeploymentError as exc:
            raise PipelineProviderError(
                f"No deployments available for model {ctx.model!r}: {exc}",
                status_code=503,
            ) from exc

        last_exc: Optional[Exception] = None

        for deployment in deployments:
            provider = deployment.provider_config
            # Use registry to resolve bare_model so overrides (e.g.
            # "openai/gpt-oss-120b" → openai_compat) keep the full name.
            try:
                _, bare_model = self._registry.resolve(ctx.model)
            except Exception:
                bare_model = ctx.model.split("/", 1)[-1] if "/" in ctx.model else ctx.model

            request = self._build_provider_request(ctx, bare_model)
            request.stream = False

            ctx.provider_name = provider.provider_name
            self._deployment_router.increment_in_flight(deployment.id)
            call_start = time.monotonic()

            try:
                response = await provider.complete(request)
                latency_ms = int((time.monotonic() - call_start) * 1000)

                # Record success metrics for the routing strategy.
                self._deployment_router.record_success(deployment.id, latency_ms)
                ctx.provider_response = response
                logger.info(
                    "Routed request %s to deployment %s (%s) — %dms",
                    ctx.request_id, deployment.id, deployment.model, latency_ms,
                )
                return

            except ProviderAuthError as exc:
                # Auth errors are not retryable — raise immediately.
                self._deployment_router.record_failure(deployment.id)
                raise PipelineProviderError(
                    f"Provider authentication failed on deployment {deployment.id}: {exc}",
                    status_code=502,
                ) from exc

            except (ProviderRateLimitError, ProviderTimeoutError, ProviderError) as exc:
                # Retryable errors — record failure and try next deployment.
                self._deployment_router.record_failure(deployment.id)
                status = getattr(exc, "status_code", None)
                # Non-retryable client errors (4xx except 429) should not fallback.
                if status is not None and 400 <= status < 500 and status != 429:
                    raise PipelineProviderError(
                        f"Provider error on deployment {deployment.id}: {exc}",
                        status_code=status,
                    ) from exc

                logger.warning(
                    "Deployment %s failed for request %s: %s — trying next fallback",
                    deployment.id, ctx.request_id, exc,
                )
                last_exc = exc
                continue

            except Exception as exc:
                # Unexpected errors — record failure, try next.
                self._deployment_router.record_failure(deployment.id)
                logger.warning(
                    "Unexpected error on deployment %s for request %s: %s",
                    deployment.id, ctx.request_id, exc, exc_info=True,
                )
                last_exc = exc
                continue

            finally:
                self._deployment_router.decrement_in_flight(deployment.id)

        # All deployments exhausted.
        if isinstance(last_exc, ProviderRateLimitError):
            raise PipelineProviderError(
                f"All deployments rate limited for {ctx.model!r}",
                status_code=429,
            ) from last_exc
        elif isinstance(last_exc, ProviderTimeoutError):
            raise PipelineProviderError(
                f"All deployments timed out for {ctx.model!r}",
                status_code=504,
            ) from last_exc
        elif last_exc is not None:
            raise PipelineProviderError(
                f"All deployments failed for {ctx.model!r}: {last_exc}",
                status_code=502,
            ) from last_exc
        else:
            raise PipelineProviderError(
                f"No deployments could serve {ctx.model!r}",
                status_code=503,
            )

    async def _routed_stream(self, ctx: PipelineContext) -> AsyncIterator[str]:
        """Streaming dispatch via DeploymentRouter with fallbacks.

        Tries each deployment in order.  Unlike non-streaming, errors
        during chunk iteration cannot fall back (the SSE connection is
        already open), so fallback only applies to connection-level
        errors.
        """
        assert self._deployment_router is not None

        dummy_request = self._build_provider_request(ctx, ctx.model)
        dummy_request.stream = True

        try:
            deployments = await self._policy_select_deployments(
                ctx, dummy_request, max_attempts=3,
            )
        except NoAvailableDeploymentError as exc:
            raise PipelineProviderError(
                f"No deployments available for streaming {ctx.model!r}: {exc}",
                status_code=503,
            ) from exc

        last_exc: Optional[Exception] = None

        for deployment in deployments:
            provider = deployment.provider_config
            try:
                _, bare_model = self._registry.resolve(ctx.model)
            except Exception:
                bare_model = ctx.model.split("/", 1)[-1] if "/" in ctx.model else ctx.model

            ctx.provider_name = provider.provider_name

            try:
                return await self._routed_stream_generator(
                    ctx, deployment, provider, bare_model,
                )

            except (ProviderAuthError,) as exc:
                self._deployment_router.record_failure(deployment.id)
                raise PipelineProviderError(
                    f"Provider auth failed on deployment {deployment.id}: {exc}",
                    status_code=502,
                ) from exc

            except (ProviderRateLimitError, ProviderTimeoutError, ProviderError) as exc:
                self._deployment_router.record_failure(deployment.id)
                status = getattr(exc, "status_code", None)
                if status is not None and 400 <= status < 500 and status != 429:
                    raise PipelineProviderError(
                        f"Provider error on deployment {deployment.id}: {exc}",
                        status_code=status,
                    ) from exc

                logger.warning(
                    "Streaming deployment %s failed for %s: %s — trying next",
                    deployment.id, ctx.request_id, exc,
                )
                last_exc = exc
                continue

            except Exception as exc:
                self._deployment_router.record_failure(deployment.id)
                logger.warning(
                    "Unexpected streaming error on deployment %s: %s",
                    deployment.id, exc, exc_info=True,
                )
                last_exc = exc
                continue

        # All deployments exhausted.
        if isinstance(last_exc, ProviderRateLimitError):
            raise PipelineProviderError(
                f"All deployments rate limited for streaming {ctx.model!r}",
                status_code=429,
            ) from last_exc
        elif last_exc is not None:
            raise PipelineProviderError(
                f"All deployments failed for streaming {ctx.model!r}: {last_exc}",
                status_code=502,
            ) from last_exc
        else:
            raise PipelineProviderError(
                f"No deployments could serve streaming {ctx.model!r}",
                status_code=503,
            )

    async def _routed_stream_generator(
        self,
        ctx: PipelineContext,
        deployment: Deployment,
        provider: ProviderConfig,
        bare_model: str,
    ) -> AsyncIterator[str]:
        """Build the SSE generator for a routed streaming request."""
        request = self._build_provider_request(ctx, bare_model)
        request.stream = True

        try:
            chunk_iter = provider.stream(request)
        except (ProviderAuthError, ProviderRateLimitError, ProviderError):
            # Re-raise so the caller can try the next deployment.
            raise

        accumulator = StreamingResponseAccumulator(
            model=ctx.model,
            request_id=ctx.request_id,
        )
        call_start = time.monotonic()
        self._deployment_router.increment_in_flight(deployment.id)

        # Streaming guardrails wrapper (optional, via env var)
        import os as _os
        _use_streaming_guard = _os.getenv("COREIQ_STREAMING_GUARD_ENABLED", "false").lower() == "true"
        if _use_streaming_guard:
            try:
                from ..security.streaming_guard import StreamingGuard, DEFAULT_STREAM_RULES
                def _on_streaming_violation(violation):
                    logger.warning(
                        "Streaming guardrail violation in %s: %s at token %d",
                        ctx.request_id, violation.type, violation.token_position
                    )
                    # Record violation to security_violations table
                    try:
                        from ..security.violations import get_violation_recorder
                        _vr = get_violation_recorder()
                        _vr.record(
                            tenant_id=ctx.tenant_id or "default",
                            category="streaming_guard",
                            severity="high",
                            message=f"Streaming violation: {violation.type} - {violation.rule_name}",
                            trace_id=ctx.request_id,
                            action_taken="blocked",
                        )
                    except Exception:
                        pass
                _stream_guard = StreamingGuard(
                    rules=DEFAULT_STREAM_RULES,
                    on_violation=_on_streaming_violation
                )
                # Wrap the chunk iterator with streaming guard
                chunk_iter = _stream_guard.filter_stream(chunk_iter)
            except Exception as _sg_exc:
                logger.debug("Streaming guardrail setup error (non-blocking): %s", _sg_exc)

        async def sse_generator() -> AsyncIterator[str]:
            """Yield SSE events and run post-stream stages.

            Wave 2A P1 — Stage 5.5 streaming coverage:
            we evaluate the policy post-stage incrementally. If a guardrail
            or limit fires mid-stream, we emit a synthetic terminal SSE
            event carrying the deny reason and close the stream.
            """
            try:
                async for chunk in chunk_iter:
                    accumulator.add(chunk)

                    # Mid-stream policy check: re-run Stage 5.5 against the
                    # partial accumulator state. _maybe_stream_policy_post
                    # returns the deny reason when a deny was tripped; the
                    # caller emits a terminal SSE event and breaks.
                    deny_reason = self._maybe_stream_policy_post(ctx, accumulator)
                    if deny_reason:
                        terminal = {
                            "id": ctx.request_id,
                            "object": "chat.completion.chunk",
                            "created": int(time.time()),
                            "model": ctx.model,
                            "choices": [{
                                "index": 0,
                                "delta": {},
                                "finish_reason": "policy_deny",
                            }],
                            "error": {
                                "message": f"policy denied mid-stream: {deny_reason}",
                                "type": "policy_error",
                                "code": "policy_deny",
                            },
                        }
                        yield f"data: {json.dumps(terminal)}\n\n"
                        yield "data: [DONE]\n\n"
                        return

                    delta: dict = {}
                    if chunk.text:
                        delta["content"] = chunk.text
                    if chunk.tool_calls:
                        delta["tool_calls"] = chunk.tool_calls

                    if chunk.is_finished and not delta:
                        event = {
                            "id": ctx.request_id,
                            "object": "chat.completion.chunk",
                            "created": int(time.time()),
                            "model": ctx.model,
                            "choices": [{
                                "index": 0,
                                "delta": {},
                                "finish_reason": chunk.finish_reason or "stop",
                            }],
                        }
                        if chunk.usage:
                            event["usage"] = chunk.usage
                        yield f"data: {json.dumps(event)}\n\n"
                        break

                    if not delta and not chunk.finish_reason:
                        continue

                    event = {
                        "id": ctx.request_id,
                        "object": "chat.completion.chunk",
                        "created": int(time.time()),
                        "model": ctx.model,
                        "choices": [{
                            "index": 0,
                            "delta": delta,
                            "finish_reason": chunk.finish_reason if chunk.is_finished else None,
                        }],
                    }
                    if chunk.usage:
                        event["usage"] = chunk.usage
                    yield f"data: {json.dumps(event)}\n\n"

                    if chunk.is_finished:
                        break

                yield "data: [DONE]\n\n"

                # Record success metrics.
                latency_ms = int((time.monotonic() - call_start) * 1000)
                self._deployment_router.record_success(deployment.id, latency_ms)

            except ProviderRateLimitError as exc:
                self._deployment_router.record_failure(deployment.id)
                error_event = {
                    "error": {
                        "message": f"Provider rate limited: {exc}",
                        "type": "rate_limit_error",
                        "code": "429",
                    }
                }
                yield f"data: {json.dumps(error_event)}\n\n"
                yield "data: [DONE]\n\n"
                return
            except ProviderError as exc:
                self._deployment_router.record_failure(deployment.id)
                error_event = {
                    "error": {
                        "message": f"Provider error: {exc}",
                        "type": "server_error",
                        "code": str(exc.status_code or 502),
                    }
                }
                yield f"data: {json.dumps(error_event)}\n\n"
                yield "data: [DONE]\n\n"
                return
            except Exception as exc:
                self._deployment_router.record_failure(deployment.id)
                logger.error(
                    "Routed streaming error for %s: %s",
                    ctx.request_id, exc, exc_info=True,
                )
                error_event = {
                    "error": {
                        "message": "Internal streaming error",
                        "type": "server_error",
                        "code": "500",
                    }
                }
                yield f"data: {json.dumps(error_event)}\n\n"
                yield "data: [DONE]\n\n"
                return
            finally:
                self._deployment_router.decrement_in_flight(deployment.id)

            # --- Post-stream stages (6 & 7) ---
            ctx.provider_response = accumulator.to_response()
            if accumulator.ttft_ms is not None:
                ctx.ttft_ms = accumulator.ttft_ms

            try:
                await self._stage_post_scan(ctx)
            except Exception as exc:
                logger.warning("Post-stream security scan failed: %s", exc)

            try:
                self._stage_policy_post(ctx)
            except PipelinePolicyError:
                # Streaming response is already in flight; we cannot reject
                # at this point — log and continue to observe.
                logger.warning(
                    "Policy post-eval would deny streaming request %s "
                    "(response already streamed)", ctx.request_id,
                )
            except Exception as exc:
                logger.debug("Post-stream policy eval failed: %s", exc)

            try:
                await self._run_observe(ctx)
            except Exception as exc:
                logger.warning("Post-stream observe failed: %s", exc)

        return sse_generator()

    # ------------------------------------------------------------------
    # Stage 6: Security post-scan
    # ------------------------------------------------------------------

    async def _stage_post_scan(self, ctx: PipelineContext) -> None:
        """Run output guardrails on the provider response."""
        if ctx.provider_response is None:
            return

        response_content = ctx.provider_response.content
        if not response_content:
            return

        from ..security.scanner import scan_messages

        output_messages = [{"role": "assistant", "content": response_content}]

        try:
            scan_result = await asyncio.to_thread(
                scan_messages, output_messages, check_pii=False
            )
        except Exception as exc:
            logger.error(
                "Security post-scan failed for request %s: %s",
                ctx.request_id, exc, exc_info=True,
            )
            return

        ctx.post_scan_clean = scan_result.clean
        ctx.post_scan_issues = scan_result.issues

        # Persist any output-scan violations to the security_violations table.
        if not scan_result.clean and scan_result.issues:
            try:
                from ..security.violations import get_violation_recorder
                _vr = get_violation_recorder()
                for _issue in scan_result.issues:
                    _vr.record(
                        tenant_id=ctx.tenant_id or "default",
                        category="output_scan",
                        severity="high" if scan_result.output_violations else "medium",
                        message=str(_issue),
                        trace_id=ctx.request_id,
                        action_taken="blocked" if scan_result.output_violations else "flagged",
                    )
            except Exception as _vr_exc:
                logger.debug("Failed to record output violation: %s", _vr_exc)

        if scan_result.output_violations:
            logger.warning(
                "Output violations in request %s: %s",
                ctx.request_id,
                scan_result.output_violations,
            )

        # Per-group content guardrules (applied after global output scan).
        if ctx.idp_groups:
            try:
                output_tokens = 0
                if ctx.provider_response:
                    output_tokens = ctx.provider_response.completion_tokens or 0
                from ..governance.guardrails import get_guardrail_engine, GuardrailViolation
                group_violations = get_guardrail_engine().check_output(
                    groups=ctx.idp_groups,
                    tenant_id=ctx.tenant_id or "default",
                    output_text=response_content,
                    output_tokens=output_tokens,
                    raise_on_violation=False,  # collect all, then decide
                )
                if group_violations:
                    ctx.post_scan_issues = ctx.post_scan_issues + group_violations
                    ctx.post_scan_clean = False
                    logger.warning(
                        "Group guardrule violations in request %s (groups=%s): %s",
                        ctx.request_id, ctx.idp_groups, group_violations,
                    )
                    # Re-run with raise=True to surface the first blocking violation
                    get_guardrail_engine().check_output(
                        groups=ctx.idp_groups,
                        tenant_id=ctx.tenant_id or "default",
                        output_text=response_content,
                        output_tokens=output_tokens,
                        raise_on_violation=True,
                    )
            except Exception as _grail_exc:
                from ..governance.guardrails import GuardrailViolation
                if isinstance(_grail_exc, GuardrailViolation):
                    raise PipelineSecurityError(str(_grail_exc)) from _grail_exc
                logger.debug("Group guardrule post-scan error (non-blocking): %s", _grail_exc)

        # Stage 6 additions: Bias monitoring, egress filtering
        try:
            # Bias monitoring — detect potential bias in AI responses
            from ..governance.bias_monitor import BiasMonitor
            _bias_monitor = BiasMonitor()
            _bias_result = _bias_monitor.analyze([response_content])
            if _bias_result.bias_detected:
                logger.warning(
                    "Bias detected in response %s: %s (fairness: %.2f)",
                    ctx.request_id,
                    _bias_result.recommendations,
                    _bias_result.fairness_score,
                )
                # Record bias violations (flagged, not blocked)
                try:
                    from ..security.violations import get_violation_recorder
                    _vr = get_violation_recorder()
                    for _rec in _bias_result.recommendations:
                        _vr.record(
                            tenant_id=ctx.tenant_id or "default",
                            category="bias_detection",
                            severity="medium",
                            message=f"Bias detected: {_rec}",
                            trace_id=ctx.request_id,
                            action_taken="flagged",
                        )
                except Exception as _vr_exc:
                    logger.debug("Failed to record bias violation: %s", _vr_exc)
        except Exception as _bias_exc:
            logger.debug("Bias monitoring error (non-blocking): %s", _bias_exc)

        # Egress filtering — check for unsafe URLs in response
        try:
            import re as _re
            from ..security.egress import EgressChecker
            _egress_checker = EgressChecker()
            # Extract URLs from response content
            _urls = _re.findall(r'https?://[^\s<>"{}|\\^`\[\]]+', response_content)
            if _urls:
                for _url in set(_urls):  # dedupe
                    _egress_result = _egress_checker.check(_url)
                    if not _egress_result.allowed:
                        logger.warning(
                            "Egress check failed in response %s: %s (url: %s)",
                            ctx.request_id,
                            _egress_result.reason,
                            _url,
                        )
                        # Record egress violations
                        try:
                            from ..security.violations import get_violation_recorder
                            _vr = get_violation_recorder()
                            _vr.record(
                                tenant_id=ctx.tenant_id or "default",
                                category="egress_filter",
                                severity="high",
                                message=f"Egress violation: {_egress_result.reason} (URL: {_url})",
                                trace_id=ctx.request_id,
                                action_taken="blocked",
                            )
                        except Exception as _vr_exc:
                            logger.debug("Failed to record egress violation: %s", _vr_exc)

                        # Block responses with unsafe URLs
                        raise PipelineSecurityError(
                            f"Response blocked: unsafe outbound URL detected. {_egress_result.reason}"
                        )
        except PipelineSecurityError:
            raise
        except Exception as _egress_exc:
            logger.debug("Egress filtering error (non-blocking): %s", _egress_exc)

        # Watermarking — embed provenance watermark in response (optional)
        try:
            import os as _os
            if _os.getenv("COREIQ_WATERMARK_ENABLED", "false").lower() == "true":
                from ..security.watermark import TextWatermarker
                _watermarker = TextWatermarker()
                _wm_result = _watermarker.embed(response_content, ctx.request_id)
                if _wm_result.substitutions > 0:
                    logger.info(
                        "Watermark embedded in response %s: %d substitutions",
                        ctx.request_id, _wm_result.substitutions,
                    )
                    # Update context with watermarked content
                    if ctx.provider_response:
                        ctx.provider_response.content = _wm_result.watermarked_text
                        response_content = _wm_result.watermarked_text
        except Exception as _wm_exc:
            logger.debug("Watermarking error (non-blocking): %s", _wm_exc)

    # ------------------------------------------------------------------
    # Stage 7: Observe
    # ------------------------------------------------------------------

    def _stage_observe(self, ctx: PipelineContext) -> None:
        """Record trace, calculate cost, and write audit log."""
        ctx.latency_ms = int((time.monotonic() - ctx.start_time) * 1000)

        # Calculate cost.
        if ctx.provider_response:
            try:
                ctx.cost = self._cost.calculate(
                    model=ctx.provider_response.model or ctx.model,
                    provider=ctx.provider_name,
                    input_tokens=ctx.provider_response.prompt_tokens,
                    output_tokens=ctx.provider_response.completion_tokens,
                )
            except Exception as exc:
                logger.error(
                    "Cost calculation failed for request %s (model=%s, provider=%s): %s",
                    ctx.request_id, ctx.model, ctx.provider_name, exc,
                )
                # Mark failure in meta so it's queryable/alertable
                ctx._cost_calculation_failed = True

        # Resolve common values used by trace write, payload capture, prometheus, and eval.
        writer = self._get_writer()
        input_tok = 0
        output_tok = 0
        finish_reason = "stop"
        if ctx.provider_response:
            input_tok = ctx.provider_response.prompt_tokens
            output_tok = ctx.provider_response.completion_tokens
            finish_reason = ctx.provider_response.finish_reason

        # Write trace.
        try:
            # ── Extract user/assistant message content ──────────────────────
            user_msg: Optional[str] = None
            assistant_msg: Optional[str] = None
            if ctx.messages:
                for m in reversed(ctx.messages):
                    if m.get("role") == "user" and user_msg is None:
                        c = m.get("content", "")
                        user_msg = c if isinstance(c, str) else json.dumps(c)
                        break
            if ctx.provider_response:
                assistant_msg = ctx.provider_response.content or None

            # ── Build structured meta ───────────────────────────────────────
            meta = {
                # Security
                "scan_clean": ctx.scan_clean,
                "scan_issues": ctx.scan_issues,
                "pii_redacted": ctx.pii_redacted,
                "post_scan_clean": ctx.post_scan_clean,
                # Request params
                "stream": ctx.stream,
                "temperature": ctx.temperature,
                "max_tokens": ctx.max_tokens,
                "top_p": ctx.top_p,
                "n": ctx.n,
                "seed": ctx.seed,
                "stop": ctx.stop,
                # Token breakdown
                "total_tok": (input_tok + output_tok) if (input_tok or output_tok) else None,
                # Conversation content (always captured — no PII masking at this layer)
                "user_msg": user_msg,
                "assistant_msg": assistant_msg,
                # Full messages array (request turns)
                "messages": ctx.messages or None,
                # Routing / function
                "function_id": ctx.function_id,
                "variant_id": ctx.variant_id,
                "episode_id": ctx.episode_id,
                # Identity
                "cache_hit": ctx.cache_hit,
                "tenant_id": ctx.tenant_id or None,
                "virtual_key_id": ctx.virtual_key_id or None,
                "user": ctx.user,
            }
            if ctx.provider_response:
                meta["provider_model_id"] = ctx.provider_response.model
                meta["provider_response_id"] = ctx.provider_response.id
                meta["usage"] = ctx.provider_response.usage
            if ctx.cost:
                meta["cost_usd"] = ctx.cost.total_cost
                meta["cached_input_cost"] = ctx.cost.cached_input_cost if hasattr(ctx.cost, "cached_input_cost") else None
            if getattr(ctx, "_cost_calculation_failed", False):
                meta["cost_calculation_failed"] = True
            # Strip None values to keep meta_json compact
            meta = {k: v for k, v in meta.items() if v is not None}

            writer.insert_trace(
                id=ctx.request_id,
                model=ctx.model,
                provider=ctx.provider_name or "unknown",
                input_tok=input_tok,
                output_tok=output_tok,
                latency_ms=ctx.latency_ms,
                finish_reason=finish_reason,
                cache_hit=ctx.cache_hit,
                meta_json=json.dumps(meta),
                user_id=ctx.user,
                tenant_id=ctx.tenant_id,
                virtual_key_id=ctx.virtual_key_id,
                ttft_ms=ctx.ttft_ms or None,
                cost_usd=ctx.cost.total_cost if ctx.cost else None,
                policy_decision_id=getattr(ctx, "policy_decision_id", None),
            )
        except Exception as exc:
            logger.warning("Failed to write trace for %s: %s", ctx.request_id, exc)

        # Payload capture (opt-in — COREIQ_CAPTURE_PAYLOADS=true)
        if os.environ.get("COREIQ_CAPTURE_PAYLOADS", "").lower() == "true":
            try:
                from ..observability.masking import mask_dict
                max_bytes = int(os.environ.get("COREIQ_PAYLOAD_MAX_BYTES", "102400"))
                half = max_bytes // 2

                # Request: mask each message dict then serialize
                if ctx.messages:
                    masked_msgs = [mask_dict(m) if isinstance(m, dict) else m for m in ctx.messages]
                    req_raw = json.dumps(masked_msgs)
                    req_bytes = req_raw.encode()
                    req_truncated = len(req_bytes) > half
                    writer.insert_payload(
                        trace_id=ctx.request_id,
                        direction="request",
                        content=req_bytes[:half].decode(errors="replace"),
                        size_bytes=len(req_bytes),
                        truncated=req_truncated,
                        tenant_id=ctx.tenant_id,
                    )
                    remaining = half if req_truncated else (max_bytes - len(req_bytes))
                else:
                    remaining = half

                # Response: serialize and mask choices
                if ctx.provider_response:
                    try:
                        choices_data = [
                            {"index": c.index, "message": mask_dict({"role": c.message.role, "content": c.message.content}), "finish_reason": c.finish_reason}
                            for c in (ctx.provider_response.choices or [])
                        ] if hasattr(ctx.provider_response, "choices") else []
                    except Exception:
                        choices_data = []
                    resp_raw = json.dumps(choices_data)
                    resp_bytes = resp_raw.encode()
                    resp_truncated = len(resp_bytes) > remaining
                    writer.insert_payload(
                        trace_id=ctx.request_id,
                        direction="response",
                        content=resp_bytes[:remaining].decode(errors="replace"),
                        size_bytes=len(resp_bytes),
                        truncated=resp_truncated,
                        tenant_id=ctx.tenant_id,
                    )
            except Exception as exc:
                logger.debug("Payload capture failed for %s: %s", ctx.request_id, exc)

        # Prometheus metrics
        try:
            from ..observability.prometheus import record_request as _prom_record
            _prom_record(
                model=ctx.model,
                provider=ctx.provider_name or "",
                input_tokens=input_tok,
                output_tokens=output_tok,
                latency_ms=ctx.latency_ms,
                cost_usd=ctx.cost.total_cost if ctx.cost else 0.0,
                cache_hit=ctx.cache_hit,
                error=(finish_reason not in ("stop", "length", "tool_calls", "function_call")),
            )
        except Exception:
            pass  # prometheus is best-effort

        # Audit log.
        try:
            self._get_audit().log(
                "proxy.inference",
                resource=ctx.model,
                principal=ctx.user or ctx.virtual_key_id or None,
                metadata={
                    "request_id": ctx.request_id,
                    "tenant_id": ctx.tenant_id or None,
                    "virtual_key_id": ctx.virtual_key_id or None,
                    "user_id": ctx.user or None,
                    "model": ctx.model,
                    "provider": ctx.provider_name,
                    "cache_hit": ctx.cache_hit,
                    "latency_ms": ctx.latency_ms,
                    "cost_usd": ctx.cost.total_cost if ctx.cost else None,
                    "pii_redacted": ctx.pii_redacted,
                    "scan_clean": ctx.scan_clean,
                    "post_scan_clean": ctx.post_scan_clean,
                    "input_tokens": ctx.provider_response.prompt_tokens if ctx.provider_response else 0,
                    "output_tokens": ctx.provider_response.completion_tokens if ctx.provider_response else 0,
                },
                trace_id=ctx.request_id,
            )
        except Exception as exc:
            logger.warning("Audit log failed for request %s: %s", ctx.request_id, exc)

        # Anomaly detection — feed the per-key rolling window detector.
        _anomaly_detected = False
        try:
            from ..governance.anomaly_realtime import get_anomaly_detector
            detector = get_anomaly_detector()
            key_id = ctx.virtual_key_id or ctx.tenant_id or None
            if key_id and ctx.provider_response:
                anomaly_events = detector.observe(
                    key_id=key_id,
                    input_tokens=ctx.provider_response.prompt_tokens,
                    output_tokens=ctx.provider_response.completion_tokens,
                    cost_usd=ctx.cost.total_cost if ctx.cost else 0.0,
                )
                for anomaly in anomaly_events:
                    _anomaly_detected = True
                    writer = self._get_writer()
                    writer.insert_event(
                        message=(
                            f"Anomaly detected ({anomaly.severity}): "
                            f"{anomaly.metric}={anomaly.value:.1f} "
                            f"z={anomaly.z_score:.2f} key={key_id}"
                        ),
                        level="warning" if anomaly.severity == "warning" else "error",
                        source="anomaly_detector",
                        trace_id=ctx.request_id,
                        tenant_id=ctx.tenant_id,
                        metadata={
                            "metric": anomaly.metric,
                            "value": anomaly.value,
                            "z_score": anomaly.z_score,
                            "severity": anomaly.severity,
                            "key_id": key_id,
                        },
                    )
                    # Webhook fan-out for the same anomaly event.
                    try:
                        from ..integrations.event_bus import emit, EVENT_ANOMALY_DETECTED
                        emit(EVENT_ANOMALY_DETECTED, {
                            "metric": anomaly.metric,
                            "value": anomaly.value,
                            "z_score": anomaly.z_score,
                            "severity": anomaly.severity,
                            "key_id": key_id,
                            "trace_id": ctx.request_id,
                        }, tenant_id=ctx.tenant_id)
                    except Exception:
                        pass
        except Exception as exc:
            logger.debug("Anomaly detection failed for %s: %s", ctx.request_id, exc)

        # Auto-eval trigger — 10% random sample + triggered by anomalies/failures.
        try:
            import random as _random
            eval_rate = float(os.environ.get("COREIQ_EVAL_SAMPLE_RATE", "0.1"))
            should_eval = (
                _anomaly_detected
                or not ctx.scan_clean
                or not ctx.post_scan_clean
                or finish_reason in ("content_filter", "error")
                or _random.random() < eval_rate
            )
            if should_eval:
                from ..store.eval_queue import enqueue_eval
                enqueue_eval(
                    ctx.request_id,
                    tenant_id=ctx.tenant_id or None,
                    model=ctx.model,
                )
        except Exception as exc:
            logger.debug("Eval enqueue failed for %s: %s", ctx.request_id, exc)

        # Record usage against virtual key.
        if ctx.virtual_key_id and self._key_manager is not None:
            try:
                tokens = 0
                cost = 0.0
                if ctx.provider_response:
                    tokens = (
                        ctx.provider_response.prompt_tokens
                        + ctx.provider_response.completion_tokens
                    )
                if ctx.cost:
                    cost = ctx.cost.total_cost
                self._key_manager.record_usage(
                    ctx.virtual_key_id, tokens=tokens, cost_usd=cost,
                )
            except Exception as exc:
                logger.debug("Virtual key usage recording failed: %s", exc)

        # Record rate limiter usage (RPM already counted in _stage_auth;
        # here we record TPM after we know the actual token count).
        if ctx.virtual_key_id and self._rate_limiter is not None:
            try:
                total_tokens = 0
                if ctx.provider_response:
                    total_tokens = (
                        ctx.provider_response.prompt_tokens
                        + ctx.provider_response.completion_tokens
                    )
                self._rate_limiter.record_usage(ctx.virtual_key_id, tokens=total_tokens)
            except Exception as exc:
                logger.debug("Rate limiter usage recording failed: %s", exc)

        # Store in cache for future hits.
        if (
            self._cache is not None
            and not ctx.cache_hit
            and ctx.provider_response is not None
        ):
            try:
                response_dict = self._format_response(ctx)
                total_tokens = (
                    ctx.provider_response.prompt_tokens
                    + ctx.provider_response.completion_tokens
                )
                self._cache.put(
                    ctx.original_messages,
                    response_dict,
                    tokens_used=total_tokens,
                )
                logger.debug("Cache stored for request %s (tokens=%d)", ctx.request_id, total_tokens)
            except Exception as exc:
                logger.warning("Cache store failed for %s: %s", ctx.request_id, exc, exc_info=True)

        # Write to inferences table when function resolution was active.
        if ctx.function_id is not None:
            try:
                self._write_inference(ctx)
            except Exception as exc:
                logger.warning("Failed to write inference for %s: %s", ctx.request_id, exc)

        # Auto-add turn to episode when an episode context is active.
        if ctx.episode_id and ctx._episode_context is not None:
            try:
                episode_mgr = self._get_episode_manager()
                episode_mgr.add_turn(
                    ctx.episode_id,
                    inference_id=ctx.request_id,
                    function_id=ctx.function_id,
                    variant_id=ctx.variant_id,
                    role="assistant",
                )
            except Exception as exc:
                logger.debug("Episode turn recording failed for %s: %s", ctx.episode_id, exc)

        # Stage 7 additions: Drift detection, compliance frameworks tracking
        try:
            # Lightweight drift tracking - feed metrics to anomaly detector
            from ..governance.anomaly_realtime import get_anomaly_detector
            _anomaly_detector = get_anomaly_detector()
            # Track token usage as a drift metric per model
            if input_tok > 0 or output_tok > 0:
                _anomaly_events = _anomaly_detector.observe(
                    key_id=f"{ctx.model}:{ctx.tenant_id or 'default'}",
                    input_tokens=input_tok,
                    output_tokens=output_tok,
                    cost_usd=ctx.cost.total_cost if ctx.cost else 0.0,
                )
                if _anomaly_events:
                    logger.warning(
                        "Anomalies detected for %s (request %s): %s",
                        ctx.model, ctx.request_id, _anomaly_events,
                    )
                    # Record anomalies as security violations
                    try:
                        from ..security.violations import get_violation_recorder
                        _vr = get_violation_recorder()
                        for _event in _anomaly_events:
                            _vr.record(
                                tenant_id=ctx.tenant_id or "default",
                                category="anomaly_detection",
                                severity=_event.severity,
                                message=f"Anomaly detected: {_event.metric}={_event.value:.2f} (z={_event.z_score:.2f})",
                                trace_id=ctx.request_id,
                                action_taken="flagged",
                            )
                    except Exception as _vr_exc:
                        logger.debug("Failed to record anomaly violation: %s", _vr_exc)
        except Exception as _drift_exc:
            logger.debug("Drift tracking error (non-blocking): %s", _drift_exc)

        # Compliance frameworks evidence gathering
        try:
            # Gather evidence for compliance frameworks (SOC 2, EU AI Act, GDPR)
            # This is lightweight evidence collection, not full package generation
            if hasattr(ctx, 'tenant_id') and ctx.tenant_id:
                # Record that this request is part of the compliance evidence trail
                # Full compliance packages can be generated via the export API
                pass  # Evidence gathering is lightweight - just metadata tracking
        except Exception as _compliance_exc:
            logger.debug("Compliance evidence gathering error (non-blocking): %s", _compliance_exc)

    # ------------------------------------------------------------------
    # Inference recording (for function-resolved requests)
    # ------------------------------------------------------------------

    def _write_inference(self, ctx: PipelineContext) -> None:
        """Write an inference record when a function was resolved in Stage 3."""
        from ..store.db import get_shared_connection
        from datetime import datetime, timezone

        conn = get_shared_connection()
        now = datetime.now(timezone.utc).isoformat()

        input_tok = 0
        output_tok = 0
        finish_reason = "stop"
        output_json = None
        rendered_input_json = None

        if ctx.provider_response:
            input_tok = ctx.provider_response.prompt_tokens
            output_tok = ctx.provider_response.completion_tokens
            finish_reason = ctx.provider_response.finish_reason
            if ctx.provider_response.content:
                output_json = json.dumps({"content": ctx.provider_response.content})

        # Store rendered messages as rendered_input_json
        if ctx.messages:
            rendered_input_json = json.dumps(ctx.messages)

        cost_usd = ctx.cost.total_cost if ctx.cost else None

        conn.execute(
            "INSERT INTO inferences(id, function_id, variant_id, episode_id, tenant_id, "
            "stored_input_json, rendered_input_json, output_json, model, provider, "
            "input_tokens, output_tokens, latency_ms, cost_usd, cache_hit, "
            "finish_reason, ts, user_id, session_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (ctx.request_id, ctx.function_id, ctx.variant_id, ctx.episode_id,
             ctx.tenant_id or None, ctx.stored_input_json, rendered_input_json,
             output_json, ctx.model, ctx.provider_name or None,
             input_tok, output_tok, ctx.latency_ms, cost_usd,
             int(ctx.cache_hit), finish_reason, now, ctx.user, None),
        )
        conn.commit()

    # ------------------------------------------------------------------
    # Streaming pipeline
    # ------------------------------------------------------------------

    async def _stream_with_pipeline(
        self,
        ctx: PipelineContext,
        provider: ProviderConfig,
        bare_model: str,
    ) -> AsyncIterator[str]:
        """Return an async generator that streams SSE and runs post-stages."""
        request = self._build_provider_request(ctx, bare_model)
        request.stream = True

        try:
            chunk_iter = provider.stream(request)
        except ProviderAuthError as exc:
            raise PipelineProviderError(
                f"Provider authentication failed: {exc}",
                status_code=502,
            ) from exc
        except ProviderError as exc:
            raise PipelineProviderError(
                f"Provider error: {exc}",
                status_code=exc.status_code or 502,
            ) from exc

        accumulator = StreamingResponseAccumulator(
            model=ctx.model,
            request_id=ctx.request_id,
        )

        async def sse_generator() -> AsyncIterator[str]:
            """Yield SSE events and run post-stream stages."""
            try:
                async for chunk in chunk_iter:
                    accumulator.add(chunk)

                    # Build SSE event inline for lower latency.
                    delta: dict = {}
                    if chunk.text:
                        delta["content"] = chunk.text
                    if chunk.tool_calls:
                        delta["tool_calls"] = chunk.tool_calls

                    if chunk.is_finished and not delta:
                        # Final sentinel.
                        event = {
                            "id": ctx.request_id,
                            "object": "chat.completion.chunk",
                            "created": int(time.time()),
                            "model": ctx.model,
                            "choices": [{
                                "index": 0,
                                "delta": {},
                                "finish_reason": chunk.finish_reason or "stop",
                            }],
                        }
                        if chunk.usage:
                            event["usage"] = chunk.usage
                        yield f"data: {json.dumps(event)}\n\n"
                        break

                    if not delta and not chunk.finish_reason:
                        continue

                    event = {
                        "id": ctx.request_id,
                        "object": "chat.completion.chunk",
                        "created": int(time.time()),
                        "model": ctx.model,
                        "choices": [{
                            "index": 0,
                            "delta": delta,
                            "finish_reason": chunk.finish_reason if chunk.is_finished else None,
                        }],
                    }
                    if chunk.usage:
                        event["usage"] = chunk.usage
                    yield f"data: {json.dumps(event)}\n\n"

                    if chunk.is_finished:
                        break

                yield "data: [DONE]\n\n"

            except ProviderRateLimitError as exc:
                error_event = {
                    "error": {
                        "message": f"Provider rate limited: {exc}",
                        "type": "rate_limit_error",
                        "code": "429",
                    }
                }
                yield f"data: {json.dumps(error_event)}\n\n"
                yield "data: [DONE]\n\n"
                return
            except ProviderError as exc:
                error_event = {
                    "error": {
                        "message": f"Provider error: {exc}",
                        "type": "server_error",
                        "code": str(exc.status_code or 502),
                    }
                }
                yield f"data: {json.dumps(error_event)}\n\n"
                yield "data: [DONE]\n\n"
                return
            except Exception as exc:
                logger.error("Streaming error for %s: %s", ctx.request_id, exc, exc_info=True)
                error_event = {
                    "error": {
                        "message": "Internal streaming error",
                        "type": "server_error",
                        "code": "500",
                    }
                }
                yield f"data: {json.dumps(error_event)}\n\n"
                yield "data: [DONE]\n\n"
                return

            # --- Post-stream stages (6 & 7) run after all chunks are sent ---
            ctx.provider_response = accumulator.to_response()
            if accumulator.ttft_ms is not None:
                ctx.ttft_ms = accumulator.ttft_ms

            # Stage 6: Post-scan (async, non-blocking for the client).
            try:
                await self._stage_post_scan(ctx)
            except Exception as exc:
                logger.warning("Post-stream security scan failed: %s", exc)

            # Stage 6.5: Policy post-evaluation.
            try:
                self._stage_policy_post(ctx)
            except PipelinePolicyError:
                logger.warning(
                    "Policy post-eval would deny streaming request %s "
                    "(response already streamed)", ctx.request_id,
                )
            except Exception as exc:
                logger.debug("Post-stream policy eval failed: %s", exc)

            # Stage 7: Observe.
            try:
                await self._run_observe(ctx)
            except Exception as exc:
                logger.warning("Post-stream observe failed: %s", exc)

        return sse_generator()

    # ------------------------------------------------------------------
    # Response formatting
    # ------------------------------------------------------------------

    def _format_response(self, ctx: PipelineContext) -> dict:
        """Format a non-streaming response in OpenAI ChatCompletion format."""
        resp = ctx.provider_response
        if resp is None:
            return {}

        result: dict[str, Any] = {
            "id": ctx.request_id,
            "object": "chat.completion",
            "created": int(time.time()),
            "model": ctx.model,
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": resp.content,
                    },
                    "finish_reason": resp.finish_reason,
                }
            ],
            "usage": resp.usage,
        }

        if resp.tool_calls:
            result["choices"][0]["message"]["tool_calls"] = resp.tool_calls
            # Persist each tool call to the tool_calls table.
            try:
                import uuid as _uuid
                from ..store.db import get_shared_connection as _get_conn
                _conn = _get_conn()
                from datetime import datetime as _dt, timezone as _tz
                _now_ts = _dt.now(_tz.utc).isoformat()
                for _tc in resp.tool_calls:
                    _fn = _tc.get("function", {}) if isinstance(_tc, dict) else {}
                    _conn.execute(
                        "INSERT INTO tool_calls(id,trace_id,tool_name,args_json,valid,ts)"
                        " VALUES(?,?,?,?,?,?)",
                        (
                            str(_uuid.uuid4()),
                            ctx.request_id,
                            _fn.get("name", "unknown"),
                            _fn.get("arguments", "{}"),
                            1,
                            _now_ts,
                        ),
                    )
                _conn.commit()
            except Exception as _tc_exc:
                logger.debug("Failed to persist tool calls: %s", _tc_exc)

        # CoreIQ extensions.
        coreiq_ext: dict[str, Any] = {
            "request_id": ctx.request_id,
            "provider": ctx.provider_name,
            "cache_hit": ctx.cache_hit,
            "latency_ms": ctx.latency_ms,
            "cost_usd": ctx.cost.total_cost if ctx.cost else None,
            "scan_clean": ctx.scan_clean,
        }
        if ctx.function_id:
            coreiq_ext["function_id"] = ctx.function_id
            coreiq_ext["variant_id"] = ctx.variant_id
            coreiq_ext["episode_id"] = ctx.episode_id
        result["_coreiq"] = coreiq_ext

        return result
