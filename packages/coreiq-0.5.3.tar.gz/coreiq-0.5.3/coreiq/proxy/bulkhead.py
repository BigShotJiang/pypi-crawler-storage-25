"""Per-tenant bulkhead.

Limits in-flight requests per tenant so a single noisy tenant cannot
saturate the proxy and starve the rest. Uses an asyncio.Semaphore per
tenant; queue depth is exported via OTel gauges.

Configure via env::

    COREIQ_BULKHEAD_DEFAULT_CONCURRENCY=64   # per-tenant default
    COREIQ_BULKHEAD_TENANT_<NAME>=<int>      # tenant-specific override

Usage::

    async with bulkhead.acquire(tenant_id):
        return await pipeline.process(...)

Raises ``BulkheadError`` if the wait queue grows past the soft cap (no
infinite waits — back-pressure is signalled to the caller).
"""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from typing import AsyncIterator

from coreiq.exceptions import BulkheadError

logger = logging.getLogger("coreiq.proxy.bulkhead")

_DEFAULT_CONCURRENCY = int(os.environ.get("COREIQ_BULKHEAD_DEFAULT_CONCURRENCY", "64"))
_DEFAULT_QUEUE_TIMEOUT = float(os.environ.get("COREIQ_BULKHEAD_QUEUE_TIMEOUT_SECS", "10"))


class _TenantSlot:
    __slots__ = ("sem", "waiting", "in_flight", "limit")

    def __init__(self, limit: int) -> None:
        self.sem = asyncio.Semaphore(limit)
        self.waiting = 0
        self.in_flight = 0
        self.limit = limit


_SLOTS: dict[str, _TenantSlot] = {}
_SLOTS_LOCK = asyncio.Lock()


def _tenant_limit(tenant: str) -> int:
    env_key = f"COREIQ_BULKHEAD_TENANT_{tenant.upper()}"
    raw = os.environ.get(env_key)
    if raw and raw.isdigit():
        return max(int(raw), 1)
    return _DEFAULT_CONCURRENCY


async def _slot_for(tenant: str) -> _TenantSlot:
    slot = _SLOTS.get(tenant)
    if slot is not None:
        return slot
    async with _SLOTS_LOCK:
        slot = _SLOTS.get(tenant)
        if slot is None:
            slot = _TenantSlot(_tenant_limit(tenant))
            _SLOTS[tenant] = slot
        return slot


@asynccontextmanager
async def acquire(tenant_id: str | None) -> AsyncIterator[None]:
    """Acquire a bulkhead slot for ``tenant_id`` (or anonymous default)."""
    tenant = tenant_id or "_anonymous"
    slot = await _slot_for(tenant)
    slot.waiting += 1
    try:
        try:
            await asyncio.wait_for(slot.sem.acquire(), timeout=_DEFAULT_QUEUE_TIMEOUT)
        except asyncio.TimeoutError as exc:
            raise BulkheadError(
                f"bulkhead: tenant {tenant!r} queue timeout (limit={slot.limit})"
            ) from exc
    finally:
        slot.waiting -= 1
    slot.in_flight += 1
    try:
        yield
    finally:
        slot.in_flight -= 1
        slot.sem.release()


def stats() -> dict[str, dict[str, int]]:
    """Return per-tenant {in_flight, waiting, limit} for metric export."""
    return {
        t: {"in_flight": s.in_flight, "waiting": s.waiting, "limit": s.limit}
        for t, s in _SLOTS.items()
    }


def reset() -> None:
    """Test helper: drop all tenant slots."""
    _SLOTS.clear()
