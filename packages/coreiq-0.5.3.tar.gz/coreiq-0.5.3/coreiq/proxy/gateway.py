"""FastAPI router implementing OpenAI-compatible proxy endpoints.

Mounts at ``/v1`` and provides:
    - ``POST /v1/chat/completions`` — chat completion (streaming and non-streaming)
    - ``POST /v1/embeddings``       — embedding generation
    - ``GET  /v1/models``           — list registered providers/models

API key extraction follows the OpenAI convention:
    - ``Authorization: Bearer sk-...``
    - ``X-API-Key: sk-...`` (fallback)

Error responses use the OpenAI error format::

    {"error": {"message": "...", "type": "...", "code": "..."}}
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from .pipeline import (
    PipelineAuthError,
    PipelineBudgetError,
    PipelinePolicyError,
    PipelineProviderError,
    PipelineSecurityError,
    RequestPipeline,
)
from .providers.registry import ProviderRegistry

logger = logging.getLogger("coreiq.proxy.gateway")

router = APIRouter(prefix="/v1", tags=["proxy"])

# ---------------------------------------------------------------------------
# Module-level state — initialised by ``init_gateway()``.
# ---------------------------------------------------------------------------

_pipeline: Optional[RequestPipeline] = None
_registry: Optional[ProviderRegistry] = None


def init_gateway(
    *,
    registry: ProviderRegistry,
    pipeline: RequestPipeline,
) -> None:
    """Initialise the gateway with a provider registry and pipeline.

    Must be called at application startup before requests are served.
    """
    global _pipeline, _registry
    _pipeline = pipeline
    _registry = registry
    logger.info("Proxy gateway initialised with %d provider(s)", len(registry))


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class ChatMessage(BaseModel):
    role: str
    content: Optional[str | list] = None  # str for text, list for multimodal (vision)
    name: Optional[str] = None
    tool_calls: Optional[list[dict]] = None
    tool_call_id: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    """OpenAI-compatible chat completion request body."""

    model: str
    messages: list[ChatMessage]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stream: Optional[bool] = False
    tools: Optional[list[dict]] = None
    tool_choice: Optional[Any] = None
    response_format: Optional[dict] = None
    stop: Optional[Any] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    seed: Optional[int] = None
    user: Optional[str] = None
    n: Optional[int] = Field(default=None, ge=1)
    logprobs: Optional[bool] = None
    top_logprobs: Optional[int] = None


class ImageGenerationRequest(BaseModel):
    """OpenAI-compatible image generation request body."""
    model: str = "dall-e-3"
    prompt: str
    n: Optional[int] = 1
    size: Optional[str] = "1024x1024"
    quality: Optional[str] = "standard"
    style: Optional[str] = None
    response_format: Optional[str] = None
    user: Optional[str] = None


class AudioTranscriptionRequest(BaseModel):
    """Metadata for audio transcription (file sent as multipart)."""
    model: str = "whisper-1"
    language: Optional[str] = None
    prompt: Optional[str] = None
    response_format: Optional[str] = None
    temperature: Optional[float] = None


class TTSRequest(BaseModel):
    """OpenAI-compatible text-to-speech request body."""
    model: str = "tts-1"
    input: str
    voice: str = "alloy"
    response_format: Optional[str] = "mp3"
    speed: Optional[float] = 1.0


class EmbeddingRequest(BaseModel):
    """OpenAI-compatible embedding request body."""

    model: str
    input: str | list[str]
    encoding_format: Optional[str] = None   # "float" or "base64"
    dimensions: Optional[int] = None
    user: Optional[str] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_api_key(request: Request) -> Optional[str]:
    """Extract API key from Authorization: Bearer or X-API-Key header.

    JWTs (3 dot-separated parts) are skipped — auth middleware validates those.
    Falls back to X-API-Key header.
    """
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        token = auth[7:].strip()
        # JWTs have 3 dot-separated parts; API keys don't — skip JWTs
        if token.count(".") >= 2:
            return request.headers.get("x-api-key")
        return token
    return request.headers.get("x-api-key")


def _openai_error(message: str, error_type: str, code: str, status_code: int) -> JSONResponse:
    """Return an error response in OpenAI error format."""
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "message": message,
                "type": error_type,
                "code": code,
            }
        },
    )


def _auth_ok(api_key: Optional[str]) -> bool:
    """Check if the provided API key is valid (master key or virtual key)."""
    import hmac as _hmac
    if not api_key:
        return False
    if _pipeline is not None and _pipeline._api_key:
        if _hmac.compare_digest(api_key, _pipeline._api_key):
            return True
    if _pipeline is not None and _pipeline._key_manager is not None:
        if api_key.startswith("sk-coreiq-") and _pipeline._key_manager.validate_key(api_key) is not None:
            return True
    return False


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/chat/completions")
async def chat_completions(body: ChatCompletionRequest, request: Request):
    """OpenAI-compatible chat completion endpoint.

    Supports both streaming (``stream: true``) and non-streaming requests.
    """
    if _pipeline is None:
        return _openai_error(
            "Proxy gateway not initialised. No providers configured.",
            "server_error",
            "gateway_not_ready",
            503,
        )

    api_key = _extract_api_key(request)
    messages = [m.model_dump(exclude_none=True) for m in body.messages]
    episode_id = request.headers.get("X-Episode-ID")

    try:
        result = await _pipeline.process(
            model=body.model,
            messages=messages,
            stream=body.stream or False,
            api_key=api_key,
            temperature=body.temperature,
            max_tokens=body.max_tokens,
            top_p=body.top_p,
            tools=body.tools,
            tool_choice=body.tool_choice,
            response_format=body.response_format,
            stop=body.stop,
            frequency_penalty=body.frequency_penalty,
            presence_penalty=body.presence_penalty,
            seed=body.seed,
            user=body.user,
            n=body.n,
            logprobs=body.logprobs,
            top_logprobs=body.top_logprobs,
            episode_id=episode_id,
        )

    except PipelineAuthError as exc:
        return _openai_error(str(exc), "authentication_error", "invalid_api_key", 401)

    except PipelineSecurityError as exc:
        return _openai_error(str(exc), "invalid_request_error", "content_policy_violation", 400)

    except PipelinePolicyError as exc:
        return _openai_error(str(exc), "permission_error", "policy_denied", 403)

    except PipelineBudgetError as exc:
        return _openai_error(str(exc), "rate_limit_error", "budget_exceeded", 429)

    except PipelineProviderError as exc:
        return _openai_error(str(exc), "server_error", "provider_error", exc.status_code)

    except Exception as exc:
        logger.error("Unhandled pipeline error: %s", exc, exc_info=True)
        return _openai_error(
            "Internal server error",
            "server_error",
            "internal_error",
            500,
        )

    # Streaming response.
    if body.stream:
        return StreamingResponse(
            result,
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    # Non-streaming response.
    return JSONResponse(content=result)


@router.get("/models")
async def list_models():
    """List available models/providers."""
    if _registry is None:
        return _openai_error(
            "Proxy gateway not initialised.",
            "server_error",
            "gateway_not_ready",
            503,
        )

    providers = _registry.list_models()
    models_data = []
    for p in providers:
        models_data.append({
            "id": p["provider"],
            "object": "model",
            "created": 0,
            "owned_by": p["provider"],
            "permission": [],
            "root": p["provider"],
            "parent": None,
            "_coreiq": {
                "class": p["class"],
                "api_base": p["api_base"],
                "environment_valid": p["environment_valid"],
            },
        })

    return JSONResponse(content={
        "object": "list",
        "data": models_data,
    })


@router.post("/embeddings")
async def embeddings(body: EmbeddingRequest, request: Request):
    """OpenAI-compatible embeddings endpoint.

    Resolves the provider via the registry, forwards the request to the
    provider's embedding endpoint, tracks cost, and returns the response
    in OpenAI-compatible format.
    """
    if _pipeline is None or _registry is None:
        return _openai_error(
            "Proxy gateway not initialised. No providers configured.",
            "server_error",
            "gateway_not_ready",
            503,
        )

    import time as _time
    import uuid as _uuid
    import httpx


    api_key = _extract_api_key(request)

    # --- Auth ---
    if _pipeline._api_key is not None and _pipeline._api_key != "":
        import hmac as _hmac
        if not api_key:
            return _openai_error(
                "Missing API key. Provide via Authorization: Bearer <key> or X-API-Key header.",
                "authentication_error",
                "invalid_api_key",
                401,
            )
        if not _hmac.compare_digest(api_key, _pipeline._api_key):
            # Check virtual key if applicable
            if not (
                _pipeline._key_manager is not None
                and api_key.startswith("sk-coreiq-")
                and _pipeline._key_manager.validate_key(api_key) is not None
            ):
                return _openai_error("Invalid API key.", "authentication_error", "invalid_api_key", 401)

    # --- Resolve provider ---
    try:
        provider, bare_model = _registry.resolve(body.model)
    except Exception as exc:
        return _openai_error(
            f"Cannot resolve model {body.model!r}: {exc}",
            "invalid_request_error",
            "model_not_found",
            400,
        )

    # --- Build embedding request body ---
    embed_body: dict[str, Any] = {
        "model": bare_model,
        "input": body.input,
    }
    if body.encoding_format is not None:
        embed_body["encoding_format"] = body.encoding_format
    if body.dimensions is not None:
        embed_body["dimensions"] = body.dimensions
    if body.user is not None:
        embed_body["user"] = body.user

    # --- Transform and send ---
    try:
        if hasattr(provider, "transform_embedding_request"):
            url, headers, embed_body = provider.transform_embedding_request(embed_body)
        else:
            # Fallback: use provider's API base + /embeddings
            api_base = provider.get_api_base()
            url = f"{api_base}/embeddings"
            # Build headers from provider
            headers = {"Content-Type": "application/json"}
            if hasattr(provider, "api_key") and provider.api_key:
                headers["Authorization"] = f"Bearer {provider.api_key}"

        start = _time.monotonic()
        timeout = httpx.Timeout(connect=10.0, read=120.0, write=10.0, pool=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, headers=headers, json=embed_body)

        latency_ms = int((_time.monotonic() - start) * 1000)

        if resp.status_code >= 400:
            return _openai_error(
                f"Provider error ({resp.status_code}): {resp.text[:500]}",
                "server_error",
                "provider_error",
                resp.status_code,
            )

        raw_response = resp.json()

        # --- Transform response ---
        if hasattr(provider, "transform_embedding_response"):
            result = provider.transform_embedding_response(raw_response)
        else:
            result = raw_response

        # --- Track cost ---
        try:
            usage = result.get("usage", {})
            total_tokens = usage.get("total_tokens", usage.get("prompt_tokens", 0))
            cost_calc = _pipeline._cost
            cost = cost_calc.calculate(
                model=bare_model,
                provider=provider.provider_name,
                input_tokens=total_tokens,
                output_tokens=0,
            )
            # Write trace for observability
            try:
                writer = _pipeline._get_writer()
                request_id = f"embd-{_uuid.uuid4().hex[:24]}"
                writer.insert_trace(
                    id=request_id,
                    model=body.model,
                    provider=provider.provider_name,
                    input_tok=total_tokens,
                    output_tok=0,
                    latency_ms=latency_ms,
                    finish_reason="stop",
                    cache_hit=False,
                    meta_json='{"type": "embedding", "cost_usd": ' + str(cost.total_cost) + '}',
                    user_id=body.user,
                )
            except Exception:
                pass
        except Exception as exc:
            logger.debug("Embedding cost calculation failed: %s", exc)

        return JSONResponse(content=result)

    except httpx.TimeoutException:
        return _openai_error(
            "Provider timed out",
            "server_error",
            "timeout",
            504,
        )
    except Exception as exc:
        logger.error("Embedding endpoint error: %s", exc, exc_info=True)
        return _openai_error(
            "Internal server error",
            "server_error",
            "internal_error",
            500,
        )


# ---------------------------------------------------------------------------
# Image generation
# ---------------------------------------------------------------------------


@router.post("/images/generations")
async def image_generations(body: ImageGenerationRequest, request: Request):
    """OpenAI-compatible image generation endpoint (DALL-E)."""
    if _pipeline is None or _registry is None:
        return _openai_error("Gateway not initialised.", "server_error", "gateway_not_ready", 503)

    import time as _time
    import uuid as _uuid
    import httpx

    api_key = _extract_api_key(request)
    if _pipeline._api_key and not _auth_ok(api_key):
        return _openai_error("Invalid API key.", "authentication_error", "invalid_api_key", 401)

    try:
        provider, bare_model = _registry.resolve(body.model)
    except Exception as exc:
        return _openai_error(f"Cannot resolve model {body.model!r}: {exc}", "invalid_request_error", "model_not_found", 400)

    img_body: dict[str, Any] = {"model": body.model, "prompt": body.prompt}
    if body.n is not None:
        img_body["n"] = body.n
    if body.size is not None:
        img_body["size"] = body.size
    if body.quality is not None:
        img_body["quality"] = body.quality
    if body.style is not None:
        img_body["style"] = body.style
    if body.response_format is not None:
        img_body["response_format"] = body.response_format
    if body.user is not None:
        img_body["user"] = body.user

    try:
        api_base = provider.get_api_base()
        url = f"{api_base}/images/generations"
        headers = {"Content-Type": "application/json"}
        if hasattr(provider, "api_key") and provider.api_key:
            headers["Authorization"] = f"Bearer {provider.api_key}"

        start = _time.monotonic()
        timeout = httpx.Timeout(connect=10.0, read=120.0, write=10.0, pool=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, headers=headers, json=img_body)
        latency_ms = int((_time.monotonic() - start) * 1000)

        if resp.status_code >= 400:
            return _openai_error(f"Provider error ({resp.status_code}): {resp.text[:500]}", "server_error", "provider_error", resp.status_code)

        result = resp.json()

        # Track cost
        try:
            _IMAGE_COST = {
                ("dall-e-3", "standard", "1024x1024"): 0.040, ("dall-e-3", "standard", "1024x1792"): 0.080,
                ("dall-e-3", "standard", "1792x1024"): 0.080, ("dall-e-3", "hd", "1024x1024"): 0.080,
                ("dall-e-3", "hd", "1024x1792"): 0.120, ("dall-e-3", "hd", "1792x1024"): 0.120,
                ("dall-e-2", "standard", "256x256"): 0.016, ("dall-e-2", "standard", "512x512"): 0.018,
                ("dall-e-2", "standard", "1024x1024"): 0.020,
            }
            per_image = _IMAGE_COST.get((bare_model, body.quality or "standard", body.size or "1024x1024"), 0.040)
            cost_usd = per_image * (body.n or 1)
            writer = _pipeline._get_writer()
            writer.insert_trace(
                id=f"img-{_uuid.uuid4().hex[:24]}",
                model=body.model, provider=provider.provider_name,
                input_tok=0, output_tok=0, latency_ms=latency_ms,
                finish_reason="stop", cache_hit=False,
                meta_json=f'{{"type":"image_generation","cost_usd":{cost_usd},"n":{body.n or 1},"size":"{body.size}"}}',
                user_id=body.user,
            )
        except Exception:
            pass

        return JSONResponse(content=result)
    except httpx.TimeoutException:
        return _openai_error("Provider timed out", "server_error", "timeout", 504)
    except Exception as exc:
        logger.error("Image generation error: %s", exc, exc_info=True)
        return _openai_error("Internal server error", "server_error", "internal_error", 500)


# ---------------------------------------------------------------------------
# Audio transcription (Whisper)
# ---------------------------------------------------------------------------


@router.post("/audio/transcriptions")
async def audio_transcriptions(request: Request):
    """OpenAI-compatible audio transcription endpoint."""
    if _pipeline is None or _registry is None:
        return _openai_error("Gateway not initialised.", "server_error", "gateway_not_ready", 503)

    import time as _time
    import uuid as _uuid
    import httpx

    api_key = _extract_api_key(request)
    if _pipeline._api_key and not _auth_ok(api_key):
        return _openai_error("Invalid API key.", "authentication_error", "invalid_api_key", 401)

    # Parse multipart form
    form = await request.form()
    audio_file = form.get("file")
    model = form.get("model", "whisper-1")
    language = form.get("language")
    prompt = form.get("prompt")
    response_format = form.get("response_format")
    temperature = form.get("temperature")

    if audio_file is None:
        return _openai_error("Missing 'file' in form data.", "invalid_request_error", "missing_file", 400)

    try:
        provider, bare_model = _registry.resolve(str(model))
    except Exception as exc:
        return _openai_error(f"Cannot resolve model {model!r}: {exc}", "invalid_request_error", "model_not_found", 400)

    try:
        api_base = provider.get_api_base()
        url = f"{api_base}/audio/transcriptions"
        headers: dict[str, str] = {}
        if hasattr(provider, "api_key") and provider.api_key:
            headers["Authorization"] = f"Bearer {provider.api_key}"

        # Build multipart form for upstream — use original model string
        # (providers like LiteLLM expect the full "openai/whisper-large-v3" name)
        file_content = await audio_file.read()
        fname = audio_file.filename or "audio.wav"
        # Infer content type from filename if not provided
        ctype = audio_file.content_type
        if not ctype or ctype == "application/octet-stream":
            ext = fname.rsplit(".", 1)[-1].lower() if "." in fname else "wav"
            ctype = {"wav": "audio/wav", "mp3": "audio/mpeg", "m4a": "audio/mp4", "ogg": "audio/ogg", "flac": "audio/flac", "webm": "audio/webm"}.get(ext, "audio/wav")
        files = {"file": (fname, file_content, ctype)}
        form_data: dict[str, str] = {"model": str(model)}
        if language:
            form_data["language"] = str(language)
        if prompt:
            form_data["prompt"] = str(prompt)
        if response_format:
            form_data["response_format"] = str(response_format)
        if temperature:
            form_data["temperature"] = str(temperature)

        start = _time.monotonic()
        timeout = httpx.Timeout(connect=10.0, read=300.0, write=30.0, pool=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, headers=headers, files=files, data=form_data)
        latency_ms = int((_time.monotonic() - start) * 1000)

        if resp.status_code >= 400:
            return _openai_error(f"Provider error ({resp.status_code}): {resp.text[:500]}", "server_error", "provider_error", resp.status_code)

        # Cost: $0.006/minute for Whisper
        try:
            result = resp.json()
            duration = result.get("duration", 0)
            cost_usd = (duration / 60.0) * 0.006
            writer = _pipeline._get_writer()
            writer.insert_trace(
                id=f"stt-{_uuid.uuid4().hex[:24]}",
                model=str(model), provider=provider.provider_name,
                input_tok=0, output_tok=0, latency_ms=latency_ms,
                finish_reason="stop", cache_hit=False,
                meta_json=f'{{"type":"audio_transcription","cost_usd":{cost_usd},"duration_sec":{duration}}}',
            )
            return JSONResponse(content=result)
        except Exception:
            # If response isn't JSON (e.g. text format), return as-is
            return JSONResponse(content={"text": resp.text})

    except httpx.TimeoutException:
        return _openai_error("Provider timed out", "server_error", "timeout", 504)
    except Exception as exc:
        logger.error("Audio transcription error: %s", exc, exc_info=True)
        return _openai_error("Internal server error", "server_error", "internal_error", 500)


# ---------------------------------------------------------------------------
# Text-to-speech
# ---------------------------------------------------------------------------


@router.post("/audio/speech")
async def audio_speech(body: TTSRequest, request: Request):
    """OpenAI-compatible text-to-speech endpoint."""
    if _pipeline is None or _registry is None:
        return _openai_error("Gateway not initialised.", "server_error", "gateway_not_ready", 503)

    import time as _time
    import uuid as _uuid
    import httpx

    api_key = _extract_api_key(request)
    if _pipeline._api_key and not _auth_ok(api_key):
        return _openai_error("Invalid API key.", "authentication_error", "invalid_api_key", 401)

    try:
        provider, bare_model = _registry.resolve(body.model)
    except Exception as exc:
        return _openai_error(f"Cannot resolve model {body.model!r}: {exc}", "invalid_request_error", "model_not_found", 400)

    tts_body: dict[str, Any] = {
        "model": body.model, "input": body.input, "voice": body.voice,
    }
    if body.response_format:
        tts_body["response_format"] = body.response_format
    if body.speed and body.speed != 1.0:
        tts_body["speed"] = body.speed

    try:
        api_base = provider.get_api_base()
        url = f"{api_base}/audio/speech"
        headers = {"Content-Type": "application/json"}
        if hasattr(provider, "api_key") and provider.api_key:
            headers["Authorization"] = f"Bearer {provider.api_key}"

        start = _time.monotonic()
        timeout = httpx.Timeout(connect=10.0, read=120.0, write=10.0, pool=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, headers=headers, json=tts_body)
        latency_ms = int((_time.monotonic() - start) * 1000)

        if resp.status_code >= 400:
            return _openai_error(f"Provider error ({resp.status_code}): {resp.text[:500]}", "server_error", "provider_error", resp.status_code)

        # Cost: tts-1 = $0.015/1K chars, tts-1-hd = $0.030/1K chars
        try:
            rate = 0.030 if "hd" in bare_model else 0.015
            cost_usd = (len(body.input) / 1000.0) * rate
            writer = _pipeline._get_writer()
            writer.insert_trace(
                id=f"tts-{_uuid.uuid4().hex[:24]}",
                model=body.model, provider=provider.provider_name,
                input_tok=len(body.input), output_tok=0, latency_ms=latency_ms,
                finish_reason="stop", cache_hit=False,
                meta_json=f'{{"type":"tts","cost_usd":{cost_usd},"chars":{len(body.input)}}}',
            )
        except Exception:
            pass

        # Return binary audio
        fmt = body.response_format or "mp3"
        content_type = {"mp3": "audio/mpeg", "opus": "audio/opus", "aac": "audio/aac", "flac": "audio/flac", "wav": "audio/wav", "pcm": "audio/pcm"}.get(fmt, "audio/mpeg")
        from fastapi.responses import Response
        return Response(content=resp.content, media_type=content_type)

    except httpx.TimeoutException:
        return _openai_error("Provider timed out", "server_error", "timeout", 504)
    except Exception as exc:
        logger.error("TTS error: %s", exc, exc_info=True)
        return _openai_error("Internal server error", "server_error", "internal_error", 500)
