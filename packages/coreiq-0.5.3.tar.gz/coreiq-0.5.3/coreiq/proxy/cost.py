"""Cost calculator for LLM inference.

Provides per-model pricing and calculates the cost of each inference
based on input and output token counts.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class CostResult:
    """Result of a cost calculation.

    The ``cached_input_*`` fields are populated when the provider reports
    that some portion of the input was served from a prompt cache (e.g.
    Anthropic ``cache_read_input_tokens``, OpenAI
    ``prompt_tokens_details.cached_tokens``, Gemini
    ``cachedContentTokenCount``). When the provider does not report
    cached usage they default to zero and the calculation degrades to
    the legacy single-tier behavior.
    """

    input_cost: float
    output_cost: float
    total_cost: float
    model: str
    provider: str
    # Token-level breakdown
    input_tokens: int = 0
    output_tokens: int = 0
    cached_input_tokens: int = 0
    cached_input_cost: float = 0.0


# ---------------------------------------------------------------------------
# Pricing database (USD per 1 million tokens)
# ---------------------------------------------------------------------------

# {provider: {model_pattern: (input_per_1m, output_per_1m)}}
_PRICING: dict[str, dict[str, tuple[float, float]]] = {
    "openai": {
        "gpt-4o": (2.50, 10.00),
        "gpt-4o-2024-11-20": (2.50, 10.00),
        "gpt-4o-2024-08-06": (2.50, 10.00),
        "gpt-4o-mini": (0.15, 0.60),
        "gpt-4o-mini-2024-07-18": (0.15, 0.60),
        "gpt-4-turbo": (10.00, 30.00),
        "gpt-4-turbo-2024-04-09": (10.00, 30.00),
        "gpt-4": (30.00, 60.00),
        "gpt-4-32k": (60.00, 120.00),
        "gpt-3.5-turbo": (0.50, 1.50),
        "gpt-3.5-turbo-0125": (0.50, 1.50),
        "o1": (15.00, 60.00),
        "o1-mini": (3.00, 12.00),
        "o1-preview": (15.00, 60.00),
        "o3": (10.00, 40.00),
        "o3-mini": (1.10, 4.40),
        "o4-mini": (1.10, 4.40),
    },
    "anthropic": {
        "claude-sonnet-4-6": (3.00, 15.00),
        "claude-sonnet-4-20250514": (3.00, 15.00),
        "claude-opus-4-6": (15.00, 75.00),
        "claude-opus-4-20250514": (15.00, 75.00),
        "claude-3-5-sonnet-20241022": (3.00, 15.00),
        "claude-3-5-sonnet-latest": (3.00, 15.00),
        "claude-3-5-haiku-20241022": (0.80, 4.00),
        "claude-3-5-haiku-latest": (0.80, 4.00),
        "claude-3-opus-20240229": (15.00, 75.00),
        "claude-3-sonnet-20240229": (3.00, 15.00),
        "claude-3-haiku-20240307": (0.25, 1.25),
    },
    "google": {
        "gemini-2.0-flash": (0.10, 0.40),
        "gemini-2.0-flash-lite": (0.075, 0.30),
        "gemini-1.5-pro": (1.25, 5.00),
        "gemini-1.5-flash": (0.075, 0.30),
        "gemini-1.5-flash-8b": (0.0375, 0.15),
        "gemini-1.0-pro": (0.50, 1.50),
    },
    "mistral": {
        "mistral-large-latest": (2.00, 6.00),
        "mistral-medium-latest": (2.70, 8.10),
        "mistral-small-latest": (0.20, 0.60),
        "codestral-latest": (0.30, 0.90),
        "open-mistral-nemo": (0.15, 0.15),
    },
    "groq": {
        "llama-3.3-70b-versatile": (0.59, 0.79),
        "llama-3.1-8b-instant": (0.05, 0.08),
        "mixtral-8x7b-32768": (0.24, 0.24),
        "gemma2-9b-it": (0.20, 0.20),
    },
    "together": {
        "meta-llama/Llama-3.3-70B-Instruct-Turbo": (0.88, 0.88),
        "meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo": (0.18, 0.18),
        "meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo": (3.50, 3.50),
        "mistralai/Mixtral-8x7B-Instruct-v0.1": (0.60, 0.60),
    },
    "cohere": {
        "command-r-plus": (2.50, 10.00),
        "command-r": (0.15, 0.60),
        "command-light": (0.30, 0.60),
    },
    "deepseek": {
        "deepseek-chat": (0.14, 0.28),
        "deepseek-coder": (0.14, 0.28),
        "deepseek-reasoner": (0.55, 2.19),
    },
    "bedrock": {
        # Claude models via Bedrock (slightly higher than direct API)
        "claude-sonnet-4-6": (3.00, 15.00),
        "anthropic.claude-sonnet-4-6-v1": (3.00, 15.00),
        "claude-haiku-4-5": (1.00, 5.00),
        "anthropic.claude-haiku-4-5-20251001-v1:0": (1.00, 5.00),
        "claude-3-5-sonnet-latest": (3.00, 15.00),
        "anthropic.claude-3-5-sonnet-20241022-v2:0": (3.00, 15.00),
        "claude-3-5-haiku-latest": (1.00, 5.00),
        "anthropic.claude-3-5-haiku-20241022-v1:0": (1.00, 5.00),
        "claude-3-opus-20240229": (15.00, 75.00),
        "anthropic.claude-3-opus-20240229-v1:0": (15.00, 75.00),
        "claude-3-haiku-20240307": (0.25, 1.25),
        "anthropic.claude-3-haiku-20240307-v1:0": (0.25, 1.25),
        # Llama models via Bedrock
        "llama3-70b": (2.65, 3.50),
        "meta.llama3-70b-instruct-v1:0": (2.65, 3.50),
        "llama3-8b": (0.30, 0.60),
        "meta.llama3-8b-instruct-v1:0": (0.30, 0.60),
        # Mistral models via Bedrock
        "mistral-large": (4.00, 12.00),
        "mistral.mistral-large-2407-v1:0": (4.00, 12.00),
        # Amazon Titan models
        "titan-premier": (0.50, 1.50),
        "amazon.titan-text-premier-v2:0": (0.50, 1.50),
        "titan-express": (0.20, 0.60),
        "amazon.titan-text-express-v1": (0.20, 0.60),
        "titan-lite": (0.15, 0.20),
        "amazon.titan-text-lite-v1": (0.15, 0.20),
    },
}

# Embedding model pricing (USD per 1M tokens) — input only.
_EMBEDDING_PRICING: dict[str, dict[str, float]] = {
    "openai": {
        "text-embedding-3-small": 0.02,
        "text-embedding-3-large": 0.13,
        "text-embedding-ada-002": 0.10,
    },
    "cohere": {
        "embed-english-v3.0": 0.10,
        "embed-multilingual-v3.0": 0.10,
        "embed-english-light-v3.0": 0.10,
        "embed-multilingual-light-v3.0": 0.10,
    },
    "mistral": {
        "mistral-embed": 0.10,
    },
    "together": {
        "togethercomputer/m2-bert-80M-8k-retrieval": 0.008,
    },
}

# Conservative fallback for unknown models (USD per 1M tokens).
_FALLBACK_PRICING: tuple[float, float] = (5.00, 15.00)


# ---------------------------------------------------------------------------
# Prompt-cache pricing tiers (USD per 1M cached input tokens)
# ---------------------------------------------------------------------------
#
# When a provider serves part of the input from its prompt cache, the
# cached portion is billed at a discounted rate. The discount factors
# vary by provider:
#
#   Anthropic: 10% of base input rate (10× cheaper)
#       https://docs.anthropic.com/en/docs/build-with-claude/prompt-caching
#   OpenAI:    50% of base input rate (2× cheaper)
#       https://platform.openai.com/docs/guides/prompt-caching
#   Gemini:    25% of base input rate (4× cheaper)
#       https://ai.google.dev/gemini-api/docs/caching
#
# We store the discount factor (multiplier on the base input rate)
# rather than absolute prices, so adding a new model only requires
# updating ``_PRICING`` and not a parallel cached-pricing table.
_CACHED_INPUT_DISCOUNT: dict[str, float] = {
    "anthropic": 0.10,
    "openai": 0.50,
    "google": 0.25,
    # Bedrock claude routes through Anthropic's pricing tier
    "bedrock": 0.10,
}


class CostCalculator:
    """Calculates inference cost based on model and token counts.

    Lookup order:
        1. Exact ``(provider, model)`` match in the pricing table.
        2. Prefix match — e.g. ``gpt-4o-2024-*`` falls back to ``gpt-4o``.
        3. Conservative fallback estimate.
    """

    def __init__(
        self,
        *,
        custom_pricing: Optional[dict[str, dict[str, tuple[float, float]]]] = None,
    ) -> None:
        # Merge custom pricing on top of defaults.
        self._pricing: dict[str, dict[str, tuple[float, float]]] = {}
        for provider, models in _PRICING.items():
            self._pricing[provider] = dict(models)
        if custom_pricing:
            for provider, models in custom_pricing.items():
                if provider not in self._pricing:
                    self._pricing[provider] = {}
                self._pricing[provider].update(models)

    def _lookup(self, provider: str, model: str) -> tuple[float, float]:
        """Return (input_per_1m, output_per_1m) for a model."""
        provider = provider.lower()
        models = self._pricing.get(provider, {})

        # Exact match.
        if model in models:
            return models[model]

        # Prefix match: find the longest matching prefix.
        best_match: Optional[str] = None
        best_len = 0
        for known_model in models:
            if model.startswith(known_model) and len(known_model) > best_len:
                best_match = known_model
                best_len = len(known_model)
        if best_match:
            return models[best_match]

        # Reverse prefix match: known model starts with given model.
        for known_model in models:
            if known_model.startswith(model):
                return models[known_model]

        return _FALLBACK_PRICING

    def calculate(
        self,
        model: str,
        provider: str,
        input_tokens: int,
        output_tokens: int,
        cached_input_tokens: int = 0,
    ) -> CostResult:
        """Calculate the cost of an inference.

        Args:
            model: The model name (without provider prefix).
            provider: The provider name (e.g. "openai", "anthropic").
            input_tokens: Total prompt/input tokens (INCLUDING any cached
                portion — provider usage reports always include cached
                tokens in their input total).
            output_tokens: Number of completion/output tokens.
            cached_input_tokens: Of the ``input_tokens``, how many were
                served from the provider's prompt cache. Defaults to 0 to
                preserve backward compatibility with callers that don't
                pass cached usage. The cached portion is billed at the
                provider's cached rate; the remainder bills at the
                normal input rate.

        Returns:
            A CostResult with itemised costs in USD, including
            ``cached_input_tokens`` and ``cached_input_cost`` so dashboards
            can show the breakdown.
        """
        input_per_1m, output_per_1m = self._lookup(provider, model)

        # Defensive clamp — providers should never report more cached
        # tokens than total input, but if they do we treat the excess
        # as uncached so the math doesn't go negative.
        cached = max(0, min(cached_input_tokens, input_tokens))
        uncached = input_tokens - cached

        cached_per_1m = input_per_1m * _CACHED_INPUT_DISCOUNT.get(
            provider.lower(), 1.0
        )
        cached_cost = (cached / 1_000_000) * cached_per_1m
        uncached_cost = (uncached / 1_000_000) * input_per_1m
        input_cost = uncached_cost + cached_cost
        output_cost = (output_tokens / 1_000_000) * output_per_1m

        return CostResult(
            input_cost=round(input_cost, 8),
            output_cost=round(output_cost, 8),
            total_cost=round(input_cost + output_cost, 8),
            model=model,
            provider=provider,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_input_tokens=cached,
            cached_input_cost=round(cached_cost, 8),
        )
