"""Model Fingerprinting — verify which model actually served a response.

Detects if a provider is silently routing to a cheaper model than advertised.
Uses response characteristic analysis.
"""
from __future__ import annotations
import logging
import re
import statistics
from dataclasses import dataclass, field
from typing import Any, Dict, List
logger = logging.getLogger(__name__)

@dataclass
class FingerprintProfile:
    model: str
    avg_tokens_per_sentence: float = 0
    vocabulary_richness: float = 0
    avg_response_length: int = 0
    formatting_patterns: Dict[str, int] = field(default_factory=dict)
    sample_count: int = 0
    def to_dict(self) -> Dict[str, Any]:
        return {"model": self.model, "avg_tokens_per_sentence": round(self.avg_tokens_per_sentence, 2),
                "vocabulary_richness": round(self.vocabulary_richness, 4),
                "avg_response_length": self.avg_response_length,
                "sample_count": self.sample_count}

@dataclass
class FingerprintResult:
    claimed_model: str
    likely_model: str
    confidence: float
    match: bool
    characteristics: Dict[str, float] = field(default_factory=dict)
    def to_dict(self) -> Dict[str, Any]:
        return {"claimed_model": self.claimed_model, "likely_model": self.likely_model,
                "confidence": round(self.confidence, 3), "match": self.match,
                "characteristics": {k: round(v, 3) for k, v in self.characteristics.items()}}

class ModelFingerprinter:
    def __init__(self):
        self._profiles: Dict[str, FingerprintProfile] = {}
        self._response_data: Dict[str, List[str]] = {}  # model -> responses

    def add_sample(self, model: str, response: str) -> None:
        self._response_data.setdefault(model, []).append(response)
        self._rebuild_profile(model)

    def _rebuild_profile(self, model: str) -> None:
        responses = self._response_data.get(model, [])
        if not responses:
            return
        all_words = []
        sentence_lengths = []
        for resp in responses:
            words = resp.split()
            all_words.extend(words)
            sentences = re.split(r'[.!?]+', resp)
            for s in sentences:
                sw = s.split()
                if sw:
                    sentence_lengths.append(len(sw))
        unique_words = len(set(w.lower() for w in all_words))
        total_words = len(all_words) or 1
        self._profiles[model] = FingerprintProfile(
            model=model,
            avg_tokens_per_sentence=statistics.mean(sentence_lengths) if sentence_lengths else 0,
            vocabulary_richness=unique_words / total_words,
            avg_response_length=int(statistics.mean(len(r) for r in responses)),
            sample_count=len(responses))

    def verify(self, claimed_model: str, response: str) -> FingerprintResult:
        words = response.split()
        sentences = re.split(r'[.!?]+', response)
        sent_lens = [len(s.split()) for s in sentences if s.split()]
        unique = len(set(w.lower() for w in words))
        total = len(words) or 1
        chars = {
            "tokens_per_sentence": statistics.mean(sent_lens) if sent_lens else 0,
            "vocabulary_richness": unique / total,
            "response_length": len(response),
        }
        claimed_profile = self._profiles.get(claimed_model)
        if not claimed_profile or claimed_profile.sample_count < 3:
            return FingerprintResult(claimed_model=claimed_model, likely_model=claimed_model,
                confidence=0.5, match=True, characteristics=chars)
        # Compare to claimed profile
        diffs = []
        if claimed_profile.avg_tokens_per_sentence > 0:
            diffs.append(abs(chars["tokens_per_sentence"] - claimed_profile.avg_tokens_per_sentence) / claimed_profile.avg_tokens_per_sentence)
        if claimed_profile.vocabulary_richness > 0:
            diffs.append(abs(chars["vocabulary_richness"] - claimed_profile.vocabulary_richness) / claimed_profile.vocabulary_richness)
        avg_diff = sum(diffs) / len(diffs) if diffs else 0
        confidence = max(0, 1.0 - avg_diff)
        match = confidence > 0.6
        # Find best matching profile
        best_model = claimed_model
        best_conf = confidence
        for model, profile in self._profiles.items():
            if model == claimed_model:
                continue
            d = []
            if profile.avg_tokens_per_sentence > 0:
                d.append(abs(chars["tokens_per_sentence"] - profile.avg_tokens_per_sentence) / profile.avg_tokens_per_sentence)
            if profile.vocabulary_richness > 0:
                d.append(abs(chars["vocabulary_richness"] - profile.vocabulary_richness) / profile.vocabulary_richness)
            conf = max(0, 1.0 - (sum(d) / len(d) if d else 1))
            if conf > best_conf:
                best_model = model
                best_conf = conf
        return FingerprintResult(claimed_model=claimed_model, likely_model=best_model,
            confidence=confidence, match=match, characteristics=chars)

    def get_profiles(self) -> List[Dict[str, Any]]:
        return [p.to_dict() for p in self._profiles.values()]
