"""Policy-driven canary traffic-weight router.

Decides — at request time — whether a tenant should be routed to the
``current`` model or a ``candidate`` model based on the canary traffic
weight stored on the active ``CanaryDeployment``. Cohort assignment is
sticky per ``(deployment_id, tenant_id)`` so the same tenant always
sees the same variant during the canary window.

Sticky storage:
- Redis (`coreiq.cache.RedisCoordinator`) when configured — survives
  restarts and is shared across replicas.
- In-memory dict otherwise — fine for single-replica dev.

Every routing decision adds an OTel span attribute
``coreiq.canary.weight`` so traffic splits are observable in the
collector without bespoke dashboard work.
"""
from __future__ import annotations

import hashlib
import logging
from typing import Optional

from coreiq.cache import get_coordinator

logger = logging.getLogger("coreiq.proxy.canary_router")

_LOCAL_COHORTS: dict[tuple[str, str], str] = {}


def _stable_hash(deployment_id: str, tenant_id: str) -> int:
    """Deterministic 0..999 bucket from (deployment_id, tenant_id)."""
    raw = f"{deployment_id}:{tenant_id}".encode("utf-8")
    digest = hashlib.sha256(raw).digest()
    return int.from_bytes(digest[:4], "big") % 1000


def assign_variant(
    deployment_id: str,
    tenant_id: str,
    traffic_pct: float,
    *,
    current: str,
    candidate: str,
) -> tuple[str, float]:
    """Return ``(model_to_use, weight_seen)`` for this request.

    ``weight_seen`` is the candidate weight (0.0..1.0) for the
    deployment, suitable for emitting as an OTel attribute.
    """
    weight = max(0.0, min(traffic_pct / 100.0, 1.0))
    coord = get_coordinator()
    cohort_key = f"{deployment_id}:{tenant_id}"
    existing: Optional[str] = None
    if coord is not None:
        existing = coord.cohort_get(cohort_key)
    else:
        existing = _LOCAL_COHORTS.get((deployment_id, tenant_id))
    if existing in (current, candidate):
        return existing, weight

    bucket = _stable_hash(deployment_id, tenant_id)
    threshold = int(weight * 1000)
    chosen = candidate if bucket < threshold else current

    if coord is not None:
        coord.cohort_set(cohort_key, chosen)
    else:
        _LOCAL_COHORTS[(deployment_id, tenant_id)] = chosen

    logger.debug(
        "canary: deployment=%s tenant=%s weight=%.3f bucket=%d → %s",
        deployment_id, tenant_id, weight, bucket, chosen,
    )
    return chosen, weight


def reset_local() -> None:
    """Test helper: clear in-memory cohort table."""
    _LOCAL_COHORTS.clear()
