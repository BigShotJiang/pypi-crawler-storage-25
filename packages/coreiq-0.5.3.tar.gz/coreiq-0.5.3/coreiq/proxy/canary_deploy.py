"""Canary Deployments for Models — route traffic % to candidate, auto-promote/rollback.

State is persisted to the ``canary_deployments`` table so deployments survive
server restarts and score history is never lost.

Usage::

    canary = CanaryDeploymentEngine()
    canary.create_deployment(current="gpt-4o", candidate="gpt-4o-mini",
        traffic_pct=5, eval_metrics=["quality"], promote_threshold=0.95)
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class CanaryStatus(str, Enum):
    active = "active"
    promoted = "promoted"
    rolled_back = "rolled_back"


def _db():
    from ..store.db import get_shared_connection
    return get_shared_connection()


def _loads(s: str) -> Any:
    try:
        return json.loads(s) if isinstance(s, str) else s
    except (json.JSONDecodeError, TypeError):
        return {}


class CanaryDeployment:
    """Thin wrapper that reads/writes directly from a DB row dict."""

    def __init__(self, row: Dict[str, Any]):
        self._r = row

    @property
    def id(self) -> str:
        return self._r["id"]

    @property
    def status(self) -> CanaryStatus:
        return CanaryStatus(self._r["status"])

    @property
    def current_model(self) -> str:
        return self._r["current_model"]

    @property
    def candidate_model(self) -> str:
        return self._r["candidate_model"]

    @property
    def traffic_pct(self) -> float:
        return float(self._r["traffic_pct"])

    @property
    def current_scores(self) -> Dict[str, List[float]]:
        return _loads(self._r["current_scores"])

    @property
    def candidate_scores(self) -> Dict[str, List[float]]:
        return _loads(self._r["candidate_scores"])

    @property
    def promote_threshold(self) -> Dict[str, float]:
        return _loads(self._r["promote_threshold"])

    @property
    def rollback_threshold(self) -> Dict[str, float]:
        return _loads(self._r["rollback_threshold"])

    def to_dict(self) -> Dict[str, Any]:
        cs = self.current_scores
        cds = self.candidate_scores
        current_avgs = {m: round(sum(s) / len(s), 4) if s else 0 for m, s in cs.items()}
        candidate_avgs = {m: round(sum(s) / len(s), 4) if s else 0 for m, s in cds.items()}
        return {
            "id": self.id,
            "current_model": self.current_model,
            "candidate_model": self.candidate_model,
            "traffic_pct": self.traffic_pct,
            "status": self._r["status"],
            "eval_metrics": _loads(self._r["eval_metrics"]),
            "promote_threshold": self.promote_threshold,
            "rollback_threshold": self.rollback_threshold,
            "current_avg_scores": current_avgs,
            "candidate_avg_scores": candidate_avgs,
            "current_samples": sum(len(v) for v in cs.values()),
            "candidate_samples": sum(len(v) for v in cds.values()),
            "created_at": self._r["created_at"],
            "concluded_at": self._r.get("concluded_at"),
        }


def _row_to_dict(row) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    try:
        keys = ["id", "current_model", "candidate_model", "traffic_pct", "status",
                "eval_metrics", "promote_threshold", "rollback_threshold", "duration_hours",
                "current_scores", "candidate_scores", "created_at", "concluded_at"]
        return {k: row[k] for k in keys}
    except (KeyError, TypeError, AttributeError):
        # fallback for backends that support dict-like access differently
        return dict(row)


class CanaryDeploymentEngine:
    def __init__(self):
        self._lock = threading.Lock()

    def create(
        self, current_model: str, candidate_model: str, traffic_pct: float = 5,
        eval_metrics: Optional[List[str]] = None,
        promote_threshold: Optional[Dict[str, float]] = None,
        rollback_threshold: Optional[Dict[str, float]] = None,
        duration_hours: int = 48,
    ) -> CanaryDeployment:
        dep_id = str(uuid.uuid4())
        created_at = datetime.now(timezone.utc).isoformat()
        em = json.dumps(eval_metrics or ["quality_score"])
        pt = json.dumps(promote_threshold or {"quality_score": 0.95})
        rt = json.dumps(rollback_threshold or {"quality_score": 0.80})
        with self._lock:
            _db().execute(
                "INSERT INTO canary_deployments "
                "(id, current_model, candidate_model, traffic_pct, status, "
                "eval_metrics, promote_threshold, rollback_threshold, duration_hours, "
                "current_scores, candidate_scores, created_at, concluded_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (dep_id, current_model, candidate_model, traffic_pct,
                 "active", em, pt, rt, duration_hours, "{}", "{}", created_at, None),
            )
            _db().commit()
        return CanaryDeployment({
            "id": dep_id, "current_model": current_model, "candidate_model": candidate_model,
            "traffic_pct": traffic_pct, "status": "active", "eval_metrics": em,
            "promote_threshold": pt, "rollback_threshold": rt, "duration_hours": duration_hours,
            "current_scores": "{}", "candidate_scores": "{}", "created_at": created_at,
            "concluded_at": None,
        })

    def get(self, deployment_id: str) -> Optional[CanaryDeployment]:
        row = _db().execute(
            "SELECT * FROM canary_deployments WHERE id = ?", (deployment_id,)
        ).fetchone()
        d = _row_to_dict(row)
        return CanaryDeployment(d) if d else None

    def list_active(self) -> List[Dict[str, Any]]:
        rows = _db().execute(
            "SELECT * FROM canary_deployments WHERE status = ? ORDER BY created_at DESC",
            ("active",),
        ).fetchall()
        result = []
        for r in rows:
            d = _row_to_dict(r)
            if d:
                result.append(CanaryDeployment(d).to_dict())
        return result

    def route(self, deployment_id: str, context_key: str = "") -> str:
        dep = self.get(deployment_id)
        if not dep or dep.status != CanaryStatus.active:
            return dep.current_model if dep else ""
        h = int(hashlib.md5(f"{deployment_id}:{context_key}".encode(), usedforsecurity=False).hexdigest(), 16)
        bucket = (h % 1000) / 10.0
        return dep.candidate_model if bucket < dep.traffic_pct else dep.current_model

    def record_score(self, deployment_id: str, model: str, metric: str, score: float) -> None:
        with self._lock:
            row = _db().execute(
                "SELECT current_model, candidate_model, current_scores, candidate_scores "
                "FROM canary_deployments WHERE id = ?", (deployment_id,)
            ).fetchone()
            if not row:
                return
            d = _row_to_dict(row)
            if not d:
                return
            if model == d["candidate_model"]:
                scores = _loads(d["candidate_scores"])
                scores.setdefault(metric, []).append(score)
                _db().execute(
                    "UPDATE canary_deployments SET candidate_scores = ? WHERE id = ?",
                    (json.dumps(scores), deployment_id),
                )
            else:
                scores = _loads(d["current_scores"])
                scores.setdefault(metric, []).append(score)
                _db().execute(
                    "UPDATE canary_deployments SET current_scores = ? WHERE id = ?",
                    (json.dumps(scores), deployment_id),
                )
            _db().commit()

    def evaluate(self, deployment_id: str) -> Dict[str, Any]:
        dep = self.get(deployment_id)
        if not dep or dep.status != CanaryStatus.active:
            return {"action": "none", "reason": "not active"}

        concluded_at = datetime.now(timezone.utc).isoformat()

        for metric, threshold in dep.rollback_threshold.items():
            scores = dep.candidate_scores.get(metric, [])
            if len(scores) >= 10:
                avg = sum(scores) / len(scores)
                if avg < threshold:
                    with self._lock:
                        _db().execute(
                            "UPDATE canary_deployments SET status = ?, concluded_at = ? WHERE id = ?",
                            ("rolled_back", concluded_at, deployment_id),
                        )
                        _db().commit()
                    return {"action": "rolled_back", "reason": f"{metric}={avg:.3f} < {threshold}"}

        for metric, threshold in dep.promote_threshold.items():
            scores = dep.candidate_scores.get(metric, [])
            if len(scores) >= 10:
                avg = sum(scores) / len(scores)
                if avg >= threshold:
                    with self._lock:
                        _db().execute(
                            "UPDATE canary_deployments SET status = ?, concluded_at = ? WHERE id = ?",
                            ("promoted", concluded_at, deployment_id),
                        )
                        _db().commit()
                    return {"action": "promoted", "reason": f"{metric}={avg:.3f} >= {threshold}"}

        return {"action": "continue", "reason": "insufficient data or thresholds not met"}
