"""Per-deployment circuit breaker with configurable thresholds.

Implements the standard three-state circuit breaker pattern:

    CLOSED  ->  (failures >= threshold)  ->  OPEN
    OPEN    ->  (recovery timeout elapsed) ->  HALF_OPEN
    HALF_OPEN -> success -> CLOSED
    HALF_OPEN -> failure -> OPEN

This prevents cascading failures by fast-failing requests to a deployment
that is known to be unhealthy, while periodically probing it to detect
recovery.
"""

from __future__ import annotations

import logging
import threading
import time
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .router import Deployment

logger = logging.getLogger("coreiq.proxy.routing")


class CircuitState(Enum):
    """Possible states for a circuit breaker."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Per-deployment circuit breaker with configurable thresholds.

    Thread-safe.  All state transitions are logged at INFO level.

    Args:
        failure_threshold: Number of consecutive failures required to trip
            the breaker from CLOSED to OPEN.
        recovery_timeout_s: Seconds to wait in OPEN state before
            transitioning to HALF_OPEN and allowing a probe request.
        half_open_max: Maximum concurrent probe requests allowed in
            HALF_OPEN state.
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout_s: float = 60.0,
        half_open_max: int = 1,
    ) -> None:
        if failure_threshold < 1:
            raise ValueError("failure_threshold must be >= 1")
        if recovery_timeout_s <= 0:
            raise ValueError("recovery_timeout_s must be positive")
        if half_open_max < 1:
            raise ValueError("half_open_max must be >= 1")

        self._failure_threshold = failure_threshold
        self._recovery_timeout_s = recovery_timeout_s
        self._half_open_max = half_open_max

        self._lock = threading.Lock()
        self._state = CircuitState.CLOSED
        self._consecutive_failures = 0
        self._last_failure_time: float = 0.0
        self._half_open_in_flight = 0

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record_success(self) -> None:
        """Record a successful request.

        Resets the failure counter.  If the breaker is HALF_OPEN, transitions
        back to CLOSED.
        """
        with self._lock:
            self._consecutive_failures = 0
            if self._state == CircuitState.HALF_OPEN:
                self._half_open_in_flight = max(0, self._half_open_in_flight - 1)
                self._state = CircuitState.CLOSED
                logger.info("Circuit breaker HALF_OPEN -> CLOSED (success)")
            elif self._state == CircuitState.OPEN:
                # Shouldn't normally happen, but handle gracefully.
                self._state = CircuitState.CLOSED
                logger.info("Circuit breaker OPEN -> CLOSED (success)")

    def record_failure(self) -> None:
        """Record a failed request.

        Increments the consecutive failure counter.  Trips the breaker to
        OPEN if the threshold is reached.  In HALF_OPEN state, immediately
        transitions back to OPEN.
        """
        now = time.monotonic()
        with self._lock:
            self._consecutive_failures += 1
            self._last_failure_time = now

            if self._state == CircuitState.HALF_OPEN:
                self._half_open_in_flight = max(0, self._half_open_in_flight - 1)
                self._state = CircuitState.OPEN
                logger.info(
                    "Circuit breaker HALF_OPEN -> OPEN (probe failed, "
                    "failures=%d)",
                    self._consecutive_failures,
                )
            elif (
                self._state == CircuitState.CLOSED
                and self._consecutive_failures >= self._failure_threshold
            ):
                self._state = CircuitState.OPEN
                logger.info(
                    "Circuit breaker CLOSED -> OPEN (threshold=%d reached)",
                    self._failure_threshold,
                )

    # ------------------------------------------------------------------
    # Availability
    # ------------------------------------------------------------------

    def is_available(self) -> bool:
        """Return whether the deployment should accept requests.

        - CLOSED: always available.
        - OPEN: available only if the recovery timeout has elapsed
          (transitions to HALF_OPEN and permits a probe).
        - HALF_OPEN: available if fewer than ``half_open_max`` probes are
          in flight.
        """
        now = time.monotonic()
        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True

            if self._state == CircuitState.OPEN:
                elapsed = now - self._last_failure_time
                if elapsed >= self._recovery_timeout_s:
                    self._state = CircuitState.HALF_OPEN
                    self._half_open_in_flight = 0
                    logger.info(
                        "Circuit breaker OPEN -> HALF_OPEN (%.1fs elapsed)",
                        elapsed,
                    )
                    # Allow one probe.
                    self._half_open_in_flight += 1
                    return True
                return False

            # HALF_OPEN
            if self._half_open_in_flight < self._half_open_max:
                self._half_open_in_flight += 1
                return True
            return False

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def state(self) -> CircuitState:
        """Return the current circuit state.

        Note: This does not trigger state transitions.  Use ``is_available()``
        to also handle OPEN -> HALF_OPEN on timeout.
        """
        with self._lock:
            return self._state

    @property
    def consecutive_failures(self) -> int:
        """Return the current consecutive failure count."""
        with self._lock:
            return self._consecutive_failures

    def reset(self) -> None:
        """Force-reset the breaker to CLOSED state."""
        with self._lock:
            prev = self._state
            self._state = CircuitState.CLOSED
            self._consecutive_failures = 0
            self._half_open_in_flight = 0
            if prev != CircuitState.CLOSED:
                logger.info("Circuit breaker %s -> CLOSED (manual reset)", prev.value)

    def __repr__(self) -> str:
        return (
            f"<CircuitBreaker state={self._state.value} "
            f"failures={self._consecutive_failures}/{self._failure_threshold}>"
        )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class CircuitBreakerRegistry:
    """Manages circuit breakers for all deployments.

    Creates breakers lazily on first access with shared default thresholds.
    Thread-safe.
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout_s: float = 60.0,
        half_open_max: int = 1,
    ) -> None:
        self._failure_threshold = failure_threshold
        self._recovery_timeout_s = recovery_timeout_s
        self._half_open_max = half_open_max
        self._lock = threading.Lock()
        self._breakers: dict[str, CircuitBreaker] = {}

    def get(self, deployment_id: str) -> CircuitBreaker:
        """Return the circuit breaker for a deployment, creating one if needed."""
        with self._lock:
            breaker = self._breakers.get(deployment_id)
            if breaker is None:
                breaker = CircuitBreaker(
                    failure_threshold=self._failure_threshold,
                    recovery_timeout_s=self._recovery_timeout_s,
                    half_open_max=self._half_open_max,
                )
                self._breakers[deployment_id] = breaker
            return breaker

    def record_success(self, deployment_id: str) -> None:
        """Record a successful request for a deployment's circuit breaker."""
        self.get(deployment_id).record_success()

    def record_failure(self, deployment_id: str) -> None:
        """Record a failed request for a deployment's circuit breaker."""
        self.get(deployment_id).record_failure()

    def available_deployments(self, deployments: list[Deployment]) -> list[Deployment]:
        """Return only deployments whose circuit breakers allow traffic.

        Args:
            deployments: Candidate deployments.

        Returns:
            A filtered list with tripped breakers removed.
        """
        return [d for d in deployments if self.get(d.id).is_available()]

    def reset(self, deployment_id: str) -> None:
        """Reset a specific deployment's circuit breaker."""
        with self._lock:
            breaker = self._breakers.get(deployment_id)
            if breaker:
                breaker.reset()

    def reset_all(self) -> None:
        """Reset all circuit breakers."""
        with self._lock:
            for breaker in self._breakers.values():
                breaker.reset()

    def summary(self) -> list[dict]:
        """Return a summary of all circuit breakers."""
        with self._lock:
            return [
                {
                    "deployment_id": did,
                    "state": breaker.state.value,
                    "consecutive_failures": breaker.consecutive_failures,
                }
                for did, breaker in sorted(self._breakers.items())
            ]
