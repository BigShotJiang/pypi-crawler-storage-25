"""Pluggable routing strategies for deployment selection.

Each strategy implements the same ``select()`` interface so that the
:class:`~coreiq.proxy.routing.router.DeploymentRouter` can swap strategies
at runtime without touching routing logic.

Available strategies:

- **lowest_latency** -- pick the deployment with the lowest rolling
  average latency.
- **lowest_cost** -- pick the cheapest deployment based on model pricing.
- **weighted** -- random selection proportional to deployment weights.
- **round_robin** -- cycle through deployments in order.
- **least_busy** -- pick the deployment with the fewest in-flight
  requests.
"""

from __future__ import annotations

import logging
import random
import threading
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from ..providers.base import ProviderRequest
    from .metrics import RoutingMetrics
    from .router import Deployment

logger = logging.getLogger("coreiq.proxy.routing")

RoutingStrategy = Literal[
    "lowest_latency",
    "lowest_cost",
    "weighted",
    "round_robin",
    "least_busy",
]


class NoAvailableDeploymentError(Exception):
    """Raised when no deployment can serve the request."""


# ---------------------------------------------------------------------------
# Strategy implementations
# ---------------------------------------------------------------------------


class LowestLatencyStrategy:
    """Pick the deployment with the lowest average latency.

    Uses a rolling window of the most recent samples (default: 10).
    Deployments without latency data are treated as having infinite latency
    so that known-good deployments are preferred.
    """

    def __init__(self, metrics: RoutingMetrics, window: int = 10) -> None:
        self._metrics = metrics
        self._window = window

    async def select(
        self,
        deployments: list[Deployment],
        request: ProviderRequest,
    ) -> Deployment:
        """Select the deployment with the lowest recent latency."""
        if not deployments:
            raise NoAvailableDeploymentError("No deployments available")

        best: Deployment | None = None
        best_latency = float("inf")

        for d in deployments:
            avg = self._metrics.avg_latency(d.id, window=self._window)
            if avg < best_latency:
                best_latency = avg
                best = d

        # If all latencies are inf (no data), pick randomly to bootstrap.
        if best is None or best_latency == float("inf"):
            return random.choice(deployments)

        return best


class LowestCostStrategy:
    """Pick the cheapest deployment based on model pricing.

    Relies on the :class:`~coreiq.proxy.cost.CostCalculator` to look up
    per-model pricing.  Falls back to random selection if pricing is
    unavailable.
    """

    def __init__(self) -> None:
        from ..cost import CostCalculator
        self._cost = CostCalculator()

    async def select(
        self,
        deployments: list[Deployment],
        request: ProviderRequest,
    ) -> Deployment:
        """Select the deployment with the lowest estimated cost."""
        if not deployments:
            raise NoAvailableDeploymentError("No deployments available")

        # Estimate a rough token count for cost comparison.
        # Use 1000 input + 500 output as a representative request size.
        est_input = 1000
        est_output = 500

        best: Deployment | None = None
        best_cost = float("inf")

        for d in deployments:
            # Parse provider from the model string.
            provider = d.model.split("/", 1)[0] if "/" in d.model else ""
            model = d.model.split("/", 1)[1] if "/" in d.model else d.model
            try:
                result = self._cost.calculate(
                    model=model,
                    provider=provider,
                    input_tokens=est_input,
                    output_tokens=est_output,
                )
                if result.total_cost < best_cost:
                    best_cost = result.total_cost
                    best = d
            except Exception:
                logger.debug("Cost lookup failed for deployment %s", d.id)
                continue

        if best is None:
            return random.choice(deployments)
        return best


class WeightedRandomStrategy:
    """Pick a deployment proportional to its configured weight.

    Deployments with higher ``weight`` values are selected more frequently.
    A weight of 0 effectively disables a deployment.
    """

    async def select(
        self,
        deployments: list[Deployment],
        request: ProviderRequest,
    ) -> Deployment:
        """Select a deployment using weighted random sampling."""
        if not deployments:
            raise NoAvailableDeploymentError("No deployments available")

        weights = [max(d.weight, 0.0) for d in deployments]
        total = sum(weights)
        if total == 0:
            # All weights are zero -- fall back to uniform random.
            return random.choice(deployments)

        selected = random.choices(deployments, weights=weights, k=1)
        return selected[0]


class RoundRobinStrategy:
    """Cycle through deployments in deterministic order.

    Thread-safe via an atomic counter.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._counter = 0

    async def select(
        self,
        deployments: list[Deployment],
        request: ProviderRequest,
    ) -> Deployment:
        """Select the next deployment in round-robin order."""
        if not deployments:
            raise NoAvailableDeploymentError("No deployments available")

        with self._lock:
            idx = self._counter % len(deployments)
            self._counter += 1
        return deployments[idx]


class LeastBusyStrategy:
    """Pick the deployment with the fewest in-flight requests.

    Ties are broken randomly to avoid herd behaviour.
    """

    def __init__(self, metrics: RoutingMetrics) -> None:
        self._metrics = metrics

    async def select(
        self,
        deployments: list[Deployment],
        request: ProviderRequest,
    ) -> Deployment:
        """Select the deployment with the lowest in-flight count."""
        if not deployments:
            raise NoAvailableDeploymentError("No deployments available")

        min_in_flight = float("inf")
        candidates: list[Deployment] = []

        for d in deployments:
            count = self._metrics.in_flight(d.id)
            if count < min_in_flight:
                min_in_flight = count
                candidates = [d]
            elif count == min_in_flight:
                candidates.append(d)

        return random.choice(candidates)


# ---------------------------------------------------------------------------
# Strategy factory
# ---------------------------------------------------------------------------

# Type alias for any strategy instance.
StrategyInstance = (
    LowestLatencyStrategy
    | LowestCostStrategy
    | WeightedRandomStrategy
    | RoundRobinStrategy
    | LeastBusyStrategy
)


def create_strategy(
    name: RoutingStrategy,
    metrics: RoutingMetrics,
) -> StrategyInstance:
    """Create a routing strategy instance by name.

    Args:
        name: One of the supported strategy names.
        metrics: Shared metrics collector (required by latency and
            least-busy strategies).

    Returns:
        A strategy instance.

    Raises:
        ValueError: If *name* is not a recognised strategy.
    """
    if name == "lowest_latency":
        return LowestLatencyStrategy(metrics)
    elif name == "lowest_cost":
        return LowestCostStrategy()
    elif name == "weighted":
        return WeightedRandomStrategy()
    elif name == "round_robin":
        return RoundRobinStrategy()
    elif name == "least_busy":
        return LeastBusyStrategy(metrics)
    else:
        raise ValueError(
            f"Unknown routing strategy {name!r}.  "
            f"Valid strategies: lowest_latency, lowest_cost, weighted, "
            f"round_robin, least_busy"
        )
