"""Cooldown manager -- temporarily removes failed deployments from rotation.

When a deployment experiences repeated failures, the cooldown manager
parks it for a configurable duration so that routing strategies skip it
until it has had time to recover.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .router import Deployment

logger = logging.getLogger("coreiq.proxy.routing")


class CooldownManager:
    """Temporarily removes failed deployments from rotation.

    Thread-safe.  Cooldown expiry is checked lazily on each query --
    no background task is required.
    """

    def __init__(self, default_cooldown_s: float = 60.0) -> None:
        """Initialise the cooldown manager.

        Args:
            default_cooldown_s: Default cooldown duration in seconds when no
                explicit duration is supplied.
        """
        if default_cooldown_s <= 0:
            raise ValueError("default_cooldown_s must be positive")
        self._default_cooldown_s = default_cooldown_s
        self._lock = threading.Lock()
        # deployment_id -> expiry monotonic timestamp
        self._cooldowns: dict[str, float] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def put_on_cooldown(
        self, deployment_id: str, duration_s: float | None = None
    ) -> None:
        """Place a deployment on cooldown.

        Args:
            deployment_id: Deployment to cool down.
            duration_s: Cooldown duration in seconds.  Falls back to the
                default if not specified.
        """
        duration = duration_s if duration_s is not None else self._default_cooldown_s
        expiry = time.monotonic() + duration
        with self._lock:
            self._cooldowns[deployment_id] = expiry
        logger.info(
            "Deployment %s put on cooldown for %.1fs",
            deployment_id,
            duration,
        )

    def is_on_cooldown(self, deployment_id: str) -> bool:
        """Return ``True`` if the deployment is currently on cooldown."""
        now = time.monotonic()
        with self._lock:
            expiry = self._cooldowns.get(deployment_id)
            if expiry is None:
                return False
            if now >= expiry:
                # Cooldown expired -- clean up lazily.
                del self._cooldowns[deployment_id]
                return False
            return True

    def remove_cooldown(self, deployment_id: str) -> None:
        """Manually remove a deployment from cooldown."""
        with self._lock:
            self._cooldowns.pop(deployment_id, None)

    def filter_available(self, deployments: list[Deployment]) -> list[Deployment]:
        """Return only deployments that are not currently on cooldown.

        Args:
            deployments: Candidate deployments.

        Returns:
            A filtered list with cooled-down deployments removed.
        """
        now = time.monotonic()
        result: list[Deployment] = []
        with self._lock:
            expired_keys: list[str] = []
            for d in deployments:
                expiry = self._cooldowns.get(d.id)
                if expiry is None:
                    result.append(d)
                elif now >= expiry:
                    expired_keys.append(d.id)
                    result.append(d)
                # else: still on cooldown, skip
            for key in expired_keys:
                del self._cooldowns[key]
        return result

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def active_cooldowns(self) -> dict[str, float]:
        """Return a dict of deployment_id -> remaining seconds on cooldown."""
        now = time.monotonic()
        result: dict[str, float] = {}
        with self._lock:
            for did, expiry in list(self._cooldowns.items()):
                remaining = expiry - now
                if remaining > 0:
                    result[did] = round(remaining, 2)
                else:
                    del self._cooldowns[did]
        return result
