"""Content-aware routing matchers (B1 — cyberpod-gateway integration).

Matchers are small, composable predicates that evaluate a
:class:`RoutingRequest` and return ``True`` if the rule they belong to
should fire. They are stdlib-only and serialize to/from JSON so they can
be stored in the ``routing_rules`` table.

Each concrete matcher registers a stable ``type`` string. The factory
function :func:`matcher_from_dict` looks the type up and rebuilds the
matcher from its persisted form. Adding a new matcher requires three
things:

1. Subclass :class:`Matcher` with a ``TYPE`` class attribute.
2. Implement ``matches()`` and (if it carries state) ``to_dict()``
   returning a JSON-serializable dict that includes ``"type"``.
3. Add the class to :data:`_REGISTRY`.

No runtime dependencies beyond the stdlib and
``coreiq.security.pii.detect_pii``.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, ClassVar

from ...security.pii import detect_pii


# ---------------------------------------------------------------------------
# RoutingRequest
# ---------------------------------------------------------------------------


@dataclass
class RoutingRequest:
    """Shape passed to every matcher's ``matches()``."""

    tenant_id: str = ""
    model: str = ""
    messages: list[dict] = field(default_factory=list)
    estimated_tokens: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def concatenated_content(self) -> str:
        """Return ``messages[*].content`` joined with newlines.

        Handles the OpenAI chat-completions shape where ``content`` is
        either a string or a list of content parts. List parts with a
        ``text`` field are flattened; anything else is ignored.
        """
        parts: list[str] = []
        for m in self.messages or []:
            c = m.get("content") if isinstance(m, dict) else None
            if isinstance(c, str):
                parts.append(c)
            elif isinstance(c, list):
                for item in c:
                    if isinstance(item, dict):
                        txt = item.get("text") or ""
                        if isinstance(txt, str):
                            parts.append(txt)
                    elif isinstance(item, str):
                        parts.append(item)
        return "\n".join(parts)

    def estimate_tokens(self) -> int:
        """Return ``estimated_tokens`` if set, else a char/4 heuristic."""
        if self.estimated_tokens and self.estimated_tokens > 0:
            return int(self.estimated_tokens)
        return max(1, len(self.concatenated_content()) // 4)


# ---------------------------------------------------------------------------
# Matcher base class
# ---------------------------------------------------------------------------


class Matcher:
    """Abstract base — every matcher implements ``matches()`` + serialization."""

    TYPE: ClassVar[str] = ""

    def matches(self, request: RoutingRequest) -> bool:  # pragma: no cover - abstract
        raise NotImplementedError

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.TYPE}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Matcher":
        return cls()

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Matcher) and self.to_dict() == other.to_dict()

    def __hash__(self) -> int:  # pragma: no cover - rarely used
        import json as _json
        return hash(_json.dumps(self.to_dict(), sort_keys=True))


# ---------------------------------------------------------------------------
# PII / PHI
# ---------------------------------------------------------------------------


class ContainsPII(Matcher):
    """Fires if ``coreiq.security.pii.detect_pii`` finds any pattern."""

    TYPE = "contains_pii"

    def matches(self, request: RoutingRequest) -> bool:
        text = request.concatenated_content()
        if not text:
            return False
        return len(detect_pii(text)) > 0


# Healthcare-specific patterns, independent of PII (MRN / ICD-10 / NPI).
_PHI_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    # Medical record numbers — common formats: MRN-xxxxxx / MRN:xxxxxx
    ("mrn", re.compile(r"\bMRN[-:\s]?\d{5,10}\b", re.IGNORECASE)),
    # ICD-10 codes: letter + 2 digits + optional .subcode
    ("icd10", re.compile(r"\b[A-TV-Z][0-9]{2}(?:\.[0-9A-Z]{1,4})?\b")),
    # NPI: National Provider Identifier — exactly 10 digits, often labelled.
    ("npi", re.compile(r"\bNPI[-:\s]?\d{10}\b", re.IGNORECASE)),
]


class ContainsPHI(Matcher):
    """Fires if the prompt contains PHI patterns or any PII.

    Reuses the PII scanner for general identifiers (SSN / email / phone)
    and layers three healthcare-specific regexes on top.
    """

    TYPE = "contains_phi"

    def matches(self, request: RoutingRequest) -> bool:
        text = request.concatenated_content()
        if not text:
            return False
        for _name, pat in _PHI_PATTERNS:
            if pat.search(text):
                return True
        # Fall back to general PII as a safety net.
        return len(detect_pii(text)) > 0


# ---------------------------------------------------------------------------
# Data residency
# ---------------------------------------------------------------------------


@dataclass
class DataResidency(Matcher):
    """Fires if ``request.metadata['region']`` is in the allow list."""

    allowed_regions: list[str] = field(default_factory=list)
    TYPE: ClassVar[str] = "data_residency"

    def matches(self, request: RoutingRequest) -> bool:
        region = (request.metadata or {}).get("region")
        if not region:
            return False
        return region in self.allowed_regions

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.TYPE, "allowed_regions": list(self.allowed_regions)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "DataResidency":
        return cls(allowed_regions=list(d.get("allowed_regions") or []))


# ---------------------------------------------------------------------------
# Token count bounds
# ---------------------------------------------------------------------------


@dataclass
class TokenCountGt(Matcher):
    """Fires if estimated tokens exceeds ``threshold``."""

    threshold: int = 0
    TYPE: ClassVar[str] = "token_count_gt"

    def matches(self, request: RoutingRequest) -> bool:
        return request.estimate_tokens() > self.threshold

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.TYPE, "threshold": int(self.threshold)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TokenCountGt":
        return cls(threshold=int(d.get("threshold") or 0))


@dataclass
class TokenCountLt(Matcher):
    """Fires if estimated tokens is below ``threshold``."""

    threshold: int = 0
    TYPE: ClassVar[str] = "token_count_lt"

    def matches(self, request: RoutingRequest) -> bool:
        return request.estimate_tokens() < self.threshold

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.TYPE, "threshold": int(self.threshold)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TokenCountLt":
        return cls(threshold=int(d.get("threshold") or 0))


# ---------------------------------------------------------------------------
# Model / tenant / regex
# ---------------------------------------------------------------------------


@dataclass
class ModelPrefix(Matcher):
    """Fires if ``request.model`` starts with any of ``prefixes``."""

    prefixes: list[str] = field(default_factory=list)
    TYPE: ClassVar[str] = "model_prefix"

    def matches(self, request: RoutingRequest) -> bool:
        model = request.model or ""
        return any(model.startswith(p) for p in self.prefixes)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.TYPE, "prefixes": list(self.prefixes)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ModelPrefix":
        return cls(prefixes=list(d.get("prefixes") or []))


@dataclass
class TenantId(Matcher):
    """Fires if ``request.tenant_id`` is in the allow list."""

    tenant_ids: list[str] = field(default_factory=list)
    TYPE: ClassVar[str] = "tenant_id"

    def matches(self, request: RoutingRequest) -> bool:
        return request.tenant_id in self.tenant_ids

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.TYPE, "tenant_ids": list(self.tenant_ids)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TenantId":
        return cls(tenant_ids=list(d.get("tenant_ids") or []))


@dataclass
class PromptRegex(Matcher):
    """Fires if the concatenated prompt matches the compiled pattern."""

    pattern: str = ""
    TYPE: ClassVar[str] = "prompt_regex"

    def __post_init__(self) -> None:
        self._compiled = re.compile(self.pattern) if self.pattern else None

    def matches(self, request: RoutingRequest) -> bool:
        if self._compiled is None:
            return False
        return self._compiled.search(request.concatenated_content()) is not None

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.TYPE, "pattern": self.pattern}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "PromptRegex":
        return cls(pattern=str(d.get("pattern") or ""))


# ---------------------------------------------------------------------------
# Registry + factory
# ---------------------------------------------------------------------------


_REGISTRY: dict[str, type[Matcher]] = {
    ContainsPII.TYPE: ContainsPII,
    ContainsPHI.TYPE: ContainsPHI,
    DataResidency.TYPE: DataResidency,
    TokenCountGt.TYPE: TokenCountGt,
    TokenCountLt.TYPE: TokenCountLt,
    ModelPrefix.TYPE: ModelPrefix,
    TenantId.TYPE: TenantId,
    PromptRegex.TYPE: PromptRegex,
}


class UnknownMatcherTypeError(ValueError):
    """Raised when :func:`matcher_from_dict` sees an unregistered ``type``."""


def matcher_from_dict(d: dict[str, Any]) -> Matcher:
    """Deserialize a persisted matcher dict back into an instance."""
    if not isinstance(d, dict):
        raise UnknownMatcherTypeError(f"matcher spec must be a dict, got {type(d).__name__}")
    t = d.get("type")
    if not t or t not in _REGISTRY:
        raise UnknownMatcherTypeError(f"unknown matcher type: {t!r}")
    return _REGISTRY[t].from_dict(d)


def matchers_from_list(items: list[dict[str, Any]]) -> list[Matcher]:
    """Convenience — deserialize a whole list."""
    return [matcher_from_dict(x) for x in items or []]


def matchers_to_list(matchers: list[Matcher]) -> list[dict[str, Any]]:
    """Convenience — serialize a whole list."""
    return [m.to_dict() for m in matchers or []]


__all__ = [
    "RoutingRequest",
    "Matcher",
    "ContainsPII",
    "ContainsPHI",
    "DataResidency",
    "TokenCountGt",
    "TokenCountLt",
    "ModelPrefix",
    "TenantId",
    "PromptRegex",
    "UnknownMatcherTypeError",
    "matcher_from_dict",
    "matchers_from_list",
    "matchers_to_list",
]
