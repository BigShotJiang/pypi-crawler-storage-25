"""Background health checker -- periodically pings deployments to verify availability.

The health checker runs as an asyncio background task, issuing lightweight
probe requests (or TCP connects) to each registered deployment on a
configurable interval.  Results feed into the circuit breaker and metrics
systems.
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from .router import Deployment

logger = logging.getLogger("coreiq.proxy.routing")


class HealthChecker:
    """Periodically pings deployments to check availability.

    Probes are performed by issuing an HTTP GET to the provider's base URL
    (or a ``/health`` endpoint if available).  A deployment is considered
    healthy if the probe completes within ``timeout_s`` without a connection
    error.

    Usage::

        checker = HealthChecker(check_interval_s=30.0)
        checker.register(deployment)
        await checker.start()
        ...
        await checker.stop()

    Thread-safe for registration; the check loop runs on the asyncio event
    loop.
    """

    def __init__(
        self,
        check_interval_s: float = 30.0,
        timeout_s: float = 5.0,
    ) -> None:
        """Initialise the health checker.

        Args:
            check_interval_s: Seconds between health check rounds.
            timeout_s: Timeout for each individual probe request.
        """
        if check_interval_s <= 0:
            raise ValueError("check_interval_s must be positive")
        if timeout_s <= 0:
            raise ValueError("timeout_s must be positive")

        self._interval = check_interval_s
        self._timeout = timeout_s
        self._lock = threading.Lock()
        self._deployments: dict[str, Deployment] = {}
        self._health: dict[str, bool] = {}
        self._last_check: dict[str, float] = {}
        self._task: asyncio.Task | None = None
        self._running = False

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, deployment: Deployment) -> None:
        """Register a deployment for health checking.

        Args:
            deployment: The deployment to monitor.
        """
        with self._lock:
            self._deployments[deployment.id] = deployment
            # Assume healthy until proven otherwise.
            self._health.setdefault(deployment.id, True)

    def unregister(self, deployment_id: str) -> None:
        """Remove a deployment from health checking."""
        with self._lock:
            self._deployments.pop(deployment_id, None)
            self._health.pop(deployment_id, None)
            self._last_check.pop(deployment_id, None)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the background health check loop.

        Safe to call multiple times -- subsequent calls are no-ops if
        already running.
        """
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._check_loop())
        logger.info(
            "Health checker started (interval=%.1fs, timeout=%.1fs)",
            self._interval,
            self._timeout,
        )

    async def stop(self) -> None:
        """Stop the background health check loop.

        Cancels the background task and waits for it to finish.
        """
        self._running = False
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("Health checker stopped")

    # ------------------------------------------------------------------
    # Check logic
    # ------------------------------------------------------------------

    async def check_deployment(self, deployment: Deployment) -> bool:
        """Probe a single deployment and return whether it is healthy.

        The probe issues an HTTP GET to the provider's base URL.  Any
        2xx or 3xx response (or even a 401/403, which means the server is
        reachable) counts as healthy.  Connection errors and timeouts are
        unhealthy.

        Args:
            deployment: The deployment to check.

        Returns:
            ``True`` if the deployment appears reachable, ``False`` otherwise.
        """
        base_url = deployment.provider_config.get_api_base()
        if not base_url:
            # Cannot probe without a URL -- assume healthy.
            return True

        # Try a lightweight GET.  Most providers will return 404 or 405 on
        # GET to their base, but the important thing is that they respond.
        timeout = httpx.Timeout(connect=self._timeout, read=self._timeout, write=self._timeout, pool=self._timeout)
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.get(base_url)
                # Any response means the server is reachable.
                healthy = resp.status_code < 500
        except httpx.TimeoutException:
            logger.debug("Health check timed out for deployment %s", deployment.id)
            healthy = False
        except httpx.ConnectError:
            logger.debug("Health check connect error for deployment %s", deployment.id)
            healthy = False
        except Exception as exc:
            logger.debug(
                "Health check failed for deployment %s: %s", deployment.id, exc
            )
            healthy = False

        # Update health state.
        with self._lock:
            prev = self._health.get(deployment.id, True)
            self._health[deployment.id] = healthy
            self._last_check[deployment.id] = time.monotonic()

        if prev and not healthy:
            logger.warning("Deployment %s is now UNHEALTHY", deployment.id)
        elif not prev and healthy:
            logger.info("Deployment %s recovered — now HEALTHY", deployment.id)

        return healthy

    def is_healthy(self, deployment_id: str) -> bool:
        """Return the last-known health status of a deployment.

        Returns ``True`` for unknown deployments (fail-open).
        """
        with self._lock:
            return self._health.get(deployment_id, True)

    # ------------------------------------------------------------------
    # Background loop
    # ------------------------------------------------------------------

    async def _check_loop(self) -> None:
        """Run health checks in a loop until stopped."""
        while self._running:
            with self._lock:
                deployments = list(self._deployments.values())

            if deployments:
                # Run checks concurrently.
                tasks = [self.check_deployment(d) for d in deployments]
                try:
                    await asyncio.gather(*tasks, return_exceptions=True)
                except Exception as exc:
                    logger.warning("Health check round failed: %s", exc)

            try:
                await asyncio.sleep(self._interval)
            except asyncio.CancelledError:
                break

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def health_status(self) -> dict[str, bool]:
        """Return a snapshot of all deployment health statuses."""
        with self._lock:
            return dict(self._health)

    @property
    def is_running(self) -> bool:
        """Return whether the health checker is currently running."""
        return self._running
