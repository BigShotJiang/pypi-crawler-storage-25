"""Routing intelligence for the CoreIQ proxy gateway.

This package provides production-grade deployment routing with:

- **Pluggable strategies** -- lowest latency, lowest cost, weighted random,
  round-robin, and least-busy selection.
- **Circuit breakers** -- per-deployment failure isolation with automatic
  recovery probing.
- **Cooldown** -- temporarily removes failed deployments from rotation.
- **Health checking** -- background probes to detect availability.
- **Metrics** -- rolling-window latency, error rate, and throughput tracking.
- **Fallback chains** -- ordered lists of deployments for automatic retries.

Quick start::

    from coreiq.proxy.routing import DeploymentRouter, Deployment

    router = DeploymentRouter(strategy="lowest_latency")
    router.add_deployment(Deployment(
        id="openai-primary",
        model="openai/gpt-4o",
        provider_config=openai_config,
    ))

    deployment = await router.select(request)
"""

from .circuit_breaker import CircuitBreaker, CircuitBreakerRegistry, CircuitState
from .cooldown import CooldownManager
from .health import HealthChecker
from .metrics import RoutingMetrics
from .router import Deployment, DeploymentRouter
from .strategies import (
    LeastBusyStrategy,
    LowestCostStrategy,
    LowestLatencyStrategy,
    NoAvailableDeploymentError,
    RoundRobinStrategy,
    RoutingStrategy,
    WeightedRandomStrategy,
    create_strategy,
)

__all__ = [
    # Router
    "Deployment",
    "DeploymentRouter",
    # Strategies
    "RoutingStrategy",
    "LowestLatencyStrategy",
    "LowestCostStrategy",
    "WeightedRandomStrategy",
    "RoundRobinStrategy",
    "LeastBusyStrategy",
    "NoAvailableDeploymentError",
    "create_strategy",
    # Circuit breaker
    "CircuitBreaker",
    "CircuitBreakerRegistry",
    "CircuitState",
    # Cooldown
    "CooldownManager",
    # Health
    "HealthChecker",
    # Metrics
    "RoutingMetrics",
]
