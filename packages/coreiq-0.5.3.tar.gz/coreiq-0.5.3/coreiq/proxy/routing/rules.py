"""Routing rules — rule data model, evaluator, and CRUD store.

A :class:`RoutingRule` binds a list of :class:`Matcher` instances to an
action (``route`` / ``block`` / ``failover``) and a target. The
:class:`RuleEvaluator` runs an ordered list of rules against a
:class:`RoutingRequest` and returns the first match.

The :class:`RuleStore` persists rules in the ``routing_rules`` table via
:func:`coreiq.store.db.get_shared_connection`. Matchers are stored as a
JSON blob in the ``matchers_json`` column and round-tripped via
:func:`matcher_from_dict`.

This module deliberately does **not** wire itself into the existing
:class:`DeploymentRouter`. That integration is deferred to a follow-up
commit; for the MVP the cyberpod team manages rules via the REST API and
exercises them with the dry-run endpoints.
"""
from __future__ import annotations

import json
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from ...store.db import get_shared_connection
from .matchers import (
    Matcher,
    RoutingRequest,
    matchers_from_list,
    matchers_to_list,
)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


VALID_ACTIONS = ("route", "block", "failover")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class RoutingRule:
    """A single rule: matchers + action + target."""

    id: str = ""
    tenant_id: str = ""
    name: str = ""
    priority: int = 100  # lower = higher priority
    matchers: list[Matcher] = field(default_factory=list)
    action: str = "route"
    target_model_prefix: Optional[str] = None
    target_deployment_id: Optional[str] = None
    enabled: bool = True
    hit_count: int = 0
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self) -> None:
        if self.action not in VALID_ACTIONS:
            raise ValueError(
                f"invalid action {self.action!r}, expected one of {VALID_ACTIONS}"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "tenant_id": self.tenant_id,
            "name": self.name,
            "priority": self.priority,
            "matchers": matchers_to_list(self.matchers),
            "action": self.action,
            "target_model_prefix": self.target_model_prefix,
            "target_deployment_id": self.target_deployment_id,
            "enabled": bool(self.enabled),
            "hit_count": int(self.hit_count),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "RoutingRule":
        return cls(
            id=str(d.get("id") or ""),
            tenant_id=str(d.get("tenant_id") or ""),
            name=str(d.get("name") or ""),
            priority=int(d.get("priority") or 100),
            matchers=matchers_from_list(d.get("matchers") or []),
            action=str(d.get("action") or "route"),
            target_model_prefix=d.get("target_model_prefix"),
            target_deployment_id=d.get("target_deployment_id"),
            enabled=bool(d.get("enabled") if d.get("enabled") is not None else True),
            hit_count=int(d.get("hit_count") or 0),
            created_at=str(d.get("created_at") or ""),
            updated_at=str(d.get("updated_at") or ""),
        )


@dataclass
class RuleEvaluationResult:
    """Result of a rule evaluation. ``matched`` is the only required field."""

    matched: bool
    rule_id: Optional[str] = None
    action: Optional[str] = None
    target: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "matched": self.matched,
            "rule_id": self.rule_id,
            "action": self.action,
            "target": self.target,
        }


# ---------------------------------------------------------------------------
# Evaluator
# ---------------------------------------------------------------------------


class RuleEvaluator:
    """Runs a list of rules in priority order, first-match-wins.

    Disabled rules are skipped. A rule with zero matchers never fires
    (defensive default — we don't want empty rules routing all traffic).
    """

    def __init__(self, rules: list[RoutingRule]):
        self._rules = sorted(
            [r for r in rules if r.enabled],
            key=lambda r: (r.priority, r.name, r.id),
        )

    def evaluate(self, request: RoutingRequest) -> RuleEvaluationResult:
        for rule in self._rules:
            if not rule.matchers:
                continue
            if all(m.matches(request) for m in rule.matchers):
                target = rule.target_model_prefix or rule.target_deployment_id
                return RuleEvaluationResult(
                    matched=True,
                    rule_id=rule.id,
                    action=rule.action,
                    target=target,
                )
        return RuleEvaluationResult(matched=False)


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------


_COLS = (
    "id",
    "tenant_id",
    "name",
    "priority",
    "matchers_json",
    "action",
    "target_model_prefix",
    "target_deployment_id",
    "enabled",
    "hit_count",
    "created_at",
    "updated_at",
)


def _row_to_rule(row: Any) -> RoutingRule:
    """Convert a StorageBackend row (mapping-like) back into a RoutingRule."""
    def get(key: str, default: Any = None) -> Any:
        if row is None:
            return default
        try:
            return row[key]
        except (KeyError, IndexError, TypeError):
            return default

    matchers_json = get("matchers_json") or "[]"
    try:
        matcher_list = json.loads(matchers_json)
    except Exception:
        matcher_list = []

    return RoutingRule(
        id=str(get("id") or ""),
        tenant_id=str(get("tenant_id") or ""),
        name=str(get("name") or ""),
        priority=int(get("priority") or 100),
        matchers=matchers_from_list(matcher_list),
        action=str(get("action") or "route"),
        target_model_prefix=get("target_model_prefix"),
        target_deployment_id=get("target_deployment_id"),
        enabled=bool(get("enabled") or 0),
        hit_count=int(get("hit_count") or 0),
        created_at=str(get("created_at") or ""),
        updated_at=str(get("updated_at") or ""),
    )


class RuleStore:
    """CRUD over the ``routing_rules`` table."""

    def __init__(self) -> None:
        self._lock = threading.Lock()

    # -- Create ---------------------------------------------------------

    def create(self, rule: RoutingRule) -> RoutingRule:
        if not rule.id:
            rule.id = str(uuid.uuid4())
        now = _now_iso()
        if not rule.created_at:
            rule.created_at = now
        rule.updated_at = now
        conn = get_shared_connection()
        with self._lock:
            conn.execute(
                f"INSERT OR REPLACE INTO routing_rules ({', '.join(_COLS)}) "
                f"VALUES ({', '.join(['?'] * len(_COLS))})",
                (
                    rule.id,
                    rule.tenant_id,
                    rule.name,
                    int(rule.priority),
                    json.dumps(matchers_to_list(rule.matchers)),
                    rule.action,
                    rule.target_model_prefix,
                    rule.target_deployment_id,
                    1 if rule.enabled else 0,
                    int(rule.hit_count),
                    rule.created_at,
                    rule.updated_at,
                ),
            )
            conn.commit()
        return rule

    # -- Read -----------------------------------------------------------

    def get(self, rule_id: str) -> Optional[RoutingRule]:
        conn = get_shared_connection()
        row = conn.execute(
            "SELECT * FROM routing_rules WHERE id=?",
            (rule_id,),
        ).fetchone()
        if row is None:
            return None
        return _row_to_rule(row)

    def list(
        self,
        tenant_id: Optional[str] = None,
        enabled: Optional[bool] = None,
    ) -> list[RoutingRule]:
        conn = get_shared_connection()
        sql = "SELECT * FROM routing_rules"
        clauses: list[str] = []
        params: list[Any] = []
        if tenant_id is not None:
            clauses.append("tenant_id=?")
            params.append(tenant_id)
        if enabled is not None:
            clauses.append("enabled=?")
            params.append(1 if enabled else 0)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY priority ASC, created_at ASC"
        rows = conn.execute(sql, tuple(params)).fetchall()
        return [_row_to_rule(r) for r in rows]

    # -- Update ---------------------------------------------------------

    def update(self, rule_id: str, **fields: Any) -> Optional[RoutingRule]:
        existing = self.get(rule_id)
        if existing is None:
            return None
        allowed = {
            "tenant_id",
            "name",
            "priority",
            "matchers",
            "action",
            "target_model_prefix",
            "target_deployment_id",
            "enabled",
        }
        for k, v in fields.items():
            if k not in allowed:
                continue
            if k == "matchers":
                # Accept either Matcher instances or dicts.
                if v and isinstance(v[0], dict):
                    v = matchers_from_list(v)
                existing.matchers = list(v)
            else:
                setattr(existing, k, v)
        # Re-validate action.
        if existing.action not in VALID_ACTIONS:
            raise ValueError(f"invalid action {existing.action!r}")
        existing.updated_at = _now_iso()
        return self.create(existing)  # INSERT OR REPLACE

    # -- Delete ---------------------------------------------------------

    def delete(self, rule_id: str) -> bool:
        conn = get_shared_connection()
        with self._lock:
            conn.execute("DELETE FROM routing_rules WHERE id=?", (rule_id,))
            conn.commit()
        return True

    # -- Hit counter ----------------------------------------------------

    def increment_hits(self, rule_id: str) -> None:
        conn = get_shared_connection()
        with self._lock:
            conn.execute(
                "UPDATE routing_rules SET hit_count = hit_count + 1, updated_at=? WHERE id=?",
                (_now_iso(), rule_id),
            )
            conn.commit()


__all__ = [
    "RoutingRule",
    "RuleEvaluationResult",
    "RuleEvaluator",
    "RuleStore",
    "VALID_ACTIONS",
]
