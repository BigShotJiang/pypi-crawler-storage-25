"""Main deployment router -- selects the best deployment for a request.

The :class:`DeploymentRouter` is the top-level orchestrator for Phase 2
routing intelligence.  It combines:

- Pluggable routing strategies (latency, cost, weighted, round-robin,
  least-busy).
- Circuit breakers to fast-fail on unhealthy deployments.
- Cooldown periods for recently-failed deployments.
- Health checks for proactive availability monitoring.
- Per-deployment metrics for data-driven decisions.
- Fallback chains for automatic retries on different deployments.

Typical usage::

    router = DeploymentRouter(strategy="lowest_latency")
    router.add_deployment(Deployment(id="d1", model="openai/gpt-4o", ...))
    router.add_deployment(Deployment(id="d2", model="anthropic/claude-sonnet-4-6", ...))

    deployment = await router.select(request)
    fallbacks = await router.select_with_fallbacks(request, max_attempts=3)
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field

from ..providers.base import ProviderConfig, ProviderRequest
from .circuit_breaker import CircuitBreakerRegistry
from .cooldown import CooldownManager
from .health import HealthChecker
from .metrics import RoutingMetrics
from .strategies import (
    NoAvailableDeploymentError,
    RoutingStrategy,
    create_strategy,
)

logger = logging.getLogger("coreiq.proxy.routing")


# ---------------------------------------------------------------------------
# Deployment descriptor
# ---------------------------------------------------------------------------


@dataclass
class Deployment:
    """A specific model+provider endpoint that can serve requests.

    Attributes:
        id: Unique deployment identifier.
        model: Model string in ``"provider/model"`` format.
        provider_config: The :class:`ProviderConfig` instance that handles
            request transformation and dispatch for this deployment.
        weight: Relative weight for weighted-random routing.  Higher values
            increase selection probability.
        max_rpm: Optional per-deployment requests-per-minute cap.
        max_tpm: Optional per-deployment tokens-per-minute cap.
        enabled: Whether this deployment is currently in the rotation.
        tags: Arbitrary tags for tag-based filtering (e.g. ``{"gpu", "us-east"}``).
    """

    id: str
    model: str
    provider_config: ProviderConfig
    weight: float = 1.0
    max_rpm: int | None = None
    max_tpm: int | None = None
    enabled: bool = True
    tags: set[str] = field(default_factory=set)
    residency: str = "unknown"

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Deployment):
            return NotImplemented
        return self.id == other.id

    def __repr__(self) -> str:
        return (
            f"<Deployment id={self.id!r} model={self.model!r} "
            f"weight={self.weight} enabled={self.enabled}>"
        )


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------


class DeploymentRouter:
    """Selects the best deployment for a request using pluggable strategies.

    The selection pipeline:

    1. Start with all enabled deployments.
    2. Filter out deployments on cooldown.
    3. Filter out deployments with tripped circuit breakers.
    4. Filter out unhealthy deployments (if health checker is active).
    5. Optionally exclude specific deployments (e.g. already-tried ones).
    6. Apply the routing strategy to pick the best candidate.

    Args:
        strategy: Name of the routing strategy to use.
        failure_threshold: Consecutive failures before a circuit breaker trips.
        recovery_timeout_s: Seconds before a tripped breaker enters half-open.
        cooldown_s: Default cooldown duration for failed deployments.
        health_check_interval_s: Seconds between background health checks.
            Set to 0 to disable health checking.
    """

    def __init__(
        self,
        strategy: RoutingStrategy = "lowest_latency",
        *,
        failure_threshold: int = 5,
        recovery_timeout_s: float = 60.0,
        cooldown_s: float = 60.0,
        health_check_interval_s: float = 30.0,
    ) -> None:
        self._lock = threading.Lock()
        self._deployments: dict[str, Deployment] = {}

        # Sub-systems.
        self._metrics = RoutingMetrics()
        self._circuit_breakers = CircuitBreakerRegistry(
            failure_threshold=failure_threshold,
            recovery_timeout_s=recovery_timeout_s,
        )
        self._cooldown = CooldownManager(default_cooldown_s=cooldown_s)
        self._health_checker: HealthChecker | None = None
        if health_check_interval_s > 0:
            self._health_checker = HealthChecker(
                check_interval_s=health_check_interval_s,
            )

        # Routing strategy.
        self._strategy_name = strategy
        self._strategy = create_strategy(strategy, self._metrics)

    # ------------------------------------------------------------------
    # Deployment management
    # ------------------------------------------------------------------

    def add_deployment(self, deployment: Deployment) -> None:
        """Register a deployment for routing.

        Args:
            deployment: The deployment to add.

        Raises:
            ValueError: If a deployment with the same ID already exists.
        """
        with self._lock:
            if deployment.id in self._deployments:
                raise ValueError(
                    f"Deployment {deployment.id!r} already exists.  "
                    "Remove it first or use replace_deployment()."
                )
            self._deployments[deployment.id] = deployment

        if self._health_checker:
            self._health_checker.register(deployment)

        logger.info(
            "Added deployment %s (model=%s, weight=%.2f)",
            deployment.id,
            deployment.model,
            deployment.weight,
        )

    def replace_deployment(self, deployment: Deployment) -> None:
        """Add or replace a deployment."""
        with self._lock:
            self._deployments[deployment.id] = deployment
        if self._health_checker:
            self._health_checker.register(deployment)

    def remove_deployment(self, deployment_id: str) -> None:
        """Remove a deployment from routing.

        Args:
            deployment_id: ID of the deployment to remove.
        """
        with self._lock:
            removed = self._deployments.pop(deployment_id, None)

        if removed is None:
            logger.warning("Attempted to remove unknown deployment %s", deployment_id)
            return

        if self._health_checker:
            self._health_checker.unregister(deployment_id)
        self._metrics.reset(deployment_id)
        self._cooldown.remove_cooldown(deployment_id)
        self._circuit_breakers.reset(deployment_id)

        logger.info("Removed deployment %s", deployment_id)

    def get_deployment(self, deployment_id: str) -> Deployment | None:
        """Return a deployment by ID, or ``None``."""
        with self._lock:
            return self._deployments.get(deployment_id)

    def list_deployments(self) -> list[Deployment]:
        """Return a list of all registered deployments."""
        with self._lock:
            return list(self._deployments.values())

    # ------------------------------------------------------------------
    # Selection
    # ------------------------------------------------------------------

    async def select(
        self,
        request: ProviderRequest,
        *,
        exclude: set[str] | None = None,
        tags: set[str] | None = None,
    ) -> Deployment:
        """Select the best deployment for a request.

        Args:
            request: The normalised provider request.
            exclude: Set of deployment IDs to exclude (e.g. already-tried).
            tags: If provided, only deployments matching ALL tags are considered.

        Returns:
            The selected :class:`Deployment`.

        Raises:
            NoAvailableDeploymentError: If no deployment can serve the request
                after all filters are applied.
        """
        candidates = self._filter_candidates(exclude=exclude, tags=tags)

        if not candidates:
            raise NoAvailableDeploymentError(
                "No deployments available after filtering "
                f"(total={len(self._deployments)}, "
                f"exclude={exclude or set()!r})"
            )

        deployment = await self._strategy.select(candidates, request)
        return deployment

    async def select_with_fallbacks(
        self,
        request: ProviderRequest,
        max_attempts: int = 3,
        *,
        tags: set[str] | None = None,
        residency: str | None = None,
    ) -> list[Deployment]:
        """Select an ordered list of deployments to try (primary + fallbacks).

        The list is ordered by preference.  The caller should try each
        deployment in order, stopping at the first success.

        Args:
            request: The normalised provider request.
            max_attempts: Maximum number of deployments to return.
            tags: Optional tag filter.

        Returns:
            A list of up to *max_attempts* deployments, ordered by
            preference.  May be shorter if fewer candidates are available.
        """
        result: list[Deployment] = []
        exclude: set[str] = set()

        for _ in range(max_attempts):
            candidates = self._filter_candidates(exclude=exclude, tags=tags)
            # Sovereignty: when the policy bundle pins a residency, never
            # fall back to deployments tagged with a different region. An
            # ``unknown`` residency is treated as a violation when the
            # policy demands a specific region — see policy/engine.py.
            if residency and residency != "any":
                candidates = [d for d in candidates if d.residency == residency]
            if not candidates:
                break

            try:
                deployment = await self._strategy.select(candidates, request)
            except NoAvailableDeploymentError:
                break

            result.append(deployment)
            exclude.add(deployment.id)

        if not result:
            raise NoAvailableDeploymentError(
                "No deployments available for fallback chain"
            )

        return result

    # ------------------------------------------------------------------
    # Feedback (call after dispatch)
    # ------------------------------------------------------------------

    def record_success(self, deployment_id: str, latency_ms: int) -> None:
        """Record a successful request for routing feedback.

        Call this after a deployment successfully handles a request.

        Args:
            deployment_id: The deployment that served the request.
            latency_ms: End-to-end latency in milliseconds.
        """
        self._metrics.record_request(deployment_id)
        self._metrics.record_latency(deployment_id, latency_ms)
        self._circuit_breakers.record_success(deployment_id)

    def record_failure(self, deployment_id: str) -> None:
        """Record a failed request for routing feedback.

        Call this when a deployment fails to handle a request.  May trigger
        the circuit breaker or cooldown.

        Args:
            deployment_id: The deployment that failed.
        """
        self._metrics.record_request(deployment_id)
        self._metrics.record_error(deployment_id)
        self._circuit_breakers.record_failure(deployment_id)

        # If the circuit breaker just opened, put the deployment on cooldown.
        breaker = self._circuit_breakers.get(deployment_id)
        from .circuit_breaker import CircuitState
        if breaker.state == CircuitState.OPEN:
            self._cooldown.put_on_cooldown(deployment_id)

    def increment_in_flight(self, deployment_id: str) -> None:
        """Track an in-flight request (for least-busy strategy)."""
        self._metrics.increment_in_flight(deployment_id)

    def decrement_in_flight(self, deployment_id: str) -> None:
        """Release an in-flight request tracker."""
        self._metrics.decrement_in_flight(deployment_id)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start background services (health checker).

        Call this once during application startup.
        """
        if self._health_checker:
            await self._health_checker.start()

    async def stop(self) -> None:
        """Stop background services.

        Call this during application shutdown.
        """
        if self._health_checker:
            await self._health_checker.stop()

    # ------------------------------------------------------------------
    # Strategy management
    # ------------------------------------------------------------------

    @property
    def strategy_name(self) -> str:
        """Return the name of the active routing strategy."""
        return self._strategy_name

    def set_strategy(self, strategy: RoutingStrategy) -> None:
        """Change the routing strategy at runtime.

        Args:
            strategy: Name of the new strategy.
        """
        self._strategy_name = strategy
        self._strategy = create_strategy(strategy, self._metrics)
        logger.info("Routing strategy changed to %s", strategy)

    # ------------------------------------------------------------------
    # Sub-system access
    # ------------------------------------------------------------------

    @property
    def metrics(self) -> RoutingMetrics:
        """Return the metrics collector."""
        return self._metrics

    @property
    def circuit_breakers(self) -> CircuitBreakerRegistry:
        """Return the circuit breaker registry."""
        return self._circuit_breakers

    @property
    def cooldown(self) -> CooldownManager:
        """Return the cooldown manager."""
        return self._cooldown

    @property
    def health_checker(self) -> HealthChecker | None:
        """Return the health checker, or ``None`` if disabled."""
        return self._health_checker

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def summary(self) -> dict:
        """Return a summary of the router's current state."""
        with self._lock:
            deployments = list(self._deployments.values())

        return {
            "strategy": self._strategy_name,
            "total_deployments": len(deployments),
            "enabled_deployments": sum(1 for d in deployments if d.enabled),
            "active_cooldowns": self._cooldown.active_cooldowns,
            "circuit_breakers": self._circuit_breakers.summary(),
            "health": (
                self._health_checker.health_status
                if self._health_checker
                else {}
            ),
        }

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _filter_candidates(
        self,
        *,
        exclude: set[str] | None = None,
        tags: set[str] | None = None,
    ) -> list[Deployment]:
        """Apply all filters and return eligible deployments."""
        with self._lock:
            candidates = [
                d for d in self._deployments.values()
                if d.enabled
            ]

        # Tag filter.
        if tags:
            candidates = [d for d in candidates if tags.issubset(d.tags)]

        # Exclude filter.
        if exclude:
            candidates = [d for d in candidates if d.id not in exclude]

        # Cooldown filter.
        candidates = self._cooldown.filter_available(candidates)

        # Circuit breaker filter.
        candidates = self._circuit_breakers.available_deployments(candidates)

        # Health filter.
        if self._health_checker:
            candidates = [
                d for d in candidates
                if self._health_checker.is_healthy(d.id)
            ]

        return candidates

    def __repr__(self) -> str:
        return (
            f"<DeploymentRouter strategy={self._strategy_name!r} "
            f"deployments={len(self._deployments)}>"
        )
