"""Routing metrics collector — latency, error rate, and throughput per deployment.

Tracks rolling-window statistics used by routing strategies to make
informed deployment selection decisions.  All operations are thread-safe.
"""

from __future__ import annotations

import collections
import logging
import threading
import time

logger = logging.getLogger("coreiq.proxy.routing")


class RoutingMetrics:
    """Collects latency, error rate, and throughput per deployment.

    Maintains rolling windows of latency samples and error/request counts
    so that routing strategies can query recent performance.  In-flight
    request tracking supports the ``least_busy`` strategy.

    All public methods are thread-safe.
    """

    def __init__(self, *, max_samples: int = 1000) -> None:
        """Initialise the metrics collector.

        Args:
            max_samples: Maximum number of latency/error samples to retain
                per deployment.  Older samples are evicted FIFO.
        """
        self._max_samples = max_samples
        self._lock = threading.Lock()

        # deployment_id -> deque of (timestamp, latency_ms)
        self._latencies: dict[str, collections.deque[tuple[float, int]]] = {}
        # deployment_id -> deque of (timestamp, is_error: bool)
        self._requests: dict[str, collections.deque[tuple[float, bool]]] = {}
        # deployment_id -> current in-flight count
        self._in_flight: dict[str, int] = {}

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record_latency(self, deployment_id: str, latency_ms: int) -> None:
        """Record a successful request latency sample.

        Args:
            deployment_id: The deployment that served the request.
            latency_ms: End-to-end latency in milliseconds.
        """
        now = time.monotonic()
        with self._lock:
            dq = self._latencies.setdefault(
                deployment_id, collections.deque(maxlen=self._max_samples)
            )
            dq.append((now, latency_ms))

    def record_error(self, deployment_id: str) -> None:
        """Record a failed request against a deployment."""
        now = time.monotonic()
        with self._lock:
            dq = self._requests.setdefault(
                deployment_id, collections.deque(maxlen=self._max_samples)
            )
            dq.append((now, True))

    def record_request(self, deployment_id: str) -> None:
        """Record a request (successful or pending) against a deployment."""
        now = time.monotonic()
        with self._lock:
            dq = self._requests.setdefault(
                deployment_id, collections.deque(maxlen=self._max_samples)
            )
            dq.append((now, False))

    # ------------------------------------------------------------------
    # Querying
    # ------------------------------------------------------------------

    def avg_latency(self, deployment_id: str, window: int = 10) -> float:
        """Return the average latency over the last *window* samples.

        Args:
            deployment_id: Deployment to query.
            window: Number of most-recent samples to average.

        Returns:
            Average latency in milliseconds, or ``float('inf')`` if no
            samples are available.
        """
        with self._lock:
            dq = self._latencies.get(deployment_id)
            if not dq:
                return float("inf")
            # Take the last `window` entries.
            samples = list(dq)[-window:]
            if not samples:
                return float("inf")
            return sum(lat for _, lat in samples) / len(samples)

    def error_rate(self, deployment_id: str, window: int = 100) -> float:
        """Return the error rate over the last *window* request records.

        Args:
            deployment_id: Deployment to query.
            window: Number of most-recent request records to consider.

        Returns:
            A float between 0.0 and 1.0 representing the proportion of
            errors.  Returns 0.0 if no records exist.
        """
        with self._lock:
            dq = self._requests.get(deployment_id)
            if not dq:
                return 0.0
            samples = list(dq)[-window:]
            if not samples:
                return 0.0
            errors = sum(1 for _, is_err in samples if is_err)
            return errors / len(samples)

    # ------------------------------------------------------------------
    # In-flight tracking
    # ------------------------------------------------------------------

    def in_flight(self, deployment_id: str) -> int:
        """Return the number of currently in-flight requests for a deployment."""
        with self._lock:
            return self._in_flight.get(deployment_id, 0)

    def increment_in_flight(self, deployment_id: str) -> None:
        """Increment the in-flight counter for a deployment.

        Call this when a request is dispatched.
        """
        with self._lock:
            self._in_flight[deployment_id] = self._in_flight.get(deployment_id, 0) + 1

    def decrement_in_flight(self, deployment_id: str) -> None:
        """Decrement the in-flight counter for a deployment.

        Call this when a request completes (success or failure).  The counter
        is clamped at zero to guard against mismatched increment/decrement.
        """
        with self._lock:
            current = self._in_flight.get(deployment_id, 0)
            self._in_flight[deployment_id] = max(0, current - 1)

    # ------------------------------------------------------------------
    # Housekeeping
    # ------------------------------------------------------------------

    def reset(self, deployment_id: str) -> None:
        """Clear all metrics for a deployment."""
        with self._lock:
            self._latencies.pop(deployment_id, None)
            self._requests.pop(deployment_id, None)
            self._in_flight.pop(deployment_id, None)

    def reset_all(self) -> None:
        """Clear all metrics for every deployment."""
        with self._lock:
            self._latencies.clear()
            self._requests.clear()
            self._in_flight.clear()

    def summary(self, deployment_id: str) -> dict:
        """Return a summary dict for a deployment's recent metrics."""
        return {
            "deployment_id": deployment_id,
            "avg_latency_ms": round(self.avg_latency(deployment_id), 2),
            "error_rate": round(self.error_rate(deployment_id), 4),
            "in_flight": self.in_flight(deployment_id),
        }
