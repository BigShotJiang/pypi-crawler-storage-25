"""Virtual API key management for the CoreIQ proxy.

Generates, validates, and manages virtual API keys that scope access to
specific models, enforce budgets, and track per-key usage.

Keys are stored as SHA-256 hashes — the raw key is returned exactly once
at creation time and is never persisted.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import secrets
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from ..store.db import get_shared_connection

logger = logging.getLogger("coreiq.proxy.keys")

_KEY_PREFIX = "sk-coreiq-"


class BudgetExceededError(Exception):
    """Raised when a virtual key's spend limit has been reached."""


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hash_key(raw_key: str) -> str:
    """SHA-256 hash of a raw API key."""
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class VirtualKey:
    """Represents a virtual API key record (never contains the raw key)."""

    id: str
    key_hash: str
    tenant_id: str
    name: str
    models: list[str] | None  # allowed models (None = all)
    max_budget_usd: float | None
    spend_usd: float
    tpm_limit: int | None
    rpm_limit: int | None
    blocked: bool
    expires_at: datetime | None
    created_at: datetime
    metadata: dict = field(default_factory=dict)


def _row_to_virtual_key(row) -> VirtualKey:
    """Convert a dict-like DB row to a VirtualKey dataclass."""
    _get = (lambda k, d=None: row.get(k, d)) if hasattr(row, "get") else (lambda k, d=None: row[k])
    models_raw = _get("models_json")
    models: list[str] | None = None
    if models_raw:
        try:
            models = json.loads(models_raw) if isinstance(models_raw, str) else models_raw
        except (json.JSONDecodeError, TypeError):
            models = None

    meta_raw = _get("metadata_json")
    metadata: dict = {}
    if meta_raw:
        try:
            metadata = json.loads(meta_raw) if isinstance(meta_raw, str) else meta_raw
        except (json.JSONDecodeError, TypeError):
            metadata = {}

    expires_at: datetime | None = None
    raw_expires = _get("expires_at")
    if raw_expires:
        try:
            expires_at = datetime.fromisoformat(raw_expires)
        except (ValueError, TypeError):
            expires_at = None

    created_at = datetime.now(timezone.utc)
    raw_created = _get("created_at")
    if raw_created:
        try:
            created_at = datetime.fromisoformat(raw_created)
        except (ValueError, TypeError):
            pass

    return VirtualKey(
        id=row["id"],
        key_hash=row["key_hash"],
        tenant_id=row["tenant_id"],
        name=row["name"] or "",
        models=models,
        max_budget_usd=row["max_budget_usd"],
        spend_usd=row["spend_usd"] or 0.0,
        tpm_limit=row["tpm_limit"],
        rpm_limit=row["rpm_limit"],
        blocked=bool(row["blocked"]),
        expires_at=expires_at,
        created_at=created_at,
        metadata=metadata,
    )


# ---------------------------------------------------------------------------
# Key manager
# ---------------------------------------------------------------------------


class KeyManager:
    """Manages virtual API keys for the CoreIQ proxy.

    All operations go directly to SQLite (via the shared per-thread
    connection) so that concurrent readers/writers stay consistent.
    """

    def generate_key(
        self,
        *,
        tenant_id: str = "default",
        name: str = "",
        models: list[str] | None = None,
        max_budget_usd: float | None = None,
        tpm_limit: int | None = None,
        rpm_limit: int | None = None,
        expires_in_days: int | None = None,
        metadata: dict | None = None,
    ) -> tuple[str, VirtualKey]:
        """Generate a new virtual key.

        Returns:
            A ``(raw_key, virtual_key_record)`` tuple.  The raw key is
            only available at creation time — it is **not** stored.
        """
        raw_key = f"{_KEY_PREFIX}{secrets.token_hex(32)}"
        key_hash = _hash_key(raw_key)
        key_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)

        expires_at: datetime | None = None
        if expires_in_days is not None and expires_in_days > 0:
            expires_at = now + timedelta(days=expires_in_days)

        models_json = json.dumps(models) if models is not None else None
        metadata_json = json.dumps(metadata or {})

        conn = get_shared_connection()
        conn.execute(
            """INSERT INTO api_keys
               (id, key_hash, tenant_id, name, models_json, max_budget_usd,
                spend_usd, tpm_limit, rpm_limit, blocked, expires_at,
                metadata_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?, ?)""",
            (
                key_id,
                key_hash,
                tenant_id,
                name,
                models_json,
                max_budget_usd,
                tpm_limit,
                rpm_limit,
                expires_at.isoformat() if expires_at else None,
                metadata_json,
                now.isoformat(),
            ),
        )
        conn.commit()

        vk = VirtualKey(
            id=key_id,
            key_hash=key_hash,
            tenant_id=tenant_id,
            name=name,
            models=models,
            max_budget_usd=max_budget_usd,
            spend_usd=0.0,
            tpm_limit=tpm_limit,
            rpm_limit=rpm_limit,
            blocked=False,
            expires_at=expires_at,
            created_at=now,
            metadata=metadata or {},
        )
        logger.info("Generated virtual key %s (tenant=%s, name=%r)", key_id, tenant_id, name)
        return raw_key, vk

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_key(self, raw_key: str) -> VirtualKey | None:
        """Validate a raw key and return its record.

        Returns ``None`` if the key is invalid, expired, or blocked.
        Uses constant-time comparison for the hash to avoid timing attacks.
        """
        if not raw_key or not raw_key.startswith(_KEY_PREFIX):
            return None

        provided_hash = _hash_key(raw_key)
        conn = get_shared_connection()
        row = conn.execute(
            "SELECT * FROM api_keys WHERE key_hash = ?",
            (provided_hash,),
        ).fetchone()

        if row is None:
            return None

        # Constant-time comparison of the stored hash vs computed hash.
        if not hmac.compare_digest(row["key_hash"], provided_hash):
            return None  # pragma: no cover — defensive

        vk = _row_to_virtual_key(row)

        # Check blocked.
        if vk.blocked:
            logger.debug("Key %s is blocked", vk.id)
            return None

        # Check expiry.
        if vk.expires_at is not None:
            now = datetime.now(timezone.utc)
            # Ensure we compare offset-aware datetimes.
            expires = vk.expires_at
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if now > expires:
                logger.debug("Key %s is expired (expired at %s)", vk.id, expires)
                return None

        return vk

    # ------------------------------------------------------------------
    # Usage tracking
    # ------------------------------------------------------------------

    def record_usage(
        self,
        key_id: str,
        *,
        tokens: int = 0,
        cost_usd: float = 0.0,
    ) -> None:
        """Track token usage and spend against a key's budget."""
        conn = get_shared_connection()
        conn.execute(
            "UPDATE api_keys SET spend_usd = spend_usd + ? WHERE id = ?",
            (cost_usd, key_id),
        )
        conn.commit()

    def check_budget(self, key: VirtualKey) -> bool:
        """Return ``True`` if the key is within its budget.

        If the key has no budget limit, always returns ``True``.
        Uses an atomic ``BEGIN IMMEDIATE`` transaction to eliminate the
        TOCTOU race between reading spend and updating it.

        .. versionchanged:: 0.12.0
           **Breaking change** — this method now raises :exc:`BudgetExceededError`
           when the budget is exceeded instead of returning ``False``.
           Callers that previously checked ``if not km.check_budget(vk)``
           must switch to a ``try/except BudgetExceededError`` pattern.

        Raises:
            BudgetExceededError: if the key's spend meets or exceeds its limit.
        """
        if key.max_budget_usd is None:
            return True

        conn = get_shared_connection()
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT spend_usd FROM api_keys WHERE id = ?",
                (key.id,),
            ).fetchone()
            if row is None:
                conn.execute("ROLLBACK")
                return False

            current_spend = row["spend_usd"] or 0.0
            if current_spend >= key.max_budget_usd:
                conn.execute("ROLLBACK")
                raise BudgetExceededError(
                    f"Virtual key budget exceeded (spend: ${current_spend:.4f}, "
                    f"limit: ${key.max_budget_usd:.2f})."
                )

            conn.commit()
            return True
        except BudgetExceededError:
            raise
        except Exception:
            try:
                conn.execute("ROLLBACK")
            except Exception:
                pass
            raise

    def check_model_allowed(self, key: VirtualKey, model: str) -> bool:
        """Return ``True`` if *model* is in the key's allowed list.

        If the key has no model restrictions (``models is None``), all
        models are allowed.  Supports wildcard prefixes like ``"openai/*"``.
        """
        if key.models is None:
            return True

        for pattern in key.models:
            if pattern == model:
                return True
            # Support wildcard: "openai/*" matches "openai/gpt-4o"
            if pattern.endswith("/*"):
                prefix = pattern[:-1]  # "openai/"
                if model.startswith(prefix):
                    return True
        return False

    # ------------------------------------------------------------------
    # Administration
    # ------------------------------------------------------------------

    def revoke_key(self, key_id: str) -> bool:
        """Block a key by ID.  Returns ``True`` if a key was found and revoked."""
        conn = get_shared_connection()
        cursor = conn.execute(
            "UPDATE api_keys SET blocked = 1 WHERE id = ?",
            (key_id,),
        )
        conn.commit()
        revoked = cursor.rowcount > 0
        if revoked:
            logger.info("Revoked key %s", key_id)
        return revoked

    def list_keys(self, tenant_id: str | None = None) -> list[VirtualKey]:
        """List all keys, optionally filtered by tenant."""
        conn = get_shared_connection()
        if tenant_id:
            rows = conn.execute(
                "SELECT * FROM api_keys WHERE tenant_id = ? ORDER BY created_at DESC",
                (tenant_id,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM api_keys ORDER BY created_at DESC",
            ).fetchall()
        return [_row_to_virtual_key(r) for r in rows]

    def get_key(self, key_id: str) -> VirtualKey | None:
        """Get a single key by ID."""
        conn = get_shared_connection()
        row = conn.execute(
            "SELECT * FROM api_keys WHERE id = ?",
            (key_id,),
        ).fetchone()
        if row is None:
            return None
        return _row_to_virtual_key(row)


# ---------------------------------------------------------------------------
# Rate limiter — sliding window RPM/TPM enforcement for virtual keys
# ---------------------------------------------------------------------------


_RATE_LIMIT_LUA = """
local key = KEYS[1]
local now = tonumber(ARGV[1])
local window_ms = tonumber(ARGV[2])
local limit = tonumber(ARGV[3])
redis.call('ZREMRANGEBYSCORE', key, 0, now - window_ms)
local count = redis.call('ZCARD', key)
if count >= limit then return 0 end
local seq = redis.call('INCR', key .. ':seq')
redis.call('ZADD', key, now, tostring(now) .. ':' .. tostring(seq))
redis.call('PEXPIRE', key, window_ms)
return 1
"""


class RateLimiter:
    """Sliding window rate limiter for virtual key RPM and TPM.

    Uses Redis (atomic Lua script) when ``COREIQ_REDIS_URL`` is set, which
    makes enforcement correct across multiple worker processes.  Falls back
    to an in-memory deque implementation (single-process only) with a
    startup warning.

    Thread-safe in both modes.
    """

    WINDOW_SECONDS: float = 60.0

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # key_id -> deque of (timestamp, tokens)
        self._windows: dict[str, deque[tuple[float, int]]] = {}
        self._redis: object | None = None
        self._rate_script: object | None = None
        self._try_connect_redis()

    def _try_connect_redis(self) -> None:
        import os
        redis_url = os.environ.get("COREIQ_REDIS_URL", "")
        if not redis_url:
            return
        try:
            import redis as _redis
            client = _redis.from_url(redis_url, socket_connect_timeout=2)
            client.ping()
            self._redis = client
            self._rate_script = client.register_script(_RATE_LIMIT_LUA)
            logger.info("RateLimiter: using Redis at %s", redis_url)
        except Exception as exc:
            logger.warning(
                "RateLimiter: could not connect to Redis (%s) — falling back to "
                "in-memory rate limiting. This is NOT safe for multi-worker deployments. "
                "Set COREIQ_REDIS_URL to fix this.",
                exc,
            )

    def _purge(self, key_id: str, now: float) -> deque[tuple[float, int]]:
        """Remove entries older than the sliding window and return the deque."""
        window = self._windows.get(key_id)
        if window is None:
            window = deque()
            self._windows[key_id] = window
        cutoff = now - self.WINDOW_SECONDS
        while window and window[0][0] <= cutoff:
            window.popleft()
        return window

    def check_rate(
        self,
        key_id: str,
        rpm_limit: int | None = None,
        tpm_limit: int | None = None,
    ) -> bool:
        """Check whether *key_id* is within its RPM and TPM limits.

        Returns ``True`` if the request should be allowed, ``False`` if
        either limit is exceeded.  A ``None`` limit means unlimited.

        When Redis is configured, uses an atomic Lua script for correctness
        across multiple worker processes.  Otherwise falls back to the
        in-memory deque implementation.

        Token usage (TPM) must be recorded separately via :meth:`record_usage`.
        """
        if rpm_limit is None and tpm_limit is None:
            return True  # No limits configured.

        # Redis path — atomic sliding window for RPM
        if self._redis is not None and self._rate_script is not None:
            try:
                return self._check_rate_redis(key_id, rpm_limit)
            except Exception as exc:
                logger.warning("Redis rate check failed, falling back to memory: %s", exc)
                # Fall through to in-memory

        # In-memory path
        now = time.monotonic()
        with self._lock:
            window = self._purge(key_id, now)

            # RPM check — count of entries in the window.
            if rpm_limit is not None and len(window) >= rpm_limit:
                return False

            # TPM check — sum of tokens in the window.
            if tpm_limit is not None:
                current_tpm = sum(tok for _, tok in window)
                if current_tpm >= tpm_limit:
                    return False

            # Record this request (0 tokens — actual tokens added later).
            window.append((now, 0))
            return True

    def _check_rate_redis(self, key_id: str, rpm_limit: int | None) -> bool:
        """Atomic Redis sliding window RPM check."""
        if rpm_limit is None:
            return True
        now_ms = int(time.time() * 1000)
        window_ms = int(self.WINDOW_SECONDS * 1000)
        result = self._rate_script(
            keys=[f"coreiq:rl:{key_id}:rpm"],
            args=[now_ms, window_ms, rpm_limit],
        )
        return bool(result)

    def record_usage(self, key_id: str, *, tokens: int = 0) -> None:
        """Record token usage for the most recent request on *key_id*.

        Updates the last entry's token count so TPM accounting is accurate.
        Called from Stage 7 (observe) after the response is received.
        """
        if tokens <= 0:
            return

        now = time.monotonic()
        with self._lock:
            window = self._purge(key_id, now)
            if window:
                # Update the last entry (the one added during check_rate).
                last_ts, last_tok = window[-1]
                window[-1] = (last_ts, last_tok + tokens)

    def current_rpm(self, key_id: str) -> int:
        """Return the current request count in the sliding window."""
        now = time.monotonic()
        with self._lock:
            window = self._purge(key_id, now)
            return len(window)

    def current_tpm(self, key_id: str) -> int:
        """Return the current token count in the sliding window."""
        now = time.monotonic()
        with self._lock:
            window = self._purge(key_id, now)
            return sum(tok for _, tok in window)
