"""Prometheus metrics endpoint for CoreIQ.

Exposes LLM-specific metrics at /metrics for Prometheus scraping.

Requires: No extra deps — uses pure Python text exposition format.

Usage::

    from coreiq.observability import configure_prometheus
    configure_prometheus(port=9090)

Or via coreiq.toml:
    [prometheus]
    enabled = true
    port = 9090
    path = "/metrics"
"""
import logging
import threading
from typing import Any, Dict

logger = logging.getLogger("coreiq.observability.prometheus")

# Thread-safe metric counters
_lock = threading.Lock()
_counters: Dict[str, float] = {
    "coreiq_requests_total": 0,
    "coreiq_tokens_input_total": 0,
    "coreiq_tokens_output_total": 0,
    "coreiq_cost_usd_total": 0.0,
    "coreiq_cache_hits_total": 0,
    "coreiq_errors_total": 0,
}
_histograms: Dict[str, list] = {
    "coreiq_latency_ms": [],  # rolling last 1000 values
}
_labels: Dict[str, Dict[str, float]] = {
    "coreiq_requests_by_model": {},   # model → count
    "coreiq_requests_by_provider": {},  # provider → count
}

_prometheus_configured = False


def record_request(
    *,
    model: str = "",
    provider: str = "",
    input_tokens: int = 0,
    output_tokens: int = 0,
    latency_ms: int = 0,
    cost_usd: float = 0.0,
    cache_hit: bool = False,
    error: bool = False,
) -> None:
    """Record a request for Prometheus metrics. Called by Tracer automatically."""
    with _lock:
        _counters["coreiq_requests_total"] += 1
        _counters["coreiq_tokens_input_total"] += input_tokens
        _counters["coreiq_tokens_output_total"] += output_tokens
        _counters["coreiq_cost_usd_total"] += cost_usd
        if cache_hit:
            _counters["coreiq_cache_hits_total"] += 1
        if error:
            _counters["coreiq_errors_total"] += 1
        if latency_ms:
            buf = _histograms["coreiq_latency_ms"]
            buf.append(latency_ms)
            if len(buf) > 1000:
                del buf[:-1000]
        if model:
            _labels["coreiq_requests_by_model"][model] = (
                _labels["coreiq_requests_by_model"].get(model, 0) + 1
            )
        if provider:
            _labels["coreiq_requests_by_provider"][provider] = (
                _labels["coreiq_requests_by_provider"].get(provider, 0) + 1
            )


def generate_metrics() -> str:
    """Generate Prometheus text format metrics string."""
    with _lock:
        lines = []

        # Simple counters
        for name, value in _counters.items():
            lines.append(f"# TYPE {name} counter")
            lines.append(f"{name} {value}")

        # Latency histogram (simplified — p50/p95/p99)
        latencies = sorted(_histograms["coreiq_latency_ms"])
        if latencies:
            n = len(latencies)
            p50 = latencies[int(n * 0.50)]
            p95 = latencies[int(n * 0.95)]
            p99 = latencies[min(int(n * 0.99), n - 1)]
            lines.append("# TYPE coreiq_latency_ms_p50 gauge")
            lines.append(f"coreiq_latency_ms_p50 {p50}")
            lines.append("# TYPE coreiq_latency_ms_p95 gauge")
            lines.append(f"coreiq_latency_ms_p95 {p95}")
            lines.append("# TYPE coreiq_latency_ms_p99 gauge")
            lines.append(f"coreiq_latency_ms_p99 {p99}")

        # Per-model counters
        lines.append("# TYPE coreiq_requests_by_model counter")
        for model, count in _labels["coreiq_requests_by_model"].items():
            lines.append(f'coreiq_requests_by_model{{model="{model}"}} {count}')

        # Per-provider counters
        lines.append("# TYPE coreiq_requests_by_provider counter")
        for provider, count in _labels["coreiq_requests_by_provider"].items():
            lines.append(f'coreiq_requests_by_provider{{provider="{provider}"}} {count}')

        return "\n".join(lines) + "\n"


def configure_prometheus(port: int = 9090, path: str = "/metrics") -> None:
    """Start a Prometheus metrics HTTP server on the given port.

    This starts a lightweight background HTTP server. For FastAPI integration,
    use the /metrics endpoint mounted by configure_otel() instead.

    Args:
        port: Port to listen on (default 9090).
        path: URL path for metrics (default /metrics).
    """
    global _prometheus_configured
    if _prometheus_configured:
        return

    import http.server

    class MetricsHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            if self.path == path:
                body = generate_metrics().encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; version=0.0.4")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, fmt: str, *args: Any) -> None:
            pass  # suppress default access log

    server = http.server.HTTPServer(("0.0.0.0", port), MetricsHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    _prometheus_configured = True
    logger.info("CoreIQ Prometheus metrics at http://0.0.0.0:%d%s", port, path)


def is_configured() -> bool:
    return _prometheus_configured
