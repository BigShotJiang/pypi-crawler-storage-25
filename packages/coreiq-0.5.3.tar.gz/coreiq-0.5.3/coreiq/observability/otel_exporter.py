"""OpenTelemetry OTLP exporter for CoreIQ spans.

Translates CoreIQ TraceSpan records into OpenTelemetry spans conforming to
the GenAI semantic conventions (https://opentelemetry.io/docs/specs/semconv/gen-ai/).

Requires: pip install coreiq[otel]

Usage::

    from coreiq.observability import configure_otel
    configure_otel(
        endpoint="http://otel-collector:4317",
        protocol="grpc",
        service_name="my-ai-app",
    )
    # All subsequent coreiq.trace() spans are automatically exported.
"""
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger("coreiq.observability.otel")

# Module-level provider/exporter handles (set by configure_otel)
_otel_configured = False
_tracer_provider = None
_otel_tracer = None
_logger_provider = None
_meter_provider = None


def configure_otel(
    endpoint: str = "http://localhost:4317",
    protocol: str = "grpc",  # "grpc" | "http/protobuf"
    service_name: str = "coreiq",
    resource_attributes: Optional[Dict[str, str]] = None,
    export_traces: bool = True,
    export_metrics: bool = True,
    batch_size: int = 512,
    export_timeout_ms: int = 5000,
    *,
    logs_endpoint: Optional[str] = None,
    metrics_endpoint: Optional[str] = None,
    export_logs: bool = True,
) -> None:
    """Configure OpenTelemetry OTLP export for CoreIQ spans.

    Call once at application startup before any LLM calls. All subsequent
    coreiq.trace() context manager spans will be exported via OTLP.

    Args:
        endpoint: OTLP collector endpoint (gRPC: 4317, HTTP: 4318).
        protocol: "grpc" or "http/protobuf".
        service_name: Resource service.name attribute.
        resource_attributes: Additional OTel resource attributes.
        export_traces: Whether to export trace spans (default True).
        export_metrics: Whether to export metrics (default True).
        batch_size: Max spans per export batch.
        export_timeout_ms: Export timeout in milliseconds.
        logs_endpoint: Optional override for the OTLP logs endpoint. Defaults
            to ``endpoint`` (OTLP convention — same collector for everything).
        metrics_endpoint: Optional override for the OTLP metrics endpoint.
            Defaults to ``endpoint``.
        export_logs: Whether to install an OTLP log exporter on the global
            ``LoggerProvider``. On by default — CoreIQ emits policy /
            security / cost / audit events as OTLP log records, and the
            consumer is expected to receive them. Set ``export_logs=False``
            only if you have your own log pipeline already wired up.
    """
    global _otel_configured, _tracer_provider, _otel_tracer
    global _logger_provider, _meter_provider
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.resources import Resource, SERVICE_NAME
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except ImportError:
        raise ImportError(
            "OpenTelemetry export requires opentelemetry-sdk. "
            "Install with: pip install coreiq[otel]"
        )

    import os as _os
    attrs = {SERVICE_NAME: service_name}
    if _os.environ.get("OTEL_SERVICE_VERSION"):
        attrs["service.version"] = _os.environ["OTEL_SERVICE_VERSION"]
    # Merge OTEL_RESOURCE_ATTRIBUTES (per spec: comma-separated key=value pairs).
    for pair in (_os.environ.get("OTEL_RESOURCE_ATTRIBUTES") or "").split(","):
        pair = pair.strip()
        if "=" in pair:
            k, _, v = pair.partition("=")
            k, v = k.strip(), v.strip()
            if k:
                attrs[k] = v
    if resource_attributes:
        attrs.update(resource_attributes)
    resource = Resource.create(attrs)
    provider = TracerProvider(resource=resource)

    if export_traces:
        exporter = _build_exporter(endpoint, protocol, export_timeout_ms)
        if exporter:
            processor = BatchSpanProcessor(
                exporter,
                max_export_batch_size=batch_size,
            )
            provider.add_span_processor(processor)

    trace.set_tracer_provider(provider)
    _tracer_provider = provider
    _otel_tracer = trace.get_tracer("coreiq", schema_url="https://opentelemetry.io/schemas/1.24.0")

    # Optional logs pipeline (OTel-only backend uses this).
    if export_logs:
        _logger_provider = _configure_logger_provider(
            resource=resource,
            endpoint=logs_endpoint or endpoint,
            protocol=protocol,
            timeout_ms=export_timeout_ms,
        )

    # Optional metrics pipeline.
    if export_metrics:
        _meter_provider = _configure_meter_provider(
            resource=resource,
            endpoint=metrics_endpoint or endpoint,
            protocol=protocol,
            timeout_ms=export_timeout_ms,
        )

    _otel_configured = True
    logger.info("CoreIQ OTel configured → %s (%s)", endpoint, protocol)


def _build_exporter(endpoint: str, protocol: str, timeout_ms: int) -> Any:
    """Build the appropriate OTLP exporter based on protocol."""
    try:
        if protocol == "grpc":
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
            return OTLPSpanExporter(
                endpoint=endpoint,
                timeout=timeout_ms // 1000,
            )
        else:  # http/protobuf
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import (  # type: ignore[assignment,unused-ignore]
                OTLPSpanExporter,
            )
            http_endpoint = endpoint.rstrip("/") + "/v1/traces"
            return OTLPSpanExporter(
                endpoint=http_endpoint,
                timeout=timeout_ms // 1000,
            )
    except ImportError as e:
        logger.warning("OTel exporter not available: %s", e)
        return None


def _configure_logger_provider(*, resource: Any, endpoint: str, protocol: str, timeout_ms: int) -> Any:
    """Install a global OTLP-backed ``LoggerProvider`` and return it."""
    try:
        from opentelemetry._logs import set_logger_provider
        from opentelemetry.sdk._logs import LoggerProvider
        from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
    except ImportError as e:  # pragma: no cover — caller already imported sdk
        logger.warning("OTel logs SDK not available: %s", e)
        return None

    provider = LoggerProvider(resource=resource)
    exporter = _build_log_exporter(endpoint, protocol, timeout_ms)
    if exporter is not None:
        provider.add_log_record_processor(BatchLogRecordProcessor(exporter))
    set_logger_provider(provider)
    return provider


def _build_log_exporter(endpoint: str, protocol: str, timeout_ms: int) -> Any:
    """Build an OTLP log exporter (gRPC or HTTP)."""
    try:
        if protocol == "grpc":
            from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
            return OTLPLogExporter(endpoint=endpoint, timeout=timeout_ms // 1000)
        from opentelemetry.exporter.otlp.proto.http._log_exporter import (  # type: ignore[assignment,unused-ignore]
            OTLPLogExporter,
        )
        http_endpoint = endpoint.rstrip("/") + "/v1/logs"
        return OTLPLogExporter(endpoint=http_endpoint, timeout=timeout_ms // 1000)
    except ImportError as e:
        logger.warning("OTel log exporter not available: %s", e)
        return None


def _configure_meter_provider(*, resource: Any, endpoint: str, protocol: str, timeout_ms: int) -> Any:
    """Install a global OTLP-backed ``MeterProvider`` and return it."""
    try:
        from opentelemetry import metrics
        from opentelemetry.sdk.metrics import MeterProvider
        from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    except ImportError as e:  # pragma: no cover
        logger.warning("OTel metrics SDK not available: %s", e)
        return None

    exporter = _build_metric_exporter(endpoint, protocol, timeout_ms)
    readers = [PeriodicExportingMetricReader(exporter)] if exporter is not None else []
    provider = MeterProvider(resource=resource, metric_readers=readers)
    metrics.set_meter_provider(provider)
    return provider


def _build_metric_exporter(endpoint: str, protocol: str, timeout_ms: int) -> Any:
    """Build an OTLP metric exporter (gRPC or HTTP)."""
    try:
        if protocol == "grpc":
            from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
            return OTLPMetricExporter(endpoint=endpoint, timeout=timeout_ms // 1000)
        from opentelemetry.exporter.otlp.proto.http.metric_exporter import (  # type: ignore[assignment,unused-ignore]
            OTLPMetricExporter,
        )
        http_endpoint = endpoint.rstrip("/") + "/v1/metrics"
        return OTLPMetricExporter(endpoint=http_endpoint, timeout=timeout_ms // 1000)
    except ImportError as e:
        logger.warning("OTel metric exporter not available: %s", e)
        return None


def emit_span(
    name: str,
    *,
    model: str = "",
    provider: str = "",
    input_tokens: int = 0,
    output_tokens: int = 0,
    latency_ms: int = 0,
    finish_reason: str = "stop",
    span_kind_str: str = "llm",
    trace_id: Optional[str] = None,
    parent_span_id: Optional[str] = None,
    attributes: Optional[Dict[str, Any]] = None,
    error: Optional[BaseException] = None,
    error_type: Optional[str] = None,
    error_message: Optional[str] = None,
) -> None:
    """Emit a single CoreIQ span to the configured OTel backend.

    This is called automatically by Tracer.record_request() when OTel is configured.
    Can also be called manually for custom spans.
    """
    if not _otel_configured or _otel_tracer is None:
        return
    try:
        from opentelemetry.trace import SpanKind, StatusCode

        from .genai_attributes import GenAIAttrs, apply as apply_genai

        kind = SpanKind.CLIENT if span_kind_str in ("llm", "tool") else SpanKind.INTERNAL

        with _otel_tracer.start_as_current_span(
            name or f"gen_ai.{span_kind_str}",
            kind=kind,
        ) as span:
            # Delegate all gen_ai.* + coreiq.* attribute setting to the
            # central mapping module so every caller (exporter, pipeline,
            # adapters) emits the same attribute shape.
            apply_genai(
                span,
                GenAIAttrs(
                    system=provider or None,
                    operation=span_kind_str,
                    request_model=model or None,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    finish_reasons=[finish_reason] if finish_reason else [],
                    latency_ms=latency_ms,
                    extra=dict(attributes) if attributes else {},
                ),
            )
            # Span hygiene: record exception + ERROR status when something
            # went wrong (caller passed an exception or error_type/message).
            if error is not None:
                span.record_exception(error)
                span.set_status(StatusCode.ERROR, str(error))
                if error_type or error.__class__.__name__:
                    span.set_attribute("error.type", error_type or error.__class__.__name__)
            elif error_type or error_message:
                span.set_status(StatusCode.ERROR, error_message or error_type or "error")
                if error_type:
                    span.set_attribute("error.type", error_type)
            else:
                span.set_status(StatusCode.OK)
    except Exception as e:
        logger.debug("OTel emit failed (non-critical): %s", e)


def is_configured() -> bool:
    """Return True if OTel export has been configured."""
    return _otel_configured


def get_logger_provider() -> Any:
    """Return the configured OTel ``LoggerProvider`` (or None)."""
    return _logger_provider


def get_meter_provider() -> Any:
    """Return the configured OTel ``MeterProvider`` (or None)."""
    return _meter_provider
