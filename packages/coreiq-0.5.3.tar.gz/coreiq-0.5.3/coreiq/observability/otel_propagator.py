"""W3C Trace Context propagation helpers.

Reads inbound ``traceparent`` / ``tracestate`` headers on incoming FastAPI
requests and injects them into outbound HTTPX calls to LLM providers, so
that coreiq spans are nested inside the customer's existing distributed
trace rather than forming their own island.

Design
------

This module wraps the official OpenTelemetry
:class:`opentelemetry.trace.propagation.tracecontext.TraceContextTextMapPropagator`
so callers don't need to know that OTel exists. Both functions degrade
gracefully when OTel isn't installed (the ``coreiq[otel]`` extra is not a
hard dependency) — :func:`extract` returns the current OTel context
unchanged, and :func:`inject` is a no-op.

Usage
-----

::

    from coreiq.observability.otel_propagator import extract, inject

    # In a FastAPI route:
    ctx = extract(dict(request.headers))

    # In an outbound provider HTTP client:
    outgoing_headers: dict[str, str] = {}
    inject(outgoing_headers, context=ctx)
    # → outgoing_headers now has "traceparent": "00-<trace>-<span>-01"
"""
from __future__ import annotations

import logging
from typing import Any, Mapping, MutableMapping, Optional

logger = logging.getLogger("coreiq.observability.otel_propagator")

# Cache the propagator lookup so repeated calls don't pay the import cost.
_propagator: Any = None
_unset = object()


def _get_propagator() -> Any:
    """Return the global OTel TextMap propagator, or None if OTel is absent."""
    global _propagator
    if _propagator is _unset or _propagator is None:
        try:
            from opentelemetry.propagate import get_global_textmap
            _propagator = get_global_textmap()
        except ImportError:
            _propagator = None
    return _propagator


def extract(headers: Mapping[str, str]) -> Any:
    """Extract a W3C Trace Context from inbound request headers.

    Returns an opaque OTel :class:`~opentelemetry.context.Context` object
    suitable for passing to ``tracer.start_as_current_span(..., context=ctx)``.
    When OTel isn't installed the function returns ``None`` — callers must
    tolerate that (spans can still start without an inbound parent).

    The header mapping is case-insensitive per the W3C spec; the OTel
    propagator already normalises keys, so passing a dict from FastAPI's
    ``request.headers`` works directly.
    """
    propagator = _get_propagator()
    if propagator is None:
        return None
    try:
        return propagator.extract(dict(headers))
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("W3C extract failed (non-critical): %s", exc)
        return None


def inject(
    headers: MutableMapping[str, str],
    *,
    context: Optional[Any] = None,
) -> None:
    """Inject the current (or provided) trace context into a headers dict.

    After the call, ``headers`` will contain ``traceparent`` (and possibly
    ``tracestate``) so that downstream services see the same trace. When
    OTel isn't installed, the function is a no-op — the outbound request
    goes out without trace headers and the downstream server will start
    its own trace.

    Pass ``context`` when the trace context isn't the currently-active
    OTel context (e.g. in tests or when bridging sync and async code).
    """
    propagator = _get_propagator()
    if propagator is None:
        return
    try:
        propagator.inject(headers, context=context)
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("W3C inject failed (non-critical): %s", exc)
