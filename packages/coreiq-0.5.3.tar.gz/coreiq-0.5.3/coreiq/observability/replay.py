"""Replay & Debug Console — replay past requests with modified parameters.

Stores request/response pairs and enables re-execution with different
models, prompts, or guardrail configs for debugging.

Usage::

    replay = ReplayEngine()
    replay.record(trace_id="abc", messages=[...], model="gpt-4o",
        response="...", tokens=500, cost=0.015)
    result = replay.replay("abc", model="gpt-4o-mini")
"""
from __future__ import annotations

import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ReplayRecord:
    trace_id: str
    messages: List[Dict[str, Any]]
    model: str
    response: str
    tokens: int = 0
    cost: float = 0.0
    latency_ms: int = 0
    guardrail_blocked: bool = False
    guardrail_reason: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    ts: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "model": self.model,
            "response_preview": self.response[:200] + "..." if len(self.response) > 200 else self.response,
            "tokens": self.tokens,
            "cost": round(self.cost, 4),
            "latency_ms": self.latency_ms,
            "guardrail_blocked": self.guardrail_blocked,
            "guardrail_reason": self.guardrail_reason,
            "message_count": len(self.messages),
            "ts": self.ts,
        }


@dataclass
class ReplayResult:
    original_trace_id: str
    replay_id: str
    original_model: str
    replay_model: str
    original_response: str
    replay_response: str
    original_cost: float
    replay_cost: float
    diff_summary: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_trace_id": self.original_trace_id,
            "replay_id": self.replay_id,
            "original_model": self.original_model,
            "replay_model": self.replay_model,
            "original_response_preview": self.original_response[:200],
            "replay_response_preview": self.replay_response[:200],
            "original_cost": round(self.original_cost, 4),
            "replay_cost": round(self.replay_cost, 4),
            "cost_difference": round(self.replay_cost - self.original_cost, 4),
            "diff_summary": self.diff_summary,
        }


class ReplayEngine:
    """Stores and replays past LLM requests for debugging."""

    def __init__(self, max_records: int = 10000):
        self._lock = threading.Lock()
        self._records: Dict[str, ReplayRecord] = {}
        self._max = max_records

    def record(
        self, trace_id: str, messages: List[Dict[str, Any]], model: str,
        response: str, tokens: int = 0, cost: float = 0.0, latency_ms: int = 0,
        guardrail_blocked: bool = False, guardrail_reason: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ReplayRecord:
        rec = ReplayRecord(
            trace_id=trace_id, messages=messages, model=model,
            response=response, tokens=tokens, cost=cost, latency_ms=latency_ms,
            guardrail_blocked=guardrail_blocked, guardrail_reason=guardrail_reason,
            metadata=metadata or {}, ts=datetime.now(timezone.utc).isoformat(),
        )
        with self._lock:
            if len(self._records) >= self._max:
                oldest = min(self._records, key=lambda k: self._records[k].ts)
                del self._records[oldest]
            self._records[trace_id] = rec
        return rec

    def get(self, trace_id: str) -> Optional[ReplayRecord]:
        return self._records.get(trace_id)

    def list_recent(self, limit: int = 50) -> List[Dict[str, Any]]:
        records = sorted(self._records.values(), key=lambda r: r.ts, reverse=True)[:limit]
        return [r.to_dict() for r in records]

    def replay(
        self, trace_id: str, *,
        replay_fn: Optional[Callable] = None,
        model: Optional[str] = None,
        modified_messages: Optional[List[Dict[str, Any]]] = None,
    ) -> ReplayResult:
        """Replay a past request with optional modifications.

        Args:
            trace_id: Original request trace ID.
            replay_fn: Function(messages, model) -> {"response": str, "cost": float}.
                If None, returns a dry-run comparison.
            model: Override model (default: same as original).
            modified_messages: Override messages (default: same as original).
        """
        rec = self._records.get(trace_id)
        if rec is None:
            raise ValueError(f"Trace '{trace_id}' not found")

        replay_model = model or rec.model
        replay_messages = modified_messages or rec.messages
        replay_id = str(uuid.uuid4())[:8]

        if replay_fn:
            result = replay_fn(replay_messages, replay_model)
            replay_response = result.get("response", "")
            replay_cost = result.get("cost", 0.0)
        else:
            replay_response = f"[dry-run] Would replay with model={replay_model}, {len(replay_messages)} messages"
            replay_cost = 0.0

        diff = ""
        if replay_response != rec.response:
            if len(replay_response) > len(rec.response) * 1.5:
                diff = "Replay response is significantly longer"
            elif len(replay_response) < len(rec.response) * 0.5:
                diff = "Replay response is significantly shorter"
            else:
                diff = "Responses differ"
        else:
            diff = "Responses are identical"

        return ReplayResult(
            original_trace_id=trace_id, replay_id=replay_id,
            original_model=rec.model, replay_model=replay_model,
            original_response=rec.response, replay_response=replay_response,
            original_cost=rec.cost, replay_cost=replay_cost, diff_summary=diff,
        )
