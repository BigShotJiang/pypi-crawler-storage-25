"""PII masking for observability pipelines.

Ported from sdk-go's PIIMaskingSpanProcessor. Integrates PII
detection with OpenTelemetry span attributes and Python logging.
"""
from __future__ import annotations
import logging
import re
from typing import Any

logger = logging.getLogger("coreiq.observability.masking")

# Patterns from sdk-go masking module
_JWT_RE = re.compile(r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+')
_BEARER_RE = re.compile(r'(?i)Bearer\s+\S+')
_EMAIL_RE = re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}')
_API_KEY_RE = re.compile(r'sk-[A-Za-z0-9_\-]{20,}')

_BLOCKED_FIELDS = frozenset({
    "password", "passwd", "secret", "token", "api_key", "apikey",
    "authorization", "auth", "private_key", "credential", "credentials",
    "access_key", "access_token", "refresh_token", "client_secret", "ssn",
})

def mask_value(value: str) -> str:
    """Mask PII in a string value. Returns [REDACTED] if sensitive content found."""
    if _JWT_RE.search(value):
        return "[JWT_REDACTED]"
    if _BEARER_RE.search(value):
        return "[BEARER_REDACTED]"
    if _API_KEY_RE.search(value):
        return "[API_KEY_REDACTED]"
    if _EMAIL_RE.search(value):
        return _EMAIL_RE.sub("[EMAIL_REDACTED]", value)
    return value

def is_blocked_field(name: str) -> bool:
    """Check if a field name should always be redacted."""
    return name.lower().replace("-", "_").replace(".", "_") in _BLOCKED_FIELDS

def mask_dict(data: dict) -> dict:
    """Mask PII in a dictionary (keys checked against blocked list, values scanned)."""
    result: dict[str, Any] = {}
    for k, v in data.items():
        if is_blocked_field(k):
            result[k] = "[REDACTED]"
        elif isinstance(v, str):
            result[k] = mask_value(v)
        elif isinstance(v, dict):
            result[k] = mask_dict(v)
        else:
            result[k] = v
    return result


class MaskingLogFilter(logging.Filter):
    """Logging filter that masks PII in log records.

    Attach to any logger: logger.addFilter(MaskingLogFilter())
    """
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = mask_value(record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = {k: mask_value(str(v)) if isinstance(v, str) else v for k, v in record.args.items()}
            elif isinstance(record.args, tuple):
                record.args = tuple(mask_value(str(a)) if isinstance(a, str) else a for a in record.args)
        return True
