"""Attribute mappers for non-trace CoreIQ events emitted to OpenTelemetry.

The :mod:`genai_attributes` module owns the ``gen_ai.*`` namespace for trace
spans. This module is its sibling for the **log-record** flavoured events that
the :class:`coreiq.store.backends.otel_backend.OtelBackend` emits — policy
decisions, security violations, and cost events. They live under the
``coreiq.*`` attribute namespace because they are CoreIQ extensions, not
standard semantic conventions.

Each class here mirrors the :class:`GenAIAttrs` pattern: a dataclass that
accepts the row dict CoreIQ already produces, and an :meth:`apply` /
:func:`from_row` that converts it into the flat ``{key: value}`` dictionary an
OTel ``LoggerProvider`` accepts via ``attributes=``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional

# ---------------------------------------------------------------------------
# Attribute name constants — single source of truth for the ``coreiq.*``
# namespace used by the OTel-only backend.
# ---------------------------------------------------------------------------

# Policy decisions
COREIQ_POLICY_ACTION = "coreiq.policy.action"
COREIQ_POLICY_RULE_ID = "coreiq.policy.rule_id"
COREIQ_POLICY_BUNDLE_ID = "coreiq.policy.bundle_id"
COREIQ_POLICY_TENANT_ID = "coreiq.policy.tenant_id"
COREIQ_POLICY_REASON = "coreiq.policy.reason"
COREIQ_POLICY_DECISION_ID = "coreiq.policy.decision_id"
COREIQ_POLICY_PRINCIPAL = "coreiq.policy.principal"

# Security violations
COREIQ_SECURITY_SEVERITY = "coreiq.security.severity"
COREIQ_SECURITY_CATEGORY = "coreiq.security.category"
COREIQ_SECURITY_DETAIL = "coreiq.security.detail"
COREIQ_SECURITY_TENANT_ID = "coreiq.security.tenant_id"
COREIQ_SECURITY_ACTION = "coreiq.security.action"

# Cost events
# Wave 2D: traces, log records and metrics all use the canonical OTel
# dotted form ``coreiq.cost.usd``. ``genai_attributes.COREIQ_COST_USD``
# was flipped from the legacy underscore form to match — both constants
# now resolve to the same string. Backwards-compat for the underscore key
# is intentionally NOT kept; downstream dashboards must update queries.
COREIQ_COST_USD = "coreiq.cost.usd"
COREIQ_COST_TOKENS_INPUT = "coreiq.cost.tokens.input"
COREIQ_COST_TOKENS_OUTPUT = "coreiq.cost.tokens.output"
COREIQ_COST_TOKENS_TOTAL = "coreiq.cost.tokens.total"
COREIQ_COST_MODEL = "coreiq.cost.model"
COREIQ_COST_PROVIDER = "coreiq.cost.provider"
COREIQ_COST_TENANT_ID = "coreiq.cost.tenant_id"


def _drop_none(d: dict[str, Any]) -> dict[str, Any]:
    """Return ``d`` without keys whose value is ``None`` or empty string."""
    return {k: v for k, v in d.items() if v is not None and v != ""}


# ---------------------------------------------------------------------------
# Policy decision
# ---------------------------------------------------------------------------


@dataclass
class PolicyDecisionAttrs:
    """OTel attributes for a CoreIQ ``policy_decisions`` row."""

    action: Optional[str] = None
    rule_id: Optional[str] = None
    bundle_id: Optional[str] = None
    tenant_id: Optional[str] = None
    reason: Optional[str] = None
    decision_id: Optional[str] = None
    principal: Optional[str] = None

    @classmethod
    def from_row(cls, row: Mapping[str, Any]) -> "PolicyDecisionAttrs":
        """Build attrs from a policy_decisions row (insert kwargs or DB row)."""
        # ``evaluated_rules_json`` is a JSON list — we keep the raw first
        # rule_id when present; consumers wanting full evaluation history
        # should query the DB-backed dashboard.
        rule_id = row.get("rule_id")
        if rule_id is None:
            rule_id = row.get("evaluated_rules") or row.get("evaluated_rules_json")
        return cls(
            action=row.get("action"),
            rule_id=str(rule_id) if rule_id is not None else None,
            bundle_id=row.get("bundle_id"),
            tenant_id=row.get("tenant_id"),
            reason=row.get("reason"),
            decision_id=row.get("decision_id") or row.get("id"),
            principal=row.get("principal"),
        )

    def apply(self) -> dict[str, Any]:
        """Return the flat attribute dict suitable for ``logger.emit``."""
        return _drop_none({
            COREIQ_POLICY_ACTION: self.action,
            COREIQ_POLICY_RULE_ID: self.rule_id,
            COREIQ_POLICY_BUNDLE_ID: self.bundle_id,
            COREIQ_POLICY_TENANT_ID: self.tenant_id,
            COREIQ_POLICY_REASON: self.reason,
            COREIQ_POLICY_DECISION_ID: self.decision_id,
            COREIQ_POLICY_PRINCIPAL: self.principal,
        })


# ---------------------------------------------------------------------------
# Security violation
# ---------------------------------------------------------------------------


@dataclass
class SecurityViolationAttrs:
    """OTel attributes for a CoreIQ ``security_violations`` row."""

    severity: Optional[str] = None
    category: Optional[str] = None
    detail: Optional[str] = None
    tenant_id: Optional[str] = None
    action: Optional[str] = None

    @classmethod
    def from_row(cls, row: Mapping[str, Any]) -> "SecurityViolationAttrs":
        return cls(
            severity=row.get("severity"),
            category=row.get("category"),
            detail=row.get("detail") or row.get("message") or row.get("details_json"),
            tenant_id=row.get("tenant_id"),
            action=row.get("action") or row.get("action_taken"),
        )

    def apply(self) -> dict[str, Any]:
        return _drop_none({
            COREIQ_SECURITY_SEVERITY: self.severity,
            COREIQ_SECURITY_CATEGORY: self.category,
            COREIQ_SECURITY_DETAIL: self.detail,
            COREIQ_SECURITY_TENANT_ID: self.tenant_id,
            COREIQ_SECURITY_ACTION: self.action,
        })


# ---------------------------------------------------------------------------
# Cost event
# ---------------------------------------------------------------------------


@dataclass
class CostEventAttrs:
    """OTel attributes for a CoreIQ cost roll-up event.

    The traces table embeds ``cost_usd`` + token counts inline, so cost events
    are derived from a trace row at write time. ``tokens_total`` is computed
    when only input + output are supplied.
    """

    usd: Optional[float] = None
    tokens_input: Optional[int] = None
    tokens_output: Optional[int] = None
    tokens_total: Optional[int] = None
    model: Optional[str] = None
    provider: Optional[str] = None
    tenant_id: Optional[str] = None

    @classmethod
    def from_row(cls, row: Mapping[str, Any]) -> "CostEventAttrs":
        ti = row.get("tokens_input")
        if ti is None:
            ti = row.get("input_tok")
        if ti is None:
            ti = row.get("input_tokens")
        to = row.get("tokens_output")
        if to is None:
            to = row.get("output_tok")
        if to is None:
            to = row.get("output_tokens")
        tt = row.get("tokens_total")
        if tt is None and ti is not None and to is not None:
            tt = int(ti) + int(to)
        return cls(
            usd=row.get("cost_usd") if row.get("cost_usd") is not None else row.get("usd"),
            tokens_input=int(ti) if ti is not None else None,
            tokens_output=int(to) if to is not None else None,
            tokens_total=int(tt) if tt is not None else None,
            model=row.get("model"),
            provider=row.get("provider"),
            tenant_id=row.get("tenant_id"),
        )

    def apply(self) -> dict[str, Any]:
        return _drop_none({
            COREIQ_COST_USD: self.usd,
            COREIQ_COST_TOKENS_INPUT: self.tokens_input,
            COREIQ_COST_TOKENS_OUTPUT: self.tokens_output,
            COREIQ_COST_TOKENS_TOTAL: self.tokens_total,
            COREIQ_COST_MODEL: self.model,
            COREIQ_COST_PROVIDER: self.provider,
            COREIQ_COST_TENANT_ID: self.tenant_id,
        })


__all__ = [
    "PolicyDecisionAttrs",
    "SecurityViolationAttrs",
    "CostEventAttrs",
    # Policy
    "COREIQ_POLICY_ACTION",
    "COREIQ_POLICY_RULE_ID",
    "COREIQ_POLICY_BUNDLE_ID",
    "COREIQ_POLICY_TENANT_ID",
    "COREIQ_POLICY_REASON",
    "COREIQ_POLICY_DECISION_ID",
    "COREIQ_POLICY_PRINCIPAL",
    # Security
    "COREIQ_SECURITY_SEVERITY",
    "COREIQ_SECURITY_CATEGORY",
    "COREIQ_SECURITY_DETAIL",
    "COREIQ_SECURITY_TENANT_ID",
    "COREIQ_SECURITY_ACTION",
    # Cost
    "COREIQ_COST_USD",
    "COREIQ_COST_TOKENS_INPUT",
    "COREIQ_COST_TOKENS_OUTPUT",
    "COREIQ_COST_TOKENS_TOTAL",
    "COREIQ_COST_MODEL",
    "COREIQ_COST_PROVIDER",
    "COREIQ_COST_TENANT_ID",
]
