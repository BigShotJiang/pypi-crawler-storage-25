"""OpenTelemetry GenAI metrics instruments.

Emits the GenAI metrics defined in the semantic conventions spec —
token usage histogram, TTFT histogram, and time-per-output-token histogram.
These are independent from trace spans: a single LLM call produces one
span AND populates every histogram, so a backend that only scrapes
metrics (Prometheus, Datadog metrics) still gets the full latency/usage
picture without parsing spans.

This module is the other half of the OTel integration started in
:mod:`coreiq.observability.otel_exporter` (which handles traces). Metrics
are only configured when ``configure_meter()`` is explicitly called with
an OTLP endpoint — calling it with ``export=False`` or omitting it
altogether produces no-op instruments that every ``record()`` call
silently ignores.

Usage
-----

::

    from coreiq.observability.metrics_genai import (
        configure_meter, record_token_usage, record_ttft, record_tpot,
    )

    configure_meter(endpoint="http://otel-collector:4317")

    # In the proxy pipeline after a provider call:
    record_token_usage(
        system="openai",
        model="gpt-4o",
        operation="chat",
        input_tokens=42,
        output_tokens=17,
    )
    record_ttft(system="openai", model="gpt-4o", operation="chat", ttft_ms=48)
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger("coreiq.observability.metrics_genai")

# Metric names from the GenAI semconv spec.
METRIC_TOKEN_USAGE = "gen_ai.client.token.usage"
METRIC_TIME_TO_FIRST_TOKEN = "gen_ai.server.time_to_first_token"
METRIC_TIME_PER_OUTPUT_TOKEN = "gen_ai.server.time_per_output_token"

# Module-level instruments (populated by configure_meter).
_configured = False
_meter_provider: Any = None
_token_usage_hist: Any = None
_ttft_hist: Any = None
_tpot_hist: Any = None


def configure_meter(
    endpoint: str = "http://localhost:4317",
    protocol: str = "grpc",
    service_name: str = "coreiq",
    export_interval_ms: int = 5_000,
    export_timeout_ms: int = 5_000,
) -> None:
    """Configure OTLP metrics export for CoreIQ GenAI histograms.

    Call this once at startup, AFTER :func:`coreiq.observability.configure_otel`
    or on its own. Safe to call multiple times — subsequent calls replace
    the previous provider.

    When OTel isn't installed, the function logs a warning and returns
    cleanly; record_* calls become no-ops.
    """
    global _configured, _meter_provider, _token_usage_hist, _ttft_hist, _tpot_hist
    try:
        from opentelemetry import metrics
        from opentelemetry.sdk.metrics import MeterProvider
        from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
        from opentelemetry.sdk.resources import Resource, SERVICE_NAME
    except ImportError:
        logger.warning(
            "GenAI metrics require opentelemetry-sdk. "
            "Install with: pip install coreiq[otel]"
        )
        return

    exporter = _build_metric_exporter(endpoint, protocol, export_timeout_ms)
    if exporter is None:
        return

    reader = PeriodicExportingMetricReader(
        exporter,
        export_interval_millis=export_interval_ms,
        export_timeout_millis=export_timeout_ms,
    )
    resource = Resource.create({SERVICE_NAME: service_name})
    provider = MeterProvider(resource=resource, metric_readers=[reader])
    metrics.set_meter_provider(provider)
    _meter_provider = provider

    meter = metrics.get_meter("coreiq.genai", schema_url="https://opentelemetry.io/schemas/1.28.0")

    _token_usage_hist = meter.create_histogram(
        name=METRIC_TOKEN_USAGE,
        description="Measures the number of input and output tokens used per GenAI request.",
        unit="{token}",
    )
    _ttft_hist = meter.create_histogram(
        name=METRIC_TIME_TO_FIRST_TOKEN,
        description="Time from request dispatch to first output token in a streaming response.",
        unit="s",
    )
    _tpot_hist = meter.create_histogram(
        name=METRIC_TIME_PER_OUTPUT_TOKEN,
        description="Average time per output token in a streaming response.",
        unit="s",
    )

    _configured = True
    logger.info("CoreIQ GenAI metrics configured → %s (%s)", endpoint, protocol)


def _build_metric_exporter(endpoint: str, protocol: str, timeout_ms: int) -> Any:
    """Build the OTLP metric exporter for the requested protocol."""
    try:
        if protocol == "grpc":
            from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
                OTLPMetricExporter,
            )
            return OTLPMetricExporter(
                endpoint=endpoint,
                timeout=max(1, timeout_ms // 1000),
            )
        from opentelemetry.exporter.otlp.proto.http.metric_exporter import (  # type: ignore[assignment,unused-ignore]
            OTLPMetricExporter,
        )
        http_endpoint = endpoint.rstrip("/") + "/v1/metrics"
        return OTLPMetricExporter(
            endpoint=http_endpoint,
            timeout=max(1, timeout_ms // 1000),
        )
    except ImportError as exc:
        logger.warning("OTel metric exporter not available: %s", exc)
        return None


def is_configured() -> bool:
    """Return True if GenAI metrics have been wired up."""
    return _configured


def record_token_usage(
    *,
    system: str,
    model: str,
    operation: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
) -> None:
    """Record a token usage datapoint for a completed request.

    Emits two histogram observations (one for input tokens, one for
    output tokens) with the ``gen_ai.token.type`` attribute distinguishing
    them — matching the shape the GenAI semconv spec defines.
    """
    if not _configured or _token_usage_hist is None:
        return
    base: dict[str, Any] = {
        "gen_ai.system": system,
        "gen_ai.request.model": model,
        "gen_ai.operation.name": operation,
    }
    try:
        if input_tokens:
            _token_usage_hist.record(
                input_tokens,
                attributes={**base, "gen_ai.token.type": "input"},
            )
        if output_tokens:
            _token_usage_hist.record(
                output_tokens,
                attributes={**base, "gen_ai.token.type": "output"},
            )
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("record_token_usage failed: %s", exc)


def record_ttft(
    *,
    system: str,
    model: str,
    operation: str,
    ttft_ms: Optional[float],
) -> None:
    """Record a time-to-first-token observation (in seconds).

    The input is milliseconds because that's what the streaming layer
    already tracks; this function converts to seconds to match the
    semconv unit.
    """
    if not _configured or _ttft_hist is None or ttft_ms is None:
        return
    try:
        _ttft_hist.record(
            float(ttft_ms) / 1000.0,
            attributes={
                "gen_ai.system": system,
                "gen_ai.request.model": model,
                "gen_ai.operation.name": operation,
            },
        )
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("record_ttft failed: %s", exc)


def record_tpot(
    *,
    system: str,
    model: str,
    operation: str,
    tpot_ms: Optional[float],
) -> None:
    """Record a time-per-output-token observation (in seconds)."""
    if not _configured or _tpot_hist is None or tpot_ms is None:
        return
    try:
        _tpot_hist.record(
            float(tpot_ms) / 1000.0,
            attributes={
                "gen_ai.system": system,
                "gen_ai.request.model": model,
                "gen_ai.operation.name": operation,
            },
        )
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("record_tpot failed: %s", exc)
