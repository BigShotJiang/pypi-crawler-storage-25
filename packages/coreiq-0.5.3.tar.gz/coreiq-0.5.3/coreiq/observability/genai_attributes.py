"""Central mapping of CoreIQ internal span data to OpenTelemetry GenAI
semantic conventions.

The GenAI semantic conventions
(https://opentelemetry.io/docs/specs/semconv/gen-ai/) define a stable set of
``gen_ai.*`` attributes that every observability consumer (Datadog,
Honeycomb, Langfuse, Arize, Jaeger, Grafana Tempo) understands. This module
is the single place that owns the attribute names and their CoreIQ
counterparts — every caller that wants to emit a GenAI span should go
through :func:`apply` instead of hard-coding attribute strings.

Why this module exists
----------------------
Before this refactor, ``otel_exporter.py`` set ``gen_ai.*`` attributes
inline in ``emit_span()``. That made it impossible for *other* callers
(the proxy pipeline, framework adapters, the MCP server) to emit spans
with consistent attributes without duplicating the mapping. Centralising
the mapping here lets every caller build a consistent GenAI-semconv span
with one function call.

Usage
-----

::

    from opentelemetry import trace
    from coreiq.observability.genai_attributes import apply, GenAIAttrs

    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("gen_ai.chat") as span:
        apply(span, GenAIAttrs(
            operation="chat",
            system="openai",
            request_model="gpt-4o",
            input_tokens=42,
            output_tokens=17,
            finish_reasons=["stop"],
            latency_ms=315,
            ttft_ms=48,
        ))
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from opentelemetry.trace import Span


# ---------------------------------------------------------------------------
# Attribute name constants
# ---------------------------------------------------------------------------
#
# These are lifted directly from the OpenTelemetry GenAI semantic
# conventions spec (v1.28+). We hard-code the strings rather than importing
# ``opentelemetry.semconv.ai`` because the `opentelemetry-semantic-conventions-ai`
# package is still experimental and versioning has broken imports in the past.
# Hard-coding the strings here means the module is importable even when the
# semconv package isn't installed, and the strings are in ONE place for easy
# updates when the spec moves.

# --- Request attributes -----------------------------------------------------
GEN_AI_SYSTEM = "gen_ai.system"  # "openai" | "anthropic" | "google" | ...
GEN_AI_OPERATION_NAME = "gen_ai.operation.name"  # "chat" | "embedding" | "tool"
GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
GEN_AI_REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
GEN_AI_REQUEST_TEMPERATURE = "gen_ai.request.temperature"
GEN_AI_REQUEST_TOP_P = "gen_ai.request.top_p"

# --- Response attributes ----------------------------------------------------
GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"
GEN_AI_RESPONSE_ID = "gen_ai.response.id"
GEN_AI_RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"

# --- Usage (tokens) ---------------------------------------------------------
GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
GEN_AI_USAGE_CACHED_INPUT_TOKENS = "gen_ai.usage.cached_input_tokens"

# --- CoreIQ extensions ------------------------------------------------------
# These are not in the spec — they're prefixed `coreiq.*` so they don't
# collide with standard attributes.
COREIQ_LATENCY_MS = "coreiq.latency_ms"
COREIQ_TTFT_MS = "coreiq.ttft_ms"
COREIQ_TPOT_MS = "coreiq.time_per_output_token_ms"
COREIQ_CACHE_HIT = "coreiq.cache_hit"
# Wave 2D: aligned to the canonical OTel dotted form ``coreiq.cost.usd`` so
# trace spans, log records and metric attributes share one key. Honeycomb /
# Datadog / Langfuse queries can now select ``coreiq.cost.usd`` without
# branching on signal type. The legacy underscore form (``coreiq.cost_usd``)
# is retired — flag in dashboard queries before upgrading.
COREIQ_COST_USD = "coreiq.cost.usd"
COREIQ_TENANT_ID = "coreiq.tenant_id"
COREIQ_VIRTUAL_KEY_ID = "coreiq.virtual_key_id"
COREIQ_VARIANT_ID = "coreiq.variant_id"
COREIQ_FUNCTION_ID = "coreiq.function_id"


@dataclass
class GenAIAttrs:
    """All the GenAI + CoreIQ attributes a single span can carry.

    Every field is optional. :func:`apply` only sets attributes whose
    values are non-None / truthy, so a consumer with partial data (e.g.
    a cache hit with no provider call) can still produce a valid span.
    """

    # Request
    system: Optional[str] = None                 # gen_ai.system
    operation: Optional[str] = None              # gen_ai.operation.name
    request_model: Optional[str] = None          # gen_ai.request.model
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None

    # Response
    response_model: Optional[str] = None
    response_id: Optional[str] = None
    finish_reasons: list[str] = field(default_factory=list)

    # Usage
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    cached_input_tokens: Optional[int] = None

    # CoreIQ-specific
    latency_ms: Optional[int] = None
    ttft_ms: Optional[int] = None
    tpot_ms: Optional[float] = None
    cache_hit: Optional[bool] = None
    cost_usd: Optional[float] = None
    tenant_id: Optional[str] = None
    virtual_key_id: Optional[str] = None
    variant_id: Optional[str] = None
    function_id: Optional[str] = None

    # Arbitrary extras — typically for adapter-specific attributes.
    extra: dict[str, Any] = field(default_factory=dict)


def apply(span: "Span", attrs: GenAIAttrs) -> None:
    """Apply the given :class:`GenAIAttrs` to the span.

    Only sets attributes whose values are non-None and non-empty. This
    means the span accurately reflects what data the caller had — a cache
    hit with no provider call can still produce a valid span with
    ``gen_ai.operation.name="chat"`` and ``coreiq.cache_hit=True`` without
    any ``gen_ai.usage.*`` attributes.

    The function never raises: if ``span`` is a no-op span (observability
    disabled), every ``set_attribute`` call is cheap and safe.
    """
    # Request
    _set_if(span, GEN_AI_SYSTEM, attrs.system)
    _set_if(span, GEN_AI_OPERATION_NAME, attrs.operation)
    _set_if(span, GEN_AI_REQUEST_MODEL, attrs.request_model)
    _set_if(span, GEN_AI_REQUEST_MAX_TOKENS, attrs.max_tokens)
    _set_if(span, GEN_AI_REQUEST_TEMPERATURE, attrs.temperature)
    _set_if(span, GEN_AI_REQUEST_TOP_P, attrs.top_p)

    # Response
    _set_if(span, GEN_AI_RESPONSE_MODEL, attrs.response_model)
    _set_if(span, GEN_AI_RESPONSE_ID, attrs.response_id)
    if attrs.finish_reasons:
        # The spec says this is a string array.
        span.set_attribute(GEN_AI_RESPONSE_FINISH_REASONS, list(attrs.finish_reasons))

    # Usage
    _set_if(span, GEN_AI_USAGE_INPUT_TOKENS, attrs.input_tokens)
    _set_if(span, GEN_AI_USAGE_OUTPUT_TOKENS, attrs.output_tokens)
    _set_if(span, GEN_AI_USAGE_CACHED_INPUT_TOKENS, attrs.cached_input_tokens)

    # CoreIQ-specific
    _set_if(span, COREIQ_LATENCY_MS, attrs.latency_ms)
    _set_if(span, COREIQ_TTFT_MS, attrs.ttft_ms)
    _set_if(span, COREIQ_TPOT_MS, attrs.tpot_ms)
    if attrs.cache_hit is not None:
        span.set_attribute(COREIQ_CACHE_HIT, bool(attrs.cache_hit))
    _set_if(span, COREIQ_COST_USD, attrs.cost_usd)
    _set_if(span, COREIQ_TENANT_ID, attrs.tenant_id)
    _set_if(span, COREIQ_VIRTUAL_KEY_ID, attrs.virtual_key_id)
    _set_if(span, COREIQ_VARIANT_ID, attrs.variant_id)
    _set_if(span, COREIQ_FUNCTION_ID, attrs.function_id)

    # Extras — caller can pass adapter-specific attributes.
    for key, value in attrs.extra.items():
        if value is not None:
            span.set_attribute(key, value)


def _set_if(span: "Span", key: str, value: Any) -> None:
    """Set ``key=value`` on the span only when value is non-None and non-empty.

    Empty strings and zero values are considered missing data and skipped
    so the span doesn't claim "the model answered in 0ms" when the caller
    simply didn't measure it.
    """
    if value is None:
        return
    if isinstance(value, str) and not value:
        return
    if isinstance(value, (int, float)) and value == 0:
        return
    span.set_attribute(key, value)
