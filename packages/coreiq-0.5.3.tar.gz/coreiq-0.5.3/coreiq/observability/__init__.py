from .tracer import Tracer, get_tracer
from .adapter import ObservabilityAdapter, CoreIQObservabilityAdapter

try:
    from .otel_exporter import configure_otel, is_configured as otel_is_configured
    _has_otel = True
except ImportError:
    _has_otel = False

try:
    from .prometheus import configure_prometheus, generate_metrics
    _has_prometheus = True
except ImportError:
    _has_prometheus = False

__all__ = ["Tracer", "get_tracer", "ObservabilityAdapter", "CoreIQObservabilityAdapter"]

if _has_otel:
    __all__ += ["configure_otel", "otel_is_configured"]
if _has_prometheus:
    __all__ += ["configure_prometheus", "generate_metrics"]
