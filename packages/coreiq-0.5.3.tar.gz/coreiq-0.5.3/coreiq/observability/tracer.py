import uuid
from typing import Optional

from ..store.writer import get_writer
from ..tracing import (
    get_current_span_id,
    get_current_session_id, get_current_agent_run_id,
    SpanKind,
)


class Tracer:
    def record_request(
        self,
        *,
        model: str,
        provider: str,
        input_tok: int,
        output_tok: int,
        latency_ms: int,
        finish_reason: str = "stop",
        cache_hit: bool = False,
        request_id: Optional[str] = None,
        # Span hierarchy fields (new — all optional for backwards compatibility)
        span_kind: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        agent_run_id: Optional[str] = None,
        session_id: Optional[str] = None,
        attributes_json: Optional[str] = None,
    ) -> str:
        rid = request_id or str(uuid.uuid4())
        # Auto-pick up context from ContextVars if not explicitly provided
        _session_id = session_id or get_current_session_id()
        _agent_run_id = agent_run_id or get_current_agent_run_id()
        _parent_span_id = parent_span_id or get_current_span_id()
        _span_kind = span_kind or SpanKind.LLM.value

        get_writer().insert_trace(
            id=rid,
            model=model,
            provider=provider,
            input_tok=input_tok,
            output_tok=output_tok,
            latency_ms=latency_ms,
            finish_reason=finish_reason,
            cache_hit=cache_hit,
            session_id=_session_id,
            # Pass extra fields via meta_json for now (db migration adds columns)
            meta_json=None,
        )
        # OTel emit commented out — not used
        # try:
        #     from .otel_exporter import is_configured, emit_span
        #     if is_configured():
        #         emit_span(...)
        # except Exception:
        #     pass

        # Record Prometheus metrics if configured (best-effort)
        try:
            from .prometheus import is_configured as prom_configured, record_request
            if prom_configured():
                record_request(
                    model=model,
                    provider=provider,
                    input_tokens=input_tok,
                    output_tokens=output_tok,
                    latency_ms=latency_ms,
                    cache_hit=cache_hit,
                )
        except Exception:
            pass

        return rid


_tracer: Optional[Tracer] = None


def get_tracer() -> Tracer:
    global _tracer
    if _tracer is None:
        _tracer = Tracer()
    return _tracer
