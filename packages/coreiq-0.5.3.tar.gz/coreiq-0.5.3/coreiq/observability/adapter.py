from __future__ import annotations
import uuid
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@runtime_checkable
class ObservabilityAdapter(Protocol):
    """Standard interface for LLM call capture (inspired by PraisonAI).

    External frameworks implement this protocol to feed data into
    CoreIQ's observability pipeline without going through the proxy.
    """

    def on_llm_start(self, model: str, messages: list[dict],
                     metadata: dict | None = None) -> str:
        """Called before LLM call. Returns call_id."""
        ...

    def on_llm_end(self, call_id: str, response: str, usage: dict,
                   latency_ms: int) -> None:
        """Called after successful LLM call. usage = {input_tokens, output_tokens, cost_usd}."""
        ...

    def on_llm_error(self, call_id: str, error: Exception) -> None:
        """Called on LLM error."""
        ...

    def on_tool_start(self, tool_name: str, args: dict) -> str:
        """Returns call_id."""
        ...

    def on_tool_end(self, call_id: str, result: str, duration_ms: int) -> None:
        ...


class CoreIQObservabilityAdapter:
    """Concrete implementation that writes to CoreIQ's EventWriter."""

    def __init__(self, tenant_id: str = "default", session_id: str | None = None):
        from ..store.writer import get_writer
        self._writer = get_writer()
        self.tenant_id = tenant_id
        self.session_id = session_id
        self._pending: dict[str, dict] = {}  # call_id -> metadata

    def on_llm_start(self, model: str, messages: list[dict],
                     metadata: dict | None = None) -> str:
        call_id = f"obs-{uuid.uuid4().hex[:16]}"
        import time
        self._pending[call_id] = {
            "model": model,
            "start": time.monotonic(),
            "metadata": metadata or {},
        }
        return call_id

    def on_llm_end(self, call_id: str, response: str, usage: dict,
                   latency_ms: int) -> None:
        import json
        pending = self._pending.pop(call_id, {})
        model = pending.get("model", "unknown")
        # Parse provider from model string (e.g. "openai/gpt-4o" -> "openai")
        parts = model.split("/", 1)
        provider = parts[0] if len(parts) > 1 else "unknown"
        model_name = parts[1] if len(parts) > 1 else model

        self._writer.insert_trace(
            id=call_id,
            model=model_name,
            provider=provider,
            input_tok=usage.get("input_tokens", 0),
            output_tok=usage.get("output_tokens", 0),
            latency_ms=latency_ms,
            finish_reason="stop",
            tenant_id=self.tenant_id,
            session_id=self.session_id,
            meta_json=json.dumps({
                "cost_usd": usage.get("cost_usd", 0),
                "source": "observability_adapter",
                **pending.get("metadata", {}),
            }),
        )

    def on_llm_error(self, call_id: str, error: Exception) -> None:
        pending = self._pending.pop(call_id, {})
        model = pending.get("model", "unknown")
        parts = model.split("/", 1)
        provider = parts[0] if len(parts) > 1 else "unknown"
        model_name = parts[1] if len(parts) > 1 else model
        import json
        self._writer.insert_trace(
            id=call_id,
            model=model_name,
            provider=provider,
            input_tok=0,
            output_tok=0,
            latency_ms=0,
            finish_reason="error",
            tenant_id=self.tenant_id,
            meta_json=json.dumps({"error": str(error), "source": "observability_adapter"}),
        )

    def on_tool_start(self, tool_name: str, args: dict) -> str:
        call_id = f"tool-{uuid.uuid4().hex[:16]}"
        import json
        self._writer.insert_tool_call(
            trace_id=call_id,
            tool_name=tool_name,
            args_json=json.dumps(args),
            id=call_id,
        )
        return call_id

    def on_tool_end(self, call_id: str, result: str, duration_ms: int) -> None:
        import json
        # Update the tool call with result and duration
        from ..store.db import get_shared_connection
        conn = get_shared_connection()
        conn.execute(
            "UPDATE tool_calls SET result_json=?, duration_ms=? WHERE id=?",
            (json.dumps(result), duration_ms, call_id),
        )
        conn.commit()
