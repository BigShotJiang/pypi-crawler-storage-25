"""CoreIQ drop-in SDK.

Public surface:
    install(proxy_url=..., api_key=..., providers=...) -> None
    uninstall() -> None
    ProxyError — raised on 4xx/5xx responses from the CoreIQ proxy.
"""

from .errors import ProxyError
from .install import install, uninstall

__all__ = ["install", "uninstall", "ProxyError"]
