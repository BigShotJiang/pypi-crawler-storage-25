"""Drop-in monkey-patch installer for OpenAI / Anthropic SDK clients.

Calling :func:`install` rebinds the ``__init__`` of ``openai.OpenAI`` and
``anthropic.Anthropic`` so that any client constructed *without* an explicit
``base_url`` is transparently routed through a CoreIQ proxy. Existing
applications can adopt CoreIQ governance with a single import line and no
further refactor.

Resolution precedence for ``proxy_url``:
    1. argument to :func:`install`
    2. ``COREIQ_PROXY_URL`` environment variable
    3. ``http://localhost:7823/v1``

Resolution precedence for ``api_key``:
    1. argument to :func:`install`
    2. ``COREIQ_API_KEY`` environment variable
    3. ``~/.coreiq/credentials`` (JSON, ``key`` field)

The installer is idempotent and threadsafe; it can be called repeatedly with
the same parameters without effect, or :func:`uninstall` can be used to
restore the original constructors.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Optional, Tuple

from .errors import ProxyError

logger = logging.getLogger("coreiq.sdk")

DEFAULT_PROXY_URL = "http://localhost:7823/v1"
_CREDENTIALS_PATH = "~/.coreiq/credentials"


@dataclass
class _State:
    """Module-level installation state.

    Holds the original ``__init__`` references so :func:`uninstall` can
    restore them, plus the resolved configuration of the active install.
    """

    installed: bool = False
    proxy_url: Optional[str] = None
    api_key: Optional[str] = None
    providers: Tuple[str, ...] = ()
    originals: dict[str, Callable[..., Any]] = field(default_factory=dict)


_state = _State()
_lock = threading.Lock()


def _parse_expires_at(value: Any) -> Optional[datetime]:
    """Best-effort parse of ``expires_at`` as ISO-8601 or epoch.

    Returns ``None`` when the value is missing or unparseable (which means
    "no known expiry" — the credential is not skipped).
    """
    if value is None or value == "":
        return None
    # epoch (int or numeric string)
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(float(value), tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        # numeric epoch as string
        try:
            return datetime.fromtimestamp(float(s), tz=timezone.utc)
        except ValueError:
            pass
        # ISO-8601; accept trailing 'Z'
        try:
            iso = s.replace("Z", "+00:00")
            dt = datetime.fromisoformat(iso)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            return None
    return None


def _load_credentials() -> Optional[str]:
    """Return the ``key`` field from ``~/.coreiq/credentials`` or ``None``.

    Behaviour:
    - Missing / unreadable / malformed file → ``None`` (no warning).
    - Credential whose ``expires_at`` is in the past or within the next 24h
      → ``None`` plus a clear warning instructing the user to re-run
      ``coreiq login``. This prevents stale keys from being silently used
      once they have expired or are about to.
    """

    try:
        path = Path(os.path.expanduser(_CREDENTIALS_PATH))
        if not path.is_file():
            return None
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        key = data.get("key")
        if not (isinstance(key, str) and key):
            return None
        expires_at = _parse_expires_at(data.get("expires_at"))
        if expires_at is not None:
            now = datetime.now(timezone.utc)
            if expires_at <= now:
                logger.warning(
                    "coreiq: stored credential expired — run 'coreiq login' to refresh"
                )
                return None
            if expires_at - now <= timedelta(hours=24):
                logger.warning(
                    "coreiq: stored credential expires within 24h — run 'coreiq login' to refresh"
                )
                return None
        return key
    except (OSError, ValueError, json.JSONDecodeError):
        return None


def _redact_url_credentials(url: str) -> str:
    """Return ``url`` with any embedded userinfo (``user:pass@``) stripped.

    URLs like ``http://sk-coreiq-xxx@host/v1`` or ``http://u:p@host/v1``
    can leak secrets if logged verbatim. This rebuilds the URL without
    the userinfo segment. Inputs that don't parse cleanly are returned
    unchanged (best-effort — callers must not rely on this for security
    boundaries; it's a defensive log-time scrub).
    """
    if not url:
        return url
    try:
        parts = urllib.parse.urlsplit(url)
    except (ValueError, TypeError):
        return url
    if not (parts.username or parts.password):
        return url
    # Rebuild netloc without userinfo.
    host = parts.hostname or ""
    if parts.port is not None:
        netloc = f"{host}:{parts.port}"
    else:
        netloc = host
    return urllib.parse.urlunsplit(
        (parts.scheme, netloc, parts.path, parts.query, parts.fragment)
    )


def _resolve_proxy_url(arg: Optional[str]) -> str:
    if arg:
        return arg
    env = os.environ.get("COREIQ_PROXY_URL")
    if env:
        return env
    return DEFAULT_PROXY_URL


def _resolve_api_key(arg: Optional[str]) -> Optional[str]:
    if arg:
        return arg
    env = os.environ.get("COREIQ_API_KEY")
    if env:
        return env
    return _load_credentials()


def _make_response_hook(proxy_url: str) -> Callable[[Any], None]:
    """Build an httpx response event hook that raises :class:`ProxyError` on 4xx/5xx.

    The hook intentionally consumes the response body via ``response.read()``
    before raising so that ``ProxyError.detail`` carries the proxy's error
    payload (which is usually a structured policy/auth message).
    """

    def _hook(response: Any) -> None:
        try:
            status = int(getattr(response, "status_code", 0))
        except (TypeError, ValueError):
            return
        if status < 400:
            return
        detail = ""
        try:
            response.read()
            detail = response.text or ""
        except Exception:
            try:
                detail = getattr(response, "text", "") or ""
            except Exception:
                detail = ""
        # Trim absurdly large bodies — the actionable bit is the first line.
        if len(detail) > 1000:
            detail = detail[:1000] + "...(truncated)"
        raise ProxyError(status_code=status, detail=detail, proxy_url=proxy_url)

    return _hook


def _make_async_response_hook(proxy_url: str) -> Callable[[Any], Any]:
    """Async variant of :func:`_make_response_hook` for ``httpx.AsyncClient``."""

    async def _hook(response: Any) -> None:
        try:
            status = int(getattr(response, "status_code", 0))
        except (TypeError, ValueError):
            return
        if status < 400:
            return
        detail = ""
        try:
            await response.aread()
            detail = response.text or ""
        except Exception:
            try:
                detail = getattr(response, "text", "") or ""
            except Exception:
                detail = ""
        if len(detail) > 1000:
            detail = detail[:1000] + "...(truncated)"
        raise ProxyError(status_code=status, detail=detail, proxy_url=proxy_url)

    return _hook


def _build_http_client(proxy_url: str, *, async_client: bool = False) -> Any:
    """Construct an httpx (Async)Client with a CoreIQ ProxyError event hook.

    Returns ``None`` when httpx is unavailable so callers can fall back to the
    SDK's default client.
    """
    try:
        import httpx  # noqa: WPS433
    except Exception:  # pragma: no cover - httpx missing
        return None
    if async_client:
        return httpx.AsyncClient(event_hooks={"response": [_make_async_response_hook(proxy_url)]})
    return httpx.Client(event_hooks={"response": [_make_response_hook(proxy_url)]})


def _wrap_openai(
    original: Callable[..., None],
    proxy_url: str,
    api_key: Optional[str],
    *,
    async_client: bool = False,
) -> Callable[..., None]:
    def __init__(self: Any, *args: Any, **kwargs: Any) -> None:
        if "base_url" not in kwargs or kwargs.get("base_url") is None:
            kwargs["base_url"] = proxy_url
        if api_key is not None and ("api_key" not in kwargs or kwargs.get("api_key") is None):
            kwargs["api_key"] = api_key
        if "http_client" not in kwargs or kwargs.get("http_client") is None:
            client = _build_http_client(proxy_url, async_client=async_client)
            if client is not None:
                kwargs["http_client"] = client
        original(self, *args, **kwargs)

    __init__.__wrapped__ = original  # type: ignore[attr-defined]
    __init__.__coreiq_patched__ = True  # type: ignore[attr-defined]
    return __init__


def _wrap_anthropic(
    original: Callable[..., None],
    proxy_url: str,
    api_key: Optional[str],
    *,
    async_client: bool = False,
) -> Callable[..., None]:
    def __init__(self: Any, *args: Any, **kwargs: Any) -> None:
        if "base_url" not in kwargs or kwargs.get("base_url") is None:
            kwargs["base_url"] = proxy_url
        if api_key is not None and ("api_key" not in kwargs or kwargs.get("api_key") is None):
            kwargs["api_key"] = api_key
        if "http_client" not in kwargs or kwargs.get("http_client") is None:
            client = _build_http_client(proxy_url, async_client=async_client)
            if client is not None:
                kwargs["http_client"] = client
        original(self, *args, **kwargs)

    __init__.__wrapped__ = original  # type: ignore[attr-defined]
    __init__.__coreiq_patched__ = True  # type: ignore[attr-defined]
    return __init__


def _patch_openai(proxy_url: str, api_key: Optional[str]) -> Optional[Callable[..., None]]:
    try:
        import openai  # noqa: WPS433
    except Exception:  # pragma: no cover - openai missing
        return None
    original = openai.OpenAI.__init__
    openai.OpenAI.__init__ = _wrap_openai(original, proxy_url, api_key)  # type: ignore[method-assign]
    return original


def _patch_openai_async(proxy_url: str, api_key: Optional[str]) -> Optional[Callable[..., None]]:
    try:
        import openai  # noqa: WPS433
    except Exception:  # pragma: no cover - openai missing
        return None
    cls = getattr(openai, "AsyncOpenAI", None)
    if cls is None:  # pragma: no cover - older openai SDK
        return None
    original = cls.__init__
    cls.__init__ = _wrap_openai(original, proxy_url, api_key, async_client=True)  # type: ignore[method-assign]
    return original


def _patch_anthropic(proxy_url: str, api_key: Optional[str]) -> Optional[Callable[..., None]]:
    try:
        import anthropic  # noqa: WPS433
    except Exception:  # pragma: no cover - anthropic missing
        return None
    original = anthropic.Anthropic.__init__
    anthropic.Anthropic.__init__ = _wrap_anthropic(original, proxy_url, api_key)  # type: ignore[method-assign]
    return original


def _patch_anthropic_async(proxy_url: str, api_key: Optional[str]) -> Optional[Callable[..., None]]:
    try:
        import anthropic  # noqa: WPS433
    except Exception:  # pragma: no cover - anthropic missing
        return None
    cls = getattr(anthropic, "AsyncAnthropic", None)
    if cls is None:  # pragma: no cover - older anthropic SDK
        return None
    original = cls.__init__
    cls.__init__ = _wrap_anthropic(original, proxy_url, api_key, async_client=True)  # type: ignore[method-assign]
    return original


def _restore() -> None:
    """Restore captured original ``__init__`` functions; safe to call twice."""

    if "openai" in _state.originals:
        try:
            import openai  # noqa: WPS433

            openai.OpenAI.__init__ = _state.originals["openai"]  # type: ignore[method-assign]
        except Exception:  # pragma: no cover
            pass
    if "openai_async" in _state.originals:
        try:
            import openai  # noqa: WPS433

            cls = getattr(openai, "AsyncOpenAI", None)
            if cls is not None:
                cls.__init__ = _state.originals["openai_async"]  # type: ignore[method-assign]
        except Exception:  # pragma: no cover
            pass
    if "anthropic" in _state.originals:
        try:
            import anthropic  # noqa: WPS433

            anthropic.Anthropic.__init__ = _state.originals["anthropic"]  # type: ignore[method-assign]
        except Exception:  # pragma: no cover
            pass
    if "anthropic_async" in _state.originals:
        try:
            import anthropic  # noqa: WPS433

            cls = getattr(anthropic, "AsyncAnthropic", None)
            if cls is not None:
                cls.__init__ = _state.originals["anthropic_async"]  # type: ignore[method-assign]
        except Exception:  # pragma: no cover
            pass
    _state.originals.clear()
    _state.installed = False
    _state.proxy_url = None
    _state.api_key = None
    _state.providers = ()


def install(
    proxy_url: Optional[str] = None,
    api_key: Optional[str] = None,
    providers: Tuple[str, ...] = ("openai", "anthropic"),
) -> None:
    """Route OpenAI / Anthropic clients through a CoreIQ proxy.

    Parameters
    ----------
    proxy_url:
        Base URL of the CoreIQ proxy. Defaults to ``COREIQ_PROXY_URL`` env
        var or ``http://localhost:7823/v1``.
    api_key:
        API key the patched clients should use when the caller does not pass
        one. Defaults to ``COREIQ_API_KEY`` env var or the ``key`` field of
        ``~/.coreiq/credentials``.
    providers:
        Iterable of providers to patch. Currently supports ``"openai"`` and
        ``"anthropic"``. Missing SDKs are silently skipped.
    """

    resolved_url = _resolve_proxy_url(proxy_url)
    resolved_key = _resolve_api_key(api_key)
    resolved_providers = tuple(providers)

    with _lock:
        if _state.installed:
            same = (
                _state.proxy_url == resolved_url
                and _state.api_key == resolved_key
                and _state.providers == resolved_providers
            )
            if same:
                return
            _restore()

        originals: dict[str, Callable[..., Any]] = {}
        if "openai" in resolved_providers:
            orig = _patch_openai(resolved_url, resolved_key)
            if orig is not None:
                originals["openai"] = orig
            orig_async = _patch_openai_async(resolved_url, resolved_key)
            if orig_async is not None:
                originals["openai_async"] = orig_async
        if "anthropic" in resolved_providers:
            orig = _patch_anthropic(resolved_url, resolved_key)
            if orig is not None:
                originals["anthropic"] = orig
            orig_async = _patch_anthropic_async(resolved_url, resolved_key)
            if orig_async is not None:
                originals["anthropic_async"] = orig_async

        _state.installed = True
        _state.proxy_url = resolved_url
        _state.api_key = resolved_key
        _state.providers = resolved_providers
        _state.originals = originals

        patched = "/".join(originals.keys()) or "no providers (skipped)"
        # Strip any embedded credentials (`user:pass@host`) before logging —
        # users sometimes embed sk-coreiq-* keys into proxy_url and the INFO
        # line ends up in shared logs / CI output. Lower to DEBUG too: the
        # detail isn't actionable for end users in normal operation.
        safe_url = _redact_url_credentials(resolved_url)
        logger.debug("coreiq: routing %s clients through %s", patched, safe_url)


def uninstall() -> None:
    """Restore the original ``openai`` / ``anthropic`` constructors.

    Safe to call when :func:`install` has not run.
    """

    with _lock:
        if not _state.installed:
            return
        _restore()
