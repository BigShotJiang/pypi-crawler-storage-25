"""Drop-in SDK error types.

When ``coreiq.install()`` wraps an OpenAI / Anthropic client, every HTTP
response from the proxy is inspected by an ``httpx`` event hook. A 4xx/5xx
response surfaces as :class:`ProxyError` with an actionable hint pointing the
developer at ``coreiq doctor``. This avoids the cryptic generic
``openai.APIStatusError`` that hides the fact that a CoreIQ proxy is in the
loop.
"""
from __future__ import annotations

from typing import Optional

from ..exceptions import CoreIQError


class ProxyError(CoreIQError):
    """Raised when the CoreIQ proxy returns a 4xx/5xx response.

    Attributes
    ----------
    status_code: int
        The HTTP status code returned by the proxy.
    detail: str
        Best-effort human-readable detail from the response body.
    proxy_url: Optional[str]
        URL of the proxy that produced the error, when known.
    """

    def __init__(
        self,
        status_code: int,
        detail: str = "",
        proxy_url: Optional[str] = None,
    ) -> None:
        self.status_code = int(status_code)
        self.detail = detail or ""
        self.proxy_url = proxy_url
        hint = "Run 'coreiq doctor' to verify the proxy is reachable and your credentials are valid."
        target = f" via {proxy_url}" if proxy_url else ""
        super().__init__(
            f"CoreIQ proxy returned HTTP {self.status_code}{target}: "
            f"{self.detail or '(no body)'}\nHint: {hint}"
        )


__all__ = ["ProxyError"]
