"""Request body size limit middleware.

Defends against accidental and adversarial oversized requests reaching the
proxy. The limit is enforced via the ``Content-Length`` header (cheap, fast)
and a streaming check on bodies served without a header (chunked uploads).

Configuration:
    COREIQ_MAX_BODY_BYTES — soft cap on the request body (default 10 MiB).
    Set to 0 to disable the limit entirely (not recommended in production).
"""
from __future__ import annotations

import logging
import os
from typing import Awaitable, Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.types import ASGIApp

logger = logging.getLogger("coreiq.server.middleware.limits")

_DEFAULT_MAX_BYTES = 10 * 1024 * 1024  # 10 MiB


def _resolve_limit() -> int:
    raw = os.environ.get("COREIQ_MAX_BODY_BYTES")
    if raw is None:
        return _DEFAULT_MAX_BYTES
    try:
        value = int(raw)
    except ValueError:
        logger.warning("COREIQ_MAX_BODY_BYTES=%r is not an int; using default", raw)
        return _DEFAULT_MAX_BYTES
    return max(value, 0)


class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    """Reject requests whose body exceeds ``max_bytes``.

    Two-stage check:
        1. If ``Content-Length`` is present, reject before reading the body.
        2. Wrap ``request.receive`` so chunked bodies (no header) are
           rejected mid-stream once the cumulative byte count crosses the
           limit, instead of letting a malicious sender stream forever.
    """

    def __init__(self, app: ASGIApp, max_bytes: int | None = None) -> None:
        super().__init__(app)
        self.max_bytes = max_bytes if max_bytes is not None else _resolve_limit()

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable],
    ):
        if self.max_bytes <= 0:
            return await call_next(request)

        cl = request.headers.get("content-length")
        if cl is not None:
            try:
                if int(cl) > self.max_bytes:
                    return self._too_large(int(cl))
            except ValueError:
                # Malformed Content-Length — let starlette/uvicorn reject.
                pass

        original_receive = request.receive
        seen = 0
        max_bytes = self.max_bytes
        too_large = self._too_large

        async def limited_receive():
            nonlocal seen
            message = await original_receive()
            if message.get("type") == "http.request":
                body = message.get("body") or b""
                seen += len(body)
                if seen > max_bytes:
                    # Disconnect the client so we don't keep buffering.
                    raise _BodyTooLargeError(seen)
            return message

        request._receive = limited_receive  # type: ignore[attr-defined]
        try:
            return await call_next(request)
        except _BodyTooLargeError as exc:
            return too_large(exc.received)

    def _too_large(self, received: int) -> JSONResponse:
        logger.warning(
            "rejecting request: body=%d bytes exceeds COREIQ_MAX_BODY_BYTES=%d",
            received, self.max_bytes,
        )
        return JSONResponse(
            status_code=413,
            content={
                "error": {
                    "code": "request_too_large",
                    "message": (
                        f"Request body of {received} bytes exceeds the "
                        f"configured limit of {self.max_bytes} bytes."
                    ),
                }
            },
        )


class _BodyTooLargeError(Exception):
    def __init__(self, received: int) -> None:
        super().__init__(f"body exceeded limit ({received} bytes)")
        self.received = received
