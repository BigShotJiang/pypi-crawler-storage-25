"""Shared FastAPI dependencies for CoreIQ server routers.

Security note: the dashboard ``/api/*`` surface uses a single master API key
(``COREIQ_API_KEY``) enforced by ``auth_middleware``.  All callers of this
surface are therefore considered master-key callers and may freely pass an
optional ``tenant_id`` query parameter to scope queries to a specific tenant.

``require_tenant`` is the canonical way for routers to obtain the effective
tenant scope.  It:

- Returns the query-string ``tenant_id`` unchanged when the caller is a
  master-key user (including ``None``, which means "all tenants").
- Is designed to also support future virtual-key callers: if
  ``request.state.is_master`` is ``False``, the VK's tenant is enforced and
  any attempt to pass a *different* ``tenant_id`` in the query string is
  rejected with HTTP 403.

Usage in a router::

    from ...server.deps import require_tenant

    @router.get("")
    def my_endpoint(
        tenant_id: Optional[str] = Depends(require_tenant),
    ):
        ...
"""
from __future__ import annotations

from typing import Optional

from fastapi import HTTPException, Query, Request


def require_tenant(
    request: Request,
    tenant_id: Optional[str] = Query(default=None, description="Tenant scope filter."),
) -> Optional[str]:
    """Return the effective tenant_id for this request.

    Master-key callers: ``tenant_id`` query param is returned as-is.
    Virtual-key callers (future): tenant is enforced from the key; mismatches
    raise HTTP 403.
    """
    is_master: bool = getattr(request.state, "is_master", True)

    if is_master:
        return tenant_id

    # Virtual-key path — enforce the tenant from the key.
    vk_tenant: Optional[str] = getattr(request.state, "tenant_id", None)
    if tenant_id is not None and tenant_id != vk_tenant:
        raise HTTPException(
            status_code=403,
            detail="tenant mismatch: query tenant_id does not match virtual key tenant",
        )
    return vk_tenant
