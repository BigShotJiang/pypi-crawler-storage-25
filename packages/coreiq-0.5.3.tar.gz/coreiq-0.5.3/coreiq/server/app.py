import asyncio
import hmac
import json
import logging
import os
import sys
import time
import uuid
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

# Load .env from the project root (coreiq/) before any config is read
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv(Path(__file__).parent.parent.parent / ".env", override=False)
except ImportError:
    pass

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

try:
    from coreiq import __version__ as _coreiq_version
except ImportError:
    _coreiq_version = "0.4.0"  # Fallback version if import fails

from .routers import traces, cache, tool_calls, feedback, evolution, query_recon, optimiser, events, tools, keys, functions, auth
from .routers import audit_chain as audit_chain_router
from .routers import eval as eval_router
from .routers import governance as governance_router
from .routers import datasets as datasets_router
from .routers import tenants as tenants_router
from .routers import violations as violations_router
from .routers import request_logs as request_logs_router
from .routers import integrations as integrations_router
from .routers import config_store as config_store_router
from .routers import billing as billing_router
from .routers import users as users_router
from .routers import scim as scim_router
from .routers import analytics as analytics_router
from .routers import incidents as incidents_router
from .routers import feature_flags as feature_flags_router
from .routers import egress as egress_router
from .routers import agent_tokens as agent_tokens_router
from .routers import revocation as revocation_router
from .routers import explain as explain_router
from .routers import prompts as prompts_router
from .routers import firewall as firewall_router
from .routers import streaming_guard as streaming_guard_router
from .routers import agent_governance as agent_governance_router
from .routers import cost_optimizer as cost_optimizer_router
from .routers import routing_rules as routing_rules_router
from .routers import groups as groups_router
from .routers import v1_integration as v1_integration_router
from .routers import policy as policy_router
from .routers.new_features import (
    regression_router, dlp_router, canary_router, redteam_router, replay_router,
)
from .routers.tier3_features import (
    watermark_router, multimodal_router, ctx_router, bias_router,
    compliance_auto_router, fed_router, fp_router,
)
from ..store.db import create_connection, get_shared_connection, init_schema
from ..config import (
    get_api_key, get_host, get_port, get_log_level,
    get_log_json, get_cors_origins, get_rate_limit,
    get_provider_configs, get_functions_config, get_metrics_config,
)
from ..proxy.gateway import router as proxy_router, init_gateway
from ..proxy.pipeline import RequestPipeline
from ..proxy.providers.registry import ProviderRegistry
from ..proxy.routing.router import Deployment, DeploymentRouter

# ── Logging ───────────────────────────────────────────────────────────────────

def _configure_logging() -> None:
    if get_log_json():
        class JsonFormatter(logging.Formatter):
            def format(self, record: logging.LogRecord) -> str:
                return json.dumps({
                    "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
                    "level": record.levelname,
                    "logger": record.name,
                    "msg": record.getMessage(),
                    **({"exc": self.formatException(record.exc_info)} if record.exc_info else {}),
                })
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter())
        logging.root.handlers = [handler]
        logging.root.setLevel(logging.INFO)
    else:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )

_configure_logging()
logger = logging.getLogger("coreiq.server")


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    import secrets
    # get_db_path removed — no longer using SQLite
    # Auth resolution:
    #   1. COREIQ_AUTH_MODE=disabled → run without auth (loud warning)
    #   2. COREIQ_API_KEY set → use it
    #   3. COREIQ_ENV=production (the default) AND no key → refuse to start
    #      (this is the fail-loud production guardrail added in self-heal #81)
    #   4. COREIQ_ENV=development AND no key → auto-generate an ephemeral
    #      dev key so `pip install coreiq && coreiq` works out of the box.
    #      The generated key is printed to stdout with a loud banner so
    #      the user can see it and point their SDK at it.
    _api_key = get_api_key()
    _auth_mode = os.environ.get("COREIQ_AUTH_MODE", "").lower()
    _env = os.environ.get("COREIQ_ENV", "development").lower()
    if _auth_mode == "disabled":
        logger.critical(
            "COREIQ_AUTH_MODE=disabled — server is running WITHOUT authentication. "
            "ALL /api/* endpoints are publicly accessible. Do NOT use this in production."
        )
    elif not _api_key:
        if _env == "production":
            logger.critical(
                "COREIQ_API_KEY is required in production. "
                "Set COREIQ_API_KEY to a secret value, "
                "set COREIQ_ENV=development to auto-generate a dev key, "
                "or set COREIQ_AUTH_MODE=disabled to explicitly run without auth."
            )
            raise RuntimeError(
                "COREIQ_API_KEY not set and COREIQ_ENV=production"
            )
        # Dev mode: auto-generate an ephemeral key. The key only exists
        # for this process lifetime — restart gives a fresh one. Printed
        # as a bright banner so `coreiq` users can copy-paste it into
        # their SDK calls immediately.
        ephemeral_key = f"sk-coreiq-dev-{secrets.token_urlsafe(24)}"
        os.environ["COREIQ_API_KEY"] = ephemeral_key
        _api_key = ephemeral_key
        print("=" * 72, file=sys.stderr)
        print("  COREIQ DEV MODE — ephemeral API key generated", file=sys.stderr)
        print(f"  Key: {ephemeral_key}", file=sys.stderr)
        print("  Use this as Authorization: Bearer <key> or X-API-Key header.", file=sys.stderr)
        print("  Set COREIQ_API_KEY=... to persist across restarts.", file=sys.stderr)
        print("  Set COREIQ_ENV=production for fail-loud production behavior.", file=sys.stderr)
        print("=" * 72, file=sys.stderr)
        logger.warning(
            "Running in dev mode with an ephemeral API key. "
            "Set COREIQ_API_KEY= to persist across restarts."
        )
    conn = create_connection()
    init_schema(conn)

    # Sovereign Policy Engine — load active bundle from file (GitOps) or DB.
    # Fail-soft: a load error must NOT prevent startup. The engine without a
    # bundle is a no-op (returns ALLOW with reason engine.no_bundle).
    try:
        from ..policy import get_policy_engine
        from ..policy.loader import load_initial_bundle
        _bundle = load_initial_bundle()
        if _bundle is not None:
            get_policy_engine().set_bundle(_bundle)
            logger.info(
                "Policy engine: loaded bundle %s (mode=%s, residency=%s)",
                _bundle.bundle_id, _bundle.mode, _bundle.residency,
            )
    except Exception as exc:
        logger.warning("Policy engine bundle load skipped: %s", exc)

    # OTel-only mode banner — when COREIQ_STORE_BACKEND=otel the dashboard
    # serves only the last-N events from each table's in-memory ring buffer.
    if os.environ.get("COREIQ_STORE_BACKEND", "").lower() == "otel":
        _otel_buffer_size = int(os.environ.get("COREIQ_OTEL_DASHBOARD_BUFFER", "1000"))
        logger.warning(
            "OTel-only mode active — DB writes disabled; dashboard reads limited to last %d events",
            _otel_buffer_size,
        )

    # Auto-populate risk register from traces on startup — new models get
    # UNCLASSIFIED tier; already-registered models are left untouched.
    try:
        from .routers.governance import _sync_risk_register_from_traces
        _rr_result = _sync_risk_register_from_traces()
        if _rr_result["added"]:
            logger.info(
                "Risk register: auto-registered %d new model(s) from traces: %s",
                len(_rr_result["added"]), ", ".join(_rr_result["added"]),
            )
    except Exception as _rr_exc:
        logger.debug("Risk register bootstrap skipped: %s", _rr_exc)

    # OTel export — env-gated. Set COREIQ_OTEL_ENDPOINT to enable. Failure
    # to configure must not block startup; observability is fail-soft.
    _otel_endpoint = os.environ.get("COREIQ_OTEL_ENDPOINT") or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    if _otel_endpoint:
        try:
            from ..observability.otel_exporter import configure_otel
            configure_otel(
                endpoint=_otel_endpoint,
                protocol=os.environ.get("COREIQ_OTEL_PROTOCOL", "grpc"),
                service_name=os.environ.get("OTEL_SERVICE_NAME", "coreiq"),
            )
            logger.info("OTel export configured -> %s", _otel_endpoint)
        except Exception as exc:
            logger.warning("OTel configuration failed (continuing without export): %s", exc)

    host, port = get_host(), get_port()
    db = f"{conn.backend_type} (configured via COREIQ_STORE_BACKEND)"
    app.state.rate_lock = asyncio.Lock()

    # Initialise the proxy gateway with a provider registry.
    registry = ProviderRegistry()
    # Auto-register providers whose environment variables are set.
    _auto_register_providers(registry)
    # Register providers from TOML config (additive — won't override env-based ones).
    _register_providers_from_toml(registry)
    # Store on app.state so /api/ready can inspect it.
    app.state.provider_registry = registry

    registered = registry.list_providers()
    if not registered:
        logger.critical(
            "No LLM providers registered! To fix this:\n"
            "  1. Export a provider key:  export OPENAI_API_KEY=sk-...\n"
            "  2. Restart CoreIQ:         coreiq\n"
            "  3. Verify at startup:      look for 'Registered N provider(s)' in logs\n"
            "  Supported: OPENAI_API_KEY, ANTHROPIC_API_KEY, GOOGLE_API_KEY, MISTRAL_API_KEY, "
            "COHERE_API_KEY, GROQ_API_KEY, TOGETHER_API_KEY, DEEPSEEK_API_KEY"
        )
    else:
        logger.info("Registered %d provider(s): %s", len(registered), ", ".join(registered))

    # Bootstrap functions, variants, and metrics from TOML config.
    _bootstrap_functions_from_toml()

    # Virtual key manager for the proxy pipeline.
    from ..proxy.keys import KeyManager, RateLimiter
    key_manager = KeyManager()
    rate_limiter = RateLimiter()

    # Shared optimization singletons — created once, reused across all requests.
    function_registry = None
    variant_manager = None
    experiment_manager = None
    template_engine = None
    dicl_store = None
    try:
        from ..optimization.function import FunctionRegistry
        from ..optimization.variant import VariantManager
        from ..optimization.experiment import ExperimentManager
        from ..optimization.templates import TemplateEngine
        from ..optimization.dicl import EmbeddingDICL

        function_registry = FunctionRegistry()
        variant_manager = VariantManager()
        experiment_manager = ExperimentManager()
        template_engine = TemplateEngine()
        dicl_store = EmbeddingDICL(db_path="<configured-backend>")
    except ImportError:
        logger.debug("Optimization modules not available — function resolution disabled")
    except Exception as exc:
        logger.warning("Failed to initialize optimization singletons: %s", exc)

    # Deployment router — intelligent routing with fallbacks, circuit breakers,
    # and strategy-based selection across provider deployments.
    deployment_router = _create_deployment_router(registry)

    # ── Cache layer (in-memory) ────────────────────────────────────────
    from ..performance.cache import InMemorySemanticCache
    cache_instance = InMemorySemanticCache(
        max_size=int(os.environ.get("COREIQ_CACHE_MAX_SIZE", "1000")),
        similarity_threshold=float(os.environ.get("COREIQ_CACHE_SIMILARITY", "0.92")),
    )

    pipeline = RequestPipeline(
        registry=registry,
        api_key=get_api_key(),
        cache=cache_instance,
        key_manager=key_manager,
        deployment_router=deployment_router,
        function_registry=function_registry,
        variant_manager=variant_manager,
        experiment_manager=experiment_manager,
        template_engine=template_engine,
        dicl_store=dicl_store,
        rate_limiter=rate_limiter,
    )
    init_gateway(registry=registry, pipeline=pipeline)

    # Wire budget governor for cost alerting
    try:
        from ..performance.cost_alerts import BudgetGovernor
        budget_governor = BudgetGovernor()
        app.state.budget_governor = budget_governor
        logger.info("BudgetGovernor wired for cost alerting")
    except Exception as exc:
        logger.warning("BudgetGovernor not available: %s", exc)

    # Wire AUP manager for acceptable use policy enforcement
    try:
        from ..governance.acceptable_use import AUPManager
        app.state.aup_manager = AUPManager()
        logger.info("AUPManager wired for acceptable use policy")
    except Exception as exc:
        logger.warning("AUPManager not available: %s", exc)

    # Start the deployment router's background services (health checks).
    if deployment_router is not None:
        await deployment_router.start()

    logger.info("CoreIQ v%s started", app.version)
    logger.info("  Dashboard:  http://%s:%s", host, port)
    logger.info("  API docs:   http://%s:%s/api/docs", host, port)
    logger.info("  Proxy:      http://%s:%s/v1/chat/completions", host, port)
    logger.info("  Health:     http://%s:%s/api/health", host, port)
    logger.info("  Ready:      http://%s:%s/api/ready", host, port)
    logger.info("  Database:   %s", db)
    if deployment_router is not None:
        logger.info("  Routing:    %s strategy, %d deployments",
                     deployment_router.strategy_name,
                     len(deployment_router.list_deployments()))
    yield

    # Shut down the deployment router's background services FIRST so no
    # new outbound provider calls start while we drain. Pending in-flight
    # httpx calls owned by request handlers will still complete because
    # FastAPI/uvicorn waits for active requests during graceful shutdown
    # (see ``terminationGracePeriodSeconds`` on the Helm Deployment).
    if deployment_router is not None:
        try:
            await deployment_router.stop()
        except Exception as exc:
            logger.warning("DeploymentRouter stop failed: %s", exc)

    # Drain audit sinks BEFORE closing the writer/OTel backend — sinks may
    # ride on the writer's queue, and closing the writer first would drop
    # buffered audit events on the floor. Each step is wrapped so a single
    # failure can't block the rest of the shutdown sequence.
    try:
        from ..governance.sinks.base import get_sink_router
        router = get_sink_router()
        # Prefer router.close() when the governance team adds it; fall back
        # to a best-effort per-sink flush()/close() iteration so audit-sink
        # batches (Splunk HEC, Datadog SIEM, S3 WORM uploaders) drain
        # before the process exits. We never raise — shutdown must continue.
        close_fn = getattr(router, "close", None)
        if callable(close_fn):
            close_fn()
        else:
            for entry in getattr(router, "_sinks", []):
                sink = getattr(entry, "sink", None)
                if sink is None:
                    continue
                for method_name in ("flush", "close"):
                    method = getattr(sink, method_name, None)
                    if callable(method):
                        try:
                            method()
                        except Exception as _sink_exc:  # noqa: BLE001
                            logger.warning(
                                "Audit sink %s %s() failed during shutdown: %s",
                                getattr(sink, "name", type(sink).__name__),
                                method_name,
                                _sink_exc,
                            )
    except Exception as exc:
        logger.warning("AuditSinkRouter flush failed: %s", exc)

    # Force-flush the OTel pipeline (spans/logs/metrics in the BatchProcessor
    # queue). For the OTel backend this also drains the per-table ring
    # buffer references; for SQL backends this is a no-op.
    try:
        from ..store.backends.otel_backend import _otel_singleton  # type: ignore[attr-defined]
        if _otel_singleton is not None:
            _otel_singleton.close()
    except Exception as exc:
        logger.warning("OtelBackend close failed: %s", exc)

    # Finally flush + close the EventWriter so buffered traces are not lost.
    try:
        from ..store.writer import get_writer
        w = get_writer()
        if w is not None:
            w.close()
    except Exception as exc:
        logger.warning("EventWriter close failed during shutdown: %s", exc)

    # Close the shared httpx.AsyncClient pool so we don't leak sockets on
    # shutdown. Pool clients are created lazily by ProviderConfig.
    try:
        from ..proxy.providers.base import close_http_pool
        await close_http_pool()
    except Exception as exc:
        logger.warning("httpx pool close failed during shutdown: %s", exc)
    logger.info("CoreIQ server shutting down")


def _create_deployment_router(registry: ProviderRegistry) -> DeploymentRouter | None:
    """Create a DeploymentRouter with a Deployment for each registered provider.

    Returns ``None`` if no providers are registered, preserving backward
    compatibility (the pipeline will fall back to direct ProviderRegistry
    resolution).

    The routing strategy is configurable via the ``COREIQ_ROUTING_STRATEGY``
    environment variable (default: ``"lowest_latency"``).
    """

    providers = registry.list_providers()
    if not providers:
        return None

    strategy = os.environ.get("COREIQ_ROUTING_STRATEGY", "lowest_latency")
    # Validate strategy name — fall back to lowest_latency on bad input.
    valid_strategies = {
        "lowest_latency", "lowest_cost", "weighted",
        "round_robin", "least_busy",
    }
    if strategy not in valid_strategies:
        logger.warning(
            "Unknown COREIQ_ROUTING_STRATEGY=%r, falling back to 'lowest_latency'. "
            "Valid strategies: %s",
            strategy, ", ".join(sorted(valid_strategies)),
        )
        strategy = "lowest_latency"

    router = DeploymentRouter(
        strategy=strategy,
        health_check_interval_s=0,  # Disable health probes — we don't have health endpoints for LLM APIs.
    )

    for provider_name in providers:
        provider_config = registry.get(provider_name)
        if provider_config is None:
            continue

        deployment = Deployment(
            id=f"{provider_name}-primary",
            model=provider_name,  # Provider name — bare model is resolved at request time.
            provider_config=provider_config,
        )
        try:
            router.add_deployment(deployment)
            logger.info(
                "Registered deployment %s for provider %s (strategy=%s)",
                deployment.id, provider_name, strategy,
            )
        except ValueError as exc:
            logger.warning("Failed to add deployment for %s: %s", provider_name, exc)

    if not router.list_deployments():
        return None

    return router


def _safe_register(
    registry: ProviderRegistry,
    name: str,
    provider: Any,
    *,
    source: str = "env",
    label: str | None = None,
) -> bool:
    """Register *provider* on *registry*, surfacing duplicate-name collisions.

    ``ProviderRegistry.register`` raises ``ValueError`` for duplicate names.
    Previously the wrapping ``except (ImportError, Exception)`` swallowed
    that as a debug log, so a misconfiguration that registered the same
    provider via TOML *and* env vars (or via two different env paths) was
    completely invisible. We now catch the duplicate case explicitly and
    log a WARNING that names both the provider and the registration source.

    Returns True iff the registration succeeded.
    """
    display = label or name
    try:
        registry.register(name, provider)
        logger.info("Auto-registered %s provider (source=%s)", display, source)
        return True
    except ValueError as exc:
        # Duplicate name — registry refused to silently replace.
        logger.warning(
            "Provider collision for %r (source=%s): %s. "
            "Skipping; the previously-registered provider remains active. "
            "Use ProviderRegistry.replace() if intentional.",
            name, source, exc,
        )
        return False
    except Exception as exc:
        logger.debug("Could not auto-register %s (source=%s): %s", display, source, exc)
        return False


def _auto_register_providers(registry: ProviderRegistry) -> None:
    """Auto-register providers based on available environment variables.

    Registration uses :func:`_safe_register` so duplicate-name collisions
    (typically caused by both ``[providers.X]`` TOML and ``X_API_KEY`` env
    being set) surface as a WARNING instead of a silent debug message.
    """

    # OpenAI
    if os.environ.get("OPENAI_API_KEY"):
        try:
            from ..proxy.providers.openai import OpenAIProvider
            _safe_register(registry, "openai", OpenAIProvider(), source="env:OPENAI_API_KEY", label="OpenAI")
        except ImportError as exc:
            logger.debug("Could not import OpenAI provider: %s", exc)

    # Anthropic
    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            from ..proxy.providers.anthropic import AnthropicProvider
            _safe_register(registry, "anthropic", AnthropicProvider(), source="env:ANTHROPIC_API_KEY", label="Anthropic")
        except ImportError as exc:
            logger.debug("Could not import Anthropic provider: %s", exc)

    # Google Gemini
    if os.environ.get("GOOGLE_API_KEY"):
        try:
            from ..proxy.providers.google import GoogleProvider
            _safe_register(registry, "google", GoogleProvider(), source="env:GOOGLE_API_KEY", label="Google Gemini")
        except ImportError as exc:
            logger.debug("Could not import Google provider: %s", exc)

    # Mistral
    if os.environ.get("MISTRAL_API_KEY"):
        try:
            from ..proxy.providers.mistral import MistralProvider
            _safe_register(registry, "mistral", MistralProvider(), source="env:MISTRAL_API_KEY", label="Mistral")
        except ImportError as exc:
            logger.debug("Could not import Mistral provider: %s", exc)

    # Cohere
    if os.environ.get("COHERE_API_KEY"):
        try:
            from ..proxy.providers.cohere import CohereProvider
            _safe_register(registry, "cohere", CohereProvider(), source="env:COHERE_API_KEY", label="Cohere")
        except ImportError as exc:
            logger.debug("Could not import Cohere provider: %s", exc)

    # Groq
    if os.environ.get("GROQ_API_KEY"):
        try:
            from ..proxy.providers.groq import GroqProvider
            _safe_register(registry, "groq", GroqProvider(), source="env:GROQ_API_KEY", label="Groq")
        except ImportError as exc:
            logger.debug("Could not import Groq provider: %s", exc)

    # Together AI
    if os.environ.get("TOGETHER_API_KEY"):
        try:
            from ..proxy.providers.together import TogetherProvider
            _safe_register(registry, "together", TogetherProvider(), source="env:TOGETHER_API_KEY", label="Together AI")
        except ImportError as exc:
            logger.debug("Could not import Together provider: %s", exc)

    # DeepSeek
    if os.environ.get("DEEPSEEK_API_KEY"):
        try:
            from ..proxy.providers.deepseek import DeepSeekProvider
            _safe_register(registry, "deepseek", DeepSeekProvider(), source="env:DEEPSEEK_API_KEY", label="DeepSeek")
        except ImportError as exc:
            logger.debug("Could not import DeepSeek provider: %s", exc)

    # AWS Bedrock
    _bedrock_available = False
    if os.environ.get("AWS_ACCESS_KEY_ID"):
        _bedrock_available = True
    else:
        # Check if boto3 can resolve credentials (e.g. IAM role, SSO, etc.)
        try:
            import boto3
            session = boto3.Session()
            creds = session.get_credentials()
            if creds is not None:
                _bedrock_available = True
        except (ImportError, Exception):
            pass
    if _bedrock_available:
        try:
            from ..proxy.providers.bedrock import BedrockProvider
            _safe_register(registry, "bedrock", BedrockProvider(), source="env:AWS_*", label="AWS Bedrock")
        except ImportError as exc:
            logger.debug("Could not import Bedrock provider: %s", exc)

    # Generic OpenAI-compatible (vLLM, SGLang, Ollama, OpenRouter)
    compat_base = os.environ.get("OPENAI_COMPATIBLE_API_BASE")
    if compat_base:
        try:
            from ..proxy.providers.openai_compat import OpenAICompatProvider
            compat_key = os.environ.get("OPENAI_COMPATIBLE_API_KEY", "")
            registered = _safe_register(
                registry,
                "openai_compat",
                OpenAICompatProvider(
                    base_url=compat_base,
                    api_key=compat_key,
                    provider_label="openai_compatible",
                ),
                source="env:OPENAI_COMPATIBLE_API_BASE",
                label="OpenAI-compatible",
            )
            if not registered:
                # Skip model-override discovery if we never owned the slot.
                pass
            else:
                # Discover available models and register overrides so callers
                # can use the full model name (e.g. "openai/gpt-oss-120b")
                # without a "openai_compat/" prefix.
                try:
                    import httpx as _httpx
                    _hdrs = {"Authorization": f"Bearer {compat_key}"} if compat_key else {}
                    with _httpx.Client(timeout=5) as _hc:
                        _r = _hc.get(f"{compat_base}/models", headers=_hdrs)
                        _models = _r.json().get("data", [])
                    for _m in _models:
                        _mid = _m.get("id", "")
                        if _mid:
                            registry.register_model_override(_mid, "openai_compat")
                    logger.info("Registered %d model override(s) for openai_compat", len(_models))
                except Exception as _e:
                    logger.warning("Could not auto-discover models from %s: %s", compat_base, _e)
        except ImportError as exc:
            logger.debug("Could not import OpenAI-compatible provider: %s", exc)
        except Exception as exc:
            logger.debug("Could not auto-register OpenAI-compatible: %s", exc)


def _register_providers_from_toml(registry: ProviderRegistry) -> None:
    """Register providers defined in ``[providers.*]`` TOML sections."""
    provider_cfgs = get_provider_configs()
    _PROVIDER_MAP = {
        "openai": ("..proxy.providers.openai", "OpenAIProvider"),
        "anthropic": ("..proxy.providers.anthropic", "AnthropicProvider"),
        "google": ("..proxy.providers.google", "GoogleProvider"),
        "mistral": ("..proxy.providers.mistral", "MistralProvider"),
        "cohere": ("..proxy.providers.cohere", "CohereProvider"),
        "groq": ("..proxy.providers.groq", "GroqProvider"),
        "together": ("..proxy.providers.together", "TogetherProvider"),
        "deepseek": ("..proxy.providers.deepseek", "DeepSeekProvider"),
        "bedrock": ("..proxy.providers.bedrock", "BedrockProvider"),
    }
    for name, cfg in provider_cfgs.items():
        name_lower = name.lower()
        if name_lower in registry:
            logger.debug("Provider %r already registered, skipping TOML config", name_lower)
            continue
        entry = _PROVIDER_MAP.get(name_lower)
        if entry is not None:
            mod_path, cls_name = entry
            try:
                import importlib
                mod = importlib.import_module(mod_path, package=__package__)
                cls = getattr(mod, cls_name)
                kwargs = {}
                if "api_key" in cfg:
                    kwargs["api_key"] = cfg["api_key"]
                if "base_url" in cfg:
                    kwargs["api_base"] = cfg["base_url"]
                provider_inst = cls(**kwargs) if kwargs else cls()
                _safe_register(registry, name_lower, provider_inst, source=f"toml:[providers.{name_lower}]")
            except Exception as exc:
                logger.warning("Could not register provider %r from TOML: %s", name_lower, exc)
        else:
            # Try as generic OpenAI-compatible
            if "base_url" in cfg:
                try:
                    from ..proxy.providers.openai_compat import OpenAICompatProvider
                    provider_inst = OpenAICompatProvider(
                        api_base=cfg.get("base_url", ""),
                        api_key=cfg.get("api_key", ""),
                    )
                    _safe_register(
                        registry, name_lower, provider_inst,
                        source=f"toml:[providers.{name_lower}]",
                        label="OpenAI-compatible",
                    )
                except Exception as exc:
                    logger.warning("Could not register provider %r from TOML: %s", name_lower, exc)
            else:
                logger.warning("Unknown provider %r in TOML config (no base_url for compat mode)", name_lower)


def _bootstrap_functions_from_toml() -> None:
    """Bootstrap functions, variants, and metrics from TOML config."""
    functions_cfg = get_functions_config()
    metrics_cfg = get_metrics_config()

    if not functions_cfg and not metrics_cfg:
        return

    try:
        from ..optimization.function import FunctionRegistry, FunctionType
        from ..optimization.variant import VariantManager, VariantType
        from ..optimization.metrics import MetricRegistry, MetricType, MetricLevel, MetricOptimize

        fn_registry = FunctionRegistry()
        variant_mgr = VariantManager()
        metric_registry = MetricRegistry()

        # Register metrics
        for metric_name, mcfg in metrics_cfg.items():
            if metric_registry.get(metric_name) is not None:
                continue
            try:
                mtype_str = mcfg.get("type", "float")
                # MetricType uses "float_" for the enum member
                mtype_val = "float_" if mtype_str == "float" else mtype_str
                metric_registry.create(
                    name=metric_name,
                    type=MetricType(mtype_val),
                    level=MetricLevel(mcfg.get("level", "inference")),
                    optimize=MetricOptimize(mcfg.get("optimize", "max")),
                )
                logger.info("Registered metric %r from TOML config", metric_name)
            except Exception as exc:
                logger.warning("Could not register metric %r from TOML: %s", metric_name, exc)

        # Register functions and their variants
        for fn_name, fcfg in functions_cfg.items():
            fn_def = fn_registry.get(fn_name)
            if fn_def is None:
                try:
                    fn_type = FunctionType(fcfg.get("type", "chat"))
                    fn_def = fn_registry.create(name=fn_name, type=fn_type)
                    logger.info("Registered function %r from TOML config", fn_name)
                except Exception as exc:
                    logger.warning("Could not register function %r from TOML: %s", fn_name, exc)
                    continue

            # Register variants for this function
            variants_cfg = fcfg.get("variants", {})
            for var_name, vcfg in variants_cfg.items():
                existing = variant_mgr.get(fn_def.id, var_name)
                if existing is not None:
                    continue
                try:
                    var_type = VariantType(vcfg.get("type", "chat_completion"))
                    config_dict = {}
                    if "json_mode" in vcfg:
                        config_dict["json_mode"] = vcfg["json_mode"]
                    variant_mgr.create(
                        function_id=fn_def.id,
                        name=var_name,
                        type=var_type,
                        model=vcfg.get("model"),
                        system_template=vcfg.get("system_template"),
                        user_template=vcfg.get("user_template"),
                        config=config_dict or None,
                        weight=float(vcfg.get("weight", 1.0)),
                    )
                    logger.info(
                        "Registered variant %r for function %r from TOML config",
                        var_name, fn_name,
                    )
                except Exception as exc:
                    logger.warning(
                        "Could not register variant %r for function %r from TOML: %s",
                        var_name, fn_name, exc,
                    )

    except ImportError:
        logger.debug("Optimization module not available, skipping TOML function bootstrap")
    except Exception as exc:
        logger.warning("Failed to bootstrap functions from TOML: %s", exc, exc_info=True)


# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="CoreIQ Dashboard API",
    version=_coreiq_version,
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_origins(),
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Content-Type", "Authorization", "X-API-Key", "X-Request-ID"],
)

# Body-size limit (configurable via COREIQ_MAX_BODY_BYTES). Sits *before*
# CORS in middleware order — added last, runs first — so oversized requests
# are rejected with a 413 before any other middleware allocates buffers.
from .middleware import BodySizeLimitMiddleware  # noqa: E402
app.add_middleware(BodySizeLimitMiddleware)


# ── Rate limiting ─────────────────────────────────────────────────────────────

# NOTE: In-memory rate limit state — resets on server restart.
# For persistent rate limiting, use an external store (Redis, etc.).
_rate_buckets: dict[str, list[float]] = defaultdict(list)
_server_start = time.monotonic()


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    lock = getattr(request.app.state, "rate_lock", None)
    if lock is None:
        lock = asyncio.Lock()
        request.app.state.rate_lock = lock
    limit = get_rate_limit()
    normalized = request.url.path.rstrip("/").lower()
    # Skip /v1/* paths — the proxy pipeline handles its own rate limiting.
    if normalized.startswith("/v1"):
        return await call_next(request)
    if limit > 0 and normalized.startswith("/api"):
        # Stricter limits during first 60s after startup (burst protection)
        now = time.monotonic()
        if now - _server_start < 60.0:
            limit = limit // 2 or 1
        ip = request.client.host if request.client else "unknown"
        async with lock:
            window = _rate_buckets[ip]
            # Slide window: keep only timestamps within the last 60s
            cutoff = now - 60.0
            _rate_buckets[ip] = [t for t in window if t > cutoff]
            if not _rate_buckets[ip]:
                del _rate_buckets[ip]
            if len(_rate_buckets.get(ip, [])) >= limit:
                return JSONResponse(
                    status_code=429,
                    content={"detail": "Rate limit exceeded. Try again in a minute."},
                    headers={
                        "Retry-After": "60",
                        "X-RateLimit-Limit": str(limit),
                        "X-RateLimit-Remaining": "0",
                        "X-RateLimit-Reset": str(int(now + 60)),
                    },
                )
            # Cap bucket dict at 10,000 IPs; evict the IP with the oldest last-seen timestamp
            if len(_rate_buckets) >= 10000 and ip not in _rate_buckets:
                oldest_ip = min(
                    _rate_buckets,
                    key=lambda k: _rate_buckets[k][-1] if _rate_buckets[k] else 0,
                )
                del _rate_buckets[oldest_ip]
            _rate_buckets[ip].append(now)
    response = await call_next(request)
    if limit > 0 and normalized.startswith("/api"):
        current_count = len(_rate_buckets.get(ip, []))
        response.headers["X-RateLimit-Limit"] = str(limit)
        response.headers["X-RateLimit-Remaining"] = str(max(0, limit - current_count))
        response.headers["X-RateLimit-Reset"] = str(int(time.monotonic() + 60))
    return response


# ── Auth ──────────────────────────────────────────────────────────────────────

# Per-IP token bucket for /auth/provision (5 req/min). Stdlib only — no new
# deps. Sliding 60s window keyed by client IP. Reset on server restart, capped
# at 10k IPs with LRU-ish eviction (oldest last-seen wins eviction).
_AUTH_PROVISION_LIMIT = 5  # requests per 60s
_auth_provision_buckets: dict[str, list[float]] = defaultdict(list)
# Lazily created on first use so we don't construct an asyncio.Lock at import
# time — that emits a DeprecationWarning on Py 3.10/3.11 and raises
# RuntimeError on Py 3.12+ when no event loop exists yet.
_auth_provision_lock: Optional[asyncio.Lock] = None


def _get_auth_provision_lock() -> asyncio.Lock:
    global _auth_provision_lock
    if _auth_provision_lock is None:
        _auth_provision_lock = asyncio.Lock()
    return _auth_provision_lock


async def _check_auth_provision_rate_limit(ip: str) -> bool:
    """Return True if the request is within the limit (allowed)."""
    async with _get_auth_provision_lock():
        now = time.monotonic()
        cutoff = now - 60.0
        bucket = [t for t in _auth_provision_buckets.get(ip, []) if t > cutoff]
        if len(bucket) >= _AUTH_PROVISION_LIMIT:
            _auth_provision_buckets[ip] = bucket
            return False
        bucket.append(now)
        _auth_provision_buckets[ip] = bucket
        # Cap dict size
        if len(_auth_provision_buckets) > 10000:
            oldest_ip = min(
                _auth_provision_buckets,
                key=lambda k: _auth_provision_buckets[k][-1] if _auth_provision_buckets[k] else 0,
            )
            if oldest_ip != ip:
                del _auth_provision_buckets[oldest_ip]
        return True


@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    required_key = get_api_key()
    auth_mode = os.environ.get("COREIQ_AUTH_MODE", "").lower()
    normalized = request.url.path.rstrip("/").lower()
    # /v1/* paths: proxy pipeline handles virtual key auth (sk-coreiq-*).
    # If a Bearer JWT is present (from gateway), validate via sidecar first,
    # then strip JWT from scope headers so proxy pipeline uses its own provider key.
    if normalized.startswith("/v1"):
        auth_header = request.headers.get("authorization", "")
        token = auth_header[7:].strip() if auth_header.startswith("Bearer ") else ""
        # Only attempt JWT validation for actual JWTs (3 dot-separated parts).
        # Plain API keys and virtual keys (sk-coreiq-*) pass through to the
        # proxy pipeline which handles its own auth.
        is_jwt = token and token.count(".") >= 2 and not token.startswith("sk-coreiq-")
        if is_jwt:
            jwt_result = await _validate_jwt_via_sidecar(token)
            if jwt_result:
                request.state.is_master = False
                request.state.tenant_id = jwt_result.get("tenant_id")
                request.state.user_id = jwt_result.get("sub")
                return await call_next(request)
            # JWT invalid — check X-API-Key fallback
            api_key = request.headers.get("X-API-Key")
            if api_key and required_key and hmac.compare_digest(api_key, required_key):
                request.state.is_master = True
                return await call_next(request)
            return JSONResponse(status_code=401, content={"detail": "Invalid JWT"})
        # Non-JWT Bearer token or no auth — let proxy pipeline handle
        return await call_next(request)

    # /auth/* endpoints — these were previously slipping past auth entirely.
    # /auth/provision is the IdP token-exchange endpoint and must be:
    #   1. Per-IP rate limited (5 req/min) to prevent token-stuffing abuse.
    #   2. NOT require X-API-Key (it is the bootstrap that mints keys), but
    #      its body MUST include a valid IdP token validated downstream.
    # Any other /auth/* path (none currently exist) is rejected with 404.
    if normalized.startswith("/auth"):
        if normalized != "/auth/provision":
            return JSONResponse(status_code=404, content={"detail": "Not Found"})
        ip = request.client.host if request.client else "unknown"
        allowed = await _check_auth_provision_rate_limit(ip)
        if not allowed:
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded for /auth/provision. 5 req/min per IP."},
                headers={"Retry-After": "60"},
            )
        # Auth provision continues — the router handler validates the IdP token.
        return await call_next(request)

    if auth_mode == "disabled" and normalized.startswith("/api"):
        logger.warning(
            "Unauthenticated request passed through: %s %s — auth is disabled (COREIQ_AUTH_MODE=disabled)",
            request.method,
            request.url.path,
        )
    elif required_key is not None and required_key != "" and normalized.startswith("/api"):
        # Skip auth on health/ready/docs/runtime-config — needed for probes, Swagger UI, and dashboard bootstrap
        if normalized in ("/api/health", "/api/ready", "/api/config", "/api/runtime-config", "/api/docs", "/api/redoc", "/api/openapi.json"):
            return await call_next(request)

        # Auth path 1: Bearer JWT from gateway/apps → validate via sidecar
        # Only for actual JWTs (3 dot-separated parts), not plain API keys.
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            api_token = auth_header[7:].strip()
            if api_token.count(".") >= 2 and not api_token.startswith("sk-coreiq-"):
                jwt_result = await _validate_jwt_via_sidecar(api_token)
                if jwt_result:
                    request.state.is_master = False
                    request.state.tenant_id = jwt_result.get("tenant_id")
                    request.state.user_id = jwt_result.get("sub")
                    return await call_next(request)
                return JSONResponse(status_code=401, content={"detail": "Invalid JWT"})

        # Auth path 2: X-API-Key (master key for dashboard)
        provided = request.headers.get("X-API-Key")
        if not hmac.compare_digest(provided or "", required_key):
            return JSONResponse(status_code=401, content={"detail": "Unauthorized"})

    request.state.is_master = True
    request.state.tenant_id = None
    return await call_next(request)


async def _validate_jwt_via_sidecar(token: str) -> dict | None:
    """Validate a JWT via CoreSDK sidecar gRPC, fallback to local HS256 verification."""
    # Try sidecar first
    try:
        import grpc
        addr = os.environ.get("CORESDK_SIDECAR_ADDR", "localhost:50051")
        from coresdk.v1 import auth_pb2, auth_pb2_grpc
        async with grpc.aio.insecure_channel(addr) as channel:
            stub = auth_pb2_grpc.AuthServiceStub(channel)
            res = await stub.ValidateToken(
                auth_pb2.ValidateTokenRequest(token=token),
                timeout=2.0,
            )
            if res.valid and res.subject and res.subject != "fail-open":
                return {"sub": res.subject, "tenant_id": res.claims.get("tenant_id", ""), "roles": list(res.roles)}
    except Exception as e:
        logger.warning("sidecar_jwt_validation_failed: %s", e)

    # Fallback: local HS256 verification using jose (same shared secret as CP)
    jwt_secret = os.environ.get("CORESDK_JWT_SECRET", "")
    if jwt_secret:
        try:
            from jose import jwt as jose_jwt
            payload = jose_jwt.decode(token, jwt_secret, algorithms=["HS256"])
            sub = payload.get("sub", "")
            if sub:
                return {"sub": sub, "tenant_id": payload.get("tenant_id", ""), "roles": payload.get("roles", [])}
        except Exception as e:
            logger.warning("local_jwt_validation_failed: %s", e)

    return None


# ── Observability middleware ───────────────────────────────────────────────────
#
# Runs inside auth_middleware (registered after it → more outer in Starlette).
# Generates a trace_id for every /api/* request, times the call, writes an
# event row, and for write operations also fans out to the ChainedAuditLogger.

_WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})
_AUDIT_SKIP_PREFIXES = (
    "/api/health", "/api/ready", "/api/config", "/api/runtime-config",
    "/api/docs", "/api/redoc", "/api/openapi.json",
)


@app.middleware("http")
async def observability_middleware(request: Request, call_next):
    normalized = request.url.path.rstrip("/").lower()
    # Only instrument /api/* paths; pass /v1/* and static assets through.
    if not normalized.startswith("/api"):
        return await call_next(request)

    t_start = time.monotonic()
    trace_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    request.state.obs_trace_id = trace_id

    response = await call_next(request)

    elapsed_ms = int((time.monotonic() - t_start) * 1000)
    status_code: int = response.status_code
    tenant_id: str | None = getattr(request.state, "tenant_id", None)

    # Write an event only for write operations or error responses.
    # Successful GET/HEAD reads are never logged — they are dashboard polls and
    # read-only calls that create noise and a self-referential feedback loop
    # (fetching /api/events would itself generate a new event).
    _is_write = request.method in _WRITE_METHODS
    _is_error = status_code >= 400
    if _is_write or _is_error:
        try:
            from ..store.writer import get_writer
            get_writer().insert_event(
                message=f"{request.method} {request.url.path} → {status_code}",
                level="warning" if status_code >= 400 else "info",
                source="api_middleware",
                trace_id=trace_id,
                tenant_id=tenant_id,
                metadata={
                    "method": request.method,
                    "path": request.url.path,
                    "status": status_code,
                    "latency_ms": elapsed_ms,
                },
            )
        except Exception as _evt_exc:
            logger.debug("observability_middleware: event write failed: %s", _evt_exc)

    # Fan-out to ChainedAuditLogger for management write operations.
    if (
        request.method in _WRITE_METHODS
        and not any(normalized.startswith(p) for p in _AUDIT_SKIP_PREFIXES)
    ):
        try:
            from ..governance.chained_audit import ChainedAuditLogger
            from ..governance.sinks.base import get_sink_router
            _audit = ChainedAuditLogger(source="api_middleware", sink_router=get_sink_router())
            _audit.log(
                action=f"{request.method} {request.url.path}",
                principal=tenant_id or "unknown",
                outcome="ok" if status_code < 400 else "error",
                metadata={
                    "status": status_code,
                    "latency_ms": elapsed_ms,
                    "trace_id": trace_id,
                },
            )
        except Exception as _audit_exc:
            logger.debug("observability_middleware: audit write failed: %s", _audit_exc)

    response.headers["X-Trace-ID"] = trace_id
    return response


# ── Global error handler ──────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception on %s: %s", request.url.path, exc, exc_info=True)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


# ── Routers ───────────────────────────────────────────────────────────────────

# Proxy gateway — mounted FIRST so /v1/* is not shadowed by dashboard static files.
app.include_router(proxy_router)

app.include_router(traces.router)
app.include_router(cache.router)
app.include_router(tool_calls.router)
app.include_router(feedback.router)
app.include_router(evolution.router)
app.include_router(query_recon.router)
app.include_router(optimiser.router)
app.include_router(events.router)
app.include_router(tools.router)
app.include_router(keys.router)
app.include_router(functions.router)
app.include_router(auth.router)
app.include_router(audit_chain_router.router)
app.include_router(eval_router.router)
app.include_router(governance_router.router)
app.include_router(datasets_router.router)
app.include_router(tenants_router.router)
app.include_router(violations_router.router)
app.include_router(request_logs_router.router)
app.include_router(integrations_router.router)
app.include_router(config_store_router.router)
app.include_router(billing_router.router)
app.include_router(users_router.router)
app.include_router(scim_router.router)
app.include_router(analytics_router.router)
app.include_router(incidents_router.router)
app.include_router(incidents_router._aup_router)
app.include_router(feature_flags_router.router)
app.include_router(egress_router.router)
app.include_router(agent_tokens_router.router)
app.include_router(revocation_router.router)
app.include_router(explain_router.router)
app.include_router(prompts_router.router)
app.include_router(firewall_router.router)
app.include_router(streaming_guard_router.router)
app.include_router(agent_governance_router.router)
app.include_router(cost_optimizer_router.router)
app.include_router(regression_router)
app.include_router(dlp_router)
app.include_router(canary_router)
app.include_router(redteam_router)
app.include_router(replay_router)
app.include_router(watermark_router)
app.include_router(multimodal_router)
app.include_router(ctx_router)
app.include_router(bias_router)
app.include_router(compliance_auto_router)
app.include_router(fed_router)
app.include_router(fp_router)
# cyberpod-gateway integration (v0.4.0)
app.include_router(routing_rules_router.router)
app.include_router(groups_router.router)
app.include_router(v1_integration_router.router)
app.include_router(policy_router.router)


# ── MCP server (Model Context Protocol) ──────────────────────────────────────
#
# Exposes the global tools registry over MCP at POST /mcp so MCP-aware
# clients (Claude Desktop, Cursor, OpenAI Agents SDK with MCP) can
# discover and call coreiq's registered tools.
try:
    from ..mcp import MCPServer, mount_mcp_router
    from ..tools.registry import ToolRegistry as _ToolRegistry

    _mcp_registry = _ToolRegistry()
    _mcp_server = MCPServer(
        registry=_mcp_registry,
        # tool_invoker is None by default — the MCP server is read-only
        # (tools/list works, tools/call returns -32002 until an invoker
        # is wired in). The tool execution path lives in coreiq's own
        # tool router and isn't exposed via MCP yet for security review.
        tool_invoker=None,
    )
    mount_mcp_router(app, _mcp_server, path="/mcp")
except Exception as _exc:  # pragma: no cover
    logger.warning("Failed to mount MCP server: %s", _exc)


# Dashboard static files are mounted at the end of this file (after all routes)
# so that /api/* routes take precedence over the catch-all "/" mount.


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/api/health", tags=["meta"])
def health():
    return {"status": "ok", "version": _coreiq_version}


@app.get("/api/runtime-config", tags=["meta"])
def get_runtime_config():
    """Return runtime configuration consumed by the dashboard.

    Distinct from GET /api/config (the config-store tenant key-value endpoint).
    """
    import os
    return {
        "default_model": os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b"),
    }


@app.get("/api/ready", tags=["meta"])
def readiness(request: Request):
    """Kubernetes readiness probe — checks the dependencies a request needs.

    Wave 2D deepened the probe to surface mis-configurations that would
    otherwise only fail at the first audited write or first policy
    decision. The probe checks:

    * **database**       — ``SELECT 1`` round trip on the shared backend.
    * **providers**      — at least one LLM provider is registered.
    * **audit_hmac**     — ``COREIQ_AUDIT_HMAC_KEY`` is set when running
      in production (or when ``COREIQ_AUDIT_FAIL_OPEN != true``); the
      chained-audit module refuses to write without it, so a missing
      key would only surface on the first audited request.
    * **policy_bundle**  — when ``COREIQ_POLICY_ENGINE=v2`` an active
      bundle must be loaded; without one the engine returns ALLOW and
      the marketed policy enforcement is silently disabled.

    Any failed check returns ``503`` with a JSON body so the load
    balancer keeps the pod out of rotation until shutdown is complete.
    """
    import os as _os

    checks: dict[str, object] = {}
    failures: list[str] = []

    # ── Database ──────────────────────────────────────────────────────
    try:
        from ..store.db import get_shared_connection
        conn = get_shared_connection()
        conn.execute("SELECT 1")
        checks["database"] = "ok"
    except Exception:
        logger.error("Readiness check DB error", exc_info=True)
        checks["database"] = "error"
        failures.append("database")

    # ── Providers ─────────────────────────────────────────────────────
    providers_ok = False
    try:
        registry = getattr(request.app.state, "provider_registry", None)
        if registry is not None:
            providers = registry.list_providers()
            if providers:
                checks["providers"] = providers
                providers_ok = True
            else:
                checks["providers"] = "none registered"
        else:
            checks["providers"] = "not initialized"
    except Exception:
        checks["providers"] = "unavailable"
    if not providers_ok:
        failures.append("providers")

    # ── Audit HMAC key (fail-loud in production) ──────────────────────
    env = _os.environ.get("COREIQ_ENV", "development").lower()
    fail_open = _os.environ.get("COREIQ_AUDIT_FAIL_OPEN", "").lower() in (
        "1", "true", "yes",
    )
    hmac_key = _os.environ.get("COREIQ_AUDIT_HMAC_KEY", "")
    if env == "production" and not fail_open and not hmac_key:
        checks["audit_hmac"] = "missing"
        failures.append("audit_hmac")
    else:
        # Either we're in dev, fail-open is set, or the key is present.
        checks["audit_hmac"] = "ok" if hmac_key else "skipped"

    # ── Active policy bundle (only when v2 engine is enabled) ─────────
    if _os.environ.get("COREIQ_POLICY_ENGINE", "").lower() == "v2":
        try:
            from ..policy import get_policy_engine
            engine = get_policy_engine()
            if engine.has_bundle:
                bundle = engine.get_bundle()
                checks["policy_bundle"] = (
                    getattr(bundle, "bundle_id", "active") if bundle else "active"
                )
            else:
                checks["policy_bundle"] = "no_active_bundle"
                failures.append("policy_bundle")
        except Exception as _exc:
            checks["policy_bundle"] = f"error: {_exc}"
            failures.append("policy_bundle")

    if failures:
        from fastapi.responses import JSONResponse
        return JSONResponse(
            status_code=503,
            content={"status": "not_ready", "checks": checks, "failed": failures},
        )

    return {"status": "ready", "checks": checks}


# ── Overview ──────────────────────────────────────────────────────────────────

def _safe_num(v, default=0):
    """Return *v* as a number, substituting *default* for None/nan/inf."""
    import math
    if v is None:
        return default
    try:
        f = float(v)
        return default if (math.isnan(f) or math.isinf(f)) else f
    except (TypeError, ValueError):
        return default


@app.get("/api/overview", tags=["meta"])
def overview(hours: int = 0):
    hours = max(0, min(hours, 8760))
    conn = get_shared_connection()
    cutoff = (
        (datetime.utcnow() - timedelta(hours=hours)).strftime('%Y-%m-%dT%H:%M:%S')
        if hours > 0 else None
    )
    # Build reusable WHERE / AND clauses using bound parameters
    where_params: tuple = (cutoff,) if cutoff else ()
    time_filter = " WHERE ts > ?" if cutoff else ""
    time_and = " AND ts > ?" if cutoff else ""

    traces_row = conn.execute(
        f"SELECT COUNT(*) as n, AVG(latency_ms) as avg_lat FROM traces{time_filter}",
        where_params,
    ).fetchone()
    cache_row = conn.execute(
        f"SELECT COUNT(*) as total, SUM(hit) as hits, SUM(CASE WHEN hit=1 THEN saved_tok ELSE 0 END) as saved FROM cache_events{time_filter}",
        where_params,
    ).fetchone()
    fb_row = conn.execute(
        f"SELECT signal, COUNT(*) as n, AVG(value) as avg_val FROM feedback{time_filter} GROUP BY signal",
        where_params,
    ).fetchall()
    fb = {r["signal"]: {"n": r["n"], "avg": r["avg_val"]} for r in fb_row}
    total = cache_row["total"] if cache_row else 0
    hits = cache_row["hits"] if cache_row else 0
    n_traces = traces_row["n"] if traces_row else 0
    fr_rows = conn.execute(
        f"SELECT finish_reason, COUNT(*) as n FROM traces{time_filter} GROUP BY finish_reason ORDER BY n DESC",
        where_params,
    ).fetchall()
    finish_reasons = {r["finish_reason"]: r["n"] for r in fr_rows}
    error_count = finish_reasons.get("error", 0)
    and_params: tuple = (cutoff,) if cutoff else ()
    count_row = conn.execute(
        f"SELECT COUNT(*) AS n FROM traces WHERE latency_ms IS NOT NULL{time_and}",
        and_params,
    ).fetchone()
    lat_total = count_row["n"] if count_row else 0

    def get_percentile(p):
        if lat_total == 0:
            return 0
        offset = max(0, int(lat_total * p / 100) - 1)
        row = conn.execute(
            f"SELECT latency_ms FROM traces WHERE latency_ms IS NOT NULL{time_and} ORDER BY latency_ms LIMIT 1 OFFSET ?",
            (*and_params, offset),
        ).fetchone()
        return row["latency_ms"] if row else 0

    p50 = get_percentile(50)
    p95 = get_percentile(95)
    p99 = get_percentile(99)

    provider_rows = conn.execute(
        f"SELECT provider, COUNT(*) as n FROM traces{time_filter} GROUP BY provider",
        where_params,
    ).fetchall()
    cost_row = conn.execute(
        f"SELECT SUM(cost_usd) as total_cost FROM traces{time_filter}",
        where_params,
    ).fetchone()

    return {
        "total_requests": n_traces,
        "total_cost_usd": round(_safe_num(cost_row["total_cost"] if cost_row else None), 6),
        "avg_latency_ms": round(_safe_num(traces_row["avg_lat"] if traces_row else None), 1),
        "p50_latency_ms": _safe_num(p50),
        "p95_latency_ms": _safe_num(p95),
        "p99_latency_ms": _safe_num(p99),
        "cache_hit_rate": round(hits / total, 4) if total else 0,
        "saved_tokens": _safe_num(cache_row["saved"] if cache_row else None),
        "thumbs_up": fb.get("thumbs_up", {}).get("n", 0),
        "thumbs_down": fb.get("thumbs_down", {}).get("n", 0),
        "avg_score": round(
            fb.get("score", {}).get("avg", 0) or (
                # Derive score from thumbs when no explicit scores exist
                (fb.get("thumbs_up", {}).get("n", 0) /
                 max(fb.get("thumbs_up", {}).get("n", 0) + fb.get("thumbs_down", {}).get("n", 0), 1))
                * 5.0  # Scale to 0-5 range
            ),
            2,
        ),
        "error_rate": round(error_count / n_traces, 4) if n_traces else 0,
        "finish_reasons": finish_reasons,
        "provider_split": {r["provider"]: r["n"] for r in provider_rows},
    }


# ── Dashboard Static Files ─────────────────────────────────────────────────────
# Mount AFTER all API routes so /api/* takes precedence over catch-all "/"
# Resolution order:
#   1. Packaged static dir (coreiq/server/static/) — ships inside the wheel
#   2. Docker layout (/app/dashboard/dist)
#   3. Monorepo source layout (../../../dashboard/dist) for editable installs
_packaged_dashboard = Path(__file__).resolve().parent / "static"
_docker_dashboard = Path("/app/dashboard/dist")
_monorepo_dashboard = Path(__file__).resolve().parent.parent.parent.parent / "dashboard" / "dist"
for _candidate in (_packaged_dashboard, _docker_dashboard, _monorepo_dashboard):
    if _candidate.exists() and (_candidate / "index.html").exists():
        app.mount("/", StaticFiles(directory=str(_candidate), html=True), name="static")
        break


@app.middleware("http")
async def _no_cache_html(request: Request, call_next):
    """Prevent browsers from caching index.html so dashboard rebuilds are picked up immediately."""
    response = await call_next(request)
    path = request.url.path
    if path == "/" or path.endswith("index.html") or ("." not in path.split("/")[-1]):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


# ── Entry point ───────────────────────────────────────────────────────────────

def start(**kwargs):
    import uvicorn
    uvicorn.run(
        app,
        host=get_host(),
        port=get_port(),
        log_level=get_log_level(),
        **kwargs,
    )


if __name__ == "__main__":
    start()
