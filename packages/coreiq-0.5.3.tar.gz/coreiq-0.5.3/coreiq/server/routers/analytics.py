"""Usage analytics API router."""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException, Query

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/daily-cost")
def daily_cost(
    tenant_id: Optional[str] = Query(None),
    days: int = Query(30, ge=1, le=365),
):
    """Daily aggregated cost, request count, and token usage."""
    try:
        from ...analytics.usage import UsageAnalytics
        rows = UsageAnalytics().daily_cost(tenant_id=tenant_id, days=days)
        return [
            {
                "date": r.date,
                "cost_usd": r.cost_usd,
                "requests": r.requests,
                "tokens": r.tokens,
            }
            for r in rows
        ]
    except Exception as exc:
        logger.exception("Unexpected error in daily_cost")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/provider-breakdown")
def provider_breakdown(
    tenant_id: Optional[str] = Query(None),
    days: int = Query(30, ge=1, le=365),
):
    """Per-provider request and cost breakdown."""
    try:
        from ...analytics.usage import UsageAnalytics
        rows = UsageAnalytics().provider_breakdown(tenant_id=tenant_id, days=days)
        return [
            {
                "provider": r.provider,
                "requests": r.requests,
                "cost_usd": r.cost_usd,
                "pct_requests": r.pct_requests,
                "pct_spend": r.pct_spend,
            }
            for r in rows
        ]
    except Exception as exc:
        logger.exception("Unexpected error in provider_breakdown")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/top-models")
def top_models(
    tenant_id: Optional[str] = Query(None),
    limit: int = Query(10, ge=1, le=100),
):
    """Top models by spend."""
    try:
        from ...analytics.usage import UsageAnalytics
        rows = UsageAnalytics().top_models(tenant_id=tenant_id, limit=limit)
        return [
            {
                "model": r.model,
                "provider": r.provider,
                "requests": r.requests,
                "cost_usd": r.cost_usd,
                "pct_spend": r.pct_spend,
            }
            for r in rows
        ]
    except Exception as exc:
        logger.exception("Unexpected error in top_models")
        raise HTTPException(status_code=500, detail="Internal server error") from exc
