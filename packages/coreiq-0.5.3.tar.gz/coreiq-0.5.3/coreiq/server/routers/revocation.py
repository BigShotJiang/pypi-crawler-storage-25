"""Token revocation endpoints."""
from __future__ import annotations
import logging
from fastapi import APIRouter, Query
from pydantic import BaseModel
from ...identity.revocation import RevocationService

logger = logging.getLogger(__name__)
router = APIRouter()

class RevokeRequest(BaseModel):
    token_id: str
    reason: str = ""
    revoked_by: str = ""

@router.post("/api/tokens/revoke")
def revoke_token(body: RevokeRequest):
    """Revoke a token by ID."""
    svc = RevocationService()
    svc.revoke(body.token_id, reason=body.reason, revoked_by=body.revoked_by)
    return {"status": "revoked", "token_id": body.token_id}

@router.get("/api/tokens/revoked")
def list_revoked(limit: int = Query(100, le=1000), offset: int = 0):
    """List revoked tokens."""
    svc = RevocationService()
    return svc.list_revoked(limit=limit, offset=offset)

@router.get("/api/tokens/check")
def check_revoked(token_id: str = Query(...)):
    """Check if a token is revoked."""
    svc = RevocationService()
    return {"token_id": token_id, "revoked": svc.is_revoked(token_id)}
