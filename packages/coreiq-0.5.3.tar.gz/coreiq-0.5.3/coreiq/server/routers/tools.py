"""Tool catalog API — register, list, search, and remove tools."""
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

from ...exceptions import ValidationError
from ...tools.registry import ToolRegistry
from ...tools.router import ToolRouter

router = APIRouter(prefix="/api/tools", tags=["tools"])

# In-memory singletons scoped to this server process.
# Clients re-register tools on startup.
_registry = ToolRegistry()
_router = ToolRouter(_registry)


# ── Pydantic models ────────────────────────────────────────────────────────────

class ToolRegisterRequest(BaseModel):
    tools: List[dict]
    defer_loading: bool = False


class ToolSearchRequest(BaseModel):
    query: str
    top_k: int = Field(default=5, ge=1, le=50)
    include_deferred: bool = True


class ToolSpecResponse(BaseModel):
    name: str
    description: str
    parameters: dict
    defer_loading: bool
    similarity_score: Optional[float] = None


class ToolSearchResponse(BaseModel):
    query: str
    top_k: int
    results: List[ToolSpecResponse]
    tokens_saved: int
    catalog_size: int


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.post("/register", summary="Register tools into the catalog")
def register_tools(body: ToolRegisterRequest):
    """Register one or more tool definitions.

    Set ``defer_loading=true`` to add tools to the deferred catalog — they are
    only loaded into context when explicitly searched for.
    """
    try:
        _registry.register(body.tools, defer_loading=body.defer_loading)
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return {"registered": len(body.tools), "total": len(_registry)}


@router.get("", response_model=List[ToolSpecResponse], summary="List registered tools")
def list_tools(include_deferred: bool = True, limit: int = 100):
    """Return registered tools.

    Pass ``include_deferred=false`` to see only eager (always-loaded) tools.
    """
    tools = _registry.all() if include_deferred else _registry.get_eager()
    return [
        ToolSpecResponse(
            name=s.name,
            description=s.description,
            parameters=s.parameters,
            defer_loading=s.defer_loading,
        )
        for s in tools[:limit]
    ]


@router.post("/search", response_model=ToolSearchResponse, summary="Search the tool catalog")
def search_tools(body: ToolSearchRequest):
    """Semantic search over the tool catalog.

    When ``include_deferred=true`` (default), searches only deferred tools —
    the catalog that is too large to load upfront. Returns tools ranked by
    semantic similarity (sentence-transformers) combined with evolution win-rate.
    """
    if body.include_deferred:
        hits = _router.select_deferred(body.query, body.top_k)
        results = [
            ToolSpecResponse(
                name=spec.name,
                description=spec.description,
                parameters=spec.parameters,
                defer_loading=spec.defer_loading,
                similarity_score=round(score, 4),
            )
            for spec, score in hits
        ]
        specs = [spec for spec, _ in hits]
    else:
        specs = _router.select(body.query, body.top_k)
        results = [
            ToolSpecResponse(
                name=s.name,
                description=s.description,
                parameters=s.parameters,
                defer_loading=s.defer_loading,
            )
            for s in specs
        ]

    return ToolSearchResponse(
        query=body.query,
        top_k=body.top_k,
        results=results,
        tokens_saved=_router.token_savings(specs),
        catalog_size=len(_registry),
    )


@router.delete("/{name}", status_code=204, summary="Remove a tool from the catalog")
def delete_tool(name: str):
    """Remove a tool by name. Returns 204 on success, 404 if not found."""
    if not _registry.remove(name):
        raise HTTPException(status_code=404, detail=f"Tool '{name}' not found")
    return Response(status_code=204)
