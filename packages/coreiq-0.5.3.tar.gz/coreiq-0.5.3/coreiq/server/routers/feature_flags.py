"""Feature flag management endpoints."""
from __future__ import annotations
import logging
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from ...governance.feature_flags import FlagService

logger = logging.getLogger(__name__)
router = APIRouter()

class CreateFlagRequest(BaseModel):
    key: str
    description: str = ""
    enabled_by_default: bool = False

class SetOverrideRequest(BaseModel):
    key: str
    tenant_id: str = ""
    user_id: str = ""
    enabled: bool = True

@router.get("/api/flags")
def list_flags():
    """List all feature flags."""
    svc = FlagService()
    return svc.list_flags()

@router.get("/api/flags/evaluate")
def evaluate_flag(key: str = Query(...), tenant_id: str = "", user_id: str = ""):
    """Evaluate a feature flag."""
    svc = FlagService()
    decision = svc.evaluate(key, tenant_id=tenant_id, user_id=user_id)
    return {"enabled": decision.enabled, "key": decision.key, "reason": decision.reason}

@router.post("/api/flags", status_code=201)
def create_flag(body: CreateFlagRequest):
    """Create a feature flag."""
    svc = FlagService()
    flag = svc.create_flag(body.key, body.description, body.enabled_by_default)
    return {"flag": {"id": flag.id, "key": flag.key, "enabled_by_default": flag.enabled_by_default}}

@router.post("/api/flags/override")
def set_override(body: SetOverrideRequest):
    """Set a tenant or user override."""
    svc = FlagService()
    try:
        svc.set_override(body.key, tenant_id=body.tenant_id, user_id=body.user_id, enabled=body.enabled)
        return {"status": "ok"}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))

@router.delete("/api/flags/{key}")
def delete_flag(key: str):
    """Delete a feature flag."""
    svc = FlagService()
    if not svc.delete_flag(key):
        raise HTTPException(status_code=404, detail="Flag not found")
    return {"status": "deleted", "key": key}
