"""SCIM 2.0 API router for CoreIQ."""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/scim/v2", tags=["scim"])

_SCIM_CONTENT_TYPE = "application/scim+json"


def _scim_response(data: dict, status_code: int = 200) -> JSONResponse:
    return JSONResponse(content=data, status_code=status_code, media_type=_SCIM_CONTENT_TYPE)


def _scim_error(status_code: int, detail: str) -> JSONResponse:
    return JSONResponse(
        content={
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:Error"],
            "status": str(status_code),
            "detail": detail,
        },
        status_code=status_code,
        media_type=_SCIM_CONTENT_TYPE,
    )


@router.post("/Users")
async def scim_create_user(resource: dict):
    """SCIM 2.0 — create a user."""
    try:
        from ...identity.scim import SCIMHandler
        result = SCIMHandler().create_user(resource)
        return _scim_response(result, status_code=201)
    except Exception as exc:
        logger.exception("SCIM operation failed in scim_create_user")
        return _scim_error(500, str(exc))


@router.get("/Users")
async def scim_list_users(
    filter: Optional[str] = Query(None, alias="filter"),
    count: int = Query(100, ge=1, le=1000),
    startIndex: int = Query(1, ge=1),
):
    """SCIM 2.0 — list users."""
    try:
        from ...identity.scim import SCIMHandler
        result = SCIMHandler().list_users(filter_str=filter, count=count, start_index=startIndex)
        return _scim_response(result)
    except Exception as exc:
        logger.exception("SCIM operation failed in scim_list_users")
        return _scim_error(500, str(exc))


@router.get("/Users/{scim_id}")
async def scim_get_user(scim_id: str):
    """SCIM 2.0 — get a user by ID."""
    try:
        from ...identity.scim import SCIMHandler
        result = SCIMHandler().get_user(scim_id)
        if result is None:
            return _scim_error(404, f"User {scim_id!r} not found")
        return _scim_response(result)
    except Exception as exc:
        logger.exception("SCIM operation failed in scim_get_user")
        return _scim_error(500, str(exc))


@router.put("/Users/{scim_id}")
async def scim_replace_user(scim_id: str, resource: dict):
    """SCIM 2.0 — replace (full update) a user."""
    try:
        from ...identity.scim import SCIMHandler
        result = SCIMHandler().update_user(scim_id, resource)
        return _scim_response(result)
    except KeyError:
        return _scim_error(404, f"User {scim_id!r} not found")
    except Exception as exc:
        logger.exception("SCIM operation failed in scim_replace_user")
        return _scim_error(500, str(exc))


@router.delete("/Users/{scim_id}")
async def scim_delete_user(scim_id: str):
    """SCIM 2.0 — delete a user."""
    try:
        from ...identity.scim import SCIMHandler
        deleted = SCIMHandler().delete_user(scim_id)
        if not deleted:
            return _scim_error(404, f"User {scim_id!r} not found")
        return JSONResponse(content=None, status_code=204)
    except Exception as exc:
        logger.exception("SCIM operation failed in scim_delete_user")
        return _scim_error(500, str(exc))
