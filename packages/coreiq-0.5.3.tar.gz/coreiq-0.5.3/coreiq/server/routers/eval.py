"""Eval API router — trigger LLM-as-a-Judge evaluations, list scores, aggregate stats."""
from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...store.backends.base import StorageBackend
from ...store.db import get_shared_connection

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/eval", tags=["eval"])


def _conn() -> StorageBackend:
    return get_shared_connection()


class EvalRequest(BaseModel):
    trace_id: str
    prompt: str = ""
    response: str = ""
    context: str = ""
    judges: Optional[List[str]] = None
    judge_model: str = ""
    judge_provider: str = "openai_compat"


class EvalResponse(BaseModel):
    trace_id: str
    scores: dict
    rationales: dict
    judges_run: List[str]
    error: Optional[str] = None


@router.post("/evaluate", response_model=EvalResponse)
async def trigger_eval(req: EvalRequest):
    """Trigger LLM-as-a-Judge evaluation for a specific trace."""
    try:
        from ...evolution.evaluator import EvalEngine
        from ...evolution.judges.base import BuiltinJudge

        judge_map = {
            "faithfulness": BuiltinJudge.FAITHFULNESS,
            "hallucination": BuiltinJudge.HALLUCINATION,
            "answer_relevance": BuiltinJudge.ANSWER_RELEVANCE,
            "toxicity": BuiltinJudge.TOXICITY,
            "groundedness": BuiltinJudge.GROUNDEDNESS,
        }

        if req.judges:
            judges = [judge_map[j] for j in req.judges if j in judge_map]
            if not judges:
                raise HTTPException(status_code=400, detail=f"Unknown judges: {req.judges}. Valid: {list(judge_map)}")
        else:
            judges = list(judge_map.values())

        import os
        judge_model = req.judge_model or os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")
        engine = EvalEngine(
            judges=judges,
            judge_model=judge_model,
            judge_provider=req.judge_provider,
        )
        result = await engine.evaluate(
            trace_id=req.trace_id,
            prompt=req.prompt,
            response=req.response,
            context=req.context,
        )
        return EvalResponse(
            trace_id=result.trace_id,
            scores=result.scores,
            rationales=result.rationales,
            judges_run=result.judges_run,
            error=result.error,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Unexpected error in trigger_eval")
        raise HTTPException(status_code=500, detail="Internal server error") from e


@router.get("/scores/{trace_id}")
def get_scores(trace_id: str):
    """Get all eval scores for a specific trace."""
    conn = _conn()
    rows = conn.execute(
        "SELECT * FROM eval_scores WHERE trace_id = ? ORDER BY ts DESC",
        (trace_id,),
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/scores")
def list_scores(
    dimension: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
):
    """List eval scores with optional dimension filter."""
    conn = _conn()
    where = "WHERE dimension = ?" if dimension else ""
    params = [dimension] if dimension else []
    params.extend([limit, offset])
    rows = conn.execute(
        f"SELECT * FROM eval_scores {where} ORDER BY ts DESC LIMIT ? OFFSET ?",
        params,
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/stats")
def eval_stats(dimension: Optional[str] = None):
    """Aggregate eval score statistics per dimension."""
    conn = _conn()
    where = "WHERE dimension = ?" if dimension else ""
    params = [dimension] if dimension else []
    rows = conn.execute(
        f"""
        SELECT
            dimension,
            COUNT(*) as count,
            AVG(score) as avg_score,
            MIN(score) as min_score,
            MAX(score) as max_score,
            AVG(CASE WHEN score >= 0.7 THEN 1.0 ELSE 0.0 END) as pass_rate
        FROM eval_scores
        {where}
        GROUP BY dimension
        ORDER BY dimension
        """,
        params,
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/trend")
def eval_trend(dimension: Optional[str] = None, hours: int = 24):
    """Hourly average eval scores over recent period."""
    from datetime import datetime, timedelta, timezone
    conn = _conn()
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    where_parts = ["ts > ?"]
    params: list = [cutoff]
    if dimension:
        where_parts.append("dimension = ?")
        params.append(dimension)
    where = "WHERE " + " AND ".join(where_parts)
    rows = conn.execute(
        f"""
        SELECT
            strftime('%Y-%m-%dT%H:00:00', ts) as hour,
            dimension,
            AVG(score) as avg_score,
            COUNT(*) as count
        FROM eval_scores
        {where}
        GROUP BY hour, dimension
        ORDER BY hour ASC
        """,
        params,
    ).fetchall()
    return [dict(r) for r in rows]
