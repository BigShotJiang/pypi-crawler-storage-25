"""API router for function, variant, experiment, and metric management."""
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...optimization.function import FunctionRegistry, FunctionType
from ...optimization.variant import VariantManager, VariantType
from ...optimization.experiment import (
    ExperimentManager,
    ExperimentAlgorithm,
    ExperimentConfig,
    ExperimentStatus,
    ExperimentType,
)
from ...optimization.metrics import MetricRegistry, MetricLevel, MetricOptimize, MetricType
from ...optimization.feedback import MetricRecorder

router = APIRouter(prefix="/api", tags=["functions"])

# ---------------------------------------------------------------------------
# Singletons (lazy-initialised, thread-safe via their own locks)
# ---------------------------------------------------------------------------

_fn_registry: Optional[FunctionRegistry] = None
_variant_mgr: Optional[VariantManager] = None
_experiment_mgr: Optional[ExperimentManager] = None
_metric_registry: Optional[MetricRegistry] = None
_metric_recorder: Optional[MetricRecorder] = None


def _get_fn_registry() -> FunctionRegistry:
    global _fn_registry
    if _fn_registry is None:
        _fn_registry = FunctionRegistry()
    return _fn_registry


def _get_variant_mgr() -> VariantManager:
    global _variant_mgr
    if _variant_mgr is None:
        _variant_mgr = VariantManager()
    return _variant_mgr


def _get_experiment_mgr() -> ExperimentManager:
    global _experiment_mgr
    if _experiment_mgr is None:
        _experiment_mgr = ExperimentManager()
    return _experiment_mgr


def _get_metric_registry() -> MetricRegistry:
    global _metric_registry
    if _metric_registry is None:
        _metric_registry = MetricRegistry()
    return _metric_registry


def _get_metric_recorder() -> MetricRecorder:
    global _metric_recorder
    if _metric_recorder is None:
        _metric_recorder = MetricRecorder(
            metric_registry=_get_metric_registry(),
            experiment_manager=_get_experiment_mgr(),
        )
    return _metric_recorder


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class FunctionCreate(BaseModel):
    name: str
    type: str = "chat"
    tenant_id: str = "default"
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None


class FunctionUpdate(BaseModel):
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None


class VariantCreate(BaseModel):
    name: str
    type: str = "chat_completion"
    model: Optional[str] = None
    system_template: Optional[str] = None
    user_template: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    weight: float = 1.0
    active: bool = True


class ExperimentCreate(BaseModel):
    name: str
    type: str = "adaptive"
    candidate_variant_ids: List[str]
    algorithm: Optional[str] = None
    metric_name: Optional[str] = None
    config: Optional[Dict[str, Any]] = None


class ExperimentConclude(BaseModel):
    winner_variant_id: Optional[str] = None


class MetricRecord(BaseModel):
    metric_name: str
    inference_id: Optional[str] = None
    episode_id: Optional[str] = None
    value: Optional[float] = None
    comment: Optional[str] = None
    demonstration: Optional[str] = None
    user_id: Optional[str] = None


class MetricDefCreate(BaseModel):
    name: str
    type: str
    level: str = "inference"
    optimize: str = "max"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fn_to_dict(fd) -> dict:
    return {
        "id": fd.id,
        "name": fd.name,
        "type": fd.type.value,
        "tenant_id": fd.tenant_id,
        "input_schema": fd.input_schema,
        "output_schema": fd.output_schema,
        "created_at": fd.created_at,
    }


def _variant_to_dict(vd) -> dict:
    return {
        "id": vd.id,
        "function_id": vd.function_id,
        "name": vd.name,
        "type": vd.type.value,
        "model": vd.model,
        "system_template": vd.system_template,
        "user_template": vd.user_template,
        "config": vd.config,
        "weight": vd.weight,
        "active": vd.active,
        "created_at": vd.created_at,
    }


def _experiment_to_dict(exp) -> dict:
    return {
        "id": exp.id,
        "function_id": exp.function_id,
        "name": exp.name,
        "type": exp.type.value,
        "algorithm": exp.algorithm.value if exp.algorithm else None,
        "metric_name": exp.metric_name,
        "status": exp.status.value,
        "config": {
            "min_samples_per_variant": exp.config.min_samples_per_variant,
            "delta": exp.config.delta,
            "epsilon": exp.config.epsilon,
            "update_period_s": exp.config.update_period_s,
            "max_samples": exp.config.max_samples,
        } if exp.config else None,
        "candidate_variant_ids": exp.candidate_variant_ids,
        "winner_variant_id": exp.winner_variant_id,
        "started_at": exp.started_at,
        "concluded_at": exp.concluded_at,
    }


def _resolve_function(name: str):
    """Resolve a function by name, raising 404 if not found."""
    fn = _get_fn_registry().get(name)
    if fn is None:
        raise HTTPException(status_code=404, detail=f"Function '{name}' not found")
    return fn


# ---------------------------------------------------------------------------
# Functions CRUD
# ---------------------------------------------------------------------------


@router.post("/functions")
def create_function(body: FunctionCreate):
    try:
        fn_type = FunctionType(body.type)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid function type: {body.type!r}")
    try:
        fd = _get_fn_registry().create(
            name=body.name,
            type=fn_type,
            tenant_id=body.tenant_id,
            input_schema=body.input_schema,
            output_schema=body.output_schema,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return _fn_to_dict(fd)


@router.get("/functions")
def list_functions(tenant_id: Optional[str] = None):
    return [_fn_to_dict(f) for f in _get_fn_registry().list(tenant_id=tenant_id)]


@router.get("/functions/{name}")
def get_function(name: str):
    return _fn_to_dict(_resolve_function(name))


@router.put("/functions/{name}")
def update_function(name: str, body: FunctionUpdate):
    kwargs: dict = {}
    if body.input_schema is not None:
        kwargs["input_schema"] = body.input_schema
    if body.output_schema is not None:
        kwargs["output_schema"] = body.output_schema
    fd = _get_fn_registry().update(name, **kwargs)
    if fd is None:
        raise HTTPException(status_code=404, detail=f"Function '{name}' not found")
    return _fn_to_dict(fd)


@router.delete("/functions/{name}")
def delete_function(name: str):
    if not _get_fn_registry().delete(name):
        raise HTTPException(status_code=404, detail=f"Function '{name}' not found")
    return {"ok": True}


# ---------------------------------------------------------------------------
# Variants
# ---------------------------------------------------------------------------


@router.post("/functions/{name}/variants")
def create_variant(name: str, body: VariantCreate):
    fn = _resolve_function(name)
    try:
        vt = VariantType(body.type)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid variant type: {body.type!r}")
    try:
        vd = _get_variant_mgr().create(
            function_id=fn.id,
            name=body.name,
            type=vt,
            model=body.model,
            system_template=body.system_template,
            user_template=body.user_template,
            config=body.config,
            weight=body.weight,
            active=body.active,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return _variant_to_dict(vd)


@router.get("/functions/{name}/variants")
def list_variants(name: str, active_only: bool = False):
    fn = _resolve_function(name)
    return [
        _variant_to_dict(v) for v in _get_variant_mgr().list(fn.id, active_only=active_only)
    ]


# ---------------------------------------------------------------------------
# Experiments
# ---------------------------------------------------------------------------


@router.post("/functions/{name}/experiments")
def create_experiment(name: str, body: ExperimentCreate):
    fn = _resolve_function(name)
    try:
        exp_type = ExperimentType(body.type)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid experiment type: {body.type!r}")

    algorithm = None
    if body.algorithm:
        try:
            algorithm = ExperimentAlgorithm(body.algorithm)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid algorithm: {body.algorithm!r}")

    config = None
    if body.config:
        config = ExperimentConfig(
            min_samples_per_variant=body.config.get("min_samples_per_variant", 20),
            delta=body.config.get("delta", 0.05),
            epsilon=body.config.get("epsilon", 0.01),
            update_period_s=body.config.get("update_period_s", 300),
            max_samples=body.config.get("max_samples", 10000),
        )

    try:
        exp = _get_experiment_mgr().create(
            function_id=fn.id,
            name=body.name,
            type=exp_type,
            candidate_variant_ids=body.candidate_variant_ids,
            algorithm=algorithm,
            metric_name=body.metric_name,
            config=config,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return _experiment_to_dict(exp)


@router.get("/functions/{name}/experiments")
def list_experiments(name: str, status: Optional[str] = None):
    fn = _resolve_function(name)
    exp_status = None
    if status:
        try:
            exp_status = ExperimentStatus(status)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid status: {status!r}")
    return [
        _experiment_to_dict(e)
        for e in _get_experiment_mgr().list(function_id=fn.id, status=exp_status)
    ]


@router.post("/functions/{name}/experiments/{experiment_id}/start")
def start_experiment(name: str, experiment_id: str):
    _resolve_function(name)  # validate function exists
    try:
        exp = _get_experiment_mgr().start(experiment_id)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return _experiment_to_dict(exp)


@router.post("/functions/{name}/experiments/{experiment_id}/conclude")
def conclude_experiment(name: str, experiment_id: str, body: ExperimentConclude):
    _resolve_function(name)  # validate function exists
    try:
        exp = _get_experiment_mgr().conclude(
            experiment_id,
            winner_variant_id=body.winner_variant_id,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return _experiment_to_dict(exp)


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------


@router.post("/metrics")
def record_metric(body: MetricRecord):
    try:
        result = _get_metric_recorder().record(
            body.metric_name,
            inference_id=body.inference_id,
            episode_id=body.episode_id,
            value=body.value,
            comment=body.comment,
            demonstration=body.demonstration,
            user_id=body.user_id,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return result


@router.get("/metrics/definitions")
def list_metric_definitions():
    return [
        {
            "id": md.id,
            "name": md.name,
            "type": md.type.value,
            "level": md.level.value,
            "optimize": md.optimize.value,
            "created_at": md.created_at,
        }
        for md in _get_metric_registry().list()
    ]


@router.post("/metrics/definitions")
def create_metric_definition(body: MetricDefCreate):
    try:
        mt = MetricType(body.type)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid metric type: {body.type!r}")
    try:
        ml = MetricLevel(body.level)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid metric level: {body.level!r}")
    try:
        mo = MetricOptimize(body.optimize)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid optimize direction: {body.optimize!r}")
    try:
        md = _get_metric_registry().create(name=body.name, type=mt, level=ml, optimize=mo)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {
        "id": md.id,
        "name": md.name,
        "type": md.type.value,
        "level": md.level.value,
        "optimize": md.optimize.value,
        "created_at": md.created_at,
    }
