from fastapi import APIRouter, Depends, Query
from typing import Optional, Any, Dict
import json
from pydantic import BaseModel
from ...store.backends.base import StorageBackend
from ...store.db import get_shared_connection
from ..deps import require_tenant
from ...store.writer import get_writer

router = APIRouter(prefix="/api/events", tags=["events"])


def _conn() -> StorageBackend:
    return get_shared_connection()


class EventCreate(BaseModel):
    message: str
    level: str = "info"
    source: Optional[str] = None
    trace_id: Optional[str] = None
    tenant_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@router.post("", status_code=201)
def create_event(body: EventCreate):
    writer = get_writer()
    event_id = writer.insert_event(
        message=body.message,
        level=body.level,
        source=body.source,
        trace_id=body.trace_id,
        tenant_id=body.tenant_id,
        metadata=body.metadata,
    )
    writer.flush()
    return {
        "id": event_id,
        "ok": True,
        "message": body.message,
        "app": body.source,
    }


@router.get("")
def list_events(
    limit: int = Query(100, le=1000),
    offset: int = 0,
    level: Optional[str] = None,
    source: Optional[str] = None,
    trace_id: Optional[str] = None,
    from_ts: Optional[str] = Query(None, alias="from"),
    tenant_id: Optional[str] = Depends(require_tenant),
):
    conn = _conn()
    where, params = [], []
    if tenant_id:
        where.append("tenant_id = ?")
        params.append(tenant_id)
    if level:
        where.append("level = ?")
        params.append(level)
    if source:
        where.append("source = ?")
        params.append(source)
    if trace_id:
        where.append("trace_id = ?")
        params.append(trace_id)
    if from_ts:
        where.append("ts >= ?")
        params.append(from_ts)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT * FROM events {clause} ORDER BY ts DESC LIMIT ? OFFSET ?",
        params + [limit, offset]
    ).fetchall()
    result = []
    for r in rows:
        row = dict(r)
        if row.get("meta_json"):
            try:
                row["metadata"] = json.loads(row["meta_json"])
            except Exception:
                row["metadata"] = {}
        else:
            row["metadata"] = {}
        result.append(row)
    return result


@router.get("/summary")
def events_summary(tenant_id: Optional[str] = Depends(require_tenant)):
    conn = _conn()
    if tenant_id:
        row = conn.execute("SELECT COUNT(*) AS total FROM events WHERE tenant_id = ?", (tenant_id,)).fetchone()
        total = row["total"] if row else 0
        by_level = {
            row["level"]: row["cnt"]
            for row in conn.execute(
                "SELECT level, COUNT(*) as cnt FROM events WHERE tenant_id = ? GROUP BY level",
                (tenant_id,)
            ).fetchall()
        }
    else:
        row = conn.execute("SELECT COUNT(*) AS total FROM events").fetchone()
        total = row["total"] if row else 0
        by_level = {
            row["level"]: row["cnt"]
            for row in conn.execute(
                "SELECT level, COUNT(*) as cnt FROM events GROUP BY level"
            ).fetchall()
        }
    return {"total": total, "by_level": by_level}
