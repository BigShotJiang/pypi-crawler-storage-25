"""REST router for content-aware routing rules (B1).

Exposes CRUD + dry-run preview for :class:`RoutingRule` objects so the
cyberpod-gateway portal can manage rules without touching the underlying
``DeploymentRouter``. Actual call-time enforcement is deferred.

Endpoints (all under ``/api/routing``):

- ``POST /rules`` — create
- ``GET /rules`` — list with ``tenant_id`` / ``enabled`` filters
- ``GET /rules/{rule_id}`` — get one
- ``PUT /rules/{rule_id}`` — update
- ``DELETE /rules/{rule_id}`` — delete
- ``POST /rules/{rule_id}/test`` — run a single rule against a payload
- ``POST /rules/preview`` — run all enabled rules and return first match
- ``GET /status`` — in-memory counters + rule totals
"""
from __future__ import annotations

import logging
import threading
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from ...proxy.routing.matchers import (
    RoutingRequest,
    UnknownMatcherTypeError,
    matchers_from_list,
    matchers_to_list,
)
from ...proxy.routing.rules import (
    VALID_ACTIONS,
    RoutingRule,
    RuleEvaluator,
    RuleStore,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/routing", tags=["routing-rules"])


# ---------------------------------------------------------------------------
# Process-local state
# ---------------------------------------------------------------------------


_store = RuleStore()
_eval_counter_lock = threading.Lock()
_eval_counter = {"total": 0, "matched": 0}


def _bump_eval(matched: bool) -> None:
    with _eval_counter_lock:
        _eval_counter["total"] += 1
        if matched:
            _eval_counter["matched"] += 1


# ---------------------------------------------------------------------------
# Pydantic request / response models
# ---------------------------------------------------------------------------


class RoutingRequestModel(BaseModel):
    tenant_id: str = ""
    model: str = ""
    messages: list[dict] = Field(default_factory=list)
    estimated_tokens: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_request(self) -> RoutingRequest:
        return RoutingRequest(
            tenant_id=self.tenant_id,
            model=self.model,
            messages=self.messages,
            estimated_tokens=self.estimated_tokens,
            metadata=self.metadata,
        )


class CreateRuleRequest(BaseModel):
    tenant_id: str = ""
    name: str
    priority: int = 100
    matchers: list[dict[str, Any]] = Field(default_factory=list)
    action: str = "route"
    target_model_prefix: Optional[str] = None
    target_deployment_id: Optional[str] = None
    enabled: bool = True


class UpdateRuleRequest(BaseModel):
    tenant_id: Optional[str] = None
    name: Optional[str] = None
    priority: Optional[int] = None
    matchers: Optional[list[dict[str, Any]]] = None
    action: Optional[str] = None
    target_model_prefix: Optional[str] = None
    target_deployment_id: Optional[str] = None
    enabled: Optional[bool] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _rule_payload(rule: RoutingRule) -> dict[str, Any]:
    return rule.to_dict()


def _parse_matchers(raw: list[dict[str, Any]]) -> list[Any]:
    try:
        return matchers_from_list(raw)
    except UnknownMatcherTypeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


def _validate_action(action: str) -> None:
    if action not in VALID_ACTIONS:
        raise HTTPException(
            status_code=400,
            detail=f"invalid action {action!r}; expected one of {list(VALID_ACTIONS)}",
        )


# ---------------------------------------------------------------------------
# CRUD endpoints
# ---------------------------------------------------------------------------


@router.post("/rules")
def create_rule(req: CreateRuleRequest):
    """Create a routing rule."""
    _validate_action(req.action)
    matchers = _parse_matchers(req.matchers)
    rule = RoutingRule(
        tenant_id=req.tenant_id,
        name=req.name,
        priority=req.priority,
        matchers=matchers,
        action=req.action,
        target_model_prefix=req.target_model_prefix,
        target_deployment_id=req.target_deployment_id,
        enabled=req.enabled,
    )
    try:
        saved = _store.create(rule)
    except Exception as exc:
        logger.exception("failed to create routing rule")
        raise HTTPException(status_code=500, detail="failed to create rule") from exc
    return _rule_payload(saved)


@router.get("/rules")
def list_rules(
    tenant_id: Optional[str] = Query(None),
    enabled: Optional[bool] = Query(None),
):
    """List routing rules, optionally filtered by tenant / enabled state."""
    rules = _store.list(tenant_id=tenant_id, enabled=enabled)
    return [_rule_payload(r) for r in rules]


@router.get("/rules/{rule_id}")
def get_rule(rule_id: str):
    rule = _store.get(rule_id)
    if rule is None:
        raise HTTPException(status_code=404, detail="rule not found")
    return _rule_payload(rule)


@router.put("/rules/{rule_id}")
def update_rule(rule_id: str, req: UpdateRuleRequest):
    existing = _store.get(rule_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="rule not found")
    fields: dict[str, Any] = {}
    for k in (
        "tenant_id",
        "name",
        "priority",
        "action",
        "target_model_prefix",
        "target_deployment_id",
        "enabled",
    ):
        v = getattr(req, k)
        if v is not None:
            fields[k] = v
    if req.matchers is not None:
        fields["matchers"] = _parse_matchers(req.matchers)
    if "action" in fields:
        _validate_action(fields["action"])
    try:
        updated = _store.update(rule_id, **fields)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if updated is None:
        raise HTTPException(status_code=404, detail="rule not found")
    return _rule_payload(updated)


@router.delete("/rules/{rule_id}")
def delete_rule(rule_id: str):
    existing = _store.get(rule_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="rule not found")
    _store.delete(rule_id)
    return {"deleted": True, "id": rule_id}


# ---------------------------------------------------------------------------
# Dry-run endpoints
# ---------------------------------------------------------------------------


@router.post("/rules/{rule_id}/test")
def test_rule(rule_id: str, req: RoutingRequestModel):
    """Run a single rule against a payload without persisting a hit."""
    rule = _store.get(rule_id)
    if rule is None:
        raise HTTPException(status_code=404, detail="rule not found")
    evaluator = RuleEvaluator([rule])
    result = evaluator.evaluate(req.to_request())
    _bump_eval(result.matched)
    return result.to_dict()


@router.post("/rules/preview")
def preview_rules(req: RoutingRequestModel):
    """Run every enabled rule for the calling tenant and return first match."""
    rules = _store.list(tenant_id=req.tenant_id or None, enabled=True)
    if not rules:
        # Fall back to every enabled rule if tenant filter yielded nothing,
        # to keep the dry-run useful in single-tenant dev setups.
        rules = _store.list(enabled=True)
    evaluator = RuleEvaluator(rules)
    result = evaluator.evaluate(req.to_request())
    _bump_eval(result.matched)
    if result.matched and result.rule_id:
        try:
            _store.increment_hits(result.rule_id)
        except Exception:
            logger.debug("failed to increment hit_count for rule %s", result.rule_id)
    return result.to_dict()


@router.get("/status")
def routing_status():
    """Return counters + totals for the rules engine."""
    rules = _store.list()
    enabled = [r for r in rules if r.enabled]
    with _eval_counter_lock:
        counters = dict(_eval_counter)
    return {
        "rules_total": len(rules),
        "rules_enabled": len(enabled),
        "recent_evaluations": counters,
    }


# Exported so tests can reset counters between runs.
def reset_counters() -> None:
    with _eval_counter_lock:
        _eval_counter["total"] = 0
        _eval_counter["matched"] = 0


__all__ = [
    "router",
    "reset_counters",
    "matchers_to_list",
]
