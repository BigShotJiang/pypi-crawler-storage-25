"""API router for AI Firewall — multi-layered WAF for LLMs."""
from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel

from ...security.firewall import AIFirewall, inject_canary, detect_canary, detect_any_canary

router = APIRouter(prefix="/api/firewall", tags=["firewall"])

_firewall: Optional[AIFirewall] = None


def _get_firewall() -> AIFirewall:
    global _firewall
    if _firewall is None:
        _firewall = AIFirewall()
    return _firewall


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class FirewallScanRequest(BaseModel):
    text: str
    threshold: Optional[float] = None


class FirewallScanMessages(BaseModel):
    messages: List[Dict[str, Any]]
    threshold: Optional[float] = None


class CanaryInjectRequest(BaseModel):
    system_prompt: str
    request_id: str


class CanaryDetectRequest(BaseModel):
    output_text: str
    request_id: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("/scan")
def scan_text(body: FirewallScanRequest):
    """Scan a single text input through all firewall layers."""
    fw = _get_firewall()
    if body.threshold is not None:
        fw = AIFirewall(threshold=body.threshold)
    verdict = fw.scan(body.text)
    return verdict.to_dict()


@router.post("/scan/messages")
def scan_messages(body: FirewallScanMessages):
    """Scan a list of chat messages through all firewall layers."""
    fw = _get_firewall()
    if body.threshold is not None:
        fw = AIFirewall(threshold=body.threshold)
    verdict = fw.scan_messages(body.messages)
    return verdict.to_dict()


@router.post("/canary/inject")
def canary_inject(body: CanaryInjectRequest):
    """Inject an invisible canary token into a system prompt."""
    result = inject_canary(body.system_prompt, body.request_id)
    return {
        "system_prompt_with_canary": result,
        "canary_injected": True,
        "original_length": len(body.system_prompt),
        "new_length": len(result),
        "invisible_chars_added": len(result) - len(body.system_prompt),
    }


@router.post("/canary/detect")
def canary_detect(body: CanaryDetectRequest):
    """Check if model output contains a leaked canary token."""
    leak = detect_canary(body.output_text, body.request_id)
    has_any = detect_any_canary(body.output_text)
    return {
        "canary_leaked": leak is not None,
        "has_any_canary": has_any,
        "request_id": leak.request_id if leak else None,
        "canary_token": leak.canary_token if leak else None,
    }
