"""API router for Prompt Registry — version control, deploy, rollback, diff."""
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, model_validator

from ...prompts.registry import PromptRegistry
from ...prompts.models import PromptStatus

router = APIRouter(prefix="/api/prompts", tags=["prompts"])

# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_registry: Optional[PromptRegistry] = None


def _get_registry() -> PromptRegistry:
    global _registry
    if _registry is None:
        _registry = PromptRegistry()
    return _registry


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class PromptRegister(BaseModel):
    prompt_id: Optional[str] = None
    name: Optional[str] = None  # alias for prompt_id
    version: str = "v1.0"
    template: str
    model: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    created_by: Optional[str] = None
    status: str = "draft"

    @model_validator(mode="after")
    def resolve_prompt_id(self) -> "PromptRegister":
        if not self.prompt_id and self.name:
            self.prompt_id = self.name
        if not self.prompt_id:
            raise ValueError("prompt_id (or name) is required")
        return self


class PromptDeploy(BaseModel):
    version: str
    traffic: float = 1.0
    rollback_policy: Optional[Dict[str, Any]] = None
    allow_unapproved: bool = False


class PromptApprove(BaseModel):
    approved_by: str


class RollbackPolicySet(BaseModel):
    metric: str
    threshold: float
    window_minutes: int = 30


class PromptResolve(BaseModel):
    context_key: Optional[str] = None


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("")
def register_prompt(body: PromptRegister):
    """Register a new prompt version."""
    try:
        status = PromptStatus(body.status)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid status: {body.status!r}")
    try:
        pv = _get_registry().register(
            prompt_id=body.prompt_id,
            version=body.version,
            template=body.template,
            model=body.model,
            metadata=body.metadata,
            created_by=body.created_by,
            status=status,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return pv.to_dict()


@router.get("")
def list_prompts():
    """List all registered prompts."""
    return _get_registry().list_prompts()


@router.get("/{prompt_id}/versions")
def list_versions(prompt_id: str, status: Optional[str] = None):
    """List all versions of a prompt."""
    filter_status = None
    if status:
        try:
            filter_status = PromptStatus(status)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid status: {status!r}")
    versions = _get_registry().list_versions(prompt_id, status=filter_status)
    if not versions:
        raise HTTPException(status_code=404, detail=f"Prompt '{prompt_id}' not found")
    return [v.to_dict() for v in versions]


@router.get("/{prompt_id}/versions/{version}")
def get_version(prompt_id: str, version: str):
    """Get a specific prompt version."""
    pv = _get_registry().get_version(prompt_id, version)
    if pv is None:
        raise HTTPException(
            status_code=404,
            detail=f"Version '{version}' not found for prompt '{prompt_id}'",
        )
    return pv.to_dict()


@router.get("/{prompt_id}/history/{version}")
def get_version_history(prompt_id: str, version: str):
    """Get the version history chain from a version back to root."""
    chain = _get_registry().get_version_history(prompt_id, version)
    if not chain:
        raise HTTPException(status_code=404, detail="Version not found")
    return [v.to_dict() for v in chain]


@router.get("/{prompt_id}/diff")
def diff_versions(prompt_id: str, old: str, new: str):
    """Get a unified diff between two prompt versions."""
    try:
        result = _get_registry().diff(prompt_id, old, new)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return result.to_dict()


@router.post("/{prompt_id}/review/{version}")
def submit_for_review(prompt_id: str, version: str):
    """Submit a draft prompt for review."""
    try:
        pv = _get_registry().submit_for_review(prompt_id, version)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return pv.to_dict()


@router.post("/{prompt_id}/approve/{version}")
def approve_version(prompt_id: str, version: str, body: PromptApprove):
    """Approve a prompt version for deployment."""
    try:
        pv = _get_registry().approve(prompt_id, version, body.approved_by)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return pv.to_dict()


@router.post("/{prompt_id}/deploy")
def deploy_prompt(prompt_id: str, body: PromptDeploy):
    """Deploy a prompt version with optional canary traffic split."""
    try:
        dep = _get_registry().deploy(
            prompt_id=prompt_id,
            version=body.version,
            traffic=body.traffic,
            rollback_policy=body.rollback_policy,
            allow_unapproved=body.allow_unapproved,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return dep.to_dict()


@router.post("/{prompt_id}/promote")
def promote_prompt(prompt_id: str):
    """Promote a canary deployment to 100% traffic."""
    try:
        dep = _get_registry().promote(prompt_id)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return dep.to_dict()


@router.post("/{prompt_id}/rollback")
def rollback_prompt(prompt_id: str):
    """Roll back to the previous prompt version."""
    try:
        dep = _get_registry().rollback(prompt_id)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return dep.to_dict()


@router.post("/{prompt_id}/rollback-policy")
def set_rollback_policy(prompt_id: str, body: RollbackPolicySet):
    """Set an auto-rollback policy on the active deployment."""
    try:
        dep = _get_registry().set_rollback_policy(
            prompt_id=prompt_id,
            metric=body.metric,
            threshold=body.threshold,
            window_minutes=body.window_minutes,
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return dep.to_dict()


@router.post("/{prompt_id}/resolve")
def resolve_prompt(prompt_id: str, body: PromptResolve):
    """Resolve which prompt version to serve (canary-aware)."""
    pv = _get_registry().resolve(prompt_id, context_key=body.context_key)
    if pv is None:
        raise HTTPException(
            status_code=404,
            detail=f"No active deployment for prompt '{prompt_id}'",
        )
    return pv.to_dict()


@router.get("/{prompt_id}/deployment")
def get_deployment(prompt_id: str):
    """Get the active deployment for a prompt."""
    dep = _get_registry().get_deployment(prompt_id)
    if dep is None:
        raise HTTPException(
            status_code=404,
            detail=f"No active deployment for prompt '{prompt_id}'",
        )
    return dep.to_dict()


@router.post("/{prompt_id}/archive/{version}")
def archive_version(prompt_id: str, version: str):
    """Archive a prompt version."""
    try:
        pv = _get_registry().archive(prompt_id, version)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return pv.to_dict()
