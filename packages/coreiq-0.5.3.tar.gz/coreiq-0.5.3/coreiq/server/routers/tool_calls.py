from fastapi import APIRouter, Query
from typing import Optional
from ...store.backends.base import StorageBackend
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/tool_calls", tags=["tool_calls"])


def _conn() -> StorageBackend:
    return get_shared_connection()


@router.get("/top")
def top_tool_calls(limit: int = 5):
    conn = _conn()
    rows = conn.execute(
        "SELECT tool_name as name, COUNT(*) as count FROM tool_calls GROUP BY tool_name ORDER BY count DESC LIMIT ?",
        (limit,)
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/stats")
def tool_call_stats():
    conn = _conn()
    row = conn.execute(
        "SELECT COUNT(*) as total, SUM(valid) as valid_n FROM tool_calls"
    ).fetchone()
    top_error_row = conn.execute(
        "SELECT error, COUNT(*) as n FROM tool_calls WHERE error IS NOT NULL GROUP BY error ORDER BY n DESC LIMIT 1"
    ).fetchone()
    by_tool = conn.execute(
        "SELECT tool_name as name, COUNT(*) as total, SUM(valid) as valid_n FROM tool_calls GROUP BY tool_name ORDER BY total DESC"
    ).fetchall()
    total = int(row["total"] or 0) if row else 0
    valid_n = int(row["valid_n"] or 0) if row else 0
    return {
        "total": total,
        "valid": valid_n,
        "invalid": total - valid_n,
        "top_error": top_error_row["error"] if top_error_row else None,
        "by_tool": [
            {
                "name": r["name"],
                "total": int(r["total"] or 0),
                "valid": int(r["valid_n"] or 0),
                "invalid": int(r["total"] or 0) - int(r["valid_n"] or 0),
            }
            for r in by_tool
        ],
    }


@router.get("")
def list_tool_calls(
    limit: int = Query(50, le=500),
    offset: int = 0,
    tool_name: Optional[str] = None,
    valid: Optional[int] = None,
):
    conn = _conn()
    where, params = [], []
    if tool_name:
        where.append("tool_name = ?")
        params.append(tool_name)
    if valid is not None:
        where.append("valid = ?")
        params.append(valid)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT * FROM tool_calls {clause} ORDER BY ts DESC LIMIT ? OFFSET ?",
        params + [limit, offset]
    ).fetchall()
    return [dict(r) for r in rows]
