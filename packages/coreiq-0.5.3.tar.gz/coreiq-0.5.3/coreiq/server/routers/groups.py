"""REST router for team (group) credit pools (B4).

Endpoints under ``/api/groups``:

- ``POST /{group_id}/budget`` — create / update a monthly budget
- ``GET  /{group_id}/budget`` — current status (consumed + remaining)
- ``POST /{group_id}/budget/consume`` — record cost + token consumption
- ``GET  /{group_id}/budget/history`` — last 12 months (empty in the MVP)
- ``POST /{group_id}/budget/reset`` — manual period reset
"""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ...performance.group_budget import (
    GroupBudgetConfig,
    GroupBudgetExceeded,
    get_group_budget_tracker,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/groups", tags=["groups"])


class GrantBudgetRequest(BaseModel):
    monthly_budget_usd: float = Field(0.0, ge=0)
    monthly_budget_tokens: int = Field(0, ge=0)
    tenant_id: str = ""


class ConsumeRequest(BaseModel):
    cost_usd: float = Field(0.0, ge=0)
    tokens: int = Field(0, ge=0)


@router.post("/{group_id}/budget")
def grant_budget(group_id: str, req: GrantBudgetRequest):
    tracker = get_group_budget_tracker()
    stats = tracker.grant(
        group_id=group_id,
        config=GroupBudgetConfig(
            monthly_budget_usd=req.monthly_budget_usd,
            monthly_budget_tokens=req.monthly_budget_tokens,
        ),
        tenant_id=req.tenant_id,
    )
    return stats.to_dict()


@router.get("/{group_id}/budget")
def get_budget(group_id: str):
    tracker = get_group_budget_tracker()
    stats = tracker.stats(group_id)
    return stats.to_dict()


@router.post("/{group_id}/budget/consume")
def consume_budget(group_id: str, req: ConsumeRequest):
    tracker = get_group_budget_tracker()
    try:
        stats = tracker.consume(
            group_id=group_id,
            cost_usd=req.cost_usd,
            tokens=req.tokens,
        )
    except GroupBudgetExceeded as exc:
        raise HTTPException(
            status_code=402,
            detail={
                "error": "group_budget_exceeded",
                "dimension": exc.dimension,
                "used": exc.used,
                "limit": exc.limit,
                "group_id": exc.group_id,
            },
        ) from exc
    return stats.to_dict()


@router.get("/{group_id}/budget/history")
def budget_history(group_id: str, months: Optional[int] = 12):
    """Return the last N months of budget history.

    MVP returns an empty list — real history persistence lands in a
    follow-up commit alongside the scheduled period-reset job.
    """
    return {"group_id": group_id, "months": months, "history": []}


@router.post("/{group_id}/budget/reset")
def reset_budget(group_id: str):
    tracker = get_group_budget_tracker()
    stats = tracker.reset_period(group_id)
    return stats.to_dict()


__all__ = ["router"]
