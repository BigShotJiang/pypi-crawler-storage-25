"""Egress/SSRF protection endpoints."""
from __future__ import annotations
import logging
from fastapi import APIRouter, Query
from ...security.egress import EgressChecker

logger = logging.getLogger(__name__)
router = APIRouter()

_checker = EgressChecker()

@router.get("/api/egress/check")
def check_egress(url: str = Query(..., description="URL to validate")):
    """Check if an outbound URL is safe (SSRF protection)."""
    decision = _checker.check(url)
    return {"allowed": decision.allowed, "reason": decision.reason, "url": decision.url}
