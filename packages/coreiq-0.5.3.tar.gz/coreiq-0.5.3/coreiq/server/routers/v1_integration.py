"""Gateway integration endpoints for cyberpod-gateway migration.

These endpoints provide the API surface that the gateway will call after
migration, replacing direct database access with API calls.

Routes use /api/v1/ prefix to distinguish from existing /api/ endpoints.
"""
from typing import Optional

from fastapi import APIRouter, Header, HTTPException, Query

router = APIRouter(prefix="/api/v1", tags=["v1-integration"])


@router.get("/providers")
async def list_providers(
    x_tenant_id: Optional[str] = Header(None),
    limit: int = Query(50, description="Maximum number of providers to return"),
    offset: int = Query(0, description="Number of providers to skip"),
) -> dict:
    """List LLM providers for gateway routing.

    Gateway calls this to discover available providers and their configurations.
    Replaces: LLMProvider.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()
        rows = conn.fetchall(
            """SELECT id, tenant_id, provider, api_key_encrypted, base_url, max_rpm, max_tpm,
                      enabled, config_json, latency_p50_ms, latency_p99_ms, requests_today,
                      tokens_today, cost_mtd, error_rate, models_json, priority, created_at
               FROM provider_configs
               WHERE tenant_id = ?
               ORDER BY priority ASC, created_at DESC
               LIMIT ? OFFSET ?""",
            (tenant_id, limit, offset),
        )

        return {
            "providers": [
                {
                    "id": row["id"],
                    "tenant_id": row["tenant_id"],
                    "provider": row["provider"],
                    "base_url": row["base_url"],
                    "max_rpm": row["max_rpm"],
                    "max_tpm": row["max_tpm"],
                    "enabled": row["enabled"] == 1,
                    "config": row.get("config_json"),
                    # Gateway fields
                    "latency_p50_ms": row.get("latency_p50_ms"),
                    "latency_p99_ms": row.get("latency_p99_ms"),
                    "requests_today": row.get("requests_today", 0),
                    "tokens_today": row.get("tokens_today", 0),
                    "cost_mtd": row.get("cost_mtd", 0.0),
                    "error_rate": row.get("error_rate", 0.0),
                    "models": row.get("models_json", []),
                    "priority": row.get("priority", 0),
                    "created_at": row["created_at"],
                }
                for row in rows
            ],
            "total": len(rows),
            "limit": limit,
            "offset": offset,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list providers: {exc}")


@router.get("/providers/{provider_id}/config")
async def get_provider_config(
    provider_id: str,
    x_tenant_id: Optional[str] = Header(None),
) -> dict:
    """Get detailed configuration for a specific provider.

    Gateway calls this to get provider credentials and configuration.
    Replaces: PortalLLMConfig.findFirst() in gateway database.
    """
    from ...store.db import get_shared_connection
    import json

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()
        row = conn.fetchone(
            """SELECT id, tenant_id, provider, api_key_encrypted, base_url, max_rpm, max_tpm,
                      enabled, config_json, latency_p50_ms, latency_p99_ms, requests_today,
                      tokens_today, cost_mtd, error_rate, models_json, priority
               FROM provider_configs
               WHERE id = ? AND tenant_id = ?""",
            (provider_id, tenant_id),
        )

        if not row:
            raise HTTPException(status_code=404, detail="Provider configuration not found")

        return {
            "id": row["id"],
            "tenant_id": row["tenant_id"],
            "provider": row["provider"],
            "api_key_encrypted": row["api_key_encrypted"],
            "base_url": row["base_url"],
            "max_rpm": row["max_rpm"],
            "max_tpm": row["max_tpm"],
            "enabled": row["enabled"] == 1,
            "config": json.loads(row.get("config_json", "{}")),
            # Gateway fields
            "latency_p50_ms": row.get("latency_p50_ms"),
            "latency_p99_ms": row.get("latency_p99_ms"),
            "requests_today": row.get("requests_today", 0),
            "tokens_today": row.get("tokens_today", 0),
            "cost_mtd": row.get("cost_mtd", 0.0),
            "error_rate": row.get("error_rate", 0.0),
            "models": json.loads(row.get("models_json", "[]")),
            "priority": row.get("priority", 0),
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to get provider config: {exc}")


@router.get("/providers/capacity")
async def list_provider_capacity(
    x_tenant_id: Optional[str] = Header(None),
    provider: Optional[str] = Query(None, description="Filter by provider name"),
    status: Optional[str] = Query(None, description="Filter by status (healthy, degraded, down)"),
) -> dict:
    """List provider capacity information for gateway routing.

    Gateway calls this to make routing decisions based on current load.
    Replaces: ProviderCapacity.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()

        # Build query dynamically based on filters
        where_clauses = ["tenant_id = ?"]
        params = [tenant_id]

        if provider:
            where_clauses.append("provider = ?")
            params.append(provider)

        if status:
            where_clauses.append("status = ?")
            params.append(status)

        where_sql = " AND ".join(where_clauses)

        rows = conn.fetchall(
            f"""SELECT id, tenant_id, provider, name, type, capacity_percent,
                      requests_per_min, avg_latency_ms, status, region, failover_order,
                      updated_at, created_at
               FROM provider_capacity
               WHERE {where_sql}
               ORDER BY failover_order ASC, provider ASC""",
            tuple(params),
        )

        return {
            "capacities": [
                {
                    "id": row["id"],
                    "tenant_id": row["tenant_id"],
                    "provider": row["provider"],
                    "name": row["name"],
                    "type": row["type"],
                    "capacity_percent": row["capacity_percent"],
                    "requests_per_min": row["requests_per_min"],
                    "avg_latency_ms": row["avg_latency_ms"],
                    "status": row["status"],
                    "region": row.get("region"),
                    "failover_order": row["failover_order"],
                    "updated_at": row["updated_at"],
                    "created_at": row["created_at"],
                }
                for row in rows
            ],
            "total": len(rows),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list provider capacity: {exc}")


@router.get("/routing/rules")
async def list_routing_rules(
    x_tenant_id: Optional[str] = Header(None),
    enabled_only: bool = Query(False, description="Only return enabled rules"),
) -> dict:
    """List routing rules for content-aware request routing.

    Gateway calls this to get routing configuration.
    Replaces: RoutingRule.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection
    import json

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()

        where_clause = "tenant_id = ?"
        params = [tenant_id]

        if enabled_only:
            where_clause += " AND enabled = 1"
            params.append(1)

        rows = conn.fetchall(
            f"""SELECT id, tenant_id, name, priority, matchers_json, action,
                      target_model_prefix, target_deployment_id, enabled, hit_count,
                      created_at, updated_at
               FROM routing_rules
               WHERE {where_clause}
               ORDER BY priority ASC, created_at DESC""",
            tuple(params),
        )

        return {
            "rules": [
                {
                    "id": row["id"],
                    "tenant_id": row["tenant_id"],
                    "name": row["name"],
                    "priority": row["priority"],
                    "matchers": json.loads(row.get("matchers_json", "[]")),
                    "action": row["action"],
                    "target_model_prefix": row.get("target_model_prefix"),
                    "target_deployment_id": row.get("target_deployment_id"),
                    "enabled": row["enabled"] == 1,
                    "hit_count": row.get("hit_count", 0),
                    "created_at": row["created_at"],
                    "updated_at": row.get("updated_at"),
                }
                for row in rows
            ],
            "total": len(rows),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list routing rules: {exc}")


@router.get("/observability/metrics")
async def get_observability_metrics(
    x_tenant_id: Optional[str] = Header(None),
    from_ts: Optional[str] = Query(None, description="ISO timestamp start"),
    to_ts: Optional[str] = Query(None, description="ISO timestamp end"),
    model: Optional[str] = Query(None, description="Filter by model"),
) -> dict:
    """Get observability metrics for gateway monitoring.

    Gateway calls this to get performance metrics and analytics.
    Replaces: PerformanceMetric.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()

        # Build query dynamically
        where_clauses = ["tenant_id = ?"]
        params = [tenant_id]

        if model:
            where_clauses.append("model = ?")
            params.append(model)
        if from_ts:
            where_clauses.append("ts >= ?")
            params.append(from_ts)
        if to_ts:
            where_clauses.append("ts <= ?")
            params.append(to_ts)

        where_sql = " AND ".join(where_clauses)

        # Get traces for metrics
        rows = conn.fetchall(
            f"""SELECT model, provider, COUNT(*) as request_count,
                      AVG(latency_ms) as avg_latency,
                      SUM(input_tok + output_tok) as total_tokens,
                      SUM(cost_usd) as total_cost,
                      SUM(CASE WHEN cache_hit = 1 THEN 1 ELSE 0 END) as cache_hits
               FROM traces
               WHERE {where_sql}
               GROUP BY model, provider
               ORDER BY request_count DESC""",
            tuple(params),
        )

        return {
            "metrics": [
                {
                    "model": row["model"],
                    "provider": row["provider"],
                    "request_count": row["request_count"],
                    "avg_latency_ms": row["avg_latency"] or 0,
                    "total_tokens": row["total_tokens"] or 0,
                    "total_cost": row["total_cost"] or 0.0,
                    "cache_hit_rate": (row["cache_hits"] or 0) / row["request_count"] if row["request_count"] else 0,
                    "finish_reasons": {},  # Would need separate query grouped by finish_reason
                }
                for row in rows
            ],
            "from_ts": from_ts,
            "to_ts": to_ts,
            "tenant_id": tenant_id,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to get metrics: {exc}")


@router.get("/security/violations")
async def list_security_violations(
    x_tenant_id: Optional[str] = Header(None),
    category: Optional[str] = Query(None, description="Filter by category"),
    severity: Optional[str] = Query(None, description="Filter by severity"),
    limit: int = Query(50, description="Maximum violations to return"),
    offset: int = Query(0, description="Number of violations to skip"),
) -> dict:
    """List security violations for gateway monitoring.

    Gateway calls this to track security events and policy violations.
    Replaces: SecurityViolation.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()

        # Build query dynamically
        where_clauses = ["tenant_id = ?"]
        params = [tenant_id]

        if category:
            where_clauses.append("category = ?")
            params.append(category)
        if severity:
            where_clauses.append("severity = ?")
            params.append(severity)

        where_sql = " AND ".join(where_clauses)

        rows = conn.fetchall(
            f"""SELECT id, tenant_id, category, severity, trace_id, message, details_json,
                      action_taken, ts
               FROM security_violations
               WHERE {where_sql}
               ORDER BY ts DESC
               LIMIT ? OFFSET ?""",
            tuple(params + [limit, offset]),
        )

        return {
            "violations": [
                {
                    "id": row["id"],
                    "tenant_id": row["tenant_id"],
                    "category": row["category"],
                    "severity": row["severity"],
                    "trace_id": row.get("trace_id"),
                    "message": row["message"],
                    "details": row.get("details_json"),
                    "action_taken": row["action_taken"],
                    "timestamp": row["ts"],
                }
                for row in rows
            ],
            "total": len(rows),
            "limit": limit,
            "offset": offset,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list violations: {exc}")


@router.get("/governance/compliance")
async def list_governance_compliance(
    x_tenant_id: Optional[str] = Header(None),
    framework: Optional[str] = Query(None, description="Filter by compliance framework"),
    status: Optional[str] = Query(None, description="Filter by status"),
) -> dict:
    """List compliance check results for governance monitoring.

    Gateway calls this to get compliance framework status.
    Replaces: ComplianceCheck.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()

        # Build query dynamically
        where_clauses = ["tenant_id = ?"]
        params = [tenant_id]

        if framework:
            where_clauses.append("control_id LIKE ?")
            params.append(f"%{framework}%")
        if status:
            where_clauses.append("status = ?")
            params.append(status)

        where_sql = " AND ".join(where_clauses)

        rows = conn.fetchall(
            f"""SELECT tenant_id, control_id, status, evidence_json, notes, computed_in_ms
               FROM compliance_check_results
               WHERE {where_sql}
               ORDER BY computed_in_ms DESC""",
            tuple(params),
        )

        return {
            "compliance_results": [
                {
                    "tenant_id": row["tenant_id"],
                    "control_id": row["control_id"],
                    "status": row["status"],
                    "evidence": row.get("evidence_json"),
                    "notes": row["notes"],
                    "computed_in_ms": row["computed_in_ms"],
                    "checked_at": None,  # Column exists but query fails in ClickHouse
                }
                for row in rows
            ],
            "total": len(rows),
        }

        return {
            "compliance_results": [
                {
                    "tenant_id": row["tenant_id"],
                    "control_id": row["control_id"],
                    "status": row["status"],
                    "evidence": row.get("evidence_json"),
                    "notes": row["notes"],
                    "computed_in_ms": row["computed_in_ms"],
                    "checked_at": row["checked_at"],
                }
                for row in rows
            ],
            "total": len(rows),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list compliance results: {exc}")


@router.get("/governance/model-risk")
async def list_model_risk(
    x_tenant_id: Optional[str] = Header(None),
    provider: Optional[str] = Query(None, description="Filter by provider"),
    risk_tier: Optional[str] = Query(None, description="Filter by risk tier"),
    limit: int = Query(50, description="Maximum entries to return"),
    offset: int = Query(0, description="Number of entries to skip"),
) -> dict:
    """List model risk register entries for gateway governance.

    Gateway calls this to get model risk assessments and approval status.
    Replaces: PortalModelPolicy.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection

    # TODO: resolve tenant_id from x-tenant-id header

    try:
        conn = get_shared_connection()

        # Build query dynamically - note: model_risk_register doesn't have tenant_id
        where_clauses = []
        params = []

        if provider:
            where_clauses.append("provider = ?")
            params.append(provider)
        if risk_tier:
            where_clauses.append("risk_tier = ?")
            params.append(risk_tier)

        where_sql = "1=1" if not where_clauses else " AND ".join(where_clauses)

        rows = conn.fetchall(
            f"""SELECT id, model_id, provider, risk_tier, use_case, approved_by,
                      approved_at, notes, metadata_json, created_at
               FROM model_risk_register
               WHERE {where_sql}
               ORDER BY created_at DESC
               LIMIT ? OFFSET ?""",
            tuple(params + [limit, offset]),
        )

        return {
            "model_risks": [
                {
                    "id": row["id"],
                    "model_id": row["model_id"],
                    "provider": row["provider"],
                    "risk_tier": row["risk_tier"],
                    "use_case": row["use_case"],
                    "approved_by": row.get("approved_by"),
                    "approved_at": row.get("approved_at"),
                    "notes": row["notes"],
                    "metadata": row.get("metadata_json"),
                    "created_at": row["created_at"],
                }
                for row in rows
            ],
            "total": len(rows),
            "limit": limit,
            "offset": offset,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list model risks: {exc}")


@router.get("/security/guardrails")
async def list_guardrails(
    x_tenant_id: Optional[str] = Header(None),
    group_name: Optional[str] = Query(None, description="Filter by group name"),
    rule_name: Optional[str] = Query(None, description="Filter by rule name"),
) -> dict:
    """List guardrail rules for content safety enforcement.

    Gateway calls this to get per-group content safety policies.
    Replaces: PortalGuardrailRule.findMany() in gateway database.
    """
    from ...store.db import get_shared_connection

    tenant_id = "default"  # TODO: resolve from x_tenant_id header

    try:
        conn = get_shared_connection()

        # Build query dynamically
        where_clauses = ["tenant_id = ?"]
        params = [tenant_id]

        if group_name:
            where_clauses.append("group_name = ?")
            params.append(group_name)
        if rule_name:
            where_clauses.append("rule_name = ?")
            params.append(rule_name)

        where_sql = " AND ".join(where_clauses)

        rows = conn.fetchall(
            f"""SELECT id, group_name, tenant_id, rule_name, pattern, description,
                      created_at
               FROM group_guardrules
               WHERE {where_sql}
               ORDER BY group_name, rule_name""",
            tuple(params),
        )

        return {
            "guardrules": [
                {
                    "id": row["id"],
                    "group_name": row["group_name"],
                    "tenant_id": row["tenant_id"],
                    "rule_name": row["rule_name"],
                    "pattern": row["pattern"],
                    "description": row["description"],
                    "created_at": row["created_at"],
                }
                for row in rows
            ],
            "total": len(rows),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list guardrails: {exc}")
