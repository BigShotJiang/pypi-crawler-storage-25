"""FastAPI router for enterprise identity / key provisioning.

Endpoints:
    POST /auth/provision        — exchange IdP identity for a CoreIQ virtual key
    POST /api/group-policies    — create/update a group policy (master key required)
    GET  /api/group-policies    — list group policies (master key required)
    DELETE /api/group-policies/{id} — delete a group policy (master key required)
    POST /api/group-guardrules  — create/update a content guardrule for a group
    GET  /api/group-guardrules  — list content guardrules (optional ?group_name filter)
    DELETE /api/group-guardrules/{id} — delete a content guardrule

``POST /auth/provision`` is the primary enterprise endpoint.  It accepts an
IdP token (OIDC JWT) or LDAP credentials and returns a long-lived CoreIQ
virtual key that the caller stores permanently.  After provisioning, the
IdP is never contacted again at runtime.
"""
from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Literal, Mapping, Optional

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field

from ...config import get_identity_config
from ...proxy.keys import KeyManager
from ...store.db import get_shared_connection
from ...identity.models import IdentityConfig

logger = logging.getLogger(__name__)

router = APIRouter(tags=["identity"])

_key_manager: KeyManager | None = None


def _get_key_manager() -> KeyManager:
    global _key_manager
    if _key_manager is None:
        _key_manager = KeyManager()
    return _key_manager


def _get_identity_config() -> IdentityConfig:
    raw = get_identity_config()
    return IdentityConfig.from_config_dict(raw)


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class ProvisionRequestBody(BaseModel):
    """Body for ``POST /auth/provision``."""

    idp: Literal["azure", "google", "okta", "ldap"] = Field(
        description="Identity provider type."
    )
    # OIDC providers
    token: Optional[str] = Field(
        default=None,
        description="IdP-issued JWT (access token or id token). Required for azure/google/okta.",
    )
    # LDAP
    username: Optional[str] = Field(
        default=None,
        description="Service account username. Required for ldap.",
    )
    password: Optional[str] = Field(
        default=None,
        description="Service account password. Required for ldap.",
    )
    # Optional overrides
    tenant_id: str = Field(default="default", description="Tenant scope for the generated key.")
    name: str = Field(default="", description="Human-readable label for the key.")
    models: Optional[list[str]] = Field(
        default=None,
        description="Allowed models. None = use group policy.",
    )
    max_budget_usd: Optional[float] = Field(
        default=None,
        description="Budget in USD. None = use group policy.",
    )
    expires_in_days: Optional[int] = Field(
        default=None,
        description="Key expiry in days from now. None = never expires.",
    )


class ProvisionResponseBody(BaseModel):
    """Response for ``POST /auth/provision``.

    The ``key`` is shown **once** and never retrievable again.
    Store it in your secret manager immediately.
    """

    key: str = Field(description="sk-coreiq-xxx — the virtual key. Store immediately.")
    key_id: str = Field(description="UUID for key management (revoke, view usage).")
    tenant_id: str
    idp: str
    sub: str = Field(description="IdP subject identifier (for audit).")
    email: str
    groups: list[str]
    models_allowed: Optional[list[str]] = None
    budget_usd: Optional[float] = None
    expires_at: Optional[str] = None


class GroupPolicyRequest(BaseModel):
    group_name: str = Field(description="IdP group name to match (exact, case-sensitive).")
    tenant_id: str = Field(default="default")
    # Model access control
    allowed_models: Optional[list[str]] = Field(
        default=None,
        description="Model allowlist. None = all models permitted.",
    )
    denied_models: Optional[list[str]] = Field(
        default=None,
        description="Model denylist. Applied before allowlist. None = no denials.",
    )
    allowed_providers: Optional[list[str]] = Field(
        default=None,
        description="Provider allowlist (e.g. ['openai', 'anthropic']). None = all providers.",
    )
    # Rate & budget limits
    max_budget_usd: Optional[float] = None
    tpm_limit: Optional[int] = None
    rpm_limit: Optional[int] = None
    # Token guardrails
    max_input_tokens: Optional[int] = Field(
        default=None,
        description="Maximum input token count per request. None = unlimited.",
    )
    max_output_tokens: Optional[int] = Field(
        default=None,
        description="Maximum output token count per response. None = unlimited.",
    )
    # RBAC & residency
    rbac_role: str = Field(
        default="operator",
        description="Dashboard/API RBAC role for users in this group: viewer | operator | admin.",
    )
    data_region: str = Field(
        default="",
        description="Data residency region tag (e.g. 'eu-west-1'). Empty = no restriction.",
    )


class GroupPolicyResponse(BaseModel):
    id: str
    group_name: str
    tenant_id: str
    allowed_models: Optional[list[str]] = None
    denied_models: Optional[list[str]] = None
    allowed_providers: Optional[list[str]] = None
    max_budget_usd: Optional[float] = None
    tpm_limit: Optional[int] = None
    rpm_limit: Optional[int] = None
    max_input_tokens: Optional[int] = None
    max_output_tokens: Optional[int] = None
    rbac_role: str = "operator"
    data_region: str = ""
    created_at: str
    updated_at: str = ""
    updated_by: str = ""


class GroupGuardruleRequest(BaseModel):
    group_name: str = Field(description="IdP group name this rule applies to.")
    tenant_id: str = Field(default="default")
    rule_name: str = Field(description="Unique rule name within the group (slug-style).")
    pattern: str = Field(
        max_length=256,
        description="Python regex pattern matched against LLM output. Case-insensitive.",
    )
    description: str = Field(default="", description="Human-readable description of the rule.")
    action: Literal["block", "warn", "redact"] = Field(
        default="block",
        description=(
            "Action on match: 'block' raises 403, 'warn' logs + continues, "
            "'redact' is reserved for future use."
        ),
    )


class GroupGuardruleResponse(BaseModel):
    id: str
    group_name: str
    tenant_id: str
    rule_name: str
    pattern: str
    description: str = ""
    action: str = "block"
    created_at: str = ""


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

_ROLE_ORDER = {"admin": 0, "operator": 1, "auditor": 2, "viewer": 3}


def _resolve_rbac_role(groups: list[str], tenant_id: str) -> str:
    """Return the most-permissive RBAC role across the user's group policies."""
    if not groups:
        return "viewer"
    try:
        conn = get_shared_connection()
        placeholders = ",".join("?" * len(groups))
        rows = conn.execute(
            f"SELECT rbac_role FROM group_policies WHERE group_name IN ({placeholders})"
            " AND tenant_id=?",
            (*groups, tenant_id),
        ).fetchall()
        roles = [r["rbac_role"] for r in rows if r.get("rbac_role")]
        return min(roles, key=lambda r: _ROLE_ORDER.get(r, 99)) if roles else "viewer"
    except Exception:
        return "viewer"


# ---------------------------------------------------------------------------
# Provision endpoint
# ---------------------------------------------------------------------------


@router.post("/auth/provision", response_model=ProvisionResponseBody, status_code=200)
def provision_key(body: ProvisionRequestBody):
    """Exchange an IdP identity for a long-lived CoreIQ virtual key.

    **OIDC flow** (azure / google / okta):
    1. Obtain an access token from your IdP (client_credentials grant or
       user login).
    2. POST this endpoint with ``idp`` and ``token``.
    3. CoreIQ validates the JWT, extracts groups, looks up group policies,
       and generates a ``sk-coreiq-xxx`` key.
    4. Store the returned key — it is shown exactly once.

    **LDAP/AD flow**:
    POST with ``idp=ldap``, ``username``, and ``password``.

    After provisioning, use the key in every subsequent request via
    ``Authorization: Bearer sk-coreiq-xxx``.  The IdP is never contacted again.
    """
    cfg = _get_identity_config()
    if not cfg.enabled:
        raise HTTPException(
            status_code=501,
            detail=(
                "Identity provisioning is not enabled. "
                "Set COREIQ_IDENTITY_ENABLED=true and configure your IdP."
            ),
        )

    # Validate input
    if body.idp in ("azure", "google", "okta"):
        if not body.token:
            raise HTTPException(
                status_code=400,
                detail=f"'token' is required for idp={body.idp!r}",
            )
    elif body.idp == "ldap":
        if not body.username or not body.password:
            raise HTTPException(
                status_code=400,
                detail="'username' and 'password' are required for idp='ldap'",
            )
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported idp: {body.idp!r}")

    # Authenticate with the IdP
    try:
        if body.idp in ("azure", "google", "okta"):
            from ...identity.oidc import validate_oidc_token
            idp_user = validate_oidc_token(body.token or "", body.idp, cfg)
        else:
            from ...identity.ldap_auth import authenticate_ldap
            # Do not pass body.tenant_id — LDAP derives tenant from the directory
            idp_user = authenticate_ldap(
                body.username or "",
                body.password or "",
                cfg,
            )
    except ValueError as exc:
        logger.warning("IdP authentication rejected: %s", exc)
        raise HTTPException(status_code=401, detail="Authentication failed") from exc
    except ImportError as exc:
        logger.error("IdP dependency missing: %s", exc)
        raise HTTPException(status_code=501, detail="IdP provider not available") from exc
    except Exception as exc:
        logger.error("IdP authentication error: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="IdP authentication failed") from exc

    # Provision the virtual key — tenant_id is always taken from the IdP assertion,
    # never from the request body (prevents tenant-escalation attacks).
    try:
        conn = get_shared_connection()
        from ...identity.provisioner import KeyProvisioner
        provisioner = KeyProvisioner(
            _get_key_manager(),
            conn,
            policy_merge=cfg.policy_merge,
        )
        result = provisioner.provision(
            idp_user,
            name=body.name,
            models=body.models,
            max_budget_usd=body.max_budget_usd,
            expires_in_days=body.expires_in_days,
        )
    except Exception as exc:
        logger.error("Key provisioning error: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Key provisioning failed") from exc

    # --- Login tracking (best-effort — never block auth on observability failure) ---
    _role = _resolve_rbac_role(result.groups, result.tenant_id)

    # 1. Tamper-evident audit log → SIEM sinks if configured
    try:
        from ...governance.chained_audit import ChainedAuditLogger
        ChainedAuditLogger().log(
            "user.login",
            principal=result.email,
            outcome="success",
            metadata={
                "sub": result.sub,
                "idp": body.idp,
                "role": _role,
                "groups": result.groups,
                "tenant_id": result.tenant_id,
                "key_id": result.key_id,
            },
        )
    except Exception:
        logger.debug("Audit log skipped (COREIQ_AUDIT_HMAC_KEY not set or sink error)")

    # 2. Update last_login on the user record
    try:
        from ...tenancy.users import UserManager
        UserManager().touch_last_login(email=result.email, tenant_id=result.tenant_id)
    except Exception:
        logger.debug("last_login update skipped — user record may not exist yet")

    # 3. Write event so login appears in /api/events and the dashboard
    try:
        from ...store.writer import get_writer
        get_writer().insert_event(
            message="user.login",
            level="info",
            source=body.idp,
            tenant_id=result.tenant_id,
            metadata={
                "email": result.email,
                "sub": result.sub,
                "role": _role,
                "key_id": result.key_id,
                "groups": result.groups,
            },
        )
    except Exception:
        logger.debug("Event insert skipped on login")

    return ProvisionResponseBody(
        key=result.key,
        key_id=result.key_id,
        tenant_id=result.tenant_id,
        idp=result.idp,
        sub=result.sub,
        email=result.email,
        groups=result.groups,
        models_allowed=result.models_allowed,
        budget_usd=result.budget_usd,
        expires_at=result.expires_at,
    )


# NOTE: Endpoints POST /auth/login and POST /auth/logout were removed
# (Wave 1B P0 security fix). They accepted unauthenticated bodies with
# arbitrary email/tenant_id and wrote to ChainedAuditLogger, allowing any
# unauth caller to poison the tamper-evident audit chain. Successful
# /auth/provision calls already emit user.login audit events with the
# real IdP-validated principal — no replacement is needed.


# ---------------------------------------------------------------------------
# Group policy management (master key required — enforced by auth_middleware)
# ---------------------------------------------------------------------------


def _parse_json_col(row: Mapping[str, Any], col: str) -> Optional[list]:
    if col not in row.keys():
        return None
    v = row[col]
    if not v:
        return None
    try:
        return json.loads(str(v))
    except (json.JSONDecodeError, TypeError):
        return None


def _safe_col(row: Mapping[str, Any], col: str, default: Any = None) -> Any:
    return row[col] if col in row.keys() else default


def _row_to_policy(row: Mapping[str, Any]) -> GroupPolicyResponse:
    return GroupPolicyResponse(
        id=str(row["id"]),
        group_name=str(row["group_name"]),
        tenant_id=str(row["tenant_id"] or "default"),
        allowed_models=_parse_json_col(row, "allowed_models_json"),
        denied_models=_parse_json_col(row, "denied_models_json"),
        allowed_providers=_parse_json_col(row, "allowed_providers_json"),
        max_budget_usd=float(row["max_budget_usd"]) if row["max_budget_usd"] is not None else None,
        tpm_limit=int(row["tpm_limit"]) if row["tpm_limit"] is not None else None,
        rpm_limit=int(row["rpm_limit"]) if row["rpm_limit"] is not None else None,
        max_input_tokens=int(_safe_col(row, "max_input_tokens")) if _safe_col(row, "max_input_tokens") is not None else None,
        max_output_tokens=int(_safe_col(row, "max_output_tokens")) if _safe_col(row, "max_output_tokens") is not None else None,
        rbac_role=str(_safe_col(row, "rbac_role", "operator") or "operator"),
        data_region=str(_safe_col(row, "data_region", "") or ""),
        created_at=str(row["created_at"] or ""),
        updated_at=str(_safe_col(row, "updated_at", "") or ""),
        updated_by=str(_safe_col(row, "updated_by", "") or ""),
    )


@router.post("/api/group-policies", response_model=GroupPolicyResponse, status_code=201)
def create_group_policy(body: GroupPolicyRequest):
    """Create or update a group policy.

    Group policies map IdP group names to CoreIQ key constraints.
    When a user is provisioned, all matching policies are merged.
    At request time, guardrails are re-evaluated live from the current policy —
    changes take effect immediately without re-provisioning.

    **Model access**:
    - `denied_models` — denylist applied first (takes precedence over allowlist)
    - `allowed_models` — allowlist; if set, only listed models are permitted
    - `allowed_providers` — restrict to specific providers (openai, anthropic, etc.)

    **Rate / budget limits**: `max_budget_usd`, `tpm_limit`, `rpm_limit`

    **Token guardrails**: `max_input_tokens`, `max_output_tokens`

    **RBAC**: `rbac_role` — viewer | operator | admin (most permissive across groups wins)
    """
    conn = get_shared_connection()
    policy_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    def _to_json(v):
        return json.dumps(v) if v is not None else None

    try:
        conn.execute(
            """
            INSERT INTO group_policies
              (id, group_name, tenant_id, allowed_models_json, denied_models_json,
               allowed_providers_json, max_budget_usd, tpm_limit, rpm_limit,
               max_input_tokens, max_output_tokens, rbac_role, data_region, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(group_name, tenant_id) DO UPDATE SET
              allowed_models_json    = excluded.allowed_models_json,
              denied_models_json     = excluded.denied_models_json,
              allowed_providers_json = excluded.allowed_providers_json,
              max_budget_usd         = excluded.max_budget_usd,
              tpm_limit              = excluded.tpm_limit,
              rpm_limit              = excluded.rpm_limit,
              max_input_tokens       = excluded.max_input_tokens,
              max_output_tokens      = excluded.max_output_tokens,
              rbac_role              = excluded.rbac_role,
              data_region            = excluded.data_region,
              updated_at             = ?
            """,
            (
                policy_id, body.group_name, body.tenant_id,
                _to_json(body.allowed_models),
                _to_json(body.denied_models),
                _to_json(body.allowed_providers),
                body.max_budget_usd, body.tpm_limit, body.rpm_limit,
                body.max_input_tokens, body.max_output_tokens,
                body.rbac_role, body.data_region, now,
                now,  # updated_at on conflict
            ),
        )
        conn.commit()
    except Exception as exc:
        logger.exception("Unexpected error in create_group_policy")
        raise HTTPException(status_code=500, detail="Internal server error") from exc

    row = conn.execute(
        "SELECT * FROM group_policies WHERE group_name = ? AND tenant_id = ?",
        (body.group_name, body.tenant_id),
    ).fetchone()
    return _row_to_policy(row)


@router.get("/api/group-policies", response_model=list[GroupPolicyResponse])
def list_group_policies(tenant_id: Optional[str] = None):
    """List all group policies, optionally filtered by tenant."""
    conn = get_shared_connection()
    if tenant_id:
        rows = conn.execute(
            "SELECT * FROM group_policies WHERE tenant_id = ? ORDER BY group_name",
            (tenant_id,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM group_policies ORDER BY tenant_id, group_name"
        ).fetchall()
    return [_row_to_policy(row) for row in rows]


@router.delete("/api/group-policies/{policy_id}", status_code=200)
def delete_group_policy(policy_id: str, tenant_id: str):
    """Delete a group policy by ID, scoped to tenant. tenant_id is required."""
    conn = get_shared_connection()
    cursor = conn.execute(
        "DELETE FROM group_policies WHERE id = ? AND tenant_id = ?",
        (policy_id, tenant_id),
    )
    conn.commit()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Group policy not found")
    return {"status": "deleted", "id": policy_id}


# ---------------------------------------------------------------------------
# Group guardrule management (content scanning rules per IdP group)
# ---------------------------------------------------------------------------


def _row_to_guardrule(row: Mapping[str, Any]) -> GroupGuardruleResponse:
    return GroupGuardruleResponse(
        id=str(row["id"]),
        group_name=str(row["group_name"]),
        tenant_id=str(row["tenant_id"] or "default"),
        rule_name=str(row["rule_name"]),
        pattern=str(row["pattern"]),
        description=str(row["description"] or ""),
        action=str(row["action"] or "block"),
        created_at=str(row["created_at"] or ""),
    )


@router.post("/api/group-guardrules", response_model=GroupGuardruleResponse, status_code=201)
def create_group_guardrule(body: GroupGuardruleRequest):
    """Create or update a content guardrule for an IdP group.

    Content guardrules are evaluated against every LLM response for users
    whose virtual key belongs to the specified group.  They complement
    group policies (which control *access*) by controlling *content*.

    **Actions**:
    - `block` — raise 403 and discard the response
    - `warn`  — log a warning but return the response
    - `redact` — reserved for future pattern-replacement support

    **Pattern** is a Python regex (case-insensitive). Example:
    ```
    (?:account.number|routing.number|IBAN|swift.code)
    ```

    Rules take effect immediately — no re-provisioning required.
    """
    # Validate regex pattern for correctness and ReDoS safety before storing
    try:
        from ...governance.guardrails import validate_guardrule_pattern
        validate_guardrule_pattern(body.pattern)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    conn = get_shared_connection()
    rule_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()

    try:
        conn.execute(
            """
            INSERT INTO group_guardrules
              (id, group_name, tenant_id, rule_name, pattern, description, action, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(group_name, tenant_id, rule_name) DO UPDATE SET
              pattern     = excluded.pattern,
              description = excluded.description,
              action      = excluded.action
            """,
            (
                rule_id, body.group_name, body.tenant_id,
                body.rule_name, body.pattern, body.description, body.action, now,
            ),
        )
        conn.commit()
    except Exception as exc:
        logger.exception("Unexpected error in create_group_guardrule")
        raise HTTPException(status_code=500, detail="Internal server error") from exc

    row = conn.execute(
        "SELECT * FROM group_guardrules WHERE group_name = ? AND tenant_id = ? AND rule_name = ?",
        (body.group_name, body.tenant_id, body.rule_name),
    ).fetchone()
    return _row_to_guardrule(row)


@router.get("/api/group-guardrules", response_model=list[GroupGuardruleResponse])
def list_group_guardrules(
    group_name: Optional[str] = None,
    tenant_id: Optional[str] = None,
):
    """List content guardrules, optionally filtered by group or tenant."""
    conn = get_shared_connection()
    conditions = []
    params: list[Any] = []
    if group_name:
        conditions.append("group_name = ?")
        params.append(group_name)
    if tenant_id:
        conditions.append("tenant_id = ?")
        params.append(tenant_id)
    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    rows = conn.execute(
        f"SELECT * FROM group_guardrules {where} ORDER BY group_name, rule_name",
        tuple(params),
    ).fetchall()
    return [_row_to_guardrule(row) for row in rows]


@router.delete("/api/group-guardrules/{rule_id}", status_code=200)
def delete_group_guardrule(rule_id: str, tenant_id: str):
    """Delete a content guardrule by ID, scoped to tenant. tenant_id is required."""
    conn = get_shared_connection()
    cursor = conn.execute(
        "DELETE FROM group_guardrules WHERE id = ? AND tenant_id = ?",
        (rule_id, tenant_id),
    )
    conn.commit()
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Guardrule not found")
    return {"status": "deleted", "id": rule_id}


# ── Acceptable Use Policy ──────────────────────────────────────────


def _get_aup_manager(request: Request):
    """Reuse singleton from app.state, fallback to new instance."""
    mgr = getattr(request.app.state, "aup_manager", None)
    if mgr is None:
        from ...governance.acceptable_use import AUPManager
        mgr = AUPManager()
    return mgr


@router.get("/api/aup/active")
def get_active_aup(request: Request, tenant_id: str = Query(..., description="Tenant identifier")):
    """Get the active acceptable use policy for a tenant."""
    mgr = _get_aup_manager(request)
    policy = mgr.get_active(tenant_id)
    if not policy:
        return {"policy": None}
    return {"policy": {"id": policy.id, "tenant_id": policy.tenant_id, "content": policy.content_markdown, "version": policy.version, "activated_at": policy.created_at}}


@router.post("/api/aup")
def create_aup(request: Request, tenant_id: str = Query(..., description="Tenant identifier"), content: str = ""):
    """Create or update the acceptable use policy for a tenant."""
    if not content.strip():
        raise HTTPException(status_code=400, detail="Policy content cannot be empty or whitespace-only")
    mgr = _get_aup_manager(request)
    policy = mgr.create_policy(tenant_id, content.strip())
    return {"policy": {"id": policy.id, "tenant_id": policy.tenant_id, "version": policy.version}}


class _AcknowledgeBody(BaseModel):
    policy_id: str
    user_id: str
    ip_address: str = ""

@router.post("/api/aup/acknowledge")
def acknowledge_aup(request: Request, body: _AcknowledgeBody):
    """Record a user's acknowledgment of the AUP."""
    mgr = _get_aup_manager(request)
    ack = mgr.acknowledge(body.policy_id, body.user_id, body.ip_address)
    return {"acknowledged": True, "id": ack.id, "acknowledged_at": ack.acknowledged_at}


@router.get("/api/aup/status")
def aup_status(request: Request, tenant_id: str = Query(..., description="Tenant identifier")):
    """Get AUP compliance status for a tenant."""
    mgr = _get_aup_manager(request)
    return mgr.acknowledgment_status(tenant_id)


@router.get("/api/aup/history")
def aup_history(tenant_id: str = Query(..., description="Tenant identifier")):
    """List all AUP versions for a tenant, newest first."""
    from ...store.db import get_shared_connection
    rows = get_shared_connection().execute(
        "SELECT * FROM aup_policies WHERE tenant_id=? ORDER BY version DESC",
        (tenant_id,),
    ).fetchall()
    return [
        {
            "id": dict(r).get("id"),
            "tenant_id": dict(r).get("tenant_id"),
            "version": dict(r).get("version"),
            "active": bool(dict(r).get("active")),
            "content": dict(r).get("content_markdown"),
            "created_at": dict(r).get("created_at"),
        }
        for r in rows
    ]
