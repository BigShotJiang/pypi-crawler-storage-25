"""User management API router."""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/users", tags=["users"])


class CreateUserRequest(BaseModel):
    tenant_id: str
    email: str
    name: str
    role: str = "viewer"


class UpdateUserRequest(BaseModel):
    email: Optional[str] = None
    name: Optional[str] = None
    role: Optional[str] = None
    status: Optional[str] = None
    mfa_enabled: Optional[int] = None


class EnforceMFARequest(BaseModel):
    tenant_id: str


class ImportCSVRequest(BaseModel):
    tenant_id: str
    csv_text: str = Field(max_length=512_000)  # 512 KB hard limit — prevents DoS via oversized uploads


def _user_dict(u) -> dict:
    return {
        "id": u.id,
        "tenant_id": u.tenant_id,
        "email": u.email,
        "name": u.name,
        "role": u.role,
        "mfa_enabled": bool(u.mfa_enabled),
        "status": u.status,
        "last_login": u.last_login,
        "created_at": u.created_at,
    }


@router.post("")
def create_user(req: CreateUserRequest):
    """Create a new user within a tenant."""
    try:
        from ...tenancy.users import UserManager
        u = UserManager().create(
            tenant_id=req.tenant_id,
            email=req.email,
            name=req.name,
            role=req.role,
        )
        return _user_dict(u)
    except Exception as exc:
        logger.exception("Unexpected error in create_user")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("")
def list_users(tenant_id: Optional[str] = None, role: Optional[str] = None, status: Optional[str] = None):
    """List users, optionally filtered by tenant_id, role, and status."""
    try:
        from ...tenancy.users import UserManager
        mgr = UserManager()
        if tenant_id:
            users = mgr.list(tenant_id=tenant_id, role=role, status=status)
        else:
            users = mgr.list_all(role=role, status=status)
        return [_user_dict(u) for u in users]
    except Exception as exc:
        logger.exception("Unexpected error in list_users")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/enforce-mfa", include_in_schema=False)
def _noop():
    # Placeholder to prevent /enforce-mfa being caught by /{user_id}
    raise HTTPException(status_code=405, detail="Use POST /api/users/enforce-mfa")


@router.get("/import-csv", include_in_schema=False)
def _noop2():
    raise HTTPException(status_code=405, detail="Use POST /api/users/import-csv")


@router.get("/{user_id}")
def get_user(user_id: str):
    """Get a single user by ID."""
    try:
        from ...tenancy.users import UserManager
        u = UserManager().get(user_id)
        if u is None:
            raise HTTPException(status_code=404, detail=f"User {user_id!r} not found")
        return _user_dict(u)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_user")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.put("/{user_id}")
def update_user(user_id: str, req: UpdateUserRequest):
    """Update user fields."""
    try:
        from ...tenancy.users import UserManager
        updates = {k: v for k, v in req.model_dump().items() if v is not None}
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        u = UserManager().update(user_id, **updates)
        if u is None:
            raise HTTPException(status_code=404, detail=f"User {user_id!r} not found")
        return _user_dict(u)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in update_user")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.delete("/{user_id}")
def delete_user(user_id: str):
    """Delete a user."""
    try:
        from ...tenancy.users import UserManager
        deleted = UserManager().delete(user_id)
        if not deleted:
            raise HTTPException(status_code=404, detail=f"User {user_id!r} not found")
        return {"deleted": True, "user_id": user_id}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in delete_user")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.post("/enforce-mfa")
def enforce_mfa(req: EnforceMFARequest):
    """Enable MFA for all users in a tenant that don't have it yet."""
    try:
        from ...tenancy.users import UserManager
        updated = UserManager().enforce_mfa(req.tenant_id)
        return {"tenant_id": req.tenant_id, "users_updated": updated}
    except Exception as exc:
        logger.exception("Unexpected error in enforce_mfa")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.post("/import-csv")
def import_csv(req: ImportCSVRequest):
    """Bulk-import users from CSV text (columns: email, name, role)."""
    try:
        from ...tenancy.users import UserManager
        users = UserManager().import_csv(req.tenant_id, req.csv_text)
        return {"tenant_id": req.tenant_id, "imported": len(users), "users": [_user_dict(u) for u in users]}
    except Exception as exc:
        logger.exception("Unexpected error in import_csv")
        raise HTTPException(status_code=500, detail="Internal server error") from exc
