from fastapi import APIRouter, Query
from ...store.backends.base import StorageBackend
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/cache", tags=["cache"])


def _conn() -> StorageBackend:
    return get_shared_connection()


@router.get("/stats")
def cache_stats():
    conn = _conn()
    row = conn.execute("""
        SELECT
            COUNT(*) as total,
            SUM(hit) as hits,
            COUNT(*) - SUM(hit) as misses,
            SUM(CASE WHEN hit=1 THEN saved_tok ELSE 0 END) as saved_tokens
        FROM cache_events
    """).fetchone()
    # Some backends (e.g. OtelBackend) return None when the ring buffer is
    # empty rather than a row of NULLs. Treat that as zero counts.
    if row is None:
        total = hits = misses = saved_tok = 0
    else:
        total = row["total"] or 0
        hits = row["hits"] or 0
        misses = row["misses"] or 0
        saved_tok = row["saved_tokens"] or 0
    return {
        "hit_rate": round(hits / total, 4) if total else 0,
        "total_hits": hits,
        "total_misses": misses,
        "saved_tokens": saved_tok,
        "savings_pct": round(saved_tok / max(saved_tok + (misses * 500), 1), 4),
        "estimated_savings_usd": round(saved_tok / 1000 * 0.003, 4),
    }


@router.post("/clear")
def clear_cache():
    """Clear the in-memory semantic cache."""
    try:
        from ...proxy.gateway import _pipeline
        if _pipeline and _pipeline._cache:
            _pipeline._cache.clear()
            return {"cleared": True}
        return {"cleared": False, "reason": "no cache instance"}
    except Exception as exc:
        return {"cleared": False, "reason": str(exc)}


@router.get("/events")
def list_cache_events(limit: int = Query(100, le=500), offset: int = 0):
    conn = _conn()
    rows = conn.execute(
        """SELECT ce.*,
               SUBSTR(qr.original, 1, 80) as query_preview
           FROM cache_events ce
           LEFT JOIN query_recon qr ON qr.trace_id = ce.trace_id
           ORDER BY ce.ts DESC LIMIT ? OFFSET ?""",
        (limit, offset)
    ).fetchall()
    return [dict(r) for r in rows]
