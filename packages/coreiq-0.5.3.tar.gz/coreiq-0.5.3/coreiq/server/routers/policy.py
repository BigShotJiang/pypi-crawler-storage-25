"""REST router for the Sovereign Policy Engine.

Endpoints under ``/v1/policy``:

- ``GET    /bundle``                        — edge pull (active bundle, ETag)
- ``GET    /bundle/{bundle_id}``            — fetch a specific version
- ``POST   /bundle``                        — submit a new draft (returns bundle_id + diff)
- ``POST   /bundle/{bundle_id}/approve``    — approve a draft (idempotent per approver)
- ``POST   /bundle/{bundle_id}/activate``   — promote to active
- ``GET    /bundle/history``                — list versions for a tenant
- ``POST   /decisions/replay``              — re-evaluate a stored decision
- ``GET    /decisions/{decision_id}``       — fetch a single decision
- ``GET    /healthz``                       — engine health (active bundle id, mode, residency)

When ``COREIQ_POLICY_FILE`` is set (GitOps mode), all writes return 409.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, Header, HTTPException, Response
from pydantic import BaseModel

from ...policy import Bundle, get_policy_engine, load_active_bundle, load_bundle_from_dict
from ...policy.bundle import BundleSignatureError
from ...policy.engine import RequestContext
from ...policy.loader import is_file_locked

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/policy", tags=["policy-engine"])


# ---------------------------------------------------------------------------
# Pydantic shapes
# ---------------------------------------------------------------------------


class BundleSubmit(BaseModel):
    bundle: Dict[str, Any]
    created_by: Optional[str] = None


class ApproveRequest(BaseModel):
    # Wave 3A: ``approver`` is now optional and only honored outside
    # production. The authenticated principal (X-Principal header or JWT
    # ``sub``) is the canonical source. Body-supplied approver in
    # production is rejected with 400.
    approver: Optional[str] = None


class RollbackRequest(BaseModel):
    reason: str


class ReplayRequest(BaseModel):
    decision_id: Optional[str] = None
    bundle_id: Optional[str] = None
    request_context: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _conn():
    from ...store.db import get_shared_connection
    return get_shared_connection()


def _row_get(row, col: str, default=None):
    """Safe column lookup tolerating backends (e.g. MongoDB) that omit
    NULL/unset fields from the result row."""
    try:
        v = row[col]
    except (KeyError, IndexError):
        return default
    return v if v is not None else default


def _row_to_bundle_meta(row) -> Dict[str, Any]:
    return {
        "bundle_id": row["bundle_id"],
        "tenant_id": row["tenant_id"],
        "version": row["version"],
        "mode": row["mode"],
        "residency": row["residency"],
        "status": row["status"],
        "created_by": _row_get(row, "created_by"),
        "created_at": _row_get(row, "created_at"),
        "approved_by": json.loads(row["approved_by_json"]) if _row_get(row, "approved_by_json") else [],
        "approved_at": _row_get(row, "approved_at"),
        "activated_at": _row_get(row, "activated_at"),
        "content_sha256": _row_get(row, "content_sha256"),
    }


def _gitops_lock() -> None:
    if is_file_locked():
        raise HTTPException(
            status_code=409,
            detail="Policy bundle is managed via COREIQ_POLICY_FILE; API writes are disabled. "
                   "Edit the file and reload.",
            headers={"X-Policy-Source": "file"},
        )


def _next_version(tenant_id: str) -> int:
    row = _conn().execute(
        "SELECT MAX(version) AS v FROM policy_bundles WHERE tenant_id=?",
        (tenant_id,),
    ).fetchone()
    return int((row["v"] if row and row["v"] is not None else 0)) + 1


# ---------------------------------------------------------------------------
# Bundle pull (edge clients)
# ---------------------------------------------------------------------------


@router.get("/bundle")
def get_active_bundle(
    response: Response,
    tenant_id: str = "default",
    if_none_match: Optional[str] = Header(default=None, alias="If-None-Match"),
):
    """Return the active bundle for *tenant_id* with ETag support."""
    bundle = load_active_bundle(tenant_id)
    if bundle is None:
        raise HTTPException(status_code=404, detail=f"No active bundle for tenant '{tenant_id}'")

    etag = bundle.bundle_id   # already sha256:...
    if if_none_match and if_none_match.strip('"') == etag:
        response.status_code = 304
        return Response(status_code=304, headers={"ETag": f'"{etag}"'})

    response.headers["ETag"] = f'"{etag}"'
    response.headers["X-Policy-Source"] = "file" if is_file_locked() else "api"
    return {
        "bundle_id": etag,
        "signature": bundle.sign(),
        "bundle": bundle.to_dict(),
    }


@router.get("/bundle/history")
def list_bundle_history(tenant_id: str = "default", limit: int = 50):
    rows = _conn().execute(
        "SELECT * FROM policy_bundles WHERE tenant_id=? ORDER BY version DESC LIMIT ?",
        (tenant_id, int(limit)),
    ).fetchall()
    return {"tenant_id": tenant_id, "versions": [_row_to_bundle_meta(r) for r in rows]}


@router.get("/bundle/{bundle_id}")
def get_bundle(bundle_id: str):
    row = _conn().execute(
        "SELECT * FROM policy_bundles WHERE bundle_id=?", (bundle_id,)
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Bundle {bundle_id} not found")
    meta = _row_to_bundle_meta(row)
    meta["bundle"] = json.loads(row["content_json"]) if row["content_json"] else {}
    meta["signature"] = row["signature"]
    return meta


# ---------------------------------------------------------------------------
# Submit / approve / activate
# ---------------------------------------------------------------------------


@router.post("/bundle", status_code=201)
def submit_bundle(payload: BundleSubmit):
    _gitops_lock()
    try:
        bundle = load_bundle_from_dict(payload.bundle)
    except (ValueError, BundleSignatureError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    bundle.created_by = payload.created_by or bundle.created_by
    bundle.created_at = bundle.created_at or datetime.now(timezone.utc).isoformat()
    bundle.version = _next_version(bundle.tenant_id)
    bundle.bundle_id = bundle.canonical_hash()
    sig = bundle.sign()

    diff = _diff_against_active(bundle)

    _conn().execute(
        """INSERT INTO policy_bundles
           (bundle_id, tenant_id, version, mode, residency,
            content_json, content_sha256, signature, status,
            created_by, created_at, approved_by_json)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            bundle.bundle_id, bundle.tenant_id, bundle.version,
            bundle.mode, bundle.residency,
            json.dumps(bundle.to_dict()), bundle.bundle_id, sig, "draft",
            bundle.created_by, bundle.created_at, json.dumps([]),
        ),
    )
    _conn().commit()

    return {"bundle_id": bundle.bundle_id, "version": bundle.version, "diff": diff}


def _diff_against_active(bundle: Bundle) -> Dict[str, Any]:
    active = load_active_bundle(bundle.tenant_id)
    if active is None:
        return {"first_bundle": True}
    a = active.to_dict()
    b = bundle.to_dict()
    changed = {}
    for k in set(a) | set(b):
        if a.get(k) != b.get(k):
            changed[k] = {"from": a.get(k), "to": b.get(k)}
    return changed


def _resolve_approver(
    payload: ApproveRequest,
    x_principal: Optional[str],
) -> tuple[str, str]:
    """Wave 3A: pick the canonical approver from the authenticated principal.

    Resolution order:
      1. ``X-Principal`` header (set by the auth middleware from JWT ``sub``)
      2. Body-supplied ``approver`` field (dev mode only — rejected in prod)

    Returns ``(approver, source)`` where ``source`` is "header" or "body".
    Raises 400 in production when only the body field is supplied — the
    body field is otherwise unauthenticated and a hostile client could
    manufacture an "approval" by another user.
    """
    import os as _os
    in_prod = _os.environ.get("COREIQ_ENV", "").lower() == "production"
    principal = (x_principal or "").strip()
    if principal:
        return principal, "header"
    body_val = (payload.approver or "").strip()
    if body_val and not in_prod:
        return body_val, "body"
    if in_prod:
        raise HTTPException(
            status_code=400,
            detail=(
                "approver must be derived from the authenticated principal "
                "(X-Principal header / JWT sub) in production; "
                "body-supplied approver is not accepted."
            ),
        )
    raise HTTPException(
        status_code=400,
        detail="approver required (set X-Principal header or pass `approver` in body)",
    )


@router.post("/bundle/{bundle_id}/approve")
def approve_bundle(
    bundle_id: str,
    payload: ApproveRequest,
    x_principal: Optional[str] = Header(default=None, alias="X-Principal"),
):
    _gitops_lock()
    approver, source = _resolve_approver(payload, x_principal)
    row = _conn().execute(
        "SELECT * FROM policy_bundles WHERE bundle_id=?", (bundle_id,)
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="bundle not found")
    if row["status"] not in ("draft", "approved"):
        raise HTTPException(status_code=409, detail=f"cannot approve bundle in status={row['status']}")

    approvers = json.loads(row["approved_by_json"]) if _row_get(row, "approved_by_json") else []
    if approver in approvers:
        return {"bundle_id": bundle_id, "approvers": approvers, "status": row["status"]}
    approvers.append(approver)

    # Sovereign+enforce bundles need 2 distinct approvers; others need 1.
    needs = 2 if (row["mode"] == "enforce" and row["residency"] not in ("any", None)) else 1
    new_status = "approved" if len(approvers) >= needs else "draft"

    _conn().execute(
        """UPDATE policy_bundles SET approved_by_json=?, approved_at=?, status=?
                WHERE bundle_id=?""",
        (
            json.dumps(approvers),
            datetime.now(timezone.utc).isoformat() if new_status == "approved" else _row_get(row, "approved_at"),
            new_status, bundle_id,
        ),
    )
    _conn().commit()

    # Wave 3A: record approval in the chained audit log, tagging the
    # source (header vs body) so forensics can tell apart bona-fide
    # principal-derived approvals from dev-mode body shortcuts.
    try:
        from ...governance.chained_audit import ChainedAuditLogger
        ChainedAuditLogger(source="policy").log(
            action="policy.bundle.approve",
            principal=approver,
            resource=f"bundle:{bundle_id}",
            outcome="success",
            metadata={
                "tenant_id": row["tenant_id"],
                "approver_source": source,
                "status": new_status,
                "approvers_count": len(approvers),
            },
        )
    except Exception as exc:
        logger.warning("approve audit failed (non-fatal): %s", exc)

    return {"bundle_id": bundle_id, "approvers": approvers, "status": new_status, "needs_approvers": needs}


@router.post("/bundle/{bundle_id}/activate")
def activate_bundle(bundle_id: str):
    _gitops_lock()
    row = _conn().execute(
        "SELECT * FROM policy_bundles WHERE bundle_id=?", (bundle_id,)
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="bundle not found")
    if row["status"] != "approved":
        raise HTTPException(
            status_code=409,
            detail=f"bundle must be 'approved' to activate (current status={row['status']})",
        )
    tenant_id = row["tenant_id"]
    now = datetime.now(timezone.utc).isoformat()
    # Demote any currently-active bundle for this tenant
    _conn().execute(
        "UPDATE policy_bundles SET status='superseded' WHERE tenant_id=? AND status='active'",
        (tenant_id,),
    )
    _conn().execute(
        "UPDATE policy_bundles SET status='active', activated_at=? WHERE bundle_id=?",
        (now, bundle_id),
    )
    _conn().commit()

    # Hot-swap engine bundle
    new_bundle = load_active_bundle(tenant_id)
    if new_bundle is not None:
        get_policy_engine().set_bundle(new_bundle)
    return {"bundle_id": bundle_id, "status": "active", "activated_at": now}


@router.post("/bundle/{bundle_id}/rollback")
def rollback_bundle(
    bundle_id: str,
    payload: RollbackRequest,
    x_principal: Optional[str] = Header(default=None, alias="X-Principal"),
):
    """Single-approver rollback of a previously-active bundle.

    Transitions a bundle in status=``superseded`` directly to ``approved``
    and immediately re-activates it. The 2-approver gate is bypassed but
    we require an authenticated principal (header ``X-Principal``) and a
    free-text ``reason`` which is woven into the audit chain.

    Returns 409 when the bundle isn't ``superseded``.
    """
    _gitops_lock()
    if not payload.reason or not payload.reason.strip():
        raise HTTPException(status_code=400, detail="reason is required for rollback")
    principal = (x_principal or "").strip()
    if not principal:
        raise HTTPException(
            status_code=401,
            detail="rollback requires an authenticated principal (X-Principal header)",
        )

    row = _conn().execute(
        "SELECT * FROM policy_bundles WHERE bundle_id=?", (bundle_id,),
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="bundle not found")
    if row["status"] != "superseded":
        raise HTTPException(
            status_code=409,
            detail=f"rollback requires status='superseded' (current={row['status']})",
        )

    tenant_id = row["tenant_id"]
    now = datetime.now(timezone.utc).isoformat()
    # Demote any currently-active bundle for this tenant
    _conn().execute(
        "UPDATE policy_bundles SET status='superseded' WHERE tenant_id=? AND status='active'",
        (tenant_id,),
    )
    # Single-approver: record the rollback principal as the sole approver
    # and flip directly to active.
    _conn().execute(
        """UPDATE policy_bundles SET status='active', activated_at=?,
                                     approved_by_json=?, approved_at=?
            WHERE bundle_id=?""",
        (
            now,
            json.dumps([principal]),
            now,
            bundle_id,
        ),
    )
    _conn().commit()

    # Audit the rollback (fail-soft).
    try:
        from ...governance.chained_audit import ChainedAuditLogger
        ChainedAuditLogger(source="policy").log(
            action="policy.bundle.rollback",
            principal=principal,
            resource=f"bundle:{bundle_id}",
            outcome="success",
            metadata={
                "tenant_id": tenant_id,
                "reason": payload.reason,
                "single_approver": True,
            },
        )
    except Exception as exc:
        logger.warning("rollback audit failed (non-fatal): %s", exc)

    new_bundle = load_active_bundle(tenant_id)
    if new_bundle is not None:
        get_policy_engine().set_bundle(new_bundle)
    return {
        "bundle_id": bundle_id,
        "status": "active",
        "activated_at": now,
        "rolled_back_by": principal,
        "reason": payload.reason,
    }


# ---------------------------------------------------------------------------
# Decisions
# ---------------------------------------------------------------------------


@router.get("/decisions/{decision_id}")
def get_decision(decision_id: str):
    row = _conn().execute(
        "SELECT * FROM policy_decisions WHERE decision_id=?", (decision_id,),
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="decision not found")
    return {
        "decision_id": row["decision_id"],
        "trace_id": row["trace_id"],
        "bundle_id": row["bundle_id"],
        "tenant_id": row["tenant_id"],
        "principal": row["principal"],
        "action": row["action"],
        "reason": row["reason"],
        "evaluated_rules": json.loads(row["evaluated_rules_json"]) if row["evaluated_rules_json"] else [],
        "target_deployment": row["target_deployment"],
        "residency": row["residency"],
        "redactions": json.loads(row["redactions_json"]) if row["redactions_json"] else [],
        "ts": row["ts"],
        # Wave 1A P0 — replay-determinism context fields (may be NULL on
        # rows written before the schema migration).
        "messages": (
            json.loads(row["messages_json"])
            if _row_has(row, "messages_json") and row["messages_json"] else []
        ),
        "input_tokens": row["input_tokens"] if _row_has(row, "input_tokens") else None,
        "metadata": (
            json.loads(row["metadata_json"])
            if _row_has(row, "metadata_json") and row["metadata_json"] else {}
        ),
        "bundle_age_seconds": (
            row["bundle_age_seconds"] if _row_has(row, "bundle_age_seconds") else None
        ),
    }


def _row_has(row, key: str) -> bool:
    """Return True if *row* has a (non-missing) column named *key*.

    StorageBackend rows expose dict-like access but raise different
    errors per backend when a column is missing (sqlite3 raises
    IndexError, others KeyError). Treat any access failure as "absent".
    """
    try:
        _ = row[key]
        return True
    except Exception:
        return False


@router.post("/decisions/replay")
def replay_decision(payload: ReplayRequest):
    """Re-evaluate a stored decision against its original bundle (or a specified one).

    Supports two modes:
      - decision_id only: rebuild ctx from the stored decision and re-evaluate
        against the bundle that produced it.
      - bundle_id + request_context: dry-run evaluation for forensics.
    """
    if not payload.decision_id and not (payload.bundle_id and payload.request_context):
        raise HTTPException(status_code=400, detail="provide decision_id OR (bundle_id + request_context)")

    d_row = None
    if payload.decision_id:
        d_row = _conn().execute(
            "SELECT * FROM policy_decisions WHERE decision_id=?", (payload.decision_id,),
        ).fetchone()
        if not d_row:
            raise HTTPException(status_code=404, detail="decision not found")
        bundle_id = d_row["bundle_id"]
    else:
        bundle_id = payload.bundle_id

    b_row = _conn().execute(
        "SELECT content_json FROM policy_bundles WHERE bundle_id=?", (bundle_id,),
    ).fetchone()
    if not b_row:
        raise HTTPException(status_code=404, detail=f"bundle {bundle_id} not found")
    bundle = Bundle.from_dict(json.loads(b_row["content_json"]))

    # Wave 1A P0 — replay determinism:
    #
    # When a decision_id is supplied, reconstruct the RequestContext from
    # the persisted policy_decisions row (messages_json, input_tokens,
    # metadata_json) so the replay re-evaluates against the exact inputs
    # that produced the original decision. Caller-supplied
    # ``request_context`` overrides take precedence so forensics can probe
    # what-if scenarios.
    stored_ctx: Dict[str, Any] = {}
    if d_row is not None:
        def _get(col: str, default=None):
            try:
                v = d_row[col]
                return v if v is not None else default
            except Exception:
                return default

        try:
            messages_json = _get("messages_json")
            metadata_json = _get("metadata_json")
            stored_ctx = {
                "tenant_id": _get("tenant_id", "default"),
                "principal": _get("principal", ""),
                "messages": json.loads(messages_json) if messages_json else [],
                "input_tokens": _get("input_tokens"),
                "metadata": json.loads(metadata_json) if metadata_json else {},
                "trace_id": _get("trace_id"),
            }
        except Exception:
            stored_ctx = {}

    ctx_dict: Dict[str, Any] = {**stored_ctx, **(payload.request_context or {})}

    pctx = RequestContext(
        tenant_id=ctx_dict.get("tenant_id", "default"),
        principal=ctx_dict.get("principal", ""),
        groups=list(ctx_dict.get("groups") or []),
        model=ctx_dict.get("model", ""),
        provider=ctx_dict.get("provider", ""),
        target_host=ctx_dict.get("target_host", ""),
        target_deployment_id=ctx_dict.get("target_deployment_id"),
        target_residency=ctx_dict.get("target_residency"),
        input_tokens=ctx_dict.get("input_tokens"),
        output_tokens=ctx_dict.get("output_tokens"),
        cost_usd=ctx_dict.get("cost_usd"),
        pii_detected=bool(ctx_dict.get("pii_detected", False)),
        metadata=dict(ctx_dict.get("metadata") or {}),
        messages=list(ctx_dict.get("messages") or []),
        trace_id=ctx_dict.get("trace_id"),
    )

    from ...policy.engine import PolicyEngine
    eng = PolicyEngine(bundle)
    decision = eng.evaluate_pre(pctx)
    if pctx.output_text or pctx.output_tokens or pctx.cost_usd:
        eng.evaluate_post(pctx, decision)
    return decision.to_dict()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


@router.get("/healthz")
def healthz():
    eng = get_policy_engine()
    bundle = eng.get_bundle()
    return {
        "engine_version": "2.0",
        "active_bundle_id": bundle.bundle_id if bundle else None,
        "mode": bundle.mode if bundle else None,
        "residency": bundle.residency if bundle else None,
        "tenant_id": bundle.tenant_id if bundle else None,
        "source": "file" if is_file_locked() else "api",
    }
