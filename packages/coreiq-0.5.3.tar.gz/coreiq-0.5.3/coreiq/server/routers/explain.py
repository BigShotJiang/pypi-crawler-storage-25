"""Authorization explanation endpoint."""
from __future__ import annotations
import logging
from dataclasses import asdict
from fastapi import APIRouter, Query
from ...identity.explain import AuthExplainer

logger = logging.getLogger(__name__)
router = APIRouter()

@router.get("/api/auth/explain")
def explain_authorize(api_key: str = Query("", description="API key to explain authorization for")):
    """Explain what authorization decisions would be made for a given API key."""
    explainer = AuthExplainer()
    result = explainer.explain(api_key)
    return asdict(result)
