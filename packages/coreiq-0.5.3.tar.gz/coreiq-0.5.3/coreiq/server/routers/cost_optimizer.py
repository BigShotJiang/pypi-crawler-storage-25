"""API router for Cost Optimizer / FinOps."""
from typing import Optional
from fastapi import APIRouter
from pydantic import BaseModel
from ...performance.cost_optimizer import CostOptimizer

router = APIRouter(prefix="/api/cost-optimizer", tags=["cost-optimizer"])
_optimizer: Optional[CostOptimizer] = None


def _get() -> CostOptimizer:
    global _optimizer
    if _optimizer is None:
        _optimizer = CostOptimizer()
    return _optimizer


class RecordRequest(BaseModel):
    model: str
    tokens: int
    cost: float
    complexity: str = "moderate"
    latency_ms: int = 0
    cache_eligible: bool = False


@router.post("/record")
def record(body: RecordRequest):
    _get().record_request(body.model, body.tokens, body.cost, body.complexity, body.latency_ms, body.cache_eligible)
    return {"recorded": True}


@router.get("/report")
def report():
    return _get().generate_report().to_dict()


@router.post("/clear")
def clear():
    _get().clear()
    return {"cleared": True}
