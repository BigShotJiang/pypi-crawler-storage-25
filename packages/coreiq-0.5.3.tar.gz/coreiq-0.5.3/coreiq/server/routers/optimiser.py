import json
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...store.db import get_shared_connection, create_connection

router = APIRouter(prefix="/api/optimiser", tags=["optimiser"])


def _conn():
    """Shared connection for reads."""
    return get_shared_connection()


def _write_conn():
    """Dedicated connection for writes (avoids WAL read/write conflicts)."""
    return create_connection()


# ── Variants ────────────────────────────────────────────────────────────────

@router.get("/variants")
def list_variants():
    conn = _conn()
    rows = conn.execute("""
        SELECT
            variant_id,
            MAX(phase)      AS phase,
            AVG(win_rate)   AS avg_win_rate,
            SUM(samples)    AS sample_size,
            MAX(promoted)   AS promoted,
            MAX(ts)         AS last_seen
        FROM evolution
        GROUP BY variant_id
        ORDER BY avg_win_rate DESC
    """).fetchall()

    # Read active variant from config
    cfg_row = conn.execute(
        "SELECT value FROM optimiser_config WHERE key='active_variant_id'"
    ).fetchone()
    active_id = cfg_row["value"] if cfg_row else None

    result = []
    for r in rows:
        wr = round(float(r["avg_win_rate"] or 0), 4)
        result.append({
            "id": r["variant_id"],
            "phase": r["phase"],
            "win_rate": wr,
            "sample_size": r["sample_size"] or 0,
            "avg_score": wr,
            "promoted": bool(r["promoted"]),
            "status": "active" if r["variant_id"] == active_id else "candidate",
            "last_seen": r["last_seen"],
        })
    return result


@router.post("/variants/{variant_id}/promote")
def promote_variant(variant_id: str):
    row = _conn().execute(
        "SELECT variant_id FROM evolution WHERE variant_id=? LIMIT 1", (variant_id,)
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Variant not found")

    now = datetime.now(timezone.utc).isoformat()
    conn = _conn()
    conn.execute(
        "INSERT OR REPLACE INTO optimiser_config(key, value, updated_at) VALUES(?,?,?)",
        ("active_variant_id", variant_id, now),
    )
    conn.commit()
    return {"ok": True, "active_variant_id": variant_id}


# ── Config ───────────────────────────────────────────────────────────────────

DEFAULTS = {
    "model": "claude-sonnet-4-6",
    "temperature": "0.7",
    "cache_threshold": "0.85",
    "active_variant_id": "",
}


def _read_config(conn) -> dict:
    rows = conn.execute("SELECT key, value FROM optimiser_config").fetchall()
    cfg = dict(DEFAULTS)
    for r in rows:
        cfg[r["key"]] = r["value"]
    return cfg


@router.get("/config")
def get_config():
    conn = _conn()
    cfg = _read_config(conn)
    return {
        "model": cfg["model"],
        "temperature": float(cfg["temperature"]),
        "cache_threshold": float(cfg["cache_threshold"]),
        "active_variant_id": cfg["active_variant_id"],
    }


class ConfigUpdate(BaseModel):
    model: Optional[str] = None
    temperature: Optional[float] = None
    cache_threshold: Optional[float] = None
    active_variant_id: Optional[str] = None


@router.put("/config")
def update_config(body: ConfigUpdate):
    updates = body.model_dump(exclude_none=True)
    if "active_variant_id" in updates and updates["active_variant_id"]:
        variant_id = updates["active_variant_id"]
        row = _conn().execute(
            "SELECT variant_id FROM evolution WHERE variant_id = ? LIMIT 1", (variant_id,)
        ).fetchone()
        if not row:
            raise HTTPException(status_code=400, detail=f"Variant '{variant_id}' not found")
    conn = _conn()
    now = datetime.now(timezone.utc).isoformat()
    for key, val in updates.items():
        conn.execute(
            "INSERT OR REPLACE INTO optimiser_config(key, value, updated_at) VALUES(?,?,?)",
            (key, str(val), now),
        )
    conn.commit()
    return _read_config(conn)


# ── Deploy ───────────────────────────────────────────────────────────────────

class DeployRequest(BaseModel):
    environment: str = "local"
    note: Optional[str] = None


@router.post("/deploy")
def deploy(body: DeployRequest):
    if body.environment not in ("local", "staging", "prod"):
        raise HTTPException(status_code=400, detail="environment must be local|staging|prod")
    cfg = _read_config(_conn())
    deploy_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    conn = _conn()
    conn.execute(
        "INSERT INTO deploy_history(id, config_snapshot, environment, deployed_at, note) VALUES(?,?,?,?,?)",
        (deploy_id, json.dumps(cfg), body.environment, now, body.note),
    )
    conn.commit()
    return {
        "id": deploy_id,
        "config_snapshot": cfg,
        "environment": body.environment,
        "deployed_at": now,
        "note": body.note,
    }


@router.get("/deploys")
def list_deploys():
    conn = _conn()
    rows = conn.execute(
        "SELECT * FROM deploy_history ORDER BY deployed_at DESC LIMIT 50"
    ).fetchall()
    return [
        {
            "id": r["id"],
            "config_snapshot": json.loads(r["config_snapshot"]),
            "environment": r["environment"],
            "deployed_at": r["deployed_at"],
            "note": r["note"],
        }
        for r in rows
    ]
