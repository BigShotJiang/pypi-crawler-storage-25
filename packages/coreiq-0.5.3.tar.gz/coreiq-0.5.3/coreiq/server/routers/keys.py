"""FastAPI router for virtual API key management.

All endpoints require the master API key (``COREIQ_API_KEY``) for
authentication — this is enforced by the existing ``auth_middleware``
in ``server/app.py`` since every route lives under ``/api/``.

Endpoints:
    POST   /api/keys           — generate a new virtual key
    GET    /api/keys           — list all keys (no raw keys shown)
    GET    /api/keys/{key_id}  — get key details
    DELETE /api/keys/{key_id}  — revoke (block) a key
"""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ...proxy.keys import KeyManager

router = APIRouter(prefix="/api/keys", tags=["keys"])

# Module-level singleton — initialised lazily on first request.
_manager: KeyManager | None = None


def _get_manager() -> KeyManager:
    global _manager
    if _manager is None:
        _manager = KeyManager()
    return _manager


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class CreateKeyRequest(BaseModel):
    """Body for ``POST /api/keys``."""

    tenant_id: str = Field(default="default", description="Tenant that owns this key.")
    name: str = Field(default="", description="Human-readable label for the key.")
    models: Optional[list[str]] = Field(
        default=None,
        description="Allowed models (e.g. ['openai/gpt-4o']). None = all models.",
    )
    max_budget_usd: Optional[float] = Field(
        default=None,
        description="Maximum spend in USD. None = unlimited.",
    )
    tpm_limit: Optional[int] = Field(default=None, description="Tokens-per-minute limit.")
    rpm_limit: Optional[int] = Field(default=None, description="Requests-per-minute limit.")
    expires_in_days: Optional[int] = Field(
        default=None,
        description="Key expiry in days from now. None = never expires.",
    )
    metadata: Optional[dict[str, Any]] = Field(
        default=None,
        description="Arbitrary metadata to attach to the key.",
    )


class KeyResponse(BaseModel):
    """Serialised key record (never includes the raw key)."""

    id: str
    tenant_id: str
    name: str
    models: Optional[list[str]] = None
    max_budget_usd: Optional[float] = None
    spend_usd: float = 0.0
    tpm_limit: Optional[int] = None
    rpm_limit: Optional[int] = None
    blocked: bool = False
    expires_at: Optional[str] = None
    created_at: str = ""
    metadata: dict[str, Any] = {}


class CreateKeyResponse(BaseModel):
    """Returned by ``POST /api/keys`` — includes the raw key exactly once."""

    key: str  # raw key — shown only at creation time
    key_info: KeyResponse


def _vk_to_response(vk) -> KeyResponse:
    return KeyResponse(
        id=vk.id,
        tenant_id=vk.tenant_id,
        name=vk.name,
        models=vk.models,
        max_budget_usd=vk.max_budget_usd,
        spend_usd=vk.spend_usd,
        tpm_limit=vk.tpm_limit,
        rpm_limit=vk.rpm_limit,
        blocked=vk.blocked,
        expires_at=vk.expires_at.isoformat() if vk.expires_at else None,
        created_at=vk.created_at.isoformat() if vk.created_at else "",
        metadata=vk.metadata,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("", response_model=CreateKeyResponse, status_code=201)
def create_key(body: CreateKeyRequest):
    """Generate a new virtual API key.

    The raw key is returned **once** in the response.  It cannot be
    retrieved again — only a SHA-256 hash is stored.
    """
    mgr = _get_manager()
    raw_key, vk = mgr.generate_key(
        tenant_id=body.tenant_id,
        name=body.name,
        models=body.models,
        max_budget_usd=body.max_budget_usd,
        tpm_limit=body.tpm_limit,
        rpm_limit=body.rpm_limit,
        expires_in_days=body.expires_in_days,
        metadata=body.metadata,
    )
    return CreateKeyResponse(key=raw_key, key_info=_vk_to_response(vk))


@router.get("", response_model=list[KeyResponse])
def list_keys(tenant_id: Optional[str] = None):
    """List all virtual keys (no raw keys shown)."""
    mgr = _get_manager()
    keys = mgr.list_keys(tenant_id=tenant_id)
    return [_vk_to_response(vk) for vk in keys]


@router.get("/{key_id}", response_model=KeyResponse)
def get_key(key_id: str):
    """Get details for a specific key."""
    mgr = _get_manager()
    vk = mgr.get_key(key_id)
    if vk is None:
        raise HTTPException(status_code=404, detail="Key not found")
    return _vk_to_response(vk)


@router.delete("/{key_id}", status_code=200)
def revoke_key(key_id: str):
    """Revoke (block) a virtual key.  The key remains in the database
    but is marked as blocked and will no longer pass validation."""
    mgr = _get_manager()
    revoked = mgr.revoke_key(key_id)
    if not revoked:
        raise HTTPException(status_code=404, detail="Key not found")
    return {"status": "revoked", "key_id": key_id}
