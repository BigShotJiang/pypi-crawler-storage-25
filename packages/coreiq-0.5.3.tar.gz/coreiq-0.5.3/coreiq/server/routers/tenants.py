"""FastAPI router for tenant management.

All endpoints require the master API key (``COREIQ_API_KEY``) for
authentication — enforced by ``auth_middleware`` in ``server/app.py``.

Endpoints:
    POST   /api/tenants              — create a new tenant
    GET    /api/tenants              — list tenants (filter by plan)
    GET    /api/tenants/{tenant_id}  — get tenant details
    PUT    /api/tenants/{tenant_id}  — update tenant (name, plan)
    DELETE /api/tenants/{tenant_id}  — delete tenant
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict

from ...tenancy.manager import Tenant, TenantManager

router = APIRouter(prefix="/api/tenants", tags=["tenants"])

# Module-level singleton — initialised lazily on first request.
_manager: TenantManager | None = None


def _get_manager() -> TenantManager:
    global _manager
    if _manager is None:
        _manager = TenantManager()
    return _manager


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class CreateTenantRequest(BaseModel):
    """Body for ``POST /api/tenants``."""

    name: str
    slug: str
    plan: str = "free"
    settings: Optional[dict] = None


class UpdateTenantRequest(BaseModel):
    """Body for ``PUT /api/tenants/{tenant_id}``."""

    name: Optional[str] = None
    plan: Optional[str] = None


class TenantResponse(BaseModel):
    """Serialised tenant record."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    slug: str
    plan: str
    settings_json: str
    created_at: str
    updated_at: str


def _to_response(t: Tenant) -> TenantResponse:
    return TenantResponse(
        id=t.id,
        name=t.name,
        slug=t.slug,
        plan=t.plan,
        settings_json=t.settings_json,
        created_at=t.created_at,
        updated_at=t.updated_at,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("", response_model=TenantResponse, status_code=201)
def create_tenant(body: CreateTenantRequest):
    """Create a new tenant."""
    mgr = _get_manager()
    tenant = mgr.create(
        name=body.name,
        slug=body.slug,
        plan=body.plan,
        settings=body.settings,
    )
    return _to_response(tenant)


@router.get("", response_model=list[TenantResponse])
def list_tenants(plan: Optional[str] = None):
    """List all tenants, optionally filtered by plan."""
    mgr = _get_manager()
    tenants = mgr.list(plan=plan)
    return [_to_response(t) for t in tenants]


@router.get("/{tenant_id}", response_model=TenantResponse)
def get_tenant(tenant_id: str):
    """Get details for a specific tenant."""
    mgr = _get_manager()
    tenant = mgr.get(tenant_id)
    if tenant is None:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return _to_response(tenant)


@router.put("/{tenant_id}", response_model=TenantResponse)
def update_tenant(tenant_id: str, body: UpdateTenantRequest):
    """Update a tenant's name or plan."""
    mgr = _get_manager()
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    tenant = mgr.update(tenant_id, **updates)
    if tenant is None:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return _to_response(tenant)


@router.delete("/{tenant_id}", status_code=200)
def delete_tenant(tenant_id: str):
    """Delete a tenant."""
    mgr = _get_manager()
    deleted = mgr.delete(tenant_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return {"status": "deleted", "tenant_id": tenant_id}
