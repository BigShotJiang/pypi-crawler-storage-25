"""API router for Agent Governance — tool policies, budgets, delegation, loop detection, HITL queue."""
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from ...governance.agent_policies import AgentPolicyEngine, AgentPolicyViolation

router = APIRouter(prefix="/api/agent-governance", tags=["agent-governance"])

_engine: Optional[AgentPolicyEngine] = None


def _get_engine() -> AgentPolicyEngine:
    global _engine
    if _engine is None:
        _engine = AgentPolicyEngine()
    return _engine


class ToolPolicySet(BaseModel):
    agent_id: str
    max_calls_per_session: int = 100
    require_approval_for: List[str] = []
    blocked_tools: List[str] = []
    allowed_tools: Optional[List[str]] = None
    rate_limit_per_minute: int = 60


class BudgetSet(BaseModel):
    agent_id: str
    max_cost_per_session: float = 5.00
    max_cost_per_day: float = 100.00
    max_tokens_per_session: int = 500000
    alert_at: float = 0.8


class DelegationPolicySet(BaseModel):
    agent_id: str
    can_delegate_to: List[str] = []
    max_delegation_depth: int = 5
    require_human_approval_after_depth: int = 3


class LoopPolicySet(BaseModel):
    agent_id: str
    max_iterations: int = 50
    cost_circuit_breaker: float = 5.00
    time_circuit_breaker_seconds: int = 300


class SessionStart(BaseModel):
    agent_id: str
    delegation_depth: int = 0


class ToolCallCheck(BaseModel):
    tool_name: str


class BudgetCheck(BaseModel):
    cost_delta: float = 0.0
    tokens_delta: int = 0


class DelegationCheck(BaseModel):
    target_agent: str


class ReasoningLog(BaseModel):
    step: str
    reasoning: str


@router.post("/policies/tool")
def set_tool_policy(body: ToolPolicySet):
    p = _get_engine().set_tool_policy(
        body.agent_id,
        max_calls_per_session=body.max_calls_per_session,
        require_approval_for=body.require_approval_for,
        blocked_tools=body.blocked_tools,
        allowed_tools=body.allowed_tools,
    )
    return p.to_dict()


@router.post("/policies/budget")
def set_budget(body: BudgetSet):
    b = _get_engine().set_agent_budget(
        body.agent_id,
        max_cost_per_session=body.max_cost_per_session,
        max_cost_per_day=body.max_cost_per_day,
        max_tokens_per_session=body.max_tokens_per_session,
        alert_at=body.alert_at,
    )
    return b.to_dict()


@router.post("/policies/delegation")
def set_delegation_policy(body: DelegationPolicySet):
    p = _get_engine().set_delegation_policy(
        body.agent_id,
        can_delegate_to=body.can_delegate_to,
        max_delegation_depth=body.max_delegation_depth,
        require_human_approval_after_depth=body.require_human_approval_after_depth,
    )
    return p.to_dict()


@router.post("/policies/loop")
def set_loop_policy(body: LoopPolicySet):
    p = _get_engine().set_loop_policy(
        body.agent_id,
        max_iterations=body.max_iterations,
        cost_circuit_breaker=body.cost_circuit_breaker,
        time_circuit_breaker_seconds=body.time_circuit_breaker_seconds,
    )
    return p.to_dict()


@router.post("/policies/reasoning/{agent_id}")
def require_reasoning(agent_id: str):
    _get_engine().require_reasoning_trace(agent_id)
    return {"agent_id": agent_id, "reasoning_trace_required": True}


@router.get("/policies/{agent_id}")
def get_policies(agent_id: str):
    return _get_engine().get_policies(agent_id)


@router.post("/sessions")
def start_session(body: SessionStart):
    session = _get_engine().start_session(body.agent_id, body.delegation_depth)
    return session.to_dict()


@router.get("/sessions")
def list_sessions():
    return _get_engine().list_sessions()


@router.get("/sessions/{session_id}")
def get_session(session_id: str):
    s = _get_engine().get_session(session_id)
    if s is None:
        raise HTTPException(404, "Session not found")
    return s.to_dict()


@router.delete("/sessions/{session_id}")
def end_session(session_id: str):
    s = _get_engine().end_session(session_id)
    if s is None:
        raise HTTPException(404, "Session not found")
    return s.to_dict()


@router.post("/sessions/{session_id}/check-tool")
def check_tool_call(session_id: str, body: ToolCallCheck):
    try:
        return _get_engine().check_tool_call(session_id, body.tool_name)
    except AgentPolicyViolation as e:
        raise HTTPException(403, str(e))


@router.post("/sessions/{session_id}/check-budget")
def check_budget(session_id: str, body: BudgetCheck):
    try:
        return _get_engine().check_budget(session_id, body.cost_delta, body.tokens_delta)
    except AgentPolicyViolation as e:
        raise HTTPException(403, str(e))


@router.post("/sessions/{session_id}/check-delegation")
def check_delegation(session_id: str, body: DelegationCheck):
    try:
        return _get_engine().check_delegation(session_id, body.target_agent)
    except AgentPolicyViolation as e:
        raise HTTPException(403, str(e))


@router.post("/sessions/{session_id}/check-loop")
def check_loop(session_id: str):
    try:
        return _get_engine().check_loop(session_id)
    except AgentPolicyViolation as e:
        raise HTTPException(403, str(e))


@router.post("/sessions/{session_id}/reasoning")
def log_reasoning(session_id: str, body: ReasoningLog):
    _get_engine().log_reasoning(session_id, body.step, body.reasoning)
    return {"logged": True}


# ---------------------------------------------------------------------------
# HITL Queue
# ---------------------------------------------------------------------------


class HITLEnqueueRequest(BaseModel):
    session_id: str
    tool_name: str
    context: Dict[str, Any] = {}


class HITLResolveRequest(BaseModel):
    approved: bool
    reviewer: str = "human"
    note: str = ""


@router.post("/hitl/enqueue")
def hitl_enqueue(body: HITLEnqueueRequest):
    """Enqueue a tool call for human approval."""
    item = _get_engine().enqueue_hitl(body.session_id, body.tool_name, body.context)
    return item.to_dict()


@router.get("/hitl/queue")
def hitl_list_queue(status: Optional[str] = Query(None, description="Filter by status: pending | approved | rejected")):
    """List HITL approval requests, optionally filtered by status."""
    items = _get_engine().list_hitl_queue(status=status)
    return {"items": [i.to_dict() for i in items], "total": len(items)}


@router.post("/hitl/{item_id}/resolve")
def hitl_resolve(item_id: str, body: HITLResolveRequest):
    """Approve or reject a pending HITL item."""
    item = _get_engine().resolve_hitl(item_id, body.approved, body.reviewer, body.note)
    if item is None:
        raise HTTPException(404, f"HITL item '{item_id}' not found")
    return item.to_dict()
