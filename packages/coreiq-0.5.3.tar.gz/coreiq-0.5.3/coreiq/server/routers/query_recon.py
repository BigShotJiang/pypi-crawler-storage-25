from fastapi import APIRouter, Query
from ...store.backends.base import StorageBackend
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/query_recon", tags=["query_recon"])


def _conn() -> StorageBackend:
    return get_shared_connection()


@router.get("")
def list_query_recon(limit: int = Query(50, le=500), offset: int = 0):
    conn = _conn()
    rows = conn.execute(
        "SELECT * FROM query_recon ORDER BY ts DESC LIMIT ? OFFSET ?",
        (limit, offset)
    ).fetchall()
    return [dict(r) for r in rows]
