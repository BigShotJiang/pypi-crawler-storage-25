"""Integrations API router — webhooks and connector templates."""
from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

_ALLOWED_DATADOG_SITES = frozenset({
    "datadoghq.com", "datadoghq.eu", "us3.datadoghq.com",
    "us5.datadoghq.com", "ap1.datadoghq.com", "ddog-gov.com",
})

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["integrations"])

_INTEGRATION_TEMPLATES = [
    {
        "id": "slack",
        "name": "Slack",
        "description": "Send alerts and notifications to Slack channels via Incoming Webhooks.",
        "type": "webhook",
        "docs_url": "https://api.slack.com/messaging/webhooks",
        "fields": ["webhook_url", "channel"],
    },
    {
        "id": "jira",
        "name": "Jira",
        "description": "Automatically create Jira issues from CoreIQ alerts.",
        "type": "connector",
        "docs_url": "https://developer.atlassian.com/cloud/jira/platform/rest/v3/",
        "fields": ["base_url", "email", "api_token", "project_key"],
    },
    {
        "id": "pagerduty",
        "name": "PagerDuty",
        "description": "Trigger and resolve PagerDuty incidents from CoreIQ events.",
        "type": "connector",
        "docs_url": "https://developer.pagerduty.com/docs/events-api-v2/",
        "fields": ["routing_key"],
    },
    {
        "id": "datadog",
        "name": "Datadog",
        "description": "Forward events and metrics to Datadog for unified observability.",
        "type": "connector",
        "docs_url": "https://docs.datadoghq.com/api/latest/events/",
        "fields": ["api_key", "site"],
    },
    {
        "id": "github_actions",
        "name": "GitHub Actions",
        "description": "Trigger GitHub Actions workflows via repository dispatch events.",
        "type": "webhook",
        "docs_url": "https://docs.github.com/en/rest/repos/repos#create-a-repository-dispatch-event",
        "fields": ["repository", "token", "event_type"],
    },
    {
        "id": "custom_webhook",
        "name": "Custom Webhook",
        "description": "Send signed JSON payloads to any HTTP endpoint on CoreIQ events.",
        "type": "webhook",
        "docs_url": None,
        "fields": ["url", "events", "secret"],
    },
]


@router.get("/integrations/templates", tags=["integrations"])
def list_integration_templates():
    """List all available integration types."""
    return _INTEGRATION_TEMPLATES


# ── Webhooks ──────────────────────────────────────────────────────────────────

class WebhookRegisterRequest(BaseModel):
    tenant_id: str
    url: str
    events: List[str]
    secret: Optional[str] = None


@router.post("/webhooks", tags=["webhooks"])
def register_webhook(req: WebhookRegisterRequest):
    """Register a new webhook endpoint."""
    try:
        from ...integrations import WebhookManager
        manager = WebhookManager()
        w = manager.register(
            tenant_id=req.tenant_id,
            url=req.url,
            events=req.events,
            secret=req.secret,
        )
        return {
            "id": w.id,
            "tenant_id": w.tenant_id,
            "url": w.url,
            "events": req.events,
            "status": w.status,
            "created_at": w.created_at,
        }
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Unexpected error in register_webhook")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/webhooks", tags=["webhooks"])
def list_webhooks(tenant_id: str):
    """List all webhooks for a tenant."""
    try:
        from ...integrations import WebhookManager
        import json
        manager = WebhookManager()
        webhooks = manager.list(tenant_id=tenant_id)
        return [
            {
                "id": w.id,
                "tenant_id": w.tenant_id,
                "url": w.url,
                "events": json.loads(w.events_json or "[]"),
                "status": w.status,
                "created_at": w.created_at,
                "last_delivery_at": w.last_delivery_at,
                "last_status_code": w.last_status_code,
            }
            for w in webhooks
        ]
    except Exception as exc:
        logger.exception("Unexpected error in list_webhooks")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.delete("/webhooks/{webhook_id}", tags=["webhooks"])
def delete_webhook(webhook_id: str, tenant_id: str):
    """Delete a webhook by ID, scoped to tenant. tenant_id is required."""
    try:
        from ...integrations import WebhookManager
        manager = WebhookManager()
        deleted = manager.delete(webhook_id=webhook_id, tenant_id=tenant_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="Webhook not found")
        return {"deleted": True, "webhook_id": webhook_id}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in delete_webhook")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


# ── Integration test-connectivity ─────────────────────────────────────────────

class TestIntegrationRequest(BaseModel):
    type: str  # "slack" | "pagerduty" | "datadog" | "jira" | "custom_webhook"
    config: dict  # connector-specific fields


@router.post("/integrations/test", tags=["integrations"])
async def test_integration(req: TestIntegrationRequest):
    """Test connectivity for a given integration type and config."""
    t = req.type.lower()
    cfg = req.config
    try:
        if t == "slack":
            from ...integrations.connectors.slack import SlackConnector
            ok = await SlackConnector(
                webhook_url=cfg["webhook_url"],
                channel=cfg.get("channel"),
            ).send("CoreIQ connectivity test", title="Test")
            return {"ok": ok, "type": t}

        elif t == "pagerduty":
            from ...integrations.connectors.pagerduty import PagerDutyConnector
            ok = await PagerDutyConnector(
                routing_key=cfg["routing_key"],
            ).trigger_incident("CoreIQ connectivity test", severity="info", dedup_key="coreiq-test")
            return {"ok": ok, "type": t}

        elif t == "datadog":
            from ...integrations.connectors.datadog import DatadogConnector
            site = cfg.get("site", "datadoghq.com")
            if site not in _ALLOWED_DATADOG_SITES:
                raise HTTPException(status_code=400, detail=f"Invalid Datadog site: {site!r}")
            ok = await DatadogConnector(
                api_key=cfg["api_key"],
                site=site,
            ).send_event("CoreIQ connectivity test", "Test event from CoreIQ", alert_type="info")
            return {"ok": ok, "type": t}

        elif t == "jira":
            from ...integrations.connectors.jira import JiraConnector
            from ...integrations.webhooks import _validate_webhook_url
            base_url = cfg["base_url"]
            try:
                _validate_webhook_url(base_url)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc))
            result = await JiraConnector(
                base_url=base_url,
                email=cfg["email"],
                api_token=cfg["api_token"],
                project_key=cfg["project_key"],
            ).create_issue("CoreIQ connectivity test", "Test issue from CoreIQ", issue_type="Task", priority="Low")
            return {"ok": result is not None, "type": t, "issue": result}

        elif t in ("custom_webhook", "webhook"):
            import httpx
            from ...integrations.webhooks import _validate_webhook_url
            url = cfg.get("url", "")
            if not url:
                raise HTTPException(status_code=400, detail="url is required for custom_webhook")
            try:
                _validate_webhook_url(url)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc))
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(url, json={"event": "test", "source": "coreiq"})
            return {"ok": 200 <= resp.status_code < 300, "type": t, "status_code": resp.status_code}

        else:
            raise HTTPException(status_code=400, detail=f"Unknown integration type: {t!r}. Valid: slack, pagerduty, datadog, jira, custom_webhook")

    except HTTPException:
        raise
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=f"Missing required config field: {exc}")
    except Exception:
        logger.exception("Unexpected error in test_integration")
        return {"ok": False, "type": t}
