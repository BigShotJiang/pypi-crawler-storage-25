"""Agent token minting endpoints."""
from __future__ import annotations
import logging
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from ...identity.agent_tokens import AgentTokenService

logger = logging.getLogger(__name__)
router = APIRouter()

class MintRequest(BaseModel):
    parent_token: str = Field(..., description="Parent API key or token")
    target_service: str = Field(..., description="Target service name")
    scopes: list[str] = Field(default_factory=list, description="Allowed scopes")
    ttl_seconds: int = Field(default=60, ge=1, le=300, description="TTL in seconds (1-300)")

class ValidateRequest(BaseModel):
    token: str

@router.post("/api/agent-tokens", status_code=201)
def mint_agent_token(body: MintRequest):
    """Mint a short-lived scoped token for agent-to-agent calls."""
    svc = AgentTokenService()
    token = svc.mint(body.parent_token, body.target_service, body.scopes, body.ttl_seconds)
    return {"token": token.token, "expires_in_seconds": token.expires_in_seconds, "target_service": token.target_service, "scopes": token.scopes, "agent_chain": token.agent_chain}

@router.post("/api/agent-tokens/validate")
def validate_agent_token(body: ValidateRequest):
    """Validate an agent token."""
    svc = AgentTokenService()
    payload = svc.validate(body.token)
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid or expired agent token")
    return {"valid": True, "payload": payload}
