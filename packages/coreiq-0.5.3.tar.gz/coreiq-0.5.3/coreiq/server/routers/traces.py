from fastapi import APIRouter, Depends, HTTPException, Query, Request
from typing import Optional
import json
from ...store.backends.base import StorageBackend
from ...store.db import get_shared_connection
from ..deps import require_tenant

router = APIRouter(prefix="/api/traces", tags=["traces"])

_DEAD_COLUMNS = {"task_id", "session_id", "span_kind", "parent_span_id", "agent_run_id"}


def _conn() -> StorageBackend:
    return get_shared_connection()


def _clean(row: dict) -> dict:
    return {k: v for k, v in row.items() if k not in _DEAD_COLUMNS}


@router.get("")
def list_traces(
    limit: int = Query(50, le=500),
    offset: int = 0,
    provider: Optional[str] = None,
    cache_hit: Optional[int] = None,
    finish_reason: Optional[str] = None,
    from_ts: Optional[str] = Query(None, alias="from"),
    tenant_id: Optional[str] = Depends(require_tenant),
):
    conn = _conn()
    where, params = [], []
    if tenant_id:
        where.append("tenant_id = ?")
        params.append(tenant_id)
    if provider:
        where.append("provider = ?")
        params.append(provider)
    if cache_hit is not None:
        where.append("cache_hit = ?")
        params.append(cache_hit)
    if finish_reason:
        where.append("finish_reason = ?")
        params.append(finish_reason)
    if from_ts:
        where.append("ts >= ?")
        params.append(from_ts)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT * FROM traces {clause} ORDER BY ts DESC LIMIT ? OFFSET ?",
        params + [limit, offset]
    ).fetchall()
    return [_clean(dict(r)) for r in rows]


@router.get("/{trace_id}")
def get_trace(trace_id: str, tenant_id: Optional[str] = Depends(require_tenant)):
    conn = _conn()
    if tenant_id:
        row = conn.execute("SELECT * FROM traces WHERE id = ? AND tenant_id = ?", (trace_id, tenant_id)).fetchone()
    else:
        row = conn.execute("SELECT * FROM traces WHERE id = ?", (trace_id,)).fetchone()
    if not row:
        from fastapi import HTTPException
        raise HTTPException(404, "Trace not found")
    result = _clean(dict(row))

    # Parse meta_json
    if result.get("meta_json"):
        try:
            result["meta"] = json.loads(result["meta_json"])
        except Exception:
            result["meta"] = {}
    else:
        result["meta"] = {}

    result["tool_calls"] = [dict(r) for r in conn.execute(
        "SELECT * FROM tool_calls WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    result["cache_events"] = [dict(r) for r in conn.execute(
        "SELECT * FROM cache_events WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    result["query_recon"] = [dict(r) for r in conn.execute(
        "SELECT * FROM query_recon WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    # Join feedback linked to this trace
    result["feedback"] = [dict(r) for r in conn.execute(
        "SELECT * FROM feedback WHERE response_id = ?", (trace_id,)
    ).fetchall()]
    return result


@router.get("/{trace_id}/payload")
def get_trace_payload(
    trace_id: str,
    request: Request,
    tenant_id: Optional[str] = Depends(require_tenant),
):
    """Return captured request/response payloads for a trace.

    Requires admin or operator role — viewer and auditor roles receive HTTP 403.
    Payloads are already PII-masked at capture time.
    """
    is_master = getattr(request.state, "is_master", False)
    role = getattr(request.state, "role", "viewer") or "viewer"
    if not is_master and role not in ("admin", "operator"):
        raise HTTPException(
            status_code=403,
            detail="Payload access requires admin or operator role",
        )

    conn = _conn()
    # Verify the trace exists and belongs to the tenant.
    if tenant_id:
        row = conn.execute(
            "SELECT id FROM traces WHERE id = ? AND tenant_id = ?",
            (trace_id, tenant_id),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT id FROM traces WHERE id = ?", (trace_id,)
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Trace not found")

    rows = conn.execute(
        "SELECT direction, content, size_bytes, truncated, ts"
        " FROM trace_payloads WHERE trace_id = ? ORDER BY ts ASC",
        (trace_id,),
    ).fetchall()
    return {
        "trace_id": trace_id,
        "payloads": [dict(r) for r in rows],
    }
