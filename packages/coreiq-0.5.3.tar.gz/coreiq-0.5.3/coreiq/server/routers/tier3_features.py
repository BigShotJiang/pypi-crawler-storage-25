"""Combined API routers for Features 11-17 (Tier 3)."""
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...security.watermark import TextWatermarker
from ...security.multimodal_guard import MultiModalGuard
from ...performance.context_optimizer import ContextOptimizer
from ...governance.bias_monitor import BiasMonitor
from ...governance.compliance_auto import ComplianceAutoGenerator
from ...analytics.federated import FederatedAnalytics
from ...proxy.model_fingerprint import ModelFingerprinter

# ═══ F11: Watermarking ═══
watermark_router = APIRouter(prefix="/api/watermark", tags=["watermark"])
_wm = None
def _get_wm():
    global _wm
    if _wm is None:
        _wm = TextWatermarker()
    return _wm

class WatermarkEmbed(BaseModel):
    text: str
    request_id: str
class WatermarkDetect(BaseModel):
    text: str
    request_id: str

@watermark_router.post("/embed")
def embed(body: WatermarkEmbed):
    return _get_wm().embed(body.text, body.request_id).to_dict()

@watermark_router.post("/detect")
def detect(body: WatermarkDetect):
    return _get_wm().detect(body.text, body.request_id).to_dict()

# ═══ F12: Multi-Modal Guardrails ═══
multimodal_router = APIRouter(prefix="/api/multimodal-guard", tags=["multimodal"])
_mm = None
def _get_mm():
    global _mm
    if _mm is None:
        _mm = MultiModalGuard()
    return _mm

class MultiModalScan(BaseModel):
    messages: List[Dict[str, Any]]

@multimodal_router.post("/scan")
def mm_scan(body: MultiModalScan):
    return _get_mm().scan_messages(body.messages).to_dict()

# ═══ F13: Context Optimizer ═══
ctx_router = APIRouter(prefix="/api/context-optimizer", tags=["context-optimizer"])
_ctx = None
def _get_ctx():
    global _ctx
    if _ctx is None:
        _ctx = ContextOptimizer()
    return _ctx

class CtxOptimize(BaseModel):
    messages: List[Dict[str, Any]]
    token_budget: Optional[int] = None

@ctx_router.post("/optimize")
def ctx_optimize(body: CtxOptimize):
    return _get_ctx().optimize(body.messages, body.token_budget).to_dict()

# ═══ F14: Bias Monitor ═══
bias_router = APIRouter(prefix="/api/bias-monitor", tags=["bias-monitor"])
_bias = None
def _get_bias():
    global _bias
    if _bias is None:
        _bias = BiasMonitor()
    return _bias

class BiasAnalyze(BaseModel):
    texts: List[str]

@bias_router.post("/analyze")
def bias_analyze(body: BiasAnalyze):
    return _get_bias().analyze(body.texts).to_dict()

# ═══ F15: Compliance Auto-Evidence ═══
compliance_auto_router = APIRouter(prefix="/api/compliance-auto", tags=["compliance-auto"])
_comp = None
def _get_comp():
    global _comp
    if _comp is None:
        _comp = ComplianceAutoGenerator()
        _comp.update_state("auth_enabled", True)
        _comp.update_state("auth_mode", "api_key")
        _comp.update_state("audit_enabled", True)
        _comp.update_state("prompt_registry", True)
        _comp.update_state("hitl_enabled", True)
        _comp.update_state("eval_engine", True)
    return _comp

@compliance_auto_router.post("/generate/{framework}")
def generate_compliance(framework: str):
    return _get_comp().generate(framework).to_dict()

@compliance_auto_router.get("/frameworks")
def list_frameworks():
    return ["soc2", "eu_ai_act", "gdpr"]

# ═══ F16: Federated Analytics ═══
fed_router = APIRouter(prefix="/api/federated", tags=["federated"])
_fed = None
def _get_fed():
    global _fed
    if _fed is None:
        _fed = FederatedAnalytics(min_tenants=3)
    return _fed

class FedSubmit(BaseModel):
    tenant_id: str
    metric: str
    value: float

@fed_router.post("/submit")
def fed_submit(body: FedSubmit):
    _get_fed().submit(body.tenant_id, body.metric, body.value)
    return {"submitted": True}

@fed_router.get("/query/{metric}")
def fed_query(metric: str):
    result = _get_fed().query(metric)
    if result is None:
        raise HTTPException(403, "Insufficient tenants for privacy-preserving query (need 3+)")
    return result.to_dict()

@fed_router.get("/metrics")
def fed_metrics():
    return _get_fed().available_metrics()

# ═══ F17: Model Fingerprinting ═══
fp_router = APIRouter(prefix="/api/fingerprint", tags=["fingerprint"])
_fp = None
def _get_fp():
    global _fp
    if _fp is None:
        _fp = ModelFingerprinter()
    return _fp

class FPSample(BaseModel):
    model: str
    response: str
class FPVerify(BaseModel):
    claimed_model: str
    response: str

@fp_router.post("/sample")
def fp_sample(body: FPSample):
    _get_fp().add_sample(body.model, body.response)
    return {"added": True}

@fp_router.post("/verify")
def fp_verify(body: FPVerify):
    return _get_fp().verify(body.claimed_model, body.response).to_dict()

@fp_router.get("/profiles")
def fp_profiles():
    return _get_fp().get_profiles()
