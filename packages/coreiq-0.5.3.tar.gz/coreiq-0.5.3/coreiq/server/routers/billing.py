"""Billing & License API router — license management and quota enforcement."""
from __future__ import annotations

import json
import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/billing", tags=["billing"])


@router.get("/license", tags=["billing"])
def get_license(tenant_id: str):
    """Get the current license for a tenant."""
    try:
        from ...billing import BillingManager
        mgr = BillingManager()
        lic = mgr.get_license(tenant_id=tenant_id)
        if lic is None:
            raise HTTPException(status_code=404, detail=f"No license found for tenant {tenant_id!r}")
        return {
            "id": lic.id,
            "tenant_id": lic.tenant_id,
            "plan": lic.plan,
            "seat_limit": lic.seat_limit,
            "token_quota_monthly": lic.token_quota_monthly,
            "features": json.loads(lic.features_json or "[]"),
            "valid_until": lic.valid_until,
            "created_at": lic.created_at,
        }
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_license")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


class LicenseSetRequest(BaseModel):
    tenant_id: str
    plan: str = "free"
    seat_limit: int = 5
    token_quota_monthly: int = 1_000_000
    features: Optional[List[str]] = None
    valid_until: Optional[str] = None


@router.post("/license", tags=["billing"])
def set_license(req: LicenseSetRequest):
    """Create or update a license for a tenant."""
    try:
        from ...billing import BillingManager
        mgr = BillingManager()
        lic = mgr.set_license(
            tenant_id=req.tenant_id,
            plan=req.plan,
            seat_limit=req.seat_limit,
            token_quota_monthly=req.token_quota_monthly,
            features=req.features,
            valid_until=req.valid_until,
        )
        return {
            "id": lic.id,
            "tenant_id": lic.tenant_id,
            "plan": lic.plan,
            "seat_limit": lic.seat_limit,
            "token_quota_monthly": lic.token_quota_monthly,
            "features": json.loads(lic.features_json or "[]"),
            "valid_until": lic.valid_until,
            "created_at": lic.created_at,
        }
    except Exception as exc:
        logger.exception("Unexpected error in set_license")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/quota", tags=["billing"])
def check_quota(tenant_id: str):
    """Check current token and seat quota usage for a tenant."""
    try:
        from ...billing import BillingManager
        mgr = BillingManager()
        status = mgr.check_quota(tenant_id=tenant_id)
        return {
            "within_quota": status.within_quota,
            "tokens_used": status.tokens_used,
            "tokens_limit": status.tokens_limit,
            "pct_tokens": status.pct_tokens,
            "seats_used": status.seats_used,
            "seats_limit": status.seats_limit,
            "pct_seats": status.pct_seats,
        }
    except Exception as exc:
        logger.exception("Unexpected error in check_quota")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/history", tags=["billing"])
def billing_history(tenant_id: str, limit: int = 12):
    """Get billing history records for a tenant."""
    try:
        from ...billing import BillingManager
        mgr = BillingManager()
        records = mgr.billing_history(tenant_id=tenant_id, limit=limit)
        return [
            {
                "id": r.id,
                "tenant_id": r.tenant_id,
                "period_start": r.period_start,
                "period_end": r.period_end,
                "total_tokens": r.total_tokens,
                "total_cost_usd": r.total_cost_usd,
                "seat_count": r.seat_count,
            }
            for r in records
        ]
    except Exception as exc:
        logger.exception("Unexpected error in billing_history")
        raise HTTPException(status_code=500, detail="Internal server error") from exc
