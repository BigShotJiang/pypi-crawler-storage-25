"""API router for Streaming Guardrails — scan text and simulate streaming cutoff."""
from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel

from ...security.streaming_guard import StreamingGuard, StreamGuardRule, ViolationType

router = APIRouter(prefix="/api/streaming-guard", tags=["streaming-guard"])


class ScanTextRequest(BaseModel):
    text: str
    rules: Optional[List[Dict[str, Any]]] = None


class SimulateStreamRequest(BaseModel):
    tokens: List[str]
    rules: Optional[List[Dict[str, Any]]] = None
    check_interval: int = 3


def _parse_rules(raw: Optional[List[Dict[str, Any]]]) -> Optional[List[StreamGuardRule]]:
    if not raw:
        return None
    from ...governance.guardrails import validate_guardrule_pattern
    rules = []
    for r in raw:
        pattern = r["pattern"]
        validate_guardrule_pattern(pattern)  # raises ValueError on ReDoS/invalid pattern
        rules.append(StreamGuardRule(
            name=r["name"],
            pattern=pattern,
            type=ViolationType(r.get("type", "custom_rule")),
            description=r.get("description", ""),
            action=r.get("action", "block"),
        ))
    return rules


@router.post("/scan")
def scan_text(body: ScanTextRequest):
    """Scan complete text against streaming guard rules."""
    rules = _parse_rules(body.rules)
    guard = StreamingGuard(rules=rules)
    result = guard.scan_complete_text(body.text)
    return result.to_dict()


@router.post("/simulate")
async def simulate_stream(body: SimulateStreamRequest):
    """Simulate a token stream and show where cutoff would happen.

    Accepts a list of token strings, processes them as if streaming,
    and returns the result including any violations and cutoff point.
    """

    rules = _parse_rules(body.rules)
    guard = StreamingGuard(rules=rules, check_interval=body.check_interval)

    async def token_gen():
        for t in body.tokens:
            yield {"text": t}

    output_tokens = []
    cutoff_info = None

    async for chunk in guard.filter_stream(token_gen()):
        if isinstance(chunk, dict) and chunk.get("is_cutoff"):
            cutoff_info = chunk
            output_tokens.append(chunk["text"])
            break
        elif isinstance(chunk, dict):
            output_tokens.append(chunk.get("text", ""))
        else:
            output_tokens.append(str(chunk))

    return {
        "output": "".join(output_tokens),
        "total_tokens_processed": len(output_tokens),
        "was_cut_off": cutoff_info is not None,
        "violation": cutoff_info.get("violation") if cutoff_info else None,
        "guard_result": cutoff_info.get("guard_result") if cutoff_info else None,
    }


@router.get("/rules")
def list_default_rules():
    """List the default streaming guard rules."""
    from ...security.streaming_guard import DEFAULT_STREAM_RULES
    return [
        {
            "name": r.name,
            "pattern": r.pattern,
            "type": r.type.value,
            "description": r.description,
            "action": r.action,
        }
        for r in DEFAULT_STREAM_RULES
    ]
