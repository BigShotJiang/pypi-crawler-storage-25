"""Audit chain verification and export API endpoints."""
import json
import os
import re
from typing import List, Optional

from fastapi import APIRouter, Header, HTTPException, Query

router = APIRouter(prefix="/api/audit", tags=["audit"])

_AUDIT_EXPORT_BASE = os.path.abspath("./audit-exports")


def _safe_audit_path(requested: str) -> str:
    """Validate that the requested path is within the audit export base directory.

    Rejects path traversal attempts and sibling directory attacks (e.g., audit-exports-evil).
    """
    resolved = os.path.abspath(requested)
    # Normalize the base path for consistent comparison
    normalized_base = os.path.abspath(_AUDIT_EXPORT_BASE)
    # Ensure the resolved path starts with the base path AND has a path separator after it
    # (unless it's exactly the base path)
    if not (resolved == normalized_base or resolved.startswith(normalized_base + os.sep)):
        raise HTTPException(status_code=400, detail="Invalid output_path")
    return resolved


@router.get("/verify")
async def verify_chain(
    from_ts: Optional[str] = Query(None, description="ISO timestamp lower bound"),
    to_ts: Optional[str] = Query(None, description="ISO timestamp upper bound"),
):
    """Verify the cryptographic integrity of the audit chain."""
    from ...governance.chained_audit import verify_audit_chain
    result = verify_audit_chain(from_ts=from_ts, to_ts=to_ts)
    return {
        "valid": result.valid,
        "entry_count": result.entry_count,
        "broken_at": result.broken_at,
        "error": result.error,
    }


@router.post("/export")
async def export_audit(
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    output_path: str = "./audit-exports/",
    include_metadata: Optional[List[str]] = None,
):
    """Export a WORM-style compliance evidence package."""
    from ...governance.worm_export import export_audit_package
    safe_path = _safe_audit_path(output_path)
    package = export_audit_package(
        output_path=safe_path,
        from_ts=from_ts,
        to_ts=to_ts,
        include_metadata=include_metadata or [],
    )
    return {
        "package_id": package.package_id,
        "path": package.path,
        "entry_count": package.entry_count,
        "manifest_hash": package.manifest_hash,
        "created_at": package.created_at,
    }


@router.get("/packages")
async def list_audit_packages(
    x_tenant_id: Optional[str] = Header(None),
    limit: int = 50,
    offset: int = 0,
):
    """List previously exported audit packages for the calling tenant."""
    if limit < 1 or limit > 200:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 200")
    if offset < 0:
        raise HTTPException(status_code=400, detail="offset must be >= 0")

    from ...store.db import get_shared_connection
    import json as _json

    tenant_id = "default"  # TODO: resolve from x_tenant_id header
    conn = get_shared_connection()
    rows = conn.fetchall(
        """SELECT id, tenant_id, from_ts, to_ts, entry_count, manifest_hash,
                  compliance_frameworks, storage_type, s3_bucket, s3_key, output_path, created_at
           FROM audit_packages
           WHERE tenant_id = ?
           ORDER BY created_at DESC
           LIMIT ? OFFSET ?""",
        (tenant_id, limit, offset),
    )

    return [
        {
            "package_id": row["id"],
            "tenant_id": row["tenant_id"],
            "from_ts": row["from_ts"],
            "to_ts": row["to_ts"],
            "entry_count": row["entry_count"],
            "manifest_hash": row["manifest_hash"],
            "frameworks": _json.loads(row["compliance_frameworks"]) if row["compliance_frameworks"] else [],
            "storage_type": row["storage_type"],
            "s3_bucket": row["s3_bucket"],
            "s3_key": row["s3_key"],
            "output_path": row["output_path"],
            "created_at": row["created_at"],
        }
        for row in rows
    ]


@router.get("/packages/{package_id}")
async def get_audit_package(package_id: str, x_tenant_id: Optional[str] = Header(None)):
    """Get details of a specific audit package."""
    if not re.match(r"^[0-9a-f-]{36}$", package_id):
        raise HTTPException(status_code=400, detail="Invalid package_id format")

    from ...store.db import get_shared_connection
    import json as _json

    tenant_id = "default"  # TODO: resolve from x_tenant_id header
    conn = get_shared_connection()
    row = conn.fetchone(
        """SELECT id, tenant_id, from_ts, to_ts, entry_count, manifest_hash,
                  compliance_frameworks, storage_type, s3_bucket, s3_key, output_path, created_at
           FROM audit_packages
           WHERE id = ? AND tenant_id = ?""",
        (package_id, tenant_id),
    )

    if not row:
        raise HTTPException(status_code=404, detail="Audit package not found")

    return {
        "package_id": row["id"],
        "tenant_id": row["tenant_id"],
        "from_ts": row["from_ts"],
        "to_ts": row["to_ts"],
        "entry_count": row["entry_count"],
        "manifest_hash": row["manifest_hash"],
        "frameworks": _json.loads(row["compliance_frameworks"]) if row["compliance_frameworks"] else [],
        "storage_type": row["storage_type"],
        "s3_bucket": row["s3_bucket"],
        "s3_key": row["s3_key"],
        "output_path": row["output_path"],
        "created_at": row["created_at"],
    }


@router.get("/packages/{package_id}/download")
async def download_audit_package(
    package_id: str,
    x_tenant_id: Optional[str] = Header(None),
):
    """Return audit package data for download (database-only storage).

    For database packages: returns the actual audit chain and event data.
    Future: for S3 packages, will return presigned URL.
    """
    if not re.match(r"^[0-9a-f-]{36}$", package_id):
        raise HTTPException(status_code=400, detail="Invalid package_id format")

    from ...store.db import get_shared_connection

    tenant_id = "default"  # TODO: resolve from x_tenant_id header
    conn = get_shared_connection()
    row = conn.fetchone(
        """SELECT id, tenant_id, from_ts, to_ts, entry_count, manifest_hash,
                  compliance_frameworks, storage_type, created_at
           FROM audit_packages
           WHERE id = ? AND tenant_id = ?""",
        (package_id, tenant_id),
    )

    if not row:
        raise HTTPException(status_code=404, detail="Audit package not found")

    # Fetch the actual audit chain data for this package
    chain_params = []
    where_clauses = []
    if row["from_ts"]:
        where_clauses.append("ts >= ?")
        chain_params.append(row["from_ts"])
    if row["to_ts"]:
        where_clauses.append("ts <= ?")
        chain_params.append(row["to_ts"])

    chain_where = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

    chain_rows = conn.execute(
        f"SELECT entry_id, event_id, prev_hash, entry_hash, ts FROM audit_chain {chain_where} ORDER BY ts ASC",
        tuple(chain_params),
    ).fetchall()

    # Build an event lookup map
    event_ids = [r["event_id"] for r in chain_rows if r["event_id"]]
    event_map: dict = {}
    if event_ids:
        all_events = conn.execute(
            "SELECT * FROM events ORDER BY ts ASC"
        ).fetchall()
        for ev in all_events:
            eid = ev.get("id") if hasattr(ev, "get") else ev["id"]
            event_map[eid] = ev

    # Build audit chain data
    audit_chain = []
    events = []
    for row in chain_rows:
        audit_chain.append({
            "entry_id": row["entry_id"],
            "event_id": row["event_id"],
            "prev_hash": row["prev_hash"],
            "entry_hash": row["entry_hash"],
            "ts": row["ts"],
        })

        ev = event_map.get(row["event_id"]) if row["event_id"] else None
        if ev:
            _get = (lambda k, d=None: ev.get(k, d)) if ev and hasattr(ev, "get") else (lambda k, d=None: d)
            meta_raw = _get("meta_json")
            events.append({
                "event_id": row["event_id"],
                "level": _get("level"),
                "message": _get("message"),
                "metadata": (json.loads(meta_raw) if isinstance(meta_raw, str) else meta_raw) if meta_raw else None,
                "source": _get("source"),
                "trace_id": _get("trace_id"),
                "ts": row["ts"],
            })

    return {
        "type": "database_export",
        "package_id": row["id"],
        "from_ts": row["from_ts"],
        "to_ts": row["to_ts"],
        "entry_count": row["entry_count"],
        "manifest_hash": row["manifest_hash"],
        "created_at": row["created_at"],
        "audit_chain": audit_chain,
        "events": events,
    }
