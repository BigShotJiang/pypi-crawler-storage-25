"""Incident response API router."""
from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/incidents", tags=["incidents"])


class CreateIncidentRequest(BaseModel):
    tenant_id: str
    title: str
    severity: str = "p3"
    violation_ids: Optional[List[str]] = None


class AcknowledgeRequest(BaseModel):
    assignee: str


class ResolveRequest(BaseModel):
    resolution: str = ""


class CreateEscalationPolicyRequest(BaseModel):
    tenant_id: str
    name: str
    levels: List[dict] = []


def _incident_dict(inc) -> dict:
    import json
    return {
        "id": inc.id,
        "tenant_id": inc.tenant_id,
        "title": inc.title,
        "severity": inc.severity,
        "status": inc.status,
        "violation_ids": json.loads(inc.violation_ids_json),
        "assignee": inc.assignee,
        "escalation_policy_id": inc.escalation_policy_id,
        "timeline": json.loads(inc.timeline_json),
        "breach_notification_required": bool(inc.breach_notification_required),
        "created_at": inc.created_at,
        "resolved_at": inc.resolved_at,
    }


def _policy_dict(ep) -> dict:
    import json
    return {
        "id": ep.id,
        "tenant_id": ep.tenant_id,
        "name": ep.name,
        "levels": json.loads(ep.levels_json),
        "created_at": ep.created_at,
    }


@router.post("")
def create_incident(req: CreateIncidentRequest):
    """Create a new incident."""
    try:
        from ...security.incidents import IncidentManager
        inc = IncidentManager().create(
            tenant_id=req.tenant_id,
            title=req.title,
            severity=req.severity,
            violation_ids=req.violation_ids,
        )
        return _incident_dict(inc)
    except Exception as exc:
        logger.exception("Unexpected error in create_incident")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("")
def list_incidents(
    tenant_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
):
    """List incidents with optional tenant/status filters."""
    try:
        from ...security.incidents import IncidentManager
        incidents = IncidentManager().list(tenant_id=tenant_id, status=status)
        return [_incident_dict(i) for i in incidents]
    except Exception as exc:
        logger.exception("Unexpected error in list_incidents")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/escalation-policies")
def list_escalation_policies(tenant_id: Optional[str] = Query(None)):
    """List escalation policies."""
    try:
        from ...security.incidents import IncidentManager
        policies = IncidentManager().list_escalation_policies(tenant_id=tenant_id)
        return [_policy_dict(p) for p in policies]
    except Exception as exc:
        logger.exception("Unexpected error in list_escalation_policies")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.post("/escalation-policies")
def create_escalation_policy(req: CreateEscalationPolicyRequest):
    """Create an escalation policy."""
    try:
        from ...security.incidents import IncidentManager
        ep = IncidentManager().create_escalation_policy(
            tenant_id=req.tenant_id,
            name=req.name,
            levels=req.levels,
        )
        return _policy_dict(ep)
    except Exception as exc:
        logger.exception("Unexpected error in create_escalation_policy")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/{incident_id}")
def get_incident(incident_id: str):
    """Get an incident by ID."""
    try:
        from ...security.incidents import IncidentManager
        inc = IncidentManager().get(incident_id)
        if inc is None:
            raise HTTPException(status_code=404, detail=f"Incident {incident_id!r} not found")
        return _incident_dict(inc)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_incident")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.post("/{incident_id}/acknowledge")
def acknowledge_incident(incident_id: str, req: AcknowledgeRequest):
    """Acknowledge an incident and assign it."""
    try:
        from ...security.incidents import IncidentManager
        inc = IncidentManager().acknowledge(incident_id, req.assignee)
        if inc is None:
            raise HTTPException(status_code=404, detail=f"Incident {incident_id!r} not found")
        return _incident_dict(inc)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in acknowledge_incident")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.post("/{incident_id}/resolve")
def resolve_incident(incident_id: str, req: ResolveRequest):
    """Resolve an incident."""
    try:
        from ...security.incidents import IncidentManager
        inc = IncidentManager().resolve(incident_id, req.resolution)
        if inc is None:
            raise HTTPException(status_code=404, detail=f"Incident {incident_id!r} not found")
        return _incident_dict(inc)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in resolve_incident")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


# ── Acceptable Use Policy ─────────────────────────────────────────────────────

class CreateAUPRequest(BaseModel):
    tenant_id: str
    content: str


class AcknowledgeAUPRequest(BaseModel):
    policy_id: str
    user_id: str
    ip_address: str = ""


_aup_router = APIRouter(prefix="/api/governance/aup", tags=["governance"])


@_aup_router.post("")
def create_aup(req: CreateAUPRequest):
    """Create or update the Acceptable Use Policy for a tenant."""
    try:
        from ...governance.acceptable_use import AUPManager
        policy = AUPManager().create_policy(req.tenant_id, req.content)
        return {"id": policy.id, "tenant_id": policy.tenant_id, "version": policy.version,
                "active": bool(policy.active), "created_at": policy.created_at}
    except Exception as exc:
        logger.exception("Unexpected error in create_aup")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@_aup_router.get("")
def get_aup(tenant_id: str):
    """Get the active Acceptable Use Policy for a tenant."""
    try:
        from ...governance.acceptable_use import AUPManager
        policy = AUPManager().get_active(tenant_id)
        if not policy:
            raise HTTPException(status_code=404, detail="No active AUP for this tenant")
        return {"id": policy.id, "tenant_id": policy.tenant_id, "version": policy.version,
                "content": policy.content_markdown, "active": bool(policy.active),
                "created_at": policy.created_at}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_aup")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@_aup_router.post("/acknowledge")
def acknowledge_aup(req: AcknowledgeAUPRequest):
    """Record a user's acknowledgment of the AUP."""
    try:
        from ...governance.acceptable_use import AUPManager
        ack = AUPManager().acknowledge(req.policy_id, req.user_id, req.ip_address)
        return {"id": ack.id, "policy_id": ack.policy_id, "user_id": ack.user_id,
                "acknowledged_at": ack.acknowledged_at}
    except Exception as exc:
        logger.exception("Unexpected error in acknowledge_aup")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@_aup_router.get("/status")
def aup_status(tenant_id: str):
    """Get acknowledgment status — how many users have/haven't signed the AUP."""
    try:
        from ...governance.acceptable_use import AUPManager
        return AUPManager().acknowledgment_status(tenant_id)
    except Exception as exc:
        logger.exception("Unexpected error in aup_status")
        raise HTTPException(status_code=500, detail="Internal server error") from exc
