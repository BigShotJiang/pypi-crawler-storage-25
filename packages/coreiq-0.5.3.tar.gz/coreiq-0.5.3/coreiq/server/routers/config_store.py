"""Config/Secrets Store API router — versioned multi-tenant key-value store."""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/config", tags=["config-store"])


class ConfigSetRequest(BaseModel):
    tenant_id: str
    key: str
    value: str
    is_secret: bool = False
    description: Optional[str] = ""
    updated_by: Optional[str] = "system"


@router.post("", tags=["config-store"])
def set_config(req: ConfigSetRequest):
    """Create or update a config/secret entry (creates a new version)."""
    try:
        from ...config_store import ConfigStoreManager
        mgr = ConfigStoreManager()
        entry = mgr.set(
            tenant_id=req.tenant_id,
            key=req.key,
            value=req.value,
            is_secret=req.is_secret,
            description=req.description or "",
            updated_by=req.updated_by or "system",
        )
        return {
            "id": entry.id,
            "tenant_id": entry.tenant_id,
            "key": entry.key,
            "value": "***" if entry.is_secret else entry.value,
            "is_secret": bool(entry.is_secret),
            "description": entry.description,
            "updated_by": entry.updated_by,
            "updated_at": entry.updated_at,
            "version": entry.version,
        }
    except Exception as exc:
        logger.exception("Unexpected error in set_config")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("", tags=["config-store"])
def list_config(tenant_id: str):
    """List all current config entries for a tenant (latest version per key)."""
    try:
        from ...config_store import ConfigStoreManager
        mgr = ConfigStoreManager()
        entries = mgr.list(tenant_id=tenant_id)
        return [
            {
                "id": e.id,
                "key": e.key,
                "value": e.value,  # secrets already masked to "***" by manager
                "is_secret": bool(e.is_secret),
                "description": e.description,
                "updated_by": e.updated_by,
                "updated_at": e.updated_at,
                "version": e.version,
            }
            for e in entries
        ]
    except Exception as exc:
        logger.exception("Unexpected error in list_config")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/{key}", tags=["config-store"])
def get_config(key: str, tenant_id: str):
    """Get the current (latest version) value for a config key."""
    try:
        from ...config_store import ConfigStoreManager
        mgr = ConfigStoreManager()
        entry = mgr.get(tenant_id=tenant_id, key=key)
        if entry is None:
            raise HTTPException(status_code=404, detail=f"Config key {key!r} not found")
        return {
            "id": entry.id,
            "key": entry.key,
            "value": entry.value,
            "is_secret": bool(entry.is_secret),
            "description": entry.description,
            "updated_by": entry.updated_by,
            "updated_at": entry.updated_at,
            "version": entry.version,
        }
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in get_config")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/{key}/history", tags=["config-store"])
def get_config_history(key: str, tenant_id: str):
    """Get the full version history for a config key."""
    try:
        from ...config_store import ConfigStoreManager
        mgr = ConfigStoreManager()
        entries = mgr.history(tenant_id=tenant_id, key=key)
        return [
            {
                "id": e.id,
                "key": e.key,
                "value": "***" if e.is_secret else e.value,
                "is_secret": bool(e.is_secret),
                "description": e.description,
                "updated_by": e.updated_by,
                "updated_at": e.updated_at,
                "version": e.version,
            }
            for e in entries
        ]
    except Exception as exc:
        logger.exception("Unexpected error in get_config_history")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.delete("/{key}", tags=["config-store"])
def delete_config(key: str, tenant_id: str):
    """Delete all versions of a config key for a tenant."""
    try:
        from ...config_store import ConfigStoreManager
        mgr = ConfigStoreManager()
        deleted = mgr.delete(tenant_id=tenant_id, key=key)
        if not deleted:
            raise HTTPException(status_code=404, detail=f"Config key {key!r} not found")
        return {"deleted": True, "key": key, "tenant_id": tenant_id}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in delete_config")
        raise HTTPException(status_code=500, detail="Internal server error") from exc
