"""FastAPI router for security violations and posture scoring.

All endpoints require the master API key (``COREIQ_API_KEY``) for
authentication — enforced by ``auth_middleware`` in ``server/app.py``.

Endpoints:
    GET /api/security/violations          — list violations with filters
    GET /api/security/violations/summary  — aggregate counts by category/severity
    GET /api/security/posture             — current posture score
    GET /api/security/posture/trend       — daily posture trend
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Query

from ...security.violations import get_violation_recorder
from ...security.posture import get_posture_engine
from ...governance.posture import compute_posture, compute_trend

router = APIRouter(prefix="/api/security", tags=["security"])


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/violations")
def list_violations(
    tenant_id: Optional[str] = None,
    category: Optional[str] = None,
    severity: Optional[str] = None,
    from_ts: Optional[str] = Query(None, alias="from"),
    to_ts: Optional[str] = Query(None, alias="to"),
    limit: int = Query(100, le=1000),
    offset: int = 0,
):
    """List security violations with optional filters."""
    recorder = get_violation_recorder()
    violations = recorder.query(
        tenant_id=tenant_id,
        category=category,
        severity=severity,
        from_ts=from_ts,
        to_ts=to_ts,
        limit=limit,
        offset=offset,
    )
    return [
        {
            "id": v.id,
            "tenant_id": v.tenant_id,
            "category": v.category,
            "severity": v.severity,
            "trace_id": v.trace_id,
            "message": v.message,
            "details_json": v.details_json,
            "action_taken": v.action_taken,
            "ts": v.ts,
        }
        for v in violations
    ]


@router.get("/violations/summary")
def violations_summary(tenant_id: Optional[str] = None):
    """Aggregate violation counts grouped by category and severity."""
    recorder = get_violation_recorder()
    return recorder.summary(tenant_id=tenant_id)


@router.get("/posture")
def security_posture(
    tenant_id: Optional[str] = None,
    window_days: int = Query(14, ge=1, le=365),
):
    """Calculate the cyberpod-aligned posture score (0-100, 6 components).

    Delegates to :func:`coreiq.governance.posture.compute_posture`.

    Also surfaces the legacy 4-component score from
    :mod:`coreiq.security.posture` under ``legacy`` so older dashboards
    that consumed ``overall`` / ``open_risks`` keep working until they
    migrate.
    """
    result = compute_posture(tenant_id=tenant_id, window_days=window_days)
    payload = result.to_dict()
    # Keep legacy keys for dashboards still reading the old shape.
    payload["overall"] = result.score
    try:
        legacy = get_posture_engine().calculate_score(
            tenant_id=tenant_id, hours=window_days * 24
        )
        payload["open_risks"] = legacy.open_risks
    except Exception:
        payload["open_risks"] = []
    return payload


@router.get("/posture/trend")
def posture_trend(
    tenant_id: Optional[str] = None,
    days: int = Query(14, ge=1, le=365),
):
    """Return a deterministic daily posture score trend for ``days`` days."""
    return compute_trend(tenant_id=tenant_id, days=days)
