"""Datasets API router — create, list, and manage eval datasets."""
from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/datasets", tags=["datasets"])


class DatasetCreateRequest(BaseModel):
    name: str
    description: str = ""
    min_score: float = 0.7
    dimension: str = "faithfulness"
    limit: int = 100
    version: int = 1


class DatasetItemRequest(BaseModel):
    input_text: str
    output_text: str
    trace_id: Optional[str] = None
    reference_output: Optional[str] = None
    labels: dict = {}
    quality_score: Optional[float] = None


@router.post("/")
def create_dataset(req: DatasetCreateRequest):
    """Build a dataset from high-quality production traces."""
    from ...evolution.dataset import DatasetBuilder
    builder = DatasetBuilder(name=req.name, description=req.description)
    added = builder.add_from_traces(
        min_score=req.min_score,
        dimension=req.dimension,
        limit=req.limit,
    )
    dataset = builder.build(version=req.version)
    return {
        "id": dataset.id,
        "name": dataset.name,
        "version": dataset.version,
        "size": dataset.size,
        "items_added": added,
        "created_at": dataset.created_at,
    }


@router.get("/")
def list_datasets():
    """List all datasets."""
    conn = get_shared_connection()
    rows = conn.execute(
        "SELECT * FROM eval_datasets ORDER BY name, version DESC"
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/{dataset_name}")
def get_dataset(dataset_name: str, version: Optional[int] = None):
    """Get a specific dataset (latest version if version not specified)."""
    conn = get_shared_connection()
    if version is not None:
        row = conn.execute(
            "SELECT * FROM eval_datasets WHERE name = ? AND version = ?",
            (dataset_name, version),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM eval_datasets WHERE name = ? ORDER BY version DESC LIMIT 1",
            (dataset_name,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Dataset {dataset_name!r} not found")
    dataset = dict(row)

    # Load items
    items = conn.execute(
        "SELECT * FROM dataset_items WHERE dataset_id = ? ORDER BY created_at",
        (dataset["id"],),
    ).fetchall()
    dataset["items"] = [dict(i) for i in items]
    return dataset


@router.post("/{dataset_name}/items")
def add_dataset_item(dataset_name: str, req: DatasetItemRequest, version: Optional[int] = None):
    """Manually add an item to a dataset."""
    conn = get_shared_connection()
    if version is not None:
        row = conn.execute(
            "SELECT id FROM eval_datasets WHERE name = ? AND version = ?",
            (dataset_name, version),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT id FROM eval_datasets WHERE name = ? ORDER BY version DESC LIMIT 1",
            (dataset_name,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Dataset {dataset_name!r} not found")

    import json
    import uuid
    from datetime import datetime, timezone

    # Fetch full dataset row to update the size counter (re-insert for ClickHouse compat)
    ds_row = conn.execute("SELECT * FROM eval_datasets WHERE id = ?", (row["id"],)).fetchone()

    item_id = str(uuid.uuid4())
    conn.execute(
        """INSERT INTO dataset_items
           (id, dataset_id, trace_id, input_text, output_text, reference_output,
            labels_json, quality_score, source, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (
            item_id, row["id"], req.trace_id, req.input_text, req.output_text,
            req.reference_output, json.dumps(req.labels), req.quality_score,
            "manual", datetime.now(timezone.utc).isoformat(),
        ),
    )
    # Re-insert with incremented size (ClickHouse ReplacingMergeTree deduplicates on FINAL reads)
    if ds_row:
        new_size = (ds_row["size"] or 0) + 1
        conn.execute(
            """INSERT INTO eval_datasets (id, name, version, description, size, metadata_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (ds_row["id"], ds_row["name"], ds_row["version"], ds_row["description"],
             new_size, ds_row["metadata_json"], ds_row["created_at"]),
        )
    conn.commit()
    return {"id": item_id, "dataset_id": row["id"]}


@router.post("/{dataset_name}/gate")
def run_eval_gate(dataset_name: str, gates: List[str], version: Optional[int] = None):
    """Run eval gates against a dataset. Returns pass/fail result.

    gates: list of expressions like ["faithfulness>=0.85", "toxicity<=0.10"]
    """
    from ...evolution.ci_gate import EvalGate, _parse_gate_expr
    gate = EvalGate(dataset_name=dataset_name, dataset_version=version)
    for expr in gates:
        try:
            t = _parse_gate_expr(expr)
            gate.add_threshold(t.dimension, t.min_score, t.max_score)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    result = gate.run()
    return {
        "dataset": result.dataset_name,
        "passed": result.passed,
        "scores": result.scores,
        "failures": result.failures,
        "report": result.report,
    }
