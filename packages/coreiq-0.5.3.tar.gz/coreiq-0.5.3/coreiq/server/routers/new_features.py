"""Combined API routers for Features 6-10: Regression, DLP, Canary Deploy, Red Team, Replay."""
import json as _json
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...evolution.regression import RegressionTester
from ...security.dlp import DLPEngine
from ...proxy.canary_deploy import CanaryDeploymentEngine
from ...security.red_team import RedTeamEngine

# ═══════════════════════════════════════════════════════════════════════════════
# Feature 6: Semantic Regression Testing
# ═══════════════════════════════════════════════════════════════════════════════

regression_router = APIRouter(prefix="/api/regression", tags=["regression"])

_regression: Optional[RegressionTester] = None
def _get_regression():
    global _regression
    if _regression is None:
        _regression = RegressionTester()
    return _regression

class BaselineAdd(BaseModel):
    version: str
    input_text: str
    output_text: str
    scores: Optional[Dict[str, float]] = None

class CompareVersions(BaseModel):
    old_version: str
    new_version: str
    new_scores: Optional[Dict[str, List[float]]] = None
    threshold: float = 0.05

@regression_router.post("/baselines")
def add_baseline(body: BaselineAdd):
    _get_regression().add_baseline(body.version, body.input_text, body.output_text, body.scores)
    return {"added": True, "version": body.version}

@regression_router.get("/baselines/{version}")
def get_baselines(version: str):
    samples = _get_regression().get_baselines(version)
    return [{"input": s.input_text, "output": s.output_text, "scores": s.scores} for s in samples]

@regression_router.post("/compare")
def compare_versions(body: CompareVersions):
    result = _get_regression().compare_versions(body.old_version, body.new_version, body.new_scores, body.threshold)
    return result.to_dict()


# ═══════════════════════════════════════════════════════════════════════════════
# Feature 7: DLP for AI
# ═══════════════════════════════════════════════════════════════════════════════

dlp_router = APIRouter(prefix="/api/dlp", tags=["dlp"])

_dlp: Optional[DLPEngine] = None
def _get_dlp():
    global _dlp
    if _dlp is None:
        _dlp = DLPEngine()
    return _dlp

class DLPScan(BaseModel):
    text: str

class DLPScanMessages(BaseModel):
    messages: List[Dict[str, Any]]

@dlp_router.post("/scan")
def dlp_scan(body: DLPScan):
    return _get_dlp().scan(body.text).to_dict()

@dlp_router.post("/scan/messages")
def dlp_scan_messages(body: DLPScanMessages):
    return _get_dlp().scan_messages(body.messages).to_dict()

@dlp_router.get("/rules")
def dlp_rules():
    from ...security.dlp import DEFAULT_DLP_RULES
    return [{"name": r.name, "category": r.category.value, "action": r.action.value, "description": r.description} for r in DEFAULT_DLP_RULES]


# ═══════════════════════════════════════════════════════════════════════════════
# Feature 8: Canary Deployments for Models
# ═══════════════════════════════════════════════════════════════════════════════

canary_router = APIRouter(prefix="/api/canary-deploy", tags=["canary-deploy"])

_canary: Optional[CanaryDeploymentEngine] = None
def _get_canary():
    global _canary
    if _canary is None:
        _canary = CanaryDeploymentEngine()
    return _canary

class CanaryCreate(BaseModel):
    current_model: str
    candidate_model: str
    traffic_pct: float = 5
    eval_metrics: List[str] = ["quality_score"]
    promote_threshold: Dict[str, float] = {"quality_score": 0.95}
    rollback_threshold: Dict[str, float] = {"quality_score": 0.80}
    duration_hours: int = 48

class CanaryRoute(BaseModel):
    context_key: str = ""

class CanaryScore(BaseModel):
    model: str
    metric: str
    score: float

@canary_router.post("")
def create_canary(body: CanaryCreate):
    dep = _get_canary().create(body.current_model, body.candidate_model, body.traffic_pct,
        body.eval_metrics, body.promote_threshold, body.rollback_threshold, body.duration_hours)
    return dep.to_dict()

@canary_router.get("")
def list_canary():
    return _get_canary().list_active()

@canary_router.get("/{dep_id}")
def get_canary(dep_id: str):
    d = _get_canary().get(dep_id)
    if not d:
        raise HTTPException(404, "Not found")
    return d.to_dict()

@canary_router.post("/{dep_id}/route")
def route_canary(dep_id: str, body: CanaryRoute):
    model = _get_canary().route(dep_id, body.context_key)
    return {"model": model}

@canary_router.post("/{dep_id}/score")
def score_canary(dep_id: str, body: CanaryScore):
    _get_canary().record_score(dep_id, body.model, body.metric, body.score)
    return {"recorded": True}

@canary_router.post("/{dep_id}/evaluate")
def evaluate_canary(dep_id: str):
    return _get_canary().evaluate(dep_id)


# ═══════════════════════════════════════════════════════════════════════════════
# Feature 9: Red Team Automation
# ═══════════════════════════════════════════════════════════════════════════════

redteam_router = APIRouter(prefix="/api/red-team", tags=["red-team"])

_redteam: Optional[RedTeamEngine] = None
def _get_redteam():
    global _redteam
    if _redteam is None:
        _redteam = RedTeamEngine()
    return _redteam

class RedTeamScan(BaseModel):
    categories: Optional[List[str]] = None
    intensity: str = "standard"

@redteam_router.get("/attacks")
def list_attacks():
    return _get_redteam().get_attack_library()

@redteam_router.post("/scan")
def run_red_team(body: RedTeamScan):
    """Run red team scan using the AI Firewall as the target."""
    from ...security.firewall import AIFirewall
    fw = AIFirewall()
    def scan_fn(prompt: str) -> Dict[str, Any]:
        verdict = fw.scan(prompt)
        return {"blocked": verdict.blocked, "response": verdict.details or "allowed"}
    report = _get_redteam().run_scan(scan_fn, body.categories, body.intensity)
    return report.to_dict()


# ═══════════════════════════════════════════════════════════════════════════════
# Feature 10: Replay & Debug
# ═══════════════════════════════════════════════════════════════════════════════

replay_router = APIRouter(prefix="/api/replay", tags=["replay"])


def _db():
    from ...store.db import get_shared_connection
    return get_shared_connection()


def _safe_get(row, key, default=None):
    """Row field access that never raises KeyError (handles MongoRow + sqlite3.Row)."""
    try:
        return row[key]
    except (KeyError, IndexError):
        return default


def _row_to_replay(row) -> Dict[str, Any]:
    meta = {}
    try:
        raw = _safe_get(row, "meta_json")
        if raw:
            meta = _json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        pass
    response_preview = meta.get("response", "") or ""
    return {
        "trace_id": _safe_get(row, "id", ""),
        "model": _safe_get(row, "model") or "",
        "provider": _safe_get(row, "provider") or "",
        "messages": meta.get("messages", []),
        "response_preview": response_preview[:200] + "..." if len(response_preview) > 200 else response_preview,
        "tokens": (_safe_get(row, "input_tok") or 0) + (_safe_get(row, "output_tok") or 0),
        "input_tok": _safe_get(row, "input_tok") or 0,
        "output_tok": _safe_get(row, "output_tok") or 0,
        "cost": round(_safe_get(row, "cost_usd") or 0.0, 6),
        "latency_ms": _safe_get(row, "latency_ms") or 0,
        "finish_reason": _safe_get(row, "finish_reason") or "",
        "ts": _safe_get(row, "ts") or "",
    }


class ReplayRequest(BaseModel):
    model: Optional[str] = None


@replay_router.get("/traces")
def list_traces(limit: int = 50, tenant_id: str = ""):
    limit = max(1, min(int(limit), 500))
    if tenant_id:
        rows = _db().execute(
            "SELECT id,model,provider,input_tok,output_tok,latency_ms,finish_reason,cost_usd,meta_json,ts "
            "FROM traces WHERE tenant_id=? ORDER BY ts DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
    else:
        rows = _db().execute(
            "SELECT id,model,provider,input_tok,output_tok,latency_ms,finish_reason,cost_usd,meta_json,ts "
            "FROM traces ORDER BY ts DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [_row_to_replay(r) for r in rows]


@replay_router.get("/traces/{trace_id}")
def get_trace(trace_id: str, tenant_id: str = ""):
    if tenant_id:
        row = _db().execute(
            "SELECT id,model,provider,input_tok,output_tok,latency_ms,finish_reason,cost_usd,meta_json,ts "
            "FROM traces WHERE id=? AND tenant_id=?",
            (trace_id, tenant_id),
        ).fetchone()
    else:
        row = _db().execute(
            "SELECT id,model,provider,input_tok,output_tok,latency_ms,finish_reason,cost_usd,meta_json,ts "
            "FROM traces WHERE id=?",
            (trace_id,),
        ).fetchone()
    if not row:
        raise HTTPException(404, "Trace not found")
    return _row_to_replay(row)


@replay_router.post("/traces/{trace_id}/replay")
def replay_trace(trace_id: str, body: ReplayRequest, tenant_id: str = ""):
    if tenant_id:
        row = _db().execute(
            "SELECT id,model,provider,input_tok,output_tok,latency_ms,finish_reason,cost_usd,meta_json,ts "
            "FROM traces WHERE id=? AND tenant_id=?",
            (trace_id, tenant_id),
        ).fetchone()
    else:
        row = _db().execute(
            "SELECT id,model,provider,input_tok,output_tok,latency_ms,finish_reason,cost_usd,meta_json,ts "
            "FROM traces WHERE id=?",
            (trace_id,),
        ).fetchone()
    if not row:
        raise HTTPException(404, f"Trace '{trace_id}' not found")

    meta = {}
    try:
        raw = row["meta_json"]
        if raw:
            meta = _json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        pass

    original_model = row["model"] or ""
    replay_model = body.model or original_model
    original_response = meta.get("response", "")
    messages = meta.get("messages", [])

    return {
        "original_trace_id": trace_id,
        "original_model": original_model,
        "replay_model": replay_model,
        "messages": messages,
        "original_response_preview": original_response[:200] + "..." if len(original_response) > 200 else original_response,
        "replay_response": f"[dry-run] Would replay {len(messages)} messages with model={replay_model}",
        "original_cost": round(row["cost_usd"] or 0.0, 6),
        "original_latency_ms": row["latency_ms"] or 0,
        "note": "Dry-run only. Connect a live LLM call to replay_fn for actual re-execution.",
    }
