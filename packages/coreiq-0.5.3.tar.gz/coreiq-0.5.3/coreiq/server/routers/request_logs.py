"""FastAPI router for enhanced request logs.

All endpoints require the master API key (``COREIQ_API_KEY``) for
authentication — enforced by ``auth_middleware`` in ``server/app.py``.

Endpoints:
    GET /api/request-logs          — list traces with enriched filters
    GET /api/request-logs/export   — CSV export of last 1000 traces
    GET /api/request-logs/{trace_id} — trace detail + associated violations
"""

from __future__ import annotations

import csv
import io
import json
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse

from ...store.backends.base import StorageBackend
from ...store.db import get_shared_connection
from ..deps import require_tenant

router = APIRouter(prefix="/api/request-logs", tags=["request-logs"])


def _conn() -> StorageBackend:
    return get_shared_connection()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_meta(row: dict) -> dict:
    """Expand meta_json into a 'meta' key and return the updated dict."""
    if row.get("meta_json"):
        try:
            row["meta"] = json.loads(row["meta_json"])
        except Exception:
            row["meta"] = {}
    else:
        row["meta"] = {}
    return row


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/export")
def export_request_logs():
    """Export the last 1000 traces as CSV.

    Returns a plain-text response with a ``Content-Disposition`` header so
    browsers will prompt a file download.
    """
    conn = _conn()
    rows = conn.execute(
        "SELECT id, model, provider, input_tok, output_tok, latency_ms, "
        "finish_reason, cache_hit, ts, tenant_id, virtual_key_id "
        "FROM traces ORDER BY ts DESC LIMIT 1000"
    ).fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    # Header
    writer.writerow([
        "id", "model", "provider", "input_tok", "output_tok",
        "latency_ms", "finish_reason", "cache_hit", "ts",
        "tenant_id", "virtual_key_id",
    ])
    for r in rows:
        writer.writerow([
            r["id"], r["model"], r["provider"], r["input_tok"],
            r["output_tok"], r["latency_ms"], r["finish_reason"],
            r["cache_hit"], r["ts"], r["tenant_id"], r["virtual_key_id"],
        ])

    csv_content = output.getvalue()
    return PlainTextResponse(
        content=csv_content,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=request_logs.csv"},
    )


@router.get("")
def list_request_logs(
    status: Optional[str] = Query(
        None,
        description="Filter by security status: 'triggered' (has violations), "
                    "'blocked' (error + violation), 'clean' (no violations)",
    ),
    from_ts: Optional[str] = Query(None, alias="from"),
    to_ts: Optional[str] = Query(None, alias="to"),
    provider: Optional[str] = None,
    model: Optional[str] = None,
    tenant_id: Optional[str] = Depends(require_tenant),
    limit: int = Query(50, le=500),
    offset: int = 0,
):
    """List request traces with enriched security-status filters.

    ``status`` values:
    - ``triggered`` — traces that have at least one security violation
    - ``blocked``   — traces with ``finish_reason='error'`` AND a violation
    - ``clean``     — traces with no associated violations
    """
    conn = _conn()
    where, params = [], []

    if from_ts:
        where.append("t.ts >= ?")
        params.append(from_ts)
    if to_ts:
        where.append("t.ts <= ?")
        params.append(to_ts)
    if provider:
        where.append("t.provider = ?")
        params.append(provider)
    if model:
        where.append("t.model = ?")
        params.append(model)
    if tenant_id:
        where.append("t.tenant_id = ?")
        params.append(tenant_id)

    # Security status filter via subquery
    if status == "triggered":
        where.append("EXISTS (SELECT 1 FROM security_violations sv WHERE sv.trace_id = t.id)")
    elif status == "blocked":
        where.append("t.finish_reason = 'error'")
        where.append("EXISTS (SELECT 1 FROM security_violations sv WHERE sv.trace_id = t.id)")
    elif status == "clean":
        where.append("NOT EXISTS (SELECT 1 FROM security_violations sv WHERE sv.trace_id = t.id)")

    clause = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT t.* FROM traces t {clause} ORDER BY t.ts DESC LIMIT ? OFFSET ?",
        params + [limit, offset]
    ).fetchall()

    result = []
    for r in rows:
        row = _parse_meta(dict(r))
        # Attach violation count for quick reference
        viol_count = conn.execute(
            "SELECT COUNT(*) as n FROM security_violations WHERE trace_id = ?",
            (row["id"],)
        ).fetchone()
        row["violation_count"] = viol_count["n"] if viol_count else 0
        result.append(row)

    return result


@router.get("/{trace_id}")
def get_request_log(trace_id: str):
    """Get a single trace with full detail and any associated security violations."""
    conn = _conn()
    row = conn.execute("SELECT * FROM traces WHERE id = ?", (trace_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Trace not found")

    result = _parse_meta(dict(row))

    # Related data
    result["tool_calls"] = [dict(r) for r in conn.execute(
        "SELECT * FROM tool_calls WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    result["cache_events"] = [dict(r) for r in conn.execute(
        "SELECT * FROM cache_events WHERE trace_id = ?", (trace_id,)
    ).fetchall()]
    result["feedback"] = [dict(r) for r in conn.execute(
        "SELECT * FROM feedback WHERE response_id = ?", (trace_id,)
    ).fetchall()]

    # Security violations associated with this trace
    violations = conn.execute(
        "SELECT * FROM security_violations WHERE trace_id = ? ORDER BY ts DESC",
        (trace_id,)
    ).fetchall()
    result["security_violations"] = [dict(v) for v in violations]

    return result
