"""Governance API router — compliance evidence export, policy management."""
from __future__ import annotations

import logging
import os
from typing import List, Optional

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/governance", tags=["governance"])


# ── Helpers ───────────────────────────────────────────────────────────────────

def _tenant_from_header(x_tenant_id: Optional[str]) -> str:
    return x_tenant_id or "default"


class ComplianceExportRequest(BaseModel):
    frameworks: List[str]  # e.g. ["soc2_type2", "eu_ai_act_art12"]
    period_start: str      # ISO-8601 date string
    period_end: str        # ISO-8601 date string
    output_path: str = "./compliance-packages/"
    sign: bool = True


class ComplianceCoverageItem(BaseModel):
    control_id: str
    control_name: str
    framework: str
    status: str


class ComplianceExportResponse(BaseModel):
    package_id: str
    output_path: str
    period_start: str
    period_end: str
    frameworks: List[str]
    coverage_report: dict
    gap_count: int
    manifest_hash: str
    generated_at: str
    storage_type: str = "filesystem"
    s3_bucket: Optional[str] = None
    s3_key: Optional[str] = None


class CompliancePackageRecord(BaseModel):
    package_id: str
    tenant_id: str
    frameworks: List[str]
    period_start: str
    period_end: str
    manifest_hash: str
    storage_type: str
    s3_bucket: Optional[str]
    s3_key: Optional[str]
    output_path: Optional[str]
    gap_count: int
    control_count: int
    generated_at: str


_COMPLIANCE_BASE_DIR = os.path.abspath("./compliance-packages")


def _safe_output_path(requested: str) -> str:
    """Resolve output_path and ensure it stays within the allowed base directory.

    Uses an explicit separator check to prevent traversal via paths like
    /compliance-packages-evil that share a common prefix with the base dir.
    """
    resolved = os.path.abspath(requested)
    base = _COMPLIANCE_BASE_DIR
    if resolved != base and not resolved.startswith(base + os.sep):
        raise HTTPException(status_code=400, detail="Invalid output_path")
    return resolved


def _parse_iso_date(value: str, field: str) -> str:
    """Validate that value is a parseable ISO-8601 date/datetime string."""
    from datetime import datetime
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail=f"Invalid {field}: must be ISO-8601")
    return value


@router.post("/compliance/export-legacy", response_model=ComplianceExportResponse)
async def export_compliance_legacy(
    req: ComplianceExportRequest,
    x_tenant_id: Optional[str] = Header(None),
):
    """Legacy compliance export path (SOC 2 CC6/CC7, EU AI Act Art 12, GDPR Art 30).

    Kept for backward compat. New callers should use the plugin-based
    ``POST /api/governance/compliance/export`` endpoint below.
    """
    try:
        from ...governance.compliance import ComplianceFramework, export_compliance_package

        if not req.frameworks:
            raise HTTPException(status_code=400, detail="frameworks must not be empty")

        _parse_iso_date(req.period_start, "period_start")
        _parse_iso_date(req.period_end, "period_end")

        fw_map = {f.value: f for f in ComplianceFramework}
        frameworks = []
        for fw_str in req.frameworks:
            fw = fw_map.get(fw_str.lower())
            if fw is None:
                raise HTTPException(
                    status_code=400,
                    detail=f"Unknown framework: {fw_str!r}",
                )
            frameworks.append(fw)

        safe_path = _safe_output_path(req.output_path)
        tenant_id = _tenant_from_header(x_tenant_id)
        package = export_compliance_package(
            frameworks=frameworks,
            period_start=req.period_start,
            period_end=req.period_end,
            output_path=safe_path,
            sign=req.sign,
            tenant_id=tenant_id,
        )
        return ComplianceExportResponse(
            package_id=package.package_id,
            output_path=package.output_path,
            period_start=package.period_start,
            period_end=package.period_end,
            frameworks=package.frameworks,
            coverage_report=package.coverage_report,
            gap_count=package.gap_count,
            manifest_hash=package.manifest_hash,
            generated_at=package.generated_at,
            storage_type=package.storage_type,
            s3_bucket=package.s3_bucket,
            s3_key=package.s3_key,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Unexpected error in export_compliance")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/compliance/packages", response_model=List[CompliancePackageRecord])
async def list_compliance_packages(
    x_tenant_id: Optional[str] = Header(None),
    limit: int = 50,
    offset: int = 0,
):
    """List previously exported compliance packages for the calling tenant."""
    if limit < 1 or limit > 200:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 200")
    if offset < 0:
        raise HTTPException(status_code=400, detail="offset must be >= 0")

    try:
        from ...store.db import get_shared_connection
        import json as _json

        tenant_id = _tenant_from_header(x_tenant_id)
        conn = get_shared_connection()
        rows = conn.fetchall(
            """SELECT id, tenant_id, frameworks, period_start, period_end, manifest_hash,
                      storage_type, s3_bucket, s3_key, output_path, gap_count, control_count, generated_at
               FROM compliance_packages
               WHERE tenant_id = ?
               ORDER BY generated_at DESC
               LIMIT ? OFFSET ?""",
            (tenant_id, limit, offset),
        )
        return [
            CompliancePackageRecord(
                package_id=row["id"],
                tenant_id=row["tenant_id"],
                frameworks=_json.loads(row["frameworks"]),
                period_start=row["period_start"],
                period_end=row["period_end"],
                manifest_hash=row["manifest_hash"],
                storage_type=row["storage_type"],
                s3_bucket=row["s3_bucket"],
                s3_key=row["s3_key"],
                output_path=row["output_path"],
                gap_count=row["gap_count"],
                control_count=row["control_count"],
                generated_at=row["generated_at"],
            )
            for row in (rows or [])
        ]
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Error listing compliance packages")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


@router.get("/compliance/packages/{package_id}/download")
async def download_compliance_package(
    package_id: str,
    x_tenant_id: Optional[str] = Header(None),
    expires_in: int = 3600,
):
    """Return a download URL for a compliance package.

    For S3 WORM packages: returns a presigned URL (valid for ``expires_in`` seconds).
    For filesystem packages: returns the absolute server-side path (suitable for
    internal tooling / admin use — do not expose this directly to end users).
    """
    import re
    if not re.fullmatch(r"[0-9a-f]{32}", package_id):
        raise HTTPException(status_code=400, detail="Invalid package_id")
    if expires_in < 60 or expires_in > 86400:
        raise HTTPException(status_code=400, detail="expires_in must be between 60 and 86400")

    try:
        from ...store.db import get_shared_connection
        from ...governance.compliance import generate_s3_presigned_url

        tenant_id = _tenant_from_header(x_tenant_id)
        conn = get_shared_connection()
        row = conn.fetchone(
            "SELECT * FROM compliance_packages WHERE id = ? AND tenant_id = ?",
            (package_id, tenant_id),
        )
        if row is None:
            raise HTTPException(status_code=404, detail="Package not found")

        if row["storage_type"] == "s3_worm" and row["s3_bucket"] and row["s3_key"]:
            region = os.environ.get("COREIQ_COMPLIANCE_S3_REGION") or os.environ.get("AWS_REGION")
            url = generate_s3_presigned_url(
                row["s3_bucket"], row["s3_key"],
                expires_in=expires_in,
                region=region,
            )
            return {"type": "presigned_url", "url": url, "expires_in": expires_in}

        # Filesystem fallback — validate path is still within the allowed base dir
        local_path = row["output_path"] or ""
        safe_base = os.environ.get("COREIQ_COMPLIANCE_DIR", str(_COMPLIANCE_BASE_DIR))
        safe_base_resolved = os.path.abspath(safe_base)
        resolved = os.path.abspath(local_path)
        if not (resolved == safe_base_resolved or resolved.startswith(safe_base_resolved + os.sep)):
            raise HTTPException(status_code=500, detail="Package path is outside allowed directory")
        if not os.path.exists(resolved):
            raise HTTPException(status_code=404, detail="Package file not found on disk")
        return {"type": "local_path", "path": resolved}

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Error generating compliance package download")
        raise HTTPException(status_code=500, detail="Internal server error") from exc


# ── Plugin-based compliance framework system (B2) ────────────────────────────

class ComplianceOverrideRequest(BaseModel):
    control_id: str
    status: str  # pass | warn | fail | not_applicable
    notes: str = ""
    evidence: Optional[dict] = None
    set_by: Optional[str] = None
    expires_at: Optional[str] = None


class CompliancePluginExportRequest(BaseModel):
    framework_id: str
    tenant_id: Optional[str] = None


def _results_for_tenant(tenant_id: str, force: bool = False) -> dict:
    from ...governance.frameworks.cache import compute_all
    return compute_all(tenant_id, force=force)


@router.get("/compliance/frameworks")
def list_frameworks() -> list:
    """List every registered compliance framework (12 builtin + any plugins)."""
    from ...governance.frameworks import REGISTRY
    return [
        {
            "id": fw.id,
            "name": fw.name,
            "version": fw.version,
            "regulator": fw.regulator,
            "url": fw.url,
            "control_count": len(fw.controls),
        }
        for fw in REGISTRY.all()
    ]


@router.get("/compliance/frameworks/{framework_id}")
def get_framework(framework_id: str, x_tenant_id: Optional[str] = Header(default=None)):
    """Return a full framework definition plus cached per-control status
    for the tenant identified by the ``X-Tenant-ID`` header."""
    from ...governance.frameworks import REGISTRY
    from ...governance.frameworks.cache import get_cached

    fw = REGISTRY.get(framework_id)
    if fw is None:
        raise HTTPException(status_code=404, detail=f"Unknown framework: {framework_id!r}")
    tenant_id = _tenant_from_header(x_tenant_id)
    controls: list = []
    for ctrl in fw.controls:
        cached = get_cached(tenant_id, ctrl.id)
        controls.append({
            **ctrl.to_dict(),
            "result": cached.to_dict() if cached else None,
        })
    return {
        "id": fw.id,
        "name": fw.name,
        "version": fw.version,
        "regulator": fw.regulator,
        "url": fw.url,
        "controls": controls,
    }


@router.get("/compliance/controls")
def list_controls() -> list:
    """Flat list of every registered control (dedup by id)."""
    from ...governance.frameworks import REGISTRY
    return [c.to_dict() for c in REGISTRY.all_controls()]


@router.get("/compliance/controls/{control_id}")
def get_control(control_id: str, x_tenant_id: Optional[str] = Header(default=None)):
    """Return a single control plus its cached status for the tenant."""
    from ...governance.frameworks import REGISTRY
    from ...governance.frameworks.cache import get_cached

    ctrl = REGISTRY.control(control_id)
    if ctrl is None:
        raise HTTPException(status_code=404, detail=f"Unknown control: {control_id!r}")
    tenant_id = _tenant_from_header(x_tenant_id)
    cached = get_cached(tenant_id, control_id)
    return {**ctrl.to_dict(), "result": cached.to_dict() if cached else None}


@router.post("/compliance/recompute")
def recompute_compliance(x_tenant_id: Optional[str] = Header(default=None)):
    """Force-recompute every control for the tenant. Returns counts."""
    tenant_id = _tenant_from_header(x_tenant_id)
    results = _results_for_tenant(tenant_id, force=True)
    counts: dict = {"pass": 0, "warn": 0, "fail": 0, "not_applicable": 0}
    for r in results.values():
        counts[r.status] = counts.get(r.status, 0) + 1
    return {"tenant_id": tenant_id, "total": len(results), "counts": counts}


@router.get("/compliance/gaps")
def list_gaps(x_tenant_id: Optional[str] = Header(default=None)) -> list:
    """Return every control currently in ``fail`` or ``warn`` status."""
    from ...governance.frameworks import REGISTRY
    tenant_id = _tenant_from_header(x_tenant_id)
    results = _results_for_tenant(tenant_id)
    out: list = []
    for cid, result in results.items():
        if result.status in ("fail", "warn"):
            ctrl = REGISTRY.control(cid)
            out.append({
                "control_id": cid,
                "control_name": ctrl.name if ctrl else cid,
                "framework_ids": list(ctrl.framework_ids) if ctrl else [],
                "importance": ctrl.importance if ctrl else "medium",
                "status": result.status,
                "evidence": result.evidence,
                "notes": result.notes,
            })
    return out


@router.post("/compliance/export")
def export_compliance_plugin(req: CompliancePluginExportRequest):
    """Generate a :class:`CompliancePackage` for the requested framework.

    Uses the backward-compat ``ComplianceAutoGenerator`` shim so the shape
    matches v0.3.0 consumers (dashboard, pytest suite).
    """
    from ...governance.compliance_auto import ComplianceAutoGenerator
    gen = ComplianceAutoGenerator()
    pkg = gen.generate(framework=req.framework_id, tenant_id=req.tenant_id or "default")
    return pkg.to_dict()


@router.get("/compliance/overrides")
def get_compliance_overrides(x_tenant_id: Optional[str] = Header(default=None)) -> list:
    from ...governance.frameworks.overrides import list_overrides
    return list_overrides(_tenant_from_header(x_tenant_id))


@router.post("/compliance/overrides")
def set_compliance_override(
    req: ComplianceOverrideRequest,
    x_tenant_id: Optional[str] = Header(default=None),
):
    from ...governance.frameworks.overrides import set_override
    try:
        set_override(
            tenant_id=_tenant_from_header(x_tenant_id),
            control_id=req.control_id,
            status=req.status,
            notes=req.notes,
            evidence=req.evidence or {},
            set_by=req.set_by or "",
            expires_at=req.expires_at,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"control_id": req.control_id, "status": req.status, "saved": True}


@router.delete("/compliance/overrides/{control_id}")
def delete_compliance_override(
    control_id: str,
    x_tenant_id: Optional[str] = Header(default=None),
):
    from ...governance.frameworks.overrides import clear_override
    clear_override(_tenant_from_header(x_tenant_id), control_id)
    return {"control_id": control_id, "cleared": True}


# ── Model Risk Register ───────────────────────────────────────────────────────

class ModelRiskRequest(BaseModel):
    model_id: str
    provider: str
    risk_tier: str = "unclassified"
    use_case: str = ""
    approved_by: Optional[str] = None
    notes: str = ""


@router.post("/risk-register/models")
def register_model_risk(req: ModelRiskRequest):
    """Add or update a model in the risk register."""
    from ...governance import get_model_risk_register
    register = get_model_risk_register()
    entry = register.add_model(
        model_id=req.model_id,
        provider=req.provider,
        risk_tier=req.risk_tier,
        use_case=req.use_case,
        approved_by=req.approved_by,
        notes=req.notes,
    )
    return {
        "id": entry.id,
        "model_id": entry.model_id,
        "provider": entry.provider,
        "risk_tier": entry.risk_tier.value,
        "use_case": entry.use_case,
        "approved_by": entry.approved_by,
        "approved_at": entry.approved_at,
        "requires_hitl": entry.requires_hitl(),
        "created_at": entry.created_at,
    }


@router.get("/risk-register/models")
def list_model_risks(tier: Optional[str] = None):
    """List all models in the risk register."""
    from ...governance import get_model_risk_register, RiskTier
    register = get_model_risk_register()
    risk_tier = RiskTier(tier) if tier else None
    entries = register.list_entries(risk_tier)
    return [
        {
            "model_id": e.model_id,
            "provider": e.provider,
            "risk_tier": e.risk_tier.value,
            "use_case": e.use_case,
            "approved_by": e.approved_by,
            "requires_hitl": e.requires_hitl(),
        }
        for e in entries
    ]


@router.get("/risk-register/summary")
def risk_register_summary():
    """Return risk register summary statistics."""
    from ...governance import get_model_risk_register
    return get_model_risk_register().risk_summary()


@router.post("/risk-register/sync-from-traces", status_code=200)
def sync_risk_register_from_traces():
    """Auto-populate the risk register from distinct model+provider pairs seen in traces.

    New models are registered as UNCLASSIFIED and require a compliance officer
    to assign a proper risk tier and approve. Already-registered models are not
    modified.
    """
    return _sync_risk_register_from_traces()


def _sync_risk_register_from_traces() -> dict:
    """Shared logic used by the endpoint and the startup bootstrap."""
    from ...store.db import get_shared_connection
    from ...governance import get_model_risk_register
    conn = get_shared_connection()
    rows = conn.execute(
        "SELECT model, provider, COUNT(*) as requests FROM traces"
        " WHERE model IS NOT NULL GROUP BY model, provider"
    ).fetchall()
    register = get_model_risk_register()
    added, skipped = [], []
    for r in rows:
        model_id = r["model"] or ""
        provider = r["provider"] or "unknown"
        if not model_id:
            continue
        existing = register.get(model_id)
        if existing:
            skipped.append(model_id)
            continue
        register.add_model(
            model_id=model_id,
            provider=provider,
            risk_tier="unclassified",
            use_case="auto-discovered from traces",
            notes=f"Auto-registered. {r['requests']} request(s) observed. Assign risk tier and approve.",
        )
        added.append(model_id)
    return {"added": added, "skipped_already_registered": skipped, "total": len(added) + len(skipped)}


class _ApproveModelRequest(BaseModel):
    model_id: str
    approved_by: str

@router.post("/risk-register/approve")
def approve_model_risk(req: _ApproveModelRequest):
    """Record compliance sign-off for a model."""
    from ...governance import get_model_risk_register
    entry = get_model_risk_register().approve(req.model_id, req.approved_by)
    if entry is None:
        raise HTTPException(status_code=404, detail=f"Model {req.model_id!r} not found in risk register")
    return {"model_id": req.model_id, "approved_by": entry.approved_by, "approved_at": entry.approved_at}


# ── Policy Version Management ─────────────────────────────────────────────────

class PolicyCreateRequest(BaseModel):
    name: str
    allowed_models: List[str] = []
    denied_models: List[str] = []
    max_input_tokens: Optional[int] = None
    max_output_tokens: Optional[int] = None
    max_cost_usd: Optional[float] = None
    allowed_providers: List[str] = []
    created_by: Optional[str] = None


@router.post("/policies")
def create_policy_version(req: PolicyCreateRequest):
    """Create a new versioned policy draft."""
    from ...governance import Policy, get_policy_version_manager
    policy = Policy(
        name=req.name,
        allowed_models=req.allowed_models,
        denied_models=req.denied_models,
        max_input_tokens=req.max_input_tokens,
        max_output_tokens=req.max_output_tokens,
        max_cost_usd=req.max_cost_usd,
        allowed_providers=req.allowed_providers,
    )
    pv = get_policy_version_manager().create_version(policy, created_by=req.created_by)
    return {
        "id": pv.id,
        "policy_name": pv.policy_name,
        "version": pv.version,
        "status": pv.status,
        "diff": pv.diff,
        "created_at": pv.created_at,
    }


@router.get("/policies/{policy_name}/history")
def get_policy_history(policy_name: str):
    """Return version history for a policy."""
    from ...governance import get_policy_version_manager
    versions = get_policy_version_manager().get_history(policy_name)
    return [
        {
            "version": pv.version,
            "status": pv.status,
            "diff": pv.diff,
            "approved_by": pv.approved_by,
            "approved_at": pv.approved_at,
            "created_at": pv.created_at,
        }
        for pv in versions
    ]


@router.post("/policies/{policy_name}/versions/{version}/approve")
def approve_policy_version(policy_name: str, version: int, approved_by: str):
    """Approve a policy version."""
    from ...governance import get_policy_version_manager
    pv = get_policy_version_manager().approve(policy_name, version, approved_by)
    if pv is None:
        raise HTTPException(status_code=404, detail=f"Policy {policy_name!r} v{version} not found")
    return {
        "policy_name": policy_name,
        "version": version,
        "status": pv.status,
        "approved_by": pv.approved_by,
        "approved_at": pv.approved_at,
    }


# ── HITL Queue ────────────────────────────────────────────────────────────────

@router.get("/hitl/queue")
def list_hitl_queue():
    """List all pending HITL review items."""
    from ...governance import get_hitl_workflow
    items = get_hitl_workflow().list_pending()
    return [
        {
            "id": item.id,
            "function_name": item.function_name,
            "risk_score": item.risk_score,
            "status": item.status,
            "timeout_s": item.timeout_s,
            "created_at": item.created_at,
        }
        for item in items
    ]


@router.get("/hitl/queue/{item_id}")
def get_hitl_item(item_id: str):
    """Get a specific HITL queue item."""
    from ...governance import get_hitl_workflow
    item = get_hitl_workflow().get(item_id)
    if item is None:
        raise HTTPException(status_code=404, detail=f"HITL item {item_id!r} not found")
    return {
        "id": item.id,
        "function_name": item.function_name,
        "risk_score": item.risk_score,
        "payload": item.payload,
        "status": item.status,
        "reviewer_id": item.reviewer_id,
        "decision": item.decision,
        "decision_at": item.decision_at,
        "timeout_s": item.timeout_s,
        "created_at": item.created_at,
    }


class HITLDecisionRequest(BaseModel):
    decision: str       # "approved" | "rejected"
    reviewer_id: Optional[str] = None


@router.post("/hitl/queue/{item_id}/decide")
def decide_hitl_item(item_id: str, req: HITLDecisionRequest):
    """Submit a human decision for a HITL queue item."""
    if req.decision not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="decision must be 'approved' or 'rejected'")
    from ...governance import get_hitl_workflow
    item = get_hitl_workflow().decide(item_id, req.decision, req.reviewer_id)
    if item is None:
        raise HTTPException(status_code=404, detail=f"HITL item {item_id!r} not found")
    return {
        "id": item.id,
        "status": item.status,
        "decision": item.decision,
        "reviewer_id": item.reviewer_id,
        "decision_at": item.decision_at,
    }
