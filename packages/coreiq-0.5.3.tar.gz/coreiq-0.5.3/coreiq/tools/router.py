"""Semantic tool router — embedding-based top-K tool selection."""
import math
from typing import Dict, List, Tuple

from .registry import ToolRegistry, ToolSpec

try:
    from sentence_transformers import SentenceTransformer
    _HAS_EMBEDDINGS = True
except ImportError:
    _HAS_EMBEDDINGS = False


def _cosine_sim(a: list, b: list) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class ToolRouter:
    """Selects the most relevant tools for a query using embeddings.

    Requires: pip install 'coreiq[embeddings]'
    Falls back gracefully to returning all tools if not installed.
    """

    _MODEL_NAME = "all-MiniLM-L6-v2"

    def __init__(self, registry: ToolRegistry):
        self._registry = registry
        self._model = None
        self._embeddings: dict = {}
        self._registry_version = -1
        self._tool_win_rates: Dict[str, float] = {}
        self._evolution_weight: float = 0.2

    def _get_model(self):
        if self._model is None and _HAS_EMBEDDINGS:
            self._model = SentenceTransformer(self._MODEL_NAME)
        return self._model

    def _ensure_embeddings(self) -> bool:
        model = self._get_model()
        if model is None:
            return False
        if self._registry.version != self._registry_version:
            self._embeddings.clear()
            self._registry_version = self._registry.version
        for spec in self._registry.all():
            if spec.name not in self._embeddings:
                text = f"{spec.name}: {spec.description}"
                self._embeddings[spec.name] = model.encode(text).tolist()
        return True

    def update_win_rate(self, tool_name: str, win_rate: float) -> None:
        """Record a tool's outcome win-rate to influence future rankings."""
        self._tool_win_rates[tool_name] = win_rate

    def _blend_score(self, tool_name: str, semantic_sim: float) -> float:
        """Blend semantic similarity with evolution win-rate."""
        win_rate = self._tool_win_rates.get(tool_name, 0.0)
        return semantic_sim * (1 - self._evolution_weight) + win_rate * self._evolution_weight

    def _keyword_select(self, query: str, tools: List[ToolSpec], top_k: int) -> List[ToolSpec]:
        """Fallback: score tools by keyword overlap with query."""
        query_words = set(query.lower().split())
        if not query_words:
            return tools[:top_k]
        max_score = 1  # avoid division by zero
        scored = []
        for spec in tools:
            text = f"{spec.name.replace('_', ' ')} {spec.description}".lower()
            text_words = set(text.split())
            overlap = len(query_words & text_words)
            name_words = set(spec.name.replace('_', ' ').lower().split())
            name_overlap = len(query_words & name_words)
            raw = overlap + name_overlap * 2  # name matches worth double
            max_score = max(max_score, raw)
            scored.append((raw, spec))
        # Normalize to [0,1] then blend with win_rate
        blended = [
            (self._blend_score(spec.name, raw / max_score), spec)
            for raw, spec in scored
        ]
        blended.sort(key=lambda x: -x[0])
        return [spec for _, spec in blended[:top_k]]

    def _keyword_select_with_scores(self, query: str, tools: List[ToolSpec], top_k: int) -> List[Tuple[ToolSpec, float]]:
        """Keyword fallback returning (spec, score) tuples."""
        query_words = set(query.lower().split())
        if not query_words:
            return [(s, 0.0) for s in tools[:top_k]]
        max_score = 1
        scored = []
        for spec in tools:
            text = f"{spec.name.replace('_', ' ')} {spec.description}".lower()
            text_words = set(text.split())
            overlap = len(query_words & text_words)
            name_words = set(spec.name.replace('_', ' ').lower().split())
            name_overlap = len(query_words & name_words)
            raw = overlap + name_overlap * 2
            max_score = max(max_score, raw)
            scored.append((raw, spec))
        blended = [
            (self._blend_score(spec.name, raw / max_score), spec)
            for raw, spec in scored
        ]
        blended.sort(key=lambda x: -x[0])
        return [(spec, score) for score, spec in blended[:top_k]]

    def _keyword_score(self, query_words: set[str], spec: ToolSpec) -> float:
        """Compute normalized keyword overlap score for a tool spec."""
        if not query_words:
            return 0.0
        text = f"{spec.name.replace('_', ' ')} {spec.description}".lower()
        text_words = set(text.split())
        overlap = len(query_words & text_words)
        name_words = set(spec.name.replace("_", " ").lower().split())
        name_overlap = len(query_words & name_words)
        max_raw = max(1, len(query_words) * 3)
        return min(1.0, (overlap + name_overlap * 2) / max_raw)

    def select(self, query: str, top_k: int = 5) -> List[ToolSpec]:
        """Return the top_k most relevant tools for query.

        Uses cosine similarity over sentence-transformer embeddings.
        Falls back to keyword matching if embeddings unavailable.
        """
        all_tools = self._registry.all()
        if not all_tools:
            return []
        if not query.strip():
            return all_tools[:top_k]

        if not _HAS_EMBEDDINGS or not self._ensure_embeddings():
            return self._keyword_select(query, all_tools, top_k)

        model = self._get_model()
        query_emb = model.encode(query).tolist()
        query_words = set(query.lower().split())

        scored = [
            (
                self._blend_score(
                    spec.name,
                    0.8 * _cosine_sim(query_emb, self._embeddings[spec.name])
                    + 0.2 * self._keyword_score(query_words, spec),
                ),
                spec,
            )
            for spec in all_tools
            if spec.name in self._embeddings
        ]
        scored.sort(key=lambda x: -x[0])
        return [spec for _, spec in scored[:top_k]]

    def select_deferred(self, query: str, top_k: int = 5) -> List[Tuple[ToolSpec, float]]:
        """Search the deferred tool catalog and return (spec, score) tuples.

        Only considers tools registered with ``defer_loading=True``.
        Uses semantic embeddings when available, keyword overlap as fallback.
        """
        deferred = self._registry.get_deferred()
        if not deferred:
            return []

        if not _HAS_EMBEDDINGS or not self._ensure_embeddings():
            return self._keyword_select_with_scores(query, deferred, top_k)

        model = self._get_model()
        query_emb = model.encode(query).tolist()

        scored = [
            (self._blend_score(spec.name, _cosine_sim(query_emb, self._embeddings[spec.name])), spec)
            for spec in deferred
            if spec.name in self._embeddings
        ]
        scored.sort(key=lambda x: -x[0])
        return [(spec, score) for score, spec in scored[:top_k]]

    def select_within_budget(
        self, query: str, token_budget: int, tokens_per_tool: int = 200
    ) -> List[ToolSpec]:
        """Greedily select tools by relevance until the token budget is filled.

        Args:
            query: The user query to score tools against.
            token_budget: Maximum tokens to spend on tool definitions.
            tokens_per_tool: Estimated token cost per tool definition.

        Returns:
            List of tools fitting within the budget, ranked by relevance.
        """
        if token_budget <= 0:
            return []

        all_tools = self._registry.all()
        if not all_tools:
            return []

        if not _HAS_EMBEDDINGS or not self._ensure_embeddings():
            all_scored = self._keyword_select(query, all_tools, len(all_tools))
        else:
            model = self._get_model()
            query_emb = model.encode(query).tolist()
            ranked = [
                (self._blend_score(spec.name, _cosine_sim(query_emb, self._embeddings[spec.name])), spec)
                for spec in all_tools
                if spec.name in self._embeddings
            ]
            ranked.sort(key=lambda x: -x[0])
            all_scored = [spec for _, spec in ranked]

        selected = []
        used = 0
        for spec in all_scored:
            if used + tokens_per_tool > token_budget:
                break
            selected.append(spec)
            used += tokens_per_tool
        return selected

    def token_savings(self, selected: List[ToolSpec], tokens_per_tool: int = 200) -> int:
        """Estimate tokens saved by sending selected tools vs all tools."""
        total = len(self._registry)
        sent = len(selected)
        return max(0, (total - sent) * tokens_per_tool)
