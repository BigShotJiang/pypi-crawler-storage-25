"""Tool schema registry — register and look up tool definitions."""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..exceptions import ValidationError


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    defer_loading: bool = False


class ToolRegistry:
    """Stores tool definitions and provides fast lookup."""

    def __init__(self):
        self._tools: Dict[str, ToolSpec] = {}
        self._version = 0

    @property
    def version(self) -> int:
        return self._version

    def register(self, tools: List[Dict[str, Any]], *, defer_loading: bool = False) -> None:
        """Register tool specs. Each dict: {name, description, parameters}.

        Args:
            tools: List of tool definition dicts.
            defer_loading: Default defer_loading value for all tools. Per-tool
                ``"defer_loading"`` key in the dict takes priority over this.
        """
        for t in tools:
            name = t.get("name", "").strip()
            if not name:
                raise ValidationError("Tool must have a non-empty 'name'")
            description = t.get("description", "")
            if len(description) > 2000:
                raise ValidationError(f"Tool '{name}' description exceeds 2000 chars")
            self._tools[name] = ToolSpec(
                name=name,
                description=description,
                parameters=t.get("parameters", {}),
                defer_loading=t.get("defer_loading", defer_loading),
            )
        self._version += 1

    def get(self, name: str) -> Optional[ToolSpec]:
        return self._tools.get(name)

    def all(self) -> List[ToolSpec]:
        return list(self._tools.values())

    def get_eager(self) -> List[ToolSpec]:
        """Return tools that are loaded immediately (not deferred)."""
        return [s for s in self._tools.values() if not s.defer_loading]

    def get_deferred(self) -> List[ToolSpec]:
        """Return tools that are only loaded on demand via search."""
        return [s for s in self._tools.values() if s.defer_loading]

    def remove(self, name: str) -> bool:
        """Remove a tool by name. Returns True if it existed, False otherwise."""
        if name in self._tools:
            del self._tools[name]
            self._version += 1
            return True
        return False

    def names(self) -> List[str]:
        return list(self._tools.keys())

    def __len__(self) -> int:
        return len(self._tools)
