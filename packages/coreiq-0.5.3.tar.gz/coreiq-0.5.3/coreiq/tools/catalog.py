"""Tool discovery protocol types."""
from dataclasses import dataclass, field
from typing import List


@dataclass
class ToolSearchResult:
    """Result of a deferred tool catalog search.

    Attributes:
        tool_refs: Names of matching tools (parallel to similarity_scores).
        similarity_scores: Relevance score [0, 1] for each tool_ref.
        query: The original search query.
        top_k: The maximum number of results requested.
        tokens_saved: Estimated tokens saved vs loading the full catalog.
    """

    tool_refs: List[str] = field(default_factory=list)
    similarity_scores: List[float] = field(default_factory=list)
    query: str = ""
    top_k: int = 5
    tokens_saved: int = 0
