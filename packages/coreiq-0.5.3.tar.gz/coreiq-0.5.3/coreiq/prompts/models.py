"""Data models for the Prompt Registry."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional


class PromptStatus(str, Enum):
    draft = "draft"
    review = "review"
    approved = "approved"
    deployed = "deployed"
    archived = "archived"


class DeploymentStatus(str, Enum):
    canary = "canary"
    promoted = "promoted"
    rolled_back = "rolled_back"


@dataclass
class PromptVersion:
    id: str
    prompt_id: str
    version: str
    template: str
    model: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    parent_version_id: Optional[str] = None
    status: PromptStatus = PromptStatus.draft
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    created_by: Optional[str] = None
    created_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "prompt_id": self.prompt_id,
            "version": self.version,
            "template": self.template,
            "model": self.model,
            "metadata": self.metadata,
            "parent_version_id": self.parent_version_id,
            "status": self.status.value,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at,
            "created_by": self.created_by,
            "created_at": self.created_at,
        }


@dataclass
class RollbackPolicy:
    metric: str
    threshold: float
    window_minutes: int = 30
    check_interval_seconds: int = 60

    def to_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.metric,
            "threshold": self.threshold,
            "window_minutes": self.window_minutes,
            "check_interval_seconds": self.check_interval_seconds,
        }


@dataclass
class PromptDeployment:
    id: str
    prompt_id: str
    version_id: str
    traffic_percent: float
    rollback_policy: Optional[RollbackPolicy] = None
    status: DeploymentStatus = DeploymentStatus.canary
    promoted_at: Optional[str] = None
    rolled_back_at: Optional[str] = None
    rolled_back_to_version_id: Optional[str] = None
    created_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "prompt_id": self.prompt_id,
            "version_id": self.version_id,
            "traffic_percent": self.traffic_percent,
            "rollback_policy": self.rollback_policy.to_dict() if self.rollback_policy else None,
            "status": self.status.value,
            "promoted_at": self.promoted_at,
            "rolled_back_at": self.rolled_back_at,
            "rolled_back_to_version_id": self.rolled_back_to_version_id,
            "created_at": self.created_at,
        }


@dataclass
class PromptDiff:
    old_version: str
    new_version: str
    unified_diff: str
    additions: int = 0
    deletions: int = 0
    old_template: str = ""
    new_template: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "old_version": self.old_version,
            "new_version": self.new_version,
            "unified_diff": self.unified_diff,
            "additions": self.additions,
            "deletions": self.deletions,
        }
