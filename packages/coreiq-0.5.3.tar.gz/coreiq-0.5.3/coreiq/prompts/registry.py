"""Prompt Registry — git-like version control for prompts.

Provides:
- Immutable prompt versions with linked history
- Status lifecycle: draft → review → approved → deployed → archived
- Canary deployments with configurable traffic split
- Auto-rollback on metric threshold breach
- Diff between any two versions
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ..store.db import get_shared_connection
from .diff import diff_prompts
from .models import (
    DeploymentStatus,
    PromptDeployment,
    PromptDiff,
    PromptStatus,
    PromptVersion,
    RollbackPolicy,
)

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class PromptRegistry:
    """Git-like version control for prompt templates.

    Each prompt is identified by a ``prompt_id`` (e.g. ``"support-reply"``).
    Versions are immutable snapshots linked via ``parent_version_id``.
    Deployments track which version is serving traffic and at what percentage.
    """

    def __init__(self):
        self._lock = threading.Lock()
        # prompt_id -> {version_str -> PromptVersion}
        self._versions_cache: Dict[str, Dict[str, PromptVersion]] = {}
        # prompt_id -> active PromptDeployment
        self._deployments_cache: Dict[str, PromptDeployment] = {}
        self._loaded = False

    def _conn(self):
        return get_shared_connection()

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            self._load_all()
            self._loaded = True

    def _load_all(self) -> None:
        conn = self._conn()
        # Load versions
        try:
            rows = conn.execute("SELECT * FROM prompt_versions ORDER BY created_at ASC").fetchall()
        except Exception:
            rows = []
        for row in rows:
            pv = self._row_to_version(row)
            self._versions_cache.setdefault(pv.prompt_id, {})[pv.version] = pv

        # Load active deployments
        try:
            rows = conn.execute(
                "SELECT * FROM prompt_deployments WHERE status IN ('canary', 'promoted')"
            ).fetchall()
        except Exception:
            rows = []
        for row in rows:
            dep = self._row_to_deployment(row)
            self._deployments_cache[dep.prompt_id] = dep

    @staticmethod
    def _row_to_version(row) -> PromptVersion:
        row = dict(row)
        metadata = None
        if row["metadata_json"]:
            metadata = json.loads(row["metadata_json"])
        return PromptVersion(
            id=row["id"],
            prompt_id=row["prompt_id"],
            version=row["version"],
            template=row["template"],
            model=row.get("model"),
            metadata=metadata,
            parent_version_id=row["parent_version_id"],
            status=PromptStatus(row["status"]),
            approved_by=row["approved_by"],
            approved_at=row["approved_at"],
            created_by=row["created_by"],
            created_at=row["created_at"] or "",
        )

    @staticmethod
    def _row_to_deployment(row) -> PromptDeployment:
        row = dict(row)
        rollback_policy = None
        if row["rollback_policy_json"]:
            rp = json.loads(row["rollback_policy_json"])
            rollback_policy = RollbackPolicy(
                metric=rp["metric"],
                threshold=rp["threshold"],
                window_minutes=rp.get("window_minutes", 30),
                check_interval_seconds=rp.get("check_interval_seconds", 60),
            )
        return PromptDeployment(
            id=row["id"],
            prompt_id=row["prompt_id"],
            version_id=row["version_id"],
            traffic_percent=float(row["traffic_percent"]),
            rollback_policy=rollback_policy,
            status=DeploymentStatus(row["status"]),
            promoted_at=row["promoted_at"],
            rolled_back_at=row["rolled_back_at"],
            rolled_back_to_version_id=row.get("rolled_back_to_version_id"),
            created_at=row["created_at"] or "",
        )

    # ------------------------------------------------------------------
    # Prompt Registration & Versioning
    # ------------------------------------------------------------------

    def register(
        self,
        prompt_id: str,
        version: str,
        template: str,
        *,
        model: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        created_by: Optional[str] = None,
        status: PromptStatus = PromptStatus.draft,
    ) -> PromptVersion:
        """Register a new prompt version.

        If this is the first version for a prompt_id, it has no parent.
        Otherwise, the parent is the latest existing version.
        """
        self._ensure_loaded()
        with self._lock:
            versions = self._versions_cache.get(prompt_id, {})
            if version in versions:
                # Idempotent: version already registered → return existing
                return versions[version]

            # Find parent (latest version by created_at)
            parent_id = None
            if versions:
                latest = max(versions.values(), key=lambda v: v.created_at)
                parent_id = latest.id

            vid = str(uuid.uuid4())
            now = _now()
            pv = PromptVersion(
                id=vid,
                prompt_id=prompt_id,
                version=version,
                template=template,
                model=model,
                metadata=metadata,
                parent_version_id=parent_id,
                status=status,
                created_by=created_by,
                created_at=now,
            )

            conn = self._conn()
            conn.execute(
                "INSERT INTO prompt_versions"
                "(id, prompt_id, version, template, model, metadata_json, "
                "parent_version_id, status, approved_by, approved_at, "
                "created_by, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (pv.id, pv.prompt_id, pv.version, pv.template, pv.model,
                 json.dumps(pv.metadata) if pv.metadata else None,
                 pv.parent_version_id, pv.status.value,
                 None, None, pv.created_by, pv.created_at),
            )
            conn.commit()

            self._versions_cache.setdefault(prompt_id, {})[version] = pv
            logger.info("Registered prompt '%s' v%s (status=%s)", prompt_id, version, status.value)
            return pv

    def get_version(self, prompt_id: str, version: str) -> Optional[PromptVersion]:
        """Get a specific version of a prompt."""
        self._ensure_loaded()
        return self._versions_cache.get(prompt_id, {}).get(version)

    def get_latest_version(self, prompt_id: str) -> Optional[PromptVersion]:
        """Get the latest version of a prompt."""
        self._ensure_loaded()
        versions = self._versions_cache.get(prompt_id, {})
        if not versions:
            return None
        return max(versions.values(), key=lambda v: v.created_at)

    def list_prompts(self) -> List[Dict[str, Any]]:
        """List all registered prompts with their version counts."""
        self._ensure_loaded()
        result = []
        for prompt_id, versions in self._versions_cache.items():
            latest = max(versions.values(), key=lambda v: v.created_at)
            deployment = self._deployments_cache.get(prompt_id)
            result.append({
                "prompt_id": prompt_id,
                "version_count": len(versions),
                "latest_version": latest.version,
                "latest_status": latest.status.value,
                "deployed_version": None,
                "deployment_status": None,
                "deployment_traffic": None,
            })
            if deployment:
                # Find the version for this deployment
                dep_version = next(
                    (v for v in versions.values() if v.id == deployment.version_id),
                    None,
                )
                if dep_version:
                    result[-1]["deployed_version"] = dep_version.version
                    result[-1]["deployment_status"] = deployment.status.value
                    result[-1]["deployment_traffic"] = deployment.traffic_percent
        return result

    def list_versions(
        self, prompt_id: str, status: Optional[PromptStatus] = None,
    ) -> List[PromptVersion]:
        """List all versions of a prompt, optionally filtered by status."""
        self._ensure_loaded()
        versions = list(self._versions_cache.get(prompt_id, {}).values())
        if status:
            versions = [v for v in versions if v.status == status]
        versions.sort(key=lambda v: v.created_at)
        return versions

    def get_version_history(self, prompt_id: str, version: str) -> List[PromptVersion]:
        """Walk the parent chain from a version back to the root."""
        self._ensure_loaded()
        versions = self._versions_cache.get(prompt_id, {})
        pv = versions.get(version)
        if pv is None:
            return []
        chain = [pv]
        visited = {pv.id}
        while pv.parent_version_id:
            parent = next(
                (v for v in versions.values() if v.id == pv.parent_version_id),
                None,
            )
            if parent is None or parent.id in visited:
                break
            chain.append(parent)
            visited.add(parent.id)
            pv = parent
        return chain

    # ------------------------------------------------------------------
    # Approval Workflow
    # ------------------------------------------------------------------

    def submit_for_review(self, prompt_id: str, version: str) -> PromptVersion:
        """Move a draft prompt to review status."""
        return self._transition_status(prompt_id, version, PromptStatus.draft, PromptStatus.review)

    def approve(
        self, prompt_id: str, version: str, approved_by: str,
    ) -> PromptVersion:
        """Approve a prompt version for deployment."""
        pv = self._transition_status(prompt_id, version, PromptStatus.review, PromptStatus.approved)
        now = _now()
        pv.approved_by = approved_by
        pv.approved_at = now
        conn = self._conn()
        conn.execute(
            "UPDATE prompt_versions SET approved_by = ?, approved_at = ? WHERE id = ?",
            (approved_by, now, pv.id),
        )
        conn.commit()
        return pv

    def archive(self, prompt_id: str, version: str) -> PromptVersion:
        """Archive a prompt version."""
        self._ensure_loaded()
        pv = self._versions_cache.get(prompt_id, {}).get(version)
        if pv is None:
            from ..exceptions import ValidationError
            raise ValidationError(f"Version '{version}' not found for prompt '{prompt_id}'")
        if pv.status == PromptStatus.deployed:
            from ..exceptions import ValidationError
            raise ValidationError("Cannot archive a deployed version — rollback first")
        pv.status = PromptStatus.archived
        conn = self._conn()
        conn.execute(
            "UPDATE prompt_versions SET status = ? WHERE id = ?",
            (PromptStatus.archived.value, pv.id),
        )
        conn.commit()
        return pv

    def _transition_status(
        self, prompt_id: str, version: str, from_status: PromptStatus, to_status: PromptStatus,
    ) -> PromptVersion:
        self._ensure_loaded()
        with self._lock:
            pv = self._versions_cache.get(prompt_id, {}).get(version)
            if pv is None:
                from ..exceptions import ValidationError
                raise ValidationError(f"Version '{version}' not found for prompt '{prompt_id}'")
            if pv.status != from_status:
                from ..exceptions import ValidationError
                raise ValidationError(
                    f"Cannot transition from '{pv.status.value}' to '{to_status.value}' "
                    f"(expected '{from_status.value}')"
                )
            pv.status = to_status
            conn = self._conn()
            conn.execute(
                "UPDATE prompt_versions SET status = ? WHERE id = ?",
                (to_status.value, pv.id),
            )
            conn.commit()
            logger.info(
                "Prompt '%s' v%s: %s → %s",
                prompt_id, version, from_status.value, to_status.value,
            )
            return pv

    # ------------------------------------------------------------------
    # Diffing
    # ------------------------------------------------------------------

    def diff(self, prompt_id: str, old_version: str, new_version: str) -> PromptDiff:
        """Generate a unified diff between two prompt versions."""
        self._ensure_loaded()
        versions = self._versions_cache.get(prompt_id, {})
        old_pv = versions.get(old_version)
        new_pv = versions.get(new_version)
        if old_pv is None:
            from ..exceptions import ValidationError
            raise ValidationError(f"Version '{old_version}' not found for prompt '{prompt_id}'")
        if new_pv is None:
            from ..exceptions import ValidationError
            raise ValidationError(f"Version '{new_version}' not found for prompt '{prompt_id}'")
        return diff_prompts(old_pv.template, new_pv.template, old_version, new_version)

    # ------------------------------------------------------------------
    # Deployment & Canary
    # ------------------------------------------------------------------

    def deploy(
        self,
        prompt_id: str,
        version: str,
        traffic: float = 1.0,
        *,
        rollback_policy: Optional[Dict[str, Any]] = None,
        allow_unapproved: bool = False,
    ) -> PromptDeployment:
        """Deploy a prompt version with optional canary traffic split.

        Args:
            prompt_id: The prompt identifier.
            version: The version string to deploy.
            traffic: Traffic percentage (0.0 to 1.0). Values < 1.0 create a canary.
            rollback_policy: Optional dict with {metric, threshold, window_minutes}.
            allow_unapproved: Skip approval check (for dev/testing).
        """
        self._ensure_loaded()
        with self._lock:
            pv = self._versions_cache.get(prompt_id, {}).get(version)
            if pv is None:
                from ..exceptions import ValidationError
                raise ValidationError(f"Version '{version}' not found for prompt '{prompt_id}'")

            if not allow_unapproved and pv.status not in (PromptStatus.approved, PromptStatus.deployed):
                from ..exceptions import ValidationError
                raise ValidationError(
                    f"Version '{version}' must be approved before deployment "
                    f"(current status: {pv.status.value})"
                )

            if not 0.0 < traffic <= 1.0:
                from ..exceptions import ValidationError
                raise ValidationError(f"traffic must be in (0.0, 1.0], got {traffic}")

            # Archive any existing deployment for this prompt
            existing = self._deployments_cache.get(prompt_id)
            if existing and existing.status in (DeploymentStatus.canary, DeploymentStatus.promoted):
                existing.status = DeploymentStatus.rolled_back
                existing.rolled_back_at = _now()
                conn = self._conn()
                conn.execute(
                    "UPDATE prompt_deployments SET status = ?, rolled_back_at = ? WHERE id = ?",
                    (DeploymentStatus.rolled_back.value, existing.rolled_back_at, existing.id),
                )
                conn.commit()

            # Create new deployment
            rp = None
            if rollback_policy:
                rp = RollbackPolicy(
                    metric=rollback_policy["metric"],
                    threshold=rollback_policy["threshold"],
                    window_minutes=rollback_policy.get("window_minutes", 30),
                    check_interval_seconds=rollback_policy.get("check_interval_seconds", 60),
                )

            dep_id = str(uuid.uuid4())
            now = _now()
            status = DeploymentStatus.promoted if traffic >= 1.0 else DeploymentStatus.canary
            dep = PromptDeployment(
                id=dep_id,
                prompt_id=prompt_id,
                version_id=pv.id,
                traffic_percent=traffic,
                rollback_policy=rp,
                status=status,
                promoted_at=now if status == DeploymentStatus.promoted else None,
                created_at=now,
            )

            # Mark version as deployed
            pv.status = PromptStatus.deployed
            conn = self._conn()
            conn.execute(
                "UPDATE prompt_versions SET status = ? WHERE id = ?",
                (PromptStatus.deployed.value, pv.id),
            )
            conn.execute(
                "INSERT INTO prompt_deployments"
                "(id, prompt_id, version_id, traffic_percent, rollback_policy_json, "
                "status, promoted_at, rolled_back_at, rolled_back_to_version_id, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (dep.id, dep.prompt_id, dep.version_id, dep.traffic_percent,
                 json.dumps(rp.to_dict()) if rp else None,
                 dep.status.value, dep.promoted_at, None, None, dep.created_at),
            )
            conn.commit()

            self._deployments_cache[prompt_id] = dep
            logger.info(
                "Deployed prompt '%s' v%s at %.0f%% traffic (status=%s)",
                prompt_id, version, traffic * 100, status.value,
            )
            return dep

    def promote(self, prompt_id: str) -> PromptDeployment:
        """Promote a canary deployment to 100% traffic."""
        self._ensure_loaded()
        with self._lock:
            dep = self._deployments_cache.get(prompt_id)
            if dep is None:
                from ..exceptions import ValidationError
                raise ValidationError(f"No active deployment for prompt '{prompt_id}'")
            if dep.status != DeploymentStatus.canary:
                from ..exceptions import ValidationError
                raise ValidationError(
                    f"Cannot promote — deployment status is '{dep.status.value}', expected 'canary'"
                )
            now = _now()
            dep.status = DeploymentStatus.promoted
            dep.traffic_percent = 1.0
            dep.promoted_at = now
            conn = self._conn()
            conn.execute(
                "UPDATE prompt_deployments SET status = ?, traffic_percent = 1.0, "
                "promoted_at = ? WHERE id = ?",
                (DeploymentStatus.promoted.value, now, dep.id),
            )
            conn.commit()
            logger.info("Promoted prompt '%s' canary to 100%%", prompt_id)
            return dep

    def rollback(self, prompt_id: str) -> PromptDeployment:
        """Roll back to the previous deployed version.

        Marks the current deployment as rolled_back. If the current
        version has a parent, creates a new deployment for the parent.
        """
        self._ensure_loaded()
        with self._lock:
            dep = self._deployments_cache.get(prompt_id)
            if dep is None:
                from ..exceptions import ValidationError
                raise ValidationError(f"No active deployment for prompt '{prompt_id}'")

            # Find the current deployed version
            versions = self._versions_cache.get(prompt_id, {})
            current_version = next(
                (v for v in versions.values() if v.id == dep.version_id), None,
            )

            now = _now()
            dep.status = DeploymentStatus.rolled_back
            dep.rolled_back_at = now

            conn = self._conn()

            # Find parent version to roll back to
            previous_version = None
            if current_version and current_version.parent_version_id:
                previous_version = next(
                    (v for v in versions.values() if v.id == current_version.parent_version_id),
                    None,
                )

            dep.rolled_back_to_version_id = previous_version.id if previous_version else None
            conn.execute(
                "UPDATE prompt_deployments SET status = ?, rolled_back_at = ?, "
                "rolled_back_to_version_id = ? WHERE id = ?",
                (DeploymentStatus.rolled_back.value, now,
                 dep.rolled_back_to_version_id, dep.id),
            )

            if previous_version:
                # Create a new deployment for the previous version
                new_dep_id = str(uuid.uuid4())
                new_dep = PromptDeployment(
                    id=new_dep_id,
                    prompt_id=prompt_id,
                    version_id=previous_version.id,
                    traffic_percent=1.0,
                    status=DeploymentStatus.promoted,
                    promoted_at=now,
                    created_at=now,
                )
                previous_version.status = PromptStatus.deployed
                conn.execute(
                    "UPDATE prompt_versions SET status = ? WHERE id = ?",
                    (PromptStatus.deployed.value, previous_version.id),
                )
                conn.execute(
                    "INSERT INTO prompt_deployments"
                    "(id, prompt_id, version_id, traffic_percent, rollback_policy_json, "
                    "status, promoted_at, rolled_back_at, rolled_back_to_version_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (new_dep.id, new_dep.prompt_id, new_dep.version_id,
                     new_dep.traffic_percent, None, new_dep.status.value,
                     new_dep.promoted_at, None, None, new_dep.created_at),
                )
                self._deployments_cache[prompt_id] = new_dep
                logger.info(
                    "Rolled back prompt '%s' → v%s",
                    prompt_id, previous_version.version,
                )
            else:
                del self._deployments_cache[prompt_id]
                logger.info("Rolled back prompt '%s' (no previous version)", prompt_id)

            # Archive the rolled-back version
            if current_version:
                current_version.status = PromptStatus.archived
                conn.execute(
                    "UPDATE prompt_versions SET status = ? WHERE id = ?",
                    (PromptStatus.archived.value, current_version.id),
                )

            conn.commit()
            return dep

    def set_rollback_policy(
        self,
        prompt_id: str,
        metric: str,
        threshold: float,
        window_minutes: int = 30,
    ) -> PromptDeployment:
        """Set an auto-rollback policy on the active deployment."""
        self._ensure_loaded()
        with self._lock:
            dep = self._deployments_cache.get(prompt_id)
            if dep is None:
                from ..exceptions import ValidationError
                raise ValidationError(f"No active deployment for prompt '{prompt_id}'")

            rp = RollbackPolicy(
                metric=metric, threshold=threshold, window_minutes=window_minutes,
            )
            dep.rollback_policy = rp
            conn = self._conn()
            conn.execute(
                "UPDATE prompt_deployments SET rollback_policy_json = ? WHERE id = ?",
                (json.dumps(rp.to_dict()), dep.id),
            )
            conn.commit()
            logger.info(
                "Set rollback policy on '%s': %s > %.2f → auto-rollback",
                prompt_id, metric, threshold,
            )
            return dep

    # ------------------------------------------------------------------
    # Resolution (which template to serve)
    # ------------------------------------------------------------------

    def resolve(
        self, prompt_id: str, *, context_key: Optional[str] = None,
    ) -> Optional[PromptVersion]:
        """Resolve which prompt version to serve.

        For canary deployments, uses a hash of ``context_key`` (user ID,
        request ID, etc.) to deterministically decide whether to serve
        the canary or the previous version.

        Args:
            prompt_id: The prompt identifier.
            context_key: A stable key for deterministic canary assignment.
                If None, always returns the deployed version.

        Returns:
            The PromptVersion to serve, or None if no deployment exists.
        """
        self._ensure_loaded()
        dep = self._deployments_cache.get(prompt_id)
        if dep is None:
            return None

        versions = self._versions_cache.get(prompt_id, {})
        canary_version = next(
            (v for v in versions.values() if v.id == dep.version_id), None,
        )

        if dep.status == DeploymentStatus.promoted or dep.traffic_percent >= 1.0:
            return canary_version

        # Canary: deterministic hash-based routing
        if context_key and canary_version:
            hash_val = int(hashlib.md5(
                f"{prompt_id}:{context_key}".encode(), usedforsecurity=False
            ).hexdigest(), 16)
            bucket = (hash_val % 1000) / 1000.0

            if bucket < dep.traffic_percent:
                return canary_version

            # Serve previous version
            if canary_version.parent_version_id:
                parent = next(
                    (v for v in versions.values() if v.id == canary_version.parent_version_id),
                    None,
                )
                if parent:
                    return parent

        return canary_version

    def get_deployment(self, prompt_id: str) -> Optional[PromptDeployment]:
        """Get the active deployment for a prompt."""
        self._ensure_loaded()
        return self._deployments_cache.get(prompt_id)

    def check_rollback_policies(self, get_metric_value) -> List[str]:
        """Check all active deployments against their rollback policies.

        Args:
            get_metric_value: Callable(metric_name, window_minutes) -> float
                Returns the current metric value for the given window.

        Returns:
            List of prompt_ids that were auto-rolled-back.
        """
        self._ensure_loaded()
        rolled_back = []
        for prompt_id, dep in list(self._deployments_cache.items()):
            if dep.rollback_policy is None:
                continue
            if dep.status not in (DeploymentStatus.canary, DeploymentStatus.promoted):
                continue
            try:
                value = get_metric_value(
                    dep.rollback_policy.metric,
                    dep.rollback_policy.window_minutes,
                )
                if value > dep.rollback_policy.threshold:
                    logger.warning(
                        "Auto-rollback triggered for '%s': %s=%.3f > threshold=%.3f",
                        prompt_id, dep.rollback_policy.metric, value,
                        dep.rollback_policy.threshold,
                    )
                    self.rollback(prompt_id)
                    rolled_back.append(prompt_id)
            except Exception as e:
                logger.error("Failed to check rollback policy for '%s': %s", prompt_id, e)
        return rolled_back

    def invalidate_cache(self) -> None:
        """Force reload from DB on next access."""
        with self._lock:
            self._versions_cache.clear()
            self._deployments_cache.clear()
            self._loaded = False
