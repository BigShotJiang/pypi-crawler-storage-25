"""Prompt diff engine — unified text diff between prompt versions."""
from __future__ import annotations

import difflib

from .models import PromptDiff


def diff_prompts(
    old_template: str,
    new_template: str,
    old_version: str = "old",
    new_version: str = "new",
) -> PromptDiff:
    """Generate a unified diff between two prompt templates.

    Returns a PromptDiff with the unified diff string and line-level
    addition/deletion counts.
    """
    old_lines = old_template.splitlines(keepends=True)
    new_lines = new_template.splitlines(keepends=True)

    diff_lines = list(difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile=f"v{old_version}",
        tofile=f"v{new_version}",
        lineterm="",
    ))

    additions = sum(1 for line in diff_lines if line.startswith("+") and not line.startswith("+++"))
    deletions = sum(1 for line in diff_lines if line.startswith("-") and not line.startswith("---"))

    return PromptDiff(
        old_version=old_version,
        new_version=new_version,
        unified_diff="\n".join(diff_lines),
        additions=additions,
        deletions=deletions,
        old_template=old_template,
        new_template=new_template,
    )
