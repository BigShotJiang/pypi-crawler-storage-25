"""Context-variable trace propagation for CoreIQ."""
import uuid
from contextlib import contextmanager, contextmanager as _contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class SpanKind(str, Enum):
    """Semantic kind of a trace span, aligned with OTel GenAI semconv."""

    LLM = "llm"
    TOOL = "tool"
    AGENT = "agent"
    RETRIEVAL = "retrieval"
    RERANK = "rerank"
    SESSION = "session"


_current_trace_id: ContextVar[Optional[str]] = ContextVar('_current_trace_id', default=None)
_current_span_id: ContextVar[Optional[str]] = ContextVar('_current_span_id', default=None)
_current_session_id: ContextVar[Optional[str]] = ContextVar('_current_session_id', default=None)
_current_agent_run_id: ContextVar[Optional[str]] = ContextVar('_current_agent_run_id', default=None)


def get_current_trace_id() -> Optional[str]:
    """Return the trace ID set by the innermost active :func:`trace` context, or None."""
    return _current_trace_id.get()


def get_current_span_id() -> Optional[str]:
    """Return the span ID of the innermost active span, or None."""
    return _current_span_id.get()


def get_current_session_id() -> Optional[str]:
    """Return the session ID set by the innermost active :func:`session` context, or None."""
    return _current_session_id.get()


def get_current_agent_run_id() -> Optional[str]:
    """Return the agent run ID set by the innermost active :func:`agent_run` context, or None."""
    return _current_agent_run_id.get()


@dataclass
class TraceSpan:
    """Lightweight span record produced by :func:`trace`, :func:`session`, and :func:`agent_run`."""

    id: str
    name: str
    kind: SpanKind = SpanKind.LLM
    parent_id: Optional[str] = None
    session_id: Optional[str] = None
    agent_run_id: Optional[str] = None
    attributes: dict = field(default_factory=dict)


@contextmanager
def trace(name: str, trace_id: Optional[str] = None, *, kind: SpanKind = SpanKind.LLM, parent: Optional[TraceSpan] = None):
    """Context manager that sets a trace_id for all nested CoreIQ calls.

    Usage::

        with coreiq.trace("agent-task") as span:
            coreiq.log_event("step 1")  # auto-carries span.id as trace_id

        # With hierarchy:
        with coreiq.trace("llm-call", kind=SpanKind.LLM, parent=parent_span) as span:
            ...
    """
    tid = trace_id or str(uuid.uuid4())
    parent_id = parent.id if parent else _current_span_id.get()
    session_id = _current_session_id.get()
    agent_run_id = _current_agent_run_id.get()

    token_trace = _current_trace_id.set(tid)
    token_span = _current_span_id.set(tid)
    span = TraceSpan(
        id=tid,
        name=name,
        kind=kind,
        parent_id=parent_id,
        session_id=session_id,
        agent_run_id=agent_run_id,
    )
    try:
        yield span
    finally:
        _current_trace_id.reset(token_trace)
        _current_span_id.reset(token_span)


@contextmanager
def session(name: str, session_id: Optional[str] = None):
    """Context manager for grouping agent runs under a user session.

    Usage::

        with coreiq.session("user-session-abc") as sess:
            with coreiq.agent_run("research-agent", session_id=sess.id) as run:
                ...
    """
    sid = session_id or str(uuid.uuid4())
    token = _current_session_id.set(sid)
    span = TraceSpan(id=sid, name=name, kind=SpanKind.SESSION)
    try:
        yield span
    finally:
        _current_session_id.reset(token)


@contextmanager
def agent_run(name: str, *, session_id: Optional[str] = None, agent_run_id: Optional[str] = None):
    """Context manager for an agent execution — groups multiple LLM/tool spans.

    Usage::

        with coreiq.agent_run("research-agent") as run:
            with coreiq.trace("llm-call", kind=SpanKind.LLM, parent=run) as span:
                ...
    """
    rid = agent_run_id or str(uuid.uuid4())
    sid = session_id or _current_session_id.get()

    token_run = _current_agent_run_id.set(rid)
    token_span = _current_span_id.set(rid)
    if sid:
        token_sess = _current_session_id.set(sid)
    else:
        token_sess = None

    span = TraceSpan(
        id=rid,
        name=name,
        kind=SpanKind.AGENT,
        session_id=sid,
    )
    try:
        yield span
    finally:
        _current_agent_run_id.reset(token_run)
        _current_span_id.reset(token_span)
        if token_sess is not None:
            _current_session_id.reset(token_sess)


# ---------------------------------------------------------------------------
# Agent orchestration helpers (PraisonAI-style)
# ---------------------------------------------------------------------------

@_contextmanager
def handoff(from_agent: str, to_agent: str, *, reason: str = "", session_id: Optional[str] = None):
    """No-op stub — agent span hierarchy tracing removed."""
    import uuid as _uuid
    yield f"handoff-{_uuid.uuid4().hex[:16]}"


@_contextmanager
def parallel_branch(name: str, *, parent_span_id: Optional[str] = None, session_id: Optional[str] = None):
    """No-op stub — agent span hierarchy tracing removed."""
    import uuid as _uuid
    yield f"branch-{_uuid.uuid4().hex[:16]}"
