"""Hooks engine package for CoreIQ — composable event-driven middleware."""
from .engine import HookEngine, HookEvent, get_hook_engine

__all__ = ["HookEngine", "HookEvent", "get_hook_engine"]
