from __future__ import annotations

import asyncio
from enum import Enum
from typing import Callable, Awaitable


class HookEvent(str, Enum):
    BEFORE_LLM = "before_llm"
    AFTER_LLM = "after_llm"
    BEFORE_TOOL = "before_tool"
    AFTER_TOOL = "after_tool"
    ON_VIOLATION = "on_violation"
    ON_INCIDENT = "on_incident"
    ON_ERROR = "on_error"


Handler = Callable[[dict], "Awaitable[dict] | dict"]


class HookEngine:
    def __init__(self) -> None:
        self._handlers: dict[str, list[tuple[int, Handler]]] = {}

    def register(self, event: HookEvent | str, handler: Handler, priority: int = 0) -> None:
        key = str(event)
        self._handlers.setdefault(key, [])
        self._handlers[key].append((priority, handler))
        self._handlers[key].sort(key=lambda x: x[0])

    def unregister(self, event: HookEvent | str, handler: Handler) -> None:
        key = str(event)
        self._handlers[key] = [
            (p, h) for p, h in self._handlers.get(key, []) if h is not handler
        ]

    async def emit(self, event: HookEvent | str, context: dict) -> dict:
        key = str(event)
        for _, handler in self._handlers.get(key, []):
            try:
                result = handler(context)
                if asyncio.iscoroutine(result):
                    result = await result
                if isinstance(result, dict):
                    context = {**context, **result}
            except Exception:
                pass
        return context


def create_budget_limit_policy(max_usd: float) -> Callable:
    async def handler(ctx: dict) -> dict:
        if ctx.get("estimated_cost_usd", 0) > max_usd:
            ctx["blocked"] = True
            ctx["block_reason"] = f"Budget limit ${max_usd} exceeded"
        return ctx

    return handler


def create_deny_tools_policy(tool_names: list[str]) -> Callable:
    async def handler(ctx: dict) -> dict:
        tools = ctx.get("tools", [])
        denied = [t for t in tools if t.get("function", {}).get("name") in tool_names]
        if denied:
            ctx["blocked"] = True
            ctx["block_reason"] = f"Denied tools: {denied}"
        return ctx

    return handler


def create_read_only_policy() -> Callable:
    return create_deny_tools_policy(["write", "create", "delete", "update", "insert", "modify"])


_engine: HookEngine | None = None


def get_hook_engine() -> HookEngine:
    global _engine
    if _engine is None:
        _engine = HookEngine()
    return _engine
