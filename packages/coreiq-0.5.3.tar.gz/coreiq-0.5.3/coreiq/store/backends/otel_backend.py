"""DB-optional OpenTelemetry storage backend.

``OtelBackend`` is a :class:`StorageBackend` that ships every CoreIQ write to
an OpenTelemetry collector instead of persisting it to a relational/document
database. Reads are served from a small in-memory **ring buffer** keyed by
table name so the dashboard's "last-N events" panes still work without a DB.

What this is for
----------------
Enterprises that already operate Honeycomb / Datadog / Grafana Tempo /
Splunk + an OTel collector don't want to operate yet another database just
for AI traces. ``COREIQ_STORE_BACKEND=otel`` makes CoreIQ a pure source of
``gen_ai.*`` spans + ``coreiq.policy.*`` / ``coreiq.security.*`` /
``coreiq.cost.*`` log records — the customer's existing observability stack
becomes the system of record.

Limitations (degradation matrix lives in ``docs/otel-only.md``)
---------------------------------------------------------------
* No historical queries, no aggregates, no ``WHERE`` clauses beyond table
  filtering. The dashboard pages that compute aggregates over months of
  history (e.g. cost-by-tenant breakdown, audit-chain verification) cannot
  function in this mode and surface a soft warning instead.
* No durable audit chain. The OTel collector is the audit trail; CoreIQ's
  HMAC-chained ``audit_chain`` table requires SQL ordering guarantees.
* All reads are restricted to ``COREIQ_OTEL_DASHBOARD_BUFFER`` rows
  (default 1000) **per table, per process**. Restarts wipe the buffer.

Configuration
-------------
``OTEL_EXPORTER_OTLP_ENDPOINT``       – traces/logs/metrics fallback endpoint
``OTEL_EXPORTER_OTLP_LOGS_ENDPOINT``  – optional logs override
``OTEL_EXPORTER_OTLP_METRICS_ENDPOINT`` – optional metrics override
``COREIQ_OTEL_DASHBOARD_BUFFER``      – ring-buffer maxlen (default 1000)
``COREIQ_OTEL_TEST_MODE=1``           – use ``InMemory*Exporter`` (tests)
"""
from __future__ import annotations

import collections
import logging
import os
import re
import threading
import time
from typing import TYPE_CHECKING, Any, Optional

from .base import StorageBackend
from ...exceptions import ConfigError

if TYPE_CHECKING:
    from opentelemetry._logs import Logger
    from opentelemetry.metrics import Counter
    from opentelemetry.sdk.metrics.export import MetricExporter
    from opentelemetry.sdk.trace.export import SpanExporter
    from opentelemetry.trace import Tracer


logger = logging.getLogger("coreiq.store.otel_backend")


# ---------------------------------------------------------------------------
# Process-wide singleton — every thread shares one OtelBackend instance
# (and therefore one TracerProvider/LoggerProvider/MeterProvider).
# Creating a TracerProvider per thread orphans spans into separate traces
# and double-installs OTLP exporters that hold onto sockets/file handles.
# ---------------------------------------------------------------------------
_otel_singleton: Optional["OtelBackend"] = None
_otel_singleton_lock = threading.Lock()


def get_otel_backend() -> "OtelBackend":
    """Return the process-wide :class:`OtelBackend` singleton.

    The factory is double-checked-locked so concurrent first calls don't
    each construct their own provider stack.
    """
    global _otel_singleton
    if _otel_singleton is None:
        with _otel_singleton_lock:
            if _otel_singleton is None:
                _otel_singleton = OtelBackend()
    return _otel_singleton


def _reset_otel_singleton() -> None:
    """Test hook — drops the cached singleton so the next call rebuilds it."""
    global _otel_singleton
    with _otel_singleton_lock:
        if _otel_singleton is not None:
            try:
                _otel_singleton.close()
            except Exception:
                pass
        _otel_singleton = None


# Regexes are intentionally permissive — the writer's SQL is well-formed but
# we want to tolerate whitespace/newlines and ``INSERT OR REPLACE INTO``.
_INSERT_RE = re.compile(
    r"^\s*INSERT\s+(?:OR\s+\w+\s+)?INTO\s+([A-Za-z_][A-Za-z0-9_]*)",
    re.IGNORECASE,
)
_SELECT_FROM_RE = re.compile(
    r"\bFROM\s+([A-Za-z_][A-Za-z0-9_]*)",
    re.IGNORECASE,
)
_VALUES_COLS_RE = re.compile(
    r"INSERT\s+(?:OR\s+\w+\s+)?INTO\s+[A-Za-z_][A-Za-z0-9_]*\s*\(([^)]+)\)",
    re.IGNORECASE,
)
# Wave 3A: also extract the VALUES (...) placeholder list so we can
# reject INSERTs where the column count and placeholder count disagree
# — those rows would produce silently truncated dict() pairs and ship
# spans with missing attributes.
_VALUES_PLACEHOLDERS_RE = re.compile(
    r"VALUES\s*\(([^)]+)\)",
    re.IGNORECASE,
)
# Tokens that indicate a SELECT we cannot meaningfully serve from a
# per-table ring buffer. JOINs and subqueries multiplex multiple tables;
# returning the rows of the first ``FROM`` token would be silently wrong,
# so we refuse and surface an empty result + warning instead.
_JOIN_RE = re.compile(r"\bJOIN\b", re.IGNORECASE)
_SUBQUERY_RE = re.compile(r"\(\s*SELECT\b", re.IGNORECASE)
_FROM_TOKEN_RE = re.compile(r"\bFROM\b", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Test-mode handles — the InMemory exporters are kept module-level so tests
# can introspect them directly without holding a backend reference.
# ---------------------------------------------------------------------------
_test_span_exporter = None
_test_log_exporter = None


def _reset_test_exporters() -> None:
    """Reset the cached in-memory exporters (used between tests)."""
    global _test_span_exporter, _test_log_exporter
    _test_span_exporter = None
    _test_log_exporter = None


def get_test_span_exporter() -> Any:
    """Return the in-memory span exporter (test-mode only)."""
    return _test_span_exporter


def get_test_log_exporter() -> Any:
    """Return the in-memory log exporter (test-mode only)."""
    return _test_log_exporter


class OtelBackend(StorageBackend):
    """Storage backend that emits OTLP spans/logs instead of writing to a DB.

    Every ``INSERT INTO <table>`` is intercepted, mapped to the OTel attribute
    namespace via :mod:`coreiq.observability.event_attributes` (or the GenAI
    semconv mapper for traces), and shipped to the configured collector. The
    same row is also appended to an in-memory ring buffer so subsequent
    ``SELECT * FROM <table> ... LIMIT N`` queries continue to return rows.
    """

    def __init__(self) -> None:
        self._test_mode = os.environ.get("COREIQ_OTEL_TEST_MODE", "").lower() in ("1", "true", "yes")
        self._buffer_maxlen = int(os.environ.get("COREIQ_OTEL_DASHBOARD_BUFFER", "1000"))
        self._buffers: dict[str, collections.deque[Any]] = collections.defaultdict(self._new_deque)
        self._tracer: Optional[Tracer] = None
        self._otel_logger: Optional[Logger] = None
        self._cost_counter: Optional[Counter] = None
        self._configure_otel_pipeline()

    def _new_deque(self) -> collections.deque[Any]:
        return collections.deque(maxlen=self._buffer_maxlen)

    # ------------------------------------------------------------------
    # OTel pipeline setup
    # ------------------------------------------------------------------

    def _configure_otel_pipeline(self) -> None:
        """Wire up tracer + logger + meter providers.

        In production reads endpoints from the standard OTLP env vars.
        In test mode (``COREIQ_OTEL_TEST_MODE=1``) installs in-memory
        exporters so tests can introspect emitted records.
        """
        global _test_span_exporter, _test_log_exporter
        try:
            from opentelemetry import metrics, trace
            from opentelemetry._logs import set_logger_provider
            from opentelemetry.sdk._logs import LoggerProvider
            from opentelemetry.sdk._logs.export import (
                BatchLogRecordProcessor,
                InMemoryLogRecordExporter,
                SimpleLogRecordProcessor,
            )
            from opentelemetry.sdk.metrics import MeterProvider
            from opentelemetry.sdk.metrics.export import (
                InMemoryMetricReader,
                PeriodicExportingMetricReader,
            )
            from opentelemetry.sdk.resources import SERVICE_NAME, Resource
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import (
                BatchSpanProcessor,
                SimpleSpanProcessor,
            )
            from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
                InMemorySpanExporter,
            )
        except ImportError as exc:  # pragma: no cover - dep advertised in pyproject
            raise ImportError(
                "OtelBackend requires opentelemetry-sdk. Install with: pip install coreiq[otel]"
            ) from exc

        # Build resource: SERVICE_NAME plus any user-supplied attributes from the
        # standard OTEL_RESOURCE_ATTRIBUTES env var (key1=val1,key2=val2).
        resource_attrs: dict[str, str] = {
            SERVICE_NAME: os.environ.get("OTEL_SERVICE_NAME", "coreiq"),
        }
        if os.environ.get("OTEL_SERVICE_VERSION"):
            resource_attrs["service.version"] = os.environ["OTEL_SERVICE_VERSION"]
        for pair in (os.environ.get("OTEL_RESOURCE_ATTRIBUTES") or "").split(","):
            pair = pair.strip()
            if "=" in pair:
                k, _, v = pair.partition("=")
                k, v = k.strip(), v.strip()
                if k:
                    resource_attrs[k] = v
        resource = Resource.create(resource_attrs)
        traces_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
        logs_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_LOGS_ENDPOINT") or traces_endpoint
        metrics_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT") or traces_endpoint

        if not self._test_mode and not traces_endpoint:
            raise ConfigError(
                "OtelBackend requires COREIQ_OTEL_ENDPOINT or OTEL_EXPORTER_OTLP_ENDPOINT",
                hint="Set COREIQ_OTEL_ENDPOINT=http://otel-collector:4317 or use "
                     "COREIQ_STORE_BACKEND=clickhouse for local dev."
            )

        # ---- Tracer ----
        from opentelemetry.trace import TracerProvider as APITracerProvider
        tracer_provider: APITracerProvider = TracerProvider(resource=resource)
        if self._test_mode:
            _test_span_exporter = InMemorySpanExporter()
            tracer_provider.add_span_processor(SimpleSpanProcessor(_test_span_exporter))  # type: ignore[attr-defined,unused-ignore]
        else:
            assert traces_endpoint is not None  # guarded above
            span_exp = _build_otlp_span_exporter(traces_endpoint)
            if span_exp is not None:
                tracer_provider.add_span_processor(BatchSpanProcessor(span_exp))  # type: ignore[attr-defined,unused-ignore]
        # In production we install the provider globally so other CoreIQ
        # callers (proxy pipeline, MCP server) reuse the same exporter. In
        # test mode we keep providers per-instance so each test gets a clean
        # exporter — set_*_provider() refuses to be re-set within a process.
        # If the host application has already installed a real TracerProvider
        # (i.e. user wired their own instrumentation), respect it and attach
        # our exporter to it instead of replacing it.
        if not self._test_mode:
            existing = trace.get_tracer_provider()
            is_default = type(existing).__name__ in ("ProxyTracerProvider", "NoOpTracerProvider")
            if is_default:
                try:
                    trace.set_tracer_provider(tracer_provider)
                except Exception:
                    pass
            else:
                # Add our span processor to the user's provider; never replace.
                if hasattr(existing, "add_span_processor") and not _RESPECT_EXISTING_DISABLED():
                    assert traces_endpoint is not None  # guarded above
                    span_exp2 = _build_otlp_span_exporter(traces_endpoint)
                    if span_exp2 is not None:
                        try:
                            existing.add_span_processor(BatchSpanProcessor(span_exp2))  # type: ignore[attr-defined,unused-ignore]
                        except Exception:
                            pass
                tracer_provider = existing  # use the user's
        self._tracer_provider = tracer_provider
        self._tracer = tracer_provider.get_tracer("coreiq.otel_backend")

        # ---- Logger ----
        from opentelemetry._logs import LoggerProvider as APILoggerProvider
        logger_provider: APILoggerProvider = LoggerProvider(resource=resource)
        if self._test_mode:
            _test_log_exporter = InMemoryLogRecordExporter()
            logger_provider.add_log_record_processor(SimpleLogRecordProcessor(_test_log_exporter))  # type: ignore[attr-defined,unused-ignore]
        else:
            assert logs_endpoint is not None  # logs_endpoint falls back to traces_endpoint, which is guarded
            log_exp = _build_otlp_log_exporter(logs_endpoint)
            if log_exp is not None:
                logger_provider.add_log_record_processor(BatchLogRecordProcessor(log_exp))  # type: ignore[attr-defined,unused-ignore]
        if not self._test_mode:
            try:
                from opentelemetry._logs import get_logger_provider
                existing_lp = get_logger_provider()
                is_default_lp = type(existing_lp).__name__ in ("ProxyLoggerProvider", "NoOpLoggerProvider")
                if is_default_lp:
                    set_logger_provider(logger_provider)
                else:
                    if hasattr(existing_lp, "add_log_record_processor") and not _RESPECT_EXISTING_DISABLED():
                        assert logs_endpoint is not None
                        log_exp2 = _build_otlp_log_exporter(logs_endpoint)
                        if log_exp2 is not None:
                            try:
                                existing_lp.add_log_record_processor(BatchLogRecordProcessor(log_exp2))  # type: ignore[attr-defined,unused-ignore]
                            except Exception:
                                pass
                    logger_provider = existing_lp
            except Exception:
                pass
        self._logger_provider = logger_provider
        self._otel_logger = logger_provider.get_logger("coreiq.otel_backend")

        # ---- Meter ----
        from opentelemetry.metrics import MeterProvider as APIMeterProvider
        from opentelemetry.sdk.metrics.export import MetricReader
        reader: Optional[MetricReader]
        if self._test_mode:
            reader = InMemoryMetricReader()
        else:
            assert metrics_endpoint is not None
            metric_exp = _build_otlp_metric_exporter(metrics_endpoint)
            reader = PeriodicExportingMetricReader(metric_exp) if metric_exp is not None else None
        meter_provider: APIMeterProvider = MeterProvider(
            resource=resource,
            metric_readers=[reader] if reader is not None else [],
        )
        if not self._test_mode:
            try:
                existing_mp = metrics.get_meter_provider()
                is_default_mp = type(existing_mp).__name__ in (
                    "ProxyMeterProvider", "NoOpMeterProvider", "_DefaultMeterProvider",
                )
                if is_default_mp:
                    metrics.set_meter_provider(meter_provider)
                else:
                    # Can't add readers to an existing provider — leave it alone.
                    meter_provider = existing_mp
            except Exception:
                pass
        self._meter_provider = meter_provider
        meter = meter_provider.get_meter("coreiq.otel_backend")
        self._cost_counter = meter.create_counter(
            "coreiq.cost.usd",
            unit="USD",
            description="Cumulative LLM cost shipped to the OTel backend.",
        )

    # ------------------------------------------------------------------
    # StorageBackend interface
    # ------------------------------------------------------------------

    def execute(self, sql: str, params: tuple = ()) -> Any:
        """Intercept ``INSERT`` statements; ignore the rest.

        DDL (``CREATE``/``ALTER``), ``DELETE``, and ``UPDATE`` are silently
        no-ops — there's no underlying database to mutate. Logged at debug
        level so accidental writes are still visible in test runs.
        """
        verb = sql.lstrip().split(None, 1)[0].upper() if sql.strip() else ""
        if verb == "INSERT":
            self._handle_insert(sql, params)
            return _NoopCursor()
        if verb in ("CREATE", "ALTER", "DROP", "PRAGMA", "BEGIN", "COMMIT"):
            logger.debug("OtelBackend: ignoring DDL/control statement: %.60s", sql)
            return _NoopCursor()
        if verb in ("DELETE", "UPDATE"):
            logger.debug("OtelBackend: ignoring %s — no DB to mutate", verb)
            return _NoopCursor()
        # Fall-through: return an empty cursor; SELECTs route via fetchall/fetchone.
        return _NoopCursor()

    def executescript(self, script: str) -> None:
        """No-op: ``OtelBackend`` has no schema to materialise."""
        logger.debug("OtelBackend: executescript ignored (no DDL backend)")

    def commit(self) -> None:
        """No-op: every write is shipped synchronously via the OTel SDK."""

    def rollback(self) -> None:
        """No-op: nothing to roll back."""

    def fetchall(self, sql: str, params: tuple = ()) -> list:
        """Return the ring buffer for the table referenced in ``FROM <name>``.

        Historical filters and aggregates are unsupported — callers receive
        the most recent rows the process has seen. The return type matches
        the SQLite ``Row`` shape (mapping access supported via dict).

        SELECTs containing ``JOIN``, subqueries, or multiple ``FROM`` tokens
        cannot be served from a per-table ring buffer — we'd silently return
        rows from only the first table. Such queries are rejected with an
        empty list + warning so the dashboard surface degrades visibly
        rather than displaying wrong data.
        """
        unsupported = self._unsupported_select_feature(sql)
        if unsupported is not None:
            logger.warning(
                "OtelBackend: unsupported SELECT feature %s — returning []. "
                "Dashboard panes that need cross-table joins are not "
                "available with the OTel backend; query: %.120s",
                unsupported,
                sql,
            )
            return []
        table = self._table_from_select(sql)
        if table is None:
            return []
        rows = list(self._buffers.get(table, ()))
        # Dashboard ``ORDER BY ts DESC LIMIT N`` semantics — newest first.
        rows.reverse()
        return rows

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        rows = self.fetchall(sql, params)
        return rows[0] if rows else None

    def close(self) -> None:
        """Flush in-flight OTel batches then drop buffer references."""
        for provider in (
            getattr(self, "_tracer_provider", None),
            getattr(self, "_logger_provider", None),
            getattr(self, "_meter_provider", None),
        ):
            try:
                if provider is None:
                    continue
                if hasattr(provider, "force_flush"):
                    provider.force_flush(timeout_millis=2000)
                if hasattr(provider, "shutdown"):
                    provider.shutdown()
            except Exception:
                pass
        self._buffers.clear()

    @property
    def backend_type(self) -> str:
        return "otel"

    # ------------------------------------------------------------------
    # Insert dispatch
    # ------------------------------------------------------------------

    def _handle_insert(self, sql: str, params: tuple) -> None:
        m = _INSERT_RE.match(sql)
        if not m:
            logger.debug("OtelBackend: unparseable INSERT: %.60s", sql)
            return
        table = m.group(1)
        row = self._build_row(sql, params)
        if row is None:
            logger.error(
                "OtelBackend: rejecting column-less INSERT into %s — "
                "writers must use an explicit ``INSERT INTO tbl (col, ...) "
                "VALUES (...)`` form so emitted spans/logs carry meaningful "
                "attributes; statement skipped: %.120s",
                table,
                sql,
            )
            return
        # Always append to the ring buffer — drives dashboard reads.
        self._buffers[table].append(row)

        # Route to the appropriate OTel signal.
        try:
            if table == "traces":
                self._emit_trace_span(row)
            elif table == "policy_decisions":
                self._emit_policy_decision(row)
            elif table == "security_violations":
                self._emit_security_violation(row)
            elif table == "events":
                self._emit_event_log(row)
            elif table == "audit_chain":
                self._emit_audit_log(row)
            else:
                # Anything else (cache_events, tool_calls, feedback, ...) is
                # logged at debug level so tests can still introspect via
                # the ring buffer without flooding the collector.
                self._emit_generic_log(table, row)
        except Exception as exc:  # never let observability writes raise
            logger.debug("OtelBackend: emit for %s failed: %s", table, exc)

    @staticmethod
    def _build_row(sql: str, params: tuple) -> Optional[dict[str, Any]]:
        """Reconstruct a column→value dict from the INSERT SQL + params.

        Returns ``None`` when the INSERT omits an explicit column list — the
        caller treats that as a hard error and skips the row. Falling back to
        ``col0/col1/...`` keys would silently drop the row's semantic content
        (provider/model/etc end up as ``None`` in emitted spans), which the
        dashboard then has no way to surface as missing.

        Wave 3A: also returns ``None`` (and logs an error) when the column
        list and the VALUES placeholder list disagree on count. Pairing them
        with ``zip()`` would silently truncate to the shorter list, again
        shipping spans with missing/wrong attributes.
        """
        cols_match = _VALUES_COLS_RE.search(sql)
        if not cols_match:
            return None
        cols = [c.strip() for c in cols_match.group(1).split(",")]
        ph_match = _VALUES_PLACEHOLDERS_RE.search(sql)
        if ph_match is not None:
            placeholders = [p.strip() for p in ph_match.group(1).split(",") if p.strip()]
            if len(placeholders) != len(cols):
                logger.error(
                    "OtelBackend: rejecting INSERT with mismatched column/value count "
                    "(columns=%d, placeholders=%d) — silent truncation would drop "
                    "semantic attributes from the emitted span/log; statement "
                    "skipped: %.160s",
                    len(cols),
                    len(placeholders),
                    sql,
                )
                return None
        return dict(zip(cols, params))

    @staticmethod
    def _table_from_select(sql: str) -> Optional[str]:
        m = _SELECT_FROM_RE.search(sql or "")
        return m.group(1) if m else None

    @staticmethod
    def _unsupported_select_feature(sql: str) -> Optional[str]:
        """Return the name of the unsupported feature in ``sql``, or ``None``.

        We can't serve JOINs / subqueries / multi-FROM SELECTs from a
        per-table ring buffer — the regex would happily latch onto the first
        ``FROM`` and return rows for the wrong table. Explicit rejection
        beats silent corruption.
        """
        if not sql:
            return None
        if _JOIN_RE.search(sql):
            return "JOIN"
        if _SUBQUERY_RE.search(sql):
            return "subquery"
        if len(_FROM_TOKEN_RE.findall(sql)) > 1:
            return "multiple FROM clauses"
        return None

    # ------------------------------------------------------------------
    # OTel signal emitters
    # ------------------------------------------------------------------

    def _emit_trace_span(self, row: dict[str, Any]) -> None:
        """Map a ``traces`` row to a GenAI span.

        Uses the ambient OTel context (``opentelemetry.context.get_current``)
        as the parent so the emitted span shares trace_id with the in-flight
        request span — preserving W3C ``traceparent`` continuity for callers
        that propagate it. Without an explicit parent context, a backend
        thread or executor pool would orphan the span into its own trace.
        """
        from opentelemetry.context import get_current
        from opentelemetry.trace import SpanKind, StatusCode

        from ...observability.genai_attributes import GenAIAttrs, apply as apply_genai

        assert self._tracer is not None
        # Wave 3A: OTel GenAI semconv v1.28+ recommends span names of the
        # form ``"<operation> <model>"`` (e.g. ``"chat gpt-4o"``) so trace
        # UIs can group spans by operation+model without parsing
        # attributes. Fall back to ``"gen_ai.chat"`` when the model is
        # unknown — preserves the legacy name for tests that rely on it.
        model = row.get("model")
        span_name = f"chat {model}" if model else "gen_ai.chat"
        with self._tracer.start_as_current_span(
            span_name,
            context=get_current(),
            kind=SpanKind.CLIENT,
        ) as span:
            attrs = GenAIAttrs(
                system=row.get("provider"),
                operation="chat",
                request_model=row.get("model"),
                input_tokens=row.get("input_tok"),
                output_tokens=row.get("output_tok"),
                finish_reasons=[row["finish_reason"]] if row.get("finish_reason") else [],
                latency_ms=row.get("latency_ms"),
                ttft_ms=row.get("ttft_ms"),
                cost_usd=row.get("cost_usd"),
                tenant_id=row.get("tenant_id"),
                virtual_key_id=row.get("virtual_key_id"),
                cache_hit=bool(row["cache_hit"]) if row.get("cache_hit") is not None else None,
            )
            apply_genai(span, attrs)
            span.set_status(StatusCode.OK)

        # Cost roll-up — one counter increment per trace with cost.
        if row.get("cost_usd"):
            try:
                from ...observability.event_attributes import CostEventAttrs
                cost_attrs = CostEventAttrs.from_row(row).apply()
                assert self._cost_counter is not None
                self._cost_counter.add(float(row["cost_usd"]), attributes=cost_attrs)
            except Exception:
                pass

    def _emit_policy_decision(self, row: dict[str, Any]) -> None:
        from opentelemetry._logs import SeverityNumber

        from ...observability.event_attributes import PolicyDecisionAttrs
        attrs = PolicyDecisionAttrs.from_row(row).apply()
        assert self._otel_logger is not None
        self._otel_logger.emit(
            timestamp=time.time_ns(),
            severity_number=SeverityNumber.INFO,
            severity_text="INFO",
            body=f"policy.decision action={row.get('action')}",
            attributes=attrs,
        )

    def _emit_security_violation(self, row: dict[str, Any]) -> None:
        from opentelemetry._logs import SeverityNumber

        from ...observability.event_attributes import SecurityViolationAttrs
        attrs = SecurityViolationAttrs.from_row(row).apply()
        assert self._otel_logger is not None
        self._otel_logger.emit(
            timestamp=time.time_ns(),
            severity_number=SeverityNumber.WARN,
            severity_text="WARN",
            body=f"security.violation category={row.get('category')}",
            attributes=attrs,
        )

    def _emit_event_log(self, row: dict[str, Any]) -> None:
        from opentelemetry._logs import SeverityNumber

        from ...observability.event_attributes import _drop_none

        level = (row.get("level") or "info").upper()
        sev = {
            "DEBUG": SeverityNumber.DEBUG,
            "INFO": SeverityNumber.INFO,
            "WARN": SeverityNumber.WARN,
            "WARNING": SeverityNumber.WARN,
            "ERROR": SeverityNumber.ERROR,
            "CRITICAL": SeverityNumber.FATAL,
        }.get(level, SeverityNumber.INFO)
        # OTel SDK rejects ``None`` attribute values (some exporters crash
        # outright). Drop them up-front rather than on the export path.
        attrs = _drop_none({
            "coreiq.event.source": row.get("source"),
            "coreiq.tenant_id": row.get("tenant_id"),
            "coreiq.trace_id": row.get("trace_id"),
        })
        assert self._otel_logger is not None
        self._otel_logger.emit(
            timestamp=time.time_ns(),
            severity_number=sev,
            severity_text=level,
            body=row.get("message") or "",
            attributes=attrs,
        )

    def _emit_audit_log(self, row: dict[str, Any]) -> None:
        from opentelemetry._logs import SeverityNumber

        from ...observability.event_attributes import _drop_none

        attrs = _drop_none({
            "coreiq.audit.entry_id": row.get("entry_id"),
            "coreiq.audit.event_id": row.get("event_id"),
            "coreiq.audit.entry_hash": row.get("entry_hash"),
            "coreiq.audit.prev_hash": row.get("prev_hash"),
        })
        assert self._otel_logger is not None
        self._otel_logger.emit(
            timestamp=time.time_ns(),
            severity_number=SeverityNumber.INFO,
            severity_text="INFO",
            body="audit.entry",
            attributes=attrs,
        )

    def _emit_generic_log(self, table: str, row: dict[str, Any]) -> None:
        from opentelemetry._logs import SeverityNumber
        # Only stringify scalars; nested JSON columns stay as-is.
        flat = {f"coreiq.{table}.{k}": v for k, v in row.items() if isinstance(v, (str, int, float, bool))}
        assert self._otel_logger is not None
        self._otel_logger.emit(
            timestamp=time.time_ns(),
            severity_number=SeverityNumber.DEBUG,
            severity_text="DEBUG",
            body=f"coreiq.{table}",
            attributes=flat,
        )


# ---------------------------------------------------------------------------
# OTLP exporter builders — kept module-level so they can be monkey-patched in
# integration tests without standing up the OTel SDK twice.
# ---------------------------------------------------------------------------


def _RESPECT_EXISTING_DISABLED() -> bool:
    """If COREIQ_OTEL_FORCE_OWN_PROVIDER=1, replace the user's provider
    (legacy behavior). Default: respect existing providers."""
    return (os.environ.get("COREIQ_OTEL_FORCE_OWN_PROVIDER", "").strip()
            in ("1", "true", "yes"))


def _otlp_protocol() -> str:
    """Resolve OTLP protocol per spec.

    Precedence:
      1. ``OTEL_EXPORTER_OTLP_PROTOCOL`` (standard env var, ``grpc`` /
         ``http/protobuf``)
      2. CoreIQ alias ``COREIQ_OTEL_PROTOCOL``
      3. Auto-detect: ``http://`` / ``https://`` endpoints → ``http/protobuf``;
         everything else (host:port, ``grpc://``) → ``grpc``.
    """
    p = (os.environ.get("OTEL_EXPORTER_OTLP_PROTOCOL")
         or os.environ.get("COREIQ_OTEL_PROTOCOL")
         or "").strip().lower()
    if p in ("grpc", "http/protobuf", "http"):
        return "http/protobuf" if p == "http" else p
    endpoint = (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or "").lower()
    if endpoint.startswith(("http://", "https://")):
        return "http/protobuf"
    return "grpc"


def _otlp_headers() -> dict[str, str] | None:
    """Parse the standard ``OTEL_EXPORTER_OTLP_HEADERS`` env var.

    Format: ``key1=value1,key2=value2`` (per spec). Returns ``None`` if unset
    so exporters use their default constructor behavior.
    """
    raw = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS")
    if not raw:
        return None
    headers: dict[str, str] = {}
    for pair in raw.split(","):
        pair = pair.strip()
        if "=" in pair:
            k, _, v = pair.partition("=")
            k, v = k.strip(), v.strip()
            if k:
                headers[k] = v
    return headers or None


def _build_otlp_span_exporter(endpoint: str) -> Optional["SpanExporter"]:
    proto = _otlp_protocol()
    headers = _otlp_headers()
    try:
        if proto == "http/protobuf":
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                OTLPSpanExporter as OTLPSpanExporterHTTP,
            )
            url = endpoint.rstrip("/") + ("" if endpoint.rstrip("/").endswith("/v1/traces") else "/v1/traces")
            return OTLPSpanExporterHTTP(endpoint=url, headers=headers)
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
            OTLPSpanExporter as OTLPSpanExporterGRPC,
        )
        return OTLPSpanExporterGRPC(endpoint=endpoint, headers=headers)
    except ImportError as e:  # pragma: no cover
        logger.warning("OTLP span exporter unavailable (%s): %s", proto, e)
        return None


def _build_otlp_log_exporter(endpoint: str) -> Optional[Any]:
    proto = _otlp_protocol()
    headers = _otlp_headers()
    try:
        if proto == "http/protobuf":
            from opentelemetry.exporter.otlp.proto.http._log_exporter import (
                OTLPLogExporter as OTLPLogExporterHTTP,
            )
            url = endpoint.rstrip("/") + ("" if endpoint.rstrip("/").endswith("/v1/logs") else "/v1/logs")
            return OTLPLogExporterHTTP(endpoint=url, headers=headers)
        from opentelemetry.exporter.otlp.proto.grpc._log_exporter import (
            OTLPLogExporter as OTLPLogExporterGRPC,
        )
        return OTLPLogExporterGRPC(endpoint=endpoint, headers=headers)
    except ImportError as e:  # pragma: no cover
        logger.warning("OTLP log exporter unavailable (%s): %s", proto, e)
        return None


def _build_otlp_metric_exporter(endpoint: str) -> Optional["MetricExporter"]:
    proto = _otlp_protocol()
    headers = _otlp_headers()
    try:
        if proto == "http/protobuf":
            from opentelemetry.exporter.otlp.proto.http.metric_exporter import (
                OTLPMetricExporter as OTLPMetricExporterHTTP,
            )
            url = endpoint.rstrip("/") + ("" if endpoint.rstrip("/").endswith("/v1/metrics") else "/v1/metrics")
            return OTLPMetricExporterHTTP(endpoint=url, headers=headers)
        from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
            OTLPMetricExporter as OTLPMetricExporterGRPC,
        )
        return OTLPMetricExporterGRPC(endpoint=endpoint, headers=headers)
    except ImportError as e:  # pragma: no cover
        logger.warning("OTLP metric exporter unavailable (%s): %s", proto, e)
        return None


class _NoopCursor:
    """Minimal cursor shim returned by ``OtelBackend.execute``.

    The :class:`coreiq.store.writer.EventWriter` doesn't read cursors after
    inserts, but a few migration paths call ``cursor.rowcount``; we expose
    the attribute to keep ``isinstance``/``hasattr`` checks happy.
    """

    rowcount = 0

    def fetchall(self) -> list:
        return []

    def fetchone(self) -> None:
        return None
