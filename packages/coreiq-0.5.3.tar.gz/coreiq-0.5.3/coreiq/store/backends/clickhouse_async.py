"""Async ClickHouse backend (clickhouse-connect async client)."""
from __future__ import annotations

import logging
from typing import Any, Optional

from coreiq.exceptions import StorageError

from .async_base import AsyncStorageBackend

logger = logging.getLogger("coreiq.store.clickhouse_async")


class ClickHouseAsyncBackend(AsyncStorageBackend):
    backend_type_value = "clickhouse"

    def __init__(self, dsn: str, database: str = "coreiq") -> None:
        self._dsn = dsn
        self._database = database
        self._client: Any = None

    async def _ensure_client(self) -> Any:
        if self._client is not None:
            return self._client
        try:
            from clickhouse_connect import get_async_client  # type: ignore[import-untyped]
        except ImportError as exc:
            raise StorageError(
                "clickhouse-connect>=0.7 required — install coreiq[clickhouse]"
            ) from exc
        self._client = await get_async_client(dsn=self._dsn, database=self._database)
        return self._client

    async def aexecute(self, sql: str, params: tuple = ()) -> Any:
        client = await self._ensure_client()
        return await client.command(sql, parameters=params or None)

    async def afetchall(self, sql: str, params: tuple = ()) -> list:
        client = await self._ensure_client()
        result = await client.query(sql, parameters=params or None)
        return [dict(zip(result.column_names, row)) for row in result.result_rows]

    async def afetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        rows = await self.afetchall(sql, params)
        return rows[0] if rows else None

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.close()
            self._client = None

    @property
    def backend_type(self) -> str:
        return self.backend_type_value
