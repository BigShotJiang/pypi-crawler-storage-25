from typing import Callable

from .base import StorageBackend
from .clickhouse_backend import ClickHouseBackend, create_clickhouse_backend
from .mongo_backend import MongoBackend, create_mongo_backend
from .mongo_schema import COLLECTION_MAP, get_collection
from .otel_backend import OtelBackend


# Public registry mapping ``COREIQ_STORE_BACKEND`` keys to a zero-arg factory.
# Backends that need configuration (postgres DSN, mongo URI) read it from the
# central config inside their factory closure — see ``store/db.py``.
BACKEND_REGISTRY: dict[str, Callable[[], StorageBackend]] = {
    "otel": OtelBackend,
}


__all__ = [
    "StorageBackend",
    "MongoBackend",
    "create_mongo_backend",
    "ClickHouseBackend",
    "create_clickhouse_backend",
    "OtelBackend",
    "COLLECTION_MAP",
    "get_collection",
    "BACKEND_REGISTRY",
]
