"""PostgreSQL storage backend — for production multi-instance deployments.

Requires: pip install coreiq[postgres]  (installs psycopg2-binary)

Configuration (coreiq.toml):
    [store]
    backend = "postgres"
    postgres_dsn = "postgresql://user:pass@host:5432/coreiq"

Or via env var:
    COREIQ_POSTGRES_DSN=postgresql://user:pass@host:5432/coreiq

All SQL goes through :func:`coreiq.store.dialect.to_postgres` before being
handed to psycopg2 — ``?`` placeholders become ``%s`` and
``INSERT OR REPLACE`` becomes ``INSERT ... ON CONFLICT DO UPDATE`` so callers
can keep writing portable SQLite-flavored SQL.

Thread safety: uses ``psycopg2.pool.ThreadedConnectionPool`` so that multiple
FastAPI worker threads can call ``execute``/``fetchall``/``fetchone``
concurrently without sharing a TCP socket.  Each public method acquires a
connection from the pool, does its work, and returns the connection before
returning to the caller.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator, Optional

from .. import dialect
from .base import StorageBackend


class _CursorResult:
    """Lightweight result wrapper returned by :meth:`PostgresBackend.execute`.

    Callers that relied on the old ``execute()`` returning a live psycopg2
    cursor (and then calling ``.fetchall()``/``.fetchone()``/``.rowcount``)
    continue to work unchanged, because this object pre-fetches all rows
    before the pool connection is returned.
    """

    def __init__(self, rows: list, rowcount: int) -> None:
        self._rows = rows
        self.rowcount = rowcount
        self._pos = 0

    def fetchall(self) -> list:
        return list(self._rows)

    def fetchone(self) -> Optional[Any]:
        if self._pos < len(self._rows):
            row = self._rows[self._pos]
            self._pos += 1
            return row
        return None


class PostgresBackend(StorageBackend):
    """psycopg2-based Postgres backend.

    Uses a ``ThreadedConnectionPool`` so concurrent FastAPI request threads
    each get their own connection rather than sharing one TCP socket.
    All cursors are ``RealDictCursor`` so ``fetchone()``/``fetchall()``
    return dict-like rows that work with ``dict(row)`` and ``row["col"]``.
    """

    def __init__(self, dsn: str, minconn: int = 1, maxconn: int = 10):
        try:
            import psycopg2
            import psycopg2.extras
            import psycopg2.pool
        except ImportError:
            raise ImportError(
                "PostgreSQL backend requires psycopg2. "
                "Install with: pip install coreiq[postgres]"
            )
        self._psycopg2 = psycopg2
        self._extras = psycopg2.extras
        self._pool = psycopg2.pool.ThreadedConnectionPool(
            minconn=minconn,
            maxconn=maxconn,
            dsn=dsn,
        )

    @contextmanager
    def _with_connection(self) -> Iterator[Any]:
        """Context manager: yield a pool connection and return it on exit.

        On exception the connection is rolled back before being returned to
        the pool so subsequent callers do not receive a poisoned connection
        in ``InFailedSqlTransaction`` state.  If rollback itself fails (e.g.
        the socket is dead) the connection is discarded via
        ``putconn(conn, close=True)`` so the pool creates a fresh one.
        """
        conn = self._pool.getconn()
        poisoned = False
        try:
            yield conn
        except Exception:
            poisoned = True
            try:
                conn.rollback()
                poisoned = False  # rollback succeeded — connection is clean
            except Exception:
                pass  # rollback failed — connection is dead, discard it
            raise
        finally:
            if poisoned:
                # Connection couldn't be rolled back — tell the pool to discard it
                self._pool.putconn(conn, close=True)
            else:
                self._pool.putconn(conn)

    def execute(self, sql: str, params: tuple = ()) -> _CursorResult:
        """Execute *sql* with *params* and return a :class:`_CursorResult`.

        For DML statements (INSERT/UPDATE/DELETE/ALTER/CREATE/DROP) the
        transaction is committed automatically before the connection is
        returned to the pool.  For SELECT statements no commit is issued.

        The returned :class:`_CursorResult` supports ``.fetchall()``,
        ``.fetchone()``, and ``.rowcount`` so existing call-sites that chain
        those methods continue to work without modification.
        """
        pg_sql = dialect.to_postgres(sql)
        stripped = pg_sql.lstrip()
        is_select = stripped.upper().startswith("SELECT")

        with self._with_connection() as conn:
            with conn.cursor(cursor_factory=self._extras.RealDictCursor) as cur:
                cur.execute(pg_sql, params if params else None)
                rowcount = cur.rowcount if cur.rowcount is not None else -1
                if is_select:
                    rows = list(cur.fetchall())
                else:
                    rows = []
                    conn.commit()
        return _CursorResult(rows, rowcount)

    def commit(self) -> None:
        """No-op: each :meth:`execute` call commits its own transaction."""

    def rollback(self) -> None:
        """No-op: per-call auto-commit means there is no open transaction."""

    def fetchall(self, sql: str, params: tuple = ()) -> list:
        pg_sql = dialect.to_postgres(sql)
        with self._with_connection() as conn:
            with conn.cursor(cursor_factory=self._extras.RealDictCursor) as cur:
                cur.execute(pg_sql, params if params else None)
                return list(cur.fetchall())

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        pg_sql = dialect.to_postgres(sql)
        with self._with_connection() as conn:
            with conn.cursor(cursor_factory=self._extras.RealDictCursor) as cur:
                cur.execute(pg_sql, params if params else None)
                return cur.fetchone()

    def close(self) -> None:
        try:
            self._pool.closeall()
        except Exception:
            pass

    @property
    def backend_type(self) -> str:
        return "postgres"


def create_postgres_backend(dsn: str) -> PostgresBackend:
    """Create a PostgresBackend from a DSN string."""
    return PostgresBackend(dsn)
