"""ClickHouse storage backend — columnar OLAP for high-volume deployments.

Requires::

    pip install coreiq[clickhouse]   # installs clickhouse-connect

Configuration::

    [store]
    backend = "clickhouse"
    clickhouse_dsn = "http://default:@localhost:8123"
    clickhouse_database = "coreiq"

Or via env vars::

    COREIQ_STORE_BACKEND=clickhouse
    COREIQ_CLICKHOUSE_DSN=http://default:@localhost:8123
    COREIQ_CLICKHOUSE_DATABASE=coreiq

Design notes
------------

- All SQL is translated through :func:`coreiq.store.dialect.to_clickhouse`
  before being sent to the driver. Callers keep writing portable
  SQLite-flavored SQL; the translator rewrites DDL (engines, sort keys,
  index strategy), placeholders, upsert semantics, and appends ``FINAL`` to
  reads against ``ReplacingMergeTree`` tables so mutable-value lookups see
  the latest row before a background merge runs.

- ``INSERT OR REPLACE`` becomes a plain ``INSERT``. The table's registered
  engine is ``ReplacingMergeTree(<version>)`` which dedupes on merge, and
  reads go through ``FINAL`` for correct semantics.

- ClickHouse's HTTP client (clickhouse-connect) is thread-safe and pooled,
  so one shared instance is used across threads (see
  ``store/db.py::get_shared_connection``).
"""
from __future__ import annotations

from typing import Any, Optional

from .. import dialect
from ..dialect import KIND_MUTATION
from .base import StorageBackend


def _inline_params_for_mutation(sql: str, params: tuple) -> str:
    """Inline ``?`` positional params into an ``ALTER TABLE ... UPDATE`` statement.

    ClickHouse mutations run via ``client.command()`` which doesn't accept a
    separate parameter dict, so we embed values directly. String values are
    single-quoted with internal quotes escaped.
    """
    result: list[str] = []
    param_idx = 0
    for ch in sql:
        if ch == "?":
            val = params[param_idx] if param_idx < len(params) else None
            param_idx += 1
            if val is None:
                result.append("NULL")
            elif isinstance(val, bool):
                result.append("1" if val else "0")
            elif isinstance(val, (int, float)):
                result.append(str(val))
            else:
                escaped = str(val).replace("'", "''")
                result.append(f"'{escaped}'")
        else:
            result.append(ch)
    return "".join(result)


class _CursorLike:
    """Minimal cursor stub returned from DDL/INSERT calls.

    Mirrors the attributes that EventWriter reads (``rowcount``) without
    requiring a real driver cursor.
    """

    def __init__(self, rowcount: int = 0):
        self.rowcount = rowcount

    def fetchall(self) -> list:
        return []

    def fetchone(self) -> None:
        return None


class ClickHouseBackend(StorageBackend):
    """ClickHouse backend using ``clickhouse-connect``'s HTTP client."""

    def __init__(self, dsn: str, database: str = "coreiq"):
        try:
            import clickhouse_connect
        except ImportError:
            raise ImportError(
                "ClickHouse backend requires clickhouse-connect. "
                "Install with: pip install coreiq[clickhouse]"
            )
        # Validate database name — identifiers cannot be parameterized in SQL,
        # so we enforce a strict allowlist before interpolating.
        import re as _re
        if not _re.fullmatch(r"[A-Za-z0-9_]+", database):
            raise ValueError(
                f"Invalid COREIQ_CLICKHOUSE_DATABASE name {database!r}. "
                "Only alphanumeric characters and underscores are allowed."
            )
        self._database = database
        # clickhouse-connect accepts either a full DSN via ``dsn=`` or
        # host/port/etc. as kwargs. We use DSN so users can put auth + host
        # in one string (http://default:pw@host:8123 or https://...).
        self._client = clickhouse_connect.get_client(dsn=dsn)
        # Ensure the target database exists, then switch the session into it.
        try:
            self._client.command(f"CREATE DATABASE IF NOT EXISTS {database}")
            self._client.database = database
        except Exception:
            # If we can't create it we'll fail naturally on first real query.
            pass

    # ------------------------------------------------------------------
    # Statement dispatch
    # ------------------------------------------------------------------

    def execute(self, sql: str, params: tuple = ()) -> Any:
        translated, kind = dialect.to_clickhouse(sql)

        if kind == dialect.KIND_SKIP:
            return _CursorLike()

        if kind == dialect.KIND_DDL:
            self._client.command(translated)
            return _CursorLike()

        if kind == KIND_MUTATION:
            # ALTER TABLE ... UPDATE — inline params and run as command()
            self._client.command(_inline_params_for_mutation(translated, params))
            return _CursorLike()

        if kind == dialect.KIND_INSERT:
            return _CursorLike(rowcount=self._insert(translated, params))

        # SELECT / OTHER — use parameterised query API
        rows = self._query(translated, params)
        return _CachedResult(rows)

    def fetchall(self, sql: str, params: tuple = ()) -> list:
        translated, kind = dialect.to_clickhouse(sql)
        if kind == dialect.KIND_SKIP:
            return []
        if kind in (dialect.KIND_DDL, dialect.KIND_INSERT):
            # Unusual — treat as no-op and return empty
            return []
        return self._query(translated, params)

    def _query(self, sql: str, params: tuple) -> list[dict]:
        """Run a SELECT and return ``[dict(row), ...]``."""
        rewritten_sql, named = _rewrite_qmarks(sql, params)
        res = self._client.query(rewritten_sql, parameters=named or None)
        return [dict(zip(res.column_names, row)) for row in res.result_rows]

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        rows = self.fetchall(sql, params)
        return rows[0] if rows else None

    def commit(self) -> None:
        # ClickHouse auto-commits; nothing to flush.
        return None

    def rollback(self) -> None:
        # ClickHouse auto-commits; no-op rollback.
        return None

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:
            pass

    @property
    def backend_type(self) -> str:
        return "clickhouse"

    # ------------------------------------------------------------------
    # Script-mode DDL — split on ; and execute each statement
    # ------------------------------------------------------------------

    def executescript(self, script: str) -> None:
        """Run a semicolon-delimited DDL script.

        Splits on ``;`` while respecting paren depth so multi-line
        ``CREATE TABLE`` blocks survive intact, then executes each statement
        via :meth:`execute` (which routes through the dialect translator).

        Idempotent ``CREATE ... IF NOT EXISTS`` errors are swallowed so a
        second init_schema call on the same database is a no-op; any other
        error propagates so real bugs don't hide.
        """
        depth = 0
        buf: list[str] = []
        stmts: list[str] = []
        for ch in script:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == ";" and depth == 0:
                stmt = "".join(buf).strip()
                if stmt:
                    stmts.append(stmt)
                buf = []
            else:
                buf.append(ch)
        tail = "".join(buf).strip()
        if tail:
            stmts.append(tail)

        for stmt in stmts:
            try:
                self.execute(stmt)
            except Exception as exc:
                msg = str(exc).lower()
                if "already exists" in msg or "code: 57" in msg:
                    continue
                raise

    # ------------------------------------------------------------------
    # INSERT handling — translate ``?`` positional params into a single-row
    # insert via ``client.insert``.
    # ------------------------------------------------------------------

    def _insert(self, sql: str, params: tuple) -> int:
        """Execute an ``INSERT INTO t(cols) VALUES (?,?,...)`` or
        ``INSERT INTO t VALUES (?,?,...)`` using clickhouse-connect's typed
        insert API. Returns the number of rows written (always 1 here)."""
        import re

        m = re.match(
            r"^\s*INSERT\s+INTO\s+(?P<table>[A-Za-z_][A-Za-z0-9_]*)"
            r"\s*(?:\((?P<cols>[^)]*)\))?\s*VALUES\s*\((?P<vals>[^)]*)\)",
            sql,
            re.IGNORECASE | re.DOTALL,
        )
        if not m:
            # Fall back to parameterised command (rare: bulk inserts, etc.)
            self._client.command(sql)
            return 0

        table = m.group("table")
        cols_str = m.group("cols") or ""
        vals_str = m.group("vals") or ""
        cols = [c.strip() for c in cols_str.split(",") if c.strip()] if cols_str else None

        # Build values_row by interleaving ?-bound params with literal values
        # (e.g. INSERT has literal 0 for blocked/spend_usd columns).
        param_idx = 0
        values_row = []
        for token in vals_str.split(","):
            token = token.strip()
            if token == "?":
                values_row.append(params[param_idx] if param_idx < len(params) else None)
                param_idx += 1
            elif token.upper() == "NULL":
                values_row.append(None)
            else:
                try:
                    values_row.append(int(token))
                except ValueError:
                    try:
                        values_row.append(float(token))
                    except ValueError:
                        values_row.append(token.strip("'\""))

        if cols:
            self._client.insert(table, [values_row], column_names=cols)
        else:
            # No column list — positional insert in schema order.
            self._client.insert(table, [values_row])
        return 1

class _CachedResult:
    """Mimics a cursor with preloaded ``fetchall()``/``fetchone()`` results."""

    def __init__(self, rows: list[dict]):
        self._rows = rows
        self.rowcount = len(rows)

    def fetchall(self) -> list[dict]:
        return list(self._rows)

    def fetchone(self) -> Optional[dict]:
        return self._rows[0] if self._rows else None


def _rewrite_qmarks(sql: str, params: tuple) -> tuple[str, dict]:
    """Rewrite ``?`` positional markers to ``{p0:T}``-style params that
    clickhouse-connect's parameterised query API expects.

    Returns ``(rewritten_sql, {"p0": v0, "p1": v1, ...})``. Literal ``?``
    inside string constants is left alone.
    """
    if not params:
        return sql, {}
    out_sql: list[str] = []
    out_params: dict = {}
    idx = 0
    in_str: Optional[str] = None
    i = 0
    while i < len(sql):
        ch = sql[i]
        if in_str:
            out_sql.append(ch)
            if ch == in_str:
                in_str = None
        elif ch in ("'", '"'):
            out_sql.append(ch)
            in_str = ch
        elif ch == "?":
            name = f"p{idx}"
            value = params[idx] if idx < len(params) else None
            out_sql.append(_ch_param_placeholder(name, value))
            out_params[name] = value
            idx += 1
        else:
            out_sql.append(ch)
        i += 1
    return "".join(out_sql), out_params


def _ch_param_placeholder(name: str, value: Any) -> str:
    """Render a ``{name:T}`` placeholder with the ClickHouse type that matches
    the Python ``value``. Defaults to ``String`` for unknowns so NULLs and
    text round-trip safely."""
    if value is None:
        return f"{{{name}:Nullable(String)}}"
    if isinstance(value, bool):
        return f"{{{name}:UInt8}}"
    if isinstance(value, int):
        return f"{{{name}:Int64}}"
    if isinstance(value, float):
        return f"{{{name}:Float64}}"
    return f"{{{name}:String}}"


def create_clickhouse_backend(dsn: str, database: str = "coreiq") -> ClickHouseBackend:
    """Factory for :class:`ClickHouseBackend`."""
    return ClickHouseBackend(dsn, database)
