"""Async storage backend ABC.

The sync ``StorageBackend`` ABC remains the durable interface for the
audit chain and dashboard. Async backends are an optional perf path for
the proxy hot loop on Postgres / Mongo / ClickHouse.

A backend may implement BOTH the sync ABC (for CLI / migrations) AND
this async ABC (for hot-path writes). The two are independent — there
is no requirement that ``execute()`` and ``aexecute()`` share a
connection.

Concrete backends live alongside their sync siblings:
- ``postgres_async.py`` (asyncpg)
- ``mongo_async.py`` (motor)
- ``clickhouse_async.py`` (clickhouse-connect async or chdb)
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional


class AsyncStorageBackend(ABC):
    """Async storage backend interface for hot-path writes."""

    @abstractmethod
    async def aexecute(self, sql: str, params: tuple = ()) -> Any:
        ...

    @abstractmethod
    async def afetchall(self, sql: str, params: tuple = ()) -> list:
        ...

    @abstractmethod
    async def afetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        ...

    @abstractmethod
    async def aclose(self) -> None:
        ...

    @property
    @abstractmethod
    def backend_type(self) -> str:
        ...

    # ---- Document-oriented (Mongo) -------------------------------------

    async def ainsert_document(self, collection: str, doc: dict) -> str:
        raise NotImplementedError

    async def afind_documents(
        self, collection: str, filter_dict: dict, limit: int = 100, skip: int = 0
    ) -> list[dict]:
        raise NotImplementedError
