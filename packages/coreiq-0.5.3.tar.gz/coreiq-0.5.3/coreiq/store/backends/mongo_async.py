"""motor-backed async Mongo backend."""
from __future__ import annotations

import logging
from typing import Any, Optional

from coreiq.exceptions import StorageError

from .async_base import AsyncStorageBackend

logger = logging.getLogger("coreiq.store.mongo_async")


class MongoAsyncBackend(AsyncStorageBackend):
    backend_type_value = "mongodb"

    def __init__(self, uri: str, database: str = "coreiq") -> None:
        try:
            from motor.motor_asyncio import AsyncIOMotorClient  # type: ignore[import-untyped]
        except ImportError as exc:
            raise StorageError("motor required — install coreiq[mongo-async]") from exc
        self._client = AsyncIOMotorClient(uri)
        self._db = self._client[database]

    async def aexecute(self, sql: str, params: tuple = ()) -> Any:
        raise StorageError("MongoAsyncBackend does not support SQL — use document API")

    async def afetchall(self, sql: str, params: tuple = ()) -> list:
        raise StorageError("MongoAsyncBackend does not support SQL — use afind_documents")

    async def afetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        raise StorageError("MongoAsyncBackend does not support SQL")

    async def ainsert_document(self, collection: str, doc: dict) -> str:
        result = await self._db[collection].insert_one(doc)
        return str(result.inserted_id)

    async def afind_documents(
        self, collection: str, filter_dict: dict, limit: int = 100, skip: int = 0
    ) -> list[dict]:
        cursor = self._db[collection].find(filter_dict).skip(skip).limit(limit)
        return [doc async for doc in cursor]

    async def aclose(self) -> None:
        self._client.close()

    @property
    def backend_type(self) -> str:
        return self.backend_type_value
