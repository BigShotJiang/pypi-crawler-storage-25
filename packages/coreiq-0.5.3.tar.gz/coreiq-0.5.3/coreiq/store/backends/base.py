"""Abstract storage backend interface for CoreIQ."""
from abc import ABC, abstractmethod
from typing import Any, Optional


class StorageBackend(ABC):
    """Abstract base class for CoreIQ storage backends.

    Implement this to add new storage backends. The EventWriter
    uses this interface so backends are interchangeable.
    """

    @abstractmethod
    def execute(self, sql: str, params: tuple = ()) -> Any:
        """Execute a SQL statement. Returns cursor-like object."""
        ...

    @abstractmethod
    def commit(self) -> None:
        """Commit the current transaction."""
        ...

    def rollback(self) -> None:
        """Roll back the current transaction.

        Default is a no-op — backends that auto-commit per statement
        (Postgres pooled, ClickHouse, MongoDB) leave this as-is.
        Backends with a real open transaction (SQLite) override this.
        """

    @abstractmethod
    def fetchall(self, sql: str, params: tuple = ()) -> list:
        """Execute a SELECT and return all rows."""
        ...

    @abstractmethod
    def fetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        """Execute a SELECT and return one row, or None."""
        ...

    @abstractmethod
    def close(self) -> None:
        """Close the backend connection."""
        ...

    @property
    @abstractmethod
    def backend_type(self) -> str:
        """Return backend identifier: 'sqlite', 'postgres', 'mongodb', 'clickhouse'."""
        ...

    # ------------------------------------------------------------------
    # Optional DDL helper — used by init_schema for SQLite's executescript
    # path. SQL backends that support it override; others split statements.
    # ------------------------------------------------------------------

    def executescript(self, script: str) -> None:
        """Execute a semicolon-delimited DDL script.

        Default implementation splits on ``;`` and runs each non-empty
        statement through :meth:`execute`. Backends with native script
        support (SQLite) override this.
        """
        for stmt in script.split(";"):
            stmt = stmt.strip()
            if stmt:
                self.execute(stmt)

    # ------------------------------------------------------------------
    # Optional document-oriented methods (default: not implemented).
    # SQL backends may leave these as-is; MongoDB backend overrides them.
    # ------------------------------------------------------------------

    def insert_document(self, collection: str, doc: dict) -> str:
        """Insert a document. Returns inserted ID."""
        raise NotImplementedError

    def find_documents(self, collection: str, filter_dict: dict, limit: int = 100, skip: int = 0) -> list[dict]:
        """Query documents."""
        raise NotImplementedError

    def update_document(self, collection: str, filter_dict: dict, update: dict) -> int:
        """Update matching documents. Returns count."""
        raise NotImplementedError

    def delete_documents(self, collection: str, filter_dict: dict) -> int:
        """Delete matching documents. Returns count."""
        raise NotImplementedError
