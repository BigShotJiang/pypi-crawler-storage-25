"""MongoDB storage backend for CoreIQ.

Requires: pip install coreiq[mongodb]  (installs pymongo>=4.6)

Configuration (env vars):
    COREIQ_STORE_BACKEND=mongodb
    COREIQ_MONGODB_URI=mongodb://user:pass@host:27017
    COREIQ_MONGODB_DATABASE=coreiq
"""
from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from .base import StorageBackend
from .mongo_schema import get_collection, get_doc_type

try:
    from pymongo import ASCENDING, DESCENDING
    _PYMONGO_AVAILABLE = True
except ImportError:
    ASCENDING = 1
    DESCENDING = -1
    _PYMONGO_AVAILABLE = False


# ---------------------------------------------------------------------------
# MongoRow — sqlite3.Row-compatible result wrapper
# ---------------------------------------------------------------------------

class MongoRow:
    """Wraps a MongoDB document to behave like sqlite3.Row.

    Supports: row["col"], row[0], dict(row), for v in row, len(row).
    """

    __slots__ = ("_cols", "_vals", "_map")

    def __init__(self, cols: list[str], vals: list):
        self._cols = cols
        self._vals = vals
        self._map: dict[str, Any] = dict(zip(cols, vals))

    def __getitem__(self, key: str | int) -> Any:
        if isinstance(key, int):
            return self._vals[key]
        return self._map[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self._map.get(key, default)

    def __contains__(self, key: object) -> bool:
        return key in self._map

    def keys(self) -> list[str]:
        return self._cols

    def __iter__(self):
        return iter(self._vals)

    def __len__(self) -> int:
        return len(self._vals)

    def __repr__(self) -> str:
        return f"MongoRow({self._map})"


# ---------------------------------------------------------------------------
# Cursor-like wrappers
# ---------------------------------------------------------------------------

class _CursorLike:
    def __init__(self, rowcount: int = 0, lastrowid: Optional[str] = None):
        self.rowcount = rowcount
        self.lastrowid = lastrowid

    def fetchall(self) -> list:
        return []

    def fetchone(self) -> None:
        return None


class _ResultCursor:
    def __init__(self, rows: list):
        self._rows = rows
        self.rowcount = len(rows)
        self.lastrowid = None

    def fetchall(self) -> list:
        return self._rows

    def fetchone(self) -> Optional[Any]:
        return self._rows[0] if self._rows else None


# ---------------------------------------------------------------------------
# SQL-to-MongoDB translator helpers
# ---------------------------------------------------------------------------

_RE_INSERT = re.compile(
    r"^\s*INSERT\s+(?:OR\s+(?:REPLACE|IGNORE)\s+)?INTO\s+(\w+)\s*"
    r"(?:\(([^)]*)\))?\s*VALUES\s*\(([^)]*)\)",
    re.IGNORECASE,
)
_RE_SELECT_FULL = re.compile(
    r"^\s*SELECT\s+(.+?)\s+FROM\s+(\w+(?:\s+(?:AS\s+)?\w+)?)"
    r"(?:\s+((?:LEFT\s+|INNER\s+)?JOIN\s+.+?))?"
    r"(?:\s+WHERE\s+(.+?))?"
    r"(?:\s+GROUP\s+BY\s+(.+?))?"
    r"(?:\s+HAVING\s+(.+?))?"
    r"(?:\s+ORDER\s+BY\s+(.+?))?"
    r"(?:\s+LIMIT\s+(\d+|\?))?"
    r"(?:\s+OFFSET\s+(\d+|\?))?"
    r"\s*$",
    re.IGNORECASE | re.DOTALL,
)
_RE_COUNT_ONLY = re.compile(
    r"^\s*SELECT\s+COUNT\s*\(\s*\*\s*\)\s+FROM\s+(\w+)"
    r"(?:\s+WHERE\s+(.+?))?\s*$",
    re.IGNORECASE | re.DOTALL,
)
_RE_DELETE = re.compile(
    r"^\s*DELETE\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+?))?\s*$",
    re.IGNORECASE | re.DOTALL,
)
_RE_UPDATE = re.compile(
    r"^\s*UPDATE\s+(\w+)\s+SET\s+(.+?)\s+WHERE\s+(.+?)\s*$",
    re.IGNORECASE | re.DOTALL,
)
_RE_AGGREGATE_FUNC = re.compile(r"\b(COUNT|SUM|AVG|MIN|MAX)\s*\(", re.IGNORECASE)
_RE_DATETIME_NOW = re.compile(
    r"datetime\s*\(\s*'now'\s*(?:,\s*'([^']+)')?\s*\)", re.IGNORECASE
)
_RE_JSON_EXTRACT = re.compile(
    r"json_extract\s*\(\s*(\w+)\s*,\s*'\$\.([^']+)'\s*\)", re.IGNORECASE
)
_RE_DDL_OR_TRANSACTION = re.compile(
    r"^\s*(?:PRAGMA|CREATE\s+(?:TABLE|INDEX|UNIQUE\s+INDEX)|ALTER\s+TABLE"
    r"|DROP\s+(?:TABLE|INDEX)|BEGIN|COMMIT|ROLLBACK|SAVEPOINT|RELEASE)",
    re.IGNORECASE,
)


def _split_set_pairs(set_clause: str) -> list[str]:
    """Split an SQL ``SET a=?, b='x', c=?`` clause into top-level pairs.

    Comma-aware: a comma inside single-quoted literal does NOT split.
    Naive ``set_clause.split(",")`` would corrupt values like
    ``approvers='alice,bob'`` even though we don't rely on that today;
    keeping the parser correct future-proofs further literals.
    """
    out: list[str] = []
    cur: list[str] = []
    in_quote = False
    for ch in set_clause:
        if ch == "'":
            in_quote = not in_quote
            cur.append(ch)
        elif ch == "," and not in_quote:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    if cur:
        out.append("".join(cur).strip())
    return [p for p in out if p]


def _eval_datetime_now(modifier: Optional[str]) -> str:
    dt = datetime.now(timezone.utc)
    if modifier:
        modifier = modifier.strip()
        m = re.match(r"([+-]?\d+)\s+(day|hour|minute|second)s?", modifier, re.IGNORECASE)
        if m:
            n = int(m.group(1))
            unit = m.group(2).lower()
            delta = {"day": timedelta(days=n), "hour": timedelta(hours=n),
                     "minute": timedelta(minutes=n), "second": timedelta(seconds=n)}.get(unit, timedelta(0))
            dt = dt + delta
    return dt.isoformat()


def _preprocess_sql(sql: str) -> str:
    def replace_dt(m: re.Match) -> str:
        return f"'{_eval_datetime_now(m.group(1))}'"
    return _RE_DATETIME_NOW.sub(replace_dt, sql)


def _resolve_field(expr: str) -> str:
    expr = expr.strip()
    m = _RE_JSON_EXTRACT.match(expr)
    if m:
        field = f"{m.group(1)}.{m.group(2)}"
    elif "." in expr and not expr.startswith("$"):
        field = expr.split(".", 1)[1]
    else:
        field = expr
    # Reject MongoDB operator injection — field names must not start with $
    if field.startswith("$"):
        raise ValueError(f"Invalid field name (MongoDB operator prefix not allowed): {field!r}")
    return field


def _parse_condition(part: str, params: tuple, offset: int) -> tuple[dict, int]:
    part = part.strip()
    for op, mop in [(">=", "$gte"), ("<=", "$lte"), ("!=", "$ne"), (">", "$gt"), ("<", "$lt")]:
        if op in part:
            left, right = part.split(op, 1)
            col = _resolve_field(left.strip())
            right = right.strip()
            if right == "?":
                return {col: {mop: params[offset]}}, offset + 1
            return {col: {mop: _parse_literal(right)}}, offset

    if "=" in part:
        left, right = part.split("=", 1)
        col = _resolve_field(left.strip())
        right = right.strip()
        if right == "?":
            return {col: params[offset]}, offset + 1
        return {col: _parse_literal(right)}, offset

    m = re.match(r"(\w+)\s+IS\s+NOT\s+NULL", part, re.IGNORECASE)
    if m:
        return {m.group(1): {"$ne": None}}, offset

    m = re.match(r"(\w+)\s+IS\s+NULL", part, re.IGNORECASE)
    if m:
        return {m.group(1): None}, offset

    m = re.match(r"(\w+)\s+LIKE\s+\?", part, re.IGNORECASE)
    if m:
        val = str(params[offset])
        regex = val.replace("%", ".*").replace("_", ".")
        return {m.group(1): {"$regex": regex, "$options": "i"}}, offset + 1

    m = re.match(r"(\w+)\s+IN\s*\(([^)]+)\)", part, re.IGNORECASE)
    if m:
        col = m.group(1)
        n = len(m.group(2).split(","))
        return {col: {"$in": list(params[offset:offset + n])}}, offset + n

    m = re.match(r"(\w+)\s+BETWEEN\s+\?\s+AND\s+\?", part, re.IGNORECASE)
    if m:
        return {m.group(1): {"$gte": params[offset], "$lte": params[offset + 1]}}, offset + 2

    # EXISTS / NOT EXISTS — skip (unsupported, return empty)
    if re.match(r"(?:NOT\s+)?EXISTS\s*\(", part, re.IGNORECASE):
        return {}, offset

    return {}, offset


def _parse_where(where_clause: str, params: tuple, param_offset: int) -> tuple[dict, int]:
    filter_dict: dict = {}
    offset = param_offset
    parts = re.split(r"\bAND\b", where_clause, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if part.startswith("(") and part.endswith(")") and re.search(r"\bOR\b", part, re.IGNORECASE):
            inner = part[1:-1]
            or_conditions = []
            for op in re.split(r"\bOR\b", inner, flags=re.IGNORECASE):
                cond, offset = _parse_condition(op.strip(), params, offset)
                if cond:
                    or_conditions.append(cond)
            if or_conditions:
                filter_dict["$or"] = or_conditions
        else:
            cond, offset = _parse_condition(part, params, offset)
            filter_dict.update(cond)
    return filter_dict, offset


def _parse_order_by(order_clause: str) -> list[tuple[str, int]]:
    result = []
    for part in order_clause.split(","):
        part = part.strip()
        if re.search(r"\bDESC\b", part, re.IGNORECASE):
            col = re.sub(r"\bDESC\b", "", part, flags=re.IGNORECASE).strip()
            result.append((_resolve_field(col), DESCENDING))
        else:
            col = re.sub(r"\bASC\b", "", part, flags=re.IGNORECASE).strip()
            result.append((_resolve_field(col), ASCENDING))
    return result


def _parse_literal(val: str) -> Any:
    val = val.strip()
    try:
        return int(val)
    except ValueError:
        pass
    try:
        return float(val)
    except ValueError:
        pass
    if val.startswith("'") and val.endswith("'"):
        return val[1:-1]
    return f"${_resolve_field(val)}"


def _parse_case_cond(cond: str) -> Any:
    cond = cond.strip()
    for op, mop in [(">=", "$gte"), ("<=", "$lte"), ("!=", "$ne"), (">", "$gt"), ("<", "$lt"), ("=", "$eq")]:
        if op in cond:
            left, right = cond.split(op, 1)
            return {mop: [_parse_literal(left.strip()), _parse_literal(right.strip())]}
    return {"$eq": [f"${cond}", True]}


def _parse_expr(expr: str) -> Any:
    expr = expr.strip()
    m = re.match(r"CASE\s+WHEN\s+(.+?)\s+THEN\s+(.+?)\s+ELSE\s+(.+?)\s+END", expr, re.IGNORECASE)
    if m:
        return {"$cond": [_parse_case_cond(m.group(1)), _parse_literal(m.group(2)), _parse_literal(m.group(3))]}

    m = re.match(r"CAST\s*\((.+?)\s+AS\s+\w+\)", expr, re.IGNORECASE)
    if m:
        return {"$toDouble": f"${_resolve_field(m.group(1).strip())}"}

    m = _RE_JSON_EXTRACT.match(expr)
    if m:
        return f"${m.group(1)}.{m.group(2)}"

    m = re.match(r"substr\s*\((\w+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", expr, re.IGNORECASE)
    if m:
        return {"$substr": [f"${m.group(1)}", int(m.group(2)) - 1, int(m.group(3))]}

    m = re.match(r"strftime\s*\(\s*'([^']+)'\s*,\s*(\w+)\s*\)", expr, re.IGNORECASE)
    if m:
        return {"$dateToString": {"format": m.group(1), "date": f"${m.group(2)}"}}

    if "+" in expr and "'" not in expr:
        parts = expr.split("+", 1)
        return {"$add": [f"${_resolve_field(parts[0])}", f"${_resolve_field(parts[1])}"]}

    return f"${_resolve_field(expr)}"


def _strip_coalesce(expr: str) -> str:
    """Unwrap top-level ``COALESCE(<inner>, <default>)`` to ``<inner>``.

    Mongo's aggregation pipeline uses ``$ifNull`` for fallback semantics,
    but for the empty-collection case the existing code already returns
    a default 0/0.0 if no document is produced. Stripping COALESCE lets
    the inner aggregate (AVG/SUM/...) be recognized; if no rows match
    Mongo emits no group document, and downstream readers handle the
    ``r is None`` branch with the SQL default value.
    """
    s = expr.strip()
    m = re.match(r"COALESCE\s*\(", s, re.IGNORECASE)
    if not m:
        return expr
    # Walk to the matching closing paren of COALESCE(.
    depth = 1
    i = m.end()
    while i < len(s) and depth > 0:
        if s[i] == "(":
            depth += 1
        elif s[i] == ")":
            depth -= 1
        i += 1
    if depth != 0:
        return expr  # malformed — leave as-is
    inner = s[m.end(): i - 1]
    # Find the top-level comma separating inner expr from default.
    depth = 0
    comma_idx = -1
    for j, ch in enumerate(inner):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            comma_idx = j
            break
    if comma_idx < 0:
        return inner.strip() + s[i:]
    return inner[:comma_idx].strip() + s[i:]


def _parse_aggregate_expr(expr: str, alias: Optional[str] = None) -> Optional[tuple[str, Any]]:
    expr = _strip_coalesce(expr.strip())
    field_name = alias or re.sub(r"[^a-zA-Z0-9_]", "_", expr).strip("_")

    if re.match(r"COUNT\s*\(\s*\*\s*\)", expr, re.IGNORECASE):
        return field_name or "count", {"$sum": 1}

    m = re.match(r"SUM\s*\((.+)\)", expr, re.IGNORECASE)
    if m:
        return field_name, {"$sum": _parse_expr(m.group(1).strip())}

    m = re.match(r"AVG\s*\((.+)\)", expr, re.IGNORECASE)
    if m:
        return field_name, {"$avg": _parse_expr(m.group(1).strip())}

    m = re.match(r"(MIN|MAX)\s*\((.+)\)", expr, re.IGNORECASE)
    if m:
        op = "$min" if m.group(1).upper() == "MIN" else "$max"
        return field_name, {op: f"${_resolve_field(m.group(2).strip())}"}

    return None


def _split_select_cols(cols_raw: str) -> list[str]:
    cols, depth, current = [], 0, []
    for ch in cols_raw:
        if ch == "(":
            depth += 1
            current.append(ch)
        elif ch == ")":
            depth -= 1
            current.append(ch)
        elif ch == "," and depth == 0:
            cols.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        cols.append("".join(current).strip())
    return cols


def _coerce_json_field(key: str, val: Any) -> Any:
    """Serialize dict/list values back to JSON strings for '_json' suffix fields.

    MongoDB stores these as native BSON documents for efficient querying.
    SQL-layer consumers expect the original string form.
    """
    if key.endswith("_json") and isinstance(val, (dict, list)):
        return json.dumps(val)
    return val


def _parse_select_cols(cols_raw: str) -> tuple[list, list]:
    agg_exprs, plain_cols = [], []
    for col in _split_select_cols(cols_raw):
        col = col.strip()
        if not col or col == "*":
            continue
        alias = None
        m_alias = re.match(r"(.+?)\s+(?:AS\s+)?(\w+)\s*$", col, re.IGNORECASE)
        if m_alias and m_alias.group(2).upper() not in ("FROM", "WHERE", "GROUP", "ORDER", "LIMIT"):
            alias = m_alias.group(2)
            col = m_alias.group(1).strip()

        if _RE_AGGREGATE_FUNC.search(col):
            result = _parse_aggregate_expr(col, alias)
            if result:
                agg_exprs.append((result[0], result[1], alias))
        else:
            plain_cols.append(alias or _resolve_field(col))
    return agg_exprs, plain_cols


# ---------------------------------------------------------------------------
# Main translator
# ---------------------------------------------------------------------------

class _SqlToMongo:
    def __init__(self, db: Any):
        self._db = db
        self._last_rows: list = []

    _MAX_SQL_LEN = 8192  # guard against ReDoS via oversized input

    def execute(self, sql: str, params: tuple = ()) -> Any:  # noqa: C901
        sql = sql.strip()
        if len(sql) > self._MAX_SQL_LEN:
            raise ValueError(f"SQL query too long ({len(sql)} chars); max {self._MAX_SQL_LEN}")

        if _RE_DDL_OR_TRANSACTION.match(sql):
            return _CursorLike()

        m = _RE_INSERT.match(sql)
        if m:
            return self._do_insert(m, params)

        m = _RE_DELETE.match(sql)
        if m:
            return self._do_delete(m, params)

        m = _RE_UPDATE.match(sql)
        if m:
            return self._do_update(m, params)

        m = _RE_COUNT_ONLY.match(sql)
        if m:
            return self._do_count(m, params)

        sql_pp = _preprocess_sql(sql)
        m = _RE_SELECT_FULL.match(sql_pp)
        if m:
            rows = self._do_select_full(m, params)
            self._last_rows = rows
            return _ResultCursor(rows)

        return _CursorLike()

    def _do_insert(self, m: re.Match, params: tuple) -> _CursorLike:
        table = m.group(1)
        cols_raw = m.group(2)
        coll = self._db[get_collection(table)]

        if cols_raw:
            cols = [c.strip() for c in cols_raw.split(",")]
            doc: dict = {}
            for col, val in zip(cols, params):
                if col.endswith("_json") and isinstance(val, str) and val:
                    try:
                        doc[col] = json.loads(val)
                    except (json.JSONDecodeError, TypeError):
                        doc[col] = val
                else:
                    doc[col] = val
        else:
            doc = {"_raw_params": list(params)}

        doc_type = get_doc_type(table)
        if doc_type:
            doc.setdefault("_doc_type", doc_type)

        # Composite-key tables — first column is part of a multi-column PK.
        # Without this exception ``INSERT OR REPLACE INTO ... (tenant_id,
        # control_id, ...)`` would write every control for a given tenant
        # under the same ``_id=tenant_id``, clobbering prior rows.
        _COMPOSITE_PK = {
            "compliance_check_results": ("tenant_id", "control_id"),
            "tenant_compliance_overrides": ("tenant_id", "control_id"),
            "metric_values": ("metric_id", "ts"),
        }
        if cols_raw:
            cols_list = [c.strip() for c in cols_raw.split(",")]
            composite = _COMPOSITE_PK.get(table)
            if composite and all(c in doc for c in composite):
                filter_doc = {c: doc[c] for c in composite}
                _id = "_".join(str(doc[c]) for c in composite)
                coll.replace_one(filter_doc, {**doc, "_id": _id}, upsert=True)
                return _CursorLike(rowcount=1, lastrowid=_id)
            id_col = cols_list[0]
            id_val = doc.get(id_col)
            if id_val is not None:
                _id = str(id_val)
                coll.replace_one({"_id": _id}, {**doc, "_id": _id}, upsert=True)
                return _CursorLike(rowcount=1, lastrowid=_id)

        _id = str(uuid.uuid4())
        coll.insert_one({**doc, "_id": _id})
        return _CursorLike(rowcount=1, lastrowid=_id)

    def _do_delete(self, m: re.Match, params: tuple) -> _CursorLike:
        table = m.group(1)
        where = m.group(2)
        coll = self._db[get_collection(table)]
        filter_dict: dict = {}
        if where:
            filter_dict, _ = _parse_where(where, params, 0)
        doc_type = get_doc_type(table)
        if doc_type:
            filter_dict["_doc_type"] = doc_type
        result = coll.delete_many(filter_dict)
        return _CursorLike(rowcount=result.deleted_count)

    def _do_update(self, m: re.Match, params: tuple) -> _CursorLike:
        table = m.group(1)
        set_clause = m.group(2)
        where_clause = m.group(3)
        coll = self._db[get_collection(table)]
        # Walk the SET clause assignment-by-assignment so we capture both
        # parameterised (``col=?``) and literal (``col='active'``) RHS
        # forms. A naive ``col=?`` regex silently dropped literal-RHS
        # SET pairs (e.g. ``SET status='active', activated_at=?``), which
        # left the row unmodified on the literal column.
        update_doc: dict = {}
        inc_doc: dict = {}
        n_set = 0  # number of "?" placeholders consumed
        # SQL ``col = col + N`` (self-referencing increment) maps to Mongo
        # ``$inc``; capture it before _parse_literal turns it into a stray
        # ``"$col + N"`` string that no test can read back as an int.
        _RE_INC = re.compile(r"^(\w+)\s*([+-])\s*(\d+(?:\.\d+)?)\s*$")
        for raw in _split_set_pairs(set_clause):
            if "=" not in raw:
                continue
            col, rhs = raw.split("=", 1)
            col = col.strip()
            rhs = rhs.strip()
            if rhs == "?":
                if n_set >= len(params):
                    break
                val = params[n_set]
                n_set += 1
                if col.endswith("_json") and isinstance(val, str) and val:
                    try:
                        update_doc[col] = json.loads(val)
                    except (json.JSONDecodeError, TypeError):
                        update_doc[col] = val
                else:
                    update_doc[col] = val
                continue
            inc_m = _RE_INC.match(rhs)
            if inc_m and inc_m.group(1) == col:
                step_str = inc_m.group(3)
                step: float | int = float(step_str) if "." in step_str else int(step_str)
                if inc_m.group(2) == "-":
                    step = -step
                inc_doc[col] = inc_doc.get(col, 0) + step
                continue
            # Literal RHS: parse as bare value; drop the dollar-prefixed
            # column-ref fallback to avoid writing "$col + N" strings.
            rhs_stripped = rhs.strip()
            if rhs_stripped.startswith("'") and rhs_stripped.endswith("'"):
                update_doc[col] = rhs_stripped[1:-1]
            else:
                try:
                    update_doc[col] = int(rhs_stripped)
                except ValueError:
                    try:
                        update_doc[col] = float(rhs_stripped)
                    except ValueError:
                        update_doc[col] = rhs_stripped
        filter_dict, _ = _parse_where(where_clause, params, n_set)
        doc_type = get_doc_type(table)
        if doc_type:
            filter_dict["_doc_type"] = doc_type
        mongo_update: dict = {}
        if update_doc:
            mongo_update["$set"] = update_doc
        if inc_doc:
            mongo_update["$inc"] = inc_doc
        if not mongo_update:
            return _CursorLike(rowcount=0)
        result = coll.update_many(filter_dict, mongo_update)
        return _CursorLike(rowcount=result.modified_count)

    def _do_count(self, m: re.Match, params: tuple) -> _ResultCursor:
        table = m.group(1)
        where = m.group(2)
        coll = self._db[get_collection(table)]
        filter_dict: dict = {}
        if where:
            filter_dict, _ = _parse_where(where, params, 0)
        doc_type = get_doc_type(table)
        if doc_type:
            filter_dict["_doc_type"] = doc_type
        count = coll.count_documents(filter_dict)
        rows = [MongoRow(["count"], [count])]
        self._last_rows = rows
        return _ResultCursor(rows)

    def _do_select_full(self, m: re.Match, params: tuple) -> list:  # noqa: C901
        cols_raw = m.group(1).strip()
        table_expr = m.group(2).strip()
        join_clause = m.group(3)
        where = m.group(4)
        group_by = m.group(5)
        order_by = m.group(7)
        limit_str = m.group(8)
        offset_str = m.group(9)

        table = table_expr.split()[0]
        coll = self._db[get_collection(table)]

        filter_dict: dict = {}
        param_offset = 0
        if where:
            filter_dict, param_offset = _parse_where(where, params, 0)

        doc_type = get_doc_type(table)
        if doc_type:
            filter_dict["_doc_type"] = doc_type

        if limit_str == "?":
            limit = int(params[param_offset]) if param_offset < len(params) else 0
            param_offset += 1
        else:
            limit = int(limit_str) if limit_str else 0
        if offset_str == "?":
            skip = int(params[param_offset]) if param_offset < len(params) else 0
        else:
            skip = int(offset_str) if offset_str else 0
        sort = _parse_order_by(order_by) if order_by else []

        agg_exprs, plain_cols = _parse_select_cols(cols_raw)
        has_agg = bool(agg_exprs or group_by or join_clause)

        if has_agg:
            return self._do_aggregate(coll, filter_dict, agg_exprs, plain_cols,
                                       group_by, join_clause, sort, limit, skip)

        projection: Optional[dict] = None
        # Treat "t.*" (aliased wildcard) the same as bare "*" — return all fields
        is_wildcard = cols_raw.strip() in ("*",) or plain_cols == ["*"]
        if not is_wildcard:
            if plain_cols:
                projection = {c: 1 for c in plain_cols}
                projection["_id"] = 0
            else:
                projection = {"_id": 0}

        cursor = coll.find(filter_dict, projection or {"_id": 0})
        if sort:
            cursor = cursor.sort(sort)
        if skip:
            cursor = cursor.skip(skip)
        if limit:
            cursor = cursor.limit(limit)

        rows = []
        for doc in cursor:
            cols = [k for k in doc if k != "_id"]
            vals = [_coerce_json_field(k, doc[k]) for k in cols]
            rows.append(MongoRow(cols, vals))
        return rows

    def _do_aggregate(self, coll, filter_dict, agg_exprs, plain_cols,
                      group_by, join_clause, sort, limit, skip):
        pipeline: list[dict] = []

        if filter_dict:
            pipeline.append({"$match": filter_dict})

        if join_clause:
            pipeline.extend(self._parse_join(join_clause))

        if group_by or agg_exprs:
            group_fields: dict = {}
            if group_by:
                for gf in group_by.split(","):
                    gf = gf.strip()
                    fname = _resolve_field(gf)
                    key = fname.replace(".", "_")
                    group_fields[key] = f"${fname}"

            group_stage: dict = {"_id": group_fields if group_fields else None}
            for field_name, mongo_expr, _ in agg_exprs:
                group_stage[field_name] = mongo_expr
            for col in plain_cols:
                if col not in group_fields:
                    group_stage[col] = {"$first": f"${col}"}

            pipeline.append({"$group": group_stage})

            project: dict = {"_id": 0}
            for key in group_fields:
                project[key] = f"$_id.{key}"
            for field_name, _, _ in agg_exprs:
                project[field_name] = 1
            # Only project plain_cols that are NOT already mapped via group_fields
            # (to avoid overwriting "$_id.key" with the literal 1)
            for col in plain_cols:
                if col not in group_fields:
                    project[col] = 1
            pipeline.append({"$project": project})

        if sort:
            pipeline.append({"$sort": dict(sort)})
        if skip:
            pipeline.append({"$skip": skip})
        if limit:
            pipeline.append({"$limit": limit})

        rows = []
        for doc in coll.aggregate(pipeline):
            cols = [k for k in doc if k != "_id"]
            vals = [_coerce_json_field(k, doc[k]) for k in cols]
            rows.append(MongoRow(cols, vals))
        return rows

    def _parse_join(self, join_clause: str) -> list[dict]:
        stages: list[dict] = []
        pattern = re.compile(
            r"(LEFT\s+)?(?:INNER\s+)?JOIN\s+(\w+)(?:\s+(?:AS\s+)?(\w+))?\s+ON\s+(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)",
            re.IGNORECASE
        )
        for m in pattern.finditer(join_clause):
            is_left = bool(m.group(1))
            from_coll = get_collection(m.group(2))
            alias = m.group(3) or m.group(2)
            local_f, foreign_f = m.group(5), m.group(7)
            stages.append({"$lookup": {
                "from": from_coll,
                "localField": local_f,
                "foreignField": foreign_f,
                "as": alias,
            }})
            if is_left:
                stages.append({"$unwind": {"path": f"${alias}", "preserveNullAndEmptyArrays": True}})
            else:
                stages.append({"$unwind": f"${alias}"})
        return stages

    def fetchall(self, sql: str, params: tuple = ()) -> list:
        result = self.execute(sql, params)
        return result.fetchall() if result else self._last_rows

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        result = self.execute(sql, params)
        return result.fetchone() if result else (self._last_rows[0] if self._last_rows else None)


# ---------------------------------------------------------------------------
# MongoBackend
# ---------------------------------------------------------------------------

class MongoBackend(StorageBackend):
    """MongoDB implementation of StorageBackend.

    Translates SQL patterns from all coreiq modules to MongoDB operations
    transparently. Consumer code calls conn.execute(sql, params) unchanged.
    """

    def __init__(self, client: Any, database: str = "coreiq"):
        if not _PYMONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for MongoDB backend. "
                "Install: pip install 'coreiq[mongodb]'"
            )
        self._client = client
        self._db = client[database]

    @property
    def backend_type(self) -> str:
        return "mongodb"

    def execute(self, sql: str, params: tuple = ()) -> Any:
        return _SqlToMongo(self._db).execute(sql, params)

    def executescript(self, script: str) -> None:
        """No-op for MongoDB — schemaless."""
        pass

    def commit(self) -> None:
        pass

    def rollback(self) -> None:
        pass  # MongoDB auto-commits; no-op rollback

    def fetchall(self, sql: str, params: tuple = ()) -> list:
        return _SqlToMongo(self._db).fetchall(sql, params)

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        return _SqlToMongo(self._db).fetchone(sql, params)

    def close(self) -> None:
        self._client.close()

    # ------------------------------------------------------------------
    # Native document-oriented methods
    # ------------------------------------------------------------------

    def insert_document(self, collection: str, doc: dict) -> str:
        coll = self._db[get_collection(collection)]
        if "_id" not in doc:
            doc = {**doc, "_id": str(uuid.uuid4())}
        coll.insert_one(doc)
        return str(doc["_id"])

    def find_documents(self, collection: str, filter_dict: dict, limit: int = 100, skip: int = 0) -> list[dict]:
        coll = self._db[get_collection(collection)]
        return list(coll.find(filter_dict, {"_id": 0}).skip(skip).limit(limit))

    def update_document(self, collection: str, filter_dict: dict, update: dict) -> int:
        coll = self._db[get_collection(collection)]
        return coll.update_many(filter_dict, {"$set": update}).modified_count

    def delete_documents(self, collection: str, filter_dict: dict) -> int:
        coll = self._db[get_collection(collection)]
        return coll.delete_many(filter_dict).deleted_count

    def create_indexes(self) -> None:
        """Create recommended indexes on all collections."""
        index_defs = [
            ("coreiq_activity_logs", [("ts", DESCENDING), ("provider", ASCENDING),
                                       ("tenant_id", ASCENDING), ("agent_run_id", ASCENDING),
                                       ("_doc_type", ASCENDING)]),
            ("coreiq_security_violations", [("tenant_id", ASCENDING), ("category", ASCENDING),
                                             ("severity", ASCENDING), ("ts", DESCENDING)]),
            ("coreiq_performance_metrics", [("function_id", ASCENDING), ("variant_id", ASCENDING),
                                             ("ts", DESCENDING), ("tenant_id", ASCENDING)]),
            ("coreiq_gateway_users", [("key_hash", ASCENDING), ("tenant_id", ASCENDING)]),
            ("coreiq_llm_providers", [("provider", ASCENDING), ("tenant_id", ASCENDING)]),
            ("coreiq_routing_rules", [("group_name", ASCENDING), ("tenant_id", ASCENDING)]),
            ("coreiq_tenants", [("slug", ASCENDING)]),
            ("coreiq_users", [("tenant_id", ASCENDING), ("email", ASCENDING)]),
            ("coreiq_incidents", [("tenant_id", ASCENDING), ("status", ASCENDING)]),
            ("coreiq_eval_scores", [("trace_id", ASCENDING), ("ts", DESCENDING)]),
            ("coreiq_tool_calls", [("trace_id", ASCENDING)]),
            ("coreiq_cache_events", [("trace_id", ASCENDING)]),
            ("coreiq_audit_chain", [("event_id", ASCENDING), ("ts", DESCENDING)]),
            ("coreiq_hitl_queue", [("status", ASCENDING)]),
            ("coreiq_webhooks", [("tenant_id", ASCENDING)]),
            ("coreiq_licenses", [("tenant_id", ASCENDING)]),
            ("coreiq_billing_records", [("tenant_id", ASCENDING)]),
        ]
        for coll_name, fields in index_defs:
            try:
                self._db[coll_name].create_index(fields, background=True)
            except Exception:
                pass


def create_mongo_backend(uri: str, database: str = "coreiq") -> MongoBackend:
    """Create a MongoBackend from a URI string."""
    if not _PYMONGO_AVAILABLE:
        raise ImportError("pymongo required. Install: pip install 'coreiq[mongodb]'")
    from pymongo import MongoClient  # noqa: PLC0415
    client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    return MongoBackend(client, database)
