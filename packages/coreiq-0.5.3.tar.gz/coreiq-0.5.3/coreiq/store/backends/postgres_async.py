"""asyncpg-backed Postgres backend for hot-path writes.

Uses a connection pool (``asyncpg.create_pool``). Statements use ``$N``
placeholders — the dialect translator already handles this for the
sync backend, so callers should pass already-translated SQL.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from coreiq.exceptions import StorageError

from .async_base import AsyncStorageBackend

logger = logging.getLogger("coreiq.store.postgres_async")


class PostgresAsyncBackend(AsyncStorageBackend):
    backend_type_value = "postgres"

    def __init__(self, dsn: str, min_size: int = 2, max_size: int = 16) -> None:
        self._dsn = dsn
        self._min_size = min_size
        self._max_size = max_size
        self._pool: Any = None

    async def _ensure_pool(self) -> Any:
        if self._pool is not None:
            return self._pool
        try:
            import asyncpg  # type: ignore[import-untyped]
        except ImportError as exc:
            raise StorageError("asyncpg required — install coreiq[postgres-async]") from exc
        self._pool = await asyncpg.create_pool(
            self._dsn, min_size=self._min_size, max_size=self._max_size
        )
        return self._pool

    async def aexecute(self, sql: str, params: tuple = ()) -> Any:
        pool = await self._ensure_pool()
        async with pool.acquire() as conn:
            return await conn.execute(sql, *params)

    async def afetchall(self, sql: str, params: tuple = ()) -> list:
        pool = await self._ensure_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
            return [dict(r) for r in rows]

    async def afetchone(self, sql: str, params: tuple = ()) -> Optional[Any]:
        pool = await self._ensure_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(sql, *params)
            return dict(row) if row else None

    async def aclose(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    @property
    def backend_type(self) -> str:
        return self.backend_type_value
