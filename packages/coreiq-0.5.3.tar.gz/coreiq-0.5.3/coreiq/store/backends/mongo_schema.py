"""Mapping from coreiq SQL table names to MongoDB collection names."""

# Table name → MongoDB collection name mapping
# Tables that map to the same collection are disambiguated by a _doc_type field
COLLECTION_MAP: dict[str, str] = {
    # Core proxy data
    "traces": "coreiq_activity_logs",
    "events": "coreiq_activity_logs",          # disambiguated by _doc_type = "trace"/"event"
    "cache_events": "coreiq_cache_events",
    "tool_calls": "coreiq_tool_calls",
    "feedback": "coreiq_feedback",
    "query_recon": "coreiq_query_recon",
    # Auth / keys
    "api_keys": "coreiq_gateway_users",
    # Provider / routing
    "provider_configs": "coreiq_llm_providers",
    "group_policies": "coreiq_routing_rules",
    "group_guardrules": "coreiq_group_guardrules",
    # Evolution / optimisation
    "evolution": "coreiq_evolution",
    "bandit_state": "coreiq_bandit_state",
    "optimiser_config": "coreiq_optimiser_config",
    "deploy_history": "coreiq_deploy_history",
    "inferences": "coreiq_performance_metrics",
    "functions": "coreiq_portal_agents",
    "variants": "coreiq_variants",
    "experiments": "coreiq_experiments",
    "metric_definitions": "coreiq_metric_definitions",
    "metric_values": "coreiq_metric_values",
    "dicl_examples": "coreiq_dicl_examples",
    "finetune_jobs": "coreiq_finetune_jobs",
    "episodes": "coreiq_portal_chats",
    "episode_turns": "coreiq_episode_turns",
    # Audit / compliance
    "audit_chain": "coreiq_audit_chain",
    "eval_scores": "coreiq_eval_scores",
    "eval_datasets": "coreiq_eval_datasets",
    "dataset_items": "coreiq_dataset_items",
    "model_risk_register": "coreiq_model_risk_register",
    "policy_versions": "coreiq_policy_versions",
    # HITL
    "hitl_queue": "coreiq_hitl_queue",
    # Multi-tenancy
    "tenants": "coreiq_tenants",
    "users": "coreiq_users",
    # Security
    "security_violations": "coreiq_security_violations",
    "incidents": "coreiq_incidents",
    "escalation_policies": "coreiq_escalation_policies",
    # Governance
    "aup_policies": "coreiq_aup_policies",
    "aup_acknowledgments": "coreiq_aup_acknowledgments",
    # Integrations
    "webhooks": "coreiq_webhooks",
    # Config store
    "config_op_entries": "coreiq_config_op_entries",
    # Billing
    "licenses": "coreiq_licenses",
    "billing_records": "coreiq_billing_records",
    # Legacy / misc
    "tenant_integrations": "coreiq_tenant_integrations",
    "integration_templates": "coreiq_integration_templates",
    "federated_identities": "coreiq_federated_identities",
}

# Tables that share a collection — need _doc_type discriminator
_DOC_TYPE_MAP: dict[str, str] = {
    "traces": "trace",
    "events": "event",
}


def get_collection(table_name: str) -> str:
    """Return the MongoDB collection name for a SQL table."""
    return COLLECTION_MAP.get(table_name, f"coreiq_{table_name}")


def get_doc_type(table_name: str) -> str | None:
    """Return the _doc_type discriminator value for tables sharing a collection, or None."""
    return _DOC_TYPE_MAP.get(table_name)
