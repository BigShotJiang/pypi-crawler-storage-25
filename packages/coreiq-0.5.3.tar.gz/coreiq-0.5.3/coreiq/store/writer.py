from __future__ import annotations

import atexit
import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from .backends.base import StorageBackend
from .db import _rollback_quietly, create_connection, init_schema

logger = logging.getLogger("coreiq.store.writer")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class EventWriter:
    def __init__(self, db_path: Optional[Path] = None):
        """Create an EventWriter.

        Uses the configured backend (COREIQ_STORE_BACKEND).
        ``db_path`` is ignored (kept for signature compatibility).
        """
        self._lock = threading.Lock()
        self._conn = create_connection()
        init_schema(self._conn)
        self._buffer: list = []
        self._buffer_limit = 50
        self._flush_interval = 0.5  # seconds
        self._timer: Optional[threading.Timer] = None
        self._closed: bool = False
        self._start_flush_timer()

    def _start_flush_timer(self):
        self._timer = threading.Timer(self._flush_interval, self._auto_flush)
        self._timer.daemon = True
        self._timer.start()

    def _auto_flush(self):
        if self._closed:
            return
        with self._lock:
            self._flush_unlocked()
            if not self._closed:
                self._start_flush_timer()

    def _flush_unlocked(self):
        """Flush buffer while lock is held."""
        if not self._buffer:
            return
        failed = []
        skip_count = 0
        for sql, params in self._buffer:
            try:
                self._conn.execute(sql, params)
            except Exception as exc:
                skip_count += 1
                logger.warning("Buffered write skipped (%d so far): %s", skip_count, exc)
                _rollback_quietly(self._conn)
                failed.append((sql, params))
        self._conn.commit()
        # Retry failed writes once (FK deps may now be satisfied)
        retry_dropped = 0
        for sql, params in failed:
            try:
                self._conn.execute(sql, params)
                self._conn.commit()
            except Exception as exc:
                retry_dropped += 1
                logger.warning("Buffered write dropped on retry (%d total): %s", retry_dropped, exc)
                _rollback_quietly(self._conn)
        self._buffer.clear()

    def flush(self):
        """Public flush — force all buffered writes to disk."""
        with self._lock:
            self._flush_unlocked()

    def close(self):
        """Flush and close. Called on shutdown."""
        if self._timer:
            self._timer.cancel()   # best-effort stop before taking the lock
        with self._lock:
            self._closed = True
            self._flush_unlocked()

    def _buffer_write(self, sql: str, params: tuple) -> None:
        """Append a write to the buffer and flush if limit reached. Caller holds lock."""
        self._buffer.append((sql, params))
        if len(self._buffer) >= self._buffer_limit:
            self._flush_unlocked()

    def insert_trace(self, *, id: str, model: str, provider: str,
                     input_tok: int, output_tok: int, latency_ms: int,
                     finish_reason: str = "stop", cache_hit: bool = False,
                     ts: Optional[str] = None,
                     meta_json: Optional[str] = None,
                     user_id: Optional[str] = None,
                     task_id: Optional[str] = None,
                     session_id: Optional[str] = None,
                     tenant_id: str | None = None,
                     virtual_key_id: str | None = None,
                     data_region: str | None = None,
                     ttft_ms: int | None = None,
                     cost_usd: float | None = None,
                     policy_decision_id: str | None = None) -> None:
        # Enforce data residency policy (best-effort — never blocks on config error)
        if tenant_id and data_region:
            try:
                from ..governance.data_residency import get_auditor
                get_auditor().check_write(tenant_id=tenant_id, region=data_region)
            except Exception as residency_exc:
                # Re-raise residency violations; swallow config/import errors
                from ..governance.data_residency import CrossRegionWriteBlocked
                if isinstance(residency_exc, CrossRegionWriteBlocked):
                    raise
                logger.debug("Residency check skipped: %s", residency_exc)
        row_ts = ts or _now()
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO traces("
                "id,model,provider,input_tok,output_tok,latency_ms,finish_reason,"
                "cache_hit,ts,meta_json,user_id,task_id,session_id,tenant_id,"
                "virtual_key_id,ttft_ms,cost_usd,policy_decision_id"
                ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (id, model, provider, input_tok, output_tok, latency_ms,
                 finish_reason, int(cache_hit), row_ts, meta_json, user_id, task_id,
                 session_id, tenant_id, virtual_key_id, ttft_ms, cost_usd,
                 policy_decision_id)
            )

    def insert_cache_event(self, *, trace_id: str, hit: bool,
                           similarity: float = 0.0, saved_tok: int = 0,
                           backend: str = "memory", ts: Optional[str] = None,
                           id: Optional[str] = None) -> None:
        row_id = id or str(uuid.uuid4())
        row_ts = ts or _now()
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO cache_events(id,trace_id,hit,similarity,saved_tok,backend,ts) VALUES (?,?,?,?,?,?,?)",
                (row_id, trace_id, int(hit), similarity,
                 saved_tok, backend, row_ts)
            )

    def insert_tool_call(self, *, trace_id: str, tool_name: str,
                         args_json: str, valid: bool = True,
                         error: Optional[str] = None,
                         ts: Optional[str] = None,
                         id: Optional[str] = None,
                         result_json: Optional[str] = None,
                         duration_ms: Optional[int] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO tool_calls(id,trace_id,tool_name,args_json,valid,error,ts,result_json,duration_ms) VALUES (?,?,?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), trace_id, tool_name, args_json,
                 int(valid), error, ts or _now(), result_json, duration_ms)
            )

    def insert_feedback(self, *, response_id: str, signal: str,
                        value: float = 0.0, dimension: Optional[str] = None,
                        correction: Optional[str] = None,
                        ts: Optional[str] = None,
                        id: Optional[str] = None,
                        user_id: Optional[str] = None,
                        task_id: Optional[str] = None,
                        session_id: Optional[str] = None) -> None:
        row_id = id or str(uuid.uuid4())
        row_ts = ts or _now()
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO feedback(id,response_id,signal,value,dimension,correction,ts,user_id,task_id,session_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (row_id, response_id, signal, value,
                 dimension, correction, row_ts, user_id, task_id, session_id)
            )

    def insert_evolution(self, *, variant_id: str, phase: str,
                         win_rate: float = 0.0, samples: int = 0,
                         promoted: bool = False, ts: Optional[str] = None,
                         id: Optional[str] = None,
                         user_id: Optional[str] = None,
                         task_id: Optional[str] = None,
                         session_id: Optional[str] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO evolution(id,variant_id,phase,win_rate,samples,promoted,ts,user_id,task_id,session_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), variant_id, phase, win_rate,
                 samples, int(promoted), ts or _now(), user_id, task_id, session_id)
            )

    def insert_query_recon(self, *, trace_id: str, original: str,
                           reconstructed: str, similarity: float = 0.0,
                           ts: Optional[str] = None,
                           id: Optional[str] = None) -> None:
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO query_recon(id,trace_id,original,reconstructed,similarity,ts) VALUES (?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), trace_id, original, reconstructed,
                 similarity, ts or _now())
            )

    def insert_event(self, *, message: str,
                     level: str = "info",
                     metadata: Optional[Dict[str, Any]] = None,
                     source: Optional[str] = None,
                     trace_id: Optional[str] = None,
                     ts: Optional[str] = None,
                     id: Optional[str] = None,
                     tenant_id: Optional[str] = None) -> str:
        event_id = id or str(uuid.uuid4())
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO events (id, level, message, meta_json, source, trace_id, ts, tenant_id) VALUES (?,?,?,?,?,?,?,?)",
                (event_id, level, message,
                 json.dumps(metadata) if metadata else None,
                 source, trace_id, ts or _now(), tenant_id)
            )
        return event_id

    def insert_payload(
        self,
        *,
        trace_id: str,
        direction: str,
        content: str,
        size_bytes: int,
        truncated: bool,
        ts: Optional[str] = None,
        tenant_id: Optional[str] = None,
        id: Optional[str] = None,
    ) -> None:
        """Store a PII-masked prompt or response payload linked to a trace.

        direction must be 'request' or 'response'.
        content must already be PII-masked before calling this.
        """
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO trace_payloads"
                "(id,trace_id,direction,content,size_bytes,truncated,ts,tenant_id)"
                " VALUES (?,?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), trace_id, direction, content,
                 size_bytes, int(truncated), ts or _now(), tenant_id)
            )

    def insert_eval_score(
        self,
        *,
        trace_id: str,
        judge_id: str,
        dimension: str,
        score: float,
        rationale: str = "",
        ts: Optional[str] = None,
        id: Optional[str] = None,
    ) -> None:
        """Store a LLM-as-a-Judge evaluation score for a trace."""
        with self._lock:
            self._buffer_write(
                "INSERT OR REPLACE INTO eval_scores(id,trace_id,judge_id,dimension,score,rationale,ts) VALUES (?,?,?,?,?,?,?)",
                (id or str(uuid.uuid4()), trace_id, judge_id, dimension, score, rationale, ts or _now())
            )

    def delete_bandit_state_before(self, cutoff: str) -> int:
        """Delete bandit_state rows older than cutoff (ISO timestamp). Thread-safe."""
        with self._lock:
            self._flush_unlocked()
            cursor = self._conn.execute(
                "DELETE FROM bandit_state WHERE updated_at < ?", (cutoff,)
            )
            self._conn.commit()
            return cursor.rowcount

    def persist_bandit_state(self, arms: dict) -> None:
        """Persist bandit alpha/beta weights. arms: {variant_id: (alpha, beta)}
        Immediate commit — not buffered (consistency-critical)."""
        now = _now()
        with self._lock:
            self._flush_unlocked()  # flush pending buffer first
            for vid, (alpha, beta) in arms.items():
                self._conn.execute(
                    "INSERT OR REPLACE INTO bandit_state(variant_id, alpha, beta, updated_at) VALUES(?,?,?,?)",
                    (vid, alpha, beta, now)
                )
            self._conn.commit()


def from_env() -> "StorageBackend":
    """Build a :class:`StorageBackend` from the current environment.

    Reads ``COREIQ_STORE_BACKEND`` (via :func:`coreiq.config.get_store_config`)
    and returns the matching backend instance. ``COREIQ_STORE_BACKEND=otel``
    yields an :class:`~coreiq.store.backends.otel_backend.OtelBackend`; any
    other value falls through to the existing dispatch in
    :func:`create_connection`.
    """
    return create_connection()


_writer: Optional[EventWriter] = None
_writer_lock = threading.Lock()


def get_writer() -> EventWriter:
    global _writer
    if _writer is None:
        with _writer_lock:
            if _writer is None:
                _writer = EventWriter()
    return _writer


def _close_writer_atexit() -> None:
    """atexit handler — flush and close the global writer to avoid losing buffered traces."""
    global _writer
    if _writer is not None:
        try:
            _writer.close()
        except Exception:
            pass  # best-effort: don't raise during interpreter shutdown


atexit.register(_close_writer_atexit)
