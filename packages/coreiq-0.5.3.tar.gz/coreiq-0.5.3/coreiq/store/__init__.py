"""CoreIQ storage — multi-backend (MongoDB, ClickHouse, PostgreSQL)."""
