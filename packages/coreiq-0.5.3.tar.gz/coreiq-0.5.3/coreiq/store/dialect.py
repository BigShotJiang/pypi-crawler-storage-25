"""SQL dialect translator — single source of truth for cross-backend SQL.

Every backend's ``execute()`` funnels SQL through one of the ``to_*`` helpers
here before handing it to its native driver. This keeps the call sites
(``EventWriter``, routers, governance modules, etc.) writing plain SQLite SQL
while still working end-to-end on Postgres, MongoDB, and ClickHouse.

Translations covered:

- ``?`` placeholders → ``%s`` (Postgres) / ``{p0:...}`` (ClickHouse) /
  passthrough (SQLite).
- ``INSERT OR REPLACE INTO t(cols) VALUES (...)`` →

    - Postgres: ``INSERT ... ON CONFLICT (pk) DO UPDATE SET non_pk = EXCLUDED.non_pk``.
    - ClickHouse: plain ``INSERT`` on a ``ReplacingMergeTree`` (merge-time dedup,
      read-time ``FINAL`` for mutable tables).

- ``INSERT OR IGNORE INTO t(cols) VALUES (...)`` →

    - Postgres: ``INSERT ... ON CONFLICT DO NOTHING``.
    - ClickHouse: plain ``INSERT`` (idempotency via ReplacingMergeTree).

- ``CREATE TABLE``, ``CREATE INDEX``, ``ALTER TABLE`` (ClickHouse only):
  full DDL translation so ``init_schema`` runs unmodified.

The ``TABLES`` registry below is the schema metadata for every table that's
upserted or needs a specific ClickHouse engine. Append-only tables (traces,
events, ...) default to ``MergeTree``; mutable "current value" tables
(``bandit_state``, ``optimiser_config``, ...) use ``ReplacingMergeTree`` so
the latest row wins after merge, and reads against them get a ``FINAL``
modifier so they see the newest version before merge runs.

Keep this registry in sync with ``store/db.py::init_schema`` when a new table
is added. A missing entry falls back to safe defaults
(``MergeTree ORDER BY id``).
"""
from __future__ import annotations

import re
from typing import Optional

# ---------------------------------------------------------------------------
# Table registry
# ---------------------------------------------------------------------------

# MergeTree — append-only tables
_APPEND = {"engine": "MergeTree", "order_by": "(ts, id)"}
_APPEND_ID_ONLY = {"engine": "MergeTree", "order_by": "id"}

# ReplacingMergeTree — mutable / "current value" tables (read-your-writes via FINAL)
def _replacing(pk: list[str], version: str = "updated_at") -> dict:
    return {
        "engine": "ReplacingMergeTree",
        "version": version,
        "order_by": f"({', '.join(pk)})",
        "mutable": True,
    }


TABLES: dict[str, dict] = {
    # Append-only (id is a UUID; ON CONFLICT DO UPDATE is effectively idempotent)
    "traces":             {"pk": ["id"], **_APPEND},
    "cache_events":       {"pk": ["id"], **_APPEND},
    "tool_calls":         {"pk": ["id"], **_APPEND},
    "feedback":           {"pk": ["id"], **_APPEND},
    "evolution":          {"pk": ["id"], **_replacing(["id"], "ts")},
    "query_recon":        {"pk": ["id"], **_APPEND},
    "events":             {"pk": ["id"], **_APPEND},
    "inferences":         {"pk": ["id"], **_APPEND},
    "metric_values":      {"pk": ["id"], **_APPEND},
    "episode_turns":      {"pk": ["id"], **_APPEND},
    "eval_scores":        {"pk": ["id"], **_APPEND},
    "audit_chain":        {"pk": ["entry_id"], **_APPEND},
    "security_violations":{"pk": ["id"], **_APPEND},
    "span_hierarchy":     {"pk": ["trace_id"], **_replacing(["trace_id"], "ts")},


    # Mutable / "current value"
    "bandit_state":       {"pk": ["variant_id"], **_replacing(["variant_id"], "updated_at")},
    "optimiser_config":   {"pk": ["key"], **_replacing(["key"], "updated_at")},
    "provider_configs":   {"pk": ["id"], **_replacing(["id"], "created_at")},
    "api_keys":           {"pk": ["id"], **_replacing(["id"], "created_at")},
    "functions":          {"pk": ["id"], **_replacing(["id"], "created_at")},
    "variants":           {"pk": ["id"], **_replacing(["id"], "created_at")},
    "experiments":        {"pk": ["id"], **_replacing(["id"], "started_at")},
    "metric_definitions": {"pk": ["id"], **_replacing(["id"], "created_at")},
    "dicl_examples":      {"pk": ["id"], **_replacing(["id"], "created_at")},
    "finetune_jobs":      {"pk": ["id"], **_replacing(["id"], "started_at")},
    "episodes":           {"pk": ["id"], **_replacing(["id"], "created_at")},
    "group_policies":     {"pk": ["id"], **_replacing(["id"], "created_at")},
    "canary_deployments": {"pk": ["id"], **_replacing(["id"], "created_at")},
    "deploy_history":     {"pk": ["id"], **_replacing(["id"], "deployed_at")},
    "model_risk_register":{"pk": ["id"], **_replacing(["id"], "created_at")},
    "policy_versions":    {"pk": ["id"], **_replacing(["id"], "created_at")},
    "eval_datasets":      {"pk": ["id"], **_replacing(["id"], "created_at")},
    "dataset_items":      {"pk": ["id"], **_replacing(["id"], "created_at")},
    "hitl_queue":         {"pk": ["id"], **_replacing(["id"], "created_at")},
    "group_guardrules":   {"pk": ["id"], **_replacing(["id"], "created_at")},
    "tenants":            {"pk": ["id"], **_replacing(["id"], "updated_at")},
    "webhooks":           {"pk": ["id"], **_replacing(["id"], "created_at")},
    "config_op_entries":  {"pk": ["id"], **_replacing(["id"], "updated_at")},
    "licenses":           {"pk": ["id"], **_replacing(["id"], "created_at")},
    "billing_records":    {"pk": ["id"], **_replacing(["id"], "period_end")},
    "users":              {"pk": ["id"], **_replacing(["id"], "created_at")},
    "incidents":          {"pk": ["id"], **_replacing(["id"], "created_at")},
    "escalation_policies":{"pk": ["id"], **_replacing(["id"], "created_at")},
    "aup_policies":       {"pk": ["id"], **_replacing(["id"], "created_at")},
    "aup_acknowledgments":{"pk": ["id"], **_replacing(["id"], "acknowledged_at")},
    "feature_flags":      {"pk": ["id"], **_replacing(["id"], "updated_at")},
    "prompt_versions":    {"pk": ["id"], **_replacing(["id"], "created_at")},
    "prompt_deployments": {"pk": ["id"], **_replacing(["id"], "created_at")},
    "revoked_tokens":     {"pk": ["id"], **_replacing(["id"], "revoked_at")},
    # cyberpod-gateway integration (v0.4.0)
    "routing_rules":      {"pk": ["id"], **_replacing(["id"], "updated_at")},
    "group_budgets":      {"pk": ["id"], **_replacing(["id"], "updated_at")},
    # Compliance framework plugin system (B2 — cyberpod-gateway integration)
    "compliance_check_results":   {"pk": ["tenant_id", "control_id"], **_replacing(["tenant_id", "control_id"], "checked_at")},
    "tenant_compliance_overrides":{"pk": ["tenant_id", "control_id"], **_replacing(["tenant_id", "control_id"], "updated_at")},
    # Gateway Migration (v0.4.0)
    "provider_capacity":  {"pk": ["id"], "engine": "MergeTree", "order_by": "(id)"},
}


def _table_meta(table: str) -> dict:
    """Return registry entry for *table*, or a safe default."""
    return TABLES.get(table, {"pk": ["id"], **_APPEND_ID_ONLY})


def is_mutable_table(table: str) -> bool:
    """True if reads against this table should append ``FINAL`` on ClickHouse."""
    return _table_meta(table).get("mutable", False)


# ---------------------------------------------------------------------------
# Regexes — datetime / strftime / json_extract / CAST AS REAL
# ---------------------------------------------------------------------------

# datetime('now', '-N days') / datetime('now', '-N hours')
_DATETIME_NOW_DAYS_RE = re.compile(
    r"datetime\('now',\s*'-(\d+)\s+days?'\)",
    re.IGNORECASE,
)
_DATETIME_NOW_HOURS_RE = re.compile(
    r"datetime\('now',\s*'-(\d+)\s+hours?'\)",
    re.IGNORECASE,
)
# datetime('now', ?||' hours') — dynamic parameterised form used in eval.py
_DATETIME_NOW_PARAM_HOURS_RE = re.compile(
    r"datetime\('now',\s*\?\s*\|\|\s*'\s*hours?'\)",
    re.IGNORECASE,
)
_DATETIME_NOW_PARAM_DAYS_RE = re.compile(
    r"datetime\('now',\s*\?\s*\|\|\s*'\s*days?'\)",
    re.IGNORECASE,
)

# strftime patterns
_STRFTIME_HOUR_RE = re.compile(
    r"strftime\('%Y-%m-%dT%H:00:00',\s*([^)]+?)\s*\)",
    re.IGNORECASE,
)
_STRFTIME_DATE_RE = re.compile(
    r"strftime\('%Y-%m-%d',\s*([^)]+?)\s*\)",
    re.IGNORECASE,
)
_STRFTIME_MONTH_RE = re.compile(
    r"strftime\('%Y-%m',\s*([^)]+?)\s*\)",
    re.IGNORECASE,
)

# json_extract(col, '$.x')
_JSON_EXTRACT_RE = re.compile(
    r"json_extract\(([^,]+),\s*'\$\.(\w+)'\)",
    re.IGNORECASE,
)

# CAST(x AS REAL) — x may contain nested function calls with their own parens.
# Match greedily up to the last `` AS REAL)`` in the CAST expression.
# We use a non-greedy match that allows any characters (including parens)
# by matching from CAST( up to the first `` AS REAL)`` boundary.
_CAST_AS_REAL_RE = re.compile(
    r"CAST\((.+?)\s+AS\s+REAL\)",
    re.IGNORECASE,
)

# SUBSTR(col, start, len) / SUBSTR(col, start) — SQLite string function
# ClickHouse uses substring() instead.
_SUBSTR_RE = re.compile(
    r"\bSUBSTR\s*\(([^,)]+),\s*(\d+)(?:,\s*(\d+))?\s*\)",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Regexes — structural
# ---------------------------------------------------------------------------

# Matches: INSERT OR REPLACE INTO <table>[(<cols>)] VALUES (...)
_INSERT_REPLACE_RE = re.compile(
    r"""^\s*INSERT\s+OR\s+REPLACE\s+INTO\s+
        (?P<table>[A-Za-z_][A-Za-z0-9_]*)
        \s*(?:\(\s*(?P<cols>[^)]*)\s*\))?
        \s*VALUES\s*\(
    """,
    re.IGNORECASE | re.VERBOSE | re.DOTALL,
)

# Matches: INSERT OR IGNORE INTO <table> ...
_INSERT_IGNORE_RE = re.compile(
    r"""^\s*INSERT\s+OR\s+IGNORE\s+INTO\s+
        (?P<table>[A-Za-z_][A-Za-z0-9_]*)
    """,
    re.IGNORECASE | re.VERBOSE,
)

_CREATE_TABLE_RE = re.compile(
    r"""^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?
        (?P<table>[A-Za-z_][A-Za-z0-9_]*)
        \s*\(
        (?P<body>.*)
        \)\s*;?\s*$
    """,
    re.IGNORECASE | re.VERBOSE | re.DOTALL,
)

_CREATE_INDEX_RE = re.compile(
    r"""^\s*CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?
        (?P<name>[A-Za-z_][A-Za-z0-9_]*)
        \s+ON\s+(?P<table>[A-Za-z_][A-Za-z0-9_]*)
        \s*\(\s*(?P<cols>[^)]+)\s*\)
    """,
    re.IGNORECASE | re.VERBOSE,
)

_ALTER_ADD_COLUMN_RE = re.compile(
    r"""^\s*ALTER\s+TABLE\s+(?P<table>[A-Za-z_][A-Za-z0-9_]*)
        \s+ADD\s+COLUMN\s+(?P<rest>.+)$
    """,
    re.IGNORECASE | re.VERBOSE | re.DOTALL,
)

_SELECT_FROM_RE = re.compile(
    r"(?P<prefix>\bFROM\s+)"
    r"(?P<table>[A-Za-z_][A-Za-z0-9_]*)"
    r"(?!\s*(?:FINAL\b|AS\b|JOIN\b|,))"
    r"(?P<alias>\s+(?!(?:WHERE|ON|LEFT|RIGHT|INNER|OUTER|CROSS|JOIN|GROUP|ORDER|HAVING|LIMIT|UNION|EXCEPT|INTERSECT|FINAL)\b)[A-Za-z_][A-Za-z0-9_]*)?",
    re.IGNORECASE,
)

# UPDATE table SET ... WHERE ... → ALTER TABLE table UPDATE ... WHERE ...
_UPDATE_RE = re.compile(
    r"^\s*UPDATE\s+(?P<table>[A-Za-z_][A-Za-z0-9_]*)\s+SET\s+(?P<rest>.+)$",
    re.IGNORECASE | re.DOTALL,
)

# ---------------------------------------------------------------------------
# SQLite (passthrough)
# ---------------------------------------------------------------------------

def to_sqlite(sql: str) -> str:
    """SQLite is the source dialect — no translation needed."""
    return sql


# ---------------------------------------------------------------------------
# Postgres
# ---------------------------------------------------------------------------

def _infer_insert_columns(sql: str) -> Optional[list[str]]:
    """Pull the column list out of an ``INSERT INTO t(a,b,c) VALUES ...`` statement."""
    m = _INSERT_REPLACE_RE.match(sql)
    if not m:
        return None
    cols = m.group("cols")
    if not cols:
        return None
    return [c.strip() for c in cols.split(",") if c.strip()]


def _rewrite_insert_or_replace_pg(sql: str) -> str:
    """Translate ``INSERT OR REPLACE`` → ``INSERT ... ON CONFLICT (pk) DO UPDATE``.

    If the table has no registered PK or the SQL uses positional ``VALUES (?,?,?)``
    without an explicit column list, fall back to ``ON CONFLICT DO NOTHING`` to
    preserve idempotency without corrupting rows.
    """
    m = _INSERT_REPLACE_RE.match(sql)
    if not m:
        return sql

    table = m.group("table")
    meta = TABLES.get(table)
    head = re.sub(
        r"^\s*INSERT\s+OR\s+REPLACE\s+INTO",
        "INSERT INTO",
        sql,
        count=1,
        flags=re.IGNORECASE,
    )

    pk = meta["pk"] if meta else None
    cols = _infer_insert_columns(sql)

    if not pk:
        return head + " ON CONFLICT DO NOTHING"

    if not cols:
        return head + f" ON CONFLICT ({', '.join(pk)}) DO NOTHING"

    non_pk = [c for c in cols if c not in pk]
    if not non_pk:
        return head + f" ON CONFLICT ({', '.join(pk)}) DO NOTHING"

    set_clause = ", ".join(f"{c} = EXCLUDED.{c}" for c in non_pk)
    return head + f" ON CONFLICT ({', '.join(pk)}) DO UPDATE SET {set_clause}"


def _rewrite_insert_or_ignore_pg(sql: str) -> str:
    return re.sub(
        r"^\s*INSERT\s+OR\s+IGNORE\s+INTO",
        "INSERT INTO",
        sql,
        count=1,
        flags=re.IGNORECASE,
    ) + " ON CONFLICT DO NOTHING"


def _qmark_to_pg_placeholders(sql: str) -> str:
    """Replace ``?`` with ``%s`` outside string literals."""
    return sql.replace("?", "%s")


def _rewrite_sqlite_functions_pg(sql: str) -> str:
    """Translate SQLite-specific functions to Postgres equivalents."""
    # datetime('now', '-N days') → (NOW() - INTERVAL 'N days')
    sql = _DATETIME_NOW_DAYS_RE.sub(
        lambda m: f"(NOW() - INTERVAL '{m.group(1)} days')", sql
    )
    # datetime('now', '-N hours') → (NOW() - INTERVAL 'N hours')
    sql = _DATETIME_NOW_HOURS_RE.sub(
        lambda m: f"(NOW() - INTERVAL '{m.group(1)} hours')", sql
    )
    # datetime('now', ?||' hours') — dynamic parameterised form
    sql = _DATETIME_NOW_PARAM_HOURS_RE.sub(
        "(NOW() - ((%s)::text || ' hours')::interval)", sql
    )
    # datetime('now', ?||' days') — dynamic parameterised form
    sql = _DATETIME_NOW_PARAM_DAYS_RE.sub(
        "(NOW() - ((%s)::text || ' days')::interval)", sql
    )
    # strftime('%Y-%m-%dT%H:00:00', col) → to_char(col::timestamp, ...)
    sql = _STRFTIME_HOUR_RE.sub(
        lambda m: f"to_char({m.group(1).strip()}::timestamp, 'YYYY-MM-DD\"T\"HH24:00:00')",
        sql,
    )
    # strftime('%Y-%m-%d', col)
    sql = _STRFTIME_DATE_RE.sub(
        lambda m: f"to_char({m.group(1).strip()}::timestamp, 'YYYY-MM-DD')",
        sql,
    )
    # strftime('%Y-%m', col)
    sql = _STRFTIME_MONTH_RE.sub(
        lambda m: f"to_char({m.group(1).strip()}::timestamp, 'YYYY-MM')",
        sql,
    )
    # CAST(x AS REAL) → CAST(x AS DOUBLE PRECISION)  [before json_extract so
    # the inner expression is still the original SQLite form]
    sql = _CAST_AS_REAL_RE.sub(
        lambda m: f"CAST({m.group(1)} AS DOUBLE PRECISION)", sql
    )
    # json_extract(col, '$.x') → (col::jsonb ->> 'x')
    sql = _JSON_EXTRACT_RE.sub(
        lambda m: f"({m.group(1).strip()}::jsonb ->> '{m.group(2)}')", sql
    )
    return sql


def to_postgres(sql: str) -> str:
    """Translate SQLite-flavored SQL to Postgres-flavored SQL."""
    if _INSERT_REPLACE_RE.match(sql):
        sql = _rewrite_insert_or_replace_pg(sql)
    elif _INSERT_IGNORE_RE.match(sql):
        sql = _rewrite_insert_or_ignore_pg(sql)
    sql = _rewrite_sqlite_functions_pg(sql)
    return _qmark_to_pg_placeholders(sql)


# ---------------------------------------------------------------------------
# ClickHouse
# ---------------------------------------------------------------------------

# Statement kinds returned alongside translated SQL so the backend knows
# whether to use client.command() (DDL) or client.query() (SELECT).
KIND_DDL = "ddl"
KIND_INSERT = "insert"
KIND_SELECT = "select"
KIND_OTHER = "other"
KIND_SKIP = "skip"       # index already covered by sort key — drop silently
KIND_MUTATION = "mutation"  # ClickHouse ALTER TABLE ... UPDATE — routed via command() with inlined params

# Column name heuristics → ClickHouse skip-index type
_BLOOM_HINTS = (
    "id", "name", "key", "email", "provider", "model", "tenant_id", "user_id",
    "session_id", "task_id", "trace_id", "agent_run_id", "parent_span_id",
    "variant_id", "function_id", "episode_id", "experiment_id", "policy_id",
    "metric_name", "dimension", "signal", "level", "category", "severity",
    "status", "tier", "risk_tier", "group_name", "kind", "span_kind",
    "virtual_key_id", "inference_id", "prompt_id",
)


def _is_bloom_column(col: str) -> bool:
    c = col.strip().strip("`\"'").lower()
    for hint in _BLOOM_HINTS:
        if c == hint or c.endswith("_" + hint):
            return True
    return False


def _ch_type(sqlite_type: str, nullable: bool) -> str:
    """Map a SQLite column type to a ClickHouse column type."""
    t = sqlite_type.strip().upper()
    if t.startswith("INTEGER"):
        base = "Int64"
    elif t.startswith("REAL") or t.startswith("DOUBLE") or t.startswith("FLOAT"):
        base = "Float64"
    else:
        base = "String"
    return f"Nullable({base})" if nullable else base


def _parse_column_def(line: str) -> Optional[tuple[str, str, bool, Optional[str]]]:
    """Parse a single column definition from a SQLite ``CREATE TABLE`` body.

    Returns ``(name, ch_type, is_primary_key, default_expr)`` or ``None`` if the
    line is a constraint (PRIMARY KEY, UNIQUE, FOREIGN KEY) rather than a
    column.
    """
    s = line.strip().rstrip(",")
    if not s:
        return None
    upper = s.upper()
    # Skip table-level constraints
    if upper.startswith(("PRIMARY KEY", "UNIQUE", "FOREIGN KEY", "CHECK", "CONSTRAINT")):
        return None

    # Strip inline REFERENCES clause: ``col TEXT REFERENCES functions(id)``
    s = re.sub(r"\s+REFERENCES\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\)", "", s, flags=re.IGNORECASE)

    parts = s.split(None, 1)
    if len(parts) < 2:
        return None
    name = parts[0].strip("`\"")
    rest = parts[1].strip()

    # Extract type (first token of rest)
    type_match = re.match(r"(\w+)", rest)
    col_type = type_match.group(1) if type_match else "TEXT"
    rest_upper = rest.upper()

    is_pk = "PRIMARY KEY" in rest_upper
    not_null = "NOT NULL" in rest_upper or "PRIMARY KEY" in rest_upper
    has_default = "DEFAULT" in rest_upper

    nullable = not (not_null or has_default)

    default_expr = None
    if has_default:
        m = re.search(r"DEFAULT\s+('[^']*'|\"[^\"]*\"|[^\s,]+)", rest, re.IGNORECASE)
        if m:
            default_expr = m.group(1)

    return name, _ch_type(col_type, nullable), is_pk, default_expr


def _strip_unique_constraint(body: str) -> str:
    """Remove ``UNIQUE(cols)`` table-level constraints — ClickHouse has no
    traditional uniqueness; dedup is via ReplacingMergeTree + ORDER BY."""
    return re.sub(r",\s*UNIQUE\s*\([^)]*\)", "", body, flags=re.IGNORECASE)


def _translate_create_table_ch(sql: str) -> str:
    """Translate a SQLite ``CREATE TABLE`` to ClickHouse.

    ClickHouse constraints we honor:

    - Columns in the sort key (``ORDER BY``) must be **non-nullable** —
      ``MergeTree`` rejects nullable primary-key columns unless
      ``allow_nullable_key`` is explicitly enabled. We force these columns
      to non-nullable and give string ones a ``DEFAULT ''`` so legacy rows
      with NULLs migrate cleanly.
    - If the requested sort key references a column that doesn't exist in
      the source schema (e.g. registry says ``(ts, id)`` but the table has
      no ``ts`` column), we degrade to ``ORDER BY id`` rather than failing.
    - ``ReplacingMergeTree``'s version column (``updated_at`` / ``created_at``
      / etc.) only takes effect when the column actually exists; otherwise
      we drop back to the parameterless form.
    """
    m = _CREATE_TABLE_RE.match(sql)
    if not m:
        return sql

    table = m.group("table")
    body = _strip_unique_constraint(m.group("body"))

    # Split columns on commas at the top level (no nested parens in our schema)
    depth = 0
    buf: list[str] = []
    lines: list[str] = []
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            lines.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    if buf:
        lines.append("".join(buf))

    # First pass: parse all columns so we know which ones exist before we
    # decide the sort key.
    parsed_cols: list[tuple[str, str, bool, Optional[str], str]] = []
    for raw in lines:
        parsed = _parse_column_def(raw)
        if parsed is None:
            continue
        name, ch_type, is_pk, default_expr = parsed
        # Remember the raw SQLite type so we can re-emit non-nullable later.
        type_match = re.match(r"(\w+)", raw.strip().split(None, 1)[1].strip()) if len(raw.strip().split(None, 1)) > 1 else None
        sqlite_type = type_match.group(1) if type_match else "TEXT"
        parsed_cols.append((name, ch_type, is_pk, default_expr, sqlite_type))

    col_names = {c[0] for c in parsed_cols}

    # Decide the sort key now that we know the real columns.
    meta = _table_meta(table)
    engine = meta["engine"]
    requested_order = meta["order_by"]
    order_cols = [c.strip() for c in requested_order.strip("()").split(",")]
    if not all(c in col_names for c in order_cols):
        # Degrade gracefully: prefer id, then any available column.
        if "id" in col_names:
            order_cols = ["id"]
        elif parsed_cols:
            order_cols = [parsed_cols[0][0]]
        else:
            order_cols = []

    sort_key_set = set(order_cols)

    # Second pass: re-emit columns, forcing sort-key columns non-nullable.
    columns: list[str] = []
    for name, ch_type, _is_pk, default_expr, sqlite_type in parsed_cols:
        if name in sort_key_set:
            # Force non-nullable. String columns without a DEFAULT get '' so
            # migrations from SQLite NULL → CH empty string work.
            ch_type = _ch_type(sqlite_type, nullable=False)
            if default_expr is None and ch_type == "String":
                default_expr = "''"
            elif default_expr is None and ch_type.startswith("Int"):
                default_expr = "0"
            elif default_expr is None and ch_type.startswith("Float"):
                default_expr = "0"
        col_sql = f"    {name} {ch_type}"
        if default_expr is not None:
            col_sql += f" DEFAULT {default_expr}"
        columns.append(col_sql)

    order_by = order_cols[0] if len(order_cols) == 1 else f"({', '.join(order_cols)})"

    engine_clause = engine
    if engine == "ReplacingMergeTree":
        # ClickHouse requires the version column to be numeric or
        # Date/DateTime/DateTime64. Our schema stores timestamps as ISO-8601
        # strings (TEXT), which CH won't accept as a version. Use the
        # parameterless form — ReplacingMergeTree will then dedup based on
        # insertion order, which is good enough for "last write wins"
        # semantics against a configured backend that only takes writes
        # from one CoreIQ process at a time.
        engine_clause = "ReplacingMergeTree"

    return (
        f"CREATE TABLE IF NOT EXISTS {table} (\n"
        + ",\n".join(columns)
        + f"\n) ENGINE = {engine_clause} ORDER BY {order_by}"
    )


def _translate_create_index_ch(sql: str) -> tuple[str, str]:
    """Translate ``CREATE INDEX``. If the column is already a sort-key prefix,
    returns ``("", KIND_SKIP)``; otherwise returns an ``ALTER TABLE ... ADD
    INDEX`` statement using ``bloom_filter`` or ``minmax``."""
    m = _CREATE_INDEX_RE.match(sql)
    if not m:
        return sql, KIND_OTHER

    name = m.group("name")
    table = m.group("table")
    cols = [c.strip().split()[0] for c in m.group("cols").split(",")]

    meta = _table_meta(table)
    order_by = meta.get("order_by", "")
    order_cols = [c.strip() for c in order_by.strip("()").split(",") if c.strip()]

    # Already covered by the sort key? Drop.
    if cols and cols[0] == (order_cols[0] if order_cols else None):
        return "", KIND_SKIP

    # Pick index type
    if all(_is_bloom_column(c) for c in cols):
        idx_type = "bloom_filter"
    elif len(cols) == 1 and cols[0] in ("ts", "created_at", "updated_at"):
        idx_type = "minmax"
    else:
        idx_type = "bloom_filter"

    expr = cols[0] if len(cols) == 1 else f"({', '.join(cols)})"
    return (
        f"ALTER TABLE {table} ADD INDEX IF NOT EXISTS {name} {expr} "
        f"TYPE {idx_type} GRANULARITY 4"
    ), KIND_DDL


def _translate_alter_add_column_ch(sql: str) -> str:
    """ClickHouse supports ``ALTER TABLE ... ADD COLUMN IF NOT EXISTS`` since
    21.x. SQLite's ``ADD COLUMN`` is implicitly ``IF NOT EXISTS`` (the schema
    init loop swallows ``duplicate column`` errors); make it explicit."""
    m = _ALTER_ADD_COLUMN_RE.match(sql)
    if not m:
        return sql
    table = m.group("table")
    rest = m.group("rest").strip().rstrip(";")
    # Strip trailing REFERENCES clause
    rest = re.sub(r"\s+REFERENCES\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\)", "", rest, flags=re.IGNORECASE)

    # Split `<name> <type> [DEFAULT x]` → translate type
    parts = rest.split(None, 1)
    if len(parts) < 2:
        return sql
    col_name = parts[0]
    col_rest = parts[1]
    type_match = re.match(r"(\w+)", col_rest)
    sqlite_type = type_match.group(1) if type_match else "TEXT"
    has_default = "DEFAULT" in col_rest.upper()
    ch_type = _ch_type(sqlite_type, nullable=not has_default)

    out = f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {col_name} {ch_type}"
    if has_default:
        dm = re.search(r"DEFAULT\s+('[^']*'|\"[^\"]*\"|[^\s]+)", col_rest, re.IGNORECASE)
        if dm:
            out += f" DEFAULT {dm.group(1)}"
    return out


def _append_final_for_mutable(sql: str) -> str:
    """Append ``FINAL`` to ``FROM <mutable_table>`` references in SELECTs.

    This gives read-your-writes semantics on ``ReplacingMergeTree`` tables
    without waiting for a background merge. Only rewrites simple single-table
    FROM clauses; joins and subqueries are left alone to avoid breaking
    queries we don't fully understand.

    Bare aliases (``FROM evolution e``) become ``FROM evolution FINAL AS e``
    so ClickHouse's parser doesn't reject the alias after ``FINAL``.
    """
    def repl(m: re.Match) -> str:
        table = m.group("table")
        if is_mutable_table(table):
            return f"{m.group('prefix')}{table} FINAL"
        return m.group(0)
    return _SELECT_FROM_RE.sub(repl, sql)


def _rewrite_sqlite_functions_ch(sql: str) -> str:
    """Translate SQLite-specific functions to ClickHouse equivalents."""
    # datetime('now', '-N days') → (now() - INTERVAL N DAY)
    sql = _DATETIME_NOW_DAYS_RE.sub(
        lambda m: f"(now() - INTERVAL {m.group(1)} DAY)", sql
    )
    # datetime('now', '-N hours') → (now() - INTERVAL N HOUR)
    sql = _DATETIME_NOW_HOURS_RE.sub(
        lambda m: f"(now() - INTERVAL {m.group(1)} HOUR)", sql
    )
    # datetime('now', ?||' hours') — dynamic parameterised form
    sql = _DATETIME_NOW_PARAM_HOURS_RE.sub(
        "(now() - toIntervalHour(abs({p0:Int64})))", sql
    )
    # datetime('now', ?||' days') — dynamic parameterised form
    sql = _DATETIME_NOW_PARAM_DAYS_RE.sub(
        "(now() - toIntervalDay(abs({p0:Int64})))", sql
    )
    # strftime('%Y-%m-%dT%H:00:00', col)
    sql = _STRFTIME_HOUR_RE.sub(
        lambda m: f"formatDateTime(parseDateTime64BestEffortOrNull({m.group(1).strip()}), '%Y-%m-%dT%H:00:00')",
        sql,
    )
    # strftime('%Y-%m-%d', col)
    sql = _STRFTIME_DATE_RE.sub(
        lambda m: f"formatDateTime(parseDateTime64BestEffortOrNull({m.group(1).strip()}), '%Y-%m-%d')",
        sql,
    )
    # strftime('%Y-%m', col)
    sql = _STRFTIME_MONTH_RE.sub(
        lambda m: f"formatDateTime(parseDateTime64BestEffortOrNull({m.group(1).strip()}), '%Y-%m')",
        sql,
    )
    # CAST(x AS REAL) → toFloat64(x)  [before json_extract so the inner
    # expression is still the original SQLite form]
    sql = _CAST_AS_REAL_RE.sub(
        lambda m: f"toFloat64({m.group(1).strip()})", sql
    )
    # json_extract(col, '$.x') → JSONExtractString(col, 'x')
    sql = _JSON_EXTRACT_RE.sub(
        lambda m: f"JSONExtractString({m.group(1).strip()}, '{m.group(2)}')", sql
    )
    # SUBSTR(col, start, len) / SUBSTR(col, start) → substring(col, start, len)
    def _substr_to_substring(m: re.Match) -> str:
        col, start = m.group(1).strip(), m.group(2)
        length = m.group(3)
        return f"substring({col}, {start}, {length})" if length else f"substring({col}, {start})"
    sql = _SUBSTR_RE.sub(_substr_to_substring, sql)
    return sql


def _classify_ch(sql: str) -> str:
    stripped = sql.lstrip().upper()
    if stripped.startswith(("CREATE ", "ALTER ", "DROP ")):
        return KIND_DDL
    if stripped.startswith("INSERT"):
        return KIND_INSERT
    if stripped.startswith(("SELECT", "WITH")):
        return KIND_SELECT
    return KIND_OTHER


def to_clickhouse(sql: str) -> tuple[str, str]:
    """Translate SQLite-flavored SQL to ClickHouse.

    Returns ``(translated_sql, kind)`` where *kind* is one of the ``KIND_*``
    constants so the backend knows which client method to dispatch to.
    """
    stripped = sql.strip()

    # CREATE TABLE
    if _CREATE_TABLE_RE.match(stripped):
        return _translate_create_table_ch(stripped), KIND_DDL

    # CREATE INDEX
    if _CREATE_INDEX_RE.match(stripped):
        return _translate_create_index_ch(stripped)

    # ALTER TABLE ADD COLUMN
    if _ALTER_ADD_COLUMN_RE.match(stripped):
        return _translate_alter_add_column_ch(stripped), KIND_DDL

    # UPDATE → ALTER TABLE ... UPDATE (ClickHouse mutation via command())
    mu = _UPDATE_RE.match(stripped)
    if mu:
        table = mu.group("table")
        rest = mu.group("rest").rstrip(";")
        sql = _rewrite_sqlite_functions_ch(f"ALTER TABLE {table} UPDATE {rest}")
        return sql, KIND_MUTATION

    # INSERT OR REPLACE / OR IGNORE → plain INSERT (ReplacingMergeTree dedupes on merge)
    if _INSERT_REPLACE_RE.match(sql):
        sql = re.sub(
            r"^\s*INSERT\s+OR\s+REPLACE\s+INTO",
            "INSERT INTO",
            sql,
            count=1,
            flags=re.IGNORECASE,
        )
    elif _INSERT_IGNORE_RE.match(sql):
        sql = re.sub(
            r"^\s*INSERT\s+OR\s+IGNORE\s+INTO",
            "INSERT INTO",
            sql,
            count=1,
            flags=re.IGNORECASE,
        )

    kind = _classify_ch(sql)

    # Translate SQLite-specific functions for non-DDL statements
    if kind != KIND_DDL:
        sql = _rewrite_sqlite_functions_ch(sql)

    # SELECT: append FINAL to simple FROM <mutable_table>
    if kind == KIND_SELECT:
        sql = _append_final_for_mutable(sql)

    return sql, kind
