import logging
import threading
from typing import Any

from .backends.base import StorageBackend
from ..exceptions import ConfigError

logger = logging.getLogger("coreiq.store")

_thread_local = threading.local()

# Connection now always means "a StorageBackend". Kept as a type alias so
# legacy call sites keep type-checking; new code should annotate StorageBackend.
Connection = StorageBackend


def _create_mongo_backend_connection() -> Any:
    """Create a MongoBackend from env/config.

    Raises RuntimeError if the backend is explicitly configured but unavailable
    (missing URI, driver not installed, or connection error).
    Returns None only when called in a context where the caller does not
    require MongoDB (internal use only — create_connection raises instead).
    """
    from ..config import get_store_config
    from .backends.mongo_backend import create_mongo_backend
    cfg = get_store_config()
    uri = cfg.get("mongodb_uri") or ""
    database = cfg.get("mongodb_database") or "coreiq"
    if not uri:
        raise RuntimeError(
            "Configured backend 'mongodb' is unavailable: "
            "COREIQ_MONGODB_URI (or mongodb_uri) is not set"
        )
    return create_mongo_backend(uri, database)


def _get_backend_type() -> str:
    """Return 'mongodb', 'postgres', or 'clickhouse' based on config."""
    try:
        from ..config import get_store_config
        cfg = get_store_config()
        return (cfg.get("backend") or "mongodb").lower()
    except (ImportError, OSError, KeyError, ValueError, AttributeError) as exc:
        logger.debug("config load failed, defaulting to mongodb: %s", exc)
        return "mongodb"


def create_connection() -> StorageBackend:
    """Create a connection to the configured storage backend.

    Dispatch is driven by COREIQ_STORE_BACKEND (default: clickhouse):
      - ``clickhouse`` → ClickHouseBackend (default)
      - ``mongodb``    → MongoBackend
      - ``postgres``   → PostgresBackend

    Raises RuntimeError if the configured backend is unavailable.
    """
    backend = _get_backend_type()

    if backend == "mongodb":
        try:
            return _create_mongo_backend_connection()
        except RuntimeError:
            raise
        except Exception as exc:
            raise RuntimeError(
                f"Configured backend 'mongodb' is unavailable: {exc}"
            ) from exc

    if backend == "postgres":
        try:
            from ..config import get_store_config
            from .backends.postgres_backend import PostgresBackend
            cfg = get_store_config()
            dsn = cfg.get("postgres_dsn") or ""
            if not dsn:
                raise RuntimeError(
                    "Configured backend 'postgres' is unavailable: "
                    "COREIQ_POSTGRES_DSN (or postgres_dsn) is not set"
                )
            return PostgresBackend(dsn)
        except RuntimeError:
            raise
        except Exception as exc:
            raise RuntimeError(
                f"Configured backend 'postgres' is unavailable: {exc}"
            ) from exc

    if backend == "otel":
        try:
            from .backends.otel_backend import get_otel_backend
            # Module-level singleton — every thread shares one backend
            # (and therefore one TracerProvider). See get_shared_connection
            # below for the matching read path.
            return get_otel_backend()
        except RuntimeError:
            raise
        except Exception as exc:
            raise RuntimeError(
                f"Configured backend 'otel' is unavailable: {exc}"
            ) from exc

    _KNOWN_BACKENDS = {"mongodb", "postgres", "otel", "clickhouse"}
    if backend not in _KNOWN_BACKENDS:
        raise ConfigError(
            f"Unknown backend {backend!r}",
            hint="Valid values: mongodb, postgres, clickhouse, otel. "
                 "Set COREIQ_STORE_BACKEND to one of these."
        )

    # Default: ClickHouse
    try:
        from ..config import get_store_config
        from .backends.clickhouse_backend import ClickHouseBackend
        cfg = get_store_config()
        dsn = cfg.get("clickhouse_dsn") or ""
        database = cfg.get("clickhouse_database") or "coreiq"
        if not dsn:
            raise RuntimeError(
                "Configured backend 'clickhouse' is unavailable: "
                "COREIQ_CLICKHOUSE_DSN (or clickhouse_dsn) is not set"
            )
        return ClickHouseBackend(dsn, database)
    except RuntimeError:
        raise
    except Exception as exc:
        raise RuntimeError(
            f"Configured backend 'clickhouse' is unavailable: {exc}"
        ) from exc


def get_shared_connection() -> StorageBackend:
    """Return a per-thread backend handle.

    All supported backends (Postgres, MongoDB, ClickHouse) use thread-safe
    drivers, so a single shared instance is reused across threads.
    """
    backend = _get_backend_type()

    if backend == "otel":
        # OTel backend is a process-wide singleton — every thread shares
        # one OtelBackend (and therefore one TracerProvider). A per-thread
        # cache here would build a fresh provider stack per worker thread,
        # orphaning spans into independent traces and leaking exporters.
        from .backends.otel_backend import get_otel_backend
        return get_otel_backend()

    attr = f"_{backend}_conn"
    existing = getattr(_thread_local, attr, None)
    if existing is not None:
        return existing
    conn = create_connection()
    setattr(_thread_local, attr, conn)
    return conn


def _init_mongo_indexes(backend: Any) -> None:
    """Create MongoDB indexes for query performance."""
    try:
        backend.create_indexes()
    except (AttributeError, RuntimeError, OSError) as exc:
        logger.warning("MongoDB index creation failed (continuing): %s", exc)


def init_schema(conn: StorageBackend) -> None:
    # MongoDB: schemaless — just ensure indexes exist
    if getattr(conn, 'backend_type', None) == "mongodb":
        _init_mongo_indexes(conn)
        return

    # OtelBackend has no schema to install — every write is shipped as an
    # OTLP signal and reads are served from an in-memory ring buffer.
    if getattr(conn, 'backend_type', None) == "otel":
        return

    conn.executescript("""
        CREATE TABLE IF NOT EXISTS traces (
            id          TEXT PRIMARY KEY,
            model       TEXT,
            provider    TEXT,
            input_tok   INTEGER,
            output_tok  INTEGER,
            latency_ms  INTEGER,
            finish_reason TEXT,
            cache_hit   INTEGER DEFAULT 0,
            ts          TEXT,
            meta_json   TEXT
        );

        CREATE TABLE IF NOT EXISTS cache_events (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT REFERENCES traces(id),
            hit         INTEGER,
            similarity  REAL,
            saved_tok   INTEGER,
            backend     TEXT,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS tool_calls (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT REFERENCES traces(id),
            tool_name   TEXT,
            args_json   TEXT,
            valid       INTEGER DEFAULT 1,
            error       TEXT,
            ts          TEXT,
            result_json TEXT,
            duration_ms INTEGER
        );

        CREATE TABLE IF NOT EXISTS feedback (
            id          TEXT PRIMARY KEY,
            response_id TEXT,
            signal      TEXT,
            value       REAL,
            dimension   TEXT,
            correction  TEXT,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS evolution (
            id          TEXT PRIMARY KEY,
            variant_id  TEXT,
            phase       TEXT,
            win_rate    REAL,
            samples     INTEGER,
            promoted    INTEGER DEFAULT 0,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS query_recon (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT REFERENCES traces(id),
            original    TEXT,
            reconstructed TEXT,
            similarity  REAL,
            ts          TEXT
        );

        CREATE TABLE IF NOT EXISTS events (
            id          TEXT PRIMARY KEY,
            level       TEXT DEFAULT 'info',
            message     TEXT NOT NULL,
            meta_json   TEXT,
            source      TEXT,
            trace_id    TEXT,
            ts          TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_traces_ts ON traces(ts);
        CREATE INDEX IF NOT EXISTS idx_traces_provider ON traces(provider);
        CREATE INDEX IF NOT EXISTS idx_tool_calls_name ON tool_calls(tool_name);
        CREATE INDEX IF NOT EXISTS idx_feedback_signal ON feedback(signal);
        CREATE INDEX IF NOT EXISTS idx_cache_events_trace ON cache_events(trace_id);
        CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
        CREATE INDEX IF NOT EXISTS idx_events_level ON events(level);

        CREATE TABLE IF NOT EXISTS bandit_state (
            variant_id  TEXT PRIMARY KEY,
            alpha       REAL DEFAULT 1.0,
            beta        REAL DEFAULT 1.0,
            updated_at  TEXT
        );

        CREATE TABLE IF NOT EXISTS optimiser_config (
            key         TEXT PRIMARY KEY,
            value       TEXT,
            updated_at  TEXT
        );

        CREATE TABLE IF NOT EXISTS deploy_history (
            id              TEXT PRIMARY KEY,
            config_snapshot TEXT,
            environment     TEXT,
            deployed_at     TEXT,
            note            TEXT
        );

        CREATE TABLE IF NOT EXISTS inferences (
            id              TEXT PRIMARY KEY,
            function_id     TEXT,
            variant_id      TEXT,
            episode_id      TEXT,
            tenant_id       TEXT,
            stored_input_json TEXT,
            rendered_input_json TEXT,
            output_json     TEXT,
            model           TEXT,
            provider        TEXT,
            input_tokens    INTEGER,
            output_tokens   INTEGER,
            latency_ms      INTEGER,
            cost_usd        REAL,
            cache_hit       INTEGER DEFAULT 0,
            finish_reason   TEXT,
            ts              TEXT,
            user_id         TEXT,
            session_id      TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_inferences_function ON inferences(function_id);
        CREATE INDEX IF NOT EXISTS idx_inferences_variant ON inferences(variant_id);
        CREATE INDEX IF NOT EXISTS idx_inferences_episode ON inferences(episode_id);
        CREATE INDEX IF NOT EXISTS idx_inferences_ts ON inferences(ts);

        CREATE TABLE IF NOT EXISTS provider_configs (
            id              TEXT PRIMARY KEY,
            tenant_id       TEXT,
            provider        TEXT NOT NULL,
            api_key_encrypted TEXT,
            base_url        TEXT,
            max_rpm         INTEGER,
            max_tpm         INTEGER,
            enabled         INTEGER DEFAULT 1,
            config_json     TEXT,
            created_at      TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_provider_configs_provider ON provider_configs(provider);

        CREATE TABLE IF NOT EXISTS api_keys (
            id              TEXT PRIMARY KEY,
            key_hash        TEXT UNIQUE NOT NULL,
            tenant_id       TEXT NOT NULL DEFAULT 'default',
            name            TEXT DEFAULT '',
            models_json     TEXT,
            max_budget_usd  REAL,
            spend_usd       REAL DEFAULT 0,
            tpm_limit       INTEGER,
            rpm_limit       INTEGER,
            blocked         INTEGER DEFAULT 0,
            expires_at      TEXT,
            metadata_json   TEXT DEFAULT '{}',
            created_at      TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash);
        CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys(tenant_id);

        CREATE TABLE IF NOT EXISTS functions (
            id              TEXT PRIMARY KEY,
            tenant_id       TEXT,
            name            TEXT UNIQUE NOT NULL,
            type            TEXT NOT NULL,
            input_schema_json TEXT,
            output_schema_json TEXT,
            created_at      TEXT
        );

        CREATE TABLE IF NOT EXISTS variants (
            id              TEXT PRIMARY KEY,
            function_id     TEXT REFERENCES functions(id),
            name            TEXT NOT NULL,
            type            TEXT NOT NULL,
            model           TEXT,
            system_template TEXT,
            user_template   TEXT,
            config_json     TEXT,
            weight          REAL DEFAULT 1.0,
            active          INTEGER DEFAULT 1,
            created_at      TEXT,
            UNIQUE(function_id, name)
        );

        CREATE TABLE IF NOT EXISTS experiments (
            id                      TEXT PRIMARY KEY,
            function_id             TEXT REFERENCES functions(id),
            name                    TEXT,
            type                    TEXT NOT NULL,
            algorithm               TEXT,
            metric_name             TEXT,
            status                  TEXT DEFAULT 'draft',
            config_json             TEXT,
            candidate_variants_json TEXT,
            winner_variant_id       TEXT,
            started_at              TEXT,
            concluded_at            TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_experiments_function ON experiments(function_id);
        CREATE INDEX IF NOT EXISTS idx_experiments_status ON experiments(status);

        CREATE TABLE IF NOT EXISTS metric_definitions (
            id              TEXT PRIMARY KEY,
            name            TEXT UNIQUE NOT NULL,
            type            TEXT NOT NULL,
            level           TEXT NOT NULL,
            optimize        TEXT NOT NULL,
            created_at      TEXT
        );

        CREATE TABLE IF NOT EXISTS metric_values (
            id              TEXT PRIMARY KEY,
            inference_id    TEXT,
            episode_id      TEXT,
            metric_name     TEXT NOT NULL,
            value           REAL,
            comment         TEXT,
            demonstration   TEXT,
            ts              TEXT,
            user_id         TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_metric_values_inference ON metric_values(inference_id);
        CREATE INDEX IF NOT EXISTS idx_metric_values_metric ON metric_values(metric_name);

        CREATE TABLE IF NOT EXISTS dicl_examples (
            id              TEXT PRIMARY KEY,
            function_id     TEXT REFERENCES functions(id),
            variant_name    TEXT,
            input_json      TEXT,
            output_json     TEXT,
            embedding_json  TEXT,
            quality_score   REAL,
            source          TEXT,
            created_at      TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_dicl_function ON dicl_examples(function_id);

        CREATE TABLE IF NOT EXISTS finetune_jobs (
            id              TEXT PRIMARY KEY,
            function_id     TEXT REFERENCES functions(id),
            provider        TEXT NOT NULL,
            base_model      TEXT NOT NULL,
            dataset_size    INTEGER,
            status          TEXT DEFAULT 'pending',
            provider_job_id TEXT,
            result_model    TEXT,
            config_json     TEXT,
            started_at      TEXT,
            completed_at    TEXT,
            error           TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_finetune_function ON finetune_jobs(function_id);

        CREATE TABLE IF NOT EXISTS episodes (
            id          TEXT PRIMARY KEY,
            function_id TEXT,
            tenant_id   TEXT,
            user_id     TEXT,
            session_id  TEXT,
            status      TEXT DEFAULT 'open',
            tags_json   TEXT,
            created_at  TEXT,
            closed_at   TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_episodes_function ON episodes(function_id);
        CREATE INDEX IF NOT EXISTS idx_episodes_status ON episodes(status);

        CREATE TABLE IF NOT EXISTS episode_turns (
            id          TEXT PRIMARY KEY,
            episode_id  TEXT REFERENCES episodes(id),
            inference_id TEXT,
            turn_number INTEGER NOT NULL,
            function_id TEXT,
            variant_id  TEXT,
            role        TEXT,
            metadata_json TEXT,
            created_at  TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_episode_turns_episode ON episode_turns(episode_id);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_episode_turns_order ON episode_turns(episode_id, turn_number);

        CREATE TABLE IF NOT EXISTS group_policies (
            id              TEXT PRIMARY KEY,
            group_name      TEXT NOT NULL,
            tenant_id       TEXT DEFAULT 'default',
            allowed_models_json TEXT,
            max_budget_usd  REAL,
            tpm_limit       INTEGER,
            rpm_limit       INTEGER,
            created_at      TEXT,
            UNIQUE(group_name, tenant_id)
        );
        CREATE INDEX IF NOT EXISTS idx_group_policies_group ON group_policies(group_name);
        CREATE INDEX IF NOT EXISTS idx_group_policies_tenant ON group_policies(tenant_id);

        CREATE TABLE IF NOT EXISTS canary_deployments (
            id                  TEXT PRIMARY KEY,
            current_model       TEXT NOT NULL,
            candidate_model     TEXT NOT NULL,
            traffic_pct         REAL NOT NULL DEFAULT 5,
            status              TEXT NOT NULL DEFAULT 'active',
            eval_metrics        TEXT NOT NULL DEFAULT '[]',
            promote_threshold   TEXT NOT NULL DEFAULT '{}',
            rollback_threshold  TEXT NOT NULL DEFAULT '{}',
            duration_hours      INTEGER NOT NULL DEFAULT 48,
            current_scores      TEXT NOT NULL DEFAULT '{}',
            candidate_scores    TEXT NOT NULL DEFAULT '{}',
            created_at          TEXT NOT NULL,
            concluded_at        TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_canary_status ON canary_deployments(status);
    """)
    # Commit the big executescript transaction before entering the
    # per-statement idempotent DDL loop below. On Postgres, the loop
    # issues rollback() on swallowed "column already exists" errors — if
    # the executescript were still uncommitted, that rollback would wipe
    # every table we just created.
    conn.commit()
    # Migration: add new columns to existing DBs
    for ddl in [
        "ALTER TABLE traces ADD COLUMN meta_json TEXT",
        "ALTER TABLE tool_calls ADD COLUMN result_json TEXT",
        "ALTER TABLE tool_calls ADD COLUMN duration_ms INTEGER",
        "CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts)",
        "CREATE INDEX IF NOT EXISTS idx_events_level ON events(level)",
        "ALTER TABLE feedback ADD COLUMN user_id TEXT",
        "ALTER TABLE feedback ADD COLUMN task_id TEXT",
        "ALTER TABLE feedback ADD COLUMN session_id TEXT",
        "ALTER TABLE evolution ADD COLUMN user_id TEXT",
        "ALTER TABLE evolution ADD COLUMN task_id TEXT",
        "ALTER TABLE evolution ADD COLUMN session_id TEXT",
        "ALTER TABLE traces ADD COLUMN user_id TEXT",
        "ALTER TABLE traces ADD COLUMN task_id TEXT",
        "ALTER TABLE traces ADD COLUMN session_id TEXT",
        # bandit_state extensions for experiment tracking
        "ALTER TABLE bandit_state ADD COLUMN experiment_id TEXT",
        "ALTER TABLE bandit_state ADD COLUMN count INTEGER DEFAULT 0",
        "ALTER TABLE bandit_state ADD COLUMN sum_rewards REAL DEFAULT 0.0",
        "ALTER TABLE bandit_state ADD COLUMN sum_sq_rewards REAL DEFAULT 0.0",
        "ALTER TABLE bandit_state ADD COLUMN algorithm TEXT",
        "ALTER TABLE traces ADD COLUMN tenant_id TEXT",
        "ALTER TABLE traces ADD COLUMN virtual_key_id TEXT",
        "CREATE INDEX IF NOT EXISTS idx_traces_tenant ON traces(tenant_id)",
        # Feature 1: Hierarchical span model
        "ALTER TABLE traces ADD COLUMN span_kind TEXT",
        "ALTER TABLE traces ADD COLUMN parent_span_id TEXT",
        "ALTER TABLE traces ADD COLUMN agent_run_id TEXT",
        "CREATE INDEX IF NOT EXISTS idx_traces_parent_span ON traces(parent_span_id)",
        "CREATE INDEX IF NOT EXISTS idx_traces_agent_run ON traces(agent_run_id)",
        "CREATE INDEX IF NOT EXISTS idx_traces_span_kind ON traces(span_kind)",

        # Feature 3: Cryptographically immutable audit chain
        """CREATE TABLE IF NOT EXISTS audit_chain (
            entry_id    TEXT PRIMARY KEY,
            event_id    TEXT NOT NULL,
            prev_hash   TEXT NOT NULL,
            entry_hash  TEXT NOT NULL,
            ts          TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_audit_chain_ts ON audit_chain(ts)",
        "CREATE INDEX IF NOT EXISTS idx_audit_chain_event ON audit_chain(event_id)",
        # Feature 5: LLM-as-a-Judge eval scores
        """CREATE TABLE IF NOT EXISTS eval_scores (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT NOT NULL,
            judge_id    TEXT NOT NULL,
            dimension   TEXT NOT NULL,
            score       REAL NOT NULL,
            rationale   TEXT,
            ts          TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_eval_scores_trace ON eval_scores(trace_id)",
        "CREATE INDEX IF NOT EXISTS idx_eval_scores_dimension ON eval_scores(dimension)",
        "CREATE INDEX IF NOT EXISTS idx_eval_scores_ts ON eval_scores(ts)",
        # Feature 10 Phase 3: Model Risk Register
        """CREATE TABLE IF NOT EXISTS model_risk_register (
            id              TEXT PRIMARY KEY,
            model_id        TEXT NOT NULL,
            provider        TEXT NOT NULL,
            risk_tier       TEXT NOT NULL,
            use_case        TEXT,
            approved_by     TEXT,
            approved_at     TEXT,
            notes           TEXT,
            metadata_json   TEXT,
            created_at      TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_model_risk_model ON model_risk_register(model_id)",
        "CREATE INDEX IF NOT EXISTS idx_model_risk_tier ON model_risk_register(risk_tier)",
        # Feature 10 Phase 3: Policy Versions
        """CREATE TABLE IF NOT EXISTS policy_versions (
            id              TEXT PRIMARY KEY,
            policy_name     TEXT NOT NULL,
            version         INTEGER NOT NULL,
            config_json     TEXT NOT NULL,
            diff_json       TEXT,
            status          TEXT DEFAULT 'draft',
            approved_by     TEXT,
            approved_at     TEXT,
            created_by      TEXT,
            created_at      TEXT,
            UNIQUE(policy_name, version)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_policy_versions_name ON policy_versions(policy_name)",
        "CREATE INDEX IF NOT EXISTS idx_policy_versions_status ON policy_versions(status)",
        # Feature 9: Production→Dataset Flywheel
        """CREATE TABLE IF NOT EXISTS eval_datasets (
            id              TEXT PRIMARY KEY,
            name            TEXT NOT NULL,
            version         INTEGER NOT NULL DEFAULT 1,
            description     TEXT,
            size            INTEGER DEFAULT 0,
            metadata_json   TEXT,
            created_at      TEXT,
            UNIQUE(name, version)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_eval_datasets_name ON eval_datasets(name)",
        """CREATE TABLE IF NOT EXISTS dataset_items (
            id              TEXT PRIMARY KEY,
            dataset_id      TEXT REFERENCES eval_datasets(id),
            trace_id        TEXT,
            input_text      TEXT,
            output_text     TEXT,
            reference_output TEXT,
            labels_json     TEXT,
            quality_score   REAL,
            source          TEXT DEFAULT 'production',
            created_at      TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_dataset_items_dataset ON dataset_items(dataset_id)",
        "CREATE INDEX IF NOT EXISTS idx_dataset_items_trace ON dataset_items(trace_id)",
        # Feature 10 Phase 4: HITL queue
        """CREATE TABLE IF NOT EXISTS hitl_queue (
            id              TEXT PRIMARY KEY,
            trace_id        TEXT,
            function_name   TEXT,
            risk_score      REAL,
            payload_json    TEXT,
            status          TEXT DEFAULT 'pending',
            reviewer_id     TEXT,
            decision        TEXT,
            decision_at     TEXT,
            fallback_used   INTEGER DEFAULT 0,
            timeout_s       INTEGER DEFAULT 300,
            created_at      TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_hitl_queue_status ON hitl_queue(status)",
        "CREATE INDEX IF NOT EXISTS idx_hitl_queue_trace ON hitl_queue(trace_id)",
        # Enterprise guardrails — extend group_policies with full guardrail config
        "ALTER TABLE group_policies ADD COLUMN denied_models_json TEXT",
        "ALTER TABLE group_policies ADD COLUMN allowed_providers_json TEXT",
        "ALTER TABLE group_policies ADD COLUMN max_input_tokens INTEGER",
        "ALTER TABLE group_policies ADD COLUMN max_output_tokens INTEGER",
        "ALTER TABLE group_policies ADD COLUMN rbac_role TEXT DEFAULT 'operator'",
        "ALTER TABLE group_policies ADD COLUMN data_region TEXT",
        "ALTER TABLE group_policies ADD COLUMN updated_at TEXT",
        "ALTER TABLE group_policies ADD COLUMN updated_by TEXT",
        # Per-group content guardrules (output safety rules)
        """CREATE TABLE IF NOT EXISTS group_guardrules (
            id              TEXT PRIMARY KEY,
            group_name      TEXT NOT NULL,
            tenant_id       TEXT DEFAULT 'default',
            rule_name       TEXT NOT NULL,
            pattern         TEXT NOT NULL,
            description     TEXT,
            action          TEXT DEFAULT 'block',
            created_at      TEXT,
            UNIQUE(group_name, tenant_id, rule_name)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_guardrules_group ON group_guardrules(group_name)",
        "CREATE INDEX IF NOT EXISTS idx_guardrules_tenant ON group_guardrules(tenant_id)",
        # Multi-tenancy
        """CREATE TABLE IF NOT EXISTS tenants (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    slug        TEXT UNIQUE NOT NULL,
    plan        TEXT DEFAULT 'free',
    settings_json TEXT DEFAULT '{}',
    created_at  TEXT,
    updated_at  TEXT
)""",
        "CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug)",
        "CREATE INDEX IF NOT EXISTS idx_tenants_plan ON tenants(plan)",
        # Security violations
        """CREATE TABLE IF NOT EXISTS security_violations (
    id          TEXT PRIMARY KEY,
    tenant_id   TEXT DEFAULT 'default',
    category    TEXT NOT NULL,
    severity    TEXT NOT NULL,
    trace_id    TEXT,
    message     TEXT NOT NULL,
    details_json TEXT,
    action_taken TEXT DEFAULT 'blocked',
    ts          TEXT
)""",
        "CREATE INDEX IF NOT EXISTS idx_violations_tenant ON security_violations(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_violations_category ON security_violations(category)",
        "CREATE INDEX IF NOT EXISTS idx_violations_severity ON security_violations(severity)",
        "CREATE INDEX IF NOT EXISTS idx_violations_ts ON security_violations(ts)",
        # Phase 4: Webhooks
        """CREATE TABLE IF NOT EXISTS webhooks (
            id              TEXT PRIMARY KEY,
            tenant_id       TEXT NOT NULL,
            url             TEXT NOT NULL,
            events_json     TEXT DEFAULT '["*"]',
            secret_hash     TEXT,
            status          TEXT DEFAULT 'active',
            created_at      TEXT,
            last_delivery_at TEXT,
            last_status_code INTEGER
        )""",
        "CREATE INDEX IF NOT EXISTS idx_webhooks_tenant ON webhooks(tenant_id)",
        # Phase 4: Config/Secrets Store (versioned, multi-tenant)
        """CREATE TABLE IF NOT EXISTS config_op_entries (
            id          TEXT PRIMARY KEY,
            tenant_id   TEXT NOT NULL,
            key         TEXT NOT NULL,
            value       TEXT,
            is_secret   INTEGER DEFAULT 0,
            description TEXT,
            updated_by  TEXT,
            updated_at  TEXT,
            version     INTEGER DEFAULT 1
        )""",
        "CREATE INDEX IF NOT EXISTS idx_config_entries_tenant_key ON config_op_entries(tenant_id, key)",
        # Phase 4: Licenses
        """CREATE TABLE IF NOT EXISTS licenses (
            id                    TEXT PRIMARY KEY,
            tenant_id             TEXT NOT NULL,
            plan                  TEXT DEFAULT 'free',
            seat_limit            INTEGER DEFAULT 5,
            token_quota_monthly   INTEGER DEFAULT 1000000,
            features_json         TEXT DEFAULT '[]',
            valid_until           TEXT,
            created_at            TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_licenses_tenant ON licenses(tenant_id)",
        # Phase 4: Billing records
        """CREATE TABLE IF NOT EXISTS billing_records (
            id              TEXT PRIMARY KEY,
            tenant_id       TEXT NOT NULL,
            period_start    TEXT,
            period_end      TEXT,
            total_tokens    INTEGER DEFAULT 0,
            total_cost_usd  REAL DEFAULT 0,
            seat_count      INTEGER DEFAULT 0
        )""",
        "CREATE INDEX IF NOT EXISTS idx_billing_tenant ON billing_records(tenant_id)",
        # Phase 3: Users
        """CREATE TABLE IF NOT EXISTS users (
            id          TEXT PRIMARY KEY,
            tenant_id   TEXT NOT NULL,
            email       TEXT NOT NULL,
            name        TEXT,
            role        TEXT DEFAULT 'viewer',
            mfa_enabled INTEGER DEFAULT 0,
            status      TEXT DEFAULT 'active',
            last_login  TEXT,
            created_at  TEXT,
            UNIQUE(tenant_id, email)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)",
        # Phase 3: Incidents
        """CREATE TABLE IF NOT EXISTS incidents (
            id                          TEXT PRIMARY KEY,
            tenant_id                   TEXT NOT NULL,
            title                       TEXT NOT NULL,
            severity                    TEXT NOT NULL,
            status                      TEXT DEFAULT 'open',
            violation_ids_json          TEXT DEFAULT '[]',
            assignee                    TEXT,
            escalation_policy_id        TEXT,
            timeline_json               TEXT DEFAULT '[]',
            breach_notification_required INTEGER DEFAULT 0,
            created_at                  TEXT,
            resolved_at                 TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_incidents_tenant ON incidents(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status)",
        # Phase 3: Escalation policies
        """CREATE TABLE IF NOT EXISTS escalation_policies (
            id          TEXT PRIMARY KEY,
            tenant_id   TEXT NOT NULL,
            name        TEXT NOT NULL,
            levels_json TEXT DEFAULT '[]',
            created_at  TEXT
        )""",
        # Phase 3: Acceptable Use Policies
        """CREATE TABLE IF NOT EXISTS aup_policies (
            id                TEXT PRIMARY KEY,
            tenant_id         TEXT NOT NULL,
            content_markdown  TEXT NOT NULL,
            version           INTEGER DEFAULT 1,
            active            INTEGER DEFAULT 1,
            created_at        TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_aup_tenant ON aup_policies(tenant_id)",
        """CREATE TABLE IF NOT EXISTS aup_acknowledgments (
            id              TEXT PRIMARY KEY,
            policy_id       TEXT NOT NULL,
            user_id         TEXT NOT NULL,
            acknowledged_at TEXT,
            ip_address      TEXT,
            UNIQUE(policy_id, user_id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_aup_acks_policy ON aup_acknowledgments(policy_id)",
        # Add tenant_id to events table (traces already has it from earlier migration)
        "ALTER TABLE events ADD COLUMN tenant_id TEXT",
        "CREATE INDEX IF NOT EXISTS idx_events_tenant ON events(tenant_id)",
        # Composite indexes for tenant-scoped query performance
        "CREATE INDEX IF NOT EXISTS idx_traces_tenant_ts ON traces(tenant_id, ts DESC)",
        "CREATE INDEX IF NOT EXISTS idx_traces_tenant_provider_ts ON traces(tenant_id, provider, ts DESC)",
        "CREATE INDEX IF NOT EXISTS idx_events_tenant_ts ON events(tenant_id, ts DESC)",
        "CREATE INDEX IF NOT EXISTS idx_events_tenant_level_ts ON events(tenant_id, level, ts DESC)",
        # Feature flags (ported from sdk-go FlagService)
        """CREATE TABLE IF NOT EXISTS feature_flags (
            id                  TEXT PRIMARY KEY,
            key                 TEXT UNIQUE NOT NULL,
            description         TEXT DEFAULT '',
            enabled_by_default  INTEGER DEFAULT 0,
            tenant_overrides    TEXT DEFAULT '{}',
            user_overrides      TEXT DEFAULT '{}',
            created_at          TEXT,
            updated_at          TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_feature_flags_key ON feature_flags(key)",
        # Prompt Registry — version control for prompts
        """CREATE TABLE IF NOT EXISTS prompt_versions (
            id                  TEXT PRIMARY KEY,
            prompt_id           TEXT NOT NULL,
            version             TEXT NOT NULL,
            template            TEXT NOT NULL,
            model               TEXT,
            metadata_json       TEXT,
            parent_version_id   TEXT,
            status              TEXT DEFAULT 'draft',
            approved_by         TEXT,
            approved_at         TEXT,
            created_by          TEXT,
            created_at          TEXT,
            UNIQUE(prompt_id, version)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_prompt_versions_prompt ON prompt_versions(prompt_id)",
        "CREATE INDEX IF NOT EXISTS idx_prompt_versions_status ON prompt_versions(status)",
        """CREATE TABLE IF NOT EXISTS prompt_deployments (
            id                          TEXT PRIMARY KEY,
            prompt_id                   TEXT NOT NULL,
            version_id                  TEXT NOT NULL,
            traffic_percent             REAL DEFAULT 1.0,
            rollback_policy_json        TEXT,
            status                      TEXT DEFAULT 'canary',
            promoted_at                 TEXT,
            rolled_back_at              TEXT,
            rolled_back_to_version_id   TEXT,
            created_at                  TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_prompt_deployments_prompt ON prompt_deployments(prompt_id)",
        "CREATE INDEX IF NOT EXISTS idx_prompt_deployments_status ON prompt_deployments(status)",
        # Agent token revocation
        """CREATE TABLE IF NOT EXISTS revoked_tokens (
            id          TEXT PRIMARY KEY,
            token_id    TEXT NOT NULL,
            reason      TEXT DEFAULT '',
            revoked_by  TEXT DEFAULT '',
            revoked_at  TEXT
        )""",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_revoked_tokens_token ON revoked_tokens(token_id)",
        # Content-aware routing rules (B1 — cyberpod-gateway integration)
        """CREATE TABLE IF NOT EXISTS routing_rules (
            id                    TEXT PRIMARY KEY,
            tenant_id             TEXT NOT NULL,
            name                  TEXT NOT NULL,
            priority              INTEGER DEFAULT 0,
            matchers_json         TEXT DEFAULT '[]',
            action                TEXT DEFAULT 'route',
            target_model_prefix   TEXT,
            target_deployment_id  TEXT,
            enabled               INTEGER DEFAULT 1,
            hit_count             INTEGER DEFAULT 0,
            created_at            TEXT,
            updated_at            TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_routing_rules_tenant ON routing_rules(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_routing_rules_enabled ON routing_rules(enabled)",
        # Team (group) credit pools (B4 — cyberpod-gateway integration)
        """CREATE TABLE IF NOT EXISTS group_budgets (
            id                     TEXT PRIMARY KEY,
            group_id               TEXT NOT NULL,
            tenant_id              TEXT,
            monthly_budget_usd     REAL DEFAULT 0,
            monthly_budget_tokens  INTEGER DEFAULT 0,
            consumed_usd           REAL DEFAULT 0,
            consumed_tokens        INTEGER DEFAULT 0,
            period_start           TEXT,
            created_at             TEXT,
            updated_at             TEXT
        )""",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_group_budgets_group ON group_budgets(group_id)",
        # Compliance framework plugin cache + overrides (B2 — cyberpod-gateway)
        """CREATE TABLE IF NOT EXISTS compliance_check_results (
            tenant_id       TEXT NOT NULL,
            control_id      TEXT NOT NULL,
            status          TEXT NOT NULL,
            evidence_json   TEXT DEFAULT '{}',
            notes           TEXT DEFAULT '',
            computed_in_ms  INTEGER DEFAULT 0,
            checked_at      TEXT NOT NULL,
            PRIMARY KEY (tenant_id, control_id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_compliance_cache_tenant ON compliance_check_results(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_compliance_cache_status ON compliance_check_results(status)",
        """CREATE TABLE IF NOT EXISTS tenant_compliance_overrides (
            tenant_id       TEXT NOT NULL,
            control_id      TEXT NOT NULL,
            status          TEXT NOT NULL,
            notes           TEXT DEFAULT '',
            evidence_json   TEXT DEFAULT '{}',
            set_by          TEXT DEFAULT '',
            expires_at      TEXT,
            created_at      TEXT,
            updated_at      TEXT,
            PRIMARY KEY (tenant_id, control_id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_compliance_overrides_tenant ON tenant_compliance_overrides(tenant_id)",
        # Durable compliance package registry — tracks every export (filesystem or S3 WORM)
        """CREATE TABLE IF NOT EXISTS compliance_packages (
            id            TEXT PRIMARY KEY,
            tenant_id     TEXT NOT NULL DEFAULT 'default',
            frameworks    TEXT NOT NULL,
            period_start  TEXT NOT NULL,
            period_end    TEXT NOT NULL,
            manifest_hash TEXT NOT NULL DEFAULT '',
            storage_type  TEXT NOT NULL DEFAULT 'filesystem',
            s3_bucket     TEXT,
            s3_key        TEXT,
            output_path   TEXT,
            gap_count     INTEGER NOT NULL DEFAULT 0,
            control_count INTEGER NOT NULL DEFAULT 0,
            generated_at  TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_compliance_packages_tenant ON compliance_packages(tenant_id, generated_at DESC)",
        # Durable audit package registry — tracks every WORM audit export (filesystem or S3)
        """CREATE TABLE IF NOT EXISTS audit_packages (
            id            TEXT PRIMARY KEY,
            tenant_id     TEXT NOT NULL DEFAULT 'default',
            from_ts       TEXT,
            to_ts         TEXT,
            entry_count   INTEGER NOT NULL DEFAULT 0,
            manifest_hash TEXT NOT NULL DEFAULT '',
            compliance_frameworks TEXT DEFAULT '[]',
            storage_type  TEXT NOT NULL DEFAULT 'filesystem',
            s3_bucket     TEXT,
            s3_key        TEXT,
            output_path   TEXT,
            created_at    TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_audit_packages_tenant ON audit_packages(tenant_id, created_at DESC)",

        # ── Gateway Migration: provider_capacity table (C1) ─────────────────────
        """CREATE TABLE IF NOT EXISTS provider_capacity (
            id                  TEXT PRIMARY KEY,
            tenant_id           TEXT,
            provider            TEXT NOT NULL,
            name                TEXT,
            type                TEXT,
            capacity_percent    INTEGER DEFAULT 0,
            requests_per_min    INTEGER DEFAULT 0,
            avg_latency_ms      INTEGER DEFAULT 0,
            status              TEXT DEFAULT 'healthy',
            region              TEXT,
            failover_order      INTEGER DEFAULT 0,
            updated_at          TEXT,
            created_at          TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_pcap_provider ON provider_capacity(provider, status)",
        "CREATE INDEX IF NOT EXISTS idx_pcap_tenant ON provider_capacity(tenant_id)",

        # ── Observability v2 ─────────────────────────────────────────────────
        # Phase 2A: opt-in prompt/response payload storage (PII-masked)
        """CREATE TABLE IF NOT EXISTS trace_payloads (
            id         TEXT PRIMARY KEY,
            trace_id   TEXT NOT NULL,
            direction  TEXT NOT NULL,
            content    TEXT,
            size_bytes INTEGER,
            truncated  INTEGER DEFAULT 0,
            ts         TEXT,
            tenant_id  TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_trace_payloads_trace  ON trace_payloads(trace_id)",
        "CREATE INDEX IF NOT EXISTS idx_trace_payloads_tenant ON trace_payloads(tenant_id, ts DESC)",
        # Phase 2B: time-to-first-token for streaming requests
        "ALTER TABLE traces ADD COLUMN ttft_ms INTEGER",
        # Phase 2C: cost as a first-class queryable column (also in meta_json for compat)
        "ALTER TABLE traces ADD COLUMN cost_usd REAL",
        # Security: store resolved IP at webhook registration to detect DNS rebinding at dispatch
        "ALTER TABLE webhooks ADD COLUMN resolved_ip TEXT",

        # ── Gateway Migration: tenant cache sync tracking (C2) ───────────────────
        "ALTER TABLE tenants ADD COLUMN synced_at TEXT",

        # ── Gateway Migration: provider_configs gateway merge fields (C3) ────────────────
        "ALTER TABLE provider_configs ADD COLUMN latency_p50_ms INTEGER",
        "ALTER TABLE provider_configs ADD COLUMN latency_p99_ms INTEGER",
        "ALTER TABLE provider_configs ADD COLUMN requests_today INTEGER DEFAULT 0",
        "ALTER TABLE provider_configs ADD COLUMN tokens_today INTEGER DEFAULT 0",
        "ALTER TABLE provider_configs ADD COLUMN cost_mtd REAL DEFAULT 0",
        "ALTER TABLE provider_configs ADD COLUMN error_rate REAL DEFAULT 0",
        "ALTER TABLE provider_configs ADD COLUMN models_json TEXT DEFAULT '[]'",
        "ALTER TABLE provider_configs ADD COLUMN priority INTEGER DEFAULT 0",

        # ── H1: prompt_versions.version type fix (TEXT → INTEGER) ────────────────
        # Cannot ALTER column type in SQLite; add a new column for numeric ordering.
        "ALTER TABLE prompt_versions ADD COLUMN version_int INTEGER",

        # ── H2: metric_values.demonstration type fix (TEXT → INTEGER) ────────────
        "ALTER TABLE metric_values ADD COLUMN demonstration_int INTEGER DEFAULT 0",

        # ── M2: traces.latency_ms type widening (INTEGER → REAL) ─────────────────
        "ALTER TABLE traces ADD COLUMN latency_ms_real REAL",

        # ── M4: Missing index on inferences(tenant_id) ──────────────────────────
        "CREATE INDEX IF NOT EXISTS idx_infer_tenant ON inferences(tenant_id)",
        # ── Sovereign Policy Engine (v2) ─────────────────────────────────────
        # policy_bundles: signed, content-addressed policy documents
        """CREATE TABLE IF NOT EXISTS policy_bundles (
            bundle_id        TEXT PRIMARY KEY,
            tenant_id        TEXT NOT NULL DEFAULT 'default',
            version          INTEGER NOT NULL,
            mode             TEXT NOT NULL DEFAULT 'observe',
            residency        TEXT NOT NULL DEFAULT 'any',
            content_json     TEXT NOT NULL,
            content_sha256   TEXT NOT NULL,
            signature        TEXT,
            status           TEXT NOT NULL DEFAULT 'draft',
            created_by       TEXT,
            created_at       TEXT,
            approved_by_json TEXT DEFAULT '[]',
            approved_at      TEXT,
            activated_at     TEXT,
            UNIQUE(tenant_id, version)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_policy_bundles_tenant ON policy_bundles(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_policy_bundles_status ON policy_bundles(status)",
        # policy_decisions: structured per-request verdicts
        """CREATE TABLE IF NOT EXISTS policy_decisions (
            decision_id        TEXT PRIMARY KEY,
            trace_id           TEXT,
            bundle_id          TEXT,
            tenant_id          TEXT NOT NULL DEFAULT 'default',
            principal          TEXT,
            action             TEXT NOT NULL,
            reason             TEXT,
            evaluated_rules_json TEXT,
            target_deployment  TEXT,
            residency          TEXT,
            redactions_json    TEXT,
            ts                 TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_policy_decisions_trace ON policy_decisions(trace_id)",
        "CREATE INDEX IF NOT EXISTS idx_policy_decisions_bundle ON policy_decisions(bundle_id)",
        "CREATE INDEX IF NOT EXISTS idx_policy_decisions_tenant ON policy_decisions(tenant_id, ts DESC)",
        "CREATE INDEX IF NOT EXISTS idx_policy_decisions_action ON policy_decisions(action)",
        # link traces to their decision
        "ALTER TABLE traces ADD COLUMN policy_decision_id TEXT",
        # Wave 1A P0: replay determinism — persist enough of the request
        # context to rebuild a RequestContext for /v1/policy/decisions/replay.
        "ALTER TABLE policy_decisions ADD COLUMN messages_json TEXT",
        "ALTER TABLE policy_decisions ADD COLUMN input_tokens INTEGER",
        "ALTER TABLE policy_decisions ADD COLUMN metadata_json TEXT",
        "ALTER TABLE policy_decisions ADD COLUMN bundle_age_seconds REAL",
        # Wave 1A P0: HMAC key rotation — record the key fingerprint that
        # signed each row so verify_audit_chain can pick the right key.
        "ALTER TABLE audit_chain ADD COLUMN key_fingerprint TEXT",
        # Wave 2B P1: per-tenant HKDF audit signing — record which tenant
        # owns the row so verify_audit_chain can derive the matching
        # per-tenant subkey from the master HMAC key. Rows lacking a
        # tenant_id (legacy entries / cross-tenant ops) fall back to the
        # master key.
        "ALTER TABLE audit_chain ADD COLUMN tenant_id TEXT",
        "CREATE INDEX IF NOT EXISTS idx_audit_chain_tenant ON audit_chain(tenant_id)",
        # Wave 2A P1: GDPR-compatible chain — keep a salted hash of the
        # principal alongside the principal itself so the chain stays
        # linkable after Art. 17 erasure (we null `principal`, keep
        # `principal_hash`).
        "ALTER TABLE policy_decisions ADD COLUMN principal_hash TEXT",
        "ALTER TABLE audit_chain ADD COLUMN principal_hash TEXT",
    ]:
        # Commit the big executescript transaction BEFORE any swallowed-error
        # rollback can wipe it out, then run each DDL in its own transaction
        # so a Postgres "column already exists" rollback only affects that
        # single statement and leaves prior ALTERs committed.
        try:
            conn.execute(ddl)
            conn.commit()
        except Exception as e:
            err = str(e).lower()
            benign = any(
                frag in err for frag in (
                    "duplicate column name",    # sqlite
                    "already exists",           # postgres, clickhouse
                    "duplicate column",         # postgres alt
                )
            )
            # Clear Postgres's poisoned transaction before the next statement.
            _rollback_quietly(conn)
            if not benign:
                raise
    conn.commit()


def _rollback_quietly(conn: StorageBackend) -> None:
    """Best-effort rollback. Delegates to ``conn.rollback()`` which every
    backend implements:
    - PostgresBackend: no-op (each execute() auto-commits; pool-level rollback
      is handled inside ``_with_connection`` on exception).
    - MongoBackend / ClickHouseBackend: no-op (auto-commit semantics).
    """
    try:
        conn.rollback()
    except (AttributeError, RuntimeError, OSError) as exc:
        logger.debug("rollback no-op or failed: %s", exc)
