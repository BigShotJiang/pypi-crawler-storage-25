from __future__ import annotations
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Optional
from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class License:
    id: str
    tenant_id: str
    plan: str
    seat_limit: int
    token_quota_monthly: int
    features_json: str
    valid_until: str
    created_at: str


@dataclass
class BillingRecord:
    id: str
    tenant_id: str
    period_start: str
    period_end: str
    total_tokens: int
    total_cost_usd: float
    seat_count: int


@dataclass
class QuotaStatus:
    within_quota: bool
    tokens_used: int
    tokens_limit: int
    seats_used: int
    seats_limit: int
    pct_tokens: float
    pct_seats: float


class BillingManager:
    def get_license(self, tenant_id: str) -> Optional[License]:
        row = get_shared_connection().execute(
            "SELECT * FROM licenses WHERE tenant_id=? ORDER BY created_at DESC LIMIT 1",
            (tenant_id,),
        ).fetchone()
        return License(**dict(row)) if row else None

    def set_license(
        self,
        tenant_id: str,
        plan: str = "free",
        seat_limit: int = 5,
        token_quota_monthly: int = 1_000_000,
        features: list[str] | None = None,
        valid_until: str | None = None,
    ) -> License:
        conn = get_shared_connection()
        lic = License(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            plan=plan,
            seat_limit=seat_limit,
            token_quota_monthly=token_quota_monthly,
            features_json=json.dumps(features or []),
            valid_until=valid_until or (datetime.now(timezone.utc) + timedelta(days=365)).isoformat(),
            created_at=_now(),
        )
        conn.execute(
            "INSERT INTO licenses(id,tenant_id,plan,seat_limit,token_quota_monthly,features_json,valid_until,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (
                lic.id,
                lic.tenant_id,
                lic.plan,
                lic.seat_limit,
                lic.token_quota_monthly,
                lic.features_json,
                lic.valid_until,
                lic.created_at,
            ),
        )
        conn.commit()
        return lic

    def check_quota(self, tenant_id: str) -> QuotaStatus:
        conn = get_shared_connection()
        lic = self.get_license(tenant_id)
        token_limit = lic.token_quota_monthly if lic else 1_000_000
        seat_limit = lic.seat_limit if lic else 5

        month_start = (
            datetime.now(timezone.utc)
            .replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            .isoformat()
        )
        tok_row = conn.execute(
            "SELECT SUM(input_tok+output_tok) as t FROM traces WHERE tenant_id=? AND ts>=?",
            (tenant_id, month_start),
        ).fetchone()
        tokens_used = (tok_row["t"] or 0) if tok_row else 0

        seat_row = conn.execute(
            "SELECT COUNT(*) as n FROM users WHERE tenant_id=? AND status='active'",
            (tenant_id,),
        ).fetchone()
        seats_used = (seat_row["n"] or 0) if seat_row else 0

        return QuotaStatus(
            within_quota=tokens_used < token_limit and seats_used <= seat_limit,
            tokens_used=tokens_used,
            tokens_limit=token_limit,
            seats_used=seats_used,
            seats_limit=seat_limit,
            pct_tokens=round(tokens_used / token_limit * 100, 1) if token_limit else 0,
            pct_seats=round(seats_used / seat_limit * 100, 1) if seat_limit else 0,
        )

    def billing_history(self, tenant_id: str, limit: int = 12) -> list[BillingRecord]:
        conn = get_shared_connection()
        rows = conn.execute(
            "SELECT * FROM billing_records WHERE tenant_id=? ORDER BY period_start DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        return [BillingRecord(**dict(r)) for r in rows]
