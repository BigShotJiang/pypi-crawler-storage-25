from .client import CoreIQClient, log_event
from .exceptions import CoreIQError, ValidationError, DatabaseError, ConfigError
from .evolution.feedback import FeedbackSignal
from .status import StatusReport
from .testing import MockCoreIQ, assert_event_logged
from .security import PromptInjectionError, OutputViolationError
from .governance import (
    PolicyViolation, ComplianceViolation, ComplianceFramework, export_compliance_package,
    hitl_gate,
)
from .performance import BudgetExceeded
from .tools import ToolSpec, ValidationResult, ToolSearchResult
from .evolution.sdk import VariantResult
from .prompts import PromptRegistry, PromptVersion, PromptStatus, DeploymentStatus

try:
    from .tracing import trace, session, agent_run, SpanKind, TraceSpan  # noqa: F401
    from .tracing import handoff, parallel_branch  # noqa: F401
    _has_tracing = True
except ImportError:
    _has_tracing = False

try:
    from .observability.adapter import ObservabilityAdapter, CoreIQObservabilityAdapter  # noqa: F401
    _has_adapter = True
except ImportError:
    _has_adapter = False

__version__ = "0.5.3"

__all__ = [
    "__version__",
    "CoreIQClient",
    "log_event",
    "CoreIQError",
    "ValidationError",
    "DatabaseError",
    "ConfigError",
    "FeedbackSignal",
    "StatusReport",
    "MockCoreIQ",
    "assert_event_logged",
    "PromptInjectionError",
    "OutputViolationError",
    "PolicyViolation",
    "ComplianceViolation",
    "ComplianceFramework",
    "export_compliance_package",
    "hitl_gate",
    "BudgetExceeded",
    "ToolSpec",
    "ValidationResult",
    "ToolSearchResult",
    "VariantResult",
    "PromptRegistry",
    "PromptVersion",
    "PromptStatus",
    "DeploymentStatus",
]

if _has_tracing:
    __all__ += ["trace", "session", "agent_run", "SpanKind", "TraceSpan", "handoff", "parallel_branch"]

if _has_adapter:
    __all__ += ["ObservabilityAdapter", "CoreIQObservabilityAdapter"]

try:
    from .sdk.install import install, uninstall  # noqa: F401
    from .sdk.errors import ProxyError  # noqa: F401
    __all__ += ["install", "uninstall", "ProxyError"]
except Exception:  # pragma: no cover - never block coreiq import on SDK
    pass
