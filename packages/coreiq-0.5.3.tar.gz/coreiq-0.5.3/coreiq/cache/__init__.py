"""Multi-replica cache coordination layer.

The in-process semantic cache (``coreiq/performance/cache.py``) is fast
but per-replica. This module supplies a Redis-backed coordinator that
shares cached completions and anomaly counters across all replicas.
"""
from .redis_coordinator import RedisCoordinator, get_coordinator

__all__ = ["RedisCoordinator", "get_coordinator"]
