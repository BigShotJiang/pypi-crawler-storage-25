"""Redis-backed coordinator for multi-replica deployments.

Centralises three cross-replica concerns behind a single Redis client:

1. Semantic cache L2 — replicas push completions into Redis so other
   replicas can hit them on retry.
2. Runtime anomaly counters — per-key 3-sigma counters that must be
   shared so anomalies aren't masked by load-balancing.
3. Canary cohort assignment — sticky tenant-to-variant mapping.

Configure via ``COREIQ_REDIS_URL`` (already used by the L2 cache). Falls
back to a no-op coordinator if Redis is not configured, so single-replica
deployments work unchanged.
"""
from __future__ import annotations

import json
import logging
import os
from typing import Any, Optional

logger = logging.getLogger("coreiq.cache.redis")


class RedisCoordinator:
    """Thin wrapper over redis-py for shared state.

    All methods are best-effort: Redis errors are logged at debug level
    and swallowed so a Redis outage degrades to single-replica behaviour
    rather than failing requests.
    """

    def __init__(self, url: str, namespace: str = "coreiq") -> None:
        try:
            import redis  # type: ignore[import-untyped]
        except ImportError as exc:
            raise RuntimeError("redis package required — install coreiq[redis]") from exc
        self._client = redis.Redis.from_url(url, decode_responses=True)
        self._ns = namespace
        self._enabled = True

    def _key(self, *parts: str) -> str:
        return ":".join((self._ns, *parts))

    # ---- Semantic cache --------------------------------------------------

    def cache_get(self, key: str) -> Optional[dict[str, Any]]:
        if not self._enabled:
            return None
        try:
            raw = self._client.get(self._key("cache", key))
        except Exception as exc:
            logger.debug("redis cache_get failed: %s", exc)
            return None
        if not raw:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None

    def cache_set(self, key: str, value: dict[str, Any], ttl_secs: int) -> None:
        if not self._enabled:
            return
        try:
            self._client.setex(self._key("cache", key), ttl_secs, json.dumps(value))
        except Exception as exc:
            logger.debug("redis cache_set failed: %s", exc)

    # ---- Anomaly counters -----------------------------------------------

    def anomaly_incr(self, key: str, ttl_secs: int = 3600) -> int:
        if not self._enabled:
            return 0
        try:
            pipe = self._client.pipeline()
            pipe.incr(self._key("anomaly", key))
            pipe.expire(self._key("anomaly", key), ttl_secs)
            results = pipe.execute()
            return int(results[0])
        except Exception as exc:
            logger.debug("redis anomaly_incr failed: %s", exc)
            return 0

    def anomaly_window(self, key: str) -> int:
        if not self._enabled:
            return 0
        try:
            return int(self._client.get(self._key("anomaly", key)) or 0)
        except Exception:
            return 0

    # ---- Canary cohort --------------------------------------------------

    def cohort_get(self, tenant: str) -> Optional[str]:
        if not self._enabled:
            return None
        try:
            return self._client.get(self._key("cohort", tenant))
        except Exception:
            return None

    def cohort_set(self, tenant: str, variant: str, ttl_secs: int = 86400) -> None:
        if not self._enabled:
            return
        try:
            self._client.setex(self._key("cohort", tenant), ttl_secs, variant)
        except Exception as exc:
            logger.debug("redis cohort_set failed: %s", exc)


_INSTANCE: Optional[RedisCoordinator] = None
_TRIED = False


def get_coordinator() -> Optional[RedisCoordinator]:
    """Return the process-wide coordinator, or ``None`` if Redis is off.

    Reads ``COREIQ_REDIS_URL`` once and caches the result. Failure to
    connect logs a warning and disables the coordinator for the lifetime
    of the process — callers should treat ``None`` as "no shared state".
    """
    global _INSTANCE, _TRIED
    if _TRIED:
        return _INSTANCE
    _TRIED = True
    url = os.environ.get("COREIQ_REDIS_URL", "").strip()
    if not url:
        return None
    try:
        _INSTANCE = RedisCoordinator(url)
        logger.info("redis coordinator enabled at %s", url)
    except Exception as exc:
        logger.warning("redis coordinator disabled: %s", exc)
        _INSTANCE = None
    return _INSTANCE
