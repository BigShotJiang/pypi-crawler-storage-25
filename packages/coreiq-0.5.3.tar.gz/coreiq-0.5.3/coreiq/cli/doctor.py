"""CLI: ``coreiq doctor`` — diagnose local CoreIQ setup.

Walks the developer through the most common pre-flight failures:

1. Is the proxy URL reachable? (``HEAD /healthz``)
2. Where is ``api_key`` coming from — env, credentials file, or missing?
3. Does the cached credential expire within the next 24h?
4. Which provider env vars are set? (so the proxy actually has upstream
   credentials to fan out to)

Exit code 0 = everything green, 1 = at least one red mark. Designed to be
the first thing a developer runs when ``coreiq.install()`` mysteriously
fails.
"""
from __future__ import annotations

import json
import os
import socket
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Tuple

import click

DEFAULT_PROXY_URL = "http://localhost:7823"

# Provider envs we look for. Keys are env var names; values are the
# friendly label printed alongside.
_PROVIDER_ENVS: tuple[tuple[str, str], ...] = (
    ("OPENAI_API_KEY", "openai"),
    ("ANTHROPIC_API_KEY", "anthropic"),
    ("GOOGLE_API_KEY", "google"),
    ("GEMINI_API_KEY", "gemini"),
    ("AZURE_OPENAI_API_KEY", "azure-openai"),
    ("MISTRAL_API_KEY", "mistral"),
    ("GROQ_API_KEY", "groq"),
    ("REPLICATE_API_TOKEN", "replicate"),
    ("HF_TOKEN", "huggingface"),
    ("FIREWORKS_API_KEY", "fireworks"),
    ("XAI_API_KEY", "xai"),
)


def _credentials_path() -> Path:
    return Path(os.path.expanduser("~/.coreiq/credentials"))


def _resolve_proxy_url(arg: Optional[str]) -> str:
    if arg:
        return arg
    env = os.environ.get("COREIQ_PROXY_URL", "").strip()
    if env:
        # Strip a trailing /v1 so we can hit /healthz at the root.
        if env.endswith("/v1"):
            env = env[:-3]
        return env
    return DEFAULT_PROXY_URL


def _check_proxy(proxy_url: str) -> Tuple[bool, str]:
    """Return ``(ok, detail)`` from a HEAD/GET to ``/healthz``."""
    try:
        import httpx  # noqa: WPS433
    except Exception as exc:  # pragma: no cover - httpx missing
        return False, f"httpx not installed: {exc}"

    base = proxy_url.rstrip("/")
    targets = [f"{base}/healthz", f"{base}/api/health"]
    last_err = ""
    for target in targets:
        try:
            resp = httpx.get(target, timeout=2.0)
            if resp.status_code < 400:
                return True, f"{target} -> {resp.status_code}"
            last_err = f"{target} -> HTTP {resp.status_code}"
        except Exception as exc:
            last_err = f"{target}: {exc}"
    return False, last_err or "no health endpoint reachable"


def _api_key_source() -> Tuple[str, Optional[str], Optional[datetime]]:
    """Return ``(source, key_prefix, expires_at)``.

    ``source`` is one of ``"env"``, ``"credentials"``, or ``"missing"``.
    """
    env = os.environ.get("COREIQ_API_KEY", "").strip()
    if env:
        return "env", (env[:8] + "...") if len(env) > 8 else env, None

    path = _credentials_path()
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            key = data.get("key") or ""
            expires_raw = data.get("expires_at")
            expires_at: Optional[datetime] = None
            if isinstance(expires_raw, (int, float)):
                expires_at = datetime.fromtimestamp(float(expires_raw), tz=timezone.utc)
            elif isinstance(expires_raw, str) and expires_raw:
                try:
                    expires_at = datetime.fromisoformat(expires_raw.replace("Z", "+00:00"))
                except ValueError:
                    expires_at = None
            prefix = (key[:8] + "...") if key else "(empty)"
            return "credentials", prefix, expires_at
        except (OSError, ValueError):
            return "credentials", "(unreadable)", None
    return "missing", None, None


def _detect_providers() -> list[str]:
    return [label for env, label in _PROVIDER_ENVS if os.environ.get(env, "").strip()]


def _mark(ok: bool) -> str:
    return click.style("OK  ", fg="green") if ok else click.style("FAIL", fg="red")


def doctor(proxy_url: Optional[str] = None) -> int:
    """Run all checks; return shell exit code (0 = all green, 1 = any red)."""
    resolved_url = _resolve_proxy_url(proxy_url)
    any_red = False

    click.echo(f"CoreIQ doctor — checking against {resolved_url}")
    click.echo("")

    # 1. Proxy reachability
    ok, detail = _check_proxy(resolved_url)
    click.echo(f"[{_mark(ok)}] proxy reachable: {detail}")
    if not ok:
        any_red = True
        click.echo(
            "       Hint: start the gateway with 'coreiq up' or set "
            "COREIQ_PROXY_URL to a running instance."
        )

    # 2. API key source
    source, prefix, expires_at = _api_key_source()
    if source == "env":
        click.echo(f"[{_mark(True)}] api_key source: env COREIQ_API_KEY ({prefix})")
    elif source == "credentials":
        click.echo(
            f"[{_mark(True)}] api_key source: ~/.coreiq/credentials ({prefix})"
        )
    else:
        any_red = True
        click.echo(
            f"[{_mark(False)}] api_key source: missing — set COREIQ_API_KEY or run 'coreiq login'"
        )

    # 3. Expiry warning
    if expires_at is not None:
        now = datetime.now(timezone.utc)
        if expires_at <= now:
            any_red = True
            click.echo(
                f"[{_mark(False)}] credential expired at {expires_at.isoformat()} — run 'coreiq login'"
            )
        elif expires_at - now <= timedelta(hours=24):
            any_red = True
            click.echo(
                f"[{_mark(False)}] credential expires within 24h ({expires_at.isoformat()}) — run 'coreiq login'"
            )
        else:
            click.echo(f"[{_mark(True)}] credential valid until {expires_at.isoformat()}")

    # 4. Provider envs
    providers = _detect_providers()
    if providers:
        click.echo(
            f"[{_mark(True)}] upstream providers detected: {', '.join(providers)}"
        )
    else:
        click.echo(
            f"[{_mark(False)}] no upstream provider keys detected "
            "(set OPENAI_API_KEY / ANTHROPIC_API_KEY / etc.)"
        )
        any_red = True

    # 5. HMAC key check (FAIL in production, WARN in dev)
    hmac_key = os.environ.get("COREIQ_AUDIT_HMAC_KEY", "").strip()
    fail_open = os.environ.get("COREIQ_AUDIT_FAIL_OPEN", "").strip().lower() in ("true", "1")
    is_production = os.environ.get("COREIQ_ENV", "development").strip().lower() == "production"
    if hmac_key:
        click.echo(f"[{_mark(True)}] COREIQ_AUDIT_HMAC_KEY: set")
    elif fail_open or not is_production:
        click.echo(
            f"[{click.style('WARN', fg='yellow')}] COREIQ_AUDIT_HMAC_KEY: not set "
            '— generate with: python -c "import secrets; print(secrets.token_hex(32))"'
            + (" (COREIQ_AUDIT_FAIL_OPEN=true)" if fail_open else " (set before deploying to production)")
        )
    else:
        any_red = True
        click.echo(
            f"[{_mark(False)}] COREIQ_AUDIT_HMAC_KEY: not set — generate with: "
            'python -c "import secrets; print(secrets.token_hex(32))"'
        )

    # 6. Port availability check
    port = int(os.environ.get("COREIQ_PORT", "7823"))
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as _sock:
        _sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            _sock.bind(("127.0.0.1", port))
            click.echo(f"[{_mark(True)}] port {port}: available")
        except OSError:
            click.echo(
                f"[{click.style('WARN', fg='yellow')}] port {port}: IN USE — another process is using this port"
            )

    # 7. Python version check
    ver = sys.version_info
    ver_str = f"{ver.major}.{ver.minor}.{ver.micro}"
    py_ok = ver >= (3, 11)
    if py_ok:
        click.echo(f"[{_mark(True)}] python {ver_str}")
    else:
        any_red = True
        click.echo(f"[{_mark(False)}] python {ver_str} — CoreIQ requires 3.11+")

    click.echo("")
    if any_red:
        click.echo(click.style("doctor: at least one check failed.", fg="red"))
        return 1
    click.echo(click.style("doctor: all checks passed.", fg="green"))
    return 0
