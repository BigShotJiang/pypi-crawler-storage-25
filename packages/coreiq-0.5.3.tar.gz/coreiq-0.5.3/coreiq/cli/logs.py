"""CLI: ``coreiq logs`` / ``coreiq tail`` — recent policy decisions.

Reads the last N rows from the ``policy_decisions`` table via the existing
:func:`coreiq.store.db.get_shared_connection` abstraction, so it
transparently works against SQLite / Postgres / MongoDB / ClickHouse. The
``otel`` backend is read-only at the wire, so we surface a clear message
instead of silently returning an empty list.

Output columns: ``ts | action | reason | model | principal | cost_usd``.
``model`` and ``cost_usd`` are joined from the ``traces`` table when a
matching ``trace_id`` exists; missing values render as ``-``.
"""
from __future__ import annotations

import os
import time
from typing import Any

import click

DEFAULT_LIMIT = 20


def _backend_type() -> str:
    return (os.environ.get("COREIQ_STORE_BACKEND", "sqlite") or "sqlite").strip().lower()


def _safe_str(value: Any, default: str = "-") -> str:
    if value is None:
        return default
    s = str(value)
    return s if s else default


def _fetch_rows(limit: int) -> list[tuple[Any, ...]]:
    """Fetch up to ``limit`` recent decisions joined with traces.

    Returns rows shaped ``(ts, action, reason, model, principal, cost_usd, decision_id)``.
    """
    from coreiq.store.db import get_shared_connection

    conn = get_shared_connection()
    sql = (
        "SELECT pd.ts, pd.action, pd.reason, t.model, pd.principal, t.cost_usd, "
        "pd.decision_id "
        "FROM policy_decisions pd "
        "LEFT JOIN traces t ON t.policy_decision_id = pd.decision_id "
        "ORDER BY pd.ts DESC LIMIT ?"
    )
    try:
        rows = conn.fetchall(sql, (int(limit),))
    except Exception:
        # Fallback: schema may not yet have policy_decision_id column or
        # any traces — just read decisions.
        rows = conn.fetchall(
            "SELECT ts, action, reason, NULL, principal, NULL, decision_id "
            "FROM policy_decisions ORDER BY ts DESC LIMIT ?",
            (int(limit),),
        )
    return list(rows or [])


def _print_rows(rows: list[tuple[Any, ...]]) -> None:
    # Most recent last — easier to read in a terminal scrollback.
    for row in reversed(rows):
        ts, action, reason, model, principal, cost_usd, _ = row
        cost_str = "-"
        if cost_usd is not None:
            try:
                cost_str = f"${float(cost_usd):.5f}"
            except (TypeError, ValueError):
                cost_str = "-"
        action_styled = action or "-"
        if action == "deny":
            action_styled = click.style(action, fg="red")
        elif action == "allow":
            action_styled = click.style(action, fg="green")
        elif action:
            action_styled = click.style(action, fg="yellow")
        click.echo(
            f"[{_safe_str(ts)}] {action_styled:<6} "
            f"reason={_safe_str(reason)} model={_safe_str(model)} "
            f"principal={_safe_str(principal)} cost={cost_str}"
        )


def logs(
    last: int = DEFAULT_LIMIT,
    follow: bool = False,
    poll_interval: float = 2.0,
) -> int:
    """Print recent policy decisions. Return shell exit code."""
    backend = _backend_type()
    if backend == "otel":
        click.echo(
            "coreiq logs is unavailable on the 'otel' backend — historical "
            "policy decisions are streamed to your collector, not stored. "
            "Query them in your observability backend (Honeycomb / Datadog / "
            "Tempo) instead.",
            err=True,
        )
        return 1

    try:
        rows = _fetch_rows(last)
    except Exception as exc:
        click.echo(f"error: failed to read policy_decisions: {exc}", err=True)
        return 1

    if not rows and not follow:
        click.echo("No policy decisions recorded yet.")
        return 0

    _print_rows(rows)
    if not follow:
        return 0

    seen: set[str] = {row[-1] for row in rows if row and row[-1] is not None}
    try:
        while True:
            time.sleep(poll_interval)
            try:
                new_rows = _fetch_rows(last)
            except Exception as exc:
                click.echo(f"error: failed to read policy_decisions: {exc}", err=True)
                return 1
            unseen = [r for r in new_rows if r and r[-1] not in seen]
            if unseen:
                _print_rows(unseen)
                seen.update(r[-1] for r in unseen if r[-1] is not None)
    except KeyboardInterrupt:
        click.echo("")
        return 0
