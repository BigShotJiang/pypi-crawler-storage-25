"""CoreIQ CLI entry point.

A small ``click`` application that dispatches to subcommands:

- ``coreiq serve`` — run the FastAPI server (the historical default).
- ``coreiq init``  — write a default ``./.coreiq/config.toml`` and ``.env.example``.
- ``coreiq up``    — auto-init if needed, then start the server.
- ``coreiq migrate`` — re-export of the existing migration tool.
- ``coreiq login`` — RFC 8628 OAuth 2.0 device-code SSO flow against
  Okta / Azure AD / Google.

For backwards compatibility, invoking ``coreiq`` with no subcommand is
equivalent to ``coreiq serve``.

We deliberately use ``click`` rather than ``typer`` here: ``click`` is
already a transitive dependency of FastAPI / uvicorn, so this module
avoids adding a new top-level requirement.
"""
from __future__ import annotations

import sys

import click


@click.group(invoke_without_command=True, help="CoreIQ — sovereign AI gateway")
@click.pass_context
def app(ctx: click.Context) -> None:
    """Top-level ``coreiq`` command."""
    if ctx.invoked_subcommand is None:
        # Back-compat: bare ``coreiq`` invocation runs the server.
        ctx.invoke(serve)


@app.command(help="Run the CoreIQ FastAPI server (legacy default).")
@click.option("--host", default=None, help="Bind address (overrides COREIQ_HOST).")
@click.option("--port", type=int, default=None, help="Listen port (overrides COREIQ_PORT).")
@click.option("--dev", is_flag=True, help="Enable hot reload (development mode).")
def serve(host: str | None, port: int | None, dev: bool) -> None:
    import os
    if host:
        os.environ["COREIQ_HOST"] = host
    if port is not None:
        os.environ["COREIQ_PORT"] = str(port)
    from coreiq.server.app import start

    if dev:
        start(reload=True, reload_dirs=["coreiq"])
    else:
        start()


@app.command(help="Write a default .coreiq/config.toml and .env.example.")
@click.option("--defaults", is_flag=True, help="Skip prompts and use safe defaults.")
@click.option("--force", is_flag=True, help="Overwrite an existing config.")
def init(defaults: bool, force: bool) -> None:
    from coreiq.cli.init import init as _init

    _init(defaults=defaults, force=force)


@app.command(help="Bootstrap (auto-init if needed) and start the server.")
@click.option("--check", is_flag=True, help="Validate config and exit without serving.")
@click.option("--host", default=None, help="Bind address (overrides COREIQ_HOST).")
@click.option("--port", type=int, default=None, help="Listen port (overrides COREIQ_PORT).")
def up(check: bool, host: str | None, port: int | None) -> None:
    import os
    if host:
        os.environ["COREIQ_HOST"] = host
    if port is not None:
        os.environ["COREIQ_PORT"] = str(port)
    from coreiq.cli.up import up as _up

    _up(check=check)


@app.command(help="Migrate the CoreIQ database between backends.")
@click.argument("args", nargs=-1, type=click.UNPROCESSED)
def migrate(args: tuple[str, ...]) -> None:
    """Thin wrapper that re-exports the existing argparse-based migrate CLI."""
    from coreiq.cli.migrate import main as _migrate_main

    # Forward unparsed args to the legacy argparse-based main().
    saved = sys.argv
    try:
        sys.argv = ["coreiq-migrate", *args]
        _migrate_main()
    finally:
        sys.argv = saved


@app.command(help="Log in to CoreIQ via your SSO IdP (RFC 8628 device-code).")
@click.option(
    "--sso",
    "provider",
    type=click.Choice(["okta", "azure", "google"]),
    default=None,
    help="IdP provider (env: COREIQ_SSO_PROVIDER).",
)
@click.option(
    "--client-id",
    default=None,
    help="OAuth client ID (env: COREIQ_SSO_CLIENT_ID).",
)
@click.option(
    "--tenant",
    default=None,
    help="Tenant identifier — Okta domain or Azure tenant UUID (env: COREIQ_SSO_TENANT).",
)
@click.option(
    "--server-url",
    default=None,
    help="CoreIQ server URL (env: COREIQ_SERVER_URL).",
)
def login(
    provider: str | None,
    client_id: str | None,
    tenant: str | None,
    server_url: str | None,
) -> None:
    """Open a browser, run RFC 8628 device-code, and save credentials to ~/.coreiq/credentials."""
    import os

    from coreiq.cli.login import PROVIDER_PRESETS, login as _login

    resolved_provider = provider or os.environ.get("COREIQ_SSO_PROVIDER", "").strip() or None
    if not resolved_provider:
        raise click.UsageError(
            "Pass --sso {okta,azure,google} or set COREIQ_SSO_PROVIDER."
        )
    if resolved_provider not in PROVIDER_PRESETS:
        raise click.UsageError(
            f"Unknown provider {resolved_provider!r}. "
            f"Supported: {sorted(PROVIDER_PRESETS)}"
        )

    try:
        _login(
            provider=resolved_provider,
            server_url=server_url,
            client_id=client_id,
            tenant=tenant,
        )
    except SystemExit as exc:
        msg = exc.code if isinstance(exc.code, str) else None
        if msg:
            click.echo(msg, err=True)
        raise click.exceptions.Exit(1) from exc


@app.command(help="Show info about the cached SSO credentials.")
def whoami() -> None:
    from coreiq.cli.whoami import whoami as _whoami

    raise click.exceptions.Exit(_whoami())


@app.command(help="Delete cached SSO credentials.")
@click.option("--yes", "-y", is_flag=True, help="Skip the confirmation prompt.")
def logout(yes: bool) -> None:
    from coreiq.cli.logout import logout as _logout

    raise click.exceptions.Exit(_logout(yes=yes))


@app.command(help="Diagnose local CoreIQ setup (proxy reachable, key, providers).")
@click.option(
    "--proxy-url",
    default=None,
    help="Override the proxy URL to probe (env: COREIQ_PROXY_URL).",
)
def doctor(proxy_url: str | None) -> None:
    from coreiq.cli.doctor import doctor as _doctor

    raise click.exceptions.Exit(_doctor(proxy_url=proxy_url))


@app.command(help="Show recent policy decisions from the configured backend.")
@click.option("--last", "-n", default=20, type=int, help="Number of rows to show.")
@click.option("--follow", "-f", is_flag=True, help="Tail new rows every 2s (Ctrl-C to exit).")
def logs(last: int, follow: bool) -> None:
    from coreiq.cli.logs import logs as _logs

    raise click.exceptions.Exit(_logs(last=last, follow=follow))


@app.command(help="Alias for `coreiq logs --follow`.")
@click.option("--last", "-n", default=20, type=int, help="Number of rows to show.")
def tail(last: int) -> None:
    from coreiq.cli.logs import logs as _logs

    raise click.exceptions.Exit(_logs(last=last, follow=True))


@app.command(help="Print a shell-completion script. Pipe it into your shell rc.")
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]))
def completion(shell: str) -> None:
    """Emit the Click completion script for *shell*.

    Usage::

        # Bash
        coreiq completion bash >> ~/.bashrc

        # Zsh
        coreiq completion zsh >> ~/.zshrc

        # Fish
        coreiq completion fish > ~/.config/fish/completions/coreiq.fish
    """
    import os
    import subprocess

    env = {
        **os.environ,
        "_COREIQ_COMPLETE": f"{shell}_source",
    }
    try:
        result = subprocess.run(
            ["coreiq"], env=env, capture_output=True, text=True, check=False
        )
    except FileNotFoundError:
        # Fallback: invoke ourselves directly via python -m.
        result = subprocess.run(
            [sys.executable, "-m", "coreiq.cli.main"],
            env=env, capture_output=True, text=True, check=False,
        )
    if result.returncode != 0 or not result.stdout.strip():
        click.echo(
            f"failed to generate {shell} completion: {result.stderr}", err=True
        )
        raise click.exceptions.Exit(1)
    click.echo(result.stdout, nl=False)


if __name__ == "__main__":
    app()
