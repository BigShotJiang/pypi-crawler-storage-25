"""CLI: coreiq login — RFC 8628 OAuth 2.0 Device Authorization Grant.

Drives the laptop developer through an SSO browser flow against Okta,
Azure AD, or Google, validates the returned ID token via the existing
:mod:`coreiq.identity.oidc` JWKS verifier, and exchanges it for a
long-lived CoreIQ virtual key via ``POST /auth/provision``.

Usage::

    coreiq login --sso okta   --tenant mycompany.okta.com --client-id <id>
    coreiq login --sso azure  --tenant <tenant-uuid>      --client-id <id>
    coreiq login --sso google --client-id <id>

Credentials are persisted to ``~/.coreiq/credentials`` with mode 0600.
``coreiq.install()`` auto-loads from this file when no api_key is passed.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import logging
import os
import secrets
import stat
import sys
import time
import webbrowser
from pathlib import Path
from typing import Any, Optional

try:
    import httpx
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "httpx is required for `coreiq login`. "
        "Install it: pip install 'coreiq[identity]'"
    ) from exc

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Provider presets (RFC 8628 device authorization endpoints)
# ---------------------------------------------------------------------------

PROVIDER_PRESETS: dict[str, dict[str, str]] = {
    "okta": {
        "device_endpoint": "https://{tenant}/oauth2/v1/device/authorize",
        "token_endpoint": "https://{tenant}/oauth2/v1/token",
        "jwks_uri": "https://{tenant}/oauth2/v1/keys",
        # Expected issuer template — validated against the id_token's `iss` claim.
        "issuer": "https://{tenant}",
        "scope": "openid profile email",
        "needs_tenant": "true",
        # Wave 3A: Okta supports PKCE (S256) on the device-code flow.
        "supports_pkce": "true",
    },
    "azure": {
        "device_endpoint": "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/devicecode",
        "token_endpoint": "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        "jwks_uri": "https://login.microsoftonline.com/{tenant}/discovery/v2.0/keys",
        "issuer": "https://login.microsoftonline.com/{tenant}/v2.0",
        "scope": "openid profile email",
        "needs_tenant": "true",
        # Azure AD v2.0 accepts PKCE params on devicecode (silently ignored
        # if not enabled at the app registration; harmless).
        "supports_pkce": "true",
    },
    "google": {
        "device_endpoint": "https://oauth2.googleapis.com/device/code",
        "token_endpoint": "https://oauth2.googleapis.com/token",
        "jwks_uri": "https://www.googleapis.com/oauth2/v3/certs",
        "issuer": "https://accounts.google.com",
        # Google does not accept "openid profile email" on device-code; use the
        # explicit userinfo.email scope (plus profile + openid).
        "scope": "openid profile https://www.googleapis.com/auth/userinfo.email",
        "needs_tenant": "false",
        # Google's device-code endpoint rejects unknown parameters; skip PKCE.
        "supports_pkce": "false",
    },
}

# Sane upper bound for end-to-end login (overrides expires_in if larger)
_MAX_LOGIN_SECONDS = 900

DEFAULT_SERVER_URL = "http://localhost:7823"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve(arg: Optional[str], env_var: str, label: str) -> str:
    val = arg or os.environ.get(env_var, "").strip()
    if not val:
        raise SystemExit(
            f"error: {label} not provided. "
            f"Pass --{label.replace('_', '-')} or set {env_var}."
        )
    return val


def _format_endpoint(template: str, tenant: str) -> str:
    return template.format(tenant=tenant) if "{tenant}" in template else template


def _generate_pkce_pair() -> tuple[str, str]:
    """Generate a PKCE (RFC 7636) ``(code_verifier, code_challenge)`` pair.

    The verifier is 43 base64url characters of cryptographically-secure
    randomness (the minimum length permitted by RFC 7636 §4.1). The
    challenge is ``base64url(sha256(verifier))`` — the S256 method, which
    is the only method we send (``plain`` is forbidden by RFC 8628 §3.4).
    """
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode("ascii")
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def _generate_state() -> str:
    """Generate an opaque ``state`` value (CSRF mitigation per RFC 6749 §10.12)."""
    return secrets.token_urlsafe(24)


def _credentials_path() -> Path:
    return Path(os.path.expanduser("~/.coreiq/credentials"))


def _save_credentials(payload: dict[str, Any]) -> Path:
    """Atomically persist credentials with mode 0600.

    Uses ``os.open(..., O_WRONLY|O_CREAT|O_EXCL, 0o600)`` to a temp file in the
    same directory, fsyncs, then ``os.rename()`` over the destination. This
    guarantees that the on-disk file is never observable with permissions
    laxer than 0600 (closing the TOCTOU window of write-then-chmod).
    """
    path = _credentials_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    # Lock down the parent dir if we just created it (best effort; do not
    # tighten perms on an existing dir the user may share).
    try:
        os.chmod(path.parent, stat.S_IRWXU)
    except OSError:
        pass

    data = json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
    tmp_path = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    # If a stale tmp file from a previous crashed run exists, remove it — we
    # need O_EXCL to succeed.
    try:
        os.unlink(tmp_path)
    except FileNotFoundError:
        pass

    fd = os.open(str(tmp_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.rename(tmp_path, path)
    return path


def _validate_id_token(
    id_token: str,
    jwks_uri: str,
    client: httpx.Client,
    *,
    expected_issuer: str,
    expected_audience: str,
) -> dict[str, Any]:
    """Validate id_token signature, ``iss`` and ``aud`` using JWKS at *jwks_uri*.

    Reuses :mod:`coreiq.identity.oidc` JWKS cache (so subsequent server-side
    validations don't re-fetch) but routes the actual fetch through the
    injected ``httpx.Client`` so tests / proxies see it.  We delegate the
    signature check to ``python-jose`` and additionally enforce:

    - ``iss`` matches the selected provider preset's issuer (prevents IdP
      substitution by a hostile token issuer).
    - ``aud`` matches the configured client_id (prevents token-replay where
      a token minted for app A is used to provision a key against app B).
    """
    from ..identity import oidc as _oidc

    try:
        from jose import jwt, JWTError
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "python-jose is required to validate ID tokens. "
            "Install it: pip install 'coreiq[identity]'"
        ) from exc

    cached = _oidc._JWKS_CACHE.get(jwks_uri)
    if cached and (time.time() - cached[1]) < _oidc._JWKS_CACHE_TTL:
        jwks = cached[0]
    else:
        resp = client.get(jwks_uri, timeout=10.0)
        resp.raise_for_status()
        jwks = resp.json()
        _oidc._JWKS_CACHE[jwks_uri] = (jwks, time.time())

    try:
        claims = jwt.decode(
            id_token,
            jwks,
            algorithms=["RS256", "RS384", "RS512"],
            audience=expected_audience,
            issuer=expected_issuer,
            options={"verify_aud": True, "verify_iss": True, "verify_exp": True},
        )
    except JWTError as exc:
        raise SystemExit(f"error: ID token validation failed: {exc}") from exc

    return claims


# ---------------------------------------------------------------------------
# Device-code flow
# ---------------------------------------------------------------------------


def _request_device_code(
    client: httpx.Client,
    device_endpoint: str,
    client_id: str,
    scope: str,
    *,
    code_challenge: Optional[str] = None,
    state: Optional[str] = None,
) -> dict[str, Any]:
    data: dict[str, str] = {"client_id": client_id, "scope": scope}
    if code_challenge:
        # RFC 8628 §3.4 best practice + RFC 7636: send S256 only.
        data["code_challenge"] = code_challenge
        data["code_challenge_method"] = "S256"
    if state:
        data["state"] = state
    resp = client.post(
        device_endpoint,
        data=data,
        headers={"Accept": "application/json"},
        timeout=10.0,
    )
    if resp.status_code >= 400:
        raise SystemExit(
            f"error: device authorization request failed: "
            f"HTTP {resp.status_code} — {resp.text}"
        )
    body = resp.json()
    # Some providers return verification_uri (Google) instead of
    # verification_uri_complete. Construct a fallback.
    if "verification_uri_complete" not in body:
        v = body.get("verification_uri") or body.get("verification_url") or ""
        u = body.get("user_code", "")
        if v and u:
            sep = "&" if "?" in v else "?"
            body["verification_uri_complete"] = f"{v}{sep}user_code={u}"
        else:
            body["verification_uri_complete"] = v
    return body


def _poll_for_token(
    client: httpx.Client,
    token_endpoint: str,
    client_id: str,
    device_code: str,
    interval: int,
    expires_in: int,
    sleep_fn: Any = time.sleep,
    *,
    code_verifier: Optional[str] = None,
    state: Optional[str] = None,
) -> dict[str, Any]:
    """Poll *token_endpoint* until success / failure / expiry."""
    deadline = time.time() + min(expires_in, _MAX_LOGIN_SECONDS)
    cur_interval = max(1, int(interval))

    while True:
        if time.time() >= deadline:
            raise SystemExit(
                "error: login timed out before approval. "
                "Re-run `coreiq login` and complete the browser step faster."
            )
        sleep_fn(cur_interval)

        token_data: dict[str, str] = {
            "client_id": client_id,
            "device_code": device_code,
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
        }
        if code_verifier:
            token_data["code_verifier"] = code_verifier
        resp = client.post(
            token_endpoint,
            data=token_data,
            headers={"Accept": "application/json"},
            timeout=10.0,
        )
        try:
            body = resp.json()
        except Exception as exc:
            raise SystemExit(
                f"error: token endpoint returned non-JSON response: {resp.text!r}"
            ) from exc

        if resp.status_code == 200 and "access_token" in body:
            # RFC 6749 §10.12: when the IdP echoes ``state`` back, validate
            # it. Most device-flow IdPs do not echo state — silently accept
            # responses that omit it.
            returned_state = body.get("state")
            if state and returned_state and returned_state != state:
                raise SystemExit(
                    "error: token endpoint returned a state value that does not "
                    "match the one we sent — possible CSRF / response substitution. "
                    "Re-run `coreiq login`."
                )
            return body

        err = body.get("error", "")
        if err == "authorization_pending":
            continue
        if err == "slow_down":
            cur_interval += 5
            continue
        if err == "expired_token":
            raise SystemExit(
                "error: device code expired before approval. "
                "Re-run `coreiq login` and approve in the browser within the "
                "displayed time window."
            )
        if err == "access_denied":
            raise SystemExit(
                "error: access denied by the IdP. "
                "Ask your administrator to grant device-code access for this app."
            )
        # Unknown error — surface clearly
        desc = body.get("error_description") or body.get("error") or resp.text
        raise SystemExit(f"error: token endpoint returned: {desc}")


def _exchange_for_coreiq_key(
    client: httpx.Client,
    server_url: str,
    provider: str,
    id_token: str,
) -> dict[str, Any]:
    url = server_url.rstrip("/") + "/auth/provision"
    resp = client.post(
        url,
        json={"idp": provider, "token": id_token},
        timeout=15.0,
    )
    if resp.status_code >= 400:
        raise SystemExit(
            f"error: /auth/provision failed: HTTP {resp.status_code} — {resp.text}"
        )
    return resp.json()


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def login(
    provider: str,
    server_url: Optional[str] = None,
    client_id: Optional[str] = None,
    tenant: Optional[str] = None,
    *,
    http_client: Optional[httpx.Client] = None,
    sleep_fn: Any = time.sleep,
    open_browser: bool = True,
) -> dict[str, Any]:
    """Run the device-code SSO flow and persist a CoreIQ virtual key.

    Returns the credentials payload that was written to disk.
    """
    if provider not in PROVIDER_PRESETS:
        raise SystemExit(
            f"error: unknown provider {provider!r}. "
            f"Supported: {sorted(PROVIDER_PRESETS)}"
        )

    preset = PROVIDER_PRESETS[provider]

    client_id = client_id or os.environ.get("COREIQ_SSO_CLIENT_ID", "").strip() or None
    if not client_id:
        raise SystemExit(
            "error: --client-id not provided and COREIQ_SSO_CLIENT_ID not set."
        )

    if preset["needs_tenant"] == "true":
        tenant = tenant or os.environ.get("COREIQ_SSO_TENANT", "").strip() or None
        if not tenant:
            raise SystemExit(
                f"error: --tenant required for provider {provider!r}. "
                "Set --tenant or COREIQ_SSO_TENANT."
            )
    else:
        tenant = tenant or ""

    server_url = (
        server_url
        or os.environ.get("COREIQ_SERVER_URL", "").strip()
        or DEFAULT_SERVER_URL
    )

    device_endpoint = _format_endpoint(preset["device_endpoint"], tenant)
    token_endpoint = _format_endpoint(preset["token_endpoint"], tenant)
    jwks_uri = _format_endpoint(preset["jwks_uri"], tenant)
    expected_issuer = _format_endpoint(preset["issuer"], tenant)
    expected_audience = client_id
    scope = preset["scope"]

    # Wave 3A: PKCE (RFC 7636 S256) + state (RFC 6749 §10.12) per
    # RFC 8628 §3.4 best-practice. Generated unconditionally so we never
    # leak whether the provider is PKCE-capable from the client's
    # request shape; sent only to providers that advertise support.
    code_verifier, code_challenge = _generate_pkce_pair()
    state = _generate_state()
    pkce_enabled = preset.get("supports_pkce", "false") == "true"
    if not pkce_enabled:
        logger.debug(
            "PKCE skipped for provider=%s (preset opt-out — endpoint rejects unknown params)",
            provider,
        )

    owns_client = http_client is None
    client = http_client or httpx.Client()
    try:
        # 1. Request device code
        dc = _request_device_code(
            client,
            device_endpoint,
            client_id,
            scope,
            code_challenge=code_challenge if pkce_enabled else None,
            state=state if pkce_enabled else None,
        )
        user_code = dc.get("user_code", "")
        verification_uri_complete = dc.get("verification_uri_complete", "")
        interval = int(dc.get("interval", 5) or 5)
        expires_in = int(dc.get("expires_in", 600) or 600)
        device_code = dc["device_code"]

        # 2. Show the user what to do
        print()
        print("=" * 64)
        print("  CoreIQ login — open this URL and approve the request:")
        print()
        print(f"    {verification_uri_complete}")
        print()
        print(f"  Code: {user_code}")
        print("=" * 64)
        print()

        if open_browser and verification_uri_complete:
            try:
                webbrowser.open(verification_uri_complete)
            except Exception:  # pragma: no cover
                logger.debug("webbrowser.open failed; continue with manual flow")

        # 3. Poll the token endpoint
        token_resp = _poll_for_token(
            client,
            token_endpoint,
            client_id,
            device_code,
            interval=interval,
            expires_in=expires_in,
            sleep_fn=sleep_fn,
            code_verifier=code_verifier if pkce_enabled else None,
            state=state if pkce_enabled else None,
        )

        id_token = token_resp.get("id_token")
        if not id_token:
            raise SystemExit(
                "error: IdP did not return an id_token. "
                "Ensure the 'openid' scope is permitted for this client."
            )

        # 4. Validate id_token signature + iss + aud using JWKS verifier
        claims = _validate_id_token(
            id_token,
            jwks_uri,
            client,
            expected_issuer=expected_issuer,
            expected_audience=expected_audience,
        )
        subject = (
            claims.get("email")
            or claims.get("preferred_username")
            or claims.get("sub")
            or "unknown"
        )

        # 5. Exchange for a CoreIQ virtual key
        prov = _exchange_for_coreiq_key(client, server_url, provider, id_token)
        coreiq_key = prov.get("key")
        if not coreiq_key:
            raise SystemExit(
                f"error: /auth/provision did not return a key: {prov!r}"
            )

        # 6. Persist credentials (chmod 0600)
        payload = {
            "server": server_url,
            "key": coreiq_key,
            "expires_at": prov.get("expires_at"),
            "subject": subject,
        }
        path = _save_credentials(payload)
        print(f"Logged in as {subject}. Credentials saved to {path}.")
        return payload
    finally:
        if owns_client:
            client.close()


# ---------------------------------------------------------------------------
# argparse entry point (fallback when cli/main.py is not yet wired)
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="coreiq login",
        description="OAuth2 device-code SSO login (RFC 8628) — Okta / Azure / Google.",
    )
    p.add_argument(
        "--sso",
        dest="provider",
        choices=sorted(PROVIDER_PRESETS),
        default=os.environ.get("COREIQ_SSO_PROVIDER", "okta"),
        help="IdP provider (env: COREIQ_SSO_PROVIDER, default: okta).",
    )
    p.add_argument(
        "--client-id",
        default=None,
        help="OAuth client ID (env: COREIQ_SSO_CLIENT_ID).",
    )
    p.add_argument(
        "--tenant",
        default=None,
        help=(
            "Tenant identifier — Okta domain (e.g. mycompany.okta.com), "
            "Azure tenant UUID, or unused for Google "
            "(env: COREIQ_SSO_TENANT)."
        ),
    )
    p.add_argument(
        "--server-url",
        default=None,
        help=(
            "CoreIQ server URL (env: COREIQ_SERVER_URL, "
            f"default: {DEFAULT_SERVER_URL})."
        ),
    )
    return p


def main(argv: Optional[list[str]] = None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        login(
            provider=args.provider,
            server_url=args.server_url,
            client_id=args.client_id,
            tenant=args.tenant,
        )
    except SystemExit as exc:
        # SystemExit messages already shaped by login() — pass through.
        if isinstance(exc.code, str):
            print(exc.code, file=sys.stderr)
            return 1
        return int(exc.code or 0)
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
