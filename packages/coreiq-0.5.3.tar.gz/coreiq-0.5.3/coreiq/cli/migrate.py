"""CLI: coreiq-migrate — migrate CoreIQ database to a different backend.

Usage:
    coreiq-migrate --to postgres --dsn postgresql://user:pass@host:5432/coreiq
    coreiq-migrate --to clickhouse --dsn http://default:@localhost:8123 --database coreiq
    coreiq-migrate --verify --backend postgres --dsn postgresql://...
    coreiq-migrate --verify --backend clickhouse --dsn http://localhost:8123
    coreiq-migrate --verify --backend sqlite
"""
import argparse
import re
import sys

_DSN_SCRUB_RE = re.compile(r"(://[^:/@\s]+:)[^@\s]*(@)")


def _scrub_dsn(s: str) -> str:
    """Replace passwords in DSN-like strings with '***'."""
    return _DSN_SCRUB_RE.sub(r"\1***\2", str(s))


def migrate_sqlite_to_postgres(dsn: str, verbose: bool = False) -> None:
    """Copy all data from the default SQLite DB to a Postgres instance."""
    import sqlite3

    from ..config import get_db_path
    from ..store.backends.postgres_backend import PostgresBackend

    sqlite_path = get_db_path()
    if not sqlite_path.exists():
        print(f"SQLite database not found at {sqlite_path}")
        sys.exit(1)

    print(f"Migrating from SQLite ({sqlite_path}) → Postgres ({dsn[:40]}...)")

    src = sqlite3.connect(str(sqlite_path))
    src.row_factory = sqlite3.Row

    try:
        pg = PostgresBackend(dsn)
    except ImportError as e:
        print(f"Error: {_scrub_dsn(e)}")
        sys.exit(1)

    tables = [
        r[0] for r in src.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()
    ]

    for table in tables:
        rows = src.execute(f"SELECT * FROM {table}").fetchall()
        if not rows:
            if verbose:
                print(f"  {table}: 0 rows (skipped)")
            continue

        cols = list(rows[0].keys())
        placeholders = ", ".join(["%s"] * len(cols))
        col_names = ", ".join(cols)
        insert_sql = f"INSERT INTO {table} ({col_names}) VALUES ({placeholders}) ON CONFLICT DO NOTHING"

        count = 0
        for row in rows:
            try:
                pg.execute(insert_sql, tuple(row))
                count += 1
            except Exception as e:
                if verbose:
                    print(f"  Warning: {table} row insert failed: {_scrub_dsn(e)}")
        pg.commit()
        print(f"  {table}: {count} rows migrated")

    pg.close()
    src.close()
    print("Migration complete.")


def migrate_sqlite_to_clickhouse(dsn: str, database: str = "coreiq", verbose: bool = False) -> None:
    """Copy all data from the default SQLite DB to a ClickHouse instance.

    Uses ``clickhouse-connect.client.insert`` for batch inserts (orders of
    magnitude faster than row-by-row INSERTs on ClickHouse). The target
    schema is initialised via the normal :func:`init_schema` path, which
    routes DDL through the dialect translator.
    """
    import sqlite3

    from ..config import get_db_path
    from ..store.backends.clickhouse_backend import ClickHouseBackend
    from ..store.db import init_schema

    sqlite_path = get_db_path()
    if not sqlite_path.exists():
        print(f"SQLite database not found at {sqlite_path}")
        sys.exit(1)

    print(f"Migrating from SQLite ({sqlite_path}) → ClickHouse ({dsn[:40]}..., db={database})")

    src = sqlite3.connect(str(sqlite_path))
    src.row_factory = sqlite3.Row

    try:
        ch = ClickHouseBackend(dsn, database)
    except ImportError as e:
        print(f"Error: {_scrub_dsn(e)}")
        sys.exit(1)

    # Ensure ClickHouse tables exist before we start inserting.
    init_schema(ch)

    tables = [
        r[0] for r in src.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()
    ]

    for table in tables:
        rows = src.execute(f"SELECT * FROM {table}").fetchall()
        if not rows:
            if verbose:
                print(f"  {table}: 0 rows (skipped)")
            continue

        cols = list(rows[0].keys())
        data = [[row[c] for c in cols] for row in rows]
        try:
            ch._client.insert(table, data, column_names=cols)
            print(f"  {table}: {len(data)} rows migrated")
        except Exception as exc:
            if verbose:
                print(f"  Warning: {table} bulk insert failed ({_scrub_dsn(exc)}); falling back row-by-row")
            count = 0
            for row in data:
                try:
                    ch._client.insert(table, [row], column_names=cols)
                    count += 1
                except Exception as exc2:
                    if verbose:
                        print(f"    row skipped: {_scrub_dsn(exc2)}")
            print(f"  {table}: {count}/{len(data)} rows migrated (row-by-row)")

    ch.close()
    src.close()
    print("Migration complete.")


def verify_backend(backend: str, dsn: str = "", database: str = "coreiq") -> None:
    """Verify a backend is reachable and has the correct schema."""
    if backend == "postgres":
        from ..store.backends.postgres_backend import PostgresBackend
        try:
            pg = PostgresBackend(dsn)
            result = pg.fetchone("SELECT COUNT(*) AS n FROM traces")
            count = result["n"] if result and "n" in result else (result[0] if result else 0)
            print(f"Postgres backend OK — traces table has {count} rows")
            pg.close()
        except Exception as e:
            print(f"Postgres backend ERROR: {_scrub_dsn(e)}")
            sys.exit(1)
    elif backend == "clickhouse":
        from ..store.backends.clickhouse_backend import ClickHouseBackend
        try:
            ch = ClickHouseBackend(dsn, database)
            result = ch.fetchone("SELECT count() AS n FROM traces")
            count = (result or {}).get("n", 0)
            print(f"ClickHouse backend OK — traces table has {count} rows")
            ch.close()
        except Exception as e:
            print(f"ClickHouse backend ERROR: {_scrub_dsn(e)}")
            sys.exit(1)
    elif backend == "sqlite":
        from ..config import get_db_path
        path = get_db_path()
        if path.exists():
            print(f"SQLite backend OK — {path}")
        else:
            print(f"SQLite backend: no database at {path} (will be created on first use)")
    else:
        print(f"Unknown backend: {backend}")
        sys.exit(1)


def main() -> None:
    parser = argparse.ArgumentParser(description="CoreIQ database migration tool")
    parser.add_argument("--to", choices=["postgres", "clickhouse", "sqlite"], help="Target backend")
    parser.add_argument("--dsn", default="", help="Target backend DSN")
    parser.add_argument("--database", default="coreiq", help="Target database name (ClickHouse)")
    parser.add_argument("--verify", action="store_true", help="Verify backend connectivity")
    parser.add_argument("--backend", default="postgres", help="Backend to verify (with --verify)")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    if args.verify:
        verify_backend(args.backend, args.dsn, args.database)
    elif args.to == "postgres":
        if not args.dsn:
            print("Error: --dsn required for postgres migration")
            sys.exit(1)
        migrate_sqlite_to_postgres(args.dsn, verbose=args.verbose)
    elif args.to == "clickhouse":
        if not args.dsn:
            print("Error: --dsn required for clickhouse migration")
            sys.exit(1)
        migrate_sqlite_to_clickhouse(args.dsn, args.database, verbose=args.verbose)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
