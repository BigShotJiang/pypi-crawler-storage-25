"""``coreiq up`` — auto-init (if needed) then start the server."""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

import click

_CONFIG_PATH = Path(".coreiq") / "config.toml"

# 5s connectivity probe ceiling — keeps `coreiq up --check` snappy in CI.
_CHECK_TIMEOUT_S = 5.0


def _validate_config(cfg_path: Path) -> bool:
    """Best-effort validation of the generated TOML file."""
    try:
        import tomllib
    except ImportError:  # pragma: no cover — Py<3.11 fallback
        import tomli as tomllib  # type: ignore[import-untyped, no-redef]
    try:
        with open(cfg_path, "rb") as f:
            data = tomllib.load(f)
    except Exception as exc:
        click.echo(f"invalid config at {cfg_path}: {exc}", err=True)
        return False
    if "gateway" not in data or "storage" not in data:
        click.echo(
            f"config at {cfg_path} is missing [gateway] or [storage] section",
            err=True,
        )
        return False
    return True


def _load_storage_section(cfg_path: Path) -> dict[str, Any]:
    """Return the ``[storage]`` table from the config (or ``{}`` on failure)."""
    try:
        import tomllib
    except ImportError:  # pragma: no cover
        import tomli as tomllib  # type: ignore[import-untyped, no-redef]
    try:
        with open(cfg_path, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return {}
    storage = data.get("storage")
    return storage if isinstance(storage, dict) else {}


def _check_postgres(dsn: str) -> tuple[bool, str]:
    """Run ``SELECT 1`` against ``dsn`` with a short timeout.

    Best-effort — missing driver / unreachable host returns ``(False, msg)``
    so the CLI can warn rather than fail hard.
    """
    try:
        import psycopg  # type: ignore[import-not-found]
    except Exception:
        try:
            import psycopg2 as psycopg  # type: ignore[import-not-found, no-redef]
        except Exception:
            return False, "psycopg driver not installed"
    try:
        conn = psycopg.connect(dsn, connect_timeout=int(_CHECK_TIMEOUT_S))
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1")
            cur.fetchone()
        finally:
            conn.close()
    except Exception as exc:
        return False, f"connection failed: {exc}"
    return True, "ok"


def _check_clickhouse(dsn: str) -> tuple[bool, str]:
    try:
        import clickhouse_connect  # type: ignore[import-not-found]
    except Exception:
        return False, "clickhouse_connect not installed"
    try:
        # Parse minimal host/port from the DSN; support both
        # ``clickhouse://host:port`` and plain ``host:port`` forms.
        from urllib.parse import urlsplit
        parts = urlsplit(dsn if "://" in dsn else f"clickhouse://{dsn}")
        client = clickhouse_connect.get_client(
            host=parts.hostname or "localhost",
            port=parts.port or 8123,
            username=parts.username or "default",
            password=parts.password or "",
            connect_timeout=int(_CHECK_TIMEOUT_S),
        )
        client.query("SELECT 1")
    except Exception as exc:
        return False, f"connection failed: {exc}"
    return True, "ok"


def _check_otel() -> tuple[bool, str]:
    """OTel mode passes if either the OTLP endpoint OR test mode is set.
    We don't HEAD the collector here because gRPC HEAD is not a thing and
    HTTP HEAD has uneven support — operators can `curl` the endpoint."""
    endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or os.environ.get(
        "COREIQ_OTEL_ENDPOINT"
    )
    if endpoint:
        return True, f"OTEL_EXPORTER_OTLP_ENDPOINT={endpoint}"
    if os.environ.get("COREIQ_OTEL_TEST_MODE", "").strip() in ("1", "true", "yes"):
        return True, "COREIQ_OTEL_TEST_MODE=1 (in-memory exporters)"
    return (
        False,
        "set OTEL_EXPORTER_OTLP_ENDPOINT (e.g. http://localhost:4318) "
        "or COREIQ_OTEL_TEST_MODE=1 for local dev",
    )


def _check_mongodb(uri: str) -> tuple[bool, str]:
    try:
        from pymongo import MongoClient  # type: ignore[import-not-found]
    except Exception:
        return False, "pymongo not installed"
    try:
        client = MongoClient(uri, serverSelectionTimeoutMS=int(_CHECK_TIMEOUT_S * 1000))
        client.admin.command("ping")
    except Exception as exc:
        return False, f"connection failed: {exc}"
    return True, "ok"


def _run_connectivity_check(cfg_path: Path) -> None:
    """Probe the configured backend; print a one-line result.

    Never raises and never aborts ``coreiq up --check`` — we only warn so
    operators can run the smoke check before they've finished wiring secrets.
    """
    storage = _load_storage_section(cfg_path)
    backend = (storage.get("backend") or "mongodb").strip().lower()

    ok = False
    detail = ""
    if backend == "mongodb":
        uri = (
            os.environ.get("COREIQ_MONGODB_URI")
            or storage.get("uri")
            or "mongodb://localhost:27017"
        )
        ok, detail = _check_mongodb(uri)
    elif backend == "postgres":
        dsn = os.environ.get("COREIQ_POSTGRES_DSN") or storage.get("dsn") or ""
        if not dsn:
            click.echo(
                "connectivity check: postgres backend configured but "
                "COREIQ_POSTGRES_DSN is not set — skipping (warn)"
            )
            return
        ok, detail = _check_postgres(dsn)
    elif backend == "clickhouse":
        dsn = (
            os.environ.get("COREIQ_CLICKHOUSE_DSN")
            or storage.get("dsn")
            or "localhost:8123"
        )
        ok, detail = _check_clickhouse(dsn)
    elif backend == "otel":
        ok, detail = _check_otel()
    else:
        click.echo(
            f"connectivity check: unknown backend '{backend}' — skipping (warn)"
        )
        return

    label = "ok" if ok else "warn"
    click.echo(f"connectivity check ({backend}): {label} — {detail}")


def up(check: bool = False) -> None:
    """Bootstrap CoreIQ. If no config exists, run ``init --defaults``.

    With ``--check`` we validate the config and run a best-effort
    connectivity probe against the configured storage backend (postgres /
    clickhouse / otel), then exit without starting the server. Useful for
    tests, CI smoke checks, and pre-deploy gates.
    """
    cfg_path = Path.cwd() / _CONFIG_PATH

    if not cfg_path.exists():
        click.echo("no config found, running `coreiq init --defaults`...")
        from coreiq.cli.init import init as _init

        _init(defaults=True, force=False)

    if not _validate_config(cfg_path):
        sys.exit(1)

    if check:
        click.echo(f"config OK: {cfg_path}")
        _run_connectivity_check(cfg_path)
        return

    from coreiq.server.app import start

    start()


if __name__ == "__main__":  # pragma: no cover
    up()
