"""CLI: ``coreiq logout`` — remove cached SSO credentials.

Deletes ``~/.coreiq/credentials`` after a confirmation prompt (skip with
``--yes``). Exits 0 even when no credentials are present so the command is
idempotent in CI.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import click


def _credentials_path() -> Path:
    return Path(os.path.expanduser("~/.coreiq/credentials"))


def logout(yes: bool = False) -> int:
    """Delete the cached credentials. Return shell exit code."""
    path = _credentials_path()
    if not path.is_file():
        click.echo("Already logged out (no credentials file).")
        return 0

    server = "(unknown)"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        server = data.get("server") or server
    except (OSError, ValueError):
        pass

    if not yes:
        confirmed = click.confirm(
            f"Delete cached credentials at {path}?", default=False
        )
        if not confirmed:
            click.echo("Aborted.")
            return 1

    try:
        path.unlink()
    except OSError as exc:
        click.echo(f"error: failed to delete {path}: {exc}", err=True)
        return 1

    click.echo(f"Logged out from {server}")
    return 0
