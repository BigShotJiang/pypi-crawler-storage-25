"""CLI: ``coreiq whoami`` — print info about the cached SSO credentials.

Reads ``~/.coreiq/credentials`` (written by ``coreiq login``) and prints the
subject, server URL, key prefix, and time-to-expiry. Exits 1 when no
credentials are present so shell scripts can branch on it.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click


def _credentials_path() -> Path:
    return Path(os.path.expanduser("~/.coreiq/credentials"))


def _parse_expires(value: object) -> Optional[datetime]:
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(float(value), tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        try:
            return datetime.fromtimestamp(float(s), tz=timezone.utc)
        except ValueError:
            pass
        try:
            return datetime.fromisoformat(s.replace("Z", "+00:00"))
        except ValueError:
            return None
    return None


def _format_delta(delta_seconds: float) -> str:
    if delta_seconds < 0:
        return "expired"
    if delta_seconds < 60:
        return f"{int(delta_seconds)}s"
    if delta_seconds < 3600:
        return f"{int(delta_seconds // 60)}m"
    if delta_seconds < 86400:
        return f"{int(delta_seconds // 3600)}h"
    return f"{int(delta_seconds // 86400)}d"


def whoami() -> int:
    """Print credential info; return shell exit code."""
    path = _credentials_path()
    if not path.is_file():
        click.echo("Not logged in. Run 'coreiq login' to authenticate.", err=True)
        return 1
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        click.echo(f"error: failed to read credentials at {path}: {exc}", err=True)
        return 1

    subject = data.get("subject") or "(unknown)"
    server = data.get("server") or "(unknown)"
    key = data.get("key") or ""
    key_prefix = (key[:8] + "...") if key else "(none)"

    expires_at_raw = data.get("expires_at")
    expires_at = _parse_expires(expires_at_raw)
    if expires_at is None:
        expires_str = "(unknown)"
        ttl_str = "(unknown)"
    else:
        expires_str = expires_at.isoformat()
        delta = (expires_at - datetime.now(timezone.utc)).total_seconds()
        ttl_str = _format_delta(delta)

    click.echo(f"Subject:    {subject}")
    click.echo(f"Server:     {server}")
    click.echo(f"Key:        {key_prefix}")
    click.echo(f"Expires at: {expires_str}")
    click.echo(f"TTL:        {ttl_str}")
    return 0
