"""Bundle loaders — file (JSON/YAML), dict, and DB.

Load order at startup:
  1. If COREIQ_POLICY_FILE is set → file loader (canonical source).
  2. Else → DB loader (`policy_bundles` table, status=active).
  3. Else → engine starts with no bundle (default-allow).

When a file is configured, the API endpoint locks writes and returns 409.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

from .bundle import Bundle, BundleSignatureError


class BundleValidationError(Exception):
    """Raised when a file-loaded bundle fails structural / 4-eyes checks."""

logger = logging.getLogger("coreiq.policy.loader")


def _is_production() -> bool:
    """Return True when COREIQ_ENV indicates a production deployment."""
    return os.environ.get("COREIQ_ENV", "").lower() == "production"


def _signing_configured() -> bool:
    """True if any policy signing scheme (HMAC or Ed25519) is configured."""
    if os.environ.get("COREIQ_POLICY_SIGNING_KEY"):
        return True
    if (
        os.environ.get("COREIQ_POLICY_SIGNING_ALG", "").lower() == "ed25519"
        and os.environ.get("COREIQ_POLICY_PUBLIC_KEY")
    ):
        return True
    return False


def _enforce_file_signature(data: Dict[str, Any], bundle: Bundle) -> None:
    """Enforce the signature contract on a file-loaded bundle.

    Wave 2B P1: in production, an unsigned bundle is *always* rejected,
    even when no signing key is configured — operators must wire one
    up. Outside production we keep the existing dev-friendly behavior:
    signing is optional unless a key is configured.

    Behavior matrix:
      - ``COREIQ_ENV=production`` and signature missing → BundleSignatureError.
      - ``COREIQ_ENV=production`` and no signing key/alg configured →
        BundleSignatureError (refuse to load — fail loudly so deployments
        cannot accidentally trust unsigned policy in production).
      - Non-production + no signing key configured → accept unsigned.
      - Signing configured + signature missing → BundleSignatureError.
      - Signing configured + signature present but invalid → BundleSignatureError.
    """
    signature = data.get("signature") or ""
    in_prod = _is_production()
    key_configured = _signing_configured()

    if in_prod:
        if not key_configured:
            raise BundleSignatureError(
                "production refuses to load policy bundles without a signing key. "
                "Set COREIQ_POLICY_SIGNING_KEY (HMAC) or "
                "COREIQ_POLICY_SIGNING_ALG=ed25519 + COREIQ_POLICY_PUBLIC_KEY."
            )
        if not signature:
            raise BundleSignatureError(
                "production refuses to load an unsigned policy bundle. "
                "Sign the bundle (or supply a sidecar .sig) before deploying."
            )
        if not bundle.verify(str(signature)):
            raise BundleSignatureError(
                f"Bundle {bundle.bundle_id} failed signature verification"
            )
        return

    # Non-production: legacy behavior — signing is optional.
    if not key_configured:
        return
    if not signature:
        raise BundleSignatureError(
            "file has no signature but signing key is configured"
        )
    if not bundle.verify(str(signature)):
        raise BundleSignatureError(
            f"Bundle {bundle.bundle_id} failed signature verification"
        )


def load_bundle_from_dict(data: Dict[str, Any]) -> Bundle:
    """Parse a bundle dict. A top-level ``signature`` field, if present, is
    stripped before construction. Signature *enforcement* happens only on
    the file-load path (see ``load_bundle_from_file``) and the DB-load path
    (see ``load_active_bundle``); API submissions use this function and are
    signed at activation time, not at parse time."""
    if "signature" in data:
        data = {k: v for k, v in data.items() if k != "signature"}
    return Bundle.from_dict(data)


def load_bundle_from_file(path: str | Path) -> Bundle:
    """Load a bundle from a JSON or YAML file. YAML is optional.

    Verifies the bundle's HMAC signature when ``COREIQ_POLICY_SIGNING_KEY``
    is configured. The signature may be embedded as a top-level ``signature``
    field in the file, or supplied via a sibling ``<file>.sig`` sidecar.
    Raises ``BundleSignatureError`` when a signing key is configured but no
    valid signature is found — GitOps customers get tamper detection.
    """
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    suffix = p.suffix.lower()
    if suffix in (".yaml", ".yml"):
        try:
            import yaml   # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "PyYAML is required to load .yaml policy files. "
                "Install with `pip install pyyaml` or use a .json file."
            ) from exc
        data = yaml.safe_load(text) or {}
    else:
        data = json.loads(text) if text.strip() else {}

    # Sidecar signature (only consulted if the file itself has no signature).
    if "signature" not in data:
        sidecar = p.with_suffix(p.suffix + ".sig")
        if sidecar.exists():
            data["signature"] = sidecar.read_text(encoding="utf-8").strip()

    bundle = load_bundle_from_dict(data)
    _enforce_file_signature(data, bundle)
    _enforce_file_four_eyes(bundle)
    return bundle


def _enforce_file_four_eyes(bundle: Bundle) -> None:
    """Wave 3A: enforce-mode + residency bundles loaded from a file must
    carry at least 2 distinct approvers, mirroring the API approval gate.

    GitOps customers commit policy bundles to disk — the API 4-eyes check
    never fires for them. Without this guard a single rogue admin could
    push an enforce+residency bundle to ``COREIQ_POLICY_FILE`` and bypass
    the dual-control requirement entirely.
    """
    if bundle.mode != "enforce":
        return
    if bundle.residency in ("any", None):
        return
    distinct = {a for a in (bundle.approved_by or []) if a}
    if len(distinct) >= 2:
        return
    raise BundleValidationError(
        f"file-loaded enforce+residency bundle requires >=2 distinct approvers; "
        f"got {sorted(distinct) or 'none'}. Add approver entries to the bundle "
        f"(approved_by) before deploying via COREIQ_POLICY_FILE."
    )


def load_active_bundle(tenant_id: str = "default") -> Optional[Bundle]:
    """Load the currently active bundle for *tenant_id* from the DB.

    Returns None if no active bundle exists (or DB unavailable).
    """
    try:
        from ..store.db import get_shared_connection
        conn = get_shared_connection()
        row = conn.execute(
            """SELECT content_json, content_sha256, signature
                 FROM policy_bundles
                WHERE tenant_id=? AND status='active'
                ORDER BY version DESC LIMIT 1""",
            (tenant_id,),
        ).fetchone()
        if not row:
            return None
        content = json.loads(row["content_json"]) if row["content_json"] else {}
        bundle = Bundle.from_dict(content)
        sig = row["signature"] or ""
        # Wave 2B P1: production refuses unsigned DB bundles, regardless
        # of whether a signing key is configured. Mirrors the file-load
        # path so the two installation channels share one contract.
        if _is_production():
            if not _signing_configured():
                raise BundleSignatureError(
                    "production refuses to load policy bundles without a signing key. "
                    "Configure COREIQ_POLICY_SIGNING_KEY or COREIQ_POLICY_SIGNING_ALG=ed25519."
                )
            if not sig:
                raise BundleSignatureError(
                    f"production refuses to load unsigned bundle {bundle.bundle_id} "
                    f"for tenant {tenant_id}"
                )
        if not bundle.verify(sig):
            raise BundleSignatureError(
                f"Bundle {bundle.bundle_id} for tenant {tenant_id} failed signature verification"
            )
        return bundle
    except BundleSignatureError:
        raise
    except Exception as exc:
        logger.debug("load_active_bundle failed (non-fatal): %s", exc)
        return None


def load_initial_bundle() -> Optional[Bundle]:
    """Load the bundle to install at engine startup.

    Resolution order:
      1. COREIQ_POLICY_FILE → file loader
      2. DB active bundle for tenant 'default'
      3. None
    """
    path = os.environ.get("COREIQ_POLICY_FILE")
    if path:
        try:
            return load_bundle_from_file(path)
        except Exception as exc:
            logger.error("Failed to load COREIQ_POLICY_FILE=%s: %s", path, exc)
            return None
    return load_active_bundle("default")


def is_file_locked() -> bool:
    """Return True when COREIQ_POLICY_FILE is set — API writes must be rejected."""
    return bool(os.environ.get("COREIQ_POLICY_FILE"))
