"""Policy evaluators — one per concern.

Each evaluator exposes evaluate_pre(bundle, ctx, decision) and (optionally)
evaluate_post(bundle, ctx, decision). They mutate the Decision in place by
appending EvaluatedRule entries and setting decision.action / decision.reason
when they fire a terminal action.
"""
