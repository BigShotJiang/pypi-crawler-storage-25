"""Guardrails evaluator — input redact/block, output regex.

Input rules can detect: pii, injection, secret, regex.
Output rules support: regex.
Actions: redact (input only), warn, block.

In v1, input pii/injection detection delegates to coreiq.security.scanner
when available, but degrades gracefully if those modules don't import.
"""
from __future__ import annotations

import re
import logging
from typing import TYPE_CHECKING, Any, Dict, List, Tuple

from ..bundle import Bundle
from ..decision import Decision, DecisionAction, EvaluatedRule
from . import classification as ev_classification

if TYPE_CHECKING:
    from ..engine import RequestContext

logger = logging.getLogger("coreiq.policy.evaluators.guardrails")


def _scan_input(messages: List[Dict[str, Any]], kinds: Tuple[str, ...]) -> Dict[str, Any]:
    """Run the security scanner; returns dict with `pii`, `injection`, `redacted_messages`.

    Fail-soft: if scanner unavailable, returns no detections.
    """
    out: Dict[str, Any] = {"pii": False, "injection": False, "redacted_messages": messages}
    try:
        from ...security.scanner import scan_and_redact
        result = scan_and_redact(messages)
        # The scanner returns various shapes across versions; accept dict or object
        if isinstance(result, dict):
            out["pii"] = bool(result.get("pii_detected") or result.get("pii"))  # type: ignore[unreachable]
            out["injection"] = bool(result.get("injection_detected") or result.get("injection"))
            out["redacted_messages"] = result.get("messages") or messages
        else:
            out["pii"] = bool(getattr(result, "pii_detected", False))
            out["injection"] = bool(getattr(result, "injection_detected", False))
            out["redacted_messages"] = getattr(result, "messages", messages)
    except Exception as exc:
        logger.debug("scanner unavailable; degraded guardrail (%s)", exc)
    return out


def evaluate_pre(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    rules = (bundle.guardrails or {}).get("input") or []
    if not rules:
        decision.add(EvaluatedRule(
            rule_id="guardrails.input.empty", evaluator="guardrails.input",
            matched=False, skipped_reason="no input guardrails configured",
        ))
        return

    # Single scan pass shared across rules
    needed: Tuple[str, ...] = tuple(d for d in (r.get("detect") for r in rules) if isinstance(d, str))
    scan = _scan_input(ctx.messages, needed)
    ctx.pii_detected = ctx.pii_detected or scan["pii"]

    for rule in rules:
        rid = rule.get("id") or f"input:{rule.get('detect')}"
        detect = rule.get("detect")
        action = rule.get("action", "block")

        # Data-classification rule — handled by its own module (P1).
        if detect == "classification":
            terminal = ev_classification.evaluate_input_rule(rule, ctx, decision)
            if terminal:
                return
            continue

        fired = False
        detail = None
        if detect == "pii":
            fired = scan["pii"]
            detail = "pii detected" if fired else None
        elif detect == "injection":
            fired = scan["injection"]
            detail = "injection detected" if fired else None
        elif detect == "regex":
            pattern = rule.get("pattern", "")
            if pattern:
                blob = "\n".join(m.get("content", "") if isinstance(m, dict) else str(m) for m in ctx.messages)
                fired = bool(re.search(pattern, blob))
                detail = f"regex hit: {pattern}" if fired else None

        if not fired:
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.input", matched=False,
                skipped_reason=f"detect={detect} did not fire",
            ))
            continue

        if action == "block":
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.input", matched=True,
                action_taken=DecisionAction.DENY, detail=detail,
            ))
            decision.action = DecisionAction.DENY
            decision.reason = f"guardrails.input.{detect}"
            return
        elif action == "redact":
            ctx.messages = scan["redacted_messages"]
            decision.redactions.append({"rule_id": rid, "kind": detect})
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.input", matched=True,
                action_taken=DecisionAction.REDACT, detail=detail,
            ))
        else:  # warn
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.input", matched=True,
                action_taken="warn", detail=detail,
            ))


def evaluate_post(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    rules = (bundle.guardrails or {}).get("output") or []
    if not rules or not ctx.output_text:
        return
    for rule in rules:
        rid = rule.get("id") or "output:regex"
        detect = rule.get("detect")
        if detect != "regex":
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.output",
                matched=False, skipped_reason=f"unsupported detect={detect} in v1",
            ))
            continue
        pattern = rule.get("pattern", "")
        action = rule.get("action", "redact")
        if not pattern:
            continue
        m = re.search(pattern, ctx.output_text)
        if not m:
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.output", matched=False,
                skipped_reason="pattern did not match output",
            ))
            continue
        if action == "block":
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.output", matched=True,
                action_taken=DecisionAction.DENY, detail=f"output matched {pattern}",
            ))
            decision.action = DecisionAction.DENY
            decision.reason = f"guardrails.output.{rid}"
            return
        elif action == "redact":
            ctx.output_text = re.sub(pattern, "[REDACTED]", ctx.output_text)
            decision.redactions.append({"rule_id": rid, "kind": "regex"})
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="guardrails.output", matched=True,
                action_taken=DecisionAction.REDACT, detail=f"redacted {pattern}",
            ))
