"""Routing rules evaluator — first-match-wins, priority-ordered.

A rule is a dict:
  { id, priority, when: {<dotted-key>: <value>}, action: { route_to_deployment | block } }

`when` is a flat conjunction over dotted-path lookups into ctx + ctx.metadata:
  - `metadata.<k>`        → ctx.metadata[k]
  - `request.pii_detected` → ctx.pii_detected
  - `model`, `provider`   → ctx.model / ctx.provider

Only equality is supported in v1. Future: operators (>, <, in, regex).
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict

from ..bundle import Bundle
from ..decision import Decision, DecisionAction, EvaluatedRule

if TYPE_CHECKING:
    from ..engine import RequestContext


def _lookup(ctx: "RequestContext", key: str) -> Any:
    if key.startswith("metadata."):
        return ctx.metadata.get(key.split(".", 1)[1])
    if key == "request.pii_detected":
        return ctx.pii_detected
    return getattr(ctx, key, None)


def _matches(when: Dict[str, Any], ctx: "RequestContext") -> bool:
    if not when:
        return True
    for k, v in when.items():
        if _lookup(ctx, k) != v:
            return False
    return True


def evaluate_pre(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    rules = sorted(bundle.routing or [], key=lambda r: r.get("priority", 100))
    if not rules:
        decision.add(EvaluatedRule(
            rule_id="routing.empty", evaluator="routing",
            matched=False, skipped_reason="no routing rules configured",
        ))
        return

    for rule in rules:
        rid = rule.get("id", "routing.unknown")
        when = rule.get("when") or {}
        action = rule.get("action") or {}
        if not _matches(when, ctx):
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="routing", matched=False,
                skipped_reason=f"when={when} did not match",
            ))
            continue

        if "block" in action:
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="routing", matched=True,
                action_taken=DecisionAction.DENY, detail=str(action["block"]),
            ))
            decision.action = DecisionAction.DENY
            decision.reason = f"routing.block:{rid}"
            return

        if "route_to_deployment" in action:
            target = action["route_to_deployment"]
            decision.target_deployment = target
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="routing", matched=True,
                action_taken=DecisionAction.ROUTE,
                detail=f"route_to_deployment={target}",
            ))
            return  # first-match-wins
