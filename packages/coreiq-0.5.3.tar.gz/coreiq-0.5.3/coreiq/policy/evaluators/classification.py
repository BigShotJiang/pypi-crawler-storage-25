"""Data-classification guardrail evaluator (P1).

Used as a sub-detector inside the input guardrails block::

    guardrails:
      input:
        - detect: classification
          allowed: ["INTERNAL", "CONFIDENTIAL"]
          action: block

The classification is read from ``ctx.metadata['data_classification']``.
Comparison is case-insensitive. When the metadata field is missing the
rule is recorded as skipped (not as a deny) — callers that want to enforce
"must be tagged" should add a separate explicit rule.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..decision import Decision, DecisionAction, EvaluatedRule

if TYPE_CHECKING:
    from ..engine import RequestContext


def _read_classification(ctx: "RequestContext") -> Optional[str]:
    md = getattr(ctx, "metadata", None) or {}
    val = md.get("data_classification")
    if val is None:
        return None
    return str(val).strip()


def evaluate_input_rule(rule: Dict[str, Any], ctx: "RequestContext", decision: Decision) -> bool:
    """Evaluate one classification rule. Returns True if the rule is terminal
    (i.e. set decision.action), so the outer guardrails loop can stop.
    """
    rid = rule.get("id") or "input:classification"
    allowed: List[str] = [str(x).upper() for x in (rule.get("allowed") or [])]
    action = rule.get("action", "block")
    cls = _read_classification(ctx)

    if cls is None:
        decision.add(EvaluatedRule(
            rule_id=rid, evaluator="guardrails.input", matched=False,
            skipped_reason="no data_classification on metadata",
        ))
        return False

    if cls.upper() in allowed:
        decision.add(EvaluatedRule(
            rule_id=rid, evaluator="guardrails.input", matched=False,
            skipped_reason=f"classification={cls} permitted",
        ))
        return False

    if action == "block":
        decision.add(EvaluatedRule(
            rule_id=rid, evaluator="guardrails.input", matched=True,
            action_taken=DecisionAction.DENY,
            detail=f"classification={cls} not in allow-list",
        ))
        decision.action = DecisionAction.DENY
        decision.reason = "guardrails.input.classification"
        return True

    # warn / observe
    decision.add(EvaluatedRule(
        rule_id=rid, evaluator="guardrails.input", matched=True,
        action_taken="warn",
        detail=f"classification={cls} not in allow-list",
    ))
    return False
