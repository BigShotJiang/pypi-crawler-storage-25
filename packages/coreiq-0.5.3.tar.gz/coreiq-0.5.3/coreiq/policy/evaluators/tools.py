"""Tool-call governance evaluator (P1).

Bundle schema::

    tools:
      allow: ["search_*", "calculator"]   # fnmatch patterns
      deny:  ["exec_*", "shell"]

Behaviour:
    * Inspects the requested tools on the RequestContext. Source preference:
      ``ctx.tools`` (a list of dicts with a ``name`` key, OpenAI tool-calling
      shape) → ``ctx.metadata['tools']`` fallback.
    * ``deny`` always wins. If a tool matches any deny pattern, the request
      is denied immediately.
    * When ``allow`` is set (non-empty), it is **default-deny**: every
      requested tool must match at least one allow pattern.
    * When ``allow`` is empty AND ``deny`` is empty, the evaluator is a
      no-op (records a skipped EvaluatedRule for audit-trail completeness).
"""
from __future__ import annotations

import fnmatch
from typing import TYPE_CHECKING, Any, Iterable, List

from ..bundle import Bundle
from ..decision import Decision, DecisionAction, EvaluatedRule

if TYPE_CHECKING:
    from ..engine import RequestContext


def _extract_tool_names(ctx: "RequestContext") -> List[str]:
    """Pull tool names off the context, accepting either ctx.tools or metadata."""
    raw = getattr(ctx, "tools", None)
    if not raw:
        raw = (ctx.metadata or {}).get("tools") if getattr(ctx, "metadata", None) else None
    if not raw:
        return []
    names: List[str] = []
    for entry in raw:
        if isinstance(entry, dict):
            # OpenAI-style: {"type": "function", "function": {"name": "..."}}
            fn = entry.get("function") if isinstance(entry.get("function"), dict) else None
            name = (fn or entry).get("name") if (fn or entry) else None
            if isinstance(name, str) and name:
                names.append(name)
        elif isinstance(entry, str):
            names.append(entry)
    return names


def _match_any(name: str, patterns: Iterable[str]) -> bool:
    return any(fnmatch.fnmatchcase(name, p) for p in patterns)


def evaluate_pre(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    cfg: Any = getattr(bundle, "tools", None)
    # Bundle.from_dict may not have populated this — tolerate absence/dict.
    if cfg is None:
        cfg = (bundle.to_dict().get("tools") if hasattr(bundle, "to_dict") else None) or {}
    allow = list((cfg or {}).get("allow") or [])
    deny = list((cfg or {}).get("deny") or [])
    requested = _extract_tool_names(ctx)

    if not allow and not deny:
        decision.add(EvaluatedRule(
            rule_id="tools.empty", evaluator="tools",
            matched=False, skipped_reason="no tool policy configured",
        ))
        return

    if not requested:
        decision.add(EvaluatedRule(
            rule_id="tools.no_tools_requested", evaluator="tools",
            matched=False, skipped_reason="no tools requested in this call",
        ))
        return

    # Deny wins.
    for name in requested:
        if deny and _match_any(name, deny):
            decision.add(EvaluatedRule(
                rule_id=f"tools.deny:{name}", evaluator="tools",
                matched=True, action_taken=DecisionAction.DENY,
                detail=f"tool '{name}' matched deny pattern",
            ))
            decision.action = DecisionAction.DENY
            decision.reason = "tools.deny"
            return

    # Allow-list = default-deny semantics.
    if allow:
        for name in requested:
            if not _match_any(name, allow):
                decision.add(EvaluatedRule(
                    rule_id=f"tools.not_allowed:{name}", evaluator="tools",
                    matched=True, action_taken=DecisionAction.DENY,
                    detail=f"tool '{name}' not in allow-list",
                ))
                decision.action = DecisionAction.DENY
                decision.reason = "tools.not_allowed"
                return

    decision.add(EvaluatedRule(
        rule_id="tools.ok", evaluator="tools",
        matched=False, skipped_reason="all requested tools permitted",
    ))
