"""Sovereignty egress evaluator — default-deny upstream allowlist.

A request must match an entry in bundle.allowed_egress AND not match
anything in bundle.denied_egress. Entries can specify:
  - deployment_id: exact match against ctx.target_deployment_id
  - host_pattern:  fnmatch glob against ctx.target_host
                   (also accepted as the alias ``host`` — a literal hostname,
                   matched as an fnmatch pattern; bare hostnames have no
                   glob metacharacters so the match is exact)
  - residency:     optional tag joined later by engine

If allowed_egress is empty, this is a no-op (only deny rules apply). This
lets dev installs run without an egress allowlist; sovereign tenants set
mode=enforce + allowed_egress to get default-deny behaviour.
"""
from __future__ import annotations

import fnmatch
from typing import TYPE_CHECKING, Any, Dict

from ..bundle import Bundle
from ..decision import Decision, DecisionAction, EvaluatedRule

if TYPE_CHECKING:
    from ..engine import RequestContext


def _matches(entry: Dict[str, Any], ctx: "RequestContext") -> bool:
    if "deployment_id" in entry and entry["deployment_id"]:
        if entry["deployment_id"] == ctx.target_deployment_id:
            return True
    # ``host`` is accepted as an alias for ``host_pattern`` so bundle authors
    # writing literal hostnames (the common case) are not silently ignored.
    pattern = entry.get("host_pattern") or entry.get("host")
    if pattern:
        host = ctx.target_host or ""
        if fnmatch.fnmatch(host, pattern):
            return True
    return False


def evaluate_pre(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    # Denied egress always fires first
    for entry in bundle.denied_egress:
        rid = entry.get("id") or f"denied:{entry.get('host_pattern') or entry.get('host') or entry.get('deployment_id') or '?'}"
        if _matches(entry, ctx):
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="egress", matched=True,
                action_taken=DecisionAction.DENY,
                detail=f"matched denied_egress entry {entry}",
            ))
            decision.action = DecisionAction.DENY
            decision.reason = "sovereignty.egress.denied"
            return
        decision.add(EvaluatedRule(
            rule_id=rid, evaluator="egress", matched=False,
            skipped_reason="no host/deployment match",
        ))

    # If no allowed_egress configured, skip the allowlist gate
    if not bundle.allowed_egress:
        decision.add(EvaluatedRule(
            rule_id="egress.allowlist", evaluator="egress", matched=False,
            skipped_reason="allowed_egress is empty (allowlist gate disabled)",
        ))
        return

    matched_any = False
    for entry in bundle.allowed_egress:
        rid = entry.get("id") or f"allowed:{entry.get('host_pattern') or entry.get('host') or entry.get('deployment_id') or '?'}"
        if _matches(entry, ctx):
            matched_any = True
            # Carry residency hint forward if the matching entry tagged one
            if entry.get("residency") and not ctx.target_residency:
                ctx.target_residency = entry["residency"]
            decision.add(EvaluatedRule(
                rule_id=rid, evaluator="egress", matched=True,
                action_taken=DecisionAction.ALLOW,
                detail=f"matched allowed_egress entry {entry}",
            ))
            break
        decision.add(EvaluatedRule(
            rule_id=rid, evaluator="egress", matched=False,
            skipped_reason="no host/deployment match",
        ))

    if not matched_any:
        decision.add(EvaluatedRule(
            rule_id="egress.default_deny", evaluator="egress", matched=True,
            action_taken=DecisionAction.DENY,
            detail=f"no allowed_egress entry matched host={ctx.target_host} deployment={ctx.target_deployment_id}",
        ))
        decision.action = DecisionAction.DENY
        decision.reason = "sovereignty.egress.default_deny"
