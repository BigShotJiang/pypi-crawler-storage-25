"""Limits evaluator — pre-call (input tokens, cumulative budget) and
post-call (output tokens, per-request cost).

P1 additions:
    * Cumulative budget pre-evaluator. Bundle::

          limits:
            max_cost_usd_per_day:   100.0
            max_cost_usd_per_month: 2500.0
            budget_scope: tenant     # or "principal"

      Spend is aggregated from ``policy_decisions`` over the rolling window
      keyed on ``tenant_id`` (and ``principal`` when scope=principal).
      Aggregates are cached process-locally for 30 s to avoid hammering the
      DB. On DB error the evaluator fails *open* (records a skipped rule);
      we never want a degraded store to silently drop traffic.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

from ..bundle import Bundle
from ..decision import Decision, DecisionAction, EvaluatedRule

if TYPE_CHECKING:
    from ..engine import RequestContext

logger = logging.getLogger("coreiq.policy.evaluators.limits")

# Process-local 30s cache: {(tenant_id, principal_or_None, window): (expiry_ts, spend_usd)}
_BUDGET_CACHE: Dict[Tuple[str, Optional[str], str], Tuple[float, float]] = {}
_BUDGET_CACHE_LOCK = threading.Lock()
_BUDGET_CACHE_TTL_S = 30.0


def _cache_get(key: Tuple[str, Optional[str], str]) -> Optional[float]:
    with _BUDGET_CACHE_LOCK:
        entry = _BUDGET_CACHE.get(key)
        if entry is None:
            return None
        expiry, spend = entry
        if expiry < time.monotonic():
            _BUDGET_CACHE.pop(key, None)
            return None
        return spend


def _cache_put(key: Tuple[str, Optional[str], str], spend: float) -> None:
    with _BUDGET_CACHE_LOCK:
        _BUDGET_CACHE[key] = (time.monotonic() + _BUDGET_CACHE_TTL_S, spend)


def _clear_budget_cache() -> None:
    """Test hook — drop cached aggregates."""
    with _BUDGET_CACHE_LOCK:
        _BUDGET_CACHE.clear()


def _aggregate_spend(
    tenant_id: str, principal: Optional[str], since_iso: str,
) -> float:
    """Sum cost_usd across policy_decisions for the rolling window.

    The decisions table doesn't carry cost as a native column — it is
    embedded in evaluated_rules / metadata. To avoid a schema migration
    we query traces (the canonical cost ledger) joined by trace_id when
    available, falling back to 0.0 on any error.
    """
    try:
        from ...store.db import get_shared_connection
        conn = get_shared_connection()
        if principal:
            q = (
                "SELECT COALESCE(SUM(t.cost_usd), 0) AS total "
                "FROM policy_decisions d "
                "LEFT JOIN traces t ON t.id = d.trace_id "
                "WHERE d.tenant_id=? AND d.principal=? AND d.ts >= ?"
            )
            params: tuple = (tenant_id, principal, since_iso)
        else:
            q = (
                "SELECT COALESCE(SUM(t.cost_usd), 0) AS total "
                "FROM policy_decisions d "
                "LEFT JOIN traces t ON t.id = d.trace_id "
                "WHERE d.tenant_id=? AND d.ts >= ?"
            )
            params = (tenant_id, since_iso)
        row = conn.execute(q, params).fetchone()
        if not row:
            return 0.0
        try:
            return float(row["total"] or 0.0)
        except Exception:
            # tuple-style row from some backends
            return float(row[0] or 0.0)
    except Exception as exc:
        logger.debug("budget aggregate failed (fail-open): %s", exc)
        return 0.0


def _window_start(now: datetime, window: str) -> datetime:
    if window == "day":
        return now - timedelta(days=1)
    if window == "month":
        return now - timedelta(days=30)
    raise ValueError(f"unknown window {window}")


def _eval_budget(
    bundle_limits: Dict[str, Any], ctx: "RequestContext", decision: Decision,
) -> bool:
    """Run cumulative-budget caps. Returns True if a deny was emitted."""
    day_cap = bundle_limits.get("max_cost_usd_per_day")
    month_cap = bundle_limits.get("max_cost_usd_per_month")
    if not day_cap and not month_cap:
        return False

    scope = (bundle_limits.get("budget_scope") or "tenant").lower()
    tenant_id = ctx.tenant_id or "default"
    principal = ctx.principal if scope == "principal" else None

    now = datetime.now(timezone.utc)

    for window, cap in (("day", day_cap), ("month", month_cap)):
        if not cap:
            continue
        key = (tenant_id, principal, window)
        spend = _cache_get(key)
        if spend is None:
            since_iso = _window_start(now, window).isoformat()
            spend = _aggregate_spend(tenant_id, principal, since_iso)
            _cache_put(key, spend)

        if spend >= float(cap):
            decision.add(EvaluatedRule(
                rule_id=f"limits.budget.{window}", evaluator="limits",
                matched=True, action_taken=DecisionAction.DENY,
                detail=f"spend ${spend:.4f} >= cap ${float(cap):.4f} (scope={scope})",
            ))
            decision.action = DecisionAction.DENY
            decision.reason = f"limits.budget.{window}"
            return True
        else:
            decision.add(EvaluatedRule(
                rule_id=f"limits.budget.{window}", evaluator="limits",
                matched=False,
                skipped_reason=f"spend ${spend:.4f} under cap ${float(cap):.4f}",
            ))
    return False


def evaluate_pre(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    limits = bundle.limits or {}
    cap = limits.get("max_input_tokens")
    if cap and ctx.input_tokens is not None and ctx.input_tokens > cap:
        decision.add(EvaluatedRule(
            rule_id="limits.max_input_tokens", evaluator="limits",
            matched=True, action_taken=DecisionAction.DENY,
            detail=f"{ctx.input_tokens} > {cap}",
        ))
        decision.action = DecisionAction.DENY
        decision.reason = "limits.input_tokens"
        return
    decision.add(EvaluatedRule(
        rule_id="limits.max_input_tokens", evaluator="limits", matched=False,
        skipped_reason="under cap or unset",
    ))

    # Cumulative budget caps.
    _eval_budget(limits, ctx, decision)


def evaluate_post(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    limits = bundle.limits or {}
    out_cap = limits.get("max_output_tokens")
    if out_cap and ctx.output_tokens is not None and ctx.output_tokens > out_cap:
        decision.add(EvaluatedRule(
            rule_id="limits.max_output_tokens", evaluator="limits",
            matched=True, action_taken=DecisionAction.DENY,
            detail=f"{ctx.output_tokens} > {out_cap}",
        ))
        decision.action = DecisionAction.DENY
        decision.reason = "limits.output_tokens"
        return

    cost_cap = limits.get("max_cost_usd_per_request")
    if cost_cap and ctx.cost_usd is not None and ctx.cost_usd > cost_cap:
        decision.add(EvaluatedRule(
            rule_id="limits.max_cost_usd_per_request", evaluator="limits",
            matched=True, action_taken=DecisionAction.DENY,
            detail=f"${ctx.cost_usd:.4f} > ${cost_cap:.4f}",
        ))
        decision.action = DecisionAction.DENY
        decision.reason = "limits.cost"


# Re-export json so tests/extensions can monkeypatch easily.
__all__ = ["evaluate_pre", "evaluate_post", "_clear_budget_cache", "json"]
