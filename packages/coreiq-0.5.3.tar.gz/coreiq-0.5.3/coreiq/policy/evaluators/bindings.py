"""Bindings overlay — apply group/role overrides to produce an effective Bundle.

Each binding looks like:
    {"groups": ["finance"], "overrides": {"limits.max_cost_usd_per_request": 1.0}}

If any of ctx.groups intersects a binding's groups, its overrides are
applied (last-write-wins). Overrides use dotted paths into bundle fields.
The result is a *shallow-copied* Bundle — original is never mutated.
"""
from __future__ import annotations

import copy
from typing import TYPE_CHECKING, Any, Dict, List, Tuple

from ..bundle import Bundle
from ..decision import Decision, EvaluatedRule

if TYPE_CHECKING:
    from ..engine import RequestContext


def _apply_dotted(target: Dict[str, Any], dotted: str, value: Any) -> None:
    parts = dotted.split(".")
    cur = target
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p], dict):
            cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = value


def apply(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> Bundle:
    if not bundle.bindings:
        decision.add(EvaluatedRule(
            rule_id="bindings.empty", evaluator="bindings",
            matched=False, skipped_reason="no bindings configured",
        ))
        return bundle

    user_groups = set(ctx.groups or [])
    overrides_to_apply: List[Tuple[str, Dict[str, Any]]] = []
    for b in bundle.bindings:
        bid = b.get("id") or f"bind:{','.join(b.get('groups') or [])}"
        bgroups = set(b.get("groups") or [])
        if user_groups & bgroups:
            overrides_to_apply.append((bid, b.get("overrides") or {}))
            decision.add(EvaluatedRule(
                rule_id=bid, evaluator="bindings", matched=True,
                action_taken="overlay",
                detail=f"groups={sorted(bgroups & user_groups)}",
            ))
        else:
            decision.add(EvaluatedRule(
                rule_id=bid, evaluator="bindings", matched=False,
                skipped_reason="no group intersection",
            ))

    if not overrides_to_apply:
        return bundle

    # Build an effective bundle by deep-copying and applying overrides
    eff_dict = copy.deepcopy(bundle.to_dict())
    for _, overrides in overrides_to_apply:
        for dotted, value in overrides.items():
            _apply_dotted(eff_dict, dotted, value)
    eff = Bundle.from_dict(eff_dict)
    # Preserve the original bundle_id on the decision — overrides don't change identity
    eff.bundle_id = bundle.bundle_id
    return eff
