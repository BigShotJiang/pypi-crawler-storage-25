"""Model allow/deny evaluator — supports glob patterns."""
from __future__ import annotations

import fnmatch
from typing import TYPE_CHECKING

from ..bundle import Bundle
from ..decision import Decision, DecisionAction, EvaluatedRule

if TYPE_CHECKING:
    from ..engine import RequestContext


def evaluate_pre(bundle: Bundle, ctx: "RequestContext", decision: Decision) -> None:
    model = ctx.model or ""
    deny = bundle.models.get("deny") or []
    allow = bundle.models.get("allow") or []

    for pat in deny:
        if fnmatch.fnmatch(model, pat):
            decision.add(EvaluatedRule(
                rule_id=f"model.deny:{pat}", evaluator="models",
                matched=True, action_taken=DecisionAction.DENY,
                detail=f"model '{model}' matched deny pattern '{pat}'",
            ))
            decision.action = DecisionAction.DENY
            decision.reason = "models.denied"
            return

    if allow:
        for pat in allow:
            if fnmatch.fnmatch(model, pat):
                decision.add(EvaluatedRule(
                    rule_id=f"model.allow:{pat}", evaluator="models",
                    matched=True, action_taken=DecisionAction.ALLOW,
                    detail=f"model '{model}' matched allow pattern '{pat}'",
                ))
                return
        decision.add(EvaluatedRule(
            rule_id="model.allowlist", evaluator="models", matched=True,
            action_taken=DecisionAction.DENY,
            detail=f"model '{model}' not on allowlist {allow}",
        ))
        decision.action = DecisionAction.DENY
        decision.reason = "models.not_allowed"
    else:
        decision.add(EvaluatedRule(
            rule_id="model.allowlist", evaluator="models", matched=False,
            skipped_reason="models.allow is empty (allowlist disabled)",
        ))
