"""Policy Bundle — the single declarative policy document.

A Bundle is content-addressed by sha256 of its canonical JSON form. The
canonical form is JSON with sorted keys, no whitespace, ensure_ascii=True.
Two bundles with the same canonical form have the same bundle_id, so an
auditor can prove which bundle produced a decision by re-hashing.

Bundles can be HMAC-signed with COREIQ_POLICY_SIGNING_KEY or Ed25519-signed
with COREIQ_POLICY_PRIVATE_KEY / COREIQ_POLICY_PUBLIC_KEY (Wave 2B P1) for
transport between control plane and edge. The signature carries an algorithm
prefix (``hmac:`` / ``ed25519:``); legacy bare-hex signatures are still
accepted as HMAC. ``COREIQ_POLICY_SIGNING_ALG=ed25519`` selects Ed25519 at
sign time.

In production (``COREIQ_ENV=production``) the loader refuses to install an
unsigned bundle — empty signature is an error. Outside production, unsigned
bundles are accepted in dev mode for ergonomics.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

try:
    # Wave 2B P1: Ed25519 bundle signing for asymmetric trust between
    # control plane and edge. ``cryptography`` is a top-level dep.
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    _ED25519_AVAILABLE = True
except Exception:  # pragma: no cover
    _ED25519_AVAILABLE = False


logger = logging.getLogger("coreiq.policy.bundle")


class BundleSignatureError(Exception):
    """Raised when a bundle's signature does not verify against the configured key."""


# Wave 2B P1: signature scheme prefixes. A bundle signature without a
# prefix is treated as raw HMAC-SHA256 hex for back-compat with v1
# deployments. New signatures emitted by ``Bundle.sign()`` carry a
# prefix when ``COREIQ_POLICY_SIGNING_ALG`` selects the algorithm.
_HMAC_PREFIX = "hmac:"
_ED25519_PREFIX = "ed25519:"


VALID_MODES = ("enforce", "observe", "disabled")
VALID_RESIDENCIES = ("eu", "in", "us", "us-gov", "on-prem", "any")


def canonical_hash(content: Dict[str, Any]) -> str:
    """Return sha256:<hex> of the canonical JSON serialization of *content*.

    Canonical: sorted keys, no whitespace, ensure_ascii=True. The bundle_id
    field is excluded from the hash (so the hash is self-referential-safe).
    """
    payload = {k: v for k, v in content.items() if k != "bundle_id"}
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    digest = hashlib.sha256(blob.encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


def _hmac_sign(blob: bytes, key: bytes) -> str:
    return hmac.new(key, blob, hashlib.sha256).hexdigest()


@dataclass
class Bundle:
    """A versioned, content-addressed policy bundle.

    Persisted as JSON in the policy_bundles table. The wire format is also
    JSON. Optional YAML loading is supported in loader.py.
    """

    tenant_id: str = "default"
    version: int = 1
    mode: str = "observe"           # enforce | observe | disabled
    residency: str = "any"           # eu | in | us | us-gov | on-prem | any
    min_engine_version: str = "2.0"

    # Sovereignty
    allowed_egress: List[Dict[str, Any]] = field(default_factory=list)
    denied_egress: List[Dict[str, Any]] = field(default_factory=list)

    # Model & provider gates
    models: Dict[str, List[str]] = field(default_factory=lambda: {"allow": [], "deny": []})

    # Routing rules — first-match-wins, evaluated in priority order (lower = higher priority)
    routing: List[Dict[str, Any]] = field(default_factory=list)

    # Input/output guardrails
    guardrails: Dict[str, List[Dict[str, Any]]] = field(default_factory=lambda: {"input": [], "output": []})

    # Limits
    limits: Dict[str, Any] = field(default_factory=dict)

    # Tool-call governance — P1
    tools: Dict[str, List[str]] = field(default_factory=lambda: {"allow": [], "deny": []})

    # Group/role bindings — overlay overrides at evaluate-time
    bindings: List[Dict[str, Any]] = field(default_factory=list)

    # Provenance
    created_at: Optional[str] = None
    created_by: Optional[str] = None
    approved_by: List[str] = field(default_factory=list)
    approved_at: Optional[str] = None

    # Wave 3A: optional traffic-weight hint for future canary / A-B
    # selection engines. Persisted in canonical form so the bundle hash
    # changes when intent changes; no runtime selection logic yet — the
    # engine ignores the field today (Wave 4 work). Range: 1..100 inclusive.
    traffic_weight: Optional[int] = None

    # Computed/cached
    bundle_id: Optional[str] = None     # sha256:... — computed lazily

    # ---- (de)serialization --------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "tenant_id": self.tenant_id,
            "version": self.version,
            "mode": self.mode,
            "residency": self.residency,
            "min_engine_version": self.min_engine_version,
            "allowed_egress": self.allowed_egress,
            "denied_egress": self.denied_egress,
            "models": self.models,
            "routing": self.routing,
            "guardrails": self.guardrails,
            "limits": self.limits,
            "tools": self.tools,
            "bindings": self.bindings,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at,
            "traffic_weight": self.traffic_weight,
        }
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Bundle":
        b = cls(
            tenant_id=str(data.get("tenant_id", "default")),
            version=int(data.get("version", 1)),
            mode=str(data.get("mode", "observe")),
            residency=str(data.get("residency", "any")),
            min_engine_version=str(data.get("min_engine_version", "2.0")),
            allowed_egress=list(data.get("allowed_egress") or []),
            denied_egress=list(data.get("denied_egress") or []),
            models=dict(data.get("models") or {"allow": [], "deny": []}),
            routing=list(data.get("routing") or []),
            guardrails=dict(data.get("guardrails") or {"input": [], "output": []}),
            limits=dict(data.get("limits") or {}),
            tools=dict(data.get("tools") or {"allow": [], "deny": []}),
            bindings=list(data.get("bindings") or []),
            created_at=data.get("created_at"),
            created_by=data.get("created_by"),
            approved_by=list(data.get("approved_by") or []),
            approved_at=data.get("approved_at"),
            traffic_weight=(
                int(data["traffic_weight"])
                if data.get("traffic_weight") is not None else None
            ),
        )
        # Default empty allow/deny if user supplied a partial models dict
        b.models.setdefault("allow", [])
        b.models.setdefault("deny", [])
        b.guardrails.setdefault("input", [])
        b.guardrails.setdefault("output", [])
        b.tools.setdefault("allow", [])
        b.tools.setdefault("deny", [])
        b.validate()
        b.bundle_id = b.canonical_hash()
        return b

    def canonical_hash(self) -> str:
        return canonical_hash(self.to_dict())

    def validate(self) -> None:
        if self.mode not in VALID_MODES:
            raise ValueError(f"Invalid mode '{self.mode}'; must be one of {VALID_MODES}")
        if self.residency not in VALID_RESIDENCIES:
            raise ValueError(f"Invalid residency '{self.residency}'; must be one of {VALID_RESIDENCIES}")
        if self.traffic_weight is not None:
            if not isinstance(self.traffic_weight, int) or not (1 <= self.traffic_weight <= 100):
                raise ValueError(
                    f"traffic_weight must be int in [1, 100]; got {self.traffic_weight!r}"
                )
        if self.mode == "enforce" and self.residency != "any" and not self.approved_by:
            # 4-eyes guard: sovereign+enforce bundles need at least one approver.
            # The endpoint layer enforces 2 approvers; this is a structural minimum.
            # We don't *raise* here because draft bundles legitimately lack approvers;
            # activation is what enforces the 2-approver rule (see endpoints.py).
            pass

    # ---- signing ------------------------------------------------------------

    def _canonical_blob(self) -> bytes:
        """Canonical bytes signed by HMAC and Ed25519 alike."""
        return json.dumps(
            {k: v for k, v in self.to_dict().items() if k != "bundle_id"},
            sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        ).encode("utf-8")

    def sign(self, key: Optional[bytes] = None) -> str:
        """Return a signature over the canonical form.

        Algorithm selection (Wave 2B P1):
          * If *key* is supplied → HMAC-SHA256 with that key (legacy callers).
          * Else if ``COREIQ_POLICY_SIGNING_ALG=ed25519`` and
            ``COREIQ_POLICY_PRIVATE_KEY`` points at an Ed25519 PEM private key
            → Ed25519 signature, returned as ``ed25519:<hex>``.
          * Else if ``COREIQ_POLICY_SIGNING_KEY`` is set → HMAC-SHA256 hex.
            For back-compat the returned string is bare hex (no prefix) so
            existing on-disk signatures keep verifying without rewrites.
          * Else → empty string (unsigned, dev mode).
        """
        # Explicit HMAC key wins — preserves legacy in-process behavior.
        if key is not None:
            return _hmac_sign(self._canonical_blob(), key)

        alg = os.environ.get("COREIQ_POLICY_SIGNING_ALG", "").lower()
        if alg == "ed25519":
            sig = self.sign_ed25519()
            if sig:
                return _ED25519_PREFIX + sig
            return ""

        env = os.environ.get("COREIQ_POLICY_SIGNING_KEY", "")
        if not env:
            return ""
        return _hmac_sign(self._canonical_blob(), env.encode("utf-8"))

    def sign_ed25519(self, private_key_path: Optional[str] = None) -> str:
        """Sign the canonical bundle with an Ed25519 private key (PEM).

        Reads ``COREIQ_POLICY_PRIVATE_KEY`` (a filesystem path) when no
        explicit *private_key_path* is supplied. Returns the raw signature
        as a hex string (no prefix). Returns empty string when no key is
        configured. Raises ``BundleSignatureError`` if the configured
        key cannot be loaded as Ed25519.
        """
        if not _ED25519_AVAILABLE:  # pragma: no cover
            raise BundleSignatureError("Ed25519 unavailable: cryptography not installed")
        path = private_key_path or os.environ.get("COREIQ_POLICY_PRIVATE_KEY", "")
        if not path:
            return ""
        try:
            pem = open(path, "rb").read()
            sk = serialization.load_pem_private_key(pem, password=None)
        except Exception as exc:
            raise BundleSignatureError(
                f"Failed to load Ed25519 private key from {path}: {exc}"
            ) from exc
        if not isinstance(sk, ed25519.Ed25519PrivateKey):
            raise BundleSignatureError(
                f"Configured key at {path} is not an Ed25519 private key"
            )
        return sk.sign(self._canonical_blob()).hex()

    def verify_ed25519(
        self,
        signature_hex: str,
        public_key_pem: Optional[bytes] = None,
        public_key_path: Optional[str] = None,
    ) -> bool:
        """Verify an Ed25519 signature (hex, no prefix) over the canonical
        bundle.

        Reads ``COREIQ_POLICY_PUBLIC_KEY`` (a filesystem path) when neither
        *public_key_pem* nor *public_key_path* is supplied. Returns False on
        any verification failure (invalid signature, malformed key, etc.).
        """
        if not _ED25519_AVAILABLE:  # pragma: no cover
            return False
        try:
            pem = public_key_pem
            if pem is None:
                path = public_key_path or os.environ.get("COREIQ_POLICY_PUBLIC_KEY", "")
                if not path:
                    return False
                pem = open(path, "rb").read()
            pk = serialization.load_pem_public_key(pem)
            if not isinstance(pk, ed25519.Ed25519PublicKey):
                return False
            pk.verify(bytes.fromhex(signature_hex), self._canonical_blob())
            return True
        except Exception:
            return False

    def verify(self, signature: str, key: Optional[bytes] = None) -> bool:
        """Constant-time verify of *signature* against the bundle.

        Algorithm dispatch (Wave 2B P1):
          * Signature with ``ed25519:`` prefix → verify_ed25519().
          * Signature with ``hmac:`` prefix → strip and verify against
            ``COREIQ_POLICY_SIGNING_KEY`` (or *key*).
          * Bare hex signature → legacy HMAC path (back-compat).
          * Empty signature → True only when no key/algorithm is configured.
        """
        alg = os.environ.get("COREIQ_POLICY_SIGNING_ALG", "").lower()
        env_hmac = os.environ.get("COREIQ_POLICY_SIGNING_KEY", "")
        env_pub = os.environ.get("COREIQ_POLICY_PUBLIC_KEY", "")

        # Explicit Ed25519 prefix
        if signature.startswith(_ED25519_PREFIX):
            return self.verify_ed25519(signature[len(_ED25519_PREFIX):])

        # Explicit HMAC prefix
        if signature.startswith(_HMAC_PREFIX):
            sig_hex = signature[len(_HMAC_PREFIX):]
            if key is not None:
                expected = _hmac_sign(self._canonical_blob(), key)
            elif env_hmac:
                expected = _hmac_sign(self._canonical_blob(), env_hmac.encode("utf-8"))
            else:
                return False
            return hmac.compare_digest(expected, sig_hex)

        # No prefix — legacy back-compat path.
        if key is None and not env_hmac and not (alg == "ed25519" and env_pub):
            # Nothing configured — accept only empty signatures (dev mode).
            return signature == ""

        if alg == "ed25519" and env_pub and signature:
            # Algorithm pinned to Ed25519 but the signature carries no
            # prefix — accept it as raw hex Ed25519 to support sidecar
            # files that don't include the prefix.
            return self.verify_ed25519(signature)

        # Default: HMAC verification.
        if key is not None:
            expected = _hmac_sign(self._canonical_blob(), key)
        elif env_hmac:
            expected = _hmac_sign(self._canonical_blob(), env_hmac.encode("utf-8"))
        else:
            return False
        if not expected or not signature:
            return False
        return hmac.compare_digest(expected, signature)
