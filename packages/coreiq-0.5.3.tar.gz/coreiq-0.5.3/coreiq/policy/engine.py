"""Policy Engine — deterministic, synchronous, pure.

evaluate_pre(ctx) and evaluate_post(ctx, decision) are the only public
methods. Each runs the configured evaluators in order, appending
EvaluatedRule entries to the Decision and returning when an evaluator
emits a terminal action (deny / route / etc.) or all evaluators pass.

The engine MUST be pure given (bundle, ctx) — no I/O, no clock reads
beyond Decision.ts. This guarantees offline replay via /v1/policy/decisions/replay.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .bundle import Bundle
from .decision import Decision, DecisionAction, EvaluatedRule
from .evaluators import bindings as ev_bindings
from .evaluators import egress as ev_egress
from .evaluators import guardrails as ev_guardrails
from .evaluators import limits as ev_limits
from .evaluators import models as ev_models
from .evaluators import routing as ev_routing
from .evaluators import tools as ev_tools

logger = logging.getLogger("coreiq.policy.engine")


@dataclass
class RequestContext:
    """Inputs to the engine. Built by the pipeline integration layer."""
    tenant_id: str = "default"
    principal: str = ""              # virtual_key_id or user id
    groups: List[str] = field(default_factory=list)
    model: str = ""
    provider: str = ""
    target_host: str = ""            # e.g. api.openai.com
    target_deployment_id: Optional[str] = None
    target_residency: Optional[str] = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    cost_usd: Optional[float] = None
    pii_detected: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    messages: List[Dict[str, Any]] = field(default_factory=list)
    tools: List[Dict[str, Any]] = field(default_factory=list)  # OpenAI tool-calling shape
    trace_id: Optional[str] = None
    output_text: Optional[str] = None  # for post-evaluation


class PolicyEngine:
    """Singleton engine that evaluates the active Bundle against a request."""

    def __init__(self, bundle: Optional[Bundle] = None) -> None:
        self._bundle: Optional[Bundle] = bundle
        self._lock = threading.RLock()

    # ---- bundle management --------------------------------------------------

    def set_bundle(self, bundle: Bundle) -> None:
        with self._lock:
            self._bundle = bundle
            logger.info("Policy bundle activated: %s (mode=%s, residency=%s, tenant=%s)",
                        bundle.bundle_id, bundle.mode, bundle.residency, bundle.tenant_id)

    def get_bundle(self) -> Optional[Bundle]:
        with self._lock:
            return self._bundle

    @property
    def has_bundle(self) -> bool:
        return self._bundle is not None

    # ---- evaluation ---------------------------------------------------------

    def evaluate_pre(self, ctx: RequestContext) -> Decision:
        """Evaluate all pre-call rules.

        Order: mode → bindings (overlay) → egress → models → limits(pre)
              → guardrails(input) → routing → residency-join.
        """
        bundle = self._bundle
        decision = Decision(
            tenant_id=ctx.tenant_id,
            principal=ctx.principal,
            trace_id=ctx.trace_id,
            bundle_id=bundle.bundle_id if bundle else None,
            residency=bundle.residency if bundle else None,
            # Wave 1A P0: capture enough request context for replay determinism.
            messages=list(ctx.messages or []),
            input_tokens=ctx.input_tokens,
            request_metadata=dict(ctx.metadata or {}),
        )
        # bundle_age_seconds — best-effort: how stale was the bundle when used?
        try:
            if bundle is not None and bundle.created_at:
                from datetime import datetime as _dt, timezone as _tz
                created = _dt.fromisoformat(bundle.created_at.replace("Z", "+00:00"))
                if created.tzinfo is None:
                    created = created.replace(tzinfo=_tz.utc)
                decision.bundle_age_seconds = (
                    _dt.now(_tz.utc) - created
                ).total_seconds()
        except Exception:
            pass

        if bundle is None:
            decision.add(EvaluatedRule(
                rule_id="engine.no_bundle", evaluator="engine",
                matched=False, skipped_reason="no active bundle; default-allow",
            ))
            decision.action = DecisionAction.ALLOW
            decision.reason = "engine.no_bundle"
            return decision

        # Mode short-circuit
        if bundle.mode == "disabled":
            decision.add(EvaluatedRule(
                rule_id="mode.disabled", evaluator="engine",
                matched=True, action_taken=DecisionAction.ALLOW,
                detail="bundle mode=disabled",
            ))
            return decision

        # Bindings overlay
        effective = ev_bindings.apply(bundle, ctx, decision)
        decision._effective_bundle = effective

        # Sequence — first evaluator to set a terminal action wins.
        # tools is wired between guardrails(input) and routing per P1.
        for evaluator in (ev_egress, ev_models, ev_limits, ev_guardrails, ev_tools, ev_routing):
            evaluator.evaluate_pre(effective, ctx, decision)
            if decision.action in (DecisionAction.DENY, DecisionAction.DENY_SIMULATED):
                self._coerce_observe(bundle, decision)
                return decision

        # Residency join — if bundle declares a region and ctx has one, they must match
        if bundle.residency != "any" and ctx.target_residency:
            if ctx.target_residency != bundle.residency and ctx.target_residency != "any":
                decision.add(EvaluatedRule(
                    rule_id="residency.join", evaluator="engine", matched=True,
                    action_taken=DecisionAction.DENY,
                    detail=f"target residency={ctx.target_residency} != bundle residency={bundle.residency}",
                ))
                decision.action = DecisionAction.DENY
                decision.reason = "sovereignty.residency"
                self._coerce_observe(bundle, decision)
                return decision

        return decision

    def evaluate_post(self, ctx: RequestContext, decision: Decision) -> Decision:
        """Evaluate post-call rules: output limits, output guardrails.

        Uses the *effective* bundle (post-bindings-overlay) stashed on the
        Decision during evaluate_pre so per-group limit overrides apply.
        """
        bundle = decision._effective_bundle or self._bundle
        if bundle is None or bundle.mode == "disabled":
            return decision
        ev_limits.evaluate_post(bundle, ctx, decision)
        ev_guardrails.evaluate_post(bundle, ctx, decision)
        if decision.action in (DecisionAction.DENY, DecisionAction.DENY_SIMULATED):
            self._coerce_observe(bundle, decision)
        return decision

    @staticmethod
    def _coerce_observe(bundle: Bundle, decision: Decision) -> None:
        """In observe mode, downgrade DENY → DENY_SIMULATED so the request proceeds.

        Emits a ``policy.denied`` webhook event for both real and simulated
        denials so operators can see what was blocked (or would have been).
        """
        if bundle.mode == "observe" and decision.action == DecisionAction.DENY:
            decision.action = DecisionAction.DENY_SIMULATED
        if decision.action in (DecisionAction.DENY, DecisionAction.DENY_SIMULATED):
            try:
                from ..integrations.event_bus import emit, EVENT_POLICY_DENIED
                emit(EVENT_POLICY_DENIED, {
                    "tenant_id": decision.tenant_id,
                    "decision_id": decision.decision_id,
                    "action": decision.action,
                    "reason": decision.reason,
                    "bundle_id": decision.bundle_id,
                    "trace_id": decision.trace_id,
                }, tenant_id=decision.tenant_id)
            except Exception:
                pass  # event emission must never break policy evaluation


# ---- module-level singleton --------------------------------------------------

_engine: Optional[PolicyEngine] = None
_engine_lock = threading.Lock()


def get_policy_engine() -> PolicyEngine:
    global _engine
    if _engine is None:
        with _engine_lock:
            if _engine is None:
                _engine = PolicyEngine()
    return _engine


def reset_policy_engine() -> None:
    """Test-only: drop the singleton so the next get_ rebuilds it."""
    global _engine
    with _engine_lock:
        _engine = None
