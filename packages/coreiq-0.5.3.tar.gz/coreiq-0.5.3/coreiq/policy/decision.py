"""Policy Decision — the structured per-request verdict.

Every request that flows through the engine produces exactly one Decision.
Each evaluator step appends an EvaluatedRule with `matched`, `action_taken`,
and (for skipped rules) a `skipped_reason`. This gives auditors *negative*
evidence — proof that a rule was considered even when it didn't fire.
"""
from __future__ import annotations

import hashlib
import json
import logging
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    pass

logger = logging.getLogger("coreiq.policy.decision")


def compute_principal_hash(principal: str, tenant_id: str) -> str:
    """Return a 16-char sha256 hex of (principal+tenant_id).

    Used for GDPR-compatible chain linkage: when ``principal`` is later
    nulled to honour an Art. 17 erasure request, ``principal_hash`` keeps
    the audit chain coherent without retaining personal data.
    """
    if not principal:
        return ""
    blob = f"{principal}|{tenant_id or ''}".encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:16]


class DecisionAction:
    ALLOW = "allow"
    DENY = "deny"
    DENY_SIMULATED = "deny_simulated"   # observe-mode would-deny
    REDACT = "redact"
    ROUTE = "route"


@dataclass
class EvaluatedRule:
    """One step in a decision trace.

    matched=True means the rule fired and produced action_taken.
    matched=False with skipped_reason means it was considered and didn't apply.
    """
    rule_id: str
    evaluator: str            # "egress" | "models" | "routing" | "guardrails.input" | ...
    matched: bool
    action_taken: Optional[str] = None
    detail: Optional[str] = None
    skipped_reason: Optional[str] = None


@dataclass
class Decision:
    decision_id: str = field(default_factory=lambda: f"pd-{uuid.uuid4().hex}")
    bundle_id: Optional[str] = None       # sha256:... of the bundle that produced this
    tenant_id: str = "default"
    principal: str = ""                   # virtual_key_id or user id
    principal_hash: str = ""              # GDPR Art.17-safe linkage; auto-derived
    trace_id: Optional[str] = None
    action: str = DecisionAction.ALLOW
    reason: str = ""                      # short machine-tag e.g. "sovereignty.egress"
    target_deployment: Optional[str] = None
    residency: Optional[str] = None
    redactions: List[Dict[str, Any]] = field(default_factory=list)
    evaluated_rules: List[EvaluatedRule] = field(default_factory=list)
    bundle_age_seconds: Optional[float] = None
    ts: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    # Wave 1A P0: replay determinism — keep enough of the request context
    # to rebuild a RequestContext on /v1/policy/decisions/replay.
    messages: List[Dict[str, Any]] = field(default_factory=list)
    input_tokens: Optional[int] = None
    request_metadata: Dict[str, Any] = field(default_factory=dict)
    # Internal: the effective bundle (post-binding overlay) carried into post-eval.
    # Not persisted; for in-process post-evaluation only.
    _effective_bundle: Optional[Any] = None

    def __post_init__(self) -> None:
        # Derive principal_hash on construction so every persisted row
        # carries it, even when callers build Decision() directly.
        if self.principal and not self.principal_hash:
            self.principal_hash = compute_principal_hash(self.principal, self.tenant_id)

    def add(self, rule: EvaluatedRule) -> None:
        self.evaluated_rules.append(rule)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["evaluated_rules"] = [asdict(r) for r in self.evaluated_rules]
        d.pop("_effective_bundle", None)
        return d


class DecisionWriter:
    """Persists Decisions to the policy_decisions table.

    Best-effort and fail-soft: a DB write failure must NOT block the
    request — the decision is still in-memory and returned to the caller.
    The chained_audit logger is also notified so the decision is woven
    into the tamper-evident audit trail.
    """

    def write(self, decision: Decision) -> None:
        # Lazily derive principal_hash if a caller bypassed __post_init__.
        if decision.principal and not decision.principal_hash:
            decision.principal_hash = compute_principal_hash(
                decision.principal, decision.tenant_id,
            )
        try:
            from ..store.db import get_shared_connection
            conn = get_shared_connection()
            try:
                conn.execute(
                    """INSERT INTO policy_decisions
                       (decision_id, trace_id, bundle_id, tenant_id, principal,
                        principal_hash,
                        action, reason, evaluated_rules_json, target_deployment,
                        residency, redactions_json, ts,
                        messages_json, input_tokens, metadata_json,
                        bundle_age_seconds)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        decision.decision_id,
                        decision.trace_id,
                        decision.bundle_id,
                        decision.tenant_id,
                        decision.principal,
                        decision.principal_hash or None,
                        decision.action,
                        decision.reason,
                        json.dumps([asdict(r) for r in decision.evaluated_rules]),
                        decision.target_deployment,
                        decision.residency,
                        json.dumps(decision.redactions) if decision.redactions else None,
                        decision.ts,
                        # Wave 1A P0: replay determinism fields.
                        json.dumps(decision.messages) if decision.messages else None,
                        decision.input_tokens,
                        json.dumps(decision.request_metadata) if decision.request_metadata else None,
                        decision.bundle_age_seconds,
                    ),
                )
            except Exception as col_exc:
                # Backward-compat for stores that haven't picked up the
                # principal_hash ALTER TABLE yet. Retry without that column.
                err = str(col_exc).lower()
                if "principal_hash" not in err:
                    raise
                conn.execute(
                    """INSERT INTO policy_decisions
                       (decision_id, trace_id, bundle_id, tenant_id, principal,
                        action, reason, evaluated_rules_json, target_deployment,
                        residency, redactions_json, ts,
                        messages_json, input_tokens, metadata_json,
                        bundle_age_seconds)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        decision.decision_id, decision.trace_id, decision.bundle_id,
                        decision.tenant_id, decision.principal,
                        decision.action, decision.reason,
                        json.dumps([asdict(r) for r in decision.evaluated_rules]),
                        decision.target_deployment, decision.residency,
                        json.dumps(decision.redactions) if decision.redactions else None,
                        decision.ts,
                        json.dumps(decision.messages) if decision.messages else None,
                        decision.input_tokens,
                        json.dumps(decision.request_metadata) if decision.request_metadata else None,
                        decision.bundle_age_seconds,
                    ),
                )
            conn.commit()
        except Exception as exc:
            logger.debug("policy_decisions write failed (non-fatal): %s", exc)

        # Best-effort weave into the chained audit log
        try:
            from ..governance.chained_audit import ChainedAuditLogger
            ChainedAuditLogger(source="policy").log(
                action="policy.decision",
                principal=decision.principal,
                resource=f"bundle:{decision.bundle_id or 'unknown'}",
                outcome=decision.action,
                metadata={
                    "decision_id": decision.decision_id,
                    "reason": decision.reason,
                    "tenant_id": decision.tenant_id,
                    "trace_id": decision.trace_id,
                    "principal_hash": decision.principal_hash,
                },
            )
        except Exception as exc:
            logger.debug("chained_audit weave failed (non-fatal): %s", exc)


_writer: Optional[DecisionWriter] = None


def get_decision_writer() -> DecisionWriter:
    global _writer
    if _writer is None:
        _writer = DecisionWriter()
    return _writer
