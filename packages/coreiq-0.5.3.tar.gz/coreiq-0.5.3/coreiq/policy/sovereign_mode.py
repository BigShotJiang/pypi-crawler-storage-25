"""Sovereign-mode kill switch.

A one-line toggle that, when enabled, refuses to dispatch requests to
non-sovereign providers (the public clouds: openai.com, anthropic.com,
etc.). Sovereign-eligible providers are the ones a tenant runs in
their own jurisdiction: self-hosted vLLM / Ollama, AWS Bedrock pinned
to an EU region, Azure OpenAI in an EU tenant, on-prem TGI, etc.

Configuration::

    [policy]
    sovereign_mode = "enforce"          # off | warn | enforce
    sovereign_allow_hosts = [
        "*.internal",
        "ollama.local:*",
        "bedrock-runtime.eu-west-1.amazonaws.com",
    ]

    # OR via env:
    COREIQ_SOVEREIGN_MODE=enforce
    COREIQ_SOVEREIGN_ALLOW_HOSTS="*.internal,ollama.local:*,bedrock-runtime.eu-west-1.amazonaws.com"

This module produces a list of egress rules to inject into the active
policy bundle at load time. The egress evaluator
(``coreiq.policy.evaluators.egress``) does the actual default-deny
enforcement — sovereign mode is purely an ergonomic shortcut.

The default deny-list covers the well-known public-cloud SaaS hosts
that CoreIQ supports as providers, so you only have to specify what
you ALLOW.
"""
from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger("coreiq.policy.sovereign_mode")

# Public-cloud SaaS hosts CoreIQ supports — these are blocked when
# sovereign mode is enforced unless they appear on the allow-list.
_NON_SOVEREIGN_HOSTS = (
    "api.openai.com",
    "api.anthropic.com",
    "generativelanguage.googleapis.com",
    "api.cohere.com",
    "api.cohere.ai",
    "api.mistral.ai",
    "api.deepseek.com",
    "api.together.xyz",
    "api.replicate.com",
    "api.groq.com",
    "api.perplexity.ai",
    "api.x.ai",
    "api-inference.huggingface.co",
    "api.fireworks.ai",
)


def _parse_csv(raw: str) -> list[str]:
    return [item.strip() for item in raw.split(",") if item.strip()]


def get_mode() -> str:
    """Return ``off``, ``warn``, or ``enforce``."""
    raw = os.environ.get("COREIQ_SOVEREIGN_MODE", "").strip().lower()
    if not raw:
        try:
            from coreiq.config import _get_toml_value
            raw = str(_get_toml_value("policy.sovereign_mode") or "").lower()
        except Exception:
            raw = ""
    if raw not in ("off", "warn", "enforce"):
        return "off"
    return raw


def get_allow_hosts() -> list[str]:
    """Return the configured sovereign allow-list (host patterns)."""
    raw = os.environ.get("COREIQ_SOVEREIGN_ALLOW_HOSTS", "").strip()
    hosts: list[str] = []
    if raw:
        hosts.extend(_parse_csv(raw))
    try:
        from coreiq.config import _get_toml_value
        toml_val = _get_toml_value("policy.sovereign_allow_hosts")
        if isinstance(toml_val, list):
            hosts.extend(str(h) for h in toml_val)
    except Exception:
        pass
    return list(dict.fromkeys(hosts))  # dedupe, preserve order


def build_egress_rules() -> dict[str, list[dict[str, Any]]]:
    """Return ``{"allowed_egress": [...], "denied_egress": [...]}``.

    Empty dict when sovereign mode is off. The returned rules are meant
    to be merged into the active policy bundle at load time so the
    existing egress evaluator does the enforcement.
    """
    mode = get_mode()
    if mode == "off":
        return {"allowed_egress": [], "denied_egress": []}

    allowed = [
        {
            "id": f"sovereign.allow.{i}",
            "host_pattern": host,
            "residency": "sovereign",
        }
        for i, host in enumerate(get_allow_hosts())
    ]

    denied = [
        {
            "id": f"sovereign.deny.{i}",
            "host_pattern": host,
        }
        for i, host in enumerate(_NON_SOVEREIGN_HOSTS)
    ]

    if mode == "warn":
        # Warn mode: log on dispatch to non-sovereign hosts but don't
        # block. We achieve this by emitting denied rules with a special
        # ``warn_only`` tag the policy engine can honour. For now we
        # leave allowed_egress empty so requests pass and rely on the
        # log-only path the engine already supports.
        return {
            "allowed_egress": [],
            "denied_egress": [{**rule, "warn_only": True} for rule in denied],
        }

    return {"allowed_egress": allowed, "denied_egress": denied}


def is_enforced() -> bool:
    return get_mode() == "enforce"


def log_status() -> None:
    """Emit a single startup log line describing the current mode."""
    mode = get_mode()
    if mode == "off":
        logger.info("sovereign mode: OFF (all providers reachable)")
        return
    hosts = get_allow_hosts()
    logger.warning(
        "sovereign mode: %s — %d allow-host pattern(s), %d non-sovereign host(s) blocked",
        mode.upper(), len(hosts), len(_NON_SOVEREIGN_HOSTS),
    )
