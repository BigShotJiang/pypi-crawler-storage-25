"""CoreIQ Sovereign Policy Engine.

A single declarative Policy Bundle governs every request: sovereignty (egress
allowlist), model allow/deny, routing rules, guardrails, limits, and group
bindings. The engine is deterministic and offline-reproducible — given the
same bundle and request context, it returns the same Decision.

Public surface:
    Bundle               — the policy document (content-addressed by sha256)
    PolicyEngine         — evaluate(ctx) -> Decision
    Decision             — structured per-request verdict with evaluated rules
    get_policy_engine()  — process-wide singleton
    load_bundle_from_*   — loaders (file, dict, db)

Boundary rule: enforcement logic must live under coreiq/policy/ — call sites
elsewhere call PolicyEngine.evaluate(). Pre-existing modules
(governance/policy.py, governance/guardrails.py, proxy/routing/rules.py)
delegate here when COREIQ_POLICY_ENGINE=v2.
"""
from __future__ import annotations

from .bundle import Bundle, BundleSignatureError, canonical_hash
from .decision import Decision, DecisionAction, EvaluatedRule
from .engine import PolicyEngine, get_policy_engine, reset_policy_engine
from .loader import load_bundle_from_dict, load_bundle_from_file, load_active_bundle

__all__ = [
    "Bundle",
    "BundleSignatureError",
    "canonical_hash",
    "Decision",
    "DecisionAction",
    "EvaluatedRule",
    "PolicyEngine",
    "get_policy_engine",
    "reset_policy_engine",
    "load_bundle_from_dict",
    "load_bundle_from_file",
    "load_active_bundle",
]
