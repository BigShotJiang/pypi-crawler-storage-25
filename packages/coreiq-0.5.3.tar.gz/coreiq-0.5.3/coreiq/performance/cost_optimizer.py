"""Cost Optimizer / FinOps for AI — analyze traffic patterns and recommend cheaper models.

Watches LLM usage patterns and generates optimization recommendations:
- Identify requests that can be served by cheaper models
- Detect cache-eligible requests (semantically similar)
- Forecast monthly spend and savings potential
- Generate actionable routing rules

Usage::

    optimizer = CostOptimizer()
    optimizer.record_request(model="gpt-4o", tokens=500, cost=0.015, complexity="simple")
    report = optimizer.generate_report()
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# Model cost tiers (per 1K tokens, averaged input+output)
MODEL_COST_TIERS: Dict[str, float] = {
    "gpt-4o": 0.0075,
    "gpt-4o-mini": 0.0003,
    "gpt-4-turbo": 0.015,
    "gpt-3.5-turbo": 0.001,
    "claude-3-opus": 0.045,
    "claude-3-sonnet": 0.009,
    "claude-3-haiku": 0.00075,
    "claude-sonnet-4-6": 0.009,
    "claude-haiku-4-5": 0.002,
    "claude-opus-4-6": 0.045,
    "gemini-pro": 0.00025,
    "gemini-flash": 0.000075,
    "mistral-large": 0.006,
    "mistral-small": 0.0006,
}

# Complexity → recommended model tier
COMPLEXITY_DOWNGRADES: Dict[str, List[str]] = {
    "gpt-4o": ["gpt-4o-mini"],
    "gpt-4-turbo": ["gpt-4o", "gpt-4o-mini"],
    "claude-3-opus": ["claude-3-sonnet", "claude-3-haiku"],
    "claude-opus-4-6": ["claude-sonnet-4-6", "claude-haiku-4-5"],
    "claude-3-sonnet": ["claude-3-haiku"],
    "claude-sonnet-4-6": ["claude-haiku-4-5"],
    "mistral-large": ["mistral-small"],
}


@dataclass
class RequestRecord:
    model: str
    tokens: int
    cost: float
    complexity: str  # "simple", "moderate", "complex"
    latency_ms: int = 0
    cache_eligible: bool = False
    ts: str = ""


@dataclass
class OptimizationFinding:
    finding_type: str  # "model_downgrade", "cache_eligible", "unused_capacity"
    description: str
    current_model: str = ""
    recommended_model: str = ""
    affected_percentage: float = 0.0
    estimated_monthly_savings: float = 0.0
    confidence: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "finding_type": self.finding_type,
            "description": self.description,
            "current_model": self.current_model,
            "recommended_model": self.recommended_model,
            "affected_percentage": round(self.affected_percentage, 1),
            "estimated_monthly_savings": round(self.estimated_monthly_savings, 2),
            "confidence": round(self.confidence, 2),
        }


@dataclass
class CostReport:
    total_requests: int = 0
    total_cost: float = 0.0
    total_tokens: int = 0
    cost_by_model: Dict[str, float] = field(default_factory=dict)
    requests_by_model: Dict[str, int] = field(default_factory=dict)
    requests_by_complexity: Dict[str, int] = field(default_factory=dict)
    findings: List[OptimizationFinding] = field(default_factory=list)
    estimated_monthly_cost: float = 0.0
    potential_monthly_savings: float = 0.0
    generated_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_requests": self.total_requests,
            "total_cost": round(self.total_cost, 4),
            "total_tokens": self.total_tokens,
            "cost_by_model": {k: round(v, 4) for k, v in self.cost_by_model.items()},
            "requests_by_model": dict(self.requests_by_model),
            "requests_by_complexity": dict(self.requests_by_complexity),
            "findings": [f.to_dict() for f in self.findings],
            "estimated_monthly_cost": round(self.estimated_monthly_cost, 2),
            "potential_monthly_savings": round(self.potential_monthly_savings, 2),
            "generated_at": self.generated_at,
        }


class CostOptimizer:
    """Analyzes LLM usage and generates cost optimization recommendations."""

    def __init__(self):
        self._lock = threading.Lock()
        self._records: List[RequestRecord] = []
        self._window_start: float = time.time()

    def record_request(
        self, model: str, tokens: int, cost: float,
        complexity: str = "moderate", latency_ms: int = 0,
        cache_eligible: bool = False,
    ) -> None:
        """Record a completed LLM request for analysis."""
        record = RequestRecord(
            model=model, tokens=tokens, cost=cost,
            complexity=complexity, latency_ms=latency_ms,
            cache_eligible=cache_eligible, ts=_now(),
        )
        with self._lock:
            self._records.append(record)

    def generate_report(self) -> CostReport:
        """Generate a cost optimization report from recorded requests."""
        with self._lock:
            records = list(self._records)

        if not records:
            return CostReport(generated_at=_now())

        report = CostReport(
            total_requests=len(records),
            total_cost=sum(r.cost for r in records),
            total_tokens=sum(r.tokens for r in records),
            generated_at=_now(),
        )

        # Aggregate by model
        for r in records:
            report.cost_by_model[r.model] = report.cost_by_model.get(r.model, 0) + r.cost
            report.requests_by_model[r.model] = report.requests_by_model.get(r.model, 0) + 1
            report.requests_by_complexity[r.complexity] = report.requests_by_complexity.get(r.complexity, 0) + 1

        # Estimate monthly cost (extrapolate from window)
        window_hours = max(1, (time.time() - self._window_start) / 3600)
        report.estimated_monthly_cost = (report.total_cost / window_hours) * 730  # avg hours/month

        # Finding 1: Model downgrade opportunities
        for model in report.requests_by_model:
            if model not in COMPLEXITY_DOWNGRADES:
                continue
            model_records = [r for r in records if r.model == model]
            simple_records = [r for r in model_records if r.complexity == "simple"]
            if not simple_records:
                continue

            pct = len(simple_records) / len(model_records) * 100
            cheaper = COMPLEXITY_DOWNGRADES[model][0]
            current_cost_per_k = MODEL_COST_TIERS.get(model, 0.01)
            cheaper_cost_per_k = MODEL_COST_TIERS.get(cheaper, 0.001)
            savings_ratio = 1 - (cheaper_cost_per_k / current_cost_per_k) if current_cost_per_k > 0 else 0

            simple_cost = sum(r.cost for r in simple_records)
            monthly_savings = (simple_cost / window_hours) * 730 * savings_ratio

            report.findings.append(OptimizationFinding(
                finding_type="model_downgrade",
                description=f"{pct:.0f}% of {model} requests are simple Q&A that {cheaper} handles with equal quality.",
                current_model=model,
                recommended_model=cheaper,
                affected_percentage=pct,
                estimated_monthly_savings=monthly_savings,
                confidence=0.85,
            ))

        # Finding 2: Cache-eligible requests
        cache_eligible = [r for r in records if r.cache_eligible]
        if cache_eligible:
            cache_pct = len(cache_eligible) / len(records) * 100
            cache_cost = sum(r.cost for r in cache_eligible)
            monthly_cache_savings = (cache_cost / window_hours) * 730 * 0.95  # 95% saved on cache hits

            report.findings.append(OptimizationFinding(
                finding_type="cache_eligible",
                description=f"{cache_pct:.0f}% of requests are cache-eligible (semantically similar to past queries).",
                affected_percentage=cache_pct,
                estimated_monthly_savings=monthly_cache_savings,
                confidence=0.75,
            ))

        report.potential_monthly_savings = sum(f.estimated_monthly_savings for f in report.findings)
        return report

    def clear(self) -> None:
        """Clear recorded data."""
        with self._lock:
            self._records.clear()
            self._window_start = time.time()
