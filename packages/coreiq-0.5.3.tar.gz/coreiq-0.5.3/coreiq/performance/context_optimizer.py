"""Context Window Optimizer — compress/summarize context to save tokens.

Analyzes incoming prompts and recommends or applies compression to fit
within token budgets while maintaining quality.
"""
from __future__ import annotations
import re
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
logger = logging.getLogger(__name__)

@dataclass
class OptimizationResult:
    original_tokens: int
    optimized_tokens: int
    tokens_saved: int
    savings_pct: float
    techniques_applied: List[str] = field(default_factory=list)
    optimized_messages: List[Dict[str, Any]] = field(default_factory=list)
    def to_dict(self) -> Dict[str, Any]:
        return {"original_tokens": self.original_tokens, "optimized_tokens": self.optimized_tokens,
                "tokens_saved": self.tokens_saved, "savings_pct": round(self.savings_pct, 1),
                "techniques_applied": self.techniques_applied, "message_count": len(self.optimized_messages)}

class ContextOptimizer:
    def __init__(self, target_reduction: float = 0.3):
        self.target_reduction = target_reduction

    def _estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)

    def optimize(self, messages: List[Dict[str, Any]], token_budget: Optional[int] = None) -> OptimizationResult:
        original_tokens = sum(self._estimate_tokens(m.get("content", "") if isinstance(m.get("content"), str) else str(m.get("content", ""))) for m in messages)
        optimized = []
        techniques = []
        for msg in messages:
            content = msg.get("content", "")
            if not isinstance(content, str):
                optimized.append(dict(msg))
                continue
            new_content = content
            # Remove excessive whitespace
            if "  " in new_content or "\n\n\n" in new_content:
                new_content = re.sub(r"\s+", " ", new_content).strip()
                if "whitespace_removal" not in techniques:
                    techniques.append("whitespace_removal")
            # Remove redundant system prompt repetitions (keep first occurrence)
            if msg.get("role") == "system" and len(new_content) > 500:
                sentences = new_content.split(". ")
                seen = set()
                deduped = []
                for s in sentences:
                    key = s.strip().lower()[:50]
                    if key not in seen:
                        seen.add(key)
                        deduped.append(s)
                if len(deduped) < len(sentences):
                    new_content = ". ".join(deduped)
                    if "deduplication" not in techniques:
                        techniques.append("deduplication")
            # Truncate very long user messages (keep first + last portions)
            if msg.get("role") == "user" and len(new_content) > 2000:
                new_content = new_content[:800] + "\n[...content truncated for efficiency...]\n" + new_content[-800:]
                if "long_message_truncation" not in techniques:
                    techniques.append("long_message_truncation")
            optimized.append({**msg, "content": new_content})

        opt_tokens = sum(self._estimate_tokens(m.get("content", "") if isinstance(m.get("content"), str) else "") for m in optimized)
        saved = original_tokens - opt_tokens
        return OptimizationResult(
            original_tokens=original_tokens, optimized_tokens=opt_tokens,
            tokens_saved=saved, savings_pct=(saved / original_tokens * 100) if original_tokens > 0 else 0,
            techniques_applied=techniques, optimized_messages=optimized)
