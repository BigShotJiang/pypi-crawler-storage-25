"""Model router — route requests to different models based on rules."""
from dataclasses import dataclass
from typing import Callable


@dataclass
class RoutingRule:
    name: str
    condition: Callable[[dict], bool]
    target_model: str
    priority: int = 0


class ModelRouter:
    """
    Routes requests to models based on ordered rules.
    Falls through to default_model if no rule matches.
    """

    def __init__(self, default_model: str):
        self._default = default_model
        self._rules: list[RoutingRule] = []

    def add_rule(self, rule: RoutingRule) -> None:
        self._rules.append(rule)
        self._rules.sort(key=lambda r: -r.priority)

    def route(self, request: dict) -> str:
        """Return the model ID to use for this request."""
        for rule in self._rules:
            try:
                if rule.condition(request):
                    return rule.target_model
            except Exception:
                continue
        return self._default

    def remove_rule(self, name: str) -> bool:
        before = len(self._rules)
        self._rules = [r for r in self._rules if r.name != name]
        return len(self._rules) < before


# Common built-in conditions
def has_images(request: dict) -> bool:
    """True if any message contains image content."""
    for msg in request.get("messages", []):
        content = msg.get("content", "")
        if isinstance(content, list):
            if any(b.get("type") == "image_url" for b in content if isinstance(b, dict)):
                return True
    return False


def token_count_exceeds(threshold: int) -> Callable[[dict], bool]:
    """Return a condition that's True if the prompt token estimate exceeds threshold."""
    def check(request: dict) -> bool:
        text = " ".join(
            msg.get("content", "") for msg in request.get("messages", [])
            if isinstance(msg.get("content"), str)
        )
        return len(text.split()) * 4 // 3 > threshold  # rough token estimate
    return check
