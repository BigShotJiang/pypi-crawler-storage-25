"""Cost anomaly detection and budget governance.

Uses exponential moving average (EMA) to learn per-model/tenant cost baselines,
then fires alerts when spend deviates beyond a configurable sigma threshold.

Usage::

    from coreiq.performance import BudgetGovernor, AlertChannel

    governor = BudgetGovernor(
        org_budget_usd_per_day=500.0,
        anomaly_threshold_sigma=3.0,
        baseline_window_days=7,
        alerts=[AlertChannel.webhook("https://hooks.slack.com/...")],
    )
    governor.record(model="gpt-4o", cost_usd=0.05, tokens=1000)
    forecast = governor.forecast_month_end(current_day=15)
"""
import math
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Alert channels
# ---------------------------------------------------------------------------

@dataclass
class CostAnomaly:
    dimension: str          # e.g. "gpt-4o" or "org"
    observed: float         # current spend
    baseline: float         # expected spend (EMA)
    sigma: float            # how many std devs above baseline
    threshold_sigma: float
    ts: str = field(default_factory=_now_iso)


class AlertChannel:
    """Factory for alert dispatch channels."""

    def __init__(self, kind: str, target: str, extra: Optional[Dict[str, Any]] = None):
        self.kind = kind
        self.target = target
        self.extra = extra or {}

    @classmethod
    def webhook(cls, url: str, headers: Optional[Dict[str, str]] = None) -> "AlertChannel":
        return cls("webhook", url, {"headers": headers or {}})

    @classmethod
    def slack(cls, webhook_url: str) -> "AlertChannel":
        return cls("slack", webhook_url)

    @classmethod
    def email(cls, address: str, smtp_host: str = "", smtp_port: int = 587) -> "AlertChannel":
        return cls("email", address, {"smtp_host": smtp_host, "smtp_port": smtp_port})

    @classmethod
    def callback(cls, fn: Callable[[CostAnomaly], None]) -> "AlertChannel":
        ch = cls("callback", "")
        ch._callback = fn
        return ch

    def dispatch(self, anomaly: CostAnomaly) -> None:
        """Send alert. Failures are swallowed — alerts must not break the call path."""
        try:
            if self.kind in ("webhook", "slack"):
                self._dispatch_webhook(anomaly)
            elif self.kind == "email":
                self._dispatch_email(anomaly)
            elif self.kind == "callback" and hasattr(self, "_callback"):
                self._callback(anomaly)
        except Exception:
            pass

    def _dispatch_webhook(self, anomaly: CostAnomaly) -> None:
        import urllib.request
        import json as _json
        payload = {
            "text": (
                f"[CoreIQ] Cost anomaly: {anomaly.dimension} spending {anomaly.observed:.4f} USD "
                f"({anomaly.sigma:.1f}\u03c3 above baseline {anomaly.baseline:.4f} USD)"
            ),
            "anomaly": {
                "dimension": anomaly.dimension,
                "observed": anomaly.observed,
                "baseline": anomaly.baseline,
                "sigma": anomaly.sigma,
                "ts": anomaly.ts,
            },
        }
        data = _json.dumps(payload).encode()
        headers = {"Content-Type": "application/json", **self.extra.get("headers", {})}
        req = urllib.request.Request(self.target, data=data, headers=headers, method="POST")
        urllib.request.urlopen(req, timeout=5)

    def _dispatch_email(self, anomaly: CostAnomaly) -> None:
        import smtplib
        from email.mime.text import MIMEText
        subject = f"[CoreIQ] Cost anomaly: {anomaly.dimension}"
        body = (
            f"Cost anomaly detected:\n"
            f"  Dimension: {anomaly.dimension}\n"
            f"  Observed: ${anomaly.observed:.4f}\n"
            f"  Baseline: ${anomaly.baseline:.4f}\n"
            f"  Sigma: {anomaly.sigma:.1f}\u03c3\n"
            f"  Timestamp: {anomaly.ts}\n"
        )
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = "coreiq-alerts@localhost"
        msg["To"] = self.target
        smtp_host = self.extra.get("smtp_host", "localhost")
        smtp_port = self.extra.get("smtp_port", 587)
        if smtp_host:
            with smtplib.SMTP(smtp_host, smtp_port, timeout=5) as s:
                s.send_message(msg)


# ---------------------------------------------------------------------------
# EMA-based anomaly detector
# ---------------------------------------------------------------------------

class _EMABaseline:
    """Per-dimension exponential moving average baseline tracker."""

    def __init__(self, alpha: float = 0.1):
        self._alpha = alpha          # smoothing factor (lower = slower adaptation)
        self._ema: Optional[float] = None
        self._emv: float = 0.0      # EMA of variance
        self._lock = threading.Lock()

    def update(self, value: float) -> tuple:
        """Update EMA with new observation. Returns (ema, std_dev)."""
        with self._lock:
            if self._ema is None:
                self._ema = value
                return self._ema, 0.0
            delta = value - self._ema
            self._ema = self._ema + self._alpha * delta
            self._emv = (1 - self._alpha) * (self._emv + self._alpha * delta ** 2)
            std = math.sqrt(self._emv) if self._emv > 0 else 0.0
            return self._ema, std

    @property
    def current(self) -> tuple:
        """Return current (ema, std_dev) without updating."""
        with self._lock:
            ema = self._ema or 0.0
            std = math.sqrt(self._emv) if self._emv > 0 else 0.0
            return ema, std


# ---------------------------------------------------------------------------
# Budget forecast
# ---------------------------------------------------------------------------

@dataclass
class BudgetForecast:
    projected_monthly_spend: float
    current_spend: float
    days_elapsed: int
    days_in_month: int = 30
    days_until_exhaustion: Optional[int] = None
    anomalies: List[CostAnomaly] = field(default_factory=list)

    @property
    def on_track(self) -> bool:
        return self.projected_monthly_spend <= (
            (self.current_spend / max(self.days_elapsed, 1)) * self.days_in_month
        )


# ---------------------------------------------------------------------------
# Budget governor
# ---------------------------------------------------------------------------

class BudgetGovernor:
    """Hierarchical budget governor with EMA-based anomaly detection.

    Tracks spend at org, team, and model-key levels. Learns baselines
    and fires alerts when spend deviates beyond threshold_sigma.

    Usage::

        governor = BudgetGovernor(
            org_budget_usd_per_day=500.0,
            anomaly_threshold_sigma=3.0,
            alerts=[AlertChannel.webhook("https://...")],
        )
        governor.record(model="gpt-4o", cost_usd=0.05, tokens=1000)
        governor.record(model="gpt-4o", cost_usd=0.05, tokens=1000, team="eng")
    """

    def __init__(
        self,
        org_budget_usd_per_day: Optional[float] = None,
        team_budgets: Optional[Dict[str, float]] = None,
        anomaly_threshold_sigma: float = 3.0,
        baseline_window_days: int = 7,
        alerts: Optional[List[AlertChannel]] = None,
        ema_alpha: float = 0.15,
    ):
        self._org_budget = org_budget_usd_per_day
        self._team_budgets = team_budgets or {}
        self._threshold_sigma = anomaly_threshold_sigma
        self._baseline_window_days = baseline_window_days
        self._alerts = alerts or []
        self._ema_alpha = ema_alpha

        self._lock = threading.Lock()
        self._baselines: Dict[str, _EMABaseline] = {}   # keyed by dimension
        self._spend_today: Dict[str, float] = {}        # dimension → today's spend
        self._spend_month: float = 0.0
        self._day_start = time.time()
        self._recent_anomalies: List[CostAnomaly] = []

    def _get_baseline(self, dimension: str) -> _EMABaseline:
        if dimension not in self._baselines:
            self._baselines[dimension] = _EMABaseline(alpha=self._ema_alpha)
        return self._baselines[dimension]

    def _check_day_rollover(self) -> None:
        """Reset daily counters if a new day has started."""
        now = time.time()
        if now - self._day_start >= 86400:
            # Flush today's spend into baselines before resetting
            for dim, spend in self._spend_today.items():
                self._get_baseline(dim).update(spend)
            self._spend_today.clear()
            self._day_start = now

    def record(
        self,
        *,
        cost_usd: float = 0.0,
        tokens: int = 0,
        model: Optional[str] = None,
        team: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> List[CostAnomaly]:
        """Record a spend event. Returns any anomalies detected."""
        with self._lock:
            self._check_day_rollover()
            self._spend_month += cost_usd

            anomalies: List[CostAnomaly] = []
            dimensions = ["org"]
            if model:
                dimensions.append(f"model:{model}")
            if team:
                dimensions.append(f"team:{team}")
            if api_key:
                dimensions.append(f"key:{api_key[:8]}")

            for dim in dimensions:
                self._spend_today[dim] = self._spend_today.get(dim, 0.0) + cost_usd
                ema, std = self._get_baseline(dim).current

                if ema > 0 and std > 0:
                    current_rate = self._spend_today[dim]
                    deviation = (current_rate - ema) / std
                    if deviation > self._threshold_sigma:
                        anomaly = CostAnomaly(
                            dimension=dim,
                            observed=current_rate,
                            baseline=ema,
                            sigma=deviation,
                            threshold_sigma=self._threshold_sigma,
                        )
                        anomalies.append(anomaly)
                        self._recent_anomalies.append(anomaly)

            for anomaly in anomalies:
                for channel in self._alerts:
                    channel.dispatch(anomaly)

            return anomalies

    def forecast_month_end(self, current_day: int = 1) -> BudgetForecast:
        """Project month-end spend based on current daily rate."""
        with self._lock:
            days_elapsed = max(current_day, 1)
            daily_rate = self._spend_month / days_elapsed
            projected = daily_rate * 30

            days_until_exhaustion = None
            if self._org_budget and daily_rate > 0:
                remaining = self._org_budget * 30 - self._spend_month
                if remaining > 0:
                    days_until_exhaustion = int(remaining / daily_rate)
                else:
                    days_until_exhaustion = 0

            return BudgetForecast(
                projected_monthly_spend=round(projected, 4),
                current_spend=round(self._spend_month, 4),
                days_elapsed=days_elapsed,
                days_until_exhaustion=days_until_exhaustion,
                anomalies=list(self._recent_anomalies[-10:]),  # last 10
            )

    @property
    def recent_anomalies(self) -> List[CostAnomaly]:
        with self._lock:
            return list(self._recent_anomalies[-20:])
