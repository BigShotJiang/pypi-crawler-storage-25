"""Team (group) credit pools (B4 — cyberpod-gateway integration).

This module layers group-level budgets on top of the per-key
:class:`coreiq.performance.budget.BudgetTracker`. A
:class:`GroupBudgetTracker` aggregates cost and token consumption across
every API key that belongs to the same ``group_id`` and enforces a
monthly budget.

State is persisted in the ``group_budgets`` table, so budgets survive
process restarts. The in-memory layer is a single
:class:`threading.Lock`-guarded dict, mirroring the existing
``BudgetTracker`` pattern.
"""
from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from ..store.db import get_shared_connection
from .budget import BudgetExceeded


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class GroupBudgetExceeded(BudgetExceeded):
    """Raised when a group's monthly budget would be exceeded."""

    def __init__(self, dimension: str, used: float, limit: float, group_id: str = ""):
        super().__init__(dimension=dimension, used=used, limit=limit)
        self.group_id = group_id

    def __str__(self) -> str:  # pragma: no cover - trivial
        return (
            f"Group budget exceeded [group={self.group_id}, {self.dimension}]: "
            f"used={self.used:.2f}, limit={self.limit:.2f}"
        )


# ---------------------------------------------------------------------------
# Config + stats dataclasses
# ---------------------------------------------------------------------------


@dataclass
class GroupBudgetConfig:
    monthly_budget_usd: float = 0.0
    monthly_budget_tokens: int = 0


@dataclass
class GroupBudgetStats:
    group_id: str
    tenant_id: str = ""
    monthly_budget_usd: float = 0.0
    monthly_budget_tokens: int = 0
    consumed_usd: float = 0.0
    consumed_tokens: int = 0
    period_start: str = ""
    remaining_usd: float = 0.0
    remaining_tokens: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "group_id": self.group_id,
            "tenant_id": self.tenant_id,
            "monthly_budget_usd": self.monthly_budget_usd,
            "monthly_budget_tokens": self.monthly_budget_tokens,
            "consumed_usd": round(self.consumed_usd, 6),
            "consumed_tokens": int(self.consumed_tokens),
            "remaining_usd": round(self.remaining_usd, 6),
            "remaining_tokens": int(self.remaining_tokens),
            "period_start": self.period_start,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _period_start_iso() -> str:
    """First day of the current UTC month in ISO-8601."""
    now = datetime.now(timezone.utc)
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()


_COLS = (
    "id",
    "group_id",
    "tenant_id",
    "monthly_budget_usd",
    "monthly_budget_tokens",
    "consumed_usd",
    "consumed_tokens",
    "period_start",
    "created_at",
    "updated_at",
)


def _row_to_stats(row: Any) -> Optional[GroupBudgetStats]:
    if row is None:
        return None

    def get(k: str, default: Any = None) -> Any:
        try:
            return row[k]
        except (KeyError, IndexError, TypeError):
            return default

    usd = float(get("monthly_budget_usd") or 0)
    toks = int(get("monthly_budget_tokens") or 0)
    cu = float(get("consumed_usd") or 0)
    ct = int(get("consumed_tokens") or 0)
    return GroupBudgetStats(
        group_id=str(get("group_id") or ""),
        tenant_id=str(get("tenant_id") or ""),
        monthly_budget_usd=usd,
        monthly_budget_tokens=toks,
        consumed_usd=cu,
        consumed_tokens=ct,
        remaining_usd=max(0.0, usd - cu) if usd else 0.0,
        remaining_tokens=max(0, toks - ct) if toks else 0,
        period_start=str(get("period_start") or ""),
    )


# ---------------------------------------------------------------------------
# Tracker
# ---------------------------------------------------------------------------


class GroupBudgetTracker:
    """Persistent, thread-safe tracker for group-level budgets."""

    def __init__(self) -> None:
        self._lock = threading.Lock()

    # -- internal persistence helpers -----------------------------------

    def _get_row(self, group_id: str) -> Optional[dict[str, Any]]:
        conn = get_shared_connection()
        row = conn.execute(
            "SELECT * FROM group_budgets WHERE group_id=?",
            (group_id,),
        ).fetchone()
        return row  # type: ignore[return-value]

    def _upsert(
        self,
        *,
        group_id: str,
        tenant_id: str,
        monthly_budget_usd: float,
        monthly_budget_tokens: int,
        consumed_usd: float,
        consumed_tokens: int,
        period_start: str,
        created_at: str,
    ) -> None:
        conn = get_shared_connection()
        conn.execute(
            f"INSERT OR REPLACE INTO group_budgets ({', '.join(_COLS)}) "
            f"VALUES ({', '.join(['?'] * len(_COLS))})",
            (
                str(uuid.uuid5(uuid.NAMESPACE_DNS, f"group-budget:{group_id}")),
                group_id,
                tenant_id,
                float(monthly_budget_usd),
                int(monthly_budget_tokens),
                float(consumed_usd),
                int(consumed_tokens),
                period_start,
                created_at,
                _now_iso(),
            ),
        )
        conn.commit()

    # -- public API -----------------------------------------------------

    def grant(
        self,
        group_id: str,
        config: GroupBudgetConfig,
        tenant_id: str = "",
    ) -> GroupBudgetStats:
        """Create or update a budget for *group_id*.

        If a budget already exists, only the limits are updated — the
        current consumption and period_start are preserved.
        """
        with self._lock:
            existing = self._get_row(group_id)
            existing_stats = _row_to_stats(existing)
            created_at = (
                existing_stats.period_start
                if existing_stats and existing_stats.period_start
                else _now_iso()
            )
            period_start = (
                existing_stats.period_start
                if existing_stats and existing_stats.period_start
                else _period_start_iso()
            )
            consumed_usd = existing_stats.consumed_usd if existing_stats else 0.0
            consumed_tokens = existing_stats.consumed_tokens if existing_stats else 0
            tid = tenant_id or (existing_stats.tenant_id if existing_stats else "")
            self._upsert(
                group_id=group_id,
                tenant_id=tid,
                monthly_budget_usd=config.monthly_budget_usd,
                monthly_budget_tokens=config.monthly_budget_tokens,
                consumed_usd=consumed_usd,
                consumed_tokens=consumed_tokens,
                period_start=period_start,
                created_at=created_at,
            )
        return self.stats(group_id)

    def consume(
        self,
        group_id: str,
        cost_usd: float = 0.0,
        tokens: int = 0,
    ) -> GroupBudgetStats:
        """Atomically add consumption. Raises :class:`GroupBudgetExceeded`
        if the new totals would breach either configured limit."""
        with self._lock:
            row = self._get_row(group_id)
            stats = _row_to_stats(row)
            if stats is None:
                raise GroupBudgetExceeded(
                    dimension="not_configured",
                    used=float(cost_usd),
                    limit=0.0,
                    group_id=group_id,
                )
            new_usd = stats.consumed_usd + float(cost_usd or 0)
            new_tokens = stats.consumed_tokens + int(tokens or 0)
            if stats.monthly_budget_usd and new_usd > stats.monthly_budget_usd:
                raise GroupBudgetExceeded(
                    dimension="monthly_budget_usd",
                    used=new_usd,
                    limit=stats.monthly_budget_usd,
                    group_id=group_id,
                )
            if stats.monthly_budget_tokens and new_tokens > stats.monthly_budget_tokens:
                raise GroupBudgetExceeded(
                    dimension="monthly_budget_tokens",
                    used=float(new_tokens),
                    limit=float(stats.monthly_budget_tokens),
                    group_id=group_id,
                )
            self._upsert(
                group_id=group_id,
                tenant_id=stats.tenant_id,
                monthly_budget_usd=stats.monthly_budget_usd,
                monthly_budget_tokens=stats.monthly_budget_tokens,
                consumed_usd=new_usd,
                consumed_tokens=new_tokens,
                period_start=stats.period_start or _period_start_iso(),
                created_at=stats.period_start or _now_iso(),
            )
        return self.stats(group_id)

    def stats(self, group_id: str) -> GroupBudgetStats:
        row = self._get_row(group_id)
        result = _row_to_stats(row)
        if result is None:
            return GroupBudgetStats(group_id=group_id)
        return result

    def remaining(self, group_id: str) -> dict[str, Any]:
        s = self.stats(group_id)
        return {"usd": s.remaining_usd, "tokens": s.remaining_tokens}

    def reset_period(self, group_id: str) -> GroupBudgetStats:
        """Zero the consumed counters and bump period_start to now."""
        with self._lock:
            row = self._get_row(group_id)
            stats = _row_to_stats(row)
            if stats is None:
                return GroupBudgetStats(group_id=group_id)
            self._upsert(
                group_id=group_id,
                tenant_id=stats.tenant_id,
                monthly_budget_usd=stats.monthly_budget_usd,
                monthly_budget_tokens=stats.monthly_budget_tokens,
                consumed_usd=0.0,
                consumed_tokens=0,
                period_start=_period_start_iso(),
                created_at=_now_iso(),
            )
        return self.stats(group_id)


# ---------------------------------------------------------------------------
# Process singleton
# ---------------------------------------------------------------------------


_tracker_lock = threading.Lock()
_tracker: Optional[GroupBudgetTracker] = None


def get_group_budget_tracker() -> GroupBudgetTracker:
    global _tracker
    with _tracker_lock:
        if _tracker is None:
            _tracker = GroupBudgetTracker()
        return _tracker


__all__ = [
    "GroupBudgetConfig",
    "GroupBudgetStats",
    "GroupBudgetTracker",
    "GroupBudgetExceeded",
    "get_group_budget_tracker",
]
