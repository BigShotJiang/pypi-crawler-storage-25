"""Request batcher — coalesce concurrent LLM requests to reduce API overhead."""
import asyncio
from dataclasses import dataclass
from typing import Any, Callable, Coroutine, Optional


@dataclass
class BatchConfig:
    max_batch_size: int = 10
    max_wait_ms: int = 20  # max time to wait for more requests before flushing


@dataclass
class _PendingRequest:
    args: tuple
    kwargs: dict
    future: asyncio.Future


class RequestBatcher:
    """
    Batches async requests within a time window.
    The caller provides a process_batch function that receives a list of
    (args, kwargs) tuples and returns a list of results in the same order.
    """

    def __init__(
        self,
        process_batch: Callable[[list[tuple]], Coroutine],
        config: Optional[BatchConfig] = None,
    ):
        self._process = process_batch
        self._config = config or BatchConfig()
        self._queue: list[_PendingRequest] = []
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None

    async def submit(self, *args, **kwargs) -> Any:
        """Submit a request; returns when the batch is processed."""
        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        req = _PendingRequest(args=args, kwargs=kwargs, future=future)

        async with self._lock:
            self._queue.append(req)
            if len(self._queue) >= self._config.max_batch_size:
                await self._flush()
            elif self._flush_task is None or self._flush_task.done():
                self._flush_task = asyncio.create_task(self._delayed_flush())

        return await future

    async def _delayed_flush(self):
        await asyncio.sleep(self._config.max_wait_ms / 1000)
        async with self._lock:
            if self._queue:
                await self._flush()

    async def _flush(self):
        if not self._queue:
            return
        batch, self._queue = self._queue[:], []
        try:
            results = await self._process([(r.args, r.kwargs) for r in batch])
            for req, result in zip(batch, results):
                if not req.future.done():
                    req.future.set_result(result)
        except Exception as exc:
            for req in batch:
                if not req.future.done():
                    req.future.set_exception(exc)
