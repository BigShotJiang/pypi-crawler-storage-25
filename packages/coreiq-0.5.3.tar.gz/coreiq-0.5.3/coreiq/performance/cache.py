"""Cache observability and in-memory semantic cache.

Provides:
- **InMemorySemanticCache** — LRU cache with optional embedding-based similarity.
- **CacheRecorder** — observability helper that logs cache metrics to the dashboard.

Example::

    from coreiq.performance.cache import InMemorySemanticCache
    cache = InMemorySemanticCache(max_size=500, similarity_threshold=0.92)
    cache.put(messages, response, tokens_used=320)
    hit = cache.get(messages, trace_id="t-123")
"""
import hashlib
import math
import threading
import time as _time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Optional

from ..store.writer import get_writer


@dataclass
class CacheEntry:
    """A single cached response with optional embedding."""
    response: Any
    key: str
    embedding: Optional[list] = None
    timestamp: float = field(default_factory=lambda: _time.monotonic())
    tokens_used: int = 0
    normalized_text: str = ""


class InMemorySemanticCache:
    """In-memory LRU cache with optional embedding-based similarity.

    With sentence-transformers: uses cosine similarity for semantic matching.
    Without: uses exact normalized string matching only.
    """

    def __init__(self, max_size: int = 1000, similarity_threshold: float = 0.92, ttl_seconds: int = 3600):
        self._max_size = max_size
        self._threshold = similarity_threshold
        self._ttl = ttl_seconds
        self._lock = threading.Lock()
        self._model_lock = threading.Lock()
        self._store: OrderedDict[str, CacheEntry] = OrderedDict()
        self._embeddings: dict[str, list] = {}
        self._model = None
        self._hit_count = 0
        self._miss_count = 0
        self._recorder = CacheRecorder()

    def _get_model(self):
        with self._model_lock:
            if self._model is None:
                try:
                    from sentence_transformers import SentenceTransformer
                    self._model = SentenceTransformer("all-MiniLM-L6-v2")
                except ImportError:
                    self._model = False
            return self._model if self._model is not False else None

    def _normalize_messages(self, messages: list[dict]) -> str:
        parts = []
        for m in messages:
            role = m.get("role", "")
            content = m.get("content", "")
            if isinstance(content, str):
                parts.append(f"{role}:{content.strip().lower()}")
        return "|".join(parts)

    def _make_key(self, messages: list[dict]) -> str:
        normalized = self._normalize_messages(messages)
        return hashlib.sha256(normalized.encode()).hexdigest()

    @staticmethod
    def _cosine_sim(a: list, b: list) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    def _evict_expired(self):
        now = _time.monotonic()
        expired = [k for k, v in self._store.items() if now - v.timestamp > self._ttl]
        for k in expired:
            del self._store[k]
            self._embeddings.pop(k, None)

    def _try_record_hit(self, trace_id: str, similarity: float, saved_tok: int) -> None:
        try:
            self._recorder.record_hit(trace_id=trace_id, similarity=similarity, saved_tok=saved_tok)
        except Exception:
            pass  # best-effort — don't fail cache on DB error

    def _try_record_miss(self, trace_id: str) -> None:
        try:
            self._recorder.record_miss(trace_id=trace_id)
        except Exception:
            pass

    def _try_record_query_recon(self, trace_id: str, original: str, reconstructed: str, similarity: float) -> None:
        try:
            self._recorder.record_query_recon(
                trace_id=trace_id,
                original=original,
                reconstructed=reconstructed,
                similarity=similarity,
            )
        except Exception:
            pass

    def get(self, messages: list[dict], trace_id: Optional[str] = None) -> Optional[CacheEntry]:
        # Compute normalized text and key before acquiring lock
        normalized = self._normalize_messages(messages)
        key = hashlib.sha256(normalized.encode()).hexdigest()

        # Compute embedding outside the lock to avoid holding it during ML inference
        model = self._get_model()
        query_emb = model.encode(normalized).tolist() if model else None

        semantic_hit = False

        with self._lock:
            self._evict_expired()

            # Exact match
            if key in self._store:
                entry = self._store[key]
                self._store.move_to_end(key)
                self._hit_count += 1
                hit_entry = entry
                hit_sim = 1.0
                miss = False
            elif query_emb and self._embeddings:
                # Semantic match
                best_sim = 0.0
                best_key = None
                for k, emb in self._embeddings.items():
                    sim = self._cosine_sim(query_emb, emb)
                    if sim > best_sim:
                        best_sim = sim
                        best_key = k
                if best_key and best_sim >= self._threshold and best_key in self._store:
                    entry = self._store[best_key]
                    self._store.move_to_end(best_key)
                    self._hit_count += 1
                    hit_entry = entry
                    hit_sim = round(best_sim, 4)
                    miss = False
                    semantic_hit = True
                else:
                    self._miss_count += 1
                    hit_entry = None
                    hit_sim = 0.0
                    miss = True
            else:
                self._miss_count += 1
                hit_entry = None
                hit_sim = 0.0
                miss = True

        # Record hit/miss outside the lock — writer is independently thread-safe
        if not miss and hit_entry is not None:
            if trace_id:
                self._try_record_hit(trace_id, hit_sim, hit_entry.tokens_used)
                # On a semantic (non-exact) hit, record the query reconstruction:
                # original = what the user actually sent; reconstructed = what was cached.
                if semantic_hit and hit_entry.normalized_text:
                    self._try_record_query_recon(
                        trace_id=trace_id,
                        original=normalized,
                        reconstructed=hit_entry.normalized_text,
                        similarity=hit_sim,
                    )
            return hit_entry
        else:
            if trace_id:
                self._try_record_miss(trace_id)
            return None

    def put(self, messages: list[dict], response: Any, tokens_used: int = 0) -> None:
        # Compute key and embedding outside the lock to avoid holding it during ML inference
        normalized = self._normalize_messages(messages)
        key = hashlib.sha256(normalized.encode()).hexdigest()
        model = self._get_model()
        embedding = model.encode(normalized).tolist() if model else None

        entry = CacheEntry(response=response, key=key, tokens_used=tokens_used, embedding=embedding, normalized_text=normalized)

        with self._lock:
            if embedding is not None:
                self._embeddings[key] = embedding

            self._store[key] = entry
            self._store.move_to_end(key)

            while len(self._store) > self._max_size:
                oldest_key, _ = self._store.popitem(last=False)
                self._embeddings.pop(oldest_key, None)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()
            self._embeddings.clear()

    @property
    def stats(self) -> dict:
        total = self._hit_count + self._miss_count
        return {
            "size": len(self._store),
            "max_size": self._max_size,
            "hit_count": self._hit_count,
            "miss_count": self._miss_count,
            "hit_rate": round(self._hit_count / total, 4) if total else 0.0,
            "has_embeddings": self._get_model() is not None,
        }


class CacheRecorder:
    """Records cache hit/miss events to the CoreIQ store for dashboard analytics.

    This is an observability helper — it does not implement caching itself.
    Plug it into your own cache layer to track hit rates, token savings,
    and query reconstruction quality.
    """

    def record_hit(self, *, trace_id: str, similarity: float, saved_tok: int, backend: str = "memory") -> None:
        get_writer().insert_cache_event(
            trace_id=trace_id,
            hit=True,
            similarity=similarity,
            saved_tok=saved_tok,
            backend=backend,
        )

    def record_miss(self, *, trace_id: str, similarity: float = 0.0, backend: str = "memory") -> None:
        get_writer().insert_cache_event(
            trace_id=trace_id,
            hit=False,
            similarity=similarity,
            saved_tok=0,
            backend=backend,
        )

    def record_query_recon(self, *, trace_id: str, original: str, reconstructed: str, similarity: float) -> None:
        get_writer().insert_query_recon(
            trace_id=trace_id,
            original=original,
            reconstructed=reconstructed,
            similarity=similarity,
        )


# Backward compat alias
SemanticCache = CacheRecorder

_cache: Optional[CacheRecorder] = None


def get_cache_recorder() -> CacheRecorder:
    global _cache
    if _cache is None:
        _cache = CacheRecorder()
    return _cache


# Backward compat alias
get_semantic_cache = get_cache_recorder


def count_tokens(text: str) -> int:
    """Count tokens using tiktoken cl100k_base encoding.

    Falls back to whitespace word count if tiktoken not installed.
    """
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except ImportError:
        return len(text.split())
