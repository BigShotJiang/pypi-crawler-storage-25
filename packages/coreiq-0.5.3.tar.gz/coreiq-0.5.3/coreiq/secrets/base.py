"""Secrets provider ABC + URI dispatcher.

The default behaviour is to resolve ``env://NAME`` and pass plain values
through unchanged. Vault / KMS / Azure providers are registered lazily
on first use to avoid loading their SDKs unless needed.
"""
from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from typing import Optional
from urllib.parse import urlparse

from coreiq.exceptions import SecretsError

logger = logging.getLogger("coreiq.secrets")


class SecretsProvider(ABC):
    """Resolve a secret by its scheme-specific path."""

    scheme: str

    @abstractmethod
    def fetch(self, path: str) -> str:
        """Return the secret value at ``path``.

        Raises ``SecretsError`` if the path is missing or the provider
        is unreachable.
        """


_REGISTRY: dict[str, SecretsProvider] = {}


def register_provider(provider: SecretsProvider) -> None:
    _REGISTRY[provider.scheme] = provider


def get_provider(scheme: str) -> Optional[SecretsProvider]:
    if scheme in _REGISTRY:
        return _REGISTRY[scheme]
    # Lazy-load known providers.
    try:
        if scheme == "vault":
            from .vault import VaultProvider
            register_provider(VaultProvider())
        elif scheme in ("aws-sm", "aws-kms"):
            from .kms import AwsSecretsManagerProvider, AwsKmsProvider
            if scheme == "aws-sm":
                register_provider(AwsSecretsManagerProvider())
            else:
                register_provider(AwsKmsProvider())
        elif scheme == "azure-kv":
            from .azure_keyvault import AzureKeyVaultProvider
            register_provider(AzureKeyVaultProvider())
    except Exception as exc:
        logger.debug("secrets: failed to load provider for %r: %s", scheme, exc)
        return None
    return _REGISTRY.get(scheme)


class _EnvProvider(SecretsProvider):
    scheme = "env"

    def fetch(self, path: str) -> str:
        val = os.environ.get(path)
        if val is None:
            raise SecretsError(f"env var {path!r} not set")
        return val


register_provider(_EnvProvider())


def resolve(value: str | None) -> str | None:
    """Resolve a secret URI. Plain values are returned unchanged.

    Recognized schemes: env, vault, aws-sm, aws-kms, azure-kv.
    """
    if value is None or not value:
        return value
    parsed = urlparse(value)
    scheme = parsed.scheme
    if not scheme or scheme not in ("env", "vault", "aws-sm", "aws-kms", "azure-kv"):
        return value
    provider = get_provider(scheme)
    if provider is None:
        raise SecretsError(
            f"secrets provider {scheme!r} not available — install the optional "
            f"dependency or fall back to env vars"
        )
    # Strip the scheme prefix; leave the remainder for the provider.
    path = value[len(scheme) + 3 :]  # skip "<scheme>://"
    return provider.fetch(path)
