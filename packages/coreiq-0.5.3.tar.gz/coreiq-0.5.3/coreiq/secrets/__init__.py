"""Secrets resolution layer.

Replaces env-var-only secret handling. A secret reference uses the URI
form ``<scheme>://<path>`` where scheme is one of ``env``, ``vault``,
``aws-sm`` (Secrets Manager), ``aws-kms`` (decrypt), ``azure-kv``.

Plain values without a recognized scheme are returned as-is for
backwards compatibility.

Example::

    from coreiq.secrets import resolve

    api_key = resolve(os.environ["COREIQ_OPENAI_KEY"])
    # "vault://kv/data/coreiq#openai_key" → fetched from Vault
    # "aws-sm://prod/coreiq/openai" → fetched from Secrets Manager
    # "sk-abc" → returned as-is
"""
from __future__ import annotations

from .base import SecretsProvider, get_provider, resolve, register_provider

__all__ = ["SecretsProvider", "get_provider", "resolve", "register_provider"]
