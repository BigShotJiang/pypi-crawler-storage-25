"""HashiCorp Vault secrets provider.

Path form: ``vault://<mount>/<path>#<key>``

Examples::

    vault://kv/data/coreiq/prod#openai_api_key
    vault://secret/data/coreiq#anthropic_api_key

Auth is taken from ``VAULT_ADDR`` + ``VAULT_TOKEN``. For Kubernetes /
AppRole auth, set those env vars before the request reaches CoreIQ.
"""
from __future__ import annotations

import os
from typing import Any

from coreiq.exceptions import SecretsError

from .base import SecretsProvider


class VaultProvider(SecretsProvider):
    scheme = "vault"

    def __init__(self) -> None:
        self._addr = os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200")
        self._token = os.environ.get("VAULT_TOKEN", "")
        self._namespace = os.environ.get("VAULT_NAMESPACE")

    def fetch(self, path: str) -> str:
        if "#" not in path:
            raise SecretsError(
                f"vault path must include a key fragment: 'mount/path#key', got {path!r}"
            )
        secret_path, key = path.rsplit("#", 1)
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise SecretsError("httpx is required for Vault secrets") from exc

        headers = {"X-Vault-Token": self._token}
        if self._namespace:
            headers["X-Vault-Namespace"] = self._namespace
        url = f"{self._addr.rstrip('/')}/v1/{secret_path.lstrip('/')}"
        try:
            with httpx.Client(timeout=5.0) as client:
                resp = client.get(url, headers=headers)
                resp.raise_for_status()
                payload: dict[str, Any] = resp.json()
        except Exception as exc:
            raise SecretsError(f"vault fetch failed for {path!r}: {exc}") from exc
        # KV v2 wraps under data.data; KV v1 puts it under data.
        data = payload.get("data") or {}
        if isinstance(data.get("data"), dict):
            data = data["data"]
        if key not in data:
            raise SecretsError(f"vault key {key!r} not found at {secret_path!r}")
        value = data[key]
        return str(value)
