"""AWS Secrets Manager + KMS providers.

- ``aws-sm://<secret-id>[#<json-key>]`` — fetch from Secrets Manager. If
  the secret is JSON, ``#key`` selects a field.
- ``aws-kms://<base64-ciphertext>`` — Decrypt a KMS ciphertext blob.

Auth uses the standard boto3 default credential chain.
"""
from __future__ import annotations

import base64
import json
import logging
from typing import Any

from coreiq.exceptions import SecretsError

from .base import SecretsProvider

logger = logging.getLogger("coreiq.secrets.kms")


def _client(service: str) -> Any:
    try:
        import boto3
    except ImportError as exc:
        raise SecretsError(
            f"boto3 is required for {service!r} secrets — install coreiq[aws]"
        ) from exc
    return boto3.client(service)


class AwsSecretsManagerProvider(SecretsProvider):
    scheme = "aws-sm"

    def fetch(self, path: str) -> str:
        secret_id, _, key = path.partition("#")
        try:
            client = _client("secretsmanager")
            resp = client.get_secret_value(SecretId=secret_id)
        except Exception as exc:
            raise SecretsError(f"secrets-manager fetch failed for {secret_id!r}: {exc}") from exc
        value = resp.get("SecretString") or ""
        if key:
            try:
                parsed = json.loads(value)
            except json.JSONDecodeError as exc:
                raise SecretsError(
                    f"secret {secret_id!r} is not JSON; cannot extract key {key!r}"
                ) from exc
            if key not in parsed:
                raise SecretsError(f"key {key!r} not in secret {secret_id!r}")
            value = parsed[key]
        return str(value)


class AwsKmsProvider(SecretsProvider):
    scheme = "aws-kms"

    def fetch(self, path: str) -> str:
        try:
            ciphertext = base64.b64decode(path)
        except Exception as exc:
            raise SecretsError(f"aws-kms path is not valid base64: {exc}") from exc
        try:
            client = _client("kms")
            resp = client.decrypt(CiphertextBlob=ciphertext)
        except Exception as exc:
            raise SecretsError(f"kms decrypt failed: {exc}") from exc
        return resp["Plaintext"].decode("utf-8")
