"""Azure Key Vault secrets provider.

Path form: ``azure-kv://<vault-name>/<secret-name>``

Auth uses ``DefaultAzureCredential`` (env, managed identity, CLI).
"""
from __future__ import annotations

from coreiq.exceptions import SecretsError

from .base import SecretsProvider


class AzureKeyVaultProvider(SecretsProvider):
    scheme = "azure-kv"

    def fetch(self, path: str) -> str:
        vault, _, name = path.partition("/")
        if not vault or not name:
            raise SecretsError(
                f"azure-kv path must be 'vault/secret', got {path!r}"
            )
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
        except ImportError as exc:
            raise SecretsError(
                "azure-keyvault-secrets is required — install coreiq[azure]"
            ) from exc
        try:
            url = f"https://{vault}.vault.azure.net"
            client = SecretClient(vault_url=url, credential=DefaultAzureCredential())
            secret = client.get_secret(name)
        except Exception as exc:
            raise SecretsError(f"keyvault fetch failed for {path!r}: {exc}") from exc
        return str(secret.value or "")
