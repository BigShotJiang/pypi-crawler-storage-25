"""Shadow mode — run a secondary model in parallel to compare outputs."""
import asyncio
import time
from dataclasses import dataclass
from typing import Any, Callable, Coroutine


@dataclass
class ShadowResult:
    primary_output: Any
    shadow_output: Any
    primary_latency_ms: int
    shadow_latency_ms: int
    diverged: bool
    similarity: float = 0.0


def _text_similarity(a: str, b: str) -> float:
    """Simple character-level Jaccard similarity for quick divergence check."""
    if not a and not b:
        return 1.0
    set_a = set(a.lower().split())
    set_b = set(b.lower().split())
    if not set_a and not set_b:
        return 1.0
    intersection = set_a & set_b
    union = set_a | set_b
    return len(intersection) / len(union)


async def shadow_call(
    primary_fn: Callable[..., Coroutine],
    shadow_fn: Callable[..., Coroutine],
    *args,
    divergence_threshold: float = 0.5,
    **kwargs,
) -> ShadowResult:
    """
    Run primary and shadow callables concurrently.
    Returns ShadowResult with both outputs and latencies.
    Shadow errors are swallowed — only primary errors propagate.
    """
    async def _run_primary():
        start = time.monotonic()
        result = await primary_fn(*args, **kwargs)
        return result, int((time.monotonic() - start) * 1000)

    async def _run_shadow():
        start = time.monotonic()
        try:
            result = await shadow_fn(*args, **kwargs)
            return result, int((time.monotonic() - start) * 1000)
        except Exception:
            return None, int((time.monotonic() - start) * 1000)

    (primary_output, primary_ms), (shadow_output, shadow_ms) = await asyncio.gather(
        _run_primary(), _run_shadow()
    )

    sim = 0.0
    if isinstance(primary_output, str) and isinstance(shadow_output, str):
        sim = _text_similarity(primary_output, shadow_output)

    diverged = sim < divergence_threshold

    return ShadowResult(
        primary_output=primary_output,
        shadow_output=shadow_output,
        primary_latency_ms=primary_ms,
        shadow_latency_ms=shadow_ms,
        diverged=diverged,
        similarity=round(sim, 4),
    )
