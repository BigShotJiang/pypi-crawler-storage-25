"""Anthropic adapter — wraps anthropic.Anthropic with CoreIQ tracing."""
import time
import uuid
from typing import Any, Optional

from ...store.writer import get_writer


def create_message(
    client,
    *,
    model: str,
    messages: list[dict],
    max_tokens: int = 1024,
    trace_id: Optional[str] = None,
    budget=None,
    **kwargs,
) -> Any:
    """
    Call client.messages.create() and record a trace.
    client: anthropic.Anthropic instance (sync version).
    Returns the message object unchanged.
    """
    t_id = trace_id or str(uuid.uuid4())
    start = time.monotonic()
    try:
        response = client.messages.create(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        finish = getattr(response, "stop_reason", "end_turn") or "end_turn"
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="anthropic",
            input_tok=usage.input_tokens if usage else 0,
            output_tok=usage.output_tokens if usage else 0,
            latency_ms=latency_ms,
            finish_reason=finish,
        )
        if budget and usage:
            try:
                budget.record(tokens=usage.input_tokens + usage.output_tokens)
            except Exception:
                pass  # don't fail the call if budget tracking fails
        return response
    except Exception:
        latency_ms = int((time.monotonic() - start) * 1000)
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="anthropic",
            input_tok=0,
            output_tok=0,
            latency_ms=latency_ms,
            finish_reason="error",
        )
        raise


async def async_create_message(
    client,
    *,
    model: str,
    messages: list[dict],
    max_tokens: int = 1024,
    trace_id: Optional[str] = None,
    **kwargs,
) -> Any:
    """Async version — call client.messages.create() and record a trace."""
    t_id = trace_id or str(uuid.uuid4())
    start = time.monotonic()
    try:
        response = await client.messages.create(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        finish = getattr(response, "stop_reason", "end_turn") or "end_turn"
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="anthropic",
            input_tok=usage.input_tokens if usage else 0,
            output_tok=usage.output_tokens if usage else 0,
            latency_ms=latency_ms,
            finish_reason=finish,
        )
        return response
    except Exception:
        latency_ms = int((time.monotonic() - start) * 1000)
        get_writer().insert_trace(
            id=t_id,
            model=model,
            provider="anthropic",
            input_tok=0,
            output_tok=0,
            latency_ms=latency_ms,
            finish_reason="error",
        )
        raise
