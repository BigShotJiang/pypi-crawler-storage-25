"""Model selector — choose the best model for a task based on cost/capability criteria."""
from dataclasses import dataclass
from typing import Optional

from .registry import ModelSpec, list_models


@dataclass
class SelectionCriteria:
    max_cost_per_1k_input: Optional[float] = None
    max_cost_per_1k_output: Optional[float] = None
    min_context_window: Optional[int] = None
    requires_vision: bool = False
    requires_tools: bool = False
    preferred_provider: Optional[str] = None
    preferred_tags: list[str] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.preferred_tags is None:
            self.preferred_tags = []


def select_model(criteria: SelectionCriteria) -> Optional[ModelSpec]:
    """Return best-fit model or None if no model meets criteria."""
    candidates = list_models(provider=criteria.preferred_provider)

    if criteria.min_context_window:
        candidates = [m for m in candidates if m.context_window >= criteria.min_context_window]
    if criteria.requires_vision:
        candidates = [m for m in candidates if m.supports_vision]
    if criteria.requires_tools:
        candidates = [m for m in candidates if m.supports_tools]
    if criteria.max_cost_per_1k_input is not None:
        candidates = [m for m in candidates if m.input_cost_per_1k > 0 and m.input_cost_per_1k <= criteria.max_cost_per_1k_input]
    if criteria.max_cost_per_1k_output is not None:
        candidates = [m for m in candidates if m.output_cost_per_1k <= criteria.max_cost_per_1k_output]

    if not candidates:
        return None

    # Score: tag matches first, then cheapest by combined cost
    def score(m: ModelSpec) -> tuple:
        tag_hits = sum(1 for t in criteria.preferred_tags if t in m.tags)
        cost = m.input_cost_per_1k + m.output_cost_per_1k
        return (-tag_hits, cost)  # more tag hits = better (negated), lower cost = better

    return sorted(candidates, key=score)[0]
