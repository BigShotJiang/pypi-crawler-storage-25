"""Variant management — prompt + model combinations per function."""
import json
import random
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from ..store.db import get_shared_connection


class VariantType(str, Enum):
    chat_completion = "chat_completion"
    dicl = "dicl"
    best_of_n = "best_of_n"
    mixture_of_n = "mixture_of_n"
    chain_of_thought = "chain_of_thought"


@dataclass
class VariantDef:
    id: str
    function_id: str
    name: str
    type: VariantType
    model: Optional[str] = None
    system_template: Optional[str] = None
    user_template: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    weight: float = 1.0
    active: bool = True
    created_at: str = ""

    @property
    def inner_variant_names(self) -> List[str]:
        """Return the list of inner variant names for composite (best/mixture-of-N) variants."""
        if self.config:
            return self.config.get("inner_variants", [])
        return []

    @property
    def n(self) -> int:
        """Return the number of candidates to generate for composite variants."""
        if self.config:
            return self.config.get("n", 3)
        return 3

    @property
    def judge_model(self) -> str:
        """Return the judge model for best-of-N selection."""
        if self.config:
            import os
            return self.config.get("judge_model", os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b"))
        import os
        return os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")

    @property
    def fuser_model(self) -> str:
        """Return the fuser model for mixture-of-N synthesis."""
        if self.config:
            import os
            return self.config.get("fuser_model", os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b"))
        import os
        return os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class VariantManager:
    """DB-backed variant management with in-memory cache. Thread-safe.

    Variants define the HOW — a specific model + prompt template combination
    for a function. Multiple variants enable A/B testing and experimentation.
    """

    def __init__(self):
        self._lock = threading.Lock()
        # function_id -> {variant_name -> VariantDef}
        self._cache: Dict[str, Dict[str, VariantDef]] = {}
        self._id_cache: Dict[str, VariantDef] = {}  # variant_id -> VariantDef
        self._loaded = False

    def _conn(self):
        return get_shared_connection()

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            self._load_all()
            self._loaded = True

    def _load_all(self) -> None:
        conn = self._conn()
        try:
            rows = conn.execute("SELECT * FROM variants").fetchall()
        except Exception:
            rows = []
        for row in rows:
            vd = self._row_to_def(row)
            self._cache.setdefault(vd.function_id, {})[vd.name] = vd
            self._id_cache[vd.id] = vd

    @staticmethod
    def _row_to_def(row) -> VariantDef:
        config = None
        if row["config_json"]:
            config = json.loads(row["config_json"])
        return VariantDef(
            id=row["id"],
            function_id=row["function_id"],
            name=row["name"],
            type=VariantType(row["type"]),
            model=row["model"],
            system_template=row["system_template"],
            user_template=row["user_template"],
            config=config,
            weight=float(row["weight"]),
            active=bool(row["active"]),
            created_at=row["created_at"] or "",
        )

    def create(
        self,
        function_id: str,
        name: str,
        type: VariantType,
        model: Optional[str] = None,
        system_template: Optional[str] = None,
        user_template: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        weight: float = 1.0,
        active: bool = True,
    ) -> VariantDef:
        """Create a new variant for a function. Raises if (function_id, name) exists."""
        self._ensure_loaded()
        with self._lock:
            fn_variants = self._cache.get(function_id, {})
            if name in fn_variants:
                from ..exceptions import ValidationError
                raise ValidationError(
                    f"Variant '{name}' already exists for function '{function_id}'"
                )
            vid = str(uuid.uuid4())
            now = _now()
            vd = VariantDef(
                id=vid, function_id=function_id, name=name, type=type,
                model=model, system_template=system_template,
                user_template=user_template, config=config,
                weight=weight, active=active, created_at=now,
            )
            conn = self._conn()
            conn.execute(
                "INSERT INTO variants(id, function_id, name, type, model, "
                "system_template, user_template, config_json, weight, active, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (vd.id, vd.function_id, vd.name, vd.type.value, vd.model,
                 vd.system_template, vd.user_template,
                 json.dumps(vd.config) if vd.config else None,
                 vd.weight, int(vd.active), vd.created_at),
            )
            conn.commit()
            self._cache.setdefault(function_id, {})[name] = vd
            self._id_cache[vd.id] = vd
            return vd

    def get(self, function_id: str, name: str) -> Optional[VariantDef]:
        """Get a variant by function_id and name."""
        self._ensure_loaded()
        return self._cache.get(function_id, {}).get(name)

    def get_by_id(self, variant_id: str) -> Optional[VariantDef]:
        """Get a variant by ID."""
        self._ensure_loaded()
        return self._id_cache.get(variant_id)

    def list(self, function_id: str, active_only: bool = False) -> List[VariantDef]:
        """List all variants for a function."""
        self._ensure_loaded()
        variants = list(self._cache.get(function_id, {}).values())
        if active_only:
            variants = [v for v in variants if v.active]
        return variants

    def update(
        self,
        variant_id: str,
        model: Optional[str] = ...,  # type: ignore[assignment]
        system_template: Optional[str] = ...,  # type: ignore[assignment]
        user_template: Optional[str] = ...,  # type: ignore[assignment]
        config: Optional[Dict[str, Any]] = ...,  # type: ignore[assignment]
        weight: Optional[float] = None,
        active: Optional[bool] = None,
    ) -> Optional[VariantDef]:
        """Update a variant. Pass sentinel (...) to leave unchanged, None to clear."""
        self._ensure_loaded()
        with self._lock:
            vd = self._id_cache.get(variant_id)
            if vd is None:
                return None
            conn = self._conn()
            updates = []
            params: list = []
            if model is not ...:
                vd.model = model
                updates.append("model = ?")
                params.append(model)
            if system_template is not ...:
                vd.system_template = system_template
                updates.append("system_template = ?")
                params.append(system_template)
            if user_template is not ...:
                vd.user_template = user_template
                updates.append("user_template = ?")
                params.append(user_template)
            if config is not ...:
                vd.config = config
                updates.append("config_json = ?")
                params.append(json.dumps(config) if config else None)
            if weight is not None:
                vd.weight = weight
                updates.append("weight = ?")
                params.append(weight)
            if active is not None:
                vd.active = active
                updates.append("active = ?")
                params.append(int(active))
            if updates:
                params.append(variant_id)
                conn.execute(
                    f"UPDATE variants SET {', '.join(updates)} WHERE id = ?",
                    params,
                )
                conn.commit()
            return vd

    def delete(self, variant_id: str) -> bool:
        """Delete a variant by ID. Returns True if deleted."""
        self._ensure_loaded()
        with self._lock:
            vd = self._id_cache.get(variant_id)
            if vd is None:
                return False
            conn = self._conn()
            conn.execute("DELETE FROM variants WHERE id = ?", (variant_id,))
            conn.commit()
            fn_variants = self._cache.get(vd.function_id, {})
            fn_variants.pop(vd.name, None)
            del self._id_cache[variant_id]
            return True

    def select_variant(
        self,
        function_id: str,
        experiment_manager: Optional[Any] = None,
    ) -> Optional[VariantDef]:
        """Select a variant for a function call.

        If an experiment_manager is provided and there is an active experiment
        for this function, delegates selection to the experiment. Otherwise,
        selects using static weight-based random sampling among active variants.
        """
        self._ensure_loaded()

        # Check for active experiment delegation
        if experiment_manager is not None:
            selected = experiment_manager.select_variant(function_id)
            if selected is not None:
                return self.get_by_id(selected)

        # Fall back to static weight-based selection
        active = self.list(function_id, active_only=True)
        if not active:
            return None
        if len(active) == 1:
            return active[0]

        weights = [v.weight for v in active]
        total = sum(weights)
        if total <= 0:
            return random.choice(active)

        r = random.random() * total
        cumulative = 0.0
        for v in active:
            cumulative += v.weight
            if r <= cumulative:
                return v
        return active[-1]

    def invalidate_cache(self) -> None:
        """Force reload from DB on next access."""
        with self._lock:
            self._cache.clear()
            self._id_cache.clear()
            self._loaded = False
