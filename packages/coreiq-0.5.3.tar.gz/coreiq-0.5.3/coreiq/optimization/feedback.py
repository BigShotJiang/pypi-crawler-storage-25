"""MetricRecorder — enhanced feedback pipeline that closes the optimization loop.

Records metric values for inferences/episodes, auto-triggers bandit updates
for active experiments, and feeds high-quality demonstrations to the DICL store.
"""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from typing import Any, List, Optional

from ..store.db import get_shared_connection

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MetricRecorder:
    """Enhanced feedback recorder that auto-triggers bandit + DICL updates.

    This is the primary feedback entry point for the optimization engine.
    When a metric value is recorded:

    1. The value is persisted to the ``metric_values`` table.
    2. If the inference belongs to a function with an active experiment,
       the reward is forwarded to the experiment's bandit.
    3. For demonstration feedback, the DICL store is updated with the
       inference's input/output as a high-quality example.
    """

    def __init__(
        self,
        metric_registry: Any = None,
        experiment_manager: Any = None,
        dicl: Any = None,
        episode_manager: Any = None,
    ) -> None:
        self._lock = threading.Lock()
        self._metric_registry = metric_registry
        self._experiment_manager = experiment_manager
        self._dicl = dicl
        self._episode_manager = episode_manager

    def _conn(self):
        return get_shared_connection()

    def _get_metric_registry(self):
        if self._metric_registry is None:
            from .metrics import MetricRegistry
            self._metric_registry = MetricRegistry()
        return self._metric_registry

    def _get_experiment_manager(self):
        if self._experiment_manager is None:
            from .experiment import ExperimentManager
            self._experiment_manager = ExperimentManager()
        return self._experiment_manager

    def _get_dicl(self):
        return self._dicl

    def _get_episode_manager(self):
        if self._episode_manager is None:
            try:
                from .episode import EpisodeManager
                self._episode_manager = EpisodeManager()
            except Exception:
                pass
        return self._episode_manager

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def record(
        self,
        metric_name: str,
        *,
        inference_id: Optional[str] = None,
        episode_id: Optional[str] = None,
        value: Optional[float] = None,
        comment: Optional[str] = None,
        demonstration: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> dict:
        """Record a metric value and trigger downstream updates.

        Parameters
        ----------
        metric_name:
            Name of a registered metric definition.
        inference_id:
            ID of the inference this metric applies to.
        episode_id:
            ID of the episode this metric applies to.
        value:
            Numeric value (for boolean/float metrics).
        comment:
            Free-text comment (for comment metrics).
        demonstration:
            Ideal output text (for demonstration metrics).
        user_id:
            Who provided the feedback.

        Returns
        -------
        dict with ``id``, ``metric_name``, ``inference_id``, ``episode_id``, ``ts``.
        """
        registry = self._get_metric_registry()

        # Delegate to MetricRegistry.record_value for validation + persistence
        mv = registry.record_value(
            metric_name=metric_name,
            inference_id=inference_id,
            episode_id=episode_id,
            value=value,
            comment=comment,
            demonstration=demonstration,
            user_id=user_id,
        )

        # Auto-trigger bandit update
        if inference_id is not None:
            self._trigger_bandit_update(inference_id, metric_name, value, comment, demonstration)

        # Episode-level credit distribution: when the metric is at episode
        # level AND an episode_id is provided, distribute reward to turns.
        if episode_id is not None:
            self._trigger_episode_credit(episode_id, metric_name, value, comment, demonstration)

        # Auto-feed DICL for demonstration feedback
        if demonstration is not None and inference_id is not None:
            self._trigger_dicl_update(inference_id)

        return {
            "id": mv.id,
            "metric_name": mv.metric_name,
            "inference_id": mv.inference_id,
            "episode_id": mv.episode_id,
            "ts": mv.ts,
        }

    def record_boolean(
        self,
        metric_name: str,
        inference_id: str,
        value: bool,
        *,
        user_id: Optional[str] = None,
    ) -> dict:
        """Convenience: record a boolean metric value."""
        return self.record(
            metric_name,
            inference_id=inference_id,
            value=1.0 if value else 0.0,
            user_id=user_id,
        )

    def record_float(
        self,
        metric_name: str,
        inference_id: str,
        value: float,
        *,
        user_id: Optional[str] = None,
    ) -> dict:
        """Convenience: record a float metric value."""
        return self.record(
            metric_name,
            inference_id=inference_id,
            value=value,
            user_id=user_id,
        )

    def record_demonstration(
        self,
        metric_name: str,
        inference_id: str,
        demonstration: str,
        *,
        user_id: Optional[str] = None,
    ) -> dict:
        """Convenience: record a demonstration (ideal output) for an inference."""
        return self.record(
            metric_name,
            inference_id=inference_id,
            demonstration=demonstration,
            user_id=user_id,
        )

    def get_for_inference(self, inference_id: str) -> List[dict]:
        """Get all metric values for a specific inference."""
        conn = self._conn()
        rows = conn.execute(
            "SELECT * FROM metric_values WHERE inference_id = ? ORDER BY ts DESC",
            (inference_id,),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def get_for_episode(self, episode_id: str) -> List[dict]:
        """Get all metric values for a specific episode."""
        conn = self._conn()
        rows = conn.execute(
            "SELECT * FROM metric_values WHERE episode_id = ? ORDER BY ts DESC",
            (episode_id,),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Internal: bandit update
    # ------------------------------------------------------------------

    def _trigger_bandit_update(
        self,
        inference_id: str,
        metric_name: str,
        value: Optional[float],
        comment: Optional[str],
        demonstration: Optional[str],
    ) -> None:
        """Look up inference -> function_id -> active experiment -> record_reward."""
        try:
            conn = self._conn()
            row = conn.execute(
                "SELECT function_id, variant_id FROM inferences WHERE id = ?",
                (inference_id,),
            ).fetchone()
            if row is None:
                logger.debug("No inference found for id %s, skipping bandit update", inference_id)
                return

            function_id = row["function_id"]
            variant_id = row["variant_id"]
            if not function_id or not variant_id:
                return

            experiment_mgr = self._get_experiment_manager()
            exp = experiment_mgr.get_active_for_function(function_id)
            if exp is None:
                return

            # Only update if this metric is the experiment's tracked metric
            if exp.metric_name and exp.metric_name != metric_name:
                return

            # Compute reward from the metric definition
            registry = self._get_metric_registry()
            metric_def = registry.get(metric_name)
            if metric_def is None:
                return

            # Determine the raw value to normalize
            if value is not None:
                raw_value = value
            elif comment is not None:
                raw_value = 1.0  # presence = positive signal
            elif demonstration is not None:
                raw_value = 1.0  # demonstration = positive signal
            else:
                return

            reward = metric_def.normalize_to_reward(raw_value)
            experiment_mgr.record_reward(function_id, variant_id, reward)

            logger.debug(
                "Bandit update: function=%s variant=%s metric=%s reward=%.3f",
                function_id, variant_id, metric_name, reward,
            )
        except Exception as exc:
            logger.warning("Bandit update failed for inference %s: %s", inference_id, exc)

    # ------------------------------------------------------------------
    # Internal: episode credit distribution
    # ------------------------------------------------------------------

    def _trigger_episode_credit(
        self,
        episode_id: str,
        metric_name: str,
        value: Optional[float],
        comment: Optional[str],
        demonstration: Optional[str],
    ) -> None:
        """Distribute episode-level reward to individual turns via credit assignment."""
        try:
            registry = self._get_metric_registry()
            metric_def = registry.get(metric_name)
            if metric_def is None:
                return

            # Only distribute for episode-level metrics
            from .metrics import MetricLevel
            if metric_def.level != MetricLevel.episode:
                return

            # Compute reward from the metric definition
            if value is not None:
                raw_value = value
            elif comment is not None:
                raw_value = 1.0
            elif demonstration is not None:
                raw_value = 1.0
            else:
                return

            reward = metric_def.normalize_to_reward(raw_value)

            episode_mgr = self._get_episode_manager()
            if episode_mgr is None:
                return

            assignments = episode_mgr.distribute_episode_reward(
                episode_id, metric_name, reward,
            )
            if not assignments:
                return

            # Feed each assignment into the experiment manager's bandit
            experiment_mgr = self._get_experiment_manager()
            for variant_id, function_id, credit in assignments:
                if variant_id and function_id:
                    experiment_mgr.record_reward(function_id, variant_id, credit)

            logger.debug(
                "Episode credit distributed: episode=%s metric=%s assignments=%d",
                episode_id, metric_name, len(assignments),
            )
        except Exception as exc:
            logger.warning(
                "Episode credit distribution failed for episode %s: %s",
                episode_id, exc,
            )

    # ------------------------------------------------------------------
    # Internal: DICL update
    # ------------------------------------------------------------------

    def _trigger_dicl_update(self, inference_id: str) -> None:
        """Feed the DICL store with a high-quality inference after demonstration feedback."""
        dicl = self._get_dicl()
        if dicl is None:
            logger.debug("No DICL engine configured, skipping DICL update")
            return

        try:
            example_id = dicl.add_from_inference(
                inference_id,
                min_quality=0.0,  # demonstrations are always high quality
            )
            if example_id:
                logger.debug("DICL example added from inference %s: %s", inference_id, example_id)
        except Exception as exc:
            logger.warning("DICL update failed for inference %s: %s", inference_id, exc)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_dict(row) -> dict:
        return {
            "id": row["id"],
            "inference_id": row["inference_id"],
            "episode_id": row["episode_id"],
            "metric_name": row["metric_name"],
            "value": row["value"],
            "comment": row["comment"],
            "demonstration": row["demonstration"],
            "ts": row["ts"],
            "user_id": row["user_id"],
        }
