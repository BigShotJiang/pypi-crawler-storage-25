"""Jinja2 template engine for prompt rendering.

Provides:
- **TemplateEngine** — renders prompt variants using Jinja2, producing
  ``RenderedInput`` objects that carry both the original application data
  (``stored_input``) and the final messages ready for a provider.
- **RenderedInput** — immutable container for rendered prompts.

Example::

    engine = TemplateEngine()
    variant = {
        "system_template": "You are a {{role}}.",
        "user_template": "Summarise: {{text}}",
    }
    rendered = engine.render_variant(variant, {"role": "editor", "text": "Hello world"})
    print(rendered.messages)
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Sequence

import jinja2
import jinja2.sandbox

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# RenderedInput
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RenderedInput:
    """Container for a rendered prompt.

    Attributes
    ----------
    stored_input:
        The original application data supplied by the caller.  Kept for DICL
        embedding, fine-tune dataset generation, and later re-rendering.
    messages:
        Fully assembled messages list ready to send to a provider.
    system_prompt:
        Rendered system-level text (``None`` if the variant has no system
        template).
    user_prompt:
        Rendered user-level text (``None`` if the variant has no user
        template).
    """

    stored_input: dict[str, Any]
    messages: list[dict[str, Any]] = field(default_factory=list)
    system_prompt: Optional[str] = None
    user_prompt: Optional[str] = None


# ---------------------------------------------------------------------------
# TemplateEngine
# ---------------------------------------------------------------------------

class TemplateEngine:
    """Jinja2-based prompt renderer with custom filters.

    The engine operates in *strict* mode — any undefined variable in a
    template raises immediately rather than silently producing an empty
    string.

    Custom filters available in templates:

    - ``|truncate(n)`` — truncate text to *n* characters with ``…`` suffix
    - ``|json`` — serialise a value to a JSON string
    - ``|upper`` — uppercase
    - ``|lower`` — lowercase
    """

    def __init__(self, *, template_dirs: Sequence[str | Path] | None = None) -> None:
        loaders: list[jinja2.BaseLoader] = []
        if template_dirs:
            for d in template_dirs:
                loaders.append(jinja2.FileSystemLoader(str(d)))

        # Always include an in-memory loader for inline templates (rendered
        # via ``from_string``).  FileSystemLoader is only used when a variant
        # references a path.
        if loaders:
            loader: jinja2.BaseLoader = jinja2.ChoiceLoader(loaders)
        else:
            loader = jinja2.BaseLoader()

        self._env = jinja2.sandbox.SandboxedEnvironment(
            loader=loader,
            undefined=jinja2.StrictUndefined,
            autoescape=False,
            keep_trailing_newline=True,
        )

        # Register custom filters
        self._env.filters["truncate_chars"] = self._filter_truncate
        self._env.filters["json"] = self._filter_json
        # upper / lower are built into Jinja2 already, but we register
        # explicit aliases for clarity.
        self._env.filters["upper"] = self._filter_upper
        self._env.filters["lower"] = self._filter_lower

    # ----- public API --------------------------------------------------------

    def render_variant(
        self,
        variant: dict[str, Any],
        input_data: dict[str, Any],
        *,
        dicl_messages: list[dict[str, Any]] | None = None,
    ) -> RenderedInput:
        """Render a variant's templates against *input_data*.

        Parameters
        ----------
        variant:
            Must contain at least one of ``system_template`` or
            ``user_template``.  Templates may be inline Jinja2 strings *or*
            file paths (resolved via the configured *template_dirs*).
        input_data:
            Application-level data to inject into templates.
        dicl_messages:
            Optional DICL few-shot examples (alternating user/assistant pairs)
            to insert between the system and user messages.

        Returns
        -------
        RenderedInput
        """
        system_prompt: Optional[str] = None
        user_prompt: Optional[str] = None

        system_tpl = variant.get("system_template")
        user_tpl = variant.get("user_template")

        if system_tpl:
            system_prompt = self._render_template(system_tpl, input_data)

        if user_tpl:
            user_prompt = self._render_template(user_tpl, input_data)

        messages = self._build_messages(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            dicl_messages=dicl_messages,
        )

        return RenderedInput(
            stored_input=dict(input_data),
            messages=messages,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )

    def render_string(self, template_str: str, context: dict[str, Any]) -> str:
        """Render an inline Jinja2 template string with *context*."""
        tpl = self._env.from_string(template_str)
        return tpl.render(**context)

    # ----- internal ----------------------------------------------------------

    def _render_template(self, template_ref: str, context: dict[str, Any]) -> str:
        """Render either an inline template or a file-based template.

        Heuristic: if *template_ref* contains ``{{`` or ``{%`` it is treated
        as an inline template.  Otherwise it is treated as a file path.
        """
        if "{{" in template_ref or "{%" in template_ref:
            return self.render_string(template_ref, context)

        # File-based template
        try:
            tpl = self._env.get_template(template_ref)
            return tpl.render(**context)
        except jinja2.TemplateNotFound:
            # Try as an absolute / relative path outside the loader
            path = Path(template_ref)
            if path.is_file():
                raw = path.read_text(encoding="utf-8")
                return self.render_string(raw, context)
            raise

    @staticmethod
    def _build_messages(
        *,
        system_prompt: Optional[str],
        user_prompt: Optional[str],
        dicl_messages: list[dict[str, Any]] | None,
    ) -> list[dict[str, Any]]:
        """Assemble the final messages list.

        Order: system → DICL examples → user.
        """
        messages: list[dict[str, Any]] = []

        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        if dicl_messages:
            messages.extend(dicl_messages)

        if user_prompt:
            messages.append({"role": "user", "content": user_prompt})

        return messages

    # ----- custom Jinja2 filters --------------------------------------------

    @staticmethod
    def _filter_truncate(value: str, length: int = 200) -> str:
        """Truncate *value* to *length* characters, appending ``…`` if cut."""
        s = str(value)
        if len(s) <= length:
            return s
        return s[:length] + "…"

    @staticmethod
    def _filter_json(value: Any) -> str:
        """Serialise *value* to a compact JSON string."""
        return json.dumps(value, ensure_ascii=False, default=str)

    @staticmethod
    def _filter_upper(value: str) -> str:
        return str(value).upper()

    @staticmethod
    def _filter_lower(value: str) -> str:
        return str(value).lower()
