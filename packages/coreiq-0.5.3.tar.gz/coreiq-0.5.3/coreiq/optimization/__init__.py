"""CoreIQ optimization engine — functions, variants, experiments, bandits, templates, DICL."""
from __future__ import annotations

from .bandit import BanditBase, TrackAndStopBandit, ThompsonBandit
from .templates import TemplateEngine, RenderedInput
from .dicl import EmbeddingDICL, DICLExample
from .function import FunctionRegistry, FunctionDef, FunctionType
from .variant import VariantManager, VariantDef, VariantType
from .experiment import (
    ExperimentManager,
    Experiment,
    ExperimentType,
    ExperimentStatus,
    ExperimentAlgorithm,
    ExperimentConfig,
)
from .metrics import MetricRegistry, MetricDef, MetricValue, MetricType, MetricLevel, MetricOptimize
from .feedback import MetricRecorder

__all__ = [
    "BanditBase", "TrackAndStopBandit", "ThompsonBandit",
    "TemplateEngine", "RenderedInput",
    "EmbeddingDICL", "DICLExample",
    "FunctionRegistry", "FunctionDef", "FunctionType",
    "VariantManager", "VariantDef", "VariantType",
    "ExperimentManager", "Experiment", "ExperimentType",
    "ExperimentStatus", "ExperimentAlgorithm", "ExperimentConfig",
    "MetricRegistry", "MetricDef", "MetricValue",
    "MetricType", "MetricLevel", "MetricOptimize",
    "MetricRecorder",
]
