"""Embedding-based Dynamic In-Context Learning (DICL).

Provides:
- **EmbeddingDICL** — stores high-quality input/output examples per function
  and retrieves the most similar ones at inference time using cosine
  similarity over embeddings.

When ``sentence-transformers`` is installed the engine uses a real
transformer model for embeddings.  Otherwise it falls back to a simple
word-frequency (TF-IDF–like) vector so that the module remains fully
functional without heavy ML dependencies.

Example::

    dicl = EmbeddingDICL(db_path="coreiq.db")
    dicl.add_example("summarize", "v1", {"text": "long doc"}, {"summary": "short"}, 0.95)
    examples = dicl.retrieve("summarize", {"text": "another doc"}, k=3)
    messages = dicl.to_messages(examples)
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import threading
import uuid
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

_ROLE_MARKERS = re.compile(
    r'(\n\s*(human|assistant|system|user)\s*:|<\|im_(start|end)\|>|<s>|</s>)',
    re.IGNORECASE
)
_MAX_DICL_CONTENT_LEN = 4000


def _sanitize_dicl_content(text: str) -> str:
    """Strip prompt-injection role markers and enforce max length."""
    text = _ROLE_MARKERS.sub(" ", str(text))
    return text[:_MAX_DICL_CONTENT_LEN]

# Sentinel used to track whether we already warned about missing
# sentence-transformers.
_WARNED_NO_TRANSFORMERS = False


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class DICLExample:
    """A single DICL example with its embedding."""

    id: str
    function_id: str
    variant_name: str
    input_data: dict[str, Any]
    output_data: dict[str, Any]
    quality_score: float = 1.0
    embedding: list[float] = field(default_factory=list)
    source: str = "manual"
    created_at: str = ""


# ---------------------------------------------------------------------------
# EmbeddingDICL
# ---------------------------------------------------------------------------

class EmbeddingDICL:
    """Embedding-based DICL with persistent SQLite storage.

    Parameters
    ----------
    db_path:
        Path to the SQLite database.  If ``None`` the module operates purely
        in-memory (useful for tests).
    embedding_model_name:
        Name of the ``sentence-transformers`` model to use when available.
    embedding_dim:
        Dimension of the fallback word-frequency vectors.  Only used when
        ``sentence-transformers`` is not installed.
    """

    def __init__(
        self,
        db_path: str | Path | None = None,
        *,
        embedding_model_name: str = "all-MiniLM-L6-v2",
        embedding_dim: int = 256,
    ) -> None:
        self._lock = threading.Lock()
        self._db_path = str(db_path) if db_path else None
        self._embedding_model_name = embedding_model_name
        self._embedding_dim = embedding_dim

        # Lazy-loaded transformer model
        self._model: Any = None
        self._model_loaded = False

        # In-memory cache of examples (function_id -> list[DICLExample])
        self._cache: dict[str, list[DICLExample]] = {}

        if self._db_path:
            self._ensure_table()
            self._load_cache()

    # ----- public API --------------------------------------------------------

    def add_example(
        self,
        function_id: str,
        variant_name: str,
        input_data: dict[str, Any],
        output_data: dict[str, Any],
        quality_score: float = 1.0,
        *,
        source: str = "manual",
    ) -> str:
        """Persist a new DICL example and return its id.

        Parameters
        ----------
        function_id:
            The function this example belongs to.
        variant_name:
            Which variant produced this output.
        input_data:
            The original application input.
        output_data:
            The ideal output.
        quality_score:
            Quality weight in ``[0, 1]``.
        source:
            One of ``"manual"``, ``"feedback"``, ``"finetune"``.
        """
        example_id = str(uuid.uuid4())
        text = self._text_for_embedding(input_data)
        embedding = self._embed(text)
        now = datetime.now(timezone.utc).isoformat()

        example = DICLExample(
            id=example_id,
            function_id=function_id,
            variant_name=variant_name,
            input_data=input_data,
            output_data=output_data,
            quality_score=quality_score,
            embedding=embedding,
            source=source,
            created_at=now,
        )

        with self._lock:
            if self._db_path:
                self._insert_db(example)
            self._cache.setdefault(function_id, []).append(example)

        return example_id

    def retrieve(
        self,
        function_id: str,
        query_input: dict[str, Any],
        *,
        k: int = 5,
        min_similarity: float = 0.7,
    ) -> list[DICLExample]:
        """Retrieve the top-*k* most similar examples for *function_id*.

        Parameters
        ----------
        function_id:
            Function to search within.
        query_input:
            Application input to compare against stored examples.
        k:
            Maximum number of examples to return.
        min_similarity:
            Minimum cosine similarity threshold.

        Returns
        -------
        list[DICLExample]
            Sorted by descending similarity, at most *k* items.
        """
        text = self._text_for_embedding(query_input)
        query_emb = self._embed(text)

        with self._lock:
            examples = self._cache.get(function_id, [])

        scored: list[tuple[float, DICLExample]] = []
        for ex in examples:
            if not ex.embedding:
                continue
            sim = self._cosine_similarity(query_emb, ex.embedding)
            if sim >= min_similarity:
                scored.append((sim * ex.quality_score, ex))

        scored.sort(key=lambda x: -x[0])
        return [ex for _, ex in scored[:k]]

    def to_messages(self, examples: list[DICLExample]) -> list[dict[str, Any]]:
        """Convert examples to alternating user/assistant message pairs.

        Suitable for injection into the messages list between the system
        prompt and the user's actual query.
        """
        messages: list[dict[str, Any]] = []
        for ex in examples:
            user_content = _sanitize_dicl_content(self._serialise_for_message(ex.input_data))
            assistant_content = _sanitize_dicl_content(self._serialise_for_message(ex.output_data))
            messages.append({"role": "user", "content": user_content})
            messages.append({"role": "assistant", "content": assistant_content})
        return messages

    def add_from_inference(
        self,
        inference_id: str,
        *,
        db_path: str | Path | None = None,
        min_quality: float = 0.8,
    ) -> Optional[str]:
        """Auto-curate a DICL example from a stored inference.

        Looks up the inference in the ``inferences`` table and any associated
        metric values.  If the average metric value meets *min_quality* the
        inference is added as a DICL example.

        Returns the new example id, or ``None`` if the inference was not
        suitable.
        """
        # db_path is accepted for backwards compatibility but ignored — we
        # always route through the configured backend now.
        _ = db_path
        if not self._db_path:
            logger.warning("add_from_inference requires persistence (db_path set)")
            return None

        from ..store.db import get_shared_connection
        conn = get_shared_connection()
        try:
            row = conn.fetchone(
                "SELECT function_id, variant_id, stored_input_json, output_json "
                "FROM inferences WHERE id = ?",
                (inference_id,),
            )
            if row is None:
                logger.warning("Inference %s not found", inference_id)
                return None

            function_id = row["function_id"]
            variant_id = row["variant_id"] or ""
            stored_input = json.loads(row["stored_input_json"] or "{}")
            output = json.loads(row["output_json"] or "{}")

            # Check quality from metric_values
            metrics = conn.fetchall(
                "SELECT value FROM metric_values WHERE inference_id = ? AND value IS NOT NULL",
                (inference_id,),
            )

            if metrics:
                avg_quality = sum(m["value"] for m in metrics) / len(metrics)
            else:
                # No metrics — skip
                logger.debug("No metric values for inference %s, skipping", inference_id)
                return None

            if avg_quality < min_quality:
                logger.debug(
                    "Inference %s quality %.3f below threshold %.3f",
                    inference_id, avg_quality, min_quality,
                )
                return None

            return self.add_example(
                function_id=function_id,
                variant_name=variant_id,
                input_data=stored_input,
                output_data=output,
                quality_score=avg_quality,
                source="feedback",
            )
        except Exception:  # pragma: no cover
            logger.exception("add_from_inference failed for %s", inference_id)
            return None

    # ----- embedding ---------------------------------------------------------

    def _embed(self, text: str) -> list[float]:
        """Compute an embedding vector for *text*.

        Uses ``sentence-transformers`` when available; falls back to a
        word-frequency vector for basic similarity.
        """
        model = self._get_model()
        if model is not None:
            vec = model.encode(text)
            return vec.tolist()

        # Fallback: word-frequency vector
        return self._word_freq_embedding(text)

    def _get_model(self) -> Any:
        """Lazy-load the sentence-transformers model."""
        global _WARNED_NO_TRANSFORMERS

        if self._model_loaded:
            return self._model

        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self._embedding_model_name)
            self._model_loaded = True
            return self._model
        except ImportError:
            self._model_loaded = True
            self._model = None
            if not _WARNED_NO_TRANSFORMERS:
                _WARNED_NO_TRANSFORMERS = True
                logger.warning(
                    "sentence-transformers not installed — DICL will use a "
                    "simple word-frequency fallback.  Install it for better "
                    "results:  pip install sentence-transformers"
                )
            return None

    def _word_freq_embedding(self, text: str) -> list[float]:
        """Produce a fixed-dimension vector from word frequencies.

        This is a very rough approximation used only when real embeddings are
        unavailable.  Each word is hashed to a bucket index and its count
        accumulated there.  The resulting vector is L2-normalised.
        """
        tokens = text.lower().split()
        counts = Counter(tokens)
        vec = [0.0] * self._embedding_dim
        for word, cnt in counts.items():
            idx = int(hashlib.md5(word.encode(), usedforsecurity=False).hexdigest(), 16) % self._embedding_dim
            vec[idx] += float(cnt)

        # L2 normalise
        norm = math.sqrt(sum(v * v for v in vec))
        if norm > 0:
            vec = [v / norm for v in vec]
        return vec

    # ----- cosine similarity -------------------------------------------------

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors.

        Uses numpy if available; falls back to a pure-Python implementation.
        """
        try:
            import numpy as np
            a_np = np.asarray(a, dtype=np.float64)
            b_np = np.asarray(b, dtype=np.float64)
            dot = float(np.dot(a_np, b_np))
            norm_a = float(np.linalg.norm(a_np))
            norm_b = float(np.linalg.norm(b_np))
            if norm_a == 0 or norm_b == 0:
                return 0.0
            return dot / (norm_a * norm_b)
        except ImportError:
            pass

        # Pure Python fallback
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    # ----- DB persistence ----------------------------------------------------

    def _get_conn(self):
        """Return the configured shared backend, or None if persistence is off.

        Returns ``(conn, is_mongo)``. Callers use ``is_mongo`` as a signal to
        skip SQL-specific paths — MongoDB is schemaless and handles its own
        translation.
        """
        if not self._db_path:
            return None, False
        from ..store.db import get_shared_connection
        conn = get_shared_connection()
        return conn, getattr(conn, "backend_type", None) == "mongodb"

    def _ensure_table(self) -> None:
        """``dicl_examples`` is created by the global ``init_schema`` path —
        nothing to do here. Kept for historical call sites."""
        return

    def _insert_db(self, example: DICLExample) -> None:
        """Insert a single example into the database."""
        conn, is_mongo = self._get_conn()
        if conn is None:
            return
        conn.execute(
            "INSERT INTO dicl_examples "
            "(id, function_id, variant_name, input_json, output_json, "
            " embedding_json, quality_score, source, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                example.id,
                example.function_id,
                example.variant_name,
                json.dumps(example.input_data, ensure_ascii=False),
                json.dumps(example.output_data, ensure_ascii=False),
                json.dumps(example.embedding),
                example.quality_score,
                example.source,
                example.created_at,
            ),
        )
        if not is_mongo:
            conn.commit()

    def _load_cache(self) -> None:
        """Load all existing examples from the database into memory."""
        conn, _is_mongo = self._get_conn()
        if conn is None:
            return
        rows = conn.fetchall("SELECT * FROM dicl_examples")
        for row in rows:
            example = DICLExample(
                id=row["id"],
                function_id=row["function_id"],
                variant_name=row["variant_name"] or "",
                input_data=json.loads(row["input_json"] or "{}"),
                output_data=json.loads(row["output_json"] or "{}"),
                quality_score=row["quality_score"] or 1.0,
                embedding=json.loads(row["embedding_json"] or "[]"),
                source=row["source"] or "manual",
                created_at=row["created_at"] or "",
            )
            self._cache.setdefault(example.function_id, []).append(example)
        logger.debug("Loaded %d DICL examples from DB", len(rows))

    # ----- helpers -----------------------------------------------------------

    @staticmethod
    def _text_for_embedding(data: dict[str, Any]) -> str:
        """Flatten a dict to a single string suitable for embedding."""
        parts: list[str] = []
        for key, value in data.items():
            if isinstance(value, str):
                parts.append(value)
            else:
                parts.append(json.dumps(value, ensure_ascii=False, default=str))
        return " ".join(parts)

    @staticmethod
    def _serialise_for_message(data: dict[str, Any]) -> str:
        """Convert data to a string for use in a chat message."""
        if len(data) == 1:
            # Single-key dicts — use the value directly if it is a string
            val = next(iter(data.values()))
            if isinstance(val, str):
                return val
        return json.dumps(data, ensure_ascii=False, indent=2, default=str)
