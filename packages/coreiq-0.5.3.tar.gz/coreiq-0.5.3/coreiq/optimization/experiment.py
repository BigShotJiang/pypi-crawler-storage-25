"""Experiment lifecycle — draft -> active -> concluded."""
import json
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from ..store.db import get_shared_connection
from ..evolution.bandit import PromptBandit


class ExperimentType(str, Enum):
    static = "static"
    adaptive = "adaptive"


class ExperimentStatus(str, Enum):
    draft = "draft"
    active = "active"
    concluded = "concluded"


class ExperimentAlgorithm(str, Enum):
    thompson_sampling = "thompson_sampling"
    track_and_stop = "track_and_stop"
    multi_objective = "multi_objective"


@dataclass
class ExperimentConfig:
    """Configuration for an adaptive experiment."""
    min_samples_per_variant: int = 20
    delta: float = 0.05        # significance level
    epsilon: float = 0.01      # stopping threshold
    update_period_s: int = 300  # how often to recompute bandit weights (seconds)
    max_samples: int = 10000   # safety cap


@dataclass
class Experiment:
    id: str
    function_id: str
    name: str
    type: ExperimentType
    algorithm: Optional[ExperimentAlgorithm] = None
    metric_name: Optional[str] = None
    status: ExperimentStatus = ExperimentStatus.draft
    config: Optional[ExperimentConfig] = None
    candidate_variant_ids: List[str] = field(default_factory=list)
    winner_variant_id: Optional[str] = None
    started_at: Optional[str] = None
    concluded_at: Optional[str] = None
    # Multi-objective fields
    objectives: Optional[List[Dict[str, Any]]] = None  # [{metric_name, direction, weight}, ...]
    scalarization: str = "weighted_sum"  # "weighted_sum" or "chebyshev"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _config_to_json(config: Optional[ExperimentConfig]) -> Optional[str]:
    if config is None:
        return None
    return json.dumps({
        "min_samples_per_variant": config.min_samples_per_variant,
        "delta": config.delta,
        "epsilon": config.epsilon,
        "update_period_s": config.update_period_s,
        "max_samples": config.max_samples,
    })


def _config_from_json(raw: Optional[str]) -> Optional[ExperimentConfig]:
    if not raw:
        return None
    d = json.loads(raw)
    return ExperimentConfig(
        min_samples_per_variant=d.get("min_samples_per_variant", 20),
        delta=d.get("delta", 0.05),
        epsilon=d.get("epsilon", 0.01),
        update_period_s=d.get("update_period_s", 300),
        max_samples=d.get("max_samples", 10000),
    )


class ExperimentManager:
    """Manages experiment lifecycle: create -> start -> conclude.

    Enforces at most one active experiment per function.
    For adaptive experiments, delegates variant selection to the bandit
    and manages bandit state in the bandit_state table.
    """

    def __init__(self):
        self._lock = threading.Lock()
        # function_id -> active Experiment
        self._active_experiments: Dict[str, Experiment] = {}
        # experiment_id -> PromptBandit (for adaptive experiments)
        self._bandits: Dict[str, PromptBandit] = {}
        self._loaded = False

    def _conn(self):
        return get_shared_connection()

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            self._load_active()
            self._loaded = True

    def _load_active(self) -> None:
        """Load all active experiments and their bandit state from DB."""
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT * FROM experiments WHERE status = 'active'"
            ).fetchall()
        except Exception:
            rows = []
        for row in rows:
            exp = self._row_to_experiment(row)
            self._active_experiments[exp.function_id] = exp
            if exp.type == ExperimentType.adaptive:
                self._load_bandit_for_experiment(exp)

    def _load_bandit_for_experiment(self, exp: Experiment) -> None:
        """Load bandit state for an adaptive experiment."""
        if exp.algorithm == ExperimentAlgorithm.multi_objective:
            self._load_multi_objective_bandit(exp)
            return
        conn = self._conn()
        bandit = PromptBandit([])
        try:
            rows = conn.execute(
                "SELECT variant_id, alpha, beta FROM bandit_state WHERE experiment_id = ?",
                (exp.id,),
            ).fetchall()
            for row in rows:
                bandit.restore_arm(row["variant_id"], float(row["alpha"]), float(row["beta"]))
        except Exception:
            # experiment_id column may not exist yet -- load all arms as fallback
            for vid in exp.candidate_variant_ids:
                bandit.add_variant(vid)
        # Ensure all candidate variants have arms
        for vid in exp.candidate_variant_ids:
            if bandit.get_arm(vid) is None:
                bandit.add_variant(vid)
        self._bandits[exp.id] = bandit

    @staticmethod
    def _row_to_experiment(row) -> Experiment:
        candidate_ids = []
        if row["candidate_variants_json"]:
            candidate_ids = json.loads(row["candidate_variants_json"])
        # Parse multi-objective fields from config_json
        objectives = None
        scalarization = "weighted_sum"
        config_raw = row["config_json"]
        if config_raw:
            try:
                d = json.loads(config_raw)
                if "objectives" in d:
                    objectives = d["objectives"]
                if "scalarization" in d:
                    scalarization = d["scalarization"]
            except (json.JSONDecodeError, TypeError):
                pass
        return Experiment(
            id=row["id"],
            function_id=row["function_id"],
            name=row["name"] or "",
            type=ExperimentType(row["type"]),
            algorithm=ExperimentAlgorithm(row["algorithm"]) if row["algorithm"] else None,
            metric_name=row["metric_name"],
            status=ExperimentStatus(row["status"]),
            config=_config_from_json(row["config_json"]),
            candidate_variant_ids=candidate_ids,
            winner_variant_id=row["winner_variant_id"],
            started_at=row["started_at"],
            concluded_at=row["concluded_at"],
            objectives=objectives,
            scalarization=scalarization,
        )

    def create(
        self,
        function_id: str,
        name: str,
        type: ExperimentType,
        candidate_variant_ids: List[str],
        algorithm: Optional[ExperimentAlgorithm] = None,
        metric_name: Optional[str] = None,
        config: Optional[ExperimentConfig] = None,
        objectives: Optional[List[Dict[str, Any]]] = None,
        scalarization: str = "weighted_sum",
    ) -> Experiment:
        """Create a new experiment in draft status.

        For multi-objective experiments, pass ``algorithm=ExperimentAlgorithm.multi_objective``
        and provide *objectives* -- a list of dicts with keys ``metric_name``,
        ``direction`` (``"max"`` or ``"min"``), and ``weight`` (float).
        """
        if type == ExperimentType.adaptive and not algorithm:
            algorithm = ExperimentAlgorithm.thompson_sampling
        if algorithm == ExperimentAlgorithm.multi_objective:
            if not objectives or len(objectives) < 1:
                from ..exceptions import ValidationError
                raise ValidationError(
                    "Multi-objective experiments require at least one objective"
                )
        elif type == ExperimentType.adaptive and not metric_name:
            from ..exceptions import ValidationError
            raise ValidationError("Adaptive experiments require a metric_name")
        if len(candidate_variant_ids) < 2:
            from ..exceptions import ValidationError
            raise ValidationError("Experiments require at least 2 candidate variants")

        eid = str(uuid.uuid4())
        exp = Experiment(
            id=eid, function_id=function_id, name=name, type=type,
            algorithm=algorithm, metric_name=metric_name,
            status=ExperimentStatus.draft, config=config or ExperimentConfig(),
            candidate_variant_ids=candidate_variant_ids,
            objectives=objectives,
            scalarization=scalarization,
        )
        # Embed multi-objective fields into config_json for persistence
        config_dict = json.loads(_config_to_json(exp.config) or "{}")
        if objectives is not None:
            config_dict["objectives"] = objectives
        if scalarization != "weighted_sum":
            config_dict["scalarization"] = scalarization
        config_json_str = json.dumps(config_dict)

        conn = self._conn()
        conn.execute(
            "INSERT INTO experiments(id, function_id, name, type, algorithm, metric_name, "
            "status, config_json, candidate_variants_json, winner_variant_id, "
            "started_at, concluded_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (exp.id, exp.function_id, exp.name, exp.type.value,
             exp.algorithm.value if exp.algorithm else None,
             exp.metric_name, exp.status.value,
             config_json_str,
             json.dumps(exp.candidate_variant_ids),
             None, None, None),
        )
        conn.commit()
        return exp

    def start(self, experiment_id: str) -> Experiment:
        """Transition an experiment from draft to active.

        Raises if there is already an active experiment for the same function.
        """
        self._ensure_loaded()
        with self._lock:
            conn = self._conn()
            row = conn.execute(
                "SELECT * FROM experiments WHERE id = ?", (experiment_id,)
            ).fetchone()
            if row is None:
                from ..exceptions import ValidationError
                raise ValidationError(f"Experiment '{experiment_id}' not found")
            exp = self._row_to_experiment(row)
            if exp.status != ExperimentStatus.draft:
                from ..exceptions import ValidationError
                raise ValidationError(
                    f"Cannot start experiment in '{exp.status.value}' status"
                )

            # Check for existing active experiment on same function
            if exp.function_id in self._active_experiments:
                existing = self._active_experiments[exp.function_id]
                from ..exceptions import ValidationError
                raise ValidationError(
                    f"Function '{exp.function_id}' already has an active experiment: "
                    f"'{existing.name}' ({existing.id})"
                )

            now = _now()
            exp.status = ExperimentStatus.active
            exp.started_at = now
            conn.execute(
                "UPDATE experiments SET status = 'active', started_at = ? WHERE id = ?",
                (now, experiment_id),
            )
            conn.commit()

            self._active_experiments[exp.function_id] = exp

            # Initialize bandit for adaptive experiments
            if exp.type == ExperimentType.adaptive:
                if exp.algorithm == ExperimentAlgorithm.multi_objective:
                    bandit = self._create_multi_objective_bandit(exp)
                    self._bandits[exp.id] = bandit
                else:
                    bandit = PromptBandit(exp.candidate_variant_ids)
                    self._bandits[exp.id] = bandit
                    self._persist_bandit(exp.id, bandit)

            return exp

    def conclude(
        self,
        experiment_id: str,
        winner_variant_id: Optional[str] = None,
    ) -> Experiment:
        """Conclude an experiment, optionally declaring a winner.

        If no winner is specified for an adaptive experiment, the current
        best arm from the bandit is used.
        """
        self._ensure_loaded()
        with self._lock:
            conn = self._conn()
            row = conn.execute(
                "SELECT * FROM experiments WHERE id = ?", (experiment_id,)
            ).fetchone()
            if row is None:
                from ..exceptions import ValidationError
                raise ValidationError(f"Experiment '{experiment_id}' not found")
            exp = self._row_to_experiment(row)
            if exp.status != ExperimentStatus.active:
                from ..exceptions import ValidationError
                raise ValidationError(
                    f"Cannot conclude experiment in '{exp.status.value}' status"
                )

            # Auto-detect winner for adaptive experiments
            if winner_variant_id is None and exp.type == ExperimentType.adaptive:
                bandit = self._bandits.get(exp.id)
                if bandit is not None:
                    if hasattr(bandit, "best"):
                        winner_variant_id = bandit.best()
                    else:
                        winner_variant_id = None

            now = _now()
            exp.status = ExperimentStatus.concluded
            exp.concluded_at = now
            exp.winner_variant_id = winner_variant_id
            conn.execute(
                "UPDATE experiments SET status = 'concluded', concluded_at = ?, "
                "winner_variant_id = ? WHERE id = ?",
                (now, winner_variant_id, experiment_id),
            )
            conn.commit()

            # Clean up active state
            self._active_experiments.pop(exp.function_id, None)
            self._bandits.pop(exp.id, None)
            return exp

    def get(self, experiment_id: str) -> Optional[Experiment]:
        """Get an experiment by ID."""
        conn = self._conn()
        row = conn.execute(
            "SELECT * FROM experiments WHERE id = ?", (experiment_id,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_experiment(row)

    def get_active_for_function(self, function_id: str) -> Optional[Experiment]:
        """Get the active experiment for a function (if any)."""
        self._ensure_loaded()
        return self._active_experiments.get(function_id)

    def list(
        self,
        function_id: Optional[str] = None,
        status: Optional[ExperimentStatus] = None,
    ) -> List[Experiment]:
        """List experiments with optional filters."""
        conn = self._conn()
        sql = "SELECT * FROM experiments WHERE 1=1"
        params: list = []
        if function_id is not None:
            sql += " AND function_id = ?"
            params.append(function_id)
        if status is not None:
            sql += " AND status = ?"
            params.append(status.value)
        sql += " ORDER BY started_at DESC"
        rows = conn.execute(sql, params).fetchall()
        return [self._row_to_experiment(r) for r in rows]

    def select_variant(self, function_id: str) -> Optional[str]:
        """Select a variant ID for a function call via the active experiment.

        For static experiments: delegates to VariantManager weight-based selection
        (returns None to let caller handle it).
        For adaptive experiments: uses the bandit to select.

        Returns variant_id or None if no active experiment.
        """
        self._ensure_loaded()
        exp = self._active_experiments.get(function_id)
        if exp is None:
            return None

        if exp.type == ExperimentType.static:
            # Static experiments use weight-based selection handled by VariantManager
            return None

        # Adaptive: use bandit
        bandit = self._bandits.get(exp.id)
        if bandit is None:
            return None

        # Multi-objective bandit has its own select logic
        if exp.algorithm == ExperimentAlgorithm.multi_objective:
            from .bandit import MultiObjectiveBandit
            if isinstance(bandit, MultiObjectiveBandit):
                return bandit.select()
            return None

        if not bandit.has_arms():
            return None

        # Check nursery phase: round-robin until min_samples_per_variant
        min_samples = exp.config.min_samples_per_variant if exp.config else 20
        for vid in exp.candidate_variant_ids:
            arm = bandit.get_arm(vid)
            if arm is not None and arm.samples < min_samples:
                return vid

        # Bandit phase: Thompson sampling
        return bandit.select()

    def record_reward(
        self,
        function_id: str,
        variant_id: str,
        reward: float,
    ) -> None:
        """Record a reward for a variant in the active experiment.

        Updates the bandit and persists state.
        """
        self._ensure_loaded()
        with self._lock:
            exp = self._active_experiments.get(function_id)
            if exp is None:
                return
            if exp.type != ExperimentType.adaptive:
                return
            if variant_id not in exp.candidate_variant_ids:
                return

            bandit = self._bandits.get(exp.id)
            if bandit is None:
                return

            # Multi-objective bandit: single reward maps to first objective
            if exp.algorithm == ExperimentAlgorithm.multi_objective:
                from .bandit import MultiObjectiveBandit
                if isinstance(bandit, MultiObjectiveBandit):
                    bandit.update(variant_id, reward)
                return

            bandit.reward(variant_id, reward)
            self._persist_bandit(exp.id, bandit)

    def record_reward_multi(
        self,
        experiment_id: str,
        variant_id: str,
        rewards: Dict[str, float],
    ) -> None:
        """Record multi-objective rewards for a variant.

        Parameters
        ----------
        experiment_id:
            The experiment ID (not function_id, since multi-objective
            experiments need explicit experiment targeting).
        variant_id:
            The variant that was pulled.
        rewards:
            Mapping of objective_name -> reward value (each in [0, 1]).
        """
        self._ensure_loaded()
        with self._lock:
            # Find the experiment among active experiments
            exp = None
            for e in self._active_experiments.values():
                if e.id == experiment_id:
                    exp = e
                    break
            if exp is None:
                return
            if exp.algorithm != ExperimentAlgorithm.multi_objective:
                return
            if variant_id not in exp.candidate_variant_ids:
                return

            bandit = self._bandits.get(exp.id)
            if bandit is None:
                return

            from .bandit import MultiObjectiveBandit
            if isinstance(bandit, MultiObjectiveBandit):
                bandit.update_multi(variant_id, rewards)

    def check_stopping(self, experiment_id: str) -> bool:
        """Check if an adaptive experiment should be stopped.

        Uses a simple rule: if any arm has significantly more wins than
        others after minimum samples, recommend stopping.
        Returns True if the experiment should be concluded.
        """
        self._ensure_loaded()
        exp = None
        for e in self._active_experiments.values():
            if e.id == experiment_id:
                exp = e
                break
        if exp is None or exp.type != ExperimentType.adaptive:
            return False

        bandit = self._bandits.get(exp.id)
        if bandit is None:
            return False

        # Multi-objective: delegate to bandit's should_stop
        if exp.algorithm == ExperimentAlgorithm.multi_objective:
            from .bandit import MultiObjectiveBandit
            if isinstance(bandit, MultiObjectiveBandit):
                return bandit.should_stop()
            return False

        config = exp.config or ExperimentConfig()

        # Check all arms have minimum samples
        for vid in exp.candidate_variant_ids:
            arm = bandit.get_arm(vid)
            if arm is None or arm.samples < config.min_samples_per_variant:
                return False

        # Check total samples cap
        total_samples = sum(
            (bandit.get_arm(vid).samples if bandit.get_arm(vid) else 0)
            for vid in exp.candidate_variant_ids
        )
        if total_samples >= config.max_samples:
            return True

        # Simple stopping rule: best arm's lower confidence bound exceeds
        # second-best arm's upper confidence bound (with delta/epsilon margin)
        arms = []
        for vid in exp.candidate_variant_ids:
            arm = bandit.get_arm(vid)
            if arm is not None:
                arms.append(arm)
        if len(arms) < 2:
            return False

        arms.sort(key=lambda a: a.win_rate, reverse=True)
        best = arms[0]
        second = arms[1]

        # Gap between best and second-best must exceed epsilon
        gap = best.win_rate - second.win_rate
        if gap < config.epsilon:
            return False

        # With enough samples and clear gap, recommend stopping
        import math
        n_best = max(best.samples, 1)
        n_second = max(second.samples, 1)
        # Approximate confidence interval width (normal approx to beta)
        ci_best = 1.96 * math.sqrt(best.win_rate * (1 - best.win_rate) / n_best)
        ci_second = 1.96 * math.sqrt(second.win_rate * (1 - second.win_rate) / n_second)

        # Best arm's lower bound > second arm's upper bound
        if (best.win_rate - ci_best) > (second.win_rate + ci_second):
            return True

        return False

    def _create_multi_objective_bandit(self, exp: Experiment) -> Any:
        """Create a MultiObjectiveBandit from an experiment's objectives config."""
        from .bandit import MultiObjectiveBandit

        objectives = exp.objectives or []
        objective_names = [o["metric_name"] for o in objectives]
        directions = {o["metric_name"]: o.get("direction", "max") for o in objectives}
        weights = [o.get("weight", 1.0) for o in objectives]

        return MultiObjectiveBandit(
            exp.candidate_variant_ids,
            objective_names=objective_names,
            directions=directions,
            preference_prior=weights,
            scalarization=exp.scalarization,
        )

    def _load_multi_objective_bandit(self, exp: Experiment) -> None:
        """Load or create a MultiObjectiveBandit for an experiment.

        Attempts to load persisted state from the bandit_state table;
        falls back to creating a fresh bandit if no state is found.
        """

        conn = self._conn()
        try:
            # Try loading serialised state from bandit_state
            rows = conn.execute(
                "SELECT variant_id, algorithm, count, sum_rewards, sum_sq_rewards "
                "FROM bandit_state WHERE experiment_id = ? AND algorithm = 'multi_objective'",
                (exp.id,),
            ).fetchall()
        except Exception:
            rows = []

        if not rows:
            # No persisted state -- create fresh
            bandit = self._create_multi_objective_bandit(exp)
            self._bandits[exp.id] = bandit
            return

        # We have rows but multi-objective state is richer than what the simple
        # bandit_state table stores, so just create a fresh bandit.
        # In production, serialised JSON state would be in a separate column/table.
        bandit = self._create_multi_objective_bandit(exp)
        self._bandits[exp.id] = bandit

    def _persist_bandit(self, experiment_id: str, bandit: PromptBandit) -> None:
        """Persist bandit state for an experiment."""
        conn = self._conn()
        now = _now()
        for vid, arm in bandit.items():
            try:
                conn.execute(
                    "INSERT OR REPLACE INTO bandit_state"
                    "(variant_id, alpha, beta, updated_at, experiment_id, "
                    "count, sum_rewards, sum_sq_rewards, algorithm) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (vid, arm.alpha, arm.beta, now, experiment_id,
                     arm.samples, arm.alpha - 1.0, 0.0, "thompson_sampling"),
                )
            except Exception:
                # Fallback if new columns don't exist yet
                conn.execute(
                    "INSERT OR REPLACE INTO bandit_state"
                    "(variant_id, alpha, beta, updated_at) VALUES (?, ?, ?, ?)",
                    (vid, arm.alpha, arm.beta, now),
                )
        conn.commit()

    def get_bandit_stats(self, experiment_id: str) -> List[Dict[str, Any]]:
        """Get bandit statistics for an experiment."""
        bandit = self._bandits.get(experiment_id)
        if bandit is None:
            return []
        if hasattr(bandit, "stats"):
            return bandit.stats()
        return []

    def invalidate_cache(self) -> None:
        """Force reload from DB on next access."""
        with self._lock:
            self._active_experiments.clear()
            self._bandits.clear()
            self._loaded = False
