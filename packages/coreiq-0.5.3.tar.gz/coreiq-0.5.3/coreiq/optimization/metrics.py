"""Metric definitions for optimization feedback signals."""
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from ..store.db import get_shared_connection


class MetricType(str, Enum):
    boolean = "boolean"
    float_ = "float"
    comment = "comment"
    demonstration = "demonstration"


class MetricLevel(str, Enum):
    inference = "inference"
    episode = "episode"


class MetricOptimize(str, Enum):
    max = "max"
    min = "min"


@dataclass
class MetricDef:
    id: str
    name: str
    type: MetricType
    level: MetricLevel
    optimize: MetricOptimize
    created_at: str = ""

    def normalize_to_reward(self, value: Any) -> float:
        """Convert a raw metric value to a [0, 1] reward for bandit updates.

        For boolean metrics: True/1 -> 1.0, False/0 -> 0.0.
        For float metrics: clamp to [0, 1] then flip if minimize.
        For comment/demonstration: returns 1.0 (presence = positive signal).
        """
        if self.type == MetricType.boolean:
            reward = 1.0 if value else 0.0
        elif self.type == MetricType.float_:
            reward = max(0.0, min(1.0, float(value)))
        elif self.type in (MetricType.comment, MetricType.demonstration):
            return 1.0
        else:
            reward = max(0.0, min(1.0, float(value)))

        if self.optimize == MetricOptimize.min:
            reward = 1.0 - reward
        return reward


@dataclass
class MetricValue:
    id: str
    inference_id: Optional[str]
    episode_id: Optional[str]
    metric_name: str
    value: Optional[float]
    comment: Optional[str]
    demonstration: Optional[str]
    ts: str
    user_id: Optional[str]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MetricRegistry:
    """DB-backed registry for metric definitions and values. Thread-safe."""

    def __init__(self):
        self._lock = threading.Lock()
        self._cache: Dict[str, MetricDef] = {}
        self._loaded = False

    def _conn(self):
        return get_shared_connection()

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            self._load_all()
            self._loaded = True

    def _load_all(self) -> None:
        conn = self._conn()
        try:
            rows = conn.execute("SELECT * FROM metric_definitions").fetchall()
        except Exception:
            rows = []
        for row in rows:
            md = MetricDef(
                id=row["id"],
                name=row["name"],
                type=MetricType(row["type"]),
                level=MetricLevel(row["level"]),
                optimize=MetricOptimize(row["optimize"]),
                created_at=row["created_at"] or "",
            )
            self._cache[md.name] = md

    def create(self, name: str, type: MetricType, level: MetricLevel,
               optimize: MetricOptimize) -> MetricDef:
        """Create a new metric definition. Raises if name already exists."""
        self._ensure_loaded()
        with self._lock:
            if name in self._cache:
                from ..exceptions import ValidationError
                raise ValidationError(f"Metric '{name}' already exists")
            mid = str(uuid.uuid4())
            now = _now()
            md = MetricDef(
                id=mid, name=name, type=type, level=level,
                optimize=optimize, created_at=now,
            )
            conn = self._conn()
            conn.execute(
                "INSERT INTO metric_definitions(id, name, type, level, optimize, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (md.id, md.name, md.type.value, md.level.value,
                 md.optimize.value, md.created_at),
            )
            conn.commit()
            self._cache[name] = md
            return md

    def get(self, name: str) -> Optional[MetricDef]:
        """Get a metric definition by name."""
        self._ensure_loaded()
        return self._cache.get(name)

    def list(self) -> List[MetricDef]:
        """Return all metric definitions."""
        self._ensure_loaded()
        return list(self._cache.values())

    def delete(self, name: str) -> bool:
        """Delete a metric definition by name. Returns True if deleted."""
        self._ensure_loaded()
        with self._lock:
            if name not in self._cache:
                return False
            md = self._cache[name]
            conn = self._conn()
            conn.execute("DELETE FROM metric_definitions WHERE id = ?", (md.id,))
            conn.commit()
            del self._cache[name]
            return True

    def update(self, name: str, optimize: Optional[MetricOptimize] = None) -> Optional[MetricDef]:
        """Update a metric definition. Only optimize direction can be changed."""
        self._ensure_loaded()
        with self._lock:
            md = self._cache.get(name)
            if md is None:
                return None
            if optimize is not None:
                md.optimize = optimize
                conn = self._conn()
                conn.execute(
                    "UPDATE metric_definitions SET optimize = ? WHERE id = ?",
                    (md.optimize.value, md.id),
                )
                conn.commit()
            return md

    def record_value(
        self,
        metric_name: str,
        inference_id: Optional[str] = None,
        episode_id: Optional[str] = None,
        value: Optional[float] = None,
        comment: Optional[str] = None,
        demonstration: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> MetricValue:
        """Record a metric value for an inference or episode."""
        self._ensure_loaded()
        md = self._cache.get(metric_name)
        if md is None:
            from ..exceptions import ValidationError
            raise ValidationError(f"Unknown metric: {metric_name!r}")
        if inference_id is None and episode_id is None:
            from ..exceptions import ValidationError
            raise ValidationError("Must provide inference_id or episode_id")

        # Validate value type matches metric type
        if md.type == MetricType.boolean:
            if value is None:
                from ..exceptions import ValidationError
                raise ValidationError("Boolean metric requires a value (0 or 1)")
        elif md.type == MetricType.float_:
            if value is None:
                from ..exceptions import ValidationError
                raise ValidationError("Float metric requires a numeric value")
        elif md.type == MetricType.comment:
            if comment is None:
                from ..exceptions import ValidationError
                raise ValidationError("Comment metric requires a comment string")
        elif md.type == MetricType.demonstration:
            if demonstration is None:
                from ..exceptions import ValidationError
                raise ValidationError("Demonstration metric requires a demonstration string")

        mid = str(uuid.uuid4())
        now = _now()
        mv = MetricValue(
            id=mid, inference_id=inference_id, episode_id=episode_id,
            metric_name=metric_name, value=value, comment=comment,
            demonstration=demonstration, ts=now, user_id=user_id,
        )
        conn = self._conn()
        conn.execute(
            "INSERT INTO metric_values(id, inference_id, episode_id, metric_name, "
            "value, comment, demonstration, ts, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (mv.id, mv.inference_id, mv.episode_id, mv.metric_name,
             mv.value, mv.comment, mv.demonstration, mv.ts, mv.user_id),
        )
        conn.commit()
        return mv

    def get_values(
        self,
        metric_name: str,
        inference_id: Optional[str] = None,
        episode_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[MetricValue]:
        """Query metric values with optional filters."""
        conn = self._conn()
        sql = "SELECT * FROM metric_values WHERE metric_name = ?"
        params: list = [metric_name]
        if inference_id is not None:
            sql += " AND inference_id = ?"
            params.append(inference_id)
        if episode_id is not None:
            sql += " AND episode_id = ?"
            params.append(episode_id)
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(sql, params).fetchall()
        return [
            MetricValue(
                id=r["id"], inference_id=r["inference_id"],
                episode_id=r["episode_id"], metric_name=r["metric_name"],
                value=r["value"], comment=r["comment"],
                demonstration=r["demonstration"], ts=r["ts"],
                user_id=r["user_id"],
            )
            for r in rows
        ]

    def get_variant_reward(self, metric_name: str, variant_id: str) -> Optional[float]:
        """Compute average reward for a variant based on metric values.

        Joins metric_values with inferences to get values for a specific variant,
        then normalizes using the metric definition.
        """
        md = self.get(metric_name)
        if md is None:
            return None
        conn = self._conn()
        if md.type in (MetricType.boolean, MetricType.float_):
            rows = conn.execute(
                "SELECT mv.value FROM metric_values mv "
                "JOIN inferences i ON mv.inference_id = i.id "
                "WHERE mv.metric_name = ? AND i.variant_id = ? AND mv.value IS NOT NULL",
                (metric_name, variant_id),
            ).fetchall()
            if not rows:
                return None
            rewards = [md.normalize_to_reward(r["value"]) for r in rows]
            return sum(rewards) / len(rewards)
        else:
            # For comment/demonstration, count presence as positive signal
            count = conn.execute(
                "SELECT COUNT(*) as cnt FROM metric_values mv "
                "JOIN inferences i ON mv.inference_id = i.id "
                "WHERE mv.metric_name = ? AND i.variant_id = ?",
                (metric_name, variant_id),
            ).fetchone()["cnt"]
            return 1.0 if count > 0 else None

    def invalidate_cache(self) -> None:
        """Force reload from DB on next access."""
        with self._lock:
            self._cache.clear()
            self._loaded = False
