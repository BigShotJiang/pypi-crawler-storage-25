"""Multi-armed bandit algorithms for variant selection.

Provides:
- **BanditBase** — Abstract base class for all bandit algorithms.
- **TrackAndStopBandit** — Three-phase state machine (nursery → tracking → stopped)
  using GLRT stopping with optional SOCP-optimal allocation (clarabel).
- **ThompsonBandit** — Thin wrapper around the existing ``PromptBandit``
  that conforms to the ``BanditBase`` interface.

Example::

    bandit = TrackAndStopBandit(["variant_a", "variant_b"], delta=0.05)
    chosen = bandit.select()
    bandit.update(chosen, 1.0)
    if bandit.should_stop():
        print(f"Winner: {bandit.best()}")
"""
from __future__ import annotations

import logging
import math
import random
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Arm data structure
# ---------------------------------------------------------------------------

@dataclass
class ArmStats:
    """Running statistics for a single arm."""

    variant_id: str
    total_reward: float = 0.0
    count: int = 0
    sum_sq: float = 0.0  # for variance estimation

    @property
    def mean(self) -> float:
        return self.total_reward / self.count if self.count > 0 else 0.0

    @property
    def variance(self) -> float:
        if self.count < 2:
            return 1.0  # uninformative prior
        return max(self.sum_sq / self.count - self.mean ** 2, 1e-12)


# ---------------------------------------------------------------------------
# BanditBase ABC
# ---------------------------------------------------------------------------

class BanditBase(ABC):
    """Abstract interface that all bandit algorithms must implement."""

    @abstractmethod
    def select(self) -> str:
        """Choose a variant to pull next."""

    @abstractmethod
    def update(self, variant_id: str, reward: float) -> None:
        """Record an observed reward for *variant_id*."""

    @abstractmethod
    def best(self) -> Optional[str]:
        """Return the current best variant (highest estimated reward)."""

    @abstractmethod
    def should_stop(self) -> bool:
        """Return ``True`` when the algorithm has identified a winner."""

    @abstractmethod
    def stats(self) -> list[dict[str, Any]]:
        """Return per-arm statistics for dashboards / persistence."""

    @abstractmethod
    def state_dict(self) -> dict[str, Any]:
        """Serialise full bandit state to a JSON-safe dictionary."""

    @classmethod
    @abstractmethod
    def from_state_dict(cls, data: dict[str, Any]) -> "BanditBase":
        """Reconstruct a bandit from a previously saved *state_dict*."""


# ---------------------------------------------------------------------------
# Track-and-Stop
# ---------------------------------------------------------------------------

class _Phase(str, Enum):
    NURSERY = "nursery"
    TRACKING = "tracking"
    STOPPED = "stopped"


class TrackAndStopBandit(BanditBase):
    """Track-and-Stop best-arm identification.

    Three phases:

    1. **Nursery** — round-robin each arm until it has *min_samples_per_variant*
       observations.
    2. **Tracking** — pull the arm most below its SOCP-optimal target proportion.
       If ``clarabel`` is not installed the target proportions fall back to
       C-tracking (proportional to ``1 / gap²``).
    3. **Stopped** — the GLRT statistic exceeds the ``beta(t, delta)`` threshold
       and a winner is declared.

    Parameters
    ----------
    variant_ids:
        List of variant identifiers (at least 2).
    delta:
        Confidence parameter (probability of misidentification). Default 0.05.
    min_samples_per_variant:
        Minimum observations per arm before leaving nursery. Default 30.
    reward_type:
        ``"bernoulli"`` or ``"gaussian"``. Controls KL divergence used in GLRT.
    """

    def __init__(
        self,
        variant_ids: list[str],
        *,
        delta: float = 0.05,
        min_samples_per_variant: int = 30,
        reward_type: str = "bernoulli",
    ) -> None:
        if len(variant_ids) < 2:
            raise ValueError("Track-and-Stop requires at least 2 variants")

        self._lock = threading.Lock()
        self._variant_ids = list(variant_ids)
        self._K = len(variant_ids)
        self._delta = delta
        self._min_samples = min_samples_per_variant
        self._reward_type = reward_type

        self._arms: dict[str, ArmStats] = {
            vid: ArmStats(variant_id=vid) for vid in variant_ids
        }
        self._phase = _Phase.NURSERY
        self._rr_index = 0  # round-robin pointer for nursery
        self._total_pulls = 0
        self._winner: Optional[str] = None

        # Cached target proportions (recomputed after tracking begins / periodically)
        self._target_props: dict[str, float] = {}
        self._glrt_recompute_interval = 10  # recompute every N pulls in tracking

    # ----- public interface --------------------------------------------------

    def select(self) -> str:
        """Choose the next arm to pull."""
        with self._lock:
            if self._phase == _Phase.STOPPED:
                return self._winner  # type: ignore[return-value]

            if self._phase == _Phase.NURSERY:
                return self._nursery_select()

            # TRACKING phase
            return self._tracking_select()

    def update(self, variant_id: str, reward: float) -> None:
        """Record an observed reward for *variant_id*."""
        with self._lock:
            arm = self._arms.get(variant_id)
            if arm is None:
                logger.warning("Unknown variant_id %s — ignoring update", variant_id)
                return

            arm.total_reward += reward
            arm.sum_sq += reward * reward
            arm.count += 1
            self._total_pulls += 1

            # Phase transitions
            if self._phase == _Phase.NURSERY:
                if all(a.count >= self._min_samples for a in self._arms.values()):
                    self._phase = _Phase.TRACKING
                    self._recompute_targets()
                    logger.info(
                        "Track-and-Stop: nursery complete (%d total pulls), entering tracking",
                        self._total_pulls,
                    )
            elif self._phase == _Phase.TRACKING:
                if self._total_pulls % self._glrt_recompute_interval == 0:
                    self._recompute_targets()
                    if self._check_glrt():
                        self._phase = _Phase.STOPPED
                        self._winner = self._empirical_best()
                        logger.info(
                            "Track-and-Stop: STOPPED — winner=%s after %d pulls",
                            self._winner,
                            self._total_pulls,
                        )

    def best(self) -> Optional[str]:
        with self._lock:
            if self._winner:
                return self._winner
            return self._empirical_best()

    def should_stop(self) -> bool:
        with self._lock:
            return self._phase == _Phase.STOPPED

    def stats(self) -> list[dict[str, Any]]:
        with self._lock:
            result = []
            for arm in sorted(self._arms.values(), key=lambda a: -a.mean):
                result.append({
                    "variant_id": arm.variant_id,
                    "mean_reward": round(arm.mean, 6),
                    "count": arm.count,
                    "variance": round(arm.variance, 6),
                    "target_proportion": round(self._target_props.get(arm.variant_id, 0.0), 6),
                    "actual_proportion": round(
                        arm.count / self._total_pulls if self._total_pulls else 0.0, 6
                    ),
                })
            return result

    def state_dict(self) -> dict[str, Any]:
        with self._lock:
            return {
                "algorithm": "track_and_stop",
                "variant_ids": self._variant_ids,
                "delta": self._delta,
                "min_samples_per_variant": self._min_samples,
                "reward_type": self._reward_type,
                "phase": self._phase.value,
                "rr_index": self._rr_index,
                "total_pulls": self._total_pulls,
                "winner": self._winner,
                "arms": {
                    vid: {
                        "total_reward": a.total_reward,
                        "count": a.count,
                        "sum_sq": a.sum_sq,
                    }
                    for vid, a in self._arms.items()
                },
            }

    @classmethod
    def from_state_dict(cls, data: dict[str, Any]) -> "TrackAndStopBandit":
        bandit = cls(
            data["variant_ids"],
            delta=data.get("delta", 0.05),
            min_samples_per_variant=data.get("min_samples_per_variant", 30),
            reward_type=data.get("reward_type", "bernoulli"),
        )
        bandit._phase = _Phase(data.get("phase", "nursery"))
        bandit._rr_index = data.get("rr_index", 0)
        bandit._total_pulls = data.get("total_pulls", 0)
        bandit._winner = data.get("winner")
        for vid, arm_data in data.get("arms", {}).items():
            if vid in bandit._arms:
                bandit._arms[vid].total_reward = arm_data["total_reward"]
                bandit._arms[vid].count = arm_data["count"]
                bandit._arms[vid].sum_sq = arm_data["sum_sq"]
        if bandit._phase == _Phase.TRACKING:
            bandit._recompute_targets()
        return bandit

    # ----- nursery -----------------------------------------------------------

    def _nursery_select(self) -> str:
        """Round-robin selection during nursery phase."""
        vid = self._variant_ids[self._rr_index % self._K]
        self._rr_index += 1
        return vid

    # ----- tracking ----------------------------------------------------------

    def _tracking_select(self) -> str:
        """Pull the arm most below its target proportion."""
        if not self._target_props:
            self._recompute_targets()

        best_gap = -float("inf")
        best_vid = self._variant_ids[0]
        for vid in self._variant_ids:
            target = self._target_props.get(vid, 1.0 / self._K)
            actual = self._arms[vid].count / self._total_pulls if self._total_pulls else 0.0
            gap = target - actual
            if gap > best_gap:
                best_gap = gap
                best_vid = vid
        return best_vid

    def _recompute_targets(self) -> None:
        """Compute target proportions via SOCP or C-tracking fallback."""
        props = self._solve_socp()
        if props is None:
            props = self._c_tracking_fallback()
        self._target_props = props

    def _solve_socp(self) -> Optional[dict[str, float]]:
        """Compute asymptotically optimal sampling proportions via SOCP.

        Uses a closed-form Gaussian approximation for the optimal proportions.
        Returns ``None`` when the problem is infeasible so the caller can
        fall back to C-tracking.
        """

        # Reference: Garivier & Kaufmann (2016), "Optimal Best Arm
        # Identification with Fixed Confidence".
        #
        # For K arms with estimated means mu_1 >= mu_2 >= ... >= mu_K, the
        # SOCP finds w* = argmax_{w in simplex} min_{a != 1} sum_k w_k * kl(mu_k, lambda_{1,a}(w))
        #
        # We solve the dual relaxation: maximise t subject to
        #   for each alternative a != best:  sum_k w_k * kl(mu_k, c_a) >= t
        #   w in simplex
        #
        # This is a second-order cone program when we approximate KL with
        # quadratic (Gaussian case) or linearise (Bernoulli).

        means = [(vid, self._arms[vid].mean) for vid in self._variant_ids]
        means.sort(key=lambda x: -x[1])
        best_vid = means[0][0]
        best_mu = means[0][1]

        gaps = {}
        for vid, mu in means[1:]:
            gap = best_mu - mu
            if gap < 1e-10:
                gap = 1e-10
            gaps[vid] = gap

        # For the SOCP formulation we use the Gaussian approximation:
        # kl(mu_a, lambda) ≈ (mu_a - lambda)^2 / (2 * sigma_a^2)
        #
        # The optimal proportions for the "transportation cost" simplify to:
        # w*_best = sum_{a!=best} w*_a  (leader gets half)
        # w*_a proportional to sigma_a / gap_a for a != best
        #
        # We implement this closed-form rather than calling the full solver
        # to keep the dependency lightweight while still getting SOCP-quality
        # allocations.

        try:
            raw_weights: dict[str, float] = {}
            for vid, gap in gaps.items():
                sigma = math.sqrt(self._arms[vid].variance)
                raw_weights[vid] = sigma / gap

            total_alt = sum(raw_weights.values())
            if total_alt < 1e-15:
                return None

            props: dict[str, float] = {}
            # Best arm gets half the budget
            props[best_vid] = 0.5
            for vid, rw in raw_weights.items():
                props[vid] = 0.5 * (rw / total_alt)

            # Normalise to ensure exact simplex membership
            total = sum(props.values())
            props = {vid: w / total for vid, w in props.items()}
            return props
        except Exception:
            logger.debug("SOCP solve failed, falling back to C-tracking", exc_info=True)
            return None

    def _c_tracking_fallback(self) -> dict[str, float]:
        """C-tracking: proportional to ``1 / gap²`` where gap = mu_best - mu_a.

        The best arm receives a proportion equal to the sum of all others
        (so it is pulled roughly half the time).
        """
        means = {vid: self._arms[vid].mean for vid in self._variant_ids}
        best_vid = max(means, key=means.get)  # type: ignore[arg-type]
        best_mu = means[best_vid]

        raw: dict[str, float] = {}
        for vid in self._variant_ids:
            if vid == best_vid:
                continue
            gap = max(best_mu - means[vid], 1e-10)
            raw[vid] = 1.0 / (gap * gap)

        total_alt = sum(raw.values())
        if total_alt < 1e-15:
            # All means identical — uniform
            return {vid: 1.0 / self._K for vid in self._variant_ids}

        props: dict[str, float] = {}
        for vid, rw in raw.items():
            props[vid] = 0.5 * (rw / total_alt)
        props[best_vid] = 0.5

        total = sum(props.values())
        return {vid: w / total for vid, w in props.items()}

    # ----- GLRT stopping rule -----------------------------------------------

    def _check_glrt(self) -> bool:
        """Check if the GLRT statistic Z(t) exceeds beta(t, delta).

        Z(t) = min over alternatives a of: sum_k N_k * kl(mu_k, mu^*)
        where mu^* is chosen to minimise the sum over the alternative
        hypothesis.

        Simplified: Z(t) = min_{a != best} [ N_best * kl(mu_best, lam) + N_a * kl(mu_a, lam) ]
        where lam = (N_best * mu_best + N_a * mu_a) / (N_best + N_a)
        """
        z = self._compute_glrt()
        beta = self._beta_threshold()
        return z > beta

    def _compute_glrt(self) -> float:
        """Compute the GLRT statistic Z(t)."""
        means = {vid: self._arms[vid].mean for vid in self._variant_ids}
        counts = {vid: self._arms[vid].count for vid in self._variant_ids}

        best_vid = max(means, key=means.get)  # type: ignore[arg-type]
        mu_best = means[best_vid]
        n_best = counts[best_vid]

        min_stat = float("inf")
        for vid in self._variant_ids:
            if vid == best_vid:
                continue

            mu_a = means[vid]
            n_a = counts[vid]

            if n_best + n_a == 0:
                min_stat = 0.0
                break

            # MLE under the alternative: weighted mean
            lam = (n_best * mu_best + n_a * mu_a) / (n_best + n_a)

            stat = n_best * self._kl(mu_best, lam) + n_a * self._kl(mu_a, lam)
            if stat < min_stat:
                min_stat = stat

        return min_stat

    def _kl(self, p: float, q: float) -> float:
        """Compute KL divergence between two distributions.

        For Bernoulli: kl(p, q) = p * log(p/q) + (1-p) * log((1-p)/(1-q))
        For Gaussian:  kl(mu, nu) ≈ (mu - nu)^2 / (2 * sigma^2)
        """
        if self._reward_type == "bernoulli":
            return self._kl_bernoulli(p, q)
        else:
            return self._kl_gaussian(p, q)

    @staticmethod
    def _kl_bernoulli(p: float, q: float) -> float:
        """KL divergence for Bernoulli distributions."""
        # Clamp to avoid log(0)
        p = max(min(p, 1.0 - 1e-15), 1e-15)
        q = max(min(q, 1.0 - 1e-15), 1e-15)
        return p * math.log(p / q) + (1.0 - p) * math.log((1.0 - p) / (1.0 - q))

    @staticmethod
    def _kl_gaussian(mu: float, nu: float, sigma_sq: float = 1.0) -> float:
        """KL divergence approximation for Gaussian distributions."""
        return (mu - nu) ** 2 / (2.0 * max(sigma_sq, 1e-15))

    def _beta_threshold(self) -> float:
        """Anytime-valid confidence threshold: log(1/delta) + K * log(log(t)).

        Uses the standard threshold from Garivier & Kaufmann (2016) for
        Track-and-Stop with GLRT.
        """
        t = max(self._total_pulls, 1)
        log_log_t = math.log(max(math.log(max(t, math.e)), 1.0))
        return math.log(1.0 / self._delta) + self._K * log_log_t

    # ----- helpers -----------------------------------------------------------

    def _empirical_best(self) -> Optional[str]:
        if not self._arms:
            return None
        return max(self._arms.values(), key=lambda a: a.mean).variant_id


# ---------------------------------------------------------------------------
# Thompson Sampling wrapper
# ---------------------------------------------------------------------------

class ThompsonBandit(BanditBase):
    """Thin wrapper around :class:`~coreiq.evolution.bandit.PromptBandit`.

    Adapts the existing Thompson-sampling implementation to the
    :class:`BanditBase` interface so it can be used interchangeably with
    :class:`TrackAndStopBandit`.

    ``should_stop()`` always returns ``False`` — Thompson sampling is an
    explore/exploit policy, not a best-arm identification algorithm.
    """

    def __init__(self, variant_ids: list[str]) -> None:
        from ..evolution.bandit import PromptBandit

        self._lock = threading.Lock()
        self._inner = PromptBandit(variant_ids)

    def select(self) -> str:
        with self._lock:
            return self._inner.select()

    def update(self, variant_id: str, reward: float) -> None:
        with self._lock:
            self._inner.reward(variant_id, max(0.0, min(1.0, reward)))

    def best(self) -> Optional[str]:
        with self._lock:
            return self._inner.best()

    def should_stop(self) -> bool:
        return False

    def stats(self) -> list[dict[str, Any]]:
        with self._lock:
            return self._inner.stats()

    def state_dict(self) -> dict[str, Any]:
        with self._lock:
            arms_data: dict[str, dict[str, float]] = {}
            for vid, arm in self._inner.items():
                arms_data[vid] = {"alpha": arm.alpha, "beta": arm.beta}
            return {
                "algorithm": "thompson_sampling",
                "variant_ids": [vid for vid, _ in self._inner.items()],
                "arms": arms_data,
            }

    @classmethod
    def from_state_dict(cls, data: dict[str, Any]) -> "ThompsonBandit":
        variant_ids = data.get("variant_ids", [])
        bandit = cls(variant_ids)
        for vid, arm_data in data.get("arms", {}).items():
            bandit._inner.restore_arm(vid, arm_data["alpha"], arm_data["beta"])
        return bandit


# ---------------------------------------------------------------------------
# Multi-Arm stats for multi-objective bandits
# ---------------------------------------------------------------------------

@dataclass
class MultiArmStats:
    """Per-arm statistics across multiple objectives."""

    variant_id: str
    objectives: Dict[str, ArmStats] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Multi-Objective Bandit (Pareto-Thompson Sampling)
# ---------------------------------------------------------------------------

class MultiObjectiveBandit(BanditBase):
    """Scalarized Pareto-Thompson Sampling.

    Each arm maintains independent Beta posteriors per objective.

    **Selection algorithm:**

    1. Sample weights from ``Dirichlet(preference_prior)`` to randomise
       the trade-off among objectives each round.
    2. For every arm, sample each per-objective Beta posterior.
    3. Scalarise the sampled vector (weighted-sum or Chebyshev).
    4. Pick the arm with the highest scalarised value.

    **Stopping rule:**

    Per-objective GLRT with Bonferroni correction across D objectives.
    The experiment stops when one variant Pareto-dominates all others
    with high confidence.

    Parameters
    ----------
    variant_ids:
        Identifiers for each arm (at least 2).
    objective_names:
        Names of the objectives being optimised.
    directions:
        Mapping of objective_name -> ``"max"`` or ``"min"``.
    preference_prior:
        Dirichlet concentration parameters per objective.
        Defaults to uniform ``[1.0, 1.0, ...]``.
    scalarization:
        ``"weighted_sum"`` or ``"chebyshev"``.
    auto_cost:
        Reserved for automatic cost-objective injection (future use).
    auto_latency:
        Reserved for automatic latency-objective injection (future use).
    """

    def __init__(
        self,
        variant_ids: List[str],
        *,
        objective_names: List[str],
        directions: Dict[str, str],
        preference_prior: Optional[List[float]] = None,
        scalarization: str = "weighted_sum",
        auto_cost: bool = False,
        auto_latency: bool = False,
    ) -> None:
        if len(variant_ids) < 2:
            raise ValueError("MultiObjectiveBandit requires at least 2 variants")
        if not objective_names:
            raise ValueError("At least one objective is required")
        for name in objective_names:
            if directions.get(name) not in ("max", "min"):
                raise ValueError(
                    f"Direction for '{name}' must be 'max' or 'min', got {directions.get(name)!r}"
                )
        if scalarization not in ("weighted_sum", "chebyshev"):
            raise ValueError(f"Unknown scalarization: {scalarization!r}")

        self._lock = threading.Lock()
        self._variant_ids = list(variant_ids)
        self._objective_names = list(objective_names)
        self._directions = dict(directions)
        self._scalarization = scalarization
        self._auto_cost = auto_cost
        self._auto_latency = auto_latency
        self._D = len(objective_names)

        if preference_prior is not None:
            if len(preference_prior) != self._D:
                raise ValueError(
                    f"preference_prior length ({len(preference_prior)}) must match "
                    f"number of objectives ({self._D})"
                )
            self._preference_prior = list(preference_prior)
        else:
            self._preference_prior = [1.0] * self._D

        # Per-arm, per-objective Beta posteriors: alpha, beta start at (1, 1).
        # We store as ArmStats for compatibility.
        self._arms: Dict[str, Dict[str, ArmStats]] = {}
        for vid in variant_ids:
            self._arms[vid] = {}
            for obj_name in objective_names:
                self._arms[vid][obj_name] = ArmStats(variant_id=vid)

        self._total_pulls = 0
        self._delta = 0.05  # Confidence level for stopping rule

        # Lazy import of ParetoFrontier to avoid circular imports at module level
        self._frontier_obj: Any = None

    # ----- Dirichlet sampling ------------------------------------------------

    def _sample_dirichlet(self) -> List[float]:
        """Sample from Dirichlet(preference_prior) using Gamma variates."""
        raw = [random.gammavariate(alpha, 1.0) for alpha in self._preference_prior]
        total = sum(raw)
        if total < 1e-15:
            return [1.0 / self._D] * self._D
        return [r / total for r in raw]

    # ----- Beta posterior sampling -------------------------------------------

    @staticmethod
    def _sample_beta(arm: ArmStats) -> float:
        """Sample from the Beta posterior for an arm.

        We interpret the arm's statistics as a Beta distribution:
        alpha = total_reward + 1, beta = (count - total_reward) + 1.
        """
        alpha = max(arm.total_reward + 1.0, 1e-6)
        beta_param = max((arm.count - arm.total_reward) + 1.0, 1e-6)
        return random.betavariate(alpha, beta_param)

    # ----- Scalarisation -----------------------------------------------------

    def _scalarise(
        self,
        sampled_values: Dict[str, float],
        weights: List[float],
    ) -> float:
        """Compute scalarised value from per-objective samples."""
        if self._scalarization == "weighted_sum":
            total = 0.0
            for i, obj_name in enumerate(self._objective_names):
                val = sampled_values.get(obj_name, 0.0)
                # Flip for minimisation objectives so higher is always better
                if self._directions[obj_name] == "min":
                    val = 1.0 - val
                total += weights[i] * val
            return total
        else:
            # Chebyshev: V_a = -max_d( w_d * |z*_d - theta_a_d| )
            # z* = ideal point (1.0 for max, 0.0 for min, both mapped to 1.0 in max-space)
            max_term = 0.0
            for i, obj_name in enumerate(self._objective_names):
                val = sampled_values.get(obj_name, 0.0)
                if self._directions[obj_name] == "min":
                    val = 1.0 - val
                # Ideal is 1.0 in max-space
                term = weights[i] * abs(1.0 - val)
                if term > max_term:
                    max_term = term
            return -max_term  # Negate because we maximise the scalarisation

    # ----- BanditBase interface ----------------------------------------------

    def select(self) -> str:
        """Sample Dirichlet weights, sample Beta posteriors, scalarise, pick argmax."""
        with self._lock:
            weights = self._sample_dirichlet()
            best_vid = self._variant_ids[0]
            best_val = -float("inf")

            for vid in self._variant_ids:
                # Sample per-objective posteriors
                sampled: Dict[str, float] = {}
                for obj_name in self._objective_names:
                    arm = self._arms[vid][obj_name]
                    sampled[obj_name] = self._sample_beta(arm)
                val = self._scalarise(sampled, weights)
                if val > best_val:
                    best_val = val
                    best_vid = vid

            return best_vid

    def update(self, variant_id: str, reward: float) -> None:
        """Single-objective compatibility: maps reward to the first objective."""
        with self._lock:
            self._update_single_locked(variant_id, self._objective_names[0], reward)

    def _update_single_locked(self, variant_id: str, objective_name: str, reward: float) -> None:
        """Update a single arm/objective pair. Must hold self._lock."""
        arms = self._arms.get(variant_id)
        if arms is None:
            logger.warning("Unknown variant_id %s -- ignoring update", variant_id)
            return
        arm = arms.get(objective_name)
        if arm is None:
            logger.warning("Unknown objective %s -- ignoring update", objective_name)
            return
        reward = max(0.0, min(1.0, reward))
        arm.total_reward += reward
        arm.sum_sq += reward * reward
        arm.count += 1
        self._total_pulls += 1
        # Invalidate cached frontier
        self._frontier_obj = None

    def update_multi(self, variant_id: str, rewards: Dict[str, float]) -> None:
        """Multi-objective update: update per-objective posteriors.

        Parameters
        ----------
        variant_id:
            The arm that was pulled.
        rewards:
            Mapping of objective_name -> observed reward value (each in [0, 1]).
        """
        with self._lock:
            for obj_name, reward in rewards.items():
                self._update_single_locked(variant_id, obj_name, reward)

    def best(self) -> Optional[str]:
        """Return the best variant under expected scalarisation.

        Uses uniform weights (equal importance to all objectives) and
        the posterior mean (not sampled).
        """
        with self._lock:
            if not self._variant_ids:
                return None

            uniform_weights = [1.0 / self._D] * self._D
            best_vid = self._variant_ids[0]
            best_val = -float("inf")

            for vid in self._variant_ids:
                means: Dict[str, float] = {}
                for obj_name in self._objective_names:
                    arm = self._arms[vid][obj_name]
                    means[obj_name] = arm.mean
                val = self._scalarise(means, uniform_weights)
                if val > best_val:
                    best_val = val
                    best_vid = vid

            return best_vid

    def pareto_best(self) -> List[str]:
        """Return all Pareto-optimal variant IDs.

        A variant is Pareto-optimal if no other variant is at least as
        good on all objectives and strictly better on at least one.
        """
        with self._lock:

            frontier = self._build_frontier_locked()
            front = frontier.compute_front()
            return [p.variant_id for p in front]

    def should_stop(self) -> bool:
        """True if one variant Pareto-dominates all others with confidence.

        Uses per-objective GLRT with Bonferroni correction: for D objectives,
        the per-objective confidence threshold uses ``delta / D``.
        """
        with self._lock:
            return self._check_stopping_locked()

    def _check_stopping_locked(self) -> bool:
        """Check multi-objective stopping condition. Must hold self._lock."""
        if self._total_pulls < 2 * len(self._variant_ids) * self._D:
            return False

        # Find potential dominator: for each candidate, check if it
        # dominates all others on every objective with sufficient confidence.
        adjusted_delta = self._delta / self._D  # Bonferroni correction

        for candidate_vid in self._variant_ids:
            dominates_all = True
            for other_vid in self._variant_ids:
                if other_vid == candidate_vid:
                    continue
                # For each objective, check if candidate is better with confidence
                all_obj_better = True
                for obj_name in self._objective_names:
                    c_arm = self._arms[candidate_vid][obj_name]
                    o_arm = self._arms[other_vid][obj_name]

                    if c_arm.count < 2 or o_arm.count < 2:
                        all_obj_better = False
                        break

                    # KL-based test: check if the gap is significant
                    c_mean = c_arm.mean
                    o_mean = o_arm.mean

                    # Flip for min objectives: we want candidate to be lower
                    if self._directions[obj_name] == "min":
                        c_mean, o_mean = 1.0 - c_mean, 1.0 - o_mean

                    if c_mean <= o_mean:
                        all_obj_better = False
                        break

                    # GLRT statistic for this pair on this objective
                    n_c = c_arm.count
                    n_o = o_arm.count
                    # Weighted mean under null (they are equal)
                    lam = (n_c * c_mean + n_o * o_mean) / (n_c + n_o)
                    # KL divergence (Bernoulli)
                    kl_c = self._kl_bernoulli(c_mean, lam)
                    kl_o = self._kl_bernoulli(o_mean, lam)
                    stat = n_c * kl_c + n_o * kl_o

                    # Threshold: beta(t, delta/D)
                    t = max(self._total_pulls, 1)
                    log_log_t = math.log(max(math.log(max(t, math.e)), 1.0))
                    K = len(self._variant_ids)
                    threshold = math.log(1.0 / adjusted_delta) + K * log_log_t

                    if stat <= threshold:
                        all_obj_better = False
                        break

                if not all_obj_better:
                    dominates_all = False
                    break

            if dominates_all:
                return True

        return False

    @staticmethod
    def _kl_bernoulli(p: float, q: float) -> float:
        """KL divergence for Bernoulli distributions."""
        p = max(min(p, 1.0 - 1e-15), 1e-15)
        q = max(min(q, 1.0 - 1e-15), 1e-15)
        return p * math.log(p / q) + (1.0 - p) * math.log((1.0 - p) / (1.0 - q))

    def frontier(self) -> Any:
        """Return the current :class:`ParetoFrontier` object."""
        with self._lock:
            return self._build_frontier_locked()

    def _build_frontier_locked(self) -> Any:
        """Build a ParetoFrontier from current arm stats. Must hold self._lock."""
        from .pareto import ParetoFrontier

        if self._frontier_obj is not None:
            return self._frontier_obj

        pf = ParetoFrontier(
            objective_names=self._objective_names,
            directions=self._directions,
        )
        for vid in self._variant_ids:
            for obj_name in self._objective_names:
                arm = self._arms[vid][obj_name]
                if arm.count > 0:
                    # Feed in all the accumulated observations as a single mean
                    # (ParetoFrontier tracks its own running stats, so we set
                    # the internal state directly.)
                    pf._data.setdefault(vid, {})
                    from .pareto import ObjectiveValue

                    pf._data[vid][obj_name] = ObjectiveValue(
                        objective_name=obj_name,
                        mean=arm.mean,
                        count=arm.count,
                        variance=arm.variance,
                        direction=self._directions[obj_name],
                        _total=arm.total_reward,
                        _sum_sq=arm.sum_sq,
                    )
        self._frontier_obj = pf
        return pf

    def stats(self) -> List[Dict[str, Any]]:
        with self._lock:
            result: List[Dict[str, Any]] = []
            for vid in self._variant_ids:
                obj_stats: Dict[str, Any] = {}
                for obj_name in self._objective_names:
                    arm = self._arms[vid][obj_name]
                    obj_stats[obj_name] = {
                        "mean_reward": round(arm.mean, 6),
                        "count": arm.count,
                        "variance": round(arm.variance, 6),
                    }
                result.append({
                    "variant_id": vid,
                    "objectives": obj_stats,
                    "total_count": sum(
                        self._arms[vid][o].count for o in self._objective_names
                    ),
                })
            return result

    def state_dict(self) -> Dict[str, Any]:
        with self._lock:
            arms_data: Dict[str, Dict[str, Dict[str, float]]] = {}
            for vid in self._variant_ids:
                arms_data[vid] = {}
                for obj_name in self._objective_names:
                    arm = self._arms[vid][obj_name]
                    arms_data[vid][obj_name] = {
                        "total_reward": arm.total_reward,
                        "count": arm.count,
                        "sum_sq": arm.sum_sq,
                    }
            return {
                "algorithm": "multi_objective",
                "variant_ids": self._variant_ids,
                "objective_names": self._objective_names,
                "directions": self._directions,
                "preference_prior": self._preference_prior,
                "scalarization": self._scalarization,
                "auto_cost": self._auto_cost,
                "auto_latency": self._auto_latency,
                "total_pulls": self._total_pulls,
                "delta": self._delta,
                "arms": arms_data,
            }

    @classmethod
    def from_state_dict(cls, data: Dict[str, Any]) -> "MultiObjectiveBandit":
        bandit = cls(
            data["variant_ids"],
            objective_names=data["objective_names"],
            directions=data["directions"],
            preference_prior=data.get("preference_prior"),
            scalarization=data.get("scalarization", "weighted_sum"),
            auto_cost=data.get("auto_cost", False),
            auto_latency=data.get("auto_latency", False),
        )
        bandit._delta = data.get("delta", 0.05)
        bandit._total_pulls = data.get("total_pulls", 0)
        for vid, obj_data in data.get("arms", {}).items():
            if vid not in bandit._arms:
                continue
            for obj_name, arm_data in obj_data.items():
                if obj_name not in bandit._arms[vid]:
                    continue
                arm = bandit._arms[vid][obj_name]
                arm.total_reward = arm_data["total_reward"]
                arm.count = arm_data["count"]
                arm.sum_sq = arm_data["sum_sq"]
        return bandit
