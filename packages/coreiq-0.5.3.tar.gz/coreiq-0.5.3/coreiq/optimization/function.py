"""Function registry — typed contracts for LLM interactions."""
import json
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from ..store.db import get_shared_connection


class FunctionType(str, Enum):
    chat = "chat"
    json = "json"


@dataclass
class FunctionDef:
    id: str
    name: str
    type: FunctionType
    tenant_id: str = "default"
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None
    created_at: str = ""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class FunctionRegistry:
    """DB-backed registry for function definitions with in-memory cache.

    Functions define the WHAT — a typed contract with input/output schemas.
    Variants (managed by VariantManager) define the HOW.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._cache: Dict[str, FunctionDef] = {}  # name -> FunctionDef
        self._id_cache: Dict[str, FunctionDef] = {}  # id -> FunctionDef
        self._loaded = False

    def _conn(self):
        return get_shared_connection()

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            self._load_all()
            self._loaded = True

    def _load_all(self) -> None:
        conn = self._conn()
        try:
            rows = conn.execute("SELECT * FROM functions").fetchall()
        except Exception:
            rows = []
        for row in rows:
            fd = self._row_to_def(row)
            self._cache[fd.name] = fd
            self._id_cache[fd.id] = fd

    @staticmethod
    def _row_to_def(row) -> FunctionDef:
        _get = row.get if hasattr(row, "get") else lambda k, d=None: row[k]
        input_schema = None
        raw_in = _get("input_schema_json")
        if raw_in:
            input_schema = json.loads(raw_in)
        output_schema = None
        raw_out = _get("output_schema_json")
        if raw_out:
            output_schema = json.loads(raw_out)
        return FunctionDef(
            id=row["id"],
            name=row["name"],
            type=FunctionType(row["type"]),
            tenant_id=_get("tenant_id") or "default",
            input_schema=input_schema,
            output_schema=output_schema,
            created_at=_get("created_at") or "",
        )

    def create(
        self,
        name: str,
        type: FunctionType,
        tenant_id: str = "default",
        input_schema: Optional[Dict[str, Any]] = None,
        output_schema: Optional[Dict[str, Any]] = None,
    ) -> FunctionDef:
        """Create a new function definition. Raises if name already exists."""
        self._ensure_loaded()
        with self._lock:
            if name in self._cache:
                from ..exceptions import ValidationError
                raise ValidationError(f"Function '{name}' already exists")
            fid = str(uuid.uuid4())
            now = _now()
            fd = FunctionDef(
                id=fid, name=name, type=type, tenant_id=tenant_id,
                input_schema=input_schema, output_schema=output_schema,
                created_at=now,
            )
            conn = self._conn()
            conn.execute(
                "INSERT INTO functions(id, tenant_id, name, type, input_schema_json, "
                "output_schema_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (fd.id, fd.tenant_id, fd.name, fd.type.value,
                 json.dumps(fd.input_schema) if fd.input_schema else None,
                 json.dumps(fd.output_schema) if fd.output_schema else None,
                 fd.created_at),
            )
            conn.commit()
            self._cache[name] = fd
            self._id_cache[fd.id] = fd
            return fd

    def get(self, name: str) -> Optional[FunctionDef]:
        """Get a function by name."""
        self._ensure_loaded()
        return self._cache.get(name)

    def get_by_id(self, function_id: str) -> Optional[FunctionDef]:
        """Get a function by ID."""
        self._ensure_loaded()
        return self._id_cache.get(function_id)

    def resolve(self, name_or_id: str) -> Optional[FunctionDef]:
        """Resolve a function by name or ID (pipeline Stage 3)."""
        self._ensure_loaded()
        fd = self._cache.get(name_or_id)
        if fd is not None:
            return fd
        return self._id_cache.get(name_or_id)

    def list(self, tenant_id: Optional[str] = None) -> List[FunctionDef]:
        """Return all functions, optionally filtered by tenant."""
        self._ensure_loaded()
        if tenant_id is None:
            return list(self._cache.values())
        return [f for f in self._cache.values() if f.tenant_id == tenant_id]

    def update(
        self,
        name: str,
        input_schema: Optional[Dict[str, Any]] = ...,  # type: ignore[assignment]
        output_schema: Optional[Dict[str, Any]] = ...,  # type: ignore[assignment]
    ) -> Optional[FunctionDef]:
        """Update a function's schemas. Pass None to clear, omit to leave unchanged."""
        self._ensure_loaded()
        with self._lock:
            fd = self._cache.get(name)
            if fd is None:
                return None
            conn = self._conn()
            updates = []
            params: list = []
            if input_schema is not ...:
                fd.input_schema = input_schema
                updates.append("input_schema_json = ?")
                params.append(json.dumps(input_schema) if input_schema else None)
            if output_schema is not ...:
                fd.output_schema = output_schema
                updates.append("output_schema_json = ?")
                params.append(json.dumps(output_schema) if output_schema else None)
            if updates:
                params.append(fd.id)
                conn.execute(
                    f"UPDATE functions SET {', '.join(updates)} WHERE id = ?",
                    params,
                )
                conn.commit()
            return fd

    def delete(self, name: str, cascade: bool = True) -> bool:
        """Delete a function by name. Returns True if deleted.

        If cascade=True, also deletes all variants, experiments, and
        related records for this function.
        """
        self._ensure_loaded()
        with self._lock:
            fd = self._cache.get(name)
            if fd is None:
                return False
            conn = self._conn()
            if cascade:
                conn.execute("DELETE FROM variants WHERE function_id = ?", (fd.id,))
                conn.execute("DELETE FROM experiments WHERE function_id = ?", (fd.id,))
                conn.execute("DELETE FROM dicl_examples WHERE function_id = ?", (fd.id,))
                conn.execute("DELETE FROM finetune_jobs WHERE function_id = ?", (fd.id,))
            conn.execute("DELETE FROM functions WHERE id = ?", (fd.id,))
            conn.commit()
            del self._cache[name]
            del self._id_cache[fd.id]
            return True

    def validate_input(self, name: str, input_data: Any) -> None:
        """Validate input data against the function's input schema.

        Raises ValidationError if validation fails. No-op if no schema defined.
        """
        fd = self.get(name)
        if fd is None:
            from ..exceptions import ValidationError
            raise ValidationError(f"Unknown function: {name!r}")
        if fd.input_schema is None:
            return
        try:
            import jsonschema
            jsonschema.validate(instance=input_data, schema=fd.input_schema)
        except ImportError:
            # jsonschema not installed — skip validation
            return
        except jsonschema.ValidationError as e:
            from ..exceptions import ValidationError
            raise ValidationError(f"Input validation failed for '{name}': {e.message}")

    def validate_output(self, name: str, output_data: Any) -> None:
        """Validate output data against the function's output schema.

        Raises ValidationError if validation fails. No-op if no schema or chat type.
        """
        fd = self.get(name)
        if fd is None:
            from ..exceptions import ValidationError
            raise ValidationError(f"Unknown function: {name!r}")
        if fd.output_schema is None or fd.type == FunctionType.chat:
            return
        try:
            import jsonschema
            jsonschema.validate(instance=output_data, schema=fd.output_schema)
        except ImportError:
            return
        except jsonschema.ValidationError as e:
            from ..exceptions import ValidationError
            raise ValidationError(f"Output validation failed for '{name}': {e.message}")

    def invalidate_cache(self) -> None:
        """Force reload from DB on next access."""
        with self._lock:
            self._cache.clear()
            self._id_cache.clear()
            self._loaded = False
