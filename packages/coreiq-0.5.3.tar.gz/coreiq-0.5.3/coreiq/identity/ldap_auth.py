"""LDAP / Active Directory authentication for CoreIQ.

Performs a bind+search against an LDAP/AD server to authenticate a service
account and extract its group memberships.  Group names are normalised to
their Common Name (CN) before being matched against CoreIQ group policies.

Requires: ``ldap3>=2.9``  (``pip install 'coreiq[identity]'``)
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import ldap3 as _ldap3_type  # noqa: F401

from .models import IdPUser, IdentityConfig

logger = logging.getLogger(__name__)


def _import_ldap3():
    """Lazy-import ldap3; raises a clear error if not installed."""
    try:
        import ldap3
        from ldap3.core.exceptions import LDAPBindError, LDAPException
        return ldap3, LDAPBindError, LDAPException
    except ImportError as exc:
        raise ImportError(
            "ldap3 is required for LDAP/AD authentication. "
            "Install it: pip install 'coreiq[identity]'"
        ) from exc


def _extract_cn(dn: str) -> str:
    """Extract the CN value from a distinguished name string.

    Example: ``CN=ml-engineers,OU=Groups,DC=acme,DC=com`` → ``ml-engineers``
    """
    for part in dn.split(","):
        part = part.strip()
        if part.upper().startswith("CN="):
            return part[3:]
    return dn


def authenticate_ldap(
    username: str,
    password: str,
    config: IdentityConfig,
    *,
    tenant_id: str = "default",
) -> IdPUser:
    """Authenticate *username* against the configured LDAP/AD server.

    Parameters
    ----------
    username:
        SAM account name (e.g. ``svc-mlteam``) or full UPN
        (``svc-mlteam@acme.com``).
    password:
        Account password.
    config:
        Resolved :class:`IdentityConfig`.
    tenant_id:
        Tenant to scope the resulting :class:`IdPUser` to.

    Returns
    -------
    IdPUser
        Normalised user record with groups populated.

    Raises
    ------
    ValueError
        On bind failure, search error, or missing configuration.
    """
    ldap3, LDAPBindError, LDAPException = _import_ldap3()

    if not config.ldap_url:
        raise ValueError("COREIQ_LDAP_URL is not configured")
    if not config.ldap_base_dn:
        raise ValueError("COREIQ_LDAP_BASE_DN is not configured")

    # Build the bind DN. Accept:
    #   svc-user          → svc-user@domain  (if domain configured)
    #   svc-user@acme.com → used as-is
    #   CN=svc-user,...   → used as-is
    import re as _re
    domain = config.ldap_domain.strip()
    if domain and not _re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9\-\.]{0,251}[A-Za-z0-9])?", domain):
        raise ValueError("COREIQ_LDAP_DOMAIN contains invalid characters")
    if "@" in username or username.upper().startswith("CN="):
        bind_user = username
    elif domain:
        bind_user = f"{username}@{domain}"
    else:
        bind_user = username

    try:
        server = ldap3.Server(config.ldap_url, get_info=ldap3.ALL, connect_timeout=5)
        conn = ldap3.Connection(
            server,
            user=bind_user,
            password=password,
            auto_bind=ldap3.AUTO_BIND_NO_TLS,
            raise_exceptions=True,
        )
        conn.bind()
    except LDAPBindError as exc:
        raise ValueError(f"LDAP authentication failed for {username!r}: {exc}") from exc
    except LDAPException as exc:
        raise ValueError(f"LDAP connection error: {exc}") from exc

    # Search for the user to get groups and attributes
    try:
        from ldap3.utils.conv import escape_filter_chars
        sam = escape_filter_chars(username.split("@")[0])  # strip domain + escape for LDAP filter safety
        conn.search(
            search_base=config.ldap_base_dn,
            search_filter=f"(sAMAccountName={sam})",
            search_scope=ldap3.SUBTREE,
            attributes=["memberOf", "mail", "displayName", "distinguishedName"],
        )
    except LDAPException as exc:
        raise ValueError(f"LDAP search failed: {exc}") from exc

    if not conn.entries:
        raise ValueError(f"User {username!r} not found in LDAP base DN {config.ldap_base_dn!r}")

    entry = conn.entries[0]

    raw_groups = []
    if hasattr(entry, "memberOf") and entry.memberOf:
        val = entry.memberOf.value
        if isinstance(val, list):
            raw_groups = val
        elif val:
            raw_groups = [val]

    groups = [_extract_cn(g) for g in raw_groups]

    email = ""
    if hasattr(entry, "mail") and entry.mail:
        email = str(entry.mail.value or "")

    display_name = ""
    if hasattr(entry, "displayName") and entry.displayName:
        display_name = str(entry.displayName.value or "")

    # Use distinguishedName as the stable sub identifier
    sub = ""
    if hasattr(entry, "distinguishedName") and entry.distinguishedName:
        sub = str(entry.distinguishedName.value or "")
    sub = sub or bind_user

    logger.info(
        "LDAP auth OK: username=%s email=%s groups=%s",
        username, email, groups,
    )

    return IdPUser(
        sub=sub,
        idp="ldap",
        email=email or bind_user,
        display_name=display_name or username,
        groups=groups,
        tenant_id=tenant_id,
    )
