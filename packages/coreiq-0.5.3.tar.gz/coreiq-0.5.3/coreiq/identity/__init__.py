"""Enterprise identity integration for CoreIQ.

Provides OIDC (Azure AD, Google Workspace, Okta) and LDAP/AD authentication
that auto-provisions long-lived CoreIQ virtual keys (AK/SK model).

Usage::

    # One-time provisioning — exchange IdP identity for a CoreIQ virtual key
    POST /auth/provision
    {
        "idp": "azure",
        "token": "<IdP JWT>",
        "tenant_id": "acme",
        "name": "ml-service-prod"
    }
    # → {"key": "sk-coreiq-xxx", ...}   ← store this, shown only once

    # Runtime — no IdP involved, just the key
    Authorization: Bearer sk-coreiq-xxx
"""
from .models import IdPUser, GroupPolicy, IdentityConfig, ProvisionRequest, ProvisionResponse
from .scim import SCIMHandler

__all__ = [
    "IdPUser",
    "GroupPolicy",
    "IdentityConfig",
    "ProvisionRequest",
    "ProvisionResponse",
    "SCIMHandler",
]
