"""OIDC JWT validation for Azure AD, Google Workspace, and Okta.

Validates IdP-issued JWTs via JWKS (JSON Web Key Sets) fetched from the
IdP's OpenID Connect discovery document.  JWKS are cached for 1 hour to
avoid hitting the IdP on every provisioning call.

Supported providers:
- **Azure AD / Entra ID** — ``https://login.microsoftonline.com/{tenant}/v2.0``
- **Google Workspace** — ``https://accounts.google.com``
- **Okta** — ``https://{domain}/oauth2/default``
"""
from __future__ import annotations

import logging
import time
from typing import Any, Optional

try:
    import httpx
except ImportError as exc:
    raise ImportError(
        "httpx is required for OIDC validation. "
        "Install it: pip install 'coreiq[identity]'"
    ) from exc

try:
    from jose import jwt, JWTError, ExpiredSignatureError
except ImportError as exc:
    raise ImportError(
        "python-jose is required for OIDC validation. "
        "Install it: pip install 'coreiq[identity]'"
    ) from exc

from .models import IdPUser, IdentityConfig

logger = logging.getLogger(__name__)

# JWKS cache: issuer_url → (jwks_dict, fetched_at)
_JWKS_CACHE: dict[str, tuple[dict, float]] = {}
_JWKS_CACHE_TTL = 3600  # 1 hour

# Well-known OIDC discovery paths per provider
_DISCOVERY_URLS: dict[str, str] = {
    "azure": "https://login.microsoftonline.com/{azure_tenant}/v2.0/.well-known/openid-configuration",
    "google": "https://accounts.google.com/.well-known/openid-configuration",
    "okta": "https://{okta_domain}/.well-known/openid-configuration",
}

# Group claim names per provider (in priority order)
_GROUP_CLAIMS: dict[str, list[str]] = {
    "azure": ["groups", "roles"],
    "google": ["groups", "hd"],   # hd = hosted domain (Workspace)
    "okta": ["groups", "roles"],
}


def _get_discovery_url(idp: str, config: IdentityConfig) -> str:
    template = _DISCOVERY_URLS[idp]
    return template.format(
        azure_tenant=config.oidc_azure_tenant or "common",
        okta_domain=config.oidc_okta_domain,
    )


def _fetch_jwks(jwks_uri: str) -> dict:
    """Fetch JWKS from *jwks_uri*, with 1-hour in-memory cache.

    Implements a stale-on-error pattern: if the cache TTL has expired and
    the upstream IdP refresh fails with a network/HTTP error, return the
    *most recent* cached JWKS rather than propagating the failure. This
    prevents a transient IdP outage from causing a total auth outage on
    cold-cache renewal.

    A WARNING is logged whenever stale data is served. We only raise if
    we have no cached value at all (true cold start with IdP unreachable).
    """
    cached = _JWKS_CACHE.get(jwks_uri)
    if cached and (time.time() - cached[1]) < _JWKS_CACHE_TTL:
        return cached[0]

    logger.debug("Fetching JWKS from %s", jwks_uri)
    try:
        resp = httpx.get(jwks_uri, timeout=10.0)
        resp.raise_for_status()
        jwks = resp.json()
    except httpx.HTTPError as exc:
        if cached is not None:
            logger.warning(
                "JWKS refresh failed for %s (%s) - serving stale cache "
                "(age=%.0fs). IdP availability should be investigated.",
                jwks_uri, exc, time.time() - cached[1],
            )
            return cached[0]
        raise
    _JWKS_CACHE[jwks_uri] = (jwks, time.time())
    return jwks


def _get_jwks_uri(idp: str, config: IdentityConfig) -> str:
    """Fetch the JWKS URI from the OIDC discovery document (cached)."""
    discovery_url = _get_discovery_url(idp, config)
    cache_key = f"_discovery_{discovery_url}"
    cached = _JWKS_CACHE.get(cache_key)
    if cached and (time.time() - cached[1]) < _JWKS_CACHE_TTL:
        return cached[0]["jwks_uri"]

    resp = httpx.get(discovery_url, timeout=10.0)
    resp.raise_for_status()
    doc = resp.json()
    _JWKS_CACHE[cache_key] = (doc, time.time())
    return doc["jwks_uri"]


def _extract_groups(claims: dict[str, Any], idp: str) -> list[str]:
    """Extract group/role memberships from JWT claims."""
    for claim_key in _GROUP_CLAIMS.get(idp, ["groups"]):
        val = claims.get(claim_key)
        if val is None:
            continue
        if isinstance(val, list):
            return [str(g) for g in val]
        if isinstance(val, str):
            return [val]
    return []


def _get_audience(idp: str, config: IdentityConfig) -> Optional[str]:
    mapping = {
        "azure": config.oidc_azure_audience,
        "google": config.oidc_google_audience,
        "okta": config.oidc_okta_audience,
    }
    return mapping.get(idp) or None


# Wave 2B P1: clock-skew tolerance applied to ``exp`` and ``nbf`` checks.
# 30 seconds is the standard tolerance recommended by RFC 7519 §4.1.4 /
# §4.1.5 implementations and matches what AWS Cognito, Auth0, and
# Microsoft Identity Platform document for default clock-skew handling.
_OIDC_LEEWAY_SECONDS = 30


def validate_oidc_token(
    token: str,
    idp: str,
    config: IdentityConfig,
) -> IdPUser:
    """Validate an IdP-issued JWT and return a normalised :class:`IdPUser`.

    Parameters
    ----------
    token:
        The raw JWT string from the IdP (access token or id token).
    idp:
        Provider identifier: ``"azure"``, ``"google"``, or ``"okta"``.
    config:
        Resolved :class:`IdentityConfig` (from ``get_identity_config()``).

    Raises
    ------
    ValueError
        If the token is invalid, expired, or the issuer/audience doesn't match.
    """
    if idp not in _DISCOVERY_URLS:
        raise ValueError(f"Unsupported OIDC provider: {idp!r}. Supported: {list(_DISCOVERY_URLS)}")

    try:
        jwks_uri = _get_jwks_uri(idp, config)
        jwks = _fetch_jwks(jwks_uri)
    except Exception as exc:
        raise ValueError(f"Failed to fetch JWKS from {idp} IdP: {exc}") from exc

    audience = _get_audience(idp, config)
    # Wave 2B P1: enable nbf check + 30s clock-skew leeway (RFC 7519 §4.1.5).
    options: dict[str, Any] = {
        "verify_exp": True,
        "verify_nbf": True,
        "verify_aud": bool(audience),
        "leeway": _OIDC_LEEWAY_SECONDS,
    }

    try:
        claims = jwt.decode(
            token,
            jwks,
            algorithms=["RS256", "RS384", "RS512"],
            audience=audience,
            options=options,
        )
    except ExpiredSignatureError as exc:
        raise ValueError("IdP token has expired. Re-authenticate and try again.") from exc
    except JWTError as exc:
        raise ValueError(f"IdP token validation failed: {exc}") from exc

    # Wave 2B P1: validate ``azp`` (authorized party) for Google tokens.
    # Google docs explicitly require the relying party to verify ``azp``
    # equals its own client_id when present, to defeat token-substitution
    # attacks across Google clients sharing the same audience.
    if idp == "google":
        azp = claims.get("azp")
        expected_client_id = audience  # google_audience is the OAuth client_id
        if azp and expected_client_id and azp != expected_client_id:
            raise ValueError(
                f"IdP token validation failed: azp claim '{azp}' does not "
                f"match configured client_id"
            )

    sub = claims.get("sub") or claims.get("oid") or ""
    if not sub:
        raise ValueError("IdP token missing 'sub' claim")

    email = (
        claims.get("email")
        or claims.get("preferred_username")
        or claims.get("upn")
        or ""
    )
    display_name = claims.get("name") or claims.get("display_name") or email
    groups = _extract_groups(claims, idp)

    # Tenant hint: Azure puts tid in the token, Google uses hd (hosted domain)
    tenant_hint = (
        claims.get("tid")          # Azure
        or claims.get("hd")        # Google Workspace
        or ""
    )

    logger.info(
        "OIDC validation OK: idp=%s sub=%s email=%s groups=%s",
        idp, sub, email, groups,
    )

    return IdPUser(
        sub=sub,
        idp=idp,  # type: ignore[arg-type]
        email=email,
        display_name=display_name,
        groups=groups,
        tenant_id=tenant_hint or "default",
        raw_claims=claims,
    )
