"""Short-lived agent token minting for service-to-service calls.

Ported from sdk-go's MintAgentToken pattern. Creates scoped JWTs
with TTL clamped to [1, 300] seconds for agent-to-agent delegation.
"""
from __future__ import annotations
import json
import logging
import time
import uuid
import hmac
import hashlib
import base64
from dataclasses import dataclass
from typing import Optional
from ..config import get_api_key

logger = logging.getLogger("coreiq.identity.agent_tokens")

@dataclass
class AgentToken:
    token: str
    expires_in_seconds: int
    agent_chain: list[str]
    target_service: str
    scopes: list[str]

class AgentTokenService:
    """Mint and validate short-lived agent tokens."""

    def __init__(self, secret: str = ""):
        resolved = secret or get_api_key()
        if not resolved:
            raise RuntimeError(
                "AgentTokenService requires a secret. Set COREIQ_API_KEY or pass secret= explicitly."
            )
        self._secret = resolved

    def mint(
        self,
        parent_token: str,
        target_service: str,
        scopes: list[str],
        ttl_seconds: int = 60,
    ) -> AgentToken:
        """Mint a short-lived scoped token for agent-to-agent calls.

        TTL is clamped to [1, 300] seconds (sdk-go pattern).
        """
        ttl_seconds = max(1, min(300, ttl_seconds))

        # Build token payload
        now = int(time.time())
        token_id = str(uuid.uuid4())
        payload = {
            "jti": token_id,
            "iss": "coreiq",
            "sub": f"agent:{target_service}",
            "iat": now,
            "exp": now + ttl_seconds,
            "scopes": scopes,
            "target": target_service,
            "parent": _hash_token(parent_token),
        }

        # Sign with HMAC-SHA256 (lightweight, no JWT library needed)
        payload_b64 = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
        header_b64 = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"AGT"}').decode().rstrip("=")
        signing_input = f"{header_b64}.{payload_b64}"
        signature = hmac.new(self._secret.encode(), signing_input.encode(), hashlib.sha256).digest()
        sig_b64 = base64.urlsafe_b64encode(signature).decode().rstrip("=")

        token = f"{signing_input}.{sig_b64}"

        logger.info("Minted agent token for %s (TTL=%ds, scopes=%s)", target_service, ttl_seconds, scopes)

        return AgentToken(
            token=token,
            expires_in_seconds=ttl_seconds,
            agent_chain=[_hash_token(parent_token), token_id],
            target_service=target_service,
            scopes=scopes,
        )

    def validate(self, token: str) -> Optional[dict]:
        """Validate an agent token. Returns payload if valid, None if expired/invalid."""
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return None

            # Verify signature
            signing_input = f"{parts[0]}.{parts[1]}"
            expected_sig = hmac.new(self._secret.encode(), signing_input.encode(), hashlib.sha256).digest()
            expected_b64 = base64.urlsafe_b64encode(expected_sig).decode().rstrip("=")
            if not hmac.compare_digest(parts[2], expected_b64):
                return None

            # Decode payload
            padding = 4 - len(parts[1]) % 4
            payload_bytes = base64.urlsafe_b64decode(parts[1] + "=" * padding)
            payload = json.loads(payload_bytes)

            # Check expiry
            if payload.get("exp", 0) < time.time():
                return None

            return payload
        except Exception:
            return None


def _hash_token(token: str) -> str:
    """Hash a token for safe storage in the agent chain."""
    return hashlib.sha256(token.encode()).hexdigest()[:16]
