"""Data models for the CoreIQ enterprise identity system."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional


@dataclass
class IdPUser:
    """Normalised identity extracted from any supported IdP.

    This is the common representation produced by OIDC JWT validation or
    LDAP bind+search. It is then passed to :class:`KeyProvisioner` which
    converts it into a CoreIQ virtual key.
    """

    # Stable unique identifier within the IdP (e.g. Azure objectId, LDAP DN)
    sub: str
    # IdP type that produced this user record
    idp: Literal["azure", "google", "okta", "ldap"]
    # User email — used as a human-readable label on the generated key
    email: str = ""
    # Display name (optional, used for key name if caller doesn't provide one)
    display_name: str = ""
    # Group memberships extracted from the IdP token / LDAP search
    groups: list[str] = field(default_factory=list)
    # Tenant hint from the IdP token (may be overridden by the request body)
    tenant_id: str = "default"
    # Raw claims from the JWT or LDAP attributes (for debugging / audit)
    raw_claims: dict[str, Any] = field(default_factory=dict)
    # Data residency region for this user's tenant (e.g. "eu-west-1")
    data_region: str = ""


@dataclass
class GroupPolicy:
    """Policy constraints derived from an IdP group.

    Admins configure these via ``POST /api/group-policies``.  When a user
    is provisioned, all matching group policies are merged (most restrictive
    wins by default, configurable via ``COREIQ_IDENTITY_POLICY_MERGE``).

    At request time, guardrails are re-evaluated live from the group policy
    so that admin changes take effect immediately without re-provisioning.
    """

    id: str
    group_name: str
    tenant_id: str = "default"
    # --- Access control ---
    allowed_models: Optional[list[str]] = None    # None = all models allowed
    denied_models: Optional[list[str]] = None     # Explicit denylist (applied before allowlist)
    allowed_providers: Optional[list[str]] = None # None = all providers allowed
    # --- Rate & budget limits ---
    max_budget_usd: Optional[float] = None        # None = unlimited
    tpm_limit: Optional[int] = None               # None = unlimited
    rpm_limit: Optional[int] = None               # None = unlimited
    # --- Token guardrails ---
    max_input_tokens: Optional[int] = None        # None = unlimited
    max_output_tokens: Optional[int] = None       # None = unlimited
    # --- Role & residency ---
    rbac_role: str = "operator"                   # RBAC role for dashboard access
    data_region: str = ""                         # e.g. "eu-west-1"
    # --- Audit ---
    created_at: str = ""
    updated_at: str = ""
    updated_by: str = ""


@dataclass
class IdentityConfig:
    """Runtime identity configuration resolved from env / TOML."""

    enabled: bool = False
    # OIDC — Azure AD / Entra ID
    oidc_azure_tenant: str = ""
    oidc_azure_audience: str = ""
    # OIDC — Google Workspace
    oidc_google_audience: str = ""
    # OIDC — Okta
    oidc_okta_domain: str = ""
    oidc_okta_audience: str = ""
    # LDAP / Active Directory
    ldap_url: str = ""
    ldap_base_dn: str = ""
    ldap_domain: str = ""
    ldap_bind_dn: str = ""
    ldap_bind_pw: str = ""
    # How to merge multiple group policies: "restrictive" | "permissive"
    policy_merge: str = "restrictive"

    @classmethod
    def from_config_dict(cls, d: dict[str, Any]) -> "IdentityConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# API request / response models (used by the FastAPI router)
# ---------------------------------------------------------------------------


@dataclass
class ProvisionRequest:
    """Body for ``POST /auth/provision``."""

    idp: Literal["azure", "google", "okta", "ldap"]
    # For OIDC providers: the IdP-issued access token (JWT)
    token: Optional[str] = None
    # For LDAP: service account credentials
    username: Optional[str] = None
    password: Optional[str] = None
    # Optional overrides
    tenant_id: str = "default"
    name: str = ""
    models: Optional[list[str]] = None        # None = use group policy
    max_budget_usd: Optional[float] = None    # None = use group policy
    expires_in_days: Optional[int] = None     # None = never expires


@dataclass
class ProvisionResponse:
    """Response for ``POST /auth/provision``.

    The ``key`` field is shown **exactly once** and never stored by CoreIQ.
    The caller must persist it immediately (Vault, env var, secret manager).
    """

    key: str                        # sk-coreiq-xxx — shown only once
    key_id: str                     # UUID for management (revoke, view usage)
    tenant_id: str
    idp: str
    sub: str                        # IdP subject (for audit)
    email: str
    groups: list[str]
    models_allowed: Optional[list[str]]
    budget_usd: Optional[float]
    expires_at: Optional[str]       # ISO-8601 or None
    provisioned: bool = True        # False if key already existed (re-provision)
