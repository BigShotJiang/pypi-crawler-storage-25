"""JWT/token revocation service.

Ported from sdk-go's RevokeToken/IsRevoked pattern. Maintains a
revocation list in SQLite for real-time token invalidation.
"""
from __future__ import annotations
import logging
import uuid
from datetime import datetime, timezone
from ..store.db import get_shared_connection

logger = logging.getLogger("coreiq.identity.revocation")

class RevocationService:
    """Manage token revocation list."""

    def revoke(self, token_id: str, *, reason: str = "", revoked_by: str = "") -> None:
        """Add a token to the revocation list."""
        conn = get_shared_connection()
        now = datetime.now(timezone.utc).isoformat()
        conn.execute(
            "INSERT OR IGNORE INTO revoked_tokens (id, token_id, reason, revoked_by, revoked_at) VALUES (?,?,?,?,?)",
            (str(uuid.uuid4()), token_id, reason, revoked_by, now)
        )
        conn.commit()
        logger.info("Revoked token %s (reason: %s, by: %s)", token_id, reason, revoked_by)

    def is_revoked(self, token_id: str) -> bool:
        """Check if a token has been revoked."""
        conn = get_shared_connection()
        row = conn.execute(
            "SELECT 1 FROM revoked_tokens WHERE token_id = ? LIMIT 1", (token_id,)
        ).fetchone()
        return row is not None

    def list_revoked(self, limit: int = 100, offset: int = 0) -> list:
        """List revoked tokens."""
        conn = get_shared_connection()
        rows = conn.execute(
            "SELECT * FROM revoked_tokens ORDER BY revoked_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        ).fetchall()
        return [dict(r) for r in rows]

    def cleanup_expired(self, before_ts: str) -> int:
        """Remove revocation entries older than a timestamp (garbage collection)."""
        conn = get_shared_connection()
        cursor = conn.execute("DELETE FROM revoked_tokens WHERE revoked_at < ?", (before_ts,))
        conn.commit()
        return cursor.rowcount
