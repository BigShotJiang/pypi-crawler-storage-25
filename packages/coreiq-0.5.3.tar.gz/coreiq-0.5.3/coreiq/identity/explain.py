"""Structured authorization explanation service.

Ported from sdk-go's ExplainAuthorize pattern. Returns a detailed
breakdown of an authorization decision for debugging and audit.
"""
from __future__ import annotations
import logging
import time
from dataclasses import dataclass, field
from ..store.db import get_shared_connection

logger = logging.getLogger("coreiq.identity.explain")

@dataclass
class ExplainResult:
    request_id: str
    outcome: str  # "allowed" or "denied"
    latency_ms: float
    auth: dict = field(default_factory=dict)
    policy: dict = field(default_factory=dict)
    rate_limit: dict = field(default_factory=dict)
    masking: dict = field(default_factory=dict)
    flags: dict = field(default_factory=dict)

class AuthExplainer:
    """Build structured explanation of an authorization decision."""

    def explain(self, api_key: str, *, request_id: str = "") -> ExplainResult:
        """Explain what would happen for a request with this API key."""
        import uuid
        start = time.monotonic()
        request_id = request_id or str(uuid.uuid4())

        result = ExplainResult(
            request_id=request_id,
            outcome="allowed",
            latency_ms=0,
        )

        get_shared_connection()

        # 1. Auth check - is the key valid?
        if api_key:
            from ..proxy.keys import KeyManager
            km = KeyManager()
            vk = km.validate_key(api_key)
            if vk:
                result.auth = {
                    "status": "valid",
                    "key_id": vk.id,
                    "tenant_id": vk.tenant_id,
                    "models": vk.models,
                    "budget_remaining_usd": vk.max_budget_usd,
                }
            else:
                result.auth = {"status": "invalid_key"}
                result.outcome = "denied"
        else:
            result.auth = {"status": "no_key_provided"}

        # 2. Rate limit check
        try:
            from ..config import get_rate_limit
            limit = get_rate_limit()
            result.rate_limit = {
                "limit_per_minute": limit,
                "status": "disabled" if limit == 0 else "active",
            }
        except Exception:
            result.rate_limit = {"status": "unknown"}

        # 3. Security scanning status
        result.masking = {
            "injection_detection": True,
            "pii_redaction": True,
            "output_guardrails": True,
        }

        # 4. Feature flags sample
        try:
            from ..governance.feature_flags import FlagService
            fs = FlagService()
            flags = fs.list_flags()
            result.flags = {"count": len(flags), "evaluated": "on_request"}
        except Exception:
            result.flags = {"count": 0, "status": "unavailable"}

        result.latency_ms = round((time.monotonic() - start) * 1000, 2)
        return result
