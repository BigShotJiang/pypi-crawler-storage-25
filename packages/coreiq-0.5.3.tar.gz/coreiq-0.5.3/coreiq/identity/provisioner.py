"""KeyProvisioner: exchange IdP identity → CoreIQ long-lived virtual key.

This is the core of the enterprise identity flow.  It:

1. Looks up :class:`GroupPolicy` records for the user's IdP groups.
2. Merges them into a single set of constraints.
3. Revokes any existing active key provisioned for the same IdP subject
   (idempotent re-provisioning).
4. Calls :meth:`KeyManager.generate_key` with the merged constraints.
5. Records the ``idp_sub`` → ``key_id`` mapping in the key's metadata.

The result is a standard CoreIQ virtual key (``sk-coreiq-xxx``) that works
identically in library mode and proxy mode — the IdP is never involved again
at runtime.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Optional

from ..proxy.keys import KeyManager
from ..store.backends.base import StorageBackend

from .models import GroupPolicy, IdPUser, ProvisionResponse

logger = logging.getLogger(__name__)

# Metadata key used to identify IdP-provisioned keys
_IDP_META_KEY = "idp_provisioned"
_IDP_SUB_META_KEY = "idp_sub"
_IDP_TYPE_META_KEY = "idp_type"


def _load_group_policies(
    conn: StorageBackend,
    groups: list[str],
    tenant_id: str,
) -> list[GroupPolicy]:
    """Load all matching :class:`GroupPolicy` records for *groups*."""
    if not groups:
        return []

    placeholders = ",".join("?" * len(groups))
    rows = conn.execute(
        f"""
        SELECT * FROM group_policies
        WHERE group_name IN ({placeholders})
          AND (tenant_id = ? OR tenant_id IS NULL OR tenant_id = '')
        """,
        (*groups, tenant_id),
    ).fetchall()

    def _parse(v):
        if not v:
            return None
        try:
            return json.loads(v)
        except (json.JSONDecodeError, TypeError):
            return None

    policies = []
    for row in rows:
        policies.append(
            GroupPolicy(
                id=row["id"],
                group_name=row["group_name"],
                tenant_id=row["tenant_id"] or "default",
                allowed_models=_parse(row["allowed_models_json"]),
                denied_models=_parse(row["denied_models_json"]) if "denied_models_json" in row.keys() else None,
                allowed_providers=_parse(row["allowed_providers_json"]) if "allowed_providers_json" in row.keys() else None,
                max_budget_usd=row["max_budget_usd"],
                tpm_limit=row["tpm_limit"],
                rpm_limit=row["rpm_limit"],
                max_input_tokens=row["max_input_tokens"] if "max_input_tokens" in row.keys() else None,
                max_output_tokens=row["max_output_tokens"] if "max_output_tokens" in row.keys() else None,
                rbac_role=row["rbac_role"] if "rbac_role" in row.keys() else "operator",
                data_region=row["data_region"] if "data_region" in row.keys() else "",
                created_at=row["created_at"] or "",
            )
        )
    return policies


def _merge_policies(
    policies: list[GroupPolicy],
    mode: str = "restrictive",
) -> dict:
    """Merge a list of group policies into a single set of constraints.

    Parameters
    ----------
    policies:
        List of matching :class:`GroupPolicy` records.
    mode:
        ``"restrictive"`` — take the *minimum* of numeric limits (safest).
        ``"permissive"``  — take the *maximum* of numeric limits.

    Returns
    -------
    dict with keys: ``allowed_models``, ``denied_models``, ``allowed_providers``,
    ``max_budget_usd``, ``tpm_limit``, ``rpm_limit``, ``max_input_tokens``,
    ``max_output_tokens`` (all may be ``None``).
    """
    if not policies:
        return {
            "allowed_models": None,
            "denied_models": None,
            "allowed_providers": None,
            "max_budget_usd": None,
            "tpm_limit": None,
            "rpm_limit": None,
            "max_input_tokens": None,
            "max_output_tokens": None,
        }

    choose = min if mode == "restrictive" else max

    # Allowed models: intersection (restrictive) or union (permissive)
    model_sets = [set(p.allowed_models) for p in policies if p.allowed_models is not None]
    if model_sets:
        if mode == "restrictive":
            merged_models: Optional[list[str]] = sorted(set.intersection(*model_sets))
        else:
            merged_models = sorted(set.union(*model_sets))
    else:
        merged_models = None  # None = all models allowed

    # Denied models: always union (a model denied by any group is denied)
    denied_sets = [set(p.denied_models) for p in policies if p.denied_models is not None]
    merged_denied: Optional[list[str]] = sorted(set.union(*denied_sets)) if denied_sets else None

    # Allowed providers: intersection (restrictive) or union (permissive)
    provider_sets = [set(p.allowed_providers) for p in policies if p.allowed_providers is not None]
    if provider_sets:
        if mode == "restrictive":
            merged_providers: Optional[list[str]] = sorted(set.intersection(*provider_sets))
        else:
            merged_providers = sorted(set.union(*provider_sets))
    else:
        merged_providers = None

    # Numeric limits: None = unlimited; pick based on mode
    budgets = [p.max_budget_usd for p in policies if p.max_budget_usd is not None]
    tpms = [p.tpm_limit for p in policies if p.tpm_limit is not None]
    rpms = [p.rpm_limit for p in policies if p.rpm_limit is not None]
    input_toks = [p.max_input_tokens for p in policies if p.max_input_tokens is not None]
    output_toks = [p.max_output_tokens for p in policies if p.max_output_tokens is not None]

    return {
        "allowed_models": merged_models,
        "denied_models": merged_denied,
        "allowed_providers": merged_providers,
        "max_budget_usd": choose(budgets) if budgets else None,
        "tpm_limit": choose(tpms) if tpms else None,
        "rpm_limit": choose(rpms) if rpms else None,
        "max_input_tokens": choose(input_toks) if input_toks else None,
        "max_output_tokens": choose(output_toks) if output_toks else None,
    }


def _find_existing_key_id(
    conn: StorageBackend,
    idp_sub: str,
    idp_type: str,
    tenant_id: str,
) -> Optional[str]:
    """Return the key_id of any active provisioned key for this IdP subject."""
    rows = conn.execute(
        """
        SELECT id, metadata_json FROM api_keys
        WHERE tenant_id = ?
          AND blocked = 0
          AND (expires_at IS NULL OR expires_at > ?)
        """,
        (tenant_id, datetime.now(timezone.utc).isoformat()),
    ).fetchall()

    for row in rows:
        try:
            meta = json.loads(row["metadata_json"] or "{}")
        except (json.JSONDecodeError, TypeError):
            continue
        if (
            meta.get(_IDP_META_KEY)
            and meta.get(_IDP_SUB_META_KEY) == idp_sub
            and meta.get(_IDP_TYPE_META_KEY) == idp_type
        ):
            return row["id"]
    return None


class KeyProvisioner:
    """Converts an :class:`IdPUser` into a CoreIQ long-lived virtual key.

    Parameters
    ----------
    key_manager:
        The :class:`KeyManager` instance (from pipeline startup).
    conn:
        A SQLite connection to the CoreIQ database.
    policy_merge:
        How to merge multiple group policies: ``"restrictive"`` (default)
        or ``"permissive"``.
    """

    def __init__(
        self,
        key_manager: KeyManager,
        conn: StorageBackend,
        *,
        policy_merge: str = "restrictive",
    ) -> None:
        self._km = key_manager
        self._conn = conn
        self._policy_merge = policy_merge

    def provision(
        self,
        idp_user: IdPUser,
        *,
        name: str = "",
        tenant_id: str = "",
        models: Optional[list[str]] = None,
        max_budget_usd: Optional[float] = None,
        expires_in_days: Optional[int] = None,
    ) -> ProvisionResponse:
        """Provision a CoreIQ virtual key for *idp_user*.

        If a valid key already exists for this IdP subject+tenant, it is
        revoked and a new one is created (re-provisioning).

        Parameters
        ----------
        idp_user:
            Validated identity from OIDC/LDAP.
        name:
            Human-readable label for the key (defaults to email or sub).
        tenant_id:
            Override the tenant from the IdP token.
        models:
            Explicit model allowlist (overrides group policy).
        max_budget_usd:
            Explicit budget (overrides group policy).
        expires_in_days:
            ``None`` = never expires.

        Returns
        -------
        ProvisionResponse
            Contains the raw key (shown once), key metadata, and policies.
        """
        effective_tenant = idp_user.tenant_id or "default"
        effective_name = name or idp_user.display_name or idp_user.email or idp_user.sub

        # Load and merge group policies
        policies = _load_group_policies(self._conn, idp_user.groups, effective_tenant)
        merged = _merge_policies(policies, self._policy_merge)

        # Caller overrides take precedence over group policy
        final_models = models if models is not None else merged["allowed_models"]
        final_budget = max_budget_usd if max_budget_usd is not None else merged["max_budget_usd"]
        final_tpm = merged["tpm_limit"]
        final_rpm = merged["rpm_limit"]

        # Revoke any existing active key for this IdP subject
        existing_id = _find_existing_key_id(
            self._conn, idp_user.sub, idp_user.idp, effective_tenant
        )
        if existing_id:
            logger.info(
                "Re-provisioning: revoking existing key %s for sub=%s idp=%s",
                existing_id, idp_user.sub, idp_user.idp,
            )
            self._km.revoke_key(existing_id)

        # Generate the new key
        metadata = {
            _IDP_META_KEY: True,
            _IDP_SUB_META_KEY: idp_user.sub,
            _IDP_TYPE_META_KEY: idp_user.idp,
            "email": idp_user.email,
            "groups": idp_user.groups,
        }

        raw_key, vk = self._km.generate_key(
            tenant_id=effective_tenant,
            name=effective_name,
            models=final_models,
            max_budget_usd=final_budget,
            tpm_limit=final_tpm,
            rpm_limit=final_rpm,
            expires_in_days=expires_in_days,
            metadata=metadata,
        )

        logger.info(
            "Provisioned key %s for idp=%s sub=%s email=%s tenant=%s groups=%s",
            vk.id, idp_user.idp, idp_user.sub, idp_user.email,
            effective_tenant, idp_user.groups,
        )

        return ProvisionResponse(
            key=raw_key,
            key_id=vk.id,
            tenant_id=effective_tenant,
            idp=idp_user.idp,
            sub=idp_user.sub,
            email=idp_user.email,
            groups=idp_user.groups,
            models_allowed=final_models,
            budget_usd=final_budget,
            expires_at=vk.expires_at,
            provisioned=True,
        )
