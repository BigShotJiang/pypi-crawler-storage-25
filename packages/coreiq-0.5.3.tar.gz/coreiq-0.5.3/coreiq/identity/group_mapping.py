"""Static IdP group → policy role mapping.

The DB-backed ``GroupPolicy`` table is the durable source of truth, but
many deployments want to pin a few well-known mappings in config (e.g.
"Engineers group → engineer role") without seeding tables. This module
reads such mappings from env / TOML and contributes them at provision
time alongside the DB lookup.

Format (TOML)::

    [identity.group_mapping]
    "AD\\Engineers" = "engineer"
    "AD\\Compliance" = "compliance_admin"

    [identity.group_mapping.policies.engineer]
    rate_limit_rpm = 200
    allowed_models = ["gpt-4o", "claude-3-7-sonnet"]

Or env::

    COREIQ_IDP_GROUP_MAP="AD\\Engineers=engineer,AD\\Compliance=compliance_admin"
"""
from __future__ import annotations

import logging
import os
from typing import Any

from coreiq.config import _get_toml_value

logger = logging.getLogger("coreiq.identity.group_mapping")


def _parse_env_mapping() -> dict[str, str]:
    raw = os.environ.get("COREIQ_IDP_GROUP_MAP", "")
    if not raw:
        return {}
    mapping: dict[str, str] = {}
    for entry in raw.split(","):
        if "=" not in entry:
            continue
        group, role = entry.split("=", 1)
        mapping[group.strip()] = role.strip()
    return mapping


def get_group_role_map() -> dict[str, str]:
    """Return ``{idp_group: role_name}`` from TOML + env, env wins."""
    toml_val = _get_toml_value("identity.group_mapping") or {}
    mapping: dict[str, str] = {}
    if isinstance(toml_val, dict):
        for k, v in toml_val.items():
            if k == "policies":
                continue
            if isinstance(v, str):
                mapping[k] = v
    mapping.update(_parse_env_mapping())
    return mapping


def get_role_policies() -> dict[str, dict[str, Any]]:
    """Return ``{role_name: policy_dict}`` from TOML."""
    policies = _get_toml_value("identity.group_mapping.policies") or {}
    if isinstance(policies, dict):
        return {k: v for k, v in policies.items() if isinstance(v, dict)}
    return {}


def resolve_roles(groups: list[str]) -> list[str]:
    """Map IdP groups to role names. Unmapped groups are dropped."""
    mapping = get_group_role_map()
    return [mapping[g] for g in groups if g in mapping]


def resolve_policy(groups: list[str]) -> dict[str, Any]:
    """Merge config-defined role policies for a set of groups.

    Conflict resolution is restrictive: integer limits take the minimum;
    list constraints take the intersection; missing keys are ignored.
    """
    role_policies = get_role_policies()
    merged: dict[str, Any] = {}
    for role in resolve_roles(groups):
        policy = role_policies.get(role)
        if not policy:
            continue
        for k, v in policy.items():
            if k not in merged:
                merged[k] = v
                continue
            existing = merged[k]
            if isinstance(existing, int) and isinstance(v, int):
                merged[k] = min(existing, v)
            elif isinstance(existing, list) and isinstance(v, list):
                merged[k] = sorted(set(existing) & set(v))
            # Unknown shape: keep first-seen.
    return merged
