"""SCIM 2.0 user provisioning handler for CoreIQ."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _user_to_scim(row: dict) -> dict:
    """Convert a coreiq users row to a SCIM User resource dict."""
    active = row.get("status", "active") == "active"
    return {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "id": row["id"],
        "userName": row["email"],
        "displayName": row.get("name", ""),
        "name": {"formatted": row.get("name", "")},
        "active": active,
        "meta": {
            "resourceType": "User",
            "created": row.get("created_at", ""),
            "lastModified": row.get("last_login") or row.get("created_at", ""),
            "location": f"/scim/v2/Users/{row['id']}",
        },
    }


def _scim_to_fields(scim_resource: dict) -> dict:
    """Extract coreiq user fields from a SCIM resource dict."""
    email = scim_resource.get("userName", "")
    # Support both displayName and name.formatted
    name = scim_resource.get("displayName") or ""
    name_obj = scim_resource.get("name")
    if not name and isinstance(name_obj, dict):
        name = name_obj.get("formatted", "")
    active = scim_resource.get("active", True)
    status = "active" if active else "suspended"
    return {"email": email, "name": name, "status": status}


class SCIMHandler:
    """SCIM 2.0 provisioning — maps SCIM Users to coreiq users table."""

    # Default tenant for SCIM-provisioned users (can be overridden via tenant_id kwarg).
    DEFAULT_TENANT = "default"

    def create_user(self, scim_resource: dict, tenant_id: str | None = None) -> dict:
        conn = get_shared_connection()
        fields = _scim_to_fields(scim_resource)
        tid = tenant_id or self.DEFAULT_TENANT
        user_id = str(uuid.uuid4())
        now = _now()
        conn.execute(
            "INSERT OR REPLACE INTO users(id,tenant_id,email,name,role,mfa_enabled,status,last_login,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (user_id, tid, fields["email"], fields["name"], "viewer", 0, fields["status"], None, now),
        )
        conn.commit()
        row = dict(conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone())
        return _user_to_scim(row)

    def get_user(self, scim_id: str) -> Optional[dict]:
        row = get_shared_connection().execute("SELECT * FROM users WHERE id=?", (scim_id,)).fetchone()
        return _user_to_scim(dict(row)) if row else None

    def update_user(self, scim_id: str, scim_resource: dict) -> dict:
        conn = get_shared_connection()
        fields = _scim_to_fields(scim_resource)
        conn.execute(
            "UPDATE users SET email=?, name=?, status=? WHERE id=?",
            (fields["email"], fields["name"], fields["status"], scim_id),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?", (scim_id,)).fetchone()
        if row is None:
            raise KeyError(f"SCIM user {scim_id!r} not found")
        return _user_to_scim(dict(row))

    def delete_user(self, scim_id: str) -> bool:
        conn = get_shared_connection()
        c = conn.execute("DELETE FROM users WHERE id=?", (scim_id,))
        conn.commit()
        return c.rowcount > 0

    def list_users(
        self,
        filter_str: str | None = None,
        count: int = 100,
        start_index: int = 1,
        tenant_id: str | None = None,
    ) -> dict:
        conn = get_shared_connection()
        params: list = []
        where_clauses: list[str] = []

        if tenant_id:
            where_clauses.append("tenant_id=?")
            params.append(tenant_id)

        # Basic SCIM filter support: userName eq "x" and displayName co "y"
        if filter_str:
            import re
            m = re.search(r'userName\s+eq\s+"([^"]+)"', filter_str, re.IGNORECASE)
            if m:
                where_clauses.append("email=?")
                params.append(m.group(1))
            m2 = re.search(r'displayName\s+co\s+"([^"]+)"', filter_str, re.IGNORECASE)
            if m2:
                where_clauses.append("name LIKE ?")
                params.append(f"%{m2.group(1)}%")

        where = (" WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
        count_row = conn.execute(f"SELECT COUNT(*) AS total FROM users{where}", tuple(params)).fetchone()
        total = count_row["total"] if count_row else 0

        offset = max(0, start_index - 1)
        rows = conn.execute(
            f"SELECT * FROM users{where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            tuple(params) + (count, offset),
        ).fetchall()

        resources = [_user_to_scim(dict(r)) for r in rows]
        return {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:ListResponse"],
            "totalResults": total,
            "startIndex": start_index,
            "itemsPerPage": len(resources),
            "Resources": resources,
        }
