"""Central configuration via environment variables and optional TOML file.

Resolution order for every setting: env var > TOML value > default.
TOML string values may contain ``${ENV_VAR}`` placeholders that are
expanded at load time.
"""

import logging
import os
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger("coreiq.config")

# ---------------------------------------------------------------------------
# TOML loader (cached)
# ---------------------------------------------------------------------------

_toml_data: dict[str, Any] | None = None
_toml_loaded: bool = False

_ENV_VAR_RE = re.compile(r"\$\{([^}]+)\}")


def _expand_env(value: Any) -> Any:
    """Recursively expand ``${ENV_VAR}`` references in string values."""
    if isinstance(value, str):
        def _replace(m: re.Match) -> str:
            return os.environ.get(m.group(1), "")
        return _ENV_VAR_RE.sub(_replace, value)
    if isinstance(value, dict):
        return {k: _expand_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand_env(v) for v in value]
    return value


def _load_toml() -> dict[str, Any]:
    """Load and cache the TOML config file.

    Reads from the path in ``COREIQ_CONFIG_FILE`` (default ``./coreiq.toml``).
    Returns an empty dict if the file does not exist or cannot be parsed.
    """
    global _toml_data, _toml_loaded
    if _toml_loaded:
        return _toml_data or {}

    _toml_loaded = True
    config_path = os.environ.get("COREIQ_CONFIG_FILE", "./coreiq.toml")
    p = Path(config_path)

    if not p.is_file():
        _toml_data = {}
        return _toml_data

    try:
        import tomllib
        with open(p, "rb") as f:
            raw = tomllib.load(f)
        _toml_data = _expand_env(raw)
        logger.info("Loaded TOML config from %s", p)
    except ImportError:
        try:
            import tomli as tomllib_fallback  # type: ignore[import-untyped]
            with open(p, "rb") as f:
                raw = tomllib_fallback.load(f)
            _toml_data = _expand_env(raw)
            logger.info("Loaded TOML config from %s (via tomli)", p)
        except ImportError:
            logger.warning(
                "Cannot load TOML config: neither tomllib (3.11+) nor tomli is available"
            )
            _toml_data = {}
    except Exception as exc:
        logger.warning("Failed to load TOML config from %s: %s", p, exc)
        _toml_data = {}

    return _toml_data


def reload_toml() -> dict[str, Any]:
    """Force-reload the TOML config (useful for tests)."""
    global _toml_loaded, _toml_data
    _toml_loaded = False
    _toml_data = None
    return _load_toml()


def _get_toml_value(path: str) -> Any:
    """Retrieve a nested value from the TOML data using dot-separated *path*.

    Example: ``_get_toml_value("gateway.port")`` -> ``toml["gateway"]["port"]``
    """
    data = _load_toml()
    parts = path.split(".")
    for part in parts:
        if not isinstance(data, dict):
            return None
        data = data.get(part)
        if data is None:
            return None
    return data


def _resolve(env_key: str, toml_path: str, default: Any = None) -> Any:
    """Resolve a config value: env var > TOML > default."""
    env_val = os.environ.get(env_key)
    if env_val is not None and env_val != "":
        return env_val
    toml_val = _get_toml_value(toml_path)
    if toml_val is not None:
        return toml_val
    return default


# ---------------------------------------------------------------------------
# Core settings (env + TOML)
# ---------------------------------------------------------------------------


def get_db_path() -> Path:
    raw = _resolve("COREIQ_DB_PATH", "gateway.db_path", "")
    if raw:
        return Path(raw)
    return Path.home() / ".coreiq" / "coreiq.db"


def get_api_key() -> str | None:
    """If set, all /api/* requests must include X-API-Key: <value> header."""
    val = _resolve("COREIQ_API_KEY", "gateway.api_key", "")
    return val or None


def get_host() -> str:
    return str(_resolve("COREIQ_HOST", "gateway.host", "127.0.0.1"))


def get_port() -> int:
    return int(_resolve("COREIQ_PORT", "gateway.port", 7823))


def get_log_level() -> str:
    return str(_resolve("COREIQ_LOG_LEVEL", "gateway.log_level", "info")).lower()


def get_log_json() -> bool:
    """If true, emit logs as JSON (for structured log aggregators)."""
    val = _resolve("COREIQ_LOG_JSON", "gateway.log_json", False)
    if isinstance(val, bool):
        return val
    return str(val).lower() in ("1", "true", "yes")


def get_cors_origins() -> list[str]:
    """Comma-separated allowed CORS origins. Defaults to localhost dev server."""
    raw = os.environ.get("COREIQ_CORS_ORIGINS", "")
    if raw:
        return [o.strip() for o in raw.split(",") if o.strip()]
    toml_val = _get_toml_value("gateway.cors_origins")
    if isinstance(toml_val, list):
        return toml_val
    return ["http://localhost:5173"]


def get_rate_limit() -> int:
    """Max requests per minute per IP. 0 = disabled."""
    return int(_resolve("COREIQ_RATE_LIMIT", "gateway.rate_limit", 0))


# ---------------------------------------------------------------------------
# Redis cache
# ---------------------------------------------------------------------------


def get_redis_url() -> str | None:
    """Redis URL for the L2 cache backend (e.g. ``redis://localhost:6379/0``).

    Returns ``None`` if not configured — the pipeline will use in-memory only.
    """
    val = _resolve("COREIQ_REDIS_URL", "gateway.cache.redis_url", "")
    return val or None


def get_redis_cache_ttl() -> int:
    """TTL in seconds for Redis cache entries. Default 3600 (1 hour)."""
    return int(_resolve("COREIQ_REDIS_CACHE_TTL", "gateway.cache.redis_ttl", 3600))


# ---------------------------------------------------------------------------
# Provider configs from TOML
# ---------------------------------------------------------------------------


def get_provider_configs() -> dict[str, dict[str, Any]]:
    """Return ``{provider_name: {key: value, ...}}`` from ``[providers.*]``."""
    providers = _get_toml_value("providers")
    if isinstance(providers, dict):
        return dict(providers)
    return {}


# ---------------------------------------------------------------------------
# Function configs from TOML
# ---------------------------------------------------------------------------


def get_functions_config() -> dict[str, dict[str, Any]]:
    """Return ``{function_name: {type, variants, experimentation, ...}}`` from ``[functions.*]``."""
    functions = _get_toml_value("functions")
    if isinstance(functions, dict):
        return dict(functions)
    return {}


# ---------------------------------------------------------------------------
# Routing config from TOML
# ---------------------------------------------------------------------------


def get_routing_config() -> dict[str, Any]:
    """Return the ``[routing]`` section."""
    routing = _get_toml_value("routing")
    if isinstance(routing, dict):
        return dict(routing)
    return {}


# ---------------------------------------------------------------------------
# Gateway config from TOML
# ---------------------------------------------------------------------------


def get_gateway_config() -> dict[str, Any]:
    """Return the full ``[gateway]`` section."""
    gw = _get_toml_value("gateway")
    if isinstance(gw, dict):
        return dict(gw)
    return {}


# ---------------------------------------------------------------------------
# Metrics config from TOML
# ---------------------------------------------------------------------------


def get_metrics_config() -> dict[str, dict[str, Any]]:
    """Return ``{metric_name: {type, level, optimize}}`` from ``[metrics.*]``."""
    metrics = _get_toml_value("metrics")
    if isinstance(metrics, dict):
        return dict(metrics)
    return {}


# ---------------------------------------------------------------------------
# Identity / Enterprise SSO config
# ---------------------------------------------------------------------------


def get_identity_config() -> dict[str, Any]:
    """Return identity/SSO configuration.

    Controls the ``POST /auth/provision`` endpoint behaviour.
    Set ``COREIQ_IDENTITY_ENABLED=true`` to activate IdP-based key provisioning.
    """
    enabled_raw = _resolve("COREIQ_IDENTITY_ENABLED", "identity.enabled", False)
    enabled = enabled_raw if isinstance(enabled_raw, bool) else str(enabled_raw).lower() in ("1", "true", "yes")

    return {
        "enabled": enabled,
        # OIDC — Azure AD / Entra ID
        "oidc_azure_tenant": _resolve("COREIQ_OIDC_AZURE_TENANT", "identity.oidc.azure_tenant", ""),
        "oidc_azure_audience": _resolve("COREIQ_OIDC_AZURE_AUDIENCE", "identity.oidc.azure_audience", ""),
        # OIDC — Google Workspace
        "oidc_google_audience": _resolve("COREIQ_OIDC_GOOGLE_AUDIENCE", "identity.oidc.google_audience", ""),
        # OIDC — Okta
        "oidc_okta_domain": _resolve("COREIQ_OIDC_OKTA_DOMAIN", "identity.oidc.okta_domain", ""),
        "oidc_okta_audience": _resolve("COREIQ_OIDC_OKTA_AUDIENCE", "identity.oidc.okta_audience", ""),
        # LDAP / Active Directory
        "ldap_url": _resolve("COREIQ_LDAP_URL", "identity.ldap.url", ""),
        "ldap_base_dn": _resolve("COREIQ_LDAP_BASE_DN", "identity.ldap.base_dn", ""),
        "ldap_domain": _resolve("COREIQ_LDAP_DOMAIN", "identity.ldap.domain", ""),
        "ldap_bind_dn": _resolve("COREIQ_LDAP_BIND_DN", "identity.ldap.bind_dn", ""),
        "ldap_bind_pw": _resolve("COREIQ_LDAP_BIND_PW", "identity.ldap.bind_pw", ""),
        # Provisioning policy
        "policy_merge": _resolve("COREIQ_IDENTITY_POLICY_MERGE", "identity.policy_merge", "restrictive"),
    }


# ---------------------------------------------------------------------------
# Storage backend config
# ---------------------------------------------------------------------------


def get_store_config() -> dict[str, Any]:
    """Return storage backend configuration.

    [store]
    backend = "mongodb"         # "mongodb" | "clickhouse" | "postgres"
    postgres_dsn = "postgresql://user:pass@host:5432/coreiq"
    mongodb_uri = "mongodb://user:pass@host:27017"
    mongodb_database = "coreiq"
    clickhouse_dsn = "http://default:@localhost:8123"
    clickhouse_database = "coreiq"
    """
    backend = str(_resolve("COREIQ_STORE_BACKEND", "store.backend", "otel")).lower()
    postgres_dsn = str(_resolve("COREIQ_POSTGRES_DSN", "store.postgres_dsn", "") or "")
    mongodb_uri = str(_resolve("COREIQ_MONGODB_URI", "store.mongodb_uri", "") or "")
    mongodb_database = str(_resolve("COREIQ_MONGODB_DATABASE", "store.mongodb_database", "coreiq"))
    clickhouse_dsn = str(_resolve("COREIQ_CLICKHOUSE_DSN", "store.clickhouse_dsn", "") or "")
    clickhouse_database = str(_resolve("COREIQ_CLICKHOUSE_DATABASE", "store.clickhouse_database", "coreiq"))
    return {
        "backend": backend,
        "postgres_dsn": postgres_dsn or None,
        "mongodb_uri": mongodb_uri or None,
        "mongodb_database": mongodb_database,
        "clickhouse_dsn": clickhouse_dsn or None,
        "clickhouse_database": clickhouse_database,
    }


def get_otel_config() -> dict[str, Any]:
    """Return OpenTelemetry export configuration.

    [otel]
    enabled = false
    endpoint = "http://localhost:4317"
    protocol = "grpc"          # "grpc" | "http/protobuf"
    service_name = "coreiq"
    export_traces = true
    export_metrics = true
    """
    enabled_raw = _resolve("COREIQ_OTEL_ENABLED", "otel.enabled", False)
    enabled = enabled_raw if isinstance(enabled_raw, bool) else str(enabled_raw).lower() in ("1", "true", "yes")
    return {
        "enabled": enabled,
        "endpoint": str(_resolve("COREIQ_OTEL_ENDPOINT", "otel.endpoint", "http://localhost:4318")),
        "protocol": str(_resolve("COREIQ_OTEL_PROTOCOL", "otel.protocol", "http/protobuf")),
        "service_name": str(_resolve("COREIQ_OTEL_SERVICE_NAME", "otel.service_name", "coreiq")),
        "export_traces": True,
        "export_metrics": True,
    }


def get_prometheus_config() -> dict[str, Any]:
    """Return Prometheus metrics scrape configuration.

    [prometheus]
    enabled = false
    port = 9090
    path = "/metrics"
    """
    enabled_raw = _resolve("COREIQ_PROMETHEUS_ENABLED", "prometheus.enabled", False)
    enabled = enabled_raw if isinstance(enabled_raw, bool) else str(enabled_raw).lower() in ("1", "true", "yes")
    return {
        "enabled": enabled,
        "port": int(_resolve("COREIQ_PROMETHEUS_PORT", "prometheus.port", 9090)),
        "path": str(_resolve("COREIQ_PROMETHEUS_PATH", "prometheus.path", "/metrics")),
    }


def get_residency_config() -> dict[str, Any]:
    """Return data residency configuration.

    [residency]
    enabled = false
    default_region = "eu-west-1"
    allowed_regions = ["eu-west-1", "eu-central-1"]
    block_cross_region_writes = false
    """
    enabled_raw = _resolve("COREIQ_RESIDENCY_ENABLED", "residency.enabled", False)
    enabled = enabled_raw if isinstance(enabled_raw, bool) else str(enabled_raw).lower() in ("1", "true", "yes")
    block_raw = _resolve("COREIQ_RESIDENCY_BLOCK_CROSS", "residency.block_cross_region_writes", False)
    block = block_raw if isinstance(block_raw, bool) else str(block_raw).lower() in ("1", "true", "yes")
    allowed = _get_toml_value("residency.allowed_regions")
    default_region = str(_resolve("COREIQ_RESIDENCY_DEFAULT_REGION", "residency.default_region", "default"))
    if not isinstance(allowed, list):
        allowed = [default_region]
    return {
        "enabled": enabled,
        "default_region": default_region,
        "allowed_regions": allowed,
        "block_cross_region_writes": block,
    }


def get_clickhouse_config() -> dict[str, Any] | None:
    """Return ClickHouse connection config, or ``None`` if not configured.

    Resolution priority:
    1. ``COREIQ_CLICKHOUSE_URL`` — full DSN (``clickhouse://user:pass@host:port/db``)
    2. Individual ``COREIQ_CLICKHOUSE_*`` env vars / TOML ``[clickhouse]``
    3. ``None`` — ClickHouse is disabled; SQLite backend is used.
    """
    # Check for the all-in-one URL first
    url = _resolve("COREIQ_CLICKHOUSE_URL", "clickhouse.url", "")
    if url:
        return {"url": url}

    # Fall back to individual settings
    host = _resolve("COREIQ_CLICKHOUSE_HOST", "clickhouse.host", "")
    if not host:
        return None

    port = int(_resolve("COREIQ_CLICKHOUSE_PORT", "clickhouse.port", 9000))
    database = str(_resolve("COREIQ_CLICKHOUSE_DATABASE", "clickhouse.database", "coreiq"))
    user = str(_resolve("COREIQ_CLICKHOUSE_USER", "clickhouse.user", "default"))
    password = str(_resolve("COREIQ_CLICKHOUSE_PASSWORD", "clickhouse.password", ""))
    secure_raw = _resolve("COREIQ_CLICKHOUSE_SECURE", "clickhouse.secure", False)
    if isinstance(secure_raw, bool):
        secure = secure_raw
    else:
        secure = str(secure_raw).lower() in ("1", "true", "yes")
    pool_size = int(_resolve("COREIQ_CLICKHOUSE_POOL_SIZE", "clickhouse.pool_size", 10))

    return {
        "host": host,
        "port": port,
        "database": database,
        "user": user,
        "password": password,
        "secure": secure,
        "pool_size": pool_size,
    }
