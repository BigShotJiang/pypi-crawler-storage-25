"""Usage analytics package for CoreIQ."""
from .usage import UsageAnalytics

__all__ = ["UsageAnalytics"]
