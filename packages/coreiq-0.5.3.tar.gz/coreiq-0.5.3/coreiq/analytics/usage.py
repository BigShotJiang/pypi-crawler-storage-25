from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta

from ..store.db import get_shared_connection


@dataclass
class DailyCost:
    date: str
    cost_usd: float
    requests: int
    tokens: int


@dataclass
class ProviderUsage:
    provider: str
    requests: int
    cost_usd: float
    pct_requests: float
    pct_spend: float


@dataclass
class ModelSpend:
    model: str
    provider: str
    requests: int
    cost_usd: float
    pct_spend: float


class UsageAnalytics:
    def daily_cost(self, tenant_id: str | None = None, days: int = 30) -> list[DailyCost]:
        conn = get_shared_connection()
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        where = "WHERE ts >= ?"
        params: list = [cutoff]
        if tenant_id:
            where += " AND tenant_id = ?"
            params.append(tenant_id)
        rows = conn.execute(
            f"SELECT ts, input_tok, output_tok, cost_usd FROM traces {where}",
            tuple(params),
        ).fetchall()

        # Group by date (first 10 chars of ts ISO string) in Python — works across
        # all backends without relying on substr() or json_extract() in SQL.
        groups: dict = defaultdict(lambda: {"reqs": 0, "tokens": 0, "cost": 0.0})
        for r in rows:
            date = str(r["ts"])[:10]
            groups[date]["reqs"] += 1
            groups[date]["tokens"] += (r.get("input_tok") or 0) + (r.get("output_tok") or 0)
            groups[date]["cost"] += float(r.get("cost_usd") or 0)

        return [
            DailyCost(
                date=date,
                cost_usd=round(info["cost"], 6),
                requests=int(info["reqs"]),
                tokens=int(info["tokens"]),
            )
            for date, info in sorted(groups.items())
        ]

    def provider_breakdown(self, tenant_id: str | None = None, days: int = 30) -> list[ProviderUsage]:
        conn = get_shared_connection()
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        where = "WHERE ts >= ?"
        params: list = [cutoff]
        if tenant_id:
            where += " AND tenant_id = ?"
            params.append(tenant_id)
        rows = conn.execute(
            f"SELECT provider, COUNT(*) as reqs, SUM(cost_usd) as cost "
            f"FROM traces {where} GROUP BY provider ORDER BY reqs DESC",
            tuple(params),
        ).fetchall()
        total_reqs = sum(r["reqs"] for r in rows) or 1
        total_cost = sum(r["cost"] or 0 for r in rows) or 1
        return [
            ProviderUsage(
                provider=r["provider"] or "unknown",
                requests=r["reqs"],
                cost_usd=round(r["cost"] or 0, 6),
                pct_requests=round(r["reqs"] / total_reqs * 100, 1),
                pct_spend=round((r["cost"] or 0) / total_cost * 100, 1),
            )
            for r in rows
        ]

    def top_models(self, tenant_id: str | None = None, limit: int = 10) -> list[ModelSpend]:
        conn = get_shared_connection()
        where = ""
        params: list = []
        if tenant_id:
            where = "WHERE tenant_id = ?"
            params.append(tenant_id)
        params.append(limit)
        rows = conn.execute(
            f"SELECT model, provider, COUNT(*) as reqs, SUM(cost_usd) as cost "
            f"FROM traces {where} GROUP BY model, provider ORDER BY cost DESC LIMIT ?",
            tuple(params),
        ).fetchall()
        total_cost = sum(r["cost"] or 0 for r in rows) or 1
        return [
            ModelSpend(
                model=r["model"] or "unknown",
                provider=r["provider"] or "unknown",
                requests=r["reqs"],
                cost_usd=round(r["cost"] or 0, 6),
                pct_spend=round((r["cost"] or 0) / total_cost * 100, 1),
            )
            for r in rows
        ]
