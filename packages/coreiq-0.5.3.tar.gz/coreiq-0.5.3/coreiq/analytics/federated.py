"""Federated Analytics — privacy-preserving aggregated insights across tenants.

Computes aggregate statistics without exposing individual tenant data.
"""
from __future__ import annotations
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
logger = logging.getLogger(__name__)

@dataclass
class FederatedInsight:
    metric: str
    aggregate: float
    tenant_count: int
    min_val: float = 0
    max_val: float = 0
    description: str = ""
    def to_dict(self) -> Dict[str, Any]:
        return {"metric": self.metric, "aggregate": round(self.aggregate, 4),
                "tenant_count": self.tenant_count, "min": round(self.min_val, 4),
                "max": round(self.max_val, 4), "description": self.description}

class FederatedAnalytics:
    def __init__(self, min_tenants: int = 3):
        self.min_tenants = min_tenants
        self._tenant_data: Dict[str, Dict[str, List[float]]] = {}  # tenant -> metric -> values

    def submit(self, tenant_id: str, metric: str, value: float) -> None:
        self._tenant_data.setdefault(tenant_id, {}).setdefault(metric, []).append(value)

    def query(self, metric: str) -> Optional[FederatedInsight]:
        tenants_with_metric = {t: vals[metric] for t, vals in self._tenant_data.items() if metric in vals}
        if len(tenants_with_metric) < self.min_tenants:
            return None  # Privacy threshold not met
        all_values = [v for vals in tenants_with_metric.values() for v in vals]
        if not all_values:
            return None
        avg = sum(all_values) / len(all_values)
        return FederatedInsight(metric=metric, aggregate=avg, tenant_count=len(tenants_with_metric),
            min_val=min(all_values), max_val=max(all_values),
            description=f"Aggregated from {len(tenants_with_metric)} tenants ({len(all_values)} data points)")

    def available_metrics(self) -> List[str]:
        metrics = set()
        for tenant_metrics in self._tenant_data.values():
            metrics.update(tenant_metrics.keys())
        return sorted(metrics)
