"""Process-wide event bus for fire-and-forget webhook dispatch.

Discrete domain events (`policy.denied`, `anomaly.detected`,
`audit.write_failed`) are emitted from synchronous code paths but webhook
delivery is async + does network I/O. This module bridges the two by
scheduling the async ``WebhookManager.dispatch()`` on the running event
loop without blocking the caller.

Per-request high-volume events (e.g. ``trace.recorded``) are intentionally
**not** emitted through this bus — they would flood any consumer. Operators
that want per-request feeds should consume the OTel trace stream instead.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger("coreiq.integrations.event_bus")

# Standardised event types. Keep this list small and stable — webhook
# subscribers filter on these strings, so renames are breaking changes.
EVENT_POLICY_DENIED = "policy.denied"
EVENT_ANOMALY_DETECTED = "anomaly.detected"
EVENT_AUDIT_WRITE_FAILED = "audit.write_failed"
EVENT_DRIFT_DETECTED = "drift.detected"
EVENT_COST_BUDGET_EXCEEDED = "cost.budget_exceeded"


def emit(event_type: str, payload: Dict[str, Any], *, tenant_id: Optional[str] = None) -> None:
    """Fire an event to webhook subscribers without blocking.

    Safe to call from synchronous code. If no event loop is running
    (e.g. during unit tests with a sync TestClient at import time) the
    event is logged and dropped — webhooks are best-effort by design.
    """
    if not tenant_id:
        # Webhooks are scoped per-tenant; without a tenant we can't route.
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        logger.debug("event_bus.emit(%s): no running loop, skipping", event_type)
        return

    async def _dispatch() -> None:
        try:
            from .webhooks import WebhookManager
            await WebhookManager().dispatch(event_type, payload, tenant_id)
        except Exception as exc:
            logger.warning("Webhook dispatch failed for %s: %s", event_type, exc)

    # Fire-and-forget: don't await, don't propagate exceptions.
    loop.create_task(_dispatch())
