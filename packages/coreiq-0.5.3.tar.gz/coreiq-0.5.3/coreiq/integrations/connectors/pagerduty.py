from __future__ import annotations


class PagerDutyConnector:
    EVENTS_URL = "https://events.pagerduty.com/v2/enqueue"

    def __init__(self, routing_key: str):
        self.routing_key = routing_key

    async def trigger_incident(
        self,
        summary: str,
        severity: str = "error",
        source: str = "coreiq",
        dedup_key: str | None = None,
    ) -> bool:
        import httpx

        payload = {
            "routing_key": self.routing_key,
            "event_action": "trigger",
            "dedup_key": dedup_key,
            "payload": {
                "summary": summary,
                "severity": severity,
                "source": source,
            },
        }
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(self.EVENTS_URL, json=payload)
                return resp.status_code in (200, 202)
        except Exception:
            return False
