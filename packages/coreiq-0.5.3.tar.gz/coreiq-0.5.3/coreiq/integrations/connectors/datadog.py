from __future__ import annotations


class DatadogConnector:
    def __init__(self, api_key: str, site: str = "datadoghq.com"):
        self.api_key = api_key
        self.site = site
        self.events_url = f"https://api.{site}/api/v1/events"

    async def send_event(
        self,
        title: str,
        text: str,
        tags: list[str] | None = None,
        alert_type: str = "info",
    ) -> bool:
        import httpx

        payload = {"title": title, "text": text, "tags": tags or [], "alert_type": alert_type}
        headers = {"DD-API-KEY": self.api_key, "Content-Type": "application/json"}
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(self.events_url, json=payload, headers=headers)
                return resp.status_code == 202
        except Exception:
            return False

    async def send_metrics(
        self,
        metric_name: str,
        value: float,
        tags: list[str] | None = None,
    ) -> bool:
        import httpx
        import time

        url = f"https://api.{self.site}/api/v1/series"
        payload = {
            "series": [
                {
                    "metric": metric_name,
                    "points": [[int(time.time()), value]],
                    "tags": tags or [],
                }
            ]
        }
        headers = {"DD-API-KEY": self.api_key, "Content-Type": "application/json"}
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(url, json=payload, headers=headers)
                return resp.status_code == 202
        except Exception:
            return False
