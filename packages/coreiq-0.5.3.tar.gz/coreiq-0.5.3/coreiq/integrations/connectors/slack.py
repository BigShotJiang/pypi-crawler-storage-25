from __future__ import annotations


class SlackConnector:
    def __init__(self, webhook_url: str, channel: str | None = None):
        self.webhook_url = webhook_url
        self.channel = channel

    async def send(self, message: str, title: str | None = None, color: str = "#36a64f") -> bool:
        import httpx

        payload: dict = {
            "attachments": [
                {
                    "color": color,
                    "title": title or "CoreIQ Alert",
                    "text": message,
                    "ts": __import__("time").time(),
                }
            ]
        }
        if self.channel:
            payload["channel"] = self.channel
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(self.webhook_url, json=payload)
                return resp.status_code == 200
        except Exception:
            return False
