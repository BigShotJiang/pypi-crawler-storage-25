from __future__ import annotations
import hashlib
import hmac
import ipaddress
import json
import socket
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse
from ..store.db import get_shared_connection


def _resolve_and_check(url: str) -> str:
    """Resolve the URL's hostname and return the IP string.

    Raises ValueError if the URL is malformed, uses a disallowed scheme,
    or resolves to a private/reserved address (SSRF guard).
    """
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Webhook URL must use http or https")
    host = parsed.hostname or ""
    if not host:
        raise ValueError("Webhook URL must not target private/internal IP addresses")
    try:
        ip_str = socket.gethostbyname(host)
    except socket.gaierror:
        raise ValueError("Webhook URL must not target private/internal IP addresses")
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        raise ValueError("Webhook URL must not target private/internal IP addresses")
    if (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    ):
        raise ValueError("Webhook URL must not target private/internal IP addresses")
    return ip_str


def _validate_webhook_url(url: str) -> None:
    """Raise ValueError if the URL targets a private/internal address."""
    _resolve_and_check(url)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Webhook:
    id: str
    tenant_id: str
    url: str
    events_json: str
    secret_hash: Optional[str]
    status: str
    created_at: str
    last_delivery_at: Optional[str]
    last_status_code: Optional[int]
    resolved_ip: Optional[str] = None


@dataclass
class DeliveryResult:
    webhook_id: str
    event_type: str
    status_code: int
    success: bool
    ts: str


class WebhookManager:
    def register(self, tenant_id: str, url: str, events: list[str], secret: str | None = None) -> Webhook:
        # Resolve and validate in one call — stores the IP to detect DNS rebinding at dispatch.
        resolved_ip = _resolve_and_check(url)
        conn = get_shared_connection()
        # Store the secret as-is — it is a shared HMAC signing key, not a
        # password. Hashing it and then using the hash as the HMAC key would
        # give a publicly-derivable key to anyone with DB read access.
        secret_hash = secret if secret else None
        w = Webhook(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            url=url,
            events_json=json.dumps(events),
            secret_hash=secret_hash,
            status="active",
            created_at=_now(),
            last_delivery_at=None,
            last_status_code=None,
            resolved_ip=resolved_ip,
        )
        conn.execute(
            "INSERT INTO webhooks(id,tenant_id,url,events_json,secret_hash,status,created_at,last_delivery_at,last_status_code,resolved_ip) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (w.id, w.tenant_id, w.url, w.events_json, w.secret_hash, w.status, w.created_at, w.last_delivery_at, w.last_status_code, w.resolved_ip),
        )
        conn.commit()
        return w

    def list(self, tenant_id: str) -> list[Webhook]:
        rows = get_shared_connection().execute(
            "SELECT * FROM webhooks WHERE tenant_id=? ORDER BY created_at DESC", (tenant_id,)
        ).fetchall()
        return [Webhook(**dict(r)) for r in rows]

    def delete(self, webhook_id: str, tenant_id: str) -> bool:
        conn = get_shared_connection()
        c = conn.execute("DELETE FROM webhooks WHERE id=? AND tenant_id=?", (webhook_id, tenant_id))
        conn.commit()
        return c.rowcount > 0

    async def dispatch(self, event_type: str, payload: dict, tenant_id: str) -> list[DeliveryResult]:
        """Send webhook to all registered hooks that subscribe to event_type."""
        import httpx

        rows = get_shared_connection().execute(
            "SELECT * FROM webhooks WHERE tenant_id=? AND status='active'", (tenant_id,)
        ).fetchall()
        results = []
        for row in rows:
            events = json.loads(row["events_json"] or "[]")
            if event_type not in events and "*" not in events:
                continue
            try:
                current_ip = _resolve_and_check(row["url"])
            except ValueError:
                continue  # silently skip invalid/private URLs
            # DNS rebinding guard: if the hostname now resolves to a different IP
            # than at registration time, block delivery.
            stored_ip = row["resolved_ip"] if row["resolved_ip"] else None
            if stored_ip and current_ip != stored_ip:
                continue
            body = json.dumps({"event": event_type, "payload": payload, "ts": _now()})
            headers = {"Content-Type": "application/json", "X-Webhook-Event": event_type}
            if row["secret_hash"]:
                sig = hmac.new(row["secret_hash"].encode(), body.encode(), hashlib.sha256).hexdigest()
                headers["X-Webhook-Signature"] = f"sha256={sig}"
            try:
                async with httpx.AsyncClient(timeout=5.0, follow_redirects=False) as client:
                    resp = await client.post(row["url"], content=body, headers=headers)
                    status_code = resp.status_code
                    success = 200 <= status_code < 300
            except Exception:
                status_code = 0
                success = False
            conn = get_shared_connection()
            conn.execute(
                "UPDATE webhooks SET last_delivery_at=?, last_status_code=? WHERE id=?",
                (_now(), status_code, row["id"]),
            )
            conn.commit()
            results.append(DeliveryResult(
                webhook_id=row["id"],
                event_type=event_type,
                status_code=status_code,
                success=success,
                ts=_now(),
            ))
        return results
