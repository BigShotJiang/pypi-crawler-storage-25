from __future__ import annotations
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional
from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class ConfigEntry:
    id: str
    tenant_id: str
    key: str
    value: str
    is_secret: int
    description: Optional[str]
    updated_by: str
    updated_at: str
    version: int


class ConfigStoreManager:
    def set(
        self,
        tenant_id: str,
        key: str,
        value: str,
        is_secret: bool = False,
        description: str = "",
        updated_by: str = "system",
    ) -> ConfigEntry:
        conn = get_shared_connection()
        stored_value = value
        if is_secret:
            try:
                from ..security.encryption import encrypt
                stored_value = encrypt(value)
            except Exception:
                pass
        row = conn.execute(
            "SELECT MAX(version) as v FROM config_op_entries WHERE tenant_id=? AND key=?",
            (tenant_id, key),
        ).fetchone()
        version = (row["v"] or 0 if row else 0) + 1
        entry = ConfigEntry(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            key=key,
            value=stored_value,
            is_secret=int(is_secret),
            description=description,
            updated_by=updated_by,
            updated_at=_now(),
            version=version,
        )
        conn.execute(
            "INSERT INTO config_op_entries(id,tenant_id,key,value,is_secret,description,updated_by,updated_at,version) VALUES(?,?,?,?,?,?,?,?,?)",
            (
                entry.id,
                entry.tenant_id,
                entry.key,
                entry.value,
                entry.is_secret,
                entry.description,
                entry.updated_by,
                entry.updated_at,
                entry.version,
            ),
        )
        conn.commit()
        return entry

    def get(self, tenant_id: str, key: str) -> Optional[ConfigEntry]:
        row = get_shared_connection().execute(
            "SELECT * FROM config_op_entries WHERE tenant_id=? AND key=? ORDER BY version DESC LIMIT 1",
            (tenant_id, key),
        ).fetchone()
        if not row:
            return None
        _get = (lambda k, d=None: row.get(k, d)) if hasattr(row, "get") else (lambda k, d=None: row[k])
        entry = ConfigEntry(
            id=row["id"],
            tenant_id=row["tenant_id"],
            key=row["key"],
            value=row["value"],
            is_secret=_get("is_secret", 0),
            description=_get("description"),
            updated_by=_get("updated_by", "system"),
            updated_at=_get("updated_at", ""),
            version=_get("version", 1),
        )
        if entry.is_secret:
            try:
                from ..security.encryption import decrypt
                entry.value = decrypt(entry.value)
            except Exception:
                pass
        return entry

    def list(self, tenant_id: str) -> list[ConfigEntry]:
        # Fetch all versions ordered by version DESC, then deduplicate by key in Python.
        # This avoids ROW_NUMBER() OVER (PARTITION BY ...) which MongoDB doesn't support.
        rows = get_shared_connection().execute(
            "SELECT * FROM config_op_entries WHERE tenant_id=? ORDER BY key, version DESC",
            (tenant_id,),
        ).fetchall()
        seen: set[str] = set()
        result = []
        for row in rows:
            key = row["key"]
            if key in seen:
                continue
            seen.add(key)
            _get = (lambda k, d=None: row.get(k, d)) if hasattr(row, "get") else (lambda k, d=None: row[k])
            entry = ConfigEntry(
                id=row["id"],
                tenant_id=row["tenant_id"],
                key=key,
                value=row["value"],
                is_secret=_get("is_secret", 0),
                description=_get("description"),
                updated_by=_get("updated_by", "system"),
                updated_at=_get("updated_at", ""),
                version=_get("version", 1),
            )
            if entry.is_secret:
                entry.value = "***"
            result.append(entry)
        return result

    def history(self, tenant_id: str, key: str) -> list[ConfigEntry]:
        rows = get_shared_connection().execute(
            "SELECT * FROM config_op_entries WHERE tenant_id=? AND key=? ORDER BY version DESC",
            (tenant_id, key),
        ).fetchall()
        return [ConfigEntry(**dict(r)) for r in rows]

    def delete(self, tenant_id: str, key: str) -> bool:
        conn = get_shared_connection()
        c = conn.execute(
            "DELETE FROM config_op_entries WHERE tenant_id=? AND key=?", (tenant_id, key)
        )
        conn.commit()
        return c.rowcount > 0
