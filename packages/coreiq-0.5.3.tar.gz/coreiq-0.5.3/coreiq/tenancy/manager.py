from __future__ import annotations
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional
from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Tenant:
    id: str
    name: str
    slug: str
    plan: str  # "free" | "pro" | "enterprise"
    settings_json: str
    created_at: str
    updated_at: str
    synced_at: Optional[str] = None


class TenantManager:
    def create(self, name: str, slug: str, plan: str = "free", settings: dict | None = None) -> Tenant:
        conn = get_shared_connection()
        t = Tenant(
            id=str(uuid.uuid4()),
            name=name,
            slug=slug,
            plan=plan,
            settings_json=__import__("json").dumps(settings or {}),
            created_at=_now(),
            updated_at=_now(),
        )
        conn.execute(
            "INSERT OR REPLACE INTO tenants(id,name,slug,plan,settings_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
            (t.id, t.name, t.slug, t.plan, t.settings_json, t.created_at, t.updated_at)
        )
        conn.commit()
        return t

    def get(self, tenant_id: str) -> Optional[Tenant]:
        conn = get_shared_connection()
        row = conn.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
        if not row:
            return None
        return Tenant(**dict(row))

    def get_by_slug(self, slug: str) -> Optional[Tenant]:
        conn = get_shared_connection()
        row = conn.execute("SELECT * FROM tenants WHERE slug=?", (slug,)).fetchone()
        if not row:
            return None
        return Tenant(**dict(row))

    def list(self, plan: str | None = None) -> list[Tenant]:
        conn = get_shared_connection()
        if plan:
            rows = conn.execute("SELECT * FROM tenants WHERE plan=? ORDER BY created_at DESC", (plan,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM tenants ORDER BY created_at DESC").fetchall()
        return [Tenant(**dict(r)) for r in rows]

    _ALLOWED_UPDATE_COLS = frozenset({
        "name", "plan", "status", "max_users", "max_keys",
        "allowed_models_json", "metadata_json", "updated_at",
    })

    def update(self, tenant_id: str, **kwargs) -> Optional[Tenant]:
        kwargs["updated_at"] = _now()
        invalid = set(kwargs) - self._ALLOWED_UPDATE_COLS
        if invalid:
            raise ValueError(f"Invalid update fields: {invalid}")
        # Second layer: build SET clause only from keys that are in the whitelist,
        # so injection is structurally impossible even if the check above is bypassed.
        safe = {k: v for k, v in kwargs.items() if k in self._ALLOWED_UPDATE_COLS}
        if not safe:
            return self.get(tenant_id)
        conn = get_shared_connection()
        sets = ", ".join(f"{k}=?" for k in safe)
        conn.execute(f"UPDATE tenants SET {sets} WHERE id=?", (*safe.values(), tenant_id))
        conn.commit()
        return self.get(tenant_id)

    def delete(self, tenant_id: str) -> bool:
        conn = get_shared_connection()
        cursor = conn.execute("DELETE FROM tenants WHERE id=?", (tenant_id,))
        conn.commit()
        return cursor.rowcount > 0
