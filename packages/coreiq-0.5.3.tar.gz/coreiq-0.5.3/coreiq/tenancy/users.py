from __future__ import annotations
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional
from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class User:
    id: str
    tenant_id: str
    email: str
    name: str
    role: str  # "admin" | "operator" | "viewer" | "auditor"
    mfa_enabled: int  # 0/1 for SQLite compat
    status: str  # "active" | "suspended" | "pending_review"
    last_login: Optional[str]
    created_at: str


class UserManager:
    def create(self, tenant_id: str, email: str, name: str, role: str = "viewer") -> User:
        conn = get_shared_connection()
        u = User(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            email=email,
            name=name,
            role=role,
            mfa_enabled=0,
            status="active",
            last_login=None,
            created_at=_now(),
        )
        conn.execute(
            "INSERT OR REPLACE INTO users(id,tenant_id,email,name,role,mfa_enabled,status,last_login,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (u.id, u.tenant_id, u.email, u.name, u.role, u.mfa_enabled, u.status, u.last_login, u.created_at),
        )
        conn.commit()
        return u

    def get(self, user_id: str) -> Optional[User]:
        conn = get_shared_connection()
        row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return User(**dict(row)) if row else None

    def list_all(self, role: str | None = None, status: str | None = None) -> list[User]:
        conn = get_shared_connection()
        filters: list[str] = []
        params: list = []
        if role:
            filters.append("role=?")
            params.append(role)
        if status:
            filters.append("status=?")
            params.append(status)
        where = f"WHERE {' AND '.join(filters)}" if filters else ""
        rows = conn.execute(
            f"SELECT * FROM users {where} ORDER BY created_at DESC",
            tuple(params),
        ).fetchall()
        return [User(**dict(r)) for r in rows]

    def list(self, tenant_id: str, role: str | None = None, status: str | None = None) -> list[User]:
        conn = get_shared_connection()
        filters = ["tenant_id=?"]
        params: list = [tenant_id]
        if role:
            filters.append("role=?")
            params.append(role)
        if status:
            filters.append("status=?")
            params.append(status)
        rows = conn.execute(
            f"SELECT * FROM users WHERE {' AND '.join(filters)} ORDER BY created_at DESC",
            tuple(params),
        ).fetchall()
        return [User(**dict(r)) for r in rows]

    _ALLOWED_UPDATE_COLS = frozenset({
        "name", "role", "mfa_enabled", "status", "last_login",
    })

    def update(self, user_id: str, **kwargs) -> Optional[User]:
        invalid = set(kwargs) - self._ALLOWED_UPDATE_COLS
        if invalid:
            raise ValueError(f"Invalid update fields: {invalid}")
        # Second layer: build SET clause only from keys that are in the whitelist,
        # so injection is structurally impossible even if the check above is bypassed.
        safe = {k: v for k, v in kwargs.items() if k in self._ALLOWED_UPDATE_COLS}
        if not safe:
            return self.get(user_id)
        conn = get_shared_connection()
        sets = ", ".join(f"{k}=?" for k in safe)
        conn.execute(f"UPDATE users SET {sets} WHERE id=?", (*safe.values(), user_id))
        conn.commit()
        return self.get(user_id)

    def delete(self, user_id: str) -> bool:
        conn = get_shared_connection()
        c = conn.execute("DELETE FROM users WHERE id=?", (user_id,))
        conn.commit()
        return c.rowcount > 0

    def touch_last_login(self, email: str, tenant_id: str) -> None:
        """Update last_login timestamp for a user identified by email + tenant."""
        conn = get_shared_connection()
        conn.execute(
            "UPDATE users SET last_login=? WHERE email=? AND tenant_id=?",
            (_now(), email, tenant_id),
        )
        conn.commit()

    def enforce_mfa(self, tenant_id: str) -> int:
        conn = get_shared_connection()
        c = conn.execute(
            "UPDATE users SET mfa_enabled=1 WHERE tenant_id=? AND mfa_enabled=0",
            (tenant_id,),
        )
        conn.commit()
        return c.rowcount

    def import_csv(self, tenant_id: str, csv_text: str) -> list[User]:
        import csv
        import io

        reader = csv.DictReader(io.StringIO(csv_text))
        created = []
        for row in reader:
            try:
                u = self.create(
                    tenant_id=tenant_id,
                    email=row.get("email", ""),
                    name=row.get("name", ""),
                    role=row.get("role", "viewer"),
                )
                created.append(u)
            except Exception:
                continue
        return created
