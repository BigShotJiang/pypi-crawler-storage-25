"""Domain-specific exceptions for CoreIQ.

The hierarchy is intentionally shallow: every exception inherits from
``CoreIQError`` so callers can catch broad failures, but each layer has
its own type so structured error handling is possible without string
matching.
"""
from __future__ import annotations


class CoreIQError(Exception):
    """Base class for all CoreIQ errors."""

    def __init__(self, message: str, *, hint: str | None = None):
        super().__init__(message)
        self.hint = hint

    def __str__(self) -> str:
        if self.hint:
            return f"{super().__str__()} — hint: {self.hint}"
        return super().__str__()


# ---- Configuration / validation ------------------------------------------------


class ConfigError(CoreIQError):
    """Invalid or missing configuration."""


class ValidationError(CoreIQError):
    """Input failed validation."""


# ---- Storage layer -------------------------------------------------------------


class StorageError(CoreIQError):
    """Persistent-storage failure (read/write/migrate)."""


class DatabaseError(StorageError):
    """Backwards-compatible alias for storage errors."""


# ---- Auth / identity -----------------------------------------------------------


class AuthError(CoreIQError):
    """Authentication or virtual-key resolution failed."""


class AuthorizationError(AuthError):
    """Caller authenticated but lacks permission for this action."""


# ---- Policy / governance -------------------------------------------------------


class PolicyError(CoreIQError):
    """Policy bundle evaluation, signing, or load failure."""


class PolicyDeniedError(PolicyError):
    """A policy actively blocked the request."""


# ---- Pipeline / proxy ----------------------------------------------------------


class PipelineError(CoreIQError):
    """Failure during the proxy pipeline (pre-process, dispatch, post-process)."""


class ProviderError(PipelineError):
    """Upstream provider returned an error or was unreachable."""


class RateLimitError(PipelineError):
    """Per-key or per-tenant rate limit exceeded."""


class BulkheadError(PipelineError):
    """Per-tenant concurrency cap exceeded; request shed to protect the system."""


# ---- Secrets -------------------------------------------------------------------


class SecretsError(CoreIQError):
    """Failure resolving a secret from the configured provider."""
