"""Testing utilities — mock client and assertion helpers."""
import tempfile
from pathlib import Path
from typing import Any, Dict, List

from .store.writer import EventWriter


class MockCoreIQ:
    """Context manager that swaps the global writer for an in-memory (temp) one.

    Usage::

        from coreiq.testing import MockCoreIQ, assert_event_logged

        with MockCoreIQ() as mock:
            my_function()
            assert_event_logged(mock, "signup", plan="pro")
    """

    def __init__(self):
        self._writer = None
        self._w_module = None
        self._orig_writer = None
        self._tmp_dir = None

    def __enter__(self):
        self._tmp_dir = tempfile.mkdtemp()
        db_path = Path(self._tmp_dir) / "mock.db"
        self._writer = EventWriter(db_path)

        import coreiq.store.writer as w
        self._orig_writer = w._writer
        w._writer = self._writer
        self._w_module = w
        return self

    def __exit__(self, *_):
        if self._w_module is not None:
            self._w_module._writer = self._orig_writer

    @property
    def events(self) -> List[Dict[str, Any]]:
        """All events logged during the mock context."""
        rows = self._writer._conn.execute(
            "SELECT * FROM events ORDER BY ts"
        ).fetchall()
        return [dict(r) for r in rows]


def assert_event_logged(mock: MockCoreIQ, message: str, **kwargs) -> None:
    """Assert that an event with the given message (and metadata kwargs) was logged.

    Raises AssertionError if not found.
    """
    import json
    for ev in mock.events:
        if ev.get("message") == message:
            if not kwargs:
                return  # found, no kwargs to check
            meta_raw = ev.get("meta_json") or "{}"
            try:
                meta = json.loads(meta_raw)
            except (json.JSONDecodeError, TypeError):
                meta = {}
            if all(meta.get(k) == v for k, v in kwargs.items()):
                return
    kw_str = f" with metadata {kwargs}" if kwargs else ""
    all_msgs = [e.get("message") for e in mock.events]
    raise AssertionError(
        f"No event logged with message={message!r}{kw_str}.\n"
        f"Logged messages: {all_msgs}"
    )
