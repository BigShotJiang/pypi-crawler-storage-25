from __future__ import annotations
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ViolationCategory(str, Enum):
    INBOUND = "inbound"
    OUTBOUND = "outbound"
    POLICY = "policy"
    RATE_LIMIT = "rate_limit"
    AUTH = "auth"


@dataclass
class SecurityViolation:
    id: str
    tenant_id: str
    category: str
    severity: str
    trace_id: Optional[str]
    message: str
    details_json: Optional[str]
    action_taken: str
    ts: str


class ViolationRecorder:
    def record(self, *, tenant_id: str = "default", category: str,
               severity: str, message: str, trace_id: str | None = None,
               details: dict | None = None, action_taken: str = "blocked") -> str:
        conn = get_shared_connection()
        vid = str(uuid.uuid4())
        import json
        conn.execute(
            "INSERT INTO security_violations(id,tenant_id,category,severity,trace_id,message,details_json,action_taken,ts) VALUES(?,?,?,?,?,?,?,?,?)",
            (vid, tenant_id, category, severity, trace_id, message,
             json.dumps(details) if details else None, action_taken, _now())
        )
        conn.commit()
        return vid

    def query(self, *, tenant_id: str | None = None, category: str | None = None,
              severity: str | None = None, from_ts: str | None = None,
              to_ts: str | None = None, limit: int = 100, offset: int = 0) -> list[SecurityViolation]:
        conn = get_shared_connection()
        filters, params = [], []
        if tenant_id:
            filters.append("tenant_id=?")
            params.append(tenant_id)
        if category:
            filters.append("category=?")
            params.append(category)
        if severity:
            filters.append("severity=?")
            params.append(severity)
        if from_ts:
            filters.append("ts>=?")
            params.append(from_ts)
        if to_ts:
            filters.append("ts<=?")
            params.append(to_ts)
        where = (" WHERE " + " AND ".join(filters)) if filters else ""
        params += [limit, offset]
        rows = conn.execute(
            f"SELECT * FROM security_violations{where} ORDER BY ts DESC LIMIT ? OFFSET ?",
            tuple(params)
        ).fetchall()
        return [SecurityViolation(**dict(r)) for r in rows]

    def summary(self, tenant_id: str | None = None) -> dict:
        conn = get_shared_connection()
        where = " WHERE tenant_id=?" if tenant_id else ""
        params = (tenant_id,) if tenant_id else ()
        rows = conn.execute(
            f"SELECT category, severity, COUNT(*) as n FROM security_violations{where} GROUP BY category, severity",
            params
        ).fetchall()
        result: dict = {}
        for r in rows:
            result.setdefault(r["category"], {})[r["severity"]] = r["n"]
        return result


_recorder: ViolationRecorder | None = None


def get_violation_recorder() -> ViolationRecorder:
    global _recorder
    if _recorder is None:
        _recorder = ViolationRecorder()
    return _recorder
