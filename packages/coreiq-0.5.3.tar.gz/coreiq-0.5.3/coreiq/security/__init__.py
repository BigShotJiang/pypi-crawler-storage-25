"""Security utilities for CoreIQ."""
from .encryption import encrypt, decrypt
from .injection import check_prompt_injection, scan_for_injection, PromptInjectionError
from .pii import redact_pii, detect_pii, PIIPattern
from .output_guard import check_output, OutputViolationError, GuardRule
from .scanner import scan_messages, scan_and_redact, ScanResult
from .violations import (
    ViolationCategory, SecurityViolation, ViolationRecorder, get_violation_recorder,
)
from .posture import PostureScore, SecurityPostureEngine, get_posture_engine
from .incidents import IncidentManager, Incident, EscalationPolicy, IncidentSeverity
from .firewall import (
    AIFirewall, FirewallVerdict, LayerResult, ThreatLayer, CanaryLeak,
    inject_canary, detect_canary, detect_any_canary,
)

__all__ = [
    "encrypt", "decrypt",
    "check_prompt_injection", "scan_for_injection", "PromptInjectionError",
    "redact_pii", "detect_pii", "PIIPattern",
    "check_output", "OutputViolationError", "GuardRule",
    "scan_messages", "scan_and_redact", "ScanResult",
    "ViolationCategory", "SecurityViolation", "ViolationRecorder", "get_violation_recorder",
    "PostureScore", "SecurityPostureEngine", "get_posture_engine",
    "IncidentManager", "Incident", "EscalationPolicy", "IncidentSeverity",
    "AIFirewall", "FirewallVerdict", "LayerResult", "ThreatLayer", "CanaryLeak",
    "inject_canary", "detect_canary", "detect_any_canary",
]
