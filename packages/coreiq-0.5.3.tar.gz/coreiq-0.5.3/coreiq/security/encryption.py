"""Fernet symmetric encryption for sensitive config values.

Usage::

    import os
    os.environ["COREIQ_ENCRYPTION_KEY"] = "your-32-byte-hex-or-fernet-key"

    from coreiq.security.encryption import encrypt, decrypt
    ct = encrypt("sk-openai-secret")
    pt = decrypt(ct)  # "sk-openai-secret"

Key formats accepted via ``COREIQ_ENCRYPTION_KEY``:
- 44-char base64url Fernet key (e.g. from ``Fernet.generate_key().decode()``)
- 64-char hex string (32 raw bytes) — converted to Fernet key automatically
"""
from __future__ import annotations

import base64
import os

try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "cryptography package is required for encryption. "
        "Install it: pip install 'coreiq[security]'"
    ) from exc


def _get_fernet() -> Fernet:
    key = os.environ.get("COREIQ_ENCRYPTION_KEY", "")
    if not key:
        raise RuntimeError(
            "COREIQ_ENCRYPTION_KEY environment variable is not set. "
            "Generate one with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
        )
    if len(key) == 44:
        # Already a Fernet key (base64url, 32 bytes encoded)
        return Fernet(key.encode())
    if len(key) == 64:
        # 32-byte hex string
        try:
            raw = bytes.fromhex(key)
        except ValueError as exc:
            raise ValueError("COREIQ_ENCRYPTION_KEY must be a 44-char Fernet key or 64-char hex string") from exc
        return Fernet(base64.urlsafe_b64encode(raw))
    raise ValueError(
        f"COREIQ_ENCRYPTION_KEY has unexpected length {len(key)}. "
        "Must be 44-char Fernet key or 64-char hex string."
    )


def encrypt(plaintext: str) -> str:
    """Encrypt *plaintext* and return a base64url-encoded ciphertext string."""
    return _get_fernet().encrypt(plaintext.encode()).decode()


def decrypt(ciphertext: str) -> str:
    """Decrypt a ciphertext produced by :func:`encrypt`."""
    try:
        return _get_fernet().decrypt(ciphertext.encode()).decode()
    except InvalidToken as exc:
        raise ValueError("Decryption failed: invalid ciphertext or wrong key") from exc
