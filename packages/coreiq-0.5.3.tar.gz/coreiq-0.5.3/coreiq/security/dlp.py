"""Data Loss Prevention (DLP) for AI — classify and block sensitive data.

Goes beyond PII to detect business-sensitive data categories:
- Financial data (revenue, earnings, forecasts)
- Cloud credentials (AWS keys, GCP tokens, Azure secrets)
- Source code / trade secrets
- Internal identifiers (employee IDs, project codenames)

Usage::

    dlp = DLPEngine()
    result = dlp.scan("Our Q3 revenue is $42M and AWS key is AKIA...")
    # result.findings: [financial_data, cloud_credential]
    # result.action: "block"
"""
from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class DataCategory(str, Enum):
    financial = "financial"
    credential = "credential"
    source_code = "source_code"
    internal_id = "internal_id"
    medical = "medical"
    legal = "legal"
    pii = "pii"


class DLPAction(str, Enum):
    allow = "allow"
    redact = "redact"
    block = "block"
    warn = "warn"


@dataclass
class DLPRule:
    name: str
    category: DataCategory
    pattern: str
    action: DLPAction = DLPAction.block
    description: str = ""

    def __post_init__(self):
        self._compiled = re.compile(self.pattern, re.IGNORECASE)

    @property
    def compiled(self) -> re.Pattern:
        if not hasattr(self, '_compiled'):
            self._compiled = re.compile(self.pattern, re.IGNORECASE)
        return self._compiled


@dataclass
class DLPFinding:
    rule_name: str
    category: str
    action: str
    matched_text: str
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_name": self.rule_name,
            "category": self.category,
            "action": self.action,
            "matched_text": self.matched_text[:50] + "..." if len(self.matched_text) > 50 else self.matched_text,
            "description": self.description,
        }


@dataclass
class DLPResult:
    clean: bool
    action: str  # worst action across all findings
    findings: List[DLPFinding] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "clean": self.clean,
            "action": self.action,
            "findings": [f.to_dict() for f in self.findings],
            "finding_count": len(self.findings),
        }


DEFAULT_DLP_RULES: List[DLPRule] = [
    # Financial
    DLPRule("revenue_data", DataCategory.financial,
            r"(?:revenue|earnings|profit|EBITDA|net\s+income)\s*(?:is|was|of|:)?\s*\$[\d,.]+[MBKmk]?",
            DLPAction.redact, "Financial revenue/earnings data"),
    DLPRule("forecast_data", DataCategory.financial,
            r"(?:forecast|projection|guidance|target)\s*(?:is|of|:)?\s*\$[\d,.]+",
            DLPAction.redact, "Financial forecast/projection"),
    # Credentials
    DLPRule("aws_access_key", DataCategory.credential,
            r"AKIA[0-9A-Z]{16}", DLPAction.block, "AWS Access Key ID"),
    DLPRule("aws_secret_key", DataCategory.credential,
            r"(?:aws_secret|secret_key|SECRET_ACCESS_KEY)\s*[:=]\s*[A-Za-z0-9/+=]{30,}",
            DLPAction.block, "AWS Secret Access Key"),
    DLPRule("gcp_service_account", DataCategory.credential,
            r'"type"\s*:\s*"service_account"', DLPAction.block, "GCP service account JSON"),
    DLPRule("azure_connection_string", DataCategory.credential,
            r"(?:DefaultEndpointsProtocol|AccountKey)=[^;\s]{20,}",
            DLPAction.block, "Azure connection string"),
    DLPRule("private_key", DataCategory.credential,
            r"-----BEGIN\s+(?:RSA\s+)?PRIVATE\s+KEY-----",
            DLPAction.block, "Private key"),
    DLPRule("generic_api_key", DataCategory.credential,
            r"sk-[A-Za-z0-9]{20,}", DLPAction.block, "API key (sk-...)"),
    DLPRule("database_url", DataCategory.credential,
            r"(?:postgres|mysql|mongodb)://\S+:\S+@\S+",
            DLPAction.block, "Database connection URL with credentials"),
    # Source code / trade secrets
    DLPRule("source_code_block", DataCategory.source_code,
            r"(?:def\s+\w+\s*\(|class\s+\w+\s*[:(]|function\s+\w+\s*\(|import\s+\w+\s+from)\s*.*\n.*\n.*",
            DLPAction.warn, "Source code block detected"),
    # Internal identifiers
    DLPRule("employee_id", DataCategory.internal_id,
            r"(?:employee|emp|staff)\s*(?:id|#|number)\s*[:=]?\s*[A-Z]?\d{4,8}",
            DLPAction.redact, "Employee ID"),
    # Medical
    DLPRule("medical_record", DataCategory.medical,
            r"(?:diagnosis|prescription|patient\s+id|medical\s+record)\s*[:=]\s*\S+",
            DLPAction.block, "Medical record data"),
    # PII (extended)
    DLPRule("credit_card", DataCategory.pii,
            r"\b(?:4[0-9]{3}|5[1-5][0-9]{2}|3[47][0-9]{2}|6(?:011|5[0-9]{2}))[- ]?[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}\b",
            DLPAction.block, "Credit card number"),
    DLPRule("ssn", DataCategory.pii,
            r"\b\d{3}-\d{2}-\d{4}\b", DLPAction.block, "Social Security Number"),
    DLPRule("passport", DataCategory.pii,
            r"(?:passport)\s*(?:#|number|no)?\s*[:=]?\s*[A-Z0-9]{6,12}",
            DLPAction.block, "Passport number"),
]

ACTION_PRIORITY = {DLPAction.allow: 0, DLPAction.warn: 1, DLPAction.redact: 2, DLPAction.block: 3}


class DLPEngine:
    """Data Loss Prevention engine for AI inputs/outputs."""

    def __init__(self, rules: Optional[List[DLPRule]] = None):
        self.rules = rules if rules is not None else list(DEFAULT_DLP_RULES)

    def scan(self, text: str) -> DLPResult:
        findings = []
        worst_action = DLPAction.allow

        for rule in self.rules:
            m = rule.compiled.search(text)
            if m:
                findings.append(DLPFinding(
                    rule_name=rule.name, category=rule.category.value,
                    action=rule.action.value, matched_text=m.group(),
                    description=rule.description,
                ))
                if ACTION_PRIORITY.get(rule.action, 0) > ACTION_PRIORITY.get(worst_action, 0):
                    worst_action = rule.action

        return DLPResult(
            clean=len(findings) == 0,
            action=worst_action.value,
            findings=findings,
        )

    def scan_messages(self, messages: List[Dict[str, Any]]) -> DLPResult:
        combined = DLPResult(clean=True, action="allow")
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                result = self.scan(content)
                combined.findings.extend(result.findings)
                if ACTION_PRIORITY.get(DLPAction(result.action), 0) > ACTION_PRIORITY.get(DLPAction(combined.action), 0):
                    combined.action = result.action
        combined.clean = len(combined.findings) == 0
        return combined
