"""Egress/SSRF protection service.

Ported from sdk-go's CheckEgress pattern. Validates outbound URLs
against private IP ranges and configurable allow/deny lists.
"""
from __future__ import annotations
import ipaddress
import logging
from dataclasses import dataclass
from urllib.parse import urlparse

logger = logging.getLogger("coreiq.security.egress")

# Private/internal IP ranges that should never be accessed
_PRIVATE_RANGES = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),  # link-local
    ipaddress.ip_network("::1/128"),           # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),          # IPv6 private
    ipaddress.ip_network("fe80::/10"),         # IPv6 link-local
]

_BLOCKED_HOSTNAMES = {"localhost", "metadata.google.internal", "169.254.169.254"}

@dataclass
class EgressDecision:
    allowed: bool
    reason: str
    url: str

class EgressChecker:
    """Validates outbound URLs for SSRF protection."""

    def __init__(self, *, allow_list: list[str] | None = None, deny_list: list[str] | None = None, block_private: bool = True):
        self.allow_list = set(allow_list or [])
        self.deny_list = set(deny_list or [])
        self.block_private = block_private

    def check(self, raw_url: str) -> EgressDecision:
        """Check if an outbound URL is safe."""
        if not raw_url or not raw_url.strip():
            return EgressDecision(allowed=False, reason="empty URL", url=raw_url)

        try:
            parsed = urlparse(raw_url)
        except Exception:
            return EgressDecision(allowed=False, reason="invalid URL", url=raw_url)

        # Must have scheme
        if parsed.scheme not in ("http", "https"):
            return EgressDecision(allowed=False, reason=f"blocked scheme: {parsed.scheme}", url=raw_url)

        hostname = (parsed.hostname or "").lower().strip(".")
        if not hostname:
            return EgressDecision(allowed=False, reason="no hostname", url=raw_url)

        # Explicit deny list
        if hostname in self.deny_list or any(hostname.endswith(f".{d}") for d in self.deny_list):
            return EgressDecision(allowed=False, reason=f"hostname in deny list: {hostname}", url=raw_url)

        # Explicit allow list (if set, only these are allowed)
        if self.allow_list:
            if hostname in self.allow_list or any(hostname.endswith(f".{a}") for a in self.allow_list):
                return EgressDecision(allowed=True, reason="hostname in allow list", url=raw_url)
            return EgressDecision(allowed=False, reason=f"hostname not in allow list: {hostname}", url=raw_url)

        # Block known dangerous hostnames
        if hostname in _BLOCKED_HOSTNAMES:
            return EgressDecision(allowed=False, reason=f"blocked hostname: {hostname}", url=raw_url)

        # Block private IPs
        if self.block_private:
            try:
                ip = ipaddress.ip_address(hostname)
                for net in _PRIVATE_RANGES:
                    if ip in net:
                        return EgressDecision(allowed=False, reason=f"private IP: {hostname}", url=raw_url)
            except ValueError:
                pass  # Not an IP — hostname is fine

        return EgressDecision(allowed=True, reason="allowed", url=raw_url)
