"""Output safety guardrails."""
import re
from dataclasses import dataclass
from typing import Optional

from ..exceptions import ValidationError


@dataclass
class GuardRule:
    name: str
    pattern: str
    description: str = ""


@dataclass
class OutputViolationError(ValidationError):
    rule: str
    text: str

    def __post_init__(self) -> None:
        if len(self.text) > 80:
            self.text = self.text[:80] + "[REDACTED]"
        Exception.__init__(self, self.rule, self.text)

    def __str__(self) -> str:
        return f"Output guard violation [{self.rule}]: content blocked"


_DEFAULT_RULES: list[GuardRule] = [
    GuardRule("no_credentials",
              r"(?:(?:password|passwd|secret|api_key|token)\s*[:=]\s*\S+"
              r"|Bearer\s+[A-Za-z0-9\-._~+/]+=*"
              r"|sk-[A-Za-z0-9]{20,}"
              r"|AKIA[0-9A-Z]{16})",
              "Potential credential leak in output"),
    GuardRule("no_system_paths", r"(?:/etc/passwd|/etc/shadow|C:\\Windows\\System32)",
              "System path reference in output"),
    GuardRule("no_sql_dump", r"(?:DROP\s+TABLE|DELETE\s+FROM|INSERT\s+INTO)\s+\w+",
              "SQL statement in output"),
]


def check_output(
    text: str,
    rules: Optional[list[GuardRule]] = None,
    *,
    raise_on_violation: bool = True,
) -> list[str]:
    """
    Check model output against safety rules.
    Returns list of violated rule names.
    Raises OutputViolationError on first match if raise_on_violation=True.
    """
    active = rules if rules is not None else _DEFAULT_RULES
    violations: list[str] = []
    for rule in active:
        if re.search(rule.pattern, text, flags=re.IGNORECASE):
            if raise_on_violation:
                raise OutputViolationError(rule=rule.name, text=text)
            violations.append(rule.name)
    return violations
