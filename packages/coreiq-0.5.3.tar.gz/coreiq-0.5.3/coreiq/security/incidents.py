from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from ..store.db import get_shared_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class IncidentSeverity(str, Enum):
    P1 = "p1"
    P2 = "p2"
    P3 = "p3"
    P4 = "p4"


@dataclass
class Incident:
    id: str
    tenant_id: str
    title: str
    severity: str
    status: str
    violation_ids_json: str
    assignee: Optional[str]
    escalation_policy_id: Optional[str]
    timeline_json: str
    breach_notification_required: int
    created_at: str
    resolved_at: Optional[str]


@dataclass
class EscalationPolicy:
    id: str
    tenant_id: str
    name: str
    levels_json: str
    created_at: str


class IncidentManager:
    def create(
        self,
        *,
        tenant_id: str,
        title: str,
        severity: str = "p3",
        violation_ids: list[str] | None = None,
    ) -> Incident:
        conn = get_shared_connection()
        inc = Incident(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            title=title,
            severity=severity,
            status="open",
            violation_ids_json=json.dumps(violation_ids or []),
            assignee=None,
            escalation_policy_id=None,
            timeline_json=json.dumps([{"ts": _now(), "action": "created", "note": "Incident created"}]),
            breach_notification_required=0,
            created_at=_now(),
            resolved_at=None,
        )
        conn.execute(
            "INSERT INTO incidents(id,tenant_id,title,severity,status,violation_ids_json,assignee,"
            "escalation_policy_id,timeline_json,breach_notification_required,created_at,resolved_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                inc.id,
                inc.tenant_id,
                inc.title,
                inc.severity,
                inc.status,
                inc.violation_ids_json,
                inc.assignee,
                inc.escalation_policy_id,
                inc.timeline_json,
                inc.breach_notification_required,
                inc.created_at,
                inc.resolved_at,
            ),
        )
        conn.commit()
        return inc

    def get(self, incident_id: str) -> Optional[Incident]:
        row = get_shared_connection().execute(
            "SELECT * FROM incidents WHERE id=?", (incident_id,)
        ).fetchone()
        return Incident(**dict(row)) if row else None

    def list(self, tenant_id: str | None = None, status: str | None = None) -> list[Incident]:
        filters: list[str] = []
        params: list = []
        if tenant_id:
            filters.append("tenant_id=?")
            params.append(tenant_id)
        if status:
            filters.append("status=?")
            params.append(status)
        where = (" WHERE " + " AND ".join(filters)) if filters else ""
        rows = get_shared_connection().execute(
            f"SELECT * FROM incidents{where} ORDER BY created_at DESC", tuple(params)
        ).fetchall()
        return [Incident(**dict(r)) for r in rows]

    def _update_timeline(self, incident_id: str, action: str, note: str) -> None:
        conn = get_shared_connection()
        row = conn.execute("SELECT timeline_json FROM incidents WHERE id=?", (incident_id,)).fetchone()
        if row:
            timeline = json.loads(row["timeline_json"])
            timeline.append({"ts": _now(), "action": action, "note": note})
            conn.execute(
                "UPDATE incidents SET timeline_json=? WHERE id=?",
                (json.dumps(timeline), incident_id),
            )
            conn.commit()

    def acknowledge(self, incident_id: str, assignee: str) -> Optional[Incident]:
        conn = get_shared_connection()
        conn.execute(
            "UPDATE incidents SET status='acknowledged', assignee=? WHERE id=?",
            (assignee, incident_id),
        )
        conn.commit()
        self._update_timeline(incident_id, "acknowledged", f"Acknowledged by {assignee}")
        return self.get(incident_id)

    def resolve(self, incident_id: str, resolution: str = "") -> Optional[Incident]:
        conn = get_shared_connection()
        conn.execute(
            "UPDATE incidents SET status='resolved', resolved_at=? WHERE id=?",
            (_now(), incident_id),
        )
        conn.commit()
        self._update_timeline(incident_id, "resolved", resolution or "Resolved")
        return self.get(incident_id)

    def list_escalation_policies(self, tenant_id: str | None = None) -> list[EscalationPolicy]:
        where = " WHERE tenant_id=?" if tenant_id else ""
        rows = get_shared_connection().execute(
            f"SELECT * FROM escalation_policies{where} ORDER BY created_at DESC",
            (tenant_id,) if tenant_id else (),
        ).fetchall()
        return [EscalationPolicy(**dict(r)) for r in rows]

    def create_escalation_policy(
        self, tenant_id: str, name: str, levels: list[dict]
    ) -> EscalationPolicy:
        conn = get_shared_connection()
        ep = EscalationPolicy(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            name=name,
            levels_json=json.dumps(levels),
            created_at=_now(),
        )
        conn.execute(
            "INSERT INTO escalation_policies(id,tenant_id,name,levels_json,created_at) VALUES(?,?,?,?,?)",
            (ep.id, ep.tenant_id, ep.name, ep.levels_json, ep.created_at),
        )
        conn.commit()
        return ep
