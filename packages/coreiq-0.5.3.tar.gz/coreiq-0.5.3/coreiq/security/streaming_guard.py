"""Streaming Guardrails — real-time token-by-token scanning with mid-stream cutoff.

Scans LLM streaming output as tokens arrive and can cut off the stream
mid-response when a policy violation is detected. This prevents harmful
content from reaching the user before the full response is complete.

Architecture::

    LLM Stream → StreamingGuard.filter_stream()
                   ├─ Accumulates tokens in a sliding window
                   ├─ Runs pattern checks every N tokens
                   ├─ On violation: yields cutoff message, stops stream
                   └─ On clean: passes tokens through unchanged

Usage::

    guard = StreamingGuard(rules=[...])
    async for chunk in guard.filter_stream(llm_chunks):
        yield chunk  # safe chunks only
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, AsyncIterator, Dict, List, Optional

logger = logging.getLogger(__name__)


class ViolationType(str, Enum):
    credential_leak = "credential_leak"
    pii_leak = "pii_leak"
    harmful_content = "harmful_content"
    injection_echo = "injection_echo"
    custom_rule = "custom_rule"


@dataclass
class StreamingViolation:
    """A violation detected during streaming."""
    type: ViolationType
    rule_name: str
    matched_text: str
    token_position: int
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type.value,
            "rule_name": self.rule_name,
            "matched_text": self.matched_text[:80] + "..." if len(self.matched_text) > 80 else self.matched_text,
            "token_position": self.token_position,
        }


@dataclass
class StreamGuardRule:
    """A rule for scanning streaming output."""
    name: str
    pattern: str
    type: ViolationType = ViolationType.custom_rule
    description: str = ""
    action: str = "block"  # "block" or "warn"

    def __post_init__(self):
        self._compiled = re.compile(self.pattern, re.IGNORECASE)

    @property
    def compiled(self) -> re.Pattern:
        if not hasattr(self, '_compiled'):
            self._compiled = re.compile(self.pattern, re.IGNORECASE)
        return self._compiled


# Default streaming rules — things that should never appear in LLM output
DEFAULT_STREAM_RULES: List[StreamGuardRule] = [
    StreamGuardRule(
        name="credential_leak",
        pattern=r"(?:password|passwd|secret|api_key|token)\s*[:=]\s*\S{8,}",
        type=ViolationType.credential_leak,
        description="Credentials appearing in output",
    ),
    StreamGuardRule(
        name="api_key_leak",
        pattern=r"sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}",
        type=ViolationType.credential_leak,
        description="API key or AWS access key in output",
    ),
    StreamGuardRule(
        name="ssn_leak",
        pattern=r"\b\d{3}-\d{2}-\d{4}\b",
        type=ViolationType.pii_leak,
        description="Social Security Number in output",
    ),
    StreamGuardRule(
        name="system_prompt_echo",
        pattern=r"(?:system\s+prompt|my\s+instructions?\s+(?:are|say)|I\s+was\s+(?:told|instructed)\s+to)",
        type=ViolationType.injection_echo,
        description="Model echoing system prompt contents",
    ),
    StreamGuardRule(
        name="harmful_instructions",
        pattern=r"(?:how\s+to\s+(?:make|build|create)\s+(?:a\s+)?(?:bomb|weapon|explosive))"
                r"|(?:step\s+\d+[.:]\s*(?:obtain|acquire|mix|combine)\s+\w+\s+(?:explosive|chemical|poison))",
        type=ViolationType.harmful_content,
        description="Harmful instruction generation",
    ),
    StreamGuardRule(
        name="sql_injection_output",
        pattern=r"(?:DROP\s+TABLE|DELETE\s+FROM|INSERT\s+INTO|UPDATE\s+\w+\s+SET)\s+\w+",
        type=ViolationType.custom_rule,
        description="SQL statements in output",
    ),
    StreamGuardRule(
        name="system_path_leak",
        pattern=r"(?:/etc/passwd|/etc/shadow|C:\\Windows\\System32\\config)",
        type=ViolationType.credential_leak,
        description="Sensitive system path in output",
    ),
]


CUTOFF_MESSAGE = "\n\n[Response blocked: policy violation detected in streaming output]"


@dataclass
class StreamGuardResult:
    """Summary of a streaming guard session."""
    total_tokens: int = 0
    total_chars: int = 0
    violations: List[StreamingViolation] = field(default_factory=list)
    was_cut_off: bool = False
    cutoff_position: Optional[int] = None
    duration_ms: int = 0

    @property
    def clean(self) -> bool:
        return len(self.violations) == 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_tokens": self.total_tokens,
            "total_chars": self.total_chars,
            "clean": self.clean,
            "violations": [v.to_dict() for v in self.violations],
            "was_cut_off": self.was_cut_off,
            "cutoff_position": self.cutoff_position,
            "duration_ms": self.duration_ms,
        }


class StreamingGuard:
    """Real-time streaming output scanner with mid-stream cutoff.

    Accumulates tokens in a sliding window and checks against guard rules
    every ``check_interval`` tokens. When a violation is detected:

    1. Immediately stops yielding content tokens
    2. Yields a cutoff message (configurable)
    3. Records the violation for audit

    Args:
        rules: List of StreamGuardRule to check against.
            Defaults to DEFAULT_STREAM_RULES.
        check_interval: Check every N tokens (default 3).
            Lower = more responsive but more CPU.
        window_size: Characters to keep in sliding window (default 500).
        cutoff_message: Message to inject when cutting off.
        on_violation: Optional callback(StreamingViolation) for alerts.
    """

    def __init__(
        self,
        rules: Optional[List[StreamGuardRule]] = None,
        *,
        check_interval: int = 3,
        window_size: int = 500,
        cutoff_message: str = CUTOFF_MESSAGE,
        on_violation=None,
    ):
        self.rules = rules if rules is not None else list(DEFAULT_STREAM_RULES)
        self.check_interval = max(1, check_interval)
        self.window_size = window_size
        self.cutoff_message = cutoff_message
        self.on_violation = on_violation

    def scan_text(self, text: str) -> List[StreamingViolation]:
        """Scan accumulated text against all rules. Returns violations found."""
        violations = []
        for rule in self.rules:
            m = rule.compiled.search(text)
            if m:
                violations.append(StreamingViolation(
                    type=rule.type,
                    rule_name=rule.name,
                    matched_text=m.group(),
                    token_position=m.start(),
                ))
        return violations

    async def filter_stream(
        self,
        chunks: AsyncIterator,
        *,
        extract_text=None,
    ) -> AsyncIterator[dict]:
        """Filter an async stream of chunks, cutting off on violation.

        Args:
            chunks: Async iterator of chunk objects (dicts or dataclass).
            extract_text: Optional callable to extract text from a chunk.
                Default expects chunk["text"] or chunk.text.

        Yields:
            Chunks that passed scanning. On violation, yields a final
            chunk with the cutoff message and stops.
        """
        start = time.monotonic()
        result = StreamGuardResult()
        buffer = ""
        token_count = 0

        async for chunk in chunks:
            # Extract text from chunk
            if extract_text:
                text = extract_text(chunk)
            elif isinstance(chunk, dict):
                text = chunk.get("text", "") or ""
            elif hasattr(chunk, "text"):
                text = chunk.text or ""
            else:
                text = str(chunk)

            if text:
                buffer += text
                token_count += 1
                result.total_tokens = token_count
                result.total_chars += len(text)

                # Trim buffer to window size
                if len(buffer) > self.window_size:
                    buffer = buffer[-self.window_size:]

                # Check at intervals
                if token_count % self.check_interval == 0:
                    violations = self.scan_text(buffer)
                    if violations:
                        for v in violations:
                            v.token_position = token_count
                            result.violations.append(v)
                            if self.on_violation:
                                try:
                                    self.on_violation(v)
                                except Exception:
                                    pass

                        # Check for blocking violations
                        blocking = [v for v in violations
                                    if any(r.action == "block" and r.name == v.rule_name
                                           for r in self.rules)]
                        if blocking:
                            result.was_cut_off = True
                            result.cutoff_position = token_count
                            result.duration_ms = int((time.monotonic() - start) * 1000)

                            logger.warning(
                                "Streaming guardrail CUT OFF at token %d: %s",
                                token_count, blocking[0].rule_name,
                            )

                            # Yield cutoff message as final chunk
                            yield {"text": self.cutoff_message, "is_cutoff": True,
                                   "violation": blocking[0].to_dict(), "guard_result": result.to_dict()}
                            return

            # Pass through clean chunk
            yield chunk

        # Final check on remaining buffer
        if buffer:
            violations = self.scan_text(buffer)
            for v in violations:
                v.token_position = token_count
                result.violations.append(v)

        result.duration_ms = int((time.monotonic() - start) * 1000)

    def scan_complete_text(self, text: str) -> StreamGuardResult:
        """Scan a complete text (non-streaming). Useful for testing."""
        start = time.monotonic()
        violations = self.scan_text(text)
        result = StreamGuardResult(
            total_tokens=len(text.split()),
            total_chars=len(text),
            violations=violations,
            was_cut_off=False,
            duration_ms=int((time.monotonic() - start) * 1000),
        )
        return result
