"""Multi-Modal Guardrails — content scanning for images, audio references, and mixed media.

Scans multi-modal LLM inputs/outputs for policy violations:
- Image URL validation (block known NSFW domains, detect data URI abuse)
- File type validation
- Content type restrictions
- Size limits
"""
from __future__ import annotations
import re
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum
logger = logging.getLogger(__name__)

class MediaType(str, Enum):
    image = "image"
    audio = "audio"
    video = "video"
    document = "document"

@dataclass
class MediaViolation:
    type: str
    rule: str
    detail: str
    def to_dict(self) -> Dict[str, Any]:
        return {"type": self.type, "rule": self.rule, "detail": self.detail}

@dataclass
class MultiModalResult:
    clean: bool
    media_items_scanned: int
    violations: List[MediaViolation] = field(default_factory=list)
    def to_dict(self) -> Dict[str, Any]:
        return {"clean": self.clean, "media_items_scanned": self.media_items_scanned, "violations": [v.to_dict() for v in self.violations]}

BLOCKED_DOMAINS = {"nsfw-site.com", "explicit-content.net", "adult-images.org"}
ALLOWED_IMAGE_TYPES = {"png", "jpg", "jpeg", "gif", "webp", "svg"}
MAX_DATA_URI_SIZE = 10 * 1024 * 1024  # 10MB

class MultiModalGuard:
    def __init__(self, blocked_domains: Optional[set] = None, max_data_uri_size: int = MAX_DATA_URI_SIZE):
        self.blocked_domains = blocked_domains or BLOCKED_DOMAINS
        self.max_size = max_data_uri_size

    def scan_messages(self, messages: List[Dict[str, Any]]) -> MultiModalResult:
        violations = []
        scanned = 0
        for msg in messages:
            content = msg.get("content")
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "image_url":
                            scanned += 1
                            url = block.get("image_url", {}).get("url", "")
                            violations.extend(self._check_image_url(url))
                        elif block.get("type") == "image":
                            scanned += 1
                            url = block.get("source", {}).get("data", "")
                            if len(url) > self.max_size:
                                violations.append(MediaViolation("image", "size_limit", f"Data exceeds {self.max_size} bytes"))
        return MultiModalResult(clean=len(violations) == 0, media_items_scanned=scanned, violations=violations)

    def _check_image_url(self, url: str) -> List[MediaViolation]:
        violations = []
        if url.startswith("data:"):
            if len(url) > self.max_size:
                violations.append(MediaViolation("image", "data_uri_size", f"Data URI exceeds {self.max_size} bytes"))
            mime = url.split(";")[0].split(":")[1] if ":" in url and ";" in url else ""
            if mime and not any(t in mime for t in ALLOWED_IMAGE_TYPES):
                violations.append(MediaViolation("image", "invalid_mime", f"MIME type '{mime}' not allowed"))
        else:
            domain = re.sub(r"https?://", "", url).split("/")[0].lower()
            if domain in self.blocked_domains:
                violations.append(MediaViolation("image", "blocked_domain", f"Domain '{domain}' is blocked"))
            # Extract file extension from the URL path (ignore domain and query string)
            from urllib.parse import urlparse
            path = urlparse(url).path
            ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
            if ext and ext not in ALLOWED_IMAGE_TYPES:
                violations.append(MediaViolation("image", "invalid_extension", f"Extension '.{ext}' not allowed"))
        return violations
