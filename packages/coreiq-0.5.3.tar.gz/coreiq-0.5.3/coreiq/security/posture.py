from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from ..store.db import get_shared_connection


@dataclass
class PostureScore:
    overall: float
    grade: str
    components: dict
    open_risks: list[dict]
    recommendations: list[str]
    as_of: str


class SecurityPostureEngine:
    """Calculates a 0-100 security posture score."""

    def calculate_score(self, tenant_id: str | None = None, hours: int = 24) -> PostureScore:
        conn = get_shared_connection()
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()

        where_t = " WHERE tenant_id=? AND ts>?" if tenant_id else " WHERE ts>?"
        params_t = (tenant_id, cutoff) if tenant_id else (cutoff,)
        where_base = " WHERE tenant_id=?" if tenant_id else ""
        params_base = (tenant_id,) if tenant_id else ()

        # 1. Violation rate score (lower violations = higher score)
        total_row = conn.execute(
            "SELECT COUNT(*) as n FROM traces" + (
                " WHERE tenant_id=? AND ts>?" if tenant_id else " WHERE ts>?"
            ),
            params_t
        ).fetchone()
        viol_row = conn.execute(
            f"SELECT COUNT(*) as n FROM security_violations{where_t}",
            params_t
        ).fetchone()
        total_req = max(total_row["n"] or 0, 1)
        violations = viol_row["n"] or 0
        viol_rate = violations / total_req
        viol_score = max(0.0, 100.0 - (viol_rate * 1000))

        # 2. Auth coverage (% requests with virtual_key_id)
        auth_row = conn.execute(
            "SELECT COUNT(*) as n FROM traces WHERE virtual_key_id IS NOT NULL AND virtual_key_id != ''"
            + (" AND tenant_id=?" if tenant_id else "")
            + " AND ts>?",
            ((tenant_id, cutoff) if tenant_id else (cutoff,))
        ).fetchone()
        auth_score = min(100.0, (auth_row["n"] or 0) / total_req * 100)

        # 3. Active guardrails (any group_guardrules configured)
        guardrail_row = conn.execute(
            "SELECT COUNT(*) as n FROM group_guardrules" + where_base,
            params_base
        ).fetchone()
        guardrail_score = 80.0 if (guardrail_row["n"] or 0) > 0 else 40.0

        # 4. Policy coverage (any group_policies configured)
        policy_row = conn.execute(
            "SELECT COUNT(*) as n FROM group_policies" + where_base,
            params_base
        ).fetchone()
        policy_score = 80.0 if (policy_row["n"] or 0) > 0 else 40.0

        # Overall weighted score
        overall = (
            viol_score * 0.35 +
            auth_score * 0.25 +
            guardrail_score * 0.25 +
            policy_score * 0.15
        )
        overall = round(min(100.0, max(0.0, overall)), 1)

        # Grade
        grade = "A" if overall >= 90 else "B" if overall >= 75 else "C" if overall >= 60 else "D" if overall >= 45 else "F"

        # Open risks
        open_risks = []
        if viol_rate > 0.01:
            open_risks.append({"risk": "High violation rate", "severity": "high", "category": "security"})
        if auth_score < 50:
            open_risks.append({"risk": "Low auth coverage — many unauthenticated requests", "severity": "medium", "category": "auth"})
        if guardrail_score < 60:
            open_risks.append({"risk": "No guardrail rules configured", "severity": "medium", "category": "guardrails"})
        if policy_score < 60:
            open_risks.append({"risk": "No group policies configured", "severity": "low", "category": "policy"})

        # Recommendations
        recommendations = []
        if auth_score < 80:
            recommendations.append("Enforce virtual API keys for all clients")
        if guardrail_score < 80:
            recommendations.append("Configure guardrail rules for PII detection")
        if policy_score < 80:
            recommendations.append("Set up group policies for model access control")

        return PostureScore(
            overall=overall,
            grade=grade,
            components={"violations": round(viol_score, 1), "auth": round(auth_score, 1),
                        "guardrails": round(guardrail_score, 1), "policy": round(policy_score, 1)},
            open_risks=open_risks,
            recommendations=recommendations,
            as_of=datetime.now(timezone.utc).isoformat(),
        )

    def get_trend(self, tenant_id: str | None = None, days: int = 30) -> list[dict]:
        result = []
        for i in range(days, 0, -1):
            d = (datetime.now(timezone.utc) - timedelta(days=i)).strftime("%Y-%m-%d")
            score = self.calculate_score(tenant_id=tenant_id, hours=24)
            result.append({"date": d, "score": score.overall, "grade": score.grade})
        return result


_engine: SecurityPostureEngine | None = None


def get_posture_engine() -> SecurityPostureEngine:
    global _engine
    if _engine is None:
        _engine = SecurityPostureEngine()
    return _engine
