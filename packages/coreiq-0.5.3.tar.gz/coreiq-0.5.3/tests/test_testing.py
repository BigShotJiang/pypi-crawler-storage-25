"""Tests for coreiq.testing module."""
import pytest


@pytest.fixture(autouse=True)
def _reset_writer(tmp_path, monkeypatch):
    monkeypatch.setenv("COREIQ_DB_PATH", str(tmp_path / "test.db"))
    import coreiq.store.writer as w
    w._writer = None
    yield
    w._writer = None


def test_mock_captures_events():
    import coreiq
    from coreiq.testing import MockCoreIQ

    with MockCoreIQ() as mock:
        coreiq.log_event("hello world")
        assert len(mock.events) == 1
        assert mock.events[0]["message"] == "hello world"


def test_mock_restores_writer_after_exit():
    from coreiq.testing import MockCoreIQ
    import coreiq.store.writer as w

    original = w._writer
    with MockCoreIQ() as mock:
        assert w._writer is mock._writer
    assert w._writer is original


def test_assert_event_logged_passes():
    import coreiq
    from coreiq.testing import MockCoreIQ, assert_event_logged

    with MockCoreIQ() as mock:
        coreiq.log_event("signup", {"plan": "pro", "user_id": "u1"})
        assert_event_logged(mock, "signup", plan="pro", user_id="u1")


def test_assert_event_logged_fails_wrong_message():
    import coreiq
    from coreiq.testing import MockCoreIQ, assert_event_logged

    with MockCoreIQ() as mock:
        coreiq.log_event("login")
        with pytest.raises(AssertionError):
            assert_event_logged(mock, "signup")


def test_assert_event_logged_fails_wrong_kwargs():
    import coreiq
    from coreiq.testing import MockCoreIQ, assert_event_logged

    with MockCoreIQ() as mock:
        coreiq.log_event("signup", {"plan": "basic"})
        with pytest.raises(AssertionError):
            assert_event_logged(mock, "signup", plan="pro")  # wrong plan


def test_assert_event_logged_no_kwargs():
    import coreiq
    from coreiq.testing import MockCoreIQ, assert_event_logged

    with MockCoreIQ() as mock:
        coreiq.log_event("ping")
        assert_event_logged(mock, "ping")  # no metadata check


def test_mock_multiple_events():
    import coreiq
    from coreiq.testing import MockCoreIQ, assert_event_logged

    with MockCoreIQ() as mock:
        coreiq.log_event("step1")
        coreiq.log_event("step2", level="warning")
        coreiq.log_event("step3")
        assert len(mock.events) == 3
        assert_event_logged(mock, "step2")
