"""Tests for deferred tool loading, semantic search, evolution-aware ranking,
budget-aware selection, and the tool catalog API endpoints."""
import pytest
from fastapi.testclient import TestClient

from coreiq.tools.registry import ToolRegistry, ToolSpec
from coreiq.tools.router import ToolRouter
from coreiq.tools.catalog import ToolSearchResult


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _reset_writer(tmp_path, monkeypatch):
    """Isolate DB and reset singletons for every test."""
    monkeypatch.setenv("COREIQ_DB_PATH", str(tmp_path / "test.db"))
    monkeypatch.setenv("COREIQ_AUTH_MODE", "disabled")
    import coreiq.store.writer as w
    import coreiq.store.db as d
    w._writer = None
    d._shared_conn = None
    d._shared_conn_path = None
    yield
    w._writer = None
    d._shared_conn = None
    d._shared_conn_path = None


@pytest.fixture(autouse=True)
def _reset_tool_catalog():
    """Reset the server-side tool catalog singletons between tests."""
    import coreiq.server.routers.tools as t
    from coreiq.tools.registry import ToolRegistry
    from coreiq.tools.router import ToolRouter
    t._registry = ToolRegistry()
    t._router = ToolRouter(t._registry)
    yield
    t._registry = ToolRegistry()
    t._router = ToolRouter(t._registry)


@pytest.fixture
def client():
    from coreiq.server.app import app
    with TestClient(app) as c:
        yield c


EAGER_TOOLS = [
    {"name": "send_email", "description": "Send an email to a recipient"},
    {"name": "read_file", "description": "Read a local file from disk"},
]

DEFERRED_TOOLS = [
    {"name": "search_web", "description": "Search the internet for web pages and results"},
    {"name": "run_sql", "description": "Execute a SQL query against the database"},
    {"name": "translate_text", "description": "Translate text between languages"},
]


# ── Group A: ToolSpec and ToolRegistry ────────────────────────────────────────

def test_toolspec_defer_loading_default_false():
    spec = ToolSpec(name="x", description="desc")
    assert spec.defer_loading is False


def test_registry_register_defer_loading_false_by_default():
    reg = ToolRegistry()
    reg.register([{"name": "tool_a", "description": "does something"}])
    assert reg.get("tool_a").defer_loading is False


def test_registry_register_defer_loading_true_batch():
    reg = ToolRegistry()
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    for t in DEFERRED_TOOLS:
        assert reg.get(t["name"]).defer_loading is True


def test_registry_register_per_tool_override_wins():
    """Per-tool dict key overrides the batch defer_loading flag."""
    reg = ToolRegistry()
    tools = [
        {"name": "eager_one", "description": "always loaded", "defer_loading": False},
        {"name": "deferred_one", "description": "loaded on demand"},
    ]
    reg.register(tools, defer_loading=True)
    assert reg.get("eager_one").defer_loading is False
    assert reg.get("deferred_one").defer_loading is True


def test_registry_get_eager_excludes_deferred():
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS, defer_loading=False)
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    eager = reg.get_eager()
    eager_names = {s.name for s in eager}
    assert eager_names == {"send_email", "read_file"}
    for s in eager:
        assert s.defer_loading is False


def test_registry_get_deferred_excludes_eager():
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS, defer_loading=False)
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    deferred = reg.get_deferred()
    deferred_names = {s.name for s in deferred}
    assert deferred_names == {"search_web", "run_sql", "translate_text"}
    for s in deferred:
        assert s.defer_loading is True


def test_registry_remove_existing():
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS)
    removed = reg.remove("send_email")
    assert removed is True
    assert reg.get("send_email") is None
    assert len(reg) == 1


def test_registry_remove_nonexistent_returns_false():
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS)
    assert reg.remove("does_not_exist") is False


def test_registry_remove_increments_version():
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS)
    v_before = reg.version
    reg.remove("send_email")
    assert reg.version > v_before


def test_registry_version_increments_on_deferred_register():
    reg = ToolRegistry()
    v0 = reg.version
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    assert reg.version > v0


def test_registry_backward_compat_no_defer_arg():
    """register() called without defer_loading works as before."""
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS)
    assert len(reg) == 2
    assert reg.get("send_email") is not None


# ── Group B: ToolRouter ───────────────────────────────────────────────────────

def test_router_select_deferred_returns_only_deferred():
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS, defer_loading=False)
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    router = ToolRouter(reg)
    results = router.select_deferred("search web", top_k=5)
    names = {spec.name for spec, _ in results}
    assert names <= {"search_web", "run_sql", "translate_text"}
    assert "send_email" not in names
    assert "read_file" not in names


def test_router_select_deferred_returns_scores():
    reg = ToolRegistry()
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    router = ToolRouter(reg)
    results = router.select_deferred("database query", top_k=3)
    for spec, score in results:
        assert isinstance(spec, ToolSpec)
        assert 0.0 <= score <= 1.0


def test_router_select_deferred_respects_top_k():
    reg = ToolRegistry()
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    router = ToolRouter(reg)
    results = router.select_deferred("any query", top_k=2)
    assert len(results) <= 2


def test_router_select_deferred_empty_when_no_deferred():
    reg = ToolRegistry()
    reg.register(EAGER_TOOLS, defer_loading=False)
    router = ToolRouter(reg)
    results = router.select_deferred("anything")
    assert results == []


def test_router_update_win_rate_affects_ranking():
    """A tool with a high win-rate should rank above an equally-similar tool."""
    reg = ToolRegistry()
    reg.register([
        {"name": "tool_a", "description": "search the web for information online"},
        {"name": "tool_b", "description": "search web pages for online information"},
    ], defer_loading=True)
    router = ToolRouter(reg)
    # Give tool_a a high win-rate
    router.update_win_rate("tool_a", 0.95)
    router.update_win_rate("tool_b", 0.05)
    results = router.select_deferred("search web", top_k=2)
    assert len(results) == 2
    top_name = results[0][0].name
    assert top_name == "tool_a"


def test_router_win_rate_defaults_gracefully_to_zero():
    """No win-rate data → pure semantic ranking, no error."""
    reg = ToolRegistry()
    reg.register(DEFERRED_TOOLS, defer_loading=True)
    router = ToolRouter(reg)
    results = router.select_deferred("translate language", top_k=3)
    assert len(results) > 0


def test_router_select_within_budget_respects_limit():
    reg = ToolRegistry()
    reg.register(DEFERRED_TOOLS + EAGER_TOOLS)
    router = ToolRouter(reg)
    # Budget for exactly 1 tool at 200 tokens each
    results = router.select_within_budget("any query", token_budget=200, tokens_per_tool=200)
    assert len(results) == 1


def test_router_select_within_budget_returns_empty_when_zero():
    reg = ToolRegistry()
    reg.register(DEFERRED_TOOLS)
    router = ToolRouter(reg)
    results = router.select_within_budget("any query", token_budget=0)
    assert results == []


def test_router_select_within_budget_fills_multiple():
    reg = ToolRegistry()
    reg.register(DEFERRED_TOOLS)  # 3 tools
    router = ToolRouter(reg)
    results = router.select_within_budget("any query", token_budget=500, tokens_per_tool=200)
    assert len(results) == 2  # 2 * 200 = 400 ≤ 500; 3 * 200 = 600 > 500


# ── Group C: ToolSearchResult ─────────────────────────────────────────────────

def test_tool_search_result_default_construction():
    r = ToolSearchResult()
    assert r.tool_refs == []
    assert r.similarity_scores == []
    assert r.query == ""
    assert r.top_k == 5
    assert r.tokens_saved == 0


def test_tool_search_result_fields():
    r = ToolSearchResult(
        tool_refs=["search_web", "run_sql"],
        similarity_scores=[0.92, 0.71],
        query="database search",
        top_k=3,
        tokens_saved=200,
    )
    assert r.tool_refs == ["search_web", "run_sql"]
    assert r.similarity_scores == [0.92, 0.71]
    assert r.tokens_saved == 200


def test_tool_search_result_parallel_lists():
    r = ToolSearchResult(
        tool_refs=["a", "b", "c"],
        similarity_scores=[0.9, 0.8, 0.7],
    )
    assert len(r.tool_refs) == len(r.similarity_scores)


# ── Group D: _ToolsInterface / CoreIQClient ───────────────────────────────────

def _make_client():
    from coreiq.client import CoreIQClient
    return CoreIQClient()


def test_client_tools_register_with_defer_loading():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    assert len(client.tools) == 3


def test_client_tools_register_backward_compat():
    """Positional call without defer_loading still works."""
    client = _make_client()
    client.tools.register(EAGER_TOOLS)
    assert len(client.tools) == 2


def test_client_tools_search_returns_tool_search_result():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    result = client.tools.search("database query")
    assert isinstance(result, ToolSearchResult)
    assert isinstance(result.tool_refs, list)
    assert isinstance(result.similarity_scores, list)
    assert len(result.tool_refs) == len(result.similarity_scores)


def test_client_tools_search_finds_relevant_tool():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    result = client.tools.search("run SQL query on database", top_k=2)
    # run_sql should be in results for a database query
    assert "run_sql" in result.tool_refs


def test_client_tools_search_empty_when_no_deferred():
    client = _make_client()
    client.tools.register(EAGER_TOOLS, defer_loading=False)
    result = client.tools.search("anything", top_k=3)
    assert result.tool_refs == []
    assert result.similarity_scores == []


def test_client_tools_resolve_names():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    specs = client.tools.resolve(["search_web", "run_sql"])
    assert len(specs) == 2
    names = {s.name for s in specs}
    assert names == {"search_web", "run_sql"}


def test_client_tools_resolve_missing_silently_skipped():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    specs = client.tools.resolve(["search_web", "nonexistent_tool"])
    assert len(specs) == 1
    assert specs[0].name == "search_web"


def test_client_tools_resolve_all_missing_returns_empty():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    specs = client.tools.resolve(["ghost_a", "ghost_b"])
    assert specs == []


def test_client_tools_context_budget():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS + EAGER_TOOLS)
    selected = client.tools.resolve(["search_web"])
    savings = client.tools.context_budget(selected, tokens_per_tool=200)
    # 5 total - 1 selected = 4 * 200 = 800
    assert savings == 800


def test_client_tools_record_usage_without_evolution_no_error():
    """record_usage with evolution=None (not yet accessed) must not raise."""
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    # _evolution is None at this point (client.evolution not accessed)
    client.tools.record_usage("search_web", 1.0)  # should not raise


def test_client_tools_record_usage_invalid_outcome_raises():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS, defer_loading=True)
    with pytest.raises(ValueError, match="0.0"):
        client.tools.record_usage("search_web", 1.5)


def test_client_tools_select_within_budget():
    client = _make_client()
    client.tools.register(DEFERRED_TOOLS + EAGER_TOOLS)
    results = client.tools.select_within_budget("any query", token_budget=400)
    assert len(results) <= 2  # 2 * 200 = 400


# ── Group E: API routes ───────────────────────────────────────────────────────

def test_api_tools_list_empty(client):
    r = client.get("/api/tools")
    assert r.status_code == 200
    assert r.json() == []


def test_api_tools_register_and_list(client):
    payload = {"tools": EAGER_TOOLS, "defer_loading": False}
    r = client.post("/api/tools/register", json=payload)
    assert r.status_code == 200
    data = r.json()
    assert data["registered"] == 2
    assert data["total"] == 2

    r2 = client.get("/api/tools")
    assert r2.status_code == 200
    names = {t["name"] for t in r2.json()}
    assert names == {"send_email", "read_file"}


def test_api_tools_register_defer_loading_reflected(client):
    payload = {"tools": DEFERRED_TOOLS, "defer_loading": True}
    client.post("/api/tools/register", json=payload)
    r = client.get("/api/tools")
    for tool in r.json():
        assert tool["defer_loading"] is True


def test_api_tools_list_include_deferred_false(client):
    client.post("/api/tools/register", json={"tools": EAGER_TOOLS, "defer_loading": False})
    client.post("/api/tools/register", json={"tools": DEFERRED_TOOLS, "defer_loading": True})
    r = client.get("/api/tools?include_deferred=false")
    assert r.status_code == 200
    names = {t["name"] for t in r.json()}
    assert names == {"send_email", "read_file"}
    assert "search_web" not in names


def test_api_tools_register_missing_name_422(client):
    payload = {"tools": [{"description": "no name here"}]}
    r = client.post("/api/tools/register", json=payload)
    assert r.status_code == 422


def test_api_tools_search_empty_catalog(client):
    r = client.post("/api/tools/search", json={"query": "anything", "top_k": 3})
    assert r.status_code == 200
    data = r.json()
    assert data["results"] == []
    assert data["catalog_size"] == 0


def test_api_tools_search_returns_results(client):
    client.post("/api/tools/register", json={"tools": DEFERRED_TOOLS, "defer_loading": True})
    r = client.post("/api/tools/search", json={"query": "SQL database query", "top_k": 3})
    assert r.status_code == 200
    data = r.json()
    assert len(data["results"]) > 0
    assert data["catalog_size"] == 3
    # run_sql should be in results
    names = [t["name"] for t in data["results"]]
    assert "run_sql" in names


def test_api_tools_search_respects_top_k(client):
    # Register 5 tools, ask for top_k=2
    tools = DEFERRED_TOOLS + EAGER_TOOLS
    client.post("/api/tools/register", json={"tools": tools, "defer_loading": True})
    r = client.post("/api/tools/search", json={"query": "anything", "top_k": 2})
    assert r.status_code == 200
    assert len(r.json()["results"]) <= 2


def test_api_tools_search_returns_similarity_scores(client):
    client.post("/api/tools/register", json={"tools": DEFERRED_TOOLS, "defer_loading": True})
    r = client.post("/api/tools/search", json={"query": "translate language", "top_k": 3})
    for tool in r.json()["results"]:
        assert "similarity_score" in tool
        assert tool["similarity_score"] is not None


def test_api_tools_search_include_deferred_false(client):
    """include_deferred=false searches all tools, not just deferred ones."""
    client.post("/api/tools/register", json={"tools": EAGER_TOOLS, "defer_loading": False})
    r = client.post("/api/tools/search", json={"query": "email", "top_k": 3, "include_deferred": False})
    assert r.status_code == 200
    # send_email should appear
    names = [t["name"] for t in r.json()["results"]]
    assert "send_email" in names


def test_api_tools_delete_existing(client):
    client.post("/api/tools/register", json={"tools": EAGER_TOOLS})
    r = client.delete("/api/tools/send_email")
    assert r.status_code == 204

    # Confirm removal
    r2 = client.get("/api/tools")
    names = {t["name"] for t in r2.json()}
    assert "send_email" not in names


def test_api_tools_delete_nonexistent(client):
    r = client.delete("/api/tools/ghost_tool")
    assert r.status_code == 404
