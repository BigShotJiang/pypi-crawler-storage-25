"""Backend parity regression tests.

Guards the "one backend owns everything" invariant: whichever backend is
configured via ``COREIQ_STORE_BACKEND`` must service every ``EventWriter``
write end-to-end and round-trip through ``fetchall`` / ``fetchone``.

Each backend is parameterised and skipped if its driver or test DSN isn't
available:

- ``sqlite``      — always runs (stdlib).
- ``postgres``    — skipped unless ``psycopg2`` is installed **and**
  ``COREIQ_TEST_POSTGRES_DSN`` is set.
- ``mongodb``     — skipped unless ``pymongo`` is installed **and**
  ``COREIQ_TEST_MONGODB_URI`` is set.
- ``clickhouse``  — skipped unless ``clickhouse_connect`` is installed
  **and** ``COREIQ_TEST_CLICKHOUSE_DSN`` is set.

To run the full matrix locally::

    docker run -d -p 8123:8123 --name ch clickhouse/clickhouse-server
    export COREIQ_TEST_CLICKHOUSE_DSN=http://default:@localhost:8123
    pytest tests/test_backend_parity.py -v
"""
from __future__ import annotations

import importlib.util
import os
import uuid

import pytest


# ---------------------------------------------------------------------------
# Availability helpers
# ---------------------------------------------------------------------------

def _have(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


_BACKENDS = [
    pytest.param(
        "postgres",
        {
            "COREIQ_STORE_BACKEND": "postgres",
            "COREIQ_POSTGRES_DSN": os.environ.get("COREIQ_TEST_POSTGRES_DSN", ""),
        },
        id="postgres",
        marks=pytest.mark.skipif(
            not (_have("psycopg2") and os.environ.get("COREIQ_TEST_POSTGRES_DSN")),
            reason="psycopg2 or COREIQ_TEST_POSTGRES_DSN missing",
        ),
    ),
    pytest.param(
        "mongodb",
        {
            "COREIQ_STORE_BACKEND": "mongodb",
            "COREIQ_MONGODB_URI": os.environ.get("COREIQ_TEST_MONGODB_URI", ""),
            "COREIQ_MONGODB_DATABASE": f"coreiq_test_{uuid.uuid4().hex[:8]}",
        },
        id="mongodb",
        marks=pytest.mark.skipif(
            not (_have("pymongo") and os.environ.get("COREIQ_TEST_MONGODB_URI")),
            reason="pymongo or COREIQ_TEST_MONGODB_URI missing",
        ),
    ),
    pytest.param(
        "clickhouse",
        {
            "COREIQ_STORE_BACKEND": "clickhouse",
            "COREIQ_CLICKHOUSE_DSN": os.environ.get("COREIQ_TEST_CLICKHOUSE_DSN", ""),
            "COREIQ_CLICKHOUSE_DATABASE": f"coreiq_test_{uuid.uuid4().hex[:8]}",
        },
        id="clickhouse",
        marks=pytest.mark.skipif(
            not (_have("clickhouse_connect") and os.environ.get("COREIQ_TEST_CLICKHOUSE_DSN")),
            reason="clickhouse_connect or COREIQ_TEST_CLICKHOUSE_DSN missing",
        ),
    ),
]


def _reset_backend(monkeypatch, tmp_path, backend_name: str, env: dict):
    """Apply env vars, reset thread-local connections, return a fresh handle."""
    # Per-test SQLite path so tests don't cross-contaminate.
    db_path = tmp_path / f"parity_{backend_name}.db"
    monkeypatch.setenv("COREIQ_DB_PATH", str(db_path))
    # The session-level conftest may have set COREIQ_STORE_BACKEND=mongodb so
    # the rest of the suite gets a consistent default. For the sqlite leg of
    # this parity matrix we must explicitly clear it (and the per-backend env
    # below sets it back for postgres/mongodb/clickhouse).
    if backend_name == "sqlite":
        monkeypatch.delenv("COREIQ_STORE_BACKEND", raising=False)
    for k, v in env.items():
        monkeypatch.setenv(k, v)

    import coreiq.store.db as db_mod
    for attr in ("conn", "conn_path", "_mongodb_conn", "_postgres_conn", "_clickhouse_conn"):
        existing = getattr(db_mod._thread_local, attr, None)
        if existing is not None and hasattr(existing, "close"):
            try:
                existing.close()
            except Exception:
                pass
        setattr(db_mod._thread_local, attr, None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("backend_name,env", _BACKENDS)
def test_backend_type_matches_config(backend_name, env, tmp_path, monkeypatch):
    _reset_backend(monkeypatch, tmp_path, backend_name, env)
    from coreiq.store.db import get_shared_connection
    conn = get_shared_connection()
    assert conn.backend_type == backend_name


@pytest.mark.parametrize("backend_name,env", _BACKENDS)
def test_init_schema_runs(backend_name, env, tmp_path, monkeypatch):
    _reset_backend(monkeypatch, tmp_path, backend_name, env)
    from coreiq.store.db import get_shared_connection, init_schema
    conn = get_shared_connection()
    init_schema(conn)
    # No assertion — just that it doesn't raise.


@pytest.mark.parametrize("backend_name,env", _BACKENDS)
def test_event_writer_trace_roundtrip(backend_name, env, tmp_path, monkeypatch):
    """EventWriter.insert_trace → fetchone must round-trip across backends."""
    _reset_backend(monkeypatch, tmp_path, backend_name, env)
    if backend_name == "mongodb":
        pytest.skip("MongoDB uses a different read model; covered by its own suite")

    from coreiq.store.writer import EventWriter
    from coreiq.store.db import get_shared_connection, init_schema

    conn = get_shared_connection()
    init_schema(conn)

    writer = EventWriter()
    trace_id = str(uuid.uuid4())
    writer.insert_trace(
        id=trace_id,
        model="gpt-4",
        provider="openai",
        input_tok=10,
        output_tok=20,
        latency_ms=100,
        finish_reason="stop",
    )
    writer.flush()

    row = conn.fetchone("SELECT id, model, provider FROM traces WHERE id = ?", (trace_id,))
    assert row is not None
    assert row["id"] == trace_id
    assert row["model"] == "gpt-4"
    assert row["provider"] == "openai"


@pytest.mark.parametrize("backend_name,env", _BACKENDS)
def test_insert_or_replace_idempotent(backend_name, env, tmp_path, monkeypatch):
    """Re-inserting the same trace ID should not explode on any backend."""
    _reset_backend(monkeypatch, tmp_path, backend_name, env)
    if backend_name == "mongodb":
        pytest.skip("MongoDB handles upsert via its own translator")

    from coreiq.store.writer import EventWriter
    from coreiq.store.db import get_shared_connection, init_schema

    conn = get_shared_connection()
    init_schema(conn)

    writer = EventWriter()
    trace_id = str(uuid.uuid4())
    for i in range(3):
        writer.insert_trace(
            id=trace_id,
            model="gpt-4",
            provider="openai",
            input_tok=10 + i,
            output_tok=20,
            latency_ms=100,
            finish_reason="stop",
        )
    writer.flush()

    rows = conn.fetchall("SELECT id FROM traces WHERE id = ?", (trace_id,))
    # SQLite: 1 row (REPLACE); Postgres: 1 (ON CONFLICT DO UPDATE);
    # ClickHouse: 1 after FINAL. Existence is the invariant.
    assert len(rows) >= 1
