"""Tests for Agent Governance — tool policies, budgets, delegation, loop detection."""
import pytest
from coreiq.governance.agent_policies import (
    AgentPolicyEngine, AgentPolicyViolation,
)


@pytest.fixture
def engine():
    return AgentPolicyEngine()


# ── Tool Policies ────────────────────────────────────────────────────────────

class TestToolPolicies:
    def test_allow_unlisted_tool(self, engine):
        engine.set_tool_policy("bot", blocked_tools=["shell_exec"])
        s = engine.start_session("bot")
        result = engine.check_tool_call(s.session_id, "web_search")
        assert result["allowed"]

    def test_block_tool(self, engine):
        engine.set_tool_policy("bot", blocked_tools=["shell_exec"])
        s = engine.start_session("bot")
        with pytest.raises(AgentPolicyViolation, match="blocked"):
            engine.check_tool_call(s.session_id, "shell_exec")

    def test_require_approval(self, engine):
        engine.set_tool_policy("bot", require_approval_for=["send_email"])
        s = engine.start_session("bot")
        result = engine.check_tool_call(s.session_id, "send_email")
        assert result["requires_approval"]

    def test_max_calls_exceeded(self, engine):
        engine.set_tool_policy("bot", max_calls_per_session=3)
        s = engine.start_session("bot")
        for _ in range(3):
            engine.check_tool_call(s.session_id, "search")
        with pytest.raises(AgentPolicyViolation, match="Max tool calls"):
            engine.check_tool_call(s.session_id, "search")

    def test_allowlist(self, engine):
        engine.set_tool_policy("bot", allowed_tools=["search", "read"])
        s = engine.start_session("bot")
        engine.check_tool_call(s.session_id, "search")
        with pytest.raises(AgentPolicyViolation, match="not in the allowed"):
            engine.check_tool_call(s.session_id, "write")

    def test_no_policy_allows_all(self, engine):
        s = engine.start_session("bot")
        result = engine.check_tool_call(s.session_id, "anything")
        assert result["allowed"]


# ── Budgets ──────────────────────────────────────────────────────────────────

class TestBudgets:
    def test_within_budget(self, engine):
        engine.set_agent_budget("bot", max_cost_per_session=2.00)
        s = engine.start_session("bot")
        result = engine.check_budget(s.session_id, cost_delta=0.50)
        assert result["within_budget"]

    def test_session_budget_exceeded(self, engine):
        engine.set_agent_budget("bot", max_cost_per_session=1.00)
        s = engine.start_session("bot")
        engine.check_budget(s.session_id, cost_delta=0.80)
        with pytest.raises(AgentPolicyViolation, match="Session cost"):
            engine.check_budget(s.session_id, cost_delta=0.30)

    def test_token_budget_exceeded(self, engine):
        engine.set_agent_budget("bot", max_tokens_per_session=1000)
        s = engine.start_session("bot")
        with pytest.raises(AgentPolicyViolation, match="Session tokens"):
            engine.check_budget(s.session_id, tokens_delta=1500)

    def test_budget_alert(self, engine):
        engine.set_agent_budget("bot", max_cost_per_session=1.00, alert_at=0.8)
        s = engine.start_session("bot")
        result = engine.check_budget(s.session_id, cost_delta=0.85)
        assert len(result["alerts"]) > 0

    def test_daily_budget_exceeded(self, engine):
        engine.set_agent_budget("bot", max_cost_per_day=1.00, max_cost_per_session=10.00)
        s = engine.start_session("bot")
        engine.check_budget(s.session_id, cost_delta=0.80)
        s2 = engine.start_session("bot")
        with pytest.raises(AgentPolicyViolation, match="Daily cost"):
            engine.check_budget(s2.session_id, cost_delta=0.30)


# ── Delegation ───────────────────────────────────────────────────────────────

class TestDelegation:
    def test_allowed_delegation(self, engine):
        engine.set_delegation_policy("bot", can_delegate_to=["helper-bot"])
        s = engine.start_session("bot")
        result = engine.check_delegation(s.session_id, "helper-bot")
        assert result["allowed"]

    def test_blocked_delegation(self, engine):
        engine.set_delegation_policy("bot", can_delegate_to=["helper-bot"])
        s = engine.start_session("bot")
        with pytest.raises(AgentPolicyViolation, match="not allowed to delegate"):
            engine.check_delegation(s.session_id, "evil-bot")

    def test_depth_limit(self, engine):
        engine.set_delegation_policy("bot", max_delegation_depth=2, can_delegate_to=["helper"])
        s = engine.start_session("bot", delegation_depth=2)
        with pytest.raises(AgentPolicyViolation, match="Max delegation depth"):
            engine.check_delegation(s.session_id, "helper")

    def test_approval_after_depth(self, engine):
        engine.set_delegation_policy("bot",
            can_delegate_to=["helper"],
            max_delegation_depth=5,
            require_human_approval_after_depth=2)
        s = engine.start_session("bot", delegation_depth=2)
        result = engine.check_delegation(s.session_id, "helper")
        assert result["requires_approval"]


# ── Loop Detection ───────────────────────────────────────────────────────────

class TestLoopDetection:
    def test_within_limit(self, engine):
        engine.set_loop_policy("bot", max_iterations=10)
        s = engine.start_session("bot")
        for _ in range(10):
            result = engine.check_loop(s.session_id)
            assert result["safe"]

    def test_iteration_exceeded(self, engine):
        engine.set_loop_policy("bot", max_iterations=5)
        s = engine.start_session("bot")
        for _ in range(5):
            engine.check_loop(s.session_id)
        with pytest.raises(AgentPolicyViolation, match="Max iterations"):
            engine.check_loop(s.session_id)

    def test_cost_circuit_breaker(self, engine):
        engine.set_loop_policy("bot", cost_circuit_breaker=1.00, max_iterations=999)
        engine.set_agent_budget("bot", max_cost_per_session=10.00)
        s = engine.start_session("bot")
        engine.check_budget(s.session_id, cost_delta=1.50)
        with pytest.raises(AgentPolicyViolation, match="Cost circuit breaker"):
            engine.check_loop(s.session_id)


# ── Reasoning Trace ──────────────────────────────────────────────────────────

class TestReasoningTrace:
    def test_log_reasoning(self, engine):
        engine.require_reasoning_trace("bot")
        s = engine.start_session("bot")
        assert s.require_reasoning_trace
        engine.log_reasoning(s.session_id, "step1", "Analyzing user query")
        engine.log_reasoning(s.session_id, "step2", "Selecting tool: search")
        assert len(s.reasoning_trace) == 2

    def test_session_summary(self, engine):
        s = engine.start_session("bot")
        d = s.to_dict()
        assert "session_id" in d
        assert "agent_id" in d
        assert d["agent_id"] == "bot"


# ── Session Management ───────────────────────────────────────────────────────

class TestSessions:
    def test_start_and_end(self, engine):
        s = engine.start_session("bot")
        assert engine.get_session(s.session_id) is not None
        ended = engine.end_session(s.session_id)
        assert ended is not None
        assert engine.get_session(s.session_id) is None

    def test_list_sessions(self, engine):
        engine.start_session("bot1")
        engine.start_session("bot2")
        sessions = engine.list_sessions()
        assert len(sessions) == 2

    def test_get_policies(self, engine):
        engine.set_tool_policy("bot", blocked_tools=["x"])
        engine.set_agent_budget("bot", max_cost_per_session=1.0)
        policies = engine.get_policies("bot")
        assert policies["agent_id"] == "bot"
        assert "x" in policies["tool_policy"]["blocked_tools"]
