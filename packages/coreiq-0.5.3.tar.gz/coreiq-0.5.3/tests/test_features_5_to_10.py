"""Integration tests for Features 5-10."""
import os
import pytest

DEFAULT_MODEL = os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")


# ── Feature 5: Cost Optimizer ────────────────────────────────────────────────

class TestCostOptimizer:
    def test_record_and_report(self):
        from coreiq.performance.cost_optimizer import CostOptimizer
        opt = CostOptimizer()
        # Simulate traffic: 60% simple on gpt-4o, 40% complex
        for _ in range(6):
            opt.record_request("gpt-4o", 500, 0.015, "simple")
        for _ in range(4):
            opt.record_request("gpt-4o", 1500, 0.045, "complex")
        # Add some cache-eligible
        opt.record_request("gpt-4o", 300, 0.009, "simple", cache_eligible=True)
        opt.record_request("gpt-4o", 300, 0.009, "simple", cache_eligible=True)

        report = opt.generate_report()
        assert report.total_requests == 12
        assert report.total_cost > 0
        assert len(report.findings) > 0
        # Should find model downgrade opportunity
        downgrade = next((f for f in report.findings if f.finding_type == "model_downgrade"), None)
        assert downgrade is not None
        assert downgrade.recommended_model == "gpt-4o-mini"
        # Should find cache opportunity
        cache = next((f for f in report.findings if f.finding_type == "cache_eligible"), None)
        assert cache is not None

    def test_empty_report(self):
        from coreiq.performance.cost_optimizer import CostOptimizer
        opt = CostOptimizer()
        report = opt.generate_report()
        assert report.total_requests == 0
        assert len(report.findings) == 0


# ── Feature 6: Semantic Regression Testing ───────────────────────────────────

class TestSemanticRegression:
    def test_no_regression(self):
        from coreiq.evolution.regression import RegressionTester
        t = RegressionTester()
        t.add_baseline("v1", "hello", "Hi there!", {"tone": 0.9, "relevance": 0.85})
        t.add_baseline("v1", "bye", "Goodbye!", {"tone": 0.88, "relevance": 0.90})
        result = t.compare_versions("v1", "v2",
            new_scores={"tone": [0.92, 0.90], "relevance": [0.87, 0.91]})
        assert not result.regression_detected
        assert "Safe to deploy" in result.recommendation or "No significant" in result.recommendation

    def test_regression_detected(self):
        from coreiq.evolution.regression import RegressionTester
        t = RegressionTester()
        t.add_baseline("v1", "hello", "Hi!", {"tone": 0.9})
        t.add_baseline("v1", "world", "World!", {"tone": 0.85})
        result = t.compare_versions("v1", "v2", new_scores={"tone": [0.5, 0.6]})
        assert result.regression_detected
        assert "tone" in result.degraded_dimensions
        assert "Block deploy" in result.recommendation

    def test_missing_baseline(self):
        from coreiq.evolution.regression import RegressionTester
        t = RegressionTester()
        result = t.compare_versions("v1", "v2")
        assert not result.regression_detected
        assert "No baseline" in result.recommendation


# ── Feature 7: DLP ──────────────────────────────────────────────────────────

class TestDLP:
    def test_clean_text(self):
        from coreiq.security.dlp import DLPEngine
        dlp = DLPEngine()
        result = dlp.scan("What is the weather today?")
        assert result.clean

    def test_detects_financial_data(self):
        from coreiq.security.dlp import DLPEngine
        dlp = DLPEngine()
        result = dlp.scan("Q3 revenue is $42M and earnings exceeded expectations")
        assert not result.clean
        assert any(f.category == "financial" for f in result.findings)

    def test_detects_aws_key(self):
        from coreiq.security.dlp import DLPEngine
        dlp = DLPEngine()
        result = dlp.scan("Use AWS key AKIAIOSFODNN7EXAMPLE to access S3")
        assert not result.clean
        assert result.action == "block"

    def test_detects_private_key(self):
        from coreiq.security.dlp import DLPEngine
        dlp = DLPEngine()
        result = dlp.scan("-----BEGIN PRIVATE KEY-----\nMIIEvg...")
        assert not result.clean

    def test_detects_database_url(self):
        from coreiq.security.dlp import DLPEngine
        dlp = DLPEngine()
        result = dlp.scan("Connect to postgres://admin:s3cret@db.internal:5432/prod")
        assert not result.clean
        assert result.action == "block"

    def test_detects_ssn(self):
        from coreiq.security.dlp import DLPEngine
        dlp = DLPEngine()
        result = dlp.scan("Employee SSN: 123-45-6789")
        assert not result.clean

    def test_scan_messages(self):
        from coreiq.security.dlp import DLPEngine
        dlp = DLPEngine()
        result = dlp.scan_messages([
            {"role": "user", "content": "Here is my AWS key: AKIAIOSFODNN7EXAMPLE"},
        ])
        assert not result.clean


# ── Feature 8: Canary Deployments ────────────────────────────────────────────

class TestCanaryDeploy:
    def setup_method(self):
        from coreiq.store.db import get_shared_connection
        from coreiq.store.db import init_schema
        init_schema(get_shared_connection())

    def test_create_and_route(self):
        from coreiq.proxy.canary_deploy import CanaryDeploymentEngine
        engine = CanaryDeploymentEngine()
        dep = engine.create(DEFAULT_MODEL, "claude-sonnet-4-6", traffic_pct=50)
        # With 50% traffic and many users, should see both models
        models = set()
        for i in range(100):
            m = engine.route(dep.id, f"user-{i}")
            models.add(m)
        assert DEFAULT_MODEL in models
        assert "claude-sonnet-4-6" in models

    def test_auto_promote(self):
        from coreiq.proxy.canary_deploy import CanaryDeploymentEngine
        engine = CanaryDeploymentEngine()
        dep = engine.create(DEFAULT_MODEL, "claude-sonnet-4-6",
            promote_threshold={"quality": 0.9}, rollback_threshold={"quality": 0.5})
        for _ in range(15):
            engine.record_score(dep.id, "claude-sonnet-4-6", "quality", 0.95)
        result = engine.evaluate(dep.id)
        assert result["action"] == "promoted"

    def test_auto_rollback(self):
        from coreiq.proxy.canary_deploy import CanaryDeploymentEngine
        engine = CanaryDeploymentEngine()
        dep = engine.create(DEFAULT_MODEL, "claude-sonnet-4-6",
            rollback_threshold={"quality": 0.8})
        for _ in range(15):
            engine.record_score(dep.id, "claude-sonnet-4-6", "quality", 0.6)
        result = engine.evaluate(dep.id)
        assert result["action"] == "rolled_back"


# ── Feature 9: Red Team ─────────────────────────────────────────────────────

class TestRedTeam:
    def test_attack_library(self):
        from coreiq.security.red_team import RedTeamEngine
        rt = RedTeamEngine()
        lib = rt.get_attack_library()
        assert len(lib) >= 15  # at least 15 attacks

    def test_run_scan_with_firewall(self):
        from coreiq.security.red_team import RedTeamEngine
        from coreiq.security.firewall import AIFirewall
        rt = RedTeamEngine()
        fw = AIFirewall()
        def scan_fn(prompt):
            v = fw.scan(prompt)
            return {"blocked": v.blocked, "response": v.details or "allowed"}
        report = rt.run_scan(scan_fn, intensity="quick")
        assert report.total_attacks == 5
        assert report.attacks_blocked > 0

    def test_category_filter(self):
        from coreiq.security.red_team import RedTeamEngine
        rt = RedTeamEngine()
        def always_block(prompt):
            return {"blocked": True, "response": "blocked"}
        report = rt.run_scan(always_block, categories=["injection"])
        assert all(r.category == "injection" for r in report.successful_attacks + [])
        for cat in report.results_by_category:
            assert cat == "injection"


# ── Feature 10: Replay & Debug ──────────────────────────────────────────────

class TestReplay:
    def test_record_and_get(self):
        from coreiq.observability.replay import ReplayEngine
        engine = ReplayEngine()
        engine.record("trace-1", [{"role": "user", "content": "Hello"}],
                       DEFAULT_MODEL, "Hi there!", tokens=50, cost=0.001)
        rec = engine.get("trace-1")
        assert rec is not None
        assert rec.model == DEFAULT_MODEL
        assert rec.response == "Hi there!"

    def test_list_recent(self):
        from coreiq.observability.replay import ReplayEngine
        engine = ReplayEngine()
        for i in range(5):
            engine.record(f"trace-{i}", [{"role": "user", "content": f"msg-{i}"}],
                          DEFAULT_MODEL, f"response-{i}")
        recent = engine.list_recent(3)
        assert len(recent) == 3

    def test_dry_run_replay(self):
        from coreiq.observability.replay import ReplayEngine
        engine = ReplayEngine()
        engine.record("trace-1", [{"role": "user", "content": "Hello"}],
                       DEFAULT_MODEL, "Hi there!", cost=0.015)
        result = engine.replay("trace-1", model="claude-sonnet-4-6")
        assert result.original_model == DEFAULT_MODEL
        assert result.replay_model == "claude-sonnet-4-6"
        assert "dry-run" in result.replay_response

    def test_replay_with_fn(self):
        from coreiq.observability.replay import ReplayEngine
        engine = ReplayEngine()
        engine.record("trace-1", [{"role": "user", "content": "Hello"}],
                       DEFAULT_MODEL, "Hi!", cost=0.015)
        def mock_llm(messages, model):
            return {"response": f"Response from {model}", "cost": 0.001}
        result = engine.replay("trace-1", replay_fn=mock_llm, model="claude-sonnet-4-6")
        assert "claude-sonnet-4-6" in result.replay_response
        assert result.replay_cost == 0.001

    def test_not_found(self):
        from coreiq.observability.replay import ReplayEngine
        engine = ReplayEngine()
        with pytest.raises(ValueError, match="not found"):
            engine.replay("nonexistent")
