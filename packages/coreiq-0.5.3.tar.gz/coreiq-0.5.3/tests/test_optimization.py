"""Comprehensive tests for Phase 3 — Optimization Engine.

Covers: FunctionRegistry, VariantManager, MetricRegistry, ExperimentManager,
bandit algorithms (Thompson + Track-and-Stop), TemplateEngine, EmbeddingDICL,
MetricRecorder, and the Functions API router.

All tests use isolated temp-directory SQLite databases — no external
dependencies (no clarabel, no sentence-transformers, no real LLM calls).
"""

import threading
from collections import Counter
from unittest.mock import MagicMock

import jinja2
import pytest

# ---------------------------------------------------------------------------
# Helpers — isolated DB per test
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_path(tmp_path):
    """Provide a database connection using the configured backend."""
    import coreiq.store.db as db_mod
    db_mod._thread_local = threading.local()

    try:
        conn = db_mod.create_connection()
        db_mod.init_schema(conn)
    except RuntimeError as exc:
        pytest.skip(f"Backend unavailable: {exc}")

    yield tmp_path / "test_opt.db"  # path kept for signature compat

    db_mod._thread_local = threading.local()


def _fresh_function_registry(db_path):
    from coreiq.optimization.function import FunctionRegistry
    reg = FunctionRegistry()
    reg._loaded = False
    reg._cache.clear()
    reg._id_cache.clear()
    return reg


def _fresh_variant_manager(db_path):
    from coreiq.optimization.variant import VariantManager
    mgr = VariantManager()
    mgr._loaded = False
    mgr._cache.clear()
    mgr._id_cache.clear()
    return mgr


def _fresh_metric_registry(db_path):
    from coreiq.optimization.metrics import MetricRegistry
    reg = MetricRegistry()
    reg._loaded = False
    reg._cache.clear()
    return reg


def _fresh_experiment_manager(db_path):
    from coreiq.optimization.experiment import ExperimentManager
    mgr = ExperimentManager()
    mgr._loaded = False
    mgr._active_experiments.clear()
    mgr._bandits.clear()
    return mgr


# ===========================================================================
# Function Registry (5 tests)
# ===========================================================================

class TestFunctionRegistry:

    def test_register_and_get_function(self, db_path):
        from coreiq.optimization.function import FunctionType
        reg = _fresh_function_registry(db_path)
        fd = reg.create("summarize", FunctionType.chat)
        assert fd.name == "summarize"
        assert fd.type == FunctionType.chat
        assert fd.id

        got = reg.get("summarize")
        assert got is not None
        assert got.id == fd.id

    def test_resolve_function_name(self, db_path):
        from coreiq.optimization.function import FunctionType
        reg = _fresh_function_registry(db_path)
        fd = reg.create("translate", FunctionType.json)

        # Resolve by name
        assert reg.resolve("translate") is not None
        assert reg.resolve("translate").id == fd.id

        # Resolve by id
        assert reg.resolve(fd.id) is not None
        assert reg.resolve(fd.id).name == "translate"

    def test_resolve_nonexistent_returns_none(self, db_path):
        reg = _fresh_function_registry(db_path)
        assert reg.resolve("does_not_exist") is None

    def test_list_functions(self, db_path):
        from coreiq.optimization.function import FunctionType
        reg = _fresh_function_registry(db_path)
        reg.create("fn_a", FunctionType.chat, tenant_id="t1")
        reg.create("fn_b", FunctionType.json, tenant_id="t2")
        reg.create("fn_c", FunctionType.chat, tenant_id="t1")

        assert len(reg.list()) == 3
        assert len(reg.list(tenant_id="t1")) == 2
        assert len(reg.list(tenant_id="t2")) == 1

    def test_delete_function(self, db_path):
        from coreiq.optimization.function import FunctionType
        reg = _fresh_function_registry(db_path)
        reg.create("doomed", FunctionType.chat)
        assert reg.get("doomed") is not None

        assert reg.delete("doomed") is True
        assert reg.get("doomed") is None
        assert reg.delete("doomed") is False  # already gone

    def test_duplicate_name_raises(self, db_path):
        from coreiq.optimization.function import FunctionType
        from coreiq.exceptions import ValidationError
        reg = _fresh_function_registry(db_path)
        reg.create("unique_fn", FunctionType.chat)
        with pytest.raises(ValidationError, match="already exists"):
            reg.create("unique_fn", FunctionType.chat)


# ===========================================================================
# Variant Manager (6 tests)
# ===========================================================================

class TestVariantManager:

    def _make_function(self, db_path):
        from coreiq.optimization.function import FunctionType
        reg = _fresh_function_registry(db_path)
        return reg.create("test_fn", FunctionType.chat)

    def test_create_variant(self, db_path):
        from coreiq.optimization.variant import VariantType
        fn = self._make_function(db_path)
        mgr = _fresh_variant_manager(db_path)
        vd = mgr.create(fn.id, "v1", VariantType.chat_completion, model="gpt-4o")
        assert vd.name == "v1"
        assert vd.model == "gpt-4o"
        assert vd.function_id == fn.id

    def test_list_variants_for_function(self, db_path):
        from coreiq.optimization.variant import VariantType
        fn = self._make_function(db_path)
        mgr = _fresh_variant_manager(db_path)
        mgr.create(fn.id, "v1", VariantType.chat_completion)
        mgr.create(fn.id, "v2", VariantType.dicl)
        mgr.create(fn.id, "v3", VariantType.chain_of_thought, active=False)

        assert len(mgr.list(fn.id)) == 3
        assert len(mgr.list(fn.id, active_only=True)) == 2

    def test_select_variant_weighted(self, db_path):
        """Run N selections and verify the distribution roughly matches weights."""
        from coreiq.optimization.variant import VariantType
        fn = self._make_function(db_path)
        mgr = _fresh_variant_manager(db_path)
        mgr.create(fn.id, "heavy", VariantType.chat_completion, weight=9.0)
        mgr.create(fn.id, "light", VariantType.chat_completion, weight=1.0)

        counts = Counter()
        N = 2000
        for _ in range(N):
            v = mgr.select_variant(fn.id)
            counts[v.name] += 1

        # heavy should get ~90% +/- 5%
        ratio = counts["heavy"] / N
        assert 0.80 < ratio < 0.97, f"heavy ratio = {ratio:.3f}"

    def test_deactivate_variant(self, db_path):
        from coreiq.optimization.variant import VariantType
        fn = self._make_function(db_path)
        mgr = _fresh_variant_manager(db_path)
        vd = mgr.create(fn.id, "v1", VariantType.chat_completion)
        assert vd.active is True

        mgr.update(vd.id, active=False)
        updated = mgr.get_by_id(vd.id)
        assert updated.active is False

    def test_variant_types(self, db_path):
        from coreiq.optimization.variant import VariantType
        fn = self._make_function(db_path)
        mgr = _fresh_variant_manager(db_path)
        for vt in VariantType:
            vd = mgr.create(fn.id, f"v_{vt.value}", vt)
            assert vd.type == vt

    def test_delete_variant(self, db_path):
        from coreiq.optimization.variant import VariantType
        fn = self._make_function(db_path)
        mgr = _fresh_variant_manager(db_path)
        vd = mgr.create(fn.id, "v1", VariantType.chat_completion)
        assert mgr.delete(vd.id) is True
        assert mgr.get_by_id(vd.id) is None


# ===========================================================================
# Metrics (5 tests)
# ===========================================================================

class TestMetrics:

    def test_register_metric(self, db_path):
        from coreiq.optimization.metrics import MetricType, MetricLevel, MetricOptimize
        reg = _fresh_metric_registry(db_path)
        md = reg.create("accuracy", MetricType.float_, MetricLevel.inference, MetricOptimize.max)
        assert md.name == "accuracy"
        assert md.type == MetricType.float_
        assert reg.get("accuracy") is not None

    def test_normalize_boolean_reward(self, db_path):
        from coreiq.optimization.metrics import MetricDef, MetricType, MetricLevel, MetricOptimize
        md = MetricDef(
            id="x", name="thumbs_up", type=MetricType.boolean,
            level=MetricLevel.inference, optimize=MetricOptimize.max,
        )
        assert md.normalize_to_reward(True) == 1.0
        assert md.normalize_to_reward(False) == 0.0
        assert md.normalize_to_reward(1) == 1.0
        assert md.normalize_to_reward(0) == 0.0

    def test_normalize_float_max(self, db_path):
        from coreiq.optimization.metrics import MetricDef, MetricType, MetricLevel, MetricOptimize
        md = MetricDef(
            id="x", name="score", type=MetricType.float_,
            level=MetricLevel.inference, optimize=MetricOptimize.max,
        )
        assert md.normalize_to_reward(0.7) == pytest.approx(0.7)
        assert md.normalize_to_reward(1.5) == 1.0  # clamped
        assert md.normalize_to_reward(-0.5) == 0.0  # clamped

    def test_normalize_float_min(self, db_path):
        from coreiq.optimization.metrics import MetricDef, MetricType, MetricLevel, MetricOptimize
        md = MetricDef(
            id="x", name="latency", type=MetricType.float_,
            level=MetricLevel.inference, optimize=MetricOptimize.min,
        )
        # optimize=min means reward is flipped: low value = high reward
        assert md.normalize_to_reward(0.2) == pytest.approx(0.8)
        assert md.normalize_to_reward(0.0) == 1.0

    def test_record_value(self, db_path):
        from coreiq.optimization.metrics import MetricType, MetricLevel, MetricOptimize
        reg = _fresh_metric_registry(db_path)
        reg.create("thumbs", MetricType.boolean, MetricLevel.inference, MetricOptimize.max)
        mv = reg.record_value("thumbs", inference_id="inf_1", value=1.0)
        assert mv.metric_name == "thumbs"
        assert mv.value == 1.0

        vals = reg.get_values("thumbs", inference_id="inf_1")
        assert len(vals) == 1


# ===========================================================================
# Experiment Lifecycle (5 tests)
# ===========================================================================

class TestExperimentLifecycle:

    def _setup(self, db_path):
        from coreiq.optimization.function import FunctionType
        from coreiq.optimization.variant import VariantType
        from coreiq.optimization.metrics import MetricType, MetricLevel, MetricOptimize
        fn_reg = _fresh_function_registry(db_path)
        fn = fn_reg.create("exp_fn", FunctionType.chat)

        var_mgr = _fresh_variant_manager(db_path)
        v1 = var_mgr.create(fn.id, "v1", VariantType.chat_completion)
        v2 = var_mgr.create(fn.id, "v2", VariantType.chat_completion)

        met_reg = _fresh_metric_registry(db_path)
        met_reg.create("quality", MetricType.float_, MetricLevel.inference, MetricOptimize.max)

        exp_mgr = _fresh_experiment_manager(db_path)
        return fn, v1, v2, exp_mgr

    def test_create_experiment(self, db_path):
        from coreiq.optimization.experiment import ExperimentType, ExperimentStatus
        fn, v1, v2, mgr = self._setup(db_path)
        exp = mgr.create(fn.id, "test_exp", ExperimentType.adaptive,
                         [v1.id, v2.id], metric_name="quality")
        assert exp.status == ExperimentStatus.draft
        assert len(exp.candidate_variant_ids) == 2

    def test_start_experiment(self, db_path):
        from coreiq.optimization.experiment import ExperimentType, ExperimentStatus
        fn, v1, v2, mgr = self._setup(db_path)
        exp = mgr.create(fn.id, "test_exp", ExperimentType.adaptive,
                         [v1.id, v2.id], metric_name="quality")
        started = mgr.start(exp.id)
        assert started.status == ExperimentStatus.active
        assert started.started_at is not None

    def test_conclude_experiment(self, db_path):
        from coreiq.optimization.experiment import ExperimentType, ExperimentStatus
        fn, v1, v2, mgr = self._setup(db_path)
        exp = mgr.create(fn.id, "test_exp", ExperimentType.adaptive,
                         [v1.id, v2.id], metric_name="quality")
        mgr.start(exp.id)
        concluded = mgr.conclude(exp.id, winner_variant_id=v1.id)
        assert concluded.status == ExperimentStatus.concluded
        assert concluded.winner_variant_id == v1.id

    def test_one_active_per_function(self, db_path):
        from coreiq.optimization.experiment import ExperimentType
        from coreiq.exceptions import ValidationError
        fn, v1, v2, mgr = self._setup(db_path)
        exp1 = mgr.create(fn.id, "exp1", ExperimentType.adaptive,
                          [v1.id, v2.id], metric_name="quality")
        exp2 = mgr.create(fn.id, "exp2", ExperimentType.adaptive,
                          [v1.id, v2.id], metric_name="quality")
        mgr.start(exp1.id)

        with pytest.raises(ValidationError, match="already has an active"):
            mgr.start(exp2.id)

    def test_record_reward(self, db_path):
        from coreiq.optimization.experiment import ExperimentType
        fn, v1, v2, mgr = self._setup(db_path)
        exp = mgr.create(fn.id, "test_exp", ExperimentType.adaptive,
                         [v1.id, v2.id], metric_name="quality")
        mgr.start(exp.id)

        # Record rewards for v1
        for _ in range(5):
            mgr.record_reward(fn.id, v1.id, 0.9)
        for _ in range(5):
            mgr.record_reward(fn.id, v2.id, 0.3)

        stats = mgr.get_bandit_stats(exp.id)
        assert len(stats) == 2
        # v1 should have higher win rate
        v1_stat = [s for s in stats if s["variant_id"] == v1.id][0]
        v2_stat = [s for s in stats if s["variant_id"] == v2.id][0]
        assert v1_stat["win_rate"] > v2_stat["win_rate"]


# ===========================================================================
# Bandit Algorithms (7 tests)
# ===========================================================================

class TestThompsonBandit:

    def test_thompson_bandit_select(self, db_path):
        from coreiq.optimization.bandit import ThompsonBandit
        bandit = ThompsonBandit(["a", "b", "c"])
        selected = bandit.select()
        assert selected in ("a", "b", "c")

    def test_thompson_bandit_update_and_best(self, db_path):
        from coreiq.optimization.bandit import ThompsonBandit
        bandit = ThompsonBandit(["a", "b"])
        # Give lots of reward to "a"
        for _ in range(50):
            bandit.update("a", 1.0)
            bandit.update("b", 0.0)
        assert bandit.best() == "a"

    def test_thompson_should_stop_always_false(self, db_path):
        from coreiq.optimization.bandit import ThompsonBandit
        bandit = ThompsonBandit(["a", "b"])
        assert bandit.should_stop() is False
        for _ in range(100):
            bandit.update("a", 1.0)
        assert bandit.should_stop() is False


class TestTrackAndStopBandit:

    def test_track_and_stop_nursery_phase(self, db_path):
        from coreiq.optimization.bandit import TrackAndStopBandit
        bandit = TrackAndStopBandit(["a", "b"], min_samples_per_variant=3)

        # During nursery we should see round-robin
        selections = [bandit.select() for _ in range(6)]
        # Should have pulled each arm 3 times (round-robin)
        assert selections.count("a") == 3
        assert selections.count("b") == 3

    def test_track_and_stop_update(self, db_path):
        from coreiq.optimization.bandit import TrackAndStopBandit
        bandit = TrackAndStopBandit(["a", "b"], min_samples_per_variant=2)

        # Feed nursery phase
        bandit.update("a", 1.0)
        bandit.update("a", 1.0)
        bandit.update("b", 0.0)
        bandit.update("b", 0.0)

        # Now in tracking phase — "a" should be best
        assert bandit.best() == "a"

    def test_track_and_stop_state_serialization(self, db_path):
        from coreiq.optimization.bandit import TrackAndStopBandit
        bandit = TrackAndStopBandit(["a", "b"], min_samples_per_variant=2, delta=0.1)
        bandit.update("a", 1.0)
        bandit.update("a", 0.8)
        bandit.update("b", 0.2)
        bandit.update("b", 0.3)

        state = bandit.state_dict()
        assert state["algorithm"] == "track_and_stop"
        assert "a" in state["arms"]
        assert state["arms"]["a"]["count"] == 2

        restored = TrackAndStopBandit.from_state_dict(state)
        assert restored.best() == bandit.best()
        assert restored.state_dict()["total_pulls"] == state["total_pulls"]

    def test_track_and_stop_requires_two_variants(self, db_path):
        from coreiq.optimization.bandit import TrackAndStopBandit
        with pytest.raises(ValueError, match="at least 2"):
            TrackAndStopBandit(["only_one"])


class TestBanditBaseInterface:

    def test_bandit_base_interface(self, db_path):
        """Both bandit implementations conform to BanditBase."""
        from coreiq.optimization.bandit import BanditBase, ThompsonBandit, TrackAndStopBandit
        assert issubclass(ThompsonBandit, BanditBase)
        assert issubclass(TrackAndStopBandit, BanditBase)

        for cls, args in [(ThompsonBandit, (["x", "y"],)), (TrackAndStopBandit, (["x", "y"],))]:
            b = cls(*args)
            # All abstract methods are callable
            assert isinstance(b.select(), str)
            b.update("x", 0.5)
            assert b.best() in ("x", "y", None)
            assert isinstance(b.should_stop(), bool)
            assert isinstance(b.stats(), list)
            state = b.state_dict()
            assert isinstance(state, dict)
            restored = cls.from_state_dict(state)
            assert isinstance(restored, BanditBase)


# ===========================================================================
# Templates (4 tests)
# ===========================================================================

class TestTemplates:

    def test_render_string(self, db_path):
        from coreiq.optimization.templates import TemplateEngine
        engine = TemplateEngine()
        result = engine.render_string("Hello {{name}}!", {"name": "World"})
        assert result == "Hello World!"

    def test_render_variant_system_template(self, db_path):
        from coreiq.optimization.templates import TemplateEngine
        engine = TemplateEngine()
        variant = {
            "system_template": "You are a {{role}}.",
            "user_template": "Summarise: {{text}}",
        }
        rendered = engine.render_variant(variant, {"role": "editor", "text": "Hello world"})
        assert rendered.system_prompt == "You are a editor."
        assert rendered.user_prompt == "Summarise: Hello world"
        assert rendered.messages[0]["role"] == "system"
        assert rendered.messages[-1]["role"] == "user"

    def test_rendered_input_stored_vs_messages(self, db_path):
        from coreiq.optimization.templates import TemplateEngine
        engine = TemplateEngine()
        variant = {
            "system_template": "System: {{s}}",
            "user_template": "User: {{u}}",
        }
        data = {"s": "hello", "u": "world"}
        rendered = engine.render_variant(variant, data)
        # stored_input preserves the original data
        assert rendered.stored_input == data
        # messages are fully rendered strings
        assert len(rendered.messages) == 2
        assert "hello" in rendered.messages[0]["content"]

    def test_strict_undefined_error(self, db_path):
        from coreiq.optimization.templates import TemplateEngine
        engine = TemplateEngine()
        with pytest.raises(jinja2.UndefinedError):
            engine.render_string("Hello {{missing_var}}!", {})

    def test_render_with_dicl_messages(self, db_path):
        from coreiq.optimization.templates import TemplateEngine
        engine = TemplateEngine()
        variant = {
            "system_template": "You are helpful.{{ '' }}",
            "user_template": "Question: {{q}}",
        }
        dicl = [
            {"role": "user", "content": "example q"},
            {"role": "assistant", "content": "example a"},
        ]
        rendered = engine.render_variant(variant, {"q": "real question"}, dicl_messages=dicl)
        # Order: system, dicl_user, dicl_assistant, user
        assert len(rendered.messages) == 4
        assert rendered.messages[0]["role"] == "system"
        assert rendered.messages[1]["role"] == "user"
        assert rendered.messages[1]["content"] == "example q"
        assert rendered.messages[3]["role"] == "user"


# ===========================================================================
# DICL (4 tests)
# ===========================================================================

class TestDICL:

    def test_add_and_retrieve_example(self, db_path, tmp_path):
        from coreiq.optimization.dicl import EmbeddingDICL
        # dicl_examples.function_id REFERENCES functions(id) — insert a stub
        # so FK enforcement (always on post-refactor) is satisfied.
        import coreiq.store.db as db_mod
        conn = db_mod.get_shared_connection()
        conn.execute(
            "INSERT OR IGNORE INTO functions(id,name,type,created_at) VALUES(?,?,?,?)",
            ("fn1", "fn1", "chat", "2024-01-01"),
        )
        conn.commit()

        dicl = EmbeddingDICL(db_path=tmp_path / "dicl.db")

        dicl.add_example("fn1", "v1", {"text": "hello world"}, {"summary": "hi"}, 0.9)
        dicl.add_example("fn1", "v1", {"text": "goodbye world"}, {"summary": "bye"}, 0.8)

        results = dicl.retrieve("fn1", {"text": "hello world"}, k=5, min_similarity=0.0)
        assert len(results) >= 1
        # The most similar should be the "hello world" example
        assert results[0].input_data["text"] == "hello world"

    def test_cosine_similarity(self, db_path):
        from coreiq.optimization.dicl import EmbeddingDICL
        # Test static method directly
        a = [1.0, 0.0, 0.0]
        b = [1.0, 0.0, 0.0]
        assert EmbeddingDICL._cosine_similarity(a, b) == pytest.approx(1.0)

        c = [0.0, 1.0, 0.0]
        assert EmbeddingDICL._cosine_similarity(a, c) == pytest.approx(0.0)

        # Zero vector
        z = [0.0, 0.0, 0.0]
        assert EmbeddingDICL._cosine_similarity(a, z) == pytest.approx(0.0)

    def test_to_messages_format(self, db_path):
        from coreiq.optimization.dicl import EmbeddingDICL, DICLExample
        dicl = EmbeddingDICL()
        examples = [
            DICLExample(
                id="1", function_id="f", variant_name="v",
                input_data={"text": "input1"}, output_data={"text": "output1"},
            ),
            DICLExample(
                id="2", function_id="f", variant_name="v",
                input_data={"text": "input2"}, output_data={"text": "output2"},
            ),
        ]
        messages = dicl.to_messages(examples)
        assert len(messages) == 4
        assert messages[0]["role"] == "user"
        assert messages[1]["role"] == "assistant"
        assert messages[0]["content"] == "input1"
        assert messages[1]["content"] == "output1"

    def test_min_similarity_filter(self, db_path, tmp_path):
        from coreiq.optimization.dicl import EmbeddingDICL
        # Satisfy dicl_examples.function_id FK against functions(id).
        import coreiq.store.db as db_mod
        conn = db_mod.get_shared_connection()
        conn.execute(
            "INSERT OR IGNORE INTO functions(id,name,type,created_at) VALUES(?,?,?,?)",
            ("fn1", "fn1", "chat", "2024-01-01"),
        )
        conn.commit()

        dicl = EmbeddingDICL(db_path=tmp_path / "dicl_filter.db")

        dicl.add_example("fn1", "v1", {"text": "apple orange banana"}, {"out": "fruit"})
        dicl.add_example("fn1", "v1", {"text": "car truck bus"}, {"out": "vehicle"})

        # With very high threshold, should get fewer or no results
        results_high = dicl.retrieve("fn1", {"text": "apple orange banana"}, k=5, min_similarity=0.99)
        results_low = dicl.retrieve("fn1", {"text": "apple orange banana"}, k=5, min_similarity=0.0)
        # Low threshold should return more (or equal) results
        assert len(results_low) >= len(results_high)


# ===========================================================================
# Feedback / MetricRecorder (4 tests)
# ===========================================================================

class TestMetricRecorder:

    def _setup_metrics(self, db_path):
        from coreiq.optimization.metrics import MetricType, MetricLevel, MetricOptimize
        reg = _fresh_metric_registry(db_path)
        reg.create("thumbs_up", MetricType.boolean, MetricLevel.inference, MetricOptimize.max)
        reg.create("score", MetricType.float_, MetricLevel.inference, MetricOptimize.max)
        return reg

    def test_record_boolean_feedback(self, db_path):
        from coreiq.optimization.feedback import MetricRecorder
        reg = self._setup_metrics(db_path)
        recorder = MetricRecorder(metric_registry=reg)
        result = recorder.record_boolean("thumbs_up", "inf_1", True)
        assert result["metric_name"] == "thumbs_up"
        assert result["inference_id"] == "inf_1"

    def test_record_float_feedback(self, db_path):
        from coreiq.optimization.feedback import MetricRecorder
        reg = self._setup_metrics(db_path)
        recorder = MetricRecorder(metric_registry=reg)
        result = recorder.record_float("score", "inf_2", 0.85)
        assert result["metric_name"] == "score"

    def test_get_for_inference(self, db_path):
        from coreiq.optimization.feedback import MetricRecorder
        reg = self._setup_metrics(db_path)
        recorder = MetricRecorder(metric_registry=reg)
        recorder.record_boolean("thumbs_up", "inf_3", True)
        recorder.record_float("score", "inf_3", 0.9)

        vals = recorder.get_for_inference("inf_3")
        assert len(vals) == 2
        names = {v["metric_name"] for v in vals}
        assert "thumbs_up" in names
        assert "score" in names

    def test_auto_bandit_update(self, db_path):
        """MetricRecorder triggers experiment_manager.record_reward when
        the inference belongs to a function with an active experiment."""
        from coreiq.optimization.feedback import MetricRecorder

        reg = self._setup_metrics(db_path)

        # Mock experiment manager
        mock_exp_mgr = MagicMock()
        mock_exp = MagicMock()
        mock_exp.metric_name = "thumbs_up"
        mock_exp_mgr.get_active_for_function.return_value = mock_exp

        recorder = MetricRecorder(metric_registry=reg, experiment_manager=mock_exp_mgr)

        # Insert a fake inference row so _trigger_bandit_update can look it up
        from coreiq.store.db import get_shared_connection
        conn = get_shared_connection()
        conn.execute(
            "INSERT INTO inferences(id, function_id, variant_id) VALUES (?, ?, ?)",
            ("inf_bandit", "fn_abc", "var_xyz"),
        )
        conn.commit()

        recorder.record_boolean("thumbs_up", "inf_bandit", True)

        # The experiment manager should have been asked to record a reward
        mock_exp_mgr.record_reward.assert_called_once()
        call_args = mock_exp_mgr.record_reward.call_args
        assert call_args[0][0] == "fn_abc"  # function_id
        assert call_args[0][1] == "var_xyz"  # variant_id
        assert call_args[0][2] == 1.0  # reward for True boolean


# ===========================================================================
# Functions API (4 tests)
# ===========================================================================

class TestFunctionsAPI:
    """Test the FastAPI router endpoints using TestClient."""

    @pytest.fixture(autouse=True)
    def _reset_singletons(self, db_path):
        """Reset the module-level singletons before each test."""
        import coreiq.server.routers.functions as fn_mod
        fn_mod._fn_registry = None
        fn_mod._variant_mgr = None
        fn_mod._experiment_mgr = None
        fn_mod._metric_registry = None
        fn_mod._metric_recorder = None
        yield
        fn_mod._fn_registry = None
        fn_mod._variant_mgr = None
        fn_mod._experiment_mgr = None
        fn_mod._metric_registry = None
        fn_mod._metric_recorder = None

    def _get_client(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from coreiq.server.routers.functions import router
        app = FastAPI()
        app.include_router(router)
        return TestClient(app)

    def test_create_function_endpoint(self, db_path):
        client = self._get_client()
        resp = client.post("/api/functions", json={
            "name": "summarize",
            "type": "chat",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "summarize"
        assert data["type"] == "chat"
        assert "id" in data

    def test_list_functions_endpoint(self, db_path):
        client = self._get_client()
        client.post("/api/functions", json={"name": "fn_a", "type": "chat"})
        client.post("/api/functions", json={"name": "fn_b", "type": "json"})

        resp = client.get("/api/functions")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2

    def test_create_variant_endpoint(self, db_path):
        client = self._get_client()
        # First create a function
        fn_resp = client.post("/api/functions", json={"name": "my_fn", "type": "chat"})
        assert fn_resp.status_code == 200

        # Then create a variant
        resp = client.post("/api/functions/my_fn/variants", json={
            "name": "v1",
            "type": "chat_completion",
            "model": "gpt-4o",
            "system_template": "You are {{role}}.",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "v1"
        assert data["model"] == "gpt-4o"

    def test_create_metric_definition_endpoint(self, db_path):
        client = self._get_client()
        resp = client.post("/api/metrics/definitions", json={
            "name": "relevance",
            "type": "float",
            "level": "inference",
            "optimize": "max",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "relevance"
        assert data["type"] == "float"
        assert data["optimize"] == "max"

    def test_list_metric_definitions_endpoint(self, db_path):
        client = self._get_client()
        client.post("/api/metrics/definitions", json={
            "name": "m1", "type": "boolean", "level": "inference", "optimize": "max"
        })
        resp = client.get("/api/metrics/definitions")
        assert resp.status_code == 200
        assert len(resp.json()) == 1
