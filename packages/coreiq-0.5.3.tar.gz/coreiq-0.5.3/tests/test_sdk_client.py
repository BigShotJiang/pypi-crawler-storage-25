"""Tests for CoreIQClient and module-level log_event."""
import pytest
import uuid

from coreiq.client import CoreIQClient, log_event


@pytest.fixture(autouse=True)
def _reset_writer(tmp_path, monkeypatch):
    """Give each test a fresh DB."""
    db_path = tmp_path / "test.db"
    monkeypatch.setenv("COREIQ_DB_PATH", str(db_path))
    import coreiq.store.writer as w
    w._writer = None
    yield
    w._writer = None


def test_log_event_returns_uuid():
    eid = log_event("Something happened")
    assert isinstance(eid, str)
    assert len(eid) == 36


def test_log_event_with_metadata():
    eid = log_event("Cache miss", metadata={"key": "hello", "score": 0.5})
    assert eid is not None


def test_log_event_level_warning():
    eid = log_event("High latency detected", level="warning", source="tracer")
    assert eid is not None


def test_log_event_invalid_level():
    from coreiq.exceptions import ValidationError
    with pytest.raises(ValidationError):
        log_event("oops", level="verbose")  # not a valid level


def test_client_log_event():
    client = CoreIQClient()
    eid = client.log_event("Client event", level="debug")
    assert isinstance(eid, str)


def test_client_log_event_with_trace_id():
    client = CoreIQClient()
    tid = str(uuid.uuid4())
    eid = client.log_event("Linked event", trace_id=tid)
    from coreiq.store.writer import get_writer
    writer = get_writer()
    row = writer._conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    assert row["trace_id"] == tid


def test_log_event_kwargs_metadata():
    eid = log_event("signup", plan="pro", user_id="u1")
    assert eid is not None


def test_client_log_event_kwargs():
    client = CoreIQClient()
    eid = client.log_event("user action", plan="enterprise")
    assert eid is not None


def test_log_event_kwargs_merged_with_metadata():
    from coreiq.store.writer import get_writer
    import json
    eid = log_event("test", {"existing": "val"}, extra_key="extra_val")
    writer = get_writer()
    row = writer._conn.execute("SELECT meta_json FROM events WHERE id=?", (eid,)).fetchone()
    meta = json.loads(row["meta_json"])
    assert meta["existing"] == "val"
    assert meta["extra_key"] == "extra_val"
