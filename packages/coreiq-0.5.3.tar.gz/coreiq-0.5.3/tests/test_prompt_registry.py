"""Tests for the Prompt Registry — version control, deploy, canary, rollback, diff."""
import os
import pytest

# Force SQLite backend for tests
os.environ.setdefault("COREIQ_STORE_BACKEND", "sqlite")


@pytest.fixture(autouse=True)
def _isolated_db(tmp_path, monkeypatch):
    """Each test gets its own fresh SQLite database."""
    db_file = tmp_path / "test_prompts.db"
    monkeypatch.setenv("COREIQ_DB_PATH", str(db_file))
    # Force re-creation of thread-local connections
    from coreiq.store import db as db_mod
    if hasattr(db_mod._thread_local, 'conn'):
        db_mod._thread_local.conn = None
    if hasattr(db_mod._thread_local, 'conn_path'):
        db_mod._thread_local.conn_path = None

    from coreiq.store.db import create_connection, init_schema
    conn = create_connection()
    init_schema(conn)
    yield


@pytest.fixture
def registry():
    from coreiq.prompts.registry import PromptRegistry
    return PromptRegistry()


# ── Registration ─────────────────────────────────────────────────────────────

class TestRegistration:
    def test_register_first_version(self, registry):
        pv = registry.register("greeting", version="1.0", template="Hello {{name}}")
        assert pv.prompt_id == "greeting"
        assert pv.version == "1.0"
        assert pv.template == "Hello {{name}}"
        assert pv.parent_version_id is None
        assert pv.status.value == "draft"

    def test_register_second_version_links_parent(self, registry):
        v1 = registry.register("greeting", version="1.0", template="Hello {{name}}")
        v2 = registry.register("greeting", version="2.0", template="Hi {{name}}!")
        assert v2.parent_version_id == v1.id

    def test_register_duplicate_version_returns_existing(self, registry):
        # Registration is idempotent — re-registering the same version returns
        # the existing record regardless of template content.
        v1 = registry.register("greeting", version="1.0", template="Hello")
        v2 = registry.register("greeting", version="1.0", template="Different")
        assert v2.id == v1.id

    def test_register_with_metadata(self, registry):
        pv = registry.register(
            "greeting", version="1.0", template="Hello",
            metadata={"author": "alice", "change": "initial version"},
            created_by="alice",
        )
        assert pv.metadata == {"author": "alice", "change": "initial version"}
        assert pv.created_by == "alice"

    def test_list_prompts(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        registry.register("farewell", version="1.0", template="Goodbye")
        prompts = registry.list_prompts()
        assert len(prompts) == 2
        ids = {p["prompt_id"] for p in prompts}
        assert ids == {"greeting", "farewell"}

    def test_list_versions(self, registry):
        registry.register("greeting", version="1.0", template="v1")
        registry.register("greeting", version="2.0", template="v2")
        registry.register("greeting", version="3.0", template="v3")
        versions = registry.list_versions("greeting")
        assert len(versions) == 3
        assert [v.version for v in versions] == ["1.0", "2.0", "3.0"]

    def test_get_version(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        pv = registry.get_version("greeting", "1.0")
        assert pv is not None
        assert pv.template == "Hello"

    def test_get_latest_version(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        registry.register("greeting", version="2.0", template="Hi")
        latest = registry.get_latest_version("greeting")
        assert latest.version == "2.0"

    def test_version_history_chain(self, registry):
        registry.register("greeting", version="1.0", template="v1")
        registry.register("greeting", version="2.0", template="v2")
        registry.register("greeting", version="3.0", template="v3")
        chain = registry.get_version_history("greeting", "3.0")
        assert len(chain) == 3
        assert chain[0].version == "3.0"
        assert chain[1].version == "2.0"
        assert chain[2].version == "1.0"


# ── Approval Workflow ────────────────────────────────────────────────────────

class TestApprovalWorkflow:
    def test_submit_for_review(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        pv = registry.submit_for_review("greeting", "1.0")
        assert pv.status.value == "review"

    def test_approve(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        registry.submit_for_review("greeting", "1.0")
        pv = registry.approve("greeting", "1.0", approved_by="bob")
        assert pv.status.value == "approved"
        assert pv.approved_by == "bob"
        assert pv.approved_at is not None

    def test_cannot_skip_review(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        with pytest.raises(Exception, match="Cannot transition"):
            registry.approve("greeting", "1.0", approved_by="bob")

    def test_archive(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        pv = registry.archive("greeting", "1.0")
        assert pv.status.value == "archived"


# ── Diff ─────────────────────────────────────────────────────────────────────

class TestDiff:
    def test_diff_two_versions(self, registry):
        registry.register("greeting", version="1.0", template="Hello {{name}}")
        registry.register("greeting", version="2.0", template="Hi {{name}}, welcome!")
        diff = registry.diff("greeting", "1.0", "2.0")
        assert diff.additions > 0 or diff.deletions > 0
        assert "Hello" in diff.unified_diff
        assert "Hi" in diff.unified_diff

    def test_diff_identical(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        registry.register("greeting", version="1.1", template="Hello")
        diff = registry.diff("greeting", "1.0", "1.1")
        assert diff.additions == 0
        assert diff.deletions == 0

    def test_diff_missing_version_raises(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        with pytest.raises(Exception, match="not found"):
            registry.diff("greeting", "1.0", "9.9")


# ── Deployment & Canary ──────────────────────────────────────────────────────

class TestDeployment:
    def _make_approved(self, registry, prompt_id, version, template):
        registry.register(prompt_id, version=version, template=template)
        registry.submit_for_review(prompt_id, version)
        registry.approve(prompt_id, version, approved_by="admin")

    def test_deploy_approved_version(self, registry):
        self._make_approved(registry, "greeting", "1.0", "Hello")
        dep = registry.deploy("greeting", version="1.0")
        assert dep.status.value == "promoted"
        assert dep.traffic_percent == 1.0

    def test_deploy_unapproved_raises(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        with pytest.raises(Exception, match="must be approved"):
            registry.deploy("greeting", version="1.0")

    def test_deploy_unapproved_with_allow(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        dep = registry.deploy("greeting", version="1.0", allow_unapproved=True)
        assert dep.status.value == "promoted"

    def test_canary_deploy(self, registry):
        self._make_approved(registry, "greeting", "1.0", "Hello")
        dep = registry.deploy("greeting", version="1.0", traffic=0.1)
        assert dep.status.value == "canary"
        assert dep.traffic_percent == 0.1

    def test_promote_canary(self, registry):
        self._make_approved(registry, "greeting", "1.0", "Hello")
        registry.deploy("greeting", version="1.0", traffic=0.1)
        dep = registry.promote("greeting")
        assert dep.status.value == "promoted"
        assert dep.traffic_percent == 1.0

    def test_rollback(self, registry):
        self._make_approved(registry, "greeting", "1.0", "Hello v1")
        registry.deploy("greeting", version="1.0", allow_unapproved=True)
        self._make_approved(registry, "greeting", "2.0", "Hello v2")
        registry.deploy("greeting", version="2.0")
        dep = registry.rollback("greeting")
        assert dep.status.value == "rolled_back"
        # Check that v1 is now deployed
        current_dep = registry.get_deployment("greeting")
        assert current_dep is not None
        v1 = registry.get_version("greeting", "1.0")
        assert current_dep.version_id == v1.id

    def test_rollback_policy(self, registry):
        self._make_approved(registry, "greeting", "1.0", "Hello")
        registry.deploy("greeting", version="1.0")
        dep = registry.set_rollback_policy("greeting", metric="error_rate", threshold=0.1)
        assert dep.rollback_policy is not None
        assert dep.rollback_policy.metric == "error_rate"
        assert dep.rollback_policy.threshold == 0.1

    def test_get_deployment(self, registry):
        self._make_approved(registry, "greeting", "1.0", "Hello")
        registry.deploy("greeting", version="1.0")
        dep = registry.get_deployment("greeting")
        assert dep is not None
        assert dep.prompt_id == "greeting"


# ── Resolution (canary routing) ─────────────────────────────────────────────

class TestResolution:
    def test_resolve_full_deploy(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        registry.deploy("greeting", version="1.0", allow_unapproved=True)
        pv = registry.resolve("greeting")
        assert pv.template == "Hello"

    def test_resolve_canary_deterministic(self, registry):
        registry.register("greeting", version="1.0", template="Old")
        registry.deploy("greeting", version="1.0", traffic=1.0, allow_unapproved=True)
        registry.register("greeting", version="2.0", template="New")
        registry.deploy("greeting", version="2.0", traffic=0.5, allow_unapproved=True)

        # Same context_key should always resolve to the same version
        results = set()
        for _ in range(10):
            pv = registry.resolve("greeting", context_key="user-123")
            results.add(pv.template)
        assert len(results) == 1  # deterministic

    def test_resolve_canary_splits_traffic(self, registry):
        registry.register("greeting", version="1.0", template="Old")
        registry.deploy("greeting", version="1.0", traffic=1.0, allow_unapproved=True)
        registry.register("greeting", version="2.0", template="New")
        registry.deploy("greeting", version="2.0", traffic=0.5, allow_unapproved=True)

        # With many different users, both versions should appear
        templates = set()
        for i in range(100):
            pv = registry.resolve("greeting", context_key=f"user-{i}")
            templates.add(pv.template)
        assert len(templates) == 2  # both old and new served

    def test_resolve_no_deployment_returns_none(self, registry):
        result = registry.resolve("nonexistent")
        assert result is None


# ── Auto-rollback ────────────────────────────────────────────────────────────

class TestAutoRollback:
    def test_check_rollback_triggers(self, registry):
        registry.register("greeting", version="1.0", template="Old")
        registry.deploy("greeting", version="1.0", allow_unapproved=True)
        registry.register("greeting", version="2.0", template="New")
        registry.deploy("greeting", version="2.0", allow_unapproved=True)
        registry.set_rollback_policy("greeting", metric="error_rate", threshold=0.1)

        # Simulate metric breach
        def get_metric(name, window):
            return 0.2  # above threshold

        rolled_back = registry.check_rollback_policies(get_metric)
        assert "greeting" in rolled_back

    def test_check_rollback_does_not_trigger_below_threshold(self, registry):
        registry.register("greeting", version="1.0", template="Hello")
        registry.deploy("greeting", version="1.0", allow_unapproved=True)
        registry.set_rollback_policy("greeting", metric="error_rate", threshold=0.5)

        def get_metric(name, window):
            return 0.1  # below threshold

        rolled_back = registry.check_rollback_policies(get_metric)
        assert len(rolled_back) == 0
