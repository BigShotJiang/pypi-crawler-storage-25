"""Tests for EventWriter — store/writer.py"""
import os
import pytest
import uuid

from coreiq.store.writer import EventWriter

DEFAULT_MODEL = os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")


@pytest.fixture
def writer(tmp_path):
    db = tmp_path / "test.db"
    return EventWriter(db_path=db)


def test_insert_trace(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=100, output_tok=50, latency_ms=420,
    )
    row = writer._conn.execute("SELECT * FROM traces WHERE id=?", (tid,)).fetchone()
    assert row is not None
    assert row["model"] == DEFAULT_MODEL
    assert row["input_tok"] == 100
    assert row["latency_ms"] == 420
    assert row["finish_reason"] == "stop"


def test_insert_cache_event(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=10, output_tok=5, latency_ms=100,
    )
    writer.insert_cache_event(trace_id=tid, hit=True, similarity=0.95, saved_tok=200)
    row = writer._conn.execute("SELECT * FROM cache_events WHERE trace_id=?", (tid,)).fetchone()
    assert row["hit"] == 1
    assert row["similarity"] == pytest.approx(0.95)


def test_insert_tool_call(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="claude-sonnet-4-6", provider="anthropic",
        input_tok=50, output_tok=20, latency_ms=300,
    )
    writer.insert_tool_call(trace_id=tid, tool_name="search", args_json='{"q":"test"}')
    row = writer._conn.execute("SELECT * FROM tool_calls WHERE trace_id=?", (tid,)).fetchone()
    assert row["tool_name"] == "search"
    assert row["valid"] == 1


def test_insert_feedback(writer):
    eid = str(uuid.uuid4())
    writer.insert_feedback(response_id=eid, signal="thumbs_up", value=1.0)
    row = writer._conn.execute("SELECT * FROM feedback WHERE response_id=?", (eid,)).fetchone()
    assert row["signal"] == "thumbs_up"
    assert row["value"] == 1.0


def test_insert_evolution(writer):
    vid = "variant-abc"
    writer.insert_evolution(variant_id=vid, phase="explore", win_rate=0.62, samples=50)
    row = writer._conn.execute("SELECT * FROM evolution WHERE variant_id=?", (vid,)).fetchone()
    assert row["phase"] == "explore"
    assert row["win_rate"] == pytest.approx(0.62)


def test_insert_query_recon(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=30, output_tok=15, latency_ms=200,
    )
    writer.insert_query_recon(
        trace_id=tid,
        original="What is the capital of France?",
        reconstructed="Capital of France?",
        similarity=0.88,
    )
    row = writer._conn.execute("SELECT * FROM query_recon WHERE trace_id=?", (tid,)).fetchone()
    assert row["original"] == "What is the capital of France?"
    assert row["similarity"] == pytest.approx(0.88)


def test_insert_event_returns_id(writer):
    eid = writer.insert_event(message="Server started", level="info", source="test")
    assert isinstance(eid, str)
    assert len(eid) == 36  # UUID


def test_insert_event_metadata(writer):
    eid = writer.insert_event(
        message="Cache miss",
        level="debug",
        metadata={"query": "hello", "latency_ms": 5},
        source="cache",
    )
    row = writer._conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    assert row["level"] == "debug"
    assert "query" in row["meta_json"]


def test_upsert_trace(writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=10, output_tok=5, latency_ms=100,
    )
    # Insert again with same ID (REPLACE semantics)
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=999, output_tok=5, latency_ms=100,
    )
    rows = writer._conn.execute("SELECT * FROM traces WHERE id=?", (tid,)).fetchall()
    assert len(rows) == 1
    assert rows[0]["input_tok"] == 999


# ── Observability v2 additions ────────────────────────────────────────────────

def test_insert_trace_ttft_and_cost(writer):
    """insert_trace accepts ttft_ms and cost_usd as first-class columns."""
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=100, output_tok=50, latency_ms=800,
        ttft_ms=120, cost_usd=0.00042,
    )
    writer.flush()
    row = writer._conn.execute("SELECT ttft_ms, cost_usd FROM traces WHERE id=?", (tid,)).fetchone()
    assert row is not None
    assert row["ttft_ms"] == 120
    assert abs(row["cost_usd"] - 0.00042) < 1e-9


def test_insert_trace_ttft_cost_default_none(writer):
    """ttft_ms and cost_usd default to NULL when not provided."""
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=10, output_tok=5, latency_ms=100,
    )
    writer.flush()
    row = writer._conn.execute("SELECT ttft_ms, cost_usd FROM traces WHERE id=?", (tid,)).fetchone()
    assert row["ttft_ms"] is None
    assert row["cost_usd"] is None


def test_insert_payload_request(writer):
    """insert_payload stores a masked request payload linked to a trace."""
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=20, output_tok=10, latency_ms=200,
    )
    writer.insert_payload(
        trace_id=tid,
        direction="request",
        content='[{"role":"user","content":"Hello ***"}]',
        size_bytes=40,
        truncated=False,
    )
    writer.flush()
    row = writer._conn.execute(
        "SELECT * FROM trace_payloads WHERE trace_id=?", (tid,)
    ).fetchone()
    assert row is not None
    assert row["direction"] == "request"
    assert "***" in row["content"]
    assert row["size_bytes"] == 40
    assert row["truncated"] == 0


def test_insert_payload_response(writer):
    """insert_payload stores a response payload; truncated flag persists."""
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=20, output_tok=10, latency_ms=200,
    )
    writer.insert_payload(
        trace_id=tid,
        direction="response",
        content="The answer is...",
        size_bytes=16,
        truncated=True,
    )
    writer.flush()
    row = writer._conn.execute(
        "SELECT truncated, direction FROM trace_payloads WHERE trace_id=?", (tid,)
    ).fetchone()
    assert row["direction"] == "response"
    assert row["truncated"] == 1


def test_insert_payload_both_directions(writer):
    """Both request and response payloads can be stored for the same trace."""
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=20, output_tok=10, latency_ms=200,
    )
    writer.insert_payload(trace_id=tid, direction="request", content="req", size_bytes=3, truncated=False)
    writer.insert_payload(trace_id=tid, direction="response", content="resp", size_bytes=4, truncated=False)
    writer.flush()
    rows = writer._conn.execute(
        "SELECT direction FROM trace_payloads WHERE trace_id=? ORDER BY direction", (tid,)
    ).fetchall()
    directions = [r["direction"] for r in rows]
    assert "request" in directions
    assert "response" in directions


def test_insert_eval_score(writer):
    """insert_eval_score stores a judge score row for a trace."""
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model=DEFAULT_MODEL, provider="openai_compat",
        input_tok=10, output_tok=5, latency_ms=100,
    )
    writer.insert_eval_score(
        trace_id=tid,
        judge_id="test-judge",
        dimension="faithfulness",
        score=0.91,
        rationale="Response closely follows the source.",
    )
    writer.flush()
    row = writer._conn.execute(
        "SELECT * FROM eval_scores WHERE trace_id=?", (tid,)
    ).fetchone()
    assert row is not None
    assert row["judge_id"] == "test-judge"
    assert row["dimension"] == "faithfulness"
    assert abs(row["score"] - 0.91) < 1e-9
    assert "closely" in row["rationale"]
