"""Tests for dev-mode auto-bootstrap on the first ``coreiq`` run.

The DX expert panel flagged that a brand-new `pip install coreiq &&
coreiq` fails with ``RuntimeError: COREIQ_API_KEY not set``. These
tests lock down the new dev-mode behaviour: when ``COREIQ_ENV`` is
unset or ``development``, coreiq generates an ephemeral API key and
uses a per-process audit HMAC marker so the server actually starts.

Production behaviour (fail-loud) is preserved and separately tested.
"""
from __future__ import annotations


import pytest


class TestAuditHMACKeyResolution:
    """coreiq.governance.chained_audit._get_hmac_key env resolution."""

    def test_explicit_key_used_verbatim(self, monkeypatch):
        monkeypatch.setenv("COREIQ_AUDIT_HMAC_KEY", "my-explicit-key")
        from coreiq.governance.chained_audit import _get_hmac_key
        assert _get_hmac_key() == b"my-explicit-key"

    def test_dev_mode_generates_ephemeral_key(self, monkeypatch):
        monkeypatch.delenv("COREIQ_AUDIT_HMAC_KEY", raising=False)
        monkeypatch.delenv("COREIQ_AUDIT_FAIL_OPEN", raising=False)
        monkeypatch.setenv("COREIQ_ENV", "development")
        from coreiq.governance.chained_audit import _get_hmac_key
        key = _get_hmac_key()
        assert key.startswith(b"coreiq-audit-dev-")

    def test_unset_env_defaults_to_dev(self, monkeypatch):
        """COREIQ_ENV unset should default to dev, not production."""
        monkeypatch.delenv("COREIQ_AUDIT_HMAC_KEY", raising=False)
        monkeypatch.delenv("COREIQ_AUDIT_FAIL_OPEN", raising=False)
        monkeypatch.delenv("COREIQ_ENV", raising=False)
        from coreiq.governance.chained_audit import _get_hmac_key
        key = _get_hmac_key()
        assert key.startswith(b"coreiq-audit-dev-")

    def test_production_mode_without_key_raises(self, monkeypatch):
        monkeypatch.delenv("COREIQ_AUDIT_HMAC_KEY", raising=False)
        monkeypatch.delenv("COREIQ_AUDIT_FAIL_OPEN", raising=False)
        monkeypatch.setenv("COREIQ_ENV", "production")
        from coreiq.governance.chained_audit import _get_hmac_key
        with pytest.raises((RuntimeError, Exception), match="COREIQ_AUDIT_HMAC_KEY is required"):
            _get_hmac_key()

    def test_production_fail_open_bypass(self, monkeypatch):
        """Backward-compat: old COREIQ_AUDIT_FAIL_OPEN=true still works."""
        monkeypatch.delenv("COREIQ_AUDIT_HMAC_KEY", raising=False)
        monkeypatch.setenv("COREIQ_AUDIT_FAIL_OPEN", "true")
        monkeypatch.setenv("COREIQ_ENV", "production")
        from coreiq.governance.chained_audit import _get_hmac_key
        key = _get_hmac_key()
        # Even in production mode, the explicit fail-open flag generates
        # a dev-style marker key rather than raising.
        assert key.startswith(b"coreiq-audit-dev-")

    def test_ephemeral_keys_differ_across_calls(self, monkeypatch):
        """Each call to _get_hmac_key in dev mode should mint a fresh
        marker key so different test runs don't collide."""
        monkeypatch.delenv("COREIQ_AUDIT_HMAC_KEY", raising=False)
        monkeypatch.setenv("COREIQ_ENV", "development")
        from coreiq.governance.chained_audit import _get_hmac_key
        k1 = _get_hmac_key()
        k2 = _get_hmac_key()
        assert k1 != k2
