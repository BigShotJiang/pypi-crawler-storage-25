"""Tests for FastAPI routes using TestClient."""
import pytest
import uuid
from fastapi.testclient import TestClient

from coreiq.server.app import app
from coreiq.store.writer import EventWriter


@pytest.fixture(autouse=True)
def _patch_db(tmp_path, monkeypatch):
    """Redirect DB to a temp file for all tests in this module."""
    db_path = tmp_path / "test.db"
    monkeypatch.setenv("COREIQ_DB_PATH", str(db_path))
    monkeypatch.setenv("COREIQ_AUTH_MODE", "disabled")
    # Reset singletons so they pick up the new path
    import coreiq.store.writer as w
    import coreiq.store.db as d
    w._writer = None
    d._shared_conn = None
    d._shared_conn_path = None
    yield
    w._writer = None
    d._shared_conn = None
    d._shared_conn_path = None


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture
def writer():
    import os
    from pathlib import Path
    db_path = Path(os.environ["COREIQ_DB_PATH"])
    return EventWriter(db_path=db_path)


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_auth_disabled_allows_api_even_with_api_key(client, monkeypatch):
    # Regression guard: disabled auth mode must always bypass /api auth checks.
    monkeypatch.setenv("COREIQ_API_KEY", "sk-coreiq-test")
    r = client.get("/api/overview")
    assert r.status_code == 200


def test_overview_empty(client):
    r = client.get("/api/overview")
    assert r.status_code == 200
    data = r.json()
    assert data["total_requests"] == 0
    assert data["cache_hit_rate"] == 0


def test_list_traces_empty(client):
    r = client.get("/api/traces")
    assert r.status_code == 200
    assert r.json() == []


def test_list_traces_with_data(client, writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="gpt-4o", provider="openai",
        input_tok=100, output_tok=50, latency_ms=300, finish_reason="stop",
    )
    r = client.get("/api/traces")
    assert r.status_code == 200
    assert len(r.json()) == 1
    assert r.json()[0]["id"] == tid


def test_list_traces_finish_reason_filter(client, writer):
    for reason in ["stop", "stop", "error"]:
        writer.insert_trace(
            id=str(uuid.uuid4()), model="gpt-4o", provider="openai",
            input_tok=10, output_tok=5, latency_ms=100, finish_reason=reason,
        )
    r = client.get("/api/traces?finish_reason=error")
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 1
    assert rows[0]["finish_reason"] == "error"


def test_get_trace_not_found(client):
    r = client.get("/api/traces/nonexistent-id")
    assert r.status_code == 404


def test_get_trace_found(client, writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="claude-sonnet-4-6", provider="anthropic",
        input_tok=200, output_tok=80, latency_ms=600,
    )
    r = client.get(f"/api/traces/{tid}")
    assert r.status_code == 200
    assert r.json()["id"] == tid
    assert "tool_calls" in r.json()
    assert "feedback" in r.json()


def test_create_feedback_valid(client, writer):
    tid = str(uuid.uuid4())
    writer.insert_trace(
        id=tid, model="gpt-4o", provider="openai",
        input_tok=10, output_tok=5, latency_ms=100,
    )
    r = client.post("/api/feedback", json={
        "response_id": tid,
        "signal": "thumbs_up",
        "value": 1.0,
    })
    assert r.status_code == 201
    assert r.json()["ok"] is True


def test_create_feedback_invalid_signal(client):
    r = client.post("/api/feedback", json={
        "response_id": "some-id",
        "signal": "not_a_real_signal",
    })
    assert r.status_code == 422


def test_create_feedback_empty_response_id(client):
    r = client.post("/api/feedback", json={
        "response_id": "   ",
        "signal": "thumbs_up",
    })
    assert r.status_code == 422


def test_feedback_summary(client, writer):
    rid = str(uuid.uuid4())
    writer.insert_feedback(response_id=rid, signal="thumbs_up", value=1.0)
    writer.insert_feedback(response_id=rid, signal="thumbs_down", value=0.0)
    r = client.get("/api/feedback/summary")
    assert r.status_code == 200
    data = r.json()
    assert data["thumbs_up"] == 1
    assert data["thumbs_down"] == 1


def test_events_list_empty(client):
    r = client.get("/api/events")
    assert r.status_code == 200
    assert r.json() == []


def test_events_list_with_data(client, writer):
    writer.insert_event(message="Test event", level="info", source="tests")
    r = client.get("/api/events")
    assert r.status_code == 200
    assert len(r.json()) >= 1


def test_events_summary(client, writer):
    writer.insert_event(message="info event", level="info")
    writer.insert_event(message="error event", level="error")
    r = client.get("/api/events/summary")
    assert r.status_code == 200
    data = r.json()
    assert data["total"] >= 2
    assert "by_level" in data
