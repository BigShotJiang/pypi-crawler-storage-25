"""Integration tests for Features 11-17 (Tier 3)."""
import os

DEFAULT_MODEL = os.environ.get("OPENAI_COMPATIBLE_DEFAULT_MODEL", "openai/gpt-oss-120b")


class TestWatermarking:
    def test_embed_and_detect(self):
        from coreiq.security.watermark import TextWatermarker
        wm = TextWatermarker()
        # Use many synonym-eligible words to ensure at least one substitution
        text = "This is also very important however it should begin fast and help show big things also"
        result = wm.embed(text, "req-test-watermark")
        # The watermark may or may not substitute depending on hash — test the mechanism
        assert result.watermark_key  # key is always generated
        det = wm.detect(result.watermarked_text, "req-test-watermark")
        # Detection should find synonym candidates
        assert det.total_candidates >= 0

    def test_no_watermark_in_clean(self):
        from coreiq.security.watermark import TextWatermarker
        wm = TextWatermarker()
        det = wm.detect("This is a completely clean normal text", "req-1")
        assert not det.is_watermarked


class TestMultiModalGuard:
    def test_clean_messages(self):
        from coreiq.security.multimodal_guard import MultiModalGuard
        guard = MultiModalGuard()
        r = guard.scan_messages([{"role": "user", "content": "Hello"}])
        assert r.clean

    def test_blocked_domain(self):
        from coreiq.security.multimodal_guard import MultiModalGuard
        guard = MultiModalGuard()
        r = guard.scan_messages([{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": "https://nsfw-site.com/image.jpg"}}
        ]}])
        assert not r.clean
        assert any(v.rule == "blocked_domain" for v in r.violations)

    def test_data_uri_size(self):
        from coreiq.security.multimodal_guard import MultiModalGuard
        guard = MultiModalGuard(max_data_uri_size=100)
        big_data = "data:image/png;base64," + "A" * 200
        r = guard.scan_messages([{"role": "user", "content": [
            {"type": "image_url", "image_url": {"url": big_data}}
        ]}])
        assert not r.clean


class TestContextOptimizer:
    def test_whitespace_removal(self):
        from coreiq.performance.context_optimizer import ContextOptimizer
        opt = ContextOptimizer()
        messages = [{"role": "user", "content": "Hello    world   how    are    you"}]
        r = opt.optimize(messages)
        assert r.tokens_saved > 0
        assert "whitespace_removal" in r.techniques_applied

    def test_long_message_truncation(self):
        from coreiq.performance.context_optimizer import ContextOptimizer
        opt = ContextOptimizer()
        messages = [{"role": "user", "content": "word " * 600}]
        r = opt.optimize(messages)
        assert "long_message_truncation" in r.techniques_applied
        assert r.tokens_saved > 0


class TestBiasMonitor:
    def test_no_bias(self):
        from coreiq.governance.bias_monitor import BiasMonitor
        m = BiasMonitor()
        r = m.analyze(["The weather is sunny today", "I like programming"])
        assert not r.bias_detected

    def test_detects_gender_bias(self):
        from coreiq.governance.bias_monitor import BiasMonitor
        m = BiasMonitor()
        r = m.analyze([
            "He is an excellent qualified strong candidate for the job",
            "She is a poor unqualified weak candidate for the job",
        ])
        assert r.bias_detected
        assert r.fairness_score < 1.0
        assert any("gender" in rec for rec in r.recommendations)

    def test_demographic_detection(self):
        from coreiq.governance.bias_monitor import BiasMonitor
        m = BiasMonitor()
        r = m.analyze(["The man was qualified", "The woman was qualified"])
        assert len(r.indicators) >= 2


class TestComplianceAuto:
    def test_soc2_generation(self):
        from coreiq.governance.compliance_auto import ComplianceAutoGenerator
        from coreiq.governance.frameworks.cache import compute_all
        gen = ComplianceAutoGenerator()
        compute_all(tenant_id="default", force=True)
        pkg = gen.generate("soc2")
        assert pkg.framework == "soc2"
        assert len(pkg.items) >= 3
        assert pkg.summary["met"] > 0

    def test_eu_ai_act(self):
        from coreiq.governance.compliance_auto import ComplianceAutoGenerator
        from coreiq.governance.frameworks.cache import compute_all
        gen = ComplianceAutoGenerator()
        compute_all(tenant_id="default", force=True)
        pkg = gen.generate("eu_ai_act")
        assert pkg.framework == "eu_ai_act"
        assert len(pkg.items) >= 3

    def test_gdpr(self):
        from coreiq.governance.compliance_auto import ComplianceAutoGenerator
        gen = ComplianceAutoGenerator()
        pkg = gen.generate("gdpr")
        assert len(pkg.items) >= 3


class TestFederatedAnalytics:
    def test_privacy_threshold(self):
        from coreiq.analytics.federated import FederatedAnalytics
        fa = FederatedAnalytics(min_tenants=3)
        fa.submit("t1", "injection_rate", 0.05)
        fa.submit("t2", "injection_rate", 0.03)
        # Only 2 tenants — should not be queryable
        assert fa.query("injection_rate") is None

    def test_aggregation(self):
        from coreiq.analytics.federated import FederatedAnalytics
        fa = FederatedAnalytics(min_tenants=3)
        fa.submit("t1", "injection_rate", 0.05)
        fa.submit("t2", "injection_rate", 0.03)
        fa.submit("t3", "injection_rate", 0.07)
        result = fa.query("injection_rate")
        assert result is not None
        assert result.tenant_count == 3
        assert abs(result.aggregate - 0.05) < 0.01


class TestModelFingerprint:
    def test_add_samples_and_verify(self):
        from coreiq.proxy.model_fingerprint import ModelFingerprinter
        fp = ModelFingerprinter()
        for i in range(5):
            fp.add_sample(DEFAULT_MODEL, f"This is a comprehensive and detailed response number {i} with sophisticated vocabulary and nuanced understanding. The analysis demonstrates depth.")
        for i in range(5):
            fp.add_sample("claude-haiku-4-5-20251001", f"Answer {i}. Short. Done.")
        r = fp.verify(DEFAULT_MODEL, "This is a comprehensive and detailed response with sophisticated analysis and nuanced vocabulary. The depth is clear.")
        assert r.claimed_model == DEFAULT_MODEL
        # Profile exists with enough samples
        profiles = fp.get_profiles()
        assert len(profiles) == 2

    def test_insufficient_samples(self):
        from coreiq.proxy.model_fingerprint import ModelFingerprinter
        fp = ModelFingerprinter()
        fp.add_sample(DEFAULT_MODEL, "Hello")
        r = fp.verify(DEFAULT_MODEL, "test response")
        assert r.confidence == 0.5  # low confidence with insufficient data
