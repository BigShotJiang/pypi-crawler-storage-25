"""Tests for models module."""
import pytest

from coreiq.models.registry import get_model, list_models, register_model, ModelSpec
from coreiq.models.selector import SelectionCriteria, select_model
from coreiq.models.shadow import _text_similarity


# ── Registry ──────────────────────────────────────────────────────────────────

def test_get_known_model():
    m = get_model("gpt-4o")
    assert m is not None
    assert m.provider == "openai"
    assert m.supports_vision is True


def test_get_unknown_model():
    assert get_model("nonexistent-model-xyz") is None


def test_list_models_all():
    models = list_models()
    assert len(models) > 0


def test_list_models_by_provider():
    openai_models = list_models(provider="openai")
    assert all(m.provider == "openai" for m in openai_models)
    assert len(openai_models) > 0


def test_list_models_by_tag():
    cheap = list_models(tag="cheap")
    assert all("cheap" in m.tags for m in cheap)


def test_register_custom_model():
    spec = ModelSpec(
        id="my-custom-model", provider="custom", context_window=8192,
        input_cost_per_1k=0.001, output_cost_per_1k=0.002,
    )
    register_model(spec)
    assert get_model("my-custom-model") is not None


def test_estimate_cost():
    m = get_model("gpt-4o")
    cost = m.estimate_cost(1000, 500)
    assert cost == pytest.approx(0.005 * 1 + 0.015 * 0.5)


# ── Selector ──────────────────────────────────────────────────────────────────

def test_select_cheapest():
    criteria = SelectionCriteria(preferred_tags=["cheap"])
    model = select_model(criteria)
    assert model is not None
    assert "cheap" in model.tags


def test_select_vision():
    criteria = SelectionCriteria(requires_vision=True)
    model = select_model(criteria)
    assert model is not None
    assert model.supports_vision is True


def test_select_no_match_returns_none():
    criteria = SelectionCriteria(
        max_cost_per_1k_input=0.0000001,  # impossibly cheap
    )
    assert select_model(criteria) is None


def test_select_by_provider():
    criteria = SelectionCriteria(preferred_provider="anthropic")
    model = select_model(criteria)
    assert model is not None
    assert model.provider == "anthropic"


# ── Shadow mode ───────────────────────────────────────────────────────────────

def test_text_similarity_identical():
    assert _text_similarity("hello world", "hello world") == pytest.approx(1.0)


def test_text_similarity_disjoint():
    assert _text_similarity("hello world", "foo bar baz") == pytest.approx(0.0)


def test_text_similarity_partial():
    sim = _text_similarity("hello world foo", "hello world bar")
    assert 0 < sim < 1.0


def test_text_similarity_empty():
    assert _text_similarity("", "") == pytest.approx(1.0)
