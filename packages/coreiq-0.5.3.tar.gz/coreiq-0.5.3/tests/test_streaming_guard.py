"""Tests for Streaming Guardrails — token-by-token scanning with cutoff."""
import asyncio
import os
import pytest

os.environ.setdefault("COREIQ_STORE_BACKEND", "sqlite")

from coreiq.security.streaming_guard import (
    StreamingGuard,
    StreamGuardRule,
    ViolationType,
    DEFAULT_STREAM_RULES,
    CUTOFF_MESSAGE,
)


# ── Helpers ──────────────────────────────────────────────────────────────────

async def _collect(async_iter):
    results = []
    async for item in async_iter:
        results.append(item)
    return results


async def _token_stream(tokens):
    for t in tokens:
        yield {"text": t}


# ── Scan Complete Text ───────────────────────────────────────────────────────

class TestScanCompleteText:
    def test_clean_text(self):
        guard = StreamingGuard()
        result = guard.scan_complete_text("Hello, how can I help you today?")
        assert result.clean
        assert len(result.violations) == 0

    def test_detects_credential(self):
        guard = StreamingGuard()
        result = guard.scan_complete_text("The password=SuperSecret123456")
        assert not result.clean
        assert any(v.type == ViolationType.credential_leak for v in result.violations)

    def test_detects_api_key(self):
        guard = StreamingGuard()
        result = guard.scan_complete_text("Use this key: sk-abcdefghijklmnopqrstuvwxyz123456")
        assert not result.clean
        assert any(v.rule_name == "api_key_leak" for v in result.violations)

    def test_detects_ssn(self):
        guard = StreamingGuard()
        result = guard.scan_complete_text("SSN: 123-45-6789")
        assert not result.clean
        assert any(v.type == ViolationType.pii_leak for v in result.violations)

    def test_detects_sql_injection(self):
        guard = StreamingGuard()
        result = guard.scan_complete_text("DROP TABLE users; DELETE FROM accounts WHERE 1=1")
        assert not result.clean

    def test_detects_system_path(self):
        guard = StreamingGuard()
        result = guard.scan_complete_text("Check /etc/passwd for user info")
        assert not result.clean

    def test_custom_rules(self):
        rules = [StreamGuardRule(
            name="no_competitor",
            pattern=r"competitor_product_name",
            type=ViolationType.custom_rule,
            description="Mentioning competitor",
        )]
        guard = StreamingGuard(rules=rules)
        result = guard.scan_complete_text("You should try competitor_product_name instead")
        assert not result.clean
        assert result.violations[0].rule_name == "no_competitor"


# ── Streaming Filter ────────────────────────────────────────────────────────

class TestStreamingFilter:
    def test_clean_stream_passes_through(self):
        guard = StreamingGuard(check_interval=1)
        tokens = ["Hello", " world", "!"]

        async def run():
            chunks = []
            async for chunk in guard.filter_stream(_token_stream(tokens)):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        texts = [c.get("text", "") if isinstance(c, dict) else "" for c in result]
        assert "".join(texts) == "Hello world!"

    def test_cuts_off_on_credential_leak(self):
        guard = StreamingGuard(check_interval=1)
        tokens = ["The ", "password=", "SuperSecret12345678", " and more"]

        async def run():
            chunks = []
            async for chunk in guard.filter_stream(_token_stream(tokens)):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        # Should have been cut off
        has_cutoff = any(
            isinstance(c, dict) and c.get("is_cutoff")
            for c in result
        )
        assert has_cutoff

    def test_cuts_off_on_api_key(self):
        guard = StreamingGuard(check_interval=1)
        tokens = ["Here is ", "your key: ", "sk-", "abcdefghijklmnopqrstuvwxyz"]

        async def run():
            chunks = []
            async for chunk in guard.filter_stream(_token_stream(tokens)):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        has_cutoff = any(isinstance(c, dict) and c.get("is_cutoff") for c in result)
        assert has_cutoff

    def test_cutoff_contains_violation_info(self):
        guard = StreamingGuard(check_interval=1)
        tokens = ["SSN: ", "123-", "45-", "6789"]

        async def run():
            chunks = []
            async for chunk in guard.filter_stream(_token_stream(tokens)):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        cutoff = next((c for c in result if isinstance(c, dict) and c.get("is_cutoff")), None)
        assert cutoff is not None
        assert "violation" in cutoff
        assert cutoff["violation"]["rule_name"] == "ssn_leak"

    def test_violation_callback(self):
        violations_seen = []
        guard = StreamingGuard(
            check_interval=1,
            on_violation=lambda v: violations_seen.append(v),
        )
        tokens = ["api_key=", "my_secret_key_12345678"]

        async def run():
            async for _ in guard.filter_stream(_token_stream(tokens)):
                pass

        asyncio.run(run())
        assert len(violations_seen) > 0

    def test_check_interval_respected(self):
        guard = StreamingGuard(check_interval=5)
        # With check_interval=5, first check at token 5
        tokens = ["a"] * 4 + ["sk-abcdefghijklmnopqrstuvwxyz"] + ["b"] * 5

        async def run():
            chunks = []
            async for chunk in guard.filter_stream(_token_stream(tokens)):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        has_cutoff = any(isinstance(c, dict) and c.get("is_cutoff") for c in result)
        assert has_cutoff

    def test_sliding_window_limits_memory(self):
        guard = StreamingGuard(window_size=50, check_interval=1)
        # Send lots of clean tokens, then a violation
        tokens = ["clean "] * 20 + ["password=SecretValue123"]

        async def run():
            chunks = []
            async for chunk in guard.filter_stream(_token_stream(tokens)):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        has_cutoff = any(isinstance(c, dict) and c.get("is_cutoff") for c in result)
        assert has_cutoff


# ── Default Rules ────────────────────────────────────────────────────────────

class TestDefaultRules:
    def test_default_rules_exist(self):
        assert len(DEFAULT_STREAM_RULES) >= 5

    def test_all_rules_compile(self):
        for rule in DEFAULT_STREAM_RULES:
            assert rule.compiled is not None

    def test_cutoff_message(self):
        assert "blocked" in CUTOFF_MESSAGE.lower()
        assert "violation" in CUTOFF_MESSAGE.lower()


# ── Integration with FastAPI ─────────────────────────────────────────────────

class TestFastAPIIntegration:
    @pytest.fixture(autouse=True)
    def _isolated_db(self, tmp_path, monkeypatch):
        db_file = tmp_path / "test_sg.db"
        monkeypatch.setenv("COREIQ_DB_PATH", str(db_file))
        from coreiq.store import db as db_mod
        if hasattr(db_mod._thread_local, 'conn'):
            db_mod._thread_local.conn = None
        if hasattr(db_mod._thread_local, 'conn_path'):
            db_mod._thread_local.conn_path = None
        from coreiq.store.db import create_connection, init_schema
        conn = create_connection()
        init_schema(conn)

    def test_scan_endpoint_via_guard(self):
        guard = StreamingGuard()
        result = guard.scan_complete_text("The password=MySecret12345678")
        assert not result.clean
        d = result.to_dict()
        assert d["clean"] is False
        assert len(d["violations"]) > 0

    def test_simulate_stream_cutoff(self):
        guard = StreamingGuard(check_interval=1)
        tokens = ["Normal ", "text ", "password=", "hunter2_secret_"]

        async def run():
            chunks = []
            async for chunk in guard.filter_stream(_token_stream(tokens)):
                chunks.append(chunk)
            return chunks

        result = asyncio.run(run())
        output = "".join(
            c.get("text", "") if isinstance(c, dict) else ""
            for c in result
        )
        assert "[Response blocked" in output
