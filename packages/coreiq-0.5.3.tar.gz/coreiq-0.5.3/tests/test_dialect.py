"""Unit tests for the SQL dialect translator (coreiq.store.dialect).

These tests are dialect-only — they don't spin up any actual backend. The
goal is to lock down the translation rules so a regression in the regex
or the TABLES registry gets caught before it breaks Postgres/ClickHouse
callers downstream.
"""
from __future__ import annotations

import pytest

from coreiq.store import dialect


# ---------------------------------------------------------------------------
# SQLite (passthrough)
# ---------------------------------------------------------------------------

class TestSqlitePassthrough:
    def test_plain_select(self):
        sql = "SELECT * FROM traces WHERE id = ?"
        assert dialect.to_sqlite(sql) == sql

    def test_insert_or_replace_unchanged(self):
        sql = "INSERT OR REPLACE INTO traces(id, model) VALUES (?, ?)"
        assert dialect.to_sqlite(sql) == sql


# ---------------------------------------------------------------------------
# Postgres
# ---------------------------------------------------------------------------

class TestPostgresUpserts:
    def test_placeholder_translation(self):
        sql = "SELECT * FROM traces WHERE id = ? AND ts > ?"
        assert dialect.to_postgres(sql) == (
            "SELECT * FROM traces WHERE id = %s AND ts > %s"
        )

    def test_insert_or_replace_with_columns_becomes_do_update(self):
        sql = "INSERT OR REPLACE INTO traces(id, model, provider) VALUES (?, ?, ?)"
        out = dialect.to_postgres(sql)
        assert out.startswith("INSERT INTO traces(id, model, provider)")
        assert "ON CONFLICT (id) DO UPDATE SET" in out
        assert "model = EXCLUDED.model" in out
        assert "provider = EXCLUDED.provider" in out

    def test_insert_or_replace_positional_becomes_do_nothing(self):
        sql = "INSERT OR REPLACE INTO cache_events VALUES (?,?,?,?,?,?,?)"
        out = dialect.to_postgres(sql)
        # No column list → we don't know which cols to SET → DO NOTHING
        assert "ON CONFLICT (id) DO NOTHING" in out

    def test_insert_or_replace_unknown_table_safe_fallback(self):
        sql = "INSERT OR REPLACE INTO unknown_table(a, b) VALUES (?, ?)"
        out = dialect.to_postgres(sql)
        assert "ON CONFLICT DO NOTHING" in out

    def test_insert_or_ignore_becomes_do_nothing(self):
        sql = "INSERT OR IGNORE INTO revoked_tokens (id, token_id) VALUES (?, ?)"
        out = dialect.to_postgres(sql)
        assert out.startswith("INSERT INTO revoked_tokens")
        assert "ON CONFLICT DO NOTHING" in out

    def test_composite_pk_upsert(self):
        # span_hierarchy uses trace_id as its sole PK
        sql = (
            "INSERT OR REPLACE INTO span_hierarchy"
            "(trace_id, span_kind, parent_span_id, agent_run_id, session_id, attributes_json, ts)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)"
        )
        out = dialect.to_postgres(sql)
        assert "ON CONFLICT (trace_id) DO UPDATE SET" in out
        assert "trace_id = EXCLUDED.trace_id" not in out  # PK excluded from SET


# ---------------------------------------------------------------------------
# ClickHouse
# ---------------------------------------------------------------------------

class TestClickHouseDDL:
    def test_create_table_append_only_uses_mergetree(self):
        sql = """CREATE TABLE IF NOT EXISTS traces (
            id          TEXT PRIMARY KEY,
            model       TEXT,
            provider    TEXT,
            ts          TEXT,
            cache_hit   INTEGER DEFAULT 0
        )"""
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_DDL
        assert "ENGINE = MergeTree" in out
        assert "ORDER BY (ts, id)" in out
        # Types translated
        assert "id String" in out
        assert "Nullable(String)" in out  # nullable columns wrapped
        assert "cache_hit Int64 DEFAULT 0" in out

    def test_create_table_mutable_uses_replacing_mergetree(self):
        sql = """CREATE TABLE IF NOT EXISTS bandit_state (
            variant_id  TEXT PRIMARY KEY,
            alpha       REAL DEFAULT 1.0,
            beta        REAL DEFAULT 1.0,
            updated_at  TEXT
        )"""
        out, _ = dialect.to_clickhouse(sql)
        # ReplacingMergeTree is parameterless: our version columns are ISO-8601
        # TEXT, which ClickHouse rejects as a version type (must be numeric or
        # datetime). The parameterless form dedupes by insertion order, which
        # is correct for our single-writer workload.
        assert "ENGINE = ReplacingMergeTree" in out
        assert "ReplacingMergeTree(" not in out
        assert "ORDER BY variant_id" in out
        assert "alpha Float64 DEFAULT 1.0" in out

    def test_create_table_strips_references(self):
        sql = """CREATE TABLE IF NOT EXISTS cache_events (
            id          TEXT PRIMARY KEY,
            trace_id    TEXT REFERENCES traces(id),
            hit         INTEGER,
            ts          TEXT
        )"""
        out, _ = dialect.to_clickhouse(sql)
        assert "REFERENCES" not in out

    def test_create_table_strips_unique_constraint(self):
        sql = """CREATE TABLE IF NOT EXISTS users (
            id          TEXT PRIMARY KEY,
            tenant_id   TEXT NOT NULL,
            email       TEXT NOT NULL,
            created_at  TEXT,
            UNIQUE(tenant_id, email)
        )"""
        out, _ = dialect.to_clickhouse(sql)
        assert "UNIQUE" not in out

    def test_create_index_on_sort_key_is_dropped(self):
        # traces sort key is (ts, id); indexing ts is redundant.
        sql = "CREATE INDEX IF NOT EXISTS idx_traces_ts ON traces(ts)"
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_SKIP
        assert out == ""

    def test_create_index_non_sort_key_becomes_bloom(self):
        sql = "CREATE INDEX IF NOT EXISTS idx_traces_provider ON traces(provider)"
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_DDL
        assert "ADD INDEX IF NOT EXISTS idx_traces_provider" in out
        assert "TYPE bloom_filter" in out

    def test_alter_add_column_is_idempotent(self):
        sql = "ALTER TABLE traces ADD COLUMN tenant_id TEXT"
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_DDL
        assert "ADD COLUMN IF NOT EXISTS tenant_id Nullable(String)" in out

    def test_alter_add_column_with_default_is_not_null(self):
        sql = "ALTER TABLE traces ADD COLUMN cache_hit INTEGER DEFAULT 0"
        out, _ = dialect.to_clickhouse(sql)
        assert "Int64" in out  # DEFAULT makes it non-nullable
        assert "Nullable" not in out
        assert "DEFAULT 0" in out


class TestClickHouseSelects:
    def test_select_on_mutable_table_gets_final(self):
        sql = "SELECT * FROM bandit_state WHERE variant_id = ?"
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_SELECT
        assert "FROM bandit_state FINAL" in out

    def test_select_on_append_table_no_final(self):
        sql = "SELECT * FROM traces WHERE id = ?"
        out, _ = dialect.to_clickhouse(sql)
        assert "FINAL" not in out

    def test_select_with_join_is_left_alone(self):
        # Joins are tricky; the translator only rewrites simple FROM clauses.
        sql = "SELECT * FROM bandit_state JOIN variants ON bandit_state.variant_id = variants.id"
        out, _ = dialect.to_clickhouse(sql)
        # Must not insert FINAL between table name and JOIN
        assert "bandit_state FINAL JOIN" not in out


class TestClickHouseInserts:
    def test_insert_or_replace_becomes_plain_insert(self):
        sql = "INSERT OR REPLACE INTO bandit_state(variant_id, alpha, beta, updated_at) VALUES(?,?,?,?)"
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_INSERT
        assert out.startswith("INSERT INTO bandit_state")
        assert "OR REPLACE" not in out

    def test_insert_or_ignore_becomes_plain_insert(self):
        sql = "INSERT OR IGNORE INTO revoked_tokens (id, token_id) VALUES (?, ?)"
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_INSERT
        assert "OR IGNORE" not in out


# ---------------------------------------------------------------------------
# Postgres — SQLite function translations
# ---------------------------------------------------------------------------

class TestPostgresFunctionTranslations:
    def test_datetime_now_days(self):
        sql = "SELECT * FROM cache_events WHERE ts >= datetime('now', '-7 days')"
        out = dialect.to_postgres(sql)
        assert "datetime(" not in out
        assert "(NOW() - INTERVAL '7 days')" in out

    def test_datetime_now_hours(self):
        sql = "SELECT * FROM traces WHERE ts >= datetime('now', '-24 hours')"
        out = dialect.to_postgres(sql)
        assert "datetime(" not in out
        assert "(NOW() - INTERVAL '24 hours')" in out

    def test_datetime_now_multiple_occurrences(self):
        sql = (
            "SELECT * FROM cache_events "
            "WHERE ts >= datetime('now', '-14 days') AND ts < datetime('now', '-7 days')"
        )
        out = dialect.to_postgres(sql)
        assert "datetime(" not in out
        assert "(NOW() - INTERVAL '14 days')" in out
        assert "(NOW() - INTERVAL '7 days')" in out

    def test_datetime_now_param_hours(self):
        sql = "SELECT * FROM eval_scores WHERE ts > datetime('now', ?||' hours')"
        out = dialect.to_postgres(sql)
        assert "datetime(" not in out
        # ? becomes %s after placeholder rewrite; the interval cast must be present
        assert "interval" in out.lower()

    def test_strftime_hour(self):
        sql = "SELECT strftime('%Y-%m-%dT%H:00:00', ts) as hour FROM eval_scores"
        out = dialect.to_postgres(sql)
        assert "strftime(" not in out
        assert "to_char(" in out
        assert "HH24:00:00" in out

    def test_strftime_date(self):
        sql = "SELECT strftime('%Y-%m-%d', ts) as day FROM traces"
        out = dialect.to_postgres(sql)
        assert "strftime(" not in out
        assert "to_char(" in out
        assert "YYYY-MM-DD" in out

    def test_strftime_month(self):
        sql = "SELECT strftime('%Y-%m', ts) as month FROM traces"
        out = dialect.to_postgres(sql)
        assert "strftime(" not in out
        assert "to_char(" in out
        assert "YYYY-MM" in out

    def test_json_extract(self):
        sql = "SELECT SUM(CAST(json_extract(meta_json, '$.cost_usd') AS REAL)) FROM traces"
        out = dialect.to_postgres(sql)
        assert "json_extract(" not in out
        assert "::jsonb" in out
        assert "->>" in out
        assert "cost_usd" in out

    def test_cast_as_real(self):
        sql = "SELECT CAST(value AS REAL) FROM metrics"
        out = dialect.to_postgres(sql)
        assert "AS REAL" not in out
        assert "DOUBLE PRECISION" in out

    def test_combined_json_extract_and_cast(self):
        sql = (
            "SELECT SUM(CAST(json_extract(meta_json,'$.cost_usd') AS REAL)) as cost "
            "FROM traces"
        )
        out = dialect.to_postgres(sql)
        assert "json_extract(" not in out
        assert "CAST(" not in out or "DOUBLE PRECISION" in out
        assert "::jsonb" in out
        assert "DOUBLE PRECISION" in out

    def test_sqlite_passthrough_unchanged_by_pg(self):
        sql = "SELECT * FROM traces WHERE id = ?"
        out = dialect.to_postgres(sql)
        assert out == "SELECT * FROM traces WHERE id = %s"


# ---------------------------------------------------------------------------
# ClickHouse — SQLite function translations
# ---------------------------------------------------------------------------

class TestClickHouseFunctionTranslations:
    def test_datetime_now_days(self):
        sql = "SELECT * FROM cache_events WHERE ts >= datetime('now', '-7 days')"
        out, kind = dialect.to_clickhouse(sql)
        assert "datetime(" not in out
        assert "(now() - INTERVAL 7 DAY)" in out
        assert kind == dialect.KIND_SELECT

    def test_datetime_now_hours(self):
        sql = "SELECT * FROM traces WHERE ts >= datetime('now', '-24 hours')"
        out, kind = dialect.to_clickhouse(sql)
        assert "datetime(" not in out
        assert "(now() - INTERVAL 24 HOUR)" in out

    def test_datetime_now_multiple_occurrences(self):
        sql = (
            "SELECT * FROM cache_events "
            "WHERE ts >= datetime('now', '-14 days') AND ts < datetime('now', '-7 days')"
        )
        out, _ = dialect.to_clickhouse(sql)
        assert "datetime(" not in out
        assert "(now() - INTERVAL 14 DAY)" in out
        assert "(now() - INTERVAL 7 DAY)" in out

    def test_datetime_now_param_hours(self):
        sql = "SELECT * FROM eval_scores WHERE ts > datetime('now', ?||' hours')"
        out, _ = dialect.to_clickhouse(sql)
        assert "datetime(" not in out
        assert "toIntervalHour" in out

    def test_strftime_hour(self):
        sql = "SELECT strftime('%Y-%m-%dT%H:00:00', ts) as hour FROM eval_scores"
        out, _ = dialect.to_clickhouse(sql)
        assert "strftime(" not in out
        assert "formatDateTime(" in out
        assert "%Y-%m-%dT%H:00:00" in out

    def test_strftime_date(self):
        sql = "SELECT strftime('%Y-%m-%d', ts) as day FROM traces"
        out, _ = dialect.to_clickhouse(sql)
        assert "strftime(" not in out
        assert "formatDateTime(" in out
        assert "%Y-%m-%d" in out

    def test_strftime_month(self):
        sql = "SELECT strftime('%Y-%m', ts) as month FROM traces"
        out, _ = dialect.to_clickhouse(sql)
        assert "strftime(" not in out
        assert "formatDateTime(" in out
        assert "%Y-%m" in out

    def test_json_extract(self):
        sql = "SELECT SUM(CAST(json_extract(meta_json, '$.cost_usd') AS REAL)) FROM traces"
        out, _ = dialect.to_clickhouse(sql)
        assert "json_extract(" not in out
        assert "JSONExtractString(" in out
        assert "cost_usd" in out

    def test_cast_as_real(self):
        sql = "SELECT CAST(value AS REAL) FROM metrics"
        out, _ = dialect.to_clickhouse(sql)
        assert "AS REAL" not in out
        assert "toFloat64(" in out

    def test_combined_json_extract_and_cast(self):
        sql = (
            "SELECT SUM(CAST(json_extract(meta_json,'$.cost_usd') AS REAL)) as cost "
            "FROM traces"
        )
        out, _ = dialect.to_clickhouse(sql)
        assert "json_extract(" not in out
        assert "JSONExtractString(" in out
        assert "toFloat64(" in out

    def test_sqlite_passthrough_unchanged_by_ch(self):
        # Plain SELECT with no SQLite functions should not be mangled
        sql = "SELECT * FROM traces WHERE id = ?"
        out, _ = dialect.to_clickhouse(sql)
        assert "datetime(" not in out
        assert "json_extract(" not in out

    def test_ddl_not_rewritten(self):
        # DDL statements (CREATE TABLE) must NOT have function rewrites applied
        sql = """CREATE TABLE IF NOT EXISTS traces (
            id TEXT PRIMARY KEY,
            ts TEXT
        )"""
        out, kind = dialect.to_clickhouse(sql)
        assert kind == dialect.KIND_DDL
        # Function rewriter should not have touched DDL
        assert "toFloat64" not in out
        assert "JSONExtractString" not in out


# ---------------------------------------------------------------------------
# Registry sanity checks
# ---------------------------------------------------------------------------

class TestTablesRegistry:
    def test_every_mutable_has_version(self):
        for name, meta in dialect.TABLES.items():
            if meta.get("engine") == "ReplacingMergeTree":
                assert "version" in meta, f"{name} missing version column"

    def test_is_mutable_table_matches_registry(self):
        assert dialect.is_mutable_table("bandit_state")
        assert not dialect.is_mutable_table("traces")
        assert not dialect.is_mutable_table("unknown_table")

    @pytest.mark.parametrize("table", [
        "traces", "inferences", "bandit_state", "optimiser_config",
        "functions", "variants", "feedback", "events",
    ])
    def test_core_tables_registered(self, table):
        assert table in dialect.TABLES
