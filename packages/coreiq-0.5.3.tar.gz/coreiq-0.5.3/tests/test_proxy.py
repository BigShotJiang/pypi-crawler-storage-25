"""Comprehensive tests for the CoreIQ proxy module.

Covers providers, streaming, cost calculation, pipeline, and gateway.
All tests are unit tests — no real network calls are made.
"""

import asyncio
import json
from typing import AsyncIterator
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Provider imports
# ---------------------------------------------------------------------------
from coreiq.proxy.providers.base import (
    GenericStreamingChunk,
    ProviderError,
    ProviderRequest,
    ProviderResponse,
)
from coreiq.proxy.providers.openai import OpenAIProvider
from coreiq.proxy.providers.anthropic import AnthropicProvider
from coreiq.proxy.providers.openai_compat import (
    OpenAICompatProvider,
    create_vllm_provider,
    create_ollama_provider,
    create_sglang_provider,
)
from coreiq.proxy.providers.registry import ProviderRegistry
from coreiq.proxy.streaming import StreamingResponseAccumulator, chunks_to_openai_sse
from coreiq.proxy.cost import CostCalculator
from coreiq.proxy.pipeline import (
    RequestPipeline,
    PipelineAuthError,
    PipelineProviderError,
)
from coreiq.proxy.gateway import (
    router as gateway_router,
    init_gateway,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_request(**overrides) -> ProviderRequest:
    """Build a minimal ProviderRequest with sensible defaults."""
    defaults = dict(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
    )
    defaults.update(overrides)
    return ProviderRequest(**defaults)


async def _collect_async_iter(aiter: AsyncIterator) -> list:
    """Drain an async iterator into a list."""
    items = []
    async for item in aiter:
        items.append(item)
    return items


# =========================================================================
# 1. OpenAI Provider Tests
# =========================================================================


class TestOpenAIProvider:
    """Unit tests for the OpenAI provider."""

    def setup_method(self):
        self.provider = OpenAIProvider(api_key="sk-test-key-123")

    def test_openai_transform_request(self):
        """Verify URL, headers, and body are correctly built."""
        req = _make_request(temperature=0.7, max_tokens=100)
        url, headers, body = self.provider.transform_request(req)

        assert url == "https://api.openai.com/v1/chat/completions"
        assert headers["Authorization"] == "Bearer sk-test-key-123"
        assert headers["Content-Type"] == "application/json"
        assert body["model"] == "gpt-4o"
        assert body["messages"] == [{"role": "user", "content": "Hello"}]
        assert body["temperature"] == 0.7
        assert body["max_tokens"] == 100

    def test_openai_transform_response(self):
        """Verify content, usage, and finish_reason are extracted correctly."""
        raw = {
            "id": "chatcmpl-abc123",
            "model": "gpt-4o",
            "choices": [
                {
                    "message": {"role": "assistant", "content": "Hi there!"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 5,
                "total_tokens": 15,
            },
        }
        resp = self.provider.transform_response(raw)

        assert resp.id == "chatcmpl-abc123"
        assert resp.model == "gpt-4o"
        assert resp.content == "Hi there!"
        assert resp.finish_reason == "stop"
        assert resp.prompt_tokens == 10
        assert resp.completion_tokens == 5
        assert resp.total_tokens == 15
        assert resp.tool_calls is None

    def test_openai_streaming_chunk(self):
        """Verify chunk parsing including finish_reason and [DONE] handling."""
        # Regular content chunk
        chunk_data = json.dumps({
            "choices": [{"delta": {"content": "Hello"}, "finish_reason": None}],
        })
        chunk = self.provider.transform_streaming_chunk(chunk_data)
        assert chunk.text == "Hello"
        assert chunk.finish_reason is None
        assert chunk.is_finished is False

        # Final chunk with finish_reason
        done_data = json.dumps({
            "choices": [{"delta": {}, "finish_reason": "stop"}],
        })
        done_chunk = self.provider.transform_streaming_chunk(done_data)
        assert done_chunk.finish_reason == "stop"
        assert done_chunk.is_finished is True

    def test_openai_streaming_chunk_with_usage(self):
        """Verify usage extraction from streaming chunks."""
        chunk_data = json.dumps({
            "choices": [{"delta": {}, "finish_reason": "stop"}],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 20,
                "total_tokens": 30,
            },
        })
        chunk = self.provider.transform_streaming_chunk(chunk_data)
        assert chunk.usage is not None
        assert chunk.usage["prompt_tokens"] == 10
        assert chunk.usage["completion_tokens"] == 20

    def test_openai_supported_params(self):
        """Verify the supported parameter list includes all expected params."""
        params = self.provider.get_supported_params("gpt-4o")
        assert "model" in params
        assert "messages" in params
        assert "temperature" in params
        assert "tools" in params
        assert "tool_choice" in params
        assert "stream_options" in params
        assert "logprobs" in params

    def test_openai_azure_url(self):
        """Verify Azure URL pattern when api_base contains 'azure'."""
        azure_provider = OpenAIProvider(
            api_key="azure-key",
            api_base="https://myinstance.openai.azure.com",
            api_version="2024-06-01",
        )
        req = _make_request(model="gpt-4o")
        url, headers, body = azure_provider.transform_request(req)

        assert "azure" in url.lower()
        assert "openai/deployments/gpt-4o/chat/completions" in url
        assert "api-version=2024-06-01" in url
        assert "api-key" in headers
        assert headers["api-key"] == "azure-key"
        # Azure body should not have "model" key
        assert "model" not in body

    def test_openai_stream_options_injected(self):
        """Verify stream_options is injected when streaming."""
        req = _make_request(stream=True)
        url, headers, body = self.provider.transform_request(req)
        assert body.get("stream_options") == {"include_usage": True}

    def test_openai_validate_environment(self):
        """Verify environment validation."""
        assert self.provider.validate_environment() is True
        no_key = OpenAIProvider(api_key="")
        assert no_key.validate_environment() is False


# =========================================================================
# 2. Anthropic Provider Tests
# =========================================================================


class TestAnthropicProvider:
    """Unit tests for the Anthropic provider."""

    def setup_method(self):
        self.provider = AnthropicProvider(api_key="sk-ant-test-key")

    def test_anthropic_system_message_extraction(self):
        """System messages should be moved to top-level 'system' param."""
        req = _make_request(
            model="claude-sonnet-4-6",
            messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "Hi"},
            ],
        )
        url, headers, body = self.provider.transform_request(req)

        assert body["system"] == "You are helpful."
        # Messages should not contain system role
        for msg in body["messages"]:
            assert msg.get("role") != "system"

    def test_anthropic_transform_request(self):
        """Verify headers (x-api-key, anthropic-version) and body structure."""
        req = _make_request(model="claude-sonnet-4-6", temperature=0.5)
        url, headers, body = self.provider.transform_request(req)

        assert url == "https://api.anthropic.com/v1/messages"
        assert headers["x-api-key"] == "sk-ant-test-key"
        assert headers["anthropic-version"] == "2023-06-01"
        assert headers["Content-Type"] == "application/json"
        assert body["model"] == "claude-sonnet-4-6"
        assert body["temperature"] == 0.5
        assert "max_tokens" in body  # Always present for Anthropic

    def test_anthropic_tool_translation(self):
        """OpenAI tool def should translate to Anthropic format."""
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "Get the weather",
                    "parameters": {
                        "type": "object",
                        "properties": {"location": {"type": "string"}},
                    },
                },
            }
        ]
        req = _make_request(model="claude-sonnet-4-6", tools=tools)
        url, headers, body = self.provider.transform_request(req)

        assert len(body["tools"]) == 1
        tool = body["tools"][0]
        assert tool["name"] == "get_weather"
        assert tool["description"] == "Get the weather"
        assert "input_schema" in tool
        assert tool["input_schema"]["type"] == "object"
        # Should NOT have OpenAI's {type: "function", function: {...}} wrapper
        assert "function" not in tool
        assert "type" not in tool  # No "type": "function" at top level

    def test_anthropic_tool_choice_translation(self):
        """OpenAI tool_choice values should map to Anthropic format."""
        # "auto" -> {"type": "auto"}
        tools = [{"type": "function", "function": {"name": "f", "description": "", "parameters": {}}}]
        req = _make_request(model="claude-sonnet-4-6", tools=tools, tool_choice="auto")
        _, _, body = self.provider.transform_request(req)
        assert body["tool_choice"] == {"type": "auto"}

        # "required" -> {"type": "any"}
        req2 = _make_request(model="claude-sonnet-4-6", tools=tools, tool_choice="required")
        _, _, body2 = self.provider.transform_request(req2)
        assert body2["tool_choice"] == {"type": "any"}

        # Specific function -> {"type": "tool", "name": "..."}
        req3 = _make_request(
            model="claude-sonnet-4-6",
            tools=tools,
            tool_choice={"type": "function", "function": {"name": "get_weather"}},
        )
        _, _, body3 = self.provider.transform_request(req3)
        assert body3["tool_choice"] == {"type": "tool", "name": "get_weather"}

    def test_anthropic_response_mapping(self):
        """Verify stop_reason -> finish_reason and content block extraction."""
        raw = {
            "id": "msg_abc123",
            "model": "claude-sonnet-4-6",
            "content": [{"type": "text", "text": "Hello!"}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        resp = self.provider.transform_response(raw)

        assert resp.id == "msg_abc123"
        assert resp.content == "Hello!"
        assert resp.finish_reason == "stop"  # end_turn -> stop
        assert resp.prompt_tokens == 10
        assert resp.completion_tokens == 5

    def test_anthropic_response_tool_use(self):
        """Verify tool_use blocks are mapped to OpenAI tool_calls format."""
        raw = {
            "id": "msg_tools",
            "model": "claude-sonnet-4-6",
            "content": [
                {"type": "tool_use", "id": "call_1", "name": "get_weather", "input": {"loc": "SF"}},
            ],
            "stop_reason": "tool_use",
            "usage": {"input_tokens": 20, "output_tokens": 10},
        }
        resp = self.provider.transform_response(raw)

        assert resp.finish_reason == "tool_calls"  # tool_use -> tool_calls
        assert resp.tool_calls is not None
        assert len(resp.tool_calls) == 1
        tc = resp.tool_calls[0]
        assert tc["id"] == "call_1"
        assert tc["type"] == "function"
        assert tc["function"]["name"] == "get_weather"
        assert json.loads(tc["function"]["arguments"]) == {"loc": "SF"}

    def test_anthropic_max_tokens_default(self):
        """Verify default max_tokens when not provided."""
        req = _make_request(model="claude-sonnet-4-6")
        # max_tokens is None by default in ProviderRequest
        _, _, body = self.provider.transform_request(req)
        assert body["max_tokens"] == 4096  # default_max_tokens

        # Custom default
        custom_provider = AnthropicProvider(api_key="k", default_max_tokens=8192)
        _, _, body2 = custom_provider.transform_request(req)
        assert body2["max_tokens"] == 8192

    def test_anthropic_tool_result_translation(self):
        """Tool role messages should become tool_result blocks with user role."""
        messages = [
            {"role": "user", "content": "What's the weather?"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "get_weather", "arguments": '{"loc": "SF"}'},
                    }
                ],
            },
            {"role": "tool", "tool_call_id": "call_1", "content": "72F and sunny"},
        ]
        req = _make_request(model="claude-sonnet-4-6", messages=messages)
        _, _, body = self.provider.transform_request(req)

        # The tool message should be converted to user role with tool_result
        tool_result_msg = None
        for msg in body["messages"]:
            if msg.get("role") == "user" and isinstance(msg.get("content"), list):
                for block in msg["content"]:
                    if block.get("type") == "tool_result":
                        tool_result_msg = block
                        break

        assert tool_result_msg is not None
        assert tool_result_msg["tool_use_id"] == "call_1"
        assert tool_result_msg["content"] == "72F and sunny"

    def test_anthropic_streaming_message_start(self):
        """Verify message_start event parsing."""
        data = json.dumps({
            "type": "message_start",
            "message": {
                "model": "claude-sonnet-4-6",
                "usage": {"input_tokens": 25, "output_tokens": 0},
            },
        })
        chunk = self.provider.transform_streaming_chunk(data)
        assert chunk.usage is not None
        assert chunk.usage["prompt_tokens"] == 25

    def test_anthropic_streaming_content_delta(self):
        """Verify content_block_delta text extraction."""
        data = json.dumps({
            "type": "content_block_delta",
            "delta": {"type": "text_delta", "text": "Hello"},
        })
        chunk = self.provider.transform_streaming_chunk(data)
        assert chunk.text == "Hello"

    def test_anthropic_streaming_message_delta(self):
        """Verify message_delta with stop_reason."""
        data = json.dumps({
            "type": "message_delta",
            "delta": {"stop_reason": "end_turn"},
            "usage": {"output_tokens": 42},
        })
        chunk = self.provider.transform_streaming_chunk(data)
        assert chunk.finish_reason == "stop"
        assert chunk.is_finished is True
        assert chunk.usage["completion_tokens"] == 42

    def test_anthropic_streaming_message_stop(self):
        """Verify message_stop event."""
        data = json.dumps({"type": "message_stop"})
        chunk = self.provider.transform_streaming_chunk(data)
        assert chunk.is_finished is True

    def test_anthropic_validate_environment(self):
        """Verify environment validation."""
        assert self.provider.validate_environment() is True
        no_key = AnthropicProvider(api_key="")
        assert no_key.validate_environment() is False


# =========================================================================
# 3. OpenAI-Compatible Provider Tests
# =========================================================================


class TestOpenAICompatProvider:
    """Unit tests for the OpenAI-compatible provider."""

    def test_openai_compat_url_construction(self):
        """base_url + /chat/completions."""
        provider = OpenAICompatProvider(base_url="http://localhost:8000/v1")
        req = _make_request()
        url, headers, body = provider.transform_request(req)
        assert url == "http://localhost:8000/v1/chat/completions"

    def test_openai_compat_trailing_slash_stripped(self):
        """Trailing slash in base_url should be stripped."""
        provider = OpenAICompatProvider(base_url="http://localhost:8000/v1/")
        req = _make_request()
        url, _, _ = provider.transform_request(req)
        assert url == "http://localhost:8000/v1/chat/completions"

    def test_openai_compat_no_api_key_required(self):
        """_requires_api_key() should return False."""
        provider = OpenAICompatProvider(base_url="http://localhost:8000/v1")
        assert provider._requires_api_key() is False

    def test_openai_compat_optional_api_key(self):
        """API key should be included in headers when provided."""
        provider = OpenAICompatProvider(base_url="http://localhost:8000/v1", api_key="my-key")
        req = _make_request()
        _, headers, _ = provider.transform_request(req)
        assert headers["Authorization"] == "Bearer my-key"

    def test_openai_compat_no_auth_header_without_key(self):
        """No Authorization header when api_key is not set."""
        provider = OpenAICompatProvider(base_url="http://localhost:8000/v1")
        req = _make_request()
        _, headers, _ = provider.transform_request(req)
        assert "Authorization" not in headers

    def test_openai_compat_custom_headers(self):
        """Custom headers should be included."""
        provider = OpenAICompatProvider(
            base_url="http://localhost:8000/v1",
            custom_headers={"X-Custom": "value"},
        )
        req = _make_request()
        _, headers, _ = provider.transform_request(req)
        assert headers["X-Custom"] == "value"

    def test_factory_vllm(self):
        """create_vllm_provider builds correct configuration."""
        provider = create_vllm_provider()
        assert provider.provider_name == "vllm"
        assert provider.base_url == "http://localhost:8000/v1"
        params = provider.get_supported_params("any-model")
        assert "tools" in params
        assert "response_format" in params

    def test_factory_ollama(self):
        """create_ollama_provider builds correct configuration."""
        provider = create_ollama_provider()
        assert provider.provider_name == "ollama"
        assert provider.base_url == "http://localhost:11434/v1"

    def test_factory_sglang(self):
        """create_sglang_provider builds correct configuration."""
        provider = create_sglang_provider()
        assert provider.provider_name == "sglang"
        assert provider.base_url == "http://localhost:30000/v1"

    def test_openai_compat_validate_environment(self):
        """Validates that base_url is set."""
        good = OpenAICompatProvider(base_url="http://localhost:8000/v1")
        assert good.validate_environment() is True


# =========================================================================
# 4. Registry Tests
# =========================================================================


class TestProviderRegistry:
    """Unit tests for the provider registry."""

    def setup_method(self):
        self.registry = ProviderRegistry()
        self.openai = OpenAIProvider(api_key="test")
        self.anthropic = AnthropicProvider(api_key="test")
        self.registry.register("openai", self.openai)
        self.registry.register("anthropic", self.anthropic)

    def test_resolve_explicit_prefix(self):
        """'openai/gpt-4o' should resolve to (OpenAI, 'gpt-4o')."""
        provider, model = self.registry.resolve("openai/gpt-4o")
        assert provider is self.openai
        assert model == "gpt-4o"

    def test_resolve_known_prefix(self):
        """'gpt-4o' should resolve to OpenAI via prefix heuristic."""
        provider, model = self.registry.resolve("gpt-4o")
        assert provider is self.openai
        assert model == "gpt-4o"

    def test_resolve_anthropic_prefix(self):
        """'claude-sonnet-4-6' should resolve to Anthropic via prefix heuristic."""
        provider, model = self.registry.resolve("claude-sonnet-4-6")
        assert provider is self.anthropic
        assert model == "claude-sonnet-4-6"

    def test_resolve_unknown_model_raises(self):
        """Unknown model without prefix should raise ProviderError."""
        with pytest.raises(ProviderError, match="Cannot determine provider"):
            self.registry.resolve("unknown-model-xyz")

    def test_resolve_unregistered_provider_raises(self):
        """Known prefix but unregistered provider should raise ProviderError."""
        with pytest.raises(ProviderError, match="not registered"):
            self.registry.resolve("gemini-2.0-flash")

    def test_register_and_list(self):
        """Register a provider and verify it appears in list_models."""
        models = self.registry.list_models()
        provider_names = [m["provider"] for m in models]
        assert "openai" in provider_names
        assert "anthropic" in provider_names
        assert len(models) == 2

    def test_register_duplicate_raises(self):
        """Registering the same name twice should raise ValueError."""
        with pytest.raises(ValueError, match="already registered"):
            self.registry.register("openai", self.openai)

    def test_replace(self):
        """replace() should overwrite without error."""
        new_openai = OpenAIProvider(api_key="new-key")
        self.registry.replace("openai", new_openai)
        provider, model = self.registry.resolve("openai/gpt-4o")
        assert provider is new_openai

    def test_model_override(self):
        """register_model_override should take precedence over prefix."""
        self.registry.register_model_override("my-custom-model", "openai")
        provider, model = self.registry.resolve("my-custom-model")
        assert provider is self.openai
        assert model == "my-custom-model"

    def test_contains_and_len(self):
        """Test __contains__ and __len__."""
        assert "openai" in self.registry
        assert "nonexistent" not in self.registry
        assert len(self.registry) == 2


# =========================================================================
# 5. Streaming Tests
# =========================================================================


class TestStreamingAccumulator:
    """Tests for StreamingResponseAccumulator."""

    def test_streaming_accumulator(self):
        """Accumulate chunks and verify the final response."""
        acc = StreamingResponseAccumulator(model="gpt-4o", request_id="req-123")

        acc.add(GenericStreamingChunk(text="Hello"))
        acc.add(GenericStreamingChunk(text=" world"))
        acc.add(GenericStreamingChunk(
            finish_reason="stop",
            is_finished=True,
            usage={"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        ))

        assert acc.content == "Hello world"
        assert acc.chunk_count == 3

        response = acc.to_response()
        assert response.id == "req-123"
        assert response.model == "gpt-4o"
        assert response.content == "Hello world"
        assert response.finish_reason == "stop"
        assert response.usage["prompt_tokens"] == 10
        assert response.usage["completion_tokens"] == 5

    def test_accumulator_tool_calls(self):
        """Verify tool call accumulation by index."""
        acc = StreamingResponseAccumulator(model="gpt-4o", request_id="req-456")

        # Tool call start
        acc.add(GenericStreamingChunk(tool_calls=[
            {"index": 0, "id": "call_1", "type": "function", "function": {"name": "search", "arguments": ""}},
        ]))
        # Arguments streamed in
        acc.add(GenericStreamingChunk(tool_calls=[
            {"index": 0, "function": {"arguments": '{"q":'}},
        ]))
        acc.add(GenericStreamingChunk(tool_calls=[
            {"index": 0, "function": {"arguments": '"test"}'}},
        ]))

        response = acc.to_response()
        assert response.tool_calls is not None
        assert len(response.tool_calls) == 1
        assert response.tool_calls[0]["id"] == "call_1"
        assert response.tool_calls[0]["function"]["name"] == "search"
        assert response.tool_calls[0]["function"]["arguments"] == '{"q":"test"}'


class TestChunksToSSE:
    """Tests for chunks_to_openai_sse."""

    def test_chunks_to_sse_format(self):
        """Verify SSE wire format: data: {json}\\n\\n."""
        async def _run():
            async def gen_chunks():
                yield GenericStreamingChunk(text="Hi")
                yield GenericStreamingChunk(text=" there", finish_reason="stop", is_finished=True)

            return await _collect_async_iter(
                chunks_to_openai_sse(gen_chunks(), model="gpt-4o", request_id="req-1", created=1234567890)
            )

        events = asyncio.run(_run())

        # Each event should start with "data: " and end with "\n\n"
        for event in events:
            assert event.startswith("data: ")
            assert event.endswith("\n\n")

        # First event should have text content
        first = json.loads(events[0][6:-2])
        assert first["choices"][0]["delta"]["content"] == "Hi"
        assert first["id"] == "req-1"
        assert first["model"] == "gpt-4o"
        assert first["object"] == "chat.completion.chunk"
        assert first["created"] == 1234567890

    def test_sse_done_signal(self):
        """Verify [DONE] is sent at end of stream."""
        async def _run():
            async def gen_chunks():
                yield GenericStreamingChunk(text="Hello", finish_reason="stop", is_finished=True)

            return await _collect_async_iter(
                chunks_to_openai_sse(gen_chunks(), model="gpt-4o", request_id="req-1")
            )

        events = asyncio.run(_run())

        # Last event should be [DONE]
        assert events[-1] == "data: [DONE]\n\n"

    def test_sse_skips_empty_deltas(self):
        """Empty chunks (no text, no tool_calls) should be skipped."""
        async def _run():
            async def gen_chunks():
                yield GenericStreamingChunk()  # empty, should be skipped
                yield GenericStreamingChunk(text="content")
                yield GenericStreamingChunk(finish_reason="stop", is_finished=True)

            return await _collect_async_iter(
                chunks_to_openai_sse(gen_chunks(), model="gpt-4o", request_id="req-1")
            )

        events = asyncio.run(_run())

        # Should have: content event, finish event, [DONE]
        data_events = [e for e in events if e != "data: [DONE]\n\n"]
        assert len(data_events) == 2  # content + finish sentinel


# =========================================================================
# 6. Cost Tests
# =========================================================================


class TestCostCalculator:
    """Tests for the cost calculator."""

    def setup_method(self):
        self.calc = CostCalculator()

    def test_known_model_cost(self):
        """gpt-4o cost calculation with known pricing."""
        result = self.calc.calculate("gpt-4o", "openai", input_tokens=1000, output_tokens=500)
        # gpt-4o: $2.50/1M input, $10.00/1M output
        expected_input = (1000 / 1_000_000) * 2.50
        expected_output = (500 / 1_000_000) * 10.00
        assert result.input_cost == pytest.approx(expected_input, abs=1e-8)
        assert result.output_cost == pytest.approx(expected_output, abs=1e-8)
        assert result.total_cost == pytest.approx(expected_input + expected_output, abs=1e-8)
        assert result.model == "gpt-4o"
        assert result.provider == "openai"

    def test_anthropic_model_cost(self):
        """claude-sonnet-4-6 cost calculation."""
        result = self.calc.calculate("claude-sonnet-4-6", "anthropic", input_tokens=2000, output_tokens=1000)
        # claude-sonnet-4-6: $3.00/1M input, $15.00/1M output
        expected_input = (2000 / 1_000_000) * 3.00
        expected_output = (1000 / 1_000_000) * 15.00
        assert result.input_cost == pytest.approx(expected_input, abs=1e-8)
        assert result.output_cost == pytest.approx(expected_output, abs=1e-8)

    def test_unknown_model_fallback(self):
        """Unknown model should use fallback pricing ($5/$15 per 1M)."""
        result = self.calc.calculate("unknown-model", "unknown_provider", input_tokens=1000, output_tokens=500)
        expected_input = (1000 / 1_000_000) * 5.00
        expected_output = (500 / 1_000_000) * 15.00
        assert result.input_cost == pytest.approx(expected_input, abs=1e-8)
        assert result.output_cost == pytest.approx(expected_output, abs=1e-8)

    def test_zero_tokens(self):
        """Zero tokens should produce zero cost."""
        result = self.calc.calculate("gpt-4o", "openai", input_tokens=0, output_tokens=0)
        assert result.input_cost == 0.0
        assert result.output_cost == 0.0
        assert result.total_cost == 0.0

    def test_custom_pricing(self):
        """Custom pricing should override defaults."""
        custom = CostCalculator(custom_pricing={
            "openai": {"gpt-4o": (1.00, 2.00)},
        })
        result = custom.calculate("gpt-4o", "openai", input_tokens=1_000_000, output_tokens=1_000_000)
        assert result.input_cost == pytest.approx(1.00, abs=1e-8)
        assert result.output_cost == pytest.approx(2.00, abs=1e-8)

    def test_prefix_match(self):
        """Model with date suffix should match base model pricing."""
        # gpt-4o-2024-11-20 should match gpt-4o pricing
        result = self.calc.calculate("gpt-4o-2024-11-20", "openai", input_tokens=1000, output_tokens=500)
        expected_input = (1000 / 1_000_000) * 2.50
        assert result.input_cost == pytest.approx(expected_input, abs=1e-8)


# =========================================================================
# 7. Pipeline Tests
# =========================================================================


class TestPipeline:
    """Integration tests for the request pipeline with mocked provider."""

    def _make_pipeline(self, *, api_key=None):
        """Create a pipeline with a mocked provider."""
        registry = ProviderRegistry()
        self.mock_provider = MagicMock(spec=OpenAIProvider)
        self.mock_provider.provider_name = "openai"

        # Make complete() return an async mock
        mock_response = ProviderResponse(
            id="chatcmpl-test",
            model="gpt-4o",
            content="Mocked response",
            finish_reason="stop",
            usage={"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        )
        self.mock_provider.complete = AsyncMock(return_value=mock_response)

        registry.register("openai", self.mock_provider)
        return RequestPipeline(registry=registry, api_key=api_key)

    def test_pipeline_happy_path(self):
        """Full flow through pipeline with mocked provider (no auth, no security scan blocking)."""
        pipeline = self._make_pipeline()

        async def _run():
            with patch("coreiq.proxy.pipeline.RequestPipeline._stage_pre_scan", new_callable=AsyncMock), \
                 patch("coreiq.proxy.pipeline.RequestPipeline._stage_post_scan", new_callable=AsyncMock), \
                 patch("coreiq.proxy.pipeline.RequestPipeline._stage_observe"):
                return await pipeline.process(
                    model="openai/gpt-4o",
                    messages=[{"role": "user", "content": "Hello"}],
                )

        result = asyncio.run(_run())

        assert isinstance(result, dict)
        assert result["object"] == "chat.completion"
        assert result["choices"][0]["message"]["content"] == "Mocked response"
        assert result["choices"][0]["finish_reason"] == "stop"
        assert result["usage"]["prompt_tokens"] == 10

        # Verify provider was called
        self.mock_provider.complete.assert_awaited_once()

    def test_pipeline_cache_hit(self):
        """Verify cached response is returned when cache has a hit."""
        pipeline = self._make_pipeline()

        # Mock cache
        cached_data = {"id": "cached", "object": "chat.completion", "choices": []}
        mock_cache = MagicMock()
        mock_entry = MagicMock()
        mock_entry.response = cached_data
        mock_cache.get.return_value = mock_entry
        pipeline._cache = mock_cache

        async def _run():
            with patch("coreiq.proxy.pipeline.RequestPipeline._stage_pre_scan", new_callable=AsyncMock), \
                 patch("coreiq.proxy.pipeline.RequestPipeline._stage_observe"):
                return await pipeline.process(
                    model="openai/gpt-4o",
                    messages=[{"role": "user", "content": "Hello"}],
                )

        result = asyncio.run(_run())

        assert result == cached_data
        # Provider should NOT have been called
        self.mock_provider.complete.assert_not_awaited()

    def test_pipeline_auth_failure(self):
        """Invalid API key should raise PipelineAuthError."""
        pipeline = self._make_pipeline(api_key="correct-key")

        async def _run():
            await pipeline.process(
                model="openai/gpt-4o",
                messages=[{"role": "user", "content": "Hello"}],
                api_key="wrong-key",
            )

        with pytest.raises(PipelineAuthError, match="Invalid API key"):
            asyncio.run(_run())

    def test_pipeline_missing_api_key(self):
        """Missing API key when required should raise PipelineAuthError."""
        pipeline = self._make_pipeline(api_key="required-key")

        async def _run():
            await pipeline.process(
                model="openai/gpt-4o",
                messages=[{"role": "user", "content": "Hello"}],
            )

        with pytest.raises(PipelineAuthError, match="Missing API key"):
            asyncio.run(_run())

    def test_pipeline_no_auth_required(self):
        """When api_key is None, no auth check should occur."""
        pipeline = self._make_pipeline(api_key=None)

        async def _run():
            with patch("coreiq.proxy.pipeline.RequestPipeline._stage_pre_scan", new_callable=AsyncMock), \
                 patch("coreiq.proxy.pipeline.RequestPipeline._stage_post_scan", new_callable=AsyncMock), \
                 patch("coreiq.proxy.pipeline.RequestPipeline._stage_observe"):
                return await pipeline.process(
                    model="openai/gpt-4o",
                    messages=[{"role": "user", "content": "Hello"}],
                )

        result = asyncio.run(_run())
        assert result["object"] == "chat.completion"

    def test_pipeline_unknown_model(self):
        """Unknown model should raise PipelineProviderError."""
        pipeline = self._make_pipeline()

        async def _run():
            with patch("coreiq.proxy.pipeline.RequestPipeline._stage_pre_scan", new_callable=AsyncMock):
                await pipeline.process(
                    model="totally-unknown-thing",
                    messages=[{"role": "user", "content": "Hello"}],
                )

        with pytest.raises(PipelineProviderError, match="Cannot resolve model"):
            asyncio.run(_run())


# =========================================================================
# 8. Gateway Tests (FastAPI TestClient)
# =========================================================================


class TestGateway:
    """FastAPI gateway endpoint tests using TestClient."""

    @pytest.fixture(autouse=True)
    def _setup_gateway(self):
        """Set up the gateway with a mocked pipeline for each test."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        # Create a fresh app with the gateway router
        self.app = FastAPI()
        self.app.include_router(gateway_router)

        # Build mock registry and pipeline
        self.mock_registry = ProviderRegistry()
        self.mock_openai = MagicMock(spec=OpenAIProvider)
        self.mock_openai.provider_name = "openai"
        self.mock_openai.get_api_base.return_value = "https://api.openai.com/v1"
        self.mock_openai.validate_environment.return_value = True
        self.mock_registry.register("openai", self.mock_openai)

        mock_response = ProviderResponse(
            id="chatcmpl-test",
            model="gpt-4o",
            content="Test response",
            finish_reason="stop",
            usage={"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        )
        self.mock_openai.complete = AsyncMock(return_value=mock_response)

        self.mock_pipeline = MagicMock(spec=RequestPipeline)
        self.mock_pipeline.process = AsyncMock(return_value={
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 1234567890,
            "model": "gpt-4o",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "Test response"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        })

        init_gateway(registry=self.mock_registry, pipeline=self.mock_pipeline)

        self.client = TestClient(self.app)
        yield
        # Clean up module-level state
        import coreiq.proxy.gateway as gw
        gw._pipeline = None
        gw._registry = None

    def test_chat_completions_endpoint(self):
        """POST /v1/chat/completions should return a valid response."""
        resp = self.client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "Hello"}],
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["object"] == "chat.completion"
        assert data["choices"][0]["message"]["content"] == "Test response"
        self.mock_pipeline.process.assert_awaited_once()

    def test_models_endpoint(self):
        """GET /v1/models should return a model list."""
        resp = self.client.get("/v1/models")
        assert resp.status_code == 200
        data = resp.json()
        assert data["object"] == "list"
        assert len(data["data"]) == 1
        assert data["data"][0]["id"] == "openai"

    def test_missing_model_field(self):
        """Missing 'model' field should return 422."""
        resp = self.client.post(
            "/v1/chat/completions",
            json={
                "messages": [{"role": "user", "content": "Hello"}],
            },
        )
        assert resp.status_code == 422

    def test_missing_messages_field(self):
        """Missing 'messages' field should return 422."""
        resp = self.client.post(
            "/v1/chat/completions",
            json={"model": "gpt-4o"},
        )
        assert resp.status_code == 422

    def test_auth_error_returns_401(self):
        """Pipeline auth error should return 401."""
        self.mock_pipeline.process = AsyncMock(
            side_effect=PipelineAuthError("Invalid API key")
        )
        resp = self.client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "Hello"}],
            },
        )
        assert resp.status_code == 401
        assert resp.json()["error"]["type"] == "authentication_error"

    def test_provider_error_returns_502(self):
        """Pipeline provider error should return the appropriate status code."""
        self.mock_pipeline.process = AsyncMock(
            side_effect=PipelineProviderError("Provider down", status_code=502)
        )
        resp = self.client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4o",
                "messages": [{"role": "user", "content": "Hello"}],
            },
        )
        assert resp.status_code == 502
        assert resp.json()["error"]["type"] == "server_error"


# =========================================================================
# Additional edge case tests
# =========================================================================


class TestProviderRequest:
    """Tests for the ProviderRequest data class."""

    def test_to_dict_omits_none(self):
        """to_dict() should omit None values by default."""
        req = _make_request()
        d = req.to_dict()
        assert "model" in d
        assert "messages" in d
        assert "temperature" not in d  # None should be omitted
        assert "max_tokens" not in d

    def test_to_dict_includes_none(self):
        """to_dict(include_none=True) should include None values."""
        req = _make_request()
        d = req.to_dict(include_none=True)
        assert "temperature" in d
        assert d["temperature"] is None

    def test_to_dict_includes_extra(self):
        """Extra params should be included in to_dict output."""
        req = _make_request(extra={"custom_param": "value"})
        d = req.to_dict()
        assert d["custom_param"] == "value"


class TestProviderResponse:
    """Tests for the ProviderResponse data class."""

    def test_total_tokens_computed(self):
        """total_tokens should be computed if not in usage."""
        resp = ProviderResponse(
            id="test",
            model="gpt-4o",
            content="",
            finish_reason="stop",
            usage={"prompt_tokens": 10, "completion_tokens": 5},
        )
        assert resp.total_tokens == 15

    def test_total_tokens_from_usage(self):
        """total_tokens should use the value from usage if present."""
        resp = ProviderResponse(
            id="test",
            model="gpt-4o",
            content="",
            finish_reason="stop",
            usage={"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 20},
        )
        assert resp.total_tokens == 20
