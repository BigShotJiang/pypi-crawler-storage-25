"""Tests for governance module."""
import pytest

from coreiq.governance.policy import Policy, PolicyViolation
from coreiq.governance.rbac import Role, Principal
from coreiq.governance.compliance import check_retention


# ── Policy ────────────────────────────────────────────────────────────────────

def test_policy_allowed_model_passes():
    p = Policy(name="test", allowed_models=["gpt-4o", "claude-sonnet-4-6"])
    p.check_model("gpt-4o")  # no exception


def test_policy_blocked_model_raises():
    p = Policy(name="test", allowed_models=["gpt-4o"])
    with pytest.raises(PolicyViolation, match="allowed_model"):
        p.check_model("gpt-3.5-turbo")


def test_policy_denied_model_raises():
    p = Policy(name="test", denied_models=["gpt-3.5-turbo"])
    with pytest.raises(PolicyViolation, match="denied_model"):
        p.check_model("gpt-3.5-turbo")


def test_policy_token_limit():
    p = Policy(name="test", max_input_tokens=1000)
    p.check_tokens(500, 100)  # ok
    with pytest.raises(PolicyViolation, match="max_input_tokens"):
        p.check_tokens(1001, 0)


def test_policy_provider_limit():
    p = Policy(name="test", allowed_providers=["openai"])
    p.check_provider("openai")  # ok
    with pytest.raises(PolicyViolation, match="allowed_provider"):
        p.check_provider("anthropic")


# ── RBAC ──────────────────────────────────────────────────────────────────────

def test_viewer_can_read():
    role = Role.from_preset("viewer")
    assert role.can("trace:read") is True


def test_viewer_cannot_write():
    role = Role.from_preset("viewer")
    assert role.can("trace:write") is False


def test_operator_can_write():
    role = Role.from_preset("operator")
    assert role.can("trace:write") is True


def test_admin_can_do_all():
    role = Role.from_preset("admin")
    assert role.can("trace:write") is True
    assert role.can("admin") is True


def test_role_require_raises():
    role = Role.from_preset("viewer")
    with pytest.raises(PermissionError):
        role.require("evolution:write")


def test_principal_require():
    p = Principal(id="user-1", role=Role.from_preset("operator"))
    p.require("feedback:write")  # ok
    with pytest.raises(PermissionError):
        p.require("admin")


# ── Compliance / retention ────────────────────────────────────────────────────

def test_retention_within_window():
    from datetime import datetime, timezone, timedelta
    recent = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
    assert check_retention(recent, max_age_days=30) is True


def test_retention_outside_window():
    from datetime import datetime, timezone, timedelta
    old = (datetime.now(timezone.utc) - timedelta(days=100)).isoformat()
    assert check_retention(old, max_age_days=30) is False
