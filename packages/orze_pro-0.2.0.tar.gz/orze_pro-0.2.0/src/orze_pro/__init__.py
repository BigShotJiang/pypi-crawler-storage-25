"""orze-pro — autopilot for GPU experiments."""
__version__ = "0.2.0"

from orze_pro.license import is_licensed, license_info, check_license
