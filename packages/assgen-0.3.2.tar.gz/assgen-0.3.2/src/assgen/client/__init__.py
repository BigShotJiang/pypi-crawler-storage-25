"""Client package for assgen."""
