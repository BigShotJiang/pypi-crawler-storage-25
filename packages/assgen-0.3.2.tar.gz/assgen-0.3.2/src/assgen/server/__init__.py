"""Server package for assgen."""
