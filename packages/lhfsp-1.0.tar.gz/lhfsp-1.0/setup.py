from setuptools import setup, find_packages

setup(
    name='lhfsp',
    version='1.0',
    packages=find_packages(),
    install_requires=[],
)