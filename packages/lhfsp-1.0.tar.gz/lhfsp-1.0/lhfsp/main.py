def lighthash(text):
    global y, z
    hashtextlist = []
    for char in text:
        x = ord(char)
        r = (x**2013)%2908
        hashchar = chr(r)
        hashtextlist.append(hashchar)
    hashtext = "".join(hashtextlist)
    return hashtext
