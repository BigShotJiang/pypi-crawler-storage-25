import pandas as pd
from sqlalchemy import text
import sqlalchemy as sa
import logging
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
from typing import Optional, Callable
import subprocess
import sys
import importlib

def ensure_package(package_name, import_name=None):
    """
    检查并自动安装缺失的包
    
    Args:
        package_name: pip包名
        import_name: 导入时的模块名（如果与包名不同）
    """
    if import_name is None:
        import_name = package_name
    
    try:
        importlib.import_module(import_name)
        logging.info(f"Package {package_name} already installed")
    except ImportError:
        logging.warning(f"Package {package_name} not found, installing...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
            logging.info(f"Package {package_name} installed successfully")
        except subprocess.CalledProcessError as e:
            raise ImportError(f"Failed to install {package_name}. Error: {e}")

def get_oracle_engine(user, password, ip_port, db, mode: str = "sid"):
    """
    获取Oracle数据库引擎
    
    Args:
        user: 用户名
        password: 密码
        ip_port: IP:端口
        db: 数据库名
        mode: 连接模式，'sid' 或 'servicename'
    """
    # 自动安装 oracledb
    ensure_package("oracledb")
    
    import oracledb
    
    # 设置thick模式（可选，如果需要兼容老版本功能）
    # oracledb.init_oracle_client()
    
    if mode.lower() == "sid":
        connection_string = f"oracle+oracledb://{user}:{password}@{ip_port}/{db}"
    elif mode.lower() == "servicename":
        connection_string = f"oracle+oracledb://{user}:{password}@{ip_port}/?service_name={db}"
    else:
        raise ValueError("Wrong mode, should be either 'sid' or 'servicename'")
    
    return sa.create_engine(
        connection_string,
        max_overflow=15,
        pool_recycle=600,
        pool_size=0
    )

def get_mysql_engine(user, passwd, ip_port, db):
    """
    获取MySQL数据库引擎
    
    Args:
        user: 用户名
        passwd: 密码
        ip_port: IP:端口
        db: 数据库名
    """
    # 自动安装 mysql-connector-python
    ensure_package("mysql-connector-python", "mysql.connector")
    
    import mysql.connector
    from urllib.parse import quote_plus
    
    encoded_passwd = quote_plus(passwd)
    return sa.create_engine(
        f"mysql+pymysql://{user}:{encoded_passwd}@{ip_port}/{db}?charset=utf8mb4",
        max_overflow=15,
        pool_recycle=600,
        pool_size=0
    )

def get_sql_df(sql, sa_engine, func: Optional[Callable] = None):
    """
    执行SQL查询并返回DataFrame
    
    Args:
        sql: SQL查询语句
        sa_engine: SQLAlchemy引擎
        func: 可选的数据处理函数
    """
    logging.info('###### sql:\n%s', sql)
    df = pd.read_sql(sql, sa_engine)
    if func is not None:
        df = func(df)
    logging.info("###### sampledf:\n%s", df.head(2))
    return df

def to_sqlin_str(in_list):
    """
    将列表转换为SQL IN语句格式的字符串
    
    Args:
        in_list: 列表或字符串
    """
    if type(in_list) == str:
        in_list = [in_list]
    ret_str = str(tuple(in_list)).replace(',)', ',')
    return ret_str

def selectDB_oracle(connect, sql, val=()):
    """
    使用原生连接执行Oracle查询（修复了拼写错误）
    
    Args:
        connect: Oracle连接对象
        sql: SQL语句
        val: 参数值
    """
    mycursor = connect.cursor()
    mycursor.execute(sql, val)  # 修复了excute -> execute的拼写错误
    myresult = mycursor.fetchall()
    mycursor.close()
    return myresult

# 使用示例
if __name__ == "__main__":
    # 配置日志
    logging.basicConfig(level=logging.INFO)
    
    # Oracle连接示例
    try:
        oracle_engine = get_oracle_engine(
            user="your_user",
            password="your_password",
            ip_port="localhost:1521",
            db="ORCL",
            mode="sid"
        )
        print("Oracle engine created successfully")
    except Exception as e:
        print(f"Oracle connection failed: {e}")
    
    # MySQL连接示例
    try:
        mysql_engine = get_mysql_engine(
            user="your_user",
            passwd="your_password",
            ip_port="localhost:3306",
            db="your_database"
        )
        print("MySQL engine created successfully")
    except Exception as e:
        print(f"MySQL connection failed: {e}")