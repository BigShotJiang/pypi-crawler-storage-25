from commitclinic.models import Finding, IntakeReport, ScoreSummary
from commitclinic.tui import _adjust_offset
from commitclinic.tui import _next_index
from commitclinic.tui import _run_treat_for_selected
from commitclinic.tui import build_dashboard_lines


def test_dashboard_lines_without_report() -> None:
    lines = build_dashboard_lines("/repo", None, None, "Ready")
    assert any("No intake report loaded" in line for line in lines)


def test_dashboard_lines_with_report_and_summary() -> None:
    report = IntakeReport.new(repo="/repo")
    report.findings.append(
        Finding(
            category="secret",
            severity="high",
            title="Detected token",
            detail="x",
            location="abc123",
        )
    )
    summary = ScoreSummary(score=70, grade="C", blocking_findings=1, category_counts={"secret": 1})

    lines = build_dashboard_lines("/repo", report, summary, "Intake complete")

    assert any("Findings: 1" in line for line in lines)
    assert any("Score: 70 (C)" in line for line in lines)
    assert any("[high] secret: Detected token" in line for line in lines)


def test_next_index_clamps_to_valid_range() -> None:
    assert _next_index(0, 3, -1) == 0
    assert _next_index(1, 3, 1) == 2
    assert _next_index(2, 3, 1) == 2


def test_adjust_offset_tracks_selected_item() -> None:
    assert _adjust_offset(selected_index=1, offset=0, window_size=10) == 0
    assert _adjust_offset(selected_index=12, offset=0, window_size=10) == 3
    assert _adjust_offset(selected_index=2, offset=5, window_size=10) == 2


def test_run_treat_for_selected_requires_location() -> None:
    code, output = _run_treat_for_selected(
        "/repo",
        Finding(category="binary", severity="low", title="x", detail="x", location=""),
    )
    assert code == 1
    assert "no path location" in output.lower()
