from __future__ import annotations

import subprocess

from commitclinic.config import Policy
from commitclinic.scanners.git_scanner import _scan_large_files


def test_scan_large_files_includes_location_from_rev_list(monkeypatch) -> None:
    rev_list = subprocess.CompletedProcess(
        args=["git"],
        returncode=0,
        stdout="aaa111 path/to/big.bin\n",
        stderr="",
    )

    cat_file = subprocess.CompletedProcess(
        args=["git"],
        returncode=0,
        stdout="aaa111 blob 2097152\n",
        stderr="",
    )

    def fake_run_git(_repo: str, _args: list[str]) -> subprocess.CompletedProcess[str]:
        return rev_list

    def fake_subprocess_run(*args, **kwargs):
        if "cat-file" in args[0]:
            return cat_file
        raise AssertionError("unexpected subprocess invocation")

    monkeypatch.setattr("commitclinic.scanners.git_scanner._run_git", fake_run_git)
    monkeypatch.setattr("commitclinic.scanners.git_scanner.subprocess.run", fake_subprocess_run)

    policy = Policy(large_file_threshold_mb=1)
    findings = _scan_large_files("/repo", policy)

    assert len(findings) == 1
    assert findings[0].category == "large_file"
    assert findings[0].location == "path/to/big.bin"


def test_scan_large_files_handles_missing_path(monkeypatch) -> None:
    rev_list = subprocess.CompletedProcess(
        args=["git"],
        returncode=0,
        stdout="bbb222\n",
        stderr="",
    )

    cat_file = subprocess.CompletedProcess(
        args=["git"],
        returncode=0,
        stdout="bbb222 blob 2097152\n",
        stderr="",
    )

    def fake_run_git(_repo: str, _args: list[str]) -> subprocess.CompletedProcess[str]:
        return rev_list

    def fake_subprocess_run(*args, **kwargs):
        if "cat-file" in args[0]:
            return cat_file
        raise AssertionError("unexpected subprocess invocation")

    monkeypatch.setattr("commitclinic.scanners.git_scanner._run_git", fake_run_git)
    monkeypatch.setattr("commitclinic.scanners.git_scanner.subprocess.run", fake_subprocess_run)

    policy = Policy(large_file_threshold_mb=1)
    findings = _scan_large_files("/repo", policy)

    assert len(findings) == 1
    assert findings[0].location == ""
