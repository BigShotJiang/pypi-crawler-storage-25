"""Tests for the scan-list command."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, call, patch

import pytest

from commitclinic.cli import build_parser, cmd_scan_list


# ---------------------------------------------------------------------------
# Parser tests
# ---------------------------------------------------------------------------

def test_scan_list_positional_required():
    parser = build_parser()
    with pytest.raises(SystemExit):
        parser.parse_args(["scan-list"])


def test_scan_list_minimal_parse():
    parser = build_parser()
    args = parser.parse_args(["scan-list", "repos.json"])
    assert args.list_file == "repos.json"
    assert args.out is None
    assert args.work_dir is None
    assert args.refresh is False
    assert args.func.__name__ == "cmd_scan_list"


def test_scan_list_all_flags():
    parser = build_parser()
    args = parser.parse_args([
        "scan-list", "repos.json",
        "--out", "results.json",
        "--work-dir", "/tmp/clones",
        "--refresh",
    ])
    assert args.out == "results.json"
    assert args.work_dir == "/tmp/clones"
    assert args.refresh is True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_args(list_file: str, **kwargs) -> SimpleNamespace:
    """Build a minimal Namespace for cmd_scan_list."""
    defaults = {
        "out": None,
        "work_dir": None,
        "refresh": False,
        "config": None,
        "strict": False,
    }
    defaults.update(kwargs)
    return SimpleNamespace(list_file=list_file, **defaults)


def _write_list(path: Path, entries):
    path.write_text(json.dumps(entries), encoding="utf-8")


# ---------------------------------------------------------------------------
# File-not-found
# ---------------------------------------------------------------------------

def test_missing_list_file(tmp_path):
    args = _make_args(str(tmp_path / "nope.json"))
    assert cmd_scan_list(args) == 1


# ---------------------------------------------------------------------------
# JSON format handling
# ---------------------------------------------------------------------------

def test_flat_string_array(tmp_path):
    list_file = tmp_path / "repos.json"
    _write_list(list_file, ["https://github.com/octocat/Hello-World"])

    mock_report = MagicMock()
    mock_report.findings = []
    mock_report.warnings = []
    mock_summary = MagicMock(score=100, grade="A", blocking_findings=0)

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        rc = cmd_scan_list(_make_args(str(list_file), work_dir=str(tmp_path / "clones")))

    assert rc == 0


def test_object_array(tmp_path):
    list_file = tmp_path / "repos.json"
    _write_list(list_file, [{"url": "https://github.com/octocat/Hello-World", "name": "hw"}])

    mock_report = MagicMock(findings=[], warnings=[])
    mock_summary = MagicMock(score=90, grade="B", blocking_findings=0)

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        rc = cmd_scan_list(_make_args(str(list_file), work_dir=str(tmp_path / "clones")))

    assert rc == 0


def test_repos_wrapper_key(tmp_path):
    list_file = tmp_path / "repos.json"
    _write_list(list_file, {"repos": [{"url": "https://github.com/octocat/Hello-World"}]})

    mock_report = MagicMock(findings=[], warnings=[])
    mock_summary = MagicMock(score=80, grade="B", blocking_findings=0)

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        rc = cmd_scan_list(_make_args(str(list_file), work_dir=str(tmp_path / "clones")))

    assert rc == 0


def test_invalid_json_format(tmp_path):
    list_file = tmp_path / "repos.json"
    list_file.write_text('"just-a-string"', encoding="utf-8")
    assert cmd_scan_list(_make_args(str(list_file))) == 1


def test_entry_missing_url_is_skipped(tmp_path):
    list_file = tmp_path / "repos.json"
    _write_list(list_file, [{"name": "no-url-here"}])

    with patch("commitclinic.cli.subprocess.run") as mock_run:
        rc = cmd_scan_list(_make_args(str(list_file), work_dir=str(tmp_path / "clones")))

    mock_run.assert_not_called()
    assert rc == 0


# ---------------------------------------------------------------------------
# Clone behaviour
# ---------------------------------------------------------------------------

def test_clone_failure_recorded(tmp_path):
    list_file = tmp_path / "repos.json"
    _write_list(list_file, [{"url": "https://github.com/no/such-repo", "name": "bad"}])

    with patch("commitclinic.cli.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=128, stderr="repository not found")
        rc = cmd_scan_list(_make_args(str(list_file), work_dir=str(tmp_path / "clones")))

    assert rc == 1
    # Default results path: list_file stem + .results.json
    results_path = list_file.with_suffix(".results.json")
    results = json.loads(results_path.read_text())
    assert results["results"][0]["status"] == "clone_failed"


def test_clone_uses_correct_git_args(tmp_path):
    list_file = tmp_path / "repos.json"
    url = "https://github.com/octocat/Hello-World"
    _write_list(list_file, [{"url": url, "name": "hw"}])

    mock_report = MagicMock(findings=[], warnings=[])
    mock_summary = MagicMock(score=100, grade="A", blocking_findings=0)
    work_dir = tmp_path / "clones"

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        cmd_scan_list(_make_args(str(list_file), work_dir=str(work_dir)))

    called_cmd = mock_run.call_args[0][0]
    assert called_cmd[0] == "git"
    assert called_cmd[1] == "clone"
    assert url in called_cmd
    assert str(work_dir / "hw") in called_cmd


# ---------------------------------------------------------------------------
# Incremental results + skip logic
# ---------------------------------------------------------------------------

def test_results_written_incrementally(tmp_path):
    list_file = tmp_path / "repos.json"
    urls = [
        {"url": "https://github.com/org/repo-a", "name": "a"},
        {"url": "https://github.com/org/repo-b", "name": "b"},
    ]
    _write_list(list_file, urls)

    results_path = tmp_path / "repos.results.json"
    written_counts = []

    mock_report = MagicMock(findings=[], warnings=[])
    mock_summary = MagicMock(score=100, grade="A", blocking_findings=0)

    original_write = Path.write_text

    def spy_write(self, *a, **kw):
        result = original_write(self, *a, **kw)
        if self == results_path:
            written_counts.append(len(json.loads(results_path.read_text())["results"]))
        return result

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary), \
         patch.object(Path, "write_text", spy_write):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        cmd_scan_list(_make_args(str(list_file), out=str(results_path), work_dir=str(tmp_path / "clones")))

    # Results file should have grown from 1 → 2 entries across writes.
    assert written_counts == [1, 2]


def test_already_scanned_repo_skipped_by_default(tmp_path):
    url = "https://github.com/octocat/Hello-World"
    list_file = tmp_path / "repos.json"
    _write_list(list_file, [{"url": url, "name": "hw"}])

    # Pre-populate results file.
    results_path = tmp_path / "repos.results.json"
    results_path.write_text(
        json.dumps({"results": [{"url": url, "status": "scanned", "score": 100}]}),
        encoding="utf-8",
    )

    with patch("commitclinic.cli.subprocess.run") as mock_run:
        cmd_scan_list(_make_args(str(list_file), out=str(results_path), work_dir=str(tmp_path / "clones")))

    mock_run.assert_not_called()


def test_refresh_flag_rescans(tmp_path):
    url = "https://github.com/octocat/Hello-World"
    list_file = tmp_path / "repos.json"
    _write_list(list_file, [{"url": url, "name": "hw"}])

    results_path = tmp_path / "repos.results.json"
    results_path.write_text(
        json.dumps({"results": [{"url": url, "status": "scanned", "score": 100}]}),
        encoding="utf-8",
    )

    mock_report = MagicMock(findings=[], warnings=[])
    mock_summary = MagicMock(score=100, grade="A", blocking_findings=0)

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        cmd_scan_list(_make_args(str(list_file), out=str(results_path), work_dir=str(tmp_path / "clones"), refresh=True))

    mock_run.assert_called_once()


# ---------------------------------------------------------------------------
# strict mode
# ---------------------------------------------------------------------------

def test_strict_returns_2_on_blocking(tmp_path):
    list_file = tmp_path / "repos.json"
    _write_list(list_file, [{"url": "https://github.com/org/repo", "name": "r"}])

    mock_report = MagicMock(findings=[MagicMock()], warnings=[])
    mock_summary = MagicMock(score=40, grade="D", blocking_findings=1)

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        rc = cmd_scan_list(_make_args(str(list_file), work_dir=str(tmp_path / "clones"), strict=True))

    assert rc == 2


def test_strict_returns_0_when_no_blocking(tmp_path):
    list_file = tmp_path / "repos.json"
    _write_list(list_file, [{"url": "https://github.com/org/repo", "name": "r"}])

    mock_report = MagicMock(findings=[], warnings=[])
    mock_summary = MagicMock(score=100, grade="A", blocking_findings=0)

    with patch("commitclinic.cli.subprocess.run") as mock_run, \
         patch("commitclinic.cli.run_git_intake", return_value=mock_report), \
         patch("commitclinic.cli.score_findings", return_value=mock_summary):
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        rc = cmd_scan_list(_make_args(str(list_file), work_dir=str(tmp_path / "clones"), strict=True))

    assert rc == 0
