from commitclinic.cli import build_parser


def test_ui_defaults_repo_to_current_directory() -> None:
    parser = build_parser()
    args = parser.parse_args(["ui"])

    assert args.repo == "."
    assert args.func.__name__ == "cmd_tui"


def test_tui_alias_still_works() -> None:
    parser = build_parser()
    args = parser.parse_args(["tui"])

    assert args.repo == "."
    assert args.func.__name__ == "cmd_tui"
