from commitclinic.config import Policy
from commitclinic.models import Finding
from commitclinic.scoring import score_findings


def test_blocking_secret_marks_blocking_and_reduces_score() -> None:
    findings = [
        Finding(
            category="secret",
            severity="high",
            title="Leaked key",
            detail="Detected credential",
        )
    ]
    summary = score_findings(findings, Policy())
    assert summary.blocking_findings == 1
    assert summary.score < 100


def test_grade_mapping_low_score_is_f() -> None:
    findings = [
        Finding(category="secret", severity="critical", title="x", detail="x")
        for _ in range(10)
    ]
    summary = score_findings(findings, Policy())
    assert summary.grade == "F"
