from __future__ import annotations

import subprocess

from commitclinic.remediation import execute_treatment


def test_bfg_requires_java(monkeypatch) -> None:
    monkeypatch.setattr("commitclinic.remediation.shutil.which", lambda _name: None)

    code, output = execute_treatment(
        "/repo",
        backend="bfg",
        approve=True,
        strip_paths=["secrets.txt"],
    )

    assert code == 1
    assert "Java is required" in output


def test_bfg_requires_jar(monkeypatch) -> None:
    monkeypatch.setattr("commitclinic.remediation.shutil.which", lambda _name: "/usr/bin/java")
    monkeypatch.setattr("commitclinic.remediation.resolve_bfg_jar", lambda **_kwargs: None)

    code, output = execute_treatment(
        "/repo",
        backend="bfg",
        approve=True,
        strip_paths=["secrets.txt"],
    )

    assert code == 1
    assert "BFG jar not found" in output


def test_bfg_executes_with_delete_file_patterns(monkeypatch) -> None:
    monkeypatch.setattr("commitclinic.remediation.shutil.which", lambda _name: "/usr/bin/java")
    monkeypatch.setattr("commitclinic.remediation.resolve_bfg_jar", lambda **_kwargs: "/tmp/bfg.jar")

    calls = {}

    def fake_run(cmd, check, capture_output, text):
        calls["cmd"] = cmd
        return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="ok", stderr="")

    monkeypatch.setattr("commitclinic.remediation.subprocess.run", fake_run)

    code, output = execute_treatment(
        "/repo",
        backend="bfg",
        approve=True,
        strip_paths=["path/to/secrets.txt"],
    )

    assert code == 0
    assert calls["cmd"] == [
        "java",
        "-jar",
        "/tmp/bfg.jar",
        "--delete-files",
        "secrets.txt",
        "/repo",
    ]
    assert "basename patterns" in output
