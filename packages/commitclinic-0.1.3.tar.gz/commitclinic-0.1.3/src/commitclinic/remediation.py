from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from commitclinic.models import Finding
from commitclinic.tools import resolve_bfg_jar


def build_treatment_plan(findings: list[Finding]) -> list[str]:
    plan: list[str] = []

    if any(f.category == "secret" for f in findings):
        plan.append(
            "Rotate and revoke exposed credentials, then rewrite affected history with git-filter-repo or BFG after backup."
        )
    if any(f.category == "large_file" for f in findings):
        plan.append(
            "Move oversized artifacts to Git LFS or release assets and remove blobs from history via approved rewrite workflow."
        )
    if any(f.category == "binary" for f in findings):
        plan.append(
            "Define binary allowlist paths and remove unexpected binaries from tracked history."
        )
    if any(f.category == "history" for f in findings):
        plan.append(
            "Run repository maintenance and reduce noisy history patterns before migration cutover."
        )

    if not plan:
        plan.append("No treatment required. Repository appears discharge-ready.")

    return plan


def execute_treatment(
    repo: str,
    *,
    backend: str,
    approve: bool,
    strip_paths: list[str],
    bfg_jar: str | None = None,
) -> tuple[int, str]:
    if not approve:
        return 1, "Refusing destructive action without --approve."
    if not strip_paths:
        return 1, "No paths supplied for treatment execution."

    if backend == "git-filter-repo":
        if not shutil.which("git-filter-repo"):
            return 1, "git-filter-repo is not installed."
        cmd = ["git-filter-repo"]
        for path in strip_paths:
            cmd.extend(["--path", path])
        cmd.append("--invert-paths")
        proc = subprocess.run(cmd, cwd=repo, check=False, capture_output=True, text=True)
        output = (proc.stdout + "\n" + proc.stderr).strip()
        return proc.returncode, output

    if backend == "bfg":
        if not shutil.which("java"):
            return 1, "Java is required to run BFG."

        jar_path = resolve_bfg_jar(bfg_jar=bfg_jar)
        if not jar_path:
            return (
                1,
                "BFG jar not found. Run `commitclinic install-tools --with-bfg` or set BFG_JAR.",
            )

        # BFG deletes by file name pattern, not an exact repository path.
        delete_patterns = [Path(path).name for path in strip_paths]
        cmd = ["java", "-jar", str(jar_path)]
        for pattern in delete_patterns:
            cmd.extend(["--delete-files", pattern])
        cmd.append(repo)

        proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
        output = (proc.stdout + "\n" + proc.stderr).strip()
        path_warning = ""
        if any("/" in path for path in strip_paths):
            path_warning = (
                "\nNote: BFG matched basename patterns derived from --strip-path values. "
                "Use git-filter-repo for exact path removals."
            )
        return proc.returncode, (output + path_warning).strip()

    return 1, f"Unsupported backend: {backend}"
