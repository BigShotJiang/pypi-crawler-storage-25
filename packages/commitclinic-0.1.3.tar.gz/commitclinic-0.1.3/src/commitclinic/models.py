from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class Finding:
    category: str
    severity: str
    title: str
    detail: str
    location: str = ""
    blocking: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class IntakeReport:
    repo: str
    source_type: str
    timestamp: str
    findings: list[Finding]
    warnings: list[str]

    @classmethod
    def new(cls, repo: str, source_type: str = "git") -> "IntakeReport":
        return cls(
            repo=repo,
            source_type=source_type,
            timestamp=datetime.now(timezone.utc).isoformat(),
            findings=[],
            warnings=[],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "repo": self.repo,
            "source_type": self.source_type,
            "timestamp": self.timestamp,
            "findings": [f.to_dict() for f in self.findings],
            "warnings": self.warnings,
        }


@dataclass
class ScoreSummary:
    score: int
    grade: str
    blocking_findings: int
    category_counts: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
