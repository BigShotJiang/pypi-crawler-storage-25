from __future__ import annotations

from collections import Counter

from commitclinic.config import Policy
from commitclinic.models import Finding, ScoreSummary


def _grade_from_score(score: int) -> str:
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


def score_findings(findings: list[Finding], policy: Policy) -> ScoreSummary:
    score = 100
    counts = Counter(f.category for f in findings)
    blocking = 0

    for finding in findings:
        weight = policy.category_weights.get(finding.category, 2)
        multiplier = {"low": 1, "medium": 2, "high": 3, "critical": 4}.get(
            finding.severity.lower(), 1
        )
        score -= weight * multiplier

        if finding.category == "secret" and finding.severity.lower() in policy.blocking_secret_severities:
            finding.blocking = True
            blocking += 1
        elif finding.blocking:
            blocking += 1

    score = max(0, min(100, score))
    return ScoreSummary(
        score=score,
        grade=_grade_from_score(score),
        blocking_findings=blocking,
        category_counts=dict(counts),
    )
