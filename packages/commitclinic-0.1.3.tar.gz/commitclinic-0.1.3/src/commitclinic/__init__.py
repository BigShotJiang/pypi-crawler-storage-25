"""CommitClinic package."""

__all__ = ["__version__"]

try:
    from commitclinic._version import version as __version__
except ImportError:  # not installed / no tag yet
    __version__ = "0.0.0.dev0"
