from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class Policy:
    large_file_threshold_mb: int = 50
    strict: bool = False
    blocking_secret_severities: set[str] = field(default_factory=lambda: {"high", "critical"})
    category_weights: dict[str, int] = field(
        default_factory=lambda: {
            "secret": 12,
            "large_file": 6,
            "binary": 4,
            "history": 3,
            "tooling": 1,
        }
    )


def load_policy(config_path: str | None, strict: bool = False) -> Policy:
    policy = Policy(strict=strict)
    if not config_path:
        return policy

    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {config_path}")

    data: dict[str, Any] = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if "large_file_threshold_mb" in data:
        policy.large_file_threshold_mb = int(data["large_file_threshold_mb"])
    if "blocking_secret_severities" in data:
        policy.blocking_secret_severities = {
            str(x).lower() for x in data["blocking_secret_severities"]
        }
    if "category_weights" in data and isinstance(data["category_weights"], dict):
        policy.category_weights.update({str(k): int(v) for k, v in data["category_weights"].items()})
    policy.strict = bool(data.get("strict", strict))
    return policy
