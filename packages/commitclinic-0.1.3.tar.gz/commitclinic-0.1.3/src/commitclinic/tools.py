from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request
from pathlib import Path

def default_tools_dir() -> Path:
    return Path.home() / ".local" / "share" / "commitclinic" / "tools"


def latest_bfg_version() -> str:
    """Return the latest BFG version from Maven Central."""
    url = (
        "https://search.maven.org/solrsearch/select"
        "?q=g:com.madgag+a:bfg&rows=1&wt=json"
    )
    with urllib.request.urlopen(url, timeout=15) as resp:  # noqa: S310
        data = json.loads(resp.read())
    return data["response"]["docs"][0]["latestVersion"]


def bfg_download_url(version: str) -> str:
    return (
        "https://repo1.maven.org/maven2/com/madgag/bfg/"
        f"{version}/bfg-{version}.jar"
    )


def install_bfg(*, version: str | None = None, tools_dir: str | None = None) -> Path:
    if version is None:
        print("Resolving latest BFG version...")
        version = latest_bfg_version()
        print(f"Latest BFG: {version}")
    target_dir = Path(tools_dir).expanduser() if tools_dir else default_tools_dir()
    target_dir.mkdir(parents=True, exist_ok=True)

    jar_path = target_dir / f"bfg-{version}.jar"
    if jar_path.exists():
        return jar_path

    urllib.request.urlretrieve(bfg_download_url(version), jar_path)  # noqa: S310
    return jar_path


def resolve_bfg_jar(
    *,
    bfg_jar: str | None = None,
    tools_dir: str | None = None,
) -> Path | None:
    if bfg_jar:
        path = Path(bfg_jar).expanduser()
        return path if path.exists() else None

    env_path = os.environ.get("BFG_JAR")
    if env_path:
        path = Path(env_path).expanduser()
        return path if path.exists() else None

    target_dir = Path(tools_dir).expanduser() if tools_dir else default_tools_dir()
    if not target_dir.exists():
        return None

    jars = sorted(target_dir.glob("bfg-*.jar"))
    if not jars:
        return None
    return jars[-1]


# ---------------------------------------------------------------------------
# trufflehog installer
# ---------------------------------------------------------------------------

def install_trufflehog(*, tools_dir: str | None = None) -> Path:
    """Install the trufflehog binary.

    Tries ``brew install trufflehog`` first (macOS).  Falls back to downloading
    the latest release binary from GitHub into *tools_dir*.

    Returns the path to the installed binary.
    """
    # Prefer brew on macOS — it handles PATH automatically.
    if shutil.which("brew"):
        subprocess.run(["brew", "install", "trufflehog"], check=True)  # noqa: S603 S607
        binary = shutil.which("trufflehog")
        if binary:
            return Path(binary)

    # Manual download fallback.
    target_dir = Path(tools_dir).expanduser() if tools_dir else default_tools_dir()
    target_dir.mkdir(parents=True, exist_ok=True)

    dest = target_dir / "trufflehog"
    if dest.exists():
        return dest

    # Resolve latest version from GitHub API.
    with urllib.request.urlopen(  # noqa: S310
        "https://api.github.com/repos/trufflesecurity/trufflehog/releases/latest",
        timeout=15,
    ) as resp:
        release = json.loads(resp.read())

    tag: str = release["tag_name"].lstrip("v")
    sys_map = {"Darwin": "darwin", "Linux": "linux", "Windows": "windows"}
    arch_map = {"arm64": "arm64", "aarch64": "arm64", "x86_64": "amd64", "AMD64": "amd64"}
    sys_name = sys_map.get(platform.system(), platform.system().lower())
    arch = arch_map.get(platform.machine(), platform.machine().lower())
    asset_name = f"trufflehog_{tag}_{sys_name}_{arch}.tar.gz"
    download_url = (
        f"https://github.com/trufflesecurity/trufflehog/releases/download/"
        f"v{tag}/{asset_name}"
    )

    with tempfile.TemporaryDirectory() as tmp:
        archive = Path(tmp) / asset_name
        urllib.request.urlretrieve(download_url, archive)  # noqa: S310
        with tarfile.open(archive, "r:gz") as tf:
            member = tf.getmember("trufflehog")
            member.name = "trufflehog"
            tf.extract(member, path=tmp, filter="data")
        shutil.move(str(Path(tmp) / "trufflehog"), str(dest))

    dest.chmod(0o755)

    # On Linux CI (root), symlink into /usr/local/bin so it's on PATH automatically.
    if os.getuid() == 0:
        system_bin = Path("/usr/local/bin/trufflehog")
        if not system_bin.exists():
            system_bin.symlink_to(dest)

    return dest
