from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from commitclinic.config import load_policy
from commitclinic.models import Finding
from commitclinic.remediation import build_treatment_plan
from commitclinic.remediation import execute_treatment
from commitclinic.reporting import (
    cli_diagnosis_summary,
    cli_intake_summary,
    write_csv_findings,
    write_json_report,
)
from commitclinic.scanners.git_scanner import run_git_intake
from commitclinic.scoring import score_findings
from commitclinic.tools import install_bfg, install_trufflehog
from commitclinic.tui import run_tui


def _load_findings_from_json(path: str) -> tuple[str, list[Finding], list[str]]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    findings = [Finding(**item) for item in data.get("findings", [])]
    repo = data.get("repo", "unknown")
    warnings = list(data.get("warnings", []))
    return repo, findings, warnings


def cmd_intake(args: argparse.Namespace) -> int:
    policy = load_policy(args.config, strict=args.strict)
    report = run_git_intake(args.repo, policy)
    summary = score_findings(report.findings, policy)

    print(cli_intake_summary(report))
    print(cli_diagnosis_summary(summary))

    if args.json_out:
        write_json_report(args.json_out, report, summary)
        print(f"Wrote JSON report: {args.json_out}")
    if args.csv_out:
        write_csv_findings(args.csv_out, report.findings)
        print(f"Wrote CSV findings: {args.csv_out}")

    if args.strict and summary.blocking_findings > 0:
        return 2
    return 0


def cmd_diagnose(args: argparse.Namespace) -> int:
    policy = load_policy(args.config, strict=args.strict)
    _, findings, _ = _load_findings_from_json(args.input)
    summary = score_findings(findings, policy)
    print(cli_diagnosis_summary(summary))
    return 2 if args.strict and summary.blocking_findings > 0 else 0


def cmd_treatment_plan(args: argparse.Namespace) -> int:
    _, findings, _ = _load_findings_from_json(args.input)
    plan = build_treatment_plan(findings)
    print("Treatment Plan:")
    for step in plan:
        print(f"- {step}")
    return 0


def cmd_discharge(args: argparse.Namespace) -> int:
    policy = load_policy(args.config, strict=args.strict)
    repo, findings, warnings = _load_findings_from_json(args.input)
    summary = score_findings(findings, policy)

    print(f"Discharge review for {repo}")
    print(cli_diagnosis_summary(summary))
    if warnings:
        print("Outstanding warnings:")
        for warning in warnings:
            print(f"- {warning}")
    return 2 if args.strict and summary.blocking_findings > 0 else 0


def cmd_treat(args: argparse.Namespace) -> int:
    code, output = execute_treatment(
        args.repo,
        backend=args.backend,
        approve=args.approve,
        strip_paths=args.strip_path,
        bfg_jar=args.bfg_jar,
    )
    if output:
        print(output)
    return code


def cmd_install_tools(args: argparse.Namespace) -> int:
    # Default: install everything when no specific flags given.
    install_bfg_flag = args.with_bfg or (not args.with_bfg and not args.with_trufflehog)
    install_trufflehog_flag = args.with_trufflehog or (not args.with_bfg and not args.with_trufflehog)

    rc = 0

    if install_bfg_flag:
        try:
            jar = install_bfg(version=args.bfg_version or None, tools_dir=args.tools_dir)
            print(f"Installed BFG: {jar}")
        except Exception as exc:  # noqa: BLE001
            print(f"Failed to install BFG: {exc}")
            rc = 1

    if install_trufflehog_flag:
        try:
            import shutil as _shutil
            binary = install_trufflehog(tools_dir=args.tools_dir)
            print(f"Installed trufflehog: {binary}")
            if not _shutil.which("trufflehog"):
                print(f"Tip: add {binary.parent} to your PATH so commitclinic can find it.")
        except Exception as exc:  # noqa: BLE001
            print(f"Failed to install trufflehog: {exc}")
            rc = 1

    return rc


def cmd_tui(args: argparse.Namespace) -> int:
    return run_tui(args.repo, args.config, args.strict)


def cmd_batch(args: argparse.Namespace) -> int:
    policy = load_policy(args.config, strict=args.strict)
    repo_paths = [
        line.strip()
        for line in Path(args.repos_file).read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]

    aggregate = []
    for repo in repo_paths:
        report = run_git_intake(repo, policy)
        summary = score_findings(report.findings, policy)
        aggregate.append({
            "repo": repo,
            "score": summary.score,
            "grade": summary.grade,
            "blocking_findings": summary.blocking_findings,
            "findings": len(report.findings),
            "warnings": len(report.warnings),
        })
        print(f"{repo}: score={summary.score} grade={summary.grade} blocking={summary.blocking_findings}")

    if args.json_out:
        output = Path(args.json_out)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps({"results": aggregate}, indent=2), encoding="utf-8")
        print(f"Wrote batch summary: {args.json_out}")

    if args.strict and any(item["blocking_findings"] > 0 for item in aggregate):
        return 2
    return 0


def cmd_scan_list(args: argparse.Namespace) -> int:
    """Clone each repo URL from a JSON list, scan it, append to results."""
    list_path = Path(args.list_file)
    if not list_path.exists():
        print(f"List file not found: {list_path}")
        return 1

    entries = json.loads(list_path.read_text(encoding="utf-8"))
    if isinstance(entries, dict) and "repos" in entries:
        entries = entries["repos"]
    if not isinstance(entries, list):
        print("Expected a JSON array (or {\"repos\": [...]}) of URL strings or objects.")
        return 1

    policy = load_policy(args.config, strict=args.strict)

    # Load existing results if appending.
    results_path = Path(args.out) if args.out else list_path.with_suffix(".results.json")
    existing: dict = {}
    if results_path.exists():
        try:
            saved = json.loads(results_path.read_text(encoding="utf-8"))
            existing = {r["url"]: r for r in saved.get("results", [])}
        except Exception:  # noqa: BLE001
            existing = {}

    work_dir = Path(args.work_dir) if args.work_dir else Path(tempfile.mkdtemp(prefix="commitclinic-"))
    work_dir.mkdir(parents=True, exist_ok=True)

    results = dict(existing)
    rc = 0

    for entry in entries:
        url = entry if isinstance(entry, str) else entry.get("url", "")
        label = (entry.get("name") if isinstance(entry, dict) else None) or url.rstrip("/").split("/")[-1]

        if not url:
            print("Skipping entry with no URL.")
            continue

        if url in results and not args.refresh:
            print(f"[skip] {label} (already scanned, use --refresh to re-scan)")
            continue

        clone_target = work_dir / label
        if clone_target.exists():
            shutil.rmtree(clone_target)

        print(f"[clone] {url} → {clone_target}")
        clone_proc = subprocess.run(
            ["git", "clone", "--quiet", url, str(clone_target)],
            check=False,
            capture_output=True,
            text=True,
        )
        if clone_proc.returncode != 0:
            print(f"  FAILED: {clone_proc.stderr.strip()}")
            results[url] = {
                "url": url,
                "name": label,
                "status": "clone_failed",
                "error": clone_proc.stderr.strip(),
                "scanned_at": datetime.now(timezone.utc).isoformat(),
            }
            rc = 1
            results_path.parent.mkdir(parents=True, exist_ok=True)
            results_path.write_text(
                json.dumps({"results": list(results.values())}, indent=2),
                encoding="utf-8",
            )
            continue

        report = run_git_intake(str(clone_target), policy)
        summary = score_findings(report.findings, policy)

        result = {
            "url": url,
            "name": label,
            "status": "scanned",
            "score": summary.score,
            "grade": summary.grade,
            "blocking": summary.blocking_findings,
            "findings": len(report.findings),
            "warnings": len(report.warnings),
            "scanned_at": datetime.now(timezone.utc).isoformat(),
        }
        results[url] = result
        blocking_flag = " ⚠ BLOCKING" if summary.blocking_findings else ""
        print(f"  score={summary.score} grade={summary.grade} findings={len(report.findings)}{blocking_flag}")

        # Write after each repo so partial progress is never lost.
        results_path.parent.mkdir(parents=True, exist_ok=True)
        results_path.write_text(
            json.dumps({"results": list(results.values())}, indent=2),
            encoding="utf-8",
        )

    print(f"\nResults written to: {results_path}")

    if args.strict and any(r.get("blocking", 0) for r in results.values()):
        return 2
    return rc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="commitclinic", description="CommitClinic repository triage CLI")
    parser.add_argument("--config", help="Path to YAML policy file")
    parser.add_argument("--strict", action="store_true", help="Fail with non-zero exit code on blocking findings")

    sub = parser.add_subparsers(dest="command", required=True)

    intake = sub.add_parser("intake", help="Run repository intake and diagnosis")
    intake.add_argument("--repo", required=True, help="Path to repository")
    intake.add_argument("--json-out", help="Write JSON report path")
    intake.add_argument("--csv-out", help="Write CSV findings path")
    intake.set_defaults(func=cmd_intake)

    diagnose = sub.add_parser("diagnose", help="Calculate score from findings JSON")
    diagnose.add_argument("--input", required=True, help="Path to findings JSON")
    diagnose.set_defaults(func=cmd_diagnose)

    treatment = sub.add_parser("treatment-plan", help="Generate remediation plan from findings JSON")
    treatment.add_argument("--input", required=True, help="Path to findings JSON")
    treatment.set_defaults(func=cmd_treatment_plan)

    discharge = sub.add_parser("discharge", help="Render final migration readiness summary")
    discharge.add_argument("--input", required=True, help="Path to findings JSON")
    discharge.set_defaults(func=cmd_discharge)

    batch = sub.add_parser("batch", help="Run intake across repo list file")
    batch.add_argument("--repos-file", required=True, help="Newline-delimited repository paths")
    batch.add_argument("--json-out", help="Output JSON summary")
    batch.set_defaults(func=cmd_batch)

    scan_list = sub.add_parser(
        "scan-list",
        help="Clone and scan repos from a JSON URL list",
    )
    scan_list.add_argument(
        "list_file",
        help='Path to JSON file: array of URLs or {"repos": [...]}',
    )
    scan_list.add_argument(
        "--out",
        help="Results JSON path (default: <list_file>.results.json)",
    )
    scan_list.add_argument(
        "--work-dir",
        help="Directory to clone repos into (default: system temp)",
    )
    scan_list.add_argument(
        "--refresh",
        action="store_true",
        help="Re-scan repos that are already in the results file",
    )
    scan_list.set_defaults(func=cmd_scan_list)

    treat = sub.add_parser("treat", help="Execute approved cleanup actions")
    treat.add_argument("--repo", required=True, help="Path to repository")
    treat.add_argument(
        "--backend",
        default="git-filter-repo",
        choices=["git-filter-repo", "bfg"],
        help="Rewrite backend",
    )
    treat.add_argument(
        "--strip-path",
        action="append",
        default=[],
        help="Path to remove from history (repeatable)",
    )
    treat.add_argument(
        "--approve",
        action="store_true",
        help="Required flag for destructive treatment execution",
    )
    treat.add_argument(
        "--bfg-jar",
        help="Path to BFG jar (otherwise BFG_JAR or default tools directory is used)",
    )
    treat.set_defaults(func=cmd_treat)

    install_tools = sub.add_parser(
        "install-tools",
        help="Install helper tools (BFG + trufflehog). Installs both by default.",
    )
    install_tools.add_argument("--with-bfg", action="store_true", help="Install only BFG jar (latest)")
    install_tools.add_argument("--with-trufflehog", action="store_true", help="Install only trufflehog")
    install_tools.add_argument("--bfg-version", default="", help="Pin a specific BFG version (default: latest)")
    install_tools.add_argument(
        "--tools-dir",
        help="Target tools directory (default: ~/.local/share/commitclinic/tools)",
    )
    install_tools.set_defaults(func=cmd_install_tools)

    tui = sub.add_parser(
        "ui",
        aliases=["tui", "dashboard"],
        help="Launch interactive terminal dashboard",
    )
    tui.add_argument("--repo", default=".", help="Path to repository (default: current directory)")
    tui.set_defaults(func=cmd_tui)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    raise SystemExit(args.func(args))


if __name__ == "__main__":
    main()
