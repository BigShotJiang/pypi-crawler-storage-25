from __future__ import annotations

import curses
import json
import tempfile
from pathlib import Path

from commitclinic.config import load_policy
from commitclinic.models import Finding, IntakeReport, ScoreSummary
from commitclinic.remediation import build_treatment_plan
from commitclinic.remediation import execute_treatment
from commitclinic.scoring import score_findings
from commitclinic.scanners.git_scanner import run_git_intake


def build_dashboard_lines(
    repo: str,
    report: IntakeReport | None,
    summary: ScoreSummary | None,
    status: str,
    selected_index: int = 0,
    list_offset: int = 0,
) -> list[str]:
    lines = [
        "CommitClinic TUI",
        f"Repo: {repo}",
        "",
        "Keys: i=intake d=diagnose p=plan w=write-json j/k or arrows=move t=treat q=quit",
        "",
        f"Status: {status}",
        "",
    ]

    if not report:
        lines.append("No intake report loaded yet. Press i to run intake.")
        return lines

    lines.append(f"Findings: {len(report.findings)}")
    lines.append(f"Warnings: {len(report.warnings)}")

    if summary:
        lines.append(f"Score: {summary.score} ({summary.grade})")
        lines.append(f"Blocking findings: {summary.blocking_findings}")
    lines.append("")

    if report.warnings:
        lines.append("Warnings:")
        for warning in report.warnings[:5]:
            lines.append(f"- {warning}")
        lines.append("")

    findings = selectable_findings(report)
    if findings:
        lines.append("Findings (selected marked with >):")
        view = findings[list_offset : list_offset + 10]
        for index, finding in enumerate(view, start=list_offset):
            marker = ">" if index == selected_index else " "
            lines.append(f"{marker} {_finding_line(finding)}")
        lines.append("")
        chosen = findings[selected_index]
        lines.append("Selected finding details:")
        lines.append(f"- Category: {chosen.category}")
        lines.append(f"- Severity: {chosen.severity}")
        lines.append(f"- Title: {chosen.title}")
        lines.append(f"- Location: {chosen.location or 'n/a'}")
        lines.append(f"- Blocking: {chosen.blocking}")
        lines.append(f"- Detail: {chosen.detail}")

    return lines


def _finding_line(finding: Finding) -> str:
    loc = f" ({finding.location})" if finding.location else ""
    return f"- [{finding.severity}] {finding.category}: {finding.title}{loc}"


def selectable_findings(report: IntakeReport) -> list[Finding]:
    return list(report.findings)


def _next_index(current: int, total: int, step: int) -> int:
    if total <= 0:
        return 0
    candidate = current + step
    if candidate < 0:
        return 0
    if candidate >= total:
        return total - 1
    return candidate


def _adjust_offset(selected_index: int, offset: int, window_size: int) -> int:
    if selected_index < offset:
        return selected_index
    if selected_index >= offset + window_size:
        return selected_index - window_size + 1
    return offset


def _run_treat_for_selected(repo: str, finding: Finding) -> tuple[int, str]:
    if not finding.location:
        return 1, "Selected finding has no path location to strip."
    return execute_treatment(
        repo,
        backend="git-filter-repo",
        approve=True,
        strip_paths=[finding.location],
    )


def run_tui(repo: str, config_path: str | None, strict: bool) -> int:
    policy = load_policy(config_path, strict=strict)
    if not Path(repo).exists():
        print(f"Repository path does not exist: {repo}")
        return 1

    state = {
        "report": None,
        "summary": None,
        "status": "Ready.",
        "selected_index": 0,
        "list_offset": 0,
    }

    def app(stdscr: curses.window) -> None:
        curses.curs_set(0)
        stdscr.nodelay(False)

        while True:
            stdscr.clear()
            rows, cols = stdscr.getmaxyx()
            lines = build_dashboard_lines(
                repo,
                state["report"],
                state["summary"],
                state["status"],
                selected_index=state["selected_index"],
                list_offset=state["list_offset"],
            )
            for idx, line in enumerate(lines[: rows - 1]):
                stdscr.addnstr(idx, 0, line, max(1, cols - 1))
            stdscr.refresh()

            key = stdscr.getch()
            if key in (ord("q"), ord("Q")):
                state["status"] = "Exiting TUI."
                return

            if key in (ord("i"), ord("I")):
                report = run_git_intake(repo, policy)
                summary = score_findings(report.findings, policy)
                state["report"] = report
                state["summary"] = summary
                state["status"] = "Intake complete."
                state["selected_index"] = 0
                state["list_offset"] = 0
                continue

            if key in (ord("d"), ord("D")):
                report = state["report"]
                if not report:
                    state["status"] = "Run intake first (press i)."
                    continue
                state["summary"] = score_findings(report.findings, policy)
                state["status"] = "Diagnosis refreshed."
                continue

            if key in (ord("p"), ord("P")):
                report = state["report"]
                if not report:
                    state["status"] = "Run intake first (press i)."
                    continue
                plan = build_treatment_plan(report.findings)
                state["status"] = f"Treatment plan: {plan[0]}"
                continue

            if key in (ord("w"), ord("W")):
                report = state["report"]
                if not report:
                    state["status"] = "Run intake first (press i)."
                    continue

                payload = report.to_dict()
                if state["summary"]:
                    payload["score_summary"] = state["summary"].to_dict()
                out = Path(tempfile.gettempdir()) / "commitclinic-tui-report.json"
                out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
                state["status"] = f"Wrote report: {out}"
                continue

            if key in (ord("j"), curses.KEY_DOWN):
                report = state["report"]
                if not report:
                    continue
                findings = selectable_findings(report)
                state["selected_index"] = _next_index(state["selected_index"], len(findings), 1)
                state["list_offset"] = _adjust_offset(
                    state["selected_index"],
                    state["list_offset"],
                    10,
                )
                continue

            if key in (ord("k"), curses.KEY_UP):
                report = state["report"]
                if not report:
                    continue
                findings = selectable_findings(report)
                state["selected_index"] = _next_index(state["selected_index"], len(findings), -1)
                state["list_offset"] = _adjust_offset(
                    state["selected_index"],
                    state["list_offset"],
                    10,
                )
                continue

            if key in (ord("t"), ord("T")):
                report = state["report"]
                if not report:
                    state["status"] = "Run intake first (press i)."
                    continue
                findings = selectable_findings(report)
                if not findings:
                    state["status"] = "No findings available for treatment."
                    continue

                selected = findings[state["selected_index"]]
                if not selected.location:
                    state["status"] = "Selected finding has no file path location."
                    continue

                prompt = "Confirm treatment for selected path? Press y to continue, any other key to cancel."
                stdscr.move(rows - 1, 0)
                stdscr.clrtoeol()
                stdscr.addnstr(rows - 1, 0, prompt, max(1, cols - 1))
                stdscr.refresh()
                confirm = stdscr.getch()
                if confirm not in (ord("y"), ord("Y")):
                    state["status"] = "Treatment canceled."
                    continue

                code, output = _run_treat_for_selected(repo, selected)
                if code == 0:
                    state["status"] = "Treatment completed for selected finding path."
                else:
                    state["status"] = f"Treatment failed: {output.splitlines()[0] if output else 'unknown error'}"

    try:
        curses.wrapper(app)
    except curses.error as exc:
        print(f"Unable to launch TUI in this terminal: {exc}")
        return 1

    return 0
