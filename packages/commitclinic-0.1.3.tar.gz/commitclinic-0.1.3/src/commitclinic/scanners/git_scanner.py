from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from commitclinic.config import Policy
from commitclinic.models import Finding, IntakeReport


def _resolve_trufflehog() -> str | None:
    """Return the path to the trufflehog binary, checking PATH then tools dir."""
    binary = shutil.which("trufflehog")
    if binary:
        return binary
    # Fall back to the commitclinic tools dir (set by install-tools).
    tools_binary = (
        Path.home() / ".local" / "share" / "commitclinic" / "tools" / "trufflehog"
    )
    if tools_binary.exists():
        return str(tools_binary)
    # Also check COMMITCLINIC_TOOLS_DIR env override.
    tools_dir = os.environ.get("COMMITCLINIC_TOOLS_DIR")
    if tools_dir:
        candidate = Path(tools_dir) / "trufflehog"
        if candidate.exists():
            return str(candidate)
    return None


def _run_git(repo: str, args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", "-C", repo, *args],
        check=False,
        capture_output=True,
        text=True,
    )


def _is_git_repo(repo: str) -> bool:
    proc = _run_git(repo, ["rev-parse", "--is-inside-work-tree"])
    return proc.returncode == 0 and proc.stdout.strip() == "true"


def _scan_large_files(repo: str, policy: Policy) -> list[Finding]:
    findings: list[Finding] = []
    rev = _run_git(repo, ["rev-list", "--objects", "--all"])
    if rev.returncode != 0:
        return findings

    object_paths: dict[str, str] = {}
    objects: list[str] = []
    for line in rev.stdout.splitlines():
        if not line.strip():
            continue
        parts = line.split(maxsplit=1)
        obj = parts[0]
        objects.append(obj)
        if len(parts) == 2 and obj not in object_paths:
            object_paths[obj] = parts[1]
    if not objects:
        return findings

    batch_input = "\n".join(objects) + "\n"
    proc = subprocess.run(
        ["git", "-C", repo, "cat-file", "--batch-check=%(objectname) %(objecttype) %(objectsize)"],
        input=batch_input,
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        return findings

    threshold_bytes = policy.large_file_threshold_mb * 1024 * 1024
    for line in proc.stdout.splitlines():
        parts = line.split()
        if len(parts) != 3:
            continue
        object_id, obj_type, size = parts
        if obj_type != "blob":
            continue
        try:
            blob_size = int(size)
        except ValueError:
            continue
        if blob_size > threshold_bytes:
            location = object_paths.get(object_id, "")
            findings.append(
                Finding(
                    category="large_file",
                    severity="medium" if blob_size < threshold_bytes * 2 else "high",
                    title="Oversized blob in history",
                    detail=f"Blob size {blob_size} bytes exceeds {threshold_bytes} bytes threshold.",
                    location=location,
                )
            )
    return findings


def _scan_binary_files_in_head(repo: str) -> list[Finding]:
    findings: list[Finding] = []
    proc = _run_git(repo, ["ls-tree", "-r", "--name-only", "HEAD"])
    if proc.returncode != 0:
        return findings

    binary_exts = {
        ".jar", ".war", ".zip", ".exe", ".dll", ".so", ".dylib", ".png", ".jpg", ".jpeg", ".gif", ".pdf", ".mp4", ".mov"
    }
    for path in proc.stdout.splitlines():
        suffix = Path(path).suffix.lower()
        if suffix in binary_exts:
            findings.append(
                Finding(
                    category="binary",
                    severity="low",
                    title="Binary file tracked in HEAD",
                    detail="Binary files in source history can complicate migration and repository health.",
                    location=path,
                )
            )
    return findings


def _scan_history_health(repo: str) -> list[Finding]:
    findings: list[Finding] = []

    count_proc = _run_git(repo, ["rev-list", "--count", "--all"])
    if count_proc.returncode == 0:
        try:
            commits = int(count_proc.stdout.strip())
            if commits > 50000:
                findings.append(
                    Finding(
                        category="history",
                        severity="medium",
                        title="Large commit history",
                        detail=f"Repository has {commits} commits, which may require migration chunking.",
                    )
                )
        except ValueError:
            pass

    size_proc = _run_git(repo, ["count-objects", "-v"])
    if size_proc.returncode == 0:
        size_kb = 0
        for line in size_proc.stdout.splitlines():
            if line.startswith("size-pack:"):
                try:
                    size_kb = int(line.split(":", 1)[1].strip())
                except ValueError:
                    size_kb = 0
                break
        if size_kb > 1024 * 1024:
            findings.append(
                Finding(
                    category="history",
                    severity="high",
                    title="Large packed history size",
                    detail=f"Packed object database is approximately {size_kb / 1024:.1f} MB.",
                )
            )

    return findings


def _scan_secrets_trufflehog(repo: str) -> tuple[list[Finding], list[str]]:
    findings: list[Finding] = []
    warnings: list[str] = []

    trufflehog_bin = _resolve_trufflehog()
    if not trufflehog_bin:
        warnings.append("trufflehog not found; secret scan was skipped. Run: commitclinic install-tools")
        findings.append(
            Finding(
                category="tooling",
                severity="low",
                title="TruffleHog unavailable",
                detail="Run `commitclinic install-tools` to enable secret detection.",
            )
        )
        return findings, warnings

    proc = subprocess.run(
        [
            trufflehog_bin,
            "git",
            f"file://{Path(repo).resolve()}",
            "--json",
            "--only-verified",
        ],
        check=False,
        capture_output=True,
        text=True,
    )

    if proc.returncode not in (0, 183):
        warnings.append(f"trufflehog failed with exit code {proc.returncode}.")
        return findings, warnings

    for line in proc.stdout.splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue

        detector = item.get("DetectorName", "UnknownDetector")
        raw = str(item.get("Raw", ""))
        redacted = raw[:6] + "..." if raw else "redacted"
        source = item.get("SourceMetadata", {})
        commit = source.get("Data", {}).get("Git", {}).get("commit", "")

        findings.append(
            Finding(
                category="secret",
                severity="high",
                title=f"Verified secret detected by {detector}",
                detail=f"Potential credential material found ({redacted}).",
                location=commit,
            )
        )

    return findings, warnings


def run_git_intake(repo: str, policy: Policy) -> IntakeReport:
    report = IntakeReport.new(repo=repo, source_type="git")

    if not _is_git_repo(repo):
        report.warnings.append("Repository is not a valid Git work tree.")
        report.findings.append(
            Finding(
                category="history",
                severity="critical",
                title="Invalid Git repository",
                detail="Expected a Git repository path for intake.",
                blocking=True,
            )
        )
        return report

    secret_findings, secret_warnings = _scan_secrets_trufflehog(repo)
    report.findings.extend(secret_findings)
    report.warnings.extend(secret_warnings)
    report.findings.extend(_scan_large_files(repo, policy))
    report.findings.extend(_scan_binary_files_in_head(repo))
    report.findings.extend(_scan_history_health(repo))

    return report
