from __future__ import annotations

import csv
import json
from pathlib import Path

from commitclinic.models import Finding, IntakeReport, ScoreSummary


def write_json_report(path: str, report: IntakeReport, summary: ScoreSummary | None = None) -> None:
    payload = report.to_dict()
    if summary:
        payload["score_summary"] = summary.to_dict()
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def write_csv_findings(path: str, findings: list[Finding]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=[
                "category",
                "severity",
                "title",
                "detail",
                "location",
                "blocking",
            ],
        )
        writer.writeheader()
        for finding in findings:
            writer.writerow(
                {
                    "category": finding.category,
                    "severity": finding.severity,
                    "title": finding.title,
                    "detail": finding.detail,
                    "location": finding.location,
                    "blocking": finding.blocking,
                }
            )


def cli_intake_summary(report: IntakeReport) -> str:
    return (
        f"Intake complete for {report.repo}\n"
        f"Diagnosis findings: {len(report.findings)}\n"
        f"Warnings: {len(report.warnings)}"
    )


def cli_diagnosis_summary(summary: ScoreSummary) -> str:
    status = "Ready" if summary.grade in {"A", "B"} else "Needs Treatment"
    return (
        f"Severity score: {summary.score} ({summary.grade})\n"
        f"Blocking findings: {summary.blocking_findings}\n"
        f"Discharge status: {status}"
    )
