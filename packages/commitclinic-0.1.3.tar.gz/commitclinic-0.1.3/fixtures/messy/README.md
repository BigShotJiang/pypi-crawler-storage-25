# Messy Repo
This repo has things commitclinic should flag:
- A large binary in git history
- Windows binaries (.exe, .dll) committed in HEAD
