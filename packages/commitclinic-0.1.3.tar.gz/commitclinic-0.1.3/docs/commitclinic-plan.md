## CommitClinic Implementation Plan (v1)

CommitClinic is a Python CLI that audits repositories for migration risk, scores readiness with A-F grades, and supports guarded cleanup actions.

### Scope

- Git-first scanning with legacy repository support via conversion/mirror into Git.
- Findings categories:
  - Secrets/password exposure
  - Binaries
  - Large files
  - Gross history indicators
- Outputs:
  - Terminal summary
  - JSON artifact
  - CSV artifact
- CI integration via GitHub Actions.

### Product Flow

1. Intake
2. Diagnosis
3. Severity
4. Treatment Plan
5. Discharge

### Safety Model

- Destructive actions are not automatic.
- Treatment outputs are plans by default.
- Explicit approvals are required before future rewrite execution modes.

### Scoring Model

- Weighted deductions from base score of 100.
- Grade bands:
  - A: 90-100
  - B: 80-89
  - C: 70-79
  - D: 60-69
  - F: <60
- High severity secrets can be marked blocking in policy.

### CI Behavior

- Default mode: report findings and upload artifacts without failing the pipeline.
- Strict mode (`--strict`): fail CI when blocking findings exist.

### Initial Deliverables

- Package and CLI scaffold.
- Git scanner with TruffleHog integration hooks.
- Scoring and reporting modules.
- Batch runner.
- GitHub Actions templates.
- Unit tests for scoring behavior.
