"""CLI entrypoint for the Python wrapper."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from ._bin import get_binary_path


def _run(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    binary = get_binary_path()
    return subprocess.run(
        [str(binary), *args],
        cwd=cwd,
        check=False,
        text=True,
    )


def generate(*args: str) -> subprocess.CompletedProcess[str]:
    return _run("generate", *args)


def emit(*args: str) -> subprocess.CompletedProcess[str]:
    return _run("emit", *args)


def build(*args: str) -> subprocess.CompletedProcess[str]:
    return _run("build", *args)


def dev(*args: str) -> subprocess.CompletedProcess[str]:
    return _run("dev", *args)


def main() -> None:
    binary = get_binary_path()
    raise SystemExit(subprocess.call([str(binary), *sys.argv[1:]]))
