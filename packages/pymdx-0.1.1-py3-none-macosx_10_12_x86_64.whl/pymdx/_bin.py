"""Locate the bundled or installed `pymdx` binary."""

from __future__ import annotations

import shutil
from pathlib import Path


def _candidate_internal_paths() -> list[Path]:
    root = Path(__file__).resolve().parent
    candidates = [
        root / "_internal" / "pymdx",
        root / "_internal" / "pymdx.exe",
        root / "_internal" / "pymdx-cli",
        root / "_internal" / "pymdx-cli.exe",
    ]
    return candidates


def get_binary_path() -> Path:
    """Return the path to the `pymdx` executable.

    The lookup order is:
    1. Bundled binary under `pymdx._internal`.
    2. A `pymdx` executable already available on `PATH`.
    """

    for candidate in _candidate_internal_paths():
        if candidate.exists():
            return candidate

    path = shutil.which("pymdx")
    if path:
        return Path(path)

    raise FileNotFoundError(
        "Could not find a pymdx binary. Install the package or ensure pymdx is on PATH."
    )
