userName : eduslip
password : Eduslip@123

pypi-AgEIcHlwaS5vcmcCJDkxYmQ1ZTY0LTIwMGUtNDFjZC05N2Q1LThmOTE2MmNmZTIxYwACD1sxLFsiZWR1c2xpcCJdXQACLFsyLFsiYmM0NjE2OWQtOTdhMS00ZjFlLTlkY2EtMjY0MjM1Y2M5YWFlIl1dAAAGIIFFN-5jYEi1dm7GPmqUJOeiYzRYINmupCfEb_iKp3C4

rm -rf build dist *.egg-info
python -m build
twine upload dist/*