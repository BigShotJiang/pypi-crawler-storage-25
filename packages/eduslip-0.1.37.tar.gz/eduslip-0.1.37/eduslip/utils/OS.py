OS_SLIPS = [
    {
  "slipNo": 1,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int allocation[5][3] = {
        {2, 3, 2},
        {4, 0, 0},
        {5, 0, 4},
        {4, 3, 3},
        {2, 2, 4}
    };

    int max[5][3] = {
        {9, 7, 5},
        {5, 2, 2},
        {1, 0, 4},
        {4, 4, 4},
        {6, 5, 5}
    };

    int available[3] = {3, 3, 2};
    int need[5][3];

    int choice, i, j;

    while (1) {
        printf("\\n1. Accept Available");
        printf("\\n2. Display Allocation and Max");
        printf("\\n3. Display Need Matrix");
        printf("\\n4. Display Available");
        printf("\\n5. Exit");
        printf("\\nEnter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("Enter Available Resources:\\n");
            for (i = 0; i < 3; i++) {
                scanf("%d", &available[i]);
            }
        }

        else if (choice == 2) {
            printf("\\nAllocation Matrix:\\n");
            for (i = 0; i < 5; i++) {
                for (j = 0; j < 3; j++) {
                    printf("%d ", allocation[i][j]);
                }
                printf("\\n");
            }

            printf("\\nMax Matrix:\\n");
            for (i = 0; i < 5; i++) {
                for (j = 0; j < 3; j++) {
                    printf("%d ", max[i][j]);
                }
                printf("\\n");
            }
        }

        else if (choice == 3) {
            printf("\\nNeed Matrix:\\n");
            for (i = 0; i < 5; i++) {
                for (j = 0; j < 3; j++) {
                    need[i][j] = max[i][j] - allocation[i][j]; // max - allocation;
                    printf("%d ", need[i][j]);
                }
                printf("\\n");
            }
        }

        else if (choice == 4) {
            printf("\\nAvailable Resources:\\n");
            for (i = 0; i < 3; i++) {
                printf("%d ", available[i]);
            }
            printf("\\n");
        }

        else if (choice == 5) {
            break;
        }

        else {
            printf("Invalid choice\\n");
        }
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int req[100], n, head, i;
    int total = 0, diff;

    printf("Enter number of requests: ");
    scanf("%d", &n);

    printf("Enter request sequence:\\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &req[i]);
    }
    printf("Enter initial head position: ");
    scanf("%d", &head);

    printf("\\nOrder of execution:\\n");

    for(i = 0; i < n; i++) {
        printf("%d ", req[i]);

        if(head > req[i])
        {
            diff = head - req[i];
        }
        else
        {
            diff = req[i] - head;
        }
        total += diff;
        head = req[i];
    }

    printf("\\nTotal head movement = %d\\n", total);

    return 0;
}"""
  }
},

{
  "slipNo": 2,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int n;
int bit[MAX];

struct file {
    char name[20];
    int blocks[MAX];
    int count;
} f[MAX];

int fc = 0;

void showBit() {
    int i;
    printf("\\nBit Vector:\\n");
    for(i = 0; i < n; i++)
        printf("%d ", bit[i]);
    printf("\\n");
}

void freeBlocks() {
    int i;
    printf("Free Blocks: ");
    for(i = 0; i < n; i++)
        if(bit[i] == 0)
            printf("%d ", i);
    printf("\\n");
}

void createFile() {
    int i, need, free = 0;

    printf("Enter file name: ");
    scanf("%s", f[fc].name);

    printf("Enter number of blocks: ");
    scanf("%d", &need);

    for(i = 0; i < n; i++)
        if(bit[i] == 0)
            free++;

    if(free < need) {
        printf("Not enough space\\n");
        return;
    }

    printf("Allocated blocks: ");
    f[fc].count = 0;

    for(i = 0; i < n && need > 0; i++) {
        if(bit[i] == 0) {
            bit[i] = 1;
            f[fc].blocks[f[fc].count++] = i;
            printf("%d ", i);
            need--;
        }
    }

    printf("\\n");
    fc++;
}

void showDir() {
    int i, j;

    printf("\\nDirectory:\\n");

    for(i = 0; i < fc; i++) {
        printf("%s -> ", f[i].name);
        for(j = 0; j < f[i].count; j++)
            printf("%d ", f[i].blocks[j]);
        printf("\\n");
    }
}

int main() {
    int i, ch;

    printf("Enter number of blocks: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        bit[i] = rand() % 2;
    }
    do {
        printf("\\n1.Show Bit Vector\\n2.Create File\\n3.Show Directory\\n4.Exit\\n");
        printf("Enter choice: ");
        scanf("%d", &ch);

        if(ch == 1) {
            showBit();
            freeBlocks();
        }
        else if(ch == 2)
            createFile();
        else if(ch == 3)
            showDir();

    } while(ch != 4);

    return 0;
}""",
    "Q2.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;
    int arr[1000];
    int local_sum = 0, total_sum = 0;
    int i, part;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    part = n / size;

    if(rank == 0) {
        for(i = 0; i < n; i++) {
            arr[i] = rand() % 100;
        }
    }

    int sub_arr[part];

    MPI_Scatter(arr, part, MPI_INT, sub_arr, part, MPI_INT, 0, MPI_COMM_WORLD);

    for(i = 0; i < part; i++) {
        local_sum = local_sum + sub_arr[i];
    }

    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Total Sum = %d\\n", total_sum);
    }

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
    // mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 3,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int i, j, k;

    int alloc[5][4] = {
        {0,0,1,2},
        {1,0,0,0},
        {1,3,5,4},
        {0,6,3,2},
        {0,0,1,4}
    };

    int max[5][4] = {
        {0,0,1,2},
        {1,7,5,0},
        {2,3,5,6},
        {0,6,5,2},
        {0,6,5,6}
    };

    int avail[4] = {1,5,2,0};

    int need[5][4];
    int finish[5] = {0};
    int safe[5];
    int count = 0;

    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    printf("Need Matrix:\\n");
    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    for(k = 0; k < 5; k++) {
        for(i = 0; i < 5; i++) {

            if(finish[i] == 0) {
                int flag = 1;

                for(j = 0; j < 4; j++) {
                    if(need[i][j] > avail[j]) {
                        flag = 0;
                        break;
                    }
                }

                if(flag == 1) {
                    for(j = 0; j < 4; j++) {
                        avail[j] = avail[j] + alloc[i][j];
                    }

                    safe[count] = i;
                    count++;
                    finish[i] = 1;
                }
            }
        }
    }

    if(count == 5) {
        printf("\\nSystem is in Safe State\\nSafe Sequence: ");
        for(i = 0; i < 5; i++) {
            printf("P%d ", safe[i]);
        }
    }
    else {
        printf("\\nSystem is NOT in Safe State\\n");
    }

    return 0;
}""",
    "Q2.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;
    int arr[1000];
    int i, part;

    int local_sum = 0, total_sum = 0;
    float avg;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    part = n / size;

    if(rank == 0) {
        for(i = 0; i < n; i++) {
            arr[i] = rand() % 100;
        }
    }

    int sub_arr[part];

    MPI_Scatter(arr, part, MPI_INT, sub_arr, part, MPI_INT, 0, MPI_COMM_WORLD);

    for(i = 0; i < part; i++) {
        local_sum = local_sum + sub_arr[i];
    }

    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        avg = (float) total_sum / n;
        printf("Total Sum = %d\\n", total_sum);
        printf("Average = %.2f\\n", avg);
    }

    MPI_Finalize();
    return 0;
}"""
  }
},

{
  "slipNo": 4,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int i, j, choice;

    int alloc[5][3] = {
        {0,1,0},
        {4,0,0},
        {5,0,4},
        {4,3,3},
        {2,2,4}
    };

    int max[5][3] = {
        {0,0,0},
        {5,2,2},
        {1,0,4},
        {4,4,4},
        {6,5,5}
    };

    int avail[3] = {7,2,6};
    int need[5][3];

    while(1) {
        printf("\\n1. Accept Available");
        printf("\\n2. Display Allocation and Max");
        printf("\\n3. Find Need Matrix");
        printf("\\n4. Display Available");
        printf("\\n5. Exit");
        printf("\\nEnter choice: ");
        scanf("%d", &choice);

        if(choice == 1) {
            printf("Enter Available Resources (A B C): ");
            for(i = 0; i < 3; i++) {
                scanf("%d", &avail[i]);
            }
        }

        else if(choice == 2) {
            printf("\\nAllocation Matrix:\\n");
            for(i = 0; i < 5; i++) {
                for(j = 0; j < 3; j++) {
                    printf("%d ", alloc[i][j]);
                }
                printf("\\n");
            }

            printf("\\nMax Matrix:\\n");
            for(i = 0; i < 5; i++) {
                for(j = 0; j < 3; j++) {
                    printf("%d ", max[i][j]);
                }
                printf("\\n");
            }
        }

        else if(choice == 3) {
            printf("\\nNeed Matrix:\\n");
            for(i = 0; i < 5; i++) {
                for(j = 0; j < 3; j++) {
                    need[i][j] = max[i][j] - alloc[i][j];
                    printf("%d ", need[i][j]);
                }
                printf("\\n");
            }
        }

        else if(choice == 4) {
            printf("\\nAvailable Resources:\\n");
            for(i = 0; i < 3; i++) {
                printf("%d ", avail[i]);
            }
            printf("\\n");
        }

        else if(choice == 5) {
            break;
        }

        else {
            printf("Invalid choice\\n");
        }
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int req[] = {86,147,91,170,95,130,102,70};
    int n = 8;
    int head = 125;
    int size = 200;

    int i, j, temp;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(req[j] > req[j + 1]) {
                temp = req[j];
                req[j] = req[j + 1];
                req[j + 1] = temp;
            }
        }
    }

    int total = 0, current = head;

    printf("Order:\\n");

    for(i = n - 1; i >= 0; i--) {
        if(req[i] < head) {
            printf("%d ", req[i]);
            total += abs(current - req[i]);
            current = req[i];
        }
    }

    total += abs(current - 0);
    current = 0;

    for(i = 0; i < n; i++) {
        if(req[i] > head) {
            printf("%d ", req[i]);
            total += abs(current - req[i]);
            current = req[i];
        }
    }

    printf("\\nTotal Head Movement = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 5,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int m, n, i, j;

    printf("Enter processes and resources: ");
    scanf("%d %d", &m, &n);

    int alloc[m][n], max[m][n], need[m][n], avail[n];

    printf("Enter Allocation:\\n");
    for(i = 0; i < m; i++) {
        for(j = 0; j < n; j++) {
            scanf("%d", &alloc[i][j]);
        }
    }

    printf("Enter Max:\\n");
    for(i = 0; i < m; i++) {
        for(j = 0; j < n; j++) {
            scanf("%d", &max[i][j]);
        }
    }

    printf("Enter Available:\\n");
    for(i = 0; i < n; i++) {
        scanf("%d", &avail[i]);
    }

    printf("\\nNeed Matrix:\\n");
    for(i = 0; i < m; i++) {
        for(j = 0; j < n; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    int p, req[n], ok = 1;

    printf("\\nEnter process number: ");
    scanf("%d", &p);

    printf("Enter request:\\n");
    for(i = 0; i < n; i++) {
        scanf("%d", &req[i]);
    }

    for(i = 0; i < n; i++) {
        if(req[i] > need[p][i] || req[i] > avail[i]) {
            ok = 0;
        }
    }

    if(ok == 1) {
        printf("Request Granted\\n");
    }
    else {
        printf("Request Denied\\n");
    }

    return 0;
}""",
    "Q2.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;
    int arr[1000];
    int i, part;

    int local_max, global_max;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    part = n / size;

    if(rank == 0) {
        for(i = 0; i < n; i++) {
            arr[i] = rand() % 1000;
        }
    }

    int sub_arr[part];

    MPI_Scatter(arr, part, MPI_INT, sub_arr, part, MPI_INT, 0, MPI_COMM_WORLD);

    local_max = sub_arr[0];

    for(i = 1; i < part; i++) {
        if(sub_arr[i] > local_max) {
            local_max = sub_arr[i];
        }
    }

    MPI_Reduce(&local_max, &global_max, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Maximum number = %d\\n", global_max);
    }

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 6,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int n;
int disk[100];
int next[100];

struct file {
    int start;
    int length;
} f[20];

int fileCount = 0;

void showBitVector() {
    int i;
    printf("Bit Vector:\\n");
    for(i = 0; i < n; i++)
        printf("%d ", disk[i]);
    printf("\\n");
}

void createFile() {
    int blocks[50];
    int i, count = 0, len;

    printf("Enter number of blocks for file: ");
    scanf("%d", &len);

    for(i = 0; i < n && count < len; i++) {
        if(disk[i] == 0) {
            blocks[count++] = i;
        }
    }

    if(count < len) {
        printf("Not enough space\\n");
        return;
    }

    for(i = 0; i < len; i++) {
        disk[blocks[i]] = 1;
        if(i != len - 1)
            next[blocks[i]] = blocks[i + 1];
        else
            next[blocks[i]] = -1;
    }

    f[fileCount].start = blocks[0];
    f[fileCount].length = len;
    fileCount++;

    printf("File created\\n");
}

void showDirectory() {
    int i, j, cur;

    for(i = 0; i < fileCount; i++) {
        printf("File %d: ", i + 1);
        cur = f[i].start;

        for(j = 0; j < f[i].length; j++) {
            printf("%d -> ", cur);
            cur = next[cur];
        }
        printf("NULL\\n");
    }
}

int main() {
    int i, choice;

    printf("Enter number of disk blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++) {
        disk[i] = rand() % 2;
        next[i] = -1;
    }

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Create File\\n3.Show Directory\\n4.Exit\\n");
        scanf("%d", &choice);

        if(choice == 1)
            showBitVector();
        else if(choice == 2)
            createFile();
        else if(choice == 3)
            showDirectory();
        else
            break;
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int req[] = {80,150,60,135,40,35,170};
    int n = 7, head = 70, size = 200;
    int i, j, t;

    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(req[j] > req[j+1]) {
                t = req[j];
                req[j] = req[j+1];
                req[j+1] = t;
            }

    int total = 0, cur = head;

    printf("Order: ");

    for(i=0;i<n;i++)
        if(req[i] > head) {
            printf("%d ", req[i]);
            total += abs(cur - req[i]);
            cur = req[i];
        }

    total += abs(cur - (size - 1));
    cur = 0;
    total += (size - 1);

    for(i=0;i<n;i++)
        if(req[i] < head) {
            printf("%d ", req[i]);
            total += abs(cur - req[i]);
            cur = req[i];
        }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 7,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int i, j, k;

    int alloc[5][4] = {
        {2,0,0,1},
        {3,1,2,1},
        {2,1,0,3},
        {1,3,1,2},
        {1,4,3,2}
    };

    int max[5][4] = {
        {4,2,1,2},
        {5,2,5,2},
        {2,3,1,6},
        {1,4,2,4},
        {3,6,6,5}
    };

    int avail[4] = {3,3,2,1};

    int need[5][4];
    int finish[5] = {0};
    int safe[5];
    int count = 0;

    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    printf("Need Matrix:\\n");
    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    for(k = 0; k < 5; k++) {
        for(i = 0; i < 5; i++) {

            if(finish[i] == 0) {
                int flag = 1;

                for(j = 0; j < 4; j++) {
                    if(need[i][j] > avail[j]) {
                        flag = 0;
                        break;
                    }
                }

                if(flag == 1) {
                    for(j = 0; j < 4; j++) {
                        avail[j] = avail[j] + alloc[i][j];
                    }

                    safe[count] = i;
                    count++;
                    finish[i] = 1;
                }
            }
        }
    }

    if(count == 5) {
        printf("\\nSystem is in Safe State\\nSafe Sequence: ");
        for(i = 0; i < 5; i++) {
            printf("P%d ", safe[i]);
        }
    }
    else {
        printf("\\nSystem is NOT in Safe State\\n");
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int a[] = {82,170,43,140,24,16,190};
    int n = 7, head = 50, size = 200;
    int i, j, t;

    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(a[j] > a[j+1]) {
                t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }

    int total = 0, cur = head;

    printf("Order: ");

    for(i=0;i<n;i++)
        if(a[i] > head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    total += abs(cur - (size - 1));
    cur = size - 1;

    for(i=n-1;i>=0;i--)
        if(a[i] < head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 8,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int disk[100], n;

struct file {
    int start;
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;
    printf("Bit Vector:\\n");
    for(i = 0; i < n; i++)
        printf("%d ", disk[i]);
    printf("\\n");
}

void createFile() {
    int len, i, j, found = 0;

    printf("Enter file size (blocks): ");
    scanf("%d", &len);

    for(i = 0; i <= n - len; i++) {
        found = 1;
        for(j = 0; j < len; j++) {
            if(disk[i + j] == 1) {
                found = 0;
                break;
            }
        }
        if(found) {
            for(j = 0; j < len; j++)
                disk[i + j] = 1;

            f[count].start = i;
            f[count].length = len;
            count++;

            printf("File allocated from %d to %d\\n", i, i + len - 1);
            return;
        }
    }

    printf("No contiguous space available\\n");
}

void showDirectory() {
    int i;
    for(i = 0; i < count; i++)
        printf("File %d: Start = %d Length = %d\\n", i + 1, f[i].start, f[i].length);
}

int main() {
    int i, ch;

    printf("Enter number of disk blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++)
        disk[i] = rand() % 2;

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Create File\\n3.Show Directory\\n4.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1)
            showBitVector();
        else if(ch == 2)
            createFile();
        else if(ch == 3)
            showDirectory();
        else
            break;
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int req[] = {186,89,44,70,102,22,51,124};
    int n = 8, head = 70;

    int visited[10] = {0};
    int total = 0, cur = head, i, j, min, pos;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        min = 10000;

        for(j = 0; j < n; j++) {
            if(!visited[j]) {
                int d = abs(cur - req[j]);
                if(d < min) {
                    min = d;
                    pos = j;
                }
            }
        }

        printf("%d ", req[pos]);
        total += abs(cur - req[pos]);
        cur = req[pos];
        visited[pos] = 1;
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 9,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int i, j, k;

    int alloc[5][4] = {
        {0,0,1,2},
        {1,0,0,0},
        {1,3,5,4},
        {0,6,3,2},
        {0,0,1,4}
    };

    int max[5][4] = {
        {0,0,1,2},
        {1,7,5,0},
        {2,3,5,6},
        {0,6,5,2},
        {0,6,5,6}
    };

    int avail[4] = {1,5,2,0};

    int need[5][4];
    int finish[5] = {0};
    int safe[5];
    int count = 0;

    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    printf("Need Matrix:\\n");
    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    for(k = 0; k < 5; k++) {
        for(i = 0; i < 5; i++) {

            if(finish[i] == 0) {
                int flag = 1;

                for(j = 0; j < 4; j++) {
                    if(need[i][j] > avail[j]) {
                        flag = 0;
                        break;
                    }
                }

                if(flag == 1) {
                    for(j = 0; j < 4; j++) {
                        avail[j] = avail[j] + alloc[i][j];
                    }

                    safe[count] = i;
                    count++;
                    finish[i] = 1;
                }
            }
        }
    }

    if(count == 5) {
        printf("\\nSystem is in Safe State\\nSafe Sequence: ");
        for(i = 0; i < 5; i++) {
            printf("P%d ", safe[i]);
        }
    }
    else {
        printf("\\nSystem is NOT in Safe State\\n");
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int a[] = {176,79,34,60,92,11,41,114};
    int n = 8, head = 65;
    int i, j, t;

    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(a[j] > a[j+1]) {
                t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }

    int total = 0, cur = head;

    printf("Order: ");

    for(i=n-1;i>=0;i--)
        if(a[i] < head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    for(i=0;i<n;i++)
        if(a[i] > head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 10,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;
    int arr[1000];
    int i, part;

    int local_sum = 0, total_sum = 0;
    float avg;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    part = n / size;

    if(rank == 0) {
        for(i = 0; i < n; i++) {
            arr[i] = rand() % 100;
        }
    }

    int sub_arr[part];

    MPI_Scatter(arr, part, MPI_INT, sub_arr, part, MPI_INT, 0, MPI_COMM_WORLD);

    for(i = 0; i < part; i++) {
        local_sum = local_sum + sub_arr[i];
    }

    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        avg = (float) total_sum / n;

        printf("Total Sum = %d\\n", total_sum);
        printf("Average = %.2f\\n", avg);
    }

    MPI_Finalize();
    return 0;

    // mpicc Q1.c
// mpirun -np 2 ./a.out
}
""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int a[] = {33,99,142,52,197,79,46,65};
    int n = 8, head = 72, size = 200;
    int i, j, t;

    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(a[j] > a[j+1]) {
                t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }

    int total = 0, cur = head;

    printf("Order: ");

    for(i=n-1;i>=0;i--)
        if(a[i] < head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    total += abs(cur - 0);
    cur = size - 1;
    total += (size - 1);

    for(i=n-1;i>=0;i--)
        if(a[i] > head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 11,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int i, j, choice;

    int alloc[5][3] = {
        {0,1,0},
        {2,0,0},
        {3,0,3},
        {2,1,1},
        {0,0,2}
    };

    int max[5][3] = {
        {0,0,0},
        {2,0,2},
        {3,0,3},
        {1,0,0},
        {0,0,2}
    };

    int avail[3] = {0,0,0};
    int need[5][3];

    while(1) {
        printf("\\n1. Accept Available");
        printf("\\n2. Display Allocation and Max");
        printf("\\n3. Display Need Matrix");
        printf("\\n4. Display Available");
        printf("\\n5. Exit");
        printf("\\nEnter choice: ");
        scanf("%d", &choice);

        if(choice == 1) {
            printf("Enter Available (A B C): ");
            for(i = 0; i < 3; i++) {
                scanf("%d", &avail[i]);
            }
        }

        else if(choice == 2) {
            printf("\\nAllocation Matrix:\\n");
            for(i = 0; i < 5; i++) {
                for(j = 0; j < 3; j++) {
                    printf("%d ", alloc[i][j]);
                }
                printf("\\n");
            }

            printf("\\nMax Matrix:\\n");
            for(i = 0; i < 5; i++) {
                for(j = 0; j < 3; j++) {
                    printf("%d ", max[i][j]);
                }
                printf("\\n");
            }
        }

        else if(choice == 3) {
            printf("\\nNeed Matrix:\\n");
            for(i = 0; i < 5; i++) {
                for(j = 0; j < 3; j++) {
                    need[i][j] = max[i][j] - alloc[i][j];
                    printf("%d ", need[i][j]);
                }
                printf("\\n");
            }
        }

        else if(choice == 4) {
            printf("\\nAvailable Resources:\\n");
            for(i = 0; i < 3; i++) {
                printf("%d ", avail[i]);
            }
            printf("\\n");
        }

        else if(choice == 5) {
            break;
        }

        else {
            printf("Invalid choice\\n");
        }
    }

    return 0;
}""",
    "Q2.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;
    int arr[1000];
    int i, part;

    int local_min, global_min;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    part = n / size;

    if(rank == 0) {
        for(i = 0; i < n; i++) {
            arr[i] = rand() % 1000;
        }
    }

    int sub_arr[part];

    MPI_Scatter(arr, part, MPI_INT, sub_arr, part, MPI_INT, 0, MPI_COMM_WORLD);

    local_min = sub_arr[0];

    for(i = 1; i < part; i++) {
        if(sub_arr[i] < local_min) {
            local_min = sub_arr[i];
        }
    }

    MPI_Reduce(&local_min, &global_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Minimum number = %d\\n", global_min);
    }

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 12,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;
    int arr[1000];
    int i, part;

    int local_sum = 0, total_sum = 0;
    float avg;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    part = n / size;

    if(rank == 0) {
        for(i = 0; i < n; i++) {
            arr[i] = rand() % 100;
        }
    }

    int sub_arr[part];

    MPI_Scatter(arr, part, MPI_INT, sub_arr, part, MPI_INT, 0, MPI_COMM_WORLD);

    for(i = 0; i < part; i++) {
        local_sum = local_sum + sub_arr[i];
    }

    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        avg = (float) total_sum / n;

        printf("Total Sum = %d\\n", total_sum);
        printf("Average = %.2f\\n", avg);
    }

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int a[] = {23,89,132,42,187,69,36,55};
    int n = 8, head = 40;
    int i, j, t;

    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(a[j] > a[j+1]) {
                t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }

    int total = 0, cur = head;
    int first = -1;

    printf("Order: ");

    for(i=0;i<n;i++)
        if(a[i] > head) {
            if(first == -1) first = a[i];
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    for(i=0;i<n;i++)
        if(a[i] < head) {
            if(cur != first) {
                total += abs(cur - a[0]);
                cur = a[0];
            }
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    printf("\\nTotal = %d", total);

    return 0;
}
"""
  }
},

{
  "slipNo": 13,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int i, j, k;

    int alloc[5][3] = {
        {0,1,0},
        {2,0,0},
        {3,0,3},
        {2,1,1},
        {0,0,2}
    };

    int max[5][3] = {
        {0,0,0},
        {2,0,2},
        {3,0,3},
        {1,0,0},
        {0,0,2}
    };

    int avail[3] = {0,0,0};

    int need[5][3];
    int finish[5] = {0};
    int safe[5];
    int count = 0;

    for(i = 0; i < 5; i++) {
        for(j = 0; j < 3; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    printf("Need Matrix:\\n");
    for(i = 0; i < 5; i++) {
        for(j = 0; j < 3; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    for(k = 0; k < 5; k++) {
        for(i = 0; i < 5; i++) {

            if(finish[i] == 0) {
                int flag = 1;

                for(j = 0; j < 3; j++) {
                    if(need[i][j] > avail[j]) {
                        flag = 0;
                        break;
                    }
                }

                if(flag == 1) {
                    for(j = 0; j < 3; j++) {
                        avail[j] = avail[j] + alloc[i][j];
                    }

                    safe[count] = i;
                    count++;
                    finish[i] = 1;
                }
            }
        }
    }

    if(count == 5) {
        printf("\\nSystem is in Safe State\\nSafe Sequence: ");
        for(i = 0; i < 5; i++) {
            printf("P%d ", safe[i]);
        }
    }
    else {
        printf("\\nSystem is NOT in Safe State\\n");
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>

int main() {
    int a[] = {176,79,34,60,92,11,41,114};
    int n = 8, head = 65, size = 200;
    int i, j, t;

    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(a[j] > a[j+1]) {
                t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }

    int total = 0, cur = head;

    printf("Order: ");

    for(i=n-1;i>=0;i--)
        if(a[i] < head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    total += abs(cur - 0);
    cur = 0;

    for(i=0;i<n;i++)
        if(a[i] > head) {
            printf("%d ", a[i]);
            total += abs(cur - a[i]);
            cur = a[i];
        }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 14,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int disk[100], n;

struct file {
    int start;
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;
    printf("Bit Vector:\\n");
    for(i = 0; i < n; i++)
        printf("%d ", disk[i]);
    printf("\\n");
}

void showDirectory() {
    int i;
    for(i = 0; i < count; i++)
        printf("File %d: Start=%d Length=%d\\n", i+1, f[i].start, f[i].length);
}

void deleteFile() {
    int i, j, fileNo;

    printf("Enter file number to delete: ");
    scanf("%d", &fileNo);

    fileNo--;

    if(fileNo < 0 || fileNo >= count) {
        printf("Invalid file\\n");
        return;
    }

    for(i = f[fileNo].start; i < f[fileNo].start + f[fileNo].length; i++)
        disk[i] = 0;

    for(i = fileNo; i < count - 1; i++)
        f[i] = f[i + 1];

    count--;

    printf("File deleted\\n");
}

int main() {
    int i, ch;

    printf("Enter number of disk blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++)
        disk[i] = rand() % 2;

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Show Directory\\n3.Delete File\\n4.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1)
            showBitVector();
        else if(ch == 2)
            showDirectory();
        else if(ch == 3)
            deleteFile();
        else
            break;
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {80,150,60,135,40,35,170};
    int n = 7, head = 70, size = 200;

    int i, j, t;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        if(a[i] > head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    diff = cur - (size - 1);
    if(diff < 0) {
        diff = -diff;
    }
    total = total + diff;

    cur = 0;
    total = total + (size - 1);

    for(i = 0; i < n; i++) {
        if(a[i] < head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 15,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int n;
int disk[100], next[100];

struct file {
    int start;
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;

    printf("Bit Vector:\\n");

    for(i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }

    printf("\\n");
}

void createFile() {
    int blocks[50];
    int i, k = 0, len;

    printf("Enter file size: ");
    scanf("%d", &len);

    for(i = 0; i < n && k < len; i++) {
        if(disk[i] == 0) {
            blocks[k] = i;
            k++;
        }
    }

    if(k < len) {
        printf("Not enough space\\n");
        return;
    }

    for(i = 0; i < len; i++) {
        disk[blocks[i]] = 1;

        if(i == len - 1) {
            next[blocks[i]] = -1;
        } else {
            next[blocks[i]] = blocks[i + 1];
        }
    }

    f[count].start = blocks[0];
    f[count].length = len;
    count++;

    printf("File created\\n");
}

void showDirectory() {
    int i, j, cur;

    for(i = 0; i < count; i++) {
        printf("File %d: ", i + 1);

        cur = f[i].start;

        for(j = 0; j < f[i].length; j++) {
            printf("%d -> ", cur);
            cur = next[cur];
        }

        printf("NULL\\n");
    }
}

int main() {
    int i, ch;

    printf("Enter number of blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++) {
        disk[i] = rand() % 2;
        next[i] = -1;
    }

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Create New File\\n3.Show Directory\\n4.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1) {
            showBitVector();
        }
        else if(ch == 2) {
            createFile();
        }
        else if(ch == 3) {
            showDirectory();
        }
        else {
            break;
        }
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {80,150,60,135,40,35,170};
    int n = 7, head = 70, size = 200;

    int i, j, t;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        if(a[i] > head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    diff = cur - (size - 1);
    if(diff < 0) {
        diff = -diff;
    }
    total = total + diff;

    cur = 0;
    total = total + (size - 1);

    for(i = 0; i < n; i++) {
        if(a[i] < head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 16,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int disk[100], n;

struct file {
    int start;
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;

    printf("Bit Vector:\\n");

    for(i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }

    printf("\\n");
}

void createFile() {
    int len, i, j, flag;

    printf("Enter file size: ");
    scanf("%d", &len);

    for(i = 0; i <= n - len; i++) {
        flag = 1;

        for(j = 0; j < len; j++) {
            if(disk[i + j] == 1) {
                flag = 0;
                break;
            }
        }

        if(flag == 1) {
            for(j = 0; j < len; j++) {
                disk[i + j] = 1;
            }

            f[count].start = i;
            f[count].length = len;
            count++;

            printf("File allocated from %d to %d\\n", i, i + len - 1);
            return;
        }
    }

    printf("No space available\\n");
}

void showDirectory() {
    int i;

    for(i = 0; i < count; i++) {
        printf("File %d: Start=%d Length=%d\\n", i + 1, f[i].start, f[i].length);
    }
}

int main() {
    int i, ch;

    printf("Enter number of blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++) {
        disk[i] = rand() % 2;
    }

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Create New File\\n3.Show Directory\\n4.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1) {
            showBitVector();
        }
        else if(ch == 2) {
            createFile();
        }
        else if(ch == 3) {
            showDirectory();
        }
        else {
            break;
        }
    }

    return 0;
}""",
    "Q2.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;
    int arr[1000];
    int i, part;

    int local_min, global_min;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    part = n / size;

    if(rank == 0) {
        for(i = 0; i < n; i++) {
            arr[i] = rand() % 1000;
        }
    }

    int sub_arr[part];

    MPI_Scatter(arr, part, MPI_INT, sub_arr, part, MPI_INT, 0, MPI_COMM_WORLD);

    local_min = sub_arr[0];

    for(i = 1; i < part; i++) {
        if(sub_arr[i] < local_min) {
            local_min = sub_arr[i];
        }
    }

    MPI_Reduce(&local_min, &global_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Minimum number = %d\\n", global_min);
    }

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 17,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int disk[100], n;

struct file {
    int index;
    int blocks[50];
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;

    printf("Bit Vector:\\n");

    for(i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }

    printf("\\n");
}

void showDirectory() {
    int i, j;

    for(i = 0; i < count; i++) {
        printf("File %d: Index=%d Blocks: ", i + 1, f[i].index);

        for(j = 0; j < f[i].length; j++) {
            printf("%d ", f[i].blocks[j]);
        }

        printf("\\n");
    }
}

void deleteFile() {
    int i, j, fileNo;

    printf("Enter file number to delete: ");
    scanf("%d", &fileNo);

    fileNo--;

    if(fileNo < 0 || fileNo >= count) {
        printf("Invalid file\\n");
        return;
    }

    disk[f[fileNo].index] = 0;

    for(j = 0; j < f[fileNo].length; j++) {
        disk[f[fileNo].blocks[j]] = 0;
    }

    for(i = fileNo; i < count - 1; i++) {
        f[i] = f[i + 1];
    }

    count--;

    printf("File deleted\\n");
}

int main() {
    int i, ch;

    printf("Enter number of blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++) {
        disk[i] = rand() % 2;
    }

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Show Directory\\n3.Delete File\\n4.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1) {
            showBitVector();
        }
        else if(ch == 2) {
            showDirectory();
        }
        else if(ch == 3) {
            deleteFile();
        }
        else {
            break;
        }
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {23,89,132,42,187,69,36,55};
    int n = 8, head = 40;

    int i, j, t;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    for(i = n - 1; i >= 0; i--) {
        if(a[i] < head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    for(i = 0; i < n; i++) {
        if(a[i] > head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 18,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int disk[100], n;

struct file {
    int index;
    int blocks[50];
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;

    printf("Bit Vector:\\n");

    for(i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }

    printf("\\n");
}

void showDirectory() {
    int i, j;

    for(i = 0; i < count; i++) {
        printf("File %d: Index=%d Blocks: ", i + 1, f[i].index);

        for(j = 0; j < f[i].length; j++) {
            printf("%d ", f[i].blocks[j]);
        }

        printf("\\n");
    }
}

void deleteFile() {
    int i, j, fileNo;

    printf("Enter file number to delete: ");
    scanf("%d", &fileNo);

    fileNo--;

    if(fileNo < 0 || fileNo >= count) {
        printf("Invalid file\\n");
        return;
    }

    disk[f[fileNo].index] = 0;

    for(j = 0; j < f[fileNo].length; j++) {
        disk[f[fileNo].blocks[j]] = 0;
    }

    for(i = fileNo; i < count - 1; i++) {
        f[i] = f[i + 1];
    }

    count--;

    printf("File deleted\\n");
}

int main() {
    int i, ch;

    printf("Enter number of blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++) {
        disk[i] = rand() % 2;
    }

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Show Directory\\n3.Delete File\\n4.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1) {
            showBitVector();
        }
        else if(ch == 2) {
            showDirectory();
        }
        else if(ch == 3) {
            deleteFile();
        }
        else {
            break;
        }
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {33,99,142,52,197,79,46,65};
    int n = 8, head = 72, size = 200;

    int i, j, t;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        if(a[i] > head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    diff = cur - (size - 1);
    if(diff < 0) {
        diff = -diff;
    }
    total = total + diff;
    cur = size - 1;

    for(i = n - 1; i >= 0; i--) {
        if(a[i] < head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 19,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdbool.h>

#define P 6
#define R 4

int main() {
    int allocation[P][R] = {
        {0,3,2,4},
        {1,2,0,1},
        {0,0,0,0},
        {3,3,2,2},
        {1,4,3,2},
        {2,4,1,4}
    };

    int max[P][R] = {
        {6,5,4,4},
        {4,4,4,4},
        {0,0,1,2},
        {3,9,3,4},
        {2,5,3,3},
        {4,6,3,4}
    };

    int available[R] = {4,3,4,2};

    int need[P][R];
    int work[R];
    bool finish[P] = {0};
    int safe[P];
    int i, j, count = 0;

    printf("Need Matrix:\\n");
    for(i = 0; i < P; i++) {
        for(j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    for(i = 0; i < R; i++)
        work[i] = available[i];

    while(count < P) {
        int found = 0;

        for(i = 0; i < P; i++) {
            if(!finish[i]) {
                int flag = 1;

                for(j = 0; j < R; j++) {
                    if(need[i][j] > work[j]) {
                        flag = 0;
                        break;
                    }
                }

                if(flag) {
                    for(j = 0; j < R; j++)
                        work[j] += allocation[i][j];

                    safe[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }

        if(!found) {
            printf("\\nSystem is NOT in safe state\\n");
            return 0;
        }
    }

    printf("\\nSystem is in SAFE state\\nSafe Sequence: ");
    for(i = 0; i < P; i++)
        printf("P%d ", safe[i]);

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {23,89,132,42,187,69,36,55};
    int n = 8, head = 40, size = 200;

    int i, j, t;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    for(i = n - 1; i >= 0; i--) {
        if(a[i] < head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    diff = cur - 0;
    if(diff < 0) {
        diff = -diff;
    }
    total = total + diff;

    cur = size - 1;
    total = total + (size - 1);

    for(i = n - 1; i >= 0; i--) {
        if(a[i] > head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 20,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int a[] = {33,99,142,52,197,79,46,65};
    int n = 8, head = 72, size = 200;
    int dir;

    int i, j, t;

    printf("Enter direction (0=Left, 1=Right): ");
    scanf("%d", &dir);

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    if(dir == 1) {
        for(i = 0; i < n; i++) {
            if(a[i] > head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }

        diff = cur - (size - 1);
        if(diff < 0) {
            diff = -diff;
        }
        total = total + diff;
        cur = size - 1;

        for(i = n - 1; i >= 0; i--) {
            if(a[i] < head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }
    }
    else {
        for(i = n - 1; i >= 0; i--) {
            if(a[i] < head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }

        diff = cur - 0;
        if(diff < 0) {
            diff = -diff;
        }
        total = total + diff;
        cur = 0;

        for(i = 0; i < n; i++) {
            if(a[i] > head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000, i;
    int *data = NULL;
    int local_n, *local_data;
    int local_max, global_max;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    local_n = n / size;
    local_data = (int *)malloc(local_n * sizeof(int));

    if(rank == 0) {
        data = (int *)malloc(n * sizeof(int));
        for(i = 0; i < n; i++)
            data[i] = rand() % 1000;
    }

    MPI_Scatter(data, local_n, MPI_INT, local_data, local_n, MPI_INT, 0, MPI_COMM_WORLD);

    local_max = local_data[0];
    for(i = 1; i < local_n; i++) {
        if(local_data[i] > local_max)
            local_max = local_data[i];
    }

    MPI_Reduce(&local_max, &global_max, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);

    if(rank == 0)
        printf("Maximum number = %d\\n", global_max);

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 21,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int a[] = {55,58,39,18,90,160,150,38,184};
    int n = 9, head = 50;

    int i, cur = head, total = 0, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        printf("%d ", a[i]);

        diff = cur - a[i];
        if(diff < 0) {
            diff = -diff;
        }

        total = total + diff;
        cur = a[i];
    }

    printf("\\nTotal = %d", total);

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000, i;
    int *data = NULL;
    int local_n, *local_data;
    int local_sum = 0, global_sum = 0;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    local_n = n / size;
    local_data = (int *)malloc(local_n * sizeof(int));

    if(rank == 0) {
        data = (int *)malloc(n * sizeof(int));
        for(i = 0; i < n; i++)
            data[i] = rand() % 1000;
    }

    MPI_Scatter(data, local_n, MPI_INT, local_data, local_n, MPI_INT, 0, MPI_COMM_WORLD);

    for(i = 0; i < local_n; i++) {
        if(local_data[i] % 2 == 0)
            local_sum += local_data[i];
    }

    MPI_Reduce(&local_sum, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0)
        printf("Sum of even numbers = %d\\n", global_sum);

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 22,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000, i;
    int *data = NULL;
    int local_n, *local_data;
    int local_sum = 0, global_sum = 0;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    local_n = n / size;
    local_data = (int *)malloc(local_n * sizeof(int));

    if(rank == 0) {
        data = (int *)malloc(n * sizeof(int));
        for(i = 0; i < n; i++)
            data[i] = rand() % 1000;
    }

    MPI_Scatter(data, local_n, MPI_INT, local_data, local_n, MPI_INT, 0, MPI_COMM_WORLD);

    for(i = 0; i < local_n; i++) {
        if(local_data[i] % 2 != 0)
            local_sum += local_data[i];
    }

    MPI_Reduce(&local_sum, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0)
        printf("Sum of odd numbers = %d\\n", global_sum);

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int disk[100], n;

struct file {
    int start;
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;

    printf("Bit Vector:\\n");

    for(i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }

    printf("\\n");
}

void deleteFile() {
    int fileNo, i, j;

    printf("Enter file number to delete: ");
    scanf("%d", &fileNo);

    fileNo = fileNo - 1;

    if(fileNo < 0 || fileNo >= count) {
        printf("Invalid file\\n");
        return;
    }

    for(i = f[fileNo].start; i < f[fileNo].start + f[fileNo].length; i++) {
        disk[i] = 0;
    }

    for(j = fileNo; j < count - 1; j++) {
        f[j] = f[j + 1];
    }

    count = count - 1;

    printf("File deleted\\n");
}

int main() {
    int i, ch;

    printf("Enter number of blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++) {
        disk[i] = rand() % 2;
    }

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Delete File\\n3.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1) {
            showBitVector();
        }
        else if(ch == 2) {
            deleteFile();
        }
        else {
            break;
        }
    }

    return 0;
}"""
  }
},

{
  "slipNo": 23,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int m, n, i, j;

    printf("Enter number of processes: ");
    scanf("%d", &m);

    printf("Enter number of resources: ");
    scanf("%d", &n);

    int alloc[10][10], max[10][10], need[10][10];
    int avail[10], total[10];

    printf("Enter total instances of resources:\\n");
    for(i = 0; i < n; i++) {
        scanf("%d", &total[i]);
        avail[i] = total[i];
    }

    printf("Enter Allocation Matrix:\\n");
    for(i = 0; i < m; i++) {
        for(j = 0; j < n; j++) {
            scanf("%d", &alloc[i][j]);
            avail[j] = avail[j] - alloc[i][j];
        }
    }

    printf("Enter Max Matrix:\\n");
    for(i = 0; i < m; i++) {
        for(j = 0; j < n; j++) {
            scanf("%d", &max[i][j]);
        }
    }

    printf("\\nNeed Matrix:\\n");
    for(i = 0; i < m; i++) {
        for(j = 0; j < n; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    int p, req[10], flag = 1;

    printf("\\nEnter process number for request: ");
    scanf("%d", &p);

    printf("Enter request vector:\\n");
    for(i = 0; i < n; i++) {
        scanf("%d", &req[i]);
    }

    for(i = 0; i < n; i++) {
        if(req[i] > need[p][i]) {
            flag = 0;
        }
    }

    if(flag == 0) {
        printf("Request cannot be granted (exceeds need)\\n");
        return 0;
    }

    for(i = 0; i < n; i++) {
        if(req[i] > avail[i]) {
            flag = 0;
        }
    }

    if(flag == 0) {
        printf("Request cannot be granted (not enough resources)\\n");
    } else {
        printf("Request can be granted immediately\\n");
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {24,90,133,43,188,70,37,55};
    int n = 8, head = 58;

    int visited[10] = {0};
    int total = 0, cur = head;
    int i, j, diff, min, pos;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        min = 10000;

        for(j = 0; j < n; j++) {
            if(visited[j] == 0) {
                diff = cur - a[j];

                if(diff < 0) {
                    diff = -diff;
                }

                if(diff < min) {
                    min = diff;
                    pos = j;
                }
            }
        }

        printf("%d ", a[pos]);

        if(cur > a[pos]) {
            total = total + (cur - a[pos]);
        } else {
            total = total + (a[pos] - cur);
        }

        cur = a[pos];
        visited[pos] = 1;
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 24,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000, i;
    int *data = NULL;
    int local_n, *local_data;
    int local_sum = 0, global_sum = 0;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    local_n = n / size;
    local_data = (int *)malloc(local_n * sizeof(int));

    if(rank == 0) {
        data = (int *)malloc(n * sizeof(int));
        for(i = 0; i < n; i++)
            data[i] = rand() % 1000;
    }

    MPI_Scatter(data, local_n, MPI_INT, local_data, local_n, MPI_INT, 0, MPI_COMM_WORLD);

    for(i = 0; i < local_n; i++) {
        if(local_data[i] % 2 != 0)
            local_sum += local_data[i];
    }

    MPI_Reduce(&local_sum, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0)
        printf("Sum of odd numbers = %d\\n", global_sum);

    MPI_Finalize();
    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}""",
    "Q2.c": """#include <stdio.h>
#include <stdbool.h>

#define P 5
#define R 3

int main() {
    int allocation[P][R] = {
        {0,1,0},
        {2,0,0},
        {3,0,3},
        {2,1,1},
        {0,0,2}
    };

    int max[P][R] = {
        {0,0,0},
        {2,0,2},
        {0,0,0},
        {1,0,0},
        {0,0,2}
    };

    int available[R] = {0,0,0};

    int need[P][R];
    int work[R];
    bool finish[P] = {0};
    int safe[P];
    int i, j, count = 0;

    printf("Need Matrix:\\n");
    for(i = 0; i < P; i++) {
        for(j = 0; j < R; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    for(i = 0; i < R; i++)
        work[i] = available[i];

    while(count < P) {
        int found = 0;

        for(i = 0; i < P; i++) {
            if(!finish[i]) {
                int flag = 1;

                for(j = 0; j < R; j++) {
                    if(need[i][j] > work[j]) {
                        flag = 0;
                        break;
                    }
                }

                if(flag) {
                    for(j = 0; j < R; j++)
                        work[j] += allocation[i][j];

                    safe[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }

        if(!found) {
            printf("\\nSystem is NOT in safe state\\n");
            return 0;
        }
    }

    printf("\\nSystem is in SAFE state\\nSafe Sequence: ");
    for(i = 0; i < P; i++)
        printf("P%d ", safe[i]);

    return 0;
}"""
  }
},

{
  "slipNo": 25,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int a[] = {86,147,91,170,95,130,102,70};
    int n = 8, head = 125;
    int dir;

    int i, j, t;

    printf("Enter direction (0=Left, 1=Right): ");
    scanf("%d", &dir);

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    if(dir == 1) {
        for(i = 0; i < n; i++) {
            if(a[i] > head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }

        for(i = n - 1; i >= 0; i--) {
            if(a[i] < head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }
    }
    else {
        for(i = n - 1; i >= 0; i--) {
            if(a[i] < head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }

        for(i = 0; i < n; i++) {
            if(a[i] > head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}""",
    "Q2.c": """#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int disk[100], next[100], n;

struct file {
    int start;
    int length;
} f[20];

int count = 0;

void showBitVector() {
    int i;

    printf("Bit Vector:\\n");

    for(i = 0; i < n; i++) {
        printf("%d ", disk[i]);
    }

    printf("\\n");
}

void createFile() {
    int blocks[50];
    int i, k = 0, len;

    printf("Enter file size: ");
    scanf("%d", &len);

    for(i = 0; i < n && k < len; i++) {
        if(disk[i] == 0) {
            blocks[k] = i;
            k++;
        }
    }

    if(k < len) {
        printf("Not enough space\\n");
        return;
    }

    for(i = 0; i < len; i++) {
        disk[blocks[i]] = 1;

        if(i == len - 1) {
            next[blocks[i]] = -1;
        } else {
            next[blocks[i]] = blocks[i + 1];
        }
    }

    f[count].start = blocks[0];
    f[count].length = len;
    count++;

    printf("File created\\n");
}

void showDirectory() {
    int i, j, cur;

    for(i = 0; i < count; i++) {
        printf("File %d: ", i + 1);

        cur = f[i].start;

        for(j = 0; j < f[i].length; j++) {
            printf("%d -> ", cur);
            cur = next[cur];
        }

        printf("NULL\\n");
    }
}

int main() {
    int i, ch;

    printf("Enter number of blocks: ");
    scanf("%d", &n);

    srand(time(0));

    for(i = 0; i < n; i++) {
        disk[i] = rand() % 2;
        next[i] = -1;
    }

    while(1) {
        printf("\\n1.Show Bit Vector\\n2.Create New File\\n3.Show Directory\\n4.Exit\\n");
        scanf("%d", &ch);

        if(ch == 1) {
            showBitVector();
        }
        else if(ch == 2) {
            createFile();
        }
        else if(ch == 3) {
            showDirectory();
        }
        else {
            break;
        }
    }

    return 0;
}"""
  }
},

{
  "slipNo": 26,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int i, j, k;

    int alloc[5][4] = {
        {0,0,1,2},
        {1,0,0,0},
        {1,3,5,4},
        {0,6,3,2},
        {0,0,1,4}
    };

    int max[5][4] = {
        {0,0,1,2},
        {1,7,5,0},
        {2,3,5,6},
        {0,6,5,2},
        {0,6,5,6}
    };

    int avail[4] = {1,5,2,0};

    int need[5][4];
    int finish[5] = {0};
    int safe[5];

    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    printf("Need Matrix:\\n");

    for(i = 0; i < 5; i++) {
        for(j = 0; j < 4; j++) {
            printf("%d ", need[i][j]);
        }
        printf("\\n");
    }

    int count = 0;

    for(k = 0; k < 5; k++) {
        for(i = 0; i < 5; i++) {
            if(finish[i] == 0) {
                int flag = 1;

                for(j = 0; j < 4; j++) {
                    if(need[i][j] > avail[j]) {
                        flag = 0;
                        break;
                    }
                }

                if(flag == 1) {
                    for(j = 0; j < 4; j++) {
                        avail[j] = avail[j] + alloc[i][j];
                    }

                    safe[count] = i;
                    count++;
                    finish[i] = 1;
                }
            }
        }
    }

    if(count == 5) {
        printf("\\nSystem is in Safe State\\nSafe Sequence: ");
        for(i = 0; i < 5; i++) {
            printf("P%d ", safe[i]);
        }
    } else {
        printf("\\nSystem is NOT in Safe State");
    }

    return 0;
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {56,59,40,19,91,161,151,39,185};
    int n = 9, head = 48;

    int i, cur = head, total = 0, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        printf("%d ", a[i]);

        diff = cur - a[i];
        if(diff < 0) {
            diff = -diff;
        }

        total = total + diff;
        cur = a[i];
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 27,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int a[] = {176,79,34,60,92,11,41,114};
    int n = 8, head = 65;

    int i, j, t;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        if(a[i] > head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    for(i = n - 1; i >= 0; i--) {
        if(a[i] < head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}""",
    "Q2.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;

    int arr[1000];
    int local_min, global_min;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int part = n / size;

    int sub[1000];

    if(rank == 0) {
        for(int i = 0; i < n; i++) {
            arr[i] = rand() % 1000;
        }
    }

    MPI_Scatter(arr, part, MPI_INT, sub, part, MPI_INT, 0, MPI_COMM_WORLD);

    local_min = sub[0];

    for(int i = 1; i < part; i++) {
        if(sub[i] < local_min) {
            local_min = sub[i];
        }
    }

    MPI_Reduce(&local_min, &global_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Minimum number = %d\\n", global_min);
    }

    MPI_Finalize();

    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 28,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <stdio.h>

int main() {
    int a[] = {56,59,40,19,91,161,151,39,185};
    int n = 9, head = 48;
    int dir;

    int i, j, t;

    printf("Enter direction (0=Left, 1=Right): ");
    scanf("%d", &dir);

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    if(dir == 1) {
        for(i = 0; i < n; i++) {
            if(a[i] > head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }

        for(i = 0; i < n; i++) {
            if(a[i] < head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }
    }
    else {
        for(i = n - 1; i >= 0; i--) {
            if(a[i] < head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }

        for(i = n - 1; i >= 0; i--) {
            if(a[i] > head) {
                printf("%d ", a[i]);

                diff = cur - a[i];
                if(diff < 0) {
                    diff = -diff;
                }

                total = total + diff;
                cur = a[i];
            }
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}""",
    "Q2.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;

    int n = 1000;
    int arr[1000];
    int sub[1000];

    int local_sum = 0, total_sum = 0;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int part = n / size;

    if(rank == 0) {
        for(int i = 0; i < n; i++) {
            arr[i] = rand() % 100;
        }
    }

    MPI_Scatter(arr, part, MPI_INT, sub, part, MPI_INT, 0, MPI_COMM_WORLD);

    for(int i = 0; i < part; i++) {
        local_sum = local_sum + sub[i];
    }

    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Total Sum = %d\\n", total_sum);
    }

    MPI_Finalize();

    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}"""
  }
},

{
  "slipNo": 29,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;

    int n = 1000;
    int arr[1000];
    int sub[1000];

    int local_sum = 0, total_sum = 0;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int part = n / size;

    if(rank == 0) {
        for(int i = 0; i < n; i++) {
            arr[i] = rand() % 100;
        }
    }

    MPI_Scatter(arr, part, MPI_INT, sub, part, MPI_INT, 0, MPI_COMM_WORLD);

    for(int i = 0; i < part; i++) {
        if(sub[i] % 2 == 0) {
            local_sum = local_sum + sub[i];
        }
    }

    MPI_Reduce(&local_sum, &total_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Sum of even numbers = %d\\n", total_sum);
    }

    MPI_Finalize();

    return 0;

// mpicc Q2.c
// mpirun -np 2 ./a.out
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {80,150,60,135,40,35,170};
    int n = 7, head = 70;

    int i, j, t;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }

    int total = 0, cur = head, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        if(a[i] > head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    for(i = 0; i < n; i++) {
        if(a[i] < head) {
            printf("%d ", a[i]);

            diff = cur - a[i];
            if(diff < 0) {
                diff = -diff;
            }

            total = total + diff;
            cur = a[i];
        }
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},

{
  "slipNo": 30,
  "questions": [
    {
      "question": "",
      "filenames": ["Q1.c"]
    },
    {
      "question": "",
      "filenames": ["Q2.c"]
    }
  ],
  "answers": {
    "Q1.c": """#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 1000;

    int arr[1000];
    int local_min, global_min;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int part = n / size;

    int sub[1000];

    if(rank == 0) {
        for(int i = 0; i < n; i++) {
            arr[i] = rand() % 1000;
        }
    }

    MPI_Scatter(arr, part, MPI_INT, sub, part, MPI_INT, 0, MPI_COMM_WORLD);

    local_min = sub[0];

    for(int i = 1; i < part; i++) {
        if(sub[i] < local_min) {
            local_min = sub[i];
        }
    }

    MPI_Reduce(&local_min, &global_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);

    if(rank == 0) {
        printf("Minimum number = %d\\n", global_min);
    }

    MPI_Finalize();

    return 0;

    // mpicc Q2.c
// mpirun -np 2 ./a.out
}""",
    "Q2.c": """#include <stdio.h>

int main() {
    int a[] = {65,95,30,91,18,116,142,44,168};
    int n = 9, head = 52;

    int i, cur = head, total = 0, diff;

    printf("Order: ");

    for(i = 0; i < n; i++) {
        printf("%d ", a[i]);

        diff = cur - a[i];
        if(diff < 0) {
            diff = -diff;
        }

        total = total + diff;
        cur = a[i];
    }

    printf("\\nTotal = %d", total);

    return 0;
}"""
  }
},
]