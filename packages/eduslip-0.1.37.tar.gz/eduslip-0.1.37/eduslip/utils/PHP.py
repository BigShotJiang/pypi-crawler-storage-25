PHP_SLIPS = [
    {
       "slipNo": 1,
       "questions" : [
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.php" : """<?php
session_start();

if(isset($_SESSION['visits']))
{
    $_SESSION['visits']++;
}
else
{
    $_SESSION['visits'] = 1;
}

echo "Page visited: " . $_SESSION['visits'] . " times";
?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from sklearn.model_selection import train_test_split\n",
          "from sklearn.linear_model import LinearRegression\n",
          "\n",
          "data = {\n",
          "    'Position' : ['Business Analyst', 'Junior Consultant', 'Senior Consultant', 'Manager', \n",
          "                 'Country Manager', 'Region Manager', 'Partner', 'Senior Partner', 'C-level', 'CEO'],\n",
          "    'Level': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],\n",
          "    'Salary': [45000, 50000, 60000, 80000, 110000, 150000, 200000, 300000, 500000, 1000000]\n",
          "}\n",
          "\n",
          "dataset = pd.DataFrame(data);\n",
          "\n",
          "x = dataset[['Level']] \n",
          "y = dataset['Salary']\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)\n",
          "\n",
          "regression = LinearRegression();\n",
          "regression.fit(x_train, y_train);\n",
          "\n",
          "y_pred = regression.predict(x_test);\n",
          "print(regression.predict([[3]]))\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

{
       "slipNo": 2,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1a.html"]
        },
        {
        "question": "",
        "filenames": ["q1b.php"]
      },
        {
        "question": "",
        "filenames": ["q1c.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1a.html" : """<!-- page1.php -->
<html>
<body>
<form action="q1b.php" method="post">
    Font Style: <input type="text" name="style"><br><br>
    Font Size: <input type="text" name="size"><br><br>
    Font Color: <input type="text" name="color"><br><br>
    Background Color: <input type="text" name="bg"><br><br>

    <input type="submit" value="Submit">
</form>
</body>
</html>""",
        "q1b.php" : """<?php

setcookie("style", $_POST['style'], time()+3600);
setcookie("size", $_POST['size'], time()+3600);
setcookie("color", $_POST['color'], time()+3600);
setcookie("bg", $_POST['bg'], time()+3600);

echo "Preferences Saved!<br><br>";

echo "Font Style: " . $_POST['style'] . "<br>";
echo "Font Size: " . $_POST['size'] . "<br>";
echo "Font Color: " . $_POST['color'] . "<br>";
echo "Background Color: " . $_POST['bg'] . "<br><br>";

echo "<a href='q1c.php'>Go to Page 3</a>";
?>""",
        "q1c.php" : """<?php

$style = $_COOKIE['style'];
$size  = $_COOKIE['size'];
$color = $_COOKIE['color'];
$bg    = $_COOKIE['bg'];
?>

<html>
<body style="background-color: <?php echo $bg; ?>;">

<p style="
    font-family: <?php echo $style; ?>;
    font-size: <?php echo $size; ?>px;
    color: <?php echo $color; ?>;
">
    This is your customized web page!
</p>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from sklearn.model_selection import train_test_split\n",
          "from sklearn.linear_model import LinearRegression\n",
          "\n",
          "data = {\n",
          "    'Salary': [30000, 45000, 50000, 65000, 80000, 110000, 150000, 200000, 300000, 500000],\n",
          "    'Purchases': [5000, 8000, 9500, 12000, 18000, 25000, 40000, 60000, 90000, 150000]\n",
          "}\n",
          "dataset = pd.DataFrame(data)\n",
          "\n",
          "print(\"--- Original Dataset ---\")\n",
          "print(dataset, \"\\n\")\n",
          "\n",
          "X = dataset[['Salary']] \n",
          "y = dataset['Purchases']\n",
          "\n",
          "X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)\n",
          "\n",
          "print(\"--- Training Set: Independent Variable (X_train) ---\")\n",
          "print(X_train, \"\\n\")\n",
          "\n",
          "print(\"--- Training Set: Target Variable (y_train) ---\")\n",
          "print(y_train, \"\\n\")\n",
          "\n",
          "print(\"--- Testing Set: Independent Variable (X_test) ---\")\n",
          "print(X_test, \"\\n\")\n",
          "\n",
          "print(\"--- Testing Set: Target Variable (y_test) ---\")\n",
          "print(y_test, \"\\n\")\n",
          "\n",
          "regressor = LinearRegression()\n",
          "\n",
          "regressor.fit(X_train, y_train)\n",
          "\n",
          "y_pred = regressor.predict(X_test)\n",
          "\n",
          "print(\"--- Model Status ---\")\n",
          "print(\"Simple Linear Regression model built and trained successfully!\\n\")\n",
          "\n",
          "print(\"--- Predicted vs Actual Purchases (Testing Set) ---\")\n",
          "results = pd.DataFrame({'Actual Purchases': y_test, 'Predicted Purchases': y_pred})\n",
          "print(results)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 3,
       "questions" : [
        {
        "question": "",
        "filenames": ["q1a.php"]
      },
        {
        "question": "",
        "filenames": ["q1b.php"]
      },
        {
        "question": "",
        "filenames": ["q1c.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1a.php" : """

<?php
session_start();
?>

<html>
<body>
<form action="q1b.php" method="post">
    Username: <input type="text" name="user"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <input type="submit" value="Login">
</form>
</body>
</html>
        """,
        "q1b.php" : """<?php

session_start();

$correct_user = "admin";
$correct_pass = "1234";

if(!isset($_SESSION['attempt']))
{
    $_SESSION['attempt'] = 0;
}

$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == $correct_user && $pass == $correct_pass)
{
    echo "<h2>Welcome $user</h2>";
    echo "<a href='q1c.php'>Go to Next Page</a>";
}
else
{
    $_SESSION['attempt']++;

    if($_SESSION['attempt'] < 3)
    {
        echo "Wrong username or password! Try again.<br>";
        echo "Attempts left: " . (3 - $_SESSION['attempt']);
        echo "<br><a href='q1a.php'>Back</a>";
    }
    else
    {
        echo "You have used all 3 attempts!";
    }
}
?>""",
        "q1c.php" : """
<?php
session_start();
?>

<html>
<body>
<h2>Welcome! Login Successful 🎉</h2>
</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "import numpy as np\n",
          "import matplotlib.pyplot as plt\n",
          "\n",
          "from sklearn.linear_model import LogisticRegression\n",
          "from sklearn.model_selection import train_test_split\n",
          "from sklearn import metrics\n",
          "\n",
          "data = pd.read_csv(\"User_Data.csv\")\n",
          "data.head()\n",
          "\n",
          "print(data.shape)\n",
          "print(data.describe())\n",
          "print(data['Purchased'].value_counts())\n",
          "\n",
          "data['Gender'] = data['Gender'].map({'Male': 1, 'Female': 0})\n",
          "\n",
          "x = data[['Gender', 'Age', 'EstimatedSalary']]\n",
          "y = data['Purchased']\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split( x, y, test_size=0.30, random_state=0)\n",
          "\n",
          "model = LogisticRegression()\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})\n",
          "print(df)\n",
          "\n",
          "print(\"Accuracy:\", metrics.accuracy_score(y_test, y_pred))\n",
          "\n",
          "print(model.predict([[1, 35, 50000]]))\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 4,
       "questions" : [
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
        "question": "",
        "filenames": ["q1a.php"]
      },
        {
        "question": "",
        "filenames": ["q1b.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.php" : """<?php session_start(); ?>

<html>
<body>
<form action="q1a.php" method="post">
    Eno: <input type="text" name="eno"><br><br>
    Ename: <input type="text" name="ename"><br><br>
    Address: <input type="text" name="addr"><br><br>
    <input type="submit" value="Next">
</form>
</body>
</html>""",
        "q1a.php" : """<?php
session_start();

$_SESSION['eno'] = $_POST['eno'];
$_SESSION['ename'] = $_POST['ename'];
$_SESSION['addr'] = $_POST['addr'];
?>

<html>
<body>
<form action="q1b.php" method="post">
    Basic: <input type="text" name="basic"><br><br>
    DA: <input type="text" name="da"><br><br>
    HRA: <input type="text" name="hra"><br><br>
    <input type="submit" value="Show">
</form>
</body>
</html>""",
        "q1b.php" : """<?php
session_start();

$eno = $_SESSION['eno'];
$ename = $_SESSION['ename'];
$addr = $_SESSION['addr'];

$basic = $_POST['basic'];
$da = $_POST['da'];
$hra = $_POST['hra'];

$total = $basic + $da + $hra;
?>

<html>
<body>
<h3>Employee Details</h3>

Eno: <?php echo $eno; ?><br>
Ename: <?php echo $ename; ?><br>
Address: <?php echo $addr; ?><br>
Basic: <?php echo $basic; ?><br>
DA: <?php echo $da; ?><br>
HRA: <?php echo $hra; ?><br>
Total: <?php echo $total; ?><br>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import numpy as np\n",
          "import pandas as pd\n",
          "import matplotlib.pyplot as plt\n",
          "\n",
          "from sklearn.linear_model import LinearRegression\n",
          "from sklearn.model_selection import train_test_split\n",
          "from sklearn.metrics import r2_score, mean_squared_error\n",
          "\n",
          "data = pd.DataFrame({\n",
          "    \"Length\": [10, 12, 13, 15, 16, 18, 20, 22, 25, 28],\n",
          "    \"Weight\": [100, 120, 130, 150, 160, 180, 200, 220, 250, 280]\n",
          "})\n",
          "\n",
          "print(data)\n",
          "\n",
          "print(data.shape)\n",
          "print(data.describe())\n",
          "\n",
          "X = data[['Length']]\n",
          "Y = data['Weight']\n",
          "\n",
          "plt.scatter(X, Y)\n",
          "plt.title(\"Fish Length vs Weight\")\n",
          "plt.xlabel(\"Length\")\n",
          "plt.ylabel(\"Weight\")\n",
          "plt.show()\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split( X, Y, test_size=0.25, random_state=0);\n",
          "\n",
          "model = LinearRegression()\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})\n",
          "print(df)\n",
          "\n",
          "print(model.predict([[17]]))\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 5,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.xml"]
        },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.xml" : """
        <?xml version="1.0" encoding="UTF-8"?>

<Items>
    <Item>
        <ItemName>Pen</ItemName>
        <ItemRate>10</ItemRate>
        <ItemQuantity>50</ItemQuantity>
    </Item>

    <Item>
        <ItemName>Notebook</ItemName>
        <ItemRate>40</ItemRate>
        <ItemQuantity>30</ItemQuantity>
    </Item>

    <Item>
        <ItemName>Pencil</ItemName>
        <ItemRate>5</ItemRate>
        <ItemQuantity>100</ItemQuantity>
    </Item>

    <Item>
        <ItemName>Eraser</ItemName>
        <ItemRate>3</ItemRate>
        <ItemQuantity>60</ItemQuantity>
    </Item>

    <Item>
        <ItemName>Marker</ItemName>
        <ItemRate>25</ItemRate>
        <ItemQuantity>20</ItemQuantity>
    </Item>
</Items>
        """,
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "import numpy as np\n",
          "import matplotlib.pyplot as plt\n",
          "\n",
          "from sklearn.linear_model import LogisticRegression\n",
          "from sklearn.model_selection import train_test_split\n",
          "from sklearn import metrics\n",
          "\n",
          "data = pd.read_csv(\"Iris.csv\")\n",
          "print(data.head())\n",
          "\n",
          "print(\"Shape:\", data.shape)\n",
          "\n",
          "print(\"\\nSpecies Count:\")\n",
          "print(data['Species'].value_counts())\n",
          "\n",
          "print(\"\\nStatistical Summary:\")\n",
          "print(data.describe())\n",
          "\n",
          "y = data['Species']\n",
          "x = data.drop(['Id', 'Species'], axis=1)\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split( x, y, test_size=0.30, random_state=0)\n",
          "\n",
          "model = LogisticRegression(random_state=10)\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})\n",
          "print(df)\n",
          "\n",
          "print(\"Accuracy:\", metrics.accuracy_score(y_test, y_pred))\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 6,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.php"]
        },
        {
        "question": "",
        "filenames": ["q1.xml"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.php" : """
        <?php

$xml = simplexml_load_file("q1.xml");

foreach($xml->book as $b)
{
    echo "Book ID: " . $b['id'] . "<br>";
    echo "Title: " . $b->title . "<br>";
    echo "Author: " . $b->author . "<br>";
    echo "Price: " . $b->price . "<br><br>";
}

?>
        """,
        "q1.xml" : """<?xml version="1.0"?>
<books>
    <book id="1">
        <title>PHP Basics</title>
        <author>ABC</author>
        <price>200</price>
    </book>

    <book id="2">
        <title>XML Guide</title>
        <author>XYZ</author>
        <price>300</price>
    </book>
</books> """,
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "transactions = [\n",
          "    ['Bread', 'Milk'],\n",
          "    ['Bread', 'Diaper', 'Beer', 'Eggs'],\n",
          "    ['Milk', 'Diaper', 'Beer', 'Coke'],\n",
          "    ['Bread', 'Milk', 'Diaper', 'Beer'],\n",
          "    ['Bread', 'Milk', 'Diaper', 'Coke']\n",
          "]\n",
          "\n",
          "print(transactions)\n",
          "\n",
          "import pandas as pd\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "print(df)\n",
          "\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "freq_items = apriori(df, min_support=0.5, use_colnames=True)\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='support', min_threshold=0.05)\n",
          "print(rules)\n",
          "\n",
          "freq_items = apriori(df, min_support=0.7, use_colnames=True)\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='support', min_threshold=0.05)\n",
          "print(rules)\n",
          "\n",
          "freq_items = apriori(df, min_support=0.4, use_colnames=True)\n",
          "print(freq_items)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 7,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.php"]
        },
        {
        "question": "",
        "filenames": ["q1.xml"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.php" : """<?php

$doc = new DOMDocument();
$doc->load("q1.xml");

$movies = $doc->getElementsByTagName("Movie");

foreach($movies as $m)
{
    $title = $m->getElementsByTagName("MovieTitle")->item(0)->nodeValue;
    $actor = $m->getElementsByTagName("ActorName")->item(0)->nodeValue;

    echo "Movie Title: " . $title . "<br>";
    echo "Actor Name: " . $actor . "<br><br>";
}

?>""",
        "q1.xml" : """<?xml version="1.0"?>
<MovieInfo>

    <Movie>
        <MovieNo>1</MovieNo>
        <MovieTitle>Inception</MovieTitle>
        <ActorName>Leonardo DiCaprio</ActorName>
        <ReleaseYear>2010</ReleaseYear>
    </Movie>

    <Movie>
        <MovieNo>2</MovieNo>
        <MovieTitle>Avengers</MovieTitle>
        <ActorName>Robert Downey Jr</ActorName>
        <ReleaseYear>2012</ReleaseYear>
    </Movie>

    <Movie>
        <MovieNo>3</MovieNo>
        <MovieTitle>Bahubali</MovieTitle>
        <ActorName>Prabhas</ActorName>
        <ReleaseYear>2015</ReleaseYear>
    </Movie>

    <Movie>
        <MovieNo>4</MovieNo>
        <MovieTitle>Dangal</MovieTitle>
        <ActorName>Aamir Khan</ActorName>
        <ReleaseYear>2016</ReleaseYear>
    </Movie>

    <Movie>
        <MovieNo>5</MovieNo>
        <MovieTitle>KGF</MovieTitle>
        <ActorName>Yash</ActorName>
        <ReleaseYear>2018</ReleaseYear>
    </Movie>

</MovieInfo>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "df_raw = pd.read_csv(\"market_basket.csv\")\n",
          "\n",
          "print(\"===== Dataset Info =====\")\n",
          "print(df_raw.info())\n",
          "\n",
          "print(\"\\n===== First 5 Rows =====\")\n",
          "print(df_raw.head())\n",
          "\n",
          "df_raw.dropna(inplace=True)\n",
          "\n",
          "transactions = df_raw.groupby('TID')['Item'].apply(list).tolist()\n",
          "\n",
          "print(\"\\n===== Transactions =====\")\n",
          "print(transactions[:5])\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\n===== Encoded Data =====\")\n",
          "print(df.head())\n",
          "\n",
          "freq_items = apriori(df, min_support=0.05, use_colnames=True)\n",
          "\n",
          "print(\"\\n===== Frequent Itemsets =====\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric=\"confidence\", min_threshold=0.5)\n",
          "\n",
          "print(\"\\n===== Association Rules =====\")\n",
          "print(rules)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 8,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """
        <html>
<body>

<script>

alert("Exams are near, have you started preparing for?");

var num1 = prompt("Enter first number:");
var num2 = prompt("Enter second number:");

var sum = parseInt(num1) + parseInt(num2);

confirm("Addition of two numbers is: " + sum);

</script>

</body>
</html>
""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "df_raw = pd.read_csv(\"Groceries_dataset.csv\")\n",
          "\n",
          "print(\"===== Dataset Info =====\")\n",
          "print(df_raw.info())\n",
          "\n",
          "print(\"\\n===== First 5 Rows =====\")\n",
          "print(df_raw.head())\n",
          "\n",
          "df_raw.dropna(inplace=True)\n",
          "\n",
          "df_raw['Transaction'] = df_raw['Member_number'].astype(str) + \"_\" + df_raw['Date']\n",
          "\n",
          "transactions = df_raw.groupby('Transaction')['itemDescription'].apply(list).tolist()\n",
          "\n",
          "print(\"\\n===== Sample Transactions =====\")\n",
          "print(transactions[:5])\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\n===== Encoded Data =====\")\n",
          "print(df.head())\n",
          "\n",
          "freq_items = apriori(df, min_support=0.01, use_colnames=True)\n",
          "\n",
          "print(\"\\n===== Frequent Itemsets =====\")\n",
          "print(freq_items.head())\n",
          "\n",
          "rules = association_rules(freq_items, metric=\"confidence\", min_threshold=0.2)\n",
          "\n",
          "print(\"\\n===== Association Rules =====\")\n",
          "print(rules.head())\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 9,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<body>

<form onsubmit="return validate()">
    Username: <input type="text" id="user"><br><br>
    Password: <input type="password" id="pass"><br><br>
    <input type="submit" value="Login">
</form>

<script>
function validate()
{
    var u = document.getElementById("user").value;
    var p = document.getElementById("pass").value;

    if(u == "")
    {
        alert("Username cannot be empty");
        return false;
    }

    if(p == "")
    {
        alert("Password cannot be empty");
        return false;
    }

    if(p.length < 6)
    {
        alert("Password must be at least 6 characters");
        return false;
    }

    alert("Login Successful");
    return true;
}
</script>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "transactions = [\n",
          "    ['Milk', 'Bread', 'Butter'],\n",
          "    ['Beer', 'Diaper', 'Chips'],\n",
          "    ['Milk', 'Diaper', 'Beer', 'Bread'],\n",
          "    ['Milk', 'Bread', 'Diaper', 'Butter'],\n",
          "    ['Bread', 'Butter'],\n",
          "    ['Milk', 'Diaper', 'Beer', 'Coke'],\n",
          "    ['Bread', 'Milk', 'Butter', 'Jam'],\n",
          "    ['Beer', 'Chips'],\n",
          "    ['Milk', 'Bread', 'Butter', 'Diaper'],\n",
          "    ['Coke', 'Chips']\n",
          "]\n",
          "\n",
          "print(\"===== Transactions =====\")\n",
          "print(transactions)\n",
          "\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "import pandas as pd\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\n===== Encoded Data =====\")\n",
          "print(df.head())\n",
          "\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "freq_items = apriori(df, min_support=0.3, use_colnames=True)\n",
          "\n",
          "print(\"\\n===== Frequent Itemsets =====\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric=\"confidence\", min_threshold=0.5)\n",
          "\n",
          "print(\"\\n===== Association Rules =====\")\n",
          "print(rules)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 10,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<head>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>

<p id="para">This is a paragraph.</p>

<button onclick="addText()">Click Me</button>

<script>
function addText()
{
    $("#para").before("Text added before paragraph<br>");
    $("#para").after("<br>Text added after paragraph");
}
</script>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "transactions = [\n",
          "    ['eggs', 'milk', 'bread'],\n",
          "    ['eggs', 'apple'],\n",
          "    ['milk', 'bread'],\n",
          "    ['apple', 'milk'],\n",
          "    ['milk', 'apple', 'bread']\n",
          "]\n",
          "\n",
          "print(\"Transactions:\")\n",
          "print(transactions)\n",
          "\n",
          "import pandas as pd\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\nEncoded Data:\")\n",
          "print(df)\n",
          "\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "freq_items = apriori(df, min_support=0.4, use_colnames=True)\n",
          "\n",
          "print(\"\\nFrequent Itemsets (min_support=0.4):\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='confidence', min_threshold=0.5)\n",
          "\n",
          "print(\"\\nAssociation Rules:\")\n",
          "print(rules)\n",
          "\n",
          "freq_items = apriori(df, min_support=0.6, use_colnames=True)\n",
          "print(\"\\nFrequent Itemsets (min_support=0.6):\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='confidence', min_threshold=0.5)\n",
          "print(\"\\nRules:\")\n",
          "print(rules)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 11,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
       {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<head>
<script>
function checkName()
{
    var name = document.getElementById("name").value;

    if(name != "")
    {
        document.getElementById("name").style.color = "red";
        document.getElementById("name").style.fontSize = "18px";
    }
    else
    {
        document.getElementById("img").style.display = "block";
    }
}

function loadImg()
{
    document.getElementById("img").style.display = "none";
}

function hoverImg()
{
    document.getElementById("img").style.width = "200px";
}

function clickImg()
{
    document.getElementById("img").style.height = "200px";
}

function mouseUpImg()
{
    document.getElementById("img").style.width = "100px";
    document.getElementById("img").style.height = "100px";
}
</script>
</head>

<body onload="loadImg()">

Enter Name:
<input type="text" id="name" onblur="checkName()"><br><br>

<img id="img" src="https://i.pinimg.com/736x/4b/5a/54/4b5a548746e53112a775716b7c70009e.jpg"
     onmouseover="hoverImg()"
     onclick="clickImg()"
     onmouseup="mouseUpImg()">

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "transactions = [\n",
          "    ['butter', 'bread', 'milk'],\n",
          "    ['butter', 'flour', 'milk', 'sugar'],\n",
          "    ['butter', 'eggs', 'milk', 'salt'],\n",
          "    ['eggs'],\n",
          "    ['butter', 'flour', 'milk', 'salt']\n",
          "]\n",
          "\n",
          "print(\"Transactions:\")\n",
          "print(transactions)\n",
          "\n",
          "import pandas as pd\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\nEncoded Data:\")\n",
          "print(df)\n",
          "\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "freq_items = apriori(df, min_support=0.4, use_colnames=True)\n",
          "\n",
          "print(\"\\nFrequent Itemsets (min_support=0.4):\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='confidence', min_threshold=0.5)\n",
          "\n",
          "print(\"\\nAssociation Rules:\")\n",
          "print(rules)\n",
          "\n",
          "freq_items = apriori(df, min_support=0.6, use_colnames=True)\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='confidence', min_threshold=0.5)\n",
          "print(rules)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 12,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.dat"]
        },
        {
        "question": "",
        "filenames": ["q1.html"]
      },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.dat" : """
        1, Rahul, 123456, 9876543210, Pune
        2, Amit, 654321, 9123456780, Mumbai
        3, Neha, 789456, 9988776655, Delhi
        """,
        "q1.html" : """<html>
<body>

<button onclick="loadData()">Print</button>

<table border="1">
<tr>
<th>SrNo</th>
<th>Name</th>
<th>Res No</th>
<th>Mobile</th>
<th>Address</th>
</tr>
<tbody id="tableData"></tbody>
</table>

<script>
function loadData()
{
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function()
    {
        if(this.readyState == 4 && this.status == 200)
        {
            document.getElementById("tableData").innerHTML = this.responseText;
        }
    };

    xhttp.open("GET", "q1.php", true);
    xhttp.send();
}
</script>

</body>
</html>""",
        "q1.php" : """<?php
$file = fopen("q1.dat", "r");

while(!feof($file))
{
    $line = fgets($file);
    if($line != "")
    {
        $data = explode(",", $line);
        echo "<tr>";
        echo "<td>".$data[0]."</td>";
        echo "<td>".$data[1]."</td>";
        echo "<td>".$data[2]."</td>";
        echo "<td>".$data[3]."</td>";
        echo "<td>".$data[4]."</td>";
        echo "</tr>";
    }
}
fclose($file);
?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "\n",
          "data = {\n",
          "    'Height': [150, 155, 160, 165, 170, 175, 180, 185, 190, 195],\n",
          "    'Weight': [50, 55, 60, 65, 70, 75, 80, 85, 90, 95]\n",
          "}\n",
          "\n",
          "df = pd.DataFrame(data)\n",
          "\n",
          "print(\"===== Dataset =====\")\n",
          "print(df)\n",
          "\n",
          "print(\"\\n===== Info =====\")\n",
          "print(df.info())\n",
          "\n",
          "print(\"\\n===== Description =====\")\n",
          "print(df.describe())\n",
          "\n",
          "X = df[['Height']]\n",
          "Y = df['Weight']\n",
          "\n",
          "print(\"\\nX (Independent):\")\n",
          "print(X)\n",
          "\n",
          "print(\"\\nY (Target):\")\n",
          "print(Y)\n",
          "\n",
          "from sklearn.model_selection import train_test_split\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split(\n",
          "    X, Y, test_size=0.25, random_state=0\n",
          ")\n",
          "\n",
          "print(\"\\n===== Training Data =====\")\n",
          "print(x_train)\n",
          "print(y_train)\n",
          "\n",
          "print(\"\\n===== Testing Data =====\")\n",
          "print(x_test)\n",
          "print(y_test)\n",
          "\n",
          "from sklearn.linear_model import LinearRegression\n",
          "\n",
          "model = LinearRegression()\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "print(\"\\n===== Predictions =====\")\n",
          "print(y_pred)\n",
          "\n",
          "result = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})\n",
          "print(\"\\n===== Comparison =====\")\n",
          "print(result)\n",
          "\n",
          "pred_weight = model.predict([[172.14]])\n",
          "print(\"Predicted Weight:\", pred_weight[0])\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 13,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<body>

Enter Name: <input type="text" onkeyup="showMsg(this.value)">
<p id="msg"></p>

<script>
function showMsg(str)
{
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function()
    {
        if(this.readyState == 4 && this.status == 200)
        {
            document.getElementById("msg").innerHTML = this.responseText;
        }
    };

    xhttp.open("GET", "q1.php?name=" + str, true);
    xhttp.send();
}
</script>

</body>
</html>""",
        "q1.php" : """<?php

$name = $_GET['name'];

if($name == "")
{
    echo "Stranger, please tell me your name!";
}
else if($name == "Rohit" || $name == "Virat" || $name == "Dhoni" || $name == "Ashwin " || $name == "Harbhajan")
{
    echo "Hello, master !";
}
else
{
    echo $name . ", I don't know you!";
}

?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "\n",
          "df = pd.read_csv(\"nursery.csv\")\n",
          "\n",
          "print(\"===== Dataset =====\")\n",
          "print(df.head(10))\n",
          "\n",
          "print(\"\\n===== Info =====\")\n",
          "print(df.info())\n",
          "\n",
          "from sklearn.preprocessing import LabelEncoder\n",
          "\n",
          "le = LabelEncoder()\n",
          "\n",
          "for col in df.columns:\n",
          "    df[col] = le.fit_transform(df[col])\n",
          "\n",
          "print(\"\\n===== Encoded Dataset =====\")\n",
          "print(df)\n",
          "\n",
          "X = df.drop('final evaluation', axis=1)\n",
          "\n",
          "Y = df['final evaluation']\n",
          "\n",
          "print(\"\\nX:\")\n",
          "print(X)\n",
          "\n",
          "print(\"\\nY:\")\n",
          "print(Y)\n",
          "\n",
          "from sklearn.model_selection import train_test_split\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split(\n",
          "    X, Y, test_size=0.25, random_state=0\n",
          ")\n",
          "\n",
          "print(\"\\n===== Training Data =====\")\n",
          "print(x_train)\n",
          "print(y_train)\n",
          "\n",
          "print(\"\\n===== Testing Data =====\")\n",
          "print(x_test)\n",
          "print(y_test)\n",
          "\n",
          "from sklearn.linear_model import LinearRegression\n",
          "\n",
          "model = LinearRegression()\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "print(\"\\n===== Prediction =====\")\n",
          "print(y_pred)\n",
          "\n",
          "result = pd.DataFrame({\n",
          "    'Actual': y_test,\n",
          "    'Predicted': y_pred\n",
          "})\n",
          "\n",
          "print(\"\\n===== Comparison =====\")\n",
          "print(result)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 14,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
  <head>
    <script type="text/javascript">
      function display() {
        var str = document.getElementById("txt1").value;

        if (str == "") {
          document.getElementById("i").innerHTML = "Please enter teacher name";
          return;
        }

        var ob = new XMLHttpRequest();
        ob.open("GET", "q1.php?q=" + encodeURIComponent(str), true);
        ob.send();

        ob.onreadystatechange = function () {
          if (ob.readyState == 4 && ob.status == 200) {
            document.getElementById("i").innerHTML = ob.responseText;
          }
        };
      }
    </script>
  </head>

  <body>
    <h2>DISPLAY INFORMATION OF TEACHER</h2>

    Enter Teacher Name:
    <input type="text" id="txt1" name="tn" />

    <br /><br />

    <input type="button" value="DISPLAY INFORMATION" onclick="display()" />

    <br /><br />

    <span id="i"></span>
  </body>
</html>


<!--

CREATE TABLE teacher(tno INT, tname VARCHAR(30), designation VARCHAR(30), salary VARCHAR(10));

INSERT INTO teacher VALUES(1, 'gautam', 'Professor', '60000');
INSERT INTO teacher VALUES(2, 'gajanan', 'Hod', '70000');
-->""",
        "q1.php" : """<?php
    $tn = $_REQUEST['q'];

    $connection = pg_connect("host=172.16.6.1 dbname=php26 user=postgres password=root");

    if(!$connection){
        echo "An error occured. <br>";
        exit;
    }

    $result = pg_query($connection, "SELECT * FROM teacher WHERE tname='$tn'");

    if(!$result){
        echo "An error occured. <br>";
        exit;
    }

    while($row = pg_fetch_row($result)){
        echo "$row[0] $row[1] $row[2] $row[3]";
    }

    pg_close();
?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "from sklearn.preprocessing import LabelEncoder\n",
          "\n",
          "transactions = [\n",
          "    ['Apple', 'Mango', 'Banana'],\n",
          "    ['Mango', 'Banana', 'Cabbage', 'Carrots'],\n",
          "    ['Mango', 'Banana', 'Carrots'],\n",
          "    ['Mango', 'Carrots']\n",
          "]\n",
          "\n",
          "print(\"Dataset:\")\n",
          "print(transactions)\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\nOne-Hot Encoded Data:\")\n",
          "print(df)\n",
          "\n",
          "le_df = df.apply(LabelEncoder().fit_transform)\n",
          "\n",
          "print(\"\\nLabel Encoded Data:\")\n",
          "print(le_df)\n",
          "\n",
          "print(\"\\n=== MIN SUPPORT = 0.5 ===\")\n",
          "\n",
          "freq_items_05 = apriori(df, min_support=0.5, use_colnames=True)\n",
          "print(\"\\nFrequent Itemsets:\")\n",
          "print(freq_items_05)\n",
          "\n",
          "rules_05 = association_rules(freq_items_05, metric='support', min_threshold=0.05)\n",
          "print(\"\\nAssociation Rules:\")\n",
          "print(rules_05)\n",
          "\n",
          "print(\"\\n=== MIN SUPPORT = 0.7 ===\")\n",
          "\n",
          "freq_items_07 = apriori(df, min_support=0.7, use_colnames=True)\n",
          "print(\"\\nFrequent Itemsets:\")\n",
          "print(freq_items_07)\n",
          "\n",
          "rules_07 = association_rules(freq_items_07, metric='support', min_threshold=0.05)\n",
          "print(\"\\nAssociation Rules:\")\n",
          "print(rules_07)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 15,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<body>

Enter Name: <input type="text" onkeyup="showHint(this.value)">
<p id="txtHint"></p>

<script>
function showHint(str)
{
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function()
    {
        if(this.readyState == 4 && this.status == 200)
        {
            document.getElementById("txtHint").innerHTML = this.responseText;
        }
    };

    xhttp.open("GET", "q1.php?q=" + str, true);
    xhttp.send();
}
</script>

</body>
</html>""",
        "q1.php" : """<?php

$q = $_GET["q"];

$names = array("Rahul","Ramesh","Rohit","Raj","Neha","Nikita","Amit","Ankit");

$suggestion = "";

if($q != "")
{
    $q = strtolower($q);

    foreach($names as $name)
    {
        if(strpos(strtolower($name), $q) === 0)
        {
            if($suggestion == "")
                $suggestion = $name;
            else
                $suggestion .= ", " . $name;
        }
    }
}

if($suggestion == "")
    echo "No suggestion";
else
    echo $suggestion;

?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "from sklearn.preprocessing import LabelEncoder\n",
          "\n",
          "transactions = [\n",
          "    ['Tata', 'Nexon', '2017'],\n",
          "    ['MG', 'Astor', '2021'],\n",
          "    ['KIA', 'Seltos', '2019'],\n",
          "    ['Hyundai', 'Creta', '2015']\n",
          "]\n",
          "\n",
          "print(\"Dataset:\")\n",
          "print(transactions)\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\nOne-Hot Encoded Data:\")\n",
          "print(df)\n",
          "\n",
          "le_df = df.apply(LabelEncoder().fit_transform)\n",
          "\n",
          "print(\"\\nLabel Encoded Data:\")\n",
          "print(le_df)\n",
          "\n",
          "print(\"\\n=== MIN SUPPORT = 0.5 ===\")\n",
          "\n",
          "freq_items_05 = apriori(df, min_support=0.5, use_colnames=True)\n",
          "print(\"\\nFrequent Itemsets:\")\n",
          "print(freq_items_05)\n",
          "\n",
          "if freq_items_05.empty:\n",
          "    print(\"\\nNo frequent itemsets found for min_support = 0.5\")\n",
          "else:\n",
          "    rules_05 = association_rules(freq_items_05, metric='support', min_threshold=0.05)\n",
          "    print(\"\\nAssociation Rules:\")\n",
          "    print(rules_05)\n",
          "\n",
          "\n",
          "print(\"\\n=== MIN SUPPORT = 0.25 ===\")\n",
          "\n",
          "freq_items_025 = apriori(df, min_support=0.25, use_colnames=True)\n",
          "print(\"\\nFrequent Itemsets:\")\n",
          "print(freq_items_025)\n",
          "\n",
          "if freq_items_025.empty:\n",
          "    print(\"\\nNo frequent itemsets found for min_support = 0.25\")\n",
          "else:\n",
          "    rules_025 = association_rules(freq_items_025, metric='support', min_threshold=0.05)\n",
          "    print(\"\\nAssociation Rules:\")\n",
          "    print(rules_025)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 16,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
        "question": "",
        "filenames": ["q1.xml"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<body>

Select Book:
<select onchange="showBook(this.value)">
    <option value="">Select</option>
    <option value="PHP">PHP</option>
    <option value="Java">Java</option>
    <option value="Python">Python</option>
</select>

<p id="result"></p>

<script>
function showBook(title)
{
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function()
    {
        if(this.readyState == 4 && this.status == 200)
        {
            document.getElementById("result").innerHTML = this.responseText;
        }
    };

    xhttp.open("GET", "q1.php?title=" + title, true);
    xhttp.send();
}
</script>

</body>
</html>""",
        "q1.php" : """<?php

$title = $_GET['title'];

$xml = simplexml_load_file("q1.xml");

foreach($xml->book as $b)
{
    if($b->title == $title)
    {
        echo "Title: " . $b->title . "<br>";
        echo "Author: " . $b->author . "<br>";
        echo "Year: " . $b->year . "<br>";
        echo "Price: " . $b->price . "<br>";
    }
}

?>""",
        "q1.xml" : """<?xml version="1.0"?>
<books>
    <book>
        <title>PHP</title>
        <author>ABC</author>
        <year>2020</year>
        <price>200</price>
    </book>

    <book>
        <title>Java</title>
        <author>XYZ</author>
        <year>2019</year>
        <price>300</price>
    </book>

    <book>
        <title>Python</title>
        <author>PQR</author>
        <year>2021</year>
        <price>250</price>
    </book>
</books>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import re\n",
          "import nltk\n",
          "from nltk.corpus import stopwords\n",
          "from nltk.tokenize import word_tokenize, sent_tokenize\n",
          "from heapq import nlargest\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "text = \"\"\"Hello all, (234)(Welcome to Python Programming Academy.\n",
          "Python Programming 122 Academy is a nice platform to learn new programming skills.\n",
          "It is difficult to get enrolled in this Academy.\"\"\"\n",
          "\n",
          "print(\"Original Text:\\n\", text)\n",
          "\n",
          "formatted_text = re.sub('[^a-zA-Z]', ' ', text)\n",
          "\n",
          "print(\"\\nPreprocessed Text:\\n\", formatted_text)\n",
          "\n",
          "formatted_text = formatted_text.lower()\n",
          "\n",
          "words = word_tokenize(formatted_text)\n",
          "\n",
          "stop_words = set(stopwords.words('english'))\n",
          "filtered_words = [word for word in words if word not in stop_words]\n",
          "\n",
          "word_freq = {}\n",
          "for word in filtered_words:\n",
          "    if word not in word_freq:\n",
          "        word_freq[word] = 1\n",
          "    else:\n",
          "        word_freq[word] += 1\n",
          "\n",
          "sentences = sent_tokenize(text)\n",
          "\n",
          "sentence_scores = {}\n",
          "for sent in sentences:\n",
          "    for word in word_tokenize(sent.lower()):\n",
          "        if word in word_freq:\n",
          "            if sent not in sentence_scores:\n",
          "                sentence_scores[sent] = word_freq[word]\n",
          "            else:\n",
          "                sentence_scores[sent] += word_freq[word]\n",
          "\n",
          "summary_sentences = nlargest(2, sentence_scores, key=sentence_scores.get)\n",
          "\n",
          "summary = ' '.join(summary_sentences)\n",
          "\n",
          "print(\"\\nSummary:\\n\", summary)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 17,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
       {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<head>
<script>
function showMessage()
{
    alert("Hello Good Morning");
}
</script>
</head>

<body onload="showMessage()">

<h2>Student Registration Form</h2>

<form>
    Name: <input type="text"><br><br>
    Email: <input type="email"><br><br>
    Mobile: <input type="number3"><br><br>
    Course: <input type="text"><br><br>

    <input type="submit" value="Register">
</form>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import re\n",
          "import nltk\n",
          "from nltk.corpus import stopwords\n",
          "from nltk.tokenize import word_tokenize, sent_tokenize\n",
          "from heapq import nlargest\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "text = \"\"\"So, keep working. Keep striving. Never give up. Fall down seven times, get up eight.\n",
          "Ease is a greater threat to progress than hardship. Ease is a greater threat to progress than hardship.\n",
          "So, keep moving, keep growing, keep learning. See you at work.\"\"\"\n",
          "\n",
          "print(\"Original Text:\\n\", text)\n",
          "\n",
          "formatted_text = re.sub('[^a-zA-Z]', ' ', text)\n",
          "\n",
          "print(\"\\nPreprocessed Text:\\n\", formatted_text)\n",
          "\n",
          "formatted_text = formatted_text.lower()\n",
          "\n",
          "words = word_tokenize(formatted_text)\n",
          "\n",
          "stop_words = set(stopwords.words('english'))\n",
          "filtered_words = [word for word in words if word not in stop_words]\n",
          "\n",
          "word_freq = {}\n",
          "for word in filtered_words:\n",
          "    word_freq[word] = word_freq.get(word, 0) + 1\n",
          "\n",
          "sentences = sent_tokenize(text)\n",
          "\n",
          "sentence_scores = {}\n",
          "for sent in sentences:\n",
          "    for word in word_tokenize(sent.lower()):\n",
          "        if word in word_freq:\n",
          "            sentence_scores[sent] = sentence_scores.get(sent, 0) + word_freq[word]\n",
          "\n",
          "summary_sentences = nlargest(2, sentence_scores, key=sentence_scores.get)\n",
          "\n",
          "summary = ' '.join(summary_sentences)\n",
          "\n",
          "print(\"\\nSummary:\\n\", summary)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 18,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<body>

Enter number: <input type="text" id="num"><br><br>
<button onclick="fibo()">Print Fibonacci</button>

<p id="result"></p>

<script>
function fibo()
{
    var n = document.getElementById("num").value;
    var a = 0, b = 1, c;
    var output = a + " " + b;

    for(var i = 2; i < n; i++)
    {
        c = a + b;
        output += " " + c;
        a = b;
        b = c;
    }

    document.getElementById("result").innerHTML = output;
}
</script>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import nltk\n",
          "import matplotlib.pyplot as plt\n",
          "from nltk.corpus import stopwords\n",
          "from nltk.tokenize import word_tokenize, sent_tokenize\n",
          "from nltk.probability import FreqDist\n",
          "from wordcloud import WordCloud\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "text = \"\"\"So, keep working. Keep striving. Never give up. Fall down seven times, get up eight.\n",
          "Ease is a greater threat to progress than hardship. Ease is a greater threat to progress than hardship.\n",
          "So, keep moving, keep growing, keep learning. See you at work.\"\"\"\n",
          "\n",
          "print(\"Original Text:\\n\", text)\n",
          "\n",
          "sentences = sent_tokenize(text)\n",
          "print(\"\\nSentences:\\n\", sentences)\n",
          "\n",
          "words = word_tokenize(text.lower())\n",
          "print(\"\\nWords:\\n\", words)\n",
          "\n",
          "stop_words = set(stopwords.words('english'))\n",
          "filtered_words = [word for word in words if word.isalpha() and word not in stop_words]\n",
          "\n",
          "print(\"\\nFiltered Words (No Stopwords):\\n\", filtered_words)\n",
          "\n",
          "freq_dist = FreqDist(filtered_words)\n",
          "\n",
          "print(\"\\nWord Frequencies:\\n\", freq_dist)\n",
          "\n",
          "plt.figure()\n",
          "freq_dist.plot(10)\n",
          "plt.title(\"Top 10 Word Frequencies\")\n",
          "plt.show()\n",
          "\n",
          "wordcloud = WordCloud(width=800, height=400, background_color='white').generate(\" \".join(filtered_words))\n",
          "\n",
          "plt.figure()\n",
          "plt.imshow(wordcloud)\n",
          "plt.axis(\"off\")\n",
          "plt.title(\"WordCloud\")\n",
          "plt.show()\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 19,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<body>

<form onsubmit="return validate()">
    Username: <input type="text" id="user"><br><br>
    Password: <input type="password" id="pass"><br><br>
    <input type="submit" value="Login">
</form>

<script>
function validate()
{
    var u = document.getElementById("user").value;
    var p = document.getElementById("pass").value;

    if(u == "")
    {
        alert("Username cannot be empty");
        return false;
    }

    if(p == "")
    {
        alert("Password cannot be empty");
        return false;
    }

    if(p.length < 6)
    {
        alert("Password must be at least 6 characters");
        return false;
    }

    alert("Login Successful");
    return true;
}
</script>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "import re\n",
          "import nltk\n",
          "import matplotlib.pyplot as plt\n",
          "from nltk.corpus import stopwords\n",
          "from nltk.tokenize import word_tokenize\n",
          "from wordcloud import WordCloud\n",
          "from sklearn.model_selection import train_test_split\n",
          "from sklearn.feature_extraction.text import CountVectorizer\n",
          "from sklearn.naive_bayes import MultinomialNB\n",
          "from sklearn.metrics import accuracy_score, classification_report\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "df = pd.read_csv(\"movie_review.csv\")\n",
          "\n",
          "print(\"Dataset Preview:\")\n",
          "print(df.head())\n",
          "\n",
          "def preprocess(text):\n",
          "    text = re.sub('[^a-zA-Z]', ' ', str(text)) \n",
          "    text = text.lower()\n",
          "    words = word_tokenize(text)\n",
          "    stop_words = set(stopwords.words('english'))\n",
          "    words = [w for w in words if w not in stop_words]\n",
          "    return \" \".join(words)\n",
          "\n",
          "df['clean_text'] = df['text'].apply(preprocess)\n",
          "\n",
          "print(\"\\nCleaned Data:\")\n",
          "print(df[['text', 'clean_text']].head())\n",
          "\n",
          "vectorizer = CountVectorizer()\n",
          "X = vectorizer.fit_transform(df['clean_text'])\n",
          "y = df['tag']  \n",
          "\n",
          "X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)\n",
          "\n",
          "model = MultinomialNB()\n",
          "model.fit(X_train, y_train)\n",
          "\n",
          "y_pred = model.predict(X_test)\n",
          "\n",
          "print(\"\\nAccuracy:\", accuracy_score(y_test, y_pred))\n",
          "print(\"\\nClassification Report:\\n\", classification_report(y_test, y_pred))\n",
          "\n",
          "pos_text = \" \".join(df[df['tag'] == 'pos']['clean_text'])\n",
          "\n",
          "wordcloud_pos = WordCloud(width=800, height=400, background_color='white').generate(pos_text)\n",
          "\n",
          "plt.figure()\n",
          "plt.imshow(wordcloud_pos)\n",
          "plt.axis(\"off\")\n",
          "plt.title(\"Positive Reviews WordCloud\")\n",
          "plt.show()\n",
          "\n",
          "neg_text = \" \".join(df[df['tag'] == 'neg']['clean_text'])\n",
          "\n",
          "wordcloud_neg = WordCloud(width=800, height=400, background_color='black').generate(neg_text)\n",
          "\n",
          "plt.figure()\n",
          "plt.imshow(wordcloud_neg)\n",
          "plt.axis(\"off\")\n",
          "plt.title(\"Negative Reviews WordCloud\")\n",
          "plt.show()\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 20,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.xml"]
        },
       {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.xml" : """<?xml version="1.0" encoding="UTF-8"?>

<Students>

    <Student>
        <RollNo>1</RollNo>
        <Name>Rahul</Name>
        <Course>BSc</Course>
        <Marks>75</Marks>
    </Student>

    <Student>
        <RollNo>2</RollNo>
        <Name>Amit</Name>
        <Course>BCA</Course>
        <Marks>82</Marks>
    </Student>

    <Student>
        <RollNo>3</RollNo>
        <Name>Neha</Name>
        <Course>MCA</Course>
        <Marks>88</Marks>
    </Student>

    <Student>
        <RollNo>4</RollNo>
        <Name>Pooja</Name>
        <Course>BCom</Course>
        <Marks>70</Marks>
    </Student>

    <Student>
        <RollNo>5</RollNo>
        <Name>Raj</Name>
        <Course>BBA</Course>
        <Marks>90</Marks>
    </Student>

</Students>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import nltk\n",
          "from nltk.corpus import stopwords\n",
          "from nltk.tokenize import word_tokenize\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "text = \"\"\"Hello all, Welcome to Python Programming Academy. Python Programming Academy is a nice platform to learn new programming skills. It is difficult to get enrolled in this Academy.\"\"\"\n",
          "\n",
          "words = word_tokenize(text.lower())\n",
          "\n",
          "stop_words = set(stopwords.words('english'))\n",
          "\n",
          "filtered_words = [word for word in words if word.isalpha() and word not in stop_words]\n",
          "\n",
          "print(\"Filtered Words:\\n\", filtered_words)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 21,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
         {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<head>
<script>
function checkNumber()
{
    var num = document.getElementById("num").value;

    if(num > 0)
        alert("Number is Positive");
    else if(num < 0)
        alert("Number is Negative");
    else
        alert("Number is Zero");
}
</script>
</head>

<body>

Enter Number: <input type="text" id="num"><br><br>
<button onclick="checkNumber()">Check</button>

</body>
</html>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from sklearn.linear_model import LinearRegression\n",
          "from sklearn.model_selection import train_test_split\n",
          "\n",
          "data = pd.DataFrame({\n",
          "    \"Age\": [19,35,26,27,19,27,27,32,25,35],\n",
          "    \"Purchased\": [0,0,0,0,0,0,0,1,0,1]\n",
          "})\n",
          "\n",
          "print(data)\n",
          "\n",
          "X = data[['Age']]\n",
          "Y = data['Purchased']\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.25)\n",
          "\n",
          "model = LinearRegression()\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "print(\"Predictions:\", y_pred)\n",
          "\n",
          "print(\"Prediction for Age 30:\", model.predict([[30]]))\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 22,
       "questions" : [
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import nltk\n",
          "from nltk.corpus import stopwords\n",
          "from nltk.tokenize import word_tokenize\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "text = \"\"\"Hello all, Welcome to Python Programming Academy. \n",
          "Python Programming Academy is a nice platform to learn new programming skills. \n",
          "It is difficult to get enrolled in this Academy.\"\"\"\n",
          "\n",
          "words = word_tokenize(text.lower())\n",
          "\n",
          "stop_words = set(stopwords.words('english'))\n",
          "\n",
          "filtered_words = [word for word in words if word.isalpha() and word not in stop_words]\n",
          "\n",
          "result = \" \".join(filtered_words)\n",
          "\n",
          "print(\"After Removing Stopwords:\\n\")\n",
          "print(result)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 23,
       "questions" : [
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import re\n",
          "\n",
          "text = \"\"\"Hello all, (234)(Welcome to Python Programming Academy.\n",
          "Python Programming 122 Academy is a nice platform to learn new programming skills.\n",
          "It is difficult to get enrolled in this Academy.\"\"\"\n",
          "\n",
          "print(\"Original Text:\\n\", text)\n",
          "\n",
          "clean_text = re.sub('[^a-zA-Z]', ' ', text)\n",
          "\n",
          "print(\"\\nCleaned Text:\\n\", clean_text)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 24,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.php"]
        },
        {
        "question": "",
        "filenames": ["q1.xml"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.php" : """<?php

if(isset($_POST['course']))
{
    $course = $_POST['course'];

    $xml = simplexml_load_file("q1.xml");

    echo "<table border='1'>";
    echo "<tr><th>RollNo</th><th>Name</th><th>Address</th><th>College</th><th>Course</th></tr>";

    foreach($xml->Student as $s)
    {
        if($s->Course == $course)
        {
            echo "<tr>";
            echo "<td>".$s->RollNo."</td>";
            echo "<td>".$s->Name."</td>";
            echo "<td>".$s->Address."</td>";
            echo "<td>".$s->College."</td>";
            echo "<td>".$s->Course."</td>";
            echo "</tr>";
        }
    }

    echo "</table>";
}
?>

<html>
<body>

<form method="post">
    Enter Course: <input type="text" name="course"><br><br>
    <input type="submit" value="Show">
</form>

</body>
</html>""",
        "q1.xml" : """<?xml version="1.0" encoding="UTF-8"?>

<Students>

    <Student>
        <RollNo>1</RollNo>
        <Name>Rahul</Name>
        <Address>Pune</Address>
        <College>ABC</College>
        <Course>BCA</Course>
    </Student>

    <Student>
        <RollNo>2</RollNo>
        <Name>Amit</Name>
        <Address>Mumbai</Address>
        <College>XYZ</College>
        <Course>BSc</Course>
    </Student>

    <Student>
        <RollNo>3</RollNo>
        <Name>Neha</Name>
        <Address>Delhi</Address>
        <College>PQR</College>
        <Course>BCA</Course>
    </Student>

    <Student>
        <RollNo>4</RollNo>
        <Name>Pooja</Name>
        <Address>Nashik</Address>
        <College>LMN</College>
        <Course>BCom</Course>
    </Student>

</Students>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "df = pd.read_csv(\"INvideos.csv\")\n",
          "\n",
          "print(\"Original Data:\")\n",
          "print(df.head())\n",
          "\n",
          "print(\"\\nMissing Values:\\n\", df.isnull().sum())\n",
          "\n",
          "df = df.dropna()\n",
          "\n",
          "df = df.drop_duplicates()\n",
          "\n",
          "df['views'] = pd.to_numeric(df['views'], errors='coerce')\n",
          "df['likes'] = pd.to_numeric(df['likes'], errors='coerce')\n",
          "df['dislikes'] = pd.to_numeric(df['dislikes'], errors='coerce')\n",
          "df['comment_count'] = pd.to_numeric(df['comment_count'], errors='coerce')\n",
          "\n",
          "df = df[(df['views'] >= 0) & (df['likes'] >= 0) & \n",
          "        (df['dislikes'] >= 0) & (df['comment_count'] >= 0)]\n",
          "\n",
          "print(\"\\nCleaned Data:\")\n",
          "# print(df.head())\n",
          "\n",
          "total_views = df['views'].sum()\n",
          "total_likes = df['likes'].sum()\n",
          "total_dislikes = df['dislikes'].sum()\n",
          "total_comments = df['comment_count'].sum()\n",
          "\n",
          "print(\"\\n===== TOTALS =====\")\n",
          "print(\"Total Views:\", total_views)\n",
          "print(\"Total Likes:\", total_likes)\n",
          "print(\"Total Dislikes:\", total_dislikes)\n",
          "print(\"Total Comments:\", total_comments)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 25,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.php"]
        },
        {
        "question": "",
        "filenames": ["q1.xml"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.php" : """<?php

$xml = simplexml_load_file("q1.xml");

$team1 = $xml->addChild("Team");
$team1->addAttribute("country", "India");
$team1->addChild("player", "Virat");
$team1->addChild("runs", "13000");
$team1->addChild("wicket", "5");

$team2 = $xml->addChild("Team");
$team2->addAttribute("country", "India");
$team2->addChild("player", "Ashwin");
$team2->addChild("runs", "3000");
$team2->addChild("wicket", "450");

$xml->asXML("q1.xml");

echo "India team data added successfully";

?>""",
        "q1.xml" : """<?xml version="1.0" encoding="UTF-8"?>
<CricketTeam>

    <Team country="Australia">
        <player>Warner</player>
        <runs>12000</runs>
        <wicket>0</wicket>
    </Team>

    <Team country="Australia">
        <player>Starc</player>
        <runs>1500</runs>
        <wicket>300</wicket>
    </Team>

<Team country="India"><player>Virat</player><runs>13000</runs><wicket>5</wicket></Team><Team country="India"><player>Ashwin</player><runs>3000</runs><wicket>450</wicket></Team></CricketTeam>
""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "import nltk\n",
          "from nltk.tokenize import word_tokenize\n",
          "from nltk.corpus import stopwords\n",
          "from textblob import TextBlob\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "df = pd.read_csv(\"covid_2021_1.csv\")\n",
          "\n",
          "print(\"Dataset Preview:\")\n",
          "print(df.head())\n",
          "\n",
          "df = df.dropna(subset=['comment_text'])\n",
          "\n",
          "df = df.drop_duplicates(subset=['comment_text'])\n",
          "\n",
          "df['comment_text'] = df['comment_text'].astype(str)\n",
          "\n",
          "print(\"\\nAfter Cleaning:\")\n",
          "print(df.shape)\n",
          "\n",
          "df['tokens'] = df['comment_text'].apply(lambda x: word_tokenize(x.lower()))\n",
          "\n",
          "print(\"\\nSample Tokens:\")\n",
          "print(df['tokens'].head())\n",
          "\n",
          "def get_sentiment(text):\n",
          "    polarity = TextBlob(text).sentiment.polarity\n",
          "    \n",
          "    if polarity > 0:\n",
          "        return \"Positive\"\n",
          "    elif polarity < 0:\n",
          "        return \"Negative\"\n",
          "    else:\n",
          "        return \"Neutral\"\n",
          "\n",
          "df['sentiment'] = df['comment_text'].apply(get_sentiment)\n",
          "\n",
          "print(\"\\nSentiment Sample:\")\n",
          "print(df[['comment_text', 'sentiment']].head())\n",
          "\n",
          "total = len(df)\n",
          "\n",
          "positive = (df['sentiment'] == 'Positive').sum()\n",
          "negative = (df['sentiment'] == 'Negative').sum()\n",
          "neutral = (df['sentiment'] == 'Neutral').sum()\n",
          "\n",
          "print(\"\\n===== SENTIMENT PERCENTAGE =====\")\n",
          "print(\"Positive %:\", (positive/total)*100)\n",
          "print(\"Negative %:\", (negative/total)*100)\n",
          "print(\"Neutral %:\", (neutral/total)*100)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 26,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
  <head>
    <script type="text/javascript">
      function display() {
        var str = document.getElementById("txt1").value;

        if (str == "") {
          document.getElementById("i").innerHTML = "Please enter employee name";
          return;
        }

        var ob = new XMLHttpRequest();
        ob.open("GET", "q1.php?q=" + encodeURIComponent(str), true);
        ob.send();

        ob.onreadystatechange = function () {
          if (ob.readyState == 4 && ob.status == 200) {
            document.getElementById("i").innerHTML = ob.responseText;
          }
        };
      }
    </script>
  </head>

  <body>
    <h2>DISPLAY INFORMATION OF employee</h2>

    Enter employee Name:
    <input type="text" id="txt1" name="tn" />

    <br /><br />

    <input type="button" value="DISPLAY INFORMATION" onclick="display()" />

    <br /><br />

    <span id="i"></span>
  </body>
</html>

<!--

CREATE TABLE employee(eno INT, ename VARCHAR(30), designation VARCHAR(30), salary VARCHAR(10));

INSERT INTO employee VALUES(1, 'gautam', 'Professor', '60000');
INSERT INTO employee VALUES(2, 'gajanan', 'Hod', '70000');
-->
""",
        "q1.php" : """<?php
    $tn = $_REQUEST['q'];

    $connection = pg_connect("host=172.16.6.1 dbname=php26 user=postgres password=root");

    if(!$connection){
        echo "An error occured. <br>";
        exit;
    }

    $result = pg_query($connection, "SELECT * FROM employee WHERE ename='$tn'");

    if(!$result){
        echo "An error occured. <br>";
        exit;
    }

    while($row = pg_fetch_row($result)){
        echo "$row[0] $row[1] $row[2] $row[3]";
    }

    pg_close();
?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import re\n",
          "import nltk\n",
          "from nltk.corpus import stopwords\n",
          "from nltk.tokenize import word_tokenize, sent_tokenize\n",
          "from heapq import nlargest\n",
          "\n",
          "nltk.download('punkt')\n",
          "nltk.download('stopwords')\n",
          "\n",
          "text = \"\"\"Hello all, Welcome to Python Programming Academy. \n",
          "Python Programming Academy is a nice platform to learn new programming skills. \n",
          "It is difficult to get enrolled in this Academy.\"\"\"\n",
          "\n",
          "print(\"Original Text:\\n\", text)\n",
          "\n",
          "clean_text = re.sub('[^a-zA-Z]', ' ', text)\n",
          "\n",
          "print(\"\\nPreprocessed Text:\\n\", clean_text)\n",
          "\n",
          "clean_text = clean_text.lower()\n",
          "\n",
          "words = word_tokenize(clean_text)\n",
          "\n",
          "stop_words = set(stopwords.words('english'))\n",
          "filtered_words = [w for w in words if w not in stop_words]\n",
          "\n",
          "word_freq = {}\n",
          "for word in filtered_words:\n",
          "    word_freq[word] = word_freq.get(word, 0) + 1\n",
          "\n",
          "sentences = sent_tokenize(text)\n",
          "\n",
          "sentence_scores = {}\n",
          "for sent in sentences:\n",
          "    for word in word_tokenize(sent.lower()):\n",
          "        if word in word_freq:\n",
          "            sentence_scores[sent] = sentence_scores.get(sent, 0) + word_freq[word]\n",
          "\n",
          "summary_sentences = nlargest(2, sentence_scores, key=sentence_scores.get)\n",
          "summary = \" \".join(summary_sentences)\n",
          "\n",
          "print(\"\\nSummary:\\n\", summary)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 27,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
<body>

Name: <input type="text" id="name"><br><br>
Age: <input type="text" id="age"><br><br>
Nationality: <input type="text" id="nation"><br><br>

<button onclick="checkVoter()">Check</button>

<p id="result"></p>

<script>
function checkVoter()
{
    var n = document.getElementById("name").value;
    var a = document.getElementById("age").value;
    var nat = document.getElementById("nation").value;

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function()
    {
        if(this.readyState == 4 && this.status == 200)
        {
            document.getElementById("result").innerHTML = this.responseText;
        }
    };

    xhttp.open("GET", "q1.php?name=" + n + "&age=" + a + "&nat=" + nat, true);
    xhttp.send();
}
</script>

</body>
</html>""",
        "q1.php" : """<?php

$name = $_GET['name'];
$age = $_GET['age'];
$nat = $_GET['nat'];

if(!ctype_upper($name))
{
    echo "Name must be in uppercase letters";
}
else if($age < 18)
{
    echo "Age must be 18 or above";
}
else if($nat != "Indian")
{
    echo "Nationality must be Indian";
}
else
{
    echo "Valid Voter";
}

?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "transactions = [\n",
          "    ['Milk', 'Bread', 'Butter'],\n",
          "    ['Beer', 'Diaper', 'Chips'],\n",
          "    ['Milk', 'Diaper', 'Beer', 'Bread'],\n",
          "    ['Milk', 'Bread', 'Diaper', 'Butter'],\n",
          "    ['Bread', 'Butter'],\n",
          "    ['Milk', 'Diaper', 'Beer', 'Coke'],\n",
          "    ['Bread', 'Milk', 'Butter', 'Jam'],\n",
          "    ['Beer', 'Chips'],\n",
          "    ['Milk', 'Bread', 'Butter', 'Diaper'],\n",
          "    ['Coke', 'Chips']\n",
          "]\n",
          "\n",
          "print(\"===== Transactions =====\")\n",
          "print(transactions)\n",
          "\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "import pandas as pd\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\n===== Encoded Data =====\")\n",
          "print(df.head())\n",
          "\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "freq_items = apriori(df, min_support=0.3, use_colnames=True)\n",
          "\n",
          "print(\"\\n===== Frequent Itemsets =====\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric=\"confidence\", min_threshold=0.5)\n",
          "\n",
          "print(\"\\n===== Association Rules =====\")\n",
          "print(rules)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 28,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.html"]
        },
        {
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.html" : """<html>
  <head>
    <script type="text/javascript">
      function display() {
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;

        if (username == "" || password == "") {
          document.getElementById("i").innerHTML =
            "Please enter username and password";
          return;
        }

        var ob = new XMLHttpRequest();
        ob.open(
          "GET",
          "login.php?username=" +
            encodeURIComponent(username) +
            "&password=" +
            encodeURIComponent(password),
          true,
        );
        ob.send();

        ob.onreadystatechange = function () {
          if (ob.readyState == 4 && ob.status == 200) {
            document.getElementById("i").innerHTML = ob.responseText;
          }
        };
      }
    </script>
  </head>

  <body>
    <h2>DISPLAY INFORMATION OF employee</h2>

    Enter User Name:
    <input type="text" id="username" name="username" />

    <br /><br />

    Enter Password:
    <input type="text" id="password" name="password" />

    <br /><br />

    <input type="button" value="DISPLAY INFORMATION" onclick="display()" />

    <br /><br />

    <span id="i"></span>

    <br /><br /><br /><br /><br /><br />
  </body>
</html>

<!--

CREATE TABLE users(id INT, username VARCHAR(30), password VARCHAR(30));

INSERT INTO users VALUES(1, 'gautam', 'gautam')
INSERT INTO users VALUES(2, 'gajanan', 'gajanan')

-->
""",
        "q1.php" : """<?php
$username = $_GET['username'];
$password = $_GET['password'];

$connection = pg_connect("host=172.16.6.1 dbname=php26 user=postgres password=root");

    if(!$connection){
        echo "An error occured. <br>";
        exit;
    }

    $result = pg_query($connection, "SELECT * FROM users WHERE username='$username' AND password='$password'");

    if(!$result){
        echo "An error occured. <br>";
        exit;
    }

    if (pg_num_rows($result) > 0) {
    echo "Login Successful ✅<br>";

    // optional: display data
    while ($row = pg_fetch_row($result)) {
        echo "Username: " . $row[0] . "<br>";
        echo "Password: " . $row[1] . "<br>";
    }
} else {
    echo "Invalid credentials ❌ or User not found";
}

pg_close($connection);
?>""",
        "untitled1.ipynb" : {
            "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "from sklearn.linear_model import LinearRegression\n",
          "from sklearn.model_selection import train_test_split\n",
          "\n",
          "data = pd.DataFrame({\n",
          "    \"Mileage\": [10, 15, 20, 25, 30, 18, 22, 28, 35, 40],\n",
          "    \"Price\": [200000, 180000, 160000, 150000, 140000, 170000, 155000, 145000, 130000, 120000]\n",
          "})\n",
          "\n",
          "print(data)\n",
          "\n",
          "X = data[['Mileage']]\n",
          "Y = data['Price']\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.25)\n",
          "\n",
          "model = LinearRegression()\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "print(\"Predictions:\", y_pred)\n",
          "\n",
          "print(\"Prediction for Mileage 20:\", model.predict([[20]]))\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 29,
       "questions" : [{
        "question": "",
        "filenames": ["q1.php"]
      },
        {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.php" : """<?php
if(isset($_POST['num']))
{
    $n = $_POST['num'];

    echo "Fibonacci Series:<br>";
    $a = 0;
    $b = 1;

    for($i=0; $i<$n; $i++)
    {
        echo $a . " ";
        $c = $a + $b;
        $a = $b;
        $b = $c;
    }

    echo "<br><br>";

    $sum = 0;
    $temp = $n;

    while($temp > 0)
    {
        $sum += $temp % 10;
        $temp = (int)($temp / 10);
    }

    echo "Sum of digits: " . $sum;
}
?>

<html>
<body>

<form method="post">
    Enter Number: <input type="text" name="num"><br><br>
    <input type="submit" value="Submit">
</form>

</body>
</html>""",
        "untitled1.ipynb" : {
          "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "import pandas as pd\n",
          "import numpy as np\n",
          "import matplotlib.pyplot as plt\n",
          "\n",
          "from sklearn.linear_model import LogisticRegression\n",
          "from sklearn.model_selection import train_test_split\n",
          "from sklearn import metrics\n",
          "\n",
          "data = pd.DataFrame({\n",
          "    \"Hours\": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],\n",
          "    \"Pass\":  [0, 0, 0, 0, 0, 1, 1, 1, 1, 1]\n",
          "})\n",
          "\n",
          "print(data.head())\n",
          "\n",
          "print(data.shape)\n",
          "print(data.describe())\n",
          "print(data['Pass'].value_counts())\n",
          "\n",
          "x = data[['Hours']]\n",
          "y = data['Pass']\n",
          "\n",
          "x_train, x_test, y_train, y_test = train_test_split(\n",
          "    x, y, test_size=0.30, random_state=0\n",
          ")\n",
          "\n",
          "model = LogisticRegression()\n",
          "model.fit(x_train, y_train)\n",
          "\n",
          "y_pred = model.predict(x_test)\n",
          "\n",
          "df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})\n",
          "print(df)\n",
          "\n",
          "print(\"Accuracy:\", metrics.accuracy_score(y_test, y_pred))\n",
          "\n",
          "print(\"Prediction for 5 hours:\", model.predict([[5]]))\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },

    {
       "slipNo": 30,
       "questions" : [
        {
            "question":"",
            "filenames": ["q1.xml"]
        },
         {
            "question":"",
            "filenames": ["untitled1.ipynb"]
        },
       ],

       "answers": {
        "q1.xml" : """<?xml version="1.0" encoding="UTF-8"?>

<Bookstore>

    <Yoga>
        <Book>
            <Book_Title>Yoga Basics</Book_Title>
            <Book_Author>Ram Dev</Book_Author>
            <Book_Price>250</Book_Price>
        </Book>

        <Book>
            <Book_Title>Advanced Yoga</Book_Title>
            <Book_Author>Anil Kumar</Book_Author>
            <Book_Price>300</Book_Price>
        </Book>
    </Yoga>

    <Story>
        <Book>
            <Book_Title>Fairy Tales</Book_Title>
            <Book_Author>ABC</Book_Author>
            <Book_Price>150</Book_Price>
        </Book>

        <Book>
            <Book_Title>Short Stories</Book_Title>
            <Book_Author>XYZ</Book_Author>
            <Book_Price>180</Book_Price>
        </Book>
    </Story>

    <Technical>
        <Book>
            <Book_Title>Java Programming</Book_Title>
            <Book_Author>James Gosling</Book_Author>
            <Book_Price>500</Book_Price>
        </Book>

        <Book>
            <Book_Title>Web Development</Book_Title>
            <Book_Author>John Smith</Book_Author>
            <Book_Price>450</Book_Price>
        </Book>
    </Technical>

</Bookstore>""",
        "untitled1.ipynb" : {
          "cells": [
      {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
          "transactions = [\n",
          "    ['eggs', 'milk', 'bread'],\n",
          "    ['eggs', 'apple'],\n",
          "    ['milk', 'bread'],\n",
          "    ['apple', 'milk'],\n",
          "    ['milk', 'apple', 'bread']\n",
          "]\n",
          "\n",
          "print(\"Transactions:\")\n",
          "print(transactions)\n",
          "\n",
          "import pandas as pd\n",
          "from mlxtend.preprocessing import TransactionEncoder\n",
          "\n",
          "te = TransactionEncoder()\n",
          "te_array = te.fit(transactions).transform(transactions)\n",
          "\n",
          "df = pd.DataFrame(te_array, columns=te.columns_)\n",
          "\n",
          "print(\"\\nEncoded Data:\")\n",
          "print(df)\n",
          "\n",
          "from mlxtend.frequent_patterns import apriori, association_rules\n",
          "\n",
          "freq_items = apriori(df, min_support=0.4, use_colnames=True)\n",
          "\n",
          "print(\"\\nFrequent Itemsets (min_support=0.4):\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='confidence', min_threshold=0.5)\n",
          "\n",
          "print(\"\\nAssociation Rules:\")\n",
          "print(rules)\n",
          "\n",
          "freq_items = apriori(df, min_support=0.6, use_colnames=True)\n",
          "\n",
          "print(\"\\nFrequent Itemsets (min_support=0.6):\")\n",
          "print(freq_items)\n",
          "\n",
          "rules = association_rules(freq_items, metric='confidence', min_threshold=0.5)\n",
          "\n",
          "print(\"\\nAssociation Rules:\")\n",
          "print(rules)\n"
        ]
      }
    ],
    "metadata": {
      "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
      },
      "language_info": {
        "file_extension": ".py",
        "mimetype": "text/x-python",
        "name": "python",
        "version": "3.x"
      }
    },
    "nbformat": 4,
    "nbformat_minor": 5
        }
       }
    },
]