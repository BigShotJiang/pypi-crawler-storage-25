"""news48 package metadata."""

__version__ = "0.2.2"
