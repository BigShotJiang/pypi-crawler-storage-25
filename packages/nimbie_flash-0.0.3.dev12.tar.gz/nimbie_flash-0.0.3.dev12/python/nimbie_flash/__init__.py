"""Python bindings and runtime helpers for the bundled Flash executor."""

from __future__ import annotations

import os
import platform
from pathlib import Path

from ._native import ExecResult, FlashInterpreter, LocalExecutor, MockExecutor, StdioExecutor, build_prompt_from_env

__all__ = [
    "ExecResult",
    "FlashInterpreter",
    "LocalExecutor",
    "MockExecutor",
    "StdioExecutor",
    "build_prompt_from_env",
    "bundled_stdio_executor_paths",
    "bundled_stdio_executor_path",
    "configure_bundled_executor",
]


_EXECUTOR_BASENAME = "flash-stdio-executor"
_ARCH_ALIASES = {
    "x86_64": "x86_64",
    "amd64": "x86_64",
    "aarch64": "aarch64",
    "arm64": "aarch64",
}
_FILENAME_ARCH = {
    "x86_64": "x86_64",
    "aarch64": "arm64",
}


def _normalize_target(target_os: str | None, target_arch: str | None) -> tuple[str | None, str | None]:
    os_name = (target_os or "").strip().lower() or None
    arch_name = (target_arch or "").strip().lower() or None
    if arch_name:
        arch_name = _ARCH_ALIASES.get(arch_name, arch_name)
    return os_name, arch_name


def _host_target() -> tuple[str | None, str | None]:
    system = platform.system().strip().lower()
    machine = platform.machine().strip().lower()
    if system.startswith("linux"):
        target_os = "linux"
    elif system.startswith("darwin"):
        target_os = "darwin"
    elif system.startswith("windows"):
        target_os = "windows"
    else:
        target_os = system or None
    target_arch = _ARCH_ALIASES.get(machine, machine or None)
    return target_os, target_arch


def _candidate_executor_names(target_os: str | None, target_arch: str | None) -> list[str]:
    suffix = ".exe" if os.name == "nt" else ""
    names: list[str] = []
    normalized_os, normalized_arch = _normalize_target(target_os, target_arch)
    if normalized_os and normalized_arch:
        file_arch = _FILENAME_ARCH.get(normalized_arch, normalized_arch)
        names.append(f"{_EXECUTOR_BASENAME}-{normalized_os}-{file_arch}{suffix}")
    names.append(f"{_EXECUTOR_BASENAME}{suffix}")
    return names


def _mark_executable(candidate: Path) -> Path:
    try:
        mode = candidate.stat().st_mode
        candidate.chmod(mode | 0o111)
    except OSError:
        pass
    return candidate


def bundled_stdio_executor_paths() -> list[Path]:
    bin_dir = Path(__file__).resolve().parent / "bin"
    if not bin_dir.is_dir():
        return []
    out: list[Path] = []
    seen: set[str] = set()
    for candidate in sorted(bin_dir.glob(f"{_EXECUTOR_BASENAME}*")):
        try:
            if not candidate.is_file():
                continue
            resolved = str(candidate.resolve())
        except Exception:
            resolved = str(candidate)
        if resolved in seen:
            continue
        seen.add(resolved)
        out.append(_mark_executable(candidate))
    return out


def bundled_stdio_executor_path(target_os: str | None = None, target_arch: str | None = None) -> Path | None:
    bin_dir = Path(__file__).resolve().parent / "bin"
    host_os, host_arch = _host_target()
    lookup_os = target_os if target_os is not None else host_os
    lookup_arch = target_arch if target_arch is not None else host_arch
    for name in _candidate_executor_names(lookup_os, lookup_arch):
        candidate = bin_dir / name
        if not candidate.is_file():
            continue
        return _mark_executable(candidate)
    return None


def configure_bundled_executor() -> Path | None:
    if os.environ.get("FLASH_STDIO_EXECUTOR_BIN"):
        return Path(os.environ["FLASH_STDIO_EXECUTOR_BIN"])
    bundled = bundled_stdio_executor_path()
    if bundled is not None:
        os.environ["FLASH_STDIO_EXECUTOR_BIN"] = str(bundled)
    return bundled


configure_bundled_executor()
