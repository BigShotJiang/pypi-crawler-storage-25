"""Shared low-level formatting helpers for debug output."""

from __future__ import annotations

import re
from typing import Any

from anemone import _best_effort

_SCORE_FRAGMENT_PATTERN = re.compile(r"(score=)(-?\d+(?:\.\d+)?)")

safe_getattr = _best_effort.safe_getattr
format_over_event = _best_effort.format_over_event
resolve_evaluation_over_event = _best_effort.resolve_evaluation_over_event


def safe_hasattr(obj: Any, attribute_name: str) -> bool:
    """Return whether ``obj`` exposes ``attribute_name`` for debug purposes."""
    try:
        getattr(obj, attribute_name)
    except (AttributeError, TypeError):
        return False
    return True


def format_branch_sequence(sequence: Any) -> str:
    """Render a principal-variation sequence."""
    try:
        return " -> ".join(str(item) for item in sequence)
    except TypeError:
        return str(sequence)


def format_value(value: Any) -> str:
    """Render a compact string for a value-like object."""
    score = safe_getattr(value, "score")
    certainty = safe_getattr(value, "certainty")
    over_event = safe_getattr(value, "over_event")

    parts: list[str] = []
    if score is not None:
        parts.append(f"score={score}")
    if certainty is not None:
        certainty_name = safe_getattr(certainty, "name")
        parts.append(
            f"certainty={certainty_name if certainty_name is not None else certainty}"
        )
    if over_event is not None:
        parts.append(f"over={format_over_event(over_event)}")

    return ", ".join(parts) if parts else str(value)


def compact_value_display(value_repr: str) -> str:
    """Round rendered score fragments to one decimal place for dense labels."""

    def _replace_score(match: re.Match[str]) -> str:
        try:
            score = float(match.group(2))
        except ValueError:
            return match.group(0)
        return f"{match.group(1)}{score:.1f}"

    return _SCORE_FRAGMENT_PATTERN.sub(_replace_score, value_repr, count=1)
