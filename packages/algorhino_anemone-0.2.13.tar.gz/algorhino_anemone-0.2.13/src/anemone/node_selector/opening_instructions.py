"""Provide classes and functions related to opening instructions in a game tree."""

from collections.abc import ItemsView, Iterator, Sequence, ValuesView
from dataclasses import dataclass
from enum import Enum
from random import Random
from typing import Any, Self

from valanga import BranchKey

from anemone import nodes
from anemone.dynamics import SearchDynamics
from anemone.nodes.utils import (
    a_branch_key_sequence_from_root,
    a_branch_str_sequence_from_root,
)

type OpeningInstructionKey = tuple[int, BranchKey]


@dataclass(slots=True)
class OpeningInstruction[NodeT: nodes.ITreeNode[Any] = nodes.ITreeNode[Any]]:
    """Represents an opening instruction for a specific node in the game tree."""

    node_to_open: NodeT
    branch: BranchKey

    def print_info(self, dynamics: SearchDynamics[Any, Any]) -> None:
        """Print information about the opening instruction."""
        print(
            f"OpeningInstruction: node_to_open {self.node_to_open.id} at hm {self.node_to_open.tree_depth} {self.node_to_open.state}| "
            f"a representative path from root to node_to_open is {a_branch_key_sequence_from_root(self.node_to_open)} "
            f"{a_branch_str_sequence_from_root(self.node_to_open, dynamics=dynamics)}| "
            f"self.branch {self.branch} {dynamics.action_name(self.node_to_open.state, self.branch)}"
        )


class OpeningInstructions[NodeT: nodes.ITreeNode[Any] = nodes.ITreeNode[Any]]:
    # TODO: do we need a dict? why not a set? verify
    """Represents a collection of opening instructions."""

    batch: dict[OpeningInstructionKey, OpeningInstruction[NodeT]]

    def __init__(
        self,
        dictionary: dict[OpeningInstructionKey, OpeningInstruction[NodeT]]
        | None = None,
    ) -> None:
        """Initialize the OpeningInstructions object.

        Args:
            dictionary: A dictionary of opening instructions (optional).

        """
        # here i use a dictionary because they are insertion ordered until there is an ordered set in python
        # order is important because some method give a batch where the last element in the batch are prioritary
        self.batch = {}

        if dictionary is not None:
            for key in dictionary:
                self[key] = dictionary[key]

    def __setitem__(
        self, key: OpeningInstructionKey, value: OpeningInstruction[NodeT]
    ) -> None:
        """Set an opening instruction in the collection.

        Args:
            key: The key for the opening instruction.
            value: The opening instruction.

        """
        # key is supposed to be a tuple with (node_to_open, branch)
        self.batch[key] = value

    def __getitem__(self, key: OpeningInstructionKey) -> OpeningInstruction[NodeT]:
        """Retrieve an opening instruction from the collection.

        Args:
            key: The key for the opening instruction.

        Returns:
            The opening instruction.

        """
        return self.batch[key]

    def __iter__(self) -> Iterator[OpeningInstructionKey]:
        """Return an iterator over the keys of the opening instructions.

        Returns:
            An iterator over the keys.

        """
        return iter(self.batch)

    def __bool__(self) -> bool:
        """Check if the collection is non-empty.

        Returns:
            True if the collection is non-empty, False otherwise.

        """
        return bool(self.batch)

    def merge(self, another_opening_instructions_batch: Self) -> None:
        """Merge another batch of opening instructions into the current collection.

        Args:
            another_opening_instructions_batch: Another OpeningInstructions object.

        """
        for (
            opening_instruction_key,
            opening_instruction,
        ) in another_opening_instructions_batch.items():
            if opening_instruction_key not in self.batch:
                self.batch[opening_instruction_key] = opening_instruction

    def pop_items(self, how_many: int, popped: Self) -> None:
        """Pop a specified number of opening instructions from the collection.

        Args:
            how_many: The number of opening instructions to pop.
            popped: An OpeningInstructions object to store the popped instructions.

        """
        how_many = min(how_many, len(self.batch))
        for _ in range(how_many):
            key, value = self.batch.popitem()
            popped[key] = value

    def values(self) -> ValuesView[OpeningInstruction[NodeT]]:
        """Return a view of the values in the collection.

        Returns:
            A view of the values.

        """
        return self.batch.values()

    def items(self) -> ItemsView[OpeningInstructionKey, OpeningInstruction[NodeT]]:
        """Return a view of the items (key-value pairs) in the collection.

        Returns:
            A view of the items.

        """
        return self.batch.items()

    def print_info(self, dynamics: SearchDynamics[Any, Any]) -> None:
        """Print information about the opening instructions in the collection."""
        print("OpeningInstructionsBatch: batch contains", len(self.batch), "elements:")
        for opening_instructions in self.batch.values():
            opening_instructions.print_info(dynamics=dynamics)

    def __len__(self) -> int:
        """Return the number of opening instructions in the collection.

        Returns:
            The number of opening instructions.

        """
        return len(self.batch)


def create_instructions_to_open_all_branches[NodeT: nodes.ITreeNode[Any]](
    branches_to_play: Sequence[BranchKey], node_to_open: NodeT
) -> OpeningInstructions[NodeT]:
    """Create opening instructions for all possible branches from a given node.

    Args:
        branches_to_play: The branch keys to open.
        node_to_open: The node to open.

    Returns:
        An OpeningInstructions object containing the opening instructions.

    """
    opening_instructions_batch: OpeningInstructions[NodeT] = OpeningInstructions()

    for branch_to_play in branches_to_play:
        # at the moment it looks redundant keys are almost the same as values but its clean
        # the keys are here for fast and redundant proof insertion
        # and the values are here for clean data processing
        opening_instructions_batch[(node_to_open.id, branch_to_play)] = (
            OpeningInstruction(node_to_open=node_to_open, branch=branch_to_play)
        )
    return opening_instructions_batch


class OpeningType(Enum):
    """Represents the type of opening to use."""

    ALL_CHILDREN = "all_children"


class OpeningInstructor:
    """Represents an opening instructor that provides opening instructions based on a specific opening type."""

    def __init__(
        self,
        opening_type: OpeningType,
        random_generator: Random,
        dynamics: SearchDynamics[Any, Any],
    ) -> None:
        """Initialize the OpeningInstructor object.

        Args:
            opening_type: The type of opening to use.
            random_generator: A random number generator.
            dynamics: The SearchDynamics object used for labeling the edges in the visualization.

        """
        self.opening_type = opening_type
        self.random_generator = random_generator
        self.dynamics = dynamics

    def all_branches_to_open(
        self, node_to_open: nodes.ITreeNode[Any]
    ) -> Sequence[BranchKey]:
        """Return a list of all possible branches to open from a given node.

        Args:
            node_to_open: The node to open.

        Returns:
            A list of branch keys.

        """
        if self.opening_type == OpeningType.ALL_CHILDREN:
            node_to_open.all_branches_generated = True
            branches_to_play = self.dynamics.legal_actions(node_to_open.state).get_all()

        else:
            raise NotImplementedError("Hello-la")
        return branches_to_play
