import { Writable, Transform } from "stream";
import { resolve as _resolve } from "path";
const ext = "js";

import { createElement as _createElement } from "react";
import { renderToPipeableStream } from "react-dom/server";


class LoggingTransformStream extends Transform {
  constructor(options) {
    super(options);
  }

  _transform(chunk, encoding, callback) {
    // Check if chunk is undefined
    if (typeof chunk === 'undefined') {
      console.error("Received undefined chunk");
      // Call the callback to signal that the chunk has been processed
      return callback();
    }

    // Pass the chunk through to the next stream in the pipeline
    this.push(chunk);
    // Call the callback to signal that the chunk has been processed
    callback();
  }

}

// Custom writable stream that logs data to the console
class LoggingWritableStream extends Writable {
  constructor(options) {
    super(options);
    this.data = [];
  }

  renderString() {
    return this.data.join("");
  }

  _write(chunk, encoding, callback) {
    this.data.push(chunk.toString());
    // Call the callback to signal that the chunk has been processed
    callback();
  }
}

import { pathToFileURL } from 'url';

class SSR {
  constructor(cwd, debug = false) {
    this.cwd = cwd;
    this.debug = debug;
  }
  async render(props) {
    return new Promise(async (resolve, reject) => {
      try {
        const cacheBuster = this.debug ? `?v=${Date.now()}` : '';
        const getImportPath = (p) => {
          const absPath = _resolve(p);
          return pathToFileURL(absPath).href + cacheBuster;
        };

        const App = await import(getImportPath("./_kiwijs/build/_kiwijs/__build__/app.js"));
        const StaticRouter = await import(getImportPath("./_kiwijs/build/_kiwijs/__build__/StaticRouterWrapper.js"));
        const { getAppContext } = await import(getImportPath("./_kiwijs/build/app/layout.js"));
        const { location } = props;
        const ReactElement = _createElement(App.default, {
          children: null,
          location,
          ...props,
        });
        const StaticRouterWrapper = _createElement(StaticRouter.default, {
          children: ReactElement,
          url: props.location.path,
        });
        const providedCtx = {
          app: StaticRouterWrapper,
          renderApp: () => ({
            enhanceApp: (App) => App,
            getStyles: (App) => App,
            styles: () => "",
            finally: () => { }
          })
        }
        const renderApp = (render) => {
          const rendered = render.renderApp();
          const componentHTML =
            renderToPipeableStream(rendered.getStyles(StaticRouterWrapper));

          // Create an instance of the logging writable stream
          const loggingWritableStream = new LoggingWritableStream();
          const loggingTransformStream = new LoggingTransformStream();
          componentHTML.pipe(loggingTransformStream).pipe(loggingWritableStream);
          // After the stream has ended, the concatenated string can be accessed
          loggingWritableStream.on("finish", () => {
            resolve(loggingWritableStream.renderString().concat(rendered.styles()))
            rendered.finally()
          });
        }
        if (typeof getAppContext === "function") {
          Object.assign(providedCtx, await getAppContext(providedCtx));
        }
        renderApp(providedCtx)

      } catch (error) {
        console.log(error, "error")
        reject(error);
      }
    })
  }

  // beta
  async partialRender(props) {
    return new Promise(async (resolve, reject) => {
      try {
        const componentPath = _resolve(this.cwd, "_kiwijs", "build", "app", ...props.location.path.split("/"), "index.js");
        const Component = await import(pathToFileURL(componentPath).href);
        const staticRouterPath = _resolve(this.cwd, "_kiwijs", "build", "app", "StaticRouterWrapper.js");
        const StaticRouter = await import(pathToFileURL(staticRouterPath).href);
      const { location } = props;
      const ReactElement = _createElement(Component.default, {
        children: null,
        location,
        ...props,
      });
      const StaticRouterWrapper = _createElement(StaticRouter.default, {
        children: ReactElement,
        url: props.location.path,
      });
      const componentHTML =
        renderToPipeableStream(ReactElement);

      // Create an instance of the logging writable stream
      const loggingWritableStream = new LoggingWritableStream();
      const loggingTransformStream = new LoggingTransformStream();
      componentHTML.pipe(loggingTransformStream).pipe(loggingWritableStream);
      // After the stream has ended, the concatenated string can be accessed
      loggingWritableStream.on("finish", () => {
        resolve(loggingWritableStream.renderString())
      });
      } catch (error) {
        reject(error);
      }
    })
  }

  async createElement(path, props) {
    const componentFile = await import(pathToFileURL(path).href);
    const Component = componentFile.default; // Import the individual component
    const reactElem = _createElement(Component, {
      ...props,
    });
    return reactElem;
  }
}


export default SSR
