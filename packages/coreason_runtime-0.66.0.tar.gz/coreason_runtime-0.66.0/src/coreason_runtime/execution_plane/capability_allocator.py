# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import hashlib
import os
import secrets
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar

import extism  # type: ignore[import-untyped]
from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent  # type: ignore[import-untyped]

from coreason_runtime.execution_plane.blob_store import UniversalBlobStore
from coreason_runtime.execution_plane.io_broker import IOBroker
from coreason_runtime.utils.exceptions import IntegrityViolationError

try:
    from coreason_manifest.utils.algebra import compute_merkle_directory_cid
except ImportError:
    # Fallback for environments where coreason-manifest is not yet updated.
    # This is a verbatim copy of the canonical implementation from coreason-manifest.
    def compute_merkle_directory_cid(file_contents: dict[str, bytes]) -> str:  # type: ignore[misc]
        """Merkle-style SHA-256 CID (local fallback)."""
        file_hashes: list[str] = []
        for filename in sorted(file_contents.keys()):
            file_hash = hashlib.sha256(file_contents[filename]).hexdigest()
            file_hashes.append(f"{filename}:{file_hash}")
        merkle_input = "\n".join(file_hashes).encode("utf-8")
        return f"sha256:{hashlib.sha256(merkle_input).hexdigest()}"


if TYPE_CHECKING:
    from coreason_manifest import CognitiveActionSpaceManifest


def verify_bundle_integrity(bundle_files: dict[str, bytes], expected_hash: str | None) -> bool:
    """Zero-trust Merkle verification: recompute the CID and compare to the registry.

    Delegates the Merkle hash to ``compute_merkle_directory_cid()`` from the
    shared kernel (``coreason-manifest``) — the single canonical implementation
    used across the entire CoReason ecosystem.

    If the expected_hash is None or empty (e.g. DRAFT capabilities that have not
    yet been compiled), verification is skipped and the function returns True.

    Args:
        bundle_files: Mapping of canonical filenames to their raw bytes.
            Expected keys: ``__init__.py``, ``manifest.yaml``, ``schema.py``, ``server.py``.
            For ``manifest.yaml``, pass the bytes with ``cryptographic_hash``
            set to null (matching the compilation-side zeroing).
        expected_hash: The sha256-prefixed hex digest from the compiled registry.

    Returns:
        True if verification passes.

    Raises:
        IntegrityViolationError: If the computed hash does not match the expected hash.
    """
    if not expected_hash:
        return True  # DRAFT capabilities skip verification

    actual = compute_merkle_directory_cid(bundle_files)

    if actual != expected_hash:
        raise IntegrityViolationError(
            f"Bundle CID mismatch. Expected {expected_hash}, got {actual}. Possible supply-chain attack or stale cache."
        )
    return True


def _initialize_wasmtime_cache() -> None:
    """Natively enable Wasmtime JIT compilation caching by initializing Wasmtime's native cache config."""
    cache_path = Path(r"C:\Users\CoReasonAdmin\.cache\wasmtime\config.toml")
    if not cache_path.exists():
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            config_content = (
                f'[cache]\nenabled = true\ndirectory = "{str(cache_path.parent / "cache").replace("\\", "/")}"\n'
            )
            cache_path.write_text(config_content, encoding="utf-8")
        except Exception:
            try:
                fallback_path = Path(tempfile.gettempdir()) / "wasmtime_config.toml"
                if not fallback_path.exists():
                    fallback_path.write_text("[cache]\nenabled = true\n", encoding="utf-8")
                cache_path = fallback_path
            except Exception:  # noqa: S110 # nosec B110
                pass
    os.environ["WASMTIME_CACHE"] = str(cache_path)


_initialize_wasmtime_cache()


class ExtismRunner:
    _cache: ClassVar[dict[int, extism.Plugin]] = {}

    @classmethod
    def get_plugin(cls, wasm_bytes: bytes, expected_hash: str) -> extism.Plugin:
        # Verify cryptographically before loading (constant time comparison)
        actual_hash = hashlib.sha256(wasm_bytes).hexdigest()
        if not secrets.compare_digest(actual_hash, expected_hash):
            raise TopologicalSeveranceEvent("WASM binary hash mismatch: zero-trust attestation failed.")

        # Cache loaded plugins to keep execution contexts warm
        h = hash(wasm_bytes)
        if h not in cls._cache:
            # SOTA 2026 Sandbox: Disable WASI capabilities unless explicitly allowed
            cls._cache[h] = extism.Plugin(wasm_bytes, wasi=False)
        return cls._cache[h]


def dynamic_capability_injection(
    action_space: "CognitiveActionSpaceManifest", mounted_capability: dict[str, Any]
) -> "CognitiveActionSpaceManifest":
    """Dynamically appends a discovered capability to the agent's CognitiveActionSpaceManifest at runtime.

    Do not require a restart of the node.
    """
    from coreason_manifest import (
        ExtismInProcessProfile,
        MCPCapabilityWhitelistPolicy,
        MCPServerManifest,
        StdioTransportProfile,
    )

    capability_name = mounted_capability.get("name", "dynamic_tool")
    is_in_process = mounted_capability.get("in_process", True)

    transport: ExtismInProcessProfile | StdioTransportProfile
    if is_in_process:
        transport = ExtismInProcessProfile.model_construct(
            wasm_path=str(mounted_capability.get("wasm_path", "plugins/dynamic_tool.wasm")),
            env_vars=mounted_capability.get("env_vars", {}),
        )
    else:
        transport = StdioTransportProfile.model_construct(command="extism", args=[])

    action_space.capabilities[capability_name] = MCPServerManifest.model_construct(
        server_cid="dynamic_mcp_pool",
        binary_hash=str(mounted_capability.get("binary_hash", "")),
        transport=transport,
        capability_whitelist=MCPCapabilityWhitelistPolicy.model_construct(),
        attestation_receipt=None,  # type: ignore[arg-type]
    )

    return action_space


def allocate_storage_operator() -> UniversalBlobStore:
    """Allocates and returns a pre-configured OpenDAL storage operator.

    Credentials are automatically handled by the UniversalBlobStore via environment variables,
    avoiding any logging of sensitive data.
    """
    return UniversalBlobStore()


def allocate_io_stream(input_topic: str, output_topic: str, mapping_logic: str | None = None) -> str:
    """Allocates an IO stream by generating a Redpanda Connect YAML topology string.

    This replaces internal Python IO streams.
    """
    broker = IOBroker()
    return broker.generate_topology(input_topic=input_topic, output_topic=output_topic, mapping_logic=mapping_logic)
