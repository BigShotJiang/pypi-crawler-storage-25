# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import importlib.util
import os
import tempfile

import pytest

import coreason_runtime.execution_plane.license_verifier as license_verifier_mod
from coreason_runtime.execution_plane.integrity import (
    _VERIFIED_MODULES_CACHE,
    IntegrityViolationError,
    assert_module_integrity,
)


def test_integrity_check_passes_on_unmodified_module() -> None:
    # This should pass without raising any exception if the file hasn't been tampered with
    # If the file gets reformatted or changed, this hash will need to be updated.
    expected_hash = "8746ade8b9540e700647aef1dabd8da7195ae70cb57f6244f02d8f853a7c1bc6"
    assert_module_integrity(license_verifier_mod, expected_hash)


def test_integrity_check_fails_on_bad_hash() -> None:
    bad_hash = "0000000000000000000000000000000000000000000000000000000000000000"

    with pytest.raises(IntegrityViolationError) as exc_info:
        assert_module_integrity(license_verifier_mod, bad_hash)

    assert "CRITICAL INTEGRITY VIOLATION" in str(exc_info.value)


def test_rust_module_direct_verification() -> None:
    """If coreason_runtime_rust is compiled, verify its functions directly with various inputs."""
    try:
        from coreason_runtime import coreason_runtime_rust  # type: ignore[attr-defined]
    except ImportError:
        pytest.skip("coreason_runtime_rust extension not compiled/installed.")

    source = "print('Hello World')\r\n"
    expected = "6075c051cc5f23ddd8926338be443cf2b28ee2422f41d0203acd005c8d1fe635"  # sha256 of normalized "print('Hello World')\n"

    assert coreason_runtime_rust.verify_module_integrity(source, expected) is True
    assert coreason_runtime_rust.verify_module_integrity(source, "badhash") is False


def _clear_caches() -> None:
    _VERIFIED_MODULES_CACHE.clear()
    try:
        from coreason_runtime import coreason_runtime_rust  # type: ignore[attr-defined]

        coreason_runtime_rust.clear_cache()
    except ImportError:
        pass


def test_integrity_check_caching() -> None:
    """Verify that successful integrity checks are cached in memory for performance."""
    expected_hash = "8746ade8b9540e700647aef1dabd8da7195ae70cb57f6244f02d8f853a7c1bc6"

    # Ensure test isolation by clearing the cache
    _clear_caches()

    assert_module_integrity(license_verifier_mod, expected_hash)

    # Module name should exist in cache map with expected hash
    module_name = license_verifier_mod.__name__
    try:
        from coreason_runtime import coreason_runtime_rust  # type: ignore[attr-defined]

        assert coreason_runtime_rust.check_cache(module_name, expected_hash) is True
    except ImportError:
        assert module_name in _VERIFIED_MODULES_CACHE
        assert _VERIFIED_MODULES_CACHE[module_name] == expected_hash


def test_ast_canonicalization_and_signatures() -> None:
    """Verify that AST canonicalization ignores comments/formatting and validates Ed25519 signatures."""
    import ast

    from cryptography.hazmat.primitives.asymmetric import ed25519

    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    pub_hex = public_key.public_bytes_raw().hex()

    # Original source
    source = "def target_func():\n    return 42\n"
    canonical = ast.unparse(ast.parse(source))
    sig_hex = private_key.sign(canonical.encode("utf-8")).hex()

    # Write to temp file
    with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w", encoding="utf-8") as f:
        f.write(f"{source}\n# CORESIG: {sig_hex}\n")
        temp_path = f.name

    try:
        # Load module dynamically
        spec = importlib.util.spec_from_file_location("dynamic_signed_mod", temp_path)
        assert spec is not None
        assert spec.loader is not None
        dummy_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(dummy_mod)

        # Clear cache first
        _clear_caches()

        # 1. Verify it passes validation using the signature public key
        assert_module_integrity(dummy_mod, pub_hex)

        # 2. Test Resilience: Rewrite file with extra spaces and comments (breaks standard hash, leaves AST intact)
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(
                f"def target_func():\n    # This is a comment that shouldn't affect AST!\n    return    42\n# CORESIG: {sig_hex}\n"
            )

        # Clear cache to force re-reading from disk
        _clear_caches()

        # Should still pass signature verification due to AST canonicalization!
        assert_module_integrity(dummy_mod, pub_hex)

        # 3. Test Mutation Tampering: Alter return value to 43 (mutates AST structure)
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(f"def target_func():\n    return 43\n# CORESIG: {sig_hex}\n")

        _clear_caches()
        with pytest.raises(IntegrityViolationError) as exc_info:
            assert_module_integrity(dummy_mod, pub_hex)

        assert "Signature verification failed" in str(exc_info.value)

    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def test_rust_cache_check_and_update() -> None:
    """Verify check_cache and update_cache behave correctly."""
    try:
        from coreason_runtime import coreason_runtime_rust  # type: ignore[attr-defined]
    except ImportError:
        pytest.skip("coreason_runtime_rust extension not compiled/installed.")

    mod_name = "test_cache_module"
    expected = "some_expected_hash"

    # Initially false
    assert coreason_runtime_rust.check_cache(mod_name, expected) is False

    # Update cache
    coreason_runtime_rust.update_cache(mod_name, expected)

    # Now true
    assert coreason_runtime_rust.check_cache(mod_name, expected) is True
    # Different hash should be false
    assert coreason_runtime_rust.check_cache(mod_name, "other_hash") is False


def test_verify_signatures_parallel() -> None:
    """Verify verify_signatures_parallel executes signature validation in batch."""
    try:
        from coreason_runtime import coreason_runtime_rust  # type: ignore[attr-defined]
    except ImportError:
        pytest.skip("coreason_runtime_rust extension not compiled/installed.")

    from cryptography.hazmat.primitives.asymmetric import ed25519

    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    pub_hex = public_key.public_bytes_raw().hex()

    messages = ["message 1", "message 2", "message 3"]
    signatures = [private_key.sign(msg.encode("utf-8")).hex() for msg in messages]

    # Verify matching signatures
    results = coreason_runtime_rust.verify_signatures_parallel(messages, signatures, pub_hex)
    assert results == [True, True, True]

    # Verify failing signatures
    bad_signatures = [signatures[0], "00" * 64, signatures[2]]
    results_bad = coreason_runtime_rust.verify_signatures_parallel(messages, bad_signatures, pub_hex)
    assert results_bad == [True, False, True]
